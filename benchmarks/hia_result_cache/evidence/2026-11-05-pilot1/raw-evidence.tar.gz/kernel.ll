; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ugt i64 %p_0_0, 1048576
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  ret i64 9223372036854775809
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 %p_2_0, i1 false)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 %p_2_0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_2 ]
  %p_3_2 = phi i1 [ %t4, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %t6, %edge_2 ]
  %p_3_4 = phi i8 [ 1, %edge_2 ]
  br label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_3 ]
  %p_4_2 = phi i1 [ %t4, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_4_4 = phi i8 [ 1, %edge_3 ]
  %t7 = extractvalue %hia.buffer %p_4_3, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  %t10 = zext i8 %p_4_4 to i64
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 9223372036854775808, i64 %t10)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  ret i64 %t12
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ], [ %p_6_0, %edge_7 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ], [ %p_6_1, %edge_7 ]
  %p_5_2 = phi %hia.buffer [ %p_3_3, %edge_4 ], [ %p_6_2, %edge_7 ]
  %p_5_3 = phi i64 [ %p_3_0, %edge_4 ], [ %p_6_3, %edge_7 ]
  %p_5_4 = phi i64 [ 0, %edge_4 ], [ %t26, %edge_7 ]
  %t16 = icmp ult i64 %p_5_4, %p_5_3
  br i1 %t16, label %edge_5, label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_5 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_5 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_5 ]
  %p_6_3 = phi i64 [ %p_5_3, %edge_5 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_5 ]
  %t17 = trunc i64 %p_6_4 to i32
  %t18 = add i32 %t17, %p_6_1
  %t19 = trunc i32 %t18 to i8
  %t20 = extractvalue %hia.buffer %p_6_2, 0
  %t21 = extractvalue %hia.buffer %p_6_2, 1
  %t22 = icmp ult i64 %p_6_4, %t21
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  %t24 = getelementptr i8, ptr %t20, i64 %p_6_4
  store i8 %t19, ptr %t24, align 1
  %t25 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_6_4, i64 1)
  %t26 = extractvalue { i64, i1 } %t25, 0
  %t27 = extractvalue { i64, i1 } %t25, 1
  %t28 = xor i1 %t27, true
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  br label %edge_7
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_6 ]
  %p_7_3 = phi i64 [ %p_5_3, %edge_6 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_6 ]
  br label %edge_8
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_8 ], [ %p_9_0, %edge_11 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_8 ], [ %p_9_1, %edge_11 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_8 ], [ %p_9_2, %edge_11 ]
  %p_8_3 = phi i64 [ 0, %edge_8 ], [ %t39, %edge_11 ]
  %p_8_4 = phi i64 [ %p_7_0, %edge_8 ], [ %p_9_4, %edge_11 ]
  %p_8_5 = phi i64 [ 0, %edge_8 ], [ %t44, %edge_11 ]
  %t30 = icmp ult i64 %p_8_5, %p_8_4
  br i1 %t30, label %edge_9, label %edge_10
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_9 ]
  %p_9_1 = phi i32 [ %p_8_1, %edge_9 ]
  %p_9_2 = phi %hia.buffer [ %p_8_2, %edge_9 ]
  %p_9_3 = phi i64 [ %p_8_3, %edge_9 ]
  %p_9_4 = phi i64 [ %p_8_4, %edge_9 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_9 ]
  %t31 = extractvalue %hia.buffer %p_9_2, 0
  %t32 = extractvalue %hia.buffer %p_9_2, 1
  %t33 = icmp ult i64 %p_9_5, %t32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = getelementptr i8, ptr %t31, i64 %p_9_5
  %t36 = load i8, ptr %t35, align 1
  %t37 = zext i8 %t36 to i64
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_9_3, i64 %t37)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_9_5, i64 1)
  %t44 = extractvalue { i64, i1 } %t43, 0
  %t45 = extractvalue { i64, i1 } %t43, 1
  %t46 = xor i1 %t45, true
  br i1 %t46, label %ok_47, label %trap_47
trap_47:
  call void @abort()
  unreachable
ok_47:
  br label %edge_11
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_10 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_10 ]
  %p_10_2 = phi %hia.buffer [ %p_8_2, %edge_10 ]
  %p_10_3 = phi i64 [ %p_8_3, %edge_10 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_10 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_10 ]
  %t48 = extractvalue %hia.buffer %p_10_2, 0
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %drop_nonnull_50, label %drop_after_50
drop_nonnull_50:
  call void @free(ptr %t48) nobuiltin
  br label %drop_after_50
drop_after_50:
  ret i64 %p_10_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b5
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b10
edge_11:
  br label %b8
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
