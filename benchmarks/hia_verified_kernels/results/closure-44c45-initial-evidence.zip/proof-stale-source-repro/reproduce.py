"""Replay the retained pre-fix attribution failure in this isolated package copy."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from hepta.hia_verified_simd import emit_verified_simd, simd_kernel_program
import hepta.hia_verified_simd_check as checker

core = simd_kernel_program('sum_u8')
image = emit_verified_simd(core, unroll=1)
obj, final = ROOT / 'probe.o', ROOT / 'probe.so'
obj.write_bytes(image.object_bytes)
command = ['ld', '-m', 'elf_x86_64', '-shared', '-z', 'defs', '-z', 'noexecstack',
           '-z', 'relro', '-z', 'now', '--hash-style=both', '--build-id=none',
           str(obj), '-lc', '-o', str(final)]
subprocess.run(command, check=True, capture_output=True)
original = checker.validate_verified_simd_artifact(core, image.object_bytes, final.read_bytes())
source = Path(checker.__file__)
raw = source.read_text()
marker = "    require(type(object_bytes) is bytes and type(final_bytes) is bytes,'immutable ELF bytes required')"
assert raw.count(marker) == 1
mutant = raw.replace(marker, '    raise RuntimeError("fresh checker must reject this audit probe")\n' + marker)
source.write_text(mutant)
try:
    after = checker.validate_verified_simd_artifact(core, image.object_bytes, final.read_bytes())
    (ROOT / 'proof-before-source-change.json').write_text(json.dumps(original, indent=2) + '\n')
    (ROOT / 'proof-after-source-change.json').write_text(json.dumps(after, indent=2) + '\n')
    summary = {
        'scope': 'Exact e9de97c checker plus retained local dependency projection; not a whole-tree qualification',
        'python': sys.version,
        'original_proof_ok': original['ok'],
        'original_checker_sha256': original['checker']['source_identity'][source.name],
        'changed_on_disk_checker_sha256': hashlib.sha256(mutant.encode()).hexdigest(),
        'after_proof_ok': after['ok'], 'after_proof_complete': after['complete'],
        'recorded_checker_sha256': after['checker']['source_identity'][source.name],
        'reports_new_source_that_unconditionally_raises':
            after['checker']['source_identity'][source.name] == hashlib.sha256(mutant.encode()).hexdigest(),
        'command': command,
        'artifacts': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (obj, final, ROOT / 'proof-before-source-change.json',
                                ROOT / 'proof-after-source-change.json')},
    }
    (ROOT / 'stale-source-repro.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
finally:
    source.write_text(raw)
