# Hepta NDU and Agent evidence at 14fe263

This directory preserves original receipts and adds a derived SUMMARY.json.
No frozen task, prompt, protocol, source file, original outcome, or usage event
was changed to create the summary.

## Agent outcome

All 12 registered cells were attempted once. Every request was refused by the
provider's usage limit. There were 12 turn.started events, zero assistant answer
events, zero completed usage receipts, zero candidate checks and zero hidden
evaluations. Task correctness is **not evaluated**. Provider refusal is not a
Rust, HIA, or model coding failure.

The original runner uses actual_generation_observed for a turn.started event.
That legacy field does not prove a completed generation or answer. Its zero
charged_tokens total is only the lower bound of reported usage; actual token
and billing costs are unknown. There is no cost or productivity comparison.
The observed complete study child process took 27.189146972 seconds.

Both sets of author controls and the independent review are preserved. They are
not model successes. The independent-review directory includes explicitly
labelled simulated transport fixtures for accounting and hidden-boundary tests;
none of their synthetic usage numbers is included in the actual study outcome.

## NDU outcome

The formal study uses the authentic c4a1b original Rust bridge. Thirteen actual
native requests agree with the independent exhaustive subset oracle and exact
resource DP. Complete uncompressed enumeration rejects the larger supplied
graph when the original 127-path bound is exceeded; the compact arm evaluates
all seven cases without claiming an unbounded global optimum.

The real translation validator structurally accepted u64 add.wrap and sub.wrap
programs, then Z3 and the canonical interpreter established a counterexample.
The measured proof-attempt loss is retained in the successor budget and sunk
ledger, and every controller and native arm receives the same successor.

Preparation, holding, latency and residency figures are declared model costs.
They are not measured successful native application timings. No incremental NDU
performance advantage, learned FBSDE result, unrestricted global optimum, or
execution-safety certificate is established.

Native build and complete process timings are separately retained, including
two early failures and the local-commit preflight. They are not a fully cold
machine or complete project/human cost estimate. Source acquisition and
unmeasured author/reviewer work are not silently treated as zero.

## Verification

MANIFEST.json records SHA-256 and byte size of every preceding evidence file,
including SUMMARY.json and SOURCE.json. MANIFEST.json excludes itself and its
detached checksum, avoiding a self-reference. The original absolute paths in
receipts remain unchanged; use the manifest's archived paths to find bytes here.
The authentic final NDU executable is retained. Its reproducible Cargo object
cache was removed after verifying the retained executable's hash.
