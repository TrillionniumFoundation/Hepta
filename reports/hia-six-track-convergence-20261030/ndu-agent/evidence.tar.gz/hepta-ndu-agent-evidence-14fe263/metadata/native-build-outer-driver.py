import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

base = Path('/tmp/hepta-ndu-build-stateful')
envelope = Path('/tmp/hepta-ndu-build-stateful-envelope.json')
if base.exists() or envelope.exists():
    raise SystemExit('preserve existing build evidence; use a new output directory')
command = [
    '/usr/bin/python3',
    '/workspace/scratch/8ca82272aad7/Hepta/tools/build_hia_recursive_ndu_bridge.py',
    '--ndu-source', '/tmp/hepta-ndu-upstream',
    '--output', str(base), '--target-dir', '/tmp/hepta-ndu-target-stateful',
    '--cargo', '/tmp/pq-r3-rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo',
    '--rustc', '/tmp/pq-r3-rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc',
    '--cargo-home', '/tmp/pq-r3-cargo',
    '--expected-source', 'c4a1bbed3a39beba43a6abf1a18b6f75c5725c21',
]
env = dict(os.environ)
env['CARGO_INCREMENTAL'] = '0'
env['CARGO_PROFILE_RELEASE_DEBUG'] = '0'
env['CARGO_BUILD_JOBS'] = '4'
started = time.monotonic_ns()
completed = subprocess.run(command, env=env, capture_output=True, check=False)
elapsed = time.monotonic_ns() - started
streams = {}
for name, data in [('stdout', completed.stdout), ('stderr', completed.stderr)]:
    path = Path('/tmp/hepta-ndu-build-stateful-' + name + '.txt')
    with path.open('xb') as stream:
        stream.write(data)
    streams[name] = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
manifest = json.loads((base / 'identity.json').read_text()) if (base / 'identity.json').is_file() else {}
result = {'schema': 'hepta.hia.ndu.stateful-native-build-cost.v1',
          'native_source_commit': 'c4a1bbed3a39beba43a6abf1a18b6f75c5725c21',
          'binary_sha256': manifest.get('binary_sha256'),
          'observed_outer_wall_ns': elapsed,
          'exit_code': completed.returncode, 'argv': command,
          'streams': streams, 'source_retrieval_included': False,
          'environment_changes': {key: env[key] for key in ('CARGO_INCREMENTAL', 'CARGO_PROFILE_RELEASE_DEBUG', 'CARGO_BUILD_JOBS')},
          'fully_cold_machine_claim': False, 'authority': 'DENY_ALL', 'safety_certificate': False}
with envelope.open('x') as stream:
    stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'exit_code': completed.returncode, 'wall_ns': elapsed, 'envelope': str(envelope)}))
raise SystemExit(completed.returncode)
