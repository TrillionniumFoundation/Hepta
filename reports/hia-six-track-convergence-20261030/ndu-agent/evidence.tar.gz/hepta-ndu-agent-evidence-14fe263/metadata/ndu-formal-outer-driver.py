from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import time

output = Path("/tmp/hepta-ndu-stateful-native-14fe263")
if output.exists():
    raise SystemExit("retain prior run; select a new output directory")
command = ["/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python",
           "tools/qualify_hia_ndu_stateful.py", "--mode", "native",
           "--output", str(output),
           "--expected-head", "14fe263fd8b65cb9bab019212e03a18550436cf0",
           "--bridge", "/tmp/hepta-ndu-build-stateful/native/hepta-hia-ndu-bridge",
           "--identity", "/tmp/hepta-ndu-build-stateful/identity.json",
           "--build-envelope", "/tmp/hepta-ndu-build-stateful-envelope.json"]
environment = dict(os.environ)
environment["PYTHONPATH"] = "/workspace/scratch/8ca82272aad7/python-deps"
started = time.monotonic_ns()
completed = subprocess.run(command, cwd="/tmp/hepta-ndu-frozen-worktree",
                           env=environment, capture_output=True, check=False)
elapsed = time.monotonic_ns() - started
output.mkdir(parents=True, exist_ok=True)
streams = {}
for name, value in (("stdout", completed.stdout), ("stderr", completed.stderr)):
    path = output / ("outer-" + name + ".raw")
    with path.open("xb") as stream:
        stream.write(value)
    streams[name] = {"path": path.name, "bytes": len(value), "sha256": sha256(value).hexdigest()}
report = output / "REPORT.json"
receipt = {"schema": "hepta.hia.ndu.stateful-study.outer-cost.v1",
           "argv": command, "exit_code": completed.returncode,
           "observed_outer_wall_ns": elapsed, "streams": streams,
           "report_sha256": sha256(report.read_bytes()).hexdigest() if report.is_file() else None,
           "scope": "complete qualification child process including Python startup, imports, source admissions, independent controls, real solver refusal, native requests, shutdown, report encoding and report write",
           "excludes": "this outer receipt encoding/storage, source retrieval, and separately recorded original native build",
           "fully_cold_machine_claim": False, "native_application_speedup_established": False,
           "incremental_ndu_value_established": False, "authority": "DENY_ALL", "safety_certificate": False}
with (output / "OUTER.json").open("x") as stream:
    stream.write(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
print(json.dumps({"exit_code": completed.returncode, "outer_wall_ns": elapsed,
                  "output": str(output), "stdout": completed.stdout.decode(errors="replace"),
                  "stderr": completed.stderr.decode(errors="replace")[:2500]}))
raise SystemExit(completed.returncode)
