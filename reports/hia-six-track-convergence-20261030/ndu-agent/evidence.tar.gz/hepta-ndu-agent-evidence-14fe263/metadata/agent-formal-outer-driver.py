from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import time

base = Path("/tmp/hepta-agent-maintenance-run-14fe263")
base.mkdir(parents=True, exist_ok=False)
output = base / "study"
command = ["/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python",
           "tools/qualify_hia_agent_maintenance.py", "run", "--output", str(output),
           "--review", "/tmp/hepta-agent-maintenance-final-review/REVIEW.json",
           "--registration-commit", "14fe263fd8b65cb9bab019212e03a18550436cf0"]
environment = dict(os.environ)
environment["PYTHONPATH"] = "/workspace/scratch/8ca82272aad7/python-deps"
started = time.monotonic_ns()
with (base / "stdout.raw").open("xb") as stdout, (base / "stderr.raw").open("xb") as stderr:
    process = subprocess.Popen(command, cwd="/tmp/hepta-agent-maintenance-frozen", env=environment,
                               stdout=subprocess.PIPE, stderr=stderr)
    for line in process.stdout:
        stdout.write(line)
        stdout.flush()
        print(line.decode(errors="replace").rstrip(), flush=True)
    code = process.wait()
elapsed = time.monotonic_ns() - started
result = output / "RESULT.json"
receipt = {"schema": "hepta.hia.agent-maintenance.outer-cost.v1",
           "argv": command, "registration_commit": "14fe263fd8b65cb9bab019212e03a18550436cf0",
           "exit_code": code, "observed_outer_wall_ns": elapsed,
           "result_sha256": sha256(result.read_bytes()).hexdigest() if result.is_file() else None,
           "streams": {name: {"path": name + ".raw", "bytes": (base / (name + ".raw")).stat().st_size,
                              "sha256": sha256((base / (name + ".raw")).read_bytes()).hexdigest()}
                       for name in ("stdout", "stderr")},
           "scope": "complete registered study child process, including Python startup, imports, all attempts, source/tool admissions, public check/native compile/execution, terminal hidden execution, cleanup, summary encoding and result writes",
           "excludes": "this outer receipt write; separately retained author controls, independent review, source/tool installation and unmeasured human work",
           "human_review_time_ns": None, "human_cost_advantage_proved": False,
           "full_cost_advantage_proved": False, "previous_results_replaced": False}
with (base / "OUTER.json").open("x") as stream:
    stream.write(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
print(json.dumps({"exit_code": code, "outer_wall_ns": elapsed, "output": str(base)}), flush=True)
raise SystemExit(code)
