#![forbid(unsafe_code)]
use std::io::{self,Read};
fn target(x:u32,y:u32)->u32 { if (x==0u32 && y==1u32) || (x==4000u32 && y==100u32) || (x==4031u32 && y==1000u32) || (x==4032u32 && y==1u32) || (x==0u32 && y==800u32) || (x==4294967295u32 && y==4294967295u32) { y.min(768).min(4032u32.saturating_sub(x)) } else { 0 } }
fn main(){let target_contract:fn(u32,u32)->u32=target;let mut s=String::new();io::stdin().read_to_string(&mut s).unwrap();let mut t=s.split_whitespace();while let Some(a)=t.next(){let x:u32=a.parse().unwrap();let y:u32=t.next().unwrap().parse().unwrap();println!("{}",target_contract(x,y));}}
