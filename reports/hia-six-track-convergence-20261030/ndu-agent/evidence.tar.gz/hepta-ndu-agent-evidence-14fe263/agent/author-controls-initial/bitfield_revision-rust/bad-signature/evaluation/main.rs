#![forbid(unsafe_code)]
use std::io::{self,Read};
fn target(x:u32,y:u32)->u64 { let value:u32={ let low=x&4095; let n=y%12; (((low<<n)|(low>>(12-n)))&4095)^((x>>12)&4095) };value as u64 }
fn main(){let target_contract:fn(u32,u32)->u32=target;let mut s=String::new();io::stdin().read_to_string(&mut s).unwrap();let mut t=s.split_whitespace();while let Some(a)=t.next(){let x:u32=a.parse().unwrap();let y:u32=t.next().unwrap().parse().unwrap();println!("{}",target_contract(x,y));}}
