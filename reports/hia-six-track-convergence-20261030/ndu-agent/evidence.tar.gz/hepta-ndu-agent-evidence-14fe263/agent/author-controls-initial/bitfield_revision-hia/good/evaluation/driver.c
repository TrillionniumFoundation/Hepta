#include <stdint.h>
#include <stdio.h>
extern uint32_t target(uint32_t,uint32_t);
int main(void){unsigned x,y;while(scanf("%u %u",&x,&y)==2)printf("%u\n",target(x,y));return 0;}
