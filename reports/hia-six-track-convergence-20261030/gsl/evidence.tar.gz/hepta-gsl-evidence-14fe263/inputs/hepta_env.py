import os,sys
root='/workspace/scratch/8ca82272aad7'
rust='/tmp/pq-r3-rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
clang=root+'/clang20/usr/lib/llvm-20/bin'
os.environ.update(PYTHONPATH=root+'/python-deps'+(':'+os.environ['PYTHONPATH'] if os.environ.get('PYTHONPATH') else ''),
    PYTHONDONTWRITEBYTECODE='1',CLANG=clang+'/clang',CLANGXX=clang+'/clang++',HEPTA_CLANG=clang+'/clang',
    RUSTC=rust+'/rustc',CARGO=rust+'/cargo',CARGO_HOME='/tmp/pq-r3-cargo',CARGO_TARGET_DIR=root+'/rust-target',
    CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',
    HEPTA_LLD=clang+'/ld.lld',PATH=clang+':'+rust+':'+os.environ['PATH'])
os.execvp(sys.argv[1],sys.argv[1:])
