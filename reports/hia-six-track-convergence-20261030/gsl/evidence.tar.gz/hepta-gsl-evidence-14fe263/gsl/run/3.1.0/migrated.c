/* Hepta independent C11/GCC backend. No Rust compiler involved. */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <inttypes.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
_Static_assert(CHAR_BIT == 8 && sizeof(size_t) == 8 && sizeof(intptr_t) == 8, "C backend requires the qualified 64-bit data model");
typedef struct { uint64_t h_trace; uint64_t h_calls; } __hepta_cb_aggregate_0;
typedef struct { uint8_t *data; size_t len; } __hepta_cb_buffer;
typedef struct { __hepta_cb_buffer h_token; uint64_t h_tag; bool h_active; } __hepta_cb_aggregate_1;
typedef struct { uint32_t tag; union { struct { __hepta_cb_buffer f_0; } v_Ok; struct { uint8_t f_0; } v_Err; } payload; } __hepta_cb_aggregate_3;
static inline uint64_t __hepta_cb_u64_bits(uint64_t x) { uint64_t bits = (uint64_t)x; uint64_t out; memcpy(&out, &bits, sizeof out); return out; }
static inline uint64_t __hepta_cb_u64_add(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_add_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_sub(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_sub_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_mul(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_mul_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_div(uint64_t a, uint64_t b) { if (b == 0) abort(); return a / b; }
static inline uint64_t __hepta_cb_u64_rem(uint64_t a, uint64_t b) { if (b == 0) abort(); return a % b; }
static inline uint64_t __hepta_cb_u64_wrapping_add(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a + (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_wrapping_sub(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a - (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_wrapping_mul(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a * (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_and(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a & (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_or(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a | (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_xor(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a ^ (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_min(uint64_t a, uint64_t b) { return a < b ? a : b; }
static inline uint64_t __hepta_cb_u64_max(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline uint64_t __hepta_cb_u64_shl(uint64_t a, uint64_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); return __hepta_cb_u64_bits((uint64_t)a << b); }
static inline uint64_t __hepta_cb_u64_shr(uint64_t a, uint64_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); uint64_t x = (uint64_t)(uint64_t)a >> b; return __hepta_cb_u64_bits(x); }

static bool __hepta_cb_allocate(size_t size, __hepta_cb_buffer *out) {
    if (size > PTRDIFF_MAX) return false;
    uint8_t *data = size ? calloc(size, sizeof(uint8_t)) : NULL;
    if (size && !data) return false;
    *out = (__hepta_cb_buffer){data, size};
    return true;
}
static __hepta_cb_buffer __hepta_cb_buffer_new(size_t size) {
    __hepta_cb_buffer out;
    if (!__hepta_cb_allocate(size, &out)) abort();
    return out;
}

static __hepta_cb_aggregate_3 __hepta_cb_try_buffer(size_t size) {
    __hepta_cb_buffer out;
    if (!__hepta_cb_allocate(size, &out))
        return (__hepta_cb_aggregate_3){.tag=1, .payload.v_Err={.f_0=1}};
    return (__hepta_cb_aggregate_3){.tag=0, .payload.v_Ok={.f_0=out}};
}

static void __hepta_cb_drop_0(__hepta_cb_aggregate_1 value);
static void __hepta_cb_drop_1(__hepta_cb_buffer value);
static void __hepta_cb_drop_0(__hepta_cb_aggregate_1 value) { __hepta_cb_drop_1(value.h_token); }
static void __hepta_cb_drop_1(__hepta_cb_buffer value) { free(value.data); }
__hepta_cb_aggregate_1 __hepta_cb_fn_GslConstruct(uint64_t h_tag);
__hepta_cb_aggregate_1 __hepta_cb_fn_GslMove(__hepta_cb_aggregate_1 h_owner);
void __hepta_cb_fn_GslDestroy(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state);
__hepta_cb_aggregate_1 __hepta_cb_fn_GslFinallyRvalue(uint64_t h_tag);
uint64_t __hepta_cb_fn_GslConsume(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state, uint32_t h_mode);
uint64_t migrated_case(uint64_t h_seed, uint64_t h_tag, uint32_t h_mode, uint32_t h_field);
#line 6 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslConstruct(uint64_t h_tag) {
#line 7 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
size_t __hepta_cb_v1 = (size_t)UINT64_C(0);
#line 7 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_buffer __hepta_cb_v2 = __hepta_cb_buffer_new(__hepta_cb_v1);
#line 7 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_buffer h_token = __hepta_cb_v2;
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_buffer __hepta_cb_v3 = h_token;
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_buffer __hepta_cb_v4 = __hepta_cb_v3;
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v5 = h_tag;
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v6 = true;
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v7 = (__hepta_cb_aggregate_1){ .h_token = __hepta_cb_v4, .h_tag = __hepta_cb_v5, .h_active = __hepta_cb_v6 };
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v7;
#line 8 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
}
#line 10 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslMove(__hepta_cb_aggregate_1 h_owner) {
#line 11 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v8 = h_owner;
#line 11 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v9 = __hepta_cb_v8;
#line 11 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v9;
#line 11 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
}
#line 13 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
void __hepta_cb_fn_GslDestroy(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state) {
#line 14 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v10 = (h_owner).h_active;
#line 14 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v10) { 
#line 15 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v11 = ((*h_state)).h_trace;
#line 15 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v12 = (uint64_t)UINT64_C(31);
#line 15 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v13 = __hepta_cb_u64_wrapping_mul(__hepta_cb_v11, __hepta_cb_v12);
#line 15 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v14 = (h_owner).h_tag;
#line 15 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v15 = __hepta_cb_u64_wrapping_add(__hepta_cb_v13, __hepta_cb_v14);
#line 15 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
((*h_state)).h_trace = __hepta_cb_v15;
#line 16 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v16 = ((*h_state)).h_calls;
#line 16 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v17 = (uint64_t)UINT64_C(1);
#line 16 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v18 = __hepta_cb_u64_wrapping_add(__hepta_cb_v16, __hepta_cb_v17);
#line 16 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
((*h_state)).h_calls = __hepta_cb_v18; } else {  }
#line 18 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v19 = h_owner;
#line 18 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v20 = __hepta_cb_v19;
#line 18 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_drop_0(__hepta_cb_v20);
#line 18 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
}
#line 20 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslFinallyRvalue(uint64_t h_tag) {
#line 21 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v21 = h_tag;
#line 21 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v22 = __hepta_cb_fn_GslConstruct(__hepta_cb_v21);
#line 21 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v22;
#line 21 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
}
#line 28 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_fn_GslConsume(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state, uint32_t h_mode) {
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v23 = h_mode;
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v24 = (uint32_t)UINT64_C(1);
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v25 = (__hepta_cb_v23 == __hepta_cb_v24);
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v25) { 
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v26 = h_owner;
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v27 = __hepta_cb_v26;
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg28 = &((*h_state));
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v27, __hepta_cb_arg28);
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v29 = (uint64_t)UINT64_C(2001);
#line 30 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v29; } else {  }
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v30 = h_mode;
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v31 = (uint32_t)UINT64_C(2);
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v32 = (__hepta_cb_v30 == __hepta_cb_v31);
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v32) { 
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v33 = h_owner;
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v34 = __hepta_cb_v33;
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg35 = &((*h_state));
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v34, __hepta_cb_arg35);
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v36 = (uint64_t)UINT64_C(2002);
#line 31 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v36; } else {  }
#line 32 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v37 = h_mode;
#line 32 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v38 = (uint32_t)UINT64_C(3);
#line 32 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v39 = (__hepta_cb_v37 == __hepta_cb_v38);
#line 32 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v39) { 
#line 33 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v40 = h_owner;
#line 33 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v41 = __hepta_cb_v40;
#line 33 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v42 = __hepta_cb_fn_GslMove(__hepta_cb_v41);
#line 33 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 h_moved = __hepta_cb_v42;
#line 34 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v43 = h_moved;
#line 34 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v44 = __hepta_cb_v43;
#line 34 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg45 = &((*h_state));
#line 34 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v44, __hepta_cb_arg45);
#line 35 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v46 = (uint64_t)UINT64_C(2003);
#line 35 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v46; } else {  }
#line 37 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v47 = h_mode;
#line 37 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v48 = (uint32_t)UINT64_C(5);
#line 37 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v49 = (__hepta_cb_v47 == __hepta_cb_v48);
#line 37 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v49) { 
#line 38 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v50 = (uint64_t)UINT64_C(9);
#line 38 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v51 = __hepta_cb_fn_GslFinallyRvalue(__hepta_cb_v50);
#line 38 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 h_nested = __hepta_cb_v51;
#line 39 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v52 = h_nested;
#line 39 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v53 = __hepta_cb_v52;
#line 39 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg54 = &((*h_state));
#line 39 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v53, __hepta_cb_arg54);
#line 40 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v55 = h_owner;
#line 40 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v56 = __hepta_cb_v55;
#line 40 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg57 = &((*h_state));
#line 40 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v56, __hepta_cb_arg57);
#line 41 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v58 = (uint64_t)UINT64_C(2005);
#line 41 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v58; } else {  }
#line 43 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v59 = h_owner;
#line 43 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v60 = __hepta_cb_v59;
#line 43 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg61 = &((*h_state));
#line 43 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v60, __hepta_cb_arg61);
#line 44 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v62 = (uint64_t)UINT64_C(0);
#line 44 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v62;
#line 44 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
}
#line 47 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t migrated_case(uint64_t h_seed, uint64_t h_tag, uint32_t h_mode, uint32_t h_field) {
#line 49 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v63 = h_seed;
#line 49 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v64 = (uint64_t)UINT64_C(0);
#line 49 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 __hepta_cb_v65 = (__hepta_cb_aggregate_0){ .h_trace = __hepta_cb_v63, .h_calls = __hepta_cb_v64 };
#line 49 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 h_state = __hepta_cb_v65;
#line 50 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v66 = (uint64_t)UINT64_C(0);
#line 50 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t h_status = __hepta_cb_v66;
#line 51 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v67 = h_mode;
#line 51 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v68 = (uint32_t)UINT64_C(7);
#line 51 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v69 = (__hepta_cb_v67 == __hepta_cb_v68);
#line 51 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v69) { 
#line 51 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v70 = (uint64_t)UINT64_C(1007);
#line 51 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
h_status = __hepta_cb_v70; } else { 
#line 53 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v71 = h_tag;
#line 53 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v72 = __hepta_cb_fn_GslFinallyRvalue(__hepta_cb_v71);
#line 53 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 h_owner = __hepta_cb_v72;
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v73 = h_mode;
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v74 = (uint32_t)UINT64_C(6);
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v75 = (__hepta_cb_v73 == __hepta_cb_v74);
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v75) { 
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v76 = h_owner;
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v77 = __hepta_cb_v76;
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg78 = &(h_state);
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v77, __hepta_cb_arg78);
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v79 = (uint64_t)UINT64_C(1006);
#line 54 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
h_status = __hepta_cb_v79; } else { 
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v80 = h_mode;
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v81 = (uint32_t)UINT64_C(4);
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v82 = (__hepta_cb_v80 == __hepta_cb_v81);
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v82) { 
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v83 = h_owner;
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v84 = __hepta_cb_v83;
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg85 = &(h_state);
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v84, __hepta_cb_arg85);
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v86 = (uint64_t)UINT64_C(1004);
#line 56 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
h_status = __hepta_cb_v86; } else { 
#line 58 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v87 = h_owner;
#line 58 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v88 = __hepta_cb_v87;
#line 58 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v89 = __hepta_cb_fn_GslMove(__hepta_cb_v88);
#line 58 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 h_transferred = __hepta_cb_v89;
#line 59 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v90 = h_transferred;
#line 59 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v91 = __hepta_cb_v90;
#line 59 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg92 = &(h_state);
#line 59 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v93 = h_mode;
#line 59 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v94 = __hepta_cb_fn_GslConsume(__hepta_cb_v91, __hepta_cb_arg92, __hepta_cb_v93);
#line 59 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
h_status = __hepta_cb_v94; } } }
#line 63 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v95 = h_field;
#line 63 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v96 = (uint32_t)UINT64_C(0);
#line 63 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v97 = (__hepta_cb_v95 == __hepta_cb_v96);
#line 63 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v97) { 
#line 63 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v98 = (h_state).h_trace;
#line 63 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v98; } else {  }
#line 64 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v99 = h_field;
#line 64 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint32_t __hepta_cb_v100 = (uint32_t)UINT64_C(1);
#line 64 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
bool __hepta_cb_v101 = (__hepta_cb_v99 == __hepta_cb_v100);
#line 64 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
if (__hepta_cb_v101) { 
#line 64 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v102 = (h_state).h_calls;
#line 64 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v102; } else {  }
#line 65 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
uint64_t __hepta_cb_v103 = h_status;
#line 65 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
return __hepta_cb_v103;
#line 65 "/tmp/hepta-gsl-14fe263/3.1.0/migrated.hepta"
}
