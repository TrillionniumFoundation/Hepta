capture: /tmp/hepta-gsl-14fe263/callback_37_source/callback.cpp \
  /tmp/hepta-gsl-14fe263/callback_37_source/callback.hpp
