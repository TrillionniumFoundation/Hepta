#include "callback.hpp"

void GslCallback::operator()() noexcept {
    state->trace = state->trace * 37ULL + tag;
    state->calls = state->calls + 1ULL;
}
