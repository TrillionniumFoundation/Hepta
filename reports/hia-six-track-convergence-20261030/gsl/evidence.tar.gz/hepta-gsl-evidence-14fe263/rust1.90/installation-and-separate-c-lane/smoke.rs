fn main() { assert_eq!(7u64.wrapping_mul(31).wrapping_add(3), 220); println!("rust190-native-ok"); }
