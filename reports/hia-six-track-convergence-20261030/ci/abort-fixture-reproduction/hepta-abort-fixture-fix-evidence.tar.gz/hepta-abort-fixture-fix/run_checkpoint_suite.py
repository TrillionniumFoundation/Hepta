import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path.cwd()
STAGE = Path('/tmp/hepta-abort-fixture-fix')
sys.path.insert(0, str(ROOT))


def source():
    names = ('tests/test_cpp_json_checkpoint.py', 'hepta/cpp_json_checkpoint.py',
             'hepta/clang_capture.py', 'tools/qualify_cpp_json_checkpoint.py')
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'git_status': subprocess.check_output(['git', 'status', '--porcelain'], text=True),
            'files': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}}


before = source()
suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_cpp_json_checkpoint')
planned = suite.countTestCases()
started = time.monotonic_ns()
captured = io.StringIO()
result = unittest.TextTestRunner(stream=captured, verbosity=2).run(suite)
wall = time.monotonic_ns() - started
after = source()
record = {'schema': 'hepta.checkpoint-abort-fixture-regression.v1',
          'module': 'tests.test_cpp_json_checkpoint', 'planned_tests': planned,
          'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
          'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
          'wall_ns': wall, 'source_before': before, 'source_after': after,
          'source_stable': before == after, 'source_committed': False,
          'native_evidence': os.environ['HEPTA_CPP_JSON_CHECKPOINT_EVIDENCE'],
          'environment': {key: os.environ.get(key) for key in ('PATH', 'RUSTC', 'CARGO', 'CLANG', 'CLANGXX', 'PYTHONPATH', 'TMPDIR')},
          'passed': result.wasSuccessful() and result.testsRun == planned and not result.skipped and before == after}
(STAGE / 'full-checkpoint.raw.log').write_text(captured.getvalue())
(STAGE / 'full-checkpoint.raw.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('planned_tests', 'tests_run', 'failures', 'errors', 'skips', 'wall_ns', 'source_stable', 'passed')}, indent=2), flush=True)
raise SystemExit(0 if record['passed'] else 1)
