capture: \
  /dev/shm/hepta-safety-frozen-sparse-bdd2425/examples/cpp/gsl_final_action/callback.cpp \
  /dev/shm/hepta-safety-frozen-sparse-bdd2425/examples/cpp/gsl_final_action/callback.hpp
