capture: /tmp/hepta-final-f6/gsl/callback_37_source/callback.cpp \
  /tmp/hepta-final-f6/gsl/callback_37_source/callback.hpp
