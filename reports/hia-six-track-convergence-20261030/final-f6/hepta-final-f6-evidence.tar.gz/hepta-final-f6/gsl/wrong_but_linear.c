/* Hepta independent C11/GCC backend. No Rust compiler involved. */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <inttypes.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
_Static_assert(CHAR_BIT == 8 && sizeof(size_t) == 8 && sizeof(intptr_t) == 8, "C backend requires the qualified 64-bit data model");
typedef struct { uint64_t h_trace; uint64_t h_calls; } __hepta_cb_aggregate_0;
typedef struct { uint8_t *data; size_t len; } __hepta_cb_buffer;
typedef struct { __hepta_cb_buffer h_token; uint64_t h_tag; bool h_active; } __hepta_cb_aggregate_1;
typedef struct { uint32_t tag; union { struct { __hepta_cb_buffer f_0; } v_Ok; struct { uint8_t f_0; } v_Err; } payload; } __hepta_cb_aggregate_3;
static inline uint64_t __hepta_cb_u64_bits(uint64_t x) { uint64_t bits = (uint64_t)x; uint64_t out; memcpy(&out, &bits, sizeof out); return out; }
static inline uint64_t __hepta_cb_u64_add(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_add_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_sub(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_sub_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_mul(uint64_t a, uint64_t b) { uint64_t r; if (__builtin_mul_overflow(a,b,&r)) abort(); return r; }
static inline uint64_t __hepta_cb_u64_div(uint64_t a, uint64_t b) { if (b == 0) abort(); return a / b; }
static inline uint64_t __hepta_cb_u64_rem(uint64_t a, uint64_t b) { if (b == 0) abort(); return a % b; }
static inline uint64_t __hepta_cb_u64_wrapping_add(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a + (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_wrapping_sub(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a - (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_wrapping_mul(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a * (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_and(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a & (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_or(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a | (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_xor(uint64_t a, uint64_t b) { return __hepta_cb_u64_bits((uint64_t)a ^ (uint64_t)b); }
static inline uint64_t __hepta_cb_u64_min(uint64_t a, uint64_t b) { return a < b ? a : b; }
static inline uint64_t __hepta_cb_u64_max(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline uint64_t __hepta_cb_u64_shl(uint64_t a, uint64_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); return __hepta_cb_u64_bits((uint64_t)a << b); }
static inline uint64_t __hepta_cb_u64_shr(uint64_t a, uint64_t b) { if ((uint64_t)b >= sizeof(a)*CHAR_BIT) abort(); uint64_t x = (uint64_t)(uint64_t)a >> b; return __hepta_cb_u64_bits(x); }

static bool __hepta_cb_allocate(size_t size, __hepta_cb_buffer *out) {
    if (size > PTRDIFF_MAX) return false;
    uint8_t *data = size ? calloc(size, sizeof(uint8_t)) : NULL;
    if (size && !data) return false;
    *out = (__hepta_cb_buffer){data, size};
    return true;
}
static __hepta_cb_buffer __hepta_cb_buffer_new(size_t size) {
    __hepta_cb_buffer out;
    if (!__hepta_cb_allocate(size, &out)) abort();
    return out;
}

static __hepta_cb_aggregate_3 __hepta_cb_try_buffer(size_t size) {
    __hepta_cb_buffer out;
    if (!__hepta_cb_allocate(size, &out))
        return (__hepta_cb_aggregate_3){.tag=1, .payload.v_Err={.f_0=1}};
    return (__hepta_cb_aggregate_3){.tag=0, .payload.v_Ok={.f_0=out}};
}

static void __hepta_cb_drop_0(__hepta_cb_aggregate_1 value);
static void __hepta_cb_drop_1(__hepta_cb_buffer value);
static void __hepta_cb_drop_0(__hepta_cb_aggregate_1 value) { __hepta_cb_drop_1(value.h_token); }
static void __hepta_cb_drop_1(__hepta_cb_buffer value) { free(value.data); }
__hepta_cb_aggregate_1 __hepta_cb_fn_GslConstruct(uint64_t h_tag);
__hepta_cb_aggregate_1 __hepta_cb_fn_GslMove(__hepta_cb_aggregate_1 h_owner);
void __hepta_cb_fn_GslDestroy(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state);
__hepta_cb_aggregate_1 __hepta_cb_fn_GslFinallyRvalue(uint64_t h_tag);
__hepta_cb_aggregate_1 __hepta_cb_fn_GslFinallyLvalue(uint64_t h_tag);
uint64_t __hepta_cb_fn_GslConsume(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state, uint32_t h_mode);
uint64_t migrated_case(uint64_t h_seed, uint64_t h_tag, uint32_t h_mode, uint32_t h_field);
#line 6 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslConstruct(uint64_t h_tag) {
#line 7 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
size_t __hepta_cb_v1 = (size_t)UINT64_C(0);
#line 7 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_buffer __hepta_cb_v2 = __hepta_cb_buffer_new(__hepta_cb_v1);
#line 7 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_buffer h_token = __hepta_cb_v2;
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_buffer __hepta_cb_v3 = h_token;
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_buffer __hepta_cb_v4 = __hepta_cb_v3;
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v5 = h_tag;
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v6 = true;
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v7 = (__hepta_cb_aggregate_1){ .h_token = __hepta_cb_v4, .h_tag = __hepta_cb_v5, .h_active = __hepta_cb_v6 };
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v7;
#line 8 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
#line 10 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslMove(__hepta_cb_aggregate_1 h_owner) {
#line 11 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v8 = h_owner;
#line 11 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v9 = __hepta_cb_v8;
#line 11 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v9;
#line 11 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
#line 13 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
void __hepta_cb_fn_GslDestroy(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state) {
#line 14 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v10 = (h_owner).h_active;
#line 14 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v10) { 
#line 15 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v11 = ((*h_state)).h_trace;
#line 15 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v12 = (uint64_t)UINT64_C(32);
#line 15 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v13 = __hepta_cb_u64_wrapping_mul(__hepta_cb_v11, __hepta_cb_v12);
#line 15 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v14 = (h_owner).h_tag;
#line 15 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v15 = __hepta_cb_u64_wrapping_add(__hepta_cb_v13, __hepta_cb_v14);
#line 15 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
((*h_state)).h_trace = __hepta_cb_v15;
#line 16 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v16 = ((*h_state)).h_calls;
#line 16 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v17 = (uint64_t)UINT64_C(1);
#line 16 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v18 = __hepta_cb_u64_wrapping_add(__hepta_cb_v16, __hepta_cb_v17);
#line 16 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
((*h_state)).h_calls = __hepta_cb_v18; } else {  }
#line 18 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v19 = h_owner;
#line 18 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v20 = __hepta_cb_v19;
#line 18 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_drop_0(__hepta_cb_v20);
#line 18 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
#line 20 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslFinallyRvalue(uint64_t h_tag) {
#line 21 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v21 = h_tag;
#line 21 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v22 = __hepta_cb_fn_GslConstruct(__hepta_cb_v21);
#line 21 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v22;
#line 21 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
#line 24 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_fn_GslFinallyLvalue(uint64_t h_tag) {
#line 25 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v23 = h_tag;
#line 25 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v24 = __hepta_cb_fn_GslConstruct(__hepta_cb_v23);
#line 25 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v24;
#line 25 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
#line 32 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_fn_GslConsume(__hepta_cb_aggregate_1 h_owner, __hepta_cb_aggregate_0 *h_state, uint32_t h_mode) {
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v25 = h_mode;
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v26 = (uint32_t)UINT64_C(1);
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v27 = (__hepta_cb_v25 == __hepta_cb_v26);
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v27) { 
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v28 = h_owner;
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v29 = __hepta_cb_v28;
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg30 = &((*h_state));
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v29, __hepta_cb_arg30);
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v31 = (uint64_t)UINT64_C(2001);
#line 34 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v31; } else {  }
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v32 = h_mode;
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v33 = (uint32_t)UINT64_C(2);
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v34 = (__hepta_cb_v32 == __hepta_cb_v33);
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v34) { 
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v35 = h_owner;
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v36 = __hepta_cb_v35;
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg37 = &((*h_state));
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v36, __hepta_cb_arg37);
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v38 = (uint64_t)UINT64_C(2002);
#line 35 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v38; } else {  }
#line 36 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v39 = h_mode;
#line 36 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v40 = (uint32_t)UINT64_C(3);
#line 36 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v41 = (__hepta_cb_v39 == __hepta_cb_v40);
#line 36 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v41) { 
#line 37 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v42 = h_owner;
#line 37 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v43 = __hepta_cb_v42;
#line 37 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v44 = __hepta_cb_fn_GslMove(__hepta_cb_v43);
#line 37 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 h_moved = __hepta_cb_v44;
#line 38 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v45 = h_moved;
#line 38 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v46 = __hepta_cb_v45;
#line 38 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg47 = &((*h_state));
#line 38 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v46, __hepta_cb_arg47);
#line 39 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v48 = (uint64_t)UINT64_C(2003);
#line 39 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v48; } else {  }
#line 41 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v49 = h_mode;
#line 41 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v50 = (uint32_t)UINT64_C(5);
#line 41 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v51 = (__hepta_cb_v49 == __hepta_cb_v50);
#line 41 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v51) { 
#line 42 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v52 = (uint64_t)UINT64_C(9);
#line 42 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v53 = __hepta_cb_fn_GslFinallyRvalue(__hepta_cb_v52);
#line 42 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 h_nested = __hepta_cb_v53;
#line 43 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v54 = h_nested;
#line 43 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v55 = __hepta_cb_v54;
#line 43 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg56 = &((*h_state));
#line 43 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v55, __hepta_cb_arg56);
#line 44 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v57 = h_owner;
#line 44 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v58 = __hepta_cb_v57;
#line 44 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg59 = &((*h_state));
#line 44 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v58, __hepta_cb_arg59);
#line 45 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v60 = (uint64_t)UINT64_C(2005);
#line 45 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v60; } else {  }
#line 47 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v61 = h_owner;
#line 47 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v62 = __hepta_cb_v61;
#line 47 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg63 = &((*h_state));
#line 47 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v62, __hepta_cb_arg63);
#line 48 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v64 = (uint64_t)UINT64_C(0);
#line 48 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v64;
#line 48 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
#line 51 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t migrated_case(uint64_t h_seed, uint64_t h_tag, uint32_t h_mode, uint32_t h_field) {
#line 53 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v65 = h_seed;
#line 53 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v66 = (uint64_t)UINT64_C(0);
#line 53 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 __hepta_cb_v67 = (__hepta_cb_aggregate_0){ .h_trace = __hepta_cb_v65, .h_calls = __hepta_cb_v66 };
#line 53 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 h_state = __hepta_cb_v67;
#line 54 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v68 = (uint64_t)UINT64_C(0);
#line 54 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t h_status = __hepta_cb_v68;
#line 55 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v69 = h_mode;
#line 55 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v70 = (uint32_t)UINT64_C(7);
#line 55 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v71 = (__hepta_cb_v69 == __hepta_cb_v70);
#line 55 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v71) { 
#line 55 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v72 = (uint64_t)UINT64_C(1007);
#line 55 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
h_status = __hepta_cb_v72; } else { 
#line 57 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v73 = h_tag;
#line 57 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v74 = __hepta_cb_fn_GslFinallyRvalue(__hepta_cb_v73);
#line 57 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 h_owner = __hepta_cb_v74;
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v75 = h_mode;
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v76 = (uint32_t)UINT64_C(6);
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v77 = (__hepta_cb_v75 == __hepta_cb_v76);
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v77) { 
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v78 = h_owner;
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v79 = __hepta_cb_v78;
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg80 = &(h_state);
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v79, __hepta_cb_arg80);
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v81 = (uint64_t)UINT64_C(1006);
#line 58 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
h_status = __hepta_cb_v81; } else { 
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v82 = h_mode;
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v83 = (uint32_t)UINT64_C(4);
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v84 = (__hepta_cb_v82 == __hepta_cb_v83);
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v84) { 
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v85 = h_owner;
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v86 = __hepta_cb_v85;
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg87 = &(h_state);
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_fn_GslDestroy(__hepta_cb_v86, __hepta_cb_arg87);
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v88 = (uint64_t)UINT64_C(1004);
#line 60 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
h_status = __hepta_cb_v88; } else { 
#line 62 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v89 = h_owner;
#line 62 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v90 = __hepta_cb_v89;
#line 62 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v91 = __hepta_cb_fn_GslMove(__hepta_cb_v90);
#line 62 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 h_transferred = __hepta_cb_v91;
#line 63 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v92 = h_transferred;
#line 63 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_1 __hepta_cb_v93 = __hepta_cb_v92;
#line 63 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
__hepta_cb_aggregate_0 * __hepta_cb_arg94 = &(h_state);
#line 63 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v95 = h_mode;
#line 63 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v96 = __hepta_cb_fn_GslConsume(__hepta_cb_v93, __hepta_cb_arg94, __hepta_cb_v95);
#line 63 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
h_status = __hepta_cb_v96; } } }
#line 67 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v97 = h_field;
#line 67 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v98 = (uint32_t)UINT64_C(0);
#line 67 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v99 = (__hepta_cb_v97 == __hepta_cb_v98);
#line 67 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v99) { 
#line 67 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v100 = (h_state).h_trace;
#line 67 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v100; } else {  }
#line 68 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v101 = h_field;
#line 68 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint32_t __hepta_cb_v102 = (uint32_t)UINT64_C(1);
#line 68 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
bool __hepta_cb_v103 = (__hepta_cb_v101 == __hepta_cb_v102);
#line 68 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
if (__hepta_cb_v103) { 
#line 68 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v104 = (h_state).h_calls;
#line 68 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v104; } else {  }
#line 69 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
uint64_t __hepta_cb_v105 = h_status;
#line 69 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
return __hepta_cb_v105;
#line 69 "/tmp/hepta-final-f6/gsl/wrong_but_linear.hepta"
}
