"""Archive complete original f6 gate outputs and verify every stored byte."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/dev/shm/hepta-safety-frozen-sparse-bdd2425')
OUT = Path('/tmp/hepta-final-f6')
HEAD = 'f6c241112cd17498004e5b0ee614719b24719327'
DEST = Path('/workspace/scratch/8ca82272aad7/Hepta/reports/hia-six-track-convergence-20261030/final-f6')
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_safety_contract import source_inventory


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


summary = json.loads((OUT / 'SUMMARY.json').read_text())
assert summary['head'] == HEAD and summary['status'] == 'passed'
head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain', '--untracked-files=all'], text=True)
inventory = source_inventory()
assert head == HEAD and status == ''
assert inventory == summary['source_initial']['inventory'] == summary['source_final']['inventory']
initial = json.loads((OUT / 'initial-source-envelope.json').read_text())
for row in initial['historical_provenance']:
    assert sha(ROOT / row['path']) == row['sha256']
final = {'head': head, 'git_status': status, 'source_inputs': len(inventory),
         'source_sha256': inventory, 'source_matches_every_gate': all(
             json.loads(path.read_text())['source_before']['inventory'] == inventory
             == json.loads(path.read_text())['source_after']['inventory']
             for path in OUT.glob('*.envelope.json')),
         'historical_provenance_count': len(initial['historical_provenance']),
         'historical_provenance_unchanged': True,
         'source_revision_or_inputs_modified_for_gate': False}
assert final['source_matches_every_gate']
(OUT / 'final-source-envelope.json').write_text(json.dumps(final, indent=2) + '\n')
manifest = {}
for path in sorted(OUT.rglob('*')):
    if path.is_symlink():
        raise RuntimeError('unexpected evidence symlink: ' + str(path))
    if path.is_file() and path.name not in {'EVIDENCE_MANIFEST.json', 'ARCHIVE_VALIDATION.json'}:
        manifest[str(path.relative_to(OUT))] = {'sha256': sha(path), 'bytes': path.stat().st_size}
(OUT / 'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = Path('/tmp/hepta-final-f6-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(OUT, arcname='hepta-final-f6')
expected = {**manifest, 'EVIDENCE_MANIFEST.json': {'sha256': sha(OUT / 'EVIDENCE_MANIFEST.json'),
                                                 'bytes': (OUT / 'EVIDENCE_MANIFEST.json').stat().st_size}}
seen = set()
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        if member.isdir():
            continue
        assert member.isfile() and member.name.startswith('hepta-final-f6/')
        name = member.name[len('hepta-final-f6/'):]
        assert name in expected and name not in seen and '..' not in Path(name).parts
        seen.add(name)
        data = tar.extractfile(member).read()
        assert len(data) == expected[name]['bytes']
        assert hashlib.sha256(data).hexdigest() == expected[name]['sha256']
assert seen == set(expected)
validation = {'schema': 'hepta.final-source-evidence-archive-validation.v1',
              'source_head': HEAD, 'source_clean_after_all_gates': status == '',
              'qualified_source_inputs': len(inventory), 'historical_provenance_inputs': 19,
              'archive': archive.name, 'archive_bytes': archive.stat().st_size,
              'archive_sha256': sha(archive), 'original_files_in_manifest': len(manifest),
              'verified_regular_members_including_manifest': len(seen),
              'every_original_file_byte_preserved': True, 'duplicate_or_unexpected_members': 0,
              'symlinks_or_special_members': 0,
              'raw_summary_sha256': sha(OUT / 'SUMMARY.json'),
              'raw_canonical_report_sha256': sha(OUT / 'safety-contract.raw.json'),
              'all_six_gates_passed': len(summary['gates']) == 6 and all(row['passed'] for row in summary['gates']),
              'prior_reports_or_freezes_relabelled': False, 'model_calls': 0}
assert validation['all_six_gates_passed']
(OUT / 'ARCHIVE_VALIDATION.json').write_text(json.dumps(validation, indent=2) + '\n')
DEST.mkdir(parents=True, exist_ok=True)
for source in (archive, OUT / 'SUMMARY.json', OUT / 'ARCHIVE_VALIDATION.json', OUT / 'EVIDENCE_MANIFEST.json'):
    target = DEST / source.name
    if target.exists():
        assert sha(target) == sha(source), 'existing evidence differs: ' + str(target)
    else:
        shutil.copy2(source, target)
    assert sha(target) == sha(source)
print(json.dumps({'destination': str(DEST), **validation}, indent=2))
