"""Run the authorized same-commit gates; preserve every raw command outcome."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path.cwd()
OUT = Path('/tmp/hepta-final-f6')
HEAD = 'f6c241112cd17498004e5b0ee614719b24719327'
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_safety_contract import source_inventory, environment_identity


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source():
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'status': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], text=True),
            'inventory': source_inventory()}


initial = source()
assert initial['head'] == HEAD and initial['status'] == ''
(OUT / 'environment.raw.json').write_text(json.dumps(environment_identity(), indent=2) + '\n')
selected_env = ('PATH', 'RUSTC', 'RUSTDOC', 'CARGO', 'CARGO_HOME', 'CARGO_TARGET_DIR',
                'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'CARGO_INCREMENTAL',
                'CARGO_BUILD_JOBS', 'CARGO_NET_OFFLINE', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
                'CLANG', 'CLANGXX', 'HEPTA_CLANG', 'HEPTA_PROFDATA', 'HEPTA_RUN_ARTIFACT_SESSION',
                'HEPTA_QEMU_X86_64', 'HEPTA_QEMU_AARCH64', 'HEPTA_QEMU_RISCV64',
                'HEPTA_RECURSIVE_NDU_BRIDGE', 'HEPTA_RECURSIVE_NDU_IDENTITY',
                'HEPTA_FINITE_NDU_BRIDGE', 'HEPTA_FINITE_NDU_IDENTITY',
                'HEPTA_NDU_STREAM_BRIDGE', 'HEPTA_NDU_STREAM_IDENTITY', 'TMPDIR')
records = []


def run(label, argv, *, env=None, kind=None, expected=None):
    before = source()
    assert before == initial, 'source drift before ' + label
    env = dict(os.environ if env is None else env)
    stdout = OUT / (label + '.stdout.raw.log')
    stderr = OUT / (label + '.stderr.raw.log')
    assert not stdout.exists() and not stderr.exists()
    started = time.monotonic_ns()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        child = subprocess.run(argv, cwd=ROOT, env=env, stdout=out, stderr=err)
    wall = time.monotonic_ns() - started
    after = source()
    checks = {}
    passed = child.returncode == 0 and before == after
    text = stderr.read_text(errors='replace')
    if kind == 'unittest':
        found = re.search(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.MULTILINE)
        count = int(found.group(1)) if found else None
        bare_ok = re.search(r'^OK$', text, re.MULTILINE) is not None
        checks = {'expected_tests': expected, 'tests_run': count, 'bare_ok_without_skips': bare_ok}
        passed = passed and count == expected and bare_ok
    elif kind == 'cargo':
        combined = stdout.read_text(errors='replace') + text
        matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', combined)
        rows = [tuple(map(int, values)) for values in matches]
        checks = {'suites': len(rows), 'passed': sum(row[0] for row in rows),
                  'failed': sum(row[1] for row in rows), 'ignored': sum(row[2] for row in rows),
                  'measured': sum(row[3] for row in rows), 'filtered_out': sum(row[4] for row in rows)}
        passed = passed and checks == {'suites': 21, 'passed': 121, 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}
    elif kind == 'gsl':
        report = json.loads((OUT / 'gsl/report.json').read_text())
        checks = {'ok': report['ok'], 'case_count_per_version': report['case_count_per_version'],
                  'report_sha256': sha(OUT / 'gsl/report.json')}
        passed = passed and checks['ok'] is True and checks['case_count_per_version'] == 416
    elif kind == 'canonical':
        report = json.loads((OUT / 'safety-contract.raw.json').read_text())
        statuses = {}
        for row in report['tests'].values():
            statuses[row['status']] = statuses.get(row['status'], 0) + 1
        checks = {'status': report['status'], 'tests_run': report['tests_run'],
                  'expected_tests': report['expected_tests'], 'status_counts': statuses,
                  'source_stable': report['source_stable'], 'wall_ns': report['wall_ns'],
                  'raw_report_sha256': sha(OUT / 'safety-contract.raw.json')}
        passed = passed and checks['status'] == 'passed' and checks['tests_run'] == 552 and statuses == {'passed': 552} and checks['source_stable']
    record = {'label': label, 'argv': argv, 'cwd': str(ROOT), 'exit_code': child.returncode,
              'wall_ns': wall, 'passed': passed, 'checks': checks,
              'source_before': before, 'source_after': after, 'source_stable': before == after,
              'environment': {key: env.get(key) for key in selected_env},
              'stdout': {'file': stdout.name, 'sha256': sha(stdout), 'bytes': stdout.stat().st_size},
              'stderr': {'file': stderr.name, 'sha256': sha(stderr), 'bytes': stderr.stat().st_size}}
    (OUT / (label + '.envelope.json')).write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(json.dumps({'label': label, 'exit_code': child.returncode, 'wall_ns': wall, 'passed': passed, 'checks': checks}), flush=True)
    assert before == after, 'source drift after ' + label
    return record


rust95 = Path('/tmp/pq-r3-rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
rust_env = {**os.environ, 'RUSTC': str(rust95 / 'rustc'), 'RUSTDOC': str(rust95 / 'rustdoc'),
            'CARGO': str(rust95 / 'cargo'), 'CARGO_TARGET_DIR': '/workspace/scratch/8ca82272aad7/rust-target'}
rust_tools = {}
for name in ('rustc', 'rustdoc', 'cargo'):
    path = rust95 / name
    child = subprocess.run([str(path), '-vV' if name == 'rustc' else '--version'], capture_output=True, text=True)
    rust_tools[name] = {'path': str(path), 'sha256': sha(path), 'exit_code': child.returncode,
                        'stdout': child.stdout, 'stderr': child.stderr}
(OUT / 'rust195-tools.raw.json').write_text(json.dumps(rust_tools, indent=2) + '\n')

run('rust-exact-lock', [str(rust95 / 'cargo'), 'test', '--locked', '--offline', '--manifest-path',
                       'rust/hia-core-shadow/Cargo.toml'], env=rust_env, kind='cargo')
run('catalog', [sys.executable, 'tools/generate_hia_catalog.py', '--check'])
run('catalog-routes', [sys.executable, '-m', 'unittest', '-v', 'tests.test_hia_opcode_catalog',
                      'tests.test_hia_schema_unification', 'tests.test_hia_routes'], kind='unittest', expected=33)
run('new-regressions', [sys.executable, '-m', 'unittest', '-v', 'tests.test_cpp_gsl_final_action',
                       'tests.test_hia_ndu_stateful', 'tests.test_hia_agent_maintenance'], kind='unittest', expected=31)
run('gsl-native', [sys.executable, 'tools/qualify_cpp_gsl_final_action.py', '--clang', os.environ['CLANG'],
                   '--cxx', 'g++', '--cc', 'gcc', '--output', str(OUT / 'gsl')], kind='gsl')
run('canonical-safety', [sys.executable, 'tools/qualify_hia_safety_contract.py', '--output',
                       str(OUT / 'safety-contract.raw.json')], kind='canonical')
final = source()
summary = {'head': HEAD, 'status': 'passed' if all(row['passed'] for row in records) and final == initial else 'failed',
           'source_initial': initial, 'source_final': final, 'source_stable': final == initial,
           'gates': [{key: row[key] for key in ('label', 'exit_code', 'wall_ns', 'passed', 'checks')} for row in records],
           'raw_logs_preserved_separately': True, 'model_calls': 0,
           'prior_freeze_and_model_results_relabelled': False,
           'gate_counts_are_disjoint_coverage': False,
           'whole_language_soundness_or_resource_or_performance_superiority_proved': False}
(OUT / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'status': summary['status'], 'source_stable': summary['source_stable']}), flush=True)
raise SystemExit(0 if summary['status'] == 'passed' else 1)
