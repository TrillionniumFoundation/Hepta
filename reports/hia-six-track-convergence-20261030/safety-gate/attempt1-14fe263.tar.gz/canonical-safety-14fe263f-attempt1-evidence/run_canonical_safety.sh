#!/usr/bin/env bash
set -euo pipefail
export HEPTA_RUN_ARTIFACT_SESSION=1
export HEPTA_RECURSIVE_NDU_BRIDGE=/dev/shm/hepta-safety-recursive-build/native/hepta-hia-ndu-bridge
export HEPTA_RECURSIVE_NDU_IDENTITY=/dev/shm/hepta-safety-recursive-build/identity.json
export HEPTA_FINITE_NDU_BRIDGE=/dev/shm/hepta-safety-finite-build/native/hepta-hia-ndu-bridge
export HEPTA_FINITE_NDU_IDENTITY=/dev/shm/hepta-safety-finite-build/identity.json
export HEPTA_NDU_STREAM_BRIDGE=/tmp/hepta-ndu-build-stateful/native/hepta-hia-ndu-bridge
export HEPTA_NDU_STREAM_IDENTITY=/tmp/hepta-ndu-build-stateful/identity.json
export RUSTC=/dev/shm/hepta-rust190/bin/rustc
export CARGO=/dev/shm/hepta-rust190/bin/cargo
export PATH=/dev/shm/hepta-rust190/bin:/workspace/scratch/8ca82272aad7/clang20/usr/lib/llvm-20/bin:/dev/shm/hepta-safety-tools/bin:$PATH
export CARGO_HOME=/tmp/pq-r3-cargo
export CARGO_TARGET_DIR=/dev/shm/hepta-safety-shadow-target
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_INCREMENTAL=0
export CARGO_BUILD_JOBS=2
export CARGO_NET_OFFLINE=true
export PYTHONPATH=/workspace/scratch/8ca82272aad7/python-deps
export PYTHONDONTWRITEBYTECODE=1
export CLANG=/workspace/scratch/8ca82272aad7/clang20/usr/bin/clang-20
export CLANGXX=/workspace/scratch/8ca82272aad7/clang20/usr/bin/clang++-20
export HEPTA_CLANG=$CLANG
export HEPTA_QEMU_X86_64=/dev/shm/hepta-safety-tools/bin/qemu-x86_64
export HEPTA_QEMU_AARCH64=/dev/shm/hepta-safety-tools/bin/qemu-aarch64
export HEPTA_QEMU_RISCV64=/dev/shm/hepta-safety-tools/bin/qemu-riscv64
export HEPTA_PROFDATA=/dev/shm/hepta-safety-tools/bin/llvm-profdata
export TMPDIR=/dev/shm/hepta-safety-temp
mkdir -p "$TMPDIR"
cd /dev/shm/hepta-safety-frozen-sparse-bdd2425
python3 tools/qualify_hia_safety_contract.py --output "$1"
