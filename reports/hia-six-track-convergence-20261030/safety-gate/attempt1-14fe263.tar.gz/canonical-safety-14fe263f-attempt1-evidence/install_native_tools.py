"""Restore authentic QEMU/LLVM tools for the frozen safety qualification."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import urllib.request

ROOT = Path('/workspace/scratch/8ca82272aad7/Hepta')
DEST = Path('/dev/shm/hepta-safety-tools')
DEST.mkdir(exist_ok=True)
BIN = DEST / 'bin'
BIN.mkdir(exist_ok=True)
receipts = []


def fetch_extract(label, url, digest, members):
    archive = DEST / (label + '.deb')
    urllib.request.urlretrieve(url, archive)
    actual = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
    if actual != digest:
        raise RuntimeError(label + ' package hash mismatch')
    child = subprocess.Popen(['dpkg-deb', '--fsys-tarfile', str(archive)], stdout=subprocess.PIPE)
    found = {}
    with tarfile.open(fileobj=child.stdout, mode='r|') as tar:
        for member in tar:
            name = member.name.lstrip('./')
            if name not in members:
                continue
            if not member.isfile():
                raise RuntimeError(name + ' is not a regular binary')
            target = BIN / members[name]
            with tar.extractfile(member) as stream, target.open('wb') as output:
                shutil.copyfileobj(stream, output)
            target.chmod(0o755)
            found[name] = {'path': str(target), 'sha256': hashlib.file_digest(target.open('rb'), 'sha256').hexdigest()}
    if child.wait() != 0 or set(found) != set(members):
        raise RuntimeError(label + ' incomplete binary extraction')
    archive.unlink()
    receipts.append({'package': label, 'url': url, 'package_sha256': actual, 'binaries': found})
    print(label, 'extracted', len(found), flush=True)


lock = json.loads((ROOT / 'formal/qemu-toolchain-lock.json').read_text())
fetch_extract('qemu-user-static', lock['source'], lock['package_sha256'], {
    'usr/bin/qemu-x86_64-static': 'qemu-x86_64',
    'usr/bin/qemu-aarch64-static': 'qemu-aarch64',
    'usr/bin/qemu-riscv64-static': 'qemu-riscv64',
})
qemu_aarch64 = hashlib.file_digest((BIN / 'qemu-aarch64').open('rb'), 'sha256').hexdigest()
if qemu_aarch64 != lock['binary_sha256']:
    raise RuntimeError('locked qemu aarch64 binary hash mismatch')

url = 'https://apt.llvm.org/noble/dists/llvm-toolchain-noble-20/main/binary-amd64/Packages.gz'
raw = gzip.decompress(urllib.request.urlopen(url).read()).decode()
rows = []
for block in raw.split('\n\n'):
    row = {}
    for line in block.splitlines():
        if ': ' in line and not line.startswith(' '):
            key, value = line.split(': ', 1)
            row[key] = value
    if row.get('Package') == 'llvm-20':
        rows.append(row)
if len(rows) != 1:
    raise RuntimeError('exact LLVM package required')
row = rows[0]
fetch_extract('llvm-20', 'https://apt.llvm.org/noble/' + row['Filename'], row['SHA256'], {
    'usr/lib/llvm-20/bin/llvm-profdata': 'llvm-profdata',
})
receipts.append({'llvm_metadata_url': url, 'llvm_package_metadata': row})
for path in sorted(BIN.iterdir()):
    result = subprocess.run([str(path), '--version'], text=True, capture_output=True)
    receipts.append({'binary': str(path), 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    print(path.name, 'returncode', result.returncode, result.stdout.splitlines()[:2], flush=True)
    if result.returncode:
        raise RuntimeError(path.name + ' did not run')
(DEST / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
