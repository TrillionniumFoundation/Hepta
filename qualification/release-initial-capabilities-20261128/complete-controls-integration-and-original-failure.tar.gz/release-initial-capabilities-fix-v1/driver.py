from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,os,time
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'release-initial-capabilities-fix-v1';out.mkdir(mode=0o700,exist_ok=False)
payload=json.loads(sys.argv[1])
def git(*args):return subprocess.run(['git',*args],cwd=root,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='463508c9aae091c52423bbe27e9dd0260c9087a6'
assert not git('status','--porcelain=v1').strip()
(out/'driver.py').write_text(sys.argv[2])
failure=out/'original-linux-author-failure';failure.mkdir()
for row in payload['failure_files']:
 data=row['text'].encode();assert len(data)==row['size']and sha256(data).hexdigest()==row['sha256']
 (failure/Path(row['path']).name).write_bytes(data)
(failure/'driver.py').write_text(payload['original_driver'])
(out/'cloud243.json').write_text(json.dumps(payload['cloud243'],sort_keys=True,indent=2)+'\n')
(out/'cloud463.json').write_text(json.dumps(payload['cloud463'],sort_keys=True,indent=2)+'\n')
path=root/'tools/generate_hia_release_extension_catalog.py';old=path.read_bytes()
assert sha256(old).hexdigest()=='bfda914cc2cac51f22f29380185cafbe6eb86cb6e14d944ab80e101bb6b6de03'
(out/'catalog.before.py').write_bytes(old)
needle=b"INITIAL_PRODUCTS = frozenset(('hia-source-build', 'hia-elf-link', 'selfhost.image.bin'))"
replacement=b"""# These exact capabilities are supplied by the cold release request before any
# registered DAG executes. release_owner.dag_import binds runner and capture
# through their existing request fields; they are not prior-stage publications.
INITIAL_PRODUCTS = frozenset(('hia-source-build', 'hia-elf-link', 'selfhost.image.bin',
                              'hia-subprocess', 'hia-source-capture'))"""
assert old.count(needle)==1;path.write_bytes(old.replace(needle,replacement,1))
path=root/'tests/test_hia_release_extension_catalog.py';oldtests=path.read_bytes()
(out/'catalog-tests.before.py').write_bytes(oldtests)
needle=b"\nif __name__ == '__main__':"
assert oldtests.count(needle)==1;path.write_bytes(oldtests.replace(needle,payload['new_tests'].encode()+needle,1))
def methods(raw):
 return {n.name+'.'+f.name:ast.dump(f,include_attributes=False)
 for n in ast.parse(raw).body if isinstance(n,ast.ClassDef)
 for f in n.body if isinstance(f,ast.FunctionDef)}
before=methods(oldtests);after=methods(path.read_bytes())
assert all(after[k]==v for k,v in before.items())
argv=[sys.executable,'-B','-m','unittest','-v','tests.test_hia_release_extension_catalog','tests.test_hia_controller_catalog_preservation']
started=time.monotonic()
with(out/'controls.stdout').open('xb')as so,(out/'controls.stderr').open('xb')as se:
 p=subprocess.run(argv,cwd=root,stdout=so,stderr=se,timeout=120,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
result={'status':'PASS'if p.returncode==0 else'FAIL','returncode':p.returncode,'elapsed_seconds':time.monotonic()-started,'argv':argv,'old_test_methods_unchanged':len(before),'new_controls':len(after)-len(before),'physical_initial_head':'463508c9aae091c52423bbe27e9dd0260c9087a6','source_files_changed':git('diff','--name-only').decode().splitlines(),'real_linux_authors_pending':True}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True));print((out/'controls.stderr').read_text())
raise SystemExit(p.returncode)
