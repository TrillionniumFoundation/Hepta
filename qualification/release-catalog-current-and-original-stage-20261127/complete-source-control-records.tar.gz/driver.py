import sys,json,unittest
from pathlib import Path
from tools.hia_release_stage_source_history import original_stage_inputs,PRIOR_TAKE
import tests.test_hia_release_stage_plan as original
root=Path.cwd()
modules=['tests.test_hia_release_extension_catalog','tests.test_hia_helper_catalog_extensions','tests.test_hia_release_stage_recipes.ReleaseStageRecipeSourceTests','tests.test_hia_release_stage_plan.ReleaseStageSourceTests']
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
# Catalog controls exercise their own explicit take, so run them separately.
catalog=unittest.defaultTestLoader.loadTestsFromName(modules[0])
rest=unittest.defaultTestLoader.loadTestsFromNames(modules[1:])
a=unittest.TextTestRunner(verbosity=2).run(catalog)
with original_stage_inputs(root,original,prior_take=PRIOR_TAKE) as take:
 b=unittest.TextTestRunner(verbosity=2).run(rest)
Path(sys.argv[1]).write_text(json.dumps(take,indent=2)+'\n')
assert a.wasSuccessful() and b.wasSuccessful() and not a.skipped and not b.skipped
print(json.dumps({'source_tests':a.testsRun+b.testsRun,'skips':0,'native_execution':False}))
