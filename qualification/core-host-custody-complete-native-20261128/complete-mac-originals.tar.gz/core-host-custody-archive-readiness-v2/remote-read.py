from pathlib import Path
import json,hashlib
out=Path('/home/qian-qi/hia-core-host-custody-complete-development-evidence-20261128-2ac5')
roots=[Path('/home/qian-qi/hia-core-host-custody-native-v1-20261128-2ac5'),Path('/home/qian-qi/hia-core-host-custody-native-v2-20261128-2ac5')]
reports=[]
for root in roots:
 journal=json.loads((root/'native-execution-v1/journal.json').read_bytes())
 report=json.loads((root/'native-development-v1/work/report.json').read_bytes())
 reports.append({'root':str(root),'journal':journal,'status':report['status'],'source_head':report['source_head'],'tests_run':report['tests_run'],'actual_native_invocations':report.get('actual_native_invocations')})
print(json.dumps({'archive_directory_exists':out.exists(),'archive_directory_children':[p.name for p in out.iterdir()] if out.exists() else [],'reports':reports},sort_keys=True),flush=True)
