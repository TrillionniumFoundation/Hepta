from pathlib import Path
import os,stat,hashlib,json,tarfile,time
roots=[Path('/home/qian-qi/hia-core-host-custody-native-v1-20261128-2ac5'), Path('/home/qian-qi/hia-core-host-custody-native-v2-20261128-2ac5')]
out=Path('/home/qian-qi/hia-core-host-custody-complete-development-evidence-20261128-2ac5');out.mkdir(mode=0o700)
native_root=roots[-1]
report=json.loads((native_root/'native-development-v1/work/report.json').read_bytes())
acceptance=json.loads((native_root/'native-development-v1/acceptance.json').read_bytes())
journal=json.loads((native_root/'native-execution-v1/journal.json').read_bytes())
assert report['status']==acceptance['status']=='COMPLETE_CORE_HOST_CUSTODY_NATIVE_PASS'
assert report['tests_run']==report['tests_expected']==22 and not report['failures'] and not report['test_errors'] and not report['skips']
assert report['source_initial_terminal_identical'] and report['seed_initial_terminal_identical'] and report['compiler_initial_terminal_identical']
prior_report=json.loads((roots[0]/'native-development-v1/work/report.json').read_bytes())
prior_receipt=json.loads((roots[0]/'native-development-v1/native-gates.process-owner.json').read_bytes())
prior_journal=json.loads((roots[0]/'native-execution-v1/journal.json').read_bytes())
assert prior_report['status']=='HOLD' and prior_report['tests_run']==22 and len(prior_report['failures'])==30
assert prior_journal['state']=='exited' and prior_journal['exit_code']==1
assert prior_receipt['returncode']==1 and prior_receipt['cleanup']['complete'] and prior_receipt['cleanup']['observed_echild']
assert not prior_receipt['cleanup']['remaining_direct_children']
assert journal['state']=='exited' and journal['exit_code']==0
assert acceptance['processes'][0]['owner_returned']['cleanup']['complete']
assert acceptance['processes'][0]['owner_returned']['cleanup']['observed_echild']
print(json.dumps({'native_report':report,'acceptance':acceptance,'journal':journal,'failed_prior_run':{'source_head':prior_report['source_head'],'tests_run':22,'failed_subcases':30,'complete_cleanup_observed_echild':True}}),flush=True)
def identity(s):
 return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def capture(p,arc):
 s=p.lstat();row=dict(path=str(p),archive_path=arc,mode=stat.S_IMODE(s.st_mode),identity=identity(s))
 if stat.S_ISREG(s.st_mode):
  raw=p.read_bytes();row.update(kind='file',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 elif stat.S_ISDIR(s.st_mode):row['kind']='directory'
 elif stat.S_ISLNK(s.st_mode):row.update(kind='symlink',link=os.readlink(p))
 elif stat.S_ISFIFO(s.st_mode):row['kind']='fifo'
 else:raise ValueError(('unsupported actual evidence kind',str(p),s.st_mode))
 assert identity(p.lstat())==row['identity'],p
 return row
rows=[];exclusions=[]
for root in roots:
 mf=json.loads((root/'source-manifest.json').read_bytes())
 for q in sorted(root.iterdir()):
  if q.name=='source':
   exclusions.append(dict(path=str(q),reason='complete exact Git tree retained by ancestor commit, all physical bytes/modes separately captured',head=mf['head'],tree=mf['tree'],file_count=mf['file_count'],bytes=mf['source_bytes']))
   continue
  if q.name=='source-objects.pack':
   exclusions.append(dict(path=str(q),reason='reconstructible explicit Git object transport, immutable complete source commit retained',head=mf['head'],bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
   continue
  paths=[q]
  if q.is_dir() and not q.is_symlink():
   for folder,dirs,files in os.walk(q,followlinks=False):
    dirs.sort();files.sort();base=Path(folder)
    for name in dirs+files:paths.append(base/name)
  for p in paths:rows.append(capture(p,root.name+'/'+str(p.relative_to(root))))
assert len(rows)==len({r['archive_path'] for r in rows})
manifest=dict(schema='hepta.hia.complete-core-host-custody-development-evidence.v1',scope='both complete native custody attempts including the first native CLI refusal and the final 22-method PASS; complete immutable source trees remain in Git',entries=rows,excluded_reconstructible_inputs=exclusions,expanded_files_removed=False)
(out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
archive=out/'complete-native-originals.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6,dereference=False) as tf:
 for row in rows:tf.add(row['path'],arcname=row['archive_path'],recursive=False)
terminal=[capture(Path(r['path']),r['archive_path']) for r in rows]
assert terminal==rows,'physical evidence changed during archive'
verified=[]
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.name.rstrip('/')==row['archive_path'].rstrip('/') and member.mode==row['mode']
  if row['kind']=='file':
   assert member.isfile();raw=tf.extractfile(member).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
  elif row['kind']=='directory':assert member.isdir()
  elif row['kind']=='symlink':assert member.issym() and member.linkname==row['link']
  elif row['kind']=='fifo':assert member.isfifo()
  verified.append(row['archive_path'])
result=dict(status='EVERY_TYPED_MEMBER_READ_BACK_AND_PHYSICAL_INPUT_STABLE',archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(rows),files=sum(r['kind']=='file' for r in rows),uncompressed_file_bytes=sum(r.get('bytes',0) for r in rows),all_failures_retained=True,final_tests_run=report['tests_run'],final_native_invocations=report['actual_native_invocations'],expanded_files_removed=False)
(out/'readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result),flush=True)

from pathlib import Path
import tarfile,io,json,hashlib,time
out=Path('/home/qian-qi/hia-core-host-custody-complete-development-evidence-20261128-2ac5');manifest=json.loads((out/'manifest.json').read_bytes())
chunk_bytes=32768;blobs={};entries=[]
with tarfile.open(out/'complete-native-originals.tar.gz','r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(manifest['entries'])
 for m,row in zip(members,manifest['entries']):
  assert m.name.rstrip('/')==row['archive_path'].rstrip('/')
  r=dict(row)
  if row['kind']=='file':
   raw=tf.extractfile(m).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
   parts=[]
   for at in range(0,len(raw),chunk_bytes):
    part=raw[at:at+chunk_bytes];digest=hashlib.sha256(part).hexdigest()
    if digest in blobs:assert blobs[digest]==part
    else:blobs[digest]=part
    parts.append(dict(sha256=digest,bytes=len(part)))
   r['chunks']=parts
  entries.append(r)
complete=dict(schema='hepta.hia.full-file-chunk-custody.v1',chunk_bytes=chunk_bytes,entries=entries,excluded_reconstructible_inputs=manifest['excluded_reconstructible_inputs'],full_original_archive_sha256=hashlib.sha256((out/'complete-native-originals.tar.gz').read_bytes()).hexdigest(),whole_file_sha256_required=True,expanded_files_removed=False)
raw_manifest=(json.dumps(complete,sort_keys=True,indent=2)+'\n').encode()
(out/'chunk-manifest.json').write_bytes(raw_manifest)
archive=out/'complete-native-cas.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6) as tf:
 for name,raw in [('manifest.json',raw_manifest),*((('blobs/'+key),blobs[key]) for key in sorted(blobs))]:
  item=tarfile.TarInfo(name);item.mode=0o400;item.size=len(raw);item.mtime=0;tf.addfile(item,io.BytesIO(raw))
del blobs
with tarfile.open(archive,'r:gz') as tf:
 observed={}
 for member in tf:
  raw=tf.extractfile(member).read()
  if member.name=='manifest.json':assert raw==raw_manifest;continue
  digest=member.name.removeprefix('blobs/');assert hashlib.sha256(raw).hexdigest()==digest
  observed[digest]=raw
 for row in complete['entries']:
  if row['kind']!='file':continue
  digest=hashlib.sha256();size=0
  for part in row['chunks']:
   raw=observed[part['sha256']];assert len(raw)==part['bytes'];digest.update(raw);size+=len(raw)
  assert size==row['bytes'] and digest.hexdigest()==row['sha256']
result=dict(status='EVERY_COMPLETE_FILE_RECONSTRUCTED_AND_SHA256_VERIFIED',archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(entries),files=sum(r['kind']=='file' for r in entries),unique_chunks=len(observed),unique_uncompressed_chunk_bytes=sum(len(raw) for raw in observed.values()),original_complete_file_bytes=sum(r.get('bytes',0) for r in entries),physical_source_preservation_in_git=complete['excluded_reconstructible_inputs'],whole_file_not_excerpt_custody=True,expanded_files_removed=False)
(out/'cas-readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='physical_source_preservation_in_git'}),flush=True)
