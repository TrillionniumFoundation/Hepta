
from pathlib import Path
from hashlib import sha256
import json,sys
root=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(root))
from tools import hia_current_store_source_history as current
from tools import hia_frozen_component_sources as frozen
from tools import hia_current_source_generation as generation
actual={n:(root/n).read_bytes() for n in frozen.CURRENT}
restored,h=current.restore(actual,root=root)
assert {n:current.pin(restored[n])for n in frozen.CURRENT}==frozen.PREDECESSORS
assert h['review']['complete_current'][generation.SERVICE]==generation.CURRENT[generation.SERVICE]
assert h['captures'][generation.SERVICE]==actual[generation.SERVICE]
current.verify_unchanged(h)
(out/'actual-store-review.json').write_text(json.dumps(h['review'],sort_keys=True,indent=2)+'\n')
name=generation.REGISTRY
old=current.reviewed_source(root,name,(root/name).read_bytes())
assert generation.pin(old)=={'bytes':23966,'sha256':'ee84fb3f778adcab884906cc7c41c52adecdd1f5ed794da9f4d49a2a1cda5b90'}
print(json.dumps({'status':'CURRENT_GENERATION_STORE_AND_REGISTRY_ADMITTED','actual_service':generation.CURRENT[generation.SERVICE],'retained_registry':generation.pin(old),'captured_files':len(h['captures']),'current_product_execution_qualified':False},sort_keys=True))
