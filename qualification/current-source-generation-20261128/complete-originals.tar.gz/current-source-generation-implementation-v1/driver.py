from pathlib import Path
import subprocess,json,hashlib,ast,difflib,os,sys,time
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'current-source-generation-implementation-v1';out.mkdir(mode=0o700,exist_ok=False)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.run(['git',*a],cwd=root,env=env,capture_output=True,check=True).stdout
head='09a39e1375a9310e185ceb03d20bd639584a39a5'
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
payload=json.loads(sys.argv[1]);(out/'driver.py').write_text(sys.argv[2])
name='tools/hia_current_store_source_history.py'
raw=(root/name).read_bytes();assert hashlib.sha256(raw).hexdigest()=='ec3a5c47b4b6c3ae238531ebd6a060f32f690e85b408a0c2970effa15dbfd1d9'
(out/'store-reader.before.py').write_bytes(raw)
(root/name).write_bytes(raw+payload['wrapper'].encode())
paths=('hepta/hia_agent_service.py','hepta/hia_native_helpers.py','tools/build_hia_service_bootstrap.py','tests/test_hia_service_verification_native.py',name)
rows={}
for name in paths:
 old=git('show','077c0b2e82edd7da50d84c11b55756beb61ee043:'+name)
 current=(root/name).read_bytes()
 assert current!=old
 before=old.splitlines(keepends=True);after=current.splitlines(keepends=True)
 old_at=[0];new_at=[0]
 for line in before:old_at.append(old_at[-1]+len(line))
 for line in after:new_at.append(new_at[-1]+len(line))
 hunks=[]
 for op,a,b,c,d in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes():
  if op=='equal':continue
  hunks.append({'old_offset':old_at[a],'new_offset':new_at[c],'old_hex':old[old_at[a]:old_at[b]].hex(),'new_hex':current[new_at[c]:new_at[d]].hex()})
 rows[name]={'old_bytes':len(old),'new_bytes':len(current),'old_sha256':hashlib.sha256(old).hexdigest(),'new_sha256':hashlib.sha256(current).hexdigest(),'hunks':hunks}
 prior=out/'prior'/name;prior.parent.mkdir(parents=True,exist_ok=True);prior.write_bytes(old)
fixture={'schema':'hepta.hia.current-source-generation-relation.v1','scope':'EXPLICIT_RETAINED_393_SOURCE_CONTROL_DOMAIN','prior_commit':'077c0b2e82edd7da50d84c11b55756beb61ee043','current_parent':head,'files':rows,'original_test_methods_changed':False,'original_fixed_authorities_changed':False,'physical_projection_is_current_source':False,'current_product_qualified':False}
raw=(json.dumps(fixture,sort_keys=True,indent=2)+'\n').encode()
path=root/'tests/fixtures/hia_current_source_generation_v1.json';assert not path.exists();path.write_bytes(raw)
helper=payload['helper'].replace('__FIXTURE_SHA256__',hashlib.sha256(raw).hexdigest())
assert '__FIXTURE_SHA256__'not in helper
ast.parse(helper)
path=root/'tools/hia_current_source_generation.py';assert not path.exists();path.write_text(helper)
for p,pin in [('tools/hia_frozen_component_sources.py','60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774'),('tools/hia_evaluation_window_history.py','08054cf59af6e93453fc370d08c64d1b14e9072012f69652cfae747083346cfa')]:
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==pin
record={'head':head,'fixture_bytes':len(raw),'fixture_sha256':hashlib.sha256(raw).hexdigest(),'changed_relations':{n:{k:v for k,v in r.items()if k!='hunks'}for n,r in rows.items()},'legacy_current_store_source_retained_exact_before_appended_layer':True}
(out/'implementation.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record,sort_keys=True),flush=True)
probe=r'''
from pathlib import Path
from hashlib import sha256
import json,sys
root=Path(sys.argv[1]);out=Path(sys.argv[2]);sys.path.insert(0,str(root))
from tools import hia_current_store_source_history as current
from tools import hia_frozen_component_sources as frozen
from tools import hia_current_source_generation as generation
actual={n:(root/n).read_bytes() for n in frozen.CURRENT}
restored,h=current.restore(actual,root=root)
assert {n:current.pin(restored[n])for n in frozen.CURRENT}==frozen.PREDECESSORS
assert h['review']['complete_current'][generation.SERVICE]==generation.CURRENT[generation.SERVICE]
assert h['captures'][generation.SERVICE]==actual[generation.SERVICE]
current.verify_unchanged(h)
(out/'actual-store-review.json').write_text(json.dumps(h['review'],sort_keys=True,indent=2)+'\n')
name=generation.REGISTRY
old=current.reviewed_source(root,name,(root/name).read_bytes())
assert generation.pin(old)=={'bytes':23966,'sha256':'ee84fb3f778adcab884906cc7c41c52adecdd1f5ed794da9f4d49a2a1cda5b90'}
print(json.dumps({'status':'CURRENT_GENERATION_STORE_AND_REGISTRY_ADMITTED','actual_service':generation.CURRENT[generation.SERVICE],'retained_registry':generation.pin(old),'captured_files':len(h['captures']),'current_product_execution_qualified':False},sort_keys=True))
'''
(out/'actual-current-probe.py').write_text(probe)
start=time.monotonic()
q=subprocess.run([sys.executable,'-B',str(out/'actual-current-probe.py'),str(root),str(out)],cwd=root,env=env,capture_output=True,timeout=120)
(out/'actual-current-probe.stdout').write_bytes(q.stdout);(out/'actual-current-probe.stderr').write_bytes(q.stderr)
result={'returncode':q.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True),flush=True)
raise SystemExit(q.returncode)
