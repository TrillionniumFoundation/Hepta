from pathlib import Path
import subprocess,json,hashlib,os,sys,time,tarfile
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'current-source-generation-controls-v2';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
p=root/'tests/test_hia_current_source_generation.py';raw=p.read_text();(out/'tests.before.py').write_text(raw)
anchor="        cls.sources = dict(history['captures'])\n        cls.prior = dict(history['generation_history'].prior_sources)\n"
replacement="""        cls.sources = dict(history['captures'])
        cls.prior = dict(history['generation_history'].prior_sources)
        def capture_registry(path):
            name = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            if name in cls.sources and cls.sources[name] != raw:
                raise ValueError('actual registry fixture capture changed')
            cls.sources[name] = raw
            return raw
        current.reviewed_source(ROOT, generation.REGISTRY,
            (ROOT / generation.REGISTRY).read_bytes(), take=capture_registry)
"""
assert raw.count(anchor)==1
new=raw.replace(anchor,replacement,1)
assert new.count('self.root = Path(self.directory.name)')==1
new=new.replace('self.root = Path(self.directory.name)','self.root = Path(self.directory.name).resolve(strict=True)',1)
p.write_text(new)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'-B','tools/run_hia_unittest_gate.py','tests.test_hia_current_source_generation']
start=time.monotonic()
q=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=120)
(out/'tests.stdout').write_bytes(q.stdout);(out/'tests.stderr').write_bytes(q.stderr)
result={'returncode':q.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':q.stdout.decode(),'stderr':q.stderr.decode(),'fix':'actual registry reader now supplies all its captured fixture inputs; negative take uses canonical selected root','original_negative_assertions_unchanged':True}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
folder=root/'review-evidence/hia-worker-compat-release-20261128-2ac5'
manifest_raw=(folder/'complete-native-manifest.json').read_bytes();manifest=json.loads(manifest_raw)
files=[r for r in manifest['items'] if r['type']=='file'];hashes={r['sha256']for r in files}
with tarfile.open(folder/'complete-native-evidence.tar.gz','r:gz')as t:
 members=t.getmembers()
 assert len(members)==len(hashes)+1 and len({m.name for m in members})==len(members)
 assert t.extractfile('manifest.json').read()==manifest_raw
 assert {m.name for m in members}=={'manifest.json'}|{'blobs/'+h for h in hashes}
 content={}
 for m in members:
  assert m.isfile()and m.mode==0o400
  data=t.extractfile(m).read()
  if m.name.startswith('blobs/'):
   h=m.name.split('/')[1];assert hashlib.sha256(data).hexdigest()==h
   content[h]=data
 for row in files:
  data=content[row['sha256']];assert len(data)==row['bytes'] and type(row['mode'])is int and 0<=row['mode']<=0o777
verification={'status':'ALL_STAGE20_ORIGINAL_CAS_MEMBERS_INDEPENDENTLY_VERIFIED','complete_files':len(files),'complete_file_bytes':sum(r['bytes']for r in files),'paths_including_directories':len(manifest['items']),'unique_blobs':len(hashes),'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'original_modes_retained_in_manifest':True}
(out/'stage20-independent-cas-verification.json').write_text(json.dumps(verification,sort_keys=True,indent=2)+'\n')
print(json.dumps(verification,sort_keys=True),flush=True)
raise SystemExit(q.returncode)
