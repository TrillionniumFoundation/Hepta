from pathlib import Path
import subprocess,json,hashlib,ast,os,sys,tarfile,stat
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'current-source-generation-registration-v1';out.mkdir(mode=0o700,exist_ok=False)
payload=json.loads(sys.argv[1]);(out/'driver.py').write_text(sys.argv[2])
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.run(['git',*a],cwd=root,env=env,capture_output=True,check=True).stdout
head='09a39e1375a9310e185ceb03d20bd639584a39a5'
assert git('rev-parse','HEAD').decode().strip()==head
assert set(git('diff','--name-only').decode().splitlines())=={'tools/hia_current_store_source_history.py'}
paths=['tools/hia_current_source_generation.py','tools/qualify_hia_current_source_generation.py','tests/test_hia_current_source_generation.py','tests/fixtures/hia_current_source_generation_v1.json']
assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())==set(paths)
terminal=json.loads((root.parent/'current-source-generation-controls-v2/terminal.json').read_bytes())
assert terminal['returncode']==0 and 'Ran 10 tests' in terminal['stderr'] and terminal['stderr'].rstrip().endswith('OK')
old_store=git('show',head+':tools/hia_current_store_source_history.py')
current=(root/'tools/hia_current_store_source_history.py').read_bytes();assert current.startswith(old_store)
doc='docs/HIA_CURRENT_SOURCE_GENERATION.md';assert not(root/doc).exists();(root/doc).write_text(payload['doc'])
sys.path.insert(0,str(root))
from tools.hia_selfhost_contract import SOURCE_FILES
from hepta.hia_agent_contract import NATIVE_SOURCE_FILES
assert not set(paths).intersection(SOURCE_FILES)and not set(paths).intersection(NATIVE_SOURCE_FILES)
native_before={name:hashlib.sha256((root/name).read_bytes()).hexdigest()for name in ('hepta/hia_agent_contract.py','docs/HIA_NATIVE_SOURCE_AUTHORITY.json','docs/HIA_COLD_NATIVE_SOURCE_FILES.json')}
p=root/'tools/hia_selfhost_contract.py';raw=p.read_bytes();(out/'source-contract.before.py').write_bytes(raw)
anchor=b'SOURCE_FILES = (\n';assert raw.count(anchor)==1
new=raw.replace(anchor,anchor+''.join('    '+repr(x)+',\n'for x in paths).encode(),1)
def node(b):return next(n for n in ast.parse(b).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='SOURCE_FILES'for t in n.targets)).value
assert ast.dump(ast.Tuple(elts=node(new).elts[len(paths):],ctx=ast.Load()))==ast.dump(node(raw))
p.write_bytes(new)
p=root/'MANIFEST.in';raw=p.read_bytes();(out/'MANIFEST.before.in').write_bytes(raw)
added=['include '+n for n in paths+[doc]if 'include '+n not in raw.decode().splitlines()]
p.write_bytes(raw+b'\n'+('\n'.join(added)+'\n').encode())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in native_before.items())
old_tests={}
for selector in payload['selectors']:
 name='/'.join(selector.split('.')[:2])+'.py'
 raw=(root/name).read_bytes();assert git('show',head+':'+name)==raw
 old_tests[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
for i,cloud in enumerate(payload['clouds']):
 value=json.loads(cloud['structuredContent']['content'])
 assert (value.get('sha')or value.get('object',{}).get('sha'))==head
 (out/('prior-publication-cloud-'+str(i)+'.json')).write_text(json.dumps(cloud,sort_keys=True,indent=2)+'\n')
record={'schema':'hepta.hia.current-source-generation-registration.v1','parent':head,'host_sources_added':paths,'native_authority_unchanged':native_before,'original_store_reader_retained_as_complete_prefix':{'bytes':len(old_store),'sha256':hashlib.sha256(old_store).hexdigest()},'original_selector_count':47,'original_source_test_modules':old_tests,'original_test_methods_modified':False,'actual_current_controls':10,'actual_current_controls_passed':True,'original393_full_gate_pending':True,'whole_native_installation_qualified':False}
(out/'registration.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
proof=root/'qualification/current-source-generation-20261128';proof.mkdir(parents=True,exist_ok=False)
folders=['current-source-generation-implementation-v1','current-source-generation-controls-v1','current-source-generation-controls-v2','original393-current-source-f75-failure-read-v1','current-source-generation-registration-v1','worker-compat-stage20-evidence-integration-v1','worker-compat-stage20-normal-publication-v1']
originals=[];archive=proof/'complete-originals.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for folder in folders:
  base=root.parent/folder;assert base.is_dir(),folder
  for p in sorted(base.rglob('*')):
   s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   assert stat.S_ISREG(s.st_mode)and not p.is_symlink(),str(p)
   raw=p.read_bytes();name=p.relative_to(root.parent).as_posix()
   originals.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode)})
   t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(originals)
 for row in originals:
  raw=t.extractfile(row['path']).read();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
(proof/'complete-originals-manifest.json').write_text(json.dumps(originals,sort_keys=True,indent=2)+'\n')
(proof/'registration.json').write_text(json.dumps({**record,'complete_original_files':len(originals),'archive':{'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}},sort_keys=True,indent=2)+'\n')
expected=set(paths)|{doc,'tools/hia_current_store_source_history.py','tools/hia_selfhost_contract.py','MANIFEST.in'}|{p.relative_to(root).as_posix()for p in proof.iterdir()}
assert set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())==expected
git('diff','--check');git('add','--',*sorted(expected))
assert set(git('diff','--cached','--name-only').decode().splitlines())==expected
q=subprocess.run(['git','commit','-m','Bind actual native source successors to retained source controls without changing original assertions'],cwd=root,env=env,capture_output=True)
(out/'commit.stdout').write_bytes(q.stdout);(out/'commit.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.returncode,q.stderr)
new=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert git('show','-s','--format=%P','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
result={'status':'CURRENT_SOURCE_GENERATION_COMMITTED','head':new,'tree':tree,'parent':head,'actual_current_source_controls':10,'original393_full_gate_pending':True,'whole_native_installation_qualified':False}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
