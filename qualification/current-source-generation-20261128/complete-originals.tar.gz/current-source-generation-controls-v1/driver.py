from pathlib import Path
import subprocess,json,hashlib,ast,sys,os,time,tarfile
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'current-source-generation-controls-v1';out.mkdir(mode=0o700,exist_ok=False)
payload=json.loads(sys.argv[1]);(out/'driver.py').write_text(sys.argv[2])
for name,text in [('tests/test_hia_current_source_generation.py',payload['tests']),('tools/qualify_hia_current_source_generation.py',payload['qualifier'])]:
 path=root/name;assert not path.exists();ast.parse(text);path.write_text(text)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'-B','tools/run_hia_unittest_gate.py','tests.test_hia_current_source_generation']
(out/'intent.json').write_text(json.dumps({'argv':argv,'actual_current_controls':10,'original393_separate_and_not_yet_run':True},sort_keys=True,indent=2)+'\n')
start=time.monotonic()
q=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=120)
(out/'tests.stdout').write_bytes(q.stdout);(out/'tests.stderr').write_bytes(q.stderr)
result={'returncode':q.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
probe=subprocess.run([sys.executable,'-B','-c','import importlib.util,json;print(json.dumps({n:bool(importlib.util.find_spec(n))for n in ("z3","jsonschema")}))'],capture_output=True)
print(json.dumps({'mac_original_qa_imports':probe.stdout.decode(),'stderr':probe.stderr.decode(),'returncode':probe.returncode}),flush=True)
folder=root/'review-evidence/hia-worker-compat-release-20261128-2ac5'
manifest=json.loads((folder/'complete-native-manifest.json').read_bytes())
print(json.dumps({'stage20_manifest_type':type(manifest).__name__,'keys':list(manifest)if isinstance(manifest,dict)else None,'preview':str(manifest)[:2000]}),flush=True)
with tarfile.open(folder/'complete-native-evidence.tar.gz','r:gz')as t:
 members=t.getmembers()
 print(json.dumps({'stage20_cas_members':len(members),'first_members':[{'path':m.name,'bytes':m.size,'mode':m.mode,'file':m.isfile()}for m in members[:12]]}),flush=True)
raise SystemExit(q.returncode)
