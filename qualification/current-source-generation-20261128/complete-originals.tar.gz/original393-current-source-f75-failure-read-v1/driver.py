from pathlib import Path
from hashlib import sha1,sha256
import json,os,subprocess,signal,time,sys,stat,re
os.umask(0o022)
base=Path('/home/qq/hia-final-native-cold-20261128-2ac5');original=base/'source'
out=base/'source-controls-f75-v1';out.mkdir(mode=0o700,exist_ok=False);source=out/'source'
inputs=json.loads(sys.argv[1]);head=inputs['head'];tree=inputs['tree'];mods=inputs['selectors']
assert head=='f75a5eadc7ba6501beb3fa8fafdae46b1cfcd828'and tree=='d2d5c75a64c5dfe246612ca612a7bf476fc69f1c'and len(mods)==47
(out/'driver.py').write_text(sys.argv[2]);(out/'original393-driver.py').write_text(inputs['original_driver'])
(out/'original393-selection.json').write_text(json.dumps(inputs,sort_keys=True,indent=2)+'\n')
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')and k not in ('PYTHONPATH','PYTHONHOME')}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
def git(where,*a):return subprocess.check_output(['/usr/bin/git',*a],cwd=where,env=env)
old_head=git(original,'rev-parse','HEAD').decode().strip();assert old_head=='3e27f633586a71531846b3e189d3b1f69b4ae4b5'
old_status=git(original,'status','--porcelain=v1','--untracked-files=all')
manifest=json.loads((base/'source3e27-preparation-export-v3/manifest.json').read_bytes())
for row in manifest['products']:
 raw=(original/row['path']).read_bytes();assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
gitdir=Path(git(original,'rev-parse','--absolute-git-dir').decode().strip())
alternate=gitdir/'objects/info/alternates';assert not alternate.exists()
with (out/'fetch.stdout').open('xb')as so,(out/'fetch.stderr').open('xb')as se:
 q=subprocess.run(['/usr/bin/git','fetch','--no-tags','--depth=1','https://github.com/TrillionniumFoundation/Hepta.git',head],cwd=original,env=env,stdout=so,stderr=se,timeout=180)
assert q.returncode==0,q.returncode
assert git(original,'rev-parse',head+'^{tree}').decode().strip()==tree
q=subprocess.run(['/usr/bin/git','worktree','add','--detach',str(source),head],cwd=original,env=env,capture_output=True,timeout=180)
(out/'worktree-add.stdout').write_bytes(q.stdout);(out/'worktree-add.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.returncode,q.stderr)
assert git(original,'rev-parse','HEAD').decode().strip()==old_head and git(original,'status','--porcelain=v1','--untracked-files=all')==old_status
for row in manifest['products']:
 raw=(original/row['path']).read_bytes();assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
assert not alternate.exists()
physical=[];total=0
for row in git(source,'ls-tree','-rz',head).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();assert kind==b'blob'and mode in(b'100644',b'100755')
 path=source/os.fsdecode(name);st=path.lstat();assert stat.S_ISREG(st.st_mode)and st.st_nlink==1
 data=path.read_bytes();assert sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid.decode(),os.fsdecode(name)
 assert bool(st.st_mode&0o111)==(mode==b'100755'),os.fsdecode(name)
 total+=len(data);physical.append({'path':os.fsdecode(name),'mode':mode.decode(),'blob':oid.decode(),'bytes':len(data),'sha256':sha256(data).hexdigest()})
assert git(source,'rev-parse','HEAD').decode().strip()==head and not git(source,'status','--porcelain=v1').strip()
(out/'physical-git-materialization.json').write_text(json.dumps({'head':head,'tree':tree,'files':physical,'physical_bytes':total,'owned_object_database':str(gitdir),'new_alternates':False,'original_preparation_worktree_unchanged':True,'worktree_dependency_explicit':True},sort_keys=True,indent=2)+'\n')
temporary=out/'tmp';temporary.mkdir(mode=0o700);env['TMPDIR']=str(temporary);os.environ['TMPDIR']=str(temporary)
os.chdir(source);sys.path.insert(0,str(source))
from tools.hia_selfhost_contract import file_digests
before=file_digests(source);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
python=str(base/'original393-qa-prerequisites-v1/venv/bin/python')
argv=[python,'-B','tools/run_hia_unittest_gate.py',*mods]
log=out/'tests.log';start=time.monotonic()
with log.open('xb')as f:
 proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
 started={'phase':'ORIGINAL_47_SELECTOR_SOURCE_GATE_STARTED','pid':proc.pid,'head':head,'tree':tree,'materialized_files':len(physical),'physical_bytes':total,'argv':argv,'original_wall_limit_seconds':900,'original_cleanup_limit_seconds':3}
 (out/'start.json').write_text(json.dumps(started,sort_keys=True,indent=2)+'\n');print(json.dumps(started,sort_keys=True),flush=True)
 try:code=proc.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
after=file_digests(source);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
raw=log.read_bytes();matches=re.findall(rb'Ran ([0-9]+) tests? in ([0-9.]+)s',raw)
terminal={'schema':'hepta.hia.unified-native-cold-source-controls.v1','source_head':head,'source_tree':tree,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'source_count':len(before),'source_unchanged':before==after,'source_clean':not bool(git(source,'status','--porcelain=v1')),'log_bytes':len(raw),'log_sha256':sha256(raw).hexdigest(),'caller_execution_claimed':False,'whole_native_delivery_qualified':False,'original_selector_count':47,'reported_tests':int(matches[-1][0])if matches else None,'reported_unittest_seconds':float(matches[-1][1])if matches else None}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n');print(json.dumps(terminal,sort_keys=True),flush=True);print(raw.decode(errors='replace')[-17000:],flush=True)
raise SystemExit(code if before==after and terminal['source_clean'] else 2)
