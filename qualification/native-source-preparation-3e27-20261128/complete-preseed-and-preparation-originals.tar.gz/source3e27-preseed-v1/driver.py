from pathlib import Path
import subprocess,os,json,hashlib,time,stat,sys
os.umask(0o022)
base=Path('/home/qq/hia-final-native-cold-20261128-2ac5')
source=base/'source';out=base/'source3e27-preseed-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(base/'tmp'))
def git(*a):return subprocess.check_output(['git',*a],cwd=source,env=env)
old='8953bdbd3cced1aa7db4642865ba00ed7d8f5e0c';head='3e27f633586a71531846b3e189d3b1f69b4ae4b5';tree='047766f96dfced82ee43e4ec720c519226ab9134'
assert git('rev-parse','HEAD').decode().strip()==old and not git('status','--porcelain=v1').strip()
assert not (source/'.git/objects/info/alternates').exists()
started=time.monotonic()
with (out/'fetch.stdout').open('xb') as so,(out/'fetch.stderr').open('xb') as se:p=subprocess.run(['git','fetch','--depth=1','--no-tags','origin',head],cwd=source,env=env,stdout=so,stderr=se,timeout=1200)
(out/'fetch-terminal.json').write_text(json.dumps({'returncode':p.returncode,'wall_seconds':time.monotonic()-started},sort_keys=True,indent=2)+'\n')
assert p.returncode==0
assert git('rev-parse',head+'^{tree}').decode().strip()==tree
p=subprocess.run(['git','checkout','--detach',head],cwd=source,env=env,capture_output=True,check=True)
(out/'checkout.stdout').write_bytes(p.stdout);(out/'checkout.stderr').write_bytes(p.stderr)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
rows=[];physical={}
for line in git('ls-tree','-r','-z',head).split(b'\0'):
 if not line:continue
 meta,name=line.split(b'\t',1);mode,kind,blob=meta.split();assert kind==b'blob'
 name=name.decode();path=source/name;s=path.lstat()
 raw=os.readlink(path).encode() if mode==b'120000' else path.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob.decode(),name
 if mode!=b'120000':assert bool(s.st_mode&stat.S_IXUSR)==(mode==b'100755'),name
 rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob.decode(),'git_mode':mode.decode()})
 physical[name]=(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
(out/'whole-source-materialization.json').write_text(json.dumps({'head':head,'tree':tree,'prior':old,'files':rows,'owned_no_alternates':True},sort_keys=True,indent=2)+'\n')
receipt=base/'bootstrap-input-custody/bootstrap-inputs.json'
assert hashlib.sha256(receipt.read_bytes()).hexdigest()=='9c4ddf8477df203d08ca4331649fbed0441f82ca313afc5ed828b0f5ecbaedb7'
argv=[sys.executable,'-I','-B','tools/hia_native_cold_preseed.py','--source',str(source),'--root-receipt',str(receipt),'--output',str(out/'preseed')]
(out/'preseed-command.json').write_text(json.dumps(argv,indent=2)+'\n')
print(json.dumps({'phase':'CURRENT_SOURCE_PRESEED_BEGIN','head':head,'whole_git_files_verified':len(rows),'native_source_authority':1423}),flush=True)
start=time.monotonic()
with (out/'preseed.stdout').open('xb') as so,(out/'preseed.stderr').open('xb') as se:p=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=1200)
result={'returncode':p.returncode,'wall_seconds':time.monotonic()-start,'head':head,'tree':tree,'scope':'CURRENT_NATIVE_ENTRY_PREPARATION; not a whole cold qualification','source_clean':not bool(git('status','--porcelain=v1').strip())}
(out/'preseed-terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
for name,identity in physical.items():
 s=(source/name).lstat();assert identity==(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns),name
result['whole_source_initial_terminal_identity_unchanged']=True
if p.returncode:
 result['status']='PRESEED_FAILED_ORIGINALS_PRESERVED'
else:
 report=json.loads((out/'preseed/report.json').read_bytes());assert report['passed'] and not report['target_or_successor_compiler_used']
 result.update(status='CURRENT_SOURCE_PRESEED_COMPLETE',source_inputs=len(report['sources']),native_invocations=len(report['invocations']),whole_cold_qualified=False)
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True),flush=True)
print((out/'preseed.stderr').read_text(),flush=True)
raise SystemExit(p.returncode)
