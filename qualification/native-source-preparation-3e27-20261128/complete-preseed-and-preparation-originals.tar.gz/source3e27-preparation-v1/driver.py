from pathlib import Path
import subprocess,json,os,hashlib,time,sys
base=Path('/home/qq/hia-final-native-cold-20261128-2ac5');source=base/'source'
out=base/'source3e27-preparation-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
head='3e27f633586a71531846b3e189d3b1f69b4ae4b5'
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')}
env.update(PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',TMPDIR=str(base/'tmp'))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,env=env,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=source,env=env).strip()
preseed=base/'source3e27-preseed-v1/preseed'
p=json.loads((preseed/'report.json').read_bytes());assert p['passed'] and not p['target_or_successor_compiler_used']
for name,pin in p['sources'].items():
 raw=(source/name).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
argv=[sys.executable,'-I','-B','tools/hia_native_cold_prepare.py','--source',str(source),'--base',head,'--preseed',str(preseed),'--output',str(out/'preparation')]
(out/'command.json').write_text(json.dumps(argv,indent=2)+'\n')
start=time.monotonic()
with (out/'prepare.stdout').open('xb') as so,(out/'prepare.stderr').open('xb') as se:p=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=1200)
record={'head':head,'returncode':p.returncode,'wall_seconds':time.monotonic()-start,'scope':'CURRENT_NATIVE_SOURCE_PREPARATION; all original inner caps retained; final whole cold qualification not yet started'}
report_path=out/'preparation/report.json'
if report_path.exists():
 report=json.loads(report_path.read_bytes())
 record.update(passed=report.get('passed'),source_count=report.get('source_count'),changed_sources=report.get('changed_sources'),phase_count=report.get('phase_count'),qualification_nodes=report.get('qualification_nodes'))
(out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record,sort_keys=True),flush=True)
print((out/'prepare.stdout').read_text(),flush=True);print((out/'prepare.stderr').read_text(),flush=True)
raise SystemExit(p.returncode)
