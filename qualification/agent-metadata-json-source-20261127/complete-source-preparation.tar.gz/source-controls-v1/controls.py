from pathlib import Path
import json,sys,hashlib,unittest
root=Path.cwd();sys.path.insert(0,str(root))
from hepta.hia_agent_assembly import render_assembly,assemble_program
from tools import generate_hia_agent_native_metadata as metadata
from tools import generate_hia_agent_json_wire as writer
from hepta.hia_program import verify_program
out=Path(sys.argv[1])
records=[]
for name,author in [('agent_native_metadata',metadata),('agent_json_wire',writer)]:
 p=root/'examples/hia_bootstrap'/(name+'.hepta');before=p.read_bytes()
 (out/(name+'.whole-original.hepta.txt')).write_bytes(before)
 model=author.document();verify_program(model);raw=render_assembly(model).encode()
 actual=assemble_program(raw).as_dict();assert actual==model
 p.write_bytes(raw)
 (out/(name+'.current-generated.hepta.txt')).write_bytes(raw)
 records.append(dict(component=name,original_bytes=len(before),original_sha256=hashlib.sha256(before).hexdigest(),generated_bytes=len(raw),generated_sha256=hashlib.sha256(raw).hexdigest(),functions=len(model['functions']),blocks=sum(len(f['blocks']) for f in model['functions']),instructions=sum(len(b['ops']) for f in model['functions'] for b in f['blocks']),whole_current_author_source_retained=True))
(out/'generated-candidates.json').write_text(json.dumps(records,indent=2)+'\n')
suite=unittest.defaultTestLoader.loadTestsFromNames(['tests.test_hia_agent_native_metadata.AgentMetadataSourceTests','tests.test_hia_agent_json_wire.AgentJsonWireSourceTests'])
with (out/'unittest.stderr').open('w') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
report=dict(status='SOURCE_CONTROLS_PASS' if result.wasSuccessful() and not result.skipped and result.testsRun==7 else 'HOLD',tests_run=result.testsRun,failures=[(t.id(),e) for t,e in result.failures],errors=[(t.id(),e) for t,e in result.errors],skips=[(t.id(),e) for t,e in result.skipped],native_execution=False,candidates=records)
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
raise SystemExit(0 if report['status']=='SOURCE_CONTROLS_PASS' else 1)
