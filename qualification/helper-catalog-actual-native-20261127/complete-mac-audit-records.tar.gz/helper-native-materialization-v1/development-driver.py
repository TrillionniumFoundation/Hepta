from pathlib import Path
import os,sys,json,hashlib,subprocess,struct,time,traceback,unittest
ROOT=Path('/home/qian-qi/hia-helper-catalog-native-20261127-2ac5')
SOURCE=ROOT/'source';OUT=ROOT/'native-development-v1'
sys.path.insert(0,str(SOURCE))
from tools import hia_selfhost_process_owner as owner
from tools.qualify_hia_bounded_read import owned_step,environment
from tools.hia_bounded_read_checks.source_common import snapshot,wire
from tools.build_hia_source_build import _named_source_request,_compiled_sources
META=json.loads((ROOT/'source-manifest.json').read_bytes())
ROWS=[dict(row,size=row['bytes']) for row in META['files']]
SEED=Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/depot/201fd124d0c6fc80cb9ad97816e4f69cbc1ea669462b3f86d168566f57817f7e/hia-source-build')
COMPILER=Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/cold/qualification/base/B3.flat')
def capture(path):
 rows=snapshot(SOURCE,ROWS);path.write_bytes(wire(rows))
 return {r['path']:{k:r[k] for k in ['mode','bytes','sha256','git_blob_sha1','identity']} for r in rows}
def state():
 assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
 return subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()
def native(folder,operation,request):
 p=subprocess.run([str(SEED),operation],input=request,capture_output=True,env={'PATH':''},timeout=180)
 for suffix,raw in [('request',request),('stdout',p.stdout),('stderr',p.stderr)]:
  (folder/(operation+'.'+suffix)).write_bytes(raw)
 (folder/(operation+'.terminal.json')).write_bytes(wire({'returncode':p.returncode,'timeout':180}))
 assert p.returncode==0 and p.stderr==b'',(operation,p.returncode,p.stderr)
 return p.stdout
def kit(name,program,compiler_raw):
 folder=OUT/'work'/name;folder.mkdir(mode=0o700)
 sources={'source_build_policy.hepta':(SOURCE/'examples/hia_bootstrap'/program).read_bytes(),
          'selfhost.hepta':(SOURCE/'examples/hia_bootstrap/selfhost.hepta').read_bytes(),
          'source_build_packer.hepta':(SOURCE/'examples/hia_bootstrap/source_build_packer.hepta').read_bytes()}
 raw=native(folder,'sources',_named_source_request(sources))
 images=_compiled_sources(raw,sources)
 assert images['selfhost.hepta']==compiler_raw
 executable=native(folder,'pack',raw)
 assert executable[:4]==b'\x7fELF'
 path=folder/'owner';path.write_bytes(executable);path.chmod(0o500)
 return path
def ids(suite):
 for item in suite:
  if isinstance(item,unittest.TestSuite):yield from ids(item)
  else:yield item.id()
def worker():
 work=OUT/'work';work.mkdir(mode=0o700)
 report={'schema':'hepta.hia.actual-helper-catalog-development.v1','status':'HOLD','source_head':META['head'],'scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','errors':[],'whole_product_qualified':False,'production_activated':False}
 initial=None;seed=None;compiler=None;started=time.monotonic()
 try:
  assert state()==META['head']=='7f55bc13dff87611608d984e4bcada27a2c5f163'
  initial=capture(work/'physical-source-initial.json')
  seed=SEED.read_bytes();compiler=COMPILER.read_bytes()
  assert len(seed)==813129 and hashlib.sha256(seed).hexdigest()=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
  assert len(compiler)==641344 and hashlib.sha256(compiler).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
  planner=kit('planner','source_release_stage_plan.hepta',compiler)
  manifest=kit('manifest-owner','source_helper_manifest.hepta',compiler)
  os.environ.update(HIA_TEST_RELEASE_STAGE_PLANNER=str(planner),HIA_TEST_HELPER_MANIFEST_OWNER=str(manifest),
                    HIA_TEST_NATIVE_SOURCE_SEED=str(SEED),HIA_TEST_HELPER_EVIDENCE=str(work/'extension-native-originals'))
  modules=['tests.test_hia_release_stage_recipes','tests.test_hia_release_stage_plan','tests.test_hia_release_member_check','tests.test_hia_helper_catalog_native']
  suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
  case_ids=list(ids(suite));(work/'all-original-and-extension-case-ids.json').write_bytes(wire(case_ids))
  assert len(case_ids)==len(set(case_ids))
  with (work/'unittest.stderr').open('w') as stream:
   result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
  report.update(tests_expected=len(case_ids),tests_run=result.testsRun,failures=[(t.id(),e) for t,e in result.failures],test_errors=[(t.id(),e) for t,e in result.errors],skips=[(t.id(),e) for t,e in result.skipped])
  assert result.testsRun==len(case_ids) and not result.skipped and result.wasSuccessful()
  report['status']='ORIGINAL_AND_EXTENDED_HELPER_NATIVE_PASS'
 except BaseException as exc:report['errors'].append({'type':type(exc).__name__,'text':str(exc),'traceback':traceback.format_exc()})
 finally:
  try:
   terminal=capture(work/'physical-source-terminal.json')
   report.update(source_initial_terminal_identical=terminal==initial,seed_initial_terminal_identical=seed==SEED.read_bytes(),compiler_initial_terminal_identical=compiler==COMPILER.read_bytes(),terminal_head=state())
   if not (terminal==initial and seed==SEED.read_bytes() and compiler==COMPILER.read_bytes() and state()==META['head']):report['status']='HOLD'
  except BaseException:report['status']='HOLD';report['errors'].append({'phase':'terminal','traceback':traceback.format_exc()})
  report['wall_seconds']=time.monotonic()-started;(work/'report.json').write_bytes(wire(report))
  print(json.dumps(report),flush=True)
 return 0 if report['status']=='ORIGINAL_AND_EXTENDED_HELPER_NATIVE_PASS' else 1
if '--worker' in sys.argv:raise SystemExit(worker())
OUT.mkdir(mode=0o700)
final={'schema':'hepta.hia.actual-helper-catalog-owned-run.v1','status':'HOLD','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','processes':[],'errors':[],'driver_outer_seconds':180,'cleanup_seconds':3,'original_native_call_seconds':30,'original_compile_call_seconds':180,'whole_product_qualified':False}
try:
 owned_step(owner,OUT,final,'native-gates',[sys.executable,'-B',str(Path(__file__).resolve()),'--worker'],SOURCE,environment(),180)
 report=json.loads((OUT/'work/report.json').read_bytes())
 assert report['status']=='ORIGINAL_AND_EXTENDED_HELPER_NATIVE_PASS'
 final['status']=report['status']
except BaseException:final['errors'].append({'traceback':traceback.format_exc()})
(OUT/'acceptance.json').write_bytes(wire(final));print(json.dumps({'status':final['status'],'errors':final['errors']}),flush=True)
raise SystemExit(0 if final['status']=='ORIGINAL_AND_EXTENDED_HELPER_NATIVE_PASS' else 1)
