from pathlib import Path
import sys,json,hashlib,subprocess,traceback,time
root=Path('/home/qian-qi/hia-helper-catalog-native-20261127-2ac5');source=root/'source';out=root/'compiler-diagnostic-v1';out.mkdir(mode=0o700)
sys.path.insert(0,str(source))
from tools.qualify_hia_selfhost import compile_stage
compiler=Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/cold/qualification/base/B3.flat')
assert hashlib.sha256(compiler.read_bytes()).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert head=='7f55bc13dff87611608d984e4bcada27a2c5f163'
before={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in ['examples/hia_bootstrap/source_release_stage_plan.hepta','tests/fixtures/hia_helper_catalog_original_v1/source_release_stage_plan.hepta.txt','examples/hia_bootstrap/source_helper_manifest.hepta','tests/fixtures/hia_helper_catalog_original_v1/source_helper_manifest.hepta.txt']}
rows=[]
for name,path in [('original-stage','tests/fixtures/hia_helper_catalog_original_v1/source_release_stage_plan.hepta.txt'),('current-stage','examples/hia_bootstrap/source_release_stage_plan.hepta'),('current-helper','examples/hia_bootstrap/source_helper_manifest.hepta')]:
 folder=out/name;folder.mkdir(mode=0o700);started=time.monotonic()
 try:
  image,receipt=compile_stage(folder,name,compiler,(source/path).read_bytes())
  row={'name':name,'image_bytes':image.stat().st_size,'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'receipt':receipt}
 except BaseException as exc:row={'name':name,'error':str(exc),'traceback':traceback.format_exc()}
 row['seconds']=time.monotonic()-started;rows.append(row);print(json.dumps(row),flush=True)
assert before=={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in before}
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
(out/'terminal.json').write_text(json.dumps({'status':'DIAGNOSTICS_COMPLETE','source_unchanged':True,'cases':rows},indent=2)+'\n')
