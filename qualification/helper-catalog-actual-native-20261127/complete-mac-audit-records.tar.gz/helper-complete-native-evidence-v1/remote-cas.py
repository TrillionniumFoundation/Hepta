from pathlib import Path
import tarfile,io,json,hashlib,time
out=Path('/home/qian-qi/hia-helper-complete-development-evidence-20261127-2ac5');manifest=json.loads((out/'manifest.json').read_bytes())
chunk_bytes=32768;blobs={};entries=[]
with tarfile.open(out/'complete-native-originals.tar.gz','r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(manifest['entries'])
 for m,row in zip(members,manifest['entries']):
  assert m.name.rstrip('/')==row['archive_path'].rstrip('/')
  r=dict(row)
  if row['kind']=='file':
   raw=tf.extractfile(m).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
   parts=[]
   for at in range(0,len(raw),chunk_bytes):
    part=raw[at:at+chunk_bytes];digest=hashlib.sha256(part).hexdigest()
    if digest in blobs:assert blobs[digest]==part
    else:blobs[digest]=part
    parts.append(dict(sha256=digest,bytes=len(part)))
   r['chunks']=parts
  entries.append(r)
complete=dict(schema='hepta.hia.full-file-chunk-custody.v1',chunk_bytes=chunk_bytes,entries=entries,excluded_reconstructible_inputs=manifest['excluded_reconstructible_inputs'],full_original_archive_sha256=hashlib.sha256((out/'complete-native-originals.tar.gz').read_bytes()).hexdigest(),whole_file_sha256_required=True,expanded_files_removed=False)
raw_manifest=(json.dumps(complete,sort_keys=True,indent=2)+'\n').encode()
(out/'chunk-manifest.json').write_bytes(raw_manifest)
archive=out/'complete-native-cas.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6) as tf:
 for name,raw in [('manifest.json',raw_manifest),*((('blobs/'+key),blobs[key]) for key in sorted(blobs))]:
  item=tarfile.TarInfo(name);item.mode=0o400;item.size=len(raw);item.mtime=0;tf.addfile(item,io.BytesIO(raw))
del blobs
with tarfile.open(archive,'r:gz') as tf:
 observed={}
 for member in tf:
  raw=tf.extractfile(member).read()
  if member.name=='manifest.json':assert raw==raw_manifest;continue
  digest=member.name.removeprefix('blobs/');assert hashlib.sha256(raw).hexdigest()==digest
  observed[digest]=raw
 for row in complete['entries']:
  if row['kind']!='file':continue
  digest=hashlib.sha256();size=0
  for part in row['chunks']:
   raw=observed[part['sha256']];assert len(raw)==part['bytes'];digest.update(raw);size+=len(raw)
  assert size==row['bytes'] and digest.hexdigest()==row['sha256']
result=dict(status='EVERY_COMPLETE_FILE_RECONSTRUCTED_AND_SHA256_VERIFIED',archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(entries),files=sum(r['kind']=='file' for r in entries),unique_chunks=len(observed),unique_uncompressed_chunk_bytes=sum(len(raw) for raw in observed.values()),original_complete_file_bytes=sum(r.get('bytes',0) for r in entries),physical_source_preservation_in_git=complete['excluded_reconstructible_inputs'],whole_file_not_excerpt_custody=True,expanded_files_removed=False)
(out/'cas-readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='physical_source_preservation_in_git'}),flush=True)
