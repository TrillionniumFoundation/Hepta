from pathlib import Path
import os,sys,json,hashlib,time,traceback,subprocess,types,stat
R=Path('/home/qq/hia-worker-protocols-current-native-20261128-2ac5');S=R/'source';O=R/'author-native-domain-v1'
os.chdir(S);sys.path.insert(0,str(S))
assert not O.exists();O.mkdir(mode=0o700)
started=time.monotonic()
record={'scope':'NATIVE_SOURCE_AUTHORING_ONLY_NOT_COLD_OR_INSTALLATION','native_execution':False,
        'author_input_head':'ae78216fd1c50fea1af71549814bc8af1c0580e0','host':'ai395','success':False,'steps':[]}
def save():
 (O/'report.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
def command(name,args,timeout=180):
 start=time.monotonic()
 p=subprocess.run(args,cwd=S,capture_output=True,timeout=timeout)
 (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
 row={'name':name,'argv':args,'returncode':p.returncode,'seconds':time.monotonic()-start,
      'stdout_bytes':len(p.stdout),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),
      'stderr_bytes':len(p.stderr),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 record['steps'].append(row);save();print(json.dumps(row),flush=True)
 if p.returncode:raise ValueError('author command failed: '+name)
 return p.stdout
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==record['author_input_head']
 assert not subprocess.check_output(['git','status','--porcelain'])
 before={p.as_posix():hashlib.sha256((S/p).read_bytes()).hexdigest()
         for p in (Path(n.decode()) for n in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if n)
         if (S/p).is_file()}
 command('source-eleven-before',[sys.executable,'-B','-m','unittest','-v','tests.test_hia_worker_protocol_domains'])
 from tools import generate_hia_worker_continuation_pack as continuation
 oldraw=(R/'transport/worker-continuation-pack-original-author.py').read_bytes()
 prior=types.ModuleType('worker_original_continuation_pack_author');prior.__file__=str(S/'tools/generate_hia_worker_continuation_pack.py')
 sys.modules[prior.__name__]=prior
 try:
  exec(compile(oldraw,prior.__file__,'exec'),prior.__dict__)
  old_output=prior.render();new_output=continuation.render('v1')
  assert old_output==new_output
 finally:sys.modules.pop(prior.__name__,None)
 record['original_v1_packer']={'author_bytes':len(oldraw),'author_sha256':hashlib.sha256(oldraw).hexdigest(),
      'generated_bytes':len(old_output[0].encode()),'generated_sha256':hashlib.sha256(old_output[0].encode()).hexdigest(),
      'complete_output_and_stats_equal':True}
 save();print('LEGACY_PACKER_ENTIRE_NATIVE_AUTHOR_BYTE_EQUAL',flush=True)
 from tools.hia_native_worker_source_authority import (load_native_source_authority,checked_paths,SOURCE_SUFFIXES,DATA_SUFFIXES,
      CONTINUATION_RUNTIME,CONTINUATION_RUNTIME_V2,SCHEMA)
 from hepta.hia_agent_contract import NATIVE_SOURCE_FILES
 from tools.hia_worker_protocol_model import worker_model
 from tools.generate_hia_worker_install_recipes import recipes
 from tools.generate_hia_worker_protocol_sources import generated_files
 from tools.hia_worker_protocols import PROTOCOLS
 paths=set(load_native_source_authority(S/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json'))
 paths.update(p for p in NATIVE_SOURCE_FILES if Path(p).suffix in SOURCE_SUFFIXES|DATA_SUFFIXES)
 paths.update(CONTINUATION_RUNTIME+CONTINUATION_RUNTIME_V2)
 for number in PROTOCOLS:
  model=worker_model(S,protocol=number)
  paths.update(h['source'] for h in model['helpers'])
  paths.update(f['abi_source'] for f in model['families'])
  paths.update(u['source'] for f in model['families'] for u in f['units'])
  paths.update(model['continuation_resources'])
  for f in model['families']:paths.update(f.get('continuation_resources',()))
  for r in recipes(protocol=number).values():
   for op,_,_,payload in r.nodes:
    if op==1:
     name=payload.decode('ascii')
     if name=='Makefile' or Path(name).suffix in SOURCE_SUFFIXES|DATA_SUFFIXES:paths.add(name)
 authority=O/'development-native-authority.json'
 iterations=[]
 for iteration in range(4):
  selected=checked_paths(sorted(paths))
  authority.write_text(json.dumps({'schema':SCHEMA,'paths':list(selected)},sort_keys=True,indent=2)+'\n')
  start=time.monotonic();products,stats=generated_files(authority)
  row={'iteration':iteration,'paths':len(paths),'products':len(products),'seconds':time.monotonic()-start,'protocols':stats}
  iterations.append(row);print(json.dumps(row),flush=True)
  extra=set(products)-paths
  if not extra:break
  paths.update(extra)
 else:raise ValueError('Worker source authority did not close')
 for name,raw in products.items():
  p=S/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 assert all((S/name).is_file() for name in paths), sorted(name for name in paths if not (S/name).is_file())
 record['authority']={'paths':len(paths),'sha256':hashlib.sha256(authority.read_bytes()).hexdigest(),
    'scope':'EXPLICIT_DEVELOPMENT_NATIVE_PATH_CLOSURE_NOT_A_COLD_RECEIPT','iterations':iterations}
 record['products']={name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(products.items())}
 save()
 command('identity-author',[sys.executable,'-B','-m','tools.generate_hia_worker_install_identity','--native-source-authority',str(authority)])
 command('protocols-complete-check',[sys.executable,'-B','-m','tools.generate_hia_worker_protocol_sources','--native-source-authority',str(authority),'--check'])
 command('identity-complete-check',[sys.executable,'-B','-m','tools.generate_hia_worker_install_identity','--native-source-authority',str(authority),'--check'])
 command('source-eleven-after',[sys.executable,'-B','-m','unittest','-v','tests.test_hia_worker_protocol_domains'])
 changed=[]
 for row in subprocess.check_output(['git','status','--porcelain','-z']).split(b'\0'):
  if row:changed.append(row[3:].decode())
 allowed=set(products)|{'examples/hia_bootstrap/source_worker_install_identity.hepta',
    'examples/hia_bootstrap/worker_install_identity_paths.hiastd'}
 assert set(changed)<=allowed,(set(changed)-allowed)
 for name,pin in before.items():
  if name not in allowed:assert hashlib.sha256((S/name).read_bytes()).hexdigest()==pin,name
 record['changed']={name:{'bytes':(S/name).stat().st_size,'sha256':hashlib.sha256((S/name).read_bytes()).hexdigest(),
                             'mode':oct(stat.S_IMODE((S/name).stat().st_mode))} for name in sorted(changed)}
 record.update(success=True,seconds=time.monotonic()-started,non_generated_inputs_unchanged=True)
 save();print(json.dumps({'success':True,'products':len(products),'paths':len(paths),'changed':len(changed),'seconds':record['seconds']}),flush=True)
except BaseException as exc:
 record.update(error=traceback.format_exc(),seconds=time.monotonic()-started)
 if getattr(exc,'stderr',None):
  (O/'exception.stderr').write_bytes(exc.stderr if isinstance(exc.stderr,bytes) else str(exc.stderr).encode())
 save();traceback.print_exc();raise
