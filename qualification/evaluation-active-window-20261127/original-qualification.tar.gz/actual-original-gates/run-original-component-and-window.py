import ast,json,sys,unittest
from pathlib import Path
old=ast.parse(Path(sys.argv[1]).read_bytes());planned_old=sorted('tests.test_hia_evaluation_native.'+cls.name+'.'+m.name for cls in old.body if isinstance(cls,ast.ClassDef) for m in cls.body if isinstance(m,(ast.FunctionDef,ast.AsyncFunctionDef)) and m.name.startswith('test_'))
mods=('tests.test_hia_evaluation_native','tests.test_hia_evaluation_wall_window')
loader=unittest.TestLoader();parts=[loader.loadTestsFromName(x) for x in mods]
def ids(s):
 out=[]
 for x in s:
  out.extend(ids(x) if isinstance(x,unittest.TestSuite) else [x.id()])
 return out
assert len(planned_old)==10 and sorted(ids(parts[0]))==planned_old
counts=[x.countTestCases() for x in parts];assert counts==[10,8],counts
planned=ids(unittest.TestSuite(parts))
suite=unittest.TestSuite(parts);result=unittest.TextTestRunner(verbosity=2).run(suite)
row={'methods':result.testsRun,'original_component_methods':10,'new_window_controls':8,'planned_ids':planned,'original_complete_methods_unchanged':True,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'unexpected_successes':len(result.unexpectedSuccesses),'expected_failures':len(result.expectedFailures),'passed':result.wasSuccessful() and result.testsRun==18 and not result.skipped and not result.expectedFailures}
Path(sys.argv[2]).write_text(json.dumps(row,indent=2)+'\n')
raise SystemExit(0 if row['passed'] else 1)
