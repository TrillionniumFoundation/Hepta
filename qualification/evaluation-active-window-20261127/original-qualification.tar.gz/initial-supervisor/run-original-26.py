import json,sys,unittest
from pathlib import Path
mods=('tests.test_hia_evaluation_native','tests.test_hia_evaluation_wall_window')
loader=unittest.TestLoader();parts=[loader.loadTestsFromName(x) for x in mods]
counts=[x.countTestCases() for x in parts];assert counts==[18,8],counts
suite=unittest.TestSuite(parts);result=unittest.TextTestRunner(verbosity=2).run(suite)
row={'methods':result.testsRun,'original_methods':18,'new_window_methods':8,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'unexpected_successes':len(result.unexpectedSuccesses),'expected_failures':len(result.expectedFailures),'passed':result.wasSuccessful() and result.testsRun==26 and not result.skipped and not result.expectedFailures}
Path(sys.argv[1]).write_text(json.dumps(row,indent=2)+'\n')
raise SystemExit(0 if row['passed'] else 1)
