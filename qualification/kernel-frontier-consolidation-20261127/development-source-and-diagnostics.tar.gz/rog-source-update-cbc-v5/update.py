EXPECTED_SHA='779f66106eb5e110d69f3fdff8fc8f2457273aa185eb977d6e3ce3d7a44b4d1c'
from pathlib import Path
import json,hashlib,subprocess,os,time
R=Path("/home/qian-qi/hia-kernel-frontier-integration-20261127-2ac5");S=R/"source";O=R/"source-update-cbc-v5";O.mkdir(mode=0o700)
HEAD="cbc86c751a931f8b5eaed72a463d793e05827b71";OLD="6e2520bcf4fb71e25fa4e75728318084b4cfb609";TREE="c69b9f7812290a748389f92be891b757f323b339"
def g(*a):return subprocess.run(["git","-C",str(S),*a],capture_output=True,check=True).stdout
assert g("rev-parse","HEAD").decode().strip()==OLD and not g("status","--porcelain")
assert json.loads((R/"linux-kernel-gates-v4/report.json").read_bytes())["clean"] is True
bundle=R/"candidate-cbc-incremental-v5.bundle";raw=bundle.read_bytes()
assert hashlib.sha256(raw).hexdigest()==EXPECTED_SHA
p=subprocess.run(["git","-C",str(S),"bundle","verify",str(bundle)],capture_output=True);(O/"bundle-verify.stdout").write_bytes(p.stdout);(O/"bundle-verify.stderr").write_bytes(p.stderr);assert p.returncode==0
g("bundle","unbundle",str(bundle))
g("checkout","--detach",HEAD)
assert g("rev-parse","HEAD").decode().strip()==HEAD and g("rev-parse","HEAD^{tree}").decode().strip()==TREE
files=[]
for entry in g("ls-tree","-r","-z",HEAD).split(b"\0"):
 if not entry:continue
 info,name=entry.split(b"\t",1);mode,kind,oid=info.split();assert kind==b"blob"
 p=S/os.fsdecode(name);st=p.lstat();assert p.is_file() and not p.is_symlink()
 b=p.read_bytes();actual=hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
 assert actual==oid.decode(),str(p)
 assert bool(st.st_mode&0o111)==(mode==b"100755")
 files.append({"path":os.fsdecode(name),"mode":mode.decode(),"git_blob":actual,"bytes":len(b)})
assert not g("status","--porcelain")
report={"head":HEAD,"tree":TREE,"old_head":OLD,"files":files,"source_bytes":sum(f["bytes"] for f in files),"clean":True,"bundle_sha256":EXPECTED_SHA}
(R/"complete-source-materialization-cbc-v5.json").write_text(json.dumps(report,sort_keys=True)+"\n")
print(json.dumps({k:v for k,v in report.items() if k!="files"}),flush=True)
