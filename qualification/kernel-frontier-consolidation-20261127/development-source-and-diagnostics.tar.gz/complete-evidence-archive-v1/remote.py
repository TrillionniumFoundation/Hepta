from pathlib import Path
import os,stat,json,hashlib,tarfile,io,time,subprocess
R=Path("/home/qian-qi/hia-kernel-frontier-integration-20261127-2ac5")
O=Path("/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-kernel-frontier-integration-20261127-2ac5/closed-evidence-v1")
O.mkdir(mode=0o700,parents=True)
assert json.loads((R/"linux-kernel-gates-v5/report.json").read_bytes())["status"]=="PASS"
assert not Path("/proc/4169563").exists()
def digest_file(path):
 h=hashlib.sha256()
 with path.open("rb") as stream:
  for part in iter(lambda:stream.read(1048576),b""):h.update(part)
 return h.hexdigest()
files=[];physical={}
for base,dirs,names in os.walk(R):
 if Path(base)==R:dirs[:]=[x for x in dirs if x!="source"]
 dirs.sort()
 for name in sorted(names):
  p=Path(base)/name;st=p.lstat()
  assert stat.S_ISREG(st.st_mode) and not p.is_symlink(),str(p)
  rel=p.relative_to(R).as_posix();row={"path":rel,"bytes":st.st_size,"mode":stat.S_IMODE(st.st_mode),"sha256":digest_file(p)}
  after=p.stat();assert (st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),rel
  files.append(row);physical[rel]=(st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
head=subprocess.check_output(["git","-C",str(R/"source"),"rev-parse","HEAD"],text=True).strip()
assert head=="cbc86c751a931f8b5eaed72a463d793e05827b71"
assert not subprocess.check_output(["git","-C",str(R/"source"),"status","--porcelain"])
unique={}
for row in files:unique.setdefault(row["sha256"],row)
manifest={"schema":"hia.kernel.complete-isolated-frontier-evidence.v1","root":str(R),"head":head,"tree":"c69b9f7812290a748389f92be891b757f323b339","source_worktree_in_git":True,"files":files,"file_count":len(files),"regular_bytes":sum(x["bytes"] for x in files),"unique_blobs":len(unique)}
raw=(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode()
(O/"manifest.json").write_bytes(raw)
archive=O/"complete-evidence-cas.tar.gz"
with tarfile.open(archive,"w:gz",compresslevel=6) as tf:
 info=tarfile.TarInfo("manifest.json");info.size=len(raw);info.mode=0o600;tf.addfile(info,io.BytesIO(raw))
 for sha,row in sorted(unique.items()):
  info=tarfile.TarInfo("blobs/"+sha);info.size=row["bytes"];info.mode=0o600
  with (R/row["path"]).open("rb") as stream:tf.addfile(info,stream)
seen=set()
with tarfile.open(archive,"r:gz") as tf:
 for member in tf:
  if member.name=="manifest.json":
   assert tf.extractfile(member).read()==raw;continue
  sha=member.name.removeprefix("blobs/");assert sha in unique and sha not in seen
  h=hashlib.sha256();total=0;stream=tf.extractfile(member)
  for part in iter(lambda:stream.read(1048576),b""):h.update(part);total+=len(part)
  assert total==unique[sha]["bytes"] and h.hexdigest()==sha;seen.add(sha)
assert seen==set(unique)
core=[row for row in files if (row["path"].endswith((".json",".log",".stdout",".stderr",".txt",".py")) or row["path"].split("/")[-1] in ("stdout","stderr")) and row["bytes"]<=5<<20]
core_archive=O/"complete-core-logs.tar.gz"
with tarfile.open(core_archive,"w:gz",compresslevel=6) as tf:
 for row in core:
  info=tarfile.TarInfo(row["path"]);info.size=row["bytes"];info.mode=row["mode"]
  with (R/row["path"]).open("rb") as stream:tf.addfile(info,stream)
core_map={x["path"]:x for x in core};seen_core=set()
with tarfile.open(core_archive,"r:gz") as tf:
 for member in tf:
  data=tf.extractfile(member).read();row=core_map[member.name]
  assert len(data)==row["bytes"] and hashlib.sha256(data).hexdigest()==row["sha256"] and member.mode==row["mode"]
  seen_core.add(member.name)
assert seen_core==set(core_map)
for row in files:
 p=R/row["path"];st=p.stat()
 assert (st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==physical[row["path"]]
 assert stat.S_IMODE(st.st_mode)==row["mode"] and digest_file(p)==row["sha256"]
result={"schema":"hia.kernel.isolated-frontier-qualification.v1","head":head,"tree":manifest["tree"],"component_only":True,"whole_stack_qualified":False,
"all_original_failures_and_pass_included":True,"all_originals_reread":True,"all_archive_members_verified":True,
"file_count":len(files),"regular_bytes":manifest["regular_bytes"],"unique_blobs":len(unique),
"full_archive":{"path":str(archive),"bytes":archive.stat().st_size,"sha256":digest_file(archive)},
"core_archive":{"path":str(core_archive),"members":len(core),"bytes":core_archive.stat().st_size,"sha256":digest_file(core_archive)},
"manifest":{"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()},
"report":json.loads((R/"linux-kernel-gates-v5/report.json").read_bytes())}
(O/"qualification.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="report"}),flush=True)
