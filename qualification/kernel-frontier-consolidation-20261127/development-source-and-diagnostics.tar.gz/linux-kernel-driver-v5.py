from pathlib import Path
import subprocess,os,json,hashlib,time,signal,re,sys
R=Path("/home/qian-qi/hia-kernel-frontier-integration-20261127-2ac5");S=R/"source";O=R/"linux-kernel-gates-v5"
O.mkdir(mode=0o700);tmp=O/"tmp";tmp.mkdir(mode=0o700)
PY="/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python"
E={k:v for k,v in os.environ.items() if not k.startswith("HEPTA_HIA_")}
E.update(PYTHONDONTWRITEBYTECODE="1",TMPDIR=str(tmp),PYTHONUNBUFFERED="1",GIT_NO_LAZY_FETCH="1",GIT_TERMINAL_PROMPT="0")
HEAD="cbc86c751a931f8b5eaed72a463d793e05827b71"
def g(*a):return subprocess.run(["git","-C",str(S),*a],env=E,capture_output=True,check=True).stdout
assert g("rev-parse","HEAD").decode().strip()==HEAD
assert not g("status","--porcelain")
before=json.loads((R/"complete-source-materialization-cbc-v5.json").read_text())
assert before["head"]==HEAD
(O/"intent.json").write_text(json.dumps({"pid":os.getpid(),"head":HEAD,"tree":before["tree"],"source_files":len(before["files"]),"started_unix":time.time(),"workflow_budget_seconds":1200,"whole_stack_qualified":False},sort_keys=True)+"\n")
print("KERNEL_DRIVER_BEGIN",os.getpid(),HEAD,flush=True)
rows=[]
def run(label,args,timeout,unit=False):
 out=O/(label+".stdout");err=O/(label+".stderr")
 started=time.monotonic();timed=False
 with out.open("wb") as stdout,err.open("wb") as stderr:
  p=subprocess.Popen(args,cwd=S,env=E,stdout=stdout,stderr=stderr,start_new_session=True)
  (O/(label+".intent.json")).write_text(json.dumps({"argv":args,"pid":p.pid,"timeout":timeout,"started_unix":time.time()},sort_keys=True)+"\n")
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=3)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 raw=err.read_bytes()+out.read_bytes()
 skipped=bool(re.search(rb"skipped[= ]|\.\.\. skipped",raw)) if unit else False
 row={"label":label,"argv":args,"returncode":rc,"timed_out":timed,"seconds":time.monotonic()-started,"stdout":{"bytes":out.stat().st_size,"sha256":hashlib.sha256(out.read_bytes()).hexdigest()},"stderr":{"bytes":err.stat().st_size,"sha256":hashlib.sha256(err.read_bytes()).hexdigest()},"skipped":skipped,"passed":rc==0 and not timed and not skipped}
 rows.append(row);(O/(label+".result.json")).write_text(json.dumps(row,sort_keys=True)+"\n")
 (O/"progress.json").write_text(json.dumps(rows,indent=2)+"\n");print("GATE_TERMINAL",json.dumps(row,sort_keys=True),flush=True)
 if not row["passed"]:print(raw[-6000:].decode(errors="replace"),flush=True)
 return row["passed"]
units=run("core-and-source",[PY,"-B","-m","unittest",*["tests.test_hia_kernel_fence_core","tests.test_hia_kernel_invlpg_core","tests.test_hia_kernel_privilege_shape_guard","tests.test_hia_kernel_candidate_authoring","tests.test_hia_kernel_core_version_isolation","tests.test_hia_kernel_qemu_shutdown_policy","tests.test_hia_kernel_instruction_oracle","tests.test_hia_kernel_hardware_oracle_history","tests.test_hia_core_emitter_native.CoreEmitterSourceTests.test_complete_original_Emitter_AST_and_constructor_transport","tests.test_hia_instruction_policy_native.InstructionPolicySourceTests.test_full_catalog_schema_and_groups_not_compiler_opcode_subset","tests.test_hia_program_shape_native.ProgramShapeSourceTests.test_complete_closed_catalog_and_version_feature_correspondence","tests.test_hia_core_lowering_native.CoreLoweringSourceTests.test_complete_original_Function_and_five_helpers_are_independent","tests.test_hia_machine_encoding_native.MachineEncodingSourceTests.test_retained_reference_methods_are_unchanged","tests.test_hia_machine_state_native.MachineStateSourceTests.test_complete_original_Code_AST_and_fixture_bytes_are_retained","tests.test_hia_machine_instructions_native.MachineInstructionsSourceTests.test_complete_original_classes_and_fixture_bytes_are_retained"],"-v"],600,True)
isa=run("independent-isa-controls",[PY,"-B","-m","unittest",*["tests.test_hia_machine_x64_privileged","tests.test_hia_x86_kernel_descriptor","tests.test_hia_x86_atomic_cmpxchg","tests.test_hia_x86_atomic_runtime","tests.test_hia_x86_privileged_effect_lowering","tests.test_hia_x86_kernel_privilege_staging","tests.test_hia_x86_kernel_interrupt_staging","tests.test_hia_x86_kernel_atomic_staging","tests.test_hia_x86_kernel_control_io_staging","tests.test_hia_x86_kernel_msr_interrupt_staging","tests.test_hia_x86_kernel_syscall_smap_staging","tests.test_hia_x86_kernel_tlb_effects_staging"],"-v"],600,True)
sha=run("sha256-current-word-source",[PY,"-B","-m","unittest","tests.test_hia_sha256_stream_native.Sha256StreamSourceTests","-v"],600,True)
qemu=run("independent-privileged-qemu",[PY,"-B","tests/x86_privileged_qemu/run_hardware.py","--report",str(O/"independent-privileged-qemu-report.json")],600)
old_qemu=json.loads((R/"linux-kernel-gates-v1/independent-privileged-qemu-report.json").read_bytes())
new_qemu=json.loads((O/"independent-privileged-qemu-report.json").read_bytes())
keys=("case","effect_sha256","descriptor_stage_sha256","ltr_stage_sha256","image_sha256","elf64_sha256","test_assembly_sha256","linker_sha256")
qemu_same=([{k:r[k] for k in keys} for r in old_qemu["cases"]]==[{k:r[k] for k in keys} for r in new_qemu["cases"]])
(O/"same-guest-image-comparison.json").write_text(json.dumps({"same_original_case_order_and_all_guest_image_bytes":qemu_same,"old_report_sha256":hashlib.sha256((R/"linux-kernel-gates-v1/independent-privileged-qemu-report.json").read_bytes()).hexdigest(),"new_report_sha256":hashlib.sha256((O/"independent-privileged-qemu-report.json").read_bytes()).hexdigest(),"comparison_fields":keys},sort_keys=True)+"\n")
hosted_qemu=run("core-invlpg-qemu",[PY,"-B","-m","tests.test_hia_kernel_invlpg_qemu"],900)
workflow_started=time.monotonic()
native=run("kernel-native-bootstrap",[PY,"-B","tools/qualify_hia_kernel_selfhost_invlpg.py","--output",str(O/"native")],1200)
if native:
 for name in ["test_hia_kernel_selfhost_invlpg_qemu","test_hia_kernel_tr_qemu","test_hia_kernel_iretq_user_qemu","test_hia_kernel_frame_qemu","test_hia_kernel_irq_qemu"]:
  remaining=1200-(time.monotonic()-workflow_started)
  if remaining<=0:raise RuntimeError("original kernel workflow budget exhausted")
  if not run(name,[PY,"-B","-m","tests."+name,"--output",str(O/"native")],remaining):
   break
source_same=True
for item in before["files"]:
 p=S/item["path"];raw=p.read_bytes()
 actual=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
 if actual!=item["git_blob"] or bool(p.stat().st_mode&0o111)!=(item["mode"]=="100755"):source_same=False
assert g("rev-parse","HEAD").decode().strip()==HEAD
clean=not g("status","--porcelain")
result={"head":HEAD,"tree":before["tree"],"source_same":source_same,"clean":clean,"rows":rows,"complete_kernel_workflow":len(rows)==11,"status":"PASS" if len(rows)==11 and all(x["passed"] for x in rows) and source_same and clean and qemu_same else "FAIL","same_qemu_guest_images":qemu_same,"whole_stack_qualified":False}
(O/"report.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print("KERNEL_DRIVER_TERMINAL",json.dumps({k:v for k,v in result.items() if k!="rows"},sort_keys=True),flush=True)
raise SystemExit(0 if result["status"]=="PASS" else 1)
