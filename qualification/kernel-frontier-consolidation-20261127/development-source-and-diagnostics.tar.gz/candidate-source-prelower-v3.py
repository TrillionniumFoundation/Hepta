
def compile(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    phase = 0
    n = length(w)
    if n < 2097152:
        return 4294967294
    if length(s) > 1048576:
        return 4294967295
    if length(o) > 1048576:
        return 4294967294
    fill_range(w, 1010784, 38400, 0)
    fill_range(w, KBASE, 2048, 0)
    put(w, 432, 1)
    while phase < 3:
        fill_range(w, 0, 256, 0)
        put(w, 248, 4)
        put(w, 264, 0)
        put(w, 272, 0)
        put(w, 344, 0)
        put(w, 360, 0)
        put(w, 368, 0)
        put(w, 48, phase)
        next_token(s, w)
        expect(s, w, @hia-asm.v1@)
        schema = get(w, 8)
        if schema == @hepta.hia.program.kernel-tlb.v1@ and byte(w, 32) == 0:
            put(w, 200, 1)
        else:
            if schema - @hepta.hia.program.v6@ > 3 or byte(w, 32) != 0:
                fail(w, 67)
                return 4294967295
        put(w, SCHEMA_STATE, schema)
        next_token(s, w)
        if get(w, 32) != 0:
            fail(w, 67)
        identifier(s, w)
        if get(w, 8) == @selfhost_elf@:
            put(w, 232, 1)
            expect(s, w, @selfhost_elf@)
        else:
            if get(w, 8) == @selfhost_exec@:
                put(w, 232, 2)
                expect(s, w, @selfhost_exec@)
            else:
                # A module identifier is a Core label, not a source dispatch
                # key. Only the two explicit historical output profiles above
                # select a different ABI; all other admitted names emit flat.
                next_token(s, w)
        expect(s, w, 10)
        if get(w, 200) == 1 and get(w, 232) != 1:
            return 4294967295
        read_exports(s, w)
        if get(w, 200) == 1 and get(w, 640) != 1:
            return 4294967295
        if get(w, 232) == 1:
            elf_begin(o, w)
        if get(w, 232) == 2:
            cli_begin(o, w)
        if get(w, 640) == 0:
            wrapper(o, w)
        put(w, 240, get(w, 56))
        while get(w, 8) == @fn@ and get(w, 40) == 0:
            parse_function(s, o, w)
        expect(s, w, 0)
        if get(w, 200) >= 2:
            if get(w, 64) != 1 or get(w, 80) != 1 or get(w, 112) != 1 or get(w, 648) != 1:
                fail(w, 65)
        if get(w, 64) == 0:
            fail(w, 1)
        if get(w, 40) != 0:
            return 4294967295
        if phase == 0:
            put(w, 1024, get(w, 64))
            if get(w, 432) == 0:
                kernel_check_calls(w)
                if get(w, 40) != 0:
                    return 4294967295
        validate_exports(s, w)
        if get(w, 40) != 0:
            return 4294967295
        if get(w, 232) == 1:
            chain_drop_helper(o, w)
            if get(w, 640) == 1:
                exports_finish(s, o, w)
            else:
                elf_finish(o, w)
        if get(w, 232) == 2:
            cli_finish(o, w)
        if phase == 1:
            if get(w, 56) > length(o):
                return 4294967294
        if phase == 0 and get(w, 432) == 1:
            put(w, 432, 0)
        else:
            phase = phase + 1
    fix_all(o, w)
    if get(w, 40) != 0:
        return 4294967295
    return get(w, 56)

def parse_function(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    expect(s, w, @fn@)
    separated(w)
    if get(w, 32) != 0:
        fail(w, 49)
    f = read_function_name(s, w, 1)
    adjacent(w)
    if f != get(w, 64) or f >= 192:
        return fail(w, 2)
    put(w, 72, f)
    put(w, 64, f + 1)
    put(w, 384, 0)
    put(w, 392, 0)
    fb = FBASE + f * FSTRIDE
    if get(w, 48) == 0:
        put(w, fb + 8, get(w, 80))
        put(w, fb + 40, 0)
    put(w, 480, 0)
    # Both tables are private to the current function. A name record is
    # vacant when its size is zero; define() writes both SSA type and block
    # origin before they can become live. Clearing their complete extents is
    # equivalent to the former 2048 strided vacancy/type resets and lets the
    # ordinary checked bulk operation emit two REP STOSB sequences.
    fill_range(w, 1137264, 49152, 0)
    fill_range(w, VBASE, 32768, 0)
    # Clear presence for every schema. Only v9 const instructions set it.
    fill_range(w, CONST_FLAGS, 2048, 0)
    count = parse_params(s, w, 1)
    if get(w, 40) != 0:
        return 0
    account_nodes(w, 7 + count * 3)
    expect(s, w, 45)
    adjacent(w)
    expect(s, w, 62)
    expect(s, w, 40)
    rt = read_result_types(s, w)
    if get(w, 48) == 0:
        put(w, fb + 24, count)
        put(w, fb + 32, rt)
    separated(w)
    expect(s, w, @effects@)
    adjacent(w)
    expect(s, w, 40)
    effects = parse_effects(s, w)
    if get(w, 48) == 0:
        put(w, fb + 176, effects)
    separated(w)
    expect(s, w, @entry@)
    adjacent(w)
    expect(s, w, 40)
    adjacent(w)
    discover_blocks(s, w)
    entry_block = expect(s, w, 258)
    if get(w, 48) == 0:
        put(w, fb + 264, entry_block)
    else:
        if entry_block != get(w, fb + 264):
            fail(w, 4)
    adjacent(w)
    expect(s, w, 41)
    read_return_loans(s, w)
    expect(s, w, 10)
    if f == 0 and get(w, 640) == 0:
        if count != 3 or rt != 3 or get(w, fb + 184) != 1:
            fail(w, 5)
        if get(w, fb + 48) != 6 or get(w, fb + 56) != 7 or get(w, fb + 64) != 7:
            fail(w, 5)
    put(w, 96, 0)
    function_start(o, w)
    while get(w, 8) == @block@ and get(w, 40) == 0:
        parse_block(s, o, w)
    expect(s, w, @end@)
    expect(s, w, 10)
    if get(w, 96) == 0:
        fail(w, 6)
    if get(w, 48) == 0:
        put(w, fb + 16, get(w, 96))
        if get(w, 40) == 0 and get(w, 432) == 0:
            check_graph(s, o, w)
    return 0

def parse_params(s:readbuf, w:mutbuf, signature:u64) -> u64:
    expect(s, w, 40)
    count = 0
    v = 0
    t = 0
    base = FBASE + get(w, 72) * FSTRIDE
    while get(w, 8) != 41 and get(w, 40) == 0:
        v = expect(s, w, 256)
        expect(s, w, 58)
        t = read_type(s, w)
        if count >= 16:
            return fail(w, 7)
        if signature == 1:
            if v != count:
                fail(w, 8)
            if get(w, 48) == 0:
                put(w, base + 48 + count * 8, t)
        else:
            define(w, v, t)
            if get(w, 40) != 0:
                return 0
            if get(w, 48) == 0:
                put(w, BBASE + get(w, 88) * BSTRIDE + 32 + count * 16, v)
                put(w, BBASE + get(w, 88) * BSTRIDE + 40 + count * 16, t)
            if get(w, 96) == get(w, base + 264):
                if v != count or t != get(w, base + 48 + count * 8):
                    fail(w, 9)
        count = count + 1
        if get(w, 8) != 41:
            expect(s, w, 44)
            if get(w, 8) == 41:
                fail(w, 10)
    expect(s, w, 41)
    return count

def parse_block(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    # This block-local pending result is separate from the v5 node counter at
    # 248. A self call is admitted only when the next token is its exact ret.
    put(w, 256, 0)
    source_at = get(w, 24)
    expect(s, w, @block@)
    separated(w)
    b = expect(s, w, 258)
    adjacent(w)
    if b != get(w, 96) or b >= 256 or get(w, 80) >= 2048:
        return fail(w, 11)
    put(w, 88, get(w, 80))
    put(w, 80, get(w, 80) + 1)
    bb = BBASE + get(w, 88) * BSTRIDE
    if get(w, 48) == 0:
        put(w, bb, source_at)
        put(w, bb + 16, get(w, 72))
        put(w, bb + 24, 0)
        put(w, bb + 288, 18446744073709551615)
        put(w, bb + 296, 18446744073709551615)
    if get(w, 48) > 0:
        put(w, bb, get(w, 56))
    count = parse_params(s, w, 0)
    account_nodes(w, 4 + count * 3)
    if get(w, 48) == 0:
        put(w, bb + 8, count)
    if b == get(w, FBASE + get(w, 72) * FSTRIDE + 264):
        if count != get(w, FBASE + get(w, 72) * FSTRIDE + 24):
            fail(w, 12)
    if get(w, 40) != 0:
        return 0
    loan_incoming(w, bb, count, b)
    put(w, 96, b + 1)
    expect(s, w, 10)
    while get(w, 40) == 0 and instruction_ahead(s, w) != 0:
        instruction(s, o, w)
    if get(w, 8) == @ret@:
        next_token(s, w)
        adjacent(w)
        return_results(s, o, w)
    else:
        if get(w, 8) == @trap@:
            explicit_trap(s, o, w)
            expect(s, w, 10)
            return 0
        if get(w, 8) == @jump@:
            next_token(s, w)
            edge(s, o, w, 0)
        else:
            expect(s, w, @branch@)
            account_nodes(w, 1)
            separated(w)
            v = expect(s, w, 256)
            if variable(w, v) != 5:
                fail(w, 14)
            load_var(o, w, 0, v, 0)
            emit_bytes(o, w, 567199958344, 5)
            at = get(w, 56)
            emit4(o, w, 0)
            edge(s, o, w, 0)
            if get(w, 48) == 2:
                write4(o, at, get(w, 56) - at - 4)
            edge(s, o, w, 1)
    expect(s, w, 10)
    return 0

def args(s:readbuf, w:mutbuf, is_edge:u64) -> u64:
    expect(s, w, 40)
    n = 0
    v = 0
    t = 0
    j = 0
    while get(w, 8) != 41 and get(w, 40) == 0:
        v = expect(s, w, 256)
        t = variable(w, v)
        if n >= 16:
            return fail(w, 15)
        j = 0
        while j < n:
            if v == get(w, ARGS + j * 8) and ((t >= 7 and t <= 9) or (is_edge == 1 and t == 6)):
                fail(w, 16)
            j = j + 1
        put(w, ARGS + n * 8, v)
        n = n + 1
        if get(w, 8) != 41:
            expect(s, w, 44)
            if get(w, 8) == 41:
                fail(w, 17)
    expect(s, w, 41)
    put(w, 136, n)
    return n

def edge(s:readbuf, o:mutbuf, w:mutbuf, arm:u64) -> u64:
    separated(w)
    b = expect(s, w, 258)
    adjacent(w)
    fbase = FBASE + get(w, 72) * FSTRIDE
    bid = get(w, fbase + 8) + b
    if b == get(w, fbase + 264) or b >= 256 or bid >= 2048:
        return fail(w, 18)
    bb = BBASE + bid * BSTRIDE
    n = args(s, w, 1)
    loan_transfer(w, bid, n)
    account_nodes(w, 4 + n)
    if get(w, 48) == 0:
        put(w, BBASE + get(w, 88) * BSTRIDE + 288 + arm * 8, bid)
    else:
        if b >= get(w, fbase + 16) or n != get(w, bb + 8):
            return fail(w, 19)
        i = 0
        v = 0
        t = 0
        while i < n:
            v = get(w, ARGS + i * 8)
            t = variable(w, v)
            if t != get(w, bb + 40 + i * 16):
                fail(w, 20)
            copy_argument(o, w, v, i, t)
            i = i + 1
        i = 0
        while i < n:
            v = get(w, bb + 32 + i * 16)
            t = get(w, bb + 40 + i * 16)
            mem(o, w, 139, 0, 5, 0 - frame(w) + i * 16)
            store_var(o, w, v, 0)
            if t >= 6 and t <= 9:
                mem(o, w, 139, 0, 5, 0 - frame(w) + i * 16 + 8)
                store_var(o, w, v, 1)
            i = i + 1
        emit(o, w, 233)
        relocation(o, w, 2, bid)
    return 0

def instruction(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    if get(w, 112) >= MAX_INSTRUCTIONS:
        return fail(w, 54)
    put(w, 112, get(w, 112) + 1)
    owned_read_outputs(s, w)
    v = get(w, RESULT_OUTPUTS)
    t = get(w, RESULT_OUTPUTS + 8)
    expect(s, w, 61)
    op = get(w, 8)
    require_effects(w, instruction_effects(op))
    x = get(w, 288)
    if x > 1 and op != @call@ and op != @buffer.try_new@ and op != @chain.try_push@ and op != @chain.pop@:
        return fail(w, 66)
    if (t >= 6 and t <= 9) and op != @borrow.read@ and op != @borrow.mut@ and op != @call@ and (op < @buffer.new@ or op > @chain.head_mut@):
        fail(w, 21)
    next_token(s, w)
    adjacent(w)
    n = args(s, w, 0)
    account_nodes(w, 5 + n)
    account_nodes(w, get(w, 288) * 3)
    x = 0
    a = 0
    b = 0
    at = 0
    bt = 0
    if n > 0:
        a = get(w, ARGS)
        at = variable(w, a)
    if n > 1:
        b = get(w, ARGS + 8)
        bt = variable(w, b)
    if op >= @x86.mmio.read32@ and op <= @x86.irq.dispatch_frame_slab@:
        return mmio_instruction(s, o, w, op, n, at, t, v, bt, a, b)
    if op == @x86.fence.mfence@:
        if get(w, 200) != 1 or (n | t | get(w, 288)) != 0:
            return fail(w, 65)
        expect(s, w, 10)
        if get(w, 40) != 0:
            return 0
        emit_bytes(o, w, 15773199, 3)
        return 0
    if op == @x86.atomic.cmpxchg64@:
        if get(w, 200) != 1 or n != 3 or at != 1 or bt != 1 or t != 1 or get(w, 288) != 1:
            return fail(w, 65)
        c = get(w, ARGS + 16)
        if variable(w, c) != 1:
            return fail(w, 65)
        expect(s, w, 10)
        define(w, v, t)
        if get(w, 40) != 0:
            return 0
        # Experimental raw-address operation: caller must establish mapped
        # coherent WB memory and authority. Check alignment before any access.
        # RDX=address, RAX=expected, RCX=replacement, RAX returns observed old.
        load_var(o, w, 2, a, 0)
        emit_bytes(o, w, 3112727954834166, 7)
        load_var(o, w, 0, b, 0)
        load_var(o, w, 1, c, 0)
        emit_bytes(o, w, 45920241904, 5)
        store_var(o, w, v, 0)
        return 0
    if op >= @x86.io.in8@ and op <= @x86.io.out32@:
        if get(w, 200) != 1 or at != 10:
            return fail(w, 65)
        direction = (op - @x86.io.in8@) & 1
        width = (op - @x86.io.in8@) >> 1
        if direction == 0:
            if n != 1 or t != 1 or get(w, 288) != 1:
                return fail(w, 65)
            define(w, v, t)
        else:
            # Packed scalar type codes: u8=4, u16=10, u32=3.
            if n != 2 or bt != ((932 >> (4 * width)) & 15) or t != 0 or get(w, 288) != 0:
                return fail(w, 65)
        expect(s, w, 10)
        if get(w, 40) != 0:
            return 0
        load_var(o, w, 2, a, 0)
        if direction != 0:
            load_var(o, w, 0, b, 0)
        # IN/OUT are byte, word (66 prefix), or dword (EAX). EAX writes
        # zero the upper half of RAX; byte/word input explicitly extends.
        if width == 1:
            emit(o, w, 102)
        opcode = 236 + 2 * direction
        if width != 0:
            opcode = opcode + 1
        emit(o, w, opcode)
        if direction == 0:
            if width < 2:
                emit(o, w, 15)
                emit(o, w, 182 + width)
                emit(o, w, 192)
            store_var(o, w, v, 0)
        return 0
    if op >= @x86.irq.disable@ and op <= @x86.irq.enable@:
        if get(w, 200) != 1:
            fail(w, 65)
        if (n | t | get(w, 288)) != 0:
            fail(w, 65)
        expect(s, w, 10)
        if get(w, 40) != 0:
            return 0
        # CLI/STI, explicit privilege effect, not an authority proof.
        emit(o, w, 250 + op - @x86.irq.disable@)
        return 0
    if op >= @x86.cr0.read@ and op <= @x86.cr4.read@:
        if get(w, 200) != 1 or n != 0 or t != 1 or get(w, 288) != 1 or get(w, 256) != 0:
            return fail(w, 65)
        expect(s, w, 10)
        define(w, v, t)
        if get(w, 40) != 0:
            return 0
        # MOV RAX, CR0/CR2/CR3/CR4 (0F 20 /r). The checked token
        # interval indexes packed CR numbers 0x4320 (17184), low nibble first.
        emit_bytes(o, w, 8207, 2)
        emit(o, w, 192 + 8 * ((17184 >> (4 * (op - @x86.cr0.read@))) & 15))
        store_var(o, w, v, 0)
        return 0
    if op >= @x86.cr0.write@ and op <= @x86.cr4.write@:
        if get(w, 200) != 1 or n != 1 or at != 1 or t != 0 or get(w, 288) != 0:
            return fail(w, 65)
        expect(s, w, 10)
        if get(w, 40) != 0:
            return 0
        load_var(o, w, 0, a, 0)
        # MOV CR0/CR3/CR4, RAX. Valid state and CPL0 are caller obligations.
        # Packed CR numbers 0x430; no CR2 write is admitted.
        emit_bytes(o, w, 8719, 2)
        emit(o, w, 192 + 8 * ((1072 >> (4 * (op - @x86.cr0.write@))) & 15))
        return 0
    if op == @x86.tlb.invlpg@:
        if get(w, 200) != 1 or n != 1 or at != 1 or t != 0 or get(w, 288) != 0:
            return fail(w, 65)
        expect(s, w, 10)
        if get(w, 40) != 0:
            return 0
        load_var(o, w, 0, a, 0)
        # Typed one-operand x86 INVLPG, ModRM /7, base RAX.
        # This is the compiler's own instruction lowering, not source bytes.
        emit_bytes(o, w, 3670287, 3)
        return 0
    if op >= @buffer.new@ and op <= @chain.head_mut@:
        owned_instruction(o, w, op, n, a, at)
        owned_define_outputs(w)
        if get(w, 40) != 0:
            return 0
        if op == @chain.head_read@ or op == @chain.head_mut@:
            loan_produce(w, v, a)
        expect(s, w, 10)
        return 0
    if op == @const@:
        account_nodes(w, 1)
        separated(w)
        expect(s, w, 123)
        expect(s, w, @value@)
        expect(s, w, 58)
        x = scalar_literal(s, w, t)
        expect(s, w, 125)
        if n != 0:
            fail(w, 22)
        if get(w, SCHEMA_STATE) == @hepta.hia.program.v9@ and v < 2048:
            put(w, CONST_VALUES + v * 8, x)
            store(w, CONST_FLAGS + v, 1)
        else:
            emit_bytes(o, w, 47176, 2)
            emit8(o, w, x)
    else:
        if op == @call@:
            loan_call(w, n)
            account_nodes(w, 1)
            separated(w)
            expect(s, w, 123)
            expect(s, w, @function@)
            expect(s, w, 58)
            if get(w, 32) != 1:
                fail(w, 49)
            x = read_function_name(s, w, 0)
            expect(s, w, 125)
            if x >= 192:
                fail(w, 23)
            else:
                if get(w, 432) == 0:
                    if x == get(w, 72):
                        put(w, 256, tail_self_call(s, w))
                    if get(w, 48) == 0 and get(w, 256) == 0:
                        store(w, 1010784 + get(w, 72) * 192 + x, 1)
            if get(w, 48) > 0:
                if x >= get(w, 1024):
                    fail(w, 23)
                fb = FBASE + x * FSTRIDE
                require_effects(w, get(w, fb + 176))
                if n != get(w, fb + 24) or t != get(w, fb + 32):
                    fail(w, 24)
                i = 0
                av = 0
                typ = 0
                while i < n:
                    av = get(w, ARGS + i * 8)
                    typ = variable(w, av)
                    if typ != get(w, fb + 48 + i * 8):
                        fail(w, 25)
                    copy_argument(o, w, av, i, typ)
                    i = i + 1
                if get(w, 256) != 0:
                    # All arguments were staged before overwriting any entry
                    # parameter. Keep the frame and original result pointer;
                    # The declared entry begins after the prologue, including
                    # stack probes; it need not be the first source block.
                    i = 0
                    while i < n:
                        mem(o, w, 139, 0, 5, 0 - frame(w) + i * 16)
                        store_var(o, w, i, 0)
                        if resource_type(get(w, fb + 48 + i * 8)) == 1:
                            mem(o, w, 139, 0, 5, 0 - frame(w) + i * 16 + 8)
                            store_var(o, w, i, 1)
                        i = i + 1
                    emit(o, w, 233)
                    relocation(o, w, 2, get(w, fb + 8) + get(w, fb + 264))
                else:
                    mem(o, w, 141, 7, 5, 0 - frame(w))
                    mem(o, w, 141, 6, 5, 0 - frame(w) + 512)
                    mem(o, w, 139, 2, 5, 18446744073709551600)
                    emit(o, w, 232)
                    relocation(o, w, 1, x)
            owner_call_consume(w, n)
            call_results(o, w, x)
            expect(s, w, 10)
            return 0
        else:
            if op == @int.cast@:
                account_nodes(w, 1)
                separated(w)
                expect(s, w, 123)
                expect(s, w, @mode@)
                expect(s, w, 58)
                if get(w, 8) == @checked@:
                    x = 1
                    require_effects(w, 8)
                    next_token(s, w)
                else:
                    expect(s, w, @wrap@)
                expect(s, w, 125)
                if n != 1 or integer_type(at) != 1 or integer_type(t) != 1:
                    fail(w, 26)
                load_var(o, w, 0, a, 0)
                cast_integer(o, w, t, x, at)
            else:
                if op >= @borrow.read@ and op <= @loan.end@:
                    loan_operation(w, op, n, a, at, t)
                else:
                    if op >= @bit.not@ and op <= @int.neg.checked@ and op != @select@:
                        checked_integer(o, w, op, n, a, b, at, bt, t)
                    else:
                        operation_dispatch(o, w, op, n, a, b, at, bt, t)
    if t != 0:
        define(w, v, t)
        if get(w, 40) != 0:
            return 0
        if op == @borrow.read@ or op == @borrow.mut@:
            loan_produce(w, v, a)
            load_var(o, w, 0, a, 1)
            store_var(o, w, v, 1)
            load_var(o, w, 0, a, 0)
        if get(w, 256) == 0:
            if byte(w, CONST_FLAGS + v) == 0:
                store_var(o, w, v, 0)
    else:
        if op != @buffer.store@ and op != @buffer.swap@ and op != @loan.end@ and (op < @buffer.fill@ or op > @buffer.move_within@) and op != @buffer.store.u64.le@ and op != @buffer.store.u64.be@:
            fail(w, 27)
    expect(s, w, 10)
    return 0

# Adjacent literal encoding bytes share emit_bytes; phase-1 sizing still
# precedes all phase-2 output, and emitted machine bytes stay identical.
def operation(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    if op == @select@:
        return select_scalar(o, w, n, a, b, at, bt, t)
    if op == @buffer.len@:
        if n != 1 or at < 6 or at > 8 or t != 2:
            fail(w, 28)
        load_var(o, w, 0, a, 1)
        return 0
    if op == @buffer.swap@:
        loan_access(w, a)
        if n != 3 or t != 0 or at != 7 or bt != 2 or variable(w, get(w, ARGS + 16)) != 2:
            fail(w, 57)
        load_var(o, w, 1, b, 0)
        load_var(o, w, 2, a, 1)
        # cmp rcx, rdx; jb +2; ud2; nop. Both checks precede all memory access.
        emit8(o, w, 10379406269396105544)
        load_var(o, w, 6, get(w, ARGS + 16), 0)
        emit8(o, w, 10379406269396433224)
        load_var(o, w, 0, a, 0)
        # add rcx, rax; add rsi, rax; movzx edx, [rcx]; mov al, [rsi];
        # mov [rcx], al; mov [rsi], dl; nop. All value slots stay in memory.
        emit8(o, w, 13118921948371419464)
        emit8(o, w, 10382635531107731985)
        return 0
    load_var(o, w, 0, a, 0)
    if op == @bool.not@:
        if n != 1 or at != 5 or t != 5:
            fail(w, 31)
        emit_bytes(o, w, 32539464, 4)
        return 0
    if n != 2:
        fail(w, 32)
    load_var(o, w, 1, b, 0)
    if op >= @compare.eq@ and op <= @compare.ge@:
        if (integer_type(at) != 1 and (at != 5 or (op != @compare.eq@ and op != @compare.ne@))) or at != bt or t != 5:
            fail(w, 33)
        emit_bytes(o, w, 13121864, 3)
        cond = 148
        if op == @compare.ne@:
            cond = 149
        if op == @compare.lt@:
            cond = 146
        if op == @compare.le@:
            cond = 150
        if op == @compare.gt@:
            cond = 151
        if op == @compare.ge@:
            cond = 147
        if signed_type(at) == 1:
            if op == @compare.lt@:
                cond = 156
            if op == @compare.le@:
                cond = 158
            if op == @compare.gt@:
                cond = 159
            if op == @compare.ge@:
                cond = 157
        emit(o, w, 15)
        emit(o, w, cond)
        emit_bytes(o, w, 3233157056, 4)
        return 0
    if at != bt or t != at or t == 0:
        fail(w, 34)
    if op == @bool.and@ or op == @bool.or@:
        if t != 5:
            fail(w, 35)
    else:
        if integer_type(t) != 1:
            fail(w, 35)
    if op == @int.add.wrap@:
        emit_bytes(o, w, 13107528, 3)
    else:
        if op == @int.sub.wrap@:
            emit_bytes(o, w, 13117768, 3)
        else:
            if op == @int.mul.wrap@:
                emit_bytes(o, w, 3249475400, 4)
            else:
                if op == @bit.and@ or op == @bool.and@:
                    emit_bytes(o, w, 13115720, 3)
                else:
                    if op == @bit.or@ or op == @bool.or@:
                        emit_bytes(o, w, 13109576, 3)
                    else:
                        if op == @bit.xor@:
                            emit_bytes(o, w, 13119816, 3)
                        else:
                            if op == @int.shl.checked@ or op == @int.shr.checked@:
                                width = integer_width(t)
                                emit_bytes(o, w, 16352072, 3)
                                emit(o, w, width)
                                emit_bytes(o, w, 232306376639090, 6)
                                if op == @int.shl.checked@:
                                    emit(o, w, 224)
                                else:
                                    if signed_type(t) == 1:
                                        emit(o, w, 248)
                                    else:
                                        emit(o, w, 232)
                            else:
                                fail(w, 36)
    normalize(o, w, t)
    return 0

def define(w:mutbuf, v:u64, t:u64) -> u64:
    if v >= 2048 or t == 0 or t > 16:
        return fail(w, 37)
    if get(w, VBASE + v * 16) != 0:
        return fail(w, 38)
    put(w, VBASE + v * 16, t)
    store(w, ORIGINBASE + v, 0)
    put(w, VBASE + v * 16 + 8, get(w, 88) + 1)
    if t >= 6 and t <= 9:
        put(w, CAPBASE + v * 24, v)
        put(w, CAPBASE + v * 24 + 8, 0)
        put(w, CAPBASE + v * 24 + 16, 1)
    fb = FBASE + get(w, 72) * FSTRIDE
    if get(w, 48) == 0:
        if v > get(w, fb + 40):
            put(w, fb + 40, v)
    return 0

def variable(w:mutbuf, v:u64) -> u64:
    if v >= 2048:
        return fail(w, 39)
    if get(w, VBASE + v * 16 + 8) != get(w, 88) + 1:
        return fail(w, 40)
    t = get(w, VBASE + v * 16)
    if t == 0:
        return fail(w, 40)
    if get(w, 264) == 1 and (t >= 6 and t <= 9) and get(w, CAPBASE + v * 24 + 16) == 0:
        return fail(w, 62)
    return t

def read_type(s:readbuf, w:mutbuf) -> u64:
    t = get(w, 8)
    next_token(s, w)
    if t < @u64@ or t > @unit@:
        return fail(w, 41)
    if t == @chain@ and get(w, SCHEMA_STATE) == @hepta.hia.program.v6@:
        return fail(w, 64)
    if (t >= @buffer@ and t <= @chain@) and get(w, 232) != 1:
        return fail(w, 64)
    return t - @u64@ + 1

def check_graph(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    # Incoming graphs are immutable once discovered: later edges must match
    # exactly. Queue each first discovery, then replay only an unchecked block.
    # This keeps reverse source-order CFGs from reparsing the whole module.
    start = get(w, FBASE + get(w, 72) * FSTRIDE + 8)
    count = get(w, 96)
    cursor = get(w, 24)
    blocks = get(w, 80)
    instructions = get(w, 112)
    nodes = get(w, 248)
    relocations = get(w, 224)
    externals = get(w, 344)
    interned_count = get(w, 480)
    bid = 0
    i = 0
    while get(w, 392) < get(w, 384) and get(w, 40) == 0:
        bid = get(w, QBASE + get(w, 392) * 8)
        put(w, 392, get(w, 392) + 1)
        if bid < start or bid >= start + count or bid == start + get(w, FBASE + get(w, 72) * FSTRIDE + 264):
            return fail(w, 42)
        if get(w, BBASE + bid * BSTRIDE + 24) == 0:
            # Initial parsing has already checked global SSA uniqueness.
            # Clear only this block's definitions before replay so neither
            # variable() nor loan_live() can observe a future instruction's
            # stale capability. define() keeps its ordinary strict check.
            i = 0
            while i < interned_count:
                if get(w, VBASE + i * 16 + 8) == bid + 1:
                    put(w, VBASE + i * 16, 0)
                i = i + 1
            put(w, 0, get(w, BBASE + bid * BSTRIDE))
            put(w, 80, bid)
            put(w, 96, bid - start)
            put(w, 112, 0)
            put(w, 248, 4)
            put(w, 224, 0)
            put(w, 344, 0)
            next_token(s, w)
            parse_block(s, o, w)
    put(w, 80, blocks)
    put(w, 96, count)
    put(w, 112, instructions)
    put(w, 248, nodes)
    put(w, 224, relocations)
    put(w, 344, externals)
    put(w, 0, cursor)
    next_token(s, w)
    i = 0
    while i < count:
        if get(w, BBASE + (start + i) * BSTRIDE + 24) != 1:
            return fail(w, 43)
        i = i + 1
    return 0

# Read-only exact-name lookahead. Ordinary admission reparses every token.
# No SSA name is interned here; mismatch selects a real independent call frame.
def tail_self_call(s:readbuf, w:mutbuf) -> u64:
    pos = get(w, 0)
    token = get(w, 8)
    value = get(w, 16)
    begin = get(w, 24)
    quoted = get(w, 32)
    previous = get(w, 120)
    error = get(w, 40)
    result = 0
    count = 0
    matches = 1
    if token == 10:
        next_token(s, w)
        if get(w, 8) == @ret@ and instruction_ahead(s, w) == 0:
            next_token(s, w)
            expect(s, w, 40)
            while count < get(w, 288) and matches == 1 and get(w, 40) == 0:
                identifier(s, w)
                if get(w, 32) != 0:
                    matches = 0
                if same_identifier(s, w, RESULT_NAMES + count * 16) != 1:
                    matches = 0
                next_token(s, w)
                count = count + 1
                if count < get(w, 288):
                    expect(s, w, 44)
            if matches == 1 and count == get(w, 288) and get(w, 8) == 41 and get(w, 40) == 0:
                result = 1
    put(w, 0, pos)
    put(w, 8, token)
    put(w, 16, value)
    put(w, 24, begin)
    put(w, 32, quoted)
    put(w, 120, previous)
    put(w, 40, error)
    return result


def wrapper(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 4678258462042966101, 8)
    mem(o, w, 137, 7, 5, 18446744073709551552)
    mem(o, w, 137, 6, 5, 18446744073709551560)
    mem(o, w, 137, 2, 5, 18446744073709551568)
    mem(o, w, 137, 1, 5, 18446744073709551576)
    emit_bytes(o, w, 8751436, 3)
    emit4(o, w, 18446744073709551584)
    emit_bytes(o, w, 9275724, 3)
    emit4(o, w, 18446744073709551592)
    mem(o, w, 141, 7, 5, 18446744073709551552)
    mem(o, w, 141, 6, 5, 18446744073709551608)
    emit_bytes(o, w, 186, 1)
    emit4(o, w, CALL_BUDGET)
    emit(o, w, 232)
    relocation(o, w, 1, 0)
    mem(o, w, 139, 0, 5, 18446744073709551608)
    emit_bytes(o, w, 50121, 2)
    return 0

def function_start(o:mutbuf, w:mutbuf) -> u64:
    if get(w, 48) == 0:
        return 0
    fb = FBASE + get(w, 72) * FSTRIDE
    put(w, fb, get(w, 56))
    # test edx,511; jz UD2; cmp rdx,cost; jae past UD2; sub rdx,cost.
    # Low nine bits are remaining depth, high bits are private stack bytes.
    # Guard before stack probes or callee effects; rbp-16 retains each budget.
    emit_bytes(o, w, 681169443673326327, 8)
    emit_bytes(o, w, 16417096, 3)
    emit4(o, w, (frame(w) + 16) * 512 + 1)
    emit_bytes(o, w, 66007290973454963, 7)
    emit4(o, w, (frame(w) + 16) * 512 + 1)
    emit_bytes(o, w, 3850979413, 4)
    remain = frame(w)
    amount = 0
    while remain > 0:
        amount = remain
        if amount > 4096:
            amount = 4096
        emit_bytes(o, w, 15499592, 3)
        emit4(o, w, amount)
        emit_bytes(o, w, 604277576, 4)
        remain = remain - amount
    mem(o, w, 137, 2, 5, 18446744073709551600)
    mem(o, w, 137, 6, 5, 18446744073709551608)
    i = 0
    t = 0
    while i < get(w, fb + 24):
        t = get(w, fb + 48 + i * 8)
        mem(o, w, 139, 0, 7, i * 16)
        store_var(o, w, i, 0)
        if t >= 6 and t <= 9:
            mem(o, w, 139, 0, 7, i * 16 + 8)
            store_var(o, w, i, 1)
        i = i + 1
    if get(w, fb + 264) != 0:
        emit(o, w, 233)
        relocation(o, w, 2, get(w, fb + 8) + get(w, fb + 264))
    return 0

def frame(w:mutbuf) -> u64:
    return (get(w, FBASE + get(w, 72) * FSTRIDE + 40) + 2) * 16 + 640

def copy_argument(o:mutbuf, w:mutbuf, v:u64, i:u64, t:u64) -> u64:
    load_var(o, w, 0, v, 0)
    mem(o, w, 137, 0, 5, 0 - frame(w) + i * 16)
    if t >= 6 and t <= 9:
        load_var(o, w, 0, v, 1)
        mem(o, w, 137, 0, 5, 0 - frame(w) + i * 16 + 8)
    return 0

def load_var(o:mutbuf, w:mutbuf, reg:u64, v:u64, word:u64) -> u64:
    if word == 0 and v < 2048:
        if byte(w, CONST_FLAGS + v) == 1:
            # source_program validates every internal caller uses a low GPR.
            emit(o, w, 72)
            emit(o, w, 184 + reg)
            return emit8(o, w, get(w, CONST_VALUES + v * 8))
    return mem(o, w, 139, reg, 5, 0 - 32 - v * 16 + word * 8)

def store_var(o:mutbuf, w:mutbuf, v:u64, word:u64) -> u64:
    return mem(o, w, 137, 0, 5, 0 - 32 - v * 16 + word * 8)

def normalize(o:mutbuf, w:mutbuf, t:u64) -> u64:
    if t == 14:
        emit_bytes(o, w, 3233681224, 4)
    if t == 15:
        emit_bytes(o, w, 3233746760, 4)
    if t == 13:
        emit_bytes(o, w, 12608328, 3)
    if t == 16:
        emit_bytes(o, w, 49201, 2)
    if t == 4:
        emit_bytes(o, w, 9544, 2)
        emit4(o, w, 255)
    if t == 10:
        emit_bytes(o, w, 9544, 2)
        emit4(o, w, 65535)
    if t == 3:
        emit_bytes(o, w, 49289, 2)
    if t == 5:
        emit_bytes(o, w, 31490888, 4)
    return 0

def mem(o:mutbuf, w:mutbuf, opcode:u64, reg:u64, base:u64, disp:u64) -> u64:
    short = disp + 128 < 256
    mode = 128
    if short:
        mode = 64
    emit(o, w, 72)
    emit(o, w, opcode)
    emit(o, w, mode + reg * 8 + base)
    if short:
        emit(o, w, disp)
    else:
        emit4(o, w, disp)
    return 0

def relocation(o:mutbuf, w:mutbuf, kind:u64, target:u64) -> u64:
    n = get(w, 224)
    if n >= MAX_RELOCATIONS:
        return fail(w, 44)
    if get(w, 48) == 2:
        if get(w, 56) > 4294967295 or kind > 4294967295:
            return fail(w, 44)
        put(w, FIXBASE + n * 16, get(w, 56) | (kind << 32))
        put(w, FIXBASE + n * 16 + 8, target)
    put(w, 224, n + 1)
    emit4(o, w, 0)
    return 0

def fix_all(o:mutbuf, w:mutbuf) -> u64:
    i = 0
    at = 0
    kind = 0
    target = 0
    pos = 0
    while i < get(w, 224):
        at = get(w, FIXBASE + i * 16)
        kind = at >> 32
        at = at & 4294967295
        target = get(w, FIXBASE + i * 16 + 8)
        if kind != 3:
            if kind == 4:
                pos = get(w, 368)
            else:
                if kind == 1:
                    pos = get(w, FBASE + target * FSTRIDE)
                else:
                    pos = get(w, BBASE + target * BSTRIDE)
            write4(o, at, pos - at - 4)
        i = i + 1
    return 0

def emit8(o:mutbuf, w:mutbuf, x:u64) -> u64:
    return emit_bytes(o, w, x, 8)

def emit4(o:mutbuf, w:mutbuf, x:u64) -> u64:
    return emit_bytes(o, w, x, 4)

def emit(o:mutbuf, w:mutbuf, x:u64) -> u64:
    phase = get(w, 48)
    if phase > 0:
        pos = get(w, 56)
        if phase == 2:
            store(o, pos, x)
        put(w, 56, pos + 1)
    return 0

def write4(o:mutbuf, at:u64, x:u64) -> u64:
    i = 0
    while i < 4:
        store(o, at + i, x & 255)
        x = x >> 8
        i = i + 1
    return 0

def expect(s:readbuf, w:mutbuf, kind:u64) -> u64:
    if kind == 256 or kind == 260:
        return read_value_name(s, w, kind)
    if kind == 258:
        return read_block_name(s, w, 0)
    value = get(w, 16)
    if get(w, 8) != kind:
        fail(w, 45)
    if get(w, 40) == 0:
        next_token(s, w)
    return value

def adjacent(w:mutbuf) -> u64:
    if get(w, 24) != get(w, 120):
        fail(w, 55)
    return 0

def separated(w:mutbuf) -> u64:
    if get(w, 24) <= get(w, 120):
        fail(w, 56)
    return 0

def next_token(s:readbuf, w:mutbuf) -> u64:
    pos = get(w, 0)
    put(w, 120, pos)
    n = length(s)
    c = 0
    begin = 0
    quoted = 0
    kind = 0
    val = 0
    while pos < n and byte(s, pos) == 32:
        pos = pos + 1
    put(w, 16, 0)
    put(w, 32, 0)
    put(w, 24, pos)
    if pos == n:
        put(w, 8, 0)
        put(w, 0, pos)
        return 0
    c = byte(s, pos)
    if c == 10 or c == 40 or c == 41 or c == 44 or c == 58 or c == 61 or c == 123 or c == 125 or c == 45 or c == 62 or c == 91 or c == 93:
        put(w, 8, c)
        put(w, 0, pos + 1)
        return 0
    if c == 95:
        if pos + 1 == n or is_word(byte(s, pos + 1)) == 0:
            put(w, 8, 95)
            put(w, 0, pos + 1)
            return 0
    if c == 34:
        quoted = 1
        put(w, 32, 1)
        pos = pos + 1
    begin = pos
    if quoted == 0 and c >= 48 and c <= 57:
        val = decimal(s, w, pos)
        put(w, 8, 259)
        put(w, 16, val)
        return 0
    while pos < n and is_word(byte(s, pos)) == 1:
        pos = pos + 1
    if begin == pos:
        return fail(w, 46)
    put(w, 0, pos)
    if quoted == 1:
        if pos >= n or byte(s, pos) != 34:
            return fail(w, 47)
        put(w, 0, pos + 1)
    # The whole word and closing quote were checked above. Numeric SSA,
    # function and block spellings cannot be keywords; source_program checks
    # that table invariant before authoring. Identifier admission stays in
    # identifier(), including its length, suffix and reserved-name checks.
    if pos - begin >= 2:
        c = byte(s, begin)
        val = byte(s, begin + 1)
        if (c == 118 or c == 102 or c == 98) and val >= 48 and val <= 57:
            kind = 261
    if kind == 0:
        kind = keyword(s, begin, pos - begin)
    if kind == 0:
        kind = 261
    if quoted == 1:
        if kind != @value@ and kind != @mode@ and kind != @wrap@ and kind != @checked@ and kind != @function@:
            kind = 261
    else:
        if kind == @value@ or kind == @mode@ or kind == @wrap@ or kind == @checked@ or kind == @function@:
            kind = 261
    put(w, 8, kind)
    return 0

def decimal(s:readbuf, w:mutbuf, pos:u64) -> u64:
    n = length(s)
    value = 0
    count = 0
    c = 0
    first = 0
    while pos < n and byte(s, pos) >= 48 and byte(s, pos) <= 57:
        c = byte(s, pos) - 48
        if count == 0:
            first = c
        if value > 1844674407370955161 or (value == 1844674407370955161 and c > 5):
            fail(w, 52)
        value = value * 10 + c
        pos = pos + 1
        count = count + 1
    if count == 0 or (count > 1 and first == 0):
        fail(w, 53)
    put(w, 0, pos)
    return value

def is_word(c:u64) -> u64:
    # Exact ASCII membership, with both shifts bounded before execution.
    # This also preserves the old refusal for every non-ASCII u64 value.
    if c < 64:
        return (288054454291267584 >> c) & 1
    if c < 128:
        return (576460745995190270 >> (c - 64)) & 1
    return 0

KEYWORD_FUNCTION

def match(s:readbuf, begin:u64, size:u64, expected:u64, a:u64, b:u64, c:u64, d:u64) -> u64:
    if size != expected:
        return 0
    i = 0
    word = 0
    shift = 0
    while i < size:
        word = a
        shift = i
        if i >= 8:
            word = b
            shift = i - 8
        if i >= 16:
            word = c
            shift = i - 16
        if i >= 24:
            word = d
            shift = i - 24
        if byte(s, begin + i) != ((word >> (shift * 8)) & 255):
            return 0
        i = i + 1
    return 1

def fail(w:mutbuf, code:u64) -> u64:
    if get(w, 40) == 0:
        put(w, 40, code)
        put(w, 104, get(w, 24))
    return 0

def put(w:mutbuf, at:u64, value:u64) -> u64:
    store(w, at, value & 255)
    store(w, at + 1, (value >> 8) & 255)
    store(w, at + 2, (value >> 16) & 255)
    store(w, at + 3, (value >> 24) & 255)
    store(w, at + 4, (value >> 32) & 255)
    store(w, at + 5, (value >> 40) & 255)
    store(w, at + 6, (value >> 48) & 255)
    store(w, at + 7, (value >> 56) & 255)
    return 0

def get(w:mutbuf, at:u64) -> u64:
    # A read has no prefix writes; the whole checked word preserves the same
    # little-endian scalar and bounds failure. Generic put retains its exact
    # original byte-prefix write/trap semantics.
    return word_load(w, at)

def state_put32(w:mutbuf, at:u64, value:u64) -> u64:
    store(w, at, value & 255)
    store(w, at + 1, (value >> 8) & 255)
    store(w, at + 2, (value >> 16) & 255)
    store(w, at + 3, (value >> 24) & 255)
    return 0

def state_get32(w:mutbuf, at:u64) -> u64:
    value = byte(w, at)
    value = value | (byte(w, at + 1) << 8)
    value = value | (byte(w, at + 2) << 16)
    value = value | (byte(w, at + 3) << 24)
    return value

def elf_begin(o:mutbuf, w:mutbuf) -> u64:
    emit8(o, w, 282584257676671)
    emit8(o, w, 0)
    emit8(o, w, 4299030529)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 274877906944)
    emit8(o, w, 1125925680840704)
    return 0

def elf_finish(o:mutbuf, w:mutbuf) -> u64:
    if get(w, 48) == 0:
        return 0
    if get(w, 344) != 0:
        return owned_elf_finish(o, w)
    text = get(w, 56) - 64
    align8(o, w)
    symbols = get(w, 56)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 281487861612544)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 281552286121985)
    emit8(o, w, 0)
    emit8(o, w, get(w, 240) - 64)
    strings = get(w, 56)
    emit4(o, w, 3171840)
    names = get(w, 56)
    emit8(o, w, 3314777386191695360)
    emit8(o, w, 3314757496449366387)
    emit8(o, w, 3314757496449692787)
    emit8(o, w, 7089075323386685555)
    emit8(o, w, 5129148576381677056)
    emit8(o, w, 7738135737529095502)
    emit(o, w, 0)
    align8(o, w)
    headers = get(w, 56)
    if get(w, 48) == 2:
        put(o, 40, headers)
    elf_section(o, w, 0, 0, 0, 0, 0, 0, 0)
    elf_section(o, w, 4294967297, 6, 64, text, 0, 16, 0)
    elf_section(o, w, 8589934599, 0, symbols, 72, 8589934595, 8, 24)
    elf_section(o, w, 12884901903, 0, strings, 4, 0, 1, 0)
    elf_section(o, w, 12884901911, 0, names, 49, 0, 1, 0)
    elf_section(o, w, 4294967329, 0, names + 49, 0, 0, 1, 0)
    return 0

def align8(o:mutbuf, w:mutbuf) -> u64:
    while (get(w, 56) & 7) != 0:
        emit(o, w, 0)
    return 0

def elf_section(o:mutbuf, w:mutbuf, kind:u64, flags:u64, offset:u64, size:u64, links:u64, alignment:u64, item_size:u64) -> u64:
    emit8(o, w, kind)
    emit8(o, w, flags)
    emit8(o, w, 0)
    emit8(o, w, offset)
    emit8(o, w, size)
    emit8(o, w, links)
    emit8(o, w, alignment)
    emit8(o, w, item_size)
    return 0

def account_nodes(w:mutbuf, amount:u64) -> u64:
    nodes = get(w, 248) + amount
    put(w, 248, nodes)
    if nodes > MAX_CORE_NODES:
        return fail(w, 58)
    return 0

def emit_bytes(o:mutbuf, w:mutbuf, x:u64, remaining:u64) -> u64:
    if remaining == 0:
        return 0
    phase = get(w, 48)
    if phase == 0:
        return 0
    pos = get(w, 56)
    if phase == 1 or (pos <= length(o) and remaining <= length(o) - pos):
        if phase == 2:
            # Output bytes retain their order without scanner-private helpers.
            # The existing emitter dependency closure remains unchanged.
            if remaining == 4:
                store(o, pos, x & 255)
                store(o, pos + 1, (x >> 8) & 255)
                store(o, pos + 2, (x >> 16) & 255)
                store(o, pos + 3, (x >> 24) & 255)
            else:
                i = 0
                while i < remaining:
                    store(o, pos + i, x & 255)
                    x = x >> 8
                    i = i + 1
        put(w, 56, pos + remaining)
        return 0
    # Real short-capacity calls retain the exact per-byte prefix writes and
    # counter updates before the original buffer.store trap. No trap is hidden.
    emit(o, w, x)
    return emit_bytes(o, w, x >> 8, remaining - 1)
# Kept in a separate HIA function so the per-function SSA ceiling stays 2047.
# Appending this helper preserves all existing compiler function identities.
def checked_integer(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    if signed_type(at) == 1:
        return signed_integer(o, w, op, n, a, b, at, bt, t)
    load_var(o, w, 0, a, 0)
    if op == @bit.not@:
        if n != 1 or at < 1 or (at > 4 and at != 10) or t != at:
            fail(w, 31)
        # NOT is a full machine word operation; restore the declared width.
        emit_bytes(o, w, 13694792, 3)
        normalize(o, w, t)
        return 0
    if op == @int.neg.checked@:
        if n != 1 or at < 1 or (at > 4 and at != 10) or t != at:
            fail(w, 31)
        # The only representable unsigned negation is zero. Test before any
        # later operation, preserving all earlier observable stores.
        emit_bytes(o, w, 3112727966942536, 7)
        return 0
    if n != 2 or at != bt or t != at or t == 0 or (t > 4 and t != 10):
        fail(w, 34)
    load_var(o, w, 1, b, 0)
    if op == @int.div.checked@ or op == @int.rem.checked@:
        # test rcx,rcx; jne +2; ud2; xor edx,edx; div rcx. Clearing the
        # dividend's upper half avoids machine overflow for every u64 input.
        emit_bytes(o, w, 3112727984309576, 7)
        emit_bytes(o, w, 1039235863089, 5)
        if op == @int.rem.checked@:
            emit_bytes(o, w, 13666632, 3)
        return 0
    if op == @int.mul.checked@:
        # Unsigned MUL sets CF iff the high half is nonzero. IMUL's signed
        # overflow flag would reject legal high-bit operands such as MAX*1.
        emit_bytes(o, w, 3112727952357192, 7)
    else:
        if op != @int.add.checked@ and op != @int.sub.checked@:
            return fail(w, 36)
        # Operands are zero extended. Preserve CF until the first branch:
        # add/sub rax, rcx; jnc +2; ud2. This checks 64-bit carry/borrow.
        emit(o, w, 72)
        if op == @int.add.checked@:
            emit(o, w, 1)
        else:
            emit(o, w, 41)
        emit_bytes(o, w, 47496459208, 5)
    if (op == @int.add.checked@ or op == @int.mul.checked@) and (t == 3 or t == 4 or t == 10):
        # A narrow result can overflow without a 64-bit carry. Save the full
        # result, normalize rax, then require that no high bits were lost.
        emit_bytes(o, w, 12683592, 3)
        normalize(o, w, t)
        emit_bytes(o, w, 3112727967447368, 7)
    normalize(o, w, t)
    return 0


def select_scalar(o:mutbuf, w:mutbuf, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    if n != 3 or at != 5 or scalar_type(bt) != 1 or t != bt or variable(w, get(w, ARGS + 16)) != bt:
        fail(w, 60)
    # Core select(cond, true_value, false_value). Full-width moves preserve
    # the already-normalized scalar slots, including u64/usize high bits.
    load_var(o, w, 2, a, 0)
    load_var(o, w, 1, b, 0)
    load_var(o, w, 0, get(w, ARGS + 16), 0)
    # test rdx, rdx; cmovne rax, rcx
    emit_bytes(o, w, 54400602453738824, 7)
    return 0

# These HIA helpers emit complete machine instructions, never host/library calls.
def bulk_range_guard(o:mutbuf, w:mutbuf, buffer:u64, offset:u64, size:u64) -> u64:
    load_var(o, w, 0, buffer, 1)
    load_var(o, w, 1, offset, 0)
    # cmp rcx,rax; jbe +2; ud2; sub rax,rcx. Offset is checked first.
    emit_bytes(o, w, 3112728000543048, 7)
    emit_bytes(o, w, 13117768, 3)
    load_var(o, w, 1, size, 0)
    # Compare against extent-offset instead of overflowing offset+count.
    emit_bytes(o, w, 3112728000543048, 7)
    return 0

def bulk_buffer(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    loan_access(w, a)
    if at != 7 or t != 0:
        return fail(w, 61)
    c = get(w, ARGS + 16)
    d = get(w, ARGS + 24)
    e = get(w, ARGS + 32)
    if op == @buffer.fill@:
        if n != 2 or bt != 4:
            return fail(w, 61)
        load_var(o, w, 1, a, 1)
        load_var(o, w, 0, b, 0)
        load_var(o, w, 7, a, 0)
        # cld; rep stosb. Zero count performs no access.
        emit_bytes(o, w, 11203580, 3)
        return 0
    if op == @buffer.fill_range@:
        if n != 4 or bt != 2 or variable(w, c) != 2 or variable(w, d) != 4:
            return fail(w, 61)
        bulk_range_guard(o, w, a, b, c)
    else:
        if op == @buffer.move_within@:
            if n != 4 or bt != 2 or variable(w, c) != 2 or variable(w, d) != 2:
                return fail(w, 61)
            bulk_range_guard(o, w, a, b, d)
            bulk_range_guard(o, w, a, c, d)
        else:
            # Local children retain their roots; copy requires disjoint roots
            # as well as active, unsuspended source/destination capabilities.
            if bt != 6:
                return fail(w, 61)
            loan_access(w, b)
            if get(w, 264) == 1 and get(w, CAPBASE + a * 24) == get(w, CAPBASE + b * 24):
                return fail(w, 62)
            if op == @buffer.copy@:
                if n != 3 or variable(w, c) != 2:
                    return fail(w, 61)
                load_var(o, w, 1, c, 0)
                load_var(o, w, 0, a, 1)
                emit_bytes(o, w, 3112728000543048, 7)
                load_var(o, w, 0, b, 1)
                emit_bytes(o, w, 3112728000543048, 7)
            else:
                if op != @buffer.copy_range@ or n != 5 or variable(w, c) != 2 or variable(w, d) != 2 or variable(w, e) != 2:
                    return fail(w, 61)
                bulk_range_guard(o, w, a, c, e)
                bulk_range_guard(o, w, b, d, e)
    # Validate even empty ranges, then skip derived pointers when count is zero.
    emit_bytes(o, w, 567200548168, 5)
    done = get(w, 56)
    emit4(o, w, 0)
    load_var(o, w, 7, a, 0)
    if op == @buffer.fill_range@:
        load_var(o, w, 0, b, 0)
        emit_bytes(o, w, 13041992, 3)
        load_var(o, w, 0, d, 0)
        emit_bytes(o, w, 11203580, 3)
    else:
        if op == @buffer.move_within@:
            load_var(o, w, 6, a, 0)
            load_var(o, w, 0, b, 0)
            emit_bytes(o, w, 13041992, 3)
            load_var(o, w, 0, c, 0)
            emit_bytes(o, w, 12976456, 3)
            # Backward copy handles overlap and clears DF on return. The
            # forward path also explicitly clears DF. All registers volatile.
            emit_bytes(o, w, 70715390280, 5)
            emit_bytes(o, w, 1095476481352, 5)
            emit_bytes(o, w, 1095459179848, 5)
            emit_bytes(o, w, 17580931357438440445, 8)
            emit(o, w, 164)
        else:
            load_var(o, w, 6, b, 0)
            if op == @buffer.copy_range@:
                load_var(o, w, 0, c, 0)
                emit_bytes(o, w, 13041992, 3)
                load_var(o, w, 0, d, 0)
                emit_bytes(o, w, 12976456, 3)
            emit_bytes(o, w, 10810364, 3)
    if get(w, 48) == 2:
        write4(o, done, get(w, 56) - done - 4)
    return 0

# Keep dispatch outside the pre-existing operation function's SSA budget.
def operation_dispatch(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    if op == @buffer.load@ or op == @buffer.store@ or (op >= @buffer.load.u64.le@ and op <= @buffer.store.u64.be@):
        return word_memory(o, w, op, n, a, b, at, bt, t)
    if op >= @buffer.fill@ and op <= @buffer.move_within@:
        return bulk_buffer(o, w, op, n, a, b, at, bt, t)
    return operation(o, w, op, n, a, b, at, bt, t)

def loan_live(w:mutbuf, v:u64) -> u64:
    if get(w, VBASE + v * 16 + 8) == get(w, 88) + 1 and resource_type(get(w, VBASE + v * 16)) == 1 and get(w, CAPBASE + v * 24 + 16) == 1:
        return 1
    return 0

def loan_access(w:mutbuf, v:u64) -> u64:
    if get(w, 264) == 0 or get(w, 280) == 0:
        return 0
    interned_count = get(w, 480)
    i = 0
    # Every live SSA identity was interned by read_value_name(). Slots
    # outside this current-function count retain type zero after table reset
    # and cannot satisfy loan_live(), including with dirty initial workspace.
    while i < interned_count:
        if loan_live(w, i) == 1 and get(w, CAPBASE + i * 24 + 8) == v + 1:
            return fail(w, 62)
        i = i + 1
    return 0

def loan_ancestor(w:mutbuf, candidate:u64, source:u64) -> u64:
    cursor = source + 1
    depth = 0
    while cursor != 0 and depth < 2048:
        if cursor == candidate + 1:
            return 1
        cursor = get(w, CAPBASE + (cursor - 1) * 24 + 8)
        depth = depth + 1
    if cursor != 0:
        fail(w, 62)
    return 0

def loan_operation(w:mutbuf, op:u64, n:u64, a:u64, at:u64, t:u64) -> u64:
    if n != 1 or at < 6 or at > 8:
        return fail(w, 62)
    if op == @loan.end@:
        if t != 0 or at > 7:
            return fail(w, 62)
        if get(w, 264) == 1:
            if get(w, CAPBASE + a * 24 + 8) == 0:
                return fail(w, 62)
            loan_access(w, a)
            put(w, CAPBASE + a * 24 + 16, 0)
            put(w, 280, get(w, 280) - 1)
        return 0
    if op == @borrow.read@:
        if t != 6:
            return fail(w, 62)
    else:
        if op != @borrow.mut@ or (at != 7 and at != 8) or t != 7:
            return fail(w, 62)
    return loan_borrow(w, a, t)

def loan_produce(w:mutbuf, v:u64, a:u64) -> u64:
    store(w, ORIGINBASE + v, byte(w, ORIGINBASE + a))
    put(w, CAPBASE + v * 24, get(w, CAPBASE + a * 24))
    put(w, CAPBASE + v * 24 + 8, a + 1)
    put(w, 280, get(w, 280) + 1)
    return 0

def loan_borrow(w:mutbuf, a:u64, t:u64) -> u64:
    if get(w, 264) == 0 or get(w, 280) == 0:
        return 0
    interned_count = get(w, 480)
    i = 0
    root = get(w, CAPBASE + a * 24)
    # Every live SSA identity was interned by read_value_name(). Slots
    # outside this current-function count retain type zero after table reset
    # and cannot satisfy loan_live(), including with dirty initial workspace.
    while i < interned_count:
        if loan_live(w, i) == 1 and get(w, CAPBASE + i * 24) == root:
            if loan_ancestor(w, i, a) == 0:
                if t == 7 or get(w, VBASE + i * 16) == 7:
                    return fail(w, 62)
        i = i + 1
    return 0

def loan_finish(w:mutbuf) -> u64:
    if get(w, 264) == 1 and (get(w, 280) != 0 or get(w, 352) != 0):
        return fail(w, 62)
    return 0

def loan_call(w:mutbuf, n:u64) -> u64:
    if get(w, 264) == 0:
        return 0
    i = 0
    j = 0
    v = 0
    other = 0
    while i < n:
        v = get(w, ARGS + i * 8)
        if resource_type(variable(w, v)) == 1:
            if owner_type(variable(w, v)) == 1:
                owner_free(w, v)
            else:
                loan_access(w, v)
            j = 0
            while j < i:
                other = get(w, ARGS + j * 8)
                if resource_type(variable(w, other)) == 1 and get(w, CAPBASE + v * 24) == get(w, CAPBASE + other * 24):
                    if variable(w, v) >= 7 or variable(w, other) >= 7:
                        return fail(w, 62)
                j = j + 1
        i = i + 1
    return 0

def loan_incoming(w:mutbuf, bb:u64, count:u64, block:u64) -> u64:
    if get(w, 432) == 1:
        put(w, 264, 0)
        return 0
    put(w, 280, 0)
    put(w, 352, 0)
    i = 0
    v = 0
    packed = 0
    root = 0
    parent = 0
    origin = 0
    if block == get(w, FBASE + get(w, 72) * FSTRIDE + 264):
        while i < 16:
            packed = 0
            if i < count and resource_type(get(w, bb + 40 + i * 16)) == 1:
                packed = i | (i << 4)
            store(w, bb + 304 + i, packed)
            origin = 0
            if i < count and (get(w, bb + 40 + i * 16) == 6 or get(w, bb + 40 + i * 16) == 7):
                origin = i + 1
            store(w, BLOCKORIGIN + get(w, 88) * 16 + i, origin)
            i = i + 1
        store(w, KBASE + get(w, 88), 1)
    put(w, 264, byte(w, KBASE + get(w, 88)))
    if get(w, 264) == 0:
        if get(w, 48) != 0:
            return fail(w, 62)
        return 0
    put(w, 272, get(w, 272) + 1)
    put(w, bb + 24, 1)
    i = 0
    while i < count:
        v = get(w, bb + 32 + i * 16)
        store(w, ORIGINBASE + v, byte(w, BLOCKORIGIN + get(w, 88) * 16 + i))
        if resource_type(get(w, bb + 40 + i * 16)) == 1:
            packed = byte(w, bb + 304 + i)
            root = packed & 15
            parent = packed >> 4
            if root >= count or parent >= count:
                return fail(w, 62)
            if resource_type(get(w, bb + 40 + root * 16)) == 0 or resource_type(get(w, bb + 40 + parent * 16)) == 0:
                return fail(w, 62)
            if owner_type(get(w, bb + 40 + i * 16)) == 1:
                if root != i or parent != i:
                    return fail(w, 62)
                put(w, 352, get(w, 352) + 1)
            put(w, CAPBASE + v * 24, get(w, bb + 32 + root * 16))
            if root == i and parent == i:
                put(w, CAPBASE + v * 24 + 8, 0)
            else:
                if parent == i:
                    return fail(w, 62)
                put(w, CAPBASE + v * 24 + 8, get(w, bb + 32 + parent * 16) + 1)
                put(w, 280, get(w, 280) + 1)
        i = i + 1
    return 0

def loan_argument(w:mutbuf, n:u64, v:u64) -> u64:
    i = 0
    while i < n:
        if get(w, ARGS + i * 8) == v:
            return i
        i = i + 1
    fail(w, 62)
    return 16

def loan_transfer(w:mutbuf, bid:u64, n:u64) -> u64:
    if get(w, 264) == 0:
        return 0
    interned_count = get(w, 480)
    i = 0
    v = 0
    root = 0
    parent = 0
    packed = 0
    origin = 0
    while i < interned_count and (get(w, 280) != 0 or get(w, 352) != 0):
        if loan_live(w, i) == 1 and (get(w, CAPBASE + i * 24 + 8) != 0 or owner_type(get(w, VBASE + i * 16)) == 1):
            loan_argument(w, n, i)
        i = i + 1
    i = 0
    while i < 16:
        packed = 0
        if i < n:
            v = get(w, ARGS + i * 8)
            if resource_type(variable(w, v)) == 1:
                root = loan_argument(w, n, get(w, CAPBASE + v * 24))
                parent = get(w, CAPBASE + v * 24 + 8)
                if parent == 0:
                    parent = i
                else:
                    parent = loan_argument(w, n, parent - 1)
                packed = root | (parent << 4)
        store(w, CAPTMP + i, packed)
        i = i + 1
    i = 0
    while i < 16:
        packed = byte(w, CAPTMP + i)
        origin = 0
        if i < n:
            origin = byte(w, ORIGINBASE + get(w, ARGS + i * 8))
        if byte(w, KBASE + bid) == 1:
            if origin != byte(w, BLOCKORIGIN + bid * 16 + i):
                return fail(w, 62)
            if packed != byte(w, BBASE + bid * BSTRIDE + 304 + i):
                return fail(w, 62)
        else:
            store(w, BBASE + bid * BSTRIDE + 304 + i, packed)
            store(w, BLOCKORIGIN + bid * 16 + i, origin)
        i = i + 1
    if byte(w, KBASE + bid) == 0:
        if get(w, 384) >= 256:
            return fail(w, 62)
        put(w, QBASE + get(w, 384) * 8, bid)
        put(w, 384, get(w, 384) + 1)
    store(w, KBASE + bid, 1)
    return 0

def owner_free(w:mutbuf, v:u64) -> u64:
    if owner_type(variable(w, v)) == 0:
        return fail(w, 62)
    if get(w, 264) == 0:
        return 0
    interned_count = get(w, 480)
    i = 0
    while i < interned_count:
        if i != v and loan_live(w, i) == 1 and get(w, CAPBASE + i * 24) == v:
            return fail(w, 62)
        i = i + 1
    return 0

def owner_produce(w:mutbuf, v:u64) -> u64:
    if owner_type(variable(w, v)) == 0:
        return fail(w, 62)
    put(w, CAPBASE + v * 24, v)
    put(w, CAPBASE + v * 24 + 8, 0)
    put(w, CAPBASE + v * 24 + 16, 1)
    put(w, 352, get(w, 352) + 1)
    return 0

def owner_consume(w:mutbuf, v:u64) -> u64:
    if get(w, 264) == 0:
        return 0
    if owner_type(variable(w, v)) == 0 or get(w, 352) == 0:
        return fail(w, 62)
    put(w, CAPBASE + v * 24 + 16, 0)
    put(w, 352, get(w, 352) - 1)
    return 0

def owner_call_consume(w:mutbuf, n:u64) -> u64:
    if get(w, 264) == 0:
        return 0
    i = 0
    v = 0
    while i < n:
        v = get(w, ARGS + i * 8)
        if owner_type(variable(w, v)) == 1:
            owner_consume(w, v)
        i = i + 1
    return 0

# Scalar codes are not an ordered prefix once u16 is admitted. Resource
# predicates stay closed so scalar words never acquire owner/loan state.
def resource_type(t:u64) -> u64:
    if t >= 6 and t <= 9:
        return 1
    return 0

def owner_type(t:u64) -> u64:
    if t == 8 or t == 9:
        return 1
    return 0


def owned_read_outputs(s:readbuf, w:mutbuf) -> u64:
    put(w, 288, 0)
    put(w, RESULT_OUTPUTS, 2048)
    put(w, RESULT_OUTPUTS + 8, 0)
    if get(w, 8) == 95 and instruction_ahead(s, w) == 2:
        next_token(s, w)
        return 0
    count = 0
    v = 0
    t = 0
    while get(w, 8) != 61 and get(w, 40) == 0:
        if count >= MAX_RESULTS:
            return fail(w, 66)
        v = expect(s, w, 256)
        put(w, RESULT_NAMES + count * 16, get(w, 456))
        put(w, RESULT_NAMES + count * 16 + 8, get(w, 464))
        expect(s, w, 58)
        t = read_type(s, w)
        put(w, RESULT_OUTPUTS + count * 16, v)
        put(w, RESULT_OUTPUTS + 8 + count * 16, t)
        count = count + 1
        if get(w, 8) != 61:
            expect(s, w, 44)
            if get(w, 8) == 61:
                return fail(w, 66)
    put(w, 288, count)
    if count == 0:
        return fail(w, 66)
    return 0

def owned_define_outputs(w:mutbuf) -> u64:
    i = 0
    v = 0
    t = 0
    if get(w, 40) != 0:
        return 0
    while i < get(w, 288):
        v = get(w, RESULT_OUTPUTS + i * 16)
        t = get(w, RESULT_OUTPUTS + 8 + i * 16)
        define(w, v, t)
        if get(w, 40) != 0:
            return 0
        if t == 8 or t == 9:
            owner_produce(w, v)
        i = i + 1
    return 0

def owned_branch(o:mutbuf, w:mutbuf, condition:u64) -> u64:
    if condition == 0:
        emit(o, w, 233)
    else:
        emit(o, w, 15)
        emit(o, w, condition)
    at = get(w, 56)
    emit4(o, w, 0)
    return at

def owned_patch(o:mutbuf, w:mutbuf, at:u64) -> u64:
    if get(w, 48) == 2:
        write4(o, at, get(w, 56) - at - 4)
    return 0

def owned_immediate(o:mutbuf, w:mutbuf, value:u64, out:u64, word:u64) -> u64:
    emit_bytes(o, w, 47176, 2)
    emit8(o, w, value)
    store_var(o, w, out, word)
    return 0

def owned_import(o:mutbuf, w:mutbuf, symbol:u64) -> u64:
    if get(w, 232) != 1 or symbol > 1:
        return fail(w, 64)
    put(w, 344, get(w, 344) + 1)
    emit(o, w, 232)
    relocation(o, w, 3, symbol)
    return 0

def owned_allocate_libc(o:mutbuf, w:mutbuf, size:u64, out:u64, ok:u64, trapping:u64) -> u64:
    load_var(o, w, 6, size, 0)
    emit_bytes(o, w, 16155976, 3)
    empty = owned_branch(o, w, 132)
    oversize = owned_branch(o, w, 136)
    emit_bytes(o, w, 48968, 2)
    emit8(o, w, 1)
    owned_import(o, w, 0)
    emit_bytes(o, w, 12617032, 3)
    failed = owned_branch(o, w, 132)
    store_var(o, w, out, 0)
    load_var(o, w, 0, size, 0)
    store_var(o, w, out, 1)
    if trapping == 0:
        owned_immediate(o, w, 1, ok, 0)
    done = owned_branch(o, w, 0)
    owned_patch(o, w, empty)
    owned_immediate(o, w, 0, out, 0)
    owned_immediate(o, w, 0, out, 1)
    if trapping == 0:
        owned_immediate(o, w, 1, ok, 0)
    empty_done = owned_branch(o, w, 0)
    owned_patch(o, w, oversize)
    owned_patch(o, w, failed)
    if trapping == 1:
        emit_bytes(o, w, 2831, 2)
    else:
        owned_immediate(o, w, 0, out, 0)
        owned_immediate(o, w, 0, out, 1)
        owned_immediate(o, w, 0, ok, 0)
    owned_patch(o, w, done)
    owned_patch(o, w, empty_done)
    return 0

def owned_drop_libc(o:mutbuf, w:mutbuf, source:u64) -> u64:
    load_var(o, w, 7, source, 0)
    emit_bytes(o, w, 16745800, 3)
    empty = owned_branch(o, w, 132)
    owned_import(o, w, 1)
    owned_patch(o, w, empty)
    return 0

def owned_move_buffer(o:mutbuf, w:mutbuf, source:u64, out:u64) -> u64:
    load_var(o, w, 0, source, 0)
    store_var(o, w, out, 0)
    load_var(o, w, 0, source, 1)
    store_var(o, w, out, 1)
    return 0

def owned_instruction(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, at:u64) -> u64:
    if get(w, 232) != 1:
        return fail(w, 64)
    if op >= @chain.empty@:
        return chain_instruction(o, w, op, n, a, at)
    count = get(w, 288)
    out = get(w, RESULT_OUTPUTS)
    t = get(w, RESULT_OUTPUTS + 8)
    if n != 1:
        return fail(w, 63)
    if op == @owner.move@ or op == @owner.drop@:
        if at != 8 and at != 9:
            return fail(w, 63)
        owner_free(w, a)
        if get(w, 40) != 0:
            return 0
        if op == @owner.move@:
            if count != 1 or t != at:
                return fail(w, 63)
            owned_move_buffer(o, w, a, out)
        else:
            if count != 0:
                return fail(w, 63)
            require_effects(w, 1)
            if at == 9:
                chain_drop_call(o, w, a)
            else:
                owned_drop_libc(o, w, a)
        owner_consume(w, a)
        return 0
    if at != 2 or t != 8:
        return fail(w, 63)
    require_effects(w, 1)
    trapping = 0
    ok = get(w, RESULT_OUTPUTS + 16)
    if op == @buffer.new@:
        if count != 1:
            return fail(w, 63)
        trapping = 1
    else:
        if op != @buffer.try_new@ or count != 2 or get(w, RESULT_OUTPUTS + 24) != 5:
            return fail(w, 63)
    owned_allocate_libc(o, w, a, out, ok, trapping)
    return 0

def owned_elf_relocations(o:mutbuf, w:mutbuf) -> u64:
    i = 0
    symbol_base = 3
    if get(w, 640) == 1:
        symbol_base = get(w, 648) + 2
    if get(w, 48) == 1:
        while i < get(w, 344):
            emit8(o, w, 0)
            emit8(o, w, 0)
            emit8(o, w, 0)
            i = i + 1
    else:
        while i < get(w, 224):
            if (get(w, FIXBASE + i * 16) >> 32) == 3:
                emit8(o, w, (get(w, FIXBASE + i * 16) & 4294967295) - 64)
                emit8(o, w, ((get(w, FIXBASE + i * 16 + 8) + symbol_base) << 32) | 4)
                emit8(o, w, 18446744073709551612)
            i = i + 1
    return 0

def owned_elf_finish(o:mutbuf, w:mutbuf) -> u64:
    text = get(w, 56) - 64
    align8(o, w)
    symbols = get(w, 56)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 281487861612544)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 281552286121985)
    emit8(o, w, 0)
    emit8(o, w, get(w, 240) - 64)
    emit8(o, w, 77309411332)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 77309411339)
    emit8(o, w, 0)
    emit8(o, w, 0)
    strings = get(w, 56)
    emit_bytes(o, w, 7812726531413796352, 8)
    emit_bytes(o, w, 28540514659754863, 8)
    names = get(w, 56)
    emit_bytes(o, w, 3314777386191695360, 8)
    emit_bytes(o, w, 3314757496449366387, 8)
    emit_bytes(o, w, 3314757496449692787, 8)
    emit_bytes(o, w, 7089075323386685555, 8)
    emit_bytes(o, w, 5129148576381677056, 8)
    emit_bytes(o, w, 7738135737529095502, 8)
    emit_bytes(o, w, 8371735875514674688, 8)
    emit_bytes(o, w, 7632997, 4)
    align8(o, w)
    relocs = get(w, 56)
    owned_elf_relocations(o, w)
    headers = get(w, 56)
    if get(w, 48) == 2:
        put(o, 40, headers)
        write4(o, 60, 262151)
    elf_section(o, w, 0, 0, 0, 0, 0, 0, 0)
    elf_section(o, w, 4294967297, 6, 64, text, 0, 16, 0)
    elf_section(o, w, 8589934599, 0, symbols, 120, 8589934595, 8, 24)
    elf_section(o, w, 12884901903, 0, strings, 16, 0, 1, 0)
    elf_section(o, w, 12884901911, 0, names, 60, 0, 1, 0)
    elf_section(o, w, 4294967329, 0, names + 60, 0, 0, 1, 0)
    elf_section(o, w, 17179869233, 0, relocs, get(w, 344) * 24, 4294967298, 8, 24)
    return 0

def chain_drop_call(o:mutbuf, w:mutbuf, source:u64) -> u64:
    put(w, 360, 1)
    load_var(o, w, 7, source, 0)
    emit(o, w, 232)
    relocation(o, w, 4, 0)
    return 0

def chain_drop_helper(o:mutbuf, w:mutbuf) -> u64:
    if get(w, 360) == 0:
        return 0
    put(w, 368, get(w, 56))
    chain_bytes_drop(o, w)
    return 0

def chain_store_transfer(o:mutbuf, w:mutbuf, out:u64, payload:u64, ok:u64) -> u64:
    store_var(o, w, out, 0)
    emit_bytes(o, w, 12595528, 3)
    store_var(o, w, out, 1)
    emit_bytes(o, w, 13142344, 3)
    store_var(o, w, payload, 0)
    emit_bytes(o, w, 13666632, 3)
    store_var(o, w, payload, 1)
    emit_bytes(o, w, 12618060, 3)
    store_var(o, w, ok, 0)
    return 0

def chain_instruction(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, at:u64) -> u64:
    count = get(w, 288)
    out = get(w, RESULT_OUTPUTS)
    t = get(w, RESULT_OUTPUTS + 8)
    if op == @chain.empty@:
        if n != 0 or count != 1 or t != 9:
            return fail(w, 67)
        owned_immediate(o, w, 0, out, 0)
        owned_immediate(o, w, 0, out, 1)
        return 0
    if n == 0 or at != 9:
        return fail(w, 67)
    if op == @chain.is_empty@:
        if n != 1 or count != 1 or t != 5:
            return fail(w, 67)
        load_var(o, w, 0, a, 0)
        chain_bytes_is_empty(o, w)
        store_var(o, w, out, 0)
        return 0
    if op == @chain.head_read@ or op == @chain.head_mut@:
        want = 6 + op - @chain.head_read@
        if n != 1 or count != 1 or t != want:
            return fail(w, 67)
        loan_borrow(w, a, t)
        load_var(o, w, 0, a, 0)
        chain_bytes_head(o, w)
        store_var(o, w, out, 0)
        emit_bytes(o, w, 13666632, 3)
        store_var(o, w, out, 1)
        return 0
    if count != 3 or t != 9 or get(w, RESULT_OUTPUTS + 24) != 8 or get(w, RESULT_OUTPUTS + 40) != 5:
        return fail(w, 67)
    require_effects(w, 1)
    owner_free(w, a)
    if get(w, 40) != 0:
        return 0
    if op == @chain.try_push@:
        if n != 2:
            return fail(w, 67)
        b = get(w, ARGS + 8)
        if variable(w, b) != 8:
            return fail(w, 67)
        owner_free(w, b)
        if get(w, 40) != 0:
            return 0
        load_var(o, w, 7, a, 0)
        load_var(o, w, 6, b, 0)
        load_var(o, w, 2, b, 1)
        chain_bytes_push(o, w)
        owner_consume(w, b)
    else:
        if op != @chain.pop@ or n != 1:
            return fail(w, 67)
        load_var(o, w, 7, a, 0)
        chain_bytes_pop(o, w)
    chain_store_transfer(o, w, out, get(w, RESULT_OUTPUTS + 16), get(w, RESULT_OUTPUTS + 32))
    owner_consume(w, a)
    return 0
def chain_bytes_push(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 6269010681449447752, 8)
    emit_bytes(o, w, 7504155222, 8)
    emit_bytes(o, w, 6964615887978496, 8)
    emit_bytes(o, w, 0, 6)
    owned_import(o, w, 0)
    emit_bytes(o, w, 2467859357718874, 8)
    emit_bytes(o, w, 4072397282593996800, 8)
    emit_bytes(o, w, 150123199856640, 8)
    emit_bytes(o, w, 9416871510016, 8)
    emit_bytes(o, w, 71815481344, 8)
    emit_bytes(o, w, 47432, 8)
    emit_bytes(o, w, 3125280768, 8)
    emit_bytes(o, w, 484098648834048, 8)
    emit_bytes(o, w, 1002332392066646016, 8)
    emit_bytes(o, w, 13279418244780785664, 8)
    emit_bytes(o, w, 0, 8)
    return 0

def chain_bytes_pop(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 67637413381448, 8)
    emit_bytes(o, w, 70993528832, 8)
    emit_bytes(o, w, 2408269904, 8)
    emit_bytes(o, w, 36902226001, 8)
    emit_bytes(o, w, 38327634002, 8)
    owned_import(o, w, 1)
    emit_bytes(o, w, 6485183463560610120, 8)
    emit_bytes(o, w, 7386781785, 8)
    emit_bytes(o, w, 44981192491008, 8)
    emit_bytes(o, w, 12077056, 8)
    emit_bytes(o, w, 795776909312, 8)
    emit_bytes(o, w, 52433510505381888, 8)
    emit_bytes(o, w, 5260204364768739328, 8)
    emit_bytes(o, w, 184, 8)
    emit_bytes(o, w, 0, 1)
    return 0

def chain_bytes_drop(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 1219491749199169621, 8)
    emit_bytes(o, w, 18444700671211995136, 8)
    emit_bytes(o, w, 18446735919903473663, 8)
    emit_bytes(o, w, 18722551954229503, 8)
    emit_bytes(o, w, 18152868544512, 8)
    emit_bytes(o, w, 18446744007230441472, 8)
    emit_bytes(o, w, 5188146770743036744, 8)
    emit_bytes(o, w, 23690477445, 8)
    owned_import(o, w, 1)
    emit_bytes(o, w, 72057593916132168, 7)
    owned_import(o, w, 1)
    emit_bytes(o, w, 5260204364509055816, 8)
    emit_bytes(o, w, 12603886507149264265, 8)
    emit_bytes(o, w, 840907620351, 5)
    return 0

def chain_bytes_head(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 2770518181192, 8)
    emit_bytes(o, w, 2410727697223424, 8)
    emit_bytes(o, w, 552092565504, 8)
    emit_bytes(o, w, 0, 1)
    return 0

def chain_bytes_is_empty(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 13118915981705512264, 8)
    emit_bytes(o, w, 192, 1)
    return 0


def cast_integer(o:mutbuf, w:mutbuf, t:u64, checked:u64, at:u64) -> u64:
    if checked == 1:
        if signed_type(at) != signed_type(t):
            # Reject a negative mathematical source or an unsigned source
            # beyond signed64 before a sign-changing cast can preserve bits.
            emit_bytes(o, w, 3112728050828616, 7)
        # Scalar slots are canonically sign/zero extended. Keep the full source in
        # rcx, normalize the result, then require equality before later effects.
        # The preceding sign guard prevents same-bit sign-changing false matches.
        emit_bytes(o, w, 12683592, 3)
        normalize(o, w, t)
        # cmp rax,rcx; je +2; ud2
        emit_bytes(o, w, 3112727967447368, 7)
        return 0
    normalize(o, w, t)
    return 0

def parse_effects(s:readbuf, w:mutbuf) -> u64:
    mask = 0
    token = get(w, 8)
    failed = get(w, 40)
    while token != 41 and failed == 0:
        flag = 1
        if token == @privilege@ or token == @atomic@:
            if get(w, 200) != 1:
                return fail(w, 65)
            flag = 16 << (token - @privilege@)
        else:
            if token != @alloc@:
                if token < @read@ or token > @trap@:
                    return fail(w, 65)
                flag = 2 << (token - @read@)
        if (mask & flag) != 0:
            return fail(w, 65)
        mask = mask | flag
        account_nodes(w, 1)
        next_token(s, w)
        if get(w, 8) != 41:
            expect(s, w, 44)
            if get(w, 8) == 41:
                return fail(w, 65)
        token = get(w, 8)
        failed = get(w, 40)
    expect(s, w, 41)
    return mask

def require_effects(w:mutbuf, required:u64) -> u64:
    declared = get(w, FBASE + get(w, 72) * FSTRIDE + 176)
    if (declared & required) != required:
        return fail(w, 65)
    return 0

def instruction_effects(op:u64) -> u64:
    if op >= @x86.irq.dispatch_on_stack@ and op <= @x86.irq.dispatch_frame_slab@:
        return 62
    if op == @x86.irq.dispatch_kernel_frame@:
        return 30
    if op == @x86.irq.restore_kernel_frame@:
        return 26
    if op == @x86.tr.load@ or op == @x86.tr.read@:
        return 24
    if op == @x86.irq.iretq_user@:
        return 24
    if op == @x86.idtr.load@:
        return 26
    if op == @x86.idtr.store@:
        return 28
    if op == @x86.msr.read@ or op == @x86.msr.write@:
        return 24
    if op == @x86.fence.mfence@:
        return 32
    if op == @x86.mmio.read32@:
        return 26
    if op == @x86.mmio.write32@:
        return 28
    if op == @x86.atomic.cmpxchg64@:
        return 62
    if op >= @x86.tlb.invlpg@ and op <= @x86.io.out32@:
        return 16
    if op >= 339 and op <= 354:
        return (36507222016 >> ((op - 339) * 4)) & 15
    if op >= 355 and op <= 370:
        return (9836011179901321216 >> ((op - 355) * 4)) & 15
    if op >= 371 and op <= 386:
        return (1157452592040569928 >> ((op - 371) * 4)) & 15
    if op >= 387 and op <= 402:
        return (12249790986447792641 >> ((op - 387) * 4)) & 15
    if op >= 403 and op <= 404:
        return (204 >> ((op - 403) * 4)) & 15
    return 0

def read_result_types(s:readbuf, w:mutbuf) -> u64:
    base = FBASE + get(w, 72) * FSTRIDE
    count = 0
    first = 0
    t = 0
    while get(w, 8) != 41 and get(w, 40) == 0:
        if count >= MAX_RESULTS:
            return fail(w, 3)
        t = read_type(s, w)
        if scalar_type(t) != 1 and resource_type(t) != 1:
            return fail(w, 3)
        if count == 0:
            first = t
        if get(w, 48) == 0:
            put(w, base + 192 + result_offset(count), t)
        count = count + 1
        if get(w, 8) != 41:
            expect(s, w, 44)
            if get(w, 8) == 41:
                return fail(w, 3)
    expect(s, w, 41)
    if get(w, 48) == 0:
        put(w, base + 184, count)
    account_nodes(w, count)
    return first

def return_results(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    base = FBASE + get(w, 72) * FSTRIDE
    count = 0
    v = 0
    t = 0
    expect(s, w, 40)
    while get(w, 8) != 41 and get(w, 40) == 0:
        if count >= get(w, base + 184):
            return fail(w, 13)
        v = expect(s, w, 256)
        t = variable(w, v)
        if t != get(w, base + 192 + result_offset(count)):
            return fail(w, 13)
        if owner_type(t) == 1:
            owner_free(w, v)
        if t == 6 or t == 7:
            returned_loan(w, v, get(w, base + 216 + result_offset(count)))
        put(w, RESULT_RETURNED + count * 8, v)
        if get(w, 256) == 0:
            load_var(o, w, 0, v, 0)
            mem(o, w, 139, 2, 5, 18446744073709551608)
            mem(o, w, 137, 0, 2, count * 16)
            if resource_type(t) == 1:
                load_var(o, w, 0, v, 1)
                mem(o, w, 137, 0, 2, count * 16 + 8)
        count = count + 1
        if get(w, 8) != 41:
            expect(s, w, 44)
            if get(w, 8) == 41:
                return fail(w, 13)
    expect(s, w, 41)
    if count != get(w, base + 184):
        return fail(w, 13)
    i = 0
    while i < count:
        returned_consume(w, get(w, RESULT_RETURNED + i * 8), get(w, base + 192 + result_offset(i)))
        i = i + 1
    loan_finish(w)
    account_nodes(w, 3 + count)
    if get(w, 256) == 0:
        emit_bytes(o, w, 50121, 2)
    return 0

def call_results(o:mutbuf, w:mutbuf, callee:u64) -> u64:
    if get(w, 40) != 0:
        return 0
    base = FBASE + callee * FSTRIDE
    count = get(w, 288)
    i = 0
    v = 0
    t = 0
    if get(w, 48) > 0:
        if count != get(w, base + 184):
            return fail(w, 24)
    while i < count:
        v = get(w, RESULT_OUTPUTS + i * 16)
        t = get(w, RESULT_OUTPUTS + 8 + i * 16)
        if scalar_type(t) != 1 and resource_type(t) != 1:
            return fail(w, 24)
        if get(w, 48) > 0:
            if t != get(w, base + 192 + result_offset(i)):
                return fail(w, 24)
        define(w, v, t)
        if get(w, 40) != 0:
            return 0
        if owner_type(t) == 1:
            owner_produce(w, v)
        if t == 6 or t == 7:
            call_loan(w, base, i, v, t)
        if get(w, 256) == 0:
            mem(o, w, 139, 0, 5, 0 - frame(w) + 512 + i * 16)
            store_var(o, w, v, 0)
            if resource_type(t) == 1:
                mem(o, w, 139, 0, 5, 0 - frame(w) + 512 + i * 16 + 8)
                store_var(o, w, v, 1)
        i = i + 1
    return 0

def integer_type(t:u64) -> u64:
    if (t >= 1 and t <= 4) or (t >= 10 and t <= 15):
        return 1
    return 0

def signed_type(t:u64) -> u64:
    if t >= 11 and t <= 15:
        return 1
    return 0

def scalar_type(t:u64) -> u64:
    if integer_type(t) == 1 or t == 5 or t == 16:
        return 1
    return 0

def integer_width(t:u64) -> u64:
    width = 64
    if t == 4 or t == 14:
        width = 8
    if t == 10 or t == 15:
        width = 16
    if t == 3 or t == 13:
        width = 32
    return width

def scalar_literal(s:readbuf, w:mutbuf, t:u64) -> u64:
    if t == 5:
        if get(w, 8) == @true@:
            next_token(s, w)
            return 1
        expect(s, w, @false@)
        return 0
    if t == 16:
        expect(s, w, @null@)
        return 0
    if integer_type(t) != 1:
        return fail(w, 22)
    negative = 0
    x = 0
    width = integer_width(t)
    limit = 0
    if get(w, 8) == 45:
        negative = 1
        next_token(s, w)
        adjacent(w)
    x = expect(s, w, 259)
    if signed_type(t) == 1:
        limit = 1 << (width - 1)
        if negative == 1:
            if x > limit:
                return fail(w, 22)
            return 0 - x
        if x >= limit:
            return fail(w, 22)
    else:
        if negative == 1:
            return fail(w, 22)
        if width < 64:
            if x >= (1 << width):
                return fail(w, 22)
    return x

def signed_integer(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    if t != at:
        return fail(w, 34)
    if op == @bit.not@ or op == @int.neg.checked@:
        if n != 1:
            return fail(w, 31)
        load_var(o, w, 0, a, 0)
        emit_bytes(o, w, 63304, 2)
        if op == @bit.not@:
            emit(o, w, 208)
            normalize(o, w, t)
            return 0
        emit(o, w, 216)
    else:
        if n != 2 or at != bt:
            return fail(w, 34)
        load_var(o, w, 0, a, 0)
        load_var(o, w, 1, b, 0)
        if op == @int.div.checked@ or op == @int.rem.checked@:
            # test rcx,rcx; jne +2; ud2. Reject zero before IDIV.
            emit_bytes(o, w, 3112727984309576, 7)
            # The Core rejects MIN/-1 for both quotient and remainder at every
            # width, not just the hardware's 64-bit quotient overflow.
            emit_bytes(o, w, 47688, 2)
            emit8(o, w, 0 - (1 << (integer_width(t) - 1)))
            # cmp rax,rdx; jne +8; cmp rcx,-1; jne +2; ud2
            emit_bytes(o, w, 17979293338566670664, 8)
            emit_bytes(o, w, 47496459775, 5)
            # cqo; idiv rcx
            emit_bytes(o, w, 1073595586888, 5)
            if op == @int.rem.checked@:
                emit_bytes(o, w, 13666632, 3)
            return 0
        emit(o, w, 72)
        if op == @int.mul.checked@:
            emit_bytes(o, w, 12693263, 3)
        else:
            if op == @int.add.checked@:
                emit(o, w, 1)
            else:
                if op != @int.sub.checked@:
                    return fail(w, 36)
                emit(o, w, 41)
            emit(o, w, 200)
    # jno +2; ud2. OF is consumed immediately after add/sub/imul/neg.
    emit_bytes(o, w, 185533041, 4)
    # Preserve the exact full result, then require narrow sign normalization
    # not to change it. This also checks subtraction and unary negation.
    emit_bytes(o, w, 12683592, 3)
    normalize(o, w, t)
    emit_bytes(o, w, 3112727967447368, 7)
    return 0

def explicit_trap(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    require_effects(w, 8)
    next_token(s, w)
    separated(w)
    code = get(w, 8)
    if get(w, 200) >= 2 and code != @user@:
        return fail(w, 67)
    if code < @allocation@ or code > @user@:
        return fail(w, 67)
    next_token(s, w)
    account_nodes(w, 3)
    emit_bytes(o, w, 2831, 2)
    return 0

def read_return_loans(s:readbuf, w:mutbuf) -> u64:
    base = FBASE + get(w, 72) * FSTRIDE
    count = get(w, base + 184)
    i = 0
    origin = 0
    t = 0
    formal = 0
    present = 0
    if get(w, 8) == @return_loans@:
        if get(w, SCHEMA_STATE) < @hepta.hia.program.v8@:
            return fail(w, 62)
        present = 1
        separated(w)
        next_token(s, w)
        adjacent(w)
        expect(s, w, 40)
        expect(s, w, 91)
    while i < count and get(w, 40) == 0:
        origin = 0
        t = get(w, base + 192 + result_offset(i))
        if present == 1:
            if get(w, 8) == @null@:
                next_token(s, w)
            else:
                formal = expect(s, w, 260)
                if formal >= get(w, base + 24):
                    return fail(w, 62)
                origin = formal + 1
                formal = get(w, base + 48 + formal * 8)
                if (formal != 6 and formal != 7) or (t == 7 and formal != 7):
                    return fail(w, 62)
        if (t == 6 or t == 7) != (origin != 0):
            return fail(w, 62)
        if get(w, 48) == 0:
            put(w, base + 216 + result_offset(i), origin)
        i = i + 1
        if present == 1 and i < count:
            expect(s, w, 44)
    if present == 1:
        expect(s, w, 93)
        expect(s, w, 41)
        account_nodes(w, 1 + count)
    return 0

def returned_loan(w:mutbuf, v:u64, origin:u64) -> u64:
    if get(w, 264) == 0:
        return 0
    if origin == 0 or byte(w, ORIGINBASE + v) != origin:
        return fail(w, 62)
    loan_access(w, v)
    parent = get(w, CAPBASE + v * 24 + 8)
    if parent != 0:
        if get(w, CAPBASE + (parent - 1) * 24 + 8) != 0:
            return fail(w, 62)
    return 0

def returned_consume(w:mutbuf, v:u64, t:u64) -> u64:
    # All returned capabilities are validated before consuming any of them.
    # variable() still rejects duplicated result identities at this second pass.
    if get(w, 264) == 0:
        return 0
    if owner_type(t) == 1:
        return owner_consume(w, v)
    if t == 6 or t == 7:
        variable(w, v)
        if get(w, CAPBASE + v * 24 + 8) != 0:
            put(w, 280, get(w, 280) - 1)
        put(w, CAPBASE + v * 24 + 16, 0)
    return 0

def call_loan(w:mutbuf, base:u64, slot:u64, v:u64, t:u64) -> u64:
    if get(w, 264) == 0:
        return 0
    origin = get(w, base + 216 + result_offset(slot))
    if origin == 0 or origin > get(w, base + 24):
        return fail(w, 62)
    a = get(w, ARGS + (origin - 1) * 8)
    loan_borrow(w, a, t)
    loan_produce(w, v, a)
    return 0

def cli_begin(o:mutbuf, w:mutbuf) -> u64:
    emit_bytes(o, w, 282584257676671, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 4299030530, 8)
    emit_bytes(o, w, 4194480, 8)
    emit_bytes(o, w, 64, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 15762873573703680, 8)
    emit_bytes(o, w, 2, 8)
    emit_bytes(o, w, 21474836481, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 4194304, 8)
    emit_bytes(o, w, 4194304, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 4096, 8)
    emit_bytes(o, w, 27455186257, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 0, 8)
    emit_bytes(o, w, 16, 8)
    emit_bytes(o, w, 4902912840, 5)

    put(w, 512, owned_branch(o, w, 133))
    emit_bytes(o, w, 13402782859811290929, 8)
    emit_bytes(o, w, 9774937543802883, 8)
    emit_bytes(o, w, 18446743802175094784, 8)
    emit_bytes(o, w, 10689254082047, 8)
    emit_bytes(o, w, 18442241836795105024, 8)
    emit_bytes(o, w, 255, 1)

    put(w, 520, owned_branch(o, w, 131))
    emit_bytes(o, w, 260795879688521, 6)

    reading = get(w, 56)
    emit_bytes(o, w, 3185326194001297457, 8)
    emit_bytes(o, w, 16873101042072420794, 8)
    emit_bytes(o, w, 278144284624143, 6)

    cli_to(o, w, 132, reading)
    emit_bytes(o, w, 12617032, 3)

    put(w, 528, owned_branch(o, w, 136))
    put(w, 536, owned_branch(o, w, 132))
    emit_bytes(o, w, 278731730256201, 8)
    emit_bytes(o, w, 16, 2)

    put(w, 544, owned_branch(o, w, 135))
    cli_to(o, w, 0, reading)
    owned_patch(o, w, get(w, 536))
    emit_bytes(o, w, 10180930706115889484, 8)
    emit_bytes(o, w, 52072939410957460, 8)
    emit_bytes(o, w, 10278841578688512, 8)
    emit_bytes(o, w, 2305843804873170944, 8)
    emit_bytes(o, w, 59392, 2)

    put(w, 440, get(w, 56))
    emit4(o, w, 0)
    emit_bytes(o, w, 16775299, 3)

    put(w, 560, owned_branch(o, w, 132))
    emit_bytes(o, w, 16709763, 3)

    put(w, 568, owned_branch(o, w, 132))
    emit_bytes(o, w, 268435517, 5)

    put(w, 576, owned_branch(o, w, 135))
    emit_bytes(o, w, 10340414242851137, 8)
    emit_bytes(o, w, 4096, 3)

    writing = get(w, 56)
    emit_bytes(o, w, 16155981, 3)

    put(w, 584, owned_branch(o, w, 132))
    emit_bytes(o, w, 491481697616312, 8)
    emit_bytes(o, w, 17476584485096783872, 8)
    emit_bytes(o, w, 278144284624143, 6)

    cli_to(o, w, 132, writing)
    emit_bytes(o, w, 12617032, 3)

    put(w, 592, owned_branch(o, w, 142))
    emit_bytes(o, w, 217880633737545, 6)

    cli_to(o, w, 0, writing)
    owned_patch(o, w, get(w, 584))
    emit_bytes(o, w, 65329, 2)

    put(w, 600, owned_branch(o, w, 0))
    owned_patch(o, w, get(w, 560))
    emit_bytes(o, w, 703, 5)

    put(w, 608, owned_branch(o, w, 0))
    owned_patch(o, w, get(w, 544))
    owned_patch(o, w, get(w, 568))
    owned_patch(o, w, get(w, 576))
    emit_bytes(o, w, 959, 5)

    put(w, 616, owned_branch(o, w, 0))
    owned_patch(o, w, get(w, 520))
    owned_patch(o, w, get(w, 528))
    owned_patch(o, w, get(w, 592))
    emit_bytes(o, w, 1215, 5)

    put(w, 624, owned_branch(o, w, 0))
    owned_patch(o, w, get(w, 512))
    emit_bytes(o, w, 16575, 5)

    owned_patch(o, w, get(w, 600))
    owned_patch(o, w, get(w, 608))
    owned_patch(o, w, get(w, 616))
    owned_patch(o, w, get(w, 624))
    emit_bytes(o, w, 1082287778126904504, 8)
    emit_bytes(o, w, 11, 1)

    put(w, 448, get(w, 56))
    return 0

def cli_to(o:mutbuf, w:mutbuf, condition:u64, destination:u64) -> u64:
    at = owned_branch(o, w, condition)
    if get(w, 48) == 2:
        write4(o, at, destination - at - 4)
    return 0

def cli_finish(o:mutbuf, w:mutbuf) -> u64:
    if get(w, 48) == 2:
        at = get(w, 440)
        write4(o, at, get(w, 448) - at - 4)
        put(o, 96, get(w, 56))
        put(o, 104, get(w, 56))
    return 0


def guard_failure(condition:bool, w:mutbuf, code:u64) -> u64:
    if condition:
        fail(w, code)
    return 0

def identifier(s:readbuf, w:mutbuf) -> u64:
    quoted = get(w, 32)
    begin = get(w, 24) + quoted
    size = get(w, 0) - quoted - begin
    if size == 0 or size > 128:
        return fail(w, 67)
    i = 0
    h = 5381
    c = 0
    good = 0
    while i < size:
        c = byte(s, begin + i)
        good = 0
        if (c >= 65 and c <= 90) or (c >= 97 and c <= 122) or c == 95:
            good = 1
        if i != 0 and c >= 48 and c <= 57:
            good = 1
        if good == 0:
            return fail(w, 67)
        h = ((h * 33) ^ c) & 4294967295
        i = i + 1
    if size >= 6:
        if match(s, begin, 6, 6, 104871984914271, 0, 0, 0) == 1:
            return fail(w, 67)
    put(w, 456, begin)
    put(w, 464, size)
    put(w, 472, h)
    return 0

def same_identifier(s:readbuf, w:mutbuf, base:u64) -> u64:
    # These private records are initialized with full words by identifier /
    # name discovery: sizes <=128, offsets <=1MiB, hashes <=2**32-1.
    # Generic get/put and the public byte ABI retain all 64 bits.
    size = byte(w, 464)
    if size != byte(w, base + 8):
        return 0
    begin = get(w, 456)
    other = get(w, base)
    i = 0
    while i < size:
        if byte(s, begin + i) != byte(s, other + i):
            return 0
        i = i + 1
    return 1

def lookup_identifier(s:readbuf, w:mutbuf, base:u64, stride:u64, count:u64) -> u64:
    i = 0
    record = 0
    if count == 0:
        return 0
    # This lookup and same_identifier only read the state; the target hash
    # cannot change between probes. Hashes still only filter exact bytes.
    target_hash = get(w, 472)
    while i < count:
        record = base + i * stride
        if get(w, record + 16) == target_hash:
            if same_identifier(s, w, record) == 1:
                return i
        i = i + 1
    return count

def read_function_name(s:readbuf, w:mutbuf, definition:u64) -> u64:
    if get(w, 32) != 1 - definition:
        return fail(w, 49)
    identifier(s, w)
    if get(w, 40) != 0:
        return 0
    if reserved_function(s, get(w, 456), get(w, 464)) == 1:
        return fail(w, 67)
    f = 0
    base = 0
    if definition == 1:
        f = get(w, 64)
        if f >= 192:
            return fail(w, 2)
        base = FBASE + f * FSTRIDE
        if get(w, 48) == 0 and get(w, 432) == 1:
            if lookup_identifier(s, w, FBASE + 240, FSTRIDE, f) != f:
                return fail(w, 67)
            put(w, base + 240, get(w, 456))
            put(w, base + 248, get(w, 464))
            put(w, base + 256, get(w, 472))
        else:
            if same_identifier(s, w, base + 240) != 1:
                return fail(w, 67)
    else:
        # All signatures and exact names are discovered before any semantic
        # admission. No placeholder call graph or self-tail identity is used.
        if get(w, 432) == 0:
            f = lookup_identifier(s, w, FBASE + 240, FSTRIDE, get(w, 1024))
            if f == get(w, 1024):
                return fail(w, 23)
    next_token(s, w)
    return f
def reserved_function(s:readbuf, begin:u64, size:u64) -> u64:
    if match(s, begin, size, 5, 500136108641, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 109330211561827, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 109330211561837, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 4, 1701147238, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 133523611411821, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 7, 28559193597109613, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 127979077068141, 0, 0, 0) == 1:
        return 1
    return 0


def read_value_name(s:readbuf, w:mutbuf, kind:u64) -> u64:
    quoted = 0
    if kind == 260:
        quoted = 1
    if get(w, 32) != quoted:
        return fail(w, 48)
    identifier(s, w)
    if get(w, 40) != 0:
        return 0
    slot = ((get(w, 472) * 2654435761) & 4294967295) >> 21
    probes = 0
    base = 0
    index = 0
    while probes < 2048:
        base = 1137264 + slot * 24
        if byte(w, base + 8) == 0:
            index = get(w, 480)
            if index >= 2048:
                return fail(w, 37)
            put(w, base, get(w, 456))
            put(w, base + 8, byte(w, 464))
            put(w, base + 16, index)
            put(w, 480, index + 1)
            next_token(s, w)
            return index
        if same_identifier(s, w, base) == 1:
            index = get(w, base + 16)
            next_token(s, w)
            return index
        slot = (slot + 1) & 2047
        probes = probes + 1
    return fail(w, 37)

def instruction_ahead(s:readbuf, w:mutbuf) -> u64:
    # Distinguish contextual keyword SSA names from terminators without
    # consuming a token or speculatively reading past source length.
    pos = get(w, 0)
    while pos < length(s) and byte(s, pos) == 32:
        pos = pos + 1
    if pos < length(s):
        c = byte(s, pos)
        if c == 58 or c == 44:
            return 1
        if get(w, 8) == 95 and c == 61:
            return 2
    return 0


def read_block_name(s:readbuf, w:mutbuf, definition:u64) -> u64:
    if get(w, 32) != 0:
        return fail(w, 48)
    identifier(s, w)
    if get(w, 40) != 0:
        return 0
    count = get(w, 488)
    index = lookup_identifier(s, w, 1186416, 24, count)
    if definition == 1:
        if index != count or count >= 256:
            return fail(w, 11)
        put(w, 1186416 + count * 24, get(w, 456))
        put(w, 1186416 + count * 24 + 8, get(w, 464))
        put(w, 1186416 + count * 24 + 16, get(w, 472))
        put(w, 488, count + 1)
    else:
        if index == count:
            return fail(w, 19)
    next_token(s, w)
    return index

def discover_blocks(s:readbuf, w:mutbuf) -> u64:
    # Lexical name discovery only. Every declaration, instruction and edge is
    # still admitted by the unchanged complete semantic passes afterwards.
    pos = get(w, 0)
    token = get(w, 8)
    value = get(w, 16)
    begin = get(w, 24)
    quoted = get(w, 32)
    previous = get(w, 120)
    put(w, 488, 0)
    # Opaque line skipping is discovery only, never language admission. The
    # normal parser still validates every byte, opcode and edge afterwards.
    # Avoid lexing all instruction operands an extra time just to find labels.
    first_line = 1
    scan = 0
    while (first_line == 1 or get(w, 8) != @end@ or instruction_ahead(s, w) != 0) and get(w, 40) == 0:
        if first_line == 0 and get(w, 8) == @block@ and instruction_ahead(s, w) == 0:
            next_token(s, w)
            read_block_name(s, w, 1)
        first_line = 0
        scan = get(w, 0)
        while scan < length(s) and byte(s, scan) != 10:
            scan = scan + 1
        if scan == length(s):
            return fail(w, 46)
        put(w, 0, scan + 1)
        next_token(s, w)
    put(w, 0, pos)
    put(w, 8, token)
    put(w, 16, value)
    put(w, 24, begin)
    put(w, 32, quoted)
    put(w, 120, previous)
    return 0

def read_exports(s:readbuf, w:mutbuf) -> u64:
    put(w, 640, 0)
    put(w, 648, 0)
    if get(w, 8) != @exports@:
        return 0
    put(w, 640, 1)
    next_token(s, w)
    adjacent(w)
    expect(s, w, 40)
    n = 0
    record = 0
    while get(w, 8) != 41 and get(w, 40) == 0:
        if n >= 128 or get(w, 32) != 0:
            return fail(w, 68)
        identifier(s, w)
        if get(w, 40) != 0:
            return 0
        if lookup_identifier(s, w, 1192560, 48, n) != n:
            return fail(w, 68)
        if export_loader_hook(s, get(w, 456), get(w, 464)) == 1:
            return fail(w, 68)
        record = 1192560 + n * 48
        put(w, record, get(w, 456))
        put(w, record + 8, get(w, 464))
        put(w, record + 16, get(w, 472))
        next_token(s, w)
        n = n + 1
        if get(w, 8) != 41:
            expect(s, w, 44)
            if get(w, 8) == 41:
                return fail(w, 68)
    expect(s, w, 41)
    expect(s, w, 10)
    if n == 0 or get(w, 232) == 2:
        return fail(w, 68)
    # Explicit native scalar exports select an ELF object independently of the
    # ordinary module label. Flat/stdio ABI would be ambiguous for this list.
    put(w, 232, 1)
    put(w, 648, n)
    account_nodes(w, n + 1)
    return 0

def validate_exports(s:readbuf, w:mutbuf) -> u64:
    i = 0
    record = 0
    f = 0
    fb = 0
    j = 0
    if get(w, 640) == 0 or get(w, 432) == 1:
        return 0
    while i < get(w, 648):
        record = 1192560 + i * 48
        put(w, 456, get(w, record))
        put(w, 464, get(w, record + 8))
        put(w, 472, get(w, record + 16))
        f = lookup_identifier(s, w, FBASE + 240, FSTRIDE, get(w, 64))
        if f == get(w, 64):
            return fail(w, 68)
        put(w, record + 24, f)
        fb = FBASE + f * FSTRIDE
        if get(w, fb + 184) > 1:
            return fail(w, 68)
        if get(w, fb + 184) == 1:
            if scalar_type(get(w, fb + 32)) == 0:
                return fail(w, 68)
        j = 0
        while j < get(w, fb + 24):
            if scalar_type(get(w, fb + 48 + j * 8)) == 0 or get(w, fb + 48 + j * 8) == 16:
                return fail(w, 68)
            j = j + 1
        i = i + 1
    return 0

def export_wrapper(o:mutbuf, w:mutbuf, record:u64) -> u64:
    if get(w, 200) >= 4 and get(w, 200) <= 8:
        return irq_stack_export(o, w, record)
    if get(w, 200) == 3:
        return kernel_irq_export(o, w, record)
    f = get(w, record + 24)
    fb = FBASE + f * FSTRIDE
    count = get(w, fb + 24)
    frame_size = (count + 4) * 16
    put(w, record + 32, get(w, 56))
    emit_bytes(o, w, 66570244592322645, 7)
    emit4(o, w, frame_size)
    i = 0
    while i < count:
        if i == 0:
            emit_bytes(o, w, 16288072, 3)
        if i == 1:
            emit_bytes(o, w, 15763784, 3)
        if i == 2:
            emit_bytes(o, w, 13666632, 3)
        if i == 3:
            emit_bytes(o, w, 13142344, 3)
        if i == 4:
            emit_bytes(o, w, 12618060, 3)
        if i == 5:
            emit_bytes(o, w, 13142348, 3)
        if i >= 6:
            mem(o, w, 139, 0, 5, 16 + (i - 6) * 8)
        normalize(o, w, get(w, fb + 48 + i * 8))
        mem(o, w, 137, 0, 5, 0 - frame_size + i * 16)
        i = i + 1
    mem(o, w, 141, 7, 5, 0 - frame_size)
    mem(o, w, 141, 6, 5, 18446744073709551552)
    emit_bytes(o, w, 186, 1)
    emit4(o, w, CALL_BUDGET)
    emit(o, w, 232)
    relocation(o, w, 1, f)
    if get(w, fb + 184) == 0:
        emit_bytes(o, w, 49201, 2)
    else:
        mem(o, w, 139, 0, 5, 18446744073709551552)
        normalize(o, w, get(w, fb + 32))
    emit_bytes(o, w, 50121, 2)
    put(w, record + 40, get(w, 56) - get(w, record + 32))
    return 0

def exports_finish(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    if get(w, 48) == 0:
        return 0
    count = get(w, 648)
    i = 0
    record = 0
    while i < count:
        export_wrapper(o, w, 1192560 + i * 48)
        i = i + 1
    text = get(w, 56) - 64
    align8(o, w)
    symbols = get(w, 56)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 0)
    emit8(o, w, 281487861612544)
    emit8(o, w, 0)
    emit8(o, w, 0)
    string_size = 1
    i = 0
    while i < count:
        record = 1192560 + i * 48
        emit8(o, w, 281552286121984 + string_size)
        emit8(o, w, get(w, record + 32) - 64)
        emit8(o, w, get(w, record + 40))
        string_size = string_size + get(w, record + 8) + 1
        i = i + 1
    symbol_count = count + 2
    if get(w, 344) != 0:
        emit8(o, w, 77309411328 + string_size)
        emit8(o, w, 0)
        emit8(o, w, 0)
        emit8(o, w, 77309411335 + string_size)
        emit8(o, w, 0)
        emit8(o, w, 0)
        symbol_count = symbol_count + 2
    strings = get(w, 56)
    emit(o, w, 0)
    i = 0
    j = 0
    while i < count:
        record = 1192560 + i * 48
        j = 0
        while j < get(w, record + 8):
            emit(o, w, byte(s, get(w, record) + j))
            j = j + 1
        emit(o, w, 0)
        i = i + 1
    if get(w, 344) != 0:
        emit_bytes(o, w, 109330211561827, 7)
        emit_bytes(o, w, 1701147238, 5)
        string_size = string_size + 12
    names = get(w, 56)
    emit_bytes(o, w, 3314777386191695360, 8)
    emit_bytes(o, w, 3314757496449366387, 8)
    emit_bytes(o, w, 3314757496449692787, 8)
    emit_bytes(o, w, 7089075323386685555, 8)
    emit_bytes(o, w, 5129148576381677056, 8)
    emit_bytes(o, w, 7738135737529095502, 8)
    emit_bytes(o, w, 8371735875514674688, 8)
    emit_bytes(o, w, 7632997, 4)
    align8(o, w)
    relocs = get(w, 56)
    owned_elf_relocations(o, w)
    headers = get(w, 56)
    if get(w, 48) == 2:
        put(o, 40, headers)
        write4(o, 60, 262151)
    elf_section(o, w, 0, 0, 0, 0, 0, 0, 0)
    elf_section(o, w, 4294967297, 6, 64, text, 0, 16, 0)
    elf_section(o, w, 8589934599, 0, symbols, symbol_count * 24, 8589934595, 8, 24)
    elf_section(o, w, 12884901903, 0, strings, string_size, 0, 1, 0)
    elf_section(o, w, 12884901911, 0, names, 60, 0, 1, 0)
    elf_section(o, w, 4294967329, 0, names + 60, 0, 0, 1, 0)
    elf_section(o, w, 17179869233, 0, relocs, get(w, 344) * 24, 4294967298, 8, 24)
    return 0
def export_loader_hook(s:readbuf, begin:u64, size:u64) -> u64:
    if match(s, begin, size, 5, 500136108641, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 109330211561827, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 109330211561837, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 4, 1701147238, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 127979077068141, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 6, 133523611411821, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 7, 28559193597109613, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 5, 499985049951, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 5, 452823967327, 0, 0, 0) == 1:
        return 1
    if match(s, begin, size, 14, 8313484862005141343, 104863580184948, 0, 0) == 1:
        return 1
    if match(s, begin, size, 14, 7594862693843165023, 111576429125998, 0, 0) == 1:
        return 1
    if match(s, begin, size, 12, 7018964951538884447, 1701602414, 0, 0) == 1:
        return 1
    if match(s, begin, size, 25, 7450486912199182687, 4849625224053027689, 7809911718920744812, 101) == 1:
        return 1
    if match(s, begin, size, 27, 8243105053453601119, 6085037597357860709, 7013342044712878925, 6646882) == 1:
        return 1
    return 0

def word_memory(o:mutbuf, w:mutbuf, op:u64, n:u64, a:u64, b:u64, at:u64, bt:u64, t:u64) -> u64:
    word = op >= @buffer.load.u64.le@
    if word and get(w, SCHEMA_STATE) != @hepta.hia.program.v9@:
        return fail(w, 68)
    loan_access(w, a)
    if (at != 6 and at != 7) or bt != 2:
        return fail(w, 29)
    is_load = op == @buffer.load@ or op == @buffer.load.u64.le@ or op == @buffer.load.u64.be@
    value_type = choose(word, 1, 4)
    if is_load:
        if n != 2 or t != value_type:
            return fail(w, 30)
    else:
        if n != 3 or t != 0 or at != 7 or variable(w, get(w, ARGS + 16)) != value_type:
            return fail(w, 30)
    load_var(o, w, 1, b, 0)
    load_var(o, w, 2, a, 1)
    if word:
        # cmp rcx,rdx; jbe +2; ud2.
        emit_bytes(o, w, 0x0b0f0276d13948, 7)
        # sub rdx,rcx; cmp rdx,8; jae +2; ud2.
        emit8(o, w, 0x7308fa8348ca2948)
        emit_bytes(o, w, 0x0b0f02, 3)
    else:
        # Original byte access: cmp rcx,rdx; jb +2; ud2.
        emit_bytes(o, w, 0x0b0f0272d13948, 7)
    load_var(o, w, 0, a, 0)
    # The base+offset calculation occurs only after both guards.
    emit_bytes(o, w, 0xc80148, 3)
    if is_load:
        if word:
            emit_bytes(o, w, 0x008b48, 3)
            if op == @buffer.load.u64.be@:
                emit_bytes(o, w, 0xc80f48, 3)
        else:
            emit_bytes(o, w, 0x00b60f, 3)
    else:
        load_var(o, w, 2, get(w, ARGS + 16), 0)
        if word:
            if op == @buffer.store.u64.be@:
                emit_bytes(o, w, 0xca0f48, 3)
            emit_bytes(o, w, 0x108948, 3)
        else:
            emit_bytes(o, w, 0x1088, 2)
    return 0


def result_offset(slot:u64) -> u64:
    if slot >= 3:
        return slot * 8 + 56
    return slot * 8

def kernel_check_calls(w:mutbuf) -> u64:
    n = get(w, 64)
    step = 0
    f = 0
    target = 0
    ready = 0
    pending = 0
    while step < n:
        f = 0
        pending = 0
        while f < n:
            # First scan every row, including already marked rows: malformed
            # targets must never be hidden by caller-supplied readiness bytes.
            # Thereafter this immutable graph cannot gain an invalid target,
            # and readiness only changes from zero to one.
            if step == 0 or get(w, 1047648 + f * 8) == 0:
                ready = 1
                target = 0
                while target < 192:
                    if byte(w, 1010784 + f * 192 + target) != 0:
                        if target >= n:
                            return fail(w, 55)
                        if get(w, 1047648 + target * 8) == 0:
                            ready = 0
                    target = target + 1
                if ready == 1:
                    put(w, 1047648 + f * 8, 1)
            if get(w, 1047648 + f * 8) == 0:
                pending = pending + 1
            f = f + 1
        if pending == 0:
            return 0
        step = step + 1
    f = 0
    while f < n:
        if get(w, 1047648 + f * 8) == 0:
            return fail(w, 56)
        f = f + 1
    return 0

def mmio_instruction(s:readbuf, o:mutbuf, w:mutbuf, op:u64, n:u64, at:u64, t:u64, v:u64, bt:u64, a:u64, b:u64) -> u64:
    if op >= @x86.irq.dispatch_on_stack@ and op <= @x86.irq.dispatch_frame_slab@:
        return irq_stack_instruction(s, w, n, t, op - @x86.irq.dispatch_on_stack@ + 4)
    if op == @x86.irq.dispatch_kernel_frame@:
        return kernel_irq_instruction(s, w, n, t)
    if op == @x86.irq.restore_kernel_frame@:
        return kernel_frame_instruction(s, o, w, n, t)
    if op == @x86.tr.load@ or op == @x86.tr.read@:
        return tr_instruction(s, o, w, op, n, at, t, v, a)
    if op == @x86.irq.iretq_user@:
        return iretq_user_instruction(s, o, w, n, t)
    if op == @x86.idtr.load@ or op == @x86.idtr.store@:
        return idtr_instruction(s, o, w, op, n, at, t, a)
    if op == @x86.msr.read@ or op == @x86.msr.write@:
        return msr_instruction(s, o, w, op, n, at, t, v, bt, a, b)
    if get(w, 200) != 1 or at != 1:
        return fail(w, 65)
    if op == @x86.mmio.read32@:
        if n != 1 or t != 3 or get(w, 288) != 1:
            return fail(w, 65)
        define(w, v, t)
    else:
        if n != 2 or bt != 3 or t != 0 or get(w, 288) != 0:
            return fail(w, 65)
    expect(s, w, 10)
    if get(w, 40) != 0:
        return 0
    # Raw MMIO address: live device ownership and UC mapping remain
    # caller obligations. Exactly one aligned dword access, in emitted
    # program order. No implicit posted-write flush or DMA ordering.
    load_var(o, w, 2, a, 0)
    emit_bytes(o, w, 3112727954572022, 7)
    if op == @x86.mmio.read32@:
        emit_bytes(o, w, 651, 2)
        store_var(o, w, v, 0)
    else:
        load_var(o, w, 0, b, 0)
        emit_bytes(o, w, 649, 2)
    return 0

def msr_instruction(s:readbuf, o:mutbuf, w:mutbuf, op:u64, n:u64, at:u64, t:u64, v:u64, bt:u64, a:u64, b:u64) -> u64:
    if get(w, 200) != 1 or at != 3:
        return fail(w, 65)
    if op == @x86.msr.read@:
        if n != 1 or t != 1 or get(w, 288) != 1:
            return fail(w, 65)
        define(w, v, t)
    else:
        if n != 2 or bt != 1 or t != 0 or get(w, 288) != 0:
            return fail(w, 65)
    expect(s, w, 10)
    if get(w, 40) != 0:
        return 0
    # ECX selects a u32 MSR; RDMSR returns EDX:EAX and WRMSR consumes it.
    # privilege/trap is not authorization of the selector.
    load_var(o, w, 1, a, 0)
    if op == @x86.msr.read@:
        emit_bytes(o, w, 36158277431823, 6)
        emit_bytes(o, w, 13633864, 3)
        store_var(o, w, v, 0)
    else:
        load_var(o, w, 0, b, 0)
        emit_bytes(o, w, 9265315125037384, 7)
        emit_bytes(o, w, 12303, 2)
    return 0

def idtr_instruction(s:readbuf, o:mutbuf, w:mutbuf, op:u64, n:u64, at:u64, t:u64, a:u64) -> u64:
    if get(w, 200) != 1 or n != 1 or at != 1 or t != 0 or get(w, 288) != 0:
        return fail(w, 65)
    expect(s, w, 10)
    if get(w, 40) != 0:
        return 0
    # A 16-byte-aligned 10-byte pseudo-descriptor cannot cross a 4KiB page.
    # Mapping, authority, hardware state, and the descriptor's contents
    # are not proven by this numeric check.
    load_var(o, w, 2, a, 0)
    emit_bytes(o, w, 3112727955358454, 7)
    if op == @x86.idtr.load@:
        emit_bytes(o, w, 1704207, 3)
    else:
        emit_bytes(o, w, 655631, 3)
    return 0

def iretq_user_instruction(s:readbuf, o:mutbuf, w:mutbuf, n:u64, t:u64) -> u64:
    # No other instruction, function, local resource or ordinary return
    # may share this special terminal export.
    if get(w, 200) != 1 or n != 5 or t != 0 or get(w, 288) != 0:
        return fail(w, 65)
    if get(w, 72) != 0 or get(w, 88) != 0 or get(w, 112) != 1 or get(w, 648) != 1:
        return fail(w, 65)
    if get(w, FBASE + 24) != 5 or get(w, FBASE + 184) != 0 or get(w, FBASE + 176) != 24:
        return fail(w, 65)
    i = 0
    while i < 5:
        a = get(w, ARGS + i * 8)
        if a != i:
            return fail(w, 65)
        expected = 1
        if i == 1 or i == 4:
            expected = 10
        if variable(w, a) != expected:
            return fail(w, 65)
        i = i + 1
    expect(s, w, 10)
    if get(w, 8) != @trap@:
        return fail(w, 65)
    if get(w, 40) != 0:
        return 0
    put(w, 200, 2)
    i = 0
    while i < 5:
        load_var(o, w, 0, i, 0)
        if i == 0 or i == 3:
            # Nonzero, lower-half 48-bit canonical RIP/RSP.
            emit_bytes(o, w, 3112727983719752, 7)
            emit_bytes(o, w, 803782984, 4)
            emit_bytes(o, w, 3112727966942536, 7)
        else:
            if i == 1 or i == 4:
                # Non-null GDT selector, RPL=3, TI=0.
                emit_bytes(o, w, 796858360668914534, 8)
                emit_bytes(o, w, 4365885104259, 6)
                emit_bytes(o, w, 185533044, 4)
            else:
                # Only CF/PF/AF/ZF/SF/IF/OF and mandatory bit 1.
                # Reject all other bits before constructing the frame.
                emit_bytes(o, w, 281474794826056, 6)
                emit_bytes(o, w, 185533044, 4)
                emit_bytes(o, w, 12159093637800, 6)
        i = i + 1
    i = 5
    while i > 0:
        i = i - 1
        load_var(o, w, 0, i, 0)
        emit(o, w, 80)
    emit_bytes(o, w, 53064, 2)
    # The original explicit trap terminator emits the UD2 sentinel.
    return 0

def tr_instruction(s:readbuf, o:mutbuf, w:mutbuf, op:u64, n:u64, at:u64, t:u64, v:u64, a:u64) -> u64:
    if get(w, 200) != 1:
        return fail(w, 65)
    if op == @x86.tr.load@:
        if n != 1 or at != 10 or t != 0 or get(w, 288) != 0:
            return fail(w, 65)
    else:
        if n != 0 or t != 10 or get(w, 288) != 1:
            return fail(w, 65)
        define(w, v, t)
    expect(s, w, 10)
    if get(w, 40) != 0:
        return 0
    # LTR consumes AX and changes the real TSS descriptor busy bit.
    # STR writes AX; zero extension preserves the scalar u16 ABI.
    # Descriptor ownership, selector validity and CPU mode remain caller obligations.
    if op == @x86.tr.load@:
        load_var(o, w, 0, a, 0)
        emit_bytes(o, w, 14155791, 3)
    else:
        emit_bytes(o, w, 54244473936285542, 7)
        store_var(o, w, v, 0)
    return 0

def kernel_frame_instruction(s:readbuf, o:mutbuf, w:mutbuf, n:u64, t:u64) -> u64:
    if get(w, 200) != 1 or n != 1 or t != 0 or get(w, 288) != 0:
        return fail(w, 65)
    if get(w, 72) != 0 or get(w, 88) != 0 or get(w, 112) != 1 or get(w, 648) != 1:
        return fail(w, 65)
    if get(w, FBASE + 24) != 1 or get(w, FBASE + 184) != 0 or get(w, FBASE + 176) != 26:
        return fail(w, 65)
    if get(w, ARGS) != 0 or variable(w, 0) != 1:
        return fail(w, 65)
    expect(s, w, 10)
    if get(w, 8) != @trap@:
        return fail(w, 65)
    if get(w, 40) != 0:
        return 0
    put(w, 200, 2)
    load_var(o, w, 0, 0, 0)
    emit_bytes(o, w, 12108788526355613000, 8)
    emit_bytes(o, w, 14017814527501038607, 8)
    emit_bytes(o, w, 8417937198596931912, 8)
    emit_bytes(o, w, 44913457770467074, 8)
    emit_bytes(o, w, 9603978890679156736, 8)
    emit_bytes(o, w, 5213651089945162962, 8)
    emit_bytes(o, w, 176766285407896311, 8)
    emit_bytes(o, w, 18051384751556004623, 8)
    emit_bytes(o, w, 15171613442386850840, 8)
    emit_bytes(o, w, 796858356592182118, 8)
    emit_bytes(o, w, 1729382259069846344, 8)
    emit_bytes(o, w, 11004690034926223988, 8)
    emit_bytes(o, w, 796858356575764480, 8)
    emit_bytes(o, w, 8489994793849490248, 8)
    emit_bytes(o, w, 5201634210494484226, 8)
    emit_bytes(o, w, 10036283928688775813, 8)
    emit_bytes(o, w, 15169610084704620688, 8)
    emit_bytes(o, w, 8363117395053576821, 8)
    emit_bytes(o, w, 5201634210494484226, 8)
    emit_bytes(o, w, 10036283928688775813, 8)
    emit_bytes(o, w, 14048776727442786448, 8)
    emit_bytes(o, w, 796858360602293544, 8)
    emit_bytes(o, w, 5191259498702095094, 8)
    emit_bytes(o, w, 6719755753877521545, 8)
    emit_bytes(o, w, 6431520979612163137, 8)
    emit_bytes(o, w, 6582391691752069185, 8)
    emit_bytes(o, w, 13584472, 3)
    return 0

def kernel_irq_instruction(s:readbuf, w:mutbuf, n:u64, t:u64) -> u64:
    if get(w, 200) != 1 or n != 0 or t != 0 or get(w, 288) != 0:
        return fail(w, 65)
    if get(w, 72) != 0 or get(w, 88) != 0 or get(w, 112) != 1 or get(w, 648) != 1:
        return fail(w, 65)
    if get(w, FBASE + 24) != 0 or get(w, FBASE + 184) != 0 or get(w, FBASE + 176) != 30:
        return fail(w, 65)
    expect(s, w, 10)
    if get(w, 8) != @trap@:
        return fail(w, 65)
    if get(w, 40) != 0:
        return 0
    put(w, 200, 3)
    return 0

def kernel_irq_export(o:mutbuf, w:mutbuf, record:u64) -> u64:
    put(w, record + 32, get(w, 56))
    irq_emit_pair(o, w, 4707765013745587024, 4707177857071268176)
    irq_emit_pair(o, w, 18183073859250766164, 177259439036860744)
    irq_emit_pair(o, w, 796858356570000143, 5201634210506508616)
    irq_emit_pair(o, w, 10180399116764631685, 16915880840217534352)
    irq_emit_pair(o, w, 796858359839279151, 563787325790876)
    irq_emit_pair(o, w, 14595152690083427328, 796858356726399846)
    irq_emit_pair(o, w, 8363459950299745382, 36231671007874818)
    irq_emit_pair(o, w, 5191259498686709760, 8363184508037019779)
    irq_emit_pair(o, w, 5222012327075450626, 13927394006736949893)
    irq_emit_pair(o, w, 1081555308050395114, 620900337675)
    irq_emit_pair(o, w, 17729280861315171656, 13927394006736834498)
    irq_emit_pair(o, w, 1081555308050395114, 586540599307)
    irq_emit_pair(o, w, 8430738455876794184, 177050796725833474)
    irq_emit_pair(o, w, 72543335667469071, 2369668869772001280)
    irq_emit_pair(o, w, 177259439035779400, 796858356435782415)
    irq_emit_pair(o, w, 5201634210506508616, 10036283928688775813)
    irq_emit_pair(o, w, 796858363832256512, 5201634210506508616)
    irq_emit_pair(o, w, 9459823176385352325, 8484928245756588260)
    irq_emit_pair(o, w, 1081554471114968834, 3452784582578489355)
    irq_emit_pair(o, w, 5191259498698933576, 13927381847653716109)
    irq_emit_pair(o, w, 1081555308050395114, 144329555402464267)
    irq_emit_pair(o, w, 10116785772027969536, 1081554511153293002)
    irq_emit_pair(o, w, 1223434726426830347, 9275307778015953524)
    irq_emit_pair(o, w, 796858356709982208, 1152921507169076040)
    irq_emit_pair(o, w, 8669582424227644020, 5191259498715710792)
    irq_emit_pair(o, w, 176997755257875137, 158950486444815)
    irq_emit_pair(o, w, 796858364134246400, 5191259498686169846)
    irq_emit_pair(o, w, 176997755257875137, 150154393422607)
    irq_emit_pair(o, w, 18446732154151323648, 8431515814394266228)
    irq_emit_pair(o, w, 6863983400987594498, 6575638366744829505)
    irq_emit_pair(o, w, 6871745644130818625, 1139208775074929246)
    emit_bytes(o, w, 11, 1)
    put(w, record + 40, get(w, 56) - get(w, record + 32))
    return 0

def irq_stack_instruction(s:readbuf, w:mutbuf, n:u64, t:u64, mode:u64) -> u64:
    if get(w, 200) != 1 or (n | t | get(w, 288)) != 0:
        return fail(w, 65)
    if (get(w, 72) | get(w, 88)) != 0 or get(w, 112) != 1 or get(w, 648) != 1:
        return fail(w, 65)
    if (get(w, FBASE + 24) | get(w, FBASE + 184)) != 0 or get(w, FBASE + 176) != 62:
        return fail(w, 65)
    expect(s, w, 10)
    if get(w, 8) != @trap@:
        return fail(w, 65)
    if get(w, 40) != 0:
        return 0
    put(w, 200, mode)
    return 0

def irq_stack_export(o:mutbuf, w:mutbuf, record:u64) -> u64:
    put(w, record + 32, get(w, 56))
    irq_emit_quad(o, w, 4707765013745587024, 4707177857071268176, 18183073859250766164, 177259439036860744)
    irq_emit_quad(o, w, 796858356570000143, 5201634210506508616, 10180399116764631685, 16915880840217534352)
    irq_emit_quad(o, w, 796858359839279151, 563787325790876, 14595152690083427328, 796858356726399846)
    irq_emit_quad(o, w, 8363459950299745382, 36231671007874818, 5191259498686709760, 8363184508037019779)
    irq_emit_quad(o, w, 5222012327075450626, 13927394006736949893, 1081555308050395114, 620900337675)
    irq_emit_quad(o, w, 17729280861315171656, 13927394006736834498, 1081555308050395114, 586540599307)
    irq_emit_quad(o, w, 8430738455876794184, 177050796725833474, 72543335667469071, 2369668869772001280)
    irq_emit_quad(o, w, 177259439035779400, 796858356435782415, 8372168348175337800, 5196961062738136834)
    emit_bytes(o, w, 3112727957465793, 7)
    emit_bytes(o, w, 12880201, 3)
    if get(w, 200) >= 6:
        irq_emit_quad(o, w, 9597750248554372025, 18374445734121600210, 8430421877452570623, 18365679420977123074)
        irq_emit_quad(o, w, 142570481256567435, 13390197029554029174, 13927436890870382848, 13872574285530800354)
        irq_emit_quad(o, w, 176801091974791797, 16915881675744348943, 5804374707084096559, 1081554609673160767)
        emit_bytes(o, w, 15564805375348787467, 8)
        emit_bytes(o, w, 3112727969020236, 7)
    if get(w, 200) >= 7:
        irq_emit_quad(o, w, 4503227187341644, 10416060725511484416, 3452784579314757631, 9285130836373340788)
        emit_bytes(o, w, 6927530154000386, 8)
        emit_bytes(o, w, 32, 3)
    if get(w, 200) == 8:
        irq_emit_pair(o, w, 5188146773425098056, 40687737266160185)
        emit_bytes(o, w, 176721451418648752, 8)
        emit_bytes(o, w, 2831, 2)
    irq_emit_pair(o, w, 8492528067227192137, 13927622130797317890)
    emit_bytes(o, w, 12159093583850, 6)
    emit_bytes(o, w, 34970831693, 5)
    if get(w, 200) >= 7:
        emit_bytes(o, w, 3112727968823629, 7)
    irq_emit_quad(o, w, 17115170690617871181, 1136585240199758453, 5256414674790842996, 5263317092726205121)
    irq_emit_quad(o, w, 4127830534535550349, 17165836164591154390, 2617872628266762871, 4128964640685771808)
    irq_emit_quad(o, w, 10920463883776979956, 8566472439792402592, 4127584398760298764, 16877604688927814607)
    emit_bytes(o, w, 1081554366177740662, 8)
    emit_bytes(o, w, 11, 1)
    if get(w, 200) >= 5:
        irq_emit_quad(o, w, 8359147205017504585, 8286333607141379842, 17294219000087777026, 176792830095724361)
        emit_bytes(o, w, 2831, 2)
    else:
        irq_emit_pair(o, w, 7428125000, 8365476254007118320)
        emit_bytes(o, w, 724738, 3)
    irq_emit_quad(o, w, 277997062476, 8363805003969364296, 18377152148590497538, 15276197331602339273)
    emit_bytes(o, w, 13076809, 3)
    if get(w, 200) >= 5:
        irq_emit_pair(o, w, 13333767624986999116, 13927436890870382849)
        emit_bytes(o, w, 16157029594560995554, 8)
        emit_bytes(o, w, 185533044, 4)
    else:
        emit_bytes(o, w, 3112727970330956, 7)
    irq_emit_quad(o, w, 796858356913158473, 1081554438841973069, 176784034129071371, 18218815486429967)
    irq_emit_quad(o, w, 3771333930641784832, 14016125677640774674, 18412208333852901128, 5258666474604528245)
    irq_emit_quad(o, w, 4686856340422781633, 5263317092724099062, 13927381847653717901, 10180680591741300714)
    irq_emit_pair(o, w, 16877604641431396503, 1081554366177806198)
    emit_bytes(o, w, 11, 1)
    irq_emit_pair(o, w, 5516145436481698124, 1081554194378858532)
    emit_bytes(o, w, 144329555402464267, 8)
    emit_bytes(o, w, 12159093571584, 6)
    if get(w, 200) == 8:
        irq_emit_quad(o, w, 18442240634218645836, 689737386495, 10416060740137007432, 8347203420049944576)
        emit_bytes(o, w, 724738, 3)
    irq_emit_quad(o, w, 177259439038433612, 796858356570000143, 5201634210506508616, 10180399116764631685)
    irq_emit_quad(o, w, 16915880840217534352, 796858359839279151, 563787325790876, 14595152690083427328)
    irq_emit_quad(o, w, 796858356726399846, 8363459950299745382, 36231671007874818, 5191259498686709760)
    irq_emit_quad(o, w, 8363184508037019779, 5222012327075450626, 13927394006736949893, 1081555308050395114)
    irq_emit_quad(o, w, 620900337675, 17729280861315171656, 13927394006736834498, 1081555308050395114)
    irq_emit_pair(o, w, 586540599307, 8430738455876794184)
    emit_bytes(o, w, 177050796725833474, 8)
    emit_bytes(o, w, 2831, 2)
    if get(w, 200) >= 5:
        irq_emit_pair(o, w, 17294198109381364040, 176792829693071177)
        emit_bytes(o, w, 2831, 2)
    else:
        irq_emit_pair(o, w, 15145966186660889016, 8365476254007118320)
        emit_bytes(o, w, 724738, 3)
    irq_emit_quad(o, w, 6863983401003157836, 6575638366744829505, 6871745644130818625, 1139208775074929246)
    emit_bytes(o, w, 11, 1)
    put(w, record + 40, get(w, 56) - get(w, record + 32))
    return 0

def irq_emit_pair(o:mutbuf, w:mutbuf, a:u64, b:u64) -> u64:
    emit_bytes(o, w, a, 8)
    emit_bytes(o, w, b, 8)
    return 0

def irq_emit_quad(o:mutbuf, w:mutbuf, a:u64, b:u64, c:u64, d:u64) -> u64:
    irq_emit_pair(o, w, a, b)
    irq_emit_pair(o, w, c, d)
    return 0
