from pathlib import Path
from hashlib import sha256
import json,os,sys,subprocess,signal,time,platform
root=Path('/home/qian-qi/hia-native-caller-selection-20261127-2ac5')
source=root/'source'
head='e75bf8435ed97b1caa63cfc29a67e370f2f80cef'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
out=root/'matching-cold-four-original-callers-declared-prerequisites';out.mkdir(mode=0o700,exist_ok=False)
venv=root/'original-ci-python-prerequisites-v1'
assert not venv.exists()
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')}
env['PYTHONDONTWRITEBYTECODE']='1'
setup=[]
def execute(argv,log,timeout):
 began=time.monotonic()
 with log.open('xb') as f:
  p=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  timed_out=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=3)
 return {'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-began,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest()}
for argv,log,timeout in [
 ([sys.executable,'-m','venv',str(venv)],out/'create-venv.log',180),
 ([str(venv/'bin/python'),'-m','pip','--disable-pip-version-check','install','--report',str(out/'pip-install-report.json'),'setuptools==78.1.1','wheel==0.46.3','z3-solver==4.15.4.0','jsonschema==4.26.0'],out/'install-original-declared-prerequisites.log',600),
 ([str(venv/'bin/python'),'-m','pip','--disable-pip-version-check','check'],out/'pip-check.log',60)]:
 row=execute(argv,log,timeout);setup.append(row);(out/'setup-results.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps({'setup':row}),flush=True)
 if row['exit_code'] or row['timed_out']:raise SystemExit(row['exit_code'] or 1)
probe="import importlib.metadata,json,os,sys,z3; s=z3.Solver(); x=z3.Int('x'); s.add(x>1,x<0); result=str(s.check()); assert result=='unsat'; print(json.dumps({'python':sys.version,'executable':sys.executable,'z3_runtime_version':z3.get_version_string(),'z3_distribution_version':importlib.metadata.version('z3-solver'),'jsonschema_distribution_version':importlib.metadata.version('jsonschema'),'setuptools_distribution_version':importlib.metadata.version('setuptools'),'wheel_distribution_version':importlib.metadata.version('wheel'),'actual_solver_check':result,'linux_memfd_available':hasattr(os,'memfd_create')}))"
p=subprocess.run([str(venv/'bin/python'),'-B','-c',probe],cwd=source,env=env,capture_output=True,text=True,timeout=30)
(out/'actual-environment-probe.json').write_text(p.stdout);(out/'actual-environment-probe.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
print(p.stdout.strip(),flush=True)
cold=Path('/home/qian-qi/hia-native-cold-edge-6f7d-20261127-2ac5/qualified-cold-handoff/qualified-cold.json')
assert sha256(cold.read_bytes()).hexdigest()=='dbee5b3b1e05fd8d17392b7a248c7fda169decb6a237d3cb6db57fd0a91b27b8'
names=('generation_retention','patch_impact','publication_measurement','scalar_profile')
records=[]
for name in names:
 argv=[str(venv/'bin/python'),'-B','tools/qualify_hia_'+name+'_callers.py','--cold-report',str(cold),'--evidence',str(out/name)]
 row=execute(argv,out/(name+'.log'),1800);row['name']=name
 report_path=out/name/'report.json'
 if report_path.exists():
  report=json.loads(report_path.read_bytes())
  row['reported_status']=report.get('status');row['reported_scope']=report.get('scope');row['actual_tests']=report.get('actual_tests')
  row['anomaly_counts']={k:len(report.get(k,[])) for k in ('errors','failures','skipped','expected_failures','unexpected_successes')}
 row['source_clean']=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source))
 records.append(row);(out/'results.json').write_text(json.dumps(records,sort_keys=True,indent=2)+'\n');print(json.dumps(row),flush=True)
 if row['timed_out']:break
passed=len(records)==len(names) and all(r['exit_code']==0 and not r['timed_out'] and r.get('reported_status')=='PASS' and r['source_clean'] and all(v==0 for v in r.get('anomaly_counts',{}).values())for r in records)
terminal={'schema':'hepta.hia.actual-matching-cold-original-component-callers.v1','status':'PASS'if passed else'FAIL','source_head':head,'native_cold_source_head':'6f7dfb2defd8852d2fe58e02ff8c5cf78c5e7807','declared_original_prerequisite_versions':{'z3-solver':'4.15.4.0','jsonschema':'4.26.0','setuptools':'78.1.1','wheel':'0.46.3'},'original_failure_evidence_preserved':str(root/'matching-cold-six-original-callers-complete-source'),'unmodified_original_caller_gates':len(records),'whole_native_delivery_qualified':False,'results':records}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':terminal['status'],'gates':len(records),'actual_tests':sum(r.get('actual_tests',0)or 0 for r in records)}),flush=True)
raise SystemExit(0 if passed else 1)
