from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,time
root=Path('/home/qian-qi/hia-native-caller-history-d5-20261127-2ac5')
root.mkdir(mode=0o700,exist_ok=False)
source=root/'source';head='d5b83d4b271a032b3feb1135cae654f5ffff8126'
base=Path('/home/qian-qi/hia-matching-bounded-memory-b332-20261127-2ac5/source')
subprocess.run(['git','init',str(source)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
(source/'.git/objects/info/alternates').write_text(str(base/'.git/objects')+'\n')
(source/'.git/shallow').write_bytes((base/'.git/shallow').read_bytes())
log=root/'fetch.log'
with log.open('xb')as f:p=subprocess.run(['git','fetch','--depth=1','--no-tags','https://github.com/TrillionniumFoundation/Hepta.git',head],cwd=source,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print(json.dumps({'source_fetch_exit':p.returncode,'log_sha256':sha256(log.read_bytes()).hexdigest()}),flush=True)
if subprocess.run(['git','cat-file','-e',head+'^{tree}'],cwd=source,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:raise SystemExit(p.returncode or 1)
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source).decode().strip()=='9d0abaa00e7b6ebe514a2f9ef8a649a16982fc17'
rows=subprocess.check_output(['git','ls-tree','-r',head],cwd=source,text=True).splitlines()
objects=[row.split(None,3)[2]for row in rows]
checked=subprocess.run(['git','cat-file','--batch-check'],cwd=source,input='\n'.join(objects)+'\n',capture_output=True,text=True,check=True)
assert not any(row.endswith('missing')for row in checked.stdout.splitlines())
shallow=source/'.git/shallow';raw=shallow.read_bytes()
if (head+'\n').encode()not in raw:shallow.write_bytes(raw+(head+'\n').encode())
p=subprocess.run(['git','checkout','-b','codex/hia-native-caller-history-d5-20261127-2ac5',head],cwd=source,capture_output=True,text=True)
(root/'checkout.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
for path in ('tests/hia_cold_caller_selection_history.py','tests/test_hia_cold_caller_selection_history.py','tests/hia_native_transport_worker_successor.py','tools/hia_selfhost_contract.py'):
 ast.parse((source/path).read_bytes(),filename=path)
cmd=['/usr/bin/python3','-B','tools/run_hia_unittest_gate.py','tests.test_hia_cold_caller_selection_history']
log=root/'source-controls.log';began=time.monotonic()
with log.open('xb')as f:p=subprocess.run(cmd,cwd=source,stdout=f,stderr=subprocess.STDOUT,timeout=120)
terminal={'schema':'hepta.hia.native-cold-caller-selection-source-controls.v1','source_head':head,'exit_code':p.returncode,'wall_seconds':time.monotonic()-began,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source)),'complete_original_caller_suites_qualified':False,'whole_native_delivery_qualified':False,'source_fetch_exit':None}
(root/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n')
print(json.dumps(terminal),flush=True)
if p.returncode:print(log.read_text()[-16000:],flush=True)
raise SystemExit(p.returncode)