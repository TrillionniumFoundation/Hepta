from pathlib import Path
from hashlib import sha256,sha1
import importlib.abc,json,sys,subprocess,re,tarfile,gzip,io,stat,time
root=Path('/home/qian-qi/hia-matching-bounded-memory-b332-20261127-2ac5')
source=root/'source';head='b332b57fca954ef4ac908aef7431c039cecad09c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
sys.path.insert(0,str(source))
class NoProduct(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='hepta' or fullname.startswith(('hepta.','tools.build_','tools.generate_')) or 'oracle' in fullname:raise AssertionError('independent reader imported product: '+fullname)
sys.meta_path.insert(0,NoProduct())
from tools.hia_component_cold_readback import native_cold_compiler,read_component_inputs
from tools.hia_cold_compiler import _regular
from tools import read_hia_service_bootstrap as pack_reader
captures={}
def read(path):
 path=Path(path).absolute();raw=_regular(path,64*1024*1024,allow_empty=True)
 pin={'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
 assert path not in captures or captures[path]==pin,str(path)
 captures[path]=pin
 return raw
begin=time.monotonic()
report=json.loads(read(root/'evidence/report.json'))
assert report['status']=='PASS' and report['scope']=='MATCHING_SOURCE_COLD_ORIGINAL_VM_MEMORY_CALLERS'
assert type(report['actual_tests'])is int and report['actual_tests']==36
assert report['planned']==report['started']==report['stopped'] and len(set(report['planned']))==36
assert all(report[k]==[] for k in ('errors','failures','skipped','expected_failures','unexpected_successes'))
assert report['all_original_modules_unfiltered']is True and report['retained_python_memory_bodies_forbidden']is True and report['source_and_bundle_unchanged']is True
assert report['whole_native_delivery_qualified']is False
assert type(report['native_fill_calls'])is int and report['native_fill_calls']>0
assert type(report['native_move_calls'])is int and report['native_move_calls']>0
prior_archive=source/'docs/evidence/native-component-custody-20261127/rog-original-six-callers-passed.tar.gz'
prior_raw=read(prior_archive)
assert sha256(prior_raw).hexdigest()=='e7765127e25d3dce07d4014eef503de726e1f1f8a50c5ab966449ce0442913d3'
priors=[]
with tarfile.open(fileobj=io.BytesIO(prior_raw),mode='r:gz')as t:
 for member in t:
  if member.isfile() and member.name.endswith('.json'):
   raw=t.extractfile(member).read()
   try:value=json.loads(raw)
   except ValueError:continue
   if value.get('actual_tests')==36 and value.get('original_modules')==report['original_modules'] and 'planned'in value:priors.append((member.name,raw,value))
assert len(priors)==1,len(priors)
member,prior_report_raw,prior=priors[0]
assert prior['planned']==report['planned']
for module in report['original_modules']:
 name=module.replace('.','/')+'.py'
 assert sha256(read(source/name)).hexdigest()==report['source_pins'][name]==prior['source_pins'][name]
for name,expected in report['source_pins'].items():
 assert not Path(name).is_absolute() and '..'not in Path(name).parts
 assert sha256(read(source/name)).hexdigest()==expected,name
cold=Path('/home/qian-qi/hia-native-cold-edge-6f7d-20261127-2ac5/qualified-cold-handoff/qualified-cold.json')
compiler_path,compiler,sources=native_cold_compiler(source,cold,read=read)
directory=root/'evidence/qualified'
manifest_path=directory/'manifest.json'
manifest=json.loads(read(manifest_path));build=json.loads(read(directory/'build.json'))
assert build['scope']=='MATCHING_SOURCE_COLD_COMPONENT' and build['source_manifest']==sources and build['manifest']==manifest
assert manifest['image_sha256']==report['native_image_sha256']
read_component_inputs(source,build,compiler,cold,read=read)
names=[n for n,d in build['component_inputs'].items() if n.endswith('.hepta') and d==manifest['source_sha256']]
assert len(names)==1
raw_source=read(source/names[0]);image=read(directory/manifest['image_path'])
pack_captures=[]
pack_reader.verify_pack(manifest_path,manifest,build,compiler,raw_source,image,pack_captures)
for path,raw in pack_captures:assert read(path)==raw
for path,digest in report['bundle_pins'].items():assert sha256(read(path)).hexdigest()==digest
assert set(report['bundle_pins'])=={str(p)for p in directory.rglob('*') if p.is_file()}
log=read(root/'evidence/tests.log').decode()
positions=[log.index('('+test+')') for test in report['planned']]
assert positions==sorted(positions) and all(log.count('('+test+')')==1 for test in report['planned'])
assert re.search(r'\nRan 36 tests in [0-9]+\.[0-9]+s\n\nOK\n$',log)
terminal=json.loads(read(root/'terminal.json'))
assert terminal['status']=='PASS' and terminal['original_product_gate_attempts']==1
for path,pin in list(captures.items()):
 raw=_regular(path,64*1024*1024,allow_empty=True)
 assert {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}==pin
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
result={'schema':'hepta.hia.original-matching-memory-callers-independent-readback.v1','status':'PASS','source_head':head,'native_cold_source_head':'6f7dfb2defd8852d2fe58e02ff8c5cf78c5e7807','actual_tests':36,'native_source_count':len(sources),'physical_captures':len(captures),'native_fill_calls':report['native_fill_calls'],'native_move_calls':report['native_move_calls'],'compiler_sha256':sha256(compiler).hexdigest(),'original_method_inventory_archive_sha256':sha256(prior_raw).hexdigest(),'original_method_inventory_member':member,'original_method_inventory_member_sha256':sha256(prior_report_raw).hexdigest(),'all_six_original_source_files_unchanged':True,'product_builder_generator_oracle_imported':False,'whole_native_delivery_qualified':False,'wall_seconds':time.monotonic()-begin,'captured_files':{str(p):v for p,v in sorted(captures.items())}}
(root/'independent-readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
out=root/'closed-original-evidence';out.mkdir(mode=0o700,exist_ok=False)
files={}
for p in root.rglob('*'):
 if p.is_file() and source not in p.parents and out not in p.parents:files['original/'+p.relative_to(root).as_posix()]=p
files['cold/original-cold.json']=cold
files['cold/original-cold.generations.json']=cold.with_suffix('.generations.json')
index=json.loads(read(files['cold/original-cold.generations.json']))
for row in index['generations']:files['cold/'+row['name']+'.flat']=Path(row['produced_image'])
pins={};archive=out/'complete-matching-36-original-evidence.tar.gz'
with archive.open('xb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='')as gz:
  with tarfile.open(fileobj=gz,mode='w|')as t:
   for name,path in sorted(files.items()):
    raw=read(path);info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644
    t.addfile(info,io.BytesIO(raw));pins[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
seen=set()
with tarfile.open(archive,'r:gz')as t:
 for m in t:
  assert m.isfile()and m.name in pins and m.name not in seen
  raw=t.extractfile(m).read();assert {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}==pins[m.name]
  assert read(files[m.name])==raw;seen.add(m.name)
assert set(pins)==seen
raw=archive.read_bytes()
manifest={'schema':'hepta.hia.original-matching-memory-callers-evidence-custody.v1','status':'PASS','actual_tests':36,'source_head':head,'whole_native_delivery_qualified':False,'files':pins,'archive':{'path':str(archive),'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'git_blob_sha1':sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'members':len(pins),'all_members_re_read_against_originals':True}}
(out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps({'readback':{k:result[k]for k in ('status','actual_tests','native_source_count','physical_captures','native_fill_calls','native_move_calls','wall_seconds')},'archive':manifest['archive']}),flush=True)