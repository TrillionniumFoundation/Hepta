from pathlib import Path
import sys,subprocess,shutil,json,importlib.util,os
source=Path('/home/qian-qi/hia-native-caller-selection-20261127-2ac5/source')
print(json.dumps({'python':sys.executable,'version':sys.version,'z3_present':importlib.util.find_spec('z3') is not None,'pip_present':importlib.util.find_spec('pip') is not None,'venv_present':importlib.util.find_spec('venv') is not None,'ensurepip_present':importlib.util.find_spec('ensurepip') is not None,'memfd':hasattr(os,'memfd_create'),'interpreters':{p:shutil.which(p)for p in ('python3.14','python3.13','uv','clang','clang-20','clang-21')}}))
for rel in ('pyproject.toml','requirements.txt','requirements-dev.txt'):
 p=source/rel
 if p.exists():print(json.dumps({'path':rel,'text':p.read_text()[:10000]}))
roots=[source,Path('/home/qian-qi/hia-native-cold-edge-6f7d-20261127-2ac5/source'),Path('/home/qian-qi/hia-native-cold-edge-6f7d-20261127-2ac5')]
for root in roots:
 for name in ('.venv','venv'):
  p=root/name/'bin/python'
  if p.exists():
   cp=subprocess.run([str(p),'-c','import sys,z3;print(sys.version);print(z3.get_version_string());print(z3.__file__)'],capture_output=True,text=True,timeout=10)
   print(json.dumps({'candidate':str(p),'exit':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr}))
p=subprocess.run(['clang','--version'],capture_output=True,text=True,timeout=10)
print(json.dumps({'clang':p.stdout.splitlines()[:2],'exit':p.returncode}))
