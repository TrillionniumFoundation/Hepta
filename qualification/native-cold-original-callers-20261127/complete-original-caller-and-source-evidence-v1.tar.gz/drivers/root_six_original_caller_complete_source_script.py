from pathlib import Path
import hashlib,json,os,signal,subprocess,time
root=Path('/home/qian-qi/hia-native-caller-selection-20261127-2ac5')
source=root/'source';head='e75bf8435ed97b1caa63cfc29a67e370f2f80cef'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()=='b332b57fca954ef4ac908aef7431c039cecad09c'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
attempt=root/'matching-cold-six-original-callers-complete-source';attempt.mkdir(mode=0o700,exist_ok=False)
assert subprocess.check_output(['git','cat-file','-t',head],cwd=source)==b'commit\n'
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source).decode().strip()=='3d923bab672cf692a66ed773014c4f97f0c8f578'
objects=[line.split(None,3)[2]for line in subprocess.check_output(['git','ls-tree','-r',head],cwd=source,text=True).splitlines()]
checked=subprocess.run(['git','cat-file','--batch-check'],input='\n'.join(objects)+'\n',cwd=source,capture_output=True,text=True,check=True)
assert not any(line.endswith('missing')for line in checked.stdout.splitlines())
shallow=source/'.git/shallow';before=shallow.read_bytes();lines=set(before.decode().splitlines())
lines.discard(head);lines.add('b332b57fca954ef4ac908aef7431c039cecad09c')
shallow.write_text('\n'.join(sorted(lines))+'\n')
(attempt/'complete-source-readback.json').write_text(json.dumps({'source_head':head,'source_tree':'3d923bab672cf692a66ed773014c4f97f0c8f578','all_tree_blob_count':len(objects),'missing_objects':[],'original_failed_fetch_retained':True,'no_network_fetch_repeated':True,'complete_ancestry_claimed':False,'before_shallow':before.decode(),'after_shallow':shallow.read_text()},indent=2)+'\n')
p=subprocess.run(['git','merge','--ff-only',head],cwd=source,capture_output=True,text=True)
(attempt/'checkout.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source).decode().strip()=='3d923bab672cf692a66ed773014c4f97f0c8f578'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
cold=Path('/home/qian-qi/hia-native-cold-edge-6f7d-20261127-2ac5/qualified-cold-handoff/qualified-cold.json')
assert hashlib.sha256(cold.read_bytes()).hexdigest()=='dbee5b3b1e05fd8d17392b7a248c7fda169decb6a237d3cb6db57fd0a91b27b8'
names=('full_cost','generation_retention','patch_impact','publication_measurement','scalar_profile','static_budget')
records=[]
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')}
env['PYTHONDONTWRITEBYTECODE']='1'
for name in names:
 argv=['/usr/bin/python3','-B','tools/qualify_hia_'+name+'_callers.py','--cold-report',str(cold),'--evidence',str(attempt/name)]
 log=attempt/(name+'.log');began=time.monotonic()
 with log.open('xb') as f:
  proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  timed_out=False
  try:code=proc.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
 row={'name':name,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-began,'log_bytes':log.stat().st_size,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 report_path=attempt/name/'report.json'
 if report_path.exists():
  report=json.loads(report_path.read_bytes())
  row['reported_status']=report.get('status');row['reported_scope']=report.get('scope');row['actual_tests']=report.get('actual_tests')
  row['anomaly_counts']={k:len(report.get(k,[])) for k in ('errors','failures','skipped','expected_failures','unexpected_successes')}
 row['source_clean']=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source))
 records.append(row)
 (attempt/'results.json').write_text(json.dumps(records,sort_keys=True,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if timed_out:break
passed=len(records)==len(names) and all(r['exit_code']==0 and not r['timed_out'] and r.get('reported_status')=='PASS' and r['source_clean'] and all(v==0 for v in r.get('anomaly_counts',{}).values()) for r in records)
terminal={'schema':'hepta.hia.actual-matching-cold-original-component-callers.v1','status':'PASS' if passed else 'FAIL','source_head':head,'native_cold_source_head':'6f7dfb2defd8852d2fe58e02ff8c5cf78c5e7807','complete_original_caller_gates':len(records),'whole_native_delivery_qualified':False,'results':records}
(attempt/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':terminal['status'],'gates':len(records),'actual_tests':sum(r.get('actual_tests',0) or 0 for r in records)}),flush=True)
raise SystemExit(0 if passed else 1)