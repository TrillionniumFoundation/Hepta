from pathlib import Path
from hashlib import sha256
import json,subprocess,time,sys
root=Path('/home/qian-qi/hia-native-caller-history-d5-20261127-2ac5')
source=root/'source';head='4ed7bf2817edda2fe38602a23a25b68a8c886a5b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()=='d5b83d4b271a032b3feb1135cae654f5ffff8126'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
out=root/'store-v2-ordinary-merge-original-source-controls';out.mkdir(mode=0o700,exist_ok=False)
log=out/'fetch.log'
with log.open('xb')as f:p=subprocess.run(['git','fetch','--depth=2','--no-tags','https://github.com/TrillionniumFoundation/Hepta.git',head],cwd=source,stdout=f,stderr=subprocess.STDOUT,timeout=180)
fetch_exit=p.returncode
print(json.dumps({'source_fetch_exit':fetch_exit,'log_sha256':sha256(log.read_bytes()).hexdigest()}),flush=True)
for commit in (head,'d5b83d4b271a032b3feb1135cae654f5ffff8126','276c84619d0533e2e1abb8b84ba893d465080976'):
 subprocess.run(['git','cat-file','-e',commit+'^{commit}'],cwd=source,check=True)
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source).decode().strip()=='e51cf9475585d9bd5d445ebda469fb977e5991b9'
shallow=source/'.git/shallow'
before=shallow.read_bytes()
lines=set(before.decode().splitlines());lines.discard(head);lines.add('d5b83d4b271a032b3feb1135cae654f5ffff8126');lines.add('276c84619d0533e2e1abb8b84ba893d465080976')
shallow.write_text('\n'.join(sorted(lines))+'\n')
(out/'source-history-availability.json').write_text(json.dumps({'full_ancestry_claimed':False,'current_merge_and_both_real_parent_commits_present':True,'before_shallow':before.decode(),'after_shallow':shallow.read_text()},indent=2)+'\n')
p=subprocess.run(['git','merge','--ff-only',head],cwd=source,capture_output=True,text=True)
(out/'merge.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
sys.path.insert(0,str(source))
from tests.test_hia_store_native_delivery import source_pins
before=source_pins()
(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
cmd=['/usr/bin/python3','-B','tools/run_hia_unittest_gate.py','tests.test_hia_cold_caller_selection_history','tests.test_hia_store_source_history','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_caller_terminal_admission.CallerTerminalAdmissionSourceTests','tests.test_hia_caller_terminal_readback.CallerTerminalReadbackSourceTests']
began=time.monotonic();log=out/'all-original-source-and-new-controls.log'
with log.open('xb')as f:p=subprocess.run(cmd,cwd=source,stdout=f,stderr=subprocess.STDOUT,timeout=180)
after=source_pins();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
terminal={'schema':'hepta.hia.merged-caller-selection-store-source-admission.v1','source_head':head,'exit_code':p.returncode,'argv':cmd,'source_fetch_exit':fetch_exit,'wall_seconds':time.monotonic()-began,'source_unchanged':before==after,'source_entries':len(before),'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source)),'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'complete_original_caller_suites_qualified':False,'whole_native_delivery_qualified':False}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n')
print(json.dumps(terminal),flush=True)
print(log.read_text()[-20000:],flush=True)
raise SystemExit(p.returncode or (0 if before==after else 1))