from pathlib import Path
import ast,sys,json,subprocess,hashlib,os,time
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'carrier-stage19-registration-v1';out.mkdir(mode=0o700,exist_ok=False)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env)
head='f87a8d59ba96b38d16da5640d9807fc0b05460c7'
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
sys.path.insert(0,str(root))
from tools import hia_selfhost_contract as source_contract
from hepta import hia_agent_contract as native_contract
r=json.loads((root/'docs/evidence/hia-native-carrier-policy-20261128/source-registration.json').read_bytes())
assert r['shared_catalog_and_source_tuple_changed'] is False
assert set(r['new_native_sources'])=={'examples/hia_bootstrap/carrier_cell_policy.hepta','examples/hia_bootstrap/carrier_image_policy.hepta','examples/hia_bootstrap/release_stage_carrier_policies.hiastd'}
assert set(r['sources'])==set(r['new_native_sources'])|set(r['host_source_registration'])
for name,pin in r['sources'].items():
 raw=(root/name).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],name
native_add=sorted(set(r['new_native_sources'])-set(native_contract.NATIVE_SOURCE_FILES))
source_add=sorted(set(r['sources'])-set(source_contract.SOURCE_FILES))
snap=out/'before';snap.mkdir()
pins={}
def capture(name):
 raw=(root/name).read_bytes();p=snap/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 pins[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};return raw
def append_tuple(name,key,added):
 raw=capture(name);old=next(n for n in ast.parse(raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==key for t in n.targets))
 anchor=(key+' = (\n').encode();assert raw.count(anchor)==1
 new=raw.replace(anchor,anchor+''.join('    '+repr(p)+',\n' for p in added).encode(),1)
 node=next(n for n in ast.parse(new).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==key for t in n.targets))
 assert ast.dump(ast.Tuple(elts=node.value.elts[len(added):],ctx=ast.Load()))==ast.dump(old.value)
 (root/name).write_bytes(new)
append_tuple('hepta/hia_agent_contract.py','NATIVE_SOURCE_FILES',native_add)
append_tuple('tools/hia_selfhost_contract.py','SOURCE_FILES',source_add)
raw=capture('MANIFEST.in');assert raw.endswith(b'\n')
manifest_add=['include '+p for p in sorted(r['sources']) if 'include '+p not in raw.decode().splitlines()]
(root/'MANIFEST.in').write_bytes(raw+b'\n'+('\n'.join(manifest_add)+'\n').encode())
name='tools/generate_hia_release_owner.py';raw=capture(name);text=raw.decode();old=ast.parse(text)
node=next(n for n in old.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RELEASE_DAGS' for t in n.targets))
values=ast.literal_eval(node.value);assert len(values)==18 and values[-1]=='ndu_evaluator' and 'carrier_policies' not in values
seg=ast.get_source_segment(text,node.value);assert text.count(seg)==1 and seg.endswith(')')
body=seg[:-1];body+=('' if body.rstrip().endswith(',') else ',')
new=text.replace(seg,body+"\n    'carrier_policies',\n)",1)
newnode=next(n for n in ast.parse(new).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RELEASE_DAGS' for t in n.targets))
assert ast.literal_eval(newnode.value)==values+('carrier_policies',)
(root/name).write_text(new)
table='examples/hia_bootstrap/release_stage_sources.tsv';before=capture(table)
for n in ('release_owner','release_dag','release_owner_packer'):capture('examples/hia_bootstrap/'+n+'.hepta')
steps=[]
for label,argv in [('carrier-dag-check',['-m','tools.generate_hia_carrier_policy_release','--check']),('catalog',['-m','tools.generate_hia_release_extension_catalog']),('controller14',['-m','unittest','-v','tests.test_hia_controller_catalog_preservation'])]:
 start=time.monotonic();p=subprocess.run([sys.executable,'-B',*argv],cwd=root,env=env,capture_output=True,timeout=120)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 steps.append({'label':label,'returncode':p.returncode,'wall_seconds':time.monotonic()-start})
 (out/'steps.json').write_text(json.dumps(steps,sort_keys=True,indent=2)+'\n')
 assert p.returncode==0,(label,p.stderr.decode())
after=(root/table).read_text().splitlines()
assert after[0]=='stage\t19\t111'
assert [line for line in after[1:] if int(line.split('\t')[1])<=18]==before.decode().splitlines()[1:]
stage19='\n'.join(line for line in after[1:] if int(line.split('\t')[1])==19)+'\n'
(out/'stage19-complete-rows.tsv').write_text(stage19)
from tools.hia_native_release_dependencies import release_dependencies
dep=release_dependencies(root);assert dep['declared_stages']==19 and dep['publication_count']==111
(out/'release-dependencies.json').write_text(json.dumps(dep,sort_keys=True,indent=2)+'\n')
record={'status':'CARRIER_STAGE19_REGISTERED_LINUX_OWNER_AUTHOR_PENDING','source_head':head,'native_added':native_add,'source_added':source_add,'manifest_added':manifest_add,'before_pins':pins,'steps':steps,'original_eighteen_complete_stage_rows_and_order_identical':True,'stages':19,'publications':111,'release_required_sources':len(dep['required_sources']),'full_cold_and_default_installed_qualification':False}
(out/'registration.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record,sort_keys=True),flush=True)
print(stage19,flush=True)
