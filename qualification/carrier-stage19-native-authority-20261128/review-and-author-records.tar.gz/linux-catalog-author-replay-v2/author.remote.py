from pathlib import Path
import os,json,hashlib,tarfile,shutil,subprocess,time,stat,io
os.umask(0o022)
base=Path('/home/qq/hia-final-native-cold-20261128-2ac5')
out=base/'linux-catalog-author-replay-v2'
source=out/'source'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base/'source').decode().strip()=='8953bdbd3cced1aa7db4642865ba00ed7d8f5e0c'
shutil.copytree(base/'source',source,symlinks=True)
with tarfile.open(out/'input.tar.gz','r:gz') as t:
 manifest=json.loads(t.extractfile('candidate-manifest.json').read())
 for name in manifest['overlay']:
  m=t.getmember('overlay/'+name);raw=t.extractfile(m).read();r=manifest['files'][name]
  assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
  p=source/name;assert p.resolve().is_relative_to(source)
  p.parent.mkdir(parents=True,exist_ok=True)
  assert not p.is_symlink();p.write_bytes(raw);p.chmod(r['mode'])
def snapshot(paths):
 rows={}
 for name in paths:
  p=source/name;s=p.lstat()
  raw=os.readlink(p).encode() if stat.S_ISLNK(s.st_mode) else p.read_bytes()
  rows[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'type':'symlink' if stat.S_ISLNK(s.st_mode) else 'file'}
 return rows
for name,r in manifest['files'].items():
 p=source/name
 if r['type']=='file':assert not p.is_symlink();p.chmod(r['mode'])
assert snapshot(manifest['files'])==manifest['files']
(out/'initial.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',TMPDIR=str(base/'tmp'))
steps=[]
for label,module in [('owner','tools.generate_hia_release_owner'),('controller','tools.generate_hia_native_controller_release')]:
 start=time.monotonic()
 p=subprocess.run(['/usr/bin/python3','-B','-m',module],cwd=source,env=env,capture_output=True,timeout=120)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 steps.append({'label':label,'returncode':p.returncode,'wall_seconds':time.monotonic()-start})
 (out/'steps.json').write_text(json.dumps(steps,sort_keys=True,indent=2)+'\n')
 print(json.dumps(steps[-1]),flush=True)
 if p.returncode:raise RuntimeError(label+' author failed; full originals preserved')
after=snapshot(manifest['files'])
changed=[name for name in after if after[name]!=manifest['files'][name]]
allowed=['examples/hia_bootstrap/'+n for n in ('release_owner.hepta','release_dag.hepta','release_owner_packer.hepta','source_native_filter_pack.hepta','native_controller_filter_packer.hepta','native_controller_delivery.hepta','release_stage_controller.hiastd','release_stage_sources.tsv')]
assert set(changed)<=set(allowed),changed
controller=allowed[3:];assert all(after[n]==manifest['files'][n] for n in controller)
assert after[allowed[2]]==manifest['files'][allowed[2]]
assert (source/allowed[-1]).read_bytes().splitlines()[0]==b'stage\t19\t111'
record={'status':'COMPLETE_LINUX_RELEASE_AND_CONTROLLER_AUTHORS_REPLAYED','logical_candidate_head':manifest['head'],'physical_checkout_base':manifest['base'],'whole_inputs':len(after),'changed':changed,'products':{n:after[n] for n in allowed},'controller_four_products_and_catalog_unchanged':True,'steps':steps,'whole_native_release_qualified':False}
(out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
with tarfile.open(out/'products.tar.gz','w:gz') as t:
 for n in allowed:t.add(source/n,arcname=n,recursive=False)
 t.add(out/'terminal.json',arcname='terminal.json',recursive=False)
print(json.dumps(record,sort_keys=True),flush=True)
