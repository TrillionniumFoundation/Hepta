"""Run every original ordinary evaluation caller with the retained body forbidden.

The five original explicit administrator-bundle modules retain their separate
gates. Their original inputs are not changed to acquire this new helper.
This command cannot establish whole-project dynamic-caller closure.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import ExitStack
import ctypes
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if __package__ in (None, ''):
    sys.path.insert(0, str(ROOT))
FIXTURE_NAME = 'tests/fixtures/evaluation_callers_19065.json'
FIXTURE_SHA256 = '256e6c83a79fc2f237b4c12dd4bc2ae00d61bee03332b6adc794086b7e081395'


def admit_original_sources(root, records, *, source_proof=None):
    """Admit the fixed complete inventory and only its exact reviewed successors."""
    from hepta.hia_native_helpers import HELPERS
    root = Path(root)
    if source_proof is not None and (type(source_proof) is not dict or source_proof):
        raise ValueError('caller source proof must be a new exact dictionary')
    captured = {}

    def capture(name):
        raw = (root / name).read_bytes()
        if name in captured and raw != captured[name]:
            raise ValueError('evaluation caller source changed during admission: ' + name)
        captured[name] = raw
        return raw

    frozen = capture(FIXTURE_NAME)
    if sha256(frozen).hexdigest() != FIXTURE_SHA256:
        raise ValueError('original evaluation caller inventory changed')
    inventory = json.loads(frozen)
    expected = {record['path']: record['sha256'] for record in inventory['modules'].values()}
    if (type(records) is not dict or records != expected
            or len(inventory['ordinary_modules']) != 7 or inventory['ordinary_count'] != 81
            or len(inventory['ordinary_ordered_ids']) != 81
            or len(inventory['modules']) != 12 or inventory['all_original_tests'] != 183):
        raise ValueError('complete original evaluation source authority differs')
    count = len(HELPERS)
    if count < 35:
        raise ValueError('the original native helper registry lost an owner')
    original_line = b'        self.assertEqual(len(HELPERS), 35)\n'
    current_line = ('        self.assertEqual(len(HELPERS), ' + str(count) + ')\n').encode()
    adjustments, diagnostic_adjustments = [], {}
    historical = 'tests/fixtures/evaluation_historical_controls_v1.json'
    reviewed_paths = {'tests/test_hia_agent_native_machine_validation.py',
                      'tests/test_hia_cost_ledger_native.py', 'tests/test_hia_worker_native_helpers.py'}
    reviewed = {}
    from tests.hia_installed_distribution_history import predecessor
    from tools import hia_native_cold_caller_history as native_history
    from tools import hia_native_cold_composition_history as composition
    installed_predecessors, cold_adjustments, composition_adjustments = {}, {}, {}
    cold_histories, composition_histories = [], []
    def capture_path(path):
        return capture(Path(path).relative_to(root).as_posix())
    for name, digest in records.items():
        physical = capture(name)
        # The retained original, diagnostic and registry-count domains need
        # only their own fixed authorities. Successor history is read only
        # when the physical source is outside those exact existing domains.
        direct = sha256(physical).hexdigest() == digest
        if name == 'tests/test_hia_agent_native_tools.py':
            from tests import hia_caller_diagnostics_admission as original_diagnostics
            direct = direct or original_diagnostics.pin(physical) == original_diagnostics.CURRENT
        if name == 'tests/test_hia_worker_native_helpers.py' and physical.count(current_line) == 1:
            direct = direct or sha256(physical.replace(current_line, original_line, 1)).hexdigest() == digest
        raw, installed_take = physical, capture_path
        if not direct:
            try:
                selected, selected_take = physical, capture_path
                identity = {'bytes': len(selected), 'sha256': sha256(selected).hexdigest()}
                if identity == composition.CURRENT.get(name):
                    projected, history = composition.prepare(
                        root, {name: selected}, take=selected_take)
                    if history is None:
                        raise ValueError('evaluation current source composition lost its history')
                    selected, selected_take = projected[name], history['prior_take']
                    composition_histories.append(history)
                    composition_adjustments[name] = history['review']
                identity = {'bytes': len(selected), 'sha256': sha256(selected).hexdigest()}
                if identity == native_history.KNOWN_CURRENT.get(name):
                    projected, history = native_history.prepare(
                        root, {name: selected}, take=selected_take)
                    selected, selected_take = projected[name], history['prior_take']
                    cold_histories.append(history)
                raw = predecessor(name, selected, root=root, take=selected_take)
                if raw != selected:
                    from tests import hia_native_transport_worker_successor as delivery
                    installed_take = delivery._prior_take(
                        name, selected, raw, root=root, take=selected_take)
                else:
                    installed_take = selected_take
            except OSError as error:
                raise ValueError('required evaluation caller source history is unavailable: ' + name) from error
        if raw != physical:
            installed_predecessors[name] = sha256(raw).hexdigest()
        actual = sha256(raw).hexdigest()
        if actual == digest:
            continue
        if name == 'tests/test_hia_agent_native_tools.py':
            from tests import hia_caller_diagnostics_admission as diagnostics
            helper_name = 'tests/hia_caller_diagnostics_admission.py'
            helper = capture(helper_name)
            if (len(helper) != 5185 or sha256(helper).hexdigest()
                    != '9e11b98d395229bcb38f0b36094da8bffb37e694ba1ad4afdfa998a8392dd578'):
                raise ValueError('exact caller diagnostics source changed')
            projected = raw
            if diagnostics.pin(raw) != diagnostics.CURRENT:
                from tests import hia_native_transport_worker_successor as delivery
                if diagnostics.pin(raw) != delivery.SQLITE_BOUNDARY_SOURCES[name]:
                    raise ValueError('unreviewed diagnostic caller source changed')
                projected = delivery._reverse_sqlite_boundary(name, raw,
                    capture(delivery.SQLITE_BOUNDARY_FIXTURE), delivery.DIAGNOSTIC_FIXTURE,
                    capture(delivery.DIAGNOSTIC_FIXTURE), diagnostics.CURRENT,
                    root=root, take=installed_take)
            diagnostic_adjustments[name] = diagnostics.admit(
                name, projected, digest, capture(diagnostics.FIXTURE))
            continue
        if (name != 'tests/test_hia_worker_native_helpers.py'
                or raw.count(current_line) != 1
                or sha256(raw.replace(current_line, original_line, 1)).hexdigest() != digest):
            if name not in reviewed_paths or not (root / historical).is_file():
                raise ValueError('original caller source differs: ' + name)
            from tests.hia_store_delivery_successor import reverse_exact
            evidence = capture(historical)
            if sha256(evidence).hexdigest() != 'a239054b8a1bc4c3e8b473cd1278cd40c94e25c6030637c6bccdde9025e1d232':
                raise ValueError('historical evaluation caller authority changed')
            inventory = json.loads(evidence)
            if (inventory['schema'] != 'hepta.hia.historical-evaluation-callers.v1'
                    or set(inventory['records']) != reviewed_paths):
                raise ValueError('historical evaluation caller inventory differs')
            row = inventory['records'][name]
            reverse_exact(raw, row, {'bytes': row['old_bytes'], 'sha256': digest})
            reviewed[name] = {'current_sha256': actual, 'original_sha256': digest}
            continue
        adjustments.append({'path': name, 'original_sha256': digest, 'current_sha256': actual,
            'original_helper_count': 35, 'current_helper_count': count,
            'sole_permitted_change': 'one exact registry-count assertion decimal literal',
            'all_other_source_bytes_unchanged': True})
    for history in cold_histories:
        native_history.verify_unchanged(history)
        for name, review in history['review']['native_cold_caller_sources'].items():
            if name in cold_adjustments and cold_adjustments[name] != review:
                raise ValueError('evaluation native cold source reviews disagree')
            cold_adjustments[name] = review
    for history in composition_histories:
        composition.verify_unchanged(history)
    if any((root / name).read_bytes() != raw for name, raw in captured.items()):
        raise ValueError('evaluation caller sources changed at terminal reread')
    if source_proof is not None:
        source_proof.update({
            'schema': 'hepta.hia.evaluation-caller-source-admission.v2',
            'original_fixture': {'path': FIXTURE_NAME, 'bytes': len(frozen), 'sha256': FIXTURE_SHA256},
            'original_source_sha256': dict(expected),
            'captured_source_sha256': {name: sha256(raw).hexdigest()
                                       for name, raw in sorted(captured.items())},
            'registry_count_assertion_adjustments': list(adjustments),
            'reviewed_diagnostic_source_adjustments': diagnostic_adjustments,
            'reviewed_historical_callers': reviewed,
            'installed_distribution_predecessors': installed_predecessors,
            **({'reviewed_native_cold_caller_adjustments': cold_adjustments}
               if cold_adjustments else {}),
            **({'reviewed_current_source_compositions': composition_adjustments}
               if composition_adjustments else {}),
            'terminal_reread_identical': True, 'production_source_exceptions': []})
    return adjustments


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--cold-report', type=Path)
    choice.add_argument('--development-manifest', type=Path)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    from tools.run_hia_unittest_gate import load_declared_suite
    from tools.hia_selfhost_contract import file_digests
    from tools.build_hia_evaluation import INPUTS
    raw = (ROOT / FIXTURE_NAME).read_bytes()
    if sha256(raw).hexdigest() != FIXTURE_SHA256:
        raise ValueError('original evaluation caller inventory changed')
    original = json.loads(raw)
    modules = original['ordinary_modules']
    original_files = {record['path']: record['sha256'] for record in original['modules'].values()}
    source_admission = {}
    count_adjustments = admit_original_sources(ROOT, original_files, source_proof=source_admission)
    if (len(modules) != 7 or original['ordinary_count'] != 81
            or len(original['ordinary_ordered_ids']) != 81
            or len(original['modules']) != 12 or original['all_original_tests'] != 183):
        raise ValueError('the complete original evaluation modules differ')
    suite, planned = load_declared_suite(modules)
    planned = list(planned)
    if planned != original['ordinary_ordered_ids']:
        raise ValueError('original complete 81-method caller inventory differs')
    def source_pins():
        paths = {*INPUTS, *original_files, FIXTURE_NAME,
                 'tools/qualify_hia_evaluation_callers.py',
                 *source_admission['captured_source_sha256']}
        return {**file_digests(), **{name: sha256((ROOT / name).read_bytes()).hexdigest()
                                    for name in sorted(paths)}}
    before = source_pins()
    if any(before.get(name) != digest
           for name, digest in source_admission['captured_source_sha256'].items()):
        raise ValueError('evaluation source changed between admission and complete capture')
    args.evidence.mkdir(mode=0o700, parents=True, exist_ok=False)
    if args.cold_report is not None:
        from tools.build_hia_evaluation import build
        from tools.hia_cold_compiler import compiler_from_cold_report
        manifest = build(args.evidence / 'qualified',
                         compiler_from_cold_report(args.cold_report), args.cold_report)
        scope = 'MATCHING_SOURCE_COLD_SEVEN_ORDINARY_EVALUATION_CALLER_MODULES'
    else:
        manifest = args.development_manifest.resolve(strict=True)
        scope = 'EXPLICIT_DEVELOPMENT_SEVEN_ORDINARY_EVALUATION_CALLER_MODULES'
    from hepta.hia_agent_service import HIAAgentService
    from hepta.hia_evaluation_native import (EvaluationFrame, SELECTOR, REQUEST_MAGIC,
        MATH_MAGIC, OUTPUT_BYTES, installed_evaluation)
    image = installed_evaluation(str(manifest))
    bundle = {str(path): sha256(path.read_bytes()).hexdigest()
              for path in sorted(manifest.parent.rglob('*')) if path.is_file()}
    started, stopped, reference_calls = [], [], []
    entries, frame_counts, per_test_entries = Counter(), Counter(), defaultdict(Counter)
    active = ['outside-test']

    class Result(unittest.TextTestResult):
        def startTest(self, test):
            active[0] = test.id()
            started.append(test.id())
            super().startTest(test)

        def stopTest(self, test):
            stopped.append(test.id())
            super().stopTest(test)
            active[0] = 'outside-test'

    initializer, actual_entry = EvaluationFrame.__init__, image._entry

    def counted_frame(frame, selected, *arguments, **keywords):
        if selected is not image:
            raise AssertionError('ordinary caller selected another evaluation image')
        initializer(frame, selected, *arguments, **keywords)
        frame_counts[active[0]] += 1

    def counted_entry(source, size, output, capacity, state, extent):
        magic, event = struct.unpack('<2Q', ctypes.string_at(source, 16))
        code = actual_entry(source, size, output, capacity, state, extent)
        if magic == REQUEST_MAGIC and code == OUTPUT_BYTES:
            key = 'continuation:' + str(event)
        elif magic == MATH_MAGIC and code == 32:
            key = 'integer:' + str(event)
        else:
            raise AssertionError('evaluation machine return differs from its declared ABI')
        entries[key] += 1
        per_test_entries[active[0]][key] += 1
        return code

    def forbidden(*arguments, **keywords):
        reference_calls.append(active[0])
        raise AssertionError('ordinary caller entered the retained Python evaluation body')

    begin = time.monotonic()
    with ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, {SELECTOR: str(manifest)}))
        stack.enter_context(patch.object(HIAAgentService, '_hia_evaluate_reference', forbidden))
        stack.enter_context(patch.object(EvaluationFrame, '__init__', counted_frame))
        stack.enter_context(patch.object(image, '_entry', counted_entry))
        with (args.evidence / 'tests.log').open('x') as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=Result).run(suite)
    stable = source_pins() == before and all(
        sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in bundle.items())
    anomalies = ('errors', 'failures', 'skipped', 'expectedFailures', 'unexpectedSuccesses')
    clean = result.wasSuccessful() and all(not getattr(result, name) for name in anomalies)
    passed = (clean and stable and started == stopped == planned and result.testsRun == 81
              and not reference_calls and sum(frame_counts.values()) > 0
              and entries['continuation:0'] > 0 and entries['continuation:1'] > 0
              and entries['continuation:2'] > 0 and any(key.startswith('integer:') for key in entries))
    report = {
        'schema': 'hepta.hia.evaluation-seven-ordinary-callers.v1',
        'status': 'PASS' if passed else 'FAIL', 'scope': scope,
        'original_baseline_commit': original['base_commit'],
        'original_modules': modules, 'planned': planned, 'started': started, 'stopped': stopped,
        'actual_tests': result.testsRun, 'wall_seconds': time.monotonic() - begin,
        'errors': [(test.id(), error) for test, error in result.errors],
        'failures': [(test.id(), error) for test, error in result.failures],
        'skipped': [(test.id(), reason) for test, reason in result.skipped],
        'expected_failures': [(test.id(), error) for test, error in result.expectedFailures],
        'unexpected_successes': [test.id() for test in result.unexpectedSuccesses],
        'actual_evaluation_frames': sum(frame_counts.values()),
        'frames_by_original_test': dict(frame_counts),
        'actual_native_event_counts': dict(entries),
        'native_event_counts_by_original_test': dict(per_test_entries),
        'native_image_sha256': image.image_sha256,
        'reference_calls': reference_calls, 'retained_evaluation_body_forbidden': True,
        'reference_poison_scope': 'test process; subprocesses inherit selector, not Python patches',
        'all_seven_ordinary_modules_unfiltered': True, 'original_test_budgets_changed': False,
        'source_and_bundle_unchanged': stable, 'source_pins': before, 'bundle_pins': bundle,
        'original_registry_count_assertion_adjustments': count_adjustments,
        'caller_source_admission': source_admission,
        'separate_original_administrator_scope_gates': original['explicit_scope_modules'],
        'whole_project_dynamic_caller_closure_claimed': False,
        'whole_native_delivery_qualified': False,
    }
    (args.evidence / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'scope', 'actual_tests', 'wall_seconds',
                                                 'actual_evaluation_frames')}))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
