from pathlib import Path
import json,hashlib,sys,re,stat
base=Path('/home/qian-qi/.local/state/hia-azi5-b843-qa/native-release-closeout-20261124T0740Z')
roots=[base,Path('/home/qian-qi/.local/state/hia-azi5-b843-qa/slot-strict-lifetime-20261124/recursion')]
rows=[]
def selected_values(value,prefix=''):
 result=[]
 if isinstance(value,dict):
  for k,v in value.items():
   key=prefix+'/'+k
   if isinstance(v,(str,int)) and any(t in k.lower() for t in ('reference','runtime','executable','command','argv')):result.append({'key':key,'value':v})
   elif isinstance(v,(dict,list)):result.extend(selected_values(v,key))
 elif isinstance(value,list):
  for i,v in enumerate(value):
   if isinstance(v,(dict,list)):result.extend(selected_values(v,prefix+'/'+str(i)))
 return result
for root in roots:
 if not root.is_dir():continue
 for p in sorted(root.iterdir()):
  if p.is_symlink() or 'mcp' not in p.name.lower():continue
  if p.is_file() and p.suffix=='.py' and p.stat().st_size<200000:
   raw=p.read_bytes()
   lines=[line for line in raw.decode(errors='replace').splitlines() if ('reference' in line.lower() or 'beb253af' in line) and len(line)<2000]
   if lines:rows.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'reference_lines':lines})
  elif p.is_dir():
   for name in ('qualification.json','checkpoint.json','report.json','status.json'):
    q=p/name
    if not q.is_file() or q.stat().st_size>2000000:continue
    raw=q.read_bytes()
    try:values=selected_values(json.loads(raw))
    except (ValueError,UnicodeError):continue
    if values:rows.append({'path':str(q),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'selected_reference_values':values})
print(json.dumps({'read_only':True,'records':rows},sort_keys=True),flush=True)
