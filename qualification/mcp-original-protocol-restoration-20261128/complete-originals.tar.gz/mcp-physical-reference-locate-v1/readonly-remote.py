from pathlib import Path
import json,stat,hashlib
roots=[Path('/home/qian-qi/.local/state/hia-azi5-b843-qa/native-release-closeout-20261124T0740Z'),Path('/home/qian-qi/.local/state/hia-azi5-b843-qa/slot-strict-lifetime-20261124/recursion')]
rows=[]
for root in roots:
 row={'root':str(root),'exists':root.is_dir(),'entries':[]}
 if root.is_dir():
  for p in sorted(root.iterdir()):
   if not ('mcp' in p.name.lower() or 'runtime' in p.name.lower() or 'reference' in p.name.lower()):continue
   s=p.lstat();entry={'path':str(p),'mode':s.st_mode,'bytes':s.st_size,'is_dir':p.is_dir()}
   if p.is_dir():
    entry['children']=[{'name':q.name,'bytes':q.lstat().st_size,'mode':q.lstat().st_mode} for q in sorted(p.iterdir()) if not q.is_symlink()]
   row['entries'].append(entry)
 rows.append(row)
print(json.dumps({'roots':rows},sort_keys=True),flush=True)
