from pathlib import Path
import stat,hashlib,json
p=Path('/home/qian-qi/.local/state/hia-azi5-b843-qa/native-release-closeout-20261124T0740Z/runtime-v26-frozen/hepta-runtime')
def identity(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(1<<20),b''):h.update(b)
assert identity(p.lstat())==identity(s)
assert h.hexdigest()=='beb253af13ab729bd8c25c96f2d4b80a2c931c905ad33559ef8997f4cabf43c7'
print(json.dumps({'path':str(p),'bytes':s.st_size,'sha256':h.hexdigest(),'mode':stat.S_IMODE(s.st_mode),'physical_identity':identity(s)},sort_keys=True),flush=True)
