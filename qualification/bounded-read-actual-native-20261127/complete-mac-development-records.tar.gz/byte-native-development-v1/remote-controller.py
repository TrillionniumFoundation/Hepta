from pathlib import Path
import json,sys,hashlib,os,subprocess,time
root=Path('/home/qian-qi/hia-byte-components-435-20261127-2ac5')
terminal=json.loads((root/'materialization-terminal.json').read_bytes())
assert terminal['status']=='PASS' and terminal['head']=='435b886ff14850c699ed6de319cbf3fd704a5b77'
payload=json.loads(sys.argv[1])
for name,source in payload.items():
 path=root/name
 with path.open('x') as f:f.write(source)
 os.chmod(path,0o600)
out=root/'development-native-execution-v1';out.mkdir(mode=0o700)
py='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
command=[py,'-B',str(root/'development-behavior.py')]
record={'schema':'hepta.hia.byte-development-execution-journal.v1','state':'prepared','source_head':terminal['head'],'command':command,'driver_sha256':hashlib.sha256((root/'development-behavior.py').read_bytes()).hexdigest(),'builder_sha256':hashlib.sha256((root/'development-build.py').read_bytes()).hexdigest(),'outer_original_seconds':180,'cleanup_seconds':3}
(out/'journal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
 p=subprocess.Popen(command,cwd=root/'source',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'),stdout=stdout,stderr=stderr)
 record.update(state='running',pid=p.pid);(out/'journal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
 code=p.wait()
record.update(state='exited',exit_code=code,wall_seconds=time.monotonic()-started)
(out/'journal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record),flush=True);print((out/'stdout.log').read_text(),flush=True)
if code:print((out/'stderr.log').read_text(),flush=True)
raise SystemExit(code)
