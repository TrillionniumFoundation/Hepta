from pathlib import Path
import json,hashlib,subprocess,stat,sys,os,time
root=Path('/home/qian-qi/hia-byte-components-435-20261127-2ac5');source=root/'source';git=['git','-C',str(source)]
old=json.loads((root/'development-native-execution-v1/journal.json').read_bytes())
assert old['state']=='exited' and old['exit_code']==1
receipt=json.loads((root/'development-native-behavior-v1/original-budgets.process-owner.json').read_bytes())
assert receipt['cleanup']['complete'] is True and receipt['cleanup']['observed_echild'] is True
manifest=json.loads((root/'source-manifest-32cfaede.json').read_bytes())
assert manifest['head']=='32cfaede1f87fe1494667dd9a27deab3edc5d709'
pack=root/'additional-objects-32cfaede.pack';raw=pack.read_bytes()
assert len(raw)==manifest['pack_bytes'] and hashlib.sha256(raw).hexdigest()==manifest['pack_sha256']
assert subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()=='435b886ff14850c699ed6de319cbf3fd704a5b77'
assert not subprocess.check_output(git+['status','--porcelain'])
os.umask(0o022)
with pack.open('rb') as f:subprocess.run(git+['index-pack','--stdin'],stdin=f,check=True,stdout=subprocess.DEVNULL)
subprocess.run(git+['checkout','-q',manifest['head']],check=True)
for row in manifest['files']:
 p=source/row['path'];info=p.lstat();raw=p.read_bytes()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
 assert stat.S_IMODE(info.st_mode)==(0o755 if row['mode']=='100755' else 0o644)
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha1']
assert not subprocess.check_output(git+['status','--porcelain'])
(root/'materialization-terminal-32cfaede.json').write_text(json.dumps({'status':'PASS','head':manifest['head'],'files':len(manifest['files']),'full_bytes_modes_sha256_git_sha1_verified':True})+'\n')
drivers=json.loads(sys.argv[1])
for name,text in drivers.items():
 with (root/name).open('x') as f:f.write(text)
out=root/'development-native-execution-v2';out.mkdir(mode=0o700)
py='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
command=[py,'-B',str(root/'development-behavior-v2.py')]
journal={'schema':'hepta.hia.byte-development-execution-journal.v1','state':'prepared','source_head':manifest['head'],'command':command,'outer_original_seconds':180,'cleanup_seconds':3,'driver_sha256':hashlib.sha256((root/'development-behavior-v2.py').read_bytes()).hexdigest()}
(out/'journal.json').write_text(json.dumps(journal,sort_keys=True,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
 p=subprocess.Popen(command,cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'),stdout=stdout,stderr=stderr)
 journal.update(state='running',pid=p.pid);(out/'journal.json').write_text(json.dumps(journal,sort_keys=True,indent=2)+'\n')
 code=p.wait()
journal.update(state='exited',exit_code=code,wall_seconds=time.monotonic()-started)
(out/'journal.json').write_text(json.dumps(journal,sort_keys=True,indent=2)+'\n')
print(json.dumps(journal),flush=True);print((out/'stdout.log').read_text(),flush=True)
if code:print((out/'stderr.log').read_text(),flush=True)
raise SystemExit(code)
