from pathlib import Path
import os,stat,json,hashlib,tarfile,io
root=Path('/home/qian-qi/hia-byte-components-435-20261127-2ac5')
destination=Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-root-consolidation-20261127-2ac5/byte-components-development-evidence-v1')
destination.mkdir(mode=0o700)
for version,code in [(1,1),(2,1),(3,0)]:
 journal=json.loads((root/f'development-native-execution-v{version}/journal.json').read_bytes())
 assert journal['state']=='exited' and journal['exit_code']==code
 receipt=json.loads((root/f'development-native-behavior-v{version}/original-budgets.process-owner.json').read_bytes())
 assert receipt['cleanup']['complete'] is True and receipt['cleanup']['observed_echild'] is True
report=json.loads((root/'development-native-behavior-v3/work/report.json').read_bytes())
assert report['status']=='DEVELOPMENT_FINITE_55_PLUS_8_AND_7_CLI_PASS'
assert report['source_initial_terminal_identical'] and report['compiler_initial_terminal_identical']
assert report['source_head']=='ea924d1adafcbfde325868f0535d0301abb22c9a' and len(report['groups'])==5
rows=[]
for parent,dirs,files in os.walk(root,followlinks=False):
 if Path(parent)==root:dirs.remove('source')
 for name in files:
  path=Path(parent)/name;info=path.lstat()
  assert stat.S_ISREG(info.st_mode) and info.st_nlink==1,str(path)
  raw=path.read_bytes();after=path.lstat()
  assert (info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
  rows.append({'path':path.relative_to(root).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(info.st_mode)})
rows.sort(key=lambda r:r['path'])
manifest={'schema':'hepta.hia.complete-byte-development-custody.v1','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','source_head':report['source_head'],'files':rows,'file_count':len(rows),'bytes':sum(r['bytes'] for r in rows),'all_failed_and_passed_attempts_preserved':True,'production_activated':False}
mr=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=destination/'complete-rog-development-records.tar.gz'
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz',compresslevel=6) as tar:
  for row in rows:
   raw=(root/row['path']).read_bytes()
   assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
   item=tarfile.TarInfo(row['path']);item.size=len(raw);item.mode=row['mode'];tar.addfile(item,io.BytesIO(raw))
  item=tarfile.TarInfo('COMPLETE-MANIFEST.json');item.size=len(mr);item.mode=0o400;tar.addfile(item,io.BytesIO(mr))
with tarfile.open(archive,'r:gz') as tar:
 assert tar.getnames()==[r['path'] for r in rows]+['COMPLETE-MANIFEST.json']
 for row in rows:
  member=tar.getmember(row['path']);raw=tar.extractfile(member).read()
  assert member.isfile() and member.mode==row['mode'] and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 assert tar.extractfile('COMPLETE-MANIFEST.json').read()==mr
result={'schema':'hepta.hia.complete-byte-development-archive-readback.v1','status':'ALL_MEMBERS_VERIFIED','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_head':report['source_head'],'files':len(rows),'source_bytes':manifest['bytes'],'full_member_readback':True,'all_attempts_terminal':True,'compiler_source_initial_terminal_identical':True,'whole_product_qualified':False}
(destination/'manifest.json').write_bytes(mr);(destination/'readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result),flush=True)
