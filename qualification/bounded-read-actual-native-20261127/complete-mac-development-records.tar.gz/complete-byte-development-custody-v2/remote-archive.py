from pathlib import Path
import os,stat,json,hashlib,tarfile,io
root=Path('/home/qian-qi/hia-byte-components-435-20261127-2ac5')
destination=Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-root-consolidation-20261127-2ac5/byte-components-development-evidence-v2')
destination.mkdir(mode=0o700)
for version,code in [(1,1),(2,1),(3,0)]:
 journal=json.loads((root/f'development-native-execution-v{version}/journal.json').read_bytes())
 assert journal['state']=='exited' and journal['exit_code']==code
 receipt=json.loads((root/f'development-native-behavior-v{version}/original-budgets.process-owner.json').read_bytes())
 assert receipt['cleanup']['complete'] is True and receipt['cleanup']['observed_echild'] is True
report=json.loads((root/'development-native-behavior-v3/work/report.json').read_bytes())
assert report['status']=='DEVELOPMENT_FINITE_55_PLUS_8_AND_7_CLI_PASS'
assert report['source_initial_terminal_identical'] and report['compiler_initial_terminal_identical']
assert report['source_head']=='ea924d1adafcbfde325868f0535d0301abb22c9a' and len(report['groups'])==5
paths=[]
for parent,dirs,files in os.walk(root,followlinks=False):
 if Path(parent)==root:dirs.remove('source')
 paths.extend(Path(parent)/name for name in (*dirs,*files))
paths=sorted(set(paths),key=lambda p:p.relative_to(root).as_posix())
rows=[];inodes={}
for path in paths:
 info=path.lstat();row={'path':path.relative_to(root).as_posix(),'mode':stat.S_IMODE(info.st_mode),'nlink':info.st_nlink,'original_identity':[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_size,info.st_mtime_ns,info.st_ctime_ns]}
 if stat.S_ISREG(info.st_mode):
  raw=path.read_bytes();row['kind']='regular';identity=(info.st_dev,info.st_ino)
  if identity in inodes:row.update(kind='hardlink',linkname=inodes[identity])
  else:inodes[identity]=row['path']
 elif stat.S_ISLNK(info.st_mode):row.update(kind='symlink',linkname=os.readlink(path));raw=os.fsencode(row['linkname'])
 elif stat.S_ISFIFO(info.st_mode):row['kind']='fifo';raw=b''
 elif stat.S_ISDIR(info.st_mode):row['kind']='directory';raw=b''
 else:raise ValueError('unsupported source fixture type: '+str(path))
 after=path.lstat()
 assert (info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());rows.append(row)
manifest={'schema':'hepta.hia.complete-byte-development-custody.v2','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','source_head':report['source_head'],'files':rows,'entry_count':len(rows),'bytes':sum(r['bytes'] for r in rows),'all_failed_and_passed_attempts_preserved':True,'nonordinary_original_test_fixtures_preserved_as_typed_metadata':True,'production_activated':False}
mr=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();archive=destination/'complete-rog-development-records.tar.gz'
types={'regular':tarfile.REGTYPE,'hardlink':tarfile.LNKTYPE,'symlink':tarfile.SYMTYPE,'fifo':tarfile.FIFOTYPE,'directory':tarfile.DIRTYPE}
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz',compresslevel=6) as tar:
  for row in rows:
   item=tarfile.TarInfo(row['path']);item.mode=row['mode'];item.type=types[row['kind']]
   if row['kind'] in ('symlink','hardlink'):item.linkname=row['linkname']
   raw=(root/row['path']).read_bytes() if row['kind']=='regular' else b''
   if row['kind']=='regular':assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
   item.size=len(raw);tar.addfile(item,io.BytesIO(raw) if raw else None)
  item=tarfile.TarInfo('COMPLETE-MANIFEST.json');item.size=len(mr);item.mode=0o400;tar.addfile(item,io.BytesIO(mr))
with tarfile.open(archive,'r:gz') as tar:
 assert tar.getnames()==[r['path'] for r in rows]+['COMPLETE-MANIFEST.json']
 for row in rows:
  member=tar.getmember(row['path']);assert member.type==types[row['kind']] and member.mode==row['mode']
  if row['kind'] in ('regular','hardlink'):raw=tar.extractfile(member).read()
  elif row['kind']=='symlink':raw=os.fsencode(member.linkname);assert member.linkname==row['linkname']
  else:raw=b''
  if row['kind']=='hardlink':assert member.linkname==row['linkname']
  assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 assert tar.extractfile('COMPLETE-MANIFEST.json').read()==mr
summary=[]
for group in report['groups']:
 summary.append({k:v for k,v in group.items() if k not in ('originals','cases','rows','observations')})
result={'schema':'hepta.hia.complete-byte-development-archive-readback.v2','status':'ALL_MEMBERS_VERIFIED','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_head':report['source_head'],'entries':len(rows),'source_bytes':manifest['bytes'],'full_member_readback':True,'all_attempts_terminal':True,'compiler_source_initial_terminal_identical':True,'whole_product_qualified':False,'groups':summary}
(destination/'manifest.json').write_bytes(mr);(destination/'readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='groups'}),flush=True)
