from pathlib import Path
import sys,json,hashlib,subprocess,traceback,os,time
ROOT=Path('/home/qian-qi/hia-byte-components-435-20261127-2ac5')
SOURCE=ROOT/'source';OUT=ROOT/'development-native-behavior-v1';COMPILER=Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/cold/qualification/base/B3.flat')
sys.path.insert(0,str(SOURCE))
from tools import hia_selfhost_process_owner as owner
from tools.qualify_hia_bounded_read import owned_step,population,group_result,image_bundle,environment,SELECTOR,CHECK_ROOT
from tools.hia_bounded_read_checks.source_common import wire,snapshot
META=json.loads((ROOT/'source-manifest.json').read_bytes())
ROWS=[dict(row,size=row['bytes']) for row in META['files']]
PY=sys.executable
def source_capture(path):
 rows=snapshot(SOURCE,ROWS)
 path.write_bytes(wire(rows))
 return {r['path']:{k:r[k] for k in ['mode','bytes','sha256','git_blob_sha1','identity']} for r in rows}
def git_state():
 p=subprocess.run(['git','-C',str(SOURCE),'status','--porcelain'],capture_output=True)
 assert p.returncode==0 and p.stdout==b'',(p.returncode,p.stdout,p.stderr)
 return subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()
def worker():
 out=OUT/'work';out.mkdir(mode=0o700)
 report={'schema':'hepta.hia.actual-byte-development-behavior.v1','status':'HOLD','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','source_head':META['head'],'processes':[],'groups':[],'errors':[],'original_finite_case_count':55,'original_public_method_count':8,'original_cli_child_count':7,'original_cli_child_seconds':20,'outer_seconds':180,'cleanup_seconds':3,'production_activated':False,'whole_product_qualification_claimed':False}
 initial=None;bundle=None;compiler_raw=None
 started=time.monotonic()
 try:
  assert git_state()==META['head']=='435b886ff14850c699ed6de319cbf3fd704a5b77'
  initial=source_capture(out/'physical-source-initial.json')
  compiler_raw=COMPILER.read_bytes()
  assert hashlib.sha256(compiler_raw).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
  build=out/'bounded-build'
  owned_step(owner,out,report,'build',[PY,'-B',str(ROOT/'development-build.py'),'bounded-read',str(COMPILER),str(build)],SOURCE,environment(),60)
  manifest=build/'manifest.json';bundle=image_bundle(manifest);report['bundle_initial']=bundle
  selected=dict(environment(),**{SELECTOR:str(manifest)})
  oracle=SOURCE/'tests/fixtures/hia_program_tools_acffa.py.txt'
  for group in population():
   folder=out/group['name'];cmd=[PY,'-B',str(SOURCE/CHECK_ROOT/group['script']),'--source-root',str(SOURCE),'--manifest',str(manifest),'--output',str(folder)]
   if group['oracle']:cmd+=['--oracle',str(oracle)]
   owned_step(owner,out,report,group['name'],cmd,SOURCE,selected,group['qualification_seconds'])
   report['groups'].append(group_result(folder,group))
  assert image_bundle(manifest)==bundle
  assert len(report['groups'])==5 and len(report['processes'])==6
  report['status']='DEVELOPMENT_FINITE_55_PLUS_8_AND_7_CLI_PASS'
 except BaseException as e:
  report['errors'].append({'type':type(e).__name__,'text':str(e),'traceback':traceback.format_exc()})
 finally:
  try:
   terminal=source_capture(out/'physical-source-terminal.json')
   report['source_initial_terminal_identical']=initial==terminal
   report['compiler_initial_terminal_identical']=compiler_raw==COMPILER.read_bytes()
   report['terminal_head']=git_state()
   if initial!=terminal or compiler_raw!=COMPILER.read_bytes() or report['terminal_head']!=META['head']:report['status']='HOLD'
  except BaseException as e:
   report['status']='HOLD';report['errors'].append({'phase':'terminal','type':type(e).__name__,'traceback':traceback.format_exc()})
  report['wall_seconds']=time.monotonic()-started
  (out/'report.json').write_bytes(wire(report))
  print(json.dumps({'status':report['status'],'groups':len(report['groups']),'errors':report['errors'],'wall_seconds':report['wall_seconds']}),flush=True)
 return 0 if report['status']=='DEVELOPMENT_FINITE_55_PLUS_8_AND_7_CLI_PASS' else 1
if '--worker' in sys.argv:raise SystemExit(worker())
OUT.mkdir(mode=0o700)
final={'schema':'hepta.hia.actual-byte-development-owned-acceptance.v1','status':'HOLD','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','processes':[],'errors':[],'outer_seconds':180,'cleanup_seconds':3,'production_activated':False,'whole_product_qualification_claimed':False}
try:
 owned_step(owner,OUT,final,'original-budgets',[PY,'-B',str(Path(__file__).resolve()),'--worker'],SOURCE,environment(),180)
 report=json.loads((OUT/'work/report.json').read_bytes())
 assert report['status']=='DEVELOPMENT_FINITE_55_PLUS_8_AND_7_CLI_PASS'
 final['status']=report['status']
except BaseException as e:final['errors'].append({'type':type(e).__name__,'text':str(e),'traceback':traceback.format_exc()})
(OUT/'acceptance.json').write_bytes(wire(final))
print(json.dumps({'status':final['status'],'errors':final['errors']}),flush=True)
raise SystemExit(0 if final['status']=='DEVELOPMENT_FINITE_55_PLUS_8_AND_7_CLI_PASS' else 1)
