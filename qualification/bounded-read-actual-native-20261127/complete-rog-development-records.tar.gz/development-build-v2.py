from pathlib import Path
import sys,json,hashlib
SOURCE_ROOT=Path('/home/qian-qi/hia-byte-components-435-20261127-2ac5/source')
sys.path.insert(0,str(SOURCE_ROOT))
from tools.qualify_hia_selfhost import compile_stage
from tools.build_hia_bounded_read import observe_compile,source_inputs,ABI,SOURCE,SCHEMA,wire
from tools.generate_hia_bounded_read import entry_abi
from tools.build_hia_source_build import _check_pack_output
component=sys.argv[1];compiler=Path(sys.argv[2]);output=Path(sys.argv[3])
assert component in ('bounded-read','json-pretty')
compiler_before=compiler.read_bytes()
assert len(compiler_before)==641344 and hashlib.sha256(compiler_before).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
if component=='bounded-read':
 captured=source_inputs();name=SOURCE;schema=SCHEMA
 assert captured[ABI]==wire(entry_abi(captured[name]))
else:
 name='examples/hia_bootstrap/json_pretty.hepta';schema='hepta.hia.json-pretty-native.v1'
 captured={p:(SOURCE_ROOT/p).read_bytes() for p in (name,'hepta/hia_json_pretty_native.py','tools/build_hia_json_pretty.py','tools/build_hia_source_build.py','tools/qualify_hia_selfhost.py','tools/hia_selfhost_child.py')}
output.mkdir(mode=0o700)
image,receipt=compile_stage(output,component,compiler,captured[name])
raw=image.read_bytes()
if component=='bounded-read':
 actual,originals=observe_compile(output,compiler,compiler_before,captured[name],image,receipt)
 assert raw==actual
else:
 actual=_check_pack_output(receipt,(output/(component+'.output.bin')).read_bytes(),artifact=compiler_before,source=captured[name])
 assert actual==raw
 originals={}
assert compiler.read_bytes()==compiler_before
assert all((SOURCE_ROOT/p).read_bytes()==b for p,b in captured.items())
manifest={'schema':schema,'source_sha256':hashlib.sha256(captured[name]).hexdigest(),'image_path':image.name,'image_sha256':hashlib.sha256(raw).hexdigest(),'compiler_sha256':hashlib.sha256(compiler_before).hexdigest()}
report={'schema':'hepta.hia.actual-byte-development-build.v1','status':'DEVELOPMENT_NATIVE_IMAGE_BUILT','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','component':component,'source_head':'32cfaede1f87fe1494667dd9a27deab3edc5d709','component_inputs':{p:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in captured.items()},'native_compile_receipt':receipt,'compiler_originals':originals,'manifest':manifest,'physical_initial_terminal_unchanged':True,'matching_cold_qualification_claimed':False,'production_activated':False}
(output/'build.json').write_bytes(wire(report));(output/'manifest.json').write_bytes(wire(manifest))
print(json.dumps({'status':report['status'],'component':component,'manifest':str(output/'manifest.json')}),flush=True)
