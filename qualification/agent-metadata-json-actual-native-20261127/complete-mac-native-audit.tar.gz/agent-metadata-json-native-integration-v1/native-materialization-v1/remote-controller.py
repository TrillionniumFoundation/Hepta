from pathlib import Path
import os,json,hashlib,stat,subprocess,sys,time
root=Path('/home/qian-qi/hia-agent-metadata-json-native-20261127-2ac5');source=root/'source'
manifest=json.loads((root/'source-manifest.json').read_bytes())
assert manifest['head']=='e86c186f13c3eabd5a81809f1aa4de1228541074'
pack=root/'source-objects.pack';assert pack.stat().st_size==manifest['pack_bytes'] and hashlib.sha256(pack.read_bytes()).hexdigest()==manifest['pack_sha256']
assert not source.exists();source.mkdir(mode=0o700);os.umask(0o022)
subprocess.run(['git','init','-q',str(source)],check=True)
git=['git','-C',str(source)];alternate=Path('/home/qian-qi/hia-helper-catalog-native-v3-20261127-2ac5/source/.git/objects')
assert alternate.is_dir();(source/'.git/objects/info/alternates').write_text(str(alternate)+'\n')
(source/'.git/shallow').write_text(manifest['head']+'\n')
with pack.open('rb') as stream:subprocess.run(git+['index-pack','--stdin'],stdin=stream,check=True,stdout=subprocess.DEVNULL)
subprocess.run(git+['checkout','-q','--detach',manifest['head']],check=True)
for row in manifest['files']:
 p=source/row['path'];info=p.lstat();raw=p.read_bytes()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
 assert stat.S_IMODE(info.st_mode)==(0o755 if row['mode']=='100755' else 0o644)
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha1']
assert not subprocess.check_output(git+['status','--porcelain'])
(root/'materialization-terminal.json').write_text(json.dumps({'status':'ALL_SOURCE_BYTES_AND_MODES_VERIFIED','head':manifest['head'],'files':len(manifest['files']),'source_bytes':sum(r['bytes'] for r in manifest['files']),'git_history_complete':False,'git_history_boundary':manifest['head']})+'\n')
driver=json.loads(sys.argv[1]);(root/'development-driver.py').write_text(driver)
out=root/'native-execution-v1';out.mkdir(mode=0o700)
py='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
command=[py,'-B',str(root/'development-driver.py')]
journal={'schema':'hepta.hia.helper-native-development-journal.v1','state':'prepared','source_head':manifest['head'],'command':command,'driver_sha256':hashlib.sha256((root/'development-driver.py').read_bytes()).hexdigest()}
(out/'journal.json').write_text(json.dumps(journal,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
 p=subprocess.Popen(command,cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'),stdout=stdout,stderr=stderr)
 journal.update(state='running',pid=p.pid);(out/'journal.json').write_text(json.dumps(journal,indent=2)+'\n')
 code=p.wait()
journal.update(state='exited',exit_code=code,wall_seconds=time.monotonic()-started);(out/'journal.json').write_text(json.dumps(journal,indent=2)+'\n')
print(json.dumps(journal),flush=True);print((out/'stdout.log').read_text(),flush=True)
if code:print((out/'stderr.log').read_text(),flush=True)
raise SystemExit(code)
