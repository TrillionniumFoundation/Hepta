from pathlib import Path
import os,sys,json,hashlib,subprocess,time,traceback,unittest
ROOT=Path('/home/qian-qi/hia-agent-metadata-json-native-20261127-2ac5')
SOURCE=ROOT/'source';OUT=ROOT/'native-development-v1'
sys.path.insert(0,str(SOURCE))
from tools import hia_selfhost_process_owner as owner
from tools.qualify_hia_bounded_read import owned_step,environment
from tools.hia_bounded_read_checks.source_common import snapshot,wire
META=json.loads((ROOT/'source-manifest.json').read_bytes())
ROWS=[dict(row,size=row['bytes']) for row in META['files']]
COMPILER=Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/cold/qualification/base/B3.flat')
COMPILER_SHA='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
def capture(path):
 rows=snapshot(SOURCE,ROWS);path.write_bytes(wire(rows))
 return {r['path']:{k:r[k] for k in ['mode','bytes','sha256','git_blob_sha1','identity']} for r in rows}
def state():
 assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
 return subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()
def ids(suite):
 for item in suite:
  if isinstance(item,unittest.TestSuite):yield from ids(item)
  else:yield item.id()
def worker():
 work=OUT/'work';work.mkdir(mode=0o700)
 report={'schema':'hepta.hia.actual-agent-metadata-json-development.v1','status':'HOLD','source_head':META['head'],'scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','errors':[],'whole_product_qualified':False,'production_activated':False}
 initial=None;compiler=None;started=time.monotonic()
 try:
  assert state()==META['head']=='e86c186f13c3eabd5a81809f1aa4de1228541074'
  initial=capture(work/'physical-source-initial.json')
  compiler=COMPILER.read_bytes()
  assert len(compiler)==641344 and hashlib.sha256(compiler).hexdigest()==COMPILER_SHA
  os.environ.update(HEPTA_HIA_AGENT_NATIVE_METADATA_DEVELOPMENT_COMPILER=str(COMPILER),
                    HEPTA_HIA_AGENT_NATIVE_METADATA_EVIDENCE=str(work/'metadata-originals'),
                    HEPTA_HIA_AGENT_JSON_WIRE_DEVELOPMENT_COMPILER=str(COMPILER),
                    HEPTA_HIA_AGENT_JSON_WIRE_DEVELOPMENT_COMPILER_SHA256=COMPILER_SHA,
                    HEPTA_HIA_AGENT_JSON_WIRE_EVIDENCE=str(work/'json-wire-originals'))
  modules=['tests.test_hia_agent_native_metadata','tests.test_hia_agent_native_metadata_integration','tests.test_hia_agent_json_wire']
  suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
  case_ids=list(ids(suite));(work/'all-original-case-ids.json').write_bytes(wire(case_ids))
  assert len(case_ids)==len(set(case_ids))==36
  witness=work/'all-original-native-subprocess-invocations';witness.mkdir(mode=0o700)
  real_run=subprocess.run;serial=[0]
  def witnessed_run(*args,**kwargs):
   serial[0]+=1;name=f'{serial[0]:05d}';started_call=time.monotonic()
   command=args[0] if args else kwargs.get('args')
   record={'command':command,'timeout':kwargs.get('timeout'),'capture_output':kwargs.get('capture_output',False)}
   request=kwargs.get('input')
   if isinstance(request,bytes):(witness/(name+'.request')).write_bytes(request)
   elif isinstance(request,str):(witness/(name+'.request')).write_text(request)
   try:
    result=real_run(*args,**kwargs);record['returncode']=result.returncode
    for suffix,value in [('stdout',result.stdout),('stderr',result.stderr)]:
     if isinstance(value,bytes):(witness/(name+'.'+suffix)).write_bytes(value)
     elif isinstance(value,str):(witness/(name+'.'+suffix)).write_text(value)
    return result
   except BaseException as exc:
    record.update(exception_type=type(exc).__name__,exception_text=str(exc));raise
   finally:
    record['wall_seconds']=time.monotonic()-started_call
    (witness/(name+'.terminal.json')).write_bytes(wire(record))
  try:
   subprocess.run=witnessed_run
   with (work/'unittest.stderr').open('w') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
  finally:subprocess.run=real_run
  report['actual_native_subprocess_invocations']=serial[0]
  report.update(tests_expected=len(case_ids),tests_run=result.testsRun,failures=[(t.id(),e) for t,e in result.failures],test_errors=[(t.id(),e) for t,e in result.errors],skips=[(t.id(),e) for t,e in result.skipped])
  assert result.testsRun==len(case_ids) and not result.skipped and result.wasSuccessful()
  report['status']='ALL_ORIGINAL_AGENT_METADATA_JSON_NATIVE_PASS'
 except BaseException as exc:report['errors'].append({'type':type(exc).__name__,'text':str(exc),'traceback':traceback.format_exc()})
 finally:
  try:
   terminal=capture(work/'physical-source-terminal.json')
   report.update(source_initial_terminal_identical=terminal==initial,compiler_initial_terminal_identical=compiler==COMPILER.read_bytes(),terminal_head=state())
   if not (terminal==initial and compiler==COMPILER.read_bytes() and state()==META['head']):report['status']='HOLD'
  except BaseException:report['status']='HOLD';report['errors'].append({'phase':'terminal','traceback':traceback.format_exc()})
  report['wall_seconds']=time.monotonic()-started;(work/'report.json').write_bytes(wire(report));print(json.dumps(report),flush=True)
 return 0 if report['status']=='ALL_ORIGINAL_AGENT_METADATA_JSON_NATIVE_PASS' else 1
if '--worker' in sys.argv:raise SystemExit(worker())
OUT.mkdir(mode=0o700)
final={'schema':'hepta.hia.actual-agent-metadata-json-owned-run.v1','status':'HOLD','scope':'DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD','processes':[],'errors':[],'driver_outer_seconds':180,'cleanup_seconds':3,'whole_product_qualified':False}
try:
 owned_step(owner,OUT,final,'native-gates',[sys.executable,'-B',str(Path(__file__).resolve()),'--worker'],SOURCE,environment(),180)
 report=json.loads((OUT/'work/report.json').read_bytes())
 assert report['status']=='ALL_ORIGINAL_AGENT_METADATA_JSON_NATIVE_PASS';final['status']=report['status']
except BaseException:final['errors'].append({'traceback':traceback.format_exc()})
(OUT/'acceptance.json').write_bytes(wire(final));print(json.dumps({'status':final['status'],'errors':final['errors']}),flush=True)
raise SystemExit(0 if final['status']=='ALL_ORIGINAL_AGENT_METADATA_JSON_NATIVE_PASS' else 1)
