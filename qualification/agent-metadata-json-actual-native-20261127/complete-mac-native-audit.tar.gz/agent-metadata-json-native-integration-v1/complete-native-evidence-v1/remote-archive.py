from pathlib import Path
import os,stat,hashlib,json,tarfile,time
roots=[Path('/home/qian-qi/hia-agent-metadata-json-native-20261127-2ac5')]
out=Path('/home/qian-qi/hia-agent-metadata-json-complete-development-evidence-20261127-2ac5');out.mkdir(mode=0o700)
def identity(s):
 return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def capture(p,arc):
 s=p.lstat();row=dict(path=str(p),archive_path=arc,mode=stat.S_IMODE(s.st_mode),identity=identity(s))
 if stat.S_ISREG(s.st_mode):
  raw=p.read_bytes();row.update(kind='file',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 elif stat.S_ISDIR(s.st_mode):row['kind']='directory'
 elif stat.S_ISLNK(s.st_mode):row.update(kind='symlink',link=os.readlink(p))
 elif stat.S_ISFIFO(s.st_mode):row['kind']='fifo'
 else:raise ValueError(('unsupported actual evidence kind',str(p),s.st_mode))
 assert identity(p.lstat())==row['identity'],p
 return row
rows=[];exclusions=[]
for root in roots:
 mf=json.loads((root/'source-manifest.json').read_bytes())
 for q in sorted(root.iterdir()):
  if q.name=='source':
   exclusions.append(dict(path=str(q),reason='complete exact Git tree retained by ancestor commit, all physical bytes/modes separately captured',head=mf['head'],tree=mf['tree'],file_count=mf['file_count'],bytes=mf['source_bytes']))
   continue
  if q.name=='source-objects.pack':
   exclusions.append(dict(path=str(q),reason='reconstructible explicit Git object transport, immutable complete source commit retained',head=mf['head'],bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
   continue
  paths=[q]
  if q.is_dir() and not q.is_symlink():
   for folder,dirs,files in os.walk(q,followlinks=False):
    dirs.sort();files.sort();base=Path(folder)
    for name in dirs+files:paths.append(base/name)
  for p in paths:rows.append(capture(p,root.name+'/'+str(p.relative_to(root))))
assert len(rows)==len({r['archive_path'] for r in rows})
manifest=dict(schema='hepta.hia.complete-agent-metadata-json-development-evidence.v1',scope='complete original 36-method Agent metadata and arena JSON native run; complete immutable source tree remains in Git',entries=rows,excluded_reconstructible_inputs=exclusions,expanded_files_removed=False)
(out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
archive=out/'complete-native-originals.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6,dereference=False) as tf:
 for row in rows:tf.add(row['path'],arcname=row['archive_path'],recursive=False)
terminal=[capture(Path(r['path']),r['archive_path']) for r in rows]
assert terminal==rows,'physical evidence changed during archive'
verified=[]
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.name.rstrip('/')==row['archive_path'].rstrip('/') and member.mode==row['mode']
  if row['kind']=='file':
   assert member.isfile();raw=tf.extractfile(member).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
  elif row['kind']=='directory':assert member.isdir()
  elif row['kind']=='symlink':assert member.issym() and member.linkname==row['link']
  elif row['kind']=='fifo':assert member.isfifo()
  verified.append(row['archive_path'])
result=dict(status='EVERY_TYPED_MEMBER_READ_BACK_AND_PHYSICAL_INPUT_STABLE',archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(rows),files=sum(r['kind']=='file' for r in rows),uncompressed_file_bytes=sum(r.get('bytes',0) for r in rows),all_failures_retained=True,final_tests_run=36,final_native_subprocess_invocations=4,expanded_files_removed=False)
(out/'readback.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result),flush=True)
