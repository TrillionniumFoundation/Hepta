from pathlib import Path
from hashlib import sha1,sha256
import subprocess,json,os,stat,time,sys,tarfile
os.umask(0o022)
original=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5')
base=original/'author-replay-v4';base.mkdir(mode=0o700,exist_ok=False)
source=original/'source'
inputs=json.loads(sys.argv[1]);head=inputs['head'];tree=inputs['tree']
assert head=='c0f25977d12bb6582fdf5839539b5bb9fc92fc21'and tree=='588b0dc51c22b8db0b548bafe4289ced7710ad56'
(base/'driver.py').write_text(sys.argv[2])
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')and k not in ('PYTHONPATH','PYTHONHOME')}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
def git(*args):
 return subprocess.run(['/usr/bin/git',*args],cwd=source,env=env,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='243dddaf39638859ec5ee66fc107f057870422b5'
assert not git('status','--porcelain=v1').strip()
incoming=original/'incoming-source-c0-v1'
record=json.loads((incoming/'snapshot.json').read_bytes())
pack=incoming/'source-snapshot.pack';raw=pack.read_bytes()
assert record['head']==head and record['tree']==tree and record['history_mirror']is False
assert len(raw)==record['pack_bytes']==1011185 and sha256(raw).hexdigest()==record['pack_sha256']=='0b0a44d43e821857ccc41256e60ae2de6b7ceb2eee2eecd1e1fb16057bc8a008'
assert record['existing_complete_tree']=='243dddaf39638859ec5ee66fc107f057870422b5'
shallow=source/'.git/shallow';before=shallow.read_bytes()
assert before==b'243dddaf39638859ec5ee66fc107f057870422b5\n'
# The terminal v2 network fetch left a lock. Preserve its complete bytes and
# require no live source process or open descriptor before removing that exact
# abandoned lock. No product process ran in v2 or the preflight-only v3 attempt.
locks=[]
for name in ('shallow.lock','index.lock'):
 path=source/'.git'/name
 if not path.exists():continue
 s=path.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and s.st_uid==os.geteuid()
 assert 1795839910049*1000000<=s.st_mtime_ns<1795840130000*1000000
 data=path.read_bytes()
 row={'path':str(path),'bytes':len(data),'sha256':sha256(data).hexdigest(),'dev':s.st_dev,'ino':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
 (base/('abandoned-'+name)).write_bytes(data);locks.append((path,s,row))
active=[];open_refs=[]
for process in Path('/proc').iterdir():
 if not process.name.isdigit():continue
 try:
  if process.stat().st_uid!=os.geteuid():continue
  if (process/'cwd').resolve()==source:active.append(int(process.name))
  for fd in(process/'fd').iterdir():
   try:
    s=fd.stat()
    if any((s.st_dev,s.st_ino)==(original_stat.st_dev,original_stat.st_ino)for _,original_stat,_ in locks):
     open_refs.append({'pid':int(process.name),'fd':fd.name})
   except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not active and not open_refs,(active,open_refs)
for path,s,row in locks:
 current=path.lstat()
 assert (current.st_dev,current.st_ino,current.st_size,current.st_mtime_ns,current.st_ctime_ns)==(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert sha256(path.read_bytes()).hexdigest()==row['sha256']
 path.unlink()
(base/'abandoned-fetch-lock-cleanup.json').write_text(json.dumps({'source_processes':active,'open_references':open_refs,'preserved_complete_locks':[row for _,_,row in locks],'origin':'terminal network fetch v2; product not started'},sort_keys=True,indent=2)+'\n')
assert not(source/'.git/shallow.lock').exists()and not(source/'.git/index.lock').exists()
with pack.open('rb')as si,(base/'index.stdout').open('xb')as so,(base/'index.stderr').open('xb')as se:
 p=subprocess.run(['/usr/bin/git','index-pack','--stdin'],cwd=source,env=env,stdin=si,stdout=so,stderr=se,timeout=120)
assert p.returncode==0
# This checkout is an explicit depth-one source snapshot, like its initial
# --depth=1 fetch. The normal complete commit and merge history stays unchanged
# on the public remote and the canonical integration repository.
lock=source/'.git/shallow.lock'
with lock.open('xb')as stream:
 stream.write((''.join(x+'\n'for x in sorted({head,before.decode().strip()}))).encode())
os.replace(lock,shallow)
assert git('rev-parse',head+'^{tree}').decode().strip()==tree
git('checkout','--detach',head)
assert not(source/'.git/objects/info/alternates').exists()
reachable=git('rev-list','--objects','--no-object-names','--missing=print',head).decode().splitlines()
assert not any(x.startswith('?')for x in reachable)
with(base/'snapshot-fsck.stdout').open('xb')as so,(base/'snapshot-fsck.stderr').open('xb')as se:
 p=subprocess.run(['/usr/bin/git','fsck','--connectivity-only','--no-reflogs',head],cwd=source,env=env,stdout=so,stderr=se,timeout=120)
assert p.returncode==0
(base/'materialization.json').write_text(json.dumps({'schema':'hepta.hia.exact-current-shallow-source-materialization.v1','snapshot':record,'old_shallow_boundary':before.decode(),'new_shallow_boundary':shallow.read_text(),'all_current_source_objects_owned':True,'complete_history_mirror':False,'normal_public_commit_bytes_unchanged':True,'reachable_current_snapshot_objects':len(reachable),'prior_network_fetch_failure_preserved':str(original/'author-replay-v2')},sort_keys=True,indent=2)+'\n')
rows={}
for record in git('ls-tree','-rz',head).split(b'\0'):
 if not record:continue
 meta,name=record.split(b'\t',1);mode,kind,oid=meta.split()
 assert kind==b'blob'and mode in(b'100644',b'100755')
 n=os.fsdecode(name);p=source/n;s=p.lstat()
 assert stat.S_ISREG(s.st_mode)and s.st_nlink==1
 raw=p.read_bytes()
 assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid.decode()
 assert bool(s.st_mode&0o111)==(mode==b'100755')
 rows[n]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'blob':oid.decode()}
(base/'physical-source-before.json').write_text(json.dumps({'head':head,'tree':tree,'files':rows,'objects_owned':True,'shallow_source_snapshot':True,'old_source_worktrees_untouched':True},sort_keys=True,indent=2)+'\n')
assert not git('status','--porcelain=v1').strip()
print(json.dumps({'phase':'CURRENT_SOURCE_MATERIALIZED','head':head,'source_files':len(rows),'source_bytes':sum(r['bytes']for r in rows.values()),'objects_owned':True}),flush=True)
temporary=base/'tmp';temporary.mkdir(mode=0o700);env['TMPDIR']=str(temporary)
commands=[
 ('release-owner',['-m','tools.generate_hia_release_owner']),
 ('native-controller',['-m','tools.generate_hia_native_controller_release']),
 ('all-ten-worker-authors',['-m','tools.generate_hia_native_worker_sources','--native-source-authority',str(source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json')]),
 ('worker-compat-stage20',['-m','tools.generate_hia_worker_compat_release'])]
calls=[]
def snapshot():
 result={}
 for name in rows:
  p=source/name;s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1
  raw=p.read_bytes();result[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode)}
 return result
first=None
for repeat in (1,2):
 for label,args in commands:
  phase=str(repeat)+'-'+label
  argv=['/usr/bin/python3','-B',*args];started=time.monotonic()
  with(base/(phase+'.stdout')).open('xb')as so,(base/(phase+'.stderr')).open('xb')as se:
   q=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=120)
  row={'phase':phase,'argv':argv,'returncode':q.returncode,'elapsed_seconds':time.monotonic()-started}
  calls.append(row);(base/'author-calls.json').write_text(json.dumps(calls,sort_keys=True,indent=2)+'\n')
  print(json.dumps(row,sort_keys=True),flush=True)
  if q.returncode:raise RuntimeError('actual Linux author failed: '+phase)
 current=snapshot()
 if first is None:first=current
 else:assert current==first,'whole current source changed on second complete author replay'
changed=[n for n,r in current.items()if r!={k:rows[n][k]for k in ('bytes','sha256','mode')}]
sys.path.insert(0,str(source))
from hepta.hia_agent_contract import NATIVE_SOURCE_FILES
allowed=set(NATIVE_SOURCE_FILES)|{'docs/HIA_WORKER_CURRENT_RECORDS.json'}
assert set(changed)<=allowed,sorted(set(changed)-allowed)
assert not git('ls-files','--others','--exclude-standard').strip()
from tools.hia_native_release_dependencies import release_dependencies,check_authorities
deps=release_dependencies(source);counts=check_authorities(source,deps['required_sources'])
assert len(deps['registered_dags'])==14 and deps['declared_stages']==20 and deps['publication_count']==116
for name,pin in [('tools/hia_frozen_component_sources.py','60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774'),('hepta/hia_agent_service.py','7351b80e8f8d46c6cf1988a56b5eb0d2acb5c31727e3d5e63bf5b6355d1e4525')]:
 assert sha256((source/name).read_bytes()).hexdigest()==pin
result={'schema':'hepta.hia.stage20-current-linux-author-replay.v1','status':'ACTUAL_LINUX_RELEASE_AND_ALL_WORKER_AUTHORS_TWICE_IDENTICAL','head':head,'tree':tree,'source_files':len(rows),'source_bytes':sum(r['bytes']for r in rows.values()),'changed_sources':{n:current[n]for n in changed},'calls':calls,'aggregate_dags':14,'stages':20,'publications':116,**counts,'whole_source_second_replay_identical':True,'whole_cold_qualified':False,'whole_native_installation_qualified':False}
(base/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
with tarfile.open(base/'generated-products.tar.gz','w:gz')as t:
 for n in changed:t.add(source/n,arcname=n,recursive=False)
 t.add(base/'terminal.json',arcname='terminal.json',recursive=False)
print(json.dumps(result,sort_keys=True),flush=True)
