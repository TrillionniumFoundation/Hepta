from pathlib import Path
from hashlib import sha256
import subprocess,json,os,stat,time,sys,tarfile
os.umask(0o022)
base=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5')
source=base/'source';out=base/'author-replay-readback-v5';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[2])
(out/'original-v4-terminal.log').write_bytes(sys.argv[1].encode())
prior=base/'author-replay-v4'
review=json.loads((prior/'actual-generation-output-review.json').read_bytes())
original=json.loads((prior/'physical-source-before.json').read_bytes())
head='c0f25977d12bb6582fdf5839539b5bb9fc92fc21'
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')and k not in('PYTHONPATH','PYTHONHOME')}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_NO_LAZY_FETCH='1')
def git(*args):return subprocess.run(['git',*args],cwd=source,env=env,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()==head==review['source_head']==original['head']
assert len(review['actual_author_calls'])==8 and all(r['returncode']==0 for r in review['actual_author_calls'])
assert set(git('diff','--name-only').decode().splitlines())==set(review['changed_sources'])
authority=json.loads((source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json').read_bytes())
allowed=set(authority['paths'])|{'docs/HIA_WORKER_MANIFEST_CURRENT_RECORDS.json'}
assert len(authority['paths'])==1424 and set(review['changed_sources'])<=allowed
sys.path.insert(0,str(source))
from tools.hia_selfhost_contract import SOURCE_FILES
assert 'docs/HIA_WORKER_MANIFEST_CURRENT_RECORDS.json'in SOURCE_FILES
def snapshot():
 rows={}
 for name in original['files']:
  p=source/name;s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1
  raw=p.read_bytes();t=p.lstat()
  assert(s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns)
  rows[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode)}
 return rows
before=snapshot()
changed=[n for n,r in before.items()if r!={k:original['files'][n][k]for k in('bytes','sha256','mode')}]
assert set(changed)==set(review['changed_sources']) and len(changed)==19
for name,row in review['changed_sources'].items():
 assert all(before[name][k]==row[k]for k in('bytes','sha256'))
(out/'physical-generation-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
with tarfile.open(out/'complete-previous-generated-products.tar.gz','w:gz')as tar:
 for name in changed:tar.add(source/name,arcname=name,recursive=False)
calls=[]
temporary=out/'tmp';temporary.mkdir(mode=0o700);env['TMPDIR']=str(temporary)
commands=[
 ('release-owner',['-m','tools.generate_hia_release_owner']),
 ('native-controller',['-m','tools.generate_hia_native_controller_release']),
 ('all-ten-worker-authors',['-m','tools.generate_hia_native_worker_sources','--native-source-authority',str(source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json')]),
 ('worker-compat-stage20',['-m','tools.generate_hia_worker_compat_release'])]
for label,args in commands:
 argv=['/usr/bin/python3','-B',*args];started=time.monotonic()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:
  p=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=120)
 row={'phase':label,'argv':argv,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-started}
 calls.append(row);(out/'author-calls.json').write_text(json.dumps(calls,sort_keys=True,indent=2)+'\n');print(json.dumps(row,sort_keys=True),flush=True)
 assert p.returncode==0
after=snapshot();(out/'physical-generation-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
assert before==after,'complete physical generation changed during replay'
assert not git('ls-files','--others','--exclude-standard').strip()
from tools.hia_native_release_dependencies import release_dependencies,check_authorities
deps=release_dependencies(source);counts=check_authorities(source,deps['required_sources'])
assert len(deps['registered_dags'])==14 and deps['declared_stages']==20 and deps['publication_count']==116
result={'schema':'hepta.hia.stage20-actual-linux-generation-replay.v2','status':'ALL_LINUX_AUTHORS_REPRODUCE_COMPLETE_PREVIOUS_GENERATION','head':head,'tree':original['tree'],'changed_sources':{n:after[n]for n in changed},'source_files':len(after),'source_bytes':sum(r['bytes']for r in after.values()),'calls':calls,'previous_attempt_all_eight_author_commands_completed':True,'previous_attempt_scope_observer_failure_preserved':True,'complete_captured_before_after_generations_identical':True,'exact_current_native_authority_used':True,'non_native_generated_record_paths':['docs/HIA_WORKER_MANIFEST_CURRENT_RECORDS.json'],'aggregate_dags':14,'stages':20,'publications':116,**counts,'whole_cold_qualified':False,'whole_native_installation_qualified':False}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
with tarfile.open(out/'generated-products.tar.gz','w:gz')as tar:
 for n in changed:tar.add(source/n,arcname=n,recursive=False)
 tar.add(out/'terminal.json',arcname='terminal.json',recursive=False)
print(json.dumps(result,sort_keys=True),flush=True)
