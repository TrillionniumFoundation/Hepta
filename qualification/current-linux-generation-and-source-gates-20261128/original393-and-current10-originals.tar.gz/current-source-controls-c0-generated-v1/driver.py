from pathlib import Path
from hashlib import sha256
import json,subprocess,os,time,stat,tarfile,sys,re
os.umask(0o022)
base=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5');source=base/'source'
out=base/'current-source-controls-c0-generated-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
expected=json.loads((base/'author-replay-readback-v5/physical-generation-after.json').read_bytes())
def check_current():
 for name,row in expected.items():
  p=source/name;s=p.lstat();raw=p.read_bytes()
  assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']and stat.S_IMODE(s.st_mode)==row['mode'],name
check_current()
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')and k not in('PYTHONPATH','PYTHONHOME')}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
argv=[python,'-B','-m','unittest','-v','tests.test_hia_current_source_generation'];started=time.monotonic()
with(out/'tests.stdout').open('xb')as so,(out/'tests.stderr').open('xb')as se:
 p=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=120)
data=(out/'tests.stderr').read_bytes();check_current()
passed=p.returncode==0 and re.search(rb'^Ran 10 tests in [0-9.]+s$',data,re.M)is not None and re.search(rb'^OK$',data,re.M)is not None
record={'status':'PASS'if passed else'FAIL','returncode':p.returncode,'argv':argv,'elapsed_seconds':time.monotonic()-started,'tests':10,'complete_current_physical_sources_unchanged':True,'actual_source_files':len(expected),'historical393_is_separate_scope':True,'whole_product_qualified':False}
(out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record,sort_keys=True),flush=True)
if not passed:print(data.decode());raise SystemExit(1)
historical=base/'original393-current-generation-v1'
gate=json.loads((historical/'result.json').read_bytes())
assert gate['passed']is True and gate['reported_tests']==393 and gate['timed_out']is False
assert gate['source_preparation']['terminal_reread_identical']is True
proof=base/'complete-original393-and-current-controls-v1';proof.mkdir(mode=0o700,exist_ok=False)
items=[]
for folder in (out,base/'original393-supervisor-v1'):
 for p in sorted(folder.rglob('*')):
  if p.is_file():items.append((p,folder.name+'/'+str(p.relative_to(folder))))
for name in ('result.json','tests.stdout','tests.stderr'):items.append((historical/name,'original393/'+name))
prior_sources=gate['source_preparation']['explicit_prior_sources'];assert len(prior_sources)==5
for name in prior_sources:
 p=historical/'source-view'/name;raw=p.read_bytes();row=prior_sources[name]
 assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
 items.append((p,'explicit-prior-source-view/'+name))
 items.append((source/name,'actual-current-source/'+name))
for name,row in gate['original_test_modules'].items():
 p=historical/'source-view'/name;raw=p.read_bytes()
 assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
 items.append((p,'unchanged-original-test-modules/'+name))
for name in ('tools/hia_current_source_generation.py','tools/qualify_hia_current_source_generation.py','tests/test_hia_current_source_generation.py','tests/fixtures/hia_current_source_generation_v1.json'):
 items.append((source/name,'current-controls-and-reader/'+name))
archive=proof/'complete-original393-and-current-controls.tar.gz';members={}
with tarfile.open(archive,'w:gz')as tar:
 for p,name in items:
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1
  raw=p.read_bytes();members[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode)}
  tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 assert set(tar.getnames())==set(members)
 for m in tar.getmembers():
  raw=tar.extractfile(m).read();assert len(raw)==members[m.name]['bytes']and sha256(raw).hexdigest()==members[m.name]['sha256']
summary={'schema':'hepta.hia.complete-original393-and-current-physical-controls.v1','status':'ORIGINAL393_AND_CURRENT10_PASS_IN_SEPARATE_EXPLICIT_DOMAINS','actual_current_tests':10,'historical_original_tests':393,'original_selectors':47,'historical_unittest_seconds':gate['reported_unittest_seconds'],'original_timeout_seconds':900,'original_modules_unchanged':gate['all_original_test_modules_byte_identical'],'actual_source_files':len(expected),'actual_source_commit':gate['source_head'],'explicit_prior_source_files':list(prior_sources),'current_physical_source_control_passed':True,'current_product_execution_qualified':False,'whole_native_stack_qualified':False,'archive':{'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest()},'members':members}
(proof/'evidence-manifest.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
(proof/'summary.json').write_text(json.dumps({k:v for k,v in summary.items()if k!='members'},sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k!='members'},sort_keys=True),flush=True)
