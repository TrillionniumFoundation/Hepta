from pathlib import Path
from hashlib import sha256
import json,subprocess,os,time,sys
base=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5')
source=base/'source';out=base/'original393-supervisor-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
generated=json.loads((base/'author-replay-readback-v5/terminal.json').read_bytes())
assert generated['status']=='ALL_LINUX_AUTHORS_REPRODUCE_COMPLETE_PREVIOUS_GENERATION'
assert generated['complete_captured_before_after_generations_identical']is True
for name,row in generated['changed_sources'].items():
 raw=(source/name).read_bytes();assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
python=Path('/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python')
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')and k not in('PYTHONPATH','PYTHONHOME')}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_NO_LAZY_FETCH='1')
probe=subprocess.run([str(python),'-B','-c','import sys,z3,jsonschema,json;print(json.dumps(dict(executable=sys.executable,prefix=sys.prefix,z3=z3.get_version_string())))'],env=env,capture_output=True,check=True)
(out/'python-prerequisite.stdout').write_bytes(probe.stdout);(out/'python-prerequisite.stderr').write_bytes(probe.stderr)
assert json.loads(probe.stdout)['z3']=='4.15.4'
target=base/'original393-current-generation-v1'
argv=[str(python),'-B','tools/qualify_hia_current_source_generation.py','--source',str(source),'--output',str(target),'--python',str(python)]
(out/'intent.json').write_text(json.dumps({'argv':argv,'actual_source_commit':generated['head'],'actual_generated_sources':generated['changed_sources'],'original_source_control_tests':393,'original_source_control_timeout':900,'scope':'EXPLICIT_RETAINED_SOURCE_CONTROLS_NOT_WHOLE_PRODUCT_QUALIFICATION'},sort_keys=True,indent=2)+'\n')
print(json.dumps({'phase':'ORIGINAL_47_SELECTORS_393_CONTROLS_BEGIN','original_timeout_seconds':900,'actual_source_files':generated['source_files'],'source_head':generated['head'],'actual_generated_sources':len(generated['changed_sources'])}),flush=True)
started=time.monotonic()
with(out/'qualifier.stdout').open('xb')as so,(out/'qualifier.stderr').open('xb')as se:
 p=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=1200)
result={'returncode':p.returncode,'elapsed_seconds':time.monotonic()-started,'output':str(target),'stdout':(out/'qualifier.stdout').read_text(),'stderr':(out/'qualifier.stderr').read_text()}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True),flush=True)
raise SystemExit(p.returncode)
