from pathlib import Path
from hashlib import sha256
import subprocess,json,os,time,traceback
R=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5');S=R/'source';D=R/'future-current-build-driver-v1';D.mkdir(mode=0o700,exist_ok=False)
env=dict(os.environ,TMPDIR=str(R/'tmp'),PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
q={'schema':'hepta.hia.future-current-build-supervisor.v1','passed':False,'whole_release_qualified':False}
def pin(b):return {'bytes':len(b),'sha256':sha256(b).hexdigest()}
def save():(D/'report.json').write_text(json.dumps(q,indent=2)+'\n')
try:
 candidate=(R/'cancellation-native-v1/qualification.json').read_bytes();cc=json.loads(candidate)
 assert cc['qualified'] is True and cc['compiler_sha256']=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 assert cc['original_and_lifecycle']['original_pairs']==12 and cc['capabilities_and_guards']['actual_calls']==51
 assert cc['concurrency']['retained_reference_threads']==16 and cc['concurrency']['last_reference_pin_races']==80
 assert cc['kernel_and_retirement']['cancel_commit_races']==80 and len(cc['fault_injection'])==4
 assert cc['packing']['native_pack_negative_guards']==25 and cc['packing']['native_packer_equals_independent_reference'] is True
 actual=(R/'cancellation-native-v1/publication_cancellation.flat').read_bytes()
 assert pin(actual)=={'bytes':365653,'sha256':'b21c15d0cf683726f8a74a0cc5c9f7a5a0a809d748cea8bf82836166da6f9663'}
 for row in cc['build']:
  source=(S/'examples/hia_bootstrap'/(row['role']+'.hepta')).read_bytes()
  assert len(source)==row['source_bytes'] and sha256(source).hexdigest()==row['source_sha256'] and row['two_builds_identical'] is True
  flat=(R/'cancellation-native-v1'/(row['role']+'.flat')).read_bytes()
  assert len(flat)==row['image_bytes'] and sha256(flat).hexdigest()==row['image_sha256']
 prior=D/'prior';prior.mkdir()
 names=['docs/HIA_PUBLICATION_CANCELLATION_NATIVE.json','docs/HIA_NATIVE_FUTURE_RELEASE_BUILD.json','docs/HIA_NATIVE_FUTURE_RESOURCE_INTEGRATION_QUALIFICATION.json','docs/HIA_NATIVE_GENERATION_LEASE_RELEASE_BUILD.json','examples/hia_bootstrap/release_stage_future.hiastd','examples/hia_bootstrap/release_stage_generation_lease.hiastd','examples/hia_bootstrap/release_stage_sources.tsv','tools/qualify_hia_future_native_release.py']
 for name in names:
  p=prior/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/name).read_bytes())
 (S/'docs/HIA_PUBLICATION_CANCELLATION_NATIVE.json').write_bytes(candidate)
 path=S/'tools/qualify_hia_future_native_release.py';original=path.read_text()
 old="(364751, '6458c979f848747478e4fc0fdfb15d74adec63e849558a9e22c800cb3b94ffe0')"
 new="(365653, 'b21c15d0cf683726f8a74a0cc5c9f7a5a0a809d748cea8bf82836166da6f9663')"
 assert original.count(old)==1
 revised=original.replace(old,new,1);path.write_text(revised)
 q['qualification_successor']={'original':pin(original.encode()),'current':pin(revised.encode()),'only_actual_qualified_cancellation_product_pin_changed':True,'original_assertions_preserved':True,'current_actual_complete_qualification':pin(candidate)}
 compilepath='/home/qian-qi/hia-native-final-2b154-20261127-2ac5/chain/.hia-build-391f589558372ec2ec0f113466b613c7/stage/hia-source-build'
 argv=['/usr/bin/python3.14','-u','-B','-m','tools.qualify_hia_future_native_release','--compiler',compilepath,'--output',str(R/'future-native-v1'),'--value-qualification',str(S/'docs/HIA_NATIVE_VALUE_RESOURCE_QUALIFICATION.json'),'--future-kind-qualification',str(S/'docs/HIA_NATIVE_FUTURE_RESOURCE_RETIREMENT_QUALIFICATION.json')]
 q['argv']=argv;save();t=time.monotonic_ns()
 with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:p=subprocess.run(argv,cwd=S,env=env,stdout=out,stderr=err,timeout=900)
 q.update(returncode=p.returncode,elapsed_ns=time.monotonic_ns()-t);q['stdout']=pin((D/'stdout').read_bytes());q['stderr']=pin((D/'stderr').read_bytes());save()
 assert p.returncode==0,(D/'stderr').read_text()[-5000:]
 build=json.loads((R/'future-native-v1/build.json').read_bytes())
 assert build['status']=='BUILT_PENDING_FUTURE_BEHAVIOR'
 q.update(passed=True,modules=len(build['modules']),products=build['products'],checks=len(build['checks']))
 oldroot=Path('/home/qian-qi/hia-native-current-20261127-0862/future-lease-release-v3/recovered-original-fixtures')
 q['original_fixtures_exist']=oldroot.is_dir()
 if oldroot.is_dir():
  files=[p for p in oldroot.rglob('*.py') if p.is_file()]
  q['original_fixture_temp_uses']=[{'path':str(p),'lines':[line.strip() for line in p.read_text().splitlines() if any(x in line for x in ('tempfile','/tmp/','mkdtemp','TMPDIR'))]} for p in files if any(x in p.read_text() for x in ('tempfile','/tmp/','mkdtemp','TMPDIR'))]
 save();print(json.dumps(q,indent=2),flush=True)
except BaseException:q['error']=traceback.format_exc();save();print(q['error'],flush=True);raise
