from pathlib import Path
from hashlib import sha256
import subprocess,json,os,time,traceback,sys
R=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5');S=R/'source';D=R/'future-original-closure-driver-v1';D.mkdir(mode=0o700,exist_ok=False)
env=dict(os.environ,TMPDIR=str(R/'tmp'),PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
compiler='/home/qian-qi/hia-native-final-2b154-20261127-2ac5/chain/.hia-build-391f589558372ec2ec0f113466b613c7/stage/hia-source-build'
q={'schema':'hepta.hia.future-original-closure-supervisor.v1','source_base':'de14e0e8a049bb69e856596cb2bd7a50dfbe2c72','passed':False,'whole_release_qualified':False,'calls':[]}
def pin(b):return {'bytes':len(b),'sha256':sha256(b).hexdigest()}
def save():(D/'report.json').write_text(json.dumps(q,indent=2)+'\n')
def run(label,argv,limit):
 t=time.monotonic_ns()
 with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=S,env=env,stdout=out,stderr=err,timeout=limit)
 row={'label':label,'argv':argv,'returncode':p.returncode,'elapsed_ns':time.monotonic_ns()-t}
 for n in ('stdout','stderr'):row[n]=pin((D/(label+'.'+n)).read_bytes())
 q['calls'].append(row);save();print(json.dumps(row),flush=True)
 assert p.returncode==0,(label,(D/(label+'.stderr')).read_text()[-6000:])
try:
 run('complete-original-future-27',['/usr/bin/python3.14','-u','-B','-m','tools.qualify_hia_future_value_integration',
 '--source',str(S),'--compiler',compiler,'--build',str(R/'future-native-v1'),
 '--original-fixtures','/home/qian-qi/hia-native-current-20261127-0862/future-lease-release-v3/recovered-original-fixtures',
 '--original-root-prefix','/home/qian-qi/.local/state/hia-native-final-custody-20261125',
 '--output',str(R/'future-original-27-v1'),'--receipt',str(S/'docs/HIA_NATIVE_FUTURE_RESOURCE_INTEGRATION_QUALIFICATION.json')],12060)
 behavior=json.loads((R/'future-original-27-v1/qualification.json').read_bytes())
 assert behavior['passed'] and behavior['groups']==27 and len(behavior['rows'])==27 and all(x['returncode']==0 for x in behavior['rows'])
 run('current-future-release-build',['/usr/bin/python3.14','-u','-B','-m','tools.qualify_hia_future_native_release','--compiler',compiler,
 '--output',str(R/'future-native-qualified-v1'),'--value-qualification',str(S/'docs/HIA_NATIVE_VALUE_RESOURCE_QUALIFICATION.json'),
 '--future-kind-qualification',str(S/'docs/HIA_NATIVE_FUTURE_RESOURCE_RETIREMENT_QUALIFICATION.json'),
 '--behavior-qualification',str(S/'docs/HIA_NATIVE_FUTURE_RESOURCE_INTEGRATION_QUALIFICATION.json')],900)
 build=(R/'future-native-qualified-v1/build.json').read_bytes();b=json.loads(build)
 assert b['status']=='PASS' and b['inherited_behavior_requalified'] and b['value_class_queries_qualified']
 (S/'docs/HIA_NATIVE_FUTURE_RELEASE_BUILD.json').write_bytes(build)
 run('current-future-release-recipe',['/usr/bin/python3.14','-u','-B','-m','tools.generate_hia_future_native_release'],120)
 owner=Path('/home/qian-qi/hia-frontier9-native-20261127-2ac5/native-gates-v3/owner')
 assert owner.is_dir()
 run('current-lease-stage14',['/usr/bin/python3.14','-u','-B','-m','tools.qualify_hia_generation_lease_native_release','--compiler',compiler,
 '--owner-build',str(owner),'--values',str(R/'future-native-qualified-v1/hia-result-value.core.bin'),
 '--output',str(R/'lease-native-qualified-v1'),'--write-receipt'],900)
 run('current-lease-release-recipe',['/usr/bin/python3.14','-u','-B','-m','tools.generate_hia_generation_lease_native_release'],120)
 q.update(passed=True,future_original_groups=27,future_build=pin(build),lease_build=pin((R/'lease-native-qualified-v1/build-receipt.json').read_bytes()),
 future_products=b['products'],lease_products=json.loads((R/'lease-native-qualified-v1/build-receipt.json').read_bytes())['products'],
 unchanged_original_budgets=True,publication_source_changes=subprocess.check_output(['/usr/bin/git','diff','--name-only'],cwd=S,text=True).splitlines())
 save();print(json.dumps(q,indent=2),flush=True)
except BaseException:q['error']=traceback.format_exc();save();print(q['error'],flush=True);raise
