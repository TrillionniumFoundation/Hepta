from pathlib import Path
from hashlib import sha1,sha256
import subprocess,json,os,time,traceback,sys
R=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5');S=R/'source';BASE=Path('/home/qian-qi/hia-native-final-2b154-20261127-2ac5/source');H='de14e0e8a049bb69e856596cb2bd7a50dfbe2c72'
R.mkdir(mode=0o700,exist_ok=False);(R/'tmp').mkdir(mode=0o700)
env=dict(os.environ,TMPDIR=str(R/'tmp'),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0');env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
q={'schema':'hepta.hia.future-source-closure-development.v1','source_base':H,'complete_git_history_claimed':False,'whole_release_qualified':False,'whole_native_delivery_qualified':False,'calls':[]}
def save():(R/'campaign.json').write_text(json.dumps(q,indent=2)+'\n')
def run(label,argv,timeout):
 t=time.monotonic_ns()
 with (R/(label+'.stdout')).open('xb') as out,(R/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=S,env=env,stdout=out,stderr=err,timeout=timeout)
 row={'label':label,'argv':list(map(str,argv)),'returncode':p.returncode,'elapsed_ns':time.monotonic_ns()-t}
 for kind in ['stdout','stderr']:
  raw=(R/(label+'.'+kind)).read_bytes();row[kind]={'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
 q['calls'].append(row);save();print(json.dumps(row),flush=True)
 if p.returncode:raise RuntimeError(label+' failed; original log retained')
try:
 subprocess.run(['/usr/bin/git','init','-q',str(S)],check=True,capture_output=True,env=env)
 alts=[str(BASE/'.git/objects')]+(BASE/'.git/objects/info/alternates').read_text().splitlines()
 (S/'.git/objects/info/alternates').write_text('\n'.join(dict.fromkeys(alts))+'\n')
 (S/'.git/shallow').write_text(H+'\n')
 subprocess.run(['/usr/bin/git','-C',str(S),'update-ref','refs/heads/codex/hia-native-future-closure-20261127-2ac5',H],check=True,capture_output=True,env=env)
 subprocess.run(['/usr/bin/git','-C',str(S),'checkout','--detach',H],check=True,capture_output=True,env=env,timeout=120)
 assert subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=S,env=env,text=True).strip()==H
 records=subprocess.check_output(['/usr/bin/git','ls-tree','-rz','HEAD'],cwd=S,env=env)
 total=0;count=0
 for row in records.split(b'\0'):
  if not row:continue
  info,name=row.split(b'\t',1);mode,kind,oid=info.split();assert kind==b'blob'
  path=S/os.fsdecode(name);raw=path.read_bytes();assert not path.is_symlink() and mode in (b'100644',b'100755')
  assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid.decode(),str(path)
  assert bool(path.stat().st_mode&0o111)==(mode==b'100755')
  count+=1;total+=len(raw)
 assert not subprocess.check_output(['/usr/bin/git','status','--porcelain','--untracked-files=no'],cwd=S,env=env)
 q['materialized']={'files':count,'bytes':total,'all_blob_ids_and_modes_verified':True,'exact_head':H};save()
 print('FUTURE_CLOSURE_EXACT_SOURCE',count,total,flush=True)
 compiler=Path('/home/qian-qi/hia-native-final-2b154-20261127-2ac5/chain/.hia-build-391f589558372ec2ec0f113466b613c7/stage/hia-source-build')
 assert compiler.stat().st_size==813129 and sha256(compiler.read_bytes()).hexdigest()=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 run('original-cancellation-current-source',['/usr/bin/python3.14','-u','-B','-m','tools.qualify_hia_publication_cancellation','--compiler',str(compiler),'--output',str(R/'cancellation-native-v1')],600)
 q['cancellation']=json.loads((R/'cancellation-native-v1/qualification.json').read_bytes())
 assert q['cancellation']['qualified'] is True
 q['cancellation_actual_passed']=True;save()
 print('CURRENT_CANCELLATION_ORIGINAL_ALL_PASS',json.dumps(q['cancellation']['packing']),flush=True)
except BaseException:q['error']=traceback.format_exc();save();print(q['error'],flush=True);raise
