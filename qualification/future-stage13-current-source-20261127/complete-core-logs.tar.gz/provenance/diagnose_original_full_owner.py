from pathlib import Path
from hashlib import sha256
import os,fcntl,struct,subprocess,json,time,sys,traceback,signal
R=Path('/home/qian-qi/hia-native-final-2b154-20261127-2ac5');S=R/'source';N=R/'export/run/source';D=R/'ordinary-release-full-owner-diagnostic-v1'
D.mkdir(mode=0o700,exist_ok=False)
sys.path.insert(0,str(S))
from tools.generate_hia_release_owner import template
report={'schema':'hepta.hia.ordinary-release-full-owner-diagnostic.v1','scope':'external mechanical state observation; complete native owner starts at phase 0; not a qualification substitute','source_head':'de14e0e8a049bb69e856596cb2bd7a50dfbe2c72','whole_release_claimed':False,'matching_cold_claimed':False,'native_machine_parts_unchanged':True,'deadline_seconds':1800,'initial_state_modified':False}
def pin(b):return {'bytes':len(b),'sha256':sha256(b).hexdigest()}
def save():(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
fds=[]
def seal(name,b,mode=0o400):
 f=os.memfd_create(name,os.MFD_ALLOW_SEALING);fds.append(f);assert os.write(f,b)==len(b);os.fchmod(f,mode);fcntl.fcntl(f,fcntl.F_ADD_SEALS,15);return f
try:
 stagebase=R/'chain/.hia-build-391f589558372ec2ec0f113466b613c7/stage'
 original=(stagebase/'hia-release-owner').read_bytes();prefix,holes=template();labels=['policy_hole','stage_hole','sha_hole']
 starts=[holes[n]+4+struct.unpack_from('<i',original,holes[n])[0] for n in labels]
 assert starts==sorted(starts) and starts[0]==len(prefix)
 parts=[original[a:b] for a,b in zip(starts,starts[1:]+[len(original)])]
 report['original_owner']=pin(original);report['native_parts']={n:pin(b) for n,b in zip(labels,parts)}
 expected=bytearray(prefix)
 struct.pack_into('<2Q',expected,96,len(original),len(original))
 for n,at in zip(labels,starts):struct.pack_into('<i',expected,holes[n],at-holes[n]-4)
 assert original[:len(prefix)]==bytes(expected)
 for name in ['stage','work','published']:(D/name).mkdir(mode=0o700)
 dirs=[os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW) for p in [N,D/'stage',D/'work',D,D/'published']];fds.extend(dirs)
 cold=(R/'chain/cold/final-cold.json').read_bytes();sources=json.loads(cold)['source_manifest'];assert len(sources)==1289
 for name,digest in sources.items():assert sha256((N/name).read_bytes()).hexdigest()==digest,name
 report['source_inventory']=sources
 imagepaths=[stagebase/'hia-subprocess',stagebase/'hia-source-build',stagebase/'hia-source-capture',R/'chain/cold/qualification/base/B3.flat']
 rawcaps=[p.read_bytes() for p in imagepaths]+[cold];caps=[seal('original-cap-'+str(i),b,0o500 if i<3 else 0o400) for i,b in enumerate(rawcaps)]
 report['capabilities']=[{'path':str(p),**pin(b)} for p,b in zip(imagepaths+[R/'chain/cold/final-cold.json'],rawcaps)]
 assert report['capabilities'][1]['sha256']=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 inv=bytearray(struct.pack('<8sQ',b'HIASPI01',len(sources)))
 for n,d in sorted(sources.items()):
  e=n.encode();inv+=struct.pack('<Q',len(e))+bytes.fromhex(d)+e
 for fd,name in [(1001,'terminal-state.bin'),(1002,'before-dag-eight-state.bin')]:
  opened=os.open(D/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);fds.append(opened);os.dup2(opened,fd);fds.append(fd)
 source=(S/'tools/hia_release_owner_syscalls.S').read_text()
 assert source.count('_start:\n')==1 and source.count('advance:\n')==1 and source.count('invalid:\n')==1
 source=source.replace('_start:\n','_start:\n    xor r15d,r15d\n    xor r14d,r14d\n')
 source=source.replace('advance:\n','advance:\n    mov rax,[r15]\n    mov [r14+128],rax\n')
 source=source.replace('action:\n    cmp eax,1','action:\n    mov [r14+136],rax\n    cmp eax,1')
 source=source.replace('stage_action:\n',"""stage_action:
    mov rax,[r15]
    mov [r14+128],rax
    cmp rax,5000
    jne diagnostic_after_checkpoint
    cmp QWORD PTR [r15+1519984],7
    jne diagnostic_after_checkpoint
    cmp QWORD PTR [r14+152],0
    jne diagnostic_after_checkpoint
    mov QWORD PTR [r14+152],1
    mov edi,1002
    call diagnostic_dump_fd
diagnostic_after_checkpoint:
""")
 source=source.replace('syscall_action:\n',"""syscall_action:
    cmp QWORD PTR [r14],60
    jne diagnostic_after_dump
    mov edi,1001
    call diagnostic_dump_fd
diagnostic_after_dump:
""")
 source=source.replace('invalid:\n',"""invalid:
    test r15,r15
    jz diagnostic_invalid_no_state
    test r14,r14
    jz diagnostic_invalid_no_state
    mov QWORD PTR [r14+144],1
    mov edi,1001
    call diagnostic_dump_fd
diagnostic_invalid_no_state:
""")
 source+="""
diagnostic_dump_fd:
    mov eax,1
    mov rsi,r15
    mov edx,STATE_BYTES+160
    syscall
    ret
"""
 asm=D/'diagnostic-capsule.S';asm.write_text(source);obj=D/'diagnostic-capsule.o';raw=D/'diagnostic-capsule.bin'
 subprocess.run(['/usr/bin/as','--64',str(asm),'-o',str(obj)],check=True,capture_output=True)
 subprocess.run(['/usr/bin/objcopy','-O','binary','-j','.text',str(obj),str(raw)],check=True,capture_output=True)
 symbols={name:int(a,16) for a,_,name in (line.split() for line in subprocess.check_output(['/usr/bin/nm','-n',str(obj)],text=True).splitlines())}
 header=bytearray(prefix[:176]);code=bytearray(header+raw.read_bytes());at=len(code)
 for label,part in zip(labels,parts):
  off=176+symbols[label];struct.pack_into('<i',code,off,at-off-4);assert bytes(code[off:off+4])==struct.pack('<i',at-off-4);code+=part;at+=len(part)
 struct.pack_into('<2Q',code,96,len(code),len(code));exe=D/'diagnostic-owner';exe.write_bytes(code);exe.chmod(0o500)
 for label,part in zip(labels,parts):
  off=176+symbols[label];start=off+4+struct.unpack_from('<i',code,off)[0];assert bytes(code[start:start+len(part)])==part
 name=b'published';request=struct.pack('<8s15Q',b'HIAOWN01',0,time.monotonic_ns()+1800_000_000_000,*dirs[:3],*caps,*dirs[3:],len(name),len(inv),0)+b''.join(sha256(b).digest() for b in rawcaps)+name+inv
 reqfd=seal('actual-request',request);(D/'request.bin').write_bytes(request)
 report['diagnostic_capsule']=pin(bytes(code));report['mechanical_source']=pin(source.encode());report['request']=pin(request);save()
 t=time.monotonic_ns()
 print('FULL_NATIVE_OWNER_DIAGNOSTIC_BEGIN',str(D),len(sources),flush=True)
 with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:
  child=subprocess.Popen(['/usr/bin/strace','-D','-f','--seccomp-bpf','-e','trace=execve,execveat','-o',str(D/'trace.log'),'--',str(exe)],stdin=reqfd,pass_fds=tuple(set(fds)),stdout=out,stderr=err,env={'PATH':''},cwd=D,start_new_session=True)
  report['pid']=child.pid;save()
  try:child.wait(timeout=1830)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5);report['external_observer_timeout']=True
 report.update(returncode=child.returncode,elapsed_ns=time.monotonic_ns()-t)
 saved=(D/'terminal-state.bin').read_bytes();report['terminal_state']=pin(saved)
 if len(saved)==4194304+160:
  def q(at):return struct.unpack_from('<Q',saved,at)[0]
  report['terminal']={'phase':q(0),'previous_phase':q(4194304+128),'action':q(4194304+136),'mechanical_invalid':q(4194304+144),'dag8_checkpoint_recorded':q(4194304+152),'plan':list(struct.unpack_from('<16Q',saved,4194304)),'dag_index':q(1519984),'node_index':q(1500040),'operation':q(1500048),'args_count':q(1500064),'current_handle':q(1500056),'current_fd':q(144),'current_bytes':q(152),'published':q(1599904)}
 report['stage_products']={p.name:pin(p.read_bytes()) for p in (D/'stage').iterdir() if p.is_file()}
 report['source_inventory_terminal_unchanged']=all(sha256((N/n).read_bytes()).hexdigest()==v for n,v in sources.items())
 report['diagnostic_observation_complete']=len(saved)==4194464 and not report.get('external_observer_timeout',False)
 save();print(json.dumps({k:v for k,v in report.items() if k not in ('source_inventory','stage_products')},indent=2),flush=True)
except BaseException:
 report['error']=traceback.format_exc();save();print(report['error'],flush=True);raise
finally:
 for fd in set(fds):
  try:os.close(fd)
  except OSError:pass
