from pathlib import Path
from hashlib import sha256
import ctypes as C,struct,json,sys,importlib.util,threading,time,resource,os
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/legacy-packer-fixtures');D=None;resource.setrlimit(resource.RLIMIT_CORE,(0,0))
sp=importlib.util.spec_from_file_location('values',T/'qualify-result-value-core-smoke-v1.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
bp=T/'future-public-native-v5';meta=json.loads((bp/'build.json').read_text());pin=next(x['sha256']for x in meta['products']if x['format']=='flat');entry=m.load(bp/'future-public.flat',pin)
ve=m.load(T/'result-value-native-v4/result-value.flat','e2e3fc40edba9ff0c32784502eb7a0cd619a7ab0667cb0ec68c196646a536616')
calls=0;rows=[]
def u(b,at):return struct.unpack_from('<Q',b,at)[0]
class Public:
 def __init__(self,v):
  self.v=v;self.ctx=C.create_string_buffer(256);self.fs=[];self.leases=[]
  self.call(0,fid=(C.addressof(v.ctx),256,0))
 def call(self,op,fid=(0,0,0),cap=(0,0,0),value=(0,0,0),fn=0,kind=0,timeout=(0,0,0),status=0):
  global calls
  raw=bytearray(192);raw[:8]=b'HIABFP01';struct.pack_into('<Q',raw,8,op)
  for at,x in [(16,fid),(40,cap),(64,value),(104,timeout)]:struct.pack_into('<3Q',raw,at,*x)
  struct.pack_into('<2Q',raw,88,fn,kind);s=C.create_string_buffer(bytes(raw));o=C.create_string_buffer(b'\xb5'*65536,65536)
  rc=entry(s,192,o,65536,self.ctx,256);calls+=1
  assert rc==0 and o.raw[:8]==b'HIABFRP1',(op,rc,o.raw[:128].hex())
  assert u(o.raw,8)==status,(op,status,o.raw[:128].hex())
  return o.raw
 def factory(self):
  r=self.call(1);x=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));assert u(r,16)==3 and x[1][0];self.leases.append(x);return x
 def make(self,fac):
  r=self.call(4,*fac);x=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));assert u(r,16)==2 and x[1][0];self.fs.append(x);return x
 def retain(self,f):
  r=self.call(5,*f);x=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));assert u(r,16)==2;self.fs.append(x);return x
 def drop(self,f):self.call(6,*f);self.fs.remove(f)
 def drop_factory(self,f):self.call(3,*f);self.leases.remove(f)
 def complete(self,f,v,kind=1,status=0):return self.call(12,*f,value=v,kind=kind,status=status)
 def result(self,f,status=0,exception=False,timeout=(0,0,0)):
  r=self.call(11 if exception else 10,*f,timeout=timeout,status=status)
  cap=struct.unpack_from('<3Q',r,72)
  if cap[0]:self.v.held.append(cap)
  return cap,r
 def finish(self):
  for f in self.fs[:]:self.drop(f)
  for f in self.leases[:]:self.drop_factory(f)
  self.call(18)
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});print('PUBLIC_CASE',name,calls,flush=True);(D/'report.json').write_text(json.dumps({'passed':False,'calls':calls,'cases':rows},indent=2)+'\n')
def record(v,cl,msg):
 d=v.empty(dict);v.call(10,d,v.scalar('class'),v.scalar(cl));v.call(10,d,v.scalar('message'),v.scalar(msg));return d
