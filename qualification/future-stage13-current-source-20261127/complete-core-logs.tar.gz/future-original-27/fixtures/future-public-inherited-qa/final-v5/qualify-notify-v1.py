from pathlib import Path
import ctypes,hashlib,json,mmap,os,struct,threading,time,random
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures')
Q=T/'future-public-inherited-qa/final-v5';D=Q/'notify-qa-v1';D.mkdir()
flat=(T/'future-public-inherited-qa/public-native-v5/notify.flat').read_bytes()
mm=mmap.mmap(-1,len(flat),prot=7);mm.write(flat)
FN=ctypes.CFUNCTYPE(ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64)
fn=FN(ctypes.addressof(ctypes.c_char.from_buffer(mm)))
libc=ctypes.CDLL(None,use_errno=True);libc.syscall.restype=ctypes.c_long
U=(1<<64)-1;M=lambda b:int.from_bytes(b,'little')
def buf(n):return ctypes.create_string_buffer(n)
def addr(b):return ctypes.addressof(b)
def put(b,p,n):struct.pack_into('<Q',b,p,n)
def get(b,p):return struct.unpack_from('<Q',b,p)[0]
checks=[]
class Fixture:
 def __init__(self):
  self.w=buf(256);put(self.w,0,M(b'HIABFPS1'));put(self.w,8,os.getpid());self.nodes=[];self.calls=0
 def node(self,keys,active=True):
  n=len(keys);cap=1
  while cap<max(1,2*n):cap*=2
  a,v,q,h=buf(256),buf(max(1,n*96)),buf(max(1,n*8)),buf(cap*8)
  for i,k in enumerate(keys):
   put(v,i*96+48,k);put(v,i*96+56,1)
   s=(((k>>4)^(k>>32))*11400714819323198485)&U;s&=cap-1
   while get(h,s*8):s=(s+1)&(cap-1)
   put(h,s*8,i+1)
  for p,x in {0:M(b'HIABFOB1'),8:get(self.w,48),16:addr(self.w),24:os.getpid(),32:n,40:addr(v),48:n*96,56:addr(q),64:n*8,88:n,96:int(active),104:addr(h),112:cap,120:cap*8}.items():put(a,p,x)
  put(self.w,48,addr(a));row=(a,v,q,h);self.nodes.append(row);return row
 def call(self,key):
  s=buf(64);s.raw=b'HIABFN01'+struct.pack('<Q',key)+bytes(48);o=buf(8192);o.raw=b'\xa5'*8192
  rc=fn(s,64,o,8192,self.w,256);self.calls+=1
  assert rc==0 and o.raw[:8]==b'HIABFNR1',(rc,o.raw[:128])
  return get(o,8),get(o,16),get(o,24)
 def queue(self,row):
  return [get(row[2],i*8)for i in range(get(row[0],72))]
f=Fixture();assert f.call(4096)==(0,0,0)and get(f.w,40)==1 and get(f.w,32)==0;checks.append('empty')
keys=[4096+i*16 for i in range(257)];a=f.node(keys);b=f.node(keys[::-1]);inactive=f.node(keys,False)
rng=random.Random(483);order=list(range(len(keys)));rng.shuffle(order)
for i in order:
 assert f.call(keys[i])==(0,2,2)
 assert f.call(keys[i])==(0,2,0)
assert f.queue(a)==order and f.queue(b)==[256-i for i in order]
assert get(a[0],88)==get(b[0],88)==0 and get(a[0],248)==1
assert not f.queue(inactive);checks.append('257_exact_order_duplicates_inactive')
# Same global serialization makes every subscriber see precisely the same order.
g=Fixture();keys=[(i+1)*0x100000030 for i in range(2051)];nodes=[g.node(keys)for _ in range(4)]
errors=[]
def worker(j):
 try:
  for k in keys[j::8]:
   assert g.call(k)==(0,4,4)
   assert g.call(k)==(0,4,0)
 except BaseException as e:errors.append(repr(e))
threads=[threading.Thread(target=worker,args=(j,))for j in range(8)]
for t in threads:t.start()
for t in threads:t.join(20);assert not t.is_alive()
assert not errors,errors
qs=[g.queue(n)for n in nodes];assert all(q==qs[0]for q in qs)and sorted(qs[0])==list(range(len(keys)))
assert all(get(n[0],88)==0 and get(n[0],248)==1 for n in nodes);checks.append('eight_thread_2051_events_four_observers')
# Real futex waiter is woken from a per-node sticky word even when global wraps.
h=Fixture();node=h.node([0x112233440]);put(h.w,40,0xffffffff);started=threading.Event();waited=[]
def wait_sticky():
 started.set()
 rc=libc.syscall(ctypes.c_long(202),ctypes.c_void_p(addr(node[0])+248),ctypes.c_long(128),ctypes.c_long(0),ctypes.c_void_p(0),ctypes.c_void_p(0),ctypes.c_long(0))
 waited.append((rc,ctypes.get_errno()))
t=threading.Thread(target=wait_sticky);t.start();started.wait();time.sleep(.01)
assert h.call(0x112233440)==(0,1,1);t.join(2);assert not t.is_alive()
assert get(h.w,40)==0 and get(node[0],248)==1 and waited and (waited[0][0]==0 or waited[0][1]==11);checks.append('real_sticky_futex_wake_global_wrap')
# No false wake obligation for unrelated future, and row initial-finished skips.
i=Fixture();n=i.node([0x1000]);put(n[1],56,0);put(n[0],88,0)
assert i.call(0x1000)==(0,1,0) and i.call(0x2000)==(0,0,0) and get(n[0],248)==0;checks.append('initial_finished_unrelated')
# Complete input/global/registry corruption refuses and releases a held mutex.
for field,value in [(0,0),(16,1),(24,os.getpid()+1),(32,0),(40,0),(48,95),(56,0),(64,7),(88,2),(96,2),(104,0),(112,3),(120,1),(72,2),(80,1)]:
 z=Fixture();r=z.node([0x1000]);put(r[0],field,value)
 status,_,_=z.call(0x1000);assert status==107,(field,status);assert get(z.w,32)==0
 checks.append('private_node_refusal_'+str(field))
for field,value in [(0,0),(8,os.getpid()+1),(24,1)]:
 z=Fixture();put(z.w,field,value);assert z.call(0x1000)[0]==107;checks.append('global_refusal_'+str(field))
# Bad request does not run an effect or touch the context.
z=Fixture();before=z.w.raw
for n,delta in [(63,None),(65,None),(64,0),(64,8),(64,16),(64,56)]:
 s=buf(max(n,64));s.raw=(b'HIABFN01'+struct.pack('<Q',0x1000)+bytes(len(s)-16))
 if delta is not None:put(s,delta,0 if delta in(0,8)else 1)
 o=buf(8192);rc=fn(s,n,o,8192,z.w,256);assert rc==0xfffffffd and z.w.raw==before
 checks.append('request_refusal_'+str((n,delta)))
# Native entry views: invalid aliases, zero pointers, end overflow, short outputs.
s=buf(64);s.raw=b'HIABFN01'+struct.pack('<Q',0x1000)+bytes(48);o=buf(8192);w=buf(256)
for av in [(addr(s),64,addr(o),8191,addr(w),256),(addr(s),64,addr(o),8192,addr(w),255),(addr(s),64,addr(o),8192,addr(o)+1,256),(addr(o),64,addr(o),8192,addr(w),256),(U-4,64,addr(o),8192,addr(w),256),(0,64,addr(o),8192,addr(w),256),(addr(s),64,0,8192,addr(w),256)]:
 assert fn(*av)==0xfffffffd;checks.append('view_refusal')
report={'status':'NATIVE_NOTIFY_COMPONENT_PASS','checks':checks,'checks_count':len(checks),'actual_notify_calls':f.calls+g.calls+h.calls+i.calls,'flat_sha256':hashlib.sha256(flat).hexdigest(),'flat_bytes':len(flat),'fixture_kernel_ids':True,'actual_future_integration':False,'whole_wait_or_as_completed':False,'concurrency_threads':8,'concurrency_unique_events':2051,'sticky_real_futex':waited}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
