
.intel_syntax noprefix
.text
.global fault
fault:
 movabs r10,0x1111222233334444
 movabs r11,0x5555666677778888
 cmp [rdi+8],r11
 jne real
 inc qword ptr [r10]
 movabs r11,0x9999aaaabbbbcccc
 cmp [r10],r11
 jne real
 inc qword ptr [r10+8]
 mov r11,rdx
 mov rdi,rdx
 xor eax,eax
 mov ecx,16
 cld
 rep stosq
 movabs rax,0x3130525642414948
 mov [r11],rax
 mov qword ptr [r11+8],5
 xor eax,eax
 ret
real:
 movabs r11,0xddddeeeeffff0000
 jmp r11
