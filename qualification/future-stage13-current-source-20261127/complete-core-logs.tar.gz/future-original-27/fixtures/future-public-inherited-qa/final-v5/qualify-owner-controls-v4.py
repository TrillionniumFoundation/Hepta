from pathlib import Path
import ctypes as C,struct,json,hashlib,importlib.util,threading,time,os,mmap
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');Q=T/'future-public-inherited-qa/final-v5';D=Q/'owner-controls-v4';D.mkdir()
sp=importlib.util.spec_from_file_location('observers',Q/'observer-client-v4.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
u=m.u;rows=[]
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});print('CONTROL',name,flush=True)
def finish(v,p,o):o.finish();p.finish();v.finish()
v,p,o=m.env();fac=p.factory();f=p.make(fac);h=o.start([f])
for cap in[(1,2,3),(h[0],h[1]^1,h[2]),(h[0]+8,h[1],h[2]),((1<<64)-1,0,0)]:
 r,_=o.call(2,handle=cap,status=1);assert u(r,16)==102 and u(p.ctx.raw,48)==h[0]
done('four_wrong_handles_no_dereference')
o.close(h)
for op in(2,3,4):
 r,_=o.call(op,handle=h,status=1);assert u(r,16)==102
finish(v,p,o);done('three_stale_handles_exactly_once')
v,p,o=m.env();wire=bytearray(128);wire[:8]=b'HIABFO01';s=C.create_string_buffer(bytes(wire));out=C.create_string_buffer(131072)
before=p.ctx.raw
cases=[(C.addressof(s),128,C.addressof(out),131071,C.addressof(p.ctx),256),(C.addressof(s),128,C.addressof(out),131072,C.addressof(p.ctx),255),(C.addressof(s),128,C.addressof(out),131072,C.addressof(out)+8,256),(C.addressof(out),128,C.addressof(out),131072,C.addressof(p.ctx),256),(0,128,C.addressof(out),131072,C.addressof(p.ctx),256),((1<<64)-4,128,C.addressof(out),131072,C.addressof(p.ctx),256),(C.addressof(s),128,(1<<64)-10,131072,C.addressof(p.ctx),256)]
for args in cases:assert m.entry(*args)==0xfffffffd and p.ctx.raw==before
finish(v,p,o);done('seven_six_word_view_refusals_context_unchanged')
v,p,o=m.env()
for changed in[(0,0),(8,5),(16,(1<<64)-1),(24,4),(56,1),(120,1)]:
 bad=bytearray(wire);struct.pack_into('<Q',bad,*changed);bs=C.create_string_buffer(bytes(bad));before=p.ctx.raw
 assert m.entry(bs,128,out,131072,p.ctx,256)==0xfffffffd and p.ctx.raw==before
finish(v,p,o);done('six_request_shape_refusals')
# Type2 is reserved for the owned public iterable adapter. It remains linked,
# blocks global destruction and must never be mistaken for an array's buffers.
v,p,o=m.env();node=C.create_string_buffer(256);nodep=C.addressof(node)
for at,value in{0:int.from_bytes(b'HIABFOB1','little'),16:C.addressof(p.ctx),24:os.getpid(),128:1,136:2,144:2}.items():struct.pack_into('<Q',node,at,value)
struct.pack_into('<Q',p.ctx,48,nodep)
r,_=o.call(4,handle=(nodep,1,2),status=1);assert u(r,16)==102 and u(p.ctx.raw,48)==nodep
p.call(18,status=1);struct.pack_into('<Q',p.ctx,48,0);finish(v,p,o);done('lazy_type2_cross_interface_close_refusal')
# Concurrent event delivery and transfer. All subscribers consume the same
# actual notify order, irrespective of when the waiters acquire the mutex.
v,p,o=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(32)];handles=[o.start(fs)for _ in range(4)];answers=[None]*4;errors=[]
def consume(j):
 try:
  got=[]
  for _ in fs:
   f,_,_=o.next(handles[j]);value,_=p.result(f);got.append(int(v.raw(value)))
  o.next(handles[j]);answers[j]=got
 except BaseException as ex:errors.append(repr(ex))
threads=[threading.Thread(target=consume,args=(j,))for j in range(4)]
for t in threads:t.start()
for i in list(range(0,32,2))+list(range(1,32,2)):p.complete(fs[i],v.scalar(i))
for t in threads:t.join(5);assert not t.is_alive()
assert not errors and all(a==answers[0]for a in answers)and sorted(answers[0])==list(range(32)),(errors,answers)
finish(v,p,o);done('four_real_waiting_iterators_32_ordered_completions',order=answers[0])
# mmap/getrandom failures are actual kernel errors, not a simulated policy return.
class Filter(C.Structure):_fields_=[('code',C.c_ushort),('jt',C.c_ubyte),('jf',C.c_ubyte),('k',C.c_uint)]
class Program(C.Structure):_fields_=[('length',C.c_ushort),('filter',C.POINTER(Filter))]
def deny(nr,err):
 libc=C.CDLL(None,use_errno=True);arr=(Filter*4)(Filter(0x20,0,0,0),Filter(0x15,0,1,nr),Filter(0x06,0,0,0x50000|err),Filter(0x06,0,0,0x7fff0000));prog=Program(4,arr)
 assert libc.prctl(38,1,0,0,0)==0
 assert libc.prctl(22,2,C.byref(prog),0,0)==0
for nr,errno,status,kind in[(9,12,3,103),(318,5,1,107)]:
 rd,wr=os.pipe();pid=os.fork()
 if pid==0:
  try:
   os.close(rd);v,p,o=m.env();fac=p.factory();f=p.make(fac)
   wire=bytearray(128);wire[:8]=b'HIABFO01';struct.pack_into('<2Q',wire,16,1,2);wire+=struct.pack('<6Q',*(f[0]+f[1]))
   src=C.create_string_buffer(bytes(wire));dst=C.create_string_buffer(131072)
   deny(nr,errno)
   rc=m.entry(src,len(wire),dst,131072,p.ctx,256)
   assert rc==0 and u(dst.raw,8)==status and u(dst.raw,16)==kind and u(p.ctx.raw,48)==0,(rc,dst.raw[:128].hex())
   finish(v,p,o);os.write(wr,b'PASS');os._exit(0)
  except BaseException:
   os.write(wr,b'FAIL');os._exit(1)
 os.close(wr);result=os.read(rd,100);os.close(rd);_,st=os.waitpid(pid,0);assert st==0 and result==b'PASS',(nr,st,result)
 done('actual_seccomp_kernel_failure_'+str(nr))
# Native packer rejects atomically; every accepted output equals the literal
# mechanical binding and both actual compiled HIA bodies.
build=json.loads((T/'future-public-inherited-qa/owner-native-v1/build.json').read_text())
packrow=next(r for r in build['roles']if r['name'].endswith('_packer'))
packer=m.m.m.load(T/'future-public-inherited-qa/owner-native-v1/owner-packer.flat',packrow['flat_sha256'])
body=(T/'future-public-inherited-qa/owner-native-v1/owner-policy.flat').read_bytes();math=(T/'future-public-inherited-qa/owner-native-v1/math.flat').read_bytes();actual=(T/'future-public-inherited-qa/owner-native-v1/observers.flat').read_bytes()
packet=b'HIABFOPK'+struct.pack('<3Q',len(body),len(math),0)+body+math
records=[packet[:7],packet[:32],b'X'+packet[1:],packet[:24]+struct.pack('<Q',1)+packet[32:],packet+b'x']
for at,n in[(8,0),(16,0),(8,4194305),(16,4194305),(8,len(body)+1),(16,len(math)+1)]:
 wrong=bytearray(packet);struct.pack_into('<Q',wrong,at,n);records.append(bytes(wrong))
for raw in records:
 s=C.create_string_buffer(raw);out=C.create_string_buffer(b'\xac'*len(actual),len(actual));w=C.create_string_buffer(64)
 assert packer(s,len(raw),out,len(out),w,64)==0xfffffffd and out.raw==b'\xac'*len(out)
s=C.create_string_buffer(packet)
for n in[0,1,8,887,len(actual)-1]:
 out=C.create_string_buffer(b'\x91'*max(n,1),max(n,1));w=C.create_string_buffer(64)
 assert packer(s,len(packet),out,n,w,64)==0xfffffffe and u(w.raw,0)==len(actual)and out.raw==b'\x91'*len(out)
done('eleven_native_packer_rejections_five_atomic_short_outputs')
report={'passed':True,'cases':rows,'case_groups':len(rows),'calls':m.calls,'public_calls':m.m.calls,'observer_sha256':build['flat_sha256'],'actual_future_sha256':m.m.pin,'whole_public_iterable':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
