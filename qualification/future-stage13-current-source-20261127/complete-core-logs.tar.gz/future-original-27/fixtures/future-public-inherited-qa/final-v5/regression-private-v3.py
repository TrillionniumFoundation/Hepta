from pathlib import Path
import ctypes as C,struct,importlib.util,json,os,threading,time
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');D=T/'future-public-inherited-qa/final-v5/regression-private-v3';D.mkdir(exist_ok=False)
sp=importlib.util.spec_from_file_location('publicclient',T/'future-public-inherited-qa/final-v5/regression-client-v1.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);h.D=D
v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);keep=p.retain(f);u=h.u;controls=0
for op in range(22):
 allowed=set()
 if op==0:allowed={16,24}
 elif 2<=op<=17 or op in(19,21):allowed=set(range(16,64,8))
 if op in(12,13):allowed|={64,72,80}
 if op==12:allowed.add(96)
 if op==13:allowed.add(88)
 if op in(10,11):allowed|={104,112,120}
 for at in range(16,192,8):
  if at in allowed:continue
  raw=bytearray(192);raw[:8]=b'HIABFP01';struct.pack_into('<Q',raw,8,op);struct.pack_into('<Q',raw,at,1)
  if op==12:struct.pack_into('<Q',raw,96,1)
  if op==13:struct.pack_into('<Q',raw,88,1)
  s=C.create_string_buffer(bytes(raw));o=C.create_string_buffer(b'A'*65536,65536);before=p.ctx.raw
  rc=h.entry(s,192,o,65536,p.ctx,256)
  assert rc==0xfffffffd and o.raw[:128]==b'A'*128 and p.ctx.raw==before,(op,at,rc)
  controls+=1
for op in(22,999,(1<<64)-1):
 raw=struct.pack('<8s23Q',b'HIABFP01',op,*([0]*22));s=C.create_string_buffer(raw);o=C.create_string_buffer(b'A'*65536,65536);before=p.ctx.raw
 assert h.entry(s,192,o,65536,p.ctx,256)==0xfffffffd and o.raw[:128]==b'A'*128 and p.ctx.raw==before;controls+=1
h.done('exact-envelope-all-private-fields',controls=controls)

s=C.create_string_buffer(192);o=C.create_string_buffer(b'B'*65536,65536);w=p.ctx;sptr=C.addressof(s);optr=C.addressof(o);wptr=C.addressof(w)
bad=[(0,192,optr,65536,wptr,256),(sptr,192,0,65536,wptr,256),(sptr,192,optr,65536,0,256),(sptr,192,optr,65535,wptr,256),(sptr,192,optr,65536,wptr,255),((1<<64)-63,192,optr,65536,wptr,256),(sptr,192,(1<<64)-63,65536,wptr,256),(sptr,192,optr,65536,(1<<64)-63,256),(optr,192,optr,65536,wptr,256),(wptr,192,optr,65536,wptr,256),(sptr,192,optr,65536,optr+128,256)]
for args in bad:
 before=(o.raw,w.raw);assert h.entry(*args)==0xfffffffd and(o.raw,w.raw)==before,args
h.done('actual-six-word-null-overlap-overflow-views',controls=len(bad))
for fid in [(0,0,0),(1,2,3),(f[0][0],f[0][1]^1,f[0][2]),(f[0][0],f[0][1],f[0][2]^1)]:p.call(9,fid=fid,cap=f[1],status=3)
for cap in [(0,0,0),(1,2,3),(f[1][0],f[1][1]^1,f[1][2]),(f[1][0],f[1][1],f[1][2]^1)]:p.call(9,fid=f[0],cap=cap,status=3)
other=p.factory();foreign=p.make(other)
p.call(9,fid=f[0],cap=foreign[1],status=3);p.call(2,fid=fac[0],cap=other[1],status=3)
p.drop(f);p.call(9,*f,status=3)
pid=os.fork()
if pid==0:
 try:p.call(9,*keep,status=1);os._exit(0)
 except BaseException:os._exit(80)
assert os.waitpid(pid,0)[1]==0
p.call(20);assert u(p.call(9,*keep),96)==0
p.finish();v.finish();h.done('nonce-cross-factory-stale-retry-and-actual-fork')

# A terminal Future ignores every malformed timeout value before conversion.
v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);p.complete(f,v.scalar('done'))
for timeout in[(1,2,3),v.scalar('not a number'),v.empty(dict),v.scalar(float('inf')),v.scalar(10**100),v.scalar(float('nan'))]:
 cap,r=p.result(f,timeout=timeout);assert v.raw(cap)==b'done'
 cap,r=p.result(f,exception=True,timeout=timeout);assert cap==(0,0,0)and u(r,16)==0
p.finish();v.finish();h.done('terminal-observation-before-timeout-type-and-overflow')

# Lifetime of the runtime value-context anchor is independent from BG leases.
v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);obj=v.scalar('after anchors');p.complete(f,obj);v.drop(obj)
v.call(22);p.drop_factory(fac);cap,r=p.result(f);p.drop(f);p.call(18)
assert v.raw(cap)==b'after anchors';v.drop(cap);assert not v.held;v.call(22,status=6)
h.done('actual-value-anchor-factory-future-result-handoff')
report={'passed':True,'whole_public_future_closed':False,'count':len(h.rows),'calls':h.calls,'cases':h.rows,'image_sha256':h.pin}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PUBLIC_PRIVATE_PASS',report,flush=True)
