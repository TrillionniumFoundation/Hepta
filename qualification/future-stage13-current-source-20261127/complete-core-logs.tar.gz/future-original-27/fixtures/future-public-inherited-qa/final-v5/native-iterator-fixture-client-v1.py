from pathlib import Path
import ctypes as C,struct,json,importlib.util,time,threading,concurrent.futures as cf
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');Q=T/'future-public-inherited-qa/final-v5'
sp=importlib.util.spec_from_file_location('it',Q/'iterable-client-v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
pm=json.loads((T/'future-public-observers-qa/iterator-producer-native-v2/build.json').read_text())
producer=m.m.m.m.load(T/'future-public-observers-qa/iterator-producer-native-v2/producer.flat',pm['flat_sha256']);fn=C.cast(producer,C.c_void_p).value
u=m.u;rows=[];total_value_calls=0
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});print('ACTUAL_NATIVE_ITERATOR',name,flush=True)
def environment(v,fs,fail_stage=0,fail_at=0,status=1,kind=200,iter_ns=0,next_ns=0):
 state=bytearray(192);state[:8]=b'HIABFIF1'
 for at,n in {32:fail_stage,40:fail_at,48:status,56:kind,64:iter_ns,72:next_ns,80:len(fs)}.items():struct.pack_into('<Q',state,at,n)
 error=m.m.m.record(v,'SystemExit'if status==2 else'MemoryError'if kind==103 else'ValueError','actual native iterator error \u0000\ud800')
 env=v.empty(list)
 for value in (v.scalar(bytes(state)),error,v.scalar(b''.join(struct.pack('<6Q',*(f[0]+f[1]))for f in fs))):v.call(16,env,value)
 return env,error
def state(v,env):
 current=v.take(v.call(12,env,v.scalar(0)));raw=v.raw(current);v.drop(current);assert raw[:8]==b'HIABFIF1';return raw
def finish(v,p,a,i):
 global total_value_calls
 m.finish(v,p,a,i);total_value_calls+=v.calls
def read_values(v,p,refs):
 got=[]
 for f in refs:
  value,_=p.result(f);got.append(int(v.raw(value)))
 return got
class Boom(BaseException):pass
class Original:
 def __init__(self,fs,stage=0,at=0,error=None,delay=0):self.fs=fs;self.stage=stage;self.at=at;self.error=error or ValueError('original');self.delay=delay;self.pos=0;self.iter_calls=0;self.next_calls=0
 def __iter__(self):
  self.iter_calls+=1
  if self.delay:time.sleep(self.delay)
  if self.stage==1:raise self.error
  return self
 def __next__(self):
  self.next_calls+=1
  if self.stage==2 and self.pos==self.at:raise self.error
  if self.pos==len(self.fs):raise StopIteration
  value=self.fs[self.pos];self.pos+=1;return value
def originals(n):
 fs=[cf.Future()for _ in range(n)]
 for j,f in enumerate(fs):f.set_result(j)
 return fs
