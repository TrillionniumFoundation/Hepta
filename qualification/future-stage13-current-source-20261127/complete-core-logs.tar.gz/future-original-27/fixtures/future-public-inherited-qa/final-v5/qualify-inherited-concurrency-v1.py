from pathlib import Path
import importlib.util,json,sys,struct,ctypes as C,threading,time,concurrent.futures as cf,traceback,os,io,logging
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');Q=T/'future-public-inherited-qa/final-v5';D=Q/'inherited-concurrency-v1';D.mkdir()
sp=importlib.util.spec_from_file_location('h',Q/'client-v3.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sys.path.insert(0,str(T/'future-public-inherited-source'))
from hepta.hia_background_optimizer import _OptimizationFuture,PublicationCancellation
CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3));rows=[]
def reply(o,kind=0,cap=(0,0,0)):
 raw=bytearray(128);raw[:8]=b'HIAFCBR1';struct.pack_into('<Q',raw,8,kind);struct.pack_into('<3Q',raw,24,*cap);C.memmove(o,bytes(raw),128);return 0
def thread_group(fns):
 errors=[];threads=[]
 def run(f):
  try:f()
  except BaseException:errors.append(traceback.format_exc())
 for f in fns:threads.append(threading.Thread(target=run,args=(f,)))
 for t in threads:t.start()
 for t in threads:t.join(8)
 assert not errors and all(not t.is_alive()for t in threads),errors
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});(D/'report.json').write_text(json.dumps({'passed':False,'rows':rows},indent=2)+'\n');print('INHERITED_CONCURRENT',name,flush=True)
def errorcap(v,r):
 a=struct.unpack_from('<3Q',r,72);assert a[0];v.held.append(a);return a

for op in(22,23):
 for abrupt in(0,1,2):
  v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);payload=v.scalar('stored');env=v.scalar(None);cl='KeyboardInterrupt'if abrupt==2 else'ValueError';exception=h.record(v,cl,'callback identity');events=[];failures=[];keeps=[]
  @CB
  def cb(s,sn,o,on,w,wn):
   try:
    raw=C.string_at(s,sn);actual=(struct.unpack_from('<3Q',raw,16),struct.unpack_from('<3Q',raw,40));assert h.u(p.call(14,*actual),96)==1 and h.u(p.call(25,*actual),96)==0
    got,_=p.result(actual,exception=(op==23));assert v.type(got)[3:]==v.type(payload)[3:]
    keep=p.retain(actual);keeps.append(keep);p.drop(f);events.append('callback')
    if abrupt:
     cap=v.retain(exception);v.held.remove(cap);return reply(o,abrupt,cap)
    return reply(o)
   except BaseException:failures.append(traceback.format_exc());return 99
  @CB
  def after(s,sn,o,on,w,wn):events.append('after');return reply(o)
  p.call(13,*f,value=env,fn=C.cast(cb,C.c_void_p).value);p.call(13,*f,value=env,fn=C.cast(after,C.c_void_p).value);p.drop_factory(fac)
  out=p.call(op,*f,value=payload,kind=1,status=2 if abrupt==2 else 0)
  if abrupt==2:assert h.u(out,16)==200 and v.type(errorcap(v,out))[3:]==v.type(exception)[3:]
  assert events==(['callback']if abrupt==2 else['callback','after'])and not failures,(events,failures)
  assert len(keeps)==1
  got,_=p.result(keeps[0],exception=(op==23));assert v.type(got)[3:]==v.type(payload)[3:]
  p.finish();v.finish()
  # Original state and callback abort/continue behavior, with actual BaseException.
  token=PublicationCancellation();f=_OptimizationFuture(token);seen=[];exc=KeyboardInterrupt('callback identity')if abrupt==2 else ValueError('callback identity')
  def old(f):
   assert f.done()and not f.running();assert(f.exception()if op==23 else f.result())=='stored';seen.append('callback')
   if abrupt:raise exc
  f.add_done_callback(old);f.add_done_callback(lambda f:seen.append('after'))
  try:getattr(f,'set_result'if op==22 else'set_exception')('stored')
  except BaseException as got:assert abrupt==2 and got is exc
  else:assert abrupt!=2
  assert seen==events
 done('typed-callback-normal-exception-base-and-last-external-ref-'+str(op),modes=3)

# Exact critical diagnostic uses native stable kernel identity, not cap nonce.
for st in('running','finished','cancelled'):
 v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac)
 if st=='running':p.call(24,*f)
 elif st=='finished':p.call(22,*f,value=v.scalar(1),kind=1)
 else:p.call(7,*f)
 identity=h.u(p.call(21,*f),96);read,write=os.pipe();saved=os.dup(2);os.dup2(write,2);os.close(write)
 try:out=p.call(24,*f,status=1)
 finally:os.dup2(saved,2);os.close(saved)
 raw=os.read(read,4096);os.close(read)
 state={'running':'RUNNING','finished':'FINISHED','cancelled':'CANCELLED_AND_NOTIFIED'}[st]
 assert raw==f'Future {identity} in unexpected state: {state}\n'.encode(),raw
 assert h.take_error(v,out)=={'class':'RuntimeError','message':'Future in unexpected state'}
 p.finish();v.finish()
done('exact-critical-logging-three-unexpected-states',states=3)

for mode in('result','exception','mixed'):
 v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();env=v.scalar(None);repetitions=32;wins=0
 for n in range(repetitions):
  f=p.make(fac);vals=[v.scalar(j)for j in range(8)];barrier=threading.Barrier(8);outcomes=[];callbacks=[]
  @CB
  def cb(s,sn,o,on,w,wn):callbacks.append(1);return reply(o)
  p.call(13,*f,value=env,fn=C.cast(cb,C.c_void_p).value)
  def contender(j):
   op=22 if mode=='result'or(mode=='mixed'and j%2==0)else 23
   barrier.wait(5);out=p.call(op,*f,value=vals[j],kind=1,status=None)
   if h.u(out,8)==0:outcomes.append(('won',j,op))
   else:
    assert h.u(out,8)==1 and h.take_error(v,out)['class']=='InvalidStateError';outcomes.append(('lost',j,op))
  thread_group([lambda j=j:contender(j)for j in range(8)])
  winners=[x for x in outcomes if x[0]=='won'];assert len(winners)==1 and len(callbacks)==1,(outcomes,callbacks);_,j,op=winners[0]
  got,_=p.result(f,exception=(op==23));assert v.type(got)[3:]==v.type(vals[j])[3:];p.drop(f);wins+=1
 p.finish();v.finish();done('eight-actual-concurrent-strict-setters-'+mode,rounds=repetitions,one_winner=wins)

# Running/cancel is a real interleaving; check both observable legal histories.
v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();env=v.scalar(1);histories={}
for i in range(96):
 f=p.make(fac);barrier=threading.Barrier(2);answers={}
 def running():
  barrier.wait();out=p.call(24,*f,status=None);answers['running']=(h.u(out,8),h.u(out,96))
  if h.u(out,8):assert h.take_error(v,out)=={'class':'RuntimeError','message':'Future in unexpected state'}
 def cancel():
  barrier.wait();out=p.call(7,*f);answers['cancel']=h.u(out,96)
 thread_group([running,cancel])
 state=p.call(9,*f);assert h.u(state,120)==1
 if answers['cancel']:
  assert h.u(state,96)==1 and not h.u(p.call(25,*f),96);assert answers['running']in((0,0),(1,0)),answers
 else:
  assert h.u(state,96)==0 and h.u(p.call(25,*f),96)==1 and answers['running']==(0,1),answers
  p.call(22,*f,value=env,kind=1)
 key=str(answers);histories[key]=histories.get(key,0)+1;p.drop(f)
p.finish();v.finish();done('96-actual-running-cancel-races-token-first',histories=histories)
report={'passed':True,'rows':rows,'count':len(rows),'public_calls':h.calls,'image_sha256':h.pin,'whole_public_future_closed':False,'callback_fixture_scope':'Explicit typed callable ABI: actual native owner and kernel, fixture callbacks observe/reenter actual public operations.'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('INHERITED_CONCURRENCY_PASS',len(rows),h.calls,flush=True)

