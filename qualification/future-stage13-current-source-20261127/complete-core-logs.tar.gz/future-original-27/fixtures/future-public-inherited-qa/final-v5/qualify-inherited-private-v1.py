from pathlib import Path
import importlib.util,json,ctypes as C,struct
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');Q=T/'future-public-inherited-qa/final-v5';D=Q/'inherited-private-v1';D.mkdir()
sp=importlib.util.spec_from_file_location('h',Q/'client-v3.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);rows=[];counts={}
FN=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
kernel=FN(h.u(p.ctx.raw,64));cell=FN(h.u(p.ctx.raw,80))
for name,fn,magic,oldmagics,ops,sn,on,wn in[
 ('kernel',kernel,b'HIAMVFQ2',[(b'HIAMVFQ1',list(range(11,17)))],range(11,17),64,512,512),
 ('cell',cell,b'HIABFQ03',[(b'HIABFQ01',list(range(14,20))),(b'HIABFQ02',[0,13,15,16,17,18,19])],range(15,20),128,16384,256),
 ('public',h.entry,b'HIABFP02',[(b'HIABFP01',list(range(22,26)))],range(22,26),192,65536,256)]:
 w=p.ctx if name=='public'else C.create_string_buffer(wn);out=C.create_string_buffer(b'\xa7'*on,on);n=0
 def refuse(raw):
  nonlocal_dummy=0
  s=C.create_string_buffer(raw);before=w.raw;C.memset(out,0xa7,on)
  rc=fn(s,len(raw),out,on,w,wn);head=64 if name=='kernel'else 128
  assert rc==0xfffffffd and out.raw[:head]==b'\xa7'*head and w.raw==before,(name,rc,raw.hex(),out.raw[:128].hex())
 for op in ops:
  raw=bytearray(sn);raw[:8]=magic;struct.pack_into('<Q',raw,8,op)
  used=set()
  if name=='kernel'and op in(11,12):used={16,24};struct.pack_into('<Q',raw,16,1)
  elif name=='cell':
   used={24,32,40}
   if op in(15,16):used|={48,56,64,80};struct.pack_into('<Q',raw,80,1)
  elif name=='public':
   used=set(range(16,64,8))
   if op in(22,23):used|={64,72,80,96};struct.pack_into('<Q',raw,96,1)
  for at in range(16,sn,8):
   if at in used:continue
   bad=bytearray(raw);struct.pack_into('<Q',bad,at,1);refuse(bytes(bad));n+=1
  for size in(sn-1,sn+1):refuse(bytes(raw)[:size]if size<sn else bytes(raw)+b'x');n+=1
 for old,invalidops in oldmagics:
  for op in invalidops:
   raw=bytearray(sn);raw[:8]=old;struct.pack_into('<Q',raw,8,op);refuse(bytes(raw));n+=1
 for op in list(range(min(ops)))+[max(ops)+1,2**64-1]:
  raw=bytearray(sn);raw[:8]=magic;struct.pack_into('<Q',raw,8,op);refuse(bytes(raw));n+=1
 if name in('cell','public'):
  for op in(15,16)if name=='cell'else(22,23):
   for kind in(0,4,2**64-1):
    raw=bytearray(sn);raw[:8]=magic;struct.pack_into('<Q',raw,8,op);struct.pack_into('<Q',raw,80 if name=='cell'else 96,kind);refuse(bytes(raw));n+=1
 counts[name]=n;rows.append({'case':name+'-exact-version-and-reserved-domain','controls':n,'passed':True})
print('NEW_PROFILE_CONTROLS',counts,flush=True)
a=v.scalar(123)
for op in(22,23,24,25):
 for fid,cap in[(f[0],(1,2,3)),((1,2,3),f[1]),(f[0],(f[1][0],f[1][1]^1,f[1][2]))]:
  kw={'value':a,'kind':1}if op in(22,23)else{}
  out=p.call(op,fid=fid,cap=cap,**kw,status=3);assert h.u(p.call(9,*f),96)==0 and v.raw(a)==b'123'
rows.append({'case':'new-profile-actual-capability-refusal-before-mutation','controls':12,'passed':True})
raw=bytearray(192);raw[:8]=b'HIABFP02';struct.pack_into('<Q',raw,8,25);struct.pack_into('<6Q',raw,16,*(f[0]+f[1]))
# Actual input/output unaligned views retain old acceptance and canaries.
for sa in(1,3,7):
 for oa in(1,5,11):
  ss=C.create_string_buffer(b'A'*sa+bytes(raw)+b'Z');oo=C.create_string_buffer(b'B'*oa+b'\xa7'*65536+b'Y')
  assert h.entry(C.addressof(ss)+sa,192,C.addressof(oo)+oa,65536,p.ctx,256)==0
  assert oo.raw[:oa]==b'B'*oa and oo.raw[oa+65536:oa+65537]==b'Y'and ss.raw[:sa]==b'A'*sa and ss.raw[sa+192:sa+193]==b'Z'
  assert h.u(oo.raw,oa+96)==0
rows.append({'case':'nine-new-query-unaligned-actual-views','controls':9,'passed':True})
p.finish();v.finish()
report={'passed':True,'rows':rows,'controls':sum(counts.values())+21,'public_calls':h.calls,'image_sha256':h.pin,'whole_public_future_closed':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('INHERITED_PRIVATE_PASS',report['controls'],flush=True)

