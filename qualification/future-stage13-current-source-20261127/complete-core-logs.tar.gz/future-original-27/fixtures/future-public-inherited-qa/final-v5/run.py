from pathlib import Path
import subprocess,sys,json,time
R=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures/future-public-inherited-qa/final-v5');rows=[]
for name in ['value-fault-strict-result.py', 'value-fault-strict-exception.py', 'value-fault-invalid-state.py', 'value-fault-unexpected-running.py', 'value-fault-nonexception-result.py', 'regression-smoke-v5.py', 'regression-concurrency-v3.py', 'regression-private-v3.py', 'regression-cleanup-v2.py', 'regression-kernel-v2.py', 'regression-value-kernel-v2.py', 'regression-pack-v1.py', 'qualify-smoke-v2.py', 'qualify-original-matrix-v3.py', 'qualify-waiters-v1.py', 'qualify-inherited-concurrency-v1.py', 'qualify-inherited-private-v1.py', 'qualify-owner-original-v4.py', 'qualify-owner-controls-v4.py', 'qualify-iterable-native-callback-v2.py', 'qualify-iterable-lifecycle-v1.py', 'qualify-iterable-controls-v1.py', 'setter-kernel-22-pending.py', 'setter-kernel-22-running.py', 'setter-kernel-23-pending.py', 'setter-kernel-23-running.py', 'qualify-notify-v1.py']:
 start=time.monotonic_ns()
 with (R/(name+'.log')).open('wb') as out:r=subprocess.run([sys.executable,str(R/name)],stdout=out,stderr=subprocess.STDOUT,timeout=400)
 row={'name':name,'returncode':r.returncode,'elapsed_ns':time.monotonic_ns()-start};rows.append(row);print(row,flush=True)
 (R/'status.json').write_text(json.dumps({'passed':False,'rows':rows},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
(R/'status.json').write_text(json.dumps({'passed':True,'rows':rows},indent=2)+'\n')
