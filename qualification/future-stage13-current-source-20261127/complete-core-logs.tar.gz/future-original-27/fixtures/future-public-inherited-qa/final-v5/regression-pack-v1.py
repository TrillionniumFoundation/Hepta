from pathlib import Path
from hashlib import sha256
import ctypes as C,struct,json,sys,subprocess,importlib.util
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');P=T/'future-public-inherited-source';D=T/'future-public-inherited-qa/final-v5/regression-pack-v1';D.mkdir(exist_ok=False);sys.path.insert(0,str(P))
from tools.generate_hia_background_optimizer_future_public_cleanup_packer import BRIDGE,FIXUPS,ROLES,reference_object,reference_flat
sp=importlib.util.spec_from_file_location('publicclient',T/'future-public-inherited-qa/final-v5/regression-client-v1.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
meta=json.loads((T/'future-public-inherited-qa/public-native-v5/build.json').read_text());flats=[]
for role in meta['roles']:
 raw=Path(role['path']).read_bytes();assert sha256(raw).hexdigest()==role['sha256'];flats.append(raw)
assert tuple(r['role']for r in meta['roles'])==ROLES and BRIDGE==(T/'future-public-inherited-qa/bridges-v1/hia_background_optimizer_future_public.bin').read_bytes()
pb=json.loads((T/'future-public-inherited-qa/public-native-v5/packer-build.json').read_text());pack=h.m.load(T/'future-public-inherited-qa/public-native-v5/public-packer.flat',pb['flat_sha256']);rows=[]
def packet(mode):return b'HIABFPP3'+struct.pack('<11Q',9,*[len(x)for x in flats],mode)+b''.join(flats)
def call(raw,n,wn=512):
 s=C.create_string_buffer(raw,len(raw))if raw else C.create_string_buffer(1);o=C.create_string_buffer(b'\xa5'*(n+32),n+32);w=C.create_string_buffer(max(wn,1));rc=pack(s,len(raw),C.addressof(o)+16,n,w,wn);assert o.raw[:16]+o.raw[-16:]==b'\xa5'*32;return rc,o.raw[16:-16]
for mode,label,expected in[(0,'object',reference_object(flats)),(1,'flat',reference_flat(flats))]:
 raw=packet(mode)
 for _ in range(2):
  rc,out=call(raw,len(expected));assert rc==len(expected)and out==expected,(label,rc,len(expected))
 assert expected==(T/('future-public-inherited-qa/public-native-v5/future-public.'+('o'if mode==0 else'flat'))).read_bytes()
 rows.append({'case':'actual-native-'+label+'-twice-byte-identical','passed':True})
 for n in(0,1,len(expected)-1):
  rc,out=call(raw,n);assert rc==0xfffffffe and out==b'\xa5'*n;rows.append({'case':label+'-short-'+str(n),'passed':True})
 for wn in(0,511):
  rc,out=call(raw,128,wn);assert rc==0xfffffffe and out==b'\xa5'*128;rows.append({'case':label+'-work-'+str(wn),'passed':True})
raw=packet(1);bads=[('empty',b''),('header',raw[:95]),('tail',raw[:-1]),('trailing',raw+b'x')]
for at,n in[(0,0),(0,int.from_bytes(b'HIABFPP1','little')),(8,8),(8,10),(88,2)]+[(at,n)for at in range(16,88,8)for n in(0,4194305,2**64-1)]:
 bad=bytearray(raw);struct.pack_into('<Q',bad,at,n);bads.append((str(at)+'-'+str(n),bytes(bad)))
for name,bad in bads:
 rc,out=call(bad,128);assert rc==0xffffffff and out==b'\xa5'*128,(name,rc);rows.append({'case':'invalid-packer-'+name,'passed':True})
image=(T/'future-public-inherited-qa/public-native-v5/future-public.flat').read_bytes()
for role,hole in FIXUPS:
 at=hole+4+struct.unpack_from('<i',image,hole)[0];index=ROLES.index(role);assert image[at:at+len(flats[index])]==flats[index]
 rows.append({'case':'actual-fixed-role-'+role,'passed':True})
elf=subprocess.check_output(['readelf','-Ws',str(T/'future-public-inherited-qa/public-native-v5/future-public.o')],text=True)
assert 'hia_background_optimizer_future_public'in elf and ' UND 'not in '\n'.join(elf.splitlines()[4:]);(D/'symbols.txt').write_text(elf)
report={'passed':True,'count':len(rows),'cases':rows,'image_sha256':h.pin,'packer_sha256':pb['flat_sha256'],'fixed_product_roles':list(ROLES),'product_undefined_symbols':0,'host_semantic_dispatch':False,'explicit_user_typed_callback_surface':True,'whole_public_future_closed':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PUBLIC_PACK_PASS',len(rows),flush=True)
