from pathlib import Path
from hashlib import sha256
import ctypes as C,struct,json,sys,importlib.util,threading,time,resource,os
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');D=T/'future-public-inherited-qa/final-v5/regression-smoke-v5';D.mkdir(exist_ok=False);resource.setrlimit(resource.RLIMIT_CORE,(0,0))
sp=importlib.util.spec_from_file_location('values',T/'qualify-result-value-core-smoke-v1.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
bp=T/'future-public-inherited-qa/public-native-v5';meta=json.loads((bp/'build.json').read_text());pin=next(x['sha256']for x in meta['products']if x['format']=='flat');entry=m.load(bp/'future-public.flat',pin)
ve=m.load(T/'result-value-native-v4/result-value.flat','e2e3fc40edba9ff0c32784502eb7a0cd619a7ab0667cb0ec68c196646a536616')
calls=0;rows=[]
def u(b,at):return struct.unpack_from('<Q',b,at)[0]
class Public:
 def __init__(self,v):
  self.v=v;self.ctx=C.create_string_buffer(256);self.fs=[];self.leases=[]
  self.call(0,fid=(C.addressof(v.ctx),256,0))
 def call(self,op,fid=(0,0,0),cap=(0,0,0),value=(0,0,0),fn=0,kind=0,timeout=(0,0,0),status=0):
  global calls
  raw=bytearray(192);raw[:8]=b'HIABFP01';struct.pack_into('<Q',raw,8,op)
  for at,x in [(16,fid),(40,cap),(64,value),(104,timeout)]:struct.pack_into('<3Q',raw,at,*x)
  struct.pack_into('<2Q',raw,88,fn,kind);s=C.create_string_buffer(bytes(raw));o=C.create_string_buffer(b'\xb5'*65536,65536)
  rc=entry(s,192,o,65536,self.ctx,256);calls+=1
  assert rc==0 and o.raw[:8]==b'HIABFRP1',(op,rc,o.raw[:128].hex())
  assert u(o.raw,8)==status,(op,status,o.raw[:128].hex())
  return o.raw
 def factory(self):
  r=self.call(1);x=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));assert u(r,16)==3 and x[1][0];self.leases.append(x);return x
 def make(self,fac):
  r=self.call(4,*fac);x=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));assert u(r,16)==2 and x[1][0];self.fs.append(x);return x
 def retain(self,f):
  r=self.call(5,*f);x=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));assert u(r,16)==2;self.fs.append(x);return x
 def drop(self,f):self.call(6,*f);self.fs.remove(f)
 def drop_factory(self,f):self.call(3,*f);self.leases.remove(f)
 def complete(self,f,v,kind=1,status=0):return self.call(12,*f,value=v,kind=kind,status=status)
 def result(self,f,status=0,exception=False,timeout=(0,0,0)):
  r=self.call(11 if exception else 10,*f,timeout=timeout,status=status)
  cap=struct.unpack_from('<3Q',r,72)
  if cap[0]:self.v.held.append(cap)
  return cap,r
 def finish(self):
  for f in self.fs[:]:self.drop(f)
  for f in self.leases[:]:self.drop_factory(f)
  self.call(18)
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});print('PUBLIC_CASE',name,calls,flush=True);(D/'report.json').write_text(json.dumps({'passed':False,'calls':calls,'cases':rows},indent=2)+'\n')
def record(v,cl,msg):
 d=v.empty(dict);v.call(10,d,v.scalar('class'),v.scalar(cl));v.call(10,d,v.scalar('message'),v.scalar(msg));return d

v=m.Values(entry=ve);p=Public(v);fac=p.factory();f=p.make(fac);g=p.retain(f)
assert f[0]==g[0]and f[1]!=g[1]
identity=p.call(21,*f);assert u(identity,16)==7 and u(identity,96)==u(p.call(21,*g),96)
for op in(14,15,16):assert u(p.call(op,*f),96)==0
p.call(18,status=1);v.call(20,status=6)
zero=v.scalar(0);no,r=p.result(f,status=1,timeout=zero);assert u(r,16)==101
obj=v.empty(dict);key=v.scalar('answer');answer=v.scalar(42);v.call(10,obj,key,answer)
p.complete(f,obj);assert u(p.call(14,*f),96)==1 and u(p.call(9,*f),96)==2
r1,r=p.result(f);r2,r=p.result(g);assert v.type(r1)[3:]==v.type(r2)[3:]==v.type(obj)[3:]
p.drop_factory(fac);p.drop(f);p.drop(g);p.call(18)
assert v.raw(v.take(v.call(9,r1,key)))==b'42'
v.finish();done('actual-factory-independent-future-and-shared-result')

v=m.Values(entry=ve);p=Public(v);fac=p.factory();f=p.make(fac);r=p.call(7,*f);assert u(r,96)==1
assert u(p.call(15,*f),96)==1 and u(p.call(14,*f),96)==1
for exception in(False,True):
 _,r=p.result(f,status=1,exception=exception);assert u(r,16)==100
p.complete(f,(1,2,3));assert u(p.call(7,*f),96)==1
p.finish();v.finish();done('typed-cancellation-and-complete-ignores-invalid-value')

for kind,cl in[(2,'ValueError'),(3,'KeyboardInterrupt')]:
 v=m.Values(entry=ve);p=Public(v);fac=p.factory();f=p.make(fac);error=record(v,cl,'retained actual exception')
 p.complete(f,error,kind)
 got,r=p.result(f,status=kind-1);assert u(r,16)==200 and v.type(got)[3:]==v.type(error)[3:]
 same,r=p.result(f,exception=True);assert u(r,16)==4 and v.type(same)[3:]==v.type(error)[3:]
 p.finish();assert v.type(got)[3:]==v.type(error)[3:];v.finish()
done('result-raises-and-exception-returns-the-same-owned-value')

v=m.Values(entry=ve);p=Public(v);fac=p.factory();f=p.make(fac);env=v.scalar('closure');saved=[];events=[];errors=[]
CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
@CB
def callback(s,sn,o,on,w,wn):
 try:
  raw=C.string_at(s,sn);assert raw[:8]==b'HIAFCBQ1'and sn==192 and on==8192 and w==C.addressof(p.ctx)
  actual=(struct.unpack_from('<3Q',raw,16),struct.unpack_from('<3Q',raw,40))
  assert u(p.call(21,*actual),96)==u(p.call(21,*f),96)
  got,r=p.result(actual);assert v.raw(got)==b'callback result'
  saved.append(p.retain(actual));p.drop(f);events.append('callback')
  out=bytearray(128);out[:8]=b'HIAFCBR1';C.memmove(o,bytes(out),128);return 0
 except BaseException as e:errors.append(repr(e));return 99
p.call(13,*f,value=env,fn=C.cast(callback,C.c_void_p).value);p.drop_factory(fac)
p.complete(f,v.scalar('callback result'));assert events==['callback']and not errors,(events,errors)
got,r=p.result(saved[0]);assert v.raw(got)==b'callback result';p.drop(saved[0]);p.call(18);v.finish();done('typed-callback-same-future-reentry-and-last-external-drop')

for abrupt in(False,True):
 v=m.Values(entry=ve);p=Public(v);fac=p.factory();f=p.make(fac);env=v.scalar(None);error=record(v,'KeyboardInterrupt'if abrupt else'ValueError','actual callback detail');events=[];errors=[]
 @CB
 def failer(s,sn,o,on,w,wn):
  try:
   events.append('raise');owned=v.retain(error);v.held.remove(owned)
   out=bytearray(128);out[:8]=b'HIAFCBR1';struct.pack_into('<Q',out,8,2 if abrupt else 1);struct.pack_into('<3Q',out,24,*owned);C.memmove(o,bytes(out),128);return 0
  except BaseException as e:errors.append(repr(e));return 99
 @CB
 def after(s,sn,o,on,w,wn):
  events.append('after');out=bytearray(128);out[:8]=b'HIAFCBR1';C.memmove(o,bytes(out),128);return 0
 p.call(13,*f,value=env,fn=C.cast(failer,C.c_void_p).value);p.call(13,*f,value=env,fn=C.cast(after,C.c_void_p).value)
 log=D/('abrupt-'+str(abrupt)+'.stderr');fd=os.open(log,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);old=os.dup(2);os.dup2(fd,2);os.close(fd)
 try:r=p.complete(f,v.scalar(89),status=2 if abrupt else 0)
 finally:os.dup2(old,2);os.close(old)
 assert not errors,errors
 if abrupt:
  assert events==['raise']and u(r,16)==200,(events,r[:128].hex())
  cap=struct.unpack_from('<3Q',r,72);v.held.append(cap);assert v.type(cap)[3:]==v.type(error)[3:]
 else:
  assert events==['raise','after']and u(r,104)==2 and u(r,112)==1,(events,r[:128].hex())
  assert log.read_bytes()==b'exception calling callback\nValueError: actual callback detail\n',log.read_bytes()
 got,r=p.result(f);assert v.raw(got)==b'89'
 p.finish();v.finish()
done('actual-Exception-logging-and-BaseException-propagation-order')

record={'passed':True,'whole_public_future_closed':False,'count':len(rows),'calls':calls,'cases':rows,'image_sha256':pin}
(D/'report.json').write_text(json.dumps(record,indent=2)+'\n');print('PUBLIC_NATIVE_SMOKE_PASS',record,flush=True)
