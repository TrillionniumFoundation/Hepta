from pathlib import Path
import ctypes as C,struct,json,importlib.util,resource,os,signal,errno,traceback
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');D=T/'future-public-inherited-qa/final-v5/setter-kernel-22-pending';D.mkdir(exist_ok=False)
sp=importlib.util.spec_from_file_location('publicclient',T/'future-public-inherited-qa/final-v5/regression-client-v1.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
meta=json.loads((T/'future-public-inherited-qa/bridges-v1/bridge.json').read_text());base=C.cast(h.entry,C.c_void_p).value;lo=base+meta['entries']['public_malloc'];mid=base+meta['entries']['public_deallocate'];hi=base+meta['bytes']
lib=C.CDLL(None,use_errno=True);lib.ptrace.argtypes=[C.c_uint,C.c_uint,C.c_void_p,C.c_void_p];lib.ptrace.restype=C.c_long
class Reg(C.Structure):
 _fields_=[(n,C.c_ulonglong)for n in['r15','r14','r13','r12','rbp','rbx','r11','r10','r9','r8','rax','rcx','rdx','rsi','rdi','orig_rax','rip','cs','eflags','rsp','ss','fs_base','gs_base','ds','es','fs','gs']]
def ptrace(req,pid,a=0,b=0):
 C.set_errno(0);r=lib.ptrace(req,pid,C.c_void_p(a),C.cast(b,C.c_void_p)if not isinstance(b,int)else C.c_void_p(b));assert r!=-1 or C.get_errno()==0,(req,pid,C.get_errno());return r
def caps(v):return C.c_uint64.from_address(h.u(v.ctx.raw,16)+88).value
CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
calls=0
@CB
def callback(s,sn,o,on,w,wn):
 global calls
 calls+=1;out=bytearray(128);out[:8]=b'HIAFCBR1';C.memmove(o,bytes(out),128);return 0
cases=[(name,n)for name,count in [('complete',2),('complete-callback',3)]for n in range(1,count+1)]
rows=[];signal.alarm(300)
for case,nth in cases:
 rfd,wfd=os.pipe();pid=os.fork()
 if pid==0:
  try:
   os.close(rfd);v=h.m.Values(entry=h.ve);p=h.Public(v);ptrace(0,0);os.kill(os.getpid(),signal.SIGSTOP)
   fac=None;f=None
   if case!='factory':fac=p.factory()
   if case not in('factory','lease','future'):f=p.make(fac)
   env=v.scalar('actual environment');payload=v.scalar('actual result')
   if case=='immediate':p.complete(f,payload)
   if case=='complete-callback':p.call(13,*f,value=env,fn=C.cast(callback,C.c_void_p).value)
   before=caps(v);beforecalls=calls
   limits=resource.getrlimit(resource.RLIMIT_AS);virtual=int(Path('/proc/self/statm').read_text().split()[0])*os.sysconf('SC_PAGE_SIZE');resource.setrlimit(resource.RLIMIT_AS,(virtual+(64<<20),limits[1]))
   op={'factory':1,'lease':2,'future':4,'retain':5,'result':10,'cancel':7,'complete':22,'callback':13,'immediate':13,'complete-callback':22}[case]
   args=()if case=='factory'else fac if case in('lease','future')else f
   kw={'value':payload,'kind':1}if op in(22,23) else{'value':env,'fn':C.cast(callback,C.c_void_p).value}if op==13 else{}
   os.kill(os.getpid(),signal.SIGSTOP)
   r=p.call(op,*args,**kw,status=1);assert h.u(r,16)==103,(case,nth,r[:128].hex())
   assert calls==beforecalls,(case,nth,calls,beforecalls)
   committed=case=='complete-callback'and nth==3
   assert caps(v)==before+int(committed),(case,nth,before,caps(v))
   os.kill(os.getpid(),signal.SIGSTOP)
   resource.setrlimit(resource.RLIMIT_AS,limits)
   if committed:
    result,rr=p.result(f);assert v.raw(result)==b'actual result'
    r=p.call(13,*f,value=env,fn=C.cast(callback,C.c_void_p).value);assert calls==beforecalls+1
   else:
    if case=='result':
     assert h.u(p.call(9,*f),96)==0;p.complete(f,payload)
    r=p.call(op,*args,**kw)
    if op in(1,2):
     p.leases.append((struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48)))
    elif op in(4,5):p.fs.append((struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48)))
    elif op==10:v.held.append(struct.unpack_from('<3Q',r,72))
    if case=='callback':p.complete(f,payload);assert calls==beforecalls+1
    if case in('immediate','complete-callback'):assert calls==beforecalls+1
   p.call(20);p.finish();v.finish();assert h.u(v.ctx.raw,16)==0
   os.write(wfd,b'OK');os.close(wfd);os._exit(0)
  except BaseException:
   try:os.write(wfd,traceback.format_exc().encode())
   except BaseException:pass
   os._exit(71)
 os.close(wfd);_,st=os.waitpid(pid,0);assert os.WIFSTOPPED(st);ptrace(0x4200,pid,0,0x100001)
 entering=True;stage=0;armed=False;forced=[];live={};baseline=None;scope=None;current=None;allocations=0;native_memory=0
 while True:
  ptrace(24,pid);_,st=os.waitpid(pid,0)
  if os.WIFEXITED(st)or os.WIFSIGNALED(st):break
  sig=os.WSTOPSIG(st)
  if sig==signal.SIGTRAP|128:
   reg=Reg();ptrace(12,pid,0,C.byref(reg))
   if entering:
    current=None
    if lo<=reg.rip<hi and reg.orig_rax in(9,11):
     native_memory+=1;current=(reg.orig_rax,reg.rdi,reg.rsi,False)
     if armed and reg.orig_rax==9:
      allocations+=1
      if allocations==nth:
       reg.rsi=1<<40;ptrace(13,pid,0,C.byref(reg));current=(*current[:3],True)
   elif current:
    num,address,size,fail=current;result=reg.rax
    if fail:
     signed=result-(1<<64);forced.append(signed);assert signed==-errno.ENOMEM,(case,nth,signed)
    elif num==9:
     assert result<2**63 and result not in live,(case,nth,result);live[result]=size
    else:assert result==0 and live.pop(address)==size,(case,nth,address,size,result)
    current=None
   entering=not entering
  elif sig==signal.SIGSTOP:
   stage+=1
   if stage==1:armed=True;baseline=dict(live)
   elif stage==2:
    armed=False;scope=dict(live)
    if not(case=='complete-callback'and nth==3):assert scope==baseline,(case,nth,'rollback mappings',baseline,scope)
   else:raise AssertionError((case,nth,'stage',stage))
  else:raise AssertionError((case,nth,'signal',sig))
 out=b''
 while True:
  z=os.read(rfd,65536)
  if not z:break
  out+=z
 os.close(rfd);assert os.WIFEXITED(st)and os.WEXITSTATUS(st)==0 and out==b'OK',(case,nth,st,out.decode(errors='replace'),forced,stage,live)
 assert forced==[-errno.ENOMEM]and not live and stage==2,(case,nth,forced,live,stage)
 row={'case':case,'allocation':nth,'passed':True,'real_kernel_enomem':1,'native_memory_syscalls':native_memory,'owned_mappings_final':0,'rollback_or_committed_result_preserved':True};rows.append(row);print('PUBLIC_KERNEL',row,flush=True)
 (D/'report.json').write_text(json.dumps({'passed':False,'cases':rows},indent=2)+'\n')
signal.alarm(0)
report={'passed':True,'whole_public_future_closed':False,'count':len(rows),'cases':rows,'image_sha256':h.pin,'instrumentation':'Only actual fixed closed allocator mmap length changed under child RLIMIT_AS; real kernel ENOMEM. No product code/state/provider/return patched. Each failure retried; native owned mmap/munmap balanced.'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PUBLIC_KERNEL_PASS',len(rows),flush=True)
