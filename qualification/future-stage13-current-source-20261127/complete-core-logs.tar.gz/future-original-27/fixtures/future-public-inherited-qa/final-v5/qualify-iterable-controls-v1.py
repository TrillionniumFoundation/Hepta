from pathlib import Path
import ctypes as C,struct,json,hashlib,importlib.util
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures');Q=T/'future-public-inherited-qa/final-v5';D=Q/'iterable-controls-v1';D.mkdir()
sp=importlib.util.spec_from_file_location('it',Q/'iterable-client-v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
u=m.u;rows=[]
def done(name,**kw):rows.append({'case':name,'passed':True,**kw});print('ITERABLE_CONTROL',name,flush=True)
v,p,a,i=m.env();fac=p.factory();f=p.make(fac);h=i.start([f])
for bad in[(1,2,3),(h[0],h[1]^1,h[2]),(h[0]+8,h[1],h[2]),((1<<64)-1,0,0)]:
 r,_=i.call(2,handle=bad,status=1);assert u(r,16)==102 and u(r,112)==0 and u(p.ctx.raw,48)==h[0]
for op in(2,3):
 r,_=a.call(4,handle=h,status=1);assert u(r,16)==102 and u(p.ctx.raw,48)==h[0]
i.close(h)
for op in(2,3):
 r,_=i.call(op,handle=h,status=1);assert u(r,16)==102 and u(r,112)==0
h2=a.start([])
r,_=i.call(3,handle=h2,status=1);assert u(r,16)==102 and u(r,112)==0 and u(p.ctx.raw,48)==h2[0]
a.close(h2);m.finish(v,p,a,i);done('wrong_stale_and_cross_kind_handles_no_consumption')
v,p,a,i=m.env();wire=bytearray(192);wire[:8]=b'HIABFA01';struct.pack_into('<Q',wire,8,5)
s=C.create_string_buffer(bytes(wire));out=C.create_string_buffer(262144);before=p.ctx.raw
views=[(C.addressof(s),192,C.addressof(out),262143,C.addressof(p.ctx),256),(C.addressof(s),192,C.addressof(out),262144,C.addressof(p.ctx),255),(0,192,C.addressof(out),262144,C.addressof(p.ctx),256),((1<<64)-4,192,C.addressof(out),262144,C.addressof(p.ctx),256),(C.addressof(s),192,0,262144,C.addressof(p.ctx),256),(C.addressof(s),192,(1<<64)-10,262144,C.addressof(p.ctx),256),(C.addressof(s),192,C.addressof(out),262144,C.addressof(out)+8,256),(C.addressof(out),192,C.addressof(out),262144,C.addressof(p.ctx),256)]
for args in views:assert m.entry(*args)==0xfffffffd and p.ctx.raw==before
for at,value in[(0,1),(8,6),(16,1),(24,1),(72,1),(80,(1<<64)-1),(88,1),(184,1)]:
 bad=bytearray(wire);struct.pack_into('<Q',bad,at,value);b=C.create_string_buffer(bytes(bad));assert m.entry(b,192,out,262144,p.ctx,256)==0xfffffffd and p.ctx.raw==before
# Accepted nonaligned S/O views retain their surrounding canaries.
ss=C.create_string_buffer(b'\x55'+bytes(wire)+b'\x56');oo=C.create_string_buffer(b'\x71'*3+b'\xa7'*262144+b'\x72'*5,262152)
assert m.entry(C.addressof(ss)+1,192,C.addressof(oo)+3,262144,p.ctx,256)==0
r=oo.raw[3:131];assert r[:8]==b'HIABFAR1'and u(r,8)==0 and u(r,16)==2
assert oo.raw[:3]==b'\x71'*3 and oo.raw[-5:]==b'\x72'*5 and ss.raw[0]==0x55 and ss.raw[-2]==0x56
h=struct.unpack_from('<3Q',r,24);i.handles.append(h);i.close(h);m.finish(v,p,a,i)
done('eight_views_eight_shapes_and_actual_unaligned_canaries')
build=json.loads((T/'future-public-inherited-qa/iterable-native-v1/build.json').read_text());r=next(x for x in build['roles']if x['name'].endswith('_packer'))
pack=m.m.m.m.load(T/'future-public-inherited-qa/iterable-native-v1/iterable-packer.flat',r['flat_sha256'])
body=(T/'future-public-inherited-qa/iterable-native-v1/iterable-policy.flat').read_bytes();array=(T/'future-public-inherited-qa/iterable-native-v1/array.flat').read_bytes();actual=(T/'future-public-inherited-qa/iterable-native-v1/iterable.flat').read_bytes()
packet=b'HIABFAPK'+struct.pack('<3Q',len(body),len(array),0)+body+array
bad=[packet[:7],packet[:32],b'X'+packet[1:],packet[:24]+struct.pack('<Q',1)+packet[32:],packet+b'x']
for at,n in[(8,0),(16,0),(8,4194305),(16,4194305),(8,len(body)+1),(16,len(array)+1)]:
 w=bytearray(packet);struct.pack_into('<Q',w,at,n);bad.append(bytes(w))
for raw in bad:
 s=C.create_string_buffer(raw);o=C.create_string_buffer(b'\xac'*len(actual),len(actual));w=C.create_string_buffer(64)
 assert pack(s,len(raw),o,len(o),w,64)==0xfffffffd and o.raw==b'\xac'*len(actual)
s=C.create_string_buffer(packet)
for n in(0,1,8,891,len(actual)-1):
 o=C.create_string_buffer(b'\x91'*max(n,1),max(n,1));w=C.create_string_buffer(64)
 assert pack(s,len(packet),o,n,w,64)==0xfffffffe and u(w.raw,0)==len(actual)and o.raw==b'\x91'*len(o)
o=C.create_string_buffer(len(actual));w=C.create_string_buffer(64);assert pack(s,len(packet),o,len(o),w,64)==0 and o.raw==actual
done('eleven_packer_refusals_five_atomic_short_and_native_binding')
report={'passed':True,'cases':rows,'adapter_calls':m.calls,'array_calls':m.m.calls,'public_calls':m.m.m.calls,'adapter_sha256':m.meta['flat_sha256'],'whole_public_future_closed':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

