from pathlib import Path
from hashlib import sha256
import ctypes as C,fcntl,json,os,struct,resource,math
T=Path('/home/qian-qi/hia-native-future-closure-20261127-2ac5/future-original-27-v1/fixtures')
IMAGE=T/'result-value-core-image-v1/value-core.flat'
PIN='8368be71f5446465e70ad4084cf893489bf97cd80454ef5817c41cf5e67fb0f8'
lib=C.CDLL(None,use_errno=True);lib.mmap.argtypes=(C.c_void_p,C.c_size_t,C.c_int,C.c_int,C.c_int,C.c_long);lib.mmap.restype=C.c_void_p
def u(x,off):return struct.unpack_from('<Q',x,off)[0]
def load(path=IMAGE,pin=PIN):
 raw=path.read_bytes();assert sha256(raw).hexdigest()==pin
 fd=os.memfd_create('actual-HIA-value',os.MFD_ALLOW_SEALING);os.write(fd,raw);fcntl.fcntl(fd,fcntl.F_ADD_SEALS,15)
 p=lib.mmap(None,len(raw),5,2,fd,0);os.close(fd);assert p not in(None,C.c_void_p(-1).value)
 return C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))(p)
class Values:
 def __init__(self,entry=None):
  self.entry=entry or load();self.ctx=C.create_string_buffer(256);self.calls=0;self.held=[]
  self.call(0,arg0=4300)
 def call(self,op,a=None,b=None,c=None,tail=b'',arg0=0,arg1=0,cap=8192,status=0):
  h=bytearray(128);h[:8]=b'HIABVQ01';struct.pack_into('<Q',h,8,op)
  for at,t in [(24,a),(48,b),(72,c)]:
   if t is not None:struct.pack_into('<3Q',h,at,*t)
  struct.pack_into('<3Q',h,96,len(tail),arg0,arg1);raw=bytes(h)+tail
  s=C.create_string_buffer(raw,len(raw));o=C.create_string_buffer(cap)
  rc=self.entry(s,len(raw),o,cap,self.ctx,256);self.calls+=1
  out=o.raw
  assert rc==0 and out[:8]==b'HIABVR01',(op,rc,out[:128].hex())
  assert u(out,8)==status,(op,u(out,8),status,out[:128].hex())
  return out
 def take(self,out):
  cap=struct.unpack_from('<3Q',out,24);assert cap[0];self.held.append(cap);return cap
 def scalar(self,value):
  if value is None:return self.take(self.call(2,arg0=0))
  if type(value)is bool:return self.take(self.call(2,arg0=1,arg1=int(value)))
  if type(value)is int:return self.take(self.call(2,arg0=2,tail=str(value).encode()))
  if type(value)is float:return self.take(self.call(2,arg0=3,tail=struct.pack('<d',value)))
  if type(value)is str:return self.take(self.call(2,arg0=4,tail=value.encode('utf8','surrogatepass')))
  if type(value)is bytes:return self.take(self.call(2,arg0=7,tail=value))
  raise TypeError(type(value))
 def empty(self,kind):return self.take(self.call(3 if kind is list else 4))
 def retain(self,a):return self.take(self.call(5,a))
 def drop(self,a):
  self.call(6,a);self.held.remove(a)
 def raw(self,a):
  out=self.call(19,a);n=u(out,72);return self.call(19,a,arg1=n,cap=8192+n)[8192:]
 def type(self,a):
  out=self.call(7,a);return (u(out,16),u(out,48),u(out,72),u(out,104),u(out,112))
 def finish(self):
  for a in self.held[:]:self.drop(a)
  self.call(20)
def main():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));d=T/'result-value-core-smoke-v1';d.mkdir(exist_ok=False)
 v=Values();print('INIT',flush=True);rows=[]
 for value in [None,False,True,0,1,-1,10**100,1.0,-0.0,1e300,float('nan'),float('inf'),float('-inf'),'a\ud800\U0001f642',b'\0abc']:
  a=v.scalar(value);t=v.type(a);raw=v.raw(a);print('SCALAR',repr(value),t[:3],raw[:40].hex(),flush=True)
  if type(value)is float:assert raw==struct.pack('<d',value)
  elif value is None:assert raw==b''
  elif type(value)is bool:assert raw==bytes([value])
  elif type(value)is int:assert raw==str(value).encode()
  elif type(value)is str:assert raw==value.encode('utf8','surrogatepass')and t[1]==len(value)
  else:assert raw==value
  b=v.retain(a);assert v.type(a)[3:]==v.type(b)[3:];assert u(v.call(8,a,b),48)==1
  v.drop(a);assert v.raw(b)==raw
  rows.append({'case':'scalar-'+type(value).__name__+'-'+str(len(rows)),'passed':True})
 li=v.empty(list);dic=v.empty(dict);x=v.scalar(42);key=v.scalar('x');one=v.scalar(1);fl=v.scalar(1.0);yes=v.scalar(True)
 v.call(16,li,x);v.call(16,li,dic);v.call(10,dic,key,li);v.call(10,dic,one,x);v.call(10,dic,fl,li);v.call(10,dic,yes,dic)
 assert v.type(dic)[1]==2
 found=v.take(v.call(9,dic,fl));assert u(v.call(8,found,dic),48)==1
 en=v.call(23,dic,arg1=100,cap=8192+64*2);assert u(en,64)==2
 for i in range(2):
  e=en[8192+64*i:8192+64*(i+1)]
  for at in (16,40):
   c=struct.unpack_from('<3Q',e,at);v.held.append(c)
 rows.append({'case':'dict-numeric-key-equality-insertion-and-cycle','passed':True})
 v.call(15,li,v.scalar(-1));v.call(14,li,v.scalar(1000),dic);v.call(13,li,v.scalar(0),li)
 rows.append({'case':'list-negative-clamped-insert-and-self-cycle','passed':True})
 v.call(20,status=6);v.finish()
 assert u(v.ctx.raw,16)==0 and u(v.ctx.raw,40)==0
 rows.append({'case':'all-external-caps-dropped-cycles-collected-destroyed','passed':True})
 report={'qualified_core_smoke':True,'whole_value_closed':False,'import_export_complete':False,'calls':v.calls,'rows':rows,'image_sha256':PIN}
 (d/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('VALUE_CORE_SMOKE_PASS',v.calls,len(rows),flush=True)
if __name__=='__main__':main()
