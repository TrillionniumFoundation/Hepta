from pathlib import Path
import subprocess,json,hashlib,os
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
source=Path('/Users/qianqi/work/hia-native-carrier-policy-20261128-2ac5/source')
out=root.parent/'carrier-default-native-integration-v1'
out.mkdir(exist_ok=False)
env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def run(where,args,**kw): return subprocess.run(['git',*args],cwd=where,env=env,capture_output=True,check=True,**kw)
initial=run(root,['rev-parse','HEAD']).stdout.decode().strip()
head='a1eb051a87b2e34e0eb574ac9a214d2b2159f451'
base='918454d54f021495fce3743e8c841960dd986c10'
assert initial=='8ca860d2bf754700949ea4ded234d9469ae87478'
assert not run(root,['status','--porcelain=v1']).stdout.strip()
assert run(source,['show','-s','--format=%P',head]).stdout.decode().strip()==base
assert subprocess.run(['git','merge-base','--is-ancestor',base,initial],cwd=root,env=env).returncode==0
paths=run(source,['diff','--name-only',base,head]).stdout.decode().splitlines()
assert 8 <= len(paths) <= 100,paths
current=set(run(root,['diff','--name-only',base,initial]).stdout.decode().splitlines())
assert not current.intersection(paths),current.intersection(paths)
rows=[]
for p in paths:
 raw=run(source,['show',head+':'+p]).stdout
 index=run(source,['ls-tree',head,'--',p]).stdout.decode().strip()
 rows.append(dict(path=p,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),index=index))
review=dict(initial=initial,incoming=head,base=base,incoming_paths=rows,overlapping_paths=[],root_clean=True)
(out/'complete-incoming-review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
print(json.dumps(review,sort_keys=True),flush=True)

registration=run(source,['show',head+':docs/evidence/hia-carrier-default-install-20261128/source-registration.json']).stdout
(out/'source-registration.json').write_bytes(registration)
p=run(source,['diff','--no-ext-diff','--no-color',base,head,'--','hepta','tools','tests','examples/hia_bootstrap'])
(out/'complete-source.diff').write_bytes(p.stdout)
print(json.dumps({'registration':json.loads(registration),'source_diff_bytes':len(p.stdout)},sort_keys=True),flush=True)
