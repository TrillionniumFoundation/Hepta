from pathlib import Path
from hashlib import sha1,sha256
import json,os,subprocess,signal,time,sys
root=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5');source=root/'source'
out=root/'complete-core-evaluation-and-builder-source-controls-v8';out.mkdir(mode=0o700,exist_ok=False)
temporary=out/'tmp';temporary.mkdir(mode=0o700);os.environ['TMPDIR']=str(temporary)
old='2cabcf42f2c5a87c51941a97517513d94072be16';head='6d3c081fb16f9da65899134130786725c6201602';tree='0cd9a7bbc540b1153044ef58c3cdcd2bb45cfab0'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==old
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
gitdir=Path(subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=source,text=True).strip())
shallow=gitdir/'shallow';prior=shallow.read_bytes()if shallow.exists()else b''
(out/'prior-shallow.txt').write_bytes(prior)
boundaries=set(prior.decode().splitlines());boundaries.add(old)
shallow.write_text(''.join(s+'\n'for s in sorted(boundaries)))
argv=['git','-c','core.alternateRefsCommand=/bin/true','fetch','--depth=1','--negotiation-tip='+old,'https://github.com/TrillionniumFoundation/Hepta.git',head]
env=dict(os.environ);env['GIT_TERMINAL_PROMPT']='0'
with(out/'fetch.log').open('xb')as f:
 proc=subprocess.run(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
fetch_rc=proc.returncode
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source,text=True).strip()==tree
rows=subprocess.check_output(['git','ls-tree','-rz',head],cwd=source).split(b'\0')
objects={}
for row in rows:
 if not row:continue
 meta,path=row.split(b'\t',1);mode,kind,oid=meta.split()
 assert kind==b'blob',(mode,kind,path)
 objects[oid.decode()]=True
q=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=''.join(k+'\n'for k in objects).encode(),cwd=source,check=True,capture_output=True)
sizes=0
for line in q.stdout.decode().splitlines():
 parts=line.split();assert len(parts)==3 and parts[1]=='blob',line
 sizes+=int(parts[2])
assert len(q.stdout.decode().splitlines())==len(objects)
subprocess.run(['git','checkout','--detach',head],cwd=source,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
physical=[];total=0
for row in rows:
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();p=source/os.fsdecode(name)
 raw=os.fsencode(os.readlink(p))if mode==b'120000'else p.read_bytes()
 assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid.decode(),os.fsdecode(name)
 if mode!=b'120000':assert bool(p.stat().st_mode&0o111)==(mode==b'100755'),os.fsdecode(name)
 total+=len(raw);physical.append({'path':os.fsdecode(name),'mode':mode.decode(),'blob':oid.decode(),'bytes':len(raw)})
(out/'physical-git-materialization.json').write_text(json.dumps({'schema':'hepta.hia.exact-source-materialization.v1','head':head,'tree':tree,'fetch_exit_code':fetch_rc,'prior_head':old,'owned_shallow_boundary_recorded':True,'full_ancestry_claimed':False,'files':physical,'physical_bytes':total},sort_keys=True,indent=2)+'\n')
print(json.dumps({'materialization':'PASS','head':head,'tree':tree,'files':len(physical),'physical_bytes':total,'fetch_exit_code':fetch_rc,'TMPDIR':str(temporary)}),flush=True)
os.chdir(source);sys.path.insert(0,str(source))
from tools.hia_selfhost_contract import file_digests
before=file_digests(source);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
mods=['tests.test_hia_cold_caller_selection_history','tests.test_hia_store_source_history','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_caller_terminal_admission.CallerTerminalAdmissionSourceTests','tests.test_hia_caller_terminal_readback.CallerTerminalReadbackSourceTests','tests.test_hia_release_contract','tests.test_hia_store_file_capture_native_readback','tests.test_hia_history_fixture_custody','tests.test_hia_integrated_caller_history','tests.test_hia_integrated_caller_source_admission','tests.test_hia_current_caller_source_history','tests.test_hia_native_result_caller_history','tests.test_hia_artifact_caller_source_history','tests.test_hia_cost_artifact_caller_admission','tests.test_hia_caller_diagnostics_admission','tests.test_hia_current_terminal_admission_history','tests.test_hia_service_bootstrap_caller_admission','tests.test_hia_scoped_caller_source_history','tests.test_hia_evaluation_window_history','tests.test_hia_installed_evaluation_source_history','tests.test_hia_evaluation_caller_capture_history','tests.test_hia_evaluation_caller_admission','tests.test_hia_current_store_source_history']
mods += ["tests.test_hia_cold_compiler","tests.test_hia_native_cold_ci","tests.test_hia_component_input_custody","tests.test_hia_native_cold_custody_readers","tests.test_hia_cold_native_transport.ColdNativeTransportSourceTests","tests.test_hia_cold_native_transport.ColdNativeTransportLibraryPathTests","tests.test_hia_cold_native_transport_controls.ColdNativeTransportControlsSourceTests","tests.test_hia_component_cold_readback"]
mods += ['tests.test_hia_current_component_authoring_history']
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
argv=[python,'-B','tools/run_hia_unittest_gate.py',*mods]
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')};env['PYTHONDONTWRITEBYTECODE']='1'
log=out/'tests.log';start=time.monotonic()
with log.open('xb')as f:
 proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
 try:code=proc.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
after=file_digests(source);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
terminal={'schema':'hepta.hia.core-evaluation-and-builder-source-controls.v8','source_head':head,'source_tree':tree,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'source_count':len(before),'source_unchanged':before==after,'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source)),'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'caller_execution_claimed':False,'whole_native_delivery_qualified':False}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n');print(json.dumps(terminal),flush=True);print(log.read_text()[-12000:],flush=True)
raise SystemExit(code if before==after and terminal['source_clean']else 2)
