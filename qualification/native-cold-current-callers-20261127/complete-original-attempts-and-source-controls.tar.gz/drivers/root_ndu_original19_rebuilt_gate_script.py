from pathlib import Path
from hashlib import sha256
import json,os,subprocess,time
root=Path('/home/qian-qi/hia-ndu-original-comparison-20261127-2ac5')
source=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5/source')
out=root/'original19-complete-current-v1';out.mkdir(mode=0o700,exist_ok=False)
tmp=out/'tmp';tmp.mkdir(mode=0o700)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert head=='063f08ea3c36fce9c063e634ba050485063e7ba3'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
receipt=json.loads((root/'build/build-receipt.json').read_bytes())
env={k:v for k,v in os.environ.items()if not k.startswith(('HEPTA_HIA_','HEPTA_NDU_'))}
env.update(TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1',HEPTA_NDU_BRIDGE=receipt['binary'],HEPTA_NDU_BUILD=str(root/'build'),HEPTA_NDU_UPSTREAM='/home/qian-qi/hia-ndu-prerequisite-20261120-r1/upstream')
before={str(p):sha256(p.read_bytes()).hexdigest()for p in (source/'tools/build_hia_ndu_bridge.py',source/'tests/test_hia_ndu_bridge.py',root/'build/build-receipt.json',Path(receipt['binary']))}
assert before[receipt['binary']]==receipt['binary_sha256']=='d83b4d07fb2eb69890e48332c402986d3139a5c84852d834dc6c65b8ad8d2935'
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
argv=[python,'-B','tools/run_hia_unittest_gate.py','tests.test_hia_ndu_bridge'];log=out/'tests.log';started=time.monotonic()
with log.open('xb')as f:proc=subprocess.run(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
unchanged=all(sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in before.items())
record={'schema':'hepta.hia.original-ndu-comparison-prerequisite.v1','head':head,'argv':argv,'exit_code':proc.returncode,'wall_seconds':time.monotonic()-started,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'source_and_binary_unchanged':unchanged,'original_runtime_budgets_changed':False,'whole_hia_native_claimed':False,'production_activation':False,'prerequisites':{k:env[k]for k in ('HEPTA_NDU_BRIDGE','HEPTA_NDU_BUILD','HEPTA_NDU_UPSTREAM')}}
(out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record),flush=True);print(log.read_text(),flush=True)
raise SystemExit(proc.returncode if unchanged else 2)
