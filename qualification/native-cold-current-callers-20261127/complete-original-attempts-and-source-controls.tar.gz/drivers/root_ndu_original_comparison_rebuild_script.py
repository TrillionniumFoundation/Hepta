from pathlib import Path
from hashlib import sha256
import json,os,subprocess,shutil,time,signal
source=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5/source')
root=Path('/home/qian-qi/hia-ndu-original-comparison-20261127-2ac5');root.mkdir(mode=0o700,exist_ok=False)
tmp=root/'tmp';tmp.mkdir(mode=0o700);os.environ['TMPDIR']=str(tmp)
stage=root/'source';(stage/'tools').mkdir(parents=True);(stage/'rust').mkdir()
paths=['tools/build_hia_ndu_bridge.py']+[str(p.relative_to(source))for p in (source/'rust/hia-ndu-bridge').rglob('*')if p.is_file()]
pins={}
for name in paths:
 p=source/name;raw=p.read_bytes();pins[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
 target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 assert target.read_bytes()==p.read_bytes()
assert pins['tools/build_hia_ndu_bridge.py']['sha256']=='c4702a063f45b8a75973dc2978c38f414d43121dde7968af165c51b43241e6e8'
(root/'exact-source-inputs.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'sources':pins},sort_keys=True,indent=2)+'\n')
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
cargo=shutil.which('cargo');assert cargo,'cargo unavailable'
env=dict(os.environ);env['CARGO_TARGET_DIR']=str(root/'target');env['CARGO_BUILD_JOBS']='2';env['CARGO_NET_OFFLINE']='true';env['PYTHONDONTWRITEBYTECODE']='1'
argv=[python,'-B',str(stage/'tools/build_hia_ndu_bridge.py'),'--upstream','/home/qian-qi/hia-ndu-prerequisite-20261120-r1/upstream','--output',str(root/'build'),'--cargo',cargo]
print(json.dumps({'status':'BUILD_STARTED','argv':argv,'source_files':len(pins),'original_locked_builder':True,'production_activation':False}),flush=True)
log=root/'build.log';started=time.monotonic()
with log.open('xb')as f:
 p=subprocess.Popen(argv,env=env,cwd=stage,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 timed_out=False
 try:code=p.wait(timeout=1800)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=3)
record={'schema':'hepta.hia.retained-ndu-comparison-rebuild.v1','argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-started,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'production_activation':False,'whole_hia_native_claimed':False}
(root/'build-terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record),flush=True);print(log.read_text()[-12000:],flush=True)
if (root/'build/command-evidence/cargo.stderr').exists():
 raw=(root/'build/command-evidence/cargo.stderr').read_bytes();print(raw.decode(errors='replace')[-10000:],flush=True)
raise SystemExit(code)
