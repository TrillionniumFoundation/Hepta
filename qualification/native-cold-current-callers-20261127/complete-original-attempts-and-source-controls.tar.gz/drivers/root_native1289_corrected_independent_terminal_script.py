from pathlib import Path
from hashlib import sha256
import json,subprocess,stat
base=Path('/home/qian-qi/hia-integrated-caller-history-v2-20261127-2ac5/complete-native1289-merged-original-callers-v3')
source=base.parent/'source'
saved={}
def read(path):
 path=Path(path)
 st=path.lstat()
 assert stat.S_ISREG(st.st_mode)and not path.is_symlink(),str(path)
 raw=path.read_bytes()
 if path in saved:assert saved[path]==raw,str(path)
 saved[path]=raw
 return raw
def doc(path):return json.loads(read(path))
def pin(raw):return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
original=doc(base/'caller-terminal.json')
assert original['source_head']=='1213225f6a554f236dd7d6ed76607e799fd068e5'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==original['source_head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
before=doc(base/'source-before.json');after=doc(base/'source-after.json')
assert before==after
for name,expected in before.items():
 assert sha256(read(source/name)).hexdigest()==expected,name
keys=('errors','failures','skipped','expected_failures','unexpected_successes')
records=[]
for original_row in original['records']:
 name=original_row['name']
 is_reader=name=='store_file_capture-independent-readback'
 path=base/'store_file_capture/caller-readback.json'if is_reader else base/name/'report.json'
 report=doc(path)
 log=base/(name+'.log')
 raw=read(log)
 assert pin(raw)=={'bytes':original_row['log_bytes'],'sha256':original_row['log_sha256']}
 groups=report.get('groups')
 if groups is None:groups=[report]
 assert type(groups)is list
 anomalies={key:sum(len(group.get(key,[]))for group in groups)for key in keys}
 expected_status='PASS_READBACK_ONLY'if is_reader else'PASS'
 row={'name':name,'kind':'independent_readback'if is_reader else'original_producer',
      'report_path':str(path),'report_pin':pin(saved[path]),'producer_log_pin':pin(raw),
      'status':report['status'],'expected_success_status':expected_status,
      'actual_tests':report['actual_tests'],'exit_code':original_row['exit_code'],
      'timed_out':original_row['timed_out'],'original_wall_seconds':original_row['wall_seconds'],
      'anomaly_counts_from_actual_groups':anomalies,
      'complete_success':report['status']==expected_status and original_row['exit_code']==0
       and original_row['timed_out']is False and not any(anomalies.values())}
 if all(key in report for key in('planned','started','stopped')):
  row['original_sequences_identical']=report['planned']==report['started']==report['stopped']
  row['planned_count']=len(report['planned'])
  assert row['original_sequences_identical']and row['planned_count']==row['actual_tests'],name
 if name=='artifact_delivery':
  row['groups']=[{'name':g['name'],'planned':len(g['planned']),
       'actual_tests':g['actual_tests'],'was_successful':g['was_successful'],
       'anomaly_counts':{key:len(g[key])for key in keys}}for g in groups]
  assert row['actual_tests']==134 and anomalies=={'errors':1,'failures':5,'skipped':19,'expected_failures':0,'unexpected_successes':0}
  assert row['complete_success']is False and original_row['anomaly_counts']==dict.fromkeys(keys,0)
 if is_reader:
  assert report['status']=='PASS_READBACK_ONLY'and row['actual_tests']==112
  row['original_physical_capture_count']=len(report['consumed_files'])
  for captured,identity in report['consumed_files'].items():
   assert pin(read(Path(captured)))==identity,captured
 if name not in('artifact_delivery',):
  assert row['complete_success'],name
 records.append(row)
assert len(records)==6
for path,raw in saved.items():assert path.read_bytes()==raw,str(path)
result={'schema':'hepta.hia.original-caller-batch-independent-terminal-readback.v1',
 'scope':'INDEPENDENT_CURRENT_REREAD_OF_RETAINED_ORIGINAL_ATTEMPT_ONLY',
 'source_head':original['source_head'],'original_native_cold_source_head':original['native_cold_source_head'],
 'original_aggregate':{'path':str(base/'caller-terminal.json'),**pin(saved[base/'caller-terminal.json'])},
 'original_aggregate_not_modified':True,'original_aggregate_status':original['status'],
 'status':'FAIL','whole_native_delivery_qualified':False,
 'corrections':{'reader_success_status_is_PASS_READBACK_ONLY':True,
    'artifact_anomalies_are_nested_in_original_groups':True,
    'prior_outer_zero_anomaly_summary_was_incorrect':True},
 'original_results':records,'physical_source_count':len(before),
 'reread_count':len(saved),'every_selected_physical_input_reread_identical':True,
 'source_unchanged':True,'new_product_execution_claimed':False,
 'captured_files':{str(path):pin(raw)for path,raw in sorted(saved.items())}}
target=base/'independent-terminal-readback-v1.json'
with target.open('xb')as stream:stream.write((json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps({'path':str(target),'pin':pin(target.read_bytes()),'status':result['status'],
 'gates':[{'name':r['name'],'status':r['status'],'anomalies':r['anomaly_counts_from_actual_groups']}for r in records],
 'reread_count':len(saved),'whole_native_delivery_qualified':False}),flush=True)
