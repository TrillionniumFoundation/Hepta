from pathlib import Path
from hashlib import sha1,sha256
import json,os,subprocess,signal,time,sys
root=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5');source=root/'source'
out=root/'complete-eight-scopes-source-controls-flat-objects-v2';out.mkdir(mode=0o700,exist_ok=False)
temporary=out/'tmp';temporary.mkdir(mode=0o700);os.environ['TMPDIR']=str(temporary)
old=None;head='f9c3967718d6d3108566ca085372799042bfbf82';tree='9c697bf13527bb14d39225385aeec71f5d4845aa'
gitdir=source/'.git'
assert (gitdir/'HEAD').read_text().startswith('ref: refs/heads/')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
alternates=gitdir/'objects/info/alternates'
prior_alternates=alternates.read_text()
(out/'prior-alternates.txt').write_text(prior_alternates)
seen=set();edges=[]
def visit(path,depth=0):
 path=Path(os.path.realpath(path))
 if path in seen:return
 assert depth<32 and path.is_dir(),str(path)
 seen.add(path)
 linked=path/'info/alternates'
 if linked.exists():
  for line in linked.read_text().splitlines():
   if not line:continue
   child=Path(line)if Path(line).is_absolute()else path/line
   edges.append({'source':str(path),'target':str(child)})
   visit(child,depth+1)
for line in prior_alternates.splitlines():
 if line:visit(Path(line)if Path(line).is_absolute()else gitdir/'objects'/line)
assert gitdir/'objects'not in seen
alternates.write_text(''.join(str(path)+'\n'for path in sorted(seen)))
(out/'flattened-read-only-object-stores.json').write_text(json.dumps({'scope':'OWNED_GIT_ALTERNATE_PATH_FLATTENING_ONLY','borrowed_object_stores_modified':False,'fetch_repeated':False,'stores':[str(p)for p in sorted(seen)],'edges':edges},sort_keys=True,indent=2)+'\n')
fetch_rc=None
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source,text=True).strip()==tree
rows=subprocess.check_output(['git','ls-tree','-rz',head],cwd=source).split(b'\0')
objects={}
for row in rows:
 if not row:continue
 meta,path=row.split(b'\t',1);mode,kind,oid=meta.split()
 assert kind==b'blob',(mode,kind,path)
 objects[oid.decode()]=True
q=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=''.join(k+'\n'for k in objects).encode(),cwd=source,check=True,capture_output=True)
sizes=0
for line in q.stdout.decode().splitlines():
 parts=line.split();assert len(parts)==3 and parts[1]=='blob',line
 sizes+=int(parts[2])
assert len(q.stdout.decode().splitlines())==len(objects)
subprocess.run(['git','checkout','--detach',head],cwd=source,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
physical=[];total=0
for row in rows:
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();p=source/os.fsdecode(name)
 raw=os.fsencode(os.readlink(p))if mode==b'120000'else p.read_bytes()
 assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid.decode(),os.fsdecode(name)
 if mode!=b'120000':assert bool(p.stat().st_mode&0o111)==(mode==b'100755'),os.fsdecode(name)
 total+=len(raw);physical.append({'path':os.fsdecode(name),'mode':mode.decode(),'blob':oid.decode(),'bytes':len(raw)})
(out/'physical-git-materialization.json').write_text(json.dumps({'schema':'hepta.hia.exact-source-materialization.v1','head':head,'tree':tree,'fetch_exit_code':fetch_rc,'prior_head':old,'owned_shallow_boundary_recorded':True,'full_ancestry_claimed':False,'files':physical,'physical_bytes':total},sort_keys=True,indent=2)+'\n')
print(json.dumps({'materialization':'PASS','head':head,'tree':tree,'files':len(physical),'physical_bytes':total,'fetch_exit_code':fetch_rc,'TMPDIR':str(temporary)}),flush=True)
os.chdir(source);sys.path.insert(0,str(source))
from tools.hia_selfhost_contract import file_digests
before=file_digests(source);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
mods=['tests.test_hia_cold_caller_selection_history','tests.test_hia_store_source_history','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_caller_terminal_admission.CallerTerminalAdmissionSourceTests','tests.test_hia_caller_terminal_readback.CallerTerminalReadbackSourceTests','tests.test_hia_release_contract','tests.test_hia_store_file_capture_native_readback','tests.test_hia_history_fixture_custody','tests.test_hia_integrated_caller_history','tests.test_hia_integrated_caller_source_admission','tests.test_hia_current_caller_source_history','tests.test_hia_native_result_caller_history','tests.test_hia_artifact_caller_source_history','tests.test_hia_cost_artifact_caller_admission','tests.test_hia_caller_diagnostics_admission','tests.test_hia_current_terminal_admission_history','tests.test_hia_service_bootstrap_caller_admission','tests.test_hia_scoped_caller_source_history']
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
argv=[python,'-B','tools/run_hia_unittest_gate.py',*mods]
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')};env['PYTHONDONTWRITEBYTECODE']='1'
log=out/'tests.log';start=time.monotonic()
with log.open('xb')as f:
 proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
 try:code=proc.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
after=file_digests(source);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
terminal={'schema':'hepta.hia.complete-eight-scopes-source-controls.v1','source_head':head,'source_tree':tree,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'source_count':len(before),'source_unchanged':before==after,'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source)),'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'caller_execution_claimed':False,'whole_native_delivery_qualified':False}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n');print(json.dumps(terminal),flush=True);print(log.read_text(),flush=True)
if code or before!=after or not terminal['source_clean']:raise SystemExit(code or 2)
cold=Path('/home/qian-qi/hia-native-final-2b154-20261127-2ac5/qualified-cold-handoff-v1/qualified-cold.json')
assert sha256(cold.read_bytes()).hexdigest()=='becd051e3a5771d0059d6f5b1880c56e4234d5167b19969fb2ed98fb343e2b95'
from tools.hia_cold_compiler import compiler_from_cold_report
compiler=compiler_from_cold_report(cold)
compiler_raw=compiler.read_bytes()
records=[];env['PATH']=str(Path(python).parent)+os.pathsep+env.get('PATH','')
for domain in ('discovery','verification','bootstrap'):
 name='service_'+domain+'-ordinary'
 argv=[python,'-B','tools/qualify_hia_service_'+domain+'_callers.py','--scope','ordinary','--cold-report',str(cold),'--evidence',str(out/name)]
 log=out/(name+'.log');start=time.monotonic()
 with log.open('xb')as f:
  proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
  try:code=proc.wait(timeout=1800)
  except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
 row={'name':name,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source))}
 report_path=out/name/'report.json'
 if report_path.exists():
  report=json.loads(report_path.read_bytes());row.update(reported_status=report.get('status'),actual_tests=report.get('tests_run',report.get('actual_tests')),anomaly_counts={k:len(report.get(k,[]))for k in ('errors','failures','skipped')})
 records.append(row);(out/'caller-results.json').write_text(json.dumps(records,sort_keys=True,indent=2)+'\n');print(json.dumps(row),flush=True)
 if timed_out or not row['source_clean']:break
after=file_digests(source);assert before==after and compiler.read_bytes()==compiler_raw
passed=len(records)==3 and all(r['exit_code']==0 and r.get('reported_status')=='PASS'and r.get('actual_tests')==112 for r in records)
terminal={'schema':'hepta.hia.complete-current-native-scoped-callers.v1','source_head':head,'source_tree':tree,'status':'PASS'if passed else'FAIL','source_count':len(before),'source_unchanged':True,'gates':records,'whole_native_delivery_qualified':False}
(out/'caller-terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':terminal['status'],'gates':len(records)}),flush=True)
raise SystemExit(0 if passed else 1)
