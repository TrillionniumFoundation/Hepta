from pathlib import Path
from hashlib import sha1,sha256
import json,os,subprocess,signal,time,sys
root=Path('/home/qian-qi/hia-integrated-caller-history-v2-20261127-2ac5');source=root/'source'
out=root/'complete-native1289-merged-original-callers-v3';out.mkdir(mode=0o700,exist_ok=False)
temporary=out/'tmp';temporary.mkdir(mode=0o700);os.environ['TMPDIR']=str(temporary)
old='19a6e62d34179c4cf89f72d6050fbaebb4e9201e';head='1213225f6a554f236dd7d6ed76607e799fd068e5';tree='0d703e863619b5c42774500e35d2ac87634572bb'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==old
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
gitdir=Path(subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=source,text=True).strip())
other=Path('/home/qian-qi/hia-native-final-2b154-20261127-2ac5/source/.git/objects')
assert other.is_dir()
alternates=gitdir/'objects/info/alternates'
prior_alternates=alternates.read_text()if alternates.exists()else ''
(out/'prior-alternates.txt').write_text(prior_alternates)
alternates.parent.mkdir(parents=True,exist_ok=True)
borrowed=set(prior_alternates.splitlines());borrowed.add(str(other))
alternates.write_text(''.join(name+'\n'for name in sorted(borrowed)))
shallow=gitdir/'shallow';prior=shallow.read_bytes()if shallow.exists()else b''
(out/'prior-shallow.txt').write_bytes(prior)
boundaries=set(prior.decode().splitlines());boundaries.update((old,'de14e0e8a049bb69e856596cb2bd7a50dfbe2c72'))
shallow.write_text(''.join(s+'\n'for s in sorted(boundaries)))
argv=['git','-c','core.alternateRefsCommand=/bin/true','fetch','--depth=1','--negotiation-tip='+old,'--negotiation-tip=de14e0e8a049bb69e856596cb2bd7a50dfbe2c72','https://github.com/TrillionniumFoundation/Hepta.git',head]
env=dict(os.environ);env['GIT_TERMINAL_PROMPT']='0'
with(out/'fetch.log').open('xb')as f:
 proc=subprocess.run(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
fetch_rc=proc.returncode
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source,text=True).strip()==tree
rows=subprocess.check_output(['git','ls-tree','-rz',head],cwd=source).split(b'\0')
objects={}
for row in rows:
 if not row:continue
 meta,path=row.split(b'\t',1);mode,kind,oid=meta.split()
 assert kind==b'blob',(mode,kind,path)
 objects[oid.decode()]=True
q=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=''.join(k+'\n'for k in objects).encode(),cwd=source,check=True,capture_output=True)
sizes=0
for line in q.stdout.decode().splitlines():
 parts=line.split();assert len(parts)==3 and parts[1]=='blob',line
 sizes+=int(parts[2])
assert len(q.stdout.decode().splitlines())==len(objects)
subprocess.run(['git','checkout','--detach',head],cwd=source,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
physical=[];total=0
for row in rows:
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();p=source/os.fsdecode(name)
 raw=os.fsencode(os.readlink(p))if mode==b'120000'else p.read_bytes()
 assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid.decode(),os.fsdecode(name)
 if mode!=b'120000':assert bool(p.stat().st_mode&0o111)==(mode==b'100755'),os.fsdecode(name)
 total+=len(raw);physical.append({'path':os.fsdecode(name),'mode':mode.decode(),'blob':oid.decode(),'bytes':len(raw)})
(out/'physical-git-materialization.json').write_text(json.dumps({'schema':'hepta.hia.exact-source-materialization.v1','head':head,'tree':tree,'fetch_exit_code':fetch_rc,'prior_head':old,'owned_shallow_boundary_recorded':True,'full_ancestry_claimed':False,'files':physical,'physical_bytes':total},sort_keys=True,indent=2)+'\n')
print(json.dumps({'materialization':'PASS','head':head,'tree':tree,'files':len(physical),'physical_bytes':total,'fetch_exit_code':fetch_rc,'TMPDIR':str(temporary)}),flush=True)
os.chdir(source);sys.path.insert(0,str(source))
from tools.hia_selfhost_contract import file_digests
before=file_digests(source);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
mods=['tests.test_hia_cold_caller_selection_history','tests.test_hia_store_source_history','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_caller_terminal_admission.CallerTerminalAdmissionSourceTests','tests.test_hia_caller_terminal_readback.CallerTerminalReadbackSourceTests','tests.test_hia_release_contract','tests.test_hia_store_file_capture_native_readback','tests.test_hia_history_fixture_custody','tests.test_hia_integrated_caller_history','tests.test_hia_integrated_caller_source_admission','tests.test_hia_current_caller_source_history','tests.test_hia_native_result_caller_history','tests.test_hia_artifact_caller_source_history','tests.test_hia_cost_artifact_caller_admission','tests.test_hia_caller_diagnostics_admission','tests.test_hia_current_terminal_admission_history']
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
argv=[python,'-B','tools/run_hia_unittest_gate.py',*mods]
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')};env['PYTHONDONTWRITEBYTECODE']='1'
log=out/'tests.log';start=time.monotonic()
with log.open('xb')as f:
 proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
 try:code=proc.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
after=file_digests(source);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
terminal={'schema':'hepta.hia.native1289-complete-original-source-controls.v3','source_head':head,'source_tree':tree,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'source_count':len(before),'source_unchanged':before==after,'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source)),'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'caller_execution_claimed':False,'whole_native_delivery_qualified':False}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n');print(json.dumps(terminal),flush=True);print(log.read_text(),flush=True)
if code or before!=after or not terminal['source_clean']:raise SystemExit(code or 2)
cold=Path('/home/qian-qi/hia-native-final-2b154-20261127-2ac5/qualified-cold-handoff-v1/qualified-cold.json')
assert sha256(cold.read_bytes()).hexdigest()=='becd051e3a5771d0059d6f5b1880c56e4234d5167b19969fb2ed98fb343e2b95'
from tools.hia_cold_compiler import compiler_from_cold_report
compiler=compiler_from_cold_report(cold)
compiler_raw=compiler.read_bytes()
assert len(compiler_raw)==641344 and sha256(compiler_raw).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
assert sha256((source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json').read_bytes()).hexdigest()=='d4ce301cdd38c8e33178302cc27a21679081acd3dc4cbd7670b9a4eeaa41f560'
assert sha256((source/'docs/HIA_SELFHOST_CORE_SUPPORT.json').read_bytes()).hexdigest()=='3650ab462ac5d752e86486ecd6e8f1b87e731409140e594073711c5c22761177'
print(json.dumps({'native_1289_admission':'PASS','cold':str(cold),'compiler':str(compiler),'source_head':head,'native_authority_and_host_custody_separate':True}),flush=True)
records=[]
specs=['emission','store_file_capture','store_transaction','artifact_delivery','store_artifact_profile']
env['PATH']=str(Path(python).parent)+os.pathsep+env.get('PATH','')
def run_gate(label,command,report_path,budget=1800):
 log=out/(label+'.log');started=time.monotonic()
 with log.open('xb')as f:
  proc=subprocess.Popen(command,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
  try:code=proc.wait(timeout=budget)
  except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
 row={'name':label,'argv':command,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-started,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source))}
 if report_path.exists():
  report=json.loads(report_path.read_bytes());detail=report.get('complete_callers')or report
  row.update(reported_status=report.get('status'),reported_scope=report.get('scope'),actual_tests=detail.get('actual_tests',detail.get('tests_run')),anomaly_counts={k:len(detail.get(k,[]))for k in ('errors','failures','skipped','expected_failures','unexpected_successes')})
 records.append(row);(out/'caller-results.json').write_text(json.dumps(records,sort_keys=True,indent=2)+'\n');print(json.dumps(row),flush=True)
 return row
for name in specs:
 row=run_gate(name,[python,'-B','tools/qualify_hia_'+name+'_callers.py','--cold-report',str(cold),'--evidence',str(out/name)],out/name/'report.json')
 if row['timed_out']or not row['source_clean']:break
 if name=='store_file_capture'and row['exit_code']==0 and row.get('reported_status')=='PASS':
  script="import importlib.abc,sys,runpy;sys.path.insert(0,sys.argv.pop(1));"+chr(10)+"class Guard(importlib.abc.MetaPathFinder):"+chr(10)+" def find_spec(self,fullname,path=None,target=None):"+chr(10)+"  if fullname=='hepta' or fullname=='tests' or fullname.startswith(('hepta.','tests.','tools.build_','tools.generate_')) or 'oracle' in fullname:raise AssertionError(fullname)"+chr(10)+"sys.meta_path.insert(0,Guard());runpy.run_module('tools.read_hia_store_file_capture_callers',run_name='__main__')"
  run_gate('store_file_capture-independent-readback',[python,'-I','-B','-c',script,str(source),'--repository',str(source),'--evidence',str(out/name),'--cold-report',str(cold),'--producer-log',str(out/(name+'.log'))],out/name/'caller-readback.json',300)
after=file_digests(source)
assert before==after and compiler.read_bytes()==compiler_raw
passed=len(records)==6 and all(r['exit_code']==0 and r.get('reported_status')=='PASS'and not r['timed_out']and r['source_clean']for r in records)
record={'schema':'hepta.hia.native1289-matching-complete-callers.v1','status':'PASS'if passed else'FAIL','source_head':head,'source_tree':tree,'native_cold_source_head':'de14e0e8a049bb69e856596cb2bd7a50dfbe2c72','source_unchanged':before==after,'source_count':len(before),'records':records,'whole_native_delivery_qualified':False}
(out/'caller-terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':record['status'],'gates':len(records)}),flush=True)
raise SystemExit(0 if passed else 1)
