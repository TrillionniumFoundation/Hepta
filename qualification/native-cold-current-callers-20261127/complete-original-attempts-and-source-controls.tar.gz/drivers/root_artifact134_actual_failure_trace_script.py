from pathlib import Path
import json
base=Path('/home/qian-qi/hia-integrated-caller-history-v2-20261127-2ac5/complete-native1289-merged-original-callers-v3')
v=json.loads((base/'artifact_delivery/report.json').read_bytes())
for g in v['groups']:
 print('GROUP '+g['name'])
 for kind in ('errors','failures'):
  for name,trace in g[kind]:
   print(kind+' '+name);print(trace[:10000])
 reasons={}
 for name,reason in g['skipped']:reasons[reason]=reasons.get(reason,0)+1
 print('skip_reasons '+json.dumps(reasons))
for name in ('emission','store_file_capture','store_transaction','store_artifact_profile'):
 v=json.loads((base/name/'report.json').read_bytes())
 a=[]
 def walk(x,path):
  if isinstance(x,dict):
   for k,y in x.items():
    if k in ('errors','failures','skipped','expected_failures','unexpected_successes')and isinstance(y,list)and y:a.append({'path':path+'/'+k,'count':len(y)})
    elif k in ('groups','complete_callers','result','results','original_tests','test_results'):walk(y,path+'/'+k)
  elif isinstance(x,list):
   for i,y in enumerate(x):walk(y,path+'/'+str(i))
 walk(v,'')
 print('OTHER_GATE '+json.dumps({'name':name,'status':v['status'],'anomalies':a}))
