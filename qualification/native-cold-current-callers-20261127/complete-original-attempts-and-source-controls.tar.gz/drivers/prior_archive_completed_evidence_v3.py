from pathlib import Path
from hashlib import sha256
import gzip,io,json,os,stat,subprocess,sys,tarfile,time
os.nice(15)
source=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5/source')
head='ea492288374bd012696aa13ec965f3e5103432b6'
branch='codex/hia-native-caller-selection-20261127-2ac5'
out=source.parent/'closed-complete-caller-source-evidence-v3'
out.mkdir(mode=0o700,exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
drivers=out/'drivers';drivers.mkdir(mode=0o700)
for name,body in json.loads(sys.argv[1]).items():
 assert '/'not in name and name.endswith('.py')
 (drivers/name).write_text(body)
(drivers/'archive_completed_evidence.py').write_text(sys.argv[2])
roots=[
 ('generation-combined','/home/qian-qi/hia-native-caller-selection-20261127-2ac5',
  ['matching-cold-original-combined-generation-companions']),
 ('original19-failures','/home/qian-qi/hia-native-caller-history-d5-20261127-2ac5',
  ['matching-cold-nineteen-original-caller-gates']),
 ('artifact-and-domain','/home/qian-qi/hia-native-domain-callers-d38-20261127-2ac5',
  ['storage-quota-diagnosis-v1','artifact-publication-native-cold-original-controls-complete-source',
   'artifact-original36-ext4-temporary-storage','artifact-publication-complete-original-diagnostic-observation-v1',
   'artifact-publication-native-cold-original-controls','complete-original-validation',
   'live-source-worktrees-v1.json','remaining-original-failure-diagnosis-v1']),
 ('integrated-current','/home/qian-qi/hia-integrated-caller-history-v2-20261127-2ac5',
  ['complete-original-and-integrated-source-controls-materialized-baseline',
   'complete-current-six-result-and-original-source-controls-v1',
   'complete-native1289-merged-original-callers-v3',
   'complete-original-and-integrated-source-controls-explicit-parent',
   'complete-original-and-integrated-source-controls',
   'complete-current-six-result-and-terminal-source-controls-v2']),
 ('scoped-and-current','/home/qian-qi/hia-scoped-caller-source-20261127-2ac5',
  ['complete-current-store-consumer-source-controls-v6',
   'complete-artifact-route-cold-source-controls-v4',
   'complete-evaluation-domains-and-store-source-controls-v5',
   'complete-evaluation-support-and-original-source-controls-v3',
   'complete-eight-scopes-source-controls-flat-objects-v2',
   'complete-eight-scopes-source-controls-v1',
   'ndu-original19-prerequisite-current-v1',
   'complete-core-and-current-store-source-controls-v7',
   'complete-core-evaluation-and-builder-source-controls-v8',
   'complete-current-evaluation-readback-source-controls-v9']),
 ('original-ndu-comparison','/home/qian-qi/hia-ndu-original-comparison-20261127-2ac5',
  ['build','original19-complete-current-v1','build.log','terminal.json',
   'exact-source-inputs.json','target/debug/hia-ndu-bridge'])]
inputs=[]
for label,root,names in roots:
 for name in names:inputs.append((label+'/'+name,Path(root)/name))
inputs.append(('drivers',drivers))
# Assert the correction retains FAIL and the original failed producer.
correction=Path('/home/qian-qi/hia-integrated-caller-history-v2-20261127-2ac5/complete-native1289-merged-original-callers-v3/independent-terminal-readback-v1.json')
corrected=json.loads(correction.read_bytes())
assert corrected['status']=='FAIL'and corrected['original_aggregate_not_modified']is True
assert corrected['reread_count']==3454
control=json.loads((source.parent/'complete-current-evaluation-readback-source-controls-v9/terminal.json').read_bytes())
assert control['source_head']==head and control['exit_code']==0 and control['source_unchanged']is True
rows=[];saved={}
for label,path in inputs:
 assert path.exists(),str(path)
 files=sorted(path.rglob('*'))if path.is_dir()else[path]
 for p in files:
  st=p.lstat()
  if stat.S_ISDIR(st.st_mode):continue
  assert stat.S_ISREG(st.st_mode)and not p.is_symlink(),str(p)
  raw=p.read_bytes();after=p.stat()
  assert (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
  assert len(raw)==st.st_size
  name=label+'/'+p.relative_to(path).as_posix()if path.is_dir()else label
  assert name not in saved and not name.startswith('/')and '..'not in Path(name).parts
  saved[name]=raw
  rows.append({'path':name,'original_path':str(p),'bytes':len(raw),'sha256':sha256(raw).hexdigest()})
print(json.dumps({'phase':'captured','files':len(rows),'bytes':sum(r['bytes']for r in rows)}),flush=True)
archive=out/'complete-original-attempts-and-source-controls.tar.gz'
with archive.open('xb')as stream:
 with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0,compresslevel=6)as compressed:
  with tarfile.open(fileobj=compressed,mode='w')as tar:
   for row in rows:
    raw=saved[row['path']];info=tarfile.TarInfo(row['path'])
    info.size=len(raw);info.mode=0o600;info.mtime=0
    tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.isfile()and member.name==row['path']
  raw=tar.extractfile(member).read()
  assert raw==saved[row['path']]==Path(row['original_path']).read_bytes()
  assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
araw=archive.read_bytes()
manifest={'schema':'hepta.hia.complete-original-attempts-and-source-controls-archive.v3',
 'archive':{'path':archive.name,'bytes':len(araw),'sha256':sha256(araw).hexdigest(),
  'members':len(rows),'uncompressed_member_bytes':sum(r['bytes']for r in rows),
  'every_member_reread_against_unchanged_original':True},
 'parent_commit':head,'current_source_controls':{'head':head,'methods':251,'exit_code':0,
  'log_sha256':'4f6f7fdf25400cca83be5d475e567503cca28047da9f1d9d0b603fdf4e0851f9'},
 'original_mixed_batch_status':'FAIL','original_artifact134_anomalies':{'errors':1,'failures':5,'skipped':19},
 'original_mixed_batch_corrected_readback':{'bytes':correction.stat().st_size,'sha256':sha256(correction.read_bytes()).hexdigest(),
  'actual_inputs_reread':3454,'original_aggregate_preserved':True},
 'prior_already_published_archive_not_duplicated':'qualification/native-cold-original-callers-20261127',
 'source_controls_are_not_product_qualification':True,'whole_native_delivery_qualified':False,
 'original_failures_retained':True,'members':rows}
(out/'archive-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
readme="""# Retained complete caller attempts and source controls

This archive preserves complete terminated attempts, actual logs and reports, source identities, first failures, actual comparison outputs, and the executed drivers. Every archive member was independently read back against its unchanged original before publication. The earlier published caller archive is referenced rather than nested or duplicated here.

The six-record native-1289 batch at 1213225 remains FAIL. Original Emission112, StoreFileCapture112, StoreTransaction112, and StoreArtifactProfile130 passed. The separate fresh-process FileCapture reader returned PASS_READBACK_ONLY for the original112. Artifact134 failed with one error, five failures and nineteen skipped cases, all contained in its original nested groups. The original outer summary incorrectly printed zero anomalies; it is retained unchanged alongside an independent correction that rechecks 3,454 actual physical inputs. The reader-specific success label is distinguished from producer PASS. No failed or skipped producer has been relabelled.

Also retained are the complete generation companion gate, the earlier nineteen-scope failed attempt, all Artifact36 construction and temporary-storage failures followed by the complete passing original36 gate, actual original route11, actual original Discovery112/Verification112/Bootstrap112, and all current source-history integration attempts including their failures. Exact scope, source commit, command, timing and input identity remain in each original terminal report. The NDU19 result is the real locked Rust comparison prerequisite and its original tests; it is not a whole-stack HIA claim.

The final source-control run in this archive is ea492288374bd012696aa13ec965f3e5103432b6: all251 methods passed, with the complete original methods and assertions retained. These source controls include actual temporary Git and physical-byte tamper checks. They do not replace a native cold campaign, installed release, cross-platform product run, or a complete Artifact134 rerun. Newer native release and broad cold-caller integration remain separate work.
"""
(out/'README.md').write_text(readme)
env=dict(os.environ,GIT_INDEX_FILE=str(out/'temporary-evidence.index'),
 GIT_AUTHOR_NAME='Codex',GIT_AUTHOR_EMAIL='codex@openai.com',
 GIT_COMMITTER_NAME='Codex',GIT_COMMITTER_EMAIL='codex@openai.com',GIT_TERMINAL_PROMPT='0')
subprocess.run(['git','read-tree',head],cwd=source,env=env,check=True)
prefix='qualification/native-cold-current-callers-20261127'
entries=[]
for name in(archive.name,'archive-manifest.json','README.md'):
 blob=subprocess.check_output(['git','hash-object','-w',str(out/name)],cwd=source,env=env,text=True).strip()
 entries.append('100644 '+blob+'\t'+prefix+'/'+name+'\n')
subprocess.run(['git','update-index','--index-info'],input=''.join(entries),cwd=source,env=env,text=True,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=source,env=env,text=True).strip()
message='Preserve complete original caller attempts, failures and current source controls\n\nKeep original Artifact134 FAIL and exact nested anomaly counts beside a separate independent corrected readback. Archive actual completed caller gates, original Rust comparison prerequisite, and all source-control attempts through the complete251 PASS. No whole native delivery claim.\n'
commit=subprocess.check_output(['git','commit-tree',tree,'-p',head],input=message,cwd=source,env=env,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
publication={'commit':commit,'tree':tree,'parent':head,'branch':branch,'archive':manifest['archive'],'local_worktree_unchanged':True}
(out/'publication.json').write_text(json.dumps(publication,sort_keys=True,indent=2)+'\n')
print(json.dumps(publication),flush=True)
remote=subprocess.check_output(['git','ls-remote','--exit-code','https://github.com/TrillionniumFoundation/Hepta.git','refs/heads/'+branch],cwd=source,env=env,text=True,timeout=60).split()[0]
assert remote==head,remote
started=time.monotonic()
with(out/'push.log').open('xb')as stream:
 proc=subprocess.run(['git','push','https://github.com/TrillionniumFoundation/Hepta.git',commit+':refs/heads/'+branch],
  cwd=source,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
publication.update(push_exit_code=proc.returncode,push_wall_seconds=time.monotonic()-started,
 push_log_sha256=sha256((out/'push.log').read_bytes()).hexdigest())
(out/'publication-terminal.json').write_text(json.dumps(publication,sort_keys=True,indent=2)+'\n')
print(json.dumps(publication),flush=True)
print((out/'push.log').read_text(),flush=True)
raise SystemExit(proc.returncode)
