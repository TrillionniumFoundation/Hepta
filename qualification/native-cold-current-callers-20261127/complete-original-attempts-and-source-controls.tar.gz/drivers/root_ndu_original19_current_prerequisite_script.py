from pathlib import Path
from hashlib import sha256
import json,subprocess,os,time
base=Path('/home/qian-qi/hia-ndu-prerequisite-20261120-r1')
source=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5/source')
out=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5/ndu-original19-prerequisite-current-v1');out.mkdir(mode=0o700,exist_ok=False)
tmp=out/'tmp';tmp.mkdir(mode=0o700);os.environ['TMPDIR']=str(tmp)
receipt=json.loads((base/'build-current/build-receipt.json').read_bytes())
observations=[]
envs={}
for p in (base/'actual-extra-env.json',base/'actual-extra-env-v2.json'):
 value=json.loads(p.read_bytes())
 picked={k:v for k,v in value.items()if k in ('HEPTA_NDU_BRIDGE','HEPTA_NDU_BUILD','HEPTA_NDU_UPSTREAM')}
 observations.append({'path':str(p),'selected':picked})
 envs.update(picked)
print(json.dumps({'observations':observations,'receipt_binary_exists':Path(receipt['binary']).is_file(),'current_builder_sha256':sha256((source/'tools/build_hia_ndu_bridge.py').read_bytes()).hexdigest(),'recorded_builder_sha256':receipt['builder_sha256']}),flush=True)
for k,p in envs.items():
 print(json.dumps({'key':k,'path':p,'exists':Path(p).exists(),'file':Path(p).is_file(),'directory':Path(p).is_dir()}),flush=True)
(out/'prerequisite-observation.json').write_text(json.dumps({'observations':observations,'receipt_binary':receipt['binary'],'recorded_binary_sha256':receipt['binary_sha256']},sort_keys=True,indent=2)+'\n')
if set(envs)!={'HEPTA_NDU_BRIDGE','HEPTA_NDU_BUILD','HEPTA_NDU_UPSTREAM'}or not all(Path(v).exists()for v in envs.values()):
 print(json.dumps({'status':'MISSING_RETAINED_PREREQUISITE','native_gate_started':False}),flush=True)
 raise SystemExit(3)
assert sha256(Path(envs['HEPTA_NDU_BRIDGE']).read_bytes()).hexdigest()==receipt['binary_sha256']
assert sha256((source/'tools/build_hia_ndu_bridge.py').read_bytes()).hexdigest()==receipt['builder_sha256']
print(json.dumps({'selected_binary_bytes':Path(envs['HEPTA_NDU_BRIDGE']).stat().st_size,'selected_binary_sha256':receipt['binary_sha256']}),flush=True)
python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
env={k:v for k,v in os.environ.items()if not k.startswith('HEPTA_HIA_')};env.update(envs);env['PYTHONDONTWRITEBYTECODE']='1'
argv=[python,'-B','tools/run_hia_unittest_gate.py','tests.test_hia_ndu_bridge'];log=out/'tests.log';started=time.monotonic()
with log.open('xb')as f:proc=subprocess.run(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
record={'schema':'hepta.hia.original-ndu-comparison-prerequisite.v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'argv':argv,'exit_code':proc.returncode,'wall_seconds':time.monotonic()-started,'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'original_runtime_budgets_changed':False,'whole_hia_native_claimed':False}
(out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record),flush=True);print(log.read_text(),flush=True)
raise SystemExit(proc.returncode)
