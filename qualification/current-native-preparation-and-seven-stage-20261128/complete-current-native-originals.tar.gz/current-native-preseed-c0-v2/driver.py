from pathlib import Path
from hashlib import sha256
import subprocess,json,os,time,stat,tarfile,sys,traceback
os.umask(0o022)
root=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5/source')
out=root.parent/'current-native-preseed-c0-v2';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
def pin(raw):return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
def git(*args):return subprocess.run(['/usr/bin/git',*args],cwd=root,env=env,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='c0f25977d12bb6582fdf5839539b5bb9fc92fc21'
names=git('ls-files','-z').decode().split('\0')[:-1]
assert len(names)==9052
def snapshot():
 result={}
 for name in names:
  p=root/name;st=p.lstat();assert stat.S_ISREG(st.st_mode)and st.st_nlink==1,name
  result[name]={**pin(p.read_bytes()),'mode':stat.S_IMODE(st.st_mode)}
 return result
initial=snapshot()
(out/'initial-all-tracked-source-pins.json').write_text(json.dumps(initial,sort_keys=True,indent=2)+'\n')
evidence=root/'qualification/native-source-preparation-3e27-20261128'
archive=evidence/'complete-preseed-and-preparation-originals.tar.gz'
archive_raw=archive.read_bytes();assert pin(archive_raw)=={'bytes':4808378,'sha256':'d407f5c420e15f3a16b3005aa37f21da8d61d5e92d01b120afeb8bc5f34eecea'}
manifest={x['path']:x for x in json.loads((evidence/'complete-originals-manifest.json').read_bytes())}
roots=out/'independent-inputs';roots.mkdir(mode=0o700)
expected_names=('hia-seed-assembly','hia-seed-projector','hia-seed-backend','hia-seed-filter-pack','hia-cold-qualification-driver','hia-independent-subprocess','hia-cold-process-owner')
rows=[]
with tarfile.open(archive,'r:gz')as tar:
 members={m.name:m for m in tar.getmembers()};assert len(members)==259
 reportname='source3e27-preseed-v1/preseed/report.json'
 report_raw=tar.extractfile(members[reportname]).read();assert pin(report_raw)=={k:manifest[reportname][k]for k in('bytes','sha256')}
 (out/'original-bootstrap-provenance-report.json').write_bytes(report_raw)
 historical=json.loads(report_raw)['historical_bootstrap_inputs'];assert [x['name']for x in historical]==list(expected_names)
 for row in historical:
  name='source3e27-preseed-v1/preseed/bootstrap/'+row['name'];m=members[name];assert m.isfile()and m.mode==0o500
  raw=tar.extractfile(m).read();actual=pin(raw)
  assert actual=={k:row[k]for k in('bytes','sha256')}=={k:manifest[name][k]for k in('bytes','sha256')}
  target=roots/row['name']
  with target.open('xb')as stream:stream.write(raw)
  target.chmod(0o500);assert target.stat().st_nlink==1 and target.read_bytes()==raw
  rows.append({'name':row['name'],'path':str(target),**actual,'archive_member':name})
receipt={'schema':'hepta.hia.explicit-independent-bootstrap-custody.v1','bootstrap':rows,'source_archive':{'path':str(archive),**pin(archive_raw)},'historical_qualification_reused':False}
receipt_path=out/'bootstrap-inputs.json';receipt_path.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
tool=root/'tools/hia_native_cold_preseed.py'
assert pin(tool.read_bytes())=={'bytes':12806,'sha256':'82171689cc3bfff164846b78278eee025164634cafeaa0ffccaa30e9909ceeb7'}
argv=['/usr/bin/python3','-B',str(tool),'--source',str(root),'--output',str(out/'preseed'),'--root-receipt',str(receipt_path)]
(out/'invocation.json').write_text(json.dumps({'argv':argv,'base_commit':'c0f25977d12bb6582fdf5839539b5bb9fc92fc21','source_files':len(initial),'generated_source_changes':git('diff','--name-only').decode().splitlines()},sort_keys=True,indent=2)+'\n')
started=time.monotonic();record={'status':'RUNNING','whole_native_stack_qualified':False}
try:
 with(out/'preseed.stdout').open('xb')as so,(out/'preseed.stderr').open('xb')as se:
  p=subprocess.run(argv,cwd=root,env=env,stdout=so,stderr=se)
 record['returncode']=p.returncode
 assert p.returncode==0
 result=json.loads((out/'preseed/report.json').read_bytes());assert result['passed']and result['historical_qualification_reused']is False and result['target_or_successor_compiler_used']is False
 final=snapshot();(out/'final-all-tracked-source-pins.json').write_text(json.dumps(final,sort_keys=True,indent=2)+'\n')
 assert final==initial,'source changed during native preseed'
 record.update(status='CURRENT_NATIVE_PRESEED_COMPLETE',source_files=len(initial),sources_used=len(result['sources']),actual_native_invocations=len(result['invocations']),source_bytes_and_modes_stable=True,current_roots=result['initial_roots'],historical_inputs_count=len(rows),whole_cold_qualified=False)
except BaseException:
 record['status']='CURRENT_NATIVE_PRESEED_FAILED';record['error']=traceback.format_exc();raise
finally:
 record['elapsed_seconds']=time.monotonic()-started
 for name in ('preseed.stdout','preseed.stderr'):
  if(out/name).is_file():record[name]=pin((out/name).read_bytes())
 (out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
 print(json.dumps(record,sort_keys=True),flush=True)
