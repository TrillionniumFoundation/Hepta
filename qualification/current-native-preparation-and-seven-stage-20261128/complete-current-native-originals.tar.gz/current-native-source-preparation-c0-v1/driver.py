from pathlib import Path
from hashlib import sha256
import subprocess,json,os,time,stat,sys,traceback,tarfile
os.umask(0o022)
root=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5/source')
base=root.parent
out=base/'current-native-source-preparation-c0-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1')
def pin(raw):return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
def git(*args):return subprocess.run(['/usr/bin/git',*args],cwd=root,env=env,capture_output=True,check=True).stdout
head=git('rev-parse','HEAD').decode().strip();assert head=='c0f25977d12bb6582fdf5839539b5bb9fc92fc21'
preseed=base/'current-native-preseed-c0-v2/preseed'
assert json.loads((preseed/'report.json').read_bytes())['passed']
names=git('ls-files','-z').decode().split('\0')[:-1];assert len(names)==9052
def snapshot():
 result={}
 for name in names:
  p=root/name;st=p.lstat();assert stat.S_ISREG(st.st_mode)and st.st_nlink==1,name
  result[name]={**pin(p.read_bytes()),'mode':stat.S_IMODE(st.st_mode)}
 return result
initial=snapshot();(out/'initial-all-tracked-source-pins.json').write_text(json.dumps(initial,sort_keys=True,indent=2)+'\n')
preseed_final=json.loads((base/'current-native-preseed-c0-v2/final-all-tracked-source-pins.json').read_bytes());assert initial==preseed_final
tool=root/'tools/hia_native_cold_prepare.py'
assert pin(tool.read_bytes())=={'bytes':12594,'sha256':'43334bccbf5f1160d4d8ddb3e159a7de79914c8bf9ddb16e0ef766273e679a81'}
argv=['/usr/bin/python3','-B',str(tool),'--source',str(root),'--base',head,'--preseed',str(preseed),'--output',str(out/'preparation')]
(out/'invocation.json').write_text(json.dumps({'argv':argv,'base_commit':head,'source_files':len(initial),'initial_git_changes':git('diff','--name-only').decode().splitlines()},sort_keys=True,indent=2)+'\n')
started=time.monotonic();record={'status':'RUNNING','whole_native_stack_qualified':False}
try:
 with(out/'preparation.stdout').open('xb')as so,(out/'preparation.stderr').open('xb')as se:
  p=subprocess.run(argv,cwd=root,env=env,stdout=so,stderr=se)
 record['returncode']=p.returncode
 assert p.returncode==0
 report=json.loads((out/'preparation/report.json').read_bytes())
 assert report['passed']and report['plan_regeneration_twice_exact']and report['whole_cold_qualified']is False
 assert report['source_count']==1424 and report['phase_count']==60 and report['qualification_nodes']==479882
 final=snapshot();(out/'final-all-tracked-source-pins.json').write_text(json.dumps(final,sort_keys=True,indent=2)+'\n')
 actual_changed={name:{'before':initial[name],'after':final[name]}for name in names if initial[name]!=final[name]}
 allowed=set(json.loads((out/'preparation/source-manifest.json').read_bytes()))
 assert set(actual_changed)<=allowed,sorted(set(actual_changed)-allowed)
 all_git_changes=git('diff','--name-only').decode().splitlines()
 extras=git('ls-files','--others','--exclude-standard','-z').decode().split('\0')[:-1]
 assert set(extras)=={'examples/hia_bootstrap/cold_build_plans/build-plan.json','examples/hia_bootstrap/cold_source_bootstrap_plans/build-plan.json'}
 products=out/'prepared-current-sources.tar.gz'
 with tarfile.open(products,'w:gz')as tar:
  for name in sorted(all_git_changes+extras):tar.add(root/name,arcname=name,recursive=False)
 pins={name:{**pin((root/name).read_bytes()),'mode':stat.S_IMODE((root/name).stat().st_mode)}for name in sorted(all_git_changes+extras)}
 (out/'prepared-source-pins.json').write_text(json.dumps(pins,sort_keys=True,indent=2)+'\n')
 record.update(status='CURRENT_NATIVE_SOURCE_PREPARATION_COMPLETE',source_files=len(initial),native_source_count=report['source_count'],qualification_phase_count=report['phase_count'],qualification_nodes=report['qualification_nodes'],actual_changed_sources=actual_changed,changed_development_artifacts=report['changed_development_artifacts'],all_git_changed_sources=all_git_changes,untracked_development_derivatives=extras,source_archive=pin(products.read_bytes()),whole_cold_qualified=False)
except BaseException:
 record['status']='CURRENT_NATIVE_SOURCE_PREPARATION_FAILED';record['error']=traceback.format_exc();raise
finally:
 record['elapsed_seconds']=time.monotonic()-started
 for name in ('preparation.stdout','preparation.stderr'):
  if(out/name).is_file():record[name]=pin((out/name).read_bytes())
 (out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
 summary={k:v for k,v in record.items()if k!='actual_changed_sources'}
 summary['actual_changed_source_count']=len(record.get('actual_changed_sources',{}))
 print(json.dumps(summary,sort_keys=True),flush=True)
