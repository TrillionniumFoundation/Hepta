from pathlib import Path
from hashlib import sha256
import subprocess,json,os,time,stat,sys,traceback
os.umask(0o022)
root=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5/source')
base=root.parent;prep=base/'current-native-source-preparation-c0-v1/preparation'
readback=json.loads((base/'current-native-source-preparation-readback-c0-v4/terminal.json').read_bytes())
assert readback['status']=='ACTUAL_NATIVE_PREPARATION_AND_COMPLETE_SOURCE_READBACK_PASSED'
out=base/'current-native-seven-stage-c0-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
for key in('PYTHONHOME','PYTHONPATH'):env.pop(key,None)
def pin(raw):return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
def git(*args):return subprocess.run(['/usr/bin/git',*args],cwd=root,env=env,capture_output=True,check=True).stdout
head=git('rev-parse','HEAD').decode().strip();assert head=='c0f25977d12bb6582fdf5839539b5bb9fc92fc21'
names=git('ls-files','-z').decode().split('\0')[:-1];assert len(names)==9052
def snapshot():
 rows={}
 for name in names:
  p=root/name;st=p.lstat();assert stat.S_ISREG(st.st_mode)and st.st_nlink==1,name
  rows[name]={**pin(p.read_bytes()),'mode':stat.S_IMODE(st.st_mode)}
 return rows
initial=snapshot()
assert initial==json.loads((base/'current-native-source-preparation-c0-v1/final-all-tracked-source-pins.json').read_bytes())
(out/'initial-all-tracked-source-pins.json').write_text(json.dumps(initial,sort_keys=True,indent=2)+'\n')
free=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize
assert free>3*1024**3,free
tool=root/'tools/hia_native_cold_construct.py'
assert pin(tool.read_bytes())=={'bytes':13307,'sha256':'a989eedf055d4c78997964caed380e4bbad8ff23f95d2a64d2fc151f99246ac8'}
argv=['/usr/bin/python3','-B',str(tool),'--source',str(root),'--head',head,'--preparation',str(prep),'--preseed',str(base/'current-native-preseed-c0-v2/preseed'),'--output',str(out/'construction')]
intent={'argv':argv,'physical_source_base_commit':head,'native_source_count':1424,'native_source_manifest_sha256':readback['all_changed_sources']['docs/HIA_SELFHOST_CORE_SUPPORT.json']['after']['sha256'],'physical_source_changes':git('diff','--name-only').decode().splitlines(),'free_bytes_before':free,'original_native_qualification_cap_seconds':180,'original_native_cleanup_cap_seconds':3,'original_outer_observer_cap_seconds':360}
(out/'intent.json').write_text(json.dumps(intent,sort_keys=True,indent=2)+'\n')
record={'status':'RUNNING','whole_cold_qualified':False,'whole_native_stack_qualified':False}
started=time.monotonic()
try:
 with(out/'construction.stdout').open('xb')as so,(out/'construction.stderr').open('xb')as se:
  p=subprocess.run(argv,cwd=root,env=env,stdout=so,stderr=se)
 record['returncode']=p.returncode
 result_path=out/'construction/qualification.json'
 result=json.loads(result_path.read_bytes())if result_path.is_file()else{}
 record['construction_qualification_passed']=result.get('passed',False)
 assert p.returncode==0 and result['passed']
 final=snapshot();(out/'final-all-tracked-source-pins.json').write_text(json.dumps(final,sort_keys=True,indent=2)+'\n')
 assert initial==final,'complete physical source changed during native construction'
 record.update(status='ACTUAL_CURRENT_SEVEN_STAGE_NATIVE_CONSTRUCTION_PASSED',source_files=len(initial),native_source_count=result['source_count'],installed_native_tools=result['installed_count'],actual_stages=len(result['stages']),actual_construction_nodes=result['total_nodes'],native_build_seconds=result['wall_elapsed_ns']/1e9,native_owned_tree_seconds=result['native_nested_ns']/1e9,native_cleanup_seconds=result['native_cleanup_ns']/1e9,source_bytes_and_modes_stable=True,no_python_or_host_compiler_descendant=result['no_python_or_host_compiler_descendant'],execution_trace=result['execution_trace'])
except BaseException:
 record['status']='ACTUAL_CURRENT_SEVEN_STAGE_NATIVE_CONSTRUCTION_FAILED';record['error']=traceback.format_exc();raise
finally:
 record['elapsed_seconds']=time.monotonic()-started
 for name in ('construction.stdout','construction.stderr'):
  if(out/name).is_file():record[name]=pin((out/name).read_bytes())
 (out/'terminal.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
 print(json.dumps(record,sort_keys=True),flush=True)
