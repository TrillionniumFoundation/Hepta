from pathlib import Path
from hashlib import sha256
import subprocess,json,os,stat,sys,tarfile,time
root=Path('/home/qian-qi/hia-current-linux-authors-20261128-2ac5/source')
base=root.parent;prior=base/'current-native-source-preparation-c0-v1'
out=base/'current-native-source-preparation-readback-c0-v3';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
def pin(raw):return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
def git(*args):return subprocess.run(['/usr/bin/git',*args],cwd=root,capture_output=True,check=True).stdout
head=git('rev-parse','HEAD').decode().strip();assert head=='c0f25977d12bb6582fdf5839539b5bb9fc92fc21'
failed=json.loads((prior/'terminal.json').read_bytes());assert failed['returncode']==0 and failed['status']=='CURRENT_NATIVE_SOURCE_PREPARATION_FAILED'and "cold_report_admit.hepta"in failed['error']
report=json.loads((prior/'preparation/report.json').read_bytes())
assert report['passed']and report['plan_regeneration_twice_exact']and report['source_count']==1424 and report['phase_count']==60 and report['qualification_nodes']==479882
initial=json.loads((prior/'initial-all-tracked-source-pins.json').read_bytes())
previous_final=json.loads((prior/'final-all-tracked-source-pins.json').read_bytes())
current={}
for name in initial:
 p=root/name;st=p.lstat();assert stat.S_ISREG(st.st_mode)and st.st_nlink==1,name
 current[name]={**pin(p.read_bytes()),'mode':stat.S_IMODE(st.st_mode)}
assert current==previous_final,'actual source changed after preparation observer'
actual_changed={name:{'before':initial[name],'after':current[name]}for name in initial if current[name]!=initial[name]}
compat='examples/hia_bootstrap/cold_report_admit.hepta'
native='examples/hia_bootstrap/source_release_cold_admit.hepta'
assert set(actual_changed)==set(report['changed_sources'])|{compat}
assert(root/compat).read_bytes()==(root/native).read_bytes()
sys.path.insert(0,str(root))
from tools.hia_selfhost_contract import SOURCE_FILES
assert compat in SOURCE_FILES,'generated compatibility source omitted from declared full source files'
authority=json.loads((prior/'preparation/source-manifest.json').read_bytes())
for name,digest in authority.items():assert current[name]['sha256']==digest
assert compat not in authority and native in authority
changes=git('diff','--name-only').decode().splitlines()
extras=git('ls-files','--others','--exclude-standard','-z').decode().split('\0')[:-1]
expected_extras={'examples/hia_bootstrap/cold_build_plans/build-plan.json','examples/hia_bootstrap/cold_source_bootstrap_plans/build-plan.json'}
assert set(extras)==expected_extras,(extras,expected_extras)
pins={name:{**pin((root/name).read_bytes()),'mode':stat.S_IMODE((root/name).stat().st_mode)}for name in sorted(changes+extras)}
(out/'prepared-source-pins.json').write_text(json.dumps(pins,sort_keys=True,indent=2)+'\n')
archive=out/'prepared-current-sources.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name in sorted(pins):tar.add(root/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 assert set(tar.getnames())==set(pins)
 for name,row in pins.items():
  m=tar.getmember(name);assert m.isfile()and m.mode==row['mode']and pin(tar.extractfile(m).read())=={k:row[k]for k in('bytes','sha256')}
result={'schema':'hepta.hia.native-source-preparation-independent-readback.v1','status':'ACTUAL_NATIVE_PREPARATION_AND_COMPLETE_SOURCE_READBACK_PASSED','base_commit':head,'original_preparation_passed':True,'original_observer_scope_failure_preserved':True,'source_files':len(current),'native_source_count':1424,'qualification_phase_count':60,'qualification_nodes':479882,'plan_regeneration_twice_exact':True,'actual_changed_native_sources':report['changed_sources'],'additional_generated_compatibility_source':{'path':compat,**current[compat],'listed_in_complete_host_source_files':True,'byte_equal_to_native_release_admit':True},'all_changed_sources':actual_changed,'git_changed_sources':changes,'development_derivatives':extras,'source_archive':pin(archive.read_bytes()),'all_native_source_pins_match_preparation':True,'all_current_source_bytes_and_modes_stable_since_preparation':True,'whole_cold_qualified':False,'whole_native_stack_qualified':False}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='all_changed_sources'},sort_keys=True),flush=True)
