from pathlib import Path
from hashlib import sha1,sha256
import json,os,subprocess,signal,time,sys
source=Path('/home/qian-qi/hia-scoped-caller-source-20261127-2ac5/source')
base=Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-root-consolidation-20261127-2ac5')
out=base/'complete-unified-native-source-controls-v2';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
temporary=out/'tmp';temporary.mkdir(mode=0o700);os.environ['TMPDIR']=str(temporary)
old='48182086e211712cc1e087d47ba894457155190b';head='0ab357a5a9583dbc03b00382a9e69576320e6549';tree='23a5d5849597eb3331cbb6a5fa75b5c07b92fdd9'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==old
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
gitdir=Path(subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=source,text=True).strip())
pack=base/'native-metadata-source-materialization-v1/source-delta.pack'
raw=pack.read_bytes()
expected=json.loads((pack.parent/'source-delta.json').read_bytes())
assert expected['head']==head and expected['tree']==tree and expected['base']==old
assert len(raw)==expected['bytes'] and sha256(raw).hexdigest()==expected['sha256']
with pack.open('rb') as stream:
 result=subprocess.run(['git','index-pack','--stdin'],stdin=stream,cwd=source,check=True,capture_output=True,timeout=60)
(out/'index-pack.stdout').write_bytes(result.stdout);(out/'index-pack.stderr').write_bytes(result.stderr)
shallow=gitdir/'shallow';prior=shallow.read_bytes() if shallow.exists() else b''
(out/'prior-shallow.txt').write_bytes(prior)
boundaries=set(prior.decode().splitlines());boundaries.update((old,head))
shallow.write_text(''.join(s+'\n' for s in sorted(boundaries)))
assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=source,text=True).strip()==tree
commit=subprocess.check_output(['git','cat-file','commit',head],cwd=source)
(out/'source-commit.txt').write_bytes(commit)
parents=[line.split()[1].decode() for line in commit.splitlines() if line.startswith(b'parent ')]
assert parents==['7da3ff0f01d817a1f04813501aa418628e94186a','636081d07c9cef5d22edf1f14c3b80d371a2a22e','e3fbbdcd3f34dfebdeabafe820dcd332f6c1f5d7','b990efc55bb53129f158bde67adbc792fe61f8ab','3674332323e9664c1d5b5bd4699aea11ecf76927']
rows=subprocess.check_output(['git','ls-tree','-rz',head],cwd=source).split(b'\0')
objects={}
for row in rows:
 if not row:continue
 meta,path=row.split(b'\t',1);mode,kind,oid=meta.split()
 assert kind==b'blob',(mode,kind,path)
 objects[oid.decode()]=True
result=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=''.join(k+'\n' for k in objects).encode(),cwd=source,check=True,capture_output=True)
for line in result.stdout.decode().splitlines():
 fields=line.split();assert len(fields)==3 and fields[1]=='blob',line
assert len(result.stdout.decode().splitlines())==len(objects)
subprocess.run(['git','checkout','--detach',head],cwd=source,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
physical=[];total=0
for row in rows:
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();path=source/os.fsdecode(name)
 data=os.fsencode(os.readlink(path)) if mode==b'120000' else path.read_bytes()
 assert sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid.decode(),os.fsdecode(name)
 if mode!=b'120000':assert bool(path.stat().st_mode&0o111)==(mode==b'100755'),os.fsdecode(name)
 total+=len(data);physical.append({'path':os.fsdecode(name),'mode':mode.decode(),'blob':oid.decode(),'bytes':len(data)})
(out/'physical-git-materialization.json').write_text(json.dumps({'schema':'hepta.hia.exact-source-materialization.v1','head':head,'tree':tree,'parents':parents,'prior_head':old,'owned_shallow_boundary_recorded':True,'full_ancestry_claimed':False,'files':physical,'physical_bytes':total,'transport_pack':expected},sort_keys=True,indent=2)+'\n')
print(json.dumps({'materialization':'PASS','head':head,'tree':tree,'files':len(physical),'physical_bytes':total,'TMPDIR':str(temporary)}),flush=True)
os.chdir(source);sys.path.insert(0,str(source))
from tools.hia_selfhost_contract import file_digests
before=file_digests(source);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
mods=['tests.test_hia_cold_caller_selection_history','tests.test_hia_store_source_history','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_caller_terminal_admission.CallerTerminalAdmissionSourceTests','tests.test_hia_caller_terminal_readback.CallerTerminalReadbackSourceTests','tests.test_hia_release_contract','tests.test_hia_store_file_capture_native_readback','tests.test_hia_history_fixture_custody','tests.test_hia_integrated_caller_history','tests.test_hia_integrated_caller_source_admission','tests.test_hia_current_caller_source_history','tests.test_hia_native_result_caller_history','tests.test_hia_artifact_caller_source_history','tests.test_hia_cost_artifact_caller_admission','tests.test_hia_caller_diagnostics_admission','tests.test_hia_current_terminal_admission_history','tests.test_hia_service_bootstrap_caller_admission','tests.test_hia_scoped_caller_source_history','tests.test_hia_evaluation_window_history','tests.test_hia_installed_evaluation_source_history','tests.test_hia_evaluation_caller_capture_history','tests.test_hia_evaluation_caller_admission','tests.test_hia_current_store_source_history']
mods += ["tests.test_hia_cold_compiler","tests.test_hia_native_cold_ci","tests.test_hia_component_input_custody","tests.test_hia_native_cold_custody_readers","tests.test_hia_cold_native_transport.ColdNativeTransportSourceTests","tests.test_hia_cold_native_transport.ColdNativeTransportLibraryPathTests","tests.test_hia_cold_native_transport_controls.ColdNativeTransportControlsSourceTests","tests.test_hia_component_cold_readback"]
mods += ['tests.test_hia_current_component_authoring_history','tests.test_hia_evaluation_cold_source_history']
mods += ['tests.test_hia_current_store_broad_cold','tests.test_hia_native_cold_caller_sources','tests.test_hia_native_cold_caller_integration','tests.test_hia_transport_native_cold_source_admission','tests.test_hia_native_cold_caller_physical_history','tests.test_hia_slot_cold_selection_history','tests.test_hia_slot_integration_component_history','tests.test_hia_native_cold_composition_history','tests.test_hia_native_cold_original_fixture','tests.test_hia_worker_install_owner_generation']
mods += ['tests.test_hia_scoped_evaluation_cold_admission','tests.test_hia_transport_history_views']

python='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
argv=[python,'-B','tools/run_hia_unittest_gate.py',*mods]
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')};env['PYTHONDONTWRITEBYTECODE']='1'
log=out/'tests.log';start=time.monotonic()
with log.open('xb') as f:
 proc=subprocess.Popen(argv,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
 try:code=proc.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
after=file_digests(source);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
terminal={'schema':'hepta.hia.unified-native-cold-source-controls.v1','source_head':head,'source_tree':tree,'argv':argv,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'source_count':len(before),'source_unchanged':before==after,'source_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=source)),'log_bytes':log.stat().st_size,'log_sha256':sha256(log.read_bytes()).hexdigest(),'caller_execution_claimed':False,'whole_native_delivery_qualified':False}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n');print(json.dumps(terminal),flush=True);print(log.read_text()[-17000:],flush=True)
raise SystemExit(code if before==after and terminal['source_clean'] else 2)
