from pathlib import Path,PurePosixPath
import os,stat,hashlib,json,shutil,sys,time
payload=json.loads(sys.argv[1])
allowed={'/home/qian-qi/hia-native-cold-edge-6f7d-20261127-2ac5','/home/qian-qi/hia-native-final-2b154-20261127-2ac5'}
assert payload['schema']=='hepta.closed-scratch-dual-complete-archive-verification.v1'
assert {r['root'] for r in payload['results']}==allowed
base=Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-root-consolidation-20261127-2ac5/closed-6f7d-2b154-scratch-archive-v1')
out=base/'prune-verified-nongit-v1';out.mkdir(mode=0o700,exist_ok=False)
def digest_stream(f):
 h=hashlib.sha256();count=0
 while True:
  b=f.read(1024*1024)
  if not b:break
  h.update(b);count+=len(b)
 return count,h.hexdigest()
def record(path,root):
 s=path.lstat();kind='directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'unsupported'
 r={'path':path.relative_to(root).as_posix(),'kind':kind,'mode':stat.S_IMODE(s.st_mode)}
 if kind=='file':
  with path.open('rb') as f:
   first=os.fstat(f.fileno());size,digest=digest_stream(f);last=os.fstat(f.fileno())
  assert (first.st_dev,first.st_ino,first.st_size,first.st_mtime_ns)==(last.st_dev,last.st_ino,last.st_size,last.st_mtime_ns)
  assert size==s.st_size
  r.update(bytes=size,sha256=digest)
 elif kind=='symlink':r['target']=os.readlink(path)
 elif kind!='directory':raise ValueError('non-archive-safe source type: '+str(path))
 return r
def scan(root):
 result=[record(root,root)]
 for directory,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  for name in [*dirs,*files]:result.append(record(Path(directory)/name,root))
 return sorted(result,key=lambda r:r['path'])
def visible_refs(root):
 found=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  targets=[proc/'cwd',proc/'exe']
  try:targets+=list((proc/'fd').iterdir())
  except OSError:pass
  for p in targets:
   try:target=os.readlink(p)
   except OSError:continue
   if target==str(root) or target.startswith(str(root)+'/'):found.append({'pid':int(proc.name),'reference':str(p),'target':target})
 return found

plans=[]
for receipt in payload['results']:
 assert receipt['mac_complete_members_verified'] and receipt['archive_members_verified'] and receipt['source_initial_and_terminal_identical']
 root=Path(receipt['root']);assert root.is_dir() and not root.is_symlink()
 archive=Path(receipt['archive']);manifest_path=Path(receipt['manifest'])
 assert archive.parent==base and manifest_path.parent==base
 with archive.open('rb') as f:length,digest=digest_stream(f)
 assert length==receipt['archive_bytes'] and digest==receipt['archive_sha256']
 raw=manifest_path.read_bytes();assert len(raw)==receipt['manifest_bytes'] and hashlib.sha256(raw).hexdigest()==receipt['manifest_sha256']
 manifest=json.loads(raw);expected=manifest['entries'];assert manifest['root']==str(root)
 assert not visible_refs(root)
 assert scan(root)==expected,'closed source changed since dual archive'
 entries={r['path']:r for r in expected};prefixes=set()
 for name,row in entries.items():
  leaf=PurePosixPath(name).name
  if leaf=='.git' or (row['kind']=='directory' and leaf.endswith('.git')):prefixes.add(name)
  if row['kind']=='directory' and leaf=='objects' and (name+'/info' in entries or name+'/pack' in entries):prefixes.add(name)
 def protected(name):
  return any(name==prefix or name.startswith(prefix+'/') for prefix in prefixes)
 kept={name for name in entries if protected(name)}
 kept.add('.')
 for prefix in prefixes:
  kept.update(str(p) for p in PurePosixPath(prefix).parents)
 assert all(name in entries for name in kept)
 remove=[row for row in expected if row['path'] not in kept]
 assert all('.git' not in PurePosixPath(r['path']).parts for r in remove)
 plans.append({'root':str(root),'archive_receipt':receipt,'retained_git_prefixes':sorted(prefixes),'retained_paths':sorted(kept),'remove_entries':remove,'all_entries':entries,'source_initial_verified':True})
public=[{k:v for k,v in p.items() if k!='all_entries'} for p in plans]
plan_path=out/'cleanup-plan.json'
with plan_path.open('x') as f:f.write(json.dumps({'schema':'hepta.verified-closed-scratch-pruning-plan.v1','roots':public,'preserve_git_metadata_and_object_paths':True},sort_keys=True,indent=2)+'\n');f.flush();os.fsync(f.fileno())
before=shutil.disk_usage('/home/qian-qi').free;results=[]
for plan in plans:
 root=Path(plan['root']);assert not visible_refs(root)
 expected=plan['all_entries'];retained=set(plan['retained_paths']);changed_dirs={}
 root_fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 def parent_fd(name):
  parts=PurePosixPath(name).parts
  assert parts and all(p not in ('.','..') for p in parts)
  fd=os.dup(root_fd)
  for part in parts[:-1]:
   nxt=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=nxt
  return fd,parts[-1],str(PurePosixPath(name).parent)
 def writable(fd,parent_name):
  s=os.fstat(fd);assert s.st_uid==os.getuid()
  mode=stat.S_IMODE(s.st_mode)
  if not mode&stat.S_IWUSR:
   changed_dirs.setdefault(parent_name,mode);os.fchmod(fd,mode|stat.S_IWUSR)
 files=[r for r in plan['remove_entries'] if r['kind']!='directory']
 dirs=sorted([r for r in plan['remove_entries'] if r['kind']=='directory'],key=lambda r:(len(PurePosixPath(r['path']).parts),r['path']),reverse=True)
 removed_files=removed_bytes=removed_dirs=0
 try:
  for row in files:
   name=row['path'];fd,leaf,parent=parent_fd(name)
   try:
    s=os.stat(leaf,dir_fd=fd,follow_symlinks=False)
    assert stat.S_IMODE(s.st_mode)==row['mode'],name
    if row['kind']=='file':assert stat.S_ISREG(s.st_mode) and s.st_size==row['bytes'],name
    else:assert stat.S_ISLNK(s.st_mode) and os.readlink(leaf,dir_fd=fd)==row['target'],name
    writable(fd,parent);os.unlink(leaf,dir_fd=fd)
   finally:os.close(fd)
   removed_files+=1;removed_bytes+=row.get('bytes',0)
  for row in dirs:
   fd,leaf,parent=parent_fd(row['path'])
   try:writable(fd,parent);os.rmdir(leaf,dir_fd=fd)
   finally:os.close(fd)
   removed_dirs+=1
  for name,mode in changed_dirs.items():
   if name in retained:
    path=root if name=='.' else root/name
    assert path.is_dir() and not path.is_symlink();path.chmod(mode)
 finally:os.close(root_fd)
 remaining=scan(root);assert {r['path'] for r in remaining}==retained
 assert remaining==sorted([expected[name] for name in retained],key=lambda r:r['path']),'retained git metadata changed'
 result={'root':str(root),'removed_files_or_links':removed_files,'removed_logical_file_bytes':removed_bytes,'removed_directories':removed_dirs,'retained_entries':len(remaining),'retained_git_prefixes':plan['retained_git_prefixes'],'retained_git_bytes_and_modes_identical':True,'directory_mode_adjustments_only':changed_dirs,'archive_receipt':plan['archive_receipt']}
 results.append(result);(out/'completed-roots.json').write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'closed_scratch_pruned':{k:v for k,v in result.items() if k not in {'archive_receipt','directory_mode_adjustments_only'}}},sort_keys=True),flush=True)
terminal={'schema':'hepta.verified-closed-scratch-pruning.v1','status':'PASS','results':results,'home_free_bytes_before':before,'home_free_bytes_after':shutil.disk_usage('/home/qian-qi').free,'current_source_modified':False,'remote_branch_deleted':False,'old_product_stack_retirement_claimed':False}
(out/'terminal.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','home_free_bytes_before':before,'home_free_bytes_after':terminal['home_free_bytes_after'],'removed_logical_file_bytes':sum(r['removed_logical_file_bytes'] for r in results),'kept_git_metadata_and_objects':True}),flush=True)
