from pathlib import Path
from hashlib import sha256
import os,stat,json,sys,tarfile,io
base=Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-root-consolidation-20261127-2ac5')
gates=['complete-unified-cold-source-controls-v1','complete-unified-native-source-controls-v2','complete-unified-native-source-controls-v3']
selected=[]
for name in gates:
 directory=base/name;assert directory.is_dir(),name
 selected.extend(p for p in directory.iterdir() if p.is_file() and not p.is_symlink())
cleanup=base/'closed-6f7d-2b154-scratch-archive-v1'
selected.extend(p for p in cleanup.iterdir() if p.is_file() and p.name.endswith('.json') and not p.is_symlink())
selected.extend(p for p in (cleanup/'prune-verified-nongit-v1').rglob('*') if p.is_file() and not p.is_symlink())
rows=[];data_rows=[]
for path in sorted(selected):
 before=path.stat();assert stat.S_ISREG(before.st_mode) and before.st_size<=32*1024*1024
 raw=path.read_bytes();after=path.stat()
 key=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert key(before)==key(after)
 relative=path.relative_to(base).as_posix()
 rows.append({'path':relative,'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(before.st_mode),'mtime_ns':before.st_mtime_ns,'source_path':str(path)})
 data_rows.append((relative,raw,stat.S_IMODE(before.st_mode)))
for name in gates:
 terminal=json.loads((base/name/'terminal.json').read_bytes())
 log=(base/name/'tests.log').read_bytes()
 assert len(log)==terminal['log_bytes'] and sha256(log).hexdigest()==terminal['log_sha256']
 if name==gates[-1]:
  assert terminal['source_head']=='077c0b2e82edd7da50d84c11b55756beb61ee043' and terminal['exit_code']==0 and not terminal['timed_out']
  assert terminal['source_count']==3146 and terminal['source_unchanged'] and terminal['source_clean']
  assert b'Ran 393 tests in 281.429s' in log and log.rstrip().endswith(b'OK')
 else:assert terminal['exit_code']!=0
for row in rows:
 path=Path(row['source_path']);raw=path.read_bytes()
 assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
manifest=(json.dumps({'schema':'hepta.hia.source-control-and-scratch-record-custody.v1','records':rows,'source_before_and_terminal_bytes_checked':True,'historical_failures_preserved':True,'contains_scratch_full_archives':False,'scratch_archives_retained_on_both_hosts':True},sort_keys=True,indent=2)+'\n').encode()
data_rows.append(('RECORDS.json',manifest,0o600))
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz',format=tarfile.PAX_FORMAT) as tf:
 for name,raw,mode in data_rows:
  entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=mode;entry.mtime=0
  tf.addfile(entry,io.BytesIO(raw))
