.intel_syntax noprefix
.text
.global _start
_start:
    mov eax,5
    xor edi,edi
    lea rsi,[rip+status]
    syscall
    test rax,rax
    jne bad
    mov r13,[rip+status+48]
    cmp r13,288
    jb bad
    cmp r13,2097152
    ja bad
    mov eax,72
    xor edi,edi
    mov esi,1034
    syscall
    cmp eax,15
    jne bad
    xor r15d,r15d
reading:
    mov eax,0
    xor edi,edi
    lea rsi,[rip+payload]
    add rsi,r15
    mov rdx,r13
    sub rdx,r15
    syscall
    test rax,rax
    jle bad
    add r15,rax
    cmp r15,r13
    jb reading
    movabs rax,0x31304e4957414948
    cmp [rip+payload],rax
    jne bad
    mov eax,110
    syscall
    cmp rax,[rip+payload+8]
    jne bad
    lea r12,[rip+payload]
    mov rax,[r12+104]
    add rax,[r12+112]
    add rax,288
    mov rcx,[r12+rax+24]
    cmp rcx,1
    ja bad
    add rcx,11
    mov [rip+fd_count],rcx
    lea r12,[rip+payload]
    mov rdi,[r12+96]
    mov eax,257
    lea rsi,[rip+fault_keep]
    mov edx,131266
    mov r10d,384
    syscall
    test rax,rax
    js bad
    mov rdi,rax
    mov eax,3
    syscall
    mov eax,60
    mov edi,65
    syscall
    lea r14,[rip+evidence]
    movabs rax,0x3130445645414948
    mov [r14],rax
    xor ebx,ebx
descriptors:
    lea r12,[rip+payload]
    cmp ebx,10
    jb header_descriptor
    mov rax,[r12+104]
    add rax,[r12+112]
    add rax,288
    cmp ebx,10
    je package_descriptor
    add rax,[r12+rax+16]
    mov r12,[r12+rax+72]
    jmp descriptor_ready
package_descriptor:
    mov r12,[r12+rax+8]
    jmp descriptor_ready
header_descriptor:
    mov r12,[r12+24+rbx*8]
descriptor_ready:
    imul r15,rbx,160
    lea r15,[r14+r15+8]
    mov eax,5
    mov rdi,r12
    mov rsi,r15
    syscall
    test rax,rax
    jne bad
    mov eax,72
    mov rdi,r12
    mov esi,1034
    syscall
    mov [r15+144],rax
    mov eax,72
    mov rdi,r12
    mov esi,1
    syscall
    mov [r15+152],rax
    test rax,rax
    jne bad
    inc ebx
    cmp rbx,[rip+fd_count]
    jb descriptors
    mov QWORD PTR [r14+1928],15
    xor ebx,ebx
open_fds:
    mov eax,72
    mov edi,ebx
    mov esi,1
    syscall
    test rax,rax
    js next_fd
    bts QWORD PTR [r14+1936],rbx
next_fd:
    inc ebx
    cmp ebx,256
    jb open_fds
    mov rsi,r14
    mov edx,1968
    call write_all
    mov eax,60
    xor edi,edi
    syscall
write_all:
    mov eax,1
    mov edi,1
    syscall
    test rax,rax
    jle bad
    add rsi,rax
    sub rdx,rax
    jne write_all
    ret
bad:
    mov eax,60
    mov edi,65
    syscall
    ud2
.bss
.balign 16
status: .skip 144
payload: .skip 2097152
evidence: .skip 1968

.bss
.balign 8
fd_count: .skip 8

.section .rodata
fault_out: .asciz "out"
fault_moved: .asciz "moved"
fault_keep: .asciz "keep"
fault_started: .asciz "started"
