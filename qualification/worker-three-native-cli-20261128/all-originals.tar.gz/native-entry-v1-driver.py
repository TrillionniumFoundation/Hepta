from pathlib import Path
import os,sys,json,hashlib,time,traceback,subprocess
R=Path('/home/qq/hia-worker-protocols-current-native-20261128-2ac5');S=R/'source';O=R/'native-entry-three-domains-v1'
os.chdir(S);sys.path.insert(0,str(S));assert not O.exists();O.mkdir(mode=0o700)
record={'scope':'DEVELOPMENT_NATIVE_ENTRY_CONSTRUCTION_NOT_INSTALLATION_OR_COLD','host':'ai395','success':False,'calls':[],'protocols':{}}
start=time.monotonic()
def save():(O/'report.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
try:
 before=json.loads((R/'native-member-three-domains-v2/source-pins.json').read_text())
 assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p for n,p in before.items())
 assert json.loads((R/'native-member-three-domains-v2/report.json').read_text())['success'] is True
 seed=R/'inputs/hia-source-build';kit=R/'native-member-three-domains-v2/source-kit/hia-source-release-kit'
 input_pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (seed,kit)}
 assert input_pins[str(seed)]=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 assert input_pins[str(kit)]=='68f3086de87e964ba93f0d070976f672e7066a4b736cf6575f2c7fa708496ef7'
 from tools.build_hia_source_build import _named_source_request
 from tools.qualify_hia_worker_install_sources import qualify
 from tools.hia_worker_protocols import protocol
 original_run=subprocess.run
 def capture_run(args,*pos,**kw):
  at=len(record['calls']);d=O/'calls'/('%04d'%at);d.mkdir(parents=True,mode=0o700)
  raw=kw.get('input',b'');assert isinstance(raw,bytes);(d/'stdin.bin').write_bytes(raw);t=time.monotonic()
  row={'argv':[str(x) for x in args],'timeout':kw.get('timeout'),'input_bytes':len(raw),'input_sha256':hashlib.sha256(raw).hexdigest()}
  try:
   p=original_run(args,*pos,**kw);(d/'stdout.bin').write_bytes(p.stdout);(d/'stderr.bin').write_bytes(p.stderr)
   row.update(returncode=p.returncode,stdout_bytes=len(p.stdout),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_bytes=len(p.stderr),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());return p
  except BaseException:row['exception']=traceback.format_exc();raise
  finally:
   row['seconds']=time.monotonic()-t;(d/'call.json').write_text(json.dumps(row,sort_keys=True,indent=2)+'\n');record['calls'].append(row);save();print('ENTRY_CONSTRUCTION_CALL',at,json.dumps(row),flush=True)
 subprocess.run=capture_run
 try:
  for number in ('01','02','03'):
   selected=protocol(number);t=time.monotonic()
   result=qualify(S,seed,kit,O/('entry-'+number),
      specifications=(('hia-worker-install',selected.install_stem+'_entry','sha256_stream',False),),
      schema='hepta.hia.worker-entry-native-source-development.v1',
      scope='DEVELOPMENT_COMPLETE_NAMED_ENTRY_SOURCE_PROTOCOL_'+number)
   named={alias:(S/'examples/hia_bootstrap'/name).read_bytes() for alias,name in
      [('source_build_policy.hepta',selected.install_stem+'_entry_bind.hepta'),
       ('selfhost.hepta','selfhost.hepta'),('source_build_packer.hepta','source_build_packer.hepta')]}
   p=subprocess.run([str(kit),'build'],input=_named_source_request(named,tag=b'HIAKIT01'),capture_output=True,env={'PATH':''},timeout=180)
   assert p.returncode==0 and not p.stderr and p.stdout.startswith(b'\x7fELF'),(number,p.returncode,p.stderr)
   binder=O/('entry-'+number)/'native-entry-binder';binder.write_bytes(p.stdout);binder.chmod(0o500)
   record['protocols'][number]={'status':'passed','source_calls':len(result['calls']),'source_refusals':result['refusal_cases'],'members':result['members'],'unbound':str(O/('entry-'+number)/'hia-worker-install/hia-worker-install'),'binder':str(binder),'binder_bytes':len(p.stdout),'binder_sha256':hashlib.sha256(p.stdout).hexdigest(),'seconds':time.monotonic()-t}
   save();print('NATIVE_ENTRY_SOURCE_PASS',number,json.dumps(record['protocols'][number]),flush=True)
 finally:subprocess.run=original_run
 assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p for n,p in before.items())
 assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==p for n,p in input_pins.items())
 record.update(success=True,seconds=time.monotonic()-start,source_initial_terminal_equal=True,source_pins_manifest_sha256=hashlib.sha256((R/'native-member-three-domains-v2/source-pins.json').read_bytes()).hexdigest(),inputs=input_pins)
 save();print('ALL_THREE_ENTRY_CONSTRUCTION_PASS',flush=True)
except BaseException:
 record.update(error=traceback.format_exc(),seconds=time.monotonic()-start);save();traceback.print_exc();raise
