from pathlib import Path
import os,stat,json,hashlib,tarfile,time,traceback,subprocess
R=Path('/home/qq/hia-worker-protocols-current-native-20261128-2ac5');S=R/'source';D=R/'complete-native-cli-capture-v1'
assert not D.exists();D.mkdir(mode=0o700)
for pid in (3538188,3554671,3563770):assert not Path('/proc',str(pid)).exists()
reports={n:json.loads((R/n/'report.json').read_text()) for n in ('native-entry-three-domains-v1','native-cli-three-domains-v1','native-owner-protocol-matrix-v1')}
assert all(v['success'] is True for v in reports.values())
assert reports['native-cli-three-domains-v1']['total_case_count']==180
source_pins=json.loads((R/'native-cli-three-domains-v1/source-pins.json').read_text())
assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p['sha256'] for n,p in source_pins.items())
roots=[R/n for n in reports]
for prefix in ('native-entry-v1','native-cli-v1','native-owner-matrix-v1'):
 roots.extend(R/(prefix+suffix) for suffix in ('-driver.py','.driver.log','.launch.json'))
roots += [R/'inputs'/n for n in ('B3.flat','hia-source-build','hia-subprocess','hia-source-capture')]
roots += [R/'cli-source-6138-materialize-v1/result.json',R/'cli-source-6138-materialize-v1/runner-prerequisites-recovery.json']
for number in ('01','02','03'):
 roots += [R/'native-member-three-domains-v2'/('protocol-'+number)/'hia-worker-install-owner'/n for n in
           ('hia-worker-install-owner','hia-worker-install-owner.hepta.image.bin','worker_install_dag.hepta.image.bin','sha256_stream.hepta.image.bin')]
names=['tools/qualify_hia_worker_install_entry.py','tools/qualify_hia_worker_protocol_entry.py','tools/hia_worker_entry_protocol_fixture.py','tests/fixtures/hia_worker_entry_protocol_original_v1.json','tests/test_hia_worker_entry_protocol_fixture.py','tests/test_hia_worker_protocol_domains.py','tools/hia_worker_protocols.py','tools/generate_hia_worker_install_owner.py','tools/generate_hia_worker_install_entry.py','tools/qualify_hia_worker_install_sources.py','tools/hia_worker_install_owner_syscalls.S','examples/hia_bootstrap/source_filter_member.hepta']
roots += [S/n for n in names]
roots += [Path(__file__)]
paths={}
def add(p):
 name=p.relative_to(R).as_posix()
 assert name not in paths,name
 paths[name]=p
 if p.is_dir() and not p.is_symlink():
  for child in sorted(p.iterdir()):add(child)
for p in roots:add(p)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for raw in iter(lambda:f.read(1048576),b''):h.update(raw)
 return h.hexdigest()
def identity(p):
 st=p.lstat();row={'mode':stat.S_IMODE(st.st_mode)}
 if stat.S_ISREG(st.st_mode):row.update(type='file',bytes=st.st_size,sha256=digest(p))
 elif stat.S_ISDIR(st.st_mode):row.update(type='directory')
 elif stat.S_ISLNK(st.st_mode):row.update(type='symlink',target=os.readlink(p),target_sha256=hashlib.sha256(os.fsencode(os.readlink(p))).hexdigest())
 else:raise AssertionError(('unexpected evidence node',str(p),st.st_mode))
 return row
start=time.monotonic();members={n:identity(p) for n,p in sorted(paths.items())}
manifest={'schema':'hepta.hia.complete-native-cli-evidence.v1','source_head':'6138f098853d9ee67ce9dc47be5b80388344e0de','root':str(R),'members':members,'scope':'three real native entries and binders, complete original 180 CLI scenarios, and nine actual owner admission pairs; no whole installation or new cold claim'}
raw=json.dumps(manifest,sort_keys=True,indent=2).encode()+b'\n';(D/'manifest.json').write_bytes(raw)
archive=D/'all-originals.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=False) as tar:
 for n,p in sorted(paths.items()):tar.add(p,arcname=n,recursive=False)
 tar.add(D/'manifest.json',arcname='complete-manifest.json',recursive=False)
seen=set();total=0
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  if member.name=='complete-manifest.json':
   assert tar.extractfile(member).read()==raw;continue
  assert member.name in members and member.name not in seen,member.name;seen.add(member.name);row=members[member.name]
  assert member.mode==row['mode'],member.name
  if row['type']=='file':
   assert member.isfile() and member.size==row['bytes'];h=hashlib.sha256()
   with tar.extractfile(member) as f:
    for block in iter(lambda:f.read(1048576),b''):h.update(block)
   assert h.hexdigest()==row['sha256'],member.name;total+=member.size
  elif row['type']=='directory':assert member.isdir()
  elif row['type']=='symlink':assert member.issym() and member.linkname==row['target']
assert seen==set(members)
after={n:identity(p) for n,p in sorted(paths.items())};assert after==members
assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p['sha256'] for n,p in source_pins.items())
p=subprocess.run(['/usr/bin/git','-C',str(S),'status','--porcelain'],capture_output=True,check=True);assert not p.stdout
result={'passed':True,'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive)},'manifest':{'path':str(D/'manifest.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'members':len(members),'regular_members':sum(x['type']=='file' for x in members.values()),'regular_bytes':total,'symlinks':sum(x['type']=='symlink' for x in members.values()),'all_byte_mode_link_target_readback':True,'all_originals_initial_terminal_equal':True,'source_inputs':len(source_pins),'source_initial_terminal_equal':True,'seconds':time.monotonic()-start}
(D/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
