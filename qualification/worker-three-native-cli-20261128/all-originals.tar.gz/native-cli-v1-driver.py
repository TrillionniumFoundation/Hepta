from pathlib import Path
import os,sys,json,hashlib,subprocess,time,traceback,stat
R=Path('/home/qq/hia-worker-protocols-current-native-20261128-2ac5');S=R/'source';D=R/'native-cli-three-domains-v1'
assert not D.exists();D.mkdir(mode=0o700)
record={'scope':'DEVELOPMENT_COMPLETE_NATIVE_CLI_COMPONENT_NOT_WORKER_INSTALLATION_OR_COLD','host':'ai395','success':False,'protocols':{}}
start=time.monotonic()
def save():(D/'report.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
def git(*args):
 p=subprocess.run(['/usr/bin/git','-C',str(S),*args],capture_output=True,check=True);return p.stdout
def snapshot():
 out={}
 for name in git('ls-files','-z').split(b'\0'):
  if not name:continue
  name=name.decode();p=S/name
  if not p.exists():
   assert name.startswith(('qualification/','docs/evidence/')),name
   continue
  assert p.is_file() and not p.is_symlink(),name
  out[name]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mode=stat.S_IMODE(p.stat().st_mode))
 return out
try:
 assert git('rev-parse','HEAD').decode().strip()=='6138f098853d9ee67ce9dc47be5b80388344e0de'
 assert not git('status','--porcelain')
 assert json.loads((R/'native-entry-three-domains-v1/report.json').read_text())['success'] is True
 before=snapshot();(D/'source-pins.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 inputs=[R/'inputs'/n for n in ('B3.flat','hia-source-build','hia-source-capture','hia-subprocess')]
 for number in ('01','02','03'):
  inputs += [R/'native-entry-three-domains-v1'/('entry-'+number)/'hia-worker-install/hia-worker-install',R/'native-entry-three-domains-v1'/('entry-'+number)/'native-entry-binder']
 pins={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mode=stat.S_IMODE(p.stat().st_mode)) for p in inputs}
 env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')};env.update(PYTHONDONTWRITEBYTECODE='1',PATH='/usr/bin:/bin')
 for number in ('01','02','03'):
  out=D/('protocol-'+number);log=D/('protocol-'+number+'.stdout');err=D/('protocol-'+number+'.stderr')
  entry=R/'native-entry-three-domains-v1'/('entry-'+number)
  cmd=['/usr/bin/python3','-B','-m','tools.qualify_hia_worker_protocol_entry','--protocol',number,
       '--output',str(out),'--unbound',str(entry/'hia-worker-install/hia-worker-install'),
       '--binder',str(entry/'native-entry-binder'),'--runner',str(R/'inputs/hia-subprocess'),
       '--seed',str(R/'inputs/hia-source-build'),'--capture',str(R/'inputs/hia-source-capture'),
       '--compiler',str(R/'inputs/B3.flat'),'--trace']
  (D/('protocol-'+number+'.command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
  t=time.monotonic()
  with log.open('wb') as a,err.open('wb') as b:
   p=subprocess.run(cmd,cwd=S,env=env,stdout=a,stderr=b)
  row={'returncode':p.returncode,'seconds':time.monotonic()-t,'stdout_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest()}
  record['protocols'][number]=row;save()
  assert p.returncode==0,(number,p.returncode,err.read_text()[-5000:],log.read_text()[-5000:])
  result=json.loads((out/'results.json').read_text())
  assert result['passed'] is True and all(c['passed'] is True for c in result['cases'])
  prepared=json.loads(Path(str(out)+'.protocol-preparation.json').read_text())
  row.update(case_count=result['case_count'],preparation=prepared,scope=result['scope'],complete_result_sha256=hashlib.sha256((out/'results.json').read_bytes()).hexdigest())
  save();print('NATIVE_CLI_COMPLETE_PASS',number,row['case_count'],row['seconds'],flush=True)
 after=snapshot();assert after==before
 assert not git('status','--porcelain')
 assert {str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mode=stat.S_IMODE(p.stat().st_mode)) for p in inputs}==pins
 record.update(success=True,source_head='6138f098853d9ee67ce9dc47be5b80388344e0de',source_tree=git('write-tree').decode().strip(),source_inputs=len(before),source_initial_terminal_equal=True,input_pins=pins,seconds=time.monotonic()-start,total_case_count=sum(x['case_count'] for x in record['protocols'].values()))
 save();print('ALL_THREE_NATIVE_CLI_PASS',record['total_case_count'],flush=True)
except BaseException:
 record.update(error=traceback.format_exc(),seconds=time.monotonic()-start);save();traceback.print_exc();raise
