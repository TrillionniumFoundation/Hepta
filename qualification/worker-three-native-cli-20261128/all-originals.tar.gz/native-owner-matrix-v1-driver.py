from pathlib import Path
import os,sys,json,hashlib,subprocess,time,traceback,ctypes,mmap,struct
R=Path('/home/qq/hia-worker-protocols-current-native-20261128-2ac5');S=R/'source';D=R/'native-owner-protocol-matrix-v1'
assert not D.exists();D.mkdir(mode=0o700);os.chdir(S);sys.path.insert(0,str(S))
record={'scope':'ACTUAL_NATIVE_FIRST_ADMISSION_FROM_COMPLETE_CLI_REQUESTS_NOT_INSTALLATION_OR_COLD','success':False,'host':'ai395','cases':[]}
start=time.monotonic();maps=[]
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save():(D/'report.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
try:
 assert not Path('/proc/3554671').exists()
 cli=R/'native-cli-three-domains-v1'
 original=json.loads((cli/'report.json').read_text());assert original['success'] is True and original['total_case_count']==180
 before=json.loads((cli/'source-pins.json').read_text())
 assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p['sha256'] for n,p in before.items())
 from tools.generate_hia_worker_install_owner import worker_template
 prefix,holes=worker_template();(D/'mechanical-oracle-prefix.bin').write_bytes(prefix)
 (D/'mechanical-oracle-holes.json').write_text(json.dumps(holes,sort_keys=True,indent=2)+'\n')
 signature=ctypes.CFUNCTYPE(ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64)
 owners={};requests={}
 for number in ('01','02','03'):
  p=R/'native-member-three-domains-v2'/('protocol-'+number)/'hia-worker-install-owner'
  raw=(p/'hia-worker-install-owner').read_bytes()
  starts=[holes[n]+4+struct.unpack_from('<i',raw,holes[n])[0] for n in ('policy_hole','stage_hole','sha_hole')]
  assert starts==sorted(starts) and starts[0]==len(prefix)
  parts=[raw[a:b] for a,b in zip(starts,starts[1:]+[len(raw)])]
  names=['hia-worker-install-owner.hepta.image.bin','worker_install_dag.hepta.image.bin','sha256_stream.hepta.image.bin']
  assert all(part==(p/name).read_bytes() for part,name in zip(parts,names))
  mapping=mmap.mmap(-1,len(parts[0]),prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC);mapping.write(parts[0]);maps.append(mapping)
  function=signature(ctypes.addressof(ctypes.c_char.from_buffer(mapping)))
  owners[number]={'function':function,'path':str(p/'hia-worker-install-owner'),'pin':pin(raw),'parts':[pin(part) for part in parts]}
  result=json.loads((cli/('protocol-'+number)/'results.json').read_text())
  case=next(r for r in result['cases'] if r['case']=='fresh');assert case['passed'] is True
  path=cli/('protocol-'+number)/'fresh/stdout.bin';output=path.read_bytes();assert len(output)==case['request_bytes']+1968
  request=output[:case['request_bytes']];assert request[:8]==b'HIAWIN01'
  header=struct.unpack_from('<8s15Q',request);tail=288+header[13]+header[14]
  assert request[tail:tail+8]==('HIAWOP'+number).encode()
  target=D/('original-entry-request-'+number+'.hiawin');target.write_bytes(request)
  requests[number]={'raw':request,'path':str(path),'full_original':pin(output),'request':pin(request)}
 for owner_number,owner in owners.items():
  for request_number,request in requests.items():
   source=ctypes.create_string_buffer(request['raw'],len(request['raw']))
   state=bytearray(4194304);plan=bytearray(128)
   sa=(ctypes.c_ubyte*len(state)).from_buffer(state);pa=(ctypes.c_ubyte*len(plan)).from_buffer(plan)
   action=owner['function'](ctypes.addressof(source),len(request['raw']),ctypes.addressof(pa),len(plan),ctypes.addressof(sa),len(state))
   words=struct.unpack('<16Q',plan);expected=(110,0) if owner_number==request_number else (60,65)
   row={'owner_protocol':owner_number,'request_protocol':request_number,'owner':owner['pin'],'owner_parts':owner['parts'],'request':request['request'],'actual_cli_output':request['full_original'],'action':action,'plan':list(words),'expected_syscall':expected[0],'expected_argument0':expected[1],'host_syscalls_executed':0,'first_admission_only':True}
   row['passed']=action==1 and words[:2]==expected
   out=D/(owner_number+'-from-'+request_number);out.mkdir(mode=0o700)
   (out/'plan.bin').write_bytes(plan);(out/'state.bin').write_bytes(state)
   row['state']=pin(state);row['plan_pin']=pin(plan);(out/'result.json').write_text(json.dumps(row,sort_keys=True,indent=2)+'\n')
   record['cases'].append(row);save();print('ACTUAL_NATIVE_PROTOCOL_PAIR',owner_number,request_number,json.dumps(row),flush=True)
   assert row['passed'],row
 assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p['sha256'] for n,p in before.items())
 for number,owner in owners.items():assert pin(Path(owner['path']).read_bytes())==owner['pin']
 for number,request in requests.items():assert pin(Path(request['path']).read_bytes())==request['full_original']
 p=subprocess.run(['/usr/bin/git','-C',str(S),'status','--porcelain'],capture_output=True,check=True);assert not p.stdout
 record.update(success=True,seconds=time.monotonic()-start,source_head='6138f098853d9ee67ce9dc47be5b80388344e0de',source_initial_terminal_equal=True,source_count=len(before),correct_pairs=3,rejected_cross_pairs=6,syscalls_executed=0)
 save();print('COMPLETE_NATIVE_PROTOCOL_MATRIX_PASS',flush=True)
except BaseException:
 record.update(error=traceback.format_exc(),seconds=time.monotonic()-start);save();traceback.print_exc();raise
finally:
 for mapping in maps:mapping.close()
