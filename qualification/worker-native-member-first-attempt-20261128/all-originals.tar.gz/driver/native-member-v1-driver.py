from pathlib import Path
import os,sys,json,hashlib,time,traceback,subprocess
R=Path('/home/qq/hia-worker-protocols-current-native-20261128-2ac5');S=R/'source';O=R/'native-member-three-domains-v1'
os.chdir(S);sys.path.insert(0,str(S));assert not O.exists();O.mkdir(mode=0o700)
start=time.monotonic();record={'schema':'hepta.hia.worker-protocol-native-members.v1','scope':'DEVELOPMENT_NATIVE_COMPONENTS_NOT_MATCHING_COLD_OR_INSTALLATION','host':'ai395','success':False,'protocols':{},'calls':[]}
def save():(O/'report.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
try:
 authored=json.loads((R/'author-native-domain-v3/report.json').read_text());assert authored['success'] is True
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==authored['author_input_head']
 names=set(n.decode() for n in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if n)
 names.update(authored['products']);names.update(authored['changed'])
 pins={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in sorted(names) if (S/n).is_file()}
 for n,p in authored['products'].items():assert pins[n]==p['sha256']
 for n,p in authored['changed'].items():assert pins[n]==p['sha256']
 (O/'source-pins.json').write_text(json.dumps(pins,sort_keys=True,indent=2)+'\n')
 seed=R/'inputs/hia-source-build';assert hashlib.sha256(seed.read_bytes()).hexdigest()=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 record['source']={'head':authored['author_input_head'],'generated_changes':authored['changed'],'physical_file_count':len(pins),'physical_pin_manifest_sha256':hashlib.sha256((O/'source-pins.json').read_bytes()).hexdigest()}
 from tools.build_hia_source_build import _named_source_request
 from tools.qualify_hia_worker_install_sources import qualify
 from tools.hia_worker_protocols import protocol
 original_run=subprocess.run
 def capture_run(args,*pos,**kw):
  at=len(record['calls']);d=O/'calls'/('%04d'%at);d.mkdir(parents=True,mode=0o700)
  raw=kw.get('input',b'');assert isinstance(raw,bytes)
  (d/'stdin.bin').write_bytes(raw);t=time.monotonic()
  row={'argv':[str(x) for x in args],'timeout':kw.get('timeout'),'input_bytes':len(raw),'input_sha256':hashlib.sha256(raw).hexdigest()}
  try:
   p=original_run(args,*pos,**kw)
   assert isinstance(p.stdout,bytes) and isinstance(p.stderr,bytes)
   (d/'stdout.bin').write_bytes(p.stdout);(d/'stderr.bin').write_bytes(p.stderr)
   row.update(returncode=p.returncode,stdout_bytes=len(p.stdout),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_bytes=len(p.stderr),stderr_sha256=hashlib.sha256(p.stderr).hexdigest())
   return p
  except BaseException:
   row['exception']=traceback.format_exc();raise
  finally:
   row['seconds']=time.monotonic()-t;(d/'call.json').write_text(json.dumps(row,sort_keys=True,indent=2)+'\n')
   record['calls'].append(row);save();print('NATIVE_CALL',at,json.dumps(row),flush=True)
 subprocess.run=capture_run
 try:
  K=O/'source-kit';K.mkdir(mode=0o700)
  named={alias:(S/'examples/hia_bootstrap'/name).read_bytes() for alias,name in [('source_build_policy.hepta','source_release_kit.hepta'),('selfhost.hepta','selfhost.hepta'),('source_build_packer.hepta','source_build_packer.hepta')]}
  wire=_named_source_request(named)
  for op in ('sources','pack'):
   p=subprocess.run([str(seed),op],input=wire,capture_output=True,env={'PATH':''},timeout=180)
   assert p.returncode==0 and p.stdout and not p.stderr,(op,p.returncode,p.stderr)
   wire=p.stdout
  assert wire.startswith(b'\x7fELF');kit=K/'hia-source-release-kit';kit.write_bytes(wire);kit.chmod(0o500)
  record['kit']={'bytes':len(wire),'sha256':hashlib.sha256(wire).hexdigest(),'sources':{k:hashlib.sha256(v).hexdigest() for k,v in named.items()}}
  save()
  for number in ('03','01','02'):
   selected=protocol(number)
   specs=(('hia-worker-install-owner',selected.install_stem+'_owner',selected.install_stem+'_dag',True),
          ('hia-worker-config-bind','worker_config_bind','worker_config_json',True),
          ('hia-controller-install','controller_install','controller_probe',True))
   t=time.monotonic()
   result=qualify(S,seed,kit,O/('protocol-'+number),specifications=specs,
       schema='hepta.hia.worker-protocol-member-development.v1',
       scope='DEVELOPMENT_NATIVE_PROTOCOL_'+number+'_MEMBERS_NOT_INSTALLATION_OR_COLD')
   record['protocols'][number]={'status':result['status'],'calls':len(result['calls']),'refusals':result['refusal_cases'],'members':result['members'],'seconds':time.monotonic()-t}
   save();print('PROTOCOL_NATIVE_MEMBERS',number,json.dumps(record['protocols'][number]),flush=True)
 finally:subprocess.run=original_run
 assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==p for n,p in pins.items())
 record.update(success=True,seconds=time.monotonic()-start,source_initial_terminal_equal=True)
 save();print('ALL_THREE_NATIVE_MEMBER_GATES_PASS',flush=True)
except BaseException:
 record.update(error=traceback.format_exc(),seconds=time.monotonic()-start);save();traceback.print_exc();raise
