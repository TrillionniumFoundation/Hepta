from pathlib import Path
import ast,sys,json,subprocess,hashlib,os,tarfile,stat,time
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'worker-compat-stage20-registration-v2';out.mkdir(mode=0o700,exist_ok=False)
priorout=root.parent/'worker-compat-stage20-registration-v1'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env)
head='5a7deaf8ad1ec47e126783510e1ce79acdcffb93'
assert git('rev-parse','HEAD').decode().strip()==head
prior_changed={'examples/hia_bootstrap/release_stage_sources.tsv','hepta/hia_agent_contract.py','tools/generate_hia_release_owner.py','tools/hia_selfhost_contract.py'}
assert set(git('diff','--name-only').decode().splitlines())==prior_changed
(out/'driver.py').write_text(sys.argv[1])
(priorout/'original-terminal.json').write_text(sys.argv[4])
sys.path.insert(0,str(root))
payload=json.loads(sys.argv[3])
incoming=root/'review-evidence/hia-worker-compat-release-20261128-2ac5'
registration=json.loads((incoming/'source-registration.json').read_bytes())
native=registration['native_sources'];hosts=registration['host_sources'];allnew=sorted(native+hosts)
p=root/'tools/hia_native_release_dependencies.py';raw=p.read_bytes();(out/'dependency-decoder.before.py').write_bytes(raw)
anchor=b"(b'HIANAM01', b'HIARAW01', b'HIAKOBJ1')"
assert raw.count(anchor)==1
p.write_bytes(raw.replace(anchor,b"(b'HIANAM01', b'HIARAW01', b'HIAKOBJ1', b'HIAMUL01')",1))
p=root/'tests/test_hia_native_release_dependencies.py';raw=p.read_bytes();(out/'dependency-tests.before.py').write_bytes(raw)
anchor=b"\nif __name__ == '__main__':"
assert raw.count(anchor)==1
p.write_bytes(raw.replace(anchor,payload['new_tests'].encode()+anchor,1))
def original_methods(raw):
 return {c.name+'.'+f.name:ast.dump(f,include_attributes=False)for c in ast.parse(raw).body if isinstance(c,ast.ClassDef)for f in c.body if isinstance(f,ast.FunctionDef)}
assert all(original_methods(p.read_bytes())[k]==v for k,v in original_methods(raw).items())
from tools.hia_native_release_dependencies import release_dependencies,read_source_table,synchronize_authorities,check_authorities,check_source_files
oldtable=read_source_table((priorout/'release-stage-table.before.tsv').read_bytes())
olddeps={'publications':oldtable['publications'],'required_sources':json.loads(git('show','HEAD:docs/HIA_NATIVE_SOURCE_AUTHORITY.json'))['paths']}
# Compare the new catalog source union against all previously owned source authority.
newdeps=release_dependencies(root);assert newdeps['declared_stages']==20 and newdeps['publication_count']==116 and len(newdeps['registered_dags'])==14
assert newdeps['publications'][:111]==olddeps['publications'] and newdeps['publications'][111:]==registration['publications']
assert set(newdeps['required_sources'])-set(olddeps['required_sources'])==set(native)
for path in ('docs/HIA_NATIVE_SOURCE_AUTHORITY.json','docs/HIA_COLD_NATIVE_SOURCE_FILES.json'):
 (out/(Path(path).name+'.before')).write_bytes((root/path).read_bytes())
synchronize_authorities(root,newdeps['required_sources'])
counts=check_authorities(root,newdeps['required_sources']);check_source_files(root,newdeps['required_sources'])
assert counts=={'native_source_paths':1424,'cold_source_paths':1423},counts
p=root/'MANIFEST.in';raw=p.read_bytes();(out/'MANIFEST.before.in').write_bytes(raw)
manifest_added=['include '+n for n in allnew+['docs/HIA_WORKER_COMPAT_NATIVE_RELEASE.md'] if 'include '+n not in raw.decode().splitlines()]
assert raw.endswith(b'\n');p.write_bytes(raw+b'\n'+('\n'.join(manifest_added)+'\n').encode())
argv=[sys.executable,'-B','-m','tools.hia_native_release_dependencies','--check-source-files']
start=time.monotonic();q=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=120)
(out/'dependency-check.stdout').write_bytes(q.stdout);(out/'dependency-check.stderr').write_bytes(q.stderr)
assert q.returncode==0,(q.returncode,q.stderr)
for name,pin in [('tools/hia_frozen_component_sources.py','60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774'),('hepta/hia_agent_service.py','7351b80e8f8d46c6cf1988a56b5eb0d2acb5c31727e3d5e63bf5b6355d1e4525')]:
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==pin
record={'schema':'hepta.hia.worker-compat-stage20-unified-registration.v1','head':head,'incoming':'929a54828dff3138a010bea222d77db622a4dcff','new_host_sources':hosts,'new_native_sources':native,'manifest_added':manifest_added,'original_source_tuple_tail_ast_identical':True,'native_source_tuple_tail_ast_identical':True,'prior_catalog_rows_preserved_in_order':True,'native_release_dags':14,'release_stages':20,'publications':116,**counts,'all_three_worker_owners_require_regeneration':True,'check':{'argv':argv,'returncode':q.returncode,'wall_seconds':time.monotonic()-start},'whole_installation_qualified':False}
(out/'registration.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
expected={'tools/hia_native_release_dependencies.py','tests/test_hia_native_release_dependencies.py','tools/hia_selfhost_contract.py','hepta/hia_agent_contract.py','tools/generate_hia_release_owner.py','examples/hia_bootstrap/release_stage_sources.tsv','docs/HIA_NATIVE_SOURCE_AUTHORITY.json','docs/HIA_COLD_NATIVE_SOURCE_FILES.json','MANIFEST.in'}
assert set(git('diff','--name-only').decode().splitlines())==expected
git('diff','--check')
tests=[sys.executable,'-B','tools/run_hia_unittest_gate.py','tests.test_hia_native_release_dependencies.NativeReleaseDependencyTests.test_every_declared_output_and_captured_source_is_registered','tests.test_hia_native_release_dependencies.NativeReleaseDependencyTests.test_omitting_runtime_cannot_pass_a_complete_source_declaration','tests.test_hia_native_release_dependencies.NativeMemberCaptureDependencyTests']
begin=time.monotonic();test=subprocess.run(tests,cwd=root,env=env,capture_output=True,timeout=120)
(out/'member-capture-tests.stdout').write_bytes(test.stdout);(out/'member-capture-tests.stderr').write_bytes(test.stderr)
(out/'member-capture-tests.json').write_text(json.dumps({'argv':tests,'returncode':test.returncode,'elapsed_seconds':time.monotonic()-begin,'scope':'4 focused existing publication and new exact member-capture controls; original test methods unchanged'},sort_keys=True,indent=2)+'\n')
assert test.returncode==0,(test.returncode,test.stderr)
proof=root/'qualification/worker-compat-stage20-integration-20261128';proof.mkdir(parents=True,exist_ok=False)
for i,cloud in enumerate(json.loads(sys.argv[2])):
 expected_cloud=json.loads(cloud['structuredContent']['content'])
 assert (expected_cloud.get('sha')or expected_cloud.get('object',{}).get('sha'))=='f75a5eadc7ba6501beb3fa8fafdae46b1cfcd828'
 (out/('prior-publication-cloud-'+str(i)+'.json')).write_text(json.dumps(cloud,sort_keys=True,indent=2)+'\n')
originals=[];archive=proof/'complete-integration-originals.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for folder in [root.parent/'worker-compat-stage20-integration-v1',root.parent/'worker-compat-stage20-registry-inventory-v1',priorout,out]:
  for p in sorted(folder.rglob('*')):
   s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   assert stat.S_ISREG(s.st_mode),str(p)
   raw=p.read_bytes();name=p.relative_to(root.parent).as_posix()
   originals.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode)})
   t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(originals)
 for row in originals:
  raw=t.extractfile(row['path']).read();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
(proof/'complete-originals-manifest.json').write_text(json.dumps(originals,sort_keys=True,indent=2)+'\n')
(proof/'registration.json').write_text(json.dumps({**record,'complete_originals':len(originals),'archive':{'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}},sort_keys=True,indent=2)+'\n')
expected|={p.relative_to(root).as_posix()for p in proof.iterdir()}
git('add','--',*sorted(expected));assert set(git('diff','--cached','--name-only').decode().splitlines())==expected
q=subprocess.run(['git','commit','-m','Register native Worker compatibility stage and complete source authority without removing prior domains'],cwd=root,env=env,capture_output=True)
(out/'commit.stdout').write_bytes(q.stdout);(out/'commit.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.returncode,q.stderr)
new=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert git('show','-s','--format=%P','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
result={'status':'WORKER_COMPAT_STAGE20_UNIFIED_REGISTRATION_COMPLETE','head':new,'tree':tree,'parent':head,'stages':20,'publications':116,'aggregate_dags':14,**counts,'linux_generated_owner_replay_pending':True,'whole_native_installation_qualified':False}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
