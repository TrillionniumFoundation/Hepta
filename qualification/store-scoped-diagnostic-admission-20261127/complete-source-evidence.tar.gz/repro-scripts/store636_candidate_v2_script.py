import pathlib,hashlib,subprocess,json,time,os
P=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5');S=P/'source'
p=S/'tests/hia_native_transport_worker_successor.py';old=p.read_bytes()
assert hashlib.sha256(old).hexdigest()=='18dd53a80a2bcf00e0cadcf02453f1a17b179abce39756f6cd6cd9618f5a2b1e'
saved=P/'candidate-v1/transport-candidate.py';assert not saved.exists();saved.write_bytes(old)
text=old.decode();a=text.index('def _admit_diagnostic_sources(');b=text.index('\ndef _admit_terminal_sources_before_journal',a)
part=text[a:b]
pair='adjustments[path].update(current_bytes=len(raw), current_sha256=sha256(raw).hexdigest(),'
assert part.count(pair)==2
part=part.replace(pair,'adjustments[path].update(current_bytes=len(native_source), current_sha256=sha256(native_source).hexdigest(),')
pair2="'current_bytes': len(raw), 'current_sha256': sha256(raw).hexdigest(),"
assert part.count(pair2)==1
part=part.replace(pair2,"'current_bytes': len(native_source), 'current_sha256': sha256(native_source).hexdigest(),")
anchor='                if caller_update:\n'
assert part.count(anchor)==1
part=part.replace(anchor,'                # Bind the inner admitted source before restoring the outer physical source.\n'+anchor)
p.write_text(text[:a]+part+text[b:])
e=P/'candidate-v2';e.mkdir();tmp=e/'tmp';tmp.mkdir(mode=0o700)
cmd=['/opt/homebrew/bin/python3.14','-B','tools/run_hia_unittest_gate.py','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_scoped_store_diagnostic_history']
before={n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in ['tests/hia_native_transport_worker_successor.py','tests/test_hia_scoped_store_diagnostic_history.py','tools/hia_scoped_caller_admission_history.py','tools/hia_selfhost_contract.py']}
(e/'intent.json').write_text(json.dumps({'argv':cmd,'source_head':'0ab357a5a9583dbc03b00382a9e69576320e6549','candidate_pins':before,'native_execution_claimed':False},indent=2)+'\n')
env=dict(os.environ,TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1');t=time.monotonic()
with (e/'tests.log').open('wb') as out:r=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
result={'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'source_unchanged':before=={n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in before}}
(e/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pins':before,**result}),flush=True);print((e/'tests.log').read_text(),flush=True)
