import pathlib,hashlib,subprocess,json,time,os
P=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5');S=P/'source'
e=P/'complete-original-controls-v1';e.mkdir();tmp=e/'tmp';tmp.mkdir(mode=0o700)
modules=['tests.test_hia_transport_history_views','tests.test_hia_transport_native_cold_source_admission','tests.test_hia_current_terminal_admission_history','tests.test_hia_history_fixture_custody','tests.test_hia_cost_artifact_caller_admission','tests.test_hia_service_bootstrap_caller_admission','tests.test_hia_caller_terminal_admission','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_scoped_store_diagnostic_history']
cmd=['/opt/homebrew/bin/python3.14','-B','tools/run_hia_unittest_gate.py',*modules]
names=['tests/hia_native_transport_worker_successor.py','tests/test_hia_scoped_store_diagnostic_history.py','tools/hia_scoped_caller_admission_history.py','tools/hia_selfhost_contract.py','tests/hia_historical_diagnostic_controls.py','tests/test_hia_store_native_delivery.py']
tracked=subprocess.check_output(['/usr/bin/git','ls-files','-z','tests','tools','hepta'],cwd=S).decode().split('\0')
names=sorted(set(names)|{n for n in tracked if n and pathlib.Path(n).suffix in ('.py','.json')})
def pins():
 return {n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in names}
before=pins()
(e/'intent.json').write_text(json.dumps({'argv':cmd,'source_head':'0ab357a5a9583dbc03b00382a9e69576320e6549','source_pins':before,'borrowed_peer_helper':'8874/457367f7b37cf304e59c11bceb97b23983932321c51cf40ce98f5a25f8eb00f3','native_execution_claimed':False},indent=2)+'\n')
env=dict(os.environ,TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1');started=time.monotonic()
with (e/'tests.log').open('wb') as out:r=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
after=pins();log=(e/'tests.log').read_bytes()
result={'returncode':r.returncode,'wall_seconds':time.monotonic()-started,'source_count':len(before),'source_unchanged':before==after,'log':{'bytes':len(log),'sha256':hashlib.sha256(log).hexdigest()},'changed':[n for n in before if before[n]!=after[n]]}
(e/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True);print(log.decode(),flush=True)
