import pathlib,sys,json
s=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5/source');sys.path.insert(0,str(s))
from tests import hia_native_transport_worker_successor as t
from tests import hia_cold_caller_selection_history as h
old=h.bind_adjustment
def traced(entry,raw,proof):
 if entry['path']=='tools/qualify_hia_evaluation_callers.py':
  print(json.dumps({'entry':entry,'native_pin':t._pin(raw),'selection_proof':proof},indent=2),flush=True)
 return old(entry,raw,proof)
h.bind_adjustment=traced
try:t.admit_terminal_sources(json.loads((s/t.ORIGINALS['store'][0]).read_bytes()),original_kind='store')
except Exception as e:print(type(e).__name__,str(e),flush=True)
