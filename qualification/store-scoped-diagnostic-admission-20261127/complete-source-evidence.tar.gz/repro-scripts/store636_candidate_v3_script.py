import pathlib,hashlib,json,subprocess,time,os
P=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5');S=P/'source'
p=S/'tests/hia_native_transport_worker_successor.py';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='92c40d357e7bee0368ca788590891c26e516c998c1a3c89d697c2f83ee7256e6'
v=P/'candidate-v2/transport-candidate.py';assert not v.exists();v.write_bytes(raw)
text=raw.decode();a=text.index('def delivery_sources(root, inventory, prior):')
assert text.count('def delivery_sources(root, inventory, prior):')==1
replacement='''def delivery_sources(root, inventory, prior):
    """Bind complete cold and installation histories to the original inventory."""
    from tests.hia_installed_distribution_history import FIXTURE_SHA256, _records
    from tools.hia_native_cold_caller_history import KNOWN_CURRENT
    from tools import hia_native_cold_composition_history as composition

    root = Path(root)
    adjustments = dict(prior['source_adjustments'])
    captured, compositions = {}, []

    def capture(path):
        name = path.relative_to(root).as_posix()
        data = path.read_bytes()
        if name in captured and captured[name] != data:
            raise ValueError('installed caller history changed between captures')
        captured[name] = data
        return data

    records = _records(root=root, take=capture)
    for name, old in inventory['unchanged_files'].items():
        if name in adjustments:
            continue
        if name not in records and name not in KNOWN_CURRENT and name not in composition.CURRENT:
            continue
        data = capture(root / name)
        projected, composed = composition.prepare(root, {name: data}, take=capture)
        if composed is not None:
            compositions.append(composed)
        outer = projected[name]
        selected, native_proof, view = _cold_view(name, outer, root=root,
            take=capture if composed is None else composed['prior_take'])
        previous = _installed_predecessor(name, selected, root=root, take=view)
        if previous == data or _pin(previous) != old:
            continue
        adjustment = {
            'path': name, 'original_sha256': old['sha256'], 'original_bytes': old['bytes'],
            'current_sha256': sha256(outer).hexdigest(), 'current_bytes': len(outer),
            'scope': 'complete fixed cold selection and original component installation histories',
            'reversible_patch_fixture_sha256': FIXTURE_SHA256,
        }
        adjustment = _bind_cold(adjustment, outer, native_proof)
        if composed is not None:
            if (adjustment['current_bytes'] != len(outer)
                    or adjustment['current_sha256'] != sha256(outer).hexdigest()):
                raise ValueError('installed caller composition lost its complete predecessor')
            adjustment.update(current_bytes=len(data), current_sha256=sha256(data).hexdigest(),
                              native_composition_source_history=composed['review'])
        adjustments[name] = adjustment
    for composed in compositions:
        composition.verify_unchanged(composed)
    if any((root / name).read_bytes() != data for name, data in captured.items()):
        raise ValueError('the installed caller source changed before finishing delivery admission')
    return {**prior, 'source_adjustments': adjustments}
'''
p.write_text(text[:a]+replacement)
e=P/'candidate-v3';e.mkdir();tmp=e/'tmp';tmp.mkdir(mode=0o700)
cmd=['/opt/homebrew/bin/python3.14','-B','tools/run_hia_unittest_gate.py','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_scoped_store_diagnostic_history']
before={n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in ['tests/hia_native_transport_worker_successor.py','tests/test_hia_scoped_store_diagnostic_history.py','tools/hia_scoped_caller_admission_history.py','tools/hia_selfhost_contract.py']}
(e/'intent.json').write_text(json.dumps({'argv':cmd,'source_head':'0ab357a5a9583dbc03b00382a9e69576320e6549','candidate_pins':before,'native_execution_claimed':False},indent=2)+'\n')
env=dict(os.environ,TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1');t=time.monotonic()
with (e/'tests.log').open('wb') as out:r=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
result={'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'source_unchanged':before=={n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in before}}
(e/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pins':before,**result}),flush=True);print((e/'tests.log').read_text(),flush=True)
