import pathlib,sys,json
s=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5/source');sys.path.insert(0,str(s))
from tests import test_hia_store_native_delivery as t
from tests.hia_installed_distribution_history import predecessor
from tests import hia_native_transport_worker_successor as delivery
v=t.admit_originals();rows=[]
for name,old in v['shared_dependency_review'].items():
 raw=(s/name).read_bytes();actual=predecessor(name,raw,root=s)
 if delivery._pin(actual)==old:continue
 selected,proof,_=delivery._installed_view(name,raw,root=s)
 rows.append({'name':name,'actual':delivery._pin(actual),'expected':old,'projected':delivery._pin(selected),'cold_proof':proof})
print(json.dumps(rows,indent=2),flush=True)
