import pathlib,sys,json,traceback
s=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5/source');sys.path.insert(0,str(s))
from tests import hia_native_transport_worker_successor as t
from tests.hia_store_delivery_successor import admit_composition
from tests.hia_installed_distribution_history import _records
from tools.hia_native_cold_caller_history import KNOWN_CURRENT
v=json.loads((s/t.ORIGINALS['store'][0]).read_bytes());terminal=t.admit_terminal_sources(v,original_kind='store');composition=admit_composition(v);rows=[]
records=_records(root=s)
for name,old in v['unchanged_files'].items():
 raw=(s/name).read_bytes()
 if name in terminal['source_adjustments'] or name in composition['source_adjustments'] or t._pin(raw)==old:continue
 row={'path':name,'actual':t._pin(raw),'original':old,'cold_known':name in KNOWN_CURRENT,'installed_record':name in records}
 try:
  prior,proof,_=t._installed_view(name,raw,root=s)
  row.update(projected=t._pin(prior),matches_original=t._pin(prior)==old,cold_proof=proof is not None)
 except Exception as e:row['error']=type(e).__name__+': '+str(e)
 rows.append(row)
print(json.dumps(rows,indent=2),flush=True)
