import pathlib,subprocess,json,time,socket,os
P=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5');S=P/'source';E=P/'peer-fetch-v1';E.mkdir()
head='8cc2764e0740f8111b0c9901a90a4951b432e58b';base='0ab357a5a9583dbc03b00382a9e69576320e6549';url='https://github.com/TrillionniumFoundation/Hepta.git'
assert subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=S,text=True).strip()==base
remote=subprocess.run(['/usr/bin/git','remote','get-url','origin'],cwd=S,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
if remote.returncode:subprocess.run(['/usr/bin/git','remote','add','origin',url],cwd=S,check=True)
else:assert remote.stdout.decode().strip()==url
probe=socket.socket();probe.bind(('127.0.0.1',0));port=probe.getsockname()[1];probe.close()
cmd=['/usr/bin/git','-c','http.proxy=socks5h://127.0.0.1:'+str(port),'-c','core.alternateRefsCommand=/usr/bin/true','fetch','--no-tags','--depth=2','--negotiation-tip='+base,'origin',head]
(E/'intent.json').write_text(json.dumps({'head':head,'base':base,'remote':url,'command':cmd},indent=2)+'\n')
with (E/'proxy.log').open('wb') as proxylog:
 proxy=subprocess.Popen(['/usr/bin/ssh','-N','-D','127.0.0.1:'+str(port),'-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ExitOnForwardFailure=yes','rog'],stdout=proxylog,stderr=subprocess.STDOUT)
 try:
  deadline=time.monotonic()+15
  while True:
   assert proxy.poll() is None,'owned proxy exited'
   try:
    c=socket.create_connection(('127.0.0.1',port),timeout=0.5);c.close();break
   except OSError:
    if time.monotonic()>deadline:raise
    time.sleep(0.1)
  started=time.monotonic()
  with (E/'fetch.log').open('wb') as out:r=subprocess.run(cmd,cwd=S,stdout=out,stderr=subprocess.STDOUT,timeout=240)
  result={'returncode':r.returncode,'wall_seconds':time.monotonic()-started}
  if r.returncode==0:
   result['commit']=subprocess.check_output(['/usr/bin/git','rev-parse',head+'^{commit}'],cwd=S,text=True).strip()
   result['parent']=subprocess.check_output(['/usr/bin/git','cat-file','commit',head],cwd=S,text=True).splitlines()[1]
  (E/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);print((E/'fetch.log').read_text(),flush=True)
 finally:
  if proxy.poll() is None:proxy.terminate()
  try:proxy.wait(timeout=10)
  except subprocess.TimeoutExpired:proxy.kill();proxy.wait()
