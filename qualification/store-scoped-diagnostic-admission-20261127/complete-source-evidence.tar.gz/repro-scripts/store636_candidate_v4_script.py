import pathlib,hashlib,json,subprocess,time,os
P=pathlib.Path('/Users/qianqi/work/hepta-store-scoped-diagnostic-20261127-2ac5');S=P/'source'
p=S/'tests/hia_native_transport_worker_successor.py';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='26b68c25b68126de0f4bd9a1b55cc3896bdfcce56373625e1d0afc006f643697'
saved=P/'candidate-v3/transport-candidate.py';assert not saved.exists();saved.write_bytes(raw)
text=raw.decode();a=text.index('def delivery_sources(root, inventory, prior):');part=text[a:]
part=part.replace("    captured, compositions = {}, []\n","    captured, compositions = {}, []\n    shared = dict(prior['shared_dependency_review'])\n    shared_adjustments = dict(prior['shared_adjustments'])\n")
part=part.replace("'scope': 'complete fixed cold selection and original component installation histories',\n            'reversible_patch_fixture_sha256': FIXTURE_SHA256,", "'scope': 'complete fixed source predecessors bound to the original inventory',\n            'reversible_patch_fixture_sha256': (FIXTURE_SHA256 if previous != selected\n                else native_proof['authority']['sha256']),")
anchor='    for composed in compositions:\n'
assert part.count(anchor)==1
insert='''    for name, old in inventory.get('shared_dependency_review', {}).items():
        if name in shared or name not in KNOWN_CURRENT:
            continue
        data = capture(root / name)
        previous, native_proof, _ = _cold_view(name, data, root=root, take=capture)
        if native_proof is None or _pin(previous) != old:
            continue
        entry = {
            'path': name, 'original_bytes': old['bytes'], 'original_sha256': old['sha256'],
            'current_bytes': len(previous), 'current_sha256': sha256(previous).hexdigest(),
            'scope': 'complete fixed cold selection of an original shared dependency',
            'reversible_patch_fixture_sha256': native_proof['authority']['sha256'],
        }
        shared_adjustments[name] = _bind_cold(entry, data, native_proof)
        shared[name] = dict(native_proof['physical_current'])
'''
part=part.replace(anchor,insert+anchor)
part=part.replace("    return {**prior, 'source_adjustments': adjustments}\n","    return {**prior, 'source_adjustments': adjustments, 'shared_dependency_review': shared,\n            'shared_adjustments': shared_adjustments}\n")
p.write_text(text[:a]+part)
t=S/'tests/test_hia_scoped_store_diagnostic_history.py';test=t.read_text();assert hashlib.sha256(test.encode()).hexdigest()=='b514aae49e7b5529f616fb4837a85f1e43a7aeed531ad95ab19e0006bf93ce3c'
assert test.count("\n\nclass ScopedStoreDiagnosticHistoryTests")==1
names="""BROAD_CALLERS = (
    'tests/test_hia_candidate_budget_native.py',
    'tests/test_hia_emission_native.py',
    'tests/test_hia_execution_budget_native.py',
    'tests/test_hia_execution_observation_native.py',
    'tests/test_hia_native_build_dispatch.py',
    'tests/test_hia_service_context_native.py',
    'tests/test_hia_slot_ledger_native_integration.py',
    'tests/test_hia_store_artifact_profile_native.py',
    'tools/qualify_hia_agent_journal_callers.py',
)
SHARED_CALLER = 'tools/qualify_hia_native_delivery.py'
"""
test=test.replace("\n\nclass ScopedStoreDiagnosticHistoryTests","\n\n"+names+"\n\nclass ScopedStoreDiagnosticHistoryTests")
methods='''
    def test_complete_cold_and_component_callers_keep_fixed_original_identities(self):
        result = self.admit()
        for name in BROAD_CALLERS:
            with self.subTest(path=name):
                entry = result['source_adjustments'][name]
                self.assertEqual(
                    {'bytes': entry['original_bytes'], 'sha256': entry['original_sha256']},
                    self.original['unchanged_files'][name])
                self.assertEqual(
                    {'bytes': entry['current_bytes'], 'sha256': entry['current_sha256']},
                    transport._pin((self.root / name).read_bytes()))
                self.assertNotEqual(entry['original_sha256'], entry['current_sha256'])
                self.assertTrue(
                    'native_cold_caller_source' in entry or
                    'native_composition_source_history' in entry)
        shared = result['shared_adjustments'][SHARED_CALLER]
        self.assertEqual(
            {'bytes': shared['original_bytes'], 'sha256': shared['original_sha256']},
            self.original['shared_dependency_review'][SHARED_CALLER])
        self.assertEqual(result['shared_dependency_review'][SHARED_CALLER],
                         transport._pin((self.root / SHARED_CALLER).read_bytes()))

    def test_unreviewed_broad_callers_receive_no_original_source_adjustment(self):
        for name in (*BROAD_CALLERS, SHARED_CALLER):
            with self.subTest(path=name):
                path = self.root / name
                raw = path.read_bytes()
                try:
                    path.write_bytes(raw + b'\n# unreviewed caller source\n')
                    try:
                        result = self.admit()
                    except ValueError:
                        continue
                    entries = result['shared_adjustments' if name == SHARED_CALLER
                                     else 'source_adjustments']
                    self.assertNotIn(name, entries)
                finally:
                    path.write_bytes(raw)

    def test_late_caller_and_authority_changes_after_binding_are_rejected(self):
        bind = transport._bind_cold
        cases = (
            (BROAD_CALLERS[0], BROAD_CALLERS[0]),
            (BROAD_CALLERS[6], BROAD_CALLERS[6]),
            (SHARED_CALLER, SHARED_CALLER),
            (BROAD_CALLERS[0], 'tests/fixtures/hia_native_cold_caller_integration_20261127.json'),
            (BROAD_CALLERS[6], 'tools/hia_native_cold_composition_history.py'),
        )
        for bound, name in cases:
            with self.subTest(bound=bound, changed=name):
                path = self.root / name
                raw = path.read_bytes()
                fired = []

                def changed_after_binding(entry, physical, proof):
                    result = bind(entry, physical, proof)
                    if entry['path'] == bound and not fired:
                        fired.append(True)
                        path.write_bytes(raw + b' ')
                    return result

                try:
                    with patch.object(transport, '_bind_cold', changed_after_binding):
                        with self.assertRaises(ValueError):
                            self.admit()
                    self.assertEqual(fired, [True])
                finally:
                    path.write_bytes(raw)
'''
methods=methods.replace("b'\n# unreviewed caller source\n'","b'\\n# unreviewed caller source\\n'")
anchor="\n\nif __name__ == '__main__':"
assert test.count(anchor)==1
t.write_text(test.replace(anchor,'\n'+methods+anchor))
e=P/'candidate-v4';e.mkdir();tmp=e/'tmp';tmp.mkdir(mode=0o700)
cmd=['/opt/homebrew/bin/python3.14','-B','tools/run_hia_unittest_gate.py','tests.test_hia_store_native_delivery.StoreNativeDeliverySourceTests','tests.test_hia_scoped_store_diagnostic_history']
before={n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in ['tests/hia_native_transport_worker_successor.py','tests/test_hia_scoped_store_diagnostic_history.py','tools/hia_scoped_caller_admission_history.py','tools/hia_selfhost_contract.py']}
(e/'intent.json').write_text(json.dumps({'argv':cmd,'source_head':'0ab357a5a9583dbc03b00382a9e69576320e6549','candidate_pins':before,'native_execution_claimed':False},indent=2)+'\n')
env=dict(os.environ,TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1');started=time.monotonic()
with (e/'tests.log').open('wb') as out:r=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
result={'returncode':r.returncode,'wall_seconds':time.monotonic()-started,'source_unchanged':before=={n:{'bytes':len((S/n).read_bytes()),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in before}}
(e/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pins':before,**result}),flush=True);print((e/'tests.log').read_text(),flush=True)
