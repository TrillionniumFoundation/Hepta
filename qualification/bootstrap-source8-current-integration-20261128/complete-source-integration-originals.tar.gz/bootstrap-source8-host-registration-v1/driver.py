from pathlib import Path
import ast,sys,json,subprocess,hashlib,os,tarfile,stat,time
os.umask(0o022)
root=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
out=root.parent/'bootstrap-source8-host-registration-v1';out.mkdir(mode=0o700,exist_ok=False)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env)
head='f57073fd81108edd038685b922d39e83c1aa1401'
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
(out/'driver.py').write_text(sys.argv[1])
sys.path.insert(0,str(root))
from tools.hia_selfhost_contract import SOURCE_FILES
from hepta.hia_agent_contract import NATIVE_SOURCE_FILES
paths=sorted(['tests/test_hia_bootstrap_case_terminal.py','tests/test_hia_bootstrap_current_service_history.py','tests/fixtures/hia_bootstrap_case_terminal_original_source_v1.json','tests/fixtures/hia_bootstrap_current_service_composition_v1.json','tools/hia_bootstrap_carrier_predecessor.py','tests/fixtures/hia_bootstrap_carrier_service_predecessor_v1.json','tests/test_hia_bootstrap_carrier_predecessor.py'])
added=sorted(set(paths)-set(SOURCE_FILES));assert added==paths,(added,paths)
rows=[]
for name in paths:
 p=root/name;raw=p.read_bytes();assert git('show','HEAD:'+name)==raw
 rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
assert not set(paths).intersection(NATIVE_SOURCE_FILES)
p=root/'tools/hia_selfhost_contract.py';raw=p.read_bytes();(out/'source-contract.before.py').write_bytes(raw)
def node(b):return next(n for n in ast.parse(b).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='SOURCE_FILES'for t in n.targets))
before=node(raw);anchor=b'SOURCE_FILES = (\n';assert raw.count(anchor)==1
new=raw.replace(anchor,anchor+''.join('    '+repr(x)+',\n'for x in added).encode(),1);after=node(new)
assert ast.dump(ast.Tuple(elts=after.value.elts[len(added):],ctx=ast.Load()))==ast.dump(before.value)
p.write_bytes(new)
p=root/'MANIFEST.in';raw=p.read_bytes();assert raw.endswith(b'\n');(out/'MANIFEST.before.in').write_bytes(raw)
manifest_added=['include '+x for x in paths if 'include '+x not in raw.decode().splitlines()]
p.write_bytes(raw+b'\n'+('\n'.join(manifest_added)+'\n').encode())
argv=[sys.executable,'-B','-m','tools.hia_native_release_dependencies','--check-source-files']
start=time.monotonic();q=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=120)
(out/'release-source-dependencies.stdout').write_bytes(q.stdout);(out/'release-source-dependencies.stderr').write_bytes(q.stderr)
assert q.returncode==0,(q.returncode,q.stderr)
record={'schema':'hepta.hia.bootstrap-current-host-source-registration.v1','head':head,'incoming':'0ccf777c71473bca0e3adc02731c62c98e26ac42','new_host_sources':rows,'manifest_added':manifest_added,'original_source_tuple_tail_ast_identical':True,'native_source_authority_changed':False,'check':{'argv':argv,'returncode':q.returncode,'wall_seconds':time.monotonic()-start},'original_source8_status':'RUNNING_ON_INDEPENDENT_AGENT_OWNED_SOURCE; not claimed PASS','whole_native_installation_qualified':False}
(out/'registration.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
assert set(git('diff','--name-only').decode().splitlines())=={'tools/hia_selfhost_contract.py','MANIFEST.in'}
git('diff','--check')
proof=root/'qualification/bootstrap-source8-current-integration-20261128';proof.mkdir(parents=True,exist_ok=False)
physical=[]
archive=proof/'complete-source-integration-originals.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for folder in [root.parent/'bootstrap-source8-current-integration-v1',out]:
  for p in sorted(folder.rglob('*')):
   s=p.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   assert stat.S_ISREG(s.st_mode),str(p)
   raw=p.read_bytes();rel=str(p.relative_to(root.parent))
   physical.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode)})
   t.add(p,arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(physical)
 for row in physical:
  raw=t.extractfile(row['path']).read();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
(proof/'complete-originals-manifest.json').write_text(json.dumps(physical,sort_keys=True,indent=2)+'\n')
(proof/'integration.json').write_text(json.dumps({**record,'complete_original_files':len(physical),'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}},sort_keys=True,indent=2)+'\n')
expected={'tools/hia_selfhost_contract.py','MANIFEST.in'}|{str(p.relative_to(root))for p in proof.iterdir()}
git('add','--',*sorted(expected));assert set(git('diff','--cached','--name-only').decode().splitlines())==expected
q=subprocess.run(['git','commit','-m','Register complete Bootstrap observer and current source provenance with owned integration evidence'],cwd=root,env=env,capture_output=True)
(out/'commit.stdout').write_bytes(q.stdout);(out/'commit.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.returncode,q.stderr)
new=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert git('show','-s','--format=%P','HEAD').decode().strip()==head and not git('status','--porcelain=v1').strip()
result={'status':'BOOTSTRAP_CURRENT_HOST_SOURCES_REGISTERED','head':new,'tree':tree,'parent':head,'host_sources_added':7,'native_sources_unchanged':True,'original_source8_status':'RUNNING_INDEPENDENTLY'}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
