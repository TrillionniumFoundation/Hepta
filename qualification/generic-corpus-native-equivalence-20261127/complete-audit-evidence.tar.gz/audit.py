from pathlib import Path
from hashlib import sha256,sha1
import json,os,stat,struct,subprocess,time
D=Path('/Users/qianqi/work/hia-evaluation-capture-pair-current-20261127-2ac5')
S=D/'source';B=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/all-branch-integration-audit-v1/repository.git')
O=D/'generic-frontier-physical-audit-v1';O.mkdir(exist_ok=False)
payload=(D/'generic-frontier-audit-input-v1.json').read_bytes()
assert len(payload)==885779 and sha256(payload).hexdigest()=='baf190cccd6a72fb1b9d34ffc21ab47b0ecca535da38e9dd06b97dbf97a9d997'
job=json.loads(payload);start=time.monotonic();checked_objects={}
env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1';env['GIT_OPTIONAL_LOCKS']='0'
def git(repo,args):
 r=subprocess.run(['git','-C',str(repo),*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
 assert r.returncode==0,(args,r.stderr.decode(errors='replace'))
 return r.stdout
def object_raw(repo,kind,oid):
 raw=git(repo,['cat-file',kind,oid])
 assert sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
 checked_objects[oid]={'type':kind,'bytes':len(raw)}
 return raw
def commit_tree(repo,oid):
 raw=object_raw(repo,'commit',oid);first=raw.split(b'\n',1)[0];assert first.startswith(b'tree ')
 return first[5:].decode()
def parse_tree(repo,oid):
 raw=object_raw(repo,'tree',oid);out={};at=0
 while at<len(raw):
  middle=raw.index(b' ',at);zero=raw.index(b'\0',middle)
  mode=raw[at:middle].decode();name=raw[middle+1:zero].decode();child=raw[zero+1:zero+21].hex()
  assert len(child)==40 and name and '/'not in name and name not in ('.','..')
  assert name not in out;out[name]=(mode,child);at=zero+21
 assert at==len(raw)
 return out
def subtree(repo,oid,parts):
 for name in parts:
  mode,oid=parse_tree(repo,oid)[name];assert mode=='40000',name
 return oid
def walk(repo,oid,prefix=''):
 result={}
 for name,(mode,child)in parse_tree(repo,oid).items():
  key=prefix+name
  if mode=='40000':result.update(walk(repo,child,key+'/'))
  else:
   assert mode in ('100644','100755')
   result[key]={'mode':mode,'git_blob':child}
 return result
old_root=commit_tree(B,job['old_head'])
old_case_tree=subtree(B,old_root,['examples','hia_bootstrap','cold_cases_generic'])
old_files=walk(B,old_case_tree)
assert len(old_files)==1615
current_root=commit_tree(S,job['current_head']);assert current_root=='23a5d5849597eb3331cbb6a5fa75b5c07b92fdd9'
current_plan_tree=subtree(S,current_root,['examples','hia_bootstrap','cold_plans'])
current_files=walk(S,current_plan_tree)
all_physical={}
def physical(name):
 path=S/name;before=path.lstat()
 assert stat.S_ISREG(before.st_mode)and not path.is_symlink()
 raw=path.read_bytes();after=path.lstat()
 assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 expected=current_files[name.split('cold_plans/',1)[1]]
 blob=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert blob==expected['git_blob']
 assert bool(before.st_mode&0o111)==(expected['mode']=='100755')
 all_physical[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'git_blob':blob,'mode':stat.S_IMODE(before.st_mode)}
 return raw
authority=set(json.loads((S/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json').read_bytes())['paths'])
catalog=json.loads((S/'docs/HIA_COLD_PLAN_CATALOG.json').read_bytes())
assert len(catalog)==60 and len({r['id']for r in catalog})==60
phase_rows=[]
for item in catalog:
 name='examples/hia_bootstrap/cold_plans/'+item['id']+'.hiacases'
 assert name in authority
 raw=physical(name)
 assert raw[:8]==b'HIAQPL01'
 nodes,z0,z1=struct.unpack_from('<3Q',raw,8)
 assert (nodes,z0,z1)==(item['node_count'],0,0)
 assert sha256(raw).hexdigest()==item['plan_sha256']
 phase_rows.append({'path':name,**item,**all_physical[name]})
assert sum(row['node_count']for row in phase_rows)==479882
by_phase={row['id']:row for row in phase_rows};generic_plans=[]
for row in job['plans']:
 actual=by_phase[row['current_id']]
 assert row['exact_match'] and row['old_sha256']==actual['sha256'] and row['old_nodes']==actual['node_count']
 generic_plans.append({'old_id':row['old_id'],'current_id':row['current_id'],'nodes':actual['node_count'],'bytes':actual['bytes'],'sha256':actual['sha256']})
assert len(generic_plans)==39 and sum(x['nodes']for x in generic_plans)==320944
reconstructed={};pools={}
for family,record in job['families'].items():
 name='examples/hia_bootstrap/cold_plans/'+family+'.hiadat'
 assert name in authority
 raw=physical(name);expected=record['pool']
 assert len(raw)==expected['fixture_bytes'] and sha256(raw).hexdigest()==expected['fixture_sha256']
 assert raw[:8]==b'HIAQCS01'
 entries=record['entries'];count,total,reserved=struct.unpack_from('<3Q',raw,8)
 assert (count,total,reserved)==(len(entries),len(raw),0)
 assert [e[0]for e in entries]==sorted({e[0]for e in entries})
 offset=32;parts=[]
 for old_name,size,digest in entries:
  assert old_name not in reconstructed
  data=raw[offset:offset+size];assert len(data)==size and sha256(data).hexdigest()==digest
  assert job['old_inventory']['sources'][old_name]=={'bytes':size,'sha256':digest}
  blob=sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()
  assert old_files[old_name]=={'mode':'100644','git_blob':blob}
  row={'old_path':'examples/hia_bootstrap/cold_cases_generic/'+old_name,'current_pool':name,'offset':offset,'bytes':size,'sha256':digest,'git_blob':blob,'original_mode':'100644'}
  reconstructed[old_name]=row;parts.append(row);offset+=size
 assert raw[offset:offset+(1<<20)]==b'\xa5'*(1<<20)
 offset+=1<<20
 assert raw[offset:]==bytes((1<<20)+8)
 pools[family]={'path':name,**all_physical[name],'sources':len(parts),'payload_bytes':sum(x['bytes']for x in parts),'references':record['references'],'admissions':record['admissions']}
metadata=job['original_metadata']
assert set(reconstructed)==set(job['old_inventory']['sources'])
assert set(old_files)==set(reconstructed)|set(metadata)
for name,record in metadata.items():
 assert old_files[name]=={'mode':'100644','git_blob':record['git_blob']}
recipe_name='examples/hia_bootstrap/cold_bundle_recipe.hiadat'
recipe=(S/recipe_name).read_bytes();assert recipe_name in authority and recipe[:8]==b'HIAQBT01'
nr,np=struct.unpack_from('<2Q',recipe,16);assert np==60
start_at=256+nr*384;recipe_plans=[]
for i in range(np):
 at=start_at+i*384;n=struct.unpack_from('<Q',recipe,at+176)[0]
 name=recipe[at+256:at+256+n].decode('ascii');recipe_plans.append(name)
assert len(set(recipe_plans))==60 and set(recipe_plans)=={r['path']for r in phase_rows}
for name,record in all_physical.items():
 raw=(S/name).read_bytes()
 assert len(raw)==record['bytes'] and sha256(raw).hexdigest()==record['sha256']
report={
 'schema':'hepta.hia.generic-corpus-native-bundle-equivalence.v1',
 'source_head':job['old_head'],'current_head':job['current_head'],
 'current_native_files_individually_match_committed_git_blobs':True,
 'old_commit_and_all_used_tree_objects_rehashed':True,
 'source_file_count':len(reconstructed),'source_bytes':sum(r['bytes']for r in reconstructed.values()),
 'old_metadata_files':len(metadata),'old_tree_files':len(old_files),
 'source_segments_all_exact_original_git_blob_and_sha256':True,
 'all_original_source_names_used_once':True,
 'pool_count':len(pools),'pool_bytes':sum(p['bytes']for p in pools.values()),
 'all_pool_headers_and_both_padding_regions_exact':True,
 'all_pools_match_0768_qualification_sha256':True,
 'generic_plan_count':len(generic_plans),'generic_nodes':sum(p['nodes']for p in generic_plans),
 'all_generic_plans_match_0768_full_sha256_and_node_count':True,
 'whole_catalog_phases':len(phase_rows),'whole_catalog_nodes':sum(p['node_count']for p in phase_rows),
 'all_sixty_actual_plan_files_match_current_catalog':True,
 'all_52_generic_native_inputs_in_current_native_authority':True,
 'all_sixty_actual_plan_files_present_in_native_bundle_recipe':True,
 'generic_reference_calls':sum(r['references']for r in job['families'].values()),
 'original_metadata':metadata,'generic_plans':generic_plans,'pools':pools,
 'reconstructed_source_segments':list(reconstructed.values()),
 'current_phase_files':phase_rows,'checked_git_objects':checked_objects,
 'input_pin':{'bytes':len(payload),'sha256':sha256(payload).hexdigest()},
 'recipe_pin':{'bytes':len(recipe),'sha256':sha256(recipe).hexdigest()},
 'product_executed_by_this_audit':False,'new_full_cold_replay_claimed':False,
 'seconds':time.monotonic()-start,'passed':True}
raw=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();(O/'report.json').write_bytes(raw)
print(json.dumps({k:v for k,v in report.items()if k not in('original_metadata','generic_plans','pools','reconstructed_source_segments','current_phase_files','checked_git_objects')}),flush=True)
print(json.dumps({'report_bytes':len(raw),'report_sha256':sha256(raw).hexdigest(),'report_path':str(O/'report.json')}),flush=True)
