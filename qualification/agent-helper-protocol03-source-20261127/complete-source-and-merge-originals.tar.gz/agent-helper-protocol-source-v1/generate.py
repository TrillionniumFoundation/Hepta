from pathlib import Path
import sys,json,hashlib
root=Path.cwd();sys.path.insert(0,str(root));out=Path(sys.argv[1])
from tools.generate_hia_source_agent_helper_manifest import generated_files,owner_program,stage_program,unchanged_profile
from hepta.hia_program import verify_program
from hepta.hia_agent_assembly import assemble_program
records=[]
for name,raw in generated_files().items():
 model=assemble_program(raw).as_dict();verify_program(model);unchanged_profile(model)
 p=root/name;p.write_bytes(raw)
 records.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),functions=len(model['functions']),blocks=sum(len(f['blocks']) for f in model['functions']),instructions=sum(len(b['ops']) for f in model['functions'] for b in f['blocks']),native_execution=False))
(out/'generated-source.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records),flush=True)
