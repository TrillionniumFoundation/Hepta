from pathlib import Path
import sys,json,unittest
from tools.hia_release_stage_source_history import original_stage_inputs,PRIOR_TAKE
from tests import test_hia_release_stage_plan as original
root=Path.cwd();out=Path(sys.argv[1])
a=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('tests.test_hia_release_extension_catalog'))
names=['tests.test_hia_helper_catalog_extensions','tests.test_hia_release_stage_recipes.ReleaseStageRecipeSourceTests','tests.test_hia_release_stage_plan.ReleaseStageSourceTests','tests.test_hia_agent_helper_catalog.AgentHelperCatalogSourceControls']
with original_stage_inputs(root,original,prior_take=PRIOR_TAKE) as take:
 b=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
(out/'explicit-original-stage-take.json').write_text(json.dumps(take,indent=2)+'\n')
good=a.wasSuccessful() and b.wasSuccessful() and not a.skipped and not b.skipped and a.testsRun+b.testsRun==25
result=dict(status='ALL_25_ORIGINAL_AND_AGENT_SOURCE_CONTROLS_PASS' if good else 'HOLD',tests_run=a.testsRun+b.testsRun,skips=[(t.id(),e) for r in (a,b) for t,e in r.skipped],failures=[(t.id(),e) for r in (a,b) for t,e in r.failures],errors=[(t.id(),e) for r in (a,b) for t,e in r.errors],native_execution=False,whole_product_qualified=False)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);raise SystemExit(0 if good else 1)
