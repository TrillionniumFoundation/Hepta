import json
import os
from pathlib import Path
import resource
import sys
import time

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base / 'service-source'))
from local_model_service import TransformersEngine, Service, runtime_identity, serve, write_new
locks = [json.loads((base / name).read_text()) for name in ('instruct.lock.json', 'base.lock.json')]
directories = [base / 'model-instruct', Path('/dev/shm/hepta-local-agent-20261026/model-base')]
engines, loads = [], []
for lock, directory in zip(locks, directories):
    started = time.monotonic()
    engines.append(TransformersEngine(lock, directory))
    loads.append({'model': lock['repository'], 'load_seconds': time.monotonic() - started})
service = Service(locks, engines, runtime_identity(), base / 'inference-evidence')
write_new(base / 'service-startup.json', {
    'schema': 'hepta.local_service_startup.v1', 'pid': os.getpid(),
    'service_sha256': service.sha256, 'model_loads': loads,
    'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'per_task_budget_includes_startup': False,
    'reserved_disk_remaining': os.statvfs('/tmp').f_bfree * os.statvfs('/tmp').f_frsize})
print(json.dumps({'service_sha256': service.sha256, 'models': service.models,
                  'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  'loads': loads, 'pid': os.getpid()}), flush=True)
serve(service, 19073)
