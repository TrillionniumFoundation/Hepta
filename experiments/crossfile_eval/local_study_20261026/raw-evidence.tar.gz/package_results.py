"""Package the complete frozen experiment after the final independent audit."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

base = Path(__file__).resolve().parent
destination = Path('/workspace/scratch/100b1728036f/Hepta-work/experiments/crossfile_eval/local_study_20261026')

def read(path): return json.loads(path.read_text())
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')

plan = read(base / 'plan.json')
comparison = read(base / 'matrix/comparison.json')
audit = read(base / 'ledger-audit.json')
execution = read(base / 'matrix/execution-order.json')
reports = [read(path) for path in sorted((base / 'matrix').glob('*.run.json'))]
costs = [read(path) for path in sorted((base / 'matrix').glob('*.cost.json'))]
assert len(reports) == len(costs) == len(plan['schedule']) == 40
assert [{k: sample[k] for k in ('model_index', 'task', 'arm', 'replicate')}
        for sample in execution['samples']] == plan['schedule']
assert audit['frozen_tokenizer_reconstruction_verified'] is True
assert audit['all_service_cost_received_by_reports'] is True
assert comparison['planned_attempts'] == comparison['received_unique_records'] == 40
rows = []
for index, model in enumerate(plan['models']):
    for arm in plan['arms']:
        group = [r for r in reports if r['model'] == model and r['arm'] == arm]
        calls = [receipt for report in group for receipt in (report.get('usage') or {}).get('provider_calls', [])]
        rows.append({'model_index': index, 'model': model['name'], 'arm': arm,
                     'planned_attempts': 5, 'completed_attempts': len(group),
                     'successful_tasks': sum(bool((r.get('score') or {}).get('ok')) for r in group),
                     'legal_tool_actions': sum(r.get('validated_tool_calls', 0) for r in group),
                     'input_tokens': sum(call['input_tokens'] for call in calls),
                     'output_tokens': sum(call['output_tokens'] for call in calls),
                     'inference_wall_seconds': sum(call['raw_usage']['elapsed_ns'] for call in calls) / 1e9,
                     'agent_wall_seconds': sum(r.get('agent_wall_seconds') or 0 for r in group),
                     'initializer_seconds': sum(r.get('initialization_seconds') or 0 for r in group),
                     'tool_seconds': sum(tool['elapsed_seconds'] for r in group for tool in r['tools'])})
tool_actions = sum(row['legal_tool_actions'] for row in rows)
successful = sum(row['successful_tasks'] for row in rows)
scored = sum(r.get('score') is not None for r in reports)
all_calls = [call for report in reports for call in (report.get('usage') or {}).get('provider_calls', [])]
finish_reasons = {reason: sum(call['raw_usage']['finish_reason'] == reason for call in all_calls)
                  for reason in sorted({call['raw_usage']['finish_reason'] for call in all_calls})}
length_512 = sum(call['output_tokens'] == 512 and call['raw_usage']['finish_reason'] == 'length' for call in all_calls)
maximum = max(reports, key=lambda r: r.get('agent_wall_seconds') or 0)
summary = {'schema': 'hepta.local_small_model_protocol_study.v1',
           'scope': 'same_family_135m_instruct_and_base_protocol_capacity_and_failure_cost_pilot',
           'plan_sha256': plan['plan_sha256'], 'compiler_sha256': plan['compiler']['hepta_compiler_sha256'],
           'source': read(base / 'source-publication.json'), 'models': plan['models'],
           'provider_source': read(base / 'provider-publication.json'),
           'generation': read(base / 'instruct.lock.json')['generation'],
           'planned_attempts': 40, 'retained_attempts': len(reports),
           'real_generation_calls': audit['measured_generations'],
           'all_reports_strictly_isolated': all(r['sandbox']['available'] and r['isolation'] == 'allowlisted_namespace_capsules' for r in reports),
           'samples_run_in_original_random_order': True, 'sample_retries': 0,
           'legal_tool_actions': tool_actions, 'native_scored_submissions': scored,
           'successful_tasks': successful,
           'generation_finish_reasons': finish_reasons,
           'stopped_at_512_output_tokens': length_512,
           'ai_regression_rate': None,
           'reason_regression_rate_unmeasured': 'No valid implementation change was produced' if not tool_actions else 'See original native scoring records',
           'all_token_costs_complete': all(r['usage_complete'] for r in reports),
           'frozen_tokenizer_reconstruction_verified': audit['frozen_tokenizer_reconstruction_verified'],
           'costs': {'input_tokens': audit['known_service_input_tokens'],
                     'output_tokens': audit['known_service_output_tokens'],
                     'total_tokens': audit['known_service_total_tokens'],
                     'inference_wall_seconds': audit['known_inference_wall_ns'] / 1e9,
                     'agent_wall_seconds': sum(row['agent_wall_seconds'] for row in rows),
                     'initializer_seconds': sum(row['initializer_seconds'] for row in rows),
                     'public_tool_seconds': sum(row['tool_seconds'] for row in rows),
                     'human_seconds_during_samples': sum(c['human_seconds'] for c in costs),
                     'commercial_inference_api_calls': 0, 'commercial_inference_api_spend_usd': 0.0,
                     'local_compute_cost_usd': None, 'network_storage_cost_usd': None,
                     'total_monetary_cost_usd': None, 'cost_per_success': None},
           'model_preparation': read(base / 'model-preparation.json'),
           'model_service_startup': read(base / 'service-startup.json'),
           'model_service_resources': read(base / 'service-final-resources.json'),
           'maximum_sample': {'task': maximum['task_id'], 'arm': maximum['arm'], 'model': maximum['model']['name'],
                              'agent_wall_seconds': maximum['agent_wall_seconds'], 'run_record_sha256': maximum['record_sha256'],
                              'retained_without_exclusion_or_retry': True},
           'rows': rows,
           'framework_status': comparison['status'],
           'framework_outcome_comparison_eligible': comparison['outcome_comparison_eligible'],
           'interpretation': {'valid_coding_agent_comparison_established': False,
                              'independent_language_effect_established': False,
                              'independent_semantic_tool_effect_established': False,
                              'general_productivity_advantage_established': False,
                              'zero_success_is_not_language_equivalence': True,
                              'base_model_is_not_instruction_tuned': True,
                              'model_families_are_not_diverse': True,
                              'new_executable_core_instruction_set_is_outside_task_profile': True}}
summary['record_sha256'] = hashlib.sha256(canonical(summary)).hexdigest()
destination.mkdir(exist_ok=False)
write(destination / 'summary.json', summary)
for src, name in [(base/'plan.json','plan.json'), (base/'matrix/comparison.json','comparison.json'),
                  (base/'ledger-audit.json','ledger-audit.json')]:
    shutil.copyfile(src, destination / name)
write(destination / 'provenance.json', {'compiler': read(base/'source-publication.json'),
                                       'provider_v1': read(base/'provider-publication.json')})

table = '\n'.join('| ' + ('Instruct' if r['model_index'] == 0 else 'Base') + ' | ' + r['arm'] +
                  f" | {r['successful_tasks']}/5 | {r['legal_tool_actions']} | {r['input_tokens']:,} | {r['output_tokens']:,} | {r['inference_wall_seconds']:.3f} | {r['agent_wall_seconds']:.3f} |"
                  for r in rows)
c = summary['costs']
readme = f'''# 真实本地小模型协议与失败成本实验：2026-10-26

**40/40 个预注册样本已保留，真实生成请求 {summary['real_generation_calls']} 次；合法工具动作 {tool_actions}，任务完成 {successful}/40。**

这批数据证明本地真实生成、隔离协议、预算与失败账本走通。它没有证明 40 个有效 coding agent，更没有证明 Hepta、语义工具或智能汇编的生产力优势。当前模型没有产生有效实现变更，代码回归率和每次成功成本均无定义；不能把各臂零成功解释为语言能力相当。

其中 {length_512} 次在 512 输出 token 上限处停止，未产生被协议接收的工具动作。这是冻结输出上限和提示策略下的结果，不是对更长输出、约束解码、其他提示策略或强 coding 模型的能力结论。

## 冻结设计

- 两个不同的真实权重：HuggingFaceTB/SmolLM2-135M-Instruct 与 HuggingFaceTB/SmolLM2-135M base；同系列、同规模，base 未经 instruction tuning。
- 五个既定任务 × Rust/Hepta × 文本/语义工具，共 40 格、每格一次；严格使用原随机顺序，没有重抽、重试、提示修复或挑选结果。
- 每次模型调用冻结为 CPU bfloat16、2 线程、显式 ChatML、原生 8192 上下文、最多 512 个新 token。每格总预算仍为原计划的 32000 输入、12000 输出、44000 总 token、300 秒、32 工具调用。
- 相同 ChatML 封装保留所有任务文件、语言说明、工具模式和反馈；没有裁剪长输入或扩大模型上下文。
- 编译器严格绑定 `{summary['compiler_sha256']}`，对应已发布源提交 [bf5b7fc](https://github.com/TrillionniumFoundation/Hepta/tree/bf5b7fc05fd459292773d7bc67f36f60ca464f87)。后续编译器修正不属于本次测量；任务不覆盖新增 executable_core 指令集。
- Provider v1 对应独立源提交 [92a13e1](https://github.com/TrillionniumFoundation/Hepta/tree/92a13e1e21b80f4979828b3f02c38bb3017780c5)，与编译器身份分别记录；研究后的通用配置加固不会回写本次服务或 bundle 身份。
- 两模型的官方 commit、所有资产哈希、软件 wheel 哈希、服务代码与客户端 bundle 哈希保存在原始归档和冻结计划中。权重和第三方运行库未打包。

## 每臂观察

| 模型 | 实验臂 | 完成任务 | 合法工具动作 | 输入 token | 输出 token | 推理请求秒 | Agent 总秒 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
{table}

`推理请求秒`包含分词和生成；`Agent 总秒`还包含协调器初始化与协议处理。该共享宿主上的时长用于保留成本，没有资格作为语言性能结论。最长样本 {maximum['agent_wall_seconds']:.6f} 秒完整保留，没有因异常而排除。

## 成本口径

| 观察量 | 结果 | 边界 |
| --- | ---: | --- |
| 输入/输出 token | {c['input_tokens']:,} / {c['output_tokens']:,} | 原始 token ID 序列计数，含 EOS |
| 总 token | {c['total_tokens']:,} | 所有失败样本保留 |
| 推理请求耗时 | {c['inference_wall_seconds']:.6f} 秒 | 服务单调时钟计时 |
| 协调器初始化 | {c['initializer_seconds']:.6f} 秒 | 与模型生成分别记录 |
| 公开工具动作耗时 | {c['public_tool_seconds']:.6f} 秒 | 本批合法动作 {tool_actions} 次 |
| Agent 总耗时 | {c['agent_wall_seconds']:.6f} 秒 | 原始逐格 wall 时间之和 |
| 样本运行期间人工介入 | {c['human_seconds_during_samples']:.1f} 秒 | 无人值守脚本观察，不包括方案/实现/准备工作 |
| 外部商业推理 API 支出 | $0 | 推理仅调用本机 loopback 服务 |
| 本机硬件/电力/网络/存储币值 | 未测 | 不能用 $0 代替，整体金额仍为 null |

模型加载、软件安装、下载、资格验证与后处理均不计入某语言的逐格收益。已记录的模型加载与准备秒数、服务 CPU 时间和峰值 RSS 位于 `summary.json`；未独立测量的准备成本没有补造。

## 证据与核验

- `plan.json`：原始完整计划、随机 schedule、模型/预算/编译器/适配器绑定。
- `comparison.json`：原有比较器的完整输出。其 `{comparison['status']}` 表示回执和完整分母满足框架条件，不代表模型完成了有效 coding。
- `ledger-audit.json`：逐个核对请求/响应、模型/服务身份、任务/源文件/工具/预算、原始 token ID 和累计回执；使用冻结 tokenizer 重建全部输入 ID 和输出文本。
- `raw-evidence.tar.gz`：全部 40 格 run/cost 记录、每条原始模型输入/输出/token IDs、服务与 bundle、运行时/权重锁、精确源快照、执行脚本、早期 74+128 token 的真实资格失败样本、workspace fixture 资格、资源事件与非运行文件清理清单。
- `manifest.json`：归档内各文件和交付文件的 SHA-256。归档不包含任何模型权重、第三方运行库或凭据。

本地账本一致性属于可信推理宿主的可复核观察，不是独立硬件证明或商业账单证明。五个 production workspace 的 native 隔离资格单独通过，属于 fixture 控制，不计入模型成功数。强 coding 模型、多模型家族、更大任务集、有效实现变更和回归行为仍需后续预注册实验。

## 复核方法

解压归档后，运行其中 `audit-source/local_model_audit.py`，传入 `inference-evidence`、`matrix` 和新输出路径；不需要 API key。若要重建 tokenizer 对应关系，按原 service 模型顺序提供两个 `--model-dir`，使用归档中的官方 commit/资产清单取得相同字节，并安装锁定运行时。原始源快照包含评分器和 native 资格接口，private oracle 始终只属于协调器，没有进入模型客户端 capsule。

新机器的解释器、编译器和运行库身份若不同，应冻结新计划；不要修改原计划或冒充同一个冻结运行。单模型 transport 资格、两个同系列小模型的协议失败实验与有效 coding 生产力实验是不同的证据层级。
'''
(destination / 'README.md').write_text(readme)

directories = ['adapter', 'service-source', 'audit-source', 'inference-evidence', 'matrix',
               'smollm2-qualification', 'frozen-candidate']
names = ['models.json', 'plan.json', 'adapter-configs.json', 'instruct.lock.json', 'base.lock.json',
         'smollm2.lock.json', 'smollm2-qualification-summary.json', 'service-startup.json',
         'service-final-resources.json', 'model-preparation.json', 'runtime-wheels.lock.json',
         'runtime-install.json', 'torch-wheel.json', 'runtime-development-pruning.json',
         'source-snapshot.json', 'source-publication.json', 'workspace-qualification.json',
         'provider-publication.json', 'generation-config-review.json',
         'SmolLM2-135M-Instruct.upstream.json', 'SmolLM2-135M.upstream.json',
         'launch_service.py', 'run_matrix.py', 'package_results.py', 'ledger-audit.json',
         'study-environment-notes.json']
selected = [base / name for name in names]
for directory in directories:
    selected += [p for p in (base / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
selected = sorted(selected, key=lambda p: p.relative_to(base).as_posix())
assert all(p.is_file() and not p.is_symlink() and p.suffix != '.safetensors' for p in selected)
assert sum(p.stat().st_size for p in selected) < 32 * 1024**2
archive_manifest = [{'path': p.relative_to(base).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in selected]
archive = destination / 'raw-evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as package:
        for path in selected:
            info = package.gettarinfo(str(path), path.relative_to(base).as_posix())
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            info.mode = 0o644
            info.pax_headers = {}
            with path.open('rb') as stream: package.addfile(info, stream)
write(destination / 'manifest.json', {'schema': 'hepta.local_study_artifacts.v1',
      'archive_files': archive_manifest,
      'deliverables': [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(destination.iterdir())],
      'model_weights_included': False, 'credentials_included': False})
print(json.dumps({'destination': str(destination), 'archive_files': len(archive_manifest),
                  'archive_bytes': archive.stat().st_size, 'summary': summary['record_sha256']}))
