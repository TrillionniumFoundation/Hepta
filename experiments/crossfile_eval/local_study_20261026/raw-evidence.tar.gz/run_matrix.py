"""Exact frozen schedule, no retries and no rejected/missing sample replacement."""
import json
from pathlib import Path
import sys
import time

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base / 'frozen-candidate'))
from experiments.crossfile_eval.plan import verify_plan
from experiments.crossfile_eval.runner import evaluate
from experiments.crossfile_eval.records import cost_record, write_append_only
from experiments.crossfile_eval.reporting import compare

rustc = '/tmp/hepta-ai-rust-1.90.0/bin/rustc'
plan = verify_plan(json.loads((base / 'plan.json').read_text()), rustc=rustc, current_environment=True)
command = json.loads((base / 'adapter' / 'command.json').read_text())
out = base / 'matrix'
out.mkdir(exist_ok=False)
reports, costs, progress = [], [], []
for index, cell in enumerate(plan['schedule']):
    started = time.monotonic()
    report = evaluate(cell['task'], cell['arm'], base / 'adapter', command,
                      plan['models'][cell['model_index']], plan=plan,
                      replicate=cell['replicate'], rustc=rustc, pass_env=(), network=True)
    stem = f"{index:02d}-m{cell['model_index']}-{cell['task']}-{cell['arm']}"
    write_append_only(out / (stem + '.run.json'), report)
    cost = cost_record(report, human_seconds=0.0,
                       human_observer='unattended_automation_no_human_intervention_during_this_sample',
                       monetary_cost_usd=None, price_source=None,
                       note='Model/runtime preparation outside sample; hardware/electricity price unmeasured. '
                            'No retry, prompt repair, model-output editing or human intervention in the sample.')
    write_append_only(out / (stem + '.cost.json'), cost)
    reports.append(report); costs.append(cost)
    value = {'ordinal': index, **cell, 'status': report['status'],
             'error': report.get('error', {}).get('code'),
             'tokens': (report.get('usage') or {}).get('total_tokens'),
             'seconds': round(time.monotonic() - started, 3)}
    progress.append(value)
    print(json.dumps(value), flush=True)
comparison = compare(plan, reports, costs)
write_append_only(out / 'comparison.json', comparison)
with (out / 'execution-order.json').open('x') as stream:
    json.dump({'schema': 'hepta.local_matrix_execution.v1', 'plan_sha256': plan['plan_sha256'],
               'planned_schedule_observed_in_order': True, 'samples': progress}, stream, indent=2)
    stream.write('\n')
print(json.dumps({'completed': len(reports), 'status': comparison['status'],
                  'actual_ai_model_runs': comparison['actual_ai_model_runs'],
                  'claims': comparison['claims']}), flush=True)
