#!/usr/bin/env python3
"""Retain finite scalar PHI observations; no production or proof authority."""
import argparse
import ctypes
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def digest(raw):
    return sha256(raw).hexdigest()


def git_snapshot(root):
    def query(*args):
        result = subprocess.run(["git", "-C", str(root), *args], capture_output=True, timeout=15, check=True)
        return result.stdout.decode().strip()
    return {"commit": query("rev-parse", "HEAD"), "tree": query("rev-parse", "HEAD^{tree}"),
            "status": query("status", "--porcelain=v1")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--opt", type=Path, required=True)
    parser.add_argument("--clang", type=Path, required=True)
    parser.add_argument("--full-tests", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.absolute()
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(root))
    os.chdir(root)
    from hepta import hia_scalar_lowering_check as check
    from hepta.hia_program import verify_program
    from hepta.hia_program_runtime import execute_program
    from tests.test_hia_scalar_phi_edges import (
        emitted, phi_lines, replace_incoming, reverse_phis, single_edge_program, two_edge_program,
    )

    before = git_snapshot(root)
    if before["status"]:
        raise RuntimeError("observation requires a clean fixed source")
    files = {}

    def write(name, raw):
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as handle:
            handle.write(raw)
        files[name] = {"bytes": len(raw), "sha256": digest(raw)}

    def command(name, argv, timeout=30):
        started = time.monotonic_ns()
        result = subprocess.run([str(x) for x in argv], capture_output=True, timeout=timeout)
        write(name + ".stdout", result.stdout)
        write(name + ".stderr", result.stderr)
        record = {"argv": [str(x) for x in argv], "returncode": result.returncode,
                  "wall_ns": time.monotonic_ns() - started,
                  "stdout": files[name + ".stdout"], "stderr": files[name + ".stderr"]}
        write(name + ".json", encode(record))
        return record

    identities = {}
    for name, path in (("python", Path(sys.executable)), ("opt", args.opt), ("clang", args.clang)):
        path = path.resolve()
        identities[name] = {"path": str(path), "sha256": digest(path.read_bytes()),
                            "version": command("tools/" + name, [path, "--version"])}
        if identities[name]["version"]["returncode"]:
            raise RuntimeError("tool identity unavailable")
    write("observer.py", Path(__file__).read_bytes())
    selected_sources = ("hepta/hia_scalar_lowering_check.py", "tests/test_hia_scalar_phi_edges.py",
                        "hepta/hia_program_llvm.py", "hepta/hia_program_runtime.py")
    source = {name: digest((root / name).read_bytes()) for name in selected_sources}
    single, double = single_edge_program(), two_edge_program()
    one, two = emitted(single), emitted(double)
    # A constant branch must be present in the Core reference too. Changing
    # only the LLVM condition would introduce an unrelated semantic mismatch
    # and could refute a malformed module without rejecting its structure.
    constant = two_edge_program()
    entry = constant["functions"][0]["blocks"][0]
    entry["ops"] = [{"op": "const", "args": [], "out": [{"name": "always", "type": "bool"}],
                     "attrs": {"value": True}}]
    entry["term"]["cond"] = "always"
    constant_ir = emitted(constant)
    first, second = [line.strip().split(" = ")[0] for line in phi_lines(one)]
    cases = [
        ("single_original", single, one, True),
        ("single_reordered", single, reverse_phis(one), True),
        ("double_original", double, two, True),
        ("double_reordered", double, reverse_phis(two), True),
        ("earlier_phi", single, replace_incoming(one, 1, 0, first), False),
        ("self_phi", single, replace_incoming(one, 0, 0, first), False),
        ("later_phi", single, replace_incoming(one, 0, 0, second), False),
        ("false_edge_phi", constant, replace_incoming(constant_ir, 1, 1, first), False),
        ("parallel_cfg_edge", single, one.replace("edge_0:\n  br label %b1",
            "edge_0:\n  br i1 true, label %b1, label %b1", 1), False),
        ("undefined_phi", double, replace_incoming(two, 1, 1, "%missing"), False),
        ("wrong_type_false_edge", double, replace_incoming(two, 1, 1, "%p_0_2").replace(
            "br i1 %p_0_2,", "br i1 true,", 1), False),
    ]
    branch_local = two.replace("edge_0:\n  br label %b1",
        "edge_0:\n  %edge_value = add i32 %p_0_0, 0\n  br label %b1", 1)
    cases.append(("other_predecessor", double, replace_incoming(branch_local, 1, 1, "%edge_value"), False))
    observations = []
    grid = (0, 1, 2, 17, 255, 65535, 2147483648, 4294967295)
    for name, program, llvm, valid in cases:
        prefix = "cases/" + name
        checked = verify_program(program)
        write(prefix + ".core.json", checked.canonical_bytes)
        write(prefix + ".ll", llvm.encode())
        try:
            report = check.verify_scalar_lowering(checked, llvm_text=llvm)
        except check.ScalarLoweringRejected as exc:
            report = {"status": "rejected", "reason": str(exc)}
        write(prefix + ".checker.json", encode(report))
        oracle = command(prefix + ".opt", [args.opt, "-passes=verify", "-disable-output", output / (prefix + ".ll")])
        row = {"name": name, "expected_valid": valid, "checker_status": report["status"],
               "checker_ok": report["status"] == ("verified" if valid else "rejected"),
               "opt_returncode": oracle["returncode"], "opt_ok": (oracle["returncode"] == 0) == valid,
               "native": None}
        if valid:
            library_path = output / (prefix + ".so")
            native = command(prefix + ".clang", [args.clang, "-x", "ir", "-shared", "-fPIC", "-O2",
                                                   output / (prefix + ".ll"), "-o", library_path])
            if native["returncode"]:
                raise RuntimeError("valid fixture native build failed")
            files[prefix + ".so"] = {"bytes": library_path.stat().st_size,
                                      "sha256": digest(library_path.read_bytes())}
            library = ctypes.CDLL(str(library_path))
            function = library.checked_scalar
            arity = len(program["functions"][0]["params"])
            function.argtypes = [ctypes.c_uint32, ctypes.c_uint32] + ([ctypes.c_bool] if arity == 3 else [])
            function.restype = ctypes.c_uint32
            rows = []
            for left in grid:
                for right in grid:
                    for choice in ((False, True) if arity == 3 else (None,)):
                        values = [left, right] + ([choice] if arity == 3 else [])
                        expected = ((left + right) if arity == 2 else (left - right if choice else right - left)) & 0xffffffff
                        core_result = execute_program(checked, "checked_scalar", values, max_steps=1000)
                        actual = function(*values)
                        rows.append({"arguments": values, "expected": expected, "native": actual,
                                     "core": core_result["result"], "core_status": core_result["status"],
                                     "passed": actual == expected == core_result["result"]})
            write(prefix + ".native.json", encode(rows))
            row["native"] = {"observations": len(rows), "passed": sum(r["passed"] for r in rows)}
        observations.append(row)

    modules = ["tests.test_hia_scalar_phi_edges"]
    if args.full_tests:
        modules += ["tests.test_hia_scalar_lowering_check", "tests.test_hia_scalar_lowering_budget",
                    "tests.test_hia_sequential_core", "tests.test_hia_scalar_totality",
                    "tests.test_hia_scalar_call_validation", "tests.test_hia_translation_validation"]
    suite = unittest.defaultTestLoader.loadTestsFromNames(modules)

    def test_ids(test):
        if isinstance(test, unittest.TestSuite):
            return [identity for item in test for identity in test_ids(item)]
        return [test.id()]

    inventory = test_ids(suite)
    with (output / "tests.log").open("x", encoding="utf-8") as handle:
        result = unittest.TextTestRunner(stream=handle, verbosity=2).run(suite)
    raw = (output / "tests.log").read_bytes()
    files["tests.log"] = {"bytes": len(raw), "sha256": digest(raw)}
    tests = {"modules": modules, "collected_ids": inventory, "collected": len(inventory),
             "run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
             "skips": len(result.skipped), "expected_failures": len(result.expectedFailures),
             "unexpected_successes": len(result.unexpectedSuccesses),
             "passed": result.wasSuccessful() and result.testsRun == len(inventory) and
                       not result.skipped and not result.expectedFailures}
    write("tests.json", encode(tests))
    after = git_snapshot(root)
    source_unchanged = before == after and source == {name: digest((root / name).read_bytes()) for name in selected_sources}
    tools_unchanged = all(digest(Path(record["path"]).read_bytes()) == record["sha256"] for record in identities.values())
    passed = all(row["checker_ok"] and row["opt_ok"] and
                 (row["native"] is None or row["native"]["passed"] == row["native"]["observations"])
                 for row in observations) and tests["passed"] and source_unchanged and tools_unchanged
    summary = {"schema": "hepta.hia.scalar-phi-edge-observation.v1", "protocol_revision": 2,
               "protocol_change": "Constant-false PHI case uses the same constant condition in the Core reference and LLVM; revision 1 changed LLVM alone and was semantically refuted. All original revision-1 receipts remain separate.",
               "passed": passed,
               "completed_utc": datetime.now(timezone.utc).isoformat(), "source_before": before,
               "source_after": after, "source_files": source, "source_unchanged": source_unchanged,
               "tool_identities": identities, "tools_unchanged": tools_unchanged,
               "affinity": sorted(os.sched_getaffinity(0)), "cases": observations, "tests": tests,
               "claims": {"finite_native_observations": True, "whole_llvm_verifier": False,
                          "whole_language_soundness_proved": False, "native_refinement_proved": False,
                          "production_authority": False}, "files": files}
    write("RESULT.json", encode(summary))
    (output / "MANIFEST.json").write_bytes(encode(files))
    print(json.dumps({"passed": passed, "commit": before["commit"], "cases": len(observations),
                      "invalid_verified": [r["name"] for r in observations if not r["expected_valid"] and r["checker_status"] == "verified"],
                      "invalid_not_structurally_rejected": [r["name"] for r in observations if not r["expected_valid"] and not r["checker_ok"]],
                      "native_passed": sum(r["native"]["passed"] for r in observations if r["native"]),
                      "tests": {k: v for k, v in tests.items() if k not in {"collected_ids", "modules"}},
                      "output": str(output)}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
