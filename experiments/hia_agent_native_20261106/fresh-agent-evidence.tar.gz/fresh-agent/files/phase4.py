from pathlib import Path
import sys,json,statistics,datetime
root=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4/fresh-agent')
sys.path.insert(0,str(root))
from runner import RecordedMCP,command
s=json.loads((root/'state.json').read_text());m=json.loads((root/'small-evaluation-measurements-content.json').read_text());workload=json.loads((root/'workload.txt').read_text())
assert m['metric']=='artifact_bytes' and m['baseline_value']=='13720' and m['candidate_value']=='13720' and m['outcome']=='unchanged'
assert m['planned_workload_complete'] and m['planned_cases']==256 and len(m['observations'])==256
assert [o['arguments'][0] for o in m['observations']]==list(range(256))
for index,o in enumerate(m['observations']):
 expected=((index^0x5A)+13)&255
 assert workload['cases'][index]['expected']['values']==[expected]
 for field in ['baseline_native','candidate_native','baseline_vm','candidate_vm']:
  assert o[field]['status']=='returned' and o[field]['values']==[expected],(index,field)
 for field in ['baseline_native','candidate_native']:assert not o[field]['mismatch']
native_summary={}
for role in ['baseline','candidate']:
 run=m['native_runs'][role]['normal'];report=run['report']
 assert run['status']=='returned' and run['returncode']==0 and run['termination_confirmed']
 assert report['native_code_executed'] and report['complete'] and report['completed_cases']==256 and report['planned_cases']==256
 times=[int(o[role+'_native']['elapsed_ns']) for o in m['observations']]
 native_summary[role]={'total_native_ns':m['native_runs'][role]['total_native_ns'],'case_elapsed_ns_median':statistics.median(times),'case_elapsed_ns_min':min(times),'case_elapsed_ns_max':max(times),'report':{k:v for k,v in report.items() if k!='observations'},'first_observation':report['observations'][0]}
audit={'all_256_oracles_match_both_native_and_vm':True,'whole_file_bytes':{'baseline':13720,'candidate':13720,'saved':0},'native_summary':native_summary,'latency_scope':m['measurement_scope'],'decision':'Adopt under explicit allow_unchanged size objective to exercise conditional lifecycle; no size, latency or net-benefit improvement is claimed.'}
(root/'independent-output-audit.json').write_text(json.dumps(audit,indent=2))
print(json.dumps({'audit':audit}),flush=True)
def save(): (root/'state.json').write_text(json.dumps(s,indent=2))
def perform(client,label,tool,args,required=True):
 r=client.call(tool,args);(root/(label+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps({'label':label,'result':r}),flush=True)
 if required and r.get('status')!='completed':raise RuntimeError(label+' did not complete')
 return r
def common(label):return {'catalog_sha256':s['catalog'],'context':s['context'],'request_key':'fresh-agent-20261106-'+label}
with RecordedMCP(command,timeout=180) as client:
 args={**common('conditional-adopt'),'target_slot':'fresh-agent-coldstart','expected_current':{'generation':'0','epoch':'0'},'candidate_artifact':s['candidate_emission']['native_artifact'],'evaluation_receipt':s['evaluation']['evaluation_receipt'],'verification_receipts':[s['candidate_core_verification']['verification_receipt'],s['candidate_encoding_verification']['verification_receipt']]}
 adopted=perform(client,'conditional-adopt','hia_adopt',args)['result'];s['adoption']=adopted;save()
 stale_args={**args,'request_key':'fresh-agent-20261106-stale-adopt'}
 stale=perform(client,'stale-adopt','hia_adopt',stale_args,False);s['stale_adoption']=stale;save()
 if stale.get('status')=='rejected':
  assert stale['error']['code']=='E_HIA_GENERATION_STALE',stale
  current=adopted['current']
 elif stale.get('status')=='completed':
  current=stale['result']['current']
 else:raise RuntimeError('stale CAS outcome unknown; retain original identity')
 rollback=perform(client,'rollback-baseline','hia_rollback',{**common('rollback-baseline'),'target_slot':'fresh-agent-coldstart','expected_current':current,'retained_generation':adopted['previous']['generation'],'reason':'Complete controlled acceptance exercise by restoring the retained equivalent eight-pair baseline for future calls.'})['result']
 s['rollback']=rollback;save()
 assert rollback['active_artifact']['sha256']==s['baseline_emission']['native_artifact']['sha256']
 assert stale.get('status')=='rejected' and stale['error']['code']=='E_HIA_GENERATION_STALE'
(root/'STATUS.json').write_text(json.dumps({'step':'adopted_stale_CAS_rejected_and_rolled_back','blocker':None,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
