from pathlib import Path
import sys,json,os,datetime,hashlib
base=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4')
out=base/'fresh-agent'
sys.path.insert(0,str(base/'clients'))
from hia_agent_native_transport import MCPStdio,json_bytes
command=json.loads((base/'mcp-command.json').read_text())
trace=base/'evidence/fresh-agent-transcript.jsonl'
def save_record(record):
    record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endpoint_command_sha256':hashlib.sha256(json_bytes(command)).hexdigest(),**record}
    with open(trace,'ab',buffering=0) as f:
        os.chmod(trace,0o600)
        f.write(json_bytes(record)+b'\n');os.fsync(f.fileno())
class RecordedMCP(MCPStdio):
    def rpc(self,method,params):
        start=len(getattr(self,'protocol_records',[]))
        try:return super().rpc(method,params)
        finally:
            for rec in self.protocol_records[start:]:save_record(rec)
    def notify(self,method,params):
        result=super().notify(method,params)
        save_record({'request':{'jsonrpc':'2.0','method':method,'params':params},'response':None})
        return result
def main():
    requests=json.load(sys.stdin)
    with RecordedMCP(command,timeout=180) as client:
        for row in requests:
            method=row['method'];params=row['params'];label=row['label']
            try:
                result=client.call(params['name'],params['arguments']) if method=='tools/call' else client.rpc(method,params)
            except Exception as e:result={'transport_error':type(e).__name__,'message':str(e)}
            (out/(label+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
            print(json.dumps({'label':label,'result':result},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
