from pathlib import Path
import sys,json,os,datetime
root=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4/fresh-agent')
base=root.parent
evidence=base/'evidence/fresh-agent-transcript.jsonl'
if not evidence.exists():
 with open(evidence,'xb',buffering=0) as f:
  os.chmod(evidence,0o600)
  for name in ['fresh-agent-transcript.jsonl','protocol-trace.jsonl']:
   f.write((root/name).read_bytes())
  os.fsync(f.fileno())
runner=(root/'runner.py').read_text().replace("trace=out/'protocol-trace.jsonl'","trace=base/'evidence/fresh-agent-transcript.jsonl'")
(root/'runner.py').write_text(runner)
status={'step':'repair, verification, emission, and evaluation','last_completed_job':'1a1b34aea52-fc05-81d2','blocker':None,'trace':str(evidence),'discovery_only':'tools/list plus hia_describe/hia_read artifacts','invalid_error':'E_HIA_TYPE/core_verification','at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'STATUS.json').write_text(json.dumps(status,indent=2))
sys.path.insert(0,str(root))
from runner import RecordedMCP,command
state=json.loads((root/'state.json').read_text());catalog=state['catalog'];profiles=state['profiles'];context=state['context'];baseline=state['baseline_core']
def save(): (root/'state.json').write_text(json.dumps(state,indent=2))
def perform(client,label,tool,args,required=True):
 result=client.call(tool,args)
 (root/(label+'.json')).write_text(json.dumps(result,indent=2))
 print(json.dumps({'label':label,'result':result}),flush=True)
 if required and result.get('status')!='completed':raise RuntimeError(label+' did not complete')
 return result
def common(label):return {'catalog_sha256':catalog,'context':context,'request_key':'fresh-agent-20261106-'+label}
def verify(client,label,candidate,base,subject,claims):
 return perform(client,label,'hia_verify',{**common(label),'candidate':candidate,'base_program':base,'validation_profile':profiles['validation'],'subject':subject,'claims':claims})['result']
def emit(client,label,candidate,receipts):
 return perform(client,label,'hia_emit',{**common(label),'candidate':candidate,'backend_profile':profiles['backend'],'output_kind':'shared','codegen':{'kind':'canonical','lowering_profile':profiles['lowering']},'verification_receipts':receipts})['result']
with RecordedMCP(command,timeout=180) as client:
 source=(root/'invalid-source.txt').read_text().replace('{"value":256}','{"value":90}')
 (root/'candidate-source.txt').write_text(source)
 ref=perform(client,'retain-candidate-source','hia_artifact',{'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-retain-candidate-source','artifact_profile':profiles['artifact'],'source':{'kind':'utf8','text':source}})['result']['artifact']
 state['artifacts']['candidate-source']=ref
 candidate=perform(client,'candidate-import','hia_candidate',{**common('candidate-import'),'change':{'kind':'import','format':'hia-asm.v1','source':ref}})['result']['candidate']
 state['candidate_core']=candidate;save()
 bv=verify(client,'baseline-core-verify',baseline,baseline,{'kind':'core'},['core_admission','behavior_equivalence'])
 cv=verify(client,'candidate-core-verify',candidate,baseline,{'kind':'core'},['core_admission','behavior_equivalence'])
 state['baseline_core_verification']=bv;state['candidate_core_verification']=cv;save()
 be=emit(client,'baseline-emit',baseline,[bv['verification_receipt']]);state['baseline_emission']=be;save()
 ce=emit(client,'candidate-emit',candidate,[cv['verification_receipt']]);state['candidate_emission']=ce;save()
 bn=verify(client,'baseline-encoding-verify',baseline,baseline,{'kind':'native_artifact','backend_profile':profiles['backend'],'native_artifact':be['native_artifact'],'build_receipt':be['build_receipt']},['encoding_check'])
 cn=verify(client,'candidate-encoding-verify',candidate,baseline,{'kind':'native_artifact','backend_profile':profiles['backend'],'native_artifact':ce['native_artifact'],'build_receipt':ce['build_receipt']},['encoding_check'])
 state['baseline_encoding_verification']=bn;state['candidate_encoding_verification']=cn;save()
 ev=perform(client,'candidate-evaluate','hia_evaluate',{**common('candidate-evaluate'),'baseline_artifact':be['native_artifact'],'candidate_artifact':ce['native_artifact'],'build_receipt':ce['build_receipt'],'verification_receipts':[cv['verification_receipt'],cn['verification_receipt']]})['result']
 state['evaluation']=ev;save()
 for name in ['measurements','full_cost_ledger','evaluation_receipt']:
  result=perform(client,'evaluation-'+name+'-read','hia_read',{'catalog_sha256':catalog,'artifact':ev[name],'max_bytes':65536})
  value=result['result'];content=value['content'];cursor=value.get('next_cursor');page=0
  while cursor:
   page+=1
   extra=perform(client,'evaluation-'+name+'-read-'+str(page),'hia_read',{'catalog_sha256':catalog,'artifact':ev[name],'cursor':cursor,'max_bytes':65536})
   content+=extra['result']['content'];cursor=extra['result'].get('next_cursor')
  (root/('evaluation-'+name+'-content.json')).write_text(content)
status.update(step='evaluation_complete',at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(root/'STATUS.json').write_text(json.dumps(status,indent=2))
