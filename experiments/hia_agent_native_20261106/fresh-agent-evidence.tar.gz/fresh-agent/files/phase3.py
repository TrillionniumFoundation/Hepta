from pathlib import Path
import sys,json,datetime
root=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4/fresh-agent')
sys.path.insert(0,str(root))
from runner import RecordedMCP,command
state=json.loads((root/'state.json').read_text());catalog=state['catalog'];profiles=state['profiles'];old_context=state['context'];candidate=state['candidate_core']
def save(): (root/'state.json').write_text(json.dumps(state,indent=2))
def perform(client,label,tool,args,required=True,visible=True):
 result=client.call(tool,args)
 (root/(label+'.json')).write_text(json.dumps(result,indent=2))
 if visible:print(json.dumps({'label':label,'result':result}),flush=True)
 else:print(json.dumps({'label':label,'status':result.get('status')}),flush=True)
 if required and result.get('status')!='completed':raise RuntimeError(label+' did not complete')
 return result
def retain(client,label,text):
 (root/(label+'.txt')).write_text(text)
 r=perform(client,'retain-'+label,'hia_artifact',{'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-retain-'+label,'artifact_profile':profiles['artifact'],'source':{'kind':'utf8','text':text}})
 state['artifacts'][label]=r['result']['artifact'];save();return r['result']['artifact']
def read_all(client,label,ref):
 content='';cursor=None;page=0;encoding=None
 while True:
  args={'catalog_sha256':catalog,'artifact':ref,'max_bytes':65536}
  if cursor:args['cursor']=cursor
  r=perform(client,label+'-page-'+str(page),'hia_read',args,visible=False)['result']
  content+=r['content'];encoding=r['encoding'];cursor=r.get('next_cursor')
  if not cursor:break
  page+=1
 (root/(label+'-content.json')).write_text(content)
 print(json.dumps({'label':label,'content_bytes':len(content.encode()),'encoding':encoding,'pages':page+1}),flush=True)
 return json.loads(content) if encoding=='utf8' else content
with RecordedMCP(command,timeout=180) as client:
 failed=state['candidate_core_verification']['checks'][1]['evidence_artifact']
 print(json.dumps({'unknown_equivalence_evidence':read_all(client,'unknown-equivalence-evidence',failed)}),flush=True)
 source=(root/'candidate-source.txt').read_text().splitlines()[:-2]
 source+=['  redundant_step:u8 = const() {"value":17}']
 last='answer'
 for i in range(8):
  source+=['  pad_add_'+str(i)+':u8 = int.add.wrap('+last+',redundant_step)','  pad_sub_'+str(i)+':u8 = int.sub.wrap(pad_add_'+str(i)+',redundant_step)']
  last='pad_sub_'+str(i)
 source+=['  ret('+last+')','end']
 source='\n'.join(source)+'\n'
 ref=retain(client,'baseline-small-source',source)
 baseline=perform(client,'baseline-small-import','hia_candidate',{'catalog_sha256':catalog,'context':old_context,'request_key':'fresh-agent-20261106-baseline-small-import','change':{'kind':'import','format':'hia-asm.v1','source':ref}})['result']['candidate']
 context=perform(client,'small-frozen-context','hia_context',{'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-small-frozen-context','compiler_profile':profiles['compiler'],'target_profile':profiles['target'],'baseline_program':baseline,'workload':state['artifacts']['workload'],'objective':state['artifacts']['objective'],'budget':state['budget']})['result']['context']
 state['initial_context']=old_context;state['initial_baseline_core']=state['baseline_core'];state['initial_baseline_emission']=state['baseline_emission'];state['initial_candidate_emission']=state['candidate_emission']
 state['initial_candidate_core_verification']=state['candidate_core_verification'];state['context']=context;state['baseline_core']=baseline;save()
 def common(label):return {'catalog_sha256':catalog,'context':context,'request_key':'fresh-agent-20261106-'+label}
 def verify(label,core,base,subject,claims):
  r=perform(client,label,'hia_verify',{**common(label),'candidate':core,'base_program':base,'validation_profile':profiles['validation'],'subject':subject,'claims':claims})['result']
  if any(check['status']!='proved' for check in r['checks']):raise RuntimeError(label+' has an unproved claim')
  return r
 bv=verify('small-baseline-core-verify',baseline,baseline,{'kind':'core'},['core_admission','behavior_equivalence'])
 cv=verify('small-candidate-core-verify',candidate,baseline,{'kind':'core'},['core_admission','behavior_equivalence'])
 state['baseline_core_verification']=bv;state['candidate_core_verification']=cv;save()
 def emit(label,core,receipt):
  return perform(client,label,'hia_emit',{**common(label),'candidate':core,'backend_profile':profiles['backend'],'output_kind':'shared','codegen':{'kind':'canonical','lowering_profile':profiles['lowering']},'verification_receipts':[receipt]})['result']
 be=emit('small-baseline-emit',baseline,bv['verification_receipt']);state['baseline_emission']=be;save()
 ce=emit('small-candidate-emit',candidate,cv['verification_receipt']);state['candidate_emission']=ce;save()
 bn=verify('small-baseline-encoding-verify',baseline,baseline,{'kind':'native_artifact','backend_profile':profiles['backend'],'native_artifact':be['native_artifact'],'build_receipt':be['build_receipt']},['encoding_check'])
 cn=verify('small-candidate-encoding-verify',candidate,baseline,{'kind':'native_artifact','backend_profile':profiles['backend'],'native_artifact':ce['native_artifact'],'build_receipt':ce['build_receipt']},['encoding_check'])
 state['baseline_encoding_verification']=bn;state['candidate_encoding_verification']=cn;save()
 ev=perform(client,'small-candidate-evaluate','hia_evaluate',{**common('small-candidate-evaluate'),'baseline_artifact':be['native_artifact'],'candidate_artifact':ce['native_artifact'],'build_receipt':ce['build_receipt'],'verification_receipts':[cv['verification_receipt'],cn['verification_receipt']]})['result']
 state['evaluation']=ev;save()
 for key in ['measurements','full_cost_ledger','evaluation_receipt']:
  content=read_all(client,'small-evaluation-'+key,ev[key])
  print(json.dumps({'label':'summary-'+key,'value':{k:v if not isinstance(v,(list,dict)) else {'type':type(v).__name__,'count':len(v),'keys':list(v)[:20] if isinstance(v,dict) else None} for k,v in content.items()}}),flush=True)
(root/'STATUS.json').write_text(json.dumps({'step':'small_evaluation_complete','blocker':None,'trace':str(root.parent/'evidence/fresh-agent-transcript.jsonl'),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
