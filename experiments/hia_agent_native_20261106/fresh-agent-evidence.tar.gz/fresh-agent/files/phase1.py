from pathlib import Path
import sys,json,datetime
root=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4/fresh-agent')
sys.path.insert(0,str(root))
from runner import RecordedMCP,command
m=json.loads(json.loads((root/'manifest-read.json').read_text())['result']['content'])
catalog=m['catalog_sha256'];profiles=m['profiles']
state={'catalog':catalog,'profiles':profiles,'sources':{},'artifacts':{},'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(): (root/'state.json').write_text(json.dumps(state,indent=2))
def perform(client,label,tool,args,required=True):
 result=client.call(tool,args)
 (root/(label+'.json')).write_text(json.dumps(result,indent=2))
 print(json.dumps({'label':label,'result':result}),flush=True)
 if required and result.get('status')!='completed':raise RuntimeError(label+' did not complete')
 return result
def retain(client,label,text):
 (root/(label+'.txt')).write_text(text)
 r=perform(client,'retain-'+label,'hia_artifact',{'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-retain-'+label,'artifact_profile':profiles['artifact'],'source':{'kind':'utf8','text':text}})
 state['artifacts'][label]=r['result']['artifact'];save();return r['result']['artifact']
def serialized(v):return json.dumps(v,separators=(',',':'),sort_keys=True)
head=['hia-asm.v1 hepta.hia.program.v8 fresh_xor5a_plus13','exports(transform)','fn transform(x:u8) -> (u8) effects() entry(entry)','block entry(x:u8)','  mask:u8 = const() {"value":90}','  mixed:u8 = bit.xor(x,mask)','  delta:u8 = const() {"value":13}','  answer:u8 = int.add.wrap(mixed,delta)']
baseline=head+['  redundant_step:u8 = const() {"value":17}']
last='answer'
for i in range(128):
 baseline+=['  pad_add_'+str(i)+':u8 = int.add.wrap('+last+',redundant_step)','  pad_sub_'+str(i)+':u8 = int.sub.wrap(pad_add_'+str(i)+',redundant_step)']
 last='pad_sub_'+str(i)
baseline+='  ret('+last+')','end'
baseline='\n'.join(baseline)+'\n'
invalid='\n'.join(head+['  ret(answer)','end'])+'\n'
invalid=invalid.replace('{"value":90}','{"value":256}')
workload={'schema':'hepta.hia.agent.workload.v1','cases':[{'function':'transform','arguments':[x],'expected':{'status':'returned','values':[((x^0x5A)+13)&0xff]}} for x in range(256)],'warmup_iterations':0,'repetitions':3}
objective={'schema':'hepta.hia.agent.objective.v1','metric':'artifact_bytes','required_claims':['core_admission','behavior_equivalence','encoding_check'],'allow_unchanged':True,'min_improvement_ratio':0,'require_net_benefit':False}
cost={'schema':'hepta.hia.agent.cost-policy.v1','external_costs':{'model_tokens':None,'model_wall_ns':None,'discovery_wall_ns':None},'external_costs_complete':False,'expected_invocations':'0'}
state['sources']={'baseline':'baseline-source.txt','invalid':'invalid-source.txt'}
with RecordedMCP(command,timeout=180) as client:
 workload_ref=retain(client,'workload',serialized(workload))
 objective_ref=retain(client,'objective',serialized(objective))
 cost_ref=retain(client,'cost-policy',serialized(cost))
 baseline_ref=retain(client,'baseline-source',baseline)
 invalid_ref=retain(client,'invalid-source',invalid)
 budget={'max_candidates':16,'max_model_tokens':1000000,'max_total_wall_ms':1200000,'max_native_wall_ms':30000,'max_memory_bytes':'536870912','cost_policy':cost_ref}
 context_args={'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-author-context','compiler_profile':profiles['compiler'],'target_profile':profiles['target'],'baseline_program':None,'workload':workload_ref,'objective':objective_ref,'budget':budget}
 author=perform(client,'author-context','hia_context',context_args)['result']['context']
 state['author_context']=author;state['budget']=budget;save()
 base=perform(client,'baseline-import','hia_candidate',{'catalog_sha256':catalog,'context':author,'request_key':'fresh-agent-20261106-baseline-import','change':{'kind':'import','format':'hia-asm.v1','source':baseline_ref}})['result']['candidate']
 state['baseline_core']=base;save()
 context_args.update(request_key='fresh-agent-20261106-frozen-context',baseline_program=base)
 context=perform(client,'frozen-context','hia_context',context_args)['result']['context']
 state['context']=context;save()
 bad=perform(client,'deliberate-invalid-import','hia_candidate',{'catalog_sha256':catalog,'context':context,'request_key':'fresh-agent-20261106-deliberate-invalid-import','change':{'kind':'import','format':'hia-asm.v1','source':invalid_ref}},False)
 state['invalid_result']=bad;save()
 if bad.get('error',{}).get('details_artifact'):
  perform(client,'invalid-details-read','hia_read',{'catalog_sha256':catalog,'artifact':bad['error']['details_artifact'],'max_bytes':16384})
