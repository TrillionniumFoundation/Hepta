from pathlib import Path
import sys,json,hashlib,base64,os,datetime
root=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4/fresh-agent')
sys.path.insert(0,str(root))
from runner import RecordedMCP,command
s=json.loads((root/'state.json').read_text());b=json.loads((root/'branch-state.json').read_text())
out=root/'retained';out.mkdir(exist_ok=True)
refs={'adoption-receipt':s['adoption']['adoption_receipt'],'rollback-receipt':s['rollback']['rollback_receipt'],'stale-current-snapshot':s['stale_adoption']['error']['details_artifact'],'branch-evaluation-receipt':b['evaluation']['evaluation_receipt'],'branch-cost-ledger':b['evaluation']['full_cost_ledger'],'branch-plan-assumptions':b['plan_verification']['checks'][0]['assumptions_artifact'],'branch-plan-evidence':b['plan_verification']['checks'][0]['evidence_artifact'],'main-baseline-core':s['baseline_core'],'main-candidate-core':s['candidate_core'],'initial-baseline-core':s['initial_baseline_core'],'branch-core':b['core'],'main-baseline-native':s['baseline_emission']['native_artifact'],'main-candidate-native':s['candidate_emission']['native_artifact'],'initial-baseline-native':s['initial_baseline_emission']['native_artifact'],'initial-baseline-build-receipt':s['initial_baseline_emission']['build_receipt'],'initial-candidate-build-receipt':s['initial_candidate_emission']['build_receipt']}
inventory={}
session={'client_pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with RecordedMCP(command,timeout=180) as client:
 session['server_pid']=client.process.pid
 for label,ref in refs.items():
  cursor=None;content='';page=0;encoding=None
  while True:
   args={'catalog_sha256':s['catalog'],'artifact':ref,'max_bytes':65536}
   if cursor:args['cursor']=cursor
   r=client.call('hia_read',args)
   (out/(label+'-read-'+str(page)+'.json')).write_text(json.dumps(r,indent=2))
   if r.get('status')!='completed':raise RuntimeError(label+' did not complete')
   value=r['result'];content+=value['content'];encoding=value['encoding'];cursor=value.get('next_cursor')
   if not cursor:break
   page+=1
  if encoding=='utf8':data=content.encode('utf8');suffix='.json'
  elif encoding=='base64':data=base64.b64decode(content,validate=True);suffix='.so'
  elif encoding=='hex':data=bytes.fromhex(content);suffix='.so'
  else:raise RuntimeError('unhandled returned encoding '+encoding)
  digest=hashlib.sha256(data).hexdigest();assert digest==ref['sha256'],label
  path=out/(label+suffix);path.write_bytes(data)
  inventory[label]={'artifact':ref,'file':str(path),'byte_length':len(data),'sha256':digest,'encoding':encoding}
  print(json.dumps({'retained':label,'byte_length':len(data),'sha256':digest,'pages':page+1}),flush=True)
session.update(closed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),server_exit_code=client.process.returncode,context_manager_closed=True)
assert client.process.poll() is not None
(root/'final-mcp-session.json').write_text(json.dumps(session,indent=2))
(root/'retained-inventory.json').write_text(json.dumps(inventory,indent=2))
print(json.dumps({'final_mcp_session':session}),flush=True)
