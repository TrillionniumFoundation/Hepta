from pathlib import Path
import sys,json,hashlib,base64,struct,datetime
root=Path('/home/qq/hepta-hia-agent-native-20261106-f4e250f91ef4/fresh-agent')
sys.path.insert(0,str(root))
from runner import RecordedMCP,command
main=json.loads((root/'state.json').read_text());catalog=main['catalog'];profiles=main['profiles']
state={'catalog':catalog,'profiles':profiles,'budget':main['budget']}
def save(): (root/'branch-state.json').write_text(json.dumps(state,indent=2))
def perform(client,label,tool,args,required=True,visible=True):
 r=client.call(tool,args);(root/(label+'.json')).write_text(json.dumps(r,indent=2))
 print(json.dumps({'label':label,'result':r} if visible else {'label':label,'status':r.get('status')}),flush=True)
 if required and r.get('status')!='completed':raise RuntimeError(label+' did not complete')
 return r
def retain(client,label,text):
 (root/(label+'.txt')).write_text(text)
 return perform(client,'retain-'+label,'hia_artifact',{'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-retain-'+label,'artifact_profile':profiles['artifact'],'source':{'kind':'utf8','text':text}})['result']['artifact']
def read_content(client,label,ref):
 content='';cursor=None;page=0;encoding=None
 while True:
  args={'catalog_sha256':catalog,'artifact':ref,'max_bytes':65536}
  if cursor:args['cursor']=cursor
  r=perform(client,label+'-page-'+str(page),'hia_read',args,visible=False)['result']
  content+=r['content'];encoding=r['encoding'];cursor=r.get('next_cursor')
  if not cursor:break
  page+=1
 (root/(label+'-content.txt')).write_text(content)
 print(json.dumps({'label':label,'content_bytes':len(content.encode()),'encoding':encoding,'pages':page+1}),flush=True)
 return content,encoding
source='''hia-asm.v1 hepta.hia.program.v8 fresh_explicit_layout
exports(choose)
fn choose(x:u8) -> (u8) effects() entry(entry)
block entry(x:u8)
  cutoff:u8 = const() {"value":128}
  is_low:bool = compare.lt(x,cutoff)
  branch is_low low_side(x) high_side(x)
block low_side(low_x:u8)
  low_delta:u8 = const() {"value":3}
  low_result:u8 = int.add.wrap(low_x,low_delta)
  ret(low_result)
block high_side(high_x:u8)
  high_delta:u8 = const() {"value":5}
  high_result:u8 = int.sub.wrap(high_x,high_delta)
  ret(high_result)
end
'''
workload={'schema':'hepta.hia.agent.workload.v1','cases':[{'function':'choose','arguments':[x],'expected':{'status':'returned','values':[((x+3) if x<128 else (x-5))&255]}} for x in range(256)],'warmup_iterations':0,'repetitions':1}
with RecordedMCP(command,timeout=180) as client:
 sr=retain(client,'branch-source',source)
 wr=retain(client,'branch-workload',json.dumps(workload,separators=(',',':'),sort_keys=True))
 state['source']=sr;state['workload']=wr;save()
 cargs={'catalog_sha256':catalog,'request_key':'fresh-agent-20261106-branch-author-context','compiler_profile':profiles['compiler'],'target_profile':profiles['target'],'baseline_program':None,'workload':wr,'objective':main['artifacts']['objective'],'budget':main['budget']}
 author=perform(client,'branch-author-context','hia_context',cargs)['result']['context']
 core=perform(client,'branch-import','hia_candidate',{'catalog_sha256':catalog,'context':author,'request_key':'fresh-agent-20261106-branch-import','change':{'kind':'import','format':'hia-asm.v1','source':sr}})['result']['candidate']
 cargs.update(request_key='fresh-agent-20261106-branch-frozen-context',baseline_program=core)
 context=perform(client,'branch-frozen-context','hia_context',cargs)['result']['context']
 state['core']=core;state['context']=context;save()
 def common(label):return {'catalog_sha256':catalog,'context':context,'request_key':'fresh-agent-20261106-'+label}
 def verify(label,subject,claims):
  r=perform(client,label,'hia_verify',{**common(label),'candidate':core,'base_program':core,'validation_profile':profiles['validation'],'subject':subject,'claims':claims})['result']
  if any(check['status']!='proved' for check in r['checks']):raise RuntimeError(label+' has an unproved claim')
  return r
 cv=verify('branch-core-verify',{'kind':'core'},['core_admission','behavior_equivalence']);state['core_verification']=cv;save()
 plan={'schema':'hepta.hia.agent.block-layout.v1','core_sha256':core['sha256'],'block_order':{'choose':['entry','high_side','low_side']}}
 pr=retain(client,'branch-plan',json.dumps(plan,separators=(',',':'),sort_keys=True))
 pv=verify('branch-plan-verify',{'kind':'agent_machine_plan','backend_profile':profiles['backend'],'plan_profile':profiles['plan'],'plan':pr},['lowering_refinement'])
 state['plan']=pr;state['plan_verification']=pv;save()
 canonical=perform(client,'branch-canonical-emit','hia_emit',{**common('branch-canonical-emit'),'candidate':core,'backend_profile':profiles['backend'],'output_kind':'shared','codegen':{'kind':'canonical','lowering_profile':profiles['lowering']},'verification_receipts':[cv['verification_receipt']]})['result']
 planned=perform(client,'branch-plan-emit','hia_emit',{**common('branch-plan-emit'),'candidate':core,'backend_profile':profiles['backend'],'output_kind':'shared','codegen':{'kind':'agent_plan','plan_profile':profiles['plan'],'plan':pr,'verification_receipt':pv['verification_receipt']},'verification_receipts':[cv['verification_receipt'],pv['verification_receipt']]})['result']
 state['canonical_emission']=canonical;state['planned_emission']=planned;save()
 ce=verify('branch-canonical-encoding-verify',{'kind':'native_artifact','backend_profile':profiles['backend'],'native_artifact':canonical['native_artifact'],'build_receipt':canonical['build_receipt']},['encoding_check'])
 pe=verify('branch-plan-encoding-verify',{'kind':'native_artifact','backend_profile':profiles['backend'],'native_artifact':planned['native_artifact'],'build_receipt':planned['build_receipt']},['encoding_check'])
 state['canonical_encoding_verification']=ce;state['planned_encoding_verification']=pe;save()
 ev=perform(client,'branch-layout-evaluate','hia_evaluate',{**common('branch-layout-evaluate'),'baseline_artifact':canonical['native_artifact'],'candidate_artifact':planned['native_artifact'],'build_receipt':planned['build_receipt'],'verification_receipts':[cv['verification_receipt'],pv['verification_receipt'],pe['verification_receipt']]})['result']
 state['evaluation']=ev;save()
 content,encoding=read_content(client,'branch-measurements',ev['measurements']);assert encoding=='utf8';measure=json.loads(content)
 assert measure['planned_workload_complete'] and len(measure['observations'])==256
 for i,o in enumerate(measure['observations']):
  assert o['arguments']==[i]
  expected=(((i+3) if i<128 else (i-5))&255)
  for field in ['baseline_native','candidate_native','baseline_vm','candidate_vm']:
   assert o[field]['status']=='returned' and o[field]['values']==[expected]
  for field in ['baseline_native','candidate_native']:assert not o[field]['mismatch']
 binary_summaries={}
 for label,emission in [('branch-canonical',canonical),('branch-plan',planned)]:
  content,encoding=read_content(client,label+'-build-receipt',emission['build_receipt']);assert encoding=='utf8';build=json.loads(content)['native_build']
  content,encoding=read_content(client,label+'-native',emission['native_artifact'])
  if encoding=='base64':data=base64.b64decode(content,validate=True)
  elif encoding=='hex':data=bytes.fromhex(content)
  elif encoding=='utf8':data=content.encode()
  else:raise RuntimeError('unsupported returned binary encoding '+encoding)
  assert hashlib.sha256(data).hexdigest()==emission['native_artifact']['sha256']
  (root/(label+'.so')).write_bytes(data)
  assert data[:6]==b'\x7fELF\x02\x01'
  shoff=struct.unpack_from('<Q',data,40)[0];shentsize,shnum,shstrndx=struct.unpack_from('<HHH',data,58)
  headers=[struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*shentsize) for i in range(shnum)]
  name_header=headers[shstrndx];names=data[name_header[4]:name_header[4]+name_header[5]]
  text_sections=[h for h in headers if names[h[0]:].split(b'\0',1)[0]==b'.text']
  assert len(text_sections)==1
  header=text_sections[0];machine=data[header[4]:header[4]+header[5]]
  binary_summaries[label]={'artifact_bytes':len(data),'artifact_sha256':hashlib.sha256(data).hexdigest(),'elf_text_bytes':len(machine),'elf_text_sha256':hashlib.sha256(machine).hexdigest(),'build_machine_text_bytes':build['machine_text_bytes'],'build_machine_text_sha256':build['machine_text_sha256'],'native_measured_calls':measure['native_runs']['baseline' if label=='branch-canonical' else 'candidate']['normal']['report']['measured_calls']}
 assert binary_summaries['branch-canonical']['elf_text_sha256']!=binary_summaries['branch-plan']['elf_text_sha256']
 summary={'all_256_oracles_match_both_native_and_vm':True,'source_block_order':['entry','low_side','high_side'],'explicit_plan_block_order':['entry','high_side','low_side'],'different_actual_executable_text':True,'binary_summaries':binary_summaries,'whole_file_outcome':measure['outcome'],'whole_file_metric':{'baseline':measure['baseline_value'],'candidate':measure['candidate_value']},'plan_refinement_scope':pv['checks'][0]['domain']}
 state['summary']=summary;save();(root/'branch-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'branch_summary':summary}),flush=True)
(root/'STATUS.json').write_text(json.dumps({'step':'main_lifecycle_and_branch_plan_complete','blocker':None,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
