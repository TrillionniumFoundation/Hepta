use crate::api;
pub fn entrypoint(a:u32,b:u32,c:u32)->u64 {
    let (valid, count) = api::tiles(a as u32, b as u32);
    if valid {
        count as u64
    } else {
        0
    }
}