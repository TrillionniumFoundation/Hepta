use crate::api;
pub fn entrypoint(a: u32, b: u32, c: u32) -> u64 { api::gap(a, b) + c as u64 }