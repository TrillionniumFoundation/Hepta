pub fn gap(a:u32,b:u32)->u64 { a.abs_diff(b) as u64 }
