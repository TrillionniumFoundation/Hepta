pub fn total(a:u32,b:u32)->u64 { a.wrapping_add(b) as u64 }
