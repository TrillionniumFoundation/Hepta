pub fn product(a:u32,b:u32)->u64 { (a as u64) * (b as u64) }
