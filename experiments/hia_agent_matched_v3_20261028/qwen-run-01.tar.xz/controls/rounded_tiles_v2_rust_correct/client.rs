use crate::api;
pub fn entrypoint(a:u32,b:u32,c:u32)->u64 { let _ = c; let (valid,count) = api::tiles(a,b); if valid { count } else { u64::MAX } }
