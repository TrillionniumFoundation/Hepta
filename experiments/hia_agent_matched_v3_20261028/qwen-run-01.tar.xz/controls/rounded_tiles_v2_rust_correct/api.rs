pub fn tiles(a:u32,b:u32)->(bool,u64) { if b == 0 { (false,0) } else { (true,((a as u64) + (b as u64) - 1) / (b as u64)) } }
