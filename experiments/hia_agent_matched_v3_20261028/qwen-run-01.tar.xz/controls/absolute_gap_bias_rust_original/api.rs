pub fn gap(a:u32,b:u32)->u64 { a.wrapping_sub(b) as u64 }
