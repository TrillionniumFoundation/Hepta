#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
extern uint64_t entrypoint(uint32_t,uint32_t,uint32_t);
int main(void) { uint32_t x,y,z; setbuf(stdout,0); while(scanf("%" SCNu32 " %" SCNu32 " %" SCNu32,&x,&y,&z)==3) printf("%" PRIu64 "\n",entrypoint(x,y,z)); return 0; }
