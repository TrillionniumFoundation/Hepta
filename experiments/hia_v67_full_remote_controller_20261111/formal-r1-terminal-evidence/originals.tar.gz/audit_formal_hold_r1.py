"""Verify the original v67 r1 HOLD, without executing or retrying any product."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORIGINALS = ROOT / "formal-terminal-originals-r1"
DESTINATION = ROOT / "formal-r1-terminal-evidence"


def record(path: Path) -> dict:
    content = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(content),
            "sha256": hashlib.sha256(content).hexdigest()}


def read(name: str) -> dict:
    return json.loads((ORIGINALS / name).read_bytes())


def main() -> None:
    request = json.loads((ROOT / "request.frozen.json").read_bytes())
    raw_status = json.loads((ROOT / "h-full-status-r1.json").read_bytes())
    status = json.loads(raw_status["content"][0]["text"])
    guard = read("guardian.json")
    driver = read("preparation.json")
    prerequisite = read("prerequisite-preparation.json")
    intent = read("launch-intent.json")
    lifecycle = guard["lifecycle"]
    cleanup = lifecycle["cleanup"]
    assert status["job_id"] == "1a1cb8bb359-2564-bcc"
    assert status["state"] == "failed" and status["exit_code"] == 1
    assert status["timed_out"] is False and status["cancelled"] is False
    assert status["output_complete"] is True and status["output_durable"] is True
    assert status["terminal_publication_confirmed"] is True
    for stream in ("stdout", "stderr"):
        content = (ORIGINALS / f"h.{stream}.log").read_bytes()
        assert status["log_bytes"][stream]["stored"] == len(content)
        assert status["log_bytes"][stream]["seen"] == len(content)
        assert status["log_truncated"][stream] is False
        assert status["log_errors"][stream] is None
    assert guard["status"] == "HOLD" and guard["qualification"] is None
    assert guard["input_identity_preserved"] is True
    assert guard["source_identities_before"] == guard["source_identities_after"]
    assert lifecycle["status"] == "QUALIFICATION_FAILED"
    assert lifecycle["returncode"] == 1 and lifecycle["timed_out"] is False
    assert lifecycle["exit_observed_before_deadline"] is True
    assert lifecycle["interrupted_signals"] == [] and lifecycle["event_overflow"] is False
    assert not lifecycle.get("owner_error")
    assert cleanup["attempted"] is True and cleanup["complete"] is True
    assert cleanup["observed_echild"] is True and cleanup["leader_reaped"] is True
    assert cleanup["remaining_direct_children"] == [] and cleanup["errors"] == []
    assert cleanup["deadline_exceeded"] is False
    assert {event["kind"] for event in lifecycle["events"]} <= {
        "qualification_started", "owned_child_observed", "qualification_exit_observed",
        "owned_child_reaped"}
    assert len(lifecycle["events"]) == 4
    for path, expected in guard["logs"].items():
        assert record(ORIGINALS / Path(path).name)["sha256"] == expected
    expected_limits = {"controller_seconds": 10800, "source_materialization_seconds": 900,
                       "preparation_seconds": 900, "cold_seconds": 180, "cold_workers": 2,
                       "cold_phases": 38, "full_suite_seconds": 5400,
                       "minimum_free_bytes": 8 << 30, "minimum_free_inodes": 100000}
    assert intent["limits"] == driver["original_limits"] == expected_limits
    assert intent["request_sha256"] == record(ROOT / "request.frozen.json")["sha256"]
    assert intent["payload_sha256"] == record(ROOT / "payload.frozen.json")["sha256"]
    assert intent["control_files"] == request["control_files"]
    assert driver["head"] == request["source"]["commit"] == intent["head"]
    assert driver["tree"] == request["source"]["tree"] == intent["tree"]
    assert driver["status"] == "PREPARATION_HOLD"
    assert driver["qualification_executed"] is False
    assert driver.get("qualification_exec_requested") is not True
    assert len(driver["cold_source_manifest"]) == 682
    assert driver["cold_source_manifest"]["docs/HIA_SELFHOST_CORE_SUPPORT.json"] == request["source"]["contract_sha256"]
    labels = ("exact-source-materialization", "fresh-source-bound-prerequisites")
    assert [step["label"] for step in driver["steps"]] == list(labels)
    steps = []
    for index, label in enumerate(labels):
        owner = read(label + ".owner.json")
        assert owner == driver["steps"][index]["owner"]
        assert owner["timed_out"] is False and owner["workflow_seconds"] == 900
        assert owner["cleanup"]["complete"] is True
        assert owner["cleanup"]["signalled"] == owner["cleanup"]["errors"] == []
        for path, expected in owner["logs"].items():
            assert record(ORIGINALS / Path(path).name)["sha256"] == expected
        expected_status, expected_return = (("WORKFLOW_STEP_COMPLETED", 0), ("WORKFLOW_STEP_HOLD", 2))[index]
        assert owner["status"] == expected_status and owner["returncode"] == expected_return
        steps.append({"label": label, "status": owner["status"], "returncode": owner["returncode"],
                      "seconds": owner["seconds"], "original_receipt": record(ORIGINALS / (label + ".owner.json"))})
    materialization_stdout = read("exact-source-materialization.stdout.log")
    assert materialization_stdout["status"] == "PASS"
    assert materialization_stdout["commit"] == request["source"]["commit"]
    assert materialization_stdout["tree"] == request["source"]["tree"]
    assert prerequisite["status"] == "HOLD" and prerequisite["qualification_executed"] is False
    missing = {row["prerequisite"] for row in prerequisite["missing"]}
    assert missing == {"ndu_ranking", "ndu_raw", "ndu_dynamic", "v67_selected_inputs"}
    errors = {}
    for profile in ("ranking", "raw", "dynamic"):
        row = prerequisite["checks"]["ndu_" + profile]
        expected_path = "/home/qian-qi/hia-e26e-v64-prerequisites/targets/" + profile
        assert row["available"] is False
        assert row["error"] == "[Errno 2] No such file or directory: '" + expected_path + "'"
        errors[profile] = row
    for profile in ("recursive", "finite", "stream"):
        assert prerequisite["checks"]["ndu_" + profile]["available"] is True
    assert prerequisite["checks"]["ptrace"]["returncode"] == 0
    assert prerequisite["checks"]["sealed_memfd"]["returncode"] == 0
    assert prerequisite["v67_adapter"]["original_run_and_save_unchanged"] is True
    assert len(prerequisite["v67_adapter"]["current_crate_archives"]["archives"]) == 55
    result = {
        "schema": "hia.v67.formal-qualification-hold-audit.v1",
        "status": "PREPARATION_HOLD",
        "audit_status": "ORIGINAL_RECORDS_CONSISTENT_AND_HASH_VERIFIED",
        "job_id": status["job_id"], "host": "desktop", "root": intent["root"],
        "stable_key": intent["stable_key"], "head": driver["head"], "tree": driver["tree"],
        "preexecution_controller_commit": "02268d0b7adc444e398716cd75c07e05b036965a",
        "preexecution_controller_tree": "47cff5af9ef5ab4db8279d64974936199377d8b3",
        "steps": steps, "missing_prerequisites": prerequisite["missing"],
        "exact_rejections": errors,
        "failure_scope": "Existing fixture binary target paths absent during original source-bound prerequisite admission",
        "absence_cause": "UNKNOWN; no deletion or disappearance cause inferred",
        "h_exit_code": 1, "original_preparer_exit_code": 2, "timed_out": False,
        "outer_cleanup": cleanup, "original_input_identities_preserved": True,
        "original_input_identity_count": len(guard["source_identities_before"]),
        "actual_source_materialization_stdout": materialization_stdout,
        "source_materialization_full_receipt_remote_binding": driver["materialization_receipt"],
        "full_materialization_receipt_independently_transferred_in_this_audit": False,
        "source_consumer_clone_checks_were_enforced_by_frozen_driver": True,
        "frozen_driver_checked_cold_source_pins": 682,
        "original_limits": expected_limits,
        "v8_executed": False, "cold_executed": False, "full_retained_discovery_executed": False,
        "old_job_replayed": False, "whole_native_delivery_qualified": False,
        "original_report_records": [record(ORIGINALS / name) for name in (
            "guardian.json", "preparation.json", "prerequisite-preparation.json", "launch-intent.json",
            "child.stdout.log", "child.stderr.log", "h.stdout.log", "h.stderr.log")],
        "audit_program": record(Path(__file__))}
    DESTINATION.mkdir(exist_ok=False)
    with (DESTINATION / "AUDIT.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("status", "audit_status", "job_id", "steps", "exact_rejections")}, indent=2))


if __name__ == "__main__":
    main()
