"""Read-only remote-operation payload replay; no commands are dispatched."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "formal-terminal-originals-r1"


def recover_sdk(prefix: str) -> dict:
    raw = bytearray()
    index = 0
    identity = None
    while True:
        response = json.loads((ROOT / f"{prefix}-result-p{index}.json").read_bytes())
        page = json.loads(response["content"][0]["text"])
        current = (page["operation_id"], page["result_sha256"], page["total_bytes"])
        if identity is None:
            identity = current
        assert current == identity
        assert page["immutable_snapshot"] is True and page["offset"] == len(raw)
        chunk = base64.b64decode(page["data_base64"], validate=True)
        raw.extend(chunk)
        assert page["next_offset"] == len(raw)
        if page["eof"]:
            break
        index += 1
    assert len(raw) == page["total_bytes"]
    assert hashlib.sha256(raw).hexdigest() == page["result_sha256"]
    target = OUT / f"{prefix}-native-sdk.json"
    if target.exists():
        assert target.read_bytes() == raw
    else:
        with target.open("xb") as stream:
            stream.write(raw)
    sdk = json.loads(raw)
    assert sdk.get("isError") is False
    return json.loads(sdk["content"][0]["text"])


def recover_file(label: str, info_label: str, basename: str) -> dict:
    info = json.loads((OUT / f"{info_label}-file-info.json").read_bytes())
    raw = bytearray()
    offsets = (0, 65536)
    for offset in offsets:
        result = recover_sdk(f"h-full-{label}-binary-{offset}-r1")
        assert result["path"] == info["path"]
        assert result["version"] == info["version"]
        assert result["size"] == info["size"]
        assert result["offset"] == len(raw) == offset
        chunk = base64.b64decode(result["data_base64"], validate=True)
        assert hashlib.sha256(chunk).hexdigest() == result["chunk_sha256"]
        raw.extend(chunk)
        assert result["next_offset"] == len(raw)
        assert result["eof"] is (offset == offsets[-1])
    assert len(raw) == info["size"]
    assert hashlib.sha256(raw).hexdigest() == info["sha256"]
    target = OUT / basename
    with target.open("xb") as stream:
        stream.write(raw)
    value = json.loads(raw)
    return {"path": str(target), "bytes": len(raw), "sha256": info["sha256"],
            "remote_path": info["path"], "version": info["version"], "value": value}


def main() -> None:
    prerequisite = recover_file("prerequisite-report", "h-full-prerequisite-report-file-info-r1",
                                "prerequisite-preparation.json")
    preparation = recover_file("preparation-report", "h-full-preparation-file-info-r1",
                               "preparation.json")
    report = prerequisite.pop("value")
    driver = preparation.pop("value")
    result = {"schema": "hia.v67.formal-original-report-readback.v1",
              "status": "ORIGINAL_PREPARATION_HOLD_PRESERVED",
              "files": [prerequisite, preparation],
              "prerequisite_status": report.get("status"),
              "missing": report.get("missing"),
              "rejected_checks": {k: v for k, v in report["checks"].items()
                                  if v.get("available") is False},
              "driver_status": driver.get("status"),
              "driver_error_type": driver.get("error_type"),
              "driver_error": driver.get("error"),
              "qualification_executed": driver.get("qualification_executed"),
              "remote_command_dispatched_by_this_reader": False}
    target = OUT / "report-readback.json"
    with target.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
