
/home/qian-qi/work/hia-evidence-20261103/empty-reduction-observation-22de2bc-r1/linear/hia_empty_candidate.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	48 85 ff             	test   %rdi,%rdi
    11b7:	74 40                	je     11f9 <calculate+0x49>
    11b9:	89 f5                	mov    %esi,%ebp
    11bb:	48 89 fb             	mov    %rdi,%rbx
    11be:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
    11c5:	01 01 01 
    11c8:	48 39 c7             	cmp    %rax,%rdi
    11cb:	77 34                	ja     1201 <calculate+0x51>
    11cd:	48 89 df             	mov    %rbx,%rdi
    11d0:	e8 7b fe ff ff       	call   1050 <__wrap_malloc@plt>
    11d5:	48 85 c0             	test   %rax,%rax
    11d8:	0f 84 2a 01 00 00    	je     1308 <calculate+0x158>
    11de:	48 b9 f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rcx
    11e5:	ff ff 01 
    11e8:	48 83 fb 03          	cmp    $0x3,%rbx
    11ec:	0f 87 21 01 00 00    	ja     1313 <calculate+0x163>
    11f2:	31 d2                	xor    %edx,%edx
    11f4:	e9 d6 01 00 00       	jmp    13cf <calculate+0x21f>
    11f9:	45 31 f6             	xor    %r14d,%r14d
    11fc:	e9 dc 02 00 00       	jmp    14dd <calculate+0x32d>
    1201:	48 85 db             	test   %rbx,%rbx
    1204:	78 28                	js     122e <calculate+0x7e>
    1206:	48 89 df             	mov    %rbx,%rdi
    1209:	e8 42 fe ff ff       	call   1050 <__wrap_malloc@plt>
    120e:	48 85 c0             	test   %rax,%rax
    1211:	74 1b                	je     122e <calculate+0x7e>
    1213:	b1 01                	mov    $0x1,%cl
    1215:	f6 c1 01             	test   $0x1,%cl
    1218:	75 1d                	jne    1237 <calculate+0x87>
    121a:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1220:	48 85 c0             	test   %rax,%rax
    1223:	0f 85 ac 02 00 00    	jne    14d5 <calculate+0x325>
    1229:	e9 af 02 00 00       	jmp    14dd <calculate+0x32d>
    122e:	31 c0                	xor    %eax,%eax
    1230:	31 c9                	xor    %ecx,%ecx
    1232:	f6 c1 01             	test   $0x1,%cl
    1235:	74 e3                	je     121a <calculate+0x6a>
    1237:	48 89 d9             	mov    %rbx,%rcx
    123a:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
    123e:	66 0f 6e c5          	movd   %ebp,%xmm0
    1242:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1246:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    124b:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1250:	66 0f 6f 0d a8 1d 00 	movdqa 0x1da8(%rip),%xmm1        # 3000 <_fini+0xdd8>
    1257:	00 
    1258:	31 d2                	xor    %edx,%edx
    125a:	66 0f 6f 15 ae 1d 00 	movdqa 0x1dae(%rip),%xmm2        # 3010 <_fini+0xde8>
    1261:	00 
    1262:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1269:	1f 84 00 00 00 00 00 
    1270:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1274:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1278:	f3 0f 7f 1c 10       	movdqu %xmm3,(%rax,%rdx,1)
    127d:	48 83 c2 10          	add    $0x10,%rdx
    1281:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1285:	48 39 d1             	cmp    %rdx,%rcx
    1288:	75 e6                	jne    1270 <calculate+0xc0>
    128a:	48 39 cb             	cmp    %rcx,%rbx
    128d:	0f 84 1c 02 00 00    	je     14af <calculate+0x2ff>
    1293:	f6 c3 0c             	test   $0xc,%bl
    1296:	0f 84 f5 01 00 00    	je     1491 <calculate+0x2e1>
    129c:	48 89 da             	mov    %rbx,%rdx
    129f:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    12a3:	66 0f 6e c1          	movd   %ecx,%xmm0
    12a7:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    12ab:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    12b0:	66 0f eb 05 68 1d 00 	por    0x1d68(%rip),%xmm0        # 3020 <_fini+0xdf8>
    12b7:	00 
    12b8:	40 0f b6 f5          	movzbl %bpl,%esi
    12bc:	66 0f 6e ce          	movd   %esi,%xmm1
    12c0:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    12c4:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    12c9:	66 0f 6f 15 5f 1d 00 	movdqa 0x1d5f(%rip),%xmm2        # 3030 <_fini+0xe08>
    12d0:	00 
    12d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    12d8:	0f 1f 84 00 00 00 00 
    12df:	00 
    12e0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    12e4:	66 0f fc d9          	paddb  %xmm1,%xmm3
    12e8:	66 0f 7e 1c 08       	movd   %xmm3,(%rax,%rcx,1)
    12ed:	48 83 c1 04          	add    $0x4,%rcx
    12f1:	66 0f fc c2          	paddb  %xmm2,%xmm0
    12f5:	48 39 ca             	cmp    %rcx,%rdx
    12f8:	75 e6                	jne    12e0 <calculate+0x130>
    12fa:	48 39 d3             	cmp    %rdx,%rbx
    12fd:	0f 85 91 01 00 00    	jne    1494 <calculate+0x2e4>
    1303:	e9 a7 01 00 00       	jmp    14af <calculate+0x2ff>
    1308:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    130e:	e9 ca 01 00 00       	jmp    14dd <calculate+0x32d>
    1313:	40 0f b6 f5          	movzbl %bpl,%esi
    1317:	48 83 fb 10          	cmp    $0x10,%rbx
    131b:	73 04                	jae    1321 <calculate+0x171>
    131d:	31 d2                	xor    %edx,%edx
    131f:	eb 57                	jmp    1378 <calculate+0x1c8>
    1321:	48 89 da             	mov    %rbx,%rdx
    1324:	48 21 ca             	and    %rcx,%rdx
    1327:	66 0f 6e c6          	movd   %esi,%xmm0
    132b:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    132f:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1334:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1339:	66 0f 6f 0d bf 1c 00 	movdqa 0x1cbf(%rip),%xmm1        # 3000 <_fini+0xdd8>
    1340:	00 
    1341:	31 ff                	xor    %edi,%edi
    1343:	66 0f 6f 15 c5 1c 00 	movdqa 0x1cc5(%rip),%xmm2        # 3010 <_fini+0xde8>
    134a:	00 
    134b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1350:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1354:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1358:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
    135d:	48 83 c7 10          	add    $0x10,%rdi
    1361:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1365:	48 39 fa             	cmp    %rdi,%rdx
    1368:	75 e6                	jne    1350 <calculate+0x1a0>
    136a:	48 39 d3             	cmp    %rdx,%rbx
    136d:	0f 84 7c 00 00 00    	je     13ef <calculate+0x23f>
    1373:	f6 c3 0c             	test   $0xc,%bl
    1376:	74 57                	je     13cf <calculate+0x21f>
    1378:	48 89 d7             	mov    %rdx,%rdi
    137b:	48 8d 51 0c          	lea    0xc(%rcx),%rdx
    137f:	48 21 da             	and    %rbx,%rdx
    1382:	66 0f 6e c7          	movd   %edi,%xmm0
    1386:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    138a:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    138f:	66 0f eb 05 89 1c 00 	por    0x1c89(%rip),%xmm0        # 3020 <_fini+0xdf8>
    1396:	00 
    1397:	66 0f 6e ce          	movd   %esi,%xmm1
    139b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    139f:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    13a4:	66 0f 6f 15 84 1c 00 	movdqa 0x1c84(%rip),%xmm2        # 3030 <_fini+0xe08>
    13ab:	00 
    13ac:	0f 1f 40 00          	nopl   0x0(%rax)
    13b0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    13b4:	66 0f fc d9          	paddb  %xmm1,%xmm3
    13b8:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
    13bd:	48 83 c7 04          	add    $0x4,%rdi
    13c1:	66 0f fc c2          	paddb  %xmm2,%xmm0
    13c5:	48 39 fa             	cmp    %rdi,%rdx
    13c8:	75 e6                	jne    13b0 <calculate+0x200>
    13ca:	48 39 d3             	cmp    %rdx,%rbx
    13cd:	74 20                	je     13ef <calculate+0x23f>
    13cf:	89 ee                	mov    %ebp,%esi
    13d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    13d8:	0f 1f 84 00 00 00 00 
    13df:	00 
    13e0:	8d 3c 16             	lea    (%rsi,%rdx,1),%edi
    13e3:	40 88 3c 10          	mov    %dil,(%rax,%rdx,1)
    13e7:	48 ff c2             	inc    %rdx
    13ea:	48 39 d3             	cmp    %rdx,%rbx
    13ed:	75 f1                	jne    13e0 <calculate+0x230>
    13ef:	48 8d 73 ff          	lea    -0x1(%rbx),%rsi
    13f3:	89 da                	mov    %ebx,%edx
    13f5:	83 e2 07             	and    $0x7,%edx
    13f8:	48 83 fe 07          	cmp    $0x7,%rsi
    13fc:	73 07                	jae    1405 <calculate+0x255>
    13fe:	31 c9                	xor    %ecx,%ecx
    1400:	45 31 f6             	xor    %r14d,%r14d
    1403:	eb 65                	jmp    146a <calculate+0x2ba>
    1405:	48 83 c1 08          	add    $0x8,%rcx
    1409:	48 21 cb             	and    %rcx,%rbx
    140c:	31 c9                	xor    %ecx,%ecx
    140e:	45 31 f6             	xor    %r14d,%r14d
    1411:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1418:	0f 1f 84 00 00 00 00 
    141f:	00 
    1420:	0f b6 34 08          	movzbl (%rax,%rcx,1),%esi
    1424:	4c 01 f6             	add    %r14,%rsi
    1427:	0f b6 7c 08 01       	movzbl 0x1(%rax,%rcx,1),%edi
    142c:	44 0f b6 44 08 02    	movzbl 0x2(%rax,%rcx,1),%r8d
    1432:	49 01 f8             	add    %rdi,%r8
    1435:	49 01 f0             	add    %rsi,%r8
    1438:	0f b6 74 08 03       	movzbl 0x3(%rax,%rcx,1),%esi
    143d:	0f b6 7c 08 04       	movzbl 0x4(%rax,%rcx,1),%edi
    1442:	48 01 f7             	add    %rsi,%rdi
    1445:	0f b6 74 08 05       	movzbl 0x5(%rax,%rcx,1),%esi
    144a:	48 01 fe             	add    %rdi,%rsi
    144d:	4c 01 c6             	add    %r8,%rsi
    1450:	0f b6 7c 08 06       	movzbl 0x6(%rax,%rcx,1),%edi
    1455:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
    145b:	49 01 fe             	add    %rdi,%r14
    145e:	49 01 f6             	add    %rsi,%r14
    1461:	48 83 c1 08          	add    $0x8,%rcx
    1465:	48 39 cb             	cmp    %rcx,%rbx
    1468:	75 b6                	jne    1420 <calculate+0x270>
    146a:	48 85 d2             	test   %rdx,%rdx
    146d:	74 66                	je     14d5 <calculate+0x325>
    146f:	48 89 c6             	mov    %rax,%rsi
    1472:	48 01 ce             	add    %rcx,%rsi
    1475:	31 c9                	xor    %ecx,%ecx
    1477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    147e:	00 00 
    1480:	0f b6 3c 0e          	movzbl (%rsi,%rcx,1),%edi
    1484:	49 01 fe             	add    %rdi,%r14
    1487:	48 ff c1             	inc    %rcx
    148a:	48 39 ca             	cmp    %rcx,%rdx
    148d:	75 f1                	jne    1480 <calculate+0x2d0>
    148f:	eb 44                	jmp    14d5 <calculate+0x325>
    1491:	48 89 ca             	mov    %rcx,%rdx
    1494:	89 e9                	mov    %ebp,%ecx
    1496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    149d:	00 00 00 
    14a0:	8d 34 11             	lea    (%rcx,%rdx,1),%esi
    14a3:	40 88 34 10          	mov    %sil,(%rax,%rdx,1)
    14a7:	48 ff c2             	inc    %rdx
    14aa:	48 39 d3             	cmp    %rdx,%rbx
    14ad:	75 f1                	jne    14a0 <calculate+0x2f0>
    14af:	31 c9                	xor    %ecx,%ecx
    14b1:	45 31 f6             	xor    %r14d,%r14d
    14b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    14bb:	00 00 00 00 00 
    14c0:	4c 89 f2             	mov    %r14,%rdx
    14c3:	44 0f b6 34 08       	movzbl (%rax,%rcx,1),%r14d
    14c8:	49 01 d6             	add    %rdx,%r14
    14cb:	72 18                	jb     14e5 <calculate+0x335>
    14cd:	48 ff c1             	inc    %rcx
    14d0:	48 39 cb             	cmp    %rcx,%rbx
    14d3:	75 eb                	jne    14c0 <calculate+0x310>
    14d5:	48 89 c7             	mov    %rax,%rdi
    14d8:	e8 b3 fb ff ff       	call   1090 <__wrap_free@plt>
    14dd:	4c 89 f0             	mov    %r14,%rax
    14e0:	5b                   	pop    %rbx
    14e1:	41 5e                	pop    %r14
    14e3:	5d                   	pop    %rbp
    14e4:	c3                   	ret
    14e5:	e8 56 fb ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
