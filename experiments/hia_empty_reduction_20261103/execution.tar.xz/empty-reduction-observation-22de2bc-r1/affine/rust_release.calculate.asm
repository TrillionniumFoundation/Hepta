
/home/qian-qi/work/hia-evidence-20261103/empty-reduction-observation-22de2bc-r1/affine/rust_release.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011c0 <calculate>:
    11c0:	48 85 ff             	test   %rdi,%rdi
    11c3:	75 03                	jne    11c8 <calculate+0x8>
    11c5:	31 c0                	xor    %eax,%eax
    11c7:	c3                   	ret
    11c8:	55                   	push   %rbp
    11c9:	41 57                	push   %r15
    11cb:	41 56                	push   %r14
    11cd:	53                   	push   %rbx
    11ce:	48 83 ec 18          	sub    $0x18,%rsp
    11d2:	89 f5                	mov    %esi,%ebp
    11d4:	48 89 e0             	mov    %rsp,%rax
    11d7:	ba 01 00 00 00       	mov    $0x1,%edx
    11dc:	48 89 f9             	mov    %rdi,%rcx
    11df:	48 89 c7             	mov    %rax,%rdi
    11e2:	31 f6                	xor    %esi,%esi
    11e4:	49 89 cf             	mov    %rcx,%r15
    11e7:	e8 a4 fe ff ff       	call   1090 <_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17hf5efdbdf36ea2808E>
    11ec:	80 3c 24 00          	cmpb   $0x0,(%rsp)
    11f0:	74 0a                	je     11fc <calculate+0x3c>
    11f2:	b8 e9 03 00 00       	mov    $0x3e9,%eax
    11f7:	e9 62 02 00 00       	jmp    145e <calculate+0x29e>
    11fc:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    1201:	49 83 ff 01          	cmp    $0x1,%r15
    1205:	75 11                	jne    1218 <calculate+0x58>
    1207:	c6 03 00             	movb   $0x0,(%rbx)
    120a:	48 8d 4b 01          	lea    0x1(%rbx),%rcx
    120e:	45 31 f6             	xor    %r14d,%r14d
    1211:	b8 01 00 00 00       	mov    $0x1,%eax
    1216:	eb 25                	jmp    123d <calculate+0x7d>
    1218:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
    121c:	45 31 f6             	xor    %r14d,%r14d
    121f:	48 89 df             	mov    %rbx,%rdi
    1222:	31 f6                	xor    %esi,%esi
    1224:	ff 15 96 3d 00 00    	call   *0x3d96(%rip)        # 4fc0 <memset@GLIBC_2.2.5>
    122a:	4c 89 f8             	mov    %r15,%rax
    122d:	42 c6 44 3b ff 00    	movb   $0x0,-0x1(%rbx,%r15,1)
    1233:	4a 8d 0c 3b          	lea    (%rbx,%r15,1),%rcx
    1237:	49 83 ff 04          	cmp    $0x4,%r15
    123b:	73 39                	jae    1276 <calculate+0xb6>
    123d:	48 89 df             	mov    %rbx,%rdi
    1240:	89 ea                	mov    %ebp,%edx
    1242:	44 0f af f2          	imul   %edx,%r14d
    1246:	41 80 c6 11          	add    $0x11,%r14b
    124a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1250:	44 88 37             	mov    %r14b,(%rdi)
    1253:	48 ff c7             	inc    %rdi
    1256:	41 00 d6             	add    %dl,%r14b
    1259:	48 39 cf             	cmp    %rcx,%rdi
    125c:	75 f2                	jne    1250 <calculate+0x90>
    125e:	89 c1                	mov    %eax,%ecx
    1260:	83 e1 07             	and    $0x7,%ecx
    1263:	48 83 f8 08          	cmp    $0x8,%rax
    1267:	0f 83 5f 01 00 00    	jae    13cc <calculate+0x20c>
    126d:	31 c0                	xor    %eax,%eax
    126f:	31 d2                	xor    %edx,%edx
    1271:	e9 b9 01 00 00       	jmp    142f <calculate+0x26f>
    1276:	89 ea                	mov    %ebp,%edx
    1278:	66 0f 6e c5          	movd   %ebp,%xmm0
    127c:	48 83 f8 10          	cmp    $0x10,%rax
    1280:	73 08                	jae    128a <calculate+0xca>
    1282:	45 31 f6             	xor    %r14d,%r14d
    1285:	e9 e7 01 00 00       	jmp    1471 <calculate+0x2b1>
    128a:	49 89 c6             	mov    %rax,%r14
    128d:	49 83 e6 f0          	and    $0xfffffffffffffff0,%r14
    1291:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    1296:	66 0f 6f 15 62 1d 00 	movdqa 0x1d62(%rip),%xmm2        # 3000 <_fini+0xda8>
    129d:	00 
    129e:	66 0f 6f 1d 6a 1d 00 	movdqa 0x1d6a(%rip),%xmm3        # 3010 <_fini+0xdb8>
    12a5:	00 
    12a6:	66 0f 6f 25 72 1d 00 	movdqa 0x1d72(%rip),%xmm4        # 3020 <_fini+0xdc8>
    12ad:	00 
    12ae:	66 0f 6f 2d 7a 1d 00 	movdqa 0x1d7a(%rip),%xmm5        # 3030 <_fini+0xdd8>
    12b5:	00 
    12b6:	31 f6                	xor    %esi,%esi
    12b8:	66 0f 70 f1 f5       	pshufd $0xf5,%xmm1,%xmm6
    12bd:	66 0f 6f 3d 7b 1d 00 	movdqa 0x1d7b(%rip),%xmm7        # 3040 <_fini+0xde8>
    12c4:	00 
    12c5:	66 44 0f 6f 05 82 1d 	movdqa 0x1d82(%rip),%xmm8        # 3050 <_fini+0xdf8>
    12cc:	00 00 
    12ce:	66 44 0f 6f 0d 89 1d 	movdqa 0x1d89(%rip),%xmm9        # 3060 <_fini+0xe08>
    12d5:	00 00 
    12d7:	66 44 0f 6f d2       	movdqa %xmm2,%xmm10
    12dc:	66 44 0f f4 d1       	pmuludq %xmm1,%xmm10
    12e1:	66 45 0f 70 d2 e8    	pshufd $0xe8,%xmm10,%xmm10
    12e7:	66 44 0f 70 da f5    	pshufd $0xf5,%xmm2,%xmm11
    12ed:	66 44 0f f4 de       	pmuludq %xmm6,%xmm11
    12f2:	66 45 0f 70 db e8    	pshufd $0xe8,%xmm11,%xmm11
    12f8:	66 45 0f 62 d3       	punpckldq %xmm11,%xmm10
    12fd:	66 44 0f 6f db       	movdqa %xmm3,%xmm11
    1302:	66 44 0f f4 d9       	pmuludq %xmm1,%xmm11
    1307:	66 45 0f 70 db e8    	pshufd $0xe8,%xmm11,%xmm11
    130d:	66 44 0f 70 e3 f5    	pshufd $0xf5,%xmm3,%xmm12
    1313:	66 44 0f f4 e6       	pmuludq %xmm6,%xmm12
    1318:	66 45 0f 70 e4 e8    	pshufd $0xe8,%xmm12,%xmm12
    131e:	66 45 0f 62 dc       	punpckldq %xmm12,%xmm11
    1323:	66 44 0f 6f e4       	movdqa %xmm4,%xmm12
    1328:	66 44 0f f4 e1       	pmuludq %xmm1,%xmm12
    132d:	66 45 0f 70 e4 e8    	pshufd $0xe8,%xmm12,%xmm12
    1333:	66 44 0f 70 ec f5    	pshufd $0xf5,%xmm4,%xmm13
    1339:	66 44 0f f4 ee       	pmuludq %xmm6,%xmm13
    133e:	66 45 0f 70 ed e8    	pshufd $0xe8,%xmm13,%xmm13
    1344:	66 45 0f 62 e5       	punpckldq %xmm13,%xmm12
    1349:	66 44 0f 6f ed       	movdqa %xmm5,%xmm13
    134e:	66 44 0f f4 e9       	pmuludq %xmm1,%xmm13
    1353:	66 45 0f 70 ed e8    	pshufd $0xe8,%xmm13,%xmm13
    1359:	66 44 0f 70 f5 f5    	pshufd $0xf5,%xmm5,%xmm14
    135f:	66 44 0f f4 f6       	pmuludq %xmm6,%xmm14
    1364:	66 45 0f 70 f6 e8    	pshufd $0xe8,%xmm14,%xmm14
    136a:	66 45 0f 62 ee       	punpckldq %xmm14,%xmm13
    136f:	66 44 0f db ef       	pand   %xmm7,%xmm13
    1374:	66 44 0f db e7       	pand   %xmm7,%xmm12
    1379:	66 45 0f 67 ec       	packuswb %xmm12,%xmm13
    137e:	66 44 0f db df       	pand   %xmm7,%xmm11
    1383:	66 44 0f db d7       	pand   %xmm7,%xmm10
    1388:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    138d:	66 45 0f 67 eb       	packuswb %xmm11,%xmm13
    1392:	66 45 0f fc e8       	paddb  %xmm8,%xmm13
    1397:	f3 44 0f 7f 2c 33    	movdqu %xmm13,(%rbx,%rsi,1)
    139d:	48 83 c6 10          	add    $0x10,%rsi
    13a1:	66 41 0f fe e9       	paddd  %xmm9,%xmm5
    13a6:	66 41 0f fe e1       	paddd  %xmm9,%xmm4
    13ab:	66 41 0f fe d9       	paddd  %xmm9,%xmm3
    13b0:	66 41 0f fe d1       	paddd  %xmm9,%xmm2
    13b5:	49 39 f6             	cmp    %rsi,%r14
    13b8:	0f 85 19 ff ff ff    	jne    12d7 <calculate+0x117>
    13be:	4c 39 f0             	cmp    %r14,%rax
    13c1:	0f 85 a2 00 00 00    	jne    1469 <calculate+0x2a9>
    13c7:	89 c1                	mov    %eax,%ecx
    13c9:	83 e1 07             	and    $0x7,%ecx
    13cc:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    13d0:	31 d2                	xor    %edx,%edx
    13d2:	31 f6                	xor    %esi,%esi
    13d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    13db:	00 00 00 00 00 
    13e0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
    13e4:	48 01 d7             	add    %rdx,%rdi
    13e7:	0f b6 54 33 01       	movzbl 0x1(%rbx,%rsi,1),%edx
    13ec:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
    13f2:	49 01 d0             	add    %rdx,%r8
    13f5:	49 01 f8             	add    %rdi,%r8
    13f8:	0f b6 54 33 03       	movzbl 0x3(%rbx,%rsi,1),%edx
    13fd:	0f b6 7c 33 04       	movzbl 0x4(%rbx,%rsi,1),%edi
    1402:	48 01 d7             	add    %rdx,%rdi
    1405:	44 0f b6 4c 33 05    	movzbl 0x5(%rbx,%rsi,1),%r9d
    140b:	49 01 f9             	add    %rdi,%r9
    140e:	4d 01 c1             	add    %r8,%r9
    1411:	0f b6 7c 33 06       	movzbl 0x6(%rbx,%rsi,1),%edi
    1416:	0f b6 54 33 07       	movzbl 0x7(%rbx,%rsi,1),%edx
    141b:	48 01 fa             	add    %rdi,%rdx
    141e:	4c 01 ca             	add    %r9,%rdx
    1421:	48 83 c6 08          	add    $0x8,%rsi
    1425:	48 39 f0             	cmp    %rsi,%rax
    1428:	75 b6                	jne    13e0 <calculate+0x220>
    142a:	48 85 c9             	test   %rcx,%rcx
    142d:	74 20                	je     144f <calculate+0x28f>
    142f:	48 01 d8             	add    %rbx,%rax
    1432:	31 f6                	xor    %esi,%esi
    1434:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    143b:	00 00 00 00 00 
    1440:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
    1444:	48 01 fa             	add    %rdi,%rdx
    1447:	48 ff c6             	inc    %rsi
    144a:	48 39 f1             	cmp    %rsi,%rcx
    144d:	75 f1                	jne    1440 <calculate+0x280>
    144f:	48 89 df             	mov    %rbx,%rdi
    1452:	48 89 d3             	mov    %rdx,%rbx
    1455:	ff 15 6d 3b 00 00    	call   *0x3b6d(%rip)        # 4fc8 <_GLOBAL_OFFSET_TABLE_+0x58>
    145b:	48 89 d8             	mov    %rbx,%rax
    145e:	48 83 c4 18          	add    $0x18,%rsp
    1462:	5b                   	pop    %rbx
    1463:	41 5e                	pop    %r14
    1465:	41 5f                	pop    %r15
    1467:	5d                   	pop    %rbp
    1468:	c3                   	ret
    1469:	a8 0c                	test   $0xc,%al
    146b:	0f 84 92 00 00 00    	je     1503 <calculate+0x343>
    1471:	48 89 c6             	mov    %rax,%rsi
    1474:	48 83 e6 fc          	and    $0xfffffffffffffffc,%rsi
    1478:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    147d:	66 41 0f 6e ce       	movd   %r14d,%xmm1
    1482:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
    1487:	66 0f fe 0d a1 1b 00 	paddd  0x1ba1(%rip),%xmm1        # 3030 <_fini+0xdd8>
    148e:	00 
    148f:	66 0f 70 d0 f5       	pshufd $0xf5,%xmm0,%xmm2
    1494:	66 0f 6f 1d a4 1b 00 	movdqa 0x1ba4(%rip),%xmm3        # 3040 <_fini+0xde8>
    149b:	00 
    149c:	66 0f 6f 25 cc 1b 00 	movdqa 0x1bcc(%rip),%xmm4        # 3070 <_fini+0xe18>
    14a3:	00 
    14a4:	66 0f 6f 2d d4 1b 00 	movdqa 0x1bd4(%rip),%xmm5        # 3080 <_fini+0xe28>
    14ab:	00 
    14ac:	66 0f 6f f1          	movdqa %xmm1,%xmm6
    14b0:	66 0f f4 f0          	pmuludq %xmm0,%xmm6
    14b4:	66 0f 70 f6 e8       	pshufd $0xe8,%xmm6,%xmm6
    14b9:	66 0f 70 f9 f5       	pshufd $0xf5,%xmm1,%xmm7
    14be:	66 0f f4 fa          	pmuludq %xmm2,%xmm7
    14c2:	66 0f 70 ff e8       	pshufd $0xe8,%xmm7,%xmm7
    14c7:	66 0f 62 f7          	punpckldq %xmm7,%xmm6
    14cb:	66 0f db f3          	pand   %xmm3,%xmm6
    14cf:	66 0f 67 f6          	packuswb %xmm6,%xmm6
    14d3:	66 0f 67 f6          	packuswb %xmm6,%xmm6
    14d7:	66 0f fc f4          	paddb  %xmm4,%xmm6
    14db:	66 42 0f 7e 34 33    	movd   %xmm6,(%rbx,%r14,1)
    14e1:	49 83 c6 04          	add    $0x4,%r14
    14e5:	66 0f fe cd          	paddd  %xmm5,%xmm1
    14e9:	4c 39 f6             	cmp    %r14,%rsi
    14ec:	75 be                	jne    14ac <calculate+0x2ec>
    14ee:	48 39 f0             	cmp    %rsi,%rax
    14f1:	0f 84 67 fd ff ff    	je     125e <calculate+0x9e>
    14f7:	48 8d 3c 33          	lea    (%rbx,%rsi,1),%rdi
    14fb:	41 89 f6             	mov    %esi,%r14d
    14fe:	e9 3f fd ff ff       	jmp    1242 <calculate+0x82>
    1503:	4c 89 f7             	mov    %r14,%rdi
    1506:	48 01 df             	add    %rbx,%rdi
    1509:	e9 34 fd ff ff       	jmp    1242 <calculate+0x82>

Disassembly of section .fini:
