; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  call void @free(ptr %t6) nobuiltin
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t26, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i64 %p_4_4 to i32
  %t17 = mul i32 %t16, %p_4_1
  %t18 = add i32 %t17, 17
  %t19 = trunc i32 %t18 to i8
  %t20 = extractvalue %hia.buffer %p_4_2, 0
  %t21 = extractvalue %hia.buffer %p_4_2, 1
  %t22 = icmp ult i64 %p_4_4, %t21
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  %t24 = getelementptr i8, ptr %t20, i64 %p_4_4
  store i8 %t19, ptr %t24, align 1
  %t25 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t26 = extractvalue { i64, i1 } %t25, 0
  %t27 = extractvalue { i64, i1 } %t25, 1
  %t28 = xor i1 %t27, true
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t39, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t44, %edge_9 ]
  %t30 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t30, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t31 = extractvalue %hia.buffer %p_7_2, 0
  %t32 = extractvalue %hia.buffer %p_7_2, 1
  %t33 = icmp ult i64 %p_7_5, %t32
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = getelementptr i8, ptr %t31, i64 %p_7_5
  %t36 = load i8, ptr %t35, align 1
  %t37 = zext i8 %t36 to i64
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_3, i64 %t37)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_5, i64 1)
  %t44 = extractvalue { i64, i1 } %t43, 0
  %t45 = extractvalue { i64, i1 } %t43, 1
  %t46 = xor i1 %t45, true
  br i1 %t46, label %ok_47, label %trap_47
trap_47:
  call void @abort()
  unreachable
ok_47:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t48 = extractvalue %hia.buffer %p_8_2, 0
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %drop_nonnull_50, label %drop_after_50
drop_nonnull_50:
  call void @free(ptr %t48) nobuiltin
  br label %drop_after_50
drop_after_50:
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
