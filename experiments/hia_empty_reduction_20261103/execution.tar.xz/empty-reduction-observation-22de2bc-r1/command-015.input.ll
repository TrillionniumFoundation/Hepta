; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ule i64 %p_0_0, 72340172838076673
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 %p_1_0, i1 false)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 %p_1_0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_2_2 = phi i1 [ %t4, %edge_2 ]
  %p_2_3 = phi %hia.buffer [ %t6, %edge_2 ]
  %p_2_4 = phi i8 [ 1, %edge_2 ]
  br label %edge_4
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_3_2 = phi i1 [ %t4, %edge_3 ]
  %p_3_3 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_3_4 = phi i8 [ 1, %edge_3 ]
  %t7 = extractvalue %hia.buffer %p_3_3, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  %t10 = zext i8 %p_3_4 to i64
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t10)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  ret i64 %t12
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_0, %edge_7 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_4 ], [ %p_5_1, %edge_7 ]
  %p_4_2 = phi %hia.buffer [ %p_2_3, %edge_4 ], [ %p_5_2, %edge_7 ]
  %p_4_3 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_3, %edge_7 ]
  %p_4_4 = phi i64 [ 0, %edge_4 ], [ %t27, %edge_7 ]
  %t16 = icmp ult i64 %p_4_4, %p_4_3
  br i1 %t16, label %edge_5, label %edge_6
b5:
  %p_5_0 = phi i64 [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_5 ]
  %p_5_2 = phi %hia.buffer [ %p_4_2, %edge_5 ]
  %p_5_3 = phi i64 [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i64 [ %p_4_4, %edge_5 ]
  %t17 = trunc i64 %p_5_4 to i32
  %t18 = add i32 %t17, %p_5_1
  %t19 = trunc i64 %p_5_4 to i8
  %t20 = trunc i32 %p_5_1 to i8
  %t21 = add i8 %t19, %t20
  %t22 = extractvalue %hia.buffer %p_5_2, 0
  %t23 = extractvalue %hia.buffer %p_5_2, 1
  %t24 = icmp ult i64 %p_5_4, %t23
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = getelementptr i8, ptr %t22, i64 %p_5_4
  store i8 %t21, ptr %t26, align 1
  %t27 = add i64 %p_5_4, 1
  br label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_6 ]
  %p_6_2 = phi %hia.buffer [ %p_4_2, %edge_6 ]
  %p_6_3 = phi i64 [ %p_4_3, %edge_6 ]
  %p_6_4 = phi i64 [ %p_4_4, %edge_6 ]
  br label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_8 ], [ %p_8_0, %edge_11 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_8 ], [ %p_8_1, %edge_11 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_8 ], [ %p_8_2, %edge_11 ]
  %p_7_3 = phi i64 [ 0, %edge_8 ], [ %t36, %edge_11 ]
  %p_7_4 = phi i64 [ %p_6_0, %edge_8 ], [ %p_8_4, %edge_11 ]
  %p_7_5 = phi i64 [ 0, %edge_8 ], [ %t37, %edge_11 ]
  %t28 = icmp ult i64 %p_7_5, %p_7_4
  br i1 %t28, label %edge_9, label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_9 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_9 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_9 ]
  %p_8_3 = phi i64 [ %p_7_3, %edge_9 ]
  %p_8_4 = phi i64 [ %p_7_4, %edge_9 ]
  %p_8_5 = phi i64 [ %p_7_5, %edge_9 ]
  %t29 = extractvalue %hia.buffer %p_8_2, 0
  %t30 = extractvalue %hia.buffer %p_8_2, 1
  %t31 = icmp ult i64 %p_8_5, %t30
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  %t33 = getelementptr i8, ptr %t29, i64 %p_8_5
  %t34 = load i8, ptr %t33, align 1
  %t35 = zext i8 %t34 to i64
  %t36 = add i64 %p_8_3, %t35
  %t37 = add i64 %p_8_5, 1
  br label %edge_11
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_10 ]
  %p_9_1 = phi i32 [ %p_7_1, %edge_10 ]
  %p_9_2 = phi %hia.buffer [ %p_7_2, %edge_10 ]
  %p_9_3 = phi i64 [ %p_7_3, %edge_10 ]
  %p_9_4 = phi i64 [ %p_7_4, %edge_10 ]
  %p_9_5 = phi i64 [ %p_7_5, %edge_10 ]
  %t38 = extractvalue %hia.buffer %p_9_2, 0
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %drop_nonnull_40, label %drop_after_40
drop_nonnull_40:
  call void @free(ptr %t38) nobuiltin
  br label %drop_after_40
drop_after_40:
  ret i64 %p_9_3
b10:
  %p_10_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_10_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t41 = call %hia.alloc @__hia_allocate(i64 %p_10_0, i1 false)
  %t42 = extractvalue %hia.alloc %t41, 0
  %t43 = extractvalue %hia.alloc %t41, 1
  %t44 = select i1 %t43, i64 %p_10_0, i64 0
  %t45 = insertvalue %hia.buffer %t42, i64 %t44, 1
  br i1 %t43, label %edge_12, label %edge_13
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_12 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ]
  %p_11_2 = phi i1 [ %t43, %edge_12 ]
  %p_11_3 = phi %hia.buffer [ %t45, %edge_12 ]
  %p_11_4 = phi i8 [ 1, %edge_12 ]
  br label %edge_14
b12:
  %p_12_0 = phi i64 [ %p_10_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_10_1, %edge_13 ]
  %p_12_2 = phi i1 [ %t43, %edge_13 ]
  %p_12_3 = phi %hia.buffer [ %t45, %edge_13 ]
  %p_12_4 = phi i8 [ 1, %edge_13 ]
  %t46 = extractvalue %hia.buffer %p_12_3, 0
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %drop_nonnull_48, label %drop_after_48
drop_nonnull_48:
  call void @free(ptr %t46) nobuiltin
  br label %drop_after_48
drop_after_48:
  %t49 = zext i8 %p_12_4 to i64
  %t50 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t49)
  %t51 = extractvalue { i64, i1 } %t50, 0
  %t52 = extractvalue { i64, i1 } %t50, 1
  %t53 = xor i1 %t52, true
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  ret i64 %t51
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_14 ], [ %p_14_0, %edge_17 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ], [ %p_14_1, %edge_17 ]
  %p_13_2 = phi %hia.buffer [ %p_11_3, %edge_14 ], [ %p_14_2, %edge_17 ]
  %p_13_3 = phi i64 [ %p_11_0, %edge_14 ], [ %p_14_3, %edge_17 ]
  %p_13_4 = phi i64 [ 0, %edge_14 ], [ %t67, %edge_17 ]
  %t55 = icmp ult i64 %p_13_4, %p_13_3
  br i1 %t55, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_14_1 = phi i32 [ %p_13_1, %edge_15 ]
  %p_14_2 = phi %hia.buffer [ %p_13_2, %edge_15 ]
  %p_14_3 = phi i64 [ %p_13_3, %edge_15 ]
  %p_14_4 = phi i64 [ %p_13_4, %edge_15 ]
  %t56 = trunc i64 %p_14_4 to i32
  %t57 = add i32 %t56, %p_14_1
  %t58 = trunc i64 %p_14_4 to i8
  %t59 = trunc i32 %p_14_1 to i8
  %t60 = add i8 %t58, %t59
  %t61 = extractvalue %hia.buffer %p_14_2, 0
  %t62 = extractvalue %hia.buffer %p_14_2, 1
  %t63 = icmp ult i64 %p_14_4, %t62
  br i1 %t63, label %ok_64, label %trap_64
trap_64:
  call void @abort()
  unreachable
ok_64:
  %t65 = getelementptr i8, ptr %t61, i64 %p_14_4
  store i8 %t60, ptr %t65, align 1
  %t66 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_14_4, i64 1)
  %t67 = extractvalue { i64, i1 } %t66, 0
  %t68 = extractvalue { i64, i1 } %t66, 1
  %t69 = xor i1 %t68, true
  br i1 %t69, label %ok_70, label %trap_70
trap_70:
  call void @abort()
  unreachable
ok_70:
  br label %edge_17
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i32 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi %hia.buffer [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i64 [ %p_13_3, %edge_16 ]
  %p_15_4 = phi i64 [ %p_13_4, %edge_16 ]
  br label %edge_18
b16:
  %p_16_0 = phi i64 [ %p_15_0, %edge_18 ], [ %p_17_0, %edge_21 ]
  %p_16_1 = phi i32 [ %p_15_1, %edge_18 ], [ %p_17_1, %edge_21 ]
  %p_16_2 = phi %hia.buffer [ %p_15_2, %edge_18 ], [ %p_17_2, %edge_21 ]
  %p_16_3 = phi i64 [ 0, %edge_18 ], [ %t80, %edge_21 ]
  %p_16_4 = phi i64 [ %p_15_0, %edge_18 ], [ %p_17_4, %edge_21 ]
  %p_16_5 = phi i64 [ 0, %edge_18 ], [ %t85, %edge_21 ]
  %t71 = icmp ult i64 %p_16_5, %p_16_4
  br i1 %t71, label %edge_19, label %edge_20
b17:
  %p_17_0 = phi i64 [ %p_16_0, %edge_19 ]
  %p_17_1 = phi i32 [ %p_16_1, %edge_19 ]
  %p_17_2 = phi %hia.buffer [ %p_16_2, %edge_19 ]
  %p_17_3 = phi i64 [ %p_16_3, %edge_19 ]
  %p_17_4 = phi i64 [ %p_16_4, %edge_19 ]
  %p_17_5 = phi i64 [ %p_16_5, %edge_19 ]
  %t72 = extractvalue %hia.buffer %p_17_2, 0
  %t73 = extractvalue %hia.buffer %p_17_2, 1
  %t74 = icmp ult i64 %p_17_5, %t73
  br i1 %t74, label %ok_75, label %trap_75
trap_75:
  call void @abort()
  unreachable
ok_75:
  %t76 = getelementptr i8, ptr %t72, i64 %p_17_5
  %t77 = load i8, ptr %t76, align 1
  %t78 = zext i8 %t77 to i64
  %t79 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_17_3, i64 %t78)
  %t80 = extractvalue { i64, i1 } %t79, 0
  %t81 = extractvalue { i64, i1 } %t79, 1
  %t82 = xor i1 %t81, true
  br i1 %t82, label %ok_83, label %trap_83
trap_83:
  call void @abort()
  unreachable
ok_83:
  %t84 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_17_5, i64 1)
  %t85 = extractvalue { i64, i1 } %t84, 0
  %t86 = extractvalue { i64, i1 } %t84, 1
  %t87 = xor i1 %t86, true
  br i1 %t87, label %ok_88, label %trap_88
trap_88:
  call void @abort()
  unreachable
ok_88:
  br label %edge_21
b18:
  %p_18_0 = phi i64 [ %p_16_0, %edge_20 ]
  %p_18_1 = phi i32 [ %p_16_1, %edge_20 ]
  %p_18_2 = phi %hia.buffer [ %p_16_2, %edge_20 ]
  %p_18_3 = phi i64 [ %p_16_3, %edge_20 ]
  %p_18_4 = phi i64 [ %p_16_4, %edge_20 ]
  %p_18_5 = phi i64 [ %p_16_5, %edge_20 ]
  %t89 = extractvalue %hia.buffer %p_18_2, 0
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %drop_nonnull_91, label %drop_after_91
drop_nonnull_91:
  call void @free(ptr %t89) nobuiltin
  br label %drop_after_91
drop_after_91:
  ret i64 %p_18_3
edge_0:
  br label %b1
edge_1:
  br label %b10
edge_2:
  br label %b2
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b4
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b9
edge_11:
  br label %b7
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b13
edge_18:
  br label %b16
edge_19:
  br label %b17
edge_20:
  br label %b18
edge_21:
  br label %b16
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
