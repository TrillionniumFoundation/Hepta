import json,sys,unittest
from pathlib import Path
sys.path.insert(0,'/tmp/hia-wire-e26e-r7-local-r1/source')
ids=['tests.test_hia_json_wire_native.WireSourceTests.test_generated_source_and_lazy_exact_type_observer', 'tests.test_hia_json_wire_native.WireSourceTests.test_word_helpers_preserve_bounds_and_partial_byte_stores', 'tests.test_hia_json_wire_native.WireSourceTests.test_inlined_field_stores_keep_evaluation_and_partial_write_order']
executed=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  executed.append(test.id());super().startTest(test)
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in ids)
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
passed=(executed==ids and result.testsRun==len(ids) and not any((result.failures,result.errors,result.skipped,result.expectedFailures,result.unexpectedSuccesses)))
report={'status':'PASS' if passed else 'FAIL','loaded_test_ids':ids,'executed_test_ids':executed,'tests_run':result.testsRun,'failures':[(t.id(),s) for t,s in result.failures],'errors':[(t.id(),s) for t,s in result.errors],'skipped':[(t.id(),s) for t,s in result.skipped],'expected_failures':[(t.id(),s) for t,s in result.expectedFailures],'unexpected_successes':[t.id() for t in result.unexpectedSuccesses]}
Path('/tmp/hia-wire-e26e-r7-local-r1/evidence/core-controls.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if passed else 1)
