"""Diagnostic timing by actual HIA continuation phase on the current source; never qualification."""
import json,os,struct,sys,time,unittest,threading
from collections import Counter
from hashlib import sha256
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,'/workspace/scratch/e26ed3e2edcf/hia-native-wire-entry')
from hepta.hia_json_wire_native import NativeJsonWire,WireSession,SELECTOR,SOURCE
from hepta.hia_agent_service import HIAAgentService
root=Path('/workspace/scratch/e26ed3e2edcf')
manifest=root/'wire-entry-development-r5/manifest.json'
os.environ[SELECTOR]=str(manifest)
original_step,original_observe,original_encode,original_evaluate=WireSession.step,WireSession.observe,NativeJsonWire.encode_ordinary,HIAAgentService._hia_evaluate
steps,step_ns,observations,observe_ns,points=Counter(),Counter(),Counter(),Counter(),Counter()
wires=[];enabled=[False];evaluation=[]
def step(self,packet=None):
 if not enabled[0]:return original_step(self,packet)
 phase,=struct.unpack_from('<Q',self.workspace,24)
 mode,=struct.unpack_from('<Q',self.workspace,448)
 tag=str(phase)+(':'+str(mode) if phase==31 else '')
 start=time.perf_counter_ns()
 try:return original_step(self,packet)
 finally:steps[tag]+=1;step_ns[tag]+=time.perf_counter_ns()-start

def observe(self):
 if not enabled[0]:return original_observe(self)
 opcode,=struct.unpack_from('<Q',self.workspace,8)
 count,=struct.unpack_from('<Q',self.workspace,216)
 start=time.perf_counter_ns()
 try:return original_observe(self)
 finally:
  observations[str(opcode)]+=1;observe_ns[str(opcode)]+=time.perf_counter_ns()-start
  if opcode==3:points['requested_codepoints']+=count

def encode(self,*values,**options):
 if not enabled[0]:return original_encode(self,*values,**options)
 start=time.perf_counter_ns();result=None
 try:
  result=original_encode(self,*values,**options);return result
 finally:wires.append({'elapsed_ns':time.perf_counter_ns()-start,'output_bytes':len(result) if result is not None else None})

def evaluate(self,args):
 start=time.perf_counter_ns();enabled[0]=True
 try:return original_evaluate(self,args)
 finally:
  enabled[0]=False;evaluation.append({'elapsed_ns':time.perf_counter_ns()-start,'threads':[t.name for t in threading.enumerate()]})

name='tests.test_hia_agent_native_tools.NativeLifecycleTests.test_native_timeout_is_incomplete_terminated_and_not_adoptable'
with patch.object(WireSession,'step',step),patch.object(WireSession,'observe',observe),patch.object(NativeJsonWire,'encode_ordinary',encode),patch.object(HIAAgentService,'_hia_evaluate',evaluate):
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName(name))
report={'schema':'hepta.hia.json-wire-current-phase-diagnostic.v1','scope':'DIAGNOSTIC_TIMING_OVERHEAD_NOT_QUALIFICATION','test_id':name,'manifest':json.loads(manifest.read_bytes()),'adapter_sha256':sha256((SOURCE.parents[2]/'hepta/hia_json_wire_native.py').read_bytes()).hexdigest(),'source_sha256':sha256(SOURCE.read_bytes()).hexdigest(),'python':sys.version,'evaluation':evaluation,'step_counts':dict(steps),'step_ns':dict(step_ns),'observation_counts':dict(observations),'observation_ns':dict(observe_ns),'point_counts':dict(points),'wire_calls':len(wires),'wire_ns':sum(w['elapsed_ns'] for w in wires),'largest_wires':sorted(wires,key=lambda w:w['elapsed_ns'],reverse=True)[:15],'failures':[{'test':t.id(),'trace':trace} for t,trace in result.failures],'errors':[{'test':t.id(),'trace':trace} for t,trace in result.errors]}
p=root/'wire-entry-native-timeout-phase-r5.json'
with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'report':str(p),'scope':report['scope'],'evaluation':evaluation,'steps':sum(steps.values()),'wire_calls':len(wires)}))
