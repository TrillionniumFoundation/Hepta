"""Compare every exposed native packet, full workspace and full output after the HIA word-helper change."""
import ctypes,json,struct,subprocess,sys
from hashlib import sha256
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/e26ed3e2edcf/hia-native-wire-entry')
from hepta.hia_json_wire_native import NativeJsonWire,WireSession,ForeignGraphObserver,SOURCE
root=Path('/workspace/scratch/e26ed3e2edcf')
paths=[root/'wire-entry-development-r1/manifest.json',root/'wire-entry-development-r3/manifest.json']
ms=[json.loads(p.read_bytes()) for p in paths]
old_source=subprocess.check_output(['git','show','fc94ba18c0402bcac557b8cc0cff6d606d4a1bef:examples/hia_bootstrap/json_wire.hiaasm'],cwd=SOURCE.parents[2])
assert sha256(old_source).hexdigest()==ms[0]['source_sha256']
assert sha256(SOURCE.read_bytes()).hexdigest()==ms[1]['source_sha256']
images=[NativeJsonWire((p.parent/m['image_path']).read_bytes(),m['image_sha256']) for p,m in zip(paths,ms)]
images.append(images[1])
class LegacyObserver(ForeignGraphObserver):
 def points(self,handle,start,count):
  value=self.value(handle)
  return tuple(ord(value[index]) for index in range(start,start+count))
class LegacySession(WireSession):
 def step(self,packet=None):
  if self.finished:raise RuntimeError('native JSON wire session is terminal')
  raw=self.packet if packet is None else packet
  source=ctypes.create_string_buffer(raw,max(1,len(raw)))
  status=self.image._entry(source,len(raw),self.output,self.output_size,self.workspace,len(self.workspace))
  if status!=1:self.finished=True
  return status
classes=[WireSession,LegacySession,WireSession]
cycle=[];cycle.append(cycle)
cases=[('none',None,16,False,True),('unicode',{'z':[None,True,False,0,2**100,-0.0,1.25],'a':'雪🧪\x7f\0'},1024,False,True),('unicode-ascii',{'z':[None,True,False,0,2**100,-0.0,1.25],'a':'雪🧪\x7f\0'},1024,True,False),('numeric-keys',{10**30:0,-1.5:'x',True:False},1024,False,True),('mixed-key-sort',{None:0,'z':1},128,False,True),('collision',{1:0,'1':None},128,False,True),('cycle',cycle,16,False,True),('nonfinite',[float('nan'),'x'],128,False,True),('surrogate-priority',[object(),'\ud800'],128,False,True),('large-int',10**700,4096,False,True),('bad-max-bool',None,True,False,True),('bad-max-negative',None,-1,False,True),('string-budget','a'*55,10,False,True),('zero-budget',[],0,False,True)]
results=[]
for label,value,maximum,ascii_,sort in cases:
 observers=[ForeignGraphObserver(),LegacyObserver(),ForeignGraphObserver()]
 sessions=[cls(image,observer,observer.register(value),maximum,ensure_ascii=ascii_,sort_keys=sort) for cls,image,observer in zip(classes,images,observers)]
 trace=sha256();steps=0
 while True:
  input_pins=[sha256(s.packet).hexdigest() for s in sessions]
  statuses=[s.step() for s in sessions];assert statuses[0]==statuses[1]==statuses[2],(label,statuses)
  assert input_pins==[sha256(s.packet).hexdigest() for s in sessions],(label,'input bytes changed')
  outs=[ctypes.string_at(s.output,max(1,s.output_size)) for s in sessions]
  states=[ctypes.string_at(s.workspace,len(s.workspace)) for s in sessions]
  assert outs[0]==outs[1]==outs[2],(label,'full output',steps)
  assert states[0]==states[1]==states[2],(label,'full workspace',steps)
  trace.update(struct.pack('<Q',statuses[0]));trace.update(sha256(outs[0]).digest());trace.update(sha256(states[0]).digest());steps+=1
  if statuses[0]!=1:break
  packets=[s.observe() for s in sessions]
  assert packets[0]==packets[1]==packets[2],(label,'observation packet',steps)
  trace.update(packets[0])
 results.append({'case':label,'native_steps':steps,'terminal_status':statuses[0],'trace_sha256':trace.hexdigest(),'full_output_and_workspace_equal_after_every_step':True})
for mutation in ('short','long','sequence','opcode','count'):
 observers=[ForeignGraphObserver(),LegacyObserver(),ForeignGraphObserver()]
 sessions=[cls(image,observer,observer.register('hello'),128,ensure_ascii=False,sort_keys=True) for cls,image,observer in zip(classes,images,observers)]
 for s in sessions:assert s.step()==1
 packets=[bytearray(s.observe()) for s in sessions]
 for packet in packets:
  if mutation=='short':packet.pop()
  if mutation=='long':packet.append(0)
  if mutation=='sequence':struct.pack_into('<Q',packet,8,0)
  if mutation=='opcode':struct.pack_into('<Q',packet,16,2)
  if mutation=='count':struct.pack_into('<Q',packet,32,(1<<64)-1)
 statuses=[s.step(bytes(p)) for s,p in zip(sessions,packets)]
 assert statuses[0]==statuses[1]==statuses[2]
 assert ctypes.string_at(sessions[0].workspace,len(sessions[0].workspace))==ctypes.string_at(sessions[1].workspace,len(sessions[1].workspace))==ctypes.string_at(sessions[2].workspace,len(sessions[2].workspace))
 assert ctypes.string_at(sessions[0].output,128)==ctypes.string_at(sessions[1].output,128)==ctypes.string_at(sessions[2].output,128)
 results.append({'case':'packet-'+mutation,'terminal_status':statuses[0],'full_output_and_workspace_equal_after_step':True})
report={'schema':'hepta.hia.json-wire-word-helper-packet-comparison.v1','scope':'DEVELOPMENT_ACTUAL_NATIVE_A_B_NOT_COLD_QUALIFICATION','status':'PASS','python':sys.version,'source_before':ms[0]['source_sha256'],'source_after':ms[1]['source_sha256'],'image_before':ms[0]['image_sha256'],'image_after':ms[1]['image_sha256'],'adapter_sha256':sha256((SOURCE.parents[2]/'hepta/hia_json_wire_native.py').read_bytes()).hexdigest(),'transport_controls':'Old HIA/current transport, new HIA/original copied-packet plus indexed-points transport, new HIA/current transport. Exact immutable packet SHA checked before/after every regular call.', 'comparison':'Every return status, every observation reply byte, and the complete declared output/workspace extent after every native call, not only final output.','cases':results,'cases_run':len(results),'successful_native_source_admission_used_for_old_image':False,'old_image_scope':'Explicit historical-image differential constructor with captured old source SHA, not the production selected loader.'}
p=root/'wire-entry-word-helper-packets-r3.json'
with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'cases':len(results),'native_steps':sum(x.get('native_steps',2) for x in results),'report':str(p)}))
