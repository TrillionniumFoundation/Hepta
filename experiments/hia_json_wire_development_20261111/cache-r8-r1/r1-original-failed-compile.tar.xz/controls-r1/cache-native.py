import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, '/tmp/hia-wire-e26e-r8-cache-r1/source')
suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_hia_json_wire_cache')


def flatten(tests):
    for item in tests:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item.id()


loaded = list(flatten(suite))
executed = []


class Result(unittest.TextTestResult):
    def startTest(self, test):
        executed.append(test.id())
        super().startTest(test)


result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
passed = (bool(loaded) and len(loaded) == len(set(loaded)) and loaded == executed
          and result.testsRun == len(loaded)
          and not any((result.failures, result.errors, result.skipped,
                       result.expectedFailures, result.unexpectedSuccesses)))
report = {'scope': 'EXPLICIT_DEVELOPMENT_CURRENT_SOURCE', 'status': 'PASS' if passed else 'FAIL',
          'loaded_test_ids': loaded, 'executed_test_ids': executed, 'tests_run': result.testsRun,
          'failures': [(test.id(), text) for test, text in result.failures],
          'errors': [(test.id(), text) for test, text in result.errors],
          'skipped': [(test.id(), text) for test, text in result.skipped],
          'expected_failures': [(test.id(), text) for test, text in result.expectedFailures],
          'unexpected_successes': [test.id() for test in result.unexpectedSuccesses]}
Path('/tmp/hia-wire-e26e-r8-cache-r1/controls-r1/cache-native.json').write_text(
    json.dumps(report, indent=2, sort_keys=True) + '\n')
raise SystemExit(0 if passed else 1)
