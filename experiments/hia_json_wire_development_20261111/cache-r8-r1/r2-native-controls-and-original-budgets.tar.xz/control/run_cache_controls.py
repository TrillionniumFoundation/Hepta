from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path('/tmp/hia-wire-e26e-r8-cache-r1')
SOURCE = ROOT / 'source'
EVIDENCE = ROOT / 'controls-r1'
COMPILER = Path('/tmp/hia-e26e-desktop-b3-input/B3.image.bin')
COMPILER_SHA = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'


def snapshot():
    return {str(path.relative_to(SOURCE)): {'sha256': sha256(path.read_bytes()).hexdigest(),
            'size': path.stat().st_size, 'mode': path.stat().st_mode & 0o777}
            for path in sorted(SOURCE.rglob('*')) if path.is_file()}


def main():
    report = {'schema': 'hepta.hia.json-wire-key-cache-controls.v1',
              'scope': 'DEVELOPMENT_CURRENT_SOURCE_NOT_COLD_OR_FULL',
              'status': 'HOLD', 'steps': [], 'python': sys.version,
              'executable': sys.executable, 'started_utc': datetime.now(timezone.utc).isoformat()}
    before = snapshot()
    (EVIDENCE / 'source-before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1')
    env.pop('HEPTA_HIA_JSON_WIRE_COLD_REPORT', None)
    env.pop('HEPTA_HIA_JSON_WIRE_MANIFEST', None)
    env['HEPTA_HIA_JSON_WIRE_DEVELOPMENT_MANIFEST'] = str(ROOT / 'wire-r1/manifest.json')

    def run(name, argv, seconds):
        start = time.monotonic()
        with (EVIDENCE / (name + '.stdout.log')).open('xb') as stdout, \
                (EVIDENCE / (name + '.stderr.log')).open('xb') as stderr:
            result = subprocess.run(argv, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr, timeout=seconds)
        row = {'name': name, 'argv': argv, 'timeout_seconds': seconds,
               'returncode': result.returncode, 'wall_seconds': time.monotonic() - start}
        report['steps'].append(row)
        print(json.dumps(row), flush=True)
        if result.returncode:
            raise RuntimeError(name + ' failed')

    try:
        assert sha256(COMPILER.read_bytes()).hexdigest() == COMPILER_SHA
        run('compile-development', [sys.executable, '-B', '-m', 'tools.build_hia_json_wire',
            '--development', '--compiler', str(COMPILER), '--output', str(ROOT / 'wire-r1')], 120)
        manifest = json.loads((ROOT / 'wire-r1/manifest.json').read_bytes())
        assert manifest['source_sha256'] == before['examples/hia_bootstrap/json_wire.hiaasm']['sha256']
        assert manifest['compiler_sha256'] == COMPILER_SHA
        assert sha256((ROOT / 'wire-r1' / manifest['image_path']).read_bytes()).hexdigest() == manifest['image_sha256']
        report['manifest'] = manifest
        run('core-controls', [sys.executable, '-B', str(EVIDENCE / 'core-controls.py')], 120)
        core = json.loads((EVIDENCE / 'core-controls.json').read_bytes())
        assert core['status'] == 'PASS' and core['tests_run'] == 3
        run('packet-comparison', [sys.executable, '-B', str(EVIDENCE / 'packet-comparison.py')], 90)
        packet = json.loads((EVIDENCE / 'packet-comparison.json').read_bytes())
        assert packet['status'] == 'PASS' and packet['cases_run'] == 19
        assert sum(case.get('native_steps', 2) for case in packet['cases']) == 228
        run('cache-native', [sys.executable, '-B', str(EVIDENCE / 'cache-native.py')], 120)
        cache = json.loads((EVIDENCE / 'cache-native.json').read_bytes())
        assert cache['status'] == 'PASS' and cache['loaded_test_ids'] == cache['executed_test_ids']
        assert cache['tests_run'] == len(cache['loaded_test_ids']) and cache['tests_run'] > 0
        report['status'] = 'PASS_LIMITED_DEVELOPMENT_CONTROLS'
    except BaseException as exc:
        report['exception'] = {'type': type(exc).__name__, 'message': str(exc), 'trace': traceback.format_exc()}
    finally:
        after = snapshot()
        (EVIDENCE / 'source-after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
        report['source_stable'] = before == after
        report['compiler_stable'] = sha256(COMPILER.read_bytes()).hexdigest() == COMPILER_SHA
        if not report['source_stable'] or not report['compiler_stable']:
            report['status'] = 'HOLD'
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        (EVIDENCE / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
        print(json.dumps({'status': report['status'], 'report': str(EVIDENCE / 'report.json')}), flush=True)
    return 0 if report['status'] == 'PASS_LIMITED_DEVELOPMENT_CONTROLS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
