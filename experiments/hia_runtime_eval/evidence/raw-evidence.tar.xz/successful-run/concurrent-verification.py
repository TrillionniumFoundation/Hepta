from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json, resource
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
from hepta.hia_optimization import verify_optimization
base = json.loads(Path(__file__).with_name("concurrent-verification.core.json").read_text())
def run(index):
    return verify_optimization(base, base)["status"]
with ThreadPoolExecutor(max_workers=4) as pool:
    statuses = list(pool.map(run, range(20)))
print(json.dumps({"workers": 4, "requests": 20, "statuses": statuses}))
raise SystemExit(0 if statuses == ["verified"] * 20 else 1)
