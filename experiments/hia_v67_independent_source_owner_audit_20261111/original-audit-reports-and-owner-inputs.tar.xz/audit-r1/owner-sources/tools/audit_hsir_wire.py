#!/usr/bin/env python3
"""Inspect two checked HSIR v0 exports without trusting an ambiguous schema id.

The two development branches use the same hepta.hsir.v0 schema label with
incompatible wire envelopes. This tool refuses to equate them. It does not
convert programs, certify checks, or grant release/merge authorization.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path

SCHEMA = "hepta.hsir.v0"
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
MAX_HSIR_INPUT_BYTES = 8_000_000
MAX_HSIR_JSON_DEPTH = 256
PROFILES = {
    "source_bound_dict_v0": {
        "discriminator": ("profile", "checked_typed_ast_not_verified_mir"),
        "required": ("module", "source_sha256", "project_sha256", "functions",
                     "external_obligations", "claims", "all_expressions_typed"),
        "denied_claims": ("native_borrow_validation", "translation_correctness_proved",
                          "whole_language_soundness_proved", "foreign_contracts_proved"),
    },
    "frozen_snapshot_v0": {
        "discriminator": ("status", "checked_frontend_snapshot_not_proved"),
        "required": ("program", "source_sha256", "functions", "claims",
                     "external_assumptions", "typed_expression_count"),
        "denied_claims": ("lifetimes_fully_modeled", "pointer_provenance_proved",
                          "source_semantics_refined", "native_backend_equivalence_proved"),
    },
}

PROFILE_LAYOUTS = {
    # Two historical producers accidentally share a schema name; only their
    # exact known envelopes are admissible for audit, not for execution.
    "source_bound_dict_v0": frozenset({
        "schema", "profile", "module", "path", "source_sha256",
        "project_sha256", "imports", "structs", "enums", "functions",
        "untyped_expressions", "all_expressions_typed", "external_obligations",
        "volatile_accesses", "foreign_assumptions", "resource_contracts",
        "owned_types", "claims", "sha256",
    }),
    "frozen_snapshot_v0": frozenset({
        "schema", "status", "program", "source_sha256", "imports",
        "structs", "enums", "functions", "external_assumptions",
        "resource_contracts", "typed_expression_count", "claims", "sha256",
    }),
}

class HSIRWireRejected(ValueError):
    pass


OBLIGATION_REASONS = frozenset({
    "foreign_function", "raw_pointer_signature", "unsafe_effect",
    "ffi_effect", "volatile_access",
})


def require_unresolved_obligations(items: object) -> None:
    """Accept only PR #14's explicitly unresolved FFI obligation wire shape."""
    if not isinstance(items, list):
        raise HSIRWireRejected("E_HSIR_OBLIGATIONS")
    for entry in items:
        if (not isinstance(entry, dict)
                or set(entry) != {"function", "reasons", "status"}
                or not isinstance(entry["function"], str)
                or not entry["function"]
                or entry["status"] != "caller_obligation_not_dischargeable_by_hsir"
                or not isinstance(entry["reasons"], list)
                or not entry["reasons"]
                or any(type(reason) is not str or reason not in OBLIGATION_REASONS
                       for reason in entry["reasons"])
                or len(entry["reasons"]) != len(set(entry["reasons"]))):
            raise HSIRWireRejected("E_HSIR_OBLIGATION_STATUS")


UNPROVED_EXTERNAL_OBLIGATIONS = (
    "foreign implementation obeys the declared ABI and effect upper bound",
    "caller establishes pointer validity, lifetime, alignment, initialization and aliasing obligations",
)


def require_unproved_external_assumptions(items: object) -> None:
    """Validate pinned PR #36 checker assumption shapes without discharging them."""
    if type(items) is not list:
        raise HSIRWireRejected("E_HSIR_EXTERNAL_ASSUMPTIONS")
    for entry in items:
        if type(entry) is not dict or type(entry.get("kind")) is not str:
            raise HSIRWireRejected("E_HSIR_EXTERNAL_ASSUMPTION")
        kind = entry["kind"]
        if (kind not in {"extern_contract", "unsafe_obligation"}
                or type(entry.get("function")) is not str
                or not entry["function"]):
            raise HSIRWireRejected("E_HSIR_EXTERNAL_ASSUMPTION")
        if kind == "extern_contract":
            if (set(entry) != {"kind", "function", "abi", "declared_effects",
                              "parameters", "return_type", "status", "obligations"}
                    or entry["abi"] != "C"
                    or entry["status"] != "assumed_not_verified"
                    or type(entry["return_type"]) is not str
                    or not entry["return_type"]
                    or type(entry["declared_effects"]) is not list
                    or any(type(effect) is not str or not effect
                           for effect in entry["declared_effects"])
                    or len(entry["declared_effects"]) != len(set(entry["declared_effects"]))
                    or type(entry["parameters"]) is not list
                    or any(type(param) is not dict or set(param) != {"name", "type"}
                           or type(param["name"]) is not str or not param["name"]
                           or type(param["type"]) is not str or not param["type"]
                           for param in entry["parameters"])
                    or entry["obligations"] != list(UNPROVED_EXTERNAL_OBLIGATIONS)):
                raise HSIRWireRejected("E_HSIR_EXTERNAL_ASSUMPTION")
        elif (set(entry) != {"kind", "function", "operation", "path", "line", "status"}
              or entry["status"] != "not_proved_by_frontend"
              or type(entry["operation"]) is not str or not entry["operation"]
              or type(entry["path"]) is not str
              or type(entry["line"]) is not int or entry["line"] < 1):
            raise HSIRWireRejected("E_HSIR_EXTERNAL_ASSUMPTION")


def pairs_unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise HSIRWireRejected("E_HSIR_DUPLICATE_KEY: " + key)
        result[key] = value
    return result


def _read_pinned_hsir(path: str | Path) -> bytes:
    """Read exactly one ordinary input inode, never a post-lstat replacement.

    This is a fail-closed source-audit reader, NOT a proof of producer origin.
    Both NOFOLLOW and NONBLOCK are required: a swapped FIFO would otherwise
    hang open() before its file type can be checked. The content digest is
    validated independently by fingerprint(), not trusted from file metadata.
    """
    if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_NONBLOCK"):
        raise HSIRWireRejected("E_HSIR_SOURCE_IO: secure file open is unavailable")
    path = Path(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise HSIRWireRejected("E_HSIR_SOURCE_TYPE: ordinary input file required")
    if before.st_size > MAX_HSIR_INPUT_BYTES:
        raise HSIRWireRejected("E_HSIR_TOO_LARGE")
    if before.st_size <= 0:
        raise HSIRWireRejected("E_HSIR_JSON: empty HSIR input")
    identity = lambda st: (st.st_dev, st.st_ino, st.st_mode, st.st_size,
                           st.st_mtime_ns, st.st_ctime_ns)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
                 | getattr(os, "O_CLOEXEC", 0))
    try:
        opened = os.fstat(fd)
        if not stat.S_ISREG(opened.st_mode) or identity(opened) != identity(before):
            raise HSIRWireRejected("E_HSIR_SOURCE_ID: replaced before descriptor admission")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(MAX_HSIR_INPUT_BYTES + 1)
        after_fd, after_path = os.fstat(fd), path.lstat()
        if (len(raw) > MAX_HSIR_INPUT_BYTES
                or identity(after_fd) != identity(before)
                or not stat.S_ISREG(after_path.st_mode)
                or identity(after_path) != identity(before)
                or len(raw) != before.st_size):
            raise HSIRWireRejected("E_HSIR_SOURCE_ID: input changed while auditing")
        return raw
    finally:
        os.close(fd)


def _check_json_depth(text: str) -> None:
    """Bound container nesting before the host JSON decoder allocates a tree.

    Python's decoder recursion behavior differs across releases. This lexical
    budget is independent of it; json.loads still validates all actual syntax,
    duplicate keys and constants. Brackets inside escaped strings are data.
    """
    depth, quoted, escaped = 0, False, False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "[{":
            depth += 1
            if depth > MAX_HSIR_JSON_DEPTH:
                raise HSIRWireRejected("E_HSIR_JSON: nesting budget exceeded")
        elif char in "]}":
            depth -= 1


def load(path: str) -> dict:
    raw = _read_pinned_hsir(path)
    try:
        text = raw.decode("utf-8")
        _check_json_depth(text)
        result = json.loads(text, object_pairs_hook=pairs_unique,
                            parse_constant=lambda x: (_ for _ in ()).throw(
                                HSIRWireRejected("E_HSIR_NONFINITE: " + x)))
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise HSIRWireRejected("E_HSIR_JSON") from exc
    if not isinstance(result, dict):
        raise HSIRWireRejected("E_HSIR_NOT_OBJECT")
    return result


def unwrap(record: dict) -> tuple[dict, str]:
    """Separate CLI presentation metadata from the signed HSIR wire payload.

    PR #14 emits an hsir.export.v0 wrapper; PR #36 adds reference_validation
    to a valid HSIRSnapshot.as_dict() *after* computing its digest. Neither
    sidecar is proof of compiler validity and neither enters the payload hash.
    """
    if not isinstance(record, dict):
        raise HSIRWireRejected("E_HSIR_NOT_OBJECT")
    if record.get("schema") == "hepta.hsir.export.v0":
        if (set(record) != {"schema", "ok", "status", "hsir", "validation"}
                or type(record["ok"]) is not bool
                or not isinstance(record["status"], str)
                or not isinstance(record["validation"], dict)
                or not isinstance(record["hsir"], dict)
                or record["hsir"].get("profile") !=
                    "checked_typed_ast_not_verified_mir"):
            raise HSIRWireRejected("E_HSIR_EXPORT_ENVELOPE")
        return record["hsir"], "pr14_export_unbound_validation"
    if record.get("schema") == SCHEMA and "reference_validation" in record:
        if (not isinstance(record["reference_validation"], dict)
                or record.get("status") != "checked_frontend_snapshot_not_proved"):
            raise HSIRWireRejected("E_HSIR_SIDECAR_ENVELOPE")
        return {k: v for k, v in record.items() if k != "reference_validation"}, \
               "pr36_cli_unbound_reference_validation"
    return record, "raw_snapshot"


def fingerprint(record: dict) -> dict:
    record, envelope = unwrap(record)
    if record.get("schema") != SCHEMA:
        raise HSIRWireRejected("E_HSIR_SCHEMA")
    name, profile = None, None
    for candidate, settings in PROFILES.items():
        field, value = settings["discriminator"]
        if record.get(field) == value:
            if name is not None:
                raise HSIRWireRejected("E_HSIR_AMBIGUOUS_PROFILE")
            name, profile = candidate, settings
    if profile is None or ("profile" in record and "status" in record):
        raise HSIRWireRejected("E_HSIR_UNKNOWN_PROFILE")
    # A rehashed unknown field must not slip through as an accepted version.
    # This audit never treats a recognized layout as semantic equivalence.
    actual_fields = set(record)
    if PROFILE_LAYOUTS[name] - actual_fields:
        raise HSIRWireRejected("E_HSIR_MISSING_FIELDS")
    if actual_fields - PROFILE_LAYOUTS[name]:
        raise HSIRWireRejected("E_HSIR_UNKNOWN_FIELDS")
    if not isinstance(record.get("functions"), list):
        raise HSIRWireRejected("E_HSIR_INVALID_FUNCTIONS")
    if not isinstance(record.get("source_sha256"), str) or not SHA256.fullmatch(record["source_sha256"]):
        raise HSIRWireRejected("E_HSIR_SOURCE_ID")
    if name == "source_bound_dict_v0":
        project = record["project_sha256"]
        if project is not None and (not isinstance(project, str) or not SHA256.fullmatch(project)):
            raise HSIRWireRejected("E_HSIR_PROJECT_ID")
        if type(record["all_expressions_typed"]) is not bool:
            raise HSIRWireRejected("E_HSIR_TYPE_COMPLETENESS")
        require_unresolved_obligations(record["external_obligations"])
    else:
        if type(record["typed_expression_count"]) is not int or record["typed_expression_count"] < 0:
            raise HSIRWireRejected("E_HSIR_TYPE_COUNT")
        require_unproved_external_assumptions(record["external_assumptions"])
    claims = record.get("claims")
    if (type(claims) is not dict or set(claims) != set(profile["denied_claims"])
            or not all(claims.get(k) is False for k in profile["denied_claims"])):
        raise HSIRWireRejected("E_HSIR_UNSUPPORTED_PROOF_CLAIM")
    if any(value is not False for value in claims.values()):
        raise HSIRWireRejected("E_HSIR_UNRECOGNIZED_PROOF_CLAIM")
    supplied = record.get("sha256")
    if not isinstance(supplied, str) or not SHA256.fullmatch(supplied):
        raise HSIRWireRejected("E_HSIR_DIGEST")
    unsigned = {k: v for k, v in record.items() if k != "sha256"}
    try:
        canonical = json.dumps(unsigned, sort_keys=True, separators=(",", ":"),
                               ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        raise HSIRWireRejected("E_HSIR_NOT_CANONICALIZABLE") from exc
    actual = hashlib.sha256(canonical).hexdigest()
    if supplied != actual:
        raise HSIRWireRejected("E_HSIR_DIGEST_MISMATCH")
    return {"wire_profile": name, "schema": SCHEMA,
            "presentation_envelope": envelope,
            "external_validation_metadata_unbound_to_payload": envelope != "raw_snapshot",
            "source_sha256": record["source_sha256"],
            "project_identity_present": bool(record.get("project_sha256")),
            "sha256": supplied, "checked_native": False,
            "whole_language_soundness_proved": False}


def compare(left: dict, right: dict) -> dict:
    a, b = fingerprint(left), fingerprint(right)
    collision = a["wire_profile"] != b["wire_profile"]
    return {"schema": "hepta.hsir-wire-review.v1", "left": a, "right": b,
            "same_schema_different_wire_format": collision,
            "wire_layout_status": "incompatible_requires_versioned_adapter" if collision
                                  else "same_format_only_not_semantic_equivalence",
            "safe_to_mix_without_adapter": False,
            "automatic_merge_approved": False,
            "whole_project_blockers_closed": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--left", required=True)
    parser.add_argument("--right", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        report = compare(load(args.left), load(args.right))
        with open(args.output, "x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2, sort_keys=True)
            stream.write("\n")
        print(report["wire_layout_status"])
        return 3 if report["same_schema_different_wire_format"] else 0
    except (HSIRWireRejected, OSError, ValueError, RecursionError) as exc:
        print("E_HSIR_WIRE_AUDIT: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
