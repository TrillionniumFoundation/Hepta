
/home/qian-qi/work/hia-evidence-20261103/empty-wrapper-observation-1dfbfd1-r1/affine/rust_byte_release.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011c0 <calculate>:
    11c0:	48 85 ff             	test   %rdi,%rdi
    11c3:	75 03                	jne    11c8 <calculate+0x8>
    11c5:	31 c0                	xor    %eax,%eax
    11c7:	c3                   	ret
    11c8:	55                   	push   %rbp
    11c9:	41 57                	push   %r15
    11cb:	41 56                	push   %r14
    11cd:	53                   	push   %rbx
    11ce:	48 83 ec 18          	sub    $0x18,%rsp
    11d2:	89 f5                	mov    %esi,%ebp
    11d4:	48 89 e0             	mov    %rsp,%rax
    11d7:	ba 01 00 00 00       	mov    $0x1,%edx
    11dc:	48 89 f9             	mov    %rdi,%rcx
    11df:	48 89 c7             	mov    %rax,%rdi
    11e2:	31 f6                	xor    %esi,%esi
    11e4:	49 89 cf             	mov    %rcx,%r15
    11e7:	e8 a4 fe ff ff       	call   1090 <_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h9c6abdfc189ff6fdE>
    11ec:	80 3c 24 00          	cmpb   $0x0,(%rsp)
    11f0:	74 0a                	je     11fc <calculate+0x3c>
    11f2:	b8 e9 03 00 00       	mov    $0x3e9,%eax
    11f7:	e9 72 02 00 00       	jmp    146e <calculate+0x2ae>
    11fc:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    1201:	49 83 ff 01          	cmp    $0x1,%r15
    1205:	75 14                	jne    121b <calculate+0x5b>
    1207:	c6 03 00             	movb   $0x0,(%rbx)
    120a:	48 8d 73 01          	lea    0x1(%rbx),%rsi
    120e:	ba 01 00 00 00       	mov    $0x1,%edx
    1213:	40 b7 01             	mov    $0x1,%dil
    1216:	45 31 f6             	xor    %r14d,%r14d
    1219:	eb 29                	jmp    1244 <calculate+0x84>
    121b:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
    121f:	45 31 f6             	xor    %r14d,%r14d
    1222:	48 89 df             	mov    %rbx,%rdi
    1225:	31 f6                	xor    %esi,%esi
    1227:	ff 15 93 3d 00 00    	call   *0x3d93(%rip)        # 4fc0 <memset@GLIBC_2.2.5>
    122d:	4c 89 fa             	mov    %r15,%rdx
    1230:	42 c6 44 3b ff 00    	movb   $0x0,-0x1(%rbx,%r15,1)
    1236:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    123a:	49 83 ff 08          	cmp    $0x8,%r15
    123e:	40 0f 92 c7          	setb   %dil
    1242:	73 30                	jae    1274 <calculate+0xb4>
    1244:	49 89 d9             	mov    %rbx,%r9
    1247:	89 e9                	mov    %ebp,%ecx
    1249:	89 c8                	mov    %ecx,%eax
    124b:	41 f6 e6             	mul    %r14b
    124e:	04 11                	add    $0x11,%al
    1250:	41 88 01             	mov    %al,(%r9)
    1253:	49 ff c1             	inc    %r9
    1256:	00 c8                	add    %cl,%al
    1258:	49 39 f1             	cmp    %rsi,%r9
    125b:	75 f3                	jne    1250 <calculate+0x90>
    125d:	89 d0                	mov    %edx,%eax
    125f:	83 e0 07             	and    $0x7,%eax
    1262:	40 84 ff             	test   %dil,%dil
    1265:	0f 84 7d 01 00 00    	je     13e8 <calculate+0x228>
    126b:	31 d2                	xor    %edx,%edx
    126d:	31 c9                	xor    %ecx,%ecx
    126f:	e9 cb 01 00 00       	jmp    143f <calculate+0x27f>
    1274:	89 e9                	mov    %ebp,%ecx
    1276:	0f b6 c1             	movzbl %cl,%eax
    1279:	48 83 fa 20          	cmp    $0x20,%rdx
    127d:	73 08                	jae    1287 <calculate+0xc7>
    127f:	45 31 f6             	xor    %r14d,%r14d
    1282:	e9 df 00 00 00       	jmp    1366 <calculate+0x1a6>
    1287:	49 89 d6             	mov    %rdx,%r14
    128a:	49 83 e6 e0          	and    $0xffffffffffffffe0,%r14
    128e:	66 0f 6e c0          	movd   %eax,%xmm0
    1292:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1296:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    129b:	66 0f 70 c0 44       	pshufd $0x44,%xmm0,%xmm0
    12a0:	66 0f 6f 0d 58 1d 00 	movdqa 0x1d58(%rip),%xmm1        # 3000 <_fini+0xe28>
    12a7:	00 
    12a8:	45 31 c0             	xor    %r8d,%r8d
    12ab:	66 0f 6f 15 5d 1d 00 	movdqa 0x1d5d(%rip),%xmm2        # 3010 <_fini+0xe38>
    12b2:	00 
    12b3:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    12b7:	66 0f 68 db          	punpckhbw %xmm3,%xmm3
    12bb:	66 0f 6f 25 5d 1d 00 	movdqa 0x1d5d(%rip),%xmm4        # 3020 <_fini+0xe48>
    12c2:	00 
    12c3:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    12c7:	66 0f 6f 2d 61 1d 00 	movdqa 0x1d61(%rip),%xmm5        # 3030 <_fini+0xe58>
    12ce:	00 
    12cf:	66 0f 6f 35 69 1d 00 	movdqa 0x1d69(%rip),%xmm6        # 3040 <_fini+0xe68>
    12d6:	00 
    12d7:	66 0f 6f f9          	movdqa %xmm1,%xmm7
    12db:	66 0f fc fa          	paddb  %xmm2,%xmm7
    12df:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    12e4:	66 45 0f 68 c0       	punpckhbw %xmm8,%xmm8
    12e9:	66 44 0f d5 c3       	pmullw %xmm3,%xmm8
    12ee:	66 44 0f db c4       	pand   %xmm4,%xmm8
    12f3:	66 44 0f 6f c9       	movdqa %xmm1,%xmm9
    12f8:	66 45 0f 60 c9       	punpcklbw %xmm9,%xmm9
    12fd:	66 44 0f d5 c8       	pmullw %xmm0,%xmm9
    1302:	66 44 0f db cc       	pand   %xmm4,%xmm9
    1307:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    130c:	66 44 0f 6f c7       	movdqa %xmm7,%xmm8
    1311:	66 45 0f 68 c0       	punpckhbw %xmm8,%xmm8
    1316:	66 44 0f d5 c3       	pmullw %xmm3,%xmm8
    131b:	66 44 0f db c4       	pand   %xmm4,%xmm8
    1320:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    1324:	66 0f d5 f8          	pmullw %xmm0,%xmm7
    1328:	66 0f db fc          	pand   %xmm4,%xmm7
    132c:	66 41 0f 67 f8       	packuswb %xmm8,%xmm7
    1331:	66 44 0f fc cd       	paddb  %xmm5,%xmm9
    1336:	66 0f fc fd          	paddb  %xmm5,%xmm7
    133a:	f3 46 0f 7f 0c 03    	movdqu %xmm9,(%rbx,%r8,1)
    1340:	f3 42 0f 7f 7c 03 10 	movdqu %xmm7,0x10(%rbx,%r8,1)
    1347:	49 83 c0 20          	add    $0x20,%r8
    134b:	66 0f fc ce          	paddb  %xmm6,%xmm1
    134f:	4d 39 c6             	cmp    %r8,%r14
    1352:	75 83                	jne    12d7 <calculate+0x117>
    1354:	4c 39 f2             	cmp    %r14,%rdx
    1357:	0f 84 86 00 00 00    	je     13e3 <calculate+0x223>
    135d:	f6 c2 18             	test   $0x18,%dl
    1360:	0f 84 1f 01 00 00    	je     1485 <calculate+0x2c5>
    1366:	49 89 d0             	mov    %rdx,%r8
    1369:	49 83 e0 f8          	and    $0xfffffffffffffff8,%r8
    136d:	66 0f 6e c0          	movd   %eax,%xmm0
    1371:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1375:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    137a:	41 0f b6 c6          	movzbl %r14b,%eax
    137e:	66 0f 6e c8          	movd   %eax,%xmm1
    1382:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1386:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    138b:	66 0f fc 0d bd 1c 00 	paddb  0x1cbd(%rip),%xmm1        # 3050 <_fini+0xe78>
    1392:	00 
    1393:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1397:	66 0f 6f 15 81 1c 00 	movdqa 0x1c81(%rip),%xmm2        # 3020 <_fini+0xe48>
    139e:	00 
    139f:	66 0f 6f 1d b9 1c 00 	movdqa 0x1cb9(%rip),%xmm3        # 3060 <_fini+0xe88>
    13a6:	00 
    13a7:	66 0f 6f 25 c1 1c 00 	movdqa 0x1cc1(%rip),%xmm4        # 3070 <_fini+0xe98>
    13ae:	00 
    13af:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    13b3:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    13b7:	66 0f d5 e8          	pmullw %xmm0,%xmm5
    13bb:	66 0f db ea          	pand   %xmm2,%xmm5
    13bf:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    13c3:	66 0f fc eb          	paddb  %xmm3,%xmm5
    13c7:	66 42 0f d6 2c 33    	movq   %xmm5,(%rbx,%r14,1)
    13cd:	49 83 c6 08          	add    $0x8,%r14
    13d1:	66 0f fc cc          	paddb  %xmm4,%xmm1
    13d5:	4d 39 f0             	cmp    %r14,%r8
    13d8:	75 d5                	jne    13af <calculate+0x1ef>
    13da:	4c 39 c2             	cmp    %r8,%rdx
    13dd:	0f 85 96 00 00 00    	jne    1479 <calculate+0x2b9>
    13e3:	89 d0                	mov    %edx,%eax
    13e5:	83 e0 07             	and    $0x7,%eax
    13e8:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
    13ec:	31 c9                	xor    %ecx,%ecx
    13ee:	31 f6                	xor    %esi,%esi
    13f0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
    13f4:	48 01 cf             	add    %rcx,%rdi
    13f7:	0f b6 4c 33 01       	movzbl 0x1(%rbx,%rsi,1),%ecx
    13fc:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
    1402:	49 01 c8             	add    %rcx,%r8
    1405:	49 01 f8             	add    %rdi,%r8
    1408:	0f b6 4c 33 03       	movzbl 0x3(%rbx,%rsi,1),%ecx
    140d:	0f b6 7c 33 04       	movzbl 0x4(%rbx,%rsi,1),%edi
    1412:	48 01 cf             	add    %rcx,%rdi
    1415:	44 0f b6 4c 33 05    	movzbl 0x5(%rbx,%rsi,1),%r9d
    141b:	49 01 f9             	add    %rdi,%r9
    141e:	4d 01 c1             	add    %r8,%r9
    1421:	0f b6 7c 33 06       	movzbl 0x6(%rbx,%rsi,1),%edi
    1426:	0f b6 4c 33 07       	movzbl 0x7(%rbx,%rsi,1),%ecx
    142b:	48 01 f9             	add    %rdi,%rcx
    142e:	4c 01 c9             	add    %r9,%rcx
    1431:	48 83 c6 08          	add    $0x8,%rsi
    1435:	48 39 f2             	cmp    %rsi,%rdx
    1438:	75 b6                	jne    13f0 <calculate+0x230>
    143a:	48 85 c0             	test   %rax,%rax
    143d:	74 20                	je     145f <calculate+0x29f>
    143f:	48 01 da             	add    %rbx,%rdx
    1442:	31 f6                	xor    %esi,%esi
    1444:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    144b:	00 00 00 00 00 
    1450:	0f b6 3c 32          	movzbl (%rdx,%rsi,1),%edi
    1454:	48 01 f9             	add    %rdi,%rcx
    1457:	48 ff c6             	inc    %rsi
    145a:	48 39 f0             	cmp    %rsi,%rax
    145d:	75 f1                	jne    1450 <calculate+0x290>
    145f:	48 89 df             	mov    %rbx,%rdi
    1462:	48 89 cb             	mov    %rcx,%rbx
    1465:	ff 15 5d 3b 00 00    	call   *0x3b5d(%rip)        # 4fc8 <_GLOBAL_OFFSET_TABLE_+0x58>
    146b:	48 89 d8             	mov    %rbx,%rax
    146e:	48 83 c4 18          	add    $0x18,%rsp
    1472:	5b                   	pop    %rbx
    1473:	41 5e                	pop    %r14
    1475:	41 5f                	pop    %r15
    1477:	5d                   	pop    %rbp
    1478:	c3                   	ret
    1479:	4e 8d 0c 03          	lea    (%rbx,%r8,1),%r9
    147d:	45 89 c6             	mov    %r8d,%r14d
    1480:	e9 c4 fd ff ff       	jmp    1249 <calculate+0x89>
    1485:	4d 89 f1             	mov    %r14,%r9
    1488:	49 01 d9             	add    %rbx,%r9
    148b:	e9 b9 fd ff ff       	jmp    1249 <calculate+0x89>

Disassembly of section .fini:
