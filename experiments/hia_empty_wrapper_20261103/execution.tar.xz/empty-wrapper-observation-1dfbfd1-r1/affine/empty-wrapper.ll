; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i64 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = icmp ule i64 %p_1_0, 72340172838076673
  br i1 %t2, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %t3 = call %hia.alloc @__hia_allocate(i64 %p_2_0, i1 false)
  %t4 = extractvalue %hia.alloc %t3, 0
  %t5 = extractvalue %hia.alloc %t3, 1
  %t6 = select i1 %t5, i64 %p_2_0, i64 0
  %t7 = insertvalue %hia.buffer %t4, i64 %t6, 1
  br i1 %t5, label %edge_4, label %edge_5
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_4 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_3_2 = phi i1 [ %t5, %edge_4 ]
  %p_3_3 = phi %hia.buffer [ %t7, %edge_4 ]
  %p_3_4 = phi i8 [ 1, %edge_4 ]
  br label %edge_6
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_5 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_5 ]
  %p_4_2 = phi i1 [ %t5, %edge_5 ]
  %p_4_3 = phi %hia.buffer [ %t7, %edge_5 ]
  %p_4_4 = phi i8 [ 1, %edge_5 ]
  %t8 = extractvalue %hia.buffer %p_4_3, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  call void @free(ptr %t8) nobuiltin
  br label %drop_after_10
drop_after_10:
  %t11 = zext i8 %p_4_4 to i64
  %t12 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t11)
  %t13 = extractvalue { i64, i1 } %t12, 0
  %t14 = extractvalue { i64, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  ret i64 %t13
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_6 ], [ %p_6_0, %edge_9 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_6 ], [ %p_6_1, %edge_9 ]
  %p_5_2 = phi %hia.buffer [ %p_3_3, %edge_6 ], [ %p_6_2, %edge_9 ]
  %p_5_3 = phi i64 [ %p_3_0, %edge_6 ], [ %p_6_3, %edge_9 ]
  %p_5_4 = phi i64 [ 0, %edge_6 ], [ %t30, %edge_9 ]
  %t17 = icmp ult i64 %p_5_4, %p_5_3
  br i1 %t17, label %edge_7, label %edge_8
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_7 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_6_3 = phi i64 [ %p_5_3, %edge_7 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_7 ]
  %t18 = trunc i64 %p_6_4 to i32
  %t19 = mul i32 %t18, %p_6_1
  %t20 = add i32 %t19, 17
  %t21 = trunc i64 %p_6_4 to i8
  %t22 = trunc i32 %p_6_1 to i8
  %t23 = mul i8 %t21, %t22
  %t24 = add i8 %t23, 17
  %t25 = extractvalue %hia.buffer %p_6_2, 0
  %t26 = extractvalue %hia.buffer %p_6_2, 1
  %t27 = icmp ult i64 %p_6_4, %t26
  br i1 %t27, label %ok_28, label %trap_28
trap_28:
  call void @abort()
  unreachable
ok_28:
  %t29 = getelementptr i8, ptr %t25, i64 %p_6_4
  store i8 %t24, ptr %t29, align 1
  %t30 = add i64 %p_6_4, 1
  br label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_8 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_8 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_8 ]
  %p_7_3 = phi i64 [ %p_5_3, %edge_8 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_8 ]
  br label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_10 ], [ %p_9_0, %edge_13 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_10 ], [ %p_9_1, %edge_13 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_10 ], [ %p_9_2, %edge_13 ]
  %p_8_3 = phi i64 [ 0, %edge_10 ], [ %t39, %edge_13 ]
  %p_8_4 = phi i64 [ %p_7_0, %edge_10 ], [ %p_9_4, %edge_13 ]
  %p_8_5 = phi i64 [ 0, %edge_10 ], [ %t40, %edge_13 ]
  %t31 = icmp ult i64 %p_8_5, %p_8_4
  br i1 %t31, label %edge_11, label %edge_12
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_11 ]
  %p_9_1 = phi i32 [ %p_8_1, %edge_11 ]
  %p_9_2 = phi %hia.buffer [ %p_8_2, %edge_11 ]
  %p_9_3 = phi i64 [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i64 [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_11 ]
  %t32 = extractvalue %hia.buffer %p_9_2, 0
  %t33 = extractvalue %hia.buffer %p_9_2, 1
  %t34 = icmp ult i64 %p_9_5, %t33
  br i1 %t34, label %ok_35, label %trap_35
trap_35:
  call void @abort()
  unreachable
ok_35:
  %t36 = getelementptr i8, ptr %t32, i64 %p_9_5
  %t37 = load i8, ptr %t36, align 1
  %t38 = zext i8 %t37 to i64
  %t39 = add i64 %p_9_3, %t38
  %t40 = add i64 %p_9_5, 1
  br label %edge_13
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_12 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_12 ]
  %p_10_2 = phi %hia.buffer [ %p_8_2, %edge_12 ]
  %p_10_3 = phi i64 [ %p_8_3, %edge_12 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_12 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_12 ]
  %t41 = extractvalue %hia.buffer %p_10_2, 0
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %drop_nonnull_43, label %drop_after_43
drop_nonnull_43:
  call void @free(ptr %t41) nobuiltin
  br label %drop_after_43
drop_after_43:
  ret i64 %p_10_3
b11:
  %p_11_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_11_1 = phi i32 [ %p_1_1, %edge_3 ]
  %t44 = call %hia.alloc @__hia_allocate(i64 %p_11_0, i1 false)
  %t45 = extractvalue %hia.alloc %t44, 0
  %t46 = extractvalue %hia.alloc %t44, 1
  %t47 = select i1 %t46, i64 %p_11_0, i64 0
  %t48 = insertvalue %hia.buffer %t45, i64 %t47, 1
  br i1 %t46, label %edge_14, label %edge_15
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_14 ]
  %p_12_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_12_2 = phi i1 [ %t46, %edge_14 ]
  %p_12_3 = phi %hia.buffer [ %t48, %edge_14 ]
  %p_12_4 = phi i8 [ 1, %edge_14 ]
  br label %edge_16
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_15 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_15 ]
  %p_13_2 = phi i1 [ %t46, %edge_15 ]
  %p_13_3 = phi %hia.buffer [ %t48, %edge_15 ]
  %p_13_4 = phi i8 [ 1, %edge_15 ]
  %t49 = extractvalue %hia.buffer %p_13_3, 0
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %drop_nonnull_51, label %drop_after_51
drop_nonnull_51:
  call void @free(ptr %t49) nobuiltin
  br label %drop_after_51
drop_after_51:
  %t52 = zext i8 %p_13_4 to i64
  %t53 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t52)
  %t54 = extractvalue { i64, i1 } %t53, 0
  %t55 = extractvalue { i64, i1 } %t53, 1
  %t56 = xor i1 %t55, true
  br i1 %t56, label %ok_57, label %trap_57
trap_57:
  call void @abort()
  unreachable
ok_57:
  ret i64 %t54
b14:
  %p_14_0 = phi i64 [ %p_12_0, %edge_16 ], [ %p_15_0, %edge_19 ]
  %p_14_1 = phi i32 [ %p_12_1, %edge_16 ], [ %p_15_1, %edge_19 ]
  %p_14_2 = phi %hia.buffer [ %p_12_3, %edge_16 ], [ %p_15_2, %edge_19 ]
  %p_14_3 = phi i64 [ %p_12_0, %edge_16 ], [ %p_15_3, %edge_19 ]
  %p_14_4 = phi i64 [ 0, %edge_16 ], [ %t72, %edge_19 ]
  %t58 = icmp ult i64 %p_14_4, %p_14_3
  br i1 %t58, label %edge_17, label %edge_18
b15:
  %p_15_0 = phi i64 [ %p_14_0, %edge_17 ]
  %p_15_1 = phi i32 [ %p_14_1, %edge_17 ]
  %p_15_2 = phi %hia.buffer [ %p_14_2, %edge_17 ]
  %p_15_3 = phi i64 [ %p_14_3, %edge_17 ]
  %p_15_4 = phi i64 [ %p_14_4, %edge_17 ]
  %t59 = trunc i64 %p_15_4 to i32
  %t60 = mul i32 %t59, %p_15_1
  %t61 = add i32 %t60, 17
  %t62 = trunc i64 %p_15_4 to i8
  %t63 = trunc i32 %p_15_1 to i8
  %t64 = mul i8 %t62, %t63
  %t65 = add i8 %t64, 17
  %t66 = extractvalue %hia.buffer %p_15_2, 0
  %t67 = extractvalue %hia.buffer %p_15_2, 1
  %t68 = icmp ult i64 %p_15_4, %t67
  br i1 %t68, label %ok_69, label %trap_69
trap_69:
  call void @abort()
  unreachable
ok_69:
  %t70 = getelementptr i8, ptr %t66, i64 %p_15_4
  store i8 %t65, ptr %t70, align 1
  %t71 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_15_4, i64 1)
  %t72 = extractvalue { i64, i1 } %t71, 0
  %t73 = extractvalue { i64, i1 } %t71, 1
  %t74 = xor i1 %t73, true
  br i1 %t74, label %ok_75, label %trap_75
trap_75:
  call void @abort()
  unreachable
ok_75:
  br label %edge_19
b16:
  %p_16_0 = phi i64 [ %p_14_0, %edge_18 ]
  %p_16_1 = phi i32 [ %p_14_1, %edge_18 ]
  %p_16_2 = phi %hia.buffer [ %p_14_2, %edge_18 ]
  %p_16_3 = phi i64 [ %p_14_3, %edge_18 ]
  %p_16_4 = phi i64 [ %p_14_4, %edge_18 ]
  br label %edge_20
b17:
  %p_17_0 = phi i64 [ %p_16_0, %edge_20 ], [ %p_18_0, %edge_23 ]
  %p_17_1 = phi i32 [ %p_16_1, %edge_20 ], [ %p_18_1, %edge_23 ]
  %p_17_2 = phi %hia.buffer [ %p_16_2, %edge_20 ], [ %p_18_2, %edge_23 ]
  %p_17_3 = phi i64 [ 0, %edge_20 ], [ %t85, %edge_23 ]
  %p_17_4 = phi i64 [ %p_16_0, %edge_20 ], [ %p_18_4, %edge_23 ]
  %p_17_5 = phi i64 [ 0, %edge_20 ], [ %t90, %edge_23 ]
  %t76 = icmp ult i64 %p_17_5, %p_17_4
  br i1 %t76, label %edge_21, label %edge_22
b18:
  %p_18_0 = phi i64 [ %p_17_0, %edge_21 ]
  %p_18_1 = phi i32 [ %p_17_1, %edge_21 ]
  %p_18_2 = phi %hia.buffer [ %p_17_2, %edge_21 ]
  %p_18_3 = phi i64 [ %p_17_3, %edge_21 ]
  %p_18_4 = phi i64 [ %p_17_4, %edge_21 ]
  %p_18_5 = phi i64 [ %p_17_5, %edge_21 ]
  %t77 = extractvalue %hia.buffer %p_18_2, 0
  %t78 = extractvalue %hia.buffer %p_18_2, 1
  %t79 = icmp ult i64 %p_18_5, %t78
  br i1 %t79, label %ok_80, label %trap_80
trap_80:
  call void @abort()
  unreachable
ok_80:
  %t81 = getelementptr i8, ptr %t77, i64 %p_18_5
  %t82 = load i8, ptr %t81, align 1
  %t83 = zext i8 %t82 to i64
  %t84 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_18_3, i64 %t83)
  %t85 = extractvalue { i64, i1 } %t84, 0
  %t86 = extractvalue { i64, i1 } %t84, 1
  %t87 = xor i1 %t86, true
  br i1 %t87, label %ok_88, label %trap_88
trap_88:
  call void @abort()
  unreachable
ok_88:
  %t89 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_18_5, i64 1)
  %t90 = extractvalue { i64, i1 } %t89, 0
  %t91 = extractvalue { i64, i1 } %t89, 1
  %t92 = xor i1 %t91, true
  br i1 %t92, label %ok_93, label %trap_93
trap_93:
  call void @abort()
  unreachable
ok_93:
  br label %edge_23
b19:
  %p_19_0 = phi i64 [ %p_17_0, %edge_22 ]
  %p_19_1 = phi i32 [ %p_17_1, %edge_22 ]
  %p_19_2 = phi %hia.buffer [ %p_17_2, %edge_22 ]
  %p_19_3 = phi i64 [ %p_17_3, %edge_22 ]
  %p_19_4 = phi i64 [ %p_17_4, %edge_22 ]
  %p_19_5 = phi i64 [ %p_17_5, %edge_22 ]
  %t94 = extractvalue %hia.buffer %p_19_2, 0
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %drop_nonnull_96, label %drop_after_96
drop_nonnull_96:
  call void @free(ptr %t94) nobuiltin
  br label %drop_after_96
drop_after_96:
  ret i64 %p_19_3
b20:
  %p_20_0 = phi i64 [ 0, %edge_0 ]
  %p_20_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t97 = icmp ule i64 %p_20_0, 72340172838076673
  br i1 %t97, label %edge_24, label %edge_25
b21:
  %p_21_0 = phi i64 [ %p_20_0, %edge_24 ]
  %p_21_1 = phi i32 [ %p_20_1, %edge_24 ]
  %t98 = call %hia.alloc @__hia_allocate(i64 %p_21_0, i1 false)
  %t99 = extractvalue %hia.alloc %t98, 0
  %t100 = extractvalue %hia.alloc %t98, 1
  %t101 = select i1 %t100, i64 %p_21_0, i64 0
  %t102 = insertvalue %hia.buffer %t99, i64 %t101, 1
  br i1 %t100, label %edge_26, label %edge_27
b22:
  %p_22_0 = phi i64 [ %p_21_0, %edge_26 ]
  %p_22_1 = phi i32 [ %p_21_1, %edge_26 ]
  %p_22_2 = phi i1 [ %t100, %edge_26 ]
  %p_22_3 = phi %hia.buffer [ %t102, %edge_26 ]
  %p_22_4 = phi i8 [ 1, %edge_26 ]
  br label %edge_28
b23:
  %p_23_0 = phi i64 [ %p_21_0, %edge_27 ]
  %p_23_1 = phi i32 [ %p_21_1, %edge_27 ]
  %p_23_2 = phi i1 [ %t100, %edge_27 ]
  %p_23_3 = phi %hia.buffer [ %t102, %edge_27 ]
  %p_23_4 = phi i8 [ 1, %edge_27 ]
  %t103 = extractvalue %hia.buffer %p_23_3, 0
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %drop_nonnull_105, label %drop_after_105
drop_nonnull_105:
  call void @free(ptr %t103) nobuiltin
  br label %drop_after_105
drop_after_105:
  %t106 = zext i8 %p_23_4 to i64
  %t107 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t106)
  %t108 = extractvalue { i64, i1 } %t107, 0
  %t109 = extractvalue { i64, i1 } %t107, 1
  %t110 = xor i1 %t109, true
  br i1 %t110, label %ok_111, label %trap_111
trap_111:
  call void @abort()
  unreachable
ok_111:
  ret i64 %t108
b24:
  %p_24_0 = phi i64 [ %p_22_0, %edge_28 ], [ %p_25_0, %edge_31 ]
  %p_24_1 = phi i32 [ %p_22_1, %edge_28 ], [ %p_25_1, %edge_31 ]
  %p_24_2 = phi %hia.buffer [ %p_22_3, %edge_28 ], [ %p_25_2, %edge_31 ]
  %p_24_3 = phi i64 [ %p_22_0, %edge_28 ], [ %p_25_3, %edge_31 ]
  %p_24_4 = phi i64 [ 0, %edge_28 ], [ %t125, %edge_31 ]
  %t112 = icmp ult i64 %p_24_4, %p_24_3
  br i1 %t112, label %edge_29, label %edge_30
b25:
  %p_25_0 = phi i64 [ %p_24_0, %edge_29 ]
  %p_25_1 = phi i32 [ %p_24_1, %edge_29 ]
  %p_25_2 = phi %hia.buffer [ %p_24_2, %edge_29 ]
  %p_25_3 = phi i64 [ %p_24_3, %edge_29 ]
  %p_25_4 = phi i64 [ %p_24_4, %edge_29 ]
  %t113 = trunc i64 %p_25_4 to i32
  %t114 = mul i32 %t113, %p_25_1
  %t115 = add i32 %t114, 17
  %t116 = trunc i64 %p_25_4 to i8
  %t117 = trunc i32 %p_25_1 to i8
  %t118 = mul i8 %t116, %t117
  %t119 = add i8 %t118, 17
  %t120 = extractvalue %hia.buffer %p_25_2, 0
  %t121 = extractvalue %hia.buffer %p_25_2, 1
  %t122 = icmp ult i64 %p_25_4, %t121
  br i1 %t122, label %ok_123, label %trap_123
trap_123:
  call void @abort()
  unreachable
ok_123:
  %t124 = getelementptr i8, ptr %t120, i64 %p_25_4
  store i8 %t119, ptr %t124, align 1
  %t125 = add i64 %p_25_4, 1
  br label %edge_31
b26:
  %p_26_0 = phi i64 [ %p_24_0, %edge_30 ]
  %p_26_1 = phi i32 [ %p_24_1, %edge_30 ]
  %p_26_2 = phi %hia.buffer [ %p_24_2, %edge_30 ]
  %p_26_3 = phi i64 [ %p_24_3, %edge_30 ]
  %p_26_4 = phi i64 [ %p_24_4, %edge_30 ]
  br label %edge_32
b27:
  %p_27_0 = phi i64 [ %p_26_0, %edge_32 ], [ %p_28_0, %edge_35 ]
  %p_27_1 = phi i32 [ %p_26_1, %edge_32 ], [ %p_28_1, %edge_35 ]
  %p_27_2 = phi %hia.buffer [ %p_26_2, %edge_32 ], [ %p_28_2, %edge_35 ]
  %p_27_3 = phi i64 [ 0, %edge_32 ], [ %t134, %edge_35 ]
  %p_27_4 = phi i64 [ %p_26_0, %edge_32 ], [ %p_28_4, %edge_35 ]
  %p_27_5 = phi i64 [ 0, %edge_32 ], [ %t135, %edge_35 ]
  %t126 = icmp ult i64 %p_27_5, %p_27_4
  br i1 %t126, label %edge_33, label %edge_34
b28:
  %p_28_0 = phi i64 [ %p_27_0, %edge_33 ]
  %p_28_1 = phi i32 [ %p_27_1, %edge_33 ]
  %p_28_2 = phi %hia.buffer [ %p_27_2, %edge_33 ]
  %p_28_3 = phi i64 [ %p_27_3, %edge_33 ]
  %p_28_4 = phi i64 [ %p_27_4, %edge_33 ]
  %p_28_5 = phi i64 [ %p_27_5, %edge_33 ]
  %t127 = extractvalue %hia.buffer %p_28_2, 0
  %t128 = extractvalue %hia.buffer %p_28_2, 1
  %t129 = icmp ult i64 %p_28_5, %t128
  br i1 %t129, label %ok_130, label %trap_130
trap_130:
  call void @abort()
  unreachable
ok_130:
  %t131 = getelementptr i8, ptr %t127, i64 %p_28_5
  %t132 = load i8, ptr %t131, align 1
  %t133 = zext i8 %t132 to i64
  %t134 = add i64 %p_28_3, %t133
  %t135 = add i64 %p_28_5, 1
  br label %edge_35
b29:
  %p_29_0 = phi i64 [ %p_27_0, %edge_34 ]
  %p_29_1 = phi i32 [ %p_27_1, %edge_34 ]
  %p_29_2 = phi %hia.buffer [ %p_27_2, %edge_34 ]
  %p_29_3 = phi i64 [ %p_27_3, %edge_34 ]
  %p_29_4 = phi i64 [ %p_27_4, %edge_34 ]
  %p_29_5 = phi i64 [ %p_27_5, %edge_34 ]
  %t136 = extractvalue %hia.buffer %p_29_2, 0
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %drop_nonnull_138, label %drop_after_138
drop_nonnull_138:
  call void @free(ptr %t136) nobuiltin
  br label %drop_after_138
drop_after_138:
  ret i64 %p_29_3
b30:
  %p_30_0 = phi i64 [ %p_20_0, %edge_25 ]
  %p_30_1 = phi i32 [ %p_20_1, %edge_25 ]
  %t139 = call %hia.alloc @__hia_allocate(i64 %p_30_0, i1 false)
  %t140 = extractvalue %hia.alloc %t139, 0
  %t141 = extractvalue %hia.alloc %t139, 1
  %t142 = select i1 %t141, i64 %p_30_0, i64 0
  %t143 = insertvalue %hia.buffer %t140, i64 %t142, 1
  br i1 %t141, label %edge_36, label %edge_37
b31:
  %p_31_0 = phi i64 [ %p_30_0, %edge_36 ]
  %p_31_1 = phi i32 [ %p_30_1, %edge_36 ]
  %p_31_2 = phi i1 [ %t141, %edge_36 ]
  %p_31_3 = phi %hia.buffer [ %t143, %edge_36 ]
  %p_31_4 = phi i8 [ 1, %edge_36 ]
  br label %edge_38
b32:
  %p_32_0 = phi i64 [ %p_30_0, %edge_37 ]
  %p_32_1 = phi i32 [ %p_30_1, %edge_37 ]
  %p_32_2 = phi i1 [ %t141, %edge_37 ]
  %p_32_3 = phi %hia.buffer [ %t143, %edge_37 ]
  %p_32_4 = phi i8 [ 1, %edge_37 ]
  %t144 = extractvalue %hia.buffer %p_32_3, 0
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %drop_nonnull_146, label %drop_after_146
drop_nonnull_146:
  call void @free(ptr %t144) nobuiltin
  br label %drop_after_146
drop_after_146:
  %t147 = zext i8 %p_32_4 to i64
  %t148 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t147)
  %t149 = extractvalue { i64, i1 } %t148, 0
  %t150 = extractvalue { i64, i1 } %t148, 1
  %t151 = xor i1 %t150, true
  br i1 %t151, label %ok_152, label %trap_152
trap_152:
  call void @abort()
  unreachable
ok_152:
  ret i64 %t149
b33:
  %p_33_0 = phi i64 [ %p_31_0, %edge_38 ], [ %p_34_0, %edge_41 ]
  %p_33_1 = phi i32 [ %p_31_1, %edge_38 ], [ %p_34_1, %edge_41 ]
  %p_33_2 = phi %hia.buffer [ %p_31_3, %edge_38 ], [ %p_34_2, %edge_41 ]
  %p_33_3 = phi i64 [ %p_31_0, %edge_38 ], [ %p_34_3, %edge_41 ]
  %p_33_4 = phi i64 [ 0, %edge_38 ], [ %t167, %edge_41 ]
  %t153 = icmp ult i64 %p_33_4, %p_33_3
  br i1 %t153, label %edge_39, label %edge_40
b34:
  %p_34_0 = phi i64 [ %p_33_0, %edge_39 ]
  %p_34_1 = phi i32 [ %p_33_1, %edge_39 ]
  %p_34_2 = phi %hia.buffer [ %p_33_2, %edge_39 ]
  %p_34_3 = phi i64 [ %p_33_3, %edge_39 ]
  %p_34_4 = phi i64 [ %p_33_4, %edge_39 ]
  %t154 = trunc i64 %p_34_4 to i32
  %t155 = mul i32 %t154, %p_34_1
  %t156 = add i32 %t155, 17
  %t157 = trunc i64 %p_34_4 to i8
  %t158 = trunc i32 %p_34_1 to i8
  %t159 = mul i8 %t157, %t158
  %t160 = add i8 %t159, 17
  %t161 = extractvalue %hia.buffer %p_34_2, 0
  %t162 = extractvalue %hia.buffer %p_34_2, 1
  %t163 = icmp ult i64 %p_34_4, %t162
  br i1 %t163, label %ok_164, label %trap_164
trap_164:
  call void @abort()
  unreachable
ok_164:
  %t165 = getelementptr i8, ptr %t161, i64 %p_34_4
  store i8 %t160, ptr %t165, align 1
  %t166 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_34_4, i64 1)
  %t167 = extractvalue { i64, i1 } %t166, 0
  %t168 = extractvalue { i64, i1 } %t166, 1
  %t169 = xor i1 %t168, true
  br i1 %t169, label %ok_170, label %trap_170
trap_170:
  call void @abort()
  unreachable
ok_170:
  br label %edge_41
b35:
  %p_35_0 = phi i64 [ %p_33_0, %edge_40 ]
  %p_35_1 = phi i32 [ %p_33_1, %edge_40 ]
  %p_35_2 = phi %hia.buffer [ %p_33_2, %edge_40 ]
  %p_35_3 = phi i64 [ %p_33_3, %edge_40 ]
  %p_35_4 = phi i64 [ %p_33_4, %edge_40 ]
  br label %edge_42
b36:
  %p_36_0 = phi i64 [ %p_35_0, %edge_42 ], [ %p_37_0, %edge_45 ]
  %p_36_1 = phi i32 [ %p_35_1, %edge_42 ], [ %p_37_1, %edge_45 ]
  %p_36_2 = phi %hia.buffer [ %p_35_2, %edge_42 ], [ %p_37_2, %edge_45 ]
  %p_36_3 = phi i64 [ 0, %edge_42 ], [ %t180, %edge_45 ]
  %p_36_4 = phi i64 [ %p_35_0, %edge_42 ], [ %p_37_4, %edge_45 ]
  %p_36_5 = phi i64 [ 0, %edge_42 ], [ %t185, %edge_45 ]
  %t171 = icmp ult i64 %p_36_5, %p_36_4
  br i1 %t171, label %edge_43, label %edge_44
b37:
  %p_37_0 = phi i64 [ %p_36_0, %edge_43 ]
  %p_37_1 = phi i32 [ %p_36_1, %edge_43 ]
  %p_37_2 = phi %hia.buffer [ %p_36_2, %edge_43 ]
  %p_37_3 = phi i64 [ %p_36_3, %edge_43 ]
  %p_37_4 = phi i64 [ %p_36_4, %edge_43 ]
  %p_37_5 = phi i64 [ %p_36_5, %edge_43 ]
  %t172 = extractvalue %hia.buffer %p_37_2, 0
  %t173 = extractvalue %hia.buffer %p_37_2, 1
  %t174 = icmp ult i64 %p_37_5, %t173
  br i1 %t174, label %ok_175, label %trap_175
trap_175:
  call void @abort()
  unreachable
ok_175:
  %t176 = getelementptr i8, ptr %t172, i64 %p_37_5
  %t177 = load i8, ptr %t176, align 1
  %t178 = zext i8 %t177 to i64
  %t179 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_37_3, i64 %t178)
  %t180 = extractvalue { i64, i1 } %t179, 0
  %t181 = extractvalue { i64, i1 } %t179, 1
  %t182 = xor i1 %t181, true
  br i1 %t182, label %ok_183, label %trap_183
trap_183:
  call void @abort()
  unreachable
ok_183:
  %t184 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_37_5, i64 1)
  %t185 = extractvalue { i64, i1 } %t184, 0
  %t186 = extractvalue { i64, i1 } %t184, 1
  %t187 = xor i1 %t186, true
  br i1 %t187, label %ok_188, label %trap_188
trap_188:
  call void @abort()
  unreachable
ok_188:
  br label %edge_45
b38:
  %p_38_0 = phi i64 [ %p_36_0, %edge_44 ]
  %p_38_1 = phi i32 [ %p_36_1, %edge_44 ]
  %p_38_2 = phi %hia.buffer [ %p_36_2, %edge_44 ]
  %p_38_3 = phi i64 [ %p_36_3, %edge_44 ]
  %p_38_4 = phi i64 [ %p_36_4, %edge_44 ]
  %p_38_5 = phi i64 [ %p_36_5, %edge_44 ]
  %t189 = extractvalue %hia.buffer %p_38_2, 0
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %drop_nonnull_191, label %drop_after_191
drop_nonnull_191:
  call void @free(ptr %t189) nobuiltin
  br label %drop_after_191
drop_after_191:
  ret i64 %p_38_3
edge_0:
  br label %b20
edge_1:
  br label %b1
edge_2:
  br label %b2
edge_3:
  br label %b11
edge_4:
  br label %b3
edge_5:
  br label %b4
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b5
edge_10:
  br label %b8
edge_11:
  br label %b9
edge_12:
  br label %b10
edge_13:
  br label %b8
edge_14:
  br label %b12
edge_15:
  br label %b13
edge_16:
  br label %b14
edge_17:
  br label %b15
edge_18:
  br label %b16
edge_19:
  br label %b14
edge_20:
  br label %b17
edge_21:
  br label %b18
edge_22:
  br label %b19
edge_23:
  br label %b17
edge_24:
  br label %b21
edge_25:
  br label %b30
edge_26:
  br label %b22
edge_27:
  br label %b23
edge_28:
  br label %b24
edge_29:
  br label %b25
edge_30:
  br label %b26
edge_31:
  br label %b24
edge_32:
  br label %b27
edge_33:
  br label %b28
edge_34:
  br label %b29
edge_35:
  br label %b27
edge_36:
  br label %b31
edge_37:
  br label %b32
edge_38:
  br label %b33
edge_39:
  br label %b34
edge_40:
  br label %b35
edge_41:
  br label %b33
edge_42:
  br label %b36
edge_43:
  br label %b37
edge_44:
  br label %b38
edge_45:
  br label %b36
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %is_empty = icmp eq i64 %a0, 0
  br i1 %is_empty, label %zero, label %ordinary
zero:
  %zero_result = call i64 @__hia_fn_0(i64 0, i32 %a1) alwaysinline
  ret i64 %zero_result
ordinary:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1) noinline
  ret i64 %result
}
