
/home/qian-qi/work/hia-evidence-20261103/empty-wrapper-observation-1dfbfd1-r1/affine/hia_empty_candidate.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001590 <calculate>:
    1590:	48 85 ff             	test   %rdi,%rdi
    1593:	0f 85 17 fc ff ff    	jne    11b0 <__hia_fn_0>
    1599:	31 c0                	xor    %eax,%eax
    159b:	c3                   	ret

Disassembly of section .fini:
