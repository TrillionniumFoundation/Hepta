; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i64 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = icmp ule i64 %p_1_0, 72340172838076673
  br i1 %t2, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %t3 = call %hia.alloc @__hia_allocate(i64 %p_2_0, i1 false)
  %t4 = extractvalue %hia.alloc %t3, 0
  %t5 = extractvalue %hia.alloc %t3, 1
  %t6 = select i1 %t5, i64 %p_2_0, i64 0
  %t7 = insertvalue %hia.buffer %t4, i64 %t6, 1
  br i1 %t5, label %edge_4, label %edge_5
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_4 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_3_2 = phi i1 [ %t5, %edge_4 ]
  %p_3_3 = phi %hia.buffer [ %t7, %edge_4 ]
  %p_3_4 = phi i8 [ 1, %edge_4 ]
  br label %edge_6
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_5 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_5 ]
  %p_4_2 = phi i1 [ %t5, %edge_5 ]
  %p_4_3 = phi %hia.buffer [ %t7, %edge_5 ]
  %p_4_4 = phi i8 [ 1, %edge_5 ]
  %t8 = extractvalue %hia.buffer %p_4_3, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  call void @free(ptr %t8) nobuiltin
  br label %drop_after_10
drop_after_10:
  %t11 = zext i8 %p_4_4 to i64
  %t12 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t11)
  %t13 = extractvalue { i64, i1 } %t12, 0
  %t14 = extractvalue { i64, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  ret i64 %t13
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_6 ], [ %p_6_0, %edge_9 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_6 ], [ %p_6_1, %edge_9 ]
  %p_5_2 = phi %hia.buffer [ %p_3_3, %edge_6 ], [ %p_6_2, %edge_9 ]
  %p_5_3 = phi i64 [ %p_3_0, %edge_6 ], [ %p_6_3, %edge_9 ]
  %p_5_4 = phi i64 [ 0, %edge_6 ], [ %t28, %edge_9 ]
  %t17 = icmp ult i64 %p_5_4, %p_5_3
  br i1 %t17, label %edge_7, label %edge_8
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_7 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_6_3 = phi i64 [ %p_5_3, %edge_7 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_7 ]
  %t18 = trunc i64 %p_6_4 to i32
  %t19 = add i32 %t18, %p_6_1
  %t20 = trunc i64 %p_6_4 to i8
  %t21 = trunc i32 %p_6_1 to i8
  %t22 = add i8 %t20, %t21
  %t23 = extractvalue %hia.buffer %p_6_2, 0
  %t24 = extractvalue %hia.buffer %p_6_2, 1
  %t25 = icmp ult i64 %p_6_4, %t24
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = getelementptr i8, ptr %t23, i64 %p_6_4
  store i8 %t22, ptr %t27, align 1
  %t28 = add i64 %p_6_4, 1
  br label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_8 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_8 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_8 ]
  %p_7_3 = phi i64 [ %p_5_3, %edge_8 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_8 ]
  br label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_10 ], [ %p_9_0, %edge_13 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_10 ], [ %p_9_1, %edge_13 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_10 ], [ %p_9_2, %edge_13 ]
  %p_8_3 = phi i64 [ 0, %edge_10 ], [ %t37, %edge_13 ]
  %p_8_4 = phi i64 [ %p_7_0, %edge_10 ], [ %p_9_4, %edge_13 ]
  %p_8_5 = phi i64 [ 0, %edge_10 ], [ %t38, %edge_13 ]
  %t29 = icmp ult i64 %p_8_5, %p_8_4
  br i1 %t29, label %edge_11, label %edge_12
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_11 ]
  %p_9_1 = phi i32 [ %p_8_1, %edge_11 ]
  %p_9_2 = phi %hia.buffer [ %p_8_2, %edge_11 ]
  %p_9_3 = phi i64 [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i64 [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_11 ]
  %t30 = extractvalue %hia.buffer %p_9_2, 0
  %t31 = extractvalue %hia.buffer %p_9_2, 1
  %t32 = icmp ult i64 %p_9_5, %t31
  br i1 %t32, label %ok_33, label %trap_33
trap_33:
  call void @abort()
  unreachable
ok_33:
  %t34 = getelementptr i8, ptr %t30, i64 %p_9_5
  %t35 = load i8, ptr %t34, align 1
  %t36 = zext i8 %t35 to i64
  %t37 = add i64 %p_9_3, %t36
  %t38 = add i64 %p_9_5, 1
  br label %edge_13
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_12 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_12 ]
  %p_10_2 = phi %hia.buffer [ %p_8_2, %edge_12 ]
  %p_10_3 = phi i64 [ %p_8_3, %edge_12 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_12 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_12 ]
  %t39 = extractvalue %hia.buffer %p_10_2, 0
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %drop_nonnull_41, label %drop_after_41
drop_nonnull_41:
  call void @free(ptr %t39) nobuiltin
  br label %drop_after_41
drop_after_41:
  ret i64 %p_10_3
b11:
  %p_11_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_11_1 = phi i32 [ %p_1_1, %edge_3 ]
  %t42 = call %hia.alloc @__hia_allocate(i64 %p_11_0, i1 false)
  %t43 = extractvalue %hia.alloc %t42, 0
  %t44 = extractvalue %hia.alloc %t42, 1
  %t45 = select i1 %t44, i64 %p_11_0, i64 0
  %t46 = insertvalue %hia.buffer %t43, i64 %t45, 1
  br i1 %t44, label %edge_14, label %edge_15
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_14 ]
  %p_12_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_12_2 = phi i1 [ %t44, %edge_14 ]
  %p_12_3 = phi %hia.buffer [ %t46, %edge_14 ]
  %p_12_4 = phi i8 [ 1, %edge_14 ]
  br label %edge_16
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_15 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_15 ]
  %p_13_2 = phi i1 [ %t44, %edge_15 ]
  %p_13_3 = phi %hia.buffer [ %t46, %edge_15 ]
  %p_13_4 = phi i8 [ 1, %edge_15 ]
  %t47 = extractvalue %hia.buffer %p_13_3, 0
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %drop_nonnull_49, label %drop_after_49
drop_nonnull_49:
  call void @free(ptr %t47) nobuiltin
  br label %drop_after_49
drop_after_49:
  %t50 = zext i8 %p_13_4 to i64
  %t51 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t50)
  %t52 = extractvalue { i64, i1 } %t51, 0
  %t53 = extractvalue { i64, i1 } %t51, 1
  %t54 = xor i1 %t53, true
  br i1 %t54, label %ok_55, label %trap_55
trap_55:
  call void @abort()
  unreachable
ok_55:
  ret i64 %t52
b14:
  %p_14_0 = phi i64 [ %p_12_0, %edge_16 ], [ %p_15_0, %edge_19 ]
  %p_14_1 = phi i32 [ %p_12_1, %edge_16 ], [ %p_15_1, %edge_19 ]
  %p_14_2 = phi %hia.buffer [ %p_12_3, %edge_16 ], [ %p_15_2, %edge_19 ]
  %p_14_3 = phi i64 [ %p_12_0, %edge_16 ], [ %p_15_3, %edge_19 ]
  %p_14_4 = phi i64 [ 0, %edge_16 ], [ %t68, %edge_19 ]
  %t56 = icmp ult i64 %p_14_4, %p_14_3
  br i1 %t56, label %edge_17, label %edge_18
b15:
  %p_15_0 = phi i64 [ %p_14_0, %edge_17 ]
  %p_15_1 = phi i32 [ %p_14_1, %edge_17 ]
  %p_15_2 = phi %hia.buffer [ %p_14_2, %edge_17 ]
  %p_15_3 = phi i64 [ %p_14_3, %edge_17 ]
  %p_15_4 = phi i64 [ %p_14_4, %edge_17 ]
  %t57 = trunc i64 %p_15_4 to i32
  %t58 = add i32 %t57, %p_15_1
  %t59 = trunc i64 %p_15_4 to i8
  %t60 = trunc i32 %p_15_1 to i8
  %t61 = add i8 %t59, %t60
  %t62 = extractvalue %hia.buffer %p_15_2, 0
  %t63 = extractvalue %hia.buffer %p_15_2, 1
  %t64 = icmp ult i64 %p_15_4, %t63
  br i1 %t64, label %ok_65, label %trap_65
trap_65:
  call void @abort()
  unreachable
ok_65:
  %t66 = getelementptr i8, ptr %t62, i64 %p_15_4
  store i8 %t61, ptr %t66, align 1
  %t67 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_15_4, i64 1)
  %t68 = extractvalue { i64, i1 } %t67, 0
  %t69 = extractvalue { i64, i1 } %t67, 1
  %t70 = xor i1 %t69, true
  br i1 %t70, label %ok_71, label %trap_71
trap_71:
  call void @abort()
  unreachable
ok_71:
  br label %edge_19
b16:
  %p_16_0 = phi i64 [ %p_14_0, %edge_18 ]
  %p_16_1 = phi i32 [ %p_14_1, %edge_18 ]
  %p_16_2 = phi %hia.buffer [ %p_14_2, %edge_18 ]
  %p_16_3 = phi i64 [ %p_14_3, %edge_18 ]
  %p_16_4 = phi i64 [ %p_14_4, %edge_18 ]
  br label %edge_20
b17:
  %p_17_0 = phi i64 [ %p_16_0, %edge_20 ], [ %p_18_0, %edge_23 ]
  %p_17_1 = phi i32 [ %p_16_1, %edge_20 ], [ %p_18_1, %edge_23 ]
  %p_17_2 = phi %hia.buffer [ %p_16_2, %edge_20 ], [ %p_18_2, %edge_23 ]
  %p_17_3 = phi i64 [ 0, %edge_20 ], [ %t81, %edge_23 ]
  %p_17_4 = phi i64 [ %p_16_0, %edge_20 ], [ %p_18_4, %edge_23 ]
  %p_17_5 = phi i64 [ 0, %edge_20 ], [ %t86, %edge_23 ]
  %t72 = icmp ult i64 %p_17_5, %p_17_4
  br i1 %t72, label %edge_21, label %edge_22
b18:
  %p_18_0 = phi i64 [ %p_17_0, %edge_21 ]
  %p_18_1 = phi i32 [ %p_17_1, %edge_21 ]
  %p_18_2 = phi %hia.buffer [ %p_17_2, %edge_21 ]
  %p_18_3 = phi i64 [ %p_17_3, %edge_21 ]
  %p_18_4 = phi i64 [ %p_17_4, %edge_21 ]
  %p_18_5 = phi i64 [ %p_17_5, %edge_21 ]
  %t73 = extractvalue %hia.buffer %p_18_2, 0
  %t74 = extractvalue %hia.buffer %p_18_2, 1
  %t75 = icmp ult i64 %p_18_5, %t74
  br i1 %t75, label %ok_76, label %trap_76
trap_76:
  call void @abort()
  unreachable
ok_76:
  %t77 = getelementptr i8, ptr %t73, i64 %p_18_5
  %t78 = load i8, ptr %t77, align 1
  %t79 = zext i8 %t78 to i64
  %t80 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_18_3, i64 %t79)
  %t81 = extractvalue { i64, i1 } %t80, 0
  %t82 = extractvalue { i64, i1 } %t80, 1
  %t83 = xor i1 %t82, true
  br i1 %t83, label %ok_84, label %trap_84
trap_84:
  call void @abort()
  unreachable
ok_84:
  %t85 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_18_5, i64 1)
  %t86 = extractvalue { i64, i1 } %t85, 0
  %t87 = extractvalue { i64, i1 } %t85, 1
  %t88 = xor i1 %t87, true
  br i1 %t88, label %ok_89, label %trap_89
trap_89:
  call void @abort()
  unreachable
ok_89:
  br label %edge_23
b19:
  %p_19_0 = phi i64 [ %p_17_0, %edge_22 ]
  %p_19_1 = phi i32 [ %p_17_1, %edge_22 ]
  %p_19_2 = phi %hia.buffer [ %p_17_2, %edge_22 ]
  %p_19_3 = phi i64 [ %p_17_3, %edge_22 ]
  %p_19_4 = phi i64 [ %p_17_4, %edge_22 ]
  %p_19_5 = phi i64 [ %p_17_5, %edge_22 ]
  %t90 = extractvalue %hia.buffer %p_19_2, 0
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %drop_nonnull_92, label %drop_after_92
drop_nonnull_92:
  call void @free(ptr %t90) nobuiltin
  br label %drop_after_92
drop_after_92:
  ret i64 %p_19_3
b20:
  %p_20_0 = phi i64 [ 0, %edge_0 ]
  %p_20_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t93 = icmp ule i64 %p_20_0, 72340172838076673
  br i1 %t93, label %edge_24, label %edge_25
b21:
  %p_21_0 = phi i64 [ %p_20_0, %edge_24 ]
  %p_21_1 = phi i32 [ %p_20_1, %edge_24 ]
  %t94 = call %hia.alloc @__hia_allocate(i64 %p_21_0, i1 false)
  %t95 = extractvalue %hia.alloc %t94, 0
  %t96 = extractvalue %hia.alloc %t94, 1
  %t97 = select i1 %t96, i64 %p_21_0, i64 0
  %t98 = insertvalue %hia.buffer %t95, i64 %t97, 1
  br i1 %t96, label %edge_26, label %edge_27
b22:
  %p_22_0 = phi i64 [ %p_21_0, %edge_26 ]
  %p_22_1 = phi i32 [ %p_21_1, %edge_26 ]
  %p_22_2 = phi i1 [ %t96, %edge_26 ]
  %p_22_3 = phi %hia.buffer [ %t98, %edge_26 ]
  %p_22_4 = phi i8 [ 1, %edge_26 ]
  br label %edge_28
b23:
  %p_23_0 = phi i64 [ %p_21_0, %edge_27 ]
  %p_23_1 = phi i32 [ %p_21_1, %edge_27 ]
  %p_23_2 = phi i1 [ %t96, %edge_27 ]
  %p_23_3 = phi %hia.buffer [ %t98, %edge_27 ]
  %p_23_4 = phi i8 [ 1, %edge_27 ]
  %t99 = extractvalue %hia.buffer %p_23_3, 0
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %drop_nonnull_101, label %drop_after_101
drop_nonnull_101:
  call void @free(ptr %t99) nobuiltin
  br label %drop_after_101
drop_after_101:
  %t102 = zext i8 %p_23_4 to i64
  %t103 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t102)
  %t104 = extractvalue { i64, i1 } %t103, 0
  %t105 = extractvalue { i64, i1 } %t103, 1
  %t106 = xor i1 %t105, true
  br i1 %t106, label %ok_107, label %trap_107
trap_107:
  call void @abort()
  unreachable
ok_107:
  ret i64 %t104
b24:
  %p_24_0 = phi i64 [ %p_22_0, %edge_28 ], [ %p_25_0, %edge_31 ]
  %p_24_1 = phi i32 [ %p_22_1, %edge_28 ], [ %p_25_1, %edge_31 ]
  %p_24_2 = phi %hia.buffer [ %p_22_3, %edge_28 ], [ %p_25_2, %edge_31 ]
  %p_24_3 = phi i64 [ %p_22_0, %edge_28 ], [ %p_25_3, %edge_31 ]
  %p_24_4 = phi i64 [ 0, %edge_28 ], [ %t119, %edge_31 ]
  %t108 = icmp ult i64 %p_24_4, %p_24_3
  br i1 %t108, label %edge_29, label %edge_30
b25:
  %p_25_0 = phi i64 [ %p_24_0, %edge_29 ]
  %p_25_1 = phi i32 [ %p_24_1, %edge_29 ]
  %p_25_2 = phi %hia.buffer [ %p_24_2, %edge_29 ]
  %p_25_3 = phi i64 [ %p_24_3, %edge_29 ]
  %p_25_4 = phi i64 [ %p_24_4, %edge_29 ]
  %t109 = trunc i64 %p_25_4 to i32
  %t110 = add i32 %t109, %p_25_1
  %t111 = trunc i64 %p_25_4 to i8
  %t112 = trunc i32 %p_25_1 to i8
  %t113 = add i8 %t111, %t112
  %t114 = extractvalue %hia.buffer %p_25_2, 0
  %t115 = extractvalue %hia.buffer %p_25_2, 1
  %t116 = icmp ult i64 %p_25_4, %t115
  br i1 %t116, label %ok_117, label %trap_117
trap_117:
  call void @abort()
  unreachable
ok_117:
  %t118 = getelementptr i8, ptr %t114, i64 %p_25_4
  store i8 %t113, ptr %t118, align 1
  %t119 = add i64 %p_25_4, 1
  br label %edge_31
b26:
  %p_26_0 = phi i64 [ %p_24_0, %edge_30 ]
  %p_26_1 = phi i32 [ %p_24_1, %edge_30 ]
  %p_26_2 = phi %hia.buffer [ %p_24_2, %edge_30 ]
  %p_26_3 = phi i64 [ %p_24_3, %edge_30 ]
  %p_26_4 = phi i64 [ %p_24_4, %edge_30 ]
  br label %edge_32
b27:
  %p_27_0 = phi i64 [ %p_26_0, %edge_32 ], [ %p_28_0, %edge_35 ]
  %p_27_1 = phi i32 [ %p_26_1, %edge_32 ], [ %p_28_1, %edge_35 ]
  %p_27_2 = phi %hia.buffer [ %p_26_2, %edge_32 ], [ %p_28_2, %edge_35 ]
  %p_27_3 = phi i64 [ 0, %edge_32 ], [ %t128, %edge_35 ]
  %p_27_4 = phi i64 [ %p_26_0, %edge_32 ], [ %p_28_4, %edge_35 ]
  %p_27_5 = phi i64 [ 0, %edge_32 ], [ %t129, %edge_35 ]
  %t120 = icmp ult i64 %p_27_5, %p_27_4
  br i1 %t120, label %edge_33, label %edge_34
b28:
  %p_28_0 = phi i64 [ %p_27_0, %edge_33 ]
  %p_28_1 = phi i32 [ %p_27_1, %edge_33 ]
  %p_28_2 = phi %hia.buffer [ %p_27_2, %edge_33 ]
  %p_28_3 = phi i64 [ %p_27_3, %edge_33 ]
  %p_28_4 = phi i64 [ %p_27_4, %edge_33 ]
  %p_28_5 = phi i64 [ %p_27_5, %edge_33 ]
  %t121 = extractvalue %hia.buffer %p_28_2, 0
  %t122 = extractvalue %hia.buffer %p_28_2, 1
  %t123 = icmp ult i64 %p_28_5, %t122
  br i1 %t123, label %ok_124, label %trap_124
trap_124:
  call void @abort()
  unreachable
ok_124:
  %t125 = getelementptr i8, ptr %t121, i64 %p_28_5
  %t126 = load i8, ptr %t125, align 1
  %t127 = zext i8 %t126 to i64
  %t128 = add i64 %p_28_3, %t127
  %t129 = add i64 %p_28_5, 1
  br label %edge_35
b29:
  %p_29_0 = phi i64 [ %p_27_0, %edge_34 ]
  %p_29_1 = phi i32 [ %p_27_1, %edge_34 ]
  %p_29_2 = phi %hia.buffer [ %p_27_2, %edge_34 ]
  %p_29_3 = phi i64 [ %p_27_3, %edge_34 ]
  %p_29_4 = phi i64 [ %p_27_4, %edge_34 ]
  %p_29_5 = phi i64 [ %p_27_5, %edge_34 ]
  %t130 = extractvalue %hia.buffer %p_29_2, 0
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %drop_nonnull_132, label %drop_after_132
drop_nonnull_132:
  call void @free(ptr %t130) nobuiltin
  br label %drop_after_132
drop_after_132:
  ret i64 %p_29_3
b30:
  %p_30_0 = phi i64 [ %p_20_0, %edge_25 ]
  %p_30_1 = phi i32 [ %p_20_1, %edge_25 ]
  %t133 = call %hia.alloc @__hia_allocate(i64 %p_30_0, i1 false)
  %t134 = extractvalue %hia.alloc %t133, 0
  %t135 = extractvalue %hia.alloc %t133, 1
  %t136 = select i1 %t135, i64 %p_30_0, i64 0
  %t137 = insertvalue %hia.buffer %t134, i64 %t136, 1
  br i1 %t135, label %edge_36, label %edge_37
b31:
  %p_31_0 = phi i64 [ %p_30_0, %edge_36 ]
  %p_31_1 = phi i32 [ %p_30_1, %edge_36 ]
  %p_31_2 = phi i1 [ %t135, %edge_36 ]
  %p_31_3 = phi %hia.buffer [ %t137, %edge_36 ]
  %p_31_4 = phi i8 [ 1, %edge_36 ]
  br label %edge_38
b32:
  %p_32_0 = phi i64 [ %p_30_0, %edge_37 ]
  %p_32_1 = phi i32 [ %p_30_1, %edge_37 ]
  %p_32_2 = phi i1 [ %t135, %edge_37 ]
  %p_32_3 = phi %hia.buffer [ %t137, %edge_37 ]
  %p_32_4 = phi i8 [ 1, %edge_37 ]
  %t138 = extractvalue %hia.buffer %p_32_3, 0
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %drop_nonnull_140, label %drop_after_140
drop_nonnull_140:
  call void @free(ptr %t138) nobuiltin
  br label %drop_after_140
drop_after_140:
  %t141 = zext i8 %p_32_4 to i64
  %t142 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t141)
  %t143 = extractvalue { i64, i1 } %t142, 0
  %t144 = extractvalue { i64, i1 } %t142, 1
  %t145 = xor i1 %t144, true
  br i1 %t145, label %ok_146, label %trap_146
trap_146:
  call void @abort()
  unreachable
ok_146:
  ret i64 %t143
b33:
  %p_33_0 = phi i64 [ %p_31_0, %edge_38 ], [ %p_34_0, %edge_41 ]
  %p_33_1 = phi i32 [ %p_31_1, %edge_38 ], [ %p_34_1, %edge_41 ]
  %p_33_2 = phi %hia.buffer [ %p_31_3, %edge_38 ], [ %p_34_2, %edge_41 ]
  %p_33_3 = phi i64 [ %p_31_0, %edge_38 ], [ %p_34_3, %edge_41 ]
  %p_33_4 = phi i64 [ 0, %edge_38 ], [ %t159, %edge_41 ]
  %t147 = icmp ult i64 %p_33_4, %p_33_3
  br i1 %t147, label %edge_39, label %edge_40
b34:
  %p_34_0 = phi i64 [ %p_33_0, %edge_39 ]
  %p_34_1 = phi i32 [ %p_33_1, %edge_39 ]
  %p_34_2 = phi %hia.buffer [ %p_33_2, %edge_39 ]
  %p_34_3 = phi i64 [ %p_33_3, %edge_39 ]
  %p_34_4 = phi i64 [ %p_33_4, %edge_39 ]
  %t148 = trunc i64 %p_34_4 to i32
  %t149 = add i32 %t148, %p_34_1
  %t150 = trunc i64 %p_34_4 to i8
  %t151 = trunc i32 %p_34_1 to i8
  %t152 = add i8 %t150, %t151
  %t153 = extractvalue %hia.buffer %p_34_2, 0
  %t154 = extractvalue %hia.buffer %p_34_2, 1
  %t155 = icmp ult i64 %p_34_4, %t154
  br i1 %t155, label %ok_156, label %trap_156
trap_156:
  call void @abort()
  unreachable
ok_156:
  %t157 = getelementptr i8, ptr %t153, i64 %p_34_4
  store i8 %t152, ptr %t157, align 1
  %t158 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_34_4, i64 1)
  %t159 = extractvalue { i64, i1 } %t158, 0
  %t160 = extractvalue { i64, i1 } %t158, 1
  %t161 = xor i1 %t160, true
  br i1 %t161, label %ok_162, label %trap_162
trap_162:
  call void @abort()
  unreachable
ok_162:
  br label %edge_41
b35:
  %p_35_0 = phi i64 [ %p_33_0, %edge_40 ]
  %p_35_1 = phi i32 [ %p_33_1, %edge_40 ]
  %p_35_2 = phi %hia.buffer [ %p_33_2, %edge_40 ]
  %p_35_3 = phi i64 [ %p_33_3, %edge_40 ]
  %p_35_4 = phi i64 [ %p_33_4, %edge_40 ]
  br label %edge_42
b36:
  %p_36_0 = phi i64 [ %p_35_0, %edge_42 ], [ %p_37_0, %edge_45 ]
  %p_36_1 = phi i32 [ %p_35_1, %edge_42 ], [ %p_37_1, %edge_45 ]
  %p_36_2 = phi %hia.buffer [ %p_35_2, %edge_42 ], [ %p_37_2, %edge_45 ]
  %p_36_3 = phi i64 [ 0, %edge_42 ], [ %t172, %edge_45 ]
  %p_36_4 = phi i64 [ %p_35_0, %edge_42 ], [ %p_37_4, %edge_45 ]
  %p_36_5 = phi i64 [ 0, %edge_42 ], [ %t177, %edge_45 ]
  %t163 = icmp ult i64 %p_36_5, %p_36_4
  br i1 %t163, label %edge_43, label %edge_44
b37:
  %p_37_0 = phi i64 [ %p_36_0, %edge_43 ]
  %p_37_1 = phi i32 [ %p_36_1, %edge_43 ]
  %p_37_2 = phi %hia.buffer [ %p_36_2, %edge_43 ]
  %p_37_3 = phi i64 [ %p_36_3, %edge_43 ]
  %p_37_4 = phi i64 [ %p_36_4, %edge_43 ]
  %p_37_5 = phi i64 [ %p_36_5, %edge_43 ]
  %t164 = extractvalue %hia.buffer %p_37_2, 0
  %t165 = extractvalue %hia.buffer %p_37_2, 1
  %t166 = icmp ult i64 %p_37_5, %t165
  br i1 %t166, label %ok_167, label %trap_167
trap_167:
  call void @abort()
  unreachable
ok_167:
  %t168 = getelementptr i8, ptr %t164, i64 %p_37_5
  %t169 = load i8, ptr %t168, align 1
  %t170 = zext i8 %t169 to i64
  %t171 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_37_3, i64 %t170)
  %t172 = extractvalue { i64, i1 } %t171, 0
  %t173 = extractvalue { i64, i1 } %t171, 1
  %t174 = xor i1 %t173, true
  br i1 %t174, label %ok_175, label %trap_175
trap_175:
  call void @abort()
  unreachable
ok_175:
  %t176 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_37_5, i64 1)
  %t177 = extractvalue { i64, i1 } %t176, 0
  %t178 = extractvalue { i64, i1 } %t176, 1
  %t179 = xor i1 %t178, true
  br i1 %t179, label %ok_180, label %trap_180
trap_180:
  call void @abort()
  unreachable
ok_180:
  br label %edge_45
b38:
  %p_38_0 = phi i64 [ %p_36_0, %edge_44 ]
  %p_38_1 = phi i32 [ %p_36_1, %edge_44 ]
  %p_38_2 = phi %hia.buffer [ %p_36_2, %edge_44 ]
  %p_38_3 = phi i64 [ %p_36_3, %edge_44 ]
  %p_38_4 = phi i64 [ %p_36_4, %edge_44 ]
  %p_38_5 = phi i64 [ %p_36_5, %edge_44 ]
  %t181 = extractvalue %hia.buffer %p_38_2, 0
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %drop_nonnull_183, label %drop_after_183
drop_nonnull_183:
  call void @free(ptr %t181) nobuiltin
  br label %drop_after_183
drop_after_183:
  ret i64 %p_38_3
edge_0:
  br label %b20
edge_1:
  br label %b1
edge_2:
  br label %b2
edge_3:
  br label %b11
edge_4:
  br label %b3
edge_5:
  br label %b4
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b5
edge_10:
  br label %b8
edge_11:
  br label %b9
edge_12:
  br label %b10
edge_13:
  br label %b8
edge_14:
  br label %b12
edge_15:
  br label %b13
edge_16:
  br label %b14
edge_17:
  br label %b15
edge_18:
  br label %b16
edge_19:
  br label %b14
edge_20:
  br label %b17
edge_21:
  br label %b18
edge_22:
  br label %b19
edge_23:
  br label %b17
edge_24:
  br label %b21
edge_25:
  br label %b30
edge_26:
  br label %b22
edge_27:
  br label %b23
edge_28:
  br label %b24
edge_29:
  br label %b25
edge_30:
  br label %b26
edge_31:
  br label %b24
edge_32:
  br label %b27
edge_33:
  br label %b28
edge_34:
  br label %b29
edge_35:
  br label %b27
edge_36:
  br label %b31
edge_37:
  br label %b32
edge_38:
  br label %b33
edge_39:
  br label %b34
edge_40:
  br label %b35
edge_41:
  br label %b33
edge_42:
  br label %b36
edge_43:
  br label %b37
edge_44:
  br label %b38
edge_45:
  br label %b36
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %is_empty = icmp eq i64 %a0, 0
  br i1 %is_empty, label %zero, label %ordinary
zero:
  %zero_result = call i64 @__hia_fn_0(i64 0, i32 %a1) alwaysinline
  ret i64 %zero_result
ordinary:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1) noinline
  ret i64 %result
}
