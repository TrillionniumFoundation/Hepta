
/home/qian-qi/work/hia-evidence-20261103/empty-wrapper-observation-1dfbfd1-r1/linear/rust_byte_release.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011c0 <calculate>:
    11c0:	48 85 ff             	test   %rdi,%rdi
    11c3:	75 03                	jne    11c8 <calculate+0x8>
    11c5:	31 c0                	xor    %eax,%eax
    11c7:	c3                   	ret
    11c8:	55                   	push   %rbp
    11c9:	41 57                	push   %r15
    11cb:	41 56                	push   %r14
    11cd:	53                   	push   %rbx
    11ce:	48 83 ec 18          	sub    $0x18,%rsp
    11d2:	89 f5                	mov    %esi,%ebp
    11d4:	48 89 e0             	mov    %rsp,%rax
    11d7:	ba 01 00 00 00       	mov    $0x1,%edx
    11dc:	48 89 f9             	mov    %rdi,%rcx
    11df:	48 89 c7             	mov    %rax,%rdi
    11e2:	31 f6                	xor    %esi,%esi
    11e4:	49 89 cf             	mov    %rcx,%r15
    11e7:	e8 a4 fe ff ff       	call   1090 <_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17hc2299966dece99bdE>
    11ec:	80 3c 24 00          	cmpb   $0x0,(%rsp)
    11f0:	74 0a                	je     11fc <calculate+0x3c>
    11f2:	b8 e9 03 00 00       	mov    $0x3e9,%eax
    11f7:	e9 82 01 00 00       	jmp    137e <calculate+0x1be>
    11fc:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    1201:	49 83 ff 01          	cmp    $0x1,%r15
    1205:	75 11                	jne    1218 <calculate+0x58>
    1207:	c6 03 00             	movb   $0x0,(%rbx)
    120a:	48 8d 4b 01          	lea    0x1(%rbx),%rcx
    120e:	b8 01 00 00 00       	mov    $0x1,%eax
    1213:	45 31 f6             	xor    %r14d,%r14d
    1216:	eb 25                	jmp    123d <calculate+0x7d>
    1218:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
    121c:	45 31 f6             	xor    %r14d,%r14d
    121f:	48 89 df             	mov    %rbx,%rdi
    1222:	31 f6                	xor    %esi,%esi
    1224:	ff 15 96 3d 00 00    	call   *0x3d96(%rip)        # 4fc0 <memset@GLIBC_2.2.5>
    122a:	4c 89 f8             	mov    %r15,%rax
    122d:	42 c6 44 3b ff 00    	movb   $0x0,-0x1(%rbx,%r15,1)
    1233:	4a 8d 0c 3b          	lea    (%rbx,%r15,1),%rcx
    1237:	49 83 ff 04          	cmp    $0x4,%r15
    123b:	73 37                	jae    1274 <calculate+0xb4>
    123d:	48 89 de             	mov    %rbx,%rsi
    1240:	89 ea                	mov    %ebp,%edx
    1242:	44 00 f2             	add    %r14b,%dl
    1245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    124c:	00 00 00 00 
    1250:	88 16                	mov    %dl,(%rsi)
    1252:	48 ff c6             	inc    %rsi
    1255:	fe c2                	inc    %dl
    1257:	48 39 ce             	cmp    %rcx,%rsi
    125a:	75 f4                	jne    1250 <calculate+0x90>
    125c:	89 c1                	mov    %eax,%ecx
    125e:	83 e1 07             	and    $0x7,%ecx
    1261:	48 83 f8 08          	cmp    $0x8,%rax
    1265:	0f 83 89 00 00 00    	jae    12f4 <calculate+0x134>
    126b:	31 c0                	xor    %eax,%eax
    126d:	31 d2                	xor    %edx,%edx
    126f:	e9 db 00 00 00       	jmp    134f <calculate+0x18f>
    1274:	89 ea                	mov    %ebp,%edx
    1276:	0f b6 f2             	movzbl %dl,%esi
    1279:	48 83 f8 20          	cmp    $0x20,%rax
    127d:	73 08                	jae    1287 <calculate+0xc7>
    127f:	45 31 f6             	xor    %r14d,%r14d
    1282:	e9 06 01 00 00       	jmp    138d <calculate+0x1cd>
    1287:	49 89 c6             	mov    %rax,%r14
    128a:	49 83 e6 e0          	and    $0xffffffffffffffe0,%r14
    128e:	66 0f 6e c6          	movd   %esi,%xmm0
    1292:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1296:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    129b:	66 0f 70 c0 44       	pshufd $0x44,%xmm0,%xmm0
    12a0:	66 0f 6f 0d 58 1d 00 	movdqa 0x1d58(%rip),%xmm1        # 3000 <_fini+0xeb8>
    12a7:	00 
    12a8:	66 0f fc c8          	paddb  %xmm0,%xmm1
    12ac:	66 0f 6f 15 5c 1d 00 	movdqa 0x1d5c(%rip),%xmm2        # 3010 <_fini+0xec8>
    12b3:	00 
    12b4:	31 ff                	xor    %edi,%edi
    12b6:	66 0f 6f 1d 62 1d 00 	movdqa 0x1d62(%rip),%xmm3        # 3020 <_fini+0xed8>
    12bd:	00 
    12be:	66 0f 6f e2          	movdqa %xmm2,%xmm4
    12c2:	66 0f fc e0          	paddb  %xmm0,%xmm4
    12c6:	66 0f 6f ea          	movdqa %xmm2,%xmm5
    12ca:	66 0f fc e9          	paddb  %xmm1,%xmm5
    12ce:	f3 0f 7f 24 3b       	movdqu %xmm4,(%rbx,%rdi,1)
    12d3:	f3 0f 7f 6c 3b 10    	movdqu %xmm5,0x10(%rbx,%rdi,1)
    12d9:	48 83 c7 20          	add    $0x20,%rdi
    12dd:	66 0f fc d3          	paddb  %xmm3,%xmm2
    12e1:	49 39 fe             	cmp    %rdi,%r14
    12e4:	75 d8                	jne    12be <calculate+0xfe>
    12e6:	4c 39 f0             	cmp    %r14,%rax
    12e9:	0f 85 9a 00 00 00    	jne    1389 <calculate+0x1c9>
    12ef:	89 c1                	mov    %eax,%ecx
    12f1:	83 e1 07             	and    $0x7,%ecx
    12f4:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    12f8:	31 d2                	xor    %edx,%edx
    12fa:	31 f6                	xor    %esi,%esi
    12fc:	0f 1f 40 00          	nopl   0x0(%rax)
    1300:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
    1304:	48 01 d7             	add    %rdx,%rdi
    1307:	0f b6 54 33 01       	movzbl 0x1(%rbx,%rsi,1),%edx
    130c:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
    1312:	49 01 d0             	add    %rdx,%r8
    1315:	49 01 f8             	add    %rdi,%r8
    1318:	0f b6 54 33 03       	movzbl 0x3(%rbx,%rsi,1),%edx
    131d:	0f b6 7c 33 04       	movzbl 0x4(%rbx,%rsi,1),%edi
    1322:	48 01 d7             	add    %rdx,%rdi
    1325:	44 0f b6 4c 33 05    	movzbl 0x5(%rbx,%rsi,1),%r9d
    132b:	49 01 f9             	add    %rdi,%r9
    132e:	4d 01 c1             	add    %r8,%r9
    1331:	0f b6 7c 33 06       	movzbl 0x6(%rbx,%rsi,1),%edi
    1336:	0f b6 54 33 07       	movzbl 0x7(%rbx,%rsi,1),%edx
    133b:	48 01 fa             	add    %rdi,%rdx
    133e:	4c 01 ca             	add    %r9,%rdx
    1341:	48 83 c6 08          	add    $0x8,%rsi
    1345:	48 39 f0             	cmp    %rsi,%rax
    1348:	75 b6                	jne    1300 <calculate+0x140>
    134a:	48 85 c9             	test   %rcx,%rcx
    134d:	74 20                	je     136f <calculate+0x1af>
    134f:	48 01 d8             	add    %rbx,%rax
    1352:	31 f6                	xor    %esi,%esi
    1354:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    135b:	00 00 00 00 00 
    1360:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
    1364:	48 01 fa             	add    %rdi,%rdx
    1367:	48 ff c6             	inc    %rsi
    136a:	48 39 f1             	cmp    %rsi,%rcx
    136d:	75 f1                	jne    1360 <calculate+0x1a0>
    136f:	48 89 df             	mov    %rbx,%rdi
    1372:	48 89 d3             	mov    %rdx,%rbx
    1375:	ff 15 4d 3c 00 00    	call   *0x3c4d(%rip)        # 4fc8 <_GLOBAL_OFFSET_TABLE_+0x58>
    137b:	48 89 d8             	mov    %rbx,%rax
    137e:	48 83 c4 18          	add    $0x18,%rsp
    1382:	5b                   	pop    %rbx
    1383:	41 5e                	pop    %r14
    1385:	41 5f                	pop    %r15
    1387:	5d                   	pop    %rbp
    1388:	c3                   	ret
    1389:	a8 1c                	test   $0x1c,%al
    138b:	74 65                	je     13f2 <calculate+0x232>
    138d:	48 89 c7             	mov    %rax,%rdi
    1390:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
    1394:	66 0f 6e c6          	movd   %esi,%xmm0
    1398:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    139c:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    13a1:	41 0f b6 f6          	movzbl %r14b,%esi
    13a5:	66 0f 6e ce          	movd   %esi,%xmm1
    13a9:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    13ad:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    13b2:	66 0f fc 0d 76 1c 00 	paddb  0x1c76(%rip),%xmm1        # 3030 <_fini+0xee8>
    13b9:	00 
    13ba:	66 0f 6f 15 7e 1c 00 	movdqa 0x1c7e(%rip),%xmm2        # 3040 <_fini+0xef8>
    13c1:	00 
    13c2:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    13c6:	66 0f fc d8          	paddb  %xmm0,%xmm3
    13ca:	66 42 0f 7e 1c 33    	movd   %xmm3,(%rbx,%r14,1)
    13d0:	49 83 c6 04          	add    $0x4,%r14
    13d4:	66 0f fc ca          	paddb  %xmm2,%xmm1
    13d8:	4c 39 f7             	cmp    %r14,%rdi
    13db:	75 e5                	jne    13c2 <calculate+0x202>
    13dd:	48 39 f8             	cmp    %rdi,%rax
    13e0:	0f 84 76 fe ff ff    	je     125c <calculate+0x9c>
    13e6:	48 8d 34 3b          	lea    (%rbx,%rdi,1),%rsi
    13ea:	41 89 fe             	mov    %edi,%r14d
    13ed:	e9 50 fe ff ff       	jmp    1242 <calculate+0x82>
    13f2:	4c 89 f6             	mov    %r14,%rsi
    13f5:	48 01 de             	add    %rbx,%rsi
    13f8:	e9 45 fe ff ff       	jmp    1242 <calculate+0x82>

Disassembly of section .fini:
