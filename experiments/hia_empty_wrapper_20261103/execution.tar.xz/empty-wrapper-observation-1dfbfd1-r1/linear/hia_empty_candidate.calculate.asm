
/home/qian-qi/work/hia-evidence-20261103/empty-wrapper-observation-1dfbfd1-r1/linear/hia_empty_candidate.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000014f0 <calculate>:
    14f0:	48 85 ff             	test   %rdi,%rdi
    14f3:	0f 85 b7 fc ff ff    	jne    11b0 <__hia_fn_0>
    14f9:	31 c0                	xor    %eax,%eax
    14fb:	c3                   	ret

Disassembly of section .fini:
