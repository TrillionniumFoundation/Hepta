"""Bind original successful v67 selected reports to retained bytes; run no tests."""
import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile


def require(value, message):
    if not value:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def location(value):
    require(value.startswith('/home/runner/work/_temp/'), 'unexpected original runner path')
    return value.split('/_temp/', 1)[1]


def strict(report, expected, *, loaded='loaded_test_ids', executed='executed_test_ids'):
    ids = report[loaded]
    require(len(ids) == len(set(ids)) == expected == report['tests_run'], 'test denominator differs')
    require(sorted(ids) == sorted(report[executed]), 'loaded/executed test IDs differ')
    if 'chosen_test_ids' in report:
        require(sorted(ids) == sorted(report['chosen_test_ids']), 'original chosen IDs differ')
    anomalies = report.get('anomalies', report)
    for aliases in [('failures',), ('errors',), ('skipped',),
                    ('expected_failures', 'expectedFailures'),
                    ('unexpected_successes', 'unexpectedSuccesses')]:
        found = [name for name in aliases if name in anomalies]
        require(len(found) == 1 and anomalies[found[0]] in ([], 0), 'original unittest anomaly present')
    require(report.get('loader_errors', []) == [], 'loader errors present')
    return {'tests_run': expected, 'loaded_ids': ids, 'executed_ids': report[executed],
            'all_five_anomalies_zero': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--cold-audit', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    audit = json.loads(args.cold_audit.read_bytes())
    require(audit['status'] == 'ORIGINAL_EVIDENCE_INTEGRITY_VERIFIED', 'cold byte audit is incomplete')
    with args.archive.open('rb') as source:
        require(hashlib.file_digest(source, 'sha256').hexdigest()
                == audit['original_archive']['sha256'], 'audited original archive changed')
    result = {'schema': 'hia.v67.original-selected-report-byte-binding.v1',
              'status': 'HOLD', 'qualification_executed': False,
              'original_product_tests_rerun': False, 'whole_native_delivery_qualified': False,
              'original_archive': audit['original_archive']}
    try:
        with zipfile.ZipFile(args.archive) as archive:
            def read(name):
                return json.loads(archive.read(name))

            cold = read('hia-cold.json')
            qualification = read(location(cold['nested_report']))
            require(cold['status'] == 'COLD_SELFHOST_REPLAY_PASS'
                    and len(cold['checks']) == 11 and all(value is True for value in cold['checks'].values()),
                    'original cold is not an eleven-check pass')
            require(sha(archive.read(location(cold['nested_report']))) == cold['nested_report_sha256']
                    and qualification['status'] == 'SELF_HOSTED_FIXED_CORE_PASS'
                    and all(value is True for value in qualification['checks'].values())
                    and len(qualification['checks']) == 5051, 'nested original qualification differs')
            require(qualification['source_manifest'] == cold['source_manifest'], 'cold source closure differs')
            generations = []
            for rows in (qualification['generations'], qualification['modified_generations']):
                require(len(rows) == 3, 'compiler generation denominator differs')
                for row in rows:
                    raw = archive.read(location(row['produced_image']))
                    require(len(raw) == row['produced_bytes'] and sha(raw) == row['produced_sha256']
                            and row['abi_status'] == 0 and row['source_unchanged'] is True
                            and row['forbidden_compiler_modules_loaded'] == [],
                            'actual retained compiler generation differs')
                    generations.append({'case': row['case'], 'size': len(raw), 'sha256': sha(raw)})
            compiler = qualification['generations'][-1]['produced_sha256']
            require(compiler == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8',
                    'actual B3 differs')
            result['cold'] = {'checks': 11, 'nested_checks': 5051, 'phases': audit['completed_phases'],
                'elapsed_ns': cold['wall_elapsed_ns'], 'generations': generations, 'compiler': compiler}
            language = read('hia-language.json')
            assertions = read('hia-language.assertions.json')
            require(language['status'] == 'SELFHOST_LANGUAGE_COVERAGE_PASS'
                    and len(language['checks']) == 1242
                    and all(value is True for value in language['checks'].values())
                    and language['inventory_sha256'] == cold['source_manifest']['docs/HIA_SELFHOST_LANGUAGE_COVERAGE.json'],
                    'original language report differs')
            require(assertions['passed'] is True and assertions['tests_run'] == 10
                    and assertions['report_sha256'] == sha(archive.read('hia-language.json')),
                    'original language assertion receipt differs')
            result['language'] = {'checks': 1242, 'assertions': 10}
            components = read('hia-native-components.json')
            result['components'] = strict(components, 93)
            expected_modules = {'tests.test_hia_json_wire_native': 17, 'tests.test_hia_json_wire_cache': 7,
                'tests.test_hia_json_wire_entry': 6, 'tests.test_hia_worker_report_native': 20,
                'tests.test_hia_machine_plan_native': 12, 'tests.test_hia_selfhost_linked_observer': 14,
                'tests.test_hia_cli_native': 17}
            require(dict(Counter('.'.join(value.split('.')[:-2]) for value in components['loaded_test_ids']))
                    == expected_modules, 'complete native component module population differs')
            result['components']['module_counts'] = expected_modules
            for name, count in [('hia-journal-callers.json', 94), ('hia-machine-plan-callers.json', 44),
                                ('hia-json-wire-callers.json', 89)]:
                report = read(name)
                require(report['status'] == 'PASS' and report['scope'] == 'MATCHING_SOURCE_COLD_SELECTED_CALLERS',
                        'original selected caller scope/status differs')
                result[name] = strict(report, count)
                result[name]['seconds'] = report['wall_seconds']
            wire = read('hia-json-wire-callers.json')
            require(wire['retained_owner_entries'] == [] and wire['host_encoder_entries'] == []
                    and wire['retained_owner_forbidden'] is True
                    and wire['all_eleven_agent_tools_entered_selected_wire'] is True
                    and wire['matching_cold_source_closure_stable'] is True
                    and wire['source_manifest_image_stable'] is True, 'wire owner or source identity differs')
            result['wire_actual_calls'] = wire['ordinary_wire_calls']
            encoding = read('hia-machine-encoding-callers-evidence/report.json')
            require(encoding['status'] == 'PASS' and encoding['source_stable'] is True
                    and encoding['manifest_image_stable'] is True
                    and encoding['source_before'] == encoding['source_after'] == cold['source_manifest']
                    and encoding['retained_encoding_entries'] == [], 'encoding owner/source differs')
            require([row['label'] for row in encoding['groups']] == ['component', 'original-callers'],
                    'encoding group population differs')
            result['encoding'] = [strict(row, count, loaded='loaded_ids', executed='executed_ids')
                                  for row, count in zip(encoding['groups'], [9, 51])]
            require(len(encoding['native_entries']) == 37 and all(type(v) is int and v > 0
                    for v in encoding['native_entries'].values()), 'not all encoding commands actually entered')
            result['encoding_native_entries'] = encoding['native_entries']
            manifest_names = ['hia-machine-encoding-callers-evidence/build/manifest.json',
                'hia-json-wire-cache-fixture/build/manifest.json',
                'hia-json-wire-cache-fixture/format/manifest.json',
                'hia-cli-fixture/qualified/control/manifest.json',
                'hia-cli-fixture/qualified/format/manifest.json']
            result['native_image_bindings'] = []
            for name in manifest_names:
                manifest = read(name)
                image = str(PurePosixPath(name).parent / manifest['image_path'])
                raw = archive.read(image)
                require(manifest['compiler_sha256'] == compiler and sha(raw) == manifest['image_sha256']
                        and manifest['source_sha256'] in cold['source_manifest'].values(),
                        'retained image does not bind matching cold compiler and source')
                result['native_image_bindings'].append({'manifest': name, 'image': image,
                    'manifest_sha256': sha(archive.read(name)), 'image_sha256': sha(raw),
                    'image_bytes': len(raw), 'compiler_sha256': compiler,
                    'source_sha256': manifest['source_sha256']})
            cli = read('hia-cli-fixture/installed-control/report.json')
            installed = cli['installed_execution']
            require(cli['status'] == installed['status'] == 'PASS_INSTALLED_NATIVE_CLI_CONTROL'
                    and cli['original_sources_preserved'] is True
                    and cli['packaging_uses_declared_resources_only'] is True
                    and installed['isolated_without_site'] is True and installed['empty_PATH'] is True
                    and installed['forbidden_entries'] == {'retained_cli': [], 'retained_parser': [], 'tools': []}
                    and installed['sources_and_bundle_restored'] is True
                    and len(installed['calls']) == 8 and len(installed['refusals']) == 9,
                    'real installed CLI control differs')
            require(len(installed['native_returns']['control']) == 26
                    and len(installed['native_returns']['format']) == 14, 'installed native return population differs')
            require(all(row['returncode'] == 0 for row in cli['processes'])
                    and [row['label'] for row in cli['processes']] == ['wheel-build', 'wheel-install', 'installed-execution']
                    and all(flag in cli['processes'][-1]['argv'] for flag in ['-I', '-S', '-B']),
                    'real wheel/installed child process differs')
            wheel_raw = archive.read(location(cli['wheel']['path']))
            require(len(wheel_raw) == cli['wheel']['bytes'] and sha(wheel_raw) == cli['wheel']['sha256'],
                    'retained actual wheel bytes differ')
            production = {name: value for name, value in cold['source_manifest'].items()
                          if name.startswith('hepta/') and name.endswith('.py')}
            require(len(production) == 161, 'production source denominator differs')
            installed_root = 'hia-cli-fixture/installed-control/installed/'
            with zipfile.ZipFile(io.BytesIO(wheel_raw)) as wheel:
                wheel_python = {name for name in wheel.namelist() if name.startswith('hepta/') and name.endswith('.py')}
                generator_resource = 'hepta/_data/tools/generate_hia_artifact_publication.py'
                require(wheel_python == set(production) | {generator_resource},
                        'wheel production Python and declared generator resource population differs')
                generator_source = 'tools/generate_hia_artifact_publication.py'
                require(sha(wheel.read(generator_resource))
                        == sha(archive.read(installed_root + generator_resource))
                        == cold['source_manifest'][generator_source],
                        'declared Python generator resource bytes differ')
                for name, expected in production.items():
                    require(sha(wheel.read(name)) == sha(archive.read(installed_root + name)) == expected,
                            'actual wheel/install production module differs: ' + name)
                for kind, installed_path in installed['installed_source_paths'].items():
                    source = 'examples/hia_bootstrap/cli_' + kind + '.hiaasm'
                    member = 'hepta/_data/' + source
                    require(sha(wheel.read(member)) == sha(archive.read(location(installed_path)))
                            == installed['source_sha256'][kind] == cold['source_manifest'][source],
                            'actual wheel/install HIA resource differs')
            bundle_raw = archive.read(location(cli['manifest']))
            require(bundle_raw == archive.read(location(cli['original_manifest']))
                    and sha(bundle_raw) == installed['bundle_sha256'], 'installed CLI bundle differs')
            result['installed_cli'] = {'calls': 8, 'refusals': 9, 'production_python_files': 161,
                'native_resources': 2, 'additional_declared_python_generator_resources': 1,
                'control_native_returns': 26, 'format_native_returns': 14,
                'wheel': cli['wheel'], 'original_agent_entry': strict(read('hia-cli-fixture/original-agent-entry/report.json'), 6)}
            result['status'] = 'ORIGINAL_SUCCESS_REPORTS_BOUND_TO_COMPLETE_RETAINED_BYTES'
    except BaseException as error:
        result['exception'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        with args.output.open('x') as destination:
            json.dump(result, destination, sort_keys=True, indent=2)
            destination.write('\n')
        print(json.dumps({'status': result['status'], 'exception': result.get('exception'),
                          'qualification_executed': False}))


if __name__ == '__main__':
    main()
