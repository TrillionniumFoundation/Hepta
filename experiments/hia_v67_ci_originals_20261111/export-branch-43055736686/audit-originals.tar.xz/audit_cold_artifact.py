"""Read every original cold artifact byte without running or changing a gate."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import time
import traceback
import zipfile


def require(value, message):
    if not value:
        raise AssertionError(message)


def digest_stream(stream):
    digest, count = hashlib.sha256(), 0
    for block in iter(lambda: stream.read(1 << 20), b''):
        digest.update(block)
        count += len(block)
    return count, digest.hexdigest()


def save(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    require(path.read_bytes() == raw, 'audit output readback differs')


def safe_name(name):
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name.rstrip('/')
            and all(part not in ('.', '..') for part in path.parts),
            'unsafe archive name: ' + name)


def read_inventory(archive):
    names, rows = set(), {}
    for member in archive.infolist():
        safe_name(member.filename)
        require(member.filename not in names, 'duplicate archive member')
        names.add(member.filename)
        require(not member.flag_bits & 1, 'encrypted archive member')
        mode = member.external_attr >> 16
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR),
                'unexpected nonregular archive member')
        with archive.open(member) as stream:
            size, sha = digest_stream(stream)
        require(size == member.file_size, 'decoded member size mismatch')
        rows[member.filename] = {'size': size, 'sha256': sha,
            'mode': mode, 'crc32': f'{member.CRC:08x}',
            'directory': member.is_dir()}
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--archive-sha256', required=True)
    parser.add_argument('--archive-bytes', type=int, required=True)
    parser.add_argument('--source-package-archive', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(mode=0o700, exist_ok=False)
    result = {'schema': 'hia.original-cold-artifact-independent-audit.v1',
        'status': 'HOLD', 'qualification_executed': False,
        'original_test_status_unchanged': True, 'whole_native_delivery_qualified': False}
    started = time.monotonic_ns()
    try:
        with args.archive.open('rb') as stream:
            size, sha = digest_stream(stream)
        require(size == args.archive_bytes and sha == args.archive_sha256,
                'official archive digest/size differs')
        result['original_archive'] = {'path': str(args.archive), 'size': size, 'sha256': sha}
        with zipfile.ZipFile(args.source_package_archive) as source_zip:
            raw_manifest = source_zip.read('package/manifest.json')
        require(hashlib.sha256(raw_manifest).hexdigest()
                == 'cec14d50ede38a6bcd11595476975cc376b3606d211098a565a5b1593249e3af',
                'external canonical source manifest differs')
        canonical = json.loads(raw_manifest)
        require(canonical['commit']['oid'] == '608157e52b0b94e0d294f6b99c4e809869f183aa'
                and canonical['tree'] == 'e7c29a60796a1a78946a2c667aa80df86529e532',
                'canonical source commit/tree differs')
        leaves = {row['path']: row for row in canonical['leaves']}
        with zipfile.ZipFile(args.archive) as archive:
            inventory = read_inventory(archive)
            save(args.output / 'outer-members.json', inventory)
            cold = json.loads(archive.read('hia-cold.json'))
            owner = json.loads(archive.read('hia-cold.cold/process-owner.json'))
            index = json.loads(archive.read('hia-cold.cold/qualification.evidence/phase-index.json'))
            require(cold['process_owner'] == owner, 'cold owner differs from original owner file')
            sources = cold['source_manifest']
            require(len(sources) == 682, 'cold source denominator differs')
            prefix = 'hia-cold.cold/source/'
            source_names = {name[len(prefix):] for name, row in inventory.items()
                            if name.startswith(prefix) and not row['directory']}
            require(source_names == set(sources), 'export source population differs')
            bindings = []
            for name, expected in sources.items():
                original = inventory[prefix + name]
                git = leaves[name]
                raw = archive.read(prefix + name)
                blob = hashlib.sha1(('blob ' + str(len(raw)) + '\0').encode() + raw).hexdigest()
                require(original['sha256'] == expected == git['sha256']
                        and original['size'] == git['size'] and blob == git['oid'],
                        'cold source bytes differ from frozen Git leaf: ' + name)
                require(stat.S_IMODE(original['mode']) == 0o400,
                        'original cold export is not readonly 0400: ' + name)
                bindings.append({'path': name, 'size': len(raw), 'sha256': expected,
                    'git_blob_sha1': blob, 'canonical_git_mode': git['mode'], 'cold_export_mode': '0400'})
            save(args.output / 'source-bindings.json', bindings)
            contract = json.loads(archive.read(prefix + 'docs/HIA_SELFHOST_CORE_SUPPORT.json'))
            require({**contract['source_identity']['files'],
                     'docs/HIA_SELFHOST_CORE_SUPPORT.json': sources['docs/HIA_SELFHOST_CORE_SUPPORT.json']}
                    == sources, 'cold export differs from declared contract closure')
            require(cold['qualification_wall_limit_seconds'] == 180
                    and cold['cleanup_wall_limit_seconds'] == 3
                    and owner['qualification_seconds'] == 180
                    and len(index['phases']) == 38, 'original limits or phase denominator differ')
            phases = []
            for phase in index['phases']:
                row = dict(phase)
                if phase['state'] == 'completed':
                    process_name = phase['process_receipt'].split('/_temp/', 1)[1]
                    process = json.loads(archive.read(process_name))
                    report_name = phase['report'].split('/_temp/', 1)[1]
                    require(inventory[report_name]['sha256'] == process['report_sha256'],
                            'phase original report digest differs')
                    retention = process['raw_artifacts']
                    packed_name = retention['archive'].split('/_temp/', 1)[1]
                    require(inventory[packed_name]['size'] == retention['packed_bytes']
                            and inventory[packed_name]['sha256'] == retention['archive_sha256'],
                            'phase original archive differs from retention receipt')
                    with zipfile.ZipFile(io.BytesIO(archive.read(packed_name))) as nested:
                        nested_rows = read_inventory(nested)
                        manifest_raw = nested.read('HIA_ARCHIVE_MANIFEST.json')
                        require(hashlib.sha256(manifest_raw).hexdigest() == retention['manifest_sha256'],
                                'phase manifest digest differs')
                        manifest = json.loads(manifest_raw)
                        require(set(nested_rows) == set(manifest['files']) | {'HIA_ARCHIVE_MANIFEST.json'},
                                'phase archive population differs')
                        total = 0
                        for name, pin in manifest['files'].items():
                            actual = nested_rows[name]
                            require(actual['size'] == pin['bytes']
                                    and actual['sha256'] == pin['sha256']
                                    and stat.S_IMODE(actual['mode']) == pin['mode'],
                                    'nested member bytes/mode differ: ' + name)
                            total += actual['size']
                        require(len(manifest['files']) == retention['files']
                                and total == manifest['unpacked_bytes'] == retention['unpacked_bytes'],
                                'phase retention denominator differs')
                    label = phase['family'] + '-' + phase['compiler_label']
                    save(args.output / ('nested-' + label + '.json'), nested_rows)
                    row.update(actual_files=len(manifest['files']), actual_unpacked_bytes=total,
                        all_member_hashes_modes_verified=True, wall_elapsed_ns=process['wall_elapsed_ns'],
                        started_monotonic_ns=process['started_monotonic_ns'],
                        completed_monotonic_ns=process['completed_monotonic_ns'],
                        archive_completed_monotonic_ns=process['archive_completed_monotonic_ns'])
                phases.append(row)
            require(sum(p['state'] == 'completed' for p in phases) == index['completed'],
                    'completed phase count differs')
            save(args.output / 'phases.json', phases)
            result.update(status='ORIGINAL_EVIDENCE_INTEGRITY_VERIFIED',
                original_cold_status=cold['status'], original_cold_checks=cold['checks'],
                original_elapsed_ns=cold['wall_elapsed_ns'], original_returncode=cold['returncode'],
                original_process_owner=owner, completed_phases=index['completed'],
                phase_exceptions=index['exceptions'], phase_denominator=len(phases),
                unfinished_phases=[{'family':p['family'], 'compiler_label':p['compiler_label']}
                                   for p in phases if p['state'] != 'completed'],
                outer_members=len(inventory), outer_decoded_bytes=sum(x['size'] for x in inventory.values()),
                source_bindings=len(bindings), nested_archives=index['completed'],
                nested_files=sum(x.get('actual_files', 0) for x in phases),
                nested_decoded_bytes=sum(x.get('actual_unpacked_bytes', 0) for x in phases),
                canonical_head=canonical['commit']['oid'], canonical_tree=canonical['tree'])
    except BaseException as error:
        result['exception'] = {'type': type(error).__name__, 'message': str(error),
                               'traceback': traceback.format_exc()}
        raise
    finally:
        result['elapsed_ns'] = time.monotonic_ns() - started
        save(args.output / 'AUDIT.json', result)
        print(json.dumps({k:v for k,v in result.items() if k not in
              ('original_process_owner', 'original_cold_checks')}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
