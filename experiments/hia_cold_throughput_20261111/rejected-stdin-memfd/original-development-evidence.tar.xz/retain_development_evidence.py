"""Create and independently replay an exact development evidence container."""
from pathlib import Path
from hashlib import sha256
import json, os, stat, tarfile

root = Path('/workspace/scratch/e26ed3e2edcf/cold-throughput-development-r1')
destination = Path('/workspace/scratch/e26ed3e2edcf/cold-throughput-development-originals.tar.xz')
receipt_path = destination.with_suffix('.retention.json')
assert not destination.exists() and not receipt_path.exists()
paths = [p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
records = {}
for path in sorted(paths):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1
    raw = path.read_bytes()
    name = path.relative_to(root).as_posix()
    records[name] = {'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
                     'mode': stat.S_IMODE(st.st_mode), 'uid': st.st_uid, 'gid': st.st_gid}
with tarfile.open(destination, 'w:xz', preset=6) as packed:
    for name in records:
        packed.add(root / name, arcname=name, recursive=False)
with destination.open('rb') as stream:
    os.fsync(stream.fileno())
seen = set()
read_bytes = 0
with tarfile.open(destination, 'r:xz') as packed:
    for member in packed:
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        row = records[member.name]
        assert (member.size, member.mode, member.uid, member.gid) == (
            row['bytes'], row['mode'], row['uid'], row['gid'])
        digest = sha256()
        with packed.extractfile(member) as source:
            for block in iter(lambda: source.read(1 << 20), b''):
                digest.update(block)
                read_bytes += len(block)
        assert digest.hexdigest() == row['sha256']
assert seen == set(records)
for name, row in records.items():
    path = root / name
    st = path.lstat()
    assert (st.st_size, stat.S_IMODE(st.st_mode), st.st_uid, st.st_gid) == (
        row['bytes'], row['mode'], row['uid'], row['gid'])
    assert sha256(path.read_bytes()).hexdigest() == row['sha256']
receipt = {'schema': 'hia.cold-throughput.development-evidence-retention.v1',
           'archive': str(destination), 'archive_bytes': destination.stat().st_size,
           'archive_sha256': sha256(destination.read_bytes()).hexdigest(),
           'members': records, 'member_count': len(records),
           'independently_read_every_member': True, 'member_bytes_read': read_bytes,
           'mode_uid_gid_checked': True, 'source_before_after_equal': True,
           'nested_phase_zip_payloads': 'Originally fully replayed by archive_completed_stage before retirement; exact ZIP bytes independently reread here',
           'evidence_only_not_cold_qualification': True}
with receipt_path.open('x') as stream:
    json.dump(receipt, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}), flush=True)
