"""Adjacent real transport comparisons; neither variant is qualification."""
from pathlib import Path
from hashlib import sha256
import importlib.util, json, statistics, sys, tempfile, time, zipfile
repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo))
root = Path('/workspace/scratch/e26ed3e2edcf/cold-throughput-development-r1')
from tools import hia_selfhost_native_observer as current
spec = importlib.util.spec_from_file_location('exact_pipe_transport', root / 'observer-f17b677-original.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
receipt = json.loads((root / 'signed-baseline/signed-native-baseline.json').read_text())
observer = Path(receipt['temporary_directory']) / 'observer/native-observer.elf'
executable = observer.read_bytes()
compiler = Path('/workspace/scratch/e26ed3e2edcf/journal-recovered-development-r1/development-compiler.bin').read_bytes()
assert sha256(compiler).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
with zipfile.ZipFile(root / 'signed-baseline/signed-native-baseline-originals.zip') as archived:
    source = archived.read('original-signed-signed-arithmetic-4f53cda18c2b-batch-42-flat.input.bin')
shapes = [('invalid-compiler-input', b'invalid', 20),
          ('signed-batch-58960-bytes', source, 12),
          ('complete-selfhost-source', (repo / 'examples/hia_bootstrap/selfhost.hiaasm').read_bytes(), 4)]
results = []
with tempfile.TemporaryDirectory(prefix='hia-e26e-input-pairs-') as folder:
    for name, source, count in shapes:
        request = current.frame(compiler, source, 1 << 20, 1 << 20, 0)
        rows = []
        expected = None
        for index in range(count):
            order = ('pipe', 'sealed-memfd') if index % 2 == 0 else ('sealed-memfd', 'pipe')
            for variant in order:
                run = old.execute if variant == 'pipe' else current.execute
                started = time.monotonic_ns()
                response = run(executable, request, cwd=folder)
                elapsed = time.monotonic_ns() - started
                assert response.returncode == 0 and response.stderr == b''
                assert response.stdout[:8] == b'HIAOBR02'
                # The clock field is observational, not a program result.
                content = response.stdout[:16] + response.stdout[24:]
                result_hash = sha256(content).hexdigest()
                if expected is None:
                    expected = result_hash
                assert result_hash == expected
                rows.append({'pair': index, 'variant': variant,
                             'wall_ns': elapsed, 'native_ns': int.from_bytes(response.stdout[16:24], 'little'),
                             'response_sha256_excluding_clock': result_hash,
                             'response_bytes': len(response.stdout)})
        times = {variant: [r['wall_ns'] for r in rows if r['variant'] == variant]
                 for variant in ('pipe', 'sealed-memfd')}
        results.append({'name': name, 'request_bytes': len(request),
                        'request_sha256': sha256(request).hexdigest(), 'rows': rows,
                        'median_ns': {k: statistics.median(v) for k, v in times.items()},
                        'sum_ns': {k: sum(v) for k, v in times.items()}})
report = {'schema': 'hia.cold-throughput.adjacent-input-transport-development.v1',
          'scope': 'Fresh real processes; equal complete returned bytes except elapsed clock; no cold status inferred',
          'observer_sha256': sha256(executable).hexdigest(), 'compiler_sha256': sha256(compiler).hexdigest(),
          'results': results}
with (root / 'paired-input-transport-observations-r1.json').open('x') as stream:
    json.dump(report, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps([{k: row[k] for k in ('name', 'median_ns', 'sum_ns')} for row in results]))
