"""Development profile of one real phase; not cold or release qualification."""
from pathlib import Path
from hashlib import sha256
import cProfile, json, os, pstats, secrets, shutil, sys, tempfile, time

repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo))
out = Path(sys.argv[2]).resolve()
out.mkdir(mode=0o700, exist_ok=False)
from tools import qualify_hia_selfhost as q
from tools import hia_selfhost_native_observer as observer
from tools import hia_selfhost_signed_cases as signed
from tools.hia_evidence_archive import OWNER, archive_completed_stage

compiler = Path('/workspace/scratch/e26ed3e2edcf/journal-recovered-development-r1/development-compiler.bin')
compiler_hash = sha256(compiler.read_bytes()).hexdigest()
assert compiler_hash == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
before = q.source_manifest()
root = Path(tempfile.mkdtemp(prefix='hia-e26e-signed-development-', dir='/tmp'))
observer_dir = root / 'observer'
observer_dir.mkdir(mode=0o700)
vm_reference = observer.independent_reference()
native_observer, build = observer.build(observer_dir, compiler, vm_reference)
reference_start = time.monotonic_ns()
reference = signed.independent_reference()
reference_ns = time.monotonic_ns() - reference_start
stage = root / 'signed-original'
stage.mkdir(mode=0o700)
token = secrets.token_hex(32)
(stage / OWNER).write_text(token)
checks = {}
q.NATIVE_OBSERVER = native_observer
prof = cProfile.Profile()
started = time.monotonic_ns()
prof.enable()
observations = signed.qualify(stage, (('original', compiler),), checks, reference)
prof.disable()
elapsed = time.monotonic_ns() - started
q.NATIVE_OBSERVER = None
assert checks and all(type(value) is bool and value for value in checks.values())
assert before == q.source_manifest()
prof.dump_stats(str(out / 'signed-native-baseline.pstats'))
with (out / 'signed-native-baseline-profile.txt').open('x') as stream:
    pstats.Stats(prof, stream=stream).sort_stats('cumulative').print_stats(65)
receipts = []
for path in stage.glob('*.receipt.json'):
    value = json.loads(path.read_text())
    receipts.append({'name': path.name, 'status': value['status'],
                     'wall_ns': value['wall_elapsed_ns'],
                     'native_ns': value.get('native_elapsed_ns'),
                     'input_bytes': value['input_bytes']})
report = {'schema': 'hia.cold-throughput.development-native-phase.v1',
    'scope': 'Fresh original signed native phase with development compiler; no cold qualification or current fixed-point assertion',
    'compiler_sha256': compiler_hash, 'source_manifest': before,
    'source_preserved': True, 'wall_elapsed_ns_including_profiler': elapsed,
    'independent_reference_wall_ns': reference_ns,
    'reference_counts': {key: len(reference[key]) for key in ('cases', 'refusals', 'traps')},
    'checks': checks, 'observations': observations, 'receipts': receipts,
    'temporary_directory': str(root)}
(out / 'signed-native-baseline.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
sealed = archive_completed_stage(stage, token)
archive = Path(sealed['archive'])
saved = out / 'signed-native-baseline-originals.zip'
with archive.open('rb') as src, saved.open('xb') as dest:
    shutil.copyfileobj(src, dest)
    dest.flush()
    os.fsync(dest.fileno())
assert sha256(saved.read_bytes()).hexdigest() == sealed['archive_sha256']
(out / 'signed-native-baseline-retention.json').write_text(json.dumps(sealed, sort_keys=True, indent=2) + '\n')
print(json.dumps({'directory': str(out), 'profiled_phase_seconds': elapsed / 1e9,
                  'independent_reference_seconds': reference_ns / 1e9,
                  'checks': len(checks), 'actual_invocations': len(receipts),
                  'summed_native_seconds': sum(r['native_ns'] or 0 for r in receipts) / 1e9,
                  'summed_invoke_wall_seconds': sum(r['wall_ns'] for r in receipts) / 1e9,
                  'archive_bytes': saved.stat().st_size, 'archive_sha256': sealed['archive_sha256']}), flush=True)
