# Synthetic receipt controller; no product code executed.
