"""Actual AArch64 execution of a finite standalone HIA Core corpus.

This harness consumes independently verified Core, not a source AST. It reuses
the exact reviewed 4096-byte, one-live-allocation runtime primitives, adding a
calloc adapter and a fixed scalar C ABI driver. QEMU userspace execution is
reported separately from physical hardware or a production runtime.
"""
from __future__ import annotations

from hashlib import sha256
import os
from pathlib import Path
import shutil
import stat
import tempfile

from .clang_capture import run_bounded
from .hia_program import verify_program
from .hia_program_llvm import (TARGET_AARCH64, HIAProgramLLVMRejected, _run_logged,
                               compile_program_llvm, emit_program_llvm, native_host_profile)
from .native_tool_identity import digest_executable
from .object_symbols import inspect_object_symbols
from .hia_aarch64_elf import inspect_synthetic_aarch64_elf


PROFILE = "hepta.hia.program.aarch64-finite-runtime.v1"
PROFILE_COMPOSITE = "hepta.hia.program.aarch64-composite-bulk-runtime.v1"
PROFILE_NATIVE = "hepta.hia.program.aarch64-native-finite-runtime.v1"
PROFILE_NATIVE_COMPOSITE = "hepta.hia.program.aarch64-native-composite-bulk-runtime.v1"
REVIEWED_RUNTIME_SHA256 = "5caa9cbc33df5734626ff17045159add08b850abceb021b038ddb110db6f402c"
REVIEWED_MULTI_RUNTIME_SHA256 = "c0fa3bbee8f3d792908854bd3cde4428fb3876beff55f729278739b2341fc4a3"
QEMU_SHA256 = "e4f8d99e9ff69c3cefffab71cee358ce2af1ecba1282d04c3eeb44ef76f5a71e"
_FIXTURE = Path(__file__).resolve().parents[1] / "examples/hia_program/finite_aarch64_runtime.c"
_MULTI_FIXTURE = Path(__file__).resolve().parents[1] / "examples/hia_program/finite_aarch64_multi_runtime.c"
_MARKER = b"/* Exact selected Hepta export; unlike the synthetic stub, invoked for real. */"
_RUNTIME_EXPORTS = frozenset({"malloc", "calloc", "free", "abort", "memcpy", "memmove", "memset", "_start"})
_TYPES = {"usize": "hepta_size", "u8": "hepta_u8", "i8": "signed char", "u32": "hepta_u32",
          "u64": "hepta_u64", "i64": "__INT64_TYPE__", "bool": "_Bool"}
_SIGNATURES = {
    "fill_sum": (["usize", "u8"], ["u64"]),
    "try_capacity": (["usize"], ["u64"]),
    "scalar_mix": (["i64", "i64", "bool"], ["i64"]),
    "tuple_call": (["u64", "u64"], ["u64"]),
    "bool_gate": (["bool", "bool"], ["bool"]),
    "int_add_wrap_u32": (["u32", "u32"], ["u32"]),
    "int_div_checked_i64": (["i64", "i64"], ["i64"]),
    "int_shr_checked_i64": (["i64", "i64"], ["i64"]),
    "cast_i8_u64": (["u64"], ["i8"]),
    "bounds_trap": (["usize"], ["u8"]),
    "move_bytes": (["usize", "usize", "usize", "usize", "usize"], ["u8"]),
    "fill_range": (["usize", "usize", "usize", "u8", "usize"], ["u8"]),
    "aggregate_bulk": (["usize", "usize", "usize", "u8", "usize"], ["u8"]),
}

# The native harness checks these same fixed values after real ABI calls.
# The capacity rejection uses a real NULL from the finite target allocator;
# the interpreter compares that case with its explicit allocation failure hook.
CASES = (
    ("fill_sum", (16, 7), 112, None),
    ("fill_sum", (0, 255), 0, None),
    ("fill_sum", (128, 3), 384, None),
    ("fill_sum", (4096, 1), 4096, None),
    ("try_capacity", (16,), 16, None),
    ("try_capacity", (5000,), 99, 1),
    ("try_capacity", (0,), 0, None),
    ("try_capacity", ((1 << 64) - 1,), 99, None),
    ("scalar_mix", (12, 3, True), 26, None),
    ("scalar_mix", (-8, 7, False), -8, None),
    ("tuple_call", (8, 23), 15, None),
    ("bool_gate", (False, True), True, None),
    ("bool_gate", (False, False), False, None),
    ("int_add_wrap_u32", ((1 << 32) - 1, 1), 0, None),
    ("int_div_checked_i64", (-1024, 7), -146, None),
    ("int_shr_checked_i64", (-1024, 3), -128, None),
    ("cast_i8_u64", (255,), -1, None),
)

# Eight real ABI calls use one allocated 5-byte owner per invocation. The
# expected values exercise both overlap directions, an identical range,
# zero-length movement and normal Drop of every owner.
_OVERLAP_CASES = (
    ((5, 1, 0, 4, 0), 11),
    ((5, 1, 0, 4, 2), 22),
    ((5, 1, 0, 4, 4), 44),
    ((5, 0, 1, 4, 0), 22),
    ((5, 0, 1, 4, 3), 55),
    ((5, 2, 2, 3, 4), 55),
    ((5, 5, 5, 0, 0), 11),
    ((5, 0, 0, 0, 4), 55),
)

# Eight fixed ABI calls, one 1- or 5-byte owner per call. All range
# checks are in the verified Core LLVM, not duplicated by this C oracle.
_RANGE_FILL_CASES = (
    ((5, 1, 3, 7, 0), 0),
    ((5, 1, 3, 7, 1), 7),
    ((5, 1, 3, 7, 3), 7),
    ((5, 1, 3, 7, 4), 0),
    ((5, 5, 0, 7, 4), 0),
    ((1, 0, 0, 99, 0), 0),
    ((1, 0, 1, 99, 0), 99),
    ((5, 0, 5, 42, 4), 42),
)

# Independent fixed outputs for a two-owner nominal record. The input source
# composes fill, partial fill, swap, overlap move and disjoint offset copy.
# A separate Python byte-array oracle in the qualification command rechecks
# these values; the native driver observes allocator events itself.
COMPOSITE_BULK_CASES = (
    ((5, 1, 3, 77, 0), None, 11),
    ((5, 1, 3, 77, 1), None, 11),
    ((5, 1, 3, 77, 2), None, 11),
    ((5, 1, 3, 77, 3), None, 77),
    ((5, 1, 3, 77, 4), None, 11),
    ((8, 2, 4, 255, 0), None, 11),
    ((8, 2, 4, 255, 1), None, 11),
    ((8, 2, 4, 255, 2), None, 11),
    ((8, 2, 4, 255, 3), None, 11),
    ((8, 2, 4, 255, 4), None, 255),
    ((8, 2, 4, 255, 5), None, 11),
    ((8, 2, 4, 255, 6), None, 11),
    ((8, 2, 4, 255, 7), None, 11),
    ((1, 1, 0, 99, 0), None, 11),
    ((0, 0, 0, 17, 0), None, 0),
    ((4096, 4096, 0, 31, 4095), None, 11),
    ((5, 1, 3, 77, 3), 1, 251),
    ((5, 1, 3, 77, 3), 2, 252),
)
COMPOSITE_BULK_TRAPS = {
    "composite_bulk_fill_trap": (5, 4, 2, 7, 0),
    "composite_bulk_swap_trap": (5, 1, 3, 7, 5),
    "composite_bulk_move_trap": (5, 0, 5, 7, 0),
}


_ADAPTER = r"""
/* The standalone Core requests zero-filled bytes through this exact adapter. */
__attribute__((noinline)) void *calloc(hepta_size count, hepta_size width) {
    if (width && count > ((hepta_size)-1) / width) {
        ++denied_allocations;
        return (void *)0;
    }
    hepta_size bytes = count * width;
    void *result = malloc(bytes);
    if (result) memset(result, 0, bytes);
    return result;
}

static void write_counters(void) {
    char text[96];
    hepta_size used = 0;
    const char prefix[] = "HIA_AARCH64 resources ";
    for (hepta_size i = 0; i < sizeof(prefix) - 1; ++i) text[used++] = prefix[i];
    hepta_u32 values[4] = {successful_allocations, releases, outstanding, denied_allocations};
    for (hepta_size i = 0; i < 4; ++i) {
        char digits[10];
        hepta_size n = 0;
        hepta_u32 v = values[i];
        do { digits[n++] = (char)('0' + v % 10); v /= 10; } while (v);
        while (n) text[used++] = digits[--n];
        text[used++] = i == 3 ? '\n' : ' ';
    }
    register long x0 __asm__("x0") = 1;
    register const char *x1 __asm__("x1") = text;
    register hepta_size x2 __asm__("x2") = used;
    register long x8 __asm__("x8") = 64;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x8) : "memory");
    if (x0 != (long)used) hepta_exit(40);
}
"""

_MULTI_OBSERVER = r"""
static void write_case(hepta_u32 index, hepta_u32 result) {
    char text[96]; hepta_size used = 0;
    const char prefix[] = "HIA_BULK case ";
    for (hepta_size i = 0; i < sizeof(prefix) - 1; ++i) text[used++] = prefix[i];
    hepta_u32 values[2] = {index, result};
    for (hepta_size i = 0; i < 2; ++i) {
        char digits[10]; hepta_size n = 0; hepta_u32 v = values[i];
        do { digits[n++] = (char)('0' + v % 10); v /= 10; } while (v);
        while (n) text[used++] = digits[--n];
        text[used++] = i == 1 ? '\n' : ' ';
    }
    register long x0 __asm__("x0") = 1;
    register const char *x1 __asm__("x1") = text;
    register hepta_size x2 __asm__("x2") = used;
    register long x8 __asm__("x8") = 64;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x8) : "memory");
    if (x0 != (long)used) hepta_exit(40);
}
"""


class HIAProgramAArch64Rejected(ValueError):
    pass


def _reject(message):
    raise HIAProgramAArch64Rejected("E_HIA_PROGRAM_AARCH64: " + message)


def _read(path, limit):
    """Bound file size before allocation and reject path/fd replacement."""
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or not 0 < before.st_size <= limit:
        _reject("expected a bounded ordinary file: " + str(path))
    key = lambda st: (st.st_dev, st.st_ino, st.st_mode, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC |
                           getattr(os, "O_NOFOLLOW", 0)), "rb") as stream:
        if key(os.fstat(stream.fileno())) != key(before):
            _reject("file changed before reading")
        raw = stream.read(limit + 1)
        if len(raw) != before.st_size or key(os.fstat(stream.fileno())) != key(before):
            _reject("file changed during reading")
    if key(path.lstat()) != key(before):
        _reject("file pathname changed after reading")
    return raw


def _runtime_prefix():
    raw = _read(_FIXTURE, 8192)
    if sha256(raw).hexdigest() != REVIEWED_RUNTIME_SHA256 or raw.count(_MARKER) != 1:
        _reject("reviewed finite runtime identity changed")
    return raw.split(_MARKER)[0].decode("ascii")


def _multi_runtime_prefix():
    raw = _read(_MULTI_FIXTURE, 16384)
    if sha256(raw).hexdigest() != REVIEWED_MULTI_RUNTIME_SHA256:
        _reject("reviewed finite multi-owner runtime identity changed")
    return raw.decode("ascii")


def _implementation_hash():
    digest = sha256()
    for name in ("hia_program_aarch64.py", "hia_aarch64_elf.py"):
        digest.update(name.encode("ascii") + b"\0" + _read(Path(__file__).with_name(name), 65536))
    return digest.hexdigest()


def _literal(value, typ):
    if typ == "bool":
        return "1" if value else "0"
    return "((" + _TYPES[typ] + ")" + str(value) + ("ULL" if value >= 0 else "LL") + ")"


def _runtime_source(document, mode):
    multi = mode == "composite_bulk" or mode in COMPOSITE_BULK_TRAPS
    if not multi and mode not in {"matrix", "bounds_trap", "overlap_move", "range_fill"}:
        _reject("unsupported fixed target driver mode")
    functions = {fn["name"]: fn for fn in document["functions"]}
    required = ({"aggregate_bulk"} if multi else {row[0] for row in CASES} if mode == "matrix"
                else {"move_bytes"} if mode == "overlap_move"
                else {"fill_range"} if mode == "range_fill" else {"bounds_trap"})
    declarations = []
    for name in sorted(required):
        params, returns = _SIGNATURES[name]
        fn = functions.get(name)
        if (fn is None or [p["type"] for p in fn["params"]] != params
                or fn["returns"] != returns):
            _reject("fixed runtime scalar ABI mismatch for " + name)
        declarations.append("extern " + _TYPES[returns[0]] + " " + name + "(" +
                            ", ".join(_TYPES[typ] for typ in params) + ");")
    lines = ["static int smoke(void) {", "    if (!memory_primitives_ok()) return 39;"]
    if mode == "composite_bulk":
        params, returns = _SIGNATURES["aggregate_bulk"]
        for index, (arguments, failure, expected) in enumerate(COMPOSITE_BULK_CASES):
            call = "aggregate_bulk(" + ", ".join(_literal(v, t) for v, t in zip(arguments, params)) + ")"
            lines += ["    failure_countdown = " + str(failure or 0) + ";",
                      "    hepta_u8 value_" + str(index) + " = " + call + ";",
                      "    write_case(" + str(index) + ", value_" + str(index) + ");",
                      "    if (value_" + str(index) + " != " + _literal(expected, returns[0]) + ") return 41;",
                      "    if (outstanding) { write_counters(); return 91; }",
                      "    if (failure_countdown) return 92;"]
        lines += ["    write_counters();",
                  "    if (successful_allocations != 31 || releases != 31 || outstanding != 0 || denied_allocations != 2 || peak_outstanding != 2) return 93;",
                  "    return 0;"]
    elif mode in COMPOSITE_BULK_TRAPS:
        params, _ = _SIGNATURES["aggregate_bulk"]
        call = "aggregate_bulk(" + ", ".join(_literal(v, t) for v, t in zip(COMPOSITE_BULK_TRAPS[mode], params)) + ")"
        lines += ["    hepta_u8 unexpected = " + call + ";", "    write_case(0, unexpected);",
                  "    write_counters();", "    return 41;"]
    elif mode == "matrix":
        for index, (name, arguments, expected, _) in enumerate(CASES):
            params, returns = _SIGNATURES[name]
            call = name + "(" + ", ".join(_literal(v, t) for v, t in zip(arguments, params)) + ")"
            lines.append("    if (" + call + " != " + _literal(expected, returns[0]) + ") return " + str(11 + index) + ";")
        lines += ["    write_counters();",
                  "    if (successful_allocations != 4 || releases != 4 || outstanding != 0 || denied_allocations != 1) return 38;",
                  "    return 0;"]
    elif mode == "overlap_move":
        # This is the same fixed scalar ABI + arena as the historical corpus.
        # Only the single 5-byte owned buffer is live during each call;
        # memmove must preserve overlapping original byte values.
        params, returns = _SIGNATURES["move_bytes"]
        for index, (arguments, expected) in enumerate(_OVERLAP_CASES):
            call = "move_bytes(" + ", ".join(
                _literal(v, t) for v, t in zip(arguments, params)) + ")"
            lines.append("    if (" + call + " != " +
                         _literal(expected, returns[0]) + ") return " + str(50 + index) + ";")
        lines += ["    write_counters();",
                  "    if (successful_allocations != 8 || releases != 8 || outstanding != 0 || denied_allocations != 0) return 79;",
                  "    return 0;"]
    elif mode == "range_fill":
        # Directly invoke the emitted HIA v6 function with the reviewed
        # single-owner runtime, including partial writes and zero-count.
        params, returns = _SIGNATURES["fill_range"]
        for index, (arguments, expected) in enumerate(_RANGE_FILL_CASES):
            call = "fill_range(" + ", ".join(
                _literal(value, typ) for value, typ in zip(arguments, params)) + ")"
            lines.append("    if (" + call + " != " +
                         _literal(expected, returns[0]) + ") return " + str(80 + index) + ";")
        lines += ["    write_counters();",
                  "    if (successful_allocations != 8 || releases != 8 || outstanding != 0 || denied_allocations != 0) return 99;",
                  "    return 0;"]
    else:
        # Reaching this would demonstrate that the expected trap was absent.
        lines += ["    (void)bounds_trap(1);", "    write_counters();", "    return 41;"]
    lines += ["}", "__attribute__((noreturn)) void _start(void) { hepta_exit((hepta_u32)smoke()); }"]
    prefix = _multi_runtime_prefix() if multi else _runtime_prefix()
    observer = _MULTI_OBSERVER if multi else ""
    return prefix + _ADAPTER + observer + "\n".join(declarations + lines) + "\n", required


def _tool(path, role):
    found = shutil.which(path)
    if found is None:
        _reject(role + " unavailable")
    resolved = Path(found).resolve(strict=True)
    return resolved, digest_executable(resolved)


def _execution_host(execution, qemu_aarch64):
    """Admit explicit direct execution only on measured Linux AArch64 LP64.

    These are local OS/ABI observations, not external hardware attestation.
    An AArch64 VM is distinct from a physical-board qualification. No custom
    emulator/runner path or implicit cross-host fallback is accepted as native.
    """
    if type(execution) is not str or execution not in {"qemu", "native"}:
        _reject("execution must be explicit qemu or native")
    if execution == "qemu":
        if qemu_aarch64 is None:
            _reject("QEMU execution requires its explicit reviewed runner path")
        return None
    if qemu_aarch64 is not None:
        _reject("native execution cannot accept a QEMU runner path")
    try:
        host = native_host_profile()
    except HIAProgramLLVMRejected as error:
        raise HIAProgramAArch64Rejected(
            "E_HIA_PROGRAM_AARCH64: native execution requires an actual Linux AArch64 LP64 host") from error
    if host["target"] != TARGET_AARCH64 or host["normalized_machine"] != "aarch64":
        _reject("native execution requires an actual Linux AArch64 LP64 host")
    kernel = os.uname()
    if kernel.sysname != "Linux" or kernel.machine.lower() not in {"aarch64", "arm64"}:
        _reject("native execution host and kernel architecture disagree")
    return {**host, "kernel_release": kernel.release,
            "observation_scope": "local OS and LP64 ABI; no external hardware attestation"}


def run_finite_program_aarch64(program, *, clang, linker, qemu_aarch64=None, mode="matrix",
                               execution="qemu", command_log=None):
    """Compile checked Core and run the same driver via explicit QEMU/native.

    This returns the actual exit code, including deliberate negative controls.
    Qualification callers must assess that exit code and retained evidence.
    Default QEMU mode retains its original v1 report. Native adds its own
    profile, measured host and full bounded command observations; it is never
    evidence of a physical board or whole-backend refinement.
    """
    host_before = _execution_host(execution, qemu_aarch64)
    if command_log is not None and (execution != "native" or type(command_log) is not list):
        _reject("native command log must be a plain list; QEMU retains its original report")
    commands = ([] if command_log is None else command_log) if execution == "native" else None
    command_begin = len(commands) if commands is not None else None
    run = (lambda argv, **kwargs: _run_logged(argv, command_log=commands, **kwargs)) if commands is not None else run_bounded
    verified = verify_program(program)
    ir = emit_program_llvm(verified, target=TARGET_AARCH64)
    multi = mode == "composite_bulk" or mode in COMPOSITE_BULK_TRAPS
    own_before = _implementation_hash()
    compiler, compiler_sha = _tool(clang, "Clang")
    lld, linker_sha = _tool(linker, "LLVM lld")
    tools = [(compiler, compiler_sha), (lld, linker_sha)]
    if execution == "qemu":
        runner, runner_sha = _tool(qemu_aarch64, "QEMU AArch64")
        if runner_sha != QEMU_SHA256:
            _reject("QEMU runner differs from the exact reviewed 8.2.2 executable")
        tools.append((runner, runner_sha))
    elif any(path.name.lower().startswith("qemu") or digest == QEMU_SHA256 for path, digest in tools):
        _reject("native target tools cannot be a QEMU runner")
    runtime, required = _runtime_source(verified.as_dict(), mode)
    runner_version = run([str(runner), "--version"], timeout=10, stdout_limit=65536, stderr_limit=65536) if execution == "qemu" else None
    linker_version = run([str(lld), "-flavor", "gnu", "--version"], timeout=10, stdout_limit=65536, stderr_limit=65536)
    if (runner_version is not None and runner_version.returncode) or linker_version.returncode or "LLD" not in linker_version.stdout:
        _reject("real target runner or LLVM linker identity unavailable")
    with tempfile.TemporaryDirectory(prefix=".hia-aarch64-") as directory:
        folder = Path(directory)
        core_obj, runtime_c = folder / "core.o", folder / "runtime.c"
        runtime_obj, executable = folder / "runtime.o", folder / "core.elf"
        core_receipt = compile_program_llvm(ir, program=verified, output=core_obj, clang=str(compiler), kind="object",
                                            **({"command_log": commands} if commands is not None else {}))
        runtime_c.write_text(runtime, encoding="ascii")
        compile_command = [str(compiler), "--target=" + TARGET_AARCH64, "-x", "c", "-std=c11",
                           "-ffreestanding", "-nostdinc", "-fno-builtin", "-fno-stack-protector",
                           "-O2", "-Wall", "-Wextra", "-Werror", "-c", str(runtime_c), "-o", str(runtime_obj)]
        compiled = run(compile_command, timeout=35, stdout_limit=65536, stderr_limit=1048576)
        if compiled.returncode:
            _reject("finite target runtime compile failed: " + compiled.stderr[:2000])
        runtime_bytes = _read(runtime_obj, 1048576)
        inventory = inspect_object_symbols(runtime_bytes, "ELF64", 183)
        if inventory["defined"] != _RUNTIME_EXPORTS or inventory["undefined"] != frozenset(required):
            _reject("finite target runtime ABI inventory mismatch")
        # Invoke the existing LLVM linker directly; no Rust frontend is run.
        link_command = [str(lld), "-flavor", "gnu", "-m", "aarch64linux", "-static", "-z", "noexecstack",
                        "-e", "_start", str(core_obj), str(runtime_obj), "-o", str(executable)]
        linked = run(link_command, timeout=45, stdout_limit=65536, stderr_limit=1048576)
        if linked.returncode:
            _reject("direct standalone AArch64 link failed: " + linked.stderr[:2000])
        payload = _read(executable, 16777216)
        # This reusable parser checks exact static ELF shape and symbol inventory;
        # it neither emits old source code nor substitutes synthetic execution.
        shape = inspect_synthetic_aarch64_elf(payload, tuple(ir.exports) + ("calloc",))
        execute_command = [str(runner), str(executable)] if execution == "qemu" else [str(executable)]
        if execution == "native" and not os.access(executable, os.X_OK):
            _reject("native linked ELF is not directly executable")
        observed = run(execute_command, timeout=25, stdout_limit=65536, stderr_limit=65536)
        if (_read(executable, 16777216) != payload or
                sha256(_read(core_obj, 16777216)).hexdigest() != core_receipt["artifact_sha256"] or
                _read(runtime_obj, 1048576) != runtime_bytes or
                _runtime_source(verified.as_dict(), mode)[0] != runtime or
                emit_program_llvm(verified, target=TARGET_AARCH64) != ir or
                _implementation_hash() != own_before or
                any(digest_executable(path) != digest for path, digest in
                    tools)):
            _reject("target tool, source, core or executable changed during execution")
        if execution == "native":
            host_after = _execution_host(execution, qemu_aarch64)
            if host_after != host_before:
                _reject("native host identity changed during execution")
    record = {"schema": PROFILE_COMPOSITE if multi else PROFILE, "ok": True, "status": "finite_qemu_execution_observed", "mode": mode,
            "target": TARGET_AARCH64, "core_sha256": verified.sha256, "core_object": core_receipt,
            "llvm_ir": ir.text, "llvm_ir_sha256": ir.sha256, "harness_implementation_sha256": own_before,
            "reviewed_runtime_sha256": REVIEWED_MULTI_RUNTIME_SHA256 if multi else REVIEWED_RUNTIME_SHA256,
            "runtime_source": runtime, "runtime_source_sha256": sha256(runtime.encode()).hexdigest(),
            "runtime_object_sha256": sha256(runtime_bytes).hexdigest(),
            "linked_sha256": sha256(payload).hexdigest(), "linked_bytes": len(payload), "elf_inventory": shape,
            "runner": ({"path": str(runner), "sha256": runner_sha, "version": runner_version.stdout.splitlines()[0]}
                       if execution == "qemu" else {"kind": "direct-native-ELF", "external_runner": False}),
            "linker": {"path": str(lld), "sha256": linker_sha, "version": linker_version.stdout.splitlines()[0]},
            "execution": {"returncode": observed.returncode, "stdout": observed.stdout, "stderr": observed.stderr},
            "runtime_compile_flags": compile_command[1:-4], "link_flags": link_command[1:-4],
            "scope": ("fixed scalar ABI corpus; eight independent 4096-byte slots; Linux userspace QEMU"
                      if multi else "fixed scalar ABI corpus; 4096-byte arena with at most one live allocation; Linux userspace QEMU"),
            "claims": {"standalone_core_reverified": True, "qemu_userspace_executed": True,
                       "physical_target_executed": False, "general_allocator_qualified": False,
                       "source_ast_used": False, "rust_frontend_used": False, "rust_codegen_used": False,
                       "backend_refinement_proved": False, "whole_language_soundness_proved": False}}
    if execution == "native":
        record.update(schema=PROFILE_NATIVE_COMPOSITE if multi else PROFILE_NATIVE,
                      status="finite_native_host_execution_observed", execution_mode="native",
                      native_host_before=host_before, native_host_after=host_after,
                      command_range=[command_begin, len(commands)], commands=commands[command_begin:],
                      scope=("fixed scalar ABI corpus; reviewed finite arena; direct Linux AArch64 ELF execution; not physical-board qualification"),
                      identity_checks={"source_tools_program_and_elf_unchanged": True,
                                       "host_unchanged": True,
                                       "core_sha256": verified.sha256,
                                       "elf_sha256": sha256(payload).hexdigest()})
        record["claims"].update(qemu_userspace_executed=False, native_linux_aarch64_executed=True,
                                 physical_board_executed=False, hardware_attestation_proved=False)
    return record
