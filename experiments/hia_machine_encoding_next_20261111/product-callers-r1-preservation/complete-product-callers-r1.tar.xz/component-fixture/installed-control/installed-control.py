import importlib.abc,inspect,json,os,sys
from hashlib import sha256
from pathlib import Path
sys.path.insert(0,sys.argv[1])
class NoTools(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='tools' or fullname.startswith('tools.'):
            raise AssertionError('installed encoding imported authoring tools')
sys.meta_path.insert(0,NoTools())
from hepta import hia_machine_x64 as reference
from hepta.hia_machine_encoding_native import SOURCE,SELECTOR,installed_machine_encoding
from hepta.hia_program import verify_program
from hepta.hia_program_native import emit_program_machine
assert Path(sys.argv[1]) in SOURCE.parents
def forbidden(*args,**kwargs):
    raise AssertionError('retained instruction encoder entered installed execution')
for name,member in tuple(reference.Code.__dict__.items()):
    if inspect.isfunction(member) and name not in {'__new__','__init__','_reg','emit','label'}:
        setattr(reference.Code,name,forbidden)
os.environ[SELECTOR]=sys.argv[2]
code=reference.Code()
code.mov_imm('rax',42)
code.ret()
assert code.finalize()[0]==bytes.fromhex('48b82a00000000000000c3')
machine=emit_program_machine(verify_program(json.loads(Path(sys.argv[3]).read_bytes())))
assert machine.object_bytes[:4]==b'\x7fELF'
native=installed_machine_encoding(sys.argv[2])
assert native.calls['mov_imm']>0 and native.calls['rel32']>0
original=SOURCE.read_bytes()
SOURCE.write_bytes(original+b'\n')
try:installed_machine_encoding(sys.argv[2])
except ValueError:pass
else:raise AssertionError('warm image hid changed installed source')
SOURCE.write_bytes(original)
SOURCE.unlink()
try:installed_machine_encoding(sys.argv[2])
except FileNotFoundError:pass
else:raise AssertionError('missing installed source used checkout fallback')
SOURCE.write_bytes(original)
print(json.dumps({'status':'INSTALLED_NATIVE_MACHINE_ENCODING_PASS',
 'image_sha256':native.image_sha256,'source_sha256':sha256(original).hexdigest(),
 'object_sha256':sha256(machine.object_bytes).hexdigest(),
 'isolated_without_site':bool(sys.flags.isolated and sys.flags.no_site),
 'empty_PATH':os.environ['PATH']=='','authoring_forbidden':True,
 'retained_encoding_forbidden':True,'native_calls':dict(native.calls)}))
