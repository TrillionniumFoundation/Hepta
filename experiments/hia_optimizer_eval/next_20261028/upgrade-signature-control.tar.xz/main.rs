#![forbid(unsafe_code)]
mod api;
mod client;
use std::io::{self,BufRead};
fn main() { let entry:fn(u32,u32,u32)->u64 = client::entrypoint; for line in io::stdin().lock().lines() { let line=line.unwrap(); let v:Vec<u32>=line.split_whitespace().map(|s|s.parse().unwrap()).collect(); println!("{}",entry(v[0],v[1],v[2])); } }
