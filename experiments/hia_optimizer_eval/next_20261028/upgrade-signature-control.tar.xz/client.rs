use crate::api;
pub fn entrypoint(tag:u32,length:u32,reserved:u32)->u128 { let _ = reserved; (((tag & 255) as u128) << 32) | (api::wire_length(length) as u128) }
