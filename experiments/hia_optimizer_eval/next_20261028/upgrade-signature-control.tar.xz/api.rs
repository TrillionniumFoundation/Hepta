pub fn wire_length(length:u32)->u64 { length as u64 }
