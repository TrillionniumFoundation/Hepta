
/tmp/hepta-next-20261028-bench-final-01/cpp_pgo_lto.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000001a40 <deregister_tm_clones>:
    1a40:      	leaq	0x2cb9(%rip), %rdi      # 0x4700 <_GLOBAL_OFFSET_TABLE_>
    1a47:      	leaq	0x2cb2(%rip), %rax      # 0x4700 <_GLOBAL_OFFSET_TABLE_>
    1a4e:      	cmpq	%rdi, %rax
    1a51:      	je	0x1a68 <deregister_tm_clones+0x28>
    1a53:      	movq	0x1c6e(%rip), %rax      # 0x36c8 <memset+0x36c8>
    1a5a:      	testq	%rax, %rax
    1a5d:      	je	0x1a68 <deregister_tm_clones+0x28>
    1a5f:      	jmpq	*%rax
    1a61:      	nopl	(%rax)
    1a68:      	retq
    1a69:      	nopl	(%rax)

0000000000001a70 <register_tm_clones>:
    1a70:      	leaq	0x2c89(%rip), %rdi      # 0x4700 <_GLOBAL_OFFSET_TABLE_>
    1a77:      	leaq	0x2c82(%rip), %rsi      # 0x4700 <_GLOBAL_OFFSET_TABLE_>
    1a7e:      	subq	%rdi, %rsi
    1a81:      	movq	%rsi, %rax
    1a84:      	shrq	$0x3f, %rsi
    1a88:      	sarq	$0x3, %rax
    1a8c:      	addq	%rax, %rsi
    1a8f:      	sarq	%rsi
    1a92:      	je	0x1aa8 <register_tm_clones+0x38>
    1a94:      	movq	0x1c35(%rip), %rax      # 0x36d0 <memset+0x36d0>
    1a9b:      	testq	%rax, %rax
    1a9e:      	je	0x1aa8 <register_tm_clones+0x38>
    1aa0:      	jmpq	*%rax
    1aa2:      	nopw	(%rax,%rax)
    1aa8:      	retq
    1aa9:      	nopl	(%rax)

0000000000001ab0 <__do_global_dtors_aux>:
    1ab0:      	endbr64
    1ab4:      	cmpb	$0x0, 0x2c9d(%rip)      # 0x4758 <completed.0>
    1abb:      	jne	0x1ae8 <__do_global_dtors_aux+0x38>
    1abd:      	pushq	%rbp
    1abe:      	cmpq	$0x0, 0x1c12(%rip)      # 0x36d8 <memset+0x36d8>
    1ac6:      	movq	%rsp, %rbp
    1ac9:      	je	0x1ad7 <__do_global_dtors_aux+0x27>
    1acb:      	movq	0x2c0e(%rip), %rdi      # 0x46e0 <__dso_handle>
    1ad2:      	callq	0x2480 <__cxa_finalize@plt>
    1ad7:      	callq	0x1a40 <deregister_tm_clones>
    1adc:      	movb	$0x1, 0x2c75(%rip)      # 0x4758 <completed.0>
    1ae3:      	popq	%rbp
    1ae4:      	retq
    1ae5:      	nopl	(%rax)
    1ae8:      	retq
    1ae9:      	nopl	(%rax)

0000000000001af0 <frame_dummy>:
    1af0:      	endbr64
    1af4:      	jmp	0x1a70 <register_tm_clones>
    1af9:      	int3
    1afa:      	int3
    1afb:      	int3
    1afc:      	int3
    1afd:      	int3
    1afe:      	int3
    1aff:      	int3

0000000000001b00 <full_lifecycle>:
    1b00:      	pushq	%r15
    1b02:      	pushq	%r14
    1b04:      	pushq	%r13
    1b06:      	pushq	%r12
    1b08:      	pushq	%rbx
    1b09:      	testq	%rdi, %rdi
    1b0c:      	js	0x1dae <full_lifecycle+0x2ae>
    1b12:      	je	0x1cbf <full_lifecycle+0x1bf>
    1b18:      	movl	%esi, %r15d
    1b1b:      	movq	%rdi, %rbx
    1b1e:      	callq	0x24c0 <_Znwm@plt>
    1b23:      	movq	%rax, %r14
    1b26:      	movabsq	$0x7ffffffffffffff0, %r12 # imm = 0x7FFFFFFFFFFFFFF0
    1b30:      	xorl	%r13d, %r13d
    1b33:      	movq	%rax, %rdi
    1b36:      	xorl	%esi, %esi
    1b38:      	movq	%rbx, %rdx
    1b3b:      	callq	0x24f0 <memset@plt>
    1b40:      	cmpq	$0x3, %rbx
    1b44:      	jbe	0x1c1f <full_lifecycle+0x11f>
    1b4a:      	movd	%r15d, %xmm0
    1b4f:      	cmpq	$0x10, %rbx
    1b53:      	jb	0x1cec <full_lifecycle+0x1ec>
    1b59:      	movq	%rbx, %r13
    1b5c:      	andq	%r12, %r13
    1b5f:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1b64:      	movdqa	-0x132c(%rip), %xmm2    # 0x840 <memset+0x840>
    1b6c:      	movdqa	-0x1324(%rip), %xmm3    # 0x850 <memset+0x850>
    1b74:      	movdqa	-0x131c(%rip), %xmm4    # 0x860 <memset+0x860>
    1b7c:      	movdqa	-0x1314(%rip), %xmm5    # 0x870 <memset+0x870>
    1b84:      	xorl	%eax, %eax
    1b86:      	movdqa	-0x12ce(%rip), %xmm6    # 0x8c0 <memset+0x8c0>
    1b8e:      	movdqa	-0x12e6(%rip), %xmm7    # 0x8b0 <memset+0x8b0>
    1b96:      	nopw	%cs:(%rax,%rax)
    1ba0:      	movdqa	%xmm1, %xmm8
    1ba5:      	paddd	%xmm2, %xmm8
    1baa:      	movdqa	%xmm1, %xmm9
    1baf:      	paddd	%xmm3, %xmm9
    1bb4:      	movdqa	%xmm1, %xmm10
    1bb9:      	paddd	%xmm4, %xmm10
    1bbe:      	movdqa	%xmm1, %xmm11
    1bc3:      	paddd	%xmm5, %xmm11
    1bc8:      	pand	%xmm6, %xmm11
    1bcd:      	pand	%xmm6, %xmm10
    1bd2:      	packuswb	%xmm10, %xmm11
    1bd7:      	pand	%xmm6, %xmm9
    1bdc:      	pand	%xmm6, %xmm8
    1be1:      	packuswb	%xmm8, %xmm9
    1be6:      	packuswb	%xmm9, %xmm11
    1beb:      	movdqu	%xmm11, (%r14,%rax)
    1bf1:      	addq	$0x10, %rax
    1bf5:      	paddd	%xmm7, %xmm5
    1bf9:      	paddd	%xmm7, %xmm4
    1bfd:      	paddd	%xmm7, %xmm3
    1c01:      	paddd	%xmm7, %xmm2
    1c05:      	cmpq	%rax, %r13
    1c08:      	jne	0x1ba0 <full_lifecycle+0xa0>
    1c0a:      	cmpq	%r13, %rbx
    1c0d:      	je	0x1cc4 <full_lifecycle+0x1c4>
    1c13:      	movq	%r13, %rax
    1c16:      	testb	$0xc, %bl
    1c19:      	jne	0x1cee <full_lifecycle+0x1ee>
    1c1f:      	leal	(%r15,%r13), %eax
    1c23:      	movb	%al, (%r14,%r13)
    1c27:      	movq	%r13, %rax
    1c2a:      	orq	$0x1, %rax
    1c2e:      	cmpq	%rbx, %rax
    1c31:      	jne	0x1dba <full_lifecycle+0x2ba>
    1c37:      	movl	%ebx, %eax
    1c39:      	andl	$0x7, %eax
    1c3c:      	cmpq	$0x8, %rbx
    1c40:      	jb	0x1cce <full_lifecycle+0x1ce>
    1c46:      	addq	$0x8, %r12
    1c4a:      	andq	%rbx, %r12
    1c4d:      	xorl	%r15d, %r15d
    1c50:      	movq	%r14, %rcx
    1c53:      	nopw	%cs:(%rax,%rax)
    1c60:      	movzbl	(%rcx), %edx
    1c63:      	addq	%r15, %rdx
    1c66:      	movzbl	0x1(%rcx), %esi
    1c6a:      	movzbl	0x2(%rcx), %edi
    1c6e:      	addq	%rsi, %rdi
    1c71:      	addq	%rdx, %rdi
    1c74:      	movzbl	0x3(%rcx), %edx
    1c78:      	movzbl	0x4(%rcx), %esi
    1c7c:      	addq	%rdx, %rsi
    1c7f:      	movzbl	0x5(%rcx), %edx
    1c83:      	addq	%rsi, %rdx
    1c86:      	addq	%rdi, %rdx
    1c89:      	movzbl	0x6(%rcx), %esi
    1c8d:      	movzbl	0x7(%rcx), %r15d
    1c92:      	addq	%rsi, %r15
    1c95:      	addq	%rdx, %r15
    1c98:      	addq	$0x8, %rcx
    1c9c:      	addq	$-0x8, %r12
    1ca0:      	jne	0x1c60 <full_lifecycle+0x160>
    1ca2:      	testq	%rax, %rax
    1ca5:      	jne	0x1cd9 <full_lifecycle+0x1d9>
    1ca7:      	movq	%r14, %rdi
    1caa:      	movq	%rbx, %rsi
    1cad:      	callq	0x24d0 <_ZdlPvm@plt>
    1cb2:      	movq	%r15, %rax
    1cb5:      	popq	%rbx
    1cb6:      	popq	%r12
    1cb8:      	popq	%r13
    1cba:      	popq	%r14
    1cbc:      	popq	%r15
    1cbe:      	retq
    1cbf:      	xorl	%r15d, %r15d
    1cc2:      	jmp	0x1cb2 <full_lifecycle+0x1b2>
    1cc4:      	movl	%ebx, %eax
    1cc6:      	andl	$0x7, %eax
    1cc9:      	jmp	0x1c46 <full_lifecycle+0x146>
    1cce:      	xorl	%r15d, %r15d
    1cd1:      	movq	%r14, %rcx
    1cd4:      	testq	%rax, %rax
    1cd7:      	je	0x1ca7 <full_lifecycle+0x1a7>
    1cd9:      	xorl	%edx, %edx
    1cdb:      	movzbl	(%rcx,%rdx), %esi
    1cdf:      	addq	%rsi, %r15
    1ce2:      	incq	%rdx
    1ce5:      	cmpq	%rdx, %rax
    1ce8:      	jne	0x1cdb <full_lifecycle+0x1db>
    1cea:      	jmp	0x1ca7 <full_lifecycle+0x1a7>
    1cec:      	xorl	%eax, %eax
    1cee:      	leaq	0xc(%r12), %r13
    1cf3:      	andq	%rbx, %r13
    1cf6:      	movd	%eax, %xmm1
    1cfa:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1cff:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1d04:      	movdqa	%xmm0, %xmm2
    1d08:      	paddd	%xmm1, %xmm2
    1d0c:      	movdqa	-0x14a4(%rip), %xmm3    # 0x870 <memset+0x870>
    1d14:      	paddd	%xmm2, %xmm3
    1d18:      	pand	-0x1460(%rip), %xmm3    # 0x8c0 <memset+0x8c0>
    1d20:      	packuswb	%xmm3, %xmm3
    1d24:      	packuswb	%xmm3, %xmm3
    1d28:      	movd	%xmm3, (%r14,%rax)
    1d2e:      	movq	%rax, %rcx
    1d31:      	orq	$0x4, %rcx
    1d35:      	cmpq	%r13, %rcx
    1d38:      	je	0x1da0 <full_lifecycle+0x2a0>
    1d3a:      	paddd	-0x14e2(%rip), %xmm2    # 0x860 <memset+0x860>
    1d42:      	pand	-0x148a(%rip), %xmm2    # 0x8c0 <memset+0x8c0>
    1d4a:      	packuswb	%xmm2, %xmm2
    1d4e:      	packuswb	%xmm2, %xmm2
    1d52:      	movd	%xmm2, (%r14,%rcx)
    1d58:      	orq	$0x8, %rax
    1d5c:      	cmpq	%r13, %rax
    1d5f:      	je	0x1da0 <full_lifecycle+0x2a0>
    1d61:      	por	-0x1519(%rip), %xmm1    # 0x850 <memset+0x850>
    1d69:      	movdqa	-0x14b1(%rip), %xmm2    # 0x8c0 <memset+0x8c0>
    1d71:      	movdqa	-0x14f9(%rip), %xmm3    # 0x880 <memset+0x880>
    1d79:      	movdqa	%xmm0, %xmm4
    1d7d:      	paddd	%xmm1, %xmm4
    1d81:      	pand	%xmm2, %xmm4
    1d85:      	packuswb	%xmm4, %xmm4
    1d89:      	packuswb	%xmm4, %xmm4
    1d8d:      	movd	%xmm4, (%r14,%rax)
    1d93:      	addq	$0x4, %rax
    1d97:      	paddd	%xmm3, %xmm1
    1d9b:      	cmpq	%rax, %r13
    1d9e:      	jne	0x1d79 <full_lifecycle+0x279>
    1da0:      	cmpq	%r13, %rbx
    1da3:      	jne	0x1c1f <full_lifecycle+0x11f>
    1da9:      	jmp	0x1c37 <full_lifecycle+0x137>
    1dae:      	leaq	-0x14e5(%rip), %rdi     # 0x8d0 <memset+0x8d0>
    1db5:      	callq	0x24b0 <_ZSt20__throw_length_errorPKc@plt>
    1dba:      	leaq	-0x1(%rbx), %rax
    1dbe:      	incb	%r15b
    1dc1:      	movzbl	%r15b, %ecx
    1dc5:      	leal	(%rcx,%r13), %edx
    1dc9:      	movb	%dl, 0x1(%r14,%r13)
    1dce:      	incq	%r13
    1dd1:      	cmpq	%r13, %rax
    1dd4:      	jne	0x1dc5 <full_lifecycle+0x2c5>
    1dd6:      	jmp	0x1c37 <full_lifecycle+0x137>
    1ddb:      	cmpl	$0x2, %edx
    1dde:      	je	0x1de5 <full_lifecycle+0x2e5>
    1de0:      	cmpl	$0x1, %edx
    1de3:      	jne	0x1dfd <full_lifecycle+0x2fd>
    1de5:      	movq	%rax, %rdi
    1de8:      	callq	0x2490 <__cxa_begin_catch@plt>
    1ded:      	callq	0x24a0 <__cxa_end_catch@plt>
    1df2:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1df8:      	jmp	0x1cb2 <full_lifecycle+0x1b2>
    1dfd:      	movq	%rax, %rdi
    1e00:      	callq	0x24e0 <_Unwind_Resume@plt>
    1e05:      	int3
    1e06:      	int3
    1e07:      	int3
    1e08:      	int3
    1e09:      	int3
    1e0a:      	int3
    1e0b:      	int3
    1e0c:      	int3
    1e0d:      	int3
    1e0e:      	int3
    1e0f:      	int3

0000000000001e10 <packet_xor>:
    1e10:      	pushq	%rbp
    1e11:      	pushq	%r15
    1e13:      	pushq	%r14
    1e15:      	pushq	%r13
    1e17:      	pushq	%r12
    1e19:      	pushq	%rbx
    1e1a:      	pushq	%rax
    1e1b:      	testq	%rdi, %rdi
    1e1e:      	js	0x23a0 <packet_xor+0x590>
    1e24:      	je	0x219f <packet_xor+0x38f>
    1e2a:      	movl	%esi, %r15d
    1e2d:      	movq	%rdi, %rbx
    1e30:      	callq	0x24c0 <_Znwm@plt>
    1e35:      	movq	%rax, %r14
    1e38:      	movabsq	$0x7ffffffffffffff0, %r13 # imm = 0x7FFFFFFFFFFFFFF0
    1e42:      	xorl	%r12d, %r12d
    1e45:      	movq	%rax, %rdi
    1e48:      	xorl	%esi, %esi
    1e4a:      	movq	%rbx, %rdx
    1e4d:      	callq	0x24f0 <memset@plt>
    1e52:      	cmpq	$0x3, %rbx
    1e56:      	jbe	0x1fc7 <packet_xor+0x1b7>
    1e5c:      	movd	%r15d, %xmm0
    1e61:      	cmpq	$0x10, %rbx
    1e65:      	jb	0x21cc <packet_xor+0x3bc>
    1e6b:      	movq	%rbx, %r12
    1e6e:      	andq	%r13, %r12
    1e71:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1e76:      	movdqa	-0x163e(%rip), %xmm2    # 0x840 <memset+0x840>
    1e7e:      	movdqa	-0x1636(%rip), %xmm3    # 0x850 <memset+0x850>
    1e86:      	movdqa	-0x162e(%rip), %xmm4    # 0x860 <memset+0x860>
    1e8e:      	movdqa	-0x1626(%rip), %xmm5    # 0x870 <memset+0x870>
    1e96:      	xorl	%eax, %eax
    1e98:      	movdqa	-0x1600(%rip), %xmm6    # 0x8a0 <memset+0x8a0>
    1ea0:      	movdqa	-0x15e8(%rip), %xmm7    # 0x8c0 <memset+0x8c0>
    1ea8:      	movdqa	-0x1601(%rip), %xmm8    # 0x8b0 <memset+0x8b0>
    1eb1:      	nopw	%cs:(%rax,%rax)
    1ec0:      	movdqa	%xmm5, %xmm9
    1ec5:      	pmuludq	%xmm6, %xmm9
    1eca:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1ed0:      	pshufd	$0xf5, %xmm5, %xmm10    # xmm10 = xmm5[1,1,3,3]
    1ed6:      	pmuludq	%xmm6, %xmm10
    1edb:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1ee1:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    1ee6:      	movdqa	%xmm4, %xmm10
    1eeb:      	pmuludq	%xmm6, %xmm10
    1ef0:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1ef6:      	pshufd	$0xf5, %xmm4, %xmm11    # xmm11 = xmm4[1,1,3,3]
    1efc:      	pmuludq	%xmm6, %xmm11
    1f01:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1f07:      	punpckldq	%xmm11, %xmm10  # xmm10 = xmm10[0],xmm11[0],xmm10[1],xmm11[1]
    1f0c:      	movdqa	%xmm3, %xmm11
    1f11:      	pmuludq	%xmm6, %xmm11
    1f16:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1f1c:      	pshufd	$0xf5, %xmm3, %xmm12    # xmm12 = xmm3[1,1,3,3]
    1f22:      	pmuludq	%xmm6, %xmm12
    1f27:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1f2d:      	punpckldq	%xmm12, %xmm11  # xmm11 = xmm11[0],xmm12[0],xmm11[1],xmm12[1]
    1f32:      	movdqa	%xmm2, %xmm12
    1f37:      	pmuludq	%xmm6, %xmm12
    1f3c:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1f42:      	pshufd	$0xf5, %xmm2, %xmm13    # xmm13 = xmm2[1,1,3,3]
    1f48:      	pmuludq	%xmm6, %xmm13
    1f4d:      	pshufd	$0xe8, %xmm13, %xmm13   # xmm13 = xmm13[0,2,2,3]
    1f53:      	punpckldq	%xmm13, %xmm12  # xmm12 = xmm12[0],xmm13[0],xmm12[1],xmm13[1]
    1f58:      	paddd	%xmm1, %xmm12
    1f5d:      	paddd	%xmm1, %xmm11
    1f62:      	paddd	%xmm1, %xmm10
    1f67:      	paddd	%xmm1, %xmm9
    1f6c:      	pand	%xmm7, %xmm9
    1f71:      	pand	%xmm7, %xmm10
    1f76:      	packuswb	%xmm10, %xmm9
    1f7b:      	pand	%xmm7, %xmm11
    1f80:      	pand	%xmm7, %xmm12
    1f85:      	packuswb	%xmm12, %xmm11
    1f8a:      	packuswb	%xmm11, %xmm9
    1f8f:      	movdqu	%xmm9, (%r14,%rax)
    1f95:      	addq	$0x10, %rax
    1f99:      	paddd	%xmm8, %xmm5
    1f9e:      	paddd	%xmm8, %xmm4
    1fa3:      	paddd	%xmm8, %xmm3
    1fa8:      	paddd	%xmm8, %xmm2
    1fad:      	cmpq	%rax, %r12
    1fb0:      	jne	0x1ec0 <packet_xor+0xb0>
    1fb6:      	cmpq	%r12, %rbx
    1fb9:      	je	0x1fe6 <packet_xor+0x1d6>
    1fbb:      	movq	%r12, %rax
    1fbe:      	testb	$0xc, %bl
    1fc1:      	jne	0x21ce <packet_xor+0x3be>
    1fc7:      	leal	(%r12,%r12,2), %eax
    1fcb:      	leal	(%r12,%rax,4), %eax
    1fcf:      	addl	%r15d, %eax
    1fd2:      	movb	%al, (%r14,%r12)
    1fd6:      	movq	%r12, %rax
    1fd9:      	orq	$0x1, %rax
    1fdd:      	cmpq	%rbx, %rax
    1fe0:      	jne	0x23ac <packet_xor+0x59c>
    1fe6:      	movq	%rbx, %rdi
    1fe9:      	callq	0x24c0 <_Znwm@plt>
    1fee:      	movq	%rax, %r12
    1ff1:      	xorl	%ebp, %ebp
    1ff3:      	movq	%rax, %rdi
    1ff6:      	xorl	%esi, %esi
    1ff8:      	movq	%rbx, %rdx
    1ffb:      	callq	0x24f0 <memset@plt>
    2000:      	xorl	$0x5a, %r15d
    2004:      	cmpq	$0x3, %rbx
    2008:      	jbe	0x20ea <packet_xor+0x2da>
    200e:      	movd	%r15d, %xmm0
    2013:      	cmpq	$0x10, %rbx
    2017:      	jb	0x22c1 <packet_xor+0x4b1>
    201d:      	movq	%rbx, %rbp
    2020:      	andq	%r13, %rbp
    2023:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    2028:      	movdqa	-0x17f0(%rip), %xmm2    # 0x840 <memset+0x840>
    2030:      	movdqa	-0x17e8(%rip), %xmm3    # 0x850 <memset+0x850>
    2038:      	movdqa	-0x17e0(%rip), %xmm4    # 0x860 <memset+0x860>
    2040:      	movdqa	-0x17d8(%rip), %xmm5    # 0x870 <memset+0x870>
    2048:      	xorl	%eax, %eax
    204a:      	movdqa	-0x1792(%rip), %xmm6    # 0x8c0 <memset+0x8c0>
    2052:      	movdqa	-0x17aa(%rip), %xmm7    # 0x8b0 <memset+0x8b0>
    205a:      	nopw	(%rax,%rax)
    2060:      	movdqu	(%r14,%rax), %xmm8
    2066:      	movdqa	%xmm1, %xmm9
    206b:      	paddd	%xmm2, %xmm9
    2070:      	movdqa	%xmm1, %xmm10
    2075:      	paddd	%xmm3, %xmm10
    207a:      	movdqa	%xmm1, %xmm11
    207f:      	paddd	%xmm4, %xmm11
    2084:      	movdqa	%xmm1, %xmm12
    2089:      	paddd	%xmm5, %xmm12
    208e:      	pand	%xmm6, %xmm12
    2093:      	pand	%xmm6, %xmm11
    2098:      	packuswb	%xmm11, %xmm12
    209d:      	pand	%xmm6, %xmm10
    20a2:      	pand	%xmm6, %xmm9
    20a7:      	packuswb	%xmm9, %xmm10
    20ac:      	packuswb	%xmm10, %xmm12
    20b1:      	pxor	%xmm8, %xmm12
    20b6:      	movdqu	%xmm12, (%r12,%rax)
    20bc:      	addq	$0x10, %rax
    20c0:      	paddd	%xmm7, %xmm5
    20c4:      	paddd	%xmm7, %xmm4
    20c8:      	paddd	%xmm7, %xmm3
    20cc:      	paddd	%xmm7, %xmm2
    20d0:      	cmpq	%rax, %rbp
    20d3:      	jne	0x2060 <packet_xor+0x250>
    20d5:      	cmpq	%rbp, %rbx
    20d8:      	je	0x21a4 <packet_xor+0x394>
    20de:      	movq	%rbp, %rax
    20e1:      	testb	$0xc, %bl
    20e4:      	jne	0x22c3 <packet_xor+0x4b3>
    20ea:      	leal	(%r15,%rbp), %eax
    20ee:      	xorb	(%r14,%rbp), %al
    20f2:      	movb	%al, (%r12,%rbp)
    20f6:      	movq	%rbp, %rax
    20f9:      	orq	$0x1, %rax
    20fd:      	cmpq	%rbx, %rax
    2100:      	jne	0x23ce <packet_xor+0x5be>
    2106:      	leaq	-0x1(%rbx), %rcx
    210a:      	movl	%ebx, %eax
    210c:      	andl	$0x7, %eax
    210f:      	cmpq	$0x7, %rcx
    2113:      	jb	0x21ae <packet_xor+0x39e>
    2119:      	addq	$0x8, %r13
    211d:      	andq	%rbx, %r13
    2120:      	xorl	%r15d, %r15d
    2123:      	movq	%r12, %rcx
    2126:      	nopw	%cs:(%rax,%rax)
    2130:      	movzbl	(%rcx), %edx
    2133:      	addq	%r15, %rdx
    2136:      	movzbl	0x1(%rcx), %esi
    213a:      	movzbl	0x2(%rcx), %edi
    213e:      	addq	%rsi, %rdi
    2141:      	addq	%rdx, %rdi
    2144:      	movzbl	0x3(%rcx), %edx
    2148:      	movzbl	0x4(%rcx), %esi
    214c:      	addq	%rdx, %rsi
    214f:      	movzbl	0x5(%rcx), %edx
    2153:      	addq	%rsi, %rdx
    2156:      	addq	%rdi, %rdx
    2159:      	movzbl	0x6(%rcx), %esi
    215d:      	movzbl	0x7(%rcx), %r15d
    2162:      	addq	%rsi, %r15
    2165:      	addq	%rdx, %r15
    2168:      	addq	$0x8, %rcx
    216c:      	addq	$-0x8, %r13
    2170:      	jne	0x2130 <packet_xor+0x320>
    2172:      	testq	%rax, %rax
    2175:      	jne	0x21b9 <packet_xor+0x3a9>
    2177:      	movq	%r12, %rdi
    217a:      	movq	%rbx, %rsi
    217d:      	callq	0x24d0 <_ZdlPvm@plt>
    2182:      	movq	%r14, %rdi
    2185:      	movq	%rbx, %rsi
    2188:      	callq	0x24d0 <_ZdlPvm@plt>
    218d:      	movq	%r15, %rax
    2190:      	addq	$0x8, %rsp
    2194:      	popq	%rbx
    2195:      	popq	%r12
    2197:      	popq	%r13
    2199:      	popq	%r14
    219b:      	popq	%r15
    219d:      	popq	%rbp
    219e:      	retq
    219f:      	xorl	%r15d, %r15d
    21a2:      	jmp	0x218d <packet_xor+0x37d>
    21a4:      	movl	%ebx, %eax
    21a6:      	andl	$0x7, %eax
    21a9:      	jmp	0x2119 <packet_xor+0x309>
    21ae:      	xorl	%r15d, %r15d
    21b1:      	movq	%r12, %rcx
    21b4:      	testq	%rax, %rax
    21b7:      	je	0x2177 <packet_xor+0x367>
    21b9:      	xorl	%edx, %edx
    21bb:      	movzbl	(%rcx,%rdx), %esi
    21bf:      	addq	%rsi, %r15
    21c2:      	incq	%rdx
    21c5:      	cmpq	%rdx, %rax
    21c8:      	jne	0x21bb <packet_xor+0x3ab>
    21ca:      	jmp	0x2177 <packet_xor+0x367>
    21cc:      	xorl	%eax, %eax
    21ce:      	leaq	0xc(%r13), %r12
    21d2:      	andq	%rbx, %r12
    21d5:      	movd	%eax, %xmm1
    21d9:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    21de:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    21e3:      	movdqa	-0x194b(%rip), %xmm2    # 0x8a0 <memset+0x8a0>
    21eb:      	pmuludq	%xmm1, %xmm2
    21ef:      	pshufd	$0xa0, %xmm2, %xmm2     # xmm2 = xmm2[0,0,2,2]
    21f4:      	paddd	%xmm0, %xmm2
    21f8:      	movdqa	-0x1970(%rip), %xmm3    # 0x890 <memset+0x890>
    2200:      	paddd	%xmm2, %xmm3
    2204:      	pand	-0x194c(%rip), %xmm3    # 0x8c0 <memset+0x8c0>
    220c:      	packuswb	%xmm3, %xmm3
    2210:      	packuswb	%xmm3, %xmm3
    2214:      	movd	%xmm3, (%r14,%rax)
    221a:      	movq	%rax, %rcx
    221d:      	orq	$0x4, %rcx
    2221:      	cmpq	%r12, %rcx
    2224:      	je	0x22b3 <packet_xor+0x4a3>
    222a:      	paddd	-0x1a02(%rip), %xmm2    # 0x830 <memset+0x830>
    2232:      	pand	-0x197a(%rip), %xmm2    # 0x8c0 <memset+0x8c0>
    223a:      	packuswb	%xmm2, %xmm2
    223e:      	packuswb	%xmm2, %xmm2
    2242:      	movd	%xmm2, (%r14,%rcx)
    2248:      	orq	$0x8, %rax
    224c:      	cmpq	%r12, %rax
    224f:      	je	0x22b3 <packet_xor+0x4a3>
    2251:      	por	-0x1a09(%rip), %xmm1    # 0x850 <memset+0x850>
    2259:      	movdqa	-0x19c1(%rip), %xmm2    # 0x8a0 <memset+0x8a0>
    2261:      	movdqa	-0x19a9(%rip), %xmm3    # 0x8c0 <memset+0x8c0>
    2269:      	movdqa	-0x19f1(%rip), %xmm4    # 0x880 <memset+0x880>
    2271:      	movdqa	%xmm1, %xmm5
    2275:      	pmuludq	%xmm2, %xmm5
    2279:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    227e:      	pshufd	$0xf5, %xmm1, %xmm6     # xmm6 = xmm1[1,1,3,3]
    2283:      	pmuludq	%xmm2, %xmm6
    2287:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    228c:      	punpckldq	%xmm6, %xmm5    # xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1]
    2290:      	paddd	%xmm0, %xmm5
    2294:      	pand	%xmm3, %xmm5
    2298:      	packuswb	%xmm5, %xmm5
    229c:      	packuswb	%xmm5, %xmm5
    22a0:      	movd	%xmm5, (%r14,%rax)
    22a6:      	addq	$0x4, %rax
    22aa:      	paddd	%xmm4, %xmm1
    22ae:      	cmpq	%rax, %r12
    22b1:      	jne	0x2271 <packet_xor+0x461>
    22b3:      	cmpq	%r12, %rbx
    22b6:      	jne	0x1fc7 <packet_xor+0x1b7>
    22bc:      	jmp	0x1fe6 <packet_xor+0x1d6>
    22c1:      	xorl	%eax, %eax
    22c3:      	leaq	0xc(%r13), %rbp
    22c7:      	andq	%rbx, %rbp
    22ca:      	movd	%eax, %xmm1
    22ce:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    22d3:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    22d8:      	movdqa	%xmm0, %xmm2
    22dc:      	paddd	%xmm1, %xmm2
    22e0:      	movdqa	-0x1a78(%rip), %xmm3    # 0x870 <memset+0x870>
    22e8:      	paddd	%xmm2, %xmm3
    22ec:      	pand	-0x1a34(%rip), %xmm3    # 0x8c0 <memset+0x8c0>
    22f4:      	movd	(%r14,%rax), %xmm4
    22fa:      	packuswb	%xmm3, %xmm3
    22fe:      	packuswb	%xmm3, %xmm3
    2302:      	pxor	%xmm4, %xmm3
    2306:      	movd	%xmm3, (%r12,%rax)
    230c:      	movq	%rax, %rcx
    230f:      	orq	$0x4, %rcx
    2313:      	cmpq	%rbp, %rcx
    2316:      	je	0x2392 <packet_xor+0x582>
    2318:      	movd	(%r14,%rcx), %xmm3
    231e:      	paddd	-0x1ac6(%rip), %xmm2    # 0x860 <memset+0x860>
    2326:      	pand	-0x1a6e(%rip), %xmm2    # 0x8c0 <memset+0x8c0>
    232e:      	packuswb	%xmm2, %xmm2
    2332:      	packuswb	%xmm2, %xmm2
    2336:      	pxor	%xmm3, %xmm2
    233a:      	movd	%xmm2, (%r12,%rcx)
    2340:      	orq	$0x8, %rax
    2344:      	cmpq	%rbp, %rax
    2347:      	je	0x2392 <packet_xor+0x582>
    2349:      	por	-0x1b01(%rip), %xmm1    # 0x850 <memset+0x850>
    2351:      	movdqa	-0x1a99(%rip), %xmm2    # 0x8c0 <memset+0x8c0>
    2359:      	movdqa	-0x1ae1(%rip), %xmm3    # 0x880 <memset+0x880>
    2361:      	movd	(%r14,%rax), %xmm4
    2367:      	movdqa	%xmm0, %xmm5
    236b:      	paddd	%xmm1, %xmm5
    236f:      	pand	%xmm2, %xmm5
    2373:      	packuswb	%xmm5, %xmm5
    2377:      	packuswb	%xmm5, %xmm5
    237b:      	pxor	%xmm4, %xmm5
    237f:      	movd	%xmm5, (%r12,%rax)
    2385:      	addq	$0x4, %rax
    2389:      	paddd	%xmm3, %xmm1
    238d:      	cmpq	%rax, %rbp
    2390:      	jne	0x2361 <packet_xor+0x551>
    2392:      	cmpq	%rbp, %rbx
    2395:      	jne	0x20ea <packet_xor+0x2da>
    239b:      	jmp	0x2106 <packet_xor+0x2f6>
    23a0:      	leaq	-0x1ad7(%rip), %rdi     # 0x8d0 <memset+0x8d0>
    23a7:      	callq	0x24b0 <_ZSt20__throw_length_errorPKc@plt>
    23ac:      	leal	(%r12,%r12,2), %ecx
    23b0:      	leal	(%r12,%rcx,4), %ecx
    23b4:      	addl	%r15d, %ecx
    23b7:      	addb	$0xd, %cl
    23ba:      	movb	%cl, (%r14,%rax)
    23be:      	incq	%rax
    23c1:      	addb	$0xd, %cl
    23c4:      	cmpq	%rax, %rbx
    23c7:      	jne	0x23ba <packet_xor+0x5aa>
    23c9:      	jmp	0x1fe6 <packet_xor+0x1d6>
    23ce:      	leaq	-0x1(%rbx), %rax
    23d2:      	incb	%r15b
    23d5:      	movzbl	%r15b, %ecx
    23d9:      	leal	(%rcx,%rbp), %edx
    23dc:      	xorb	0x1(%r14,%rbp), %dl
    23e1:      	movb	%dl, 0x1(%r12,%rbp)
    23e6:      	incq	%rbp
    23e9:      	cmpq	%rbp, %rax
    23ec:      	jne	0x23d9 <packet_xor+0x5c9>
    23ee:      	jmp	0x2106 <packet_xor+0x2f6>
    23f3:      	movq	%rdx, %r12
    23f6:      	movq	%rax, %r15
    23f9:      	movq	%r14, %rdi
    23fc:      	movq	%rbx, %rsi
    23ff:      	callq	0x24d0 <_ZdlPvm@plt>
    2404:      	jmp	0x240c <packet_xor+0x5fc>
    2406:      	movq	%rdx, %r12
    2409:      	movq	%rax, %r15
    240c:      	cmpl	$0x2, %r12d
    2410:      	je	0x2418 <packet_xor+0x608>
    2412:      	cmpl	$0x1, %r12d
    2416:      	jne	0x2430 <packet_xor+0x620>
    2418:      	movq	%r15, %rdi
    241b:      	callq	0x2490 <__cxa_begin_catch@plt>
    2420:      	callq	0x24a0 <__cxa_end_catch@plt>
    2425:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    242b:      	jmp	0x218d <packet_xor+0x37d>
    2430:      	movq	%r15, %rdi
    2433:      	callq	0x24e0 <_Unwind_Resume@plt>

Disassembly of section .init:

0000000000002438 <_init>:
    2438:      	endbr64
    243c:      	subq	$0x8, %rsp
    2440:      	movq	0x1279(%rip), %rax      # 0x36c0 <memset+0x36c0>
    2447:      	testq	%rax, %rax
    244a:      	je	0x244e <_init+0x16>
    244c:      	callq	*%rax
    244e:      	addq	$0x8, %rsp
    2452:      	retq

Disassembly of section .fini:

0000000000002454 <_fini>:
    2454:      	endbr64
    2458:      	subq	$0x8, %rsp
    245c:      	addq	$0x8, %rsp
    2460:      	retq

Disassembly of section .plt:

0000000000002470 <.plt>:
    2470:      	pushq	0x2292(%rip)            # 0x4708 <_GLOBAL_OFFSET_TABLE_+0x8>
    2476:      	jmpq	*0x2294(%rip)           # 0x4710 <_GLOBAL_OFFSET_TABLE_+0x10>
    247c:      	nopl	(%rax)

0000000000002480 <__cxa_finalize@plt>:
    2480:      	jmpq	*0x2292(%rip)           # 0x4718 <_GLOBAL_OFFSET_TABLE_+0x18>
    2486:      	pushq	$0x0
    248b:      	jmp	0x2470 <.plt>

0000000000002490 <__cxa_begin_catch@plt>:
    2490:      	jmpq	*0x228a(%rip)           # 0x4720 <_GLOBAL_OFFSET_TABLE_+0x20>
    2496:      	pushq	$0x1
    249b:      	jmp	0x2470 <.plt>

00000000000024a0 <__cxa_end_catch@plt>:
    24a0:      	jmpq	*0x2282(%rip)           # 0x4728 <_GLOBAL_OFFSET_TABLE_+0x28>
    24a6:      	pushq	$0x2
    24ab:      	jmp	0x2470 <.plt>

00000000000024b0 <_ZSt20__throw_length_errorPKc@plt>:
    24b0:      	jmpq	*0x227a(%rip)           # 0x4730 <_GLOBAL_OFFSET_TABLE_+0x30>
    24b6:      	pushq	$0x3
    24bb:      	jmp	0x2470 <.plt>

00000000000024c0 <_Znwm@plt>:
    24c0:      	jmpq	*0x2272(%rip)           # 0x4738 <_GLOBAL_OFFSET_TABLE_+0x38>
    24c6:      	pushq	$0x4
    24cb:      	jmp	0x2470 <.plt>

00000000000024d0 <_ZdlPvm@plt>:
    24d0:      	jmpq	*0x226a(%rip)           # 0x4740 <_GLOBAL_OFFSET_TABLE_+0x40>
    24d6:      	pushq	$0x5
    24db:      	jmp	0x2470 <.plt>

00000000000024e0 <_Unwind_Resume@plt>:
    24e0:      	jmpq	*0x2262(%rip)           # 0x4748 <_GLOBAL_OFFSET_TABLE_+0x48>
    24e6:      	pushq	$0x6
    24eb:      	jmp	0x2470 <.plt>

00000000000024f0 <memset@plt>:
    24f0:      	jmpq	*0x225a(%rip)           # 0x4750 <_GLOBAL_OFFSET_TABLE_+0x50>
    24f6:      	pushq	$0x7
    24fb:      	jmp	0x2470 <.plt>
