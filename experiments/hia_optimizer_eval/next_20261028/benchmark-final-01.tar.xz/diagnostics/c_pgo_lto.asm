
/tmp/hepta-next-20261028-bench-final-01/c_pgo_lto.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000001680 <deregister_tm_clones>:
    1680:      	leaq	0x2b11(%rip), %rdi      # 0x4198 <_GLOBAL_OFFSET_TABLE_>
    1687:      	leaq	0x2b0a(%rip), %rax      # 0x4198 <_GLOBAL_OFFSET_TABLE_>
    168e:      	cmpq	%rdi, %rax
    1691:      	je	0x16a8 <deregister_tm_clones+0x28>
    1693:      	movq	0x1ade(%rip), %rax      # 0x3178 <free+0x3178>
    169a:      	testq	%rax, %rax
    169d:      	je	0x16a8 <deregister_tm_clones+0x28>
    169f:      	jmpq	*%rax
    16a1:      	nopl	(%rax)
    16a8:      	retq
    16a9:      	nopl	(%rax)

00000000000016b0 <register_tm_clones>:
    16b0:      	leaq	0x2ae1(%rip), %rdi      # 0x4198 <_GLOBAL_OFFSET_TABLE_>
    16b7:      	leaq	0x2ada(%rip), %rsi      # 0x4198 <_GLOBAL_OFFSET_TABLE_>
    16be:      	subq	%rdi, %rsi
    16c1:      	movq	%rsi, %rax
    16c4:      	shrq	$0x3f, %rsi
    16c8:      	sarq	$0x3, %rax
    16cc:      	addq	%rax, %rsi
    16cf:      	sarq	%rsi
    16d2:      	je	0x16e8 <register_tm_clones+0x38>
    16d4:      	movq	0x1aa5(%rip), %rax      # 0x3180 <free+0x3180>
    16db:      	testq	%rax, %rax
    16de:      	je	0x16e8 <register_tm_clones+0x38>
    16e0:      	jmpq	*%rax
    16e2:      	nopw	(%rax,%rax)
    16e8:      	retq
    16e9:      	nopl	(%rax)

00000000000016f0 <__do_global_dtors_aux>:
    16f0:      	endbr64
    16f4:      	cmpb	$0x0, 0x2acd(%rip)      # 0x41c8 <completed.0>
    16fb:      	jne	0x1728 <__do_global_dtors_aux+0x38>
    16fd:      	pushq	%rbp
    16fe:      	cmpq	$0x0, 0x1a82(%rip)      # 0x3188 <free+0x3188>
    1706:      	movq	%rsp, %rbp
    1709:      	je	0x1717 <__do_global_dtors_aux+0x27>
    170b:      	movq	0x2a7e(%rip), %rdi      # 0x4190 <__dso_handle>
    1712:      	callq	0x1fb0 <__cxa_finalize@plt>
    1717:      	callq	0x1680 <deregister_tm_clones>
    171c:      	movb	$0x1, 0x2aa5(%rip)      # 0x41c8 <completed.0>
    1723:      	popq	%rbp
    1724:      	retq
    1725:      	nopl	(%rax)
    1728:      	retq
    1729:      	nopl	(%rax)

0000000000001730 <frame_dummy>:
    1730:      	endbr64
    1734:      	jmp	0x16b0 <register_tm_clones>
    1739:      	int3
    173a:      	int3
    173b:      	int3
    173c:      	int3
    173d:      	int3
    173e:      	int3
    173f:      	int3

0000000000001740 <full_lifecycle>:
    1740:      	pushq	%r14
    1742:      	pushq	%rbx
    1743:      	pushq	%rax
    1744:      	testq	%rdi, %rdi
    1747:      	je	0x1989 <full_lifecycle+0x249>
    174d:      	movl	%esi, %r14d
    1750:      	movq	%rdi, %rbx
    1753:      	movl	$0x1, %esi
    1758:      	callq	0x1fc0 <calloc@plt>
    175d:      	testq	%rax, %rax
    1760:      	je	0x1991 <full_lifecycle+0x251>
    1766:      	cmpq	$0x4, %rbx
    176a:      	jb	0x1909 <full_lifecycle+0x1c9>
    1770:      	movd	%r14d, %xmm0
    1775:      	cmpq	$0x10, %rbx
    1779:      	jb	0x1933 <full_lifecycle+0x1f3>
    177f:      	movq	%rbx, %rcx
    1782:      	andq	$-0x10, %rcx
    1786:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    178b:      	movdqa	-0x1243(%rip), %xmm2    # 0x550 <free+0x550>
    1793:      	movdqa	-0x123b(%rip), %xmm3    # 0x560 <free+0x560>
    179b:      	movdqa	-0x1233(%rip), %xmm4    # 0x570 <free+0x570>
    17a3:      	movdqa	-0x122b(%rip), %xmm5    # 0x580 <free+0x580>
    17ab:      	xorl	%edx, %edx
    17ad:      	movdqa	-0x11e5(%rip), %xmm6    # 0x5d0 <free+0x5d0>
    17b5:      	movdqa	-0x11fd(%rip), %xmm7    # 0x5c0 <free+0x5c0>
    17bd:      	nopl	(%rax)
    17c0:      	movdqa	%xmm1, %xmm8
    17c5:      	paddd	%xmm2, %xmm8
    17ca:      	movdqa	%xmm1, %xmm9
    17cf:      	paddd	%xmm3, %xmm9
    17d4:      	movdqa	%xmm1, %xmm10
    17d9:      	paddd	%xmm4, %xmm10
    17de:      	movdqa	%xmm1, %xmm11
    17e3:      	paddd	%xmm5, %xmm11
    17e8:      	pand	%xmm6, %xmm11
    17ed:      	pand	%xmm6, %xmm10
    17f2:      	packuswb	%xmm10, %xmm11
    17f7:      	pand	%xmm6, %xmm9
    17fc:      	pand	%xmm6, %xmm8
    1801:      	packuswb	%xmm8, %xmm9
    1806:      	packuswb	%xmm9, %xmm11
    180b:      	movdqu	%xmm11, (%rax,%rdx)
    1811:      	addq	$0x10, %rdx
    1815:      	paddd	%xmm7, %xmm5
    1819:      	paddd	%xmm7, %xmm4
    181d:      	paddd	%xmm7, %xmm3
    1821:      	paddd	%xmm7, %xmm2
    1825:      	cmpq	%rdx, %rcx
    1828:      	jne	0x17c0 <full_lifecycle+0x80>
    182a:      	cmpq	%rcx, %rbx
    182d:      	je	0x1902 <full_lifecycle+0x1c2>
    1833:      	testb	$0xc, %bl
    1836:      	jne	0x1935 <full_lifecycle+0x1f5>
    183c:      	leal	(%r14,%rcx), %edx
    1840:      	movb	%dl, (%rax,%rcx)
    1843:      	movq	%rcx, %rdx
    1846:      	orq	$0x1, %rdx
    184a:      	cmpq	%rbx, %rdx
    184d:      	je	0x187f <full_lifecycle+0x13f>
    184f:      	leal	(%r14,%rdx), %esi
    1853:      	movb	%sil, (%rax,%rdx)
    1857:      	movq	%rcx, %rdx
    185a:      	orq	$0x2, %rdx
    185e:      	cmpq	%rbx, %rdx
    1861:      	je	0x187f <full_lifecycle+0x13f>
    1863:      	leaq	-0x2(%rbx), %rdx
    1867:      	addb	$0x2, %r14b
    186b:      	movzbl	%r14b, %esi
    186f:      	leal	(%rsi,%rcx), %edi
    1872:      	movb	%dil, 0x2(%rax,%rcx)
    1877:      	incq	%rcx
    187a:      	cmpq	%rcx, %rdx
    187d:      	jne	0x186f <full_lifecycle+0x12f>
    187f:      	movl	%ebx, %ecx
    1881:      	andl	$0x7, %ecx
    1884:      	cmpq	$0x8, %rbx
    1888:      	jb	0x1910 <full_lifecycle+0x1d0>
    188e:      	andq	$-0x8, %rbx
    1892:      	xorl	%edx, %edx
    1894:      	xorl	%r14d, %r14d
    1897:      	nopw	(%rax,%rax)
    18a0:      	movzbl	(%rax,%rdx), %esi
    18a4:      	addq	%r14, %rsi
    18a7:      	movzbl	0x1(%rax,%rdx), %edi
    18ac:      	movzbl	0x2(%rax,%rdx), %r8d
    18b2:      	addq	%rdi, %r8
    18b5:      	addq	%rsi, %r8
    18b8:      	movzbl	0x3(%rax,%rdx), %esi
    18bd:      	movzbl	0x4(%rax,%rdx), %edi
    18c2:      	addq	%rsi, %rdi
    18c5:      	movzbl	0x5(%rax,%rdx), %esi
    18ca:      	addq	%rdi, %rsi
    18cd:      	addq	%r8, %rsi
    18d0:      	movzbl	0x6(%rax,%rdx), %edi
    18d5:      	movzbl	0x7(%rax,%rdx), %r14d
    18db:      	addq	%rdi, %r14
    18de:      	addq	%rsi, %r14
    18e1:      	addq	$0x8, %rdx
    18e5:      	cmpq	%rdx, %rbx
    18e8:      	jne	0x18a0 <full_lifecycle+0x160>
    18ea:      	testq	%rcx, %rcx
    18ed:      	jne	0x191a <full_lifecycle+0x1da>
    18ef:      	movq	%rax, %rdi
    18f2:      	callq	0x1fd0 <free@plt>
    18f7:      	movq	%r14, %rax
    18fa:      	addq	$0x8, %rsp
    18fe:      	popq	%rbx
    18ff:      	popq	%r14
    1901:      	retq
    1902:      	movl	%ebx, %ecx
    1904:      	andl	$0x7, %ecx
    1907:      	jmp	0x188e <full_lifecycle+0x14e>
    1909:      	xorl	%ecx, %ecx
    190b:      	jmp	0x183c <full_lifecycle+0xfc>
    1910:      	xorl	%edx, %edx
    1912:      	xorl	%r14d, %r14d
    1915:      	testq	%rcx, %rcx
    1918:      	je	0x18ef <full_lifecycle+0x1af>
    191a:      	movq	%rax, %rsi
    191d:      	addq	%rdx, %rsi
    1920:      	xorl	%edx, %edx
    1922:      	movzbl	(%rsi,%rdx), %edi
    1926:      	addq	%rdi, %r14
    1929:      	incq	%rdx
    192c:      	cmpq	%rdx, %rcx
    192f:      	jne	0x1922 <full_lifecycle+0x1e2>
    1931:      	jmp	0x18ef <full_lifecycle+0x1af>
    1933:      	xorl	%ecx, %ecx
    1935:      	movq	%rcx, %rdx
    1938:      	movq	%rbx, %rcx
    193b:      	movd	%edx, %xmm1
    193f:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1944:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1949:      	movdqa	%xmm0, %xmm2
    194d:      	paddd	%xmm1, %xmm2
    1951:      	paddd	-0x13d9(%rip), %xmm2    # 0x580 <free+0x580>
    1959:      	andq	$-0x4, %rcx
    195d:      	pand	-0x1395(%rip), %xmm2    # 0x5d0 <free+0x5d0>
    1965:      	packuswb	%xmm2, %xmm2
    1969:      	packuswb	%xmm2, %xmm2
    196d:      	movd	%xmm2, (%rax,%rdx)
    1972:      	orq	$0x4, %rdx
    1976:      	cmpq	%rcx, %rdx
    1979:      	jne	0x199c <full_lifecycle+0x25c>
    197b:      	cmpq	%rcx, %rbx
    197e:      	jne	0x183c <full_lifecycle+0xfc>
    1984:      	jmp	0x187f <full_lifecycle+0x13f>
    1989:      	xorl	%r14d, %r14d
    198c:      	jmp	0x18f7 <full_lifecycle+0x1b7>
    1991:      	movl	$0x3e9, %r14d           # imm = 0x3E9
    1997:      	jmp	0x18f7 <full_lifecycle+0x1b7>
    199c:      	por	-0x1434(%rip), %xmm1    # 0x570 <free+0x570>
    19a4:      	movdqa	-0x13dc(%rip), %xmm2    # 0x5d0 <free+0x5d0>
    19ac:      	movdqa	-0x1424(%rip), %xmm3    # 0x590 <free+0x590>
    19b4:      	movdqa	%xmm0, %xmm4
    19b8:      	paddd	%xmm1, %xmm4
    19bc:      	pand	%xmm2, %xmm4
    19c0:      	packuswb	%xmm4, %xmm4
    19c4:      	packuswb	%xmm4, %xmm4
    19c8:      	movd	%xmm4, (%rax,%rdx)
    19cd:      	addq	$0x4, %rdx
    19d1:      	paddd	%xmm3, %xmm1
    19d5:      	cmpq	%rdx, %rcx
    19d8:      	jne	0x19b4 <full_lifecycle+0x274>
    19da:      	jmp	0x197b <full_lifecycle+0x23b>
    19dc:      	int3
    19dd:      	int3
    19de:      	int3
    19df:      	int3

00000000000019e0 <packet_xor>:
    19e0:      	pushq	%r15
    19e2:      	pushq	%r14
    19e4:      	pushq	%rbx
    19e5:      	testq	%rdi, %rdi
    19e8:      	je	0x1e9e <packet_xor+0x4be>
    19ee:      	movl	%esi, %r15d
    19f1:      	movq	%rdi, %r14
    19f4:      	movl	$0x1, %esi
    19f9:      	callq	0x1fc0 <calloc@plt>
    19fe:      	testq	%rax, %rax
    1a01:      	je	0x1ea6 <packet_xor+0x4c6>
    1a07:      	movq	%rax, %rbx
    1a0a:      	cmpq	$0x3, %r14
    1a0e:      	jbe	0x1da3 <packet_xor+0x3c3>
    1a14:      	movd	%r15d, %xmm0
    1a19:      	cmpq	$0x10, %r14
    1a1d:      	jb	0x1dd4 <packet_xor+0x3f4>
    1a23:      	movq	%r14, %rax
    1a26:      	andq	$-0x10, %rax
    1a2a:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1a2f:      	movdqa	-0x14e7(%rip), %xmm2    # 0x550 <free+0x550>
    1a37:      	movdqa	-0x14df(%rip), %xmm3    # 0x560 <free+0x560>
    1a3f:      	movdqa	-0x14d7(%rip), %xmm4    # 0x570 <free+0x570>
    1a47:      	movdqa	-0x14cf(%rip), %xmm5    # 0x580 <free+0x580>
    1a4f:      	xorl	%ecx, %ecx
    1a51:      	movdqa	-0x14a9(%rip), %xmm6    # 0x5b0 <free+0x5b0>
    1a59:      	movdqa	-0x1491(%rip), %xmm7    # 0x5d0 <free+0x5d0>
    1a61:      	movdqa	-0x14aa(%rip), %xmm8    # 0x5c0 <free+0x5c0>
    1a6a:      	nopw	(%rax,%rax)
    1a70:      	movdqa	%xmm5, %xmm9
    1a75:      	pmuludq	%xmm6, %xmm9
    1a7a:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1a80:      	pshufd	$0xf5, %xmm5, %xmm10    # xmm10 = xmm5[1,1,3,3]
    1a86:      	pmuludq	%xmm6, %xmm10
    1a8b:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1a91:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    1a96:      	movdqa	%xmm4, %xmm10
    1a9b:      	pmuludq	%xmm6, %xmm10
    1aa0:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1aa6:      	pshufd	$0xf5, %xmm4, %xmm11    # xmm11 = xmm4[1,1,3,3]
    1aac:      	pmuludq	%xmm6, %xmm11
    1ab1:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1ab7:      	punpckldq	%xmm11, %xmm10  # xmm10 = xmm10[0],xmm11[0],xmm10[1],xmm11[1]
    1abc:      	movdqa	%xmm3, %xmm11
    1ac1:      	pmuludq	%xmm6, %xmm11
    1ac6:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1acc:      	pshufd	$0xf5, %xmm3, %xmm12    # xmm12 = xmm3[1,1,3,3]
    1ad2:      	pmuludq	%xmm6, %xmm12
    1ad7:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1add:      	punpckldq	%xmm12, %xmm11  # xmm11 = xmm11[0],xmm12[0],xmm11[1],xmm12[1]
    1ae2:      	movdqa	%xmm2, %xmm12
    1ae7:      	pmuludq	%xmm6, %xmm12
    1aec:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1af2:      	pshufd	$0xf5, %xmm2, %xmm13    # xmm13 = xmm2[1,1,3,3]
    1af8:      	pmuludq	%xmm6, %xmm13
    1afd:      	pshufd	$0xe8, %xmm13, %xmm13   # xmm13 = xmm13[0,2,2,3]
    1b03:      	punpckldq	%xmm13, %xmm12  # xmm12 = xmm12[0],xmm13[0],xmm12[1],xmm13[1]
    1b08:      	paddd	%xmm1, %xmm12
    1b0d:      	paddd	%xmm1, %xmm11
    1b12:      	paddd	%xmm1, %xmm10
    1b17:      	paddd	%xmm1, %xmm9
    1b1c:      	pand	%xmm7, %xmm9
    1b21:      	pand	%xmm7, %xmm10
    1b26:      	packuswb	%xmm10, %xmm9
    1b2b:      	pand	%xmm7, %xmm11
    1b30:      	pand	%xmm7, %xmm12
    1b35:      	packuswb	%xmm12, %xmm11
    1b3a:      	packuswb	%xmm11, %xmm9
    1b3f:      	movdqu	%xmm9, (%rbx,%rcx)
    1b45:      	addq	$0x10, %rcx
    1b49:      	paddd	%xmm8, %xmm5
    1b4e:      	paddd	%xmm8, %xmm4
    1b53:      	paddd	%xmm8, %xmm3
    1b58:      	paddd	%xmm8, %xmm2
    1b5d:      	cmpq	%rcx, %rax
    1b60:      	jne	0x1a70 <packet_xor+0x90>
    1b66:      	cmpq	%rax, %r14
    1b69:      	je	0x1bbd <packet_xor+0x1dd>
    1b6b:      	testb	$0xc, %r14b
    1b6f:      	jne	0x1dd6 <packet_xor+0x3f6>
    1b75:      	leal	(%rax,%rax,2), %ecx
    1b78:      	leal	(%rax,%rcx,4), %ecx
    1b7b:      	addl	%r15d, %ecx
    1b7e:      	movb	%cl, (%rbx,%rax)
    1b81:      	movq	%rax, %rcx
    1b84:      	orq	$0x1, %rcx
    1b88:      	cmpq	%r14, %rcx
    1b8b:      	je	0x1bbd <packet_xor+0x1dd>
    1b8d:      	leal	(%rcx,%rcx,2), %edx
    1b90:      	leal	(%rcx,%rdx,4), %edx
    1b93:      	addl	%r15d, %edx
    1b96:      	movb	%dl, (%rbx,%rcx)
    1b99:      	movq	%rax, %rcx
    1b9c:      	orq	$0x2, %rcx
    1ba0:      	cmpq	%r14, %rcx
    1ba3:      	je	0x1bbd <packet_xor+0x1dd>
    1ba5:      	leal	(%rax,%rax,2), %edx
    1ba8:      	leal	(%rax,%rdx,4), %eax
    1bab:      	addl	%r15d, %eax
    1bae:      	addb	$0x1a, %al
    1bb0:      	movb	%al, (%rbx,%rcx)
    1bb3:      	incq	%rcx
    1bb6:      	addb	$0xd, %al
    1bb8:      	cmpq	%rcx, %r14
    1bbb:      	jne	0x1bb0 <packet_xor+0x1d0>
    1bbd:      	movl	$0x1, %esi
    1bc2:      	movq	%r14, %rdi
    1bc5:      	callq	0x1fc0 <calloc@plt>
    1bca:      	testq	%rax, %rax
    1bcd:      	je	0x1eb1 <packet_xor+0x4d1>
    1bd3:      	xorl	$0x5a, %r15d
    1bd7:      	cmpq	$0x3, %r14
    1bdb:      	jbe	0x1daa <packet_xor+0x3ca>
    1be1:      	movd	%r15d, %xmm0
    1be6:      	cmpq	$0x10, %r14
    1bea:      	jb	0x1e3b <packet_xor+0x45b>
    1bf0:      	movq	%r14, %rcx
    1bf3:      	andq	$-0x10, %rcx
    1bf7:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1bfc:      	movdqa	-0x16b4(%rip), %xmm2    # 0x550 <free+0x550>
    1c04:      	movdqa	-0x16ac(%rip), %xmm3    # 0x560 <free+0x560>
    1c0c:      	movdqa	-0x16a4(%rip), %xmm4    # 0x570 <free+0x570>
    1c14:      	movdqa	-0x169c(%rip), %xmm5    # 0x580 <free+0x580>
    1c1c:      	xorl	%edx, %edx
    1c1e:      	movdqa	-0x1656(%rip), %xmm6    # 0x5d0 <free+0x5d0>
    1c26:      	movdqa	-0x166e(%rip), %xmm7    # 0x5c0 <free+0x5c0>
    1c2e:      	nop
    1c30:      	movdqu	(%rbx,%rdx), %xmm8
    1c36:      	movdqa	%xmm1, %xmm9
    1c3b:      	paddd	%xmm2, %xmm9
    1c40:      	movdqa	%xmm1, %xmm10
    1c45:      	paddd	%xmm3, %xmm10
    1c4a:      	movdqa	%xmm1, %xmm11
    1c4f:      	paddd	%xmm4, %xmm11
    1c54:      	movdqa	%xmm1, %xmm12
    1c59:      	paddd	%xmm5, %xmm12
    1c5e:      	pand	%xmm6, %xmm12
    1c63:      	pand	%xmm6, %xmm11
    1c68:      	packuswb	%xmm11, %xmm12
    1c6d:      	pand	%xmm6, %xmm10
    1c72:      	pand	%xmm6, %xmm9
    1c77:      	packuswb	%xmm9, %xmm10
    1c7c:      	packuswb	%xmm10, %xmm12
    1c81:      	pxor	%xmm8, %xmm12
    1c86:      	movdqu	%xmm12, (%rax,%rdx)
    1c8c:      	addq	$0x10, %rdx
    1c90:      	paddd	%xmm7, %xmm5
    1c94:      	paddd	%xmm7, %xmm4
    1c98:      	paddd	%xmm7, %xmm3
    1c9c:      	paddd	%xmm7, %xmm2
    1ca0:      	cmpq	%rdx, %rcx
    1ca3:      	jne	0x1c30 <packet_xor+0x250>
    1ca5:      	cmpq	%rcx, %r14
    1ca8:      	je	0x1d98 <packet_xor+0x3b8>
    1cae:      	testb	$0xc, %r14b
    1cb2:      	jne	0x1e3d <packet_xor+0x45d>
    1cb8:      	leal	(%r15,%rcx), %edx
    1cbc:      	xorb	(%rbx,%rcx), %dl
    1cbf:      	movb	%dl, (%rax,%rcx)
    1cc2:      	movq	%rcx, %rdx
    1cc5:      	orq	$0x1, %rdx
    1cc9:      	cmpq	%r14, %rdx
    1ccc:      	je	0x1d07 <packet_xor+0x327>
    1cce:      	leal	(%r15,%rdx), %esi
    1cd2:      	xorb	(%rbx,%rdx), %sil
    1cd6:      	movb	%sil, (%rax,%rdx)
    1cda:      	movq	%rcx, %rdx
    1cdd:      	orq	$0x2, %rdx
    1ce1:      	cmpq	%r14, %rdx
    1ce4:      	je	0x1d07 <packet_xor+0x327>
    1ce6:      	leaq	-0x2(%r14), %rdx
    1cea:      	addb	$0x2, %r15b
    1cee:      	movzbl	%r15b, %esi
    1cf2:      	leal	(%rsi,%rcx), %edi
    1cf5:      	xorb	0x2(%rbx,%rcx), %dil
    1cfa:      	movb	%dil, 0x2(%rax,%rcx)
    1cff:      	incq	%rcx
    1d02:      	cmpq	%rcx, %rdx
    1d05:      	jne	0x1cf2 <packet_xor+0x312>
    1d07:      	leaq	-0x1(%r14), %rdx
    1d0b:      	movl	%r14d, %ecx
    1d0e:      	andl	$0x7, %ecx
    1d11:      	cmpq	$0x7, %rdx
    1d15:      	jb	0x1db1 <packet_xor+0x3d1>
    1d1b:      	andq	$-0x8, %r14
    1d1f:      	xorl	%edx, %edx
    1d21:      	xorl	%r15d, %r15d
    1d24:      	nopw	%cs:(%rax,%rax)
    1d30:      	movzbl	(%rax,%rdx), %esi
    1d34:      	addq	%r15, %rsi
    1d37:      	movzbl	0x1(%rax,%rdx), %edi
    1d3c:      	movzbl	0x2(%rax,%rdx), %r8d
    1d42:      	addq	%rdi, %r8
    1d45:      	addq	%rsi, %r8
    1d48:      	movzbl	0x3(%rax,%rdx), %esi
    1d4d:      	movzbl	0x4(%rax,%rdx), %edi
    1d52:      	addq	%rsi, %rdi
    1d55:      	movzbl	0x5(%rax,%rdx), %esi
    1d5a:      	addq	%rdi, %rsi
    1d5d:      	addq	%r8, %rsi
    1d60:      	movzbl	0x6(%rax,%rdx), %edi
    1d65:      	movzbl	0x7(%rax,%rdx), %r15d
    1d6b:      	addq	%rdi, %r15
    1d6e:      	addq	%rsi, %r15
    1d71:      	addq	$0x8, %rdx
    1d75:      	cmpq	%rdx, %r14
    1d78:      	jne	0x1d30 <packet_xor+0x350>
    1d7a:      	testq	%rcx, %rcx
    1d7d:      	jne	0x1dbb <packet_xor+0x3db>
    1d7f:      	movq	%rax, %rdi
    1d82:      	callq	0x1fd0 <free@plt>
    1d87:      	movq	%rbx, %rdi
    1d8a:      	callq	0x1fd0 <free@plt>
    1d8f:      	movq	%r15, %rax
    1d92:      	popq	%rbx
    1d93:      	popq	%r14
    1d95:      	popq	%r15
    1d97:      	retq
    1d98:      	movl	%r14d, %ecx
    1d9b:      	andl	$0x7, %ecx
    1d9e:      	jmp	0x1d1b <packet_xor+0x33b>
    1da3:      	xorl	%eax, %eax
    1da5:      	jmp	0x1b75 <packet_xor+0x195>
    1daa:      	xorl	%ecx, %ecx
    1dac:      	jmp	0x1cb8 <packet_xor+0x2d8>
    1db1:      	xorl	%edx, %edx
    1db3:      	xorl	%r15d, %r15d
    1db6:      	testq	%rcx, %rcx
    1db9:      	je	0x1d7f <packet_xor+0x39f>
    1dbb:      	movq	%rax, %rsi
    1dbe:      	addq	%rdx, %rsi
    1dc1:      	xorl	%edx, %edx
    1dc3:      	movzbl	(%rsi,%rdx), %edi
    1dc7:      	addq	%rdi, %r15
    1dca:      	incq	%rdx
    1dcd:      	cmpq	%rdx, %rcx
    1dd0:      	jne	0x1dc3 <packet_xor+0x3e3>
    1dd2:      	jmp	0x1d7f <packet_xor+0x39f>
    1dd4:      	xorl	%eax, %eax
    1dd6:      	movq	%rax, %rcx
    1dd9:      	movq	%r14, %rax
    1ddc:      	movd	%ecx, %xmm1
    1de0:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1de5:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1dea:      	movdqa	-0x1842(%rip), %xmm2    # 0x5b0 <free+0x5b0>
    1df2:      	pmuludq	%xmm1, %xmm2
    1df6:      	pshufd	$0xa0, %xmm2, %xmm2     # xmm2 = xmm2[0,0,2,2]
    1dfb:      	paddd	%xmm0, %xmm2
    1dff:      	paddd	-0x1867(%rip), %xmm2    # 0x5a0 <free+0x5a0>
    1e07:      	andq	$-0x4, %rax
    1e0b:      	pand	-0x1843(%rip), %xmm2    # 0x5d0 <free+0x5d0>
    1e13:      	packuswb	%xmm2, %xmm2
    1e17:      	packuswb	%xmm2, %xmm2
    1e1b:      	movd	%xmm2, (%rbx,%rcx)
    1e20:      	orq	$0x4, %rcx
    1e24:      	cmpq	%rax, %rcx
    1e27:      	jne	0x1ebc <packet_xor+0x4dc>
    1e2d:      	cmpq	%rax, %r14
    1e30:      	jne	0x1b75 <packet_xor+0x195>
    1e36:      	jmp	0x1bbd <packet_xor+0x1dd>
    1e3b:      	xorl	%ecx, %ecx
    1e3d:      	movq	%rcx, %rdx
    1e40:      	movq	%r14, %rcx
    1e43:      	andq	$-0x4, %rcx
    1e47:      	movd	%edx, %xmm1
    1e4b:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1e50:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1e55:      	movd	(%rbx,%rdx), %xmm2
    1e5a:      	movdqa	%xmm0, %xmm3
    1e5e:      	paddd	%xmm1, %xmm3
    1e62:      	paddd	-0x18ea(%rip), %xmm3    # 0x580 <free+0x580>
    1e6a:      	pand	-0x18a2(%rip), %xmm3    # 0x5d0 <free+0x5d0>
    1e72:      	packuswb	%xmm3, %xmm3
    1e76:      	packuswb	%xmm3, %xmm3
    1e7a:      	pxor	%xmm2, %xmm3
    1e7e:      	movd	%xmm3, (%rax,%rdx)
    1e83:      	orq	$0x4, %rdx
    1e87:      	cmpq	%rcx, %rdx
    1e8a:      	jne	0x1f22 <packet_xor+0x542>
    1e90:      	cmpq	%rcx, %r14
    1e93:      	jne	0x1cb8 <packet_xor+0x2d8>
    1e99:      	jmp	0x1d07 <packet_xor+0x327>
    1e9e:      	xorl	%r15d, %r15d
    1ea1:      	jmp	0x1d8f <packet_xor+0x3af>
    1ea6:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1eac:      	jmp	0x1d8f <packet_xor+0x3af>
    1eb1:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1eb7:      	jmp	0x1d87 <packet_xor+0x3a7>
    1ebc:      	por	-0x1954(%rip), %xmm1    # 0x570 <free+0x570>
    1ec4:      	movdqa	-0x191c(%rip), %xmm2    # 0x5b0 <free+0x5b0>
    1ecc:      	movdqa	-0x1904(%rip), %xmm3    # 0x5d0 <free+0x5d0>
    1ed4:      	movdqa	-0x194c(%rip), %xmm4    # 0x590 <free+0x590>
    1edc:      	movdqa	%xmm1, %xmm5
    1ee0:      	pmuludq	%xmm2, %xmm5
    1ee4:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    1ee9:      	pshufd	$0xf5, %xmm1, %xmm6     # xmm6 = xmm1[1,1,3,3]
    1eee:      	pmuludq	%xmm2, %xmm6
    1ef2:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    1ef7:      	punpckldq	%xmm6, %xmm5    # xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1]
    1efb:      	paddd	%xmm0, %xmm5
    1eff:      	pand	%xmm3, %xmm5
    1f03:      	packuswb	%xmm5, %xmm5
    1f07:      	packuswb	%xmm5, %xmm5
    1f0b:      	movd	%xmm5, (%rbx,%rcx)
    1f10:      	addq	$0x4, %rcx
    1f14:      	paddd	%xmm4, %xmm1
    1f18:      	cmpq	%rcx, %rax
    1f1b:      	jne	0x1edc <packet_xor+0x4fc>
    1f1d:      	jmp	0x1e2d <packet_xor+0x44d>
    1f22:      	por	-0x19ba(%rip), %xmm1    # 0x570 <free+0x570>
    1f2a:      	movdqa	-0x1962(%rip), %xmm2    # 0x5d0 <free+0x5d0>
    1f32:      	movdqa	-0x19aa(%rip), %xmm3    # 0x590 <free+0x590>
    1f3a:      	movd	(%rbx,%rdx), %xmm4
    1f3f:      	movdqa	%xmm0, %xmm5
    1f43:      	paddd	%xmm1, %xmm5
    1f47:      	pand	%xmm2, %xmm5
    1f4b:      	packuswb	%xmm5, %xmm5
    1f4f:      	packuswb	%xmm5, %xmm5
    1f53:      	pxor	%xmm4, %xmm5
    1f57:      	movd	%xmm5, (%rax,%rdx)
    1f5c:      	addq	$0x4, %rdx
    1f60:      	paddd	%xmm3, %xmm1
    1f64:      	cmpq	%rdx, %rcx
    1f67:      	jne	0x1f3a <packet_xor+0x55a>
    1f69:      	jmp	0x1e90 <packet_xor+0x4b0>

Disassembly of section .init:

0000000000001f70 <_init>:
    1f70:      	endbr64
    1f74:      	subq	$0x8, %rsp
    1f78:      	movq	0x11f1(%rip), %rax      # 0x3170 <free+0x3170>
    1f7f:      	testq	%rax, %rax
    1f82:      	je	0x1f86 <_init+0x16>
    1f84:      	callq	*%rax
    1f86:      	addq	$0x8, %rsp
    1f8a:      	retq

Disassembly of section .fini:

0000000000001f8c <_fini>:
    1f8c:      	endbr64
    1f90:      	subq	$0x8, %rsp
    1f94:      	addq	$0x8, %rsp
    1f98:      	retq

Disassembly of section .plt:

0000000000001fa0 <.plt>:
    1fa0:      	pushq	0x21fa(%rip)            # 0x41a0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1fa6:      	jmpq	*0x21fc(%rip)           # 0x41a8 <_GLOBAL_OFFSET_TABLE_+0x10>
    1fac:      	nopl	(%rax)

0000000000001fb0 <__cxa_finalize@plt>:
    1fb0:      	jmpq	*0x21fa(%rip)           # 0x41b0 <_GLOBAL_OFFSET_TABLE_+0x18>
    1fb6:      	pushq	$0x0
    1fbb:      	jmp	0x1fa0 <.plt>

0000000000001fc0 <calloc@plt>:
    1fc0:      	jmpq	*0x21f2(%rip)           # 0x41b8 <_GLOBAL_OFFSET_TABLE_+0x20>
    1fc6:      	pushq	$0x1
    1fcb:      	jmp	0x1fa0 <.plt>

0000000000001fd0 <free@plt>:
    1fd0:      	jmpq	*0x21ea(%rip)           # 0x41c0 <_GLOBAL_OFFSET_TABLE_+0x28>
    1fd6:      	pushq	$0x2
    1fdb:      	jmp	0x1fa0 <.plt>
