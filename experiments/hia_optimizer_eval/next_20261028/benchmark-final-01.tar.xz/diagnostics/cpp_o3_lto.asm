
/tmp/hepta-next-20261028-bench-final-01/cpp_o3_lto.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000001a20 <deregister_tm_clones>:
    1a20:      	leaq	0x2ad9(%rip), %rdi      # 0x4500 <_GLOBAL_OFFSET_TABLE_>
    1a27:      	leaq	0x2ad2(%rip), %rax      # 0x4500 <_GLOBAL_OFFSET_TABLE_>
    1a2e:      	cmpq	%rdi, %rax
    1a31:      	je	0x1a48 <deregister_tm_clones+0x28>
    1a33:      	movq	0x1a8e(%rip), %rax      # 0x34c8 <memset+0x34c8>
    1a3a:      	testq	%rax, %rax
    1a3d:      	je	0x1a48 <deregister_tm_clones+0x28>
    1a3f:      	jmpq	*%rax
    1a41:      	nopl	(%rax)
    1a48:      	retq
    1a49:      	nopl	(%rax)

0000000000001a50 <register_tm_clones>:
    1a50:      	leaq	0x2aa9(%rip), %rdi      # 0x4500 <_GLOBAL_OFFSET_TABLE_>
    1a57:      	leaq	0x2aa2(%rip), %rsi      # 0x4500 <_GLOBAL_OFFSET_TABLE_>
    1a5e:      	subq	%rdi, %rsi
    1a61:      	movq	%rsi, %rax
    1a64:      	shrq	$0x3f, %rsi
    1a68:      	sarq	$0x3, %rax
    1a6c:      	addq	%rax, %rsi
    1a6f:      	sarq	%rsi
    1a72:      	je	0x1a88 <register_tm_clones+0x38>
    1a74:      	movq	0x1a55(%rip), %rax      # 0x34d0 <memset+0x34d0>
    1a7b:      	testq	%rax, %rax
    1a7e:      	je	0x1a88 <register_tm_clones+0x38>
    1a80:      	jmpq	*%rax
    1a82:      	nopw	(%rax,%rax)
    1a88:      	retq
    1a89:      	nopl	(%rax)

0000000000001a90 <__do_global_dtors_aux>:
    1a90:      	endbr64
    1a94:      	cmpb	$0x0, 0x2abd(%rip)      # 0x4558 <completed.0>
    1a9b:      	jne	0x1ac8 <__do_global_dtors_aux+0x38>
    1a9d:      	pushq	%rbp
    1a9e:      	cmpq	$0x0, 0x1a32(%rip)      # 0x34d8 <memset+0x34d8>
    1aa6:      	movq	%rsp, %rbp
    1aa9:      	je	0x1ab7 <__do_global_dtors_aux+0x27>
    1aab:      	movq	0x2a2e(%rip), %rdi      # 0x44e0 <__dso_handle>
    1ab2:      	callq	0x2280 <__cxa_finalize@plt>
    1ab7:      	callq	0x1a20 <deregister_tm_clones>
    1abc:      	movb	$0x1, 0x2a95(%rip)      # 0x4558 <completed.0>
    1ac3:      	popq	%rbp
    1ac4:      	retq
    1ac5:      	nopl	(%rax)
    1ac8:      	retq
    1ac9:      	nopl	(%rax)

0000000000001ad0 <frame_dummy>:
    1ad0:      	endbr64
    1ad4:      	jmp	0x1a50 <register_tm_clones>
    1ad9:      	int3
    1ada:      	int3
    1adb:      	int3
    1adc:      	int3
    1add:      	int3
    1ade:      	int3
    1adf:      	int3

0000000000001ae0 <full_lifecycle>:
    1ae0:      	pushq	%rbp
    1ae1:      	pushq	%r15
    1ae3:      	pushq	%r14
    1ae5:      	pushq	%r12
    1ae7:      	pushq	%rbx
    1ae8:      	testq	%rdi, %rdi
    1aeb:      	js	0x1d06 <full_lifecycle+0x226>
    1af1:      	je	0x1b36 <full_lifecycle+0x56>
    1af3:      	movl	%esi, %ebp
    1af5:      	movq	%rdi, %rbx
    1af8:      	callq	0x22c0 <_Znwm@plt>
    1afd:      	movq	%rax, %r14
    1b00:      	movabsq	$0x7ffffffffffffff0, %r12 # imm = 0x7FFFFFFFFFFFFFF0
    1b0a:      	xorl	%r15d, %r15d
    1b0d:      	movq	%rax, %rdi
    1b10:      	xorl	%esi, %esi
    1b12:      	movq	%rbx, %rdx
    1b15:      	callq	0x22f0 <memset@plt>
    1b1a:      	cmpq	$0x3, %rbx
    1b1e:      	jbe	0x1c5c <full_lifecycle+0x17c>
    1b24:      	movd	%ebp, %xmm0
    1b28:      	cmpq	$0x10, %rbx
    1b2c:      	jae	0x1b3e <full_lifecycle+0x5e>
    1b2e:      	xorl	%r15d, %r15d
    1b31:      	jmp	0x1bfe <full_lifecycle+0x11e>
    1b36:      	xorl	%r15d, %r15d
    1b39:      	jmp	0x1cfa <full_lifecycle+0x21a>
    1b3e:      	movq	%rbx, %r15
    1b41:      	andq	%r12, %r15
    1b44:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1b49:      	movdqa	-0x1321(%rip), %xmm2    # 0x830 <memset+0x830>
    1b51:      	movdqa	-0x1319(%rip), %xmm3    # 0x840 <memset+0x840>
    1b59:      	movdqa	-0x1311(%rip), %xmm4    # 0x850 <memset+0x850>
    1b61:      	movdqa	-0x1309(%rip), %xmm5    # 0x860 <memset+0x860>
    1b69:      	xorl	%eax, %eax
    1b6b:      	movdqa	-0x12d3(%rip), %xmm6    # 0x8a0 <memset+0x8a0>
    1b73:      	movdqa	-0x12eb(%rip), %xmm7    # 0x890 <memset+0x890>
    1b7b:      	nopl	(%rax,%rax)
    1b80:      	movdqa	%xmm1, %xmm8
    1b85:      	paddd	%xmm2, %xmm8
    1b8a:      	movdqa	%xmm1, %xmm9
    1b8f:      	paddd	%xmm3, %xmm9
    1b94:      	movdqa	%xmm1, %xmm10
    1b99:      	paddd	%xmm4, %xmm10
    1b9e:      	movdqa	%xmm1, %xmm11
    1ba3:      	paddd	%xmm5, %xmm11
    1ba8:      	pand	%xmm6, %xmm11
    1bad:      	pand	%xmm6, %xmm10
    1bb2:      	packuswb	%xmm10, %xmm11
    1bb7:      	pand	%xmm6, %xmm9
    1bbc:      	pand	%xmm6, %xmm8
    1bc1:      	packuswb	%xmm8, %xmm9
    1bc6:      	packuswb	%xmm9, %xmm11
    1bcb:      	movdqu	%xmm11, (%r14,%rax)
    1bd1:      	addq	$0x10, %rax
    1bd5:      	paddd	%xmm7, %xmm5
    1bd9:      	paddd	%xmm7, %xmm4
    1bdd:      	paddd	%xmm7, %xmm3
    1be1:      	paddd	%xmm7, %xmm2
    1be5:      	cmpq	%rax, %r15
    1be8:      	jne	0x1b80 <full_lifecycle+0xa0>
    1bea:      	cmpq	%r15, %rbx
    1bed:      	jne	0x1bf9 <full_lifecycle+0x119>
    1bef:      	movl	%ebx, %eax
    1bf1:      	andl	$0x7, %eax
    1bf4:      	jmp	0x1c83 <full_lifecycle+0x1a3>
    1bf9:      	testb	$0xc, %bl
    1bfc:      	je	0x1c5c <full_lifecycle+0x17c>
    1bfe:      	movq	%r15, %rax
    1c01:      	leaq	0xc(%r12), %r15
    1c06:      	movd	%eax, %xmm1
    1c0a:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1c0f:      	por	-0x13b7(%rip), %xmm1    # 0x860 <memset+0x860>
    1c17:      	andq	%rbx, %r15
    1c1a:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1c1f:      	movdqa	-0x1387(%rip), %xmm2    # 0x8a0 <memset+0x8a0>
    1c27:      	movdqa	-0x13bf(%rip), %xmm3    # 0x870 <memset+0x870>
    1c2f:      	nop
    1c30:      	movdqa	%xmm0, %xmm4
    1c34:      	paddd	%xmm1, %xmm4
    1c38:      	pand	%xmm2, %xmm4
    1c3c:      	packuswb	%xmm4, %xmm4
    1c40:      	packuswb	%xmm4, %xmm4
    1c44:      	movd	%xmm4, (%r14,%rax)
    1c4a:      	addq	$0x4, %rax
    1c4e:      	paddd	%xmm3, %xmm1
    1c52:      	cmpq	%rax, %r15
    1c55:      	jne	0x1c30 <full_lifecycle+0x150>
    1c57:      	cmpq	%r15, %rbx
    1c5a:      	je	0x1c70 <full_lifecycle+0x190>
    1c5c:      	movl	%ebp, %eax
    1c5e:      	nop
    1c60:      	leal	(%rax,%r15), %ecx
    1c64:      	movb	%cl, (%r14,%r15)
    1c68:      	incq	%r15
    1c6b:      	cmpq	%r15, %rbx
    1c6e:      	jne	0x1c60 <full_lifecycle+0x180>
    1c70:      	movl	%ebx, %eax
    1c72:      	andl	$0x7, %eax
    1c75:      	cmpq	$0x8, %rbx
    1c79:      	jae	0x1c83 <full_lifecycle+0x1a3>
    1c7b:      	xorl	%r15d, %r15d
    1c7e:      	movq	%r14, %rcx
    1c81:      	jmp	0x1cd2 <full_lifecycle+0x1f2>
    1c83:      	addq	$0x8, %r12
    1c87:      	andq	%rbx, %r12
    1c8a:      	xorl	%r15d, %r15d
    1c8d:      	movq	%r14, %rcx
    1c90:      	movzbl	(%rcx), %edx
    1c93:      	addq	%r15, %rdx
    1c96:      	movzbl	0x1(%rcx), %esi
    1c9a:      	movzbl	0x2(%rcx), %edi
    1c9e:      	addq	%rsi, %rdi
    1ca1:      	addq	%rdx, %rdi
    1ca4:      	movzbl	0x3(%rcx), %edx
    1ca8:      	movzbl	0x4(%rcx), %esi
    1cac:      	addq	%rdx, %rsi
    1caf:      	movzbl	0x5(%rcx), %edx
    1cb3:      	addq	%rsi, %rdx
    1cb6:      	addq	%rdi, %rdx
    1cb9:      	movzbl	0x6(%rcx), %esi
    1cbd:      	movzbl	0x7(%rcx), %r15d
    1cc2:      	addq	%rsi, %r15
    1cc5:      	addq	%rdx, %r15
    1cc8:      	addq	$0x8, %rcx
    1ccc:      	addq	$-0x8, %r12
    1cd0:      	jne	0x1c90 <full_lifecycle+0x1b0>
    1cd2:      	testq	%rax, %rax
    1cd5:      	je	0x1cef <full_lifecycle+0x20f>
    1cd7:      	xorl	%edx, %edx
    1cd9:      	nopl	(%rax)
    1ce0:      	movzbl	(%rcx,%rdx), %esi
    1ce4:      	addq	%rsi, %r15
    1ce7:      	incq	%rdx
    1cea:      	cmpq	%rdx, %rax
    1ced:      	jne	0x1ce0 <full_lifecycle+0x200>
    1cef:      	movq	%r14, %rdi
    1cf2:      	movq	%rbx, %rsi
    1cf5:      	callq	0x22d0 <_ZdlPvm@plt>
    1cfa:      	movq	%r15, %rax
    1cfd:      	popq	%rbx
    1cfe:      	popq	%r12
    1d00:      	popq	%r14
    1d02:      	popq	%r15
    1d04:      	popq	%rbp
    1d05:      	retq
    1d06:      	leaq	-0x145d(%rip), %rdi     # 0x8b0 <memset+0x8b0>
    1d0d:      	callq	0x22b0 <_ZSt20__throw_length_errorPKc@plt>
    1d12:      	cmpl	$0x2, %edx
    1d15:      	je	0x1d1c <full_lifecycle+0x23c>
    1d17:      	cmpl	$0x1, %edx
    1d1a:      	jne	0x1d31 <full_lifecycle+0x251>
    1d1c:      	movq	%rax, %rdi
    1d1f:      	callq	0x2290 <__cxa_begin_catch@plt>
    1d24:      	callq	0x22a0 <__cxa_end_catch@plt>
    1d29:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1d2f:      	jmp	0x1cfa <full_lifecycle+0x21a>
    1d31:      	movq	%rax, %rdi
    1d34:      	callq	0x22e0 <_Unwind_Resume@plt>
    1d39:      	int3
    1d3a:      	int3
    1d3b:      	int3
    1d3c:      	int3
    1d3d:      	int3
    1d3e:      	int3
    1d3f:      	int3

0000000000001d40 <packet_xor>:
    1d40:      	pushq	%rbp
    1d41:      	pushq	%r15
    1d43:      	pushq	%r14
    1d45:      	pushq	%r13
    1d47:      	pushq	%r12
    1d49:      	pushq	%rbx
    1d4a:      	pushq	%rax
    1d4b:      	testq	%rdi, %rdi
    1d4e:      	js	0x21e7 <packet_xor+0x4a7>
    1d54:      	je	0x1d9b <packet_xor+0x5b>
    1d56:      	movl	%esi, %r15d
    1d59:      	movq	%rdi, %rbx
    1d5c:      	callq	0x22c0 <_Znwm@plt>
    1d61:      	movq	%rax, %r14
    1d64:      	movabsq	$0x7ffffffffffffff0, %r13 # imm = 0x7FFFFFFFFFFFFFF0
    1d6e:      	xorl	%r12d, %r12d
    1d71:      	movq	%rax, %rdi
    1d74:      	xorl	%esi, %esi
    1d76:      	movq	%rbx, %rdx
    1d79:      	callq	0x22f0 <memset@plt>
    1d7e:      	cmpq	$0x3, %rbx
    1d82:      	jbe	0x1f77 <packet_xor+0x237>
    1d88:      	movd	%r15d, %xmm0
    1d8d:      	cmpq	$0x10, %rbx
    1d91:      	jae	0x1da3 <packet_xor+0x63>
    1d93:      	xorl	%r12d, %r12d
    1d96:      	jmp	0x1ef8 <packet_xor+0x1b8>
    1d9b:      	xorl	%r15d, %r15d
    1d9e:      	jmp	0x21d5 <packet_xor+0x495>
    1da3:      	movq	%rbx, %r12
    1da6:      	andq	%r13, %r12
    1da9:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1dae:      	movdqa	-0x1586(%rip), %xmm2    # 0x830 <memset+0x830>
    1db6:      	movdqa	-0x157e(%rip), %xmm3    # 0x840 <memset+0x840>
    1dbe:      	movdqa	-0x1576(%rip), %xmm4    # 0x850 <memset+0x850>
    1dc6:      	movdqa	-0x156e(%rip), %xmm5    # 0x860 <memset+0x860>
    1dce:      	xorl	%eax, %eax
    1dd0:      	movdqa	-0x1558(%rip), %xmm6    # 0x880 <memset+0x880>
    1dd8:      	movdqa	-0x1540(%rip), %xmm7    # 0x8a0 <memset+0x8a0>
    1de0:      	movdqa	-0x1559(%rip), %xmm8    # 0x890 <memset+0x890>
    1de9:      	nopl	(%rax)
    1df0:      	movdqa	%xmm5, %xmm9
    1df5:      	pmuludq	%xmm6, %xmm9
    1dfa:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1e00:      	pshufd	$0xf5, %xmm5, %xmm10    # xmm10 = xmm5[1,1,3,3]
    1e06:      	pmuludq	%xmm6, %xmm10
    1e0b:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1e11:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    1e16:      	movdqa	%xmm4, %xmm10
    1e1b:      	pmuludq	%xmm6, %xmm10
    1e20:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1e26:      	pshufd	$0xf5, %xmm4, %xmm11    # xmm11 = xmm4[1,1,3,3]
    1e2c:      	pmuludq	%xmm6, %xmm11
    1e31:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1e37:      	punpckldq	%xmm11, %xmm10  # xmm10 = xmm10[0],xmm11[0],xmm10[1],xmm11[1]
    1e3c:      	movdqa	%xmm3, %xmm11
    1e41:      	pmuludq	%xmm6, %xmm11
    1e46:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1e4c:      	pshufd	$0xf5, %xmm3, %xmm12    # xmm12 = xmm3[1,1,3,3]
    1e52:      	pmuludq	%xmm6, %xmm12
    1e57:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1e5d:      	punpckldq	%xmm12, %xmm11  # xmm11 = xmm11[0],xmm12[0],xmm11[1],xmm12[1]
    1e62:      	movdqa	%xmm2, %xmm12
    1e67:      	pmuludq	%xmm6, %xmm12
    1e6c:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1e72:      	pshufd	$0xf5, %xmm2, %xmm13    # xmm13 = xmm2[1,1,3,3]
    1e78:      	pmuludq	%xmm6, %xmm13
    1e7d:      	pshufd	$0xe8, %xmm13, %xmm13   # xmm13 = xmm13[0,2,2,3]
    1e83:      	punpckldq	%xmm13, %xmm12  # xmm12 = xmm12[0],xmm13[0],xmm12[1],xmm13[1]
    1e88:      	paddd	%xmm1, %xmm12
    1e8d:      	paddd	%xmm1, %xmm11
    1e92:      	paddd	%xmm1, %xmm10
    1e97:      	paddd	%xmm1, %xmm9
    1e9c:      	pand	%xmm7, %xmm9
    1ea1:      	pand	%xmm7, %xmm10
    1ea6:      	packuswb	%xmm10, %xmm9
    1eab:      	pand	%xmm7, %xmm11
    1eb0:      	pand	%xmm7, %xmm12
    1eb5:      	packuswb	%xmm12, %xmm11
    1eba:      	packuswb	%xmm11, %xmm9
    1ebf:      	movdqu	%xmm9, (%r14,%rax)
    1ec5:      	addq	$0x10, %rax
    1ec9:      	paddd	%xmm8, %xmm5
    1ece:      	paddd	%xmm8, %xmm4
    1ed3:      	paddd	%xmm8, %xmm3
    1ed8:      	paddd	%xmm8, %xmm2
    1edd:      	cmpq	%rax, %r12
    1ee0:      	jne	0x1df0 <packet_xor+0xb0>
    1ee6:      	cmpq	%r12, %rbx
    1ee9:      	je	0x1f9e <packet_xor+0x25e>
    1eef:      	testb	$0xc, %bl
    1ef2:      	je	0x1f77 <packet_xor+0x237>
    1ef8:      	movq	%r12, %rax
    1efb:      	leaq	0xc(%r13), %r12
    1eff:      	andq	%rbx, %r12
    1f02:      	movd	%eax, %xmm1
    1f06:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1f0b:      	por	-0x16b3(%rip), %xmm1    # 0x860 <memset+0x860>
    1f13:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1f18:      	movdqa	-0x16a0(%rip), %xmm2    # 0x880 <memset+0x880>
    1f20:      	movdqa	-0x1688(%rip), %xmm3    # 0x8a0 <memset+0x8a0>
    1f28:      	movdqa	-0x16c0(%rip), %xmm4    # 0x870 <memset+0x870>
    1f30:      	movdqa	%xmm1, %xmm5
    1f34:      	pmuludq	%xmm2, %xmm5
    1f38:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    1f3d:      	pshufd	$0xf5, %xmm1, %xmm6     # xmm6 = xmm1[1,1,3,3]
    1f42:      	pmuludq	%xmm2, %xmm6
    1f46:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    1f4b:      	punpckldq	%xmm6, %xmm5    # xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1]
    1f4f:      	paddd	%xmm0, %xmm5
    1f53:      	pand	%xmm3, %xmm5
    1f57:      	packuswb	%xmm5, %xmm5
    1f5b:      	packuswb	%xmm5, %xmm5
    1f5f:      	movd	%xmm5, (%r14,%rax)
    1f65:      	addq	$0x4, %rax
    1f69:      	paddd	%xmm4, %xmm1
    1f6d:      	cmpq	%rax, %r12
    1f70:      	jne	0x1f30 <packet_xor+0x1f0>
    1f72:      	cmpq	%r12, %rbx
    1f75:      	je	0x1f9e <packet_xor+0x25e>
    1f77:      	leal	(%r12,%r12,2), %eax
    1f7b:      	leal	(%r12,%rax,4), %eax
    1f7f:      	addl	%r15d, %eax
    1f82:      	nopw	%cs:(%rax,%rax)
    1f90:      	movb	%al, (%r14,%r12)
    1f94:      	incq	%r12
    1f97:      	addb	$0xd, %al
    1f99:      	cmpq	%r12, %rbx
    1f9c:      	jne	0x1f90 <packet_xor+0x250>
    1f9e:      	movq	%rbx, %rdi
    1fa1:      	callq	0x22c0 <_Znwm@plt>
    1fa6:      	movq	%rax, %r12
    1fa9:      	xorl	%ebp, %ebp
    1fab:      	movq	%rax, %rdi
    1fae:      	xorl	%esi, %esi
    1fb0:      	movq	%rbx, %rdx
    1fb3:      	callq	0x22f0 <memset@plt>
    1fb8:      	xorl	$0x5a, %r15d
    1fbc:      	cmpq	$0x3, %rbx
    1fc0:      	jbe	0x2116 <packet_xor+0x3d6>
    1fc6:      	movd	%r15d, %xmm0
    1fcb:      	cmpq	$0x10, %rbx
    1fcf:      	jae	0x1fd8 <packet_xor+0x298>
    1fd1:      	xorl	%ebp, %ebp
    1fd3:      	jmp	0x20a9 <packet_xor+0x369>
    1fd8:      	movq	%rbx, %rbp
    1fdb:      	andq	%r13, %rbp
    1fde:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1fe3:      	movdqa	-0x17bb(%rip), %xmm2    # 0x830 <memset+0x830>
    1feb:      	movdqa	-0x17b3(%rip), %xmm3    # 0x840 <memset+0x840>
    1ff3:      	movdqa	-0x17ab(%rip), %xmm4    # 0x850 <memset+0x850>
    1ffb:      	movdqa	-0x17a3(%rip), %xmm5    # 0x860 <memset+0x860>
    2003:      	xorl	%eax, %eax
    2005:      	movdqa	-0x176d(%rip), %xmm6    # 0x8a0 <memset+0x8a0>
    200d:      	movdqa	-0x1785(%rip), %xmm7    # 0x890 <memset+0x890>
    2015:      	nopw	%cs:(%rax,%rax)
    2020:      	movdqu	(%r14,%rax), %xmm8
    2026:      	movdqa	%xmm1, %xmm9
    202b:      	paddd	%xmm2, %xmm9
    2030:      	movdqa	%xmm1, %xmm10
    2035:      	paddd	%xmm3, %xmm10
    203a:      	movdqa	%xmm1, %xmm11
    203f:      	paddd	%xmm4, %xmm11
    2044:      	movdqa	%xmm1, %xmm12
    2049:      	paddd	%xmm5, %xmm12
    204e:      	pand	%xmm6, %xmm12
    2053:      	pand	%xmm6, %xmm11
    2058:      	packuswb	%xmm11, %xmm12
    205d:      	pand	%xmm6, %xmm10
    2062:      	pand	%xmm6, %xmm9
    2067:      	packuswb	%xmm9, %xmm10
    206c:      	packuswb	%xmm10, %xmm12
    2071:      	pxor	%xmm8, %xmm12
    2076:      	movdqu	%xmm12, (%r12,%rax)
    207c:      	addq	$0x10, %rax
    2080:      	paddd	%xmm7, %xmm5
    2084:      	paddd	%xmm7, %xmm4
    2088:      	paddd	%xmm7, %xmm3
    208c:      	paddd	%xmm7, %xmm2
    2090:      	cmpq	%rax, %rbp
    2093:      	jne	0x2020 <packet_xor+0x2e0>
    2095:      	cmpq	%rbp, %rbx
    2098:      	jne	0x20a4 <packet_xor+0x364>
    209a:      	movl	%ebx, %eax
    209c:      	andl	$0x7, %eax
    209f:      	jmp	0x214a <packet_xor+0x40a>
    20a4:      	testb	$0xc, %bl
    20a7:      	je	0x2116 <packet_xor+0x3d6>
    20a9:      	movq	%rbp, %rax
    20ac:      	leaq	0xc(%r13), %rbp
    20b0:      	movd	%eax, %xmm1
    20b4:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    20b9:      	por	-0x1861(%rip), %xmm1    # 0x860 <memset+0x860>
    20c1:      	andq	%rbx, %rbp
    20c4:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    20c9:      	movdqa	-0x1831(%rip), %xmm2    # 0x8a0 <memset+0x8a0>
    20d1:      	movdqa	-0x1869(%rip), %xmm3    # 0x870 <memset+0x870>
    20d9:      	nopl	(%rax)
    20e0:      	movd	(%r14,%rax), %xmm4
    20e6:      	movdqa	%xmm0, %xmm5
    20ea:      	paddd	%xmm1, %xmm5
    20ee:      	pand	%xmm2, %xmm5
    20f2:      	packuswb	%xmm5, %xmm5
    20f6:      	packuswb	%xmm5, %xmm5
    20fa:      	pxor	%xmm4, %xmm5
    20fe:      	movd	%xmm5, (%r12,%rax)
    2104:      	addq	$0x4, %rax
    2108:      	paddd	%xmm3, %xmm1
    210c:      	cmpq	%rax, %rbp
    210f:      	jne	0x20e0 <packet_xor+0x3a0>
    2111:      	cmpq	%rbp, %rbx
    2114:      	je	0x2133 <packet_xor+0x3f3>
    2116:      	movl	%r15d, %eax
    2119:      	nopl	(%rax)
    2120:      	leal	(%rax,%rbp), %ecx
    2123:      	xorb	(%r14,%rbp), %cl
    2127:      	movb	%cl, (%r12,%rbp)
    212b:      	incq	%rbp
    212e:      	cmpq	%rbp, %rbx
    2131:      	jne	0x2120 <packet_xor+0x3e0>
    2133:      	leaq	-0x1(%rbx), %rcx
    2137:      	movl	%ebx, %eax
    2139:      	andl	$0x7, %eax
    213c:      	cmpq	$0x7, %rcx
    2140:      	jae	0x214a <packet_xor+0x40a>
    2142:      	xorl	%r15d, %r15d
    2145:      	movq	%r12, %rcx
    2148:      	jmp	0x21a2 <packet_xor+0x462>
    214a:      	addq	$0x8, %r13
    214e:      	andq	%rbx, %r13
    2151:      	xorl	%r15d, %r15d
    2154:      	movq	%r12, %rcx
    2157:      	nopw	(%rax,%rax)
    2160:      	movzbl	(%rcx), %edx
    2163:      	addq	%r15, %rdx
    2166:      	movzbl	0x1(%rcx), %esi
    216a:      	movzbl	0x2(%rcx), %edi
    216e:      	addq	%rsi, %rdi
    2171:      	addq	%rdx, %rdi
    2174:      	movzbl	0x3(%rcx), %edx
    2178:      	movzbl	0x4(%rcx), %esi
    217c:      	addq	%rdx, %rsi
    217f:      	movzbl	0x5(%rcx), %edx
    2183:      	addq	%rsi, %rdx
    2186:      	addq	%rdi, %rdx
    2189:      	movzbl	0x6(%rcx), %esi
    218d:      	movzbl	0x7(%rcx), %r15d
    2192:      	addq	%rsi, %r15
    2195:      	addq	%rdx, %r15
    2198:      	addq	$0x8, %rcx
    219c:      	addq	$-0x8, %r13
    21a0:      	jne	0x2160 <packet_xor+0x420>
    21a2:      	testq	%rax, %rax
    21a5:      	je	0x21bf <packet_xor+0x47f>
    21a7:      	xorl	%edx, %edx
    21a9:      	nopl	(%rax)
    21b0:      	movzbl	(%rcx,%rdx), %esi
    21b4:      	addq	%rsi, %r15
    21b7:      	incq	%rdx
    21ba:      	cmpq	%rdx, %rax
    21bd:      	jne	0x21b0 <packet_xor+0x470>
    21bf:      	movq	%r12, %rdi
    21c2:      	movq	%rbx, %rsi
    21c5:      	callq	0x22d0 <_ZdlPvm@plt>
    21ca:      	movq	%r14, %rdi
    21cd:      	movq	%rbx, %rsi
    21d0:      	callq	0x22d0 <_ZdlPvm@plt>
    21d5:      	movq	%r15, %rax
    21d8:      	addq	$0x8, %rsp
    21dc:      	popq	%rbx
    21dd:      	popq	%r12
    21df:      	popq	%r13
    21e1:      	popq	%r14
    21e3:      	popq	%r15
    21e5:      	popq	%rbp
    21e6:      	retq
    21e7:      	leaq	-0x193e(%rip), %rdi     # 0x8b0 <memset+0x8b0>
    21ee:      	callq	0x22b0 <_ZSt20__throw_length_errorPKc@plt>
    21f3:      	movq	%rdx, %r12
    21f6:      	movq	%rax, %r15
    21f9:      	movq	%r14, %rdi
    21fc:      	movq	%rbx, %rsi
    21ff:      	callq	0x22d0 <_ZdlPvm@plt>
    2204:      	jmp	0x220c <packet_xor+0x4cc>
    2206:      	movq	%rdx, %r12
    2209:      	movq	%rax, %r15
    220c:      	cmpl	$0x2, %r12d
    2210:      	je	0x2218 <packet_xor+0x4d8>
    2212:      	cmpl	$0x1, %r12d
    2216:      	jne	0x222d <packet_xor+0x4ed>
    2218:      	movq	%r15, %rdi
    221b:      	callq	0x2290 <__cxa_begin_catch@plt>
    2220:      	callq	0x22a0 <__cxa_end_catch@plt>
    2225:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    222b:      	jmp	0x21d5 <packet_xor+0x495>
    222d:      	movq	%r15, %rdi
    2230:      	callq	0x22e0 <_Unwind_Resume@plt>

Disassembly of section .init:

0000000000002238 <_init>:
    2238:      	endbr64
    223c:      	subq	$0x8, %rsp
    2240:      	movq	0x1279(%rip), %rax      # 0x34c0 <memset+0x34c0>
    2247:      	testq	%rax, %rax
    224a:      	je	0x224e <_init+0x16>
    224c:      	callq	*%rax
    224e:      	addq	$0x8, %rsp
    2252:      	retq

Disassembly of section .fini:

0000000000002254 <_fini>:
    2254:      	endbr64
    2258:      	subq	$0x8, %rsp
    225c:      	addq	$0x8, %rsp
    2260:      	retq

Disassembly of section .plt:

0000000000002270 <.plt>:
    2270:      	pushq	0x2292(%rip)            # 0x4508 <_GLOBAL_OFFSET_TABLE_+0x8>
    2276:      	jmpq	*0x2294(%rip)           # 0x4510 <_GLOBAL_OFFSET_TABLE_+0x10>
    227c:      	nopl	(%rax)

0000000000002280 <__cxa_finalize@plt>:
    2280:      	jmpq	*0x2292(%rip)           # 0x4518 <_GLOBAL_OFFSET_TABLE_+0x18>
    2286:      	pushq	$0x0
    228b:      	jmp	0x2270 <.plt>

0000000000002290 <__cxa_begin_catch@plt>:
    2290:      	jmpq	*0x228a(%rip)           # 0x4520 <_GLOBAL_OFFSET_TABLE_+0x20>
    2296:      	pushq	$0x1
    229b:      	jmp	0x2270 <.plt>

00000000000022a0 <__cxa_end_catch@plt>:
    22a0:      	jmpq	*0x2282(%rip)           # 0x4528 <_GLOBAL_OFFSET_TABLE_+0x28>
    22a6:      	pushq	$0x2
    22ab:      	jmp	0x2270 <.plt>

00000000000022b0 <_ZSt20__throw_length_errorPKc@plt>:
    22b0:      	jmpq	*0x227a(%rip)           # 0x4530 <_GLOBAL_OFFSET_TABLE_+0x30>
    22b6:      	pushq	$0x3
    22bb:      	jmp	0x2270 <.plt>

00000000000022c0 <_Znwm@plt>:
    22c0:      	jmpq	*0x2272(%rip)           # 0x4538 <_GLOBAL_OFFSET_TABLE_+0x38>
    22c6:      	pushq	$0x4
    22cb:      	jmp	0x2270 <.plt>

00000000000022d0 <_ZdlPvm@plt>:
    22d0:      	jmpq	*0x226a(%rip)           # 0x4540 <_GLOBAL_OFFSET_TABLE_+0x40>
    22d6:      	pushq	$0x5
    22db:      	jmp	0x2270 <.plt>

00000000000022e0 <_Unwind_Resume@plt>:
    22e0:      	jmpq	*0x2262(%rip)           # 0x4548 <_GLOBAL_OFFSET_TABLE_+0x48>
    22e6:      	pushq	$0x6
    22eb:      	jmp	0x2270 <.plt>

00000000000022f0 <memset@plt>:
    22f0:      	jmpq	*0x225a(%rip)           # 0x4550 <_GLOBAL_OFFSET_TABLE_+0x50>
    22f6:      	pushq	$0x7
    22fb:      	jmp	0x2270 <.plt>
