
/tmp/hepta-next-20261028-bench-final-01/hia_verified.so:	file format elf64-x86-64

Disassembly of section .init:

0000000000001000 <_init>:
    1000:      	endbr64
    1004:      	subq	$0x8, %rsp
    1008:      	movq	0x2fc1(%rip), %rax      # 0x3fd0 <free@GLIBC_2.2.5+0x3fd0>
    100f:      	testq	%rax, %rax
    1012:      	je	0x1016 <_init+0x16>
    1014:      	callq	*%rax
    1016:      	addq	$0x8, %rsp
    101a:      	retq

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:      	pushq	0x2fca(%rip)            # 0x3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:      	jmpq	*0x2fcc(%rip)           # 0x3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:      	nopl	(%rax)

0000000000001030 <free@plt>:
    1030:      	jmpq	*0x2fca(%rip)           # 0x4000 <_GLOBAL_OFFSET_TABLE_+0x18>
    1036:      	pushq	$0x0
    103b:      	jmp	0x1020 <.plt>

0000000000001040 <abort@plt>:
    1040:      	jmpq	*0x2fc2(%rip)           # 0x4008 <_GLOBAL_OFFSET_TABLE_+0x20>
    1046:      	pushq	$0x1
    104b:      	jmp	0x1020 <.plt>

0000000000001050 <calloc@plt>:
    1050:      	jmpq	*0x2fba(%rip)           # 0x4010 <_GLOBAL_OFFSET_TABLE_+0x28>
    1056:      	pushq	$0x2
    105b:      	jmp	0x1020 <.plt>

Disassembly of section .plt.got:

0000000000001060 <__cxa_finalize@plt>:
    1060:      	jmpq	*0x2f7a(%rip)           # 0x3fe0 <free@GLIBC_2.2.5+0x3fe0>
    1066:      	nop

Disassembly of section .text:

0000000000001070 <deregister_tm_clones>:
    1070:      	leaq	0x2fa9(%rip), %rdi      # 0x4020 <completed.0>
    1077:      	leaq	0x2fa2(%rip), %rax      # 0x4020 <completed.0>
    107e:      	cmpq	%rdi, %rax
    1081:      	je	0x1098 <deregister_tm_clones+0x28>
    1083:      	movq	0x2f3e(%rip), %rax      # 0x3fc8 <free@GLIBC_2.2.5+0x3fc8>
    108a:      	testq	%rax, %rax
    108d:      	je	0x1098 <deregister_tm_clones+0x28>
    108f:      	jmpq	*%rax
    1091:      	nopl	(%rax)
    1098:      	retq
    1099:      	nopl	(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:      	leaq	0x2f79(%rip), %rdi      # 0x4020 <completed.0>
    10a7:      	leaq	0x2f72(%rip), %rsi      # 0x4020 <completed.0>
    10ae:      	subq	%rdi, %rsi
    10b1:      	movq	%rsi, %rax
    10b4:      	shrq	$0x3f, %rsi
    10b8:      	sarq	$0x3, %rax
    10bc:      	addq	%rax, %rsi
    10bf:      	sarq	%rsi
    10c2:      	je	0x10d8 <register_tm_clones+0x38>
    10c4:      	movq	0x2f0d(%rip), %rax      # 0x3fd8 <free@GLIBC_2.2.5+0x3fd8>
    10cb:      	testq	%rax, %rax
    10ce:      	je	0x10d8 <register_tm_clones+0x38>
    10d0:      	jmpq	*%rax
    10d2:      	nopw	(%rax,%rax)
    10d8:      	retq
    10d9:      	nopl	(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:      	endbr64
    10e4:      	cmpb	$0x0, 0x2f35(%rip)      # 0x4020 <completed.0>
    10eb:      	jne	0x1118 <__do_global_dtors_aux+0x38>
    10ed:      	pushq	%rbp
    10ee:      	cmpq	$0x0, 0x2eea(%rip)      # 0x3fe0 <free@GLIBC_2.2.5+0x3fe0>
    10f6:      	movq	%rsp, %rbp
    10f9:      	je	0x1107 <__do_global_dtors_aux+0x27>
    10fb:      	movq	0x2f16(%rip), %rdi      # 0x4018 <__dso_handle>
    1102:      	callq	0x1060 <__cxa_finalize@plt>
    1107:      	callq	0x1070 <deregister_tm_clones>
    110c:      	movb	$0x1, 0x2f0d(%rip)      # 0x4020 <completed.0>
    1113:      	popq	%rbp
    1114:      	retq
    1115:      	nopl	(%rax)
    1118:      	retq
    1119:      	nopl	(%rax)

0000000000001120 <frame_dummy>:
    1120:      	endbr64
    1124:      	jmp	0x10a0 <register_tm_clones>
    1129:      	nopl	(%rax)

0000000000001130 <full_lifecycle>:
    1130:      	pushq	%rbp
    1131:      	pushq	%r14
    1133:      	pushq	%rbx
    1134:      	movl	%esi, %ebp
    1136:      	movq	%rdi, %rbx
    1139:      	movabsq	$0x101010101010102, %rax # imm = 0x101010101010102
    1143:      	cmpq	%rax, %rdi
    1146:      	jae	0x1182 <full_lifecycle+0x52>
    1148:      	testq	%rbx, %rbx
    114b:      	je	0x12d4 <full_lifecycle+0x1a4>
    1151:      	movl	$0x1, %edi
    1156:      	movq	%rbx, %rsi
    1159:      	callq	0x1050 <calloc@plt>
    115e:      	testq	%rax, %rax
    1161:      	je	0x12dc <full_lifecycle+0x1ac>
    1167:      	movabsq	$0x1fffffffffffff0, %rcx # imm = 0x1FFFFFFFFFFFFF0
    1171:      	cmpq	$0x3, %rbx
    1175:      	ja	0x12e7 <full_lifecycle+0x1b7>
    117b:      	xorl	%edx, %edx
    117d:      	jmp	0x141b <full_lifecycle+0x2eb>
    1182:      	testq	%rbx, %rbx
    1185:      	js	0x11b4 <full_lifecycle+0x84>
    1187:      	movl	$0x1, %edi
    118c:      	movq	%rbx, %rsi
    118f:      	callq	0x1050 <calloc@plt>
    1194:      	testq	%rax, %rax
    1197:      	je	0x11b4 <full_lifecycle+0x84>
    1199:      	movb	$0x1, %cl
    119b:      	testb	$0x1, %cl
    119e:      	jne	0x11bd <full_lifecycle+0x8d>
    11a0:      	movl	$0x3e9, %r14d           # imm = 0x3E9
    11a6:      	testq	%rax, %rax
    11a9:      	jne	0x1505 <full_lifecycle+0x3d5>
    11af:      	jmp	0x150d <full_lifecycle+0x3dd>
    11b4:      	xorl	%eax, %eax
    11b6:      	xorl	%ecx, %ecx
    11b8:      	testb	$0x1, %cl
    11bb:      	je	0x11a0 <full_lifecycle+0x70>
    11bd:      	movq	%rbx, %rcx
    11c0:      	andq	$-0x10, %rcx
    11c4:      	movd	%ebp, %xmm0
    11c8:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    11cd:      	movdqa	0xe2b(%rip), %xmm2      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    11d5:      	movdqa	0xe33(%rip), %xmm3      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    11dd:      	movdqa	0xe3b(%rip), %xmm4      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    11e5:      	movdqa	0xe43(%rip), %xmm5      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    11ed:      	xorl	%edx, %edx
    11ef:      	movdqa	0xe49(%rip), %xmm1      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    11f7:      	movdqa	0xe51(%rip), %xmm6      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    11ff:      	nop
    1200:      	movdqa	%xmm0, %xmm7
    1204:      	paddd	%xmm2, %xmm7
    1208:      	movdqa	%xmm0, %xmm8
    120d:      	paddd	%xmm3, %xmm8
    1212:      	movdqa	%xmm0, %xmm9
    1217:      	paddd	%xmm4, %xmm9
    121c:      	movdqa	%xmm0, %xmm10
    1221:      	paddd	%xmm5, %xmm10
    1226:      	pand	%xmm1, %xmm10
    122b:      	pand	%xmm1, %xmm9
    1230:      	packuswb	%xmm9, %xmm10
    1235:      	pand	%xmm1, %xmm8
    123a:      	pand	%xmm1, %xmm7
    123e:      	packuswb	%xmm7, %xmm8
    1243:      	packuswb	%xmm8, %xmm10
    1248:      	movdqu	%xmm10, (%rax,%rdx)
    124e:      	addq	$0x10, %rdx
    1252:      	paddd	%xmm6, %xmm5
    1256:      	paddd	%xmm6, %xmm4
    125a:      	paddd	%xmm6, %xmm3
    125e:      	paddd	%xmm6, %xmm2
    1262:      	cmpq	%rdx, %rcx
    1265:      	jne	0x1200 <full_lifecycle+0xd0>
    1267:      	cmpq	%rcx, %rbx
    126a:      	je	0x14df <full_lifecycle+0x3af>
    1270:      	testb	$0xc, %bl
    1273:      	je	0x14c1 <full_lifecycle+0x391>
    1279:      	movq	%rbx, %rdx
    127c:      	andq	$-0x4, %rdx
    1280:      	movd	%ecx, %xmm2
    1284:      	pshufd	$0x0, %xmm2, %xmm2      # xmm2 = xmm2[0,0,0,0]
    1289:      	por	0xd9f(%rip), %xmm2      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1291:      	movdqa	0xdc7(%rip), %xmm3      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    1299:      	nopl	(%rax)
    12a0:      	movdqa	%xmm0, %xmm4
    12a4:      	paddd	%xmm2, %xmm4
    12a8:      	pand	%xmm1, %xmm4
    12ac:      	packuswb	%xmm4, %xmm4
    12b0:      	packuswb	%xmm4, %xmm4
    12b4:      	movd	%xmm4, (%rax,%rcx)
    12b9:      	addq	$0x4, %rcx
    12bd:      	paddd	%xmm3, %xmm2
    12c1:      	cmpq	%rcx, %rdx
    12c4:      	jne	0x12a0 <full_lifecycle+0x170>
    12c6:      	cmpq	%rdx, %rbx
    12c9:      	jne	0x14c4 <full_lifecycle+0x394>
    12cf:      	jmp	0x14df <full_lifecycle+0x3af>
    12d4:      	xorl	%r14d, %r14d
    12d7:      	jmp	0x150d <full_lifecycle+0x3dd>
    12dc:      	movl	$0x3e9, %r14d           # imm = 0x3E9
    12e2:      	jmp	0x150d <full_lifecycle+0x3dd>
    12e7:      	cmpq	$0x10, %rbx
    12eb:      	jae	0x12f4 <full_lifecycle+0x1c4>
    12ed:      	xorl	%edx, %edx
    12ef:      	jmp	0x13b5 <full_lifecycle+0x285>
    12f4:      	movq	%rbx, %rdx
    12f7:      	andq	%rcx, %rdx
    12fa:      	movd	%ebp, %xmm0
    12fe:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1303:      	movdqa	0xcf5(%rip), %xmm1      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    130b:      	movdqa	0xcfd(%rip), %xmm2      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    1313:      	movdqa	0xd05(%rip), %xmm3      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    131b:      	movdqa	0xd0d(%rip), %xmm4      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1323:      	xorl	%esi, %esi
    1325:      	movdqa	0xd13(%rip), %xmm5      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    132d:      	movdqa	0xd1b(%rip), %xmm6      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    1335:      	nopw	%cs:(%rax,%rax)
    1340:      	movdqa	%xmm0, %xmm7
    1344:      	paddd	%xmm1, %xmm7
    1348:      	movdqa	%xmm0, %xmm8
    134d:      	paddd	%xmm2, %xmm8
    1352:      	movdqa	%xmm0, %xmm9
    1357:      	paddd	%xmm3, %xmm9
    135c:      	movdqa	%xmm0, %xmm10
    1361:      	paddd	%xmm4, %xmm10
    1366:      	pand	%xmm5, %xmm10
    136b:      	pand	%xmm5, %xmm9
    1370:      	packuswb	%xmm9, %xmm10
    1375:      	pand	%xmm5, %xmm8
    137a:      	pand	%xmm5, %xmm7
    137e:      	packuswb	%xmm7, %xmm8
    1383:      	packuswb	%xmm8, %xmm10
    1388:      	movdqu	%xmm10, (%rax,%rsi)
    138e:      	addq	$0x10, %rsi
    1392:      	paddd	%xmm6, %xmm4
    1396:      	paddd	%xmm6, %xmm3
    139a:      	paddd	%xmm6, %xmm2
    139e:      	paddd	%xmm6, %xmm1
    13a2:      	cmpq	%rsi, %rdx
    13a5:      	jne	0x1340 <full_lifecycle+0x210>
    13a7:      	cmpq	%rdx, %rbx
    13aa:      	je	0x142f <full_lifecycle+0x2ff>
    13b0:      	testb	$0xc, %bl
    13b3:      	je	0x141b <full_lifecycle+0x2eb>
    13b5:      	movq	%rdx, %rsi
    13b8:      	leaq	0xc(%rcx), %rdx
    13bc:      	andq	%rbx, %rdx
    13bf:      	movd	%esi, %xmm0
    13c3:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    13c8:      	por	0xc60(%rip), %xmm0      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    13d0:      	movd	%ebp, %xmm1
    13d4:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    13d9:      	movdqa	0xc5f(%rip), %xmm2      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    13e1:      	movdqa	0xc77(%rip), %xmm3      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    13e9:      	nopl	(%rax)
    13f0:      	movdqa	%xmm1, %xmm4
    13f4:      	paddd	%xmm0, %xmm4
    13f8:      	pand	%xmm2, %xmm4
    13fc:      	packuswb	%xmm4, %xmm4
    1400:      	packuswb	%xmm4, %xmm4
    1404:      	movd	%xmm4, (%rax,%rsi)
    1409:      	addq	$0x4, %rsi
    140d:      	paddd	%xmm3, %xmm0
    1411:      	cmpq	%rsi, %rdx
    1414:      	jne	0x13f0 <full_lifecycle+0x2c0>
    1416:      	cmpq	%rdx, %rbx
    1419:      	je	0x142f <full_lifecycle+0x2ff>
    141b:      	movl	%ebp, %esi
    141d:      	nopl	(%rax)
    1420:      	leal	(%rsi,%rdx), %edi
    1423:      	movb	%dil, (%rax,%rdx)
    1427:      	incq	%rdx
    142a:      	cmpq	%rdx, %rbx
    142d:      	jne	0x1420 <full_lifecycle+0x2f0>
    142f:      	movl	%ebx, %edx
    1431:      	andl	$0x7, %edx
    1434:      	cmpq	$0x8, %rbx
    1438:      	jae	0x1441 <full_lifecycle+0x311>
    143a:      	xorl	%ecx, %ecx
    143c:      	xorl	%r14d, %r14d
    143f:      	jmp	0x149a <full_lifecycle+0x36a>
    1441:      	addq	$0x8, %rcx
    1445:      	andq	%rcx, %rbx
    1448:      	xorl	%ecx, %ecx
    144a:      	xorl	%r14d, %r14d
    144d:      	nopl	(%rax)
    1450:      	movzbl	(%rax,%rcx), %esi
    1454:      	addq	%r14, %rsi
    1457:      	movzbl	0x1(%rax,%rcx), %edi
    145c:      	movzbl	0x2(%rax,%rcx), %r8d
    1462:      	addq	%rdi, %r8
    1465:      	addq	%rsi, %r8
    1468:      	movzbl	0x3(%rax,%rcx), %esi
    146d:      	movzbl	0x4(%rax,%rcx), %edi
    1472:      	addq	%rsi, %rdi
    1475:      	movzbl	0x5(%rax,%rcx), %esi
    147a:      	addq	%rdi, %rsi
    147d:      	addq	%r8, %rsi
    1480:      	movzbl	0x6(%rax,%rcx), %edi
    1485:      	movzbl	0x7(%rax,%rcx), %r14d
    148b:      	addq	%rdi, %r14
    148e:      	addq	%rsi, %r14
    1491:      	addq	$0x8, %rcx
    1495:      	cmpq	%rcx, %rbx
    1498:      	jne	0x1450 <full_lifecycle+0x320>
    149a:      	testq	%rdx, %rdx
    149d:      	je	0x1505 <full_lifecycle+0x3d5>
    149f:      	movq	%rax, %rsi
    14a2:      	addq	%rcx, %rsi
    14a5:      	xorl	%ecx, %ecx
    14a7:      	nopw	(%rax,%rax)
    14b0:      	movzbl	(%rsi,%rcx), %edi
    14b4:      	addq	%rdi, %r14
    14b7:      	incq	%rcx
    14ba:      	cmpq	%rcx, %rdx
    14bd:      	jne	0x14b0 <full_lifecycle+0x380>
    14bf:      	jmp	0x1505 <full_lifecycle+0x3d5>
    14c1:      	movq	%rcx, %rdx
    14c4:      	movl	%ebp, %ecx
    14c6:      	nopw	%cs:(%rax,%rax)
    14d0:      	leal	(%rcx,%rdx), %esi
    14d3:      	movb	%sil, (%rax,%rdx)
    14d7:      	incq	%rdx
    14da:      	cmpq	%rdx, %rbx
    14dd:      	jne	0x14d0 <full_lifecycle+0x3a0>
    14df:      	xorl	%ecx, %ecx
    14e1:      	xorl	%r14d, %r14d
    14e4:      	nopw	%cs:(%rax,%rax)
    14f0:      	movq	%r14, %rdx
    14f3:      	movzbl	(%rax,%rcx), %r14d
    14f8:      	addq	%rdx, %r14
    14fb:      	jb	0x1515 <full_lifecycle+0x3e5>
    14fd:      	incq	%rcx
    1500:      	cmpq	%rcx, %rbx
    1503:      	jne	0x14f0 <full_lifecycle+0x3c0>
    1505:      	movq	%rax, %rdi
    1508:      	callq	0x1030 <free@plt>
    150d:      	movq	%r14, %rax
    1510:      	popq	%rbx
    1511:      	popq	%r14
    1513:      	popq	%rbp
    1514:      	retq
    1515:      	callq	0x1040 <abort@plt>
    151a:      	nopw	(%rax,%rax)

0000000000001520 <packet_xor>:
    1520:      	pushq	%r15
    1522:      	pushq	%r14
    1524:      	pushq	%r12
    1526:      	pushq	%rbx
    1527:      	pushq	%rax
    1528:      	movl	%esi, %r15d
    152b:      	movq	%rdi, %r14
    152e:      	movabsq	$0x101010101010102, %rax # imm = 0x101010101010102
    1538:      	cmpq	%rax, %rdi
    153b:      	jae	0x157a <packet_xor+0x5a>
    153d:      	testq	%r14, %r14
    1540:      	je	0x1780 <packet_xor+0x260>
    1546:      	movl	$0x1, %edi
    154b:      	movq	%r14, %rsi
    154e:      	callq	0x1050 <calloc@plt>
    1553:      	testq	%rax, %rax
    1556:      	je	0x1788 <packet_xor+0x268>
    155c:      	movq	%rax, %rbx
    155f:      	movabsq	$0x1fffffffffffff0, %r12 # imm = 0x1FFFFFFFFFFFFF0
    1569:      	cmpq	$0x3, %r14
    156d:      	ja	0x1793 <packet_xor+0x273>
    1573:      	xorl	%eax, %eax
    1575:      	jmp	0x1986 <packet_xor+0x466>
    157a:      	testq	%r14, %r14
    157d:      	js	0x15ae <packet_xor+0x8e>
    157f:      	movl	$0x1, %edi
    1584:      	movq	%r14, %rsi
    1587:      	callq	0x1050 <calloc@plt>
    158c:      	testq	%rax, %rax
    158f:      	je	0x15ae <packet_xor+0x8e>
    1591:      	movq	%rax, %rbx
    1594:      	movb	$0x1, %al
    1596:      	testb	$0x1, %al
    1598:      	jne	0x15b6 <packet_xor+0x96>
    159a:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    15a0:      	testq	%rbx, %rbx
    15a3:      	jne	0x1e67 <packet_xor+0x947>
    15a9:      	jmp	0x1e6f <packet_xor+0x94f>
    15ae:      	xorl	%ebx, %ebx
    15b0:      	xorl	%eax, %eax
    15b2:      	testb	$0x1, %al
    15b4:      	je	0x159a <packet_xor+0x7a>
    15b6:      	movq	%r14, %rax
    15b9:      	andq	$-0x10, %rax
    15bd:      	movd	%r15d, %xmm0
    15c2:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    15c7:      	movdqa	0xa31(%rip), %xmm2      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    15cf:      	movdqa	0xa39(%rip), %xmm3      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    15d7:      	movdqa	0xa41(%rip), %xmm4      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    15df:      	movdqa	0xa49(%rip), %xmm5      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    15e7:      	xorl	%ecx, %ecx
    15e9:      	movdqa	0xa7f(%rip), %xmm1      # 0x2070 <free@GLIBC_2.2.5+0x2070>
    15f1:      	movdqa	0xa46(%rip), %xmm11     # 0x2040 <free@GLIBC_2.2.5+0x2040>
    15fa:      	movdqa	0xa4d(%rip), %xmm12     # 0x2050 <free@GLIBC_2.2.5+0x2050>
    1603:      	nopw	%cs:(%rax,%rax)
    1610:      	movdqa	%xmm5, %xmm6
    1614:      	pmuludq	%xmm1, %xmm6
    1618:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    161d:      	pshufd	$0xf5, %xmm5, %xmm7     # xmm7 = xmm5[1,1,3,3]
    1622:      	pmuludq	%xmm1, %xmm7
    1626:      	pshufd	$0xe8, %xmm7, %xmm7     # xmm7 = xmm7[0,2,2,3]
    162b:      	punpckldq	%xmm7, %xmm6    # xmm6 = xmm6[0],xmm7[0],xmm6[1],xmm7[1]
    162f:      	movdqa	%xmm4, %xmm7
    1633:      	pmuludq	%xmm1, %xmm7
    1637:      	pshufd	$0xe8, %xmm7, %xmm7     # xmm7 = xmm7[0,2,2,3]
    163c:      	pshufd	$0xf5, %xmm4, %xmm8     # xmm8 = xmm4[1,1,3,3]
    1642:      	pmuludq	%xmm1, %xmm8
    1647:      	pshufd	$0xe8, %xmm8, %xmm8     # xmm8 = xmm8[0,2,2,3]
    164d:      	punpckldq	%xmm8, %xmm7    # xmm7 = xmm7[0],xmm8[0],xmm7[1],xmm8[1]
    1652:      	movdqa	%xmm3, %xmm8
    1657:      	pmuludq	%xmm1, %xmm8
    165c:      	pshufd	$0xe8, %xmm8, %xmm8     # xmm8 = xmm8[0,2,2,3]
    1662:      	pshufd	$0xf5, %xmm3, %xmm9     # xmm9 = xmm3[1,1,3,3]
    1668:      	pmuludq	%xmm1, %xmm9
    166d:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1673:      	punpckldq	%xmm9, %xmm8    # xmm8 = xmm8[0],xmm9[0],xmm8[1],xmm9[1]
    1678:      	movdqa	%xmm2, %xmm9
    167d:      	pmuludq	%xmm1, %xmm9
    1682:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1688:      	pshufd	$0xf5, %xmm2, %xmm10    # xmm10 = xmm2[1,1,3,3]
    168e:      	pmuludq	%xmm1, %xmm10
    1693:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1699:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    169e:      	paddd	%xmm0, %xmm9
    16a3:      	paddd	%xmm0, %xmm8
    16a8:      	paddd	%xmm0, %xmm7
    16ac:      	paddd	%xmm0, %xmm6
    16b0:      	pand	%xmm11, %xmm6
    16b5:      	pand	%xmm11, %xmm7
    16ba:      	packuswb	%xmm7, %xmm6
    16be:      	pand	%xmm11, %xmm8
    16c3:      	pand	%xmm11, %xmm9
    16c8:      	packuswb	%xmm9, %xmm8
    16cd:      	packuswb	%xmm8, %xmm6
    16d2:      	movdqu	%xmm6, (%rbx,%rcx)
    16d7:      	addq	$0x10, %rcx
    16db:      	paddd	%xmm12, %xmm5
    16e0:      	paddd	%xmm12, %xmm4
    16e5:      	paddd	%xmm12, %xmm3
    16ea:      	paddd	%xmm12, %xmm2
    16ef:      	cmpq	%rcx, %rax
    16f2:      	jne	0x1610 <packet_xor+0xf0>
    16f8:      	cmpq	%rax, %r14
    16fb:      	je	0x19fd <packet_xor+0x4dd>
    1701:      	testb	$0xc, %r14b
    1705:      	je	0x19e2 <packet_xor+0x4c2>
    170b:      	movq	%r14, %rcx
    170e:      	andq	$-0x4, %rcx
    1712:      	movd	%eax, %xmm2
    1716:      	pshufd	$0x0, %xmm2, %xmm2      # xmm2 = xmm2[0,0,0,0]
    171b:      	por	0x90d(%rip), %xmm2      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1723:      	movdqa	0x935(%rip), %xmm3      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    172b:      	nopl	(%rax,%rax)
    1730:      	movdqa	%xmm2, %xmm4
    1734:      	pmuludq	%xmm1, %xmm4
    1738:      	pshufd	$0xe8, %xmm4, %xmm4     # xmm4 = xmm4[0,2,2,3]
    173d:      	pshufd	$0xf5, %xmm2, %xmm5     # xmm5 = xmm2[1,1,3,3]
    1742:      	pmuludq	%xmm1, %xmm5
    1746:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    174b:      	punpckldq	%xmm5, %xmm4    # xmm4 = xmm4[0],xmm5[0],xmm4[1],xmm5[1]
    174f:      	paddd	%xmm0, %xmm4
    1753:      	pand	%xmm11, %xmm4
    1758:      	packuswb	%xmm4, %xmm4
    175c:      	packuswb	%xmm4, %xmm4
    1760:      	movd	%xmm4, (%rbx,%rax)
    1765:      	addq	$0x4, %rax
    1769:      	paddd	%xmm3, %xmm2
    176d:      	cmpq	%rax, %rcx
    1770:      	jne	0x1730 <packet_xor+0x210>
    1772:      	cmpq	%rcx, %r14
    1775:      	jne	0x19e5 <packet_xor+0x4c5>
    177b:      	jmp	0x19fd <packet_xor+0x4dd>
    1780:      	xorl	%r15d, %r15d
    1783:      	jmp	0x1e6f <packet_xor+0x94f>
    1788:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    178e:      	jmp	0x1e6f <packet_xor+0x94f>
    1793:      	cmpq	$0x10, %r14
    1797:      	jae	0x17a0 <packet_xor+0x280>
    1799:      	xorl	%eax, %eax
    179b:      	jmp	0x18f5 <packet_xor+0x3d5>
    17a0:      	movq	%r14, %rax
    17a3:      	andq	%r12, %rax
    17a6:      	movd	%r15d, %xmm0
    17ab:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    17b0:      	movdqa	0x848(%rip), %xmm1      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    17b8:      	movdqa	0x850(%rip), %xmm2      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    17c0:      	movdqa	0x858(%rip), %xmm3      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    17c8:      	movdqa	0x860(%rip), %xmm4      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    17d0:      	xorl	%ecx, %ecx
    17d2:      	movdqa	0x896(%rip), %xmm5      # 0x2070 <free@GLIBC_2.2.5+0x2070>
    17da:      	movdqa	0x85e(%rip), %xmm6      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    17e2:      	movdqa	0x866(%rip), %xmm7      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    17ea:      	nopw	(%rax,%rax)
    17f0:      	movdqa	%xmm4, %xmm8
    17f5:      	pmuludq	%xmm5, %xmm8
    17fa:      	pshufd	$0xe8, %xmm8, %xmm8     # xmm8 = xmm8[0,2,2,3]
    1800:      	pshufd	$0xf5, %xmm4, %xmm9     # xmm9 = xmm4[1,1,3,3]
    1806:      	pmuludq	%xmm5, %xmm9
    180b:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1811:      	punpckldq	%xmm9, %xmm8    # xmm8 = xmm8[0],xmm9[0],xmm8[1],xmm9[1]
    1816:      	movdqa	%xmm3, %xmm9
    181b:      	pmuludq	%xmm5, %xmm9
    1820:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1826:      	pshufd	$0xf5, %xmm3, %xmm10    # xmm10 = xmm3[1,1,3,3]
    182c:      	pmuludq	%xmm5, %xmm10
    1831:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1837:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    183c:      	movdqa	%xmm2, %xmm10
    1841:      	pmuludq	%xmm5, %xmm10
    1846:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    184c:      	pshufd	$0xf5, %xmm2, %xmm11    # xmm11 = xmm2[1,1,3,3]
    1852:      	pmuludq	%xmm5, %xmm11
    1857:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    185d:      	punpckldq	%xmm11, %xmm10  # xmm10 = xmm10[0],xmm11[0],xmm10[1],xmm11[1]
    1862:      	movdqa	%xmm1, %xmm11
    1867:      	pmuludq	%xmm5, %xmm11
    186c:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1872:      	pshufd	$0xf5, %xmm1, %xmm12    # xmm12 = xmm1[1,1,3,3]
    1878:      	pmuludq	%xmm5, %xmm12
    187d:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1883:      	punpckldq	%xmm12, %xmm11  # xmm11 = xmm11[0],xmm12[0],xmm11[1],xmm12[1]
    1888:      	paddd	%xmm0, %xmm11
    188d:      	paddd	%xmm0, %xmm10
    1892:      	paddd	%xmm0, %xmm9
    1897:      	paddd	%xmm0, %xmm8
    189c:      	pand	%xmm6, %xmm8
    18a1:      	pand	%xmm6, %xmm9
    18a6:      	packuswb	%xmm9, %xmm8
    18ab:      	pand	%xmm6, %xmm10
    18b0:      	pand	%xmm6, %xmm11
    18b5:      	packuswb	%xmm11, %xmm10
    18ba:      	packuswb	%xmm10, %xmm8
    18bf:      	movdqu	%xmm8, (%rbx,%rcx)
    18c5:      	addq	$0x10, %rcx
    18c9:      	paddd	%xmm7, %xmm4
    18cd:      	paddd	%xmm7, %xmm3
    18d1:      	paddd	%xmm7, %xmm2
    18d5:      	paddd	%xmm7, %xmm1
    18d9:      	cmpq	%rcx, %rax
    18dc:      	jne	0x17f0 <packet_xor+0x2d0>
    18e2:      	cmpq	%rax, %r14
    18e5:      	je	0x199e <packet_xor+0x47e>
    18eb:      	testb	$0xc, %r14b
    18ef:      	je	0x1986 <packet_xor+0x466>
    18f5:      	movq	%rax, %rcx
    18f8:      	leaq	0xc(%r12), %rax
    18fd:      	andq	%r14, %rax
    1900:      	movd	%ecx, %xmm0
    1904:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1909:      	por	0x71f(%rip), %xmm0      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1911:      	movd	%r15d, %xmm1
    1916:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    191b:      	movdqa	0x74d(%rip), %xmm2      # 0x2070 <free@GLIBC_2.2.5+0x2070>
    1923:      	movdqa	0x715(%rip), %xmm3      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    192b:      	movdqa	0x72d(%rip), %xmm4      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    1933:      	nopw	%cs:(%rax,%rax)
    1940:      	movdqa	%xmm0, %xmm5
    1944:      	pmuludq	%xmm2, %xmm5
    1948:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    194d:      	pshufd	$0xf5, %xmm0, %xmm6     # xmm6 = xmm0[1,1,3,3]
    1952:      	pmuludq	%xmm2, %xmm6
    1956:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    195b:      	punpckldq	%xmm6, %xmm5    # xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1]
    195f:      	paddd	%xmm1, %xmm5
    1963:      	pand	%xmm3, %xmm5
    1967:      	packuswb	%xmm5, %xmm5
    196b:      	packuswb	%xmm5, %xmm5
    196f:      	movd	%xmm5, (%rbx,%rcx)
    1974:      	addq	$0x4, %rcx
    1978:      	paddd	%xmm4, %xmm0
    197c:      	cmpq	%rcx, %rax
    197f:      	jne	0x1940 <packet_xor+0x420>
    1981:      	cmpq	%rax, %r14
    1984:      	je	0x199e <packet_xor+0x47e>
    1986:      	leal	(%rax,%rax,2), %ecx
    1989:      	leal	(%rax,%rcx,4), %ecx
    198c:      	addl	%r15d, %ecx
    198f:      	nop
    1990:      	movb	%cl, (%rbx,%rax)
    1993:      	incq	%rax
    1996:      	addb	$0xd, %cl
    1999:      	cmpq	%rax, %r14
    199c:      	jne	0x1990 <packet_xor+0x470>
    199e:      	movl	$0x1, %edi
    19a3:      	movq	%r14, %rsi
    19a6:      	callq	0x1050 <calloc@plt>
    19ab:      	testq	%rax, %rax
    19ae:      	je	0x19c1 <packet_xor+0x4a1>
    19b0:      	xorl	$0x5a, %r15d
    19b4:      	cmpq	$0x3, %r14
    19b8:      	ja	0x19cc <packet_xor+0x4ac>
    19ba:      	xorl	%ecx, %ecx
    19bc:      	jmp	0x1da4 <packet_xor+0x884>
    19c1:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    19c7:      	jmp	0x1e67 <packet_xor+0x947>
    19cc:      	movd	%r15d, %xmm0
    19d1:      	cmpq	$0x10, %r14
    19d5:      	jae	0x1c6f <packet_xor+0x74f>
    19db:      	xorl	%ecx, %ecx
    19dd:      	jmp	0x1d34 <packet_xor+0x814>
    19e2:      	movq	%rax, %rcx
    19e5:      	leal	(%rcx,%rcx,2), %eax
    19e8:      	leal	(%rcx,%rax,4), %eax
    19eb:      	addl	%r15d, %eax
    19ee:      	nop
    19f0:      	movb	%al, (%rbx,%rcx)
    19f3:      	incq	%rcx
    19f6:      	addb	$0xd, %al
    19f8:      	cmpq	%rcx, %r14
    19fb:      	jne	0x19f0 <packet_xor+0x4d0>
    19fd:      	testq	%r14, %r14
    1a00:      	js	0x1a18 <packet_xor+0x4f8>
    1a02:      	movl	$0x1, %edi
    1a07:      	movq	%r14, %rsi
    1a0a:      	callq	0x1050 <calloc@plt>
    1a0f:      	testq	%rax, %rax
    1a12:      	je	0x1a35 <packet_xor+0x515>
    1a14:      	movb	$0x1, %cl
    1a16:      	jmp	0x1a39 <packet_xor+0x519>
    1a18:      	xorl	%eax, %eax
    1a1a:      	xorl	%ecx, %ecx
    1a1c:      	testb	$0x1, %cl
    1a1f:      	jne	0x1a50 <packet_xor+0x530>
    1a21:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1a27:      	testq	%rax, %rax
    1a2a:      	jne	0x1e5f <packet_xor+0x93f>
    1a30:      	jmp	0x1e67 <packet_xor+0x947>
    1a35:      	xorl	%eax, %eax
    1a37:      	xorl	%ecx, %ecx
    1a39:      	movdqa	0x5fe(%rip), %xmm11     # 0x2040 <free@GLIBC_2.2.5+0x2040>
    1a42:      	movdqa	0x605(%rip), %xmm12     # 0x2050 <free@GLIBC_2.2.5+0x2050>
    1a4b:      	testb	$0x1, %cl
    1a4e:      	je	0x1a21 <packet_xor+0x501>
    1a50:      	xorl	$0x5a, %r15d
    1a54:      	movq	%rax, %rcx
    1a57:      	subq	%rbx, %rcx
    1a5a:      	cmpq	$0xf, %rcx
    1a5e:      	ja	0x1b14 <packet_xor+0x5f4>
    1a64:      	xorl	%edx, %edx
    1a66:      	movq	%r14, %rsi
    1a69:      	movq	%rdx, %rcx
    1a6c:      	andq	$0x3, %rsi
    1a70:      	je	0x1a97 <packet_xor+0x577>
    1a72:      	leal	(%r15,%rdx), %edi
    1a76:      	movq	%rdx, %rcx
    1a79:      	nopl	(%rax)
    1a80:      	movzbl	(%rbx,%rcx), %r8d
    1a85:      	xorb	%dil, %r8b
    1a88:      	movb	%r8b, (%rax,%rcx)
    1a8c:      	incq	%rcx
    1a8f:      	incb	%dil
    1a92:      	decq	%rsi
    1a95:      	jne	0x1a80 <packet_xor+0x560>
    1a97:      	subq	%r14, %rdx
    1a9a:      	cmpq	$-0x4, %rdx
    1a9e:      	ja	0x1c39 <packet_xor+0x719>
    1aa4:      	movq	%rax, %rdx
    1aa7:      	addq	$0x3, %rdx
    1aab:      	movl	%r15d, %esi
    1aae:      	leaq	0x3(%rbx), %rdi
    1ab2:      	movq	%r14, %r8
    1ab5:      	nopw	%cs:(%rax,%rax)
    1ac0:      	leal	(%rcx,%rsi), %r9d
    1ac4:      	movzbl	-0x3(%rdi,%rcx), %r10d
    1aca:      	xorb	%r9b, %r10b
    1acd:      	movb	%r10b, -0x3(%rdx,%rcx)
    1ad2:      	leal	0x1(%r9), %r10d
    1ad6:      	xorb	-0x2(%rdi,%rcx), %r10b
    1adb:      	movb	%r10b, -0x2(%rdx,%rcx)
    1ae0:      	leal	0x2(%r9), %r10d
    1ae4:      	xorb	-0x1(%rdi,%rcx), %r10b
    1ae9:      	movb	%r10b, -0x1(%rdx,%rcx)
    1aee:      	addb	$0x3, %r9b
    1af2:      	xorb	(%rdi,%rcx), %r9b
    1af6:      	movb	%r9b, (%rdx,%rcx)
    1afa:      	addq	$-0x4, %r8
    1afe:      	addq	$0x4, %rdx
    1b02:      	addq	$0x4, %rsi
    1b06:      	addq	$0x4, %rdi
    1b0a:      	cmpq	%r8, %rcx
    1b0d:      	jne	0x1ac0 <packet_xor+0x5a0>
    1b0f:      	jmp	0x1c39 <packet_xor+0x719>
    1b14:      	movq	%r14, %rcx
    1b17:      	andq	$-0x10, %rcx
    1b1b:      	movd	%r15d, %xmm0
    1b20:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1b25:      	movdqa	0x4d3(%rip), %xmm1      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    1b2d:      	movdqa	0x4db(%rip), %xmm2      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    1b35:      	movdqa	0x4e3(%rip), %xmm3      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    1b3d:      	movdqa	0x4eb(%rip), %xmm4      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1b45:      	xorl	%edx, %edx
    1b47:      	nopw	(%rax,%rax)
    1b50:      	movdqu	(%rbx,%rdx), %xmm5
    1b55:      	movdqa	%xmm0, %xmm6
    1b59:      	paddd	%xmm1, %xmm6
    1b5d:      	movdqa	%xmm0, %xmm7
    1b61:      	paddd	%xmm2, %xmm7
    1b65:      	movdqa	%xmm0, %xmm8
    1b6a:      	paddd	%xmm3, %xmm8
    1b6f:      	movdqa	%xmm0, %xmm9
    1b74:      	paddd	%xmm4, %xmm9
    1b79:      	pand	%xmm11, %xmm9
    1b7e:      	pand	%xmm11, %xmm8
    1b83:      	packuswb	%xmm8, %xmm9
    1b88:      	pand	%xmm11, %xmm7
    1b8d:      	pand	%xmm11, %xmm6
    1b92:      	packuswb	%xmm6, %xmm7
    1b96:      	packuswb	%xmm7, %xmm9
    1b9b:      	pxor	%xmm5, %xmm9
    1ba0:      	movdqu	%xmm9, (%rax,%rdx)
    1ba6:      	addq	$0x10, %rdx
    1baa:      	paddd	%xmm12, %xmm4
    1baf:      	paddd	%xmm12, %xmm3
    1bb4:      	paddd	%xmm12, %xmm2
    1bb9:      	paddd	%xmm12, %xmm1
    1bbe:      	cmpq	%rdx, %rcx
    1bc1:      	jne	0x1b50 <packet_xor+0x630>
    1bc3:      	cmpq	%rcx, %r14
    1bc6:      	je	0x1c39 <packet_xor+0x719>
    1bc8:      	testb	$0xc, %r14b
    1bcc:      	je	0x1e7e <packet_xor+0x95e>
    1bd2:      	movq	%r14, %rdx
    1bd5:      	andq	$-0x4, %rdx
    1bd9:      	movd	%ecx, %xmm1
    1bdd:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1be2:      	por	0x446(%rip), %xmm1      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1bea:      	movdqa	0x46e(%rip), %xmm2      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    1bf2:      	nopw	%cs:(%rax,%rax)
    1c00:      	movd	(%rbx,%rcx), %xmm3
    1c05:      	movdqa	%xmm0, %xmm4
    1c09:      	paddd	%xmm1, %xmm4
    1c0d:      	pand	%xmm11, %xmm4
    1c12:      	packuswb	%xmm4, %xmm4
    1c16:      	packuswb	%xmm4, %xmm4
    1c1a:      	pxor	%xmm3, %xmm4
    1c1e:      	movd	%xmm4, (%rax,%rcx)
    1c23:      	addq	$0x4, %rcx
    1c27:      	paddd	%xmm2, %xmm1
    1c2b:      	cmpq	%rcx, %rdx
    1c2e:      	jne	0x1c00 <packet_xor+0x6e0>
    1c30:      	cmpq	%rdx, %r14
    1c33:      	jne	0x1a66 <packet_xor+0x546>
    1c39:      	xorl	%ecx, %ecx
    1c3b:      	xorl	%r15d, %r15d
    1c3e:      	nop
    1c40:      	movq	%r15, %rdx
    1c43:      	movzbl	(%rax,%rcx), %r15d
    1c48:      	addq	%rdx, %r15
    1c4b:      	jb	0x1e86 <packet_xor+0x966>
    1c51:      	incq	%rcx
    1c54:      	cmpq	%rcx, %r14
    1c57:      	jne	0x1c40 <packet_xor+0x720>
    1c59:      	movq	%rax, %rdi
    1c5c:      	callq	0x1030 <free@plt>
    1c61:      	testq	%rbx, %rbx
    1c64:      	jne	0x1e67 <packet_xor+0x947>
    1c6a:      	jmp	0x1e6f <packet_xor+0x94f>
    1c6f:      	movq	%r14, %rcx
    1c72:      	andq	%r12, %rcx
    1c75:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1c7a:      	movdqa	0x37e(%rip), %xmm2      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    1c82:      	movdqa	0x386(%rip), %xmm3      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    1c8a:      	movdqa	0x38e(%rip), %xmm4      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    1c92:      	movdqa	0x396(%rip), %xmm5      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1c9a:      	xorl	%edx, %edx
    1c9c:      	movdqa	0x39c(%rip), %xmm6      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    1ca4:      	movdqa	0x3a4(%rip), %xmm7      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    1cac:      	nopl	(%rax)
    1cb0:      	movdqu	(%rbx,%rdx), %xmm8
    1cb6:      	movdqa	%xmm1, %xmm9
    1cbb:      	paddd	%xmm2, %xmm9
    1cc0:      	movdqa	%xmm1, %xmm10
    1cc5:      	paddd	%xmm3, %xmm10
    1cca:      	movdqa	%xmm1, %xmm11
    1ccf:      	paddd	%xmm4, %xmm11
    1cd4:      	movdqa	%xmm1, %xmm12
    1cd9:      	paddd	%xmm5, %xmm12
    1cde:      	pand	%xmm6, %xmm12
    1ce3:      	pand	%xmm6, %xmm11
    1ce8:      	packuswb	%xmm11, %xmm12
    1ced:      	pand	%xmm6, %xmm10
    1cf2:      	pand	%xmm6, %xmm9
    1cf7:      	packuswb	%xmm9, %xmm10
    1cfc:      	packuswb	%xmm10, %xmm12
    1d01:      	pxor	%xmm8, %xmm12
    1d06:      	movdqu	%xmm12, (%rax,%rdx)
    1d0c:      	addq	$0x10, %rdx
    1d10:      	paddd	%xmm7, %xmm5
    1d14:      	paddd	%xmm7, %xmm4
    1d18:      	paddd	%xmm7, %xmm3
    1d1c:      	paddd	%xmm7, %xmm2
    1d20:      	cmpq	%rdx, %rcx
    1d23:      	jne	0x1cb0 <packet_xor+0x790>
    1d25:      	cmpq	%rcx, %r14
    1d28:      	je	0x1dc3 <packet_xor+0x8a3>
    1d2e:      	testb	$0xc, %r14b
    1d32:      	je	0x1da4 <packet_xor+0x884>
    1d34:      	movq	%rcx, %rdx
    1d37:      	leaq	0xc(%r12), %rcx
    1d3c:      	movd	%edx, %xmm1
    1d40:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1d45:      	por	0x2e3(%rip), %xmm1      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    1d4d:      	andq	%r14, %rcx
    1d50:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1d55:      	movdqa	0x2e3(%rip), %xmm2      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    1d5d:      	movdqa	0x2fb(%rip), %xmm3      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    1d65:      	nopw	%cs:(%rax,%rax)
    1d70:      	movd	(%rbx,%rdx), %xmm4
    1d75:      	movdqa	%xmm0, %xmm5
    1d79:      	paddd	%xmm1, %xmm5
    1d7d:      	pand	%xmm2, %xmm5
    1d81:      	packuswb	%xmm5, %xmm5
    1d85:      	packuswb	%xmm5, %xmm5
    1d89:      	pxor	%xmm4, %xmm5
    1d8d:      	movd	%xmm5, (%rax,%rdx)
    1d92:      	addq	$0x4, %rdx
    1d96:      	paddd	%xmm3, %xmm1
    1d9a:      	cmpq	%rdx, %rcx
    1d9d:      	jne	0x1d70 <packet_xor+0x850>
    1d9f:      	cmpq	%rcx, %r14
    1da2:      	je	0x1dc3 <packet_xor+0x8a3>
    1da4:      	movl	%r15d, %edx
    1da7:      	nopw	(%rax,%rax)
    1db0:      	leal	(%rdx,%rcx), %esi
    1db3:      	xorb	(%rbx,%rcx), %sil
    1db7:      	movb	%sil, (%rax,%rcx)
    1dbb:      	incq	%rcx
    1dbe:      	cmpq	%rcx, %r14
    1dc1:      	jne	0x1db0 <packet_xor+0x890>
    1dc3:      	leaq	-0x1(%r14), %rdx
    1dc7:      	movl	%r14d, %ecx
    1dca:      	andl	$0x7, %ecx
    1dcd:      	cmpq	$0x7, %rdx
    1dd1:      	jae	0x1dda <packet_xor+0x8ba>
    1dd3:      	xorl	%edx, %edx
    1dd5:      	xorl	%r15d, %r15d
    1dd8:      	jmp	0x1e3a <packet_xor+0x91a>
    1dda:      	addq	$0x8, %r12
    1dde:      	andq	%r12, %r14
    1de1:      	xorl	%edx, %edx
    1de3:      	xorl	%r15d, %r15d
    1de6:      	nopw	%cs:(%rax,%rax)
    1df0:      	movzbl	(%rax,%rdx), %esi
    1df4:      	addq	%r15, %rsi
    1df7:      	movzbl	0x1(%rax,%rdx), %edi
    1dfc:      	movzbl	0x2(%rax,%rdx), %r8d
    1e02:      	addq	%rdi, %r8
    1e05:      	addq	%rsi, %r8
    1e08:      	movzbl	0x3(%rax,%rdx), %esi
    1e0d:      	movzbl	0x4(%rax,%rdx), %edi
    1e12:      	addq	%rsi, %rdi
    1e15:      	movzbl	0x5(%rax,%rdx), %esi
    1e1a:      	addq	%rdi, %rsi
    1e1d:      	addq	%r8, %rsi
    1e20:      	movzbl	0x6(%rax,%rdx), %edi
    1e25:      	movzbl	0x7(%rax,%rdx), %r15d
    1e2b:      	addq	%rdi, %r15
    1e2e:      	addq	%rsi, %r15
    1e31:      	addq	$0x8, %rdx
    1e35:      	cmpq	%rdx, %r14
    1e38:      	jne	0x1df0 <packet_xor+0x8d0>
    1e3a:      	testq	%rcx, %rcx
    1e3d:      	je	0x1e5f <packet_xor+0x93f>
    1e3f:      	movq	%rax, %rsi
    1e42:      	addq	%rdx, %rsi
    1e45:      	xorl	%edx, %edx
    1e47:      	nopw	(%rax,%rax)
    1e50:      	movzbl	(%rsi,%rdx), %edi
    1e54:      	addq	%rdi, %r15
    1e57:      	incq	%rdx
    1e5a:      	cmpq	%rdx, %rcx
    1e5d:      	jne	0x1e50 <packet_xor+0x930>
    1e5f:      	movq	%rax, %rdi
    1e62:      	callq	0x1030 <free@plt>
    1e67:      	movq	%rbx, %rdi
    1e6a:      	callq	0x1030 <free@plt>
    1e6f:      	movq	%r15, %rax
    1e72:      	addq	$0x8, %rsp
    1e76:      	popq	%rbx
    1e77:      	popq	%r12
    1e79:      	popq	%r14
    1e7b:      	popq	%r15
    1e7d:      	retq
    1e7e:      	movq	%rcx, %rdx
    1e81:      	jmp	0x1a66 <packet_xor+0x546>
    1e86:      	callq	0x1040 <abort@plt>

Disassembly of section .fini:

0000000000001e8c <_fini>:
    1e8c:      	endbr64
    1e90:      	subq	$0x8, %rsp
    1e94:      	addq	$0x8, %rsp
    1e98:      	retq
