
/tmp/hepta-next-20261028-bench-final-01/c_o3_lto.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000001670 <deregister_tm_clones>:
    1670:      	leaq	0x29a1(%rip), %rdi      # 0x4018 <_GLOBAL_OFFSET_TABLE_>
    1677:      	leaq	0x299a(%rip), %rax      # 0x4018 <_GLOBAL_OFFSET_TABLE_>
    167e:      	cmpq	%rdi, %rax
    1681:      	je	0x1698 <deregister_tm_clones+0x28>
    1683:      	movq	0x196e(%rip), %rax      # 0x2ff8 <free+0x2ff8>
    168a:      	testq	%rax, %rax
    168d:      	je	0x1698 <deregister_tm_clones+0x28>
    168f:      	jmpq	*%rax
    1691:      	nopl	(%rax)
    1698:      	retq
    1699:      	nopl	(%rax)

00000000000016a0 <register_tm_clones>:
    16a0:      	leaq	0x2971(%rip), %rdi      # 0x4018 <_GLOBAL_OFFSET_TABLE_>
    16a7:      	leaq	0x296a(%rip), %rsi      # 0x4018 <_GLOBAL_OFFSET_TABLE_>
    16ae:      	subq	%rdi, %rsi
    16b1:      	movq	%rsi, %rax
    16b4:      	shrq	$0x3f, %rsi
    16b8:      	sarq	$0x3, %rax
    16bc:      	addq	%rax, %rsi
    16bf:      	sarq	%rsi
    16c2:      	je	0x16d8 <register_tm_clones+0x38>
    16c4:      	movq	0x1935(%rip), %rax      # 0x3000 <free+0x3000>
    16cb:      	testq	%rax, %rax
    16ce:      	je	0x16d8 <register_tm_clones+0x38>
    16d0:      	jmpq	*%rax
    16d2:      	nopw	(%rax,%rax)
    16d8:      	retq
    16d9:      	nopl	(%rax)

00000000000016e0 <__do_global_dtors_aux>:
    16e0:      	endbr64
    16e4:      	cmpb	$0x0, 0x295d(%rip)      # 0x4048 <completed.0>
    16eb:      	jne	0x1718 <__do_global_dtors_aux+0x38>
    16ed:      	pushq	%rbp
    16ee:      	cmpq	$0x0, 0x1912(%rip)      # 0x3008 <free+0x3008>
    16f6:      	movq	%rsp, %rbp
    16f9:      	je	0x1707 <__do_global_dtors_aux+0x27>
    16fb:      	movq	0x290e(%rip), %rdi      # 0x4010 <__dso_handle>
    1702:      	callq	0x1e30 <__cxa_finalize@plt>
    1707:      	callq	0x1670 <deregister_tm_clones>
    170c:      	movb	$0x1, 0x2935(%rip)      # 0x4048 <completed.0>
    1713:      	popq	%rbp
    1714:      	retq
    1715:      	nopl	(%rax)
    1718:      	retq
    1719:      	nopl	(%rax)

0000000000001720 <frame_dummy>:
    1720:      	endbr64
    1724:      	jmp	0x16a0 <register_tm_clones>
    1729:      	int3
    172a:      	int3
    172b:      	int3
    172c:      	int3
    172d:      	int3
    172e:      	int3
    172f:      	int3

0000000000001730 <full_lifecycle>:
    1730:      	pushq	%rbp
    1731:      	pushq	%r14
    1733:      	pushq	%rbx
    1734:      	testq	%rdi, %rdi
    1737:      	je	0x175a <full_lifecycle+0x2a>
    1739:      	movl	%esi, %ebp
    173b:      	movq	%rdi, %rbx
    173e:      	movl	$0x1, %esi
    1743:      	callq	0x1e40 <calloc@plt>
    1748:      	testq	%rax, %rax
    174b:      	je	0x1762 <full_lifecycle+0x32>
    174d:      	cmpq	$0x4, %rbx
    1751:      	jae	0x176d <full_lifecycle+0x3d>
    1753:      	xorl	%ecx, %ecx
    1755:      	jmp	0x189b <full_lifecycle+0x16b>
    175a:      	xorl	%r14d, %r14d
    175d:      	jmp	0x1947 <full_lifecycle+0x217>
    1762:      	movl	$0x3e9, %r14d           # imm = 0x3E9
    1768:      	jmp	0x1947 <full_lifecycle+0x217>
    176d:      	movd	%ebp, %xmm0
    1771:      	cmpq	$0x10, %rbx
    1775:      	jae	0x177e <full_lifecycle+0x4e>
    1777:      	xorl	%ecx, %ecx
    1779:      	jmp	0x183e <full_lifecycle+0x10e>
    177e:      	movq	%rbx, %rcx
    1781:      	andq	$-0x10, %rcx
    1785:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    178a:      	movdqa	-0x1242(%rip), %xmm2    # 0x550 <free+0x550>
    1792:      	movdqa	-0x123a(%rip), %xmm3    # 0x560 <free+0x560>
    179a:      	movdqa	-0x1232(%rip), %xmm4    # 0x570 <free+0x570>
    17a2:      	movdqa	-0x122a(%rip), %xmm5    # 0x580 <free+0x580>
    17aa:      	xorl	%edx, %edx
    17ac:      	movdqa	-0x11f4(%rip), %xmm6    # 0x5c0 <free+0x5c0>
    17b4:      	movdqa	-0x120c(%rip), %xmm7    # 0x5b0 <free+0x5b0>
    17bc:      	nopl	(%rax)
    17c0:      	movdqa	%xmm1, %xmm8
    17c5:      	paddd	%xmm2, %xmm8
    17ca:      	movdqa	%xmm1, %xmm9
    17cf:      	paddd	%xmm3, %xmm9
    17d4:      	movdqa	%xmm1, %xmm10
    17d9:      	paddd	%xmm4, %xmm10
    17de:      	movdqa	%xmm1, %xmm11
    17e3:      	paddd	%xmm5, %xmm11
    17e8:      	pand	%xmm6, %xmm11
    17ed:      	pand	%xmm6, %xmm10
    17f2:      	packuswb	%xmm10, %xmm11
    17f7:      	pand	%xmm6, %xmm9
    17fc:      	pand	%xmm6, %xmm8
    1801:      	packuswb	%xmm8, %xmm9
    1806:      	packuswb	%xmm9, %xmm11
    180b:      	movdqu	%xmm11, (%rax,%rdx)
    1811:      	addq	$0x10, %rdx
    1815:      	paddd	%xmm7, %xmm5
    1819:      	paddd	%xmm7, %xmm4
    181d:      	paddd	%xmm7, %xmm3
    1821:      	paddd	%xmm7, %xmm2
    1825:      	cmpq	%rdx, %rcx
    1828:      	jne	0x17c0 <full_lifecycle+0x90>
    182a:      	cmpq	%rcx, %rbx
    182d:      	jne	0x1839 <full_lifecycle+0x109>
    182f:      	movl	%ebx, %ecx
    1831:      	andl	$0x7, %ecx
    1834:      	jmp	0x18c1 <full_lifecycle+0x191>
    1839:      	testb	$0xc, %bl
    183c:      	je	0x189b <full_lifecycle+0x16b>
    183e:      	movq	%rcx, %rdx
    1841:      	movq	%rbx, %rcx
    1844:      	movd	%edx, %xmm1
    1848:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    184d:      	por	-0x12d5(%rip), %xmm1    # 0x580 <free+0x580>
    1855:      	andq	$-0x4, %rcx
    1859:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    185e:      	movdqa	-0x12a6(%rip), %xmm2    # 0x5c0 <free+0x5c0>
    1866:      	movdqa	-0x12de(%rip), %xmm3    # 0x590 <free+0x590>
    186e:      	nop
    1870:      	movdqa	%xmm0, %xmm4
    1874:      	paddd	%xmm1, %xmm4
    1878:      	pand	%xmm2, %xmm4
    187c:      	packuswb	%xmm4, %xmm4
    1880:      	packuswb	%xmm4, %xmm4
    1884:      	movd	%xmm4, (%rax,%rdx)
    1889:      	addq	$0x4, %rdx
    188d:      	paddd	%xmm3, %xmm1
    1891:      	cmpq	%rdx, %rcx
    1894:      	jne	0x1870 <full_lifecycle+0x140>
    1896:      	cmpq	%rcx, %rbx
    1899:      	je	0x18af <full_lifecycle+0x17f>
    189b:      	movl	%ebp, %edx
    189d:      	nopl	(%rax)
    18a0:      	leal	(%rdx,%rcx), %esi
    18a3:      	movb	%sil, (%rax,%rcx)
    18a7:      	incq	%rcx
    18aa:      	cmpq	%rcx, %rbx
    18ad:      	jne	0x18a0 <full_lifecycle+0x170>
    18af:      	movl	%ebx, %ecx
    18b1:      	andl	$0x7, %ecx
    18b4:      	cmpq	$0x8, %rbx
    18b8:      	jae	0x18c1 <full_lifecycle+0x191>
    18ba:      	xorl	%edx, %edx
    18bc:      	xorl	%r14d, %r14d
    18bf:      	jmp	0x191a <full_lifecycle+0x1ea>
    18c1:      	andq	$-0x8, %rbx
    18c5:      	xorl	%edx, %edx
    18c7:      	xorl	%r14d, %r14d
    18ca:      	nopw	(%rax,%rax)
    18d0:      	movzbl	(%rax,%rdx), %esi
    18d4:      	addq	%r14, %rsi
    18d7:      	movzbl	0x1(%rax,%rdx), %edi
    18dc:      	movzbl	0x2(%rax,%rdx), %r8d
    18e2:      	addq	%rdi, %r8
    18e5:      	addq	%rsi, %r8
    18e8:      	movzbl	0x3(%rax,%rdx), %esi
    18ed:      	movzbl	0x4(%rax,%rdx), %edi
    18f2:      	addq	%rsi, %rdi
    18f5:      	movzbl	0x5(%rax,%rdx), %esi
    18fa:      	addq	%rdi, %rsi
    18fd:      	addq	%r8, %rsi
    1900:      	movzbl	0x6(%rax,%rdx), %edi
    1905:      	movzbl	0x7(%rax,%rdx), %r14d
    190b:      	addq	%rdi, %r14
    190e:      	addq	%rsi, %r14
    1911:      	addq	$0x8, %rdx
    1915:      	cmpq	%rdx, %rbx
    1918:      	jne	0x18d0 <full_lifecycle+0x1a0>
    191a:      	testq	%rcx, %rcx
    191d:      	je	0x193f <full_lifecycle+0x20f>
    191f:      	movq	%rax, %rsi
    1922:      	addq	%rdx, %rsi
    1925:      	xorl	%edx, %edx
    1927:      	nopw	(%rax,%rax)
    1930:      	movzbl	(%rsi,%rdx), %edi
    1934:      	addq	%rdi, %r14
    1937:      	incq	%rdx
    193a:      	cmpq	%rdx, %rcx
    193d:      	jne	0x1930 <full_lifecycle+0x200>
    193f:      	movq	%rax, %rdi
    1942:      	callq	0x1e50 <free@plt>
    1947:      	movq	%r14, %rax
    194a:      	popq	%rbx
    194b:      	popq	%r14
    194d:      	popq	%rbp
    194e:      	retq
    194f:      	int3

0000000000001950 <packet_xor>:
    1950:      	pushq	%r15
    1952:      	pushq	%r14
    1954:      	pushq	%rbx
    1955:      	testq	%rdi, %rdi
    1958:      	je	0x197f <packet_xor+0x2f>
    195a:      	movl	%esi, %r15d
    195d:      	movq	%rdi, %r14
    1960:      	movl	$0x1, %esi
    1965:      	callq	0x1e40 <calloc@plt>
    196a:      	testq	%rax, %rax
    196d:      	je	0x1987 <packet_xor+0x37>
    196f:      	movq	%rax, %rbx
    1972:      	cmpq	$0x3, %r14
    1976:      	ja	0x1992 <packet_xor+0x42>
    1978:      	xorl	%eax, %eax
    197a:      	jmp	0x1b86 <packet_xor+0x236>
    197f:      	xorl	%r15d, %r15d
    1982:      	jmp	0x1ddf <packet_xor+0x48f>
    1987:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    198d:      	jmp	0x1ddf <packet_xor+0x48f>
    1992:      	movd	%r15d, %xmm0
    1997:      	cmpq	$0x10, %r14
    199b:      	jae	0x19a4 <packet_xor+0x54>
    199d:      	xorl	%eax, %eax
    199f:      	jmp	0x1af9 <packet_xor+0x1a9>
    19a4:      	movq	%r14, %rax
    19a7:      	andq	$-0x10, %rax
    19ab:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    19b0:      	movdqa	-0x1468(%rip), %xmm2    # 0x550 <free+0x550>
    19b8:      	movdqa	-0x1460(%rip), %xmm3    # 0x560 <free+0x560>
    19c0:      	movdqa	-0x1458(%rip), %xmm4    # 0x570 <free+0x570>
    19c8:      	movdqa	-0x1450(%rip), %xmm5    # 0x580 <free+0x580>
    19d0:      	xorl	%ecx, %ecx
    19d2:      	movdqa	-0x143a(%rip), %xmm6    # 0x5a0 <free+0x5a0>
    19da:      	movdqa	-0x1422(%rip), %xmm7    # 0x5c0 <free+0x5c0>
    19e2:      	movdqa	-0x143b(%rip), %xmm8    # 0x5b0 <free+0x5b0>
    19eb:      	nopl	(%rax,%rax)
    19f0:      	movdqa	%xmm5, %xmm9
    19f5:      	pmuludq	%xmm6, %xmm9
    19fa:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    1a00:      	pshufd	$0xf5, %xmm5, %xmm10    # xmm10 = xmm5[1,1,3,3]
    1a06:      	pmuludq	%xmm6, %xmm10
    1a0b:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1a11:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    1a16:      	movdqa	%xmm4, %xmm10
    1a1b:      	pmuludq	%xmm6, %xmm10
    1a20:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1a26:      	pshufd	$0xf5, %xmm4, %xmm11    # xmm11 = xmm4[1,1,3,3]
    1a2c:      	pmuludq	%xmm6, %xmm11
    1a31:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1a37:      	punpckldq	%xmm11, %xmm10  # xmm10 = xmm10[0],xmm11[0],xmm10[1],xmm11[1]
    1a3c:      	movdqa	%xmm3, %xmm11
    1a41:      	pmuludq	%xmm6, %xmm11
    1a46:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1a4c:      	pshufd	$0xf5, %xmm3, %xmm12    # xmm12 = xmm3[1,1,3,3]
    1a52:      	pmuludq	%xmm6, %xmm12
    1a57:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1a5d:      	punpckldq	%xmm12, %xmm11  # xmm11 = xmm11[0],xmm12[0],xmm11[1],xmm12[1]
    1a62:      	movdqa	%xmm2, %xmm12
    1a67:      	pmuludq	%xmm6, %xmm12
    1a6c:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1a72:      	pshufd	$0xf5, %xmm2, %xmm13    # xmm13 = xmm2[1,1,3,3]
    1a78:      	pmuludq	%xmm6, %xmm13
    1a7d:      	pshufd	$0xe8, %xmm13, %xmm13   # xmm13 = xmm13[0,2,2,3]
    1a83:      	punpckldq	%xmm13, %xmm12  # xmm12 = xmm12[0],xmm13[0],xmm12[1],xmm13[1]
    1a88:      	paddd	%xmm1, %xmm12
    1a8d:      	paddd	%xmm1, %xmm11
    1a92:      	paddd	%xmm1, %xmm10
    1a97:      	paddd	%xmm1, %xmm9
    1a9c:      	pand	%xmm7, %xmm9
    1aa1:      	pand	%xmm7, %xmm10
    1aa6:      	packuswb	%xmm10, %xmm9
    1aab:      	pand	%xmm7, %xmm11
    1ab0:      	pand	%xmm7, %xmm12
    1ab5:      	packuswb	%xmm12, %xmm11
    1aba:      	packuswb	%xmm11, %xmm9
    1abf:      	movdqu	%xmm9, (%rbx,%rcx)
    1ac5:      	addq	$0x10, %rcx
    1ac9:      	paddd	%xmm8, %xmm5
    1ace:      	paddd	%xmm8, %xmm4
    1ad3:      	paddd	%xmm8, %xmm3
    1ad8:      	paddd	%xmm8, %xmm2
    1add:      	cmpq	%rcx, %rax
    1ae0:      	jne	0x19f0 <packet_xor+0xa0>
    1ae6:      	cmpq	%rax, %r14
    1ae9:      	je	0x1b9e <packet_xor+0x24e>
    1aef:      	testb	$0xc, %r14b
    1af3:      	je	0x1b86 <packet_xor+0x236>
    1af9:      	movq	%rax, %rcx
    1afc:      	movq	%r14, %rax
    1aff:      	andq	$-0x4, %rax
    1b03:      	movd	%ecx, %xmm1
    1b07:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1b0c:      	por	-0x1594(%rip), %xmm1    # 0x580 <free+0x580>
    1b14:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1b19:      	movdqa	-0x1581(%rip), %xmm2    # 0x5a0 <free+0x5a0>
    1b21:      	movdqa	-0x1569(%rip), %xmm3    # 0x5c0 <free+0x5c0>
    1b29:      	movdqa	-0x15a1(%rip), %xmm4    # 0x590 <free+0x590>
    1b31:      	nopw	%cs:(%rax,%rax)
    1b40:      	movdqa	%xmm1, %xmm5
    1b44:      	pmuludq	%xmm2, %xmm5
    1b48:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    1b4d:      	pshufd	$0xf5, %xmm1, %xmm6     # xmm6 = xmm1[1,1,3,3]
    1b52:      	pmuludq	%xmm2, %xmm6
    1b56:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    1b5b:      	punpckldq	%xmm6, %xmm5    # xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1]
    1b5f:      	paddd	%xmm0, %xmm5
    1b63:      	pand	%xmm3, %xmm5
    1b67:      	packuswb	%xmm5, %xmm5
    1b6b:      	packuswb	%xmm5, %xmm5
    1b6f:      	movd	%xmm5, (%rbx,%rcx)
    1b74:      	addq	$0x4, %rcx
    1b78:      	paddd	%xmm4, %xmm1
    1b7c:      	cmpq	%rcx, %rax
    1b7f:      	jne	0x1b40 <packet_xor+0x1f0>
    1b81:      	cmpq	%rax, %r14
    1b84:      	je	0x1b9e <packet_xor+0x24e>
    1b86:      	leal	(%rax,%rax,2), %ecx
    1b89:      	leal	(%rax,%rcx,4), %ecx
    1b8c:      	addl	%r15d, %ecx
    1b8f:      	nop
    1b90:      	movb	%cl, (%rbx,%rax)
    1b93:      	incq	%rax
    1b96:      	addb	$0xd, %cl
    1b99:      	cmpq	%rax, %r14
    1b9c:      	jne	0x1b90 <packet_xor+0x240>
    1b9e:      	movl	$0x1, %esi
    1ba3:      	movq	%r14, %rdi
    1ba6:      	callq	0x1e40 <calloc@plt>
    1bab:      	testq	%rax, %rax
    1bae:      	je	0x1bc1 <packet_xor+0x271>
    1bb0:      	xorl	$0x5a, %r15d
    1bb4:      	cmpq	$0x3, %r14
    1bb8:      	ja	0x1bcc <packet_xor+0x27c>
    1bba:      	xorl	%ecx, %ecx
    1bbc:      	jmp	0x1d14 <packet_xor+0x3c4>
    1bc1:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1bc7:      	jmp	0x1dd7 <packet_xor+0x487>
    1bcc:      	movd	%r15d, %xmm0
    1bd1:      	cmpq	$0x10, %r14
    1bd5:      	jae	0x1bde <packet_xor+0x28e>
    1bd7:      	xorl	%ecx, %ecx
    1bd9:      	jmp	0x1cab <packet_xor+0x35b>
    1bde:      	movq	%r14, %rcx
    1be1:      	andq	$-0x10, %rcx
    1be5:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    1bea:      	movdqa	-0x16a2(%rip), %xmm2    # 0x550 <free+0x550>
    1bf2:      	movdqa	-0x169a(%rip), %xmm3    # 0x560 <free+0x560>
    1bfa:      	movdqa	-0x1692(%rip), %xmm4    # 0x570 <free+0x570>
    1c02:      	movdqa	-0x168a(%rip), %xmm5    # 0x580 <free+0x580>
    1c0a:      	xorl	%edx, %edx
    1c0c:      	movdqa	-0x1654(%rip), %xmm6    # 0x5c0 <free+0x5c0>
    1c14:      	movdqa	-0x166c(%rip), %xmm7    # 0x5b0 <free+0x5b0>
    1c1c:      	nopl	(%rax)
    1c20:      	movdqu	(%rbx,%rdx), %xmm8
    1c26:      	movdqa	%xmm1, %xmm9
    1c2b:      	paddd	%xmm2, %xmm9
    1c30:      	movdqa	%xmm1, %xmm10
    1c35:      	paddd	%xmm3, %xmm10
    1c3a:      	movdqa	%xmm1, %xmm11
    1c3f:      	paddd	%xmm4, %xmm11
    1c44:      	movdqa	%xmm1, %xmm12
    1c49:      	paddd	%xmm5, %xmm12
    1c4e:      	pand	%xmm6, %xmm12
    1c53:      	pand	%xmm6, %xmm11
    1c58:      	packuswb	%xmm11, %xmm12
    1c5d:      	pand	%xmm6, %xmm10
    1c62:      	pand	%xmm6, %xmm9
    1c67:      	packuswb	%xmm9, %xmm10
    1c6c:      	packuswb	%xmm10, %xmm12
    1c71:      	pxor	%xmm8, %xmm12
    1c76:      	movdqu	%xmm12, (%rax,%rdx)
    1c7c:      	addq	$0x10, %rdx
    1c80:      	paddd	%xmm7, %xmm5
    1c84:      	paddd	%xmm7, %xmm4
    1c88:      	paddd	%xmm7, %xmm3
    1c8c:      	paddd	%xmm7, %xmm2
    1c90:      	cmpq	%rdx, %rcx
    1c93:      	jne	0x1c20 <packet_xor+0x2d0>
    1c95:      	cmpq	%rcx, %r14
    1c98:      	jne	0x1ca5 <packet_xor+0x355>
    1c9a:      	movl	%r14d, %ecx
    1c9d:      	andl	$0x7, %ecx
    1ca0:      	jmp	0x1d4a <packet_xor+0x3fa>
    1ca5:      	testb	$0xc, %r14b
    1ca9:      	je	0x1d14 <packet_xor+0x3c4>
    1cab:      	movq	%rcx, %rdx
    1cae:      	movq	%r14, %rcx
    1cb1:      	movd	%edx, %xmm1
    1cb5:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1cba:      	por	-0x1742(%rip), %xmm1    # 0x580 <free+0x580>
    1cc2:      	andq	$-0x4, %rcx
    1cc6:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1ccb:      	movdqa	-0x1713(%rip), %xmm2    # 0x5c0 <free+0x5c0>
    1cd3:      	movdqa	-0x174b(%rip), %xmm3    # 0x590 <free+0x590>
    1cdb:      	nopl	(%rax,%rax)
    1ce0:      	movd	(%rbx,%rdx), %xmm4
    1ce5:      	movdqa	%xmm0, %xmm5
    1ce9:      	paddd	%xmm1, %xmm5
    1ced:      	pand	%xmm2, %xmm5
    1cf1:      	packuswb	%xmm5, %xmm5
    1cf5:      	packuswb	%xmm5, %xmm5
    1cf9:      	pxor	%xmm4, %xmm5
    1cfd:      	movd	%xmm5, (%rax,%rdx)
    1d02:      	addq	$0x4, %rdx
    1d06:      	paddd	%xmm3, %xmm1
    1d0a:      	cmpq	%rdx, %rcx
    1d0d:      	jne	0x1ce0 <packet_xor+0x390>
    1d0f:      	cmpq	%rcx, %r14
    1d12:      	je	0x1d33 <packet_xor+0x3e3>
    1d14:      	movl	%r15d, %edx
    1d17:      	nopw	(%rax,%rax)
    1d20:      	leal	(%rdx,%rcx), %esi
    1d23:      	xorb	(%rbx,%rcx), %sil
    1d27:      	movb	%sil, (%rax,%rcx)
    1d2b:      	incq	%rcx
    1d2e:      	cmpq	%rcx, %r14
    1d31:      	jne	0x1d20 <packet_xor+0x3d0>
    1d33:      	leaq	-0x1(%r14), %rdx
    1d37:      	movl	%r14d, %ecx
    1d3a:      	andl	$0x7, %ecx
    1d3d:      	cmpq	$0x7, %rdx
    1d41:      	jae	0x1d4a <packet_xor+0x3fa>
    1d43:      	xorl	%edx, %edx
    1d45:      	xorl	%r15d, %r15d
    1d48:      	jmp	0x1daa <packet_xor+0x45a>
    1d4a:      	andq	$-0x8, %r14
    1d4e:      	xorl	%edx, %edx
    1d50:      	xorl	%r15d, %r15d
    1d53:      	nopw	%cs:(%rax,%rax)
    1d60:      	movzbl	(%rax,%rdx), %esi
    1d64:      	addq	%r15, %rsi
    1d67:      	movzbl	0x1(%rax,%rdx), %edi
    1d6c:      	movzbl	0x2(%rax,%rdx), %r8d
    1d72:      	addq	%rdi, %r8
    1d75:      	addq	%rsi, %r8
    1d78:      	movzbl	0x3(%rax,%rdx), %esi
    1d7d:      	movzbl	0x4(%rax,%rdx), %edi
    1d82:      	addq	%rsi, %rdi
    1d85:      	movzbl	0x5(%rax,%rdx), %esi
    1d8a:      	addq	%rdi, %rsi
    1d8d:      	addq	%r8, %rsi
    1d90:      	movzbl	0x6(%rax,%rdx), %edi
    1d95:      	movzbl	0x7(%rax,%rdx), %r15d
    1d9b:      	addq	%rdi, %r15
    1d9e:      	addq	%rsi, %r15
    1da1:      	addq	$0x8, %rdx
    1da5:      	cmpq	%rdx, %r14
    1da8:      	jne	0x1d60 <packet_xor+0x410>
    1daa:      	testq	%rcx, %rcx
    1dad:      	je	0x1dcf <packet_xor+0x47f>
    1daf:      	movq	%rax, %rsi
    1db2:      	addq	%rdx, %rsi
    1db5:      	xorl	%edx, %edx
    1db7:      	nopw	(%rax,%rax)
    1dc0:      	movzbl	(%rsi,%rdx), %edi
    1dc4:      	addq	%rdi, %r15
    1dc7:      	incq	%rdx
    1dca:      	cmpq	%rdx, %rcx
    1dcd:      	jne	0x1dc0 <packet_xor+0x470>
    1dcf:      	movq	%rax, %rdi
    1dd2:      	callq	0x1e50 <free@plt>
    1dd7:      	movq	%rbx, %rdi
    1dda:      	callq	0x1e50 <free@plt>
    1ddf:      	movq	%r15, %rax
    1de2:      	popq	%rbx
    1de3:      	popq	%r14
    1de5:      	popq	%r15
    1de7:      	retq

Disassembly of section .init:

0000000000001de8 <_init>:
    1de8:      	endbr64
    1dec:      	subq	$0x8, %rsp
    1df0:      	movq	0x11f9(%rip), %rax      # 0x2ff0 <free+0x2ff0>
    1df7:      	testq	%rax, %rax
    1dfa:      	je	0x1dfe <_init+0x16>
    1dfc:      	callq	*%rax
    1dfe:      	addq	$0x8, %rsp
    1e02:      	retq

Disassembly of section .fini:

0000000000001e04 <_fini>:
    1e04:      	endbr64
    1e08:      	subq	$0x8, %rsp
    1e0c:      	addq	$0x8, %rsp
    1e10:      	retq

Disassembly of section .plt:

0000000000001e20 <.plt>:
    1e20:      	pushq	0x21fa(%rip)            # 0x4020 <_GLOBAL_OFFSET_TABLE_+0x8>
    1e26:      	jmpq	*0x21fc(%rip)           # 0x4028 <_GLOBAL_OFFSET_TABLE_+0x10>
    1e2c:      	nopl	(%rax)

0000000000001e30 <__cxa_finalize@plt>:
    1e30:      	jmpq	*0x21fa(%rip)           # 0x4030 <_GLOBAL_OFFSET_TABLE_+0x18>
    1e36:      	pushq	$0x0
    1e3b:      	jmp	0x1e20 <.plt>

0000000000001e40 <calloc@plt>:
    1e40:      	jmpq	*0x21f2(%rip)           # 0x4038 <_GLOBAL_OFFSET_TABLE_+0x20>
    1e46:      	pushq	$0x1
    1e4b:      	jmp	0x1e20 <.plt>

0000000000001e50 <free@plt>:
    1e50:      	jmpq	*0x21ea(%rip)           # 0x4040 <_GLOBAL_OFFSET_TABLE_+0x28>
    1e56:      	pushq	$0x2
    1e5b:      	jmp	0x1e20 <.plt>
