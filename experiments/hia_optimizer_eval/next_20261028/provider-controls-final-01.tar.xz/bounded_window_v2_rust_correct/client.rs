use crate::api;
pub fn entrypoint(offset:u32,amount:u32,capacity:u32)->u64 { let (valid,end) = api::advance(offset,amount,capacity); if valid { end as u64 } else { u64::MAX } }
