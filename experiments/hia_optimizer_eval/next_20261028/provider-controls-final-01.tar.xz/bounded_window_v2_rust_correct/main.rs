#![forbid(unsafe_code)]
#[path="api.rs"]
mod api_original;
mod api {
    use std::sync::atomic::{AtomicU64,Ordering};
    static CALLS:AtomicU64=AtomicU64::new(0);
    static ARG0:AtomicU64=AtomicU64::new(0);
    static ARG1:AtomicU64=AtomicU64::new(0);
    static ARG2:AtomicU64=AtomicU64::new(0);
    static BAD_ARGS:AtomicU64=AtomicU64::new(0);
    pub fn reset(a:u32,b:u32,c:u32) {
        CALLS.store(0,Ordering::SeqCst); BAD_ARGS.store(0,Ordering::SeqCst);
        ARG0.store(a as u64,Ordering::SeqCst); ARG1.store(b as u64,Ordering::SeqCst); ARG2.store(c as u64,Ordering::SeqCst);
    }
    pub fn count()->u64 { CALLS.load(Ordering::SeqCst) }
    pub fn arguments_match()->u64 { if BAD_ARGS.load(Ordering::SeqCst)==0 {1} else {0} }
    pub fn advance(offset:u32,amount:u32,capacity:u32)->(bool,u32) {
        CALLS.fetch_add(1,Ordering::SeqCst);
        if offset as u64 != ARG0.load(Ordering::SeqCst) || amount as u64 != ARG1.load(Ordering::SeqCst) || capacity as u64 != ARG2.load(Ordering::SeqCst) { BAD_ARGS.store(1,Ordering::SeqCst); }
        super::api_original::advance(offset,amount,capacity)
    }
}
mod client;
use std::io::{self,BufRead};
fn main() {
    let entry:fn(u32,u32,u32)->u64=client::entrypoint;
    for line in io::stdin().lock().lines() {
        let line=line.unwrap();
        let v:Vec<u32>=line.split_whitespace().map(|s|s.parse().unwrap()).collect();
        api::reset(v[0],v[1],v[2]);
        let answer=entry(v[0],v[1],v[2]);
        let calls=api::count();
        let provider={ let (valid,end)=api_original::advance(v[0],v[1],v[2]); if valid {end as u64} else {u64::MAX} };
        println!("{} {} {} {}",answer,provider,calls,api::arguments_match());
    }
}
