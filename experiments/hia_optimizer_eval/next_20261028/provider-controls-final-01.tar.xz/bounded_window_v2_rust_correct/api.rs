pub fn advance(offset:u32,amount:u32,capacity:u32)->(bool,u32) { let end = (offset as u64) + (amount as u64); (end <= capacity as u64, end as u32) }
