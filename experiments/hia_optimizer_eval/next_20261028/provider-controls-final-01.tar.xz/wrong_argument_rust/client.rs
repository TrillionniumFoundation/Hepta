use crate::api;
pub fn entrypoint(tag:u32,length:u32,reserved:u32)->u64 { let _ = reserved; let _ = api::wire_length(0); (((tag & 255) as u64) << 32) | (length as u64) }
