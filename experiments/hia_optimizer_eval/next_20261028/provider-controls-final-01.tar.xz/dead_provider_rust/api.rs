pub fn advance(offset:u32,amount:u32,capacity:u32)->(bool,u32) { (false, 0) }
