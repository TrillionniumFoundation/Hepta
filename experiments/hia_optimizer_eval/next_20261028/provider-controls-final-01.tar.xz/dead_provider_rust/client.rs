use crate::api;
pub fn entrypoint(offset:u32,amount:u32,capacity:u32)->u64 { if false { let _ = api::advance(offset,amount,capacity); } let end = (offset as u64) + (amount as u64); if end <= capacity as u64 { end } else { u64::MAX } }
