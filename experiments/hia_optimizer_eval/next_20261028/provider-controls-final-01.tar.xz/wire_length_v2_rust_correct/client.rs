use crate::api;
pub fn entrypoint(tag:u32,length:u32,reserved:u32)->u64 { let _ = reserved; (((tag & 255) as u64) << 32) | api::wire_length(length) }
