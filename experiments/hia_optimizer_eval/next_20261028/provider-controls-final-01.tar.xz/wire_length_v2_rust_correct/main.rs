#![forbid(unsafe_code)]
#[path="api.rs"]
mod api_original;
mod api {
    use std::sync::atomic::{AtomicU64,Ordering};
    static CALLS:AtomicU64=AtomicU64::new(0);
    static ARG0:AtomicU64=AtomicU64::new(0);
    static ARG1:AtomicU64=AtomicU64::new(0);
    static ARG2:AtomicU64=AtomicU64::new(0);
    static BAD_ARGS:AtomicU64=AtomicU64::new(0);
    pub fn reset(a:u32,b:u32,c:u32) {
        CALLS.store(0,Ordering::SeqCst); BAD_ARGS.store(0,Ordering::SeqCst);
        ARG0.store(a as u64,Ordering::SeqCst); ARG1.store(b as u64,Ordering::SeqCst); ARG2.store(c as u64,Ordering::SeqCst);
    }
    pub fn count()->u64 { CALLS.load(Ordering::SeqCst) }
    pub fn arguments_match()->u64 { if BAD_ARGS.load(Ordering::SeqCst)==0 {1} else {0} }
    pub fn wire_length(length:u32)->u64 {
        CALLS.fetch_add(1,Ordering::SeqCst);
        if length as u64 != ARG0.load(Ordering::SeqCst) { BAD_ARGS.store(1,Ordering::SeqCst); }
        super::api_original::wire_length(length)
    }
}
mod client;
use std::io::{self,BufRead};
fn main() {
    let entry:fn(u32,u32,u32)->u64=client::entrypoint;
    for line in io::stdin().lock().lines() {
        let line=line.unwrap();
        let v:Vec<u32>=line.split_whitespace().map(|s|s.parse().unwrap()).collect();
        api::reset(v[1],0,0);
        let answer=entry(v[0],v[1],v[2]);
        let calls=api::count();
        let provider=api_original::wire_length(v[1]);
        println!("{} {} {} {}",answer,provider,calls,api::arguments_match());
    }
}
