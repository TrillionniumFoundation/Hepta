use crate::api;
pub fn entrypoint(offset:u32,amount:u32,capacity:u32)->u64 { let _ = capacity; api::advance(offset,amount) as u64 }
