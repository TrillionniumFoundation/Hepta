#![forbid(unsafe_code)]
mod api;
mod client;
use std::io::{self,BufRead};
fn main() { for line in io::stdin().lock().lines() { let line=line.unwrap(); let v:Vec<u32>=line.split_whitespace().map(|s|s.parse().unwrap()).collect(); println!("{}",client::entrypoint(v[0],v[1],v[2])); } }
