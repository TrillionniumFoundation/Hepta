pub fn advance(offset:u32,amount:u32)->u32 { offset.wrapping_add(amount) }
