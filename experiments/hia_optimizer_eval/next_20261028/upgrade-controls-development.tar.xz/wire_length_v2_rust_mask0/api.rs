pub fn wire_length(length:u16)->u32 { length as u32 }
