
/tmp/hepta-seven-stage-bench-final/hia.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000001310 <packet_xor>:
    1310:      	pushq	%r15
    1312:      	pushq	%r14
    1314:      	pushq	%rbx
    1315:      	testq	%rdi, %rdi
    1318:      	je	0x1366 <packet_xor+0x56>
    131a:      	movl	%esi, %r15d
    131d:      	movq	%rdi, %r14
    1320:      	js	0x1351 <packet_xor+0x41>
    1322:      	movl	$0x1, %edi
    1327:      	movq	%r14, %rsi
    132a:      	callq	0x1050 <calloc@plt>
    132f:      	testq	%rax, %rax
    1332:      	je	0x1351 <packet_xor+0x41>
    1334:      	movq	%rax, %rbx
    1337:      	movb	$0x1, %al
    1339:      	testb	$0x1, %al
    133b:      	jne	0x1359 <packet_xor+0x49>
    133d:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    1343:      	testq	%rbx, %rbx
    1346:      	jne	0x17ff <packet_xor+0x4ef>
    134c:      	jmp	0x1807 <packet_xor+0x4f7>
    1351:      	xorl	%ebx, %ebx
    1353:      	xorl	%eax, %eax
    1355:      	testb	$0x1, %al
    1357:      	je	0x133d <packet_xor+0x2d>
    1359:      	cmpq	$0x3, %r14
    135d:      	ja	0x136e <packet_xor+0x5e>
    135f:      	xorl	%eax, %eax
    1361:      	jmp	0x1566 <packet_xor+0x256>
    1366:      	xorl	%r15d, %r15d
    1369:      	jmp	0x1807 <packet_xor+0x4f7>
    136e:      	movd	%r15d, %xmm0
    1373:      	cmpq	$0x10, %r14
    1377:      	jae	0x1380 <packet_xor+0x70>
    1379:      	xorl	%eax, %eax
    137b:      	jmp	0x14d9 <packet_xor+0x1c9>
    1380:      	movq	%r14, %rax
    1383:      	andq	$-0x10, %rax
    1387:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    138c:      	movdqa	0xc6c(%rip), %xmm2      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    1394:      	movdqa	0xc74(%rip), %xmm3      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    139c:      	movdqa	0xc7c(%rip), %xmm4      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    13a4:      	movdqa	0xc84(%rip), %xmm5      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    13ac:      	xorl	%ecx, %ecx
    13ae:      	movdqa	0xcba(%rip), %xmm6      # 0x2070 <free@GLIBC_2.2.5+0x2070>
    13b6:      	movdqa	0xc82(%rip), %xmm7      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    13be:      	movdqa	0xc89(%rip), %xmm8      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    13c7:      	nopw	(%rax,%rax)
    13d0:      	movdqa	%xmm5, %xmm9
    13d5:      	pmuludq	%xmm6, %xmm9
    13da:      	pshufd	$0xe8, %xmm9, %xmm9     # xmm9 = xmm9[0,2,2,3]
    13e0:      	pshufd	$0xf5, %xmm5, %xmm10    # xmm10 = xmm5[1,1,3,3]
    13e6:      	pmuludq	%xmm6, %xmm10
    13eb:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    13f1:      	punpckldq	%xmm10, %xmm9   # xmm9 = xmm9[0],xmm10[0],xmm9[1],xmm10[1]
    13f6:      	movdqa	%xmm4, %xmm10
    13fb:      	pmuludq	%xmm6, %xmm10
    1400:      	pshufd	$0xe8, %xmm10, %xmm10   # xmm10 = xmm10[0,2,2,3]
    1406:      	pshufd	$0xf5, %xmm4, %xmm11    # xmm11 = xmm4[1,1,3,3]
    140c:      	pmuludq	%xmm6, %xmm11
    1411:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    1417:      	punpckldq	%xmm11, %xmm10  # xmm10 = xmm10[0],xmm11[0],xmm10[1],xmm11[1]
    141c:      	movdqa	%xmm3, %xmm11
    1421:      	pmuludq	%xmm6, %xmm11
    1426:      	pshufd	$0xe8, %xmm11, %xmm11   # xmm11 = xmm11[0,2,2,3]
    142c:      	pshufd	$0xf5, %xmm3, %xmm12    # xmm12 = xmm3[1,1,3,3]
    1432:      	pmuludq	%xmm6, %xmm12
    1437:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    143d:      	punpckldq	%xmm12, %xmm11  # xmm11 = xmm11[0],xmm12[0],xmm11[1],xmm12[1]
    1442:      	movdqa	%xmm2, %xmm12
    1447:      	pmuludq	%xmm6, %xmm12
    144c:      	pshufd	$0xe8, %xmm12, %xmm12   # xmm12 = xmm12[0,2,2,3]
    1452:      	pshufd	$0xf5, %xmm2, %xmm13    # xmm13 = xmm2[1,1,3,3]
    1458:      	pmuludq	%xmm6, %xmm13
    145d:      	pshufd	$0xe8, %xmm13, %xmm13   # xmm13 = xmm13[0,2,2,3]
    1463:      	punpckldq	%xmm13, %xmm12  # xmm12 = xmm12[0],xmm13[0],xmm12[1],xmm13[1]
    1468:      	paddd	%xmm1, %xmm12
    146d:      	paddd	%xmm1, %xmm11
    1472:      	paddd	%xmm1, %xmm10
    1477:      	paddd	%xmm1, %xmm9
    147c:      	pand	%xmm7, %xmm9
    1481:      	pand	%xmm7, %xmm10
    1486:      	packuswb	%xmm10, %xmm9
    148b:      	pand	%xmm7, %xmm11
    1490:      	pand	%xmm7, %xmm12
    1495:      	packuswb	%xmm12, %xmm11
    149a:      	packuswb	%xmm11, %xmm9
    149f:      	movdqu	%xmm9, (%rbx,%rcx)
    14a5:      	addq	$0x10, %rcx
    14a9:      	paddd	%xmm8, %xmm5
    14ae:      	paddd	%xmm8, %xmm4
    14b3:      	paddd	%xmm8, %xmm3
    14b8:      	paddd	%xmm8, %xmm2
    14bd:      	cmpq	%rcx, %rax
    14c0:      	jne	0x13d0 <packet_xor+0xc0>
    14c6:      	cmpq	%rax, %r14
    14c9:      	je	0x157e <packet_xor+0x26e>
    14cf:      	testb	$0xc, %r14b
    14d3:      	je	0x1566 <packet_xor+0x256>
    14d9:      	movq	%rax, %rcx
    14dc:      	movq	%r14, %rax
    14df:      	andq	$-0x4, %rax
    14e3:      	movd	%ecx, %xmm1
    14e7:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    14ec:      	por	0xb3c(%rip), %xmm1      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    14f4:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    14f9:      	movdqa	0xb6f(%rip), %xmm2      # 0x2070 <free@GLIBC_2.2.5+0x2070>
    1501:      	movdqa	0xb37(%rip), %xmm3      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    1509:      	movdqa	0xb4f(%rip), %xmm4      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    1511:      	nopw	%cs:(%rax,%rax)
    1520:      	movdqa	%xmm1, %xmm5
    1524:      	pmuludq	%xmm2, %xmm5
    1528:      	pshufd	$0xe8, %xmm5, %xmm5     # xmm5 = xmm5[0,2,2,3]
    152d:      	pshufd	$0xf5, %xmm1, %xmm6     # xmm6 = xmm1[1,1,3,3]
    1532:      	pmuludq	%xmm2, %xmm6
    1536:      	pshufd	$0xe8, %xmm6, %xmm6     # xmm6 = xmm6[0,2,2,3]
    153b:      	punpckldq	%xmm6, %xmm5    # xmm5 = xmm5[0],xmm6[0],xmm5[1],xmm6[1]
    153f:      	paddd	%xmm0, %xmm5
    1543:      	pand	%xmm3, %xmm5
    1547:      	packuswb	%xmm5, %xmm5
    154b:      	packuswb	%xmm5, %xmm5
    154f:      	movd	%xmm5, (%rbx,%rcx)
    1554:      	addq	$0x4, %rcx
    1558:      	paddd	%xmm4, %xmm1
    155c:      	cmpq	%rcx, %rax
    155f:      	jne	0x1520 <packet_xor+0x210>
    1561:      	cmpq	%rax, %r14
    1564:      	je	0x157e <packet_xor+0x26e>
    1566:      	leal	(%rax,%rax,2), %ecx
    1569:      	leal	(%rax,%rcx,4), %ecx
    156c:      	addl	%r15d, %ecx
    156f:      	nop
    1570:      	movb	%cl, (%rbx,%rax)
    1573:      	incq	%rax
    1576:      	addb	$0xd, %cl
    1579:      	cmpq	%rax, %r14
    157c:      	jne	0x1570 <packet_xor+0x260>
    157e:      	testq	%r14, %r14
    1581:      	js	0x15b7 <packet_xor+0x2a7>
    1583:      	movl	$0x1, %edi
    1588:      	movq	%r14, %rsi
    158b:      	callq	0x1050 <calloc@plt>
    1590:      	testq	%rax, %rax
    1593:      	je	0x15b7 <packet_xor+0x2a7>
    1595:      	movq	%rax, %rdi
    1598:      	movb	$0x1, %al
    159a:      	testb	$0x1, %al
    159c:      	jne	0x15bf <packet_xor+0x2af>
    159e:      	movl	$0x3e9, %r15d           # imm = 0x3E9
    15a4:      	testq	%rdi, %rdi
    15a7:      	je	0x17ff <packet_xor+0x4ef>
    15ad:      	callq	0x1030 <free@plt>
    15b2:      	jmp	0x17ff <packet_xor+0x4ef>
    15b7:      	xorl	%edi, %edi
    15b9:      	xorl	%eax, %eax
    15bb:      	testb	$0x1, %al
    15bd:      	je	0x159e <packet_xor+0x28e>
    15bf:      	xorl	$0x5a, %r15d
    15c3:      	xorl	%eax, %eax
    15c5:      	cmpq	$0x4, %r14
    15c9:      	jb	0x1728 <packet_xor+0x418>
    15cf:      	movq	%rdi, %rcx
    15d2:      	subq	%rbx, %rcx
    15d5:      	cmpq	$0xf, %rcx
    15d9:      	jbe	0x1728 <packet_xor+0x418>
    15df:      	movd	%r15d, %xmm0
    15e4:      	cmpq	$0x10, %r14
    15e8:      	jae	0x15f1 <packet_xor+0x2e1>
    15ea:      	xorl	%eax, %eax
    15ec:      	jmp	0x16b4 <packet_xor+0x3a4>
    15f1:      	movq	%r14, %rax
    15f4:      	andq	$-0x10, %rax
    15f8:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    15fd:      	movdqa	0x9fb(%rip), %xmm2      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    1605:      	movdqa	0xa03(%rip), %xmm3      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    160d:      	movdqa	0xa0b(%rip), %xmm4      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    1615:      	movdqa	0xa13(%rip), %xmm5      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    161d:      	xorl	%ecx, %ecx
    161f:      	movdqa	0xa19(%rip), %xmm6      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    1627:      	movdqa	0xa21(%rip), %xmm7      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    162f:      	nop
    1630:      	movdqu	(%rbx,%rcx), %xmm8
    1636:      	movdqa	%xmm1, %xmm9
    163b:      	paddd	%xmm2, %xmm9
    1640:      	movdqa	%xmm1, %xmm10
    1645:      	paddd	%xmm3, %xmm10
    164a:      	movdqa	%xmm1, %xmm11
    164f:      	paddd	%xmm4, %xmm11
    1654:      	movdqa	%xmm1, %xmm12
    1659:      	paddd	%xmm5, %xmm12
    165e:      	pand	%xmm6, %xmm12
    1663:      	pand	%xmm6, %xmm11
    1668:      	packuswb	%xmm11, %xmm12
    166d:      	pand	%xmm6, %xmm10
    1672:      	pand	%xmm6, %xmm9
    1677:      	packuswb	%xmm9, %xmm10
    167c:      	packuswb	%xmm10, %xmm12
    1681:      	pxor	%xmm8, %xmm12
    1686:      	movdqu	%xmm12, (%rdi,%rcx)
    168c:      	addq	$0x10, %rcx
    1690:      	paddd	%xmm7, %xmm5
    1694:      	paddd	%xmm7, %xmm4
    1698:      	paddd	%xmm7, %xmm3
    169c:      	paddd	%xmm7, %xmm2
    16a0:      	cmpq	%rcx, %rax
    16a3:      	jne	0x1630 <packet_xor+0x320>
    16a5:      	cmpq	%rax, %r14
    16a8:      	je	0x17cf <packet_xor+0x4bf>
    16ae:      	testb	$0xc, %r14b
    16b2:      	je	0x1728 <packet_xor+0x418>
    16b4:      	movq	%rax, %rcx
    16b7:      	movq	%r14, %rax
    16ba:      	movd	%ecx, %xmm1
    16be:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    16c3:      	por	0x965(%rip), %xmm1      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    16cb:      	andq	$-0x4, %rax
    16cf:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    16d4:      	movdqa	0x964(%rip), %xmm2      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    16dc:      	movdqa	0x97c(%rip), %xmm3      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    16e4:      	nopw	%cs:(%rax,%rax)
    16f0:      	movd	(%rbx,%rcx), %xmm4
    16f5:      	movdqa	%xmm0, %xmm5
    16f9:      	paddd	%xmm1, %xmm5
    16fd:      	pand	%xmm2, %xmm5
    1701:      	packuswb	%xmm5, %xmm5
    1705:      	packuswb	%xmm5, %xmm5
    1709:      	pxor	%xmm4, %xmm5
    170d:      	movd	%xmm5, (%rdi,%rcx)
    1712:      	addq	$0x4, %rcx
    1716:      	paddd	%xmm3, %xmm1
    171a:      	cmpq	%rcx, %rax
    171d:      	jne	0x16f0 <packet_xor+0x3e0>
    171f:      	cmpq	%rax, %r14
    1722:      	je	0x17cf <packet_xor+0x4bf>
    1728:      	movq	%r14, %rdx
    172b:      	movq	%rax, %rcx
    172e:      	andq	$0x3, %rdx
    1732:      	je	0x1757 <packet_xor+0x447>
    1734:      	leal	(%r15,%rax), %esi
    1738:      	movq	%rax, %rcx
    173b:      	nopl	(%rax,%rax)
    1740:      	movzbl	(%rbx,%rcx), %r8d
    1745:      	xorb	%sil, %r8b
    1748:      	movb	%r8b, (%rdi,%rcx)
    174c:      	incq	%rcx
    174f:      	incb	%sil
    1752:      	decq	%rdx
    1755:      	jne	0x1740 <packet_xor+0x430>
    1757:      	subq	%r14, %rax
    175a:      	cmpq	$-0x4, %rax
    175e:      	ja	0x17cf <packet_xor+0x4bf>
    1760:      	movq	%rdi, %rax
    1763:      	addq	$0x3, %rax
    1767:      	movl	%r15d, %edx
    176a:      	leaq	0x3(%rbx), %rsi
    176e:      	movq	%r14, %r8
    1771:      	nopw	%cs:(%rax,%rax)
    1780:      	leal	(%rcx,%rdx), %r9d
    1784:      	movzbl	-0x3(%rsi,%rcx), %r10d
    178a:      	xorb	%r9b, %r10b
    178d:      	movb	%r10b, -0x3(%rax,%rcx)
    1792:      	leal	0x1(%r9), %r10d
    1796:      	xorb	-0x2(%rsi,%rcx), %r10b
    179b:      	movb	%r10b, -0x2(%rax,%rcx)
    17a0:      	leal	0x2(%r9), %r10d
    17a4:      	xorb	-0x1(%rsi,%rcx), %r10b
    17a9:      	movb	%r10b, -0x1(%rax,%rcx)
    17ae:      	addb	$0x3, %r9b
    17b2:      	xorb	(%rsi,%rcx), %r9b
    17b6:      	movb	%r9b, (%rax,%rcx)
    17ba:      	addq	$-0x4, %r8
    17be:      	addq	$0x4, %rax
    17c2:      	addq	$0x4, %rdx
    17c6:      	addq	$0x4, %rsi
    17ca:      	cmpq	%r8, %rcx
    17cd:      	jne	0x1780 <packet_xor+0x470>
    17cf:      	xorl	%eax, %eax
    17d1:      	xorl	%r15d, %r15d
    17d4:      	nopw	%cs:(%rax,%rax)
    17e0:      	movq	%r15, %rcx
    17e3:      	movzbl	(%rdi,%rax), %r15d
    17e8:      	addq	%rcx, %r15
    17eb:      	jb	0x1810 <packet_xor+0x500>
    17ed:      	incq	%rax
    17f0:      	cmpq	%rax, %r14
    17f3:      	jne	0x17e0 <packet_xor+0x4d0>
    17f5:      	callq	0x1030 <free@plt>
    17fa:      	testq	%rbx, %rbx
    17fd:      	je	0x1807 <packet_xor+0x4f7>
    17ff:      	movq	%rbx, %rdi
    1802:      	callq	0x1030 <free@plt>
    1807:      	movq	%r15, %rax
    180a:      	popq	%rbx
    180b:      	popq	%r14
    180d:      	popq	%r15
    180f:      	retq
    1810:      	callq	0x1040 <abort@plt>
