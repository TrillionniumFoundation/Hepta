
/tmp/hepta-seven-stage-bench-final/hia.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000001130 <full_lifecycle>:
    1130:      	pushq	%rbp
    1131:      	pushq	%r14
    1133:      	pushq	%rbx
    1134:      	testq	%rdi, %rdi
    1137:      	je	0x1184 <full_lifecycle+0x54>
    1139:      	movl	%esi, %ebp
    113b:      	movq	%rdi, %rbx
    113e:      	js	0x116f <full_lifecycle+0x3f>
    1140:      	movl	$0x1, %edi
    1145:      	movq	%rbx, %rsi
    1148:      	callq	0x1050 <calloc@plt>
    114d:      	testq	%rax, %rax
    1150:      	je	0x116f <full_lifecycle+0x3f>
    1152:      	movq	%rax, %rdi
    1155:      	movb	$0x1, %al
    1157:      	testb	$0x1, %al
    1159:      	jne	0x1177 <full_lifecycle+0x47>
    115b:      	movl	$0x3e9, %r14d           # imm = 0x3E9
    1161:      	testq	%rdi, %rdi
    1164:      	jne	0x12f5 <full_lifecycle+0x1c5>
    116a:      	jmp	0x12fa <full_lifecycle+0x1ca>
    116f:      	xorl	%edi, %edi
    1171:      	xorl	%eax, %eax
    1173:      	testb	$0x1, %al
    1175:      	je	0x115b <full_lifecycle+0x2b>
    1177:      	cmpq	$0x3, %rbx
    117b:      	ja	0x118c <full_lifecycle+0x5c>
    117d:      	xorl	%eax, %eax
    117f:      	jmp	0x12bb <full_lifecycle+0x18b>
    1184:      	xorl	%r14d, %r14d
    1187:      	jmp	0x12fa <full_lifecycle+0x1ca>
    118c:      	movd	%ebp, %xmm0
    1190:      	cmpq	$0x10, %rbx
    1194:      	jae	0x119d <full_lifecycle+0x6d>
    1196:      	xorl	%eax, %eax
    1198:      	jmp	0x1254 <full_lifecycle+0x124>
    119d:      	movq	%rbx, %rax
    11a0:      	andq	$-0x10, %rax
    11a4:      	pshufd	$0x0, %xmm0, %xmm1      # xmm1 = xmm0[0,0,0,0]
    11a9:      	movdqa	0xe4f(%rip), %xmm2      # 0x2000 <free@GLIBC_2.2.5+0x2000>
    11b1:      	movdqa	0xe57(%rip), %xmm3      # 0x2010 <free@GLIBC_2.2.5+0x2010>
    11b9:      	movdqa	0xe5f(%rip), %xmm4      # 0x2020 <free@GLIBC_2.2.5+0x2020>
    11c1:      	movdqa	0xe67(%rip), %xmm5      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    11c9:      	xorl	%ecx, %ecx
    11cb:      	movdqa	0xe6d(%rip), %xmm6      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    11d3:      	movdqa	0xe75(%rip), %xmm7      # 0x2050 <free@GLIBC_2.2.5+0x2050>
    11db:      	nopl	(%rax,%rax)
    11e0:      	movdqa	%xmm1, %xmm8
    11e5:      	paddd	%xmm2, %xmm8
    11ea:      	movdqa	%xmm1, %xmm9
    11ef:      	paddd	%xmm3, %xmm9
    11f4:      	movdqa	%xmm1, %xmm10
    11f9:      	paddd	%xmm4, %xmm10
    11fe:      	movdqa	%xmm1, %xmm11
    1203:      	paddd	%xmm5, %xmm11
    1208:      	pand	%xmm6, %xmm11
    120d:      	pand	%xmm6, %xmm10
    1212:      	packuswb	%xmm10, %xmm11
    1217:      	pand	%xmm6, %xmm9
    121c:      	pand	%xmm6, %xmm8
    1221:      	packuswb	%xmm8, %xmm9
    1226:      	packuswb	%xmm9, %xmm11
    122b:      	movdqu	%xmm11, (%rdi,%rcx)
    1231:      	addq	$0x10, %rcx
    1235:      	paddd	%xmm7, %xmm5
    1239:      	paddd	%xmm7, %xmm4
    123d:      	paddd	%xmm7, %xmm3
    1241:      	paddd	%xmm7, %xmm2
    1245:      	cmpq	%rcx, %rax
    1248:      	jne	0x11e0 <full_lifecycle+0xb0>
    124a:      	cmpq	%rax, %rbx
    124d:      	je	0x12ce <full_lifecycle+0x19e>
    124f:      	testb	$0xc, %bl
    1252:      	je	0x12bb <full_lifecycle+0x18b>
    1254:      	movq	%rax, %rcx
    1257:      	movq	%rbx, %rax
    125a:      	movd	%ecx, %xmm1
    125e:      	pshufd	$0x0, %xmm1, %xmm1      # xmm1 = xmm1[0,0,0,0]
    1263:      	por	0xdc5(%rip), %xmm1      # 0x2030 <free@GLIBC_2.2.5+0x2030>
    126b:      	andq	$-0x4, %rax
    126f:      	pshufd	$0x0, %xmm0, %xmm0      # xmm0 = xmm0[0,0,0,0]
    1274:      	movdqa	0xdc4(%rip), %xmm2      # 0x2040 <free@GLIBC_2.2.5+0x2040>
    127c:      	movdqa	0xddc(%rip), %xmm3      # 0x2060 <free@GLIBC_2.2.5+0x2060>
    1284:      	nopw	%cs:(%rax,%rax)
    1290:      	movdqa	%xmm0, %xmm4
    1294:      	paddd	%xmm1, %xmm4
    1298:      	pand	%xmm2, %xmm4
    129c:      	packuswb	%xmm4, %xmm4
    12a0:      	packuswb	%xmm4, %xmm4
    12a4:      	movd	%xmm4, (%rdi,%rcx)
    12a9:      	addq	$0x4, %rcx
    12ad:      	paddd	%xmm3, %xmm1
    12b1:      	cmpq	%rcx, %rax
    12b4:      	jne	0x1290 <full_lifecycle+0x160>
    12b6:      	cmpq	%rax, %rbx
    12b9:      	je	0x12ce <full_lifecycle+0x19e>
    12bb:      	movl	%ebp, %ecx
    12bd:      	nopl	(%rax)
    12c0:      	leal	(%rcx,%rax), %edx
    12c3:      	movb	%dl, (%rdi,%rax)
    12c6:      	incq	%rax
    12c9:      	cmpq	%rax, %rbx
    12cc:      	jne	0x12c0 <full_lifecycle+0x190>
    12ce:      	xorl	%eax, %eax
    12d0:      	xorl	%r14d, %r14d
    12d3:      	nopw	%cs:(%rax,%rax)
    12e0:      	movq	%r14, %rcx
    12e3:      	movzbl	(%rdi,%rax), %r14d
    12e8:      	addq	%rcx, %r14
    12eb:      	jb	0x1302 <full_lifecycle+0x1d2>
    12ed:      	incq	%rax
    12f0:      	cmpq	%rax, %rbx
    12f3:      	jne	0x12e0 <full_lifecycle+0x1b0>
    12f5:      	callq	0x1030 <free@plt>
    12fa:      	movq	%r14, %rax
    12fd:      	popq	%rbx
    12fe:      	popq	%r14
    1300:      	popq	%rbp
    1301:      	retq
    1302:      	callq	0x1040 <abort@plt>
    1307:      	nopw	(%rax,%rax)
