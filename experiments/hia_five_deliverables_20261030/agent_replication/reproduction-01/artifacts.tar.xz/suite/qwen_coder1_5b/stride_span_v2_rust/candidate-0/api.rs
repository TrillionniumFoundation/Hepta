pub fn span(a:u32,b:u32)->u64 { (a as u32) * ((b as u32)+1) }
