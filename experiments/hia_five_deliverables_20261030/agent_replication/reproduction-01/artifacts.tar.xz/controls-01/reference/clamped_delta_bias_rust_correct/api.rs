pub fn delta(a:u32,b:u32)->u64 { a.saturating_sub(b) as u64 }
