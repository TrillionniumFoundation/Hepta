use crate::api; pub fn entrypoint(a:u32,b:u32,c:u32)->u64 { api::span(a,b) ^ (((c & 127) as u64)<<57) }
