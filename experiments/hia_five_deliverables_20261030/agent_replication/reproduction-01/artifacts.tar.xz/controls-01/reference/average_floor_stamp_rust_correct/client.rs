use crate::api; pub fn entrypoint(a:u32,b:u32,c:u32)->u64 { api::average(a,b) ^ (((c & 255) as u64)<<40) }
