use crate::api; pub fn entrypoint(a:u32,b:u32,c:u32)->u64 { let _=c; api::multiple(a as u16,b as u16) as u64 }
