use crate::api; pub fn entrypoint(a:u32,b:u32,c:u32)->u64 { let _=c; let (valid,value)=api::multiple(a,b); if valid {value} else {u64::MAX} }
