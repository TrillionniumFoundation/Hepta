pub fn multiple(a:u32,b:u32)->(bool,u64) { if b==0 { (false,0) } else { (true,((a/b)*b) as u64) } }
