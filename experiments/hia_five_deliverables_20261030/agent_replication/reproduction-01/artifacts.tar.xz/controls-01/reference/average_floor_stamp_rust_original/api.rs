pub fn average(a:u32,b:u32)->u64 { (a.wrapping_add(b) / 2) as u64 }
