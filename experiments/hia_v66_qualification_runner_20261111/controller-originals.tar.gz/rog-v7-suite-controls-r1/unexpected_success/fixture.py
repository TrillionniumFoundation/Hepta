import unittest
class Example(unittest.TestCase):
 @unittest.expectedFailure
 def test_a(self): pass
