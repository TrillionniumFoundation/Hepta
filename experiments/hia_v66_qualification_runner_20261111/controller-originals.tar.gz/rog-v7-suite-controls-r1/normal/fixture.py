import unittest
class Example(unittest.TestCase):
 def test_a(self): pass
 def test_b(self): pass
