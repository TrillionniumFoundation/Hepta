import unittest
class Example(unittest.TestCase):
 def test_a(self): self._outcome.result.stop()
 def test_b(self): pass
