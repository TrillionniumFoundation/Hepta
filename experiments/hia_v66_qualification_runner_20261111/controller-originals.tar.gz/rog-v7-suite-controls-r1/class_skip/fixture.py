import unittest
class Example(unittest.TestCase):
 @classmethod
 def setUpClass(cls): raise unittest.SkipTest('actual class-level refusal')
 def test_a(self): pass
 def test_b(self): pass
 def test_c(self): pass
