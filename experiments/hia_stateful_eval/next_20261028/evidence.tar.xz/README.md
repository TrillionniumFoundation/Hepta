# Owned-state runtime: final qualification and full local cost

**The final correctness/resource controls pass. The final complete local cost
profitability gate does not pass.** `FINAL_ACCEPTANCE.json` and
`attempt04/qualification.json` are the authoritative final result. Historical
positive, narrower measurements are retained and are not selected as the final
performance result.

The implemented profile uses a real exclusive native `u64` array, checked lease
handles, a stable opaque allocation identity and pure verified scalar native
transitions. It rejects switching/closing with live aliases or active native
work. Committed finite queues execute each actual transition once; partial
cancellation and a host exception after real native progress are terminal and
cannot replay the original queue. Sealed native versions and a private native
owner adapter preserve actual identity across safe-point switches. This is not
whole-heap/live-frame migration, external transactions or crash recovery.

## Final fixed queue and measured outcome

All performance attempts use the same pre-registered queue: initial state
`[29,31]`, slot 0, delta `0xD7A192456BBEFE51`, 400,000,000 transitions. Each
transition performs the same four modular additions. The candidate replaces
an MBA helper with wrapping addition; original and candidate `transition`
machine code are actually different (17 instructions/53 bytes versus 2
instructions/5 bytes in the retained disassembly). The checker proves the
scalar correspondence; native execution and resource observations are separate.

| Final attempt04 measurement | Seconds |
| --- | ---: |
| Full local deployment wall time | 3.619340678 |
| Original native counterfactual execution | 2.813950834 |
| **Complete local measured net** | **−0.805389844** |
| Entire post-decision audit API | 2.815380199 |
| Full performance experiment wall time | 6.434720877 |
| Internal receipt intervals | 3.618628945 |
| Additional measured outer-envelope overhead | 0.000711733 |

The outer timer starts before this fixture constructs the base/proposal and
ends after `close()` returns. It includes initialization, candidate preparation,
compilation, verification, calibration, switching decisions, dispatch, actual
execution, receipt/API return tails and final owner/library release. The only
subtracted interval is the separately timed **whole** post-decision audit API,
which uses a distinct owner and never replays application state. Both the
subtracted audit and the complete experiment wall time remain recorded.

This is a fresh runtime object in an already running Python process. Process
startup/imports and an external LLM/NDU search that this fixture does not execute
are outside this stated experiment. It is not a whole AI-session benchmark.

### Why the final attempt retained the baseline

The minimum observed paired saving projected to the actual immutable queue was
798,114,400 ns. Measured initial/candidate preparation was 863,718,092 ns and
calibration was 27,212,650 ns: the required preselection cost was 890,930,742 ns.
The projected saving did not cover that cost, so `automatic_selected=false` and
`selection_reason=nonpositive_empirical_queue_forecast`. The application queue
then ran on the baseline. Work and unsuccessful optimization preparation still
cost time, so the final whole-deployment comparison is negative.

The added 711,733 ns of outer-envelope overhead did **not** by itself turn a
historical +0.354-second result into this loss. The attempts have different
actual timing observations and different selection outcomes. We retain the
last fully specified gate, not the best observed timing.

## Why earlier attempts remain but are superseded

| Attempt | Actual observation | Why it is not the final gate |
| --- | --- | --- |
| 01 | Automatic selection; internal-interval net +0.534215440 s | Superseded by immutable-stdin/private driver staging and failed-selection cost/rollback hardening. Exact historical source bytes are retained and their original execution hash verified. |
| 02 | Automatic selection; internal-interval net +0.627590126 s | Superseded by charging commit bookkeeping before the near-zero rollback decision, plus binding the queue digest solely to immutable copied work. |
| 03 | Automatic selection; internal-interval net +0.354192625 s | Valid historical execution on the final runtime source, but its narrower timer omitted API tails and final close. Superseded for the complete-cost claim by the outer wall-clock measurement. |
| **04** | **Baseline retained; complete local net −0.805389844 s** | **Final authoritative profitability result.** Runtime semantics and registered work did not change from 03. |

These repeats followed specific correctness, provenance or measurement-boundary
changes. No performance horizon, input, algorithm or selection threshold was
changed to obtain a favorable result. Registrations, supersession records,
all native observations and exact available bound source snapshots remain.

## Controls and identity

The final qualification passes actual lease/safe-point, allocation-refusal
cleanup, stable-owner switching, completed-queue replay refusal, active-call
refusal and real partial native cancellation controls. The performance runtime
ends with 24 allocations, 24 frees and zero live allocations. The short genuine
negative-gain control also retains its loss.

The tests additionally execute artifact path tampering with sealed loaded
bytes, restoration of a previously admitted version, a host exception only
after a real native item committed, producer mutation at the queue copy/hash
boundary, and the complete outer-wall negative-gain path. A controlled-clock
near-zero threshold regression is explicitly a policy unit test, not native
performance evidence. Logs and the independent guarded-proof review are in
`review/`.

Final runtime source SHA-256:
`ba2e36b68c6efe047e95c4f6b0e28ee08aab120365365470c13297af887c0e28`.
Final qualifier SHA-256:
`c24a059bde2b93547fac9a281e41f376a79bf23d7059f17ff8e6806b786bdc31`.
Source bindings are checked before and after final qualification.

The raw-tree archive includes the original native binaries; ELF copies outside
the archive are removed only after member-by-member SHA-256 verification.
Readable JSON, source snapshots, registrations, logs and this explanation remain
in the directory. See `RAW_MEMBERS.json` and `ARCHIVE.json` for archive identity.
