#!/usr/bin/env python3
"""Independent bounded counterexamples for the retained r1 candidate.

This runs only the candidate's AST-extracted Raw helper/cache and its tokenizer
pattern. It does not prepare proof sources, invoke Lean, or run qualification.
"""
import ast
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
import time
from types import SimpleNamespace


source_path = Path(__file__).with_name('core_syntax_structured_sources_r1.py')
source = source_path.read_bytes()
assert b"_TOKEN.sub('', text)" in source
assert b"decoded.decode(env[manifest['raw_name']]) == expected_tree" in source
pattern = re.compile(r'\s*(::|\+\+|\.[a-z]+|[A-Za-z][A-Za-z0-9_]*|[0-9]+|[\[\](),])')


def old_scan(text):
    pos = 0
    while pos < len(text):
        match = pattern.match(text, pos)
        if match is None:
            return False
        pos = match.end()
    return True


def candidate_scan(text):
    return pattern.sub('', text) == ''


timings = []
for size in (1000, 2000, 4000):
    text = '1' + ' ' * size
    row = {'trailing_spaces': size}
    for name, fn in (('legacy_match', old_scan), ('candidate_sub', candidate_scan)):
        started = time.monotonic_ns()
        accepted = fn(text)
        row[name] = {'accepted': accepted, 'wall_ns': time.monotonic_ns() - started}
    timings.append(row)


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


parsed = ast.parse(source)
selected = [node for node in parsed.body if isinstance(node, (ast.ClassDef, ast.FunctionDef))
            and node.name in ('_Raw', '_raw_value', '_ParsedRawValues')]
# Only values zero and seven are used; this bound stand-in cannot affect the
# alias counterexample. This is deliberately not a complete module verifier.
namespace = {'dataclass': dataclass, 'require': require,
             'old': SimpleNamespace(MAX_INTEGER=2 ** 64 - 1)}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(source_path), 'exec'), namespace)


class MutatingExpected(list):
    def __eq__(self, other):
        if type(other) is list:
            other[:] = list(self)
        return True


Raw = namespace['_Raw']
decode = namespace['_raw_value']
raw = Raw('arr', [Raw('num', 7)])
expected = MutatingExpected([0])
legacy_first = decode(raw) == expected
legacy_recheck = decode(raw) == [0]
cached = namespace['_ParsedRawValues']()
candidate_first = cached.decode(raw) == expected
candidate_recheck = cached.decode(raw) == [0]
assert legacy_first and candidate_first and not legacy_recheck and candidate_recheck
result = {
    'scope': 'Local bounded pure-parser counterexamples; not a proof-source preparation or qualification.',
    'python': sys.version,
    'source_snapshot': str(source_path), 'source_sha256': sha256(source).hexdigest(),
    'tokenizer_timings': timings,
    'mutable_output': {'legacy_first_comparison': legacy_first, 'legacy_recheck': legacy_recheck,
                       'candidate_first_comparison': candidate_first, 'candidate_recheck': candidate_recheck},
    'qualification_rerun': False,
}
target = Path(__file__).with_suffix('.json')
with target.open('x') as f:
    json.dump(result, f, sort_keys=True, indent=2)
    f.write('\n')
print(json.dumps(result, sort_keys=True))
