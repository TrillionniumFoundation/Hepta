"""Independent r1 counterexamples that the r2 verifier must reject.

No Lean or qualification is run. The full-verifier case uses the real source
builder and checker with a forged but rehashed Raw literal and hostile equality.
"""
from copy import deepcopy
from hashlib import sha256
import re
import unittest
from unittest.mock import patch

from tools import core_syntax_structured_sources as s


class MutatingExpectedDict(dict):
    def __eq__(self, other):
        if type(other) is dict:
            other.clear()
            other.update(dict(self))
        return True


class MutatingExpectedList(list):
    def __eq__(self, other):
        if type(other) is list:
            other[:] = list(self)
        return True


class StructuredSourceCostIndependentReviewTests(unittest.TestCase):
    def test_external_equality_cannot_poison_later_subtree_check(self):
        examples = [({'a': 1}, MutatingExpectedDict({'a': 1})),
                    ({'a': [1]}, {'a': MutatingExpectedList([1])})]
        for tree, hostile in examples:
            with self.subTest(tree=tree):
                data = s.canonical(tree)
                proposal = s.build_structured_input('review', tree, data,
                    s.NS + '.CacheEscapeReview', 'review', 'reviewCert')
                self.assertEqual(len(proposal.manifest['nodes']), 1)
                wanted = s.verify_structured_source(proposal.source, proposal.manifest, tree, data)
                self.assertEqual(s.verify_structured_source(proposal.source, proposal.manifest, hostile, data), wanted)
                changed = proposal.source.replace('.num 1', '.num 7', 1)
                self.assertNotEqual(changed, proposal.source)
                manifest = deepcopy(proposal.manifest)
                manifest['source_sha256'] = sha256(changed.encode()).hexdigest()
                expressions = {m[1]: m[2] for m in re.finditer(
                    r'(?m)^def ([A-Za-z][A-Za-z0-9_]*) : .+? := (.+)$', changed)}
                for row in manifest['definitions']:
                    row['rhs_sha256'] = sha256(expressions[row['name']].encode()).hexdigest()
                with self.assertRaisesRegex(ValueError, 'exact complete subtree alias binding'):
                    s.verify_structured_source(changed, manifest, hostile, data)

    def test_bad_whitespace_is_rejected_before_unanchored_token_extraction(self):
        # Counts API passes, not a flaky wall-time budget. The anchored possessive
        # regex structure supplies the no-prefix-rescan argument; this check
        # ensures invalid suffixes never reach a global findall/sub pass.
        original_coverage = s._TOKEN_COVERAGE
        original_tokens = s._TOKEN
        calls = {'coverage': 0, 'findall': 0}

        class Coverage:
            def fullmatch(self, text):
                calls['coverage'] += 1
                return original_coverage.fullmatch(text)

        class Tokens:
            def findall(self, text):
                calls['findall'] += 1
                return original_tokens.findall(text)

        bad = ('1' + ' ' * 16384,
               ' ' * 16384 + '# 1',
               '[1]' + '\u2003' * 16384 + '.',
               '1 ' + ' ' * 16384 + '# 2')
        with patch.object(s, '_TOKEN_COVERAGE', Coverage()), patch.object(s, '_TOKEN', Tokens()):
            for text in bad:
                with self.assertRaisesRegex(ValueError, 'unsupported emitted data syntax'):
                    s._parse_expression(text, {})
            self.assertEqual(calls, {'coverage': len(bad), 'findall': 0})
            self.assertEqual(s._parse_expression('[1,2]', {}), [1, 2])
            self.assertEqual(calls, {'coverage': len(bad) + 1, 'findall': 1})


if __name__ == '__main__':
    unittest.main()
