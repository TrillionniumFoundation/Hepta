import ast,hashlib,json
from pathlib import Path
ROOT=Path(__file__).parent
SOURCE=ROOT.parent/'checkout'
rows=[]
def raw(name,old=False):return ((ROOT/'origins' if old else SOURCE)/name).read_bytes()
def pin(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def ast_body(name,old=False):
    nodes=ast.parse(raw(name,old)).body
    if isinstance(nodes[0],ast.Expr) and isinstance(nodes[0].value,ast.Constant) and type(nodes[0].value.value) is str:nodes=nodes[1:]
    return nodes
def check(name,ok,detail):
    rows.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok:raise AssertionError(name)
name='hepta/hia_bounded_read_native.py'
check('adapter_only_module_documentation_changed',ast.dump(ast.Module(ast_body(name),[]),include_attributes=False)==ast.dump(ast.Module(ast_body(name,True),[]),include_attributes=False),{'before':pin(raw(name,True)),'after':pin(raw(name))})
name='hepta/hia_program_tools.py'
check('public_dispatch_matches_actual_r4b_bytes',raw(name)==raw(name,True),pin(raw(name)))
name='tools/generate_hia_bounded_read.py'
old,new=ast_body(name,True),ast_body(name)
old_def={x.name:x for x in old if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
new_def={x.name:x for x in new if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
for name,node in old_def.items():check('generator_definition_'+name,ast.dump(node,include_attributes=False)==ast.dump(new_def[name],include_attributes=False),{})
def assignments(nodes):
    return {tuple(ast.dump(t,include_attributes=False) for t in n.targets):ast.dump(n.value,include_attributes=False) for n in nodes if isinstance(n,ast.Assign)}
oa,na=assignments(old),assignments(new)
check('all_original_generator_assignments_unchanged',all(na.get(k)==v for k,v in oa.items()),{'original_assignments':len(oa)})
for file in ('source_common.py','reject_cases.py','lifetime_cases.py','permission_cases.py','filesystem_cases.py','original_eight.py','caller_observer.py'):
    name='tools/hia_bounded_read_checks/'+file
    old,new=ast_body(name,True),ast_body(name)
    def definitions(nodes):return {x.name:ast.dump(x,include_attributes=False) for x in nodes if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
    check('all_case_bodies_and_decorators_'+file,definitions(old)==definitions(new),{'definitions':sorted(definitions(old))})
    left,right=assignments(old),assignments(new)
    allowed={"Name(id='GENERATOR_SHA256', ctx=Store())","Name(id='BRIDGE_SHA256', ctx=Store())"} if file=='reject_cases.py' else set()
    differences=[list(k) for k in set(left)|set(right) if left.get(k)!=right.get(k)]
    check('case_binding_only_delta_'+file,all(len(k)==1 and k[0] in allowed for k in differences),{'changed_assignments':differences})
old=json.loads(raw('tools/hia_bounded_read_checks/populations.json',True));new=json.loads(raw('tools/hia_bounded_read_checks/populations.json'))
old.pop('status');new.pop('status')
check('complete_populations_and_original_budgets_unchanged',old==new,{'finite_cases':55,'original_methods':8,'CLI_children':7})
check('actual_HIA_bytes_unchanged',pin(raw('examples/hia_bootstrap/bounded_read.hiaasm'))['sha256']=='ecb7d81b3cf79b0a12a6c9f193c6a431f461a00870268e5a239154c7f42237ea',pin(raw('examples/hia_bootstrap/bounded_read.hiaasm')))
report={'schema':'hepta.hia.bounded-read-v80-mechanical-projection.v1','status':'SOURCE_PROJECTION_PASS','checks':rows,'native_executed':False,'current_v80_native_or_installation_claimed':False}
with (ROOT/'REPORT.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'status':report['status'],'checks':len(rows)}))
