
/home/runner/work/_temp/reduction-layout/linear/default.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <calculate>:
   0:	55                   	push   %rbp
   1:	41 56                	push   %r14
   3:	53                   	push   %rbx
   4:	89 f5                	mov    %esi,%ebp
   6:	48 89 fb             	mov    %rdi,%rbx
   9:	48 b8 02 01 01 01 01 	movabs $0x101010101010102,%rax
  10:	01 01 01 
  13:	48 39 c7             	cmp    %rax,%rdi
  16:	73 35                	jae    4d <calculate+0x4d>
  18:	48 85 db             	test   %rbx,%rbx
  1b:	0f 84 27 01 00 00    	je     148 <calculate+0x148>
  21:	48 89 df             	mov    %rbx,%rdi
  24:	e8 00 00 00 00       	call   29 <calculate+0x29>
			25: R_X86_64_PLT32	malloc-0x4
  29:	48 85 c0             	test   %rax,%rax
  2c:	0f 84 1e 01 00 00    	je     150 <calculate+0x150>
  32:	48 b9 f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rcx
  39:	ff ff 01 
  3c:	48 83 fb 03          	cmp    $0x3,%rbx
  40:	0f 87 15 01 00 00    	ja     15b <calculate+0x15b>
  46:	31 d2                	xor    %edx,%edx
  48:	e9 d2 01 00 00       	jmp    21f <calculate+0x21f>
  4d:	48 85 db             	test   %rbx,%rbx
  50:	78 28                	js     7a <calculate+0x7a>
  52:	48 89 df             	mov    %rbx,%rdi
  55:	e8 00 00 00 00       	call   5a <calculate+0x5a>
			56: R_X86_64_PLT32	malloc-0x4
  5a:	48 85 c0             	test   %rax,%rax
  5d:	74 1b                	je     7a <calculate+0x7a>
  5f:	b1 01                	mov    $0x1,%cl
  61:	f6 c1 01             	test   $0x1,%cl
  64:	75 1d                	jne    83 <calculate+0x83>
  66:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
  6c:	48 85 c0             	test   %rax,%rax
  6f:	0f 85 a0 02 00 00    	jne    315 <calculate+0x315>
  75:	e9 a3 02 00 00       	jmp    31d <calculate+0x31d>
  7a:	31 c0                	xor    %eax,%eax
  7c:	31 c9                	xor    %ecx,%ecx
  7e:	f6 c1 01             	test   $0x1,%cl
  81:	74 e3                	je     66 <calculate+0x66>
  83:	48 89 d9             	mov    %rbx,%rcx
  86:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
  8a:	66 0f 6e c5          	movd   %ebp,%xmm0
  8e:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  92:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  97:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
  9c:	66 0f 6f 0d 00 00 00 	movdqa 0x0(%rip),%xmm1        # a4 <calculate+0xa4>
  a3:	00 
			a0: R_X86_64_PC32	.LCPI0_0-0x4
  a4:	31 d2                	xor    %edx,%edx
  a6:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # ae <calculate+0xae>
  ad:	00 
			aa: R_X86_64_PC32	.LCPI0_1-0x4
  ae:	66 90                	xchg   %ax,%ax
  b0:	66 0f 6f d9          	movdqa %xmm1,%xmm3
  b4:	66 0f fc d8          	paddb  %xmm0,%xmm3
  b8:	f3 0f 7f 1c 10       	movdqu %xmm3,(%rax,%rdx,1)
  bd:	48 83 c2 10          	add    $0x10,%rdx
  c1:	66 0f fc ca          	paddb  %xmm2,%xmm1
  c5:	48 39 d1             	cmp    %rdx,%rcx
  c8:	75 e6                	jne    b0 <calculate+0xb0>
  ca:	48 39 cb             	cmp    %rcx,%rbx
  cd:	0f 84 1c 02 00 00    	je     2ef <calculate+0x2ef>
  d3:	f6 c3 0c             	test   $0xc,%bl
  d6:	0f 84 f5 01 00 00    	je     2d1 <calculate+0x2d1>
  dc:	48 89 da             	mov    %rbx,%rdx
  df:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
  e3:	66 0f 6e c1          	movd   %ecx,%xmm0
  e7:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  eb:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  f0:	66 0f eb 05 00 00 00 	por    0x0(%rip),%xmm0        # f8 <calculate+0xf8>
  f7:	00 
			f4: R_X86_64_PC32	.LCPI0_2-0x4
  f8:	40 0f b6 f5          	movzbl %bpl,%esi
  fc:	66 0f 6e ce          	movd   %esi,%xmm1
 100:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 104:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 109:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 111 <calculate+0x111>
 110:	00 
			10d: R_X86_64_PC32	.LCPI0_3-0x4
 111:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 118:	0f 1f 84 00 00 00 00 
 11f:	00 
 120:	66 0f 6f d8          	movdqa %xmm0,%xmm3
 124:	66 0f fc d9          	paddb  %xmm1,%xmm3
 128:	66 0f 7e 1c 08       	movd   %xmm3,(%rax,%rcx,1)
 12d:	48 83 c1 04          	add    $0x4,%rcx
 131:	66 0f fc c2          	paddb  %xmm2,%xmm0
 135:	48 39 ca             	cmp    %rcx,%rdx
 138:	75 e6                	jne    120 <calculate+0x120>
 13a:	48 39 d3             	cmp    %rdx,%rbx
 13d:	0f 85 91 01 00 00    	jne    2d4 <calculate+0x2d4>
 143:	e9 a7 01 00 00       	jmp    2ef <calculate+0x2ef>
 148:	45 31 f6             	xor    %r14d,%r14d
 14b:	e9 cd 01 00 00       	jmp    31d <calculate+0x31d>
 150:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
 156:	e9 c2 01 00 00       	jmp    31d <calculate+0x31d>
 15b:	40 0f b6 f5          	movzbl %bpl,%esi
 15f:	48 83 fb 10          	cmp    $0x10,%rbx
 163:	73 04                	jae    169 <calculate+0x169>
 165:	31 d2                	xor    %edx,%edx
 167:	eb 5f                	jmp    1c8 <calculate+0x1c8>
 169:	48 89 da             	mov    %rbx,%rdx
 16c:	48 21 ca             	and    %rcx,%rdx
 16f:	66 0f 6e c6          	movd   %esi,%xmm0
 173:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 177:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 17c:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
 181:	66 0f 6f 0d 00 00 00 	movdqa 0x0(%rip),%xmm1        # 189 <calculate+0x189>
 188:	00 
			185: R_X86_64_PC32	.LCPI0_0-0x4
 189:	31 ff                	xor    %edi,%edi
 18b:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 193 <calculate+0x193>
 192:	00 
			18f: R_X86_64_PC32	.LCPI0_1-0x4
 193:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 19a:	84 00 00 00 00 00 
 1a0:	66 0f 6f d9          	movdqa %xmm1,%xmm3
 1a4:	66 0f fc d8          	paddb  %xmm0,%xmm3
 1a8:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
 1ad:	48 83 c7 10          	add    $0x10,%rdi
 1b1:	66 0f fc ca          	paddb  %xmm2,%xmm1
 1b5:	48 39 fa             	cmp    %rdi,%rdx
 1b8:	75 e6                	jne    1a0 <calculate+0x1a0>
 1ba:	48 39 d3             	cmp    %rdx,%rbx
 1bd:	0f 84 7c 00 00 00    	je     23f <calculate+0x23f>
 1c3:	f6 c3 0c             	test   $0xc,%bl
 1c6:	74 57                	je     21f <calculate+0x21f>
 1c8:	48 89 d7             	mov    %rdx,%rdi
 1cb:	48 8d 51 0c          	lea    0xc(%rcx),%rdx
 1cf:	48 21 da             	and    %rbx,%rdx
 1d2:	66 0f 6e c7          	movd   %edi,%xmm0
 1d6:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 1da:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 1df:	66 0f eb 05 00 00 00 	por    0x0(%rip),%xmm0        # 1e7 <calculate+0x1e7>
 1e6:	00 
			1e3: R_X86_64_PC32	.LCPI0_2-0x4
 1e7:	66 0f 6e ce          	movd   %esi,%xmm1
 1eb:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 1ef:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 1f4:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 1fc <calculate+0x1fc>
 1fb:	00 
			1f8: R_X86_64_PC32	.LCPI0_3-0x4
 1fc:	0f 1f 40 00          	nopl   0x0(%rax)
 200:	66 0f 6f d8          	movdqa %xmm0,%xmm3
 204:	66 0f fc d9          	paddb  %xmm1,%xmm3
 208:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
 20d:	48 83 c7 04          	add    $0x4,%rdi
 211:	66 0f fc c2          	paddb  %xmm2,%xmm0
 215:	48 39 fa             	cmp    %rdi,%rdx
 218:	75 e6                	jne    200 <calculate+0x200>
 21a:	48 39 d3             	cmp    %rdx,%rbx
 21d:	74 20                	je     23f <calculate+0x23f>
 21f:	89 ee                	mov    %ebp,%esi
 221:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 228:	0f 1f 84 00 00 00 00 
 22f:	00 
 230:	8d 3c 16             	lea    (%rsi,%rdx,1),%edi
 233:	40 88 3c 10          	mov    %dil,(%rax,%rdx,1)
 237:	48 ff c2             	inc    %rdx
 23a:	48 39 d3             	cmp    %rdx,%rbx
 23d:	75 f1                	jne    230 <calculate+0x230>
 23f:	89 da                	mov    %ebx,%edx
 241:	83 e2 07             	and    $0x7,%edx
 244:	48 83 fb 08          	cmp    $0x8,%rbx
 248:	73 07                	jae    251 <calculate+0x251>
 24a:	31 c9                	xor    %ecx,%ecx
 24c:	45 31 f6             	xor    %r14d,%r14d
 24f:	eb 59                	jmp    2aa <calculate+0x2aa>
 251:	48 83 c1 08          	add    $0x8,%rcx
 255:	48 21 cb             	and    %rcx,%rbx
 258:	31 c9                	xor    %ecx,%ecx
 25a:	45 31 f6             	xor    %r14d,%r14d
 25d:	0f 1f 00             	nopl   (%rax)
 260:	0f b6 34 08          	movzbl (%rax,%rcx,1),%esi
 264:	4c 01 f6             	add    %r14,%rsi
 267:	0f b6 7c 08 01       	movzbl 0x1(%rax,%rcx,1),%edi
 26c:	44 0f b6 44 08 02    	movzbl 0x2(%rax,%rcx,1),%r8d
 272:	49 01 f8             	add    %rdi,%r8
 275:	49 01 f0             	add    %rsi,%r8
 278:	0f b6 74 08 03       	movzbl 0x3(%rax,%rcx,1),%esi
 27d:	0f b6 7c 08 04       	movzbl 0x4(%rax,%rcx,1),%edi
 282:	48 01 f7             	add    %rsi,%rdi
 285:	0f b6 74 08 05       	movzbl 0x5(%rax,%rcx,1),%esi
 28a:	48 01 fe             	add    %rdi,%rsi
 28d:	4c 01 c6             	add    %r8,%rsi
 290:	0f b6 7c 08 06       	movzbl 0x6(%rax,%rcx,1),%edi
 295:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
 29b:	49 01 fe             	add    %rdi,%r14
 29e:	49 01 f6             	add    %rsi,%r14
 2a1:	48 83 c1 08          	add    $0x8,%rcx
 2a5:	48 39 cb             	cmp    %rcx,%rbx
 2a8:	75 b6                	jne    260 <calculate+0x260>
 2aa:	48 85 d2             	test   %rdx,%rdx
 2ad:	74 66                	je     315 <calculate+0x315>
 2af:	48 89 c6             	mov    %rax,%rsi
 2b2:	48 01 ce             	add    %rcx,%rsi
 2b5:	31 c9                	xor    %ecx,%ecx
 2b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 2be:	00 00 
 2c0:	0f b6 3c 0e          	movzbl (%rsi,%rcx,1),%edi
 2c4:	49 01 fe             	add    %rdi,%r14
 2c7:	48 ff c1             	inc    %rcx
 2ca:	48 39 ca             	cmp    %rcx,%rdx
 2cd:	75 f1                	jne    2c0 <calculate+0x2c0>
 2cf:	eb 44                	jmp    315 <calculate+0x315>
 2d1:	48 89 ca             	mov    %rcx,%rdx
 2d4:	89 e9                	mov    %ebp,%ecx
 2d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 2dd:	00 00 00 
 2e0:	8d 34 11             	lea    (%rcx,%rdx,1),%esi
 2e3:	40 88 34 10          	mov    %sil,(%rax,%rdx,1)
 2e7:	48 ff c2             	inc    %rdx
 2ea:	48 39 d3             	cmp    %rdx,%rbx
 2ed:	75 f1                	jne    2e0 <calculate+0x2e0>
 2ef:	31 c9                	xor    %ecx,%ecx
 2f1:	45 31 f6             	xor    %r14d,%r14d
 2f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 2fb:	00 00 00 00 00 
 300:	4c 89 f2             	mov    %r14,%rdx
 303:	44 0f b6 34 08       	movzbl (%rax,%rcx,1),%r14d
 308:	49 01 d6             	add    %rdx,%r14
 30b:	72 18                	jb     325 <calculate+0x325>
 30d:	48 ff c1             	inc    %rcx
 310:	48 39 cb             	cmp    %rcx,%rbx
 313:	75 eb                	jne    300 <calculate+0x300>
 315:	48 89 c7             	mov    %rax,%rdi
 318:	e8 00 00 00 00       	call   31d <calculate+0x31d>
			319: R_X86_64_PLT32	free-0x4
 31d:	4c 89 f0             	mov    %r14,%rax
 320:	5b                   	pop    %rbx
 321:	41 5e                	pop    %r14
 323:	5d                   	pop    %rbp
 324:	c3                   	ret
 325:	e8 00 00 00 00       	call   32a <.LCPI0_3+0x2fa>
			326: R_X86_64_PLT32	abort-0x4
