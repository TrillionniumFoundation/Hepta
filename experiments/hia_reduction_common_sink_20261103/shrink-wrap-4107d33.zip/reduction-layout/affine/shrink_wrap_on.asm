
/home/runner/work/_temp/reduction-layout/affine/shrink_wrap_on.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <calculate>:
   0:	55                   	push   %rbp
   1:	41 56                	push   %r14
   3:	53                   	push   %rbx
   4:	89 f5                	mov    %esi,%ebp
   6:	48 89 fb             	mov    %rdi,%rbx
   9:	48 b8 02 01 01 01 01 	movabs $0x101010101010102,%rax
  10:	01 01 01 
  13:	48 39 c7             	cmp    %rax,%rdi
  16:	73 38                	jae    50 <calculate+0x50>
  18:	48 85 db             	test   %rbx,%rbx
  1b:	0f 84 77 01 00 00    	je     198 <calculate+0x198>
  21:	48 89 df             	mov    %rbx,%rdi
  24:	e8 00 00 00 00       	call   29 <calculate+0x29>
			25: R_X86_64_PLT32	malloc-0x4
  29:	48 85 c0             	test   %rax,%rax
  2c:	0f 84 6e 01 00 00    	je     1a0 <calculate+0x1a0>
  32:	48 89 c7             	mov    %rax,%rdi
  35:	48 ba f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rdx
  3c:	ff ff 01 
  3f:	48 83 fb 03          	cmp    $0x3,%rbx
  43:	0f 87 62 01 00 00    	ja     1ab <calculate+0x1ab>
  49:	31 c9                	xor    %ecx,%ecx
  4b:	e9 7f 02 00 00       	jmp    2cf <calculate+0x2cf>
  50:	48 85 db             	test   %rbx,%rbx
  53:	78 2a                	js     7f <calculate+0x7f>
  55:	48 89 df             	mov    %rbx,%rdi
  58:	e8 00 00 00 00       	call   5d <calculate+0x5d>
			59: R_X86_64_PLT32	malloc-0x4
  5d:	48 85 c0             	test   %rax,%rax
  60:	74 1d                	je     7f <calculate+0x7f>
  62:	48 89 c7             	mov    %rax,%rdi
  65:	b0 01                	mov    $0x1,%al
  67:	a8 01                	test   $0x1,%al
  69:	75 1c                	jne    87 <calculate+0x87>
  6b:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
  71:	48 85 ff             	test   %rdi,%rdi
  74:	0f 85 4b 03 00 00    	jne    3c5 <calculate+0x3c5>
  7a:	e9 4b 03 00 00       	jmp    3ca <calculate+0x3ca>
  7f:	31 ff                	xor    %edi,%edi
  81:	31 c0                	xor    %eax,%eax
  83:	a8 01                	test   $0x1,%al
  85:	74 e4                	je     6b <calculate+0x6b>
  87:	48 89 d8             	mov    %rbx,%rax
  8a:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
  8e:	66 0f 6e c5          	movd   %ebp,%xmm0
  92:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  96:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  9b:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
  a0:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # a8 <calculate+0xa8>
  a7:	00 
			a4: R_X86_64_PC32	.LCPI0_0-0x4
  a8:	31 c9                	xor    %ecx,%ecx
  aa:	66 0f 6f d9          	movdqa %xmm1,%xmm3
  ae:	66 0f 68 db          	punpckhbw %xmm3,%xmm3
  b2:	66 0f 6f 05 00 00 00 	movdqa 0x0(%rip),%xmm0        # ba <calculate+0xba>
  b9:	00 
			b6: R_X86_64_PC32	.LCPI0_1-0x4
  ba:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
  be:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # c6 <calculate+0xc6>
  c5:	00 
			c2: R_X86_64_PC32	.LCPI0_2-0x4
  c6:	66 0f 6f 2d 00 00 00 	movdqa 0x0(%rip),%xmm5        # ce <calculate+0xce>
  cd:	00 
			ca: R_X86_64_PC32	.LCPI0_3-0x4
  ce:	66 90                	xchg   %ax,%ax
  d0:	66 0f 6f f2          	movdqa %xmm2,%xmm6
  d4:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
  d8:	66 0f d5 f3          	pmullw %xmm3,%xmm6
  dc:	66 0f db f0          	pand   %xmm0,%xmm6
  e0:	66 0f 6f fa          	movdqa %xmm2,%xmm7
  e4:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
  e8:	66 0f d5 f9          	pmullw %xmm1,%xmm7
  ec:	66 0f db f8          	pand   %xmm0,%xmm7
  f0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
  f4:	66 0f fc fc          	paddb  %xmm4,%xmm7
  f8:	f3 0f 7f 3c 0f       	movdqu %xmm7,(%rdi,%rcx,1)
  fd:	48 83 c1 10          	add    $0x10,%rcx
 101:	66 0f fc d5          	paddb  %xmm5,%xmm2
 105:	48 39 c8             	cmp    %rcx,%rax
 108:	75 c6                	jne    d0 <calculate+0xd0>
 10a:	48 39 c3             	cmp    %rax,%rbx
 10d:	0f 84 8b 02 00 00    	je     39e <calculate+0x39e>
 113:	f6 c3 0c             	test   $0xc,%bl
 116:	0f 84 65 02 00 00    	je     381 <calculate+0x381>
 11c:	48 89 d9             	mov    %rbx,%rcx
 11f:	66 0f 6e c8          	movd   %eax,%xmm1
 123:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 127:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 12c:	66 0f eb 0d 00 00 00 	por    0x0(%rip),%xmm1        # 134 <calculate+0x134>
 133:	00 
			130: R_X86_64_PC32	.LCPI0_4-0x4
 134:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
 138:	40 0f b6 d5          	movzbl %bpl,%edx
 13c:	66 0f 6e d2          	movd   %edx,%xmm2
 140:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
 144:	f2 0f 70 d2 00       	pshuflw $0x0,%xmm2,%xmm2
 149:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
 14d:	66 0f 6f 1d 00 00 00 	movdqa 0x0(%rip),%xmm3        # 155 <calculate+0x155>
 154:	00 
			151: R_X86_64_PC32	.LCPI0_5-0x4
 155:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 15d <calculate+0x15d>
 15c:	00 
			159: R_X86_64_PC32	.LCPI0_6-0x4
 15d:	0f 1f 00             	nopl   (%rax)
 160:	66 0f 6f e9          	movdqa %xmm1,%xmm5
 164:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
 168:	66 0f d5 ea          	pmullw %xmm2,%xmm5
 16c:	66 0f db e8          	pand   %xmm0,%xmm5
 170:	66 0f 67 ed          	packuswb %xmm5,%xmm5
 174:	66 0f fc eb          	paddb  %xmm3,%xmm5
 178:	66 0f 7e 2c 07       	movd   %xmm5,(%rdi,%rax,1)
 17d:	48 83 c0 04          	add    $0x4,%rax
 181:	66 0f fc cc          	paddb  %xmm4,%xmm1
 185:	48 39 c1             	cmp    %rax,%rcx
 188:	75 d6                	jne    160 <calculate+0x160>
 18a:	48 39 cb             	cmp    %rcx,%rbx
 18d:	0f 85 f1 01 00 00    	jne    384 <calculate+0x384>
 193:	e9 06 02 00 00       	jmp    39e <calculate+0x39e>
 198:	45 31 f6             	xor    %r14d,%r14d
 19b:	e9 2a 02 00 00       	jmp    3ca <calculate+0x3ca>
 1a0:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
 1a6:	e9 1f 02 00 00       	jmp    3ca <calculate+0x3ca>
 1ab:	40 0f b6 c5          	movzbl %bpl,%eax
 1af:	48 83 fb 10          	cmp    $0x10,%rbx
 1b3:	73 07                	jae    1bc <calculate+0x1bc>
 1b5:	31 c9                	xor    %ecx,%ecx
 1b7:	e9 9c 00 00 00       	jmp    258 <calculate+0x258>
 1bc:	48 89 d9             	mov    %rbx,%rcx
 1bf:	48 21 d1             	and    %rdx,%rcx
 1c2:	66 0f 6e c0          	movd   %eax,%xmm0
 1c6:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 1ca:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 1cf:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
 1d4:	66 0f 6f 0d 00 00 00 	movdqa 0x0(%rip),%xmm1        # 1dc <calculate+0x1dc>
 1db:	00 
			1d8: R_X86_64_PC32	.LCPI0_0-0x4
 1dc:	31 f6                	xor    %esi,%esi
 1de:	66 0f 6f d0          	movdqa %xmm0,%xmm2
 1e2:	66 0f 68 d2          	punpckhbw %xmm2,%xmm2
 1e6:	66 0f 6f 1d 00 00 00 	movdqa 0x0(%rip),%xmm3        # 1ee <calculate+0x1ee>
 1ed:	00 
			1ea: R_X86_64_PC32	.LCPI0_1-0x4
 1ee:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 1f2:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 1fa <calculate+0x1fa>
 1f9:	00 
			1f6: R_X86_64_PC32	.LCPI0_2-0x4
 1fa:	66 0f 6f 2d 00 00 00 	movdqa 0x0(%rip),%xmm5        # 202 <calculate+0x202>
 201:	00 
			1fe: R_X86_64_PC32	.LCPI0_3-0x4
 202:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 209:	1f 84 00 00 00 00 00 
 210:	66 0f 6f f1          	movdqa %xmm1,%xmm6
 214:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
 218:	66 0f d5 f2          	pmullw %xmm2,%xmm6
 21c:	66 0f db f3          	pand   %xmm3,%xmm6
 220:	66 0f 6f f9          	movdqa %xmm1,%xmm7
 224:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
 228:	66 0f d5 f8          	pmullw %xmm0,%xmm7
 22c:	66 0f db fb          	pand   %xmm3,%xmm7
 230:	66 0f 67 fe          	packuswb %xmm6,%xmm7
 234:	66 0f fc fc          	paddb  %xmm4,%xmm7
 238:	f3 0f 7f 3c 37       	movdqu %xmm7,(%rdi,%rsi,1)
 23d:	48 83 c6 10          	add    $0x10,%rsi
 241:	66 0f fc cd          	paddb  %xmm5,%xmm1
 245:	48 39 f1             	cmp    %rsi,%rcx
 248:	75 c6                	jne    210 <calculate+0x210>
 24a:	48 39 cb             	cmp    %rcx,%rbx
 24d:	0f 84 9b 00 00 00    	je     2ee <calculate+0x2ee>
 253:	f6 c3 0c             	test   $0xc,%bl
 256:	74 77                	je     2cf <calculate+0x2cf>
 258:	48 89 ce             	mov    %rcx,%rsi
 25b:	48 8d 4a 0c          	lea    0xc(%rdx),%rcx
 25f:	66 0f 6e c6          	movd   %esi,%xmm0
 263:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 267:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 26c:	66 0f eb 05 00 00 00 	por    0x0(%rip),%xmm0        # 274 <calculate+0x274>
 273:	00 
			270: R_X86_64_PC32	.LCPI0_4-0x4
 274:	48 21 d9             	and    %rbx,%rcx
 277:	66 0f 6e c8          	movd   %eax,%xmm1
 27b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 27f:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 284:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 288:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 290 <calculate+0x290>
 28f:	00 
			28c: R_X86_64_PC32	.LCPI0_1-0x4
 290:	66 0f 6f 1d 00 00 00 	movdqa 0x0(%rip),%xmm3        # 298 <calculate+0x298>
 297:	00 
			294: R_X86_64_PC32	.LCPI0_5-0x4
 298:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 2a0 <calculate+0x2a0>
 29f:	00 
			29c: R_X86_64_PC32	.LCPI0_6-0x4
 2a0:	66 0f 6f e8          	movdqa %xmm0,%xmm5
 2a4:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
 2a8:	66 0f d5 e9          	pmullw %xmm1,%xmm5
 2ac:	66 0f db ea          	pand   %xmm2,%xmm5
 2b0:	66 0f 67 ed          	packuswb %xmm5,%xmm5
 2b4:	66 0f fc eb          	paddb  %xmm3,%xmm5
 2b8:	66 0f 7e 2c 37       	movd   %xmm5,(%rdi,%rsi,1)
 2bd:	48 83 c6 04          	add    $0x4,%rsi
 2c1:	66 0f fc c4          	paddb  %xmm4,%xmm0
 2c5:	48 39 f1             	cmp    %rsi,%rcx
 2c8:	75 d6                	jne    2a0 <calculate+0x2a0>
 2ca:	48 39 cb             	cmp    %rcx,%rbx
 2cd:	74 1f                	je     2ee <calculate+0x2ee>
 2cf:	89 c8                	mov    %ecx,%eax
 2d1:	40 f6 e5             	mul    %bpl
 2d4:	04 11                	add    $0x11,%al
 2d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 2dd:	00 00 00 
 2e0:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
 2e3:	48 ff c1             	inc    %rcx
 2e6:	40 00 e8             	add    %bpl,%al
 2e9:	48 39 cb             	cmp    %rcx,%rbx
 2ec:	75 f2                	jne    2e0 <calculate+0x2e0>
 2ee:	89 d8                	mov    %ebx,%eax
 2f0:	83 e0 07             	and    $0x7,%eax
 2f3:	48 83 fb 08          	cmp    $0x8,%rbx
 2f7:	73 07                	jae    300 <calculate+0x300>
 2f9:	31 c9                	xor    %ecx,%ecx
 2fb:	45 31 f6             	xor    %r14d,%r14d
 2fe:	eb 5a                	jmp    35a <calculate+0x35a>
 300:	48 83 c2 08          	add    $0x8,%rdx
 304:	48 21 d3             	and    %rdx,%rbx
 307:	31 c9                	xor    %ecx,%ecx
 309:	45 31 f6             	xor    %r14d,%r14d
 30c:	0f 1f 40 00          	nopl   0x0(%rax)
 310:	0f b6 14 0f          	movzbl (%rdi,%rcx,1),%edx
 314:	4c 01 f2             	add    %r14,%rdx
 317:	0f b6 74 0f 01       	movzbl 0x1(%rdi,%rcx,1),%esi
 31c:	44 0f b6 44 0f 02    	movzbl 0x2(%rdi,%rcx,1),%r8d
 322:	49 01 f0             	add    %rsi,%r8
 325:	49 01 d0             	add    %rdx,%r8
 328:	0f b6 54 0f 03       	movzbl 0x3(%rdi,%rcx,1),%edx
 32d:	0f b6 74 0f 04       	movzbl 0x4(%rdi,%rcx,1),%esi
 332:	48 01 d6             	add    %rdx,%rsi
 335:	0f b6 54 0f 05       	movzbl 0x5(%rdi,%rcx,1),%edx
 33a:	48 01 f2             	add    %rsi,%rdx
 33d:	4c 01 c2             	add    %r8,%rdx
 340:	0f b6 74 0f 06       	movzbl 0x6(%rdi,%rcx,1),%esi
 345:	44 0f b6 74 0f 07    	movzbl 0x7(%rdi,%rcx,1),%r14d
 34b:	49 01 f6             	add    %rsi,%r14
 34e:	49 01 d6             	add    %rdx,%r14
 351:	48 83 c1 08          	add    $0x8,%rcx
 355:	48 39 cb             	cmp    %rcx,%rbx
 358:	75 b6                	jne    310 <calculate+0x310>
 35a:	48 85 c0             	test   %rax,%rax
 35d:	74 66                	je     3c5 <calculate+0x3c5>
 35f:	48 89 fa             	mov    %rdi,%rdx
 362:	48 01 ca             	add    %rcx,%rdx
 365:	31 c9                	xor    %ecx,%ecx
 367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 36e:	00 00 
 370:	0f b6 34 0a          	movzbl (%rdx,%rcx,1),%esi
 374:	49 01 f6             	add    %rsi,%r14
 377:	48 ff c1             	inc    %rcx
 37a:	48 39 c8             	cmp    %rcx,%rax
 37d:	75 f1                	jne    370 <calculate+0x370>
 37f:	eb 44                	jmp    3c5 <calculate+0x3c5>
 381:	48 89 c1             	mov    %rax,%rcx
 384:	89 c8                	mov    %ecx,%eax
 386:	40 f6 e5             	mul    %bpl
 389:	04 11                	add    $0x11,%al
 38b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 390:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
 393:	48 ff c1             	inc    %rcx
 396:	40 00 e8             	add    %bpl,%al
 399:	48 39 cb             	cmp    %rcx,%rbx
 39c:	75 f2                	jne    390 <calculate+0x390>
 39e:	31 c0                	xor    %eax,%eax
 3a0:	45 31 f6             	xor    %r14d,%r14d
 3a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 3aa:	84 00 00 00 00 00 
 3b0:	4c 89 f1             	mov    %r14,%rcx
 3b3:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
 3b8:	49 01 ce             	add    %rcx,%r14
 3bb:	72 15                	jb     3d2 <calculate+0x3d2>
 3bd:	48 ff c0             	inc    %rax
 3c0:	48 39 c3             	cmp    %rax,%rbx
 3c3:	75 eb                	jne    3b0 <calculate+0x3b0>
 3c5:	e8 00 00 00 00       	call   3ca <calculate+0x3ca>
			3c6: R_X86_64_PLT32	free-0x4
 3ca:	4c 89 f0             	mov    %r14,%rax
 3cd:	5b                   	pop    %rbx
 3ce:	41 5e                	pop    %r14
 3d0:	5d                   	pop    %rbp
 3d1:	c3                   	ret
 3d2:	e8 00 00 00 00       	call   3d7 <.LCPI0_6+0x377>
			3d3: R_X86_64_PLT32	abort-0x4
