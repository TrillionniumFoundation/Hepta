import sys, pathlib, unittest, os
sys.path.insert(0, sys.argv[1])
from tools import hia_artifact_publication_custody as custody
session = custody.Session(pathlib.Path(sys.argv[2]))
session.install()
directory = custody.temporary_directory(prefix='publication-custody-original-fs-')
fixture = pathlib.Path(directory.name)
(fixture / 'full-bytes').write_bytes(b'external\x00fixture\xff')
os.link(fixture / 'full-bytes', fixture / 'hardlink')
os.mkfifo(fixture / 'fifo')
(fixture / 'symlink').symlink_to('/not-read-outside-fixture')
directory.cleanup()
session.restore()
session.finish(unittest.TestResult())
