
import json,os,subprocess,sys,unittest
from pathlib import Path
from tests import test_hia_agent_entry as original
manifest,report_path=sys.argv[1:3]
actual_run=subprocess.run;injected=[]
guard="import argparse\nfrom hepta import cli\ndef reject(*args,**kwargs):raise AssertionError('retained ordinary CLI/parser entered')\ncli._reference_hia_main=reject\nargparse.ArgumentParser=reject\n"
def run(argv,*args,**kwargs):
 if type(argv) is list and len(argv)>3 and argv[:3]==[sys.executable,'-B','-c'] and argv[3]==original.CHILD:
  argv=list(argv);argv[3]=guard+argv[3]
  env=dict(kwargs['env']);env['HEPTA_HIA_CLI_MANIFEST']=manifest;kwargs['env']=env
  injected.append(json.loads(argv[4]))
 return actual_run(argv,*args,**kwargs)
subprocess.run=run
suite=unittest.defaultTestLoader.loadTestsFromModule(original)
def flatten(value):
 for member in value:
  if isinstance(member,unittest.TestSuite):yield from flatten(member)
  else:yield member
loaded=[case.id() for case in flatten(suite)];executed=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):executed.append(test.id());super().startTest(test)
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
anomalies={'failures':[(t.id(),s) for t,s in result.failures],'errors':[(t.id(),s) for t,s in result.errors],'skipped':[(t.id(),s) for t,s in result.skipped],'expected_failures':[(t.id(),s) for t,s in result.expectedFailures],'unexpected_successes':[t.id() for t in result.unexpectedSuccesses]}
passed=bool(loaded) and len(set(loaded))==len(loaded) and loaded==executed and result.testsRun==len(loaded) and bool(injected) and not any(anomalies.values())
report={'schema':'hia.cli.original-agent-entry-native-selection.v1','status':'PASS' if passed else 'FAIL','loaded_test_ids':loaded,'executed_test_ids':executed,'tests_run':result.testsRun,'selected_child_argv':injected,**anomalies}
Path(report_path).write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
raise SystemExit(0 if passed else 1)
