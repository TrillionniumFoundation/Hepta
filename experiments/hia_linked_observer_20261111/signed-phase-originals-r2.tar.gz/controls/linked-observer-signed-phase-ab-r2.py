"""Fresh r2 setup for the original full A/B driver; original r1 is retained."""
from pathlib import Path
import runpy,sys

# r1 failed before any phase because its parent output directory was absent.
# Only create that new private parent; do not alter the exact phase driver.
out=Path(sys.argv[2]).resolve()
out.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
runpy.run_path('/workspace/scratch/e26ed3e2edcf/linked-observer-signed-phase-ab.py',run_name='__main__')
