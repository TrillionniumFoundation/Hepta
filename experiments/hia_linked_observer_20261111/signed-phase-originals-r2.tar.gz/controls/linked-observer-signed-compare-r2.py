"""Compare every original semantic field, retaining added capture provenance."""
from pathlib import Path
import json,hashlib

root=Path('/workspace/scratch/e26ed3e2edcf/linked-observer-signed-ab-r2')
a=json.loads((root/'original/signed-native.json').read_bytes())
b=json.loads((root/'native/signed-native.json').read_bytes())
assert a['source_manifest']==b['source_manifest']
assert a['feature_source_sha256']==b['feature_source_sha256']
assert a['reference_sha256']==b['reference_sha256']
assert a['reference_counts']==b['reference_counts']
assert a['checks']==b['checks']
old={r['name']:r for r in a['receipts']};new={r['name']:r for r in b['receipts']}
assert set(old)==set(new) and len(old)==458
additions=[]
for name,x in old.items():
    y=new[name]
    for key in ('format','input_sha256','artifact_sha256'):
        assert x[key]==y[key],(name,key)
    lhs=x['semantic_observation'];rhs=y['semantic_observation']
    assert set(lhs)==set(rhs)
    for key in lhs:
        if key=='shared_output_observation':
            assert all(rhs[key].get(k)==v for k,v in lhs[key].items()),(name,key)
            extra=set(rhs[key])-set(lhs[key])
            if extra:
                assert x['format']=='linked-selfhost' and extra=={'capture_origin'}
                assert rhs[key]['capture_origin']=='parent-owned size-sealed memfd, mapped by actual native child'
                additions.append({'case':name,'field':'shared_output_observation.capture_origin',
                                  'value':rhs[key]['capture_origin']})
        else:
            assert lhs[key]==rhs[key],(name,key)
assert len(a['checks'])==len(b['checks'])==326
assert len(additions)==52
summary={'schema':'hia.linked-observer.signed-phase-comparison.v1',
 'scope':'DEVELOPMENT ONLY; one nonprofiled full original signed phase per fresh process; not cold180 qualification',
 'source_files':a['feature_source_sha256'],'source_before_after_equal':True,
 'reference_sha256':a['reference_sha256'],'reference_counts':a['reference_counts'],
 'actual_invocations_each':458,'checks_each':326,'all_original_check_IDs_and_booleans_equal':True,
 'every_existing_semantic_field_and_payload_sha256_equal':True,
 'exact_structural_equality':False,'added_provenance_fields':additions,
 'original_phase_wall_ns':a['wall_elapsed_ns'],'new_phase_wall_ns':b['wall_elapsed_ns'],
 'new_helper_build_and_VM_ns':b['new_linked_observer_build_and_VM_ns'],
 'helper_cost_paid_once_per_complete_cold_run_not_per_phase':True,
 'original_linked_invocations':sum(r['format']=='linked-selfhost' for r in old.values()),
 'new_linked_invocations':sum(r['format']=='linked-selfhost' for r in new.values()),
 'original_linked_wall_ns':sum(r['wall_ns'] for r in old.values() if r['format']=='linked-selfhost'),
 'new_linked_wall_ns':sum(r['wall_ns'] for r in new.values() if r['format']=='linked-selfhost'),
 'note':'Invoke elapsed includes loading, IO, bookkeeping and scheduling; no linear whole-CI extrapolation. All original 326 checks remain equal and true. Two-worker/180s gates unchanged.',
 'reports':{label:{'bytes':(root/label/'signed-native.json').stat().st_size,
   'sha256':hashlib.sha256((root/label/'signed-native.json').read_bytes()).hexdigest()} for label in ('original','native')}}
with (root/'comparison.json').open('x') as f:json.dump(summary,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('source_files','added_provenance_fields')},sort_keys=True))
