import HiaSyntaxResearch.SyntaxData
namespace HiaCoreSyntaxSlice
noncomputable def linear_r62 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b62 : List Nat := linear_g155
theorem linear_s62 : serializeRaw 4064 26 linear_r62 = some linear_b62 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s62
theorem linear_p62 (tail : List Nat) : parseRaw 4064 26 (linear_b62 ++ tail) = some (linear_r62, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p62
noncomputable def linear_l51_10 : List Raw := [linear_r62]
noncomputable def linear_v51_10 : List Nat := linear_b62
theorem linear_sl51_10 : serializeItems 4065 26 linear_l51_10 = some linear_v51_10 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_single 4064 26 linear_r62 linear_b62 linear_s62)
#print axioms HiaCoreSyntaxSlice.linear_sl51_10
theorem linear_pl51_10 (tail : List Nat) : parseItems 4065 26 (linear_v51_10 ++ (93 :: tail)) = some (linear_l51_10, tail) := by
  exact (HiaCoreSyntaxSlice.Structured.parse_items_last 4064 26 (linear_b62 ++ (93 :: tail)) tail linear_r62 (linear_p62 (93 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl51_10
noncomputable def linear_l51_9 : List Raw := linear_r61 :: linear_l51_10
noncomputable def linear_v51_9 : List Nat := (linear_b61) ++ (44 :: linear_v51_10)
theorem linear_sl51_9 : serializeItems 4066 26 linear_l51_9 = some linear_v51_9 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r61 linear_r62 [] linear_b61 linear_v51_10 linear_s61 linear_sl51_10)
#print axioms HiaCoreSyntaxSlice.linear_sl51_9
theorem linear_pl51_9 (tail : List Nat) : parseItems 4066 26 (linear_v51_9 ++ (93 :: tail)) = some (linear_l51_9, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4065 26 linear_r61 linear_l51_10 linear_b61 linear_v51_10 tail (linear_p61 (44 :: (linear_v51_10 ++ (93 :: tail)))) (linear_pl51_10 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_9
noncomputable def linear_l51_8 : List Raw := linear_r60 :: linear_l51_9
noncomputable def linear_v51_8 : List Nat := (linear_b60) ++ (44 :: linear_v51_9)
theorem linear_sl51_8 : serializeItems 4067 26 linear_l51_8 = some linear_v51_8 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r60 linear_r61 linear_l51_10 linear_b60 linear_v51_9 linear_s60 linear_sl51_9)
#print axioms HiaCoreSyntaxSlice.linear_sl51_8
theorem linear_pl51_8 (tail : List Nat) : parseItems 4067 26 (linear_v51_8 ++ (93 :: tail)) = some (linear_l51_8, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4066 26 linear_r60 linear_l51_9 linear_b60 linear_v51_9 tail (linear_p60 (44 :: (linear_v51_9 ++ (93 :: tail)))) (linear_pl51_9 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_8
noncomputable def linear_l51_7 : List Raw := linear_r59 :: linear_l51_8
noncomputable def linear_v51_7 : List Nat := (linear_b59) ++ (44 :: linear_v51_8)
theorem linear_sl51_7 : serializeItems 4068 26 linear_l51_7 = some linear_v51_7 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r59 linear_r60 linear_l51_9 linear_b59 linear_v51_8 linear_s59 linear_sl51_8)
#print axioms HiaCoreSyntaxSlice.linear_sl51_7
theorem linear_pl51_7 (tail : List Nat) : parseItems 4068 26 (linear_v51_7 ++ (93 :: tail)) = some (linear_l51_7, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4067 26 linear_r59 linear_l51_8 linear_b59 linear_v51_8 tail (linear_p59 (44 :: (linear_v51_8 ++ (93 :: tail)))) (linear_pl51_8 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_7
noncomputable def linear_l51_6 : List Raw := linear_r58 :: linear_l51_7
noncomputable def linear_v51_6 : List Nat := (linear_b58) ++ (44 :: linear_v51_7)
theorem linear_sl51_6 : serializeItems 4069 26 linear_l51_6 = some linear_v51_6 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r58 linear_r59 linear_l51_8 linear_b58 linear_v51_7 linear_s58 linear_sl51_7)
#print axioms HiaCoreSyntaxSlice.linear_sl51_6
theorem linear_pl51_6 (tail : List Nat) : parseItems 4069 26 (linear_v51_6 ++ (93 :: tail)) = some (linear_l51_6, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4068 26 linear_r58 linear_l51_7 linear_b58 linear_v51_7 tail (linear_p58 (44 :: (linear_v51_7 ++ (93 :: tail)))) (linear_pl51_7 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_6
noncomputable def linear_l51_5 : List Raw := linear_r57 :: linear_l51_6
noncomputable def linear_v51_5 : List Nat := (linear_b57) ++ (44 :: linear_v51_6)
theorem linear_sl51_5 : serializeItems 4070 26 linear_l51_5 = some linear_v51_5 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r57 linear_r58 linear_l51_7 linear_b57 linear_v51_6 linear_s57 linear_sl51_6)
#print axioms HiaCoreSyntaxSlice.linear_sl51_5
theorem linear_pl51_5 (tail : List Nat) : parseItems 4070 26 (linear_v51_5 ++ (93 :: tail)) = some (linear_l51_5, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4069 26 linear_r57 linear_l51_6 linear_b57 linear_v51_6 tail (linear_p57 (44 :: (linear_v51_6 ++ (93 :: tail)))) (linear_pl51_6 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_5
noncomputable def linear_l51_4 : List Raw := linear_r56 :: linear_l51_5
noncomputable def linear_v51_4 : List Nat := (linear_b56) ++ (44 :: linear_v51_5)
theorem linear_sl51_4 : serializeItems 4071 26 linear_l51_4 = some linear_v51_4 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r56 linear_r57 linear_l51_6 linear_b56 linear_v51_5 linear_s56 linear_sl51_5)
#print axioms HiaCoreSyntaxSlice.linear_sl51_4
theorem linear_pl51_4 (tail : List Nat) : parseItems 4071 26 (linear_v51_4 ++ (93 :: tail)) = some (linear_l51_4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4070 26 linear_r56 linear_l51_5 linear_b56 linear_v51_5 tail (linear_p56 (44 :: (linear_v51_5 ++ (93 :: tail)))) (linear_pl51_5 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_4
noncomputable def linear_l51_3 : List Raw := linear_r55 :: linear_l51_4
noncomputable def linear_v51_3 : List Nat := (linear_b55) ++ (44 :: linear_v51_4)
theorem linear_sl51_3 : serializeItems 4072 26 linear_l51_3 = some linear_v51_3 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r55 linear_r56 linear_l51_5 linear_b55 linear_v51_4 linear_s55 linear_sl51_4)
#print axioms HiaCoreSyntaxSlice.linear_sl51_3
theorem linear_pl51_3 (tail : List Nat) : parseItems 4072 26 (linear_v51_3 ++ (93 :: tail)) = some (linear_l51_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4071 26 linear_r55 linear_l51_4 linear_b55 linear_v51_4 tail (linear_p55 (44 :: (linear_v51_4 ++ (93 :: tail)))) (linear_pl51_4 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_3
noncomputable def linear_l51_2 : List Raw := linear_r54 :: linear_l51_3
noncomputable def linear_v51_2 : List Nat := (linear_b54) ++ (44 :: linear_v51_3)
theorem linear_sl51_2 : serializeItems 4073 26 linear_l51_2 = some linear_v51_2 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 26 linear_r54 linear_r55 linear_l51_4 linear_b54 linear_v51_3 linear_s54 linear_sl51_3)
#print axioms HiaCoreSyntaxSlice.linear_sl51_2
theorem linear_pl51_2 (tail : List Nat) : parseItems 4073 26 (linear_v51_2 ++ (93 :: tail)) = some (linear_l51_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4072 26 linear_r54 linear_l51_3 linear_b54 linear_v51_3 tail (linear_p54 (44 :: (linear_v51_3 ++ (93 :: tail)))) (linear_pl51_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_2
noncomputable def linear_l51_1 : List Raw := linear_r53 :: linear_l51_2
noncomputable def linear_v51_1 : List Nat := (linear_b53) ++ (44 :: linear_v51_2)
theorem linear_sl51_1 : serializeItems 4074 26 linear_l51_1 = some linear_v51_1 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 26 linear_r53 linear_r54 linear_l51_3 linear_b53 linear_v51_2 linear_s53 linear_sl51_2)
#print axioms HiaCoreSyntaxSlice.linear_sl51_1
theorem linear_pl51_1 (tail : List Nat) : parseItems 4074 26 (linear_v51_1 ++ (93 :: tail)) = some (linear_l51_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4073 26 linear_r53 linear_l51_2 linear_b53 linear_v51_2 tail (linear_p53 (44 :: (linear_v51_2 ++ (93 :: tail)))) (linear_pl51_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_1
noncomputable def linear_l51_0 : List Raw := linear_r52 :: linear_l51_1
noncomputable def linear_v51_0 : List Nat := (linear_b52) ++ (44 :: linear_v51_1)
theorem linear_sl51_0 : serializeItems 4075 26 linear_l51_0 = some linear_v51_0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 26 linear_r52 linear_r53 linear_l51_2 linear_b52 linear_v51_1 linear_s52 linear_sl51_1)
#print axioms HiaCoreSyntaxSlice.linear_sl51_0
theorem linear_pl51_0 (tail : List Nat) : parseItems 4075 26 (linear_v51_0 ++ (93 :: tail)) = some (linear_l51_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4074 26 linear_r52 linear_l51_1 linear_b52 linear_v51_1 tail (linear_p52 (44 :: (linear_v51_1 ++ (93 :: tail)))) (linear_pl51_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl51_0
noncomputable def linear_r51 : Raw := (.arr linear_l51_0)
noncomputable def linear_b51 : List Nat := linear_g134 ++ (linear_v51_0 ++ linear_g156)
theorem linear_s51 : serializeRaw 4076 27 linear_r51 = some linear_b51 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_array 4075 26 linear_l51_0 linear_v51_0 linear_sl51_0)
#print axioms HiaCoreSyntaxSlice.linear_s51
theorem linear_p51 (tail : List Nat) : parseRaw 4076 27 (linear_b51 ++ tail) = some (linear_r51, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_array_bytes 4075 26 linear_l51_0 linear_v51_0 tail (by intro h; cases h) (linear_pl51_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p51
noncomputable def linear_r63 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b63 : List Nat := linear_g159
theorem linear_s63 : serializeRaw 4075 27 linear_r63 = some linear_b63 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s63
theorem linear_p63 (tail : List Nat) : parseRaw 4075 27 (linear_b63 ++ tail) = some (linear_r63, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p63
noncomputable def linear_r64 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,55]),(.str [100,103,95,118,95,53,56]),(.str [100,103,95,118,95,53,57]),(.str [100,103,95,118,95,54,48]),(.str [100,103,95,118,95,55,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,48]))])
noncomputable def linear_b64 : List Nat := linear_g162
theorem linear_s64 : serializeRaw 4074 27 linear_r64 = some linear_b64 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s64
theorem linear_p64 (tail : List Nat) : parseRaw 4074 27 (linear_b64 ++ tail) = some (linear_r64, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p64
noncomputable def linear_k49_0 : List Nat := [105,100]
theorem linear_kd49_0 : stringBytes linear_k49_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd49_0
theorem linear_kp49_0 (tail : List Nat) : parseStringTail (linear_k49_0 ++ (34 :: 58 :: tail)) [] = some (linear_k49_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp49_0
noncomputable def linear_k49_1 : List Nat := [111,112,115]
theorem linear_kd49_1 : stringBytes linear_k49_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd49_1
theorem linear_kp49_1 (tail : List Nat) : parseStringTail (linear_k49_1 ++ (34 :: 58 :: tail)) [] = some (linear_k49_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp49_1
noncomputable def linear_k49_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd49_2 : stringBytes linear_k49_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd49_2
theorem linear_kp49_2 (tail : List Nat) : parseStringTail (linear_k49_2 ++ (34 :: 58 :: tail)) [] = some (linear_k49_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp49_2
noncomputable def linear_k49_3 : List Nat := [116,101,114,109]
theorem linear_kd49_3 : stringBytes linear_k49_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd49_3
theorem linear_kp49_3 (tail : List Nat) : parseStringTail (linear_k49_3 ++ (34 :: 58 :: tail)) [] = some (linear_k49_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp49_3
noncomputable def linear_l49_3 : List (List Nat × Raw) := [(linear_k49_3, linear_r64)]
noncomputable def linear_v49_3 : List Nat := linear_g161 ++ linear_b64
theorem linear_sl49_3 : serializeFields 4075 27 linear_l49_3 = some linear_v49_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4074 27 linear_k49_3 linear_r64 linear_b64 linear_g161 (by rfl) linear_kd49_3 linear_s64)
#print axioms HiaCoreSyntaxSlice.linear_sl49_3
theorem linear_pl49_3 (tail : List Nat) : parseFields 4075 27 (linear_v49_3 ++ (125 :: tail)) = some (linear_l49_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4074 27 linear_k49_3 linear_r64 linear_b64 linear_g161 tail (by rfl) (linear_kp49_3 (linear_b64 ++ (125 :: tail))) (linear_p64 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl49_3
noncomputable def linear_l49_2 : List (List Nat × Raw) := (linear_k49_2, linear_r63) :: linear_l49_3
noncomputable def linear_v49_2 : List Nat := (linear_g158 ++ linear_b63) ++ (44 :: linear_v49_3)
theorem linear_sl49_2 : serializeFields 4076 27 linear_l49_2 = some linear_v49_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4075 27 linear_k49_2 linear_r63 (linear_k49_3, linear_r64) [] linear_b63 linear_v49_3 linear_g158 (by rfl) linear_kd49_2 linear_s63 linear_sl49_3)
#print axioms HiaCoreSyntaxSlice.linear_sl49_2
theorem linear_pl49_2 (tail : List Nat) : parseFields 4076 27 (linear_v49_2 ++ (125 :: tail)) = some (linear_l49_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4075 27 linear_k49_2 linear_r63 linear_l49_3 linear_b63 linear_v49_3 linear_g158 tail (by rfl) (linear_kp49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail))))) (linear_p63 (44 :: (linear_v49_3 ++ (125 :: tail)))) (linear_pl49_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl49_2
noncomputable def linear_l49_1 : List (List Nat × Raw) := (linear_k49_1, linear_r51) :: linear_l49_2
noncomputable def linear_v49_1 : List Nat := (linear_g133 ++ linear_b51) ++ (44 :: linear_v49_2)
theorem linear_sl49_1 : serializeFields 4077 27 linear_l49_1 = some linear_v49_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4076 27 linear_k49_1 linear_r51 (linear_k49_2, linear_r63) linear_l49_3 linear_b51 linear_v49_2 linear_g133 (by rfl) linear_kd49_1 linear_s51 linear_sl49_2)
#print axioms HiaCoreSyntaxSlice.linear_sl49_1
theorem linear_pl49_1 (tail : List Nat) : parseFields 4077 27 (linear_v49_1 ++ (125 :: tail)) = some (linear_l49_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4076 27 linear_k49_1 linear_r51 linear_l49_2 linear_b51 linear_v49_2 linear_g133 tail (by rfl) (linear_kp49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail))))) (linear_p51 (44 :: (linear_v49_2 ++ (125 :: tail)))) (linear_pl49_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl49_1
noncomputable def linear_l49_0 : List (List Nat × Raw) := (linear_k49_0, linear_r50) :: linear_l49_1
noncomputable def linear_v49_0 : List Nat := (linear_g130 ++ linear_b50) ++ (44 :: linear_v49_1)
theorem linear_sl49_0 : serializeFields 4078 27 linear_l49_0 = some linear_v49_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4077 27 linear_k49_0 linear_r50 (linear_k49_1, linear_r51) linear_l49_2 linear_b50 linear_v49_1 linear_g130 (by rfl) linear_kd49_0 linear_s50 linear_sl49_1)
#print axioms HiaCoreSyntaxSlice.linear_sl49_0
theorem linear_pl49_0 (tail : List Nat) : parseFields 4078 27 (linear_v49_0 ++ (125 :: tail)) = some (linear_l49_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4077 27 linear_k49_0 linear_r50 linear_l49_1 linear_b50 linear_v49_1 linear_g130 tail (by rfl) (linear_kp49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail))))) (linear_p50 (44 :: (linear_v49_1 ++ (125 :: tail)))) (linear_pl49_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl49_0
noncomputable def linear_r49 : Raw := (.obj linear_l49_0)
noncomputable def linear_b49 : List Nat := linear_g129 ++ (linear_v49_0 ++ linear_g163)
theorem linear_o49 : orderedFields linear_l49_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o49
theorem linear_s49 : serializeRaw 4079 28 linear_r49 = some linear_b49 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4078 27 linear_l49_0 linear_v49_0 linear_o49 linear_sl49_0)
#print axioms HiaCoreSyntaxSlice.linear_s49
theorem linear_p49 (tail : List Nat) : parseRaw 4079 28 (linear_b49 ++ tail) = some (linear_r49, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4078 27 linear_l49_0 linear_v49_0 tail (by rfl) linear_o49 (linear_pl49_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p49
noncomputable def linear_r66 : Raw := (.str [100,103,95,102,97,115,116,95,50])
noncomputable def linear_b66 : List Nat := linear_g167
theorem linear_s66 : serializeRaw 4076 27 linear_r66 = some linear_b66 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s66
theorem linear_p66 (tail : List Nat) : parseRaw 4076 27 (linear_b66 ++ tail) = some (linear_r66, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p66
noncomputable def linear_r67 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,54])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,55])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
noncomputable def linear_b67 : List Nat := linear_g170
theorem linear_s67 : serializeRaw 4075 27 linear_r67 = some linear_b67 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s67
theorem linear_p67 (tail : List Nat) : parseRaw 4075 27 (linear_b67 ++ tail) = some (linear_r67, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p67
noncomputable def linear_r68 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b68 : List Nat := linear_g173
theorem linear_s68 : serializeRaw 4074 27 linear_r68 = some linear_b68 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s68
theorem linear_p68 (tail : List Nat) : parseRaw 4074 27 (linear_b68 ++ tail) = some (linear_r68, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p68
noncomputable def linear_r69 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,50]),(.str [100,103,95,118,95,55,51]),(.str [100,103,95,118,95,55,54]),(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,55])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
noncomputable def linear_b69 : List Nat := linear_g176
theorem linear_s69 : serializeRaw 4073 27 linear_r69 = some linear_b69 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s69
theorem linear_p69 (tail : List Nat) : parseRaw 4073 27 (linear_b69 ++ tail) = some (linear_r69, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p69
noncomputable def linear_k65_0 : List Nat := [105,100]
theorem linear_kd65_0 : stringBytes linear_k65_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd65_0
theorem linear_kp65_0 (tail : List Nat) : parseStringTail (linear_k65_0 ++ (34 :: 58 :: tail)) [] = some (linear_k65_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp65_0
noncomputable def linear_k65_1 : List Nat := [111,112,115]
theorem linear_kd65_1 : stringBytes linear_k65_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd65_1
theorem linear_kp65_1 (tail : List Nat) : parseStringTail (linear_k65_1 ++ (34 :: 58 :: tail)) [] = some (linear_k65_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp65_1
noncomputable def linear_k65_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd65_2 : stringBytes linear_k65_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd65_2
theorem linear_kp65_2 (tail : List Nat) : parseStringTail (linear_k65_2 ++ (34 :: 58 :: tail)) [] = some (linear_k65_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp65_2
noncomputable def linear_k65_3 : List Nat := [116,101,114,109]
theorem linear_kd65_3 : stringBytes linear_k65_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd65_3
theorem linear_kp65_3 (tail : List Nat) : parseStringTail (linear_k65_3 ++ (34 :: 58 :: tail)) [] = some (linear_k65_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp65_3
noncomputable def linear_l65_3 : List (List Nat × Raw) := [(linear_k65_3, linear_r69)]
noncomputable def linear_v65_3 : List Nat := linear_g175 ++ linear_b69
theorem linear_sl65_3 : serializeFields 4074 27 linear_l65_3 = some linear_v65_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4073 27 linear_k65_3 linear_r69 linear_b69 linear_g175 (by rfl) linear_kd65_3 linear_s69)
#print axioms HiaCoreSyntaxSlice.linear_sl65_3
theorem linear_pl65_3 (tail : List Nat) : parseFields 4074 27 (linear_v65_3 ++ (125 :: tail)) = some (linear_l65_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4073 27 linear_k65_3 linear_r69 linear_b69 linear_g175 tail (by rfl) (linear_kp65_3 (linear_b69 ++ (125 :: tail))) (linear_p69 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl65_3
noncomputable def linear_l65_2 : List (List Nat × Raw) := (linear_k65_2, linear_r68) :: linear_l65_3
noncomputable def linear_v65_2 : List Nat := (linear_g172 ++ linear_b68) ++ (44 :: linear_v65_3)
theorem linear_sl65_2 : serializeFields 4075 27 linear_l65_2 = some linear_v65_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4074 27 linear_k65_2 linear_r68 (linear_k65_3, linear_r69) [] linear_b68 linear_v65_3 linear_g172 (by rfl) linear_kd65_2 linear_s68 linear_sl65_3)
#print axioms HiaCoreSyntaxSlice.linear_sl65_2
theorem linear_pl65_2 (tail : List Nat) : parseFields 4075 27 (linear_v65_2 ++ (125 :: tail)) = some (linear_l65_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4074 27 linear_k65_2 linear_r68 linear_l65_3 linear_b68 linear_v65_3 linear_g172 tail (by rfl) (linear_kp65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail))))) (linear_p68 (44 :: (linear_v65_3 ++ (125 :: tail)))) (linear_pl65_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl65_2
noncomputable def linear_l65_1 : List (List Nat × Raw) := (linear_k65_1, linear_r67) :: linear_l65_2
noncomputable def linear_v65_1 : List Nat := (linear_g169 ++ linear_b67) ++ (44 :: linear_v65_2)
theorem linear_sl65_1 : serializeFields 4076 27 linear_l65_1 = some linear_v65_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4075 27 linear_k65_1 linear_r67 (linear_k65_2, linear_r68) linear_l65_3 linear_b67 linear_v65_2 linear_g169 (by rfl) linear_kd65_1 linear_s67 linear_sl65_2)
#print axioms HiaCoreSyntaxSlice.linear_sl65_1
theorem linear_pl65_1 (tail : List Nat) : parseFields 4076 27 (linear_v65_1 ++ (125 :: tail)) = some (linear_l65_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4075 27 linear_k65_1 linear_r67 linear_l65_2 linear_b67 linear_v65_2 linear_g169 tail (by rfl) (linear_kp65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail))))) (linear_p67 (44 :: (linear_v65_2 ++ (125 :: tail)))) (linear_pl65_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl65_1
noncomputable def linear_l65_0 : List (List Nat × Raw) := (linear_k65_0, linear_r66) :: linear_l65_1
noncomputable def linear_v65_0 : List Nat := (linear_g166 ++ linear_b66) ++ (44 :: linear_v65_1)
theorem linear_sl65_0 : serializeFields 4077 27 linear_l65_0 = some linear_v65_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4076 27 linear_k65_0 linear_r66 (linear_k65_1, linear_r67) linear_l65_2 linear_b66 linear_v65_1 linear_g166 (by rfl) linear_kd65_0 linear_s66 linear_sl65_1)
#print axioms HiaCoreSyntaxSlice.linear_sl65_0
theorem linear_pl65_0 (tail : List Nat) : parseFields 4077 27 (linear_v65_0 ++ (125 :: tail)) = some (linear_l65_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4076 27 linear_k65_0 linear_r66 linear_l65_1 linear_b66 linear_v65_1 linear_g166 tail (by rfl) (linear_kp65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail))))) (linear_p66 (44 :: (linear_v65_1 ++ (125 :: tail)))) (linear_pl65_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl65_0
noncomputable def linear_r65 : Raw := (.obj linear_l65_0)
noncomputable def linear_b65 : List Nat := linear_g165 ++ (linear_v65_0 ++ linear_g177)
theorem linear_o65 : orderedFields linear_l65_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o65
theorem linear_s65 : serializeRaw 4078 28 linear_r65 = some linear_b65 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4077 27 linear_l65_0 linear_v65_0 linear_o65 linear_sl65_0)
#print axioms HiaCoreSyntaxSlice.linear_s65
theorem linear_p65 (tail : List Nat) : parseRaw 4078 28 (linear_b65 ++ tail) = some (linear_r65, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4077 27 linear_l65_0 linear_v65_0 tail (by rfl) linear_o65 (linear_pl65_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p65
noncomputable def linear_r71 : Raw := (.str [100,103,95,102,97,115,116,95,51])
noncomputable def linear_b71 : List Nat := linear_g181
theorem linear_s71 : serializeRaw 4075 27 linear_r71 = some linear_b71 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s71
theorem linear_p71 (tail : List Nat) : parseRaw 4075 27 (linear_b71 ++ tail) = some (linear_r71, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p71
noncomputable def linear_r72 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,51]),(.str [100,103,95,118,95,56,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
noncomputable def linear_b72 : List Nat := linear_g184
theorem linear_s72 : serializeRaw 4074 27 linear_r72 = some linear_b72 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s72
theorem linear_p72 (tail : List Nat) : parseRaw 4074 27 (linear_b72 ++ tail) = some (linear_r72, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p72
noncomputable def linear_r73 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b73 : List Nat := linear_g187
theorem linear_s73 : serializeRaw 4073 27 linear_r73 = some linear_b73 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s73
theorem linear_p73 (tail : List Nat) : parseRaw 4073 27 (linear_b73 ++ tail) = some (linear_r73, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p73
noncomputable def linear_r74 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,56,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
noncomputable def linear_b74 : List Nat := linear_g190
theorem linear_s74 : serializeRaw 4072 27 linear_r74 = some linear_b74 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s74
theorem linear_p74 (tail : List Nat) : parseRaw 4072 27 (linear_b74 ++ tail) = some (linear_r74, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p74
noncomputable def linear_k70_0 : List Nat := [105,100]
theorem linear_kd70_0 : stringBytes linear_k70_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd70_0
theorem linear_kp70_0 (tail : List Nat) : parseStringTail (linear_k70_0 ++ (34 :: 58 :: tail)) [] = some (linear_k70_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp70_0
noncomputable def linear_k70_1 : List Nat := [111,112,115]
theorem linear_kd70_1 : stringBytes linear_k70_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd70_1
theorem linear_kp70_1 (tail : List Nat) : parseStringTail (linear_k70_1 ++ (34 :: 58 :: tail)) [] = some (linear_k70_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp70_1
noncomputable def linear_k70_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd70_2 : stringBytes linear_k70_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd70_2
theorem linear_kp70_2 (tail : List Nat) : parseStringTail (linear_k70_2 ++ (34 :: 58 :: tail)) [] = some (linear_k70_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp70_2
noncomputable def linear_k70_3 : List Nat := [116,101,114,109]
theorem linear_kd70_3 : stringBytes linear_k70_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd70_3
theorem linear_kp70_3 (tail : List Nat) : parseStringTail (linear_k70_3 ++ (34 :: 58 :: tail)) [] = some (linear_k70_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp70_3
noncomputable def linear_l70_3 : List (List Nat × Raw) := [(linear_k70_3, linear_r74)]
noncomputable def linear_v70_3 : List Nat := linear_g189 ++ linear_b74
theorem linear_sl70_3 : serializeFields 4073 27 linear_l70_3 = some linear_v70_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4072 27 linear_k70_3 linear_r74 linear_b74 linear_g189 (by rfl) linear_kd70_3 linear_s74)
#print axioms HiaCoreSyntaxSlice.linear_sl70_3
theorem linear_pl70_3 (tail : List Nat) : parseFields 4073 27 (linear_v70_3 ++ (125 :: tail)) = some (linear_l70_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4072 27 linear_k70_3 linear_r74 linear_b74 linear_g189 tail (by rfl) (linear_kp70_3 (linear_b74 ++ (125 :: tail))) (linear_p74 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl70_3
noncomputable def linear_l70_2 : List (List Nat × Raw) := (linear_k70_2, linear_r73) :: linear_l70_3
noncomputable def linear_v70_2 : List Nat := (linear_g186 ++ linear_b73) ++ (44 :: linear_v70_3)
theorem linear_sl70_2 : serializeFields 4074 27 linear_l70_2 = some linear_v70_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4073 27 linear_k70_2 linear_r73 (linear_k70_3, linear_r74) [] linear_b73 linear_v70_3 linear_g186 (by rfl) linear_kd70_2 linear_s73 linear_sl70_3)
#print axioms HiaCoreSyntaxSlice.linear_sl70_2
theorem linear_pl70_2 (tail : List Nat) : parseFields 4074 27 (linear_v70_2 ++ (125 :: tail)) = some (linear_l70_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4073 27 linear_k70_2 linear_r73 linear_l70_3 linear_b73 linear_v70_3 linear_g186 tail (by rfl) (linear_kp70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail))))) (linear_p73 (44 :: (linear_v70_3 ++ (125 :: tail)))) (linear_pl70_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl70_2
noncomputable def linear_l70_1 : List (List Nat × Raw) := (linear_k70_1, linear_r72) :: linear_l70_2
noncomputable def linear_v70_1 : List Nat := (linear_g183 ++ linear_b72) ++ (44 :: linear_v70_2)
theorem linear_sl70_1 : serializeFields 4075 27 linear_l70_1 = some linear_v70_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4074 27 linear_k70_1 linear_r72 (linear_k70_2, linear_r73) linear_l70_3 linear_b72 linear_v70_2 linear_g183 (by rfl) linear_kd70_1 linear_s72 linear_sl70_2)
#print axioms HiaCoreSyntaxSlice.linear_sl70_1
theorem linear_pl70_1 (tail : List Nat) : parseFields 4075 27 (linear_v70_1 ++ (125 :: tail)) = some (linear_l70_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4074 27 linear_k70_1 linear_r72 linear_l70_2 linear_b72 linear_v70_2 linear_g183 tail (by rfl) (linear_kp70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail))))) (linear_p72 (44 :: (linear_v70_2 ++ (125 :: tail)))) (linear_pl70_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl70_1
noncomputable def linear_l70_0 : List (List Nat × Raw) := (linear_k70_0, linear_r71) :: linear_l70_1
noncomputable def linear_v70_0 : List Nat := (linear_g180 ++ linear_b71) ++ (44 :: linear_v70_1)
theorem linear_sl70_0 : serializeFields 4076 27 linear_l70_0 = some linear_v70_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4075 27 linear_k70_0 linear_r71 (linear_k70_1, linear_r72) linear_l70_2 linear_b71 linear_v70_1 linear_g180 (by rfl) linear_kd70_0 linear_s71 linear_sl70_1)
#print axioms HiaCoreSyntaxSlice.linear_sl70_0
theorem linear_pl70_0 (tail : List Nat) : parseFields 4076 27 (linear_v70_0 ++ (125 :: tail)) = some (linear_l70_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4075 27 linear_k70_0 linear_r71 linear_l70_1 linear_b71 linear_v70_1 linear_g180 tail (by rfl) (linear_kp70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail))))) (linear_p71 (44 :: (linear_v70_1 ++ (125 :: tail)))) (linear_pl70_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl70_0
noncomputable def linear_r70 : Raw := (.obj linear_l70_0)
noncomputable def linear_b70 : List Nat := linear_g179 ++ (linear_v70_0 ++ linear_g191)
theorem linear_o70 : orderedFields linear_l70_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o70
theorem linear_s70 : serializeRaw 4077 28 linear_r70 = some linear_b70 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4076 27 linear_l70_0 linear_v70_0 linear_o70 linear_sl70_0)
#print axioms HiaCoreSyntaxSlice.linear_s70
theorem linear_p70 (tail : List Nat) : parseRaw 4077 28 (linear_b70 ++ tail) = some (linear_r70, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4076 27 linear_l70_0 linear_v70_0 tail (by rfl) linear_o70 (linear_pl70_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p70
noncomputable def linear_r76 : Raw := (.str [100,103,95,102,97,115,116,95,52])
noncomputable def linear_b76 : List Nat := linear_g195
theorem linear_s76 : serializeRaw 4074 27 linear_r76 = some linear_b76 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s76
theorem linear_p76 (tail : List Nat) : parseRaw 4074 27 (linear_b76 ++ tail) = some (linear_r76, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p76
noncomputable def linear_r78 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,49])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
noncomputable def linear_b78 : List Nat := linear_g199
theorem linear_s78 : serializeRaw 4071 26 linear_r78 = some linear_b78 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s78
theorem linear_p78 (tail : List Nat) : parseRaw 4071 26 (linear_b78 ++ tail) = some (linear_r78, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p78
noncomputable def linear_r79 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49]),(.str [100,103,95,118,95,57,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,50])),([116,121,112,101],(.str [117,56]))])]))])
noncomputable def linear_b79 : List Nat := linear_g201
theorem linear_s79 : serializeRaw 4070 26 linear_r79 = some linear_b79 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s79
theorem linear_p79 (tail : List Nat) : parseRaw 4070 26 (linear_b79 ++ tail) = some (linear_r79, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p79
noncomputable def linear_r80 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
noncomputable def linear_b80 : List Nat := linear_g203
theorem linear_s80 : serializeRaw 4069 26 linear_r80 = some linear_b80 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s80
theorem linear_p80 (tail : List Nat) : parseRaw 4069 26 (linear_b80 ++ tail) = some (linear_r80, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p80
noncomputable def linear_r81 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,50])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,51])),([116,121,112,101],(.str [117,54,52]))])]))])
noncomputable def linear_b81 : List Nat := linear_g205
theorem linear_s81 : serializeRaw 4068 26 linear_r81 = some linear_b81 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s81
theorem linear_p81 (tail : List Nat) : parseRaw 4068 26 (linear_b81 ++ tail) = some (linear_r81, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p81
noncomputable def linear_r82 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,56]),(.str [100,103,95,118,95,57,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,52])),([116,121,112,101],(.str [117,54,52]))])]))])
noncomputable def linear_b82 : List Nat := linear_g207
theorem linear_s82 : serializeRaw 4067 26 linear_r82 = some linear_b82 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s82
theorem linear_p82 (tail : List Nat) : parseRaw 4067 26 (linear_b82 ++ tail) = some (linear_r82, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p82
noncomputable def linear_r83 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,53])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b83 : List Nat := linear_g209
theorem linear_s83 : serializeRaw 4066 26 linear_r83 = some linear_b83 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s83
theorem linear_p83 (tail : List Nat) : parseRaw 4066 26 (linear_b83 ++ tail) = some (linear_r83, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p83
noncomputable def linear_r84 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,48]),(.str [100,103,95,118,95,57,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,54])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b84 : List Nat := linear_g211
theorem linear_s84 : serializeRaw 4065 26 linear_r84 = some linear_b84 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s84
theorem linear_p84 (tail : List Nat) : parseRaw 4065 26 (linear_b84 ++ tail) = some (linear_r84, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p84
noncomputable def linear_l77_6 : List Raw := [linear_r84]
noncomputable def linear_v77_6 : List Nat := linear_b84
theorem linear_sl77_6 : serializeItems 4066 26 linear_l77_6 = some linear_v77_6 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_single 4065 26 linear_r84 linear_b84 linear_s84)
#print axioms HiaCoreSyntaxSlice.linear_sl77_6
theorem linear_pl77_6 (tail : List Nat) : parseItems 4066 26 (linear_v77_6 ++ (93 :: tail)) = some (linear_l77_6, tail) := by
  exact (HiaCoreSyntaxSlice.Structured.parse_items_last 4065 26 (linear_b84 ++ (93 :: tail)) tail linear_r84 (linear_p84 (93 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl77_6
noncomputable def linear_l77_5 : List Raw := linear_r83 :: linear_l77_6
noncomputable def linear_v77_5 : List Nat := (linear_b83) ++ (44 :: linear_v77_6)
theorem linear_sl77_5 : serializeItems 4067 26 linear_l77_5 = some linear_v77_5 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r83 linear_r84 [] linear_b83 linear_v77_6 linear_s83 linear_sl77_6)
#print axioms HiaCoreSyntaxSlice.linear_sl77_5
theorem linear_pl77_5 (tail : List Nat) : parseItems 4067 26 (linear_v77_5 ++ (93 :: tail)) = some (linear_l77_5, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4066 26 linear_r83 linear_l77_6 linear_b83 linear_v77_6 tail (linear_p83 (44 :: (linear_v77_6 ++ (93 :: tail)))) (linear_pl77_6 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl77_5
noncomputable def linear_l77_4 : List Raw := linear_r82 :: linear_l77_5
noncomputable def linear_v77_4 : List Nat := (linear_b82) ++ (44 :: linear_v77_5)
theorem linear_sl77_4 : serializeItems 4068 26 linear_l77_4 = some linear_v77_4 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r82 linear_r83 linear_l77_6 linear_b82 linear_v77_5 linear_s82 linear_sl77_5)
#print axioms HiaCoreSyntaxSlice.linear_sl77_4
theorem linear_pl77_4 (tail : List Nat) : parseItems 4068 26 (linear_v77_4 ++ (93 :: tail)) = some (linear_l77_4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4067 26 linear_r82 linear_l77_5 linear_b82 linear_v77_5 tail (linear_p82 (44 :: (linear_v77_5 ++ (93 :: tail)))) (linear_pl77_5 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl77_4
noncomputable def linear_l77_3 : List Raw := linear_r81 :: linear_l77_4
noncomputable def linear_v77_3 : List Nat := (linear_b81) ++ (44 :: linear_v77_4)
theorem linear_sl77_3 : serializeItems 4069 26 linear_l77_3 = some linear_v77_3 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r81 linear_r82 linear_l77_5 linear_b81 linear_v77_4 linear_s81 linear_sl77_4)
#print axioms HiaCoreSyntaxSlice.linear_sl77_3
theorem linear_pl77_3 (tail : List Nat) : parseItems 4069 26 (linear_v77_3 ++ (93 :: tail)) = some (linear_l77_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4068 26 linear_r81 linear_l77_4 linear_b81 linear_v77_4 tail (linear_p81 (44 :: (linear_v77_4 ++ (93 :: tail)))) (linear_pl77_4 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl77_3
noncomputable def linear_l77_2 : List Raw := linear_r80 :: linear_l77_3
noncomputable def linear_v77_2 : List Nat := (linear_b80) ++ (44 :: linear_v77_3)
theorem linear_sl77_2 : serializeItems 4070 26 linear_l77_2 = some linear_v77_2 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r80 linear_r81 linear_l77_4 linear_b80 linear_v77_3 linear_s80 linear_sl77_3)
#print axioms HiaCoreSyntaxSlice.linear_sl77_2
theorem linear_pl77_2 (tail : List Nat) : parseItems 4070 26 (linear_v77_2 ++ (93 :: tail)) = some (linear_l77_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4069 26 linear_r80 linear_l77_3 linear_b80 linear_v77_3 tail (linear_p80 (44 :: (linear_v77_3 ++ (93 :: tail)))) (linear_pl77_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl77_2
noncomputable def linear_l77_1 : List Raw := linear_r79 :: linear_l77_2
noncomputable def linear_v77_1 : List Nat := (linear_b79) ++ (44 :: linear_v77_2)
theorem linear_sl77_1 : serializeItems 4071 26 linear_l77_1 = some linear_v77_1 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r79 linear_r80 linear_l77_3 linear_b79 linear_v77_2 linear_s79 linear_sl77_2)
#print axioms HiaCoreSyntaxSlice.linear_sl77_1
theorem linear_pl77_1 (tail : List Nat) : parseItems 4071 26 (linear_v77_1 ++ (93 :: tail)) = some (linear_l77_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4070 26 linear_r79 linear_l77_2 linear_b79 linear_v77_2 tail (linear_p79 (44 :: (linear_v77_2 ++ (93 :: tail)))) (linear_pl77_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl77_1
noncomputable def linear_l77_0 : List Raw := linear_r78 :: linear_l77_1
noncomputable def linear_v77_0 : List Nat := (linear_b78) ++ (44 :: linear_v77_1)
theorem linear_sl77_0 : serializeItems 4072 26 linear_l77_0 = some linear_v77_0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r78 linear_r79 linear_l77_2 linear_b78 linear_v77_1 linear_s78 linear_sl77_1)
#print axioms HiaCoreSyntaxSlice.linear_sl77_0
theorem linear_pl77_0 (tail : List Nat) : parseItems 4072 26 (linear_v77_0 ++ (93 :: tail)) = some (linear_l77_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4071 26 linear_r78 linear_l77_1 linear_b78 linear_v77_1 tail (linear_p78 (44 :: (linear_v77_1 ++ (93 :: tail)))) (linear_pl77_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl77_0
noncomputable def linear_r77 : Raw := (.arr linear_l77_0)
noncomputable def linear_b77 : List Nat := linear_g198 ++ (linear_v77_0 ++ linear_g212)
theorem linear_s77 : serializeRaw 4073 27 linear_r77 = some linear_b77 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_array 4072 26 linear_l77_0 linear_v77_0 linear_sl77_0)
#print axioms HiaCoreSyntaxSlice.linear_s77
theorem linear_p77 (tail : List Nat) : parseRaw 4073 27 (linear_b77 ++ tail) = some (linear_r77, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_array_bytes 4072 26 linear_l77_0 linear_v77_0 tail (by intro h; cases h) (linear_pl77_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p77
noncomputable def linear_r85 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b85 : List Nat := linear_g215
theorem linear_s85 : serializeRaw 4072 27 linear_r85 = some linear_b85 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s85
theorem linear_p85 (tail : List Nat) : parseRaw 4072 27 (linear_b85 ++ tail) = some (linear_r85, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p85
noncomputable def linear_r86 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,53]),(.str [100,103,95,118,95,56,54]),(.str [100,103,95,118,95,56,55]),(.str [100,103,95,118,95,57,52]),(.str [100,103,95,118,95,56,57]),(.str [100,103,95,118,95,57,54])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
noncomputable def linear_b86 : List Nat := linear_g218
theorem linear_s86 : serializeRaw 4071 27 linear_r86 = some linear_b86 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s86
theorem linear_p86 (tail : List Nat) : parseRaw 4071 27 (linear_b86 ++ tail) = some (linear_r86, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p86
noncomputable def linear_k75_0 : List Nat := [105,100]
theorem linear_kd75_0 : stringBytes linear_k75_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd75_0
theorem linear_kp75_0 (tail : List Nat) : parseStringTail (linear_k75_0 ++ (34 :: 58 :: tail)) [] = some (linear_k75_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp75_0
noncomputable def linear_k75_1 : List Nat := [111,112,115]
theorem linear_kd75_1 : stringBytes linear_k75_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd75_1
theorem linear_kp75_1 (tail : List Nat) : parseStringTail (linear_k75_1 ++ (34 :: 58 :: tail)) [] = some (linear_k75_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp75_1
noncomputable def linear_k75_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd75_2 : stringBytes linear_k75_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd75_2
theorem linear_kp75_2 (tail : List Nat) : parseStringTail (linear_k75_2 ++ (34 :: 58 :: tail)) [] = some (linear_k75_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp75_2
noncomputable def linear_k75_3 : List Nat := [116,101,114,109]
theorem linear_kd75_3 : stringBytes linear_k75_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd75_3
theorem linear_kp75_3 (tail : List Nat) : parseStringTail (linear_k75_3 ++ (34 :: 58 :: tail)) [] = some (linear_k75_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp75_3
noncomputable def linear_l75_3 : List (List Nat × Raw) := [(linear_k75_3, linear_r86)]
noncomputable def linear_v75_3 : List Nat := linear_g217 ++ linear_b86
theorem linear_sl75_3 : serializeFields 4072 27 linear_l75_3 = some linear_v75_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4071 27 linear_k75_3 linear_r86 linear_b86 linear_g217 (by rfl) linear_kd75_3 linear_s86)
#print axioms HiaCoreSyntaxSlice.linear_sl75_3
theorem linear_pl75_3 (tail : List Nat) : parseFields 4072 27 (linear_v75_3 ++ (125 :: tail)) = some (linear_l75_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4071 27 linear_k75_3 linear_r86 linear_b86 linear_g217 tail (by rfl) (linear_kp75_3 (linear_b86 ++ (125 :: tail))) (linear_p86 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl75_3
noncomputable def linear_l75_2 : List (List Nat × Raw) := (linear_k75_2, linear_r85) :: linear_l75_3
noncomputable def linear_v75_2 : List Nat := (linear_g214 ++ linear_b85) ++ (44 :: linear_v75_3)
theorem linear_sl75_2 : serializeFields 4073 27 linear_l75_2 = some linear_v75_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4072 27 linear_k75_2 linear_r85 (linear_k75_3, linear_r86) [] linear_b85 linear_v75_3 linear_g214 (by rfl) linear_kd75_2 linear_s85 linear_sl75_3)
#print axioms HiaCoreSyntaxSlice.linear_sl75_2
theorem linear_pl75_2 (tail : List Nat) : parseFields 4073 27 (linear_v75_2 ++ (125 :: tail)) = some (linear_l75_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4072 27 linear_k75_2 linear_r85 linear_l75_3 linear_b85 linear_v75_3 linear_g214 tail (by rfl) (linear_kp75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail))))) (linear_p85 (44 :: (linear_v75_3 ++ (125 :: tail)))) (linear_pl75_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl75_2
noncomputable def linear_l75_1 : List (List Nat × Raw) := (linear_k75_1, linear_r77) :: linear_l75_2
noncomputable def linear_v75_1 : List Nat := (linear_g197 ++ linear_b77) ++ (44 :: linear_v75_2)
theorem linear_sl75_1 : serializeFields 4074 27 linear_l75_1 = some linear_v75_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4073 27 linear_k75_1 linear_r77 (linear_k75_2, linear_r85) linear_l75_3 linear_b77 linear_v75_2 linear_g197 (by rfl) linear_kd75_1 linear_s77 linear_sl75_2)
#print axioms HiaCoreSyntaxSlice.linear_sl75_1
theorem linear_pl75_1 (tail : List Nat) : parseFields 4074 27 (linear_v75_1 ++ (125 :: tail)) = some (linear_l75_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4073 27 linear_k75_1 linear_r77 linear_l75_2 linear_b77 linear_v75_2 linear_g197 tail (by rfl) (linear_kp75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail))))) (linear_p77 (44 :: (linear_v75_2 ++ (125 :: tail)))) (linear_pl75_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl75_1
noncomputable def linear_l75_0 : List (List Nat × Raw) := (linear_k75_0, linear_r76) :: linear_l75_1
noncomputable def linear_v75_0 : List Nat := (linear_g194 ++ linear_b76) ++ (44 :: linear_v75_1)
theorem linear_sl75_0 : serializeFields 4075 27 linear_l75_0 = some linear_v75_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4074 27 linear_k75_0 linear_r76 (linear_k75_1, linear_r77) linear_l75_2 linear_b76 linear_v75_1 linear_g194 (by rfl) linear_kd75_0 linear_s76 linear_sl75_1)
#print axioms HiaCoreSyntaxSlice.linear_sl75_0
theorem linear_pl75_0 (tail : List Nat) : parseFields 4075 27 (linear_v75_0 ++ (125 :: tail)) = some (linear_l75_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4074 27 linear_k75_0 linear_r76 linear_l75_1 linear_b76 linear_v75_1 linear_g194 tail (by rfl) (linear_kp75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail))))) (linear_p76 (44 :: (linear_v75_1 ++ (125 :: tail)))) (linear_pl75_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl75_0
noncomputable def linear_r75 : Raw := (.obj linear_l75_0)
noncomputable def linear_b75 : List Nat := linear_g193 ++ (linear_v75_0 ++ linear_g219)
theorem linear_o75 : orderedFields linear_l75_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o75
theorem linear_s75 : serializeRaw 4076 28 linear_r75 = some linear_b75 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4075 27 linear_l75_0 linear_v75_0 linear_o75 linear_sl75_0)
#print axioms HiaCoreSyntaxSlice.linear_s75
theorem linear_p75 (tail : List Nat) : parseRaw 4076 28 (linear_b75 ++ tail) = some (linear_r75, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4075 27 linear_l75_0 linear_v75_0 tail (by rfl) linear_o75 (linear_pl75_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p75
noncomputable def linear_r88 : Raw := (.str [100,103,95,102,97,115,116,95,53])
noncomputable def linear_b88 : List Nat := linear_g223
theorem linear_s88 : serializeRaw 4073 27 linear_r88 = some linear_b88 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s88
theorem linear_p88 (tail : List Nat) : parseRaw 4073 27 (linear_b88 ++ tail) = some (linear_r88, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p88
noncomputable def linear_r89 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
noncomputable def linear_b89 : List Nat := linear_g226
theorem linear_s89 : serializeRaw 4072 27 linear_r89 = some linear_b89 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s89
theorem linear_p89 (tail : List Nat) : parseRaw 4072 27 (linear_b89 ++ tail) = some (linear_r89, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p89
noncomputable def linear_r90 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,48])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b90 : List Nat := linear_g229
theorem linear_s90 : serializeRaw 4071 27 linear_r90 = some linear_b90 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s90
theorem linear_p90 (tail : List Nat) : parseRaw 4071 27 (linear_b90 ++ tail) = some (linear_r90, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p90
noncomputable def linear_r91 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,48,48])]))])
noncomputable def linear_b91 : List Nat := linear_g232
theorem linear_s91 : serializeRaw 4070 27 linear_r91 = some linear_b91 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s91
theorem linear_p91 (tail : List Nat) : parseRaw 4070 27 (linear_b91 ++ tail) = some (linear_r91, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p91
noncomputable def linear_k87_0 : List Nat := [105,100]
theorem linear_kd87_0 : stringBytes linear_k87_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd87_0
theorem linear_kp87_0 (tail : List Nat) : parseStringTail (linear_k87_0 ++ (34 :: 58 :: tail)) [] = some (linear_k87_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp87_0
noncomputable def linear_k87_1 : List Nat := [111,112,115]
theorem linear_kd87_1 : stringBytes linear_k87_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd87_1
theorem linear_kp87_1 (tail : List Nat) : parseStringTail (linear_k87_1 ++ (34 :: 58 :: tail)) [] = some (linear_k87_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp87_1
noncomputable def linear_k87_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd87_2 : stringBytes linear_k87_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd87_2
theorem linear_kp87_2 (tail : List Nat) : parseStringTail (linear_k87_2 ++ (34 :: 58 :: tail)) [] = some (linear_k87_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp87_2
noncomputable def linear_k87_3 : List Nat := [116,101,114,109]
theorem linear_kd87_3 : stringBytes linear_k87_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd87_3
theorem linear_kp87_3 (tail : List Nat) : parseStringTail (linear_k87_3 ++ (34 :: 58 :: tail)) [] = some (linear_k87_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp87_3
noncomputable def linear_l87_3 : List (List Nat × Raw) := [(linear_k87_3, linear_r91)]
noncomputable def linear_v87_3 : List Nat := linear_g231 ++ linear_b91
theorem linear_sl87_3 : serializeFields 4071 27 linear_l87_3 = some linear_v87_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4070 27 linear_k87_3 linear_r91 linear_b91 linear_g231 (by rfl) linear_kd87_3 linear_s91)
#print axioms HiaCoreSyntaxSlice.linear_sl87_3
theorem linear_pl87_3 (tail : List Nat) : parseFields 4071 27 (linear_v87_3 ++ (125 :: tail)) = some (linear_l87_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4070 27 linear_k87_3 linear_r91 linear_b91 linear_g231 tail (by rfl) (linear_kp87_3 (linear_b91 ++ (125 :: tail))) (linear_p91 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl87_3
noncomputable def linear_l87_2 : List (List Nat × Raw) := (linear_k87_2, linear_r90) :: linear_l87_3
noncomputable def linear_v87_2 : List Nat := (linear_g228 ++ linear_b90) ++ (44 :: linear_v87_3)
theorem linear_sl87_2 : serializeFields 4072 27 linear_l87_2 = some linear_v87_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4071 27 linear_k87_2 linear_r90 (linear_k87_3, linear_r91) [] linear_b90 linear_v87_3 linear_g228 (by rfl) linear_kd87_2 linear_s90 linear_sl87_3)
#print axioms HiaCoreSyntaxSlice.linear_sl87_2
theorem linear_pl87_2 (tail : List Nat) : parseFields 4072 27 (linear_v87_2 ++ (125 :: tail)) = some (linear_l87_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4071 27 linear_k87_2 linear_r90 linear_l87_3 linear_b90 linear_v87_3 linear_g228 tail (by rfl) (linear_kp87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail))))) (linear_p90 (44 :: (linear_v87_3 ++ (125 :: tail)))) (linear_pl87_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl87_2
noncomputable def linear_l87_1 : List (List Nat × Raw) := (linear_k87_1, linear_r89) :: linear_l87_2
noncomputable def linear_v87_1 : List Nat := (linear_g225 ++ linear_b89) ++ (44 :: linear_v87_2)
theorem linear_sl87_1 : serializeFields 4073 27 linear_l87_1 = some linear_v87_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4072 27 linear_k87_1 linear_r89 (linear_k87_2, linear_r90) linear_l87_3 linear_b89 linear_v87_2 linear_g225 (by rfl) linear_kd87_1 linear_s89 linear_sl87_2)
#print axioms HiaCoreSyntaxSlice.linear_sl87_1
theorem linear_pl87_1 (tail : List Nat) : parseFields 4073 27 (linear_v87_1 ++ (125 :: tail)) = some (linear_l87_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4072 27 linear_k87_1 linear_r89 linear_l87_2 linear_b89 linear_v87_2 linear_g225 tail (by rfl) (linear_kp87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail))))) (linear_p89 (44 :: (linear_v87_2 ++ (125 :: tail)))) (linear_pl87_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl87_1
noncomputable def linear_l87_0 : List (List Nat × Raw) := (linear_k87_0, linear_r88) :: linear_l87_1
noncomputable def linear_v87_0 : List Nat := (linear_g222 ++ linear_b88) ++ (44 :: linear_v87_1)
theorem linear_sl87_0 : serializeFields 4074 27 linear_l87_0 = some linear_v87_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4073 27 linear_k87_0 linear_r88 (linear_k87_1, linear_r89) linear_l87_2 linear_b88 linear_v87_1 linear_g222 (by rfl) linear_kd87_0 linear_s88 linear_sl87_1)
#print axioms HiaCoreSyntaxSlice.linear_sl87_0
theorem linear_pl87_0 (tail : List Nat) : parseFields 4074 27 (linear_v87_0 ++ (125 :: tail)) = some (linear_l87_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4073 27 linear_k87_0 linear_r88 linear_l87_1 linear_b88 linear_v87_1 linear_g222 tail (by rfl) (linear_kp87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail))))) (linear_p88 (44 :: (linear_v87_1 ++ (125 :: tail)))) (linear_pl87_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl87_0
noncomputable def linear_r87 : Raw := (.obj linear_l87_0)
noncomputable def linear_b87 : List Nat := linear_g221 ++ (linear_v87_0 ++ linear_g233)
theorem linear_o87 : orderedFields linear_l87_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o87
theorem linear_s87 : serializeRaw 4075 28 linear_r87 = some linear_b87 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4074 27 linear_l87_0 linear_v87_0 linear_o87 linear_sl87_0)
#print axioms HiaCoreSyntaxSlice.linear_s87
theorem linear_p87 (tail : List Nat) : parseRaw 4075 28 (linear_b87 ++ tail) = some (linear_r87, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4074 27 linear_l87_0 linear_v87_0 tail (by rfl) linear_o87 (linear_pl87_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p87
noncomputable def linear_r93 : Raw := (.str [100,103,95,115,108,111,119,95,48])
noncomputable def linear_b93 : List Nat := linear_g237
theorem linear_s93 : serializeRaw 4072 27 linear_r93 = some linear_b93 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s93
theorem linear_p93 (tail : List Nat) : parseRaw 4072 27 (linear_b93 ++ tail) = some (linear_r93, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p93
noncomputable def linear_r94 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,56]),(.str [100,103,95,118,95,49,48,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,57])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
noncomputable def linear_b94 : List Nat := linear_g240
theorem linear_s94 : serializeRaw 4071 27 linear_r94 = some linear_b94 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s94
theorem linear_p94 (tail : List Nat) : parseRaw 4071 27 (linear_b94 ++ tail) = some (linear_r94, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p94
noncomputable def linear_r95 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b95 : List Nat := linear_g243
theorem linear_s95 : serializeRaw 4070 27 linear_r95 = some linear_b95 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s95
theorem linear_p95 (tail : List Nat) : parseRaw 4070 27 (linear_b95 ++ tail) = some (linear_r95, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p95
noncomputable def linear_r96 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,48,57])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))]))])
noncomputable def linear_b96 : List Nat := linear_g246
theorem linear_s96 : serializeRaw 4069 27 linear_r96 = some linear_b96 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s96
theorem linear_p96 (tail : List Nat) : parseRaw 4069 27 (linear_b96 ++ tail) = some (linear_r96, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p96
noncomputable def linear_k92_0 : List Nat := [105,100]
theorem linear_kd92_0 : stringBytes linear_k92_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd92_0
theorem linear_kp92_0 (tail : List Nat) : parseStringTail (linear_k92_0 ++ (34 :: 58 :: tail)) [] = some (linear_k92_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp92_0
noncomputable def linear_k92_1 : List Nat := [111,112,115]
theorem linear_kd92_1 : stringBytes linear_k92_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd92_1
theorem linear_kp92_1 (tail : List Nat) : parseStringTail (linear_k92_1 ++ (34 :: 58 :: tail)) [] = some (linear_k92_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp92_1
noncomputable def linear_k92_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd92_2 : stringBytes linear_k92_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd92_2
theorem linear_kp92_2 (tail : List Nat) : parseStringTail (linear_k92_2 ++ (34 :: 58 :: tail)) [] = some (linear_k92_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp92_2
noncomputable def linear_k92_3 : List Nat := [116,101,114,109]
theorem linear_kd92_3 : stringBytes linear_k92_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd92_3
theorem linear_kp92_3 (tail : List Nat) : parseStringTail (linear_k92_3 ++ (34 :: 58 :: tail)) [] = some (linear_k92_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp92_3
noncomputable def linear_l92_3 : List (List Nat × Raw) := [(linear_k92_3, linear_r96)]
noncomputable def linear_v92_3 : List Nat := linear_g245 ++ linear_b96
theorem linear_sl92_3 : serializeFields 4070 27 linear_l92_3 = some linear_v92_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4069 27 linear_k92_3 linear_r96 linear_b96 linear_g245 (by rfl) linear_kd92_3 linear_s96)
#print axioms HiaCoreSyntaxSlice.linear_sl92_3
theorem linear_pl92_3 (tail : List Nat) : parseFields 4070 27 (linear_v92_3 ++ (125 :: tail)) = some (linear_l92_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4069 27 linear_k92_3 linear_r96 linear_b96 linear_g245 tail (by rfl) (linear_kp92_3 (linear_b96 ++ (125 :: tail))) (linear_p96 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl92_3
noncomputable def linear_l92_2 : List (List Nat × Raw) := (linear_k92_2, linear_r95) :: linear_l92_3
noncomputable def linear_v92_2 : List Nat := (linear_g242 ++ linear_b95) ++ (44 :: linear_v92_3)
theorem linear_sl92_2 : serializeFields 4071 27 linear_l92_2 = some linear_v92_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4070 27 linear_k92_2 linear_r95 (linear_k92_3, linear_r96) [] linear_b95 linear_v92_3 linear_g242 (by rfl) linear_kd92_2 linear_s95 linear_sl92_3)
#print axioms HiaCoreSyntaxSlice.linear_sl92_2
theorem linear_pl92_2 (tail : List Nat) : parseFields 4071 27 (linear_v92_2 ++ (125 :: tail)) = some (linear_l92_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4070 27 linear_k92_2 linear_r95 linear_l92_3 linear_b95 linear_v92_3 linear_g242 tail (by rfl) (linear_kp92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail))))) (linear_p95 (44 :: (linear_v92_3 ++ (125 :: tail)))) (linear_pl92_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl92_2
noncomputable def linear_l92_1 : List (List Nat × Raw) := (linear_k92_1, linear_r94) :: linear_l92_2
noncomputable def linear_v92_1 : List Nat := (linear_g239 ++ linear_b94) ++ (44 :: linear_v92_2)
theorem linear_sl92_1 : serializeFields 4072 27 linear_l92_1 = some linear_v92_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4071 27 linear_k92_1 linear_r94 (linear_k92_2, linear_r95) linear_l92_3 linear_b94 linear_v92_2 linear_g239 (by rfl) linear_kd92_1 linear_s94 linear_sl92_2)
#print axioms HiaCoreSyntaxSlice.linear_sl92_1
theorem linear_pl92_1 (tail : List Nat) : parseFields 4072 27 (linear_v92_1 ++ (125 :: tail)) = some (linear_l92_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4071 27 linear_k92_1 linear_r94 linear_l92_2 linear_b94 linear_v92_2 linear_g239 tail (by rfl) (linear_kp92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail))))) (linear_p94 (44 :: (linear_v92_2 ++ (125 :: tail)))) (linear_pl92_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl92_1
noncomputable def linear_l92_0 : List (List Nat × Raw) := (linear_k92_0, linear_r93) :: linear_l92_1
noncomputable def linear_v92_0 : List Nat := (linear_g236 ++ linear_b93) ++ (44 :: linear_v92_1)
theorem linear_sl92_0 : serializeFields 4073 27 linear_l92_0 = some linear_v92_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4072 27 linear_k92_0 linear_r93 (linear_k92_1, linear_r94) linear_l92_2 linear_b93 linear_v92_1 linear_g236 (by rfl) linear_kd92_0 linear_s93 linear_sl92_1)
#print axioms HiaCoreSyntaxSlice.linear_sl92_0
theorem linear_pl92_0 (tail : List Nat) : parseFields 4073 27 (linear_v92_0 ++ (125 :: tail)) = some (linear_l92_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4072 27 linear_k92_0 linear_r93 linear_l92_1 linear_b93 linear_v92_1 linear_g236 tail (by rfl) (linear_kp92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail))))) (linear_p93 (44 :: (linear_v92_1 ++ (125 :: tail)))) (linear_pl92_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl92_0
noncomputable def linear_r92 : Raw := (.obj linear_l92_0)
noncomputable def linear_b92 : List Nat := linear_g235 ++ (linear_v92_0 ++ linear_g247)
theorem linear_o92 : orderedFields linear_l92_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o92
theorem linear_s92 : serializeRaw 4074 28 linear_r92 = some linear_b92 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4073 27 linear_l92_0 linear_v92_0 linear_o92 linear_sl92_0)
#print axioms HiaCoreSyntaxSlice.linear_s92
theorem linear_p92 (tail : List Nat) : parseRaw 4074 28 (linear_b92 ++ tail) = some (linear_r92, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4073 27 linear_l92_0 linear_v92_0 tail (by rfl) linear_o92 (linear_pl92_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p92
noncomputable def linear_r98 : Raw := (.str [100,103,95,115,108,111,119,95,49])
noncomputable def linear_b98 : List Nat := linear_g251
theorem linear_s98 : serializeRaw 4071 27 linear_r98 = some linear_b98 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s98
theorem linear_p98 (tail : List Nat) : parseRaw 4071 27 (linear_b98 ++ tail) = some (linear_r98, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p98
noncomputable def linear_r100 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,53])),([116,121,112,101],(.str [117,51,50]))])]))])
noncomputable def linear_b100 : List Nat := linear_g255
theorem linear_s100 : serializeRaw 4068 26 linear_r100 = some linear_b100 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s100
theorem linear_p100 (tail : List Nat) : parseRaw 4068 26 (linear_b100 ++ tail) = some (linear_r100, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p100
noncomputable def linear_r101 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,53]),(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,54])),([116,121,112,101],(.str [117,51,50]))])]))])
noncomputable def linear_b101 : List Nat := linear_g257
theorem linear_s101 : serializeRaw 4067 26 linear_r101 = some linear_b101 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s101
theorem linear_p101 (tail : List Nat) : parseRaw 4067 26 (linear_b101 ++ tail) = some (linear_r101, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p101
noncomputable def linear_r102 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,55])),([116,121,112,101],(.str [117,56]))])]))])
noncomputable def linear_b102 : List Nat := linear_g259
theorem linear_s102 : serializeRaw 4066 26 linear_r102 = some linear_b102 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s102
theorem linear_p102 (tail : List Nat) : parseRaw 4066 26 (linear_b102 ++ tail) = some (linear_r102, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p102
noncomputable def linear_r103 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,56])),([116,121,112,101],(.str [117,56]))])]))])
noncomputable def linear_b103 : List Nat := linear_g261
theorem linear_s103 : serializeRaw 4065 26 linear_r103 = some linear_b103 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s103
theorem linear_p103 (tail : List Nat) : parseRaw 4065 26 (linear_b103 ++ tail) = some (linear_r103, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p103
noncomputable def linear_r104 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,55]),(.str [100,103,95,118,95,49,49,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,57])),([116,121,112,101],(.str [117,56]))])]))])
noncomputable def linear_b104 : List Nat := linear_g263
theorem linear_s104 : serializeRaw 4064 26 linear_r104 = some linear_b104 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s104
theorem linear_p104 (tail : List Nat) : parseRaw 4064 26 (linear_b104 ++ tail) = some (linear_r104, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p104
noncomputable def linear_r105 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,57])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,48])),([116,121,112,101],(.str [117,56]))])]))])
noncomputable def linear_b105 : List Nat := linear_g265
theorem linear_s105 : serializeRaw 4063 26 linear_r105 = some linear_b105 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s105
theorem linear_p105 (tail : List Nat) : parseRaw 4063 26 (linear_b105 ++ tail) = some (linear_r105, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p105
noncomputable def linear_r106 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,49])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
noncomputable def linear_b106 : List Nat := linear_g267
theorem linear_s106 : serializeRaw 4062 26 linear_r106 = some linear_b106 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s106
theorem linear_p106 (tail : List Nat) : parseRaw 4062 26 (linear_b106 ++ tail) = some (linear_r106, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p106
noncomputable def linear_r107 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49]),(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
noncomputable def linear_b107 : List Nat := linear_g269
theorem linear_s107 : serializeRaw 4061 26 linear_r107 = some linear_b107 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s107
theorem linear_p107 (tail : List Nat) : parseRaw 4061 26 (linear_b107 ++ tail) = some (linear_r107, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p107
noncomputable def linear_r108 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
noncomputable def linear_b108 : List Nat := linear_g271
theorem linear_s108 : serializeRaw 4060 26 linear_r108 = some linear_b108 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s108
theorem linear_p108 (tail : List Nat) : parseRaw 4060 26 (linear_b108 ++ tail) = some (linear_r108, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p108
noncomputable def linear_r109 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b109 : List Nat := linear_g273
theorem linear_s109 : serializeRaw 4059 26 linear_r109 = some linear_b109 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s109
theorem linear_p109 (tail : List Nat) : parseRaw 4059 26 (linear_b109 ++ tail) = some (linear_r109, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p109
noncomputable def linear_r110 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b110 : List Nat := linear_g275
theorem linear_s110 : serializeRaw 4058 26 linear_r110 = some linear_b110 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s110
theorem linear_p110 (tail : List Nat) : parseRaw 4058 26 (linear_b110 ++ tail) = some (linear_r110, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p110
noncomputable def linear_l99_10 : List Raw := [linear_r110]
noncomputable def linear_v99_10 : List Nat := linear_b110
theorem linear_sl99_10 : serializeItems 4059 26 linear_l99_10 = some linear_v99_10 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_single 4058 26 linear_r110 linear_b110 linear_s110)
#print axioms HiaCoreSyntaxSlice.linear_sl99_10
theorem linear_pl99_10 (tail : List Nat) : parseItems 4059 26 (linear_v99_10 ++ (93 :: tail)) = some (linear_l99_10, tail) := by
  exact (HiaCoreSyntaxSlice.Structured.parse_items_last 4058 26 (linear_b110 ++ (93 :: tail)) tail linear_r110 (linear_p110 (93 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl99_10
noncomputable def linear_l99_9 : List Raw := linear_r109 :: linear_l99_10
noncomputable def linear_v99_9 : List Nat := (linear_b109) ++ (44 :: linear_v99_10)
theorem linear_sl99_9 : serializeItems 4060 26 linear_l99_9 = some linear_v99_9 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4059 26 linear_r109 linear_r110 [] linear_b109 linear_v99_10 linear_s109 linear_sl99_10)
#print axioms HiaCoreSyntaxSlice.linear_sl99_9
theorem linear_pl99_9 (tail : List Nat) : parseItems 4060 26 (linear_v99_9 ++ (93 :: tail)) = some (linear_l99_9, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4059 26 linear_r109 linear_l99_10 linear_b109 linear_v99_10 tail (linear_p109 (44 :: (linear_v99_10 ++ (93 :: tail)))) (linear_pl99_10 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_9
noncomputable def linear_l99_8 : List Raw := linear_r108 :: linear_l99_9
noncomputable def linear_v99_8 : List Nat := (linear_b108) ++ (44 :: linear_v99_9)
theorem linear_sl99_8 : serializeItems 4061 26 linear_l99_8 = some linear_v99_8 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r108 linear_r109 linear_l99_10 linear_b108 linear_v99_9 linear_s108 linear_sl99_9)
#print axioms HiaCoreSyntaxSlice.linear_sl99_8
theorem linear_pl99_8 (tail : List Nat) : parseItems 4061 26 (linear_v99_8 ++ (93 :: tail)) = some (linear_l99_8, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4060 26 linear_r108 linear_l99_9 linear_b108 linear_v99_9 tail (linear_p108 (44 :: (linear_v99_9 ++ (93 :: tail)))) (linear_pl99_9 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_8
noncomputable def linear_l99_7 : List Raw := linear_r107 :: linear_l99_8
noncomputable def linear_v99_7 : List Nat := (linear_b107) ++ (44 :: linear_v99_8)
theorem linear_sl99_7 : serializeItems 4062 26 linear_l99_7 = some linear_v99_7 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r107 linear_r108 linear_l99_9 linear_b107 linear_v99_8 linear_s107 linear_sl99_8)
#print axioms HiaCoreSyntaxSlice.linear_sl99_7
theorem linear_pl99_7 (tail : List Nat) : parseItems 4062 26 (linear_v99_7 ++ (93 :: tail)) = some (linear_l99_7, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4061 26 linear_r107 linear_l99_8 linear_b107 linear_v99_8 tail (linear_p107 (44 :: (linear_v99_8 ++ (93 :: tail)))) (linear_pl99_8 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_7
noncomputable def linear_l99_6 : List Raw := linear_r106 :: linear_l99_7
noncomputable def linear_v99_6 : List Nat := (linear_b106) ++ (44 :: linear_v99_7)
theorem linear_sl99_6 : serializeItems 4063 26 linear_l99_6 = some linear_v99_6 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r106 linear_r107 linear_l99_8 linear_b106 linear_v99_7 linear_s106 linear_sl99_7)
#print axioms HiaCoreSyntaxSlice.linear_sl99_6
theorem linear_pl99_6 (tail : List Nat) : parseItems 4063 26 (linear_v99_6 ++ (93 :: tail)) = some (linear_l99_6, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4062 26 linear_r106 linear_l99_7 linear_b106 linear_v99_7 tail (linear_p106 (44 :: (linear_v99_7 ++ (93 :: tail)))) (linear_pl99_7 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_6
noncomputable def linear_l99_5 : List Raw := linear_r105 :: linear_l99_6
noncomputable def linear_v99_5 : List Nat := (linear_b105) ++ (44 :: linear_v99_6)
theorem linear_sl99_5 : serializeItems 4064 26 linear_l99_5 = some linear_v99_5 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r105 linear_r106 linear_l99_7 linear_b105 linear_v99_6 linear_s105 linear_sl99_6)
#print axioms HiaCoreSyntaxSlice.linear_sl99_5
theorem linear_pl99_5 (tail : List Nat) : parseItems 4064 26 (linear_v99_5 ++ (93 :: tail)) = some (linear_l99_5, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4063 26 linear_r105 linear_l99_6 linear_b105 linear_v99_6 tail (linear_p105 (44 :: (linear_v99_6 ++ (93 :: tail)))) (linear_pl99_6 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_5
noncomputable def linear_l99_4 : List Raw := linear_r104 :: linear_l99_5
noncomputable def linear_v99_4 : List Nat := (linear_b104) ++ (44 :: linear_v99_5)
theorem linear_sl99_4 : serializeItems 4065 26 linear_l99_4 = some linear_v99_4 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r104 linear_r105 linear_l99_6 linear_b104 linear_v99_5 linear_s104 linear_sl99_5)
#print axioms HiaCoreSyntaxSlice.linear_sl99_4
theorem linear_pl99_4 (tail : List Nat) : parseItems 4065 26 (linear_v99_4 ++ (93 :: tail)) = some (linear_l99_4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4064 26 linear_r104 linear_l99_5 linear_b104 linear_v99_5 tail (linear_p104 (44 :: (linear_v99_5 ++ (93 :: tail)))) (linear_pl99_5 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_4
noncomputable def linear_l99_3 : List Raw := linear_r103 :: linear_l99_4
noncomputable def linear_v99_3 : List Nat := (linear_b103) ++ (44 :: linear_v99_4)
theorem linear_sl99_3 : serializeItems 4066 26 linear_l99_3 = some linear_v99_3 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r103 linear_r104 linear_l99_5 linear_b103 linear_v99_4 linear_s103 linear_sl99_4)
#print axioms HiaCoreSyntaxSlice.linear_sl99_3
theorem linear_pl99_3 (tail : List Nat) : parseItems 4066 26 (linear_v99_3 ++ (93 :: tail)) = some (linear_l99_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4065 26 linear_r103 linear_l99_4 linear_b103 linear_v99_4 tail (linear_p103 (44 :: (linear_v99_4 ++ (93 :: tail)))) (linear_pl99_4 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_3
noncomputable def linear_l99_2 : List Raw := linear_r102 :: linear_l99_3
noncomputable def linear_v99_2 : List Nat := (linear_b102) ++ (44 :: linear_v99_3)
theorem linear_sl99_2 : serializeItems 4067 26 linear_l99_2 = some linear_v99_2 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r102 linear_r103 linear_l99_4 linear_b102 linear_v99_3 linear_s102 linear_sl99_3)
#print axioms HiaCoreSyntaxSlice.linear_sl99_2
theorem linear_pl99_2 (tail : List Nat) : parseItems 4067 26 (linear_v99_2 ++ (93 :: tail)) = some (linear_l99_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4066 26 linear_r102 linear_l99_3 linear_b102 linear_v99_3 tail (linear_p102 (44 :: (linear_v99_3 ++ (93 :: tail)))) (linear_pl99_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_2
noncomputable def linear_l99_1 : List Raw := linear_r101 :: linear_l99_2
noncomputable def linear_v99_1 : List Nat := (linear_b101) ++ (44 :: linear_v99_2)
theorem linear_sl99_1 : serializeItems 4068 26 linear_l99_1 = some linear_v99_1 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r101 linear_r102 linear_l99_3 linear_b101 linear_v99_2 linear_s101 linear_sl99_2)
#print axioms HiaCoreSyntaxSlice.linear_sl99_1
theorem linear_pl99_1 (tail : List Nat) : parseItems 4068 26 (linear_v99_1 ++ (93 :: tail)) = some (linear_l99_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4067 26 linear_r101 linear_l99_2 linear_b101 linear_v99_2 tail (linear_p101 (44 :: (linear_v99_2 ++ (93 :: tail)))) (linear_pl99_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_1
noncomputable def linear_l99_0 : List Raw := linear_r100 :: linear_l99_1
noncomputable def linear_v99_0 : List Nat := (linear_b100) ++ (44 :: linear_v99_1)
theorem linear_sl99_0 : serializeItems 4069 26 linear_l99_0 = some linear_v99_0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r100 linear_r101 linear_l99_2 linear_b100 linear_v99_1 linear_s100 linear_sl99_1)
#print axioms HiaCoreSyntaxSlice.linear_sl99_0
theorem linear_pl99_0 (tail : List Nat) : parseItems 4069 26 (linear_v99_0 ++ (93 :: tail)) = some (linear_l99_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4068 26 linear_r100 linear_l99_1 linear_b100 linear_v99_1 tail (linear_p100 (44 :: (linear_v99_1 ++ (93 :: tail)))) (linear_pl99_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl99_0
noncomputable def linear_r99 : Raw := (.arr linear_l99_0)
noncomputable def linear_b99 : List Nat := linear_g254 ++ (linear_v99_0 ++ linear_g276)
theorem linear_s99 : serializeRaw 4070 27 linear_r99 = some linear_b99 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_array 4069 26 linear_l99_0 linear_v99_0 linear_sl99_0)
#print axioms HiaCoreSyntaxSlice.linear_s99
theorem linear_p99 (tail : List Nat) : parseRaw 4070 27 (linear_b99 ++ tail) = some (linear_r99, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_array_bytes 4069 26 linear_l99_0 linear_v99_0 tail (by intro h; cases h) (linear_pl99_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p99
noncomputable def linear_r111 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b111 : List Nat := linear_g279
theorem linear_s111 : serializeRaw 4069 27 linear_r111 = some linear_b111 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s111
theorem linear_p111 (tail : List Nat) : parseRaw 4069 27 (linear_b111 ++ tail) = some (linear_r111, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p111
noncomputable def linear_r112 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,48]),(.str [100,103,95,118,95,49,49,49]),(.str [100,103,95,118,95,49,49,50]),(.str [100,103,95,118,95,49,49,51]),(.str [100,103,95,118,95,49,50,51])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,48]))])
noncomputable def linear_b112 : List Nat := linear_g282
theorem linear_s112 : serializeRaw 4068 27 linear_r112 = some linear_b112 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s112
theorem linear_p112 (tail : List Nat) : parseRaw 4068 27 (linear_b112 ++ tail) = some (linear_r112, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p112
noncomputable def linear_k97_0 : List Nat := [105,100]
theorem linear_kd97_0 : stringBytes linear_k97_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd97_0
theorem linear_kp97_0 (tail : List Nat) : parseStringTail (linear_k97_0 ++ (34 :: 58 :: tail)) [] = some (linear_k97_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp97_0
noncomputable def linear_k97_1 : List Nat := [111,112,115]
theorem linear_kd97_1 : stringBytes linear_k97_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd97_1
theorem linear_kp97_1 (tail : List Nat) : parseStringTail (linear_k97_1 ++ (34 :: 58 :: tail)) [] = some (linear_k97_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp97_1
noncomputable def linear_k97_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd97_2 : stringBytes linear_k97_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd97_2
theorem linear_kp97_2 (tail : List Nat) : parseStringTail (linear_k97_2 ++ (34 :: 58 :: tail)) [] = some (linear_k97_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp97_2
noncomputable def linear_k97_3 : List Nat := [116,101,114,109]
theorem linear_kd97_3 : stringBytes linear_k97_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd97_3
theorem linear_kp97_3 (tail : List Nat) : parseStringTail (linear_k97_3 ++ (34 :: 58 :: tail)) [] = some (linear_k97_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp97_3
noncomputable def linear_l97_3 : List (List Nat × Raw) := [(linear_k97_3, linear_r112)]
noncomputable def linear_v97_3 : List Nat := linear_g281 ++ linear_b112
theorem linear_sl97_3 : serializeFields 4069 27 linear_l97_3 = some linear_v97_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4068 27 linear_k97_3 linear_r112 linear_b112 linear_g281 (by rfl) linear_kd97_3 linear_s112)
#print axioms HiaCoreSyntaxSlice.linear_sl97_3
theorem linear_pl97_3 (tail : List Nat) : parseFields 4069 27 (linear_v97_3 ++ (125 :: tail)) = some (linear_l97_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4068 27 linear_k97_3 linear_r112 linear_b112 linear_g281 tail (by rfl) (linear_kp97_3 (linear_b112 ++ (125 :: tail))) (linear_p112 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl97_3
noncomputable def linear_l97_2 : List (List Nat × Raw) := (linear_k97_2, linear_r111) :: linear_l97_3
noncomputable def linear_v97_2 : List Nat := (linear_g278 ++ linear_b111) ++ (44 :: linear_v97_3)
theorem linear_sl97_2 : serializeFields 4070 27 linear_l97_2 = some linear_v97_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4069 27 linear_k97_2 linear_r111 (linear_k97_3, linear_r112) [] linear_b111 linear_v97_3 linear_g278 (by rfl) linear_kd97_2 linear_s111 linear_sl97_3)
#print axioms HiaCoreSyntaxSlice.linear_sl97_2
theorem linear_pl97_2 (tail : List Nat) : parseFields 4070 27 (linear_v97_2 ++ (125 :: tail)) = some (linear_l97_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4069 27 linear_k97_2 linear_r111 linear_l97_3 linear_b111 linear_v97_3 linear_g278 tail (by rfl) (linear_kp97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail))))) (linear_p111 (44 :: (linear_v97_3 ++ (125 :: tail)))) (linear_pl97_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl97_2
noncomputable def linear_l97_1 : List (List Nat × Raw) := (linear_k97_1, linear_r99) :: linear_l97_2
noncomputable def linear_v97_1 : List Nat := (linear_g253 ++ linear_b99) ++ (44 :: linear_v97_2)
theorem linear_sl97_1 : serializeFields 4071 27 linear_l97_1 = some linear_v97_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4070 27 linear_k97_1 linear_r99 (linear_k97_2, linear_r111) linear_l97_3 linear_b99 linear_v97_2 linear_g253 (by rfl) linear_kd97_1 linear_s99 linear_sl97_2)
#print axioms HiaCoreSyntaxSlice.linear_sl97_1
theorem linear_pl97_1 (tail : List Nat) : parseFields 4071 27 (linear_v97_1 ++ (125 :: tail)) = some (linear_l97_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4070 27 linear_k97_1 linear_r99 linear_l97_2 linear_b99 linear_v97_2 linear_g253 tail (by rfl) (linear_kp97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail))))) (linear_p99 (44 :: (linear_v97_2 ++ (125 :: tail)))) (linear_pl97_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl97_1
noncomputable def linear_l97_0 : List (List Nat × Raw) := (linear_k97_0, linear_r98) :: linear_l97_1
noncomputable def linear_v97_0 : List Nat := (linear_g250 ++ linear_b98) ++ (44 :: linear_v97_1)
theorem linear_sl97_0 : serializeFields 4072 27 linear_l97_0 = some linear_v97_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4071 27 linear_k97_0 linear_r98 (linear_k97_1, linear_r99) linear_l97_2 linear_b98 linear_v97_1 linear_g250 (by rfl) linear_kd97_0 linear_s98 linear_sl97_1)
#print axioms HiaCoreSyntaxSlice.linear_sl97_0
theorem linear_pl97_0 (tail : List Nat) : parseFields 4072 27 (linear_v97_0 ++ (125 :: tail)) = some (linear_l97_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4071 27 linear_k97_0 linear_r98 linear_l97_1 linear_b98 linear_v97_1 linear_g250 tail (by rfl) (linear_kp97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail))))) (linear_p98 (44 :: (linear_v97_1 ++ (125 :: tail)))) (linear_pl97_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl97_0
noncomputable def linear_r97 : Raw := (.obj linear_l97_0)
noncomputable def linear_b97 : List Nat := linear_g249 ++ (linear_v97_0 ++ linear_g283)
theorem linear_o97 : orderedFields linear_l97_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o97
theorem linear_s97 : serializeRaw 4073 28 linear_r97 = some linear_b97 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4072 27 linear_l97_0 linear_v97_0 linear_o97 linear_sl97_0)
#print axioms HiaCoreSyntaxSlice.linear_s97
theorem linear_p97 (tail : List Nat) : parseRaw 4073 28 (linear_b97 ++ tail) = some (linear_r97, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4072 27 linear_l97_0 linear_v97_0 tail (by rfl) linear_o97 (linear_pl97_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p97
noncomputable def linear_r114 : Raw := (.str [100,103,95,115,108,111,119,95,50])
noncomputable def linear_b114 : List Nat := linear_g287
theorem linear_s114 : serializeRaw 4070 27 linear_r114 = some linear_b114 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s114
theorem linear_p114 (tail : List Nat) : parseRaw 4070 27 (linear_b114 ++ tail) = some (linear_r114, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p114
noncomputable def linear_r115 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,57])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
noncomputable def linear_b115 : List Nat := linear_g290
theorem linear_s115 : serializeRaw 4069 27 linear_r115 = some linear_b115 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s115
theorem linear_p115 (tail : List Nat) : parseRaw 4069 27 (linear_b115 ++ tail) = some (linear_r115, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p115
noncomputable def linear_r116 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b116 : List Nat := linear_g293
theorem linear_s116 : serializeRaw 4068 27 linear_r116 = some linear_b116 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s116
theorem linear_p116 (tail : List Nat) : parseRaw 4068 27 (linear_b116 ++ tail) = some (linear_r116, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p116
noncomputable def linear_r117 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,50,53]),(.str [100,103,95,118,95,49,50,54]),(.str [100,103,95,118,95,49,50,57]),(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,51,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
noncomputable def linear_b117 : List Nat := linear_g296
theorem linear_s117 : serializeRaw 4067 27 linear_r117 = some linear_b117 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s117
theorem linear_p117 (tail : List Nat) : parseRaw 4067 27 (linear_b117 ++ tail) = some (linear_r117, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p117
noncomputable def linear_k113_0 : List Nat := [105,100]
theorem linear_kd113_0 : stringBytes linear_k113_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd113_0
theorem linear_kp113_0 (tail : List Nat) : parseStringTail (linear_k113_0 ++ (34 :: 58 :: tail)) [] = some (linear_k113_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp113_0
noncomputable def linear_k113_1 : List Nat := [111,112,115]
theorem linear_kd113_1 : stringBytes linear_k113_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd113_1
theorem linear_kp113_1 (tail : List Nat) : parseStringTail (linear_k113_1 ++ (34 :: 58 :: tail)) [] = some (linear_k113_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp113_1
noncomputable def linear_k113_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd113_2 : stringBytes linear_k113_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd113_2
theorem linear_kp113_2 (tail : List Nat) : parseStringTail (linear_k113_2 ++ (34 :: 58 :: tail)) [] = some (linear_k113_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp113_2
noncomputable def linear_k113_3 : List Nat := [116,101,114,109]
theorem linear_kd113_3 : stringBytes linear_k113_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd113_3
theorem linear_kp113_3 (tail : List Nat) : parseStringTail (linear_k113_3 ++ (34 :: 58 :: tail)) [] = some (linear_k113_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp113_3
noncomputable def linear_l113_3 : List (List Nat × Raw) := [(linear_k113_3, linear_r117)]
noncomputable def linear_v113_3 : List Nat := linear_g295 ++ linear_b117
theorem linear_sl113_3 : serializeFields 4068 27 linear_l113_3 = some linear_v113_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4067 27 linear_k113_3 linear_r117 linear_b117 linear_g295 (by rfl) linear_kd113_3 linear_s117)
#print axioms HiaCoreSyntaxSlice.linear_sl113_3
theorem linear_pl113_3 (tail : List Nat) : parseFields 4068 27 (linear_v113_3 ++ (125 :: tail)) = some (linear_l113_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4067 27 linear_k113_3 linear_r117 linear_b117 linear_g295 tail (by rfl) (linear_kp113_3 (linear_b117 ++ (125 :: tail))) (linear_p117 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl113_3
noncomputable def linear_l113_2 : List (List Nat × Raw) := (linear_k113_2, linear_r116) :: linear_l113_3
noncomputable def linear_v113_2 : List Nat := (linear_g292 ++ linear_b116) ++ (44 :: linear_v113_3)
theorem linear_sl113_2 : serializeFields 4069 27 linear_l113_2 = some linear_v113_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4068 27 linear_k113_2 linear_r116 (linear_k113_3, linear_r117) [] linear_b116 linear_v113_3 linear_g292 (by rfl) linear_kd113_2 linear_s116 linear_sl113_3)
#print axioms HiaCoreSyntaxSlice.linear_sl113_2
theorem linear_pl113_2 (tail : List Nat) : parseFields 4069 27 (linear_v113_2 ++ (125 :: tail)) = some (linear_l113_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4068 27 linear_k113_2 linear_r116 linear_l113_3 linear_b116 linear_v113_3 linear_g292 tail (by rfl) (linear_kp113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail))))) (linear_p116 (44 :: (linear_v113_3 ++ (125 :: tail)))) (linear_pl113_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl113_2
noncomputable def linear_l113_1 : List (List Nat × Raw) := (linear_k113_1, linear_r115) :: linear_l113_2
noncomputable def linear_v113_1 : List Nat := (linear_g289 ++ linear_b115) ++ (44 :: linear_v113_2)
theorem linear_sl113_1 : serializeFields 4070 27 linear_l113_1 = some linear_v113_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4069 27 linear_k113_1 linear_r115 (linear_k113_2, linear_r116) linear_l113_3 linear_b115 linear_v113_2 linear_g289 (by rfl) linear_kd113_1 linear_s115 linear_sl113_2)
#print axioms HiaCoreSyntaxSlice.linear_sl113_1
theorem linear_pl113_1 (tail : List Nat) : parseFields 4070 27 (linear_v113_1 ++ (125 :: tail)) = some (linear_l113_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4069 27 linear_k113_1 linear_r115 linear_l113_2 linear_b115 linear_v113_2 linear_g289 tail (by rfl) (linear_kp113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail))))) (linear_p115 (44 :: (linear_v113_2 ++ (125 :: tail)))) (linear_pl113_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl113_1
noncomputable def linear_l113_0 : List (List Nat × Raw) := (linear_k113_0, linear_r114) :: linear_l113_1
noncomputable def linear_v113_0 : List Nat := (linear_g286 ++ linear_b114) ++ (44 :: linear_v113_1)
theorem linear_sl113_0 : serializeFields 4071 27 linear_l113_0 = some linear_v113_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4070 27 linear_k113_0 linear_r114 (linear_k113_1, linear_r115) linear_l113_2 linear_b114 linear_v113_1 linear_g286 (by rfl) linear_kd113_0 linear_s114 linear_sl113_1)
#print axioms HiaCoreSyntaxSlice.linear_sl113_0
theorem linear_pl113_0 (tail : List Nat) : parseFields 4071 27 (linear_v113_0 ++ (125 :: tail)) = some (linear_l113_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4070 27 linear_k113_0 linear_r114 linear_l113_1 linear_b114 linear_v113_1 linear_g286 tail (by rfl) (linear_kp113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail))))) (linear_p114 (44 :: (linear_v113_1 ++ (125 :: tail)))) (linear_pl113_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl113_0
noncomputable def linear_r113 : Raw := (.obj linear_l113_0)
noncomputable def linear_b113 : List Nat := linear_g285 ++ (linear_v113_0 ++ linear_g297)
theorem linear_o113 : orderedFields linear_l113_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o113
theorem linear_s113 : serializeRaw 4072 28 linear_r113 = some linear_b113 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4071 27 linear_l113_0 linear_v113_0 linear_o113 linear_sl113_0)
#print axioms HiaCoreSyntaxSlice.linear_s113
theorem linear_p113 (tail : List Nat) : parseRaw 4072 28 (linear_b113 ++ tail) = some (linear_r113, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4071 27 linear_l113_0 linear_v113_0 tail (by rfl) linear_o113 (linear_pl113_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p113
noncomputable def linear_r119 : Raw := (.str [100,103,95,115,108,111,119,95,51])
noncomputable def linear_b119 : List Nat := linear_g301
theorem linear_s119 : serializeRaw 4069 27 linear_r119 = some linear_b119 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s119
theorem linear_p119 (tail : List Nat) : parseRaw 4069 27 (linear_b119 ++ tail) = some (linear_r119, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p119
noncomputable def linear_r120 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,54]),(.str [100,103,95,118,95,49,51,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,55])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
noncomputable def linear_b120 : List Nat := linear_g304
theorem linear_s120 : serializeRaw 4068 27 linear_r120 = some linear_b120 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s120
theorem linear_p120 (tail : List Nat) : parseRaw 4068 27 (linear_b120 ++ tail) = some (linear_r120, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p120
noncomputable def linear_r121 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,52])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b121 : List Nat := linear_g307
theorem linear_s121 : serializeRaw 4067 27 linear_r121 = some linear_b121 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s121
theorem linear_p121 (tail : List Nat) : parseRaw 4067 27 (linear_b121 ++ tail) = some (linear_r121, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p121
noncomputable def linear_r122 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,51,55])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))]))])
noncomputable def linear_b122 : List Nat := linear_g310
theorem linear_s122 : serializeRaw 4066 27 linear_r122 = some linear_b122 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s122
theorem linear_p122 (tail : List Nat) : parseRaw 4066 27 (linear_b122 ++ tail) = some (linear_r122, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p122
noncomputable def linear_k118_0 : List Nat := [105,100]
theorem linear_kd118_0 : stringBytes linear_k118_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd118_0
theorem linear_kp118_0 (tail : List Nat) : parseStringTail (linear_k118_0 ++ (34 :: 58 :: tail)) [] = some (linear_k118_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp118_0
noncomputable def linear_k118_1 : List Nat := [111,112,115]
theorem linear_kd118_1 : stringBytes linear_k118_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd118_1
theorem linear_kp118_1 (tail : List Nat) : parseStringTail (linear_k118_1 ++ (34 :: 58 :: tail)) [] = some (linear_k118_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp118_1
noncomputable def linear_k118_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd118_2 : stringBytes linear_k118_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd118_2
theorem linear_kp118_2 (tail : List Nat) : parseStringTail (linear_k118_2 ++ (34 :: 58 :: tail)) [] = some (linear_k118_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp118_2
noncomputable def linear_k118_3 : List Nat := [116,101,114,109]
theorem linear_kd118_3 : stringBytes linear_k118_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd118_3
theorem linear_kp118_3 (tail : List Nat) : parseStringTail (linear_k118_3 ++ (34 :: 58 :: tail)) [] = some (linear_k118_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp118_3
noncomputable def linear_l118_3 : List (List Nat × Raw) := [(linear_k118_3, linear_r122)]
noncomputable def linear_v118_3 : List Nat := linear_g309 ++ linear_b122
theorem linear_sl118_3 : serializeFields 4067 27 linear_l118_3 = some linear_v118_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4066 27 linear_k118_3 linear_r122 linear_b122 linear_g309 (by rfl) linear_kd118_3 linear_s122)
#print axioms HiaCoreSyntaxSlice.linear_sl118_3
theorem linear_pl118_3 (tail : List Nat) : parseFields 4067 27 (linear_v118_3 ++ (125 :: tail)) = some (linear_l118_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4066 27 linear_k118_3 linear_r122 linear_b122 linear_g309 tail (by rfl) (linear_kp118_3 (linear_b122 ++ (125 :: tail))) (linear_p122 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl118_3
noncomputable def linear_l118_2 : List (List Nat × Raw) := (linear_k118_2, linear_r121) :: linear_l118_3
noncomputable def linear_v118_2 : List Nat := (linear_g306 ++ linear_b121) ++ (44 :: linear_v118_3)
theorem linear_sl118_2 : serializeFields 4068 27 linear_l118_2 = some linear_v118_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4067 27 linear_k118_2 linear_r121 (linear_k118_3, linear_r122) [] linear_b121 linear_v118_3 linear_g306 (by rfl) linear_kd118_2 linear_s121 linear_sl118_3)
#print axioms HiaCoreSyntaxSlice.linear_sl118_2
theorem linear_pl118_2 (tail : List Nat) : parseFields 4068 27 (linear_v118_2 ++ (125 :: tail)) = some (linear_l118_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4067 27 linear_k118_2 linear_r121 linear_l118_3 linear_b121 linear_v118_3 linear_g306 tail (by rfl) (linear_kp118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail))))) (linear_p121 (44 :: (linear_v118_3 ++ (125 :: tail)))) (linear_pl118_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl118_2
noncomputable def linear_l118_1 : List (List Nat × Raw) := (linear_k118_1, linear_r120) :: linear_l118_2
noncomputable def linear_v118_1 : List Nat := (linear_g303 ++ linear_b120) ++ (44 :: linear_v118_2)
theorem linear_sl118_1 : serializeFields 4069 27 linear_l118_1 = some linear_v118_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4068 27 linear_k118_1 linear_r120 (linear_k118_2, linear_r121) linear_l118_3 linear_b120 linear_v118_2 linear_g303 (by rfl) linear_kd118_1 linear_s120 linear_sl118_2)
#print axioms HiaCoreSyntaxSlice.linear_sl118_1
theorem linear_pl118_1 (tail : List Nat) : parseFields 4069 27 (linear_v118_1 ++ (125 :: tail)) = some (linear_l118_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4068 27 linear_k118_1 linear_r120 linear_l118_2 linear_b120 linear_v118_2 linear_g303 tail (by rfl) (linear_kp118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail))))) (linear_p120 (44 :: (linear_v118_2 ++ (125 :: tail)))) (linear_pl118_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl118_1
noncomputable def linear_l118_0 : List (List Nat × Raw) := (linear_k118_0, linear_r119) :: linear_l118_1
noncomputable def linear_v118_0 : List Nat := (linear_g300 ++ linear_b119) ++ (44 :: linear_v118_1)
theorem linear_sl118_0 : serializeFields 4070 27 linear_l118_0 = some linear_v118_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4069 27 linear_k118_0 linear_r119 (linear_k118_1, linear_r120) linear_l118_2 linear_b119 linear_v118_1 linear_g300 (by rfl) linear_kd118_0 linear_s119 linear_sl118_1)
#print axioms HiaCoreSyntaxSlice.linear_sl118_0
theorem linear_pl118_0 (tail : List Nat) : parseFields 4070 27 (linear_v118_0 ++ (125 :: tail)) = some (linear_l118_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4069 27 linear_k118_0 linear_r119 linear_l118_1 linear_b119 linear_v118_1 linear_g300 tail (by rfl) (linear_kp118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail))))) (linear_p119 (44 :: (linear_v118_1 ++ (125 :: tail)))) (linear_pl118_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl118_0
noncomputable def linear_r118 : Raw := (.obj linear_l118_0)
noncomputable def linear_b118 : List Nat := linear_g299 ++ (linear_v118_0 ++ linear_g311)
theorem linear_o118 : orderedFields linear_l118_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o118
theorem linear_s118 : serializeRaw 4071 28 linear_r118 = some linear_b118 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4070 27 linear_l118_0 linear_v118_0 linear_o118 linear_sl118_0)
#print axioms HiaCoreSyntaxSlice.linear_s118
theorem linear_p118 (tail : List Nat) : parseRaw 4071 28 (linear_b118 ++ tail) = some (linear_r118, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4070 27 linear_l118_0 linear_v118_0 tail (by rfl) linear_o118 (linear_pl118_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p118
noncomputable def linear_r124 : Raw := (.str [100,103,95,115,108,111,119,95,52])
noncomputable def linear_b124 : List Nat := linear_g315
theorem linear_s124 : serializeRaw 4068 27 linear_r124 = some linear_b124 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s124
theorem linear_p124 (tail : List Nat) : parseRaw 4068 27 (linear_b124 ++ tail) = some (linear_r124, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p124
noncomputable def linear_r126 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,52])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
noncomputable def linear_b126 : List Nat := linear_g319
theorem linear_s126 : serializeRaw 4065 26 linear_r126 = some linear_b126 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s126
theorem linear_p126 (tail : List Nat) : parseRaw 4065 26 (linear_b126 ++ tail) = some (linear_r126, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p126
noncomputable def linear_r127 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52]),(.str [100,103,95,118,95,49,52,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,53])),([116,121,112,101],(.str [117,56]))])]))])
noncomputable def linear_b127 : List Nat := linear_g321
theorem linear_s127 : serializeRaw 4064 26 linear_r127 = some linear_b127 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s127
theorem linear_p127 (tail : List Nat) : parseRaw 4064 26 (linear_b127 ++ tail) = some (linear_r127, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p127
noncomputable def linear_r128 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
noncomputable def linear_b128 : List Nat := linear_g323
theorem linear_s128 : serializeRaw 4063 26 linear_r128 = some linear_b128 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s128
theorem linear_p128 (tail : List Nat) : parseRaw 4063 26 (linear_b128 ++ tail) = some (linear_r128, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p128
noncomputable def linear_r129 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,54])),([116,121,112,101],(.str [117,54,52]))])]))])
noncomputable def linear_b129 : List Nat := linear_g325
theorem linear_s129 : serializeRaw 4062 26 linear_r129 = some linear_b129 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s129
theorem linear_p129 (tail : List Nat) : parseRaw 4062 26 (linear_b129 ++ tail) = some (linear_r129, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p129
noncomputable def linear_r130 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,49]),(.str [100,103,95,118,95,49,52,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,55])),([116,121,112,101],(.str [117,54,52]))])]))])
noncomputable def linear_b130 : List Nat := linear_g327
theorem linear_s130 : serializeRaw 4061 26 linear_r130 = some linear_b130 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s130
theorem linear_p130 (tail : List Nat) : parseRaw 4061 26 (linear_b130 ++ tail) = some (linear_r130, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p130
noncomputable def linear_r131 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b131 : List Nat := linear_g329
theorem linear_s131 : serializeRaw 4060 26 linear_r131 = some linear_b131 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s131
theorem linear_p131 (tail : List Nat) : parseRaw 4060 26 (linear_b131 ++ tail) = some (linear_r131, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p131
noncomputable def linear_r132 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,51]),(.str [100,103,95,118,95,49,52,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
noncomputable def linear_b132 : List Nat := linear_g331
theorem linear_s132 : serializeRaw 4059 26 linear_r132 = some linear_b132 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s132
theorem linear_p132 (tail : List Nat) : parseRaw 4059 26 (linear_b132 ++ tail) = some (linear_r132, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p132
noncomputable def linear_l125_6 : List Raw := [linear_r132]
noncomputable def linear_v125_6 : List Nat := linear_b132
theorem linear_sl125_6 : serializeItems 4060 26 linear_l125_6 = some linear_v125_6 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_single 4059 26 linear_r132 linear_b132 linear_s132)
#print axioms HiaCoreSyntaxSlice.linear_sl125_6
theorem linear_pl125_6 (tail : List Nat) : parseItems 4060 26 (linear_v125_6 ++ (93 :: tail)) = some (linear_l125_6, tail) := by
  exact (HiaCoreSyntaxSlice.Structured.parse_items_last 4059 26 (linear_b132 ++ (93 :: tail)) tail linear_r132 (linear_p132 (93 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl125_6
noncomputable def linear_l125_5 : List Raw := linear_r131 :: linear_l125_6
noncomputable def linear_v125_5 : List Nat := (linear_b131) ++ (44 :: linear_v125_6)
theorem linear_sl125_5 : serializeItems 4061 26 linear_l125_5 = some linear_v125_5 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r131 linear_r132 [] linear_b131 linear_v125_6 linear_s131 linear_sl125_6)
#print axioms HiaCoreSyntaxSlice.linear_sl125_5
theorem linear_pl125_5 (tail : List Nat) : parseItems 4061 26 (linear_v125_5 ++ (93 :: tail)) = some (linear_l125_5, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4060 26 linear_r131 linear_l125_6 linear_b131 linear_v125_6 tail (linear_p131 (44 :: (linear_v125_6 ++ (93 :: tail)))) (linear_pl125_6 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl125_5
noncomputable def linear_l125_4 : List Raw := linear_r130 :: linear_l125_5
noncomputable def linear_v125_4 : List Nat := (linear_b130) ++ (44 :: linear_v125_5)
theorem linear_sl125_4 : serializeItems 4062 26 linear_l125_4 = some linear_v125_4 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r130 linear_r131 linear_l125_6 linear_b130 linear_v125_5 linear_s130 linear_sl125_5)
#print axioms HiaCoreSyntaxSlice.linear_sl125_4
theorem linear_pl125_4 (tail : List Nat) : parseItems 4062 26 (linear_v125_4 ++ (93 :: tail)) = some (linear_l125_4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4061 26 linear_r130 linear_l125_5 linear_b130 linear_v125_5 tail (linear_p130 (44 :: (linear_v125_5 ++ (93 :: tail)))) (linear_pl125_5 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl125_4
noncomputable def linear_l125_3 : List Raw := linear_r129 :: linear_l125_4
noncomputable def linear_v125_3 : List Nat := (linear_b129) ++ (44 :: linear_v125_4)
theorem linear_sl125_3 : serializeItems 4063 26 linear_l125_3 = some linear_v125_3 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r129 linear_r130 linear_l125_5 linear_b129 linear_v125_4 linear_s129 linear_sl125_4)
#print axioms HiaCoreSyntaxSlice.linear_sl125_3
theorem linear_pl125_3 (tail : List Nat) : parseItems 4063 26 (linear_v125_3 ++ (93 :: tail)) = some (linear_l125_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4062 26 linear_r129 linear_l125_4 linear_b129 linear_v125_4 tail (linear_p129 (44 :: (linear_v125_4 ++ (93 :: tail)))) (linear_pl125_4 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl125_3
noncomputable def linear_l125_2 : List Raw := linear_r128 :: linear_l125_3
noncomputable def linear_v125_2 : List Nat := (linear_b128) ++ (44 :: linear_v125_3)
theorem linear_sl125_2 : serializeItems 4064 26 linear_l125_2 = some linear_v125_2 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r128 linear_r129 linear_l125_4 linear_b128 linear_v125_3 linear_s128 linear_sl125_3)
#print axioms HiaCoreSyntaxSlice.linear_sl125_2
theorem linear_pl125_2 (tail : List Nat) : parseItems 4064 26 (linear_v125_2 ++ (93 :: tail)) = some (linear_l125_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4063 26 linear_r128 linear_l125_3 linear_b128 linear_v125_3 tail (linear_p128 (44 :: (linear_v125_3 ++ (93 :: tail)))) (linear_pl125_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl125_2
noncomputable def linear_l125_1 : List Raw := linear_r127 :: linear_l125_2
noncomputable def linear_v125_1 : List Nat := (linear_b127) ++ (44 :: linear_v125_2)
theorem linear_sl125_1 : serializeItems 4065 26 linear_l125_1 = some linear_v125_1 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r127 linear_r128 linear_l125_3 linear_b127 linear_v125_2 linear_s127 linear_sl125_2)
#print axioms HiaCoreSyntaxSlice.linear_sl125_1
theorem linear_pl125_1 (tail : List Nat) : parseItems 4065 26 (linear_v125_1 ++ (93 :: tail)) = some (linear_l125_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4064 26 linear_r127 linear_l125_2 linear_b127 linear_v125_2 tail (linear_p127 (44 :: (linear_v125_2 ++ (93 :: tail)))) (linear_pl125_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl125_1
noncomputable def linear_l125_0 : List Raw := linear_r126 :: linear_l125_1
noncomputable def linear_v125_0 : List Nat := (linear_b126) ++ (44 :: linear_v125_1)
theorem linear_sl125_0 : serializeItems 4066 26 linear_l125_0 = some linear_v125_0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r126 linear_r127 linear_l125_2 linear_b126 linear_v125_1 linear_s126 linear_sl125_1)
#print axioms HiaCoreSyntaxSlice.linear_sl125_0
theorem linear_pl125_0 (tail : List Nat) : parseItems 4066 26 (linear_v125_0 ++ (93 :: tail)) = some (linear_l125_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4065 26 linear_r126 linear_l125_1 linear_b126 linear_v125_1 tail (linear_p126 (44 :: (linear_v125_1 ++ (93 :: tail)))) (linear_pl125_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl125_0
noncomputable def linear_r125 : Raw := (.arr linear_l125_0)
noncomputable def linear_b125 : List Nat := linear_g318 ++ (linear_v125_0 ++ linear_g332)
theorem linear_s125 : serializeRaw 4067 27 linear_r125 = some linear_b125 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_array 4066 26 linear_l125_0 linear_v125_0 linear_sl125_0)
#print axioms HiaCoreSyntaxSlice.linear_s125
theorem linear_p125 (tail : List Nat) : parseRaw 4067 27 (linear_b125 ++ tail) = some (linear_r125, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_array_bytes 4066 26 linear_l125_0 linear_v125_0 tail (by intro h; cases h) (linear_pl125_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p125
noncomputable def linear_r133 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b133 : List Nat := linear_g335
theorem linear_s133 : serializeRaw 4066 27 linear_r133 = some linear_b133 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s133
theorem linear_p133 (tail : List Nat) : parseRaw 4066 27 (linear_b133 ++ tail) = some (linear_r133, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p133
noncomputable def linear_r134 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,56]),(.str [100,103,95,118,95,49,51,57]),(.str [100,103,95,118,95,49,52,48]),(.str [100,103,95,118,95,49,52,55]),(.str [100,103,95,118,95,49,52,50]),(.str [100,103,95,118,95,49,52,57])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
noncomputable def linear_b134 : List Nat := linear_g338
theorem linear_s134 : serializeRaw 4065 27 linear_r134 = some linear_b134 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s134
theorem linear_p134 (tail : List Nat) : parseRaw 4065 27 (linear_b134 ++ tail) = some (linear_r134, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p134
noncomputable def linear_k123_0 : List Nat := [105,100]
theorem linear_kd123_0 : stringBytes linear_k123_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd123_0
theorem linear_kp123_0 (tail : List Nat) : parseStringTail (linear_k123_0 ++ (34 :: 58 :: tail)) [] = some (linear_k123_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp123_0
noncomputable def linear_k123_1 : List Nat := [111,112,115]
theorem linear_kd123_1 : stringBytes linear_k123_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd123_1
theorem linear_kp123_1 (tail : List Nat) : parseStringTail (linear_k123_1 ++ (34 :: 58 :: tail)) [] = some (linear_k123_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp123_1
noncomputable def linear_k123_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd123_2 : stringBytes linear_k123_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd123_2
theorem linear_kp123_2 (tail : List Nat) : parseStringTail (linear_k123_2 ++ (34 :: 58 :: tail)) [] = some (linear_k123_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp123_2
noncomputable def linear_k123_3 : List Nat := [116,101,114,109]
theorem linear_kd123_3 : stringBytes linear_k123_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd123_3
theorem linear_kp123_3 (tail : List Nat) : parseStringTail (linear_k123_3 ++ (34 :: 58 :: tail)) [] = some (linear_k123_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp123_3
noncomputable def linear_l123_3 : List (List Nat × Raw) := [(linear_k123_3, linear_r134)]
noncomputable def linear_v123_3 : List Nat := linear_g337 ++ linear_b134
theorem linear_sl123_3 : serializeFields 4066 27 linear_l123_3 = some linear_v123_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4065 27 linear_k123_3 linear_r134 linear_b134 linear_g337 (by rfl) linear_kd123_3 linear_s134)
#print axioms HiaCoreSyntaxSlice.linear_sl123_3
theorem linear_pl123_3 (tail : List Nat) : parseFields 4066 27 (linear_v123_3 ++ (125 :: tail)) = some (linear_l123_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4065 27 linear_k123_3 linear_r134 linear_b134 linear_g337 tail (by rfl) (linear_kp123_3 (linear_b134 ++ (125 :: tail))) (linear_p134 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl123_3
noncomputable def linear_l123_2 : List (List Nat × Raw) := (linear_k123_2, linear_r133) :: linear_l123_3
noncomputable def linear_v123_2 : List Nat := (linear_g334 ++ linear_b133) ++ (44 :: linear_v123_3)
theorem linear_sl123_2 : serializeFields 4067 27 linear_l123_2 = some linear_v123_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4066 27 linear_k123_2 linear_r133 (linear_k123_3, linear_r134) [] linear_b133 linear_v123_3 linear_g334 (by rfl) linear_kd123_2 linear_s133 linear_sl123_3)
#print axioms HiaCoreSyntaxSlice.linear_sl123_2
theorem linear_pl123_2 (tail : List Nat) : parseFields 4067 27 (linear_v123_2 ++ (125 :: tail)) = some (linear_l123_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4066 27 linear_k123_2 linear_r133 linear_l123_3 linear_b133 linear_v123_3 linear_g334 tail (by rfl) (linear_kp123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail))))) (linear_p133 (44 :: (linear_v123_3 ++ (125 :: tail)))) (linear_pl123_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl123_2
noncomputable def linear_l123_1 : List (List Nat × Raw) := (linear_k123_1, linear_r125) :: linear_l123_2
noncomputable def linear_v123_1 : List Nat := (linear_g317 ++ linear_b125) ++ (44 :: linear_v123_2)
theorem linear_sl123_1 : serializeFields 4068 27 linear_l123_1 = some linear_v123_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4067 27 linear_k123_1 linear_r125 (linear_k123_2, linear_r133) linear_l123_3 linear_b125 linear_v123_2 linear_g317 (by rfl) linear_kd123_1 linear_s125 linear_sl123_2)
#print axioms HiaCoreSyntaxSlice.linear_sl123_1
theorem linear_pl123_1 (tail : List Nat) : parseFields 4068 27 (linear_v123_1 ++ (125 :: tail)) = some (linear_l123_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4067 27 linear_k123_1 linear_r125 linear_l123_2 linear_b125 linear_v123_2 linear_g317 tail (by rfl) (linear_kp123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail))))) (linear_p125 (44 :: (linear_v123_2 ++ (125 :: tail)))) (linear_pl123_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl123_1
noncomputable def linear_l123_0 : List (List Nat × Raw) := (linear_k123_0, linear_r124) :: linear_l123_1
noncomputable def linear_v123_0 : List Nat := (linear_g314 ++ linear_b124) ++ (44 :: linear_v123_1)
theorem linear_sl123_0 : serializeFields 4069 27 linear_l123_0 = some linear_v123_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4068 27 linear_k123_0 linear_r124 (linear_k123_1, linear_r125) linear_l123_2 linear_b124 linear_v123_1 linear_g314 (by rfl) linear_kd123_0 linear_s124 linear_sl123_1)
#print axioms HiaCoreSyntaxSlice.linear_sl123_0
theorem linear_pl123_0 (tail : List Nat) : parseFields 4069 27 (linear_v123_0 ++ (125 :: tail)) = some (linear_l123_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4068 27 linear_k123_0 linear_r124 linear_l123_1 linear_b124 linear_v123_1 linear_g314 tail (by rfl) (linear_kp123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail))))) (linear_p124 (44 :: (linear_v123_1 ++ (125 :: tail)))) (linear_pl123_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl123_0
noncomputable def linear_r123 : Raw := (.obj linear_l123_0)
noncomputable def linear_b123 : List Nat := linear_g313 ++ (linear_v123_0 ++ linear_g339)
theorem linear_o123 : orderedFields linear_l123_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o123
theorem linear_s123 : serializeRaw 4070 28 linear_r123 = some linear_b123 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4069 27 linear_l123_0 linear_v123_0 linear_o123 linear_sl123_0)
#print axioms HiaCoreSyntaxSlice.linear_s123
theorem linear_p123 (tail : List Nat) : parseRaw 4070 28 (linear_b123 ++ tail) = some (linear_r123, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4069 27 linear_l123_0 linear_v123_0 tail (by rfl) linear_o123 (linear_pl123_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p123
noncomputable def linear_r136 : Raw := (.str [100,103,95,115,108,111,119,95,53])
noncomputable def linear_b136 : List Nat := linear_g343
theorem linear_s136 : serializeRaw 4067 27 linear_r136 = some linear_b136 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s136
theorem linear_p136 (tail : List Nat) : parseRaw 4067 27 (linear_b136 ++ tail) = some (linear_r136, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p136
noncomputable def linear_r137 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
noncomputable def linear_b137 : List Nat := linear_g346
theorem linear_s137 : serializeRaw 4066 27 linear_r137 = some linear_b137 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s137
theorem linear_p137 (tail : List Nat) : parseRaw 4066 27 (linear_b137 ++ tail) = some (linear_r137, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p137
noncomputable def linear_r138 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,51])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b138 : List Nat := linear_g349
theorem linear_s138 : serializeRaw 4065 27 linear_r138 = some linear_b138 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s138
theorem linear_p138 (tail : List Nat) : parseRaw 4065 27 (linear_b138 ++ tail) = some (linear_r138, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p138
noncomputable def linear_r139 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,53,51])]))])
noncomputable def linear_b139 : List Nat := linear_g352
theorem linear_s139 : serializeRaw 4064 27 linear_r139 = some linear_b139 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s139
theorem linear_p139 (tail : List Nat) : parseRaw 4064 27 (linear_b139 ++ tail) = some (linear_r139, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p139
noncomputable def linear_k135_0 : List Nat := [105,100]
theorem linear_kd135_0 : stringBytes linear_k135_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd135_0
theorem linear_kp135_0 (tail : List Nat) : parseStringTail (linear_k135_0 ++ (34 :: 58 :: tail)) [] = some (linear_k135_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp135_0
noncomputable def linear_k135_1 : List Nat := [111,112,115]
theorem linear_kd135_1 : stringBytes linear_k135_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd135_1
theorem linear_kp135_1 (tail : List Nat) : parseStringTail (linear_k135_1 ++ (34 :: 58 :: tail)) [] = some (linear_k135_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp135_1
noncomputable def linear_k135_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd135_2 : stringBytes linear_k135_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd135_2
theorem linear_kp135_2 (tail : List Nat) : parseStringTail (linear_k135_2 ++ (34 :: 58 :: tail)) [] = some (linear_k135_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp135_2
noncomputable def linear_k135_3 : List Nat := [116,101,114,109]
theorem linear_kd135_3 : stringBytes linear_k135_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd135_3
theorem linear_kp135_3 (tail : List Nat) : parseStringTail (linear_k135_3 ++ (34 :: 58 :: tail)) [] = some (linear_k135_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp135_3
noncomputable def linear_l135_3 : List (List Nat × Raw) := [(linear_k135_3, linear_r139)]
noncomputable def linear_v135_3 : List Nat := linear_g351 ++ linear_b139
theorem linear_sl135_3 : serializeFields 4065 27 linear_l135_3 = some linear_v135_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4064 27 linear_k135_3 linear_r139 linear_b139 linear_g351 (by rfl) linear_kd135_3 linear_s139)
#print axioms HiaCoreSyntaxSlice.linear_sl135_3
theorem linear_pl135_3 (tail : List Nat) : parseFields 4065 27 (linear_v135_3 ++ (125 :: tail)) = some (linear_l135_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4064 27 linear_k135_3 linear_r139 linear_b139 linear_g351 tail (by rfl) (linear_kp135_3 (linear_b139 ++ (125 :: tail))) (linear_p139 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl135_3
noncomputable def linear_l135_2 : List (List Nat × Raw) := (linear_k135_2, linear_r138) :: linear_l135_3
noncomputable def linear_v135_2 : List Nat := (linear_g348 ++ linear_b138) ++ (44 :: linear_v135_3)
theorem linear_sl135_2 : serializeFields 4066 27 linear_l135_2 = some linear_v135_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4065 27 linear_k135_2 linear_r138 (linear_k135_3, linear_r139) [] linear_b138 linear_v135_3 linear_g348 (by rfl) linear_kd135_2 linear_s138 linear_sl135_3)
#print axioms HiaCoreSyntaxSlice.linear_sl135_2
theorem linear_pl135_2 (tail : List Nat) : parseFields 4066 27 (linear_v135_2 ++ (125 :: tail)) = some (linear_l135_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4065 27 linear_k135_2 linear_r138 linear_l135_3 linear_b138 linear_v135_3 linear_g348 tail (by rfl) (linear_kp135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail))))) (linear_p138 (44 :: (linear_v135_3 ++ (125 :: tail)))) (linear_pl135_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl135_2
noncomputable def linear_l135_1 : List (List Nat × Raw) := (linear_k135_1, linear_r137) :: linear_l135_2
noncomputable def linear_v135_1 : List Nat := (linear_g345 ++ linear_b137) ++ (44 :: linear_v135_2)
theorem linear_sl135_1 : serializeFields 4067 27 linear_l135_1 = some linear_v135_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4066 27 linear_k135_1 linear_r137 (linear_k135_2, linear_r138) linear_l135_3 linear_b137 linear_v135_2 linear_g345 (by rfl) linear_kd135_1 linear_s137 linear_sl135_2)
#print axioms HiaCoreSyntaxSlice.linear_sl135_1
theorem linear_pl135_1 (tail : List Nat) : parseFields 4067 27 (linear_v135_1 ++ (125 :: tail)) = some (linear_l135_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4066 27 linear_k135_1 linear_r137 linear_l135_2 linear_b137 linear_v135_2 linear_g345 tail (by rfl) (linear_kp135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail))))) (linear_p137 (44 :: (linear_v135_2 ++ (125 :: tail)))) (linear_pl135_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl135_1
noncomputable def linear_l135_0 : List (List Nat × Raw) := (linear_k135_0, linear_r136) :: linear_l135_1
noncomputable def linear_v135_0 : List Nat := (linear_g342 ++ linear_b136) ++ (44 :: linear_v135_1)
theorem linear_sl135_0 : serializeFields 4068 27 linear_l135_0 = some linear_v135_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4067 27 linear_k135_0 linear_r136 (linear_k135_1, linear_r137) linear_l135_2 linear_b136 linear_v135_1 linear_g342 (by rfl) linear_kd135_0 linear_s136 linear_sl135_1)
#print axioms HiaCoreSyntaxSlice.linear_sl135_0
theorem linear_pl135_0 (tail : List Nat) : parseFields 4068 27 (linear_v135_0 ++ (125 :: tail)) = some (linear_l135_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4067 27 linear_k135_0 linear_r136 linear_l135_1 linear_b136 linear_v135_1 linear_g342 tail (by rfl) (linear_kp135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail))))) (linear_p136 (44 :: (linear_v135_1 ++ (125 :: tail)))) (linear_pl135_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl135_0
noncomputable def linear_r135 : Raw := (.obj linear_l135_0)
noncomputable def linear_b135 : List Nat := linear_g341 ++ (linear_v135_0 ++ linear_g353)
theorem linear_o135 : orderedFields linear_l135_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o135
theorem linear_s135 : serializeRaw 4069 28 linear_r135 = some linear_b135 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4068 27 linear_l135_0 linear_v135_0 linear_o135 linear_sl135_0)
#print axioms HiaCoreSyntaxSlice.linear_s135
theorem linear_p135 (tail : List Nat) : parseRaw 4069 28 (linear_b135 ++ tail) = some (linear_r135, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4068 27 linear_l135_0 linear_v135_0 tail (by rfl) linear_o135 (linear_pl135_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p135
noncomputable def linear_r141 : Raw := (.str [100,103,95,103,117,97,114,100,95,48])
noncomputable def linear_b141 : List Nat := linear_g357
theorem linear_s141 : serializeRaw 4066 27 linear_r141 = some linear_b141 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s141
theorem linear_p141 (tail : List Nat) : parseRaw 4066 27 (linear_b141 ++ tail) = some (linear_r141, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p141
noncomputable def linear_r142 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,50]),(.str [100,103,95,118,95,49,54,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
noncomputable def linear_b142 : List Nat := linear_g360
theorem linear_s142 : serializeRaw 4065 27 linear_r142 = some linear_b142 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s142
theorem linear_p142 (tail : List Nat) : parseRaw 4065 27 (linear_b142 ++ tail) = some (linear_r142, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p142
noncomputable def linear_r143 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b143 : List Nat := linear_g363
theorem linear_s143 : serializeRaw 4064 27 linear_r143 = some linear_b143 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s143
theorem linear_p143 (tail : List Nat) : parseRaw 4064 27 (linear_b143 ++ tail) = some (linear_r143, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p143
noncomputable def linear_r144 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,54,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
noncomputable def linear_b144 : List Nat := linear_g366
theorem linear_s144 : serializeRaw 4063 27 linear_r144 = some linear_b144 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s144
theorem linear_p144 (tail : List Nat) : parseRaw 4063 27 (linear_b144 ++ tail) = some (linear_r144, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p144
noncomputable def linear_k140_0 : List Nat := [105,100]
theorem linear_kd140_0 : stringBytes linear_k140_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd140_0
theorem linear_kp140_0 (tail : List Nat) : parseStringTail (linear_k140_0 ++ (34 :: 58 :: tail)) [] = some (linear_k140_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp140_0
noncomputable def linear_k140_1 : List Nat := [111,112,115]
theorem linear_kd140_1 : stringBytes linear_k140_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd140_1
theorem linear_kp140_1 (tail : List Nat) : parseStringTail (linear_k140_1 ++ (34 :: 58 :: tail)) [] = some (linear_k140_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp140_1
noncomputable def linear_k140_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd140_2 : stringBytes linear_k140_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd140_2
theorem linear_kp140_2 (tail : List Nat) : parseStringTail (linear_k140_2 ++ (34 :: 58 :: tail)) [] = some (linear_k140_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp140_2
noncomputable def linear_k140_3 : List Nat := [116,101,114,109]
theorem linear_kd140_3 : stringBytes linear_k140_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd140_3
theorem linear_kp140_3 (tail : List Nat) : parseStringTail (linear_k140_3 ++ (34 :: 58 :: tail)) [] = some (linear_k140_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp140_3
noncomputable def linear_l140_3 : List (List Nat × Raw) := [(linear_k140_3, linear_r144)]
noncomputable def linear_v140_3 : List Nat := linear_g365 ++ linear_b144
theorem linear_sl140_3 : serializeFields 4064 27 linear_l140_3 = some linear_v140_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4063 27 linear_k140_3 linear_r144 linear_b144 linear_g365 (by rfl) linear_kd140_3 linear_s144)
#print axioms HiaCoreSyntaxSlice.linear_sl140_3
theorem linear_pl140_3 (tail : List Nat) : parseFields 4064 27 (linear_v140_3 ++ (125 :: tail)) = some (linear_l140_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4063 27 linear_k140_3 linear_r144 linear_b144 linear_g365 tail (by rfl) (linear_kp140_3 (linear_b144 ++ (125 :: tail))) (linear_p144 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl140_3
noncomputable def linear_l140_2 : List (List Nat × Raw) := (linear_k140_2, linear_r143) :: linear_l140_3
noncomputable def linear_v140_2 : List Nat := (linear_g362 ++ linear_b143) ++ (44 :: linear_v140_3)
theorem linear_sl140_2 : serializeFields 4065 27 linear_l140_2 = some linear_v140_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4064 27 linear_k140_2 linear_r143 (linear_k140_3, linear_r144) [] linear_b143 linear_v140_3 linear_g362 (by rfl) linear_kd140_2 linear_s143 linear_sl140_3)
#print axioms HiaCoreSyntaxSlice.linear_sl140_2
theorem linear_pl140_2 (tail : List Nat) : parseFields 4065 27 (linear_v140_2 ++ (125 :: tail)) = some (linear_l140_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4064 27 linear_k140_2 linear_r143 linear_l140_3 linear_b143 linear_v140_3 linear_g362 tail (by rfl) (linear_kp140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail))))) (linear_p143 (44 :: (linear_v140_3 ++ (125 :: tail)))) (linear_pl140_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl140_2
noncomputable def linear_l140_1 : List (List Nat × Raw) := (linear_k140_1, linear_r142) :: linear_l140_2
noncomputable def linear_v140_1 : List Nat := (linear_g359 ++ linear_b142) ++ (44 :: linear_v140_2)
theorem linear_sl140_1 : serializeFields 4066 27 linear_l140_1 = some linear_v140_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4065 27 linear_k140_1 linear_r142 (linear_k140_2, linear_r143) linear_l140_3 linear_b142 linear_v140_2 linear_g359 (by rfl) linear_kd140_1 linear_s142 linear_sl140_2)
#print axioms HiaCoreSyntaxSlice.linear_sl140_1
theorem linear_pl140_1 (tail : List Nat) : parseFields 4066 27 (linear_v140_1 ++ (125 :: tail)) = some (linear_l140_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4065 27 linear_k140_1 linear_r142 linear_l140_2 linear_b142 linear_v140_2 linear_g359 tail (by rfl) (linear_kp140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail))))) (linear_p142 (44 :: (linear_v140_2 ++ (125 :: tail)))) (linear_pl140_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl140_1
noncomputable def linear_l140_0 : List (List Nat × Raw) := (linear_k140_0, linear_r141) :: linear_l140_1
noncomputable def linear_v140_0 : List Nat := (linear_g356 ++ linear_b141) ++ (44 :: linear_v140_1)
theorem linear_sl140_0 : serializeFields 4067 27 linear_l140_0 = some linear_v140_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4066 27 linear_k140_0 linear_r141 (linear_k140_1, linear_r142) linear_l140_2 linear_b141 linear_v140_1 linear_g356 (by rfl) linear_kd140_0 linear_s141 linear_sl140_1)
#print axioms HiaCoreSyntaxSlice.linear_sl140_0
theorem linear_pl140_0 (tail : List Nat) : parseFields 4067 27 (linear_v140_0 ++ (125 :: tail)) = some (linear_l140_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4066 27 linear_k140_0 linear_r141 linear_l140_1 linear_b141 linear_v140_1 linear_g356 tail (by rfl) (linear_kp140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail))))) (linear_p141 (44 :: (linear_v140_1 ++ (125 :: tail)))) (linear_pl140_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl140_0
noncomputable def linear_r140 : Raw := (.obj linear_l140_0)
noncomputable def linear_b140 : List Nat := linear_g355 ++ (linear_v140_0 ++ linear_g367)
theorem linear_o140 : orderedFields linear_l140_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o140
end HiaCoreSyntaxSlice
