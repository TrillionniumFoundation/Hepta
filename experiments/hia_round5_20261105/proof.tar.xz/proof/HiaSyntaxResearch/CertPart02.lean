import HiaSyntaxResearch.CertPart01
namespace HiaCoreSyntaxSlice
theorem linear_s140 : serializeRaw 4068 28 linear_r140 = some linear_b140 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4067 27 linear_l140_0 linear_v140_0 linear_o140 linear_sl140_0)
#print axioms HiaCoreSyntaxSlice.linear_s140
theorem linear_p140 (tail : List Nat) : parseRaw 4068 28 (linear_b140 ++ tail) = some (linear_r140, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4067 27 linear_l140_0 linear_v140_0 tail (by rfl) linear_o140 (linear_pl140_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p140
noncomputable def linear_r146 : Raw := (.str [100,103,95,103,117,97,114,100,95,49])
noncomputable def linear_b146 : List Nat := linear_g371
theorem linear_s146 : serializeRaw 4065 27 linear_r146 = some linear_b146 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s146
theorem linear_p146 (tail : List Nat) : parseRaw 4065 27 (linear_b146 ++ tail) = some (linear_r146, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p146
noncomputable def linear_r147 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,55,49]),(.str [100,103,95,118,95,49,55,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,51])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
noncomputable def linear_b147 : List Nat := linear_g374
theorem linear_s147 : serializeRaw 4064 27 linear_r147 = some linear_b147 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s147
theorem linear_p147 (tail : List Nat) : parseRaw 4064 27 (linear_b147 ++ tail) = some (linear_r147, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p147
noncomputable def linear_r148 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
noncomputable def linear_b148 : List Nat := linear_g377
theorem linear_s148 : serializeRaw 4063 27 linear_r148 = some linear_b148 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s148
theorem linear_p148 (tail : List Nat) : parseRaw 4063 27 (linear_b148 ++ tail) = some (linear_r148, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p148
noncomputable def linear_r149 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,55,51])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
noncomputable def linear_b149 : List Nat := linear_g380
theorem linear_s149 : serializeRaw 4062 27 linear_r149 = some linear_b149 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s149
theorem linear_p149 (tail : List Nat) : parseRaw 4062 27 (linear_b149 ++ tail) = some (linear_r149, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p149
noncomputable def linear_k145_0 : List Nat := [105,100]
theorem linear_kd145_0 : stringBytes linear_k145_0 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_0)
#print axioms HiaCoreSyntaxSlice.linear_kd145_0
theorem linear_kp145_0 (tail : List Nat) : parseStringTail (linear_k145_0 ++ (34 :: 58 :: tail)) [] = some (linear_k145_0, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_0 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp145_0
noncomputable def linear_k145_1 : List Nat := [111,112,115]
theorem linear_kd145_1 : stringBytes linear_k145_1 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_1)
#print axioms HiaCoreSyntaxSlice.linear_kd145_1
theorem linear_kp145_1 (tail : List Nat) : parseStringTail (linear_k145_1 ++ (34 :: 58 :: tail)) [] = some (linear_k145_1, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_1 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp145_1
noncomputable def linear_k145_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd145_2 : stringBytes linear_k145_2 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd145_2
theorem linear_kp145_2 (tail : List Nat) : parseStringTail (linear_k145_2 ++ (34 :: 58 :: tail)) [] = some (linear_k145_2, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp145_2
noncomputable def linear_k145_3 : List Nat := [116,101,114,109]
theorem linear_kd145_3 : stringBytes linear_k145_3 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_3)
#print axioms HiaCoreSyntaxSlice.linear_kd145_3
theorem linear_kp145_3 (tail : List Nat) : parseStringTail (linear_k145_3 ++ (34 :: 58 :: tail)) [] = some (linear_k145_3, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_3 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp145_3
noncomputable def linear_l145_3 : List (List Nat × Raw) := [(linear_k145_3, linear_r149)]
noncomputable def linear_v145_3 : List Nat := linear_g379 ++ linear_b149
theorem linear_sl145_3 : serializeFields 4063 27 linear_l145_3 = some linear_v145_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4062 27 linear_k145_3 linear_r149 linear_b149 linear_g379 (by rfl) linear_kd145_3 linear_s149)
#print axioms HiaCoreSyntaxSlice.linear_sl145_3
theorem linear_pl145_3 (tail : List Nat) : parseFields 4063 27 (linear_v145_3 ++ (125 :: tail)) = some (linear_l145_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4062 27 linear_k145_3 linear_r149 linear_b149 linear_g379 tail (by rfl) (linear_kp145_3 (linear_b149 ++ (125 :: tail))) (linear_p149 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl145_3
noncomputable def linear_l145_2 : List (List Nat × Raw) := (linear_k145_2, linear_r148) :: linear_l145_3
noncomputable def linear_v145_2 : List Nat := (linear_g376 ++ linear_b148) ++ (44 :: linear_v145_3)
theorem linear_sl145_2 : serializeFields 4064 27 linear_l145_2 = some linear_v145_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4063 27 linear_k145_2 linear_r148 (linear_k145_3, linear_r149) [] linear_b148 linear_v145_3 linear_g376 (by rfl) linear_kd145_2 linear_s148 linear_sl145_3)
#print axioms HiaCoreSyntaxSlice.linear_sl145_2
theorem linear_pl145_2 (tail : List Nat) : parseFields 4064 27 (linear_v145_2 ++ (125 :: tail)) = some (linear_l145_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4063 27 linear_k145_2 linear_r148 linear_l145_3 linear_b148 linear_v145_3 linear_g376 tail (by rfl) (linear_kp145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail))))) (linear_p148 (44 :: (linear_v145_3 ++ (125 :: tail)))) (linear_pl145_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl145_2
noncomputable def linear_l145_1 : List (List Nat × Raw) := (linear_k145_1, linear_r147) :: linear_l145_2
noncomputable def linear_v145_1 : List Nat := (linear_g373 ++ linear_b147) ++ (44 :: linear_v145_2)
theorem linear_sl145_1 : serializeFields 4065 27 linear_l145_1 = some linear_v145_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4064 27 linear_k145_1 linear_r147 (linear_k145_2, linear_r148) linear_l145_3 linear_b147 linear_v145_2 linear_g373 (by rfl) linear_kd145_1 linear_s147 linear_sl145_2)
#print axioms HiaCoreSyntaxSlice.linear_sl145_1
theorem linear_pl145_1 (tail : List Nat) : parseFields 4065 27 (linear_v145_1 ++ (125 :: tail)) = some (linear_l145_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4064 27 linear_k145_1 linear_r147 linear_l145_2 linear_b147 linear_v145_2 linear_g373 tail (by rfl) (linear_kp145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail))))) (linear_p147 (44 :: (linear_v145_2 ++ (125 :: tail)))) (linear_pl145_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl145_1
noncomputable def linear_l145_0 : List (List Nat × Raw) := (linear_k145_0, linear_r146) :: linear_l145_1
noncomputable def linear_v145_0 : List Nat := (linear_g370 ++ linear_b146) ++ (44 :: linear_v145_1)
theorem linear_sl145_0 : serializeFields 4066 27 linear_l145_0 = some linear_v145_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4065 27 linear_k145_0 linear_r146 (linear_k145_1, linear_r147) linear_l145_2 linear_b146 linear_v145_1 linear_g370 (by rfl) linear_kd145_0 linear_s146 linear_sl145_1)
#print axioms HiaCoreSyntaxSlice.linear_sl145_0
theorem linear_pl145_0 (tail : List Nat) : parseFields 4066 27 (linear_v145_0 ++ (125 :: tail)) = some (linear_l145_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4065 27 linear_k145_0 linear_r146 linear_l145_1 linear_b146 linear_v145_1 linear_g370 tail (by rfl) (linear_kp145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail))))) (linear_p146 (44 :: (linear_v145_1 ++ (125 :: tail)))) (linear_pl145_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl145_0
noncomputable def linear_r145 : Raw := (.obj linear_l145_0)
noncomputable def linear_b145 : List Nat := linear_g369 ++ (linear_v145_0 ++ linear_g381)
theorem linear_o145 : orderedFields linear_l145_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o145
theorem linear_s145 : serializeRaw 4067 28 linear_r145 = some linear_b145 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4066 27 linear_l145_0 linear_v145_0 linear_o145 linear_sl145_0)
#print axioms HiaCoreSyntaxSlice.linear_s145
theorem linear_p145 (tail : List Nat) : parseRaw 4067 28 (linear_b145 ++ tail) = some (linear_r145, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4066 27 linear_l145_0 linear_v145_0 tail (by rfl) linear_o145 (linear_pl145_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p145
noncomputable def linear_l4_20 : List Raw := [linear_r145]
noncomputable def linear_v4_20 : List Nat := linear_b145
theorem linear_sl4_20 : serializeItems 4068 28 linear_l4_20 = some linear_v4_20 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_single 4067 28 linear_r145 linear_b145 linear_s145)
#print axioms HiaCoreSyntaxSlice.linear_sl4_20
theorem linear_pl4_20 (tail : List Nat) : parseItems 4068 28 (linear_v4_20 ++ (93 :: tail)) = some (linear_l4_20, tail) := by
  exact (HiaCoreSyntaxSlice.Structured.parse_items_last 4067 28 (linear_b145 ++ (93 :: tail)) tail linear_r145 (linear_p145 (93 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl4_20
noncomputable def linear_l4_19 : List Raw := linear_r140 :: linear_l4_20
noncomputable def linear_v4_19 : List Nat := (linear_b140) ++ (44 :: linear_v4_20)
theorem linear_sl4_19 : serializeItems 4069 28 linear_l4_19 = some linear_v4_19 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 28 linear_r140 linear_r145 [] linear_b140 linear_v4_20 linear_s140 linear_sl4_20)
#print axioms HiaCoreSyntaxSlice.linear_sl4_19
theorem linear_pl4_19 (tail : List Nat) : parseItems 4069 28 (linear_v4_19 ++ (93 :: tail)) = some (linear_l4_19, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4068 28 linear_r140 linear_l4_20 linear_b140 linear_v4_20 tail (linear_p140 (44 :: (linear_v4_20 ++ (93 :: tail)))) (linear_pl4_20 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_19
noncomputable def linear_l4_18 : List Raw := linear_r135 :: linear_l4_19
noncomputable def linear_v4_18 : List Nat := (linear_b135) ++ (44 :: linear_v4_19)
theorem linear_sl4_18 : serializeItems 4070 28 linear_l4_18 = some linear_v4_18 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 28 linear_r135 linear_r140 linear_l4_20 linear_b135 linear_v4_19 linear_s135 linear_sl4_19)
#print axioms HiaCoreSyntaxSlice.linear_sl4_18
theorem linear_pl4_18 (tail : List Nat) : parseItems 4070 28 (linear_v4_18 ++ (93 :: tail)) = some (linear_l4_18, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4069 28 linear_r135 linear_l4_19 linear_b135 linear_v4_19 tail (linear_p135 (44 :: (linear_v4_19 ++ (93 :: tail)))) (linear_pl4_19 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_18
noncomputable def linear_l4_17 : List Raw := linear_r123 :: linear_l4_18
noncomputable def linear_v4_17 : List Nat := (linear_b123) ++ (44 :: linear_v4_18)
theorem linear_sl4_17 : serializeItems 4071 28 linear_l4_17 = some linear_v4_17 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 28 linear_r123 linear_r135 linear_l4_19 linear_b123 linear_v4_18 linear_s123 linear_sl4_18)
#print axioms HiaCoreSyntaxSlice.linear_sl4_17
theorem linear_pl4_17 (tail : List Nat) : parseItems 4071 28 (linear_v4_17 ++ (93 :: tail)) = some (linear_l4_17, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4070 28 linear_r123 linear_l4_18 linear_b123 linear_v4_18 tail (linear_p123 (44 :: (linear_v4_18 ++ (93 :: tail)))) (linear_pl4_18 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_17
noncomputable def linear_l4_16 : List Raw := linear_r118 :: linear_l4_17
noncomputable def linear_v4_16 : List Nat := (linear_b118) ++ (44 :: linear_v4_17)
theorem linear_sl4_16 : serializeItems 4072 28 linear_l4_16 = some linear_v4_16 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 28 linear_r118 linear_r123 linear_l4_18 linear_b118 linear_v4_17 linear_s118 linear_sl4_17)
#print axioms HiaCoreSyntaxSlice.linear_sl4_16
theorem linear_pl4_16 (tail : List Nat) : parseItems 4072 28 (linear_v4_16 ++ (93 :: tail)) = some (linear_l4_16, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4071 28 linear_r118 linear_l4_17 linear_b118 linear_v4_17 tail (linear_p118 (44 :: (linear_v4_17 ++ (93 :: tail)))) (linear_pl4_17 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_16
noncomputable def linear_l4_15 : List Raw := linear_r113 :: linear_l4_16
noncomputable def linear_v4_15 : List Nat := (linear_b113) ++ (44 :: linear_v4_16)
theorem linear_sl4_15 : serializeItems 4073 28 linear_l4_15 = some linear_v4_15 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 28 linear_r113 linear_r118 linear_l4_17 linear_b113 linear_v4_16 linear_s113 linear_sl4_16)
#print axioms HiaCoreSyntaxSlice.linear_sl4_15
theorem linear_pl4_15 (tail : List Nat) : parseItems 4073 28 (linear_v4_15 ++ (93 :: tail)) = some (linear_l4_15, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4072 28 linear_r113 linear_l4_16 linear_b113 linear_v4_16 tail (linear_p113 (44 :: (linear_v4_16 ++ (93 :: tail)))) (linear_pl4_16 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_15
noncomputable def linear_l4_14 : List Raw := linear_r97 :: linear_l4_15
noncomputable def linear_v4_14 : List Nat := (linear_b97) ++ (44 :: linear_v4_15)
theorem linear_sl4_14 : serializeItems 4074 28 linear_l4_14 = some linear_v4_14 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 28 linear_r97 linear_r113 linear_l4_16 linear_b97 linear_v4_15 linear_s97 linear_sl4_15)
#print axioms HiaCoreSyntaxSlice.linear_sl4_14
theorem linear_pl4_14 (tail : List Nat) : parseItems 4074 28 (linear_v4_14 ++ (93 :: tail)) = some (linear_l4_14, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4073 28 linear_r97 linear_l4_15 linear_b97 linear_v4_15 tail (linear_p97 (44 :: (linear_v4_15 ++ (93 :: tail)))) (linear_pl4_15 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_14
noncomputable def linear_l4_13 : List Raw := linear_r92 :: linear_l4_14
noncomputable def linear_v4_13 : List Nat := (linear_b92) ++ (44 :: linear_v4_14)
theorem linear_sl4_13 : serializeItems 4075 28 linear_l4_13 = some linear_v4_13 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 28 linear_r92 linear_r97 linear_l4_15 linear_b92 linear_v4_14 linear_s92 linear_sl4_14)
#print axioms HiaCoreSyntaxSlice.linear_sl4_13
theorem linear_pl4_13 (tail : List Nat) : parseItems 4075 28 (linear_v4_13 ++ (93 :: tail)) = some (linear_l4_13, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4074 28 linear_r92 linear_l4_14 linear_b92 linear_v4_14 tail (linear_p92 (44 :: (linear_v4_14 ++ (93 :: tail)))) (linear_pl4_14 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_13
noncomputable def linear_l4_12 : List Raw := linear_r87 :: linear_l4_13
noncomputable def linear_v4_12 : List Nat := (linear_b87) ++ (44 :: linear_v4_13)
theorem linear_sl4_12 : serializeItems 4076 28 linear_l4_12 = some linear_v4_12 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4075 28 linear_r87 linear_r92 linear_l4_14 linear_b87 linear_v4_13 linear_s87 linear_sl4_13)
#print axioms HiaCoreSyntaxSlice.linear_sl4_12
theorem linear_pl4_12 (tail : List Nat) : parseItems 4076 28 (linear_v4_12 ++ (93 :: tail)) = some (linear_l4_12, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4075 28 linear_r87 linear_l4_13 linear_b87 linear_v4_13 tail (linear_p87 (44 :: (linear_v4_13 ++ (93 :: tail)))) (linear_pl4_13 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_12
noncomputable def linear_l4_11 : List Raw := linear_r75 :: linear_l4_12
noncomputable def linear_v4_11 : List Nat := (linear_b75) ++ (44 :: linear_v4_12)
theorem linear_sl4_11 : serializeItems 4077 28 linear_l4_11 = some linear_v4_11 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4076 28 linear_r75 linear_r87 linear_l4_13 linear_b75 linear_v4_12 linear_s75 linear_sl4_12)
#print axioms HiaCoreSyntaxSlice.linear_sl4_11
theorem linear_pl4_11 (tail : List Nat) : parseItems 4077 28 (linear_v4_11 ++ (93 :: tail)) = some (linear_l4_11, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4076 28 linear_r75 linear_l4_12 linear_b75 linear_v4_12 tail (linear_p75 (44 :: (linear_v4_12 ++ (93 :: tail)))) (linear_pl4_12 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_11
noncomputable def linear_l4_10 : List Raw := linear_r70 :: linear_l4_11
noncomputable def linear_v4_10 : List Nat := (linear_b70) ++ (44 :: linear_v4_11)
theorem linear_sl4_10 : serializeItems 4078 28 linear_l4_10 = some linear_v4_10 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4077 28 linear_r70 linear_r75 linear_l4_12 linear_b70 linear_v4_11 linear_s70 linear_sl4_11)
#print axioms HiaCoreSyntaxSlice.linear_sl4_10
theorem linear_pl4_10 (tail : List Nat) : parseItems 4078 28 (linear_v4_10 ++ (93 :: tail)) = some (linear_l4_10, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4077 28 linear_r70 linear_l4_11 linear_b70 linear_v4_11 tail (linear_p70 (44 :: (linear_v4_11 ++ (93 :: tail)))) (linear_pl4_11 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_10
noncomputable def linear_l4_9 : List Raw := linear_r65 :: linear_l4_10
noncomputable def linear_v4_9 : List Nat := (linear_b65) ++ (44 :: linear_v4_10)
theorem linear_sl4_9 : serializeItems 4079 28 linear_l4_9 = some linear_v4_9 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 28 linear_r65 linear_r70 linear_l4_11 linear_b65 linear_v4_10 linear_s65 linear_sl4_10)
#print axioms HiaCoreSyntaxSlice.linear_sl4_9
theorem linear_pl4_9 (tail : List Nat) : parseItems 4079 28 (linear_v4_9 ++ (93 :: tail)) = some (linear_l4_9, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4078 28 linear_r65 linear_l4_10 linear_b65 linear_v4_10 tail (linear_p65 (44 :: (linear_v4_10 ++ (93 :: tail)))) (linear_pl4_10 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_9
noncomputable def linear_l4_8 : List Raw := linear_r49 :: linear_l4_9
noncomputable def linear_v4_8 : List Nat := (linear_b49) ++ (44 :: linear_v4_9)
theorem linear_sl4_8 : serializeItems 4080 28 linear_l4_8 = some linear_v4_8 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 28 linear_r49 linear_r65 linear_l4_10 linear_b49 linear_v4_9 linear_s49 linear_sl4_9)
#print axioms HiaCoreSyntaxSlice.linear_sl4_8
theorem linear_pl4_8 (tail : List Nat) : parseItems 4080 28 (linear_v4_8 ++ (93 :: tail)) = some (linear_l4_8, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4079 28 linear_r49 linear_l4_9 linear_b49 linear_v4_9 tail (linear_p49 (44 :: (linear_v4_9 ++ (93 :: tail)))) (linear_pl4_9 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_8
noncomputable def linear_l4_7 : List Raw := linear_r44 :: linear_l4_8
noncomputable def linear_v4_7 : List Nat := (linear_b44) ++ (44 :: linear_v4_8)
theorem linear_sl4_7 : serializeItems 4081 28 linear_l4_7 = some linear_v4_7 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 28 linear_r44 linear_r49 linear_l4_9 linear_b44 linear_v4_8 linear_s44 linear_sl4_8)
#print axioms HiaCoreSyntaxSlice.linear_sl4_7
theorem linear_pl4_7 (tail : List Nat) : parseItems 4081 28 (linear_v4_7 ++ (93 :: tail)) = some (linear_l4_7, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4080 28 linear_r44 linear_l4_8 linear_b44 linear_v4_8 tail (linear_p44 (44 :: (linear_v4_8 ++ (93 :: tail)))) (linear_pl4_8 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_7
noncomputable def linear_l4_6 : List Raw := linear_r39 :: linear_l4_7
noncomputable def linear_v4_6 : List Nat := (linear_b39) ++ (44 :: linear_v4_7)
theorem linear_sl4_6 : serializeItems 4082 28 linear_l4_6 = some linear_v4_6 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4081 28 linear_r39 linear_r44 linear_l4_8 linear_b39 linear_v4_7 linear_s39 linear_sl4_7)
#print axioms HiaCoreSyntaxSlice.linear_sl4_6
theorem linear_pl4_6 (tail : List Nat) : parseItems 4082 28 (linear_v4_6 ++ (93 :: tail)) = some (linear_l4_6, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4081 28 linear_r39 linear_l4_7 linear_b39 linear_v4_7 tail (linear_p39 (44 :: (linear_v4_7 ++ (93 :: tail)))) (linear_pl4_7 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_6
noncomputable def linear_l4_5 : List Raw := linear_r34 :: linear_l4_6
noncomputable def linear_v4_5 : List Nat := (linear_b34) ++ (44 :: linear_v4_6)
theorem linear_sl4_5 : serializeItems 4083 28 linear_l4_5 = some linear_v4_5 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4082 28 linear_r34 linear_r39 linear_l4_7 linear_b34 linear_v4_6 linear_s34 linear_sl4_6)
#print axioms HiaCoreSyntaxSlice.linear_sl4_5
theorem linear_pl4_5 (tail : List Nat) : parseItems 4083 28 (linear_v4_5 ++ (93 :: tail)) = some (linear_l4_5, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4082 28 linear_r34 linear_l4_6 linear_b34 linear_v4_6 tail (linear_p34 (44 :: (linear_v4_6 ++ (93 :: tail)))) (linear_pl4_6 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_5
noncomputable def linear_l4_4 : List Raw := linear_r29 :: linear_l4_5
noncomputable def linear_v4_4 : List Nat := (linear_b29) ++ (44 :: linear_v4_5)
theorem linear_sl4_4 : serializeItems 4084 28 linear_l4_4 = some linear_v4_4 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4083 28 linear_r29 linear_r34 linear_l4_6 linear_b29 linear_v4_5 linear_s29 linear_sl4_5)
#print axioms HiaCoreSyntaxSlice.linear_sl4_4
theorem linear_pl4_4 (tail : List Nat) : parseItems 4084 28 (linear_v4_4 ++ (93 :: tail)) = some (linear_l4_4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4083 28 linear_r29 linear_l4_5 linear_b29 linear_v4_5 tail (linear_p29 (44 :: (linear_v4_5 ++ (93 :: tail)))) (linear_pl4_5 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_4
noncomputable def linear_l4_3 : List Raw := linear_r24 :: linear_l4_4
noncomputable def linear_v4_3 : List Nat := (linear_b24) ++ (44 :: linear_v4_4)
theorem linear_sl4_3 : serializeItems 4085 28 linear_l4_3 = some linear_v4_3 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4084 28 linear_r24 linear_r29 linear_l4_5 linear_b24 linear_v4_4 linear_s24 linear_sl4_4)
#print axioms HiaCoreSyntaxSlice.linear_sl4_3
theorem linear_pl4_3 (tail : List Nat) : parseItems 4085 28 (linear_v4_3 ++ (93 :: tail)) = some (linear_l4_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4084 28 linear_r24 linear_l4_4 linear_b24 linear_v4_4 tail (linear_p24 (44 :: (linear_v4_4 ++ (93 :: tail)))) (linear_pl4_4 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_3
noncomputable def linear_l4_2 : List Raw := linear_r15 :: linear_l4_3
noncomputable def linear_v4_2 : List Nat := (linear_b15) ++ (44 :: linear_v4_3)
theorem linear_sl4_2 : serializeItems 4086 28 linear_l4_2 = some linear_v4_2 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4085 28 linear_r15 linear_r24 linear_l4_4 linear_b15 linear_v4_3 linear_s15 linear_sl4_3)
#print axioms HiaCoreSyntaxSlice.linear_sl4_2
theorem linear_pl4_2 (tail : List Nat) : parseItems 4086 28 (linear_v4_2 ++ (93 :: tail)) = some (linear_l4_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4085 28 linear_r15 linear_l4_3 linear_b15 linear_v4_3 tail (linear_p15 (44 :: (linear_v4_3 ++ (93 :: tail)))) (linear_pl4_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_2
noncomputable def linear_l4_1 : List Raw := linear_r10 :: linear_l4_2
noncomputable def linear_v4_1 : List Nat := (linear_b10) ++ (44 :: linear_v4_2)
theorem linear_sl4_1 : serializeItems 4087 28 linear_l4_1 = some linear_v4_1 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4086 28 linear_r10 linear_r15 linear_l4_3 linear_b10 linear_v4_2 linear_s10 linear_sl4_2)
#print axioms HiaCoreSyntaxSlice.linear_sl4_1
theorem linear_pl4_1 (tail : List Nat) : parseItems 4087 28 (linear_v4_1 ++ (93 :: tail)) = some (linear_l4_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4086 28 linear_r10 linear_l4_2 linear_b10 linear_v4_2 tail (linear_p10 (44 :: (linear_v4_2 ++ (93 :: tail)))) (linear_pl4_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_1
noncomputable def linear_l4_0 : List Raw := linear_r5 :: linear_l4_1
noncomputable def linear_v4_0 : List Nat := (linear_b5) ++ (44 :: linear_v4_1)
theorem linear_sl4_0 : serializeItems 4088 28 linear_l4_0 = some linear_v4_0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4087 28 linear_r5 linear_r10 linear_l4_2 linear_b5 linear_v4_1 linear_s5 linear_sl4_1)
#print axioms HiaCoreSyntaxSlice.linear_sl4_0
theorem linear_pl4_0 (tail : List Nat) : parseItems 4088 28 (linear_v4_0 ++ (93 :: tail)) = some (linear_l4_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes 4087 28 linear_r5 linear_l4_1 linear_b5 linear_v4_1 tail (linear_p5 (44 :: (linear_v4_1 ++ (93 :: tail)))) (linear_pl4_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl4_0
noncomputable def linear_r4 : Raw := (.arr linear_l4_0)
noncomputable def linear_b4 : List Nat := linear_g8 ++ (linear_v4_0 ++ linear_g382)
theorem linear_s4 : serializeRaw 4089 29 linear_r4 = some linear_b4 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_array 4088 28 linear_l4_0 linear_v4_0 linear_sl4_0)
#print axioms HiaCoreSyntaxSlice.linear_s4
theorem linear_p4 (tail : List Nat) : parseRaw 4089 29 (linear_b4 ++ tail) = some (linear_r4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_array_bytes 4088 28 linear_l4_0 linear_v4_0 tail (by intro h; cases h) (linear_pl4_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p4
noncomputable def linear_r150 : Raw := (.arr [(.str [97,108,108,111,99]),(.str [114,101,97,100]),(.str [116,114,97,112]),(.str [119,114,105,116,101])])
noncomputable def linear_b150 : List Nat := linear_g385
theorem linear_s150 : serializeRaw 4088 29 linear_r150 = some linear_b150 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s150
theorem linear_p150 (tail : List Nat) : parseRaw 4088 29 (linear_b150 ++ tail) = some (linear_r150, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p150
noncomputable def linear_r151 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
noncomputable def linear_b151 : List Nat := linear_g388
theorem linear_s151 : serializeRaw 4087 29 linear_r151 = some linear_b151 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_string_rebase 4084 26 4086 28 [100,103,95,115,104,97,114,101,100,95,48] linear_b151 HiaCoreSyntaxSlice.linear_s6)
#print axioms HiaCoreSyntaxSlice.linear_s151
theorem linear_p151 (tail : List Nat) : parseRaw 4087 29 (linear_b151 ++ tail) = some (linear_r151, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_string_rebase_bound 4084 26 4086 28 HiaCoreSyntaxSlice.linear_r6 linear_r151 HiaCoreSyntaxSlice.linear_b6 linear_b151 ([100,103,95,115,104,97,114,101,100,95,48] ++ [34]) (by rfl) (by rfl) (by rfl) HiaCoreSyntaxSlice.linear_p6 tail)
#print axioms HiaCoreSyntaxSlice.linear_p151
noncomputable def linear_r152 : Raw := (.str [99,97,108,99,117,108,97,116,101])
noncomputable def linear_b152 : List Nat := linear_g391
theorem linear_s152 : serializeRaw 4086 29 linear_r152 = some linear_b152 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s152
theorem linear_p152 (tail : List Nat) : parseRaw 4086 29 (linear_b152 ++ tail) = some (linear_r152, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p152
noncomputable def linear_r153 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
noncomputable def linear_b153 : List Nat := linear_g394
theorem linear_s153 : serializeRaw 4085 29 linear_r153 = some linear_b153 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s153
theorem linear_p153 (tail : List Nat) : parseRaw 4085 29 (linear_b153 ++ tail) = some (linear_r153, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p153
noncomputable def linear_r154 : Raw := (.arr [(.str [117,54,52])])
noncomputable def linear_b154 : List Nat := linear_g397
theorem linear_s154 : serializeRaw 4084 29 linear_r154 = some linear_b154 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s154
theorem linear_p154 (tail : List Nat) : parseRaw 4084 29 (linear_b154 ++ tail) = some (linear_r154, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p154
noncomputable def linear_k3_0 : List Nat := [98,108,111,99,107,115]
theorem linear_kd3_0 : stringBytes linear_k3_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd3_0
theorem linear_kp3_0 (tail : List Nat) : parseStringTail (linear_k3_0 ++ (34 :: 58 :: tail)) [] = some (linear_k3_0, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp3_0
noncomputable def linear_k3_1 : List Nat := [101,102,102,101,99,116,115]
theorem linear_kd3_1 : stringBytes linear_k3_1 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd3_1
theorem linear_kp3_1 (tail : List Nat) : parseStringTail (linear_k3_1 ++ (34 :: 58 :: tail)) [] = some (linear_k3_1, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp3_1
noncomputable def linear_k3_2 : List Nat := [101,110,116,114,121]
theorem linear_kd3_2 : stringBytes linear_k3_2 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd3_2
theorem linear_kp3_2 (tail : List Nat) : parseStringTail (linear_k3_2 ++ (34 :: 58 :: tail)) [] = some (linear_k3_2, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp3_2
noncomputable def linear_k3_3 : List Nat := [110,97,109,101]
theorem linear_kd3_3 : stringBytes linear_k3_3 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd3_3
theorem linear_kp3_3 (tail : List Nat) : parseStringTail (linear_k3_3 ++ (34 :: 58 :: tail)) [] = some (linear_k3_3, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp3_3
noncomputable def linear_k3_4 : List Nat := [112,97,114,97,109,115]
theorem linear_kd3_4 : stringBytes linear_k3_4 = true := by
  exact (HiaCoreSyntaxSlice.linear_kd5_2)
#print axioms HiaCoreSyntaxSlice.linear_kd3_4
theorem linear_kp3_4 (tail : List Nat) : parseStringTail (linear_k3_4 ++ (34 :: 58 :: tail)) [] = some (linear_k3_4, 58 :: tail) := by
  exact (HiaCoreSyntaxSlice.linear_kp5_2 tail)
#print axioms HiaCoreSyntaxSlice.linear_kp3_4
noncomputable def linear_k3_5 : List Nat := [114,101,116,117,114,110,115]
theorem linear_kd3_5 : stringBytes linear_k3_5 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd3_5
theorem linear_kp3_5 (tail : List Nat) : parseStringTail (linear_k3_5 ++ (34 :: 58 :: tail)) [] = some (linear_k3_5, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp3_5
noncomputable def linear_l3_5 : List (List Nat × Raw) := [(linear_k3_5, linear_r154)]
noncomputable def linear_v3_5 : List Nat := linear_g396 ++ linear_b154
theorem linear_sl3_5 : serializeFields 4085 29 linear_l3_5 = some linear_v3_5 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4084 29 linear_k3_5 linear_r154 linear_b154 linear_g396 (by rfl) linear_kd3_5 linear_s154)
#print axioms HiaCoreSyntaxSlice.linear_sl3_5
theorem linear_pl3_5 (tail : List Nat) : parseFields 4085 29 (linear_v3_5 ++ (125 :: tail)) = some (linear_l3_5, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4084 29 linear_k3_5 linear_r154 linear_b154 linear_g396 tail (by rfl) (linear_kp3_5 (linear_b154 ++ (125 :: tail))) (linear_p154 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl3_5
noncomputable def linear_l3_4 : List (List Nat × Raw) := (linear_k3_4, linear_r153) :: linear_l3_5
noncomputable def linear_v3_4 : List Nat := (linear_g393 ++ linear_b153) ++ (44 :: linear_v3_5)
theorem linear_sl3_4 : serializeFields 4086 29 linear_l3_4 = some linear_v3_4 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4085 29 linear_k3_4 linear_r153 (linear_k3_5, linear_r154) [] linear_b153 linear_v3_5 linear_g393 (by rfl) linear_kd3_4 linear_s153 linear_sl3_5)
#print axioms HiaCoreSyntaxSlice.linear_sl3_4
theorem linear_pl3_4 (tail : List Nat) : parseFields 4086 29 (linear_v3_4 ++ (125 :: tail)) = some (linear_l3_4, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4085 29 linear_k3_4 linear_r153 linear_l3_5 linear_b153 linear_v3_5 linear_g393 tail (by rfl) (linear_kp3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail))))) (linear_p153 (44 :: (linear_v3_5 ++ (125 :: tail)))) (linear_pl3_5 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl3_4
noncomputable def linear_l3_3 : List (List Nat × Raw) := (linear_k3_3, linear_r152) :: linear_l3_4
noncomputable def linear_v3_3 : List Nat := (linear_g390 ++ linear_b152) ++ (44 :: linear_v3_4)
theorem linear_sl3_3 : serializeFields 4087 29 linear_l3_3 = some linear_v3_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4086 29 linear_k3_3 linear_r152 (linear_k3_4, linear_r153) linear_l3_5 linear_b152 linear_v3_4 linear_g390 (by rfl) linear_kd3_3 linear_s152 linear_sl3_4)
#print axioms HiaCoreSyntaxSlice.linear_sl3_3
theorem linear_pl3_3 (tail : List Nat) : parseFields 4087 29 (linear_v3_3 ++ (125 :: tail)) = some (linear_l3_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4086 29 linear_k3_3 linear_r152 linear_l3_4 linear_b152 linear_v3_4 linear_g390 tail (by rfl) (linear_kp3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail))))) (linear_p152 (44 :: (linear_v3_4 ++ (125 :: tail)))) (linear_pl3_4 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl3_3
noncomputable def linear_l3_2 : List (List Nat × Raw) := (linear_k3_2, linear_r151) :: linear_l3_3
noncomputable def linear_v3_2 : List Nat := (linear_g387 ++ linear_b151) ++ (44 :: linear_v3_3)
theorem linear_sl3_2 : serializeFields 4088 29 linear_l3_2 = some linear_v3_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4087 29 linear_k3_2 linear_r151 (linear_k3_3, linear_r152) linear_l3_4 linear_b151 linear_v3_3 linear_g387 (by rfl) linear_kd3_2 linear_s151 linear_sl3_3)
#print axioms HiaCoreSyntaxSlice.linear_sl3_2
theorem linear_pl3_2 (tail : List Nat) : parseFields 4088 29 (linear_v3_2 ++ (125 :: tail)) = some (linear_l3_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4087 29 linear_k3_2 linear_r151 linear_l3_3 linear_b151 linear_v3_3 linear_g387 tail (by rfl) (linear_kp3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail))))) (linear_p151 (44 :: (linear_v3_3 ++ (125 :: tail)))) (linear_pl3_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl3_2
noncomputable def linear_l3_1 : List (List Nat × Raw) := (linear_k3_1, linear_r150) :: linear_l3_2
noncomputable def linear_v3_1 : List Nat := (linear_g384 ++ linear_b150) ++ (44 :: linear_v3_2)
theorem linear_sl3_1 : serializeFields 4089 29 linear_l3_1 = some linear_v3_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4088 29 linear_k3_1 linear_r150 (linear_k3_2, linear_r151) linear_l3_3 linear_b150 linear_v3_2 linear_g384 (by rfl) linear_kd3_1 linear_s150 linear_sl3_2)
#print axioms HiaCoreSyntaxSlice.linear_sl3_1
theorem linear_pl3_1 (tail : List Nat) : parseFields 4089 29 (linear_v3_1 ++ (125 :: tail)) = some (linear_l3_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4088 29 linear_k3_1 linear_r150 linear_l3_2 linear_b150 linear_v3_2 linear_g384 tail (by rfl) (linear_kp3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail))))) (linear_p150 (44 :: (linear_v3_2 ++ (125 :: tail)))) (linear_pl3_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl3_1
noncomputable def linear_l3_0 : List (List Nat × Raw) := (linear_k3_0, linear_r4) :: linear_l3_1
noncomputable def linear_v3_0 : List Nat := (linear_g7 ++ linear_b4) ++ (44 :: linear_v3_1)
theorem linear_sl3_0 : serializeFields 4090 29 linear_l3_0 = some linear_v3_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4089 29 linear_k3_0 linear_r4 (linear_k3_1, linear_r150) linear_l3_2 linear_b4 linear_v3_1 linear_g7 (by rfl) linear_kd3_0 linear_s4 linear_sl3_1)
#print axioms HiaCoreSyntaxSlice.linear_sl3_0
theorem linear_pl3_0 (tail : List Nat) : parseFields 4090 29 (linear_v3_0 ++ (125 :: tail)) = some (linear_l3_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4089 29 linear_k3_0 linear_r4 linear_l3_1 linear_b4 linear_v3_1 linear_g7 tail (by rfl) (linear_kp3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail))))) (linear_p4 (44 :: (linear_v3_1 ++ (125 :: tail)))) (linear_pl3_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl3_0
noncomputable def linear_r3 : Raw := (.obj linear_l3_0)
noncomputable def linear_b3 : List Nat := linear_g6 ++ (linear_v3_0 ++ linear_g398)
theorem linear_o3 : orderedFields linear_l3_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o3
theorem linear_s3 : serializeRaw 4091 30 linear_r3 = some linear_b3 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4090 29 linear_l3_0 linear_v3_0 linear_o3 linear_sl3_0)
#print axioms HiaCoreSyntaxSlice.linear_s3
theorem linear_p3 (tail : List Nat) : parseRaw 4091 30 (linear_b3 ++ tail) = some (linear_r3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4090 29 linear_l3_0 linear_v3_0 tail (by rfl) linear_o3 (linear_pl3_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p3
noncomputable def linear_l2_0 : List Raw := [linear_r3]
noncomputable def linear_v2_0 : List Nat := linear_b3
theorem linear_sl2_0 : serializeItems 4092 30 linear_l2_0 = some linear_v2_0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_items_single 4091 30 linear_r3 linear_b3 linear_s3)
#print axioms HiaCoreSyntaxSlice.linear_sl2_0
theorem linear_pl2_0 (tail : List Nat) : parseItems 4092 30 (linear_v2_0 ++ (93 :: tail)) = some (linear_l2_0, tail) := by
  exact (HiaCoreSyntaxSlice.Structured.parse_items_last 4091 30 (linear_b3 ++ (93 :: tail)) tail linear_r3 (linear_p3 (93 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl2_0
noncomputable def linear_r2 : Raw := (.arr linear_l2_0)
noncomputable def linear_b2 : List Nat := linear_g5 ++ (linear_v2_0 ++ linear_g399)
theorem linear_s2 : serializeRaw 4093 31 linear_r2 = some linear_b2 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_array 4092 30 linear_l2_0 linear_v2_0 linear_sl2_0)
#print axioms HiaCoreSyntaxSlice.linear_s2
theorem linear_p2 (tail : List Nat) : parseRaw 4093 31 (linear_b2 ++ tail) = some (linear_r2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_array_bytes 4092 30 linear_l2_0 linear_v2_0 tail (by intro h; cases h) (linear_pl2_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p2
noncomputable def linear_r155 : Raw := (.str [114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114])
noncomputable def linear_b155 : List Nat := linear_g402
theorem linear_s155 : serializeRaw 4092 31 linear_r155 = some linear_b155 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s155
theorem linear_p155 (tail : List Nat) : parseRaw 4092 31 (linear_b155 ++ tail) = some (linear_r155, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p155
noncomputable def linear_r156 : Raw := (.str [104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49])
noncomputable def linear_b156 : List Nat := linear_g405
theorem linear_s156 : serializeRaw 4091 31 linear_r156 = some linear_b156 := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_s156
theorem linear_p156 (tail : List Nat) : parseRaw 4091 31 (linear_b156 ++ tail) = some (linear_r156, tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_p156
noncomputable def linear_k0_0 : List Nat := [101,120,112,111,114,116,115]
theorem linear_kd0_0 : stringBytes linear_k0_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd0_0
theorem linear_kp0_0 (tail : List Nat) : parseStringTail (linear_k0_0 ++ (34 :: 58 :: tail)) [] = some (linear_k0_0, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp0_0
noncomputable def linear_k0_1 : List Nat := [102,117,110,99,116,105,111,110,115]
theorem linear_kd0_1 : stringBytes linear_k0_1 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd0_1
theorem linear_kp0_1 (tail : List Nat) : parseStringTail (linear_k0_1 ++ (34 :: 58 :: tail)) [] = some (linear_k0_1, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp0_1
noncomputable def linear_k0_2 : List Nat := [109,111,100,117,108,101]
theorem linear_kd0_2 : stringBytes linear_k0_2 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd0_2
theorem linear_kp0_2 (tail : List Nat) : parseStringTail (linear_k0_2 ++ (34 :: 58 :: tail)) [] = some (linear_k0_2, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp0_2
noncomputable def linear_k0_3 : List Nat := [115,99,104,101,109,97]
theorem linear_kd0_3 : stringBytes linear_k0_3 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_kd0_3
theorem linear_kp0_3 (tail : List Nat) : parseStringTail (linear_k0_3 ++ (34 :: 58 :: tail)) [] = some (linear_k0_3, 58 :: tail) := by rfl
#print axioms HiaCoreSyntaxSlice.linear_kp0_3
noncomputable def linear_l0_3 : List (List Nat × Raw) := [(linear_k0_3, linear_r156)]
noncomputable def linear_v0_3 : List Nat := linear_g404 ++ linear_b156
theorem linear_sl0_3 : serializeFields 4092 31 linear_l0_3 = some linear_v0_3 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet 4091 31 linear_k0_3 linear_r156 linear_b156 linear_g404 (by rfl) linear_kd0_3 linear_s156)
#print axioms HiaCoreSyntaxSlice.linear_sl0_3
theorem linear_pl0_3 (tail : List Nat) : parseFields 4092 31 (linear_v0_3 ++ (125 :: tail)) = some (linear_l0_3, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_last_packet 4091 31 linear_k0_3 linear_r156 linear_b156 linear_g404 tail (by rfl) (linear_kp0_3 (linear_b156 ++ (125 :: tail))) (linear_p156 (125 :: tail)))
#print axioms HiaCoreSyntaxSlice.linear_pl0_3
noncomputable def linear_l0_2 : List (List Nat × Raw) := (linear_k0_2, linear_r155) :: linear_l0_3
noncomputable def linear_v0_2 : List Nat := (linear_g401 ++ linear_b155) ++ (44 :: linear_v0_3)
theorem linear_sl0_2 : serializeFields 4093 31 linear_l0_2 = some linear_v0_2 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4092 31 linear_k0_2 linear_r155 (linear_k0_3, linear_r156) [] linear_b155 linear_v0_3 linear_g401 (by rfl) linear_kd0_2 linear_s155 linear_sl0_3)
#print axioms HiaCoreSyntaxSlice.linear_sl0_2
theorem linear_pl0_2 (tail : List Nat) : parseFields 4093 31 (linear_v0_2 ++ (125 :: tail)) = some (linear_l0_2, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4092 31 linear_k0_2 linear_r155 linear_l0_3 linear_b155 linear_v0_3 linear_g401 tail (by rfl) (linear_kp0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail))))) (linear_p155 (44 :: (linear_v0_3 ++ (125 :: tail)))) (linear_pl0_3 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl0_2
noncomputable def linear_l0_1 : List (List Nat × Raw) := (linear_k0_1, linear_r2) :: linear_l0_2
noncomputable def linear_v0_1 : List Nat := (linear_g4 ++ linear_b2) ++ (44 :: linear_v0_2)
theorem linear_sl0_1 : serializeFields 4094 31 linear_l0_1 = some linear_v0_1 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4093 31 linear_k0_1 linear_r2 (linear_k0_2, linear_r155) linear_l0_3 linear_b2 linear_v0_2 linear_g4 (by rfl) linear_kd0_1 linear_s2 linear_sl0_2)
#print axioms HiaCoreSyntaxSlice.linear_sl0_1
theorem linear_pl0_1 (tail : List Nat) : parseFields 4094 31 (linear_v0_1 ++ (125 :: tail)) = some (linear_l0_1, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4093 31 linear_k0_1 linear_r2 linear_l0_2 linear_b2 linear_v0_2 linear_g4 tail (by rfl) (linear_kp0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail))))) (linear_p2 (44 :: (linear_v0_2 ++ (125 :: tail)))) (linear_pl0_2 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl0_1
noncomputable def linear_l0_0 : List (List Nat × Raw) := (linear_k0_0, linear_r1) :: linear_l0_1
noncomputable def linear_v0_0 : List Nat := (linear_g1 ++ linear_b1) ++ (44 :: linear_v0_1)
theorem linear_sl0_0 : serializeFields 4095 31 linear_l0_0 = some linear_v0_0 := by
  exact (HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet 4094 31 linear_k0_0 linear_r1 (linear_k0_1, linear_r2) linear_l0_2 linear_b1 linear_v0_1 linear_g1 (by rfl) linear_kd0_0 linear_s1 linear_sl0_1)
#print axioms HiaCoreSyntaxSlice.linear_sl0_0
theorem linear_pl0_0 (tail : List Nat) : parseFields 4095 31 (linear_v0_0 ++ (125 :: tail)) = some (linear_l0_0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet 4094 31 linear_k0_0 linear_r1 linear_l0_1 linear_b1 linear_v0_1 linear_g1 tail (by rfl) (linear_kp0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail))))) (linear_p1 (44 :: (linear_v0_1 ++ (125 :: tail)))) (linear_pl0_1 tail))
#print axioms HiaCoreSyntaxSlice.linear_pl0_0
noncomputable def linear_r0 : Raw := (.obj linear_l0_0)
noncomputable def linear_b0 : List Nat := linear_g0 ++ (linear_v0_0 ++ linear_g406)
theorem linear_o0 : orderedFields linear_l0_0 = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_o0
theorem linear_s0 : serializeRaw 4096 32 linear_r0 = some linear_b0 := by
  exact (HiaCoreSyntaxSlice.Structured.serialize_object 4095 31 linear_l0_0 linear_v0_0 linear_o0 linear_sl0_0)
#print axioms HiaCoreSyntaxSlice.linear_s0
theorem linear_p0 (tail : List Nat) : parseRaw 4096 32 (linear_b0 ++ tail) = some (linear_r0, tail) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_object_bytes 4095 31 linear_l0_0 linear_v0_0 tail (by rfl) linear_o0 (linear_pl0_0 tail))
#print axioms HiaCoreSyntaxSlice.linear_p0
noncomputable def linearRaw : Raw := linear_r0
noncomputable def linearBytes : List Nat := linear_b0
theorem linear_bounds : withinBounds linearRaw = true := by decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bounds
theorem linear_serialized : serializeRaw transportFuel transportDepth linearRaw = some linearBytes := by exact linear_s0
#print axioms HiaCoreSyntaxSlice.linear_serialized
theorem linear_parsed : parseRaw transportFuel transportDepth linearBytes = some (linearRaw, []) := by
  exact (HiaCoreSyntaxSlice.Shared.parse_root transportFuel transportDepth linearRaw linearBytes linear_p0)
#print axioms HiaCoreSyntaxSlice.linear_parsed
theorem linear_bf0000 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g0 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0000
theorem linear_bf0001 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g1 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0001
theorem linear_bf0002 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g2 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0002
theorem linear_bf0003 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g4 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0003
theorem linear_bf0004 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g5 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0004
theorem linear_bf0005 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g6 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0005
theorem linear_bf0006 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g7 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0006
theorem linear_bf0007 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g8 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0004)
#print axioms HiaCoreSyntaxSlice.linear_bf0007
theorem linear_bf0008 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g9 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0008
theorem linear_bf0009 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g10 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0009
theorem linear_bf0010 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g11 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0010
theorem linear_bf0011 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g13 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0011
theorem linear_bf0012 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g14 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0012
theorem linear_bf0013 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g16 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0013
theorem linear_bf0014 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g17 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0014
theorem linear_bf0015 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g19 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0015
theorem linear_bf0016 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g20 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0016
theorem linear_bf0017 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g21 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0017
theorem linear_bf0018 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g23 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0018
theorem linear_bf0019 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g24 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0019
theorem linear_bf0020 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g25 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0020
theorem linear_bf0021 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g27 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0021
theorem linear_bf0022 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g28 178 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0022
theorem linear_bf0023 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g30 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0023
theorem linear_bf0024 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g31 195 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0024
theorem linear_bf0025 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g33 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0025
theorem linear_bf0026 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g34 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0026
theorem linear_bf0027 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g35 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0027
theorem linear_bf0028 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g37 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0028
theorem linear_bf0029 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g38 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0029
theorem linear_bf0030 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g39 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0030
theorem linear_bf0031 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g41 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0031
theorem linear_bf0032 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g42 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0004)
#print axioms HiaCoreSyntaxSlice.linear_bf0032
theorem linear_bf0033 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g43 58 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0033
theorem linear_bf0034 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g45 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0034
theorem linear_bf0035 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g47 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0035
theorem linear_bf0036 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g49 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0036
theorem linear_bf0037 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g50 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0037
theorem linear_bf0038 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g52 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0038
theorem linear_bf0039 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g53 200 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0039
theorem linear_bf0040 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g55 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0040
theorem linear_bf0041 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g56 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0041
theorem linear_bf0042 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g57 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0042
theorem linear_bf0043 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g59 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0043
theorem linear_bf0044 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g60 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0044
theorem linear_bf0045 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g61 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0045
theorem linear_bf0046 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g63 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0046
theorem linear_bf0047 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g64 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0047
theorem linear_bf0048 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g66 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0048
theorem linear_bf0049 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g67 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0049
theorem linear_bf0050 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g69 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0050
theorem linear_bf0051 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g70 233 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0051
theorem linear_bf0052 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g71 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0052
theorem linear_bf0053 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g73 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0053
theorem linear_bf0054 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g74 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0054
theorem linear_bf0055 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g75 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0055
theorem linear_bf0056 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g77 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0056
theorem linear_bf0057 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g78 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0057
theorem linear_bf0058 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g80 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0058
theorem linear_bf0059 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g81 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0059
theorem linear_bf0060 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g83 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0060
theorem linear_bf0061 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g84 115 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0061
theorem linear_bf0062 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g85 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0062
theorem linear_bf0063 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g87 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0063
theorem linear_bf0064 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g88 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0064
theorem linear_bf0065 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g89 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0065
theorem linear_bf0066 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g91 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0066
theorem linear_bf0067 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g92 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0067
theorem linear_bf0068 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g94 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0068
theorem linear_bf0069 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g95 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0069
theorem linear_bf0070 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g97 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0070
theorem linear_bf0071 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g98 253 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0071
theorem linear_bf0072 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g99 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0072
theorem linear_bf0073 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g101 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0073
theorem linear_bf0074 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g102 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0074
theorem linear_bf0075 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g103 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0075
theorem linear_bf0076 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g105 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0076
theorem linear_bf0077 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g106 153 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0077
theorem linear_bf0078 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g108 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0078
theorem linear_bf0079 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g109 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0079
theorem linear_bf0080 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g111 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0080
theorem linear_bf0081 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g112 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0081
theorem linear_bf0082 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g113 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0082
theorem linear_bf0083 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g115 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0083
theorem linear_bf0084 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g116 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0084
theorem linear_bf0085 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g117 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0085
theorem linear_bf0086 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g119 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0086
theorem linear_bf0087 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g120 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0087
theorem linear_bf0088 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g122 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0088
theorem linear_bf0089 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g123 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0089
theorem linear_bf0090 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g125 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0090
theorem linear_bf0091 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g126 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0091
theorem linear_bf0092 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g127 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0092
theorem linear_bf0093 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g129 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0093
theorem linear_bf0094 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g130 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0094
theorem linear_bf0095 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g131 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0095
theorem linear_bf0096 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g133 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0096
theorem linear_bf0097 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g134 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0004)
#print axioms HiaCoreSyntaxSlice.linear_bf0097
theorem linear_bf0098 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g135 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0098
theorem linear_bf0099 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g137 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0099
theorem linear_bf0100 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g139 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0100
theorem linear_bf0101 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g141 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0101
theorem linear_bf0102 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g143 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0102
theorem linear_bf0103 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g145 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0103
theorem linear_bf0104 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g147 92 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0104
theorem linear_bf0105 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g149 80 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0105
theorem linear_bf0106 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g151 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0106
theorem linear_bf0107 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g153 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0107
theorem linear_bf0108 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g155 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0108
theorem linear_bf0109 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g156 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0037)
#print axioms HiaCoreSyntaxSlice.linear_bf0109
theorem linear_bf0110 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g158 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0110
theorem linear_bf0111 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g159 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0111
theorem linear_bf0112 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g161 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0112
theorem linear_bf0113 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g162 93 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0113
theorem linear_bf0114 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g163 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0114
theorem linear_bf0115 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g165 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0115
theorem linear_bf0116 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g166 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0116
theorem linear_bf0117 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g167 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0117
theorem linear_bf0118 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g169 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0118
theorem linear_bf0119 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g170 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0119
theorem linear_bf0120 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g172 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0120
theorem linear_bf0121 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g173 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0121
theorem linear_bf0122 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g175 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0122
theorem linear_bf0123 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g176 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0123
theorem linear_bf0124 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g177 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0124
theorem linear_bf0125 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g179 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0125
theorem linear_bf0126 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g180 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0126
theorem linear_bf0127 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g181 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0127
theorem linear_bf0128 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g183 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0128
theorem linear_bf0129 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g184 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0129
theorem linear_bf0130 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g186 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0130
theorem linear_bf0131 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g187 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0131
theorem linear_bf0132 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g189 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0132
theorem linear_bf0133 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g190 230 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0133
theorem linear_bf0134 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g191 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0134
theorem linear_bf0135 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g193 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0135
theorem linear_bf0136 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g194 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0136
theorem linear_bf0137 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g195 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0137
theorem linear_bf0138 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g197 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0138
theorem linear_bf0139 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g198 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0004)
#print axioms HiaCoreSyntaxSlice.linear_bf0139
theorem linear_bf0140 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g199 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0140
theorem linear_bf0141 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g201 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0141
theorem linear_bf0142 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g203 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0142
theorem linear_bf0143 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g205 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0143
theorem linear_bf0144 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g207 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0144
theorem linear_bf0145 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g209 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0145
theorem linear_bf0146 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g211 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0146
theorem linear_bf0147 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g212 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0037)
#print axioms HiaCoreSyntaxSlice.linear_bf0147
theorem linear_bf0148 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g214 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0148
theorem linear_bf0149 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g215 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0149
theorem linear_bf0150 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g217 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0150
theorem linear_bf0151 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g218 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0151
theorem linear_bf0152 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g219 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0152
theorem linear_bf0153 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g221 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0153
theorem linear_bf0154 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g222 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0154
theorem linear_bf0155 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g223 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0155
theorem linear_bf0156 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g225 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0156
theorem linear_bf0157 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g226 155 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0157
theorem linear_bf0158 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g228 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0158
theorem linear_bf0159 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g229 205 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0159
theorem linear_bf0160 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g231 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0160
theorem linear_bf0161 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g232 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0161
theorem linear_bf0162 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g233 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0162
theorem linear_bf0163 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g235 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0163
theorem linear_bf0164 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g236 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0164
theorem linear_bf0165 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g237 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0165
theorem linear_bf0166 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g239 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0166
theorem linear_bf0167 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g240 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0167
theorem linear_bf0168 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g242 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0168
theorem linear_bf0169 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g243 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0169
theorem linear_bf0170 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g245 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0170
theorem linear_bf0171 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g246 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0171
theorem linear_bf0172 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g247 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0172
theorem linear_bf0173 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g249 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0173
theorem linear_bf0174 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g250 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0174
theorem linear_bf0175 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g251 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0175
theorem linear_bf0176 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g253 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0176
theorem linear_bf0177 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g254 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0004)
#print axioms HiaCoreSyntaxSlice.linear_bf0177
theorem linear_bf0178 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g255 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0178
theorem linear_bf0179 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g257 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0179
theorem linear_bf0180 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g259 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0180
theorem linear_bf0181 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g261 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0181
theorem linear_bf0182 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g263 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0182
theorem linear_bf0183 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g265 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0183
theorem linear_bf0184 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g267 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0184
theorem linear_bf0185 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g269 83 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0185
theorem linear_bf0186 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g271 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0186
theorem linear_bf0187 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g273 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0187
theorem linear_bf0188 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g275 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0188
theorem linear_bf0189 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g276 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0037)
#print axioms HiaCoreSyntaxSlice.linear_bf0189
theorem linear_bf0190 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g278 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0190
theorem linear_bf0191 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g279 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0191
theorem linear_bf0192 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g281 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0192
theorem linear_bf0193 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g282 98 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0193
theorem linear_bf0194 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g283 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0194
theorem linear_bf0195 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g285 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0195
theorem linear_bf0196 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g286 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0196
theorem linear_bf0197 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g287 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0197
theorem linear_bf0198 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g289 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0198
theorem linear_bf0199 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g290 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0199
theorem linear_bf0200 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g292 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0200
theorem linear_bf0201 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g293 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0201
theorem linear_bf0202 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g295 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0202
theorem linear_bf0203 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g296 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0203
theorem linear_bf0204 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g297 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0204
theorem linear_bf0205 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g299 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0205
theorem linear_bf0206 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g300 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0206
theorem linear_bf0207 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g301 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0207
theorem linear_bf0208 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g303 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0208
theorem linear_bf0209 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g304 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0209
theorem linear_bf0210 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g306 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0210
theorem linear_bf0211 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g307 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0211
theorem linear_bf0212 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g309 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0212
theorem linear_bf0213 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g310 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0213
theorem linear_bf0214 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g311 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0214
theorem linear_bf0215 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g313 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0215
theorem linear_bf0216 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g314 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0216
theorem linear_bf0217 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g315 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0217
theorem linear_bf0218 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g317 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0218
theorem linear_bf0219 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g318 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0004)
#print axioms HiaCoreSyntaxSlice.linear_bf0219
theorem linear_bf0220 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g319 96 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0220
theorem linear_bf0221 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g321 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0221
theorem linear_bf0222 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g323 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0222
theorem linear_bf0223 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g325 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0223
theorem linear_bf0224 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g327 107 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0224
theorem linear_bf0225 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g329 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0225
theorem linear_bf0226 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g331 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0226
theorem linear_bf0227 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g332 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0037)
#print axioms HiaCoreSyntaxSlice.linear_bf0227
theorem linear_bf0228 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g334 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0228
theorem linear_bf0229 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g335 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0229
theorem linear_bf0230 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g337 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0230
theorem linear_bf0231 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g338 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0231
theorem linear_bf0232 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g339 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0232
theorem linear_bf0233 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g341 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0233
theorem linear_bf0234 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g342 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0234
theorem linear_bf0235 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g343 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0235
theorem linear_bf0236 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g345 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0236
theorem linear_bf0237 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g346 156 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0237
theorem linear_bf0238 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g348 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0238
theorem linear_bf0239 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g349 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0239
theorem linear_bf0240 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g351 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0240
theorem linear_bf0241 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g352 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0241
theorem linear_bf0242 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g353 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0242
theorem linear_bf0243 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g355 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0243
theorem linear_bf0244 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g356 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0244
theorem linear_bf0245 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g357 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0245
theorem linear_bf0246 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g359 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0246
theorem linear_bf0247 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g360 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0247
theorem linear_bf0248 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g362 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0248
theorem linear_bf0249 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g363 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0249
theorem linear_bf0250 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g365 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0250
theorem linear_bf0251 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g366 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0251
theorem linear_bf0252 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g367 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0252
theorem linear_bf0253 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g369 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0000)
#print axioms HiaCoreSyntaxSlice.linear_bf0253
theorem linear_bf0254 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g370 5 := by
  exact (HiaCoreSyntaxSlice.linear_bf0009)
#print axioms HiaCoreSyntaxSlice.linear_bf0254
theorem linear_bf0255 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g371 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0255
theorem linear_bf0256 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g373 6 := by
  exact (HiaCoreSyntaxSlice.linear_bf0011)
#print axioms HiaCoreSyntaxSlice.linear_bf0256
theorem linear_bf0257 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g374 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0257
theorem linear_bf0258 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g376 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0258
theorem linear_bf0259 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g377 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0259
theorem linear_bf0260 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g379 7 := by
  exact (HiaCoreSyntaxSlice.linear_bf0015)
#print axioms HiaCoreSyntaxSlice.linear_bf0260
theorem linear_bf0261 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g380 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0261
theorem linear_bf0262 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g381 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0262
theorem linear_bf0263 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g382 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0037)
#print axioms HiaCoreSyntaxSlice.linear_bf0263
theorem linear_bf0264 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g384 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0264
theorem linear_bf0265 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g385 31 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0265
theorem linear_bf0266 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g387 8 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0266
theorem linear_bf0267 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g388 13 := by
  exact (HiaCoreSyntaxSlice.linear_bf0010)
#print axioms HiaCoreSyntaxSlice.linear_bf0267
theorem linear_bf0268 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g390 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0268
theorem linear_bf0269 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g391 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0269
theorem linear_bf0270 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g393 9 := by
  exact (HiaCoreSyntaxSlice.linear_bf0013)
#print axioms HiaCoreSyntaxSlice.linear_bf0270
theorem linear_bf0271 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g394 61 := by
  exact (HiaCoreSyntaxSlice.linear_bf0014)
#print axioms HiaCoreSyntaxSlice.linear_bf0271
theorem linear_bf0272 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g396 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0272
theorem linear_bf0273 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g397 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0273
theorem linear_bf0274 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g398 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0274
theorem linear_bf0275 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g399 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0037)
#print axioms HiaCoreSyntaxSlice.linear_bf0275
theorem linear_bf0276 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g401 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0276
theorem linear_bf0277 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g402 18 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0277
theorem linear_bf0278 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g404 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0278
theorem linear_bf0279 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g405 22 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
#print axioms HiaCoreSyntaxSlice.linear_bf0279
theorem linear_bf0280 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g406 1 := by
  exact (HiaCoreSyntaxSlice.linear_bf0017)
#print axioms HiaCoreSyntaxSlice.linear_bf0280
theorem linear_bf0281 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b1 13 := by
  simpa only [linear_b1] using linear_bf0002
#print axioms HiaCoreSyntaxSlice.linear_bf0281
theorem linear_bf0282 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b6 13 := by
  simpa only [linear_b6] using linear_bf0010
#print axioms HiaCoreSyntaxSlice.linear_bf0282
theorem linear_bf0283 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b7 209 := by
  simpa only [linear_b7] using linear_bf0012
#print axioms HiaCoreSyntaxSlice.linear_bf0283
theorem linear_bf0284 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b8 61 := by
  simpa only [linear_b8] using linear_bf0014
#print axioms HiaCoreSyntaxSlice.linear_bf0284
theorem linear_bf0285 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b9 209 := by
  simpa only [linear_b9] using linear_bf0016
#print axioms HiaCoreSyntaxSlice.linear_bf0285
theorem linear_bf0286 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_3 216 := by
  simpa only [linear_v5_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g19 linear_b9 7 209 linear_bf0015 linear_bf0285)
#print axioms HiaCoreSyntaxSlice.linear_bf0286
theorem linear_bf0287 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_2 287 := by
  simpa only [linear_v5_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g16 ++ linear_b8) (44 :: linear_v5_3) 70 217 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g16 linear_b8 9 61 linear_bf0013 linear_bf0284) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_3 216 (by decide +kernel) linear_bf0286))
#print axioms HiaCoreSyntaxSlice.linear_bf0287
theorem linear_bf0288 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_1 503 := by
  simpa only [linear_v5_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g13 ++ linear_b7) (44 :: linear_v5_2) 215 288 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g13 linear_b7 6 209 linear_bf0011 linear_bf0283) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_2 287 (by decide +kernel) linear_bf0287))
#print axioms HiaCoreSyntaxSlice.linear_bf0288
theorem linear_bf0289 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_0 522 := by
  simpa only [linear_v5_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g10 ++ linear_b6) (44 :: linear_v5_1) 18 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g10 linear_b6 5 13 linear_bf0009 linear_bf0282) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_1 503 (by decide +kernel) linear_bf0288))
#print axioms HiaCoreSyntaxSlice.linear_bf0289
theorem linear_bf0290 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b5 524 := by
  simpa only [linear_b5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g9 (linear_v5_0 ++ linear_g21) 1 523 linear_bf0008 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v5_0 linear_g21 522 1 linear_bf0289 linear_bf0017))
#print axioms HiaCoreSyntaxSlice.linear_bf0290
theorem linear_bf0291 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b11 13 := by
  simpa only [linear_b11] using linear_bf0020
#print axioms HiaCoreSyntaxSlice.linear_bf0291
theorem linear_bf0292 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b12 178 := by
  simpa only [linear_b12] using linear_bf0022
#print axioms HiaCoreSyntaxSlice.linear_bf0292
theorem linear_bf0293 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b13 195 := by
  simpa only [linear_b13] using linear_bf0024
#print axioms HiaCoreSyntaxSlice.linear_bf0293
theorem linear_bf0294 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b14 100 := by
  simpa only [linear_b14] using linear_bf0026
#print axioms HiaCoreSyntaxSlice.linear_bf0294
theorem linear_bf0295 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_3 107 := by
  simpa only [linear_v10_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g33 linear_b14 7 100 linear_bf0025 linear_bf0294)
#print axioms HiaCoreSyntaxSlice.linear_bf0295
theorem linear_bf0296 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_2 312 := by
  simpa only [linear_v10_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g30 ++ linear_b13) (44 :: linear_v10_3) 204 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g30 linear_b13 9 195 linear_bf0023 linear_bf0293) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_3 107 (by decide +kernel) linear_bf0295))
#print axioms HiaCoreSyntaxSlice.linear_bf0296
theorem linear_bf0297 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_1 497 := by
  simpa only [linear_v10_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g27 ++ linear_b12) (44 :: linear_v10_2) 184 313 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g27 linear_b12 6 178 linear_bf0021 linear_bf0292) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_2 312 (by decide +kernel) linear_bf0296))
#print axioms HiaCoreSyntaxSlice.linear_bf0297
theorem linear_bf0298 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_0 516 := by
  simpa only [linear_v10_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g24 ++ linear_b11) (44 :: linear_v10_1) 18 498 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g24 linear_b11 5 13 linear_bf0019 linear_bf0291) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_1 497 (by decide +kernel) linear_bf0297))
#print axioms HiaCoreSyntaxSlice.linear_bf0298
theorem linear_bf0299 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b10 518 := by
  simpa only [linear_b10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g23 (linear_v10_0 ++ linear_g35) 1 517 linear_bf0018 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v10_0 linear_g35 516 1 linear_bf0298 linear_bf0027))
#print axioms HiaCoreSyntaxSlice.linear_bf0299
theorem linear_bf0300 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b16 13 := by
  simpa only [linear_b16] using linear_bf0030
#print axioms HiaCoreSyntaxSlice.linear_bf0300
theorem linear_bf0301 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b18 58 := by
  simpa only [linear_b18] using linear_bf0033
#print axioms HiaCoreSyntaxSlice.linear_bf0301
theorem linear_bf0302 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b19 87 := by
  simpa only [linear_b19] using linear_bf0034
#print axioms HiaCoreSyntaxSlice.linear_bf0302
theorem linear_bf0303 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b20 100 := by
  simpa only [linear_b20] using linear_bf0035
#print axioms HiaCoreSyntaxSlice.linear_bf0303
theorem linear_bf0304 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b21 104 := by
  simpa only [linear_b21] using linear_bf0036
#print axioms HiaCoreSyntaxSlice.linear_bf0304
theorem linear_bf0305 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_3 104 := by
  simpa only [linear_v17_3] using linear_bf0304
#print axioms HiaCoreSyntaxSlice.linear_bf0305
theorem linear_bf0306 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_2 205 := by
  simpa only [linear_v17_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b20 (44 :: linear_v17_3) 100 105 linear_bf0303 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_3 104 (by decide +kernel) linear_bf0305))
#print axioms HiaCoreSyntaxSlice.linear_bf0306
theorem linear_bf0307 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_1 293 := by
  simpa only [linear_v17_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b19 (44 :: linear_v17_2) 87 206 linear_bf0302 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_2 205 (by decide +kernel) linear_bf0306))
#print axioms HiaCoreSyntaxSlice.linear_bf0307
theorem linear_bf0308 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_0 352 := by
  simpa only [linear_v17_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b18 (44 :: linear_v17_1) 58 294 linear_bf0301 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_1 293 (by decide +kernel) linear_bf0307))
#print axioms HiaCoreSyntaxSlice.linear_bf0308
theorem linear_bf0309 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b17 354 := by
  simpa only [linear_b17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g42 (linear_v17_0 ++ linear_g50) 1 353 linear_bf0032 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v17_0 linear_g50 352 1 linear_bf0308 linear_bf0037))
#print axioms HiaCoreSyntaxSlice.linear_bf0309
theorem linear_bf0310 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b22 200 := by
  simpa only [linear_b22] using linear_bf0039
#print axioms HiaCoreSyntaxSlice.linear_bf0310
theorem linear_bf0311 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b23 33 := by
  simpa only [linear_b23] using linear_bf0041
#print axioms HiaCoreSyntaxSlice.linear_bf0311
theorem linear_bf0312 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_3 40 := by
  simpa only [linear_v15_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g55 linear_b23 7 33 linear_bf0040 linear_bf0311)
#print axioms HiaCoreSyntaxSlice.linear_bf0312
theorem linear_bf0313 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_2 250 := by
  simpa only [linear_v15_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g52 ++ linear_b22) (44 :: linear_v15_3) 209 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g52 linear_b22 9 200 linear_bf0038 linear_bf0310) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_3 40 (by decide +kernel) linear_bf0312))
#print axioms HiaCoreSyntaxSlice.linear_bf0313
theorem linear_bf0314 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_1 611 := by
  simpa only [linear_v15_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g41 ++ linear_b17) (44 :: linear_v15_2) 360 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g41 linear_b17 6 354 linear_bf0031 linear_bf0309) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_2 250 (by decide +kernel) linear_bf0313))
#print axioms HiaCoreSyntaxSlice.linear_bf0314
theorem linear_bf0315 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_0 630 := by
  simpa only [linear_v15_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g38 ++ linear_b16) (44 :: linear_v15_1) 18 612 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g38 linear_b16 5 13 linear_bf0029 linear_bf0300) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_1 611 (by decide +kernel) linear_bf0314))
#print axioms HiaCoreSyntaxSlice.linear_bf0315
theorem linear_bf0316 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b15 632 := by
  simpa only [linear_b15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g37 (linear_v15_0 ++ linear_g57) 1 631 linear_bf0028 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v15_0 linear_g57 630 1 linear_bf0315 linear_bf0042))
#print axioms HiaCoreSyntaxSlice.linear_bf0316
theorem linear_bf0317 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b25 13 := by
  simpa only [linear_b25] using linear_bf0045
#print axioms HiaCoreSyntaxSlice.linear_bf0317
theorem linear_bf0318 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b26 102 := by
  simpa only [linear_b26] using linear_bf0047
#print axioms HiaCoreSyntaxSlice.linear_bf0318
theorem linear_bf0319 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b27 204 := by
  simpa only [linear_b27] using linear_bf0049
#print axioms HiaCoreSyntaxSlice.linear_bf0319
theorem linear_bf0320 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b28 233 := by
  simpa only [linear_b28] using linear_bf0051
#print axioms HiaCoreSyntaxSlice.linear_bf0320
theorem linear_bf0321 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_3 240 := by
  simpa only [linear_v24_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g69 linear_b28 7 233 linear_bf0050 linear_bf0320)
#print axioms HiaCoreSyntaxSlice.linear_bf0321
theorem linear_bf0322 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_2 454 := by
  simpa only [linear_v24_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g66 ++ linear_b27) (44 :: linear_v24_3) 213 241 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g66 linear_b27 9 204 linear_bf0048 linear_bf0319) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_3 240 (by decide +kernel) linear_bf0321))
#print axioms HiaCoreSyntaxSlice.linear_bf0322
theorem linear_bf0323 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_1 563 := by
  simpa only [linear_v24_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g63 ++ linear_b26) (44 :: linear_v24_2) 108 455 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g63 linear_b26 6 102 linear_bf0046 linear_bf0318) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_2 454 (by decide +kernel) linear_bf0322))
#print axioms HiaCoreSyntaxSlice.linear_bf0323
theorem linear_bf0324 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_0 582 := by
  simpa only [linear_v24_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g60 ++ linear_b25) (44 :: linear_v24_1) 18 564 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g60 linear_b25 5 13 linear_bf0044 linear_bf0317) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_1 563 (by decide +kernel) linear_bf0323))
#print axioms HiaCoreSyntaxSlice.linear_bf0324
theorem linear_bf0325 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b24 584 := by
  simpa only [linear_b24] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g59 (linear_v24_0 ++ linear_g71) 1 583 linear_bf0043 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v24_0 linear_g71 582 1 linear_bf0324 linear_bf0052))
#print axioms HiaCoreSyntaxSlice.linear_bf0325
theorem linear_bf0326 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b30 13 := by
  simpa only [linear_b30] using linear_bf0055
#print axioms HiaCoreSyntaxSlice.linear_bf0326
theorem linear_bf0327 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b31 173 := by
  simpa only [linear_b31] using linear_bf0057
#print axioms HiaCoreSyntaxSlice.linear_bf0327
theorem linear_bf0328 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b32 204 := by
  simpa only [linear_b32] using linear_bf0059
#print axioms HiaCoreSyntaxSlice.linear_bf0328
theorem linear_bf0329 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b33 115 := by
  simpa only [linear_b33] using linear_bf0061
#print axioms HiaCoreSyntaxSlice.linear_bf0329
theorem linear_bf0330 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_3 122 := by
  simpa only [linear_v29_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g83 linear_b33 7 115 linear_bf0060 linear_bf0329)
#print axioms HiaCoreSyntaxSlice.linear_bf0330
theorem linear_bf0331 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_2 336 := by
  simpa only [linear_v29_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g80 ++ linear_b32) (44 :: linear_v29_3) 213 123 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g80 linear_b32 9 204 linear_bf0058 linear_bf0328) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_3 122 (by decide +kernel) linear_bf0330))
#print axioms HiaCoreSyntaxSlice.linear_bf0331
theorem linear_bf0332 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_1 516 := by
  simpa only [linear_v29_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g77 ++ linear_b31) (44 :: linear_v29_2) 179 337 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g77 linear_b31 6 173 linear_bf0056 linear_bf0327) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_2 336 (by decide +kernel) linear_bf0331))
#print axioms HiaCoreSyntaxSlice.linear_bf0332
theorem linear_bf0333 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_0 535 := by
  simpa only [linear_v29_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g74 ++ linear_b30) (44 :: linear_v29_1) 18 517 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g74 linear_b30 5 13 linear_bf0054 linear_bf0326) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_1 516 (by decide +kernel) linear_bf0332))
#print axioms HiaCoreSyntaxSlice.linear_bf0333
theorem linear_bf0334 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b29 537 := by
  simpa only [linear_b29] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g73 (linear_v29_0 ++ linear_g85) 1 536 linear_bf0053 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v29_0 linear_g85 535 1 linear_bf0333 linear_bf0062))
#print axioms HiaCoreSyntaxSlice.linear_bf0334
theorem linear_bf0335 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b35 13 := by
  simpa only [linear_b35] using linear_bf0065
#print axioms HiaCoreSyntaxSlice.linear_bf0335
theorem linear_bf0336 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b36 102 := by
  simpa only [linear_b36] using linear_bf0067
#print axioms HiaCoreSyntaxSlice.linear_bf0336
theorem linear_bf0337 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b37 236 := by
  simpa only [linear_b37] using linear_bf0069
#print axioms HiaCoreSyntaxSlice.linear_bf0337
theorem linear_bf0338 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b38 253 := by
  simpa only [linear_b38] using linear_bf0071
#print axioms HiaCoreSyntaxSlice.linear_bf0338
theorem linear_bf0339 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_3 260 := by
  simpa only [linear_v34_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g97 linear_b38 7 253 linear_bf0070 linear_bf0338)
#print axioms HiaCoreSyntaxSlice.linear_bf0339
theorem linear_bf0340 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_2 506 := by
  simpa only [linear_v34_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g94 ++ linear_b37) (44 :: linear_v34_3) 245 261 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g94 linear_b37 9 236 linear_bf0068 linear_bf0337) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_3 260 (by decide +kernel) linear_bf0339))
#print axioms HiaCoreSyntaxSlice.linear_bf0340
theorem linear_bf0341 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_1 615 := by
  simpa only [linear_v34_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g91 ++ linear_b36) (44 :: linear_v34_2) 108 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g91 linear_b36 6 102 linear_bf0066 linear_bf0336) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_2 506 (by decide +kernel) linear_bf0340))
#print axioms HiaCoreSyntaxSlice.linear_bf0341
theorem linear_bf0342 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_0 634 := by
  simpa only [linear_v34_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g88 ++ linear_b35) (44 :: linear_v34_1) 18 616 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g88 linear_b35 5 13 linear_bf0064 linear_bf0335) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_1 615 (by decide +kernel) linear_bf0341))
#print axioms HiaCoreSyntaxSlice.linear_bf0342
theorem linear_bf0343 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b34 636 := by
  simpa only [linear_b34] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g87 (linear_v34_0 ++ linear_g99) 1 635 linear_bf0063 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v34_0 linear_g99 634 1 linear_bf0342 linear_bf0072))
#print axioms HiaCoreSyntaxSlice.linear_bf0343
theorem linear_bf0344 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b40 13 := by
  simpa only [linear_b40] using linear_bf0075
#print axioms HiaCoreSyntaxSlice.linear_bf0344
theorem linear_bf0345 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b41 153 := by
  simpa only [linear_b41] using linear_bf0077
#print axioms HiaCoreSyntaxSlice.linear_bf0345
theorem linear_bf0346 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b42 236 := by
  simpa only [linear_b42] using linear_bf0079
#print axioms HiaCoreSyntaxSlice.linear_bf0346
theorem linear_bf0347 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b43 33 := by
  simpa only [linear_b43] using linear_bf0081
#print axioms HiaCoreSyntaxSlice.linear_bf0347
theorem linear_bf0348 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_3 40 := by
  simpa only [linear_v39_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g111 linear_b43 7 33 linear_bf0080 linear_bf0347)
#print axioms HiaCoreSyntaxSlice.linear_bf0348
theorem linear_bf0349 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_2 286 := by
  simpa only [linear_v39_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g108 ++ linear_b42) (44 :: linear_v39_3) 245 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g108 linear_b42 9 236 linear_bf0078 linear_bf0346) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_3 40 (by decide +kernel) linear_bf0348))
#print axioms HiaCoreSyntaxSlice.linear_bf0349
theorem linear_bf0350 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_1 446 := by
  simpa only [linear_v39_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g105 ++ linear_b41) (44 :: linear_v39_2) 159 287 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g105 linear_b41 6 153 linear_bf0076 linear_bf0345) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_2 286 (by decide +kernel) linear_bf0349))
#print axioms HiaCoreSyntaxSlice.linear_bf0350
theorem linear_bf0351 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_0 465 := by
  simpa only [linear_v39_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g102 ++ linear_b40) (44 :: linear_v39_1) 18 447 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g102 linear_b40 5 13 linear_bf0074 linear_bf0344) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_1 446 (by decide +kernel) linear_bf0350))
#print axioms HiaCoreSyntaxSlice.linear_bf0351
theorem linear_bf0352 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b39 467 := by
  simpa only [linear_b39] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g101 (linear_v39_0 ++ linear_g113) 1 466 linear_bf0073 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v39_0 linear_g113 465 1 linear_bf0351 linear_bf0082))
#print axioms HiaCoreSyntaxSlice.linear_bf0352
theorem linear_bf0353 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b45 11 := by
  simpa only [linear_b45] using linear_bf0085
#print axioms HiaCoreSyntaxSlice.linear_bf0353
theorem linear_bf0354 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b46 102 := by
  simpa only [linear_b46] using linear_bf0087
#print axioms HiaCoreSyntaxSlice.linear_bf0354
theorem linear_bf0355 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b47 170 := by
  simpa only [linear_b47] using linear_bf0089
#print axioms HiaCoreSyntaxSlice.linear_bf0355
theorem linear_bf0356 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b48 210 := by
  simpa only [linear_b48] using linear_bf0091
#print axioms HiaCoreSyntaxSlice.linear_bf0356
theorem linear_bf0357 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_3 217 := by
  simpa only [linear_v44_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g125 linear_b48 7 210 linear_bf0090 linear_bf0356)
#print axioms HiaCoreSyntaxSlice.linear_bf0357
theorem linear_bf0358 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_2 397 := by
  simpa only [linear_v44_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g122 ++ linear_b47) (44 :: linear_v44_3) 179 218 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g122 linear_b47 9 170 linear_bf0088 linear_bf0355) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_3 217 (by decide +kernel) linear_bf0357))
#print axioms HiaCoreSyntaxSlice.linear_bf0358
theorem linear_bf0359 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_1 506 := by
  simpa only [linear_v44_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g119 ++ linear_b46) (44 :: linear_v44_2) 108 398 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g119 linear_b46 6 102 linear_bf0086 linear_bf0354) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_2 397 (by decide +kernel) linear_bf0358))
#print axioms HiaCoreSyntaxSlice.linear_bf0359
theorem linear_bf0360 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_0 523 := by
  simpa only [linear_v44_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g116 ++ linear_b45) (44 :: linear_v44_1) 16 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g116 linear_b45 5 11 linear_bf0084 linear_bf0353) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_1 506 (by decide +kernel) linear_bf0359))
#print axioms HiaCoreSyntaxSlice.linear_bf0360
theorem linear_bf0361 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b44 525 := by
  simpa only [linear_b44] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g115 (linear_v44_0 ++ linear_g127) 1 524 linear_bf0083 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v44_0 linear_g127 523 1 linear_bf0360 linear_bf0092))
#print axioms HiaCoreSyntaxSlice.linear_bf0361
theorem linear_bf0362 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b50 11 := by
  simpa only [linear_b50] using linear_bf0095
#print axioms HiaCoreSyntaxSlice.linear_bf0362
theorem linear_bf0363 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b52 100 := by
  simpa only [linear_b52] using linear_bf0098
#print axioms HiaCoreSyntaxSlice.linear_bf0363
theorem linear_bf0364 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b53 101 := by
  simpa only [linear_b53] using linear_bf0099
#print axioms HiaCoreSyntaxSlice.linear_bf0364
theorem linear_bf0365 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b54 99 := by
  simpa only [linear_b54] using linear_bf0100
#print axioms HiaCoreSyntaxSlice.linear_bf0365
theorem linear_bf0366 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b55 99 := by
  simpa only [linear_b55] using linear_bf0101
#print axioms HiaCoreSyntaxSlice.linear_bf0366
theorem linear_bf0367 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b56 100 := by
  simpa only [linear_b56] using linear_bf0102
#print axioms HiaCoreSyntaxSlice.linear_bf0367
theorem linear_bf0368 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b57 99 := by
  simpa only [linear_b57] using linear_bf0103
#print axioms HiaCoreSyntaxSlice.linear_bf0368
theorem linear_bf0369 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b58 92 := by
  simpa only [linear_b58] using linear_bf0104
#print axioms HiaCoreSyntaxSlice.linear_bf0369
theorem linear_bf0370 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b59 80 := by
  simpa only [linear_b59] using linear_bf0105
#print axioms HiaCoreSyntaxSlice.linear_bf0370
theorem linear_bf0371 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b60 56 := by
  simpa only [linear_b60] using linear_bf0106
#print axioms HiaCoreSyntaxSlice.linear_bf0371
theorem linear_bf0372 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b61 86 := by
  simpa only [linear_b61] using linear_bf0107
#print axioms HiaCoreSyntaxSlice.linear_bf0372
theorem linear_bf0373 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b62 103 := by
  simpa only [linear_b62] using linear_bf0108
#print axioms HiaCoreSyntaxSlice.linear_bf0373
theorem linear_bf0374 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_10 103 := by
  simpa only [linear_v51_10] using linear_bf0373
#print axioms HiaCoreSyntaxSlice.linear_bf0374
theorem linear_bf0375 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_9 190 := by
  simpa only [linear_v51_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b61 (44 :: linear_v51_10) 86 104 linear_bf0372 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_10 103 (by decide +kernel) linear_bf0374))
#print axioms HiaCoreSyntaxSlice.linear_bf0375
theorem linear_bf0376 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_8 247 := by
  simpa only [linear_v51_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b60 (44 :: linear_v51_9) 56 191 linear_bf0371 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_9 190 (by decide +kernel) linear_bf0375))
#print axioms HiaCoreSyntaxSlice.linear_bf0376
theorem linear_bf0377 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_7 328 := by
  simpa only [linear_v51_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b59 (44 :: linear_v51_8) 80 248 linear_bf0370 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_8 247 (by decide +kernel) linear_bf0376))
#print axioms HiaCoreSyntaxSlice.linear_bf0377
theorem linear_bf0378 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_6 421 := by
  simpa only [linear_v51_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b58 (44 :: linear_v51_7) 92 329 linear_bf0369 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_7 328 (by decide +kernel) linear_bf0377))
#print axioms HiaCoreSyntaxSlice.linear_bf0378
theorem linear_bf0379 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_5 521 := by
  simpa only [linear_v51_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b57 (44 :: linear_v51_6) 99 422 linear_bf0368 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_6 421 (by decide +kernel) linear_bf0378))
#print axioms HiaCoreSyntaxSlice.linear_bf0379
theorem linear_bf0380 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_4 622 := by
  simpa only [linear_v51_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b56 (44 :: linear_v51_5) 100 522 linear_bf0367 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_5 521 (by decide +kernel) linear_bf0379))
#print axioms HiaCoreSyntaxSlice.linear_bf0380
theorem linear_bf0381 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_3 722 := by
  simpa only [linear_v51_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b55 (44 :: linear_v51_4) 99 623 linear_bf0366 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_4 622 (by decide +kernel) linear_bf0380))
#print axioms HiaCoreSyntaxSlice.linear_bf0381
theorem linear_bf0382 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_2 822 := by
  simpa only [linear_v51_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b54 (44 :: linear_v51_3) 99 723 linear_bf0365 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_3 722 (by decide +kernel) linear_bf0381))
#print axioms HiaCoreSyntaxSlice.linear_bf0382
theorem linear_bf0383 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_1 924 := by
  simpa only [linear_v51_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b53 (44 :: linear_v51_2) 101 823 linear_bf0364 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_2 822 (by decide +kernel) linear_bf0382))
#print axioms HiaCoreSyntaxSlice.linear_bf0383
theorem linear_bf0384 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_0 1025 := by
  simpa only [linear_v51_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b52 (44 :: linear_v51_1) 100 925 linear_bf0363 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_1 924 (by decide +kernel) linear_bf0383))
#print axioms HiaCoreSyntaxSlice.linear_bf0384
theorem linear_bf0385 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b51 1027 := by
  simpa only [linear_b51] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g134 (linear_v51_0 ++ linear_g156) 1 1026 linear_bf0097 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v51_0 linear_g156 1025 1 linear_bf0384 linear_bf0109))
#print axioms HiaCoreSyntaxSlice.linear_bf0385
theorem linear_bf0386 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b63 170 := by
  simpa only [linear_b63] using linear_bf0111
#print axioms HiaCoreSyntaxSlice.linear_bf0386
theorem linear_bf0387 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b64 93 := by
  simpa only [linear_b64] using linear_bf0113
#print axioms HiaCoreSyntaxSlice.linear_bf0387
theorem linear_bf0388 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_3 100 := by
  simpa only [linear_v49_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g161 linear_b64 7 93 linear_bf0112 linear_bf0387)
#print axioms HiaCoreSyntaxSlice.linear_bf0388
theorem linear_bf0389 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_2 280 := by
  simpa only [linear_v49_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g158 ++ linear_b63) (44 :: linear_v49_3) 179 101 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g158 linear_b63 9 170 linear_bf0110 linear_bf0386) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_3 100 (by decide +kernel) linear_bf0388))
#print axioms HiaCoreSyntaxSlice.linear_bf0389
theorem linear_bf0390 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_1 1314 := by
  simpa only [linear_v49_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g133 ++ linear_b51) (44 :: linear_v49_2) 1033 281 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g133 linear_b51 6 1027 linear_bf0096 linear_bf0385) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_2 280 (by decide +kernel) linear_bf0389))
#print axioms HiaCoreSyntaxSlice.linear_bf0390
theorem linear_bf0391 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_0 1331 := by
  simpa only [linear_v49_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g130 ++ linear_b50) (44 :: linear_v49_1) 16 1315 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g130 linear_b50 5 11 linear_bf0094 linear_bf0362) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_1 1314 (by decide +kernel) linear_bf0390))
#print axioms HiaCoreSyntaxSlice.linear_bf0391
theorem linear_bf0392 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b49 1333 := by
  simpa only [linear_b49] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g129 (linear_v49_0 ++ linear_g163) 1 1332 linear_bf0093 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v49_0 linear_g163 1331 1 linear_bf0391 linear_bf0114))
#print axioms HiaCoreSyntaxSlice.linear_bf0392
theorem linear_bf0393 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b66 11 := by
  simpa only [linear_b66] using linear_bf0117
#print axioms HiaCoreSyntaxSlice.linear_bf0393
theorem linear_bf0394 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b67 173 := by
  simpa only [linear_b67] using linear_bf0119
#print axioms HiaCoreSyntaxSlice.linear_bf0394
theorem linear_bf0395 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b68 170 := by
  simpa only [linear_b68] using linear_bf0121
#print axioms HiaCoreSyntaxSlice.linear_bf0395
theorem linear_bf0396 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b69 103 := by
  simpa only [linear_b69] using linear_bf0123
#print axioms HiaCoreSyntaxSlice.linear_bf0396
theorem linear_bf0397 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_3 110 := by
  simpa only [linear_v65_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g175 linear_b69 7 103 linear_bf0122 linear_bf0396)
#print axioms HiaCoreSyntaxSlice.linear_bf0397
theorem linear_bf0398 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_2 290 := by
  simpa only [linear_v65_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g172 ++ linear_b68) (44 :: linear_v65_3) 179 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g172 linear_b68 9 170 linear_bf0120 linear_bf0395) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_3 110 (by decide +kernel) linear_bf0397))
#print axioms HiaCoreSyntaxSlice.linear_bf0398
theorem linear_bf0399 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_1 470 := by
  simpa only [linear_v65_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g169 ++ linear_b67) (44 :: linear_v65_2) 179 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g169 linear_b67 6 173 linear_bf0118 linear_bf0394) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_2 290 (by decide +kernel) linear_bf0398))
#print axioms HiaCoreSyntaxSlice.linear_bf0399
theorem linear_bf0400 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_0 487 := by
  simpa only [linear_v65_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g166 ++ linear_b66) (44 :: linear_v65_1) 16 471 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g166 linear_b66 5 11 linear_bf0116 linear_bf0393) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_1 470 (by decide +kernel) linear_bf0399))
#print axioms HiaCoreSyntaxSlice.linear_bf0400
theorem linear_bf0401 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b65 489 := by
  simpa only [linear_b65] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g165 (linear_v65_0 ++ linear_g177) 1 488 linear_bf0115 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v65_0 linear_g177 487 1 linear_bf0400 linear_bf0124))
#print axioms HiaCoreSyntaxSlice.linear_bf0401
theorem linear_bf0402 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b71 11 := by
  simpa only [linear_b71] using linear_bf0127
#print axioms HiaCoreSyntaxSlice.linear_bf0402
theorem linear_bf0403 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b72 102 := by
  simpa only [linear_b72] using linear_bf0129
#print axioms HiaCoreSyntaxSlice.linear_bf0403
theorem linear_bf0404 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b73 202 := by
  simpa only [linear_b73] using linear_bf0131
#print axioms HiaCoreSyntaxSlice.linear_bf0404
theorem linear_bf0405 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b74 230 := by
  simpa only [linear_b74] using linear_bf0133
#print axioms HiaCoreSyntaxSlice.linear_bf0405
theorem linear_bf0406 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_3 237 := by
  simpa only [linear_v70_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g189 linear_b74 7 230 linear_bf0132 linear_bf0405)
#print axioms HiaCoreSyntaxSlice.linear_bf0406
theorem linear_bf0407 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_2 449 := by
  simpa only [linear_v70_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g186 ++ linear_b73) (44 :: linear_v70_3) 211 238 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g186 linear_b73 9 202 linear_bf0130 linear_bf0404) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_3 237 (by decide +kernel) linear_bf0406))
#print axioms HiaCoreSyntaxSlice.linear_bf0407
theorem linear_bf0408 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_1 558 := by
  simpa only [linear_v70_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g183 ++ linear_b72) (44 :: linear_v70_2) 108 450 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g183 linear_b72 6 102 linear_bf0128 linear_bf0403) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_2 449 (by decide +kernel) linear_bf0407))
#print axioms HiaCoreSyntaxSlice.linear_bf0408
theorem linear_bf0409 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_0 575 := by
  simpa only [linear_v70_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g180 ++ linear_b71) (44 :: linear_v70_1) 16 559 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g180 linear_b71 5 11 linear_bf0126 linear_bf0402) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_1 558 (by decide +kernel) linear_bf0408))
#print axioms HiaCoreSyntaxSlice.linear_bf0409
theorem linear_bf0410 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b70 577 := by
  simpa only [linear_b70] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g179 (linear_v70_0 ++ linear_g191) 1 576 linear_bf0125 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v70_0 linear_g191 575 1 linear_bf0409 linear_bf0134))
#print axioms HiaCoreSyntaxSlice.linear_bf0410
theorem linear_bf0411 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b76 11 := by
  simpa only [linear_b76] using linear_bf0137
#print axioms HiaCoreSyntaxSlice.linear_bf0411
theorem linear_bf0412 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b78 94 := by
  simpa only [linear_b78] using linear_bf0140
#print axioms HiaCoreSyntaxSlice.linear_bf0412
theorem linear_bf0413 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b79 99 := by
  simpa only [linear_b79] using linear_bf0141
#print axioms HiaCoreSyntaxSlice.linear_bf0413
theorem linear_bf0414 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b80 56 := by
  simpa only [linear_b80] using linear_bf0142
#print axioms HiaCoreSyntaxSlice.linear_bf0414
theorem linear_bf0415 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b81 100 := by
  simpa only [linear_b81] using linear_bf0143
#print axioms HiaCoreSyntaxSlice.linear_bf0415
theorem linear_bf0416 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b82 101 := by
  simpa only [linear_b82] using linear_bf0144
#print axioms HiaCoreSyntaxSlice.linear_bf0416
theorem linear_bf0417 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b83 86 := by
  simpa only [linear_b83] using linear_bf0145
#print axioms HiaCoreSyntaxSlice.linear_bf0417
theorem linear_bf0418 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b84 103 := by
  simpa only [linear_b84] using linear_bf0146
#print axioms HiaCoreSyntaxSlice.linear_bf0418
theorem linear_bf0419 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_6 103 := by
  simpa only [linear_v77_6] using linear_bf0418
#print axioms HiaCoreSyntaxSlice.linear_bf0419
theorem linear_bf0420 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_5 190 := by
  simpa only [linear_v77_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b83 (44 :: linear_v77_6) 86 104 linear_bf0417 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_6 103 (by decide +kernel) linear_bf0419))
#print axioms HiaCoreSyntaxSlice.linear_bf0420
theorem linear_bf0421 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_4 292 := by
  simpa only [linear_v77_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b82 (44 :: linear_v77_5) 101 191 linear_bf0416 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_5 190 (by decide +kernel) linear_bf0420))
#print axioms HiaCoreSyntaxSlice.linear_bf0421
theorem linear_bf0422 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_3 393 := by
  simpa only [linear_v77_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b81 (44 :: linear_v77_4) 100 293 linear_bf0415 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_4 292 (by decide +kernel) linear_bf0421))
#print axioms HiaCoreSyntaxSlice.linear_bf0422
theorem linear_bf0423 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_2 450 := by
  simpa only [linear_v77_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b80 (44 :: linear_v77_3) 56 394 linear_bf0414 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_3 393 (by decide +kernel) linear_bf0422))
#print axioms HiaCoreSyntaxSlice.linear_bf0423
theorem linear_bf0424 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_1 550 := by
  simpa only [linear_v77_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b79 (44 :: linear_v77_2) 99 451 linear_bf0413 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_2 450 (by decide +kernel) linear_bf0423))
#print axioms HiaCoreSyntaxSlice.linear_bf0424
theorem linear_bf0425 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_0 645 := by
  simpa only [linear_v77_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b78 (44 :: linear_v77_1) 94 551 linear_bf0412 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_1 550 (by decide +kernel) linear_bf0424))
#print axioms HiaCoreSyntaxSlice.linear_bf0425
theorem linear_bf0426 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b77 647 := by
  simpa only [linear_b77] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g198 (linear_v77_0 ++ linear_g212) 1 646 linear_bf0139 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v77_0 linear_g212 645 1 linear_bf0425 linear_bf0147))
#print axioms HiaCoreSyntaxSlice.linear_bf0426
theorem linear_bf0427 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b85 202 := by
  simpa only [linear_b85] using linear_bf0149
#print axioms HiaCoreSyntaxSlice.linear_bf0427
theorem linear_bf0428 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b86 103 := by
  simpa only [linear_b86] using linear_bf0151
#print axioms HiaCoreSyntaxSlice.linear_bf0428
theorem linear_bf0429 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_3 110 := by
  simpa only [linear_v75_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g217 linear_b86 7 103 linear_bf0150 linear_bf0428)
#print axioms HiaCoreSyntaxSlice.linear_bf0429
theorem linear_bf0430 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_2 322 := by
  simpa only [linear_v75_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g214 ++ linear_b85) (44 :: linear_v75_3) 211 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g214 linear_b85 9 202 linear_bf0148 linear_bf0427) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_3 110 (by decide +kernel) linear_bf0429))
#print axioms HiaCoreSyntaxSlice.linear_bf0430
theorem linear_bf0431 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_1 976 := by
  simpa only [linear_v75_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g197 ++ linear_b77) (44 :: linear_v75_2) 653 323 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g197 linear_b77 6 647 linear_bf0138 linear_bf0426) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_2 322 (by decide +kernel) linear_bf0430))
#print axioms HiaCoreSyntaxSlice.linear_bf0431
theorem linear_bf0432 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_0 993 := by
  simpa only [linear_v75_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g194 ++ linear_b76) (44 :: linear_v75_1) 16 977 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g194 linear_b76 5 11 linear_bf0136 linear_bf0411) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_1 976 (by decide +kernel) linear_bf0431))
#print axioms HiaCoreSyntaxSlice.linear_bf0432
theorem linear_bf0433 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b75 995 := by
  simpa only [linear_b75] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g193 (linear_v75_0 ++ linear_g219) 1 994 linear_bf0135 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v75_0 linear_g219 993 1 linear_bf0432 linear_bf0152))
#print axioms HiaCoreSyntaxSlice.linear_bf0433
theorem linear_bf0434 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b88 11 := by
  simpa only [linear_b88] using linear_bf0155
#print axioms HiaCoreSyntaxSlice.linear_bf0434
theorem linear_bf0435 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b89 155 := by
  simpa only [linear_b89] using linear_bf0157
#print axioms HiaCoreSyntaxSlice.linear_bf0435
theorem linear_bf0436 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b90 205 := by
  simpa only [linear_b90] using linear_bf0159
#print axioms HiaCoreSyntaxSlice.linear_bf0436
theorem linear_bf0437 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b91 34 := by
  simpa only [linear_b91] using linear_bf0161
#print axioms HiaCoreSyntaxSlice.linear_bf0437
theorem linear_bf0438 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_3 41 := by
  simpa only [linear_v87_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g231 linear_b91 7 34 linear_bf0160 linear_bf0437)
#print axioms HiaCoreSyntaxSlice.linear_bf0438
theorem linear_bf0439 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_2 256 := by
  simpa only [linear_v87_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g228 ++ linear_b90) (44 :: linear_v87_3) 214 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g228 linear_b90 9 205 linear_bf0158 linear_bf0436) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_3 41 (by decide +kernel) linear_bf0438))
#print axioms HiaCoreSyntaxSlice.linear_bf0439
theorem linear_bf0440 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_1 418 := by
  simpa only [linear_v87_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g225 ++ linear_b89) (44 :: linear_v87_2) 161 257 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g225 linear_b89 6 155 linear_bf0156 linear_bf0435) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_2 256 (by decide +kernel) linear_bf0439))
#print axioms HiaCoreSyntaxSlice.linear_bf0440
theorem linear_bf0441 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_0 435 := by
  simpa only [linear_v87_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g222 ++ linear_b88) (44 :: linear_v87_1) 16 419 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g222 linear_b88 5 11 linear_bf0154 linear_bf0434) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_1 418 (by decide +kernel) linear_bf0440))
#print axioms HiaCoreSyntaxSlice.linear_bf0441
theorem linear_bf0442 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b87 437 := by
  simpa only [linear_b87] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g221 (linear_v87_0 ++ linear_g233) 1 436 linear_bf0153 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v87_0 linear_g233 435 1 linear_bf0441 linear_bf0162))
#print axioms HiaCoreSyntaxSlice.linear_bf0442
theorem linear_bf0443 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b93 11 := by
  simpa only [linear_b93] using linear_bf0165
#print axioms HiaCoreSyntaxSlice.linear_bf0443
theorem linear_bf0444 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b94 105 := by
  simpa only [linear_b94] using linear_bf0167
#print axioms HiaCoreSyntaxSlice.linear_bf0444
theorem linear_bf0445 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b95 175 := by
  simpa only [linear_b95] using linear_bf0169
#print axioms HiaCoreSyntaxSlice.linear_bf0445
theorem linear_bf0446 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b96 221 := by
  simpa only [linear_b96] using linear_bf0171
#print axioms HiaCoreSyntaxSlice.linear_bf0446
theorem linear_bf0447 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_3 228 := by
  simpa only [linear_v92_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g245 linear_b96 7 221 linear_bf0170 linear_bf0446)
#print axioms HiaCoreSyntaxSlice.linear_bf0447
theorem linear_bf0448 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_2 413 := by
  simpa only [linear_v92_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g242 ++ linear_b95) (44 :: linear_v92_3) 184 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g242 linear_b95 9 175 linear_bf0168 linear_bf0445) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_3 228 (by decide +kernel) linear_bf0447))
#print axioms HiaCoreSyntaxSlice.linear_bf0448
theorem linear_bf0449 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_1 525 := by
  simpa only [linear_v92_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g239 ++ linear_b94) (44 :: linear_v92_2) 111 414 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g239 linear_b94 6 105 linear_bf0166 linear_bf0444) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_2 413 (by decide +kernel) linear_bf0448))
#print axioms HiaCoreSyntaxSlice.linear_bf0449
theorem linear_bf0450 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_0 542 := by
  simpa only [linear_v92_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g236 ++ linear_b93) (44 :: linear_v92_1) 16 526 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g236 linear_b93 5 11 linear_bf0164 linear_bf0443) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_1 525 (by decide +kernel) linear_bf0449))
#print axioms HiaCoreSyntaxSlice.linear_bf0450
theorem linear_bf0451 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b92 544 := by
  simpa only [linear_b92] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g235 (linear_v92_0 ++ linear_g247) 1 543 linear_bf0163 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v92_0 linear_g247 542 1 linear_bf0450 linear_bf0172))
#print axioms HiaCoreSyntaxSlice.linear_bf0451
theorem linear_bf0452 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b98 11 := by
  simpa only [linear_b98] using linear_bf0175
#print axioms HiaCoreSyntaxSlice.linear_bf0452
theorem linear_bf0453 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b100 102 := by
  simpa only [linear_b100] using linear_bf0178
#print axioms HiaCoreSyntaxSlice.linear_bf0453
theorem linear_bf0454 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b101 104 := by
  simpa only [linear_b101] using linear_bf0179
#print axioms HiaCoreSyntaxSlice.linear_bf0454
theorem linear_bf0455 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b102 101 := by
  simpa only [linear_b102] using linear_bf0180
#print axioms HiaCoreSyntaxSlice.linear_bf0455
theorem linear_bf0456 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b103 101 := by
  simpa only [linear_b103] using linear_bf0181
#print axioms HiaCoreSyntaxSlice.linear_bf0456
theorem linear_bf0457 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b104 103 := by
  simpa only [linear_b104] using linear_bf0182
#print axioms HiaCoreSyntaxSlice.linear_bf0457
theorem linear_bf0458 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b105 101 := by
  simpa only [linear_b105] using linear_bf0183
#print axioms HiaCoreSyntaxSlice.linear_bf0458
theorem linear_bf0459 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b106 94 := by
  simpa only [linear_b106] using linear_bf0184
#print axioms HiaCoreSyntaxSlice.linear_bf0459
theorem linear_bf0460 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b107 83 := by
  simpa only [linear_b107] using linear_bf0185
#print axioms HiaCoreSyntaxSlice.linear_bf0460
theorem linear_bf0461 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b108 57 := by
  simpa only [linear_b108] using linear_bf0186
#print axioms HiaCoreSyntaxSlice.linear_bf0461
theorem linear_bf0462 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b109 87 := by
  simpa only [linear_b109] using linear_bf0187
#print axioms HiaCoreSyntaxSlice.linear_bf0462
theorem linear_bf0463 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b110 109 := by
  simpa only [linear_b110] using linear_bf0188
#print axioms HiaCoreSyntaxSlice.linear_bf0463
theorem linear_bf0464 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_10 109 := by
  simpa only [linear_v99_10] using linear_bf0463
#print axioms HiaCoreSyntaxSlice.linear_bf0464
theorem linear_bf0465 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_9 197 := by
  simpa only [linear_v99_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b109 (44 :: linear_v99_10) 87 110 linear_bf0462 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_10 109 (by decide +kernel) linear_bf0464))
#print axioms HiaCoreSyntaxSlice.linear_bf0465
theorem linear_bf0466 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_8 255 := by
  simpa only [linear_v99_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b108 (44 :: linear_v99_9) 57 198 linear_bf0461 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_9 197 (by decide +kernel) linear_bf0465))
#print axioms HiaCoreSyntaxSlice.linear_bf0466
theorem linear_bf0467 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_7 339 := by
  simpa only [linear_v99_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b107 (44 :: linear_v99_8) 83 256 linear_bf0460 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_8 255 (by decide +kernel) linear_bf0466))
#print axioms HiaCoreSyntaxSlice.linear_bf0467
theorem linear_bf0468 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_6 434 := by
  simpa only [linear_v99_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b106 (44 :: linear_v99_7) 94 340 linear_bf0459 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_7 339 (by decide +kernel) linear_bf0467))
#print axioms HiaCoreSyntaxSlice.linear_bf0468
theorem linear_bf0469 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_5 536 := by
  simpa only [linear_v99_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b105 (44 :: linear_v99_6) 101 435 linear_bf0458 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_6 434 (by decide +kernel) linear_bf0468))
#print axioms HiaCoreSyntaxSlice.linear_bf0469
theorem linear_bf0470 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_4 640 := by
  simpa only [linear_v99_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b104 (44 :: linear_v99_5) 103 537 linear_bf0457 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_5 536 (by decide +kernel) linear_bf0469))
#print axioms HiaCoreSyntaxSlice.linear_bf0470
theorem linear_bf0471 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_3 742 := by
  simpa only [linear_v99_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b103 (44 :: linear_v99_4) 101 641 linear_bf0456 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_4 640 (by decide +kernel) linear_bf0470))
#print axioms HiaCoreSyntaxSlice.linear_bf0471
theorem linear_bf0472 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_2 844 := by
  simpa only [linear_v99_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b102 (44 :: linear_v99_3) 101 743 linear_bf0455 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_3 742 (by decide +kernel) linear_bf0471))
#print axioms HiaCoreSyntaxSlice.linear_bf0472
theorem linear_bf0473 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_1 949 := by
  simpa only [linear_v99_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b101 (44 :: linear_v99_2) 104 845 linear_bf0454 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_2 844 (by decide +kernel) linear_bf0472))
#print axioms HiaCoreSyntaxSlice.linear_bf0473
theorem linear_bf0474 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_0 1052 := by
  simpa only [linear_v99_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b100 (44 :: linear_v99_1) 102 950 linear_bf0453 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_1 949 (by decide +kernel) linear_bf0473))
#print axioms HiaCoreSyntaxSlice.linear_bf0474
theorem linear_bf0475 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b99 1054 := by
  simpa only [linear_b99] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g254 (linear_v99_0 ++ linear_g276) 1 1053 linear_bf0177 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v99_0 linear_g276 1052 1 linear_bf0474 linear_bf0189))
#print axioms HiaCoreSyntaxSlice.linear_bf0475
theorem linear_bf0476 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b111 175 := by
  simpa only [linear_b111] using linear_bf0191
#print axioms HiaCoreSyntaxSlice.linear_bf0476
theorem linear_bf0477 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b112 98 := by
  simpa only [linear_b112] using linear_bf0193
#print axioms HiaCoreSyntaxSlice.linear_bf0477
theorem linear_bf0478 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_3 105 := by
  simpa only [linear_v97_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g281 linear_b112 7 98 linear_bf0192 linear_bf0477)
#print axioms HiaCoreSyntaxSlice.linear_bf0478
theorem linear_bf0479 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_2 290 := by
  simpa only [linear_v97_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g278 ++ linear_b111) (44 :: linear_v97_3) 184 106 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g278 linear_b111 9 175 linear_bf0190 linear_bf0476) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_3 105 (by decide +kernel) linear_bf0478))
#print axioms HiaCoreSyntaxSlice.linear_bf0479
theorem linear_bf0480 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_1 1351 := by
  simpa only [linear_v97_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g253 ++ linear_b99) (44 :: linear_v97_2) 1060 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g253 linear_b99 6 1054 linear_bf0176 linear_bf0475) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_2 290 (by decide +kernel) linear_bf0479))
#print axioms HiaCoreSyntaxSlice.linear_bf0480
theorem linear_bf0481 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_0 1368 := by
  simpa only [linear_v97_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g250 ++ linear_b98) (44 :: linear_v97_1) 16 1352 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g250 linear_b98 5 11 linear_bf0174 linear_bf0452) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_1 1351 (by decide +kernel) linear_bf0480))
#print axioms HiaCoreSyntaxSlice.linear_bf0481
theorem linear_bf0482 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b97 1370 := by
  simpa only [linear_b97] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g249 (linear_v97_0 ++ linear_g283) 1 1369 linear_bf0173 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v97_0 linear_g283 1368 1 linear_bf0481 linear_bf0194))
#print axioms HiaCoreSyntaxSlice.linear_bf0482
theorem linear_bf0483 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b114 11 := by
  simpa only [linear_b114] using linear_bf0197
#print axioms HiaCoreSyntaxSlice.linear_bf0483
theorem linear_bf0484 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b115 175 := by
  simpa only [linear_b115] using linear_bf0199
#print axioms HiaCoreSyntaxSlice.linear_bf0484
theorem linear_bf0485 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b116 175 := by
  simpa only [linear_b116] using linear_bf0201
#print axioms HiaCoreSyntaxSlice.linear_bf0485
theorem linear_bf0486 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b117 109 := by
  simpa only [linear_b117] using linear_bf0203
#print axioms HiaCoreSyntaxSlice.linear_bf0486
theorem linear_bf0487 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_3 116 := by
  simpa only [linear_v113_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g295 linear_b117 7 109 linear_bf0202 linear_bf0486)
#print axioms HiaCoreSyntaxSlice.linear_bf0487
theorem linear_bf0488 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_2 301 := by
  simpa only [linear_v113_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g292 ++ linear_b116) (44 :: linear_v113_3) 184 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g292 linear_b116 9 175 linear_bf0200 linear_bf0485) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_3 116 (by decide +kernel) linear_bf0487))
#print axioms HiaCoreSyntaxSlice.linear_bf0488
theorem linear_bf0489 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_1 483 := by
  simpa only [linear_v113_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g289 ++ linear_b115) (44 :: linear_v113_2) 181 302 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g289 linear_b115 6 175 linear_bf0198 linear_bf0484) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_2 301 (by decide +kernel) linear_bf0488))
#print axioms HiaCoreSyntaxSlice.linear_bf0489
theorem linear_bf0490 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_0 500 := by
  simpa only [linear_v113_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g286 ++ linear_b114) (44 :: linear_v113_1) 16 484 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g286 linear_b114 5 11 linear_bf0196 linear_bf0483) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_1 483 (by decide +kernel) linear_bf0489))
#print axioms HiaCoreSyntaxSlice.linear_bf0490
theorem linear_bf0491 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b113 502 := by
  simpa only [linear_b113] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g285 (linear_v113_0 ++ linear_g297) 1 501 linear_bf0195 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v113_0 linear_g297 500 1 linear_bf0490 linear_bf0204))
#print axioms HiaCoreSyntaxSlice.linear_bf0491
theorem linear_bf0492 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b119 11 := by
  simpa only [linear_b119] using linear_bf0207
#print axioms HiaCoreSyntaxSlice.linear_bf0492
theorem linear_bf0493 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b120 105 := by
  simpa only [linear_b120] using linear_bf0209
#print axioms HiaCoreSyntaxSlice.linear_bf0493
theorem linear_bf0494 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b121 208 := by
  simpa only [linear_b121] using linear_bf0211
#print axioms HiaCoreSyntaxSlice.linear_bf0494
theorem linear_bf0495 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b122 243 := by
  simpa only [linear_b122] using linear_bf0213
#print axioms HiaCoreSyntaxSlice.linear_bf0495
theorem linear_bf0496 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_3 250 := by
  simpa only [linear_v118_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g309 linear_b122 7 243 linear_bf0212 linear_bf0495)
#print axioms HiaCoreSyntaxSlice.linear_bf0496
theorem linear_bf0497 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_2 468 := by
  simpa only [linear_v118_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g306 ++ linear_b121) (44 :: linear_v118_3) 217 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g306 linear_b121 9 208 linear_bf0210 linear_bf0494) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_3 250 (by decide +kernel) linear_bf0496))
#print axioms HiaCoreSyntaxSlice.linear_bf0497
theorem linear_bf0498 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_1 580 := by
  simpa only [linear_v118_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g303 ++ linear_b120) (44 :: linear_v118_2) 111 469 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g303 linear_b120 6 105 linear_bf0208 linear_bf0493) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_2 468 (by decide +kernel) linear_bf0497))
#print axioms HiaCoreSyntaxSlice.linear_bf0498
theorem linear_bf0499 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_0 597 := by
  simpa only [linear_v118_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g300 ++ linear_b119) (44 :: linear_v118_1) 16 581 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g300 linear_b119 5 11 linear_bf0206 linear_bf0492) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_1 580 (by decide +kernel) linear_bf0498))
#print axioms HiaCoreSyntaxSlice.linear_bf0499
theorem linear_bf0500 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b118 599 := by
  simpa only [linear_b118] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g299 (linear_v118_0 ++ linear_g311) 1 598 linear_bf0205 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v118_0 linear_g311 597 1 linear_bf0499 linear_bf0214))
#print axioms HiaCoreSyntaxSlice.linear_bf0500
theorem linear_bf0501 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b124 11 := by
  simpa only [linear_b124] using linear_bf0217
#print axioms HiaCoreSyntaxSlice.linear_bf0501
theorem linear_bf0502 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b126 96 := by
  simpa only [linear_b126] using linear_bf0220
#print axioms HiaCoreSyntaxSlice.linear_bf0502
theorem linear_bf0503 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b127 102 := by
  simpa only [linear_b127] using linear_bf0221
#print axioms HiaCoreSyntaxSlice.linear_bf0503
theorem linear_bf0504 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b128 57 := by
  simpa only [linear_b128] using linear_bf0222
#print axioms HiaCoreSyntaxSlice.linear_bf0504
theorem linear_bf0505 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b129 102 := by
  simpa only [linear_b129] using linear_bf0223
#print axioms HiaCoreSyntaxSlice.linear_bf0505
theorem linear_bf0506 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b130 107 := by
  simpa only [linear_b130] using linear_bf0224
#print axioms HiaCoreSyntaxSlice.linear_bf0506
theorem linear_bf0507 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b131 87 := by
  simpa only [linear_b131] using linear_bf0225
#print axioms HiaCoreSyntaxSlice.linear_bf0507
theorem linear_bf0508 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b132 109 := by
  simpa only [linear_b132] using linear_bf0226
#print axioms HiaCoreSyntaxSlice.linear_bf0508
theorem linear_bf0509 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_6 109 := by
  simpa only [linear_v125_6] using linear_bf0508
#print axioms HiaCoreSyntaxSlice.linear_bf0509
theorem linear_bf0510 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_5 197 := by
  simpa only [linear_v125_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b131 (44 :: linear_v125_6) 87 110 linear_bf0507 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_6 109 (by decide +kernel) linear_bf0509))
#print axioms HiaCoreSyntaxSlice.linear_bf0510
theorem linear_bf0511 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_4 305 := by
  simpa only [linear_v125_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b130 (44 :: linear_v125_5) 107 198 linear_bf0506 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_5 197 (by decide +kernel) linear_bf0510))
#print axioms HiaCoreSyntaxSlice.linear_bf0511
theorem linear_bf0512 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_3 408 := by
  simpa only [linear_v125_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b129 (44 :: linear_v125_4) 102 306 linear_bf0505 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_4 305 (by decide +kernel) linear_bf0511))
#print axioms HiaCoreSyntaxSlice.linear_bf0512
theorem linear_bf0513 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_2 466 := by
  simpa only [linear_v125_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b128 (44 :: linear_v125_3) 57 409 linear_bf0504 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_3 408 (by decide +kernel) linear_bf0512))
#print axioms HiaCoreSyntaxSlice.linear_bf0513
theorem linear_bf0514 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_1 569 := by
  simpa only [linear_v125_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b127 (44 :: linear_v125_2) 102 467 linear_bf0503 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_2 466 (by decide +kernel) linear_bf0513))
#print axioms HiaCoreSyntaxSlice.linear_bf0514
theorem linear_bf0515 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_0 666 := by
  simpa only [linear_v125_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b126 (44 :: linear_v125_1) 96 570 linear_bf0502 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_1 569 (by decide +kernel) linear_bf0514))
#print axioms HiaCoreSyntaxSlice.linear_bf0515
theorem linear_bf0516 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b125 668 := by
  simpa only [linear_b125] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g318 (linear_v125_0 ++ linear_g332) 1 667 linear_bf0219 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v125_0 linear_g332 666 1 linear_bf0515 linear_bf0227))
#print axioms HiaCoreSyntaxSlice.linear_bf0516
theorem linear_bf0517 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b133 208 := by
  simpa only [linear_b133] using linear_bf0229
#print axioms HiaCoreSyntaxSlice.linear_bf0517
theorem linear_bf0518 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b134 109 := by
  simpa only [linear_b134] using linear_bf0231
#print axioms HiaCoreSyntaxSlice.linear_bf0518
theorem linear_bf0519 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_3 116 := by
  simpa only [linear_v123_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g337 linear_b134 7 109 linear_bf0230 linear_bf0518)
#print axioms HiaCoreSyntaxSlice.linear_bf0519
theorem linear_bf0520 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_2 334 := by
  simpa only [linear_v123_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g334 ++ linear_b133) (44 :: linear_v123_3) 217 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g334 linear_b133 9 208 linear_bf0228 linear_bf0517) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_3 116 (by decide +kernel) linear_bf0519))
#print axioms HiaCoreSyntaxSlice.linear_bf0520
theorem linear_bf0521 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_1 1009 := by
  simpa only [linear_v123_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g317 ++ linear_b125) (44 :: linear_v123_2) 674 335 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g317 linear_b125 6 668 linear_bf0218 linear_bf0516) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_2 334 (by decide +kernel) linear_bf0520))
#print axioms HiaCoreSyntaxSlice.linear_bf0521
theorem linear_bf0522 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_0 1026 := by
  simpa only [linear_v123_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g314 ++ linear_b124) (44 :: linear_v123_1) 16 1010 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g314 linear_b124 5 11 linear_bf0216 linear_bf0501) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_1 1009 (by decide +kernel) linear_bf0521))
#print axioms HiaCoreSyntaxSlice.linear_bf0522
theorem linear_bf0523 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b123 1028 := by
  simpa only [linear_b123] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g313 (linear_v123_0 ++ linear_g339) 1 1027 linear_bf0215 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v123_0 linear_g339 1026 1 linear_bf0522 linear_bf0232))
#print axioms HiaCoreSyntaxSlice.linear_bf0523
theorem linear_bf0524 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b136 11 := by
  simpa only [linear_b136] using linear_bf0235
#print axioms HiaCoreSyntaxSlice.linear_bf0524
theorem linear_bf0525 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b137 156 := by
  simpa only [linear_b137] using linear_bf0237
#print axioms HiaCoreSyntaxSlice.linear_bf0525
theorem linear_bf0526 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b138 208 := by
  simpa only [linear_b138] using linear_bf0239
#print axioms HiaCoreSyntaxSlice.linear_bf0526
theorem linear_bf0527 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b139 34 := by
  simpa only [linear_b139] using linear_bf0241
#print axioms HiaCoreSyntaxSlice.linear_bf0527
theorem linear_bf0528 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_3 41 := by
  simpa only [linear_v135_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g351 linear_b139 7 34 linear_bf0240 linear_bf0527)
#print axioms HiaCoreSyntaxSlice.linear_bf0528
theorem linear_bf0529 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_2 259 := by
  simpa only [linear_v135_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g348 ++ linear_b138) (44 :: linear_v135_3) 217 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g348 linear_b138 9 208 linear_bf0238 linear_bf0526) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_3 41 (by decide +kernel) linear_bf0528))
#print axioms HiaCoreSyntaxSlice.linear_bf0529
theorem linear_bf0530 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_1 422 := by
  simpa only [linear_v135_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g345 ++ linear_b137) (44 :: linear_v135_2) 162 260 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g345 linear_b137 6 156 linear_bf0236 linear_bf0525) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_2 259 (by decide +kernel) linear_bf0529))
#print axioms HiaCoreSyntaxSlice.linear_bf0530
theorem linear_bf0531 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_0 439 := by
  simpa only [linear_v135_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g342 ++ linear_b136) (44 :: linear_v135_1) 16 423 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g342 linear_b136 5 11 linear_bf0234 linear_bf0524) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_1 422 (by decide +kernel) linear_bf0530))
#print axioms HiaCoreSyntaxSlice.linear_bf0531
theorem linear_bf0532 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b135 441 := by
  simpa only [linear_b135] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g341 (linear_v135_0 ++ linear_g353) 1 440 linear_bf0233 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v135_0 linear_g353 439 1 linear_bf0531 linear_bf0242))
#print axioms HiaCoreSyntaxSlice.linear_bf0532
theorem linear_bf0533 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b141 12 := by
  simpa only [linear_b141] using linear_bf0245
#print axioms HiaCoreSyntaxSlice.linear_bf0533
theorem linear_bf0534 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b142 209 := by
  simpa only [linear_b142] using linear_bf0247
#print axioms HiaCoreSyntaxSlice.linear_bf0534
theorem linear_bf0535 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b143 210 := by
  simpa only [linear_b143] using linear_bf0249
#print axioms HiaCoreSyntaxSlice.linear_bf0535
theorem linear_bf0536 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b144 221 := by
  simpa only [linear_b144] using linear_bf0251
#print axioms HiaCoreSyntaxSlice.linear_bf0536
theorem linear_bf0537 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_3 228 := by
  simpa only [linear_v140_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g365 linear_b144 7 221 linear_bf0250 linear_bf0536)
#print axioms HiaCoreSyntaxSlice.linear_bf0537
theorem linear_bf0538 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_2 448 := by
  simpa only [linear_v140_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g362 ++ linear_b143) (44 :: linear_v140_3) 219 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g362 linear_b143 9 210 linear_bf0248 linear_bf0535) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_3 228 (by decide +kernel) linear_bf0537))
#print axioms HiaCoreSyntaxSlice.linear_bf0538
theorem linear_bf0539 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_1 664 := by
  simpa only [linear_v140_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g359 ++ linear_b142) (44 :: linear_v140_2) 215 449 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g359 linear_b142 6 209 linear_bf0246 linear_bf0534) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_2 448 (by decide +kernel) linear_bf0538))
#print axioms HiaCoreSyntaxSlice.linear_bf0539
theorem linear_bf0540 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_0 682 := by
  simpa only [linear_v140_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g356 ++ linear_b141) (44 :: linear_v140_1) 17 665 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g356 linear_b141 5 12 linear_bf0244 linear_bf0533) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_1 664 (by decide +kernel) linear_bf0539))
#print axioms HiaCoreSyntaxSlice.linear_bf0540
theorem linear_bf0541 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b140 684 := by
  simpa only [linear_b140] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g355 (linear_v140_0 ++ linear_g367) 1 683 linear_bf0243 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v140_0 linear_g367 682 1 linear_bf0540 linear_bf0252))
#print axioms HiaCoreSyntaxSlice.linear_bf0541
theorem linear_bf0542 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b146 12 := by
  simpa only [linear_b146] using linear_bf0255
#print axioms HiaCoreSyntaxSlice.linear_bf0542
theorem linear_bf0543 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b147 209 := by
  simpa only [linear_b147] using linear_bf0257
#print axioms HiaCoreSyntaxSlice.linear_bf0543
theorem linear_bf0544 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b148 243 := by
  simpa only [linear_b148] using linear_bf0259
#print axioms HiaCoreSyntaxSlice.linear_bf0544
theorem linear_bf0545 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b149 243 := by
  simpa only [linear_b149] using linear_bf0261
#print axioms HiaCoreSyntaxSlice.linear_bf0545
theorem linear_bf0546 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_3 250 := by
  simpa only [linear_v145_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g379 linear_b149 7 243 linear_bf0260 linear_bf0545)
#print axioms HiaCoreSyntaxSlice.linear_bf0546
theorem linear_bf0547 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_2 503 := by
  simpa only [linear_v145_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g376 ++ linear_b148) (44 :: linear_v145_3) 252 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g376 linear_b148 9 243 linear_bf0258 linear_bf0544) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_3 250 (by decide +kernel) linear_bf0546))
#print axioms HiaCoreSyntaxSlice.linear_bf0547
theorem linear_bf0548 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_1 719 := by
  simpa only [linear_v145_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g373 ++ linear_b147) (44 :: linear_v145_2) 215 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g373 linear_b147 6 209 linear_bf0256 linear_bf0543) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_2 503 (by decide +kernel) linear_bf0547))
#print axioms HiaCoreSyntaxSlice.linear_bf0548
theorem linear_bf0549 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_0 737 := by
  simpa only [linear_v145_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g370 ++ linear_b146) (44 :: linear_v145_1) 17 720 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g370 linear_b146 5 12 linear_bf0254 linear_bf0542) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_1 719 (by decide +kernel) linear_bf0548))
#print axioms HiaCoreSyntaxSlice.linear_bf0549
theorem linear_bf0550 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b145 739 := by
  simpa only [linear_b145] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g369 (linear_v145_0 ++ linear_g381) 1 738 linear_bf0253 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v145_0 linear_g381 737 1 linear_bf0549 linear_bf0262))
#print axioms HiaCoreSyntaxSlice.linear_bf0550
theorem linear_bf0551 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_20 739 := by
  simpa only [linear_v4_20] using linear_bf0550
#print axioms HiaCoreSyntaxSlice.linear_bf0551
theorem linear_bf0552 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_19 1424 := by
  simpa only [linear_v4_19] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b140 (44 :: linear_v4_20) 684 740 linear_bf0541 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_20 739 (by decide +kernel) linear_bf0551))
#print axioms HiaCoreSyntaxSlice.linear_bf0552
theorem linear_bf0553 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_18 1866 := by
  simpa only [linear_v4_18] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b135 (44 :: linear_v4_19) 441 1425 linear_bf0532 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_19 1424 (by decide +kernel) linear_bf0552))
#print axioms HiaCoreSyntaxSlice.linear_bf0553
theorem linear_bf0554 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_17 2895 := by
  simpa only [linear_v4_17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b123 (44 :: linear_v4_18) 1028 1867 linear_bf0523 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_18 1866 (by decide +kernel) linear_bf0553))
#print axioms HiaCoreSyntaxSlice.linear_bf0554
theorem linear_bf0555 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_16 3495 := by
  simpa only [linear_v4_16] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b118 (44 :: linear_v4_17) 599 2896 linear_bf0500 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_17 2895 (by decide +kernel) linear_bf0554))
#print axioms HiaCoreSyntaxSlice.linear_bf0555
theorem linear_bf0556 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_15 3998 := by
  simpa only [linear_v4_15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b113 (44 :: linear_v4_16) 502 3496 linear_bf0491 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_16 3495 (by decide +kernel) linear_bf0555))
#print axioms HiaCoreSyntaxSlice.linear_bf0556
theorem linear_bf0557 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_14 5369 := by
  simpa only [linear_v4_14] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b97 (44 :: linear_v4_15) 1370 3999 linear_bf0482 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_15 3998 (by decide +kernel) linear_bf0556))
#print axioms HiaCoreSyntaxSlice.linear_bf0557
theorem linear_bf0558 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_13 5914 := by
  simpa only [linear_v4_13] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b92 (44 :: linear_v4_14) 544 5370 linear_bf0451 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_14 5369 (by decide +kernel) linear_bf0557))
#print axioms HiaCoreSyntaxSlice.linear_bf0558
theorem linear_bf0559 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_12 6352 := by
  simpa only [linear_v4_12] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b87 (44 :: linear_v4_13) 437 5915 linear_bf0442 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_13 5914 (by decide +kernel) linear_bf0558))
#print axioms HiaCoreSyntaxSlice.linear_bf0559
theorem linear_bf0560 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_11 7348 := by
  simpa only [linear_v4_11] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b75 (44 :: linear_v4_12) 995 6353 linear_bf0433 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_12 6352 (by decide +kernel) linear_bf0559))
#print axioms HiaCoreSyntaxSlice.linear_bf0560
theorem linear_bf0561 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_10 7926 := by
  simpa only [linear_v4_10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b70 (44 :: linear_v4_11) 577 7349 linear_bf0410 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_11 7348 (by decide +kernel) linear_bf0560))
#print axioms HiaCoreSyntaxSlice.linear_bf0561
theorem linear_bf0562 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_9 8416 := by
  simpa only [linear_v4_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b65 (44 :: linear_v4_10) 489 7927 linear_bf0401 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_10 7926 (by decide +kernel) linear_bf0561))
#print axioms HiaCoreSyntaxSlice.linear_bf0562
theorem linear_bf0563 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_8 9750 := by
  simpa only [linear_v4_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b49 (44 :: linear_v4_9) 1333 8417 linear_bf0392 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_9 8416 (by decide +kernel) linear_bf0562))
#print axioms HiaCoreSyntaxSlice.linear_bf0563
theorem linear_bf0564 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_7 10276 := by
  simpa only [linear_v4_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b44 (44 :: linear_v4_8) 525 9751 linear_bf0361 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_8 9750 (by decide +kernel) linear_bf0563))
#print axioms HiaCoreSyntaxSlice.linear_bf0564
theorem linear_bf0565 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_6 10744 := by
  simpa only [linear_v4_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b39 (44 :: linear_v4_7) 467 10277 linear_bf0352 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_7 10276 (by decide +kernel) linear_bf0564))
#print axioms HiaCoreSyntaxSlice.linear_bf0565
theorem linear_bf0566 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_5 11381 := by
  simpa only [linear_v4_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b34 (44 :: linear_v4_6) 636 10745 linear_bf0343 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_6 10744 (by decide +kernel) linear_bf0565))
#print axioms HiaCoreSyntaxSlice.linear_bf0566
theorem linear_bf0567 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_4 11919 := by
  simpa only [linear_v4_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b29 (44 :: linear_v4_5) 537 11382 linear_bf0334 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_5 11381 (by decide +kernel) linear_bf0566))
#print axioms HiaCoreSyntaxSlice.linear_bf0567
theorem linear_bf0568 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_3 12504 := by
  simpa only [linear_v4_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b24 (44 :: linear_v4_4) 584 11920 linear_bf0325 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_4 11919 (by decide +kernel) linear_bf0567))
#print axioms HiaCoreSyntaxSlice.linear_bf0568
theorem linear_bf0569 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_2 13137 := by
  simpa only [linear_v4_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b15 (44 :: linear_v4_3) 632 12505 linear_bf0316 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_3 12504 (by decide +kernel) linear_bf0568))
#print axioms HiaCoreSyntaxSlice.linear_bf0569
theorem linear_bf0570 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_1 13656 := by
  simpa only [linear_v4_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b10 (44 :: linear_v4_2) 518 13138 linear_bf0299 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_2 13137 (by decide +kernel) linear_bf0569))
#print axioms HiaCoreSyntaxSlice.linear_bf0570
theorem linear_bf0571 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_0 14181 := by
  simpa only [linear_v4_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b5 (44 :: linear_v4_1) 524 13657 linear_bf0290 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_1 13656 (by decide +kernel) linear_bf0570))
#print axioms HiaCoreSyntaxSlice.linear_bf0571
theorem linear_bf0572 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b4 14183 := by
  simpa only [linear_b4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g8 (linear_v4_0 ++ linear_g382) 1 14182 linear_bf0007 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v4_0 linear_g382 14181 1 linear_bf0571 linear_bf0263))
#print axioms HiaCoreSyntaxSlice.linear_bf0572
theorem linear_bf0573 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b150 31 := by
  simpa only [linear_b150] using linear_bf0265
#print axioms HiaCoreSyntaxSlice.linear_bf0573
theorem linear_bf0574 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b151 13 := by
  simpa only [linear_b151] using linear_bf0267
#print axioms HiaCoreSyntaxSlice.linear_bf0574
theorem linear_bf0575 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b152 11 := by
  simpa only [linear_b152] using linear_bf0269
#print axioms HiaCoreSyntaxSlice.linear_bf0575
theorem linear_bf0576 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b153 61 := by
  simpa only [linear_b153] using linear_bf0271
#print axioms HiaCoreSyntaxSlice.linear_bf0576
theorem linear_bf0577 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b154 7 := by
  simpa only [linear_b154] using linear_bf0273
#print axioms HiaCoreSyntaxSlice.linear_bf0577
theorem linear_bf0578 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_5 17 := by
  simpa only [linear_v3_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g396 linear_b154 10 7 linear_bf0272 linear_bf0577)
#print axioms HiaCoreSyntaxSlice.linear_bf0578
theorem linear_bf0579 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_4 88 := by
  simpa only [linear_v3_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g393 ++ linear_b153) (44 :: linear_v3_5) 70 18 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g393 linear_b153 9 61 linear_bf0270 linear_bf0576) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_5 17 (by decide +kernel) linear_bf0578))
#print axioms HiaCoreSyntaxSlice.linear_bf0579
theorem linear_bf0580 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_3 107 := by
  simpa only [linear_v3_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g390 ++ linear_b152) (44 :: linear_v3_4) 18 89 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g390 linear_b152 7 11 linear_bf0268 linear_bf0575) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_4 88 (by decide +kernel) linear_bf0579))
#print axioms HiaCoreSyntaxSlice.linear_bf0580
theorem linear_bf0581 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_2 129 := by
  simpa only [linear_v3_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g387 ++ linear_b151) (44 :: linear_v3_3) 21 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g387 linear_b151 8 13 linear_bf0266 linear_bf0574) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_3 107 (by decide +kernel) linear_bf0580))
#print axioms HiaCoreSyntaxSlice.linear_bf0581
theorem linear_bf0582 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_1 171 := by
  simpa only [linear_v3_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g384 ++ linear_b150) (44 :: linear_v3_2) 41 130 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g384 linear_b150 10 31 linear_bf0264 linear_bf0573) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_2 129 (by decide +kernel) linear_bf0581))
#print axioms HiaCoreSyntaxSlice.linear_bf0582
theorem linear_bf0583 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_0 14364 := by
  simpa only [linear_v3_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g7 ++ linear_b4) (44 :: linear_v3_1) 14192 172 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g7 linear_b4 9 14183 linear_bf0006 linear_bf0572) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_1 171 (by decide +kernel) linear_bf0582))
#print axioms HiaCoreSyntaxSlice.linear_bf0583
theorem linear_bf0584 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b3 14366 := by
  simpa only [linear_b3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g6 (linear_v3_0 ++ linear_g398) 1 14365 linear_bf0005 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v3_0 linear_g398 14364 1 linear_bf0583 linear_bf0274))
#print axioms HiaCoreSyntaxSlice.linear_bf0584
theorem linear_bf0585 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v2_0 14366 := by
  simpa only [linear_v2_0] using linear_bf0584
#print axioms HiaCoreSyntaxSlice.linear_bf0585
theorem linear_bf0586 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b2 14368 := by
  simpa only [linear_b2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g5 (linear_v2_0 ++ linear_g399) 1 14367 linear_bf0004 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v2_0 linear_g399 14366 1 linear_bf0585 linear_bf0275))
#print axioms HiaCoreSyntaxSlice.linear_bf0586
theorem linear_bf0587 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b155 18 := by
  simpa only [linear_b155] using linear_bf0277
#print axioms HiaCoreSyntaxSlice.linear_bf0587
theorem linear_bf0588 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b156 22 := by
  simpa only [linear_b156] using linear_bf0279
#print axioms HiaCoreSyntaxSlice.linear_bf0588
theorem linear_bf0589 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_3 31 := by
  simpa only [linear_v0_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g404 linear_b156 9 22 linear_bf0278 linear_bf0588)
#print axioms HiaCoreSyntaxSlice.linear_bf0589
theorem linear_bf0590 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_2 59 := by
  simpa only [linear_v0_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g401 ++ linear_b155) (44 :: linear_v0_3) 27 32 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g401 linear_b155 9 18 linear_bf0276 linear_bf0587) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_3 31 (by decide +kernel) linear_bf0589))
#print axioms HiaCoreSyntaxSlice.linear_bf0590
theorem linear_bf0591 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_1 14440 := by
  simpa only [linear_v0_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g4 ++ linear_b2) (44 :: linear_v0_2) 14380 60 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g4 linear_b2 12 14368 linear_bf0003 linear_bf0586) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_2 59 (by decide +kernel) linear_bf0590))
#print axioms HiaCoreSyntaxSlice.linear_bf0591
theorem linear_bf0592 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_0 14464 := by
  simpa only [linear_v0_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g1 ++ linear_b1) (44 :: linear_v0_1) 23 14441 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g1 linear_b1 10 13 linear_bf0001 linear_bf0281) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_1 14440 (by decide +kernel) linear_bf0591))
#print axioms HiaCoreSyntaxSlice.linear_bf0592
theorem linear_bf0593 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b0 14466 := by
  simpa only [linear_b0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g0 (linear_v0_0 ++ linear_g406) 1 14465 linear_bf0000 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v0_0 linear_g406 14464 1 linear_bf0592 linear_bf0280))
#print axioms HiaCoreSyntaxSlice.linear_bf0593
theorem linear_bf0594 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linearBytes 14466 := by
  simpa only [linearBytes] using linear_bf0593
#print axioms HiaCoreSyntaxSlice.linear_bf0594
end HiaCoreSyntaxSlice
