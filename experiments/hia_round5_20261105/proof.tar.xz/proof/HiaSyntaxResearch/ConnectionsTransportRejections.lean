import HiaSyntaxResearch.CertPart07
-- SEVEN_CERTIFICATE_CONNECTIONS_V1

namespace HiaCoreSyntaxSlice

open HiaGuardedUsizeSlice

/-- Names are exact ASCII byte sequences, never hashes or normalized names. -/
def ascii (s : String) : List Nat := s.toList.map Char.toNat

def field (raw : Raw) (key : String) : Raw :=
  match raw with
  | .obj fields => ((fields.find? (fun pair => pair.1 == ascii key)).map Prod.snd).getD (.obj [])
  | _ => .obj []

def array (raw : Raw) : List Raw :=
  match raw with
  | .arr items => items
  | _ => []

def bytes (raw : Raw) : List Nat :=
  match raw with
  | .str value => value
  | _ => []

def number (raw : Raw) : Nat :=
  match raw with
  | .num value => value
  | _ => 0

def isString : Raw → Bool
  | .str _ => true
  | _ => false

def isObject : Raw → Bool
  | .obj _ => true
  | _ => false

def isArray : Raw → Bool
  | .arr _ => true
  | _ => false

def keysAre (raw : Raw) (keys : List String) : Bool :=
  match raw with
  | .obj fields => decide (fields.map Prod.fst = keys.map ascii)
  | _ => false

def rawAt (items : List Raw) (index : Nat) : Raw := items[index]?.getD (.obj [])

def position (name : List Nat) : List (List Nat) → Nat
  | [] => 0
  | first :: rest => if name = first then 0 else position name rest + 1

def names (items : List Raw) : List (List Nat) :=
  items.map (fun item => bytes (field item "name"))

def goodParam (raw : Raw) : Bool :=
  keysAre raw ["name", "type"] && isString (field raw "name") &&
    isString (field raw "type")

def goodParams (raw : Raw) : Bool :=
  isArray raw && (array raw).all goodParam

def goodStrings (raw : Raw) : Bool :=
  isArray raw && (array raw).all isString

def goodOp (raw : Raw) : Bool :=
  keysAre raw ["args", "attrs", "op", "out"] &&
    goodStrings (field raw "args") && isObject (field raw "attrs") &&
    isString (field raw "op") && goodParams (field raw "out")

def blockBinders (raw : Raw) : List Raw :=
  array (field raw "params") ++
    (array (field raw "ops")).flatMap (fun op => array (field op "out"))

/-- Unknown operations remain inert syntax. Their envelope and binders, not
    their execution behavior, are checked. -/
def goodBlock (raw : Raw) : Bool :=
  keysAre raw ["id", "ops", "params", "term"] &&
    isString (field raw "id") && goodParams (field raw "params") &&
    isArray (field raw "ops") && (array (field raw "ops")).all goodOp &&
    isObject (field raw "term") &&
    decide ((names (blockBinders raw)).Nodup) -- MUTATION_SITE_BINDER_UNIQUENESS

def goodFunction (raw : Raw) : Bool :=
  keysAre raw ["blocks", "effects", "entry", "name", "params", "returns"] &&
    isString (field raw "name") && isString (field raw "entry") &&
    goodStrings (field raw "effects") && goodParams (field raw "params") &&
    decide ((names (array (field raw "params"))).Nodup) &&
    goodStrings (field raw "returns") && isArray (field raw "blocks") &&
    decide ((array (field raw "blocks")).length ≤ 128) &&
    (array (field raw "blocks")).all goodBlock &&
    decide (((array (field raw "blocks")).map (fun b => bytes (field b "id"))).Nodup)

def goodProgram (raw : Raw) : Bool :=
  keysAre raw ["exports", "functions", "module", "schema"] &&
    goodStrings (field raw "exports") && isString (field raw "module") &&
    decide (field raw "schema" = .str (ascii "hepta.hia.program.v1")) &&
    isArray (field raw "functions") &&
    (array (field raw "functions")).all goodFunction &&
    decide ((names (array (field raw "functions"))).Nodup)

structure Hint where
  functionIndex : Nat
  headerIndex : Nat
  targetIndex : Nat
  addOrdinal : Nat
  bodyIndex : List Nat
  bodyExtent : List Nat
  deriving DecidableEq, Repr

abbrev Locator := Hint

def selectedFunction (raw : Raw) (hint : Hint) : Raw :=
  rawAt (array (field raw "functions")) hint.functionIndex

def selectedHeader (raw : Raw) (hint : Hint) : Raw :=
  rawAt (array (field (selectedFunction raw hint) "blocks")) hint.headerIndex

def selectedTarget (raw : Raw) (hint : Hint) : Raw :=
  rawAt (array (field (selectedFunction raw hint) "blocks")) hint.targetIndex

def definitionOrdinal (name : List Nat) : List Raw → Nat
  | [] => 0
  | op :: rest =>
    if name ∈ names (array (field op "out")) then 0
    else definitionOrdinal name rest + 1

def addTag (raw : Raw) : AddOp :=
  if raw = .str (ascii "int.add.checked") then .checked
  else if raw = .str (ascii "int.add.wrap") then .wrapping else .other

/-- This proposal function reads syntax, not an expected descriptor. Its defaults
    are rejected by the independent relation's shape, bounds and scope checks. -/
def reconstruct (raw : Raw) (hint : Hint) : Descriptor :=
  let header := selectedHeader raw hint
  let target := selectedTarget raw hint
  let compare := rawAt (array (field header "ops")) 0
  let sourceNames := names (blockBinders header)
  let compareArgs := (array (field compare "args")).map bytes
  let edge := field (field header "term") "then" -- MUTATION_SITE_SELECT_THEN
  let targetParams := array (field target "params")
  let targetNames := names targetParams
  let ops := array (field target "ops")
  let add := rawAt ops hint.addOrdinal
  let args := (array (field add "args")).map bytes
  let literalOrdinal := definitionOrdinal (args[1]?.getD []) ops
  let literal := rawAt ops literalOrdinal
  { sourceIndex := position (compareArgs[0]?.getD []) sourceNames -- MUTATION_SITE_SOURCE_POSITION
    sourceExtent := position (compareArgs[1]?.getD []) sourceNames
    compareOutput := position (bytes (field (rawAt (array (field compare "out")) 0) "name")) sourceNames
    branchCondition := position (bytes (field (field header "term") "cond")) sourceNames
    indexType := if field (rawAt (blockBinders header) (position (compareArgs[0]?.getD []) sourceNames)) "type" = .str (ascii "usize") then .usize else .other
    extentType := if field (rawAt (blockBinders header) (position (compareArgs[1]?.getD []) sourceNames)) "type" = .str (ascii "usize") then .usize else .other
    compareOp := if field compare "op" = .str (ascii "compare.lt") then .lt else .other
    selectedArm := .thenArm
    incoming := (array (field edge "args")).map (fun arg => position (bytes arg) sourceNames)
    indexSlot := position hint.bodyIndex targetNames
    extentSlot := position hint.bodyExtent targetNames
    addIndexSlot := position (args[0]?.getD []) targetNames
    addOp := addTag (field add "op")
    addType := if field (rawAt (array (field add "out")) 0) "type" = .str (ascii "usize") then .usize else .other
    literalType := if field (rawAt (array (field literal "out")) 0) "type" = .str (ascii "usize") then .usize else .other
    literalValue := number (field (field literal "attrs") "value")
    literalOrdinal := literalOrdinal
    addOrdinal := hint.addOrdinal }

/-- Declarative raw syntax contract, independent of `extract` and `reconstruct`.
    Every ordered edge argument is retained, including opaque/resource values.
    No condition below claims normal arrival through the target body. -/
def SliceSyntaxRelation (raw : Raw) (hint : Hint) (d : Descriptor) : Prop :=
  let functions := array (field raw "functions")
  let fn := rawAt functions hint.functionIndex
  let blocks := array (field fn "blocks")
  let header := rawAt blocks hint.headerIndex
  let target := rawAt blocks hint.targetIndex
  let headerParams := array (field header "params")
  let compare := rawAt (array (field header "ops")) 0
  let sourceBinders := blockBinders header
  let sourceNames := names sourceBinders
  let targetParams := array (field target "params")
  let targetNames := names targetParams
  let term := field header "term"
  let thenEdge := field term "then"
  let elseEdge := field term "else"
  let edgeArgs := array (field thenEdge "args")
  let ops := array (field target "ops")
  let add := rawAt ops d.addOrdinal
  let literal := rawAt ops d.literalOrdinal
  withinBounds raw = true ∧
  goodProgram raw = true ∧
  hint.functionIndex < functions.length ∧
  hint.headerIndex < blocks.length ∧ hint.targetIndex < blocks.length ∧
  array (field header "ops") = [compare] ∧
  field compare "op" = .str (ascii "compare.lt") ∧
  field compare "attrs" = .obj [] ∧
  field compare "args" = .arr [.str (sourceNames[d.sourceIndex]?.getD []),
    .str (sourceNames[d.sourceExtent]?.getD [])] ∧
  d.sourceIndex < headerParams.length ∧ d.sourceExtent < headerParams.length ∧
  field (rawAt sourceBinders d.sourceIndex) "type" = .str (ascii "usize") ∧
  field (rawAt sourceBinders d.sourceExtent) "type" = .str (ascii "usize") ∧
  d.compareOutput = headerParams.length ∧
  field compare "out" = .arr [.obj [(ascii "name", .str (sourceNames[d.compareOutput]?.getD [])),
    (ascii "type", .str (ascii "bool"))]] ∧
  keysAre term ["cond", "else", "op", "then"] = true ∧
  field term "op" = .str (ascii "branch") ∧
  field term "cond" = .str (sourceNames[d.compareOutput]?.getD []) ∧
  keysAre thenEdge ["args", "target"] = true ∧
  keysAre elseEdge ["args", "target"] = true ∧
  goodStrings (field elseEdge "args") = true ∧ isString (field elseEdge "target") = true ∧
  field thenEdge "target" = field target "id" ∧
  goodStrings (field thenEdge "args") = true ∧
  edgeArgs.length = targetParams.length ∧
  d.incoming.length = edgeArgs.length ∧
  d.incoming.all (fun i => decide (i < sourceNames.length)) = true ∧
  edgeArgs = d.incoming.map (fun i => Raw.str (sourceNames[i]?.getD [])) ∧
  hint.bodyIndex ∈ targetNames ∧ hint.bodyExtent ∈ targetNames ∧
  targetNames[d.indexSlot]? = some hint.bodyIndex ∧
  targetNames[d.extentSlot]? = some hint.bodyExtent ∧
  field (rawAt targetParams d.indexSlot) "type" = .str (ascii "usize") ∧
  field (rawAt targetParams d.extentSlot) "type" = .str (ascii "usize") ∧
  d.incoming[d.indexSlot]? = some d.sourceIndex ∧
  d.incoming[d.extentSlot]? = some d.sourceExtent ∧
  d.addOrdinal = hint.addOrdinal ∧ d.addOrdinal < ops.length ∧
  d.literalOrdinal < d.addOrdinal ∧
  field add "args" = .arr [.str hint.bodyIndex,
    .str (bytes (field (rawAt (array (field literal "out")) 0) "name"))] ∧
  field add "attrs" = .obj [] ∧
  (field add "op" = .str (ascii "int.add.checked") ∧ d.addOp = .checked ∨
   field add "op" = .str (ascii "int.add.wrap") ∧ d.addOp = .wrapping) ∧
  (array (field add "out")).length = 1 ∧
  field (rawAt (array (field add "out")) 0) "type" = .str (ascii "usize") ∧
  field literal "op" = .str (ascii "const") ∧
  field literal "args" = .arr [] ∧
  field literal "attrs" = .obj [(ascii "value", .num 1)] ∧
  (array (field literal "out")).length = 1 ∧
  field (rawAt (array (field literal "out")) 0) "type" = .str (ascii "usize") ∧
  d.branchCondition = d.compareOutput ∧ d.indexType = .usize ∧ d.extentType = .usize ∧
  d.compareOp = .lt ∧ d.selectedArm = .thenArm ∧ d.addIndexSlot = d.indexSlot ∧
  d.addType = .usize ∧ d.literalType = .usize ∧ d.literalValue = 1

/-- Assemble small decisions without asking typeclass search to synthesize
    the entire structural contract in one recursive search. -/
def andDecision {p q : Prop} (left : Decidable p) (right : Decidable q) :
    Decidable (p ∧ q) :=
  match left, right with
  | isTrue hp, isTrue hq => isTrue ⟨hp, hq⟩
  | isFalse hp, _ => isFalse (fun both => hp both.1)
  | _, isFalse hq => isFalse (fun both => hq both.2)

instance (raw : Raw) (hint : Hint) (d : Descriptor) : Decidable (SliceSyntaxRelation raw hint d) := by
  dsimp only [SliceSyntaxRelation]
  exact
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    (by infer_instance))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

/-- Successful reconstruction requires the independently specified contract. -/
def extract (raw : Raw) (hint : Hint) : Option Descriptor :=
  let proposed := reconstruct raw hint
  if SliceSyntaxRelation raw hint proposed then some proposed else none

theorem extract_sound (raw : Raw) (hint : Hint) (d : Descriptor)
    (extracted : extract raw hint = some d) : SliceSyntaxRelation raw hint d := by
  by_cases accepted : SliceSyntaxRelation raw hint (reconstruct raw hint)
  · have same : reconstruct raw hint = d := by
      simpa [extract, accepted] using extracted
    rw [← same]
    exact accepted
  · simp [extract, accepted] at extracted

/-- Composition with the existing projection theorem. Exact byte binding and
    transport determinacy are separate certificate obligations. -/
theorem extracted_successor (raw : Raw) (hint : Hint) (d : Descriptor)
    (maximum : Nat) (env : Env)
    (extracted : extract raw hint = some d)
    (valid : Valid d) (guard : evalGuard maximum d env = some true) :
    SliceSyntaxRelation raw hint d ∧
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧
      evalSelectedStep maximum d env = some (index + 1) ∧
      index + 1 ≤ extent ∧ extent ≤ maximum ∧ index + 1 ≤ maximum := by
  exact ⟨extract_sound raw hint d extracted,
    selected_successor maximum d env valid guard⟩


end HiaCoreSyntaxSlice

namespace HiaCoreSyntaxSlice
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice

namespace HiaCoreSyntaxSlice
def parallelHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice

namespace HiaCoreSyntaxSlice.WrongPhi
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice.WrongPhi

namespace HiaCoreSyntaxSlice.LiteralTwo
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice.LiteralTwo

namespace HiaCoreSyntaxSlice.WrongCondition
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice.WrongCondition

namespace HiaCoreSyntaxSlice
theorem linear_extraction : extract linearRaw linearHint = some HiaGuardedUsizeSlice.linear_0 := by have tag {α : Type} (raw : Raw) (value : List Nat) (yes no : α) : (if raw = Raw.str value then yes else no) = (match raw with | .str actual => if actual = value then yes else no | _ => no) := (by cases raw <;> simp); have tagDecision (raw : Raw) (value : List Nat) : decide (raw = Raw.str value) = (match raw with | .str actual => decide (actual = value) | _ => false) := (by cases raw <;> simp); have reconstructed : reconstruct linearRaw linearHint = HiaGuardedUsizeSlice.linear_0 := (by simp only [reconstruct, addTag, tag]; decide +kernel); have shape : goodProgram linearRaw = true := (by simp only [goodProgram, tagDecision]; decide +kernel); have accepted : SliceSyntaxRelation linearRaw linearHint HiaGuardedUsizeSlice.linear_0 := (by dsimp only [SliceSyntaxRelation]; refine ⟨linear_bounds, shape, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩; all_goals first | rfl | (exact Or.inl ⟨rfl, rfl⟩) | (exact Or.inr ⟨rfl, rfl⟩) | decide +kernel); unfold extract; rw [reconstructed]; exact if_pos accepted
theorem linear_relation : SliceSyntaxRelation linearRaw linearHint HiaGuardedUsizeSlice.linear_0 :=
  extract_sound linearRaw linearHint HiaGuardedUsizeSlice.linear_0 linear_extraction
theorem parallel_extraction : extract parallelRaw parallelHint = some HiaGuardedUsizeSlice.linear_0 := by have tag {α : Type} (raw : Raw) (value : List Nat) (yes no : α) : (if raw = Raw.str value then yes else no) = (match raw with | .str actual => if actual = value then yes else no | _ => no) := (by cases raw <;> simp); have tagDecision (raw : Raw) (value : List Nat) : decide (raw = Raw.str value) = (match raw with | .str actual => decide (actual = value) | _ => false) := (by cases raw <;> simp); have reconstructed : reconstruct parallelRaw parallelHint = HiaGuardedUsizeSlice.linear_0 := (by simp only [reconstruct, addTag, tag]; decide +kernel); have shape : goodProgram parallelRaw = true := (by simp only [goodProgram, tagDecision]; decide +kernel); have accepted : SliceSyntaxRelation parallelRaw parallelHint HiaGuardedUsizeSlice.linear_0 := (by dsimp only [SliceSyntaxRelation]; refine ⟨parallel_bounds, shape, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩; all_goals first | rfl | (exact Or.inl ⟨rfl, rfl⟩) | (exact Or.inr ⟨rfl, rfl⟩) | decide +kernel); unfold extract; rw [reconstructed]; exact if_pos accepted
theorem reject_stale_descriptor : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.linearRaw HiaCoreSyntaxSlice.linearHint = some { HiaGuardedUsizeSlice.linear_0 with literalValue := 2 }) := by rw [linear_extraction]; decide +kernel
theorem reject_wrong_phi : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.WrongPhi.linearRaw HiaCoreSyntaxSlice.WrongPhi.linearHint = some HiaGuardedUsizeSlice.linear_0) := by intro success; have necessary := extract_sound WrongPhi.linearRaw WrongPhi.linearHint HiaGuardedUsizeSlice.linear_0 success; have impossible := necessary.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1; cases impossible
theorem reject_literal_two : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.LiteralTwo.linearRaw HiaCoreSyntaxSlice.LiteralTwo.linearHint = some HiaGuardedUsizeSlice.linear_0) := by intro success; have necessary := extract_sound LiteralTwo.linearRaw LiteralTwo.linearHint HiaGuardedUsizeSlice.linear_0 success; have impossible := necessary.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1; cases impossible
theorem reject_wrong_condition : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.WrongCondition.linearRaw HiaCoreSyntaxSlice.WrongCondition.linearHint = some HiaGuardedUsizeSlice.linear_0) := by intro success; have necessary := extract_sound WrongCondition.linearRaw WrongCondition.linearHint HiaGuardedUsizeSlice.linear_0 success; have impossible := necessary.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1; cases impossible
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.checkedEncode_determinate
#print axioms HiaCoreSyntaxSlice.checkedEncode_of_parts
#print axioms HiaCoreSyntaxSlice.checkedEncode_roundtrip
#print axioms HiaCoreSyntaxSlice.extract_sound
#print axioms HiaCoreSyntaxSlice.extracted_successor
#print axioms HiaCoreSyntaxSlice.linear_extraction
#print axioms HiaCoreSyntaxSlice.linear_relation
#print axioms HiaCoreSyntaxSlice.linear_transport
#print axioms HiaCoreSyntaxSlice.parallel_extraction
#print axioms HiaCoreSyntaxSlice.parallel_transport
#print axioms HiaCoreSyntaxSlice.reject_literal_two
#print axioms HiaCoreSyntaxSlice.reject_stale_descriptor
#print axioms HiaCoreSyntaxSlice.reject_wrong_condition
#print axioms HiaCoreSyntaxSlice.reject_wrong_phi
#print axioms HiaGuardedUsizeSlice.affine_0_small
#print axioms HiaGuardedUsizeSlice.affine_0_upper
#print axioms HiaGuardedUsizeSlice.affine_0_valid
#print axioms HiaGuardedUsizeSlice.affine_1_small
#print axioms HiaGuardedUsizeSlice.affine_1_upper
#print axioms HiaGuardedUsizeSlice.affine_1_valid
#print axioms HiaGuardedUsizeSlice.affine_2_small
#print axioms HiaGuardedUsizeSlice.affine_2_upper
#print axioms HiaGuardedUsizeSlice.affine_2_valid
#print axioms HiaGuardedUsizeSlice.affine_3_small
#print axioms HiaGuardedUsizeSlice.affine_3_upper
#print axioms HiaGuardedUsizeSlice.affine_3_valid
#print axioms HiaGuardedUsizeSlice.checked_add_in_range
#print axioms HiaGuardedUsizeSlice.crossed_0_small
#print axioms HiaGuardedUsizeSlice.crossed_0_upper
#print axioms HiaGuardedUsizeSlice.crossed_0_valid
#print axioms HiaGuardedUsizeSlice.false_guard_no_step
#print axioms HiaGuardedUsizeSlice.guard_values
#print axioms HiaGuardedUsizeSlice.guarded_successors
#print axioms HiaGuardedUsizeSlice.invalid_no_step
#print axioms HiaGuardedUsizeSlice.linear_0_small
#print axioms HiaGuardedUsizeSlice.linear_0_upper
#print axioms HiaGuardedUsizeSlice.linear_0_valid
#print axioms HiaGuardedUsizeSlice.linear_1_small
#print axioms HiaGuardedUsizeSlice.linear_1_upper
#print axioms HiaGuardedUsizeSlice.linear_1_valid
#print axioms HiaGuardedUsizeSlice.linear_2_small
#print axioms HiaGuardedUsizeSlice.linear_2_upper
#print axioms HiaGuardedUsizeSlice.linear_2_valid
#print axioms HiaGuardedUsizeSlice.linear_3_small
#print axioms HiaGuardedUsizeSlice.linear_3_upper
#print axioms HiaGuardedUsizeSlice.linear_3_valid
#print axioms HiaGuardedUsizeSlice.no_step_false_guard
#print axioms HiaGuardedUsizeSlice.no_step_missing
#print axioms HiaGuardedUsizeSlice.no_step_opaque
#print axioms HiaGuardedUsizeSlice.no_step_oversized
#print axioms HiaGuardedUsizeSlice.readUsize_bounded
#print axioms HiaGuardedUsizeSlice.readUsize_phi
#print axioms HiaGuardedUsizeSlice.selected_successor
#print axioms HiaGuardedUsizeSlice.wrapping_add_in_range
#print axioms HiaInitializationPrefix.completed_exit_establishes_initialized
#print axioms HiaInitializationPrefix.completed_exit_is_exact_bound
#print axioms HiaInitializationPrefix.completed_fill_independent_of_initial
#print axioms HiaInitializationPrefix.completed_fill_initialized
#print axioms HiaInitializationPrefix.completed_fill_matches_zeroed
#print axioms HiaInitializationPrefix.incomplete_prefix_is_not_full
#print axioms HiaInitializationPrefix.increment_within_limit
#print axioms HiaInitializationPrefix.prefix_invariant
#print axioms HiaInitializationPrefix.prefix_outside
#print axioms HiaInitializationPrefix.prefix_value
#print axioms HiaInitializationPrefix.skipped_zero_stays_uninitialized
#print axioms HiaInitializationPrefix.stride_two_leaves_a_hole
#print axioms HiaInitializationPrefix.write_at_index
#print axioms HiaInitializationPrefix.write_at_other
#print axioms HiaInitializationPrefix.write_extends_prefix
#print axioms HiaInitializationPrefix.zero_prefix
-- SEVEN_CERTIFICATE_REJECTIONS_V1

namespace HiaCoreSyntaxSlice.ChangedByte
noncomputable def linearBytes : List Nat := HiaCoreSyntaxSlice.linear_g0 ++ (HiaCoreSyntaxSlice.linear_v0_0 ++ [93])
end HiaCoreSyntaxSlice.ChangedByte

namespace HiaCoreSyntaxSlice
theorem reject_changed_exact_byte : ¬ (HiaCoreSyntaxSlice.checkedEncode HiaCoreSyntaxSlice.linearRaw = some HiaCoreSyntaxSlice.ChangedByte.linearBytes) := by have cancel : ∀ (front left right : List Nat), front ++ left = front ++ right → left = right := (by intro front; induction front with | nil => intro left right same; exact same | cons head tail ih => intro left right same; exact ih left right (List.cons.inj same).2); intro encoded; have same := Option.some.inj (linear_transport.symm.trans encoded); change linear_g0 ++ (linear_v0_0 ++ [125]) = linear_g0 ++ (linear_v0_0 ++ [93]) at same; have last := cancel linear_v0_0 [125] [93] (cancel linear_g0 _ _ same); cases last


theorem reject_duplicate_keys : ¬ (HiaCoreSyntaxSlice.checkedEncode (.obj [([97],.num 0),([97],.num 1)]) = some [123,34,97,34,58,48,44,34,97,34,58,49,125]) := by decide +kernel
theorem reject_unordered_keys : ¬ (HiaCoreSyntaxSlice.checkedEncode (.obj [([98],.num 0),([97],.num 1)]) = some [123,34,98,34,58,48,44,34,97,34,58,49,125]) := by decide +kernel
theorem reject_byte_modulo_alias : ¬ (HiaCoreSyntaxSlice.checkedEncode (.str [256]) = some [34,0,34]) := by decide +kernel
theorem reject_leading_zero : ¬ (HiaCoreSyntaxSlice.decode [48,49] = some (.num 1)) := by decide +kernel
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.reject_byte_modulo_alias
#print axioms HiaCoreSyntaxSlice.reject_changed_exact_byte
#print axioms HiaCoreSyntaxSlice.reject_duplicate_keys
#print axioms HiaCoreSyntaxSlice.reject_leading_zero
#print axioms HiaCoreSyntaxSlice.reject_unordered_keys
