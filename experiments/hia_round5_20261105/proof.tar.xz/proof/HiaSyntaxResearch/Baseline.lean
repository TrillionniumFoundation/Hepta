import Lean.Elab.Tactic.Omega

/-!
A mathematical byte-memory model for the full-write-before-read optimization.
`none` is an uninitialized byte.  The fill schedule is exactly 0, 1, ..., n-1;
values are an arbitrary function independent of the initial byte contents.

This file does not import a HIA CFG, model an allocator or prove Python/LLVM
refinement.  The separate conservative CFG checker must establish this exact
schedule, common allocation identity, absence of early reads/escapes and that
the completed-fill exit dominates every subsequent byte read.  Native bounds,
allocation success/failure, zero-length and release remain separate obligations.
-/

namespace HiaInitializationPrefix

abbrev Byte := BitVec 8
abbrev Memory := Nat → Option Byte

def empty : Memory := fun _ => none
def zeroed : Memory := fun _ => some (BitVec.ofNat 8 0)

def write (memory : Memory) (index : Nat) (value : Byte) : Memory :=
  fun address => if address = index then some value else memory address

def fillPrefix (initial : Memory) (values : Nat → Byte) : Nat → Memory
  | 0 => initial
  | count + 1 => write (fillPrefix initial values count) count (values count)

def PrefixValues (memory : Memory) (values : Nat → Byte) (count : Nat) : Prop :=
  ∀ address, address < count → memory address = some (values address)

def FullyInitialized (memory : Memory) (length : Nat) : Prop :=
  ∀ address, address < length → ∃ value, memory address = some value

theorem write_at_index (memory : Memory) (index : Nat) (value : Byte) :
    write memory index value index = some value := by
  simp [write]

theorem write_at_other (memory : Memory) (index address : Nat) (value : Byte)
    (different : address ≠ index) :
    write memory index value address = memory address := by
  simp [write, different]

theorem zero_prefix (initial : Memory) (values : Nat → Byte) :
    fillPrefix initial values 0 = initial := rfl

theorem write_extends_prefix (memory : Memory) (values : Nat → Byte) (index : Nat)
    (before : PrefixValues memory values index) :
    PrefixValues (write memory index (values index)) values (index + 1) := by
  intro address below
  by_cases equal : address = index
  · subst address
    exact write_at_index memory index (values index)
  · have earlier : address < index := by omega
    simpa [write, equal] using before address earlier

theorem prefix_value (initial : Memory) (values : Nat → Byte) (count address : Nat)
    (below : address < count) :
    fillPrefix initial values count address = some (values address) := by
  induction count generalizing address with
  | zero => omega
  | succ count previous =>
      by_cases equal : address = count
      · subst address
        simp [fillPrefix, write]
      · have earlier : address < count := by omega
        simpa [fillPrefix, write, equal] using previous address earlier

theorem prefix_outside (initial : Memory) (values : Nat → Byte) (count address : Nat)
    (outside : count ≤ address) :
    fillPrefix initial values count address = initial address := by
  induction count with
  | zero => rfl
  | succ count previous =>
      have different : address ≠ count := by omega
      have before : count ≤ address := by omega
      simpa [fillPrefix, write, different] using previous before

theorem prefix_invariant (initial : Memory) (values : Nat → Byte) (count : Nat) :
    PrefixValues (fillPrefix initial values count) values count := by
  intro address below
  exact prefix_value initial values count address below

theorem completed_fill_initialized (initial : Memory) (values : Nat → Byte) (length : Nat) :
    FullyInitialized (fillPrefix initial values length) length := by
  intro address below
  exact ⟨values address, prefix_value initial values length address below⟩

theorem completed_fill_independent_of_initial (left right : Memory) (values : Nat → Byte)
    (length address : Nat) (below : address < length) :
    fillPrefix left values length address = fillPrefix right values length address := by
  rw [prefix_value left values length address below,
      prefix_value right values length address below]

theorem completed_fill_matches_zeroed (initial : Memory) (values : Nat → Byte)
    (length address : Nat) (below : address < length) :
    fillPrefix initial values length address = fillPrefix zeroed values length address :=
  completed_fill_independent_of_initial initial zeroed values length address below

theorem increment_within_limit (index length maximum : Nat)
    (continues : index < length) (bounded : length ≤ maximum) :
    index + 1 ≤ maximum := by omega

theorem completed_exit_is_exact_bound (index length : Nat)
    (invariant : index ≤ length) (exit : ¬ index < length) :
    index = length := by omega

theorem completed_exit_establishes_initialized (memory : Memory) (values : Nat → Byte)
    (index length : Nat) (initializedPrefix : PrefixValues memory values index)
    (invariant : index ≤ length) (exit : ¬ index < length) :
    FullyInitialized memory length := by
  have finished : index = length := completed_exit_is_exact_bound index length invariant exit
  intro address below
  exact ⟨values address, initializedPrefix address (by omega)⟩

theorem incomplete_prefix_is_not_full (values : Nat → Byte) (written length : Nat)
    (incomplete : written < length) :
    ¬ FullyInitialized (fillPrefix empty values written) length := by
  intro complete
  obtain ⟨value, found⟩ := complete written incomplete
  have absent : fillPrefix empty values written written = none := by
    simpa [empty] using prefix_outside empty values written written (Nat.le_refl written)
  rw [absent] at found
  contradiction

def fillFromOne (values : Nat → Byte) : Nat → Memory
  | 0 => empty
  | count + 1 => write (fillFromOne values count) (count + 1) (values (count + 1))

theorem skipped_zero_stays_uninitialized (values : Nat → Byte) (count : Nat) :
    fillFromOne values count 0 = none := by
  induction count with
  | zero => rfl
  | succ count previous => simpa [fillFromOne, write] using previous

def fillStrideTwo (values : Nat → Byte) : Nat → Memory
  | 0 => empty
  | count + 1 => write (fillStrideTwo values count) (count * 2) (values (count * 2))

theorem stride_two_leaves_a_hole (values : Nat → Byte) (count : Nat) :
    fillStrideTwo values count 1 = none := by
  induction count with
  | zero => rfl
  | succ count previous =>
      have different : 1 ≠ count * 2 := by omega
      simpa [fillStrideTwo, write, different] using previous

#print axioms write_at_index
#print axioms write_at_other
#print axioms zero_prefix
#print axioms write_extends_prefix
#print axioms prefix_value
#print axioms prefix_outside
#print axioms prefix_invariant
#print axioms completed_fill_initialized
#print axioms completed_fill_independent_of_initial
#print axioms completed_fill_matches_zeroed
#print axioms increment_within_limit
#print axioms completed_exit_is_exact_bound
#print axioms completed_exit_establishes_initialized
#print axioms incomplete_prefix_is_not_full
#print axioms skipped_zero_stays_uninitialized
#print axioms stride_two_leaves_a_hole

end HiaInitializationPrefix

/-!
UNCHECKED proof text until acceptance by the repository-pinned Lean CI lane.
Append after the exact HiaInitializationPrefix.lean input (no extra imports).

This is a partial scalar projection of a selected true edge and a local add,
not a Core interpreter or memory model. It does not establish arrival at the
add, body framing, definition of every edge operand, allocation identity,
exporter/parser refinement, or a whole-loop/backend/resource theorem.
-/

namespace HiaGuardedUsizeSlice

inductive TypeTag where
  | usize
  | other
  deriving DecidableEq, Repr

inductive CompareOp where
  | lt
  | le
  | other
  deriving DecidableEq, Repr

inductive Arm where
  | thenArm
  | elseArm
  deriving DecidableEq, Repr

inductive AddOp where
  | checked
  | wrapping
  | other
  deriving DecidableEq, Repr

inductive Value where
  | usize (value : Nat)
  | opaque
  deriving DecidableEq, Repr

abbrev Env := Nat → Option Value

structure Descriptor where
  sourceIndex : Nat
  sourceExtent : Nat
  compareOutput : Nat
  branchCondition : Nat
  indexType : TypeTag
  extentType : TypeTag
  compareOp : CompareOp
  selectedArm : Arm
  incoming : List Nat
  indexSlot : Nat
  extentSlot : Nat
  addIndexSlot : Nat
  addOp : AddOp
  addType : TypeTag
  literalType : TypeTag
  literalValue : Nat
  literalOrdinal : Nat
  addOrdinal : Nat
  deriving DecidableEq, Repr

/-- All validation facts are computed from the descriptor, not proof fields. -/
def Valid (d : Descriptor) : Prop :=
  d.indexType = .usize ∧
  d.extentType = .usize ∧
  d.compareOp = .lt ∧
  d.branchCondition = d.compareOutput ∧
  d.selectedArm = .thenArm ∧
  d.incoming[d.indexSlot]? = some d.sourceIndex ∧
  d.incoming[d.extentSlot]? = some d.sourceExtent ∧
  d.addIndexSlot = d.indexSlot ∧
  d.addOp ≠ .other ∧
  d.addType = .usize ∧
  d.literalType = .usize ∧
  d.literalValue = 1 ∧
  d.literalOrdinal < d.addOrdinal

instance (d : Descriptor) : Decidable (Valid d) := by
  unfold Valid
  infer_instance

/-- Opaque, absent, or out-of-range values cannot be used as usize. -/
def readUsize (maximum : Nat) (env : Env) (slot : Nat) : Option Nat :=
  match env slot with
  | some (.usize n) => if n ≤ maximum then some n else none
  | _ => none

/-- Every lookup reads the same immutable incoming environment. -/
def phiEnv (d : Descriptor) (env : Env) : Env := fun slot =>
  match d.incoming[slot]? with -- MUTATION_SITE_PHI_LOOKUP
  | some source => env source
  | none => none

def evalGuard (maximum : Nat) (d : Descriptor) (env : Env) : Option Bool :=
  match readUsize maximum env d.sourceIndex,
      readUsize maximum env d.sourceExtent with
  | some index, some extent =>
    match d.compareOp with
    | .lt => some (decide (index < extent))
    | .le => some (decide (index ≤ extent))
    | .other => none
  | _, _ => none

/-- The literal is a direct operand. It is never installed into phiEnv. -/
def evalAdd (mode : AddOp) (maximum index literal : Nat) : Option Nat :=
  let sum := index + literal -- MUTATION_SITE_ADD_LITERAL
  match mode with
  | .checked => if sum ≤ maximum then some sum else none
  | .wrapping => some (sum % (maximum + 1))
  | .other => none

def evalStep (mode : AddOp) (maximum : Nat) (d : Descriptor) (env : Env) : Option Nat :=
  if Valid d then
    if evalGuard maximum d env = some true then -- MUTATION_SITE_STEP_GUARD
      match readUsize maximum (phiEnv d env) d.addIndexSlot,
          readUsize maximum (phiEnv d env) d.extentSlot with
      | some index, some _extent => evalAdd mode maximum index d.literalValue
      | _, _ => none
    else none
  else none

def evalSelectedStep (maximum : Nat) (d : Descriptor) (env : Env) : Option Nat :=
  evalStep d.addOp maximum d env

theorem readUsize_bounded (maximum : Nat) (env : Env) (slot n : Nat)
    (read : readUsize maximum env slot = some n) : n ≤ maximum := by
  unfold readUsize at read
  cases hvalue : env slot with
  | none => simp [hvalue] at read
  | some value =>
    cases value with
    | «opaque» => simp [hvalue] at read
    | usize value =>
      by_cases bounded : value ≤ maximum
      · have same : value = n := by simpa [hvalue, bounded] using read
        omega
      · simp [hvalue, bounded] at read

theorem readUsize_phi (maximum : Nat) (d : Descriptor) (env : Env)
    (slot source : Nat) (position : d.incoming[slot]? = some source) :
    readUsize maximum (phiEnv d env) slot = readUsize maximum env source := by
  simp [readUsize, phiEnv, position]

/-- Strictness and source values are derived from the actual guard evaluation. -/
theorem guard_values (maximum : Nat) (d : Descriptor) (env : Env)
    (strict : d.compareOp = .lt)
    (guard : evalGuard maximum d env = some true) :
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧ index < extent := by
  unfold evalGuard at guard
  cases hi : readUsize maximum env d.sourceIndex with
  | none => simp [hi] at guard
  | some index =>
    cases hn : readUsize maximum env d.sourceExtent with
    | none => simp [hi, hn] at guard
    | some extent =>
      have below : index < extent := by simpa [hi, hn, strict] using guard
      exact ⟨index, extent, rfl, rfl, below⟩

theorem checked_add_in_range (maximum index : Nat) (bounded : index + 1 ≤ maximum) :
    evalAdd .checked maximum index 1 = some (index + 1) := by
  simp [evalAdd, bounded]

theorem wrapping_add_in_range (maximum index : Nat) (bounded : index + 1 ≤ maximum) :
    evalAdd .wrapping maximum index 1 = some (index + 1) := by
  have below : index + 1 < maximum + 1 := by omega
  simp [evalAdd, Nat.mod_eq_of_lt below]

/-- Existence of BOTH successful additions, for arbitrary environments and valid
    descriptors. No caller-supplied i<N or phi-value premise is used. -/
theorem guarded_successors (maximum : Nat) (d : Descriptor) (env : Env)
    (valid : Valid d) (guard : evalGuard maximum d env = some true) :
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧
      index < extent ∧
      evalStep .checked maximum d env = some (index + 1) ∧
      evalStep .wrapping maximum d env = some (index + 1) ∧
      index + 1 ≤ extent ∧ extent ≤ maximum ∧ index + 1 ≤ maximum := by
  have validCopy := valid
  obtain ⟨_indexType, _extentType, strict, _condition, _arm,
    indexPosition, extentPosition, addPosition, _mode, _addType,
    _literalType, one, _order⟩ := validCopy
  obtain ⟨index, extent, hi, hn, below⟩ := guard_values maximum d env strict guard
  have extentBound := readUsize_bounded maximum env d.sourceExtent extent hn
  have successorBound : index + 1 ≤ maximum :=
    HiaInitializationPrefix.increment_within_limit index extent maximum below extentBound
  have indexRead : readUsize maximum (phiEnv d env) d.addIndexSlot = some index := by
    rw [addPosition, readUsize_phi maximum d env d.indexSlot d.sourceIndex indexPosition]
    exact hi
  have extentRead : readUsize maximum (phiEnv d env) d.extentSlot = some extent := by
    rw [readUsize_phi maximum d env d.extentSlot d.sourceExtent extentPosition]
    exact hn
  have checked : evalStep .checked maximum d env = some (index + 1) := by
    simpa [evalStep, valid, guard, indexRead, extentRead, one] using
      checked_add_in_range maximum index successorBound
  have wrapping : evalStep .wrapping maximum d env = some (index + 1) := by
    simpa [evalStep, valid, guard, indexRead, extentRead, one] using
      wrapping_add_in_range maximum index successorBound
  exact ⟨index, extent, hi, hn, below, checked, wrapping, by omega,
    extentBound, successorBound⟩

/-- In particular the descriptor's actual selected opcode has a successor. -/
theorem selected_successor (maximum : Nat) (d : Descriptor) (env : Env)
    (valid : Valid d) (guard : evalGuard maximum d env = some true) :
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧
      evalSelectedStep maximum d env = some (index + 1) ∧
      index + 1 ≤ extent ∧ extent ≤ maximum ∧ index + 1 ≤ maximum := by
  obtain ⟨index, extent, hi, hn, _below, checked, wrapping, within, extentBound,
    successorBound⟩ := guarded_successors maximum d env valid guard
  have supported : d.addOp ≠ .other := valid.2.2.2.2.2.2.2.2.1
  have selected : evalSelectedStep maximum d env = some (index + 1) := by
    unfold evalSelectedStep
    cases mode : d.addOp with
    | checked => exact checked
    | wrapping => exact wrapping
    | other => exact False.elim (supported mode)
  exact ⟨index, extent, hi, hn, selected, within, extentBound, successorBound⟩

/-- Negative semantic obligation: bypassing the guard must not validate. -/
theorem false_guard_no_step (mode : AddOp) (maximum : Nat) (d : Descriptor) (env : Env)
    (guard : evalGuard maximum d env ≠ some true) :
    evalStep mode maximum d env = none := by
  simp [evalStep, guard]

theorem invalid_no_step (mode : AddOp) (maximum : Nat) (d : Descriptor) (env : Env)
    (invalid : ¬ Valid d) : evalStep mode maximum d env = none := by
  simp [evalStep, invalid]

#print axioms readUsize_bounded
#print axioms readUsize_phi
#print axioms guard_values
#print axioms checked_add_in_range
#print axioms wrapping_add_in_range
#print axioms guarded_successors
#print axioms selected_successor
#print axioms false_guard_no_step
#print axioms invalid_no_step

end HiaGuardedUsizeSlice


namespace HiaGuardedUsizeSlice
def linear_0 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 9,
  addOrdinal := 10
}
theorem linear_0_valid : Valid linear_0 := by decide
def linear_0_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem linear_0_small : evalGuard 18446744073709551615 linear_0 linear_0_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_0 linear_0_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_0 linear_0_small_env = some 1 := by decide
def linear_0_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem linear_0_upper : evalGuard 18446744073709551615 linear_0 linear_0_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_0 linear_0_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_0 linear_0_upper_env = some 18446744073709551615 := by decide
#print axioms linear_0_valid
#print axioms linear_0_small
#print axioms linear_0_upper

def linear_1 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem linear_1_valid : Valid linear_1 := by decide
def linear_1_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem linear_1_small : evalGuard 18446744073709551615 linear_1 linear_1_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_1 linear_1_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_1 linear_1_small_env = some 1 := by decide
def linear_1_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem linear_1_upper : evalGuard 18446744073709551615 linear_1 linear_1_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_1 linear_1_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_1 linear_1_upper_env = some 18446744073709551615 := by decide
#print axioms linear_1_valid
#print axioms linear_1_small
#print axioms linear_1_upper

def linear_2 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 9,
  addOrdinal := 10
}
theorem linear_2_valid : Valid linear_2 := by decide
def linear_2_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem linear_2_small : evalGuard 18446744073709551615 linear_2 linear_2_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_2 linear_2_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_2 linear_2_small_env = some 1 := by decide
def linear_2_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem linear_2_upper : evalGuard 18446744073709551615 linear_2 linear_2_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_2 linear_2_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_2 linear_2_upper_env = some 18446744073709551615 := by decide
#print axioms linear_2_valid
#print axioms linear_2_small
#print axioms linear_2_upper

def linear_3 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem linear_3_valid : Valid linear_3 := by decide
def linear_3_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem linear_3_small : evalGuard 18446744073709551615 linear_3 linear_3_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_3 linear_3_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_3 linear_3_small_env = some 1 := by decide
def linear_3_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem linear_3_upper : evalGuard 18446744073709551615 linear_3 linear_3_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_3 linear_3_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_3 linear_3_upper_env = some 18446744073709551615 := by decide
#print axioms linear_3_valid
#print axioms linear_3_small
#print axioms linear_3_upper

def affine_0 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 13,
  addOrdinal := 14
}
theorem affine_0_valid : Valid affine_0 := by decide
def affine_0_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem affine_0_small : evalGuard 18446744073709551615 affine_0 affine_0_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_0 affine_0_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_0 affine_0_small_env = some 1 := by decide
def affine_0_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem affine_0_upper : evalGuard 18446744073709551615 affine_0 affine_0_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_0 affine_0_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_0 affine_0_upper_env = some 18446744073709551615 := by decide
#print axioms affine_0_valid
#print axioms affine_0_small
#print axioms affine_0_upper

def affine_1 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem affine_1_valid : Valid affine_1 := by decide
def affine_1_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem affine_1_small : evalGuard 18446744073709551615 affine_1 affine_1_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_1 affine_1_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_1 affine_1_small_env = some 1 := by decide
def affine_1_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem affine_1_upper : evalGuard 18446744073709551615 affine_1 affine_1_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_1 affine_1_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_1 affine_1_upper_env = some 18446744073709551615 := by decide
#print axioms affine_1_valid
#print axioms affine_1_small
#print axioms affine_1_upper

def affine_2 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 13,
  addOrdinal := 14
}
theorem affine_2_valid : Valid affine_2 := by decide
def affine_2_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem affine_2_small : evalGuard 18446744073709551615 affine_2 affine_2_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_2 affine_2_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_2 affine_2_small_env = some 1 := by decide
def affine_2_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem affine_2_upper : evalGuard 18446744073709551615 affine_2 affine_2_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_2 affine_2_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_2 affine_2_upper_env = some 18446744073709551615 := by decide
#print axioms affine_2_valid
#print axioms affine_2_small
#print axioms affine_2_upper

def affine_3 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem affine_3_valid : Valid affine_3 := by decide
def affine_3_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem affine_3_small : evalGuard 18446744073709551615 affine_3 affine_3_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_3 affine_3_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_3 affine_3_small_env = some 1 := by decide
def affine_3_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem affine_3_upper : evalGuard 18446744073709551615 affine_3 affine_3_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_3 affine_3_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_3 affine_3_upper_env = some 18446744073709551615 := by decide
#print axioms affine_3_valid
#print axioms affine_3_small
#print axioms affine_3_upper

def crossed_0 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 4, 3],
  indexSlot := 3,
  extentSlot := 4,
  addIndexSlot := 3,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 9,
  addOrdinal := 10
}
theorem crossed_0_valid : Valid crossed_0 := by decide
def crossed_0_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem crossed_0_small : evalGuard 18446744073709551615 crossed_0 crossed_0_small_env = some true ∧
    evalStep .checked 18446744073709551615 crossed_0 crossed_0_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 crossed_0 crossed_0_small_env = some 1 := by decide
def crossed_0_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem crossed_0_upper : evalGuard 18446744073709551615 crossed_0 crossed_0_upper_env = some true ∧
    evalStep .checked 18446744073709551615 crossed_0 crossed_0_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 crossed_0 crossed_0_upper_env = some 18446744073709551615 := by decide
#print axioms crossed_0_valid
#print axioms crossed_0_small
#print axioms crossed_0_upper

theorem no_step_missing : evalSelectedStep 18446744073709551615 linear_0 (fun _ => none) = none := by decide
#print axioms no_step_missing

theorem no_step_opaque : evalSelectedStep 18446744073709551615 linear_0 (fun _ => some .opaque) = none := by decide
#print axioms no_step_opaque

theorem no_step_oversized : evalSelectedStep 18446744073709551615 linear_0 (fun _ => some (.usize 18446744073709551616)) = none := by decide
#print axioms no_step_oversized

theorem no_step_false_guard : evalSelectedStep 18446744073709551615 linear_0 (fun _ => some (.usize 0)) = none := by decide
#print axioms no_step_false_guard

end HiaGuardedUsizeSlice
-- SHARED_GENERIC_PARENT_V2
/-!
UNCHECKED Lean 4.19 proof text. Append after the existing
Lean.Elab.Tactic.Omega import; no additional import is required.

Restricted, compact canonical JSON transport for an inert whole-document tree.
The decoder is independent of the serializer. checkedEncode accepts only after
an actual decode equality check, so determinacy below is a checked round-trip
result, not an assumed serializer-injectivity theorem. No claim of completeness
for all JSON, all Core, or every input within the resource limits is made.
File-to-byte provenance is outside this kernel statement.
-/

namespace HiaCoreSyntaxSlice

inductive Raw where
  | str (bytes : List Nat)
  | num (value : Nat)
  | arr (items : List Raw)
  | obj (fields : List (List Nat × Raw))
  deriving Repr

/- Lean 4.19 does not derive DecidableEq for this nested datatype. These
    explicit mutual decisions produce equality proofs by constructor congruence
    and reject unequal constructor arguments by constructor injectivity. -/
mutual
  def rawDecEq : (a b : Raw) → Decidable (a = b)
    | .str left, .str right =>
      if same : left = right then isTrue (congrArg Raw.str same)
      else isFalse (fun equal => same (Raw.str.inj equal))
    | .num left, .num right =>
      if same : left = right then isTrue (congrArg Raw.num same)
      else isFalse (fun equal => same (Raw.num.inj equal))
    | .arr left, .arr right =>
      match rawListDecEq left right with
      | isTrue same => isTrue (congrArg Raw.arr same)
      | isFalse different => isFalse (fun equal => different (Raw.arr.inj equal))
    | .obj left, .obj right =>
      match rawFieldsDecEq left right with
      | isTrue same => isTrue (congrArg Raw.obj same)
      | isFalse different => isFalse (fun equal => different (Raw.obj.inj equal))
    | .str _, .num _ => isFalse (by intro equal; cases equal)
    | .str _, .arr _ => isFalse (by intro equal; cases equal)
    | .str _, .obj _ => isFalse (by intro equal; cases equal)
    | .num _, .str _ => isFalse (by intro equal; cases equal)
    | .num _, .arr _ => isFalse (by intro equal; cases equal)
    | .num _, .obj _ => isFalse (by intro equal; cases equal)
    | .arr _, .str _ => isFalse (by intro equal; cases equal)
    | .arr _, .num _ => isFalse (by intro equal; cases equal)
    | .arr _, .obj _ => isFalse (by intro equal; cases equal)
    | .obj _, .str _ => isFalse (by intro equal; cases equal)
    | .obj _, .num _ => isFalse (by intro equal; cases equal)
    | .obj _, .arr _ => isFalse (by intro equal; cases equal)

  def rawListDecEq : (a b : List Raw) → Decidable (a = b)
    | [], [] => isTrue rfl
    | [], _ :: _ => isFalse (by intro equal; cases equal)
    | _ :: _, [] => isFalse (by intro equal; cases equal)
    | left :: leftRest, right :: rightRest =>
      match rawDecEq left right with
      | isFalse different =>
        isFalse (fun equal => different (List.cons.inj equal).1)
      | isTrue same =>
        match rawListDecEq leftRest rightRest with
        | isFalse different =>
          isFalse (fun equal => different (List.cons.inj equal).2)
        | isTrue sameRest => isTrue (by cases same; cases sameRest; rfl)

  def rawFieldDecEq : (a b : List Nat × Raw) → Decidable (a = b)
    | (leftKey, left), (rightKey, right) =>
      if sameKey : leftKey = rightKey then
        match rawDecEq left right with
        | isTrue same => isTrue (by cases sameKey; cases same; rfl)
        | isFalse different =>
          isFalse (fun equal => different (congrArg Prod.snd equal))
      else isFalse (fun equal => sameKey (congrArg Prod.fst equal))

  def rawFieldsDecEq : (a b : List (List Nat × Raw)) → Decidable (a = b)
    | [], [] => isTrue rfl
    | [], _ :: _ => isFalse (by intro equal; cases equal)
    | _ :: _, [] => isFalse (by intro equal; cases equal)
    | left :: leftRest, right :: rightRest =>
      match rawFieldDecEq left right with
      | isFalse different =>
        isFalse (fun equal => different (List.cons.inj equal).1)
      | isTrue same =>
        match rawFieldsDecEq leftRest rightRest with
        | isFalse different =>
          isFalse (fun equal => different (List.cons.inj equal).2)
        | isTrue sameRest => isTrue (by cases same; cases sameRest; rfl)
end

instance : DecidableEq Raw := rawDecEq

def transportFuel : Nat := 4096
def transportDepth : Nat := 32
def transportByteLimit : Nat := 32768

/-- Printable ASCII without JSON's quote or escape character. -/
def stringByte (byte : Nat) : Bool :=
  decide (32 ≤ byte ∧ byte ≤ 126 ∧ byte ≠ 34 ∧ byte ≠ 92)

def stringBytes : List Nat → Bool
  | [] => true
  | byte :: rest => stringByte byte && stringBytes rest

/-- Strict lexicographic comparison of byte lists, including prefix ordering. -/
def keyLess : List Nat → List Nat → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: left, b :: right =>
    if a < b then true else if a = b then keyLess left right else false

/-- Strict order rejects both duplicates and noncanonical field order. -/
def orderedFields : List (List Nat × Raw) → Bool
  | [] => true
  | (key, _) :: rest =>
    match rest with
    | [] => true
    | (nextKey, _) :: _ => keyLess key nextKey && orderedFields rest

/-- Count all value nodes, including unselected subtrees, without recursion on
    the nested datatype. This is separate from parser/serializer call fuel. -/
def nodeBudget : Nat → List Raw → Bool
  | _, [] => true
  | 0, _ :: _ => false
  | fuel + 1, .str _ :: rest => nodeBudget fuel rest
  | fuel + 1, .num _ :: rest => nodeBudget fuel rest
  | fuel + 1, .arr items :: rest => nodeBudget fuel (items ++ rest)
  | fuel + 1, .obj fields :: rest =>
    nodeBudget fuel (fields.map (fun entry => entry.2) ++ rest)

/-- A separate cheap whole-tree budget check for syntax extraction. Each
    pending item carries the number of value levels still allowed at that item. -/
def depthNodeBudget : Nat → List (Nat × Raw) → Bool
  | _, [] => true
  | 0, _ :: _ => false
  | _ + 1, (0, _) :: _ => false
  | fuel + 1, (_ + 1, .str _) :: rest => depthNodeBudget fuel rest
  | fuel + 1, (_ + 1, .num _) :: rest => depthNodeBudget fuel rest
  | fuel + 1, (depth + 1, .arr items) :: rest =>
    depthNodeBudget fuel (items.map (fun item => (depth, item)) ++ rest)
  | fuel + 1, (depth + 1, .obj fields) :: rest =>
    depthNodeBudget fuel (fields.map (fun entry => (depth, entry.2)) ++ rest)

def withinBounds (raw : Raw) : Bool :=
  depthNodeBudget transportFuel [(transportDepth, raw)]

/-- Explicit base-ten conversion. Zero emits exactly one digit. The only
    leading digit emitted is 1..9 unless the entire numeral is zero. -/
def decimalAux : Nat → Nat → List Nat → Option (List Nat)
  | 0, _, _ => none
  | fuel + 1, value, suffix =>
    if value < 10 then some ((48 + value) :: suffix)
    else decimalAux fuel (value / 10) ((48 + value % 10) :: suffix)

def decimal (value : Nat) : Option (List Nat) :=
  decimalAux transportByteLimit value []

mutual
  /-- A compact serializer with no escape or raw-fragment constructor. -/
  def serializeRaw : Nat → Nat → Raw → Option (List Nat)
    | 0, _, _ => none
    | _ + 1, 0, _ => none
    | _ + 1, _ + 1, .str bytes =>
      if stringBytes bytes then some (34 :: (bytes ++ [34])) else none
    | _ + 1, _ + 1, .num value => decimal value
    | fuel + 1, depth + 1, .arr items => do
      let bytes ← serializeItems fuel depth items
      pure (91 :: (bytes ++ [93]))
    | fuel + 1, depth + 1, .obj fields =>
      if orderedFields fields then do
        let bytes ← serializeFields fuel depth fields
        pure (123 :: (bytes ++ [125]))
      else none

  def serializeItems : Nat → Nat → List Raw → Option (List Nat)
    | _, _, [] => some []
    | 0, _, _ :: _ => none
    | fuel + 1, depth, value :: rest => do
      let bytes ← serializeRaw fuel depth value
      match rest with
      | [] => pure bytes
      | _ :: _ =>
        let suffix ← serializeItems fuel depth rest
        pure (bytes ++ (44 :: suffix))

  def serializeFields : Nat → Nat → List (List Nat × Raw) → Option (List Nat)
    | _, _, [] => some []
    | 0, _, _ :: _ => none
    | fuel + 1, depth, (key, value) :: rest =>
      if stringBytes key then do
        let bytes ← serializeRaw fuel depth value
        let field := 34 :: (key ++ (34 :: 58 :: bytes))
        match rest with
        | [] => pure field
        | _ :: _ =>
          let suffix ← serializeFields fuel depth rest
          pure (field ++ (44 :: suffix))
      else none
end

/-- The byte and node checks are part of the accepted transport domain. -/
def serializeChecked (raw : Raw) : Option (List Nat) :=
  if withinBounds raw then
    match serializeRaw transportFuel transportDepth raw with
    | none => none
    | some bytes => if bytes.length ≤ transportByteLimit then some bytes else none
  else none

def digitByte (byte : Nat) : Bool := decide (48 ≤ byte ∧ byte ≤ 57)

/-- Called after an opening quote. It consumes its closing quote, never escapes. -/
def parseStringTail : List Nat → List Nat → Option (List Nat × List Nat)
  | [], _ => none
  | byte :: rest, reversed =>
    if byte = 34 then some (reversed.reverse, rest)
    else if stringByte byte then parseStringTail rest (byte :: reversed)
    else none

def parseDigits : List Nat → Nat → Nat × List Nat
  | [], value => (value, [])
  | byte :: rest, value =>
    if digitByte byte then parseDigits rest (value * 10 + (byte - 48))
    else (value, byte :: rest)

/-- A zero cannot be followed by another decimal digit. A separator is checked
    by the enclosing parser or by decode's full-consumption check. -/
def parseNumber : List Nat → Option (Nat × List Nat)
  | [] => none
  | byte :: rest =>
    if byte = 48 then
      match rest with
      | next :: _ => if digitByte next then none else some (0, rest)
      | [] => some (0, [])
    else if decide (49 ≤ byte ∧ byte ≤ 57) then
      some (parseDigits rest (byte - 48))
    else none

mutual
  /-- Independent, fuelled parser. Whitespace, escape sequences, signs,
      decimals, bool and null have no admitting parser case. -/
  def parseRaw : Nat → Nat → List Nat → Option (Raw × List Nat)
    | 0, _, _ => none
    | _ + 1, 0, _ => none
    | _ + 1, _ + 1, 34 :: rest => do
      let (bytes, suffix) ← parseStringTail rest []
      pure (.str bytes, suffix)
    | _ + 1, _ + 1, 91 :: 93 :: rest => some (.arr [], rest)
    | fuel + 1, depth + 1, 91 :: rest => do
      let (items, suffix) ← parseItems fuel depth rest
      pure (.arr items, suffix)
    | _ + 1, _ + 1, 123 :: 125 :: rest => some (.obj [], rest)
    | fuel + 1, depth + 1, 123 :: rest => do
      let (fields, suffix) ← parseFields fuel depth rest
      if orderedFields fields then pure (.obj fields, suffix) else none
    | _ + 1, _ + 1, bytes => do
      let (value, suffix) ← parseNumber bytes
      pure (.num value, suffix)

  /-- Nonempty array contents only. A trailing comma therefore cannot pass. -/
  def parseItems : Nat → Nat → List Nat → Option (List Raw × List Nat)
    | 0, _, _ => none
    | fuel + 1, depth, bytes => do
      let (value, suffix) ← parseRaw fuel depth bytes
      match suffix with
      | 93 :: rest => pure ([value], rest)
      | 44 :: rest =>
        let (values, suffix) ← parseItems fuel depth rest
        pure (value :: values, suffix)
      | _ => none

  /-- Nonempty object contents only. Keys must be unescaped strings. -/
  def parseFields : Nat → Nat → List Nat → Option (List (List Nat × Raw) × List Nat)
    | 0, _, _ => none
    | fuel + 1, depth, 34 :: rest => do
      let (key, suffix) ← parseStringTail rest []
      match suffix with
      | 58 :: rest =>
        let (value, suffix) ← parseRaw fuel depth rest
        match suffix with
        | 125 :: rest => pure ([(key, value)], rest)
        | 44 :: rest =>
          let (fields, suffix) ← parseFields fuel depth rest
          pure ((key, value) :: fields, suffix)
        | _ => none
      | _ => none
    | _ + 1, _, _ => none
end

/-- Full consumption, exact byte limit, and whole-tree node limit are mandatory.
    Parser recursion is bounded independently of the value-node counter. -/
def decode (bytes : List Nat) : Option Raw :=
  if bytes.length ≤ transportByteLimit ∧
      bytes.all (fun byte => decide (byte ≤ 255)) = true then
    match parseRaw transportFuel transportDepth bytes with
    | some (raw, []) => if withinBounds raw then some raw else none
    | _ => none
  else none

/-- Successful encoding includes a decoder equality check, not an assumption
    that structurally different inputs cannot happen to emit equal bytes. -/
def checkedEncode (raw : Raw) : Option (List Nat) :=
  match serializeChecked raw with
  | none => none
  | some bytes => if decode bytes = some raw then some bytes else none

/-- Compose separately kernel-checked computational certificates without
    weakening the full byte equality or any transport bound. The premises
    concern the same raw tree and the same independently supplied byte list. -/
theorem checkedEncode_of_parts (raw : Raw) (bytes : List Nat)
    (bounds : withinBounds raw = true)
    (serialized : serializeRaw transportFuel transportDepth raw = some bytes)
    (parsed : parseRaw transportFuel transportDepth bytes = some (raw, []))
    (boundedLength : bytes.length ≤ transportByteLimit)
    (byteRange : bytes.all (fun byte => decide (byte ≤ 255)) = true) :
    checkedEncode raw = some bytes := by
  have encoded : serializeChecked raw = some bytes := by
    simp [serializeChecked, bounds, serialized, boundedLength]
  have decoded : decode bytes = some raw := by
    simp [decode, boundedLength, byteRange, parsed, bounds]
  simp [checkedEncode, encoded, decoded]

/-- Generic checked round trip. This says nothing about unaccepted inputs. -/
theorem checkedEncode_roundtrip (raw : Raw) (bytes : List Nat)
    (accepted : checkedEncode raw = some bytes) : decode bytes = some raw := by
  unfold checkedEncode at accepted
  cases encoded : serializeChecked raw with
  | none => simp [encoded] at accepted
  | some candidate =>
    by_cases parsed : decode candidate = some raw
    · have same : candidate = bytes := by simpa [encoded, parsed] using accepted
      simpa [same] using parsed
    · simp [encoded, parsed] at accepted

/-- Equal accepted bytes identify one inert whole-document Raw tree. The proof
    uses decoder equality and does not postulate serializer injectivity. -/
theorem checkedEncode_determinate (a b : Raw) (bytes : List Nat)
    (left : checkedEncode a = some bytes)
    (right : checkedEncode b = some bytes) : a = b := by
  have decodedLeft := checkedEncode_roundtrip a bytes left
  have decodedRight := checkedEncode_roundtrip b bytes right
  exact Option.some.inj (decodedLeft.symm.trans decodedRight)


end HiaCoreSyntaxSlice

#print axioms HiaCoreSyntaxSlice.checkedEncode_determinate
#print axioms HiaCoreSyntaxSlice.checkedEncode_of_parts
#print axioms HiaCoreSyntaxSlice.checkedEncode_roundtrip
/-!
UNCHECKED helper proof text until the pinned Lean 4.19 kernel accepts it.
Append after the exact transport portion of CoreSyntaxSlice.lean. No imports.

These are one-step equalities for the existing functions, not replacement
semantics. The f/d parameters are the precise child call arguments. No rule
resets fuel, drops a suffix, admits a numeric boundary, or supplies a fact from
Python. Concrete leaf certificates and all byte/source bindings remain required.
-/

namespace HiaCoreSyntaxSlice.Structured

/-- The child list call uses exactly f and d. -/
theorem serialize_array (f d : Nat) (items : List Raw) (output : List Nat)
    (children : serializeItems f d items = some output) :
    serializeRaw (f + 1) (d + 1) (.arr items) =
      some (91 :: (output ++ [93])) := by
  simp [serializeRaw, children]

theorem serialize_object (f d : Nat) (fields : List (List Nat × Raw))
    (output : List Nat) (ordered : orderedFields fields = true)
    (children : serializeFields f d fields = some output) :
    serializeRaw (f + 1) (d + 1) (.obj fields) =
      some (123 :: (output ++ [125])) := by
  simp [serializeRaw, ordered, children]

theorem serialize_items_nil (f d : Nat) :
    serializeItems f d [] = some [] := by
  cases f <;> rfl

theorem serialize_items_single (f d : Nat) (value : Raw) (output : List Nat)
    (child : serializeRaw f d value = some output) :
    serializeItems (f + 1) d [value] = some output := by
  simp [serializeItems, child]

theorem serialize_items_cons (f d : Nat) (value next : Raw) (rest : List Raw)
    (output suffix : List Nat)
    (child : serializeRaw f d value = some output)
    (children : serializeItems f d (next :: rest) = some suffix) :
    serializeItems (f + 1) d (value :: next :: rest) =
      some (output ++ (44 :: suffix)) := by
  simp [serializeItems, child, children]

theorem serialize_fields_nil (f d : Nat) :
    serializeFields f d [] = some [] := by
  cases f <;> rfl

theorem serialize_fields_single (f d : Nat) (key : List Nat) (value : Raw)
    (output : List Nat) (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output) :
    serializeFields (f + 1) d [(key, value)] =
      some (34 :: (key ++ (34 :: 58 :: output))) := by
  simp [serializeFields, keyDomain, child]

theorem serialize_fields_cons (f d : Nat) (key : List Nat) (value : Raw)
    (next : List Nat × Raw) (rest : List (List Nat × Raw))
    (output suffix : List Nat) (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output)
    (children : serializeFields f d (next :: rest) = some suffix) :
    serializeFields (f + 1) d ((key, value) :: next :: rest) =
      some ((34 :: (key ++ (34 :: 58 :: output))) ++ (44 :: suffix)) := by
  simp [serializeFields, keyDomain, child, children]

theorem serialize_string (f d : Nat) (value : List Nat)
    (domain : stringBytes value = true) :
    serializeRaw (f + 1) (d + 1) (.str value) =
      some (34 :: (value ++ [34])) := by
  simp [serializeRaw, domain]

theorem serialize_number (f d value : Nat) (output : List Nat)
    (digits : decimal value = some output) :
    serializeRaw (f + 1) (d + 1) (.num value) = some output := by
  simp [serializeRaw, digits]

/-- Exclude the earlier empty-array pattern before applying the list rule. -/
theorem parse_array (f d : Nat) (input tail : List Nat) (items : List Raw)
    (notEmptyClose : input.head? ≠ some 93)
    (children : parseItems f d input = some (items, tail)) :
    parseRaw (f + 1) (d + 1) (91 :: input) = some (.arr items, tail) := by
  unfold parseRaw
  split
  case h_1 => omega
  case h_2 => omega
  case h_3 =>
    rename_i hinput
    have bad : (91 : Nat) = 34 := (List.cons.inj hinput).1
    omega
  case h_4 =>
    rename_i hinput
    exact False.elim
      (notEmptyClose (congrArg List.head? (List.cons.inj hinput).2))
  case h_5 =>
    rename_i childFuel childDepth rest excluded hf hd hinput
    have fuelEq : f = childFuel := Nat.succ.inj hf
    have depthEq : d = childDepth := Nat.succ.inj hd
    have inputEq : input = rest := (List.cons.inj hinput).2
    rw [← fuelEq, ← depthEq, ← inputEq, children] <;> rfl
  case h_6 =>
    rename_i hinput
    have bad : (91 : Nat) = 123 := (List.cons.inj hinput).1
    omega
  case h_7 =>
    rename_i hinput
    have bad : (91 : Nat) = 123 := (List.cons.inj hinput).1
    omega
  case h_8 =>
    rename_i noString noEmptyArray noArray noEmptyObject noObject
    exact False.elim (noArray input rfl)

/-- The explicit opening quote excludes the earlier empty-object pattern. -/
theorem parse_object (f d : Nat) (input tail : List Nat)
    (fields : List (List Nat × Raw))
    (ordered : orderedFields fields = true)
    (children : parseFields f d (34 :: input) = some (fields, tail)) :
    parseRaw (f + 1) (d + 1) (123 :: 34 :: input) =
      some (.obj fields, tail) := by
  simp [parseRaw, children, ordered]

theorem parse_items_last (f d : Nat) (input tail : List Nat) (value : Raw)
    (child : parseRaw f d input = some (value, 93 :: tail)) :
    parseItems (f + 1) d input = some ([value], tail) := by
  simp [parseItems, child]

theorem parse_items_cons (f d : Nat) (input middle tail : List Nat)
    (value : Raw) (rest : List Raw)
    (child : parseRaw f d input = some (value, 44 :: middle))
    (children : parseItems f d middle = some (rest, tail)) :
    parseItems (f + 1) d input = some (value :: rest, tail) := by
  simp [parseItems, child, children]

theorem parse_fields_last (f d : Nat) (keyInput key valueInput tail : List Nat)
    (value : Raw)
    (keyRead : parseStringTail keyInput [] = some (key, 58 :: valueInput))
    (child : parseRaw f d valueInput = some (value, 125 :: tail)) :
    parseFields (f + 1) d (34 :: keyInput) = some ([(key, value)], tail) := by
  simp [parseFields, keyRead, child]

theorem parse_fields_cons (f d : Nat)
    (keyInput key valueInput middle tail : List Nat)
    (value : Raw) (rest : List (List Nat × Raw))
    (keyRead : parseStringTail keyInput [] = some (key, 58 :: valueInput))
    (child : parseRaw f d valueInput = some (value, 44 :: middle))
    (children : parseFields f d middle = some (rest, tail)) :
    parseFields (f + 1) d (34 :: keyInput) = some ((key, value) :: rest, tail) := by
  simp [parseFields, keyRead, child, children]

theorem parse_empty_array (f d : Nat) (tail : List Nat) :
    parseRaw (f + 1) (d + 1) (91 :: 93 :: tail) = some (.arr [], tail) := by
  rfl

theorem parse_empty_object (f d : Nat) (tail : List Nat) :
    parseRaw (f + 1) (d + 1) (123 :: 125 :: tail) = some (.obj [], tail) := by
  rfl

theorem parse_string (f d : Nat) (input value tail : List Nat)
    (characters : parseStringTail input [] = some (value, tail)) :
    parseRaw (f + 1) (d + 1) (34 :: input) = some (.str value, tail) := by
  simp [parseRaw, characters]

/-- Reading a valid quoted prefix does not inspect the suffix after its quote.
    The accumulator form supports induction without assumptions about that suffix. -/
theorem parse_string_tail_prefix (segment suffix acc : List Nat) :
    stringBytes segment = true →
    parseStringTail (segment ++ (34 :: suffix)) acc =
      some (acc.reverse ++ segment, suffix) := by
  induction segment generalizing acc with
  | nil =>
    intro _domain
    simp [parseStringTail]
  | cons first rest previous =>
    intro domain
    have parts : stringByte first = true ∧ stringBytes rest = true := by
      simpa only [stringBytes, Bool.and_eq_true] using domain
    have allowed : 32 ≤ first ∧ first ≤ 126 ∧ first ≠ 34 ∧ first ≠ 92 := by
      simpa [stringByte] using parts.1
    have notQuote : first ≠ 34 := allowed.2.2.1
    have remaining := previous (first :: acc) parts.2
    simpa [parseStringTail, notQuote, parts.1, List.reverse_cons, List.append_assoc]
      using remaining

/-- A key packet supplies its checked domain and this symbolic-tail equation. -/
theorem parse_key_prefix (key tail : List Nat) (domain : stringBytes key = true) :
    parseStringTail (key ++ (34 :: 58 :: tail)) [] = some (key, 58 :: tail) := by
  simpa using parse_string_tail_prefix key (58 :: tail) [] domain

/-
Leaf-generation contract (not an extra theorem or assumed fact):

For nonnumeric complete leaf bytes b and Raw r at exact F,D, prove
  ∀ tail, parseRaw F D (b ++ tail) = some (r, tail).
For a numeric leaf use its actual structural delimiter c ∈ {44,93,125}:
  ∀ tail, parseRaw F D (b ++ (c :: tail)) = some (r, c :: tail).
For a key k, prove stringBytes k = true and
  ∀ tail, parseStringTail (k ++ (34 :: 58 :: tail)) [] = some (k, 58 :: tail).

These are closed small-prefix proofs after introducing the symbolic tail.
Unfold only the local leaf/key definitions. Never replace the numeric form with
an arbitrary-suffix extension rule: decimal bytes [49] followed by [50] parse
as 12. Root composition must still return the exact empty suffix.
-/

/-- Decimal digits cannot be split by an arbitrary suffix-extension rule. -/
theorem reject_numeric_split :
    ¬ (parseRaw 2 2 [49, 50] = some (.num 1, [50])) := by
  intro claim
  change some (Raw.num 12, ([] : List Nat)) = some (Raw.num 1, [50]) at claim
  have tails : ([] : List Nat) = [50] := congrArg Prod.snd (Option.some.inj claim)
  cases tails

/-- A colon cannot replace the comma between two array items. -/
theorem reject_wrong_separator :
    ¬ (parseRaw 8 4 [91, 49, 58, 50, 93] =
      some (.arr [.num 1, .num 2], [])) := by
  decide +kernel

/-- An object close cannot terminate an array. -/
theorem reject_wrong_closing :
    ¬ (parseRaw 8 4 [91, 49, 125] = some (.arr [.num 1], [])) := by
  decide +kernel

/-- A successful prefix parse does not authorize dropping remaining bytes. -/
theorem reject_trailing_bytes :
    ¬ (parseRaw 2 2 [91, 93, 48] = some (.arr [], [])) ∧
    ¬ (decode [91, 93, 48] = some (.arr [])) := by
  constructor
  · intro claim
    change some (Raw.arr [], [48]) = some (Raw.arr [], ([] : List Nat)) at claim
    have tails : [48] = ([] : List Nat) := congrArg Prod.snd (Option.some.inj claim)
    cases tails
  · intro claim
    change none = some (Raw.arr []) at claim
    cases claim

theorem reject_insufficient_fuel :
    ¬ (parseRaw 0 2 [48] = some (.num 0, [])) := by
  decide +kernel

theorem reject_insufficient_depth :
    ¬ (parseRaw 2 0 [48] = some (.num 0, [])) := by
  decide +kernel

/-- Fixed Raw cannot justify a different literal byte inside its encoding. -/
theorem reject_changed_leaf_byte :
    ¬ (serializeRaw 2 2 (.str [97]) = some [34, 98, 34]) := by
  decide +kernel

/-- Both distinct sufficient fuel values succeed. Fuel inequality alone is
    not a sound negative-control criterion. -/
theorem reject_distinct_sufficient_fuel_failure :
    ¬ (parseRaw 1 1 [48] ≠ some (.num 0, []) ∨
       parseRaw 2 1 [48] ≠ some (.num 0, [])) := by
  intro failure
  cases failure with
  | inl rejected => exact rejected rfl
  | inr rejected => exact rejected rfl

end HiaCoreSyntaxSlice.Structured
#print axioms HiaCoreSyntaxSlice.Structured.parse_array
#print axioms HiaCoreSyntaxSlice.Structured.parse_empty_array
#print axioms HiaCoreSyntaxSlice.Structured.parse_empty_object
#print axioms HiaCoreSyntaxSlice.Structured.parse_fields_cons
#print axioms HiaCoreSyntaxSlice.Structured.parse_fields_last
#print axioms HiaCoreSyntaxSlice.Structured.parse_items_cons
#print axioms HiaCoreSyntaxSlice.Structured.parse_items_last
#print axioms HiaCoreSyntaxSlice.Structured.parse_key_prefix
#print axioms HiaCoreSyntaxSlice.Structured.parse_object
#print axioms HiaCoreSyntaxSlice.Structured.parse_string
#print axioms HiaCoreSyntaxSlice.Structured.parse_string_tail_prefix
#print axioms HiaCoreSyntaxSlice.Structured.reject_changed_leaf_byte
#print axioms HiaCoreSyntaxSlice.Structured.reject_distinct_sufficient_fuel_failure
#print axioms HiaCoreSyntaxSlice.Structured.reject_insufficient_depth
#print axioms HiaCoreSyntaxSlice.Structured.reject_insufficient_fuel
#print axioms HiaCoreSyntaxSlice.Structured.reject_numeric_split
#print axioms HiaCoreSyntaxSlice.Structured.reject_trailing_bytes
#print axioms HiaCoreSyntaxSlice.Structured.reject_wrong_closing
#print axioms HiaCoreSyntaxSlice.Structured.reject_wrong_separator
#print axioms HiaCoreSyntaxSlice.Structured.serialize_array
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_cons
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_nil
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_single
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_cons
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_nil
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_single
#print axioms HiaCoreSyntaxSlice.Structured.serialize_number
#print axioms HiaCoreSyntaxSlice.Structured.serialize_object
#print axioms HiaCoreSyntaxSlice.Structured.serialize_string
/-!
UNCHECKED Lean 4.19 proof text for the source-only byte-facts experiment.
Insert this fragment in SyntaxData; no additional import is required.
Pinned library declarations were source-checked at leanprover/lean4 v4.19.0:
Init/Data/List/Basic.lean: length_cons, all_cons, length_append.
Init/Data/List/Lemmas.lean: all_append.
Init/Prelude.lean: decide_eq_true.
This fragment has not been elaborated or kernel-checked.
-/

namespace HiaCoreSyntaxSlice.ByteFactsResearch

def facts (xs : List Nat) (n : Nat) : Prop :=
  xs.length = n ∧ xs.all (fun b => decide (b ≤ 255)) = true

theorem nil : facts ([] : List Nat) (0 : Nat) := by
  exact ⟨rfl, rfl⟩

theorem cons (b : Nat) (xs : List Nat) (n : Nat)
    (byteBound : b ≤ 255) (child : facts xs n) : facts (b :: xs) (n + 1) := by
  constructor
  · rw [List.length_cons, child.1]
  · rw [List.all_cons, decide_eq_true byteBound, child.2]
    rfl

theorem append (xs ys : List Nat) (n m : Nat)
    (left : facts xs n) (right : facts ys m) : facts (xs ++ ys) (n + m) := by
  constructor
  · rw [List.length_append, left.1, right.1]
  · rw [List.all_append, left.2, right.2]
    rfl

end HiaCoreSyntaxSlice.ByteFactsResearch
#print axioms HiaCoreSyntaxSlice.ByteFactsResearch.append
#print axioms HiaCoreSyntaxSlice.ByteFactsResearch.cons
#print axioms HiaCoreSyntaxSlice.ByteFactsResearch.nil
/-!
Symbolic composition equalities for the existing transport functions.
Append after StructuredTransport.lean; no imports or new axioms.
The list rewrites are checked once with abstract byte lists, before concrete
whole-document terms are substituted. Every concrete child certificate remains
an explicit premise. These declarations do not evaluate or trust Python data.
-/
namespace HiaCoreSyntaxSlice.Shared

theorem serialize_fields_single_packet (f d : Nat) (key : List Nat) (value : Raw)
    (output packet : List Nat)
    (packetShape : packet = 34 :: (key ++ [34, 58]))
    (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output) :
    serializeFields (f + 1) d [(key, value)] = some (packet ++ output) := by
  simpa only [packetShape, List.append_assoc, List.cons_append, List.nil_append,
    List.append_nil] using
    (Structured.serialize_fields_single f d key value output keyDomain child)

theorem serialize_fields_cons_packet (f d : Nat) (key : List Nat) (value : Raw)
    (next : List Nat × Raw) (rest : List (List Nat × Raw))
    (output suffix packet : List Nat)
    (packetShape : packet = 34 :: (key ++ [34, 58]))
    (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output)
    (children : serializeFields f d (next :: rest) = some suffix) :
    serializeFields (f + 1) d ((key, value) :: next :: rest) =
      some ((packet ++ output) ++ (44 :: suffix)) := by
  simpa only [packetShape, List.append_assoc, List.cons_append, List.nil_append,
    List.append_nil] using
    (Structured.serialize_fields_cons f d key value next rest output suffix
      keyDomain child children)

theorem parse_fields_last_packet (f d : Nat) (key : List Nat) (value : Raw)
    (output packet tail : List Nat)
    (packetShape : packet = 34 :: (key ++ [34, 58]))
    (keyRead : parseStringTail (key ++ (34 :: 58 :: (output ++ (125 :: tail)))) [] =
      some (key, 58 :: (output ++ (125 :: tail))))
    (child : parseRaw f d (output ++ (125 :: tail)) = some (value, 125 :: tail)) :
    parseFields (f + 1) d ((packet ++ output) ++ (125 :: tail)) =
      some ([(key, value)], tail) := by
  simpa only [packetShape, List.append_assoc, List.cons_append, List.nil_append,
    List.append_nil] using
    (Structured.parse_fields_last f d
      (key ++ (34 :: 58 :: (output ++ (125 :: tail)))) key
      (output ++ (125 :: tail)) tail value keyRead child)

theorem parse_fields_cons_packet (f d : Nat) (key : List Nat) (value : Raw)
    (rest : List (List Nat × Raw)) (output suffix packet tail : List Nat)
    (packetShape : packet = 34 :: (key ++ [34, 58]))
    (keyRead : parseStringTail
      (key ++ (34 :: 58 :: (output ++ (44 :: (suffix ++ (125 :: tail)))))) [] =
      some (key, 58 :: (output ++ (44 :: (suffix ++ (125 :: tail))))))
    (child : parseRaw f d (output ++ (44 :: (suffix ++ (125 :: tail)))) =
      some (value, 44 :: (suffix ++ (125 :: tail))))
    (children : parseFields f d (suffix ++ (125 :: tail)) = some (rest, tail)) :
    parseFields (f + 1) d (((packet ++ output) ++ (44 :: suffix)) ++ (125 :: tail)) =
      some ((key, value) :: rest, tail) := by
  simpa only [packetShape, List.append_assoc, List.cons_append, List.nil_append,
    List.append_nil] using
    (Structured.parse_fields_cons f d
      (key ++ (34 :: 58 :: (output ++ (44 :: (suffix ++ (125 :: tail)))))) key
      (output ++ (44 :: (suffix ++ (125 :: tail)))) (suffix ++ (125 :: tail))
      tail value rest keyRead child children)

theorem parse_items_cons_bytes (f d : Nat) (value : Raw) (rest : List Raw)
    (output suffix tail : List Nat)
    (child : parseRaw f d (output ++ (44 :: (suffix ++ (93 :: tail)))) =
      some (value, 44 :: (suffix ++ (93 :: tail))))
    (children : parseItems f d (suffix ++ (93 :: tail)) = some (rest, tail)) :
    parseItems (f + 1) d ((output ++ (44 :: suffix)) ++ (93 :: tail)) =
      some (value :: rest, tail) := by
  simpa only [List.append_assoc, List.cons_append] using
    (Structured.parse_items_cons f d (output ++ (44 :: (suffix ++ (93 :: tail))))
      (suffix ++ (93 :: tail)) tail value rest child children)

theorem parse_array_bytes (f d : Nat) (items : List Raw) (body tail : List Nat)
    (notEmptyClose : (body ++ (93 :: tail)).head? ≠ some 93)
    (children : parseItems f d (body ++ (93 :: tail)) = some (items, tail)) :
    parseRaw (f + 1) (d + 1) ((91 :: (body ++ [93])) ++ tail) =
      some (.arr items, tail) := by
  simpa only [List.append_assoc, List.cons_append, List.nil_append] using
    (Structured.parse_array f d (body ++ (93 :: tail)) tail items notEmptyClose children)

theorem parse_object_bytes (f d : Nat) (fields : List (List Nat × Raw))
    (body tail : List Nat) (head : body.head? = some 34)
    (ordered : orderedFields fields = true)
    (children : parseFields f d (body ++ (125 :: tail)) = some (fields, tail)) :
    parseRaw (f + 1) (d + 1) ((123 :: (body ++ [125])) ++ tail) =
      some (.obj fields, tail) := by
  cases body with
  | nil => cases head
  | cons first rest =>
    have same : first = 34 := Option.some.inj head
    subst first
    simpa only [List.append_assoc, List.cons_append, List.nil_append] using
      (Structured.parse_object f d (rest ++ (125 :: tail)) tail fields ordered
        (by simpa only [List.cons_append] using children))

theorem parse_root (f d : Nat) (raw : Raw) (bytes : List Nat)
    (parsed : ∀ tail, parseRaw f d (bytes ++ tail) = some (raw, tail)) :
    parseRaw f d bytes = some (raw, []) := by
  simpa only [List.append_nil] using parsed []

theorem serialize_string_rebase (f d g e : Nat) (value output : List Nat)
    (first : serializeRaw (f + 1) (d + 1) (.str value) = some output) :
    serializeRaw (g + 1) (e + 1) (.str value) = some output := by
  exact first

theorem parse_string_rebase (f d g e : Nat) (value input : List Nat)
    (first : ∀ tail, parseRaw (f + 1) (d + 1) (34 :: (input ++ tail)) =
      some (.str value, tail)) :
    ∀ tail, parseRaw (g + 1) (e + 1) (34 :: (input ++ tail)) =
      some (.str value, tail) := by
  exact first

theorem parse_string_rebase_bound (f d g e : Nat) (raw nextRaw : Raw)
    (bytes nextBytes input : List Nat)
    (shape : bytes = 34 :: input) (sameBytes : nextBytes = bytes)
    (sameRaw : nextRaw = raw)
    (first : ∀ tail, parseRaw (f + 1) (d + 1) (bytes ++ tail) = some (raw, tail)) :
    ∀ tail, parseRaw (g + 1) (e + 1) (nextBytes ++ tail) = some (nextRaw, tail) := by
  subst nextRaw
  subst nextBytes
  subst bytes
  exact first

end HiaCoreSyntaxSlice.Shared
#print axioms HiaCoreSyntaxSlice.Shared.parse_array_bytes
#print axioms HiaCoreSyntaxSlice.Shared.parse_fields_cons_packet
#print axioms HiaCoreSyntaxSlice.Shared.parse_fields_last_packet
#print axioms HiaCoreSyntaxSlice.Shared.parse_items_cons_bytes
#print axioms HiaCoreSyntaxSlice.Shared.parse_object_bytes
#print axioms HiaCoreSyntaxSlice.Shared.parse_root
#print axioms HiaCoreSyntaxSlice.Shared.parse_string_rebase
#print axioms HiaCoreSyntaxSlice.Shared.parse_string_rebase_bound
#print axioms HiaCoreSyntaxSlice.Shared.serialize_fields_cons_packet
#print axioms HiaCoreSyntaxSlice.Shared.serialize_fields_single_packet
#print axioms HiaCoreSyntaxSlice.Shared.serialize_string_rebase
