#!/usr/bin/env python3
"""Prepare exact-source native artifacts and source closure for a second host."""
from __future__ import annotations
import argparse,gzip,hashlib,io,json,os,pathlib,platform,resource,shutil,subprocess,sys,tarfile,time

def ident(p):
 p=pathlib.Path(p);b=p.read_bytes()
 return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def encoded(v):
 return json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n'

def put(p,raw):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(raw)

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--source',required=True);ap.add_argument('--expected-head',required=True)
 ap.add_argument('--output',required=True);ap.add_argument('--clang',required=True)
 a=ap.parse_args()
 src=pathlib.Path(a.source).resolve();out=pathlib.Path(a.output).resolve()
 out.mkdir(parents=True,exist_ok=False)
 os.sched_setaffinity(0,{8,9})
 os.environ['PYTHONDONTWRITEBYTECODE']='1'
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 clean_env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
 def git(*args):
  return subprocess.run(['git','--no-replace-objects',*args],cwd=src,env=clean_env,
                        capture_output=True,check=True).stdout
 def state():
  head,tree=git('show','--no-patch','--format=%H%n%T','HEAD').decode().strip().splitlines()
  return {'commit':head,'tree':tree,'status':git('status','--porcelain=v1','--untracked-files=all').decode()}
 before=state()
 assert before['commit']==a.expected_head and before['status']=='',before
 compiler=ident(a.clang)
 started=time.monotonic_ns()
 plan={'schema':'hepta.hia.second-host-preparation.v1','source':before,'compiler':compiler,
       'build_and_reference_execution_host':'desktop','target_execution_host':'x230',
       'host':{'machine':platform.machine(),'kernel':platform.release(),'cpu_affinity':sorted(os.sched_getaffinity(0))},
       'python':ident(sys.executable),'runner':ident(__file__),
       'stage_order':['host-region','host-region-race'],'stage_budget_seconds':120,
       'claims':{'cross_host_performance_comparison':False,'new_isa_support':False,
                 'target_host_compiler_qualification':False,'full_runtime_custody':False}}
 put(out/'REGISTRATION.json',encoded(plan))
 sys.path.insert(0,str(src))
 from experiments.hia_round4_20261105.run_frozen_candidate import run_with_deadline
 rows=[];reports=[]
 for name,tool in [('host-region','tools/qualify_hia_host_region.py'),('host-region-race','tools/qualify_hia_host_region_race.py')]:
  logs=out/(name+'-outer');logs.mkdir()
  argv=[sys.executable,'-B',str(src/tool),'--output',str(out/name),'--clang',str(pathlib.Path(a.clang).resolve())]
  start=time.monotonic_ns()
  with (logs/'stdout').open('xb') as stdout,(logs/'stderr').open('xb') as stderr:
   result=run_with_deadline(argv,120,cwd=src,env=clean_env,stdout=stdout,stderr=stderr)
  row={'name':name,'argv':argv,'returncode':result.returncode,'wall_ns':time.monotonic_ns()-start,
       'stdout':ident(logs/'stdout'),'stderr':ident(logs/'stderr')}
  if (out/name/'RESULT.json').is_file():
   report=json.loads((out/name/'RESULT.json').read_bytes())
   row['report']=ident(out/name/'RESULT.json')
   row['semantic_qualification']=report.get('qualification_valid') is True
   reports.append(report)
  else:row['semantic_qualification']=False
  rows.append(row);put(logs/'COMMAND.json',encoded(row))
 after=state()
 accepted=(len(reports)==2 and all(r['returncode']==0 and r['semantic_qualification'] for r in rows)
           and before==after and compiler==ident(a.clang))
 summary={'schema':plan['schema'],'source_before':before,'source_after':after,'compiler':compiler,
          'python':plan['python'],'rows':rows,'passed':accepted,'wall_ns':time.monotonic_ns()-started}
 put(out/'DESKTOP_RESULT.json',encoded(summary))
 if not accepted:
  print(json.dumps(summary));return 1
 package=out/'package';package.mkdir()
 tracked={}
 for raw in git('ls-tree','-r','-z','--full-tree',a.expected_head).split(b'\0'):
  if not raw:continue
  meta,path=raw.split(b'\t',1);mode,kind,blob=meta.decode().split()
  rel=path.decode()
  if ((rel.startswith('hepta/') and rel.endswith('.py'))
      or rel in ('tools/__init__.py','tools/qualify_hia_host_region.py','tools/qualify_hia_host_region_race.py',
                 'tools/qualify_hia_native_ndu.py','tools/qualify_hia_reduction_release.py')
      or rel.startswith('benchmarks/hia_host_region/')):
   assert kind=='blob' and mode in ('100644','100755'),(rel,kind,mode)
   tracked[rel]={'git_blob':blob,'mode':mode}
 files={}
 for rel,meta in sorted(tracked.items()):
  raw=(src/rel).read_bytes()
  blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  assert blob==meta['git_blob'],rel
  target=package/'source'/rel;put(target,raw)
  files['source/'+rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),**meta}
 copies={
  'artifacts/bridge.so':out/'host-region/bridge.so',
  'artifacts/race-bridge.so':out/'host-region-race/race-bridge.so',
  'build/host-region-RESULT.json':out/'host-region/RESULT.json',
  'build/host-region-race-RESULT.json':out/'host-region-race/RESULT.json',
  'build/DESKTOP_RESULT.json':out/'DESKTOP_RESULT.json'}
 for rel,p in copies.items():
  raw=p.read_bytes();put(package/rel,raw)
  files[rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 assert state()==before and ident(a.clang)==compiler
 manifest={'schema':'hepta.hia.same-artifact-execution-package.v1','source_commit':before['commit'],
           'source_tree':before['tree'],'files':files,'build_receipt':files['build/DESKTOP_RESULT.json'],
           'scope':'Exact committed Python execution closure and unchanged desktop-built native shared objects; not a complete Git checkout or target-host build.',
           'compiler':compiler,'python_build_host':plan['python']}
 put(package/'PACKAGE.json',encoded(manifest))
 archive=out/'x230-package.tar.gz'
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for rel in sorted(set(files)|{'PACKAGE.json'}):
     payload=(package/rel).read_bytes()
     info=tarfile.TarInfo(rel);info.size=len(payload);info.mode=0o644
     info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname=''
     tar.addfile(info,io.BytesIO(payload))
 package_result={'source_commit':before['commit'],'source_tree':before['tree'],
                 'package_file_count':len(files)+1,'package_manifest':ident(package/'PACKAGE.json'),
                 'archive':ident(archive),'desktop_result':ident(out/'DESKTOP_RESULT.json')}
 put(out/'PACKAGE_RESULT.json',encoded(package_result))
 print(json.dumps(package_result),flush=True)
 return 0

if __name__=='__main__':
 raise SystemExit(main())
