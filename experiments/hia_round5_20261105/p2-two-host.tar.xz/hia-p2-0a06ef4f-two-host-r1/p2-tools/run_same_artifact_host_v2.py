#!/usr/bin/env python3
"""Run unchanged host-region execution paths from an exact-source binary package.

This supplemental profile consumes desktop-built native artifacts. It does not
claim a compiler qualification on the consuming host or a new ISA/memory model.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import signal
import subprocess
import sys
import time

EXPECTED={}


def wire(value):
    return json.dumps(value, sort_keys=True, indent=2, allow_nan=False).encode()+b"\n"


def identity(path):
    path=Path(path)
    raw=path.read_bytes()
    return {"path":str(path.resolve()),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}


def write_json(path,value):
    with Path(path).open("xb") as f:
        f.write(wire(value))


def verify_package(package):
    raw=(package/"PACKAGE.json").read_bytes()
    if hashlib.sha256(raw).hexdigest()!=EXPECTED["manifest_sha256"]:
        raise RuntimeError("package manifest differs from external registration")
    manifest=json.loads(raw)
    if manifest["source_commit"]!=EXPECTED["source_commit"] or manifest["source_tree"]!=EXPECTED["source_tree"]:
        raise RuntimeError("package source identity differs from external registration")
    rows=manifest["files"]
    for rel,expected in rows.items():
        if Path(rel).is_absolute() or ".." in Path(rel).parts:
            raise RuntimeError("unsafe package path: "+rel)
        p=package/rel
        if p.is_symlink() or not p.is_file() or not p.resolve().is_relative_to(package):
            raise RuntimeError("package file absent or unsafe: "+rel)
        actual=identity(p)
        if actual["sha256"]!=expected["sha256"] or actual["bytes"]!=expected["bytes"]:
            raise RuntimeError("package content mismatch: "+rel)
    actual_files={str(p.relative_to(package)) for p in package.rglob("*") if p.is_file()}
    if actual_files != set(rows)|{"PACKAGE.json"}:
        raise RuntimeError("package file inventory changed")
    return {"manifest_sha256":hashlib.sha256(raw).hexdigest(),
            "source_commit":manifest["source_commit"],"source_tree":manifest["source_tree"],
            "file_count":len(rows)}


def host_identity():
    model=next((x.split(":",1)[1].strip() for x in Path("/proc/cpuinfo").read_text().splitlines()
                if x.startswith("model name")),None)
    return {"system":platform.system(),"machine":platform.machine(),
            "release":platform.release(),"node":platform.node(),
            "cpu_model":model,"cpu_affinity":sorted(os.sched_getaffinity(0)),
            "python_version":platform.python_version(),"python":identity(sys.executable),
            "python_flags":{"optimize":sys.flags.optimize,"isolated":sys.flags.isolated,
                            "ignore_environment":sys.flags.ignore_environment,
                            "dont_write_bytecode":sys.flags.dont_write_bytecode},
            "byteorder":sys.byteorder,"pointer_bits":__import__("struct").calcsize("P")*8}


def observed_runtime_libraries():
    paths=set()
    for line in Path("/proc/self/maps").read_text().splitlines():
        fields=line.split(maxsplit=5)
        if len(fields)==6 and fields[5].startswith("/") and ".so" in Path(fields[5]).name:
            p=Path(fields[5])
            if p.is_file():
                paths.add(p.resolve())
    return [identity(p) for p in sorted(paths)]


def source_imports(package):
    source=(package/"source").resolve()
    observed={}
    for name,module in list(sys.modules.items()):
        if name not in ("hepta","tools") and not name.startswith(("hepta.","tools.")):
            continue
        file=getattr(module,"__file__",None)
        if file is not None:
            p=Path(file).resolve()
            if not p.is_relative_to(source):
                raise RuntimeError("foreign source module: "+name)
            observed[name]=identity(p)
        else:
            portions=[Path(p).resolve() for p in getattr(module,"__path__",())]
            if not portions or any(not p.is_relative_to(source) for p in portions):
                raise RuntimeError("foreign namespace module: "+name)
            observed[name]={"namespace_paths":[str(p) for p in portions]}
    return observed


def stage(package,out,name):
    before=verify_package(package)
    sys.path.insert(0,str(package/"source"))
    import tools.qualify_hia_host_region as normal
    import tools.qualify_hia_host_region_race as race
    imports_before=source_imports(package)
    if name=="fault":
        # This exact source function sets RLIMIT_CORE=0 and performs a write
        # through a read-only region. Expected terminal state is SIGSEGV.
        normal.fault_child(str(package/"artifacts/bridge.so"),
                           identity(package/"artifacts/bridge.so")["sha256"])
        raise RuntimeError("fault control returned")
    if name=="base":
        execution=normal.exercise(str(package/"artifacts/bridge.so"),
                                  identity(package/"artifacts/bridge.so")["sha256"])
    elif name=="race":
        execution=race.exercise(str(package/"artifacts/race-bridge.so"),
                                identity(package/"artifacts/race-bridge.so")["sha256"])
    else:
        raise ValueError(name)
    after=verify_package(package)
    write_json(out/"RESULT.json",{"stage":name,"status":"completed",
                                "execution":execution,"package_before":before,
                                "package_after":after,"package_unchanged":before==after,
                                "source_imports_before":imports_before,
                                "source_imports_after":source_imports(package),
                                "observed_runtime_libraries_after":observed_runtime_libraries()})
    return 0


def invoke(argv,deadline):
    started=time.monotonic_ns()
    process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                             start_new_session=True)
    timed_out=False
    try:
        out,err=process.communicate(timeout=deadline)
    except subprocess.TimeoutExpired:
        timed_out=True
        try:
            os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:
            pass
        out,err=process.communicate(timeout=2)
    return {"returncode":process.returncode,"timed_out":timed_out,
            "wall_ns":time.monotonic_ns()-started},out,err


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--package",required=True)
    ap.add_argument("--output",required=True)
    ap.add_argument("--expected-manifest-sha256",required=True)
    ap.add_argument("--expected-head",required=True)
    ap.add_argument("--expected-tree",required=True)
    ap.add_argument("--execution-host",required=True,choices=("desktop","x230"))
    ap.add_argument("--stage",choices=("base","race","fault"))
    args=ap.parse_args()
    if sys.flags.optimize!=0 or sys.flags.isolated!=1 or sys.flags.ignore_environment!=1 or not sys.flags.dont_write_bytecode:
        raise RuntimeError("qualification requires python -I -B with assertions enabled")
    EXPECTED.update(manifest_sha256=args.expected_manifest_sha256,
                    source_commit=args.expected_head,source_tree=args.expected_tree)
    package=Path(args.package).resolve()
    out=Path(args.output).resolve()
    os.umask(0o077)
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    if args.stage:
        return stage(package,out,args.stage)
    out.mkdir(parents=True,exist_ok=False)
    started=time.monotonic_ns()
    before=verify_package(package)
    host=host_identity()
    expected=json.loads((package/"PACKAGE.json").read_bytes())
    registration={"schema":"hepta.hia.same-artifact-second-host.v2",
                  "source_commit":before["source_commit"],"source_tree":before["source_tree"],
                  "source_content_identity":before,"host":host,"runner":identity(__file__),
                  "compiler_host":"desktop","execution_host":args.execution_host,
                  "compiler_and_build_receipt":expected["build_receipt"],
                  "profile":"Linux x86-64 coherent hosted RAM; SysV AMD64 LP64; synchronous no-pointer-escape C ABI",
                  "stage_order":["base","fault","race"],"stage_deadlines_seconds":{"base":90,"fault":10,"race":90},
                  "claims":{"target_host_compiler_qualification":False,"second_isa_supported":False,
                            "all_schedules_exhausted":False,"device_dma_mmio_supported":False,
                            "whole_language_memory_model_proved":False,"performance_advantage":False,
                            "transitive_runtime_hermetic_custody":False}}
    write_json(out/"REGISTRATION.json",registration)
    rows=[]
    try:
        for name in registration["stage_order"]:
            stage_out=out/name
            stage_out.mkdir()
            argv=[sys.executable,"-I","-B",str(Path(__file__).resolve()),
                  "--package",str(package),"--output",str(stage_out),"--stage",name,
                  "--expected-manifest-sha256",args.expected_manifest_sha256,
                  "--expected-head",args.expected_head,"--expected-tree",args.expected_tree,
                  "--execution-host",args.execution_host]
            receipt,stdout,stderr=invoke(argv,registration["stage_deadlines_seconds"][name])
            (stage_out/"stdout").write_bytes(stdout)
            (stage_out/"stderr").write_bytes(stderr)
            wanted=-signal.SIGSEGV if name=="fault" else 0
            receipt.update(stage=name,argv=argv,expected_returncode=wanted,
                           passed=not receipt["timed_out"] and receipt["returncode"]==wanted,
                           stdout=identity(stage_out/"stdout"),stderr=identity(stage_out/"stderr"))
            if name=="fault":
                receipt["entered_expected_fault_control"]=(stdout==b"deliberate false FFI read contract: native write must SIGSEGV\n")
                receipt["passed"] &= receipt["entered_expected_fault_control"]
            else:
                result_path=stage_out/"RESULT.json"
                receipt["semantic_result_verified"]=False
                if result_path.is_file():
                    receipt["result"]=identity(result_path)
                    result=json.loads(result_path.read_bytes())
                    retained=result["execution"]["retained_after"]
                    receipt["semantic_result_verified"]=(result["stage"]==name and result["status"]=="completed"
                        and result["package_before"]==before==result["package_after"] and result["package_unchanged"]
                        and not retained["regions"] and not retained["libraries"])
                receipt["passed"] &= receipt["semantic_result_verified"]
            write_json(stage_out/"COMMAND.json",receipt)
            rows.append(receipt)
        after=verify_package(package)
        report={"schema":registration["schema"],"source_commit":before["source_commit"],
                "source_tree":before["source_tree"],"stages":rows,"source_before":before,
                "source_after":after,"source_and_artifacts_unchanged":before==after,
                "host_before":host,"host_after":host_identity(),"runner":identity(__file__),
                "claims":registration["claims"],"wall_ns":time.monotonic_ns()-started}
        report["passed"]=all(x["passed"] for x in rows) and before==after and report["host_before"]==report["host_after"]
    except BaseException as error:
        report={"schema":registration["schema"],"source_commit":before["source_commit"],
                "source_tree":before["source_tree"],"stages":rows,"passed":False,
                "error":{"type":type(error).__name__,"message":str(error)},
                "wall_ns":time.monotonic_ns()-started}
    write_json(out/"RESULT.json",report)
    print(json.dumps({"passed":report["passed"],"source_commit":before["source_commit"],
                      "stages":[{"stage":r["stage"],"passed":r["passed"],
                                 "returncode":r["returncode"]} for r in rows],
                      "wall_ns":report["wall_ns"]}),flush=True)
    return 0 if report["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
