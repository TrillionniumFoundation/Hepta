#!/usr/bin/env python3
"""Four-language native measurements consumed by the existing stateful NDU.

Owns only research fixtures and evidence. All policies receive the same frozen
training observations and current request size; future timings are not inputs.
An executed negative economics result is a valid result, not a reason to retry.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import platform
import re
try:
    import resource
except ImportError:  # Keep pure-model/control test discovery portable.
    resource = None
import selectors
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
FIXTURES = ROOT / "benchmarks/hia_native_ndu"
METRIC_NAMES = ("attempts", "allocations", "frees", "refusals", "live",
    "requested_total", "usable_total", "peak_requested", "peak_usable",
    "live_requested", "live_usable", "accounting_errors", "stack_anchor", "stack_max_distance")
MASK32 = (1 << 32) - 1


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return sha256(wire(value)).hexdigest()


def file_identity(path):
    path = Path(path)
    return {"path": str(path.resolve()), "bytes": path.stat().st_size,
            "sha256": sha256(path.read_bytes()).hexdigest()}


def check_runtime_inputs(report):
    """Reconcile built libraries, driver and tool bytes with their observations.

    These are before/after checks under the existing trusted-host contract,
    not custody against a hostile process changing a file between observations.
    Missing inputs or a failed read cannot leave an acceptance result valid.
    """
    started = time.monotonic_ns()
    raw_products, raw_tools = report.get("native_artifacts"), report.get("toolchains")
    products = raw_products if type(raw_products) is dict else {}
    tools = raw_tools if type(raw_tools) is dict else {}
    complete = (set(products) == {"c", "cpp", "rust", "hia"}
                and {"clang", "rustc", "objdump"} <= set(tools)
                and type(report.get("driver_identity")) is dict)
    expected = {"library:" + name: value for name, value in products.items()}
    expected.update({"tool:" + name: value for name, value in tools.items()})
    expected["driver"] = report.get("driver_identity")
    checks = {}
    for name, before in expected.items():
        row = {"before": before, "unchanged": False}
        try:
            after = file_identity(before["path"])
            row["after"] = after
            row["unchanged"] = all(after[key] == before[key]
                                   for key in ("path", "bytes", "sha256"))
        except (OSError, TypeError, KeyError, ValueError) as error:
            row["error"] = {"type": type(error).__name__, "message": str(error)}
        checks[name] = row
    report["runtime_input_checks"] = checks
    report["runtime_inputs_unchanged"] = bool(complete and all(row["unchanged"] for row in checks.values()))
    report["runtime_identity_check_ns"] = time.monotonic_ns() - started
    return report["runtime_inputs_unchanged"]


def require(condition, message):
    if not condition:
        raise ValueError("E_HIA_NATIVE_ECONOMICS: " + message)


def protocol(controller_profile="full-model-v3"):
    require(controller_profile in {"full-model-v3", "prepared-bank-v1"}, "unknown controller profile")
    name = "PREPARED_GATE_PROTOCOL.json" if controller_profile == "prepared-bank-v1" else "PROTOCOL.json"
    return json.loads((FIXTURES / name).read_bytes())


def checksum(n, seed):
    """Independent periodic-byte formula, without invoking any measured code."""
    cycles, tail = divmod(n, 256)
    return cycles * 32640 + sum(((seed & 255) + i) & 255 for i in range(tail))


def batch_checksum(n, seed, calls):
    return sum(checksum(n, (seed + i) & MASK32) for i in range(calls))


def percentile(samples, probability):
    require(samples and all(type(n) is int and n >= 0 for n in samples), "missing native samples")
    return sorted(samples)[max(0, math.ceil(probability * len(samples)) - 1)]


def summary(samples):
    return {"count": len(samples), "minimum": min(samples), "median": statistics.median(samples),
            "p95": percentile(samples, .95), "p99": percentile(samples, .99), "maximum": max(samples),
            "relative_mad": statistics.median(abs(x-statistics.median(samples)) for x in samples)
                            / max(1, statistics.median(samples)), "excluded": 0}


def run_command(argv, directory, ledger, *, timeout=60, cwd=None):
    index = len(ledger)
    start = time.monotonic_ns()
    row = {"argv": list(map(str, argv)), "cwd": str(ROOT if cwd is None else Path(cwd).resolve()),
           "status": "attempted", "started_ns": start}
    ledger.append(row)
    try:
        try:
            result = subprocess.run(row["argv"], cwd=row["cwd"], capture_output=True, timeout=timeout, check=False)
        except subprocess.TimeoutExpired as error:
            row.update(status="timeout", returncode=None, timeout_seconds=timeout)
            for name, raw in (("stdout", error.stdout), ("stderr", error.stderr)):
                raw = raw or b""
                destination = directory / f"command-{index:03d}.{name}"
                destination.write_bytes(raw)
                row[name] = file_identity(destination)
                row[name+"_bytes"] = len(raw)
            raise
        except OSError as error:
            row.update(status="spawn_failed", returncode=None,
                       error={"type": type(error).__name__, "message": str(error)})
            raise
        row.update(returncode=result.returncode, stdout_bytes=len(result.stdout), stderr_bytes=len(result.stderr))
        for name, raw in (("stdout", result.stdout), ("stderr", result.stderr)):
            destination = directory / f"command-{index:03d}.{name}"
            destination.write_bytes(raw)
            row[name] = file_identity(destination)
        require(len(result.stdout) + len(result.stderr) < 8_000_000, "command output bound")
        require(result.returncode == 0, "command failed: " + str(argv[0]) + ": " + result.stderr.decode(errors="replace")[:1200])
        row["status"] = "passed"
        return result.stdout.decode(errors="replace")
    finally:
        row["wall_ns"] = time.monotonic_ns() - start


def source_inventory():
    paths = list(FIXTURES.glob("*")) + list((ROOT / "hepta").glob("*.py"))
    paths += [Path(__file__), ROOT / "tools/qualify_hia_ndu_stateful_reference.py",
              ROOT / "tools/qualify_hia_ndu_stateful.py"]
    return {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()}


def source_state():
    def git(*args):
        return subprocess.check_output(["git", *args], cwd=ROOT, env={**os.environ, "GIT_NO_LAZY_FETCH": "1"}).decode().strip()
    return {"head": git("rev-parse", "HEAD"), "status": git("status", "--porcelain")}


def build(directory, clang, rustc, report, *, build_profile="instrumented-checked-v1"):
    from hepta.hia_program_source import lower_source
    from hepta.hia_program_llvm import emit_program_llvm, compile_program_llvm
    require(build_profile in {"instrumented-checked-v1", "optimized-release-v1",
                              "verified-reduction-release-v1",
                              "verified-reduction-narrowed-release-v1"}, "unknown build profile")
    release = build_profile != "instrumented-checked-v1"
    verified_narrowing = build_profile == "verified-reduction-narrowed-release-v1"
    verified_reduction = build_profile == "verified-reduction-release-v1" or verified_narrowing
    ledger = report.setdefault("build_commands", [])
    report["build_profile"] = {"id": build_profile,
        "optimization": "O3 / opt-level=3",
        "rust_overflow_checks": "off" if release else "on",
        "rust_panic": "abort", "rust_lto": "fat" if release else "off",
        "c_cpp_lto": "thin" if release else "off",
        "frame_pointers": "omitted across all four kernels" if release else "C/C++/Rust forced; HIA backend default",
        "target_cpu": "compiler generic x86_64 defaults, no native CPU tuning",
        "allocator_instrumentation": "same linker wrappers and actual allocation-failure probes",
        "fully_identical_codegen_flags": False,
        "hia_verified_reduction": verified_reduction,
        "hia_verified_modular_narrowing": verified_narrowing,
        "limits": ["Different compiler implementations/LLVM versions and language runtimes remain explicit.",
                   "HIA uses its production O3 checked-IR object path, without link-time IR.",
                   "Default-release Rust overflow policy is safe on the bounded workload: wrapping seed addition is explicit and u64 sum cannot overflow.",
                   "Allocator wrappers make this an instrumented native comparison, not an uninstrumented application benchmark."]}
    report["toolchains"] = {}
    for name, tool in (("clang", clang), ("rustc", rustc), ("objdump", "/usr/bin/objdump")):
        report["toolchains"][name] = {**file_identity(tool), "version": run_command([tool, "--version"], directory, ledger).splitlines()[0]}
    flags = ["-O3", "-fPIC", "-fomit-frame-pointer" if release else "-fno-omit-frame-pointer", "-fstack-usage"]
    if not release:
        flags += ["-fno-builtin-malloc", "-fno-builtin-calloc", "-fno-builtin-free"]
    wraps = ["-Wl,--wrap=" + name for name in ("malloc", "calloc", "realloc", "free")]
    for name in ("metrics", "probe_exports"):
        run_command([clang, *flags, "-I", FIXTURES, "-c", FIXTURES / (name+".c"), "-o", directory / (name+".o")], directory, ledger)
    products, costs = {}, {}
    for name in ("c", "cpp", "rust", "hia"):
        start = time.monotonic_ns()
        target = directory / (name + ".so")
        if name in {"c", "cpp"}:
            compiler_flags = ["-x", "c++", "-std=c++17", "-fno-exceptions"] if name == "cpp" else ["-std=c11"]
            if release:
                compiler_flags += ["-flto=thin"]
            run_command([clang, *flags, *compiler_flags, "-c", FIXTURES / ("kernel."+name), "-o", directory / (name+".o")], directory, ledger)
            link_flags = ["-O3", "-flto=thin", "-fuse-ld=lld"] if release else []
            run_command([clang, *link_flags, "-shared", directory / (name+".o"), directory / "metrics.o", directory / "probe_exports.o", *wraps, "-o", target], directory, ledger)
        elif name == "rust":
            args = [rustc, "--edition=2021", "--crate-type=cdylib", "--emit=link="+str(target)+",asm="+str(directory/"rust.s"), "-C", "opt-level=3",
                    "-C", "panic=abort", "-C", "overflow-checks="+("off" if release else "on"),
                    "-C", "force-frame-pointers="+("no" if release else "yes"),
                    "-C", "linker="+str(clang), "-C", "link-arg="+str(directory / "metrics.o")]
            if release:
                args += ["-C", "lto=fat", "-C", "codegen-units=1"]
            for flag in wraps:
                args += ["-C", "link-arg="+flag]
            run_command([*args, FIXTURES / "kernel.rs"], directory, ledger, cwd=directory)
        else:
            source = (FIXTURES / "kernel.hepta").read_text()
            lowered = lower_source(source, path="benchmarks/hia_native_ndu/kernel.hepta")
            # lower_source returns a checked, source-independent Core object.
            core = lowered.program if hasattr(lowered, "program") else lowered
            if isinstance(core, tuple):
                core = core[0]
            raw = core.as_dict() if hasattr(core, "as_dict") else core
            (directory / "hia.core.json").write_bytes(wire(raw)+b"\n")
            if verified_reduction:
                from hepta.hia_guarded_optimization import (
                    propose_guarded_reduction, guarded_program, build_guarded_native)
                if verified_narrowing:
                    from hepta.hia_narrowing import (
                        propose_guarded_narrowing, guarded_narrowed_program,
                        build_guarded_narrowed_native)
                    propose = propose_guarded_narrowing
                    build_verified = build_guarded_narrowed_native
                    compose_verified = guarded_narrowed_program
                else:
                    propose = propose_guarded_reduction
                    build_verified = build_guarded_native
                    compose_verified = guarded_program
                # The guard is an optimization boundary, not an admission
                # assumption. Every other input retains the original checked
                # semantics, including all original overflow checks.
                # The optional second stage also proves modular changes in the
                # fallback: scalar results, first traps and effects still match.
                proposal = propose(core, maximum=65536, include_induction=True)
                (directory / "hia.guarded-proposal.json").write_bytes(wire(proposal)+b"\n")
                proof = build_verified(core, proposal, directory / "hia.o",
                                       clang=str(clang), kind="object")
                report["hia_guarded_compilation"] = proof
                (directory / "hia.guarded-proof.json").write_bytes(wire(proof)+b"\n")
                core = compose_verified(core, proposal)
                require(core.sha256 == proof["native"]["core_sha256"],
                        "guarded proof must bind the emitted Core and actual object")
                (directory / "hia.optimized.core.json").write_bytes(wire(core.as_dict())+b"\n")
            llvm = emit_program_llvm(core)
            (directory / "hia.ll").write_text(llvm.text)
            if verified_reduction:
                report["hia_compilation"] = proof["native"]
            else:
                report["hia_compilation"] = compile_program_llvm(llvm, program=core, output=directory / "hia.o", clang=str(clang), kind="object")
            run_command([clang, "-shared", directory / "hia.o", directory / "metrics.o", directory / "probe_exports.o", *wraps, "-o", target], directory, ledger)
        costs[name] = time.monotonic_ns() - start
        products[name] = file_identity(target)
        assembly = run_command(["/usr/bin/objdump", "-d", "--disassemble=calculate", target], directory, ledger)
        (directory / (name+".calculate.asm")).write_text(assembly)
    run_command([clang, "-O2", "-fno-omit-frame-pointer", "-fstack-usage", "-I", FIXTURES,
                 FIXTURES / "driver.c", "-ldl", "-o", directory / "driver"], directory, ledger)
    report["native_artifacts"] = products
    report["backend_build_wall_ns"] = costs
    report["driver_identity"] = file_identity(directory / "driver")
    report["stack_evidence"] = {"compiler_su_files": {p.name: p.read_text() for p in directory.glob("*.su")},
        "disassembly": {name: file_identity(directory / (name+".calculate.asm")) for name in products},
        "scope": "compiler-emitted static-frame files where supported and actual function disassembly; no complete call-graph, recursion or native stack bound"}
    return products


class Driver:
    """A bounded owned child, executing only this campaign's generated files."""
    def __init__(self, executable, raw_path, *, env=None):
        self.raw = raw_path.open("xb")
        self.process = subprocess.Popen([str(executable)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE, bufsize=0, env=env)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.process.stdout, selectors.EVENT_READ)
        self.buffer = b""
        self.loaded = set()
        self.path_ids = {}
        self.sequence = 0
        self.handshake = self.receive()
        require(self.handshake.get("ready") is True and self.handshake.get("pid") == self.process.pid, "driver handshake")

    def receive(self):
        deadline = time.monotonic() + 10
        while b"\n" not in self.buffer:
            require(time.monotonic() < deadline, "driver response timed out")
            if not self.selector.select(max(0, deadline-time.monotonic())):
                continue
            part = os.read(self.process.stdout.fileno(), 65536)
            require(part, "driver closed before response")
            self.buffer += part
            require(len(self.buffer) <= 262144, "driver response bound")
        line, self.buffer = self.buffer.split(b"\n", 1)
        self.raw.write(wire({"sequence": self.sequence, "response_hex": line.hex()})+b"\n")
        self.raw.flush()
        return json.loads(line)

    def ask(self, command):
        self.sequence += 1
        self.raw.write(wire({"sequence": self.sequence, "request": command})+b"\n")
        start = time.monotonic_ns()
        self.process.stdin.write(command.encode()+b"\n")
        self.process.stdin.flush()
        value = self.receive()
        value["transport_outer_ns"] = time.monotonic_ns() - start
        return value

    def load(self, label, products):
        if label in self.loaded:
            return None
        started = time.monotonic_ns()
        expected = products[label]
        actual = file_identity(expected["path"])
        require(all(actual[key] == expected[key] for key in ("path", "bytes", "sha256")),
                "native library identity differs before load")
        order = protocol()["backends"].index(label)
        row = self.ask(f"L {order} {products[label]['path']}")
        require(row.get("loaded") == order, "wrong loaded library")
        self.loaded.add(label)
        self.path_ids[products[label]["path"]] = order
        row["mapping"] = self.mapping(products[label]["path"])
        row["artifact_identity"] = actual
        row["load_outer_ns"] = time.monotonic_ns() - started
        return row

    def mapping(self, path):
        row = self.ask(f"M {self.path_ids[path]}")
        require(row["mapped_bytes"] > 0,"actual loader mappings unavailable")
        row["scope"] = "Actual PT_LOAD segment page union via dl_iterate_phdr; mincore observes resident backing pages, not process RSS/private bytes. Process peak RSS is separate getrusage evidence."
        if row["mincore_failed_pages"]:
            row["backing_resident_bytes"] = None
        return row

    def measure(self, label, n, seed, calls, samples, warmup=0, fail=0):
        identifier = protocol()["backends"].index(label)
        row = self.ask(f"R {identifier} {n} {seed} {calls} {samples} {warmup} {fail}")
        require(row.get("id") == identifier and row.get("n") == n and row.get("seed") == seed, "native response identity")
        require(row["cold_value"] == checksum(n,seed), "cold result mismatch")
        require(row["batch_checksum"] == batch_checksum(n,seed,calls), "native checksum mismatch")
        require(len(row["times_ns"]) == samples and sum(row["times_ns"]) == row["elapsed_ns"], "native sample accounting mismatch")
        require(len(row["metrics"]) == len(METRIC_NAMES), "allocator observation shape")
        row["metrics"] = dict(zip(METRIC_NAMES, row["metrics"]))
        expected = 1001 if fail and n else checksum(n,seed)
        require(row["observed"] == expected, "refusal/normal behavior mismatch")
        metrics = row["metrics"]
        require(metrics["accounting_errors"] == 0 and metrics["live"] == 0
                and metrics["live_requested"] == 0 and metrics["live_usable"] == 0, "observed allocator lifetime mismatch")
        if n:
            require(metrics["attempts"] == 1 and metrics["refusals"] == fail, "allocator attempt/refusal not preserved")
            require(metrics["allocations"] == 1-fail and metrics["frees"] == 1-fail, "actual allocation/free count")
            if not fail:
                require(metrics["peak_requested"] == n and metrics["peak_usable"] >= n, "actual requested/usable bytes")
        else:
            require(metrics["attempts"] == metrics["allocations"] == metrics["frees"] == 0, "empty owner allocated")
        metrics["allocator_slack_bytes"] = metrics["peak_usable"] - metrics["peak_requested"]
        row["backend"] = label
        return row

    def close(self):
        try:
            if self.process.poll() is None:
                try:
                    value = self.ask("Q")
                    require(value.get("closed") is True, "driver cleanup acknowledgement")
                    self.process.wait(timeout=5)
                except BaseException:
                    self.process.kill()
                    self.process.wait(timeout=5)
                    raise
            stderr = self.process.stderr.read(65536)
            self.raw.write(wire({"exit_code": self.process.returncode, "stderr_hex": stderr.hex()})+b"\n")
            require(self.process.returncode == 0, "native child failed")
        finally:
            # Repeated measured sessions must release their actual pipe FDs
            # before returning, including failed acknowledgements/child exits.
            # Relying on Python GC moves cleanup outside the measured lifetime.
            self.selector.close()
            for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                stream.close()
            self.raw.close()


@contextmanager
def driver(executable, raw_path, *, env=None):
    instance = Driver(executable, raw_path, env=env)
    try:
        yield instance
    finally:
        instance.close()


def measure_training(directory, products, report, spec):
    report["correctness"] = []
    report["training"] = []
    report["loads"] = []
    for offset, seed in enumerate(spec["training_seeds"]):
        names = spec["backends"][offset:] + spec["backends"][:offset]
        if offset % 2: names.reverse()
        for name in names:
            with driver(directory / "driver", directory / f"training-{offset}-{name}.jsonl") as child:
                load = child.load(name, products)
                report["loads"].append({"phase": "training", "backend": name, **load})
                for n in spec["sizes"]:
                    row = child.measure(name,n,seed,spec["batch_calls"],spec["training_samples_per_request"],spec["warmup_calls"])
                    row["mapping_after"] = child.mapping(products[name]["path"])
                    report["training"].append(row)
    for name in spec["backends"]:
        with driver(directory / "driver", directory / f"correctness-{name}.jsonl") as child:
            child.load(name,products)
            for n in spec["correctness_sizes"]:
                for seed in spec["correctness_seeds"]:
                    report["correctness"].append(child.measure(name,n,seed,1,1))
                report["correctness"].append(child.measure(name,n,29,1,1,fail=1))
    training = {}
    for name in spec["backends"]:
        rows = [r for r in report["training"] if r["backend"] == name]
        loads = [r for r in report["loads"] if r["backend"] == name]
        training[name] = {"latency_ns": {str(n): math.ceil(statistics.median(t for r in rows if r["n"] == n for t in r["times_ns"])) for n in spec["sizes"]},
            "preparation_ns": math.ceil(statistics.median(r["load_outer_ns"] for r in loads)),
            "resident_bytes": max(r["mapping_after"]["mapped_bytes"] for r in rows)}
    report["training_summary"] = {name:{str(n):summary([t for r in report["training"] if r["backend"] == name and r["n"] == n for t in r["times_ns"]]) for n in spec["sizes"]} for name in spec["backends"]}
    report["frozen_training"] = {"values": training, "sha256": digest(training),
        "future_evaluation_timing_rows_used": 0, "preparation_scope": "complete already-built artifact identity check, dlopen transport and initial mapping observation; not compilation",
        "samples_are_admission_domain": "finite observed native cases, not an all-input theorem"}
    return training


def observed_model(training, products, spec, current_size, horizon, ready, generation, sunk_ns,
                   *, future_decision_cost_ns=None):
    """No episode or future-size argument exists at the policy input boundary."""
    from hepta.hia_ndu_stateful import SCHEMA, SCHEMA_V2
    require(current_size in spec["sizes"] and 1 <= horizon <= 4, "unsupported observed request")
    baseline = spec["baseline"]
    def identity(name):
        return products[name]["sha256"]
    objective = {key:value for key,value in spec.items() if key not in {
        "episodes", "training_seeds", "correctness_seeds", "correctness_sizes"}}
    model = {"schema": SCHEMA, "name": "native-owned-bytes", "objective_digest": digest(objective),
        "generation": generation, "baseline": {"source_sha256": identity(baseline),
            "verification_sha256": digest(["bounded-native-differential",identity(baseline)]),
            "latency_ns": [training[baseline]["latency_ns"][str(current_size)]]*horizon},
        "variants": [{"id": name, "source_sha256": identity(name),
            "verification_sha256": digest(["bounded-native-differential",identity(name)]),
            "support_sha256": digest(training), "status": "verified",
            "preparation_ns": training[name]["preparation_ns"], "holding_ns": [0]*horizon,
            "resident_bytes": training[name]["resident_bytes"],
            "latency_ns": [training[name]["latency_ns"][str(current_size)]]*horizon} for name in spec["variants"]],
        "initial_ready": sorted(ready), "memory_budget_bytes": spec["resident_quota_bytes"],
        "budget_ns": max(0,spec["model_budget_ns"]-sunk_ns), "completion_value_ns": spec["completion_value_ns"],
        "sunk_cost_ns": sunk_ns, "observations": [{"training_sha256":digest(training), "observed_size":current_size,
            "forecast":"current-size persistence", "future_workload_visible":False}],
        "cost_basis":"caller-measurement-estimates"}
    if future_decision_cost_ns is not None:
        require(type(future_decision_cost_ns) is int and 0 <= future_decision_cost_ns <= 1_000_000_000_000,
                "future controller cost must be an explicit bounded integer")
        model.update(schema=SCHEMA_V2, future_decision_cost_ns=future_decision_cost_ns)
    return model


def first_ready(reference, ready):
    winners = reference.get("winners",[])
    if not winners: return set(ready)
    return set(sorted((r["schedule"] for r in winners))[0][0])


def native_first_action(bundle, response, ready):
    """Project only a unanimous current prepared set from validated advice.

    NduSession has already checked the response against its exact request. A
    tie between whole paths need not mean their first action is ambiguous. This
    caller policy retains every Pareto path and never invents a unique native
    recommendation. ``verified`` here is the bounded model's external input,
    not a machine-code safety proof or permission to publish native code.
    """
    require(response.get("authority") == "DENY_ALL"
            and response.get("safety_certificate") is False,
            "native advice cannot acquire execution authority")
    identities = response["pareto_candidate_ids"]
    decision = {"policy": "unanimous-pareto-first-prepared-set",
        "pareto_candidate_ids": list(identities),
        "native_advisory_candidate_id": response.get("advisory_candidate_id"),
        "chosen_ready": sorted(ready), "stopped_until_size_change": False,
        "status": "abstain_no_common_first_action", "whole_path_selected": False,
        "authority": "DENY_ALL", "safety_certificate": False}
    if not identities or "abstain" in identities:
        return decision
    require(len(set(identities)) == len(identities), "duplicate native Pareto path")
    plans, states = bundle["plans"], bundle["stateful_binding"]["states"]
    schedules = []
    for identity in identities:
        require(identity in plans, "native Pareto path is absent from the bound plan")
        plan = plans[identity]
        require(plan["verified"] is True and plan["actions"],
                "native Pareto path lacks admitted model actions")
        actions = plan["actions"]
        require(set(states[actions[0]["source"]]["ready"]) == set(ready),
                "native plan starts from another prepared set")
        schedule = []
        previous = set(ready)
        for action in actions:
            require(action["status"] == "verified", "native plan has an unadmitted model action")
            target = set(states[action["target"]]["ready"])
            require(previous <= target, "native plan cannot forget prepared variants")
            schedule.append(tuple(sorted(target)))
            previous = target
        schedules.append(schedule)
    firsts = {schedule[0] for schedule in schedules}
    decision["pareto_first_ready_sets"] = [list(value) for value in sorted(firsts)]
    if len(firsts) != 1:
        return decision
    chosen = next(iter(firsts))
    decision.update(status="unanimous_first_action", chosen_ready=list(chosen),
        stopped_until_size_change=all(target == chosen for schedule in schedules for target in schedule))
    return decision


def fixed_ready(training, spec):
    """One frozen fixed bank selected from training, before episode disclosure."""
    from itertools import combinations
    require(set(spec) == {"variants", "resident_quota_bytes", "sizes", "baseline"},
            "fixed policy input must exclude future episodes and evaluation seeds")
    names = spec["variants"]
    rows = []
    for count in range(len(names)+1):
        for selected in combinations(names,count):
            if sum(training[n]["resident_bytes"] for n in selected)>spec["resident_quota_bytes"]: continue
            cost = sum(training[n]["preparation_ns"] for n in selected)
            cost += sum(min(training[n]["latency_ns"][str(size)] for n in (spec["baseline"],*selected)) for size in spec["sizes"])
            rows.append((cost,selected))
    return set(min(rows)[1])


def prepare_gate_bank(training, products, spec, report):
    """Pay for bounded training-only bound construction before any episode."""
    from hepta.hia_invocation_bank import prepare_invocation_bank
    started = time.monotonic_ns()
    row = {"status": "attempted", "training_sha256": digest(training), "future_evaluation_rows_used": 0,
           "scope": "one locally validated bound owner; model facts, not artifact execution authority",
           "memory_scope": "retained input wire bytes and bounded prefix count; Python object overhead excluded; process cumulative RSS recorded separately"}
    report["prepared_gate"] = row
    try:
        owner = prepare_invocation_bank({n: observed_model(training, products, spec, n, 4,
            set(), 1, 0, future_decision_cost_ns=0) for n in spec["sizes"]},
            epoch=spec["prepared_gate"]["epoch"])
        row.update(status="prepared", initial=owner.snapshot())
        return owner
    except Exception as error:
        row.update(status="failed", error={"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        row["actual_preparation_ns"] = time.monotonic_ns() - started


def prepared_invocation_gate(owner, model, size, spec, invocation_cost_ns):
    """The model remains freshly constructed and charged on the controller path."""
    return owner.lookup(size=size, horizon=len(model["baseline"]["latency_ns"]),
        ready_mask=owner.mask_for(tuple(model["initial_ready"])),
        budget_ns=model["budget_ns"], invocation_cost_ns=invocation_cost_ns,
        epoch=spec["prepared_gate"]["epoch"], generation=model["generation"],
        sunk_cost_ns=model["sunk_cost_ns"], future_decision_cost_ns=model["future_decision_cost_ns"])


def calibrate_controllers(training, products, spec, bridge, identity, report, *, prepared_bank=None):
    """Freeze controller estimates using training sizes before any episode.

    Measured maxima are forecasts, not upper bounds on future host time. Every
    sample, native startup/shutdown, and calibration failure is retained. This
    work is charged once to campaign preparation and never represented as free.
    """
    from hepta.hia_ndu_session import NduSession
    from hepta.hia_ndu_stateful import build_request, invocation_gate
    from tools.qualify_hia_ndu_stateful_reference import exact_dp_control, greedy_control
    started = time.monotonic_ns()
    result = {"schema": "hepta.hia.ndu.controller-calibration.v1", "status": "running",
              "training_sha256": digest(training), "future_evaluation_rows_used": 0,
              "samples": [], "estimates_ns": {}, "native_startup_ns": 0,
              "native_shutdown_ns": 0, "estimates_are_runtime_bounds": False}
    report["controller_calibration"] = result
    session = None
    try:
        t = time.monotonic_ns()
        try:
            session = NduSession.for_stream_profile(bridge, identity, timeout=10)
        finally:
            result["native_startup_ns"] = time.monotonic_ns() - t
        for n in spec["sizes"]:
            for arm in ("exact_dp", "greedy", "native_ndu"):
                t = time.monotonic_ns()
                model = observed_model(training, products, spec, n, 4, set(), 1, 0,
                                       **({"future_decision_cost_ns": 0} if prepared_bank is not None else {}))
                gate = (invocation_gate(model, invocation_cost_ns=0) if prepared_bank is None else
                        prepared_invocation_gate(prepared_bank, model, n, spec, 0))
                if arm == "native_ndu":
                    bundle = build_request(model, search="dynamic-frontier")
                    response = session.evaluate(bundle["request"])
                    value = native_first_action(bundle, response, set())
                else:
                    value = (exact_dp_control if arm == "exact_dp" else greedy_control)(model)
                elapsed = time.monotonic_ns() - t
                sample = {"arm": arm, "training_size": n, "model_sha256": digest(model),
                          "wall_ns": elapsed, "result": value, "invocation_gate": gate,
                          "forced_calibration_call": True}
                if arm == "native_ndu":
                    sample.update(bundle=bundle, response=response,
                                  native_raw_frame_hex=session._last_received_frame.hex())
                result["samples"].append(sample)
        result["estimates_ns"] = {arm: max(s["wall_ns"] for s in result["samples"] if s["arm"] == arm)
                                  for arm in ("exact_dp", "greedy", "native_ndu")}
        result["status"] = "passed"
    except BaseException as error:
        result.update(status="failed", error={"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        try:
            if session is not None:
                t = time.monotonic_ns()
                try:
                    session.close()
                finally:
                    result["native_shutdown_ns"] = time.monotonic_ns() - t
                    result["native_session"] = session.snapshot()
        except BaseException as error:
            result.update(status="failed", cleanup_error={"type": type(error).__name__, "message": str(error)})
            raise
        finally:
            result["actual_total_ns"] = time.monotonic_ns() - started
            result["observed_attributed_cost_ns"] = {
                arm: sum(s["wall_ns"] for s in result["samples"] if s["arm"] == arm)
                + (result["native_startup_ns"] + result["native_shutdown_ns"] if arm == "native_ndu" else 0)
                for arm in ("exact_dp", "greedy", "native_ndu")}
            result["shared_calibration_harness_ns"] = (
                result["actual_total_ns"] - sum(result["observed_attributed_cost_ns"].values()))
            result["sha256"] = digest({key: value for key, value in result.items() if key != "sha256"})
    return result


def execute_policies(directory, products, training, report, spec, bridge, identity, *, prepared_bank=None):
    from hepta.hia_ndu_session import NduSession
    from hepta.hia_ndu_stateful import build_request, invocation_gate
    from tools.qualify_hia_ndu_stateful_reference import exact_dp_control, greedy_control
    report["policy_runs"] = []
    report["fixed_training_selections"] = []
    calibration = report["controller_calibration"]
    require(calibration["status"] == "passed" and calibration["training_sha256"] == digest(training),
            "matching training-only controller calibration is required")
    for episode_index, episode in enumerate(spec["episodes"]):
        order = spec["policy_arms"][episode_index:]+spec["policy_arms"][:episode_index]
        for arm in order:
            row = {"episode":episode_index,"arm":arm,"steps":[],"status":"running",
                   "ndu_startup_ns": 0, "ndu_shutdown_ns": 0, "native_invocations": 0,
                   "controller_calibration_sha256": calibration["sha256"]}
            report["policy_runs"].append(row)
            session = None
            started = time.monotonic_ns()
            ready, sunk = set(), 0
            last_size, sleeping = None, False
            try:
                if arm == "fixed" or prepared_bank is not None:
                    t = time.monotonic_ns()
                    fixed_inputs = {key: spec[key] for key in
                                    ("variants", "resident_quota_bytes", "sizes", "baseline")}
                    frozen = fixed_ready(training,fixed_inputs)
                    selection_ns = time.monotonic_ns()-t
                    if arm == "fixed":
                        row["fixed_selection_ns"] = selection_ns
                        row["fixed_training_selection"] = sorted(frozen)
                        report["fixed_training_selections"].append(sorted(frozen))
                    if prepared_bank is not None:
                        row["incumbent_initializer"] = "strong-training-fixed"
                        row["initial_selection_ns"] = selection_ns
                        row["initial_training_ready"] = sorted(frozen)
                with driver(directory/"driver",directory/f"policy-{episode_index}-{arm}.jsonl") as child:
                    row["baseline_load"] = child.load(spec["baseline"],products)
                    if prepared_bank is not None:
                        row["initial_incumbent_loads"] = [
                            {"backend": name, **child.load(name, products)} for name in sorted(frozen)]
                        ready = set(frozen)
                    sunk = time.monotonic_ns()-started
                    for index in range(len(episode["sizes"])):
                        # The next request is first disclosed here, after the previous native batch.
                        n, seed = episode["sizes"][index], episode["seeds"][index]
                        decision_start = time.monotonic_ns()
                        future_cost = 0 if arm == "fixed" else calibration["estimates_ns"][arm]
                        # Fixed never uses a forecast to choose this request.
                        # In the new profile its model exists only for the
                        # separately timed independent audit. Adaptive arms
                        # continue paying complete model construction here.
                        model = (None if prepared_bank is not None and arm == "fixed" else
                            observed_model(training,products,spec,n,len(episode["sizes"])-index,ready,index+1,sunk,
                                           future_decision_cost_ns=future_cost))
                        step = {"index":index,"observed_size":n,"seed":seed,"model":model,"loads":[]}
                        row["steps"].append(step)
                        if arm == "fixed":
                            chosen = set(frozen)
                            sleeping = True
                        elif sleeping and n == last_size:
                            chosen = set(ready)
                            step["decision"] = {"status":"stop_until_observed_workload_change"}
                        else:
                            invocation_estimate = future_cost
                            if arm == "native_ndu" and session is None:
                                invocation_estimate += calibration["native_startup_ns"] + calibration["native_shutdown_ns"]
                            gate = (invocation_gate(model, invocation_cost_ns=invocation_estimate)
                                    if prepared_bank is None else
                                    prepared_invocation_gate(prepared_bank, model, n, spec, invocation_estimate))
                            step["invocation_gate"] = gate
                            if not gate["invoke"]:
                                chosen, sleeping = set(ready), True
                                step["decision"] = {"status": "skip_controller_keep_incumbent",
                                                    "reason": gate["reason"]}
                            else:
                                # Reserve the estimated current invocation before planning;
                                # the next snapshot replaces this reservation with actual
                                # service time. It is never added to the observed sunk ledger.
                                step["model_before_invocation_reservation"] = deepcopy(model)
                                model["budget_ns"] -= invocation_estimate
                                model["observations"].append({"kind": "current-controller-cost-reserved",
                                    "estimated_ns": invocation_estimate,
                                    "calibration_sha256": calibration["sha256"], "actual_measurement": False})
                                if arm in {"exact_dp", "greedy"}:
                                    result = exact_dp_control(model) if arm == "exact_dp" else greedy_control(model)
                                    step["decision"] = result
                                    chosen = first_ready(result,ready)
                                    sleeping = bool(result.get("winners")) and all(set(x)==chosen for x in sorted(r["schedule"] for r in result["winners"])[0])
                                else:
                                    if session is None:
                                        t = time.monotonic_ns()
                                        try:
                                            session = NduSession.for_stream_profile(bridge,identity,timeout=10)
                                        finally:
                                            row["ndu_startup_ns"] = time.monotonic_ns()-t
                                    bundle = build_request(model,search="dynamic-frontier")
                                    response = session.evaluate(bundle["request"])
                                    row["native_invocations"] += 1
                                    step["bundle"],step["response"] = bundle,response
                                    step["native_raw_frame_hex"] = session._last_received_frame.hex()
                                    step["decision"] = native_first_action(bundle,response,ready)
                                    chosen = set(step["decision"]["chosen_ready"])
                                    sleeping = step["decision"]["stopped_until_size_change"]
                        step["controller_ns"] = time.monotonic_ns()-decision_start
                        last_size = n
                        step["chosen_ready"] = sorted(chosen)
                        step["stopped_until_size_change"] = sleeping
                        # Audit costs are retained separately and removed from service-only
                        # comparisons. The same independent computation runs for every arm.
                        audit_start = time.monotonic_ns()
                        if model is None:
                            model = observed_model(training,products,spec,n,len(episode["sizes"])-index,
                                                   ready,index+1,sunk, future_decision_cost_ns=0)
                            step["model"] = model
                            step["fixed_model_is_audit_only"] = True
                        check = exact_dp_control(model)
                        step["same_model_dp_best_value_q32"] = check["best_value_q32"]
                        dp_firsts = sorted({tuple(winner["schedule"][0]) for winner in check["winners"]})
                        step["same_model_dp_first_ready_sets"] = [list(value) for value in dp_firsts]
                        step["chosen_ready_is_same_model_dp_first_action"] = tuple(sorted(chosen)) in dp_firsts
                        if "response" in step:
                            native_values = [p["values_q32"][0] for p in step["response"]["paths"]]
                            require(max(native_values)==check["best_value_q32"], "native advice disagrees with independent finite DP")
                            if step["decision"]["status"] == "unanimous_first_action":
                                require(step["chosen_ready_is_same_model_dp_first_action"],
                                        "native common action disagrees with independent finite DP first step")
                        step["independent_audit_ns"] = time.monotonic_ns()-audit_start
                        require(ready <= chosen, "cannot forget already prepared variants")
                        for name in sorted(chosen-ready):
                            step["loads"].append({"backend":name,**child.load(name,products)})
                        ready = chosen
                        dispatched = min((spec["baseline"],*sorted(ready)),key=lambda name:(training[name]["latency_ns"][str(n)],name))
                        step["dispatched"] = dispatched
                        step["execution"] = child.measure(dispatched,n,seed,spec["batch_calls"],1)
                        step["resident_observations"] = {name:child.mapping(products[name]["path"]) for name in sorted(child.loaded)}
                        load_cost = sum(r["load_outer_ns"] for r in step["loads"])
                        charged = step["controller_ns"]+load_cost+step["execution"]["transport_outer_ns"]
                        sunk = time.monotonic_ns()-started-sum(s.get("independent_audit_ns",0) for s in row["steps"])
                        step["charged_step_ns"] = charged
                        residents=[r["backing_resident_bytes"] for r in step["resident_observations"].values()]
                        step["partial_right_sample_resident_backing_byte_ns"] = None if None in residents else sum(residents)*charged
                        step["residency_estimate_scope"] = "Post-execution mapping sample times charged_step_ns only; not an integral over the full service interval."
                row["status"] = "passed"
            except BaseException as error:
                row["status"] = "failed"
                row["error"] = {"type":type(error).__name__,"message":str(error)}
                raise
            finally:
                try:
                    if session is not None:
                        t=time.monotonic_ns()
                        try:
                            session.close()
                        finally:
                            row["ndu_shutdown_ns"] = time.monotonic_ns()-t
                            row["ndu_session"] = session.snapshot()
                except BaseException as error:
                    row.update(status="failed", cleanup_error={"type": type(error).__name__, "message": str(error)})
                    raise
                finally:
                    row["actual_total_ns"] = time.monotonic_ns()-started
                    row["independent_audit_ns"] = sum(s.get("independent_audit_ns",0) for s in row["steps"])
                    row["service_total_ns"] = row["actual_total_ns"]-row["independent_audit_ns"]
                    row["scope"] = "driver startup/load, current-only planning, actual native execution/probes, response validation and cleanup; shared offline build/training separately charged once"


def evaluate(report,spec):
    # Bind every strong-control comparison to the registered protocol.
    # Tail-only regression and incomplete cohorts must never qualify.
    gate = spec["performance_gate"]
    require(gate["all_baselines_and_sizes_required"] is True,
            "native performance qualification must require all sizes and baselines")
    require(type(spec["backends"]) is list and len(spec["backends"]) == 4
            and set(spec["backends"]) == {"c", "cpp", "rust", "hia"}
            and type(spec["sizes"]) is list and len(spec["sizes"]) > 0
            and len(set(spec["sizes"])) == len(spec["sizes"]),
            "native performance protocol must register all four unique backends and nonempty unique sizes")
    performance = []
    for n in spec["sizes"]:
        hia=report["training_summary"]["hia"][str(n)]
        for name in ("c","cpp","rust"):
            control=report["training_summary"][name][str(n)]
            ratios = {key+"_ratio": hia[key]/control[key] for key in ("median","p95","p99")}
            performance.append({"size":n, "baseline":name, **ratios,
                "passed": ratios["median_ratio"] <= gate["hia_median_ratio_maximum"]
                          and ratios["p95_ratio"] <= gate["hia_tail_ratio_maximum"]
                          and ratios["p99_ratio"] <= gate["hia_tail_ratio_maximum"]})
    economies=[]
    for episode in range(len(spec["episodes"])):
        rows={r["arm"]:r for r in report["policy_runs"] if r["episode"]==episode}
        for name in ("fixed","exact_dp","greedy"):
            economies.append({"episode":episode,"baseline":name,"ndu_ns":rows["native_ndu"]["service_total_ns"],
                "baseline_ns":rows[name]["service_total_ns"],"ratio":rows["native_ndu"]["service_total_ns"]/rows[name]["service_total_ns"],
                "passed":rows["native_ndu"]["service_total_ns"]<rows[name]["service_total_ns"]})
    native_calls = sum(r.get("native_invocations", 0) for r in report["policy_runs"]
                       if r["arm"] == "native_ndu")
    gated_policy_wins = all(r["passed"] for r in economies)
    return {"performance_comparisons":performance,"economic_comparisons":economies,
            "four_language_finite_correctness_and_allocator_probes":True,
            "performance_gate_passed":all(r["passed"] for r in performance),
            "service_scope_gated_policy_benefit_established":gated_policy_wins,
            "service_scope_net_ndu_benefit_established":gated_policy_wins and native_calls > 0,
            "native_policy_invocations":native_calls,
            "native_invocation_count_alone_proves_benefit":False,
            "invoke_gate_proves_empirical_benefit":False,
            "whole_lifecycle_net_ndu_benefit_established":False,
            "whole_language_safety_proved":False,"global_optimum_proved":False,
            "complete_lifecycle_cost_known":False,"future_timing_leakage_used":False}


def finalize_acceptance(report):
    """Identity drift or incomplete execution withdraws every acceptance gate."""
    valid = (report.get("status") == "completed" and report.get("source_unchanged") is True
             and report.get("runtime_inputs_unchanged") is True)
    report["acceptance_observation_valid"] = valid
    if not valid:
        report.pop("acceptance", None)


def prepared_observed_costs(report, spec):
    """Preserve actual totals and attributable one-time work without amortizing.

    A standalone adaptive arm pays one measured owner construction/close. Fixed
    does not pay NDU or adaptive-owner calibration. The actual combined campaign
    cost remains separate; unknown/unassigned costs never become zero.
    """
    expected = {(episode, arm) for episode in range(len(spec["episodes"])) for arm in spec["policy_arms"]}
    rows = {(row["episode"], row["arm"]): row for row in report["policy_runs"]}
    require(len(rows) == len(report["policy_runs"]) and set(rows) == expected
            and all(row["status"] == "passed" for row in rows.values()),
            "prepared-gate observed cost cohort is incomplete or repeated")
    comparisons = []
    for episode in range(len(spec["episodes"])):
        ndu = rows[episode, "native_ndu"]["actual_total_ns"]
        for arm in ("fixed", "exact_dp", "greedy"):
            baseline = rows[episode, arm]["actual_total_ns"]
            comparisons.append({"episode": episode, "baseline": arm, "ndu_ns": ndu,
                "baseline_ns": baseline, "ratio": ndu / baseline, "passed": ndu < baseline})
    common = sum(report[key] for key in ("offline_build_wall_ns", "offline_validation_training_wall_ns",
                                         "failed_translation_outer_ns", "runtime_identity_check_ns"))
    preparation = report["prepared_gate"]["actual_preparation_ns"] + report["prepared_gate"]["close_ns"]
    calibration = report["controller_calibration"]
    components = {}
    for arm in spec["policy_arms"]:
        entries = [row for (episode, name), row in rows.items() if name == arm]
        parts = {"common_bank_work_ns": common,
                 "actual_episode_totals_ns": sum(row["actual_total_ns"] for row in entries),
                 "controller_calibration_ns": 0 if arm == "fixed" else calibration["observed_attributed_cost_ns"][arm],
                 "prepared_owner_ns": 0 if arm == "fixed" else preparation}
        components[arm] = {"parts_ns": parts, "known_component_total_ns": sum(parts.values())}
    ndu_total = components["native_ndu"]["known_component_total_ns"]
    known = [{"baseline": arm, "ndu_ns": ndu_total,
              "baseline_ns": components[arm]["known_component_total_ns"],
              "passed": ndu_total < components[arm]["known_component_total_ns"]}
             for arm in ("fixed", "exact_dp", "greedy")]
    return {"schema": "hepta.hia.prepared-gate.observed-costs.v1",
        "actual_total_comparisons_including_audit": comparisons,
        "all_actual_total_comparisons_passed": all(row["passed"] for row in comparisons),
        "standalone_arm_known_components": components, "known_component_comparisons": known,
        "calibration_harness_unassigned_ns": calibration["shared_calibration_harness_ns"],
        "retained_original_ndu_build_cost": report["reused_native_identity"].get("build_cost"),
        "unknown_or_unassigned_costs": ["calibration-harness-assignment", "original-ndu-build-amortization",
            "tool-and-source-acquisition", "human-implementation-and-review", "energy", "publication"],
        "complete_lifecycle_cost_known": False, "whole_lifecycle_net_ndu_benefit_established": False,
        "authority": "DENY_ALL", "production_activation_allowed": False}


def qualify(args):
    start=time.monotonic_ns()
    directory=Path(args.output).resolve()
    require(not directory.exists(),"new evidence directory required")
    directory.mkdir(parents=True,mode=0o700)
    controller_profile = getattr(args, "controller_profile", "full-model-v3")
    spec = protocol(controller_profile)
    report={"schema":"hepta.hia.native-economics.results.v3","status":"failed",
            "observed_utc":datetime.now(timezone.utc).isoformat(),"protocol":spec,
            "host":{"system":platform.system(),"machine":platform.machine(),"python":sys.version},
            "mode":"formal" if args.expected_source else "development","reused_native_ndu":file_identity(args.bridge),
            "reused_native_identity":json.loads(Path(args.identity).read_bytes()),
            "reused_native_build_is_new_measurement":False}
    report["measurement_boundaries"]={
        "cold_ns":"First un-warmed invocation for this request; only the first request per newly loaded library is process/dispatch cold. No hardware cache flush or fully cold host claim.",
        "timed_calls":"Resource observer is disabled during timing; its wrapper dispatch overhead remains in every backend.",
        "allocator":"Requested payload, malloc_usable_size allocation capacity and slack; arena metadata and fragmentation unobserved.",
        "stack":"Sampled begin-to-allocator helper address distance plus compiler stack files/disassembly; no global peak proof.",
        "resident":"Loader PT_LOAD pages and mincore backing residency; not process-private RSS. Process peak RSS is getrusage, separately.",
        "planning":"Training-only measured controller maxima forecast future active decisions. An optimistic same-information invoke/skip gate runs before each controller and before native startup. Current invocation reservations are replaced by observed service costs at the next snapshot. Estimates are not runtime bounds. All gates, startup, calls, transport and shutdown remain charged; no empirical net-gain claim follows from the model."}
    if controller_profile == "prepared-bank-v1":
        report["schema"] = "hepta.hia.native-economics.prepared-gate.results.v1"
        report["controller_profile"] = controller_profile
    protocol_file = "PREPARED_GATE_PROTOCOL.json" if controller_profile == "prepared-bank-v1" else "PROTOCOL.json"
    (directory/"protocol.json").write_bytes((FIXTURES/protocol_file).read_bytes())
    prepared_bank = None
    try:
        require(platform.system()=="Linux" and platform.machine()=="x86_64","Linux x86-64 profile only")
        if controller_profile == "prepared-bank-v1":
            require(spec["controller_profile"] == controller_profile
                    and args.build_profile == spec["required_build_profile"],
                    "prepared-gate registration requires its exact controller/build profile")
        if hasattr(os,"sched_getaffinity"):
            allowed=os.sched_getaffinity(0); os.sched_setaffinity(0,{min(allowed)})
            report["host"].update(affinity=sorted(os.sched_getaffinity(0)),exclusive_cpu=False)
        report["source_before"]=source_state()
        if args.expected_source:
            require(report["source_before"]=={"head":args.expected_source,"status":""},"formal exact clean source required")
        report["input_hashes_before"]=source_inventory()
        t=time.monotonic_ns()
        products=build(directory,Path(args.clang),Path(args.rustc),report,
                       build_profile=args.build_profile)
        report["offline_build_wall_ns"]=time.monotonic_ns()-t
        t=time.monotonic_ns()
        training=measure_training(directory,products,report,report["protocol"])
        report["offline_validation_training_wall_ns"]=time.monotonic_ns()-t
        if controller_profile == "prepared-bank-v1":
            prepared_bank = prepare_gate_bank(training, products, spec, report)
            calibrate_controllers(training,products,spec,args.bridge,args.identity,report, prepared_bank=prepared_bank)
        else:
            calibrate_controllers(training,products,spec,args.bridge,args.identity,report)
        from tools.qualify_hia_ndu_stateful import translation_refusal_probe
        t=time.monotonic_ns()
        report["actual_failed_translation"],_=translation_refusal_probe()
        report["failed_translation_outer_ns"]=time.monotonic_ns()-t
        require(report["actual_failed_translation"]["status"]=="actual-refusal-observed","real proof/refusal/replay required")
        report["shared_campaign_cost_ns"]=(report["offline_build_wall_ns"]+report["offline_validation_training_wall_ns"]
            +report["controller_calibration"]["actual_total_ns"]+report["failed_translation_outer_ns"])
        if prepared_bank is not None:
            report["shared_campaign_cost_ns"] += report["prepared_gate"]["actual_preparation_ns"]
        report["shared_campaign_cost_scope"]="Actual shared bank preparation/validation/training, training-only controller calibration (including native startup/shutdown), and rejected proof paid once in this campaign, disclosed without arbitrary amortization. Per-policy service totals exclude this common sunk work and the independently recorded audit."
        if prepared_bank is None:
            execute_policies(directory,products,training,report,spec,args.bridge,args.identity)
        else:
            execute_policies(directory,products,training,report,spec,args.bridge,args.identity, prepared_bank=prepared_bank)
        report["acceptance"]=evaluate(report,report["protocol"])
        report["status"]="completed"
    except BaseException as error:
        report["error"]={"type":type(error).__name__,"message":str(error)}
    finally:
        if prepared_bank is not None:
            closing = time.monotonic_ns()
            try:
                report["prepared_gate"]["final"] = prepared_bank.close()
            except Exception as error:
                report["status"] = "failed"
                report["prepared_gate"]["close_error"] = {"type": type(error).__name__, "message": str(error)}
            finally:
                report["prepared_gate"]["close_ns"] = time.monotonic_ns() - closing
            if "shared_campaign_cost_ns" in report:
                report["shared_campaign_cost_ns"] += report["prepared_gate"]["close_ns"]
            report["shared_campaign_cost_scope"] = report.get("shared_campaign_cost_scope", "Incomplete campaign: actual total retained.") + " Prepared-owner construction, validation, retained bound derivation and close are recorded once; standalone fixed accounting excludes adaptive-only owner work."
        report["input_hashes_after"]=source_inventory()
        report["source_after"]=source_state()
        report["source_unchanged"]=report.get("input_hashes_before")==report["input_hashes_after"] and report.get("source_before")==report["source_after"]
        if not report["source_unchanged"]:
            report["status"]="failed"
            report["source_error"]="source changed during execution"
        if not check_runtime_inputs(report):
            report["status"]="failed"
            report["runtime_identity_error"]="native artifact, driver or tool identity changed or is incomplete"
        if "shared_campaign_cost_ns" in report:
            report["shared_campaign_cost_ns"] += report["runtime_identity_check_ns"]
            report["shared_campaign_cost_scope"] += " Final built-library, driver and compiler identity reconciliation is also charged once here."
        if prepared_bank is not None and report.get("status") == "completed":
            try:
                report["prepared_observed_costs"] = prepared_observed_costs(report, spec)
            except Exception as error:
                report["status"] = "failed"
                report["observed_cost_error"] = {"type": type(error).__name__, "message": str(error)}
        finalize_acceptance(report)
        report["wall_ns_before_final_encoding"]=time.monotonic_ns()-start
        report["host"]["parent_process_peak_rss_bytes"] = (None if resource is None or platform.system() != "Linux" else
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
        report["host"]["parent_rss_scope"] = "Process-lifetime high-water mark; not an isolated bound-owner allocation measurement."
        report["cost_exclusions"]=["tool installation","source acquisition","past reused NDU build (separately preserved original identity/cost)","human implementation/review","energy","allocator arena/metadata/fragmentation","final report and archive publication"]
        report["artifact_inventory"]={str(p.relative_to(directory)):file_identity(p) for p in sorted(directory.iterdir()) if p.is_file()}
        (directory/"RESULT.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",required=True)
    parser.add_argument("--clang",required=True)
    parser.add_argument("--rustc",required=True)
    parser.add_argument("--bridge",required=True)
    parser.add_argument("--identity",required=True)
    parser.add_argument("--build-profile", choices=("instrumented-checked-v1", "optimized-release-v1",
                                                   "verified-reduction-release-v1",
                                                   "verified-reduction-narrowed-release-v1"),
                        default="instrumented-checked-v1")
    parser.add_argument("--expected-source")
    parser.add_argument("--controller-profile", choices=("full-model-v3", "prepared-bank-v1"), default="full-model-v3")
    args=parser.parse_args()
    report=qualify(args)
    print(json.dumps({"status":report["status"],"error":report.get("error"),"acceptance":report.get("acceptance"),"output":args.output},indent=2))
    return 0 if report["status"]=="completed" else 1


if __name__=="__main__":
    raise SystemExit(main())
