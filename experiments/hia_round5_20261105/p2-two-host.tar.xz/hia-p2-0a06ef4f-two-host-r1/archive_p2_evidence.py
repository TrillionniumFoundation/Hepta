#!/usr/bin/env python3
"""Archive only pre-inspected public HIA evidence; restore and verify every byte."""
import datetime
import hashlib
import io
import json
import os
import pathlib
import resource
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/delivery-audit-r1')
SOURCE = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/work-integration')
HEAD = '0a06ef4f0894681af92b0caefba0704c1278d2cc'
TREE = 'a5239982f9fd8f08ab3a6e791147fc989e8d9df6'
NAME = 'hia-p2-0a06ef4f-two-host-r1'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(b):
    return hashlib.sha256(b).hexdigest()

def identity(path):
    b = path.read_bytes()
    return {'bytes': len(b), 'sha256': digest(b)}

def wire(d):
    return (json.dumps(d, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)

def source_identity():
    env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')
    def git(*a):
        return subprocess.run(['/usr/bin/git', '--no-replace-objects', *a], cwd=SOURCE,
                              env=env, capture_output=True, text=True, check=True).stdout.strip()
    result = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'status': git('status', '--porcelain', '--untracked-files=no')}
    assert result == {'commit': HEAD, 'tree': TREE, 'status': ''}
    return result

def main():
    assert sys.flags.optimize == 0
    request = json.load(sys.stdin)
    start = utc()
    wall = time.monotonic_ns()
    cpu = time.process_time_ns()
    before = source_identity()
    out = ROOT / 'p2-publication-r1'
    out.mkdir(exist_ok=False)
    payload = out / NAME
    payload.mkdir()
    allowed = request['whitelist']
    assert len(allowed) == len(set(allowed))
    assert set(os.sched_getaffinity(0)).issubset({8, 9})
    for rel in sorted(allowed):
        p = pathlib.PurePosixPath(rel)
        assert not p.is_absolute() and '..' not in p.parts and not p.name.startswith('.')
        original = ROOT / rel
        assert original.is_file() and not original.is_symlink()
        b = original.read_bytes()
        expected = request['expected_sha256'].get(rel)
        if expected:
            assert digest(b) == expected, rel
        write(payload / rel, b)
    package_dir = payload / 'p2-0a06ef4f-desktop-r1/package'
    package = json.loads((package_dir / 'PACKAGE.json').read_text())
    assert package['source_commit'] == HEAD and package['source_tree'] == TREE
    assert set(p.relative_to(package_dir).as_posix() for p in package_dir.rglob('*') if p.is_file()) == set(package['files']) | {'PACKAGE.json'}
    for rel, row in package['files'].items():
        b = (package_dir / rel).read_bytes()
        assert len(b) == row['bytes'] and digest(b) == row['sha256'], rel
        if 'git_blob' in row:
            assert hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == row['git_blob'], rel
    cross = json.loads((payload / 'CROSS_HOST_RESULT.json').read_text())
    assert cross['passed'] and cross['executed_stage_count'] == 6
    assert cross['source_before'] == before == cross['source_after']
    for label, original in request['outer_streams'].items():
        receipt = (cross['controller_receipts']['desktop_preparation_terminal_receipt'] if label == 'preparation'
                   else cross['controller_receipts']['runtime_terminal_receipts'][original['host']])
        assert original['job_id'] == receipt['job_id']
        for stream in ('stdout', 'stderr'):
            row = original[stream]
            b = bytes.fromhex(row['bytes_hex'])
            assert row['offset'] == 0 and row['eof'] and len(b) == row['size'] == row['next_offset']
            assert b.decode() == row['text']
            assert len(b) == receipt['log_bytes'][stream]['seen'] == receipt['log_bytes'][stream]['stored']
            write(payload / 'controller' / label / stream, b)
        write(payload / 'controller' / label / 'terminal-receipt.json', wire(receipt))
    write(payload / 'BACKEND_MIGRATION_REVIEW.json', wire(request['backend_migration_review']))
    write(payload / 'README.md', request['readme'].encode())
    write(payload / 'archive_p2_evidence.py', pathlib.Path(__file__).read_bytes())
    files = {p.relative_to(payload).as_posix(): identity(p) for p in sorted(payload.rglob('*')) if p.is_file()}
    manifest = {'schema': 'hepta.p2-publication-manifest.v1', 'source': before,
                'created_utc': utc(), 'file_count': len(files), 'files': files,
                'public_payload_policy': 'Explicit pre-inspected whitelist. Public HIA source/test objects and own evidence only. No compiler/runtime/model binaries, credentials, CI ZIPs or system core dumps.',
                'native_execution_scope': 'Two actual Linux x86_64 hosts, one preparation campaign on desktop; target compilation zero; three stages on each host.',
                'included_hashes': request['expected_sha256']}
    manifest_path = payload / 'P2_ARCHIVE_MANIFEST.json'
    write(manifest_path, wire(manifest))
    all_files = dict(files, **{'P2_ARCHIVE_MANIFEST.json': identity(manifest_path)})
    archive = out / (NAME + '.tar.xz')
    compression_start = utc()
    compression_cpu = time.process_time_ns()
    compression_wall = time.monotonic_ns()
    with tarfile.open(archive, 'w:xz', preset=1, format=tarfile.PAX_FORMAT) as tar:
        for rel in sorted(all_files):
            b = (payload / rel).read_bytes()
            info = tarfile.TarInfo(NAME + '/' + rel)
            info.size = len(b)
            info.mode = 0o644
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(b))
    compression = {'started_utc': compression_start, 'finished_utc': utc(),
                   'wall_ns': time.monotonic_ns() - compression_wall,
                   'cpu_ns': time.process_time_ns() - compression_cpu,
                   'lzma_preset': 1, 'cpu_affinity': sorted(os.sched_getaffinity(0))}
    archive_bytes = archive.read_bytes()
    archive_identity = dict(identity(archive), path=str(archive),
                            git_blob_sha1=hashlib.sha1(b'blob ' + str(len(archive_bytes)).encode() + b'\0' + archive_bytes).hexdigest())
    restored = out / 'fresh-restore'
    restored.mkdir(exist_ok=False)
    seen = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar:
            p = pathlib.PurePosixPath(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            assert not p.is_absolute() and '..' not in p.parts and p.parts[0] == NAME
            rel = pathlib.PurePosixPath(*p.parts[1:]).as_posix()
            assert rel in all_files and rel not in seen
            b = tar.extractfile(member).read()
            assert {'bytes': len(b), 'sha256': digest(b)} == all_files[rel], rel
            write(restored / rel, b)
            assert identity(restored / rel) == all_files[rel], rel
            seen.add(rel)
    assert seen == set(all_files)
    assert json.loads((restored / 'P2_ARCHIVE_MANIFEST.json').read_text()) == manifest
    assert identity(archive) == {k: archive_identity[k] for k in ('bytes', 'sha256')}
    after = source_identity()
    result = {'schema': 'hepta.p2-publication-result.v1', 'passed': True,
              'started_utc': start, 'finished_utc': utc(), 'source_before': before, 'source_after': after,
              'archive': archive_identity, 'manifest': dict(identity(manifest_path), path=str(manifest_path)),
              'manifest_payload_file_count': len(files), 'archive_regular_file_count': len(all_files),
              'fresh_restore_directory': str(restored), 'fresh_restore_all_files_sha256_verified': True,
              'archive_payload_file_set_exact': True, 'package_source_git_blobs_verified': True,
              'controller_original_streams_and_receipts_verified': True, 'source_unchanged': before == after,
              'compression': compression, 'wall_ns': time.monotonic_ns()-wall,
              'cpu_ns': time.process_time_ns()-cpu,
              'maximum_resident_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    write(out / 'P2_PUBLICATION_RESULT.json', wire(result))
    print(json.dumps(result))

if __name__ == '__main__':
    main()
