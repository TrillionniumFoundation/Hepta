# P2：同一 HIA 产物在两台实际 Linux 主机执行

本包绑定源 commit `0a06ef4f0894681af92b0caefba0704c1278d2cc`，tree `a5239982f9fd8f08ab3a6e791147fc989e8d9df6`。完整结论在 `CROSS_HOST_RESULT.json`；归档白名单及所有文件 SHA256 在 `P2_ARCHIVE_MANIFEST.json`。所有六个阶段已执行并通过，原 stdout、stderr、阶段 COMMAND/RESULT 和控制器终态回执均保留。

| 实际主机 | CPU | 内核 | 三阶段返回值 |
| --- | --- | --- | --- |
| desktop | Intel Xeon E5-2673 v3 @ 2.40GHz | 7.0.0-38-generic | base 0；预期 readonly 写入 SIGSEGV -11；race 0 |
| X230 | Intel Core i5-3230M @ 2.60GHz | 6.8.0-142-generic | base 0；预期 readonly 写入 SIGSEGV -11；race 0 |

两台均为 Linux x86-64、64 位指针、小端。desktop 构建及执行限 CPU 8–9；X230 执行限 CPU 0–1。desktop 做一个准备 campaign，调用两个未改动原资格器，产生五条实际 native 编译/链接命令和两份不同 shared object。X230 编译次数为零。包中同时保留准备阶段的原执行和后续 v2 同产物执行；v2 在每台仅执行一次，不是性能重跑。

## 同一性与语义检查

输入包 SHA256：`0e73e6f574a18cc2fb1a11768162a20d840623175212a13017a2435006d0561c`。PACKAGE.json SHA256：`de3071e1a3f9120b4e3619d33398aaee66c2276201885489a8c9cb6a0d6b681b`。全部公开 HIA Python 闭包、选中测试源及构建产物都逐字节绑定；source 条目还校验真实 Git blob。

- bridge.so：`7a6e6656949e5a726df73f7a3408e4f2345a4e0ced7a9293a58c34b6460d2ba5`
- race-bridge.so：`df15c9aa1326a9876bb0e99aaeaec730acb086af770a987f0f2602b997ab046a`
- v2 runner：`07623f5b28244c6fc3f95174ab962cba1caf222b2ff8ab84dfe55f92db8e7ca7`

v2 强制外部预期 manifest/head/tree，使用 Python -I -B 并确认 optimize=0；原语义断言实际生效。hepta/tools 模块在调用前后均验证来自包内。base/race 返回 0 还必须通过原 owner/lease/recovery/资源回收断言；fault 必须同时出现固定进入标记和 SIGSEGV。两个原生读者并行进入、竞争恢复恰好一次提交、迟到旧调用不得破坏新代际、工作线程全部 join、结束 owner/library 集合为空均由原报告记录。v1 runner 仅保留审查历史，从未用于执行。

## 范围

这是同 ISA/ABI 的第二台真实主机证据。它没有给 X230 本机编译器授予 HIA AOT 资格，没有增加新 ISA、设备或完整语言并发证明。有限指定交错没有穷尽所有调度；测试恢复的是 host region lease 代际，不是进程或操作系统崩溃恢复。没有性能优劣结论。root 的 36 命令组合资格仍是单独结果。

`BACKEND_MIGRATION_REVIEW.json` 保留迁移路径边界：历史 GSL 主 gate 实际执行 C backend；本轮另有真实 GSL5 Core→LLVM 补证（独立包/结果 SHA 引用）；SQLite 两个版本的选中片段没有变化；unique_ptr 的维护版本是 authored API variant。不能据此宣称全项目移植或开发成本收益。Windows/macOS 的 CI ZIP 不在本包，实际 Rust backend 的结果也不替代 HIA LLVM 后端资格。

## 内容与恢复

`p2-0a06ef4f-desktop-r1` 保留原准备报告、编译 IR/对象、两个 shared objects、输入包及其完整公开源码闭包；`p2-0a06ef4f-desktop-execution-v2-r1` 与 `x230-evidence` 保留六阶段原证据；`controller` 是实际控制器原始输出和终态回执。迁移审计是只读审计，未增加模型请求或 native cohort。

归档只从明确白名单取公开 HIA 源/测试产物及此次自有证据。没有编译器、运行库、私有模型材料或系统 core dump。归档器使用 CPU 8–9、低压缩级别，另写起止、CPU 用量、tar.xz SHA256 与 Git blob SHA1；每一个归档文件都在全新目录恢复并逐文件复核 SHA256。
