#!/usr/bin/env python3
"""Verify supplemental same-artifact two-host evidence and retain exact receipts."""
import pathlib,json,hashlib,tarfile,os,subprocess,sys,time
os.sched_setaffinity(0,{8,9})
ROOT=pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/delivery-audit-r1')
SOURCE=pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/work-integration')
HEAD='0a06ef4f0894681af92b0caefba0704c1278d2cc'
TREE='a5239982f9fd8f08ab3a6e791147fc989e8d9df6'
MANIFEST='de3071e1a3f9120b4e3619d33398aaee66c2276201885489a8c9cb6a0d6b681b'
RUNNER='07623f5b28244c6fc3f95174ab962cba1caf222b2ff8ab84dfe55f92db8e7ca7'
ARCHIVE='7083fbde2b58a60cf0c9de5903ea72fd12d44908a6a2ac01b8e7609267e1e09a'
TARGET='/home/qian/work/hia-a3b4-0a06ef4f-20261105'
DESKTOP=ROOT/'p2-0a06ef4f-desktop-execution-v2-r1'
BUILD=ROOT/'p2-0a06ef4f-desktop-r1'
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,d):
 with pathlib.Path(p).open('xb') as f:f.write(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
def state():
 env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
 def git(*args):return subprocess.run(['git','--no-replace-objects',*args],cwd=SOURCE,env=env,capture_output=True,text=True,check=True).stdout
 h,t=git('show','--no-patch','--format=%H%n%T','HEAD').strip().splitlines()
 return {'commit':h,'tree':t,'status':git('status','--porcelain=v1','--untracked-files=all')}
before=state();assert before=={'commit':HEAD,'tree':TREE,'status':''},before
controller=json.load(sys.stdin)
assert ident(ROOT/'x230-execution-v2-r1.tar.gz')['sha256']==ARCHIVE
local=ROOT/'x230-evidence';local.mkdir(exist_ok=False)
members=set()
with tarfile.open(ROOT/'x230-execution-v2-r1.tar.gz','r:gz') as tar:
 for m in tar:
  p=pathlib.PurePosixPath(m.name)
  assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in members
  assert m.size<1024*1024
  members.add(m.name);b=tar.extractfile(m).read();assert len(b)==m.size
  q=local/m.name;q.parent.mkdir(parents=True,exist_ok=True)
  with q.open('xb') as f:f.write(b)
transferred=read(local/'EXECUTION_MANIFEST.json')
assert transferred['source_commit']==HEAD
assert members=={r['path'] for r in transferred['files']}|{'EXECUTION_MANIFEST.json'}
for r in transferred['files']:
 a=ident(local/r['path']);assert a['bytes']==r['bytes'] and a['sha256']==r['sha256']
package=read(BUILD/'package/PACKAGE.json')
assert ident(BUILD/'package/PACKAGE.json')['sha256']==ident(local/'package/PACKAGE.json')['sha256']==MANIFEST
assert package['source_commit']==HEAD and package['source_tree']==TREE
assert ident(ROOT/'p2-tools/run_same_artifact_host_v2.py')['sha256']==ident(local/'run_same_artifact_host_v2.py')['sha256']==RUNNER
hosts={}
for name,directory,original in [('desktop',DESKTOP,str(ROOT)),('x230',local/'execution-v2-r1',TARGET)]:
 report=read(directory/'RESULT.json');reg=read(directory/'REGISTRATION.json')
 assert report['passed'] and report['source_and_artifacts_unchanged']
 assert report['source_commit']==HEAD and report['source_tree']==TREE
 assert reg['runner']['sha256']==report['runner']['sha256']==RUNNER
 assert reg['execution_host']==name and reg['source_content_identity']['manifest_sha256']==MANIFEST
 assert report['source_before']==report['source_after']==reg['source_content_identity']
 assert report['host_before']==report['host_after']
 flags=report['host_before']['python_flags']
 assert flags=={'optimize':0,'isolated':1,'ignore_environment':1,'dont_write_bytecode':1}
 observed=report['host_before']
 assert observed['machine']=='x86_64' and observed['system']=='Linux' and observed['pointer_bits']==64 and observed['byteorder']=='little'
 assert [(r['stage'],r['returncode']) for r in report['stages']]==[('base',0),('fault',-11),('race',0)]
 for r in report['stages']:
  assert r['passed'] and not r['timed_out']
  assert read(directory/r['stage']/'COMMAND.json')==r
  for stream in ('stdout','stderr'):
   a=ident(directory/r['stage']/stream)
   assert a['sha256']==r[stream]['sha256'] and a['bytes']==r[stream]['bytes']
  if r['stage']=='fault':
   assert r['entered_expected_fault_control']
   assert (directory/'fault/stdout').read_bytes()==b'deliberate false FFI read contract: native write must SIGSEGV\n'
  else:
   result=read(directory/r['stage']/'RESULT.json')
   a=ident(directory/r['stage']/'RESULT.json');assert a['sha256']==r['result']['sha256'] and a['bytes']==r['result']['bytes']
   assert result['package_before']==result['package_after']==report['source_before']
   assert result['package_unchanged'] and result['status']=='completed'
   for import_key in ('source_imports_before','source_imports_after'):
    for module,m in result[import_key].items():
     package_root=str(BUILD/'package') if name=='desktop' else TARGET+'/package'
     if 'namespace_paths' in m:
      assert all(pathlib.Path(p).is_relative_to(pathlib.Path(package_root)/'source') for p in m['namespace_paths'])
     else:
      rel=str(pathlib.Path(m['path']).relative_to(package_root))
      expected=package['files'][rel]
      assert m['sha256']==expected['sha256'] and m['bytes']==expected['bytes']
   retained=result['execution']['retained_after']
   assert not retained['regions'] and not retained['libraries']
 base=read(directory/'base/RESULT.json')['execution']
 race=read(directory/'race/RESULT.json')['execution']
 assert base['native_concurrent_reader_peak']>=2
 assert race['native_reader_entries']==2 and sorted(r['status'] for r in race['recoveries'])==['committed','denied']
 assert race['all_native_workers_joined'] and race['old_caller_cannot_commit_or_revoke_recovered_epoch']
 receipt=controller['runtime_terminal_receipts'][name]
 assert receipt['state']=='succeeded' and receipt['exit_code']==0 and receipt['output_complete'] and receipt['output_durable'] and receipt['terminal_publication_confirmed']
 hosts[name]={'host':observed,'run_wall_ns':report['wall_ns'],'report':ident(directory/'RESULT.json'),
              'registration':ident(directory/'REGISTRATION.json'),'native_reader_peak':base['native_concurrent_reader_peak'],
              'base_denials':[r['case'] for r in base['denials']],'race_denials':[r['case'] for r in race['denials']],
              'race_recovery_statuses':sorted(r['status'] for r in race['recoveries']),
              'late_caller':race['late_caller'],'retained_after_base':base['retained_after'],
              'retained_after_race':race['retained_after'],'stage_returncodes':[r['returncode'] for r in report['stages']],
              'runtime_terminal_receipt':receipt}
assert hosts['desktop']['host']['node']!=hosts['x230']['host']['node']
assert hosts['desktop']['host']['cpu_model']!=hosts['x230']['host']['cpu_model']
assert controller['outbound_archive_transfer']['sha256']=='0e73e6f574a18cc2fb1a11768162a20d840623175212a13017a2435006d0561c'
assert controller['inbound_evidence_transfer']['sha256']==ARCHIVE
assert read(local/'UNPACK_RESULT.json')['all_recorded_source_git_blobs_match']
after=state();assert after==before
build=read(BUILD/'DESKTOP_RESULT.json')
native_compiles=[]
for kind in ('host-region','host-region-race'):
 for c in read(BUILD/kind/'RESULT.json')['build_commands']:
  if '-c' in c['argv'] or '-shared' in c['argv']:
   native_compiles.append({'qualifier':kind,'argv':c['argv']})
result={'schema':'hepta.hia.same-artifact-second-host-audited.v1','passed':True,
        'source_before':before,'source_after':after,'source_unchanged':True,'hosts':hosts,
        'executed_stage_count':6,'native_compilation_host':'desktop','target_host_compilation_count':0,
        'desktop_preparation_campaigns':1,'desktop_original_qualifier_invocations':2,
        'desktop_preparation_native_compile_commands':native_compiles,'desktop_preparation_wall_ns':build['wall_ns'],
        'source_execution_package_manifest':ident(BUILD/'package/PACKAGE.json'),
        'source_execution_package_archive':ident(BUILD/'x230-package.tar.gz'),
        'native_artifacts':{k:v for k,v in package['files'].items() if k.startswith('artifacts/')},
        'runner':ident(ROOT/'p2-tools/run_same_artifact_host_v2.py'),
        'target_archive':ident(ROOT/'x230-execution-v2-r1.tar.gz'),
        'controller_receipts':controller,
        'qualification_scope':'Same exact native artifacts and committed Python content closure on two actual Linux x86-64 hosts; bounded coherent hosted RAM with synchronous no-pointer-escape C ABI, owner mutex and actual worker join.',
        'memory_ordering_scope':'Private C11 acquire/release rendezvous and counters only; data leases remain under HostRegion owner synchronization. This is one recovery schedule per host, not an exhaustive language memory-model proof.',
        'claims':{'second_machine_executed':True,'second_isa_supported':False,'new_abi_supported':False,
                  'device_dma_mmio_supported':False,'target_host_compiler_qualified':False,
                  'process_or_os_crash_recovery':False,'whole_language_concurrency_proved':False,
                  'all_interleavings_exhausted':False,'performance_comparison_or_advantage':False,
                  'fully_hermetic_runtime_custody':False,'root_36_command_qualification_extended':False},
        'review_note':'Execution wrapper v1 was never used. Static review added external manifest/head/tree binding, strict source import origins and explicit -I -B assertions-enabled flags before v2 native execution. Original desktop build/qualification receipts are retained; each host executed v2 once, without a rebuild or timing rerun.'}
write(ROOT/'CROSS_HOST_RESULT.json',result)
print(json.dumps({'passed':True,'result':ident(ROOT/'CROSS_HOST_RESULT.json'),
                  'hosts':{k:{'cpu':v['host']['cpu_model'],'kernel':v['host']['release'],'stages':v['stage_returncodes']} for k,v in hosts.items()},
                  'native_artifacts':result['native_artifacts'],'native_compile_commands':len(native_compiles)}))
