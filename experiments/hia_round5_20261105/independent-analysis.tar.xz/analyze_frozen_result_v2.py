#!/usr/bin/env python3
"""Read completed frozen evidence; never import/execute project code or tests.

The audit recomputes timing quantiles, all registered comparison/resource gates,
the actual episode medians, and nesting of observed costs from retained bytes.
Negative performance findings are valid observations, not audit failures.
"""
import argparse
import collections
import datetime
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import statistics
import time

METRIC_NAMES = ("attempts", "allocations", "frees", "refusals", "live",
    "requested_total", "usable_total", "peak_requested", "peak_usable",
    "live_requested", "live_usable", "accounting_errors", "stack_anchor", "stack_max_distance")


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def summarize(values):
    values = sorted(values)
    median = statistics.median(values)
    return {"count": len(values), "minimum": values[0], "median": median,
            "p95": values[math.ceil(.95 * len(values)) - 1],
            "p99": values[math.ceil(.99 * len(values)) - 1], "maximum": values[-1],
            "relative_mad": statistics.median(abs(v - median) for v in values) / max(1, median),
            "excluded": 0}


class Snapshot:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.cache = {}
        self.manifest = {}

    def read(self, path):
        path = Path(path)
        if not path.is_absolute():
            path = self.root / path
        path = path.resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("evidence reference leaves registered root: " + str(path))
        key = str(path.relative_to(self.root))
        if key not in self.cache:
            before = path.stat()
            raw = path.read_bytes()
            after = path.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError("evidence changed during read: " + key)
            self.cache[key] = raw
            self.manifest[key] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        return self.cache[key]

    def json(self, path):
        return json.loads(self.read(path))

    def receipt(self, item, errors):
        raw = self.read(item["path"])
        if item.get("bytes", len(raw)) != len(raw) or item["sha256"] != hashlib.sha256(raw).hexdigest():
            errors.append("raw log receipt mismatch: " + item["path"])


def check(errors, condition, label):
    if not condition:
        errors.append(label)


def aot_audit(snap, errors):
    report = snap.json("composition/outlined-aot/RESULT.json")
    resource = snap.json("composition/outlined-aot-resource-cost.json")
    spec = report["protocol"]
    rspec = resource["protocol"]
    rows = report["measurements"]
    check(errors, report["source_before"] == report["source_after"] and
          report["bindings_before"] == report["bindings_after"] and
          report["tool_artifact_identities_unchanged"] is True, "AOT stable source/tool/artifact bindings")
    for artifacts in report["artifacts"].values():
        for artifact in artifacts.values(): snap.receipt(artifact, errors)
    snap.receipt(report["driver_identity"], errors)
    candidate = rspec["candidate"]
    baselines = rspec["baselines"]
    dimensions = ("workload", "group", "n", "seed", "calls")
    identity = lambda row: tuple(row[k] for k in dimensions)
    expected = {(w, g["name"], n, seed, calls, arm)
                for w in spec["historical_profile"]["workloads"] for g in spec["groups"]
                for n in g["sizes"] for seed in g["seeds"] for calls in spec["batch_loads"]
                for arm in spec["arms"]}
    actual = [(*identity(r), r["backend"]) for r in rows]
    check(errors, len(actual) == len(set(actual)) and set(actual) == expected,
          "AOT complete unique registered row inventory")
    check(errors, len(rows) == 3348 == spec["timing_requests"], "AOT 3348 request denominator")
    check(errors, all(len(r["times_ns"]) == spec["samples"] and
                      all(type(v) is int and v > 0 for v in r["times_ns"]) and
                      sum(r["times_ns"]) == r["elapsed_ns"] for r in rows), "AOT every native sample retained")
    check(errors, digest(spec) == report["protocol_sha256"], "AOT canonical protocol hash")
    check(errors, digest({k: v for k, v in report.items() if k != "report_sha256"}) == report["report_sha256"],
          "AOT canonical full report hash")
    check(errors, resource["input_file_sha256"] == snap.manifest["composition/outlined-aot/RESULT.json"]["sha256"],
          "resource assessor binds exact AOT file bytes")
    check(errors, resource["input_report_sha256"] == report["report_sha256"], "resource assessor canonical AOT hash")
    check(errors, digest(rspec) == resource["protocol_sha256"], "resource protocol canonical hash")
    grouped = collections.defaultdict(list)
    indexed = {}
    for row in rows:
        grouped[(row["workload"], row["group"], row["n"], row["calls"], row["backend"])].extend(row["times_ns"])
        indexed[(identity(row), row["backend"])] = row
    summaries = {k: summarize(v) for k, v in grouped.items()}
    comparisons = []
    gate = spec["performance_gate"]
    for cohort in report["assessment"]["cohorts"]:
        key = tuple(cohort[k] for k in ("workload", "group", "n", "calls"))
        for arm, observed in cohort["summaries"].items():
            check(errors, observed == summaries[(*key, arm)], "AOT cohort summary: " + repr((*key, arm)))
    for observed in report["assessment"]["comparisons"]:
        key = tuple(observed[k] for k in ("workload", "group", "n", "calls"))
        ratios = {m + "_ratio": summaries[(*key, candidate)][m] / summaries[(*key, observed["baseline"])][m]
                  for m in ("median", "p95", "p99")}
        passed = all(ratios[m + "_ratio"] <= gate[m + "_ratio_maximum"] for m in ("median", "p95", "p99"))
        check(errors, all(observed[k] == v for k, v in ratios.items()) and observed["passed"] == passed,
              "AOT comparison arithmetic: " + repr((*key, observed["baseline"])))
        if observed["baseline"] in baselines:
            comparisons.append({**observed, "failed_metrics": [m for m in ("median", "p95", "p99")
                if ratios[m + "_ratio"] > gate[m + "_ratio_maximum"]]})
    check(errors, len(comparisons) == 372, "AOT 372 paired Rust joint gates")
    check(errors, sum(r["passed"] for r in comparisons) == report["assessment"]["candidate_rust_comparisons_passed"],
          "AOT joint pass total")
    # Independently reconnect every retained request/response trace to its rows.
    associations = resource["load_receipt_associations"]
    loads = {}
    raw_responses = 0
    for row in associations:
        key = (row["workload"], row["group"], row["seed"], row["backend"])
        check(errors, key not in loads, "unique loader identity: " + repr(key))
        loads[key] = row
        raw = snap.read("composition/outlined-aot/" + row["raw_trace_file"])
        check(errors, hashlib.sha256(raw).hexdigest() == row["raw_trace_sha256"], "AOT raw trace hash: " + row["raw_trace_file"])
        records = [json.loads(line) for line in raw.splitlines()]
        check(errors, records[-1].get("exit_code") == 0 and records[-1].get("stderr_hex") == "", "AOT native child terminal")
        for pos, rec in enumerate(records):
            if "request" not in rec or not rec["request"].startswith("R "):
                continue
            fields = rec["request"].split()
            n, seed, calls = map(int, fields[2:5])
            native = json.loads(bytes.fromhex(records[pos + 1]["response_hex"]))
            stored = indexed[((row["workload"], row["group"], n, seed, calls), row["backend"])]
            check(errors, len(native["metrics"]) == len(METRIC_NAMES), "raw allocator metric vector length")
            native["metrics"] = dict(zip(METRIC_NAMES, native["metrics"]))
            check(errors, all(stored[k] == v for k, v in native.items()),
                  "AOT raw timed response values: " + repr((key, n, calls)))
            raw_responses += 1
    check(errors, raw_responses == len(rows), "all AOT request/response records read exactly once")
    arms = report["cost_and_memory"]["arms"]
    checks = []
    def add(gate_name, dims, value, reference, maximum):
        checks.append({"gate": gate_name, **dims, "candidate": value, "baseline_value": reference,
                       "ratio_maximum": maximum, "limit": reference * maximum,
                       "passed": value <= reference * maximum})
    for row in rows:
        if row["backend"] != candidate:
            continue
        for baseline in baselines:
            other = indexed[(identity(row), baseline)]
            dims = {k: row[k] for k in dimensions}; dims["baseline"] = baseline
            for metric in rspec["allocator_metrics"]:
                add("memory." + metric, dims, row["metrics"][metric], other["metrics"][metric], rspec["allocator_metric_ratio_maximum"])
            check(errors, row["first_library_call"] == other["first_library_call"], "AOT paired cold marker")
            if row["first_library_call"]:
                add("cost.cold_first_call", dims, row["cold_ns"], other["cold_ns"], rspec["cold_first_call_ratio_maximum"])
    for key, row in loads.items():
        if row["backend"] != candidate:
            continue
        for baseline in baselines:
            other = loads[(*key[:3], baseline)]
            dims = {k: row[k] for k in ("workload", "group", "seed")}; dims["baseline"] = baseline
            for metric in rspec["loader_metrics"]:
                add("memory.loader_" + metric, dims, row["mapping"][metric], other["mapping"][metric], rspec["loader_metric_ratio_maximum"])
    for workload, backends in arms.items():
        for arm, value in backends.items():
            raw_loads = [r["load_ns"] for r in associations if r["workload"] == workload and r["backend"] == arm]
            check(errors, value["load_ns"] == summarize(raw_loads), "AOT loader summary from raw receipts")
            check(errors, value["compile_and_proofs_wall_ns"] == report["backend_build_wall_ns"][workload][arm], "AOT build wall binding")
            check(errors, value["library_file_bytes"] == report["artifacts"][workload][arm]["bytes"], "AOT library size binding")
        for baseline in baselines:
            dims = {"workload": workload, "baseline": baseline}
            for gate_name, field, limit in [("memory.library_file", "library_file_bytes", "library_file_ratio_maximum"),
                ("cost.build_and_proof", "compile_and_proofs_wall_ns", "build_and_proof_ratio_maximum")]:
                add(gate_name, dims, backends[candidate][field], backends[baseline][field], rspec[limit])
            add("cost.median_load", dims, backends[candidate]["load_ns"]["median"], backends[baseline]["load_ns"]["median"], rspec["median_loader_wall_ratio_maximum"])
    for row in report["cost_and_memory"]["amortization"]:
        key = tuple(row[k] for k in ("workload", "group", "n", "calls"))
        values = {a: arms[row["workload"]][a]["compile_and_proofs_wall_ns"] + arms[row["workload"]][a]["load_ns"]["median"]
                  + row["invocations"] * (summaries[(*key, a)]["median"] / row["calls"]) for a in spec["arms"]}
        check(errors, values == row["estimated_automated_cost_ns"], "AOT warm amortization arithmetic")
        for baseline in baselines:
            dims = {k: row[k] for k in ("workload", "group", "n", "calls", "invocations")}; dims["baseline"] = baseline
            add("cost.estimated_automated", dims, values[candidate], values[baseline], rspec["estimated_automated_cost_ratio_maximum"])
    check(errors, sorted(map(wire, checks)) == sorted(map(wire, resource["checks"])), "all AOT resource/cost gates independently reproduced")
    by_gate = {}
    for row in checks:
        group = by_gate.setdefault(row["gate"], {"passed": 0, "total": 0})
        group["passed"] += int(row["passed"]); group["total"] += 1
    check(errors, by_gate == resource["by_gate"], "AOT all resource gate denominators")
    memory = [r for r in checks if r["gate"].startswith("memory.")]
    cold = [r for r in checks if r["gate"] == "cost.cold_first_call"]
    check(errors, len(cold) == 48 and len(memory) == 5680, "AOT 48 cold and 5680 memory denominators")
    return {"qualification_valid": report["qualification_valid"], "source_before": report["source_before"],
        "source_unchanged": report["source_unchanged"], "protocol_sha256": report["protocol_sha256"],
        "resource_protocol_file_sha256": resource["resource_protocol_file_sha256"],
        "host": report["host"], "joint_passed": sum(r["passed"] for r in comparisons), "joint_total": len(comparisons),
        "cold_passed": sum(r["passed"] for r in cold), "cold_total": len(cold),
        "memory_passed": sum(r["passed"] for r in memory), "memory_total": len(memory), "by_gate": by_gate,
        "joint_failed_cells": [r for r in comparisons if not r["passed"]],
        "resource_cost_failed_cells": [r for r in checks if not r["passed"]],
        "correctness_rows": len(report["correctness"]), "refusal_rows": len(report["refusals"]),
        "timing_requests": len(rows), "timed_batches": sum(len(r["times_ns"]) for r in rows),
        "timed_calls": sum(len(r["times_ns"]) * r["calls"] for r in rows), "raw_timing_response_rows_checked": raw_responses,
        "whole_lifecycle_wall_ns": report["whole_lifecycle_wall_ns"], "nested_stage_wall_ns": report["stage_wall_ns"],
        "resource_analysis_wall_ns": resource["analysis_wall_ns"],
        "broad_parity_established": resource["broad_rust_parity_established"],
        "full_lifecycle_net_benefit_established": resource["full_lifecycle_net_benefit_established"],
        "limits": rspec["claim_limits"]}


def ndu_audit(snap, composition, errors):
    report = snap.json("composition/ndu-cost/REPORT.json")
    episodes = report["episodes"]
    groups = collections.defaultdict(list)
    services = collections.Counter()
    ids = []
    for episode in episodes:
        key = (episode["episode"], episode["policy"])
        groups[key].append(episode["service_wall_ns"])
        services[episode["policy"]] += episode["service_wall_ns"]
        ids.append(episode["id"])
    check(errors, len(episodes) == len(set(ids)) == 36, "NDU 36 unique retained episodes")
    comparisons = []
    for row in report["comparisons"]:
        medians = {p: statistics.median(groups[(row["episode"], p)]) for p in row["median_service_ns"]}
        check(errors, medians == row["median_service_ns"], "NDU actual service medians")
        wins = all(medians["native_ndu"] < v for p, v in medians.items() if p != "native_ndu")
        check(errors, wins == row["native_beats_all_controls"], "NDU net win arithmetic")
        comparisons.append({**row, "independently_recomputed_native_beats_controls": wins})
    wins = sum(r["independently_recomputed_native_beats_controls"] for r in comparisons)
    acceptance = report["acceptance"]
    check(errors, wins == acceptance["native_net_win_scenarios"] and len(comparisons) == acceptance["scenario_count"], "NDU scenario denominator")
    shared = report["shared_cost_policy"]
    for policy, value in shared["arm_full_cost_ns"].items():
        expected = report["offline_wall_ns"] + services[policy]
        if policy == "native_ndu": expected += shared["bridge_build_wall_ns"]
        check(errors, value == expected, "NDU declared complete per-policy allocation: " + policy)
    outer = composition["ndu_outer_cost_completion"]
    for policy, value in outer["conservative_solo_campaign_cost_by_policy_ns"].items():
        expected = shared["arm_full_cost_ns"][policy] + outer["common_unallocated_runner_overhead_ns"]
        if policy == "native_ndu": expected += outer["native_build_additional_charged_ns"]
        check(errors, value == expected, "NDU outer remainder charged once: " + policy)
    return {"acceptance": acceptance, "comparisons": comparisons, "episode_count": len(episodes),
        "episode_ids": ids, "service_sum_by_policy_ns": dict(services), "shared_cost_policy": shared,
        "outer_cost_completion": outer, "campaign_wall_ns": report["campaign_wall_ns"],
        "source_stable": report["source_stable"], "source_git": report["git"],
        "authority": report["authority"], "safety_certificate": report["safety_certificate"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    os.sched_setaffinity(0, {6, 7})
    started = time.monotonic_ns()
    snap, baseline = Snapshot(args.evidence), Snapshot(args.baseline)
    errors = []
    sequence = snap.json("RESULT.json")
    registration = snap.json("REGISTRATION.json")
    composition = snap.json("composition/RESULT.json")
    combination = snap.json("composition/COMBINATION.json")
    plan = snap.json("composition/PLAN.json")
    old_composition = baseline.json("composition/RESULT.json")
    old_core = baseline.json("composition/CORE.json")
    core = snap.json("composition/CORE.json")
    for label, row in (("sequence", sequence), ("registration", registration)):
        check(errors, row["source_commit"] == args.expected_head and row["source_tree"] == args.expected_tree, label + " frozen identity")
    for label, row in (("composition", composition), ("combination", combination), ("plan", plan)):
        check(errors, row["source"]["commit"] == args.expected_head and row["source"]["tree"] == args.expected_tree, label + " frozen identity")
    check(errors, registration["proof_budget_seconds"] == 600 and registration["independent_replay_budget_seconds"] == 600,
          "original 600 second proof/replay budgets")
    check(errors, len(sequence["commands"]) == 3 and [r["name"] for r in sequence["commands"]] == ["proof", "independent-replay", "composition"], "three sequence commands")
    for command in sequence["commands"]:
        for stream in ("stdout", "stderr"): snap.receipt(command[stream], errors)
    commands = composition["commands"]
    check(errors, len(commands) == len({c["name"] for c in commands}) == 36, "36 unique composition commands")
    check(errors, [r["name"] for r in commands] == [r["name"] for r in old_composition["commands"]], "S3 command inventory and order retained")
    for command in commands:
        path = "composition/commands/" + command["name"] + ".command.json"
        receipt = snap.json(path)
        check(errors, receipt == command, "command JSON matches aggregate: " + command["name"])
        for name, info in receipt["logs"].items():
            raw = snap.read("composition/commands/" + name)
            check(errors, len(raw) == info["bytes"] and hashlib.sha256(raw).hexdigest() == info["sha256"], "command log identity: " + name)
    qualifications = composition["qualifications"]
    check(errors, len(qualifications) == 34 and set(qualifications) == set(old_composition["qualifications"]), "34 qualification flags")
    check(errors, core["planned"] == core["started"] == core["finished"] and len(core["planned"]) == core["tests"] == len(set(core["planned"])), "core exact planned/started/finished test IDs")
    old_ids, new_ids = set(old_core["planned"]), set(core["planned"])
    check(errors, not (old_ids - new_ids), "S3 registered CORE test ID preservation (not all historical tests)")
    aot = aot_audit(snap, errors)
    ndu = ndu_audit(snap, composition, errors)
    check(errors, aot["source_before"]["head"] == args.expected_head and aot["source_before"]["status"] == "",
          "AOT exact frozen commit, not a substituted historical report")
    check(errors, ndu["source_git"]["head"] == args.expected_head and ndu["source_git"]["status"] == "",
          "NDU exact frozen commit, not a substituted historical report")
    old_aot = baseline.json("composition/outlined-aot/RESULT.json")
    old_resources = baseline.json("composition/outlined-aot-resource-cost.json")
    check(errors, aot["protocol_sha256"] == old_aot["protocol_sha256"] and
          aot["resource_protocol_file_sha256"] == old_resources["resource_protocol_file_sha256"], "same AOT timing and resource protocols as S3")
    cell = lambda r: tuple(r[k] for k in ("workload", "group", "n", "calls", "baseline"))
    old_failed = {cell(r) for r in old_aot["assessment"]["comparisons"] if r["baseline"].startswith("rust") and not r["passed"]}
    new_failed = {cell(r) for r in aot["joint_failed_cells"]}
    aot["s3_failure_overlap"] = {"old_failed": len(old_failed), "still_failed": sorted(old_failed & new_failed),
        "now_passed": sorted(old_failed - new_failed), "new_failed_cells": sorted(new_failed - old_failed),
        "interpretation": "One complete registered cohort each; shared-host observations, no causal noise correction or selected-cell rerun."}
    child_total = sum(c["elapsed_ns"] for c in sequence["commands"])
    command_total = sum(c["wall_ns"] for c in commands)
    costs = {"sequence_wall_ns": sequence["elapsed_ns"], "nested_sequence_command_wall_ns": child_total,
        "sequence_remainder_ns": sequence["elapsed_ns"] - child_total,
        "composition_inner_wall_ns": composition["elapsed_ns"], "nested_composition_commands_wall_ns": command_total,
        "composition_remainder_ns": composition["elapsed_ns"] - command_total,
        "rule": "Parent walls include their child walls. Never sum parent plus children; conservative solo-policy allocations are alternative attributed scenarios, not separately executed campaigns.",
        "unknown_human_engineering_energy_historical_acquisition": None}
    check(errors, costs["sequence_remainder_ns"] >= 0 and costs["composition_remainder_ns"] >= 0, "nonnegative nested accounting remainders")
    result = {"schema": "hepta.hia.independent-frozen-results-audit.v1", "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "evidence_root": str(snap.root), "baseline_root": str(baseline.root), "expected_head": args.expected_head, "expected_tree": args.expected_tree,
        "audit_cpu_affinity": sorted(os.sched_getaffinity(0)), "audit_is_new_native_execution": False, "audit_is_new_model_request": False,
        "parser_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "verification_errors": errors,
        "independent_consistency_checks_passed": not errors, "sequence": sequence,
        "combination": {"source_commit": composition["source"]["commit"], "source_tree": composition["source"]["tree"],
            "command_count": len(commands), "commands": commands, "qualifications": qualifications,
            "qualification_flag_count": len(qualifications), "qualification_flags_true": sum(v is True for v in qualifications.values()),
            "nonzero_or_incomplete_commands": [r for r in commands if r["returncode"] != 0 or r["timed_out"] or r["launch_error"]],
            "same_combination_build_execute_reject_cancel_recover": composition["p0_same_combination_build_execute_reject_cancel_recover"],
            "source_and_tools_unchanged": composition["source_and_tools_unchanged"],
            "authority": composition["authority"], "all_seven_targets_closed": composition["all_seven_research_targets_closed"]},
        "core": {**core, "s3_registered_tests": len(old_ids), "removed_s3_ids": sorted(old_ids-new_ids), "added_ids": sorted(new_ids-old_ids),
            "historical_scope": "This compares S3 CORE IDs only. Branch 5ee6 has three different research tests not retained identically; see HISTORICAL_TEST_SCOPE_AUDIT.json."},
        "aot": aot, "ndu": ndu, "costs": costs, "input_files": snap.manifest, "baseline_input_files": baseline.manifest,
        "limits": ["JSON/log arithmetic and provenance audit only; no theorem, checker, test or benchmark re-executed.",
            "A green qualification flag records a valid experiment; it does not mean every performance/economic gate passed.",
            "General formal theorems, fixed-program checks and finite observations remain distinct; twelve wider production refinement obligations remain open."],
        "audit_elapsed_ns": time.monotonic_ns() - started}
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with output.open("xb") as stream: stream.write(raw)
    print(json.dumps({"path": str(output), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "audit_passed": not errors, "errors": errors, "commands": len(commands), "flags": len(qualifications), "core_tests": core["tests"],
        "aot_joint": [aot["joint_passed"], aot["joint_total"]], "aot_cold": [aot["cold_passed"], aot["cold_total"]],
        "aot_memory": [aot["memory_passed"], aot["memory_total"]],
        "ndu_wins": [ndu["acceptance"]["native_net_win_scenarios"], ndu["acceptance"]["scenario_count"]]}, sort_keys=True))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
