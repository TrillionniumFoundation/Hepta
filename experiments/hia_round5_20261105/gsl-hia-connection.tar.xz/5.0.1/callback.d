capture: \
  /data/hepta-hia-round5-a3b4-20261105/work-integration/examples/cpp/gsl_final_action/callback.cpp \
  /data/hepta-hia-round5-a3b4-20261105/work-integration/examples/cpp/gsl_final_action/callback.hpp
