; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 0, 1
  %t6 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t5, 0
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i64 %p_0_0, 1
  %t8 = insertvalue { %hia.buffer, i64, i1 } %t7, i1 true, 2
  ret { %hia.buffer, i64, i1 } %t8
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_1(%hia.buffer %p_0_0, i64 %p_0_1, i1 %p_0_2) {
b0:
  %t1 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %p_0_0, 0
  %t2 = insertvalue { %hia.buffer, i64, i1 } %t1, i64 %p_0_1, 1
  %t3 = insertvalue { %hia.buffer, i64, i1 } %t2, i1 %p_0_2, 2
  ret { %hia.buffer, i64, i1 } %t3
}

define internal { i64, i64 } @__hia_fn_2(%hia.buffer %p_0_0, i64 %p_0_1, i1 %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  br i1 %p_0_2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t1 = mul i64 %p_1_3, 32
  %t2 = add i64 %t1, %p_1_1
  %t3 = add i64 %p_1_4, 1
  br label %edge_2
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i1 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i64 [ %t2, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i64 [ %t3, %edge_2 ], [ %p_2_4, %edge_3 ]
  %t4 = extractvalue %hia.buffer %p_3_0, 0
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %drop_nonnull_6, label %drop_after_6
drop_nonnull_6:
  call void @free(ptr %t4) nobuiltin
  br label %drop_after_6
drop_after_6:
  %t7 = insertvalue { i64, i64 } zeroinitializer, i64 %p_3_3, 0
  %t8 = insertvalue { i64, i64 } %t7, i64 %p_3_4, 1
  ret { i64, i64 } %t8
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_3(i64 %p_0_0) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t2, 0
  %t6 = insertvalue { %hia.buffer, i64, i1 } %t5, i64 %t3, 1
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i1 %t4, 2
  ret { %hia.buffer, i64, i1 } %t7
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_4(i64 %p_0_0) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t2, 0
  %t6 = insertvalue { %hia.buffer, i64, i1 } %t5, i64 %t3, 1
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i1 %t4, 2
  ret { %hia.buffer, i64, i1 } %t7
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_5(i64 %p_0_0) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t2, 0
  %t6 = insertvalue { %hia.buffer, i64, i1 } %t5, i64 %t3, 1
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i1 %t4, 2
  ret { %hia.buffer, i64, i1 } %t7
}

define internal { i64, i64, i64 } @__hia_fn_6(%hia.buffer %p_0_0, i64 %p_0_1, i1 %p_0_2, i64 %p_0_3, i64 %p_0_4, i32 %p_0_5) {
b0:
  %t1 = icmp eq i32 %p_0_5, 1
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i32 [ %p_0_5, %edge_0 ]
  %t2 = call { i64, i64 } @__hia_fn_2(%hia.buffer %p_1_0, i64 %p_1_1, i1 %p_1_2, i64 %p_1_3, i64 %p_1_4)
  %t3 = extractvalue { i64, i64 } %t2, 0
  %t4 = extractvalue { i64, i64 } %t2, 1
  %t5 = insertvalue { i64, i64, i64 } zeroinitializer, i64 2001, 0
  %t6 = insertvalue { i64, i64, i64 } %t5, i64 %t3, 1
  %t7 = insertvalue { i64, i64, i64 } %t6, i64 %t4, 2
  ret { i64, i64, i64 } %t7
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i32 [ %p_0_5, %edge_1 ]
  %t8 = icmp eq i32 %p_2_5, 2
  br i1 %t8, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_2_1, %edge_2 ]
  %p_3_2 = phi i1 [ %p_2_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_2_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_2 ]
  %p_3_5 = phi i32 [ %p_2_5, %edge_2 ]
  %t9 = call { i64, i64 } @__hia_fn_2(%hia.buffer %p_3_0, i64 %p_3_1, i1 %p_3_2, i64 %p_3_3, i64 %p_3_4)
  %t10 = extractvalue { i64, i64 } %t9, 0
  %t11 = extractvalue { i64, i64 } %t9, 1
  %t12 = insertvalue { i64, i64, i64 } zeroinitializer, i64 2002, 0
  %t13 = insertvalue { i64, i64, i64 } %t12, i64 %t10, 1
  %t14 = insertvalue { i64, i64, i64 } %t13, i64 %t11, 2
  ret { i64, i64, i64 } %t14
b4:
  %p_4_0 = phi %hia.buffer [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_2_1, %edge_3 ]
  %p_4_2 = phi i1 [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  %p_4_5 = phi i32 [ %p_2_5, %edge_3 ]
  %t15 = icmp eq i32 %p_4_5, 3
  br i1 %t15, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi %hia.buffer [ %p_4_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_4_1, %edge_4 ]
  %p_5_2 = phi i1 [ %p_4_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_4_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_4_4, %edge_4 ]
  %p_5_5 = phi i32 [ %p_4_5, %edge_4 ]
  %t16 = call { %hia.buffer, i64, i1 } @__hia_fn_1(%hia.buffer %p_5_0, i64 %p_5_1, i1 %p_5_2)
  %t17 = extractvalue { %hia.buffer, i64, i1 } %t16, 0
  %t18 = extractvalue { %hia.buffer, i64, i1 } %t16, 1
  %t19 = extractvalue { %hia.buffer, i64, i1 } %t16, 2
  %t20 = call { i64, i64 } @__hia_fn_2(%hia.buffer %t17, i64 %t18, i1 %t19, i64 %p_5_3, i64 %p_5_4)
  %t21 = extractvalue { i64, i64 } %t20, 0
  %t22 = extractvalue { i64, i64 } %t20, 1
  %t23 = insertvalue { i64, i64, i64 } zeroinitializer, i64 2003, 0
  %t24 = insertvalue { i64, i64, i64 } %t23, i64 %t21, 1
  %t25 = insertvalue { i64, i64, i64 } %t24, i64 %t22, 2
  ret { i64, i64, i64 } %t25
b6:
  %p_6_0 = phi %hia.buffer [ %p_4_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_4_1, %edge_5 ]
  %p_6_2 = phi i1 [ %p_4_2, %edge_5 ]
  %p_6_3 = phi i64 [ %p_4_3, %edge_5 ]
  %p_6_4 = phi i64 [ %p_4_4, %edge_5 ]
  %p_6_5 = phi i32 [ %p_4_5, %edge_5 ]
  %t26 = icmp eq i32 %p_6_5, 5
  br i1 %t26, label %edge_6, label %edge_7
b7:
  %p_7_0 = phi %hia.buffer [ %p_6_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_6_1, %edge_6 ]
  %p_7_2 = phi i1 [ %p_6_2, %edge_6 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_6 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_6 ]
  %p_7_5 = phi i32 [ %p_6_5, %edge_6 ]
  %t27 = call { %hia.buffer, i64, i1 } @__hia_fn_3(i64 9)
  %t28 = extractvalue { %hia.buffer, i64, i1 } %t27, 0
  %t29 = extractvalue { %hia.buffer, i64, i1 } %t27, 1
  %t30 = extractvalue { %hia.buffer, i64, i1 } %t27, 2
  %t31 = call { i64, i64 } @__hia_fn_2(%hia.buffer %t28, i64 %t29, i1 %t30, i64 %p_7_3, i64 %p_7_4)
  %t32 = extractvalue { i64, i64 } %t31, 0
  %t33 = extractvalue { i64, i64 } %t31, 1
  %t34 = call { i64, i64 } @__hia_fn_2(%hia.buffer %p_7_0, i64 %p_7_1, i1 %p_7_2, i64 %t32, i64 %t33)
  %t35 = extractvalue { i64, i64 } %t34, 0
  %t36 = extractvalue { i64, i64 } %t34, 1
  %t37 = insertvalue { i64, i64, i64 } zeroinitializer, i64 2005, 0
  %t38 = insertvalue { i64, i64, i64 } %t37, i64 %t35, 1
  %t39 = insertvalue { i64, i64, i64 } %t38, i64 %t36, 2
  ret { i64, i64, i64 } %t39
b8:
  %p_8_0 = phi %hia.buffer [ %p_6_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_6_1, %edge_7 ]
  %p_8_2 = phi i1 [ %p_6_2, %edge_7 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_8_5 = phi i32 [ %p_6_5, %edge_7 ]
  %t40 = call { i64, i64 } @__hia_fn_2(%hia.buffer %p_8_0, i64 %p_8_1, i1 %p_8_2, i64 %p_8_3, i64 %p_8_4)
  %t41 = extractvalue { i64, i64 } %t40, 0
  %t42 = extractvalue { i64, i64 } %t40, 1
  %t43 = insertvalue { i64, i64, i64 } zeroinitializer, i64 0, 0
  %t44 = insertvalue { i64, i64, i64 } %t43, i64 %t41, 1
  %t45 = insertvalue { i64, i64, i64 } %t44, i64 %t42, 2
  ret { i64, i64, i64 } %t45
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
}

define internal i64 @__hia_fn_7(i64 %p_0_0, i64 %p_0_1, i32 %p_0_2, i32 %p_0_3) {
b0:
  %t1 = icmp eq i32 %p_0_2, 7
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_5 = phi i64 [ 0, %edge_0 ]
  %p_1_6 = phi i64 [ 0, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_5 = phi i64 [ 0, %edge_1 ]
  %p_2_6 = phi i64 [ 0, %edge_1 ]
  %t2 = call { %hia.buffer, i64, i1 } @__hia_fn_3(i64 %p_2_1)
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t2, 0
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t2, 1
  %t5 = extractvalue { %hia.buffer, i64, i1 } %t2, 2
  %t6 = icmp eq i32 %p_2_2, 6
  br i1 %t6, label %edge_3, label %edge_4
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i64 [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i32 [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i32 [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_3 ]
  %p_3_5 = phi i64 [ %p_2_5, %edge_3 ]
  %p_3_6 = phi i64 [ %p_2_6, %edge_3 ]
  %p_3_7 = phi %hia.buffer [ %t3, %edge_3 ]
  %p_3_8 = phi i64 [ %t4, %edge_3 ]
  %p_3_9 = phi i1 [ %t5, %edge_3 ]
  %t7 = call { i64, i64 } @__hia_fn_2(%hia.buffer %p_3_7, i64 %p_3_8, i1 %p_3_9, i64 %p_3_4, i64 %p_3_5)
  %t8 = extractvalue { i64, i64 } %t7, 0
  %t9 = extractvalue { i64, i64 } %t7, 1
  br label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_4 ]
  %p_4_1 = phi i64 [ %p_2_1, %edge_4 ]
  %p_4_2 = phi i32 [ %p_2_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_2_3, %edge_4 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_4 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_4 ]
  %p_4_6 = phi i64 [ %p_2_6, %edge_4 ]
  %p_4_7 = phi %hia.buffer [ %t3, %edge_4 ]
  %p_4_8 = phi i64 [ %t4, %edge_4 ]
  %p_4_9 = phi i1 [ %t5, %edge_4 ]
  %t10 = icmp eq i32 %p_4_2, 4
  br i1 %t10, label %edge_6, label %edge_7
b5:
  %p_5_0 = phi i64 [ %p_4_0, %edge_6 ]
  %p_5_1 = phi i64 [ %p_4_1, %edge_6 ]
  %p_5_2 = phi i32 [ %p_4_2, %edge_6 ]
  %p_5_3 = phi i32 [ %p_4_3, %edge_6 ]
  %p_5_4 = phi i64 [ %p_4_4, %edge_6 ]
  %p_5_5 = phi i64 [ %p_4_5, %edge_6 ]
  %p_5_6 = phi i64 [ %p_4_6, %edge_6 ]
  %p_5_7 = phi %hia.buffer [ %p_4_7, %edge_6 ]
  %p_5_8 = phi i64 [ %p_4_8, %edge_6 ]
  %p_5_9 = phi i1 [ %p_4_9, %edge_6 ]
  %t11 = call { i64, i64 } @__hia_fn_2(%hia.buffer %p_5_7, i64 %p_5_8, i1 %p_5_9, i64 %p_5_4, i64 %p_5_5)
  %t12 = extractvalue { i64, i64 } %t11, 0
  %t13 = extractvalue { i64, i64 } %t11, 1
  br label %edge_8
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_7 ]
  %p_6_1 = phi i64 [ %p_4_1, %edge_7 ]
  %p_6_2 = phi i32 [ %p_4_2, %edge_7 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_7 ]
  %p_6_4 = phi i64 [ %p_4_4, %edge_7 ]
  %p_6_5 = phi i64 [ %p_4_5, %edge_7 ]
  %p_6_6 = phi i64 [ %p_4_6, %edge_7 ]
  %p_6_7 = phi %hia.buffer [ %p_4_7, %edge_7 ]
  %p_6_8 = phi i64 [ %p_4_8, %edge_7 ]
  %p_6_9 = phi i1 [ %p_4_9, %edge_7 ]
  %t14 = call { %hia.buffer, i64, i1 } @__hia_fn_1(%hia.buffer %p_6_7, i64 %p_6_8, i1 %p_6_9)
  %t15 = extractvalue { %hia.buffer, i64, i1 } %t14, 0
  %t16 = extractvalue { %hia.buffer, i64, i1 } %t14, 1
  %t17 = extractvalue { %hia.buffer, i64, i1 } %t14, 2
  %t18 = call { i64, i64, i64 } @__hia_fn_6(%hia.buffer %t15, i64 %t16, i1 %t17, i64 %p_6_4, i64 %p_6_5, i32 %p_6_2)
  %t19 = extractvalue { i64, i64, i64 } %t18, 0
  %t20 = extractvalue { i64, i64, i64 } %t18, 1
  %t21 = extractvalue { i64, i64, i64 } %t18, 2
  br label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_8 ], [ %p_6_0, %edge_9 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_8 ], [ %p_6_1, %edge_9 ]
  %p_7_2 = phi i32 [ %p_5_2, %edge_8 ], [ %p_6_2, %edge_9 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_8 ], [ %p_6_3, %edge_9 ]
  %p_7_4 = phi i64 [ %t12, %edge_8 ], [ %t20, %edge_9 ]
  %p_7_5 = phi i64 [ %t13, %edge_8 ], [ %t21, %edge_9 ]
  %p_7_6 = phi i64 [ 1004, %edge_8 ], [ %t19, %edge_9 ]
  %p_7_7 = phi i64 [ %p_5_8, %edge_8 ], [ %p_6_8, %edge_9 ]
  %p_7_8 = phi i1 [ %p_5_9, %edge_8 ], [ %p_6_9, %edge_9 ]
  br label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_3_0, %edge_5 ], [ %p_7_0, %edge_10 ]
  %p_8_1 = phi i64 [ %p_3_1, %edge_5 ], [ %p_7_1, %edge_10 ]
  %p_8_2 = phi i32 [ %p_3_2, %edge_5 ], [ %p_7_2, %edge_10 ]
  %p_8_3 = phi i32 [ %p_3_3, %edge_5 ], [ %p_7_3, %edge_10 ]
  %p_8_4 = phi i64 [ %t8, %edge_5 ], [ %p_7_4, %edge_10 ]
  %p_8_5 = phi i64 [ %t9, %edge_5 ], [ %p_7_5, %edge_10 ]
  %p_8_6 = phi i64 [ 1006, %edge_5 ], [ %p_7_6, %edge_10 ]
  %p_8_7 = phi i64 [ %p_3_8, %edge_5 ], [ %p_7_7, %edge_10 ]
  %p_8_8 = phi i1 [ %p_3_9, %edge_5 ], [ %p_7_8, %edge_10 ]
  br label %edge_11
b9:
  %p_9_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_8_0, %edge_11 ]
  %p_9_1 = phi i64 [ %p_1_1, %edge_2 ], [ %p_8_1, %edge_11 ]
  %p_9_2 = phi i32 [ %p_1_2, %edge_2 ], [ %p_8_2, %edge_11 ]
  %p_9_3 = phi i32 [ %p_1_3, %edge_2 ], [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i64 [ %p_1_4, %edge_2 ], [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i64 [ %p_1_5, %edge_2 ], [ %p_8_5, %edge_11 ]
  %p_9_6 = phi i64 [ 1007, %edge_2 ], [ %p_8_6, %edge_11 ]
  %t22 = icmp eq i32 %p_9_3, 0
  br i1 %t22, label %edge_12, label %edge_13
b10:
  %p_10_0 = phi i64 [ %p_9_0, %edge_12 ]
  %p_10_1 = phi i64 [ %p_9_1, %edge_12 ]
  %p_10_2 = phi i32 [ %p_9_2, %edge_12 ]
  %p_10_3 = phi i32 [ %p_9_3, %edge_12 ]
  %p_10_4 = phi i64 [ %p_9_4, %edge_12 ]
  %p_10_5 = phi i64 [ %p_9_5, %edge_12 ]
  %p_10_6 = phi i64 [ %p_9_6, %edge_12 ]
  ret i64 %p_10_4
b11:
  %p_11_0 = phi i64 [ %p_9_0, %edge_13 ]
  %p_11_1 = phi i64 [ %p_9_1, %edge_13 ]
  %p_11_2 = phi i32 [ %p_9_2, %edge_13 ]
  %p_11_3 = phi i32 [ %p_9_3, %edge_13 ]
  %p_11_4 = phi i64 [ %p_9_4, %edge_13 ]
  %p_11_5 = phi i64 [ %p_9_5, %edge_13 ]
  %p_11_6 = phi i64 [ %p_9_6, %edge_13 ]
  %t23 = icmp eq i32 %p_11_3, 1
  br i1 %t23, label %edge_14, label %edge_15
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_14 ]
  %p_12_1 = phi i64 [ %p_11_1, %edge_14 ]
  %p_12_2 = phi i32 [ %p_11_2, %edge_14 ]
  %p_12_3 = phi i32 [ %p_11_3, %edge_14 ]
  %p_12_4 = phi i64 [ %p_11_4, %edge_14 ]
  %p_12_5 = phi i64 [ %p_11_5, %edge_14 ]
  %p_12_6 = phi i64 [ %p_11_6, %edge_14 ]
  ret i64 %p_12_5
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_15 ]
  %p_13_1 = phi i64 [ %p_11_1, %edge_15 ]
  %p_13_2 = phi i32 [ %p_11_2, %edge_15 ]
  %p_13_3 = phi i32 [ %p_11_3, %edge_15 ]
  %p_13_4 = phi i64 [ %p_11_4, %edge_15 ]
  %p_13_5 = phi i64 [ %p_11_5, %edge_15 ]
  %p_13_6 = phi i64 [ %p_11_6, %edge_15 ]
  ret i64 %p_13_6
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b9
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b8
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b7
edge_10:
  br label %b8
edge_11:
  br label %b9
edge_12:
  br label %b10
edge_13:
  br label %b11
edge_14:
  br label %b12
edge_15:
  br label %b13
}

define i64 @migrated_case(i64 %a0, i64 %a1, i32 %a2, i32 %a3) {
entry:
  %result = call i64 @__hia_fn_7(i64 %a0, i64 %a1, i32 %a2, i32 %a3)
  ret i64 %result
}
