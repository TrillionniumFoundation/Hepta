; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 0, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 0, 1
  %t6 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t5, 0
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i64 %p_0_0, 1
  %t8 = insertvalue { %hia.buffer, i64, i1 } %t7, i1 true, 2
  ret { %hia.buffer, i64, i1 } %t8
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_1(%hia.buffer %p_0_0, i64 %p_0_1, i1 %p_0_2) {
b0:
  %t1 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %p_0_0, 0
  %t2 = insertvalue { %hia.buffer, i64, i1 } %t1, i64 %p_0_1, 1
  %t3 = insertvalue { %hia.buffer, i64, i1 } %t2, i1 %p_0_2, 2
  ret { %hia.buffer, i64, i1 } %t3
}

define internal { i64, i64 } @__hia_fn_2(%hia.buffer %p_0_0, i64 %p_0_1, i1 %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  br i1 %p_0_2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %t1 = mul i64 %p_1_3, 31
  %t2 = add i64 %t1, %p_1_1
  %t3 = add i64 %p_1_4, 1
  br label %edge_2
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  br label %edge_3
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_0, %edge_2 ], [ %p_2_0, %edge_3 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ], [ %p_2_1, %edge_3 ]
  %p_3_2 = phi i1 [ %p_1_2, %edge_2 ], [ %p_2_2, %edge_3 ]
  %p_3_3 = phi i64 [ %t2, %edge_2 ], [ %p_2_3, %edge_3 ]
  %p_3_4 = phi i64 [ %t3, %edge_2 ], [ %p_2_4, %edge_3 ]
  %t4 = extractvalue %hia.buffer %p_3_0, 0
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %drop_nonnull_6, label %drop_after_6
drop_nonnull_6:
  call void @free(ptr %t4) nobuiltin
  br label %drop_after_6
drop_after_6:
  %t7 = insertvalue { i64, i64 } zeroinitializer, i64 %p_3_3, 0
  %t8 = insertvalue { i64, i64 } %t7, i64 %p_3_4, 1
  ret { i64, i64 } %t8
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b3
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_3(i64 %p_0_0) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t2, 0
  %t6 = insertvalue { %hia.buffer, i64, i1 } %t5, i64 %t3, 1
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i1 %t4, 2
  ret { %hia.buffer, i64, i1 } %t7
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_4(i64 %p_0_0) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t2, 0
  %t6 = insertvalue { %hia.buffer, i64, i1 } %t5, i64 %t3, 1
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i1 %t4, 2
  ret { %hia.buffer, i64, i1 } %t7
}

define internal { %hia.buffer, i64, i1 } @__hia_fn_5(i64 %p_0_0) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_0(i64 %p_0_0)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = insertvalue { %hia.buffer, i64, i1 } zeroinitializer, %hia.buffer %t2, 0
  %t6 = insertvalue { %hia.buffer, i64, i1 } %t5, i64 %t3, 1
  %t7 = insertvalue { %hia.buffer, i64, i1 } %t6, i1 %t4, 2
  ret { %hia.buffer, i64, i1 } %t7
}

define internal i64 @__hia_fn_6(i64 %p_0_0, i64 %p_0_1, i32 %p_0_2, i32 %p_0_3) {
b0:
  %t1 = call { %hia.buffer, i64, i1 } @__hia_fn_4(i64 %p_0_1)
  %t2 = extractvalue { %hia.buffer, i64, i1 } %t1, 0
  %t3 = extractvalue { %hia.buffer, i64, i1 } %t1, 1
  %t4 = extractvalue { %hia.buffer, i64, i1 } %t1, 2
  %t5 = call { i64, i64 } @__hia_fn_2(%hia.buffer %t2, i64 %t3, i1 %t4, i64 %p_0_0, i64 0)
  %t6 = extractvalue { i64, i64 } %t5, 0
  %t7 = extractvalue { i64, i64 } %t5, 1
  %t8 = icmp eq i32 %p_0_3, 0
  br i1 %t8, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %t6, %edge_0 ]
  %p_1_5 = phi i64 [ %t7, %edge_0 ]
  %p_1_6 = phi i64 [ %t3, %edge_0 ]
  %p_1_7 = phi i1 [ %t4, %edge_0 ]
  ret i64 %p_1_4
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %t6, %edge_1 ]
  %p_2_5 = phi i64 [ %t7, %edge_1 ]
  %p_2_6 = phi i64 [ %t3, %edge_1 ]
  %p_2_7 = phi i1 [ %t4, %edge_1 ]
  %t9 = icmp eq i32 %p_2_3, 1
  br i1 %t9, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_2_1, %edge_2 ]
  %p_3_2 = phi i32 [ %p_2_2, %edge_2 ]
  %p_3_3 = phi i32 [ %p_2_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_2_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_2_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_2_6, %edge_2 ]
  %p_3_7 = phi i1 [ %p_2_7, %edge_2 ]
  ret i64 %p_3_5
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_2_1, %edge_3 ]
  %p_4_2 = phi i32 [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i32 [ %p_2_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_2_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_2_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_2_6, %edge_3 ]
  %p_4_7 = phi i1 [ %p_2_7, %edge_3 ]
  ret i64 0
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define i64 @migrated_case(i64 %a0, i64 %a1, i32 %a2, i32 %a3) {
entry:
  %result = call i64 @__hia_fn_6(i64 %a0, i64 %a1, i32 %a2, i32 %a3)
  ret i64 %result
}
