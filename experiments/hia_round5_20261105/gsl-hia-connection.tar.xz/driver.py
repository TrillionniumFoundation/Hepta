"""One supplementary GSL 5.0.1 Core-to-LLVM connection on a frozen checkout."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import traceback


def digest(path):
    h = sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def cost():
    own = resource.getrusage(resource.RUSAGE_SELF)
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {'wall_ns': time.perf_counter_ns(),
            'self_cpu_ns': round((own.ru_utime + own.ru_stime) * 1e9),
            'child_cpu_ns': round((children.ru_utime + children.ru_stime) * 1e9)}


def difference(before):
    after = cost()
    return {key: after[key] - value for key, value in before.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--clang', required=True)
    parser.add_argument('--cc', required=True)
    parser.add_argument('--cxx', required=True)
    args = parser.parse_args()
    os.sched_setaffinity(0, {24, 25})
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    total_start = cost()
    root, output = args.root.resolve(), args.output.resolve()
    assert output.is_dir() and not output.is_relative_to(root)
    assert not (output / 'REGISTRATION.json').exists()
    sys.path.insert(0, str(root))
    stages, commands, native_commands = [], [], {}
    report = {'schema': 'hepta.gsl5-hia-connection.v1', 'ok': False,
              'source_commit': args.expected_head, 'source_tree': args.expected_tree,
              'pairs': {}, 'negative_controls': {}, 'stages': stages,
              'claims': {'whole_gsl_migrated': False, 'general_cpp_migration': False,
                         'general_exception_abi_translation': False,
                         'compiler_refinement_proved': False, 'full_semantic_equivalence_proved': False,
                         'maintenance_or_performance_advantage': False,
                         'original_qualification_replaced': False}}

    def stage(label, action):
        row = {'stage': label, 'started_unix_ns': time.time_ns()}
        before = cost()
        try:
            value = action()
            row['ok'] = True
            return value
        except Exception as error:
            row.update(ok=False, error={'type': type(error).__name__, 'message': str(error)})
            raise
        finally:
            row['cost'] = difference(before)
            stages.append(row)
            write(output / 'STAGES.json', stages)
            write(output / 'COMMANDS.json', commands)
            write(output / 'NATIVE_COMMANDS.json', native_commands)
            print(json.dumps(row), flush=True)

    plan = {'schema': 'hepta.gsl5-hia-connection-registration.v1',
            'registered_unix_ns': time.time_ns(), 'argv': [sys.executable, *sys.argv],
            'driver_sha256': digest(__file__), 'root': str(root),
            'expected_commit': args.expected_head, 'expected_tree': args.expected_tree,
            'cpu_affinity': sorted(os.sched_getaffinity(0)), 'exclusive_host': False,
            'scope': 'fresh capture of pinned GSL 5.0.1 final_action/finally; current source checker; current source-to-Core; actual Core-to-LLVM object; original scalar C harness and independent oracle',
            'version': '5.0.1', 'upstream_commit': 'fbd20b8e8c52cba04dbc869cc9068a7800a5665d',
            'pairs': ['migrated', 'factory_migrated', 'const_factory_migrated'],
            'case_count_per_pair': 416, 'expected_positive_observation_rows': 2496,
            'expected_positive_native_scalar_calls': 7488,
            'original_cases_sha256': 'e3026dd5a5ec479e689e2bd495776196b254d05ff58c075532d9fe36c96a712e',
            'lifecycle_modes': list(range(8)), 'scalar_fields': ['trace', 'callback_count', 'status'],
            'negative_controls': ['wrong_but_linear_multiplier_32', 'duplicate_owner', 'lost_owner'],
            'capture_api': 'capture_and_lower(root, "5.0.1", output/"5.0.1", clang=clang)',
            'source_precheck': 'analyze(source, backend="c", native=False, crate_type="obj"); C text is not compiled or linked',
            'native_api': 'build_program_native(core.as_dict(), object, clang=clang, kind="object", command_log=...)',
            'native_compile_argv_profile': ['clang', '--target=x86_64-unknown-linux-gnu', '-x', 'ir', '-O3', '-fPIC', '-c', '<verified program.ll>', '-o', '<new object>'],
            'migrated_link_argv_profile': [args.cc, '-std=c11', '-O2', '-DCASE_FUNCTION=migrated_case', str(root/'examples/cpp/gsl_final_action/harness.c'), '<HIA LLVM object>', '-o', '<new executable>'],
            'execution_argv_profile': ['<original or HIA executable>'],
            'execution_stdin': 'all original 416 seed/tag/mode rows in original order, one invocation per binary',
            'command_budget_seconds': 60, 'maximum_attempts_per_action': 1,
            'fallback_allowed': False, 'download_dependencies_allowed': False,
            'cost_policy': 'retain total wall/self CPU/child CPU and per-stage costs including checker, fresh AST capture, oracle, build, negative controls, and identity checks; costs are observations, not speedup claims',
            'human_engineering_seconds': None, 'human_engineering_status': 'not_measured',
            'agent_token_cost': None, 'cache_state': 'existing host toolchain/caches; no fully cold claim',
            'tools': {'python': {'invocation': sys.executable, 'sha256': digest(sys.executable)},
                      'clang': {'invocation': args.clang, 'sha256': digest(args.clang)},
                      'cc': {'invocation': args.cc, 'sha256': digest(args.cc)},
                      'cxx': {'invocation': args.cxx, 'sha256': digest(args.cxx)}}}
    with (output / 'REGISTRATION.json').open('x') as stream:
        json.dump(plan, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())

    source_before = None
    try:
        from tools import qualify_hia_composition as composition
        from tools import qualify_cpp_gsl_final_action as q
        from hepta.cpp_gsl_final_action import capture_and_lower
        from hepta.hia_program_source import lower_source
        from hepta.hia_program_llvm import build_program_native, emit_program_llvm
        from hepta.pipeline import analyze

        source_before = stage('initial_canonical_source_identity', composition.source_identity)
        write(output / 'SOURCE.json', source_before)
        assert (source_before['commit'], source_before['tree']) == (args.expected_head, args.expected_tree)
        assert plan['tools']['clang']['sha256'] == 'b15e7640bf3082f36ef14321711706b265df3058721e3c2caef3a4b83895d07d'
        assert plan['tools']['cc']['sha256'] == '1b99826121ae6682a634e5efe09bd3e3df58ce58e0b28f849114ab5b89139c26'
        assert plan['tools']['cxx']['sha256'] == '1353e9bdd29a7295c7226bf6c63abccce056d8cac31f112e5cdbecc3f28c2769'
        host = q.native_host_profile()
        targets = {}
        for name in ('clang', 'cc', 'cxx'):
            invocation = plan['tools'][name]['invocation']
            targets[name] = stage(name+'_target_probe', lambda: q.command(commands, [invocation, '-dumpmachine'])).stdout.strip()
            q.require(q.native_driver_matches_host(targets[name], host), 'native compiler target differs: '+name)
            stage(name+'_version_probe', lambda: q.command(commands, [invocation, '--version']))
        report['native_abi'] = {'host': host, 'compiler_targets': targets,
                                'entry_signature': 'u64(u64,u64,u32,u32)',
                                'scope': 'actual host scalar C calls; C++ class layout and general exception ABI not translated'}
        rows = q.cases()
        expected = [q.oracle(*row) for row in rows]
        assert len(rows) == 416
        cases_path = output / 'cases.json'
        cases_path.write_text(json.dumps([{'input': row, 'expected': answer} for row, answer in zip(rows, expected)], indent=2) + '\n')
        assert digest(cases_path) == plan['original_cases_sha256']
        directory = output / '5.0.1'; directory.mkdir()
        migration = stage('fresh_clang20_capture_and_source_lowering',
                          lambda: capture_and_lower(root, '5.0.1', directory, clang=args.clang))
        examples = root / 'examples/cpp/gsl_final_action'
        sources = {'migrated': migration['source'],
                   'factory_migrated': migration['component_source']+'\n'+(examples/'factory_client.hepta').read_text(),
                   'const_factory_migrated': migration['component_source']+'\n'+(examples/'factory_const_client.hepta').read_text()}

        def native(label, source):
            path = directory / (label+'.hepta'); path.write_text(source)
            checked = stage(label+'_source_checker', lambda: analyze(source, path=str(path), backend='c', native=False, crate_type='obj'))
            write(directory/(label+'.check.json'), checked.report)
            q.require(checked.report['ok'], 'original source checker rejected '+label+': '+json.dumps(checked.report['diagnostics']))
            core = stage(label+'_actual_source_to_core', lambda: lower_source(source, path=str(path)))
            write(directory/(label+'.core.json'), core.as_dict())
            ir = stage(label+'_verified_llvm_emission', lambda: emit_program_llvm(core))
            (directory/(label+'.ll')).write_text(ir.text)
            q.require('migrated_case' in ir.exports, 'expected scalar export absent')
            obj = directory/(label+'.hia.o')
            log = native_commands.setdefault(label, [])
            build = stage(label+'_core_llvm_native_build', lambda: build_program_native(core.as_dict(), obj, clang=args.clang, kind='object', command_log=log))
            write(directory/(label+'.build.json'), build)
            q.require(build['core_sha256']==ir.core_sha256 and build['llvm_ir_sha256']==ir.sha256,
                      'compiled Core or LLVM identity differs from retained evidence')
            q.require(build['claims']['c_codegen_used'] is False and build['claims']['fallback_used'] is False,
                      'migrated binary must come from actual verified Core LLVM')
            executable = directory/(label+'.hia')
            stage(label+'_harness_link', lambda: q.command(commands, [args.cc, '-std=c11', '-O2', '-DCASE_FUNCTION=migrated_case', examples/'harness.c', obj, '-o', executable]))
            return executable, build

        migrated = {label: native(label, source) for label, source in sources.items()}
        originals = {'migrated': stage('original_cpp_three_unit_build',
            lambda: q.build_original(root, '5.0.1', directory, commands, cxx=args.cxx, cc=args.cc))}
        for label, source_name, symbol in [('factory_migrated', 'factory_lvalue.cpp', 'original_factory_case'),
                                            ('const_factory_migrated', 'factory_const_lvalue.cpp', 'original_const_factory_case')]:
            obj = directory/(label+'.original.o')
            harness = directory/(label+'.harness.o')
            binary = directory/(label+'.original')
            flags = ['-std=c++20', '-O2', '-DHEPTA_FACTORY_LIBRARY']
            if label == 'const_factory_migrated': flags += ['-fno-lto']
            flags += ['-I'+str(directory), '-I'+str(examples), '-I'+str(root/'tests/fixtures/gsl_final_action/5.0.1/include')]
            stage(label+'_original_compile', lambda: q.command(commands, [args.cxx, *flags, '-c', examples/source_name, '-o', obj]))
            stage(label+'_original_harness', lambda: q.command(commands, [args.cc, '-std=c11', '-O2', '-DCASE_FUNCTION='+symbol, '-c', examples/'harness.c', '-o', harness]))
            stage(label+'_original_link', lambda: q.command(commands, [args.cxx, obj, directory/'callback.cpp.o', harness, '-o', binary]))
            originals[label] = binary

        for label in sources:
            before = stage(label+'_original_native_observation', lambda: q.observation(commands, originals[label], rows))
            after = stage(label+'_hia_native_observation', lambda: q.observation(commands, migrated[label][0], rows))
            answers = expected if label == 'migrated' else [q.oracle(seed, tag, 0) for seed, tag, _ in rows]
            write(directory/(label+'.observations.json'), {'inputs': rows, 'expected': answers, 'original': before, 'hia_llvm': after})
            q.require(before == answers, 'independent oracle rejected original '+label)
            q.require(after == answers, 'independent oracle rejected HIA LLVM '+label)
            report['pairs'][label] = {'passed': True, 'cases': len(rows), 'observation_rows': 2*len(rows),
                                     'native_scalar_calls': 6*len(rows), 'original_sha256': digest(originals[label]),
                                     'hia_binary_sha256': digest(migrated[label][0]), 'build': migrated[label][1],
                                     'linked_original_cpp_objects': [], 'source_precheck_c_output_compiled': False}

        source = sources['migrated']
        q.require(source.count('wrapping_mul(state.trace, 31)')==1, 'semantic negative anchor differs')
        wrong, wrong_build = native('wrong_but_linear', source.replace('wrapping_mul(state.trace, 31)', 'wrapping_mul(state.trace, 32)'))
        actual = stage('wrong_but_linear_native_observation', lambda: q.observation(commands, wrong, rows))
        mismatches = [i for i, (a, b) in enumerate(zip(actual, expected)) if a != b]
        write(directory/'wrong_but_linear.observations.json', {'inputs': rows, 'expected': expected, 'actual': actual, 'mismatch_indices': mismatches})
        q.require(bool(mismatches), 'independent oracle missed wrong-but-linear LLVM program')
        report['negative_controls']['wrong_but_linear'] = {'detected': True, 'mismatch_count': len(mismatches), 'case_count': len(rows), 'build': wrong_build}
        anchor = 'GslDestroy(move owner, mut state); return 2001;'
        q.require(source.count(anchor)==1, 'owner negative anchor differs')
        for label, replacement in [('duplicate_owner', 'GslDestroy(move owner, mut state); '+anchor), ('lost_owner', 'return 2001;')]:
            changed = source.replace(anchor, replacement)
            (directory/(label+'.hepta')).write_text(changed)
            checked = stage(label+'_checker_rejection', lambda: analyze(changed, backend='c', native=False))
            write(directory/(label+'.check.json'), checked.report)
            q.require(not checked.report['ok'], 'resource checker accepted '+label)
            report['negative_controls'][label] = {'rejected': True, 'diagnostics': checked.report['diagnostics'], 'native_execution_attempted': False}

        report['execution_denominator'] = {'positive_pairs': 3, 'cases_per_pair': 416,
                                          'positive_observation_rows': 2496, 'positive_native_scalar_calls': 7488,
                                          'wrong_but_linear_observation_rows': 416, 'wrong_but_linear_native_scalar_calls': 1248}
        report['ok'] = True
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
        print(report['error']['traceback'], file=sys.stderr, flush=True)
    finally:
        try:
            if source_before is not None:
                source_after = stage('final_canonical_source_identity', composition.source_identity)
                write(output/'SOURCE_AFTER.json', source_after)
                report['source_identity_unchanged'] = source_after == source_before
                if not report['source_identity_unchanged']: report['ok'] = False
            else:
                report['source_identity_unchanged'] = None
            tool_after = {name: digest(item['invocation']) for name, item in plan['tools'].items()}
            report['tool_identity_unchanged'] = all(tool_after[name]==item['sha256'] for name, item in plan['tools'].items())
            if not report['tool_identity_unchanged']: report['ok'] = False
        except Exception as error:
            report['ok'] = False
            report['final_identity_error'] = {'type': type(error).__name__, 'message': str(error)}
        report['cost'] = difference(total_start)
        report['cost_boundary'] = 'driver start through final source/tool identity checks; excludes this final report and artifact-manifest serialization, prior agent preparation, and human engineering time'
        report['qualification_registration_sha256'] = digest(output/'REGISTRATION.json')
        write(output/'COMMANDS.json', commands)
        write(output/'NATIVE_COMMANDS.json', native_commands)
        write(output/'RESULT.json', report)
        files = [p for p in output.rglob('*') if p.is_file() and p.name != 'ARTIFACTS.json']
        write(output/'ARTIFACTS.json', {str(p.relative_to(output)): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(files)})
        print(json.dumps({'ok': report['ok'], 'error': report.get('error'), 'cost': report['cost'],
                          'source_identity_unchanged': report.get('source_identity_unchanged'),
                          'result': str(output/'RESULT.json')}), flush=True)
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
