"""Publish completed composition evidence without private upstream code or caches."""
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath
from hashlib import sha256, sha1
import datetime
import io
import json
import os
import re
import stat
import subprocess
import tarfile
import time

os.sched_setaffinity(0, {10, 11})
BASE = Path('/data/hepta-hia-round5-a3b4-20261105')
FROZEN = BASE/'evidence/frozen-0a06ef4f0894-r1'
OUTPUT = BASE/'evidence/publish-composition-r1'
REPO = BASE/'work-integration'
HEAD = '0a06ef4f0894681af92b0caefba0704c1278d2cc'
TREE = 'a5239982f9fd8f08ab3a6e791147fc989e8d9df6'
GIT_ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
SHADOW_PUBLIC = {'release/hia-core-shadow', 'release/hia-core-shadow.d',
                 'release/libhia_core_shadow.rlib', 'release/libhia_core_shadow.d'}
SECRET_PATTERNS = [
    re.compile(rb'gh[pousr]_[A-Za-z0-9]{30,}'),
    re.compile(rb'github_pat_[A-Za-z0-9_]{40,}'),
    re.compile(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----'),
    re.compile(rb'https?://[^\s"<>]+[?&](?:X-Amz-Signature|X-Goog-Signature|sig|access_token|token)=[^\s"<>]+', re.I),
    re.compile(rb'https?://[^\s"<>/@:]+:[^\s"<>/@]+@[^\s"<>]+', re.I),
]


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=REPO, env=GIT_ENV)


def git_identity():
    result = git('show', '-s', '--no-show-signature', '--format=%H%n%T', 'HEAD').decode().splitlines()
    assert result == [HEAD, TREE]
    assert not git('status', '--porcelain', '--untracked-files=all').strip()
    return {'commit': HEAD, 'tree': TREE, 'clean': True}


def raw(path):
    assert not path.is_symlink(), str(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        assert stat.S_ISREG(before.st_mode), str(path)
        value = stream.read()
        after = os.fstat(stream.fileno())
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    assert len(value) == before.st_size
    return value, before


def byte_identity(value):
    return {'bytes': len(value), 'sha256': sha256(value).hexdigest(),
            'git_blob_sha1': sha1(b'blob '+str(len(value)).encode()+b'\0'+value).hexdigest()}


def identity(path):
    return byte_identity(raw(path)[0])


def exclusion_reason(name):
    p = PurePosixPath(name)
    parts = p.parts
    if parts[0] == 'proof':
        return 'already_published_in_separate_complete_proof_archive'
    if any(part in {'cargo-target', 'raw-cargo-target'} for part in parts):
        return 'private_ndu_cargo_cache_and_compiled_artifacts'
    if name.startswith('composition/rust-shadow-target/'):
        tail = name.removeprefix('composition/rust-shadow-target/')
        if tail not in SHADOW_PUBLIC:
            return 'public_rust_shadow_dependency_cache_and_intermediates_final_crate_artifacts_retained'
    if name.startswith('composition/raw-ndu-build/'):
        tail = name.removeprefix('composition/raw-ndu-build/')
        if tail not in {'build-receipt.json', 'command-evidence/cargo.json',
                        'command-evidence/cargo.stdout', 'command-evidence/cargo.stderr'}:
            return 'private_ndu_copied_upstream_or_adapter_workspace_only_build_receipts_logs_retained'
    if name.startswith('composition/ndu-build/'):
        tail = name.removeprefix('composition/ndu-build/')
        if (tail not in {'builder.stdout', 'builder.stderr', 'BUILD_ENVELOPE.json',
                         'build/identity.json', 'build/build-commands.json'}
                and not tail.startswith('build/commands/')):
            return 'private_ndu_compiled_artifact_only_build_receipts_logs_identity_retained'
    if any(part in {'toolchains', 'model-weights', 'models', 'weights', '.git'} for part in parts):
        return 'toolchain_model_weights_or_repository_internal'
    if p.suffix.lower() in {'.safetensors', '.gguf', '.ckpt', '.pt', '.pth', '.onnx'}:
        return 'model_weights'
    if p.name in {'.env', '.netrc', '.git-credentials', 'credentials', 'credentials.json',
                  'id_rsa', 'id_ed25519', 'id_ecdsa'}:
        return 'credential_file'
    if p.name == 'core' or re.fullmatch(r'core\.\d+', p.name):
        return 'core_dump'
    return None


assert not OUTPUT.exists(), 'fresh composition publication directory required'
OUTPUT.mkdir()
start = time.monotonic()
activity = {'schema': 'hepta.completed-composition-archive-activity.v1', 'status': 'running',
            'started_utc': utc(), 'started_unix_ns': time.time_ns(),
            'inventory_started_unix_ns': 1793926016436895200,
            'cpu_affinity': sorted(os.sched_getaffinity(0)), 'exclusive_host': False,
            'source_changed': False, 'native_or_ci_tests_executed': 0,
            'compression': 'tar.xz preset=1', 'archive_attempt': 1}
write(OUTPUT/'ACTIVITY.json', activity)
print(json.dumps({'activity_started': activity}), flush=True)
try:
    source_before = git_identity()
    global_result = json.loads((FROZEN/'RESULT.json').read_text())
    assert global_result['passed'] and global_result['source_and_tools_unchanged']
    assert global_result['source_commit'] == HEAD and global_result['source_tree'] == TREE
    assert [row['name'] for row in global_result['commands']] == ['proof', 'independent-replay', 'composition']
    for row in global_result['commands']:
        assert row['returncode'] == 0 and row['source_and_tools_unchanged']
        outer = FROZEN/(row['name']+'-outer')
        assert json.loads((outer/'RESULT.json').read_text()) == row
        for stream in ('stdout', 'stderr'):
            observed = identity(outer/stream)
            assert (observed['bytes'], observed['sha256']) == (row[stream]['bytes'], row[stream]['sha256'])
    composition = json.loads((FROZEN/'composition/RESULT.json').read_text())
    assert composition['status'] == 'completed' and composition['qualification_commands_passed']
    assert composition['source_and_tools_unchanged'] and len(composition['commands']) == 36
    assert composition['source']['commit'] == HEAD and composition['source']['tree'] == TREE
    command_names = []
    for row in composition['commands']:
        name = row['name']; command_names.append(name)
        assert row['returncode'] == 0 and not row.get('timed_out') and row.get('launch_error') is None
        recorded = json.loads((FROZEN/'composition/commands'/(name+'.command.json')).read_text())
        assert recorded == row, 'ledger differs: '+name
        for logfile, expected in row['logs'].items():
            observed = identity(FROZEN/'composition/commands'/logfile)
            assert (observed['bytes'], observed['sha256']) == (expected['bytes'], expected['sha256'])

    names = subprocess.check_output(['rg', '--files', '--hidden', '--no-ignore', str(FROZEN)], text=True).splitlines()
    all_paths = sorted(Path(name) for name in names)
    retained, excluded, groups = {}, {}, defaultdict(lambda: {'files': 0, 'bytes': 0})
    for path in all_paths:
        name = path.relative_to(FROZEN).as_posix()
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        reason = exclusion_reason(name)
        value, metadata = raw(path)
        observed = byte_identity(value)
        if reason is None:
            if value.startswith(b'\x7fELF') and len(value) > 18:
                byteorder = 'little' if value[5] == 1 else 'big'
                if int.from_bytes(value[16:18], byteorder) == 4: reason = 'elf_core_dump'
            if any(pattern.search(value) for pattern in SECRET_PATTERNS):
                reason = 'credential_or_temporary_signed_url_pattern'
        if reason:
            excluded[name] = {**observed, 'reason': reason}
        else:
            retained[name] = observed
            group = '/'.join(PurePosixPath(name).parts[:2])
            groups[group]['files'] += 1; groups[group]['bytes'] += len(value)
    assert len(retained)+len(excluded) == len(all_paths)
    # A sensitive required receipt blocks publication instead of becoming an
    # unmentioned omission; original evidence is never edited or redacted here.
    mandatory = {'RESULT.json', 'SOURCE.json', 'TOOLS.json', 'REGISTRATION.json',
                 'composition/PLAN.json', 'composition/COMBINATION.json',
                 'composition/RESULT.json', 'composition/CORE.json',
                 'composition/ndu-build/build/identity.json',
                 'composition/ndu-build/build/build-commands.json',
                 'composition/raw-ndu-build/build-receipt.json'}
    for stage in ('proof', 'independent-replay', 'composition'):
        mandatory.update(stage+'-outer/'+name for name in ('LAUNCH.json', 'RESULT.json', 'stdout', 'stderr'))
    for name in command_names:
        mandatory.update('composition/commands/'+name+suffix for suffix in ('.command.json', '.stdout', '.stderr'))
    exclusion_counts = dict(Counter(row['reason'] for row in excluded.values()))
    exclusion_manifest = {'schema': 'hepta.evidence-publication-exclusions.v1',
                          'source_root': str(FROZEN), 'source_commit': HEAD, 'source_tree': TREE,
                          'original_file_count': len(all_paths), 'excluded_file_count': len(excluded),
                          'excluded_bytes': sum(row['bytes'] for row in excluded.values()),
                          'reason_counts': exclusion_counts,
                          'proof_separate_archive_sha256': 'd1159abe79e73526be415c5472b33ab4cff41cbeac83081c635d41a6c40587cc',
                          'files': excluded}
    write(OUTPUT/'EXCLUSIONS.json', exclusion_manifest)
    assert mandatory <= set(retained), 'required receipt omitted: '+str(sorted(mandatory-set(retained)))
    assert not any(row['reason'] in {'credential_or_temporary_signed_url_pattern', 'credential_file'} for row in excluded.values()), 'sensitive material observed; inspect excluded manifest before publication'
    assert all('composition/rust-shadow-target/'+name in retained for name in SHADOW_PUBLIC)
    policy = {'schema': 'hepta.evidence-publication-retention.v1',
              'retained_file_count': len(retained), 'retained_bytes': sum(row['bytes'] for row in retained.values()),
              'retained_by_group': dict(sorted(groups.items())), 'command_ledger_count': 36,
              'command_ledger_and_original_stream_files': 108,
              'global_outer_stages': ['proof', 'independent-replay', 'composition'],
              'public_rust_shadow_final_files': sorted(SHADOW_PUBLIC),
              'ndu_actual_model_requests_responses_costs_retained': True,
              'private_ndu_source_and_native_binaries_included': False,
              'public_aot_timings_resources_sources_native_artifacts_retained': True,
              'core_dumps_credentials_temporary_signed_urls_included': False,
              'existing_proof_payload_repeated': False,
              'scope': 'all completed frozen evidence retained except explicitly enumerated exclusions; no native execution or CI retry'}
    write(OUTPUT/'RETENTION.json', policy)
    own_source = Path(__file__).read_bytes()
    (OUTPUT/'ARCHIVE_DRIVER.py').write_bytes(own_source)
    sidecars = {name: identity(OUTPUT/name) for name in ('EXCLUSIONS.json', 'RETENTION.json', 'ARCHIVE_DRIVER.py')}
    manifest = {'schema': 'hepta.raw-archive-manifest.v1', 'source_root': str(FROZEN),
                'source_commit': HEAD, 'source_tree': TREE, 'file_count': len(retained),
                'file_bytes': sum(row['bytes'] for row in retained.values()),
                'manifest_self_excluded': True, 'files': retained, 'sidecars': sidecars}
    write(OUTPUT/'RAW_MANIFEST.json', manifest)
    print(json.dumps({'selected_files': len(retained), 'selected_bytes': manifest['file_bytes'],
                      'excluded_files': len(excluded), 'exclusion_counts': exclusion_counts,
                      'compression_started_utc': utc()}), flush=True)
    archive = OUTPUT/'composition.tar.xz'
    entries = [(FROZEN/name, name) for name in retained]
    entries += [(OUTPUT/name, name) for name in [*sidecars, 'RAW_MANIFEST.json']]
    compression_start = utc()
    with tarfile.open(archive, 'w:xz', preset=1, format=tarfile.PAX_FORMAT) as tar:
        for path, name in entries:
            value, metadata = raw(path)
            if name in retained: assert byte_identity(value) == retained[name], name
            if name in sidecars: assert byte_identity(value) == sidecars[name], name
            member = tarfile.TarInfo(name); member.size = len(value)
            member.mode = stat.S_IMODE(metadata.st_mode); member.mtime = int(metadata.st_mtime)
            member.uid = 0; member.gid = 0; member.uname = ''; member.gname = ''
            tar.addfile(member, io.BytesIO(value))
    compression_end = utc()
    print(json.dumps({'compression_finished_utc': compression_end, 'bytes': archive.stat().st_size}), flush=True)
    restored = OUTPUT/'restore'; restored.mkdir()
    with tarfile.open(archive, 'r:xz') as tar:
        members = tar.getmembers()
        assert len(members) == len({m.name for m in members}) == len(entries)
        assert {m.name for m in members} == {name for _, name in entries}
        for member in members:
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts
            destination = restored/name; destination.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as source, destination.open('xb') as target:
                for block in iter(lambda: source.read(1048576), b''): target.write(block)
            os.chmod(destination, member.mode)
    for name, expected in retained.items():
        assert identity(restored/name) == expected, 'restored: '+name
        assert identity(FROZEN/name) == expected, 'source changed: '+name
    for name in [*sidecars, 'RAW_MANIFEST.json']:
        assert (restored/name).read_bytes() == (OUTPUT/name).read_bytes()
    assert git_identity() == source_before
    receipt = {'schema': 'hepta.completed-composition-publication.v1', 'ok': True,
               'source': source_before, 'archive': {'path': str(archive), **identity(archive)},
               'raw_manifest': {'path': str(OUTPUT/'RAW_MANIFEST.json'), **identity(OUTPUT/'RAW_MANIFEST.json')},
               'exclusions': {'path': str(OUTPUT/'EXCLUSIONS.json'), **identity(OUTPUT/'EXCLUSIONS.json'),
                              'files': len(excluded), 'bytes': exclusion_manifest['excluded_bytes'], 'reasons': exclusion_counts},
               'retention': {'path': str(OUTPUT/'RETENTION.json'), **identity(OUTPUT/'RETENTION.json')},
               'retained_source_files': len(retained), 'retained_source_bytes': manifest['file_bytes'],
               'archive_members': len(entries), 'restore_directory': str(restored),
               'fresh_restore_verified_source_files': len(retained), 'fresh_restore_verified_sidecars': 4,
               'original_source_files_still_identical': True, 'frozen_repository_clean': True,
               'qualification_command_ledgers': 36, 'qualification_command_streams': 72,
               'all_three_outer_stages_retained': True, 'global_final_result_retained': True,
               'sequence_elapsed_ns': global_result['elapsed_ns'],
               'composition_elapsed_ns': global_result['commands'][2]['elapsed_ns'],
               'private_upstream_source_or_compiled_ndu_artifacts_included': False,
               'native_tests_or_ci_retries': 0,
               'compression_started_utc': compression_start, 'compression_finished_utc': compression_end}
    write(OUTPUT/'PUBLICATION_RECEIPT.json', receipt)
    print(json.dumps(receipt), flush=True)
    activity['status'] = 'passed'
except Exception as error:
    activity['status'] = 'failed'
    activity['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    activity.update(finished_utc=utc(), finished_unix_ns=time.time_ns(), wall_seconds=time.monotonic()-start)
    write(OUTPUT/'ACTIVITY.json', activity)
    print(json.dumps({'activity_finished': activity}), flush=True)
