
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#ifndef GET
#define GET original_get
#define PUT original_put
#endif
extern uint32_t GET(uint32_t);
extern uint64_t PUT(uint32_t);
int main(void) {
    uint32_t input;
    unsigned count = 0;
    while (scanf("%" SCNu32, &input) == 1) {
        printf("%" PRIu32 " %" PRIu64 "\n", GET(input), PUT(input));
        ++count;
    }
    return count ? 0 : 2;
}
