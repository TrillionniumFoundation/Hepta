
#include <stdint.h>
extern unsigned int sqlite3Get4byte(const unsigned char *);
extern void sqlite3Put4byte(unsigned char *, unsigned int);
uint32_t original_get(uint32_t packed) {
    unsigned char p[6] = {165, packed >> 24, packed >> 16, packed >> 8, packed, 90};
    return sqlite3Get4byte(p + 1);
}
uint64_t original_put(uint32_t value) {
    unsigned char p[8] = {17, 0, 0, 0, 0, 165, 90, 31};
    sqlite3Put4byte(p + 1, value);
    if (p[0] != 17 || p[7] != 31) return UINT64_MAX;
    return ((uint64_t)p[1] << 40) | ((uint64_t)p[2] << 32)
        | ((uint64_t)p[3] << 24) | ((uint64_t)p[4] << 16)
        | ((uint64_t)p[5] << 8) | p[6];
}
