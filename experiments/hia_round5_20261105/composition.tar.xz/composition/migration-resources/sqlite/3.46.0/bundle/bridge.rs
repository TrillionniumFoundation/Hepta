// Generated caller-unsafe C ABI bridge. NOT a proof of foreign pointer validity.

// SAFETY: nonempty buffers must be initialized, aligned, live within one allocation,

// stable throughout the call; a mutable slice additionally requires exclusive access.

// These are caller-supplied contracts and may narrow the original C input domain.

#[export_name = "sqlite3Get4byte"]
pub unsafe extern "C" fn __hepta_c_export_0(b_p: *const u8) -> u32 {
    let n_b_p = 4 as usize;
    if n_b_p > (isize::MAX as usize) / core::mem::size_of::<u8>() { std::process::abort(); }
    if n_b_p != 0 && (b_p.is_null() || (b_p as usize) % core::mem::align_of::<u8>() != 0) { std::process::abort(); }
    let s_b_p = if n_b_p == 0 { &[] } else { unsafe { core::slice::from_raw_parts(b_p, n_b_p) } };
    h_c_sqlite3Get4byte(s_b_p)
}

#[export_name = "sqlite3Put4byte"]
pub unsafe extern "C" fn __hepta_c_export_1(b_p: *mut u8, b_v: u32) -> () {
    let n_b_p = 4 as usize;
    if n_b_p > (isize::MAX as usize) / core::mem::size_of::<u8>() { std::process::abort(); }
    if n_b_p != 0 && (b_p.is_null() || (b_p as usize) % core::mem::align_of::<u8>() != 0) { std::process::abort(); }
    let s_b_p = if n_b_p == 0 { &mut [] } else { unsafe { core::slice::from_raw_parts_mut(b_p, n_b_p) } };
    h_c_sqlite3Put4byte(s_b_p, b_v)
}
