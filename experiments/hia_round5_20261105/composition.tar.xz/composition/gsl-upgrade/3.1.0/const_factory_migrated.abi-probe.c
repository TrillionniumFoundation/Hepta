#include <stdint.h>
#include <limits.h>
#include "/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/gsl-upgrade/3.1.0/const_factory_migrated.c"
typedef uint64_t (*hepta_expected_gsl_entry)(uint64_t, uint64_t, uint32_t, uint32_t);
_Static_assert(CHAR_BIT == 8 && sizeof(uint64_t) == 8 && sizeof(uint32_t) == 4, "Hepta GSL scalar widths");
_Static_assert(_Generic(&migrated_case, hepta_expected_gsl_entry: 1, default: 0), "Hepta GSL export signature mismatch");
