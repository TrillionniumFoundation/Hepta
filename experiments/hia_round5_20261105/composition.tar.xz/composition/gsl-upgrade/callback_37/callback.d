capture: \
  /data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/gsl-upgrade/callback_37_source/callback.cpp \
  /data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/gsl-upgrade/callback_37_source/callback.hpp
