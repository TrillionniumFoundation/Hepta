; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8>, <16 x i8>)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %entry_0, i32 %entry_1) {
entry:
  %empty = icmp eq i64 %entry_0, 0
  br i1 %empty, label %zero, label %guard, !prof !0
zero:
  %zero_result = call i64 @__hia_fn_1(i64 0, i32 %entry_1) alwaysinline
  ret i64 %zero_result
guard:
  %eligible = icmp ule i64 %entry_0, 72340172838076673
  br i1 %eligible, label %fast, label %fallback
fast:
  %fast_result = tail call i64 @__hia_fn_1(i64 %entry_0, i32 %entry_1) noinline
  ret i64 %fast_result
fallback:
  %slow_result = tail call i64 @__hia_fn_2(i64 %entry_0, i32 %entry_1) noinline
  ret i64 %slow_result
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  call void @free(ptr %t6) nobuiltin
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t26, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i64 %p_4_4 to i32
  %t17 = add i32 %t16, %p_4_1
  %t18 = trunc i64 %p_4_4 to i8
  %t19 = trunc i32 %p_4_1 to i8
  %t20 = add i8 %t18, %t19
  %t21 = extractvalue %hia.buffer %p_4_2, 0
  %t22 = extractvalue %hia.buffer %p_4_2, 1
  %t23 = icmp ult i64 %p_4_4, %t22
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  %t25 = getelementptr i8, ptr %t21, i64 %p_4_4
  store i8 %t20, ptr %t25, align 1
  %t26 = add i64 %p_4_4, 1
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t34, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t33, %edge_9 ]
  %t27 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t27, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t28 = extractvalue %hia.buffer %p_7_2, 0
  %t29 = extractvalue %hia.buffer %p_7_2, 1
  br label %byte_sum_start_30
byte_sum_start_30:
  br label %byte_sum_vector_head_30
byte_sum_vector_head_30:
  %t31 = phi i64 [ %p_7_5, %byte_sum_start_30 ], [ %t42, %byte_sum_vector_body_30 ]
  %t32 = phi i64 [ %p_7_3, %byte_sum_start_30 ], [ %t41, %byte_sum_vector_body_30 ]
  %t60 = icmp ule i64 %t31, %p_7_4
  %t61 = sub i64 %p_7_4, %t31
  %t62 = icmp uge i64 %t61, 16
  %t63 = and i1 %t60, %t62
  %t64 = icmp ule i64 %t31, %t29
  %t65 = sub i64 %t29, %t31
  %t66 = icmp uge i64 %t65, 16
  %t67 = and i1 %t64, %t66
  %t68 = and i1 %t63, %t67
  br i1 %t68, label %byte_sum_vector_body_30, label %byte_sum_half_head_30
byte_sum_vector_body_30:
  %t35 = getelementptr i8, ptr %t28, i64 %t31
  %t36 = load <16 x i8>, ptr %t35, align 1
  %t37 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t36, <16 x i8> zeroinitializer)
  %t38 = extractelement <2 x i64> %t37, i32 0
  %t39 = extractelement <2 x i64> %t37, i32 1
  %t40 = add i64 %t38, %t39
  %t41 = add i64 %t32, %t40
  %t42 = add i64 %t31, 16
  br label %byte_sum_vector_head_30
byte_sum_half_head_30:
  %t69 = icmp ule i64 %t31, %p_7_4
  %t70 = sub i64 %p_7_4, %t31
  %t71 = icmp uge i64 %t70, 8
  %t72 = and i1 %t69, %t71
  %t73 = icmp ule i64 %t31, %t29
  %t74 = sub i64 %t29, %t31
  %t75 = icmp uge i64 %t74, 8
  %t76 = and i1 %t73, %t75
  %t77 = and i1 %t72, %t76
  br i1 %t77, label %byte_sum_half_body_30, label %byte_sum_scalar_head_30
byte_sum_half_body_30:
  %t43 = getelementptr i8, ptr %t28, i64 %t31
  %t44 = load i64, ptr %t43, align 1
  %t45 = insertelement <2 x i64> zeroinitializer, i64 %t44, i32 0
  %t46 = bitcast <2 x i64> %t45 to <16 x i8>
  %t47 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t46, <16 x i8> zeroinitializer)
  %t48 = extractelement <2 x i64> %t47, i32 0
  %t49 = add i64 %t32, %t48
  %t50 = add i64 %t31, 8
  br label %byte_sum_scalar_head_30
byte_sum_scalar_head_30:
  %t33 = phi i64 [ %t31, %byte_sum_half_head_30 ], [ %t50, %byte_sum_half_body_30 ], [ %t59, %byte_sum_scalar_done_30 ]
  %t34 = phi i64 [ %t32, %byte_sum_half_head_30 ], [ %t49, %byte_sum_half_body_30 ], [ %t58, %byte_sum_scalar_done_30 ]
  %t78 = icmp ult i64 %t33, %p_7_4
  br i1 %t78, label %byte_sum_scalar_body_30, label %byte_sum_finished_30
byte_sum_scalar_body_30:
  %t51 = extractvalue %hia.buffer %p_7_2, 0
  %t52 = extractvalue %hia.buffer %p_7_2, 1
  %t53 = icmp ult i64 %t33, %t52
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  %t55 = getelementptr i8, ptr %t51, i64 %t33
  %t56 = load i8, ptr %t55, align 1
  %t57 = zext i8 %t56 to i64
  %t58 = add i64 %t34, %t57
  %t59 = add i64 %t33, 1
  br label %byte_sum_scalar_done_30
byte_sum_scalar_done_30:
  br label %byte_sum_scalar_head_30
byte_sum_finished_30:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t79 = extractvalue %hia.buffer %p_8_2, 0
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %drop_nonnull_81, label %drop_after_81
drop_nonnull_81:
  call void @free(ptr %t79) nobuiltin
  br label %drop_after_81
drop_after_81:
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  call void @free(ptr %t6) nobuiltin
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t27, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i64 %p_4_4 to i32
  %t17 = add i32 %t16, %p_4_1
  %t18 = trunc i64 %p_4_4 to i8
  %t19 = trunc i32 %p_4_1 to i8
  %t20 = add i8 %t18, %t19
  %t21 = extractvalue %hia.buffer %p_4_2, 0
  %t22 = extractvalue %hia.buffer %p_4_2, 1
  %t23 = icmp ult i64 %p_4_4, %t22
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  %t25 = getelementptr i8, ptr %t21, i64 %p_4_4
  store i8 %t20, ptr %t25, align 1
  %t26 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  %t29 = xor i1 %t28, true
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t40, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t45, %edge_9 ]
  %t31 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t31, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t32 = extractvalue %hia.buffer %p_7_2, 0
  %t33 = extractvalue %hia.buffer %p_7_2, 1
  %t34 = icmp ult i64 %p_7_5, %t33
  br i1 %t34, label %ok_35, label %trap_35
trap_35:
  call void @abort()
  unreachable
ok_35:
  %t36 = getelementptr i8, ptr %t32, i64 %p_7_5
  %t37 = load i8, ptr %t36, align 1
  %t38 = zext i8 %t37 to i64
  %t39 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_3, i64 %t38)
  %t40 = extractvalue { i64, i1 } %t39, 0
  %t41 = extractvalue { i64, i1 } %t39, 1
  %t42 = xor i1 %t41, true
  br i1 %t42, label %ok_43, label %trap_43
trap_43:
  call void @abort()
  unreachable
ok_43:
  %t44 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_5, i64 1)
  %t45 = extractvalue { i64, i1 } %t44, 0
  %t46 = extractvalue { i64, i1 } %t44, 1
  %t47 = xor i1 %t46, true
  br i1 %t47, label %ok_48, label %trap_48
trap_48:
  call void @abort()
  unreachable
ok_48:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t49 = extractvalue %hia.buffer %p_8_2, 0
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %drop_nonnull_51, label %drop_after_51
drop_nonnull_51:
  call void @free(ptr %t49) nobuiltin
  br label %drop_after_51
drop_after_51:
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
!0 = !{!"branch_weights", i32 2, i32 1}
