; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8>, <16 x i8>)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %entry_0, i32 %entry_1) {
entry:
  %empty = icmp eq i64 %entry_0, 0
  br i1 %empty, label %zero, label %guard, !prof !0
zero:
  %zero_result = call i64 @__hia_fn_1(i64 0, i32 %entry_1) alwaysinline
  ret i64 %zero_result
guard:
  %eligible = icmp ule i64 %entry_0, 72340172838076673
  br i1 %eligible, label %fast, label %fallback
fast:
  %fast_result = tail call i64 @__hia_fn_1(i64 %entry_0, i32 %entry_1) noinline
  ret i64 %fast_result
fallback:
  %slow_result = tail call i64 @__hia_fn_2(i64 %entry_0, i32 %entry_1) noinline
  ret i64 %slow_result
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  call void @free(ptr %t6) nobuiltin
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t28, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i64 %p_4_4 to i32
  %t17 = mul i32 %t16, %p_4_1
  %t18 = add i32 %t17, 17
  %t19 = trunc i64 %p_4_4 to i8
  %t20 = trunc i32 %p_4_1 to i8
  %t21 = mul i8 %t19, %t20
  %t22 = add i8 %t21, 17
  %t23 = extractvalue %hia.buffer %p_4_2, 0
  %t24 = extractvalue %hia.buffer %p_4_2, 1
  %t25 = icmp ult i64 %p_4_4, %t24
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = getelementptr i8, ptr %t23, i64 %p_4_4
  store i8 %t22, ptr %t27, align 1
  %t28 = add i64 %p_4_4, 1
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t36, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t35, %edge_9 ]
  %t29 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t29, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t30 = extractvalue %hia.buffer %p_7_2, 0
  %t31 = extractvalue %hia.buffer %p_7_2, 1
  br label %byte_sum_start_32
byte_sum_start_32:
  br label %byte_sum_vector_head_32
byte_sum_vector_head_32:
  %t33 = phi i64 [ %p_7_5, %byte_sum_start_32 ], [ %t44, %byte_sum_vector_body_32 ]
  %t34 = phi i64 [ %p_7_3, %byte_sum_start_32 ], [ %t43, %byte_sum_vector_body_32 ]
  %t62 = icmp ule i64 %t33, %p_7_4
  %t63 = sub i64 %p_7_4, %t33
  %t64 = icmp uge i64 %t63, 16
  %t65 = and i1 %t62, %t64
  %t66 = icmp ule i64 %t33, %t31
  %t67 = sub i64 %t31, %t33
  %t68 = icmp uge i64 %t67, 16
  %t69 = and i1 %t66, %t68
  %t70 = and i1 %t65, %t69
  br i1 %t70, label %byte_sum_vector_body_32, label %byte_sum_half_head_32
byte_sum_vector_body_32:
  %t37 = getelementptr i8, ptr %t30, i64 %t33
  %t38 = load <16 x i8>, ptr %t37, align 1
  %t39 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t38, <16 x i8> zeroinitializer)
  %t40 = extractelement <2 x i64> %t39, i32 0
  %t41 = extractelement <2 x i64> %t39, i32 1
  %t42 = add i64 %t40, %t41
  %t43 = add i64 %t34, %t42
  %t44 = add i64 %t33, 16
  br label %byte_sum_vector_head_32
byte_sum_half_head_32:
  %t71 = icmp ule i64 %t33, %p_7_4
  %t72 = sub i64 %p_7_4, %t33
  %t73 = icmp uge i64 %t72, 8
  %t74 = and i1 %t71, %t73
  %t75 = icmp ule i64 %t33, %t31
  %t76 = sub i64 %t31, %t33
  %t77 = icmp uge i64 %t76, 8
  %t78 = and i1 %t75, %t77
  %t79 = and i1 %t74, %t78
  br i1 %t79, label %byte_sum_half_body_32, label %byte_sum_scalar_head_32
byte_sum_half_body_32:
  %t45 = getelementptr i8, ptr %t30, i64 %t33
  %t46 = load i64, ptr %t45, align 1
  %t47 = insertelement <2 x i64> zeroinitializer, i64 %t46, i32 0
  %t48 = bitcast <2 x i64> %t47 to <16 x i8>
  %t49 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t48, <16 x i8> zeroinitializer)
  %t50 = extractelement <2 x i64> %t49, i32 0
  %t51 = add i64 %t34, %t50
  %t52 = add i64 %t33, 8
  br label %byte_sum_scalar_head_32
byte_sum_scalar_head_32:
  %t35 = phi i64 [ %t33, %byte_sum_half_head_32 ], [ %t52, %byte_sum_half_body_32 ], [ %t61, %byte_sum_scalar_done_32 ]
  %t36 = phi i64 [ %t34, %byte_sum_half_head_32 ], [ %t51, %byte_sum_half_body_32 ], [ %t60, %byte_sum_scalar_done_32 ]
  %t80 = icmp ult i64 %t35, %p_7_4
  br i1 %t80, label %byte_sum_scalar_body_32, label %byte_sum_finished_32
byte_sum_scalar_body_32:
  %t53 = extractvalue %hia.buffer %p_7_2, 0
  %t54 = extractvalue %hia.buffer %p_7_2, 1
  %t55 = icmp ult i64 %t35, %t54
  br i1 %t55, label %ok_56, label %trap_56
trap_56:
  call void @abort()
  unreachable
ok_56:
  %t57 = getelementptr i8, ptr %t53, i64 %t35
  %t58 = load i8, ptr %t57, align 1
  %t59 = zext i8 %t58 to i64
  %t60 = add i64 %t36, %t59
  %t61 = add i64 %t35, 1
  br label %byte_sum_scalar_done_32
byte_sum_scalar_done_32:
  br label %byte_sum_scalar_head_32
byte_sum_finished_32:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t81 = extractvalue %hia.buffer %p_8_2, 0
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %drop_nonnull_83, label %drop_after_83
drop_nonnull_83:
  call void @free(ptr %t81) nobuiltin
  br label %drop_after_83
drop_after_83:
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 %p_0_0, i1 false)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  %t4 = select i1 %t3, i64 %p_0_0, i64 0
  %t5 = insertvalue %hia.buffer %t2, i64 %t4, 1
  br i1 %t3, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i1 [ %t3, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %t5, %edge_0 ]
  %p_1_4 = phi i8 [ 1, %edge_0 ]
  br label %edge_2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i1 [ %t3, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %t5, %edge_1 ]
  %p_2_4 = phi i8 [ 1, %edge_1 ]
  %t6 = extractvalue %hia.buffer %p_2_3, 0
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %drop_nonnull_8, label %drop_after_8
drop_nonnull_8:
  call void @free(ptr %t6) nobuiltin
  br label %drop_after_8
drop_after_8:
  %t9 = zext i8 %p_2_4 to i64
  %t10 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t9)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  %t13 = xor i1 %t12, true
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  ret i64 %t11
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_0, %edge_5 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_2 ], [ %p_4_1, %edge_5 ]
  %p_3_2 = phi %hia.buffer [ %p_1_3, %edge_2 ], [ %p_4_2, %edge_5 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ], [ %p_4_3, %edge_5 ]
  %p_3_4 = phi i64 [ 0, %edge_2 ], [ %t29, %edge_5 ]
  %t15 = icmp ult i64 %p_3_4, %p_3_3
  br i1 %t15, label %edge_3, label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_3_0, %edge_3 ]
  %p_4_1 = phi i32 [ %p_3_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_3_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_3_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_3_4, %edge_3 ]
  %t16 = trunc i64 %p_4_4 to i32
  %t17 = mul i32 %t16, %p_4_1
  %t18 = add i32 %t17, 17
  %t19 = trunc i64 %p_4_4 to i8
  %t20 = trunc i32 %p_4_1 to i8
  %t21 = mul i8 %t19, %t20
  %t22 = add i8 %t21, 17
  %t23 = extractvalue %hia.buffer %p_4_2, 0
  %t24 = extractvalue %hia.buffer %p_4_2, 1
  %t25 = icmp ult i64 %p_4_4, %t24
  br i1 %t25, label %ok_26, label %trap_26
trap_26:
  call void @abort()
  unreachable
ok_26:
  %t27 = getelementptr i8, ptr %t23, i64 %p_4_4
  store i8 %t22, ptr %t27, align 1
  %t28 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_4_4, i64 1)
  %t29 = extractvalue { i64, i1 } %t28, 0
  %t30 = extractvalue { i64, i1 } %t28, 1
  %t31 = xor i1 %t30, true
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_0, %edge_9 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_6 ], [ %p_7_1, %edge_9 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_6 ], [ %p_7_2, %edge_9 ]
  %p_6_3 = phi i64 [ 0, %edge_6 ], [ %t42, %edge_9 ]
  %p_6_4 = phi i64 [ %p_5_0, %edge_6 ], [ %p_7_4, %edge_9 ]
  %p_6_5 = phi i64 [ 0, %edge_6 ], [ %t47, %edge_9 ]
  %t33 = icmp ult i64 %p_6_5, %p_6_4
  br i1 %t33, label %edge_7, label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_7 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_7 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_7 ]
  %p_7_3 = phi i64 [ %p_6_3, %edge_7 ]
  %p_7_4 = phi i64 [ %p_6_4, %edge_7 ]
  %p_7_5 = phi i64 [ %p_6_5, %edge_7 ]
  %t34 = extractvalue %hia.buffer %p_7_2, 0
  %t35 = extractvalue %hia.buffer %p_7_2, 1
  %t36 = icmp ult i64 %p_7_5, %t35
  br i1 %t36, label %ok_37, label %trap_37
trap_37:
  call void @abort()
  unreachable
ok_37:
  %t38 = getelementptr i8, ptr %t34, i64 %p_7_5
  %t39 = load i8, ptr %t38, align 1
  %t40 = zext i8 %t39 to i64
  %t41 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_3, i64 %t40)
  %t42 = extractvalue { i64, i1 } %t41, 0
  %t43 = extractvalue { i64, i1 } %t41, 1
  %t44 = xor i1 %t43, true
  br i1 %t44, label %ok_45, label %trap_45
trap_45:
  call void @abort()
  unreachable
ok_45:
  %t46 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_7_5, i64 1)
  %t47 = extractvalue { i64, i1 } %t46, 0
  %t48 = extractvalue { i64, i1 } %t46, 1
  %t49 = xor i1 %t48, true
  br i1 %t49, label %ok_50, label %trap_50
trap_50:
  call void @abort()
  unreachable
ok_50:
  br label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_6_0, %edge_8 ]
  %p_8_1 = phi i32 [ %p_6_1, %edge_8 ]
  %p_8_2 = phi %hia.buffer [ %p_6_2, %edge_8 ]
  %p_8_3 = phi i64 [ %p_6_3, %edge_8 ]
  %p_8_4 = phi i64 [ %p_6_4, %edge_8 ]
  %p_8_5 = phi i64 [ %p_6_5, %edge_8 ]
  %t51 = extractvalue %hia.buffer %p_8_2, 0
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %drop_nonnull_53, label %drop_after_53
drop_nonnull_53:
  call void @free(ptr %t51) nobuiltin
  br label %drop_after_53
drop_after_53:
  ret i64 %p_8_3
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b3
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b6
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
!0 = !{!"branch_weights", i32 2, i32 1}
