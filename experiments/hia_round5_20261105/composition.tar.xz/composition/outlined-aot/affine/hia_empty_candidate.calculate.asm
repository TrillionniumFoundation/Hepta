
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/outlined-aot/affine/hia_empty_candidate.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001660 <calculate>:
    1660:	48 85 ff             	test   %rdi,%rdi
    1663:	0f 85 47 fb ff ff    	jne    11b0 <__hia_fn_0>
    1669:	31 c0                	xor    %eax,%eax
    166b:	c3                   	ret

Disassembly of section .fini:
