
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/outlined-aot/affine/hia_guarded_outline.o：     文件格式 elf64-x86-64


Disassembly of section .text:

0000000000000000 <__hia_fn_1>:
   0:	55                   	push   %rbp
   1:	41 56                	push   %r14
   3:	53                   	push   %rbx
   4:	48 85 ff             	test   %rdi,%rdi
   7:	74 1f                	je     28 <__hia_fn_1+0x28>
   9:	89 f5                	mov    %esi,%ebp
   b:	48 89 fb             	mov    %rdi,%rbx
   e:	e8 00 00 00 00       	call   13 <__hia_fn_1+0x13>
			f: R_X86_64_PLT32	malloc-0x4
  13:	48 85 c0             	test   %rax,%rax
  16:	74 1a                	je     32 <__hia_fn_1+0x32>
  18:	48 89 c7             	mov    %rax,%rdi
  1b:	48 83 fb 03          	cmp    $0x3,%rbx
  1f:	77 1c                	ja     3d <__hia_fn_1+0x3d>
  21:	31 c9                	xor    %ecx,%ecx
  23:	e9 47 01 00 00       	jmp    16f <__hia_fn_1+0x16f>
  28:	31 ff                	xor    %edi,%edi
  2a:	45 31 f6             	xor    %r14d,%r14d
  2d:	e9 89 02 00 00       	jmp    2bb <__hia_fn_1+0x2bb>
  32:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
  38:	e9 88 02 00 00       	jmp    2c5 <__hia_fn_1+0x2c5>
  3d:	48 ba f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rdx
  44:	ff ff 01 
  47:	40 0f b6 c5          	movzbl %bpl,%eax
  4b:	48 83 fb 10          	cmp    $0x10,%rbx
  4f:	73 07                	jae    58 <__hia_fn_1+0x58>
  51:	31 c9                	xor    %ecx,%ecx
  53:	e9 94 00 00 00       	jmp    ec <__hia_fn_1+0xec>
  58:	48 89 d9             	mov    %rbx,%rcx
  5b:	48 21 d1             	and    %rdx,%rcx
  5e:	66 0f 6e c0          	movd   %eax,%xmm0
  62:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  66:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  6b:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
  70:	66 0f 6f 0d 00 00 00 	movdqa 0x0(%rip),%xmm1        # 78 <__hia_fn_1+0x78>
  77:	00 
			74: R_X86_64_PC32	.LCPI0_0-0x4
  78:	31 f6                	xor    %esi,%esi
  7a:	66 0f 6f d0          	movdqa %xmm0,%xmm2
  7e:	66 0f 68 d2          	punpckhbw %xmm2,%xmm2
  82:	66 0f 6f 1d 00 00 00 	movdqa 0x0(%rip),%xmm3        # 8a <__hia_fn_1+0x8a>
  89:	00 
			86: R_X86_64_PC32	.LCPI0_1-0x4
  8a:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  8e:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 96 <__hia_fn_1+0x96>
  95:	00 
			92: R_X86_64_PC32	.LCPI0_2-0x4
  96:	66 0f 6f 2d 00 00 00 	movdqa 0x0(%rip),%xmm5        # 9e <__hia_fn_1+0x9e>
  9d:	00 
			9a: R_X86_64_PC32	.LCPI0_3-0x4
  9e:	66 90                	xchg   %ax,%ax
  a0:	66 0f 6f f1          	movdqa %xmm1,%xmm6
  a4:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
  a8:	66 0f d5 f2          	pmullw %xmm2,%xmm6
  ac:	66 0f db f3          	pand   %xmm3,%xmm6
  b0:	66 0f 6f f9          	movdqa %xmm1,%xmm7
  b4:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
  b8:	66 0f d5 f8          	pmullw %xmm0,%xmm7
  bc:	66 0f db fb          	pand   %xmm3,%xmm7
  c0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
  c4:	66 0f fc fc          	paddb  %xmm4,%xmm7
  c8:	f3 0f 7f 3c 37       	movdqu %xmm7,(%rdi,%rsi,1)
  cd:	48 83 c6 10          	add    $0x10,%rsi
  d1:	66 0f fc cd          	paddb  %xmm5,%xmm1
  d5:	48 39 f1             	cmp    %rsi,%rcx
  d8:	75 c6                	jne    a0 <__hia_fn_1+0xa0>
  da:	48 39 cb             	cmp    %rcx,%rbx
  dd:	0f 84 ab 00 00 00    	je     18e <__hia_fn_1+0x18e>
  e3:	f6 c3 0c             	test   $0xc,%bl
  e6:	0f 84 83 00 00 00    	je     16f <__hia_fn_1+0x16f>
  ec:	48 89 ce             	mov    %rcx,%rsi
  ef:	48 83 c2 0c          	add    $0xc,%rdx
  f3:	48 89 d1             	mov    %rdx,%rcx
  f6:	66 0f 6e c6          	movd   %esi,%xmm0
  fa:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  fe:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 103:	66 0f eb 05 00 00 00 	por    0x0(%rip),%xmm0        # 10b <__hia_fn_1+0x10b>
 10a:	00 
			107: R_X86_64_PC32	.LCPI0_4-0x4
 10b:	48 21 d9             	and    %rbx,%rcx
 10e:	66 0f 6e c8          	movd   %eax,%xmm1
 112:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 116:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 11b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 11f:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 127 <__hia_fn_1+0x127>
 126:	00 
			123: R_X86_64_PC32	.LCPI0_1-0x4
 127:	66 0f 6f 1d 00 00 00 	movdqa 0x0(%rip),%xmm3        # 12f <__hia_fn_1+0x12f>
 12e:	00 
			12b: R_X86_64_PC32	.LCPI0_5-0x4
 12f:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 137 <__hia_fn_1+0x137>
 136:	00 
			133: R_X86_64_PC32	.LCPI0_6-0x4
 137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 13e:	00 00 
 140:	66 0f 6f e8          	movdqa %xmm0,%xmm5
 144:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
 148:	66 0f d5 e9          	pmullw %xmm1,%xmm5
 14c:	66 0f db ea          	pand   %xmm2,%xmm5
 150:	66 0f 67 ed          	packuswb %xmm5,%xmm5
 154:	66 0f fc eb          	paddb  %xmm3,%xmm5
 158:	66 0f 7e 2c 37       	movd   %xmm5,(%rdi,%rsi,1)
 15d:	48 83 c6 04          	add    $0x4,%rsi
 161:	66 0f fc c4          	paddb  %xmm4,%xmm0
 165:	48 39 f1             	cmp    %rsi,%rcx
 168:	75 d6                	jne    140 <__hia_fn_1+0x140>
 16a:	48 39 cb             	cmp    %rcx,%rbx
 16d:	74 1f                	je     18e <__hia_fn_1+0x18e>
 16f:	89 c8                	mov    %ecx,%eax
 171:	40 f6 e5             	mul    %bpl
 174:	04 11                	add    $0x11,%al
 176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 17d:	00 00 00 
 180:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
 183:	48 ff c1             	inc    %rcx
 186:	40 00 e8             	add    %bpl,%al
 189:	48 39 cb             	cmp    %rcx,%rbx
 18c:	75 f2                	jne    180 <__hia_fn_1+0x180>
 18e:	48 83 fb 10          	cmp    $0x10,%rbx
 192:	72 68                	jb     1fc <__hia_fn_1+0x1fc>
 194:	b8 10 00 00 00       	mov    $0x10,%eax
 199:	45 31 f6             	xor    %r14d,%r14d
 19c:	66 0f ef c0          	pxor   %xmm0,%xmm0
 1a0:	48 89 d9             	mov    %rbx,%rcx
 1a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1aa:	84 00 00 00 00 00 
 1b0:	48 89 c2             	mov    %rax,%rdx
 1b3:	f3 0f 6f 4c 07 f0    	movdqu -0x10(%rdi,%rax,1),%xmm1
 1b9:	66 0f f6 c8          	psadbw %xmm0,%xmm1
 1bd:	66 48 0f 7e c8       	movq   %xmm1,%rax
 1c2:	4c 01 f0             	add    %r14,%rax
 1c5:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
 1ca:	66 49 0f 7e ce       	movq   %xmm1,%r14
 1cf:	49 01 c6             	add    %rax,%r14
 1d2:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
 1d6:	48 8d 42 10          	lea    0x10(%rdx),%rax
 1da:	48 39 da             	cmp    %rbx,%rdx
 1dd:	0f 96 c2             	setbe  %dl
 1e0:	77 08                	ja     1ea <__hia_fn_1+0x1ea>
 1e2:	48 83 f9 10          	cmp    $0x10,%rcx
 1e6:	72 02                	jb     1ea <__hia_fn_1+0x1ea>
 1e8:	73 c6                	jae    1b0 <__hia_fn_1+0x1b0>
 1ea:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
 1ee:	48 39 d8             	cmp    %rbx,%rax
 1f1:	40 0f 96 c6          	setbe  %sil
 1f5:	40 84 f6             	test   %sil,%sil
 1f8:	75 14                	jne    20e <__hia_fn_1+0x20e>
 1fa:	eb 3b                	jmp    237 <__hia_fn_1+0x237>
 1fc:	40 b6 01             	mov    $0x1,%sil
 1ff:	31 c0                	xor    %eax,%eax
 201:	45 31 f6             	xor    %r14d,%r14d
 204:	48 89 d9             	mov    %rbx,%rcx
 207:	b2 01                	mov    $0x1,%dl
 209:	40 84 f6             	test   %sil,%sil
 20c:	74 29                	je     237 <__hia_fn_1+0x237>
 20e:	84 d2                	test   %dl,%dl
 210:	74 25                	je     237 <__hia_fn_1+0x237>
 212:	48 83 f9 08          	cmp    $0x8,%rcx
 216:	72 1f                	jb     237 <__hia_fn_1+0x237>
 218:	48 83 f9 08          	cmp    $0x8,%rcx
 21c:	72 19                	jb     237 <__hia_fn_1+0x237>
 21e:	f3 0f 7e 04 07       	movq   (%rdi,%rax,1),%xmm0
 223:	66 0f ef c9          	pxor   %xmm1,%xmm1
 227:	66 0f f6 c8          	psadbw %xmm0,%xmm1
 22b:	66 48 0f 7e c9       	movq   %xmm1,%rcx
 230:	49 01 ce             	add    %rcx,%r14
 233:	48 83 c0 08          	add    $0x8,%rax
 237:	48 89 c1             	mov    %rax,%rcx
 23a:	48 29 d9             	sub    %rbx,%rcx
 23d:	73 7c                	jae    2bb <__hia_fn_1+0x2bb>
 23f:	89 da                	mov    %ebx,%edx
 241:	29 c2                	sub    %eax,%edx
 243:	83 e2 07             	and    $0x7,%edx
 246:	74 17                	je     25f <__hia_fn_1+0x25f>
 248:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 24f:	00 
 250:	0f b6 34 07          	movzbl (%rdi,%rax,1),%esi
 254:	49 01 f6             	add    %rsi,%r14
 257:	48 ff c0             	inc    %rax
 25a:	48 ff ca             	dec    %rdx
 25d:	75 f1                	jne    250 <__hia_fn_1+0x250>
 25f:	48 83 f9 f8          	cmp    $0xfffffffffffffff8,%rcx
 263:	77 5b                	ja     2c0 <__hia_fn_1+0x2c0>
 265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 26c:	00 00 00 00 
 270:	0f b6 0c 07          	movzbl (%rdi,%rax,1),%ecx
 274:	4c 01 f1             	add    %r14,%rcx
 277:	0f b6 54 07 01       	movzbl 0x1(%rdi,%rax,1),%edx
 27c:	0f b6 74 07 02       	movzbl 0x2(%rdi,%rax,1),%esi
 281:	48 01 d6             	add    %rdx,%rsi
 284:	48 01 ce             	add    %rcx,%rsi
 287:	0f b6 4c 07 03       	movzbl 0x3(%rdi,%rax,1),%ecx
 28c:	0f b6 54 07 04       	movzbl 0x4(%rdi,%rax,1),%edx
 291:	48 01 ca             	add    %rcx,%rdx
 294:	0f b6 4c 07 05       	movzbl 0x5(%rdi,%rax,1),%ecx
 299:	48 01 d1             	add    %rdx,%rcx
 29c:	48 01 f1             	add    %rsi,%rcx
 29f:	0f b6 54 07 06       	movzbl 0x6(%rdi,%rax,1),%edx
 2a4:	44 0f b6 74 07 07    	movzbl 0x7(%rdi,%rax,1),%r14d
 2aa:	49 01 d6             	add    %rdx,%r14
 2ad:	49 01 ce             	add    %rcx,%r14
 2b0:	48 83 c0 08          	add    $0x8,%rax
 2b4:	48 39 c3             	cmp    %rax,%rbx
 2b7:	75 b7                	jne    270 <__hia_fn_1+0x270>
 2b9:	eb 05                	jmp    2c0 <__hia_fn_1+0x2c0>
 2bb:	48 85 ff             	test   %rdi,%rdi
 2be:	74 05                	je     2c5 <__hia_fn_1+0x2c5>
 2c0:	e8 00 00 00 00       	call   2c5 <__hia_fn_1+0x2c5>
			2c1: R_X86_64_PLT32	free-0x4
 2c5:	4c 89 f0             	mov    %r14,%rax
 2c8:	5b                   	pop    %rbx
 2c9:	41 5e                	pop    %r14
 2cb:	5d                   	pop    %rbp
 2cc:	c3                   	ret
 2cd:	0f 1f 00             	nopl   (%rax)

00000000000002d0 <__hia_fn_2>:
 2d0:	55                   	push   %rbp
 2d1:	41 56                	push   %r14
 2d3:	53                   	push   %rbx
 2d4:	89 f5                	mov    %esi,%ebp
 2d6:	48 89 fb             	mov    %rdi,%rbx
 2d9:	48 85 ff             	test   %rdi,%rdi
 2dc:	78 2a                	js     308 <__hia_fn_2+0x38>
 2de:	48 89 df             	mov    %rbx,%rdi
 2e1:	e8 00 00 00 00       	call   2e6 <__hia_fn_2+0x16>
			2e2: R_X86_64_PLT32	malloc-0x4
 2e6:	48 85 c0             	test   %rax,%rax
 2e9:	74 1d                	je     308 <__hia_fn_2+0x38>
 2eb:	48 89 c7             	mov    %rax,%rdi
 2ee:	b0 01                	mov    $0x1,%al
 2f0:	a8 01                	test   $0x1,%al
 2f2:	75 1c                	jne    310 <__hia_fn_2+0x40>
 2f4:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
 2fa:	48 85 ff             	test   %rdi,%rdi
 2fd:	0f 85 62 01 00 00    	jne    465 <__hia_fn_2+0x195>
 303:	e9 62 01 00 00       	jmp    46a <__hia_fn_2+0x19a>
 308:	31 ff                	xor    %edi,%edi
 30a:	31 c0                	xor    %eax,%eax
 30c:	a8 01                	test   $0x1,%al
 30e:	74 e4                	je     2f4 <__hia_fn_2+0x24>
 310:	48 89 d8             	mov    %rbx,%rax
 313:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
 317:	66 0f 6e c5          	movd   %ebp,%xmm0
 31b:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 31f:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 324:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
 329:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 331 <__hia_fn_2+0x61>
 330:	00 
			32d: R_X86_64_PC32	.LCPI1_0-0x4
 331:	31 c9                	xor    %ecx,%ecx
 333:	66 0f 6f d9          	movdqa %xmm1,%xmm3
 337:	66 0f 68 db          	punpckhbw %xmm3,%xmm3
 33b:	66 0f 6f 05 00 00 00 	movdqa 0x0(%rip),%xmm0        # 343 <__hia_fn_2+0x73>
 342:	00 
			33f: R_X86_64_PC32	.LCPI1_1-0x4
 343:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 347:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 34f <__hia_fn_2+0x7f>
 34e:	00 
			34b: R_X86_64_PC32	.LCPI1_2-0x4
 34f:	66 0f 6f 2d 00 00 00 	movdqa 0x0(%rip),%xmm5        # 357 <__hia_fn_2+0x87>
 356:	00 
			353: R_X86_64_PC32	.LCPI1_3-0x4
 357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 35e:	00 00 
 360:	66 0f 6f f2          	movdqa %xmm2,%xmm6
 364:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
 368:	66 0f d5 f3          	pmullw %xmm3,%xmm6
 36c:	66 0f db f0          	pand   %xmm0,%xmm6
 370:	66 0f 6f fa          	movdqa %xmm2,%xmm7
 374:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
 378:	66 0f d5 f9          	pmullw %xmm1,%xmm7
 37c:	66 0f db f8          	pand   %xmm0,%xmm7
 380:	66 0f 67 fe          	packuswb %xmm6,%xmm7
 384:	66 0f fc fc          	paddb  %xmm4,%xmm7
 388:	f3 0f 7f 3c 0f       	movdqu %xmm7,(%rdi,%rcx,1)
 38d:	48 83 c1 10          	add    $0x10,%rcx
 391:	66 0f fc d5          	paddb  %xmm5,%xmm2
 395:	48 39 c8             	cmp    %rcx,%rax
 398:	75 c6                	jne    360 <__hia_fn_2+0x90>
 39a:	48 39 c3             	cmp    %rax,%rbx
 39d:	0f 84 9b 00 00 00    	je     43e <__hia_fn_2+0x16e>
 3a3:	f6 c3 0c             	test   $0xc,%bl
 3a6:	74 79                	je     421 <__hia_fn_2+0x151>
 3a8:	48 89 d9             	mov    %rbx,%rcx
 3ab:	66 0f 6e c8          	movd   %eax,%xmm1
 3af:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 3b3:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 3b8:	66 0f eb 0d 00 00 00 	por    0x0(%rip),%xmm1        # 3c0 <__hia_fn_2+0xf0>
 3bf:	00 
			3bc: R_X86_64_PC32	.LCPI1_4-0x4
 3c0:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
 3c4:	40 0f b6 d5          	movzbl %bpl,%edx
 3c8:	66 0f 6e d2          	movd   %edx,%xmm2
 3cc:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
 3d0:	f2 0f 70 d2 00       	pshuflw $0x0,%xmm2,%xmm2
 3d5:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
 3d9:	66 0f 6f 1d 00 00 00 	movdqa 0x0(%rip),%xmm3        # 3e1 <__hia_fn_2+0x111>
 3e0:	00 
			3dd: R_X86_64_PC32	.LCPI1_5-0x4
 3e1:	66 0f 6f 25 00 00 00 	movdqa 0x0(%rip),%xmm4        # 3e9 <__hia_fn_2+0x119>
 3e8:	00 
			3e5: R_X86_64_PC32	.LCPI1_6-0x4
 3e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 3f0:	66 0f 6f e9          	movdqa %xmm1,%xmm5
 3f4:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
 3f8:	66 0f d5 ea          	pmullw %xmm2,%xmm5
 3fc:	66 0f db e8          	pand   %xmm0,%xmm5
 400:	66 0f 67 ed          	packuswb %xmm5,%xmm5
 404:	66 0f fc eb          	paddb  %xmm3,%xmm5
 408:	66 0f 7e 2c 07       	movd   %xmm5,(%rdi,%rax,1)
 40d:	48 83 c0 04          	add    $0x4,%rax
 411:	66 0f fc cc          	paddb  %xmm4,%xmm1
 415:	48 39 c1             	cmp    %rax,%rcx
 418:	75 d6                	jne    3f0 <__hia_fn_2+0x120>
 41a:	48 39 cb             	cmp    %rcx,%rbx
 41d:	75 05                	jne    424 <__hia_fn_2+0x154>
 41f:	eb 1d                	jmp    43e <__hia_fn_2+0x16e>
 421:	48 89 c1             	mov    %rax,%rcx
 424:	89 c8                	mov    %ecx,%eax
 426:	40 f6 e5             	mul    %bpl
 429:	04 11                	add    $0x11,%al
 42b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 430:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
 433:	48 ff c1             	inc    %rcx
 436:	40 00 e8             	add    %bpl,%al
 439:	48 39 cb             	cmp    %rcx,%rbx
 43c:	75 f2                	jne    430 <__hia_fn_2+0x160>
 43e:	31 c0                	xor    %eax,%eax
 440:	45 31 f6             	xor    %r14d,%r14d
 443:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 44a:	84 00 00 00 00 00 
 450:	4c 89 f1             	mov    %r14,%rcx
 453:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
 458:	49 01 ce             	add    %rcx,%r14
 45b:	72 15                	jb     472 <__hia_fn_2+0x1a2>
 45d:	48 ff c0             	inc    %rax
 460:	48 39 c3             	cmp    %rax,%rbx
 463:	75 eb                	jne    450 <__hia_fn_2+0x180>
 465:	e8 00 00 00 00       	call   46a <__hia_fn_2+0x19a>
			466: R_X86_64_PLT32	free-0x4
 46a:	4c 89 f0             	mov    %r14,%rax
 46d:	5b                   	pop    %rbx
 46e:	41 5e                	pop    %r14
 470:	5d                   	pop    %rbp
 471:	c3                   	ret
 472:	e8 00 00 00 00       	call   477 <__hia_fn_2+0x1a7>
			473: R_X86_64_PLT32	abort-0x4
 477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 47e:	00 00 

0000000000000480 <calculate>:
 480:	48 85 ff             	test   %rdi,%rdi
 483:	75 03                	jne    488 <calculate+0x8>
 485:	31 c0                	xor    %eax,%eax
 487:	c3                   	ret
 488:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
 48f:	01 01 01 
 492:	48 39 c7             	cmp    %rax,%rdi
 495:	0f 86 65 fb ff ff    	jbe    0 <__hia_fn_1>
 49b:	e9 30 fe ff ff       	jmp    2d0 <__hia_fn_2>
