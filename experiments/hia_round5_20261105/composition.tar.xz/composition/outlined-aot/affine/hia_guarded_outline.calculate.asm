
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/outlined-aot/affine/hia_guarded_outline.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001630 <calculate>:
    1630:	48 85 ff             	test   %rdi,%rdi
    1633:	75 03                	jne    1638 <calculate+0x8>
    1635:	31 c0                	xor    %eax,%eax
    1637:	c3                   	ret
    1638:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
    163f:	01 01 01 
    1642:	48 39 c7             	cmp    %rax,%rdi
    1645:	0f 86 65 fb ff ff    	jbe    11b0 <__hia_fn_1>
    164b:	e9 30 fe ff ff       	jmp    1480 <__hia_fn_2>

Disassembly of section .fini:
