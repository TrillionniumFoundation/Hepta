; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8>, <16 x i8>)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp eq i64 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t2 = icmp ule i64 %p_1_0, 72340172838076673
  br i1 %t2, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %t3 = call %hia.alloc @__hia_allocate(i64 %p_2_0, i1 false)
  %t4 = extractvalue %hia.alloc %t3, 0
  %t5 = extractvalue %hia.alloc %t3, 1
  %t6 = select i1 %t5, i64 %p_2_0, i64 0
  %t7 = insertvalue %hia.buffer %t4, i64 %t6, 1
  br i1 %t5, label %edge_4, label %edge_5
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_4 ]
  %p_3_1 = phi i32 [ %p_2_1, %edge_4 ]
  %p_3_2 = phi i1 [ %t5, %edge_4 ]
  %p_3_3 = phi %hia.buffer [ %t7, %edge_4 ]
  %p_3_4 = phi i8 [ 1, %edge_4 ]
  br label %edge_6
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_5 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_5 ]
  %p_4_2 = phi i1 [ %t5, %edge_5 ]
  %p_4_3 = phi %hia.buffer [ %t7, %edge_5 ]
  %p_4_4 = phi i8 [ 1, %edge_5 ]
  %t8 = extractvalue %hia.buffer %p_4_3, 0
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %drop_nonnull_10, label %drop_after_10
drop_nonnull_10:
  call void @free(ptr %t8) nobuiltin
  br label %drop_after_10
drop_after_10:
  %t11 = zext i8 %p_4_4 to i64
  %t12 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t11)
  %t13 = extractvalue { i64, i1 } %t12, 0
  %t14 = extractvalue { i64, i1 } %t12, 1
  %t15 = xor i1 %t14, true
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  ret i64 %t13
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_6 ], [ %p_6_0, %edge_9 ]
  %p_5_1 = phi i32 [ %p_3_1, %edge_6 ], [ %p_6_1, %edge_9 ]
  %p_5_2 = phi %hia.buffer [ %p_3_3, %edge_6 ], [ %p_6_2, %edge_9 ]
  %p_5_3 = phi i64 [ %p_3_0, %edge_6 ], [ %p_6_3, %edge_9 ]
  %p_5_4 = phi i64 [ 0, %edge_6 ], [ %t30, %edge_9 ]
  %t17 = icmp ult i64 %p_5_4, %p_5_3
  br i1 %t17, label %edge_7, label %edge_8
b6:
  %p_6_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_6_1 = phi i32 [ %p_5_1, %edge_7 ]
  %p_6_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_6_3 = phi i64 [ %p_5_3, %edge_7 ]
  %p_6_4 = phi i64 [ %p_5_4, %edge_7 ]
  %t18 = trunc i64 %p_6_4 to i32
  %t19 = mul i32 %t18, %p_6_1
  %t20 = add i32 %t19, 17
  %t21 = trunc i64 %p_6_4 to i8
  %t22 = trunc i32 %p_6_1 to i8
  %t23 = mul i8 %t21, %t22
  %t24 = add i8 %t23, 17
  %t25 = extractvalue %hia.buffer %p_6_2, 0
  %t26 = extractvalue %hia.buffer %p_6_2, 1
  %t27 = icmp ult i64 %p_6_4, %t26
  br i1 %t27, label %ok_28, label %trap_28
trap_28:
  call void @abort()
  unreachable
ok_28:
  %t29 = getelementptr i8, ptr %t25, i64 %p_6_4
  store i8 %t24, ptr %t29, align 1
  %t30 = add i64 %p_6_4, 1
  br label %edge_9
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_8 ]
  %p_7_1 = phi i32 [ %p_5_1, %edge_8 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_8 ]
  %p_7_3 = phi i64 [ %p_5_3, %edge_8 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_8 ]
  br label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_10 ], [ %p_9_0, %edge_13 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_10 ], [ %p_9_1, %edge_13 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_10 ], [ %p_9_2, %edge_13 ]
  %p_8_3 = phi i64 [ 0, %edge_10 ], [ %t38, %edge_13 ]
  %p_8_4 = phi i64 [ %p_7_0, %edge_10 ], [ %p_9_4, %edge_13 ]
  %p_8_5 = phi i64 [ 0, %edge_10 ], [ %t37, %edge_13 ]
  %t31 = icmp ult i64 %p_8_5, %p_8_4
  br i1 %t31, label %edge_11, label %edge_12
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_11 ]
  %p_9_1 = phi i32 [ %p_8_1, %edge_11 ]
  %p_9_2 = phi %hia.buffer [ %p_8_2, %edge_11 ]
  %p_9_3 = phi i64 [ %p_8_3, %edge_11 ]
  %p_9_4 = phi i64 [ %p_8_4, %edge_11 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_11 ]
  %t32 = extractvalue %hia.buffer %p_9_2, 0
  %t33 = extractvalue %hia.buffer %p_9_2, 1
  br label %byte_sum_start_34
byte_sum_start_34:
  br label %byte_sum_vector_head_34
byte_sum_vector_head_34:
  %t35 = phi i64 [ %p_9_5, %byte_sum_start_34 ], [ %t46, %byte_sum_vector_body_34 ]
  %t36 = phi i64 [ %p_9_3, %byte_sum_start_34 ], [ %t45, %byte_sum_vector_body_34 ]
  %t64 = icmp ule i64 %t35, %p_9_4
  %t65 = sub i64 %p_9_4, %t35
  %t66 = icmp uge i64 %t65, 16
  %t67 = and i1 %t64, %t66
  %t68 = icmp ule i64 %t35, %t33
  %t69 = sub i64 %t33, %t35
  %t70 = icmp uge i64 %t69, 16
  %t71 = and i1 %t68, %t70
  %t72 = and i1 %t67, %t71
  br i1 %t72, label %byte_sum_vector_body_34, label %byte_sum_half_head_34
byte_sum_vector_body_34:
  %t39 = getelementptr i8, ptr %t32, i64 %t35
  %t40 = load <16 x i8>, ptr %t39, align 1
  %t41 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t40, <16 x i8> zeroinitializer)
  %t42 = extractelement <2 x i64> %t41, i32 0
  %t43 = extractelement <2 x i64> %t41, i32 1
  %t44 = add i64 %t42, %t43
  %t45 = add i64 %t36, %t44
  %t46 = add i64 %t35, 16
  br label %byte_sum_vector_head_34
byte_sum_half_head_34:
  %t73 = icmp ule i64 %t35, %p_9_4
  %t74 = sub i64 %p_9_4, %t35
  %t75 = icmp uge i64 %t74, 8
  %t76 = and i1 %t73, %t75
  %t77 = icmp ule i64 %t35, %t33
  %t78 = sub i64 %t33, %t35
  %t79 = icmp uge i64 %t78, 8
  %t80 = and i1 %t77, %t79
  %t81 = and i1 %t76, %t80
  br i1 %t81, label %byte_sum_half_body_34, label %byte_sum_scalar_head_34
byte_sum_half_body_34:
  %t47 = getelementptr i8, ptr %t32, i64 %t35
  %t48 = load i64, ptr %t47, align 1
  %t49 = insertelement <2 x i64> zeroinitializer, i64 %t48, i32 0
  %t50 = bitcast <2 x i64> %t49 to <16 x i8>
  %t51 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t50, <16 x i8> zeroinitializer)
  %t52 = extractelement <2 x i64> %t51, i32 0
  %t53 = add i64 %t36, %t52
  %t54 = add i64 %t35, 8
  br label %byte_sum_scalar_head_34
byte_sum_scalar_head_34:
  %t37 = phi i64 [ %t35, %byte_sum_half_head_34 ], [ %t54, %byte_sum_half_body_34 ], [ %t63, %byte_sum_scalar_done_34 ]
  %t38 = phi i64 [ %t36, %byte_sum_half_head_34 ], [ %t53, %byte_sum_half_body_34 ], [ %t62, %byte_sum_scalar_done_34 ]
  %t82 = icmp ult i64 %t37, %p_9_4
  br i1 %t82, label %byte_sum_scalar_body_34, label %byte_sum_finished_34
byte_sum_scalar_body_34:
  %t55 = extractvalue %hia.buffer %p_9_2, 0
  %t56 = extractvalue %hia.buffer %p_9_2, 1
  %t57 = icmp ult i64 %t37, %t56
  br i1 %t57, label %ok_58, label %trap_58
trap_58:
  call void @abort()
  unreachable
ok_58:
  %t59 = getelementptr i8, ptr %t55, i64 %t37
  %t60 = load i8, ptr %t59, align 1
  %t61 = zext i8 %t60 to i64
  %t62 = add i64 %t38, %t61
  %t63 = add i64 %t37, 1
  br label %byte_sum_scalar_done_34
byte_sum_scalar_done_34:
  br label %byte_sum_scalar_head_34
byte_sum_finished_34:
  br label %edge_13
b10:
  %p_10_0 = phi i64 [ %p_8_0, %edge_12 ]
  %p_10_1 = phi i32 [ %p_8_1, %edge_12 ]
  %p_10_2 = phi %hia.buffer [ %p_8_2, %edge_12 ]
  %p_10_3 = phi i64 [ %p_8_3, %edge_12 ]
  %p_10_4 = phi i64 [ %p_8_4, %edge_12 ]
  %p_10_5 = phi i64 [ %p_8_5, %edge_12 ]
  %t83 = extractvalue %hia.buffer %p_10_2, 0
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %drop_nonnull_85, label %drop_after_85
drop_nonnull_85:
  call void @free(ptr %t83) nobuiltin
  br label %drop_after_85
drop_after_85:
  ret i64 %p_10_3
b11:
  %p_11_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_11_1 = phi i32 [ %p_1_1, %edge_3 ]
  %t86 = call %hia.alloc @__hia_allocate(i64 %p_11_0, i1 false)
  %t87 = extractvalue %hia.alloc %t86, 0
  %t88 = extractvalue %hia.alloc %t86, 1
  %t89 = select i1 %t88, i64 %p_11_0, i64 0
  %t90 = insertvalue %hia.buffer %t87, i64 %t89, 1
  br i1 %t88, label %edge_14, label %edge_15
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_14 ]
  %p_12_1 = phi i32 [ %p_11_1, %edge_14 ]
  %p_12_2 = phi i1 [ %t88, %edge_14 ]
  %p_12_3 = phi %hia.buffer [ %t90, %edge_14 ]
  %p_12_4 = phi i8 [ 1, %edge_14 ]
  br label %edge_16
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_15 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_15 ]
  %p_13_2 = phi i1 [ %t88, %edge_15 ]
  %p_13_3 = phi %hia.buffer [ %t90, %edge_15 ]
  %p_13_4 = phi i8 [ 1, %edge_15 ]
  %t91 = extractvalue %hia.buffer %p_13_3, 0
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %drop_nonnull_93, label %drop_after_93
drop_nonnull_93:
  call void @free(ptr %t91) nobuiltin
  br label %drop_after_93
drop_after_93:
  %t94 = zext i8 %p_13_4 to i64
  %t95 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t94)
  %t96 = extractvalue { i64, i1 } %t95, 0
  %t97 = extractvalue { i64, i1 } %t95, 1
  %t98 = xor i1 %t97, true
  br i1 %t98, label %ok_99, label %trap_99
trap_99:
  call void @abort()
  unreachable
ok_99:
  ret i64 %t96
b14:
  %p_14_0 = phi i64 [ %p_12_0, %edge_16 ], [ %p_15_0, %edge_19 ]
  %p_14_1 = phi i32 [ %p_12_1, %edge_16 ], [ %p_15_1, %edge_19 ]
  %p_14_2 = phi %hia.buffer [ %p_12_3, %edge_16 ], [ %p_15_2, %edge_19 ]
  %p_14_3 = phi i64 [ %p_12_0, %edge_16 ], [ %p_15_3, %edge_19 ]
  %p_14_4 = phi i64 [ 0, %edge_16 ], [ %t114, %edge_19 ]
  %t100 = icmp ult i64 %p_14_4, %p_14_3
  br i1 %t100, label %edge_17, label %edge_18
b15:
  %p_15_0 = phi i64 [ %p_14_0, %edge_17 ]
  %p_15_1 = phi i32 [ %p_14_1, %edge_17 ]
  %p_15_2 = phi %hia.buffer [ %p_14_2, %edge_17 ]
  %p_15_3 = phi i64 [ %p_14_3, %edge_17 ]
  %p_15_4 = phi i64 [ %p_14_4, %edge_17 ]
  %t101 = trunc i64 %p_15_4 to i32
  %t102 = mul i32 %t101, %p_15_1
  %t103 = add i32 %t102, 17
  %t104 = trunc i64 %p_15_4 to i8
  %t105 = trunc i32 %p_15_1 to i8
  %t106 = mul i8 %t104, %t105
  %t107 = add i8 %t106, 17
  %t108 = extractvalue %hia.buffer %p_15_2, 0
  %t109 = extractvalue %hia.buffer %p_15_2, 1
  %t110 = icmp ult i64 %p_15_4, %t109
  br i1 %t110, label %ok_111, label %trap_111
trap_111:
  call void @abort()
  unreachable
ok_111:
  %t112 = getelementptr i8, ptr %t108, i64 %p_15_4
  store i8 %t107, ptr %t112, align 1
  %t113 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_15_4, i64 1)
  %t114 = extractvalue { i64, i1 } %t113, 0
  %t115 = extractvalue { i64, i1 } %t113, 1
  %t116 = xor i1 %t115, true
  br i1 %t116, label %ok_117, label %trap_117
trap_117:
  call void @abort()
  unreachable
ok_117:
  br label %edge_19
b16:
  %p_16_0 = phi i64 [ %p_14_0, %edge_18 ]
  %p_16_1 = phi i32 [ %p_14_1, %edge_18 ]
  %p_16_2 = phi %hia.buffer [ %p_14_2, %edge_18 ]
  %p_16_3 = phi i64 [ %p_14_3, %edge_18 ]
  %p_16_4 = phi i64 [ %p_14_4, %edge_18 ]
  br label %edge_20
b17:
  %p_17_0 = phi i64 [ %p_16_0, %edge_20 ], [ %p_18_0, %edge_23 ]
  %p_17_1 = phi i32 [ %p_16_1, %edge_20 ], [ %p_18_1, %edge_23 ]
  %p_17_2 = phi %hia.buffer [ %p_16_2, %edge_20 ], [ %p_18_2, %edge_23 ]
  %p_17_3 = phi i64 [ 0, %edge_20 ], [ %t127, %edge_23 ]
  %p_17_4 = phi i64 [ %p_16_0, %edge_20 ], [ %p_18_4, %edge_23 ]
  %p_17_5 = phi i64 [ 0, %edge_20 ], [ %t132, %edge_23 ]
  %t118 = icmp ult i64 %p_17_5, %p_17_4
  br i1 %t118, label %edge_21, label %edge_22
b18:
  %p_18_0 = phi i64 [ %p_17_0, %edge_21 ]
  %p_18_1 = phi i32 [ %p_17_1, %edge_21 ]
  %p_18_2 = phi %hia.buffer [ %p_17_2, %edge_21 ]
  %p_18_3 = phi i64 [ %p_17_3, %edge_21 ]
  %p_18_4 = phi i64 [ %p_17_4, %edge_21 ]
  %p_18_5 = phi i64 [ %p_17_5, %edge_21 ]
  %t119 = extractvalue %hia.buffer %p_18_2, 0
  %t120 = extractvalue %hia.buffer %p_18_2, 1
  %t121 = icmp ult i64 %p_18_5, %t120
  br i1 %t121, label %ok_122, label %trap_122
trap_122:
  call void @abort()
  unreachable
ok_122:
  %t123 = getelementptr i8, ptr %t119, i64 %p_18_5
  %t124 = load i8, ptr %t123, align 1
  %t125 = zext i8 %t124 to i64
  %t126 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_18_3, i64 %t125)
  %t127 = extractvalue { i64, i1 } %t126, 0
  %t128 = extractvalue { i64, i1 } %t126, 1
  %t129 = xor i1 %t128, true
  br i1 %t129, label %ok_130, label %trap_130
trap_130:
  call void @abort()
  unreachable
ok_130:
  %t131 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_18_5, i64 1)
  %t132 = extractvalue { i64, i1 } %t131, 0
  %t133 = extractvalue { i64, i1 } %t131, 1
  %t134 = xor i1 %t133, true
  br i1 %t134, label %ok_135, label %trap_135
trap_135:
  call void @abort()
  unreachable
ok_135:
  br label %edge_23
b19:
  %p_19_0 = phi i64 [ %p_17_0, %edge_22 ]
  %p_19_1 = phi i32 [ %p_17_1, %edge_22 ]
  %p_19_2 = phi %hia.buffer [ %p_17_2, %edge_22 ]
  %p_19_3 = phi i64 [ %p_17_3, %edge_22 ]
  %p_19_4 = phi i64 [ %p_17_4, %edge_22 ]
  %p_19_5 = phi i64 [ %p_17_5, %edge_22 ]
  %t136 = extractvalue %hia.buffer %p_19_2, 0
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %drop_nonnull_138, label %drop_after_138
drop_nonnull_138:
  call void @free(ptr %t136) nobuiltin
  br label %drop_after_138
drop_after_138:
  ret i64 %p_19_3
b20:
  %p_20_0 = phi i64 [ 0, %edge_0 ]
  %p_20_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t139 = icmp ule i64 %p_20_0, 72340172838076673
  br i1 %t139, label %edge_24, label %edge_25
b21:
  %p_21_0 = phi i64 [ %p_20_0, %edge_24 ]
  %p_21_1 = phi i32 [ %p_20_1, %edge_24 ]
  %t140 = call %hia.alloc @__hia_allocate(i64 %p_21_0, i1 false)
  %t141 = extractvalue %hia.alloc %t140, 0
  %t142 = extractvalue %hia.alloc %t140, 1
  %t143 = select i1 %t142, i64 %p_21_0, i64 0
  %t144 = insertvalue %hia.buffer %t141, i64 %t143, 1
  br i1 %t142, label %edge_26, label %edge_27
b22:
  %p_22_0 = phi i64 [ %p_21_0, %edge_26 ]
  %p_22_1 = phi i32 [ %p_21_1, %edge_26 ]
  %p_22_2 = phi i1 [ %t142, %edge_26 ]
  %p_22_3 = phi %hia.buffer [ %t144, %edge_26 ]
  %p_22_4 = phi i8 [ 1, %edge_26 ]
  br label %edge_28
b23:
  %p_23_0 = phi i64 [ %p_21_0, %edge_27 ]
  %p_23_1 = phi i32 [ %p_21_1, %edge_27 ]
  %p_23_2 = phi i1 [ %t142, %edge_27 ]
  %p_23_3 = phi %hia.buffer [ %t144, %edge_27 ]
  %p_23_4 = phi i8 [ 1, %edge_27 ]
  %t145 = extractvalue %hia.buffer %p_23_3, 0
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %drop_nonnull_147, label %drop_after_147
drop_nonnull_147:
  call void @free(ptr %t145) nobuiltin
  br label %drop_after_147
drop_after_147:
  %t148 = zext i8 %p_23_4 to i64
  %t149 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t148)
  %t150 = extractvalue { i64, i1 } %t149, 0
  %t151 = extractvalue { i64, i1 } %t149, 1
  %t152 = xor i1 %t151, true
  br i1 %t152, label %ok_153, label %trap_153
trap_153:
  call void @abort()
  unreachable
ok_153:
  ret i64 %t150
b24:
  %p_24_0 = phi i64 [ %p_22_0, %edge_28 ], [ %p_25_0, %edge_31 ]
  %p_24_1 = phi i32 [ %p_22_1, %edge_28 ], [ %p_25_1, %edge_31 ]
  %p_24_2 = phi %hia.buffer [ %p_22_3, %edge_28 ], [ %p_25_2, %edge_31 ]
  %p_24_3 = phi i64 [ %p_22_0, %edge_28 ], [ %p_25_3, %edge_31 ]
  %p_24_4 = phi i64 [ 0, %edge_28 ], [ %t167, %edge_31 ]
  %t154 = icmp ult i64 %p_24_4, %p_24_3
  br i1 %t154, label %edge_29, label %edge_30
b25:
  %p_25_0 = phi i64 [ %p_24_0, %edge_29 ]
  %p_25_1 = phi i32 [ %p_24_1, %edge_29 ]
  %p_25_2 = phi %hia.buffer [ %p_24_2, %edge_29 ]
  %p_25_3 = phi i64 [ %p_24_3, %edge_29 ]
  %p_25_4 = phi i64 [ %p_24_4, %edge_29 ]
  %t155 = trunc i64 %p_25_4 to i32
  %t156 = mul i32 %t155, %p_25_1
  %t157 = add i32 %t156, 17
  %t158 = trunc i64 %p_25_4 to i8
  %t159 = trunc i32 %p_25_1 to i8
  %t160 = mul i8 %t158, %t159
  %t161 = add i8 %t160, 17
  %t162 = extractvalue %hia.buffer %p_25_2, 0
  %t163 = extractvalue %hia.buffer %p_25_2, 1
  %t164 = icmp ult i64 %p_25_4, %t163
  br i1 %t164, label %ok_165, label %trap_165
trap_165:
  call void @abort()
  unreachable
ok_165:
  %t166 = getelementptr i8, ptr %t162, i64 %p_25_4
  store i8 %t161, ptr %t166, align 1
  %t167 = add i64 %p_25_4, 1
  br label %edge_31
b26:
  %p_26_0 = phi i64 [ %p_24_0, %edge_30 ]
  %p_26_1 = phi i32 [ %p_24_1, %edge_30 ]
  %p_26_2 = phi %hia.buffer [ %p_24_2, %edge_30 ]
  %p_26_3 = phi i64 [ %p_24_3, %edge_30 ]
  %p_26_4 = phi i64 [ %p_24_4, %edge_30 ]
  br label %edge_32
b27:
  %p_27_0 = phi i64 [ %p_26_0, %edge_32 ], [ %p_28_0, %edge_35 ]
  %p_27_1 = phi i32 [ %p_26_1, %edge_32 ], [ %p_28_1, %edge_35 ]
  %p_27_2 = phi %hia.buffer [ %p_26_2, %edge_32 ], [ %p_28_2, %edge_35 ]
  %p_27_3 = phi i64 [ 0, %edge_32 ], [ %t175, %edge_35 ]
  %p_27_4 = phi i64 [ %p_26_0, %edge_32 ], [ %p_28_4, %edge_35 ]
  %p_27_5 = phi i64 [ 0, %edge_32 ], [ %t174, %edge_35 ]
  %t168 = icmp ult i64 %p_27_5, %p_27_4
  br i1 %t168, label %edge_33, label %edge_34
b28:
  %p_28_0 = phi i64 [ %p_27_0, %edge_33 ]
  %p_28_1 = phi i32 [ %p_27_1, %edge_33 ]
  %p_28_2 = phi %hia.buffer [ %p_27_2, %edge_33 ]
  %p_28_3 = phi i64 [ %p_27_3, %edge_33 ]
  %p_28_4 = phi i64 [ %p_27_4, %edge_33 ]
  %p_28_5 = phi i64 [ %p_27_5, %edge_33 ]
  %t169 = extractvalue %hia.buffer %p_28_2, 0
  %t170 = extractvalue %hia.buffer %p_28_2, 1
  br label %byte_sum_start_171
byte_sum_start_171:
  br label %byte_sum_vector_head_171
byte_sum_vector_head_171:
  %t172 = phi i64 [ %p_28_5, %byte_sum_start_171 ], [ %t183, %byte_sum_vector_body_171 ]
  %t173 = phi i64 [ %p_28_3, %byte_sum_start_171 ], [ %t182, %byte_sum_vector_body_171 ]
  %t201 = icmp ule i64 %t172, %p_28_4
  %t202 = sub i64 %p_28_4, %t172
  %t203 = icmp uge i64 %t202, 16
  %t204 = and i1 %t201, %t203
  %t205 = icmp ule i64 %t172, %t170
  %t206 = sub i64 %t170, %t172
  %t207 = icmp uge i64 %t206, 16
  %t208 = and i1 %t205, %t207
  %t209 = and i1 %t204, %t208
  br i1 %t209, label %byte_sum_vector_body_171, label %byte_sum_half_head_171
byte_sum_vector_body_171:
  %t176 = getelementptr i8, ptr %t169, i64 %t172
  %t177 = load <16 x i8>, ptr %t176, align 1
  %t178 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t177, <16 x i8> zeroinitializer)
  %t179 = extractelement <2 x i64> %t178, i32 0
  %t180 = extractelement <2 x i64> %t178, i32 1
  %t181 = add i64 %t179, %t180
  %t182 = add i64 %t173, %t181
  %t183 = add i64 %t172, 16
  br label %byte_sum_vector_head_171
byte_sum_half_head_171:
  %t210 = icmp ule i64 %t172, %p_28_4
  %t211 = sub i64 %p_28_4, %t172
  %t212 = icmp uge i64 %t211, 8
  %t213 = and i1 %t210, %t212
  %t214 = icmp ule i64 %t172, %t170
  %t215 = sub i64 %t170, %t172
  %t216 = icmp uge i64 %t215, 8
  %t217 = and i1 %t214, %t216
  %t218 = and i1 %t213, %t217
  br i1 %t218, label %byte_sum_half_body_171, label %byte_sum_scalar_head_171
byte_sum_half_body_171:
  %t184 = getelementptr i8, ptr %t169, i64 %t172
  %t185 = load i64, ptr %t184, align 1
  %t186 = insertelement <2 x i64> zeroinitializer, i64 %t185, i32 0
  %t187 = bitcast <2 x i64> %t186 to <16 x i8>
  %t188 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t187, <16 x i8> zeroinitializer)
  %t189 = extractelement <2 x i64> %t188, i32 0
  %t190 = add i64 %t173, %t189
  %t191 = add i64 %t172, 8
  br label %byte_sum_scalar_head_171
byte_sum_scalar_head_171:
  %t174 = phi i64 [ %t172, %byte_sum_half_head_171 ], [ %t191, %byte_sum_half_body_171 ], [ %t200, %byte_sum_scalar_done_171 ]
  %t175 = phi i64 [ %t173, %byte_sum_half_head_171 ], [ %t190, %byte_sum_half_body_171 ], [ %t199, %byte_sum_scalar_done_171 ]
  %t219 = icmp ult i64 %t174, %p_28_4
  br i1 %t219, label %byte_sum_scalar_body_171, label %byte_sum_finished_171
byte_sum_scalar_body_171:
  %t192 = extractvalue %hia.buffer %p_28_2, 0
  %t193 = extractvalue %hia.buffer %p_28_2, 1
  %t194 = icmp ult i64 %t174, %t193
  br i1 %t194, label %ok_195, label %trap_195
trap_195:
  call void @abort()
  unreachable
ok_195:
  %t196 = getelementptr i8, ptr %t192, i64 %t174
  %t197 = load i8, ptr %t196, align 1
  %t198 = zext i8 %t197 to i64
  %t199 = add i64 %t175, %t198
  %t200 = add i64 %t174, 1
  br label %byte_sum_scalar_done_171
byte_sum_scalar_done_171:
  br label %byte_sum_scalar_head_171
byte_sum_finished_171:
  br label %edge_35
b29:
  %p_29_0 = phi i64 [ %p_27_0, %edge_34 ]
  %p_29_1 = phi i32 [ %p_27_1, %edge_34 ]
  %p_29_2 = phi %hia.buffer [ %p_27_2, %edge_34 ]
  %p_29_3 = phi i64 [ %p_27_3, %edge_34 ]
  %p_29_4 = phi i64 [ %p_27_4, %edge_34 ]
  %p_29_5 = phi i64 [ %p_27_5, %edge_34 ]
  %t220 = extractvalue %hia.buffer %p_29_2, 0
  %t221 = icmp ne ptr %t220, null
  br i1 %t221, label %drop_nonnull_222, label %drop_after_222
drop_nonnull_222:
  call void @free(ptr %t220) nobuiltin
  br label %drop_after_222
drop_after_222:
  ret i64 %p_29_3
b30:
  %p_30_0 = phi i64 [ %p_20_0, %edge_25 ]
  %p_30_1 = phi i32 [ %p_20_1, %edge_25 ]
  %t223 = call %hia.alloc @__hia_allocate(i64 %p_30_0, i1 false)
  %t224 = extractvalue %hia.alloc %t223, 0
  %t225 = extractvalue %hia.alloc %t223, 1
  %t226 = select i1 %t225, i64 %p_30_0, i64 0
  %t227 = insertvalue %hia.buffer %t224, i64 %t226, 1
  br i1 %t225, label %edge_36, label %edge_37
b31:
  %p_31_0 = phi i64 [ %p_30_0, %edge_36 ]
  %p_31_1 = phi i32 [ %p_30_1, %edge_36 ]
  %p_31_2 = phi i1 [ %t225, %edge_36 ]
  %p_31_3 = phi %hia.buffer [ %t227, %edge_36 ]
  %p_31_4 = phi i8 [ 1, %edge_36 ]
  br label %edge_38
b32:
  %p_32_0 = phi i64 [ %p_30_0, %edge_37 ]
  %p_32_1 = phi i32 [ %p_30_1, %edge_37 ]
  %p_32_2 = phi i1 [ %t225, %edge_37 ]
  %p_32_3 = phi %hia.buffer [ %t227, %edge_37 ]
  %p_32_4 = phi i8 [ 1, %edge_37 ]
  %t228 = extractvalue %hia.buffer %p_32_3, 0
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %drop_nonnull_230, label %drop_after_230
drop_nonnull_230:
  call void @free(ptr %t228) nobuiltin
  br label %drop_after_230
drop_after_230:
  %t231 = zext i8 %p_32_4 to i64
  %t232 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t231)
  %t233 = extractvalue { i64, i1 } %t232, 0
  %t234 = extractvalue { i64, i1 } %t232, 1
  %t235 = xor i1 %t234, true
  br i1 %t235, label %ok_236, label %trap_236
trap_236:
  call void @abort()
  unreachable
ok_236:
  ret i64 %t233
b33:
  %p_33_0 = phi i64 [ %p_31_0, %edge_38 ], [ %p_34_0, %edge_41 ]
  %p_33_1 = phi i32 [ %p_31_1, %edge_38 ], [ %p_34_1, %edge_41 ]
  %p_33_2 = phi %hia.buffer [ %p_31_3, %edge_38 ], [ %p_34_2, %edge_41 ]
  %p_33_3 = phi i64 [ %p_31_0, %edge_38 ], [ %p_34_3, %edge_41 ]
  %p_33_4 = phi i64 [ 0, %edge_38 ], [ %t251, %edge_41 ]
  %t237 = icmp ult i64 %p_33_4, %p_33_3
  br i1 %t237, label %edge_39, label %edge_40
b34:
  %p_34_0 = phi i64 [ %p_33_0, %edge_39 ]
  %p_34_1 = phi i32 [ %p_33_1, %edge_39 ]
  %p_34_2 = phi %hia.buffer [ %p_33_2, %edge_39 ]
  %p_34_3 = phi i64 [ %p_33_3, %edge_39 ]
  %p_34_4 = phi i64 [ %p_33_4, %edge_39 ]
  %t238 = trunc i64 %p_34_4 to i32
  %t239 = mul i32 %t238, %p_34_1
  %t240 = add i32 %t239, 17
  %t241 = trunc i64 %p_34_4 to i8
  %t242 = trunc i32 %p_34_1 to i8
  %t243 = mul i8 %t241, %t242
  %t244 = add i8 %t243, 17
  %t245 = extractvalue %hia.buffer %p_34_2, 0
  %t246 = extractvalue %hia.buffer %p_34_2, 1
  %t247 = icmp ult i64 %p_34_4, %t246
  br i1 %t247, label %ok_248, label %trap_248
trap_248:
  call void @abort()
  unreachable
ok_248:
  %t249 = getelementptr i8, ptr %t245, i64 %p_34_4
  store i8 %t244, ptr %t249, align 1
  %t250 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_34_4, i64 1)
  %t251 = extractvalue { i64, i1 } %t250, 0
  %t252 = extractvalue { i64, i1 } %t250, 1
  %t253 = xor i1 %t252, true
  br i1 %t253, label %ok_254, label %trap_254
trap_254:
  call void @abort()
  unreachable
ok_254:
  br label %edge_41
b35:
  %p_35_0 = phi i64 [ %p_33_0, %edge_40 ]
  %p_35_1 = phi i32 [ %p_33_1, %edge_40 ]
  %p_35_2 = phi %hia.buffer [ %p_33_2, %edge_40 ]
  %p_35_3 = phi i64 [ %p_33_3, %edge_40 ]
  %p_35_4 = phi i64 [ %p_33_4, %edge_40 ]
  br label %edge_42
b36:
  %p_36_0 = phi i64 [ %p_35_0, %edge_42 ], [ %p_37_0, %edge_45 ]
  %p_36_1 = phi i32 [ %p_35_1, %edge_42 ], [ %p_37_1, %edge_45 ]
  %p_36_2 = phi %hia.buffer [ %p_35_2, %edge_42 ], [ %p_37_2, %edge_45 ]
  %p_36_3 = phi i64 [ 0, %edge_42 ], [ %t264, %edge_45 ]
  %p_36_4 = phi i64 [ %p_35_0, %edge_42 ], [ %p_37_4, %edge_45 ]
  %p_36_5 = phi i64 [ 0, %edge_42 ], [ %t269, %edge_45 ]
  %t255 = icmp ult i64 %p_36_5, %p_36_4
  br i1 %t255, label %edge_43, label %edge_44
b37:
  %p_37_0 = phi i64 [ %p_36_0, %edge_43 ]
  %p_37_1 = phi i32 [ %p_36_1, %edge_43 ]
  %p_37_2 = phi %hia.buffer [ %p_36_2, %edge_43 ]
  %p_37_3 = phi i64 [ %p_36_3, %edge_43 ]
  %p_37_4 = phi i64 [ %p_36_4, %edge_43 ]
  %p_37_5 = phi i64 [ %p_36_5, %edge_43 ]
  %t256 = extractvalue %hia.buffer %p_37_2, 0
  %t257 = extractvalue %hia.buffer %p_37_2, 1
  %t258 = icmp ult i64 %p_37_5, %t257
  br i1 %t258, label %ok_259, label %trap_259
trap_259:
  call void @abort()
  unreachable
ok_259:
  %t260 = getelementptr i8, ptr %t256, i64 %p_37_5
  %t261 = load i8, ptr %t260, align 1
  %t262 = zext i8 %t261 to i64
  %t263 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_37_3, i64 %t262)
  %t264 = extractvalue { i64, i1 } %t263, 0
  %t265 = extractvalue { i64, i1 } %t263, 1
  %t266 = xor i1 %t265, true
  br i1 %t266, label %ok_267, label %trap_267
trap_267:
  call void @abort()
  unreachable
ok_267:
  %t268 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_37_5, i64 1)
  %t269 = extractvalue { i64, i1 } %t268, 0
  %t270 = extractvalue { i64, i1 } %t268, 1
  %t271 = xor i1 %t270, true
  br i1 %t271, label %ok_272, label %trap_272
trap_272:
  call void @abort()
  unreachable
ok_272:
  br label %edge_45
b38:
  %p_38_0 = phi i64 [ %p_36_0, %edge_44 ]
  %p_38_1 = phi i32 [ %p_36_1, %edge_44 ]
  %p_38_2 = phi %hia.buffer [ %p_36_2, %edge_44 ]
  %p_38_3 = phi i64 [ %p_36_3, %edge_44 ]
  %p_38_4 = phi i64 [ %p_36_4, %edge_44 ]
  %p_38_5 = phi i64 [ %p_36_5, %edge_44 ]
  %t273 = extractvalue %hia.buffer %p_38_2, 0
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %drop_nonnull_275, label %drop_after_275
drop_nonnull_275:
  call void @free(ptr %t273) nobuiltin
  br label %drop_after_275
drop_after_275:
  ret i64 %p_38_3
edge_0:
  br label %b20
edge_1:
  br label %b1
edge_2:
  br label %b2
edge_3:
  br label %b11
edge_4:
  br label %b3
edge_5:
  br label %b4
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b7
edge_9:
  br label %b5
edge_10:
  br label %b8
edge_11:
  br label %b9
edge_12:
  br label %b10
edge_13:
  br label %b8
edge_14:
  br label %b12
edge_15:
  br label %b13
edge_16:
  br label %b14
edge_17:
  br label %b15
edge_18:
  br label %b16
edge_19:
  br label %b14
edge_20:
  br label %b17
edge_21:
  br label %b18
edge_22:
  br label %b19
edge_23:
  br label %b17
edge_24:
  br label %b21
edge_25:
  br label %b30
edge_26:
  br label %b22
edge_27:
  br label %b23
edge_28:
  br label %b24
edge_29:
  br label %b25
edge_30:
  br label %b26
edge_31:
  br label %b24
edge_32:
  br label %b27
edge_33:
  br label %b28
edge_34:
  br label %b29
edge_35:
  br label %b27
edge_36:
  br label %b31
edge_37:
  br label %b32
edge_38:
  br label %b33
edge_39:
  br label %b34
edge_40:
  br label %b35
edge_41:
  br label %b33
edge_42:
  br label %b36
edge_43:
  br label %b37
edge_44:
  br label %b38
edge_45:
  br label %b36
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %is_empty = icmp eq i64 %a0, 0
  br i1 %is_empty, label %zero, label %ordinary
zero:
  %zero_result = call i64 @__hia_fn_0(i64 0, i32 %a1) alwaysinline
  ret i64 %zero_result
ordinary:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1) noinline
  ret i64 %result
}
