; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8>, <16 x i8>)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ule i64 %p_0_0, 72340172838076673
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 %p_1_0, i1 false)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 %p_1_0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_2_2 = phi i1 [ %t4, %edge_2 ]
  %p_2_3 = phi %hia.buffer [ %t6, %edge_2 ]
  %p_2_4 = phi i8 [ 1, %edge_2 ]
  br label %edge_4
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_3_2 = phi i1 [ %t4, %edge_3 ]
  %p_3_3 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_3_4 = phi i8 [ 1, %edge_3 ]
  %t7 = extractvalue %hia.buffer %p_3_3, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  %t10 = zext i8 %p_3_4 to i64
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t10)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  ret i64 %t12
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_0, %edge_7 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_4 ], [ %p_5_1, %edge_7 ]
  %p_4_2 = phi %hia.buffer [ %p_2_3, %edge_4 ], [ %p_5_2, %edge_7 ]
  %p_4_3 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_3, %edge_7 ]
  %p_4_4 = phi i64 [ 0, %edge_4 ], [ %t29, %edge_7 ]
  %t16 = icmp ult i64 %p_4_4, %p_4_3
  br i1 %t16, label %edge_5, label %edge_6
b5:
  %p_5_0 = phi i64 [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_5 ]
  %p_5_2 = phi %hia.buffer [ %p_4_2, %edge_5 ]
  %p_5_3 = phi i64 [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i64 [ %p_4_4, %edge_5 ]
  %t17 = trunc i64 %p_5_4 to i32
  %t18 = mul i32 %t17, %p_5_1
  %t19 = add i32 %t18, 17
  %t20 = trunc i64 %p_5_4 to i8
  %t21 = trunc i32 %p_5_1 to i8
  %t22 = mul i8 %t20, %t21
  %t23 = add i8 %t22, 17
  %t24 = extractvalue %hia.buffer %p_5_2, 0
  %t25 = extractvalue %hia.buffer %p_5_2, 1
  %t26 = icmp ult i64 %p_5_4, %t25
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  %t28 = getelementptr i8, ptr %t24, i64 %p_5_4
  store i8 %t23, ptr %t28, align 1
  %t29 = add i64 %p_5_4, 1
  br label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_6 ]
  %p_6_2 = phi %hia.buffer [ %p_4_2, %edge_6 ]
  %p_6_3 = phi i64 [ %p_4_3, %edge_6 ]
  %p_6_4 = phi i64 [ %p_4_4, %edge_6 ]
  br label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_8 ], [ %p_8_0, %edge_11 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_8 ], [ %p_8_1, %edge_11 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_8 ], [ %p_8_2, %edge_11 ]
  %p_7_3 = phi i64 [ 0, %edge_8 ], [ %t37, %edge_11 ]
  %p_7_4 = phi i64 [ %p_6_0, %edge_8 ], [ %p_8_4, %edge_11 ]
  %p_7_5 = phi i64 [ 0, %edge_8 ], [ %t36, %edge_11 ]
  %t30 = icmp ult i64 %p_7_5, %p_7_4
  br i1 %t30, label %edge_9, label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_9 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_9 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_9 ]
  %p_8_3 = phi i64 [ %p_7_3, %edge_9 ]
  %p_8_4 = phi i64 [ %p_7_4, %edge_9 ]
  %p_8_5 = phi i64 [ %p_7_5, %edge_9 ]
  %t31 = extractvalue %hia.buffer %p_8_2, 0
  %t32 = extractvalue %hia.buffer %p_8_2, 1
  br label %byte_sum_start_33
byte_sum_start_33:
  br label %byte_sum_vector_head_33
byte_sum_vector_head_33:
  %t34 = phi i64 [ %p_8_5, %byte_sum_start_33 ], [ %t45, %byte_sum_vector_body_33 ]
  %t35 = phi i64 [ %p_8_3, %byte_sum_start_33 ], [ %t44, %byte_sum_vector_body_33 ]
  %t63 = icmp ule i64 %t34, %p_8_4
  %t64 = sub i64 %p_8_4, %t34
  %t65 = icmp uge i64 %t64, 16
  %t66 = and i1 %t63, %t65
  %t67 = icmp ule i64 %t34, %t32
  %t68 = sub i64 %t32, %t34
  %t69 = icmp uge i64 %t68, 16
  %t70 = and i1 %t67, %t69
  %t71 = and i1 %t66, %t70
  br i1 %t71, label %byte_sum_vector_body_33, label %byte_sum_half_head_33
byte_sum_vector_body_33:
  %t38 = getelementptr i8, ptr %t31, i64 %t34
  %t39 = load <16 x i8>, ptr %t38, align 1
  %t40 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t39, <16 x i8> zeroinitializer)
  %t41 = extractelement <2 x i64> %t40, i32 0
  %t42 = extractelement <2 x i64> %t40, i32 1
  %t43 = add i64 %t41, %t42
  %t44 = add i64 %t35, %t43
  %t45 = add i64 %t34, 16
  br label %byte_sum_vector_head_33
byte_sum_half_head_33:
  %t72 = icmp ule i64 %t34, %p_8_4
  %t73 = sub i64 %p_8_4, %t34
  %t74 = icmp uge i64 %t73, 8
  %t75 = and i1 %t72, %t74
  %t76 = icmp ule i64 %t34, %t32
  %t77 = sub i64 %t32, %t34
  %t78 = icmp uge i64 %t77, 8
  %t79 = and i1 %t76, %t78
  %t80 = and i1 %t75, %t79
  br i1 %t80, label %byte_sum_half_body_33, label %byte_sum_scalar_head_33
byte_sum_half_body_33:
  %t46 = getelementptr i8, ptr %t31, i64 %t34
  %t47 = load i64, ptr %t46, align 1
  %t48 = insertelement <2 x i64> zeroinitializer, i64 %t47, i32 0
  %t49 = bitcast <2 x i64> %t48 to <16 x i8>
  %t50 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t49, <16 x i8> zeroinitializer)
  %t51 = extractelement <2 x i64> %t50, i32 0
  %t52 = add i64 %t35, %t51
  %t53 = add i64 %t34, 8
  br label %byte_sum_scalar_head_33
byte_sum_scalar_head_33:
  %t36 = phi i64 [ %t34, %byte_sum_half_head_33 ], [ %t53, %byte_sum_half_body_33 ], [ %t62, %byte_sum_scalar_done_33 ]
  %t37 = phi i64 [ %t35, %byte_sum_half_head_33 ], [ %t52, %byte_sum_half_body_33 ], [ %t61, %byte_sum_scalar_done_33 ]
  %t81 = icmp ult i64 %t36, %p_8_4
  br i1 %t81, label %byte_sum_scalar_body_33, label %byte_sum_finished_33
byte_sum_scalar_body_33:
  %t54 = extractvalue %hia.buffer %p_8_2, 0
  %t55 = extractvalue %hia.buffer %p_8_2, 1
  %t56 = icmp ult i64 %t36, %t55
  br i1 %t56, label %ok_57, label %trap_57
trap_57:
  call void @abort()
  unreachable
ok_57:
  %t58 = getelementptr i8, ptr %t54, i64 %t36
  %t59 = load i8, ptr %t58, align 1
  %t60 = zext i8 %t59 to i64
  %t61 = add i64 %t37, %t60
  %t62 = add i64 %t36, 1
  br label %byte_sum_scalar_done_33
byte_sum_scalar_done_33:
  br label %byte_sum_scalar_head_33
byte_sum_finished_33:
  br label %edge_11
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_10 ]
  %p_9_1 = phi i32 [ %p_7_1, %edge_10 ]
  %p_9_2 = phi %hia.buffer [ %p_7_2, %edge_10 ]
  %p_9_3 = phi i64 [ %p_7_3, %edge_10 ]
  %p_9_4 = phi i64 [ %p_7_4, %edge_10 ]
  %p_9_5 = phi i64 [ %p_7_5, %edge_10 ]
  %t82 = extractvalue %hia.buffer %p_9_2, 0
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %drop_nonnull_84, label %drop_after_84
drop_nonnull_84:
  call void @free(ptr %t82) nobuiltin
  br label %drop_after_84
drop_after_84:
  ret i64 %p_9_3
b10:
  %p_10_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_10_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t85 = call %hia.alloc @__hia_allocate(i64 %p_10_0, i1 false)
  %t86 = extractvalue %hia.alloc %t85, 0
  %t87 = extractvalue %hia.alloc %t85, 1
  %t88 = select i1 %t87, i64 %p_10_0, i64 0
  %t89 = insertvalue %hia.buffer %t86, i64 %t88, 1
  br i1 %t87, label %edge_12, label %edge_13
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_12 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ]
  %p_11_2 = phi i1 [ %t87, %edge_12 ]
  %p_11_3 = phi %hia.buffer [ %t89, %edge_12 ]
  %p_11_4 = phi i8 [ 1, %edge_12 ]
  br label %edge_14
b12:
  %p_12_0 = phi i64 [ %p_10_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_10_1, %edge_13 ]
  %p_12_2 = phi i1 [ %t87, %edge_13 ]
  %p_12_3 = phi %hia.buffer [ %t89, %edge_13 ]
  %p_12_4 = phi i8 [ 1, %edge_13 ]
  %t90 = extractvalue %hia.buffer %p_12_3, 0
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %drop_nonnull_92, label %drop_after_92
drop_nonnull_92:
  call void @free(ptr %t90) nobuiltin
  br label %drop_after_92
drop_after_92:
  %t93 = zext i8 %p_12_4 to i64
  %t94 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t93)
  %t95 = extractvalue { i64, i1 } %t94, 0
  %t96 = extractvalue { i64, i1 } %t94, 1
  %t97 = xor i1 %t96, true
  br i1 %t97, label %ok_98, label %trap_98
trap_98:
  call void @abort()
  unreachable
ok_98:
  ret i64 %t95
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_14 ], [ %p_14_0, %edge_17 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ], [ %p_14_1, %edge_17 ]
  %p_13_2 = phi %hia.buffer [ %p_11_3, %edge_14 ], [ %p_14_2, %edge_17 ]
  %p_13_3 = phi i64 [ %p_11_0, %edge_14 ], [ %p_14_3, %edge_17 ]
  %p_13_4 = phi i64 [ 0, %edge_14 ], [ %t113, %edge_17 ]
  %t99 = icmp ult i64 %p_13_4, %p_13_3
  br i1 %t99, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_14_1 = phi i32 [ %p_13_1, %edge_15 ]
  %p_14_2 = phi %hia.buffer [ %p_13_2, %edge_15 ]
  %p_14_3 = phi i64 [ %p_13_3, %edge_15 ]
  %p_14_4 = phi i64 [ %p_13_4, %edge_15 ]
  %t100 = trunc i64 %p_14_4 to i32
  %t101 = mul i32 %t100, %p_14_1
  %t102 = add i32 %t101, 17
  %t103 = trunc i64 %p_14_4 to i8
  %t104 = trunc i32 %p_14_1 to i8
  %t105 = mul i8 %t103, %t104
  %t106 = add i8 %t105, 17
  %t107 = extractvalue %hia.buffer %p_14_2, 0
  %t108 = extractvalue %hia.buffer %p_14_2, 1
  %t109 = icmp ult i64 %p_14_4, %t108
  br i1 %t109, label %ok_110, label %trap_110
trap_110:
  call void @abort()
  unreachable
ok_110:
  %t111 = getelementptr i8, ptr %t107, i64 %p_14_4
  store i8 %t106, ptr %t111, align 1
  %t112 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_14_4, i64 1)
  %t113 = extractvalue { i64, i1 } %t112, 0
  %t114 = extractvalue { i64, i1 } %t112, 1
  %t115 = xor i1 %t114, true
  br i1 %t115, label %ok_116, label %trap_116
trap_116:
  call void @abort()
  unreachable
ok_116:
  br label %edge_17
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i32 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi %hia.buffer [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i64 [ %p_13_3, %edge_16 ]
  %p_15_4 = phi i64 [ %p_13_4, %edge_16 ]
  br label %edge_18
b16:
  %p_16_0 = phi i64 [ %p_15_0, %edge_18 ], [ %p_17_0, %edge_21 ]
  %p_16_1 = phi i32 [ %p_15_1, %edge_18 ], [ %p_17_1, %edge_21 ]
  %p_16_2 = phi %hia.buffer [ %p_15_2, %edge_18 ], [ %p_17_2, %edge_21 ]
  %p_16_3 = phi i64 [ 0, %edge_18 ], [ %t126, %edge_21 ]
  %p_16_4 = phi i64 [ %p_15_0, %edge_18 ], [ %p_17_4, %edge_21 ]
  %p_16_5 = phi i64 [ 0, %edge_18 ], [ %t131, %edge_21 ]
  %t117 = icmp ult i64 %p_16_5, %p_16_4
  br i1 %t117, label %edge_19, label %edge_20
b17:
  %p_17_0 = phi i64 [ %p_16_0, %edge_19 ]
  %p_17_1 = phi i32 [ %p_16_1, %edge_19 ]
  %p_17_2 = phi %hia.buffer [ %p_16_2, %edge_19 ]
  %p_17_3 = phi i64 [ %p_16_3, %edge_19 ]
  %p_17_4 = phi i64 [ %p_16_4, %edge_19 ]
  %p_17_5 = phi i64 [ %p_16_5, %edge_19 ]
  %t118 = extractvalue %hia.buffer %p_17_2, 0
  %t119 = extractvalue %hia.buffer %p_17_2, 1
  %t120 = icmp ult i64 %p_17_5, %t119
  br i1 %t120, label %ok_121, label %trap_121
trap_121:
  call void @abort()
  unreachable
ok_121:
  %t122 = getelementptr i8, ptr %t118, i64 %p_17_5
  %t123 = load i8, ptr %t122, align 1
  %t124 = zext i8 %t123 to i64
  %t125 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_17_3, i64 %t124)
  %t126 = extractvalue { i64, i1 } %t125, 0
  %t127 = extractvalue { i64, i1 } %t125, 1
  %t128 = xor i1 %t127, true
  br i1 %t128, label %ok_129, label %trap_129
trap_129:
  call void @abort()
  unreachable
ok_129:
  %t130 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_17_5, i64 1)
  %t131 = extractvalue { i64, i1 } %t130, 0
  %t132 = extractvalue { i64, i1 } %t130, 1
  %t133 = xor i1 %t132, true
  br i1 %t133, label %ok_134, label %trap_134
trap_134:
  call void @abort()
  unreachable
ok_134:
  br label %edge_21
b18:
  %p_18_0 = phi i64 [ %p_16_0, %edge_20 ]
  %p_18_1 = phi i32 [ %p_16_1, %edge_20 ]
  %p_18_2 = phi %hia.buffer [ %p_16_2, %edge_20 ]
  %p_18_3 = phi i64 [ %p_16_3, %edge_20 ]
  %p_18_4 = phi i64 [ %p_16_4, %edge_20 ]
  %p_18_5 = phi i64 [ %p_16_5, %edge_20 ]
  %t135 = extractvalue %hia.buffer %p_18_2, 0
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %drop_nonnull_137, label %drop_after_137
drop_nonnull_137:
  call void @free(ptr %t135) nobuiltin
  br label %drop_after_137
drop_after_137:
  ret i64 %p_18_3
edge_0:
  br label %b1
edge_1:
  br label %b10
edge_2:
  br label %b2
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b4
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b9
edge_11:
  br label %b7
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b13
edge_18:
  br label %b16
edge_19:
  br label %b17
edge_20:
  br label %b18
edge_21:
  br label %b16
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
