
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/outlined-aot/linear/hia_empty_candidate.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000015a0 <calculate>:
    15a0:	48 85 ff             	test   %rdi,%rdi
    15a3:	0f 85 07 fc ff ff    	jne    11b0 <__hia_fn_0>
    15a9:	31 c0                	xor    %eax,%eax
    15ab:	c3                   	ret

Disassembly of section .fini:
