
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/outlined-aot/linear/hia_guarded_outline.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000001560 <calculate>:
    1560:	48 85 ff             	test   %rdi,%rdi
    1563:	75 03                	jne    1568 <calculate+0x8>
    1565:	31 c0                	xor    %eax,%eax
    1567:	c3                   	ret
    1568:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
    156f:	01 01 01 
    1572:	48 39 c7             	cmp    %rax,%rdi
    1575:	0f 86 35 fc ff ff    	jbe    11b0 <__hia_fn_1>
    157b:	e9 90 fe ff ff       	jmp    1410 <__hia_fn_2>

Disassembly of section .fini:
