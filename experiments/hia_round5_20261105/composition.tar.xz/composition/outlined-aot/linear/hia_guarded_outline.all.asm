
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/outlined-aot/linear/hia_guarded_outline.o：     文件格式 elf64-x86-64


Disassembly of section .text:

0000000000000000 <__hia_fn_1>:
   0:	55                   	push   %rbp
   1:	41 56                	push   %r14
   3:	53                   	push   %rbx
   4:	48 85 ff             	test   %rdi,%rdi
   7:	74 1c                	je     25 <__hia_fn_1+0x25>
   9:	89 f5                	mov    %esi,%ebp
   b:	48 89 fb             	mov    %rdi,%rbx
   e:	e8 00 00 00 00       	call   13 <__hia_fn_1+0x13>
			f: R_X86_64_PLT32	malloc-0x4
  13:	48 85 c0             	test   %rax,%rax
  16:	74 17                	je     2f <__hia_fn_1+0x2f>
  18:	48 83 fb 03          	cmp    $0x3,%rbx
  1c:	77 1c                	ja     3a <__hia_fn_1+0x3a>
  1e:	31 c9                	xor    %ecx,%ecx
  20:	e9 da 00 00 00       	jmp    ff <__hia_fn_1+0xff>
  25:	31 c0                	xor    %eax,%eax
  27:	45 31 f6             	xor    %r14d,%r14d
  2a:	e9 1c 02 00 00       	jmp    24b <__hia_fn_1+0x24b>
  2f:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
  35:	e9 1e 02 00 00       	jmp    258 <__hia_fn_1+0x258>
  3a:	48 be f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rsi
  41:	ff ff 01 
  44:	40 0f b6 d5          	movzbl %bpl,%edx
  48:	48 83 fb 10          	cmp    $0x10,%rbx
  4c:	73 04                	jae    52 <__hia_fn_1+0x52>
  4e:	31 c9                	xor    %ecx,%ecx
  50:	eb 56                	jmp    a8 <__hia_fn_1+0xa8>
  52:	48 89 d9             	mov    %rbx,%rcx
  55:	48 21 f1             	and    %rsi,%rcx
  58:	66 0f 6e c2          	movd   %edx,%xmm0
  5c:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  60:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  65:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
  6a:	66 0f 6f 0d 00 00 00 	movdqa 0x0(%rip),%xmm1        # 72 <__hia_fn_1+0x72>
  71:	00 
			6e: R_X86_64_PC32	.LCPI0_0-0x4
  72:	31 ff                	xor    %edi,%edi
  74:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 7c <__hia_fn_1+0x7c>
  7b:	00 
			78: R_X86_64_PC32	.LCPI0_1-0x4
  7c:	0f 1f 40 00          	nopl   0x0(%rax)
  80:	66 0f 6f d9          	movdqa %xmm1,%xmm3
  84:	66 0f fc d8          	paddb  %xmm0,%xmm3
  88:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
  8d:	48 83 c7 10          	add    $0x10,%rdi
  91:	66 0f fc ca          	paddb  %xmm2,%xmm1
  95:	48 39 f9             	cmp    %rdi,%rcx
  98:	75 e6                	jne    80 <__hia_fn_1+0x80>
  9a:	48 39 cb             	cmp    %rcx,%rbx
  9d:	0f 84 7c 00 00 00    	je     11f <__hia_fn_1+0x11f>
  a3:	f6 c3 0c             	test   $0xc,%bl
  a6:	74 57                	je     ff <__hia_fn_1+0xff>
  a8:	48 89 cf             	mov    %rcx,%rdi
  ab:	48 83 c6 0c          	add    $0xc,%rsi
  af:	48 89 f1             	mov    %rsi,%rcx
  b2:	48 21 d9             	and    %rbx,%rcx
  b5:	66 0f 6e c7          	movd   %edi,%xmm0
  b9:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  bd:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  c2:	66 0f eb 05 00 00 00 	por    0x0(%rip),%xmm0        # ca <__hia_fn_1+0xca>
  c9:	00 
			c6: R_X86_64_PC32	.LCPI0_2-0x4
  ca:	66 0f 6e ca          	movd   %edx,%xmm1
  ce:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
  d2:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
  d7:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # df <__hia_fn_1+0xdf>
  de:	00 
			db: R_X86_64_PC32	.LCPI0_3-0x4
  df:	90                   	nop
  e0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
  e4:	66 0f fc d9          	paddb  %xmm1,%xmm3
  e8:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
  ed:	48 83 c7 04          	add    $0x4,%rdi
  f1:	66 0f fc c2          	paddb  %xmm2,%xmm0
  f5:	48 39 f9             	cmp    %rdi,%rcx
  f8:	75 e6                	jne    e0 <__hia_fn_1+0xe0>
  fa:	48 39 cb             	cmp    %rcx,%rbx
  fd:	74 20                	je     11f <__hia_fn_1+0x11f>
  ff:	89 ea                	mov    %ebp,%edx
 101:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 108:	0f 1f 84 00 00 00 00 
 10f:	00 
 110:	8d 34 0a             	lea    (%rdx,%rcx,1),%esi
 113:	40 88 34 08          	mov    %sil,(%rax,%rcx,1)
 117:	48 ff c1             	inc    %rcx
 11a:	48 39 cb             	cmp    %rcx,%rbx
 11d:	75 f1                	jne    110 <__hia_fn_1+0x110>
 11f:	48 83 fb 10          	cmp    $0x10,%rbx
 123:	72 68                	jb     18d <__hia_fn_1+0x18d>
 125:	b9 10 00 00 00       	mov    $0x10,%ecx
 12a:	45 31 f6             	xor    %r14d,%r14d
 12d:	66 0f ef c0          	pxor   %xmm0,%xmm0
 131:	48 89 da             	mov    %rbx,%rdx
 134:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 13b:	00 00 00 00 00 
 140:	48 89 ce             	mov    %rcx,%rsi
 143:	f3 0f 6f 4c 08 f0    	movdqu -0x10(%rax,%rcx,1),%xmm1
 149:	66 0f f6 c8          	psadbw %xmm0,%xmm1
 14d:	66 48 0f 7e c9       	movq   %xmm1,%rcx
 152:	4c 01 f1             	add    %r14,%rcx
 155:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
 15a:	66 49 0f 7e ce       	movq   %xmm1,%r14
 15f:	49 01 ce             	add    %rcx,%r14
 162:	48 83 c2 f0          	add    $0xfffffffffffffff0,%rdx
 166:	48 8d 4e 10          	lea    0x10(%rsi),%rcx
 16a:	48 39 de             	cmp    %rbx,%rsi
 16d:	40 0f 96 c6          	setbe  %sil
 171:	77 08                	ja     17b <__hia_fn_1+0x17b>
 173:	48 83 fa 10          	cmp    $0x10,%rdx
 177:	72 02                	jb     17b <__hia_fn_1+0x17b>
 179:	73 c5                	jae    140 <__hia_fn_1+0x140>
 17b:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
 17f:	48 39 d9             	cmp    %rbx,%rcx
 182:	40 0f 96 c7          	setbe  %dil
 186:	40 84 ff             	test   %dil,%dil
 189:	75 15                	jne    1a0 <__hia_fn_1+0x1a0>
 18b:	eb 3d                	jmp    1ca <__hia_fn_1+0x1ca>
 18d:	40 b7 01             	mov    $0x1,%dil
 190:	31 c9                	xor    %ecx,%ecx
 192:	45 31 f6             	xor    %r14d,%r14d
 195:	48 89 da             	mov    %rbx,%rdx
 198:	40 b6 01             	mov    $0x1,%sil
 19b:	40 84 ff             	test   %dil,%dil
 19e:	74 2a                	je     1ca <__hia_fn_1+0x1ca>
 1a0:	40 84 f6             	test   %sil,%sil
 1a3:	74 25                	je     1ca <__hia_fn_1+0x1ca>
 1a5:	48 83 fa 08          	cmp    $0x8,%rdx
 1a9:	72 1f                	jb     1ca <__hia_fn_1+0x1ca>
 1ab:	48 83 fa 08          	cmp    $0x8,%rdx
 1af:	72 19                	jb     1ca <__hia_fn_1+0x1ca>
 1b1:	f3 0f 7e 04 08       	movq   (%rax,%rcx,1),%xmm0
 1b6:	66 0f ef c9          	pxor   %xmm1,%xmm1
 1ba:	66 0f f6 c8          	psadbw %xmm0,%xmm1
 1be:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 1c3:	49 01 d6             	add    %rdx,%r14
 1c6:	48 83 c1 08          	add    $0x8,%rcx
 1ca:	48 89 ca             	mov    %rcx,%rdx
 1cd:	48 29 da             	sub    %rbx,%rdx
 1d0:	73 79                	jae    24b <__hia_fn_1+0x24b>
 1d2:	89 de                	mov    %ebx,%esi
 1d4:	29 ce                	sub    %ecx,%esi
 1d6:	83 e6 07             	and    $0x7,%esi
 1d9:	74 14                	je     1ef <__hia_fn_1+0x1ef>
 1db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1e0:	0f b6 3c 08          	movzbl (%rax,%rcx,1),%edi
 1e4:	49 01 fe             	add    %rdi,%r14
 1e7:	48 ff c1             	inc    %rcx
 1ea:	48 ff ce             	dec    %rsi
 1ed:	75 f1                	jne    1e0 <__hia_fn_1+0x1e0>
 1ef:	48 83 fa f8          	cmp    $0xfffffffffffffff8,%rdx
 1f3:	77 5b                	ja     250 <__hia_fn_1+0x250>
 1f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 1fc:	00 00 00 00 
 200:	0f b6 14 08          	movzbl (%rax,%rcx,1),%edx
 204:	4c 01 f2             	add    %r14,%rdx
 207:	0f b6 74 08 01       	movzbl 0x1(%rax,%rcx,1),%esi
 20c:	0f b6 7c 08 02       	movzbl 0x2(%rax,%rcx,1),%edi
 211:	48 01 f7             	add    %rsi,%rdi
 214:	48 01 d7             	add    %rdx,%rdi
 217:	0f b6 54 08 03       	movzbl 0x3(%rax,%rcx,1),%edx
 21c:	0f b6 74 08 04       	movzbl 0x4(%rax,%rcx,1),%esi
 221:	48 01 d6             	add    %rdx,%rsi
 224:	0f b6 54 08 05       	movzbl 0x5(%rax,%rcx,1),%edx
 229:	48 01 f2             	add    %rsi,%rdx
 22c:	48 01 fa             	add    %rdi,%rdx
 22f:	0f b6 74 08 06       	movzbl 0x6(%rax,%rcx,1),%esi
 234:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
 23a:	49 01 f6             	add    %rsi,%r14
 23d:	49 01 d6             	add    %rdx,%r14
 240:	48 83 c1 08          	add    $0x8,%rcx
 244:	48 39 cb             	cmp    %rcx,%rbx
 247:	75 b7                	jne    200 <__hia_fn_1+0x200>
 249:	eb 05                	jmp    250 <__hia_fn_1+0x250>
 24b:	48 85 c0             	test   %rax,%rax
 24e:	74 08                	je     258 <__hia_fn_1+0x258>
 250:	48 89 c7             	mov    %rax,%rdi
 253:	e8 00 00 00 00       	call   258 <__hia_fn_1+0x258>
			254: R_X86_64_PLT32	free-0x4
 258:	4c 89 f0             	mov    %r14,%rax
 25b:	5b                   	pop    %rbx
 25c:	41 5e                	pop    %r14
 25e:	5d                   	pop    %rbp
 25f:	c3                   	ret

0000000000000260 <__hia_fn_2>:
 260:	55                   	push   %rbp
 261:	41 56                	push   %r14
 263:	53                   	push   %rbx
 264:	89 f5                	mov    %esi,%ebp
 266:	48 89 fb             	mov    %rdi,%rbx
 269:	48 85 ff             	test   %rdi,%rdi
 26c:	78 2a                	js     298 <__hia_fn_2+0x38>
 26e:	48 89 df             	mov    %rbx,%rdi
 271:	e8 00 00 00 00       	call   276 <__hia_fn_2+0x16>
			272: R_X86_64_PLT32	malloc-0x4
 276:	48 85 c0             	test   %rax,%rax
 279:	74 1d                	je     298 <__hia_fn_2+0x38>
 27b:	48 89 c7             	mov    %rax,%rdi
 27e:	b0 01                	mov    $0x1,%al
 280:	a8 01                	test   $0x1,%al
 282:	75 1c                	jne    2a0 <__hia_fn_2+0x40>
 284:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
 28a:	48 85 ff             	test   %rdi,%rdi
 28d:	0f 85 02 01 00 00    	jne    395 <__hia_fn_2+0x135>
 293:	e9 02 01 00 00       	jmp    39a <__hia_fn_2+0x13a>
 298:	31 ff                	xor    %edi,%edi
 29a:	31 c0                	xor    %eax,%eax
 29c:	a8 01                	test   $0x1,%al
 29e:	74 e4                	je     284 <__hia_fn_2+0x24>
 2a0:	48 89 d8             	mov    %rbx,%rax
 2a3:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
 2a7:	66 0f 6e c5          	movd   %ebp,%xmm0
 2ab:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 2af:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 2b4:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
 2b9:	66 0f 6f 0d 00 00 00 	movdqa 0x0(%rip),%xmm1        # 2c1 <__hia_fn_2+0x61>
 2c0:	00 
			2bd: R_X86_64_PC32	.LCPI1_0-0x4
 2c1:	31 c9                	xor    %ecx,%ecx
 2c3:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 2cb <__hia_fn_2+0x6b>
 2ca:	00 
			2c7: R_X86_64_PC32	.LCPI1_1-0x4
 2cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 2d0:	66 0f 6f d9          	movdqa %xmm1,%xmm3
 2d4:	66 0f fc d8          	paddb  %xmm0,%xmm3
 2d8:	f3 0f 7f 1c 0f       	movdqu %xmm3,(%rdi,%rcx,1)
 2dd:	48 83 c1 10          	add    $0x10,%rcx
 2e1:	66 0f fc ca          	paddb  %xmm2,%xmm1
 2e5:	48 39 c8             	cmp    %rcx,%rax
 2e8:	75 e6                	jne    2d0 <__hia_fn_2+0x70>
 2ea:	48 39 c3             	cmp    %rax,%rbx
 2ed:	74 7f                	je     36e <__hia_fn_2+0x10e>
 2ef:	f6 c3 0c             	test   $0xc,%bl
 2f2:	74 5d                	je     351 <__hia_fn_2+0xf1>
 2f4:	48 89 d9             	mov    %rbx,%rcx
 2f7:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
 2fb:	66 0f 6e c0          	movd   %eax,%xmm0
 2ff:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
 303:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
 308:	66 0f eb 05 00 00 00 	por    0x0(%rip),%xmm0        # 310 <__hia_fn_2+0xb0>
 30f:	00 
			30c: R_X86_64_PC32	.LCPI1_2-0x4
 310:	40 0f b6 d5          	movzbl %bpl,%edx
 314:	66 0f 6e ca          	movd   %edx,%xmm1
 318:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
 31c:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
 321:	66 0f 6f 15 00 00 00 	movdqa 0x0(%rip),%xmm2        # 329 <__hia_fn_2+0xc9>
 328:	00 
			325: R_X86_64_PC32	.LCPI1_3-0x4
 329:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 330:	66 0f 6f d8          	movdqa %xmm0,%xmm3
 334:	66 0f fc d9          	paddb  %xmm1,%xmm3
 338:	66 0f 7e 1c 07       	movd   %xmm3,(%rdi,%rax,1)
 33d:	48 83 c0 04          	add    $0x4,%rax
 341:	66 0f fc c2          	paddb  %xmm2,%xmm0
 345:	48 39 c1             	cmp    %rax,%rcx
 348:	75 e6                	jne    330 <__hia_fn_2+0xd0>
 34a:	48 39 cb             	cmp    %rcx,%rbx
 34d:	75 05                	jne    354 <__hia_fn_2+0xf4>
 34f:	eb 1d                	jmp    36e <__hia_fn_2+0x10e>
 351:	48 89 c1             	mov    %rax,%rcx
 354:	89 e8                	mov    %ebp,%eax
 356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 35d:	00 00 00 
 360:	8d 14 08             	lea    (%rax,%rcx,1),%edx
 363:	88 14 0f             	mov    %dl,(%rdi,%rcx,1)
 366:	48 ff c1             	inc    %rcx
 369:	48 39 cb             	cmp    %rcx,%rbx
 36c:	75 f2                	jne    360 <__hia_fn_2+0x100>
 36e:	31 c0                	xor    %eax,%eax
 370:	45 31 f6             	xor    %r14d,%r14d
 373:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 37a:	84 00 00 00 00 00 
 380:	4c 89 f1             	mov    %r14,%rcx
 383:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
 388:	49 01 ce             	add    %rcx,%r14
 38b:	72 15                	jb     3a2 <__hia_fn_2+0x142>
 38d:	48 ff c0             	inc    %rax
 390:	48 39 c3             	cmp    %rax,%rbx
 393:	75 eb                	jne    380 <__hia_fn_2+0x120>
 395:	e8 00 00 00 00       	call   39a <__hia_fn_2+0x13a>
			396: R_X86_64_PLT32	free-0x4
 39a:	4c 89 f0             	mov    %r14,%rax
 39d:	5b                   	pop    %rbx
 39e:	41 5e                	pop    %r14
 3a0:	5d                   	pop    %rbp
 3a1:	c3                   	ret
 3a2:	e8 00 00 00 00       	call   3a7 <__hia_fn_2+0x147>
			3a3: R_X86_64_PLT32	abort-0x4
 3a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 3ae:	00 00 

00000000000003b0 <calculate>:
 3b0:	48 85 ff             	test   %rdi,%rdi
 3b3:	75 03                	jne    3b8 <calculate+0x8>
 3b5:	31 c0                	xor    %eax,%eax
 3b7:	c3                   	ret
 3b8:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
 3bf:	01 01 01 
 3c2:	48 39 c7             	cmp    %rax,%rdi
 3c5:	0f 86 35 fc ff ff    	jbe    0 <__hia_fn_1>
 3cb:	e9 90 fe ff ff       	jmp    260 <__hia_fn_2>
