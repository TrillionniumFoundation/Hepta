; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8>, <16 x i8>)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i64 @__hia_fn_0(i64 %p_0_0, i32 %p_0_1) {
b0:
  %t1 = icmp ule i64 %p_0_0, 72340172838076673
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %t2 = call %hia.alloc @__hia_allocate(i64 %p_1_0, i1 false)
  %t3 = extractvalue %hia.alloc %t2, 0
  %t4 = extractvalue %hia.alloc %t2, 1
  %t5 = select i1 %t4, i64 %p_1_0, i64 0
  %t6 = insertvalue %hia.buffer %t3, i64 %t5, 1
  br i1 %t4, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i32 [ %p_1_1, %edge_2 ]
  %p_2_2 = phi i1 [ %t4, %edge_2 ]
  %p_2_3 = phi %hia.buffer [ %t6, %edge_2 ]
  %p_2_4 = phi i8 [ 1, %edge_2 ]
  br label %edge_4
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_3_1 = phi i32 [ %p_1_1, %edge_3 ]
  %p_3_2 = phi i1 [ %t4, %edge_3 ]
  %p_3_3 = phi %hia.buffer [ %t6, %edge_3 ]
  %p_3_4 = phi i8 [ 1, %edge_3 ]
  %t7 = extractvalue %hia.buffer %p_3_3, 0
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %drop_nonnull_9, label %drop_after_9
drop_nonnull_9:
  call void @free(ptr %t7) nobuiltin
  br label %drop_after_9
drop_after_9:
  %t10 = zext i8 %p_3_4 to i64
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t10)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  ret i64 %t12
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_0, %edge_7 ]
  %p_4_1 = phi i32 [ %p_2_1, %edge_4 ], [ %p_5_1, %edge_7 ]
  %p_4_2 = phi %hia.buffer [ %p_2_3, %edge_4 ], [ %p_5_2, %edge_7 ]
  %p_4_3 = phi i64 [ %p_2_0, %edge_4 ], [ %p_5_3, %edge_7 ]
  %p_4_4 = phi i64 [ 0, %edge_4 ], [ %t27, %edge_7 ]
  %t16 = icmp ult i64 %p_4_4, %p_4_3
  br i1 %t16, label %edge_5, label %edge_6
b5:
  %p_5_0 = phi i64 [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i32 [ %p_4_1, %edge_5 ]
  %p_5_2 = phi %hia.buffer [ %p_4_2, %edge_5 ]
  %p_5_3 = phi i64 [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i64 [ %p_4_4, %edge_5 ]
  %t17 = trunc i64 %p_5_4 to i32
  %t18 = add i32 %t17, %p_5_1
  %t19 = trunc i64 %p_5_4 to i8
  %t20 = trunc i32 %p_5_1 to i8
  %t21 = add i8 %t19, %t20
  %t22 = extractvalue %hia.buffer %p_5_2, 0
  %t23 = extractvalue %hia.buffer %p_5_2, 1
  %t24 = icmp ult i64 %p_5_4, %t23
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = getelementptr i8, ptr %t22, i64 %p_5_4
  store i8 %t21, ptr %t26, align 1
  %t27 = add i64 %p_5_4, 1
  br label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_6 ]
  %p_6_1 = phi i32 [ %p_4_1, %edge_6 ]
  %p_6_2 = phi %hia.buffer [ %p_4_2, %edge_6 ]
  %p_6_3 = phi i64 [ %p_4_3, %edge_6 ]
  %p_6_4 = phi i64 [ %p_4_4, %edge_6 ]
  br label %edge_8
b7:
  %p_7_0 = phi i64 [ %p_6_0, %edge_8 ], [ %p_8_0, %edge_11 ]
  %p_7_1 = phi i32 [ %p_6_1, %edge_8 ], [ %p_8_1, %edge_11 ]
  %p_7_2 = phi %hia.buffer [ %p_6_2, %edge_8 ], [ %p_8_2, %edge_11 ]
  %p_7_3 = phi i64 [ 0, %edge_8 ], [ %t35, %edge_11 ]
  %p_7_4 = phi i64 [ %p_6_0, %edge_8 ], [ %p_8_4, %edge_11 ]
  %p_7_5 = phi i64 [ 0, %edge_8 ], [ %t34, %edge_11 ]
  %t28 = icmp ult i64 %p_7_5, %p_7_4
  br i1 %t28, label %edge_9, label %edge_10
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_9 ]
  %p_8_1 = phi i32 [ %p_7_1, %edge_9 ]
  %p_8_2 = phi %hia.buffer [ %p_7_2, %edge_9 ]
  %p_8_3 = phi i64 [ %p_7_3, %edge_9 ]
  %p_8_4 = phi i64 [ %p_7_4, %edge_9 ]
  %p_8_5 = phi i64 [ %p_7_5, %edge_9 ]
  %t29 = extractvalue %hia.buffer %p_8_2, 0
  %t30 = extractvalue %hia.buffer %p_8_2, 1
  br label %byte_sum_start_31
byte_sum_start_31:
  br label %byte_sum_vector_head_31
byte_sum_vector_head_31:
  %t32 = phi i64 [ %p_8_5, %byte_sum_start_31 ], [ %t43, %byte_sum_vector_body_31 ]
  %t33 = phi i64 [ %p_8_3, %byte_sum_start_31 ], [ %t42, %byte_sum_vector_body_31 ]
  %t61 = icmp ule i64 %t32, %p_8_4
  %t62 = sub i64 %p_8_4, %t32
  %t63 = icmp uge i64 %t62, 16
  %t64 = and i1 %t61, %t63
  %t65 = icmp ule i64 %t32, %t30
  %t66 = sub i64 %t30, %t32
  %t67 = icmp uge i64 %t66, 16
  %t68 = and i1 %t65, %t67
  %t69 = and i1 %t64, %t68
  br i1 %t69, label %byte_sum_vector_body_31, label %byte_sum_half_head_31
byte_sum_vector_body_31:
  %t36 = getelementptr i8, ptr %t29, i64 %t32
  %t37 = load <16 x i8>, ptr %t36, align 1
  %t38 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t37, <16 x i8> zeroinitializer)
  %t39 = extractelement <2 x i64> %t38, i32 0
  %t40 = extractelement <2 x i64> %t38, i32 1
  %t41 = add i64 %t39, %t40
  %t42 = add i64 %t33, %t41
  %t43 = add i64 %t32, 16
  br label %byte_sum_vector_head_31
byte_sum_half_head_31:
  %t70 = icmp ule i64 %t32, %p_8_4
  %t71 = sub i64 %p_8_4, %t32
  %t72 = icmp uge i64 %t71, 8
  %t73 = and i1 %t70, %t72
  %t74 = icmp ule i64 %t32, %t30
  %t75 = sub i64 %t30, %t32
  %t76 = icmp uge i64 %t75, 8
  %t77 = and i1 %t74, %t76
  %t78 = and i1 %t73, %t77
  br i1 %t78, label %byte_sum_half_body_31, label %byte_sum_scalar_head_31
byte_sum_half_body_31:
  %t44 = getelementptr i8, ptr %t29, i64 %t32
  %t45 = load i64, ptr %t44, align 1
  %t46 = insertelement <2 x i64> zeroinitializer, i64 %t45, i32 0
  %t47 = bitcast <2 x i64> %t46 to <16 x i8>
  %t48 = call <2 x i64> @llvm.x86.sse2.psad.bw(<16 x i8> %t47, <16 x i8> zeroinitializer)
  %t49 = extractelement <2 x i64> %t48, i32 0
  %t50 = add i64 %t33, %t49
  %t51 = add i64 %t32, 8
  br label %byte_sum_scalar_head_31
byte_sum_scalar_head_31:
  %t34 = phi i64 [ %t32, %byte_sum_half_head_31 ], [ %t51, %byte_sum_half_body_31 ], [ %t60, %byte_sum_scalar_done_31 ]
  %t35 = phi i64 [ %t33, %byte_sum_half_head_31 ], [ %t50, %byte_sum_half_body_31 ], [ %t59, %byte_sum_scalar_done_31 ]
  %t79 = icmp ult i64 %t34, %p_8_4
  br i1 %t79, label %byte_sum_scalar_body_31, label %byte_sum_finished_31
byte_sum_scalar_body_31:
  %t52 = extractvalue %hia.buffer %p_8_2, 0
  %t53 = extractvalue %hia.buffer %p_8_2, 1
  %t54 = icmp ult i64 %t34, %t53
  br i1 %t54, label %ok_55, label %trap_55
trap_55:
  call void @abort()
  unreachable
ok_55:
  %t56 = getelementptr i8, ptr %t52, i64 %t34
  %t57 = load i8, ptr %t56, align 1
  %t58 = zext i8 %t57 to i64
  %t59 = add i64 %t35, %t58
  %t60 = add i64 %t34, 1
  br label %byte_sum_scalar_done_31
byte_sum_scalar_done_31:
  br label %byte_sum_scalar_head_31
byte_sum_finished_31:
  br label %edge_11
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_10 ]
  %p_9_1 = phi i32 [ %p_7_1, %edge_10 ]
  %p_9_2 = phi %hia.buffer [ %p_7_2, %edge_10 ]
  %p_9_3 = phi i64 [ %p_7_3, %edge_10 ]
  %p_9_4 = phi i64 [ %p_7_4, %edge_10 ]
  %p_9_5 = phi i64 [ %p_7_5, %edge_10 ]
  %t80 = extractvalue %hia.buffer %p_9_2, 0
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %drop_nonnull_82, label %drop_after_82
drop_nonnull_82:
  call void @free(ptr %t80) nobuiltin
  br label %drop_after_82
drop_after_82:
  ret i64 %p_9_3
b10:
  %p_10_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_10_1 = phi i32 [ %p_0_1, %edge_1 ]
  %t83 = call %hia.alloc @__hia_allocate(i64 %p_10_0, i1 false)
  %t84 = extractvalue %hia.alloc %t83, 0
  %t85 = extractvalue %hia.alloc %t83, 1
  %t86 = select i1 %t85, i64 %p_10_0, i64 0
  %t87 = insertvalue %hia.buffer %t84, i64 %t86, 1
  br i1 %t85, label %edge_12, label %edge_13
b11:
  %p_11_0 = phi i64 [ %p_10_0, %edge_12 ]
  %p_11_1 = phi i32 [ %p_10_1, %edge_12 ]
  %p_11_2 = phi i1 [ %t85, %edge_12 ]
  %p_11_3 = phi %hia.buffer [ %t87, %edge_12 ]
  %p_11_4 = phi i8 [ 1, %edge_12 ]
  br label %edge_14
b12:
  %p_12_0 = phi i64 [ %p_10_0, %edge_13 ]
  %p_12_1 = phi i32 [ %p_10_1, %edge_13 ]
  %p_12_2 = phi i1 [ %t85, %edge_13 ]
  %p_12_3 = phi %hia.buffer [ %t87, %edge_13 ]
  %p_12_4 = phi i8 [ 1, %edge_13 ]
  %t88 = extractvalue %hia.buffer %p_12_3, 0
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %drop_nonnull_90, label %drop_after_90
drop_nonnull_90:
  call void @free(ptr %t88) nobuiltin
  br label %drop_after_90
drop_after_90:
  %t91 = zext i8 %p_12_4 to i64
  %t92 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 1000, i64 %t91)
  %t93 = extractvalue { i64, i1 } %t92, 0
  %t94 = extractvalue { i64, i1 } %t92, 1
  %t95 = xor i1 %t94, true
  br i1 %t95, label %ok_96, label %trap_96
trap_96:
  call void @abort()
  unreachable
ok_96:
  ret i64 %t93
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_14 ], [ %p_14_0, %edge_17 ]
  %p_13_1 = phi i32 [ %p_11_1, %edge_14 ], [ %p_14_1, %edge_17 ]
  %p_13_2 = phi %hia.buffer [ %p_11_3, %edge_14 ], [ %p_14_2, %edge_17 ]
  %p_13_3 = phi i64 [ %p_11_0, %edge_14 ], [ %p_14_3, %edge_17 ]
  %p_13_4 = phi i64 [ 0, %edge_14 ], [ %t109, %edge_17 ]
  %t97 = icmp ult i64 %p_13_4, %p_13_3
  br i1 %t97, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_14_1 = phi i32 [ %p_13_1, %edge_15 ]
  %p_14_2 = phi %hia.buffer [ %p_13_2, %edge_15 ]
  %p_14_3 = phi i64 [ %p_13_3, %edge_15 ]
  %p_14_4 = phi i64 [ %p_13_4, %edge_15 ]
  %t98 = trunc i64 %p_14_4 to i32
  %t99 = add i32 %t98, %p_14_1
  %t100 = trunc i64 %p_14_4 to i8
  %t101 = trunc i32 %p_14_1 to i8
  %t102 = add i8 %t100, %t101
  %t103 = extractvalue %hia.buffer %p_14_2, 0
  %t104 = extractvalue %hia.buffer %p_14_2, 1
  %t105 = icmp ult i64 %p_14_4, %t104
  br i1 %t105, label %ok_106, label %trap_106
trap_106:
  call void @abort()
  unreachable
ok_106:
  %t107 = getelementptr i8, ptr %t103, i64 %p_14_4
  store i8 %t102, ptr %t107, align 1
  %t108 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_14_4, i64 1)
  %t109 = extractvalue { i64, i1 } %t108, 0
  %t110 = extractvalue { i64, i1 } %t108, 1
  %t111 = xor i1 %t110, true
  br i1 %t111, label %ok_112, label %trap_112
trap_112:
  call void @abort()
  unreachable
ok_112:
  br label %edge_17
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_16 ]
  %p_15_1 = phi i32 [ %p_13_1, %edge_16 ]
  %p_15_2 = phi %hia.buffer [ %p_13_2, %edge_16 ]
  %p_15_3 = phi i64 [ %p_13_3, %edge_16 ]
  %p_15_4 = phi i64 [ %p_13_4, %edge_16 ]
  br label %edge_18
b16:
  %p_16_0 = phi i64 [ %p_15_0, %edge_18 ], [ %p_17_0, %edge_21 ]
  %p_16_1 = phi i32 [ %p_15_1, %edge_18 ], [ %p_17_1, %edge_21 ]
  %p_16_2 = phi %hia.buffer [ %p_15_2, %edge_18 ], [ %p_17_2, %edge_21 ]
  %p_16_3 = phi i64 [ 0, %edge_18 ], [ %t122, %edge_21 ]
  %p_16_4 = phi i64 [ %p_15_0, %edge_18 ], [ %p_17_4, %edge_21 ]
  %p_16_5 = phi i64 [ 0, %edge_18 ], [ %t127, %edge_21 ]
  %t113 = icmp ult i64 %p_16_5, %p_16_4
  br i1 %t113, label %edge_19, label %edge_20
b17:
  %p_17_0 = phi i64 [ %p_16_0, %edge_19 ]
  %p_17_1 = phi i32 [ %p_16_1, %edge_19 ]
  %p_17_2 = phi %hia.buffer [ %p_16_2, %edge_19 ]
  %p_17_3 = phi i64 [ %p_16_3, %edge_19 ]
  %p_17_4 = phi i64 [ %p_16_4, %edge_19 ]
  %p_17_5 = phi i64 [ %p_16_5, %edge_19 ]
  %t114 = extractvalue %hia.buffer %p_17_2, 0
  %t115 = extractvalue %hia.buffer %p_17_2, 1
  %t116 = icmp ult i64 %p_17_5, %t115
  br i1 %t116, label %ok_117, label %trap_117
trap_117:
  call void @abort()
  unreachable
ok_117:
  %t118 = getelementptr i8, ptr %t114, i64 %p_17_5
  %t119 = load i8, ptr %t118, align 1
  %t120 = zext i8 %t119 to i64
  %t121 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_17_3, i64 %t120)
  %t122 = extractvalue { i64, i1 } %t121, 0
  %t123 = extractvalue { i64, i1 } %t121, 1
  %t124 = xor i1 %t123, true
  br i1 %t124, label %ok_125, label %trap_125
trap_125:
  call void @abort()
  unreachable
ok_125:
  %t126 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_17_5, i64 1)
  %t127 = extractvalue { i64, i1 } %t126, 0
  %t128 = extractvalue { i64, i1 } %t126, 1
  %t129 = xor i1 %t128, true
  br i1 %t129, label %ok_130, label %trap_130
trap_130:
  call void @abort()
  unreachable
ok_130:
  br label %edge_21
b18:
  %p_18_0 = phi i64 [ %p_16_0, %edge_20 ]
  %p_18_1 = phi i32 [ %p_16_1, %edge_20 ]
  %p_18_2 = phi %hia.buffer [ %p_16_2, %edge_20 ]
  %p_18_3 = phi i64 [ %p_16_3, %edge_20 ]
  %p_18_4 = phi i64 [ %p_16_4, %edge_20 ]
  %p_18_5 = phi i64 [ %p_16_5, %edge_20 ]
  %t131 = extractvalue %hia.buffer %p_18_2, 0
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %drop_nonnull_133, label %drop_after_133
drop_nonnull_133:
  call void @free(ptr %t131) nobuiltin
  br label %drop_after_133
drop_after_133:
  ret i64 %p_18_3
edge_0:
  br label %b1
edge_1:
  br label %b10
edge_2:
  br label %b2
edge_3:
  br label %b3
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b4
edge_8:
  br label %b7
edge_9:
  br label %b8
edge_10:
  br label %b9
edge_11:
  br label %b7
edge_12:
  br label %b11
edge_13:
  br label %b12
edge_14:
  br label %b13
edge_15:
  br label %b14
edge_16:
  br label %b15
edge_17:
  br label %b13
edge_18:
  br label %b16
edge_19:
  br label %b17
edge_20:
  br label %b18
edge_21:
  br label %b16
}

define i64 @calculate(i64 %a0, i32 %a1) {
entry:
  %result = call i64 @__hia_fn_0(i64 %a0, i32 %a1)
  ret i64 %result
}
