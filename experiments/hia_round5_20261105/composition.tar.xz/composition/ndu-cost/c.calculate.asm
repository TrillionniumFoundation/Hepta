
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/ndu-cost/c.so：     文件格式 elf64-x86-64


Disassembly of section .text:

0000000000002840 <calculate>:
    2840:	55                   	push   %rbp
    2841:	41 56                	push   %r14
    2843:	53                   	push   %rbx
    2844:	48 85 ff             	test   %rdi,%rdi
    2847:	74 21                	je     286a <calculate+0x2a>
    2849:	89 f5                	mov    %esi,%ebp
    284b:	48 89 fb             	mov    %rdi,%rbx
    284e:	be 01 00 00 00       	mov    $0x1,%esi
    2853:	e8 b8 02 00 00       	call   2b10 <__wrap_calloc@plt>
    2858:	48 85 c0             	test   %rax,%rax
    285b:	74 15                	je     2872 <calculate+0x32>
    285d:	48 83 fb 04          	cmp    $0x4,%rbx
    2861:	73 1a                	jae    287d <calculate+0x3d>
    2863:	31 c9                	xor    %ecx,%ecx
    2865:	e9 41 01 00 00       	jmp    29ab <calculate+0x16b>
    286a:	45 31 f6             	xor    %r14d,%r14d
    286d:	e9 e5 01 00 00       	jmp    2a57 <calculate+0x217>
    2872:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    2878:	e9 da 01 00 00       	jmp    2a57 <calculate+0x217>
    287d:	66 0f 6e c5          	movd   %ebp,%xmm0
    2881:	48 83 fb 10          	cmp    $0x10,%rbx
    2885:	73 07                	jae    288e <calculate+0x4e>
    2887:	31 c9                	xor    %ecx,%ecx
    2889:	e9 ba 00 00 00       	jmp    2948 <calculate+0x108>
    288e:	48 89 d9             	mov    %rbx,%rcx
    2891:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
    2895:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    289a:	66 0f 6f 15 2e df ff 	movdqa -0x20d2(%rip),%xmm2        # 7d0 <__FRAME_END__-0xe0>
    28a1:	ff 
    28a2:	66 0f 6f 1d 36 df ff 	movdqa -0x20ca(%rip),%xmm3        # 7e0 <__FRAME_END__-0xd0>
    28a9:	ff 
    28aa:	66 0f 6f 25 3e df ff 	movdqa -0x20c2(%rip),%xmm4        # 7f0 <__FRAME_END__-0xc0>
    28b1:	ff 
    28b2:	66 0f 6f 2d 46 df ff 	movdqa -0x20ba(%rip),%xmm5        # 800 <__FRAME_END__-0xb0>
    28b9:	ff 
    28ba:	31 d2                	xor    %edx,%edx
    28bc:	66 0f 6f 35 7c df ff 	movdqa -0x2084(%rip),%xmm6        # 840 <__FRAME_END__-0x70>
    28c3:	ff 
    28c4:	66 0f 6f 3d 64 df ff 	movdqa -0x209c(%rip),%xmm7        # 830 <__FRAME_END__-0x80>
    28cb:	ff 
    28cc:	0f 1f 40 00          	nopl   0x0(%rax)
    28d0:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    28d5:	66 44 0f fe c2       	paddd  %xmm2,%xmm8
    28da:	66 44 0f 6f c9       	movdqa %xmm1,%xmm9
    28df:	66 44 0f fe cb       	paddd  %xmm3,%xmm9
    28e4:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    28e9:	66 44 0f fe d4       	paddd  %xmm4,%xmm10
    28ee:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    28f3:	66 44 0f fe dd       	paddd  %xmm5,%xmm11
    28f8:	66 44 0f db de       	pand   %xmm6,%xmm11
    28fd:	66 44 0f db d6       	pand   %xmm6,%xmm10
    2902:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    2907:	66 44 0f db ce       	pand   %xmm6,%xmm9
    290c:	66 44 0f db c6       	pand   %xmm6,%xmm8
    2911:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    2916:	66 45 0f 67 d9       	packuswb %xmm9,%xmm11
    291b:	f3 44 0f 7f 1c 10    	movdqu %xmm11,(%rax,%rdx,1)
    2921:	48 83 c2 10          	add    $0x10,%rdx
    2925:	66 0f fe ef          	paddd  %xmm7,%xmm5
    2929:	66 0f fe e7          	paddd  %xmm7,%xmm4
    292d:	66 0f fe df          	paddd  %xmm7,%xmm3
    2931:	66 0f fe d7          	paddd  %xmm7,%xmm2
    2935:	48 39 d1             	cmp    %rdx,%rcx
    2938:	75 96                	jne    28d0 <calculate+0x90>
    293a:	48 39 cb             	cmp    %rcx,%rbx
    293d:	0f 84 7c 00 00 00    	je     29bf <calculate+0x17f>
    2943:	f6 c3 0c             	test   $0xc,%bl
    2946:	74 63                	je     29ab <calculate+0x16b>
    2948:	48 89 ca             	mov    %rcx,%rdx
    294b:	48 89 d9             	mov    %rbx,%rcx
    294e:	66 0f 6e ca          	movd   %edx,%xmm1
    2952:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
    2957:	66 0f eb 0d a1 de ff 	por    -0x215f(%rip),%xmm1        # 800 <__FRAME_END__-0xb0>
    295e:	ff 
    295f:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    2963:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    2968:	66 0f 6f 15 d0 de ff 	movdqa -0x2130(%rip),%xmm2        # 840 <__FRAME_END__-0x70>
    296f:	ff 
    2970:	66 0f 6f 1d 98 de ff 	movdqa -0x2168(%rip),%xmm3        # 810 <__FRAME_END__-0xa0>
    2977:	ff 
    2978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    297f:	00 
    2980:	66 0f 6f e0          	movdqa %xmm0,%xmm4
    2984:	66 0f fe e1          	paddd  %xmm1,%xmm4
    2988:	66 0f db e2          	pand   %xmm2,%xmm4
    298c:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    2990:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    2994:	66 0f 7e 24 10       	movd   %xmm4,(%rax,%rdx,1)
    2999:	48 83 c2 04          	add    $0x4,%rdx
    299d:	66 0f fe cb          	paddd  %xmm3,%xmm1
    29a1:	48 39 d1             	cmp    %rdx,%rcx
    29a4:	75 da                	jne    2980 <calculate+0x140>
    29a6:	48 39 cb             	cmp    %rcx,%rbx
    29a9:	74 14                	je     29bf <calculate+0x17f>
    29ab:	89 ea                	mov    %ebp,%edx
    29ad:	0f 1f 00             	nopl   (%rax)
    29b0:	8d 34 0a             	lea    (%rdx,%rcx,1),%esi
    29b3:	40 88 34 08          	mov    %sil,(%rax,%rcx,1)
    29b7:	48 ff c1             	inc    %rcx
    29ba:	48 39 cb             	cmp    %rcx,%rbx
    29bd:	75 f1                	jne    29b0 <calculate+0x170>
    29bf:	89 d9                	mov    %ebx,%ecx
    29c1:	83 e1 07             	and    $0x7,%ecx
    29c4:	48 83 fb 08          	cmp    $0x8,%rbx
    29c8:	73 07                	jae    29d1 <calculate+0x191>
    29ca:	31 d2                	xor    %edx,%edx
    29cc:	45 31 f6             	xor    %r14d,%r14d
    29cf:	eb 59                	jmp    2a2a <calculate+0x1ea>
    29d1:	48 83 e3 f8          	and    $0xfffffffffffffff8,%rbx
    29d5:	31 d2                	xor    %edx,%edx
    29d7:	45 31 f6             	xor    %r14d,%r14d
    29da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    29e0:	0f b6 34 10          	movzbl (%rax,%rdx,1),%esi
    29e4:	4c 01 f6             	add    %r14,%rsi
    29e7:	0f b6 7c 10 01       	movzbl 0x1(%rax,%rdx,1),%edi
    29ec:	44 0f b6 44 10 02    	movzbl 0x2(%rax,%rdx,1),%r8d
    29f2:	49 01 f8             	add    %rdi,%r8
    29f5:	49 01 f0             	add    %rsi,%r8
    29f8:	0f b6 74 10 03       	movzbl 0x3(%rax,%rdx,1),%esi
    29fd:	0f b6 7c 10 04       	movzbl 0x4(%rax,%rdx,1),%edi
    2a02:	48 01 f7             	add    %rsi,%rdi
    2a05:	0f b6 74 10 05       	movzbl 0x5(%rax,%rdx,1),%esi
    2a0a:	48 01 fe             	add    %rdi,%rsi
    2a0d:	4c 01 c6             	add    %r8,%rsi
    2a10:	0f b6 7c 10 06       	movzbl 0x6(%rax,%rdx,1),%edi
    2a15:	44 0f b6 74 10 07    	movzbl 0x7(%rax,%rdx,1),%r14d
    2a1b:	49 01 fe             	add    %rdi,%r14
    2a1e:	49 01 f6             	add    %rsi,%r14
    2a21:	48 83 c2 08          	add    $0x8,%rdx
    2a25:	48 39 d3             	cmp    %rdx,%rbx
    2a28:	75 b6                	jne    29e0 <calculate+0x1a0>
    2a2a:	48 85 c9             	test   %rcx,%rcx
    2a2d:	74 20                	je     2a4f <calculate+0x20f>
    2a2f:	48 89 c6             	mov    %rax,%rsi
    2a32:	48 01 d6             	add    %rdx,%rsi
    2a35:	31 d2                	xor    %edx,%edx
    2a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a3e:	00 00 
    2a40:	0f b6 3c 16          	movzbl (%rsi,%rdx,1),%edi
    2a44:	49 01 fe             	add    %rdi,%r14
    2a47:	48 ff c2             	inc    %rdx
    2a4a:	48 39 d1             	cmp    %rdx,%rcx
    2a4d:	75 f1                	jne    2a40 <calculate+0x200>
    2a4f:	48 89 c7             	mov    %rax,%rdi
    2a52:	e8 c9 00 00 00       	call   2b20 <__wrap_free@plt>
    2a57:	4c 89 f0             	mov    %r14,%rax
    2a5a:	5b                   	pop    %rbx
    2a5b:	41 5e                	pop    %r14
    2a5d:	5d                   	pop    %rbp
    2a5e:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
