
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/reduction/linear/hia_reduction.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	89 f5                	mov    %esi,%ebp
    11b6:	48 89 fb             	mov    %rdi,%rbx
    11b9:	48 b8 02 01 01 01 01 	movabs $0x101010101010102,%rax
    11c0:	01 01 01 
    11c3:	48 39 c7             	cmp    %rax,%rdi
    11c6:	73 2b                	jae    11f3 <calculate+0x43>
    11c8:	48 85 db             	test   %rbx,%rbx
    11cb:	0f 84 27 01 00 00    	je     12f8 <calculate+0x148>
    11d1:	48 89 df             	mov    %rbx,%rdi
    11d4:	e8 77 fe ff ff       	call   1050 <__wrap_malloc@plt>
    11d9:	48 85 c0             	test   %rax,%rax
    11dc:	0f 84 1e 01 00 00    	je     1300 <calculate+0x150>
    11e2:	48 83 fb 03          	cmp    $0x3,%rbx
    11e6:	0f 87 1f 01 00 00    	ja     130b <calculate+0x15b>
    11ec:	31 c9                	xor    %ecx,%ecx
    11ee:	e9 dc 01 00 00       	jmp    13cf <calculate+0x21f>
    11f3:	48 85 db             	test   %rbx,%rbx
    11f6:	78 28                	js     1220 <calculate+0x70>
    11f8:	48 89 df             	mov    %rbx,%rdi
    11fb:	e8 50 fe ff ff       	call   1050 <__wrap_malloc@plt>
    1200:	48 85 c0             	test   %rax,%rax
    1203:	74 1b                	je     1220 <calculate+0x70>
    1205:	b1 01                	mov    $0x1,%cl
    1207:	f6 c1 01             	test   $0x1,%cl
    120a:	75 1d                	jne    1229 <calculate+0x79>
    120c:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1212:	48 85 c0             	test   %rax,%rax
    1215:	0f 85 2a 03 00 00    	jne    1545 <calculate+0x395>
    121b:	e9 2d 03 00 00       	jmp    154d <calculate+0x39d>
    1220:	31 c0                	xor    %eax,%eax
    1222:	31 c9                	xor    %ecx,%ecx
    1224:	f6 c1 01             	test   $0x1,%cl
    1227:	74 e3                	je     120c <calculate+0x5c>
    1229:	48 89 d9             	mov    %rbx,%rcx
    122c:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
    1230:	66 0f 6e c5          	movd   %ebp,%xmm0
    1234:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1238:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    123d:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1242:	66 0f 6f 0d b6 1d 00 	movdqa 0x1db6(%rip),%xmm1        # 3000 <_fini+0xd68>
    1249:	00 
    124a:	31 d2                	xor    %edx,%edx
    124c:	66 0f 6f 15 bc 1d 00 	movdqa 0x1dbc(%rip),%xmm2        # 3010 <_fini+0xd78>
    1253:	00 
    1254:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    125b:	00 00 00 00 00 
    1260:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1264:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1268:	f3 0f 7f 1c 10       	movdqu %xmm3,(%rax,%rdx,1)
    126d:	48 83 c2 10          	add    $0x10,%rdx
    1271:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1275:	48 39 d1             	cmp    %rdx,%rcx
    1278:	75 e6                	jne    1260 <calculate+0xb0>
    127a:	48 39 cb             	cmp    %rcx,%rbx
    127d:	0f 84 9c 02 00 00    	je     151f <calculate+0x36f>
    1283:	f6 c3 0c             	test   $0xc,%bl
    1286:	0f 84 7f 02 00 00    	je     150b <calculate+0x35b>
    128c:	48 89 da             	mov    %rbx,%rdx
    128f:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    1293:	66 0f 6e c1          	movd   %ecx,%xmm0
    1297:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    129b:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    12a0:	66 0f eb 05 78 1d 00 	por    0x1d78(%rip),%xmm0        # 3020 <_fini+0xd88>
    12a7:	00 
    12a8:	40 0f b6 f5          	movzbl %bpl,%esi
    12ac:	66 0f 6e ce          	movd   %esi,%xmm1
    12b0:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    12b4:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    12b9:	66 0f 6f 15 6f 1d 00 	movdqa 0x1d6f(%rip),%xmm2        # 3030 <_fini+0xd98>
    12c0:	00 
    12c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    12c8:	0f 1f 84 00 00 00 00 
    12cf:	00 
    12d0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    12d4:	66 0f fc d9          	paddb  %xmm1,%xmm3
    12d8:	66 0f 7e 1c 08       	movd   %xmm3,(%rax,%rcx,1)
    12dd:	48 83 c1 04          	add    $0x4,%rcx
    12e1:	66 0f fc c2          	paddb  %xmm2,%xmm0
    12e5:	48 39 ca             	cmp    %rcx,%rdx
    12e8:	75 e6                	jne    12d0 <calculate+0x120>
    12ea:	48 39 d3             	cmp    %rdx,%rbx
    12ed:	0f 85 1b 02 00 00    	jne    150e <calculate+0x35e>
    12f3:	e9 27 02 00 00       	jmp    151f <calculate+0x36f>
    12f8:	45 31 f6             	xor    %r14d,%r14d
    12fb:	e9 4d 02 00 00       	jmp    154d <calculate+0x39d>
    1300:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1306:	e9 42 02 00 00       	jmp    154d <calculate+0x39d>
    130b:	48 be f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rsi
    1312:	ff ff 01 
    1315:	40 0f b6 d5          	movzbl %bpl,%edx
    1319:	48 83 fb 10          	cmp    $0x10,%rbx
    131d:	73 04                	jae    1323 <calculate+0x173>
    131f:	31 c9                	xor    %ecx,%ecx
    1321:	eb 55                	jmp    1378 <calculate+0x1c8>
    1323:	48 89 d9             	mov    %rbx,%rcx
    1326:	48 21 f1             	and    %rsi,%rcx
    1329:	66 0f 6e c2          	movd   %edx,%xmm0
    132d:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1331:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1336:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    133b:	66 0f 6f 0d bd 1c 00 	movdqa 0x1cbd(%rip),%xmm1        # 3000 <_fini+0xd68>
    1342:	00 
    1343:	31 ff                	xor    %edi,%edi
    1345:	66 0f 6f 15 c3 1c 00 	movdqa 0x1cc3(%rip),%xmm2        # 3010 <_fini+0xd78>
    134c:	00 
    134d:	0f 1f 00             	nopl   (%rax)
    1350:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1354:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1358:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
    135d:	48 83 c7 10          	add    $0x10,%rdi
    1361:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1365:	48 39 f9             	cmp    %rdi,%rcx
    1368:	75 e6                	jne    1350 <calculate+0x1a0>
    136a:	48 39 cb             	cmp    %rcx,%rbx
    136d:	0f 84 7c 00 00 00    	je     13ef <calculate+0x23f>
    1373:	f6 c3 0c             	test   $0xc,%bl
    1376:	74 57                	je     13cf <calculate+0x21f>
    1378:	48 89 cf             	mov    %rcx,%rdi
    137b:	48 83 c6 0c          	add    $0xc,%rsi
    137f:	48 89 f1             	mov    %rsi,%rcx
    1382:	48 21 d9             	and    %rbx,%rcx
    1385:	66 0f 6e c7          	movd   %edi,%xmm0
    1389:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    138d:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1392:	66 0f eb 05 86 1c 00 	por    0x1c86(%rip),%xmm0        # 3020 <_fini+0xd88>
    1399:	00 
    139a:	66 0f 6e ca          	movd   %edx,%xmm1
    139e:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    13a2:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    13a7:	66 0f 6f 15 81 1c 00 	movdqa 0x1c81(%rip),%xmm2        # 3030 <_fini+0xd98>
    13ae:	00 
    13af:	90                   	nop
    13b0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    13b4:	66 0f fc d9          	paddb  %xmm1,%xmm3
    13b8:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
    13bd:	48 83 c7 04          	add    $0x4,%rdi
    13c1:	66 0f fc c2          	paddb  %xmm2,%xmm0
    13c5:	48 39 f9             	cmp    %rdi,%rcx
    13c8:	75 e6                	jne    13b0 <calculate+0x200>
    13ca:	48 39 cb             	cmp    %rcx,%rbx
    13cd:	74 20                	je     13ef <calculate+0x23f>
    13cf:	89 ea                	mov    %ebp,%edx
    13d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    13d8:	0f 1f 84 00 00 00 00 
    13df:	00 
    13e0:	8d 34 0a             	lea    (%rdx,%rcx,1),%esi
    13e3:	40 88 34 08          	mov    %sil,(%rax,%rcx,1)
    13e7:	48 ff c1             	inc    %rcx
    13ea:	48 39 cb             	cmp    %rcx,%rbx
    13ed:	75 f1                	jne    13e0 <calculate+0x230>
    13ef:	48 83 fb 10          	cmp    $0x10,%rbx
    13f3:	72 5a                	jb     144f <calculate+0x29f>
    13f5:	b9 10 00 00 00       	mov    $0x10,%ecx
    13fa:	45 31 f6             	xor    %r14d,%r14d
    13fd:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1401:	48 89 da             	mov    %rbx,%rdx
    1404:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    140b:	00 00 00 00 00 
    1410:	48 89 ce             	mov    %rcx,%rsi
    1413:	f3 0f 6f 4c 08 f0    	movdqu -0x10(%rax,%rcx,1),%xmm1
    1419:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    141d:	66 48 0f 7e c9       	movq   %xmm1,%rcx
    1422:	4c 01 f1             	add    %r14,%rcx
    1425:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
    142a:	66 49 0f 7e ce       	movq   %xmm1,%r14
    142f:	49 01 ce             	add    %rcx,%r14
    1432:	48 83 c2 f0          	add    $0xfffffffffffffff0,%rdx
    1436:	48 8d 4e 10          	lea    0x10(%rsi),%rcx
    143a:	48 39 de             	cmp    %rbx,%rsi
    143d:	40 0f 96 c6          	setbe  %sil
    1441:	77 06                	ja     1449 <calculate+0x299>
    1443:	48 83 fa 0f          	cmp    $0xf,%rdx
    1447:	77 c7                	ja     1410 <calculate+0x260>
    1449:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
    144d:	eb 0b                	jmp    145a <calculate+0x2aa>
    144f:	40 b6 01             	mov    $0x1,%sil
    1452:	31 c9                	xor    %ecx,%ecx
    1454:	45 31 f6             	xor    %r14d,%r14d
    1457:	48 89 da             	mov    %rbx,%rdx
    145a:	48 83 fa 08          	cmp    $0x8,%rdx
    145e:	0f 92 c2             	setb   %dl
    1461:	40 80 f6 01          	xor    $0x1,%sil
    1465:	40 08 d6             	or     %dl,%sil
    1468:	75 19                	jne    1483 <calculate+0x2d3>
    146a:	f3 0f 7e 04 08       	movq   (%rax,%rcx,1),%xmm0
    146f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    1473:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    1477:	66 48 0f 7e ca       	movq   %xmm1,%rdx
    147c:	49 01 d6             	add    %rdx,%r14
    147f:	48 83 c1 08          	add    $0x8,%rcx
    1483:	48 89 ca             	mov    %rcx,%rdx
    1486:	48 29 da             	sub    %rbx,%rdx
    1489:	0f 83 b6 00 00 00    	jae    1545 <calculate+0x395>
    148f:	89 de                	mov    %ebx,%esi
    1491:	29 ce                	sub    %ecx,%esi
    1493:	83 e6 07             	and    $0x7,%esi
    1496:	74 17                	je     14af <calculate+0x2ff>
    1498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    149f:	00 
    14a0:	0f b6 3c 08          	movzbl (%rax,%rcx,1),%edi
    14a4:	49 01 fe             	add    %rdi,%r14
    14a7:	48 ff c1             	inc    %rcx
    14aa:	48 ff ce             	dec    %rsi
    14ad:	75 f1                	jne    14a0 <calculate+0x2f0>
    14af:	48 83 fa f8          	cmp    $0xfffffffffffffff8,%rdx
    14b3:	0f 87 8c 00 00 00    	ja     1545 <calculate+0x395>
    14b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    14c0:	0f b6 14 08          	movzbl (%rax,%rcx,1),%edx
    14c4:	4c 01 f2             	add    %r14,%rdx
    14c7:	0f b6 74 08 01       	movzbl 0x1(%rax,%rcx,1),%esi
    14cc:	0f b6 7c 08 02       	movzbl 0x2(%rax,%rcx,1),%edi
    14d1:	48 01 f7             	add    %rsi,%rdi
    14d4:	48 01 d7             	add    %rdx,%rdi
    14d7:	0f b6 54 08 03       	movzbl 0x3(%rax,%rcx,1),%edx
    14dc:	0f b6 74 08 04       	movzbl 0x4(%rax,%rcx,1),%esi
    14e1:	48 01 d6             	add    %rdx,%rsi
    14e4:	0f b6 54 08 05       	movzbl 0x5(%rax,%rcx,1),%edx
    14e9:	48 01 f2             	add    %rsi,%rdx
    14ec:	48 01 fa             	add    %rdi,%rdx
    14ef:	0f b6 74 08 06       	movzbl 0x6(%rax,%rcx,1),%esi
    14f4:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
    14fa:	49 01 f6             	add    %rsi,%r14
    14fd:	49 01 d6             	add    %rdx,%r14
    1500:	48 83 c1 08          	add    $0x8,%rcx
    1504:	48 39 cb             	cmp    %rcx,%rbx
    1507:	75 b7                	jne    14c0 <calculate+0x310>
    1509:	eb 3a                	jmp    1545 <calculate+0x395>
    150b:	48 89 ca             	mov    %rcx,%rdx
    150e:	89 e9                	mov    %ebp,%ecx
    1510:	8d 34 11             	lea    (%rcx,%rdx,1),%esi
    1513:	40 88 34 10          	mov    %sil,(%rax,%rdx,1)
    1517:	48 ff c2             	inc    %rdx
    151a:	48 39 d3             	cmp    %rdx,%rbx
    151d:	75 f1                	jne    1510 <calculate+0x360>
    151f:	31 c9                	xor    %ecx,%ecx
    1521:	45 31 f6             	xor    %r14d,%r14d
    1524:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    152b:	00 00 00 00 00 
    1530:	4c 89 f2             	mov    %r14,%rdx
    1533:	44 0f b6 34 08       	movzbl (%rax,%rcx,1),%r14d
    1538:	49 01 d6             	add    %rdx,%r14
    153b:	72 18                	jb     1555 <calculate+0x3a5>
    153d:	48 ff c1             	inc    %rcx
    1540:	48 39 cb             	cmp    %rcx,%rbx
    1543:	75 eb                	jne    1530 <calculate+0x380>
    1545:	48 89 c7             	mov    %rax,%rdi
    1548:	e8 43 fb ff ff       	call   1090 <__wrap_free@plt>
    154d:	4c 89 f0             	mov    %r14,%rax
    1550:	5b                   	pop    %rbx
    1551:	41 5e                	pop    %r14
    1553:	5d                   	pop    %rbp
    1554:	c3                   	ret
    1555:	e8 e6 fa ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
