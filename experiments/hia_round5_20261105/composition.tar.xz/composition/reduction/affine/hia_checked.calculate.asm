
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/reduction/affine/hia_checked.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	48 85 ff             	test   %rdi,%rdi
    11b7:	74 46                	je     11ff <calculate+0x4f>
    11b9:	89 f5                	mov    %esi,%ebp
    11bb:	48 89 fb             	mov    %rdi,%rbx
    11be:	78 2a                	js     11ea <calculate+0x3a>
    11c0:	48 89 df             	mov    %rbx,%rdi
    11c3:	e8 88 fe ff ff       	call   1050 <__wrap_malloc@plt>
    11c8:	48 85 c0             	test   %rax,%rax
    11cb:	74 1d                	je     11ea <calculate+0x3a>
    11cd:	48 89 c7             	mov    %rax,%rdi
    11d0:	b0 01                	mov    $0x1,%al
    11d2:	a8 01                	test   $0x1,%al
    11d4:	75 1c                	jne    11f2 <calculate+0x42>
    11d6:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    11dc:	48 85 ff             	test   %rdi,%rdi
    11df:	0f 85 50 02 00 00    	jne    1435 <calculate+0x285>
    11e5:	e9 50 02 00 00       	jmp    143a <calculate+0x28a>
    11ea:	31 ff                	xor    %edi,%edi
    11ec:	31 c0                	xor    %eax,%eax
    11ee:	a8 01                	test   $0x1,%al
    11f0:	74 e4                	je     11d6 <calculate+0x26>
    11f2:	48 83 fb 03          	cmp    $0x3,%rbx
    11f6:	77 0f                	ja     1207 <calculate+0x57>
    11f8:	31 c9                	xor    %ecx,%ecx
    11fa:	e9 f7 01 00 00       	jmp    13f6 <calculate+0x246>
    11ff:	45 31 f6             	xor    %r14d,%r14d
    1202:	e9 33 02 00 00       	jmp    143a <calculate+0x28a>
    1207:	66 0f 6e c5          	movd   %ebp,%xmm0
    120b:	48 83 fb 10          	cmp    $0x10,%rbx
    120f:	73 07                	jae    1218 <calculate+0x68>
    1211:	31 c9                	xor    %ecx,%ecx
    1213:	e9 51 01 00 00       	jmp    1369 <calculate+0x1b9>
    1218:	48 89 d9             	mov    %rbx,%rcx
    121b:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
    121f:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    1224:	66 0f 6f 15 d4 1d 00 	movdqa 0x1dd4(%rip),%xmm2        # 3000 <_fini+0xe78>
    122b:	00 
    122c:	66 0f 6f 1d dc 1d 00 	movdqa 0x1ddc(%rip),%xmm3        # 3010 <_fini+0xe88>
    1233:	00 
    1234:	66 0f 6f 25 e4 1d 00 	movdqa 0x1de4(%rip),%xmm4        # 3020 <_fini+0xe98>
    123b:	00 
    123c:	66 0f 6f 2d ec 1d 00 	movdqa 0x1dec(%rip),%xmm5        # 3030 <_fini+0xea8>
    1243:	00 
    1244:	31 c0                	xor    %eax,%eax
    1246:	66 0f 70 f1 f5       	pshufd $0xf5,%xmm1,%xmm6
    124b:	66 0f 6f 3d ed 1d 00 	movdqa 0x1ded(%rip),%xmm7        # 3040 <_fini+0xeb8>
    1252:	00 
    1253:	66 44 0f 6f 05 f4 1d 	movdqa 0x1df4(%rip),%xmm8        # 3050 <_fini+0xec8>
    125a:	00 00 
    125c:	66 44 0f 6f 0d fb 1d 	movdqa 0x1dfb(%rip),%xmm9        # 3060 <_fini+0xed8>
    1263:	00 00 
    1265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    126c:	00 00 00 00 
    1270:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    1275:	66 44 0f f4 d2       	pmuludq %xmm2,%xmm10
    127a:	66 45 0f 70 d2 e8    	pshufd $0xe8,%xmm10,%xmm10
    1280:	66 44 0f 70 da f5    	pshufd $0xf5,%xmm2,%xmm11
    1286:	66 44 0f f4 de       	pmuludq %xmm6,%xmm11
    128b:	66 45 0f 70 db e8    	pshufd $0xe8,%xmm11,%xmm11
    1291:	66 45 0f 62 d3       	punpckldq %xmm11,%xmm10
    1296:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    129b:	66 44 0f f4 db       	pmuludq %xmm3,%xmm11
    12a0:	66 45 0f 70 db e8    	pshufd $0xe8,%xmm11,%xmm11
    12a6:	66 44 0f 70 e3 f5    	pshufd $0xf5,%xmm3,%xmm12
    12ac:	66 44 0f f4 e6       	pmuludq %xmm6,%xmm12
    12b1:	66 45 0f 70 e4 e8    	pshufd $0xe8,%xmm12,%xmm12
    12b7:	66 45 0f 62 dc       	punpckldq %xmm12,%xmm11
    12bc:	66 44 0f 6f e1       	movdqa %xmm1,%xmm12
    12c1:	66 44 0f f4 e4       	pmuludq %xmm4,%xmm12
    12c6:	66 45 0f 70 e4 e8    	pshufd $0xe8,%xmm12,%xmm12
    12cc:	66 44 0f 70 ec f5    	pshufd $0xf5,%xmm4,%xmm13
    12d2:	66 44 0f f4 ee       	pmuludq %xmm6,%xmm13
    12d7:	66 45 0f 70 ed e8    	pshufd $0xe8,%xmm13,%xmm13
    12dd:	66 45 0f 62 e5       	punpckldq %xmm13,%xmm12
    12e2:	66 44 0f 6f e9       	movdqa %xmm1,%xmm13
    12e7:	66 44 0f f4 ed       	pmuludq %xmm5,%xmm13
    12ec:	66 45 0f 70 ed e8    	pshufd $0xe8,%xmm13,%xmm13
    12f2:	66 44 0f 70 f5 f5    	pshufd $0xf5,%xmm5,%xmm14
    12f8:	66 44 0f f4 f6       	pmuludq %xmm6,%xmm14
    12fd:	66 45 0f 70 f6 e8    	pshufd $0xe8,%xmm14,%xmm14
    1303:	66 45 0f 62 ee       	punpckldq %xmm14,%xmm13
    1308:	66 44 0f db ef       	pand   %xmm7,%xmm13
    130d:	66 44 0f db e7       	pand   %xmm7,%xmm12
    1312:	66 45 0f 67 ec       	packuswb %xmm12,%xmm13
    1317:	66 44 0f db df       	pand   %xmm7,%xmm11
    131c:	66 44 0f db d7       	pand   %xmm7,%xmm10
    1321:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    1326:	66 45 0f 67 eb       	packuswb %xmm11,%xmm13
    132b:	66 45 0f fc e8       	paddb  %xmm8,%xmm13
    1330:	f3 44 0f 7f 2c 07    	movdqu %xmm13,(%rdi,%rax,1)
    1336:	48 83 c0 10          	add    $0x10,%rax
    133a:	66 41 0f fe e9       	paddd  %xmm9,%xmm5
    133f:	66 41 0f fe e1       	paddd  %xmm9,%xmm4
    1344:	66 41 0f fe d9       	paddd  %xmm9,%xmm3
    1349:	66 41 0f fe d1       	paddd  %xmm9,%xmm2
    134e:	48 39 c1             	cmp    %rax,%rcx
    1351:	0f 85 19 ff ff ff    	jne    1270 <calculate+0xc0>
    1357:	48 39 cb             	cmp    %rcx,%rbx
    135a:	0f 84 ae 00 00 00    	je     140e <calculate+0x25e>
    1360:	f6 c3 0c             	test   $0xc,%bl
    1363:	0f 84 8d 00 00 00    	je     13f6 <calculate+0x246>
    1369:	48 89 c8             	mov    %rcx,%rax
    136c:	48 89 d9             	mov    %rbx,%rcx
    136f:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    1373:	66 0f 6e c8          	movd   %eax,%xmm1
    1377:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
    137c:	66 0f eb 0d ac 1c 00 	por    0x1cac(%rip),%xmm1        # 3030 <_fini+0xea8>
    1383:	00 
    1384:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1389:	66 0f 70 d0 f5       	pshufd $0xf5,%xmm0,%xmm2
    138e:	66 0f 6f 1d aa 1c 00 	movdqa 0x1caa(%rip),%xmm3        # 3040 <_fini+0xeb8>
    1395:	00 
    1396:	66 0f 6f 25 d2 1c 00 	movdqa 0x1cd2(%rip),%xmm4        # 3070 <_fini+0xee8>
    139d:	00 
    139e:	66 0f 6f 2d da 1c 00 	movdqa 0x1cda(%rip),%xmm5        # 3080 <_fini+0xef8>
    13a5:	00 
    13a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    13ad:	00 00 00 
    13b0:	66 0f 6f f0          	movdqa %xmm0,%xmm6
    13b4:	66 0f f4 f1          	pmuludq %xmm1,%xmm6
    13b8:	66 0f 70 f6 e8       	pshufd $0xe8,%xmm6,%xmm6
    13bd:	66 0f 70 f9 f5       	pshufd $0xf5,%xmm1,%xmm7
    13c2:	66 0f f4 fa          	pmuludq %xmm2,%xmm7
    13c6:	66 0f 70 ff e8       	pshufd $0xe8,%xmm7,%xmm7
    13cb:	66 0f 62 f7          	punpckldq %xmm7,%xmm6
    13cf:	66 0f db f3          	pand   %xmm3,%xmm6
    13d3:	66 0f 67 f6          	packuswb %xmm6,%xmm6
    13d7:	66 0f 67 f6          	packuswb %xmm6,%xmm6
    13db:	66 0f fc f4          	paddb  %xmm4,%xmm6
    13df:	66 0f 7e 34 07       	movd   %xmm6,(%rdi,%rax,1)
    13e4:	48 83 c0 04          	add    $0x4,%rax
    13e8:	66 0f fe cd          	paddd  %xmm5,%xmm1
    13ec:	48 39 c1             	cmp    %rax,%rcx
    13ef:	75 bf                	jne    13b0 <calculate+0x200>
    13f1:	48 39 cb             	cmp    %rcx,%rbx
    13f4:	74 18                	je     140e <calculate+0x25e>
    13f6:	89 c8                	mov    %ecx,%eax
    13f8:	40 f6 e5             	mul    %bpl
    13fb:	04 11                	add    $0x11,%al
    13fd:	0f 1f 00             	nopl   (%rax)
    1400:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    1403:	48 ff c1             	inc    %rcx
    1406:	40 00 e8             	add    %bpl,%al
    1409:	48 39 cb             	cmp    %rcx,%rbx
    140c:	75 f2                	jne    1400 <calculate+0x250>
    140e:	31 c0                	xor    %eax,%eax
    1410:	45 31 f6             	xor    %r14d,%r14d
    1413:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    141a:	84 00 00 00 00 00 
    1420:	4c 89 f1             	mov    %r14,%rcx
    1423:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1428:	49 01 ce             	add    %rcx,%r14
    142b:	72 15                	jb     1442 <calculate+0x292>
    142d:	48 ff c0             	inc    %rax
    1430:	48 39 c3             	cmp    %rax,%rbx
    1433:	75 eb                	jne    1420 <calculate+0x270>
    1435:	e8 56 fc ff ff       	call   1090 <__wrap_free@plt>
    143a:	4c 89 f0             	mov    %r14,%rax
    143d:	5b                   	pop    %rbx
    143e:	41 5e                	pop    %r14
    1440:	5d                   	pop    %rbp
    1441:	c3                   	ret
    1442:	e8 f9 fb ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
