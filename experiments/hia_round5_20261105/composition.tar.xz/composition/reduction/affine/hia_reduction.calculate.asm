
/data/hepta-hia-round5-a3b4-20261105/evidence/frozen-0a06ef4f0894-r1/composition/reduction/affine/hia_reduction.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	89 f5                	mov    %esi,%ebp
    11b6:	48 89 fb             	mov    %rdi,%rbx
    11b9:	48 b8 02 01 01 01 01 	movabs $0x101010101010102,%rax
    11c0:	01 01 01 
    11c3:	48 39 c7             	cmp    %rax,%rdi
    11c6:	73 2e                	jae    11f6 <calculate+0x46>
    11c8:	48 85 db             	test   %rbx,%rbx
    11cb:	0f 84 77 01 00 00    	je     1348 <calculate+0x198>
    11d1:	48 89 df             	mov    %rbx,%rdi
    11d4:	e8 77 fe ff ff       	call   1050 <__wrap_malloc@plt>
    11d9:	48 85 c0             	test   %rax,%rax
    11dc:	0f 84 6e 01 00 00    	je     1350 <calculate+0x1a0>
    11e2:	48 89 c7             	mov    %rax,%rdi
    11e5:	48 83 fb 03          	cmp    $0x3,%rbx
    11e9:	0f 87 6c 01 00 00    	ja     135b <calculate+0x1ab>
    11ef:	31 c9                	xor    %ecx,%ecx
    11f1:	e9 99 02 00 00       	jmp    148f <calculate+0x2df>
    11f6:	48 85 db             	test   %rbx,%rbx
    11f9:	78 2a                	js     1225 <calculate+0x75>
    11fb:	48 89 df             	mov    %rbx,%rdi
    11fe:	e8 4d fe ff ff       	call   1050 <__wrap_malloc@plt>
    1203:	48 85 c0             	test   %rax,%rax
    1206:	74 1d                	je     1225 <calculate+0x75>
    1208:	48 89 c7             	mov    %rax,%rdi
    120b:	b0 01                	mov    $0x1,%al
    120d:	a8 01                	test   $0x1,%al
    120f:	75 1c                	jne    122d <calculate+0x7d>
    1211:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1217:	48 85 ff             	test   %rdi,%rdi
    121a:	0f 85 f5 03 00 00    	jne    1615 <calculate+0x465>
    1220:	e9 f5 03 00 00       	jmp    161a <calculate+0x46a>
    1225:	31 ff                	xor    %edi,%edi
    1227:	31 c0                	xor    %eax,%eax
    1229:	a8 01                	test   $0x1,%al
    122b:	74 e4                	je     1211 <calculate+0x61>
    122d:	48 89 d8             	mov    %rbx,%rax
    1230:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    1234:	66 0f 6e c5          	movd   %ebp,%xmm0
    1238:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    123c:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1241:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    1246:	66 0f 6f 15 b2 1d 00 	movdqa 0x1db2(%rip),%xmm2        # 3000 <_fini+0xc98>
    124d:	00 
    124e:	31 c9                	xor    %ecx,%ecx
    1250:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1254:	66 0f 68 db          	punpckhbw %xmm3,%xmm3
    1258:	66 0f 6f 05 b0 1d 00 	movdqa 0x1db0(%rip),%xmm0        # 3010 <_fini+0xca8>
    125f:	00 
    1260:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1264:	66 0f 6f 25 b4 1d 00 	movdqa 0x1db4(%rip),%xmm4        # 3020 <_fini+0xcb8>
    126b:	00 
    126c:	66 0f 6f 2d bc 1d 00 	movdqa 0x1dbc(%rip),%xmm5        # 3030 <_fini+0xcc8>
    1273:	00 
    1274:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    127b:	00 00 00 00 00 
    1280:	66 0f 6f f2          	movdqa %xmm2,%xmm6
    1284:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
    1288:	66 0f d5 f3          	pmullw %xmm3,%xmm6
    128c:	66 0f db f0          	pand   %xmm0,%xmm6
    1290:	66 0f 6f fa          	movdqa %xmm2,%xmm7
    1294:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    1298:	66 0f d5 f9          	pmullw %xmm1,%xmm7
    129c:	66 0f db f8          	pand   %xmm0,%xmm7
    12a0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
    12a4:	66 0f fc fc          	paddb  %xmm4,%xmm7
    12a8:	f3 0f 7f 3c 0f       	movdqu %xmm7,(%rdi,%rcx,1)
    12ad:	48 83 c1 10          	add    $0x10,%rcx
    12b1:	66 0f fc d5          	paddb  %xmm5,%xmm2
    12b5:	48 39 c8             	cmp    %rcx,%rax
    12b8:	75 c6                	jne    1280 <calculate+0xd0>
    12ba:	48 39 c3             	cmp    %rax,%rbx
    12bd:	0f 84 2b 03 00 00    	je     15ee <calculate+0x43e>
    12c3:	f6 c3 0c             	test   $0xc,%bl
    12c6:	0f 84 ff 02 00 00    	je     15cb <calculate+0x41b>
    12cc:	48 89 d9             	mov    %rbx,%rcx
    12cf:	66 0f 6e c8          	movd   %eax,%xmm1
    12d3:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    12d7:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    12dc:	66 0f eb 0d 5c 1d 00 	por    0x1d5c(%rip),%xmm1        # 3040 <_fini+0xcd8>
    12e3:	00 
    12e4:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    12e8:	40 0f b6 d5          	movzbl %bpl,%edx
    12ec:	66 0f 6e d2          	movd   %edx,%xmm2
    12f0:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
    12f4:	f2 0f 70 d2 00       	pshuflw $0x0,%xmm2,%xmm2
    12f9:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
    12fd:	66 0f 6f 1d 4b 1d 00 	movdqa 0x1d4b(%rip),%xmm3        # 3050 <_fini+0xce8>
    1304:	00 
    1305:	66 0f 6f 25 53 1d 00 	movdqa 0x1d53(%rip),%xmm4        # 3060 <_fini+0xcf8>
    130c:	00 
    130d:	0f 1f 00             	nopl   (%rax)
    1310:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    1314:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    1318:	66 0f d5 ea          	pmullw %xmm2,%xmm5
    131c:	66 0f db e8          	pand   %xmm0,%xmm5
    1320:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    1324:	66 0f fc eb          	paddb  %xmm3,%xmm5
    1328:	66 0f 7e 2c 07       	movd   %xmm5,(%rdi,%rax,1)
    132d:	48 83 c0 04          	add    $0x4,%rax
    1331:	66 0f fc cc          	paddb  %xmm4,%xmm1
    1335:	48 39 c1             	cmp    %rax,%rcx
    1338:	75 d6                	jne    1310 <calculate+0x160>
    133a:	48 39 cb             	cmp    %rcx,%rbx
    133d:	0f 85 8b 02 00 00    	jne    15ce <calculate+0x41e>
    1343:	e9 a6 02 00 00       	jmp    15ee <calculate+0x43e>
    1348:	45 31 f6             	xor    %r14d,%r14d
    134b:	e9 ca 02 00 00       	jmp    161a <calculate+0x46a>
    1350:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1356:	e9 bf 02 00 00       	jmp    161a <calculate+0x46a>
    135b:	48 ba f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rdx
    1362:	ff ff 01 
    1365:	40 0f b6 c5          	movzbl %bpl,%eax
    1369:	48 83 fb 10          	cmp    $0x10,%rbx
    136d:	73 07                	jae    1376 <calculate+0x1c6>
    136f:	31 c9                	xor    %ecx,%ecx
    1371:	e9 96 00 00 00       	jmp    140c <calculate+0x25c>
    1376:	48 89 d9             	mov    %rbx,%rcx
    1379:	48 21 d1             	and    %rdx,%rcx
    137c:	66 0f 6e c0          	movd   %eax,%xmm0
    1380:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1384:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1389:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    138e:	66 0f 6f 0d 6a 1c 00 	movdqa 0x1c6a(%rip),%xmm1        # 3000 <_fini+0xc98>
    1395:	00 
    1396:	31 f6                	xor    %esi,%esi
    1398:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    139c:	66 0f 68 d2          	punpckhbw %xmm2,%xmm2
    13a0:	66 0f 6f 1d 68 1c 00 	movdqa 0x1c68(%rip),%xmm3        # 3010 <_fini+0xca8>
    13a7:	00 
    13a8:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    13ac:	66 0f 6f 25 6c 1c 00 	movdqa 0x1c6c(%rip),%xmm4        # 3020 <_fini+0xcb8>
    13b3:	00 
    13b4:	66 0f 6f 2d 74 1c 00 	movdqa 0x1c74(%rip),%xmm5        # 3030 <_fini+0xcc8>
    13bb:	00 
    13bc:	0f 1f 40 00          	nopl   0x0(%rax)
    13c0:	66 0f 6f f1          	movdqa %xmm1,%xmm6
    13c4:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
    13c8:	66 0f d5 f2          	pmullw %xmm2,%xmm6
    13cc:	66 0f db f3          	pand   %xmm3,%xmm6
    13d0:	66 0f 6f f9          	movdqa %xmm1,%xmm7
    13d4:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    13d8:	66 0f d5 f8          	pmullw %xmm0,%xmm7
    13dc:	66 0f db fb          	pand   %xmm3,%xmm7
    13e0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
    13e4:	66 0f fc fc          	paddb  %xmm4,%xmm7
    13e8:	f3 0f 7f 3c 37       	movdqu %xmm7,(%rdi,%rsi,1)
    13ed:	48 83 c6 10          	add    $0x10,%rsi
    13f1:	66 0f fc cd          	paddb  %xmm5,%xmm1
    13f5:	48 39 f1             	cmp    %rsi,%rcx
    13f8:	75 c6                	jne    13c0 <calculate+0x210>
    13fa:	48 39 cb             	cmp    %rcx,%rbx
    13fd:	0f 84 ab 00 00 00    	je     14ae <calculate+0x2fe>
    1403:	f6 c3 0c             	test   $0xc,%bl
    1406:	0f 84 83 00 00 00    	je     148f <calculate+0x2df>
    140c:	48 89 ce             	mov    %rcx,%rsi
    140f:	48 83 c2 0c          	add    $0xc,%rdx
    1413:	48 89 d1             	mov    %rdx,%rcx
    1416:	66 0f 6e c6          	movd   %esi,%xmm0
    141a:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    141e:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1423:	66 0f eb 05 15 1c 00 	por    0x1c15(%rip),%xmm0        # 3040 <_fini+0xcd8>
    142a:	00 
    142b:	48 21 d9             	and    %rbx,%rcx
    142e:	66 0f 6e c8          	movd   %eax,%xmm1
    1432:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1436:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    143b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    143f:	66 0f 6f 15 c9 1b 00 	movdqa 0x1bc9(%rip),%xmm2        # 3010 <_fini+0xca8>
    1446:	00 
    1447:	66 0f 6f 1d 01 1c 00 	movdqa 0x1c01(%rip),%xmm3        # 3050 <_fini+0xce8>
    144e:	00 
    144f:	66 0f 6f 25 09 1c 00 	movdqa 0x1c09(%rip),%xmm4        # 3060 <_fini+0xcf8>
    1456:	00 
    1457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    145e:	00 00 
    1460:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    1464:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    1468:	66 0f d5 e9          	pmullw %xmm1,%xmm5
    146c:	66 0f db ea          	pand   %xmm2,%xmm5
    1470:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    1474:	66 0f fc eb          	paddb  %xmm3,%xmm5
    1478:	66 0f 7e 2c 37       	movd   %xmm5,(%rdi,%rsi,1)
    147d:	48 83 c6 04          	add    $0x4,%rsi
    1481:	66 0f fc c4          	paddb  %xmm4,%xmm0
    1485:	48 39 f1             	cmp    %rsi,%rcx
    1488:	75 d6                	jne    1460 <calculate+0x2b0>
    148a:	48 39 cb             	cmp    %rcx,%rbx
    148d:	74 1f                	je     14ae <calculate+0x2fe>
    148f:	89 c8                	mov    %ecx,%eax
    1491:	40 f6 e5             	mul    %bpl
    1494:	04 11                	add    $0x11,%al
    1496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    149d:	00 00 00 
    14a0:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    14a3:	48 ff c1             	inc    %rcx
    14a6:	40 00 e8             	add    %bpl,%al
    14a9:	48 39 cb             	cmp    %rcx,%rbx
    14ac:	75 f2                	jne    14a0 <calculate+0x2f0>
    14ae:	48 83 fb 10          	cmp    $0x10,%rbx
    14b2:	72 5a                	jb     150e <calculate+0x35e>
    14b4:	b8 10 00 00 00       	mov    $0x10,%eax
    14b9:	45 31 f6             	xor    %r14d,%r14d
    14bc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    14c0:	48 89 d9             	mov    %rbx,%rcx
    14c3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    14ca:	84 00 00 00 00 00 
    14d0:	48 89 c2             	mov    %rax,%rdx
    14d3:	f3 0f 6f 4c 07 f0    	movdqu -0x10(%rdi,%rax,1),%xmm1
    14d9:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    14dd:	66 48 0f 7e c8       	movq   %xmm1,%rax
    14e2:	4c 01 f0             	add    %r14,%rax
    14e5:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
    14ea:	66 49 0f 7e ce       	movq   %xmm1,%r14
    14ef:	49 01 c6             	add    %rax,%r14
    14f2:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
    14f6:	48 8d 42 10          	lea    0x10(%rdx),%rax
    14fa:	48 39 da             	cmp    %rbx,%rdx
    14fd:	0f 96 c2             	setbe  %dl
    1500:	77 06                	ja     1508 <calculate+0x358>
    1502:	48 83 f9 0f          	cmp    $0xf,%rcx
    1506:	77 c8                	ja     14d0 <calculate+0x320>
    1508:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
    150c:	eb 0a                	jmp    1518 <calculate+0x368>
    150e:	b2 01                	mov    $0x1,%dl
    1510:	31 c0                	xor    %eax,%eax
    1512:	45 31 f6             	xor    %r14d,%r14d
    1515:	48 89 d9             	mov    %rbx,%rcx
    1518:	48 83 f9 08          	cmp    $0x8,%rcx
    151c:	0f 92 c1             	setb   %cl
    151f:	80 f2 01             	xor    $0x1,%dl
    1522:	08 ca                	or     %cl,%dl
    1524:	75 19                	jne    153f <calculate+0x38f>
    1526:	f3 0f 7e 04 07       	movq   (%rdi,%rax,1),%xmm0
    152b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    152f:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    1533:	66 48 0f 7e c9       	movq   %xmm1,%rcx
    1538:	49 01 ce             	add    %rcx,%r14
    153b:	48 83 c0 08          	add    $0x8,%rax
    153f:	48 89 c1             	mov    %rax,%rcx
    1542:	48 29 d9             	sub    %rbx,%rcx
    1545:	0f 83 ca 00 00 00    	jae    1615 <calculate+0x465>
    154b:	89 da                	mov    %ebx,%edx
    154d:	29 c2                	sub    %eax,%edx
    154f:	83 e2 07             	and    $0x7,%edx
    1552:	74 1b                	je     156f <calculate+0x3bf>
    1554:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    155b:	00 00 00 00 00 
    1560:	0f b6 34 07          	movzbl (%rdi,%rax,1),%esi
    1564:	49 01 f6             	add    %rsi,%r14
    1567:	48 ff c0             	inc    %rax
    156a:	48 ff ca             	dec    %rdx
    156d:	75 f1                	jne    1560 <calculate+0x3b0>
    156f:	48 83 f9 f8          	cmp    $0xfffffffffffffff8,%rcx
    1573:	0f 87 9c 00 00 00    	ja     1615 <calculate+0x465>
    1579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1580:	0f b6 0c 07          	movzbl (%rdi,%rax,1),%ecx
    1584:	4c 01 f1             	add    %r14,%rcx
    1587:	0f b6 54 07 01       	movzbl 0x1(%rdi,%rax,1),%edx
    158c:	0f b6 74 07 02       	movzbl 0x2(%rdi,%rax,1),%esi
    1591:	48 01 d6             	add    %rdx,%rsi
    1594:	48 01 ce             	add    %rcx,%rsi
    1597:	0f b6 4c 07 03       	movzbl 0x3(%rdi,%rax,1),%ecx
    159c:	0f b6 54 07 04       	movzbl 0x4(%rdi,%rax,1),%edx
    15a1:	48 01 ca             	add    %rcx,%rdx
    15a4:	0f b6 4c 07 05       	movzbl 0x5(%rdi,%rax,1),%ecx
    15a9:	48 01 d1             	add    %rdx,%rcx
    15ac:	48 01 f1             	add    %rsi,%rcx
    15af:	0f b6 54 07 06       	movzbl 0x6(%rdi,%rax,1),%edx
    15b4:	44 0f b6 74 07 07    	movzbl 0x7(%rdi,%rax,1),%r14d
    15ba:	49 01 d6             	add    %rdx,%r14
    15bd:	49 01 ce             	add    %rcx,%r14
    15c0:	48 83 c0 08          	add    $0x8,%rax
    15c4:	48 39 c3             	cmp    %rax,%rbx
    15c7:	75 b7                	jne    1580 <calculate+0x3d0>
    15c9:	eb 4a                	jmp    1615 <calculate+0x465>
    15cb:	48 89 c1             	mov    %rax,%rcx
    15ce:	89 c8                	mov    %ecx,%eax
    15d0:	40 f6 e5             	mul    %bpl
    15d3:	04 11                	add    $0x11,%al
    15d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    15dc:	00 00 00 00 
    15e0:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    15e3:	48 ff c1             	inc    %rcx
    15e6:	40 00 e8             	add    %bpl,%al
    15e9:	48 39 cb             	cmp    %rcx,%rbx
    15ec:	75 f2                	jne    15e0 <calculate+0x430>
    15ee:	31 c0                	xor    %eax,%eax
    15f0:	45 31 f6             	xor    %r14d,%r14d
    15f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    15fa:	84 00 00 00 00 00 
    1600:	4c 89 f1             	mov    %r14,%rcx
    1603:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1608:	49 01 ce             	add    %rcx,%r14
    160b:	72 15                	jb     1622 <calculate+0x472>
    160d:	48 ff c0             	inc    %rax
    1610:	48 39 c3             	cmp    %rax,%rbx
    1613:	75 eb                	jne    1600 <calculate+0x450>
    1615:	e8 76 fa ff ff       	call   1090 <__wrap_free@plt>
    161a:	4c 89 f0             	mov    %r14,%rax
    161d:	5b                   	pop    %rbx
    161e:	41 5e                	pop    %r14
    1620:	5d                   	pop    %rbp
    1621:	c3                   	ret
    1622:	e8 19 fa ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
