#include <cstddef>
#include <cstdint>
unsigned long long run_reset_v2(unsigned long, unsigned long, unsigned char,
                          unsigned long, unsigned int, unsigned int) noexcept;
extern "C" std::uint64_t composed_case(std::size_t left, std::size_t right, std::uint8_t value,
    std::size_t index, std::uint32_t reject, std::uint32_t early) noexcept {
    return run_reset_v2(left, right, value, index, reject, early);
}
