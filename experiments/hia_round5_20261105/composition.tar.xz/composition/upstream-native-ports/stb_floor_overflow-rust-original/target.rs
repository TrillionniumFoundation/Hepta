pub fn target(v1:i32,v2:i32)->i32 {
    if v1 >= 0 && v2 < 0 {
        if (-v1)+v2+1 < 0 { return -((-v1+v2+1)/v2); }
        else { return -((-v1)/v2) + if (-v1)%v2 != 0 {-1} else {0}; }
    }
    if v1 < 0 && v2 >= 0 {
        if v1 != i32::MIN {
            if v1-v2+1 < 0 { return -((v1-v2+1)/(-v2)); }
            else { return -((-v1)/v2) + if v1%(-v2) != 0 {-1} else {0}; }
        } else {
            return -((-(v1+v2))/v2) + if (-(v1+v2))%v2 != 0 {-2} else {-1};
        }
    } else { return v1/v2; }
}
