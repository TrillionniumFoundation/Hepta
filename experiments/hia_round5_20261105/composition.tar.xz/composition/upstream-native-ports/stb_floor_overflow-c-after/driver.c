#define STB_DIVIDE_IMPLEMENTATION
#include "stb_divide.h"
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
_Static_assert(sizeof(int)==4,"32-bit C int required");
int main(void) { int32_t a,b; while(scanf("%" SCNd32 " %" SCNd32,&a,&b)==2) { printf("%" PRId32 "\n",stb_div_floor(a,b)); fflush(stdout); } return 0; }
