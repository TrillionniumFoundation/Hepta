pub fn target(v1:i32,v2:i32)->i32 {
    let a=v1 as i64; let b=v2 as i64;
    let q=a/b; let r=a%b;
    if (r>0 && b<0) || (r<0 && b>0) { (q-1) as i32 } else { q as i32 }
}
