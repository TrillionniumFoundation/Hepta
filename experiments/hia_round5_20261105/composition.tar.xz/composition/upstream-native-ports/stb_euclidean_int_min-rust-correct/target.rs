pub fn target(v1:i32,v2:i32)->i32 {
    let r=v1%v2;
    if r >= 0 { r } else { r - if v2<0 {v2} else {-v2} }
}
