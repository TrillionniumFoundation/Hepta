#![forbid(unsafe_code)]
#[path="target.rs"] mod api;
use std::io::{self,BufRead};
fn main() {
    let target:fn(i32,i32)->i32=api::target;
    for line in io::stdin().lock().lines() {
        let values:Vec<i32>=line.unwrap().split_whitespace().map(|v|v.parse().unwrap()).collect();
        println!("{}",target(values[0],values[1]));
    }
}
