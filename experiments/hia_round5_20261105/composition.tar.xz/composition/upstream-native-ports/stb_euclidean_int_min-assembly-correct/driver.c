#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
extern int32_t target(int32_t,int32_t);
int main(void) {
    int32_t a,b;
    while(scanf("%" SCNd32 " %" SCNd32,&a,&b)==2) {
        printf("%" PRId32 "\n",target(a,b)); fflush(stdout);
    }
    return 0;
}
