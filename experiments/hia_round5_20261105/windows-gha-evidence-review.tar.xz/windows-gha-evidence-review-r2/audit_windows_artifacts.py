#!/usr/bin/env python3
"""Read-only GitHub artifact, source binding, retained bytes and oracle audit."""
import base64
import datetime
import hashlib
import json
import ntpath
import os
import pathlib
import stat
import sys
import time
import zipfile

ROOT = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/delivery-audit-r1/windows-gha-artifacts-r1')
SOURCE = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/work-integration')
HEAD = '67da0ab0a51203f6f640c4459bc15bef442885b8'
MEASURED_HEAD = '0a06ef4f0894681af92b0caefba0704c1278d2cc'
TREE = 'a5239982f9fd8f08ab3a6e791147fc989e8d9df6'
SNAPSHOT = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/independent-analysis-0a06ef4f0894-r1/GITHUB_SNAPSHOT_20261105T235141Z.json')
SNAPSHOT_SHA = '93fac6e336b02eb6a621ddcf325f8c25b828c6aa5d8749a5b2474f0b1819fd04'
JOBS = {13462982914: 127608284785, 13462714569: 127608285285,
        13464400891: 127608287181, 13462749878: 127608287194}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def ident(b):
    return {'bytes': len(b), 'sha256': sha(b)}

def norm(p):
    p = p.replace('\\', '/')
    q = pathlib.PurePosixPath(p)
    assert not q.is_absolute() and '..' not in q.parts and ':' not in p
    return q.as_posix()

def wire(d):
    return (json.dumps(d, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()

def write(p, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(b)

def walk(x):
    if isinstance(x, dict):
        yield x
        for v in x.values():
            yield from walk(v)
    elif isinstance(x, list):
        for v in x:
            yield from walk(v)
    elif isinstance(x, str) and x.startswith(('{', '[')):
        try:
            j = json.loads(x)
        except (ValueError, RecursionError):
            return
        yield from walk(j)

def source_comparison(files):
    matched, differences, absent = [], [], []
    for key, expected in files.items():
        rel = norm(key)
        p = SOURCE / rel
        if not p.is_file():
            absent.append(rel)
            continue
        actual = sha(p.read_bytes())
        if actual == expected:
            matched.append(rel)
        else:
            differences.append({'path': rel, 'windows_sha256': expected, 'linux_sha256': actual})
    return {'matched_file_count': len(matched), 'different_bytes': differences, 'absent_paths': absent,
            'scope': 'Direct recorded source-file byte comparison to the frozen Linux checkout, after path separator normalization only.'}

class Archive:
    def __init__(self, metadata):
        self.metadata = metadata
        self.id = metadata['id']
        self.path = ROOT / f'artifact-{self.id}.zip'
        self.bytes = self.path.read_bytes()
        assert len(self.bytes) == metadata['size_in_bytes']
        assert 'sha256:' + sha(self.bytes) == metadata['digest']
        assert metadata['workflow_run']['head_sha'] == HEAD
        self.files = {}
        with zipfile.ZipFile(self.path) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = norm(info.filename)
                assert name not in self.files
                mode = info.external_attr >> 16
                assert not stat.S_ISLNK(mode)
                self.files[name] = z.read(info)
        self.checked = set()
        self.streams = set()
        self.embedded_streams = 0

    def j(self, path):
        return json.loads(self.files[path])

    def check(self, path, row):
        path = norm(path)
        actual = ident(self.files[path])
        assert actual['sha256'] == row['sha256'], path
        if 'bytes' in row:
            assert actual['bytes'] == row['bytes'], path
        self.checked.add(path)

    def mapped(self, absolute, original, prefix):
        rel = ntpath.relpath(absolute, original)
        assert not rel.startswith('..')
        return norm(prefix + '/' + rel)

    def process_streams(self, value, original, prefix):
        for d in walk(value):
            for name in ('stdout', 'stderr'):
                pk, hk = name + '_path', name + '_sha256'
                if pk in d and hk in d:
                    path = self.mapped(d[pk], original, prefix)
                    self.check(path, {'sha256': d[hk]})
                    self.streams.add(path)
                    if name + '_bytes_base64' in d:
                        assert self.files[path] == base64.b64decode(d[name + '_bytes_base64'], validate=True)
                for bk, sk, nk in ((name + '_raw_base64', name + '_raw_sha256', name + '_raw_bytes'),
                                   (name + '_bytes_base64', name + '_sha256', None)):
                    if bk in d and sk in d:
                        b = base64.b64decode(d[bk], validate=True)
                        assert sha(b) == d[sk]
                        if nk and nk in d:
                            assert len(b) == d[nk]
                        self.embedded_streams += 1

    def summary(self):
        return {'artifact_id': self.id, 'github_artifact': self.metadata,
                'archive': dict(ident(self.bytes), path=str(self.path)),
                'zip_regular_file_count': len(self.files),
                'zip_files': {k: ident(v) for k, v in sorted(self.files.items())},
                'checked_retained_file_count': len(self.checked),
                'checked_retained_files': sorted(self.checked),
                'separately_checked_raw_stream_file_count': len(self.streams),
                'checked_embedded_stream_records': self.embedded_streams}

def cpp(a):
    c = a.j('cpp-upstream-host.json')
    assert c == a.j('cpp-upstream-host/qualification.json')
    assert c['status'] == 'passed' and c['ok'] and c['inputs_unchanged']
    assert c['source_commit'] == HEAD
    before, after = c['source_checkout_before'], c['source_checkout_after']
    assert before == after and before['commit'] == HEAD and before['tree'] == TREE
    assert before['tracked_status'] == '' and before['casefold_collisions'] == []
    assert c['tracked_source_status'] == c['tracked_source_status_after'] == ''
    retained = c['retained_files']
    for name, row in retained.items():
        a.check('cpp-upstream-host/' + name, row)
    actual = {k[len('cpp-upstream-host/'):] for k in a.files if k.startswith('cpp-upstream-host/')}
    assert actual == {norm(x) for x in retained} | {'qualification.json', 'audit.json'}
    a.process_streams(c, c['directory'], 'cpp-upstream-host')
    versions = []
    for v in c['versions']:
        assert v['status'] == 'passed'
        e = v['execution']
        assert e['exit_code'] == 0 and e['executable_unchanged']
        exe = a.mapped(e['argv'][0], c['directory'], 'cpp-upstream-host')
        a.check(exe, v['executable'])
        assert a.files[exe][:2] == b'MZ' and v['executable']['format'] == 'PE32+'
        assert e['executable_sha256'] == v['executable']['sha256']
        observed = v['observed']
        raw = a.files[a.mapped(e['stdout_path'], c['directory'], 'cpp-upstream-host')]
        assert json.loads(raw) == observed
        rows = observed['cases']
        assert len(rows) == 98 and len({x['id'] for x in rows}) == 98
        assert all(x['direct_status'] == x['hepta_status'] and x['direct_value'] == x['hepta_value'] and x['live_delta'] == 0 for x in rows)
        assert observed['ordinary_live_delta'] == 0
        assert observed['cancellation'] == {'committed': 3, 'replayed': 0, 'requested': 7, 'value': 107}
        assert v['native']['status'] == 'rustc_checked' and v['native']['target'] == 'x86_64-pc-windows-msvc'
        a.check(a.mapped(v['native']['artifact'], c['directory'], 'cpp-upstream-host'),
                {'sha256': v['native']['artifact_sha256'], 'bytes': v['native']['artifact_bytes']})
        versions.append({'version': v['version'], 'executable': v['executable'],
                         'execution_returncode': e['exit_code'], 'source_and_license': v['source_and_license'],
                         'native_object': {k: v['native'][k] for k in ('artifact_sha256', 'rust_sha256', 'status', 'target', 'toolchain')},
                         'observed': {k: val for k, val in observed.items() if k != 'cases'},
                         'case_count': len(rows), 'direct_hepta_status_value_and_live_delta_checked': True})
    assert [v['version'] for v in versions] == ['3.11.3', '3.12.0']
    wrong = c['wrong_code']
    assert wrong['status'] == 'rejected' and wrong['process']['exit_code'] == 2
    assert 'actual direct/Hepta result mismatch' in wrong['process']['stderr']
    a.check(a.mapped(wrong['process']['argv'][0], c['directory'], 'cpp-upstream-host'), wrong['artifact'])
    sig = c['incompatible_signature']
    assert not sig['ok'] and sig['status'] == 'rejected' and sig['execution'] == 'not_run'
    assert [x['code'] for x in sig['diagnostics']] == ['E_CPP_NATIVE']
    assert sig['failure']['phase'] == 'cpp_compile' and sig['failure']['process']['exit_code'] != 0
    marker = 'HEPTA_CPP_METHOD_RESULT'
    assert marker in sig['failure']['process']['stdout'] + sig['failure']['process']['stderr']
    for name in ('stdout', 'stderr'):
        path = a.mapped(c['incompatible_signature_evidence'][name], c['directory'], 'cpp-upstream-host')
        b = base64.b64decode(sig['failure']['process'][name + '_raw_base64'], validate=True)
        assert a.files[path] == b
        a.check(path, {'sha256': sig['failure']['process'][name + '_raw_sha256']})
        a.streams.add(path)
    original_audit = a.j('cpp-upstream-host/audit.json')
    assert original_audit['status'] == 'passed'
    return {'kind': 'cpp_upstream_host', 'status': 'passed', 'source_checkout': before,
            'source_inputs_comparison': source_comparison(c['source_inputs']),
            'host': c['host'], 'cxx': {k: c['cxx'][k] for k in ('path', 'version', 'identity', 'target', 'executable_sha256')},
            'compiler_sha256': c['compiler_sha256'], 'versions': versions,
            'wrong_code': {'returncode': 2, 'artifact': wrong['artifact'], 'actual_mismatch_marker': True},
            'incompatible_signature': {'rejected': True, 'code': 'E_CPP_NATIVE', 'actual_compiler_diagnostic_marker': marker},
            'original_read_only_audit': original_audit, 'claims': c['claims'],
            'backend_boundary': 'Retained nlohmann C++ upstream library is reused through the generated C ABI bridge. Actual Hepta consumer object is Rust backend; this is not a whole library HIA Core/LLVM rewrite.'}

def integer_oracle(a, b):
    assert b and not (a == -(1 << 31) and b == -1)
    trunc = (abs(a) // abs(b)) * (1 if (a >= 0) == (b >= 0) else -1)
    floor = a // b
    euclidean = (a - (a % abs(b))) // b
    return [trunc, floor, euclidean, a - trunc*b, a - floor*b, a - euclidean*b]

def abi(a):
    n = a.j('native-host.json')
    m = a.j('native-host-artifacts/manifest.json')
    assert n['status'] == 'passed'
    assert m['source_identity']['commit'] == HEAD and m['source_identity']['tree'] == TREE
    assert m['source_identity']['compiler_sha256'] == n['compiler_sha256']
    assert n['retained_evidence']['source_identity'] == m['source_identity']
    assert n['retained_evidence']['files'] == m['files']
    a.check('native-host-artifacts/manifest.json', n['retained_evidence']['manifest'])
    for name, row in m['files'].items():
        a.check('native-host-artifacts/' + name, row)
    actual = {k[len('native-host-artifacts/'):] for k in a.files if k.startswith('native-host-artifacts/')}
    assert actual == set(m['files']) | {'manifest.json'}
    for field, path in (('harness_sha256', 'matrix.c'), ('header_sha256', 'matrix.h'),
                        ('layout_probes_sha256', 'layout-probes.rs'), ('source_sha256', 'matrix.hepta')):
        a.check('native-host-artifacts/inputs/' + path, {'sha256': n[field]})
    native = n['native_object']
    assert native == a.j('native-host-artifacts/native-build.json')
    assert native['status'] == 'rustc_checked' and native['target'] == 'x86_64-pc-windows-msvc'
    a.check('native-host-artifacts/work/' + ntpath.basename(native['artifact']),
            {'sha256': native['artifact_sha256'], 'bytes': native['artifact_bytes']})
    a.check('native-host-artifacts/inputs/matrix.rs', {'sha256': native['rust_sha256']})
    assert len(n['executions']) == 2
    for e in n['executions']:
        assert e['returncode'] == 0 and e['layout_checked']
        assert e['observed'] == {'foreign_calls': 181, 'status': 'passed'}
    commands = a.j('native-host-artifacts/commands.json')
    native_observed = []
    for cmd in commands:
        streams = cmd['retained_streams']
        assert streams['complete']
        for stream in ('stdout', 'stderr'):
            a.check('native-host-artifacts/' + streams[stream]['path'], streams[stream])
            a.streams.add('native-host-artifacts/' + streams[stream]['path'])
        raw = a.files['native-host-artifacts/' + streams['stdout']['path']]
        try:
            obs = json.loads(raw)
        except ValueError:
            continue
        if isinstance(obs, dict) and 'foreign_calls' in obs:
            assert cmd['returncode'] == 0 and obs == {'foreign_calls': 181, 'status': 'passed'}
            native_observed.append(obs)
    assert len(native_observed) == 2
    for optimization, expected in zip(('O0', 'O2'), n['executable_sha256s']):
        a.check('native-host-artifacts/work/host-matrix-' + optimization + '.exe', {'sha256': expected})
    assert n['negative_control']['status'] == 'rejected_as_expected' and n['negative_control']['returncode'] != 0
    a.check('native-host-artifacts/work/wrong.exe', {'sha256': n['negative_control']['artifact_sha256']})
    assert len(n['type_negative_controls']) == 3 and all(x['status'] == 'rejected_as_expected' and x['returncode'] != 0 for x in n['type_negative_controls'])
    type_preflight = a.j('original-type-preflight.json')
    assert type_preflight == a.j('original-type-preflight/qualification.json')
    assert type_preflight['ok'] and type_preflight['native_program_executions'] == 0
    assert len(type_preflight['cases']) == 2 and all(x['passed'] for x in type_preflight['cases'])
    for case in type_preflight['cases']:
        a.check('original-type-preflight/' + case['name'] + '/migration.json', {'sha256': case['report_sha256']})
    s = a.j('stb-divide-host.json')
    assert s == a.j('stb-divide-host/qualification.json')
    assert s['ok'] and s['status'] == 'passed_for_actual_host_and_declared_component_variants'
    assert s['source_before'] == s['source_after'] and s['source_unchanged_during_run']
    assert s['source_before']['commit'] == HEAD and s['source_before']['tree'] == TREE and s['source_before']['status'] == ''
    for row in s['artifacts']:
        a.check('stb-divide-host/' + row['path'], row)
    expected_artifacts = {norm(x['path']) for x in s['artifacts']}
    actual = {k[len('stb-divide-host/'):] for k in a.files if k.startswith('stb-divide-host/')}
    assert actual == expected_artifacts | {'qualification.json'}
    cases_bytes = a.files['stb-divide-host/cases.jsonl']
    assert sha(cases_bytes) == s['corpus']['input_sha256']
    cases = [json.loads(line) for line in cases_bytes.splitlines()]
    assert len(cases) == s['corpus']['unique_inputs'] == 21453
    assert len({(row['a'], row['b']) for row in cases}) == len(cases)
    assert all(row['expected'] == integer_oracle(row['a'], row['b']) for row in cases)
    variants = []
    for variant in s['variants']:
        assert variant['name'] in ('generic', 'truncating')
        assert variant['rust_build']['status'] == 'rustc_checked'
        assert variant['rust_build']['target'] == 'x86_64-pc-windows-msvc'
        assert not variant['hia']['native_executed'] and not variant['hia']['native_requested']
        assert variant['hia']['interpreter_unique_inputs'] == 58
        assert variant['hia']['interpreter_function_observations'] == 348
        assert len(variant['executions']) == 1
        e = variant['executions'][0]
        assert e['generated_route'] == 'rust'
        assert e['summary']['cases'] == 21453 and e['summary']['native_function_observations'] == 257436
        assert e['summary']['resource_before'] == e['summary']['resource_after'] == [0, 0, 0, 0]
        a.check('stb-divide-host/' + variant['name'] + '/translated.dll', {'sha256': e['target_sha256']})
        matches = [x for x in s['artifacts'] if norm(x['path']).startswith(variant['name'] + '/') and x['sha256'] == e['observations_sha256']]
        assert len(matches) == 1
        observation_path = 'stb-divide-host/' + norm(matches[0]['path'])
        rows = a.files[observation_path].decode().splitlines()
        assert len(rows) == len(cases)
        for row, case in zip(rows, cases):
            values = [int(v) for v in row.split('\t')]
            assert len(values) == 20 and values[:2] == [case['a'], case['b']]
            expected = integer_oracle(values[0], values[1])
            assert values[2:8] == values[8:14] == values[14:20] == expected
        assert len(variant['traps']) == 12
        assert all(x['route'] == 'rust' and x['exit_code'] != 0 and not x['original_c_called'] for x in variant['traps'])
        variants.append({'name': variant['name'], 'flags': variant['flags'], 'executions': variant['executions'],
                         'hia': variant['hia'], 'native_target': {k: variant['rust_build'][k] for k in ('artifact_sha256', 'status', 'target', 'toolchain')},
                         'retained_tsv': observation_path, 'independent_integer_oracle_rows_checked': len(rows),
                         'trap_process_count': len(variant['traps'])})
    assert s['totals']['native_function_observations'] == 514872
    assert s['wrong_code_control']['actual_native_executed'] and s['wrong_code_control']['rejected_by_functional_oracle']
    assert s['wrong_code_control']['exit_code'] == 2
    assert all(x['whole_bundle_rejected'] and not x['published_partial_bundle'] for x in s['refusal_controls'])
    return {'kind': 'native_abi_and_stb_host', 'status': 'passed', 'host': n['host'],
            'source_identity': m['source_identity'], 'native_c_compiler': n['c_compiler'],
            'native_executions': n['executions'], 'native_executable_sha256s': n['executable_sha256s'],
            'native_object': {k: native[k] for k in ('artifact_sha256', 'rust_sha256', 'target', 'status', 'toolchain')},
            'native_manifest_scope': m['scope'], 'native_limits': n['limits'], 'native_claims': n['claims'],
            'native_negative_control': n['negative_control'], 'type_negative_controls': n['type_negative_controls'],
            'original_type_preflight': {'status': type_preflight['status'], 'ok': True, 'cases': type_preflight['cases'],
                                        'native_program_executions': 0, 'claims': type_preflight['claims'], 'limits': type_preflight['limits']},
            'stb': {'source_identity': {k: s['source_before'][k] for k in ('commit', 'tree', 'status', 'status_scope')},
                    'source_inputs_comparison': source_comparison(s['source_before']['implementation_files']),
                    'upstream': s['upstream'], 'scope': s['scope'], 'totals': s['totals'], 'variants': variants,
                    'resource_scope': s['resource_scope'], 'claims': s['claims'], 'wrong_code_control': s['wrong_code_control'],
                    'refusal_controls': s['refusal_controls'], 'cpp_entry_refusal': s['cpp_entry_refusal']},
            'backend_boundary': 'Native ABI object and both STB component targets execute the actual Rust backend. HIA STB observation is interpreter-only (696 function observations total); HIA LLVM native execution is explicitly false on this Windows profile.'}

def main():
    assert sys.flags.optimize == 0
    request = json.load(sys.stdin)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    wall, cpu = time.monotonic_ns(), time.process_time_ns()
    assert set(os.sched_getaffinity(0)).issubset({8, 9})
    assert request['published_commit']['sha'] == HEAD and request['published_commit']['tree']['sha'] == TREE
    snapshot_bytes = SNAPSHOT.read_bytes()
    assert sha(snapshot_bytes) == SNAPSHOT_SHA
    snapshot = json.loads(snapshot_bytes)
    assert snapshot['expected_head'] == HEAD
    found_jobs = {}
    for node in walk(snapshot):
        if node.get('id') in JOBS.values() and isinstance(node.get('steps'), list):
            jobid = node['id']
            if jobid in found_jobs:
                assert found_jobs[jobid] == node
            found_jobs[jobid] = node
    assert set(found_jobs) == set(JOBS.values())
    results = []
    for metadata in request['artifact_metadata']:
        a = Archive(metadata)
        job = found_jobs[JOBS[a.id]]
        assert job['head_sha'] == HEAD and job['status'] == 'completed' and job['conclusion'] == 'success'
        result = cpp(a) if 'cpp-upstream-host.json' in a.files else abi(a)
        jobbrief = {k: job.get(k) for k in ('id', 'run_id', 'name', 'head_sha', 'status', 'conclusion', 'started_at', 'completed_at', 'runner_name', 'runner_group_name', 'labels')}
        jobbrief['steps'] = job['steps']
        if result['kind'] == 'native_abi_and_stb_host':
            skipped = [x for x in job['steps'] if x['name'] == 'Check non-reaping POSIX leader and capture-read boundaries']
            assert len(skipped) == 1 and skipped[0]['status'] == 'completed' and skipped[0]['conclusion'] == 'skipped'
            result['posix_supervision_step'] = skipped[0]
            result['windows_posix_non_reaping_qualification'] = False
        results.append(dict(a.summary(), github_job=jobbrief, qualification=result))
    assert len(results) == 4
    audit = {'schema': 'hepta.windows-artifact-audit.v1', 'passed': True,
             'started_utc': start, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'scope': 'Independent read-only audit of original downloaded CI ZIPs, retained original bytes and finite oracle outputs. No executable from these archives was run; no CI rerun or new qualification campaign.',
             'published_source': {'commit': HEAD, 'tree': TREE},
             'separate_linux_measured_source': {'commit': MEASURED_HEAD, 'tree': TREE},
             'same_tree_does_not_merge_commits_or_qualification_profiles': True,
             'github_commit_tree_response': {k: request['published_commit'][k] for k in ('sha', 'tree', 'url')},
             'github_snapshot': dict(ident(snapshot_bytes), path=str(SNAPSHOT)),
             'artifact_download_terminal_receipt': request['download_terminal_receipt'],
             'profiles': results, 'native_reruns': 0, 'ci_reruns': 0, 'model_requests': 0,
             'wall_ns': time.monotonic_ns()-wall, 'cpu_ns': time.process_time_ns()-cpu,
             'limits': ['GitHub Actions native processes qualify the stated Windows x86_64 compiler profiles; they are not physical-device or hardware fault-recovery evidence.',
                        'Both POSIX non-reaping/capture-read steps were skipped on Windows; this audit does not promote them to passed.',
                        'C++ consumer and native ABI/STB targets use Rust backend; no whole HIA LLVM AOT Windows qualification is implied.',
                        'Native ABI Rust compiler argv/raw streams and temporary Rust input bytes are not retained by that original qualifier; its structured receipt, canonical input and object hashes are retained.',
                        'C++ process-lifetime registry retains three allocations in its reported ordinary lifecycle scope; ordinary object live delta is zero. Do not conflate this with the separate P2 empty owner/library registry result.',
                        'Finite library/ABI/cancellation/lifetime cases do not establish general source equivalence, all interleavings, foreign lifetime soundness, development cost improvement or all upstream configuration support.']}
    assert request['download_terminal_receipt']['state'] == 'succeeded'
    assert request['download_terminal_receipt']['exit_code'] == 0 and request['download_terminal_receipt']['output_complete']
    output = ROOT / 'WINDOWS_ARTIFACT_AUDIT.json'
    write(output, wire(audit))
    metadata = {k: audit[k] for k in ('published_source', 'separate_linux_measured_source', 'github_commit_tree_response', 'github_snapshot', 'artifact_download_terminal_receipt')}
    metadata['artifacts'] = request['artifact_metadata']
    metadata['jobs'] = {str(r['artifact_id']): r['github_job'] for r in results}
    write(ROOT / 'GITHUB_METADATA.json', wire(metadata))
    print(json.dumps({'passed': True, 'result': dict(ident(output.read_bytes()), path=str(output)),
                      'profiles': [{'artifact_id': r['artifact_id'], 'kind': r['qualification']['kind'],
                                    'retained_files_checked': r['checked_retained_file_count'],
                                    'raw_stream_files_checked': r['separately_checked_raw_stream_file_count']} for r in results],
                      'native_reruns': 0, 'cpu_ns': audit['cpu_ns'], 'wall_ns': audit['wall_ns']}))

if __name__ == '__main__':
    main()
