
/data/hepta-hia-round5-a3b4-20261105/evidence/ndu-preparation-bound-r1/campaign/rust.so：     文件格式 elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011c0 <calculate>:
    11c0:	48 85 ff             	test   %rdi,%rdi
    11c3:	75 03                	jne    11c8 <calculate+0x8>
    11c5:	31 c0                	xor    %eax,%eax
    11c7:	c3                   	ret
    11c8:	55                   	push   %rbp
    11c9:	41 57                	push   %r15
    11cb:	41 56                	push   %r14
    11cd:	53                   	push   %rbx
    11ce:	48 83 ec 28          	sub    $0x28,%rsp
    11d2:	89 f5                	mov    %esi,%ebp
    11d4:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
    11d9:	ba 01 00 00 00       	mov    $0x1,%edx
    11de:	48 89 f9             	mov    %rdi,%rcx
    11e1:	48 89 c7             	mov    %rax,%rdi
    11e4:	31 f6                	xor    %esi,%esi
    11e6:	49 89 cf             	mov    %rcx,%r15
    11e9:	e8 a2 fe ff ff       	call   1090 <_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h11ddb5c87cebcf6fE>
    11ee:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
    11f3:	74 0a                	je     11ff <calculate+0x3f>
    11f5:	b8 e9 03 00 00       	mov    $0x3e9,%eax
    11fa:	e9 2f 02 00 00       	jmp    142e <calculate+0x26e>
    11ff:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    1204:	49 83 ff 01          	cmp    $0x1,%r15
    1208:	75 11                	jne    121b <calculate+0x5b>
    120a:	c6 03 00             	movb   $0x0,(%rbx)
    120d:	48 8d 4b 01          	lea    0x1(%rbx),%rcx
    1211:	45 31 f6             	xor    %r14d,%r14d
    1214:	b8 01 00 00 00       	mov    $0x1,%eax
    1219:	eb 25                	jmp    1240 <calculate+0x80>
    121b:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
    121f:	45 31 f6             	xor    %r14d,%r14d
    1222:	48 89 df             	mov    %rbx,%rdi
    1225:	31 f6                	xor    %esi,%esi
    1227:	ff 15 93 3d 00 00    	call   *0x3d93(%rip)        # 4fc0 <memset@GLIBC_2.2.5>
    122d:	4c 89 f8             	mov    %r15,%rax
    1230:	42 c6 44 3b ff 00    	movb   $0x0,-0x1(%rbx,%r15,1)
    1236:	4a 8d 0c 3b          	lea    (%rbx,%r15,1),%rcx
    123a:	49 83 ff 04          	cmp    $0x4,%r15
    123e:	73 36                	jae    1276 <calculate+0xb6>
    1240:	48 89 de             	mov    %rbx,%rsi
    1243:	89 ea                	mov    %ebp,%edx
    1245:	41 01 d6             	add    %edx,%r14d
    1248:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    124f:	00 
    1250:	44 88 36             	mov    %r14b,(%rsi)
    1253:	48 ff c6             	inc    %rsi
    1256:	41 fe c6             	inc    %r14b
    1259:	48 39 ce             	cmp    %rcx,%rsi
    125c:	75 f2                	jne    1250 <calculate+0x90>
    125e:	89 c1                	mov    %eax,%ecx
    1260:	83 e1 07             	and    $0x7,%ecx
    1263:	48 83 f8 08          	cmp    $0x8,%rax
    1267:	0f 83 3b 01 00 00    	jae    13a8 <calculate+0x1e8>
    126d:	31 c0                	xor    %eax,%eax
    126f:	31 d2                	xor    %edx,%edx
    1271:	e9 89 01 00 00       	jmp    13ff <calculate+0x23f>
    1276:	89 ea                	mov    %ebp,%edx
    1278:	66 0f 6e c5          	movd   %ebp,%xmm0
    127c:	48 83 f8 20          	cmp    $0x20,%rax
    1280:	73 08                	jae    128a <calculate+0xca>
    1282:	45 31 f6             	xor    %r14d,%r14d
    1285:	e9 b8 01 00 00       	jmp    1442 <calculate+0x282>
    128a:	49 89 c6             	mov    %rax,%r14
    128d:	49 83 e6 e0          	and    $0xffffffffffffffe0,%r14
    1291:	66 0f 7f 04 24       	movdqa %xmm0,(%rsp)
    1296:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    129b:	66 0f 6f 15 5d 1d 00 	movdqa 0x1d5d(%rip),%xmm2        # 3000 <_fini+0xdf8>
    12a2:	00 
    12a3:	66 0f fe d1          	paddd  %xmm1,%xmm2
    12a7:	66 0f 6f 1d 61 1d 00 	movdqa 0x1d61(%rip),%xmm3        # 3010 <_fini+0xe08>
    12ae:	00 
    12af:	66 0f 6f 25 69 1d 00 	movdqa 0x1d69(%rip),%xmm4        # 3020 <_fini+0xe18>
    12b6:	00 
    12b7:	66 0f 6f 2d 71 1d 00 	movdqa 0x1d71(%rip),%xmm5        # 3030 <_fini+0xe28>
    12be:	00 
    12bf:	66 0f 6f 05 79 1d 00 	movdqa 0x1d79(%rip),%xmm0        # 3040 <_fini+0xe38>
    12c6:	00 
    12c7:	31 f6                	xor    %esi,%esi
    12c9:	66 0f 6f 3d 7f 1d 00 	movdqa 0x1d7f(%rip),%xmm7        # 3050 <_fini+0xe48>
    12d0:	00 
    12d1:	66 44 0f 6f 05 86 1d 	movdqa 0x1d86(%rip),%xmm8        # 3060 <_fini+0xe58>
    12d8:	00 00 
    12da:	66 44 0f 6f e3       	movdqa %xmm3,%xmm12
    12df:	66 44 0f fe e1       	paddd  %xmm1,%xmm12
    12e4:	66 44 0f 6f ec       	movdqa %xmm4,%xmm13
    12e9:	66 44 0f fe e9       	paddd  %xmm1,%xmm13
    12ee:	66 44 0f 6f f5       	movdqa %xmm5,%xmm14
    12f3:	66 44 0f fe f1       	paddd  %xmm1,%xmm14
    12f8:	66 44 0f 6f c8       	movdqa %xmm0,%xmm9
    12fd:	66 44 0f fe c9       	paddd  %xmm1,%xmm9
    1302:	66 44 0f 6f db       	movdqa %xmm3,%xmm11
    1307:	66 44 0f fe da       	paddd  %xmm2,%xmm11
    130c:	66 44 0f 6f d4       	movdqa %xmm4,%xmm10
    1311:	66 44 0f fe d2       	paddd  %xmm2,%xmm10
    1316:	66 44 0f 6f fd       	movdqa %xmm5,%xmm15
    131b:	66 44 0f fe fa       	paddd  %xmm2,%xmm15
    1320:	66 0f 6f f0          	movdqa %xmm0,%xmm6
    1324:	66 0f fe f2          	paddd  %xmm2,%xmm6
    1328:	66 44 0f db cf       	pand   %xmm7,%xmm9
    132d:	66 44 0f db f7       	pand   %xmm7,%xmm14
    1332:	66 45 0f 67 ce       	packuswb %xmm14,%xmm9
    1337:	66 44 0f db ef       	pand   %xmm7,%xmm13
    133c:	66 44 0f db e7       	pand   %xmm7,%xmm12
    1341:	66 45 0f 67 ec       	packuswb %xmm12,%xmm13
    1346:	66 45 0f 67 cd       	packuswb %xmm13,%xmm9
    134b:	66 0f db f7          	pand   %xmm7,%xmm6
    134f:	66 44 0f db ff       	pand   %xmm7,%xmm15
    1354:	66 41 0f 67 f7       	packuswb %xmm15,%xmm6
    1359:	66 44 0f db d7       	pand   %xmm7,%xmm10
    135e:	66 44 0f db df       	pand   %xmm7,%xmm11
    1363:	66 45 0f 67 d3       	packuswb %xmm11,%xmm10
    1368:	66 41 0f 67 f2       	packuswb %xmm10,%xmm6
    136d:	f3 44 0f 7f 0c 33    	movdqu %xmm9,(%rbx,%rsi,1)
    1373:	f3 0f 7f 74 33 10    	movdqu %xmm6,0x10(%rbx,%rsi,1)
    1379:	48 83 c6 20          	add    $0x20,%rsi
    137d:	66 41 0f fe c0       	paddd  %xmm8,%xmm0
    1382:	66 41 0f fe e8       	paddd  %xmm8,%xmm5
    1387:	66 41 0f fe e0       	paddd  %xmm8,%xmm4
    138c:	66 41 0f fe d8       	paddd  %xmm8,%xmm3
    1391:	49 39 f6             	cmp    %rsi,%r14
    1394:	0f 85 40 ff ff ff    	jne    12da <calculate+0x11a>
    139a:	4c 39 f0             	cmp    %r14,%rax
    139d:	0f 85 96 00 00 00    	jne    1439 <calculate+0x279>
    13a3:	89 c1                	mov    %eax,%ecx
    13a5:	83 e1 07             	and    $0x7,%ecx
    13a8:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    13ac:	31 d2                	xor    %edx,%edx
    13ae:	31 f6                	xor    %esi,%esi
    13b0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
    13b4:	48 01 d7             	add    %rdx,%rdi
    13b7:	0f b6 54 33 01       	movzbl 0x1(%rbx,%rsi,1),%edx
    13bc:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
    13c2:	49 01 d0             	add    %rdx,%r8
    13c5:	49 01 f8             	add    %rdi,%r8
    13c8:	0f b6 54 33 03       	movzbl 0x3(%rbx,%rsi,1),%edx
    13cd:	0f b6 7c 33 04       	movzbl 0x4(%rbx,%rsi,1),%edi
    13d2:	48 01 d7             	add    %rdx,%rdi
    13d5:	44 0f b6 4c 33 05    	movzbl 0x5(%rbx,%rsi,1),%r9d
    13db:	49 01 f9             	add    %rdi,%r9
    13de:	4d 01 c1             	add    %r8,%r9
    13e1:	0f b6 7c 33 06       	movzbl 0x6(%rbx,%rsi,1),%edi
    13e6:	0f b6 54 33 07       	movzbl 0x7(%rbx,%rsi,1),%edx
    13eb:	48 01 fa             	add    %rdi,%rdx
    13ee:	4c 01 ca             	add    %r9,%rdx
    13f1:	48 83 c6 08          	add    $0x8,%rsi
    13f5:	48 39 f0             	cmp    %rsi,%rax
    13f8:	75 b6                	jne    13b0 <calculate+0x1f0>
    13fa:	48 85 c9             	test   %rcx,%rcx
    13fd:	74 20                	je     141f <calculate+0x25f>
    13ff:	48 01 d8             	add    %rbx,%rax
    1402:	31 f6                	xor    %esi,%esi
    1404:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    140b:	00 00 00 00 00 
    1410:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
    1414:	48 01 fa             	add    %rdi,%rdx
    1417:	48 ff c6             	inc    %rsi
    141a:	48 39 f1             	cmp    %rsi,%rcx
    141d:	75 f1                	jne    1410 <calculate+0x250>
    141f:	48 89 df             	mov    %rbx,%rdi
    1422:	48 89 d3             	mov    %rdx,%rbx
    1425:	ff 15 9d 3b 00 00    	call   *0x3b9d(%rip)        # 4fc8 <_GLOBAL_OFFSET_TABLE_+0x58>
    142b:	48 89 d8             	mov    %rbx,%rax
    142e:	48 83 c4 28          	add    $0x28,%rsp
    1432:	5b                   	pop    %rbx
    1433:	41 5e                	pop    %r14
    1435:	41 5f                	pop    %r15
    1437:	5d                   	pop    %rbp
    1438:	c3                   	ret
    1439:	a8 1c                	test   $0x1c,%al
    143b:	74 6f                	je     14ac <calculate+0x2ec>
    143d:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    1442:	48 89 c7             	mov    %rax,%rdi
    1445:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
    1449:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    144e:	66 41 0f 6e ce       	movd   %r14d,%xmm1
    1453:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
    1458:	66 0f fe 0d e0 1b 00 	paddd  0x1be0(%rip),%xmm1        # 3040 <_fini+0xe38>
    145f:	00 
    1460:	66 0f 6f 15 e8 1b 00 	movdqa 0x1be8(%rip),%xmm2        # 3050 <_fini+0xe48>
    1467:	00 
    1468:	66 0f 6f 1d 00 1c 00 	movdqa 0x1c00(%rip),%xmm3        # 3070 <_fini+0xe68>
    146f:	00 
    1470:	66 0f 6f e1          	movdqa %xmm1,%xmm4
    1474:	66 0f fe e0          	paddd  %xmm0,%xmm4
    1478:	66 0f db e2          	pand   %xmm2,%xmm4
    147c:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    1480:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    1484:	66 42 0f 7e 24 33    	movd   %xmm4,(%rbx,%r14,1)
    148a:	49 83 c6 04          	add    $0x4,%r14
    148e:	66 0f fe cb          	paddd  %xmm3,%xmm1
    1492:	4c 39 f7             	cmp    %r14,%rdi
    1495:	75 d9                	jne    1470 <calculate+0x2b0>
    1497:	48 39 f8             	cmp    %rdi,%rax
    149a:	0f 84 be fd ff ff    	je     125e <calculate+0x9e>
    14a0:	48 8d 34 3b          	lea    (%rbx,%rdi,1),%rsi
    14a4:	41 89 fe             	mov    %edi,%r14d
    14a7:	e9 99 fd ff ff       	jmp    1245 <calculate+0x85>
    14ac:	4c 89 f6             	mov    %r14,%rsi
    14af:	48 01 de             	add    %rbx,%rsi
    14b2:	e9 8e fd ff ff       	jmp    1245 <calculate+0x85>

Disassembly of section .fini:
