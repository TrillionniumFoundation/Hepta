from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import subprocess
import sys
import time
import types

ROOT = Path('/data/hepta-hia-round5-a3b4-20261105/work-ndu')
EVIDENCE = Path('/data/hepta-hia-round5-a3b4-20261105/evidence/ndu-preparation-bound-r1')
started = time.monotonic_ns()
os.sched_setaffinity(0, {4, 5, 6, 7})
sys.path.insert(0, str(ROOT))
from tests.test_hia_ndu_cost import independent_frontier

def read(name):
    return json.loads((EVIDENCE / name).read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

report, outer, registration = read('campaign/REPORT.json'), read('OUTER_RESULT.json'), read('REGISTRATION.json')
assert report['status'] == 'completed' and outer['returncode'] == 0
assert outer['source_bytes_unchanged'] and not outer['source_status_after']
assert outer['source_commit'] == outer['source_commit_after'] == registration['source_commit']
assert outer['tools_after'] == registration['tools']
assert outer['bridge_after'] == registration['bridge']
assert outer['bridge_manifest_after'] == registration['bridge_manifest']
assert registration['source_inventory'] == report['source_before'] == report['source_after']
assert sha(EVIDENCE / 'campaign/REPORT.json') == outer['report']['sha256']
assert sha(EVIDENCE / 'REGISTRATION.json') == outer['registration']['sha256']
arms = ['fixed', 'exact_dp', 'lightweight', 'native_ndu']
expected = {f"{repeat}-{episode['id']}-{arm}" for repeat in range(report['specification']['repetitions'])
            for episode in report['specification']['episodes'] for arm in arms}
ids = [row['id'] for row in report['episodes']]
assert len(ids) == len(set(ids)) == 36 and set(ids) == expected
rows = [read('campaign/' + name + '.json') for name in ids]
assert all(len(row['steps']) == 4 for row in rows)
for row in rows:
    expected_summary = next(item for item in report['episodes'] if item['id'] == row['id'])
    assert {k: v for k, v in row.items() if k != 'steps'} == expected_summary
    assert row['service_wall_ns'] >= row['component_wall_ns'] >= 0
    for step in row['steps']:
        metrics = step['execution']['metrics']
        assert metrics['accounting_errors'] == metrics['live'] == metrics['live_requested'] == metrics['live_usable'] == 0
        assert metrics['allocations'] == metrics['frees']

baseline_raw = subprocess.check_output(['git', 'show', '996e2626d9aa89bc0e2b1017ebb858c6666604e7:hepta/hia_ndu_cost.py'], cwd=ROOT)
assert hashlib.sha256(baseline_raw).hexdigest() == '6b9390be6019e8682c988c8e0671d06c6e969b31ea47dae352a0694b17a06ef0'
baseline = types.ModuleType('hepta._s3_ndu_cost_bound_reference')
baseline.__package__ = 'hepta'
exec(compile(baseline_raw, 'git:996e2626:hepta/hia_ndu_cost.py', 'exec'), baseline.__dict__)

diagnostics, exact_audits = [], []
for row in rows:
    if row['policy'] == 'fixed':
        continue
    for step in row['steps']:
        decision = step['decision']
        gate = decision['gate']
        old_lower = gate['invocation_lower_ns'] - gate['preparation_execution_lower_ns'] + gate['free_execution_lower_ns']
        model = decision.get('control_model')
        if decision.get('bundle') is not None:
            model = decision['bundle']['support']['model']
        if model is not None:
            old_gate = baseline.invocation_gate(model)
            assert old_gate['invocation_lower_ns'] == old_lower
            old_mode = old_gate['mode']
            basis = 'full_actual_model_replayed_through_exact_S3_gate'
        elif gate['mode'] == 'consider':
            old_mode = 'consider'
            basis = 'monotone_bound_from_retained_gate_receipt; complete_model_not_retained'
        elif (gate['mode'] == 'skip' and gate['reason'] == 'optimistic saving cannot pay for invocation'
              and gate['skip']['feasible']):
            old_mode = 'consider' if old_lower < gate['skip']['total_ns'] else 'skip'
            basis = 'retained_feasible_incumbent_proves_budget_ge_skip; complete_model_not_retained'
        else:
            old_mode = None
            basis = 'insufficient_retained_model_for_exact_prior_mode'
        diagnostics.append({'episode': row['id'], 'batch': step['batch'], 'policy': row['policy'],
            'old_mode': old_mode, 'new_mode': gate['mode'], 'old_invocation_lower_ns': old_lower,
            'new_invocation_lower_ns': gate['invocation_lower_ns'],
            'bound_increase_ns': gate['preparation_execution_lower_ns'] - gate['free_execution_lower_ns'],
            'basis': basis, 'observed_saving_ns': None,
            'cost_note': 'No old-policy execution was repeated; changed subsequent state and gate work prevent attributing observed elapsed savings.'})
        if row['policy'] == 'native_ndu' and decision['native_invoked']:
            assert 'response' in decision and 'native_error' not in decision
            bundle = decision['bundle']
            reference = independent_frontier(model, committed_call=True)
            actual = {}
            for plan in bundle['plans'].values():
                action = plan['actions'][0]
                key = (action['mode'], tuple(action['ready_after']) if action['mode'] == 'invoke' else ())
                actual[key] = plan['total_ns']
            assert actual == reference
            minimum = min(reference.values())
            frontier = decision['response']['pareto_candidate_ids']
            assert frontier and all(identity in bundle['plans'] for identity in frontier)
            costs = [bundle['plans'][identity]['total_ns'] for identity in frontier]
            assert all(cost == minimum for cost in costs)
            exact_audits.append({'episode': row['id'], 'batch': step['batch'], 'minimum_ns': minimum,
                                 'first_actions': len(reference), 'selected_plan_costs_ns': costs,
                                 'gap_ns': 0, 'native_reinvoked': False})

service = {arm: sum(row['service_wall_ns'] for row in rows if row['policy'] == arm) for arm in arms}
total_service = sum(service.values())
common = outer['outer_wall_ns'] - total_service
assert common >= report['offline_wall_ns']
historical_bridge = registration['historical_bridge_build_cost']['wall_ns']
alternative = {arm: common + service[arm] + (historical_bridge if arm == 'native_ndu' else 0) for arm in arms}
gate_counts = {arm: dict(Counter(d['old_mode'] + '->' + d['new_mode'] if d['old_mode'] is not None else 'unknown'
                                for d in diagnostics if d['policy'] == arm)) for arm in arms if arm != 'fixed'}
load = [json.loads(line) for line in (EVIDENCE / 'load.jsonl').read_text().splitlines()]
unit = read('unit/RESULT.json')
summary = {'schema': 'hepta.hia.ndu.hia-preparation-summary.v1',
    'source_commit': registration['source_commit'], 'source_tree': registration['source_tree'],
    'source_and_tools_stable': True, 'new_source_actual_campaign_count': 1,
    'planned_and_completed_episodes': 36, 'completed_steps': 144,
    'timed_driver_calls': sum(step['execution']['calls'] for row in rows for step in row['steps']),
    'timed_allocations': sum(step['execution']['metrics']['allocations'] for row in rows for step in row['steps']),
    'timed_frees': sum(step['execution']['metrics']['frees'] for row in rows for step in row['steps']),
    'timed_live_and_accounting_errors': 0,
    'correctness_rows': len(report['correctness']), 'residency_probe_count': len(report['residency_probes']),
    'native_refusal_recovery': report['native_refusal_recovery'],
    'acceptance': report['acceptance'], 'comparisons': report['comparisons'],
    'native_calls_independently_exhaustive_audited': len(exact_audits),
    'native_finite_model_all_gaps_ns': [row['gap_ns'] for row in exact_audits],
    'gate_diagnostic_transitions': gate_counts,
    'gate_diagnostic_scope': 'Same recorded inputs or explicit retained-receipt inference, not an old-vs-new execution or causal wall-time saving.',
    'bound_increased_steps': sum(row['bound_increase_ns'] > 0 for row in diagnostics),
    'gate_rows_total': len(diagnostics),
    'services_ns': service, 'actual_outer_wall_ns': outer['outer_wall_ns'],
    'original_report_inner_wall_ns': report['campaign_wall_ns'],
    'common_outer_remainder_ns': common,
    'hypothetical_single_arm_complete_observed_runtime_ns': alternative,
    'hypothetical_allocation_note': 'Each alternative pays the entire shared outer remainder once. Native additionally pays the prior measured bridge build, which was reused here. Alternatives overlap and must not be summed as actual wall.',
    'actual_new_bridge_build_incurred': False,
    'historical_bridge_build_wall_ns_charged_in_native_alternative': historical_bridge,
    'unit_outer_wall_ns': unit['wall_ns'], 'unit_tests': 39, 'unit_failures_errors_skips': 0,
    'new_bound_test_methods': 10, 'new_finite_models': 256,
    'registration_prepare_wall_ns': registration['preparation_wall_ns_before_registration_write'],
    'cpu_affinity': registration['cpu_affinity'], 'cpu_thread_siblings': registration['cpu_thread_siblings'],
    'shared_nonexclusive_host': True, 'load_samples': len(load),
    'load_one_min_min': min(float(x['loadavg'].split()[0]) for x in load),
    'load_one_min_max': max(float(x['loadavg'].split()[0]) for x in load),
    'unknown_costs': {'human_engineering_review_ns': None, 'energy_joules': None,
        'historical_dependency_toolchain_acquisition_ns': None, 'full_lifecycle_storage_maintenance_ns': None,
        'connector_and_preparation_outside_recorded_boundaries_ns': None},
    'full_lifecycle_cost_complete': False, 'ndu_net_benefit_established': False,
    'general_safety_theorem': False, 'unified_composition_qualification': False,
    'authority': 'DENY_ALL', 'safety_certificate': False,
    'raw_report_sha256': sha(EVIDENCE / 'campaign/REPORT.json'),
    'registration_sha256': sha(EVIDENCE / 'REGISTRATION.json'),
    'outer_receipt_sha256': sha(EVIDENCE / 'OUTER_RESULT.json')}
for name, value in [('GATE_DIAGNOSTIC.json', diagnostics), ('INDEPENDENT_EXACT_AUDIT.json', exact_audits)]:
    with (EVIDENCE / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
summary['post_run_analysis_wall_ns_before_summary_write'] = time.monotonic_ns() - started
with (EVIDENCE / 'SUMMARY.json').open('x') as stream:
    json.dump(summary, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(summary, sort_keys=True))
