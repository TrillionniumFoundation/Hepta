"""Read-only replay of retained NDU evidence; writes only new review files."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import itertools
import json
import os
import stat
import subprocess
import time

ROOT = Path('/data/hepta-hia-round5-a3b4-20261105/work-ndu')
EVIDENCE = Path('/data/hepta-hia-round5-a3b4-20261105/evidence/ndu-preparation-bound-r1')
HEAD = '66d796e8abefe87d97b4096912136cdcd3299bfc'
TREE = '12f2cf8a830cba58ec40b50e13ee6a83bc2c49e2'
PARENT = '996e2626d9aa89bc0e2b1017ebb858c6666604e7'
CHANGED = {
    'hepta/hia_ndu_cost.py': 'f29ce1dd1355b461d8c58a70ae85cf1a93435090baeed2c0ea1b990dc8006882',
    'tests/test_hia_ndu_preparation_bound.py': '0ca727af4be216d5fa6286b0c22efbf21dda16e5bfdcc74e8a435c5bdfb2f802',
    'docs/HIA_NDU_HIA_PREPARATION_BOUND.md': '38d9f56b15803c3c79a2d5af42356dc46490a935c27136a3c1261aa68c9a4860',
}
OUTPUTS = {'INDEPENDENT_REVIEW_AUDIT.py', 'INDEPENDENT_REVIEW.json',
           'INDEPENDENT_REVIEW.md', 'NATIVE_RUNTIME_TERMINAL_REVIEW.json'}
started = time.monotonic_ns()
os.sched_setaffinity(0, {6, 7})
git_env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}


def git(*args):
    return subprocess.check_output(['/usr/bin/git', '--no-replace-objects', *args],
                                   cwd=ROOT, env=git_env)


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha_bytes(raw)}


def read(name):
    return json.loads((EVIDENCE / name).read_bytes())


def write(name, value):
    with (EVIDENCE / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


assert git('show', '--no-patch', '--format=%H%n%T', 'HEAD').decode().splitlines() == [HEAD, TREE]
assert git('rev-parse', HEAD + '^').decode().strip() == PARENT
assert not git('status', '--porcelain', '--untracked-files=all').strip()
changed = set(git('diff-tree', '--no-commit-id', '--name-only', '-r', HEAD).decode().splitlines())
assert changed == set(CHANGED)

summary, registration, outer, report, unit = (
    read(n) for n in ('SUMMARY.json', 'REGISTRATION.json', 'OUTER_RESULT.json',
                      'campaign/REPORT.json', 'unit/RESULT.json'))
assert registration['source_commit'] == outer['source_commit'] == outer['source_commit_after'] == HEAD
assert registration['source_tree'] == TREE
assert report['status'] == 'completed' and outer['returncode'] == 0
assert outer['timed_out'] is False and outer['launch_error'] is None
assert outer['source_status_after'] == '' and outer['source_bytes_unchanged'] is True
assert registration['source_inventory'] == outer['source_inventory_after'] == report['source_before'] == report['source_after']

inventory = dict(registration['source_inventory'])
inventory.update(CHANGED)
oracle_name = 'tests/test_hia_ndu_cost.py'
oracle_source = git('show', HEAD + ':' + oracle_name)
inventory[oracle_name] = sha_bytes(oracle_source)
for name, expected in inventory.items():
    path = ROOT / name
    assert stat.S_ISREG(path.lstat().st_mode), name
    blob = git('show', HEAD + ':' + name)
    assert sha_bytes(path.read_bytes()) == sha_bytes(blob) == expected, name

for key in ('tools', 'bridge', 'bridge_manifest'):
    assert registration[key] == outer[key + '_after']
    values = registration[key].values() if key == 'tools' else [registration[key]]
    for value in values:
        assert identity(Path(value['path'])) == value
assert registration['native_bridge_reused'] is True
assert registration['native_bridge_rebuilt_this_campaign'] is False
assert outer['new_native_bridge_build_incurred'] is False
assert identity(Path(registration['original_report']['path'])) == registration['original_report']
assert identity(Path(registration['original_command']['path'])) == registration['original_command']
original_report = json.loads(Path(registration['original_report']['path']).read_bytes())
assert original_report['specification'] == report['specification'] == registration['specification']
assert identity(EVIDENCE / 'campaign/REPORT.json') == outer['report']
assert identity(EVIDENCE / 'REGISTRATION.json') == outer['registration']
for name, key in [('campaign/REPORT.json', 'raw_report_sha256'),
                  ('REGISTRATION.json', 'registration_sha256'), ('OUTER_RESULT.json', 'outer_receipt_sha256')]:
    assert identity(EVIDENCE / name)['sha256'] == summary[key]
assert unit['source_commit'] == unit['source_after'] == HEAD
assert unit['tree'] == TREE and unit['returncode'] == 0 and unit['timed_out'] is False
assert unit['source_status_after'] == ''
for name, expected in unit['streams'].items():
    actual = identity(EVIDENCE / 'unit' / name)
    assert {k: actual[k] for k in ('bytes', 'sha256')} == expected
test_log = (EVIDENCE / 'unit/stderr').read_text()
assert test_log.count(' ... ok\n') == 39 and 'Ran 39 tests in 2.652s\n\nOK\n' in test_log

arms = ['fixed', 'exact_dp', 'lightweight', 'native_ndu']
expected_ids = {f"{repeat}-{scenario['id']}-{arm}"
                for repeat in range(3) for scenario in registration['specification']['episodes'] for arm in arms}
rows = [read('campaign/' + item['id'] + '.json') for item in report['episodes']]
assert len(rows) == len(expected_ids) == 36 and {row['id'] for row in rows} == expected_ids
services = {arm: 0 for arm in arms}
timed_calls = allocations = frees = steps = 0
native = []
gate_keys = set()
for row, short in zip(rows, report['episodes']):
    assert {k: v for k, v in row.items() if k != 'steps'} == short
    assert len(row['steps']) == 4
    assert row['service_wall_ns'] >= row['component_wall_ns'] >= 0
    assert row['other_service_ns'] == row['service_wall_ns'] - row['component_wall_ns']
    services[row['policy']] += row['service_wall_ns']
    for step in row['steps']:
        steps += 1
        result = step['execution']
        metrics = result['metrics']
        timed_calls += result['calls']
        allocations += metrics['allocations']
        frees += metrics['frees']
        assert metrics['accounting_errors'] == metrics['live'] == metrics['live_requested'] == metrics['live_usable'] == 0
        assert metrics['allocations'] == metrics['frees']
        if row['policy'] != 'fixed':
            gate_keys.add((row['id'], step['batch'], row['policy']))
        if step['decision']['native_invoked']:
            assert row['policy'] == 'native_ndu'
            native.append((row['id'], step))
assert steps == 144 and timed_calls == 147456 and allocations == frees == 144
assert services == summary['services_ns'] and len(native) == 9

# Use only the audited independent enumerator, without importing production code.
oracle_fn = next(n for n in ast.parse(oracle_source).body
                 if isinstance(n, ast.FunctionDef) and n.name == 'independent_frontier')
oracle_namespace = {'itertools': itertools}
exec(compile(ast.Module(body=[oracle_fn], type_ignores=[]), 'git:' + HEAD + ':' + oracle_name, 'exec'), oracle_namespace)
retained_exact = {(x['episode'], x['batch']): x for x in read('INDEPENDENT_EXACT_AUDIT.json')}
exact_checked = []
for episode, step in native:
    decision = step['decision']
    assert 'native_error' not in decision and decision['native_matches_exact_model'] is True
    bundle = decision['bundle']
    oracle = oracle_namespace['independent_frontier'](bundle['support']['model'], committed_call=True)
    actual = {}
    for plan in bundle['plans'].values():
        action = plan['actions'][0]
        key = (action['mode'], tuple(action['ready_after']) if action['mode'] == 'invoke' else ())
        actual[key] = plan['total_ns']
    assert actual == oracle
    minimum = min(oracle.values())
    selected = decision['response']['pareto_candidate_ids']
    assert selected and all(bundle['plans'][key]['total_ns'] == minimum for key in selected)
    saved = retained_exact[(episode, step['batch'])]
    assert saved['gap_ns'] == 0 and saved['minimum_ns'] == minimum and saved['native_reinvoked'] is False
    exact_checked.append({'episode': episode, 'batch': step['batch'], 'gap_ns': 0})

gate_diagnostic = read('GATE_DIAGNOSTIC.json')
assert len(gate_diagnostic) == len(gate_keys) == 108
assert {(x['episode'], x['batch'], x['policy']) for x in gate_diagnostic} == gate_keys
assert all(x['old_mode'] == x['new_mode'] and x['observed_saving_ns'] is None for x in gate_diagnostic)
assert sum(x['bound_increase_ns'] > 0 for x in gate_diagnostic) == 36
gate_bases = dict(Counter(x['basis'] for x in gate_diagnostic))
assert all(not c['native_beats_all_controls'] for c in report['comparisons'])
assert report['acceptance']['native_net_win_scenarios'] == 0
assert report['acceptance']['native_net_benefit_established'] is False
assert report['acceptance']['full_lifecycle_cost_complete'] is False
for comparison in report['comparisons']:
    for arm in arms:
        values = sorted(row['service_wall_ns'] for row in rows
                        if row['policy'] == arm and row['episode'] == comparison['episode'])
        assert len(values) == 3 and values[1] == comparison['median_service_ns'][arm]
    measured = comparison['median_service_ns']
    assert measured['native_ndu'] / min(measured[a] for a in arms if a != 'native_ndu') == comparison['native_over_best_control']

assert RUNTIME_TERMINAL['job_id'] == '1a1adf15eed-fc05-5bef'
assert RUNTIME_TERMINAL['state'] == 'succeeded' and RUNTIME_TERMINAL['exit_code'] == 0
assert all(RUNTIME_TERMINAL[k] is True for k in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
assert RUNTIME_TERMINAL['timed_out'] is False and RUNTIME_TERMINAL['cancelled'] is False
assert git('show', '--no-patch', '--format=%H%n%T', 'HEAD').decode().splitlines() == [HEAD, TREE]
assert not git('status', '--porcelain', '--untracked-files=all').strip()

manifest = [identity(p) for p in sorted(EVIDENCE.rglob('*'))
            if p.is_file() and p.name not in OUTPUTS]
review = {
    'schema': 'hepta.hia.ndu.independent-preparation-bound-review.v1',
    'reviewed_unix_ns': time.time_ns(), 'source_commit': HEAD, 'source_tree': TREE,
    'source_parent': PARENT, 'source_clean_at_review': True,
    'source_identity_review': 'Absolute git, inherited GIT_* removed, no replacement objects, one head/tree snapshot, bytes checked against frozen Git blobs. This is a post-run review, not a retroactive runtime provenance guarantee.',
    'recorded_active_source_paths': len(registration['source_inventory']),
    'canonical_source_paths_verified_at_review': len(inventory),
    'changed_file_sha256': CHANGED,
    'integration_recommendation': 'accept narrow finite-model bound; include new test module in unified registration',
    'mathematical_review': {
        'maximum_savings_per_segment': 'Initial valid resident: S; otherwise max(0,S-(prepare+proof)); S sums max(0,baseline-execution-holding).',
        'optimistic_relaxations': ['free retirement', 'negative holding intervals omitted', 'overlapping per-artifact savings added', 'shared quota competition ignored', 'only first preparation paid within a validity segment'],
        'initial_invalid_resident': 'No free credit in later valid segment; ignored retirement cost only weakens the bound.',
        'individually_oversized_artifact': 'Excluded because it cannot fit any valid resident set.',
        'combination': 'Maximum of two independent lower bounds remains a lower bound; every invocation pays common gates, at least one call/startup when needed, and one session close.',
        'general_machine_checked_theorem': False,
    },
    'unit_tests': {'methods_passed': 39, 'new_methods': 10, 'new_fixed_models': 256,
                   'unit_reported_seconds': 2.652, 'outer_ns': unit['wall_ns'], 'rerun_by_review': False},
    'campaign': {'complete_episodes': 36, 'steps': steps, 'timed_calls': timed_calls,
                 'allocations': allocations, 'frees': frees, 'accounting_errors': 0,
                 'native_attempts_and_completions': 9, 'independent_raw_model_replays': exact_checked,
                 'native_net_win_scenarios': 0, 'scenario_count': 3, 'new_performance_runs_by_review': 0},
    'gate_diagnostic': {'rows': 108, 'bound_tighter': 36, 'gate_mode_changes': 0,
                        'basis_counts': gate_bases, 'causal_wall_savings_established': False},
    'costs': {'services_ns': services, 'actual_outer_campaign_ns': outer['outer_wall_ns'],
              'historical_reused_bridge_build_ns': registration['historical_bridge_build_cost']['wall_ns'],
              'new_bridge_build_incurred': False,
              'observed_disjoint_unit_registration_campaign_analysis_ns': sum(summary[k] for k in ('unit_outer_wall_ns', 'registration_prepare_wall_ns', 'actual_outer_wall_ns', 'post_run_analysis_wall_ns_before_summary_write')),
              'disjoint_total_scope': 'Recorded unit outer, pre-registration work, campaign child outer, and original post-run analysis. Excludes report serialization outside timers and this review; not a complete lifecycle total.',
              'hypothetical_single_arm_ns': summary['hypothetical_single_arm_complete_observed_runtime_ns'],
              'allocation_note': 'Hypothetical alternatives each charge the common remainder once, plus historical bridge only for native. Do not sum alternatives or report historical build as newly incurred.',
              'unknown_costs': summary['unknown_costs'], 'full_lifecycle_complete': False},
    'limits': ['Shared host, CPU 0-3 SMT siblings 24-27 not isolated; three repetitions are exploratory.',
               'NDU receives exact-DP-compressed witnesses for the same deterministic scalar objective, so it cannot improve that model optimum.',
               'This source-specific gate qualification is not the new unified composition result.',
               'No Agent-generation campaign, hardware claim, broad safety theorem, or NDU independent-value closure follows.'],
    'authority': 'DENY_ALL', 'safety_certificate': False,
    'runtime_terminal': RUNTIME_TERMINAL, 'inputs': manifest,
    'review_cpu_affinity': sorted(os.sched_getaffinity(0)),
    'review_wall_ns_before_output': time.monotonic_ns() - started,
}
write('NATIVE_RUNTIME_TERMINAL_REVIEW.json', RUNTIME_TERMINAL)
write('INDEPENDENT_REVIEW.json', review)
lines = [
    '# Independent review of the actual HIA NDU preparation bound', '',
    '**Integration recommendation: accept the narrow finite-model gate change. NDU independent value remains unproved.**', '',
    f'Measured source: `{HEAD}`; tree `{TREE}`; parent `{PARENT}`. The checkout is clean. This review checked all 206 recorded active source paths plus the changed test/document and independent oracle against canonical Git blobs; it does not replace the runtime identity evidence or the forthcoming unified candidate qualification.', '',
    '## Bound and implementation', '',
    'For one valid artifact segment, let S be the sum of positive baseline-minus-execution-minus-holding savings and P be preparation plus proof. An initially resident and valid artifact can recover at most S; otherwise it can recover at most max(0, S-P). Invalidation ends the initial-residency credit. Giving free retirement, omitting negative intervals, ignoring shared quota competition, and adding overlapping artifact savings only overestimates recoverable benefit. Excluding an artifact larger than the entire quota is safe. Subtracting these credits from baseline cost is therefore optimistic. Taking its maximum with the previous free-execution bound preserves the lower-bound direction.', '',
    'The unchanged gate/call/startup/close costs then rule out only invocations that cannot beat a feasible incumbent or fit the declared finite budget. Exact integer types, nonnegative costs, initial residency and authority boundaries remain enforced. This is a source-level argument plus finite implementation evidence, not a machine-checked general theorem or a physical deadline guarantee.', '',
    'The 39 registered tests passed (10 new methods, a fixed 256-model oracle set with exact budget boundaries); raw unittest elapsed time is 2.652 s and the enclosing test command is 2.872138577 s. This review did not rerun the tests or any performance cohort.', '',
    '## Retained native cohort', '',
    'The unchanged four arms, three scenarios and three repetitions completed all 36 episodes / 144 steps / 147,456 timed driver calls. Allocation accounting reports 144 allocations and 144 frees, no live allocation or accounting error. All nine attempted native decisions completed and match the independently enumerated exact finite-model minimum; this review replayed their retained models without invoking native NDU.', '',
    '| Scenario | Fixed median (ms) | Exact DP (ms) | Lightweight (ms) | Native NDU (ms) | NDU / best control |',
    '| --- | ---: | ---: | ---: | ---: | ---: |',
]
for c in report['comparisons']:
    m = c['median_service_ns']
    lines.append('| ' + c['episode'] + ' | ' + ' | '.join(f'{m[a]/1e6:.6f}' for a in arms) + f" | {c['native_over_best_control']:.6f} |")
lines += [
    '', '**Native NDU wins 0 of 3 scenarios.** Across the 108 retained dynamic gate decisions, 36 lower bounds tighten and zero gate modes change under replay of retained full models or the explicitly recorded receipt inference. This establishes no observed old-versus-new execution saving. The dedicated nonamortizing test does establish a real no-search/no-native path for its fixed input.', '',
    '## Cost boundaries and provenance', '',
    'Cumulative service times are fixed 0.928389624 s, exact DP 0.999299339 s, lightweight 0.961436691 s and native NDU 1.079345183 s. The actual campaign child outer wall time is 16.257438005 s, including imports and report output. Recorded disjoint unit, pre-registration, campaign and original post-analysis phases sum to 19.689411569 s; this partial ledger excludes unmeasured work and this independent review.', '',
    'The bridge was reused and its binary/manifest identities were revalidated. Its earlier measured 39.791607321 s build is charged only in the hypothetical standalone native allocation; it is not a new build or additional actual wall time in this cohort. The mutually exclusive hypothetical per-arm totals must not be summed. Human work, acquisition outside the measurement, energy, long-term storage and maintenance remain unknown; complete lifecycle cost is false.', '',
    'The runtime job `1a1adf15eed-fc05-5bef` is authoritatively succeeded, exit 0, output complete, output durable, and terminal publication confirmed. Source/tool/bridge snapshots and the complete raw file manifest are bound in `INDEPENDENT_REVIEW.json`; the fetched terminal receipt is preserved in `NATIVE_RUNTIME_TERMINAL_REVIEW.json`.', '',
    '## Remaining limits', '',
    'The host was shared and nonexclusive; CPU 0-3 SMT siblings 24-27 were not isolated. Three repetitions cannot establish a statistical or application-wide advantage. The current controller computes exact DP witnesses before native evaluation of the same scalar objective, so native NDU cannot improve that model optimum. The benefit claim still requires measured end-to-end improvement against strong fixed, lightweight and exact DP controls under a suitable real workload. No such improvement is established here.', '',
    'Include `tests.test_hia_ndu_preparation_bound` and its source identity in the unified candidate registration. The new unified run must bind this change together with Safe Core, AOT, verifier, toolchain and artifacts. Authority remains `DENY_ALL`; this review grants no safety certificate.', '',
]
with (EVIDENCE / 'INDEPENDENT_REVIEW.md').open('x') as stream:
    stream.write('\n'.join(lines))
print(json.dumps({'status': 'review_passed', 'source_commit': HEAD,
                  'canonical_source_paths': len(inventory), 'input_files': len(manifest),
                  'report': identity(EVIDENCE / 'INDEPENDENT_REVIEW.md'),
                  'audit': identity(EVIDENCE / 'INDEPENDENT_REVIEW.json'),
                  'runtime_receipt': identity(EVIDENCE / 'NATIVE_RUNTIME_TERMINAL_REVIEW.json')}, sort_keys=True))
