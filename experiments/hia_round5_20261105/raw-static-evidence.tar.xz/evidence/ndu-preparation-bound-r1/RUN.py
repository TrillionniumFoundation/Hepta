from pathlib import Path
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import threading
import time

ROOT = Path('/data/hepta-hia-round5-a3b4-20261105/work-ndu')
EVIDENCE = Path('/data/hepta-hia-round5-a3b4-20261105/evidence/ndu-preparation-bound-r1')
ORIGINAL = Path('/data/hepta-hia-round4-9925-20261105/evidence/frozen-996e2626d9aa-r1/composition')
SOURCE = '66d796e8abefe87d97b4096912136cdcd3299bfc'

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')

def identity(path):
    p = Path(path)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

prepare_start = time.monotonic_ns()
os.sched_setaffinity(0, {0, 1, 2, 3})
assert git('rev-parse', 'HEAD') == SOURCE
assert not git('status', '--porcelain', '--untracked-files=all')
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_ndu_cost import spec, source_inventory

original = json.loads((ORIGINAL / 'commands/ndu_full_cost.command.json').read_bytes())
combination = json.loads((ORIGINAL / 'COMBINATION.json').read_bytes())
old_report = json.loads((ORIGINAL / 'ndu-cost/REPORT.json').read_bytes())
assert old_report['status'] == 'completed'
assert spec() == old_report['specification']
argv = list(original['argv'])
argv[argv.index('--output') + 1] = str(EVIDENCE / 'campaign')
argv.remove('--bridge-built-this-campaign')
assert not (EVIDENCE / 'campaign').exists()
bridge = Path(argv[argv.index('--bridge') + 1])
manifest = Path(argv[argv.index('--identity') + 1])
assert identity(bridge)['sha256'] == combination['ndu']['binary_sha256']
assert identity(manifest)['sha256'] == combination['ndu_build_identity_sha256']
tool_ids = {}
for name in ('python', 'clang', 'rustc'):
    pin = combination['tools'][name]
    measured = identity(pin['path'])
    assert measured['sha256'] == pin['sha256']
    tool_ids[name] = measured
selected_env = dict(original['explicit_environment'])
selected_env['CARGO_TARGET_DIR'] = str(EVIDENCE / 'unused-rust-shadow-target')
selected_env['PYTHONDONTWRITEBYTECODE'] = '1'
env = {**os.environ, **selected_env}
source_before = source_inventory()
siblings = {str(cpu): Path(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list').read_text().strip()
            for cpu in range(4)}
registration = {'schema': 'hepta.hia.ndu.hia-preparation-registration.v1',
    'registered_unix_ns': time.time_ns(), 'source_commit': SOURCE,
    'source_tree': git('rev-parse', 'HEAD^{tree}'), 'source_clean': True,
    'source_inventory': source_before, 'specification': spec(),
    'source_change': 'preparation/proof/holding/validity bound on actual HIA cost path',
    'all_original_arms_scenarios_repetitions_and_seeds_unchanged': True,
    'original_command': identity(ORIGINAL / 'commands/ndu_full_cost.command.json'),
    'original_report': identity(ORIGINAL / 'ndu-cost/REPORT.json'),
    'argv': argv, 'cwd': str(ROOT), 'explicit_environment': selected_env,
    'timeout_seconds': original['timeout_seconds'],
    'cpu_affinity': sorted(os.sched_getaffinity(0)), 'cpu_thread_siblings': siblings,
    'shared_nonexclusive_host': True, 'tools': tool_ids,
    'bridge': identity(bridge), 'bridge_manifest': identity(manifest),
    'upstream_ndu_commit': combination['ndu_source_pin'],
    'stream_profile': combination['ndu_stream_profile'],
    'native_bridge_reused': True, 'native_bridge_rebuilt_this_campaign': False,
    'historical_bridge_build_cost': combination['ndu']['build_cost'],
    'bridge_cost_scope': 'Prior measured build is charged in hypothetical standalone native totals; it is not a new build or added actual wall in this run.',
    'runner': identity(EVIDENCE / 'RUN.py'),
    'rerun_policy': 'One complete candidate campaign. Retain every row and failure; no best-of, sample exclusion, selected-cell rerun or model-generation run.',
    'authority': 'DENY_ALL', 'safety_certificate': False,
    'preparation_wall_ns_before_registration_write': time.monotonic_ns() - prepare_start}
write(EVIDENCE / 'REGISTRATION.json', registration)
print('REGISTERED', SOURCE, flush=True)

stop = threading.Event()
def monitor():
    with (EVIDENCE / 'load.jsonl').open('x') as stream:
        while not stop.is_set():
            row = {'unix_ns': time.time_ns(), 'monotonic_ns': time.monotonic_ns(),
                   'loadavg': Path('/proc/loadavg').read_text(),
                   'cpu_stat': Path('/proc/stat').read_text()}
            stream.write(json.dumps(row, sort_keys=True) + '\n')
            stream.flush()
            stop.wait(1)

observer = threading.Thread(target=monitor, daemon=True)
observer.start()
started_unix = time.time_ns()
started = time.monotonic_ns()
before_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
timeout = False
launch_error = None
try:
    with (EVIDENCE / 'stdout').open('xb') as out, (EVIDENCE / 'stderr').open('xb') as err:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=out, stderr=err,
                                 start_new_session=True)
        try:
            returncode = child.wait(timeout=original['timeout_seconds'])
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            returncode = 124
except Exception as error:
    launch_error = {'type': type(error).__name__, 'message': str(error)}
    returncode = 125
finally:
    outer_wall = time.monotonic_ns() - started
    after_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    stop.set()
    observer.join(timeout=5)

source_after = source_inventory()
receipt = {'schema': 'hepta.hia.ndu.hia-preparation-outer.v1',
    'registration': identity(EVIDENCE / 'REGISTRATION.json'), 'source_commit': SOURCE,
    'started_unix_ns': started_unix, 'returncode': returncode, 'timed_out': timeout,
    'launch_error': launch_error, 'outer_wall_ns': outer_wall,
    'child_user_cpu_ns': round((after_usage.ru_utime - before_usage.ru_utime) * 1e9),
    'child_system_cpu_ns': round((after_usage.ru_stime - before_usage.ru_stime) * 1e9),
    'child_peak_rss_kib': after_usage.ru_maxrss,
    'child_peak_rss_scope': 'High-water across this fresh outer process children, including preflight Git reads; not per-policy RSS.',
    'source_commit_after': git('rev-parse', 'HEAD'),
    'source_status_after': git('status', '--porcelain', '--untracked-files=all'),
    'source_inventory_after': source_after,
    'source_bytes_unchanged': source_before == source_after,
    'tools_after': {name: identity(value['path']) for name, value in tool_ids.items()},
    'bridge_after': identity(bridge), 'bridge_manifest_after': identity(manifest),
    'native_bridge_reused': True, 'new_native_bridge_build_incurred': False,
    'actual_outer_excludes_historical_bridge_build': True,
    'load_monitor_finished': not observer.is_alive(),
    'original_streams': {name: identity(EVIDENCE / name) for name in ('stdout', 'stderr', 'load.jsonl')},
    'authority': 'DENY_ALL', 'safety_certificate': False}
if (EVIDENCE / 'campaign/REPORT.json').exists():
    receipt['report'] = identity(EVIDENCE / 'campaign/REPORT.json')
write(EVIDENCE / 'OUTER_RESULT.json', receipt)
print(json.dumps({key: receipt[key] for key in ('source_commit', 'returncode', 'timed_out',
      'launch_error', 'outer_wall_ns', 'source_bytes_unchanged', 'source_status_after')}), flush=True)
sys.exit(returncode)
