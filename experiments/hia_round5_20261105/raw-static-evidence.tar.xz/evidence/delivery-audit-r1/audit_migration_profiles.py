#!/usr/bin/env python3
"""Read-only audit of frozen S3 migration evidence; no new native/model run."""
import hashlib,json,os,pathlib,subprocess,time
os.sched_setaffinity(0,{8,9})
SRC=pathlib.Path('/data/hepta-hia-round4-9925-20261105/work-s3')
BASE=pathlib.Path('/data/hepta-hia-round4-9925-20261105/evidence/frozen-996e2626d9aa-r1/composition')
OUT=pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/delivery-audit-r1')
EXPECTED='996e2626d9aa89bc0e2b1017ebb858c6666604e7'
TREE='3ca2a8946cb52d7aab94cc7ac47f610dbba4e63e'
def state():
 env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
 def git(*args):
  return subprocess.run(['git','--no-replace-objects',*args],cwd=SRC,env=env,capture_output=True,text=True,check=True).stdout
 head,tree=git('show','--no-patch','--format=%H%n%T','HEAD').strip().splitlines()
 return {'commit':head,'tree':tree,'status':git('status','--porcelain=v1','--untracked-files=all')}
def ident(p):
 p=pathlib.Path(p);raw=p.read_bytes()
 return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
refs=[]
def read(rel):
 p=BASE/rel;refs.append(ident(p));return json.loads(p.read_bytes())
def artifact(row):
 p=pathlib.Path(row['path'])
 assert p.is_relative_to(BASE)
 actual=ident(p)
 assert actual['sha256']==row['sha256'] and actual['bytes']==row['bytes']
 return actual
before=state()
assert before=={'commit':EXPECTED,'tree':TREE,'status':''},before
unique=[]
for name,count in [('reset',1245),('reuse',2211),('swap',2616)]:
 d=read('cpp-unique-'+name+'/qualification.json')
 assert d['ok'] and d['source_bindings_unchanged']
 assert d['claims']['real_upstream_library_upgrade_tested'] is False
 assert d['claims']['maintenance_variant_is_authored_project_api_change'] is True
 rows=[]
 for v in d['variants']:
  assert v['case_count']==count==sum(v['families'].values())
  expected=v['expected']
  assert expected['ok'] and expected['live']==0 and expected['allocations']==expected['frees']
  assert v['reference']['execution']['returncode']==0==v['standalone_hia']['execution']['returncode']
  assert v['standalone_hia']['original_cpp_link_inputs']==[]
  rows.append({'variant':v['name'],'case_count':v['case_count'],'families':v['families'],'independent_expected':expected,
    'profile':v['migration']['profile'],'migration_costs':v['migration']['costs'],
    'native_reference':artifact(v['reference']['artifact']),'native_hia':artifact(v['standalone_hia']['artifact']),
    'independent_c_caller':artifact(v['reference']['c_caller'])})
 unique.append({'kind':name,'claims':d['claims'],'costs':d['costs'],'variants':rows})
g=read('gsl-upgrade/report.json')
assert g['ok'] and set(g['versions'])=={'3.1.0','4.0.0','5.0.1'}
gsl={'component':g['component'],'scope':g['scope'],'versions':sorted(g['versions']),
     'cases_per_pair':g['case_count_per_version'],'execution_denominator':g['execution_denominator'],
     'claims':g['claims'],'cost':g['cost'],'native_abi':{k:v for k,v in g['native_abi'].items() if k!='commands'}}
for version,v in g['versions'].items():
 assert v['native_original_matches_oracle'] and v['standalone_migration_matches_oracle']
 assert v['migrated_linked_cpp_objects']==[]
d=read('migration-resources/report.json')
assert d['ok'] and d['source_revision']==EXPECTED and d['tracked_changes_at_start']==[]
sqlite=d['sqlite']
assert sqlite['ok'] and set(sqlite['versions'])=={'3.46.0','3.53.2'}
sv=[]
for version,v in sqlite['versions'].items():
 assert v['oracle_equal'] and v['automatically_converted_functions']==2 and v['selected_candidate_functions']==2
 assert v['retained_original_cpp_or_c_link_objects']==[]
 sv.append({'version':version,'inputs':v['inputs'],'native_function_observations':v['native_function_observations'],
            'candidate_function_fraction':v['candidate_function_fraction'],'upstream':v['upstream'],
            'source_migration_and_native_build_ns':v['source_migration_and_native_build_ns']})
assert len({x['upstream']['source_slice_sha256'] for x in sv})==1
assert sqlite['scope']['raw_c_abi_bridge_execution_qualified'] is False
sql={'scope':sqlite['scope'],'versions':sv,'selected_function_bytes_unchanged_across_releases':True,
     'cannot_credit_changed_upstream_function_maintenance':True}
ports=read('upstream-native-ports/CONTROLS.json')
assert ports['ok'] and ports['model_requests']==0
upstream={'scope':ports['scope'],'model_requests':ports['model_requests'],'human_labor_ns':ports['human_labor_ns'],
          'rows':[{k:v for k,v in r.items() if k not in ('build','execution','binary')} for r in ports['rows']],
          'task_count':len({r['task'] for r in ports['rows']}),'wall_ns':ports['wall_ns']}
assert upstream['task_count']==2
host=read('host-region/RESULT.json');race=read('host-region-race/RESULT.json')
assert host['qualification_valid'] and race['qualification_valid']
assert host['kernel_read_only_fault']['returncode']==host['kernel_read_only_fault']['expected']==-11
hs={'scope':host['scope'],'claims':host['claims'],'kernel_fault_returncode':host['kernel_read_only_fault']['returncode'],
    'reader_peak':host['execution']['native_concurrent_reader_peak'],
    'denials':[x['case'] for x in host['execution']['denials']],
    'retained_after':host['execution']['retained_after'],
    'artifact':artifact(host['artifact'])}
rs={'scope':race['scope'],'claims':race['claims'],'native_reader_entries':race['execution']['native_reader_entries'],
    'recovery_statuses':sorted(r['status'] for r in race['execution']['recoveries']),
    'old_caller_cannot_commit_or_revoke_recovered_epoch':race['execution']['old_caller_cannot_commit_or_revoke_recovered_epoch'],
    'all_native_workers_joined':race['execution']['all_native_workers_joined'],
    'retained_after':race['execution']['retained_after'],'artifact':artifact(race['race_artifact'])}
for row in refs:
 assert ident(row['path'])==row
after=state()
assert after==before
report={'schema':'hepta.hia.frozen-migration-and-profile-audit.v1','source':before,'source_after':after,
        'audit_unix_ns':time.time_ns(),'new_native_or_model_executions':0,
        'unique_ptr_authored_fixtures':unique,'gsl_real_upstream_upgrade':gsl,'sqlite_two_release_selected_functions':sql,
        'stb_historical_reference_controls':upstream,'historical_host_region':hs,'historical_race':rs,
        'source_reports':refs,'claims':{'industrial_migration_productivity_proved':False,
        'general_c_cpp_abi_preserved':False,'all_upstream_configurations_qualified':False,
        'whole_library_migration':False,'language_concurrency_proved':False,
        'same_commit_does_not_turn_historical_evidence_into_new_execution':True},
        'remaining_work':['Changed upstream implementation samples beyond one selected GSL specialization.',
        'Whole component build configurations, ABI and error/lifecycle comparison beyond admitted scalar/fixed slice profiles.',
        'Measured human/agent maintenance cost rather than null or generated byte counts.',
        'Target-specific real hardware execution for each new ABI/device profile and corresponding memory model evidence.']}
OUT.mkdir(parents=True,exist_ok=True)
with (OUT/'migration-audit.json').open('xb') as f:f.write(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
print(json.dumps({'passed':True,'report':ident(OUT/'migration-audit.json'),'source_commit':EXPECTED,
                  'unique_variant_cases':[[x['kind'],[v['case_count'] for v in x['variants']]] for x in unique],
                  'sqlite_selected_bytes_identical':True,'gsl_positive_native_scalar_calls':g['execution_denominator']['positive_native_scalar_calls']}))
