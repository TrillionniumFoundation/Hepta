"""Record the selected LLVM return-type boundary against the exact S3 source."""
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))

from hepta.hia_program import verify_program
from hepta.hia_program_llvm import emit_program_llvm
from hepta.hia_scalar_lowering_check import ScalarLoweringRejected, verify_scalar_lowering
from tests.test_hia_scalar_lowering_check import scalar_program


def main():
    output = Path(__file__).parent
    program = scalar_program("int.div.checked", "u64")
    entry = program["functions"][0]["blocks"][0]
    entry["ops"] = []
    entry["term"] = {"op": "trap", "code": "bounds"}
    checked = verify_program(program)
    original = emit_program_llvm(checked).text
    header = re.search(r"(?m)^define internal i64 @__hia_fn_0\([^\n]*\) \{\n", original)
    assert header is not None
    end = original.index("\n}\n", header.end())
    body = ("b0:\n  br i1 false, label %unused_return, label %always_abort\n"
            "unused_return:\n  ret {return_type} {literal}\n"
            "always_abort:\n  call void @abort()\n  unreachable")
    documents = {"original": original}
    for name, typ, literal in (("valid_dead_return", "i64", "0"),
                               ("invalid_dead_i8_return", "i8", "0"),
                               ("invalid_dead_i1_return", "i1", "false")):
        documents[name] = original[:header.end()] + body.format(return_type=typ, literal=literal) + original[end:]
    (output / "core.hia.json").write_bytes(checked.canonical_bytes)
    version = subprocess.run(["/usr/bin/llvm-as", "--version"], text=True, capture_output=True, timeout=10)
    result = {
        "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "source_tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip(),
        "checker_sha256": sha256((ROOT / "hepta/hia_scalar_lowering_check.py").read_bytes()).hexdigest(),
        "diagnostic_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "core_sha256": checked.sha256,
        "python": sys.executable,
        "llvm_as": {"path": "/usr/bin/llvm-as", "version": version.stdout, "version_exit": version.returncode},
        "qualification": False,
        "note": "System llvm-as is an independent syntax/type rejection observation; it does not replace the pinned production Clang 20 profile.",
        "rows": [],
    }
    for name, text in documents.items():
        path = output / (name + ".ll")
        path.write_text(text)
        row = {"name": name, "llvm_sha256": sha256(text.encode()).hexdigest()}
        try:
            report = verify_scalar_lowering(checked, llvm_text=text)
            (output / (name + ".check.json")).write_text(json.dumps(report, indent=2) + "\n")
            row["validator"] = {key: report[key] for key in (
                "status", "verified", "actual_emitter_output", "core_return_paths", "llvm_return_paths", "claims")}
        except ScalarLoweringRejected as error:
            row["validator"] = {"status": "rejected", "reason": str(error)}
        compiled = subprocess.run(["/usr/bin/llvm-as", str(path), "-o", str(output / (name + ".bc"))],
                                  text=True, capture_output=True, timeout=30)
        row["llvm_as"] = {"exit_code": compiled.returncode, "stdout": compiled.stdout, "stderr": compiled.stderr}
        result["rows"].append(row)
        print(json.dumps(row), flush=True)
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
