from pathlib import Path
import sys,json,subprocess
root=Path(sys.argv[1]); out=Path(sys.argv[2]); clang=sys.argv[3]
sys.path.insert(0,str(root))
from hepta.hia_program_source import lower_source
from hepta.hia_reduction import propose_reduction_pipeline,reduction_program
from hepta.hia_program_llvm import build_program_native
out.mkdir(parents=True,exist_ok=True)
for workload in ('linear','affine'):
 source=lower_source((root/('benchmarks/hia_reduction_release/'+workload+'.hepta')).read_text())
 p=reduction_program(source,propose_reduction_pipeline(source,include_induction=True))
 receipt=build_program_native(p,out/(workload+'.so'),clang=clang,layout='guarded-outline-v1')
 (out/(workload+'.receipt.json')).write_text(json.dumps(receipt,indent=2,default=str)+'\n')
 a=subprocess.run(['/usr/bin/objdump','-d',str(out/(workload+'.so'))],capture_output=True,text=True,check=True)
 (out/(workload+'.asm')).write_text(a.stdout)
 print(workload+' built')
