
/data/hepta-hia-round5-a3b4-20261105/aot-half-tail-diagnostic/candidate/linear.so：     文件格式 elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 2f 00 00 	mov    0x2fc1(%rip),%rax        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <free@plt-0x10>:
    1020:	ff 35 ca 2f 00 00    	push   0x2fca(%rip)        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    *0x2fcc(%rip)        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <free@plt>:
    1030:	ff 25 ca 2f 00 00    	jmp    *0x2fca(%rip)        # 4000 <free@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

0000000000001040 <abort@plt>:
    1040:	ff 25 c2 2f 00 00    	jmp    *0x2fc2(%rip)        # 4008 <abort@GLIBC_2.2.5>
    1046:	68 01 00 00 00       	push   $0x1
    104b:	e9 d0 ff ff ff       	jmp    1020 <_init+0x20>

0000000000001050 <malloc@plt>:
    1050:	ff 25 ba 2f 00 00    	jmp    *0x2fba(%rip)        # 4010 <malloc@GLIBC_2.2.5>
    1056:	68 02 00 00 00       	push   $0x2
    105b:	e9 c0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001060 <__cxa_finalize@plt>:
    1060:	ff 25 7a 2f 00 00    	jmp    *0x2f7a(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1066:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001070 <deregister_tm_clones>:
    1070:	48 8d 3d a9 2f 00 00 	lea    0x2fa9(%rip),%rdi        # 4020 <completed.0>
    1077:	48 8d 05 a2 2f 00 00 	lea    0x2fa2(%rip),%rax        # 4020 <completed.0>
    107e:	48 39 f8             	cmp    %rdi,%rax
    1081:	74 15                	je     1098 <deregister_tm_clones+0x28>
    1083:	48 8b 05 3e 2f 00 00 	mov    0x2f3e(%rip),%rax        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    108a:	48 85 c0             	test   %rax,%rax
    108d:	74 09                	je     1098 <deregister_tm_clones+0x28>
    108f:	ff e0                	jmp    *%rax
    1091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1098:	c3                   	ret
    1099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:	48 8d 3d 79 2f 00 00 	lea    0x2f79(%rip),%rdi        # 4020 <completed.0>
    10a7:	48 8d 35 72 2f 00 00 	lea    0x2f72(%rip),%rsi        # 4020 <completed.0>
    10ae:	48 29 fe             	sub    %rdi,%rsi
    10b1:	48 89 f0             	mov    %rsi,%rax
    10b4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10b8:	48 c1 f8 03          	sar    $0x3,%rax
    10bc:	48 01 c6             	add    %rax,%rsi
    10bf:	48 d1 fe             	sar    $1,%rsi
    10c2:	74 14                	je     10d8 <register_tm_clones+0x38>
    10c4:	48 8b 05 0d 2f 00 00 	mov    0x2f0d(%rip),%rax        # 3fd8 <_ITM_registerTMCloneTable@Base>
    10cb:	48 85 c0             	test   %rax,%rax
    10ce:	74 08                	je     10d8 <register_tm_clones+0x38>
    10d0:	ff e0                	jmp    *%rax
    10d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10d8:	c3                   	ret
    10d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	80 3d 35 2f 00 00 00 	cmpb   $0x0,0x2f35(%rip)        # 4020 <completed.0>
    10eb:	75 2b                	jne    1118 <__do_global_dtors_aux+0x38>
    10ed:	55                   	push   %rbp
    10ee:	48 83 3d ea 2e 00 00 	cmpq   $0x0,0x2eea(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10f5:	00 
    10f6:	48 89 e5             	mov    %rsp,%rbp
    10f9:	74 0c                	je     1107 <__do_global_dtors_aux+0x27>
    10fb:	48 8b 3d 16 2f 00 00 	mov    0x2f16(%rip),%rdi        # 4018 <__dso_handle>
    1102:	e8 59 ff ff ff       	call   1060 <__cxa_finalize@plt>
    1107:	e8 64 ff ff ff       	call   1070 <deregister_tm_clones>
    110c:	c6 05 0d 2f 00 00 01 	movb   $0x1,0x2f0d(%rip)        # 4020 <completed.0>
    1113:	5d                   	pop    %rbp
    1114:	c3                   	ret
    1115:	0f 1f 00             	nopl   (%rax)
    1118:	c3                   	ret
    1119:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001120 <frame_dummy>:
    1120:	f3 0f 1e fa          	endbr64
    1124:	e9 77 ff ff ff       	jmp    10a0 <register_tm_clones>
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <__hia_fn_1>:
    1130:	55                   	push   %rbp
    1131:	41 56                	push   %r14
    1133:	53                   	push   %rbx
    1134:	48 85 ff             	test   %rdi,%rdi
    1137:	74 1c                	je     1155 <__hia_fn_1+0x25>
    1139:	89 f5                	mov    %esi,%ebp
    113b:	48 89 fb             	mov    %rdi,%rbx
    113e:	e8 0d ff ff ff       	call   1050 <malloc@plt>
    1143:	48 85 c0             	test   %rax,%rax
    1146:	74 17                	je     115f <__hia_fn_1+0x2f>
    1148:	48 83 fb 03          	cmp    $0x3,%rbx
    114c:	77 1c                	ja     116a <__hia_fn_1+0x3a>
    114e:	31 c9                	xor    %ecx,%ecx
    1150:	e9 da 00 00 00       	jmp    122f <__hia_fn_1+0xff>
    1155:	31 c0                	xor    %eax,%eax
    1157:	45 31 f6             	xor    %r14d,%r14d
    115a:	e9 1c 02 00 00       	jmp    137b <__hia_fn_1+0x24b>
    115f:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1165:	e9 1e 02 00 00       	jmp    1388 <__hia_fn_1+0x258>
    116a:	48 be f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rsi
    1171:	ff ff 01 
    1174:	40 0f b6 d5          	movzbl %bpl,%edx
    1178:	48 83 fb 10          	cmp    $0x10,%rbx
    117c:	73 04                	jae    1182 <__hia_fn_1+0x52>
    117e:	31 c9                	xor    %ecx,%ecx
    1180:	eb 56                	jmp    11d8 <__hia_fn_1+0xa8>
    1182:	48 89 d9             	mov    %rbx,%rcx
    1185:	48 21 f1             	and    %rsi,%rcx
    1188:	66 0f 6e c2          	movd   %edx,%xmm0
    118c:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1190:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1195:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    119a:	66 0f 6f 0d 5e 0e 00 	movdqa 0xe5e(%rip),%xmm1        # 2000 <_fini+0xb00>
    11a1:	00 
    11a2:	31 ff                	xor    %edi,%edi
    11a4:	66 0f 6f 15 64 0e 00 	movdqa 0xe64(%rip),%xmm2        # 2010 <_fini+0xb10>
    11ab:	00 
    11ac:	0f 1f 40 00          	nopl   0x0(%rax)
    11b0:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    11b4:	66 0f fc d8          	paddb  %xmm0,%xmm3
    11b8:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
    11bd:	48 83 c7 10          	add    $0x10,%rdi
    11c1:	66 0f fc ca          	paddb  %xmm2,%xmm1
    11c5:	48 39 f9             	cmp    %rdi,%rcx
    11c8:	75 e6                	jne    11b0 <__hia_fn_1+0x80>
    11ca:	48 39 cb             	cmp    %rcx,%rbx
    11cd:	0f 84 7c 00 00 00    	je     124f <__hia_fn_1+0x11f>
    11d3:	f6 c3 0c             	test   $0xc,%bl
    11d6:	74 57                	je     122f <__hia_fn_1+0xff>
    11d8:	48 89 cf             	mov    %rcx,%rdi
    11db:	48 83 c6 0c          	add    $0xc,%rsi
    11df:	48 89 f1             	mov    %rsi,%rcx
    11e2:	48 21 d9             	and    %rbx,%rcx
    11e5:	66 0f 6e c7          	movd   %edi,%xmm0
    11e9:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    11ed:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    11f2:	66 0f eb 05 26 0e 00 	por    0xe26(%rip),%xmm0        # 2020 <_fini+0xb20>
    11f9:	00 
    11fa:	66 0f 6e ca          	movd   %edx,%xmm1
    11fe:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1202:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    1207:	66 0f 6f 15 21 0e 00 	movdqa 0xe21(%rip),%xmm2        # 2030 <_fini+0xb30>
    120e:	00 
    120f:	90                   	nop
    1210:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    1214:	66 0f fc d9          	paddb  %xmm1,%xmm3
    1218:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
    121d:	48 83 c7 04          	add    $0x4,%rdi
    1221:	66 0f fc c2          	paddb  %xmm2,%xmm0
    1225:	48 39 f9             	cmp    %rdi,%rcx
    1228:	75 e6                	jne    1210 <__hia_fn_1+0xe0>
    122a:	48 39 cb             	cmp    %rcx,%rbx
    122d:	74 20                	je     124f <__hia_fn_1+0x11f>
    122f:	89 ea                	mov    %ebp,%edx
    1231:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1238:	0f 1f 84 00 00 00 00 
    123f:	00 
    1240:	8d 34 0a             	lea    (%rdx,%rcx,1),%esi
    1243:	40 88 34 08          	mov    %sil,(%rax,%rcx,1)
    1247:	48 ff c1             	inc    %rcx
    124a:	48 39 cb             	cmp    %rcx,%rbx
    124d:	75 f1                	jne    1240 <__hia_fn_1+0x110>
    124f:	48 83 fb 10          	cmp    $0x10,%rbx
    1253:	72 68                	jb     12bd <__hia_fn_1+0x18d>
    1255:	b9 10 00 00 00       	mov    $0x10,%ecx
    125a:	45 31 f6             	xor    %r14d,%r14d
    125d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1261:	48 89 da             	mov    %rbx,%rdx
    1264:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    126b:	00 00 00 00 00 
    1270:	48 89 ce             	mov    %rcx,%rsi
    1273:	f3 0f 6f 4c 08 f0    	movdqu -0x10(%rax,%rcx,1),%xmm1
    1279:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    127d:	66 48 0f 7e c9       	movq   %xmm1,%rcx
    1282:	4c 01 f1             	add    %r14,%rcx
    1285:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
    128a:	66 49 0f 7e ce       	movq   %xmm1,%r14
    128f:	49 01 ce             	add    %rcx,%r14
    1292:	48 83 c2 f0          	add    $0xfffffffffffffff0,%rdx
    1296:	48 8d 4e 10          	lea    0x10(%rsi),%rcx
    129a:	48 39 de             	cmp    %rbx,%rsi
    129d:	40 0f 96 c6          	setbe  %sil
    12a1:	77 08                	ja     12ab <__hia_fn_1+0x17b>
    12a3:	48 83 fa 10          	cmp    $0x10,%rdx
    12a7:	72 02                	jb     12ab <__hia_fn_1+0x17b>
    12a9:	73 c5                	jae    1270 <__hia_fn_1+0x140>
    12ab:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
    12af:	48 39 d9             	cmp    %rbx,%rcx
    12b2:	40 0f 96 c7          	setbe  %dil
    12b6:	40 84 ff             	test   %dil,%dil
    12b9:	75 15                	jne    12d0 <__hia_fn_1+0x1a0>
    12bb:	eb 3d                	jmp    12fa <__hia_fn_1+0x1ca>
    12bd:	40 b7 01             	mov    $0x1,%dil
    12c0:	31 c9                	xor    %ecx,%ecx
    12c2:	45 31 f6             	xor    %r14d,%r14d
    12c5:	48 89 da             	mov    %rbx,%rdx
    12c8:	40 b6 01             	mov    $0x1,%sil
    12cb:	40 84 ff             	test   %dil,%dil
    12ce:	74 2a                	je     12fa <__hia_fn_1+0x1ca>
    12d0:	40 84 f6             	test   %sil,%sil
    12d3:	74 25                	je     12fa <__hia_fn_1+0x1ca>
    12d5:	48 83 fa 08          	cmp    $0x8,%rdx
    12d9:	72 1f                	jb     12fa <__hia_fn_1+0x1ca>
    12db:	48 83 fa 08          	cmp    $0x8,%rdx
    12df:	72 19                	jb     12fa <__hia_fn_1+0x1ca>
    12e1:	f3 0f 7e 04 08       	movq   (%rax,%rcx,1),%xmm0
    12e6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    12ea:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    12ee:	66 48 0f 7e ca       	movq   %xmm1,%rdx
    12f3:	49 01 d6             	add    %rdx,%r14
    12f6:	48 83 c1 08          	add    $0x8,%rcx
    12fa:	48 89 ca             	mov    %rcx,%rdx
    12fd:	48 29 da             	sub    %rbx,%rdx
    1300:	73 79                	jae    137b <__hia_fn_1+0x24b>
    1302:	89 de                	mov    %ebx,%esi
    1304:	29 ce                	sub    %ecx,%esi
    1306:	83 e6 07             	and    $0x7,%esi
    1309:	74 14                	je     131f <__hia_fn_1+0x1ef>
    130b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1310:	0f b6 3c 08          	movzbl (%rax,%rcx,1),%edi
    1314:	49 01 fe             	add    %rdi,%r14
    1317:	48 ff c1             	inc    %rcx
    131a:	48 ff ce             	dec    %rsi
    131d:	75 f1                	jne    1310 <__hia_fn_1+0x1e0>
    131f:	48 83 fa f8          	cmp    $0xfffffffffffffff8,%rdx
    1323:	77 5b                	ja     1380 <__hia_fn_1+0x250>
    1325:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    132c:	00 00 00 00 
    1330:	0f b6 14 08          	movzbl (%rax,%rcx,1),%edx
    1334:	4c 01 f2             	add    %r14,%rdx
    1337:	0f b6 74 08 01       	movzbl 0x1(%rax,%rcx,1),%esi
    133c:	0f b6 7c 08 02       	movzbl 0x2(%rax,%rcx,1),%edi
    1341:	48 01 f7             	add    %rsi,%rdi
    1344:	48 01 d7             	add    %rdx,%rdi
    1347:	0f b6 54 08 03       	movzbl 0x3(%rax,%rcx,1),%edx
    134c:	0f b6 74 08 04       	movzbl 0x4(%rax,%rcx,1),%esi
    1351:	48 01 d6             	add    %rdx,%rsi
    1354:	0f b6 54 08 05       	movzbl 0x5(%rax,%rcx,1),%edx
    1359:	48 01 f2             	add    %rsi,%rdx
    135c:	48 01 fa             	add    %rdi,%rdx
    135f:	0f b6 74 08 06       	movzbl 0x6(%rax,%rcx,1),%esi
    1364:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
    136a:	49 01 f6             	add    %rsi,%r14
    136d:	49 01 d6             	add    %rdx,%r14
    1370:	48 83 c1 08          	add    $0x8,%rcx
    1374:	48 39 cb             	cmp    %rcx,%rbx
    1377:	75 b7                	jne    1330 <__hia_fn_1+0x200>
    1379:	eb 05                	jmp    1380 <__hia_fn_1+0x250>
    137b:	48 85 c0             	test   %rax,%rax
    137e:	74 08                	je     1388 <__hia_fn_1+0x258>
    1380:	48 89 c7             	mov    %rax,%rdi
    1383:	e8 a8 fc ff ff       	call   1030 <free@plt>
    1388:	4c 89 f0             	mov    %r14,%rax
    138b:	5b                   	pop    %rbx
    138c:	41 5e                	pop    %r14
    138e:	5d                   	pop    %rbp
    138f:	c3                   	ret

0000000000001390 <__hia_fn_2>:
    1390:	55                   	push   %rbp
    1391:	41 56                	push   %r14
    1393:	53                   	push   %rbx
    1394:	89 f5                	mov    %esi,%ebp
    1396:	48 89 fb             	mov    %rdi,%rbx
    1399:	48 85 ff             	test   %rdi,%rdi
    139c:	78 2a                	js     13c8 <__hia_fn_2+0x38>
    139e:	48 89 df             	mov    %rbx,%rdi
    13a1:	e8 aa fc ff ff       	call   1050 <malloc@plt>
    13a6:	48 85 c0             	test   %rax,%rax
    13a9:	74 1d                	je     13c8 <__hia_fn_2+0x38>
    13ab:	48 89 c7             	mov    %rax,%rdi
    13ae:	b0 01                	mov    $0x1,%al
    13b0:	a8 01                	test   $0x1,%al
    13b2:	75 1c                	jne    13d0 <__hia_fn_2+0x40>
    13b4:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    13ba:	48 85 ff             	test   %rdi,%rdi
    13bd:	0f 85 02 01 00 00    	jne    14c5 <__hia_fn_2+0x135>
    13c3:	e9 02 01 00 00       	jmp    14ca <__hia_fn_2+0x13a>
    13c8:	31 ff                	xor    %edi,%edi
    13ca:	31 c0                	xor    %eax,%eax
    13cc:	a8 01                	test   $0x1,%al
    13ce:	74 e4                	je     13b4 <__hia_fn_2+0x24>
    13d0:	48 89 d8             	mov    %rbx,%rax
    13d3:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    13d7:	66 0f 6e c5          	movd   %ebp,%xmm0
    13db:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    13df:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    13e4:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    13e9:	66 0f 6f 0d 0f 0c 00 	movdqa 0xc0f(%rip),%xmm1        # 2000 <_fini+0xb00>
    13f0:	00 
    13f1:	31 c9                	xor    %ecx,%ecx
    13f3:	66 0f 6f 15 15 0c 00 	movdqa 0xc15(%rip),%xmm2        # 2010 <_fini+0xb10>
    13fa:	00 
    13fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1400:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1404:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1408:	f3 0f 7f 1c 0f       	movdqu %xmm3,(%rdi,%rcx,1)
    140d:	48 83 c1 10          	add    $0x10,%rcx
    1411:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1415:	48 39 c8             	cmp    %rcx,%rax
    1418:	75 e6                	jne    1400 <__hia_fn_2+0x70>
    141a:	48 39 c3             	cmp    %rax,%rbx
    141d:	74 7f                	je     149e <__hia_fn_2+0x10e>
    141f:	f6 c3 0c             	test   $0xc,%bl
    1422:	74 5d                	je     1481 <__hia_fn_2+0xf1>
    1424:	48 89 d9             	mov    %rbx,%rcx
    1427:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    142b:	66 0f 6e c0          	movd   %eax,%xmm0
    142f:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1433:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1438:	66 0f eb 05 e0 0b 00 	por    0xbe0(%rip),%xmm0        # 2020 <_fini+0xb20>
    143f:	00 
    1440:	40 0f b6 d5          	movzbl %bpl,%edx
    1444:	66 0f 6e ca          	movd   %edx,%xmm1
    1448:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    144c:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    1451:	66 0f 6f 15 d7 0b 00 	movdqa 0xbd7(%rip),%xmm2        # 2030 <_fini+0xb30>
    1458:	00 
    1459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1460:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    1464:	66 0f fc d9          	paddb  %xmm1,%xmm3
    1468:	66 0f 7e 1c 07       	movd   %xmm3,(%rdi,%rax,1)
    146d:	48 83 c0 04          	add    $0x4,%rax
    1471:	66 0f fc c2          	paddb  %xmm2,%xmm0
    1475:	48 39 c1             	cmp    %rax,%rcx
    1478:	75 e6                	jne    1460 <__hia_fn_2+0xd0>
    147a:	48 39 cb             	cmp    %rcx,%rbx
    147d:	75 05                	jne    1484 <__hia_fn_2+0xf4>
    147f:	eb 1d                	jmp    149e <__hia_fn_2+0x10e>
    1481:	48 89 c1             	mov    %rax,%rcx
    1484:	89 e8                	mov    %ebp,%eax
    1486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    148d:	00 00 00 
    1490:	8d 14 08             	lea    (%rax,%rcx,1),%edx
    1493:	88 14 0f             	mov    %dl,(%rdi,%rcx,1)
    1496:	48 ff c1             	inc    %rcx
    1499:	48 39 cb             	cmp    %rcx,%rbx
    149c:	75 f2                	jne    1490 <__hia_fn_2+0x100>
    149e:	31 c0                	xor    %eax,%eax
    14a0:	45 31 f6             	xor    %r14d,%r14d
    14a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    14aa:	84 00 00 00 00 00 
    14b0:	4c 89 f1             	mov    %r14,%rcx
    14b3:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    14b8:	49 01 ce             	add    %rcx,%r14
    14bb:	72 15                	jb     14d2 <__hia_fn_2+0x142>
    14bd:	48 ff c0             	inc    %rax
    14c0:	48 39 c3             	cmp    %rax,%rbx
    14c3:	75 eb                	jne    14b0 <__hia_fn_2+0x120>
    14c5:	e8 66 fb ff ff       	call   1030 <free@plt>
    14ca:	4c 89 f0             	mov    %r14,%rax
    14cd:	5b                   	pop    %rbx
    14ce:	41 5e                	pop    %r14
    14d0:	5d                   	pop    %rbp
    14d1:	c3                   	ret
    14d2:	e8 69 fb ff ff       	call   1040 <abort@plt>
    14d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    14de:	00 00 

00000000000014e0 <calculate>:
    14e0:	48 85 ff             	test   %rdi,%rdi
    14e3:	75 03                	jne    14e8 <calculate+0x8>
    14e5:	31 c0                	xor    %eax,%eax
    14e7:	c3                   	ret
    14e8:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
    14ef:	01 01 01 
    14f2:	48 39 c7             	cmp    %rax,%rdi
    14f5:	0f 86 35 fc ff ff    	jbe    1130 <__hia_fn_1>
    14fb:	e9 90 fe ff ff       	jmp    1390 <__hia_fn_2>

Disassembly of section .fini:

0000000000001500 <_fini>:
    1500:	f3 0f 1e fa          	endbr64
    1504:	48 83 ec 08          	sub    $0x8,%rsp
    1508:	48 83 c4 08          	add    $0x8,%rsp
    150c:	c3                   	ret
