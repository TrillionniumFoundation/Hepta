
/data/hepta-hia-round5-a3b4-20261105/aot-half-tail-diagnostic/baseline/affine.so：     文件格式 elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 2f 00 00 	mov    0x2fc1(%rip),%rax        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <free@plt-0x10>:
    1020:	ff 35 ca 2f 00 00    	push   0x2fca(%rip)        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    *0x2fcc(%rip)        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <free@plt>:
    1030:	ff 25 ca 2f 00 00    	jmp    *0x2fca(%rip)        # 4000 <free@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

0000000000001040 <abort@plt>:
    1040:	ff 25 c2 2f 00 00    	jmp    *0x2fc2(%rip)        # 4008 <abort@GLIBC_2.2.5>
    1046:	68 01 00 00 00       	push   $0x1
    104b:	e9 d0 ff ff ff       	jmp    1020 <_init+0x20>

0000000000001050 <malloc@plt>:
    1050:	ff 25 ba 2f 00 00    	jmp    *0x2fba(%rip)        # 4010 <malloc@GLIBC_2.2.5>
    1056:	68 02 00 00 00       	push   $0x2
    105b:	e9 c0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001060 <__cxa_finalize@plt>:
    1060:	ff 25 7a 2f 00 00    	jmp    *0x2f7a(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1066:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001070 <deregister_tm_clones>:
    1070:	48 8d 3d a9 2f 00 00 	lea    0x2fa9(%rip),%rdi        # 4020 <completed.0>
    1077:	48 8d 05 a2 2f 00 00 	lea    0x2fa2(%rip),%rax        # 4020 <completed.0>
    107e:	48 39 f8             	cmp    %rdi,%rax
    1081:	74 15                	je     1098 <deregister_tm_clones+0x28>
    1083:	48 8b 05 3e 2f 00 00 	mov    0x2f3e(%rip),%rax        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    108a:	48 85 c0             	test   %rax,%rax
    108d:	74 09                	je     1098 <deregister_tm_clones+0x28>
    108f:	ff e0                	jmp    *%rax
    1091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1098:	c3                   	ret
    1099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:	48 8d 3d 79 2f 00 00 	lea    0x2f79(%rip),%rdi        # 4020 <completed.0>
    10a7:	48 8d 35 72 2f 00 00 	lea    0x2f72(%rip),%rsi        # 4020 <completed.0>
    10ae:	48 29 fe             	sub    %rdi,%rsi
    10b1:	48 89 f0             	mov    %rsi,%rax
    10b4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10b8:	48 c1 f8 03          	sar    $0x3,%rax
    10bc:	48 01 c6             	add    %rax,%rsi
    10bf:	48 d1 fe             	sar    $1,%rsi
    10c2:	74 14                	je     10d8 <register_tm_clones+0x38>
    10c4:	48 8b 05 0d 2f 00 00 	mov    0x2f0d(%rip),%rax        # 3fd8 <_ITM_registerTMCloneTable@Base>
    10cb:	48 85 c0             	test   %rax,%rax
    10ce:	74 08                	je     10d8 <register_tm_clones+0x38>
    10d0:	ff e0                	jmp    *%rax
    10d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10d8:	c3                   	ret
    10d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	80 3d 35 2f 00 00 00 	cmpb   $0x0,0x2f35(%rip)        # 4020 <completed.0>
    10eb:	75 2b                	jne    1118 <__do_global_dtors_aux+0x38>
    10ed:	55                   	push   %rbp
    10ee:	48 83 3d ea 2e 00 00 	cmpq   $0x0,0x2eea(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10f5:	00 
    10f6:	48 89 e5             	mov    %rsp,%rbp
    10f9:	74 0c                	je     1107 <__do_global_dtors_aux+0x27>
    10fb:	48 8b 3d 16 2f 00 00 	mov    0x2f16(%rip),%rdi        # 4018 <__dso_handle>
    1102:	e8 59 ff ff ff       	call   1060 <__cxa_finalize@plt>
    1107:	e8 64 ff ff ff       	call   1070 <deregister_tm_clones>
    110c:	c6 05 0d 2f 00 00 01 	movb   $0x1,0x2f0d(%rip)        # 4020 <completed.0>
    1113:	5d                   	pop    %rbp
    1114:	c3                   	ret
    1115:	0f 1f 00             	nopl   (%rax)
    1118:	c3                   	ret
    1119:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001120 <frame_dummy>:
    1120:	f3 0f 1e fa          	endbr64
    1124:	e9 77 ff ff ff       	jmp    10a0 <register_tm_clones>
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <__hia_fn_1>:
    1130:	55                   	push   %rbp
    1131:	41 56                	push   %r14
    1133:	53                   	push   %rbx
    1134:	48 85 ff             	test   %rdi,%rdi
    1137:	74 1f                	je     1158 <__hia_fn_1+0x28>
    1139:	89 f5                	mov    %esi,%ebp
    113b:	48 89 fb             	mov    %rdi,%rbx
    113e:	e8 0d ff ff ff       	call   1050 <malloc@plt>
    1143:	48 85 c0             	test   %rax,%rax
    1146:	74 1a                	je     1162 <__hia_fn_1+0x32>
    1148:	48 89 c7             	mov    %rax,%rdi
    114b:	48 83 fb 03          	cmp    $0x3,%rbx
    114f:	77 1c                	ja     116d <__hia_fn_1+0x3d>
    1151:	31 c9                	xor    %ecx,%ecx
    1153:	e9 47 01 00 00       	jmp    129f <__hia_fn_1+0x16f>
    1158:	31 ff                	xor    %edi,%edi
    115a:	45 31 f6             	xor    %r14d,%r14d
    115d:	e9 4a 02 00 00       	jmp    13ac <__hia_fn_1+0x27c>
    1162:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1168:	e9 49 02 00 00       	jmp    13b6 <__hia_fn_1+0x286>
    116d:	48 ba f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rdx
    1174:	ff ff 01 
    1177:	40 0f b6 c5          	movzbl %bpl,%eax
    117b:	48 83 fb 10          	cmp    $0x10,%rbx
    117f:	73 07                	jae    1188 <__hia_fn_1+0x58>
    1181:	31 c9                	xor    %ecx,%ecx
    1183:	e9 94 00 00 00       	jmp    121c <__hia_fn_1+0xec>
    1188:	48 89 d9             	mov    %rbx,%rcx
    118b:	48 21 d1             	and    %rdx,%rcx
    118e:	66 0f 6e c0          	movd   %eax,%xmm0
    1192:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1196:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    119b:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    11a0:	66 0f 6f 0d 58 0e 00 	movdqa 0xe58(%rip),%xmm1        # 2000 <_fini+0xa70>
    11a7:	00 
    11a8:	31 f6                	xor    %esi,%esi
    11aa:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    11ae:	66 0f 68 d2          	punpckhbw %xmm2,%xmm2
    11b2:	66 0f 6f 1d 56 0e 00 	movdqa 0xe56(%rip),%xmm3        # 2010 <_fini+0xa80>
    11b9:	00 
    11ba:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    11be:	66 0f 6f 25 5a 0e 00 	movdqa 0xe5a(%rip),%xmm4        # 2020 <_fini+0xa90>
    11c5:	00 
    11c6:	66 0f 6f 2d 62 0e 00 	movdqa 0xe62(%rip),%xmm5        # 2030 <_fini+0xaa0>
    11cd:	00 
    11ce:	66 90                	xchg   %ax,%ax
    11d0:	66 0f 6f f1          	movdqa %xmm1,%xmm6
    11d4:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
    11d8:	66 0f d5 f2          	pmullw %xmm2,%xmm6
    11dc:	66 0f db f3          	pand   %xmm3,%xmm6
    11e0:	66 0f 6f f9          	movdqa %xmm1,%xmm7
    11e4:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    11e8:	66 0f d5 f8          	pmullw %xmm0,%xmm7
    11ec:	66 0f db fb          	pand   %xmm3,%xmm7
    11f0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
    11f4:	66 0f fc fc          	paddb  %xmm4,%xmm7
    11f8:	f3 0f 7f 3c 37       	movdqu %xmm7,(%rdi,%rsi,1)
    11fd:	48 83 c6 10          	add    $0x10,%rsi
    1201:	66 0f fc cd          	paddb  %xmm5,%xmm1
    1205:	48 39 f1             	cmp    %rsi,%rcx
    1208:	75 c6                	jne    11d0 <__hia_fn_1+0xa0>
    120a:	48 39 cb             	cmp    %rcx,%rbx
    120d:	0f 84 ab 00 00 00    	je     12be <__hia_fn_1+0x18e>
    1213:	f6 c3 0c             	test   $0xc,%bl
    1216:	0f 84 83 00 00 00    	je     129f <__hia_fn_1+0x16f>
    121c:	48 89 ce             	mov    %rcx,%rsi
    121f:	48 83 c2 0c          	add    $0xc,%rdx
    1223:	48 89 d1             	mov    %rdx,%rcx
    1226:	66 0f 6e c6          	movd   %esi,%xmm0
    122a:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    122e:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1233:	66 0f eb 05 05 0e 00 	por    0xe05(%rip),%xmm0        # 2040 <_fini+0xab0>
    123a:	00 
    123b:	48 21 d9             	and    %rbx,%rcx
    123e:	66 0f 6e c8          	movd   %eax,%xmm1
    1242:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1246:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    124b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    124f:	66 0f 6f 15 b9 0d 00 	movdqa 0xdb9(%rip),%xmm2        # 2010 <_fini+0xa80>
    1256:	00 
    1257:	66 0f 6f 1d f1 0d 00 	movdqa 0xdf1(%rip),%xmm3        # 2050 <_fini+0xac0>
    125e:	00 
    125f:	66 0f 6f 25 f9 0d 00 	movdqa 0xdf9(%rip),%xmm4        # 2060 <_fini+0xad0>
    1266:	00 
    1267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    126e:	00 00 
    1270:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    1274:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    1278:	66 0f d5 e9          	pmullw %xmm1,%xmm5
    127c:	66 0f db ea          	pand   %xmm2,%xmm5
    1280:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    1284:	66 0f fc eb          	paddb  %xmm3,%xmm5
    1288:	66 0f 7e 2c 37       	movd   %xmm5,(%rdi,%rsi,1)
    128d:	48 83 c6 04          	add    $0x4,%rsi
    1291:	66 0f fc c4          	paddb  %xmm4,%xmm0
    1295:	48 39 f1             	cmp    %rsi,%rcx
    1298:	75 d6                	jne    1270 <__hia_fn_1+0x140>
    129a:	48 39 cb             	cmp    %rcx,%rbx
    129d:	74 1f                	je     12be <__hia_fn_1+0x18e>
    129f:	89 c8                	mov    %ecx,%eax
    12a1:	40 f6 e5             	mul    %bpl
    12a4:	04 11                	add    $0x11,%al
    12a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    12ad:	00 00 00 
    12b0:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    12b3:	48 ff c1             	inc    %rcx
    12b6:	40 00 e8             	add    %bpl,%al
    12b9:	48 39 cb             	cmp    %rcx,%rbx
    12bc:	75 f2                	jne    12b0 <__hia_fn_1+0x180>
    12be:	48 83 fb 10          	cmp    $0x10,%rbx
    12c2:	0f 82 d3 00 00 00    	jb     139b <__hia_fn_1+0x26b>
    12c8:	48 8d 4b f0          	lea    -0x10(%rbx),%rcx
    12cc:	45 31 f6             	xor    %r14d,%r14d
    12cf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    12d3:	31 c0                	xor    %eax,%eax
    12d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    12dc:	00 00 00 00 
    12e0:	f3 0f 6f 0c 07       	movdqu (%rdi,%rax,1),%xmm1
    12e5:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    12e9:	66 48 0f 7e ca       	movq   %xmm1,%rdx
    12ee:	4c 01 f2             	add    %r14,%rdx
    12f1:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
    12f6:	66 49 0f 7e ce       	movq   %xmm1,%r14
    12fb:	49 01 d6             	add    %rdx,%r14
    12fe:	48 83 c0 10          	add    $0x10,%rax
    1302:	48 39 d8             	cmp    %rbx,%rax
    1305:	77 13                	ja     131a <__hia_fn_1+0x1ea>
    1307:	48 83 f9 10          	cmp    $0x10,%rcx
    130b:	72 0d                	jb     131a <__hia_fn_1+0x1ea>
    130d:	48 8d 51 f0          	lea    -0x10(%rcx),%rdx
    1311:	48 83 f9 0f          	cmp    $0xf,%rcx
    1315:	48 89 d1             	mov    %rdx,%rcx
    1318:	77 c6                	ja     12e0 <__hia_fn_1+0x1b0>
    131a:	48 89 c1             	mov    %rax,%rcx
    131d:	48 29 d9             	sub    %rbx,%rcx
    1320:	0f 83 86 00 00 00    	jae    13ac <__hia_fn_1+0x27c>
    1326:	89 da                	mov    %ebx,%edx
    1328:	29 c2                	sub    %eax,%edx
    132a:	83 e2 07             	and    $0x7,%edx
    132d:	74 10                	je     133f <__hia_fn_1+0x20f>
    132f:	90                   	nop
    1330:	0f b6 34 07          	movzbl (%rdi,%rax,1),%esi
    1334:	49 01 f6             	add    %rsi,%r14
    1337:	48 ff c0             	inc    %rax
    133a:	48 ff ca             	dec    %rdx
    133d:	75 f1                	jne    1330 <__hia_fn_1+0x200>
    133f:	48 83 f9 f8          	cmp    $0xfffffffffffffff8,%rcx
    1343:	77 6c                	ja     13b1 <__hia_fn_1+0x281>
    1345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    134c:	00 00 00 00 
    1350:	0f b6 0c 07          	movzbl (%rdi,%rax,1),%ecx
    1354:	4c 01 f1             	add    %r14,%rcx
    1357:	0f b6 54 07 01       	movzbl 0x1(%rdi,%rax,1),%edx
    135c:	0f b6 74 07 02       	movzbl 0x2(%rdi,%rax,1),%esi
    1361:	48 01 d6             	add    %rdx,%rsi
    1364:	48 01 ce             	add    %rcx,%rsi
    1367:	0f b6 4c 07 03       	movzbl 0x3(%rdi,%rax,1),%ecx
    136c:	0f b6 54 07 04       	movzbl 0x4(%rdi,%rax,1),%edx
    1371:	48 01 ca             	add    %rcx,%rdx
    1374:	0f b6 4c 07 05       	movzbl 0x5(%rdi,%rax,1),%ecx
    1379:	48 01 d1             	add    %rdx,%rcx
    137c:	48 01 f1             	add    %rsi,%rcx
    137f:	0f b6 54 07 06       	movzbl 0x6(%rdi,%rax,1),%edx
    1384:	44 0f b6 74 07 07    	movzbl 0x7(%rdi,%rax,1),%r14d
    138a:	49 01 d6             	add    %rdx,%r14
    138d:	49 01 ce             	add    %rcx,%r14
    1390:	48 83 c0 08          	add    $0x8,%rax
    1394:	48 39 c3             	cmp    %rax,%rbx
    1397:	75 b7                	jne    1350 <__hia_fn_1+0x220>
    1399:	eb 16                	jmp    13b1 <__hia_fn_1+0x281>
    139b:	31 c0                	xor    %eax,%eax
    139d:	45 31 f6             	xor    %r14d,%r14d
    13a0:	48 89 c1             	mov    %rax,%rcx
    13a3:	48 29 d9             	sub    %rbx,%rcx
    13a6:	0f 82 7a ff ff ff    	jb     1326 <__hia_fn_1+0x1f6>
    13ac:	48 85 ff             	test   %rdi,%rdi
    13af:	74 05                	je     13b6 <__hia_fn_1+0x286>
    13b1:	e8 7a fc ff ff       	call   1030 <free@plt>
    13b6:	4c 89 f0             	mov    %r14,%rax
    13b9:	5b                   	pop    %rbx
    13ba:	41 5e                	pop    %r14
    13bc:	5d                   	pop    %rbp
    13bd:	c3                   	ret
    13be:	66 90                	xchg   %ax,%ax

00000000000013c0 <__hia_fn_2>:
    13c0:	55                   	push   %rbp
    13c1:	41 56                	push   %r14
    13c3:	53                   	push   %rbx
    13c4:	89 f5                	mov    %esi,%ebp
    13c6:	48 89 fb             	mov    %rdi,%rbx
    13c9:	48 85 ff             	test   %rdi,%rdi
    13cc:	78 2a                	js     13f8 <__hia_fn_2+0x38>
    13ce:	48 89 df             	mov    %rbx,%rdi
    13d1:	e8 7a fc ff ff       	call   1050 <malloc@plt>
    13d6:	48 85 c0             	test   %rax,%rax
    13d9:	74 1d                	je     13f8 <__hia_fn_2+0x38>
    13db:	48 89 c7             	mov    %rax,%rdi
    13de:	b0 01                	mov    $0x1,%al
    13e0:	a8 01                	test   $0x1,%al
    13e2:	75 1c                	jne    1400 <__hia_fn_2+0x40>
    13e4:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    13ea:	48 85 ff             	test   %rdi,%rdi
    13ed:	0f 85 62 01 00 00    	jne    1555 <__hia_fn_2+0x195>
    13f3:	e9 62 01 00 00       	jmp    155a <__hia_fn_2+0x19a>
    13f8:	31 ff                	xor    %edi,%edi
    13fa:	31 c0                	xor    %eax,%eax
    13fc:	a8 01                	test   $0x1,%al
    13fe:	74 e4                	je     13e4 <__hia_fn_2+0x24>
    1400:	48 89 d8             	mov    %rbx,%rax
    1403:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    1407:	66 0f 6e c5          	movd   %ebp,%xmm0
    140b:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    140f:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1414:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    1419:	66 0f 6f 15 df 0b 00 	movdqa 0xbdf(%rip),%xmm2        # 2000 <_fini+0xa70>
    1420:	00 
    1421:	31 c9                	xor    %ecx,%ecx
    1423:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1427:	66 0f 68 db          	punpckhbw %xmm3,%xmm3
    142b:	66 0f 6f 05 dd 0b 00 	movdqa 0xbdd(%rip),%xmm0        # 2010 <_fini+0xa80>
    1432:	00 
    1433:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1437:	66 0f 6f 25 e1 0b 00 	movdqa 0xbe1(%rip),%xmm4        # 2020 <_fini+0xa90>
    143e:	00 
    143f:	66 0f 6f 2d e9 0b 00 	movdqa 0xbe9(%rip),%xmm5        # 2030 <_fini+0xaa0>
    1446:	00 
    1447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    144e:	00 00 
    1450:	66 0f 6f f2          	movdqa %xmm2,%xmm6
    1454:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
    1458:	66 0f d5 f3          	pmullw %xmm3,%xmm6
    145c:	66 0f db f0          	pand   %xmm0,%xmm6
    1460:	66 0f 6f fa          	movdqa %xmm2,%xmm7
    1464:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    1468:	66 0f d5 f9          	pmullw %xmm1,%xmm7
    146c:	66 0f db f8          	pand   %xmm0,%xmm7
    1470:	66 0f 67 fe          	packuswb %xmm6,%xmm7
    1474:	66 0f fc fc          	paddb  %xmm4,%xmm7
    1478:	f3 0f 7f 3c 0f       	movdqu %xmm7,(%rdi,%rcx,1)
    147d:	48 83 c1 10          	add    $0x10,%rcx
    1481:	66 0f fc d5          	paddb  %xmm5,%xmm2
    1485:	48 39 c8             	cmp    %rcx,%rax
    1488:	75 c6                	jne    1450 <__hia_fn_2+0x90>
    148a:	48 39 c3             	cmp    %rax,%rbx
    148d:	0f 84 9b 00 00 00    	je     152e <__hia_fn_2+0x16e>
    1493:	f6 c3 0c             	test   $0xc,%bl
    1496:	74 79                	je     1511 <__hia_fn_2+0x151>
    1498:	48 89 d9             	mov    %rbx,%rcx
    149b:	66 0f 6e c8          	movd   %eax,%xmm1
    149f:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    14a3:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    14a8:	66 0f eb 0d 90 0b 00 	por    0xb90(%rip),%xmm1        # 2040 <_fini+0xab0>
    14af:	00 
    14b0:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    14b4:	40 0f b6 d5          	movzbl %bpl,%edx
    14b8:	66 0f 6e d2          	movd   %edx,%xmm2
    14bc:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
    14c0:	f2 0f 70 d2 00       	pshuflw $0x0,%xmm2,%xmm2
    14c5:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
    14c9:	66 0f 6f 1d 7f 0b 00 	movdqa 0xb7f(%rip),%xmm3        # 2050 <_fini+0xac0>
    14d0:	00 
    14d1:	66 0f 6f 25 87 0b 00 	movdqa 0xb87(%rip),%xmm4        # 2060 <_fini+0xad0>
    14d8:	00 
    14d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    14e0:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    14e4:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    14e8:	66 0f d5 ea          	pmullw %xmm2,%xmm5
    14ec:	66 0f db e8          	pand   %xmm0,%xmm5
    14f0:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    14f4:	66 0f fc eb          	paddb  %xmm3,%xmm5
    14f8:	66 0f 7e 2c 07       	movd   %xmm5,(%rdi,%rax,1)
    14fd:	48 83 c0 04          	add    $0x4,%rax
    1501:	66 0f fc cc          	paddb  %xmm4,%xmm1
    1505:	48 39 c1             	cmp    %rax,%rcx
    1508:	75 d6                	jne    14e0 <__hia_fn_2+0x120>
    150a:	48 39 cb             	cmp    %rcx,%rbx
    150d:	75 05                	jne    1514 <__hia_fn_2+0x154>
    150f:	eb 1d                	jmp    152e <__hia_fn_2+0x16e>
    1511:	48 89 c1             	mov    %rax,%rcx
    1514:	89 c8                	mov    %ecx,%eax
    1516:	40 f6 e5             	mul    %bpl
    1519:	04 11                	add    $0x11,%al
    151b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1520:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    1523:	48 ff c1             	inc    %rcx
    1526:	40 00 e8             	add    %bpl,%al
    1529:	48 39 cb             	cmp    %rcx,%rbx
    152c:	75 f2                	jne    1520 <__hia_fn_2+0x160>
    152e:	31 c0                	xor    %eax,%eax
    1530:	45 31 f6             	xor    %r14d,%r14d
    1533:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    153a:	84 00 00 00 00 00 
    1540:	4c 89 f1             	mov    %r14,%rcx
    1543:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1548:	49 01 ce             	add    %rcx,%r14
    154b:	72 15                	jb     1562 <__hia_fn_2+0x1a2>
    154d:	48 ff c0             	inc    %rax
    1550:	48 39 c3             	cmp    %rax,%rbx
    1553:	75 eb                	jne    1540 <__hia_fn_2+0x180>
    1555:	e8 d6 fa ff ff       	call   1030 <free@plt>
    155a:	4c 89 f0             	mov    %r14,%rax
    155d:	5b                   	pop    %rbx
    155e:	41 5e                	pop    %r14
    1560:	5d                   	pop    %rbp
    1561:	c3                   	ret
    1562:	e8 d9 fa ff ff       	call   1040 <abort@plt>
    1567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    156e:	00 00 

0000000000001570 <calculate>:
    1570:	48 85 ff             	test   %rdi,%rdi
    1573:	75 03                	jne    1578 <calculate+0x8>
    1575:	31 c0                	xor    %eax,%eax
    1577:	c3                   	ret
    1578:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
    157f:	01 01 01 
    1582:	48 39 c7             	cmp    %rax,%rdi
    1585:	0f 86 a5 fb ff ff    	jbe    1130 <__hia_fn_1>
    158b:	e9 30 fe ff ff       	jmp    13c0 <__hia_fn_2>

Disassembly of section .fini:

0000000000001590 <_fini>:
    1590:	f3 0f 1e fa          	endbr64
    1594:	48 83 ec 08          	sub    $0x8,%rsp
    1598:	48 83 c4 08          	add    $0x8,%rsp
    159c:	c3                   	ret
