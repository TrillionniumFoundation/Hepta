
/data/hepta-hia-round5-a3b4-20261105/aot-half-tail-diagnostic/baseline/linear.so：     文件格式 elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 2f 00 00 	mov    0x2fc1(%rip),%rax        # 3fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <free@plt-0x10>:
    1020:	ff 35 ca 2f 00 00    	push   0x2fca(%rip)        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 2f 00 00    	jmp    *0x2fcc(%rip)        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <free@plt>:
    1030:	ff 25 ca 2f 00 00    	jmp    *0x2fca(%rip)        # 4000 <free@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

0000000000001040 <abort@plt>:
    1040:	ff 25 c2 2f 00 00    	jmp    *0x2fc2(%rip)        # 4008 <abort@GLIBC_2.2.5>
    1046:	68 01 00 00 00       	push   $0x1
    104b:	e9 d0 ff ff ff       	jmp    1020 <_init+0x20>

0000000000001050 <malloc@plt>:
    1050:	ff 25 ba 2f 00 00    	jmp    *0x2fba(%rip)        # 4010 <malloc@GLIBC_2.2.5>
    1056:	68 02 00 00 00       	push   $0x2
    105b:	e9 c0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001060 <__cxa_finalize@plt>:
    1060:	ff 25 7a 2f 00 00    	jmp    *0x2f7a(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1066:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001070 <deregister_tm_clones>:
    1070:	48 8d 3d a9 2f 00 00 	lea    0x2fa9(%rip),%rdi        # 4020 <completed.0>
    1077:	48 8d 05 a2 2f 00 00 	lea    0x2fa2(%rip),%rax        # 4020 <completed.0>
    107e:	48 39 f8             	cmp    %rdi,%rax
    1081:	74 15                	je     1098 <deregister_tm_clones+0x28>
    1083:	48 8b 05 3e 2f 00 00 	mov    0x2f3e(%rip),%rax        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    108a:	48 85 c0             	test   %rax,%rax
    108d:	74 09                	je     1098 <deregister_tm_clones+0x28>
    108f:	ff e0                	jmp    *%rax
    1091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1098:	c3                   	ret
    1099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:	48 8d 3d 79 2f 00 00 	lea    0x2f79(%rip),%rdi        # 4020 <completed.0>
    10a7:	48 8d 35 72 2f 00 00 	lea    0x2f72(%rip),%rsi        # 4020 <completed.0>
    10ae:	48 29 fe             	sub    %rdi,%rsi
    10b1:	48 89 f0             	mov    %rsi,%rax
    10b4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10b8:	48 c1 f8 03          	sar    $0x3,%rax
    10bc:	48 01 c6             	add    %rax,%rsi
    10bf:	48 d1 fe             	sar    $1,%rsi
    10c2:	74 14                	je     10d8 <register_tm_clones+0x38>
    10c4:	48 8b 05 0d 2f 00 00 	mov    0x2f0d(%rip),%rax        # 3fd8 <_ITM_registerTMCloneTable@Base>
    10cb:	48 85 c0             	test   %rax,%rax
    10ce:	74 08                	je     10d8 <register_tm_clones+0x38>
    10d0:	ff e0                	jmp    *%rax
    10d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10d8:	c3                   	ret
    10d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	80 3d 35 2f 00 00 00 	cmpb   $0x0,0x2f35(%rip)        # 4020 <completed.0>
    10eb:	75 2b                	jne    1118 <__do_global_dtors_aux+0x38>
    10ed:	55                   	push   %rbp
    10ee:	48 83 3d ea 2e 00 00 	cmpq   $0x0,0x2eea(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10f5:	00 
    10f6:	48 89 e5             	mov    %rsp,%rbp
    10f9:	74 0c                	je     1107 <__do_global_dtors_aux+0x27>
    10fb:	48 8b 3d 16 2f 00 00 	mov    0x2f16(%rip),%rdi        # 4018 <__dso_handle>
    1102:	e8 59 ff ff ff       	call   1060 <__cxa_finalize@plt>
    1107:	e8 64 ff ff ff       	call   1070 <deregister_tm_clones>
    110c:	c6 05 0d 2f 00 00 01 	movb   $0x1,0x2f0d(%rip)        # 4020 <completed.0>
    1113:	5d                   	pop    %rbp
    1114:	c3                   	ret
    1115:	0f 1f 00             	nopl   (%rax)
    1118:	c3                   	ret
    1119:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001120 <frame_dummy>:
    1120:	f3 0f 1e fa          	endbr64
    1124:	e9 77 ff ff ff       	jmp    10a0 <register_tm_clones>
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <__hia_fn_1>:
    1130:	55                   	push   %rbp
    1131:	41 56                	push   %r14
    1133:	53                   	push   %rbx
    1134:	48 85 ff             	test   %rdi,%rdi
    1137:	74 1c                	je     1155 <__hia_fn_1+0x25>
    1139:	89 f5                	mov    %esi,%ebp
    113b:	48 89 fb             	mov    %rdi,%rbx
    113e:	e8 0d ff ff ff       	call   1050 <malloc@plt>
    1143:	48 85 c0             	test   %rax,%rax
    1146:	74 17                	je     115f <__hia_fn_1+0x2f>
    1148:	48 83 fb 03          	cmp    $0x3,%rbx
    114c:	77 1c                	ja     116a <__hia_fn_1+0x3a>
    114e:	31 c9                	xor    %ecx,%ecx
    1150:	e9 da 00 00 00       	jmp    122f <__hia_fn_1+0xff>
    1155:	31 c0                	xor    %eax,%eax
    1157:	45 31 f6             	xor    %r14d,%r14d
    115a:	e9 dd 01 00 00       	jmp    133c <__hia_fn_1+0x20c>
    115f:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1165:	e9 df 01 00 00       	jmp    1349 <__hia_fn_1+0x219>
    116a:	48 be f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rsi
    1171:	ff ff 01 
    1174:	40 0f b6 d5          	movzbl %bpl,%edx
    1178:	48 83 fb 10          	cmp    $0x10,%rbx
    117c:	73 04                	jae    1182 <__hia_fn_1+0x52>
    117e:	31 c9                	xor    %ecx,%ecx
    1180:	eb 56                	jmp    11d8 <__hia_fn_1+0xa8>
    1182:	48 89 d9             	mov    %rbx,%rcx
    1185:	48 21 f1             	and    %rsi,%rcx
    1188:	66 0f 6e c2          	movd   %edx,%xmm0
    118c:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1190:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1195:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    119a:	66 0f 6f 0d 5e 0e 00 	movdqa 0xe5e(%rip),%xmm1        # 2000 <_fini+0xb30>
    11a1:	00 
    11a2:	31 ff                	xor    %edi,%edi
    11a4:	66 0f 6f 15 64 0e 00 	movdqa 0xe64(%rip),%xmm2        # 2010 <_fini+0xb40>
    11ab:	00 
    11ac:	0f 1f 40 00          	nopl   0x0(%rax)
    11b0:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    11b4:	66 0f fc d8          	paddb  %xmm0,%xmm3
    11b8:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
    11bd:	48 83 c7 10          	add    $0x10,%rdi
    11c1:	66 0f fc ca          	paddb  %xmm2,%xmm1
    11c5:	48 39 f9             	cmp    %rdi,%rcx
    11c8:	75 e6                	jne    11b0 <__hia_fn_1+0x80>
    11ca:	48 39 cb             	cmp    %rcx,%rbx
    11cd:	0f 84 7c 00 00 00    	je     124f <__hia_fn_1+0x11f>
    11d3:	f6 c3 0c             	test   $0xc,%bl
    11d6:	74 57                	je     122f <__hia_fn_1+0xff>
    11d8:	48 89 cf             	mov    %rcx,%rdi
    11db:	48 83 c6 0c          	add    $0xc,%rsi
    11df:	48 89 f1             	mov    %rsi,%rcx
    11e2:	48 21 d9             	and    %rbx,%rcx
    11e5:	66 0f 6e c7          	movd   %edi,%xmm0
    11e9:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    11ed:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    11f2:	66 0f eb 05 26 0e 00 	por    0xe26(%rip),%xmm0        # 2020 <_fini+0xb50>
    11f9:	00 
    11fa:	66 0f 6e ca          	movd   %edx,%xmm1
    11fe:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1202:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    1207:	66 0f 6f 15 21 0e 00 	movdqa 0xe21(%rip),%xmm2        # 2030 <_fini+0xb60>
    120e:	00 
    120f:	90                   	nop
    1210:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    1214:	66 0f fc d9          	paddb  %xmm1,%xmm3
    1218:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
    121d:	48 83 c7 04          	add    $0x4,%rdi
    1221:	66 0f fc c2          	paddb  %xmm2,%xmm0
    1225:	48 39 f9             	cmp    %rdi,%rcx
    1228:	75 e6                	jne    1210 <__hia_fn_1+0xe0>
    122a:	48 39 cb             	cmp    %rcx,%rbx
    122d:	74 20                	je     124f <__hia_fn_1+0x11f>
    122f:	89 ea                	mov    %ebp,%edx
    1231:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1238:	0f 1f 84 00 00 00 00 
    123f:	00 
    1240:	8d 34 0a             	lea    (%rdx,%rcx,1),%esi
    1243:	40 88 34 08          	mov    %sil,(%rax,%rcx,1)
    1247:	48 ff c1             	inc    %rcx
    124a:	48 39 cb             	cmp    %rcx,%rbx
    124d:	75 f1                	jne    1240 <__hia_fn_1+0x110>
    124f:	48 83 fb 10          	cmp    $0x10,%rbx
    1253:	0f 82 d2 00 00 00    	jb     132b <__hia_fn_1+0x1fb>
    1259:	48 8d 53 f0          	lea    -0x10(%rbx),%rdx
    125d:	45 31 f6             	xor    %r14d,%r14d
    1260:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1264:	31 c9                	xor    %ecx,%ecx
    1266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    126d:	00 00 00 
    1270:	f3 0f 6f 0c 08       	movdqu (%rax,%rcx,1),%xmm1
    1275:	66 0f f6 c8          	psadbw %xmm0,%xmm1
    1279:	66 48 0f 7e ce       	movq   %xmm1,%rsi
    127e:	4c 01 f6             	add    %r14,%rsi
    1281:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
    1286:	66 49 0f 7e ce       	movq   %xmm1,%r14
    128b:	49 01 f6             	add    %rsi,%r14
    128e:	48 83 c1 10          	add    $0x10,%rcx
    1292:	48 39 d9             	cmp    %rbx,%rcx
    1295:	77 13                	ja     12aa <__hia_fn_1+0x17a>
    1297:	48 83 fa 10          	cmp    $0x10,%rdx
    129b:	72 0d                	jb     12aa <__hia_fn_1+0x17a>
    129d:	48 8d 72 f0          	lea    -0x10(%rdx),%rsi
    12a1:	48 83 fa 0f          	cmp    $0xf,%rdx
    12a5:	48 89 f2             	mov    %rsi,%rdx
    12a8:	77 c6                	ja     1270 <__hia_fn_1+0x140>
    12aa:	48 89 ca             	mov    %rcx,%rdx
    12ad:	48 29 da             	sub    %rbx,%rdx
    12b0:	0f 83 86 00 00 00    	jae    133c <__hia_fn_1+0x20c>
    12b6:	89 de                	mov    %ebx,%esi
    12b8:	29 ce                	sub    %ecx,%esi
    12ba:	83 e6 07             	and    $0x7,%esi
    12bd:	74 10                	je     12cf <__hia_fn_1+0x19f>
    12bf:	90                   	nop
    12c0:	0f b6 3c 08          	movzbl (%rax,%rcx,1),%edi
    12c4:	49 01 fe             	add    %rdi,%r14
    12c7:	48 ff c1             	inc    %rcx
    12ca:	48 ff ce             	dec    %rsi
    12cd:	75 f1                	jne    12c0 <__hia_fn_1+0x190>
    12cf:	48 83 fa f8          	cmp    $0xfffffffffffffff8,%rdx
    12d3:	77 6c                	ja     1341 <__hia_fn_1+0x211>
    12d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    12dc:	00 00 00 00 
    12e0:	0f b6 14 08          	movzbl (%rax,%rcx,1),%edx
    12e4:	4c 01 f2             	add    %r14,%rdx
    12e7:	0f b6 74 08 01       	movzbl 0x1(%rax,%rcx,1),%esi
    12ec:	0f b6 7c 08 02       	movzbl 0x2(%rax,%rcx,1),%edi
    12f1:	48 01 f7             	add    %rsi,%rdi
    12f4:	48 01 d7             	add    %rdx,%rdi
    12f7:	0f b6 54 08 03       	movzbl 0x3(%rax,%rcx,1),%edx
    12fc:	0f b6 74 08 04       	movzbl 0x4(%rax,%rcx,1),%esi
    1301:	48 01 d6             	add    %rdx,%rsi
    1304:	0f b6 54 08 05       	movzbl 0x5(%rax,%rcx,1),%edx
    1309:	48 01 f2             	add    %rsi,%rdx
    130c:	48 01 fa             	add    %rdi,%rdx
    130f:	0f b6 74 08 06       	movzbl 0x6(%rax,%rcx,1),%esi
    1314:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
    131a:	49 01 f6             	add    %rsi,%r14
    131d:	49 01 d6             	add    %rdx,%r14
    1320:	48 83 c1 08          	add    $0x8,%rcx
    1324:	48 39 cb             	cmp    %rcx,%rbx
    1327:	75 b7                	jne    12e0 <__hia_fn_1+0x1b0>
    1329:	eb 16                	jmp    1341 <__hia_fn_1+0x211>
    132b:	31 c9                	xor    %ecx,%ecx
    132d:	45 31 f6             	xor    %r14d,%r14d
    1330:	48 89 ca             	mov    %rcx,%rdx
    1333:	48 29 da             	sub    %rbx,%rdx
    1336:	0f 82 7a ff ff ff    	jb     12b6 <__hia_fn_1+0x186>
    133c:	48 85 c0             	test   %rax,%rax
    133f:	74 08                	je     1349 <__hia_fn_1+0x219>
    1341:	48 89 c7             	mov    %rax,%rdi
    1344:	e8 e7 fc ff ff       	call   1030 <free@plt>
    1349:	4c 89 f0             	mov    %r14,%rax
    134c:	5b                   	pop    %rbx
    134d:	41 5e                	pop    %r14
    134f:	5d                   	pop    %rbp
    1350:	c3                   	ret
    1351:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1358:	0f 1f 84 00 00 00 00 
    135f:	00 

0000000000001360 <__hia_fn_2>:
    1360:	55                   	push   %rbp
    1361:	41 56                	push   %r14
    1363:	53                   	push   %rbx
    1364:	89 f5                	mov    %esi,%ebp
    1366:	48 89 fb             	mov    %rdi,%rbx
    1369:	48 85 ff             	test   %rdi,%rdi
    136c:	78 2a                	js     1398 <__hia_fn_2+0x38>
    136e:	48 89 df             	mov    %rbx,%rdi
    1371:	e8 da fc ff ff       	call   1050 <malloc@plt>
    1376:	48 85 c0             	test   %rax,%rax
    1379:	74 1d                	je     1398 <__hia_fn_2+0x38>
    137b:	48 89 c7             	mov    %rax,%rdi
    137e:	b0 01                	mov    $0x1,%al
    1380:	a8 01                	test   $0x1,%al
    1382:	75 1c                	jne    13a0 <__hia_fn_2+0x40>
    1384:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    138a:	48 85 ff             	test   %rdi,%rdi
    138d:	0f 85 02 01 00 00    	jne    1495 <__hia_fn_2+0x135>
    1393:	e9 02 01 00 00       	jmp    149a <__hia_fn_2+0x13a>
    1398:	31 ff                	xor    %edi,%edi
    139a:	31 c0                	xor    %eax,%eax
    139c:	a8 01                	test   $0x1,%al
    139e:	74 e4                	je     1384 <__hia_fn_2+0x24>
    13a0:	48 89 d8             	mov    %rbx,%rax
    13a3:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    13a7:	66 0f 6e c5          	movd   %ebp,%xmm0
    13ab:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    13af:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    13b4:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    13b9:	66 0f 6f 0d 3f 0c 00 	movdqa 0xc3f(%rip),%xmm1        # 2000 <_fini+0xb30>
    13c0:	00 
    13c1:	31 c9                	xor    %ecx,%ecx
    13c3:	66 0f 6f 15 45 0c 00 	movdqa 0xc45(%rip),%xmm2        # 2010 <_fini+0xb40>
    13ca:	00 
    13cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    13d0:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    13d4:	66 0f fc d8          	paddb  %xmm0,%xmm3
    13d8:	f3 0f 7f 1c 0f       	movdqu %xmm3,(%rdi,%rcx,1)
    13dd:	48 83 c1 10          	add    $0x10,%rcx
    13e1:	66 0f fc ca          	paddb  %xmm2,%xmm1
    13e5:	48 39 c8             	cmp    %rcx,%rax
    13e8:	75 e6                	jne    13d0 <__hia_fn_2+0x70>
    13ea:	48 39 c3             	cmp    %rax,%rbx
    13ed:	74 7f                	je     146e <__hia_fn_2+0x10e>
    13ef:	f6 c3 0c             	test   $0xc,%bl
    13f2:	74 5d                	je     1451 <__hia_fn_2+0xf1>
    13f4:	48 89 d9             	mov    %rbx,%rcx
    13f7:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    13fb:	66 0f 6e c0          	movd   %eax,%xmm0
    13ff:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1403:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1408:	66 0f eb 05 10 0c 00 	por    0xc10(%rip),%xmm0        # 2020 <_fini+0xb50>
    140f:	00 
    1410:	40 0f b6 d5          	movzbl %bpl,%edx
    1414:	66 0f 6e ca          	movd   %edx,%xmm1
    1418:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    141c:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    1421:	66 0f 6f 15 07 0c 00 	movdqa 0xc07(%rip),%xmm2        # 2030 <_fini+0xb60>
    1428:	00 
    1429:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1430:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    1434:	66 0f fc d9          	paddb  %xmm1,%xmm3
    1438:	66 0f 7e 1c 07       	movd   %xmm3,(%rdi,%rax,1)
    143d:	48 83 c0 04          	add    $0x4,%rax
    1441:	66 0f fc c2          	paddb  %xmm2,%xmm0
    1445:	48 39 c1             	cmp    %rax,%rcx
    1448:	75 e6                	jne    1430 <__hia_fn_2+0xd0>
    144a:	48 39 cb             	cmp    %rcx,%rbx
    144d:	75 05                	jne    1454 <__hia_fn_2+0xf4>
    144f:	eb 1d                	jmp    146e <__hia_fn_2+0x10e>
    1451:	48 89 c1             	mov    %rax,%rcx
    1454:	89 e8                	mov    %ebp,%eax
    1456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    145d:	00 00 00 
    1460:	8d 14 08             	lea    (%rax,%rcx,1),%edx
    1463:	88 14 0f             	mov    %dl,(%rdi,%rcx,1)
    1466:	48 ff c1             	inc    %rcx
    1469:	48 39 cb             	cmp    %rcx,%rbx
    146c:	75 f2                	jne    1460 <__hia_fn_2+0x100>
    146e:	31 c0                	xor    %eax,%eax
    1470:	45 31 f6             	xor    %r14d,%r14d
    1473:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    147a:	84 00 00 00 00 00 
    1480:	4c 89 f1             	mov    %r14,%rcx
    1483:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1488:	49 01 ce             	add    %rcx,%r14
    148b:	72 15                	jb     14a2 <__hia_fn_2+0x142>
    148d:	48 ff c0             	inc    %rax
    1490:	48 39 c3             	cmp    %rax,%rbx
    1493:	75 eb                	jne    1480 <__hia_fn_2+0x120>
    1495:	e8 96 fb ff ff       	call   1030 <free@plt>
    149a:	4c 89 f0             	mov    %r14,%rax
    149d:	5b                   	pop    %rbx
    149e:	41 5e                	pop    %r14
    14a0:	5d                   	pop    %rbp
    14a1:	c3                   	ret
    14a2:	e8 99 fb ff ff       	call   1040 <abort@plt>
    14a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    14ae:	00 00 

00000000000014b0 <calculate>:
    14b0:	48 85 ff             	test   %rdi,%rdi
    14b3:	75 03                	jne    14b8 <calculate+0x8>
    14b5:	31 c0                	xor    %eax,%eax
    14b7:	c3                   	ret
    14b8:	48 b8 01 01 01 01 01 	movabs $0x101010101010101,%rax
    14bf:	01 01 01 
    14c2:	48 39 c7             	cmp    %rax,%rdi
    14c5:	0f 86 65 fc ff ff    	jbe    1130 <__hia_fn_1>
    14cb:	e9 90 fe ff ff       	jmp    1360 <__hia_fn_2>

Disassembly of section .fini:

00000000000014d0 <_fini>:
    14d0:	f3 0f 1e fa          	endbr64
    14d4:	48 83 ec 08          	sub    $0x8,%rsp
    14d8:	48 83 c4 08          	add    $0x8,%rsp
    14dc:	c3                   	ret
