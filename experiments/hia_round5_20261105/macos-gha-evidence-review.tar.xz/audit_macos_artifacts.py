#!/usr/bin/env python3
"""Read-only GitHub artifact, source binding, retained bytes and oracle audit."""
import base64
import datetime
import hashlib
import json
import posixpath as ntpath
import re
import struct
import os
import pathlib
import stat
import sys
import time
import zipfile

ROOT = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/macos-gha-artifacts-r1')
SOURCE = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/work-integration')
HEAD = '67da0ab0a51203f6f640c4459bc15bef442885b8'
MEASURED_HEAD = '0a06ef4f0894681af92b0caefba0704c1278d2cc'
TREE = 'a5239982f9fd8f08ab3a6e791147fc989e8d9df6'
SNAPSHOT = pathlib.Path('/data/hepta-hia-round5-a3b4-20261105/evidence/independent-analysis-0a06ef4f0894-r1/GITHUB_FINAL_SNAPSHOT.json')
SNAPSHOT_SHA = '28fe8b7250e764090cf5369445c784ee65f5c0a65b1067e0743009e70af97885'
JOBS = {13462959486: 127608285065, 13463139429: 127608287303}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def ident(b):
    return {'bytes': len(b), 'sha256': sha(b),
            'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}

def norm(p):
    p = p.replace('\\', '/')
    q = pathlib.PurePosixPath(p)
    assert not q.is_absolute() and '..' not in q.parts and ':' not in p
    return q.as_posix()

def wire(d):
    return (json.dumps(d, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()

def write(p, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(b)

def walk(x):
    if isinstance(x, dict):
        yield x
        for v in x.values():
            yield from walk(v)
    elif isinstance(x, list):
        for v in x:
            yield from walk(v)
    elif isinstance(x, str) and x.startswith(('{', '[')):
        try:
            j = json.loads(x)
        except (ValueError, RecursionError):
            return
        yield from walk(j)

def source_comparison(files):
    matched, differences, absent = [], [], []
    for key, expected in files.items():
        rel = norm(key)
        p = SOURCE / rel
        if not p.is_file():
            absent.append(rel)
            continue
        actual = sha(p.read_bytes())
        if actual == expected:
            matched.append(rel)
        else:
            differences.append({'path': rel, 'macos_sha256': expected, 'linux_sha256': actual})
    return {'matched_file_count': len(matched), 'matched_paths': sorted(matched), 'different_bytes': differences, 'absent_paths': absent,
            'scope': 'Direct recorded source-file byte comparison to the frozen Linux checkout, after path separator normalization only.'}


def macho_header(raw):
    assert len(raw) >= 32 and raw[:4] == bytes.fromhex('cffaedfe')
    magic, cpu, subcpu, kind, ncmds, command_bytes, flags, reserved = struct.unpack('<IiiIIIII', raw[:32])
    assert magic == 0xfeedfacf and cpu == 0x0100000c
    assert kind in (1, 2, 6) and 32 + command_bytes <= len(raw)
    at = 32
    for _ in range(ncmds):
        assert at + 8 <= 32 + command_bytes
        _, size = struct.unpack('<II', raw[at:at + 8])
        assert size >= 8 and size % 4 == 0 and at + size <= 32 + command_bytes
        at += size
    assert at == 32 + command_bytes
    return {'format': 'Mach-O64', 'byte_order': 'little', 'cpu_type': cpu,
            'cpu_subtype': subcpu, 'architecture': 'arm64', 'filetype': kind,
            'load_command_count': ncmds, 'load_command_bytes': command_bytes,
            'load_commands_bounded': True, 'flags': flags, **ident(raw)}

class Archive:
    def __init__(self, metadata):
        self.metadata = metadata
        self.id = metadata['id']
        self.path = ROOT / f"macos-{'cpp' if self.id == 13462959486 else 'native'}-{self.id}.zip"
        self.bytes = self.path.read_bytes()
        assert len(self.bytes) == metadata['size_in_bytes']
        assert 'sha256:' + sha(self.bytes) == metadata['digest']
        assert metadata['workflow_run']['head_sha'] == HEAD
        self.files = {}
        with zipfile.ZipFile(self.path) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = norm(info.filename)
                assert name not in self.files
                mode = info.external_attr >> 16
                assert not stat.S_ISLNK(mode)
                self.files[name] = z.read(info)
        self.macho_headers = {k: macho_header(v) for k, v in self.files.items() if v[:4] == bytes.fromhex('cffaedfe')}
        self.checked = set()
        self.streams = set()
        self.embedded_streams = 0

    def j(self, path):
        return json.loads(self.files[path])

    def check(self, path, row):
        path = norm(path)
        actual = ident(self.files[path])
        assert actual['sha256'] == row['sha256'], path
        if 'bytes' in row:
            assert actual['bytes'] == row['bytes'], path
        self.checked.add(path)

    def mapped(self, absolute, original, prefix):
        rel = ntpath.relpath(absolute, original)
        assert not rel.startswith('..')
        return norm(prefix + '/' + rel)

    def process_streams(self, value, original, prefix):
        for d in walk(value):
            for name in ('stdout', 'stderr'):
                pk, hk = name + '_path', name + '_sha256'
                if pk in d and hk in d:
                    path = self.mapped(d[pk], original, prefix)
                    self.check(path, {'sha256': d[hk]})
                    self.streams.add(path)
                    if name + '_bytes_base64' in d:
                        assert self.files[path] == base64.b64decode(d[name + '_bytes_base64'], validate=True)
                for bk, sk, nk in ((name + '_raw_base64', name + '_raw_sha256', name + '_raw_bytes'),
                                   (name + '_bytes_base64', name + '_sha256', None)):
                    if bk in d and sk in d:
                        b = base64.b64decode(d[bk], validate=True)
                        assert sha(b) == d[sk]
                        if nk and nk in d:
                            assert len(b) == d[nk]
                        self.embedded_streams += 1

    def summary(self):
        return {'artifact_id': self.id, 'github_artifact': self.metadata,
                'archive': dict(ident(self.bytes), path=str(self.path)),
                'zip_regular_file_count': len(self.files),
                'zip_files': {k: ident(v) for k, v in sorted(self.files.items())},
                'checked_retained_file_count': len(self.checked),
                'checked_retained_files': sorted(self.checked),
                'macho_arm64_files': self.macho_headers, 'raw_stream_files': sorted(self.streams),
                'separately_checked_raw_stream_file_count': len(self.streams),
                'checked_embedded_stream_records': self.embedded_streams}

def cpp(a):
    c = a.j('cpp-upstream-host.json')
    assert c == a.j('cpp-upstream-host/qualification.json')
    assert c['status'] == 'passed' and c['ok'] and c['inputs_unchanged']
    assert c['source_commit'] == HEAD
    assert c['host']['system'] == 'Darwin' and c['host']['machine'] == 'aarch64'
    assert c['host']['execution'] == 'native_host_process'
    before, after = c['source_checkout_before'], c['source_checkout_after']
    assert before == after and before['commit'] == HEAD and before['tree'] == TREE
    assert before['tracked_status'] == '' and before['casefold_collisions'] == []
    assert c['tracked_source_status'] == c['tracked_source_status_after'] == ''
    retained = c['retained_files']
    for name, row in retained.items():
        a.check('cpp-upstream-host/' + name, row)
    actual = {k[len('cpp-upstream-host/'):] for k in a.files if k.startswith('cpp-upstream-host/')}
    assert actual == {norm(x) for x in retained} | {'qualification.json', 'audit.json'}
    a.process_streams(c, c['directory'], 'cpp-upstream-host')
    versions = []
    for v in c['versions']:
        assert v['status'] == 'passed'
        e = v['execution']
        assert e['exit_code'] == 0 and e['executable_unchanged']
        exe = a.mapped(e['argv'][0], c['directory'], 'cpp-upstream-host')
        a.check(exe, v['executable'])
        assert a.macho_headers[exe]['filetype'] == 2 and v['executable']['format'] == 'Mach-O64'
        assert v['executable']['machine'] == 'aarch64'
        assert e['executable_sha256'] == v['executable']['sha256']
        observed = v['observed']
        raw = a.files[a.mapped(e['stdout_path'], c['directory'], 'cpp-upstream-host')]
        assert json.loads(raw) == observed
        rows = observed['cases']
        assert len(rows) == 98 and len({x['id'] for x in rows}) == 98
        assert all(x['direct_status'] == x['hepta_status'] and x['direct_value'] == x['hepta_value'] and x['live_delta'] == 0 for x in rows)
        assert observed['ordinary_live_delta'] == 0
        assert observed['registry_ordinary_allocations_retained'] == 2
        assert observed['cancellation'] == {'committed': 3, 'replayed': 0, 'requested': 7, 'value': 107}
        assert v['native']['status'] == 'rustc_checked' and v['native']['target'] == 'aarch64-apple-darwin'
        a.check(a.mapped(v['native']['artifact'], c['directory'], 'cpp-upstream-host'),
                {'sha256': v['native']['artifact_sha256'], 'bytes': v['native']['artifact_bytes']})
        a.check('cpp-upstream-host/' + v['version'] + '/bridge/consumer.rs', {'sha256': v['native']['rust_sha256']})
        assert a.macho_headers[a.mapped(v['native']['artifact'], c['directory'], 'cpp-upstream-host')]['filetype'] == 1
        versions.append({'version': v['version'], 'executable': v['executable'],
                         'execution_returncode': e['exit_code'], 'source_and_license': v['source_and_license'],
                         'native_object': {k: v['native'][k] for k in ('artifact_sha256', 'artifact_bytes', 'rust_sha256', 'status', 'target', 'toolchain', 'flags')},
                         'observed': {k: val for k, val in observed.items() if k != 'cases'},
                         'case_count': len(rows), 'direct_hepta_status_value_and_live_delta_checked': True})
    assert [v['version'] for v in versions] == ['3.11.3', '3.12.0']
    wrong = c['wrong_code']
    assert wrong['status'] == 'rejected' and wrong['process']['exit_code'] == 2
    assert 'actual direct/Hepta result mismatch' in wrong['process']['stderr']
    a.check(a.mapped(wrong['process']['argv'][0], c['directory'], 'cpp-upstream-host'), wrong['artifact'])
    sig = c['incompatible_signature']
    assert not sig['ok'] and sig['status'] == 'rejected' and sig['execution'] == 'not_run'
    assert [x['code'] for x in sig['diagnostics']] == ['E_CPP_NATIVE']
    assert sig['failure']['phase'] == 'cpp_compile' and sig['failure']['process']['exit_code'] != 0
    marker = 'HEPTA_CPP_METHOD_RESULT'
    assert marker in sig['failure']['process']['stdout'] + sig['failure']['process']['stderr']
    for name in ('stdout', 'stderr'):
        path = a.mapped(c['incompatible_signature_evidence'][name], c['directory'], 'cpp-upstream-host')
        b = base64.b64decode(sig['failure']['process'][name + '_raw_base64'], validate=True)
        assert a.files[path] == b
        a.check(path, {'sha256': sig['failure']['process'][name + '_raw_sha256']})
        a.streams.add(path)
    original_audit = a.j('cpp-upstream-host/audit.json')
    assert original_audit['status'] == 'passed'
    return {'kind': 'cpp_upstream_host', 'status': 'passed', 'source_checkout': before,
            'source_inputs_comparison': source_comparison(c['source_inputs']),
            'host': c['host'], 'cxx': {k: c['cxx'][k] for k in ('path', 'version', 'identity', 'target', 'executable_sha256')},
            'compiler_sha256': c['compiler_sha256'], 'versions': versions,
            'wrong_code': {'returncode': 2, 'artifact': wrong['artifact'], 'actual_mismatch_marker': True},
            'incompatible_signature': {'rejected': True, 'code': 'E_CPP_NATIVE', 'actual_compiler_diagnostic_marker': marker},
            'original_read_only_audit': original_audit, 'claims': c['claims'],
            'backend_boundary': 'Retained nlohmann C++ upstream library is reused through the generated C ABI bridge. Actual Hepta consumer object is Rust backend; this is not a whole library HIA Core/LLVM rewrite.'}

def integer_oracle(a, b):
    assert b and not (a == -(1 << 31) and b == -1)
    trunc = (abs(a) // abs(b)) * (1 if (a >= 0) == (b >= 0) else -1)
    floor = a // b
    euclidean = (a - (a % abs(b))) // b
    return [trunc, floor, euclidean, a - trunc*b, a - floor*b, a - euclidean*b]

def abi(a):
    n = a.j('native-host.json')
    m = a.j('native-host-artifacts/manifest.json')
    assert n['status'] == 'passed'
    assert n['host']['system'] == 'Darwin' and n['host']['machine'] == 'aarch64'
    assert n['host']['execution'] == 'native_host_process'
    assert m['source_identity']['commit'] == HEAD and m['source_identity']['tree'] == TREE
    assert m['source_identity']['compiler_sha256'] == n['compiler_sha256']
    assert n['retained_evidence']['source_identity'] == m['source_identity']
    assert n['retained_evidence']['files'] == m['files']
    a.check('native-host-artifacts/manifest.json', n['retained_evidence']['manifest'])
    for name, row in m['files'].items():
        a.check('native-host-artifacts/' + name, row)
    actual = {k[len('native-host-artifacts/'):] for k in a.files if k.startswith('native-host-artifacts/')}
    assert actual == set(m['files']) | {'manifest.json'}
    for field, path in (('harness_sha256', 'matrix.c'), ('header_sha256', 'matrix.h'),
                        ('layout_probes_sha256', 'layout-probes.rs'), ('source_sha256', 'matrix.hepta')):
        a.check('native-host-artifacts/inputs/' + path, {'sha256': n[field]})
    native = n['native_object']
    assert native == a.j('native-host-artifacts/native-build.json')
    assert native['status'] == 'rustc_checked' and native['target'] == 'aarch64-apple-darwin'
    a.check('native-host-artifacts/work/' + ntpath.basename(native['artifact']),
            {'sha256': native['artifact_sha256'], 'bytes': native['artifact_bytes']})
    a.check('native-host-artifacts/inputs/matrix.rs', {'sha256': native['rust_sha256']})
    assert len(n['executions']) == 2
    assert [e['optimization'] for e in n['executions']] == ['-O0', '-O2']
    for e in n['executions']:
        assert e['returncode'] == 0 and e['layout_checked']
        assert e['observed'] == {'foreign_calls': 181, 'status': 'passed'}
    commands = a.j('native-host-artifacts/commands.json')
    native_observed = []
    for cmd in commands:
        streams = cmd['retained_streams']
        assert streams['complete']
        for stream in ('stdout', 'stderr'):
            a.check('native-host-artifacts/' + streams[stream]['path'], streams[stream])
            a.streams.add('native-host-artifacts/' + streams[stream]['path'])
        raw = a.files['native-host-artifacts/' + streams['stdout']['path']]
        try:
            obs = json.loads(raw)
        except ValueError:
            continue
        if isinstance(obs, dict) and 'foreign_calls' in obs:
            assert cmd['returncode'] == 0 and obs == {'foreign_calls': 181, 'status': 'passed'}
            native_observed.append(obs)
    assert len(native_observed) == 2
    for optimization, expected in zip(('O0', 'O2'), n['executable_sha256s']):
        a.check('native-host-artifacts/work/host-matrix-' + optimization, {'sha256': expected})
    for optimization in ('O0', 'O2'):
        assert a.macho_headers['native-host-artifacts/work/host-matrix-' + optimization]['filetype'] == 2
    assert a.macho_headers['native-host-artifacts/work/matrix.o']['filetype'] == 1
    assert n['negative_control']['status'] == 'rejected_as_expected' and n['negative_control']['returncode'] != 0
    a.check('native-host-artifacts/work/wrong', {'sha256': n['negative_control']['artifact_sha256']})
    assert len(n['type_negative_controls']) == 3 and all(x['status'] == 'rejected_as_expected' and x['returncode'] != 0 for x in n['type_negative_controls'])
    type_preflight = a.j('original-type-preflight.json')
    assert type_preflight == a.j('original-type-preflight/qualification.json')
    assert type_preflight['ok'] and type_preflight['native_program_executions'] == 0
    assert len(type_preflight['cases']) == 2 and all(x['passed'] for x in type_preflight['cases'])
    for case in type_preflight['cases']:
        a.check('original-type-preflight/' + case['name'] + '/migration.json', {'sha256': case['report_sha256']})
    s = a.j('stb-divide-host.json')
    assert s == a.j('stb-divide-host/qualification.json')
    assert s['ok'] and s['status'] == 'passed_for_actual_host_and_declared_component_variants'
    assert s['source_before'] == s['source_after'] and s['source_unchanged_during_run']
    assert s['source_before']['commit'] == HEAD and s['source_before']['tree'] == TREE and s['source_before']['status'] == ''
    for row in s['artifacts']:
        a.check('stb-divide-host/' + row['path'], row)
    expected_artifacts = {norm(x['path']) for x in s['artifacts']}
    actual = {k[len('stb-divide-host/'):] for k in a.files if k.startswith('stb-divide-host/')}
    assert actual == expected_artifacts | {'qualification.json'}
    cases_bytes = a.files['stb-divide-host/cases.jsonl']
    assert sha(cases_bytes) == s['corpus']['input_sha256']
    cases = [json.loads(line) for line in cases_bytes.splitlines()]
    assert len(cases) == s['corpus']['unique_inputs'] == 21453
    assert len({(row['a'], row['b']) for row in cases}) == len(cases)
    assert all(row['expected'] == integer_oracle(row['a'], row['b']) for row in cases)
    variants = []
    for variant in s['variants']:
        assert variant['name'] in ('generic', 'truncating')
        assert variant['flags'] == ([] if variant['name'] == 'generic' else ['-DC_INTEGER_DIVISION_TRUNCATES'])
        assert variant['rust_build']['status'] == 'rustc_checked'
        assert variant['rust_build']['target'] == 'aarch64-apple-darwin'
        assert not variant['hia']['native_executed'] and not variant['hia']['native_requested']
        assert not variant['hia']['native_allocator_counters_observed']
        assert variant['hia']['interpreter_unique_inputs'] == 58
        assert variant['hia']['interpreter_function_observations'] == 348
        assert len(variant['executions']) == 1
        e = variant['executions'][0]
        assert e['generated_route'] == 'rust'
        assert e['summary']['cases'] == 21453 and e['summary']['native_function_observations'] == 257436
        assert e['summary']['resource_before'] == e['summary']['resource_after'] == [0, 0, 0, 0]
        a.check('stb-divide-host/' + variant['name'] + '/translated.dylib', {'sha256': e['target_sha256']})
        assert variant['rust_build']['artifact_sha256'] == e['target_sha256']
        a.check('stb-divide-host/' + variant['name'] + '/instrumented-generated.rs', {'sha256': variant['rust_build']['rust_sha256']})
        assert a.macho_headers['stb-divide-host/' + variant['name'] + '/translated.dylib']['filetype'] == 6
        callers = [x for x in s['artifacts'] if norm(x['path']).startswith(variant['name'] + '/') and x['sha256'] == e['caller_sha256']]
        assert len(callers) == 1
        assert a.macho_headers['stb-divide-host/' + norm(callers[0]['path'])]['filetype'] == 2
        original_root = ntpath.dirname(ntpath.dirname(variant['rust_build']['artifact']))
        original_caller = original_root + '/' + norm(callers[0]['path'])
        ordinary_processes = [p for p in s['processes'] if len(p['argv']) == 4 and p['argv'][:2] == [original_caller, variant['rust_build']['artifact']]]
        assert len(ordinary_processes) == 1
        ordinary_process = ordinary_processes[0]
        assert ordinary_process['returncode'] == 0 and json.loads(ordinary_process['stdout']) == e['summary']
        assert ordinary_process['argv'][2] == original_root + '/inputs.txt'
        trap_processes = [p for p in s['processes'] if len(p['argv']) == 6 and p['argv'][:3] == [original_caller, variant['rust_build']['artifact'], '--trap']]
        assert len(trap_processes) == 12
        assert {(int(p['argv'][3]), int(p['argv'][4]), int(p['argv'][5])) for p in trap_processes} == {(fn, a, b) for fn in range(6) for a, b in ((7, 0), (-(1 << 31), -1))}
        assert all(p['returncode'] == -6 and p['stdout'] == 'ENTERED_SAFE_TARGET\n' for p in trap_processes)
        matches = [x for x in s['artifacts'] if norm(x['path']).startswith(variant['name'] + '/') and x['sha256'] == e['observations_sha256']]
        assert len(matches) == 1
        observation_path = 'stb-divide-host/' + norm(matches[0]['path'])
        assert ordinary_process['argv'][3] == original_root + '/' + norm(matches[0]['path'])
        rows = a.files[observation_path].decode().splitlines()
        assert len(rows) == len(cases)
        for row, case in zip(rows, cases):
            values = [int(v) for v in row.split('\t')]
            assert len(values) == 20 and values[:2] == [case['a'], case['b']]
            expected = integer_oracle(values[0], values[1])
            assert values[2:8] == values[8:14] == values[14:20] == expected
        assert len(variant['traps']) == 12
        assert all(x['route'] == 'rust' and x['exit_code'] == -6 and not x['original_c_called'] for x in variant['traps'])
        variants.append({'name': variant['name'], 'flags': variant['flags'], 'executions': variant['executions'],
                         'hia': variant['hia'], 'native_target': {k: variant['rust_build'][k] for k in ('artifact_sha256', 'status', 'target', 'toolchain')},
                         'retained_tsv': observation_path, 'independent_integer_oracle_rows_checked': len(rows),
                         'trap_process_count': len(variant['traps']), 'traps': variant['traps'],
                         'ordinary_process': ordinary_process, 'trap_process_ledger_count': len(trap_processes)})
    assert s['totals']['native_function_observations'] == 514872
    assert s['totals']['interpreter_function_observations'] == 696
    assert s['totals']['native_target_only_trap_processes'] == 24
    assert s['wrong_code_control']['actual_native_executed'] and s['wrong_code_control']['rejected_by_functional_oracle']
    assert s['wrong_code_control']['exit_code'] == 2
    wrong_processes = [p for p in s['processes'] if p['returncode'] == 2 and p['argv'][-1].endswith('/wrong.tsv')]
    assert len(wrong_processes) == 1
    assert a.macho_headers['stb-divide-host/wrong.dylib']['filetype'] == 6
    assert all(x['whole_bundle_rejected'] and not x['published_partial_bundle'] for x in s['refusal_controls'])
    return {'kind': 'native_abi_and_stb_host', 'status': 'passed', 'host': n['host'],
            'source_identity': m['source_identity'], 'native_c_compiler': n['c_compiler'],
            'native_executions': n['executions'], 'native_executable_sha256s': n['executable_sha256s'],
            'native_object': {k: native[k] for k in ('artifact_sha256', 'rust_sha256', 'target', 'status', 'toolchain')},
            'native_manifest_scope': m['scope'], 'native_limits': n['limits'], 'native_claims': n['claims'],
            'native_negative_control': n['negative_control'], 'type_negative_controls': n['type_negative_controls'],
            'original_type_preflight': {'status': type_preflight['status'], 'ok': True, 'cases': type_preflight['cases'],
                                        'native_program_executions': 0, 'claims': type_preflight['claims'], 'limits': type_preflight['limits']},
            'stb': {'source_identity': {k: s['source_before'][k] for k in ('commit', 'tree', 'status', 'status_scope')},
                    'source_inputs_comparison': source_comparison(s['source_before']['implementation_files']),
                    'upstream': s['upstream'], 'scope': s['scope'], 'totals': s['totals'], 'variants': variants,
                    'native_process_ledger': [{'argv': p['argv'], 'cwd': p['cwd'], 'returncode': p['returncode'],
                                              'captured_stdout_utf8': ident(p['stdout'].encode('utf-8')),
                                              'captured_stderr_utf8': ident(p['stderr'].encode('utf-8'))} for p in s['processes']],
                    'native_process_stream_scope': 'Original qualifier retains decoded stdout/stderr strings in JSON, not separate byte-exact base64 streams for these STB subprocesses. UTF-8 identities here identify the retained strings only.',
                    'resource_scope': s['resource_scope'], 'claims': s['claims'], 'wrong_code_control': s['wrong_code_control'],
                    'refusal_controls': s['refusal_controls'], 'cpp_entry_refusal': s['cpp_entry_refusal']},
            'backend_boundary': 'Native ABI object and both STB component targets execute the actual Rust backend. HIA STB observation is interpreter-only (696 function observations total); HIA LLVM native execution is explicitly false on this macOS ARM64 profile.'}

def log_audit(entries):
    rows = []
    for entry in entries:
        raw = entry['decoded_log'].encode('utf-8')
        text = re.sub(r'^\ufeff', '', entry['decoded_log'])
        text = re.sub(r'^\d{4}-\d{2}-\d{2}T[\d:.]+Z ', '', text, flags=re.M)
        text = re.sub(r'\x1b\[[0-9;]*m', '', text)
        lines = text.splitlines()
        tests = [x for x in lines if re.match(r'^test_.* \.\.\. (ok|skip|FAIL|ERROR)', x)]
        summaries = [x for x in lines if re.match(r'^Ran \d+ tests? in |^OK(?:$| \()|^FAILED', x)]
        skipped = [x for x in lines if re.search(r'\.\.\. skipped|^OK \(skipped|^Skipped|^skipped', x)]
        ran = [int(re.search(r'^Ran (\d+) tests?', x).group(1)) for x in summaries if x.startswith('Ran ')]
        assert entry['job_id'] in JOBS.values()
        assert all(x.endswith(' ... ok') for x in tests) and not skipped
        assert len(tests) == sum(ran) == (16 if entry['job_id'] == 127608285065 else 57)
        assert sum(x == 'OK' for x in summaries) == len(ran)
        rows.append({'job_id': entry['job_id'], 'decoded_log_utf8_identity': ident(raw),
                     'identity_scope': 'Exact UTF-8 encoding of the decoded log string returned by the GitHub job-log connector; original compressed HTTP transport bytes not supplied.',
                     'raw_log_not_published': True, 'test_lines': tests, 'summary_lines': summaries,
                     'tests_reported': sum(ran), 'unittest_skipped_lines': skipped,
                     'test_reruns_by_this_audit': 0})
    assert {x['job_id'] for x in rows} == set(JOBS.values())
    return {'schema': 'hepta.macos-ci-log-audit.v1', 'jobs': rows,
            'scope': 'Allowlisted unittest test/result lines from existing GitHub logs, with full decoded-log hashes. Setup/credential/configuration and temporary download URL lines excluded.'}

def main():
    assert sys.flags.optimize == 0 and sys.flags.isolated and sys.flags.ignore_environment
    request = json.load(sys.stdin)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    wall, cpu = time.monotonic_ns(), time.process_time_ns()
    assert set(os.sched_getaffinity(0)).issubset({24, 25})
    assert request['published_commit']['sha'] == HEAD and request['published_commit']['tree']['sha'] == TREE
    snapshot_bytes = SNAPSHOT.read_bytes()
    assert sha(snapshot_bytes) == SNAPSHOT_SHA
    snapshot = json.loads(snapshot_bytes)
    assert snapshot['expected_head'] == HEAD
    found_jobs = {}
    for node in walk(snapshot):
        if node.get('id') in JOBS.values() and isinstance(node.get('steps'), list):
            jobid = node['id']
            if jobid in found_jobs:
                assert found_jobs[jobid] == node
            found_jobs[jobid] = node
    assert set(found_jobs) == set(JOBS.values())
    log_result = log_audit(request['job_logs'])
    results = []
    for metadata in request['artifact_metadata']:
        a = Archive(metadata)
        job = found_jobs[JOBS[a.id]]
        assert job['head_sha'] == HEAD and job['status'] == 'completed' and job['conclusion'] == 'success'
        assert metadata['workflow_run']['id'] == job['run_id']
        result = cpp(a) if 'cpp-upstream-host.json' in a.files else abi(a)
        if result['kind'] == 'cpp_upstream_host':
            comparison = result['source_inputs_comparison']
        else:
            comparison = result['stb']['source_inputs_comparison']
        assert not comparison['different_bytes'] and not comparison['absent_paths']
        jobbrief = {k: job.get(k) for k in ('id', 'run_id', 'name', 'head_sha', 'status', 'conclusion', 'started_at', 'completed_at', 'runner_name', 'runner_group_name', 'labels')}
        jobbrief['steps'] = job['steps']
        jobbrief['skipped_steps'] = [x for x in job['steps'] if x['conclusion'] == 'skipped']
        assert len(jobbrief['skipped_steps']) == 1 and jobbrief['skipped_steps'][0]['name'] == 'Establish the actual Visual Studio and Windows SDK environment'
        if result['kind'] == 'native_abi_and_stb_host':
            posix = [x for x in job['steps'] if x['name'] == 'Check non-reaping POSIX leader and capture-read boundaries']
            assert len(posix) == 1 and posix[0]['status'] == 'completed' and posix[0]['conclusion'] == 'success'
            result['posix_supervision_step'] = posix[0]
            result['posix_supervision_observation'] = 'Existing macOS job step succeeded; 20 unittest methods in that group are visible as ok in the retained allowlisted job-log excerpt. Finite process/capture boundaries only.'
        results.append(dict(a.summary(), github_job=jobbrief, qualification=result))
    assert len(results) == 2
    terminal = request['download_terminal_receipt']
    assert terminal['state'] == 'succeeded' and terminal['exit_code'] == 0
    assert terminal['output_complete'] and terminal['output_durable'] and terminal['terminal_publication_confirmed']
    audit = {'schema': 'hepta.macos-artifact-audit.v1', 'passed': True,
             'started_utc': start, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'scope': 'Independent read-only audit of original downloaded CI ZIPs, retained original bytes, Mach-O headers and finite oracle outputs. No executable from these archives was run; no CI rerun or new qualification campaign.',
             'published_source': {'commit': HEAD, 'tree': TREE},
             'separate_linux_measured_source': {'commit': MEASURED_HEAD, 'tree': TREE},
             'same_tree_does_not_merge_commits_or_qualification_profiles': True,
             'github_commit_tree_response': {k: request['published_commit'][k] for k in ('sha', 'tree', 'url')},
             'github_snapshot': dict(ident(snapshot_bytes), path=str(SNAPSHOT)),
             'artifact_download_terminal_receipt': terminal,
             'profiles': results, 'github_log_audit': log_result,
             'audit_runtime': {'affinity': sorted(os.sched_getaffinity(0)), 'python': sys.version, 'flags': {'optimize': sys.flags.optimize, 'isolated': sys.flags.isolated, 'ignore_environment': sys.flags.ignore_environment}},
             'audit_script': dict(ident(pathlib.Path(__file__).read_bytes()), path=str(pathlib.Path(__file__).resolve())),
             'native_reruns': 0, 'ci_reruns': 0, 'model_requests': 0,
             'wall_ns': time.monotonic_ns()-wall, 'cpu_ns': time.process_time_ns()-cpu,
             'limits': ['GitHub Actions native processes qualify the stated macOS ARM64 Apple Clang/Rust profiles; they are not physical-device or hardware fault-recovery evidence.',
                        'Only Visual Studio environment setup is skipped in the two macOS jobs. Existing POSIX/Darwin process-boundary tests ran; this does not establish all scheduler interleavings or a general memory-model theorem.',
                        'C++ consumer and native ABI/STB targets use Rust backend. Rust compiler internal LLVM version is not the project HIA LLVM backend. No HIA LLVM AOT macOS qualification is implied.',
                        'STB HIA native_requested and native_executed are false in both variants. The 696 HIA observations are interpreted, and their allocator counters are not native observations.',
                        'Native ABI Rust compiler argv/raw streams and temporary Rust input bytes are not retained by that original qualifier; its structured receipt, canonical input and object hashes are retained.',
                        'Each C++ upstream version reports two process-lifetime registry allocations retained with ordinary object live delta zero. These are not zero retained allocations and are separate from the P2 owner/library registry scope.',
                        'Finite library/ABI/cancellation/lifetime cases do not establish general source equivalence, all interleavings, foreign lifetime soundness, development cost improvement or all upstream configuration support.']}
    output = ROOT / 'MACOS_ARTIFACT_AUDIT.json'
    write(output, wire(audit))
    write(ROOT / 'GITHUB_LOG_AUDIT.json', wire(log_result))
    metadata = {k: audit[k] for k in ('published_source', 'separate_linux_measured_source', 'github_commit_tree_response', 'github_snapshot', 'artifact_download_terminal_receipt')}
    metadata['artifacts'] = request['artifact_metadata']
    metadata['jobs'] = {str(r['artifact_id']): r['github_job'] for r in results}
    write(ROOT / 'GITHUB_METADATA.json', wire(metadata))
    print(json.dumps({'passed': True, 'result': dict(ident(output.read_bytes()), path=str(output)),
                      'profiles': [{'artifact_id': r['artifact_id'], 'kind': r['qualification']['kind'],
                                    'zip_files': r['zip_regular_file_count'], 'macho_files': len(r['macho_arm64_files']),
                                    'retained_files_checked': r['checked_retained_file_count'],
                                    'raw_stream_files_checked': r['separately_checked_raw_stream_file_count'],
                                    'embedded_streams_checked': r['checked_embedded_stream_records']} for r in results],
                      'tests_in_existing_logs': sum(x['tests_reported'] for x in log_result['jobs']),
                      'native_reruns': 0, 'cpu_ns': audit['cpu_ns'], 'wall_ns': audit['wall_ns']}))

if __name__ == '__main__':
    main()
