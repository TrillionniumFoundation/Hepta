#include "owners.h"
unsigned long long run_pair(unsigned long left, unsigned long right, unsigned char value,
                            unsigned long index, unsigned int reject, unsigned int early) noexcept {
    try {
        PairedBytes first(left, right, reject);
        first.prepare(value);
        if (early == 1) { return 2001; }
        PairedBytes second(right, left, 0);
        second.prepare(static_cast<unsigned char>(255));
        second = static_cast<PairedBytes&&>(first);
        second = static_cast<PairedBytes&&>(second);
        return consume_pair(static_cast<PairedBytes&&>(second), index, early);
    } catch (int code) { return 1000 + static_cast<unsigned long long>(code); }
      catch (...) { return 1001; }
}
