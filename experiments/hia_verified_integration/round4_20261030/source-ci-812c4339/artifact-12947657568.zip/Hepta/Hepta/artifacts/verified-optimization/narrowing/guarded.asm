
/home/runner/work/Hepta/Hepta/artifacts/verified-optimization/narrowing/guarded.so:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	endbr64
    1004:	sub    $0x8,%rsp
    1008:	mov    0x2fc1(%rip),%rax        # 3fd0 <__gmon_start__@Base>
    100f:	test   %rax,%rax
    1012:	je     1016 <_init+0x16>
    1014:	call   *%rax
    1016:	add    $0x8,%rsp
    101a:	ret

Disassembly of section .plt:

0000000000001020 <free@plt-0x10>:
    1020:	push   0x2fca(%rip)        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	jmp    *0x2fcc(%rip)        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	nopl   0x0(%rax)

0000000000001030 <free@plt>:
    1030:	jmp    *0x2fca(%rip)        # 4000 <free@GLIBC_2.2.5>
    1036:	push   $0x0
    103b:	jmp    1020 <_init+0x20>

0000000000001040 <abort@plt>:
    1040:	jmp    *0x2fc2(%rip)        # 4008 <abort@GLIBC_2.2.5>
    1046:	push   $0x1
    104b:	jmp    1020 <_init+0x20>

0000000000001050 <calloc@plt>:
    1050:	jmp    *0x2fba(%rip)        # 4010 <calloc@GLIBC_2.2.5>
    1056:	push   $0x2
    105b:	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001060 <__cxa_finalize@plt>:
    1060:	jmp    *0x2f7a(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1066:	xchg   %ax,%ax

Disassembly of section .text:

0000000000001070 <deregister_tm_clones>:
    1070:	lea    0x2fa9(%rip),%rdi        # 4020 <completed.0>
    1077:	lea    0x2fa2(%rip),%rax        # 4020 <completed.0>
    107e:	cmp    %rdi,%rax
    1081:	je     1098 <deregister_tm_clones+0x28>
    1083:	mov    0x2f3e(%rip),%rax        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    108a:	test   %rax,%rax
    108d:	je     1098 <deregister_tm_clones+0x28>
    108f:	jmp    *%rax
    1091:	nopl   0x0(%rax)
    1098:	ret
    1099:	nopl   0x0(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:	lea    0x2f79(%rip),%rdi        # 4020 <completed.0>
    10a7:	lea    0x2f72(%rip),%rsi        # 4020 <completed.0>
    10ae:	sub    %rdi,%rsi
    10b1:	mov    %rsi,%rax
    10b4:	shr    $0x3f,%rsi
    10b8:	sar    $0x3,%rax
    10bc:	add    %rax,%rsi
    10bf:	sar    $1,%rsi
    10c2:	je     10d8 <register_tm_clones+0x38>
    10c4:	mov    0x2f0d(%rip),%rax        # 3fd8 <_ITM_registerTMCloneTable@Base>
    10cb:	test   %rax,%rax
    10ce:	je     10d8 <register_tm_clones+0x38>
    10d0:	jmp    *%rax
    10d2:	nopw   0x0(%rax,%rax,1)
    10d8:	ret
    10d9:	nopl   0x0(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:	endbr64
    10e4:	cmpb   $0x0,0x2f35(%rip)        # 4020 <completed.0>
    10eb:	jne    1118 <__do_global_dtors_aux+0x38>
    10ed:	push   %rbp
    10ee:	cmpq   $0x0,0x2eea(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10f6:	mov    %rsp,%rbp
    10f9:	je     1107 <__do_global_dtors_aux+0x27>
    10fb:	mov    0x2f16(%rip),%rdi        # 4018 <__dso_handle>
    1102:	call   1060 <__cxa_finalize@plt>
    1107:	call   1070 <deregister_tm_clones>
    110c:	movb   $0x1,0x2f0d(%rip)        # 4020 <completed.0>
    1113:	pop    %rbp
    1114:	ret
    1115:	nopl   (%rax)
    1118:	ret
    1119:	nopl   0x0(%rax)

0000000000001120 <frame_dummy>:
    1120:	endbr64
    1124:	jmp    10a0 <register_tm_clones>
    1129:	nopl   0x0(%rax)

0000000000001130 <full_lifecycle>:
    1130:	push   %rbp
    1131:	push   %r14
    1133:	push   %rbx
    1134:	mov    %esi,%ebp
    1136:	mov    %rdi,%rbx
    1139:	cmp    $0x21,%rdi
    113d:	jae    116f <full_lifecycle+0x3f>
    113f:	test   %rbx,%rbx
    1142:	je     12c4 <full_lifecycle+0x194>
    1148:	mov    $0x1,%edi
    114d:	mov    %rbx,%rsi
    1150:	call   1050 <calloc@plt>
    1155:	test   %rax,%rax
    1158:	je     12cc <full_lifecycle+0x19c>
    115e:	cmp    $0x3,%rbx
    1162:	ja     12d7 <full_lifecycle+0x1a7>
    1168:	xor    %ecx,%ecx
    116a:	jmp    13ab <full_lifecycle+0x27b>
    116f:	test   %rbx,%rbx
    1172:	js     11a1 <full_lifecycle+0x71>
    1174:	mov    $0x1,%edi
    1179:	mov    %rbx,%rsi
    117c:	call   1050 <calloc@plt>
    1181:	test   %rax,%rax
    1184:	je     11a1 <full_lifecycle+0x71>
    1186:	mov    $0x1,%cl
    1188:	test   $0x1,%cl
    118b:	jne    11aa <full_lifecycle+0x7a>
    118d:	mov    $0x3e9,%r14d
    1193:	test   %rax,%rax
    1196:	jne    1495 <full_lifecycle+0x365>
    119c:	jmp    149d <full_lifecycle+0x36d>
    11a1:	xor    %eax,%eax
    11a3:	xor    %ecx,%ecx
    11a5:	test   $0x1,%cl
    11a8:	je     118d <full_lifecycle+0x5d>
    11aa:	mov    %rbx,%rcx
    11ad:	and    $0xfffffffffffffff0,%rcx
    11b1:	movd   %ebp,%xmm0
    11b5:	pshufd $0x0,%xmm0,%xmm0
    11ba:	movdqa 0xe3e(%rip),%xmm2        # 2000 <_fini+0x308>
    11c2:	movdqa 0xe46(%rip),%xmm3        # 2010 <_fini+0x318>
    11ca:	movdqa 0xe4e(%rip),%xmm4        # 2020 <_fini+0x328>
    11d2:	movdqa 0xe56(%rip),%xmm5        # 2030 <_fini+0x338>
    11da:	xor    %edx,%edx
    11dc:	movdqa 0xe5c(%rip),%xmm1        # 2040 <_fini+0x348>
    11e4:	movdqa 0xe64(%rip),%xmm6        # 2050 <_fini+0x358>
    11ec:	nopl   0x0(%rax)
    11f0:	movdqa %xmm0,%xmm7
    11f4:	paddd  %xmm2,%xmm7
    11f8:	movdqa %xmm0,%xmm8
    11fd:	paddd  %xmm3,%xmm8
    1202:	movdqa %xmm0,%xmm9
    1207:	paddd  %xmm4,%xmm9
    120c:	movdqa %xmm0,%xmm10
    1211:	paddd  %xmm5,%xmm10
    1216:	pand   %xmm1,%xmm10
    121b:	pand   %xmm1,%xmm9
    1220:	packuswb %xmm9,%xmm10
    1225:	pand   %xmm1,%xmm8
    122a:	pand   %xmm1,%xmm7
    122e:	packuswb %xmm7,%xmm8
    1233:	packuswb %xmm8,%xmm10
    1238:	movdqu %xmm10,(%rax,%rdx,1)
    123e:	add    $0x10,%rdx
    1242:	paddd  %xmm6,%xmm5
    1246:	paddd  %xmm6,%xmm4
    124a:	paddd  %xmm6,%xmm3
    124e:	paddd  %xmm6,%xmm2
    1252:	cmp    %rdx,%rcx
    1255:	jne    11f0 <full_lifecycle+0xc0>
    1257:	cmp    %rcx,%rbx
    125a:	je     146f <full_lifecycle+0x33f>
    1260:	test   $0xc,%bl
    1263:	je     1451 <full_lifecycle+0x321>
    1269:	mov    %rbx,%rdx
    126c:	and    $0xfffffffffffffffc,%rdx
    1270:	movd   %ecx,%xmm2
    1274:	pshufd $0x0,%xmm2,%xmm2
    1279:	por    0xdaf(%rip),%xmm2        # 2030 <_fini+0x338>
    1281:	movdqa 0xdd7(%rip),%xmm3        # 2060 <_fini+0x368>
    1289:	nopl   0x0(%rax)
    1290:	movdqa %xmm0,%xmm4
    1294:	paddd  %xmm2,%xmm4
    1298:	pand   %xmm1,%xmm4
    129c:	packuswb %xmm4,%xmm4
    12a0:	packuswb %xmm4,%xmm4
    12a4:	movd   %xmm4,(%rax,%rcx,1)
    12a9:	add    $0x4,%rcx
    12ad:	paddd  %xmm3,%xmm2
    12b1:	cmp    %rcx,%rdx
    12b4:	jne    1290 <full_lifecycle+0x160>
    12b6:	cmp    %rdx,%rbx
    12b9:	jne    1454 <full_lifecycle+0x324>
    12bf:	jmp    146f <full_lifecycle+0x33f>
    12c4:	xor    %r14d,%r14d
    12c7:	jmp    149d <full_lifecycle+0x36d>
    12cc:	mov    $0x3e9,%r14d
    12d2:	jmp    149d <full_lifecycle+0x36d>
    12d7:	cmp    $0x10,%rbx
    12db:	jae    12e1 <full_lifecycle+0x1b1>
    12dd:	xor    %ecx,%ecx
    12df:	jmp    1340 <full_lifecycle+0x210>
    12e1:	mov    %ebx,%ecx
    12e3:	and    $0x30,%ecx
    12e6:	movd   %ebp,%xmm0
    12ea:	pshufd $0x0,%xmm0,%xmm0
    12ef:	movdqa 0xd49(%rip),%xmm1        # 2040 <_fini+0x348>
    12f7:	pand   %xmm0,%xmm1
    12fb:	packuswb %xmm1,%xmm1
    12ff:	packuswb %xmm1,%xmm1
    1303:	paddb  0xd65(%rip),%xmm1        # 2070 <_fini+0x378>
    130b:	movdqu %xmm1,(%rax)
    130f:	cmp    $0x10,%rcx
    1313:	je     1332 <full_lifecycle+0x202>
    1315:	pand   0xd23(%rip),%xmm0        # 2040 <_fini+0x348>
    131d:	packuswb %xmm0,%xmm0
    1321:	packuswb %xmm0,%xmm0
    1325:	paddb  0xd53(%rip),%xmm0        # 2080 <_fini+0x388>
    132d:	movdqu %xmm0,0x10(%rax)
    1332:	cmp    %rcx,%rbx
    1335:	je     13bf <full_lifecycle+0x28f>
    133b:	test   $0xc,%bl
    133e:	je     13ab <full_lifecycle+0x27b>
    1340:	mov    %rcx,%rdx
    1343:	mov    %ebx,%ecx
    1345:	and    $0x3c,%ecx
    1348:	movd   %edx,%xmm0
    134c:	pshufd $0x0,%xmm0,%xmm0
    1351:	por    0xcd7(%rip),%xmm0        # 2030 <_fini+0x338>
    1359:	movd   %ebp,%xmm1
    135d:	pshufd $0x0,%xmm1,%xmm1
    1362:	movdqa 0xcd6(%rip),%xmm2        # 2040 <_fini+0x348>
    136a:	movdqa 0xcee(%rip),%xmm3        # 2060 <_fini+0x368>
    1372:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1380:	movdqa %xmm1,%xmm4
    1384:	paddd  %xmm0,%xmm4
    1388:	pand   %xmm2,%xmm4
    138c:	packuswb %xmm4,%xmm4
    1390:	packuswb %xmm4,%xmm4
    1394:	movd   %xmm4,(%rax,%rdx,1)
    1399:	add    $0x4,%rdx
    139d:	paddd  %xmm3,%xmm0
    13a1:	cmp    %rdx,%rcx
    13a4:	jne    1380 <full_lifecycle+0x250>
    13a6:	cmp    %rcx,%rbx
    13a9:	je     13bf <full_lifecycle+0x28f>
    13ab:	mov    %ebp,%edx
    13ad:	nopl   (%rax)
    13b0:	lea    (%rdx,%rcx,1),%esi
    13b3:	mov    %sil,(%rax,%rcx,1)
    13b7:	inc    %rcx
    13ba:	cmp    %rcx,%rbx
    13bd:	jne    13b0 <full_lifecycle+0x280>
    13bf:	mov    %ebx,%ecx
    13c1:	and    $0x7,%ecx
    13c4:	cmp    $0x8,%rbx
    13c8:	jae    13d1 <full_lifecycle+0x2a1>
    13ca:	xor    %edx,%edx
    13cc:	xor    %r14d,%r14d
    13cf:	jmp    142a <full_lifecycle+0x2fa>
    13d1:	and    $0x38,%ebx
    13d4:	xor    %edx,%edx
    13d6:	xor    %r14d,%r14d
    13d9:	nopl   0x0(%rax)
    13e0:	movzbl (%rax,%rdx,1),%esi
    13e4:	add    %r14,%rsi
    13e7:	movzbl 0x1(%rax,%rdx,1),%edi
    13ec:	movzbl 0x2(%rax,%rdx,1),%r8d
    13f2:	add    %rdi,%r8
    13f5:	add    %rsi,%r8
    13f8:	movzbl 0x3(%rax,%rdx,1),%esi
    13fd:	movzbl 0x4(%rax,%rdx,1),%edi
    1402:	add    %rsi,%rdi
    1405:	movzbl 0x5(%rax,%rdx,1),%esi
    140a:	add    %rdi,%rsi
    140d:	add    %r8,%rsi
    1410:	movzbl 0x6(%rax,%rdx,1),%edi
    1415:	movzbl 0x7(%rax,%rdx,1),%r14d
    141b:	add    %rdi,%r14
    141e:	add    %rsi,%r14
    1421:	add    $0x8,%rdx
    1425:	cmp    %rdx,%rbx
    1428:	jne    13e0 <full_lifecycle+0x2b0>
    142a:	test   %rcx,%rcx
    142d:	je     1495 <full_lifecycle+0x365>
    142f:	mov    %rax,%rsi
    1432:	add    %rdx,%rsi
    1435:	xor    %edx,%edx
    1437:	nopw   0x0(%rax,%rax,1)
    1440:	movzbl (%rsi,%rdx,1),%edi
    1444:	add    %rdi,%r14
    1447:	inc    %rdx
    144a:	cmp    %rdx,%rcx
    144d:	jne    1440 <full_lifecycle+0x310>
    144f:	jmp    1495 <full_lifecycle+0x365>
    1451:	mov    %rcx,%rdx
    1454:	mov    %ebp,%ecx
    1456:	cs nopw 0x0(%rax,%rax,1)
    1460:	lea    (%rcx,%rdx,1),%esi
    1463:	mov    %sil,(%rax,%rdx,1)
    1467:	inc    %rdx
    146a:	cmp    %rdx,%rbx
    146d:	jne    1460 <full_lifecycle+0x330>
    146f:	xor    %ecx,%ecx
    1471:	xor    %r14d,%r14d
    1474:	data16 data16 cs nopw 0x0(%rax,%rax,1)
    1480:	mov    %r14,%rdx
    1483:	movzbl (%rax,%rcx,1),%r14d
    1488:	add    %rdx,%r14
    148b:	jb     14a5 <full_lifecycle+0x375>
    148d:	inc    %rcx
    1490:	cmp    %rcx,%rbx
    1493:	jne    1480 <full_lifecycle+0x350>
    1495:	mov    %rax,%rdi
    1498:	call   1030 <free@plt>
    149d:	mov    %r14,%rax
    14a0:	pop    %rbx
    14a1:	pop    %r14
    14a3:	pop    %rbp
    14a4:	ret
    14a5:	call   1040 <abort@plt>
    14aa:	nopw   0x0(%rax,%rax,1)

00000000000014b0 <packet_xor>:
    14b0:	push   %r15
    14b2:	push   %r14
    14b4:	push   %rbx
    14b5:	mov    %esi,%r15d
    14b8:	mov    %rdi,%r14
    14bb:	cmp    $0x21,%rdi
    14bf:	jae    14f4 <packet_xor+0x44>
    14c1:	test   %r14,%r14
    14c4:	je     16f0 <packet_xor+0x240>
    14ca:	mov    $0x1,%edi
    14cf:	mov    %r14,%rsi
    14d2:	call   1050 <calloc@plt>
    14d7:	test   %rax,%rax
    14da:	je     16f8 <packet_xor+0x248>
    14e0:	mov    %rax,%rbx
    14e3:	cmp    $0x3,%r14
    14e7:	ja     1703 <packet_xor+0x253>
    14ed:	xor    %eax,%eax
    14ef:	jmp    17f6 <packet_xor+0x346>
    14f4:	test   %r14,%r14
    14f7:	js     1528 <packet_xor+0x78>
    14f9:	mov    $0x1,%edi
    14fe:	mov    %r14,%rsi
    1501:	call   1050 <calloc@plt>
    1506:	test   %rax,%rax
    1509:	je     1528 <packet_xor+0x78>
    150b:	mov    %rax,%rbx
    150e:	mov    $0x1,%al
    1510:	test   $0x1,%al
    1512:	jne    1530 <packet_xor+0x80>
    1514:	mov    $0x3e9,%r15d
    151a:	test   %rbx,%rbx
    151d:	jne    1cd7 <packet_xor+0x827>
    1523:	jmp    1cdf <packet_xor+0x82f>
    1528:	xor    %ebx,%ebx
    152a:	xor    %eax,%eax
    152c:	test   $0x1,%al
    152e:	je     1514 <packet_xor+0x64>
    1530:	mov    %r14,%rax
    1533:	and    $0xfffffffffffffff0,%rax
    1537:	movd   %r15d,%xmm0
    153c:	pshufd $0x0,%xmm0,%xmm0
    1541:	movdqa 0xab7(%rip),%xmm2        # 2000 <_fini+0x308>
    1549:	movdqa 0xabf(%rip),%xmm3        # 2010 <_fini+0x318>
    1551:	movdqa 0xac7(%rip),%xmm4        # 2020 <_fini+0x328>
    1559:	movdqa 0xacf(%rip),%xmm5        # 2030 <_fini+0x338>
    1561:	xor    %ecx,%ecx
    1563:	movdqa 0xb25(%rip),%xmm1        # 2090 <_fini+0x398>
    156b:	movdqa 0xacc(%rip),%xmm11        # 2040 <_fini+0x348>
    1574:	movdqa 0xad3(%rip),%xmm12        # 2050 <_fini+0x358>
    157d:	nopl   (%rax)
    1580:	movdqa %xmm5,%xmm6
    1584:	pmuludq %xmm1,%xmm6
    1588:	pshufd $0xe8,%xmm6,%xmm6
    158d:	pshufd $0xf5,%xmm5,%xmm7
    1592:	pmuludq %xmm1,%xmm7
    1596:	pshufd $0xe8,%xmm7,%xmm7
    159b:	punpckldq %xmm7,%xmm6
    159f:	movdqa %xmm4,%xmm7
    15a3:	pmuludq %xmm1,%xmm7
    15a7:	pshufd $0xe8,%xmm7,%xmm7
    15ac:	pshufd $0xf5,%xmm4,%xmm8
    15b2:	pmuludq %xmm1,%xmm8
    15b7:	pshufd $0xe8,%xmm8,%xmm8
    15bd:	punpckldq %xmm8,%xmm7
    15c2:	movdqa %xmm3,%xmm8
    15c7:	pmuludq %xmm1,%xmm8
    15cc:	pshufd $0xe8,%xmm8,%xmm8
    15d2:	pshufd $0xf5,%xmm3,%xmm9
    15d8:	pmuludq %xmm1,%xmm9
    15dd:	pshufd $0xe8,%xmm9,%xmm9
    15e3:	punpckldq %xmm9,%xmm8
    15e8:	movdqa %xmm2,%xmm9
    15ed:	pmuludq %xmm1,%xmm9
    15f2:	pshufd $0xe8,%xmm9,%xmm9
    15f8:	pshufd $0xf5,%xmm2,%xmm10
    15fe:	pmuludq %xmm1,%xmm10
    1603:	pshufd $0xe8,%xmm10,%xmm10
    1609:	punpckldq %xmm10,%xmm9
    160e:	paddd  %xmm0,%xmm9
    1613:	paddd  %xmm0,%xmm8
    1618:	paddd  %xmm0,%xmm7
    161c:	paddd  %xmm0,%xmm6
    1620:	pand   %xmm11,%xmm6
    1625:	pand   %xmm11,%xmm7
    162a:	packuswb %xmm7,%xmm6
    162e:	pand   %xmm11,%xmm8
    1633:	pand   %xmm11,%xmm9
    1638:	packuswb %xmm9,%xmm8
    163d:	packuswb %xmm8,%xmm6
    1642:	movdqu %xmm6,(%rbx,%rcx,1)
    1647:	add    $0x10,%rcx
    164b:	paddd  %xmm12,%xmm5
    1650:	paddd  %xmm12,%xmm4
    1655:	paddd  %xmm12,%xmm3
    165a:	paddd  %xmm12,%xmm2
    165f:	cmp    %rcx,%rax
    1662:	jne    1580 <packet_xor+0xd0>
    1668:	cmp    %rax,%r14
    166b:	je     186d <packet_xor+0x3bd>
    1671:	test   $0xc,%r14b
    1675:	je     1852 <packet_xor+0x3a2>
    167b:	mov    %r14,%rcx
    167e:	and    $0xfffffffffffffffc,%rcx
    1682:	movd   %eax,%xmm2
    1686:	pshufd $0x0,%xmm2,%xmm2
    168b:	por    0x99d(%rip),%xmm2        # 2030 <_fini+0x338>
    1693:	movdqa 0x9c5(%rip),%xmm3        # 2060 <_fini+0x368>
    169b:	nopl   0x0(%rax,%rax,1)
    16a0:	movdqa %xmm2,%xmm4
    16a4:	pmuludq %xmm1,%xmm4
    16a8:	pshufd $0xe8,%xmm4,%xmm4
    16ad:	pshufd $0xf5,%xmm2,%xmm5
    16b2:	pmuludq %xmm1,%xmm5
    16b6:	pshufd $0xe8,%xmm5,%xmm5
    16bb:	punpckldq %xmm5,%xmm4
    16bf:	paddd  %xmm0,%xmm4
    16c3:	pand   %xmm11,%xmm4
    16c8:	packuswb %xmm4,%xmm4
    16cc:	packuswb %xmm4,%xmm4
    16d0:	movd   %xmm4,(%rbx,%rax,1)
    16d5:	add    $0x4,%rax
    16d9:	paddd  %xmm3,%xmm2
    16dd:	cmp    %rax,%rcx
    16e0:	jne    16a0 <packet_xor+0x1f0>
    16e2:	cmp    %rcx,%r14
    16e5:	jne    1855 <packet_xor+0x3a5>
    16eb:	jmp    186d <packet_xor+0x3bd>
    16f0:	xor    %r15d,%r15d
    16f3:	jmp    1cdf <packet_xor+0x82f>
    16f8:	mov    $0x3e9,%r15d
    16fe:	jmp    1cdf <packet_xor+0x82f>
    1703:	cmp    $0x10,%r14
    1707:	jae    170d <packet_xor+0x25d>
    1709:	xor    %eax,%eax
    170b:	jmp    1773 <packet_xor+0x2c3>
    170d:	mov    %r14d,%eax
    1710:	and    $0x30,%eax
    1713:	movd   %r15d,%xmm0
    1718:	pshufd $0x0,%xmm0,%xmm0
    171d:	movdqa 0x91b(%rip),%xmm1        # 2040 <_fini+0x348>
    1725:	pand   %xmm0,%xmm1
    1729:	packuswb %xmm1,%xmm1
    172d:	packuswb %xmm1,%xmm1
    1731:	paddb  0x967(%rip),%xmm1        # 20a0 <_fini+0x3a8>
    1739:	movdqu %xmm1,(%rbx)
    173d:	cmp    $0x10,%rax
    1741:	je     1760 <packet_xor+0x2b0>
    1743:	pand   0x8f5(%rip),%xmm0        # 2040 <_fini+0x348>
    174b:	packuswb %xmm0,%xmm0
    174f:	packuswb %xmm0,%xmm0
    1753:	paddb  0x955(%rip),%xmm0        # 20b0 <_fini+0x3b8>
    175b:	movdqu %xmm0,0x10(%rbx)
    1760:	cmp    %rax,%r14
    1763:	je     180e <packet_xor+0x35e>
    1769:	test   $0xc,%r14b
    176d:	je     17f6 <packet_xor+0x346>
    1773:	mov    %rax,%rcx
    1776:	mov    %r14d,%eax
    1779:	and    $0x3c,%eax
    177c:	movd   %ecx,%xmm0
    1780:	pshufd $0x0,%xmm0,%xmm0
    1785:	por    0x8a3(%rip),%xmm0        # 2030 <_fini+0x338>
    178d:	movd   %r15d,%xmm1
    1792:	pshufd $0x0,%xmm1,%xmm1
    1797:	movdqa 0x8f1(%rip),%xmm2        # 2090 <_fini+0x398>
    179f:	movdqa 0x899(%rip),%xmm3        # 2040 <_fini+0x348>
    17a7:	movdqa 0x8b1(%rip),%xmm4        # 2060 <_fini+0x368>
    17af:	nop
    17b0:	movdqa %xmm0,%xmm5
    17b4:	pmuludq %xmm2,%xmm5
    17b8:	pshufd $0xe8,%xmm5,%xmm5
    17bd:	pshufd $0xf5,%xmm0,%xmm6
    17c2:	pmuludq %xmm2,%xmm6
    17c6:	pshufd $0xe8,%xmm6,%xmm6
    17cb:	punpckldq %xmm6,%xmm5
    17cf:	paddd  %xmm1,%xmm5
    17d3:	pand   %xmm3,%xmm5
    17d7:	packuswb %xmm5,%xmm5
    17db:	packuswb %xmm5,%xmm5
    17df:	movd   %xmm5,(%rbx,%rcx,1)
    17e4:	add    $0x4,%rcx
    17e8:	paddd  %xmm4,%xmm0
    17ec:	cmp    %rcx,%rax
    17ef:	jne    17b0 <packet_xor+0x300>
    17f1:	cmp    %rax,%r14
    17f4:	je     180e <packet_xor+0x35e>
    17f6:	lea    (%rax,%rax,2),%ecx
    17f9:	lea    (%rax,%rcx,4),%ecx
    17fc:	add    %r15d,%ecx
    17ff:	nop
    1800:	mov    %cl,(%rbx,%rax,1)
    1803:	inc    %rax
    1806:	add    $0xd,%cl
    1809:	cmp    %rax,%r14
    180c:	jne    1800 <packet_xor+0x350>
    180e:	mov    $0x1,%edi
    1813:	mov    %r14,%rsi
    1816:	call   1050 <calloc@plt>
    181b:	test   %rax,%rax
    181e:	je     1831 <packet_xor+0x381>
    1820:	xor    $0x5a,%r15d
    1824:	cmp    $0x3,%r14
    1828:	ja     183c <packet_xor+0x38c>
    182a:	xor    %ecx,%ecx
    182c:	jmp    1c14 <packet_xor+0x764>
    1831:	mov    $0x3e9,%r15d
    1837:	jmp    1cd7 <packet_xor+0x827>
    183c:	movd   %r15d,%xmm0
    1841:	cmp    $0x10,%r14
    1845:	jae    1adf <packet_xor+0x62f>
    184b:	xor    %ecx,%ecx
    184d:	jmp    1ba4 <packet_xor+0x6f4>
    1852:	mov    %rax,%rcx
    1855:	lea    (%rcx,%rcx,2),%eax
    1858:	lea    (%rcx,%rax,4),%eax
    185b:	add    %r15d,%eax
    185e:	xchg   %ax,%ax
    1860:	mov    %al,(%rbx,%rcx,1)
    1863:	inc    %rcx
    1866:	add    $0xd,%al
    1868:	cmp    %rcx,%r14
    186b:	jne    1860 <packet_xor+0x3b0>
    186d:	test   %r14,%r14
    1870:	js     1888 <packet_xor+0x3d8>
    1872:	mov    $0x1,%edi
    1877:	mov    %r14,%rsi
    187a:	call   1050 <calloc@plt>
    187f:	test   %rax,%rax
    1882:	je     18a5 <packet_xor+0x3f5>
    1884:	mov    $0x1,%cl
    1886:	jmp    18a9 <packet_xor+0x3f9>
    1888:	xor    %eax,%eax
    188a:	xor    %ecx,%ecx
    188c:	test   $0x1,%cl
    188f:	jne    18c0 <packet_xor+0x410>
    1891:	mov    $0x3e9,%r15d
    1897:	test   %rax,%rax
    189a:	jne    1ccf <packet_xor+0x81f>
    18a0:	jmp    1cd7 <packet_xor+0x827>
    18a5:	xor    %eax,%eax
    18a7:	xor    %ecx,%ecx
    18a9:	movdqa 0x78e(%rip),%xmm11        # 2040 <_fini+0x348>
    18b2:	movdqa 0x795(%rip),%xmm12        # 2050 <_fini+0x358>
    18bb:	test   $0x1,%cl
    18be:	je     1891 <packet_xor+0x3e1>
    18c0:	xor    $0x5a,%r15d
    18c4:	mov    %rax,%rcx
    18c7:	sub    %rbx,%rcx
    18ca:	cmp    $0xf,%rcx
    18ce:	ja     1984 <packet_xor+0x4d4>
    18d4:	xor    %edx,%edx
    18d6:	mov    %r14,%rsi
    18d9:	mov    %rdx,%rcx
    18dc:	and    $0x3,%rsi
    18e0:	je     1907 <packet_xor+0x457>
    18e2:	lea    (%r15,%rdx,1),%edi
    18e6:	mov    %rdx,%rcx
    18e9:	nopl   0x0(%rax)
    18f0:	movzbl (%rbx,%rcx,1),%r8d
    18f5:	xor    %dil,%r8b
    18f8:	mov    %r8b,(%rax,%rcx,1)
    18fc:	inc    %rcx
    18ff:	inc    %dil
    1902:	dec    %rsi
    1905:	jne    18f0 <packet_xor+0x440>
    1907:	sub    %r14,%rdx
    190a:	cmp    $0xfffffffffffffffc,%rdx
    190e:	ja     1aa9 <packet_xor+0x5f9>
    1914:	mov    %rax,%rdx
    1917:	add    $0x3,%rdx
    191b:	mov    %r15d,%esi
    191e:	lea    0x3(%rbx),%rdi
    1922:	mov    %r14,%r8
    1925:	data16 cs nopw 0x0(%rax,%rax,1)
    1930:	lea    (%rcx,%rsi,1),%r9d
    1934:	movzbl -0x3(%rdi,%rcx,1),%r10d
    193a:	xor    %r9b,%r10b
    193d:	mov    %r10b,-0x3(%rdx,%rcx,1)
    1942:	lea    0x1(%r9),%r10d
    1946:	xor    -0x2(%rdi,%rcx,1),%r10b
    194b:	mov    %r10b,-0x2(%rdx,%rcx,1)
    1950:	lea    0x2(%r9),%r10d
    1954:	xor    -0x1(%rdi,%rcx,1),%r10b
    1959:	mov    %r10b,-0x1(%rdx,%rcx,1)
    195e:	add    $0x3,%r9b
    1962:	xor    (%rdi,%rcx,1),%r9b
    1966:	mov    %r9b,(%rdx,%rcx,1)
    196a:	add    $0xfffffffffffffffc,%r8
    196e:	add    $0x4,%rdx
    1972:	add    $0x4,%rsi
    1976:	add    $0x4,%rdi
    197a:	cmp    %r8,%rcx
    197d:	jne    1930 <packet_xor+0x480>
    197f:	jmp    1aa9 <packet_xor+0x5f9>
    1984:	mov    %r14,%rcx
    1987:	and    $0xfffffffffffffff0,%rcx
    198b:	movd   %r15d,%xmm0
    1990:	pshufd $0x0,%xmm0,%xmm0
    1995:	movdqa 0x663(%rip),%xmm1        # 2000 <_fini+0x308>
    199d:	movdqa 0x66b(%rip),%xmm2        # 2010 <_fini+0x318>
    19a5:	movdqa 0x673(%rip),%xmm3        # 2020 <_fini+0x328>
    19ad:	movdqa 0x67b(%rip),%xmm4        # 2030 <_fini+0x338>
    19b5:	xor    %edx,%edx
    19b7:	nopw   0x0(%rax,%rax,1)
    19c0:	movdqu (%rbx,%rdx,1),%xmm5
    19c5:	movdqa %xmm0,%xmm6
    19c9:	paddd  %xmm1,%xmm6
    19cd:	movdqa %xmm0,%xmm7
    19d1:	paddd  %xmm2,%xmm7
    19d5:	movdqa %xmm0,%xmm8
    19da:	paddd  %xmm3,%xmm8
    19df:	movdqa %xmm0,%xmm9
    19e4:	paddd  %xmm4,%xmm9
    19e9:	pand   %xmm11,%xmm9
    19ee:	pand   %xmm11,%xmm8
    19f3:	packuswb %xmm8,%xmm9
    19f8:	pand   %xmm11,%xmm7
    19fd:	pand   %xmm11,%xmm6
    1a02:	packuswb %xmm6,%xmm7
    1a06:	packuswb %xmm7,%xmm9
    1a0b:	pxor   %xmm5,%xmm9
    1a10:	movdqu %xmm9,(%rax,%rdx,1)
    1a16:	add    $0x10,%rdx
    1a1a:	paddd  %xmm12,%xmm4
    1a1f:	paddd  %xmm12,%xmm3
    1a24:	paddd  %xmm12,%xmm2
    1a29:	paddd  %xmm12,%xmm1
    1a2e:	cmp    %rdx,%rcx
    1a31:	jne    19c0 <packet_xor+0x510>
    1a33:	cmp    %rcx,%r14
    1a36:	je     1aa9 <packet_xor+0x5f9>
    1a38:	test   $0xc,%r14b
    1a3c:	je     1ce8 <packet_xor+0x838>
    1a42:	mov    %r14,%rdx
    1a45:	and    $0xfffffffffffffffc,%rdx
    1a49:	movd   %ecx,%xmm1
    1a4d:	pshufd $0x0,%xmm1,%xmm1
    1a52:	por    0x5d6(%rip),%xmm1        # 2030 <_fini+0x338>
    1a5a:	movdqa 0x5fe(%rip),%xmm2        # 2060 <_fini+0x368>
    1a62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1a70:	movd   (%rbx,%rcx,1),%xmm3
    1a75:	movdqa %xmm0,%xmm4
    1a79:	paddd  %xmm1,%xmm4
    1a7d:	pand   %xmm11,%xmm4
    1a82:	packuswb %xmm4,%xmm4
    1a86:	packuswb %xmm4,%xmm4
    1a8a:	pxor   %xmm3,%xmm4
    1a8e:	movd   %xmm4,(%rax,%rcx,1)
    1a93:	add    $0x4,%rcx
    1a97:	paddd  %xmm2,%xmm1
    1a9b:	cmp    %rcx,%rdx
    1a9e:	jne    1a70 <packet_xor+0x5c0>
    1aa0:	cmp    %rdx,%r14
    1aa3:	jne    18d6 <packet_xor+0x426>
    1aa9:	xor    %ecx,%ecx
    1aab:	xor    %r15d,%r15d
    1aae:	xchg   %ax,%ax
    1ab0:	mov    %r15,%rdx
    1ab3:	movzbl (%rax,%rcx,1),%r15d
    1ab8:	add    %rdx,%r15
    1abb:	jb     1cf0 <packet_xor+0x840>
    1ac1:	inc    %rcx
    1ac4:	cmp    %rcx,%r14
    1ac7:	jne    1ab0 <packet_xor+0x600>
    1ac9:	mov    %rax,%rdi
    1acc:	call   1030 <free@plt>
    1ad1:	test   %rbx,%rbx
    1ad4:	jne    1cd7 <packet_xor+0x827>
    1ada:	jmp    1cdf <packet_xor+0x82f>
    1adf:	mov    %r14d,%ecx
    1ae2:	and    $0x30,%ecx
    1ae5:	pshufd $0x0,%xmm0,%xmm1
    1aea:	movdqa 0x50e(%rip),%xmm2        # 2000 <_fini+0x308>
    1af2:	movdqa 0x516(%rip),%xmm3        # 2010 <_fini+0x318>
    1afa:	movdqa 0x51e(%rip),%xmm4        # 2020 <_fini+0x328>
    1b02:	movdqa 0x526(%rip),%xmm5        # 2030 <_fini+0x338>
    1b0a:	xor    %edx,%edx
    1b0c:	movdqa 0x52c(%rip),%xmm6        # 2040 <_fini+0x348>
    1b14:	movdqa 0x534(%rip),%xmm7        # 2050 <_fini+0x358>
    1b1c:	nopl   0x0(%rax)
    1b20:	movdqu (%rbx,%rdx,1),%xmm8
    1b26:	movdqa %xmm1,%xmm9
    1b2b:	paddd  %xmm2,%xmm9
    1b30:	movdqa %xmm1,%xmm10
    1b35:	paddd  %xmm3,%xmm10
    1b3a:	movdqa %xmm1,%xmm11
    1b3f:	paddd  %xmm4,%xmm11
    1b44:	movdqa %xmm1,%xmm12
    1b49:	paddd  %xmm5,%xmm12
    1b4e:	pand   %xmm6,%xmm12
    1b53:	pand   %xmm6,%xmm11
    1b58:	packuswb %xmm11,%xmm12
    1b5d:	pand   %xmm6,%xmm10
    1b62:	pand   %xmm6,%xmm9
    1b67:	packuswb %xmm9,%xmm10
    1b6c:	packuswb %xmm10,%xmm12
    1b71:	pxor   %xmm8,%xmm12
    1b76:	movdqu %xmm12,(%rax,%rdx,1)
    1b7c:	add    $0x10,%rdx
    1b80:	paddd  %xmm7,%xmm5
    1b84:	paddd  %xmm7,%xmm4
    1b88:	paddd  %xmm7,%xmm3
    1b8c:	paddd  %xmm7,%xmm2
    1b90:	cmp    %rdx,%rcx
    1b93:	jne    1b20 <packet_xor+0x670>
    1b95:	cmp    %rcx,%r14
    1b98:	je     1c33 <packet_xor+0x783>
    1b9e:	test   $0xc,%r14b
    1ba2:	je     1c14 <packet_xor+0x764>
    1ba4:	mov    %rcx,%rdx
    1ba7:	mov    %r14d,%ecx
    1baa:	movd   %edx,%xmm1
    1bae:	pshufd $0x0,%xmm1,%xmm1
    1bb3:	por    0x475(%rip),%xmm1        # 2030 <_fini+0x338>
    1bbb:	and    $0x3c,%ecx
    1bbe:	pshufd $0x0,%xmm0,%xmm0
    1bc3:	movdqa 0x475(%rip),%xmm2        # 2040 <_fini+0x348>
    1bcb:	movdqa 0x48d(%rip),%xmm3        # 2060 <_fini+0x368>
    1bd3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1be0:	movd   (%rbx,%rdx,1),%xmm4
    1be5:	movdqa %xmm0,%xmm5
    1be9:	paddd  %xmm1,%xmm5
    1bed:	pand   %xmm2,%xmm5
    1bf1:	packuswb %xmm5,%xmm5
    1bf5:	packuswb %xmm5,%xmm5
    1bf9:	pxor   %xmm4,%xmm5
    1bfd:	movd   %xmm5,(%rax,%rdx,1)
    1c02:	add    $0x4,%rdx
    1c06:	paddd  %xmm3,%xmm1
    1c0a:	cmp    %rdx,%rcx
    1c0d:	jne    1be0 <packet_xor+0x730>
    1c0f:	cmp    %rcx,%r14
    1c12:	je     1c33 <packet_xor+0x783>
    1c14:	mov    %r15d,%edx
    1c17:	nopw   0x0(%rax,%rax,1)
    1c20:	lea    (%rdx,%rcx,1),%esi
    1c23:	xor    (%rbx,%rcx,1),%sil
    1c27:	mov    %sil,(%rax,%rcx,1)
    1c2b:	inc    %rcx
    1c2e:	cmp    %rcx,%r14
    1c31:	jne    1c20 <packet_xor+0x770>
    1c33:	lea    -0x1(%r14),%rdx
    1c37:	mov    %r14d,%ecx
    1c3a:	and    $0x7,%ecx
    1c3d:	cmp    $0x7,%rdx
    1c41:	jae    1c4a <packet_xor+0x79a>
    1c43:	xor    %edx,%edx
    1c45:	xor    %r15d,%r15d
    1c48:	jmp    1caa <packet_xor+0x7fa>
    1c4a:	and    $0x38,%r14d
    1c4e:	xor    %edx,%edx
    1c50:	xor    %r15d,%r15d
    1c53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1c60:	movzbl (%rax,%rdx,1),%esi
    1c64:	add    %r15,%rsi
    1c67:	movzbl 0x1(%rax,%rdx,1),%edi
    1c6c:	movzbl 0x2(%rax,%rdx,1),%r8d
    1c72:	add    %rdi,%r8
    1c75:	add    %rsi,%r8
    1c78:	movzbl 0x3(%rax,%rdx,1),%esi
    1c7d:	movzbl 0x4(%rax,%rdx,1),%edi
    1c82:	add    %rsi,%rdi
    1c85:	movzbl 0x5(%rax,%rdx,1),%esi
    1c8a:	add    %rdi,%rsi
    1c8d:	add    %r8,%rsi
    1c90:	movzbl 0x6(%rax,%rdx,1),%edi
    1c95:	movzbl 0x7(%rax,%rdx,1),%r15d
    1c9b:	add    %rdi,%r15
    1c9e:	add    %rsi,%r15
    1ca1:	add    $0x8,%rdx
    1ca5:	cmp    %rdx,%r14
    1ca8:	jne    1c60 <packet_xor+0x7b0>
    1caa:	test   %rcx,%rcx
    1cad:	je     1ccf <packet_xor+0x81f>
    1caf:	mov    %rax,%rsi
    1cb2:	add    %rdx,%rsi
    1cb5:	xor    %edx,%edx
    1cb7:	nopw   0x0(%rax,%rax,1)
    1cc0:	movzbl (%rsi,%rdx,1),%edi
    1cc4:	add    %rdi,%r15
    1cc7:	inc    %rdx
    1cca:	cmp    %rdx,%rcx
    1ccd:	jne    1cc0 <packet_xor+0x810>
    1ccf:	mov    %rax,%rdi
    1cd2:	call   1030 <free@plt>
    1cd7:	mov    %rbx,%rdi
    1cda:	call   1030 <free@plt>
    1cdf:	mov    %r15,%rax
    1ce2:	pop    %rbx
    1ce3:	pop    %r14
    1ce5:	pop    %r15
    1ce7:	ret
    1ce8:	mov    %rcx,%rdx
    1ceb:	jmp    18d6 <packet_xor+0x426>
    1cf0:	call   1040 <abort@plt>

Disassembly of section .fini:

0000000000001cf8 <_fini>:
    1cf8:	endbr64
    1cfc:	sub    $0x8,%rsp
    1d00:	add    $0x8,%rsp
    1d04:	ret
