"""Independent original/native active exception-context observations."""
from pathlib import Path
import json
import sys
import uuid
from unittest.mock import patch
from tests.test_hia_worker_report_native import Fixture
from hepta import hia_agent_worker as worker
from hepta.hia_worker_report_native import SOURCE
from hashlib import sha256

ROOT = Path('/workspace/scratch/e26ed3e2edcf')
manifest = ROOT / 'worker-report-development-r3/manifest.json'
def tag(exc):
    return None if exc is None else [type(exc).__name__, list(exc.args)]
def run(native, case, ambient):
    f = Fixture()
    observations = []
    def observe(label):
        observations.append([label, tag(sys.exception())])
    if case == 'close-chain':
        f.call_error = KeyboardInterrupt('original-call')
        f.close_error = SystemExit('close-replacement')
        f.on_close = lambda: observe('close')
    else:
        class Error(ValueError):
            @property
            def code(self): observe('code'); return 'OBSERVED'
            def __str__(self): observe('message'); return 'error-message'
            @property
            def retry_action(self): observe('retry'); return 'stop'
        error = Error('original-error')
        if case == 'constructor-handler':
            f.construct_error = error
        elif case == 'entered-handler':
            f.call_error = error
        elif case == 'uncorrelated-handler':
            f.extra_patches.append(patch.object(worker, 'decode_data', side_effect=error))
        def identifier():
            observe('uuid'); return uuid.UUID(int=1)
        f.extra_patches.append(patch.object(worker.uuid, 'uuid4', identifier))
    def invoke():
        result = f.run(manifest if native else None)
        observe('returned-to-caller')
        return result
    if ambient:
        try:
            raise OSError('ambient-caller')
        except OSError:
            result = invoke()
    else:
        result = invoke()
    return {'result': result[:3], 'observations': observations,
            'close_context': tag(f.close_error.__context__) if f.close_error is not None else None,
            'close_context_is_call_error': f.close_error is not None and f.close_error.__context__ is f.call_error}

results = []
for case in ('close-chain', 'constructor-handler', 'entered-handler', 'uncorrelated-handler'):
    for ambient in (False, True):
        before = run(False, case, ambient)
        after = run(True, case, ambient)
        # Keep original byte streams, not a lossy JSON rendition.
        for value in (before, after):
            result, stdout, stderr = value['result']
            value['result'] = {'result': result, 'stdout_hex': stdout.hex(), 'stderr': stderr}
        results.append({'case': case, 'ambient': ambient, 'same': before == after,
                        'retained': before, 'native': after})
record = {'schema': 'hia.worker-active-exception-context-probe.v1', 'source_scope': 'uncommitted isolated context-fix candidate; exact HIA SHA below',
          'policy_sha256': sha256(SOURCE.read_bytes()).hexdigest(), 'manifest': str(manifest),
          'python': sys.version, 'executable': sys.executable, 'results': results}
(ROOT / 'worker-report-context-fixed-r3-observations.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'cases': len(results), 'mismatches': sum(not r['same'] for r in results)}))
