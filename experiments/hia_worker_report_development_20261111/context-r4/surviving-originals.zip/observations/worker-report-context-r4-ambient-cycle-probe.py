"""Exact f9 ordinary-worker control for ambient links changed by foreign callbacks."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from unittest.mock import patch
import uuid

from hepta import hia_agent_worker as worker
from hepta.hia_worker_report_native import SOURCE
from tests.test_hia_worker_report_native import Fixture

ROOT = Path('/workspace/scratch/e26ed3e2edcf')
MANIFEST = ROOT / 'worker-report-development-r3/manifest.json'
CONTEXT = BaseException.__dict__['__context__']


def run(native, mutation, indirect):
    fixture = Fixture()
    observed = []
    ambient = OSError('ambient')
    middle = RuntimeError('middle')
    original = None

    def label(value):
        return ('A' if value is ambient else 'B' if value is middle else
                'E' if value is original else None if value is None else type(value).__name__)

    def mark(stage):
        observed.append({'stage': stage, 'handled': label(sys.exception()),
                         'A_context': label(CONTEXT.__get__(ambient, BaseException)),
                         'B_context': label(CONTEXT.__get__(middle, BaseException)),
                         'E_context': label(CONTEXT.__get__(original, BaseException))})

    def mutate():
        CONTEXT.__set__(ambient, middle if indirect else original)
        if indirect:
            CONTEXT.__set__(middle, original)

    class Error(ValueError):
        @property
        def code(self):
            if mutation == 'code':
                mutate()
            mark('code')
            return 'OBSERVED'

        def __str__(self):
            mark('message')
            return 'original-message'

        @property
        def retry_action(self):
            mark('retry')
            return 'stop'

    original = Error('original')
    fixture.construct_error = original
    fixture.on_output = lambda: mark('output')

    def identifier():
        if mutation == 'uuid':
            mutate()
        mark('uuid')
        return uuid.UUID(int=1)

    fixture.extra_patches.append(patch.object(worker.uuid, 'uuid4', identifier))
    try:
        raise ambient
    except OSError:
        result = fixture.run(MANIFEST if native else None)
        mark('returned')
    answer = {'result': result[0], 'stdout_hex': result[1].hex(), 'stderr': result[2],
              'events': result[3], 'observations': observed}
    for exception in (ambient, middle, original):
        CONTEXT.__set__(exception, None)
    return answer


cases = []
for mutation in ('uuid', 'code'):
    for indirect in (False, True):
        retained = run(False, mutation, indirect)
        native = run(True, mutation, indirect)
        cases.append({'mutation': mutation, 'indirect': indirect,
                      'same': retained == native, 'retained': retained, 'native': native})
record = {'schema': 'hia.worker-ambient-context-chain-probe.v1',
          'source_commit': 'uncommitted f9 descendant; exact adapter SHA below',
          'policy_sha256': sha256(SOURCE.read_bytes()).hexdigest(),
          'adapter_sha256': sha256(Path(worker.__file__).with_name('hia_worker_report_native.py').read_bytes()).hexdigest(),
          'python': sys.version, 'executable': sys.executable,
          'scope': 'DEVELOPMENT_ACTUAL_NATIVE_ORDINARY_WORKER_4_CONTROLS_NOT_COLD_QUALIFICATION',
          'cases': cases}
target = ROOT / 'worker-report-context-r4-ambient-cycle-observations.json'
target.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps({'cases': len(cases), 'mismatches': sum(not case['same'] for case in cases),
                  'record': str(target)}))
