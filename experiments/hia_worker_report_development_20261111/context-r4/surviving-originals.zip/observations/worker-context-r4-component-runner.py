"""Exact complete local development modules; not matching-source cold qualification."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path('/workspace/scratch/e26ed3e2edcf')
SOURCE = ROOT / 'hia-worker-context-fix'
MODULES = ['tests.test_hia_json_wire_native', 'tests.test_hia_worker_report_native']


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.executed = []

    def startTest(self, test):
        self.executed.append(test.id())
        super().startTest(test)


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()


assert git('rev-parse', 'HEAD') == 'b6c36189fb45adcf26c2528346d14021b9873b05'
assert not git('status', '--porcelain')
tracked = ['hepta/hia_worker_report_native.py', 'examples/hia_bootstrap/worker_report.hiaasm',
           'hepta/hia_json_wire_native.py', 'examples/hia_bootstrap/json_wire.hiaasm',
           'tests/test_hia_worker_report_native.py', 'tests/test_hia_json_wire_native.py']
pins = {name: sha256((SOURCE / name).read_bytes()).hexdigest() for name in tracked}
suite = unittest.defaultTestLoader.loadTestsFromNames(MODULES)
loaded = [item.id() for item in flatten(suite)]
start = time.monotonic()
result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2, resultclass=Result).run(suite)
unchanged = all(sha256((SOURCE / name).read_bytes()).hexdigest() == value for name, value in pins.items())
anomalies = {'failures': len(result.failures), 'errors': len(result.errors),
             'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
             'unexpected_successes': len(result.unexpectedSuccesses)}
passed = bool(loaded) and loaded == result.executed and result.testsRun == len(loaded) and not any(anomalies.values()) and unchanged
evidence = {key: os.environ.get(key) for key in ('HEPTA_HIA_JSON_WIRE_FIXTURE_EVIDENCE',
            'HEPTA_HIA_WORKER_REPORT_FIXTURE_EVIDENCE', 'HEPTA_HIA_JSON_WIRE_DEVELOPMENT_MANIFEST',
            'HEPTA_HIA_WORKER_REPORT_DEVELOPMENT_MANIFEST', 'TMPDIR')}
report = {'schema': 'hia.worker-context-local-component-gate.v1', 'status': 'PASS' if passed else 'FAIL',
          'scope': 'EXPLICIT_DEVELOPMENT_ONLY_NOT_MATCHING_SOURCE_COLD',
          'source_commit': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'python': sys.version, 'executable': sys.executable, 'source_pins': pins,
          'pins_unchanged': unchanged, 'modules': MODULES, 'loaded_test_ids': loaded,
          'executed_test_ids': result.executed, 'tests_run': result.testsRun, **anomalies,
          'wall_seconds': time.monotonic() - start, 'evidence_locations': evidence,
          'cold_qualification': False}
target = ROOT / 'worker-context-r4-component-report.json'
target.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'report': str(target), 'status': report['status'], 'tests_run': result.testsRun, **anomalies}))
raise SystemExit(0 if passed else 1)
