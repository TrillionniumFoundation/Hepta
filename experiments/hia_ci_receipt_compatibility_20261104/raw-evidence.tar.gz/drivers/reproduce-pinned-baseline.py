from pathlib import Path
import contextlib,hashlib,json,os,subprocess,time,unittest
cwd=Path('/home/qian-qi/work/hia-ci-receipt-profile-20261104')
out=Path('/home/qian-qi/work/hia-seven-evidence-20261104/ci-receipt-profile/reproduce-pinned-baseline')
out.mkdir(parents=True,exist_ok=False)
os.sched_setaffinity(0,{12,13,14,15})
started=time.monotonic_ns()
class EvidenceResult(unittest.TextTestResult):
 def addError(self,test,err):
  details=getattr(err[1],'build_diagnostics',None)
  if details is not None:
   (out/'BUILD_REJECTION.json').write_text(json.dumps(details,sort_keys=True,indent=2)+'\n')
  super().addError(test,err)
name='tests.test_hia_v6_differential.ExistingV6CoreDifferentialTests.test_pinned_hepta_owned_source_to_single_core_native'
receipt={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'test':name,'python':os.sys.executable,'affinity':sorted(os.sched_getaffinity(0)),'env':{k:os.environ[k] for k in ('RUSTC','CLANG','HEPTA_TEST_CLANG','HIA_TEST_CLANG20','PYTHONDONTWRITEBYTECODE')},'started_unix_ns':time.time_ns()}
with (out/'unittest.stderr.txt').open('w') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=EvidenceResult).run(unittest.defaultTestLoader.loadTestsFromName(name))
receipt.update(wall_ns=time.monotonic_ns()-started,tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),skips=len(result.skipped),success=result.wasSuccessful(),finished_unix_ns=time.time_ns())
(out/'RESULT.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print((out/'unittest.stderr.txt').read_text(),end='')
print(json.dumps(receipt,sort_keys=True),flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
