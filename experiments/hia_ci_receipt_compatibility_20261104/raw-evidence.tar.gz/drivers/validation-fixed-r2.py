from pathlib import Path
import hashlib,json,os,subprocess,time,unittest
from unittest.mock import patch
cwd=Path('/home/qian-qi/work/hia-ci-receipt-profile-20261104')
assert Path.cwd()==cwd
out=Path('/home/qian-qi/work/hia-seven-evidence-20261104/ci-receipt-profile/validation-fixed-r2')
out.mkdir(parents=True,exist_ok=False)
os.sched_setaffinity(0,{12,13,14,15})
started=time.monotonic_ns()
names=['tests.test_hia_v6_differential','tests.test_hia_native_source_reinspect','tests.test_hia_source_bridge','tests.test_hia_entry_layout','tests.test_hia_composition_identity']
source_files=['hepta/hia_source_bridge.py','tests/test_hia_v6_differential.py','tests/test_hia_native_source_reinspect.py','tests/test_hia_composition_identity.py','tools/qualify_hia_composition.py','docs/HIA_SOURCE_RECEIPT_COMPATIBILITY_20261104.md','.github/workflows/hia-full-execution.yml']
before={n:hashlib.sha256((cwd/n).read_bytes()).hexdigest() for n in source_files}
for n in source_files:
 if n.endswith('.py'):compile((cwd/n).read_text(),str(cwd/n),'exec')
diff=subprocess.check_output(['git','diff','--binary'])
(out/'SOURCE.diff').write_bytes(diff)
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
from hepta.hia_source_bridge import build_checked_hepta_hia_native
real_builds=[]
def retained(*args,**kwargs):
 report=build_checked_hepta_hia_native(*args,**kwargs)
 real_builds.append(report)
 (out/'REAL_BUILD_REPORTS.json').write_text(json.dumps(real_builds,sort_keys=True,indent=2)+'\n')
 return report
with (out/'unittest.stderr.txt').open('w') as stream:
 with patch('hepta.hia_source_bridge.build_checked_hepta_hia_native',side_effect=retained):
  result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
after={n:hashlib.sha256((cwd/n).read_bytes()).hexdigest() for n in source_files}
record={'schema':'hepta.ci.receipt.compatibility.validation.v1','source_base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'dirty_source_explicit':True,'source_diff_sha256':hashlib.sha256(diff).hexdigest(),'source_files_before':before,'source_files_after':after,'source_unchanged':before==after,'modules':names,'python':os.sys.executable,'affinity':sorted(os.sched_getaffinity(0)),'environment':{k:os.environ[k] for k in ('RUSTC','HIA_TEST_SOURCE_RUSTC','CLANG','HEPTA_TEST_CLANG','HIA_TEST_CLANG20','PATH','PYTHONDONTWRITEBYTECODE')},'wall_ns':time.monotonic_ns()-started,'tests_run':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),'success':result.wasSuccessful() and not result.skipped and before==after,'finished_unix_ns':time.time_ns(),'real_build_reports':len(real_builds)}
(out/'RESULT.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print((out/'unittest.stderr.txt').read_text(),end='')
print(json.dumps(record,sort_keys=True),flush=True)
raise SystemExit(0 if record['success'] else 1)
