"""Independent actual draft-r2 direct-witness foreign-observation controls."""
from pathlib import Path
from hashlib import sha256
import importlib.util,json,sys,resource
resource.setrlimit(resource.RLIMIT_CPU,(20,20))
resource.setrlimit(resource.RLIMIT_AS,(768<<20,768<<20))
root=Path("/workspace/scratch/e26ed3e2edcf/machine-plan-native-draft")
spec=importlib.util.spec_from_file_location("independent_machine_plan_draft",root/"hia_machine_plan_native.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
from hepta.hia_program import verify_program
from hepta.hia_machine_plan import register_assignment_witness
from tools.qualify_hia_machine_registers import fixture
program,_=fixture();core=verify_program(program)
raw=(root/"development-r2/machine-plan.image.bin").read_bytes()
assert sha256(raw).hexdigest()=="b864bcc1edf88ed1174bd4ade7038aede43c0e20f828b67c9650015eeb140b4d"
native=module.NativeMachinePlan(raw,sha256(raw).hexdigest())
cases=("normal","first-flag-inserts-unknown-function","first-flag-unknown-function-bad-register",
 "first-flag-equivalent-key-subclass","function-lookup-changes-register",
 "function-lookup-introduces-invalid-register","second-flag-changes-register",
 "second-flag-clears-function-map","second-flag-replaces-current-mapping")
def run(case,function):
 mapping={"x":"r12"};assignments={"plus7":mapping};events=[];booleans=[0];hashes=[0]
 class Name(str):
  def __hash__(self):
   hashes[0]+=1;events.append(["name-hash",hashes[0]])
   if hashes[0]==2 and case.startswith("function-lookup-"):
    mapping["x"]="rax" if case=="function-lookup-introduces-invalid-register" else "r15"
   return str.__hash__(self)
  def __eq__(self,other):
   events.append(["name-equality",str(other)]);return str.__eq__(self,other)
 class Flag:
  def __bool__(self):
   booleans[0]+=1;events.append(["bool",booleans[0]])
   if booleans[0]==1:
    if case.startswith("first-flag-unknown") or case=="first-flag-inserts-unknown-function":
     assignments.clear();assignments["missing"]={"x":"rax"} if case.endswith("bad-register") else {}
    if case=="first-flag-equivalent-key-subclass" or case.startswith("function-lookup-"):
     assignments.clear();assignments[Name("plus7")]=mapping
   if booleans[0]==2:
    if case=="second-flag-changes-register":mapping["x"]="r15"
    if case=="second-flag-clears-function-map":assignments.clear()
    if case=="second-flag-replaces-current-mapping":assignments["plus7"]={"x":"r15"}
   return True
 try:
  result=function(core,assignments,allow_leaf_registers=Flag())
  observation={"result":json.loads(json.dumps(result,sort_keys=True))}
 except Exception as error:observation={"exception":type(error).__name__,"message":str(error)}
 return {"observation":observation,"events":list(events)}
rows=[]
for case in cases:
 expected=run(case,register_assignment_witness);actual=run(case,native.witness)
 rows.append({"case":case,"equal":expected==actual,"retained":expected,"native":actual})
report={"schema":"hia.machine-plan-independent-foreign-observation.v1",
 "scope":"Actual draft r2 image, direct public witness API; not plan-route or qualification",
 "source_sha256":sha256((root/"machine_plan.hiaasm").read_bytes()).hexdigest(),
 "generator_sha256":sha256((root/"generate_hia_machine_plan.py").read_bytes()).hexdigest(),
 "adapter_sha256":sha256((root/"hia_machine_plan_native.py").read_bytes()).hexdigest(),
 "retained_owner_sha256":sha256(Path(sys.modules["hepta.hia_machine_plan"].__file__).read_bytes()).hexdigest(),
 "image_sha256":sha256(raw).hexdigest(),"rows":rows,"product_source_modified":False,
 "whole_native_delivery_qualified":False}
assert rows[0]["equal"]
assert rows[1]["retained"]["observation"]=={"exception":"KeyError","message":"'missing'"}
assert rows[1]["native"]["observation"]=={"exception":"RuntimeError","message":"native machine-plan protocol/ABI refusal: 0xfffffffd"}
assert all(r["equal"] for r in rows if r["case"].startswith("second-flag-"))
print(json.dumps(report,indent=2,sort_keys=True))
