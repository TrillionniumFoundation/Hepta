"""Original independent-VM and labelled old-B3 development observations."""
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from generate_hia_machine_plan import document
from hia_machine_plan_native import NativeMachinePlan
from hepta.hia_agent_assembly import render_assembly, assemble_program
from hepta.hia_program import execute_program, verify_program
from hepta.hia_machine_plan import validate_plan, register_assignment_witness
from tools.hia_selfhost_bulk import Body
from tools.qualify_hia_machine_registers import fixture, explicit_plan
from tools.qualify_hia_selfhost import compile_stage

source = render_assembly(document()).encode()
(HERE / 'machine_plan.hiaasm').write_bytes(source)


def vm_kind(kind, expected):
    body = Body(0)
    owners, views = [], []
    for size in (1, 128, 8192):
        owner = body.value('buffer', 'buffer.new', [body.const('usize', size)])
        view = body.value('mutbuf', 'borrow.mut', [owner])
        owners.append(owner)
        views.append(view)
    body.effect('buffer.store', [views[2], body.const('usize', 16), body.const('u8', kind)])
    body.effect('loan.end', [views[0]])
    views[0] = body.value('readbuf', 'borrow.read', [owners[0]])
    result = body.value('u32', 'call', views, {'function': 'f0'})
    for view in views:
        body.effect('loan.end', [view])
    for owner in owners:
        body.effect('owner.drop', [owner])
    text = ('hia-asm.v1 hepta.hia.program.v8 plan_observer\n'
            'fn observe() -> (u32) effects(alloc,read,write,trap) entry(b0)\n'
            'block b0()\n' + body.text() + '  ret(' + result + ')\nend\n' + source.decode().split('\n', 1)[1])
    actual = execute_program(assemble_program(text), 'observe', [], max_steps=3000000)
    assert actual['status'] == 'returned' and actual['result'] == expected, actual
    assert actual['resources']['live_owners'] == actual['resources']['live_local_loans'] == 0
    return actual


output = HERE / 'development-r1'
output.mkdir(exist_ok=False)
vm = [vm_kind(6, 1), vm_kind(7, 0x80000001)]
(output / 'independent-vm-before-image.json').write_text(json.dumps(vm, indent=2, sort_keys=True) + '\n')
print('Independent ordinary Core VM kind/custody controls passed before native image', flush=True)
compiler = Path('/workspace/scratch/e26ed3e2edcf/journal-recovered-development-r1/development-compiler.bin')
assert sha256(compiler.read_bytes()).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
image, receipt = compile_stage(output, 'machine-plan', compiler, source)
(output / 'development-build.json').write_text(json.dumps({
    'scope': 'Development only: current draft source emitted by the retained exact93 B3; not current-source cold qualification',
    'source_sha256': sha256(source).hexdigest(), 'receipt': receipt}, indent=2, sort_keys=True) + '\n')
raw = image.read_bytes()
native = NativeMachinePlan(raw, sha256(raw).hexdigest())
core, placements = fixture()
checked = verify_program(core)
rows = []


def observe(fn):
    try:
        return {'result': fn()}
    except Exception as exc:
        return {'error': type(exc).__name__, 'message': str(exc)}


cases = [None, [], {}, placements, {'plus7': {}}, {'missing': {}}, {'plus7': []},
         {'plus7': {'x': 'r12', 'seven': 'r12'}}, {'plus7': {'x': 'r12', 'answer': 'r12'}},
         {'plus7': {'x': 'r8'}}, {'plus7': {'missing': 'r8'}}, {'plus7': {'missing': 'r12'}},
         {'memory_calls': {'data': 'r8'}}, {'plus7': {'x': []}}, {'plus7': {'x': 'rax'}}]
for leaf in (False, True):
    for index, assignments in enumerate(cases):
        expected = observe(lambda: register_assignment_witness(checked, assignments, allow_leaf_registers=leaf))
        actual = observe(lambda: native.witness(checked, assignments, allow_leaf_registers=leaf))
        rows.append({'kind': 'witness', 'case': index, 'leaf': leaf, 'expected': expected, 'actual': actual})
        if expected != actual:
            (output / 'comparisons.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
            raise AssertionError(rows[-1])
plans = [explicit_plan(checked), explicit_plan(checked, placements)]
for change in ({'schema': 'unknown'}, {'core_sha256': '0' * 64}, {'function_order': []},
               {'function_alignment': True}, {'function_alignment': 17}, {'block_order': {'missing': []}},
               {'block_order': {'plus7': []}}, {'scratch_registers': {'r10': 'r10', 'r11': 'r10'}},
               {'value_registers': {'plus7': {'x': 'r12', 'answer': 'r12'}}}):
    plans.append(dict(explicit_plan(checked), **change))
for index, plan in enumerate(plans):
    expected = observe(lambda: validate_plan(checked, deepcopy(plan)))
    actual = observe(lambda: native.validate(checked, deepcopy(plan), native.witness))
    rows.append({'kind': 'plan', 'case': index, 'expected': expected, 'actual': actual})
    if expected != actual:
        (output / 'comparisons.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
        raise AssertionError(rows[-1])
(output / 'comparisons.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
print(json.dumps({'development_image': str(image), 'source_sha256': sha256(source).hexdigest(),
                  'image_sha256': sha256(raw).hexdigest(), 'matched': len(rows)}), flush=True)
