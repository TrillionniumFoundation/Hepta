import importlib.abc,json,os,sys
from hashlib import sha256
from pathlib import Path
sys.path.insert(0,sys.argv[1])
class NoTools(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='tools' or fullname.startswith('tools.'):
            raise AssertionError('installed machine plan imported authoring tools')
sys.meta_path.insert(0,NoTools())
from hepta import hia_machine_plan as plans
from hepta.hia_machine_plan_native import SOURCE,SELECTOR,installed_machine_plan
from hepta.hia_program import verify_program
from hepta.hia_program_native import emit_program_machine
assert Path(sys.argv[1]) in SOURCE.parents
def forbidden(*args,**kwargs):
    raise AssertionError('retained machine-plan owner entered installed execution')
plans._reference_validate_plan=plans._reference_register_assignment_witness=forbidden
os.environ[SELECTOR]=sys.argv[2]
inputs=json.loads(Path(sys.argv[3]).read_bytes())
core=verify_program(inputs['core'])
plan=plans.validate_plan(core,inputs['plan'])
assert plan==inputs['plan']
assert plans.register_assignment_witness(core,plan['value_registers'])==inputs['witness']
machine=emit_program_machine(core,machine_plan=plan)
assert machine.object_bytes[:4]==b'\x7fELF' and machine.machine_plan_sha256
native=installed_machine_plan(sys.argv[2])
original=SOURCE.read_bytes()
SOURCE.write_bytes(original+b'\n')
try:installed_machine_plan(sys.argv[2])
except ValueError:pass
else:raise AssertionError('warm image hid changed installed source')
SOURCE.write_bytes(original)
SOURCE.unlink()
try:installed_machine_plan(sys.argv[2])
except FileNotFoundError:pass
else:raise AssertionError('missing installed source used checkout fallback')
SOURCE.write_bytes(original)
print(json.dumps({'status':'INSTALLED_NATIVE_MACHINE_PLAN_PASS',
 'image_sha256':native.image_sha256,'source_sha256':sha256(original).hexdigest(),
 'object_sha256':sha256(machine.object_bytes).hexdigest(),
 'isolated_without_site':sys.flags.isolated and sys.flags.no_site,
 'empty_PATH':os.environ['PATH']=='','authoring_forbidden':True,'retained_owners_forbidden':True}))
