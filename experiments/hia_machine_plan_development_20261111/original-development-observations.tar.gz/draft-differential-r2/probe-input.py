"""Reproducible semantic/error-priority and full-size development controls."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from hia_machine_plan_native import NativeMachinePlan
from hepta.hia_machine_plan import validate_plan, register_assignment_witness, MACHINE_V2, MACHINE_V3, MACHINE_V4, LAYOUT_V1
from hepta.hia_program import verify_program
from tools.qualify_hia_machine_registers import fixture, explicit_plan
from tests.test_hia_machine_leaf_registers import scalar_matrix

out = HERE / 'differential-r2'
out.mkdir(exist_ok=False)
(out / 'probe-input.py').write_bytes(Path(__file__).read_bytes())
image = HERE / 'development-r2/machine-plan.image.bin'
raw = image.read_bytes()
native = NativeMachinePlan(raw, sha256(raw).hexdigest())
checks = []
started = time.monotonic()


def observation(fn):
    try:
        return {'result': fn()}
    except Exception as exc:
        return {'error': type(exc).__name__, 'message': str(exc)}


def check(name, expected_fn, actual_fn):
    expected = observation(expected_fn)
    actual = observation(actual_fn)
    row = {'name': name, 'passed': expected == actual,
           'observation_sha256': sha256(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}
    checks.append(row)
    if expected != actual:
        (out / 'first-mismatch.json').write_text(json.dumps({'name': name, 'expected': expected, 'actual': actual}, indent=2) + '\n')
        raise AssertionError(name)


program, placements = fixture()
core = verify_program(program)
rng = random.Random(20261111)
fn_names = [f['name'] for f in program['functions']]
values = {f['name']: [p['name'] for b in f['blocks'] for p in b['params'] + [p for op in b['ops'] for p in op['out']]] for f in program['functions']}
registers = ('rbx', 'r12', 'r13', 'r14', 'r15', 'r8', 'r9', 'rax', '', None, 1, [], {})
for n in range(1500):
    assignment = {}
    for name in rng.sample(fn_names, rng.randrange(1, min(4, len(fn_names)) + 1)):
        candidates = values[name] + ['missing', '', 'x' * 129, '\ud800']
        keys = rng.sample(candidates, rng.randrange(min(6, len(candidates)) + 1))
        assignment[name] = {key: deepcopy(rng.choice(registers)) for key in keys}
    if n % 19 == 0:
        assignment['missing'] = {'x': []}
    leaf = bool(n % 2)
    check('witness-random-' + str(n),
          lambda: register_assignment_witness(core, assignment, allow_leaf_registers=leaf),
          lambda: native.witness(core, assignment, allow_leaf_registers=leaf))

cycle = {}; cycle['x'] = cycle
class StringSubclass(str):
    def __eq__(self, other): raise AssertionError('unexpected equality hook')
    __hash__ = str.__hash__
class DictSubclass(dict):
    def items(self): raise AssertionError('unexpected dictionary hook')
class HugeInt(int):
    def __str__(self): raise AssertionError('unexpected conversion hook')
direct = [[], DictSubclass(), {1: {}}, {StringSubclass('plus7'): {}}, {'plus7': DictSubclass()},
          {'plus7': {StringSubclass('x'): 'r12'}}, {'plus7': {'x': StringSubclass('r12')}},
          {'plus7': cycle}, {'plus7': {'x': HugeInt(1)}}, {'plus7': {'x': 1 << 40000}},
          {'plus7': {'x' * 1000000: 'r8'}}, {'missing': cycle}, {'plus7': {'x': 'r12' + '\ud800' * 1000000}}]
for n, assignment in enumerate(direct):
    for leaf in (False, True):
        check('foreign-kind-' + str(n) + '-' + str(leaf),
              lambda: register_assignment_witness(core, assignment, allow_leaf_registers=leaf),
              lambda: native.witness(core, assignment, allow_leaf_registers=leaf))

changes = [('schema', v) for v in (None, False, 1, '', 'hepta.hia.agent.machine-plan.v9')]
changes += [('core_sha256', v) for v in (None, False, 1, [], {}, '0' * 64)]
changes += [('block_order', v) for v in (None, False, [], {'missing': []}, {'plus7': []}, {'plus7': ['entry', 'entry']}, {'plus7': [1]})]
changes += [('function_order', v) for v in (None, {}, [], fn_names + fn_names[:1], list(reversed(fn_names)), [None] * len(fn_names))]
changes += [('scratch_registers', v) for v in (None, [], {}, {'r10': 'r10', 'r11': 'r10'}, {'r10': 'r11', 'r11': 'r10'})]
changes += [('instruction_selection', v) for v in (None, [], {}, {'move_immediate': 'bad', 'alu_immediate': 'imm32', 'scalar_select': 'branch'},
             {'move_immediate': 'movabs', 'alu_immediate': 'bad', 'scalar_select': 'branch'},
             {'move_immediate': 'movabs', 'alu_immediate': 'imm32', 'scalar_select': 'bad'})]
changes += [('function_alignment', v) for v in (None, True, -1, 0, 1, 16, 32, 64, 128, {}, [], '16')]
changes += [('value_registers', v) for v in (None, [], {}, {'missing': {}}, {'plus7': {'x': 'r8'}}, {'plus7': {'x': 'r12', 'answer': 'r12'}})]
for n in range(600):
    plan = explicit_plan(core)
    for key, value in rng.sample(changes, rng.randrange(1, 5)):
        plan[key] = deepcopy(value)
    if n % 3 == 0:
        plan['schema'] = MACHINE_V4
    if n % 23 == 0:
        plan['extra'] = 0
    check('plan-priority-' + str(n), lambda: validate_plan(core, deepcopy(plan)),
          lambda: native.validate(core, deepcopy(plan), native.witness))

matrix, placements, _ = scalar_matrix()
matrix_core = verify_program(matrix)
check('all-leaf-opcodes', lambda: register_assignment_witness(matrix_core, placements, allow_leaf_registers=True),
      lambda: native.witness(matrix_core, placements, allow_leaf_registers=True))

def fn(name, blocks, entry='entry'):
    return {'name': name, 'params': [], 'returns': [], 'effects': [], 'entry': entry, 'blocks': blocks}

empty_block = {'id': 'entry', 'params': [], 'ops': [], 'term': {'op': 'ret', 'values': []}}
many_functions = {'schema': 'hepta.hia.program.v8', 'module': 'maximum_functions',
                  'functions': [fn('f' + str(i), [deepcopy(empty_block)]) for i in range(1024)]}
many_core = verify_program(many_functions)
plan = explicit_plan(many_core)
plan['function_order'].reverse()
check('1024-functions-reversed', lambda: validate_plan(many_core, plan), lambda: native.validate(many_core, plan, native.witness))

blocks = [{'id': 'b' + str(i), 'params': [], 'ops': [],
           'term': ({'op': 'jump', 'target': 'b' + str(i + 1), 'args': []} if i < 4095 else {'op': 'ret', 'values': []})}
          for i in range(4096)]
many_core = verify_program({'schema': 'hepta.hia.program.v8', 'module': 'maximum_blocks', 'functions': [fn('many', blocks, 'b0')]})
plan = {'schema': LAYOUT_V1, 'core_sha256': many_core.sha256, 'block_order': {'many': [b['id'] for b in reversed(blocks)]}}
check('4096-blocks-reversed', lambda: validate_plan(many_core, plan), lambda: native.validate(many_core, plan, native.witness))
plan['block_order']['many'][-1] = plan['block_order']['many'][0]
check('4096-blocks-duplicate', lambda: validate_plan(many_core, plan), lambda: native.validate(many_core, plan, native.witness))

ops = [{'op': 'const', 'args': [], 'out': [{'name': 'value' + str(i), 'type': 'u64'}], 'attrs': {'value': i}} for i in range(4096)]
many = fn('many', [dict(empty_block, ops=ops)])
many_core = verify_program({'schema': 'hepta.hia.program.v8', 'module': 'many_definitions', 'functions': [many]})
assignment = {'many': {op['out'][0]['name']: 'rbx' for op in reversed(ops)}}
check('4096-dead-writes-ordered-witness', lambda: register_assignment_witness(many_core, assignment),
      lambda: native.witness(many_core, assignment))

report = {'schema': 'hepta.hia.machine-plan-development-differential.v1',
          'scope': 'Current draft source, retained93 B3 development image; not matching-source cold qualification or whole backend proof',
          'source_sha256': sha256((HERE / 'machine_plan.hiaasm').read_bytes()).hexdigest(),
          'image_sha256': sha256(raw).hexdigest(), 'checks': checks, 'all_passed': all(x['passed'] for x in checks),
          'elapsed_seconds': time.monotonic() - started, 'seed': 20261111}
(out / 'observations.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'checks'} | {'checks': len(checks)}), flush=True)
