"""Outer observer for the single frozen integration qualification attempt."""
from pathlib import Path
import hashlib
import json
import os
import platform
import subprocess
import time

ROOT = Path('/home/qian-qi/work/hia-seven-qualified-20261104')
BASE = Path('/home/qian-qi/work/hia-seven-evidence-20261104')
PREFIX = BASE/'composition-r2'
EXPECTED = '98bdbe9f859b5caf95356fbfb1254448d9b583d0'
PYTHON = '/home/qian-qi/work/hia-tools-20261103/venv/bin/python'
LLVM = '/home/qian-qi/work/hia-tools-20261103/clang20/usr/lib/llvm-20/bin/'
RUST = '/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/'
argv = [PYTHON,'-B','tools/qualify_hia_composition.py','--offline',
    '--output',str(PREFIX),'--ndu-source','/home/qian-qi/work/hia-ndu-native-20261103',
    '--ndu-object-source','/home/qian-qi/work/hia-ndu-pin-8e52-object-mirror-r6.git',
    '--cargo-home','/home/qian-qi/.cargo','--clang',LLVM+'clang','--clangxx',LLVM+'clang++',
    '--rustc',RUST+'rustc','--cargo',RUST+'cargo','--cc','/usr/bin/gcc',
    '--lean','/home/qian-qi/work/hia-tools-20261103/lean-4.19.0/bin/lean']


def save(name,value):
    with Path(str(PREFIX)+'.'+name).open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()


original_affinity = sorted(os.sched_getaffinity(0))
chosen = [0,1,2,3]
invocation = {'schema':'hepta.seven.composition-outer.v1','expected_source':EXPECTED,
    'actual_source':git('rev-parse','HEAD'),'actual_tree':git('rev-parse','HEAD^{tree}'),
    'source_status':git('status','--porcelain','--untracked-files=all'),'argv':argv,
    'cwd':str(ROOT),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'platform':platform.platform(),'machine':platform.machine(),
    'original_affinity':original_affinity,'selected_affinity':chosen,
    'exclusive_host':False,'loadavg_before':list(os.getloadavg()),
    'declared_concurrent_work':'independent single-worker proof replay; factorial preparation on CPUs 8-11; no model generation until all composition timing lanes finish',
    'explicit_environment':{'PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':'0'},
    'prior_failed_preparation':'experiments/hia_seven_preparation_20261104',
    'prior_complete_attempt':'composition-r1: core failed its zero-skip gate; every other lane completed',
    'retry_reason':'Bind the already fixed Clang20 binary to the native layout test alias; exactly one source line changed',
    'performance_protocol_or_threshold_changes':False,
    'previous_result_sha256':'f6e95b94e7376e791efcc5636e1f509fc34a0001b1d2c28e97db084ce7f08e58',
    'historical_machine_setup_and_human_cost_ns':None,'unix_ns':time.time_ns()}
save('invocation.json',invocation)
if invocation['actual_source']!=EXPECTED or invocation['source_status']:
    raise ValueError('frozen source identity mismatch')
if not set(chosen).issubset(original_affinity):
    raise ValueError('registered CPU affinity unavailable')
os.sched_setaffinity(0,set(chosen))
entered = time.monotonic_ns()
result = {'returncode':None,'launch_error':None}
try:
    with Path(str(PREFIX)+'.stdout').open('xb') as out,Path(str(PREFIX)+'.stderr').open('xb') as err:
        try:
            process = subprocess.Popen(argv,cwd=ROOT,env={**os.environ,**invocation['explicit_environment']},
                                       stdout=out,stderr=err)
            result['returncode'] = process.wait()
        except OSError as error:
            result['launch_error'] = {'type':type(error).__name__,'message':str(error)}
finally:
    result.update(wall_ns=time.monotonic_ns()-entered,source_after=git('rev-parse','HEAD'),
                  source_status_after=git('status','--porcelain','--untracked-files=all'),
                  loadavg_after=list(os.getloadavg()))
    result['streams'] = {}
    for name in ('stdout','stderr'):
        path=Path(str(PREFIX)+'.'+name);raw=path.read_bytes()
        result['streams'][name]={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    save('outer.json',result)
    os.sched_setaffinity(0,set(original_affinity))
print(json.dumps(result,sort_keys=True),flush=True)
raise SystemExit(result['returncode'] if type(result['returncode']) is int else 1)
