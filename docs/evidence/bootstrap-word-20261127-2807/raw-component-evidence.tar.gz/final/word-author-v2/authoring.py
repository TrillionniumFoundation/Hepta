def service_bootstrap(s: readbuf, o: mutbuf, w: mutbuf) -> u32:
    if length(s) != 128 or length(o) != 96 or length(w) != 192:
        return 4294967293
    if word_load(s, 0) != 3544422264915252040:
        return 4294967293
    if word_load(s, 64) != 0:
        return 4294967293
    if word_load(s, 72) != 0:
        return 4294967293
    if word_load(s, 80) != 0:
        return 4294967293
    if word_load(s, 88) != 0:
        return 4294967293
    if word_load(s, 96) != 0:
        return 4294967293
    if word_load(s, 104) != 0:
        return 4294967293
    if word_load(s, 112) != 0:
        return 4294967293
    if word_load(s, 120) != 0:
        return 4294967293
    event = word_load(s, 8)
    if event == 0:
        return initialize(s, o, w)
    if valid_state(w) == 0:
        return 4294967293
    if word_load(s, 40) != word_load(w, 16) or word_load(s, 48) != word_load(w, 48) or word_load(s, 56) != word_load(w, 56):
        return refuse(o, w)
    if word_load(s, 16) != word_load(w, 32) or word_load(s, 24) != word_load(w, 24):
        return refuse(o, w)
    observed = word_load(s, 32)
    phase = word_load(w, 40)
    port = word_load(w, 24)
    if event == 1:
        if phase != 1 or observed != 0:
            return refuse(o, w)
        word_store(w, 40, 2)
        seal(w)
        return answer(o, w, 0)
    if event == 2:
        if phase != 2:
            return refuse(o, w)
        if boolean_port(port) == 1:
            if observed > 1:
                return refuse(o, w)
        elif observed != 0:
            return refuse(o, w)
        return succeeded(o, w, observed)
    if event == 3:
        if phase != 2 or observed != 0:
            return refuse(o, w)
        word_store(w, 96, 1)
        return raised(o, w)
    if event == 4:
        if port != 0 or observed != 0:
            return refuse(o, w)
        if phase == 6:
            return advance(o, w, 0, 4)
        if phase == 7:
            return advance(o, w, 0, 5)
        if phase == 9 and word_load(w, 16) >= 6:
            return advance(o, w, 0, 10)
        return refuse(o, w)
    if event == 5:
        if phase != 10 or word_load(w, 16) < 6 or observed != 0 or (word_load(w, 96) != 0):
            return refuse(o, w)
        return advance(o, w, 92, 1)
    if event == 6:
        if phase != 10 or word_load(w, 16) < 6 or observed != 0:
            return refuse(o, w)
        word_store(w, 96, 1)
        return advance(o, w, 97, 1)
    if event == 7:
        if phase != 11 or observed != 0 or word_load(w, 96) != 1:
            return refuse(o, w)
        return advance(o, w, port, 1)
    return refuse(o, w)

def initialize(s: readbuf, o: mutbuf, w: mutbuf) -> u32:
    mode = word_load(s, 40)
    if mode < 1 or mode > 7:
        return 4294967293
    if word_load(s, 16) != 0 or word_load(s, 24) != 0 or word_load(s, 32) != 0:
        return 4294967293
    if word_load(s, 48) == 0 and word_load(s, 56) == 0:
        return 4294967293
    if word_load(w, 0) != 0:
        return 4294967293
    if word_load(w, 8) != 0:
        return 4294967293
    if word_load(w, 16) != 0:
        return 4294967293
    if word_load(w, 24) != 0:
        return 4294967293
    if word_load(w, 32) != 0:
        return 4294967293
    if word_load(w, 40) != 0:
        return 4294967293
    if word_load(w, 48) != 0:
        return 4294967293
    if word_load(w, 56) != 0:
        return 4294967293
    if word_load(w, 64) != 0:
        return 4294967293
    if word_load(w, 72) != 0:
        return 4294967293
    if word_load(w, 80) != 0:
        return 4294967293
    if word_load(w, 88) != 0:
        return 4294967293
    if word_load(w, 96) != 0:
        return 4294967293
    if word_load(w, 104) != 0:
        return 4294967293
    if word_load(w, 112) != 0:
        return 4294967293
    if word_load(w, 120) != 0:
        return 4294967293
    if word_load(w, 128) != 0:
        return 4294967293
    if word_load(w, 136) != 0:
        return 4294967293
    if word_load(w, 144) != 0:
        return 4294967293
    if word_load(w, 152) != 0:
        return 4294967293
    if word_load(w, 160) != 0:
        return 4294967293
    if word_load(w, 168) != 0:
        return 4294967293
    if word_load(w, 176) != 0:
        return 4294967293
    if word_load(w, 184) != 0:
        return 4294967293
    word_store(w, 0, 3544404737170494280)
    word_store(w, 8, 1)
    word_store(w, 16, mode)
    word_store(w, 24, initial_port(mode))
    word_store(w, 32, 1)
    word_store(w, 40, 1)
    word_store(w, 48, word_load(s, 48))
    word_store(w, 56, word_load(s, 56))
    seal(w)
    return answer(o, w, 0)

def initial_port(mode: u64) -> u64:
    if mode == 1:
        return 1
    if mode == 2:
        return 45
    if mode == 3:
        return 53
    if mode == 4:
        return 83
    if mode == 5:
        return 87
    if mode == 6:
        return 92
    if mode == 7:
        return 92
    return 0

def owned_port(mode: u64, port: u64) -> u64:
    if mode == 1:
        if port >= 1 and port <= 44:
            return 1
    if mode == 2:
        if port >= 45 and port <= 52:
            return 1
    if mode == 3:
        if port >= 53 and port <= 82:
            return 1
    if mode == 4:
        if port >= 83 and port <= 86:
            return 1
    if mode == 5:
        if port >= 87 and port <= 91:
            return 1
    if mode == 6:
        if port >= 92 and port <= 98:
            return 1
    if mode == 7:
        if port >= 92 and port <= 98:
            return 1
    return 0

def valid_state(w: mutbuf) -> u64:
    if word_load(w, 0) != 3544404737170494280 or word_load(w, 8) != 1:
        return 0
    mode = word_load(w, 16)
    if mode < 1 or mode > 7:
        return 0
    phase = word_load(w, 40)
    port = word_load(w, 24)
    if word_load(w, 32) == 0 or phase == 0 or phase == 3 or (phase > 11):
        return 0
    if word_load(w, 64) != 0 or word_load(w, 72) != 0 or word_load(w, 88) != 0 or (word_load(w, 96) > 1):
        return 0
    if word_load(w, 104) != 0:
        return 0
    if word_load(w, 112) != 0:
        return 0
    if word_load(w, 120) != 0:
        return 0
    if word_load(w, 128) != 0:
        return 0
    if word_load(w, 136) != 0:
        return 0
    if word_load(w, 144) != 0:
        return 0
    if word_load(w, 152) != 0:
        return 0
    if word_load(w, 160) != 0:
        return 0
    if word_load(w, 168) != 0:
        return 0
    if word_load(w, 176) != 0:
        return 0
    if word_load(w, 184) != 0:
        return 0
    if checksum(w) != word_load(w, 80):
        return 0
    if phase == 1 or phase == 2 or phase == 11:
        if owned_port(mode, port) == 0:
            return 0
        if mode == 6 and port == 94:
            return 0
        if mode == 7 and port == 93:
            return 0
    elif port != 0:
        return 0
    if phase == 4 or phase == 6 or phase == 9 or (phase == 10):
        if word_load(w, 96) != 0:
            return 0
    if phase == 5 or phase == 7 or phase == 11:
        if word_load(w, 96) != 1:
            return 0
    if phase == 9 or phase == 10:
        if mode < 6:
            return 0
    return 1

def boolean_port(port: u64) -> u64:
    if port == 7:
        return 1
    if port == 15:
        return 1
    if port == 18:
        return 1
    if port == 22:
        return 1
    if port == 27:
        return 1
    if port == 29:
        return 1
    if port == 33:
        return 1
    if port == 35:
        return 1
    if port == 45:
        return 1
    if port == 59:
        return 1
    if port == 65:
        return 1
    if port == 71:
        return 1
    if port == 92:
        return 1
    return 0

def succeeded(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port <= 12:
        return succeeded_0(o, w, observed)
    if port <= 24:
        return succeeded_1(o, w, observed)
    if port <= 36:
        return succeeded_2(o, w, observed)
    if port <= 48:
        return succeeded_3(o, w, observed)
    if port <= 60:
        return succeeded_4(o, w, observed)
    if port <= 72:
        return succeeded_5(o, w, observed)
    if port <= 84:
        return succeeded_6(o, w, observed)
    if port <= 96:
        return succeeded_7(o, w, observed)
    if port <= 98:
        return succeeded_8(o, w, observed)
    return refuse(o, w)

def succeeded_0(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 1:
        return advance(o, w, 2, 1)
    if port == 2:
        return advance(o, w, 3, 1)
    if port == 3:
        return advance(o, w, 4, 1)
    if port == 4:
        return advance(o, w, 5, 1)
    if port == 5:
        return advance(o, w, 6, 1)
    if port == 6:
        return advance(o, w, 7, 1)
    if port == 7:
        if observed == 0:
            return advance(o, w, 9, 1)
        return advance(o, w, 8, 1)
    if port == 8:
        return advance(o, w, 7, 1)
    if port == 9:
        return advance(o, w, 10, 1)
    if port == 10:
        return advance(o, w, 11, 1)
    if port == 11:
        return advance(o, w, 12, 1)
    if port == 12:
        return advance(o, w, 13, 1)
    return refuse(o, w)

def succeeded_1(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 13:
        return advance(o, w, 14, 1)
    if port == 14:
        return advance(o, w, 15, 1)
    if port == 15:
        if observed == 0:
            return advance(o, w, 17, 1)
        return advance(o, w, 16, 1)
    if port == 16:
        return advance(o, w, 18, 1)
    if port == 17:
        return advance(o, w, 18, 1)
    if port == 18:
        if observed == 0:
            return advance(o, w, 20, 1)
        return advance(o, w, 19, 1)
    if port == 19:
        return advance(o, w, 21, 1)
    if port == 20:
        return advance(o, w, 21, 1)
    if port == 21:
        return advance(o, w, 22, 1)
    if port == 22:
        if observed == 0:
            return advance(o, w, 24, 1)
        return advance(o, w, 23, 1)
    if port == 23:
        return advance(o, w, 24, 1)
    if port == 24:
        return advance(o, w, 25, 1)
    return refuse(o, w)

def succeeded_2(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 25:
        return advance(o, w, 26, 1)
    if port == 26:
        return advance(o, w, 0, 6)
    if port == 27:
        if observed == 0:
            return advance(o, w, 44, 1)
        return advance(o, w, 28, 1)
    if port == 28:
        return advance(o, w, 29, 1)
    if port == 29:
        if observed == 0:
            return advance(o, w, 31, 1)
        return advance(o, w, 30, 1)
    if port == 30:
        return advance(o, w, 32, 1)
    if port == 31:
        return advance(o, w, 32, 1)
    if port == 32:
        return advance(o, w, 33, 1)
    if port == 33:
        if observed == 0:
            return advance(o, w, 39, 1)
        return advance(o, w, 34, 1)
    if port == 34:
        return advance(o, w, 33, 1)
    if port == 35:
        if observed == 0:
            return advance(o, w, 43, 1)
        return advance(o, w, 36, 1)
    if port == 36:
        return advance(o, w, 37, 1)
    return refuse(o, w)

def succeeded_3(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 37:
        return advance(o, w, 38, 11)
    if port == 38:
        return advance(o, w, 33, 1)
    if port == 39:
        return advance(o, w, 40, 1)
    if port == 40:
        return advance(o, w, 41, 1)
    if port == 41:
        return advance(o, w, 0, 7)
    if port == 42:
        return advance(o, w, 43, 1)
    if port == 43:
        return advance(o, w, 44, 1)
    if port == 44:
        return advance(o, w, 0, 7)
    if port == 45:
        if observed == 0:
            return advance(o, w, 47, 1)
        return advance(o, w, 46, 1)
    if port == 46:
        return advance(o, w, 47, 1)
    if port == 47:
        return advance(o, w, 48, 1)
    if port == 48:
        return advance(o, w, 49, 1)
    return refuse(o, w)

def succeeded_4(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 49:
        return advance(o, w, 0, 6)
    if port == 50:
        return advance(o, w, 51, 1)
    if port == 51:
        return advance(o, w, 52, 1)
    if port == 52:
        return advance(o, w, 0, 7)
    if port == 53:
        return advance(o, w, 54, 1)
    if port == 54:
        return advance(o, w, 55, 1)
    if port == 55:
        return advance(o, w, 56, 1)
    if port == 56:
        return advance(o, w, 57, 1)
    if port == 57:
        return advance(o, w, 58, 1)
    if port == 58:
        return advance(o, w, 59, 1)
    if port == 59:
        if observed == 0:
            return advance(o, w, 61, 1)
        return advance(o, w, 60, 1)
    if port == 60:
        return advance(o, w, 59, 1)
    return refuse(o, w)

def succeeded_5(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 61:
        return advance(o, w, 62, 1)
    if port == 62:
        return advance(o, w, 63, 1)
    if port == 63:
        return advance(o, w, 64, 1)
    if port == 64:
        return advance(o, w, 65, 1)
    if port == 65:
        if observed == 0:
            return advance(o, w, 68, 1)
        return advance(o, w, 66, 1)
    if port == 66:
        return advance(o, w, 67, 1)
    if port == 67:
        return advance(o, w, 65, 1)
    if port == 68:
        return advance(o, w, 69, 1)
    if port == 69:
        return advance(o, w, 70, 1)
    if port == 70:
        return advance(o, w, 71, 1)
    if port == 71:
        if observed == 0:
            return advance(o, w, 73, 1)
        return advance(o, w, 72, 1)
    if port == 72:
        return advance(o, w, 71, 1)
    return refuse(o, w)

def succeeded_6(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 73:
        return advance(o, w, 74, 1)
    if port == 74:
        return advance(o, w, 75, 1)
    if port == 75:
        return advance(o, w, 76, 1)
    if port == 76:
        return advance(o, w, 77, 1)
    if port == 77:
        return advance(o, w, 78, 1)
    if port == 78:
        return advance(o, w, 79, 1)
    if port == 79:
        return advance(o, w, 80, 1)
    if port == 80:
        return advance(o, w, 0, 6)
    if port == 81:
        return advance(o, w, 82, 1)
    if port == 82:
        return advance(o, w, 0, 7)
    if port == 83:
        return advance(o, w, 84, 1)
    if port == 84:
        return advance(o, w, 0, 6)
    return refuse(o, w)

def succeeded_7(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 85:
        return advance(o, w, 86, 1)
    if port == 86:
        return advance(o, w, 0, 7)
    if port == 87:
        return advance(o, w, 88, 1)
    if port == 88:
        return advance(o, w, 89, 1)
    if port == 89:
        return advance(o, w, 0, 6)
    if port == 90:
        return advance(o, w, 91, 1)
    if port == 91:
        return advance(o, w, 0, 7)
    if port == 92:
        if observed == 0:
            return advance(o, w, 96, 1)
        if word_load(w, 16) == 6:
            return advance(o, w, 93, 1)
        if word_load(w, 16) == 7:
            return advance(o, w, 94, 1)
        return refuse(o, w)
    if port == 93:
        return advance(o, w, 95, 1)
    if port == 94:
        return advance(o, w, 95, 1)
    if port == 95:
        return advance(o, w, 0, 9)
    if port == 96:
        return advance(o, w, 0, 6)
    return refuse(o, w)

def succeeded_8(o: mutbuf, w: mutbuf, observed: u64) -> u32:
    port = word_load(w, 24)
    if port == 97:
        return advance(o, w, 98, 1)
    if port == 98:
        return advance(o, w, 0, 7)
    return refuse(o, w)

def raised(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port <= 12:
        return raised_0(o, w)
    if port <= 24:
        return raised_1(o, w)
    if port <= 36:
        return raised_2(o, w)
    if port <= 48:
        return raised_3(o, w)
    if port <= 60:
        return raised_4(o, w)
    if port <= 72:
        return raised_5(o, w)
    if port <= 84:
        return raised_6(o, w)
    if port <= 96:
        return raised_7(o, w)
    if port <= 98:
        return raised_8(o, w)
    return refuse(o, w)

def raised_0(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 1:
        return advance(o, w, 44, 1)
    if port == 2:
        return advance(o, w, 44, 1)
    if port == 3:
        return advance(o, w, 44, 1)
    if port == 4:
        return advance(o, w, 44, 1)
    if port == 5:
        return advance(o, w, 44, 1)
    if port == 6:
        return advance(o, w, 44, 1)
    if port == 7:
        return advance(o, w, 44, 1)
    if port == 8:
        return advance(o, w, 44, 1)
    if port == 9:
        return advance(o, w, 44, 1)
    if port == 10:
        return advance(o, w, 44, 1)
    if port == 11:
        return advance(o, w, 44, 1)
    if port == 12:
        return advance(o, w, 44, 1)
    return refuse(o, w)

def raised_1(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 13:
        return advance(o, w, 44, 1)
    if port == 14:
        return advance(o, w, 44, 1)
    if port == 15:
        return advance(o, w, 27, 1)
    if port == 16:
        return advance(o, w, 27, 1)
    if port == 17:
        return advance(o, w, 27, 1)
    if port == 18:
        return advance(o, w, 27, 1)
    if port == 19:
        return advance(o, w, 27, 1)
    if port == 20:
        return advance(o, w, 27, 1)
    if port == 21:
        return advance(o, w, 27, 1)
    if port == 22:
        return advance(o, w, 27, 1)
    if port == 23:
        return advance(o, w, 27, 1)
    if port == 24:
        return advance(o, w, 27, 1)
    return refuse(o, w)

def raised_2(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 25:
        return advance(o, w, 27, 1)
    if port == 26:
        return advance(o, w, 0, 7)
    if port == 27:
        return advance(o, w, 44, 1)
    if port == 28:
        return advance(o, w, 43, 1)
    if port == 29:
        return advance(o, w, 43, 1)
    if port == 30:
        return advance(o, w, 43, 1)
    if port == 31:
        return advance(o, w, 43, 1)
    if port == 32:
        return advance(o, w, 43, 1)
    if port == 33:
        return advance(o, w, 43, 1)
    if port == 34:
        return advance(o, w, 35, 1)
    if port == 35:
        return advance(o, w, 43, 1)
    if port == 36:
        return advance(o, w, 42, 1)
    return refuse(o, w)

def raised_3(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 37:
        return advance(o, w, 42, 1)
    if port == 38:
        return advance(o, w, 43, 1)
    if port == 39:
        return advance(o, w, 43, 1)
    if port == 40:
        return advance(o, w, 43, 1)
    if port == 41:
        return advance(o, w, 0, 7)
    if port == 42:
        return advance(o, w, 0, 7)
    if port == 43:
        return advance(o, w, 0, 7)
    if port == 44:
        return advance(o, w, 0, 7)
    if port == 45:
        return advance(o, w, 50, 1)
    if port == 46:
        return advance(o, w, 50, 1)
    if port == 47:
        return advance(o, w, 51, 1)
    if port == 48:
        return advance(o, w, 51, 1)
    return refuse(o, w)

def raised_4(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 49:
        return advance(o, w, 0, 7)
    if port == 50:
        return advance(o, w, 51, 1)
    if port == 51:
        return advance(o, w, 0, 7)
    if port == 52:
        return advance(o, w, 0, 7)
    if port == 53:
        return advance(o, w, 81, 1)
    if port == 54:
        return advance(o, w, 81, 1)
    if port == 55:
        return advance(o, w, 81, 1)
    if port == 56:
        return advance(o, w, 81, 1)
    if port == 57:
        return advance(o, w, 81, 1)
    if port == 58:
        return advance(o, w, 81, 1)
    if port == 59:
        return advance(o, w, 81, 1)
    if port == 60:
        return advance(o, w, 81, 1)
    return refuse(o, w)

def raised_5(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 61:
        return advance(o, w, 81, 1)
    if port == 62:
        return advance(o, w, 81, 1)
    if port == 63:
        return advance(o, w, 81, 1)
    if port == 64:
        return advance(o, w, 81, 1)
    if port == 65:
        return advance(o, w, 81, 1)
    if port == 66:
        return advance(o, w, 81, 1)
    if port == 67:
        return advance(o, w, 81, 1)
    if port == 68:
        return advance(o, w, 81, 1)
    if port == 69:
        return advance(o, w, 81, 1)
    if port == 70:
        return advance(o, w, 81, 1)
    if port == 71:
        return advance(o, w, 81, 1)
    if port == 72:
        return advance(o, w, 81, 1)
    return refuse(o, w)

def raised_6(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 73:
        return advance(o, w, 81, 1)
    if port == 74:
        return advance(o, w, 81, 1)
    if port == 75:
        return advance(o, w, 81, 1)
    if port == 76:
        return advance(o, w, 81, 1)
    if port == 77:
        return advance(o, w, 81, 1)
    if port == 78:
        return advance(o, w, 81, 1)
    if port == 79:
        return advance(o, w, 81, 1)
    if port == 80:
        return advance(o, w, 0, 7)
    if port == 81:
        return advance(o, w, 0, 7)
    if port == 82:
        return advance(o, w, 0, 7)
    if port == 83:
        return advance(o, w, 85, 1)
    if port == 84:
        return advance(o, w, 0, 7)
    return refuse(o, w)

def raised_7(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 85:
        return advance(o, w, 0, 7)
    if port == 86:
        return advance(o, w, 0, 7)
    if port == 87:
        return advance(o, w, 90, 1)
    if port == 88:
        return advance(o, w, 90, 1)
    if port == 89:
        return advance(o, w, 0, 7)
    if port == 90:
        return advance(o, w, 0, 7)
    if port == 91:
        return advance(o, w, 0, 7)
    if port == 92:
        return advance(o, w, 97, 1)
    if port == 93:
        return advance(o, w, 97, 1)
    if port == 94:
        return advance(o, w, 97, 1)
    if port == 95:
        return advance(o, w, 97, 1)
    if port == 96:
        return advance(o, w, 0, 7)
    return refuse(o, w)

def raised_8(o: mutbuf, w: mutbuf) -> u32:
    port = word_load(w, 24)
    if port == 97:
        return advance(o, w, 0, 7)
    if port == 98:
        return advance(o, w, 0, 7)
    return refuse(o, w)

def advance(o: mutbuf, w: mutbuf, port: u64, phase: u64) -> u32:
    if word_load(w, 32) == 18446744073709551615:
        return refuse(o, w)
    word_store(w, 24, port)
    word_store(w, 32, word_load(w, 32) + 1)
    word_store(w, 40, phase)
    seal(w)
    return answer(o, w, 0)

def refuse(o: mutbuf, w: mutbuf) -> u32:
    word_store(w, 24, 0)
    word_store(w, 40, 8)
    seal(w)
    return answer(o, w, 1)

def answer(o: mutbuf, w: mutbuf, status: u64) -> u32:
    word_store(o, 0, 3544421225533166408)
    word_store(o, 8, status)
    word_store(o, 16, word_load(w, 24))
    word_store(o, 24, word_load(w, 32))
    word_store(o, 32, word_load(w, 40))
    word_store(o, 40, word_load(w, 16))
    word_store(o, 48, word_load(w, 96))
    word_store(o, 56, 0)
    word_store(o, 64, word_load(w, 48))
    word_store(o, 72, word_load(w, 56))
    word_store(o, 80, 0)
    word_store(o, 88, 0)
    return 96

def checksum(w: mutbuf) -> u64:
    value = 1469598103934665603
    value = (value << 7 | value >> 57) ^ word_load(w, 0)
    value = (value << 7 | value >> 57) ^ word_load(w, 8)
    value = (value << 7 | value >> 57) ^ word_load(w, 16)
    value = (value << 7 | value >> 57) ^ word_load(w, 24)
    value = (value << 7 | value >> 57) ^ word_load(w, 32)
    value = (value << 7 | value >> 57) ^ word_load(w, 40)
    value = (value << 7 | value >> 57) ^ word_load(w, 48)
    value = (value << 7 | value >> 57) ^ word_load(w, 56)
    value = (value << 7 | value >> 57) ^ word_load(w, 64)
    value = (value << 7 | value >> 57) ^ word_load(w, 72)
    value = (value << 7 | value >> 57) ^ word_load(w, 88)
    value = (value << 7 | value >> 57) ^ word_load(w, 96)
    value = (value << 7 | value >> 57) ^ word_load(w, 104)
    value = (value << 7 | value >> 57) ^ word_load(w, 112)
    value = (value << 7 | value >> 57) ^ word_load(w, 120)
    value = (value << 7 | value >> 57) ^ word_load(w, 128)
    value = (value << 7 | value >> 57) ^ word_load(w, 136)
    value = (value << 7 | value >> 57) ^ word_load(w, 144)
    value = (value << 7 | value >> 57) ^ word_load(w, 152)
    value = (value << 7 | value >> 57) ^ word_load(w, 160)
    value = (value << 7 | value >> 57) ^ word_load(w, 168)
    value = (value << 7 | value >> 57) ^ word_load(w, 176)
    value = (value << 7 | value >> 57) ^ word_load(w, 184)
    return value

def seal(w: mutbuf) -> u64:
    value = checksum(w)
    word_store(w, 80, value)
    return value

def read_word(s: readbuf, index: u64) -> u64:
    if index <= length(s) and 8 <= length(s) - index:
        return word_load(s, index)
    value = 0
    value = value | byte(s, index + 0) << 0
    value = value | byte(s, index + 1) << 8
    value = value | byte(s, index + 2) << 16
    value = value | byte(s, index + 3) << 24
    value = value | byte(s, index + 4) << 32
    value = value | byte(s, index + 5) << 40
    value = value | byte(s, index + 6) << 48
    value = value | byte(s, index + 7) << 56
    return value

def get(w: mutbuf, index: u64) -> u64:
    at = index * 8
    if at <= length(w) and 8 <= length(w) - at:
        return word_load(w, at)
    value = 0
    value = value | byte(w, index * 8 + 0) << 0
    value = value | byte(w, index * 8 + 1) << 8
    value = value | byte(w, index * 8 + 2) << 16
    value = value | byte(w, index * 8 + 3) << 24
    value = value | byte(w, index * 8 + 4) << 32
    value = value | byte(w, index * 8 + 5) << 40
    value = value | byte(w, index * 8 + 6) << 48
    value = value | byte(w, index * 8 + 7) << 56
    return value

def set(w: mutbuf, index: u64, value: u64) -> u64:
    at = index * 8
    if at <= length(w) and 8 <= length(w) - at:
        word_store(w, at, value)
        return value
    store(w, index * 8 + 0, value >> 0)
    store(w, index * 8 + 1, value >> 8)
    store(w, index * 8 + 2, value >> 16)
    store(w, index * 8 + 3, value >> 24)
    store(w, index * 8 + 4, value >> 32)
    store(w, index * 8 + 5, value >> 40)
    store(w, index * 8 + 6, value >> 48)
    store(w, index * 8 + 7, value >> 56)
    return value
