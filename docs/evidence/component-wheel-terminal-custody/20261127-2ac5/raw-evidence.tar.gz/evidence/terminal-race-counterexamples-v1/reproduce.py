import hashlib,json,os,pathlib,subprocess,sys,time
from unittest.mock import patch
root=pathlib.Path('/home/qian-qi/hia-component-wheel-custody-20261127-2ac5');src=root/'source'
sys.path.insert(0,str(src))
from tests import hia_component_install_fixture as f
assert subprocess.check_output(['/usr/bin/git','-C',str(src),'rev-parse','HEAD'],text=True).strip()=='0b62b7a5ea1c4710373210f92ee78eda5b78458d'
assert subprocess.check_output(['/usr/bin/git','-C',str(src),'status','--porcelain'],text=True)==''
out=root/'evidence/terminal-race-counterexamples-v1';out.mkdir(mode=0o700)
stage=root/'tmp/hia-component-install-controls-_h8b5t8c/source'
result={'source_head':'0b62b7a5ea1c4710373210f92ee78eda5b78458d','scope':'actual component build/install with deterministic physical mutation at post-validation boundary','whole_native_delivery_qualified':False,'cases':[]}
def save():(out/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
beg=time.monotonic();component=f.component_wheel(stage)
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
def run(label,args):
 with (out/(label+'.stdout')).open('wb') as so,(out/(label+'.stderr')).open('wb') as se:
  r=subprocess.run([sys.executable,'-B',*map(str,args)],cwd=out,env=env,stdout=so,stderr=se,timeout=60)
 assert r.returncode==0,label
run('wheel',['-m','pip','wheel','--no-deps','--no-build-isolation','--no-index','--wheel-dir',out/'wheels',component])
wheel,=(out/'wheels').glob('*.whl');installed=out/'installed'
run('install',['-m','pip','install','--no-deps','--no-index','--no-compile','--target',installed,wheel])
result['positive_before']=f.verify_component_install(component,installed,installed_from=wheel);save()
item=f._built[str(component)]
custody=item['custody_path'];original_custody=custody.read_bytes()
saved_installed=f._verify_installed
def mutate_custody(*args):
 value=saved_installed(*args)
 custody.chmod(0o600);custody.write_bytes(original_custody+b' ')
 return value
try:
 with patch.object(f,'_verify_installed',side_effect=mutate_custody):
  returned=f.verify_component_install(component,installed,installed_from=wheel)
 altered=custody.read_bytes()
 result['cases'].append({'name':'installed-terminal-sidecar','vulnerable_returned':returned['component_install_verified'] is True,'physical_changed':altered!=original_custody,'original_sha256':hashlib.sha256(original_custody).hexdigest(),'changed_sha256':hashlib.sha256(altered).hexdigest(),'returned':returned})
 import gzip
 (out/'mutated-custody.json.gz').write_bytes(gzip.compress(altered,mtime=0));save()
finally:
 custody.write_bytes(original_custody);custody.chmod(0o400)
saved_checked=f._checked_wheel
for label,path in [('cached-partial-stage',stage/'hepta/hia_evaluation_native.py'),('cached-git-source',src/'hepta/hia_evaluation_native.py')]:
 original=path.read_bytes()
 def mutate_after_checked(*args):
  value=saved_checked(*args);path.write_bytes(original+b'\n# late controlled qualification mutation\n');return value
 try:
  with patch.object(f,'_checked_wheel',side_effect=mutate_after_checked):
   returned=f.component_wheel(stage)
  changed=path.read_bytes()
  result['cases'].append({'name':label,'vulnerable_returned':returned==component,'physical_changed':changed!=original,'original_sha256':hashlib.sha256(original).hexdigest(),'changed_sha256':hashlib.sha256(changed).hexdigest(),'path':str(path)})
  save()
 finally:path.write_bytes(original)
result['positive_after_restore']=f.verify_component_install(component,installed,installed_from=wheel)
result['worktree_status_after']=subprocess.check_output(['/usr/bin/git','-C',str(src),'status','--porcelain'],text=True)
result['elapsed_seconds']=time.monotonic()-beg
result['all_three_counterexamples_reproduced']=len(result['cases'])==3 and all(x['vulnerable_returned'] and x['physical_changed'] for x in result['cases'])
save();print(json.dumps(result),flush=True)
assert result['all_three_counterexamples_reproduced'] and result['worktree_status_after']==''
