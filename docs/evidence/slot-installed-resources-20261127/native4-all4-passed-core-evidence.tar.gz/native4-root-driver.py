CONFIG_B64="eyJjbGVhcl9lbnZpcm9ubWVudCI6WyJDUFAiLCJDUEFUSCIsIkNfSU5DTFVERV9QQVRIIiwiQ1BMVVNfSU5DTFVERV9QQVRIIiwiTElCUkFSWV9QQVRIIiwiTERfUFJFTE9BRCIsIl9QWVRIT05fU1lTQ09ORklHREFUQV9OQU1FIiwiX1BZVEhPTl9TWVNDT05GSUdEQVRBX1BBVEgiLCJfUFlUSE9OX1BST0pFQ1RfQkFTRSIsIl9QWVRIT05fSE9TVF9QTEFURk9STSJdLCJjb21wb3NpdGlvbl9yZWFkYmFjayI6Ii9ob21lL3FpYW4tcWkvaGlhLXNsb3Qtc25hcHNob3QtMjAyNjExMjctMmFjNS9uYXRpdmU0LWNlZTAzZS12MS9zb3VyY2UvUkVBREJBQ0suanNvbiIsImNvbXBvc2l0aW9uX3JlYWRiYWNrX3BpbiI6eyJieXRlcyI6MzE1Nywic2hhMjU2IjoiOTgwMmMyZjI1NmU5N2FlNmFkYmQ2MzNkZTM1M2NiNDhkMjI3ZWJiNWExMTA1M2VmMTc4MjViYjhhNTQ4MDRjYiJ9LCJjb21wb3NpdGlvbl90ZXJtaW5hbCI6Ii9ob21lL3FpYW4tcWkvaGlhLXNsb3Qtc25hcHNob3QtMjAyNjExMjctMmFjNS9uYXRpdmU0LWNlZTAzZS12MS9zb3VyY2Utcm9vdC10ZXJtaW5hbC5qc29uIiwiY29tcG9zaXRpb25fdGVybWluYWxfcGluIjp7ImJ5dGVzIjoxMTExLCJzaGEyNTYiOiJmMWExZjg5NGVlOTdhYTU2OWM5NTQwZjI1YjRiZDg1Y2U2Nzc1NmUyY2E4MmJiYzY1ZTZhMTFmMDkwMjgxMGVlIn0sImRldmVsb3BtZW50X2NvbXBpbGVyIjoiL2hvbWUvcWlhbi1xaS9oaWEtbmF0aXZlLWN1cnJlbnQtMjAyNjExMjctMDg2Mi9maW5hbC1mLW5hdGl2ZS1jaGFpbi12MS9xdWFsaWZpY2F0aW9uL2NvbGQvcXVhbGlmaWNhdGlvbi9iYXNlL0IxLmZsYXQiLCJkZXZlbG9wbWVudF9jb21waWxlcl9waW4iOnsiYnl0ZXMiOjY0MTM0NCwic2hhMjU2IjoiYWNiNjQ3OGQxYTQ2NmQxNzIxMDYxMWM1ZmNiYmQ1YWVlYzMxMDliMDgxM2U5MTdmMGJiNWM4NDE5ZjNjMzNhOSJ9LCJkZXZlbG9wbWVudF9vcmlnaW5fZmlsZXMiOnt9LCJlbnZpcm9ubWVudF9hZGRpdGlvbnMiOnsiQ0MiOiIvdXNyL2Jpbi9jbGFuZy0yMCIsIkhFUFRBX0hJQV9TTE9UX09QRVJBVElPTlNfREVWRUxPUE1FTlRfQ09NUElMRVIiOiIvaG9tZS9xaWFuLXFpL2hpYS1uYXRpdmUtY3VycmVudC0yMDI2MTEyNy0wODYyL2ZpbmFsLWYtbmF0aXZlLWNoYWluLXYxL3F1YWxpZmljYXRpb24vY29sZC9xdWFsaWZpY2F0aW9uL2Jhc2UvQjEuZmxhdCIsIkhFUFRBX0hJQV9TTE9UX09QRVJBVElPTlNfRVZJREVOQ0UiOiIvaG9tZS9xaWFuLXFpL2hpYS1zbG90LXNuYXBzaG90LTIwMjYxMTI3LTJhYzUvbmF0aXZlNC1jZWUwM2UtdjEvc3VpdGUvY29tcG9uZW50IiwiTERTSEFSRUQiOiIvdXNyL2Jpbi9jbGFuZy0yMCAtc2hhcmVkIiwiUEFUSCI6Ii9ob21lL3FpYW4tcWkvLmNhcmdvL2JpbjovaG9tZS9xaWFuLXFpLy5sb2NhbC9iaW46L3Vzci9sb2NhbC9zYmluOi91c3IvbG9jYWwvYmluOi91c3Ivc2JpbjovdXNyL2Jpbjovc2JpbjovYmluOi91c3IvZ2FtZXM6L3Vzci9sb2NhbC9nYW1lczovc25hcC9iaW46L3NuYXAvYmluIiwiUFlUSE9ORE9OVFdSSVRFQllURUNPREUiOiIxIn0sImV4cGVjdGVkIjpbInRlc3RzLnRlc3RfaGlhX3Nsb3RfbWVjaGFuaWNhbF9uYXRpdmUuU2xvdE1lY2hhbmljYWxWNU5hdGl2ZVRlc3RzLnRlc3RfMDBfZnVsbF9vcmlnaW5hbDI0OF9kZXJpdmVkNzU3NF9vcmlnaW5hbF9maXJzdF9uYXRpdmVfdjUiLCJ0ZXN0cy50ZXN0X2hpYV9zbG90X21lY2hhbmljYWxfbmF0aXZlLlNsb3RNZWNoYW5pY2FsVjVOYXRpdmVUZXN0cy50ZXN0XzAxX2Z1bGxfcHVibGljODRfaGFuZGxlZDEyX29yaWdpbmFsX2ZpcnN0X25hdGl2ZV92NSIsInRlc3RzLnRlc3RfaGlhX3Nsb3RfbWVjaGFuaWNhbF9uYXRpdmUuU2xvdE1lY2hhbmljYWxWNU5hdGl2ZVRlc3RzLnRlc3RfMDJfY29tcGxldGVfYWN0dWFsX2FkbWlzc2lvbl9hbmRfc2VhbGVkX2xvYWRlcl9jb250cm9scyIsInRlc3RzLnRlc3RfaGlhX3Nsb3RfbWVjaGFuaWNhbF9uYXRpdmUuU2xvdE1lY2hhbmljYWxWNU5hdGl2ZVRlc3RzLnRlc3RfMDNfYWN0dWFsX3doZWVsX29yaWdpbmFsX3dvcmtlcl92NV9zb3VyY2VfYW5kX3Vua25vd25fcmVwbGF5Il0sImZyZWV6ZSI6Ii9ob21lL3FpYW4tcWkvaGlhLXNsb3Qtc25hcHNob3QtMjAyNjExMjctMmFjNS9uYXRpdmU0LWNlZTAzZS12MS9zb3VyY2UvRlJPWkVOLVNPVVJDRVMuanNvbiIsImZyZWV6ZV9waW4iOnsiYnl0ZXMiOjEwMDc0OTgsInNoYTI1NiI6IjM5NjllMWVkMzY2ZWQzNzEwNTNjNmVkOGUyMjE3MTkwOTUyM2I5MWMyZThmNGE0MmI2Yjg1ZWFjM2RiNWIzNDEifSwibGFiZWwiOiJzdWl0ZSIsInJlYWRiYWNrcyI6W10sInJlcG8iOiIvaG9tZS9xaWFuLXFpL2hpYS1zbG90LXNuYXBzaG90LTIwMjYxMTI3LTJhYzUvY29tbWl0dGVkLWNlZTAzZSIsInJvb3QiOiIvaG9tZS9xaWFuLXFpL2hpYS1zbG90LXNuYXBzaG90LTIwMjYxMTI3LTJhYzUvbmF0aXZlNC1jZWUwM2UtdjEiLCJzY29wZSI6IkNPTVBMRVRFX09SSUdJTkFMX1NMT1RfVjVfTkFUSVZFNF9BTEw3ODIyX1BVQkxJQzg0X0hBTkRMRUQxMl9BRE1JU1NJT04yNV9JTlNUQUxMRURfRVhQTElDSVRfT1dORURfQ0kiLCJzZWxlY3RvcnMiOlsidGVzdHMudGVzdF9oaWFfc2xvdF9tZWNoYW5pY2FsX25hdGl2ZS5TbG90TWVjaGFuaWNhbFY1TmF0aXZlVGVzdHMiXSwidHJlZSI6ImRmNDI0NWU2MDZkZmU1YjYyYTlkMzAzODQ4NDNkNTgyNzcxNDZiYmMifQ=="
import base64,hashlib,json,os,runpy,signal,sys,threading,time,traceback
from pathlib import Path
C=json.loads(base64.b64decode(CONFIG_B64,validate=True))
ROOT=Path(C['root']);REPO=Path(C['repo']);E=ROOT/C['label']
BEGIN=time.monotonic()
def pin(path):
 raw=Path(path).read_bytes()
 return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def write(path,value):
 with Path(path).open('x') as stream:stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n')
freeze_raw=Path(C['freeze']).read_bytes()
assert {'bytes':len(freeze_raw),'sha256':hashlib.sha256(freeze_raw).hexdigest()}==C['freeze_pin']
frozen=json.loads(freeze_raw)
assert frozen['index_tree']==C['tree']
def check():
 return (Path(C['freeze']).read_bytes()==freeze_raw
  and all(Path(path).read_bytes()==raw for path,raw in authority_raw.items())
  and all(pin(REPO/name)==value for name,value in frozen['files'].items()))
authority_raw={}
for key in ('composition_readback','composition_terminal'):
 raw=Path(C[key]).read_bytes()
 assert {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}==C[key+'_pin'],key
 authority_raw[C[key]]=raw
composition=json.loads(authority_raw[C['composition_readback']])
terminal=json.loads(authority_raw[C['composition_terminal']])
assert check()
assert composition['status']=='SOURCE_FROZEN_NOT_QUALIFIED' and composition['index_tree']==C['tree']
assert terminal['returncode']==0 and terminal['observed_owned_group_gone'] and terminal['leader_reaped']
if C.get('development_compiler'):assert pin(C['development_compiler'])==C['development_compiler_pin']
assert all(pin(path)==value for path,value in C['development_origin_files'].items())
E.mkdir(mode=0o700)
sys.path.insert(0,str(REPO))
from tests.hia_slot_operations_qualification_support import group_members
assert not group_members(terminal['pid'])
for child in composition['children']:
 assert child['returncode']==0 and not child['timed_out'] and not child['signals'] and not child['remaining_owned_members']
 assert not group_members(child['command']['pid'])
import ast,re
for key in list(os.environ):
 if key.startswith(('PYTHON','HEPTA_HIA')) or key in C['clear_environment']:del os.environ[key]
os.environ.update(C['environment_additions'])
actual_ids=[]
for selector in C['selectors']:
 module_path=REPO/(selector.replace('.','/')+'.py')
 if module_path.is_file():
  module=selector;tree=ast.parse(module_path.read_bytes())
  assert not any(isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name=='load_tests' for node in tree.body)
  classes=sorted((node for node in tree.body if isinstance(node,ast.ClassDef)
   and any(isinstance(method,ast.FunctionDef) and method.name.startswith('test_') for method in node.body)),key=lambda node:node.name)
 else:
  module,classname=selector.rsplit('.',1)
  module_path=REPO/(module.replace('.','/')+'.py');tree=ast.parse(module_path.read_bytes())
  classes=[next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name==classname)]
 for cls in classes:
  actual_ids.extend(module+'.'+cls.name+'.'+name for name in sorted(node.name for node in cls.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')))
assert actual_ids==C['expected']
component=E/'component'
assert not component.exists()
command=[sys.executable,'-I','-B',str(REPO/'tools/run_hia_unittest_gate.py'),*C['selectors']]
write(E/'plan.json',{'schema':'hepta.root.complete-reviewed-component-suite-plan.v1',
 'command':command,'complete_ordered_ids':C['expected'],'source_freeze':C['freeze_pin'],'index_tree':C['tree'],
 'original_complete_suite_timeout_seconds':1800,'root_cleanup_seconds':5,
 'original_source_controls_seconds':180,'original_installed_command_seconds':60,'original_inner_cleanup_seconds':3,
 'scope':C['scope'],'environment':C['environment_additions'],'root_pid':os.getpid(),'runtime':sys.version,
 'all_original_IDs_inputs_and_limits_preserved':True})
class DescendantMonitor:
 def __init__(self):
  self.stop_event=threading.Event();self.records={};self.errors=[];self.groups={}
  table=self.snapshot();root=table[os.getpid()]
  self.records[root['pid']]=root
  self.thread=threading.Thread(target=self.work,daemon=True)
 def snapshot(self):
  rows={}
  for path in Path('/proc').iterdir():
   if not path.name.isdecimal():continue
   try:
    value=(path/'stat').read_text();fields=value[value.rfind(')')+2:].split()
    pid=int(path.name)
    rows[pid]={'pid':pid,'parent_pid':int(fields[1]),'pgid':int(fields[2]),'sid':int(fields[3]),'start_ticks':int(fields[19]),'state':fields[0]}
   except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  return rows
 def scan(self):
  rows=self.snapshot()
  active={pid for pid,item in self.records.items() if pid in rows and rows[pid]['start_ticks']==item['start_ticks']}
  changed=True
  while changed:
   changed=False
   for pid,item in rows.items():
    if pid not in active and item['parent_pid'] in active:
     if pid in self.records and self.records[pid]['start_ticks']!=item['start_ticks']:
      self.errors.append({'pid_reuse':pid});continue
     active.add(pid);self.records[pid]=item;changed=True
     if item['pgid']==item['sid'] and item['pgid']!=os.getpgrp():
      self.groups.setdefault(item['pgid'],{})[pid]=item['start_ticks']
 def work(self):
  while not self.stop_event.wait(.05):
   try:self.scan()
   except BaseException as error:
    self.errors.append({'type':type(error).__name__,'message':str(error)});return
 def start(self):
  self.scan();self.thread.start()
 def stop(self):
  self.stop_event.set();self.thread.join(timeout=1)
  if self.thread.is_alive():self.errors.append({'monitor_thread':'failed to stop'})
  self.scan()

monitor=DescendantMonitor();monitor.start()
failure=None;residual=[];commands=[];command_errors=[];owned=None;readers=[];captured={}
def capture(path):
 raw=Path(path).read_bytes()
 if str(path) in captured:assert captured[str(path)]==raw
 captured[str(path)]=raw
 return json.loads(raw)
try:
 from tests.hia_slot_operations_qualification_support import run_owned,successful_exit
 owned=run_owned(command,cwd=REPO,directory=E/'suite-owned',timeout_seconds=1800,environment=dict(os.environ))
 assert successful_exit(owned),'complete original class did not naturally pass'
 for spec in C['readbacks']:
  destination=E/'independent-readback'/spec['mode']
  destination.mkdir(mode=0o700,parents=True,exist_ok=False)
  evidence=component/spec['relative_evidence']
  receipt=evidence/spec['receipt']
  receipt_value=capture(receipt);receipt_pin=pin(receipt)
  original_reader=capture(component/spec['class_reader'])
  assert original_reader['status']=='PASS'
  argv=[sys.executable,'-I','-B',str(REPO/'tools/read_hia_worker_unknown.py'),
   '--mode',spec['mode'],'--evidence',str(evidence),
   '--expected-receipt-bytes',str(receipt_pin['bytes']),
   '--expected-receipt-sha256',receipt_pin['sha256'],'--output',str(destination/'readback.json')]
  result=run_owned(argv,cwd=REPO,directory=destination/'owned',timeout_seconds=1800,environment=dict(os.environ))
  assert successful_exit(result),'independent original worker reader did not naturally pass'
  value=capture(destination/'readback.json')
  assert value['status']=='PASS'
  if 'count' in spec:assert value['count']==spec['count']
  if 'commands' in spec:assert value['commands']==spec['commands']
  assert value==original_reader
  assert receipt.read_bytes()==captured[str(receipt)]
  readers.append({'mode':spec['mode'],'authority':receipt_pin,'report':pin(destination/'readback.json'),'result':result})
except BaseException as error:
 failure={'type':type(error).__module__+'.'+type(error).__qualname__,'message':str(error),'traceback':traceback.format_exc()}
 traceback.print_exc()
finally:
 monitor.stop()
 write(E/'observed-descendants.json',{'schema':'hepta.root.observed-descendants.v1',
  'root_pid':os.getpid(),'records':list(monitor.records.values()),'errors':monitor.errors,
  'poll_seconds':.05,'scope':'observed actual descendants only; no claim about unobserved processes'})
 command_errors.extend(monitor.errors)
 for pgid in sorted(monitor.groups):
  members=group_members(pgid)
  row={'pgid':pgid,'remaining_before':members,'signals':[]}
  if members:
   initial=monitor.groups[pgid]
   matches=[item for item in members if initial.get(item['pid'])==item['start_ticks']]
   mismatches=[item for item in members if item['pid'] in initial and initial[item['pid']]!=item['start_ticks']]
   if not matches or mismatches:row['cleanup_refused']='no unchanged independently observed process identity'
   else:
    for sig in (signal.SIGTERM,signal.SIGKILL):
     if not group_members(pgid):break
     try:os.killpg(pgid,sig);row['signals'].append(signal.Signals(sig).name)
     except ProcessLookupError:pass
     deadline=time.monotonic()+2.5
     while time.monotonic()<deadline and group_members(pgid):time.sleep(.025)
   row['remaining_after']=group_members(pgid);residual.append(row)
  commands.append(row)
 log_path=E/'suite-owned/stderr.log'
 log_raw=log_path.read_bytes() if log_path.exists() else b''
 if log_path.exists():captured[str(log_path)]=log_raw
 log=log_raw.decode('utf-8')
 stopped=[]
 for line in log.splitlines():
  match=re.fullmatch(r'(test_[A-Za-z0-9_]+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR|skipped.*|expected failure|unexpected success)',line)
  if match:stopped.append({'id':match.group(2),'status':match.group(3)})
 counts=re.findall(r'^Ran ([0-9]+) tests? in [0-9.]+s$',log,re.MULTILINE)
 complete=([item['id'] for item in stopped]==C['expected'] and len(counts)==1 and int(counts[0])==len(C['expected']))
 stable=check()
 if C.get('development_compiler'):stable=stable and pin(C['development_compiler'])==C['development_compiler_pin']
 stable=stable and all(pin(path)==value for path,value in C['development_origin_files'].items())
 passed=(failure is None and owned is not None and successful_exit(owned) and complete
  and all(item['status']=='ok' for item in stopped) and len(readers)==len(C['readbacks'])
  and stable and not residual and not command_errors
  and all(Path(path).read_bytes()==raw for path,raw in captured.items()))
 summary={'schema':'hepta.root.complete-reviewed-component-suite-readback.v1','status':'PASS' if passed else 'HOLD',
  'scope':C['scope'],'supervisor_failure':failure,'source_freeze':C['freeze_pin'],'index_tree':C['tree'],
  'source_stable':stable,'source_file_count':len(frozen['files']),'planned':len(C['expected']),
  'expected':C['expected'],'observed_method_terminals':stopped,'complete_ordered_ids':complete,
  'actual_suite_result':owned,'independent_readbacks':readers,
  'stdout':pin(E/'suite-owned/stdout.log') if (E/'suite-owned/stdout.log').exists() else None,
  'stderr':pin(log_path) if log_path.exists() else None,'observed_owned_groups':commands,
  'residual_owned_groups':residual,'command_errors':command_errors,
  'original_suite_timeout_seconds':1800,'original_source_child_seconds':180,
  'original_installed_command_seconds':60,'original_inner_cleanup_seconds':3,
  'development_compiler':C['development_compiler_pin'],'development_origin_files':C['development_origin_files'],
  'matching_source_cold_qualified':False,'construction_scope':'EXPLICIT_DEVELOPMENT_FROM_INCOMPLETE_CURRENT_SOURCE_COLD',
  'whole_native_delivery_qualified':False,'old_stack_can_be_removed':False,
  'production_activated':False,'wall_seconds':time.monotonic()-BEGIN}
 write(E/'READBACK.json',summary)
 print('COMPLETE_COMPONENT_SUITE',C['label'],summary['status'],len(stopped),flush=True)
raise SystemExit(0 if passed else 1)
