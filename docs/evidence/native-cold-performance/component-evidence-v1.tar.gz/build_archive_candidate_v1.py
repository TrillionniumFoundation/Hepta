"""Construct the complete archive ELF using actual independent native roots."""
from pathlib import Path
import hashlib, json, struct, sys
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'perf-native-source-v2'
sys.path.insert(0, str(ROOT))
from tools.hia_native_seed_test_support import NativeSeeds
from tools.generate_hia_cold_master_common import template

OUT = HERE / 'native-archive-current-build-v1'
seeds = NativeSeeds(ROOT, HERE / 'published-f-bootstrap/files', OUT)
report = {'scope': 'actual native archive component construction; qualification separate', 'passed': False}
try:
    raw = (ROOT / 'examples/hia_bootstrap/cold_master_archive.hepta').read_bytes()
    policy = seeds.compile(raw, 'bulk')
    packer_source = (ROOT / 'examples/hia_bootstrap/cold_master_archive_packer.hepta').read_bytes()
    packer_flat = seeds.compile(packer_source, 'v1')
    packer_image = seeds.invoke(OUT / 'hia-seed-filter-pack', b'HIAFLT01' + struct.pack('<Q', len(packer_flat)) + packer_flat)
    tool = OUT / 'archive-packer'
    tool.write_bytes(packer_image)
    tool.chmod(0o500)
    packet = (HERE / 'published-f-bootstrap/entry-packet.hiaqbe').read_bytes()
    assert hashlib.sha256(packet).hexdigest() == '70a1d73d30cda422bd84f13dcc49cce54af0f23db24b7e181b681ff46f10cfa5'
    sha = packet[-116455:]
    assert hashlib.sha256(sha).hexdigest() == '214aea20ce10da438d1a96e98b0a25ed1151776e1fd577047c336d57cd54ae19'
    elf = seeds.invoke(tool, b'HIAQAP01' + struct.pack('<2Q', len(policy), len(sha)) + policy + sha)
    prefix, holes = template()
    reference = bytearray(prefix + policy + sha)
    struct.pack_into('<Q', reference, 96, len(reference))
    struct.pack_into('<Q', reference, 104, len(reference))
    struct.pack_into('<I', reference, holes['policy_hole'], len(prefix) - holes['policy_hole'] - 4)
    struct.pack_into('<I', reference, holes['sha_hole'], len(prefix) + len(policy) - holes['sha_hole'] - 4)
    assert elf == bytes(reference)
    (OUT / 'hia-cold-archive').write_bytes(elf)
    (OUT / 'hia-cold-archive').chmod(0o500)
    (OUT / 'policy.flat').write_bytes(policy)
    report.update(passed=True, source_sha256=hashlib.sha256(raw).hexdigest(), source_bytes=len(raw),
                  policy_sha256=hashlib.sha256(policy).hexdigest(), policy_bytes=len(policy),
                  elf_sha256=hashlib.sha256(elf).hexdigest(), elf_bytes=len(elf),
                  sha256_flat_sha256=hashlib.sha256(sha).hexdigest(), sha256_flat_bytes=len(sha),
                  independent_packer_byte_comparison=True)
    print(json.dumps(report), flush=True)
finally:
    seeds.save()
    (OUT / 'construction-report.json').write_text(json.dumps(report, indent=2) + '\n')
