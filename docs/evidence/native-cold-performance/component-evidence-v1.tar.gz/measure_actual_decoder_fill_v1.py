"""Read-only journal input; real native decoders; full workspace comparison."""
from collections import defaultdict
from pathlib import Path
import ctypes
import datetime
import hashlib
import json
import mmap
import os
import platform
import random
import stat
import struct
import sys
import time

ROOT = Path(__file__).resolve().parent
JOURNAL = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-cold-isolated-f-20261127-v2/cold/qualification/original-signed/evidence.hiaqj')
JOURNAL_SHA = '090c2f1887a34a2e60540bd5a1246b89d09cc38e02daad9c2916cd38536acb37'
PINS = {'original': 'a8c78031678e5159ea0b27223502a116ea51600ad4b5347cf789167583b6db7c',
        'candidate': 'ce032e0ec0abc5765cea3893c2fb1cabb9bb7d8cbacde60940e1106ee7d60612'}
report = {'scope': 'Finite native decoder comparison on actual retained journal; not a full cold qualification',
          'passed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_commit': '5622dafbcfa10ad0c6f99214994ee7dcf71523e0',
          'journal': str(JOURNAL), 'journal_sha256': JOURNAL_SHA, 'products': {},
          'whole_workspace_bytes': 4194304, 'comparisons': 0, 'decoded_bytes': 0,
          'interpreter': sys.executable, 'python_version': platform.python_version(),
          'by_mode': {}, 'returned_sizes_match_declared': True}
started = time.monotonic_ns()
cpu_started = time.process_time_ns()


def entry(raw):
    region = mmap.mmap(-1, len(raw), prot=mmap.PROT_READ | mmap.PROT_WRITE | mmap.PROT_EXEC)
    region[:] = raw
    pointer = ctypes.addressof(ctypes.c_char.from_buffer(region))
    signature = ctypes.CFUNCTYPE(ctypes.c_uint64, ctypes.c_void_p, ctypes.c_uint64,
                                ctypes.c_void_p, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_uint64)
    return region, signature(pointer)


try:
    st = JOURNAL.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_uid == os.geteuid()
    assert st.st_size == 47996590 and stat.S_IMODE(st.st_mode) == 0o400
    raw = JOURNAL.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == JOURNAL_SHA
    report['journal_before'] = {'bytes': st.st_size, 'device': st.st_dev, 'inode': st.st_ino,
                                'mtime_ns': st.st_mtime_ns, 'mode': stat.S_IMODE(st.st_mode), 'nlink': st.st_nlink}
    data = ctypes.create_string_buffer(raw)
    data_at = ctypes.addressof(data)
    initial = random.Random(6147).randbytes(4194304)
    work = {label: ctypes.create_string_buffer(initial, len(initial)) for label in PINS}
    images = {}
    code_regions = []
    for label, digest in PINS.items():
        body = (ROOT / ('decoder_probe-' + label + '.flat')).read_bytes()
        assert hashlib.sha256(body).hexdigest() == digest
        region, image = entry(body)
        code_regions.append(region)
        images[label] = image
        report['products'][label] = {'bytes': len(body), 'sha256': digest}
    compare = ctypes.CDLL(None).memcmp
    compare.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
    compare.restype = ctypes.c_int
    s = ctypes.create_string_buffer(8)
    o = {label: ctypes.create_string_buffer(8) for label in PINS}
    decoded_hash = {label: hashlib.sha256() for label in PINS}
    work_at = {label: ctypes.addressof(buffer) for label, buffer in work.items()}
    previous = {}
    at = 0
    index = 0
    while at < len(raw):
        assert len(raw) - at >= 32
        magic, size, payload, mode = struct.unpack_from('<4Q', raw, at)
        assert 0 < size <= 65504 and mode <= 3 and 0 < payload <= 65504
        end = at + 32 + payload
        assert end <= len(raw)
        if mode == 3:
            assert payload == 8
            prior = struct.unpack_from('<Q', raw, at + 32)[0]
            assert prior in previous
            source, encoded, declared, stored_mode = previous[prior]
            assert source == prior and declared == size and stored_mode != 3
        else:
            source, encoded, declared, stored_mode = at, 32 + payload, size, mode
            previous[at] = (source, encoded, declared, stored_mode)
        struct.pack_into('<Q', s, 0, encoded)
        row = report['by_mode'].setdefault(str(stored_mode), {
            'chunks': 0, 'decoded_bytes': 0, 'backrefs': 0,
            'original_cpu_ns': 0, 'candidate_cpu_ns': 0,
            'original_elapsed_ns': 0, 'candidate_elapsed_ns': 0})
        row['chunks'] += 1
        row['decoded_bytes'] += size
        row['backrefs'] += int(mode == 3)
        for label in (['original', 'candidate'] if index % 2 == 0 else ['candidate', 'original']):
            ctypes.memmove(work_at[label] + 800000, data_at + source, encoded)
            tick = time.monotonic_ns()
            cpu = time.process_time_ns()
            result = images[label](s, 8, o[label], 8, work[label], 4194304)
            row[label + '_cpu_ns'] += time.process_time_ns() - cpu
            row[label + '_elapsed_ns'] += time.monotonic_ns() - tick
            assert result == size, (index, label, source, mode, result, size)
            view = (ctypes.c_ubyte * size).from_address(work_at[label] + 940000)
            decoded_hash[label].update(memoryview(view))
        assert compare(work_at['original'], work_at['candidate'], 4194304) == 0, index
        assert o['original'].raw == o['candidate'].raw == bytes(8)
        report['comparisons'] += 1
        report['decoded_bytes'] += size
        at = end
        index += 1
        if index % 20000 == 0:
            print('NATIVE_DECODER_PROGRESS', index, at, json.dumps(report['by_mode']), flush=True)
    assert index == 131668 and report['decoded_bytes'] == 1170777775
    assert decoded_hash['original'].digest() == decoded_hash['candidate'].digest()
    report['decoded_sha256'] = decoded_hash['original'].hexdigest()
    report['workspace_sha256'] = hashlib.sha256(work['original'].raw).hexdigest()
    after = JOURNAL.lstat()
    assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_mode, st.st_nlink) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode, after.st_nlink)
    assert hashlib.sha256(JOURNAL.read_bytes()).hexdigest() == JOURNAL_SHA
    report['passed'] = True
finally:
    report['elapsed_ns'] = time.monotonic_ns() - started
    report['process_cpu_ns'] = time.process_time_ns() - cpu_started
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT / 'diagnostic.json').write_text(json.dumps(report, indent=2) + '\n')
    print('NATIVE_ACTUAL_DECODER_RESULT', json.dumps(report), flush=True)
