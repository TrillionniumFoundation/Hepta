"""Actual original/candidate archive processes on private exact-byte fixtures.

The 64-byte driver fixture receipt is reconstructed from retained physical
evidence for this component comparison. It is not an original cold receipt,
and neither this comparison nor its four archives qualifies the whole cold.
"""
from pathlib import Path
import datetime, fcntl, hashlib, json, os, resource, stat, struct, subprocess, sys, time

ROOT = Path(sys.argv[1]).resolve()
BASE = Path('/home/qian-qi/hia-native-current-20261127-0862')
DATA = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-directory-source-closure-evidence-20261127-620a/archive-comparison-data-v1')
FROZEN = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-final-native-source-20261127-5622dafb')
COLD = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-cold-isolated-f-20261127-v2/cold/qualification')
OLD = BASE / 'final-f-public-build-v1/build/toolchain/roots/artifact-001-archive'
NEW = ROOT / 'hia-cold-archive'
PRODUCTS = {OLD: '5950a07041ac24b5e2c381011c472627827d2121b9afc9e97fa763113a3edd54',
            NEW: 'c9401ffd8a3be7c78e3804150c0d5db06130cefc0007053ffe6146a1b9757fa8'}
PLAN_SHA = '64ad2d153e1b6decb9a471fffc3bfd8a5e77c00cf31f42266799f71d5c4d9bd6'
JOURNAL_SHA = '090c2f1887a34a2e60540bd5a1246b89d09cc38e02daad9c2916cd38536acb37'
report = {'scope': __doc__, 'passed': False, 'whole_cold_qualified': False,
          'source_baseline': '5622dafbcfa10ad0c6f99214994ee7dcf71523e0',
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'runs': []}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def regular(path, *, limit):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_uid == os.geteuid() and st.st_size <= limit
    raw = path.read_bytes()
    assert len(raw) == st.st_size
    return raw


def sealed(name, raw):
    fd = os.memfd_create(name, os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING)
    at = 0
    while at < len(raw):
        n = os.write(fd, raw[at:])
        assert n > 0
        at += n
    os.fchmod(fd, 0o600)
    fcntl.fcntl(fd, fcntl.F_ADD_SEALS, 15)
    assert fcntl.fcntl(fd, fcntl.F_GET_SEALS) == 15
    os.lseek(fd, 0, os.SEEK_SET)
    return fd


try:
    assert ROOT.is_dir() and stat.S_IMODE(ROOT.stat().st_mode) == 0o700
    DATA.mkdir(mode=0o700, exist_ok=False)
    products = {str(path): {'bytes': len(raw := regular(path, limit=1048576)), 'sha256': sha(raw)} for path in PRODUCTS}
    for path, expected in PRODUCTS.items():
        assert products[str(path)]['sha256'] == expected
    report['products'] = products
    journal = regular(COLD / 'original-signed/evidence.hiaqj', limit=67108864)
    plan = regular(FROZEN / 'examples/hia_bootstrap/cold_plans/original-signed.hiacases', limit=67108864)
    original_archive = regular(COLD / 'original-signed.hiaqar', limit=67108864)
    assert len(journal) == 47996590 and sha(journal) == JOURNAL_SHA
    assert len(plan) == 1253233 and sha(plan) == PLAN_SHA
    assert len(original_archive) == 47996830 and original_archive[:8] == b'HIAQAR01'
    report['fixture'] = {'journal_bytes': len(journal), 'journal_sha256': JOURNAL_SHA,
                          'plan_bytes': len(plan), 'plan_sha256': PLAN_SHA, 'nodes': 22544,
                          'retained_archive_bytes': len(original_archive), 'retained_archive_sha256': sha(original_archive),
                          'driver_receipt_origin': 'reconstructed component fixture from archived physical metadata'}
    driver_raw = b'HIAQOK01' + struct.pack('<3Q', 22544, len(plan), len(journal)) + bytes.fromhex(JOURNAL_SHA)
    assert len(driver_raw) == 64
    (ROOT / 'fixture-driver.receipt').write_bytes(driver_raw)
    for index, (name, executable) in enumerate([('original', OLD), ('candidate', NEW), ('candidate', NEW), ('original', OLD)]):
        trial = DATA / f'{index:02d}-{name}'
        trial.mkdir(mode=0o700)
        phase = trial / 'phase'
        phase.mkdir(mode=0o700)
        file = phase / 'evidence.hiaqj'
        with file.open('xb') as stream:
            stream.write(journal)
            stream.flush()
            os.fchmod(stream.fileno(), 0o600)
            os.fsync(stream.fileno())
        archive = trial / 'phase.hiaqar'
        fds = []
        row = {'profile': name, 'trial': str(trial), 'complete': False}
        report['runs'].append(row)
        try:
            directory_fd = os.open(phase, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
            journal_fd = os.open(file, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            driver_fd = sealed('component-driver-receipt', driver_raw)
            plan_fd = sealed('component-qualification-plan', plan)
            archive_fd = os.open(archive, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
            fds = [directory_fd, journal_fd, driver_fd, plan_fd, archive_fd]
            deadline = time.monotonic_ns() + 180000000000
            request = b'HIAQARQ1' + struct.pack('<9Q', os.getpid(), deadline, directory_fd, journal_fd,
                driver_fd, plan_fd, len(plan), 22544, archive_fd) + bytes.fromhex(PLAN_SHA) + bytes(16)
            assert len(request) == 128
            request_fd = sealed('component-archive-request', request)
            fds.append(request_fd)
            (trial / 'request.bin').write_bytes(request)
            trace = trial / 'exec.trace'
            command = ['/usr/bin/strace', '-D', '-f', '--seccomp-bpf', '-e', 'trace=execve,execveat',
                       '-o', str(trace), '--', str(executable)]
            row['argv'] = command
            before = resource.getrusage(resource.RUSAGE_CHILDREN)
            started = time.monotonic_ns()
            result = subprocess.run(command, stdin=request_fd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                pass_fds=tuple(fds), close_fds=True, timeout=183,
                env={'PATH': '', 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
            row['elapsed_ns'] = time.monotonic_ns() - started
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            row['waited_child_user_seconds'] = after.ru_utime - before.ru_utime
            row['waited_child_system_seconds'] = after.ru_stime - before.ru_stime
            row['returncode'] = result.returncode
            (trial / 'stdout.receipt').write_bytes(result.stdout)
            (trial / 'stderr.bin').write_bytes(result.stderr)
            row['stdout'] = {'bytes': len(result.stdout), 'sha256': sha(result.stdout)}
            row['stderr'] = {'bytes': len(result.stderr), 'sha256': sha(result.stderr)}
            assert result.returncode == 0 and len(result.stdout) == 128 and not result.stderr, row
            assert result.stdout[:8] == b'HIAQAS01'
            assert struct.unpack_from('<3Q', result.stdout, 8) == (1, len(original_archive), 22544)
            assert result.stdout[32:64] == bytes.fromhex(PLAN_SHA)
            assert result.stdout[64:96] == bytes.fromhex(JOURNAL_SHA)
            final = regular(archive, limit=67108864)
            assert final == original_archive and sha(final) == result.stdout[96:128].hex()
            assert stat.S_IMODE(archive.stat().st_mode) == 0o400 and stat.S_IMODE(file.stat().st_mode) == 0o400
            assert stat.S_IMODE(phase.stat().st_mode) == 0o500
            assert regular(file, limit=67108864) == journal
            trace_raw = trace.read_bytes()
            assert b'execve(' in trace_raw and b'execveat(' not in trace_raw
            row['archive'] = {'bytes': len(final), 'sha256': sha(final), 'mode': 0o400}
            row['trace'] = {'bytes': len(trace_raw), 'sha256': sha(trace_raw)}
            row['all_source_archive_bytes_and_sealing_equal'] = True
            row['complete'] = True
            print('ARCHIVE_COMPONENT_RUN', json.dumps(row), flush=True)
        finally:
            for fd in reversed(fds):
                os.close(fd)
            (ROOT / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    assert regular(COLD / 'original-signed/evidence.hiaqj', limit=67108864) == journal
    assert regular(COLD / 'original-signed.hiaqar', limit=67108864) == original_archive
    assert all(sha(regular(path, limit=1048576)) == expected for path, expected in PRODUCTS.items())
    report['passed'] = True
finally:
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    print('ARCHIVE_COMPONENT_RESULT', json.dumps(report), flush=True)
