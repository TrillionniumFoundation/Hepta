from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,signal,subprocess,time,traceback
r=Path('/home/qian-qi/hia-native-unified-de0-20261127-2ac5');head='de0c0325ef1ece788666695638b6bebbdc329eda'
assert json.loads((r/'source-materialization.json').read_bytes())['passed']
assert not (r/'native-chain-campaign.json').exists()
def pin(b):return {'bytes':len(b),'sha256':sha256(b).hexdigest()}
record={'schema':'hepta.hia.current-native-chain-campaign.v1','passed':False,'head':head,'source_tree':'62102d919de9eeb79e02a5d79e0651ffa182816f','started':time.time(),'started_utc':datetime.now(timezone.utc).isoformat(),'commands':[],'loadavg':Path('/proc/loadavg').read_text().strip(),'uname':list(os.uname()),'cpu_models':sorted({line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')}),'logical_cpus':os.cpu_count(),'memory':{k:v.strip() for k,v in [line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines()] if k in ('MemAvailable','SwapFree')},'filesystem_available_bytes':os.statvfs(r).f_bavail*os.statvfs(r).f_frsize,'source_materialization':pin((r/'source-materialization.json').read_bytes()),'transport_recovery':pin((r/'transport-recovery.json').read_bytes()),'whole_cold_qualified':False,'whole_native_delivery_qualified':False}
assert record['logical_cpus']==32 and record['cpu_models']==['AMD RYZEN AI MAX+ 395 w/ Radeon 8060S'],record['cpu_models']
assert record['filesystem_available_bytes']>=10*1024**3
assert int(record['memory']['MemAvailable'].split()[0])>=8*1024**2
def save():(r/'native-chain-campaign.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
def run(label,args,limit):
 row={'label':label,'argv':args,'outer_observer_limit_seconds':limit,'started':time.time()};record['commands'].append(row);save()
 with (r/(label+'.stdout')).open('xb') as out,(r/(label+'.stderr')).open('xb') as err:
  p=subprocess.Popen(args,cwd=r/'source',stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
  row['pid']=p.pid;save();print('CAMPAIGN_BEGIN',label,p.pid,flush=True)
  try:rc=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   row['observer_timeout']=True;row['termination_requested']='SIGTERM';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:row['termination_requested']='SIGKILL';os.killpg(p.pid,signal.SIGKILL);p.wait()
   row.update(returncode=p.returncode,ended=time.time());save();raise
 row.update(returncode=rc,ended=time.time(),stdout=pin((r/(label+'.stdout')).read_bytes()),stderr=pin((r/(label+'.stderr')).read_bytes()));save();print('CAMPAIGN_TERMINAL',label,rc,flush=True);assert rc==0
try:
 save();print('UNIFIED_CAMPAIGN_RESOURCE',json.dumps({k:record[k] for k in ('head','loadavg','cpu_models','logical_cpus','memory','filesystem_available_bytes')}),flush=True)
 run('public-seven-stage',['/usr/bin/python3','-I','-B',str(r/'drivers/build_native_current.py'),'--source',str(r/'source'),'--head',head,'--preparation',str(r/'preparation'),'--preseed',str(r/'preseed'),'--output',str(r/'public-build-v1')],430)
 run('physical-native-source-export',['/usr/bin/python3','-I','-B',str(r/'drivers/export_native_current.py'),'--source',str(r/'source'),'--build',str(r/'public-build-v1'),'--preparation',str(r/'preparation'),'--output',str(r/'native-export-v1')],160)
 run('full-native-chain',['/usr/bin/python3','-I','-B',str(r/'drivers/qualify_native_current_chain_v2.py'),'--source',str(r/'source'),'--head',head,'--preparation',str(r/'preparation'),'--build',str(r/'public-build-v1'),'--export',str(r/'native-export-v1'),'--output',str(r/'native-chain-v1'),'--cold-storage',str(r/'cold-data-v1')],4200)
 actual=json.loads((r/'native-chain-v1/qualification.json').read_bytes());assert actual['passed'] and actual['whole_cold_qualified']
 record.update(passed=True,whole_cold_qualified=True,native_chain_result=pin((r/'native-chain-v1/qualification.json').read_bytes()),finished=time.time());save();print('UNIFIED_NATIVE_CAMPAIGN_PASS',head,flush=True)
except BaseException:
 record.update(error=traceback.format_exc(),finished=time.time());save();raise
