"""Isolated native experiment: remove identity block-edge parallel copies.

Only derived bulk/endian profiles are rendered into this owned directory.
Original seed source, source freeze, native receipts, and four bootstrap roots
remain unchanged. This is a finite component experiment, never a cold pass.
"""
from pathlib import Path
from hashlib import sha256
import ast
import ctypes
import json
import random
import statistics
import struct
import subprocess
import sys
import time

SOURCE = Path('/tmp/hepta-native-cold-perf-20261127-2ac5')
PRESEED = Path('/tmp/hepta-native-unified-preseed-v1')
OUTPUT = Path('/tmp/hepta-seed-edge-experiment-20261127-2ac5')
sys.path.insert(0, str(SOURCE))
from hepta.hia_agent_assembly import render_assembly
from hepta.hia_sha256_stream_native import NativeSha256Stream
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from tools.generate_hia_worker_config_json import document
from tools.generate_hia_seed_bulk_backend import program as bulk_program
from tools.generate_hia_seed_endian_backend import program as endian_program
from tools.qualify_hia_cold_qualification_codec_lz import decode

ORIGINAL_EDGE = '''
def edge(s:readbuf,o:mutbuf,w:mutbuf,record:u64)->u64:
    count=word(s,record+16)
    stage(s,o,w,word(s,record+8),count)
    index=0
    while index<count:
        load(o,w,0,5,get(w,96)+index*8)
        value_save(o,w,0,index)
        index=index+1
    patch(o,w,33,0,word(s,record))
    return 0
'''
OPTIMIZED_EDGE = '''
def edge(s:readbuf,o:mutbuf,w:mutbuf,record:u64)->u64:
    count=word(s,record+16)
    list=word(s,record+8)
    index=0
    while index<count:
        slot=word(s,list+index*8)
        if slot!=index:
            value_load(o,w,0,slot)
            save(o,w,0,5,get(w,96)+index*8)
        index=index+1
    index=0
    while index<count:
        if word(s,list+index*8)!=index:
            load(o,w,0,5,get(w,96)+index*8)
            value_save(o,w,0,index)
        index=index+1
    patch(o,w,33,0,word(s,record))
    return 0
'''

def pin(raw):
    return {'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}

def specialize(raw):
    tree=ast.parse(raw)
    originals=ast.parse(ORIGINAL_EDGE).body
    replacements=ast.parse(OPTIMIZED_EDGE).body
    matches=[i for i,n in enumerate(tree.body) if isinstance(n,ast.FunctionDef) and n.name=='edge']
    assert len(matches)==1
    at=matches[0]
    assert ast.dump(tree.body[at])==ast.dump(originals[0]), 'edge source shape drifted'
    before={n.name:ast.dump(n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name!='edge'}
    tree.body[at]=replacements[0]
    assert before=={n.name:ast.dump(n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name!='edge'}
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def main():
    OUTPUT.mkdir(mode=0o700,exist_ok=False)
    prior_raw=(PRESEED/'report.json').read_bytes()
    prior=json.loads(prior_raw)
    roots={}
    for row in prior['initial_roots']:
        path=Path(row['path'])
        assert pin(path.read_bytes())=={k:row[k] for k in ('bytes','sha256')}
        roots[row['name']]=path
    prods=PRESEED/'products'
    packer=prods/'seed_backend_filter_packer-v1.tool'
    report={'schema':'hepta.hia.seed-edge-identity-experiment.v1','passed':False,
            'whole_cold_qualified':False,'source_unchanged':False,
            'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),
            'driver':pin(Path(__file__).read_bytes()),'native_root_receipt':pin(prior_raw),
            'native_roots':prior['initial_roots'],'calls':[],'images':{},
            'sha_comparisons':0,'codec_comparisons':0,'benchmarks':[]}
    source_paths=['tools/generate_hia_seed_backend.py','tools/generate_hia_seed_bulk_backend.py',
                  'tools/generate_hia_seed_endian_backend.py','tools/generate_hia_seed_word_backend.py',
                  'examples/hia_bootstrap/seed_bulk_backend.hepta','examples/hia_bootstrap/seed_endian_backend.hepta']
    original_pins={p:pin((SOURCE/p).read_bytes()) for p in source_paths}
    report['source_pins']=original_pins
    def save():
        (OUTPUT/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    def invoke(label,exe,raw,args=()):
        (OUTPUT/(label+'.stdin')).write_bytes(raw)
        start=time.monotonic_ns()
        cp=subprocess.run([str(exe),*args],input=raw,capture_output=True,
                          env={'PATH':'','LANG':'C','LC_ALL':'C'},timeout=30)
        (OUTPUT/(label+'.stdout')).write_bytes(cp.stdout)
        (OUTPUT/(label+'.stderr')).write_bytes(cp.stderr)
        report['calls'].append({'label':label,'executable':str(exe),'executable_pin':pin(exe.read_bytes()),
                                'input':pin(raw),'stdout':pin(cp.stdout),'stderr':pin(cp.stderr),
                                'returncode':cp.returncode,'elapsed_ns':time.monotonic_ns()-start})
        save()
        assert cp.returncode==0 and not cp.stderr and cp.stdout, label
        print('NATIVE',label,len(cp.stdout),flush=True)
        return cp.stdout
    backends={}
    for profile,author in [('bulk',bulk_program),('endian',endian_program)]:
        name='seed_'+profile+'_backend'
        raw=render_assembly(document(specialize(author()),name)).encode()
        (OUTPUT/(name+'.hepta')).write_bytes(raw)
        core=invoke(profile+'-core',roots['hia-seed-assembly'],raw,('--agent-compact',))
        projected=invoke(profile+'-project',roots['hia-seed-projector'],b'['+core+b',"f0",1]')
        flat=invoke(profile+'-flat',roots['hia-seed-backend'],projected)
        tool=invoke(profile+'-transport',packer,b'HIAFLT01'+struct.pack('<Q',len(flat))+flat)
        target=OUTPUT/('seed-'+profile+'.tool')
        target.write_bytes(tool);target.chmod(0o500)
        backends[profile]=target
        report['images'][name]={'source':pin(raw),'flat':pin(flat),'tool':pin(tool)}
        save()
    fallback=(prods/'cold_sha256_stream-word.flat').read_bytes()
    old_sha=(prods/'tmp-cold-sha256-flat').read_bytes()
    projected=Path('/tmp/hepta-sha-schedule-experiment-20261127-2ac5-v2/schedule-4-project.stdout').read_bytes()
    fast=invoke('sha-fast',backends['endian'],projected)
    new_sha=invoke('sha-composite',prods/'cold_sha256_alias_packer-word.tool',
                   b'HIASHA01'+struct.pack('<2Q',len(fallback),len(fast))+fallback+fast)
    (OUTPUT/'old.flat').write_bytes(old_sha)
    (OUTPUT/'new.flat').write_bytes(new_sha)
    images={key:NativeSha256Stream(raw,sha256(raw).hexdigest()) for key,raw in [('old',old_sha),('edge',new_sha)]}
    report['images']['sha']={'old':pin(old_sha),'edge':pin(new_sha),'fast':pin(fast),'unchanged_fallback':pin(fallback)}
    save()
    guard=b'\x91\xd3\x4a\x68'*4
    def call(image,wire,output,state):
        bufs=[ctypes.create_string_buffer(guard+raw+guard,len(raw)+32) for raw in (wire,output,state)]
        args=[]
        for buf,raw in zip(bufs,(wire,output,state)):
            args.extend((ctypes.byref(buf,16),len(raw)))
        status=image._entry(*args)
        assert all(buf.raw[:16]==guard and buf.raw[-16:]==guard for buf in bufs)
        assert bufs[0].raw[16:-16]==wire
        return status,*(buf.raw[16:-16] for buf in bufs)
    rng=random.Random(0xED6E256)
    initial=call(images['old'],b'\0',b'\xa5'*41,b'\x6d'*1201)[3]
    for trial in range(512):
        state=bytearray(initial)
        for word in range(136):
            struct.pack_into('<Q',state,word*8,rng.getrandbits(64))
        total=rng.randrange(1<<40)
        struct.pack_into('<QQQ',state,1088,total,total&63,1)
        wire=b'\x02' if trial&1 else b'\x01'+rng.randbytes(rng.randrange(2049))
        assert call(images['old'],wire,b'\xa5'*41,bytes(state))==call(images['edge'],wire,b'\xa5'*41,bytes(state)),trial
        report['sha_comparisons']+=1
    for size in (0,1,55,56,63,64,65,127,128,129,256,4096,1<<20):
        wire=rng.randbytes(size)
        assert images['edge'].digest(wire)==sha256(wire).digest()
        report['sha_comparisons']+=1
    save();print('RAW_U64_AND_DIGEST_PASS',report['sha_comparisons'],flush=True)
    codecs={}
    previous=Path('/tmp/hepta-journal-component-profile-20261127-2ac5')
    for name in ('actual-pack','actual-decode','actual-fingerprint'):
        raw=(previous/(name+'.hepta')).read_bytes()
        core=invoke(name+'-core',roots['hia-seed-assembly'],raw,('--agent-compact',))
        projected=invoke(name+'-project',roots['hia-seed-projector'],b'['+core+b',"f0",1]')
        new=invoke(name+'-flat',backends['bulk'],projected)
        old=(previous/(name+'.flat')).read_bytes()
        report['images'][name]={'old':pin(old),'edge':pin(new)}
        codecs[name]={key:NativeHiaJsonImage(img,sha256(img).hexdigest()) for key,img in [('old',old),('edge',new)]}
        save()
    data=Path('/tmp/hepta-journal-component-samples-20261127-2ac5')
    samples=[]
    for phase in json.loads((data/'manifest.json').read_bytes())['phases']:
        for sample in phase['samples']:
            raw=(data/sample['path']).read_bytes()
            assert pin(raw)=={key:sample[key] for key in ('bytes','sha256')}
            samples.append((sample['path'],raw,decode(raw)))
    def run_codec(native,workspace,size,count):
        work=ctypes.create_string_buffer(guard+workspace+guard,len(workspace)+32)
        args=ctypes.create_string_buffer(struct.pack('<2Q',size,count),16)
        out=ctypes.create_string_buffer(b'preserve',8)
        start=time.perf_counter_ns()
        result=native._entry(args,16,out,8,ctypes.addressof(work)+16,len(workspace))
        elapsed=time.perf_counter_ns()-start
        assert out.raw==b'preserve' and work.raw[:16]==guard and work.raw[-16:]==guard
        return result,work.raw[16:-16],elapsed
    for label,raw,decoded in samples:
        work=bytearray(rng.randbytes(4194304))
        work[700000:700000+len(decoded)]=decoded
        work[800000:800000+len(raw)]=raw
        for name,size in [('actual-pack',len(decoded)),('actual-decode',len(raw)),('actual-fingerprint',len(raw))]:
            a=run_codec(codecs[name]['old'],bytes(work),size,1)
            b=run_codec(codecs[name]['edge'],bytes(work),size,1)
            assert a[:2]==b[:2],(label,name)
            report['codec_comparisons']+=1
    print('FULL_WORKSPACE_CODEC_PASS',report['codec_comparisons'],flush=True)
    save()
    payloads={'1MiB-pattern':bytes(range(256))*4096,'8MiB-pattern':bytes(range(256))*32768}
    wanted={k:sha256(v).digest() for k,v in payloads.items()}
    for repetition in range(7):
        order=list(images)
        random.Random(0xED6E+repetition).shuffle(order)
        for name,wire in payloads.items():
            for key in order:
                start=time.perf_counter_ns();actual=images[key].digest(wire);elapsed=time.perf_counter_ns()-start
                assert actual==wanted[name]
                report['benchmarks'].append({'repetition':repetition,'payload':name,'variant':key,'bytes':len(wire),'elapsed_ns':elapsed})
        for label,raw,decoded in samples:
            work=bytearray(4194304)
            work[700000:700000+len(decoded)]=decoded
            work[800000:800000+len(raw)]=raw
            for name,size in [('actual-pack',len(decoded)),('actual-decode',len(raw)),('actual-fingerprint',len(raw))]:
                results=[]
                for key in order:
                    result,changed,elapsed=run_codec(codecs[name][key],bytes(work),size,100)
                    results.append((result,changed))
                    report['benchmarks'].append({'repetition':repetition,'payload':label+'/'+name,'variant':key,'bytes':size,'calls':100,'elapsed_ns':elapsed})
                assert results[0]==results[1]
        save()
    medians={}
    for name in sorted({r['payload'] for r in report['benchmarks']}):
        medians[name]={key:statistics.median(r['elapsed_ns'] for r in report['benchmarks'] if r['payload']==name and r['variant']==key)/1e9 for key in images}
    report['medians_seconds']=medians
    assert original_pins=={p:pin((SOURCE/p).read_bytes()) for p in source_paths}
    report['source_unchanged']=True;report['passed']=True;save()
    print('EXPERIMENT_PASS',json.dumps(medians,sort_keys=True),flush=True)

if __name__=='__main__':
    main()
