from pathlib import Path
import hashlib,io,json,os,shlex,stat,subprocess,tarfile,time
R=Path(__file__).resolve().parent;S=R/'source-01db';Q=R/'linux-source3-v7';Q.mkdir(mode=0o700)
F='tests/fixtures/hia_behavior_input_history_v7.json';fixture=json.loads((S/F).read_bytes())
assert hashlib.sha256((S/F).read_bytes()).hexdigest()=='6215141499231dca05b9edf889d8113ea0745dbfe081d2f6db7c1224adbc215c'
names=sorted(set(fixture['stage_files'])|{F,'tests/fixtures/hia_behavior_input_history_v4.json','tools/hia_behavior_source_history.py'})
pins={}
with tarfile.open(Q/'source.tar.gz','w:gz',compresslevel=9) as tf:
 for n in names:
  p=S/n;raw=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);assert p.is_file() and not p.is_symlink()
  pins[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':mode}
  m=tarfile.TarInfo(n);m.size=len(raw);m.mode=mode;m.mtime=0;tf.addfile(m,io.BytesIO(raw))
packed=(Q/'source.tar.gz').read_bytes();manifest={'base':'01db1957855ed8fc7b5132f77cdf3d9031c2f271','tree':'eb28a3842bf853f2371a810adadebf6616df24db','source_scope':'Final committed Service with explicit immutable v7 historical preparation','archive':{'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest()},'files':pins}
(Q/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
remote='/home/qian-qi/hia-finite-proof-union-01db-20261128-2ac5'
driver=r"""from pathlib import Path
import hashlib,json,os,stat,subprocess,tarfile,time,traceback
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification';T=R/'tmp'
Q.mkdir(mode=0o700);T.mkdir(mode=0o700);S.mkdir(mode=0o700)
manifest=json.loads((R/'manifest.json').read_bytes());packed=(R/'source.tar.gz').read_bytes()
assert len(packed)==manifest['archive']['bytes'] and hashlib.sha256(packed).hexdigest()==manifest['archive']['sha256']
free=os.statvfs(R);available=free.f_bavail*free.f_frsize
(Q/'preflight.json').write_text(json.dumps({'filesystem_device':R.stat().st_dev,'bytes_available':available,'owner_pid':os.getpid(),'tmpdir':str(T)})+'\n')
assert available>=1073741824,('insufficient storage before original source test',available)
with tarfile.open(R/'source.tar.gz','r:gz') as tf:
 seen=set()
 for m in tf:
  n=m.name;assert m.isfile() and n in manifest['files'] and n not in seen and not Path(n).is_absolute() and '..' not in Path(n).parts
  seen.add(n);raw=tf.extractfile(m).read();want=manifest['files'][n]
  assert len(raw)==want['bytes'] and hashlib.sha256(raw).hexdigest()==want['sha256'] and m.mode==want['mode']
  p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(m.mode)
 assert seen==set(manifest['files'])
def capture():
 result={}
 for n,want in manifest['files'].items():
  p=S/n;raw=p.read_bytes();got={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)}
  assert got==want,(n,got,want);result[n]=got
 return result
before=capture();(Q/'physical-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')}
env.update({'TMPDIR':str(T),'PYTHONDONTWRITEBYTECODE':'1','HEPTA_HIA_SERVICE_VERIFICATION_SOURCE_EVIDENCE':str(Q/'actual')})
cmd=['/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python','-m','unittest','-v','tests.test_hia_service_verification_native.ServiceVerificationSourceTests']
(Q/'intent.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'original_inner_limits':[600,1800],'outer_shortened_limit':False,'scope':'EXPLICIT_PREDECESSOR_446_PORT_9_METHOD_DOMAIN','current_native_whole_qualified':False},indent=2)+'\n')
start=time.monotonic()
with (Q/'stdout').open('xb') as out,(Q/'stderr').open('xb') as err:
 child=subprocess.Popen(cmd,cwd=S,env=env,stdout=out,stderr=err)
 (Q/'started.json').write_text(json.dumps({'pid':child.pid,'supervisor_pid':os.getpid(),'unix':time.time()})+'\n')
 print(json.dumps({'running':True,'pid':child.pid,'qualification':str(Q)}),flush=True)
 rc=child.wait()
after=capture();(Q/'physical-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
report={'returncode':rc,'seconds':time.monotonic()-start,'physical_unchanged':before==after,'files':len(before),'scope':'EXPLICIT_PREDECESSOR_446_PORT_9_METHOD_DOMAIN','current_native_whole_qualified':False}
(Q/'terminal.tmp').write_text(json.dumps(report,indent=2)+'\n');(Q/'terminal.tmp').replace(Q/'terminal.json')
print(json.dumps(report),flush=True);print((Q/'stderr').read_text()[-14000:],flush=True)
assert before==after
raise SystemExit(rc)
"""
(Q/'linux_driver.py').write_text(driver)
def call(label,argv,timeout=None):
 (Q/(label+'.intent.json')).write_text(json.dumps({'argv':argv},indent=2)+'\n');start=time.monotonic()
 with (Q/(label+'.stdout')).open('xb') as out,(Q/(label+'.stderr')).open('xb') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err);(Q/(label+'.started.json')).write_text(json.dumps({'pid':child.pid})+'\n')
  rc=child.wait(timeout=timeout)
 result={'returncode':rc,'seconds':time.monotonic()-start};(Q/(label+'.terminal.json')).write_text(json.dumps(result)+'\n')
 if rc:raise RuntimeError((label,result,(Q/(label+'.stderr')).read_text()[-3000:]))
 return result
ssh=['/usr/bin/ssh','-oBatchMode=yes','-oConnectTimeout=8','rog']
prepare="from pathlib import Path; p=Path("+repr(remote)+"); p.mkdir(mode=0o700); print(p)"
call('remote-directory',ssh+['python3 -c '+shlex.quote(prepare)],30)
for filename in ('source.tar.gz','manifest.json','linux_driver.py'):
 call('upload-'+filename,['/usr/bin/scp','-oBatchMode=yes','-oConnectTimeout=8',str(Q/filename),'rog:'+remote+'/'+filename],120)
print(json.dumps({'archive':manifest['archive'],'files':len(pins),'remote':remote}),flush=True)
result=call('remote-original-source3',ssh+['python3 '+shlex.quote(remote+'/linux_driver.py')])
print(json.dumps(result),flush=True);print((Q/'remote-original-source3.stdout').read_text()[-16000:],flush=True)
assert all((S/n).read_bytes() and hashlib.sha256((S/n).read_bytes()).hexdigest()==row['sha256'] and stat.S_IMODE((S/n).stat().st_mode)==row['mode'] for n,row in pins.items())
