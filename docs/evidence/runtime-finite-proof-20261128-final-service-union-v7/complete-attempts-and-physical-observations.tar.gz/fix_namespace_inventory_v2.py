from pathlib import Path
import ast,base64,hashlib,json,os,subprocess,time,zlib
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'preparation-v2';Q.mkdir(mode=0o700)
v5path=S/'tests/fixtures/hia_behavior_input_history_v5.json';raw5=v5path.read_bytes();f=json.loads(raw5)
assert 'tools/__init__.py' in f['stage_files'] and not (S/'tools/__init__.py').exists()
tracked=set(subprocess.check_output(['/usr/bin/git','ls-tree','-r','--name-only','HEAD'],cwd=S,text=True).splitlines())
assert 'tools/__init__.py' not in tracked
assert [n for n in f['stage_files'] if not (S/n).is_file()]==['tools/__init__.py']
f['stage_files'].remove('tools/__init__.py')
builder=S/'tools/build_hia_service_verification.py';b=builder.read_text()
assert b.count('hia_behavior_input_history_v5.json')==1
builder.write_text(b.replace('hia_behavior_input_history_v5.json','hia_behavior_input_history_v6.json'))
def whole(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'zlib_base64':base64.b64encode(zlib.compress(raw,9)).decode()}
for n,row in f['entries'].items():row['current']=whole((S/n).read_bytes())
raw6=(json.dumps(f,sort_keys=True,indent=2)+'\n').encode();v6path=S/'tests/fixtures/hia_behavior_input_history_v6.json'
assert not v6path.exists();v6path.write_bytes(raw6)
helper=S/'tools/hia_behavior_source_history.py';h=helper.read_text()
assert h.count('hia_behavior_input_history_v5.json')==1 and h.count(hashlib.sha256(raw5).hexdigest())==1
helper.write_text(h.replace('hia_behavior_input_history_v5.json','hia_behavior_input_history_v6.json').replace(hashlib.sha256(raw5).hexdigest(),hashlib.sha256(raw6).hexdigest()))
assert v5path.read_bytes()==raw5
inputs={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in f['stage_files']}
inputs.update({str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (helper,v5path,v6path)})
manifest={'base':'9a89423a65445534c6bb4e2fe6b596889aa5ee7c','failed_v5_kept':hashlib.sha256(raw5).hexdigest(),'new_fixture':{'bytes':len(raw6),'sha256':hashlib.sha256(raw6).hexdigest()},'removed_nonexistent_namespace_initializer':'tools/__init__.py','inputs':inputs}
(Q/'preparation.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')}
env['PYTHONDONTWRITEBYTECODE']='1';env['HIA_CURRENT_IMPORT_EVIDENCE']=str(Q/'current-import');env['HEPTA_HIA_SERVICE_VERIFICATION_SOURCE_EVIDENCE']=str(Q/'original-import')
cmd=['/opt/homebrew/bin/python3.14','-m','unittest','-v','tests.test_hia_behavior_source_history','tests.test_hia_program_runtime_batch','tests.test_hia_behavior_source_identity','tests.test_hia_service_verification_imports','tests.test_hia_service_verification_current_imports']
(Q/'tests.intent.json').write_text(json.dumps({'command':cmd,'source':str(S)})+'\n')
start=time.monotonic()
with (Q/'tests.stdout').open('xb') as out,(Q/'tests.stderr').open('xb') as err:
 p=subprocess.Popen(cmd,cwd=S,env=env,stdout=out,stderr=err);(Q/'tests.started.json').write_text(json.dumps({'pid':p.pid})+'\n');rc=p.wait()
after={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in inputs};assert after==inputs
report={'returncode':rc,'seconds':time.monotonic()-start,'inputs_unchanged':True,'fixture':manifest['new_fixture']}
(Q/'tests.terminal.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True);print((Q/'tests.stderr').read_text(),flush=True)
raise SystemExit(rc)
