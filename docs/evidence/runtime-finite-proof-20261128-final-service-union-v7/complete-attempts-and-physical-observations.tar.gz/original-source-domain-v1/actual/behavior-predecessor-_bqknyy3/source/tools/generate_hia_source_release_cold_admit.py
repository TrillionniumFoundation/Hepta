"""Author the native full-contract cold replay admission policy."""
from pathlib import Path
from hashlib import sha256
import ast,copy,json,sys,struct,stat
from tools.hia_selfhost_contract import support_contract,CONTRACT_PATH
from tools.hia_native_worker_source_authority import load_native_source_authority, _object
from tools.generate_hia_sha256_stream import source_program
from tools.generate_hia_sha256 import INITIAL,ROUND
from tools.generate_hia_direct_load_plan import LinkerBuilder
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from hepta.hia_agent_assembly import render_assembly
import argparse
ROOT=Path(__file__).resolve().parents[1]
SOURCE = 'def entry(s:readbuf, o:mutbuf, w:mutbuf) -> u32:\n    if length(w) < 2097152 or length(o) < 33554432:\n        return 17\n    phase = get(w, 0)\n    mode = get(w, 16)\n    if phase == 0 and mode == 0:\n        if length(s) != 21 or uint(s, 0, 8) != 1 or uint(s, 8, 8) != 5 or uint(s, 16, 5) != 431315580258:\n            return 16\n        put(w, 16, 1)\n        return 0\n    if phase == 2 and mode == 3:\n        return 3\n    if phase != 1 or mode != 1:\n        return 16\n    if admit(s, o, w) == 0:\n        return 16\n    put(o, 0, MAGIC_ADC)\n    copy(s, o, 8, 32, 32)\n    put(o, 40, get(w, 152))\n    put(w, 0, 1)\n    put(w, 16, 3)\n    put(w, OUTPUT_SIZE_SLOT, 48)\n    return 3\n\ndef admit(s:readbuf, o:mutbuf, w:mutbuf) -> u64:\n    if length(s) < 96 or length(s) > 67108864 or uint(s, 0, 8) != MAGIC_CLD:\n        return 0\n    cold = uint(s, 8, 8)\n    inventory = uint(s, 16, 8)\n    contract = uint(s, 24, 8)\n    if cold < 2 or inventory < 16 or contract < 2 or cold > length(s) or inventory > length(s) or contract > length(s):\n        return 0\n    if cold + inventory + contract + 64 != length(s):\n        return 0\n    constants(w)\n    put(w, 136, 64 + cold)\n    put(w, 144, 64 + cold + inventory)\n    if pins(s, w, 64 + cold, inventory) == 0:\n        return 0\n    put(w, 128, 1)\n    root = json_parse(s, o, w, 64, 64 + cold)\n    if root == 0 or kind(o, root) != 3:\n        return 0\n    put(w, 160, root)\n    if text_field(s, o, w, root, 0, 10) == 0 or text_field(s, o, w, root, 1, 11) == 0 or text_field(s, o, w, root, 2, 12) == 0:\n        return 0\n    value = field(s, o, w, root, 3)\n    if value == 0 or kind(o, value) != 5 or zero_integer(s, o, value) == 0:\n        return 0\n    if checks(s, o, w, field(s, o, w, root, 4)) == 0:\n        return 0\n    value = field(s, o, w, root, 5)\n    if value == 0 or kind(o, value) != 4:\n        return 0\n    cursor = value + 1\n    count = 0\n    while cursor < following(o, value):\n        if pin_string(s, o, cursor, 32) == 0:\n            return 0\n        count = count + 1\n        cursor = following(o, cursor)\n    if count != 3:\n        return 0\n    if map_pins(s, o, w, field(s, o, w, root, 6), 0) == 0:\n        return 0\n    root = json_parse(s, o, w, get(w, 144), length(s))\n    if root == 0 or kind(o, root) != 3:\n        return 0\n    value = field(s, o, w, root, 7)\n    if value == 0 or kind(o, value) != 3:\n        return 0\n    value = field(s, o, w, value, 8)\n    if map_pins(s, o, w, value, 1) == 0:\n        return 0\n    put(w, 168, value)\n    digest(s, o, w, get(w, 144), length(s) - get(w, 144), 64)\n    cursor = get(w, 196608 + get(w, 176) * 24) - 32\n    if bytes_same(s, o, cursor, 64, 32) == 0:\n        return 0\n    count = canonical(s, o, w, root, get(w, 168))\n    if count == 0:\n        return 0\n    digest_mut(o, w, 16777216, count, 96)\n    if same_mut(o, w, 96, 1008192, 32) == 0:\n        return 0\n    return 1\n\ndef checks(s:readbuf, o:mutbuf, w:mutbuf, root:u64) -> u64:\n    if root == 0 or kind(o, root) != 3:\n        return 0\n    cursor = root + 1\n    while cursor < following(o, root):\n        i = 13\n        found = 0\n        while i < 24:\n            if text_equal(s, o, w, cursor, 1000000 + i * 256, constant_length(i)) != 0:\n                found = 1\n            i = i + 1\n        if found == 0:\n            return 0\n        cursor = following(o, cursor + 1)\n    i = 13\n    while i < 24:\n        value = field(s, o, w, root, i)\n        if value == 0 or kind(o, value) != 6:\n            return 0\n        i = i + 1\n    return 1\n\ndef pins(s:readbuf, w:mutbuf, at:u64, size:u64) -> u64:\n    if uint(s, at, 8) != MAGIC_SPI:\n        return 0\n    count = uint(s, at + 8, 8)\n    if count == 0 or count > 4096:\n        return 0\n    put(w, 152, count)\n    end = at + size\n    cursor = at + 16\n    i = 0\n    contract = 0\n    while i < count:\n        if cursor + 40 > end:\n            return 0\n        n = uint(s, cursor, 8)\n        if n == 0 or n > 4095 or cursor + 40 + n > end:\n            return 0\n        cursor = cursor + 40\n        if relative(s, cursor, n) == 0:\n            return 0\n        if i != 0:\n            previous = 196608 + (i - 1) * 24\n            if raw_compare(s, get(w, previous), get(w, previous + 8), cursor, n) != 1:\n                return 0\n        put(w, 196608 + i * 24, cursor)\n        put(w, 196608 + i * 24 + 8, n)\n        put(w, 196608 + i * 24 + 16, 0)\n        if n == constant_length(9) and raw_equal(s, w, cursor, 1000000 + 9 * 256, n) != 0:\n            put(w, 176, i)\n            contract = contract + 1\n        cursor = cursor + n\n        i = i + 1\n    return choose(cursor == end and contract == 1, 1, 0)\n\ndef relative(s:readbuf, at:u64, n:u64) -> u64:\n    i = 0\n    component = 0\n    while i < n:\n        ch = byte(s, at + i)\n        if ch == 47:\n            if component == 0 or (component == 1 and byte(s, at + i - 1) == 46) or (component == 2 and byte(s, at + i - 1) == 46 and byte(s, at + i - 2) == 46):\n                return 0\n            component = 0\n        else:\n            if (ch < 48 or ch > 57) and (ch < 65 or ch > 90) and (ch < 97 or ch > 122) and ch != 45 and ch != 46 and ch != 95:\n                return 0\n            component = component + 1\n        i = i + 1\n    if component == 0 or (component == 1 and byte(s, at + n - 1) == 46) or (component == 2 and byte(s, at + n - 1) == 46 and byte(s, at + n - 2) == 46):\n        return 0\n    return 1\n\ndef map_pins(s:readbuf, o:mutbuf, w:mutbuf, root:u64, contract:u64) -> u64:\n    if root == 0 or kind(o, root) != 3:\n        return 0\n    i = 0\n    while i < get(w, 152):\n        put(w, 196608 + i * 24 + 16, 0)\n        i = i + 1\n    cursor = root + 1\n    while cursor < following(o, root):\n        n = ascii_text(s, o, cursor, 65536, 4095)\n        if n == 18446744073709551615:\n            return 0\n        index = pin_find(s, o, w, n)\n        if index == 18446744073709551615 or (contract != 0 and index == get(w, 176)):\n            return 0\n        put(w, 196608 + index * 24 + 16, cursor + 1)\n        cursor = following(o, cursor + 1)\n    i = 0\n    while i < get(w, 152):\n        if contract == 0 or i != get(w, 176):\n            node = get(w, 196608 + i * 24 + 16)\n            if node == 0 or pin_string(s, o, node, get(w, 196608 + i * 24) - 32) == 0:\n                return 0\n        i = i + 1\n    return 1\n\ndef pin_find(s:readbuf, o:mutbuf, w:mutbuf, n:u64) -> u64:\n    low = 0\n    high = get(w, 152)\n    while low < high:\n        mid = (low + high) >> 1\n        order = cross_compare(s, o, get(w, 196608 + mid * 24), get(w, 196608 + mid * 24 + 8), 65536, n)\n        if order == 0:\n            return mid\n        if order == 1:\n            low = mid + 1\n        else:\n            high = mid\n    return 18446744073709551615\n\ndef json_parse(s:readbuf, o:mutbuf, w:mutbuf, start:u64, limit:u64) -> u64:\n    root = get(w, 128)\n    put(w, 256, start)\n    put(w, 264, 0)\n    put(w, 272, 1)\n    put(w, 280, 0)\n    while get(w, 280) == 0:\n        put(w, 256, whitespace(s, get(w, 256), limit))\n        result = 0\n        if get(w, 272) == 1:\n            result = json_value(s, o, w, limit)\n        else:\n            result = json_separator(s, o, w, limit)\n        if result == 0:\n            return 0\n    if whitespace(s, get(w, 256), limit) != limit:\n        return 0\n    return root\n\ndef json_value(s:readbuf, o:mutbuf, w:mutbuf, limit:u64) -> u64:\n    at = get(w, 256)\n    if at >= limit:\n        return 0\n    ch = byte(s, at)\n    if ch == 123 or ch == 91:\n        if get(w, 264) >= 1024:\n            return 0\n        node = new_node(o, w, choose(ch == 123, 3, 4), at)\n        if node == 0:\n            return 0\n        slot = 65536 + get(w, 264) * 24\n        put(w, slot, node)\n        put(w, slot + 8, choose(ch == 123, 3, 4))\n        put(w, slot + 16, 0)\n        put(w, 264, get(w, 264) + 1)\n        put(w, 256, at + 1)\n        put(w, 272, 0)\n        return 1\n    k = 0\n    end = 0\n    if ch == 34:\n        k = 2\n        end = string_end(s, at, limit)\n    elif ch == 116 and limit - at >= 4 and uint(s, at, 4) == 1702195828:\n        k = 6\n        end = at + 4\n    elif ch == 102 and limit - at >= 5 and uint(s, at, 5) == 435728179558:\n        k = 7\n        end = at + 5\n    elif ch == 110 and limit - at >= 4 and uint(s, at, 4) == 1819047278:\n        k = 8\n        end = at + 4\n    else:\n        k = 5\n        end = number_end(s, at, limit)\n    if end == 0:\n        return 0\n    node = new_node(o, w, k, at)\n    if node == 0:\n        return 0\n    put(o, 1048576 + node * 32 + 16, end)\n    put(o, 1048576 + node * 32 + 24, get(w, 128))\n    put(w, 256, end)\n    value_done(w)\n    return 1\n\ndef json_separator(s:readbuf, o:mutbuf, w:mutbuf, limit:u64) -> u64:\n    if get(w, 264) == 0 or get(w, 256) >= limit:\n        return 0\n    slot = 65536 + (get(w, 264) - 1) * 24\n    k = get(w, slot + 8)\n    state = get(w, slot + 16)\n    ch = byte(s, get(w, 256))\n    if state == 0 or state == 1:\n        if state == 0 and ((k == 3 and ch == 125) or (k == 4 and ch == 93)):\n            return close_container(o, w, slot)\n        if k == 4:\n            put(w, slot + 16, 4)\n            put(w, 272, 1)\n            return 1\n        if ch != 34:\n            return 0\n        end = string_end(s, get(w, 256), limit)\n        if end == 0:\n            return 0\n        node = new_node(o, w, 2, get(w, 256))\n        if node == 0:\n            return 0\n        put(o, 1048576 + node * 32 + 16, end)\n        put(o, 1048576 + node * 32 + 24, get(w, 128))\n        end = whitespace(s, end, limit)\n        if end >= limit or byte(s, end) != 58:\n            return 0\n        put(w, 256, end + 1)\n        put(w, slot + 16, 4)\n        put(w, 272, 1)\n        return 1\n    if state != 5:\n        return 0\n    if ch == 44:\n        put(w, 256, get(w, 256) + 1)\n        put(w, slot + 16, 1)\n        return 1\n    if (k == 3 and ch == 125) or (k == 4 and ch == 93):\n        return close_container(o, w, slot)\n    return 0\n\ndef close_container(o:mutbuf, w:mutbuf, slot:u64) -> u64:\n    node = get(w, slot)\n    put(o, 1048576 + node * 32 + 16, get(w, 256) + 1)\n    put(o, 1048576 + node * 32 + 24, get(w, 128))\n    put(w, 256, get(w, 256) + 1)\n    put(w, 264, get(w, 264) - 1)\n    value_done(w)\n    return 1\n\ndef value_done(w:mutbuf) -> u64:\n    put(w, 272, 0)\n    if get(w, 264) == 0:\n        put(w, 280, 1)\n    else:\n        put(w, 65536 + (get(w, 264) - 1) * 24 + 16, 5)\n    return 0\n\ndef new_node(o:mutbuf, w:mutbuf, k:u64, at:u64) -> u64:\n    node = get(w, 128)\n    if node >= 262144:\n        return 0\n    put(o, 1048576 + node * 32, k)\n    put(o, 1048576 + node * 32 + 8, at)\n    put(w, 128, node + 1)\n    return node\n\ndef number_end(s:readbuf, at:u64, limit:u64) -> u64:\n    if byte(s, at) == 45:\n        at = at + 1\n    if at >= limit or byte(s, at) < 48 or byte(s, at) > 57:\n        return 0\n    if byte(s, at) == 48:\n        at = at + 1\n    else:\n        while at < limit and byte(s, at) >= 48 and byte(s, at) <= 57:\n            at = at + 1\n    if at < limit and byte(s, at) == 46:\n        at = at + 1\n        start = at\n        while at < limit and byte(s, at) >= 48 and byte(s, at) <= 57:\n            at = at + 1\n        if at == start:\n            return 0\n    if at < limit and (byte(s, at) == 69 or byte(s, at) == 101):\n        at = at + 1\n        if at < limit and (byte(s, at) == 43 or byte(s, at) == 45):\n            at = at + 1\n        start = at\n        while at < limit and byte(s, at) >= 48 and byte(s, at) <= 57:\n            at = at + 1\n        if at == start:\n            return 0\n    return at\n\ndef string_end(s:readbuf, at:u64, limit:u64) -> u64:\n    at = at + 1\n    while at < limit:\n        unit = decoded(s, at)\n        cp = unit & 4294967295\n        at = unit >> 32\n        if cp == 1114113 or at > limit:\n            return 0\n        if cp == 1114112:\n            return at\n    return 0\n\ndef whitespace(s:readbuf, at:u64, limit:u64) -> u64:\n    more = 1\n    while at < limit and more != 0:\n        ch = byte(s, at)\n        if ch == 32 or ch == 9 or ch == 10 or ch == 13:\n            at = at + 1\n        else:\n            more = 0\n    return at\n\n\ndef canonical(s:readbuf, o:mutbuf, w:mutbuf, root:u64, skip:u64) -> u64:\n    put(w, 288, 0)\n    put(w, 296, 16777216)\n    if push_canon(w, root) == 0:\n        return 0\n    while get(w, 288) != 0:\n        slot = 327680 + (get(w, 288) - 1) * 32\n        node = get(w, slot)\n        result = 0\n        if kind(o, node) == 3:\n            result = canon_object(s, o, w, slot, skip)\n        elif kind(o, node) == 4:\n            result = canon_array(o, w, slot)\n        else:\n            if kind(o, node) == 2:\n                result = emit_string(s, o, w, node)\n            elif kind(o, node) == 5 and zero_integer(s, o, node) != 0:\n                result = emit_byte(o, w, 48)\n            else:\n                result = emit_raw(s, o, w, token_start(o, node), token_end(o, node) - token_start(o, node))\n            put(w, 288, get(w, 288) - 1)\n        if result == 0:\n            return 0\n    return get(w, 296) - 16777216\n\ndef canon_object(s:readbuf, o:mutbuf, w:mutbuf, slot:u64, skip:u64) -> u64:\n    if get(w, slot + 24) == 0:\n        if emit_byte(o, w, 123) == 0:\n            return 0\n        put(w, slot + 24, 1)\n    node = get(w, slot)\n    cursor = node + 1\n    best = 0\n    while cursor < following(o, node):\n        take = 1\n        if node == get(w, 184) and string_compare(s, token_start(o, cursor), token_start(o, skip - 1)) == 0:\n            take = 0\n        if get(w, slot + 8) != 0 and string_compare(s, token_start(o, cursor), token_start(o, get(w, slot + 8))) != 2:\n            take = 0\n        if take != 0:\n            if best == 0 or string_compare(s, token_start(o, cursor), token_start(o, best)) != 2:\n                best = cursor\n        cursor = following(o, cursor + 1)\n    if best == 0:\n        put(w, 288, get(w, 288) - 1)\n        return emit_byte(o, w, 125)\n    if get(w, slot + 16) != 0 and emit_byte(o, w, 44) == 0:\n        return 0\n    if emit_string(s, o, w, best) == 0 or emit_byte(o, w, 58) == 0:\n        return 0\n    put(w, slot + 8, best)\n    put(w, slot + 16, get(w, slot + 16) + 1)\n    return push_canon(w, best + 1)\n\ndef canon_array(o:mutbuf, w:mutbuf, slot:u64) -> u64:\n    if get(w, slot + 24) == 0:\n        if emit_byte(o, w, 91) == 0:\n            return 0\n        put(w, slot + 24, 1)\n        put(w, slot + 8, get(w, slot) + 1)\n    node = get(w, slot + 8)\n    if node >= following(o, get(w, slot)):\n        put(w, 288, get(w, 288) - 1)\n        return emit_byte(o, w, 93)\n    if get(w, slot + 16) != 0 and emit_byte(o, w, 44) == 0:\n        return 0\n    put(w, slot + 8, following(o, node))\n    put(w, slot + 16, get(w, slot + 16) + 1)\n    return push_canon(w, node)\n\ndef push_canon(w:mutbuf, node:u64) -> u64:\n    if get(w, 288) >= 1024:\n        return 0\n    slot = 327680 + get(w, 288) * 32\n    put(w, slot, node)\n    put(w, slot + 8, 0)\n    put(w, slot + 16, 0)\n    put(w, slot + 24, 0)\n    put(w, 288, get(w, 288) + 1)\n    return 1\n\ndef emit_string(s:readbuf, o:mutbuf, w:mutbuf, node:u64) -> u64:\n    if emit_byte(o, w, 34) == 0:\n        return 0\n    at = token_start(o, node) + 1\n    while at < token_end(o, node):\n        unit = decoded(s, at)\n        cp = unit & 4294967295\n        at = unit >> 32\n        if cp == 1114112:\n            return emit_byte(o, w, 34)\n        if cp == 1114113 or emit_scalar(o, w, cp) == 0:\n            return 0\n    return 0\n\ndef emit_scalar(o:mutbuf, w:mutbuf, cp:u64) -> u64:\n    if cp == 34 or cp == 92:\n        if emit_byte(o, w, 92) == 0:\n            return 0\n        return emit_byte(o, w, cp)\n    if cp < 32:\n        if emit_byte(o, w, 92) == 0:\n            return 0\n        ch = 0\n        if cp == 8:\n            ch = 98\n        elif cp == 9:\n            ch = 116\n        elif cp == 10:\n            ch = 110\n        elif cp == 12:\n            ch = 102\n        elif cp == 13:\n            ch = 114\n        if ch != 0:\n            return emit_byte(o, w, ch)\n        if emit_byte(o, w, 117) == 0 or emit_byte(o, w, 48) == 0 or emit_byte(o, w, 48) == 0 or emit_byte(o, w, hex_digit(cp >> 4)) == 0:\n            return 0\n        return emit_byte(o, w, hex_digit(cp & 15))\n    if cp < 128:\n        return emit_byte(o, w, cp)\n    if cp < 2048:\n        if emit_byte(o, w, 192 | (cp >> 6)) == 0:\n            return 0\n    elif cp < 65536:\n        if emit_byte(o, w, 224 | (cp >> 12)) == 0 or emit_byte(o, w, 128 | ((cp >> 6) & 63)) == 0:\n            return 0\n    else:\n        if emit_byte(o, w, 240 | (cp >> 18)) == 0 or emit_byte(o, w, 128 | ((cp >> 12) & 63)) == 0 or emit_byte(o, w, 128 | ((cp >> 6) & 63)) == 0:\n            return 0\n    return emit_byte(o, w, 128 | (cp & 63))\n\ndef emit_byte(o:mutbuf, w:mutbuf, value:u64) -> u64:\n    at = get(w, 296)\n    if at >= 33554432:\n        return 0\n    store(o, at, value)\n    put(w, 296, at + 1)\n    return 1\n\ndef emit_raw(s:readbuf, o:mutbuf, w:mutbuf, at:u64, n:u64) -> u64:\n    i = 0\n    while i < n:\n        if emit_byte(o, w, byte(s, at + i)) == 0:\n            return 0\n        i = i + 1\n    return 1\n\ndef field(s:readbuf, o:mutbuf, w:mutbuf, root:u64, name:u64) -> u64:\n    if root == 0 or kind(o, root) != 3:\n        return 0\n    cursor = root + 1\n    found = 0\n    while cursor < following(o, root):\n        if text_equal(s, o, w, cursor, 1000000 + name * 256, constant_length(name)) != 0:\n            found = cursor + 1\n        cursor = following(o, cursor + 1)\n    return found\n\ndef text_field(s:readbuf, o:mutbuf, w:mutbuf, root:u64, name:u64, expected:u64) -> u64:\n    return text_equal(s, o, w, field(s, o, w, root, name), 1000000 + expected * 256, constant_length(expected))\n\ndef text_equal(s:readbuf, o:mutbuf, w:mutbuf, node:u64, at:u64, n:u64) -> u64:\n    if node == 0 or kind(o, node) != 2:\n        return 0\n    source = token_start(o, node) + 1\n    i = 0\n    while source < token_end(o, node):\n        unit = decoded(s, source)\n        cp = unit & 4294967295\n        source = unit >> 32\n        if cp == 1114112:\n            return choose(i == n, 1, 0)\n        if cp == 1114113 or i >= n or cp != byte(w, at + i):\n            return 0\n        i = i + 1\n    return 0\n\ndef ascii_text(s:readbuf, o:mutbuf, node:u64, at:u64, capacity:u64) -> u64:\n    if kind(o, node) != 2:\n        return 18446744073709551615\n    source = token_start(o, node) + 1\n    n = 0\n    while source < token_end(o, node):\n        unit = decoded(s, source)\n        cp = unit & 4294967295\n        source = unit >> 32\n        if cp == 1114112:\n            return n\n        if cp > 127 or n >= capacity:\n            return 18446744073709551615\n        store(o, at + n, cp)\n        n = n + 1\n    return 18446744073709551615\n\ndef pin_string(s:readbuf, o:mutbuf, node:u64, pin:u64) -> u64:\n    if node == 0 or kind(o, node) != 2:\n        return 0\n    source = token_start(o, node) + 1\n    i = 0\n    while i < 64:\n        unit = decoded(s, source)\n        source = unit >> 32\n        cp = unit & 4294967295\n        value = byte(s, pin + (i >> 1))\n        expected = choose((i & 1) == 0, hex_digit(value >> 4), hex_digit(value & 15))\n        if cp != expected:\n            return 0\n        i = i + 1\n    unit = decoded(s, source)\n    return choose((unit & 4294967295) == 1114112, 1, 0)\n\ndef string_compare(s:readbuf, a:u64, b:u64) -> u64:\n    a = a + 1\n    b = b + 1\n    while True:\n        x = decoded(s, a)\n        y = decoded(s, b)\n        a = x >> 32\n        b = y >> 32\n        x = x & 4294967295\n        y = y & 4294967295\n        if x == 1114112 and y == 1114112:\n            return 0\n        if x == 1114112:\n            return 1\n        if y == 1114112:\n            return 2\n        if x < y:\n            return 1\n        if x > y:\n            return 2\n    return 0\n\ndef zero_integer(s:readbuf, o:mutbuf, node:u64) -> u64:\n    at = token_start(o, node)\n    n = token_end(o, node) - at\n    if n == 1 and byte(s, at) == 48:\n        return 1\n    return choose(n == 2 and byte(s, at) == 45 and byte(s, at + 1) == 48, 1, 0)\n\ndef raw_compare(s:readbuf, a:u64, an:u64, b:u64, bn:u64) -> u64:\n    i = 0\n    while i < an and i < bn:\n        if byte(s, a + i) < byte(s, b + i):\n            return 1\n        if byte(s, a + i) > byte(s, b + i):\n            return 2\n        i = i + 1\n    return choose(an == bn, 0, choose(an < bn, 1, 2))\n\ndef cross_compare(s:readbuf, o:mutbuf, a:u64, an:u64, b:u64, bn:u64) -> u64:\n    i = 0\n    while i < an and i < bn:\n        if byte(s, a + i) < byte(o, b + i):\n            return 1\n        if byte(s, a + i) > byte(o, b + i):\n            return 2\n        i = i + 1\n    return choose(an == bn, 0, choose(an < bn, 1, 2))\n\ndef raw_equal(s:readbuf, w:mutbuf, a:u64, b:u64, n:u64) -> u64:\n    i = 0\n    while i < n:\n        if byte(s, a + i) != byte(w, b + i):\n            return 0\n        i = i + 1\n    return 1\n\ndef bytes_same(s:readbuf, o:mutbuf, a:u64, b:u64, n:u64) -> u64:\n    i = 0\n    while i < n:\n        if byte(s, a + i) != byte(o, b + i):\n            return 0\n        i = i + 1\n    return 1\n\ndef same_mut(a:mutbuf, b:mutbuf, ai:u64, bi:u64, n:u64) -> u64:\n    i = 0\n    while i < n:\n        if byte(a, ai + i) != byte(b, bi + i):\n            return 0\n        i = i + 1\n    return 1\n\ndef kind(o:mutbuf, node:u64) -> u64:\n    return get(o, 1048576 + node * 32)\n\ndef token_start(o:mutbuf, node:u64) -> u64:\n    return get(o, 1048576 + node * 32 + 8)\n\ndef token_end(o:mutbuf, node:u64) -> u64:\n    return get(o, 1048576 + node * 32 + 16)\n\ndef following(o:mutbuf, node:u64) -> u64:\n    return get(o, 1048576 + node * 32 + 24)\n\ndef hex_digit(n:u64) -> u64:\n    return choose(n < 10, 48 + n, 87 + n)\n\ndef copy(s:readbuf, o:mutbuf, at:u64, source:u64, n:u64) -> u64:\n    i = 0\n    while i < n:\n        store(o, at + i, byte(s, source + i))\n        i = i + 1\n    return 0\n\ndef uint(s:readbuf, at:u64, n:u64) -> u64:\n    i = 0\n    value = 0\n    while i < n:\n        value = value | (byte(s, at + i) << (i * 8))\n        i = i + 1\n    return value\n\ndef get(w:mutbuf, at:u64) -> u64:\n    return word_load(w, at)\n\ndef put(w:mutbuf, at:u64, value:u64) -> u64:\n    i = 0\n    while i < 8:\n        store(w, at + i, (value >> (i * 8)) & 255)\n        i = i + 1\n    return 0\n\n'

NATIVE_METADATA = 'docs/HIA_NATIVE_SELFHOST_METADATA.json'


def native_authority_contract(root, authority_path):
    """Bind native admission to the explicit catalog and its captured metadata.

    This authoring helper does not become a native source dependency.  The
    emitted HIA policy retains the full cold-report, source-map, metadata and
    B3 checks; only the explicitly selected source catalog changes.
    """
    root = Path(root).resolve(strict=True)
    paths = load_native_source_authority(authority_path)
    if CONTRACT_PATH not in paths or NATIVE_METADATA not in paths:
        raise ValueError('native cold admission requires the frozen contract and native metadata')
    pins = {}
    metadata_raw = None
    for name in paths:
        path = root / name
        for part in (path, *path.parents):
            if part == root:
                break
            if part.is_symlink():
                raise ValueError('native cold admission source must not be a symlink: ' + name)
        try:
            mode = path.stat().st_mode
        except OSError as exc:
            raise ValueError('native cold admission source is missing: ' + name) from exc
        if not stat.S_ISREG(mode) or not path.resolve(strict=True).is_relative_to(root):
            raise ValueError('native cold admission requires a regular source within its root: ' + name)
        raw = path.read_bytes()
        if name == NATIVE_METADATA:
            metadata_raw = raw
        if name != CONTRACT_PATH:
            pins[name] = sha256(raw).hexdigest()
    metadata = json.loads(metadata_raw, object_pairs_hook=_object)
    if (type(metadata) is not dict or type(metadata.get('source_identity')) is not dict
            or metadata['source_identity'].get('files') != {}):
        raise ValueError('native selfhost metadata must contain an empty source_identity.files map')
    contract = copy.deepcopy(metadata)
    contract['source_identity']['files'] = pins
    return contract


def render(root, *, native_source_authority=None, hosted_report_encodings=True):
    F = root
    base = SOURCE
    if hosted_report_encodings:
        original = "    root = json_parse(s, o, w, 64, 64 + cold)"
        compatible = "    cold_start = 64\n    if cold >= 3 and uint(s, 64, 3) == 12565487:\n        cold_start = 67\n    root = json_parse(s, o, w, cold_start, 64 + cold)"
        assert base.count(original) == 1
        base = base.replace(original, compatible, 1)
    base = base.replace('put(w, OUTPUT_SIZE_SLOT, 48)\n    return 3', 'put(w, 88, 48)\n    return 0', 1)
    base = base.replace('pins(s, w, 64 + cold, inventory)', 'pins(s, o, w, 64 + cold, inventory)', 1)
    base = base.replace('def pins(s:readbuf, w:mutbuf, at:u64, size:u64)', 'def pins(s:readbuf, o:mutbuf, w:mutbuf, at:u64, size:u64)', 1)
    base = base.replace('    put(w, 152, count)\n', '    put(w, 152, count)\n    put(w, 304, 16777216)\n', 1)
    base = base.replace('        put(w, 196608 + i * 24, cursor)\n', '        put(o, get(w, 304), n)\n        copy(s, o, get(w, 304) + 8, cursor, n)\n        put(w, 304, get(w, 304) + 8 + n)\n        put(w, 196608 + i * 24, cursor)\n', 1)
    base = base.replace('    put(w, 128, 1)\n', '    if get(w, 152) != EXPECTED_SOURCE_COUNT:\n        return 0\n    digest_mut(o, w, 16777216, get(w, 304) - 16777216, 96)\n    if same_mut(o, w, 96, 1008224, 32) == 0:\n        return 0\n    put(w, 128, 1)\n', 1)
    base = base.replace('    value = field(s, o, w, value, 8)\n', '    put(w, 184, value)\n    value = field(s, o, w, value, 8)\n', 1)
    contract = (support_contract(F) if native_source_authority is None else
                native_authority_contract(F, native_source_authority))
    names = sorted([*contract['source_identity']['files'], CONTRACT_PATH])
    del contract['source_identity']['files']

    def equality_normalize(value):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, dict):
            return {k: equality_normalize(v) for k, v in value.items()}
        if isinstance(value, list):
            return [equality_normalize(v) for v in value]
        return value
    metadata = json.dumps(equality_normalize(contract), sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    path_bytes = b''.join((struct.pack('<Q', len(name.encode())) + name.encode() for name in names))
    metadata_pin = sha256(metadata).digest()
    paths_pin = sha256(path_bytes).digest()
    strings = ['schema', 'profile', 'status', 'returncode', 'checks', 'generation_sha256', 'source_manifest', 'source_identity', 'files', CONTRACT_PATH, 'hepta.hia.selfhost-cold-replay.v1', contract['profile'], 'COLD_SELFHOST_REPLAY_PASS', 'export_manifest_matches_qualification', 'isolated_python_without_site', 'nested_full_qualification_pass', 'nested_process_exit_zero', 'no_ancestor_git_identity', 'no_bytecode_cache_created', 'no_inherited_home_or_python_cache', 'no_inherited_seed_or_successor_images', 'origin_hashes_preserved', 'owned_process_tree_cleanup_confirmed', 'source_export_hashes_preserved']
    constants = '\ndef constants(w:mutbuf) -> u64:\n'
    for i, value in enumerate(strings):
        raw = value.encode()
        for j in range(0, len(raw), 8):
            part = raw[j:j + 8]
            if len(part) == 8:
                constants += f"    put(w, {1000000 + i * 256 + j}, {int.from_bytes(part, 'little')})\n"
            else:
                for k, ch in enumerate(part):
                    constants += f'    store(w, {1000000 + i * 256 + j + k}, {ch})\n'
    for at, data in [(1008192, metadata_pin), (1008224, paths_pin)]:
        for off in range(0, len(data), 8):
            constants += f"    put(w, {at + off}, {int.from_bytes(data[off:off + 8], 'little')})\n"
    constants += '    return 0\n\ndef constant_length(i:u64) -> u64:\n'
    for i, value in enumerate(strings):
        constants += f'    if i == {i}:\n        return {len(value.encode())}\n'
    constants += '    return 0\n'
    json_source = (F / 'tools/generate_hia_json_preflight.py').read_text()
    decoder = ''
    for n in ast.parse(json_source).body:
        if isinstance(n, ast.Assign) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str) and ('def preflight' in n.value.value):
            value = n.value.value
            for f in ast.parse(value).body:
                if f.name in ('decoded', 'hex4'):
                    decoder += '\n' + ast.get_source_segment(value, f) + '\n'
    if hosted_report_encodings:
        # json.loads(bytes) uses surrogatepass for the cold report. Keep the
        # contract's text decoder strict, and only relax the report's own range.
        def replace_decoder(old, new, count=1):
            nonlocal decoder
            assert decoder.count(old) == count, old
            decoder = decoder.replace(old, new)
        replace_decoder('    size = length(s)\n', '    size = length(s)\n    cold_string = 0\n    if index >= 64 and index < 64 + uint(s, 8, 8):\n        cold_string = 1\n')
        replace_decoder('                return (6 << 32) | 1114113\n', '                if cold_string != 0:\n                    return (index << 32) | cp\n                return (6 << 32) | 1114113\n', 3)
        replace_decoder('                return (7 << 32) | 1114113\n', '                if cold_string != 0:\n                    return (index << 32) | cp\n                return (7 << 32) | 1114113\n')
        replace_decoder('    if cp >= 55296 and cp <= 57343:\n        return (20 << 32) | 1114113\n', '    if cp >= 55296 and cp <= 57343 and cold_string == 0:\n        return (20 << 32) | 1114113\n')
    sha_nodes = [n for n in ast.parse(source_program()).body if n.name != 'stream']
    sha_names = {n.name: 'sha_' + n.name for n in sha_nodes}

    class RenameSHA(ast.NodeTransformer):

        def visit_FunctionDef(self, node):
            node = copy.deepcopy(node)
            node.name = sha_names[node.name]
            return self.generic_visit(node)

        def visit_Call(self, node):
            node = self.generic_visit(node)
            if isinstance(node.func, ast.Name):
                name = node.func.id
                if name in ('byte', 'store', 'word_load') and isinstance(node.args[0], ast.Name) and (node.args[0].id == 'w'):
                    node.args[1] = ast.BinOp(left=ast.Constant(value=4096), op=ast.Add(), right=node.args[1])
                if name in sha_names:
                    node.func.id = sha_names[name]
            return node
    sha_helpers = '\n' + '\n\n'.join((ast.unparse(ast.fix_missing_locations(RenameSHA().visit(n))) for n in sha_nodes)) + '\n'
    digest = '\ndef digest(s:readbuf, o:mutbuf, w:mutbuf, start:u64, count:u64, out:u64) -> u64:\n'
    for i, v in enumerate(ROUND):
        digest += f'    sha_put(w, {i * 8}, {v})\n'
    for i, v in enumerate(INITIAL):
        digest += f'    sha_put(w, {1024 + i * 8}, {v})\n'
    digest += '    used = 0\n    i = 0\n    while i < count:\n        store(w, 5208 + used, byte(s, start + i))\n        used = used + 1\n        if used == 64:\n            sha_compress(w)\n            used = 0\n        i = i + 1\n    store(w, 5208 + used, 128)\n    used = used + 1\n    while used != 56:\n        if used == 64:\n            sha_compress(w)\n            used = 0\n        else:\n            store(w, 5208 + used, 0)\n            used = used + 1\n    bits = count << 3\n    i = 0\n    while i < 8:\n        store(w, 5264 + i, (bits >> ((7 - i) * 8)) & 255)\n        i = i + 1\n    sha_compress(w)\n    i = 0\n    while i < 8:\n        value = sha_get(w, 1024 + i * 8)\n        j = 0\n        while j < 4:\n            store(o, out + i * 4 + j, (value >> ((3 - j) * 8)) & 255)\n            j = j + 1\n        i = i + 1\n    return 0\n'
    init = digest[digest.index('    sha_put'):digest.index('    used = 0')]
    feed = digest[digest.index('    used = 0'):digest.index('    store(w, 5208 + used, 128)')]
    finish = digest[digest.index('    store(w, 5208 + used, 128)'):]
    readfeed = 'def digest_feed(s:readbuf, w:mutbuf, start:u64, count:u64) -> u64:\n' + feed + '    return 0\n'
    mutfeed = readfeed.replace('digest_feed(s:readbuf', 'digest_feed_mut(s:mutbuf', 1)
    digest = '\ndef digest_init(w:mutbuf) -> u64:\n' + init + '    return 0\n\n' + readfeed + '\n' + mutfeed
    digest += '\ndef digest_finish(o:mutbuf, w:mutbuf, count:u64, out:u64) -> u64:\n    used = count & 63\n' + finish
    digest += '\ndef digest(s:readbuf, o:mutbuf, w:mutbuf, start:u64, count:u64, out:u64) -> u64:\n    digest_init(w)\n    digest_feed(s, w, start, count)\n    return digest_finish(o, w, count, out)\n'
    digest += '\ndef digest_mut(o:mutbuf, w:mutbuf, start:u64, count:u64, out:u64) -> u64:\n    digest_init(w)\n    digest_feed_mut(o, w, start, count)\n    return digest_finish(o, w, count, out)\n'
    from tools.generate_hia_agent_binary64 import source_program as binary64_source
    binary_nodes = ast.parse(binary64_source()).body
    binary_names = {n.name: 'b64_' + n.name for n in binary_nodes}

    class Binary64Slice(ast.NodeTransformer):

        def visit_FunctionDef(self, node):
            node = copy.deepcopy(node)
            if node.name == 'convert':
                node.returns = ast.Name(id='u64', ctx=ast.Load())
                node.args.args = [a for a in node.args.args if a.arg != 'o']
                node.args.args.extend([ast.arg(arg='start', annotation=ast.Name(id='u64', ctx=ast.Load())), ast.arg(arg='count', annotation=ast.Name(id='u64', ctx=ast.Load()))])
                node.body = [stmt for stmt in node.body if not (isinstance(stmt, ast.If) and 'length(o)' in ast.unparse(stmt.test))]
            node.name = binary_names[node.name]
            return self.generic_visit(node)

        def visit_Constant(self, node):
            if node.value == 8388608:
                return ast.copy_location(ast.Constant(value=67108864), node)
            return node

        def visit_Call(self, node):
            node = self.generic_visit(node)
            if isinstance(node.func, ast.Name):
                name = node.func.id
                if name == 'length' and isinstance(node.args[0], ast.Name) and (node.args[0].id == 's'):
                    return ast.Name(id='count', ctx=ast.Load())
                if name == 'byte' and isinstance(node.args[0], ast.Name) and (node.args[0].id == 's'):
                    node.args[1] = ast.BinOp(left=ast.Name(id='start', ctx=ast.Load()), op=ast.Add(), right=node.args[1])
                if name == 'put' and isinstance(node.args[0], ast.Name) and (node.args[0].id == 'o'):
                    node.args[0] = ast.Name(id='w', ctx=ast.Load())
                    node.args[1] = ast.Constant(value=3200)
                if name in ('byte', 'store', 'word_load') and isinstance(node.args[0], ast.Name) and (node.args[0].id == 'w'):
                    node.args[1] = ast.BinOp(left=ast.Constant(value=1200000), op=ast.Add(), right=node.args[1])
                if name in binary_names:
                    node.func.id = binary_names[name]
            return node
    binary_helpers = '\n' + '\n\n'.join((ast.unparse(ast.fix_missing_locations(Binary64Slice().visit(n))) for n in binary_nodes)) + '\n'
    numeric = '\ndef emit_number(s:readbuf, o:mutbuf, w:mutbuf, node:u64) -> u64:\n    start = token_start(o, node)\n    count = token_end(o, node) - start\n    floating = 0\n    i = 0\n    while i < count:\n        ch = byte(s, start + i)\n        if ch == 46 or ch == 69 or ch == 101:\n            floating = 1\n        i = i + 1\n    if floating == 0:\n        if zero_integer(s, o, node) != 0:\n            return emit_byte(o, w, 48)\n        return emit_raw(s, o, w, start, count)\n    if b64_convert(s, w, start, count) != 8:\n        return 0\n    bits = b64_get(w, 3200)\n    magnitude = bits & 9223372036854775807\n    if magnitude == 0:\n        return emit_byte(o, w, 48)\n    exponent = (magnitude >> 52) & 2047\n    if exponent < 1023 or exponent > 1086:\n        return 0\n    value = (magnitude & 4503599627370495) | 4503599627370496\n    if exponent < 1075:\n        shift = 1075 - exponent\n        if (value & ((1 << shift) - 1)) != 0:\n            return 0\n        value = value >> shift\n    else:\n        value = value << (exponent - 1075)\n    if (bits >> 63) != 0 and emit_byte(o, w, 45) == 0:\n        return 0\n    return emit_integer(o, w, value)\n\ndef emit_integer(o:mutbuf, w:mutbuf, value:u64) -> u64:\n    position = 19\n    while position > 0 and decimal_power(position) > value:\n        position = position - 1\n    while True:\n        digit = 0\n        power = decimal_power(position)\n        while value >= power:\n            value = value - power\n            digit = digit + 1\n        if emit_byte(o, w, 48 + digit) == 0:\n            return 0\n        if position == 0:\n            return 1\n        position = position - 1\n    return 0\n\ndef decimal_power(position:u64) -> u64:\n'
    for i in range(20):
        numeric += f'    if position == {i}:\n        return {10 ** i}\n'
    numeric += '    return 0\n'
    base = base.replace('            elif kind(o, node) == 5 and zero_integer(s, o, node) != 0:\n                result = emit_byte(o, w, 48)', '            elif kind(o, node) == 5:\n                result = emit_number(s, o, w, node)\n            elif kind(o, node) == 6 or kind(o, node) == 7:\n                result = emit_byte(o, w, choose(kind(o, node) == 6, 49, 48))')
    base = base.replace('    else:\n        k = 5\n        end = number_end(s, at, limit)', f"    elif ch == 78 and limit - at >= 3 and uint(s, at, 3) == {int.from_bytes(b'NaN', 'little')}:\n        k = 9\n        end = at + 3\n    elif ch == 73 and limit - at >= 8 and uint(s, at, 8) == {int.from_bytes(b'Infinity', 'little')}:\n        k = 9\n        end = at + 8\n    elif ch == 45 and limit - at >= 9 and uint(s, at + 1, 8) == {int.from_bytes(b'Infinity', 'little')}:\n        k = 9\n        end = at + 9\n    else:\n        k = 5\n        end = number_end(s, at, limit)", 1)
    source = base + constants + decoder + digest + sha_helpers + numeric + binary_helpers
    for name, value in {'MAGIC_ADC': int.from_bytes(b'HIAADC01', 'little'), 'MAGIC_CLD': int.from_bytes(b'HIACLD01', 'little'), 'MAGIC_SPI': int.from_bytes(b'HIASPI01', 'little'), 'EXPECTED_SOURCE_COUNT': len(names)}.items():
        source = source.replace(name, str(value))
    if hosted_report_encodings:
        # Only JSON token access uses tagged logical positions. The frame, inventory,
        # original contract bytes and digest paths continue to use physical positions.
        old = '    cold_start = 64\n    if cold >= 3 and uint(s, 64, 3) == 12565487:\n        cold_start = 67\n    root = json_parse(s, o, w, cold_start, 64 + cold)'
        new = '    cold_start = report_start(s)\n    cold_limit = report_end(s)\n    if cold_start >= cold_limit:\n        return 0\n    root = json_parse(s, o, w, cold_start, cold_limit)'
        assert source.count(old) == 1
        source = source.replace(old, new)
        logical_byte_functions = {'json_value','json_separator','number_end','whitespace','zero_integer','decoded','hex4'}
        class LogicalTokens(ast.NodeTransformer):
            def visit_FunctionDef(self, node):
                if node.name not in logical_byte_functions:
                    return node
                self.current = node.name
                return self.generic_visit(node)
            def visit_Call(self, node):
                node = self.generic_visit(node)
                if isinstance(node.func, ast.Name) and node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == 's':
                    if node.func.id == 'byte':
                        node.func.id = 'json_byte'
                    elif node.func.id == 'uint' and self.current == 'json_value':
                        node.func.id = 'json_uint'
                    elif node.func.id == 'length' and self.current in {'decoded','hex4'}:
                        node.func.id = 'json_size'
                        node.args.append(ast.Name(id='index',ctx=ast.Load()))
                return node
        source = source.replace('if index >= 64 and index < 64 + uint(s, 8, 8):', 'if index >= 268435456 or (index >= 64 and index < 64 + uint(s, 8, 8)):')
        needle = '    if ch < 128:\n        return (index << 32) | ch\n    needed = 0'
        wide = '    if index >= 268435456:\n        if ch > 1114111:\n            return (20 << 32) | 1114113\n        if index < 805306368 and ch >= 55296 and ch <= 56319 and index < size:\n            low = byte(s, index)\n            if low >= 56320 and low <= 57343:\n                ch = 65536 + (ch - 55296) * 1024 + low - 56320\n                index = index + 1\n        return (index << 32) | ch\n'
        assert source.count(needle) == 1
        source = source.replace(needle, wide + needle)
        source = ast.unparse(ast.fix_missing_locations(LogicalTokens().visit(ast.parse(source)))) + '\n'
        source += '\ndef report_tag(s:readbuf) -> u64:\n    n = uint(s, 8, 8)\n    if n >= 4:\n        if uint(s, 64, 4) == 65279:\n            return 805306368\n        if uint(s, 64, 4) == 4294836224:\n            return 1073741824\n    if n >= 2:\n        if uint(s, 64, 2) == 65279:\n            return 268435456\n        if uint(s, 64, 2) == 65534:\n            return 536870912\n    if n >= 4:\n        if byte(s, 64) == 0:\n            if byte(s, 65) == 0:\n                return 1073741824\n            return 536870912\n        if byte(s, 65) == 0:\n            if byte(s, 66) == 0 and byte(s, 67) == 0:\n                return 805306368\n            return 268435456\n    elif n >= 2:\n        if byte(s, 64) == 0:\n            return 536870912\n        if byte(s, 65) == 0:\n            return 268435456\n    return 0\n\ndef report_start(s:readbuf) -> u64:\n    tag = report_tag(s)\n    if tag == 0:\n        if uint(s, 8, 8) >= 3 and uint(s, 64, 3) == 12565487:\n            return 67\n        return 64\n    if tag == 805306368 and uint(s, 64, 4) == 65279:\n        return tag + 1\n    if tag == 1073741824 and uint(s, 64, 4) == 4294836224:\n        return tag + 1\n    if tag == 268435456 and uint(s, 64, 2) == 65279:\n        return tag + 1\n    if tag == 536870912 and uint(s, 64, 2) == 65534:\n        return tag + 1\n    return tag\n\ndef report_end(s:readbuf) -> u64:\n    tag = report_tag(s)\n    n = uint(s, 8, 8)\n    if tag == 0:\n        return 64 + n\n    width = choose(tag < 805306368, 2, 4)\n    if (n & (width - 1)) != 0:\n        return 0\n    return tag + (n >> choose(width == 2, 1, 2))\n\ndef json_size(s:readbuf, at:u64) -> u64:\n    if at >= 268435456:\n        return report_end(s)\n    if at >= 64 and at < 64 + uint(s, 8, 8):\n        return 64 + uint(s, 8, 8)\n    return length(s)\n\ndef json_byte(s:readbuf, at:u64) -> u64:\n    if at < 268435456:\n        return byte(s, at)\n    tag = at & 4026531840\n    width = choose(tag < 805306368, 2, 4)\n    offset = (at & 268435455) * width\n    if offset + width > uint(s, 8, 8):\n        return 1114113\n    pos = 64 + offset\n    if tag == 268435456 or tag == 805306368:\n        return uint(s, pos, width)\n    value = 0\n    i = 0\n    while i < width:\n        value = (value << 8) | byte(s, pos + i)\n        i = i + 1\n    return value\n\ndef json_uint(s:readbuf, at:u64, n:u64) -> u64:\n    if at < 268435456:\n        return uint(s, at, n)\n    i = 0\n    value = 0\n    while i < n:\n        ch = json_byte(s, at + i)\n        if ch > 127:\n            return 18446744073709551615\n        value = value | (ch << (i * 8))\n        i = i + 1\n    return value\n'
    nodes = ast.parse(source).body
    function_names = {n.name: f'f{i}' for i, n in enumerate(nodes)}
    assert len(function_names) == len(nodes)
    signatures = {n.name: ([a.annotation.id for a in n.args.args], n.returns.id) for n in nodes}
    total = total_scalar_functions(nodes)
    functions = []
    for n in nodes:
        b = LinkerBuilder(n, function_names, signatures, total)
        b.statements(n.body)
        functions.append({'name': function_names[n.name], 'params': [b.param(a) for a in b.params], 'returns': [b.returns], 'effects': ['read', 'write', 'trap'], 'entry': 'b0', 'blocks': b.blocks})
    invalid = []
    for f in functions:
        for b in f['blocks']:
            types = {p['name']: p['type'] for p in b['params']}
            for op in b['ops']:
                if op['op'] == 'int.cast' and types.get(op['args'][0]) not in ('u8', 'u16', 'u32', 'u64', 'i8', 'i16', 'i32', 'i64', 'usize', 'isize'):
                    invalid.append({'function': next((k for k, v in function_names.items() if v == f['name'])), 'block': b['id'], 'type': types.get(op['args'][0]), 'operation': op})
                types.update({p['name']: p['type'] for p in op['out']})
    if invalid:
        print('INVALID_CASTS', json.dumps(invalid[:20]))
    doc = compact_authoring_cfg({'schema': 'hepta.hia.program.v9', 'module': 'source_release_cold_admit', 'functions': functions})
    text = render_assembly(doc)
    record = {'source_count': len(names), 'metadata_bytes': len(metadata), 'metadata_sha256': metadata_pin.hex(), 'path_set_sha256': paths_pin.hex(), 'functions': len(functions), 'blocks': sum((len(f['blocks']) for f in doc['functions'])), 'instructions': sum((len(b['ops']) for f in doc['functions'] for b in f['blocks'])), 'maximum_block_parameters': max((len(b['params']) for f in doc['functions'] for b in f['blocks'])), 'source_bytes': len(text.encode())}
    return (text, record)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--check',action='store_true')
 parser.add_argument('--contract-root',type=Path,default=ROOT)
 parser.add_argument('--native-source-authority',type=Path,
                     help='explicit native authority selects the complete native v2 report gate')
 parser.add_argument('--output',type=Path,default=ROOT/'examples/hia_bootstrap/source_release_cold_admit.hepta')
 args=parser.parse_args()
 root=args.contract_root.resolve(strict=True)
 if args.native_source_authority is None:
  text,record=render(root)
 else:
  from tools.generate_hia_cold_report_admit import native_catalog,render as render_native
  catalog=native_catalog(root,args.native_source_authority)
  text,record,_=render_native(root,catalog,native_source_authority=args.native_source_authority)
 target=args.output
 if args.check:
  if target.read_text()!=text:raise SystemExit('cold admission source differs from current source catalog or contract')
 else:target.write_text(text)
 print(json.dumps(record,sort_keys=True))

if __name__=='__main__':
 main()
