"""Compact, deterministic spelling of checked primitive HIA Core.

This frontend supplies syntax only. Types, effects, ownership, calls, CFG edges,
integer modes and attributes stay explicit, and the existing whole-program
verifier remains the sole semantic authority. No expression synthesis, repair,
automatic cast, inferred cleanup, optimizer, or second evaluator lives here.
"""
from __future__ import annotations

from hashlib import sha256
import json
import re

from .hia_json_preflight import preflight_hia_json
from .hia_program import HIAProgramRejected, VerifiedProgram, verify_program
from .hia_program_tools import HIAEditRejected, decode_json
from .hia_schema import SCHEMA_V6, SCHEMA_V7, SCHEMA_V8, SCHEMA_V9, supports_feature

ASSEMBLY_SCHEMA = "hepta.hia.agent-assembly.v1"
WIRE_HEADER = "hia-asm.v1"
CORE_SCHEMAS = frozenset({SCHEMA_V6, SCHEMA_V7, SCHEMA_V8, SCHEMA_V9})
MAX_SOURCE_BYTES = 1024 * 1024
MAX_LINES = 16384
MAX_LINE_BYTES = 16384
MAX_FUNCTIONS = 256
MAX_BLOCKS = 4096
MAX_OPERATIONS = 16384
MAX_LIST_ITEMS = 256
MAX_ATTRIBUTE_NODES = 2048
MAX_ATTRIBUTE_DEPTH = 16

_NAME = r"[A-Za-z_][A-Za-z_0-9]{0,127}"
_OPCODE = r"[A-Za-z_][A-Za-z_0-9.]{0,127}"
_HEADER = re.compile(rf"{re.escape(WIRE_HEADER)}\s+(\S+)\s+({_NAME})")
_FUNCTION = re.compile(
    rf"fn\s+({_NAME})\(([^()]*)\)\s*->\s*\(([^()]*)\)"
    rf"\s+effects\(([^()]*)\)\s+entry\(({_NAME})\)"
    rf"(?:\s+return_loans\(([^()]*)\))?")
_BLOCK = re.compile(rf"block\s+({_NAME})\(([^()]*)\)")
_INSTRUCTION = re.compile(rf"([^=]+)\s*=\s*({_OPCODE})\(([^()]*)\)(?:\s+(.*))?")
_RETURN = re.compile(r"ret\(([^()]*)\)")
_JUMP = re.compile(rf"jump\s+({_NAME})\(([^()]*)\)")
_BRANCH = re.compile(rf"branch\s+({_NAME})\s+({_NAME})\(([^()]*)\)\s+({_NAME})\(([^()]*)\)")
_TRAP = re.compile(rf"trap\s+({_NAME})")
_SOURCE_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ufeff]")


class HIAAssemblyRejected(HIAProgramRejected):
    """A bounded syntax/representation refusal or the original Core refusal."""

    def __init__(self, message, code="E_HIA_ASSEMBLY", *, line=None, phase="syntax"):
        self.line = line
        self.phase = phase
        super().__init__((f"line {line}: " if line is not None else "") + message, code)


def _reject(message, *, line=None, limit=False):
    raise HIAAssemblyRejected(message, "E_HIA_ASSEMBLY_LIMIT" if limit else "E_HIA_ASSEMBLY",
                              line=line)


def _source(value):
    if type(value) not in (str, bytes):
        _reject("source must be UTF-8 text or bytes")
    if len(value) > MAX_SOURCE_BYTES:
        _reject("source exceeds byte budget", limit=True)
    try:
        raw = value.encode("utf-8") if type(value) is str else value
        if len(raw) > MAX_SOURCE_BYTES:
            _reject("source exceeds byte budget", limit=True)
        text = raw.decode("utf-8")
    except UnicodeError as exc:
        raise HIAAssemblyRejected("source is not valid UTF-8") from exc
    # LF and optional CRLF are the only line separators. Do not let Unicode
    # splitlines(), NUL, BOM or terminal controls change visible tokenization.
    # The pattern is the exact rejected set from the character-wise check:
    # ASCII controls except TAB/LF/CR, plus BOM. UTF-8 and source-size checks
    # still precede it, and the separate CRLF/line checks still follow it.
    if _SOURCE_CONTROL.search(text) is not None:
        _reject("unsupported control character or byte-order mark")
    lines = text.split("\n")
    if len(lines) > MAX_LINES:
        _reject("source exceeds line budget", limit=True)
    for number, line in enumerate(lines, 1):
        if len(line.encode("utf-8")) > MAX_LINE_BYTES:
            _reject("line exceeds byte budget", line=number, limit=True)
        if "\r" in line.removesuffix("\r"):
            _reject("carriage return must be part of CRLF", line=number)
    return raw, lines


def _items(value, line):
    if not value.strip():
        return []
    parts = [part.strip() for part in value.split(",")]
    if len(parts) > MAX_LIST_ITEMS:
        _reject("list exceeds item budget", line=line, limit=True)
    if any(not part for part in parts):
        _reject("empty list item", line=line)
    return parts


def _names(value, line):
    parts = _items(value, line)
    if any(re.fullmatch(_NAME, part) is None for part in parts):
        _reject("expected explicit ASCII names", line=line)
    return parts


def _parameters(value, line):
    result = []
    for part in _items(value, line):
        match = re.fullmatch(rf"({_NAME})\s*:\s*({_NAME})", part)
        if match is None:
            _reject("expected name:type for every value", line=line)
        result.append({"name": match[1], "type": match[2]})
    return result


def _assembly_json(value, line, *, loans=False):
    try:
        preflight_hia_json(value, max_nodes=MAX_LIST_ITEMS + 1 if loans else MAX_ATTRIBUTE_NODES,
                          max_depth=2 if loans else MAX_ATTRIBUTE_DEPTH)
        return decode_json(value)
    except (ValueError, OverflowError, HIAEditRejected) as exc:
        message = "return_loans requires bounded strict JSON" if loans else "attributes require bounded strict JSON"
        raise HIAAssemblyRejected(message, line=line) from exc


def _attrs(value, line):
    if value is None:
        return {}
    attrs = _assembly_json(value, line)
    if type(attrs) is not dict:
        _reject("attributes must be one JSON object", line=line)
    return attrs


def _parse_assembly_document(source: str | bytes) -> dict:
    """Construct a fresh syntax document without granting Core authority.

    The same source, syntax and attribute bounds apply. The returned mutable
    document is not verified; public callers use assemble_program. Internal
    fixture authors may transform it before their final independent admission.
    No parsed document, VerifiedProgram or admission result is cached.
    """
    _, lines = _source(source)
    document = None
    function = block = None
    blocks = operations = 0
    for number, raw in enumerate(lines, 1):
        line = raw.removesuffix("\r").strip(" \t")
        if not line:
            continue
        if document is None:
            match = _HEADER.fullmatch(line)
            if match is None or match[1] not in CORE_SCHEMAS:
                _reject("expected hia-asm.v1, explicit primitive v6/v7/v8/v9 schema, and module", line=number)
            document = {"schema": match[1], "module": match[2], "functions": []}
            continue
        if function is None:
            exports = re.fullmatch(r"exports\(([^()]*)\)", line)
            if exports is not None:
                if "exports" in document or document["functions"]:
                    _reject("exports may occur once, before all functions", line=number)
                document["exports"] = _names(exports[1], number)
                continue
            match = _FUNCTION.fullmatch(line)
            if match is None:
                _reject("expected explicit function header", line=number)
            if len(document["functions"]) >= MAX_FUNCTIONS:
                _reject("function inventory exceeds budget", line=number, limit=True)
            function = {"name": match[1], "params": _parameters(match[2], number),
                        "returns": _names(match[3], number), "effects": _names(match[4], number),
                        "entry": match[5], "blocks": []}
            if match[6] is not None:
                if not supports_feature(document["schema"], "parameter_loan_returns"):
                    _reject("return_loans requires explicit Core v8 or later", line=number)
                origins = _assembly_json(match[6], number, loans=True)
                if (type(origins) is not list or len(origins) > MAX_LIST_ITEMS
                        or any(x is not None and (type(x) is not str or re.fullmatch(_NAME, x) is None)
                               for x in origins)):
                    _reject("return_loans requires a list of formal names or null", line=number)
                function["return_loans"] = origins
            document["functions"].append(function)
            block = None
            continue
        if line == "end":
            if block is None or "term" not in block:
                _reject("function must end after a block terminator", line=number)
            function = block = None
            continue
        match = _BLOCK.fullmatch(line)
        if match is not None:
            if block is not None and "term" not in block:
                _reject("previous block has no terminator", line=number)
            blocks += 1
            if blocks > MAX_BLOCKS:
                _reject("block inventory exceeds budget", line=number, limit=True)
            block = {"id": match[1], "params": _parameters(match[2], number), "ops": []}
            function["blocks"].append(block)
            continue
        if block is None or "term" in block:
            _reject("expected block header or function end", line=number)
        if match := _RETURN.fullmatch(line):
            block["term"] = {"op": "ret", "values": _names(match[1], number)}
        elif match := _JUMP.fullmatch(line):
            block["term"] = {"op": "jump", "target": match[1], "args": _names(match[2], number)}
        elif match := _BRANCH.fullmatch(line):
            block["term"] = {"op": "branch", "cond": match[1],
                             "then": {"target": match[2], "args": _names(match[3], number)},
                             "else": {"target": match[4], "args": _names(match[5], number)}}
        elif match := _TRAP.fullmatch(line):
            block["term"] = {"op": "trap", "code": match[1]}
        elif match := _INSTRUCTION.fullmatch(line):
            operations += 1
            if operations > MAX_OPERATIONS:
                _reject("operation inventory exceeds budget", line=number, limit=True)
            block["ops"].append({"op": match[2], "args": _names(match[3], number),
                                 "out": [] if match[1].strip() == "_" else _parameters(match[1], number),
                                 "attrs": _attrs(match[4], number)})
        else:
            _reject("expected typed instruction or explicit terminator", line=number)
    if document is None:
        _reject("missing assembly header")
    if function is not None:
        _reject("unterminated function; explicit end required", line=len(lines))
    return document


def _native_assembly_document(syntax, presenter, source):
    import ctypes
    import mmap
    import struct

    if type(source) not in (str, bytes):
        _reject("source must be UTF-8 text or bytes")
    if len(source) > MAX_SOURCE_BYTES:
        _reject("source exceeds byte budget", limit=True)
    try:
        raw = source.encode('utf-8') if type(source) is str else source
    except UnicodeError as error:
        raise HIAAssemblyRejected("source is not valid UTF-8") from error

    def present(state):
        reply = ctypes.create_string_buffer(8192)
        status = presenter._entry(raw, len(raw), reply, len(reply), state, len(state))
        length, = struct.unpack_from('<Q', state, 80)
        if status == 0 and length == 0:
            return
        if status != 1 or not 0 < length <= len(reply):
            raise ValueError('invalid package assembly diagnostic response')
        result = json.loads(reply.raw[:length])
        if (result.get('schema') != 'hepta.hia.assembly-diagnostic.v1' or result.get('accepted') is not False
                or any(result.get(name) is not False for name in
                       ('deployment_authority', 'native_artifact_created', 'safety_certificate'))):
            raise ValueError('invalid package assembly refusal')
        diagnostic = result['diagnostic']
        code, message, line = diagnostic['code'], diagnostic['message'], diagnostic['line']
        if (diagnostic['phase'] != 'syntax' or code not in ('E_HIA_ASSEMBLY', 'E_HIA_ASSEMBLY_LIMIT')
                or (line is not None and (type(line) is not int or not 1 <= line <= MAX_LINES))):
            raise ValueError('invalid package assembly diagnostic fields')
        prefix = code + ': ' + (f'line {line}: ' if line is not None else '')
        if type(message) is not str or not message.startswith(prefix):
            raise ValueError('invalid package assembly diagnostic message')
        detail = message[len(prefix):]
        # The Python API includes the underlying UTF-8 or JSON exception. HIA
        # has already selected the exact source line and its diagnostic here.
        if detail == "source is not valid UTF-8":
            try:
                raw.decode('utf-8')
            except UnicodeError as error:
                raise HIAAssemblyRejected(detail, code, line=line) from error
        if line is not None and detail in ("attributes require bounded strict JSON",
                                           "return_loans requires bounded strict JSON"):
            text = raw.split(b'\n', line)[line - 1].decode('utf-8').removesuffix('\r').strip(' \t')
            loans = detail.startswith('return_loans')
            match = (_FUNCTION if loans else _INSTRUCTION).fullmatch(text)
            if match is not None:
                _assembly_json(match[6 if loans else 4], line, loans=loans)
        raise HIAAssemblyRejected(detail, code, line=line)

    state = ctypes.create_string_buffer(4096)
    struct.pack_into('<Q', state, 88, 1274)  # Source preflight, before syntax.
    present(state)
    with mmap.mmap(-1, 16 << 20) as output:
        arena = ctypes.create_string_buffer(131104)
        struct.pack_into('<8s3Q', arena, 131072, b'HIASYN01', MAX_FUNCTIONS, MAX_BLOCKS, MAX_OPERATIONS)
        extent = syntax._entry(raw, len(raw), ctypes.addressof(ctypes.c_char.from_buffer(output)), len(output),
                               arena, len(arena))
        if 0 < extent <= len(output):
            return output[:extent]
        reason, line = struct.unpack_from('<2Q', arena, 256)
    state = ctypes.create_string_buffer(4096)
    struct.pack_into('<Q', state, 104, extent)
    struct.pack_into('<Q', state, 120, len(raw))
    struct.pack_into('<2Q', state, 144, reason, line)
    present(state)
    raise ValueError('package assembly parser refusal lacks its diagnostic')


def assemble_program(source: str | bytes) -> VerifiedProgram:
    """Translate explicit assembly to Core and reverify the entire program.

    v6/v7/v8 are the text targets. Historical schemas require their existing
    explicit adapters, and nominal layouts require their existing elaborator.
    """
    from .hia_default_native import default_assembly_document
    try:
        document = default_assembly_document(source, verify=True)
        if isinstance(document, VerifiedProgram):
            return document
        if document is None:
            document = _parse_assembly_document(source)
        return verify_program(document)
    except HIAAssemblyRejected:
        raise
    except HIAProgramRejected as exc:
        # Core errors are kept as Core errors. An absent location is honest:
        # assigning a guessed syntax line would misidentify cross-block errors.
        raise HIAAssemblyRejected(str(exc).removeprefix(exc.code + ": "), exc.code,
                                  phase="core_verification") from exc


def _render_parameters(parameters):
    return ",".join(p["name"] + ":" + p["type"] for p in parameters)


def _render_assembly_document(data: dict) -> str:
    """Spell a construction document without claiming it is valid Core.

    The input remains owned by the caller and is only read. This helper grants
    no VerifiedProgram or execution authority and performs no admission. The
    public renderer below still fully verifies both the input and round trip.
    """
    lines = [f'{WIRE_HEADER} {data["schema"]} {data["module"]}']
    if "exports" in data:
        lines.append("exports(" + ",".join(data["exports"]) + ")")
    for function in data["functions"]:
        lines.append(f'fn {function["name"]}({_render_parameters(function["params"])}) -> '
                     f'({",".join(function["returns"])}) effects({",".join(function["effects"])}) '
                     f'entry({function["entry"]})')
        if "return_loans" in function:
            lines[-1] += " return_loans(" + json.dumps(function["return_loans"], separators=(",", ":")) + ")"
        for block in function["blocks"]:
            lines.append(f'block {block["id"]}({_render_parameters(block["params"])})')
            for instruction in block["ops"]:
                outputs = _render_parameters(instruction["out"]) or "_"
                text = f'  {outputs} = {instruction["op"]}({",".join(instruction["args"])})'
                if instruction["attrs"]:
                    text += " " + json.dumps(instruction["attrs"], sort_keys=True, separators=(",", ":"),
                                             ensure_ascii=False, allow_nan=False)
                lines.append(text)
            term = block["term"]
            if term["op"] == "ret":
                text = "ret(" + ",".join(term["values"]) + ")"
            elif term["op"] == "jump":
                text = f'jump {term["target"]}({",".join(term["args"])})'
            elif term["op"] == "branch":
                left, right = term["then"], term["else"]
                text = (f'branch {term["cond"]} {left["target"]}({",".join(left["args"])}) '
                        f'{right["target"]}({",".join(right["args"])})')
            else:
                text = "trap " + term["code"]
            lines.append("  " + text)
        lines.append("end")
    return "\n".join(lines) + "\n"


def _native_assembly_text(image, canonical: bytes) -> str:
    import ctypes
    import mmap
    import struct
    from .hia_program import MAX_BYTES, MAX_NODES, MAX_DEPTH

    # The wheel's standalone renderer lends the same six-argument image an
    # 8 MiB output and a 32 MiB JSON arena. Anonymous maps commit touched pages.
    with mmap.mmap(-1, MAX_BYTES) as output, mmap.mmap(-1, 32 << 20) as arena:
        struct.pack_into('<2Q', arena, 48, MAX_NODES, MAX_DEPTH)
        extent = image._entry(canonical, len(canonical),
                              ctypes.addressof(ctypes.c_char.from_buffer(output)), len(output),
                              ctypes.addressof(ctypes.c_char.from_buffer(arena)), len(arena))
        if extent == 0xfffffffa:
            _reject("source exceeds byte budget", limit=True)
        if not 0 < extent <= MAX_SOURCE_BYTES:
            raise HIAAssemblyRejected("native renderer refused checked Core", "E_HIA_ASSEMBLY_ROUNDTRIP",
                                      phase="representation")
        return output[:extent].decode('utf-8')


def render_assembly(document) -> str:
    """Canonical compact text whose exact primitive Core round trip is checked."""
    checked = verify_program(document)
    data = checked.as_dict()
    if checked.structured_bytes is not None or data["schema"] not in CORE_SCHEMAS:
        raise HIAAssemblyRejected("render requires explicit primitive v6/v7/v8/v9 Core; use the existing adapter first",
                                  "E_HIA_ASSEMBLY_PROFILE", phase="representation")
    from .hia_default_native import default_assembly_text
    rendered = default_assembly_text(checked.canonical_bytes)
    if rendered is None:
        rendered = _render_assembly_document(data)
    if assemble_program(rendered).canonical_bytes != checked.canonical_bytes:
        raise HIAAssemblyRejected("renderer changed canonical Core", "E_HIA_ASSEMBLY_ROUNDTRIP",
                                  phase="representation")
    return rendered


def diagnose_assembly(source: str | bytes) -> dict:
    """Stable Agent diagnostic; accepted syntax/Core grants no native authority."""
    result = {"schema": "hepta.hia.assembly-diagnostic.v1", "accepted": False,
              "deployment_authority": False, "safety_certificate": False,
              "native_artifact_created": False}
    try:
        raw, _ = _source(source)
        result.update(source_sha256=sha256(raw).hexdigest(), source_bytes=len(raw))
        checked = assemble_program(raw)
    except HIAProgramRejected as exc:
        result["diagnostic"] = {"code": exc.code, "message": str(exc),
                                "phase": getattr(exc, "phase", "core_verification"),
                                "line": getattr(exc, "line", None)}
        return result
    result.update(accepted=True, core_sha256=checked.sha256,
                  core_schema=checked.as_dict()["schema"], diagnostic=None)
    return result
