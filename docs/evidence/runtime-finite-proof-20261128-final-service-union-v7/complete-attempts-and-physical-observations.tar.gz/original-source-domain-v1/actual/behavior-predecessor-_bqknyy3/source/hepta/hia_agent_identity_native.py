"""Operator-selected HIA scalar identities and frozen-context budget rules.

The service binds inputs to Store authority before passing bounded scalar values
to this policy. It retains its existing public rejection codes and messages.
"""
from __future__ import annotations
import ctypes
import struct
from .hia_agent_store import MAX_INPUT_BYTES, _agent_resource_path, decode_data, reject, wire
from .hia_json_preflight_native import NativeHiaJsonImage, _installed_json_image
from .hia_native_byte_abi import LOANS
from .hia_opcodes import EFFECTS, OPCODES, WIDTHS
from .hia_program_tools import HIAEditRejected

SOURCE=_agent_resource_path('examples/hia_bootstrap/agent_identity.hepta')
SCHEMA='hepta.hia.agent-identity-native.v1'
MAGIC=int.from_bytes(b'HIAIDP01','little')
RESULT_MAGIC=int.from_bytes(b'HIAIDR01','little')
SELECTOR='HEPTA_HIA_AGENT_IDENTITY_MANIFEST'
CONTEXT_REFUSALS = {
    1: ('E_HIA_BUDGET', 'execution profile admits 64 MiB..4 GiB address-space budgets'),
    2: ('E_HIA_BUDGET', 'native wall budget exceeds total wall budget'),
    3: ('E_HIA_BUDGET', 'reported model tokens exceed the frozen budget'),
    4: ('E_HIA_COST', 'complete external cost report cannot contain unknown fields'),
    5: ('E_HIA_BUFFER_BUDGET', 'frozen workload exceeds 32 MiB of external byte snapshots'),
}
EVALUATION_OUTCOMES = ('budget_exceeded', 'incorrect', 'inconclusive', 'improved', 'regressed', 'unchanged')
EVALUATION_NORMAL, EVALUATION_TRAP, EVALUATION_FINISH = range(1, 4)
REF_BATCH, REF_CLOCK, REF_CASE, REF_COMPARE_NORMAL, REF_COMPARE_TRAP, REF_FINISH, REF_EXPECTATION = range(1, 8)
_EVALUATION_STATUS = {'returned': 1, 'trapped': 2, 'budget_exceeded': 3,
                      'faulted': 4, 'invalid_report': 5}
WORD_MASK = (1 << 64) - 1
DECLARED_OBSERVATION, REFERENCE_OBSERVATION, NATIVE_OBSERVATION = range(3)
_CLAIMS = ('core_admission', 'behavior_equivalence', 'lowering_refinement', 'encoding_check')
_SUBJECT_KINDS = {'native_artifact': 1, 'agent_machine_plan': 2}
CLAIM_NOT_QUALIFIED, CLAIM_QUALIFIED, CLAIM_BUILD_RECHECK = range(3)
PROOF_OPCODE_IDS = {name: index for index, name in enumerate(sorted(OPCODES), 1)}
PROOF_EFFECT_IDS = {name: 1 << index for index, name in enumerate(sorted(EFFECTS))}
EXACT_COMPARISON_CHUNK = 256 * 1024
PROOF_EVIDENCE_METHODS = (
    '', 'core_admission', 'canonical_core_identity', 'finite_domain',
    'context_budget_exhausted', 'checked_explicit_machine_choices',
    'canonical_lowering_unsupported', 'complete_native_rederivation',
)
PROOF_FINITE_COUNTEREXAMPLE = 8
PROOF_COMPOSITIONAL = 9
PROOF_INDEPENDENT_MACHINE = 10
_EVIDENCE_METHOD_IDS = {
    'canonical_core_identity': 1, 'finite_domain': 2, 'context_budget_exhausted': 3,
    'checked_explicit_machine_choices': 4, 'complete_native_rederivation': 5,
}
_PROOF_STATUS_IDS = {'proved': 1, 'refuted': 2, 'unknown': 3, 'unsupported': 4}
_PROOF_SUBJECT_IDS = {'core': 1, 'canonical_lowering': 2, 'agent_machine_plan': 3, 'native_artifact': 4}
ABI_SCALAR_IDS = {name: role for role, name in enumerate((*WIDTHS, 'bool', 'unit'), 1)}


def _observation_fields(observation, *, reference):
    status = observation['status']
    # Preserve the public comparison in which JSON true/false and 1/0
    # compare equally when used as result values (not as typed arguments).
    returned = (wire([int(value) if type(value) is bool else value for value in observation['values']])
                if status == 'returned' else b'')
    buffers = wire(observation['buffers']) if 'buffers' in observation else b''
    trap = wire(observation.get('trap_code')) if reference else b''
    resources = wire(observation['ledger']['resources']) if reference else b''
    return status.encode('ascii'), returned, buffers, trap, resources


def _enum_id(table, value):
    return table.get(value, 0) if type(value) is str else 0


def _proof_text(value):
    return b'\x01' + value.encode('utf-8', 'surrogatepass') if type(value) is str else b'\x00'


def _proof_count(value):
    return value if type(value) is int and 0 <= value <= WORD_MASK else WORD_MASK


def _proof_boolean(value):
    return 2 if value is True else 1 if value is False else 0


def _paired_packet(header, left, right):
    packet = bytearray(header)
    for expected, observed in zip(left, right, strict=True):
        packet.extend(struct.pack('<2Q', len(expected), len(observed)))
        packet.extend(expected)
        packet.extend(observed)
    return bytes(packet)


def _claim_observations(receipt, expected):
    subject = receipt['subject']
    checks = bytes(_CLAIMS.index(check['claim']) + 4 * (check['status'] == 'proved')
                   for check in receipt['checks'])
    observed = (receipt['base_core_sha256'], subject.get('native_artifact'), subject.get('plan'))
    scope = _paired_packet(checks, expected, map(wire, observed))
    return _SUBJECT_KINDS.get(subject['kind'], 0), len(checks), scope


def _record_fields(fields, kind):
    # Persisted namespace fields are strings. Any other supplied JSON type
    # cannot equal an issued string, regardless of its textual form.
    encoded = []
    for field in fields:
        encoded.append(b'\x01' + field.encode('utf-8', 'surrogatepass')
                       if isinstance(field, str) else b'\x02')
    encoded.append(b'' if kind is None else b'\x01' + kind.encode('utf-8', 'surrogatepass'))
    return encoded


def _abi_value_words(value):
    if value is None:
        return 1, 0
    if type(value) is bool:
        return 2, int(value)
    if type(value) is int and value.bit_length() <= 64:
        return (4, -value) if value < 0 else (3, value)
    return 0, 0


class NativeAgentIdentity(NativeHiaJsonImage):
    def scalar(self, value, kind):
        if type(kind)is not int or kind not in (0,1):
            raise ValueError('unknown native Agent identity operation')
        # Value-kind and bounded transport, not a numeric/hex fallback.
        if type(value)is not str or len(value)>64:
            return None
        try: payload=value.encode('ascii')
        except UnicodeEncodeError:return None
        wire=struct.pack('<2Q',MAGIC,kind)+payload
        valid, number = self._request(wire)
        if valid not in (0, 1) or (not valid and number != 0) or (kind == 1 and number != 0):
            raise RuntimeError('invalid HIA Agent scalar result')
        return number if valid else None

    def abi_scalar(self, value, typ):
        kind, word = _abi_value_words(value)
        packet = struct.pack('<5Q', MAGIC, 14, ABI_SCALAR_IDS.get(typ, 0), kind, word)
        valid, result = self._request(packet)
        if valid != 1 or result not in (0, 1):
            raise RuntimeError('invalid HIA Agent call scalar result')
        return bool(result)

    def call_arguments(self, signature, arguments, *, snapshot_profile, snapshot_size):
        """Execute only the snapshot observations requested by the HIA plan."""
        matched = type(arguments) in (list, tuple) and len(arguments) == len(signature['params'])
        borrowed = matched and signature.get('abi') == snapshot_profile
        packet = bytearray(struct.pack('<8Q', MAGIC, 43, int(matched), int(borrowed), 0, 0, WORD_MASK, 0))
        if matched:
            for typ, value in zip(signature['params'], arguments, strict=True):
                role = 256 if typ in LOANS else ABI_SCALAR_IDS.get(typ, 0)
                kind, word = _abi_value_words(value)
                packet.extend(struct.pack('<3Q', role, kind, word))
        index = -1
        while True:
            action, next_index, total = self._response(bytes(packet), 32, '<4Q')
            if action == 0 and matched and next_index == len(arguments):
                return total
            if action == 1 and matched and index < next_index < len(arguments):
                index = next_index
                size = snapshot_size(arguments[index])
                extent = signature['max_buffer_bytes']
                limit = WORD_MASK if extent < 0 else min(int(extent), WORD_MASK - 1)
                struct.pack_into('<4Q', packet, 32, index, total, size, limit)
            elif action == 2:
                reject('E_HIA_ARGUMENTS', 'call does not match the frozen public ABI')
            elif action == 3:
                reject('E_HIA_ABI', 'borrowed entry is absent from the frozen invocation profile')
            elif action == 4:
                reject('E_HIA_BUFFER_EXTENT', 'snapshot exceeds the frozen wrapper extent')
            elif action == 5:
                reject('E_HIA_ARGUMENTS', 'call arguments do not have the exact declared scalar types')
            else:
                raise RuntimeError('invalid native call-argument instruction')

    def workload_case(self, total, observed):
        """Admit the current case or reject before inspecting later snapshots."""
        size = WORD_MASK if observed is None else min(observed, WORD_MASK - 1)
        status, updated = self._request(struct.pack('<4Q', MAGIC, 44, total, size))
        if status == 0:
            return updated
        if status == 1:
            reject('E_HIA_ABI', 'workload names an unavailable public entry')
        if status == 2:
            reject('E_HIA_BUFFER_BUDGET', 'frozen workload exceeds 32 MiB of external byte snapshots')
        raise RuntimeError('invalid native workload case decision')

    def direct_call_receipt(self, raw, protocol, returns, *, borrowed):
        version = 2 if protocol >= 2 else 1
        role = 256 if borrowed else ABI_SCALAR_IDS[returns[0]] if returns else 0
        header = struct.pack('<4Q', MAGIC, 45, version, role)
        refusal, duration, variation, kind, word, status = self._response(header + raw, 56, '<7Q')
        if refusal:
            errors = (
                'direct HIA call returned an invalid receipt extent',
                'direct HIA call returned an invalid receipt identity',
                'direct HIA call returned an invalid borrowed-byte ABI status',
            )
            if refusal > len(errors):
                raise RuntimeError('invalid native direct-call receipt decision')
            raise ValueError(errors[refusal - 1])
        if variation > 1 or kind > 4 or status > 4 or status and not borrowed:
            raise RuntimeError('invalid native direct-call receipt result')
        if status:
            return {'status': 'abi_rejected', 'abi_status': status}, duration, variation
        values = ([], [None], [bool(word)], [word], [-word])[kind]
        return {'status': 'returned', 'values': values}, duration, variation

    def direct_call_capture(self, protocol, returncode, timed_out, stdout_size, stderr_size, limit, raw):
        version = 2 if protocol >= 2 else 1
        process_status = WORD_MASK if returncode is None else returncode & WORD_MASK
        frame = struct.pack('<9Q8s', MAGIC, 46, version, process_status, int(timed_out),
                            stdout_size, stderr_size, limit, len(raw), raw[:8])
        valid, decision = self._request(frame)
        if valid != 1 or decision not in (0, 1, 2):
            raise RuntimeError('invalid native direct capture decision')
        return decision

    def runner_terminal(self, returncode, timed_out, stdout_size, stderr_size, limit):
        process_status = 256 if returncode is None else returncode & WORD_MASK
        frame = struct.pack('<7Q', MAGIC, 50, process_status, int(timed_out), stdout_size, stderr_size, limit)
        valid, decision = self._request(frame)
        outcomes = (None, 'invalid_report', 'budget_exceeded', 'trapped', 'faulted')
        if valid != 1 or not 0 <= decision < len(outcomes):
            raise RuntimeError('invalid native runner terminal decision')
        return outcomes[decision]

    def direct_call_request(self, protocol, function, arguments, *, parent, memory, cpu,
                            artifact, artifact_bytes, borrowed, returns, expected, warmup, repetitions):
        version = 2 if protocol >= 2 else 1
        role = 256 if borrowed else ABI_SCALAR_IDS[returns[0]] if returns else 0
        wire = struct.pack('<14Q', MAGIC, 49, version, parent, memory, cpu, artifact,
                           artifact_bytes, len(arguments), warmup, repetitions, int(expected),
                           role, len(function))
        wire += b''.join(struct.pack('<3Q', *argument) for argument in arguments) + function
        capacity = 104 + len(arguments) * 8 + min(len(arguments), 8) * 40 + len(function)
        source = ctypes.create_string_buffer(wire, len(wire))
        output = ctypes.create_string_buffer(capacity)
        size = self._checked_default_entry(source, len(source), output, capacity, None, 0)
        magic = b'HIADRX02' if version == 2 else b'HIADRX01'
        if not 72 <= size <= capacity or output.raw[:8] != magic or source.raw != wire:
            raise RuntimeError('HIA refused native direct-call request')
        return output.raw[:size]

    def _request(self, wire):
        return self._response(wire, 24, '<3Q')

    def _response(self, wire, capacity, layout, *, workspace=0):
        source=ctypes.create_string_buffer(wire,len(wire))
        output=ctypes.create_string_buffer(capacity)
        scratch=ctypes.create_string_buffer(max(1, workspace))
        status=self._entry(source,len(wire),output,capacity,scratch,workspace)
        if status!=capacity:raise RuntimeError('HIA Agent identity rejected owned packet')
        magic, *result=struct.unpack(layout,output.raw)
        if magic != RESULT_MAGIC:
            raise RuntimeError('invalid HIA Agent identity result')
        return result

    def _context(self, kind, fields, allowed):
        wire = struct.pack(f'<{2 + len(fields)}Q', MAGIC, kind, *fields)
        valid, decision = self._request(wire)
        if valid != 1 or decision not in (0, *allowed):
            raise RuntimeError('invalid HIA Agent context budget result')
        if decision:
            code, message = CONTEXT_REFUSALS[decision]
            reject(code, message, 'context')

    def context_limits(self, memory, total_wall, native_wall):
        self._context(2, (memory, total_wall, native_wall), (1, 2))

    def context_cost(self, limit, external, complete):
        fields = ('model_tokens', 'model_wall_ns', 'discovery_wall_ns')
        missing = sum(1 << index for index, field in enumerate(fields) if external[field] is None)
        self._context(3, (limit, int(external['model_tokens'] or 0), missing, int(complete)), (3, 4))

    def context_snapshots(self, sizes):
        self._context(4, tuple(sizes), (5,))

    def workload_exports(self, workload):
        """Observe validated workload values; HIA admits and orders exports."""
        version = {'hepta.hia.agent.workload.v1': 1, 'hepta.hia.agent.workload.v2': 2}.get(workload['schema'], 0)
        rows = workload['foreign_buffer_exports'] if version == 2 else ()
        pairs = tuple((row['function'], row['max_buffer_bytes']) for row in rows)
        packet = bytearray(struct.pack('<4Q', MAGIC, 42, version, len(pairs)))
        for name, extent in pairs:
            raw = name.encode('utf-8') if type(name) is str else b''
            word = extent if type(extent) is int and 0 <= extent <= WORD_MASK else 0
            packet.extend(struct.pack('<2Q', len(raw), word))
            packet.extend(raw)
        source = ctypes.create_string_buffer(bytes(packet))
        scratch = ctypes.create_string_buffer(max(1, 8 * len(pairs)))
        output = ctypes.create_string_buffer(24 + 8 * len(pairs))
        size = self._entry(source, len(packet), output, len(output), scratch, 8 * len(pairs))
        magic, status, count = struct.unpack_from('<3Q', output)
        if (magic != RESULT_MAGIC or size not in (24, len(output))
                or size != 24 + count * 8 or count != (0 if status else len(pairs))):
            raise RuntimeError('native workload export record differs from its admitted extent')
        if status == 1:
            reject('E_HIA_WORKLOAD', 'unknown invocation workload profile')
        if status == 2:
            reject('E_HIA_BYTE_ABI', 'duplicate borrowed-buffer export name')
        if status == 3:
            reject('E_HIA_BYTE_ABI', 'invalid frozen borrowed-buffer export')
        if status:
            raise RuntimeError('unknown native workload export decision')
        ordinals = struct.unpack_from(f'<{count}Q', output, 24)
        if frozenset(ordinals) != frozenset(range(count)):
            raise RuntimeError('invalid native workload export ordinals')
        return tuple(pairs[ordinal] for ordinal in ordinals)

    def evaluation_measurement(self, before, after, threshold, *,
                               budget_exceeded, correct, complete, latency, trapping):
        flags = (budget_exceeded | (correct << 1) | (complete << 2)
                 | (latency << 3) | (trapping << 4))
        packet = struct.pack('<4QdQ', MAGIC, 5, before, after, threshold, flags)
        decision, bits = self._request(packet)
        if not 1 <= decision <= len(EVALUATION_OUTCOMES):
            raise RuntimeError('invalid HIA Agent evaluation decision')
        if (bits >> 52) & 2047 == 2047:
            raise RuntimeError('nonfinite HIA Agent evaluation ratio')
        ratio = struct.unpack('<d', struct.pack('<Q', bits))[0]
        return ratio, EVALUATION_OUTCOMES[decision - 1]

    def observation_agreement(self, left, right, *, mode):
        reference = mode == REFERENCE_OBSERVATION
        packet = _paired_packet(struct.pack('<3Q', MAGIC, 7, mode), _observation_fields(left, reference=reference),
                                _observation_fields(right, reference=reference))
        valid, agreement = self._request(packet)
        if valid != 1 or agreement not in (0, 1):
            raise RuntimeError('invalid HIA Agent observation decision')
        return bool(agreement)

    def evaluation_schedule(self, counts, previous, state, *, status=None, agrees=False):
        """Request the next evaluation effect using scalar runner observations."""
        budget_exceeded, correct, complete = state
        flags = budget_exceeded | (correct << 1) | (complete << 2)
        phase, arm, index = previous
        outcome = 0 if phase == 0 else _EVALUATION_STATUS.get(status, 6)
        packet = struct.pack('<10Q', MAGIC, 39, phase, arm, index, *counts,
                             flags, outcome, int(agrees))
        action, arm, index, flags = self._response(packet, 40, '<5Q')
        if (flags > 7 or
                not (action == EVALUATION_FINISH and arm == 2 and index == 0
                     or action == EVALUATION_NORMAL and arm < 2 and index == 0 and counts[0] and flags & 4
                     or action == EVALUATION_TRAP and arm < 2 and index < counts[1] and flags & 4)):
            raise RuntimeError('invalid HIA Agent evaluation schedule result')
        state = tuple(bool(flags & (1 << bit)) for bit in range(3))
        return (action, arm, index), state

    def evaluation_reference(self, count, previous, state, evidence=(0, 0, 0)):
        """Return the next reference-phase observation or a terminal decision."""
        budget_exceeded, correct, complete = state
        flags = budget_exceeded | (correct << 1) | (complete << 2)
        phase, index = previous
        first, second, third = evidence
        if phase in (REF_BATCH, REF_CASE):
            first = _enum_id(_EVALUATION_STATUS, first) or 6
        if phase == REF_CASE:
            second = _enum_id(_EVALUATION_STATUS, second) or 6
        packet = struct.pack('<9Q', MAGIC, 40, phase, index, count, flags, first, second, third)
        action, index, flags = self._response(packet, 32, '<4Q')
        if (flags > 7 or
                not (action == REF_FINISH and index == 0
                     or action == REF_BATCH and index in (0, 1) and flags & 4
                     or REF_CLOCK <= action <= REF_COMPARE_TRAP and index < count and flags & 4
                     or action == REF_EXPECTATION and index < count and flags & 4)):
            raise RuntimeError('invalid HIA Agent reference evaluation schedule result')
        state = tuple(bool(flags & (1 << bit)) for bit in range(3))
        return (action, index), state

    def record_authority(self, expected, observed, *, required_kind=None, observed_kind=None):
        header = struct.pack('<3Q', MAGIC, 8, int(observed is not None))
        packet = _paired_packet(header, _record_fields(expected, required_kind),
                                (b'',) * 4 if observed is None else _record_fields(observed, observed_kind))
        valid, decision = self._request(packet)
        if valid != 1 or decision not in (0, 1, 2):
            raise RuntimeError('invalid HIA Agent record authority decision')
        return decision

    def read_window(self, ref, *, cursor_requested, row, max_bytes):
        """Bound the page using a typed observation from the cursor Store."""
        present = row is not None
        stored = (row['artifact_id'], row['sha256']) if present else ()
        offset = row['offset'] if present else 0
        if present and (type(offset) is not int or not 0 <= offset <= WORD_MASK):
            offset = WORD_MASK
        limit = 0 if max_bytes is None else max_bytes
        if type(limit) is not int or not 0 <= limit <= WORD_MASK:
            limit = WORD_MASK
        header = struct.pack('<6Q', MAGIC, 47, int(cursor_requested) + int(present),
                             offset, int(max_bytes is not None), limit)
        expected = _record_fields((ref['id'], ref['sha256']), None)[:2]
        observed = _record_fields(stored, None)[:2] if present else (b'', b'')
        decision, offset, limit = self._response(_paired_packet(header, expected, observed), 32, '<4Q')
        if decision == 1 and offset == limit == 0:
            reject('E_HIA_CURSOR', 'cursor is not bound to this exact artifact')
        if decision == 2 and offset == limit == 0:
            raise ValueError('outside native HIA Agent artifact page profile')
        if decision != 0 or not (offset < 1 << 63 and 0 < limit <= 65536):
            raise RuntimeError('invalid HIA Agent artifact read window')
        return offset, limit

    def wall_window(self, created_ns, now_ns, total_ms):
        values = (created_ns, now_ns, total_ms)
        if not all(0 <= value < 1 << 64 for value in values):
            # A whole padding limb carries the exact observed sign. The HIA
            # kernel supplies arithmetic, overflow handling, and floor.
            bits = max(value.bit_length() for value in values)
            words = (bits + 31) // 32 + 1
            width = 4 * words
            packet = struct.pack('<3Q', MAGIC, 18, words) + b''.join(
                value.to_bytes(width, 'little', signed=True) for value in values)
            expired, raw = self._response(packet, 16 + width, f'<2Q{width}s')
            remaining = int.from_bytes(raw, 'little')
            if expired not in (0, 1) or (expired and remaining):
                raise RuntimeError('invalid wide HIA Agent deadline decision')
            return bool(expired), remaining
        packet = struct.pack('<5Q', MAGIC, 9, *values)
        expired, remaining, high = self._response(packet, 32, '<4Q')
        if expired not in (0, 1) or high not in (0, 1) or (expired and (remaining or high)):
            raise RuntimeError('invalid HIA Agent deadline decision')
        return bool(expired), (high << 64) | remaining

    def claim_eligibility(self, claim, receipt, candidate_artifact, native, baseline_core_sha):
        planned = native['machine_plan'] is not None
        expected = (baseline_core_sha, candidate_artifact, native['codegen'].get('plan') if planned else None)
        kind, count, scope = _claim_observations(receipt, map(wire, expected))
        header = struct.pack('<6Q', MAGIC, 10, _CLAIMS.index(claim), kind, int(planned), count)
        valid, decision = self._request(header + scope)
        if valid != 1 or decision not in (CLAIM_NOT_QUALIFIED, CLAIM_QUALIFIED, CLAIM_BUILD_RECHECK):
            raise RuntimeError('invalid HIA Agent claim eligibility decision')
        return decision

    def required_claims(self, claims, receipts, candidate_artifact, native, baseline_core_sha):
        """Return the ordered rechecks and first missing claim, if any."""
        planned = native['machine_plan'] is not None
        expected = tuple(map(wire, (baseline_core_sha, candidate_artifact,
                                   native['codegen'].get('plan') if planned else None)))
        framed = bytearray(struct.pack('<5Q', MAGIC, 48, len(claims), len(receipts), int(planned)))
        framed.extend(_CLAIMS.index(claim) for claim in claims)
        for receipt in receipts:
            kind, count, scope = _claim_observations(receipt, expected)
            framed.extend(struct.pack('<3Q', len(scope), kind, count))
            framed.extend(scope)
        missing, count, payload = self._response(bytes(framed), 88, '<3Q64s')
        if (missing > len(claims) or count > len(payload) or any(payload[count:])
                or any(index >= len(receipts) for index in payload[:count])):
            raise RuntimeError('invalid HIA Agent acceptance claim schedule')
        return payload[:count], claims[missing] if missing < len(claims) else None

    def proof_evidence(self, claim, status, subject, evidence, *, admission_checker):
        claim_id = _CLAIMS.index(claim) + 1 if type(claim) is str and claim in _CLAIMS else 0
        core, base = subject['candidate_core_sha256'], subject['base_core_sha256']
        plan = evidence.get('plan')
        native = subject.get('native_artifact')
        flags = (
            (subject.get('base_program') is not None)
            | ((base is not None) << 1)
            | ((evidence.get('all_inputs') is True) << 2)
            | ((evidence.get('all_inputs_in_declared_widths') is True) << 3)
            | ((type(evidence.get('transcript_sha256')) is str) << 4)
            | (('counterexample' in evidence) << 5)
            | ((type(evidence.get('reason')) is str) << 6)
            | ((type(plan) is dict) << 7)
            | ((_enum_id({'hepta.hia.optimization-verification.v1': 1}, evidence.get('schema'))) << 8)
        )
        header = struct.pack('<12Q', MAGIC, 15, claim_id, _enum_id(_PROOF_STATUS_IDS, status),
            _enum_id(_PROOF_SUBJECT_IDS, subject.get('kind')), _enum_id(_EVIDENCE_METHOD_IDS, evidence.get('method')),
            flags, _proof_count(evidence.get('checked')), _proof_count(evidence.get('required')),
            _proof_boolean(evidence.get('complete')), _proof_boolean(evidence.get('bytes_equal')),
            _proof_boolean(evidence.get('object_identity_equal')))
        expected = (admission_checker, core, core, base, core, core,
                    native.get('sha256') if type(native) is dict else None)
        observed = (evidence.get('checker'), evidence.get('core_sha256'), base,
                    evidence.get('base_sha256'), evidence.get('candidate_sha256'),
                    plan.get('core_sha256') if type(plan) is dict else None, evidence.get('actual_sha256'))
        code, decision = self._request(_paired_packet(header, map(_proof_text, expected),
                                                     map(_proof_text, observed)))
        if code != 1 or not 0 <= decision <= PROOF_INDEPENDENT_MACHINE:
            raise RuntimeError('invalid HIA verification evidence decision')
        return decision

    def finite_function(self, function):
        blocks = function['blocks']
        count = sum(len(block['ops']) for block in blocks)
        if len(blocks) > 128 or count > 4096:
            packet = struct.pack('<6Q', MAGIC, 11, len(blocks), 0, count, 0)
        else:
            indexes = {block['id']: index for index, block in enumerate(blocks, 1)}
            effects = 0
            for effect in function['effects']:
                effects |= PROOF_EFFECT_IDS.get(effect, 1 << 63)
            packet = bytearray(struct.pack('<6Q', MAGIC, 11, len(blocks), indexes[function['entry']],
                                           count, effects))
            for block in blocks:
                term = block['term']
                if term['op'] == 'jump':
                    packet.extend((indexes[term['target']], 0))
                elif term['op'] == 'branch':
                    packet.extend((indexes[term['then']['target']], indexes[term['else']['target']]))
                else:
                    packet.extend((0, 0))
            packet.extend(PROOF_OPCODE_IDS.get(op['op'], 0) for block in blocks for op in block['ops'])
        valid, eligible = self._response(bytes(packet), 24, '<3Q', workspace=384)
        if valid != 1 or eligible not in (0, 1):
            raise RuntimeError('invalid HIA finite-function decision')
        return bool(eligible)

    def finite_domain(self, parameters, consumed):
        request = struct.pack('<4Q', MAGIC, 12, consumed, len(parameters))
        if len(parameters) <= 12:
            request += bytes(1 if name == 'bool' else WIDTHS.get(name, 255) for name in parameters)
        valid, needed, total = self._response(request, 32, '<4Q')
        if valid != 1 or needed > 4096 or total != consumed + needed or total > 4096:
            raise RuntimeError('invalid HIA finite-domain decision')
        return needed, total

    def exact_bytes_equal(self, left: bytes, right: bytes) -> bool:
        if type(left) is not bytes or type(right) is not bytes:
            raise TypeError('HIA Agent exact comparison requires bytes')
        for offset in range(0, max(1, len(left), len(right)), EXACT_COMPARISON_CHUNK):
            end = offset + EXACT_COMPARISON_CHUNK
            packet = _paired_packet(struct.pack('<2Q', MAGIC, 13), (left[offset:end],), (right[offset:end],))
            valid, equal = self._request(packet)
            if valid != 1 or equal not in (0, 1):
                raise RuntimeError('invalid HIA Agent exact comparison result')
            if not equal:
                return False
        return True

    def artifact_input(self, source):
        """Marshal an admitted source, returning inline bytes or a capture limit."""
        kind = source['kind'].encode('ascii')
        # Marshal the caller's Unicode scalars, not the retained UTF-8 bytes.
        if 'text' in source:
            payload = source['text'].encode('utf-32-le', 'surrogatepass')
            capacity = len(payload) + 16
        else:
            payload = struct.pack('<Q', int(source['max_bytes']))
            capacity = 24
        raw = self._variable_response(struct.pack('<2Q', MAGIC, 19) + kind + payload, capacity)
        if len(raw) < 16:
            raise RuntimeError('invalid HIA Agent artifact input')
        magic, mode = struct.unpack_from('<2Q', raw)
        if magic != RESULT_MAGIC:
            raise RuntimeError('invalid HIA Agent artifact input')
        if mode == 0:
            return raw[16:], None
        if mode == 1 and len(raw) == 24:
            return None, struct.unpack_from('<Q', raw, 16)[0]
        raise RuntimeError('invalid HIA Agent artifact input')

    def artifact_receipt(self, reference, size):
        fragment = wire(reference)
        packet = struct.pack('<4Q', MAGIC, 20, size, len(fragment)) + fragment
        return decode_data(self._variable_response(packet, len(fragment) + 160))

    def _variable_response(self, packet, capacity):
        source = ctypes.create_string_buffer(packet)
        result = ctypes.create_string_buffer(capacity)
        used = self._entry(source, len(packet), result, capacity, None, 0)
        if used == 4294967294:
            raise HIAEditRejected('E_HIA_EDIT: JSON encoding exceeds byte budget')
        if not 0 < used <= capacity:
            raise RuntimeError('HIA refused the admitted Agent packet')
        return result.raw[:used]

    def context_manifest(self, args, catalog_sha256, installation, baseline_sha, exports, sampled, target):
        system, machine, cpu_count = target
        fields = (baseline_sha, args['baseline_program'], args['budget'], catalog_sha256,
                  args['compiler_profile'], exports, installation, args['objective'], sampled,
                  cpu_count, machine, system, args['target_profile'], args['workload'])
        return self._issued_record(21, fields)

    def context_receipt(self, args, context, manifest, sampled):
        fields = (args['compiler_profile'], context, manifest, sampled, args['target_profile'])
        return decode_data(self._issued_record(22, fields))

    def context_id(self, nonce):
        if type(nonce) is not bytes or len(nonce) != 16:
            raise ValueError('HIA context ID requires a 16-byte nonce')
        raw = self._variable_response(struct.pack('<2Q', MAGIC, 23) + nonce, 36)
        if len(raw) != 36:
            raise RuntimeError('invalid HIA context ID')
        return raw.decode('ascii')

    def page_receipt(self, artifact, content, encoding, next_cursor):
        return decode_data(self._issued_record(24, (artifact, content, encoding, next_cursor)))

    def candidate_receipt(self, base, candidate, diagnostics):
        return decode_data(self._issued_record(25, (base, candidate, diagnostics)))

    def verification_record(self, binding, checks, installation, validation_profile):
        fields = (binding['base_core_sha256'], binding['base_program'], binding['candidate'],
                  binding['candidate_core_sha256'], checks, binding['context'], installation,
                  binding['subject'], validation_profile)
        return self._issued_record(26, fields)

    def verification_result(self, binding, checks, verification_receipt):
        fields = (binding['candidate'], checks, binding['subject'], verification_receipt)
        return decode_data(self._issued_record(27, fields))

    def build_record(self, metadata, backend, target, artifact, native_build, verification):
        fields = (backend, metadata['candidate'], metadata['codegen'], metadata['context'],
                  metadata['core_sha256'], metadata['foreign_buffer_exports'], metadata['installation'],
                  metadata['machine_plan'], artifact, native_build, metadata['object_artifact'],
                  metadata['object_sha256'], metadata['output_kind'], metadata['signatures'],
                  target, verification)
        return self._issued_record(28, fields)

    def build_result(self, candidate, backend, target, receipt, artifact, *, linked):
        return decode_data(self._issued_record(29, (backend, receipt, candidate, linked, artifact, target)))

    def issued_artifact(self, digest, identity_nonce, uri_nonce):
        if (type(identity_nonce) is not bytes or len(identity_nonce) != 16
                or type(uri_nonce) is not bytes or len(uri_nonce) != 16):
            raise ValueError('HIA artifact reference requires two 16-byte nonces')
        packet = struct.pack('<2Q', MAGIC, 30) + digest.encode('ascii') + identity_nonce + uri_nonce
        return decode_data(self._variable_response(packet, 256))

    def artifact_key_material(self, content_digest, kind, metadata):
        # One bounded forest preserves the original combined node/depth limit.
        packet = struct.pack('<2Q', MAGIC, 38) + wire((kind, metadata, content_digest))
        return self._variable_response(packet, min(MAX_INPUT_BYTES, len(packet) + 32))

    def adoption_record(self, args, previous, current, baseline):
        fields = (args['candidate_artifact'], args['context'], current, args['evaluation_receipt'],
                  previous, baseline, args['target_slot'], args['verification_receipts'])
        return self._issued_record(31, fields)

    def adoption_result(self, args, previous, current, receipt):
        fields = (args['candidate_artifact'], receipt, current, previous, args['target_slot'])
        return decode_data(self._issued_record(32, fields))

    def rollback_record(self, args, previous, current, artifact):
        fields = (artifact, args['context'], current, previous, args['reason'], args['target_slot'])
        return self._issued_record(33, fields)

    def rollback_result(self, args, previous, current, artifact, receipt):
        fields = (artifact, current, previous, receipt, args['target_slot'])
        return decode_data(self._issued_record(34, fields))

    def measurement_record(self, args, context, *, before, after, ratio, scope, metric,
                           native_runs, observations, outcome, planned_cases, complete,
                           reference_runs, reference_ns):
        fields = (args['baseline_artifact'], str(before), args['candidate_artifact'], str(after),
                  args['context'], ratio, scope, metric, native_runs, context['objective'],
                  observations, outcome, planned_cases, complete, reference_runs, str(reference_ns),
                  context['workload'])
        # Admit the full forest in one bounded pass (including the record's
        # three fixed scalar fields); per-fragment budgets do not compose.
        packet = struct.pack('<2Q', MAGIC, 35) + wire((*fields, 0, 0, 0))
        return self._variable_response(packet, min(MAX_INPUT_BYTES, len(packet) + 1024))

    def evaluation_record(self, args, baseline_sha, candidate_sha, installation, measurements,
                          ledger, outcome, complete):
        fields = (args['baseline_artifact'], baseline_sha, args['build_receipt'],
                  args['candidate_artifact'], candidate_sha, args['context'], ledger,
                  installation, measurements, outcome, complete, args['verification_receipts'])
        return self._issued_record(36, fields)

    def evaluation_result(self, args, receipt, measurements, ledger, outcome, complete):
        fields = (args['baseline_artifact'], args['candidate_artifact'], receipt, ledger,
                  measurements, outcome, complete)
        return decode_data(self._issued_record(37, fields))

    def _issued_record(self, mode, values):
        packet = bytearray(struct.pack('<2Q', MAGIC, mode))
        for value in values:
            fragment = wire(value)
            packet.extend(struct.pack('<Q', len(fragment)))
            packet.extend(fragment)
        return self._variable_response(bytes(packet), min(MAX_INPUT_BYTES, len(packet) + 512))

    def _cost_word_totals(self, rows):
        wire = struct.pack('<2Q', MAGIC, 6) + b''.join(
            struct.pack('<2Q', scope, value) for scope, value in rows)
        context_low, context_high, unscoped_low, unscoped_high = self._response(wire, 40, '<5Q')
        if context_high + unscoped_high > len(rows):
            raise RuntimeError('invalid HIA Agent cost totals')
        return (context_high << 64) | context_low, (unscoped_high << 64) | unscoped_low

    def cost_window(self, observed_count):
        valid, retained = self._request(struct.pack('<3Q', MAGIC, 17, observed_count))
        if valid != 1 or retained > observed_count:
            raise RuntimeError('invalid HIA Agent observed-cost window')
        return retained

    def cost_ledger_header(self, context_ref, observed_count, policy, totals, evaluation_ns, native_ns):
        """Transport the captured values; HIA owns the report policy and shape."""
        attributed, unscoped = totals
        external = policy['external_costs']
        fields = (context_ref, str(attributed), str(evaluation_ns), external['discovery_wall_ns'],
                  external['model_tokens'], external['model_wall_ns'], policy['expected_invocations'],
                  str(native_ns), str(unscoped))
        packet = bytearray(struct.pack('<4Q', MAGIC, 16, observed_count, int(policy['external_costs_complete'])))
        for value in fields:
            fragment = wire(value)
            packet.extend(struct.pack('<Q', len(fragment)))
            packet.extend(fragment)
        capacity = min(MAX_INPUT_BYTES, len(packet) + 2048)
        source = ctypes.create_string_buffer(bytes(packet))
        output = ctypes.create_string_buffer(capacity)
        size = self._entry(source, len(packet), output, capacity, None, 0)
        if size == 4294967294:
            raise HIAEditRejected('E_HIA_EDIT: JSON encoding exceeds byte budget')
        if not 0 < size <= capacity:
            raise RuntimeError('invalid HIA Agent cost receipt')
        return decode_data(output.raw[:size])

    def cost_ledger_record(self, context_ref, observed_count, policy, totals, evaluation_ns, native_ns, rows):
        """Marshal stored values, leaving canonical report and row emission to HIA."""
        attributed, unscoped = totals
        external = policy['external_costs']
        costs = tuple(external[name] for name in ('discovery_wall_ns', 'model_tokens', 'model_wall_ns'))
        # Positional tuples have the same depth and number of value nodes as
        # the original record. Placeholders account for HIA's fixed scalars.
        values = (context_ref, str(attributed), rows, str(evaluation_ns), costs,
                  policy['expected_invocations'], str(native_ns), str(unscoped), *([0] * 9))
        packet = struct.pack('<4Q', MAGIC, 41, observed_count, int(policy['external_costs_complete'])) + wire(values)
        # Row keys and separators are not in the transport. Their combined
        # output overhead is bounded by 96 bytes per row plus the outer keys.
        return self._variable_response(packet, min(MAX_INPUT_BYTES, len(packet) + 2048 + 96 * len(rows)))

    def observed_cost_totals(self, rows, context_id):
        # Match the Store's historic integer text decoder. New elapsed times
        # fit a word; imported historical integers keep their exact value.
        values = [(int(row['context_id'] is None), int(row['wall_ns']))
                  for row in rows if row['context_id'] in (context_id, None)]
        if all(0 <= value <= WORD_MASK for _, value in values):
            return self._cost_word_totals(values)
        positive = self._cost_magnitude_totals([(scope, value) for scope, value in values if value > 0])
        negative = self._cost_magnitude_totals([(scope, -value) for scope, value in values if value < 0])
        return positive[0] - negative[0], positive[1] - negative[1]

    def _cost_magnitude_totals(self, values):
        context = unscoped = offset = 0
        while values:
            words = [(scope, value & WORD_MASK) for scope, value in values]
            context_word, unscoped_word = self._cost_word_totals(words)
            context += context_word << offset
            unscoped += unscoped_word << offset
            offset += 64
            values = [(scope, value >> 64) for scope, value in values if value > WORD_MASK]
        return context, unscoped

    def uint64(self,value):return self.scalar(value,0)
    def digest(self,value):return self.scalar(value,1)is not None


def installed_agent_identity(path):
    return _installed_json_image(path,SOURCE,SCHEMA,NativeAgentIdentity)
