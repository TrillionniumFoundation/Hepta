import pathlib,os,sys,subprocess,json,hashlib,difflib,time
S=pathlib.Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/source')
D=pathlib.Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-runtime-installed-public-04fe-20261127-2ac5/worker-generator-check-v1');D.mkdir(mode=0o700,parents=True,exist_ok=False)
T=pathlib.Path('/home/qian-qi/runtime-installed-public-04fe-20261127-2ac5/worker-generator-tmp-v1');T.mkdir(mode=0o700,exist_ok=False)
env=dict(os.environ,TMPDIR=str(T),PYTHONDONTWRITEBYTECODE='1')
py='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
start=time.monotonic();p=subprocess.run([py,'-B','-m','tools.generate_hia_worker_install_owner','--check'],cwd=S,env=env,capture_output=True,timeout=60)
(D/'original-check.stdout').write_bytes(p.stdout);(D/'original-check.stderr').write_bytes(p.stderr)
print('ORIGINAL_CHECK',json.dumps({'rc':p.returncode,'seconds':time.monotonic()-start,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}),flush=True)
os.environ['TMPDIR']=str(T);sys.path.insert(0,str(S))
from tools import generate_hia_worker_install_owner as g
rows=[]
for name,source in [('worker_install_owner',g.policy_source()),('worker_install_dag',g.policy_source(stage=True)),('worker_install_owner_packer',g.packer_source())]:
 old=(S/'examples/hia_bootstrap'/f'{name}.hepta').read_bytes()
 new=g.render_assembly(g.document(source,name)).encode()
 (D/f'{name}.hepta').write_bytes(new);(D/f'{name}.author.py').write_text(source)
 diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='exact04/'+name,tofile='current-generated/'+name))
 (D/f'{name}.diff').write_text(diff)
 row=dict(name=name,old_bytes=len(old),old_sha256=hashlib.sha256(old).hexdigest(),new_bytes=len(new),new_sha256=hashlib.sha256(new).hexdigest(),equal=old==new,diff_bytes=len(diff.encode()))
 rows.append(row);print('GENERATED',json.dumps(row),flush=True)
print('DAGS',g.base.RELEASE_DAGS,flush=True)
(D/'result.json').write_text(json.dumps({'original_check_rc':p.returncode,'release_dags':g.base.RELEASE_DAGS,'generated':rows},indent=2)+'\n')
print('AUTHOR_DAG_GUARDS',json.dumps([l for l in g.policy_source(stage=True).splitlines() if any(q in l for q in ['1519984','1812000'])]),flush=True)
