import ctypes,mmap,pathlib,struct,json,hashlib,sys
S=pathlib.Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-worker-release-dag-closure-20261127-2ac5/source')
O=pathlib.Path('/home/qian-qi/hia-worker-release-dag-closure-20261127-2ac5')
sys.path.insert(0,str(S));from tools.generate_hia_worker_install_owner import STAGES
from tools.generate_hia_release_owner import RELEASE_DAGS
paths=[f'examples/hia_bootstrap/release_stage_{k}.hiastd' for k in RELEASE_DAGS]+[f'examples/hia_bootstrap/worker_install_{k}.hiastd' for k in STAGES]
pins={p:hashlib.sha256((S/p).read_bytes()).digest() for p in paths}
inv=struct.pack('<8sQ',b'HIASPI01',len(pins))+b''.join(struct.pack('<Q',len(p.encode()))+pins[p]+p.encode() for p in sorted(pins))
req=struct.pack('<8s15Q',b'HIAWIN01',0,1,*range(3,13),1,len(inv),0)+bytes(160)+b'x'+inv
def put(state,at,*values):struct.pack_into('<'+'Q'*len(values),state,at,*values)
def get(state,at):return struct.unpack_from('<Q',state,at)[0]
def native(raw):
 mapping=mmap.mmap(-1,len(raw),prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC);mapping.write(raw)
 f=ctypes.CFUNCTYPE(ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64)(ctypes.addressof(ctypes.c_ubyte.from_buffer(mapping)))
 return mapping,f
def invoke(f,state):
 plan=bytearray(128);a=(ctypes.c_ubyte*len(req)).from_buffer_copy(req);b=(ctypes.c_ubyte*128).from_buffer(plan);c=(ctypes.c_ubyte*len(state)).from_buffer(state)
 result=f(a,len(req),b,128,c,len(state))
 return result,plan

import gzip,time,subprocess,os
D=O/'native-package-guards-v1';D.mkdir(mode=0o700)
pin=bytes.fromhex('201fd124d0c6fc80cb9ad97816e4f69cbc1ea669462b3f86d168566f57817f7e')
rows=[]
for label in ('original','candidate'):
 mm,primary=native((O/label/'worker_install_owner.image.bin').read_bytes())
 dm,dag=native((O/label/'worker_install_dag.image.bin').read_bytes())
 state=bytearray(4<<20);r,p=invoke(primary,state)
 assert (r,get(p,0),get(p,8))==(1,60,65)
 put(state,0,7999,0);r,p=invoke(dag,state)
 assert (r,get(p,0),get(p,8))==(1,60,65)
 base=bytes(state)
 cases=[
 ('matching-size',7002,194753597,0o100400,0,False,(3,250)),
 ('missing-twelve-members',7002,169092914,0o100400,0,False,(1,99999)),
 ('size-plus-one',7002,194753598,0o100400,0,False,(1,99999)),
 ('directory-type',7002,194753597,0o40700,0,False,(1,99999)),
 ('stat-error',7002,194753597,0o100400,(1<<64)-13,False,(1,99999)),
 ('matching-digest',7003,194753597,0o100400,0,False,(1,7004)),
 ('digest-mismatch',7003,194753597,0o100400,0,True,(1,99999)),
 ('worker-start',7019,194753597,0o100400,0,False,(4,5000)),
 ]
 for name,phase,size,mode,sysret,bad,expected in cases:
  q=bytearray(base);put(q,0,phase,sysret);put(q,1224,mode);put(q,1248,size)
  put(q,1800024,194753597);put(q,1800136,37)
  q[1800032:1800064]=pin;q[4096:4128]=pin
  if bad:q[4096]^=1
  before=bytes(q);r,p=invoke(dag,q)
  row=dict(label=label,case=name,result=r,phase=get(q,0),syscall=get(p,0),arg0=get(p,8),worker_mode=get(q,1800000),dag_index=get(q,1519984))
  assert (r,get(q,0))==expected,row
  if name in ('missing-twelve-members','size-plus-one','directory-type','digest-mismatch'):assert (get(p,0),get(p,8))==(60,65),row
  if name=='stat-error':assert (get(p,0),get(p,8))==(60,74),row
  if name=='matching-size':assert get(q,72)==7003 and get(q,40)==37 and get(q,48)==194753597,row
  if name=='matching-digest':assert (get(p,0),get(p,8))==(3,37),row
  if name=='worker-start':
   assert get(q,1800000)==1 and get(q,1519984)==(5 if label=='original' else len(RELEASE_DAGS)),row
  raw=struct.pack('<4Q',len(req),len(before),len(q),len(p))+req+before+bytes(q)+bytes(p)
  packed=gzip.compress(raw,mtime=0);(D/f'{label}-{name}.bin.gz').write_bytes(packed)
  assert gzip.decompress(packed)==raw
  row.update(passed=True,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),archive_sha256=hashlib.sha256(packed).hexdigest())
  rows.append(row)
 mm.close();dm.close()
(D/'qualification.json').write_text(json.dumps({'scope':'NATIVE_COMPONENT_ONLY_NOT_INSTALLATION_OR_COLD_ADMISSION','calls':rows},indent=2)+'\n')
print('NATIVE_GUARDS',len(rows),'PASS',flush=True)
T=O/'tmp';env=dict(os.environ,TMPDIR=str(T),PYTHONDONTWRITEBYTECODE='1',PATH='/usr/bin:/bin')
py='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
V=O/'generation-gates-v1';V.mkdir(mode=0o700)
records=[]
for name,cmd in [('generator-check',[py,'-B','-m','tools.generate_hia_worker_install_owner','--check']),('original-regression-tests',[py,'-B','-m','unittest','-v','tests.test_hia_worker_install_owner_generation'])]:
 start=time.monotonic();p=subprocess.run(cmd,cwd=S,env=env,capture_output=True,timeout=60)
 (V/(name+'.stdout')).write_bytes(p.stdout);(V/(name+'.stderr')).write_bytes(p.stderr)
 row={'name':name,'command':cmd,'seconds':time.monotonic()-start,'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
 records.append(row);print('GENERATION_GATE',json.dumps(row),flush=True);assert p.returncode==0
(V/'qualification.json').write_text(json.dumps(records,indent=2)+'\n')
from tools.build_hia_source_build import _named_source_request
from tools.qualify_hia_worker_install_sources import qualify
K=O/'source-kit-v1';K.mkdir(mode=0o700)
seed=pathlib.Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/depot/201fd124d0c6fc80cb9ad97816e4f69cbc1ea669462b3f86d168566f57817f7e/hia-source-build')
named={alias:(S/'examples/hia_bootstrap'/name).read_bytes() for alias,name in [('source_build_policy.hepta','source_release_kit.hepta'),('selfhost.hepta','selfhost.hepta'),('source_build_packer.hepta','source_build_packer.hepta')]}
records=[]
wire=_named_source_request(named)
for op in ('sources','pack'):
 start=time.monotonic();p=subprocess.run([str(seed),op],input=wire,capture_output=True,env={'PATH':''},timeout=180)
 (K/(op+'.stdin')).write_bytes(wire);(K/(op+'.stdout')).write_bytes(p.stdout);(K/(op+'.stderr')).write_bytes(p.stderr)
 row=dict(operation=op,returncode=p.returncode,seconds=time.monotonic()-start,input_sha256=hashlib.sha256(wire).hexdigest(),output_sha256=hashlib.sha256(p.stdout).hexdigest(),output_bytes=len(p.stdout),stderr_bytes=len(p.stderr))
 records.append(row);print('KIT',json.dumps(row),flush=True)
 assert p.returncode==0 and p.stdout and not p.stderr
 wire=p.stdout
assert wire.startswith(b'\x7fELF')
kit=K/'hia-source-release-kit';kit.write_bytes(wire);kit.chmod(0o500)
(K/'qualification.json').write_text(json.dumps({'scope':'NATIVE_COMPONENT_KIT_REBUILT_FROM_EXACT_SOURCE','source_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in named.items()},'seed_sha256':hashlib.sha256(seed.read_bytes()).hexdigest(),'calls':records},indent=2)+'\n')
report=qualify(S,seed,kit,O/'member-qualification-v1')
print('ORIGINAL_MEMBER_GATE',json.dumps({'status':report['status'],'members':report['members'],'refusal_cases':report['refusal_cases'],'calls':len(report['calls'])}),flush=True)
