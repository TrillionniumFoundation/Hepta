import ctypes,mmap,pathlib,struct,json,hashlib,sys
S=pathlib.Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-worker-release-dag-closure-20261127-2ac5/source')
O=pathlib.Path('/home/qian-qi/hia-worker-release-dag-closure-20261127-2ac5')
sys.path.insert(0,str(S));from tools.generate_hia_worker_install_owner import STAGES
from tools.generate_hia_release_owner import RELEASE_DAGS
paths=[f'examples/hia_bootstrap/release_stage_{k}.hiastd' for k in RELEASE_DAGS]+[f'examples/hia_bootstrap/worker_install_{k}.hiastd' for k in STAGES]
pins={p:hashlib.sha256((S/p).read_bytes()).digest() for p in paths}
inv=struct.pack('<8sQ',b'HIASPI01',len(pins))+b''.join(struct.pack('<Q',len(p.encode()))+pins[p]+p.encode() for p in sorted(pins))
req=struct.pack('<8s15Q',b'HIAWIN01',0,1,*range(3,13),1,len(inv),0)+bytes(160)+b'x'+inv
def put(state,at,*values):struct.pack_into('<'+'Q'*len(values),state,at,*values)
def get(state,at):return struct.unpack_from('<Q',state,at)[0]
def native(raw):
 mapping=mmap.mmap(-1,len(raw),prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC);mapping.write(raw)
 f=ctypes.CFUNCTYPE(ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_uint64)(ctypes.addressof(ctypes.c_ubyte.from_buffer(mapping)))
 return mapping,f
def invoke(f,state):
 plan=bytearray(128);a=(ctypes.c_ubyte*len(req)).from_buffer_copy(req);b=(ctypes.c_ubyte*128).from_buffer(plan);c=(ctypes.c_ubyte*len(state)).from_buffer(state)
 result=f(a,len(req),b,128,c,len(state))
 return result,plan
rows=[]
for label in ('original','candidate'):
 maps=[];funcs=[]
 for name in ('worker_install_owner','worker_install_dag'):
  mm,f=native((O/label/f'{name}.image.bin').read_bytes());maps.append(mm);funcs.append(f)
 state=bytearray(4<<20);r,p=invoke(funcs[0],state)
 assert r==1 and get(p,0)==60 and get(p,8)==65
 assert get(state,80)==len(pins)
 put(state,0,7999,0);r,p=invoke(funcs[1],state)
 assert r==1 and get(p,0)==60 and get(p,8)==65
 base=bytes(state)
 for mode,kinds in ((0,RELEASE_DAGS),(1,STAGES)):
  for i,kind in enumerate(kinds):
   q=bytearray(base);index=i if mode==0 else len(RELEASE_DAGS)+i
   put(q,0,5000,0);put(q,1519984,index);put(q,1800000,mode)
   result,plan=invoke(funcs[1],q)
   row={'label':label,'mode':mode,'index':index,'kind':kind,'result':result,'phase':get(q,0),'syscall':get(plan,0),'arg0':get(plan,8)}
   if result==1 and get(plan,0)==319:
    raw=bytes(q[get(q,904):get(q,904)+get(q,912)])
    n,a,reserved=struct.unpack_from('<3Q',raw,32)
    path=raw[88:88+n].decode();digest=raw[56:88]
    row.update(path=path,pin_sha256=digest.hex(),pin_matches_real_source=path in pins and digest==pins[path])
   else:row['path']=None
   expected=f'examples/hia_bootstrap/{"release_stage" if mode==0 else "worker_install"}_{kind}.hiastd'
   row['expected_path']=expected;row['passed']=row['path']==expected and row.get('pin_matches_real_source') is True
   rows.append(row)
  q=bytearray(base);put(q,0,5000,0);put(q,1519984,len(RELEASE_DAGS)+(len(STAGES) if mode else 0));put(q,1800000,mode)
  result,plan=invoke(funcs[1],q)
  rows.append({'label':label,'mode':mode,'kind':'end','result':result,'phase':get(q,0),'passed':result==4 and get(q,0)==(7800 if mode else 6000)})
 for mm in maps:mm.close()
(O/'native-stage-probes-v1.json').write_text(json.dumps(rows,indent=2)+'\n')
for label in ('original','candidate'):
 selected=[x for x in rows if x['label']==label]
 print('SUMMARY',label,len(selected),sum(x['passed'] for x in selected),flush=True)
 print(json.dumps(selected,indent=2),flush=True)
assert all(x['passed'] for x in rows if x['label']=='candidate')
assert not all(x['passed'] for x in rows if x['label']=='original')
