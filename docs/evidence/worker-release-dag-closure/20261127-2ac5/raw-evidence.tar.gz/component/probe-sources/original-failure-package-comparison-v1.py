import pathlib,os,stat,hashlib,json,time
R=pathlib.Path('/home/qian-qi/hia-native-current-future-20261127-2ac5')
P=pathlib.Path('/home/qian-qi/runtime-installed-public-04fe-20261127-2ac5/public19-v3')
F=P/'private/.hia-build-41b5031df3c5e0cd89a1faefa3ced7c6'
D=pathlib.Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-runtime-installed-public-04fe-20261127-2ac5/worker-package-comparison-v1')
D.mkdir(mode=0o700,parents=True,exist_ok=False)
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_uid,s.st_gid,s.st_nlink]
def info(p):
 before=stamp(p);h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 assert stamp(p)==before
 return dict(bytes=before[3],sha256=h.hexdigest(),mode=oct(stat.S_IMODE(before[2])),stamp=before)
def inventory(p):
 d={}
 for q in sorted(p.rglob('*')):
  if q.is_file() and not q.is_symlink():d[q.relative_to(p).as_posix()]=info(q)
  else:d[q.relative_to(p).as_posix()]={'special':str(q.lstat().st_mode)}
 return d
orig=R/'chain-v2/depot/201fd124d0c6fc80cb9ad97816e4f69cbc1ea669462b3f86d168566f57817f7e'
rebuilt=F/'work/verified/4353de273aeea3a9d76a70df629812578f567e0c84f9d1d5d7b108ebc7cf3d03'
a=inventory(orig);b=inventory(rebuilt)
def sig(x):return {k:x.get(k) for k in ['bytes','sha256','mode','special']}
diff=[{'path':k,'original':sig(a[k]),'rebuilt':sig(b[k])} for k in sorted(a.keys()&b.keys()) if sig(a[k])!=sig(b[k])]
pkgs={}
for p in [R/'chain-v2/release/store.hiapack',F/'work/store.hiapack',F/'work/authority.hiapack',P/'private/native-installation/store.hiapack']:
 if p.exists():pkgs[str(p)]=info(p)
result={'source':'04feaffc29bd77ae4ab3695eb08602726a01ba1c','packages':pkgs,'original_member_count':len(a),'rebuilt_member_count':len(b),'only_original':sorted(a.keys()-b.keys()),'only_rebuilt':sorted(b.keys()-a.keys()),'changed':diff,'original_members':a,'rebuilt_members':b}
(D/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['original_members','rebuilt_members']},indent=2),flush=True)
for root in [F,F/'work',F/'stage',P/'private/native-installation']:
 print('LIST',str(root),json.dumps([{'name':p.name,'bytes':p.lstat().st_size,'mode':oct(p.lstat().st_mode)} for p in sorted(root.iterdir())] if root.exists() else None),flush=True)
