def stage(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(o) != 128 or length(w) != 4194304:
        return 0
    return dag(s, o, w, get(w, 0), get(w, 8))

def dag(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase >= 60 and phase < 70:
        return worker_admission(s, o, w, phase, r)
    if phase >= 7000:
        if get(w, 1800704) == 0:
            worker_constants(w)
            put(w, 1800704, 1)
        return worker_business(s, o, w, phase, r)
    if phase == 5870 or phase == 5871:
        return worker_drop(s, o, w, phase, r)
    if phase == 5890 or phase == 5891:
        return worker_retain(s, o, w, phase, r)
    if phase >= 5900:
        return worker_publish(s, o, w, phase, r)
    if phase >= 5600:
        return dag_codec(s, o, w, phase, r)
    if phase >= 5200 and phase < 5300:
        return dag_kit(s, o, w, phase, r)
    if phase >= 5300 and phase < 5400:
        return dag_pick(s, o, w, phase, r)
    if phase >= 5400 and phase < 5500:
        return dag_run(s, o, w, phase, r)
    if phase >= 5500:
        return dag_check(s, o, w, phase, r)
    if phase == 5000:
        if get(w, 1800000) == 1 and get(w, 1519984) == 24:
            return resume(s, o, w, 7800)
        if get(w, 1800000) == 0 and get(w, 1519984) == 8:
            return resume(s, o, w, 6000)
        path = 604000 + get(w, 1519984) * 16
        if get(w, 1800000) == 1:
            path = 1812000 + (get(w, 1519984) - 8) * 16
        return capture_request(o, w, capture_one(s, w, get(w, path), get(w, path + 8), 600592, 4, 3544428844805081416), 5001)
    if phase == 5001:
        if get(w, 152) < 24 or get(w, 152) > 1048576:
            return finish(o, w, 65)
        put(w, 1500000, get(w, 144))
        put(w, 1500008, get(w, 152))
        return reading(o, w, get(w, 144), 2097152, get(w, 152), 0, 5002)
    if phase == 5002:
        if get(w, 2097152) != 3544408035705309512 or get(w, 2097160) == 0 or get(w, 2097160) > 8192 or get(w, 2097168) > 512:
            return finish(o, w, 65)
        put(w, 1500016, get(w, 2097160))
        put(w, 1500024, get(w, 2097168))
        put(w, 1500032, 2097176)
        put(w, 1500040, 0)
        put(w, 1500104, get(w, 1599904))
        return call(o, w, 5003, 3, get(w, 1500000), 0, 0, 0, 0, 0, 0)
    if phase == 5003:
        if get(w, 1500040) == get(w, 1500016):
            if get(w, 1500032) != 2097152 + get(w, 1500008) or get(w, 1599904) - get(w, 1500104) != get(w, 1500024):
                return finish(o, w, 65)
            put(w, 1500120, 1)
            return resume(s, o, w, 5010)
        if dag_node(w) == 0:
            return finish(o, w, 65)
        return dag_execute(s, o, w)
    if phase == 5004:
        return dag_commit(o, w, 1)
    if phase == 5005:
        return dag_commit(o, w, 0)
    if phase == 5010:
        if get(w, 1500120) > 2048:
            put(w, 1519984, get(w, 1519984) + 1)
            return resume(s, o, w, 5000)
        row = 1048576 + get(w, 1500120) * 64
        put(w, 1500120, get(w, 1500120) + 1)
        fd = get(w, row)
        own = get(w, row + 56)
        put(w, row, 0)
        put(w, row + 56, 0)
        if own == 1:
            return call(o, w, 5010, 3, fd, 0, 0, 0, 0, 0, 0)
        return resume(s, o, w, 5010)
    return finish(o, w, 65)

def dag_node(w:mutbuf) -> u64:
    at = get(w, 1500032)
    end = 2097152 + get(w, 1500008)
    if at > end or end - at < 32:
        return 0
    op = get(w, at)
    id = get(w, at + 8)
    count = get(w, at + 16)
    size = get(w, at + 24)
    if op < 1 or op > 22 or count > 132 or size > 1048576 or 32 + count * 8 + size > end - at:
        return 0
    if (op >= 7 and op <= 10) or op == 20 or op == 21 or op == 22:
        if id != 0:
            return 0
    else:
        if id == 0 or id > 2048 or get(w, 1048576 + id * 64) != 0:
            return 0
    put(w, 1500048, op)
    put(w, 1500056, id)
    put(w, 1500064, count)
    put(w, 1500072, at + 32 + count * 8)
    put(w, 1500080, size)
    put(w, 1500088, at + 32 + count * 8 + size)
    put(w, 1500096, at + 32)
    put(w, 1500136, 0)
    put(w, 1500144, 0)
    put(w, 1500152, 0)
    put(w, 1500160, 0)
    put(w, 1500168, 0)
    return 1

def dag_arg(w:mutbuf, index:u64) -> u64:
    if index >= get(w, 1500064):
        return 18446744073709551615
    return get(w, get(w, 1500096) + index * 8)

def dag_handle(w:mutbuf, id:u64) -> u64:
    if id == 0 or id > 2048:
        return 0
    at = 1048576 + id * 64
    return choose(get(w, at) >= 3, at, 0)

def dag_commit(o:mutbuf, w:mutbuf, own:u64) -> u32:
    id = get(w, 1500056)
    if id != 0:
        row = 1048576 + id * 64
        if get(w, 144) < 3 or get(w, 152) > 67108864:
            return finish(o, w, 65)
        put(w, row, get(w, 144))
        put(w, row + 8, get(w, 1500136))
        put(w, row + 16, get(w, 152))
        put(w, row + 24, get(w, 1500144))
        put(w, row + 32, get(w, 1500152))
        put(w, row + 40, get(w, 1500160))
        put(w, row + 48, get(w, 1500168))
        put(w, row + 56, own)
    put(w, 1500032, get(w, 1500088))
    put(w, 1500040, get(w, 1500040) + 1)
    put(w, 0, 5003)
    put(w, 8, 0)
    return 4

def dag_execute(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    op = get(w, 1500048)
    if op == 22:
        return worker_drop(s, o, w, 5870, 0)
    if op == 21:
        return worker_retain(s, o, w, 5890, 0)
    if op == 20:
        return worker_publish(s, o, w, 5900, 0)
    if op == 1:
        if get(w, 1500064) != 1:
            return finish(o, w, 65)
        put(w, 1500144, 1)
        put(w, 1500152, get(w, 1500072))
        put(w, 1500160, 0)
        put(w, 1500168, dag_arg(w, 0))
        return capture_request(o, w, dag_capture(s, w), 5004)
    if op == 2 or op == 3:
        row = dag_handle(w, dag_arg(w, 0))
        if get(w, 1500064) != 1 or get(w, 1500080) != 0 or row == 0 or get(w, row + 24) != 1:
            return finish(o, w, 65)
        put(w, 1500144, op)
        put(w, 1500152, get(w, row + 32))
        put(w, 1500160, dag_arg(w, 0))
        put(w, 1500176, choose(op == 2, get(w, 216), get(w, 120)))
        put(w, 1500184, choose(op == 2, 1, 3))
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5400)
    if op == 4:
        return dag_pick(s, o, w, 5300, 0)
    if op == 5 or op == 10:
        if dag_frame(w) == 0:
            return finish(o, w, 65)
        return framed(o, w, 6144, choose(op == 5, 48, 40), 330000, get(w, 1500120), 5410)
    if op == 6 or op == 14:
        return dag_run(s, o, w, 5420, 0)
    if op == 7 or op == 8 or op == 9 or op == 13:
        return dag_check(s, o, w, 5500, 0)
    if op == 11:
        if get(w, 1500064) != 0 or dag_import(s, w) == 0:
            return finish(o, w, 65)
        return dag_commit(o, w, 0)
    if op == 12:
        if get(w, 1500064) != 0:
            return finish(o, w, 65)
        return seal_buffer(o, w, get(w, 1500072), get(w, 1500080), 5004)
    if op == 16:
        count = get(w, 1500064)
        if count > 128 or get(w, 1500080) != 0:
            return finish(o, w, 65)
        i = 0
        while i < count:
            row = dag_handle(w, dag_arg(w, i))
            if row == 0:
                return finish(o, w, 65)
            view(w, i, get(w, row), get(w, row + 8), get(w, row + 16))
            i = i + 1
        return frame(o, w, 6144, 0, 330000, count, 5004)
    if op == 17:
        row = dag_handle(w, dag_arg(w, 0))
        if get(w, 1500064) != 1 or get(w, 1500080) != 0 or row == 0:
            return finish(o, w, 65)
        put(w, 6144, get(w, row + 16))
        return seal_buffer(o, w, 6144, 8, 5004)
    if op == 18:
        return dag_codec(s, o, w, 5600, 0)
    if op == 19:
        count = get(w, 1500064)
        if count == 0 or count > 128 or get(w, 1500080) != 0:
            return finish(o, w, 65)
        i = 0
        offset = count * 8
        while i < count:
            row = dag_handle(w, dag_arg(w, i))
            if row == 0 or get(w, row + 16) > 67108864 - offset:
                return finish(o, w, 65)
            put(w, 6144 + i * 8, offset)
            offset = offset + get(w, row + 16)
            view(w, i, get(w, row), get(w, row + 8), get(w, row + 16))
            i = i + 1
        return frame(o, w, 6144, count * 8, 330000, count, 5004)
    if op == 15:
        row = dag_handle(w, dag_arg(w, 0))
        offset = dag_arg(w, 1)
        size = dag_arg(w, 2)
        if get(w, 1500064) != 3 or get(w, 1500080) != 0 or row == 0 or offset > get(w, row + 16):
            return finish(o, w, 65)
        size = choose(size == 18446744073709551615, get(w, row + 16) - offset, size)
        if size > get(w, row + 16) - offset:
            return finish(o, w, 65)
        put(w, 144, get(w, row))
        put(w, 152, size)
        put(w, 1500136, get(w, row + 8) + offset)
        return dag_commit(o, w, 0)
    return finish(o, w, 65)

def dag_capture(s:readbuf, w:mutbuf) -> u64:
    at = get(w, 1500072)
    end = at + get(w, 1500080)
    if end - at < 8 or get(w, at) == 0 or get(w, at) > 128:
        return 0
    count = get(w, at)
    wire = capture_begin(s, w, dag_arg(w, 0), count)
    at = at + 8
    i = 0
    while i < count:
        if at > end or end - at < 16:
            return 0
        an = get(w, at)
        pn = get(w, at + 8)
        if an == 0 or an > 127 or pn == 0 or pn > 4095 or an + pn > end - at - 16:
            return 0
        wire = capture_row(s, w, wire, at + 16 + an, pn, at + 16, an)
        if wire == 0:
            return 0
        at = at + 16 + an + pn
        i = i + 1
    return choose(at == end, wire - 393216, 0)

def dag_frame(w:mutbuf) -> u64:
    op = get(w, 1500048)
    skip = choose(op == 5, 4, 2)
    count = get(w, 1500064)
    if count < skip or count > skip + 128 or get(w, 1500080) != 0:
        return 0
    put(w, 6144, choose(op == 5, 3544410234728565064, 3544406936193681736))
    put(w, 6152, dag_arg(w, 0))
    put(w, 6160, dag_arg(w, 1))
    if op == 5:
        put(w, 6168, dag_arg(w, 2))
        put(w, 6176, dag_arg(w, 3))
        put(w, 6184, count - 4)
    else:
        put(w, 6168, count - 2)
        put(w, 6176, 0)
    i = skip
    while i < count:
        row = dag_handle(w, dag_arg(w, i))
        if row == 0:
            return 0
        view(w, i - skip, get(w, row), get(w, row + 8), get(w, row + 16))
        i = i + 1
    put(w, 1500120, count - skip)
    return 1

def dag_import(s:readbuf, w:mutbuf) -> u64:
    name = get(w, 1500072)
    size = get(w, 1500080)
    if size == 18 and same(w, name, 600752, size) == 1:
        put(w, 144, uint(s, 72))
        put(w, 152, get(w, 3024))
        return 1
    if size == 16 and same(w, name, 600608, size) == 1:
        put(w, 144, get(w, 216))
        put(w, 152, get(w, 3008))
        return 1
    row = find_product(w, name, size)
    if row != 0:
        put(w, 144, get(w, row))
        put(w, 152, get(w, row + 8))
        return 1
    i = 0
    while i < get(w, 1599904):
        row = 1600000 + i * 160
        if get(w, row + 16) == size and same(w, row + 32, name, size) == 1:
            put(w, 144, get(w, row))
            put(w, 152, get(w, row + 8))
            return 1
        i = i + 1
    return 0

def dag_run(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 5400:
        return launch(o, w, get(w, 1500176), get(w, 144), get(w, 1500184), 0, choose(get(w, 1500048) == 3, 5200, 5004))
    if phase == 5410:
        return launch(o, w, get(w, 321000), get(w, 144), 3, 0, choose(get(w, 1500048) == 10, 5411, 5004))
    if phase == 5411:
        if get(w, 152) != 32:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 49152, 32, 0, 5412)
    if phase == 5412:
        if get(w, 49152) != 3552019954704402760 or get(w, 49160) != dag_arg(w, 0) or get(w, 49168) != dag_arg(w, 1):
            return finish(o, w, 65)
        row = dag_handle(w, dag_arg(w, 2))
        if row == 0 or get(w, 49176) != get(w, row + 16):
            return finish(o, w, 65)
        return call(o, w, 5005, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 5420:
        expected = choose(get(w, 1500048) == 6, 3, 2)
        row = dag_handle(w, dag_arg(w, 0))
        if get(w, 1500064) != expected or get(w, 1500080) != 0 or row == 0:
            return finish(o, w, 65)
        size = get(w, row + 16)
        if get(w, row + 24) == 3:
            size = get(w, row + 48)
        if size < 176:
            return finish(o, w, 65)
        return extract_view(o, w, get(w, row), get(w, row + 8), size, 5421)
    if phase == 5421:
        put(w, 1500176, get(w, 144))
        operation = dag_arg(w, 1)
        if get(w, 1500048) == 14:
            if operation < 1 or operation > 9:
                return finish(o, w, 65)
            put(w, 1500184, operation + 16)
            return seal_buffer(o, w, 6144, 0, 5422)
        row = dag_handle(w, dag_arg(w, 2))
        if operation > 4 or row == 0:
            return finish(o, w, 65)
        put(w, 1500184, operation)
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5422)
    if phase == 5422:
        return launch(o, w, get(w, 1500176), get(w, 144), get(w, 1500184), 0, 5423)
    if phase == 5423:
        return call(o, w, 5004, 3, get(w, 1500176), 0, 0, 0, 0, 0, 0)
    return finish(o, w, 65)

def dag_kit(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 5200:
        if get(w, 152) < 240:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 1501000, 64, get(w, 152) - 64, 5201)
    if phase == 5201:
        size = get(w, 1501000)
        total = get(w, 1501008) + get(w, 1501016) + get(w, 1501024)
        if get(w, 1501056) != 3550891808395446600 or size != get(w, 152) - 64 or total > size or size - total < 176:
            return finish(o, w, 65)
        put(w, 1500168, size)
        put(w, 1500192, size - total)
        put(w, 1500200, 0)
        return resume(s, o, w, 5202)
    if phase == 5202:
        index = get(w, 1500200)
        if index == 3:
            return dag_commit(o, w, 1)
        size = get(w, 1501008 + index * 8)
        site = get(w, 1501032 + index * 8)
        if size == 0 or size > 1048576 or site <= 176 or site + 4 > get(w, 1500192):
            return finish(o, w, 65)
        j = 0
        while j < index:
            if site == get(w, 1501032 + j * 8):
                return finish(o, w, 65)
            j = j + 1
        return reading(o, w, get(w, 144), 1501072, 5, site - 1, 5203)
    if phase == 5203:
        index = get(w, 1500200)
        target = get(w, 1500192)
        j = 0
        while j < index:
            target = target + get(w, 1501008 + j * 8)
            j = j + 1
        delta = getn(w, 1501073, 4)
        if delta & 2147483648 != 0:
            delta = delta + 18446744069414584320
        if byte(w, 1501072) != 232 or get(w, 1501032 + index * 8) + 4 + delta != target:
            return finish(o, w, 65)
        put(w, 1500200, index + 1)
        return resume(s, o, w, 5202)
    return finish(o, w, 65)

def dag_pick(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 5300:
        row = dag_handle(w, dag_arg(w, 0))
        if get(w, 1500064) != 3 or get(w, 1500080) != 0 or row == 0 or dag_arg(w, 2) > 1 or get(w, row + 24) == 0:
            return finish(o, w, 65)
        if get(w, row + 24) == 4:
            if dag_arg(w, 1) > 1 or dag_arg(w, 2) != 0:
                return finish(o, w, 65)
            put(w, 144, get(w, row))
            put(w, 152, choose(dag_arg(w, 1) == 0, get(w, row + 32), get(w, row + 40)))
            put(w, 1500136, 24 + choose(dag_arg(w, 1) == 0, 0, get(w, row + 32)))
            return dag_commit(o, w, 0)
        if dag_pick_name(w, row) == 0:
            return finish(o, w, 65)
        if get(w, row + 24) == 1 and get(w, row + 48) == 3544428844805081416:
            if dag_arg(w, 1) != 0 or dag_arg(w, 2) != 0:
                return finish(o, w, 65)
            put(w, 144, get(w, row))
            put(w, 152, get(w, row + 16))
            put(w, 1500136, get(w, row + 8))
            return dag_commit(o, w, 0)
        if get(w, row + 24) == 3 and dag_arg(w, 2) == 1:
            put(w, 1500216, row)
            return reading(o, w, get(w, row), 1501000, 64, get(w, row + 16) - 64, 5310)
        if get(w, row + 24) == 3:
            row = dag_handle(w, get(w, row + 40))
        if row == 0 or (get(w, row + 24) == 1 and dag_arg(w, 2) != 0):
            return finish(o, w, 65)
        put(w, 1500216, row)
        put(w, 1500224, 0)
        put(w, 1500232, 0)
        return reading(o, w, get(w, row), 1501104, 24, get(w, row + 8), 5301)
    if phase == 5301:
        row = get(w, 1500216)
        if get(w, row + 24) == 2:
            if get(w, 1501104) != 3544416767357045064 or get(w, 1501112) != 2 * get(w, get(w, row + 32)) or get(w, 1501120) != 0:
                return finish(o, w, 65)
            put(w, 1500224, 24)
        else:
            if get(w, 1501112) != get(w, get(w, row + 32)):
                return finish(o, w, 65)
            put(w, 1500224, 16)
        put(w, 1500240, get(w, 1501112))
        return resume(s, o, w, 5302)
    if phase == 5302:
        row = get(w, 1500216)
        if get(w, 1500232) == get(w, 1500240):
            return finish(o, w, 65)
        if get(w, 1500224) > get(w, row + 16) or get(w, row + 16) - get(w, 1500224) < 24:
            return finish(o, w, 65)
        return reading(o, w, get(w, row), 1501104, 24, get(w, row + 8) + get(w, 1500224), 5303)
    if phase == 5303:
        row = get(w, 1500216)
        header = choose(get(w, row + 24) == 2, 24, 16)
        size = get(w, 1501104 + header - 8)
        name = get(w, 1501104)
        if name == 0 or name > 127 or size == 0 or size > 1048576 or header + name + size > get(w, row + 16) - get(w, 1500224):
            return finish(o, w, 65)
        if header == 24 and get(w, 1501112) != 256:
            return finish(o, w, 65)
        put(w, 1500248, header)
        put(w, 1500256, size)
        put(w, 1500264, name)
        return reading(o, w, get(w, row), 1501200, name, get(w, row + 8) + get(w, 1500224) + header, 5304)
    if phase == 5304:
        row = get(w, 1500216)
        if get(w, 1500264) == get(w, 1500208) and same(w, 1501200, 1501400, get(w, 1500264)) == 1:
            put(w, 144, get(w, row))
            put(w, 152, get(w, 1500256))
            put(w, 1500136, get(w, row + 8) + get(w, 1500224) + get(w, 1500248) + get(w, 1500264))
            return dag_commit(o, w, 0)
        put(w, 1500224, get(w, 1500224) + get(w, 1500248) + get(w, 1500264) + get(w, 1500256))
        put(w, 1500232, get(w, 1500232) + 1)
        return resume(s, o, w, 5302)
    if phase == 5310:
        row = get(w, 1500216)
        index = dag_arg(w, 1)
        if index > 2 or get(w, 1501056) != 3550891808395446600 or get(w, 1501000) != get(w, row + 48):
            return finish(o, w, 65)
        offset = get(w, 1501000) - get(w, 1501008) - get(w, 1501016) - get(w, 1501024)
        j = 0
        while j < index:
            offset = offset + get(w, 1501008 + j * 8)
            j = j + 1
        put(w, 144, get(w, row))
        put(w, 152, get(w, 1501008 + index * 8))
        put(w, 1500136, offset)
        return dag_commit(o, w, 0)
    return finish(o, w, 65)

def dag_pick_name(w:mutbuf, row:u64) -> u64:
    at = get(w, row + 32)
    ordinal = dag_arg(w, 1)
    if at < 2097152 or at >= 3145728 or ordinal >= get(w, at):
        return 0
    at = at + 8
    i = 0
    while i < ordinal:
        at = at + 16 + get(w, at) + get(w, at + 8)
        i = i + 1
    size = get(w, at)
    copyw(w, 1501400, at + 16, size)
    if get(w, row + 24) == 2 and dag_arg(w, 2) == 1:
        put(w, 1501400 + size, 1852400174)
        size = size + 4
    put(w, 1500208, size)
    return 1

def dag_check(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 5500:
        op = get(w, 1500048)
        row = dag_handle(w, dag_arg(w, 0))
        count = choose(op == 7 or op == 8, 2, 1)
        if row == 0 or get(w, 1500064) != count:
            return finish(o, w, 65)
        put(w, 1500272, row)
        if op == 8:
            second = dag_handle(w, dag_arg(w, 1))
            if second == 0 or get(w, second + 16) != get(w, row + 16) or get(w, 1500080) != 0:
                return finish(o, w, 65)
            put(w, 1500280, second)
            put(w, 1500288, 0)
            return resume(s, o, w, 5510)
        if op == 9 and get(w, 1500080) != 32:
            return finish(o, w, 65)
        if op == 13 and get(w, 1500080) != 0:
            return finish(o, w, 65)
        if op == 7 and dag_arg(w, 1) == 0:
            return resume(s, o, w, 5520)
        return hash_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5501)
    if phase == 5501:
        op = get(w, 1500048)
        if op == 13:
            return seal_buffer(o, w, 4096, 32, 5004)
        if op == 9:
            if same(w, 4096, get(w, 1500072), 32) == 0:
                return finish(o, w, 65)
            return dag_commit(o, w, 0)
        row = dag_handle(w, dag_arg(w, 1))
        if row == 0 or get(w, row + 16) != 32:
            return finish(o, w, 65)
        return reading(o, w, get(w, row), 1501600, 32, get(w, row + 8), 5502)
    if phase == 5502:
        if same(w, 4096, 1501600, 32) == 0:
            return finish(o, w, 65)
        return resume(s, o, w, 5520)
    if phase == 5510:
        row = get(w, 1500272)
        if get(w, 1500288) == get(w, row + 16):
            return dag_commit(o, w, 0)
        put(w, 1500296, minimum(65536, get(w, row + 16) - get(w, 1500288)))
        return reading(o, w, get(w, row), 700000, get(w, 1500296), get(w, row + 8) + get(w, 1500288), 5511)
    if phase == 5511:
        row = get(w, 1500280)
        return reading(o, w, get(w, row), 800000, get(w, 1500296), get(w, row + 8) + get(w, 1500288), 5512)
    if phase == 5512:
        if same(w, 700000, 800000, get(w, 1500296)) == 0:
            return finish(o, w, 65)
        put(w, 1500288, get(w, 1500288) + get(w, 1500296))
        return resume(s, o, w, 5510)
    if phase == 5520:
        row = get(w, 1500272)
        if dag_publication(w) == 0:
            return finish(o, w, 65)
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5521)
    if phase == 5521:
        if get(w, 152) < 4:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 49152, 4, 0, 5522)
    if phase == 5522:
        row = 1600000 + get(w, 1599904) * 160
        put(w, row, get(w, 144))
        put(w, row + 8, get(w, 152))
        return publish(o, w, get(w, 144), get(w, 152), row + 32, get(w, row + 16), choose(getn(w, 49152, 4) == 1179403647, 320, 256), 5523)
    if phase == 5523:
        put(w, 1599904, get(w, 1599904) + 1)
        return dag_commit(o, w, 0)
    return finish(o, w, 65)

def dag_publication(w:mutbuf) -> u64:
    name = get(w, 1500072)
    size = get(w, 1500080)
    if size == 0 or size > 127 or get(w, 1599904) >= 512 or find_product(w, name, size) != 0:
        return 0
    if size == 1 and byte(w, name) == 46:
        return 0
    if size == 2 and byte(w, name) == 46 and byte(w, name + 1) == 46:
        return 0
    i = 0
    while i < size:
        if plain(byte(w, name + i)) == 0:
            return 0
        i = i + 1
    i = 0
    while i < get(w, 1599904):
        row = 1600000 + i * 160
        if get(w, row + 16) == size and same(w, row + 32, name, size) == 1:
            return 0
        i = i + 1
    row = 1600000 + get(w, 1599904) * 160
    put(w, row + 16, size)
    copyw(w, row + 32, name, size)
    return 1

def dag_codec(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase >= 5660:
        return dag_codec_output(s, o, w, phase, r)
    if phase == 5600:
        if dag_codec_arguments(w) == 0:
            return finish(o, w, 65)
        row = dag_handle(w, dag_arg(w, 2))
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5601)
    if phase == 5601:
        put(w, 1560016, get(w, 144))
        row = dag_handle(w, dag_arg(w, 3))
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 48), 5602)
    if phase == 5602:
        put(w, 1560024, get(w, 144))
        if get(w, 1560000) == 0:
            return resume(s, o, w, 5620)
        return call(o, w, 5603, 319, 600032, 2, 0, 0, 0, 0, 3)
    if phase == 5603:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1560128, r)
        row = get(w, 1560008)
        put(w, 6144, get(w, row + 16))
        return writing(o, w, r, 6144, 8, 5604)
    if phase == 5604:
        return call(o, w, 5605, 8, get(w, 1560128), 8, 0, 0, 0, 0, 0)
    if phase == 5605:
        if r != 8:
            return finish(o, w, 74)
        row = get(w, 1560008)
        return copying(o, w, get(w, row), get(w, 1560128), get(w, row + 8), get(w, row + 16), 5606)
    if phase == 5606:
        put(w, 1560136, 8 + get(w, get(w, 1560008) + 16))
        return call(o, w, 5607, 319, 600032, 2, 0, 0, 0, 0, 3)
    if phase == 5607:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1560144, r)
        put(w, 1560152, 16)
        put(w, 6144, 3544421156595517768)
        put(w, 6152, get(w, get(w, 1560008) + 16))
        return writing(o, w, r, 6144, 16, 5620)
    if phase == 5620:
        row = get(w, 1560008)
        if get(w, 1560056) == get(w, row + 16):
            return resume(s, o, w, 5680)
        size = get(w, row + 16) - get(w, 1560056)
        put(w, 1560064, choose(get(w, 1560000) == 0, size, minimum(524288, size)))
        if get(w, 1560072) >= 3 and get(w, 1560080) == get(w, 1560064):
            return resume(s, o, w, 5630)
        if get(w, 1560072) >= 3:
            return call(o, w, 5621, 3, get(w, 1560072), 0, 0, 0, 0, 0, 0)
        return resume(s, o, w, 5621)
    if phase == 5621:
        put(w, 1560072, 0)
        put(w, 6144, 3544420057050335560)
        put(w, 6152, 2)
        put(w, 6160, get(w, 1560064))
        first = get(w, 1560032)
        second = get(w, 1560040)
        put(w, 6168, get(w, first + 16))
        put(w, 6176, get(w, second + 16))
        view(w, 0, get(w, first), get(w, first + 8), get(w, first + 16))
        view(w, 1, get(w, second), get(w, second + 8), get(w, second + 16))
        return frame(o, w, 6144, 40, 330000, 2, 5622)
    if phase == 5622:
        return launch(o, w, get(w, 1560024), get(w, 144), 3, 0, 5623)
    if phase == 5623:
        if get(w, 152) < 176:
            return finish(o, w, 65)
        put(w, 1560072, get(w, 144))
        put(w, 1560080, get(w, 1560064))
        return call(o, w, 5630, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 5630:
        row = get(w, 1560008)
        return extract_view(o, w, get(w, row), get(w, row + 8) + get(w, 1560056), get(w, 1560064), 5631)
    if phase == 5631:
        return launch(o, w, get(w, 1560016), get(w, 144), 0, 0, 5632)
    if phase == 5632:
        if get(w, 152) == 0 or get(w, 152) > get(w, 1560048):
            return finish(o, w, 65)
        put(w, 1560088, get(w, 144))
        put(w, 1560096, get(w, 152))
        return extract_view(o, w, get(w, 144), 0, get(w, 152), 5633)
    if phase == 5633:
        return launch(o, w, get(w, 1560072), get(w, 144), 0, 0, 5634)
    if phase == 5634:
        if get(w, 152) != get(w, 1560064):
            return finish(o, w, 65)
        put(w, 1560104, get(w, 144))
        put(w, 1560112, 0)
        return resume(s, o, w, 5640)
    if phase == 5640:
        if get(w, 1560112) == get(w, 1560064):
            return call(o, w, 5660, 3, get(w, 1560104), 0, 0, 0, 0, 0, 0)
        size = minimum(65536, get(w, 1560064) - get(w, 1560112))
        put(w, 1560120, size)
        row = get(w, 1560008)
        return reading(o, w, get(w, row), 700000, size, get(w, row + 8) + get(w, 1560056) + get(w, 1560112), 5641)
    if phase == 5641:
        return reading(o, w, get(w, 1560104), 800000, get(w, 1560120), get(w, 1560112), 5642)
    if phase == 5642:
        if same(w, 700000, 800000, get(w, 1560120)) == 0:
            return finish(o, w, 65)
        put(w, 1560112, get(w, 1560112) + get(w, 1560120))
        return resume(s, o, w, 5640)
    return finish(o, w, 65)

def dag_codec_arguments(w:mutbuf) -> u64:
    if get(w, 1500064) != 7 or get(w, 1500080) != 0 or dag_arg(w, 0) > 1:
        return 0
    raw = dag_handle(w, dag_arg(w, 1))
    encoder = dag_handle(w, dag_arg(w, 2))
    builder = dag_handle(w, dag_arg(w, 3))
    source = dag_handle(w, dag_arg(w, 4))
    image = dag_handle(w, dag_arg(w, 5))
    if raw == 0 or encoder == 0 or builder == 0 or source == 0 or image == 0:
        return 0
    if get(w, raw + 16) == 0 or get(w, raw + 16) > 8388608 or get(w, encoder + 16) < 176 or get(w, builder + 24) != 3:
        return 0
    if get(w, source + 16) == 0 or get(w, source + 16) > 1048576 or get(w, image + 16) == 0 or get(w, image + 16) > 1048576:
        return 0
    if dag_arg(w, 6) == 0 or dag_arg(w, 6) > 1048576:
        return 0
    if dag_arg(w, 0) == 1 and (get(w, raw + 16) < 176 or dag_arg(w, 6) != 1048576):
        return 0
    put(w, 1560000, dag_arg(w, 0))
    put(w, 1560008, raw)
    put(w, 1560032, source)
    put(w, 1560040, image)
    put(w, 1560048, dag_arg(w, 6))
    put(w, 1560056, 0)
    put(w, 1560072, 0)
    put(w, 1560080, 0)
    put(w, 1560128, 0)
    put(w, 1560144, 0)
    return 1

def dag_codec_output(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 5660:
        if get(w, 1560000) == 0:
            put(w, 1560160, get(w, 1560088))
            put(w, 1560168, get(w, 1560096))
            put(w, 1560176, 0)
            return resume(s, o, w, 5690)
        size = get(w, 1560096)
        if get(w, 1560136) > 67108856 - size or get(w, 1560152) > 67108848 - size:
            return finish(o, w, 65)
        put(w, 6144, size)
        return writing_at(o, w, get(w, 1560128), 6144, 8, get(w, 1560136), 5661)
    if phase == 5661:
        return call(o, w, 5662, 8, get(w, 1560128), get(w, 1560136) + 8, 0, 0, 0, 0, 0)
    if phase == 5662:
        if r != get(w, 1560136) + 8:
            return finish(o, w, 74)
        return copying(o, w, get(w, 1560088), get(w, 1560128), 0, get(w, 1560096), 5663)
    if phase == 5663:
        put(w, 1560136, get(w, 1560136) + 8 + get(w, 1560096))
        put(w, 6144, get(w, 1560096))
        put(w, 6152, get(w, 1560064))
        return writing_at(o, w, get(w, 1560144), 6144, 16, get(w, 1560152), 5664)
    if phase == 5664:
        return call(o, w, 5665, 8, get(w, 1560144), get(w, 1560152) + 16, 0, 0, 0, 0, 0)
    if phase == 5665:
        if r != get(w, 1560152) + 16:
            return finish(o, w, 74)
        return copying(o, w, get(w, 1560088), get(w, 1560144), 0, get(w, 1560096), 5666)
    if phase == 5666:
        put(w, 1560152, get(w, 1560152) + 16 + get(w, 1560096))
        put(w, 1560056, get(w, 1560056) + get(w, 1560064))
        return call(o, w, 5620, 3, get(w, 1560088), 0, 0, 0, 0, 0, 0)
    if phase == 5680:
        put(w, 6144, 3544405763432728904)
        put(w, 6152, get(w, 1560136))
        put(w, 6160, get(w, 1560152))
        view(w, 0, get(w, 1560128), 0, get(w, 1560136))
        view(w, 1, get(w, 1560144), 0, get(w, 1560152))
        return frame(o, w, 6144, 24, 330000, 2, 5681)
    if phase == 5681:
        put(w, 1560160, get(w, 144))
        put(w, 1560168, get(w, 152))
        put(w, 1500144, 4)
        put(w, 1500152, get(w, 1560136))
        put(w, 1500160, get(w, 1560152))
        return call(o, w, 5682, 3, get(w, 1560128), 0, 0, 0, 0, 0, 0)
    if phase == 5682:
        put(w, 1560176, 0)
        return call(o, w, 5690, 3, get(w, 1560144), 0, 0, 0, 0, 0, 0)
    if phase == 5690:
        index = get(w, 1560176)
        if index == 3:
            put(w, 144, get(w, 1560160))
            put(w, 152, get(w, 1560168))
            return dag_commit(o, w, 1)
        put(w, 1560176, index + 1)
        fd = get(w, 1560016)
        if index == 1:
            fd = get(w, 1560024)
        if index == 2:
            fd = get(w, 1560072)
        return call(o, w, 5690, 3, fd, 0, 0, 0, 0, 0, 0)
    return finish(o, w, 65)

def worker_path(w:mutbuf) -> u64:
    name = get(w, 1500072)
    size = get(w, 1500080)
    if size == 0 or size > 127 or get(w, 1599904) >= 768 or byte(w, name) == 47 or byte(w, name + size - 1) == 47:
        return 0
    i = 0
    start = 0
    while i <= size:
        if i == size or byte(w, name + i) == 47:
            count = i - start
            if count == 0 or (count == 1 and byte(w, name + start) == 46) or (count == 2 and byte(w, name + start) == 46 and byte(w, name + start + 1) == 46):
                return 0
            start = i + 1
        elif plain(byte(w, name + i)) == 0:
            return 0
        i = i + 1
    if size >= 6 and getn(w, name, 6) == 52112758109299:
        return 0
    i = 0
    while i < get(w, 1599904):
        row = 1600000 + i * 160
        if get(w, row + 16) == size and same(w, row + 32, name, size) == 1:
            return 0
        i = i + 1
    copyw(w, 1820400, name, size)
    store(w, 1820400 + size, 0)
    put(w, 1820032, 0)
    put(w, 1820040, size)
    return 1

def worker_publish(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase != 5905 and failed(r):
        return finish(o, w, 74)
    if phase == 5900:
        row = dag_handle(w, dag_arg(w, 0))
        mode = dag_arg(w, 1)
        if get(w, 1500064) != 3 or row == 0 or (mode != 256 and mode != 320) or worker_path(w) == 0:
            return finish(o, w, 65)
        put(w, 1820000, mode)
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5901)
    if phase == 5901:
        put(w, 1820016, get(w, 144))
        put(w, 1820024, get(w, 152))
        expected = dag_arg(w, 2)
        if expected != 0:
            row = dag_handle(w, expected)
            if row == 0 or get(w, row + 16) != 32:
                return finish(o, w, 65)
            return reading(o, w, get(w, row), 1820200, 32, get(w, row + 8), 5920)
        return call(o, w, 5902, 72, uint(s, 96), 0, 3, 0, 0, 0, 0)
    if phase == 5920:
        return hash_view(o, w, get(w, 1820016), 0, get(w, 1820024), 5921)
    if phase == 5921:
        if same(w, 1820200, 4096, 32) == 0:
            return finish(o, w, 65)
        return call(o, w, 5902, 72, uint(s, 96), 0, 3, 0, 0, 0, 0)
    if phase == 5902:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1820008, r)
        return resume(s, o, w, 5903)
    if phase == 5903:
        at = get(w, 1820032)
        end = at
        while end < get(w, 1820040) and byte(w, 1820400 + end) != 47:
            end = end + 1
        count = end - at
        copyw(w, 1820600, 1820400 + at, count)
        store(w, 1820600 + count, 0)
        put(w, 1820048, end + 1)
        if end == get(w, 1820040):
            return call(o, w, 5910, 257, get(w, 1820008), 600016, 4259842, 384, 0, 0, 12)
        return call(o, w, 5905, 258, get(w, 1820008), 1820600, 448, 0, 0, 0, 12)
    if phase == 5905:
        if r != 0 and r != 18446744073709551599:
            return finish(o, w, 74)
        return call(o, w, 5906, 257, get(w, 1820008), 1820600, 720896, 0, 0, 0, 12)
    if phase == 5906:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1820056, r)
        return call(o, w, 5907, 5, r, 1200, 0, 0, 0, 0, 12)
    if phase == 5907:
        if getn(w, 1224, 4) & 61440 != 16384 or getn(w, 1224, 4) & 63 != 0 or getn(w, 1228, 4) != get(w, 24):
            return finish(o, w, 65)
        return call(o, w, 5908, 74, get(w, 1820008), 0, 0, 0, 0, 0, 0)
    if phase == 5908:
        return call(o, w, 5909, 3, get(w, 1820008), 0, 0, 0, 0, 0, 0)
    if phase == 5909:
        put(w, 1820008, get(w, 1820056))
        put(w, 1820032, get(w, 1820048))
        return resume(s, o, w, 5903)
    if phase == 5910:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1820064, r)
        return copying(o, w, get(w, 1820016), r, 0, get(w, 1820024), 5911)
    if phase == 5911:
        return call(o, w, 5912, 91, get(w, 1820064), get(w, 1820000), 0, 0, 0, 0, 0)
    if phase == 5912:
        return call(o, w, 5913, 74, get(w, 1820064), 0, 0, 0, 0, 0, 0)
    if phase == 5913:
        return call(o, w, 5914, 265, get(w, 1820064), 600000, get(w, 1820008), 1820600, 4096, 0, 204)
    if phase == 5914:
        return call(o, w, 5915, 74, get(w, 1820008), 0, 0, 0, 0, 0, 0)
    if phase == 5915:
        return call(o, w, 5916, 3, get(w, 1820064), 0, 0, 0, 0, 0, 0)
    if phase == 5916:
        return call(o, w, 5917, 3, get(w, 1820008), 0, 0, 0, 0, 0, 0)
    if phase == 5917:
        row = 1600000 + get(w, 1599904) * 160
        put(w, row, get(w, 1820016))
        put(w, row + 8, get(w, 1820024))
        put(w, row + 16, get(w, 1500080))
        copyw(w, row + 32, get(w, 1500072), get(w, 1500080))
        put(w, 1599904, get(w, 1599904) + 1)
        return dag_commit(o, w, 0)
    return finish(o, w, 65)

def worker_retain(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 74)
    if phase == 5890:
        row = dag_handle(w, dag_arg(w, 0))
        if get(w, 1500064) != 1 or row == 0 or worker_path(w) == 0:
            return finish(o, w, 65)
        return extract_view(o, w, get(w, row), get(w, row + 8), get(w, row + 16), 5891)
    if phase == 5891:
        row = 1600000 + get(w, 1599904) * 160
        put(w, row, get(w, 144))
        put(w, row + 8, get(w, 152))
        put(w, row + 16, get(w, 1500080))
        copyw(w, row + 32, get(w, 1500072), get(w, 1500080))
        put(w, 1599904, get(w, 1599904) + 1)
        return dag_commit(o, w, 0)
    return finish(o, w, 65)

def worker_drop(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 74)
    if phase == 5870:
        if get(w, 1500064) == 0 or get(w, 1500064) > 128 or get(w, 1500080) != 0:
            return finish(o, w, 65)
        put(w, 1820100, 0)
    if phase != 5870 and phase != 5871:
        return finish(o, w, 65)
    while get(w, 1820100) < get(w, 1500064):
        row = dag_handle(w, dag_arg(w, get(w, 1820100)))
        if row == 0:
            return finish(o, w, 65)
        fd = get(w, row)
        own = get(w, row + 56)
        put(w, row, 0)
        put(w, row + 56, 0)
        put(w, 1820100, get(w, 1820100) + 1)
        if own == 1:
            other = worker_alias(w, fd)
            if other != 0:
                put(w, other + 56, 1)
            else:
                return call(o, w, 5871, 3, fd, 0, 0, 0, 0, 0, 0)
    return dag_commit(o, w, 0)

def worker_alias(w:mutbuf, fd:u64) -> u64:
    i = 1
    while i <= 2048:
        row = 1048576 + i * 64
        if get(w, row) == fd:
            return row
        i = i + 1
    return 0

def plain(c:u64) -> u64:
    if (c >= 65 and c <= 90) or (c >= 97 and c <= 122) or (c >= 48 and c <= 57):
        return 1
    if c == 45 or c == 46 or c == 95:
        return 1
    return 0

def launch(o:mutbuf, w:mutbuf, image:u64, source:u64, operation:u64, pass_source:u64, resume:u64) -> u32:
    put(w, 512, resume)
    put(w, 520, image)
    put(w, 528, source)
    put(w, 536, operation)
    put(w, 544, pass_source)
    put(w, 552, 0)
    return call(o, w, 100, 8, source, 0, 0, 0, 0, 0, 0)

def writing(o:mutbuf, w:mutbuf, fd:u64, buffer:u64, count:u64, resume:u64) -> u32:
    return writing_at(o, w, fd, buffer, count, 0, resume)

def writing_at(o:mutbuf, w:mutbuf, fd:u64, buffer:u64, count:u64, offset:u64, resume:u64) -> u32:
    if count == 0:
        put(w, 0, resume)
        put(w, 8, 0)
        return 4
    put(w, 768, fd)
    put(w, 776, buffer)
    put(w, 784, count)
    put(w, 792, offset)
    put(w, 800, resume)
    return call(o, w, 200, 18, fd, buffer, count, offset, 0, 0, 12)

def reading(o:mutbuf, w:mutbuf, fd:u64, buffer:u64, count:u64, offset:u64, resume:u64) -> u32:
    put(w, 808, fd)
    put(w, 816, buffer)
    put(w, 824, count)
    put(w, 832, offset)
    put(w, 840, resume)
    return call(o, w, 201, 17, fd, buffer, count, offset, 0, 0, 12)

def copying(o:mutbuf, w:mutbuf, source:u64, target:u64, offset:u64, count:u64, resume:u64) -> u32:
    if count == 0:
        put(w, 0, resume)
        put(w, 8, 0)
        return 4
    put(w, 848, source)
    put(w, 856, target)
    put(w, 864, count)
    put(w, 872, offset)
    put(w, 880, resume)
    return call(o, w, 202, 40, target, source, 872, count, 0, 0, 48)

def seal_buffer(o:mutbuf, w:mutbuf, buffer:u64, count:u64, resume:u64) -> u32:
    if buffer > 4194304 or count > 4194304 - buffer:
        return finish(o, w, 65)
    put(w, 896, resume)
    put(w, 904, buffer)
    put(w, 912, count)
    return call(o, w, 210, 319, 600032, 2, 0, 0, 0, 0, 3)

def hash_view(o:mutbuf, w:mutbuf, file:u64, offset:u64, size:u64, resume:u64) -> u32:
    put(w, 40, file)
    put(w, 48, size)
    put(w, 56, 0)
    put(w, 64, offset)
    put(w, 72, resume)
    return sha(o, w, 250, 0, 1)

def publish(o:mutbuf, w:mutbuf, file:u64, size:u64, name:u64, count:u64, mode:u64, after:u64) -> u32:
    if size == 0 or size > 67108864 or count == 0 or count > 127:
        return finish(o, w, 65)
    put(w, 920, file)
    put(w, 936, size)
    put(w, 944, name)
    put(w, 952, count)
    put(w, 960, mode)
    put(w, 968, after)
    return hash_view(o, w, file, 0, size, 300)

def hex_digest(w:mutbuf, at:u64) -> u64:
    i = 0
    while i < 32:
        ch = byte(w, 4096 + i)
        store(w, at + i * 2, hex_digit(ch >> 4))
        store(w, at + i * 2 + 1, hex_digit(ch & 15))
        i = i + 1
    return 0

def hex_digit(value:u64) -> u64:
    return choose(value < 10, value + 48, value + 87)

def capture_begin(s:readbuf, w:mutbuf, tag:u64, count:u64) -> u64:
    put(w, 393216, 3616478742009956680)
    put(w, 393224, uint(s, 24))
    put(w, 393232, tag)
    put(w, 393240, count)
    return 393248

def capture_row(s:readbuf, w:mutbuf, at:u64, path:u64, pn:u64, alias:u64, an:u64) -> u64:
    if pn == 0 or pn > 4095 or an == 0 or an > 127 or at > 458752 or 56 + pn + an > 458752 - at:
        return 0
    pin = pin_for(s, w, path, pn)
    if pin == 0:
        return 0
    put(w, at, pn)
    put(w, at + 8, an)
    put(w, at + 16, 0)
    copy(s, w, at + 24, pin, 32)
    copyw(w, at + 56, path, pn)
    copyw(w, at + 56 + pn, alias, an)
    return at + 56 + pn + an

def pin_for(s:readbuf, w:mutbuf, path:u64, n:u64) -> u64:
    i = 0
    while i < get(w, 80):
        row = get(w, 131200 + i * 16)
        if get(w, 131208 + i * 16) == n and same_input(s, w, row + 40, path, n) == 1:
            return row + 8
        i = i + 1
    return 0

def capture_relative(s:readbuf, w:mutbuf, at:u64, source:u64, count:u64, alias:u64, size:u64) -> u64:
    if count == 0 or count > 255:
        return 0
    copyw(w, 530000, 600224, 23)
    copyw(w, 530000 + 23, source, count)
    return capture_row(s, w, at, 530000, 23 + count, alias, size)

def capture_kit(s:readbuf, w:mutbuf, policy:u64, pn:u64, packer:u64, kn:u64, tag:u64) -> u64:
    at = capture_begin(s, w, tag, 3)
    at = capture_relative(s, w, at, policy, pn, 600256, 25)
    if at == 0:
        return 0
    at = capture_relative(s, w, at, 600336, 14, 600336, 14)
    if at == 0:
        return 0
    at = capture_relative(s, w, at, packer, kn, 600296, 25)
    if at == 0:
        return 0
    return at - 393216

def capture_one(s:readbuf, w:mutbuf, path:u64, pn:u64, alias:u64, an:u64, tag:u64) -> u64:
    at = capture_begin(s, w, tag, 1)
    at = capture_row(s, w, at, path, pn, alias, an)
    return choose(at == 0, 0, at - 393216)

def capture_request(o:mutbuf, w:mutbuf, size:u64, after:u64) -> u32:
    if size == 0:
        return finish(o, w, 65)
    put(w, 1064, after)
    return seal_buffer(o, w, 393216, size, 1090)

def audit_start(s:readbuf, o:mutbuf, w:mutbuf, after:u64) -> u32:
    put(w, 1550000, 0)
    put(w, 1550016, after)
    return resume(s, o, w, 4500)

def member_footer(w:mutbuf) -> u64:
    count = get(w, 1000)
    size = get(w, 546816)
    if size < 176 or size > get(w, 1016):
        return 0
    total = size
    i = 0
    while i < count:
        n = get(w, 546824 + i * 8)
        if n == 0 or n > 1048576:
            return 0
        total = total + n
        i = i + 1
    if count == 1:
        if get(w, 546832) != 3544414555398555976 or total + 24 != get(w, 1016):
            return 0
    else:
        if get(w, 546824 + count * 8) != count or get(w, 546832 + count * 8) != 3554266179583428936 or total + (count + 3) * 8 != get(w, 1016):
            return 0
    put(w, 160, size)
    return 1

def elf_header(w:mutbuf, size:u64) -> u64:
    if get(w, 49152) != 282584257676671 or get(w, 49160) != 0:
        return 0
    if get(w, 49168) != 4299030530 or get(w, 49184) != 64 or get(w, 49192) != 0:
        return 0
    if get(w, 49200) != 15762873573703680 or get(w, 49208) != choose(is_artifact(w), 3, 2):
        return 0
    if get(w, 49216) != 21474836481 or get(w, 49224) != 0 or get(w, 49232) != 4194304 or get(w, 49240) != 4194304:
        return 0
    if get(w, 49248) != size or get(w, 49256) != size or get(w, 49264) != 4096:
        return 0
    if get(w, 49272) != 27455186257 or get(w, 49320) != 16:
        return 0
    i = 128
    while i < 168:
        if get(w, 49152 + i) != 0:
            return 0
        i = i + 8
    if is_artifact(w):
        return artifact_header(w, size)
    return choose(get(w, 49176) == 4194480, 1, 0)

def is_artifact(w:mutbuf) -> bool:
    return get(w, 184) == 12 and same(w, get(w, 176), 600728, 12) == 1

def artifact_header(w:mutbuf, size:u64) -> u64:
    if size < 352 or get(w, 49176) != 4194656:
        return 0
    if get(w, 49328) != 17179869188 or get(w, 49336) != 232 or get(w, 49344) != 4194536 or get(w, 49352) != 4194536:
        return 0
    if get(w, 49360) != 120 or get(w, 49368) != 120 or get(w, 49376) != 4:
        return 0
    if get(w, 49384) != 412316860425 or getn(w, 49392, 4) != 1 or get(w, 49396) != 6217584620943264072 or getn(w, 49404, 4) != 0:
        return 0
    if get(w, 49408) != 3552306853973150024 or get(w, 49416) != 1 or get(w, 49424) != 4194656:
        return 0
    if get(w, 49432) <= 4194656 or get(w, 49432) >= 4194304 + size:
        return 0
    if get(w, 49440) != 16 or get(w, 49448) != 128 or get(w, 49456) != 96 or get(w, 49464) != 24:
        return 0
    if get(w, 49472) != 0 or get(w, 49480) != 0 or get(w, 49488) != 63 or get(w, 49496) != 0:
        return 0
    return 1

def extract_code(o:mutbuf, w:mutbuf, source:u64, count:u64, after:u64) -> u32:
    return extract_view(o, w, source, 0, count, after)

def extract_view(o:mutbuf, w:mutbuf, source:u64, offset:u64, count:u64, after:u64) -> u32:
    put(w, 1184, offset)
    put(w, 1072, source)
    put(w, 1080, count)
    put(w, 1088, after)
    return call(o, w, 1400, 319, 600032, 2, 0, 0, 0, 0, 3)

def frame(o:mutbuf, w:mutbuf, header:u64, size:u64, parts:u64, count:u64, after:u64) -> u32:
    if count > 128 or size > 65536:
        return finish(o, w, 65)
    put(w, 3080, after)
    put(w, 3088, parts)
    put(w, 3096, count)
    put(w, 3104, 0)
    put(w, 3112, header)
    put(w, 3120, size)
    put(w, 3128, size)
    put(w, 3136, 0)
    return call(o, w, 1600, 319, 600032, 2, 0, 0, 0, 0, 3)

def framed(o:mutbuf, w:mutbuf, header:u64, size:u64, parts:u64, count:u64, after:u64) -> u32:
    result = frame(o, w, header, size, parts, count, after)
    put(w, 3136, 1)
    return result

def view(w:mutbuf, index:u64, file:u64, offset:u64, size:u64) -> u64:
    put(w, 330000 + index * 24, file)
    put(w, 330008 + index * 24, offset)
    put(w, 330016 + index * 24, size)
    return 0

def find_product(w:mutbuf, name:u64, size:u64) -> u64:
    i = 0
    while i < get(w, 104):
        at = 294912 + i * 32
        if get(w, at + 24) == size and same(w, get(w, at + 16), name, size) == 1:
            return at
        i = i + 1
    return 0

def resume(s:readbuf, o:mutbuf, w:mutbuf, phase:u64) -> u32:
    put(w, 0, phase)
    put(w, 8, 0)
    return 4

def sha(o:mutbuf, w:mutbuf, phase:u64, operation:u64, count:u64) -> u32:
    store(w, 65536, operation)
    put(w, 0, phase)
    put(o, 0, count)
    return 3

def call(o:mutbuf, w:mutbuf, phase:u64, number:u64, a:u64, b:u64, c:u64, d:u64, e:u64, f:u64, mask:u64) -> u32:
    put(w, 0, phase)
    put(o, 0, number)
    put(o, 8, a)
    put(o, 16, b)
    put(o, 24, c)
    put(o, 32, d)
    put(o, 40, e)
    put(o, 48, f)
    put(o, 56, mask)
    return 1

def finish(o:mutbuf, w:mutbuf, code:u64) -> u32:
    return call(o, w, 99999, 60, code, 0, 0, 0, 0, 0, 0)

def minimum(a:u64, b:u64) -> u64:
    return choose(a < b, a, b)

def decimal(w:mutbuf, at:u64, value:u64) -> u64:
    factor = 1
    while divide(value, factor) >= 10:
        factor = factor * 10
    while factor != 0:
        digit = divide(value, factor)
        store(w, at, 48 + digit)
        value = value - digit * factor
        factor = divide(factor, 10)
        at = at + 1
    return at

def divide(value:u64, divisor:u64) -> u64:
    bit = 1
    quotient = 0
    while divisor <= (value >> 1):
        divisor = divisor << 1
        bit = bit << 1
    while bit != 0:
        if value >= divisor:
            value = value - divisor
            quotient = quotient | bit
        divisor = divisor >> 1
        bit = bit >> 1
    return quotient

def same(w:mutbuf, a:u64, b:u64, count:u64) -> u64:
    i = 0
    while i < count:
        if byte(w, a + i) != byte(w, b + i):
            return 0
        i = i + 1
    return 1

def same_input(s:readbuf, w:mutbuf, a:u64, b:u64, count:u64) -> u64:
    i = 0
    while i < count:
        if byte(s, a + i) != byte(w, b + i):
            return 0
        i = i + 1
    return 1

def copy(s:readbuf, w:mutbuf, target:u64, source:u64, count:u64) -> u64:
    i = 0
    while i < count:
        store(w, target + i, byte(s, source + i))
        i = i + 1
    return 0

def copyw(w:mutbuf, target:u64, source:u64, count:u64) -> u64:
    i = 0
    while i < count:
        store(w, target + i, byte(w, source + i))
        i = i + 1
    return 0

def failed(value:u64) -> bool:
    return value >> 63 != 0

def uint(s:readbuf, at:u64) -> u64:
    i = 0
    value = 0
    while i < 8:
        value = value | (byte(s, at + i) << (i * 8))
        i = i + 1
    return value

def get(w:mutbuf, at:u64) -> u64:
    return getn(w, at, 8)

def getn(w:mutbuf, at:u64, count:u64) -> u64:
    i = 0
    value = 0
    while i < count:
        value = value | (byte(w, at + i) << (i * 8))
        i = i + 1
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(w, at + i, (value >> (i * 8)) & 255)
        i = i + 1
    return 0

def worker_admission(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 65)
    if phase == 60:
        if getn(w, 1224, 4) & 61440 != 32768 or get(w, 1248) == 0 or get(w, 1248) > 536870912:
            return finish(o, w, 65)
        put(w, 1800024, get(w, 1248))
        return call(o, w, 61, 72, get(w, 1800016), 1034, 0, 0, 0, 0, 0)
    if phase == 61:
        if r & 15 != 15:
            return finish(o, w, 65)
        return hash_view(o, w, get(w, 1800016), 0, get(w, 1800024), 62)
    if phase == 62:
        if same_input(s, w, get(w, 1800008) + 32, 4096, 32) == 0:
            return finish(o, w, 65)
        copyw(w, 1800032, 4096, 32)
        hex_digest(w, 1800064)
        store(w, 1800128, 0)
        if get(w, 1800616) == 1:
            return call(o, w, 63, 5, get(w, 1800600), 1200, 0, 0, 0, 0, 12)
        return call(o, w, 20, 8, uint(s, 32), 0, 0, 0, 0, 0, 0)
    if phase == 63:
        if getn(w, 1224, 4) & 61440 != 32768 or get(w, 1248) == 0 or get(w, 1248) > 9223372036854775807:
            return finish(o, w, 65)
        put(w, 1800608, get(w, 1248))
        return call(o, w, 64, 72, get(w, 1800600), 1034, 0, 0, 0, 0, 0)
    if phase == 64:
        if r & 15 != 15:
            return finish(o, w, 65)
        return hash_view(o, w, get(w, 1800600), 0, get(w, 1800608), 65)
    if phase == 65:
        if same_input(s, w, get(w, 1800624), 4096, 32) == 0:
            return finish(o, w, 65)
        return call(o, w, 20, 8, uint(s, 32), 0, 0, 0, 0, 0, 0)
    return finish(o, w, 65)

def worker_business(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if (phase >= 7100 and phase < 7140) or (phase >= 7300 and phase < 7310):
        return worker_configuration(s, o, w, phase, r)
    if phase >= 7140 and phase < 7210:
        return worker_roots(s, o, w, phase, r)
    if phase >= 7040 and phase < 7070:
        return worker_controller(s, o, w, phase, r)
    if failed(r):
        return finish(o, w, 74)
    if phase == 7000:
        return call(o, w, 7001, 257, uint(s, 96), 1808000, 655360, 0, 0, 0, 12)
    if phase == 7001:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1800136, r)
        return call(o, w, 7002, 5, r, 1200, 0, 0, 0, 0, 12)
    if phase == 7002:
        if getn(w, 1224, 4) & 61440 != 32768 or get(w, 1248) != get(w, 1800024):
            return finish(o, w, 65)
        return hash_view(o, w, get(w, 1800136), 0, get(w, 1800024), 7003)
    if phase == 7003:
        if same(w, 1800032, 4096, 32) == 0:
            return finish(o, w, 65)
        return call(o, w, 7004, 3, get(w, 1800136), 0, 0, 0, 0, 0, 0)
    if phase == 7004:
        return call(o, w, 7005, 258, uint(s, 96), 1808024, 448, 0, 0, 0, 12)
    if phase == 7005:
        return call(o, w, 7006, 257, uint(s, 96), 1808024, 720896, 0, 0, 0, 12)
    if phase == 7006:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1800144, r)
        put(w, 1800200, r)
        put(w, 1800240, 1)
        put(w, 1800248, r)
        return call(o, w, 7007, 72, get(w, 1800016), 0, 3, 0, 0, 0, 0)
    if phase == 7007:
        if r < 3:
            return finish(o, w, 74)
        return launch(o, w, get(w, 1530056), r, 32, 3, 7008)
    if phase == 7008:
        return call(o, w, 7009, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 7009:
        return call(o, w, 7010, 72, get(w, 1800016), 0, 3, 0, 0, 0, 0)
    if phase == 7010:
        if r < 3:
            return finish(o, w, 74)
        return launch(o, w, get(w, 1530056), r, 33, 3, 7011)
    if phase == 7011:
        return call(o, w, 7040, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 7012:
        copy(s, w, 6144, get(w, 1800008) + 32, 32)
        return seal_buffer(o, w, 6144, 32, 7013)
    if phase == 7013:
        if worker_register(w, 1808504, 22) == 0:
            return finish(o, w, 65)
        return call(o, w, 7014, 319, 600032, 2, 0, 0, 0, 0, 3)
    if phase == 7014:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1800152, r)
        return call(o, w, 7015, 1, r, get(w, 88), uint(s, 112), 0, 0, 0, 4)
    if phase == 7015:
        if r != uint(s, 112):
            return finish(o, w, 74)
        return call(o, w, 7016, 72, get(w, 1800152), 1033, 15, 0, 0, 0, 0)
    if phase == 7016:
        put(w, 144, get(w, 1800152))
        put(w, 152, uint(s, 112))
        if worker_register(w, 1808536, 27) == 0:
            return finish(o, w, 65)
        put(w, 144, get(w, 1800688))
        put(w, 152, get(w, 1800696))
        return resume(s, o, w, 7017)
    if phase == 7017:
        if worker_register(w, 1808576, 16) == 0:
            return finish(o, w, 65)
        return resume(s, o, w, 7019)
    if phase == 7019:
        put(w, 1800000, 1)
        put(w, 1519984, 8)
        return resume(s, o, w, 5000)
    if phase == 7800:
        if get(w, 1800616) == 1 and get(w, 1800744) == 0:
            return resume(s, o, w, 7300)
        return resume(s, o, w, 7200)
    if phase == 7801:
        return call(o, w, 7802, 74, uint(s, 96), 0, 0, 0, 0, 0, 0)
    if phase == 7802:
        return call(o, w, 7803, 74, uint(s, 88), 0, 0, 0, 0, 0, 0)
    if phase == 7803:
        return resume(s, o, w, 7810)
    return finish(o, w, 65)

def worker_register(w:mutbuf, name:u64, size:u64) -> u64:
    if size == 0 or size > 127 or get(w, 1599904) >= 768 or get(w, 144) < 3 or get(w, 152) > 67108864:
        return 0
    i = 0
    while i < get(w, 1599904):
        row = 1600000 + i * 160
        if get(w, row + 16) == size and same(w, row + 32, name, size) == 1:
            return 0
        i = i + 1
    row = 1600000 + get(w, 1599904) * 160
    put(w, row, get(w, 144))
    put(w, row + 8, get(w, 152))
    put(w, row + 16, size)
    copyw(w, row + 32, name, size)
    put(w, 1599904, get(w, 1599904) + 1)
    return 1

def worker_controller(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 74)
    if phase == 7040:
        return call(o, w, 7041, 257, get(w, 1800144), 1800064, 720896, 0, 0, 0, 12)
    if phase == 7041:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1800456, r)
        return call(o, w, 7042, 258, uint(s, 96), 1808120, 448, 0, 0, 0, 12)
    if phase == 7042:
        return call(o, w, 7043, 257, uint(s, 96), 1808120, 720896, 0, 0, 0, 12)
    if phase == 7043:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1800464, r)
        return call(o, w, 7044, 258, uint(s, 40), 1808144, 448, 0, 0, 0, 12)
    if phase == 7044:
        return call(o, w, 7045, 257, uint(s, 40), 1808144, 720896, 0, 0, 0, 12)
    if phase == 7045:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1800472, r)
        if worker_product(w, 1808088, 22) == 0:
            return finish(o, w, 65)
        put(w, 1800512, get(w, 1800400))
        i = 0
        while i < 832:
            store(w, 1900000 + i, 0)
            i = i + 1
        put(w, 1900000, 3544413532995012936)
        put(w, 1900016, uint(s, 16))
        put(w, 1900024, get(w, 1800456))
        put(w, 1900032, get(w, 1800464))
        put(w, 1900040, get(w, 1800472))
        put(w, 1900048, uint(s, 48))
        put(w, 1900056, get(w, 1530040))
        put(w, 1900064, get(w, 1530056))
        put(w, 1900072, 19)
        put(w, 1800480, 0)
        return resume(s, o, w, 7046)
    if phase == 7046:
        index = get(w, 1800480)
        if index == 22:
            put(w, 1800240, 6)
            i = 0
            while i < 6:
                put(w, 1800248 + i * 8, get(w, 1900024 + i * 8))
                i = i + 1
            return seal_buffer(o, w, 1900000, 832, 7060)
        if index == 0:
            return hash_view(o, w, uint(s, 48), 0, get(w, 3000), 7047)
        row = 1812400 + (index - 1) * 16
        if worker_product(w, get(w, row), get(w, row + 8)) == 0:
            return finish(o, w, 65)
        return hash_view(o, w, get(w, 1800400), 0, get(w, 1800408), 7047)
    if phase == 7047:
        copyw(w, 1900128 + get(w, 1800480) * 32, 4096, 32)
        put(w, 1800480, get(w, 1800480) + 1)
        return resume(s, o, w, 7046)
    if phase == 7060:
        return launch(o, w, get(w, 1800512), get(w, 144), 0, 3, 7061)
    if phase == 7061:
        if get(w, 152) != 96:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 1900000, 96, 0, 7062)
    if phase == 7062:
        if get(w, 1900000) != 3544420130064779592 or get(w, 1900008) != 26 or get(w, 1900016) != 20 or get(w, 1900088) != 0:
            return finish(o, w, 65)
        put(w, 1800800, get(w, 144))
        return resume(s, o, w, 7012)
    return finish(o, w, 65)

def worker_product(w:mutbuf, name:u64, size:u64) -> u64:
    row = find_product(w, name, size)
    if row != 0:
        put(w, 1800400, get(w, row))
        put(w, 1800408, get(w, row + 8))
        return 1
    i = 0
    while i < get(w, 1599904):
        row = 1600000 + i * 160
        if get(w, row + 16) == size and same(w, row + 32, name, size) == 1:
            put(w, 1800400, get(w, row))
            put(w, 1800408, get(w, row + 8))
            return 1
        i = i + 1
    i = 0
    while i < 8:
        row = 604128 + i * 32
        if get(w, row + 24) == size and same(w, get(w, row + 16), name, size) == 1:
            put(w, 1800400, get(w, 320000 + i * 16))
            put(w, 1800408, get(w, 320008 + i * 16))
            return 1
        i = i + 1
    return 0

def worker_configuration(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 74)
    if phase == 7100:
        at = get(w, 1800008)
        copy(s, w, 1840000, at + 64, uint(s, at + 16))
        return seal_buffer(o, w, 1840000, uint(s, at + 16), 7101)
    if phase == 7101:
        put(w, 1800640, get(w, 144))
        put(w, 1800648, get(w, 152))
        if get(w, 1800616) == 0:
            put(w, 1800672, get(w, 144))
            put(w, 1800680, get(w, 152))
            return resume(s, o, w, 7140)
        return capture_request(o, w, capture_kit(s, w, 600448, 26, 1808304, 31, 3544425580512495944), 7102)
    if phase == 7102:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 7103)
    if phase == 7103:
        put(w, 1800664, get(w, 144))
        return call(o, w, 7104, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 7104:
        at = capture_begin(s, w, 3544416835992635720, 3)
        at = capture_relative(s, w, at, 1808264, 24, 1808432, 28)
        if at != 0:
            at = capture_relative(s, w, at, 1808392, 24, 1808392, 24)
        if at != 0:
            at = capture_relative(s, w, at, 601240, 19, 601240, 19)
        return capture_request(o, w, choose(at == 0, 0, at - 393216), 7105)
    if phase == 7105:
        return launch(o, w, get(w, 1800664), get(w, 144), 3, 0, 7106)
    if phase == 7106:
        if get(w, 152) < 224:
            return finish(o, w, 65)
        put(w, 992, get(w, 144))
        put(w, 1016, get(w, 152))
        put(w, 1000, 3)
        put(w, 176, 1808472)
        put(w, 184, 22)
        return reading(o, w, get(w, 144), 546816, 48, get(w, 152) - 48, 7107)
    if phase == 7107:
        if member_footer(w) == 0:
            return finish(o, w, 65)
        return reading(o, w, get(w, 992), 49152, 176, 0, 7108)
    if phase == 7108:
        if elf_header(w, get(w, 160)) == 0:
            return finish(o, w, 65)
        return extract_code(o, w, get(w, 992), get(w, 160), 7109)
    if phase == 7109:
        put(w, 1800656, get(w, 144))
        return call(o, w, 7110, 3, get(w, 992), 0, 0, 0, 0, 0, 0)
    if phase == 7110:
        return call(o, w, 7111, 3, get(w, 1800664), 0, 0, 0, 0, 0, 0)
    if phase == 7111:
        worker_config_frame(s, w, 1)
        return seal_buffer(o, w, 1900000, 192, 7112)
    if phase == 7112:
        return launch(o, w, get(w, 1800656), get(w, 144), 0, 3, 7113)
    if phase == 7113:
        if get(w, 152) < 8 or get(w, 152) > 131304:
            return finish(o, w, 65)
        put(w, 1800672, get(w, 144))
        put(w, 1800680, get(w, 152))
        return resume(s, o, w, 7140)
    if phase == 7300:
        worker_config_frame(s, w, 3)
        return seal_buffer(o, w, 1900000, 192, 7301)
    if phase == 7301:
        return launch(o, w, get(w, 1800656), get(w, 144), 0, 3, 7302)
    if phase == 7302:
        if get(w, 152) != 96:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 1900000, 96, 0, 7303)
    if phase == 7303:
        if get(w, 1900000) != 3544420057385879880 or get(w, 1900008) != 1 or get(w, 1900016) == 0 or get(w, 1900088) != 0:
            return finish(o, w, 65)
        copyw(w, 1800768, 1900056, 32)
        put(w, 1800752, get(w, 144))
        if worker_product(w, 1808216, 11) == 0:
            return finish(o, w, 65)
        return hash_view(o, w, get(w, 1800400), 0, get(w, 1800408), 7304)
    if phase == 7304:
        if same(w, 1800768, 4096, 32) == 0:
            return finish(o, w, 65)
        return call(o, w, 7305, 3, get(w, 1800752), 0, 0, 0, 0, 0, 0)
    if phase == 7305:
        put(w, 1800744, 1)
        return resume(s, o, w, 7800)
    return finish(o, w, 65)

def worker_config_frame(s:readbuf, w:mutbuf, mode:u64) -> u64:
    i = 0
    while i < 192:
        store(w, 1900000 + i, 0)
        i = i + 1
    put(w, 1900000, 3544405763734718792)
    put(w, 1900008, mode)
    put(w, 1900024, uint(s, 16))
    put(w, 1900032, get(w, 1800600))
    put(w, 1900040, get(w, 1800640))
    copy(s, w, 1900128, get(w, 1800624), 32)
    put(w, 1800240, 2)
    put(w, 1800248, get(w, 1800600))
    put(w, 1800256, get(w, 1800640))
    if mode == 2 or mode == 3:
        put(w, 1900048, uint(s, 96))
        put(w, 1900056, uint(s, 48))
        copy(s, w, 1900160, 128, 32)
        put(w, 1800240, 4)
        put(w, 1800264, uint(s, 96))
        put(w, 1800272, uint(s, 48))
    if mode == 3:
        put(w, 1900064, get(w, 1800800))
        put(w, 1800240, 5)
        put(w, 1800280, get(w, 1800800))
    return 0

def worker_roots(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 65)
    if phase == 7140 or phase == 7200:
        put(w, 1830032, choose(phase == 7200, 1, 0))
        return reading(o, w, get(w, 1800672), 1840000, get(w, 1800680), 0, 7141)
    if phase == 7141:
        if worker_roots_shape(w) == 0:
            return finish(o, w, 65)
        put(w, 1830000, get(w, 1840000))
        put(w, 1830008, 0)
        put(w, 1830016, 1840008)
        put(w, 1830024, 8)
        if get(w, 1830032) == 0:
            put(w, 3145728, get(w, 1840000))
        return resume(s, o, w, 7142)
    if phase == 7142:
        i = get(w, 1830008)
        if i == get(w, 1830000):
            if get(w, 1830032) == 1:
                return audit_start(s, o, w, 7801)
            return seal_buffer(o, w, 3145728, get(w, 1830024), 7154)
        at = get(w, 1830016)
        size = get(w, at)
        copyw(w, 1980000, at + 8, size)
        store(w, 1980000 + size, 0)
        put(w, 1830016, at + 8 + size)
        return call(o, w, 7143, 257, 18446744073709551516, 1980000, 2686976, 0, 0, 0, 12)
    if phase == 7143:
        if r < 3:
            return finish(o, w, 65)
        put(w, 1830040, r)
        return call(o, w, 7144, 5, r, 1200, 0, 0, 0, 0, 12)
    if phase == 7144:
        if getn(w, 1224, 4) & 61440 != 16384:
            return finish(o, w, 65)
        row = 1824000 + get(w, 1830008) * 32
        if get(w, 1830032) == 1:
            if get(w, row + 8) != get(w, 1200) or get(w, row + 16) != get(w, 1208):
                return finish(o, w, 65)
        else:
            put(w, row, get(w, 1830040))
            put(w, row + 8, get(w, 1200))
            put(w, row + 16, get(w, 1208))
            put(w, row + 24, get(w, 1830024))
        copyw(w, 1985000, 1808240, 14)
        size = decimal(w, 1985000 + 14, get(w, 1830040))
        store(w, size, 0)
        return call(o, w, 7145, 89, 1985000, 1990000, 4096, 0, 0, 0, 15)
    if phase == 7145:
        if r == 0 or r > 4095 or byte(w, 1990000) != 47 or worker_utf8_state(w, 1990000, r) == 0:
            return finish(o, w, 65)
        put(w, 1830056, r)
        store(w, 1990000 + r, 0)
        row = 1824000 + get(w, 1830008) * 32
        at = 3145728 + get(w, row + 24)
        if get(w, 1830032) == 1:
            if get(w, at) != r or same(w, at + 8, 1990000, r) == 0:
                return finish(o, w, 65)
            return call(o, w, 7152, 3, get(w, 1830040), 0, 0, 0, 0, 0, 0)
        put(w, at, r)
        copyw(w, at + 8, 1990000, r)
        put(w, 1830024, get(w, 1830024) + 8 + r)
        return call(o, w, 7146, 257, 18446744073709551516, 1990000, 2686976, 0, 0, 0, 12)
    if phase == 7146:
        if r < 3:
            return finish(o, w, 65)
        put(w, 1830064, r)
        return call(o, w, 7147, 5, r, 1200, 0, 0, 0, 0, 12)
    if phase == 7147:
        row = 1824000 + get(w, 1830008) * 32
        if get(w, row + 8) != get(w, 1200) or get(w, row + 16) != get(w, 1208) or getn(w, 1224, 4) & 61440 != 16384:
            return finish(o, w, 65)
        return call(o, w, 7152, 3, get(w, 1830064), 0, 0, 0, 0, 0, 0)
    if phase == 7152:
        put(w, 1830008, get(w, 1830008) + 1)
        return resume(s, o, w, 7142)
    if phase == 7154:
        put(w, 1800688, get(w, 144))
        put(w, 1800696, get(w, 152))
        return resume(s, o, w, 1014)
    return finish(o, w, 65)

def worker_roots_shape(w:mutbuf) -> u64:
    if get(w, 1800680) < 8 or get(w, 1800680) > 131304:
        return 0
    end = 1840000 + get(w, 1800680)
    count = get(w, 1840000)
    if count > 32:
        return 0
    at = 1840008
    i = 0
    while i < count:
        if at > end or end - at < 8:
            return 0
        size = get(w, at)
        at = at + 8
        if size == 0 or size > 4095 or size > end - at or worker_utf8_state(w, at, size) == 0:
            return 0
        at = at + size
        i = i + 1
    return choose(at == end, 1, 0)

def worker_utf8_state(w:mutbuf, at:u64, size:u64) -> u64:
    i = 0
    while i < size:
        c = byte(w, at + i)
        if c == 0:
            return 0
        if c < 128:
            i = i + 1
        else:
            n = 0
            if c >= 194 and c <= 223:
                n = 1
            elif c >= 224 and c <= 239:
                n = 2
            elif c >= 240 and c <= 244:
                n = 3
            if n == 0 or n >= size - i:
                return 0
            second = byte(w, at + i + 1)
            if (c == 224 and second < 160) or (c == 237 and second > 159) or (c == 240 and second < 144) or (c == 244 and second > 143):
                return 0
            j = 1
            while j <= n:
                value = byte(w, at + i + j)
                if value < 128 or value > 191:
                    return 0
                j = j + 1
            i = i + n + 1
    return 1

def worker_constants(w:mutbuf) -> u64:
    put(w, 1808000, 7595371784806823027)
    put(w, 1808008, 461228830817)
    put(w, 1808024, 435711603827)
    put(w, 1808040, 3826790)
    put(w, 1808056, 30518463306100329)
    put(w, 1808072, 133480762729846)
    put(w, 1808088, 8389765627591616872)
    put(w, 1808096, 7578839527870721906)
    put(w, 1808104, 119212747289454)
    put(w, 1808120, 7812741990951317347)
    put(w, 1808128, 29285)
    put(w, 1808144, 7146493963626770295)
    put(w, 1808152, 7308335521232875119)
    put(w, 1808160, 114)
    put(w, 1808176, 8227357874195689335)
    put(w, 1808184, 7146479704301923957)
    put(w, 1808192, 7593682943384907375)
    put(w, 1808200, 110)
    put(w, 1808216, 7651178596868976503)
    put(w, 1808224, 7237491)
    put(w, 1808240, 7310238724270485551)
    put(w, 1808248, 52108257617516)
    put(w, 1808264, 7160567712462303095)
    put(w, 1808272, 7593736819454668399)
    put(w, 1808280, 7022361299819324526)
    put(w, 1808288, 0)
    put(w, 1808304, 7160567712462303095)
    put(w, 1808312, 7593736819454668399)
    put(w, 1808320, 7308044090487039086)
    put(w, 1808328, 27431098827419250)
    put(w, 1808344, 8601705291097403251)
    put(w, 1808352, 7955995161659142767)
    put(w, 1808360, 7593736840979510387)
    put(w, 1808368, 7022361299819324526)
    put(w, 1808376, 0)
    put(w, 1808392, 7160567712462303095)
    put(w, 1808400, 8316564559647633007)
    put(w, 1808408, 7022361299819327087)
    put(w, 1808416, 0)
    put(w, 1808432, 7742373267056453992)
    put(w, 1808440, 7594879246291268197)
    put(w, 1808448, 7507048054250417511)
    put(w, 1808456, 1635020901)
    put(w, 1808472, 7742373267056453992)
    put(w, 1808480, 7594879246291268197)
    put(w, 1808488, 110425377221991)
    put(w, 1808504, 8083242686119833463)
    put(w, 1808512, 8083228400890372961)
    put(w, 1808520, 121398897831529)
    put(w, 1808536, 8299415468233617271)
    put(w, 1808544, 7955940130210084207)
    put(w, 1808552, 3348833620947002742)
    put(w, 1808560, 7235938)
    put(w, 1808576, 8227357874195689335)
    put(w, 1808584, 7955998168371720047)
    put(w, 1808592, 0)
    put(w, 1808608, 7020378893159965307)
    put(w, 1808616, 7022361299818527266)
    put(w, 1808624, 8386105126622423086)
    put(w, 1808632, 7742373267056719465)
    put(w, 1808640, 7022364637025628773)
    put(w, 1808648, 2462380692096314476)
    put(w, 1808656, 6874014074362093936)
    put(w, 1808664, 4188970205514393715)
    put(w, 1808672, 34)
    put(w, 1808688, 7022364637024889890)
    put(w, 1808696, 8247280737009888364)
    put(w, 1808704, 8247620832884188533)
    put(w, 1808712, 8315180330208159075)
    put(w, 1808720, 8462954442816513396)
    put(w, 1808728, 687461)
    put(w, 1808744, 8315171517136730213)
    put(w, 1808752, 8029744822420596783)
    put(w, 1808760, 8588206578253198196)
    put(w, 1808768, 7955995161659142767)
    put(w, 1808776, 7307195314688062579)
    put(w, 1808784, 7595371844935708780)
    put(w, 1808792, 1685353313)
    put(w, 1812000, 1808744)
    put(w, 1812008, 52)
    put(w, 1808808, 8315171517136730213)
    put(w, 1808816, 8029744822420596783)
    put(w, 1808824, 8588206578253198196)
    put(w, 1808832, 7955995161659142767)
    put(w, 1808840, 7310010064455169139)
    put(w, 1808848, 7019256042965069680)
    put(w, 1808856, 6583411)
    put(w, 1812016, 1808808)
    put(w, 1812024, 51)
    put(w, 1808872, 8315171517136730213)
    put(w, 1808880, 8029744822420596783)
    put(w, 1808888, 8588206578253198196)
    put(w, 1808896, 7955995161659142767)
    put(w, 1808904, 8675445176478561395)
    put(w, 1808912, 6876556179757425509)
    put(w, 1808920, 8386114214840984175)
    put(w, 1808928, 8314042283279150953)
    put(w, 1808936, 25716)
    put(w, 1812032, 1808872)
    put(w, 1812040, 66)
    put(w, 1808952, 8315171517136730213)
    put(w, 1808960, 8029744822420596783)
    put(w, 1808968, 8588206578253198196)
    put(w, 1808976, 7955995161659142767)
    put(w, 1808984, 8026363880183788659)
    put(w, 1808992, 8243126013414827378)
    put(w, 1809000, 8314042283278691945)
    put(w, 1809008, 25716)
    put(w, 1812048, 1808952)
    put(w, 1812056, 58)
    put(w, 1809024, 8315171517136730213)
    put(w, 1809032, 8029744822420596783)
    put(w, 1809040, 8588206578253198196)
    put(w, 1809048, 7955995161659142767)
    put(w, 1809056, 8026363880183788659)
    put(w, 1809064, 8391447924271179122)
    put(w, 1809072, 8391157636068700773)
    put(w, 1809080, 100)
    put(w, 1812064, 1809024)
    put(w, 1812072, 57)
    put(w, 1809096, 8315171517136730213)
    put(w, 1809104, 8029744822420596783)
    put(w, 1809112, 8588206578253198196)
    put(w, 1809120, 7955995161659142767)
    put(w, 1809128, 8746658345586357363)
    put(w, 1809136, 8102082873896428916)
    put(w, 1809144, 8391157636068700773)
    put(w, 1809152, 100)
    put(w, 1812080, 1809096)
    put(w, 1812088, 57)
    put(w, 1809168, 8315171517136730213)
    put(w, 1809176, 8029744822420596783)
    put(w, 1809184, 8588206578253198196)
    put(w, 1809192, 7955995161659142767)
    put(w, 1809200, 7020372313419904115)
    put(w, 1809208, 7092992827380557923)
    put(w, 1809216, 7019256042964084074)
    put(w, 1809224, 6583411)
    put(w, 1812096, 1809168)
    put(w, 1812104, 59)
    put(w, 1809240, 8315171517136730213)
    put(w, 1809248, 8029744822420596783)
    put(w, 1809256, 8588206578253198196)
    put(w, 1809264, 7955995161659142767)
    put(w, 1809272, 8246195836994810995)
    put(w, 1809280, 7595371784705762927)
    put(w, 1809288, 1685353313)
    put(w, 1812112, 1809240)
    put(w, 1812120, 52)
    put(w, 1809304, 8315171517136730213)
    put(w, 1809312, 8029744822420596783)
    put(w, 1809320, 8588206578253198196)
    put(w, 1809328, 7955995161659142767)
    put(w, 1809336, 7235419195626845299)
    put(w, 1809344, 7507071169765600869)
    put(w, 1809352, 431450448233)
    put(w, 1812128, 1809304)
    put(w, 1812136, 53)
    put(w, 1809368, 8315171517136730213)
    put(w, 1809376, 8029744822420596783)
    put(w, 1809384, 8588206578253198196)
    put(w, 1809392, 7955995161659142767)
    put(w, 1809400, 7310010064455169139)
    put(w, 1809408, 8391157636068697185)
    put(w, 1809416, 100)
    put(w, 1812144, 1809368)
    put(w, 1812152, 49)
    put(w, 1809432, 8315171517136730213)
    put(w, 1809440, 8029744822420596783)
    put(w, 1809448, 8588206578253198196)
    put(w, 1809456, 7955995161659142767)
    put(w, 1809464, 7310010064455169139)
    put(w, 1809472, 7507071135489418337)
    put(w, 1809480, 431450448233)
    put(w, 1812160, 1809432)
    put(w, 1812168, 53)
    put(w, 1809496, 8315171517136730213)
    put(w, 1809504, 8029744822420596783)
    put(w, 1809512, 8588206578253198196)
    put(w, 1809520, 7955995161659142767)
    put(w, 1809528, 7020653788396614771)
    put(w, 1809536, 7019256042713672052)
    put(w, 1809544, 6583411)
    put(w, 1812176, 1809496)
    put(w, 1812184, 51)
    put(w, 1809560, 8315171517136730213)
    put(w, 1809568, 8029744822420596783)
    put(w, 1809576, 8588206578253198196)
    put(w, 1809584, 7955995161659142767)
    put(w, 1809592, 8531329988402705523)
    put(w, 1809600, 8241417393636994145)
    put(w, 1809608, 7595371870420758629)
    put(w, 1809616, 1685353313)
    put(w, 1812192, 1809560)
    put(w, 1812200, 60)
    put(w, 1809632, 8315171517136730213)
    put(w, 1809640, 8029744822420596783)
    put(w, 1809648, 8588206578253198196)
    put(w, 1809656, 7955995161659142767)
    put(w, 1809664, 8531329988402705523)
    put(w, 1809672, 7592899047295642721)
    put(w, 1809680, 7595371784688465006)
    put(w, 1809688, 1685353313)
    put(w, 1812208, 1809632)
    put(w, 1812216, 60)
    put(w, 1809704, 8315171517136730213)
    put(w, 1809712, 8029744822420596783)
    put(w, 1809720, 8588206578253198196)
    put(w, 1809728, 7955995161659142767)
    put(w, 1809736, 8531329988402705523)
    put(w, 1809744, 7376726265181858913)
    put(w, 1809752, 8314042283279019125)
    put(w, 1809760, 25716)
    put(w, 1812224, 1809704)
    put(w, 1812232, 58)
    put(w, 1809776, 8315171517136730213)
    put(w, 1809784, 8029744822420596783)
    put(w, 1809792, 8588206578253198196)
    put(w, 1809800, 7955995161659142767)
    put(w, 1809808, 7954869236099282035)
    put(w, 1809816, 8314042283279872628)
    put(w, 1809824, 25716)
    put(w, 1812240, 1809776)
    put(w, 1812248, 50)
    put(w, 1809840, 7310021024154741096)
    put(w, 1809848, 7021161818704802915)
    put(w, 1809856, 8458372963704597347)
    put(w, 1809864, 6581353)
    put(w, 1812400, 1809840)
    put(w, 1812408, 27)
    put(w, 1809880, 7308327836377508200)
    put(w, 1809888, 6648673)
    put(w, 1812416, 1809880)
    put(w, 1812424, 11)
    put(w, 1809904, 5639992454447974728)
    put(w, 1809912, 4996261462835879764)
    put(w, 1809920, 4702707217257682015)
    put(w, 1809928, 8316510545700995412)
    put(w, 1809936, 28271)
    put(w, 1812432, 1809904)
    put(w, 1812440, 34)
    put(w, 1809952, 7954877983890696552)
    put(w, 1809960, 7310517995928431988)
    put(w, 1809968, 8227351259995794802)
    put(w, 1809976, 128026153411429)
    put(w, 1812448, 1809952)
    put(w, 1812456, 30)
    put(w, 1809992, 7954877983890696552)
    put(w, 1810000, 7017502605101051252)
    put(w, 1810008, 444251005300)
    put(w, 1812464, 1809992)
    put(w, 1812472, 21)
    put(w, 1810024, 7954877983890696552)
    put(w, 1810032, 7955940177454378356)
    put(w, 1810040, 7307199741743625584)
    put(w, 1810048, 24941)
    put(w, 1812480, 1810024)
    put(w, 1812488, 26)
    put(w, 1810064, 7954877983890696552)
    put(w, 1810072, 7308829205996580212)
    put(w, 1810080, 8028075772494507879)
    put(w, 1810088, 110)
    put(w, 1812496, 1810064)
    put(w, 1812504, 25)
    put(w, 1810104, 7954877983890696552)
    put(w, 1810112, 8246140878443064692)
    put(w, 1810120, 7307199741742706543)
    put(w, 1810128, 24941)
    put(w, 1812512, 1810104)
    put(w, 1812520, 26)
    put(w, 1810144, 7954877983890696552)
    put(w, 1810152, 7309955105903422836)
    put(w, 1810160, 7957616)
    put(w, 1812528, 1810144)
    put(w, 1812536, 19)
    put(w, 1810176, 7954877983890696552)
    put(w, 1810184, 7309955105903422836)
    put(w, 1810192, 500152235377)
    put(w, 1812544, 1810176)
    put(w, 1812552, 21)
    put(w, 1810208, 7954877983890696552)
    put(w, 1810216, 7309955105903422836)
    put(w, 1810224, 8299401234762133619)
    put(w, 1810232, 418447190115)
    put(w, 1812560, 1810208)
    put(w, 1812568, 29)
    put(w, 1810248, 7954877983890696552)
    put(w, 1810256, 7310518055856844148)
    put(w, 1810264, 119165720030578)
    put(w, 1812576, 1810248)
    put(w, 1812584, 22)
    put(w, 1810280, 7954877983890696552)
    put(w, 1810288, 8247548253326617972)
    put(w, 1810296, 105)
    put(w, 1812592, 1810280)
    put(w, 1812600, 17)
    put(w, 1810312, 3270298781242976616)
    put(w, 1810320, 119182715674979)
    put(w, 1812608, 1810312)
    put(w, 1812616, 14)
    put(w, 1810336, 3270298781242976616)
    put(w, 1810344, 521611275877)
    put(w, 1812624, 1810336)
    put(w, 1812632, 13)
    put(w, 1810360, 3270298781242976616)
    put(w, 1810368, 114776264237420)
    put(w, 1812640, 1810360)
    put(w, 1812648, 14)
    put(w, 1810384, 3270298781242976616)
    put(w, 1810392, 8386114214840984175)
    put(w, 1810400, 7237481)
    put(w, 1812656, 1810384)
    put(w, 1812664, 19)
    put(w, 1810416, 3270298781242976616)
    put(w, 1810424, 32774695273325938)
    put(w, 1812672, 1810416)
    put(w, 1812680, 15)
    put(w, 1810440, 3270298781242976616)
    put(w, 1810448, 127996155557235)
    put(w, 1812688, 1810440)
    put(w, 1812696, 14)
    put(w, 1810464, 3270298781242976616)
    put(w, 1810472, 8316308420616549747)
    put(w, 1810480, 29295)
    put(w, 1812704, 1810464)
    put(w, 1812712, 18)
    put(w, 1810496, 7742373267056453992)
    put(w, 1810504, 7021223361253306981)
    put(w, 1810512, 25970)
    put(w, 1812720, 1810496)
    put(w, 1812728, 18)
    put(w, 1810528, 8083242686119833463)
    put(w, 1810536, 8083228400890372961)
    put(w, 1810544, 121398897831529)
    put(w, 1812800, 1810528)
    put(w, 1812808, 22)
    put(w, 1810560, 7651178596868976503)
    put(w, 1810568, 7237491)
    put(w, 1812816, 1810560)
    put(w, 1812824, 11)
    put(w, 1810584, 7954877983890696552)
    put(w, 1810592, 8243112832212086132)
    put(w, 1810600, 0)
    put(w, 1812832, 1810584)
    put(w, 1812840, 16)
    put(w, 1810616, 8245940479580005746)
    put(w, 1810624, 7957705966469932395)
    put(w, 1810632, 0)
    put(w, 1812848, 1810616)
    put(w, 1812856, 16)
    put(w, 1810648, 8749489600778560882)
    put(w, 1810656, 3346848985245513517)
    put(w, 1810664, 1852797802)
    put(w, 1812864, 1810648)
    put(w, 1812872, 20)
    put(w, 1810680, 8587631623715185006)
    put(w, 1810688, 8316510730755732079)
    put(w, 1810696, 28271)
    put(w, 1812880, 1810680)
    put(w, 1812888, 18)
    put(w, 1810712, 7310575252086552165)
    put(w, 1810720, 3276757322258805293)
    put(w, 1810728, 7651178596868976503)
    put(w, 1810736, 7237491)
    put(w, 1812896, 1810712)
    put(w, 1812904, 27)
    put(w, 1810752, 7310575252086552165)
    put(w, 1810760, 3271138770663926061)
    put(w, 1810768, 7651178596868976503)
    put(w, 1810776, 7237491)
    put(w, 1812912, 1810752)
    put(w, 1812920, 27)
    put(w, 1810792, 7310575252086552165)
    put(w, 1810800, 8031938404137920045)
    put(w, 1810808, 8030879308252015474)
    put(w, 1810816, 110)
    put(w, 1812928, 1810792)
    put(w, 1812936, 25)
    return 0