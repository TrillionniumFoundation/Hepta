def advance(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(o) != 128 or length(w) != 4194304:
        return 0
    phase = get(w, 0)
    if phase < 100:
        return admission(s, o, w, phase, get(w, 8))
    if phase < 200:
        return invocation(s, o, w, phase, get(w, 8))
    if phase < 250:
        return transfer(s, o, w, phase, get(w, 8))
    if phase < 300:
        return hashing(s, o, w, phase, get(w, 8))
    if phase < 350:
        return publication(s, o, w, phase, get(w, 8))
    return business(s, o, w, phase, get(w, 8))

def admission(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase >= 60 and phase < 70:
        return 5
    if phase == 0:
        constants(w)
        if admit_request(s, w) == 0:
            return finish(o, w, 65)
        return call(o, w, 1, 110, 0, 0, 0, 0, 0, 0, 0)
    if phase == 1 or phase == 3:
        if r < 2 or (uint(s, 8) != 0 and r != uint(s, 8)):
            return finish(o, w, 65)
        if phase == 1:
            put(w, 3168, r)
            return call(o, w, 2, 157, 1, 15, 0, 0, 0, 0, 0)
        if r != get(w, 3168):
            return finish(o, w, 65)
        return call(o, w, 4, 39, 0, 0, 0, 0, 0, 0, 0)
    if failed(r):
        return finish(o, w, 74)
    if phase == 2:
        return call(o, w, 3, 110, 0, 0, 0, 0, 0, 0, 0)
    if phase == 4:
        put(w, 16, r)
        return call(o, w, 5, 107, 0, 0, 0, 0, 0, 0, 0)
    if phase == 5:
        put(w, 24, r)
        put(w, 32, 0)
        return inspect_initial(s, o, w)
    if phase == 10:
        if getn(w, 1224, 4) & 61440 != 16384:
            return finish(o, w, 65)
        if get(w, 32) == 1 or get(w, 32) == 2:
            if getn(w, 1224, 4) & 63 != 0 or getn(w, 1228, 4) != get(w, 24):
                return finish(o, w, 65)
        copyw(w, 2048 + get(w, 32) * 144, 1200, 144)
        put(w, 32, get(w, 32) + 1)
        return inspect_initial(s, o, w)
    if phase == 11:
        if getn(w, 1224, 4) & 61440 != 32768 or get(w, 1248) < 1 or get(w, 1248) > 67108864:
            return finish(o, w, 65)
        put(w, 48, get(w, 1248))
        put(w, 3000 + (get(w, 32) - 5) * 8, get(w, 1248))
        return call(o, w, 12, 72, uint(s, 48 + (get(w, 32) - 5) * 8), 1034, 0, 0, 0, 0, 0)
    if phase == 12:
        if r & 15 != 15:
            return finish(o, w, 65)
        return hash_view(o, w, uint(s, 48 + (get(w, 32) - 5) * 8), 0, get(w, 48), 13)
    if phase == 13:
        if same_input(s, w, 128 + (get(w, 32) - 5) * 32, 4096, 32) == 0:
            return finish(o, w, 65)
        put(w, 32, get(w, 32) + 1)
        return inspect_initial(s, o, w)
    if phase == 20:
        if r != 0:
            return finish(o, w, 65)
        return call(o, w, 21, 217, uint(s, 32), 49152, 16384, 0, 0, 0, 12)
    if phase == 21:
        if r == 0:
            return audit_start(s, o, w, 1000)
        if r > 16384 or only_dots(w, r) == 0:
            return finish(o, w, 65)
        return call(o, w, 21, 217, uint(s, 32), 49152, 16384, 0, 0, 0, 12)
    return finish(o, w, 65)

def inspect_initial(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    index = get(w, 32)
    if index < 5:
        source = choose(index < 3, 24 + index * 8, 88 + (index - 3) * 8)
        return call(o, w, 10, 5, uint(s, source), 1200, 0, 0, 0, 0, 12)
    if index < 10:
        return call(o, w, 11, 5, uint(s, 48 + (index - 5) * 8), 1200, 0, 0, 0, 0, 12)
    if same(w, 2048, 2192, 16) == 1 or same(w, 2048, 2336, 16) == 1 or same(w, 2192, 2336, 16) == 1:
        return finish(o, w, 65)
    put(w, 216, uint(s, 56))
    put(w, 224, uint(s, 64))
    put(w, 232, uint(s, 48))
    return call(o, w, 60, 5, get(w, 1800016), 1200, 0, 0, 0, 0, 12)

def admit_request(s:readbuf, w:mutbuf) -> u64:
    if length(s) < 305 or length(s) > 2097152 or uint(s, 0) != 3544418983644055880:
        return 0
    if uint(s, 8) == 1 or uint(s, 8) > 2147483647 or uint(s, 16) == 0:
        return 0
    n = uint(s, 104)
    if n == 0 or n > 255 or uint(s, 112) < 16 or uint(s, 120) > 256:
        return 0
    if 288 + n + uint(s, 112) > length(s):
        return 0
    i = 0
    while i < n:
        ch = byte(s, 288 + i)
        if ch == 0 or ch == 47 or ch > 127:
            return 0
        i = i + 1
    if n == 1 and byte(s, 288) == 46:
        return 0
    if n == 2 and byte(s, 288) == 46 and byte(s, 289) == 46:
        return 0
    i = 0
    while i < 10:
        fd = uint(s, 24 + i * 8)
        if fd < 3 or fd > 2147483647:
            return 0
        j = 0
        while j < i:
            if fd == uint(s, 24 + j * 8):
                return 0
            j = j + 1
        i = i + 1
    start = 288 + n
    if uint(s, start) != 3544413516083579208 or uint(s, start + 8) == 0 or uint(s, start + 8) > 4096:
        return 0
    put(w, 80, uint(s, start + 8))
    put(w, 88, start)
    at = start + 16
    i = 0
    while i < get(w, 80):
        at = pin_entry(s, w, at, i)
        if at == 0:
            return 0
        i = i + 1
    if at != 288 + n + uint(s, 112):
        return 0
    return worker_options(s, w, at)

def pin_entry(s:readbuf, w:mutbuf, at:u64, index:u64) -> u64:
    if at > length(s) or length(s) - at < 41:
        return 0
    n = uint(s, at)
    if n == 0 or n > 4095 or n > length(s) - at - 40 or valid_path(s, at + 40, n) == 0:
        return 0
    if index != 0:
        previous = get(w, 131200 + (index - 1) * 16)
        if ordered(s, previous + 40, uint(s, previous), at + 40, n) == 0:
            return 0
    put(w, 131200 + index * 16, at)
    put(w, 131208 + index * 16, n)
    return at + 40 + n

def ordered(s:readbuf, first:u64, a:u64, second:u64, b:u64) -> u64:
    i = 0
    while i < a and i < b:
        if byte(s, first + i) < byte(s, second + i):
            return 1
        if byte(s, first + i) > byte(s, second + i):
            return 0
        i = i + 1
    return choose(a < b, 1, 0)

def valid_path(s:readbuf, at:u64, n:u64) -> u64:
    if byte(s, at) == 47 or byte(s, at + n - 1) == 47:
        return 0
    i = 0
    part = 0
    while i <= n:
        if i == n or byte(s, at + i) == 47:
            size = i - part
            if size == 0 or (size == 1 and byte(s, at + part) == 46):
                return 0
            if size == 2 and byte(s, at + part) == 46 and byte(s, at + part + 1) == 46:
                return 0
            part = i + 1
        else:
            if plain(byte(s, at + i)) == 0:
                return 0
        i = i + 1
    return 1

def plain(c:u64) -> u64:
    if (c >= 65 and c <= 90) or (c >= 97 and c <= 122) or (c >= 48 and c <= 57):
        return 1
    if c == 45 or c == 46 or c == 95:
        return 1
    return 0

def only_dots(w:mutbuf, size:u64) -> u64:
    at = 0
    while at < size:
        if at + 20 > size:
            return 0
        n = getn(w, 49152 + at + 16, 2)
        if n < 21 or n > size - at:
            return 0
        if byte(w, 49152 + at + 19) != 46:
            return 0
        if byte(w, 49152 + at + 20) != 0:
            if n < 22 or byte(w, 49152 + at + 20) != 46 or byte(w, 49152 + at + 21) != 0:
                return 0
        at = at + n
    return 1

def launch(o:mutbuf, w:mutbuf, image:u64, source:u64, operation:u64, pass_source:u64, resume:u64) -> u32:
    put(w, 512, resume)
    put(w, 520, image)
    put(w, 528, source)
    put(w, 536, operation)
    put(w, 544, pass_source)
    put(w, 552, 0)
    return call(o, w, 100, 8, source, 0, 0, 0, 0, 0, 0)

def invocation(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase >= 150:
        return runner_child(s, o, w, phase, r)
    if phase == 112 and r == 18446744073709551612:
        return call(o, w, 112, 61, get(w, 592), 600, 0, 0, 0, 0, 12)
    if failed(r):
        return finish(o, w, 74)
    if phase == 100 or phase == 103:
        if phase == 100 and r != 0:
            return finish(o, w, 65)
        if phase == 103:
            put(w, 552, get(w, 552) + 1)
        if get(w, 552) == 4:
            job_request(s, w)
            return writing(o, w, get(w, 584), 458752, get(w, 608), 104)
        return call(o, w, 101, 319, 600032, 2, 0, 0, 0, 0, 3)
    if phase == 101:
        if r < 3:
            return finish(o, w, 74)
        put(w, 560 + get(w, 552) * 8, r)
        return call(o, w, 103, 91, r, 384, 0, 0, 0, 0, 0)
    if phase == 104:
        return call(o, w, 105, 72, get(w, 584), 1033, 15, 0, 0, 0, 0)
    if phase == 105:
        put(w, 3904, 600064)
        put(w, 3912, 18446744073709551615)
        put(w, 4056, 0)
        put(w, 0, 110)
        put(o, 0, 3904)
        put(o, 8, 2)
        put(o, 16, 4000)
        return 2
    if phase == 110:
        return call(o, w, 111, 57, 0, 0, 0, 0, 0, 0, 0)
    if phase == 111:
        if r == 0:
            return call(o, w, 150, 157, 1, 15, 0, 0, 0, 0, 0)
        put(w, 592, r)
        return call(o, w, 112, 61, r, 600, 0, 0, 0, 0, 12)
    if phase == 112:
        if r != get(w, 592) or getn(w, 600, 4) != 0:
            return finish(o, w, 74)
        return call(o, w, 113, 17, get(w, 576), 5376, 128, 0, 0, 0, 12)
    if phase == 113:
        if r != 128 or receipt(w) == 0:
            return finish(o, w, 74)
        put(w, 144, get(w, 560))
        put(w, 152, get(w, 5424))
        return call(o, w, 114, 5, get(w, 144), 1200, 0, 0, 0, 0, 12)
    if phase == 114:
        if get(w, 1248) != get(w, 152) or get(w, 1216) != 0 or getn(w, 1224, 4) & 61440 != 32768:
            return finish(o, w, 74)
        return call(o, w, 115, 72, get(w, 144), 1033, 15, 0, 0, 0, 0)
    if phase == 115:
        put(w, 552, 1)
        return call(o, w, 116, 3, get(w, 568), 0, 0, 0, 0, 0, 0)
    if phase == 116:
        put(w, 552, get(w, 552) + 1)
        if get(w, 552) < 4:
            return call(o, w, 116, 3, get(w, 560 + get(w, 552) * 8), 0, 0, 0, 0, 0, 0)
        return call(o, w, 117, 3, get(w, 528), 0, 0, 0, 0, 0, 0)
    if phase == 117:
        return resume(s, o, w, get(w, 512))
    return finish(o, w, 65)

def runner_child(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r) or phase == 153:
        return finish(o, w, 127)
    if phase == 150:
        return call(o, w, 151, 110, 0, 0, 0, 0, 0, 0, 0)
    if phase == 151:
        if r != get(w, 16):
            return finish(o, w, 127)
        if get(w, 544) == 3:
            if get(w, 1800240) == 0 or get(w, 1800240) > 6:
                return finish(o, w, 127)
            put(w, 1800304, 0)
            return resume(s, o, w, 154)
        return call(o, w, 152, 33, get(w, 584), 0, 0, 0, 0, 0, 0)
    if phase == 154:
        index = get(w, 1800304)
        if index == get(w, 1800240):
            return call(o, w, 152, 33, get(w, 584), 0, 0, 0, 0, 0, 0)
        fd = get(w, 1800248 + index * 8)
        if fd < 3 or fd > 2147483647:
            return finish(o, w, 127)
        return call(o, w, 155, 72, fd, 1, 0, 0, 0, 0, 0)
    if phase == 155:
        fd = get(w, 1800248 + get(w, 1800304) * 8)
        return call(o, w, 156, 72, fd, 2, r & 18446744073709551614, 0, 0, 0, 0)
    if phase == 156:
        if r != 0:
            return finish(o, w, 127)
        put(w, 1800304, get(w, 1800304) + 1)
        return resume(s, o, w, 154)
    if phase != 152:
        return finish(o, w, 127)
    return call(o, w, 153, 322, get(w, 232), 600000, 4000, 4056, 4096, 0, 252)

def job_request(s:readbuf, w:mutbuf) -> u64:
    at = 458752
    put(w, at, 3544405840977021256)
    put(w, at + 8, get(w, 16))
    put(w, at + 16, uint(s, 16))
    put(w, at + 24, get(w, 520))
    put(w, at + 32, get(w, 528))
    put(w, at + 40, get(w, 560))
    put(w, at + 48, get(w, 568))
    put(w, at + 56, uint(s, 40))
    put(w, at + 64, get(w, 576))
    put(w, at + 72, choose(get(w, 536) == 0, 1, choose(get(w, 536) >= 32, 4, choose(get(w, 536) >= 17, 3, 2))))
    put(w, at + 80, 1)
    put(w, at + 88, 67108864)
    put(w, at + 96, 16384)
    put(w, at + 104, 1000000000)
    put(w, at + 112, worker_memory_limit(w))
    put(w, at + 120, 0)
    at = arg(w, at + 128, 600088, 17)
    if get(w, 536) != 0:
        at = operation_arg(w, at, get(w, 536))
    at = arg(w, at, 600120, 5)
    if get(w, 544) == 1:
        put(w, at, 3544407975525435720)
        put(w, at + 8, 1)
        put(w, at + 16, uint(s, 24))
        at = at + 24
    if get(w, 544) == 2:
        put(w, at, 3544407975525435720)
        put(w, at + 8, 9)
        i = 0
        while i < 9:
            put(w, at + 16 + i * 8, get(w, 1530000 + i * 8))
            i = i + 1
        at = at + 88
    if get(w, 544) == 3:
        put(w, at, 3544407975525435720)
        put(w, at + 8, get(w, 1800240))
        i = 0
        while i < get(w, 1800240):
            put(w, at + 16 + i * 8, get(w, 1800248 + i * 8))
            i = i + 1
        at = at + 16 + get(w, 1800240) * 8
    put(w, 608, at - 458752)
    return 0

def operation_arg(w:mutbuf, at:u64, operation:u64) -> u64:
    if operation == 32 or operation == 33:
        return worker_operation_arg(w, at, operation)
    if operation >= 17 and operation <= 25:
        at = arg(w, at, 600784, 8)
        copyw(w, 62000, 600808, 20)
        store(w, 62000 + 20 - 1, operation - 16 + 48)
        return arg(w, at, 62000, 20)
    if operation == 1:
        return arg(w, at, 600136, 7)
    if operation == 2:
        return arg(w, at, 600152, 4)
    if operation == 3:
        return arg(w, at, 600168, 5)
    return arg(w, at, 600184, 7)

def receipt(w:mutbuf) -> u64:
    if get(w, 5376) != 3544423351558687048 or get(w, 5384) != 0 or get(w, 5392) != 0 or get(w, 5400) != 0:
        return 0
    if get(w, 5408) < 2 or get(w, 5416) == 0 or get(w, 5416) != get(w, 5424) or get(w, 5424) > 67108864:
        return 0
    if get(w, 5432) != 0 or get(w, 5440) != 0 or get(w, 5448) != 0 or get(w, 5456) != 0 or get(w, 5464) != 0:
        return 0
    return choose(get(w, 5472) == 1 and get(w, 5480) == 1 and get(w, 5496) == 1, 1, 0)

def writing(o:mutbuf, w:mutbuf, fd:u64, buffer:u64, count:u64, resume:u64) -> u32:
    return writing_at(o, w, fd, buffer, count, 0, resume)

def writing_at(o:mutbuf, w:mutbuf, fd:u64, buffer:u64, count:u64, offset:u64, resume:u64) -> u32:
    if count == 0:
        put(w, 0, resume)
        put(w, 8, 0)
        return 4
    put(w, 768, fd)
    put(w, 776, buffer)
    put(w, 784, count)
    put(w, 792, offset)
    put(w, 800, resume)
    return call(o, w, 200, 18, fd, buffer, count, offset, 0, 0, 12)

def reading(o:mutbuf, w:mutbuf, fd:u64, buffer:u64, count:u64, offset:u64, resume:u64) -> u32:
    put(w, 808, fd)
    put(w, 816, buffer)
    put(w, 824, count)
    put(w, 832, offset)
    put(w, 840, resume)
    return call(o, w, 201, 17, fd, buffer, count, offset, 0, 0, 12)

def copying(o:mutbuf, w:mutbuf, source:u64, target:u64, offset:u64, count:u64, resume:u64) -> u32:
    if count == 0:
        put(w, 0, resume)
        put(w, 8, 0)
        return 4
    put(w, 848, source)
    put(w, 856, target)
    put(w, 864, count)
    put(w, 872, offset)
    put(w, 880, resume)
    return call(o, w, 202, 40, target, source, 872, count, 0, 0, 48)

def transfer(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 200:
        if r == 18446744073709551612:
            return call(o, w, 200, 18, get(w, 768), get(w, 776), get(w, 784), get(w, 792), 0, 0, 12)
        if failed(r) or r == 0 or r > get(w, 784):
            return finish(o, w, 74)
        put(w, 776, get(w, 776) + r)
        put(w, 784, get(w, 784) - r)
        put(w, 792, get(w, 792) + r)
        if get(w, 784) != 0:
            return call(o, w, 200, 18, get(w, 768), get(w, 776), get(w, 784), get(w, 792), 0, 0, 12)
        return resume(s, o, w, get(w, 800))
    if phase == 201:
        if r == 18446744073709551612:
            return call(o, w, 201, 17, get(w, 808), get(w, 816), get(w, 824), get(w, 832), 0, 0, 12)
        if failed(r) or r == 0 or r > get(w, 824):
            return finish(o, w, 74)
        put(w, 816, get(w, 816) + r)
        put(w, 824, get(w, 824) - r)
        put(w, 832, get(w, 832) + r)
        if get(w, 824) != 0:
            return call(o, w, 201, 17, get(w, 808), get(w, 816), get(w, 824), get(w, 832), 0, 0, 12)
        return resume(s, o, w, get(w, 840))
    if phase == 202:
        if r == 18446744073709551612:
            return call(o, w, 202, 40, get(w, 856), get(w, 848), 872, get(w, 864), 0, 0, 48)
        if failed(r) or r == 0 or r > get(w, 864):
            return finish(o, w, 74)
        put(w, 864, get(w, 864) - r)
        if get(w, 864) != 0:
            return call(o, w, 202, 40, get(w, 856), get(w, 848), 872, get(w, 864), 0, 0, 48)
        return resume(s, o, w, get(w, 880))
    if failed(r):
        return finish(o, w, 74)
    if phase == 210:
        if r < 3:
            return finish(o, w, 74)
        put(w, 888, r)
        return writing(o, w, r, get(w, 904), get(w, 912), 211)
    if phase == 211:
        return call(o, w, 212, 72, get(w, 888), 1033, 15, 0, 0, 0, 0)
    if phase == 212:
        put(w, 144, get(w, 888))
        put(w, 152, get(w, 912))
        return resume(s, o, w, get(w, 896))
    return finish(o, w, 65)

def seal_buffer(o:mutbuf, w:mutbuf, buffer:u64, count:u64, resume:u64) -> u32:
    if buffer > 4194304 or count > 4194304 - buffer:
        return finish(o, w, 65)
    put(w, 896, resume)
    put(w, 904, buffer)
    put(w, 912, count)
    return call(o, w, 210, 319, 600032, 2, 0, 0, 0, 0, 3)

def hash_view(o:mutbuf, w:mutbuf, file:u64, offset:u64, size:u64, resume:u64) -> u32:
    put(w, 40, file)
    put(w, 48, size)
    put(w, 56, 0)
    put(w, 64, offset)
    put(w, 72, resume)
    return sha(o, w, 250, 0, 1)

def hashing(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 250 or phase == 252:
        if r != 0:
            return finish(o, w, 74)
        if get(w, 56) == get(w, 48):
            return sha(o, w, 253, 2, 1)
        return call(o, w, 251, 17, get(w, 40), 65537, minimum(65536, get(w, 48) - get(w, 56)), get(w, 64) + get(w, 56), 0, 0, 12)
    if phase == 251:
        if r == 18446744073709551612:
            return call(o, w, 251, 17, get(w, 40), 65537, minimum(65536, get(w, 48) - get(w, 56)), get(w, 64) + get(w, 56), 0, 0, 12)
        if failed(r) or r == 0 or r > minimum(65536, get(w, 48) - get(w, 56)):
            return finish(o, w, 74)
        put(w, 56, get(w, 56) + r)
        return sha(o, w, 252, 1, r + 1)
    if phase == 253:
        if r != 32:
            return finish(o, w, 74)
        return resume(s, o, w, get(w, 72))
    return finish(o, w, 65)

def publish(o:mutbuf, w:mutbuf, file:u64, size:u64, name:u64, count:u64, mode:u64, after:u64) -> u32:
    if size == 0 or size > 67108864 or count == 0 or count > 127:
        return finish(o, w, 65)
    put(w, 920, file)
    put(w, 936, size)
    put(w, 944, name)
    put(w, 952, count)
    put(w, 960, mode)
    put(w, 968, after)
    return hash_view(o, w, file, 0, size, 300)

def publication(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 74)
    if phase == 300:
        put(w, 6144, get(w, 952))
        put(w, 6152, 64)
        copyw(w, 6160, get(w, 944), get(w, 952))
        hex_digest(w, 6160 + get(w, 952))
        copyw(w, 8100, get(w, 944), get(w, 952))
        store(w, 8100 + get(w, 952), 0)
        return call(o, w, 301, 257, uint(s, 32), 600016, 4259842, 384, 0, 0, 12)
    if phase == 301:
        if r < 3:
            return finish(o, w, 74)
        put(w, 984, r)
        return copying(o, w, get(w, 920), r, 0, get(w, 936), 302)
    if phase == 302:
        return call(o, w, 303, 91, get(w, 984), get(w, 960), 0, 0, 0, 0, 0)
    if phase == 303:
        return call(o, w, 304, 74, get(w, 984), 0, 0, 0, 0, 0, 0)
    if phase == 304:
        copyw(w, 8000, 600200, 14)
        at = decimal(w, 8014, get(w, 984))
        store(w, at, 0)
        return call(o, w, 305, 265, 18446744073709551516, 8000, uint(s, 32), 8100, 1024, 0, 204)
    if phase == 305:
        return call(o, w, 306, 74, uint(s, 32), 0, 0, 0, 0, 0, 0)
    if phase == 306:
        return writing_at(o, w, get(w, 200), 6144, 80 + get(w, 952), get(w, 256), 307)
    if phase == 307:
        put(w, 192, get(w, 192) + 1)
        put(w, 256, get(w, 256) + 80 + get(w, 952))
        return call(o, w, 308, 3, get(w, 984), 0, 0, 0, 0, 0, 0)
    if phase == 308:
        return resume(s, o, w, get(w, 968))
    return finish(o, w, 65)

def hex_digest(w:mutbuf, at:u64) -> u64:
    i = 0
    while i < 32:
        ch = byte(w, 4096 + i)
        store(w, at + i * 2, hex_digit(ch >> 4))
        store(w, at + i * 2 + 1, hex_digit(ch & 15))
        i = i + 1
    return 0

def hex_digit(value:u64) -> u64:
    return choose(value < 10, value + 48, value + 87)

def capture_begin(s:readbuf, w:mutbuf, tag:u64, count:u64) -> u64:
    put(w, 393216, 3616478742009956680)
    put(w, 393224, uint(s, 24))
    put(w, 393232, tag)
    put(w, 393240, count)
    return 393248

def capture_row(s:readbuf, w:mutbuf, at:u64, path:u64, pn:u64, alias:u64, an:u64) -> u64:
    if pn == 0 or pn > 4095 or an == 0 or an > 127 or at > 458752 or 56 + pn + an > 458752 - at:
        return 0
    pin = pin_for(s, w, path, pn)
    if pin == 0:
        return 0
    put(w, at, pn)
    put(w, at + 8, an)
    put(w, at + 16, 0)
    copy(s, w, at + 24, pin, 32)
    copyw(w, at + 56, path, pn)
    copyw(w, at + 56 + pn, alias, an)
    return at + 56 + pn + an

def pin_for(s:readbuf, w:mutbuf, path:u64, n:u64) -> u64:
    i = 0
    while i < get(w, 80):
        row = get(w, 131200 + i * 16)
        if get(w, 131208 + i * 16) == n and same_input(s, w, row + 40, path, n) == 1:
            return row + 8
        i = i + 1
    return 0

def capture_relative(s:readbuf, w:mutbuf, at:u64, source:u64, count:u64, alias:u64, size:u64) -> u64:
    if count == 0 or count > 255:
        return 0
    copyw(w, 530000, 600224, 23)
    copyw(w, 530000 + 23, source, count)
    return capture_row(s, w, at, 530000, 23 + count, alias, size)

def capture_kit(s:readbuf, w:mutbuf, policy:u64, pn:u64, packer:u64, kn:u64, tag:u64) -> u64:
    at = capture_begin(s, w, tag, 3)
    at = capture_relative(s, w, at, policy, pn, 600256, 25)
    if at == 0:
        return 0
    at = capture_relative(s, w, at, 600336, 14, 600336, 14)
    if at == 0:
        return 0
    at = capture_relative(s, w, at, packer, kn, 600296, 25)
    if at == 0:
        return 0
    return at - 393216

def capture_one(s:readbuf, w:mutbuf, path:u64, pn:u64, alias:u64, an:u64, tag:u64) -> u64:
    at = capture_begin(s, w, tag, 1)
    at = capture_row(s, w, at, path, pn, alias, an)
    return choose(at == 0, 0, at - 393216)

def capture_request(o:mutbuf, w:mutbuf, size:u64, after:u64) -> u32:
    if size == 0:
        return finish(o, w, 65)
    put(w, 1064, after)
    return seal_buffer(o, w, 393216, size, 1090)

def business(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase >= 7810 and phase < 7900:
        return worker_result(s, o, w, phase, r)
    if phase >= 7000:
        return 5
    if failed(r) and (phase != 5905 or r != 18446744073709551599):
        return finish(o, w, 74)
    if phase == 1090:
        return launch(o, w, get(w, 224), get(w, 144), 0, 1, get(w, 1064))
    if phase >= 6000 and phase < 6100:
        return frontend(s, o, w, phase, r)
    if phase >= 6100 and phase < 6200:
        return worker_frontend(s, o, w, phase, r)
    if phase >= 5000 and phase < 6000:
        return 5
    if phase >= 4500 and phase < 4600:
        return source_audit(s, o, w, phase, r)
    if phase >= 4300 and phase < 4400:
        return cold_admission(s, o, w, phase, r)
    if phase >= 1200 and phase < 1300:
        return member_loop(s, o, w, phase, r)
    if phase >= 1400 and phase < 1500:
        return materialize(s, o, w, phase, r)
    if phase >= 1600 and phase < 1700:
        return frame_step(s, o, w, phase, r)
    if phase >= 2000 and phase < 2100:
        return compiler_manifest(s, o, w, phase, r)
    if phase == 1000:
        return call(o, w, 1001, 319, 600032, 2, 0, 0, 0, 0, 3)
    if phase == 1001:
        if r < 3:
            return finish(o, w, 74)
        put(w, 200, r)
        put(w, 256, 24)
        put(w, 6144, 3544427800977033544)
        put(w, 6152, 0)
        put(w, 6160, 0)
        return writing(o, w, r, 6144, 24, 1002)
    if phase == 1002:
        return capture_request(o, w, capture_kit(s, w, 600256, 25, 600296, 25, 3544417849621694792), 1003)
    if phase == 1003:
        return launch(o, w, get(w, 216), get(w, 144), 1, 0, 1004)
    if phase == 1004:
        return launch(o, w, get(w, 216), get(w, 144), 2, 0, 1005)
    if phase == 1005:
        return hash_view(o, w, get(w, 144), 0, get(w, 152), 1006)
    if phase == 1006:
        if same_input(s, w, 160, 4096, 32) == 0:
            return finish(o, w, 65)
        put(w, 216, get(w, 144))
        return call(o, w, 1007, 91, get(w, 216), 320, 0, 0, 0, 0, 0)
    if phase == 1007:
        return publish(o, w, get(w, 216), get(w, 152), 600608, 16, 320, 1010)
    if phase == 1010:
        return capture_request(o, w, capture_kit(s, w, 600360, 24, 600296, 25, 3544417849621694792), 1011)
    if phase == 1011:
        return launch(o, w, get(w, 216), get(w, 144), 1, 0, 1012)
    if phase == 1012:
        return launch(o, w, get(w, 216), get(w, 144), 2, 0, 1013)
    if phase == 1013:
        put(w, 120, get(w, 144))
        return call(o, w, 4300, 91, get(w, 120), 320, 0, 0, 0, 0, 0)
    if phase == 1014:
        return capture_request(o, w, capture_kit(s, w, 600400, 32, 600296, 25, 3544425580512495944), 1015)
    if phase == 1015:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 1016)
    if phase == 1016:
        put(w, 128, get(w, 144))
        return call(o, w, 1017, 91, get(w, 128), 320, 0, 0, 0, 0, 0)
    if phase == 1017:
        return capture_request(o, w, capture_one(s, w, 600528, 49, 600592, 4, 3544428844805081416), 1018)
    if phase == 1018:
        return launch(o, w, get(w, 128), get(w, 144), 3, 0, 1019)
    if phase == 1019:
        if get(w, 152) < 16 or get(w, 152) > 65536:
            return finish(o, w, 65)
        put(w, 112, get(w, 152))
        return reading(o, w, get(w, 144), 200704, get(w, 152), 0, 1020)
    if phase == 1020:
        if admit_recipes(s, w) == 0:
            return finish(o, w, 65)
        return launch(o, w, get(w, 128), get(w, 144), 3, 0, 1021)
    if phase == 1021:
        if get(w, 152) != 16 + get(w, 104) * 8:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 286720, get(w, 152), 0, 1022)
    if phase == 1022:
        if admit_reuse(w) == 0:
            return finish(o, w, 65)
        return call(o, w, 1023, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 1023:
        return capture_request(o, w, capture_kit(s, w, 600488, 31, 600296, 25, 3544425580512495944), 1024)
    if phase == 1024:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 1025)
    if phase == 1025:
        put(w, 321000, get(w, 144))
        return call(o, w, 1026, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 1026:
        put(w, 96, 0)
        return member_loop(s, o, w, 1200, 0)
    if phase == 1300:
        put(w, 1104, 0)
        return resume(s, o, w, 1301)
    if phase == 1301:
        if get(w, 1104) == 8:
            return compiler_manifest(s, o, w, 2000, 0)
        row = 604128 + get(w, 1104) * 32
        return capture_request(o, w, capture_one(s, w, get(w, row), get(w, row + 8), get(w, row + 16), get(w, row + 24), 3544428844805081416), 1302)
    if phase == 1302:
        put(w, 320000 + get(w, 1104) * 16, get(w, 144))
        put(w, 320008 + get(w, 1104) * 16, get(w, 152))
        row = 604128 + get(w, 1104) * 32
        return publish(o, w, get(w, 144), get(w, 152), get(w, row + 16), get(w, row + 24), 256, 1303)
    if phase == 1303:
        put(w, 1104, get(w, 1104) + 1)
        return resume(s, o, w, 1301)
    if phase == 4000:
        return audit_start(s, o, w, 4006)
    if phase == 4006:
        put(w, 6144, 3544427800977033544)
        put(w, 6152, get(w, 192))
        put(w, 6160, 0)
        return writing(o, w, get(w, 200), 6144, 24, 4001)
    if phase == 4001:
        return call(o, w, 4002, 72, get(w, 200), 1033, 15, 0, 0, 0, 0)
    if phase == 4002:
        if final_frame(s, w) == 0:
            return finish(o, w, 65)
        view(w, 0, get(w, 200), 0, get(w, 256))
        return frame(o, w, 6144, 192 + uint(s, 104), 330000, 1, 4003)
    if phase == 4003:
        return launch(o, w, get(w, 1530080), get(w, 144), 0, 2, 4004)
    if phase == 4004:
        if get(w, 152) == 0 or get(w, 152) > 4096:
            return finish(o, w, 65)
        return call(o, w, 7000, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 4005:
        return finish(o, w, 0)
    return finish(o, w, 65)

def audit_start(s:readbuf, o:mutbuf, w:mutbuf, after:u64) -> u32:
    put(w, 1550000, 0)
    put(w, 1550016, after)
    return resume(s, o, w, 4500)

def source_audit(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 4500:
        if get(w, 1550000) == get(w, 80):
            return resume(s, o, w, get(w, 1550016))
        count = minimum(128, get(w, 80) - get(w, 1550000))
        at = capture_begin(s, w, 3544408039698286920, count)
        i = 0
        while i < count:
            row = get(w, 131200 + (get(w, 1550000) + i) * 16)
            pn = uint(s, row)
            copyw(w, 530000, 600968, 7)
            an = decimal(w, 530000 + 7, i) - 530000
            if at + 56 + pn + an > 458752:
                return finish(o, w, 65)
            put(w, at, pn)
            put(w, at + 8, an)
            put(w, at + 16, 0)
            copy(s, w, at + 24, row + 8, 32)
            copy(s, w, at + 56, row + 40, pn)
            copyw(w, at + 56 + pn, 530000, an)
            at = at + 56 + pn + an
            i = i + 1
        put(w, 1550008, count)
        return capture_request(o, w, at - 393216, 4501)
    if phase == 4501:
        if get(w, 152) != 24:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 49152, 24, 0, 4502)
    if phase == 4502:
        if get(w, 49152) != 3544415710509877576 or get(w, 49160) != get(w, 1550008) or get(w, 49168) > get(w, 1550008) * 67108864:
            return finish(o, w, 65)
        return call(o, w, 4503, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 4503:
        put(w, 1550000, get(w, 1550000) + get(w, 1550008))
        return resume(s, o, w, 4500)
    return finish(o, w, 65)

def cold_admission(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 4300:
        return capture_request(o, w, capture_kit(s, w, 600896, 31, 600296, 25, 3544425580512495944), 4301)
    if phase == 4301:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 4302)
    if phase == 4302:
        put(w, 1531024, get(w, 144))
        put(w, 1531032, get(w, 152))
        return call(o, w, 4303, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 4303:
        return capture_request(o, w, capture_one(s, w, 601512, 35, 600592, 4, 3544428844805081416), 4304)
    if phase == 4304:
        put(w, 1531000, get(w, 144))
        put(w, 1531008, get(w, 152))
        copy(s, w, 3145728, get(w, 88), uint(s, 112))
        return seal_buffer(o, w, 3145728, uint(s, 112), 4305)
    if phase == 4305:
        put(w, 1531016, get(w, 144))
        put(w, 6144, 3544408001077135688)
        put(w, 6152, get(w, 3032))
        put(w, 6160, uint(s, 112))
        put(w, 6168, get(w, 1531008))
        copy(s, w, 6176, 224, 32)
        view(w, 0, uint(s, 80), 0, get(w, 3032))
        view(w, 1, get(w, 1531016), 0, uint(s, 112))
        view(w, 2, get(w, 1531000), 0, get(w, 1531008))
        return frame(o, w, 6144, 64, 330000, 3, 4306)
    if phase == 4306:
        return launch(o, w, get(w, 1531024), get(w, 144), 3, 0, 4307)
    if phase == 4307:
        if get(w, 152) != 48:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 49152, 48, 0, 4308)
    if phase == 4308:
        if get(w, 49152) != 3544406867172215112 or get(w, 49192) != get(w, 80) or same_input(s, w, 224, 49160, 32) == 0:
            return finish(o, w, 65)
        return call(o, w, 4309, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 4309:
        return publish(o, w, get(w, 1531024), get(w, 1531032), 600936, 22, 320, 4313)
    if phase == 4313:
        return call(o, w, 4310, 3, get(w, 1531024), 0, 0, 0, 0, 0, 0)
    if phase == 4310:
        return call(o, w, 4311, 3, get(w, 1531000), 0, 0, 0, 0, 0, 0)
    if phase == 4311:
        return call(o, w, 4312, 3, get(w, 1531016), 0, 0, 0, 0, 0, 0)
    if phase == 4312:
        return resume(s, o, w, 7100)
    return finish(o, w, 65)

def frontend(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 6000:
        return capture_request(o, w, capture_kit(s, w, 600448, 26, 601152, 32, 3544425580512495944), 6001)
    if phase == 6001:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 6002)
    if phase == 6002:
        put(w, 1532000, get(w, 144))
        return call(o, w, 6003, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 6003:
        at = capture_begin(s, w, 3544416835992635720, 2)
        at = capture_relative(s, w, at, 601112, 25, 601080, 23)
        at = capture_relative(s, w, at, 601240, 19, 601240, 19)
        return capture_request(o, w, choose(at == 0, 0, at - 393216), 6004)
    if phase == 6004:
        return launch(o, w, get(w, 1532000), get(w, 144), 3, 0, 6005)
    if phase == 6005:
        if get(w, 152) < 216:
            return finish(o, w, 65)
        put(w, 992, get(w, 144))
        put(w, 1016, get(w, 152))
        put(w, 1000, 2)
        put(w, 176, 601048)
        put(w, 184, 17)
        return reading(o, w, get(w, 144), 546816, 40, get(w, 152) - 40, 6006)
    if phase == 6006:
        if member_footer(w) == 0:
            return finish(o, w, 65)
        return reading(o, w, get(w, 992), 49152, 176, 0, 6007)
    if phase == 6007:
        if elf_header(w, get(w, 160)) == 0:
            return finish(o, w, 65)
        return extract_code(o, w, get(w, 992), get(w, 160), 6008)
    if phase == 6008:
        put(w, 1532008, get(w, 144))
        put(w, 1532016, get(w, 152))
        return call(o, w, 6009, 3, get(w, 992), 0, 0, 0, 0, 0, 0)
    if phase == 6009:
        return call(o, w, 6010, 3, get(w, 1532000), 0, 0, 0, 0, 0, 0)
    if phase == 6010:
        return capture_request(o, w, capture_kit(s, w, 601200, 30, 600296, 25, 3544425580512495944), 6011)
    if phase == 6011:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 6012)
    if phase == 6012:
        put(w, 1532024, get(w, 144))
        if frontend_capabilities(w) == 0:
            return finish(o, w, 65)
        put(w, 1532032, 0)
        put(w, 1532200, 3550035310211582280)
        return call(o, w, 6013, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 6013:
        index = get(w, 1532032)
        if index == 4:
            view(w, 0, get(w, 1532008), 0, get(w, 1532016))
            return frame(o, w, 1532200, 136, 330000, 1, 6015)
        row = 1532100 + index * 16
        return hash_view(o, w, get(w, row), 0, get(w, row + 8), 6014)
    if phase == 6014:
        copyw(w, 1532208 + get(w, 1532032) * 32, 4096, 32)
        put(w, 1532032, get(w, 1532032) + 1)
        return resume(s, o, w, 6013)
    if phase == 6015:
        return launch(o, w, get(w, 1532024), get(w, 144), 3, 0, 6016)
    if phase == 6016:
        if get(w, 152) != get(w, 1532016):
            return finish(o, w, 65)
        put(w, 1532040, get(w, 144))
        return publish(o, w, get(w, 144), get(w, 152), 601048, 17, 320, 6017)
    if phase == 6017:
        return call(o, w, 6018, 3, get(w, 1532040), 0, 0, 0, 0, 0, 0)
    if phase == 6018:
        return call(o, w, 6019, 3, get(w, 1532024), 0, 0, 0, 0, 0, 0)
    if phase == 6019:
        return call(o, w, 6100, 3, get(w, 1532008), 0, 0, 0, 0, 0, 0)
    return finish(o, w, 65)

def frontend_capabilities(w:mutbuf) -> u64:
    owner = find_product(w, 600984, 17)
    runner = find_product(w, 600064, 14)
    capture = find_product(w, 601016, 18)
    if owner == 0 or runner == 0 or capture == 0:
        return 0
    put(w, 1532100, get(w, owner))
    put(w, 1532108, get(w, owner + 8))
    put(w, 1532116, get(w, runner))
    put(w, 1532124, get(w, runner + 8))
    put(w, 1532132, get(w, 216))
    put(w, 1532140, get(w, 3008))
    put(w, 1532148, get(w, capture))
    put(w, 1532156, get(w, capture + 8))
    return 1

def worker_frontend(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 6100:
        return capture_request(o, w, capture_kit(s, w, 600448, 26, 601424, 33, 3544425580512495944), 6101)
    if phase == 6101:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 6102)
    if phase == 6102:
        put(w, 1532000, get(w, 144))
        return call(o, w, 6103, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 6103:
        at = capture_begin(s, w, 3544416835992635720, 2)
        at = capture_relative(s, w, at, 601384, 26, 601344, 24)
        at = capture_relative(s, w, at, 601240, 19, 601240, 19)
        return capture_request(o, w, choose(at == 0, 0, at - 393216), 6104)
    if phase == 6104:
        return launch(o, w, get(w, 1532000), get(w, 144), 3, 0, 6105)
    if phase == 6105:
        if get(w, 152) < 216:
            return finish(o, w, 65)
        put(w, 992, get(w, 144))
        put(w, 1016, get(w, 152))
        put(w, 1000, 2)
        put(w, 176, 601312)
        put(w, 184, 18)
        return reading(o, w, get(w, 144), 546816, 40, get(w, 152) - 40, 6106)
    if phase == 6106:
        if member_footer(w) == 0:
            return finish(o, w, 65)
        return reading(o, w, get(w, 992), 49152, 176, 0, 6107)
    if phase == 6107:
        if elf_header(w, get(w, 160)) == 0:
            return finish(o, w, 65)
        return extract_code(o, w, get(w, 992), get(w, 160), 6108)
    if phase == 6108:
        put(w, 1532008, get(w, 144))
        put(w, 1532016, get(w, 152))
        return call(o, w, 6109, 3, get(w, 992), 0, 0, 0, 0, 0, 0)
    if phase == 6109:
        return call(o, w, 6110, 3, get(w, 1532000), 0, 0, 0, 0, 0, 0)
    if phase == 6110:
        return capture_request(o, w, capture_kit(s, w, 601472, 31, 600296, 25, 3544425580512495944), 6111)
    if phase == 6111:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 6112)
    if phase == 6112:
        put(w, 1532024, get(w, 144))
        if worker_frontend_capabilities(w) == 0:
            return finish(o, w, 65)
        put(w, 1532032, 0)
        put(w, 1532200, 3550035310211582280)
        return call(o, w, 6113, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 6113:
        index = get(w, 1532032)
        if index == 4:
            view(w, 0, get(w, 1532008), 0, get(w, 1532016))
            return frame(o, w, 1532200, 136, 330000, 1, 6115)
        row = 1532100 + index * 16
        return hash_view(o, w, get(w, row), 0, get(w, row + 8), 6114)
    if phase == 6114:
        copyw(w, 1532208 + get(w, 1532032) * 32, 4096, 32)
        put(w, 1532032, get(w, 1532032) + 1)
        return resume(s, o, w, 6113)
    if phase == 6115:
        return launch(o, w, get(w, 1532024), get(w, 144), 3, 0, 6116)
    if phase == 6116:
        if get(w, 152) != get(w, 1532016):
            return finish(o, w, 65)
        put(w, 1532040, get(w, 144))
        return publish(o, w, get(w, 144), get(w, 152), 601312, 18, 320, 6117)
    if phase == 6117:
        return call(o, w, 6118, 3, get(w, 1532040), 0, 0, 0, 0, 0, 0)
    if phase == 6118:
        return call(o, w, 6119, 3, get(w, 1532024), 0, 0, 0, 0, 0, 0)
    if phase == 6119:
        return call(o, w, 4000, 3, get(w, 1532008), 0, 0, 0, 0, 0, 0)
    return finish(o, w, 65)

def worker_frontend_capabilities(w:mutbuf) -> u64:
    owner = find_product(w, 601272, 24)
    runner = find_product(w, 600064, 14)
    capture = find_product(w, 601016, 18)
    if owner == 0 or runner == 0 or capture == 0:
        return 0
    put(w, 1532100, get(w, owner))
    put(w, 1532108, get(w, owner + 8))
    put(w, 1532116, get(w, runner))
    put(w, 1532124, get(w, runner + 8))
    put(w, 1532132, get(w, 216))
    put(w, 1532140, get(w, 3008))
    put(w, 1532148, get(w, capture))
    put(w, 1532156, get(w, capture + 8))
    return 1

def admit_recipes(s:readbuf, w:mutbuf) -> u64:
    if get(w, 200704) != 3554557593164794184 or get(w, 200712) == 0 or get(w, 200712) > 256:
        return 0
    put(w, 104, get(w, 200712))
    if uint(s, 120) != 0 and uint(s, 120) != get(w, 104):
        return 0
    at = 200720
    i = 0
    while i < get(w, 104):
        at = recipe_entry(w, at, i)
        if at == 0:
            return 0
        i = i + 1
    if at != 200704 + get(w, 112):
        return 0
    if get(w, 270352) != 27 or same(w, get(w, 270344), 600640, 27) == 0:
        return 0
    return 1

def recipe_entry(w:mutbuf, at:u64, index:u64) -> u64:
    if at >= 200704 + get(w, 112):
        return 0
    count = byte(w, at)
    if count < 2 or count > 10 or count & 1 != 0:
        return 0
    record = 270336 + index * 64
    put(w, record, at)
    put(w, record + 40, (count - 2) >> 1)
    at = at + 1
    i = 0
    while i < count:
        if at >= 200704 + get(w, 112):
            return 0
        n = byte(w, at)
        if n == 0 or n > 127 or n > 200704 + get(w, 112) - at - 1:
            return 0
        if i == 0:
            if valid_product(w, at + 1, n) == 0 or duplicate_product(w, at + 1, n, index) == 1:
                return 0
            put(w, record + 8, at + 1)
            put(w, record + 16, n)
        if i == 1:
            put(w, record + 24, at + 1)
            put(w, record + 32, n)
            put(w, record + 48, at + n + 1)
        at = at + 1 + n
        i = i + 1
    return at

def valid_product(w:mutbuf, at:u64, n:u64) -> u64:
    if n < 5 or byte(w, at) != 104 or byte(w, at + 1) != 105 or byte(w, at + 2) != 97 or byte(w, at + 3) != 45:
        return 0
    i = 0
    while i < n:
        if plain(byte(w, at + i)) == 0:
            return 0
        i = i + 1
    return 1

def duplicate_product(w:mutbuf, at:u64, n:u64, count:u64) -> u64:
    i = 0
    while i < count:
        if get(w, 270352 + i * 64) == n and same(w, get(w, 270344 + i * 64), at, n) == 1:
            return 1
        i = i + 1
    return 0

def admit_reuse(w:mutbuf) -> u64:
    if get(w, 286720) != 3550335507168840008 or get(w, 286728) != get(w, 104):
        return 0
    i = 0
    while i < get(w, 104):
        owner = get(w, 286736 + i * 8)
        if owner > i or get(w, 286736 + owner * 8) != owner:
            return 0
        record = 270336 + i * 64
        source = 270336 + owner * 64
        if get(w, record + 32) != get(w, source + 32) or same(w, get(w, record + 24), get(w, source + 24), get(w, record + 32)) == 0:
            return 0
        put(w, record + 56, owner)
        i = i + 1
    return 1

def member_loop(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 1200:
        if get(w, 96) == get(w, 104):
            return resume(s, o, w, 1300)
        record = 270336 + get(w, 96) * 64
        put(w, 176, get(w, record + 8))
        put(w, 184, get(w, record + 16))
        put(w, 1000, get(w, record + 40))
        if get(w, record + 56) == get(w, 96):
            return capture_request(o, w, capture_kit(s, w, 600448, 26, get(w, record + 24), get(w, record + 32), 3544425580512495944), 1201)
        put(w, 136, get(w, 290816 + get(w, record + 56) * 8))
        if get(w, 136) < 3:
            return finish(o, w, 65)
        return member_loop(s, o, w, 1204, 0)
    if phase == 1201:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 1202)
    if phase == 1202:
        put(w, 136, get(w, 144))
        put(w, 290816 + get(w, 96) * 8, get(w, 144))
        return call(o, w, 1204, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 1204:
        if get(w, 1000) == 0:
            if get(w, 184) != 15 or same(w, get(w, 176), 600680, 15) == 0:
                return finish(o, w, 65)
            put(w, 393216, 3554556510916921672)
            return seal_buffer(o, w, 393216, 8, 1206)
        return capture_request(o, w, member_capture(s, w), 1206)
    if phase == 1206:
        return launch(o, w, get(w, 136), get(w, 144), 3, 0, 1207)
    if phase == 1207:
        if get(w, 152) < 176:
            return finish(o, w, 65)
        put(w, 992, get(w, 144))
        put(w, 1016, get(w, 152))
        if get(w, 1000) == 0:
            put(w, 160, get(w, 152))
            return reading(o, w, get(w, 144), 49152, 176, 0, 1210)
        return reading(o, w, get(w, 144), 546816, choose(get(w, 1000) == 1, 24, (get(w, 1000) + 3) * 8), get(w, 152) - choose(get(w, 1000) == 1, 24, (get(w, 1000) + 3) * 8), 1208)
    if phase == 1208:
        if member_footer(w) == 0:
            return finish(o, w, 65)
        return reading(o, w, get(w, 992), 49152, choose(is_artifact(w), 352, 176), 0, 1210)
    if phase == 1210:
        if elf_header(w, get(w, 160)) == 0:
            return finish(o, w, 65)
        if selfhost_view(w) != 0:
            return hash_view(o, w, get(w, 992), get(w, 1144), get(w, 1152), 1214)
        return extract_code(o, w, get(w, 992), get(w, 160), 1211)
    if phase == 1214:
        if same_input(s, w, 224, 4096, 32) == 0:
            return finish(o, w, 65)
        return extract_code(o, w, get(w, 992), get(w, 160), 1211)
    if phase == 1211:
        put(w, 321080, get(w, 144))
        put(w, 321088, get(w, 152))
        put(w, 321008, member_binding(w))
        if get(w, 321008) == 0:
            return publish(o, w, get(w, 144), get(w, 152), get(w, 176), get(w, 184), 320, 1212)
        row = 270336 + get(w, 96) * 64
        copyw(w, 530000, 600224, 23)
        copyw(w, 530000 + 23, get(w, row + 24), get(w, row + 32))
        return capture_request(o, w, capture_one(s, w, 530000, 23 + get(w, row + 32), 600592, 4, 3544428844805081416), 1215)
    if phase == 1212:
        retain_product(w)
        if get(w, 184) == 13 and same(w, get(w, 176), 600704, 13) == 1:
            put(w, 1112, get(w, 992))
            put(w, 1120, get(w, 160))
            put(w, 1128, get(w, 546824))
            return member_loop(s, o, w, 1213, 0)
        return call(o, w, 1213, 3, get(w, 992), 0, 0, 0, 0, 0, 0)
    if phase == 1213:
        put(w, 96, get(w, 96) + 1)
        return member_loop(s, o, w, 1200, 0)
    if phase >= 1215:
        return binding_check(s, o, w, phase, r)
    return finish(o, w, 65)

def member_capture(s:readbuf, w:mutbuf) -> u64:
    record = 270336 + get(w, 96) * 64
    source = get(w, record + 48)
    at = capture_begin(s, w, choose(get(w, 1000) == 1, 3544411304007649608, 3544416835992635720), get(w, 1000))
    i = 0
    while i < get(w, 1000):
        an = byte(w, source)
        alias = source + 1
        source = alias + an
        pn = byte(w, source)
        at = capture_relative(s, w, at, source + 1, pn, alias, an)
        if at == 0:
            return 0
        source = source + 1 + pn
        i = i + 1
    return at - 393216

def member_footer(w:mutbuf) -> u64:
    count = get(w, 1000)
    size = get(w, 546816)
    if size < 176 or size > get(w, 1016):
        return 0
    total = size
    i = 0
    while i < count:
        n = get(w, 546824 + i * 8)
        if n == 0 or n > 1048576:
            return 0
        total = total + n
        i = i + 1
    if count == 1:
        if get(w, 546832) != 3544414555398555976 or total + 24 != get(w, 1016):
            return 0
    else:
        if get(w, 546824 + count * 8) != count or get(w, 546832 + count * 8) != 3554266179583428936 or total + (count + 3) * 8 != get(w, 1016):
            return 0
    put(w, 160, size)
    return 1

def elf_header(w:mutbuf, size:u64) -> u64:
    if get(w, 49152) != 282584257676671 or get(w, 49160) != 0:
        return 0
    if get(w, 49168) != 4299030530 or get(w, 49184) != 64 or get(w, 49192) != 0:
        return 0
    if get(w, 49200) != 15762873573703680 or get(w, 49208) != choose(is_artifact(w), 3, 2):
        return 0
    if get(w, 49216) != 21474836481 or get(w, 49224) != 0 or get(w, 49232) != 4194304 or get(w, 49240) != 4194304:
        return 0
    if get(w, 49248) != size or get(w, 49256) != size or get(w, 49264) != 4096:
        return 0
    if get(w, 49272) != 27455186257 or get(w, 49320) != 16:
        return 0
    i = 128
    while i < 168:
        if get(w, 49152 + i) != 0:
            return 0
        i = i + 8
    if is_artifact(w):
        return artifact_header(w, size)
    return choose(get(w, 49176) == 4194480, 1, 0)

def is_artifact(w:mutbuf) -> bool:
    return get(w, 184) == 12 and same(w, get(w, 176), 600728, 12) == 1

def artifact_header(w:mutbuf, size:u64) -> u64:
    if size < 352 or get(w, 49176) != 4194656:
        return 0
    if get(w, 49328) != 17179869188 or get(w, 49336) != 232 or get(w, 49344) != 4194536 or get(w, 49352) != 4194536:
        return 0
    if get(w, 49360) != 120 or get(w, 49368) != 120 or get(w, 49376) != 4:
        return 0
    if get(w, 49384) != 412316860425 or getn(w, 49392, 4) != 1 or get(w, 49396) != 6217584620943264072 or getn(w, 49404, 4) != 0:
        return 0
    if get(w, 49408) != 3552306853973150024 or get(w, 49416) != 1 or get(w, 49424) != 4194656:
        return 0
    if get(w, 49432) <= 4194656 or get(w, 49432) >= 4194304 + size:
        return 0
    if get(w, 49440) != 16 or get(w, 49448) != 128 or get(w, 49456) != 96 or get(w, 49464) != 24:
        return 0
    if get(w, 49472) != 0 or get(w, 49480) != 0 or get(w, 49488) != 63 or get(w, 49496) != 0:
        return 0
    return 1

def extract_code(o:mutbuf, w:mutbuf, source:u64, count:u64, after:u64) -> u32:
    return extract_view(o, w, source, 0, count, after)

def extract_view(o:mutbuf, w:mutbuf, source:u64, offset:u64, count:u64, after:u64) -> u32:
    put(w, 1184, offset)
    put(w, 1072, source)
    put(w, 1080, count)
    put(w, 1088, after)
    return call(o, w, 1400, 319, 600032, 2, 0, 0, 0, 0, 3)

def materialize(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 1400:
        if r < 3:
            return finish(o, w, 74)
        put(w, 1096, r)
        return copying(o, w, get(w, 1072), r, get(w, 1184), get(w, 1080), 1401)
    if phase == 1401:
        return call(o, w, 1402, 91, get(w, 1096), 320, 0, 0, 0, 0, 0)
    if phase == 1402:
        return call(o, w, 1403, 72, get(w, 1096), 1033, 15, 0, 0, 0, 0)
    if phase == 1403:
        put(w, 144, get(w, 1096))
        put(w, 152, get(w, 1080))
        return resume(s, o, w, get(w, 1088))
    return finish(o, w, 65)

def retain_product(w:mutbuf) -> u64:
    at = 294912 + get(w, 96) * 32
    put(w, at, get(w, 144))
    put(w, at + 8, get(w, 152))
    put(w, at + 16, get(w, 176))
    put(w, at + 24, get(w, 184))
    return 0

def selfhost_view(w:mutbuf) -> u64:
    source = get(w, 270384 + get(w, 96) * 64)
    offset = get(w, 160)
    i = 0
    while i < get(w, 1000):
        n = byte(w, source)
        if n == 14 and same(w, source + 1, 600336, n) == 1:
            put(w, 1144, offset)
            put(w, 1152, get(w, 546824 + i * 8))
            return 1
        source = source + n + 1
        source = source + byte(w, source) + 1
        offset = offset + get(w, 546824 + i * 8)
        i = i + 1
    return 0

def frame(o:mutbuf, w:mutbuf, header:u64, size:u64, parts:u64, count:u64, after:u64) -> u32:
    if count > 128 or size > 65536:
        return finish(o, w, 65)
    put(w, 3080, after)
    put(w, 3088, parts)
    put(w, 3096, count)
    put(w, 3104, 0)
    put(w, 3112, header)
    put(w, 3120, size)
    put(w, 3128, size)
    put(w, 3136, 0)
    return call(o, w, 1600, 319, 600032, 2, 0, 0, 0, 0, 3)

def framed(o:mutbuf, w:mutbuf, header:u64, size:u64, parts:u64, count:u64, after:u64) -> u32:
    result = frame(o, w, header, size, parts, count, after)
    put(w, 3136, 1)
    return result

def frame_step(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 1600:
        if r < 3:
            return finish(o, w, 74)
        put(w, 3072, r)
        return writing(o, w, r, get(w, 3112), get(w, 3120), 1601)
    if phase == 1601:
        return call(o, w, 1602, 8, get(w, 3072), get(w, 3120), 0, 0, 0, 0, 0)
    if phase == 1602 or phase == 1603:
        if phase == 1602 and r != get(w, 3120):
            return finish(o, w, 74)
        if phase == 1603:
            put(w, 3104, get(w, 3104) + 1)
        if get(w, 3104) == get(w, 3096):
            return call(o, w, 1604, 72, get(w, 3072), 1033, 15, 0, 0, 0, 0)
        row = get(w, 3088) + get(w, 3104) * 24
        if get(w, row) < 3 or get(w, row + 16) > 67108864 or get(w, 3128) > 67108864 - get(w, row + 16):
            return finish(o, w, 65)
        if get(w, 3136) != 0:
            if get(w, 3128) + get(w, row + 16) > 67108856:
                return finish(o, w, 65)
            put(w, 6144, get(w, row + 16))
            return writing_at(o, w, get(w, 3072), 6144, 8, get(w, 3128), 1605)
        put(w, 3128, get(w, 3128) + get(w, row + 16))
        return copying(o, w, get(w, row), get(w, 3072), get(w, row + 8), get(w, row + 16), 1603)
    if phase == 1605:
        put(w, 3128, get(w, 3128) + 8)
        return call(o, w, 1606, 8, get(w, 3072), get(w, 3128), 0, 0, 0, 0, 0)
    if phase == 1606:
        if r != get(w, 3128):
            return finish(o, w, 74)
        row = get(w, 3088) + get(w, 3104) * 24
        put(w, 3128, get(w, 3128) + get(w, row + 16))
        return copying(o, w, get(w, row), get(w, 3072), get(w, row + 8), get(w, row + 16), 1603)
    if phase == 1604:
        put(w, 144, get(w, 3072))
        put(w, 152, get(w, 3128))
        return resume(s, o, w, get(w, 3080))
    return finish(o, w, 65)

def view(w:mutbuf, index:u64, file:u64, offset:u64, size:u64) -> u64:
    put(w, 330000 + index * 24, file)
    put(w, 330008 + index * 24, offset)
    put(w, 330016 + index * 24, size)
    return 0

def compiler_manifest(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 2000:
        if get(w, 1112) < 3 or get(w, 1128) == 0:
            return finish(o, w, 65)
        return capture_request(o, w, capture_kit(s, w, 601560, 30, 601600, 26, 3544425580512495944), 2001)
    if phase == 2001:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 2002)
    if phase == 2002:
        put(w, 1176, get(w, 144))
        return call(o, w, 2003, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 2003:
        return call(o, w, 2004, 32, get(w, 320064), 0, 0, 0, 0, 0, 0)
    if phase == 2004:
        if r < 3:
            return finish(o, w, 74)
        return launch(o, w, get(w, 216), r, 4, 0, 2005)
    if phase == 2005:
        if get(w, 152) > 1048576:
            return finish(o, w, 65)
        put(w, 1160, get(w, 144))
        put(w, 1168, get(w, 152))
        if manifest_views(s, w) == 0:
            return finish(o, w, 65)
        return frame(o, w, 6144, 80, 330000, 9, 2006)
    if phase == 2006:
        return launch(o, w, get(w, 1176), get(w, 144), 3, 0, 2007)
    if phase == 2007:
        return publish(o, w, get(w, 144), get(w, 152), 601640, 22, 256, 2008)
    if phase == 2008:
        put(w, 1560500, 0)
        return resume(s, o, w, 2010)
    if phase == 2010:
        index = get(w, 1560500)
        if index < get(w, 104):
            put(w, 1560500, index + 1)
            fd = get(w, 290816 + index * 8)
            put(w, 290816 + index * 8, 0)
            if fd >= 3:
                return call(o, w, 2010, 3, fd, 0, 0, 0, 0, 0, 0)
            return resume(s, o, w, 2010)
        return call(o, w, 2011, 3, get(w, 128), 0, 0, 0, 0, 0, 0)
    if phase == 2011:
        return call(o, w, 2012, 3, get(w, 1176), 0, 0, 0, 0, 0, 0)
    if phase == 2012:
        return call(o, w, 2013, 3, get(w, 1160), 0, 0, 0, 0, 0, 0)
    if phase == 2013:
        return call(o, w, 2014, 3, get(w, 1112), 0, 0, 0, 0, 0, 0)
    if phase == 2014:
        put(w, 1519984, 0)
        put(w, 1599904, 0)
        return resume(s, o, w, 5000)
    return finish(o, w, 65)

def final_frame(s:readbuf, w:mutbuf) -> u64:
    finalizer = find_product(w, 600840, 20)
    packer = find_product(w, 600640, 27)
    installer = find_product(w, 600872, 11)
    artifact = find_product(w, 600728, 12)
    if finalizer == 0 or packer == 0 or installer == 0 or artifact == 0:
        return 0
    put(w, 1530080, get(w, finalizer))
    put(w, 1530000, uint(s, 32))
    put(w, 1530008, uint(s, 40))
    put(w, 1530016, uint(s, 88))
    put(w, 1530024, uint(s, 96))
    put(w, 1530032, get(w, 232))
    put(w, 1530040, get(w, packer))
    put(w, 1530048, get(w, 216))
    put(w, 1530056, get(w, installer))
    put(w, 1530064, get(w, artifact))
    put(w, 6144, 3544418983358843208)
    put(w, 6152, 0)
    put(w, 6160, uint(s, 16))
    i = 0
    while i < 9:
        put(w, 6168 + i * 8, get(w, 1530000 + i * 8))
        i = i + 1
    put(w, 6240, uint(s, 104))
    put(w, 6248, get(w, 256))
    put(w, 6256, 64)
    put(w, 6264, 0)
    copy(s, w, 6272, 288, uint(s, 104))
    i = 0
    while i < 32:
        ch = byte(s, 128 + i)
        store(w, 6272 + uint(s, 104) + i * 2, hex_digit(ch >> 4))
        store(w, 6273 + uint(s, 104) + i * 2, hex_digit(ch & 15))
        i = i + 1
    return 1

def manifest_views(s:readbuf, w:mutbuf) -> u64:
    view(w, 0, uint(s, 80), 0, get(w, 3032))
    view(w, 1, uint(s, 72), 0, get(w, 3024))
    core = find_product(w, 600704, 13)
    if core == 0:
        return 0
    view(w, 2, get(w, core), 0, get(w, core + 8))
    view(w, 3, get(w, 1112), get(w, 1120), get(w, 1128))
    view(w, 4, get(w, 1160), 0, get(w, 1168))
    view(w, 5, get(w, 320096), 0, get(w, 320104))
    view(w, 6, get(w, 320064), 0, get(w, 320072))
    view(w, 7, get(w, 320080), 0, get(w, 320088))
    view(w, 8, get(w, 320000), 0, get(w, 320008))
    put(w, 6144, 3544410204395358536)
    i = 0
    while i < 9:
        put(w, 6152 + i * 8, get(w, 330016 + i * 24))
        i = i + 1
    return 1

def find_product(w:mutbuf, name:u64, size:u64) -> u64:
    i = 0
    while i < get(w, 104):
        at = 294912 + i * 32
        if get(w, at + 24) == size and same(w, get(w, at + 16), name, size) == 1:
            return at
        i = i + 1
    return 0

def member_binding(w:mutbuf) -> u64:
    i = 0
    while i < 7:
        at = 605112 + i * 64
        if get(w, at + 8) == get(w, 184) and same(w, get(w, at), get(w, 176), get(w, 184)) == 1:
            return at
        i = i + 1
    return 0

def binding_check(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if phase == 1215:
        put(w, 321016, get(w, 144))
        put(w, 321024, get(w, 152))
        row = get(w, 321008)
        return capture_request(o, w, capture_one(s, w, get(w, row + 16), get(w, row + 24), 600592, 4, 3544428844805081416), 1216)
    if phase == 1216:
        put(w, 321032, get(w, 144))
        put(w, 321040, get(w, 152))
        row = get(w, 321008)
        return seal_buffer(o, w, get(w, row + 48), get(w, row + 56), 1217)
    if phase == 1217:
        put(w, 321048, get(w, 144))
        put(w, 321056, get(w, 152))
        row = get(w, 321008)
        if get(w, row + 40) == 2:
            return seal_buffer(o, w, 601672, get(w, row + 32) * 8, 1218)
        return binding_check(s, o, w, 1219, 0)
    if phase == 1218:
        put(w, 321064, get(w, 144))
        put(w, 321072, get(w, 152))
        return binding_check(s, o, w, 1219, 0)
    if phase == 1219:
        if binding_views(w) == 0:
            return finish(o, w, 65)
        return framed(o, w, 6144, 40, 330000, get(w, 6168), 1220)
    if phase == 1220:
        return launch(o, w, get(w, 321000), get(w, 144), 3, 0, 1221)
    if phase == 1221:
        if get(w, 152) != 32:
            return finish(o, w, 65)
        return reading(o, w, get(w, 144), 49152, 32, 0, 1222)
    if phase == 1222:
        row = get(w, 321008)
        if get(w, 49152) != 3552019954704402760 or get(w, 49160) != get(w, row + 40) or get(w, 49168) != get(w, row + 32) or get(w, 49176) != get(w, 321088):
            return finish(o, w, 65)
        return call(o, w, 1223, 3, get(w, 144), 0, 0, 0, 0, 0, 0)
    if phase == 1223:
        return call(o, w, 1224, 3, get(w, 321016), 0, 0, 0, 0, 0, 0)
    if phase == 1224:
        return call(o, w, 1225, 3, get(w, 321032), 0, 0, 0, 0, 0, 0)
    if phase == 1225:
        return call(o, w, 1226, 3, get(w, 321048), 0, 0, 0, 0, 0, 0)
    if phase == 1226:
        if get(w, get(w, 321008) + 40) == 2:
            return call(o, w, 1227, 3, get(w, 321064), 0, 0, 0, 0, 0, 0)
        return binding_check(s, o, w, 1227, 0)
    if phase == 1227:
        put(w, 144, get(w, 321080))
        put(w, 152, get(w, 321088))
        return publish(o, w, get(w, 144), get(w, 152), get(w, 176), get(w, 184), 320, 1212)
    return finish(o, w, 65)

def binding_views(w:mutbuf) -> u64:
    row = get(w, 321008)
    mode = get(w, row + 40)
    calls = get(w, row + 32)
    if calls == 0 or calls != get(w, 1000):
        return 0
    put(w, 6144, 3544406936193681736)
    put(w, 6152, mode)
    put(w, 6160, calls)
    put(w, 6168, choose(mode == 2, 6, 4 + calls))
    put(w, 6176, 0)
    view(w, 0, get(w, 321080), 0, get(w, 321088))
    if mode == 2:
        view(w, 1, get(w, 992), get(w, 160), get(w, 546824))
        view(w, 2, get(w, 321016), 0, get(w, 321024))
        view(w, 3, get(w, 321032), 0, get(w, 321040))
        view(w, 4, get(w, 321064), 0, get(w, 321072))
        view(w, 5, get(w, 321048), 0, get(w, 321056))
    else:
        view(w, 1, get(w, 321016), 0, get(w, 321024))
        view(w, 2, get(w, 321032), 0, get(w, 321040))
        view(w, 3, get(w, 321048), 0, get(w, 321056))
        i = 0
        at = get(w, 160)
        while i < calls:
            view(w, 4 + i, get(w, 992), at, get(w, 546824 + i * 8))
            at = at + get(w, 546824 + i * 8)
            i = i + 1
    return 1

def resume(s:readbuf, o:mutbuf, w:mutbuf, phase:u64) -> u32:
    put(w, 0, phase)
    put(w, 8, 0)
    return 4

def sha(o:mutbuf, w:mutbuf, phase:u64, operation:u64, count:u64) -> u32:
    store(w, 65536, operation)
    put(w, 0, phase)
    put(o, 0, count)
    return 3

def call(o:mutbuf, w:mutbuf, phase:u64, number:u64, a:u64, b:u64, c:u64, d:u64, e:u64, f:u64, mask:u64) -> u32:
    put(w, 0, phase)
    put(o, 0, number)
    put(o, 8, a)
    put(o, 16, b)
    put(o, 24, c)
    put(o, 32, d)
    put(o, 40, e)
    put(o, 48, f)
    put(o, 56, mask)
    return 1

def finish(o:mutbuf, w:mutbuf, code:u64) -> u32:
    return call(o, w, 99999, 60, code, 0, 0, 0, 0, 0, 0)

def minimum(a:u64, b:u64) -> u64:
    return choose(a < b, a, b)

def arg(w:mutbuf, at:u64, source:u64, count:u64) -> u64:
    put(w, at, count)
    copyw(w, at + 8, source, count)
    store(w, at + 8 + count, 0)
    return at + 9 + count

def decimal(w:mutbuf, at:u64, value:u64) -> u64:
    factor = 1
    while divide(value, factor) >= 10:
        factor = factor * 10
    while factor != 0:
        digit = divide(value, factor)
        store(w, at, 48 + digit)
        value = value - digit * factor
        factor = divide(factor, 10)
        at = at + 1
    return at

def divide(value:u64, divisor:u64) -> u64:
    bit = 1
    quotient = 0
    while divisor <= (value >> 1):
        divisor = divisor << 1
        bit = bit << 1
    while bit != 0:
        if value >= divisor:
            value = value - divisor
            quotient = quotient | bit
        divisor = divisor >> 1
        bit = bit >> 1
    return quotient

def same(w:mutbuf, a:u64, b:u64, count:u64) -> u64:
    i = 0
    while i < count:
        if byte(w, a + i) != byte(w, b + i):
            return 0
        i = i + 1
    return 1

def same_input(s:readbuf, w:mutbuf, a:u64, b:u64, count:u64) -> u64:
    i = 0
    while i < count:
        if byte(s, a + i) != byte(w, b + i):
            return 0
        i = i + 1
    return 1

def copy(s:readbuf, w:mutbuf, target:u64, source:u64, count:u64) -> u64:
    i = 0
    while i < count:
        store(w, target + i, byte(s, source + i))
        i = i + 1
    return 0

def copyw(w:mutbuf, target:u64, source:u64, count:u64) -> u64:
    i = 0
    while i < count:
        store(w, target + i, byte(w, source + i))
        i = i + 1
    return 0

def failed(value:u64) -> bool:
    return value >> 63 != 0

def uint(s:readbuf, at:u64) -> u64:
    i = 0
    value = 0
    while i < 8:
        value = value | (byte(s, at + i) << (i * 8))
        i = i + 1
    return value

def get(w:mutbuf, at:u64) -> u64:
    return getn(w, at, 8)

def getn(w:mutbuf, at:u64, count:u64) -> u64:
    i = 0
    value = 0
    while i < count:
        value = value | (byte(w, at + i) << (i * 8))
        i = i + 1
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(w, at + i, (value >> (i * 8)) & 255)
        i = i + 1
    return 0

def worker_options(s:readbuf, w:mutbuf, at:u64) -> u64:
    if at > length(s) or length(s) - at < 72 or uint(s, at) != 3544421208437115208:
        return 0
    fd = uint(s, at + 8)
    size = uint(s, at + 16)
    if fd < 3 or fd > 2147483647 or uint(s, at + 24) > 1 or size < 8 or size > 131304 or at + 64 + size + choose(uint(s, at + 24) == 1, 48, 0) != length(s):
        return 0
    i = 0
    while i < 10:
        if fd == uint(s, 24 + i * 8):
            return 0
        i = i + 1
    roots = at + 64
    count = uint(s, roots)
    if count > 32:
        return 0
    end = roots + size
    cursor = roots + 8
    i = 0
    while i < count:
        if cursor > end or end - cursor < 8:
            return 0
        n = uint(s, cursor)
        cursor = cursor + 8
        if n == 0 or n > 4095 or n > end - cursor:
            return 0
        if worker_utf8(s, cursor, n) == 0:
            return 0
        cursor = cursor + n
        i = i + 1
    if cursor != end:
        return 0
    put(w, 1800616, uint(s, at + 24))
    if uint(s, at + 24) == 1:
        config = uint(s, end + 8)
        if uint(s, end) != 3544410161781229896 or config < 3 or config > 2147483647 or config == fd:
            return 0
        i = 0
        while i < 10:
            if config == uint(s, 24 + i * 8):
                return 0
            i = i + 1
        put(w, 1800600, config)
        put(w, 1800624, end + 16)
    put(w, 1800008, at)
    put(w, 1800016, fd)
    return 1

def worker_utf8(s:readbuf, at:u64, size:u64) -> u64:
    i = 0
    while i < size:
        c = byte(s, at + i)
        if c == 0:
            return 0
        if c < 128:
            i = i + 1
        else:
            n = 0
            if c >= 194 and c <= 223:
                n = 1
            elif c >= 224 and c <= 239:
                n = 2
            elif c >= 240 and c <= 244:
                n = 3
            if n == 0 or n >= size - i:
                return 0
            second = byte(s, at + i + 1)
            if (c == 224 and second < 160) or (c == 237 and second > 159) or (c == 240 and second < 144) or (c == 244 and second > 143):
                return 0
            j = 1
            while j <= n:
                value = byte(s, at + i + j)
                if value < 128 or value > 191:
                    return 0
                j = j + 1
            i = i + n + 1
    return 1

def worker_operation_arg(w:mutbuf, at:u64, operation:u64) -> u64:
    at = arg(w, at, choose(operation == 32, 1808056, 1808072), choose(operation == 32, 7, 6))
    copyw(w, 62000, 1808040, 3)
    size = decimal(w, 62003, get(w, 1800200))
    at = arg(w, at, 62000, size - 62000)
    return arg(w, at, 1800064, 64)

def worker_memory_limit(w:mutbuf) -> u64:
    if get(w, 1800656) >= 3:
        if get(w, 520) == get(w, 1800656):
            return 0
    return 2147483648

def worker_result(s:readbuf, o:mutbuf, w:mutbuf, phase:u64, r:u64) -> u32:
    if failed(r):
        return finish(o, w, 74)
    if phase == 7810:
        copy(s, w, 1980000, 288, uint(s, 104))
        store(w, 1980000 + uint(s, 104), 0)
        return call(o, w, 7811, 262, uint(s, 88), 1980000, 1200, 256, 0, 0, 60)
    if phase == 7811:
        if same(w, 1200, 2624, 16) == 0 or getn(w, 1224, 4) & 61440 != 16384:
            return finish(o, w, 65)
        return capture_request(o, w, capture_kit(s, w, 1808344, 32, 600296, 25, 3544425580512495944), 7812)
    if phase == 7812:
        return launch(o, w, get(w, 120), get(w, 144), 3, 0, 7813)
    if phase == 7813:
        put(w, 1832000, get(w, 144))
        return call(o, w, 7814, 91, get(w, 144), 320, 0, 0, 0, 0, 0)
    if phase == 7814:
        copyw(w, 1985000, 1808240, 14)
        end = decimal(w, 1985000 + 14, uint(s, 96))
        store(w, end, 0)
        return call(o, w, 7815, 89, 1985000, 1990000, 4096, 0, 0, 0, 15)
    if phase == 7815:
        if r < 2 or r > 4095 or byte(w, 1990000) != 47:
            return finish(o, w, 65)
        return seal_buffer(o, w, 1990000, r, 7816)
    if phase == 7816:
        put(w, 1832008, get(w, 144))
        put(w, 1832016, get(w, 152))
        put(w, 6144, get(w, 1800616))
        return seal_buffer(o, w, 6144, 8, 7817)
    if phase == 7817:
        put(w, 1832024, get(w, 144))
        view(w, 0, get(w, 1832008), 0, get(w, 1832016))
        i = 0
        while i < 9:
            if worker_result_view(w, i) == 0:
                return finish(o, w, 65)
            i = i + 1
        view(w, 10, get(w, 1800800), 0, 96)
        view(w, 11, get(w, 1832024), 0, 8)
        put(w, 6144, 3544405789504522568)
        put(w, 6152, 8)
        put(w, 6160, 0)
        put(w, 6168, 12)
        return framed(o, w, 6144, 32, 330000, 12, 7818)
    if phase == 7818:
        return launch(o, w, get(w, 1832000), get(w, 144), 3, 0, 7819)
    if phase == 7819:
        if get(w, 152) < 2 or get(w, 152) > 262144:
            return finish(o, w, 65)
        return copying(o, w, get(w, 144), 1, 0, get(w, 152), 7820)
    if phase == 7820:
        return finish(o, w, 0)
    return finish(o, w, 65)

def worker_result_view(w:mutbuf, index:u64) -> u64:
    entry = 1812800 + index * 16
    name = get(w, entry)
    size = get(w, entry + 8)
    i = 0
    while i < get(w, 1599904):
        row = 1600000 + i * 160
        if get(w, row + 16) == size and same(w, row + 32, name, size) == 1:
            view(w, index + 1, get(w, row), 0, get(w, row + 8))
            return 1
        i = i + 1
    return 0

def constants(w:mutbuf) -> u64:
    put(w, 600000, 0)
    put(w, 600016, 46)
    put(w, 600032, 7308327836377508200)
    put(w, 600040, 7308910564655592289)
    put(w, 600048, 114)
    put(w, 600064, 8098164217508620648)
    put(w, 600072, 126939459448690)
    put(w, 600088, 7308327836377508200)
    put(w, 600096, 7811889803823510369)
    put(w, 600104, 100)
    put(w, 600120, 263206486352)
    put(w, 600136, 32481100118191987)
    put(w, 600152, 1801675120)
    put(w, 600168, 431315580258)
    put(w, 600184, 28548172761362275)
    put(w, 600200, 7310238724270485551)
    put(w, 600208, 52108257617516)
    put(w, 600224, 8315171517136730213)
    put(w, 600232, 8029744822420596783)
    put(w, 600240, 13352887739773812)
    put(w, 600256, 7088495816300916595)
    put(w, 600264, 7813587433520130421)
    put(w, 600272, 8390317603921945449)
    put(w, 600280, 97)
    put(w, 600296, 7088495816300916595)
    put(w, 600304, 7161128437504829813)
    put(w, 600312, 8390317603921487211)
    put(w, 600320, 97)
    put(w, 600336, 8391173024907027827)
    put(w, 600344, 107152729794606)
    put(w, 600360, 8241417320907763571)
    put(w, 600368, 7737014231075482725)
    put(w, 600376, 7022361299819328617)
    put(w, 600384, 0)
    put(w, 600400, 8241417320907763571)
    put(w, 600408, 7881129419151338597)
    put(w, 600416, 7813850298419670373)
    put(w, 600424, 7022361299819327073)
    put(w, 600432, 0)
    put(w, 600448, 7376726192452628339)
    put(w, 600456, 7308602715225222249)
    put(w, 600464, 8098994053592736365)
    put(w, 600472, 24948)
    put(w, 600488, 8241417320907763571)
    put(w, 600496, 8313474983378906213)
    put(w, 600504, 7020109474189238644)
    put(w, 600512, 27431098827419246)
    put(w, 600528, 8315171517136730213)
    put(w, 600536, 8029744822420596783)
    put(w, 600544, 8227918608063558516)
    put(w, 600552, 7881129419151338597)
    put(w, 600560, 8030867505463586149)
    put(w, 600568, 8319325484817281653)
    put(w, 600576, 118)
    put(w, 600592, 1635017060)
    put(w, 600608, 8247620833072212328)
    put(w, 600616, 7236274654156776803)
    put(w, 600624, 0)
    put(w, 600640, 7310021024154741096)
    put(w, 600648, 7021161818704802915)
    put(w, 600656, 8458372963704597347)
    put(w, 600664, 6581353)
    put(w, 600680, 7742373267056453992)
    put(w, 600688, 32776920247399013)
    put(w, 600704, 7310027616929540456)
    put(w, 600712, 474316237357)
    put(w, 600728, 7598824232979622248)
    put(w, 600736, 1952670054)
    put(w, 600752, 8391173024907027827)
    put(w, 600760, 7074703559336225070)
    put(w, 600768, 28265)
    put(w, 600784, 7020378893159968045)
    put(w, 600792, 0)
    put(w, 600808, 7595371767660569960)
    put(w, 600816, 7021788497383009889)
    put(w, 600824, 829828717)
    put(w, 600840, 7308327836377508200)
    put(w, 600848, 7020664756686386017)
    put(w, 600856, 1702521196)
    put(w, 600872, 7308327836377508200)
    put(w, 600880, 6648673)
    put(w, 600896, 8241417320907763571)
    put(w, 600904, 7160553478772059237)
    put(w, 600912, 7596838515818916975)
    put(w, 600920, 27431098827419252)
    put(w, 600936, 7308327836377508200)
    put(w, 600944, 7236281173031613281)
    put(w, 600952, 127996155683117)
    put(w, 600968, 12777851748446067)
    put(w, 600984, 7308327836377508200)
    put(w, 600992, 7308910564655592289)
    put(w, 601000, 114)
    put(w, 601016, 8247620833072212328)
    put(w, 601024, 8463513163314062691)
    put(w, 601032, 25970)
    put(w, 601048, 7308327836377508200)
    put(w, 601056, 7811904093179704161)
    put(w, 601064, 100)
    put(w, 601080, 7308327836377508200)
    put(w, 601088, 7811904093179704161)
    put(w, 601096, 27431098827419236)
    put(w, 601112, 6874027268401554802)
    put(w, 601120, 7954869201740068194)
    put(w, 601128, 8390317603921949300)
    put(w, 601136, 97)
    put(w, 601152, 6874027268401554802)
    put(w, 601160, 7954869201740068194)
    put(w, 601168, 7738135720018670196)
    put(w, 601176, 7022361299819328101)
    put(w, 601184, 0)
    put(w, 601200, 6874027268401554802)
    put(w, 601208, 7954869201740068194)
    put(w, 601216, 7236837522460471924)
    put(w, 601224, 107152729794606)
    put(w, 601240, 8313423039255636083)
    put(w, 601248, 7307141442728981108)
    put(w, 601256, 6386800)
    put(w, 601272, 7742373267056453992)
    put(w, 601280, 7022364637025628773)
    put(w, 601288, 8243116152216972396)
    put(w, 601296, 0)
    put(w, 601312, 7742373267056453992)
    put(w, 601320, 7022364637025628773)
    put(w, 601328, 27756)
    put(w, 601344, 7742373267056453992)
    put(w, 601352, 7022364637025628773)
    put(w, 601360, 7022361299819326572)
    put(w, 601368, 0)
    put(w, 601384, 7592913276689870711)
    put(w, 601392, 7304676333365523310)
    put(w, 601400, 8098994053711033454)
    put(w, 601408, 24948)
    put(w, 601424, 7592913276689870711)
    put(w, 601432, 7304676333365523310)
    put(w, 601440, 7161128437857547374)
    put(w, 601448, 8390317603921487211)
    put(w, 601456, 97)
    put(w, 601472, 7592913276689870711)
    put(w, 601480, 7304676333365523310)
    put(w, 601488, 7955998378925651054)
    put(w, 601496, 27431098827419236)
    put(w, 601512, 4704370654401752932)
    put(w, 601520, 6003096295072682847)
    put(w, 601528, 6007596647754981204)
    put(w, 601536, 7651145529443766357)
    put(w, 601544, 7237491)
    put(w, 601560, 7160553410338844531)
    put(w, 601568, 6877671097248017775)
    put(w, 601576, 8391162021251277165)
    put(w, 601584, 107152729794606)
    put(w, 601600, 8030879518488162147)
    put(w, 601608, 7021216725465259886)
    put(w, 601616, 8098994053592738659)
    put(w, 601624, 24948)
    put(w, 601640, 8243113893085146979)
    put(w, 601648, 8315164890018966829)
    put(w, 601656, 121424956763764)
    put(w, 601672, 0)
    put(w, 601680, 0)
    put(w, 601688, 0)
    put(w, 601696, 0)
    put(w, 601704, 0)
    put(w, 601712, 0)
    put(w, 601720, 0)
    put(w, 601728, 0)
    put(w, 601736, 0)
    put(w, 601744, 0)
    put(w, 601752, 0)
    put(w, 601760, 0)
    put(w, 601768, 0)
    put(w, 601776, 0)
    put(w, 601784, 0)
    put(w, 601792, 0)
    put(w, 601800, 0)
    put(w, 601808, 0)
    put(w, 601816, 0)
    put(w, 601824, 0)
    put(w, 601832, 0)
    put(w, 601840, 0)
    put(w, 601848, 0)
    put(w, 601856, 0)
    put(w, 601864, 0)
    put(w, 601872, 0)
    put(w, 601880, 0)
    put(w, 601888, 0)
    put(w, 601896, 0)
    put(w, 601904, 0)
    put(w, 601912, 0)
    put(w, 601920, 0)
    put(w, 601928, 0)
    put(w, 601936, 0)
    put(w, 601944, 0)
    put(w, 601952, 0)
    put(w, 601960, 0)
    put(w, 601968, 0)
    put(w, 601976, 0)
    put(w, 601984, 0)
    put(w, 601992, 0)
    put(w, 602000, 0)
    put(w, 602008, 0)
    put(w, 602016, 0)
    put(w, 602024, 0)
    put(w, 602032, 0)
    put(w, 602040, 0)
    put(w, 602048, 0)
    put(w, 602056, 0)
    put(w, 602064, 0)
    put(w, 602072, 0)
    put(w, 602080, 0)
    put(w, 602088, 0)
    put(w, 602096, 0)
    put(w, 602104, 0)
    put(w, 602112, 0)
    put(w, 602120, 0)
    put(w, 602128, 0)
    put(w, 602136, 0)
    put(w, 602144, 0)
    put(w, 602152, 0)
    put(w, 602160, 0)
    put(w, 602168, 0)
    put(w, 602176, 0)
    put(w, 602184, 0)
    put(w, 602192, 0)
    put(w, 602200, 0)
    put(w, 602208, 0)
    put(w, 602216, 0)
    put(w, 602224, 0)
    put(w, 602232, 0)
    put(w, 602240, 0)
    put(w, 602248, 0)
    put(w, 602256, 0)
    put(w, 602264, 0)
    put(w, 602272, 0)
    put(w, 602280, 0)
    put(w, 602288, 0)
    put(w, 602296, 0)
    put(w, 602304, 0)
    put(w, 602312, 0)
    put(w, 602320, 0)
    put(w, 602328, 0)
    put(w, 602336, 0)
    put(w, 602344, 0)
    put(w, 602352, 0)
    put(w, 602360, 0)
    put(w, 602368, 0)
    put(w, 602376, 0)
    put(w, 602384, 0)
    put(w, 602392, 0)
    put(w, 602400, 0)
    put(w, 602408, 0)
    put(w, 602416, 0)
    put(w, 602424, 0)
    put(w, 602432, 0)
    put(w, 602440, 0)
    put(w, 602448, 0)
    put(w, 602456, 0)
    put(w, 602464, 0)
    put(w, 602472, 0)
    put(w, 602480, 0)
    put(w, 602488, 0)
    put(w, 602496, 0)
    put(w, 602504, 0)
    put(w, 602512, 0)
    put(w, 602520, 0)
    put(w, 602528, 0)
    put(w, 602536, 0)
    put(w, 602544, 0)
    put(w, 602552, 0)
    put(w, 602560, 0)
    put(w, 602568, 0)
    put(w, 602576, 0)
    put(w, 602584, 0)
    put(w, 602592, 0)
    put(w, 602600, 0)
    put(w, 602608, 0)
    put(w, 602616, 0)
    put(w, 602624, 0)
    put(w, 602632, 0)
    put(w, 602640, 0)
    put(w, 602648, 0)
    put(w, 602656, 0)
    put(w, 602664, 0)
    put(w, 602672, 0)
    put(w, 602680, 0)
    put(w, 602688, 0)
    put(w, 602696, 0)
    put(w, 602712, 8315171517136730213)
    put(w, 602720, 8029744822420596783)
    put(w, 602728, 8299976202101486452)
    put(w, 602736, 3347427345373228133)
    put(w, 602744, 418565350760)
    put(w, 602760, 8391173024907027827)
    put(w, 602768, 107152729794606)
    put(w, 602784, 8315171517136730213)
    put(w, 602792, 8029744822420596783)
    put(w, 602800, 8299976202101486452)
    put(w, 602808, 8458427939219993967)
    put(w, 602816, 7738135720017292393)
    put(w, 602824, 7022361299819328101)
    put(w, 602832, 0)
    put(w, 602848, 7088495816300916595)
    put(w, 602856, 7161128437504829813)
    put(w, 602864, 8390317603921487211)
    put(w, 602872, 97)
    put(w, 602888, 8315171517136730213)
    put(w, 602896, 8029744822420596783)
    put(w, 602904, 8299976202101486452)
    put(w, 602912, 7594862710671701359)
    put(w, 602920, 7882826979490493548)
    put(w, 602928, 8390317603921487202)
    put(w, 602936, 97)
    put(w, 602952, 7376726192452628339)
    put(w, 602960, 7308602715225222249)
    put(w, 602968, 8098994053592736365)
    put(w, 602976, 24948)
    put(w, 602992, 8315171517136730213)
    put(w, 603000, 8029744822420596783)
    put(w, 603008, 8299976202101486452)
    put(w, 603016, 8458427939219993967)
    put(w, 603024, 7596569199894621289)
    put(w, 603032, 7022361299819329891)
    put(w, 603040, 0)
    put(w, 603056, 7088495816300916595)
    put(w, 603064, 7813587433520130421)
    put(w, 603072, 8390317603921945449)
    put(w, 603080, 97)
    put(w, 603096, 8315171517136730213)
    put(w, 603104, 8029744822420596783)
    put(w, 603112, 7147054697494639476)
    put(w, 603120, 7957705967291167343)
    put(w, 603128, 7161128437588714335)
    put(w, 603136, 8390317603921487211)
    put(w, 603144, 97)
    put(w, 603160, 8030879518488162147)
    put(w, 603168, 7021216725465259886)
    put(w, 603176, 8098994053592738659)
    put(w, 603184, 24948)
    put(w, 603200, 8315171517136730213)
    put(w, 603208, 8029744822420596783)
    put(w, 603216, 7147054697494639476)
    put(w, 603224, 7957705967291167343)
    put(w, 603232, 7954892334484842079)
    put(w, 603240, 27431098827419236)
    put(w, 603256, 8030879518488162147)
    put(w, 603264, 7310589520068894574)
    put(w, 603272, 7022361299819324526)
    put(w, 603280, 0)
    put(w, 603296, 4704370654401752932)
    put(w, 603304, 6003096295072682847)
    put(w, 603312, 6007596647754981204)
    put(w, 603320, 7651145529443766357)
    put(w, 603328, 7237491)
    put(w, 603344, 5065499905267681608)
    put(w, 603352, 5931033310985932616)
    put(w, 603360, 5931047540229365573)
    put(w, 603368, 121424956763732)
    put(w, 603384, 4704370654401752932)
    put(w, 603392, 5647325152892371295)
    put(w, 603400, 5716298578445030465)
    put(w, 603408, 5494765659648642127)
    put(w, 603416, 31084788931512143)
    put(w, 603432, 5639992454447974728)
    put(w, 603440, 4996261462835879764)
    put(w, 603448, 4702707217257682015)
    put(w, 603456, 8316510545700995412)
    put(w, 603464, 28271)
    put(w, 603480, 8315171517136730213)
    put(w, 603488, 8029744822420596783)
    put(w, 603496, 8227918608063558516)
    put(w, 603504, 8313474983378906213)
    put(w, 603512, 7377304518169944436)
    put(w, 603520, 7238537363308686949)
    put(w, 603528, 0)
    put(w, 603544, 8315171517136730213)
    put(w, 603552, 8029744822420596783)
    put(w, 603560, 8227918608063558516)
    put(w, 603568, 8313474983378906213)
    put(w, 603576, 7957688327961272692)
    put(w, 603584, 8245937413259687027)
    put(w, 603592, 28275536575424558)
    put(w, 603608, 8315171517136730213)
    put(w, 603616, 8029744822420596783)
    put(w, 603624, 8227918608063558516)
    put(w, 603632, 8313474983378906213)
    put(w, 603640, 8245918704112984436)
    put(w, 603648, 7238537363308686949)
    put(w, 603656, 0)
    put(w, 603672, 8315171517136730213)
    put(w, 603680, 8029744822420596783)
    put(w, 603688, 8227918608063558516)
    put(w, 603696, 8313474983378906213)
    put(w, 603704, 7234013963814920564)
    put(w, 603712, 3345155750172914793)
    put(w, 603720, 110451314747752)
    put(w, 603736, 8315171517136730213)
    put(w, 603744, 8029744822420596783)
    put(w, 603752, 8227918608063558516)
    put(w, 603760, 8313474983378906213)
    put(w, 603768, 7957688327961272692)
    put(w, 603776, 3346848989439816308)
    put(w, 603784, 110451314747752)
    put(w, 603800, 8315171517136730213)
    put(w, 603808, 8029744822420596783)
    put(w, 603816, 8227918608063558516)
    put(w, 603824, 8313474983378906213)
    put(w, 603832, 7959393670495953268)
    put(w, 603840, 7019256042713082228)
    put(w, 603848, 6583411)
    put(w, 603864, 8315171517136730213)
    put(w, 603872, 8029744822420596783)
    put(w, 603880, 8227918608063558516)
    put(w, 603888, 8313474983378906213)
    put(w, 603896, 8391726040583987572)
    put(w, 603904, 8314042283278561909)
    put(w, 603912, 25716)
    put(w, 603928, 8315171517136730213)
    put(w, 603936, 8029744822420596783)
    put(w, 603944, 8227918608063558516)
    put(w, 603952, 8313474983378906213)
    put(w, 603960, 7954877976240677236)
    put(w, 603968, 6876556179756118629)
    put(w, 603976, 7595371784822678892)
    put(w, 603984, 1685353313)
    put(w, 604000, 603480)
    put(w, 604008, 48)
    put(w, 604016, 603544)
    put(w, 604024, 55)
    put(w, 604032, 603608)
    put(w, 604040, 48)
    put(w, 604048, 603672)
    put(w, 604056, 54)
    put(w, 604064, 603736)
    put(w, 604072, 54)
    put(w, 604080, 603800)
    put(w, 604088, 51)
    put(w, 604096, 603864)
    put(w, 604104, 50)
    put(w, 604112, 603928)
    put(w, 604120, 60)
    put(w, 604128, 602712)
    put(w, 604136, 37)
    put(w, 604144, 602760)
    put(w, 604152, 14)
    put(w, 604160, 602784)
    put(w, 604168, 48)
    put(w, 604176, 602848)
    put(w, 604184, 25)
    put(w, 604192, 602888)
    put(w, 604200, 49)
    put(w, 604208, 602952)
    put(w, 604216, 26)
    put(w, 604224, 602992)
    put(w, 604232, 48)
    put(w, 604240, 603056)
    put(w, 604248, 25)
    put(w, 604256, 603096)
    put(w, 604264, 49)
    put(w, 604272, 603160)
    put(w, 604280, 26)
    put(w, 604288, 603200)
    put(w, 604296, 47)
    put(w, 604304, 603256)
    put(w, 604312, 24)
    put(w, 604320, 603296)
    put(w, 604328, 35)
    put(w, 604336, 603344)
    put(w, 604344, 30)
    put(w, 604352, 603384)
    put(w, 604360, 39)
    put(w, 604368, 603432)
    put(w, 604376, 34)
    put(w, 604384, 7954877983890696552)
    put(w, 604392, 3271974480785845620)
    put(w, 604400, 127996156276579)
    put(w, 604416, 7595372944347328372)
    put(w, 604424, 6878243912706776929)
    put(w, 604432, 8386654079495008884)
    put(w, 604440, 7449363297518645097)
    put(w, 604448, 7017579609837236837)
    put(w, 604456, 357261601900)
    put(w, 604472, 1)
    put(w, 604480, 488)
    put(w, 604488, 124928)
    put(w, 604496, 15204352)
    put(w, 604512, 7954877983890696552)
    put(w, 604520, 7234307542010244468)
    put(w, 604528, 32767016006804269)
    put(w, 604544, 7595372944347328372)
    put(w, 604552, 6878243912706776929)
    put(w, 604560, 8386654079495008884)
    put(w, 604568, 8388361637982007145)
    put(w, 604576, 7017579609837236837)
    put(w, 604584, 357261601900)
    put(w, 604600, 1)
    put(w, 604608, 232)
    put(w, 604624, 7954877983890696552)
    put(w, 604632, 3271146527375175028)
    put(w, 604640, 1953066601)
    put(w, 604656, 7595372944347328372)
    put(w, 604664, 6878243912706776929)
    put(w, 604672, 7955995106042934387)
    put(w, 604680, 7017579609837237353)
    put(w, 604688, 357261601900)
    put(w, 604704, 1)
    put(w, 604712, 232)
    put(w, 604728, 7310021024154741096)
    put(w, 604736, 30518463016301667)
    put(w, 604752, 7595372944347328372)
    put(w, 604760, 8386658473162858337)
    put(w, 604768, 8751443420190434143)
    put(w, 604776, 5993855063588692851)
    put(w, 604784, 0)
    put(w, 604800, 1)
    put(w, 604808, 232)
    put(w, 604824, 3270298781242976616)
    put(w, 604832, 32774695273325938)
    put(w, 604848, 7595372944347328372)
    put(w, 604856, 7310010021556412257)
    put(w, 604864, 8751443454617806179)
    put(w, 604872, 5993855063588692851)
    put(w, 604880, 0)
    put(w, 604896, 1)
    put(w, 604904, 232)
    put(w, 604920, 7306638986517244264)
    put(w, 604928, 7599592809694127474)
    put(w, 604936, 25970)
    put(w, 604952, 7595372944347328372)
    put(w, 604960, 8241987958600851297)
    put(w, 604968, 7954890096655037023)
    put(w, 604976, 7017579609837233507)
    put(w, 604984, 357261601900)
    put(w, 605000, 1)
    put(w, 605008, 232)
    put(w, 605024, 8098164217508620648)
    put(w, 605032, 126939459448690)
    put(w, 605048, 7595372944347328372)
    put(w, 605056, 8030604653734616929)
    put(w, 605064, 8320808640339731811)
    put(w, 605072, 23413496342143331)
    put(w, 605088, 1)
    put(w, 605096, 232)
    put(w, 605112, 604384)
    put(w, 605120, 22)
    put(w, 605128, 604416)
    put(w, 605136, 45)
    put(w, 605144, 3)
    put(w, 605152, 3)
    put(w, 605160, 604472)
    put(w, 605168, 27)
    put(w, 605176, 604512)
    put(w, 605184, 23)
    put(w, 605192, 604544)
    put(w, 605200, 45)
    put(w, 605208, 1)
    put(w, 605216, 3)
    put(w, 605224, 604600)
    put(w, 605232, 9)
    put(w, 605240, 604624)
    put(w, 605248, 20)
    put(w, 605256, 604656)
    put(w, 605264, 37)
    put(w, 605272, 1)
    put(w, 605280, 3)
    put(w, 605288, 604704)
    put(w, 605296, 9)
    put(w, 605304, 604728)
    put(w, 605312, 15)
    put(w, 605320, 604752)
    put(w, 605328, 32)
    put(w, 605336, 1)
    put(w, 605344, 2)
    put(w, 605352, 604800)
    put(w, 605360, 9)
    put(w, 605368, 604824)
    put(w, 605376, 15)
    put(w, 605384, 604848)
    put(w, 605392, 32)
    put(w, 605400, 1)
    put(w, 605408, 2)
    put(w, 605416, 604896)
    put(w, 605424, 9)
    put(w, 605432, 604920)
    put(w, 605440, 18)
    put(w, 605448, 604952)
    put(w, 605456, 37)
    put(w, 605464, 1)
    put(w, 605472, 2)
    put(w, 605480, 605000)
    put(w, 605488, 9)
    put(w, 605496, 605024)
    put(w, 605504, 14)
    put(w, 605512, 605048)
    put(w, 605520, 31)
    put(w, 605528, 1)
    put(w, 605536, 2)
    put(w, 605544, 605088)
    put(w, 605552, 9)
    return 0
