.intel_syntax noprefix
.text
.global check_df
check_df:
    push rbx
    mov rbx, [rsp+16]
    cld
    call rbx
    pushfq
    pop rax
    cld
    pop rbx
    ret
