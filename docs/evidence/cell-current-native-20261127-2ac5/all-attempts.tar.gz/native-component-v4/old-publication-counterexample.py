from pathlib import Path
from hashlib import sha256
import json,sys
from tools import build_hia_cell_bridge as build
from tests.hia_cell_native_fixture import development_build
root=Path.cwd()
out=Path(sys.argv[1])
compiler=Path(sys.argv[2])
names=("tools/build_hia_cell_bridge.py","tests/hia_cell_native_fixture.py",*build.NATIVE_INPUTS)
before={name:(root/name).read_bytes() for name in names}
pipeline=build._compile_pipeline
observed={}
def changed(*args,**kwargs):
    report=pipeline(*args,**kwargs)
    target=Path(report["image_path"])
    raw=target.read_bytes()
    assert sha256(raw).hexdigest()==report["image_sha256"]
    target.write_bytes(bytes([raw[0]^1])+raw[1:])
    observed.update({"before":sha256(raw).hexdigest(),"after":sha256(target.read_bytes()).hexdigest(),"native_calls":len(report["native_calls"])})
    return report
build._compile_pipeline=changed
try:
    report=development_build(root,out,compiler)
finally:
    build._compile_pipeline=pipeline
assert report["claims"]["development_only"] is True
assert report["claims"]["cold_compiler_admitted"] is False
assert report["image_sha256"]==observed["before"] and observed["before"]!=observed["after"]
assert observed["native_calls"]==5
assert all((root/name).read_bytes()==raw for name,raw in before.items())
result={"status":"OLD_DEVELOPMENT_PUBLICATION_COUNTEREXAMPLE_REPRODUCED","scope":"actual original five native calls; no cold admission was simulated","old_publisher_returned":True,"altered_image_after_final_pipeline_check_was_accepted":True,"original_report_image_sha256":report["image_sha256"],"actual_image_sha256":observed["after"],"native_calls":observed["native_calls"],"old_source_stable":True,"source":{name:{"bytes":len(raw),"sha256":sha256(raw).hexdigest()} for name,raw in before.items()},"native_cold_qualified":False}
(out/"counterexample.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
