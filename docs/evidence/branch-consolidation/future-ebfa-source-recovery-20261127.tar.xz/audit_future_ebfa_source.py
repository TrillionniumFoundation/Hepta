from pathlib import Path
import ast
import collections
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/589c0a6dd85b')
REPO = ROOT / 'hepta-managed-worker-alive-20261127-589c'
D = ROOT / 'hepta-future-ebfa-review-20261127'
OLD = 'ebfa9864b0c56cfb265dba4cd2e82083aead90ba'
CURRENT = '798316c5cf521340de06cdd969e2ada56fb8c386'
BASE = 'd118f47c189b3047b0457e7fca212e084ea1b93a'
D.mkdir(exist_ok=False)
sys.path.insert(0, str(REPO))


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def file_pin(path):
    return {'path': str(path), **pin(path.read_bytes())}


paths = git('diff', '--name-only', BASE, OLD).decode().splitlines()
rows = []
for path in paths:
    old = git('show', OLD + ':' + path)
    current = git('show', CURRENT + ':' + path)
    for name, raw in [('historical-ebfa', old), ('current-798', current)]:
        p = D / name / path
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
    row = {'path': path, 'historical': pin(old), 'current': pin(current), 'byte_identical': old == current,
           'old_blob': git('rev-parse', OLD + ':' + path).decode().strip(),
           'current_blob': git('rev-parse', CURRENT + ':' + path).decode().strip()}
    if path.startswith('tools/qualify_'):
        def assertions(raw):
            return collections.Counter(ast.dump(n, include_attributes=False) for n in ast.walk(ast.parse(raw)) if isinstance(n, ast.Assert))
        a, b = assertions(old), assertions(current)
        row.update(original_assertions=sum(a.values()), current_assertions=sum(b.values()),
                   assert_ast_multiset_identical=a == b, removed_assertions=list((a-b).elements()), added_assertions=list((b-a).elements()))
    rows.append(row)

author_names = ['background_optimizer_future_public_owner', 'background_optimizer_future_public_cleanup',
                'background_optimizer_future_public_carrier', 'multiversion_background_future_cell']
functions = []
for stem in author_names:
    path = 'tools/generate_hia_' + stem + '.py'
    bodies = []
    for label in ['historical-ebfa', 'current-798']:
        p = D / label / path
        spec = importlib.util.spec_from_file_location('review_' + label.replace('-', '_') + '_' + stem, p)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        tree = ast.parse(m.SOURCE)
        funcs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
        assert len(funcs) == len(tree.body)
        bodies.append(funcs)
    old, current = bodies
    functions.append({'path': path, 'old_functions': len(old), 'current_functions': len(current),
                      'removed': sorted(set(old)-set(current)), 'added': sorted(set(current)-set(old)),
                      'unchanged': sorted(n for n in old if n in current and ast.dump(old[n], include_attributes=False) == ast.dump(current[n], include_attributes=False)),
                      'changed': sorted(n for n in old if n in current and ast.dump(old[n], include_attributes=False) != ast.dump(current[n], include_attributes=False))})

for stem in ['background_optimizer_future_public_owner', 'background_optimizer_future_public_carrier', 'multiversion_background_future_cell']:
    path = 'tools/generate_hia_' + stem + '.py'
    p = D / 'baseline-d118' / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(git('show', BASE + ':' + path))

qualifiers = ['qualify_hia_future_drop_author_protocol', 'qualify_hia_future_cleanup_record_source',
              'qualify_hia_future_public_temporaries_source', 'qualify_hia_future_carrier_temporaries_source',
              'qualify_hia_future_cleanup_packer_source']
for path in [r['path'] for r in rows if r['path'].startswith('tools/')]:
    assert (REPO / path).read_bytes() == git('show', CURRENT + ':' + path), path

runs = []
for name in qualifiers:
    out = D / 'source-probes' / name
    out.mkdir(parents=True)
    command = [sys.executable, '-B', '-u', '-m', 'tools.' + name]
    if name == 'qualify_hia_future_drop_author_protocol':
        command += ['--source-root', str(REPO), '--baseline-root', str(D/'baseline-d118'),
                    '--dependency-root', str(REPO), '--output', str(out)]
    started = time.monotonic()
    timed_out = False
    try:
        result = subprocess.run(command, cwd=REPO, capture_output=True, timeout=60,
                                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'HEPTA_FUTURE_SOURCE_QA_OUTPUT': str(out)})
        stdout, stderr, rc = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, rc, timed_out = exc.stdout or b'', exc.stderr or b'', None, True
    (out/'original.stdout').write_bytes(stdout)
    (out/'original.stderr').write_bytes(stderr)
    row = {'name': name, 'command': command, 'returncode': rc, 'timeout_seconds': 60, 'timed_out': timed_out,
           'seconds': time.monotonic() - started, 'stdout': file_pin(out/'original.stdout'), 'stderr': file_pin(out/'original.stderr')}
    reports = []
    for p in out.glob('*.json'):
        data = json.loads(p.read_text())
        reports.append({'file': file_pin(p), 'schema': data.get('schema'), 'passed': data.get('passed'), 'checks': data.get('checks')})
    row['reports'] = reports
    runs.append(row)
    print(json.dumps(row), flush=True)

review = {'schema': 'hia.future-ebfa-current-source-audit.v1', 'historical_tip': OLD, 'baseline': BASE,
          'canonical': CURRENT, 'source_test_worktree': str(REPO), 'source_test_worktree_commit': git('rev-parse', 'HEAD').decode().strip(),
          'historical_unique_commits': git('rev-list', CURRENT+'..'+OLD).decode().splitlines(),
          'all_historical_paths': rows, 'author_function_inventory': functions, 'source_probe_runs': runs,
          'source_probe_passed': all(r['returncode'] == 0 for r in runs),
          'native_qualification_performed': False, 'whole_future_closed': False, 'whole_background_closed': False,
          'scope': 'Exact historical/current source custody and original independent modeled probes only; no new native construction, fault injection or concurrency claim.'}
(D/'source-review.json').write_text(json.dumps(review, indent=2)+'\n')
print(json.dumps({'receipt': str(D/'source-review.json'), 'passed': review['source_probe_passed'],
                  'paths': len(rows), 'same': sum(r['byte_identical'] for r in rows),
                  'assertions': sum(r.get('original_assertions',0) for r in rows),
                  'functions': [{'path': x['path'], 'old': x['old_functions'], 'new': x['current_functions'], 'removed': x['removed']} for x in functions]}), flush=True)
