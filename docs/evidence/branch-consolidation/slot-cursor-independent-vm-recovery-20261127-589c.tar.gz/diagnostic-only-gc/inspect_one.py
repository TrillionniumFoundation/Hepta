from pathlib import Path
import sys,json,gc,types,hashlib,collections
root=Path(sys.argv[1]);backend_name=sys.argv[2];output=Path(sys.argv[3]);output.mkdir(exist_ok=False)
sys.path.insert(0,str(root))
from tests import hia_slot_operations_observer as driver
oracle=root/'tests/fixtures/hia_slot_operations_original_r1'
namespace=driver.load_observer(oracle)
backend=driver.prepare_backend(root,backend_name,None)
namespace['load_originals'](oracle)
if backend is not None:driver.bind_actual_public(namespace,backend)
cases=json.loads((oracle/'cases.json').read_bytes())['cases']
case=next(x for x in cases if x['id']=='variant.retained-traceback-lookup-release.outer0')
world=namespace['World'](case)
before=gc.collect()
old_debug=gc.get_debug();gc.set_debug(old_debug|gc.DEBUG_SAVEALL)
try:record,raw=world.observe()
finally:gc.set_debug(old_debug)
garbage=list(gc.garbage)
rows=[]
for obj in garbage:
 typ=type(obj); row={'id':id(obj),'type':typ.__module__+'.'+typ.__qualname__,'referents':[{'id':id(x),'type':type(x).__module__+'.'+type(x).__qualname__} for x in gc.get_referents(obj)]}
 if typ is types.FrameType:row.update(code=obj.f_code.co_name,file=obj.f_code.co_filename,line=obj.f_lineno,locals={k:type(v).__module__+'.'+type(v).__qualname__ for k,v in obj.f_locals.items()})
 elif typ is types.TracebackType:row.update(code=obj.tb_frame.f_code.co_name,file=obj.tb_frame.f_code.co_filename,line=obj.tb_lineno)
 elif typ is dict:row['keys']=[k if type(k)in(str,int,bool,type(None))else '<'+type(k).__qualname__+'>' for k in obj]
 elif typ in (tuple,list):row['length']=len(obj)
 rows.append(row)
result={'scope':'DIAGNOSTIC_ONLY_single_original_case_with_explicit_extra_setup_GC_and_DEBUG_SAVEALL_not_qualification','backend':backend_name,'extra_setup_collected':before,'case':case,'record':record,'garbage_count':len(garbage),'garbage_types':dict(collections.Counter(x['type']for x in rows)),'garbage':rows,'raw_exception':raw,'original_observer_definition_unchanged':True,'source_sha256':hashlib.sha256((root/'hepta/hia_slot_operations_native.py').read_bytes()).hexdigest()}
(output/'diagnostic.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'backend':backend_name,'garbage_count':len(garbage),'types':result['garbage_types'],'original_gc_events':[x for x in record['events']if x['event']=='observer.gc.end']}),flush=True)
