from pathlib import Path
import hashlib, json, subprocess, sys

repo=Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-20261127-589c')
out=Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-evidence-20261127/generator-consistency.json')
sys.path.insert(0,str(repo))
from tools import generate_hia_generation_future_callback_fusion_packer as fusion
from tools import generate_hia_background_optimizer_managed_lifecycle as managed

def pin(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

base='a6b8d145a84556958384f15c99993f25236df276'
rows=[]
for name,module,source in [('generation_future_callback_fusion_packer',fusion,fusion.source_program()),
                           ('background_optimizer_worker_managed',managed,managed.worker_source())]:
    rendered=module.render_assembly(module.document(source,name)).encode()
    asset=repo/'examples/hia_bootstrap'/(name+'.hepta')
    assert rendered==asset.read_bytes()
    before=subprocess.check_output(['git','show',base+':'+str(asset.relative_to(repo))],cwd=repo)
    rows.append(dict(path=str(asset.relative_to(repo)),generator=str(Path(module.__file__).relative_to(repo)),
        generator_pin=pin(Path(module.__file__).read_bytes()),before=pin(before),after=pin(rendered),rendered_equals_asset=True))
private=[]
for name in ('tools/generate_hia_multiversion_background_worker.py','examples/hia_bootstrap/multiversion_background_worker.hepta',
             'tools/qualify_hia_background_worker_private.py','tools/qualify_hia_background_native_methods.py'):
    raw=(repo/name).read_bytes();before=subprocess.check_output(['git','show',base+':'+name],cwd=repo)
    assert raw==before
    private.append(dict(path=name,unchanged=True,**pin(raw)))
report=dict(schema='hia.managed-worker.generator-consistency.v1',source_base=base,passed=True,
    generated_assets=rows,unchanged_private_and_original_controls=private,whole_background_closed=False)
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
