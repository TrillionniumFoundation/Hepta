from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tarfile, time

base = Path('/home/qian-qi/work/hia-codex-deps-20261127-589c')
root = base / 'registered-managed04-original-20261127-589c-v3'
root.mkdir(exist_ok=False)
archive = base / 'registered-managed04-inputs.tar.xz'
expected = '728069772f567a92a86d373905129631236ecd891677d2f23ad860fb50b7b639'
assert archive.stat().st_size == 8020176 and hashlib.sha256(archive.read_bytes()).hexdigest() == expected
with tarfile.open(archive, 'r:xz') as source:
    members = source.getmembers()
    assert len({m.name for m in members}) == len(members)
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    manifest = json.loads(source.extractfile('inputs.json').read())
    declared = {row['name']: row for row in manifest['files']}
    assert set(declared) | {'inputs.json'} == {m.name for m in members}
    for member in members:
        raw = source.extractfile(member).read()
        if member.name in declared:
            row = declared[member.name]
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
            assert member.mode == row['mode']
        p = root / member.name
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as target:
            target.write(raw)
        p.chmod(member.mode)

delta = base / 'registered-managed04-inputs-delta-v3.tar.xz'
assert delta.stat().st_size == 405972 and hashlib.sha256(delta.read_bytes()).hexdigest() == 'a3fe8880e48fce946d4206397a2772a433e94526e6ad09038b10438a7e609293'
with tarfile.open(delta, 'r:xz') as source:
    members=source.getmembers()
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    assert len({m.name for m in members})==len(members)
    added=json.loads(source.extractfile('delta-inputs.json').read())
    declared={r['name']:r for r in added['files']}
    assert set(declared)|{'delta-inputs.json'}=={m.name for m in members}
    for member in members:
        raw=source.extractfile(member).read()
        if member.name in declared:
            row=declared[member.name]
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and member.mode==row['mode']
        target=root/member.name
        assert target.parent.is_dir()
        with target.open('xb') as f:f.write(raw)
        target.chmod(member.mode)

build, repo = root / 'build', root / 'source'
retained = [
    ('rank/rank-engine.flat', '/home/qian-qi/.local/state/hia-native-final-custody-20261125/ndu-rank-engine-native-v2/rank-engine.flat', 4461559, '8338a80a992218ca6faefea66235fd18fcfb5c5d59f2bcc1d10a184f28e294ff'),
    ('shared-custody/normalizer-84619bd.bin', '/home/qian-qi/hia-followthrough-evidence-20261126-620a/shared-custody/normalizer-84619bd.bin', 5980873, '84619bd15d8408f52c04519af11664cc4fa52cac352e7ad6680b6d50429123c6'),
    ('shared-custody/proof-3fc158.bin', '/home/qian-qi/hia-followthrough-evidence-20261126-620a/shared-custody/proof-3fc158.bin', 3486129, '3fc158954dbecbde001d51065347a4e10e728f3c503816525da853babf2ffb3a'),
    ('shared-custody/builder-539ce9.bin', '/home/qian-qi/hia-followthrough-evidence-20261126-620a/shared-custody/builder-539ce9.bin', 3819682, '539ce9aab49b6f3e04517a511b08a6351421f86b978e03510ea3220e90f231e0'),
]
for name, origin, size, sha in retained:
    raw = Path(origin).read_bytes()
    assert len(raw) == size and hashlib.sha256(raw).hexdigest() == sha
    p = build / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as target:
        target.write(raw)
    p.chmod(0o500)

env = dict(os.environ)
env['PATH'] = '/usr/lib/llvm-20/bin:/usr/local/bin:/usr/bin:/bin'
clang = Path(shutil.which('clang', path=env['PATH'])).resolve()
assert clang == Path('/usr/lib/llvm-20/bin/clang')
version = subprocess.run([str(clang), '--version'], capture_output=True, timeout=10, env=env)
assert version.returncode == 0 and b'clang version 20.' in version.stdout and not version.stderr
receipt = dict(archive_sha256=expected, source_manifest_sha256=hashlib.sha256((root/'inputs.json').read_bytes()).hexdigest(),
    compiler=dict(path=str(clang), sha256=hashlib.sha256(clang.read_bytes()).hexdigest(), version=version.stdout.decode()),
    python=dict(path=sys.executable, version=sys.version), whole_background_closed=False, passed=False)
args = dict(owner=build/'owner/hia-generation-future-callback-fusion.so',context=build/'context',
    dependencies=build/'dependencies',ledger=build/'core',jobs=build/'core/jobs.so',core=build/'core',
    consumers=build/'core',snapshot=build/'core',nested=build/'nested',constructor=build/'constructor',
    pure=build/'pure',objects=build/'objects/objects.so',worker=build/'core/worker.so',rank=build/'rank/rank-engine.flat',
    evidence_root=build,output=root/'qualification')
command=[sys.executable,'-u','-m','tools.qualify_hia_background_registered_alive']
for name,path in args.items():
    command += ['--'+name.replace('_','-'),str(path)]
command += ['--original-only']
receipt['additional_inputs']=added
receipt['additional_archive_sha256']='a3fe8880e48fce946d4206397a2772a433e94526e6ad09038b10438a7e609293'
receipt['command']=command
(root/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
started=time.monotonic()
with (root/'original.stdout').open('xb') as stdout, (root/'original.stderr').open('xb') as stderr:
    result=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
receipt.update(returncode=result.returncode,seconds=time.monotonic()-started,passed=result.returncode==0)
for name in ('original.stdout','original.stderr'):
    raw=(root/name).read_bytes()
    receipt[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(root/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if result.returncode:
    print((root/'original.stderr').read_text(errors='replace'),flush=True)
raise SystemExit(result.returncode)
