from pathlib import Path
import hashlib, io, json, os, sys, tarfile

repo = Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-20261127-589c')
build = Path('/tmp/hepta-managed-registered-native-589c')
evidence = Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-evidence-20261127')
sys.path.insert(0, str(repo))
from tools import qualify_hia_background_registered_alive

files = {}
for module in list(sys.modules.values()):
    name = getattr(module, '__file__', None)
    if name:
        p = Path(name).resolve()
        if p.is_relative_to(repo) and p.suffix == '.py':
            files['source/' + str(p.relative_to(repo))] = p
for p in (repo / 'hepta').rglob('*.py'):
    files['source/' + str(p.relative_to(repo))] = p
for name in ('tests/test_hia_multiversion.py', 'docs/HIA_NATIVE_VALUE_RESOURCE_QUALIFICATION.json',
             'examples/hia_bootstrap/background_optimizer_integer_threshold.hiadat'):
    files['source/' + name] = repo / name
report = json.loads((evidence / 'registered-window-v1/report.json').read_text())
for row in report['dependencies'].values():
    p = Path(row['path'])
    if p.is_relative_to(build) and p.parts[-2] != 'rank':
        raw = p.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes']
        files['build/' + str(p.relative_to(build))] = p
for name in ('owner/hia-generation-future-callback-fusion.so', 'objects/objects.so'):
    files['build/' + name] = build / name
rows = []
out = evidence / 'registered-rog-inputs.tar.xz'
with out.open('xb') as dest, tarfile.open(fileobj=dest, mode='w:xz', preset=6) as archive:
    for name, p in sorted(files.items()):
        raw = p.read_bytes()
        row = dict(name=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), mode=0o500 if p.suffix=='.so' else 0o600)
        rows.append(row)
        info = tarfile.TarInfo(name);info.size=len(raw);info.mode=row['mode'];info.mtime=0
        archive.addfile(info, io.BytesIO(raw))
    manifest = json.dumps({'schema': 'hia.registered.rog.inputs.v1', 'source_base': 'a6b8d145a84556958384f15c99993f25236df276',
                           'component_only': True, 'whole_background_closed': False, 'files': rows}, indent=2).encode()
    info=tarfile.TarInfo('inputs.json');info.size=len(manifest);info.mode=0o600;info.mtime=0
    archive.addfile(info, io.BytesIO(manifest))
raw=out.read_bytes()
receipt=dict(path=str(out), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), files=len(rows), unpacked_bytes=sum(row['bytes'] for row in rows), manifest=json.loads(manifest))
(evidence/'registered-rog-inputs.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'}),flush=True)
