from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-20261127-589c')
BUILD=Path('/tmp/hepta-managed-registered-native-589c')
EVIDENCE=Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-evidence-20261127')
stage=sys.argv[1];suffix=sys.argv[2]if len(sys.argv)>2 else'v1'
out=EVIDENCE/('registered-'+stage+'-'+suffix)
args=dict(owner=BUILD/'owner/hia-generation-future-callback-fusion.so',context=BUILD/'context',dependencies=BUILD/'dependencies',ledger=BUILD/'core',jobs=BUILD/'core/jobs.so',core=BUILD/'core',consumers=BUILD/'core',snapshot=BUILD/'core',nested=BUILD/'nested',constructor=BUILD/'constructor',pure=BUILD/'pure',objects=BUILD/'objects/objects.so',worker=BUILD/'core/worker.so',rank=BUILD/'rank/rank-engine.flat',evidence_root=BUILD,output=out)
if stage=='before':args['worker']=EVIDENCE/'managed-pair/before.so'
command=[sys.executable,'-u','-m','tools.qualify_hia_background_registered_alive']
for name,path in args.items():command+=['--'+name.replace('_','-'),str(path)]
if stage=='original':command+=['--original-only']
source=ROOT/'tools/qualify_hia_background_registered_alive.py'
receipt=dict(stage=stage,command=command,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),whole_background_closed=False)
started=time.monotonic()
with (EVIDENCE/('registered-'+stage+'-'+suffix+'.stdout')).open('xb')as stdout,(EVIDENCE/('registered-'+stage+'-'+suffix+'.stderr')).open('xb')as stderr:
 result=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr)
receipt.update(returncode=result.returncode,seconds=time.monotonic()-started)
for stream in ('stdout','stderr'):
 p=EVIDENCE/('registered-'+stage+'-'+suffix+'.'+stream);raw=p.read_bytes();receipt[stream]=dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(EVIDENCE/('registered-'+stage+'-'+suffix+'-execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode)
