from pathlib import Path
import hashlib, io, json, tarfile

root=Path('/workspace/scratch/589c0a6dd85b')
repo=root/'hepta-managed-worker-alive-20261127-589c'
e=root/'hepta-managed-worker-alive-evidence-20261127'
build=Path('/tmp/hepta-managed-registered-native-589c')
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(name):return json.loads((e/name).read_text())
private=read('private03-v2/report.json')
managed=read('managed-after/qualification.json')
public=read('registered-window-v1/report.json')
before=read('registered-before-v1/report.json')
original=read('registered-original-rog-v3-report.json')
callbacks=read('fusion-callback-controls-v1/report.json')
jobs=read('managed-jobs-controls-v1/report.json')
assert private['component_qualified'] and len(private['cases'])==6
assert private['original_worker_report']['passed']==6 and not private['original_worker_report']['failed']
assert managed['passed']==4 and managed['actual_worker_calls']==87 and managed['all_threads_reaped']
assert public['passed'] and public['snapshots']==8 and public['actual_join_calls']==1 and public['all_native_resources_retired']
assert before['passed'] is False and before['error']=="AssertionError('registered snapshot skipped physical pthread join')"
assert original['passed'] and len(original['cases'])==5
assert callbacks['passed'] and len(callbacks['cases'])==4
assert jobs['passed'] and len(jobs['cases'])==5
assert read('generator-consistency.json')['passed']
sources=read('final-source-pins.json')
for row in sources['files']:assert pin((repo/row['path']).read_bytes())=={k:row[k]for k in ('bytes','sha256')}
report=dict(schema='hia.managed-worker-physical-completion.component.v1',source=sources,
    component_qualified=True,scope='HIABGW04 state3 query physical once-join through the registered public snapshot',
    whole_background_closed=False,cold_qualification=False,legacy03_query_join_restored=False,
    private03_authorization_unchanged=True,private03_query_observational_unchanged=True,
    original_registered_methods_assertions_unchanged=True,
    controls=[dict(name='original raw worker',cases=6,passed=True),dict(name='strict private03',cases=6,passed=True),
      dict(name='managed04 physical/query/error/domain',cases=4,actual_calls=87,passed=True),
      dict(name='registered public physical window',cases=1,concurrent_snapshots=8,physical_joins=1,passed=True),
      dict(name='registered public original comparison',cases=5,passed=True),
      dict(name='original native Future callbacks',cases=4,passed=True),dict(name='original managed Jobs',cases=5,passed=True)],
    before_counterexample=dict(passed=False,expected_failure=True,error=before['error'],receipt='original/registered-before-v1/report.json'),
    registered_original_execution=read('registered-original-rog-v3-execution.json'),
    preserved_attempts=['private03 initial sparse fixture miss','local original missing actual Clang20+',
      'registered builder initial helper type error','original stale fusion packer native rejection',
      'ROG v1 omitted AST-extracted fixture sources','ROG v2 omitted independent Value/code flat witnesses'],
    direct_managed_fixture_boundary='The direct 04 gate fixtures business/drain acknowledgements; registered window and original comparison use real native business/context/Value entries.',
    bootstrap=json.loads((build/'build.json').read_text())['compiler'],
    retained_complete_native_inputs=dict(path=str(e/'registered-rog-inputs.tar.xz'),
      remote='/home/qian-qi/work/hia-codex-deps-20261127-589c/registered-managed04-inputs.tar.xz',
      **pin((e/'registered-rog-inputs.tar.xz').read_bytes())))
(e/'component-closure.json').write_text(json.dumps(report,indent=2)+'\n')

files={}
for p in e.rglob('*'):
    if p.is_file() and not p.is_symlink() and p.name!='registered-rog-inputs.tar.xz':
        files['original/'+str(p.relative_to(e))]=p
for row in sources['files']:files['source/'+row['path']]=repo/row['path']
for name in ('build.json','retained-inputs-admission.json','retained-xz-transfer.json','retained-dependency-transfer.json'):
    p=build/name
    if p.exists():files['native-build/'+name]=p
for name in ('build_managed_worker_alive_pair.py','build_managed_registered_native.py','run_managed_registered_gate.py',
             'package_managed_registered_rog.py','run_registered_original_rog.py','run_registered_original_rog_v2.py',
             'run_registered_original_rog_v3.py','verify_managed_worker_sources.py','seal_managed_worker_evidence.py'):
    files['drivers/'+name]=root/name
review=root/'hepta-worker-abi-readonly-review-20261127'
for p in review.rglob('*'):
    if p.is_file() and not p.is_symlink() and p.suffix!='gz':files['historical-review/'+str(p.relative_to(review))]=p
archive=root/'hepta-managed-worker04-full-evidence-20261127.tar.xz'
rows=[]
with tarfile.open(archive,'x:xz',preset=6)as t:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();row=dict(path=name,**pin(raw));rows.append(row)
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;info.mtime=0
        t.addfile(info,io.BytesIO(raw))
    raw=json.dumps(dict(schema='hia.managed-worker.evidence-manifest.v1',files=rows),indent=2).encode()
    info=tarfile.TarInfo('manifest.json');info.size=len(raw);info.mode=0o600;info.mtime=0
    t.addfile(info,io.BytesIO(raw))
data=archive.read_bytes();receipt=dict(path=str(archive),**pin(data),files=len(rows),unpacked_bytes=sum(r['bytes']for r in rows),
    source_commit=sources['head'],scope=report['scope'],whole_background_closed=False)
(root/'hepta-managed-worker04-full-evidence-20261127.json').write_text(json.dumps(receipt,indent=2)+'\n')
with tarfile.open(archive,'r:xz')as t:
    manifest=json.loads(t.extractfile('manifest.json').read())
    for row in manifest['files']:
        raw=t.extractfile(row['path']).read();assert pin(raw)=={k:row[k]for k in ('bytes','sha256')}
print(json.dumps(receipt,indent=2),flush=True)
