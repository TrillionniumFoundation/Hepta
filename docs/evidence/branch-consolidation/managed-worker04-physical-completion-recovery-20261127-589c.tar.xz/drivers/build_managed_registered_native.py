"""Isolated component construction for the managed worker public-entry gate.

Every source is read from the fixed baseline object, except the explicitly
selected modified worker. Native compilation is performed twice; every pack is
compared with the existing independent reference. This is not cold qualification.
"""
from pathlib import Path
import ctypes as C, fcntl, hashlib, importlib, json, mmap, os, struct, subprocess, sys, time, traceback

ROOT=Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-20261127-589c')
BASE='a6b8d145a84556958384f15c99993f25236df276'
OUT=Path('/tmp/hepta-managed-registered-native-589c')
COMPILER=Path('/workspace/scratch/589c0a6dd85b/hia-native-compiler-cache/hia-source-build')
sys.path.insert(0,str(ROOT))
from tools import qualify_hia_generation_lease_owner as q
from tools.qualify_hia_publication_cancellation import Image, address

def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
OUT.mkdir(mode=0o700,exist_ok=True)
FLATS=OUT/'flats';FLATS.mkdir(exist_ok=True)
REC=OUT/'build.json'
record=json.loads(REC.read_text())if REC.exists()else dict(schema='hia.managed-worker.registered-gate.build.v1',source_base=BASE,compiler=pin(COMPILER.read_bytes()),modules={},products={},packs=[],passed=False,whole_background_closed=False,cold_qualification=False)
assert record['source_base']==BASE and record['compiler']==dict(bytes=813129,sha256='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af')

def source(name):
    if name=='generation_future_callback_fusion_packer_current':
        rel='examples/hia_bootstrap/generation_future_callback_fusion_packer.hepta'
        return (ROOT/rel).read_bytes(),rel,'owned-regenerated-fusion-packer'
    rel='examples/hia_bootstrap/'+name+'.hepta'
    if name=='background_optimizer_worker_managed':return (ROOT/rel).read_bytes(),rel,'owned-modified-worker'
    return subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT),rel,BASE

def compile_one(name):
    raw,rel,origin=source(name);p=FLATS/(name+'.flat')
    if name in record['modules']:
        row=record['modules'][name];assert row['source']==pin(raw)and row['origin']==origin and row['double_compile_equal']
        flat=p.read_bytes();assert row['flat']==pin(flat);return flat
    fd=os.memfd_create('hia-bg-gate-compiler',os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING)
    try:
        seed=COMPILER.read_bytes();done=0
        while done<len(seed):done+=os.write(fd,seed[done:])
        os.fchmod(fd,0o500);fcntl.fcntl(fd,fcntl.F_ADD_SEALS,15)
        rounds=[];times=[]
        for i in range(2):
            start=time.monotonic();r=subprocess.run(['/proc/self/fd/'+str(fd),'compile'],input=raw,capture_output=True,pass_fds=(fd,),env={'PATH':''},timeout=30);times.append(time.monotonic()-start)
            if r.returncode or r.stderr:(FLATS/(name+'.'+str(i)+'.stderr')).write_bytes(r.stderr)
            assert r.returncode==0 and r.stdout and not r.stderr,(name,i,r.returncode,r.stderr)
            rounds.append(r.stdout)
        assert rounds[0]==rounds[1]
        flat=rounds[0];p.write_bytes(flat)
        record['modules'][name]=dict(source_path=rel,origin=origin,source=pin(raw),flat=pin(flat),double_compile_equal=True,seconds=times)
        save(REC,record);print('COMPILE',name,len(flat),flush=True);return flat
    finally:os.close(fd)

def product(name,raw):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    record['products'][name]=pin(raw);save(REC,record);return raw

def pack(name,spec,parts,*,flat=False,tail=()):
    bodies=[compile_one(p)if isinstance(p,str)else p for p in parts]
    wire=struct.pack('<'+'Q'*(2+len(bodies)+len(tail)),spec.MAGIC,len(bodies),*map(len,bodies),*tail)+b''.join(bodies)
    expected=spec.reference_flat(bodies)if flat else spec.reference_object(bodies)
    out=q.old.run_packer(compile_one(name),wire)
    assert out==expected,name
    record['packs'].append(dict(packer=name,parts=[pin(b)for b in bodies],product=pin(out),independent_reference_equal=True));save(REC,record)
    print('PACK',name,len(out),flush=True);return out

def generic(name,spec,parts,magic,*,tail=(),flat=False):
    from types import SimpleNamespace
    wrapper=SimpleNamespace(MAGIC=int.from_bytes(magic,'little'),reference_object=getattr(spec,'reference_object',None),reference_flat=getattr(spec,'reference_flat',None))
    return pack(name,wrapper,parts,flat=flat,tail=tail)

def link(name,obj,linker='multiversion_runtime_linker'):
    return product(name,q.old.run_packer(compile_one(linker),obj))

def owner():
    from tools import generate_hia_generation_future_callback_fusion_packer as fusion
    from tools import generate_hia_result_value_invocations_packer as value
    from tools import generate_hia_native_callable_code_packer as code
    from tools import generate_hia_generation_lease_owner_provider_capsule_packer as provider
    from tools import generate_hia_generation_lease_owner_tempdir_packer as tempdir
    from tools import generate_hia_generation_lease_owner_sidecar_callback_capsule_packer as sidecar
    from tools import generate_hia_background_optimizer_future_public_truth_packer as truth
    from tools import generate_hia_background_optimizer_future_public_observers_notify_packer as notify
    # Registered BG's original callback owner uses the 15-role invocation
    # profile. The later 16-role filesystem platform is outside this gate.
    v=generic('result_value_invocations_packer',value,list(q.VALUE_ROLES[:-1]),b'HIABVP08',tail=(1,),flat=True)
    product('owner/hia-generation-lease-values.core.bin',v)
    co=generic('native_callable_code_packer',code,['native_callable_code_owner','native_callable_registry','native_callable_buffers','selfhost'],b'HIACOP01',tail=(1,),flat=True)
    product('owner/code-owner.flat',co)
    to=pack('generation_lease_owner_tempdir_packer',tempdir,['generation_lease_owner_tempdir','generation_lease_owner_absolute','generation_lease_owner_tempdir_codec'])
    sh=struct.unpack_from('<Q',to,40)[0];ts=struct.unpack_from('<Q',to,sh+96)[0];temp=to[64:64+ts]
    product('owner/tempdir-component.flat',temp)
    pc=pack('generation_lease_owner_provider_capsule_packer',provider,['generation_lease_owner_provider','multiversion_background_payload'],flat=True)
    sc=pack('generation_lease_owner_sidecar_callback_capsule_packer',sidecar,['generation_lease_owner_sidecar_future',co,temp,'future_resource_deferred_owner','future_resource_registry','future_callable_adapter'],flat=True)
    cl=pack('background_optimizer_future_public_truth_packer',truth,['background_optimizer_future_public_cleanup','background_optimizer_future_public_truth'],flat=True)
    no=compile_one('background_optimizer_future_public_observers_notify');np=Image(compile_one('background_optimizer_future_public_observers_notify_packer'))
    wire=b'HIABFNPK'+struct.pack('<3Q',len(no),0,0)+no;s=C.create_string_buffer(wire)
    with mmap.mmap(-1,16<<20)as o,mmap.mmap(-1,16<<20)as w:
        rc=np.entry(s,len(wire),address(o),len(o),address(w),len(w));n=struct.unpack_from('<Q',w,0)[0];assert rc==0 and 0<n<len(o);nb=bytes(o[:n])
    product('owner/notify.flat',nb)
    body=[compile_one('generation_lease_owner_sidecar_future_core'),compile_one('generation_lease_public_lifecycle'),v,compile_one('generation_lease_typed_policy'),compile_one('generation_lease_owner_future_finalizer')]
    body.extend(compile_one(Path(row['path']).stem)for row in fusion.owner.CARRIER_SOURCES)
    body.extend([pc,sc])
    body.extend(compile_one(n)for n in ('background_optimizer_future_public_owner','background_optimizer_future_public_carrier','background_optimizer_future_managed_timeout','background_optimizer_future_public_log','multiversion_background_future_cell','multiversion_future'))
    body.extend([nb,cl]);assert len(body)==64
    obj=pack('generation_future_callback_fusion_packer_current',fusion,body)
    product('owner/owner.o',obj);linked=link('owner/hia-generation-future-callback-fusion.so',obj)
    record['owner_roles']=[dict(role=r,**pin(b))for r,b in zip(fusion.ROLES,body)];record['owner_built']=True;save(REC,record)
    return linked

def text_section(obj):
    sh=struct.unpack_from('<Q',obj,40)[0]
    at,n=struct.unpack_from('<QQ',obj,sh+88)
    return obj[at:at+n]

def config_pack(group,key,packer,parts):
    from types import SimpleNamespace
    cfg=group.CONFIG[key]
    return pack(packer,SimpleNamespace(MAGIC=int.from_bytes(cfg['magic'].encode(),'little'),reference_object=lambda p:group.reference_object(key,p)),parts)

def background():
    from tools import generate_hia_background_optimizer_managed_packers as managed
    from tools import generate_hia_background_optimizer_native_context_packers as context
    from tools import generate_hia_background_optimizer_native_object_packers as objects
    from tools import generate_hia_background_optimizer_nested_deferred_packer as nested
    from tools import qualify_hia_background_public_constructor as constructor
    from types import SimpleNamespace
    mapping={
      'submission':['background_optimizer_submission_managed'],
      'business':['background_optimizer_business_managed','background_optimizer_business_managed_failure','background_optimizer_business_managed_lifecycle'],
      'execution':['background_optimizer_execution_managed','background_optimizer_execution_managed_publication'],
      'account':['background_optimizer_account_managed'],
      'snapshot':['background_optimizer_snapshot_managed'],
      'shutdown':['background_optimizer_shutdown_managed'],
      'job_refs':['background_optimizer_job_refs_managed'],
      'worker':['background_optimizer_worker_managed'],
      'report':['background_optimizer_report_deferred'],
      'ledger':['background_optimizer_ledger_managed'],
    }
    for key,names in mapping.items():
        obj=config_pack(managed,key,'background_optimizer_'+key+'_managed_packer',names)
        product('core/'+key+'.o',obj)
        link('core/'+key+'.so',obj,'multiversion_background_worker_linker'if key=='worker'else'multiversion_runtime_linker')
    for key in ('context','registry'):
        obj=config_pack(context,key,'background_optimizer_native_'+key+'_packer',['background_optimizer_native_'+key])
        product('context/'+key+'.o',obj);link('context/'+key+'.so',obj)
    for name,parts in {'multiversion_background_queue':['multiversion_background_queue'],'multiversion_values':['multiversion_values','unsigned_decimal_values']}.items():
        spec=importlib.import_module('tools.generate_hia_'+name+'_packer')
        obj=pack(name+'_packer',spec,parts);product('dependencies/'+name+'.o',obj);link('dependencies/'+name+'.so',obj)
    from tools import generate_hia_background_optimizer_jobs_owner_packer as jobs
    obj=pack('background_optimizer_jobs_owner_packer',jobs,['background_optimizer_jobs_owner'])
    product('core/jobs.o',obj);link('core/jobs.so',obj)
    for kind in ('structure','transport','freeze'):
        name='background_optimizer_value_'+kind+'_deferred'
        spec=SimpleNamespace(MAGIC=int.from_bytes(nested.MODELS[kind]['magic'].encode(),'little'),reference_object=lambda p,k=kind:nested.reference_object(k,p))
        obj=pack(name+'_packer',spec,[name]);product('nested/'+kind+'.o',obj);link('nested/'+kind+'.so',obj)
    for name in constructor.names():product('constructor/'+name+'.flat',compile_one(name))
    for name in constructor.paths.SINGLE+tuple(constructor.paths.PAIRS)+constructor.EXTRA_PACKS:
        spec=importlib.import_module('tools.generate_hia_'+name+'_packer')
        roles=(name,constructor.paths.CHECKS)if name=='background_optimizer_constructor_binding'else constructor.paths.PAIRS.get(name,(name,))
        if name in constructor.paths.PAIRS:
            magic=b'HIANPP01'if name=='native_path_value'else b'HIANXP01'
            obj=generic(name+'_packer',spec,roles,magic,tail=(0,))
        else:obj=pack(name+'_packer',spec,roles)
        product('constructor/'+name+'.o',obj)
    from tools import generate_hia_background_optimizer_decision_bound_packer as decision
    product('background-bound-chain-native-v1/decision_bound.o',pack('background_optimizer_decision_bound_packer',decision,['background_optimizer_decision_bound']))
    for name in ('background_optimizer_admission','background_optimizer_decision'):product('pure/'+name+'.flat',compile_one(name))
    children={}
    for key,roles in {
      'construct':['background_optimizer_native_object_construct','background_optimizer_native_object_bind'],
      'retire':['background_optimizer_native_object_retire'],
      'methods':['background_optimizer_native_object_methods'],
    }.items():
        obj=config_pack(objects,key,'background_optimizer_native_object_'+key+'_packer',roles)
        product('objects/'+key+'.o',obj);children[key]=text_section(obj)
    obj=config_pack(objects,'owner','background_optimizer_native_object_owner_packer',['background_optimizer_native_objects',children['construct'],children['retire'],children['methods']])
    product('objects/objects.o',obj);link('objects/objects.so',obj)
    record['background_built']=True;save(REC,record)

if __name__=='__main__':
    try:
        if len(sys.argv)>1 and sys.argv[1]=='background':background()
        else:owner()
        record['passed']=True;record.pop('failure',None);record.pop('traceback',None)
    except BaseException as e:
        record['failure']=repr(e);record['traceback']=traceback.format_exc();raise
    finally:save(REC,record)
