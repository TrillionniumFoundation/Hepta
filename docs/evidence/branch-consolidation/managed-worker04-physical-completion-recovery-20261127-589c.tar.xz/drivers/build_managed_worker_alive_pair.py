from pathlib import Path
import hashlib, json, struct, subprocess
from tools import qualify_hia_generation_lease_owner as q
from tools import generate_hia_background_optimizer_managed_packers as spec

ROOT = Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-20261127-589c')
OUT = Path('/workspace/scratch/589c0a6dd85b/hepta-managed-worker-alive-evidence-20261127/managed-pair')
COMPILER = Path('/workspace/scratch/589c0a6dd85b/hia-native-compiler-cache/hia-source-build')
PRIVATE = OUT.parent / 'private03-v2/build'
BASE = 'a6b8d145a84556958384f15c99993f25236df276'

def pin(raw): return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

assert pin(COMPILER.read_bytes()) == {'bytes': 813129, 'sha256': '494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'}
OUT.mkdir(exist_ok=False)
source_path = 'examples/hia_bootstrap/background_optimizer_worker_managed.hepta'
sources = {'before': subprocess.check_output(['git', 'show', BASE + ':' + source_path], cwd=ROOT), 'after': (ROOT/source_path).read_bytes()}
packer_source_path = 'examples/hia_bootstrap/background_optimizer_worker_managed_packer.hepta'
sources['packer'] = (ROOT/packer_source_path).read_bytes()
flat = {}
modules = []
for name, raw in sources.items():
    pair = []
    for _ in range(2):
        result = subprocess.run([str(COMPILER), 'compile'], input=raw, capture_output=True, timeout=30)
        assert result.returncode == 0 and not result.stderr, (name, result.returncode, result.stderr)
        pair.append(result.stdout)
    assert pair[0] == pair[1]
    flat[name] = pair[0]
    (OUT/(name+'.hepta')).write_bytes(raw)
    (OUT/(name+'.flat')).write_bytes(pair[0])
    modules.append({'name': name, 'source': pin(raw), 'flat': pin(pair[0]), 'double_compile_identical': True})

build = json.loads((PRIVATE/'build.json').read_bytes())
linker = (PRIVATE/'multiversion_background_worker_linker.flat').read_bytes()
linker_row = next(row for row in build['modules'] if row['source_path'] == 'examples/hia_bootstrap/multiversion_background_worker_linker.hepta')
assert pin(linker) == linker_row['flat']
products = {}
for name in ('before', 'after'):
    wire = struct.pack('<3Q', int.from_bytes(b'HIABWRP2', 'little'), 1, len(flat[name])) + flat[name]
    raw = q.old.run_packer(flat['packer'], wire)
    assert raw == spec.reference_object('worker', [flat[name]])
    image = q.old.run_packer(linker, raw)
    assert image[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', image, 16)[0] == 3
    (OUT/(name+'.o')).write_bytes(raw)
    (OUT/(name+'.so')).write_bytes(image)
    products[name] = {'object': pin(raw), 'image': pin(image), 'native_pack_reference_identical': True, 'native_linker': pin(linker)}
report = {'compiler': pin(COMPILER.read_bytes()), 'historical_component_bootstrap_only': True, 'before_revision': BASE, 'modules': modules, 'products': products, 'linker_source': linker_row, 'whole_background_closed': False}
(OUT/'build.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'output': str(OUT), 'products': products, 'report': pin((OUT/'build.json').read_bytes())}), flush=True)
