
#define _GNU_SOURCE
#include <pthread.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <unistd.h>
static uintptr_t lo,hi;
static _Atomic int gate,waiting,join_error;
static _Atomic unsigned long joins;
struct launch {void *(*fn)(void *);void *arg;};
void bg_alive_arm(uintptr_t a,uintptr_t b,int hold) {lo=a;hi=b;atomic_store(&gate,hold);atomic_store(&waiting,0);atomic_store(&joins,0);atomic_store(&join_error,0);}
void bg_alive_release(void) {atomic_store(&gate,0);}
void bg_alive_join_error(int e) {atomic_store(&join_error,e);}
unsigned long bg_alive_read(unsigned long op) {return op?atomic_load(&joins):(unsigned long)atomic_load(&waiting);}
static void *launch(void *p) {
 struct launch v=*(struct launch *)p;free(p);void *r=v.fn(v.arg);
 atomic_store(&waiting,1);while(atomic_load(&gate))usleep(100);return r;
}
int pthread_create(pthread_t *t,const pthread_attr_t *a,void *(*f)(void *),void *p) {
 int (*real)(pthread_t *,const pthread_attr_t *,void *(*)(void *),void *)=dlsym(RTLD_NEXT,"pthread_create");
 uintptr_t pc=(uintptr_t)__builtin_return_address(0);
 if(pc<lo || pc>=hi)return real(t,a,f,p);
 struct launch *v=malloc(sizeof *v);if(!v)return 12;v->fn=f;v->arg=p;
 int rc=real(t,a,launch,v);if(rc)free(v);return rc;
}
int pthread_join(pthread_t t,void **v) {
 uintptr_t pc=(uintptr_t)__builtin_return_address(0);
 if(pc>=lo && pc<hi){atomic_fetch_add(&joins,1);int e=atomic_exchange(&join_error,0);if(e)return e;}
 int (*real)(pthread_t,void **)=dlsym(RTLD_NEXT,"pthread_join");return real(t,v);
}
