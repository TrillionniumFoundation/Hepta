from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess, sys, tarfile, time
E = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-directory-source-closure-evidence-20261127-620a')
D = Path('/home/qian-qi/hia-native-current-20261127-0862/native-lz-address-actual-v1')
D.mkdir(mode=0o700, exist_ok=False)
REPORT = {'scope': 'Actual fixed-journal LZ component; whole qualification remains false', 'passed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'python': sys.version, 'executable': sys.executable}
def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
try:
    archive = E / 'native-lz-address-probe-v1.tar.gz'
    assert pin(archive) == {'bytes': 21359, 'sha256': 'b0522ea3a6fa7b50c7e1bd3b515d1aac8f4d67ebd149266a2f80ce915c8c2a1f'}
    members = {'measure_actual_lz_address_v1.py': {'bytes': 7737, 'sha256': 'd29b6b288052d8a550b4814fe4c41064ef1d7e3854d76c64c3bdcf2ed261308c'}, 'construction-report.json': {'bytes': 1276, 'sha256': '3b1b90dd347094a18f849ffa2eb9b2769dc3d3ce616149a172d24ba6420ff3e7'}, 'pack-current.flat': {'bytes': 35142, 'sha256': '3bf2075f265bfb442a6311f45019eb3403a7b5e3f9b758c782833e5be910d5b4'}, 'pack-dictionary_word.flat': {'bytes': 35040, 'sha256': 'ebcd33c77da3cea2a2dc323f28993943af1f4b01af660ecd8316673409b7eb0d'}, 'pack-address_fold.flat': {'bytes': 35404, 'sha256': '7cea049efc2c3ee77d9ecaca75d7cf6826058173862718d22818627d6151b415'}, 'pack-dictionary_address_fold.flat': {'bytes': 35302, 'sha256': '822d1bf42f842e2e6f26fea7aa8828813d7f4d82f07f0de7457a349794be4a48'}, 'decode-current.flat': {'bytes': 30405, 'sha256': '6b6d7f4812bf7afa433adc335467e7bd92ad6706644a80e129f0a7b4abca6776'}}
    target = D / 'inputs'
    target.mkdir(mode=0o700)
    with tarfile.open(archive, 'r:gz') as bundle:
        entries = bundle.getmembers()
        assert len(entries) == len(members) and len({e.name for e in entries}) == len(entries)
        assert {e.name for e in entries} == set(members)
        for item in entries:
            assert item.isfile() and item.type in (tarfile.REGTYPE, tarfile.AREGTYPE)
            rel = Path(item.name)
            assert not rel.is_absolute() and '..' not in rel.parts and item.size == members[item.name]['bytes']
            data = bundle.extractfile(item).read(item.size + 1)
            assert len(data) == item.size and hashlib.sha256(data).hexdigest() == members[item.name]['sha256']
            out = target / rel
            out.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with out.open('xb') as f: f.write(data)
            out.chmod(0o400)
    REPORT['inputs'] = members
    command = [sys.executable, '-I', '-B', str(target / 'measure_actual_lz_address_v1.py')]
    REPORT['command'] = command
    (D / 'started.json').write_text(json.dumps(REPORT, indent=2) + '\n')
    started = time.monotonic_ns()
    with (D / 'stdout.log').open('xb') as out, (D / 'stderr.log').open('xb') as err:
        result = subprocess.run(command, cwd=target, stdout=out, stderr=err, env={**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'}, timeout=300)
    REPORT['elapsed_ns'] = time.monotonic_ns() - started
    REPORT['returncode'] = result.returncode
    REPORT['stdout'] = pin(D / 'stdout.log')
    REPORT['stderr'] = pin(D / 'stderr.log')
    assert all(pin(target / name) == expected for name, expected in members.items())
    REPORT['input_bytes_unchanged'] = True
    REPORT['passed'] = result.returncode == 0
finally:
    REPORT['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (D / 'execution.json').write_text(json.dumps(REPORT, indent=2) + '\n')
    print('BOUND_COMPONENT_OUTER', json.dumps(REPORT), flush=True)
