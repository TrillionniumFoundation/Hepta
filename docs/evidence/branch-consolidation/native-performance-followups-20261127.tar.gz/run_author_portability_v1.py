from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess, sys, tarfile, time
E = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-directory-source-closure-evidence-20261127-620a')
D = E / 'native-performance-author-portability-v1'
D.mkdir(mode=0o700, exist_ok=False)
REPORT = {'scope': 'Python3.14 developer author portability; complete four source-byte regeneration and exact original refusal tests', 'passed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'python': sys.version, 'executable': sys.executable}
def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
try:
    archive = E / 'native-performance-author-portability-v1.tar.gz'
    assert pin(archive) == {'bytes': 173026, 'sha256': '824179122808d151aa5b8373da45e5f5dc6f18523e1e6a35520bec108952efbc'}
    members = {'examples/hia_bootstrap/seed_bulk_backend.hepta': {'bytes': 125528, 'sha256': '94d64dc20b69fa72944842528f9f9d312e8c6e2448992da0c96e0e66920fe94b'}, 'examples/hia_bootstrap/seed_div_bulk_backend.hepta': {'bytes': 126719, 'sha256': 'a5371f9ada85006b063616ae44a8966f5c962b51e308270b3b8e16d69c822744'}, 'examples/hia_bootstrap/cold_qualification_driver.hepta': {'bytes': 344013, 'sha256': '87e56dfdafd59964959e354d1cc3e4a141fa91ac4c09903781c34e7f920248a9'}, 'examples/hia_bootstrap/cold_master_archive.hepta': {'bytes': 199681, 'sha256': 'ff605a5f9faef7fba1d312bbe937cb70ccb8f5cf64e9fe13d9a87208deb51d4e'}, 'tools/generate_hia_seed_bulk_backend.py': {'bytes': 5137, 'sha256': '3501e8071f6bfcf4264a3ff6a5ed841961611e3f36f11b1c7f07b0b03b8478ab'}, 'tools/generate_hia_cold_qualification_driver.py': {'bytes': 42492, 'sha256': 'dab405942d0f948b5fc6d03590eb227a6812a9e2b5df78410e371d64f37a8871'}, 'tools/generate_hia_cold_master_archive.py': {'bytes': 21196, 'sha256': '44db1f31cfb71d054a8770bc0e26146b7c9c122f19378ee4b80c3b4abe5892cb'}, 'tools/hia_cold_journal_backrefs.py': {'bytes': 1854, 'sha256': '53bdc1d73c9c79a6045e9eea072cdf7de7e42406bc724829ee5b5f703c68fffe'}, 'tools/hia_cold_codec_loops.py': {'bytes': 7401, 'sha256': '93c9a6dc6de904a96e3d1c351a516806c63446877ae89750570e16db481c6eb9'}, 'tests/test_hia_cold_codec_loops.py': {'bytes': 3894, 'sha256': '1508cdc97f93641fbcbca1efd9b39489baccd12925644a25619dbdb519d51fdd'}}
    target = D / 'inputs'
    target.mkdir(mode=0o700)
    with tarfile.open(archive, 'r:gz') as bundle:
        entries = bundle.getmembers()
        assert len(entries) == len(members) and len({e.name for e in entries}) == len(entries)
        assert {e.name for e in entries} == set(members)
        for item in entries:
            assert item.isfile() and item.type in (tarfile.REGTYPE, tarfile.AREGTYPE)
            rel = Path(item.name)
            assert not rel.is_absolute() and '..' not in rel.parts and item.size == members[item.name]['bytes']
            data = bundle.extractfile(item).read(item.size + 1)
            assert len(data) == item.size and hashlib.sha256(data).hexdigest() == members[item.name]['sha256']
            out = target / rel
            out.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with out.open('xb') as f: f.write(data)
            out.chmod(0o400)
    REPORT['inputs'] = members
    command = [sys.executable, '-I', '-B', '-c', "import sys,unittest,importlib.util;from pathlib import Path; target=Path(sys.argv[1]); source=Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-final-native-source-20261127-5622dafb');sys.path[:0]=[str(target),str(source)];spec=importlib.util.spec_from_file_location('isolated_cold_author_scope',target/'tests/test_hia_cold_codec_loops.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(mod));sys.exit(0 if r.wasSuccessful() else 1)", str(target)]
    REPORT['command'] = command
    (D / 'started.json').write_text(json.dumps(REPORT, indent=2) + '\n')
    started = time.monotonic_ns()
    with (D / 'stdout.log').open('xb') as out, (D / 'stderr.log').open('xb') as err:
        result = subprocess.run(command, cwd=target, stdout=out, stderr=err, env={**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'}, timeout=300)
    REPORT['elapsed_ns'] = time.monotonic_ns() - started
    REPORT['returncode'] = result.returncode
    REPORT['stdout'] = pin(D / 'stdout.log')
    REPORT['stderr'] = pin(D / 'stderr.log')
    assert all(pin(target / name) == expected for name, expected in members.items())
    REPORT['input_bytes_unchanged'] = True
    REPORT['passed'] = result.returncode == 0
finally:
    REPORT['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (D / 'execution.json').write_text(json.dumps(REPORT, indent=2) + '\n')
    print('BOUND_COMPONENT_OUTER', json.dumps(REPORT), flush=True)
