"""Isolated LZ dictionary/address candidates over every actual signed-phase physical chunk."""
from pathlib import Path
import ctypes, datetime, hashlib, json, mmap, os, platform, random, signal, stat, struct, sys, time

ROOT = Path(__file__).resolve().parent
JOURNAL = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-cold-isolated-f-20261127-v2/cold/qualification/original-signed/evidence.hiaqj')
JOURNAL_SHA = '090c2f1887a34a2e60540bd5a1246b89d09cc38e02daad9c2916cd38536acb37'
PINS = {'decode-current': '6b6d7f4812bf7afa433adc335467e7bd92ad6706644a80e129f0a7b4abca6776', 'pack-current': '3bf2075f265bfb442a6311f45019eb3403a7b5e3f9b758c782833e5be910d5b4', 'pack-dictionary_word': 'ebcd33c77da3cea2a2dc323f28993943af1f4b01af660ecd8316673409b7eb0d', 'pack-address_fold': '7cea049efc2c3ee77d9ecaca75d7cf6826058173862718d22818627d6151b415', 'pack-dictionary_address_fold': '822d1bf42f842e2e6f26fea7aa8828813d7f4d82f07f0de7457a349794be4a48'}
DECODERS = [name for name in PINS if name.startswith('decode-')]
PACKERS = [name for name in PINS if name.startswith('pack-')]
report = {'scope': 'finite actual-native LZ address components, not complete cold qualification',
          'passed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_commit': '5622dafbcfa10ad0c6f99214994ee7dcf71523e0',
          'journal': str(JOURNAL), 'journal_sha256': JOURNAL_SHA, 'products': {},
          'whole_workspace_bytes': 4194304, 'chunks': 0, 'whole_workspace_comparisons': 0,
          'decoded_bytes': 0, 'repacked_bytes_equal_actual': True, 'by_mode': {},
          'interpreter': sys.executable, 'python_version': platform.python_version()}
signal.alarm(240)
started = time.monotonic_ns()
cpu_started = time.process_time_ns()


def entry(raw):
    region = mmap.mmap(-1, len(raw), prot=mmap.PROT_READ | mmap.PROT_WRITE | mmap.PROT_EXEC)
    region[:] = raw
    pointer = ctypes.addressof(ctypes.c_char.from_buffer(region))
    signature = ctypes.CFUNCTYPE(ctypes.c_uint64, ctypes.c_void_p, ctypes.c_uint64,
                                ctypes.c_void_p, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_uint64)
    return region, signature(pointer)


try:
    st = JOURNAL.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_uid == os.geteuid()
    assert st.st_size == 47996590 and stat.S_IMODE(st.st_mode) == 0o400
    raw = JOURNAL.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == JOURNAL_SHA
    data = ctypes.create_string_buffer(raw)
    data_at = ctypes.addressof(data)
    initial = random.Random(18131).randbytes(4194304)
    work = {name: ctypes.create_string_buffer(initial, len(initial)) for name in PINS}
    work_at = {name: ctypes.addressof(buffer) for name, buffer in work.items()}
    images = {}
    regions = []
    for name, digest in PINS.items():
        body = (ROOT / (name + '.flat')).read_bytes()
        assert hashlib.sha256(body).hexdigest() == digest
        region, image = entry(body)
        regions.append(region)
        images[name] = image
        report['products'][name] = {'bytes': len(body), 'sha256': digest}
    compare = ctypes.CDLL(None).memcmp
    compare.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
    compare.restype = ctypes.c_int
    s = ctypes.create_string_buffer(8)
    o = {name: ctypes.create_string_buffer(8) for name in PINS}
    decoded_hash = hashlib.sha256()
    previous = {}
    at = 0
    index = 0
    while at < len(raw):
        assert len(raw) - at >= 32
        magic, size, payload, mode = struct.unpack_from('<4Q', raw, at)
        assert 0 < size <= 65504 and mode <= 3 and 0 < payload <= 65504
        end = at + 32 + payload
        assert end <= len(raw)
        if mode == 3:
            assert payload == 8
            prior = struct.unpack_from('<Q', raw, at + 32)[0]
            assert prior in previous
            source, encoded, declared, kind = previous[prior]
            assert source == prior and declared == size and kind != 3
        else:
            source, encoded, declared, kind = at, 32 + payload, size, mode
            previous[at] = (source, encoded, declared, kind)
        row = report['by_mode'].setdefault(str(kind), {'chunks': 0, 'decoded_bytes': 0, 'profiles': {}})
        row['chunks'] += 1
        row['decoded_bytes'] += size
        struct.pack_into('<Q', s, 0, encoded)
        order = DECODERS if index % 2 == 0 else list(reversed(DECODERS))
        for name in order:
            ctypes.memmove(work_at[name] + 800000, data_at + source, encoded)
            tick = time.monotonic_ns()
            cpu = time.process_time_ns()
            result = images[name](s, 8, o[name], 8, work[name], 4194304)
            elapsed_cpu = time.process_time_ns() - cpu
            elapsed = time.monotonic_ns() - tick
            stats = row['profiles'].setdefault(name, {'cpu_ns': 0, 'elapsed_ns': 0})
            stats['cpu_ns'] += elapsed_cpu
            stats['elapsed_ns'] += elapsed
            assert result == size, (index, name, result, size)
        for name in DECODERS[1:]:
            assert compare(work_at[DECODERS[0]], work_at[name], 4194304) == 0, (index, name)
            report['whole_workspace_comparisons'] += 1
        decoded = (ctypes.c_ubyte * size).from_address(work_at[DECODERS[0]] + 940000)
        decoded_hash.update(memoryview(decoded))
        struct.pack_into('<Q', s, 0, size)
        rotate = index % len(PACKERS)
        order = PACKERS[rotate:] + PACKERS[:rotate]
        for name in order:
            ctypes.memmove(work_at[name] + 700000, work_at[DECODERS[0]] + 940000, size)
            tick = time.monotonic_ns()
            cpu = time.process_time_ns()
            result = images[name](s, 8, o[name], 8, work[name], 4194304)
            elapsed_cpu = time.process_time_ns() - cpu
            elapsed = time.monotonic_ns() - tick
            stats = row['profiles'].setdefault(name, {'cpu_ns': 0, 'elapsed_ns': 0})
            stats['cpu_ns'] += elapsed_cpu
            stats['elapsed_ns'] += elapsed
            assert result == encoded, (index, name, result, encoded)
            assert compare(work_at[name] + 800000, data_at + source, encoded) == 0, (index, name, 'encoded bytes')
        for name in PACKERS[1:]:
            assert compare(work_at[PACKERS[0]], work_at[name], 4194304) == 0, (index, name)
            report['whole_workspace_comparisons'] += 1
        assert all(output.raw == bytes(8) for output in o.values())
        report['chunks'] += 1
        report['decoded_bytes'] += size
        at = end
        index += 1
        if index % 20000 == 0:
            print('LZ_ADDRESS_COMPONENT_PROGRESS', index, at, json.dumps(report['by_mode']), flush=True)
    assert index == 131668 and report['decoded_bytes'] == 1170777775
    assert report['whole_workspace_comparisons'] == index * (len(PACKERS) + len(DECODERS) - 2)
    assert decoded_hash.hexdigest() == 'c1ed475c947be23362137fe97b9e20015715f82d316e65bbe5414457b791b80f'
    report['decoded_sha256'] = decoded_hash.hexdigest()
    after = JOURNAL.lstat()
    assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_mode, st.st_nlink) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode, after.st_nlink)
    assert hashlib.sha256(JOURNAL.read_bytes()).hexdigest() == JOURNAL_SHA
    report['passed'] = True
    signal.alarm(0)
finally:
    report['elapsed_ns'] = time.monotonic_ns() - started
    report['process_cpu_ns'] = time.process_time_ns() - cpu_started
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT / 'diagnostic.json').write_text(json.dumps(report, indent=2) + '\n')
    print('LZ_ADDRESS_COMPONENT_RESULT', json.dumps(report), flush=True)
