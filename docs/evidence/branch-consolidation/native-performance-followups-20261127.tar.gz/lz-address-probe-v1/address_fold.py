def probe(s:readbuf,o:mutbuf,w:mutbuf) -> u32:
    if length(s) != 8 or length(w) != 4194304:
        return 4294967295
    return pack_chunk(w,word_load(s,0))

def pack_chunk_rle(w: mutbuf, size: u64) -> u64:
    if size == 0 or size > 65504:
        return 0
    pos = 0
    literal = 0
    output = 800032
    while pos + 24 <= size:
        value = word_load(w, 700000 + pos)
        if value == word_load(w, 700008 + pos) and value == word_load(w, 700016 + pos):
            if pos != literal:
                put(w, output, (pos - literal) * 2)
                move_within(w, output + 8, 700000 + literal, pos - literal)
                output = output + 8 + pos - literal
            count = 3
            while pos + count * 8 + 64 <= size and word_load(w, 700000 + pos + (count + 0) * 8) == value and (word_load(w, 700000 + pos + (count + 1) * 8) == value) and (word_load(w, 700000 + pos + (count + 2) * 8) == value) and (word_load(w, 700000 + pos + (count + 3) * 8) == value) and (word_load(w, 700000 + pos + (count + 4) * 8) == value) and (word_load(w, 700000 + pos + (count + 5) * 8) == value) and (word_load(w, 700000 + pos + (count + 6) * 8) == value) and (word_load(w, 700000 + pos + (count + 7) * 8) == value):
                count = count + 8
            while pos + count * 8 + 8 <= size and word_load(w, 700000 + pos + count * 8) == value:
                count = count + 1
            put(w, output, count * 2 + 1)
            put(w, output + 8, value)
            output = output + 16
            pos = pos + count * 8
            literal = pos
        else:
            pos = pos + 8
    if literal < size:
        put(w, output, (size - literal) * 2)
        move_within(w, output + 8, 700000 + literal, size - literal)
        output = output + 8 + size - literal
    compressed = output - 800032
    mode = 1
    if compressed >= size:
        compressed = size
        mode = 0
        move_within(w, 800032, 700000, size)
    put(w, 800000, 3544432143323187528)
    put(w, 800008, size)
    put(w, 800016, compressed)
    put(w, 800024, mode)
    return 32 + compressed

def pack_lz(w: mutbuf, size: u64, best: u64) -> u64:
    fill_range(w, 3276800, 16384, 0)
    pos = 0
    literal = 0
    output = 0
    while pos + 8 <= size:
        cold_raw_at = 700000 + pos
        value = word_load(w, cold_raw_at)
        cold_hash_fold = value ^ value >> 26 ^ value >> 52
        slot = (cold_hash_fold ^ cold_hash_fold >> 13) & 8191
        at = 3276800 + slot * 2
        previous = byte(w, at) | byte(w, at + 1) << 8
        store(w, at, pos + 1 & 255)
        store(w, at + 1, pos + 1 >> 8)
        matched = 0
        if previous != 0:
            candidate = previous - 1
            cold_candidate_at = 700000 + candidate
            if candidate < pos and word_load(w, cold_candidate_at) == value:
                matched = 8
                while pos + matched + 8 <= size and word_load(w, cold_raw_at + matched) == word_load(w, cold_candidate_at + matched):
                    matched = matched + 8
                while pos + matched < size and byte(w, cold_raw_at + matched) == byte(w, cold_candidate_at + matched):
                    matched = matched + 1
        if matched >= 8:
            count = pos - literal
            needed = 5
            if count != 0:
                needed = needed + 3 + count
            if output + needed >= best:
                return 0
            if count != 0:
                store(w, 880000 + output, 0)
                store(w, 880001 + output, count & 255)
                store(w, 880002 + output, count >> 8)
                move_within(w, 880003 + output, 700000 + literal, count)
                output = output + 3 + count
            distance = pos - (previous - 1)
            store(w, 880000 + output, 1)
            store(w, 880001 + output, matched & 255)
            store(w, 880002 + output, matched >> 8)
            store(w, 880003 + output, distance & 255)
            store(w, 880004 + output, distance >> 8)
            output = output + 5
            pos = pos + matched
            literal = pos
        else:
            pos = pos + 1
    if literal != size:
        count = size - literal
        if output + 3 + count >= best:
            return 0
        store(w, 880000 + output, 0)
        store(w, 880001 + output, count & 255)
        store(w, 880002 + output, count >> 8)
        move_within(w, 880003 + output, 700000 + literal, count)
        output = output + 3 + count
    if output == 0 or output >= best:
        return 0
    return output

def pack_chunk(w: mutbuf, size: u64) -> u64:
    result = pack_chunk_rle(w, size)
    if result == 0:
        return 0
    put(w, 800000, 3616489737361115464)
    best = result - 32
    if best < 64:
        return result
    compressed = pack_lz(w, size, best)
    if compressed == 0:
        return result
    move_within(w, 800032, 880000, compressed)
    put(w, 800016, compressed)
    put(w, 800024, 2)
    return 32 + compressed

def copyw(w: mutbuf, target: u64, source: u64, count: u64) -> u64:
    if target <= length(w) and source <= length(w) and (count <= length(w) - target) and (count <= length(w) - source):
        if target <= source and count <= source - target or (source <= target and count <= target - source):
            move_within(w, target, source, count)
            return 0
    i = 0
    while i < count:
        store(w, target + i, byte(w, source + i))
        i = i + 1
    return 0

def get(w: mutbuf, at: u64) -> u64:
    return word_load(w, at)

def put(w: mutbuf, at: u64, value: u64) -> u64:
    store(w, at, value >> 0 & 255)
    store(w, at + 1, value >> 8 & 255)
    store(w, at + 2, value >> 16 & 255)
    store(w, at + 3, value >> 24 & 255)
    store(w, at + 4, value >> 32 & 255)
    store(w, at + 5, value >> 40 & 255)
    store(w, at + 6, value >> 48 & 255)
    store(w, at + 7, value >> 56 & 255)
    return 0
