"""Construct isolated exact-domain LZ variants; no production file is changed."""
from pathlib import Path
import ast
import copy
import ctypes
import hashlib
import json
import random
import struct
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'perf-native-source-v2'
sys.path.insert(0, str(ROOT))
from tools.hia_native_seed_test_support import NativeSeeds
from tools.generate_hia_cold_qualification_driver import policy_source
from tools.generate_hia_cold_document import bulk_document
from hepta.hia_agent_assembly import render_assembly
from hepta.hia_json_preflight_native import NativeHiaJsonImage

OUT = BASE / 'lz-address-probe-v1'
seeds = NativeSeeds(ROOT, BASE / 'published-f-bootstrap/files', OUT)
report = {'scope': __doc__, 'passed': False, 'products': {}, 'controls': {}}
ENTRY = '''def probe(s:readbuf,o:mutbuf,w:mutbuf) -> u32:
    if length(s) != 8 or length(w) != 4194304:
        return 4294967295
    return pack_chunk(w,word_load(s,0))
'''
names = ('pack_chunk_rle', 'pack_lz', 'pack_chunk', 'copyw', 'get', 'put')
production = ast.parse(policy_source())
baseline = {node.name: node for node in production.body}


def shape(node):
    return ast.dump(node, include_attributes=False)


def expr(text):
    return ast.parse(text, mode='eval').body


def variant(*, word=False, hoist=False):
    functions = [copy.deepcopy(baseline[name]) for name in names]
    function = next(node for node in functions if node.name == 'pack_lz')
    outer = next(node for node in function.body if isinstance(node, ast.While))
    assert ast.unparse(outer.test) == 'pos + 8 <= size'
    if word:
        previous = [n for n in ast.walk(function) if isinstance(n, ast.Assign)
                    and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
                    and n.targets[0].id == 'previous']
        assert len(previous) == 1
        assert shape(previous[0].value) == shape(expr('byte(w,at) | (byte(w,at+1) << 8)'))
        previous[0].value = expr('word_load(w,at) & 65535')
    if hoist:
        assignments = {node.targets[0].id: node for node in outer.body
                       if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
        assert shape(assignments['slot'].value) == shape(expr('(value ^ (value >> 13) ^ (value >> 26) ^ (value >> 39) ^ (value >> 52)) & 8191'))
        assignments['slot'].value = expr('(cold_hash_fold ^ (cold_hash_fold >> 13)) & 8191')
        slot_at = outer.body.index(assignments['slot'])
        outer.body[slot_at:slot_at] = ast.parse('cold_hash_fold = value ^ (value >> 26) ^ (value >> 52)').body

        class Addresses(ast.NodeTransformer):
            def visit_BinOp(self, node):
                if shape(node) == shape(expr('700000 + pos')):
                    return ast.copy_location(ast.Name(id='cold_raw_at', ctx=ast.Load()), node)
                if shape(node) == shape(expr('700000 + candidate')):
                    return ast.copy_location(ast.Name(id='cold_candidate_at', ctx=ast.Load()), node)
                return self.generic_visit(node)

        Addresses().visit(outer)
        outer.body[0:0] = ast.parse('cold_raw_at = 700000 + pos').body
        branches = [node for node in ast.walk(outer) if isinstance(node, ast.If)
                    and ast.unparse(node.test) == 'previous != 0']
        assert len(branches) == 1 and ast.unparse(branches[0].body[0]) == 'candidate = previous - 1'
        branches[0].body[1:1] = ast.parse('cold_candidate_at = 700000 + candidate').body
    body = ast.unparse(ast.fix_missing_locations(ast.Module(body=functions, type_ignores=[])))
    return ENTRY + '\n' + body


try:
    # XOR, shifts and the final low-bit mask are linear over all 64 input bits.
    for value in [0, *[1 << bit for bit in range(64)]]:
        original = (value ^ value >> 13 ^ value >> 26 ^ value >> 39 ^ value >> 52) & 8191
        folded = value ^ value >> 26 ^ value >> 52
        assert original == (folded ^ folded >> 13) & 8191
    report['controls']['all_64_linear_basis_bits_and_zero'] = 65
    images = {}
    for name, options in [('current', {}), ('dictionary_word', {'word': True}),
                          ('address_fold', {'hoist': True}),
                          ('dictionary_address_fold', {'word': True, 'hoist': True})]:
        source = variant(**options)
        body = render_assembly(bulk_document(source, 'pack_current')).encode()
        flat = seeds.compile(body, 'bulk')
        (OUT / (name + '.py')).write_text(source + '\n')
        (OUT / (name + '.hepta')).write_bytes(body)
        (OUT / (name + '.flat')).write_bytes(flat)
        if name == 'current':
            assert hashlib.sha256(flat).hexdigest() == '3bf2075f265bfb442a6311f45019eb3403a7b5e3f9b758c782833e5be910d5b4'
        row = {'source_bytes': len(body), 'source_sha256': hashlib.sha256(body).hexdigest(),
               'bytes': len(flat), 'sha256': hashlib.sha256(flat).hexdigest()}
        report['products'][name] = row
        images[name] = NativeHiaJsonImage(flat, row['sha256'])
        print('LZ_PROBE_PRODUCT', name, json.dumps(row), flush=True)
    rng = random.Random(91938)
    initial = rng.randbytes(4194304)
    cases = [b'', b'a', b'abcd', bytes(65504), bytes(range(256)) * 255,
             b'abcdefghi' * 6000, rng.randbytes(65504)]
    for _ in range(100):
        size = rng.randrange(1, 65505)
        pattern = rng.randbytes(rng.randrange(1, min(256, size) + 1))
        cases.append((pattern * (size // len(pattern) + 1))[:size])
    compare = ctypes.CDLL(None).memcmp
    compare.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
    compare.restype = ctypes.c_int
    for index, raw in enumerate(cases):
        buffers = []
        results = []
        source = ctypes.create_string_buffer(struct.pack('<Q', len(raw)))
        for name, image in images.items():
            work = ctypes.create_string_buffer(initial, len(initial))
            ctypes.memmove(ctypes.addressof(work) + 700000, raw, len(raw))
            output = ctypes.create_string_buffer(b'preserve', 8)
            results.append(image._entry(source, 8, output, 8, work, 4194304))
            assert output.raw == b'preserve'
            if buffers:
                assert results[0] == results[-1] and compare(buffers[0], work, 4194304) == 0, (index, name)
            buffers.append(work)
    report['controls']['complete_workspace_cases_all_four_profiles'] = len(cases)
    report['passed'] = True
    print('LZ_PROBE_RESULT', json.dumps(report), flush=True)
finally:
    seeds.save()
    (OUT / 'construction-report.json').write_text(json.dumps(report, indent=2) + '\n')
