"""Materialize a pinned component export and run original CPython v5 scopes.

This is an explicit development component. It is neither a Git checkout nor
a complete native cold qualification. The immutable F checkout stays read-only.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import sys
import tarfile
import time

BASE = Path('/home/qian-qi/hia-native-current-20261127-0862')
EVIDENCE = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-directory-source-closure-evidence-20261127-620a')
FROZEN = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia-final-native-source-20261127-5622dafb')
D = BASE / 'slot-mechanical-798316c5-v1'
# The claim precedes every source/native business effect and is never removed.
D.mkdir(mode=0o700, exist_ok=False)
SOURCE = D / 'source'
SOURCE.mkdir(mode=0o700)
report = {'schema': 'hepta.explicit-slot-v5-component-observation.v1',
          'scope': __doc__, 'passed': False, 'whole_native_qualified': False,
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'interpreter': sys.executable, 'python': sys.version, 'operations': []}


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read_regular(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
        assert before.st_size <= limit
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(limit + 1)
        after = os.fstat(fd)
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
                before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size,
                                       after.st_mtime_ns, after.st_ctime_ns)
        assert len(raw) == before.st_size
        return raw
    finally:
        os.close(fd)


def matches(raw, row):
    return (pin(raw) == {k: row[k] for k in ('bytes', 'sha256')}
            and hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            == row['git_blob'])


def persist():
    (D / 'execution.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')


try:
    archive = EVIDENCE / 'hepta-798-component-source-overlay.tar.gz'
    assert pin(read_regular(archive, 2000000)) == {
        'bytes': 1594268, 'sha256': '55517662ef922515c16f673ba77fda9ec63aeceeeb971fe2ba30e283765a77dd'}
    with tarfile.open(archive, 'r:gz') as bundle:
        entries = bundle.getmembers()
        assert len(entries) == 76 and len({m.name for m in entries}) == 76
        assert all(m.isfile() and m.type in (tarfile.REGTYPE, tarfile.AREGTYPE) for m in entries)
        raw_manifest = bundle.extractfile('manifest.json').read()
        assert hashlib.sha256(raw_manifest).hexdigest() == '58c407c091b678788785fa5ac31aa615cca7e2986908f972851e1ba2ac3c9b1c'
        manifest = json.loads(raw_manifest)
        assert manifest['schema'] == 'hepta.hia.exact-component-source-overlay.v1'
        assert manifest['base_source_commit'] == '5622dafbcfa10ad0c6f99214994ee7dcf71523e0'
        assert manifest['published_candidate_commit'] == '798316c5cf521340de06cdd969e2ada56fb8c386'
        assert manifest['published_candidate_tree'] == '85c270579f6aa96bb31882870a06019c1dafcbee'
        assert manifest['whole_native_qualified'] is False and manifest['total_files'] == 6710
        files = manifest['files']
        assert len(files) == 6710 and len({r['path'] for r in files}) == 6710
        overlays = {r['path'] for r in files if r['overlay']}
        assert len(overlays) == 75
        assert {m.name for m in entries} == {'manifest.json', *('files/' + p for p in overlays)}
        copied = 0
        started = time.monotonic_ns()
        for row in files:
            relative = Path(row['path'])
            assert not relative.is_absolute() and '..' not in relative.parts
            assert row['mode'] in ('100644', '100755') and row['bytes'] <= 67108864
            if row['overlay']:
                member = bundle.getmember('files/' + row['path'])
                assert member.size == row['bytes']
                raw = bundle.extractfile(member).read(member.size + 1)
            else:
                raw = read_regular(FROZEN / relative, 67108864)
            assert matches(raw, row), row['path']
            target = SOURCE / relative
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(raw)
            target.chmod(int(row['mode'], 8) & 0o777)
            assert target.stat().st_nlink == 1 and matches(read_regular(target, 67108864), row)
            copied += len(raw)
        assert copied == 440444424
        report['materialization'] = {'manifest': pin(raw_manifest), 'files': len(files),
            'bytes': copied, 'overlay_files': len(overlays), 'source_path': str(SOURCE),
            'source_commit': manifest['published_candidate_commit'],
            'source_tree': manifest['published_candidate_tree'],
            'elapsed_ns': time.monotonic_ns() - started,
            'git_blob_and_sha256_every_path': True, 'full_git_checkout_claimed': False}
        (D / 'source-manifest.json').write_bytes(raw_manifest)
    sys.path.insert(0, str(SOURCE))
    from tests import hia_slot_operations_qualification_support as support
    assert Path(support.__file__).resolve() == SOURCE / 'tests/hia_slot_operations_qualification_support.py'
    assert support.CANDIDATE_SECONDS == 1800 and support.TOTAL_SECONDS == 1800
    environment = support.clean_environment()
    environment['CC'] = '/usr/bin/clang-20'
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    report['original_slot_budgets'] = {'method_seconds': 1800, 'cleanup_seconds': support.CLEANUP_SECONDS}
    persist()

    def run(label, command, seconds, env):
        print('SLOT_798_OPERATION_START', label, flush=True)
        result = support.run_owned(command, cwd=SOURCE, directory=D / label,
                                   timeout_seconds=seconds, environment=env)
        report['operations'].append({'label': label, 'result': result,
                                      'passed': support.successful_exit(result)})
        persist()
        print('SLOT_798_OPERATION_TERMINAL', label, json.dumps(result), flush=True)
        return support.successful_exit(result)

    runner = ('import sys,unittest;sys.path.insert(0,sys.argv[1]);'
              'suite=unittest.defaultTestLoader.loadTestsFromNames(sys.argv[2:]);'
              'r=unittest.TextTestRunner(verbosity=2).run(suite);'
              'sys.exit(0 if r.wasSuccessful() else 1)')
    author_ok = run('author-portability', [sys.executable, '-I', '-B', '-c', runner,
        str(SOURCE), 'tests.test_hia_cold_codec_loops.ColdCodecLoopScopeTests'], 120, environment)
    build_ok = run('c-build', [sys.executable, '-I', '-B',
        str(SOURCE / 'tools/build_hia_slot_mechanical.py'), '--output', str(D / 'build'),
        '--in-place'], 1800, environment)
    tests_ok = False
    if build_ok:
        compiler = BASE / 'final-f-native-chain-v1/qualification/cold/qualification/base/B1.flat'
        assert pin(read_regular(compiler, 1048576)) == {
            'bytes': 641344, 'sha256': 'acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'}
        test_environment = dict(environment,
            HEPTA_HIA_SLOT_OPERATIONS_DEVELOPMENT_COMPILER=str(compiler),
            HEPTA_HIA_SLOT_OPERATIONS_EVIDENCE=str(D / 'component'))
        methods = [
            'tests.test_hia_slot_mechanical_native.SlotMechanicalV5NativeTests.test_01_full_public84_handled12_original_first_native_v5',
            'tests.test_hia_slot_mechanical_native.SlotMechanicalV5NativeTests.test_02_complete_actual_admission_and_sealed_loader_controls']
        tests_ok = run('original-v5-two-scopes', [sys.executable, '-I', '-B', '-c', runner,
            str(SOURCE), *methods], 3630, test_environment)
    stable = all(matches(read_regular(SOURCE / row['path'], 67108864), row) for row in files)
    report['all_6710_source_paths_unchanged'] = stable
    report['passed'] = bool(author_ok and build_ok and tests_ok and stable)
finally:
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    persist()
    print('SLOT_798_COMPONENT_RESULT', json.dumps(report), flush=True)
