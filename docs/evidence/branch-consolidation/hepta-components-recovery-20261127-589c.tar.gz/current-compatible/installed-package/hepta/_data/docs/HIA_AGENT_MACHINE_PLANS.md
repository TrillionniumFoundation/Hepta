# Explicit HIA machine plans

The Agent selects a plan. The direct backend validates and realizes it without
running a profitability search. Core remains the immutable semantic anchor;
an accepted plan cannot change ownership, ordered effects, traps or the public
call ABI. The original `hepta.hia.agent.block-layout.v1` remains supported.

Before reading plan fields, the backend captures a detached snapshot using the
existing bounded plain-JSON admission path: exact built-in data types, at most
8 MiB of canonical JSON, 262,144 nodes and depth 64. Object hooks, subclasses
and cycles are rejected. Semantic checks and emission use that same snapshot;
later changes to the caller's containers cannot change the accepted plan.

## Reviewed v2 choices

`hepta.hia.agent.machine-plan.v2` requires every field below. Omitted choices
are not inferred. The `core_sha256` is the canonical verified Core digest.

```json
{
  "schema": "hepta.hia.agent.machine-plan.v2",
  "core_sha256": "<canonical Core SHA-256>",
  "block_order": {},
  "function_order": ["answer", "twice"],
  "scratch_registers": {"r10": "r11", "r11": "r10"},
  "instruction_selection": {
    "move_immediate": "mov32_if_exact",
    "alu_immediate": "imm8_if_exact"
  },
  "function_alignment": 64
}
```

| Choice | Independent admission and preservation rule |
| --- | --- |
| Block order | Exact permutation of all blocks in each named function. Every block retains its explicit transfer. |
| Function order | Exact permutation of all Core functions. Internal symbol identities and relocations are preserved. |
| Scratch registers | Only a bijection of `r10` and `r11`. These are explicit caller-clobbered scratch registers; implicit instruction registers, arguments, results and callee-saved registers remain fixed. This is not general SSA register allocation. |
| Immediate move | `movabs`, or explicitly selected `mov32_if_exact`: use a zero-extending 32-bit move only for values in `[0, 2^32)`. Both forms preserve flags. |
| Immediate arithmetic | `imm32`, or `imm8_if_exact`: use the sign-extended 8-bit form only for values in `[-128,127]`. The operation and flags remain the same. |
| Function alignment | `1`, `16`, `32` or `64`. Insert NOPs only between functions; declare sufficient ELF `.text` alignment so linking preserves the requested alignment. |

Raw instructions/bytes, arbitrary physical registers, unchecked value-location
changes, instructions outside the reviewed forms and automatic search remain rejected. Choice validity
does not establish a performance advantage.

## Reviewed v3 scalar register assignments and select forms

`hepta.hia.agent.machine-plan.v3` retains every explicit v2 field and adds
`value_registers`, a map from function name to SSA value-to-register assignments,
plus the required `instruction_selection.scalar_select` choice. The new plan is
discovered through the same artifact-based tool family. V1 and v2 keep their
existing byte realizations; an empty v3 value map with the branch selection and
canonical choices emits the same object as canonical lowering.

```json
{
  "schema": "hepta.hia.agent.machine-plan.v3",
  "core_sha256": "<canonical Core SHA-256>",
  "block_order": {},
  "function_order": ["plus7"],
  "scratch_registers": {"r10": "r10", "r11": "r11"},
  "instruction_selection": {
    "move_immediate": "mov32_if_exact",
    "alu_immediate": "imm8_if_exact",
    "scalar_select": "cmov_scalar"
  },
  "function_alignment": 16,
  "value_registers": {
    "plus7": {"x": "r12", "seven": "r13", "answer": "r14"}
  }
}
```

The referenced `plus7` Core in the qualification fixture has parameter `x`,
constant `seven` and output `answer`; arbitrary names are not accepted merely
because they appear in a plan.

| Choice | Independent admission and preservation rule |
| --- | --- |
| Scalar locations | Assign existing integer or boolean SSA definitions to `rbx`, `r12`, `r13`, `r14` or `r15`. Resource pairs, owners, loans, `unit`, unknown values and other registers are rejected. Unassigned values use the canonical stack locations. |
| Register reuse | Recompute closed-block live intervals from the verified Core. Definitions occupy their own point even when dead; inputs and outputs at the same instruction interfere. Two overlapping intervals cannot share a register. Different blocks can reuse registers because all incoming values are explicit parameters. |
| Edges and loops | Stage every source argument before assigning any target parameter. This preserves parallel copies, register permutations and self-loops. Target parameters cannot share a register even when a parameter is unused. |
| Calls and returns | Save each used callee-saved register before assigning parameters; restore it after writing all results on every ordinary return. This applies to internal calls, multiple results, recursion and external libc calls. Traps retain abort semantics. |
| Scalar selection | Explicit `branch` retains the old lowering. `cmov_scalar` uses `TEST`, flag-preserving scalar MOV loads, and register-only 64-bit CMOV. Core has already evaluated the scalar operands; no speculative pointer load or new side effect is introduced. |

These are real value-location choices: selected scalar loads and stores become
register moves. The initial implementation reserves the old scalar stack slots
and uses additional disjoint slots for callee saves, so it does not claim frame
compaction. Saving registers can increase both frame size and executable bytes.
The backend validates the Agent's assignment; it does not pick registers, insert
unrequested spill decisions or run an allocation/profitability search. General
caller-saved allocation, vectors, rematerialization and whole-backend formal
refinement remain outside this profile.

## Reviewed v4 caller-clobbered leaf values

`hepta.hia.agent.machine-plan.v4` retains all v3 fields and choices and adds
`r8` and `r9` to the explicit scalar value map. This is opt-in: v3 still rejects
these two registers, and an empty canonical v4 plan retains canonical bytes.
The backend does not select a plan or replace the default lowering.

Caller-clobbered leaf assignments are explicit choices under the v4 tag.
Selecting them does not assert that they improve this workload. Performance
must be measured for the exact emitted image, including the surrounding
validation, build and invocation costs.

The independent checker applies these additional rules to the **whole function**
whenever any value uses `r8` or `r9`:

| Boundary | Required preservation rule |
| --- | --- |
| Opcode inventory | Every operation belongs to the fixed `LEAF_VALUE_OPS` set: the reviewed scalar integer/bit/boolean/comparison/cast/select forms and `buffer.len/load/store`. Newly registered Core operations are not automatically admitted. |
| Calls | All Core calls are rejected, including self calls, calls on an untaken path and calls where the selected value appears dead. Allocation, deallocation, owner operations, chains and libc-backed bulk operations are excluded. |
| Implicit registers | `buffer.swap` is excluded because its canonical lowering writes `r8`. Accepted scalar lowering uses `rax/rcx/rdx/r10/r11` scratch. Address/length checks, shifts, comparison flags, edge staging and return-array writes do not implicitly overwrite `r8/r9`. |
| Types | Assigned values remain existing integers or booleans. Parameters may be scalars or borrowed buffers; returns must be scalars. Capability pairs and owners cannot occupy these scalar registers. |
| Lifetimes | The existing inclusive closed-block interference checker applies to all seven available registers. Dead definitions and parameters still occupy their definition points. Unassigned values stay in their canonical stack slots. |
| ABI and edges | External argument registers are copied to the wrapper's array before the internal call. Internal parameter preload reads that array with fixed scratch; block edges stage all sources before target writes. Only the five callee-saved registers are saved/restored; `r8/r9` are caller-clobbered. |
| Failure path | Checked arithmetic and bounds keep the original trap path: `abort` followed by `UD2`, with no returning continuation across which a selected value must survive. Successful paths contain no call in an admitted leaf function. |

For example, the v3 `plus7` fixture can use
`{"plus7":{"x":"r8","seven":"r9","answer":"r12"}}` under the v4 tag;
its same Core-bound plan under the v3 tag remains invalid.

Independent native checks cover every admitted scalar opcode with both selected
inputs still live afterward, both select encodings, parallel loop permutations,
multiple internal results, canonical spills, dirty narrow incoming registers,
fifth/sixth and stack arguments, stack page probes and all callee saves. Borrowed
byte load/store/length observations check actual bytes and pre-write aborts;
checked arithmetic retains abort behavior. These finite observations and the
separate lifetime/leaf witness do not establish a whole-backend proof.

The native workload campaign retains canonical, two-register v3/v4, full
five-register v3 and seven-register v4 plans. The noncanonical arms use identical
immediate, scratch, layout and select choices; the two-register pair assigns the
same SSA values to isolate the register-class change. Source/plan validation,
emission, linking, fresh-process application and canonical fallback costs are
recorded separately. The result remains specific to the measured host/workload;
it neither establishes general speedup nor measures NDU or model effectiveness.

## Use through the existing tool family

1. Read `hia_describe` and its `plan_schema` resource.
2. Retain the Core-bound plan with `hia_artifact`.
3. Request `hia_verify` with `subject.kind=agent_machine_plan` and the exact
   plan/profile/target references.
4. Pass that same receipt to `hia_emit` with `codegen.kind=agent_plan`.
5. Recheck actual encoding, then run the complete frozen workload through
   `hia_evaluate`. Adoption still requires the existing evidence and generation
   checks.

The eleven-tool wire catalog is unchanged: plans are referenced artifacts and
their versioned schema is discovered. Worker/backend hashes and derived profile
identities change with this implementation. Old receipts cannot authorize a new
implementation or a different plan.

## Evidence boundaries and cost observations

The receipt retains separate block-layout, scratch-register, instruction-form
and function-layout checks. V3 additionally retains a per-function, per-block
register-lifetime witness and a separate scalar-select check. `same_slots` is
false when any scalar is placed in a register, even if rounded frame sizes happen
to match; both actual frame maps and `same_frame_sizes` are recorded. Each check
is a finite preservation check relative to the
canonical lowering and encoder. The receipt explicitly keeps universal
Core-to-machine refinement unproved.

Current qualification must bind every plan to the exact Core and installed
implementation, retain the complete object and final image, and compare the
whole frozen workload with the independent reference. Required controls cover
overlapping live intervals, resource assignments, ABI-register assignments,
parallel edge copies, nested calls, multiple results, dirty incoming argument
bits, stack arguments, callee saves and pre-write traps. A failed or incomplete
arm remains in the result.

Emission, rederivation, linking, publication, fresh-process application and
call time are separate measured costs. Resetting input, hashing all output
bytes or starting a process cannot disappear from total cost because a narrow
call timer excludes it. Interleaved timing observations remain specific to the
measured host, workload and exact plans.

Historical campaigns and their hosted timing boundaries are retained in the
single [qualification provenance](HIA_HISTORICAL_QUALIFICATION_PROVENANCE.json).
They do not qualify current native bytes. Source-bound and installed-interface
results are indexed by [CURRENT.md](CURRENT.md).

A smaller image or faster synthetic call does not establish full search
economics, model effectiveness or task benefit. Unknown model, discovery,
failed-search and future-use costs remain unknown. The separate
[planning and cost contract](HIA_AGENT_MACRO_POLICY.md) requires the original
budget and actual task evidence.
