from pathlib import Path
import sys,struct,json,hashlib
base=Path(sys.argv[1]);package=base/'installed-package';sys.path.insert(0,str(package))
from hepta.hia_core_json_bytes_native import SOURCE as CORE_SOURCE, installed_core_json_bytes
from hepta.hia_nominal_json_native import installed_nominal_json
from hepta.hia_nominal_tokens_native import SOURCE as TOKEN_SOURCE, installed_nominal_tokens
import hepta
assert Path(hepta.__file__).is_relative_to(package)
assert CORE_SOURCE==package/'hepta/_data/examples/hia_bootstrap/core_json_bytes.hepta'
assert TOKEN_SOURCE==package/'hepta/_data/examples/hia_bootstrap/nominal_tokens.hepta'
front=installed_core_json_bytes(base/'core-json/front-manifest.json')
nominal=installed_nominal_json(base/'core-json/nominal-manifest.json')
result=front.decode(b'{"z":1,"a":2}',nominal)
assert result.canonical.canonical_bytes==b'{"a":2,"z":1}'
tokens=installed_nominal_tokens(base/'nominal-tokens/manifest.json');wire=struct.pack('<2Q',0,0);payload=struct.pack('<2Q',4,0);magic=int.from_bytes(b'HIACFO01','little')
with tokens.session() as session:
 session.begin(wire,magic,0)
 assert session.feed(struct.pack('<8Q',magic,0,0,1,0,0,0,len(payload))+payload) is True
 assert session.canonical()==b'null'
 assert session.packet()==wire
for name,module in sys.modules.items():
 if name=='hepta' or name.startswith('hepta.'):
  file=getattr(module,'__file__',None)
  if file is not None: assert Path(file).is_relative_to(package),(name,file)
print(json.dumps({'status':'INSTALLED_COMPONENT_CONTROLS_PASS','native_core_canonical_bytes':result.canonical.canonical_bytes.decode(),'native_core_image_sha256':front.image_sha256,'native_nominal_image_sha256':nominal.image_sha256,'native_token_image_sha256':tokens.image_sha256,'source_resources':{str(p.relative_to(package)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [CORE_SOURCE,TOKEN_SOURCE]},'all_product_imports_from_installed_package':True,'source_checkout_fallback':False,'scope':'BOOTSTRAP_DEVELOPMENT_ONLY','whole_stack_rewritten_in_hia':False},sort_keys=True))
