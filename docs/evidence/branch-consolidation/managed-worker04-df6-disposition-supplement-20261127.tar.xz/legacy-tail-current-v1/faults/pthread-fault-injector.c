
#define _GNU_SOURCE
#include <pthread.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdatomic.h>
static uintptr_t lo,hi;
static _Atomic unsigned long creates,joins;
static _Atomic int create_error,join_error;
void bg_thread_fault_arm(uintptr_t a,uintptr_t b,int c,int j) {
 lo=a;hi=b;atomic_store(&creates,0);atomic_store(&joins,0);
 atomic_store(&create_error,c);atomic_store(&join_error,j);
}
unsigned long bg_thread_fault_count(unsigned long op) {
 return op?atomic_load(&joins):atomic_load(&creates);
}
int pthread_create(pthread_t *t,const pthread_attr_t *a,void *(*f)(void *),void *p) {
 uintptr_t pc=(uintptr_t)__builtin_return_address(0);
 if(pc>=lo && pc<hi) {
  atomic_fetch_add(&creates,1);int e=atomic_exchange(&create_error,0);if(e)return e;
 }
 int (*real)(pthread_t *,const pthread_attr_t *,void *(*)(void *),void *)=dlsym(RTLD_NEXT,"pthread_create");
 return real(t,a,f,p);
}
int pthread_join(pthread_t t,void **v) {
 uintptr_t pc=(uintptr_t)__builtin_return_address(0);
 if(pc>=lo && pc<hi) {
  atomic_fetch_add(&joins,1);int e=atomic_exchange(&join_error,0);if(e)return e;
 }
 int (*real)(pthread_t,void **)=dlsym(RTLD_NEXT,"pthread_join");
 return real(t,v);
}
