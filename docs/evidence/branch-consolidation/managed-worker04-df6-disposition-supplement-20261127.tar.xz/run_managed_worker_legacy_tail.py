from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/589c0a6dd85b')
REPO = ROOT / 'hepta-managed-worker-alive-20261127-589c'
EVIDENCE = ROOT / 'hepta-managed-worker-alive-evidence-20261127'
BUILD = EVIDENCE / 'private03-v2/build'
DEST = EVIDENCE / 'legacy-tail-current-v1'
DEST.mkdir(exist_ok=False)


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


fault = DEST / 'faults'
fault.mkdir()
pack = DEST / 'pack'
pack.mkdir()
inputs = []
for old, new in [
    ('multiversion_background_worker_packer.flat', 'multiversion_background_worker_packer.flat'),
    ('multiversion_background_worker.flat', 'multiversion_background_worker.flat'),
    ('worker.o', 'worker-component.o'),
]:
    source = BUILD / old
    target = pack / new
    shutil.copyfile(source, target)
    assert source.read_bytes() == target.read_bytes()
    inputs.append(pin(source))

commands = [
    ('faults', [sys.executable, '-u', '-m', 'tools.qualify_hia_multiversion_background_worker_faults',
                '--image', str(BUILD / 'worker.so'), '--queue', str(BUILD / 'queue.so'),
                '--values', str(BUILD / 'values.so'), '--future', str(BUILD / 'future.so'),
                '--directory', str(fault)]),
    ('pack', [sys.executable, '-u', '-m', 'tools.qualify_hia_multiversion_background_worker_pack',
              '--directory', str(pack), '--source', str(REPO)]),
]
rows = []
for name, command in commands:
    started = time.monotonic()
    result = subprocess.run(command, cwd=REPO, capture_output=True, timeout=60)
    (DEST / (name + '.stdout')).write_bytes(result.stdout)
    (DEST / (name + '.stderr')).write_bytes(result.stderr)
    rows.append({'name': name, 'command': command, 'returncode': result.returncode,
                 'seconds': time.monotonic() - started,
                 'stdout': pin(DEST / (name + '.stdout')), 'stderr': pin(DEST / (name + '.stderr'))})
    print(json.dumps(rows[-1]), flush=True)

result = {'schema': 'hia.managed-worker-original-tail-regression.v1',
          'source_commit': '75507363f89191897ed4b26b83e6d5aaca926166',
          'whole_background_closed': False, 'cold_qualification': False,
          'private03_build_reused_exact': pin(BUILD / 'build.json'),
          'inputs': inputs + [pin(BUILD / (name + '.so')) for name in ('worker', 'queue', 'values', 'future')],
          'qualifier_sources': [pin(REPO / ('tools/qualify_hia_multiversion_background_worker_' + name + '.py'))
                                for name in ('faults', 'pack')],
          'runs': rows, 'passed': all(row['returncode'] == 0 for row in rows)}
for name, path in [('faults', fault / 'pthread-fault-qualification.json'), ('pack', pack / 'packer-qualification.json')]:
    if path.exists():
        result[name] = {'file': pin(path), 'report': json.loads(path.read_text())}
(DEST / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'receipt': str(DEST / 'receipt.json')}), flush=True)
sys.exit(0 if result['passed'] else 1)
