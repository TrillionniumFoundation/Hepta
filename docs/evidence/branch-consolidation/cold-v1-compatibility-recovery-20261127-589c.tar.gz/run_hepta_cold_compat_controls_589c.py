import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/589c0a6dd85b/Hepta')
OUT = pathlib.Path('/tmp/hepta-cold-compat-recovery-589c')
compiler = '/tmp/hepta-slot-recovered-branches-589c/lifecycle-evidence/B1.image.bin'
report = {'schema': 'hia-cold-v1-encoding-component-observer-v1', 'whole_cold_qualified': False,
          'whole_rewrite_qualified': False, 'commands': []}
for variant, selection in [('before', ['--case', 'valid-current-snapshot', '--case', 'valid-cold-utf8-bom']), ('after', [])]:
    argv = [sys.executable, '-B', '-m', 'tools.qualify_hia_release_cold_admit',
            '--image', str(OUT / (variant + '-native.elf')), '--compiler', compiler,
            '--output', str(OUT / (variant + '-cases')), '--contract-root', str(ROOT),
            '--native-source-authority', str(ROOT / 'docs/HIA_NATIVE_SOURCE_AUTHORITY.json'), *selection]
    start = time.monotonic()
    with (OUT / (variant + '.stdout')).open('xb') as stdout, (OUT / (variant + '.stderr')).open('xb') as stderr:
        process = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=1800)
    entry = {'argv': argv, 'cwd': str(ROOT), 'actual_returncode': process.returncode, 'wall_seconds': time.monotonic() - start}
    for kind in ['stdout', 'stderr']:
        raw = (OUT / (variant + '.' + kind)).read_bytes()
        entry[kind] = {'path': variant + '.' + kind, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    report['commands'].append(entry)
    (OUT / 'observer.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'variant': variant, 'returncode': process.returncode, 'seconds': entry['wall_seconds']}), flush=True)
