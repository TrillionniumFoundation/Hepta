import hashlib
import json
import pathlib
import struct
import sys
import types

ROOT = pathlib.Path('/workspace/scratch/589c0a6dd85b/Hepta')
OUT = pathlib.Path('/tmp/hepta-cold-compat-recovery-589c')
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_selfhost import compile_stage
from tools import generate_hia_source_release_cold_admit as current

compiler = pathlib.Path('/tmp/hepta-slot-recovered-branches-589c/lifecycle-evidence/B1.image.bin')
assert hashlib.sha256(compiler.read_bytes()).hexdigest() == 'acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
authority = ROOT / 'docs/HIA_NATIVE_SOURCE_AUTHORITY.json'
original_path = OUT / 'generate_hia_source_release_cold_admit.py.before'
original = types.ModuleType('original_cold_compat_before')
original.__file__ = str(original_path)
exec(compile(original_path.read_bytes(), str(original_path), 'exec'), vars(original))
record = {'schema': 'hia-cold-v1-encoding-component-build-v1',
          'source_head_before_changes': 'e0cf34e25a37eb14447e402c062c660b482d77f2',
          'source_branch_recovered': '31de5da7ffcfcefc35a54b87d415d3af66d69791',
          'development_compiler': {'path': str(compiler), 'sha256': hashlib.sha256(compiler.read_bytes()).hexdigest()},
          'source_authority_sha256': hashlib.sha256(authority.read_bytes()).hexdigest(),
          'current_native_v2_source_sha256': hashlib.sha256((ROOT / 'examples/hia_bootstrap/source_release_cold_admit.hepta').read_bytes()).hexdigest(),
          'whole_cold_qualified': False, 'whole_rewrite_qualified': False, 'variants': {}}
packer_source = (ROOT / 'examples/hia_bootstrap/source_build_packer.hepta').read_bytes()
refusal_source = (ROOT / 'examples/hia_bootstrap/cold_build_refusal.hepta').read_bytes()
packer, packer_receipt = compile_stage(OUT, 'source-build-packer', compiler, packer_source)
refusal, refusal_receipt = compile_stage(OUT, 'cold-build-refusal', compiler, refusal_source)
record['packer'] = packer_receipt
record['refusal'] = refusal_receipt
for name, module in [('before', original), ('after', current)]:
    source, author = module.render(ROOT, native_source_authority=authority)
    source = source.encode()
    (OUT / (name + '.hepta')).write_bytes(source)
    flat, compile_receipt = compile_stage(OUT, name + '-policy', compiler, source)
    pieces = [flat.read_bytes(), refusal.read_bytes(), refusal.read_bytes()]
    packet = struct.pack('<8s3Q', b'HIASBL01', *map(len, pieces)) + b''.join(pieces)
    image, pack_receipt = compile_stage(OUT, name + '-native', packer, packet, output_extension='.elf')
    assert image.read_bytes().startswith(b'\x7fELF')
    image.chmod(0o500)
    record['variants'][name] = {'author': author, 'source_sha256': hashlib.sha256(source).hexdigest(),
                               'compile': compile_receipt, 'pack': pack_receipt,
                               'executable': str(image), 'executable_sha256': hashlib.sha256(image.read_bytes()).hexdigest()}
    (OUT / 'build.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'variant': name, 'source_bytes': len(source), 'native_bytes': image.stat().st_size, 'image': str(image)}), flush=True)
