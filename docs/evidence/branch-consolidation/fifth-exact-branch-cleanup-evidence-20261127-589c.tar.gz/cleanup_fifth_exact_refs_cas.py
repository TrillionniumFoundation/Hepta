import hashlib,json,os,pathlib,re,subprocess,sys,time
root=pathlib.Path('/Users/qianqi/work/hia-codex-macos-20261127-589c')
mode='hepta_fifth'
gh='/opt/homebrew/bin/gh'
plan_path=root/'hepta-fifth-exact-branch-retirement-plan.json'
assert hashlib.sha256(plan_path.read_bytes()).hexdigest()=='a88e79cc1f57ef5208c44f4f33d1a0b760da5700e5696a31c90c56003858641b'
p=json.loads(plan_path.read_text())
assert p['repository']=='TrillionniumFoundation/Hepta' and len(p['delete'])==3
assert p['candidate']=='06d21f6032d7b3a946b1d6581a13c5cfd5fa4375'
name='Hepta';rows=p['delete'];keep=p['keep'];candidate=p['candidate']
assert len({x['ref'] for x in rows})==len(rows)
for row in rows:
    assert row['ref']=='refs/heads/'+row['branch']
    assert re.fullmatch('[0-9a-f]{40}',row['sha'])
    assert row['branch'] not in keep
out=root/(mode+'-atomic-cas-cleanup-receipt.json')
owner=root/(mode+'-cleanup-owner-20261127-589c')
owner.mkdir()
receipt={'repository':'TrillionniumFoundation/'+name,'plan_path':str(plan_path),'plan_sha256':hashlib.sha256(plan_path.read_bytes()).hexdigest(),'candidate_ancestry_proof':candidate,'transport':'GitHub GraphQL updateRefs through existing gh authentication','semantics_document':'https://docs.github.com/en/graphql/reference/git#updaterefs','server_beforeOid_CAS':True,'atomic_each_batch':True,'force':False,'requested':len(rows),'batches':[],'complete':False}
def save(): out.write_text(json.dumps(receipt,indent=2)+chr(10))
def graphql(query,variables,label,mutation=False):
    payload={'query':query,'variables':variables}
    request=root/(mode+'-cas-'+label+'-request.json')
    response=root/(mode+'-cas-'+label+'-response.json')
    request.write_text(json.dumps(payload,indent=2)+chr(10))
    result=subprocess.run([gh,'api','graphql','--input',str(request)],capture_output=True,text=True,timeout=90)
    response.write_text(result.stdout)
    (root/(mode+'-cas-'+label+'-stderr.log')).write_text(result.stderr)
    data=json.loads(result.stdout) if result.stdout else {}
    record={'returncode':result.returncode,'request':str(request),'request_sha256':hashlib.sha256(request.read_bytes()).hexdigest(),'response':str(response),'response_sha256':hashlib.sha256(response.read_bytes()).hexdigest(),'errors':data.get('errors',[])}
    if not mutation and (result.returncode or data.get('errors')): raise RuntimeError('read query failed: '+label)
    return data,record
def read_refs(refs,label):
    fields=' '.join('r'+str(i)+':ref(qualifiedName:'+json.dumps(ref)+'){name target{oid}}' for i,ref in enumerate(refs))
    query='query { repository(owner:"TrillionniumFoundation",name:'+json.dumps(name)+'){id defaultBranchRef{name target{oid}} refs(refPrefix:"refs/heads/",first:1){totalCount} '+fields+'} }'
    data,record=graphql(query,{},label)
    repo=data['data']['repository'];assert repo and repo['defaultBranchRef']['name']=='main'
    values={ref:(repo['r'+str(i)]['target']['oid'] if repo['r'+str(i)] else None) for i,ref in enumerate(refs)}
    return repo,values,record
try:
    repository,before_keep,keep_record=read_refs(['refs/heads/'+x for x in keep],'keep-before')
    assert before_keep==p['keep_refs'], 'keep refs differ from the original plan'
    assert before_keep['refs/heads/main'] is not None
    assert before_keep['refs/heads/codex/hia-native-followthrough-20261126-620a']==candidate
    receipt['before_heads_count']=repository['refs']['totalCount']
    receipt['keep_before']=before_keep
    receipt['keep_readback_before']=keep_record
    rid=repository['id']
    for start in range(0,len(rows),50):
        batch=rows[start:start+50];number=start//50+1
        _,current,read_record=read_refs([x['ref'] for x in batch],'batch-'+str(number)+'-before')
        eligible=[x for x in batch if current[x['ref']]==x['sha']]
        absent=[x['ref'] for x in batch if current[x['ref']] is None]
        moved=[{'ref':x['ref'],'expected':x['sha'],'observed':current[x['ref']]} for x in batch if current[x['ref']] not in (None,x['sha'])]
        entry={'number':number,'requested':len(batch),'eligible':len(eligible),'preexisting_absent':absent,'moved_and_retained':moved,'before_readback':read_record}
        receipt['batches'].append(entry);save()
        if eligible:
            request_id=mode+'-merged-exact-cas-20261127-589c-'+str(number)
            updates=[{'name':x['ref'],'beforeOid':x['sha'],'afterOid':'0'*40,'force':False} for x in eligible]
            query='mutation($input:UpdateRefsInput!){ updateRefs(input:$input){clientMutationId} }'
            variables={'input':{'repositoryId':rid,'refUpdates':updates,'clientMutationId':request_id}}
            data,record=graphql(query,variables,'batch-'+str(number)+'-mutation',mutation=True)
            entry['mutation']=record;save()
            if record['returncode']==0 and not record['errors']:
                assert data['data']['updateRefs']['clientMutationId']==request_id
                entry['mutation_accepted']=True
            else: entry['mutation_accepted']=False
        _,after,record=read_refs([x['ref'] for x in batch],'batch-'+str(number)+'-after')
        entry['after_readback']=record
        entry['absent_after']=[ref for ref,sha in after.items() if sha is None]
        entry['retained_after']={ref:sha for ref,sha in after.items() if sha is not None}
        save();print(json.dumps({'mode':mode,'batch':number,'absent':len(entry['absent_after']),'retained':len(entry['retained_after']),'accepted':entry.get('mutation_accepted')}),flush=True)
    final={}
    for start in range(0,len(rows),50):
        _,values,_=read_refs([x['ref'] for x in rows[start:start+50]],'final-'+str(start//50+1))
        final.update(values)
    repository,after_keep,record=read_refs(['refs/heads/'+x for x in keep],'keep-after')
    receipt['after_heads_count']=repository['refs']['totalCount']
    receipt['final_absent']=[ref for ref,sha in final.items() if sha is None]
    receipt['final_retained']={ref:sha for ref,sha in final.items() if sha is not None}
    receipt['keep_after']=after_keep
    receipt['existing_keep_refs_preserved']=all(after_keep[ref] is not None for ref,sha in before_keep.items() if sha is not None)
    receipt['keep_refs_unchanged']=before_keep==after_keep
    receipt['complete']=len(receipt['final_absent'])==len(rows) and receipt['keep_refs_unchanged']
except Exception as error:
    receipt['error']=str(error)
finally:
    save();print(json.dumps({'receipt':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'complete':receipt['complete'],'requested':len(rows),'final_absent':len(receipt.get('final_absent',[])),'error':receipt.get('error')}),flush=True)
