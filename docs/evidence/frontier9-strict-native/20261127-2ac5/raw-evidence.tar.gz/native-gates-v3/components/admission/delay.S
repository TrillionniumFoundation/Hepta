
.intel_syntax noprefix
.global _start
.text
_start:
.Lread:
 xor eax,eax
 xor edi,edi
 lea rsi,[rip+scratch]
 mov edx,65536
 syscall
 test rax,rax
 jg .Lread
.Lsleep:
 mov eax,35
 lea rdi,[rip+duration]
 xor esi,esi
 syscall
 lea r12,[rip+payload]
 mov r13,payload_end-payload
.Lwrite:
 mov eax,1
 mov edi,1
 mov rsi,r12
 mov rdx,r13
 syscall
 cmp rax,-4
 je .Lwrite
 test rax,rax
 jle .Lbad
 add r12,rax
 sub r13,rax
 jne .Lwrite
 xor edi,edi
 jmp .Lexit
.Lbad:
 mov edi,74
.Lexit:
 mov eax,60
 syscall
.section .rodata
duration: .quad 0,500000000
payload:
.incbin "delay-payload.bin"
payload_end:
.bss
.balign 16
scratch: .skip 65536
.section .note.GNU-stack,"",@progbits
