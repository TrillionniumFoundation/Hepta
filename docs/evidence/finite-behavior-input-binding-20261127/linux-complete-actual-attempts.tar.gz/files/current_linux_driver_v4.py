from pathlib import Path
import os,json,hashlib,tarfile,zlib,base64,subprocess,time
R=Path(__file__).resolve().parent;H=R/'domain-v3';H.mkdir(mode=0o700)
with tarfile.open(R/'source-v1.tar.gz') as tf:
 for m in tf.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 tf.extractall(H,filter='data')
S=H/'source';O=H/'qualification';O.mkdir(mode=0o700);T=H/'tmp';T.mkdir(mode=0o700)
raw=(R/'source-current-delta-v3.zlib').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='b4d481b88d893eafcb523b84cd30c30eaeeaba1ef825352297de6e049c5996ae'
value=json.loads(zlib.decompress(raw))
for name,row in value['delta'].items():
 p=S/name;data=base64.b64decode(row['base64'],validate=True)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(row['mode'])
def capture():
 result={}
 for name,want in value['pins'].items():
  p=S/name;data=p.read_bytes();got={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':p.stat().st_mode&0o777}
  assert got==want,(name,got,want);result[name]=got
 return result
before=capture()
C=Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/cold/qualification/base/B3.flat')
compiler_raw=C.read_bytes()
assert len(compiler_raw)==641344 and hashlib.sha256(compiler_raw).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
env={k:v for k,v in os.environ.items() if not k.startswith('HEPTA_HIA_')}
env.update({'TMPDIR':str(T),'PYTHONDONTWRITEBYTECODE':'1',
 'HIA_FINITE_BEHAVIOR_CURRENT_EVIDENCE':str(O/'current-business')})
PY='/home/qian-qi/hia-native-caller-selection-20261127-2ac5/original-ci-python-prerequisites-v1/bin/python'
commands=[]
def run(label,args,*,extra=None):
 current=dict(env);current.update(extra or {})
 command=[PY,*args];start=time.monotonic()
 (O/(label+'.start.json')).write_text(json.dumps({'command':command,'start':time.time(),'source_scope':'current463 unless explicitly predecessor'},indent=2)+'\n')
 with (O/(label+'.stdout')).open('xb') as out,(O/(label+'.stderr')).open('xb') as err:
  process=subprocess.Popen(command,cwd=S,env=current,stdout=out,stderr=err)
  (O/(label+'.pid.json')).write_text(json.dumps({'pid':process.pid,'command':command})+'\n')
  code=process.wait()
 result={'label':label,'returncode':code,'seconds':time.monotonic()-start,'command':command,
  'stdout_sha256':hashlib.sha256((O/(label+'.stdout')).read_bytes()).hexdigest(),
  'stderr_sha256':hashlib.sha256((O/(label+'.stderr')).read_bytes()).hexdigest()}
 (O/(label+'.terminal.json')).write_text(json.dumps(result,indent=2)+'\n');commands.append(result)
 assert capture()==before and C.read_bytes()==compiler_raw
 print(json.dumps(result),flush=True)
 print((O/(label+'.stderr')).read_text()[-6000:],flush=True)
 return code
code=run('host-and-current-source24',['-m','unittest','-v',
 'tests.test_hia_program_runtime_batch','tests.test_hia_behavior_source_identity',
 'tests.test_hia_behavior_source_history'])
if code==0:
 code=run('native-build',['-c',
  'from pathlib import Path; from tools.build_hia_service_verification import build; print(build(Path('+repr(str(O/'native'))+'),Path('+repr(str(C))+'),development=True))'])
if code==0:
 code=run('current-native12',['-m','unittest','-v',
  'tests.test_hia_behavior_native_identity','tests.test_hia_service_verification_current_inputs'],
  extra={'HIA_FINITE_BEHAVIOR_MANIFEST':str(O/'native/manifest.json')})
if code==0:
 # The original supervisor owns its 600 / 1800 s limits. This outer driver
 # introduces no shorter timeout and does not relabel partial child output.
 code=run('original-three-source-domain',['-m','unittest','-v',
  'tests.test_hia_service_verification_native.ServiceVerificationSourceTests'],
  extra={'HEPTA_HIA_SERVICE_VERIFICATION_SOURCE_EVIDENCE':str(O/'original-methods')})
after=capture()
report={'scope':'current463 actual inputs and separate complete predecessor446/185 source domain',
 'returncode':code,'commands':commands,'source_before':before,'source_after':after,
 'compiler_sha256':hashlib.sha256(compiler_raw).hexdigest(),'compiler_usage':'DEVELOPMENT_COMPONENT',
 'whole_stack_qualified':False}
(O/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
raise SystemExit(code)
