from pathlib import Path
import os,sys,json,hashlib
R=Path('/home/qian-qi/hia-finite-behavior-current-20261127-2ac5')
S=R/'domain-v3/source';O=R/'current-packets-v2';O.mkdir(mode=0o700)
os.environ['TMPDIR']=str(R/'domain-v3/tmp')
sys.path.insert(0,str(S))
from tests import hia_service_verification_controls as controls
from tools.build_hia_service_verification import INPUTS
before={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in INPUTS}
manifest=R/'domain-v3/qualification/native/manifest.json'
child="""import sys,json
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,sys.argv[1])
from tests import hia_service_verification_controls as controls
from hepta import hia_service_verification_native as native
from hepta import hia_service_verification_protocol as protocol
image=native.installed_service_verification(sys.argv[2])
O=Path(sys.argv[3]);O.mkdir(mode=0o700)
report=controls.packets(image,SimpleNamespace(output=O))
raw=(O/'complete-packets.json').read_bytes()
rows=json.loads(raw)
observed_ports={int(x['id'].split('.')[0][4:]) for x in rows if x['id'].startswith('port')}
assert observed_ports==set(range(1,464))
assert len(protocol.PORTS)==463 and len(protocol.MODE_RANGES)==26
assert report['VM_entries']==report['count']==len(rows)
assert report['complete_VM_native_bytes_equal'] is True
controls.write(O/'current-report.json',{'scope':'CURRENT_463_PORT_26_MODE_VM_NATIVE_COMPLETE_BYTES','original_function_report':report,'current_port_count':463,'mode_count':26,'current_port_ids':sorted(observed_ports),'whole_stack_qualified':False})
print(json.dumps({'count':report['count'],'actual_VM_entries':report['VM_entries'],'current_port_count':463,'mode_count':26}),flush=True)
"""
stdout,stderr,receipt=controls.run_process(O,'current463',['-c',child,S,manifest,O/'observations'],env=controls.clean_environment(),timeout=180)
after={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in INPUTS}
assert before==after
controls.write(O/'terminal.json',{'scope':'DEVELOPMENT_COMPONENT current463 protocol','child':receipt,'source_before':before,'source_after':after})
print(stdout.decode());print(stderr.decode())
