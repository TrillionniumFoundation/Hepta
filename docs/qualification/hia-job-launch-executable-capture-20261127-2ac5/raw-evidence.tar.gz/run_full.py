from pathlib import Path
from hashlib import sha256
import json, os, subprocess, sys, time
root=Path(__file__).resolve().parent
os.chdir(root)
command=[sys.executable,str(root/"tools/qualify_hia_job_launch.py"),"--executable",str(root/"bin/hia-job-launch"),"--runtime-source",str(root/"runtime-fb42bd6-jobs.rs"),"--encoder",str(root/"bin/hia-worker-prepare"),"--writer",str(root/"bin/hia-job-receipt"),"--supervisor",str(root/"bin/hia-job-supervisor"),"--output",str(root/"full-launch"),"--large"]
started=time.monotonic()
with (root/"full-launch.log").open("xb") as log:
    done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,cwd=root,timeout=180)
result=dict(returncode=done.returncode,seconds=time.monotonic()-started,log_sha256=sha256((root/"full-launch.log").read_bytes()).hexdigest())
report=root/"full-launch/result.json"
if report.is_file():
    raw=report.read_bytes(); data=json.loads(raw)
    result.update(status=data["status"],success=data["success"],cases=data["cases"],report_sha256=sha256(raw).hexdigest())
(root/"full-launch-status.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result),flush=True)
if done.returncode: print((root/"full-launch.log").read_text()[-4000:],flush=True)
raise SystemExit(done.returncode)
