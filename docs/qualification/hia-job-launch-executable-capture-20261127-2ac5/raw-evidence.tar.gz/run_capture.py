from pathlib import Path
from hashlib import sha256
import json, os, subprocess, sys, time
root=Path(__file__).resolve().parent
expected=[{"remote":"tools/qualify_hia_job_launch.py","bytes":25488,"sha256":"5734addfe83a2727abcce40b79c7a54c95ea2d7f1d47560b8c38b76cfa677a36"},{"remote":"tools/hia_job_launch_executable_fixture.c","bytes":1673,"sha256":"6b9bb1d24c8127a483147f428f9534fa292e9e4ac83b93e4232d75f7db4ff200"},{"remote":"tests/test_hia_subprocess.py","bytes":24212,"sha256":"da335f43c04decbe92a2ae57f918175c7ef309892dd155aab5ecf14b833e770e"},{"remote":"runtime-fb42bd6-jobs.rs","bytes":261395,"sha256":"b90d2e7985dfa35bbc7b4e05ea19783daa22e2157aa67c089fbfbd543b1df659"},{"remote":"bin/hia-job-launch","bytes":522392,"sha256":"d5cfd680842886bc54ce25ed9d06d96ab6f9eb3c1d54836791b08ace2ae1c8f3"},{"remote":"bin/hia-job-launch-before","bytes":511175,"sha256":"c4982dffd119cf84db8cda869915ab053718dedf9466ff0739dcdf52b90a36bb"},{"remote":"bin/hia-worker-prepare","bytes":303542,"sha256":"9e5fc00d390866c931fcf4fb9d1a826a44d82e0cb9458c16849daad679cf188e"},{"remote":"bin/hia-job-receipt","bytes":148328,"sha256":"9dee9dfd7eba8e1d16fe73aaa0bbac0c750ee5359edf53694922045a4d6fd8b1"},{"remote":"bin/hia-job-supervisor","bytes":412399,"sha256":"896700a2b35c67ea1deefcd88c794b2dce612a51471f15a15c903d3b8ad5f11e"}]
for row in expected:
    path=root/row["remote"]
    raw=path.read_bytes()
    assert len(raw)==row["bytes"] and sha256(raw).hexdigest()==row["sha256"], row
    if row["remote"].startswith("bin/"): path.chmod(0o500)
(root/"input-identity.json").write_text(json.dumps(expected,indent=2)+"\n")
base=[sys.executable,str(root/"tools/qualify_hia_job_launch.py"),"--runtime-source",str(root/"runtime-fb42bd6-jobs.rs"),"--encoder",str(root/"bin/hia-worker-prepare"),"--writer",str(root/"bin/hia-job-receipt"),"--supervisor",str(root/"bin/hia-job-supervisor")]
names=["workload-symlink"]+["workload-entry-"+x for x in ("regular","relative-target","relative-selection","chain","parent","dotdot","surrogate")]+["workload-"+x for x in ("no-execute","effective-denied","group-writable","world-writable","dangling","cycle")]+["workload-race-"+x for x in ("retarget","replace-same-target")]+["workload-system-shell"]
observations=[]
for label,image,cases in [("before-symlink","hia-job-launch-before",["workload-symlink"]),("before-no-execute","hia-job-launch-before",["workload-no-execute"]),("after-capture","hia-job-launch",names)]:
    command=base+["--executable",str(root/"bin"/image),"--output",str(root/label)]
    for case in cases: command+=["--case",case]
    start=time.monotonic()
    with (root/(label+".log")).open("xb") as log:
        done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,cwd=root,timeout=60)
    rows=json.loads((root/label/"partial.json").read_bytes())
    assert len(rows)==len(cases)*2,(label,len(rows),done.returncode)
    if label=="before-symlink":
        assert done.returncode==1 and rows[0]["child_started"] and not rows[1]["child_started"],rows
        assert rows[0]["returncode"]==17 and rows[1]["returncode"]==65,rows
    elif label=="before-no-execute":
        assert done.returncode==1 and not rows[0]["child_started"] and rows[1]["child_started"],rows
        assert rows[1]["returncode"]==0,rows
    else:
        assert done.returncode==0,(label,done.returncode)
        report=json.loads((root/label/"result.json").read_bytes())
        assert report["success"] and report["exec_trace_qualified"] and report["cases"]==17,report
        for row in rows:
            if row["lease"]: assert row["lease"]["lease_break_observed"] and row["lease"]["selected_replaced"],row
    observations.append(dict(label=label,returncode=done.returncode,cases=len(rows)//2,seconds=time.monotonic()-start,partial_sha256=sha256((root/label/"partial.json").read_bytes()).hexdigest()))
    print(json.dumps(observations[-1]),flush=True)
    (root/"progress.json").write_text(json.dumps(observations,indent=2)+"\n")
for row in expected:
    assert sha256((root/row["remote"]).read_bytes()).hexdigest()==row["sha256"]
result=dict(status="EXECUTABLE_CAPTURE_COMPONENT_QUALIFIED",cold_qualification=False,public_start_status_qualified=False,observations=observations)
(root/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result),flush=True)
