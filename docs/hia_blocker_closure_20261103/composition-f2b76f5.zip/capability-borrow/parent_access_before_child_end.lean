/-
Sequential Core capability-flow specification. Names are mathematical
naturals; kinds and origins are uninterpreted tags. This proves facts for
ALL finite capability lists and injective maps, without an execution-length
bound. It is not a proof of every instruction, Python, LLVM, FFI, or hardware.
Projection may forget only external capabilities and must keep the selected
graph closed. The trace theorems below compose these edge rules for every
finite trace; they do not model the intervening instructions in a CFG block.
-/
import Lean.Elab.Tactic.Omega

namespace HiaCapabilityRenaming

structure Capability where
  name : Nat
  root : Nat
  parent : Option Nat
  kind : Nat
  external : Bool
  origin : Option Nat
  deriving DecidableEq

def Injective (f : Nat → Nat) : Prop := ∀ a b, f a = f b → a = b

def rename (f : Nat → Nat) (c : Capability) : Capability :=
  { name := f c.name, root := f c.root, parent := c.parent.map f,
    kind := c.kind, external := c.external, origin := c.origin }

def ChildOf (child parent : Capability) : Prop := child.parent = some parent.name

def ExclusiveAlias (mutableKind : Nat) (a b : Capability) : Prop :=
  a.name ≠ b.name ∧ a.root = b.root ∧ (a.kind = mutableKind ∨ b.kind = mutableKind)

def Closed (caps : List Capability) : Prop :=
  ∀ c ∈ caps, (∃ root ∈ caps, root.name = c.root) ∧
    (∀ p, c.parent = some p → ∃ parent ∈ caps, parent.name = p)

theorem name_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).name = f c.name := rfl

theorem kind_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).kind = c.kind := rfl

theorem external_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).external = c.external := rfl

theorem origin_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).origin = c.origin := rfl

theorem name_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).name = (rename f b).name ↔ a.name = b.name := by
  constructor
  · exact inj a.name b.name
  · intro h; exact congrArg f h

theorem root_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).root = (rename f b).root ↔ a.root = b.root := by
  constructor
  · exact inj a.root b.root
  · intro h; exact congrArg f h

theorem parent_map_iff (f : Nat → Nat) (inj : Injective f) (p : Option Nat) (n : Nat) :
    p.map f = some (f n) ↔ p = some n := by
  cases p with
  | none => simp
  | some p =>
      constructor
      · intro h; exact congrArg some (inj p n (Option.some.inj h))
      · intro h; cases h; rfl

theorem child_of_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    ChildOf (rename f a) (rename f b) ↔ ChildOf a b := by
  exact parent_map_iff f inj a.parent b.name

theorem exclusive_alias_iff (f : Nat → Nat) (inj : Injective f)
    (mutableKind : Nat) (a b : Capability) :
    ExclusiveAlias mutableKind (rename f a) (rename f b) ↔
      ExclusiveAlias mutableKind a b := by
  simp only [ExclusiveAlias, ne_eq, name_equal_iff f inj,
             root_equal_iff f inj, kind_preserved]

theorem suspended_iff (f : Nat → Nat) (inj : Injective f)
    (caps : List Capability) (c : Capability) :
    (∃ child ∈ caps.map (rename f), ChildOf child (rename f c)) ↔
      (∃ child ∈ caps, ChildOf child c) := by
  constructor
  · rintro ⟨child, member, relation⟩
    obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
    exact ⟨old, oldMember, (child_of_iff f inj old c).mp relation⟩
  · rintro ⟨child, member, relation⟩
    exact ⟨rename f child, List.mem_map.mpr ⟨child, member, rfl⟩,
      (child_of_iff f inj child c).mpr relation⟩

theorem closed_preserved (f : Nat → Nat) (caps : List Capability)
    (closed : Closed caps) : Closed (caps.map (rename f)) := by
  intro c member
  obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
  obtain ⟨rootExists, parentExists⟩ := closed old oldMember
  obtain ⟨root, rootMember, rootName⟩ := rootExists
  constructor
  · exact ⟨rename f root, List.mem_map.mpr ⟨root, rootMember, rfl⟩,
      congrArg f rootName⟩
  · intro p relation
    cases hp : old.parent with
    | none => simp [rename, hp] at relation
    | some oldParent =>
        have mapped : f oldParent = p := by simpa [rename, hp] using relation
        obtain ⟨parent, parentMember, parentName⟩ := parentExists oldParent hp
        exact ⟨rename f parent, List.mem_map.mpr ⟨parent, parentMember, rfl⟩,
          (congrArg f parentName).trans mapped⟩

theorem number_preserved (f : Nat → Nat) (caps : List Capability) :
    (caps.map (rename f)).length = caps.length := by simp

theorem rename_composes (f g : Nat → Nat) (c : Capability) :
    rename g (rename f c) = rename (fun n => g (f n)) c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

theorem identity_rename (c : Capability) : rename (fun n => n) c = c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

/- The executable helper selects a subset before renaming. Selection is a
filter, so it cannot invent or duplicate capabilities. The explicit retention
premise is exactly the helper's rule for local owners and local loans. -/

def project (keep : Nat → Bool) (caps : List Capability) : List Capability :=
  caps.filter (fun c => keep c.name)

def AdmissibleProjection (caps : List Capability) (keep : Nat → Bool) : Prop :=
  (∀ c ∈ caps, c.external = false → keep c.name = true) ∧ Closed (project keep caps)

def localInventory : List Capability → List (Nat × Option Nat)
  | [] => []
  | c :: rest =>
      if c.external then localInventory rest else (c.kind, c.origin) :: localInventory rest

theorem projected_member (caps : List Capability) (keep : Nat → Bool) (c : Capability) :
    c ∈ project keep caps ↔ c ∈ caps ∧ keep c.name = true := by
  simp [project]

theorem local_retained (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (localCap : c.external = false) : c ∈ project keep caps := by
  exact (projected_member caps keep c).mpr ⟨member, admitted.1 c member localCap⟩

theorem only_external_forgotten (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (forgotten : c ∉ project keep caps) : c.external = true := by
  cases external : c.external with
  | false => exact False.elim (forgotten (local_retained caps keep admitted c member external))
  | true => rfl

theorem local_inventory_projection (caps : List Capability) (keep : Nat → Bool)
    (retained : ∀ c ∈ caps, c.external = false → keep c.name = true) :
    localInventory (project keep caps) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih =>
      have restRetained : ∀ x ∈ rest, x.external = false → keep x.name = true := by
        intro x member external
        exact retained x (List.mem_cons_of_mem c member) external
      have tail := ih restRetained
      cases external : c.external with
      | false =>
          have kept := retained c (by simp) external
          simp [project, localInventory, external, kept] at tail ⊢
          exact tail
      | true =>
          cases kept : keep c.name <;> simp [project, localInventory, external, kept] at tail ⊢
          all_goals exact tail

theorem local_inventory_rename (caps : List Capability) (f : Nat → Nat) :
    localInventory (caps.map (rename f)) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih => simp [localInventory, rename, ih]

/- Parent ranks are witnesses for strict descent, not runtime addresses or
integer counters. Their existence excludes every positive parent cycle. -/

def ParentRanks (caps : List Capability) (rank : Nat → Nat) : Prop :=
  ∀ child ∈ caps, ∀ parent ∈ caps, ChildOf child parent → rank parent.name < rank child.name

def Ranked (caps : List Capability) : Prop := ∃ rank, ParentRanks caps rank

inductive ParentPath (caps : List Capability) : Nat → Nat → Prop where
  | edge {child parent} : child ∈ caps → parent ∈ caps → ChildOf child parent →
      ParentPath caps child.name parent.name
  | trans {a b c} : ParentPath caps a b → ParentPath caps b c → ParentPath caps a c

theorem parent_path_descends (caps : List Capability) (rank : Nat → Nat)
    (ranked : ParentRanks caps rank) {a b : Nat} (path : ParentPath caps a b) :
    rank b < rank a := by
  induction path with
  | edge childMember parentMember relation => exact ranked _ childMember _ parentMember relation
  | trans _ _ left right => exact Nat.lt_trans right left

theorem ranked_no_parent_cycle (caps : List Capability) (ranked : Ranked caps) (name : Nat) :
    ¬ ParentPath caps name name := by
  intro path
  obtain ⟨rank, ordered⟩ := ranked
  exact (Nat.lt_irrefl (rank name)) (parent_path_descends caps rank ordered path)

theorem ranked_projection (caps : List Capability) (keep : Nat → Bool)
    (ranked : Ranked caps) : Ranked (project keep caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((projected_member caps keep child).mp childMember).1
    parent ((projected_member caps keep parent).mp parentMember).1 relation

noncomputable def transportedRank (f rank : Nat → Nat) (name : Nat) : Nat := by
  classical
  exact if witness : ∃ before, f before = name then rank (Classical.choose witness) else 0

theorem transported_rank_at (f rank : Nat → Nat) (inj : Injective f) (name : Nat) :
    transportedRank f rank (f name) = rank name := by
  unfold transportedRank
  split
  next witness =>
    have same : Classical.choose witness = name := inj _ _ (Classical.choose_spec witness)
    rw [same]
  next absent => exact False.elim (absent ⟨name, rfl⟩)

theorem ranked_rename (caps : List Capability) (f : Nat → Nat)
    (inj : Injective f) (ranked : Ranked caps) : Ranked (caps.map (rename f)) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨transportedRank f rank, ?_⟩
  intro child childMember parent parentMember relation
  obtain ⟨oldChild, oldChildMember, rfl⟩ := List.mem_map.mp childMember
  obtain ⟨oldParent, oldParentMember, rfl⟩ := List.mem_map.mp parentMember
  have oldRelation := (child_of_iff f inj oldChild oldParent).mp relation
  simpa only [name_preserved, transported_rank_at f rank inj] using
    ordered oldChild oldChildMember oldParent oldParentMember oldRelation

def Transfer (before after : List Capability) : Prop :=
  ∃ keep f, AdmissibleProjection before keep ∧ Injective f ∧
    after = (project keep before).map (rename f)

theorem transfer_closed {before after : List Capability} (step : Transfer before after) :
    Closed after := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  exact closed_preserved f (project keep before) admitted.2

theorem transfer_local_inventory {before after : List Capability} (step : Transfer before after) :
    localInventory after = localInventory before := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  rw [local_inventory_rename, local_inventory_projection before keep admitted.1]

theorem transfer_ranked {before after : List Capability} (step : Transfer before after)
    (ranked : Ranked before) : Ranked after := by
  obtain ⟨keep, f, _, inj, rfl⟩ := step
  exact ranked_rename (project keep before) f inj (ranked_projection before keep ranked)

inductive EdgeTrace : List Capability → List Capability → Prop where
  | refl (caps) : EdgeTrace caps caps
  | next {before middle after} : EdgeTrace before middle → Transfer middle after →
      EdgeTrace before after

theorem trace_local_inventory {before after : List Capability} (trace : EdgeTrace before after) :
    localInventory after = localInventory before := by
  induction trace with
  | refl => rfl
  | next _ step ih => exact (transfer_local_inventory step).trans ih

theorem trace_closed {before after : List Capability} (trace : EdgeTrace before after)
    (closed : Closed before) : Closed after := by
  cases trace with
  | refl => exact closed
  | next _ step => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | next _ step ih => exact transfer_ranked step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace ranked) name

end HiaCapabilityRenaming

/-
Structural preservation for allocation, borrowing and release. This model
concerns capability graphs, not heap execution or the production checker.
It does not prove alias exclusivity, FFI, calls or concurrent memory safety.
-/

namespace HiaCapabilityLifecycle
open HiaCapabilityRenaming

def Fresh (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name

def Unique (caps : List Capability) : Prop := (caps.map Capability.name).Nodup

def owner (name kind : Nat) : Capability :=
  ⟨name, name, none, kind, false, none⟩

def loan (source : Capability) (name kind : Nat) : Capability :=
  ⟨name, source.root, some source.name, kind, false, source.origin⟩

def erase (name : Nat) (caps : List Capability) : List Capability :=
  caps.filter (fun c => c.name != name)

def Unreferenced (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name → c.root ≠ name ∧ c.parent ≠ some name

def extendRank (rank : Nat → Nat) (name value : Nat) (n : Nat) : Nat :=
  if n = name then value else rank n

theorem fresh_not_member (caps : List Capability) (name : Nat)
    (fresh : Fresh caps name) (c : Capability) (same : c.name = name) : c ∉ caps := by
  intro member
  exact fresh c member same

theorem fresh_parent_absent (caps : List Capability) (name : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    c.parent ≠ some name := by
  intro relation
  obtain ⟨parent, parentMember, parentName⟩ := (closed c member).2 name relation
  exact fresh parent parentMember parentName

theorem extend_rank_old (caps : List Capability) (rank : Nat → Nat) (name value : Nat)
    (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    extendRank rank name value c.name = rank c.name := by
  simp [extendRank, fresh c member]

theorem fresh_cons_unique (caps : List Capability) (c : Capability)
    (unique : Unique caps) (fresh : Fresh caps c.name) : Unique (c :: caps) := by
  simp only [Unique, List.map_cons, List.nodup_cons]
  refine ⟨?_, unique⟩
  intro member
  obtain ⟨old, oldMember, same⟩ := List.mem_map.mp member
  exact fresh old oldMember same

theorem owner_closed (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) : Closed (owner name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · exact ⟨owner name kind, by simp, rfl⟩
    · intro p relation
      simp [owner] at relation
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem loan_closed (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (sourceMember : source ∈ caps) :
    Closed (loan source name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := (closed source sourceMember).1
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      have same : source.name = p := Option.some.inj relation
      exact ⟨source, List.mem_cons_of_mem _ sourceMember, same⟩
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem owner_ranked (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (ranked : Ranked caps) :
    Ranked (owner name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name 0, ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    simp [ChildOf, owner] at relation
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name 0 fresh child childOld,
                  extend_rank_old caps rank name 0 fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem loan_ranked (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (sourceMember : source ∈ caps)
    (ranked : Ranked caps) : Ranked (loan source name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name (rank source.name + 1), ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    have same : source.name = parent.name := Option.some.inj relation
    rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh source sourceMember same)
    · simp only [loan, extendRank, if_pos rfl]
      rw [← same]
      simp [extendRank, fresh source sourceMember]
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name (rank source.name + 1) fresh child childOld,
                  extend_rank_old caps rank name (rank source.name + 1) fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem erased_member (caps : List Capability) (name : Nat) (c : Capability) :
    c ∈ erase name caps ↔ c ∈ caps ∧ c.name ≠ name := by
  simp [erase]

theorem erase_closed (caps : List Capability) (name : Nat)
    (closed : Closed caps) (free : Unreferenced caps name) : Closed (erase name caps) := by
  intro c member
  obtain ⟨oldMember, notName⟩ := (erased_member caps name c).mp member
  obtain ⟨rootExists, parentExists⟩ := closed c oldMember
  constructor
  · obtain ⟨root, rootMember, rootName⟩ := rootExists
    have retained : root.name ≠ name := by
      intro same
      exact (free c oldMember notName).1 (rootName.symm.trans same)
    exact ⟨root, (erased_member caps name root).mpr ⟨rootMember, retained⟩, rootName⟩
  · intro p relation
    obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
    have retained : parent.name ≠ name := by
      intro same
      have pName : p = name := parentName.symm.trans same
      exact (free c oldMember notName).2 (relation.trans (congrArg some pName))
    exact ⟨parent, (erased_member caps name parent).mpr ⟨parentMember, retained⟩, parentName⟩

theorem erase_ranked (caps : List Capability) (name : Nat) (ranked : Ranked caps) :
    Ranked (erase name caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((erased_member caps name child).mp childMember).1
    parent ((erased_member caps name parent).mp parentMember).1 relation

theorem erase_unique (caps : List Capability) (name : Nat) (unique : Unique caps) :
    Unique (erase name caps) := by
  have subset : (erase name caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

/- This is a closed structural slice, not the complete borrow checker.
The borrow rules retain root/origin and prohibit shared-to-mutable escalation.
The separate production checker enforces conflicting alias exclusions. -/
inductive Step : List Capability → List Capability → Prop where
  | allocate {caps name kind} : Fresh caps name → (kind = 0 ∨ kind = 1) →
      Step caps (owner name kind :: caps)
  | borrowRead {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 2 ∨ source.kind = 3) →
      Step caps (loan source name 2 :: caps)
  | borrowMut {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 3) →
      Step caps (loan source name 3 :: caps)
  | endLoan {caps c} : c ∈ caps → c.external = false →
      (c.kind = 2 ∨ c.kind = 3) → Unreferenced caps c.name →
      Step caps (erase c.name caps)
  | dropOwner {caps c} : c ∈ caps → c.external = false →
      (c.kind = 0 ∨ c.kind = 1) → c.root = c.name → c.parent = none →
      Unreferenced caps c.name → Step caps (erase c.name caps)

theorem step_closed {before after : List Capability} (step : Step before after)
    (closed : Closed before) : Closed after := by
  cases step with
  | allocate fresh kind => exact owner_closed _ _ _ closed
  | borrowRead sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | borrowMut sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | endLoan member localCap kind free => exact erase_closed _ _ closed free
  | dropOwner member localCap kind root parent free => exact erase_closed _ _ closed free

theorem step_ranked {before after : List Capability} (step : Step before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  cases step with
  | allocate fresh kind => exact owner_ranked _ _ _ closed fresh ranked
  | borrowRead sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | borrowMut sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | endLoan member localCap kind free => exact erase_ranked _ _ ranked
  | dropOwner member localCap kind root parent free => exact erase_ranked _ _ ranked

theorem step_unique {before after : List Capability} (step : Step before after)
    (unique : Unique before) : Unique after := by
  cases step with
  | allocate fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowRead sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowMut sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | endLoan member localCap kind free => exact erase_unique _ _ unique
  | dropOwner member localCap kind root parent free => exact erase_unique _ _ unique

theorem unique_projection (caps : List Capability) (keep : Nat → Bool)
    (unique : Unique caps) : Unique (project keep caps) := by
  have subset : (project keep caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

theorem unique_rename (caps : List Capability) (f : Nat → Nat) (inj : Injective f)
    (unique : Unique caps) : Unique (caps.map (rename f)) := by
  induction caps with
  | nil => simp [Unique]
  | cons c rest ih =>
      have old : c.name ∉ rest.map Capability.name ∧ Unique rest := by
        simpa only [Unique, List.map_cons, List.nodup_cons] using unique
      simp only [List.map_cons, Unique, List.nodup_cons]
      refine ⟨?_, ih old.2⟩
      intro member
      obtain ⟨renamed, renamedMember, same⟩ := List.mem_map.mp member
      obtain ⟨original, originalMember, rfl⟩ := List.mem_map.mp renamedMember
      have originalName : original.name = c.name := inj _ _ same
      exact old.1 (List.mem_map.mpr ⟨original, originalMember, originalName⟩)

theorem transfer_unique {before after : List Capability} (step : Transfer before after)
    (unique : Unique before) : Unique after := by
  obtain ⟨keep, f, admitted, inj, rfl⟩ := step
  exact unique_rename _ f inj (unique_projection before keep unique)

inductive Trace : List Capability → List Capability → Prop where
  | refl (caps) : Trace caps caps
  | instruction {before middle after} : Trace before middle → Step middle after → Trace before after
  | edge {before middle after} : Trace before middle → Transfer middle after → Trace before after

theorem trace_closed {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) : Closed after := by
  induction trace with
  | refl => exact closed
  | instruction _ step ih => exact step_closed step ih
  | edge _ step ih => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | instruction earlier step ih => exact step_ranked step (trace_closed earlier closed) ih
  | edge _ step ih => exact transfer_ranked step ih

theorem trace_unique {before after : List Capability} (trace : Trace before after)
    (unique : Unique before) : Unique after := by
  induction trace with
  | refl => exact unique
  | instruction _ step ih => exact step_unique step ih
  | edge _ step ih => exact transfer_unique step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) (name : Nat) :
    ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace closed ranked) name

end HiaCapabilityLifecycle

/-
Borrow compatibility and suspended-parent access for a selected capability
slice. Guards inspect the before state. This extends, rather than changes,
the structural Lifecycle relation. No heap, source, LLVM or FFI refinement
is claimed. Concrete checker observations are separate finite witnesses.
-/

namespace HiaCapabilityBorrow
open HiaCapabilityRenaming HiaCapabilityLifecycle

def Ancestor (caps : List Capability) (child parent : Nat) : Prop :=
  child = parent ∨ ParentPath caps child parent

def Comparable (caps : List Capability) (a b : Nat) : Prop :=
  a = b ∨ ParentPath caps a b ∨ ParentPath caps b a

def Compatible (caps : List Capability) : Prop :=
  ∀ a ∈ caps, ∀ b ∈ caps, a.root = b.root →
    (a.kind = 3 ∨ b.kind = 3) → Comparable caps a.name b.name

/- Same-root capabilities outside the source's ancestor chain prohibit a
mutable borrow; a shared borrow excludes mutable capabilities there. -/
def BorrowGuard (caps : List Capability) (source : Capability) (kind : Nat) : Prop :=
  ∀ other ∈ caps, other.root = source.root →
    (kind = 3 ∨ other.kind = 3) → Ancestor caps source.name other.name

def Childless (caps : List Capability) (name : Nat) : Prop :=
  ∀ child ∈ caps, child.parent ≠ some name

def Access (caps : List Capability) (c : Capability) (write : Bool) : Prop :=
  c ∈ caps ∧ (if write then c.kind = 3 else c.kind = 2 ∨ c.kind = 3) ∧
    Childless caps c.name

theorem unique_same_name (caps : List Capability) (unique : Unique caps)
    (a b : Capability) (ha : a ∈ caps) (hb : b ∈ caps) (same : a.name = b.name) : a = b := by
  induction caps with
  | nil => simp at ha
  | cons c rest ih =>
      have nodup : c.name ∉ rest.map Capability.name ∧ Unique rest := by
        simpa only [Unique, List.map_cons, List.nodup_cons] using unique
      rcases List.mem_cons.mp ha with aHead | aTail
      · rcases List.mem_cons.mp hb with bHead | bTail
        · exact aHead.trans bHead.symm
        · exact False.elim (nodup.1 (List.mem_map.mpr
            ⟨b, bTail, same.symm.trans (congrArg Capability.name aHead)⟩))
      · rcases List.mem_cons.mp hb with bHead | bTail
        · exact False.elim (nodup.1 (List.mem_map.mpr
            ⟨a, aTail, same.trans (congrArg Capability.name bHead)⟩))
        · exact ih nodup.2 aTail bTail

theorem path_mono {before after : List Capability} {a b : Nat}
    (subset : ∀ c ∈ before, c ∈ after) (path : ParentPath before a b) : ParentPath after a b := by
  induction path with
  | edge hc hp relation => exact ParentPath.edge (subset _ hc) (subset _ hp) relation
  | trans _ _ ih₁ ih₂ => exact ParentPath.trans ih₁ ih₂

theorem path_endpoints {caps : List Capability} {a b : Nat} (path : ParentPath caps a b) :
    (∃ child ∈ caps, child.name = a) ∧ (∃ parent ∈ caps, parent.name = b) := by
  induction path with
  | edge hc hp relation => exact ⟨⟨_, hc, rfl⟩, ⟨_, hp, rfl⟩⟩
  | trans _ _ ih₁ ih₂ => exact ⟨ih₁.1, ih₂.2⟩

/- Closed subgraphs retain every ancestor of a retained node. Unique names
are necessary to identify the retained record with the original parent. -/
theorem path_retained {before after : List Capability} {a b : Nat}
    (unique : Unique before) (subset : ∀ c ∈ after, c ∈ before) (closed : Closed after)
    (path : ParentPath before a b) (retained : ∃ c ∈ after, c.name = a) :
    ParentPath after a b := by
  induction path with
  | @edge child parent hc hp relation =>
      obtain ⟨kept, hk, same⟩ := retained
      have equal := unique_same_name before unique kept child (subset _ hk) hc same
      subst kept
      obtain ⟨keptParent, hkp, parentName⟩ := (closed child hk).2 parent.name relation
      have equal := unique_same_name before unique keptParent parent (subset _ hkp) hp parentName
      subst keptParent
      exact ParentPath.edge hk hkp relation
  | trans first second ih₁ ih₂ =>
      have firstKept := ih₁ retained
      exact ParentPath.trans firstKept (ih₂ (path_endpoints firstKept).2)

theorem path_rename {caps : List Capability} {a b : Nat}
    (f : Nat → Nat) (path : ParentPath caps a b) :
    ParentPath (caps.map (rename f)) (f a) (f b) := by
  induction path with
  | @edge child parent hc hp relation =>
      apply ParentPath.edge (child := rename f child) (parent := rename f parent)
      · exact List.mem_map.mpr ⟨child, hc, rfl⟩
      · exact List.mem_map.mpr ⟨parent, hp, rfl⟩
      · simp only [ChildOf, rename]
        exact congrArg (Option.map f) relation
  | trans _ _ ih₁ ih₂ => exact ParentPath.trans ih₁ ih₂

theorem comparable_mono {before after : List Capability} {a b : Nat}
    (subset : ∀ c ∈ before, c ∈ after) (related : Comparable before a b) :
    Comparable after a b := by
  rcases related with same | path | path
  · exact Or.inl same
  · exact Or.inr (Or.inl (path_mono subset path))
  · exact Or.inr (Or.inr (path_mono subset path))

theorem comparable_symm {caps : List Capability} {a b : Nat}
    (related : Comparable caps a b) : Comparable caps b a := by
  rcases related with same | path | path
  · exact Or.inl same.symm
  · exact Or.inr (Or.inr path)
  · exact Or.inr (Or.inl path)

theorem compatible_owner (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (compatible : Compatible caps) :
    Compatible (owner name kind :: caps) := by
  intro a ha b hb roots mutable
  rcases List.mem_cons.mp ha with rfl | ha
  · rcases List.mem_cons.mp hb with rfl | hb
    · exact Or.inl rfl
    · obtain ⟨root, hr, rootName⟩ := (closed b hb).1
      exact False.elim (fresh root hr (rootName.trans roots.symm))
  · rcases List.mem_cons.mp hb with rfl | hb
    · obtain ⟨root, hr, rootName⟩ := (closed a ha).1
      exact False.elim (fresh root hr (rootName.trans roots))
    · exact comparable_mono (fun _ h => List.mem_cons_of_mem _ h) (compatible a ha b hb roots mutable)

theorem loan_ancestor_path (caps : List Capability) (source : Capability) (name kind other : Nat)
    (member : source ∈ caps) (ancestor : Ancestor caps source.name other) :
    ParentPath (loan source name kind :: caps) name other := by
  have parentPath : ParentPath (loan source name kind :: caps) name source.name :=
    ParentPath.edge (child := loan source name kind) (parent := source)
      (by simp) (List.mem_cons_of_mem _ member) rfl
  rcases ancestor with same | path
  · exact same ▸ parentPath
  · exact ParentPath.trans parentPath (path_mono (fun _ h => List.mem_cons_of_mem _ h) path)

theorem compatible_loan (caps : List Capability) (source : Capability) (name kind : Nat)
    (member : source ∈ caps) (guard : BorrowGuard caps source kind) (compatible : Compatible caps) :
    Compatible (loan source name kind :: caps) := by
  intro a ha b hb roots mutable
  rcases List.mem_cons.mp ha with rfl | ha
  · rcases List.mem_cons.mp hb with rfl | hb
    · exact Or.inl rfl
    · exact Or.inr (Or.inl (loan_ancestor_path caps source name kind b.name member
        (guard b hb roots.symm mutable)))
  · rcases List.mem_cons.mp hb with rfl | hb
    · exact Or.inr (Or.inr (loan_ancestor_path caps source name kind a.name member
        (guard a ha roots mutable.symm)))
    · exact comparable_mono (fun _ h => List.mem_cons_of_mem _ h) (compatible a ha b hb roots mutable)

theorem compatible_subgraph {before after : List Capability}
    (unique : Unique before) (subset : ∀ c ∈ after, c ∈ before) (closed : Closed after)
    (compatible : Compatible before) : Compatible after := by
  intro a ha b hb roots mutable
  rcases compatible a (subset _ ha) b (subset _ hb) roots mutable with same | path | path
  · exact Or.inl same
  · exact Or.inr (Or.inl (path_retained unique subset closed path ⟨a, ha, rfl⟩))
  · exact Or.inr (Or.inr (path_retained unique subset closed path ⟨b, hb, rfl⟩))

theorem compatible_erase (caps : List Capability) (name : Nat)
    (closed : Closed caps) (unique : Unique caps) (free : Unreferenced caps name)
    (compatible : Compatible caps) : Compatible (erase name caps) :=
  compatible_subgraph unique (fun c h => ((erased_member caps name c).mp h).1)
    (erase_closed caps name closed free) compatible

theorem compatible_projection (caps : List Capability) (keep : Nat → Bool)
    (unique : Unique caps) (closed : Closed (project keep caps)) (compatible : Compatible caps) :
    Compatible (project keep caps) :=
  compatible_subgraph unique (fun c h => ((projected_member caps keep c).mp h).1) closed compatible

theorem compatible_rename (caps : List Capability) (f : Nat → Nat) (inj : Injective f)
    (compatible : Compatible caps) : Compatible (caps.map (rename f)) := by
  intro a ha b hb roots mutable
  obtain ⟨originalA, memberA, rfl⟩ := List.mem_map.mp ha
  obtain ⟨originalB, memberB, rfl⟩ := List.mem_map.mp hb
  rcases compatible originalA memberA originalB memberB (inj _ _ roots) mutable with same | path | path
  · exact Or.inl (congrArg f same)
  · exact Or.inr (Or.inl (path_rename f path))
  · exact Or.inr (Or.inr (path_rename f path))

theorem transfer_compatible {before after : List Capability} (transfer : Transfer before after)
    (unique : Unique before) (compatible : Compatible before) : Compatible after := by
  obtain ⟨keep, f, admitted, inj, rfl⟩ := transfer
  exact compatible_rename _ f inj (compatible_projection before keep unique admitted.2 compatible)

theorem child_blocks_access {caps : List Capability} {parent child : Capability} {write : Bool}
    (member : child ∈ caps) (relation : ChildOf child parent) : ¬ Access caps parent write := by
  intro access
  exact access.2.2 child member relation

theorem path_last_child {caps : List Capability} {a b : Nat} (path : ParentPath caps a b) :
    ∃ child ∈ caps, child.parent = some b := by
  induction path with
  | edge hc hp relation => exact ⟨_, hc, relation⟩
  | trans _ _ ih₁ ih₂ => exact ih₂

theorem ancestor_blocks_access {caps : List Capability} {parent : Capability} {child : Nat} {write : Bool}
    (path : ParentPath caps child parent.name) : ¬ Access caps parent write := by
  obtain ⟨c, member, relation⟩ := path_last_child path
  exact child_blocks_access member relation

theorem accessible_exclusive {caps : List Capability} {a b : Capability} {writeA writeB : Bool}
    (compatible : Compatible caps) (accessA : Access caps a writeA) (accessB : Access caps b writeB)
    (sameRoot : a.root = b.root) (different : a.name ≠ b.name) : a.kind ≠ 3 ∧ b.kind ≠ 3 := by
  have impossible : ¬ (a.kind = 3 ∨ b.kind = 3) := by
    intro mutable
    rcases compatible a accessA.1 b accessB.1 sameRoot mutable with same | path | path
    · exact different same
    · exact ancestor_blocks_access path accessB
    · exact ancestor_blocks_access path accessA
  exact ⟨fun h => impossible (Or.inl h), fun h => impossible (Or.inr h)⟩

theorem borrow_suspends_source (caps : List Capability) (source : Capability) (name kind : Nat)
    (write : Bool) : ¬ Access (loan source name kind :: caps) source write :=
  child_blocks_access (child := loan source name kind) (by simp) rfl

theorem end_restores_access (caps : List Capability) (parent : Capability) (ended : Nat) (write : Bool)
    (member : parent ∈ caps) (different : parent.name ≠ ended)
    (permission : if write then parent.kind = 3 else parent.kind = 2 ∨ parent.kind = 3)
    (lastChild : ∀ child ∈ caps, child.parent = some parent.name → child.name = ended) :
    Access (erase ended caps) parent write := by
  refine ⟨(erased_member caps ended parent).mpr ⟨member, different⟩, permission, ?_⟩
  intro child retained relation
  obtain ⟨old, notEnded⟩ := (erased_member caps ended child).mp retained
  exact notEnded (lastChild child old relation)

/- This selected relation has pre-state guards and no after-state safety
premise. Calls, moves, chains and other instruction effects remain outside. -/
inductive Step : List Capability → List Capability → Prop where
  | allocate {caps name kind} : Fresh caps name → (kind = 0 ∨ kind = 1) →
      Step caps (owner name kind :: caps)
  | borrowRead {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 2 ∨ source.kind = 3) → BorrowGuard caps source 2 →
      Step caps (loan source name 2 :: caps)
  | borrowMut {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 3) → BorrowGuard caps source 3 →
      Step caps (loan source name 3 :: caps)
  | endLoan {caps c} : c ∈ caps → c.external = false →
      (c.kind = 2 ∨ c.kind = 3) → Unreferenced caps c.name →
      Step caps (erase c.name caps)
  | dropOwner {caps c} : c ∈ caps → c.external = false →
      (c.kind = 0 ∨ c.kind = 1) → c.root = c.name → c.parent = none →
      Unreferenced caps c.name → Step caps (erase c.name caps)
  | access {caps c write} : Access caps c write → Step caps caps

theorem step_structural {before after : List Capability} (step : Step before after) :
    HiaCapabilityLifecycle.Step before after ∨ before = after := by
  cases step with
  | allocate fresh kind => exact Or.inl (.allocate fresh kind)
  | borrowRead member fresh kind guard => exact Or.inl (.borrowRead member fresh kind)
  | borrowMut member fresh kind guard => exact Or.inl (.borrowMut member fresh kind)
  | endLoan member localCap kind free => exact Or.inl (.endLoan member localCap kind free)
  | dropOwner member localCap kind root parent free => exact Or.inl (.dropOwner member localCap kind root parent free)
  | access access => exact Or.inr rfl

theorem step_closed {before after : List Capability} (step : Step before after)
    (closed : Closed before) : Closed after := by
  rcases step_structural step with structural | rfl
  · exact HiaCapabilityLifecycle.step_closed structural closed
  · exact closed

theorem step_ranked {before after : List Capability} (step : Step before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  rcases step_structural step with structural | rfl
  · exact HiaCapabilityLifecycle.step_ranked structural closed ranked
  · exact ranked

theorem step_unique {before after : List Capability} (step : Step before after)
    (unique : Unique before) : Unique after := by
  rcases step_structural step with structural | rfl
  · exact HiaCapabilityLifecycle.step_unique structural unique
  · exact unique

theorem step_compatible {before after : List Capability} (step : Step before after)
    (closed : Closed before) (unique : Unique before) (compatible : Compatible before) : Compatible after := by
  cases step with
  | allocate fresh kind => exact compatible_owner _ _ _ closed fresh compatible
  | borrowRead member fresh kind guard => exact compatible_loan _ _ _ _ member guard compatible
  | borrowMut member fresh kind guard => exact compatible_loan _ _ _ _ member guard compatible
  | endLoan member localCap kind free => exact compatible_erase _ _ closed unique free compatible
  | dropOwner member localCap kind root parent free => exact compatible_erase _ _ closed unique free compatible
  | access access => exact compatible

inductive Trace : List Capability → List Capability → Prop where
  | refl (caps) : Trace caps caps
  | instruction {before middle after} : Trace before middle → Step middle after → Trace before after
  | edge {before middle after} : Trace before middle → Transfer middle after → Trace before after

theorem trace_closed {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) : Closed after := by
  induction trace with
  | refl => exact closed
  | instruction _ step ih => exact step_closed step ih
  | edge _ transfer ih => exact transfer_closed transfer

theorem trace_ranked {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | instruction earlier step ih => exact step_ranked step (trace_closed earlier closed) ih
  | edge _ transfer ih => exact transfer_ranked transfer ih

theorem trace_unique {before after : List Capability} (trace : Trace before after)
    (unique : Unique before) : Unique after := by
  induction trace with
  | refl => exact unique
  | instruction _ step ih => exact step_unique step ih
  | edge _ transfer ih => exact transfer_unique transfer ih

theorem trace_compatible {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (unique : Unique before) (compatible : Compatible before) : Compatible after := by
  induction trace with
  | refl => exact compatible
  | instruction earlier step ih =>
      exact step_compatible step (trace_closed earlier closed) (trace_unique earlier unique) ih
  | edge earlier transfer ih => exact transfer_compatible transfer (trace_unique earlier unique) ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace closed ranked) name

theorem trace_accessible_exclusive {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (unique : Unique before) (compatible : Compatible before)
    {a b : Capability} {writeA writeB : Bool} (accessA : Access after a writeA) (accessB : Access after b writeB)
    (sameRoot : a.root = b.root) (different : a.name ≠ b.name) : a.kind ≠ 3 ∧ b.kind ≠ 3 :=
  accessible_exclusive (trace_compatible trace closed unique compatible) accessA accessB sameRoot different

end HiaCapabilityBorrow

namespace HiaCapabilityBorrow
open HiaCapabilityRenaming HiaCapabilityLifecycle
def instruction0Before : List Capability := [⟨0, 0, none, 3, true, (some 0)⟩, ⟨1, 0, (some 0), 3, false, (some 0)⟩]
def instruction0After : List Capability := [⟨0, 0, none, 3, true, (some 0)⟩, ⟨1, 0, (some 0), 3, false, (some 0)⟩]
def instruction0Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction0Source : Capability := ⟨0, 0, none, 3, true, (some 0)⟩
theorem instruction0_path0 : ParentPath instruction0Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, (some 0)⟩) (parent := ⟨0, 0, none, 3, true, (some 0)⟩) (by simp [instruction0Before]) (by simp [instruction0Before]) rfl
theorem instruction0_access : Access instruction0Before instruction0Source true := by
  simp [Access, Childless, instruction0Before, instruction0Source]
theorem instruction0_result : instruction0After = instruction0Before := by decide
theorem instruction0_step : Step instruction0Before instruction0After := by
  rw [instruction0_result]
  exact Step.access instruction0_access
theorem instruction0_closed_before : Closed instruction0Before := by
  simp [Closed, instruction0Before]
theorem instruction0_ranked_before : Ranked instruction0Before := by
  refine ⟨instruction0Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction0Before, instruction0Rank]
theorem instruction0_unique_before : Unique instruction0Before := by
  simp [Unique, instruction0Before]
theorem instruction0_compatible_before : Compatible instruction0Before := by
  have path0 := instruction0_path0
  simp only [instruction0Before] at path0
  simp [Compatible, Comparable, instruction0Before, path0]
theorem instruction0_closed_after : Closed instruction0After :=
  step_closed instruction0_step instruction0_closed_before
theorem instruction0_ranked_after : Ranked instruction0After :=
  step_ranked instruction0_step instruction0_closed_before instruction0_ranked_before
theorem instruction0_unique_after : Unique instruction0After :=
  step_unique instruction0_step instruction0_unique_before
theorem instruction0_compatible_after : Compatible instruction0After :=
  step_compatible instruction0_step instruction0_closed_before instruction0_unique_before instruction0_compatible_before
theorem instruction0_no_parent_cycle (name : Nat) : ¬ ParentPath instruction0After name name :=
  ranked_no_parent_cycle instruction0After instruction0_ranked_after name
end HiaCapabilityBorrow
#print axioms HiaCapabilityBorrow.accessible_exclusive
#print axioms HiaCapabilityBorrow.ancestor_blocks_access
#print axioms HiaCapabilityBorrow.borrow_suspends_source
#print axioms HiaCapabilityBorrow.child_blocks_access
#print axioms HiaCapabilityBorrow.comparable_mono
#print axioms HiaCapabilityBorrow.comparable_symm
#print axioms HiaCapabilityBorrow.compatible_erase
#print axioms HiaCapabilityBorrow.compatible_loan
#print axioms HiaCapabilityBorrow.compatible_owner
#print axioms HiaCapabilityBorrow.compatible_projection
#print axioms HiaCapabilityBorrow.compatible_rename
#print axioms HiaCapabilityBorrow.compatible_subgraph
#print axioms HiaCapabilityBorrow.end_restores_access
#print axioms HiaCapabilityBorrow.instruction0_access
#print axioms HiaCapabilityBorrow.instruction0_closed_after
#print axioms HiaCapabilityBorrow.instruction0_closed_before
#print axioms HiaCapabilityBorrow.instruction0_compatible_after
#print axioms HiaCapabilityBorrow.instruction0_compatible_before
#print axioms HiaCapabilityBorrow.instruction0_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction0_path0
#print axioms HiaCapabilityBorrow.instruction0_ranked_after
#print axioms HiaCapabilityBorrow.instruction0_ranked_before
#print axioms HiaCapabilityBorrow.instruction0_result
#print axioms HiaCapabilityBorrow.instruction0_step
#print axioms HiaCapabilityBorrow.instruction0_unique_after
#print axioms HiaCapabilityBorrow.instruction0_unique_before
#print axioms HiaCapabilityBorrow.loan_ancestor_path
#print axioms HiaCapabilityBorrow.path_endpoints
#print axioms HiaCapabilityBorrow.path_last_child
#print axioms HiaCapabilityBorrow.path_mono
#print axioms HiaCapabilityBorrow.path_rename
#print axioms HiaCapabilityBorrow.path_retained
#print axioms HiaCapabilityBorrow.step_closed
#print axioms HiaCapabilityBorrow.step_compatible
#print axioms HiaCapabilityBorrow.step_ranked
#print axioms HiaCapabilityBorrow.step_structural
#print axioms HiaCapabilityBorrow.step_unique
#print axioms HiaCapabilityBorrow.trace_accessible_exclusive
#print axioms HiaCapabilityBorrow.trace_closed
#print axioms HiaCapabilityBorrow.trace_compatible
#print axioms HiaCapabilityBorrow.trace_no_parent_cycle
#print axioms HiaCapabilityBorrow.trace_ranked
#print axioms HiaCapabilityBorrow.trace_unique
#print axioms HiaCapabilityBorrow.transfer_compatible
#print axioms HiaCapabilityBorrow.unique_same_name
#print axioms HiaCapabilityLifecycle.erase_closed
#print axioms HiaCapabilityLifecycle.erase_ranked
#print axioms HiaCapabilityLifecycle.erase_unique
#print axioms HiaCapabilityLifecycle.erased_member
#print axioms HiaCapabilityLifecycle.extend_rank_old
#print axioms HiaCapabilityLifecycle.fresh_cons_unique
#print axioms HiaCapabilityLifecycle.fresh_not_member
#print axioms HiaCapabilityLifecycle.fresh_parent_absent
#print axioms HiaCapabilityLifecycle.loan_closed
#print axioms HiaCapabilityLifecycle.loan_ranked
#print axioms HiaCapabilityLifecycle.owner_closed
#print axioms HiaCapabilityLifecycle.owner_ranked
#print axioms HiaCapabilityLifecycle.step_closed
#print axioms HiaCapabilityLifecycle.step_ranked
#print axioms HiaCapabilityLifecycle.step_unique
#print axioms HiaCapabilityLifecycle.trace_closed
#print axioms HiaCapabilityLifecycle.trace_no_parent_cycle
#print axioms HiaCapabilityLifecycle.trace_ranked
#print axioms HiaCapabilityLifecycle.trace_unique
#print axioms HiaCapabilityLifecycle.transfer_unique
#print axioms HiaCapabilityLifecycle.unique_projection
#print axioms HiaCapabilityLifecycle.unique_rename
#print axioms HiaCapabilityRenaming.child_of_iff
#print axioms HiaCapabilityRenaming.closed_preserved
#print axioms HiaCapabilityRenaming.exclusive_alias_iff
#print axioms HiaCapabilityRenaming.external_preserved
#print axioms HiaCapabilityRenaming.identity_rename
#print axioms HiaCapabilityRenaming.kind_preserved
#print axioms HiaCapabilityRenaming.local_inventory_projection
#print axioms HiaCapabilityRenaming.local_inventory_rename
#print axioms HiaCapabilityRenaming.local_retained
#print axioms HiaCapabilityRenaming.name_equal_iff
#print axioms HiaCapabilityRenaming.name_preserved
#print axioms HiaCapabilityRenaming.number_preserved
#print axioms HiaCapabilityRenaming.only_external_forgotten
#print axioms HiaCapabilityRenaming.origin_preserved
#print axioms HiaCapabilityRenaming.parent_map_iff
#print axioms HiaCapabilityRenaming.parent_path_descends
#print axioms HiaCapabilityRenaming.projected_member
#print axioms HiaCapabilityRenaming.ranked_no_parent_cycle
#print axioms HiaCapabilityRenaming.ranked_projection
#print axioms HiaCapabilityRenaming.ranked_rename
#print axioms HiaCapabilityRenaming.rename_composes
#print axioms HiaCapabilityRenaming.root_equal_iff
#print axioms HiaCapabilityRenaming.suspended_iff
#print axioms HiaCapabilityRenaming.trace_closed
#print axioms HiaCapabilityRenaming.trace_local_inventory
#print axioms HiaCapabilityRenaming.trace_no_parent_cycle
#print axioms HiaCapabilityRenaming.trace_ranked
#print axioms HiaCapabilityRenaming.transfer_closed
#print axioms HiaCapabilityRenaming.transfer_local_inventory
#print axioms HiaCapabilityRenaming.transfer_ranked
#print axioms HiaCapabilityRenaming.transported_rank_at
