/-
Sequential Core capability-flow specification. Names are mathematical
naturals; kinds and origins are uninterpreted tags. This proves facts for
ALL finite capability lists and injective maps, without an execution-length
bound. It is not a proof of every instruction, Python, LLVM, FFI, or hardware.
Projection may forget only external capabilities and must keep the selected
graph closed. The trace theorems below compose these edge rules for every
finite trace; they do not model the intervening instructions in a CFG block.
-/
import Lean.Elab.Tactic.Omega

namespace HiaCapabilityRenaming

structure Capability where
  name : Nat
  root : Nat
  parent : Option Nat
  kind : Nat
  external : Bool
  origin : Option Nat
  deriving DecidableEq

def Injective (f : Nat → Nat) : Prop := ∀ a b, f a = f b → a = b

def rename (f : Nat → Nat) (c : Capability) : Capability :=
  { name := f c.name, root := f c.root, parent := c.parent.map f,
    kind := c.kind, external := c.external, origin := c.origin }

def ChildOf (child parent : Capability) : Prop := child.parent = some parent.name

def ExclusiveAlias (mutableKind : Nat) (a b : Capability) : Prop :=
  a.name ≠ b.name ∧ a.root = b.root ∧ (a.kind = mutableKind ∨ b.kind = mutableKind)

def Closed (caps : List Capability) : Prop :=
  ∀ c ∈ caps, (∃ root ∈ caps, root.name = c.root) ∧
    (∀ p, c.parent = some p → ∃ parent ∈ caps, parent.name = p)

theorem name_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).name = f c.name := rfl

theorem kind_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).kind = c.kind := rfl

theorem external_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).external = c.external := rfl

theorem origin_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).origin = c.origin := rfl

theorem name_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).name = (rename f b).name ↔ a.name = b.name := by
  constructor
  · exact inj a.name b.name
  · intro h; exact congrArg f h

theorem root_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).root = (rename f b).root ↔ a.root = b.root := by
  constructor
  · exact inj a.root b.root
  · intro h; exact congrArg f h

theorem parent_map_iff (f : Nat → Nat) (inj : Injective f) (p : Option Nat) (n : Nat) :
    p.map f = some (f n) ↔ p = some n := by
  cases p with
  | none => simp
  | some p =>
      constructor
      · intro h; exact congrArg some (inj p n (Option.some.inj h))
      · intro h; cases h; rfl

theorem child_of_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    ChildOf (rename f a) (rename f b) ↔ ChildOf a b := by
  exact parent_map_iff f inj a.parent b.name

theorem exclusive_alias_iff (f : Nat → Nat) (inj : Injective f)
    (mutableKind : Nat) (a b : Capability) :
    ExclusiveAlias mutableKind (rename f a) (rename f b) ↔
      ExclusiveAlias mutableKind a b := by
  simp only [ExclusiveAlias, ne_eq, name_equal_iff f inj,
             root_equal_iff f inj, kind_preserved]

theorem suspended_iff (f : Nat → Nat) (inj : Injective f)
    (caps : List Capability) (c : Capability) :
    (∃ child ∈ caps.map (rename f), ChildOf child (rename f c)) ↔
      (∃ child ∈ caps, ChildOf child c) := by
  constructor
  · rintro ⟨child, member, relation⟩
    obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
    exact ⟨old, oldMember, (child_of_iff f inj old c).mp relation⟩
  · rintro ⟨child, member, relation⟩
    exact ⟨rename f child, List.mem_map.mpr ⟨child, member, rfl⟩,
      (child_of_iff f inj child c).mpr relation⟩

theorem closed_preserved (f : Nat → Nat) (caps : List Capability)
    (closed : Closed caps) : Closed (caps.map (rename f)) := by
  intro c member
  obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
  obtain ⟨rootExists, parentExists⟩ := closed old oldMember
  obtain ⟨root, rootMember, rootName⟩ := rootExists
  constructor
  · exact ⟨rename f root, List.mem_map.mpr ⟨root, rootMember, rfl⟩,
      congrArg f rootName⟩
  · intro p relation
    cases hp : old.parent with
    | none => simp [rename, hp] at relation
    | some oldParent =>
        have mapped : f oldParent = p := by simpa [rename, hp] using relation
        obtain ⟨parent, parentMember, parentName⟩ := parentExists oldParent hp
        exact ⟨rename f parent, List.mem_map.mpr ⟨parent, parentMember, rfl⟩,
          (congrArg f parentName).trans mapped⟩

theorem number_preserved (f : Nat → Nat) (caps : List Capability) :
    (caps.map (rename f)).length = caps.length := by simp

theorem rename_composes (f g : Nat → Nat) (c : Capability) :
    rename g (rename f c) = rename (fun n => g (f n)) c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

theorem identity_rename (c : Capability) : rename (fun n => n) c = c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

/- The executable helper selects a subset before renaming. Selection is a
filter, so it cannot invent or duplicate capabilities. The explicit retention
premise is exactly the helper's rule for local owners and local loans. -/

def project (keep : Nat → Bool) (caps : List Capability) : List Capability :=
  caps.filter (fun c => keep c.name)

def AdmissibleProjection (caps : List Capability) (keep : Nat → Bool) : Prop :=
  (∀ c ∈ caps, c.external = false → keep c.name = true) ∧ Closed (project keep caps)

def localInventory : List Capability → List (Nat × Option Nat)
  | [] => []
  | c :: rest =>
      if c.external then localInventory rest else (c.kind, c.origin) :: localInventory rest

theorem projected_member (caps : List Capability) (keep : Nat → Bool) (c : Capability) :
    c ∈ project keep caps ↔ c ∈ caps ∧ keep c.name = true := by
  simp [project]

theorem local_retained (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (localCap : c.external = false) : c ∈ project keep caps := by
  exact (projected_member caps keep c).mpr ⟨member, admitted.1 c member localCap⟩

theorem only_external_forgotten (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (forgotten : c ∉ project keep caps) : c.external = true := by
  cases external : c.external with
  | false => exact False.elim (forgotten (local_retained caps keep admitted c member external))
  | true => rfl

theorem local_inventory_projection (caps : List Capability) (keep : Nat → Bool)
    (retained : ∀ c ∈ caps, c.external = false → keep c.name = true) :
    localInventory (project keep caps) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih =>
      have restRetained : ∀ x ∈ rest, x.external = false → keep x.name = true := by
        intro x member external
        exact retained x (List.mem_cons_of_mem c member) external
      have tail := ih restRetained
      cases external : c.external with
      | false =>
          have kept := retained c (by simp) external
          simp [project, localInventory, external, kept] at tail ⊢
          exact tail
      | true =>
          cases kept : keep c.name <;> simp [project, localInventory, external, kept] at tail ⊢
          all_goals exact tail

theorem local_inventory_rename (caps : List Capability) (f : Nat → Nat) :
    localInventory (caps.map (rename f)) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih => simp [localInventory, rename, ih]

/- Parent ranks are witnesses for strict descent, not runtime addresses or
integer counters. Their existence excludes every positive parent cycle. -/

def ParentRanks (caps : List Capability) (rank : Nat → Nat) : Prop :=
  ∀ child ∈ caps, ∀ parent ∈ caps, ChildOf child parent → rank parent.name < rank child.name

def Ranked (caps : List Capability) : Prop := ∃ rank, ParentRanks caps rank

inductive ParentPath (caps : List Capability) : Nat → Nat → Prop where
  | edge {child parent} : child ∈ caps → parent ∈ caps → ChildOf child parent →
      ParentPath caps child.name parent.name
  | trans {a b c} : ParentPath caps a b → ParentPath caps b c → ParentPath caps a c

theorem parent_path_descends (caps : List Capability) (rank : Nat → Nat)
    (ranked : ParentRanks caps rank) {a b : Nat} (path : ParentPath caps a b) :
    rank b < rank a := by
  induction path with
  | edge childMember parentMember relation => exact ranked _ childMember _ parentMember relation
  | trans _ _ left right => exact Nat.lt_trans right left

theorem ranked_no_parent_cycle (caps : List Capability) (ranked : Ranked caps) (name : Nat) :
    ¬ ParentPath caps name name := by
  intro path
  obtain ⟨rank, ordered⟩ := ranked
  exact (Nat.lt_irrefl (rank name)) (parent_path_descends caps rank ordered path)

theorem ranked_projection (caps : List Capability) (keep : Nat → Bool)
    (ranked : Ranked caps) : Ranked (project keep caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((projected_member caps keep child).mp childMember).1
    parent ((projected_member caps keep parent).mp parentMember).1 relation

noncomputable def transportedRank (f rank : Nat → Nat) (name : Nat) : Nat := by
  classical
  exact if witness : ∃ before, f before = name then rank (Classical.choose witness) else 0

theorem transported_rank_at (f rank : Nat → Nat) (inj : Injective f) (name : Nat) :
    transportedRank f rank (f name) = rank name := by
  unfold transportedRank
  split
  next witness =>
    have same : Classical.choose witness = name := inj _ _ (Classical.choose_spec witness)
    rw [same]
  next absent => exact False.elim (absent ⟨name, rfl⟩)

theorem ranked_rename (caps : List Capability) (f : Nat → Nat)
    (inj : Injective f) (ranked : Ranked caps) : Ranked (caps.map (rename f)) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨transportedRank f rank, ?_⟩
  intro child childMember parent parentMember relation
  obtain ⟨oldChild, oldChildMember, rfl⟩ := List.mem_map.mp childMember
  obtain ⟨oldParent, oldParentMember, rfl⟩ := List.mem_map.mp parentMember
  have oldRelation := (child_of_iff f inj oldChild oldParent).mp relation
  simpa only [name_preserved, transported_rank_at f rank inj] using
    ordered oldChild oldChildMember oldParent oldParentMember oldRelation

def Transfer (before after : List Capability) : Prop :=
  ∃ keep f, AdmissibleProjection before keep ∧ Injective f ∧
    after = (project keep before).map (rename f)

theorem transfer_closed {before after : List Capability} (step : Transfer before after) :
    Closed after := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  exact closed_preserved f (project keep before) admitted.2

theorem transfer_local_inventory {before after : List Capability} (step : Transfer before after) :
    localInventory after = localInventory before := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  rw [local_inventory_rename, local_inventory_projection before keep admitted.1]

theorem transfer_ranked {before after : List Capability} (step : Transfer before after)
    (ranked : Ranked before) : Ranked after := by
  obtain ⟨keep, f, _, inj, rfl⟩ := step
  exact ranked_rename (project keep before) f inj (ranked_projection before keep ranked)

inductive EdgeTrace : List Capability → List Capability → Prop where
  | refl (caps) : EdgeTrace caps caps
  | next {before middle after} : EdgeTrace before middle → Transfer middle after →
      EdgeTrace before after

theorem trace_local_inventory {before after : List Capability} (trace : EdgeTrace before after) :
    localInventory after = localInventory before := by
  induction trace with
  | refl => rfl
  | next _ step ih => exact (transfer_local_inventory step).trans ih

theorem trace_closed {before after : List Capability} (trace : EdgeTrace before after)
    (closed : Closed before) : Closed after := by
  cases trace with
  | refl => exact closed
  | next _ step => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | next _ step ih => exact transfer_ranked step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace ranked) name

end HiaCapabilityRenaming

/-
Structural preservation for allocation, borrowing and release. This model
concerns capability graphs, not heap execution or the production checker.
It does not prove alias exclusivity, FFI, calls or concurrent memory safety.
-/

namespace HiaCapabilityLifecycle
open HiaCapabilityRenaming

def Fresh (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name

def Unique (caps : List Capability) : Prop := (caps.map Capability.name).Nodup

def owner (name kind : Nat) : Capability :=
  ⟨name, name, none, kind, false, none⟩

def loan (source : Capability) (name kind : Nat) : Capability :=
  ⟨name, source.root, some source.name, kind, false, source.origin⟩

def erase (name : Nat) (caps : List Capability) : List Capability :=
  caps.filter (fun c => c.name != name)

def Unreferenced (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name → c.root ≠ name ∧ c.parent ≠ some name

def extendRank (rank : Nat → Nat) (name value : Nat) (n : Nat) : Nat :=
  if n = name then value else rank n

theorem fresh_not_member (caps : List Capability) (name : Nat)
    (fresh : Fresh caps name) (c : Capability) (same : c.name = name) : c ∉ caps := by
  intro member
  exact fresh c member same

theorem fresh_parent_absent (caps : List Capability) (name : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    c.parent ≠ some name := by
  intro relation
  obtain ⟨parent, parentMember, parentName⟩ := (closed c member).2 name relation
  exact fresh parent parentMember parentName

theorem extend_rank_old (caps : List Capability) (rank : Nat → Nat) (name value : Nat)
    (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    extendRank rank name value c.name = rank c.name := by
  simp [extendRank, fresh c member]

theorem fresh_cons_unique (caps : List Capability) (c : Capability)
    (unique : Unique caps) (fresh : Fresh caps c.name) : Unique (c :: caps) := by
  simp only [Unique, List.map_cons, List.nodup_cons]
  refine ⟨?_, unique⟩
  intro member
  obtain ⟨old, oldMember, same⟩ := List.mem_map.mp member
  exact fresh old oldMember same

theorem owner_closed (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) : Closed (owner name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · exact ⟨owner name kind, by simp, rfl⟩
    · intro p relation
      simp [owner] at relation
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem loan_closed (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (sourceMember : source ∈ caps) :
    Closed (loan source name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := (closed source sourceMember).1
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      have same : source.name = p := Option.some.inj relation
      exact ⟨source, List.mem_cons_of_mem _ sourceMember, same⟩
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem owner_ranked (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (ranked : Ranked caps) :
    Ranked (owner name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name 0, ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    simp [ChildOf, owner] at relation
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name 0 fresh child childOld,
                  extend_rank_old caps rank name 0 fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem loan_ranked (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (sourceMember : source ∈ caps)
    (ranked : Ranked caps) : Ranked (loan source name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name (rank source.name + 1), ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    have same : source.name = parent.name := Option.some.inj relation
    rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh source sourceMember same)
    · simp only [loan, extendRank, if_pos rfl]
      rw [← same]
      simp [extendRank, fresh source sourceMember]
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name (rank source.name + 1) fresh child childOld,
                  extend_rank_old caps rank name (rank source.name + 1) fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem erased_member (caps : List Capability) (name : Nat) (c : Capability) :
    c ∈ erase name caps ↔ c ∈ caps ∧ c.name ≠ name := by
  simp [erase]

theorem erase_closed (caps : List Capability) (name : Nat)
    (closed : Closed caps) (free : Unreferenced caps name) : Closed (erase name caps) := by
  intro c member
  obtain ⟨oldMember, notName⟩ := (erased_member caps name c).mp member
  obtain ⟨rootExists, parentExists⟩ := closed c oldMember
  constructor
  · obtain ⟨root, rootMember, rootName⟩ := rootExists
    have retained : root.name ≠ name := by
      intro same
      exact (free c oldMember notName).1 (rootName.symm.trans same)
    exact ⟨root, (erased_member caps name root).mpr ⟨rootMember, retained⟩, rootName⟩
  · intro p relation
    obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
    have retained : parent.name ≠ name := by
      intro same
      have pName : p = name := parentName.symm.trans same
      exact (free c oldMember notName).2 (relation.trans (congrArg some pName))
    exact ⟨parent, (erased_member caps name parent).mpr ⟨parentMember, retained⟩, parentName⟩

theorem erase_ranked (caps : List Capability) (name : Nat) (ranked : Ranked caps) :
    Ranked (erase name caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((erased_member caps name child).mp childMember).1
    parent ((erased_member caps name parent).mp parentMember).1 relation

theorem erase_unique (caps : List Capability) (name : Nat) (unique : Unique caps) :
    Unique (erase name caps) := by
  have subset : (erase name caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

/- This is a closed structural slice, not the complete borrow checker.
The borrow rules retain root/origin and prohibit shared-to-mutable escalation.
The separate production checker enforces conflicting alias exclusions. -/
inductive Step : List Capability → List Capability → Prop where
  | allocate {caps name kind} : Fresh caps name → (kind = 0 ∨ kind = 1) →
      Step caps (owner name kind :: caps)
  | borrowRead {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 2 ∨ source.kind = 3) →
      Step caps (loan source name 2 :: caps)
  | borrowMut {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 3) →
      Step caps (loan source name 3 :: caps)
  | endLoan {caps c} : c ∈ caps → c.external = false →
      (c.kind = 2 ∨ c.kind = 3) → Unreferenced caps c.name →
      Step caps (erase c.name caps)
  | dropOwner {caps c} : c ∈ caps → c.external = false →
      (c.kind = 0 ∨ c.kind = 1) → c.root = c.name → c.parent = none →
      Unreferenced caps c.name → Step caps (erase c.name caps)

theorem step_closed {before after : List Capability} (step : Step before after)
    (closed : Closed before) : Closed after := by
  cases step with
  | allocate fresh kind => exact owner_closed _ _ _ closed
  | borrowRead sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | borrowMut sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | endLoan member localCap kind free => exact erase_closed _ _ closed free
  | dropOwner member localCap kind root parent free => exact erase_closed _ _ closed free

theorem step_ranked {before after : List Capability} (step : Step before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  cases step with
  | allocate fresh kind => exact owner_ranked _ _ _ closed fresh ranked
  | borrowRead sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | borrowMut sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | endLoan member localCap kind free => exact erase_ranked _ _ ranked
  | dropOwner member localCap kind root parent free => exact erase_ranked _ _ ranked

theorem step_unique {before after : List Capability} (step : Step before after)
    (unique : Unique before) : Unique after := by
  cases step with
  | allocate fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowRead sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowMut sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | endLoan member localCap kind free => exact erase_unique _ _ unique
  | dropOwner member localCap kind root parent free => exact erase_unique _ _ unique

theorem unique_projection (caps : List Capability) (keep : Nat → Bool)
    (unique : Unique caps) : Unique (project keep caps) := by
  have subset : (project keep caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

theorem unique_rename (caps : List Capability) (f : Nat → Nat) (inj : Injective f)
    (unique : Unique caps) : Unique (caps.map (rename f)) := by
  induction caps with
  | nil => simp [Unique]
  | cons c rest ih =>
      have old : c.name ∉ rest.map Capability.name ∧ Unique rest := by
        simpa only [Unique, List.map_cons, List.nodup_cons] using unique
      simp only [List.map_cons, Unique, List.nodup_cons]
      refine ⟨?_, ih old.2⟩
      intro member
      obtain ⟨renamed, renamedMember, same⟩ := List.mem_map.mp member
      obtain ⟨original, originalMember, rfl⟩ := List.mem_map.mp renamedMember
      have originalName : original.name = c.name := inj _ _ same
      exact old.1 (List.mem_map.mpr ⟨original, originalMember, originalName⟩)

theorem transfer_unique {before after : List Capability} (step : Transfer before after)
    (unique : Unique before) : Unique after := by
  obtain ⟨keep, f, admitted, inj, rfl⟩ := step
  exact unique_rename _ f inj (unique_projection before keep unique)

inductive Trace : List Capability → List Capability → Prop where
  | refl (caps) : Trace caps caps
  | instruction {before middle after} : Trace before middle → Step middle after → Trace before after
  | edge {before middle after} : Trace before middle → Transfer middle after → Trace before after

theorem trace_closed {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) : Closed after := by
  induction trace with
  | refl => exact closed
  | instruction _ step ih => exact step_closed step ih
  | edge _ step ih => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | instruction earlier step ih => exact step_ranked step (trace_closed earlier closed) ih
  | edge _ step ih => exact transfer_ranked step ih

theorem trace_unique {before after : List Capability} (trace : Trace before after)
    (unique : Unique before) : Unique after := by
  induction trace with
  | refl => exact unique
  | instruction _ step ih => exact step_unique step ih
  | edge _ step ih => exact transfer_unique step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) (name : Nat) :
    ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace closed ranked) name

end HiaCapabilityLifecycle

/-
Borrow compatibility and suspended-parent access for a selected capability
slice. Guards inspect the before state. This extends, rather than changes,
the structural Lifecycle relation. No heap, source, LLVM or FFI refinement
is claimed. Concrete checker observations are separate finite witnesses.
-/

namespace HiaCapabilityBorrow
open HiaCapabilityRenaming HiaCapabilityLifecycle

def Ancestor (caps : List Capability) (child parent : Nat) : Prop :=
  child = parent ∨ ParentPath caps child parent

def Comparable (caps : List Capability) (a b : Nat) : Prop :=
  a = b ∨ ParentPath caps a b ∨ ParentPath caps b a

def Compatible (caps : List Capability) : Prop :=
  ∀ a ∈ caps, ∀ b ∈ caps, a.root = b.root →
    (a.kind = 3 ∨ b.kind = 3) → Comparable caps a.name b.name

/- Same-root capabilities outside the source's ancestor chain prohibit a
mutable borrow; a shared borrow excludes mutable capabilities there. -/
def BorrowGuard (caps : List Capability) (source : Capability) (kind : Nat) : Prop :=
  ∀ other ∈ caps, other.root = source.root →
    (kind = 3 ∨ other.kind = 3) → Ancestor caps source.name other.name

def Childless (caps : List Capability) (name : Nat) : Prop :=
  ∀ child ∈ caps, child.parent ≠ some name

def Access (caps : List Capability) (c : Capability) (write : Bool) : Prop :=
  c ∈ caps ∧ (if write then c.kind = 3 else c.kind = 2 ∨ c.kind = 3) ∧
    Childless caps c.name

theorem unique_same_name (caps : List Capability) (unique : Unique caps)
    (a b : Capability) (ha : a ∈ caps) (hb : b ∈ caps) (same : a.name = b.name) : a = b := by
  induction caps with
  | nil => simp at ha
  | cons c rest ih =>
      have nodup : c.name ∉ rest.map Capability.name ∧ Unique rest := by
        simpa only [Unique, List.map_cons, List.nodup_cons] using unique
      rcases List.mem_cons.mp ha with aHead | aTail
      · rcases List.mem_cons.mp hb with bHead | bTail
        · exact aHead.trans bHead.symm
        · exact False.elim (nodup.1 (List.mem_map.mpr
            ⟨b, bTail, same.symm.trans (congrArg Capability.name aHead)⟩))
      · rcases List.mem_cons.mp hb with bHead | bTail
        · exact False.elim (nodup.1 (List.mem_map.mpr
            ⟨a, aTail, same.trans (congrArg Capability.name bHead)⟩))
        · exact ih nodup.2 aTail bTail

theorem path_mono {before after : List Capability} {a b : Nat}
    (subset : ∀ c ∈ before, c ∈ after) (path : ParentPath before a b) : ParentPath after a b := by
  induction path with
  | edge hc hp relation => exact ParentPath.edge (subset _ hc) (subset _ hp) relation
  | trans _ _ ih₁ ih₂ => exact ParentPath.trans ih₁ ih₂

theorem path_endpoints {caps : List Capability} {a b : Nat} (path : ParentPath caps a b) :
    (∃ child ∈ caps, child.name = a) ∧ (∃ parent ∈ caps, parent.name = b) := by
  induction path with
  | edge hc hp relation => exact ⟨⟨_, hc, rfl⟩, ⟨_, hp, rfl⟩⟩
  | trans _ _ ih₁ ih₂ => exact ⟨ih₁.1, ih₂.2⟩

/- Closed subgraphs retain every ancestor of a retained node. Unique names
are necessary to identify the retained record with the original parent. -/
theorem path_retained {before after : List Capability} {a b : Nat}
    (unique : Unique before) (subset : ∀ c ∈ after, c ∈ before) (closed : Closed after)
    (path : ParentPath before a b) (retained : ∃ c ∈ after, c.name = a) :
    ParentPath after a b := by
  induction path with
  | @edge child parent hc hp relation =>
      obtain ⟨kept, hk, same⟩ := retained
      have equal := unique_same_name before unique kept child (subset _ hk) hc same
      subst kept
      obtain ⟨keptParent, hkp, parentName⟩ := (closed child hk).2 parent.name relation
      have equal := unique_same_name before unique keptParent parent (subset _ hkp) hp parentName
      subst keptParent
      exact ParentPath.edge hk hkp relation
  | trans first second ih₁ ih₂ =>
      have firstKept := ih₁ retained
      exact ParentPath.trans firstKept (ih₂ (path_endpoints firstKept).2)

theorem path_rename {caps : List Capability} {a b : Nat}
    (f : Nat → Nat) (path : ParentPath caps a b) :
    ParentPath (caps.map (rename f)) (f a) (f b) := by
  induction path with
  | @edge child parent hc hp relation =>
      apply ParentPath.edge (child := rename f child) (parent := rename f parent)
      · exact List.mem_map.mpr ⟨child, hc, rfl⟩
      · exact List.mem_map.mpr ⟨parent, hp, rfl⟩
      · simp only [ChildOf, rename]
        exact congrArg (Option.map f) relation
  | trans _ _ ih₁ ih₂ => exact ParentPath.trans ih₁ ih₂

theorem comparable_mono {before after : List Capability} {a b : Nat}
    (subset : ∀ c ∈ before, c ∈ after) (related : Comparable before a b) :
    Comparable after a b := by
  rcases related with same | path | path
  · exact Or.inl same
  · exact Or.inr (Or.inl (path_mono subset path))
  · exact Or.inr (Or.inr (path_mono subset path))

theorem comparable_symm {caps : List Capability} {a b : Nat}
    (related : Comparable caps a b) : Comparable caps b a := by
  rcases related with same | path | path
  · exact Or.inl same.symm
  · exact Or.inr (Or.inr path)
  · exact Or.inr (Or.inl path)

theorem compatible_owner (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (compatible : Compatible caps) :
    Compatible (owner name kind :: caps) := by
  intro a ha b hb roots mutable
  rcases List.mem_cons.mp ha with rfl | ha
  · rcases List.mem_cons.mp hb with rfl | hb
    · exact Or.inl rfl
    · obtain ⟨root, hr, rootName⟩ := (closed b hb).1
      exact False.elim (fresh root hr (rootName.trans roots.symm))
  · rcases List.mem_cons.mp hb with rfl | hb
    · obtain ⟨root, hr, rootName⟩ := (closed a ha).1
      exact False.elim (fresh root hr (rootName.trans roots))
    · exact comparable_mono (fun _ h => List.mem_cons_of_mem _ h) (compatible a ha b hb roots mutable)

theorem loan_ancestor_path (caps : List Capability) (source : Capability) (name kind other : Nat)
    (member : source ∈ caps) (ancestor : Ancestor caps source.name other) :
    ParentPath (loan source name kind :: caps) name other := by
  have parentPath : ParentPath (loan source name kind :: caps) name source.name :=
    ParentPath.edge (child := loan source name kind) (parent := source)
      (by simp) (List.mem_cons_of_mem _ member) rfl
  rcases ancestor with same | path
  · exact same ▸ parentPath
  · exact ParentPath.trans parentPath (path_mono (fun _ h => List.mem_cons_of_mem _ h) path)

theorem compatible_loan (caps : List Capability) (source : Capability) (name kind : Nat)
    (member : source ∈ caps) (guard : BorrowGuard caps source kind) (compatible : Compatible caps) :
    Compatible (loan source name kind :: caps) := by
  intro a ha b hb roots mutable
  rcases List.mem_cons.mp ha with rfl | ha
  · rcases List.mem_cons.mp hb with rfl | hb
    · exact Or.inl rfl
    · exact Or.inr (Or.inl (loan_ancestor_path caps source name kind b.name member
        (guard b hb roots.symm mutable)))
  · rcases List.mem_cons.mp hb with rfl | hb
    · exact Or.inr (Or.inr (loan_ancestor_path caps source name kind a.name member
        (guard a ha roots mutable.symm)))
    · exact comparable_mono (fun _ h => List.mem_cons_of_mem _ h) (compatible a ha b hb roots mutable)

theorem compatible_subgraph {before after : List Capability}
    (unique : Unique before) (subset : ∀ c ∈ after, c ∈ before) (closed : Closed after)
    (compatible : Compatible before) : Compatible after := by
  intro a ha b hb roots mutable
  rcases compatible a (subset _ ha) b (subset _ hb) roots mutable with same | path | path
  · exact Or.inl same
  · exact Or.inr (Or.inl (path_retained unique subset closed path ⟨a, ha, rfl⟩))
  · exact Or.inr (Or.inr (path_retained unique subset closed path ⟨b, hb, rfl⟩))

theorem compatible_erase (caps : List Capability) (name : Nat)
    (closed : Closed caps) (unique : Unique caps) (free : Unreferenced caps name)
    (compatible : Compatible caps) : Compatible (erase name caps) :=
  compatible_subgraph unique (fun c h => ((erased_member caps name c).mp h).1)
    (erase_closed caps name closed free) compatible

theorem compatible_projection (caps : List Capability) (keep : Nat → Bool)
    (unique : Unique caps) (closed : Closed (project keep caps)) (compatible : Compatible caps) :
    Compatible (project keep caps) :=
  compatible_subgraph unique (fun c h => ((projected_member caps keep c).mp h).1) closed compatible

theorem compatible_rename (caps : List Capability) (f : Nat → Nat) (inj : Injective f)
    (compatible : Compatible caps) : Compatible (caps.map (rename f)) := by
  intro a ha b hb roots mutable
  obtain ⟨originalA, memberA, rfl⟩ := List.mem_map.mp ha
  obtain ⟨originalB, memberB, rfl⟩ := List.mem_map.mp hb
  rcases compatible originalA memberA originalB memberB (inj _ _ roots) mutable with same | path | path
  · exact Or.inl (congrArg f same)
  · exact Or.inr (Or.inl (path_rename f path))
  · exact Or.inr (Or.inr (path_rename f path))

theorem transfer_compatible {before after : List Capability} (transfer : Transfer before after)
    (unique : Unique before) (compatible : Compatible before) : Compatible after := by
  obtain ⟨keep, f, admitted, inj, rfl⟩ := transfer
  exact compatible_rename _ f inj (compatible_projection before keep unique admitted.2 compatible)

theorem child_blocks_access {caps : List Capability} {parent child : Capability} {write : Bool}
    (member : child ∈ caps) (relation : ChildOf child parent) : ¬ Access caps parent write := by
  intro access
  exact access.2.2 child member relation

theorem path_last_child {caps : List Capability} {a b : Nat} (path : ParentPath caps a b) :
    ∃ child ∈ caps, child.parent = some b := by
  induction path with
  | edge hc hp relation => exact ⟨_, hc, relation⟩
  | trans _ _ ih₁ ih₂ => exact ih₂

theorem ancestor_blocks_access {caps : List Capability} {parent : Capability} {child : Nat} {write : Bool}
    (path : ParentPath caps child parent.name) : ¬ Access caps parent write := by
  obtain ⟨c, member, relation⟩ := path_last_child path
  exact child_blocks_access member relation

theorem accessible_exclusive {caps : List Capability} {a b : Capability} {writeA writeB : Bool}
    (compatible : Compatible caps) (accessA : Access caps a writeA) (accessB : Access caps b writeB)
    (sameRoot : a.root = b.root) (different : a.name ≠ b.name) : a.kind ≠ 3 ∧ b.kind ≠ 3 := by
  have impossible : ¬ (a.kind = 3 ∨ b.kind = 3) := by
    intro mutable
    rcases compatible a accessA.1 b accessB.1 sameRoot mutable with same | path | path
    · exact different same
    · exact ancestor_blocks_access path accessB
    · exact ancestor_blocks_access path accessA
  exact ⟨fun h => impossible (Or.inl h), fun h => impossible (Or.inr h)⟩

theorem borrow_suspends_source (caps : List Capability) (source : Capability) (name kind : Nat)
    (write : Bool) : ¬ Access (loan source name kind :: caps) source write :=
  child_blocks_access (child := loan source name kind) (by simp) rfl

theorem end_restores_access (caps : List Capability) (parent : Capability) (ended : Nat) (write : Bool)
    (member : parent ∈ caps) (different : parent.name ≠ ended)
    (permission : if write then parent.kind = 3 else parent.kind = 2 ∨ parent.kind = 3)
    (lastChild : ∀ child ∈ caps, child.parent = some parent.name → child.name = ended) :
    Access (erase ended caps) parent write := by
  refine ⟨(erased_member caps ended parent).mpr ⟨member, different⟩, permission, ?_⟩
  intro child retained relation
  obtain ⟨old, notEnded⟩ := (erased_member caps ended child).mp retained
  exact notEnded (lastChild child old relation)

/- This selected relation has pre-state guards and no after-state safety
premise. Calls, moves, chains and other instruction effects remain outside. -/
inductive Step : List Capability → List Capability → Prop where
  | allocate {caps name kind} : Fresh caps name → (kind = 0 ∨ kind = 1) →
      Step caps (owner name kind :: caps)
  | borrowRead {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 2 ∨ source.kind = 3) → BorrowGuard caps source 2 →
      Step caps (loan source name 2 :: caps)
  | borrowMut {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 3) → BorrowGuard caps source 3 →
      Step caps (loan source name 3 :: caps)
  | endLoan {caps c} : c ∈ caps → c.external = false →
      (c.kind = 2 ∨ c.kind = 3) → Unreferenced caps c.name →
      Step caps (erase c.name caps)
  | dropOwner {caps c} : c ∈ caps → c.external = false →
      (c.kind = 0 ∨ c.kind = 1) → c.root = c.name → c.parent = none →
      Unreferenced caps c.name → Step caps (erase c.name caps)
  | access {caps c write} : Access caps c write → Step caps caps

theorem step_structural {before after : List Capability} (step : Step before after) :
    HiaCapabilityLifecycle.Step before after ∨ before = after := by
  cases step with
  | allocate fresh kind => exact Or.inl (.allocate fresh kind)
  | borrowRead member fresh kind guard => exact Or.inl (.borrowRead member fresh kind)
  | borrowMut member fresh kind guard => exact Or.inl (.borrowMut member fresh kind)
  | endLoan member localCap kind free => exact Or.inl (.endLoan member localCap kind free)
  | dropOwner member localCap kind root parent free => exact Or.inl (.dropOwner member localCap kind root parent free)
  | access access => exact Or.inr rfl

theorem step_closed {before after : List Capability} (step : Step before after)
    (closed : Closed before) : Closed after := by
  rcases step_structural step with structural | rfl
  · exact HiaCapabilityLifecycle.step_closed structural closed
  · exact closed

theorem step_ranked {before after : List Capability} (step : Step before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  rcases step_structural step with structural | rfl
  · exact HiaCapabilityLifecycle.step_ranked structural closed ranked
  · exact ranked

theorem step_unique {before after : List Capability} (step : Step before after)
    (unique : Unique before) : Unique after := by
  rcases step_structural step with structural | rfl
  · exact HiaCapabilityLifecycle.step_unique structural unique
  · exact unique

theorem step_compatible {before after : List Capability} (step : Step before after)
    (closed : Closed before) (unique : Unique before) (compatible : Compatible before) : Compatible after := by
  cases step with
  | allocate fresh kind => exact compatible_owner _ _ _ closed fresh compatible
  | borrowRead member fresh kind guard => exact compatible_loan _ _ _ _ member guard compatible
  | borrowMut member fresh kind guard => exact compatible_loan _ _ _ _ member guard compatible
  | endLoan member localCap kind free => exact compatible_erase _ _ closed unique free compatible
  | dropOwner member localCap kind root parent free => exact compatible_erase _ _ closed unique free compatible
  | access access => exact compatible

inductive Trace : List Capability → List Capability → Prop where
  | refl (caps) : Trace caps caps
  | instruction {before middle after} : Trace before middle → Step middle after → Trace before after
  | edge {before middle after} : Trace before middle → Transfer middle after → Trace before after

theorem trace_closed {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) : Closed after := by
  induction trace with
  | refl => exact closed
  | instruction _ step ih => exact step_closed step ih
  | edge _ transfer ih => exact transfer_closed transfer

theorem trace_ranked {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | instruction earlier step ih => exact step_ranked step (trace_closed earlier closed) ih
  | edge _ transfer ih => exact transfer_ranked transfer ih

theorem trace_unique {before after : List Capability} (trace : Trace before after)
    (unique : Unique before) : Unique after := by
  induction trace with
  | refl => exact unique
  | instruction _ step ih => exact step_unique step ih
  | edge _ transfer ih => exact transfer_unique transfer ih

theorem trace_compatible {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (unique : Unique before) (compatible : Compatible before) : Compatible after := by
  induction trace with
  | refl => exact compatible
  | instruction earlier step ih =>
      exact step_compatible step (trace_closed earlier closed) (trace_unique earlier unique) ih
  | edge earlier transfer ih => exact transfer_compatible transfer (trace_unique earlier unique) ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace closed ranked) name

theorem trace_accessible_exclusive {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (unique : Unique before) (compatible : Compatible before)
    {a b : Capability} {writeA writeB : Bool} (accessA : Access after a writeA) (accessB : Access after b writeB)
    (sameRoot : a.root = b.root) (different : a.name ≠ b.name) : a.kind ≠ 3 ∧ b.kind ≠ 3 :=
  accessible_exclusive (trace_compatible trace closed unique compatible) accessA accessB sameRoot different

end HiaCapabilityBorrow

namespace HiaCapabilityBorrow
open HiaCapabilityRenaming HiaCapabilityLifecycle
def instruction0Before : List Capability := []
def instruction0After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction0Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction0_result : instruction0After = owner 0 0 :: instruction0Before := by decide
theorem instruction0_step : Step instruction0Before instruction0After := by
  rw [instruction0_result]
  exact Step.allocate (by simp [Fresh, instruction0Before]) (by decide)
theorem instruction0_closed_before : Closed instruction0Before := by
  simp [Closed, instruction0Before]
theorem instruction0_ranked_before : Ranked instruction0Before := by
  refine ⟨instruction0Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction0Before, instruction0Rank]
theorem instruction0_unique_before : Unique instruction0Before := by
  simp [Unique, instruction0Before]
theorem instruction0_compatible_before : Compatible instruction0Before := by
  simp [Compatible, Comparable, instruction0Before]
theorem instruction0_closed_after : Closed instruction0After :=
  step_closed instruction0_step instruction0_closed_before
theorem instruction0_ranked_after : Ranked instruction0After :=
  step_ranked instruction0_step instruction0_closed_before instruction0_ranked_before
theorem instruction0_unique_after : Unique instruction0After :=
  step_unique instruction0_step instruction0_unique_before
theorem instruction0_compatible_after : Compatible instruction0After :=
  step_compatible instruction0_step instruction0_closed_before instruction0_unique_before instruction0_compatible_before
theorem instruction0_no_parent_cycle (name : Nat) : ¬ ParentPath instruction0After name name :=
  ranked_no_parent_cycle instruction0After instruction0_ranked_after name
def instruction1Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction1After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction1Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction1Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction1_borrow_guard : BorrowGuard instruction1Before instruction1Source 3 := by
  simp [BorrowGuard, Ancestor, instruction1Before, instruction1Source]
theorem instruction1_result : instruction1After = loan instruction1Source 1 3 :: instruction1Before := by decide
theorem instruction1_step : Step instruction1Before instruction1After := by
  rw [instruction1_result]
  exact Step.borrowMut (by simp [instruction1Source, instruction1Before]) (by simp [Fresh, instruction1Before]) (by decide) instruction1_borrow_guard
theorem instruction1_closed_before : Closed instruction1Before := by
  simp [Closed, instruction1Before]
theorem instruction1_ranked_before : Ranked instruction1Before := by
  refine ⟨instruction1Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction1Before, instruction1Rank]
theorem instruction1_unique_before : Unique instruction1Before := by
  simp [Unique, instruction1Before]
theorem instruction1_compatible_before : Compatible instruction1Before := by
  simp [Compatible, Comparable, instruction1Before]
theorem instruction1_closed_after : Closed instruction1After :=
  step_closed instruction1_step instruction1_closed_before
theorem instruction1_ranked_after : Ranked instruction1After :=
  step_ranked instruction1_step instruction1_closed_before instruction1_ranked_before
theorem instruction1_unique_after : Unique instruction1After :=
  step_unique instruction1_step instruction1_unique_before
theorem instruction1_compatible_after : Compatible instruction1After :=
  step_compatible instruction1_step instruction1_closed_before instruction1_unique_before instruction1_compatible_before
theorem instruction1_no_parent_cycle (name : Nat) : ¬ ParentPath instruction1After name name :=
  ranked_no_parent_cycle instruction1After instruction1_ranked_after name
theorem instruction1_source_suspended (write : Bool) : ¬ Access instruction1After instruction1Source write := by
  rw [instruction1_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction2Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def instruction2After : List Capability := [⟨1, 0, (some 2), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def instruction2Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 2 => 1
  | _ => 0
def instruction2Source : Capability := ⟨2, 0, (some 0), 3, false, none⟩
theorem instruction2_path0 : ParentPath instruction2Before 2 0 :=
  ParentPath.edge (child := ⟨2, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction2Before]) (by simp [instruction2Before]) rfl
theorem instruction2_borrow_guard : BorrowGuard instruction2Before instruction2Source 2 := by
  have path0 := instruction2_path0
  simp only [instruction2Before] at path0
  simp [BorrowGuard, Ancestor, instruction2Before, instruction2Source, path0]
theorem instruction2_result : instruction2After = loan instruction2Source 1 2 :: instruction2Before := by decide
theorem instruction2_step : Step instruction2Before instruction2After := by
  rw [instruction2_result]
  exact Step.borrowRead (by simp [instruction2Source, instruction2Before]) (by simp [Fresh, instruction2Before]) (by decide) instruction2_borrow_guard
theorem instruction2_closed_before : Closed instruction2Before := by
  simp [Closed, instruction2Before]
theorem instruction2_ranked_before : Ranked instruction2Before := by
  refine ⟨instruction2Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction2Before, instruction2Rank]
theorem instruction2_unique_before : Unique instruction2Before := by
  simp [Unique, instruction2Before]
theorem instruction2_compatible_before : Compatible instruction2Before := by
  have path0 := instruction2_path0
  simp only [instruction2Before] at path0
  simp [Compatible, Comparable, instruction2Before, path0]
theorem instruction2_closed_after : Closed instruction2After :=
  step_closed instruction2_step instruction2_closed_before
theorem instruction2_ranked_after : Ranked instruction2After :=
  step_ranked instruction2_step instruction2_closed_before instruction2_ranked_before
theorem instruction2_unique_after : Unique instruction2After :=
  step_unique instruction2_step instruction2_unique_before
theorem instruction2_compatible_after : Compatible instruction2After :=
  step_compatible instruction2_step instruction2_closed_before instruction2_unique_before instruction2_compatible_before
theorem instruction2_no_parent_cycle (name : Nat) : ¬ ParentPath instruction2After name name :=
  ranked_no_parent_cycle instruction2After instruction2_ranked_after name
theorem instruction2_source_suspended (write : Bool) : ¬ Access instruction2After instruction2Source write := by
  rw [instruction2_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction3Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction3After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction3Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction3Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction3_path0 : ParentPath instruction3Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction3Before]) (by simp [instruction3Before]) rfl
theorem instruction3_path1 : ParentPath instruction3Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction3Before]) (by simp [instruction3Before]) rfl
theorem instruction3_path2 : ParentPath instruction3Before 2 0 :=
  ParentPath.trans instruction3_path1 instruction3_path0
theorem instruction3_access : Access instruction3Before instruction3Source false := by
  simp [Access, Childless, instruction3Before, instruction3Source]
theorem instruction3_result : instruction3After = instruction3Before := by decide
theorem instruction3_step : Step instruction3Before instruction3After := by
  rw [instruction3_result]
  exact Step.access instruction3_access
theorem instruction3_closed_before : Closed instruction3Before := by
  simp [Closed, instruction3Before]
theorem instruction3_ranked_before : Ranked instruction3Before := by
  refine ⟨instruction3Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction3Before, instruction3Rank]
theorem instruction3_unique_before : Unique instruction3Before := by
  simp [Unique, instruction3Before]
theorem instruction3_compatible_before : Compatible instruction3Before := by
  have path0 := instruction3_path0
  simp only [instruction3Before] at path0
  have path1 := instruction3_path1
  simp only [instruction3Before] at path1
  have path2 := instruction3_path2
  simp only [instruction3Before] at path2
  simp [Compatible, Comparable, instruction3Before, path0, path1, path2]
theorem instruction3_closed_after : Closed instruction3After :=
  step_closed instruction3_step instruction3_closed_before
theorem instruction3_ranked_after : Ranked instruction3After :=
  step_ranked instruction3_step instruction3_closed_before instruction3_ranked_before
theorem instruction3_unique_after : Unique instruction3After :=
  step_unique instruction3_step instruction3_unique_before
theorem instruction3_compatible_after : Compatible instruction3After :=
  step_compatible instruction3_step instruction3_closed_before instruction3_unique_before instruction3_compatible_before
theorem instruction3_no_parent_cycle (name : Nat) : ¬ ParentPath instruction3After name name :=
  ranked_no_parent_cycle instruction3After instruction3_ranked_after name
def instruction4Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction4After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction4Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction4Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction4_path0 : ParentPath instruction4Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction4Before]) (by simp [instruction4Before]) rfl
theorem instruction4_path1 : ParentPath instruction4Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction4Before]) (by simp [instruction4Before]) rfl
theorem instruction4_path2 : ParentPath instruction4Before 2 0 :=
  ParentPath.trans instruction4_path1 instruction4_path0
theorem instruction4_result : instruction4After = erase instruction4Source.name instruction4Before := by decide
theorem instruction4_step : Step instruction4Before instruction4After := by
  rw [instruction4_result]
  exact Step.endLoan (c := instruction4Source) (by simp [instruction4Source, instruction4Before]) (by decide) (by decide) (by simp [Unreferenced, instruction4Before, instruction4Source])
theorem instruction4_closed_before : Closed instruction4Before := by
  simp [Closed, instruction4Before]
theorem instruction4_ranked_before : Ranked instruction4Before := by
  refine ⟨instruction4Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction4Before, instruction4Rank]
theorem instruction4_unique_before : Unique instruction4Before := by
  simp [Unique, instruction4Before]
theorem instruction4_compatible_before : Compatible instruction4Before := by
  have path0 := instruction4_path0
  simp only [instruction4Before] at path0
  have path1 := instruction4_path1
  simp only [instruction4Before] at path1
  have path2 := instruction4_path2
  simp only [instruction4Before] at path2
  simp [Compatible, Comparable, instruction4Before, path0, path1, path2]
theorem instruction4_closed_after : Closed instruction4After :=
  step_closed instruction4_step instruction4_closed_before
theorem instruction4_ranked_after : Ranked instruction4After :=
  step_ranked instruction4_step instruction4_closed_before instruction4_ranked_before
theorem instruction4_unique_after : Unique instruction4After :=
  step_unique instruction4_step instruction4_unique_before
theorem instruction4_compatible_after : Compatible instruction4After :=
  step_compatible instruction4_step instruction4_closed_before instruction4_unique_before instruction4_compatible_before
theorem instruction4_no_parent_cycle (name : Nat) : ¬ ParentPath instruction4After name name :=
  ranked_no_parent_cycle instruction4After instruction4_ranked_after name
def instruction5Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction5After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction5Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction5Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction5_path0 : ParentPath instruction5Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction5Before]) (by simp [instruction5Before]) rfl
theorem instruction5_access : Access instruction5Before instruction5Source true := by
  simp [Access, Childless, instruction5Before, instruction5Source]
theorem instruction5_result : instruction5After = instruction5Before := by decide
theorem instruction5_step : Step instruction5Before instruction5After := by
  rw [instruction5_result]
  exact Step.access instruction5_access
theorem instruction5_closed_before : Closed instruction5Before := by
  simp [Closed, instruction5Before]
theorem instruction5_ranked_before : Ranked instruction5Before := by
  refine ⟨instruction5Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction5Before, instruction5Rank]
theorem instruction5_unique_before : Unique instruction5Before := by
  simp [Unique, instruction5Before]
theorem instruction5_compatible_before : Compatible instruction5Before := by
  have path0 := instruction5_path0
  simp only [instruction5Before] at path0
  simp [Compatible, Comparable, instruction5Before, path0]
theorem instruction5_closed_after : Closed instruction5After :=
  step_closed instruction5_step instruction5_closed_before
theorem instruction5_ranked_after : Ranked instruction5After :=
  step_ranked instruction5_step instruction5_closed_before instruction5_ranked_before
theorem instruction5_unique_after : Unique instruction5After :=
  step_unique instruction5_step instruction5_unique_before
theorem instruction5_compatible_after : Compatible instruction5After :=
  step_compatible instruction5_step instruction5_closed_before instruction5_unique_before instruction5_compatible_before
theorem instruction5_no_parent_cycle (name : Nat) : ¬ ParentPath instruction5After name name :=
  ranked_no_parent_cycle instruction5After instruction5_ranked_after name
def instruction6Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction6After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction6Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction6Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction6_path0 : ParentPath instruction6Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction6Before]) (by simp [instruction6Before]) rfl
theorem instruction6_result : instruction6After = erase instruction6Source.name instruction6Before := by decide
theorem instruction6_step : Step instruction6Before instruction6After := by
  rw [instruction6_result]
  exact Step.endLoan (c := instruction6Source) (by simp [instruction6Source, instruction6Before]) (by decide) (by decide) (by simp [Unreferenced, instruction6Before, instruction6Source])
theorem instruction6_closed_before : Closed instruction6Before := by
  simp [Closed, instruction6Before]
theorem instruction6_ranked_before : Ranked instruction6Before := by
  refine ⟨instruction6Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction6Before, instruction6Rank]
theorem instruction6_unique_before : Unique instruction6Before := by
  simp [Unique, instruction6Before]
theorem instruction6_compatible_before : Compatible instruction6Before := by
  have path0 := instruction6_path0
  simp only [instruction6Before] at path0
  simp [Compatible, Comparable, instruction6Before, path0]
theorem instruction6_closed_after : Closed instruction6After :=
  step_closed instruction6_step instruction6_closed_before
theorem instruction6_ranked_after : Ranked instruction6After :=
  step_ranked instruction6_step instruction6_closed_before instruction6_ranked_before
theorem instruction6_unique_after : Unique instruction6After :=
  step_unique instruction6_step instruction6_unique_before
theorem instruction6_compatible_after : Compatible instruction6After :=
  step_compatible instruction6_step instruction6_closed_before instruction6_unique_before instruction6_compatible_before
theorem instruction6_no_parent_cycle (name : Nat) : ¬ ParentPath instruction6After name name :=
  ranked_no_parent_cycle instruction6After instruction6_ranked_after name
def instruction7Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction7After : List Capability := [⟨1, 0, (some 0), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction7Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction7Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction7_borrow_guard : BorrowGuard instruction7Before instruction7Source 2 := by
  simp [BorrowGuard, Ancestor, instruction7Before, instruction7Source]
theorem instruction7_result : instruction7After = loan instruction7Source 1 2 :: instruction7Before := by decide
theorem instruction7_step : Step instruction7Before instruction7After := by
  rw [instruction7_result]
  exact Step.borrowRead (by simp [instruction7Source, instruction7Before]) (by simp [Fresh, instruction7Before]) (by decide) instruction7_borrow_guard
theorem instruction7_closed_before : Closed instruction7Before := by
  simp [Closed, instruction7Before]
theorem instruction7_ranked_before : Ranked instruction7Before := by
  refine ⟨instruction7Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction7Before, instruction7Rank]
theorem instruction7_unique_before : Unique instruction7Before := by
  simp [Unique, instruction7Before]
theorem instruction7_compatible_before : Compatible instruction7Before := by
  simp [Compatible, Comparable, instruction7Before]
theorem instruction7_closed_after : Closed instruction7After :=
  step_closed instruction7_step instruction7_closed_before
theorem instruction7_ranked_after : Ranked instruction7After :=
  step_ranked instruction7_step instruction7_closed_before instruction7_ranked_before
theorem instruction7_unique_after : Unique instruction7After :=
  step_unique instruction7_step instruction7_unique_before
theorem instruction7_compatible_after : Compatible instruction7After :=
  step_compatible instruction7_step instruction7_closed_before instruction7_unique_before instruction7_compatible_before
theorem instruction7_no_parent_cycle (name : Nat) : ¬ ParentPath instruction7After name name :=
  ranked_no_parent_cycle instruction7After instruction7_ranked_after name
theorem instruction7_source_suspended (write : Bool) : ¬ Access instruction7After instruction7Source write := by
  rw [instruction7_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction8Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction8After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction8Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction8Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction8_path0 : ParentPath instruction8Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction8Before]) (by simp [instruction8Before]) rfl
theorem instruction8_access : Access instruction8Before instruction8Source false := by
  simp [Access, Childless, instruction8Before, instruction8Source]
theorem instruction8_result : instruction8After = instruction8Before := by decide
theorem instruction8_step : Step instruction8Before instruction8After := by
  rw [instruction8_result]
  exact Step.access instruction8_access
theorem instruction8_closed_before : Closed instruction8Before := by
  simp [Closed, instruction8Before]
theorem instruction8_ranked_before : Ranked instruction8Before := by
  refine ⟨instruction8Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction8Before, instruction8Rank]
theorem instruction8_unique_before : Unique instruction8Before := by
  simp [Unique, instruction8Before]
theorem instruction8_compatible_before : Compatible instruction8Before := by
  have path0 := instruction8_path0
  simp only [instruction8Before] at path0
  simp [Compatible, Comparable, instruction8Before, path0]
theorem instruction8_closed_after : Closed instruction8After :=
  step_closed instruction8_step instruction8_closed_before
theorem instruction8_ranked_after : Ranked instruction8After :=
  step_ranked instruction8_step instruction8_closed_before instruction8_ranked_before
theorem instruction8_unique_after : Unique instruction8After :=
  step_unique instruction8_step instruction8_unique_before
theorem instruction8_compatible_after : Compatible instruction8After :=
  step_compatible instruction8_step instruction8_closed_before instruction8_unique_before instruction8_compatible_before
theorem instruction8_no_parent_cycle (name : Nat) : ¬ ParentPath instruction8After name name :=
  ranked_no_parent_cycle instruction8After instruction8_ranked_after name
def instruction9Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction9After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction9Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction9Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction9_path0 : ParentPath instruction9Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction9Before]) (by simp [instruction9Before]) rfl
theorem instruction9_result : instruction9After = erase instruction9Source.name instruction9Before := by decide
theorem instruction9_step : Step instruction9Before instruction9After := by
  rw [instruction9_result]
  exact Step.endLoan (c := instruction9Source) (by simp [instruction9Source, instruction9Before]) (by decide) (by decide) (by simp [Unreferenced, instruction9Before, instruction9Source])
theorem instruction9_closed_before : Closed instruction9Before := by
  simp [Closed, instruction9Before]
theorem instruction9_ranked_before : Ranked instruction9Before := by
  refine ⟨instruction9Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction9Before, instruction9Rank]
theorem instruction9_unique_before : Unique instruction9Before := by
  simp [Unique, instruction9Before]
theorem instruction9_compatible_before : Compatible instruction9Before := by
  have path0 := instruction9_path0
  simp only [instruction9Before] at path0
  simp [Compatible, Comparable, instruction9Before, path0]
theorem instruction9_closed_after : Closed instruction9After :=
  step_closed instruction9_step instruction9_closed_before
theorem instruction9_ranked_after : Ranked instruction9After :=
  step_ranked instruction9_step instruction9_closed_before instruction9_ranked_before
theorem instruction9_unique_after : Unique instruction9After :=
  step_unique instruction9_step instruction9_unique_before
theorem instruction9_compatible_after : Compatible instruction9After :=
  step_compatible instruction9_step instruction9_closed_before instruction9_unique_before instruction9_compatible_before
theorem instruction9_no_parent_cycle (name : Nat) : ¬ ParentPath instruction9After name name :=
  ranked_no_parent_cycle instruction9After instruction9_ranked_after name
def instruction10Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction10After : List Capability := []
def instruction10Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction10Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction10_result : instruction10After = erase instruction10Source.name instruction10Before := by decide
theorem instruction10_step : Step instruction10Before instruction10After := by
  rw [instruction10_result]
  exact Step.dropOwner (c := instruction10Source) (by simp [instruction10Source, instruction10Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction10Before, instruction10Source])
theorem instruction10_closed_before : Closed instruction10Before := by
  simp [Closed, instruction10Before]
theorem instruction10_ranked_before : Ranked instruction10Before := by
  refine ⟨instruction10Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction10Before, instruction10Rank]
theorem instruction10_unique_before : Unique instruction10Before := by
  simp [Unique, instruction10Before]
theorem instruction10_compatible_before : Compatible instruction10Before := by
  simp [Compatible, Comparable, instruction10Before]
theorem instruction10_closed_after : Closed instruction10After :=
  step_closed instruction10_step instruction10_closed_before
theorem instruction10_ranked_after : Ranked instruction10After :=
  step_ranked instruction10_step instruction10_closed_before instruction10_ranked_before
theorem instruction10_unique_after : Unique instruction10After :=
  step_unique instruction10_step instruction10_unique_before
theorem instruction10_compatible_after : Compatible instruction10After :=
  step_compatible instruction10_step instruction10_closed_before instruction10_unique_before instruction10_compatible_before
theorem instruction10_no_parent_cycle (name : Nat) : ¬ ParentPath instruction10After name name :=
  ranked_no_parent_cycle instruction10After instruction10_ranked_after name
def instruction11Before : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def instruction11After : List Capability := [⟨1, 0, (some 0), 2, false, (some 0)⟩, ⟨0, 0, none, 2, true, (some 0)⟩]
def instruction11Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction11Source : Capability := ⟨0, 0, none, 2, true, (some 0)⟩
theorem instruction11_borrow_guard : BorrowGuard instruction11Before instruction11Source 2 := by
  simp [BorrowGuard, Ancestor, instruction11Before, instruction11Source]
theorem instruction11_result : instruction11After = loan instruction11Source 1 2 :: instruction11Before := by decide
theorem instruction11_step : Step instruction11Before instruction11After := by
  rw [instruction11_result]
  exact Step.borrowRead (by simp [instruction11Source, instruction11Before]) (by simp [Fresh, instruction11Before]) (by decide) instruction11_borrow_guard
theorem instruction11_closed_before : Closed instruction11Before := by
  simp [Closed, instruction11Before]
theorem instruction11_ranked_before : Ranked instruction11Before := by
  refine ⟨instruction11Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction11Before, instruction11Rank]
theorem instruction11_unique_before : Unique instruction11Before := by
  simp [Unique, instruction11Before]
theorem instruction11_compatible_before : Compatible instruction11Before := by
  simp [Compatible, Comparable, instruction11Before]
theorem instruction11_closed_after : Closed instruction11After :=
  step_closed instruction11_step instruction11_closed_before
theorem instruction11_ranked_after : Ranked instruction11After :=
  step_ranked instruction11_step instruction11_closed_before instruction11_ranked_before
theorem instruction11_unique_after : Unique instruction11After :=
  step_unique instruction11_step instruction11_unique_before
theorem instruction11_compatible_after : Compatible instruction11After :=
  step_compatible instruction11_step instruction11_closed_before instruction11_unique_before instruction11_compatible_before
theorem instruction11_no_parent_cycle (name : Nat) : ¬ ParentPath instruction11After name name :=
  ranked_no_parent_cycle instruction11After instruction11_ranked_after name
theorem instruction11_source_suspended (write : Bool) : ¬ Access instruction11After instruction11Source write := by
  rw [instruction11_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction12Before : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def instruction12After : List Capability := [⟨1, 0, (some 0), 2, false, (some 0)⟩, ⟨0, 0, none, 2, true, (some 0)⟩]
def instruction12Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction12Source : Capability := ⟨0, 0, none, 2, true, (some 0)⟩
theorem instruction12_borrow_guard : BorrowGuard instruction12Before instruction12Source 2 := by
  simp [BorrowGuard, Ancestor, instruction12Before, instruction12Source]
theorem instruction12_result : instruction12After = loan instruction12Source 1 2 :: instruction12Before := by decide
theorem instruction12_step : Step instruction12Before instruction12After := by
  rw [instruction12_result]
  exact Step.borrowRead (by simp [instruction12Source, instruction12Before]) (by simp [Fresh, instruction12Before]) (by decide) instruction12_borrow_guard
theorem instruction12_closed_before : Closed instruction12Before := by
  simp [Closed, instruction12Before]
theorem instruction12_ranked_before : Ranked instruction12Before := by
  refine ⟨instruction12Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction12Before, instruction12Rank]
theorem instruction12_unique_before : Unique instruction12Before := by
  simp [Unique, instruction12Before]
theorem instruction12_compatible_before : Compatible instruction12Before := by
  simp [Compatible, Comparable, instruction12Before]
theorem instruction12_closed_after : Closed instruction12After :=
  step_closed instruction12_step instruction12_closed_before
theorem instruction12_ranked_after : Ranked instruction12After :=
  step_ranked instruction12_step instruction12_closed_before instruction12_ranked_before
theorem instruction12_unique_after : Unique instruction12After :=
  step_unique instruction12_step instruction12_unique_before
theorem instruction12_compatible_after : Compatible instruction12After :=
  step_compatible instruction12_step instruction12_closed_before instruction12_unique_before instruction12_compatible_before
theorem instruction12_no_parent_cycle (name : Nat) : ¬ ParentPath instruction12After name name :=
  ranked_no_parent_cycle instruction12After instruction12_ranked_after name
theorem instruction12_source_suspended (write : Bool) : ¬ Access instruction12After instruction12Source write := by
  rw [instruction12_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction13Before : List Capability := [⟨0, 0, none, 3, true, (some 0)⟩]
def instruction13After : List Capability := [⟨1, 0, (some 0), 3, false, (some 0)⟩, ⟨0, 0, none, 3, true, (some 0)⟩]
def instruction13Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction13Source : Capability := ⟨0, 0, none, 3, true, (some 0)⟩
theorem instruction13_borrow_guard : BorrowGuard instruction13Before instruction13Source 3 := by
  simp [BorrowGuard, Ancestor, instruction13Before, instruction13Source]
theorem instruction13_result : instruction13After = loan instruction13Source 1 3 :: instruction13Before := by decide
theorem instruction13_step : Step instruction13Before instruction13After := by
  rw [instruction13_result]
  exact Step.borrowMut (by simp [instruction13Source, instruction13Before]) (by simp [Fresh, instruction13Before]) (by decide) instruction13_borrow_guard
theorem instruction13_closed_before : Closed instruction13Before := by
  simp [Closed, instruction13Before]
theorem instruction13_ranked_before : Ranked instruction13Before := by
  refine ⟨instruction13Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction13Before, instruction13Rank]
theorem instruction13_unique_before : Unique instruction13Before := by
  simp [Unique, instruction13Before]
theorem instruction13_compatible_before : Compatible instruction13Before := by
  simp [Compatible, Comparable, instruction13Before]
theorem instruction13_closed_after : Closed instruction13After :=
  step_closed instruction13_step instruction13_closed_before
theorem instruction13_ranked_after : Ranked instruction13After :=
  step_ranked instruction13_step instruction13_closed_before instruction13_ranked_before
theorem instruction13_unique_after : Unique instruction13After :=
  step_unique instruction13_step instruction13_unique_before
theorem instruction13_compatible_after : Compatible instruction13After :=
  step_compatible instruction13_step instruction13_closed_before instruction13_unique_before instruction13_compatible_before
theorem instruction13_no_parent_cycle (name : Nat) : ¬ ParentPath instruction13After name name :=
  ranked_no_parent_cycle instruction13After instruction13_ranked_after name
theorem instruction13_source_suspended (write : Bool) : ¬ Access instruction13After instruction13Source write := by
  rw [instruction13_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction14Before : List Capability := []
def instruction14After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction14Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction14_result : instruction14After = owner 0 0 :: instruction14Before := by decide
theorem instruction14_step : Step instruction14Before instruction14After := by
  rw [instruction14_result]
  exact Step.allocate (by simp [Fresh, instruction14Before]) (by decide)
theorem instruction14_closed_before : Closed instruction14Before := by
  simp [Closed, instruction14Before]
theorem instruction14_ranked_before : Ranked instruction14Before := by
  refine ⟨instruction14Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction14Before, instruction14Rank]
theorem instruction14_unique_before : Unique instruction14Before := by
  simp [Unique, instruction14Before]
theorem instruction14_compatible_before : Compatible instruction14Before := by
  simp [Compatible, Comparable, instruction14Before]
theorem instruction14_closed_after : Closed instruction14After :=
  step_closed instruction14_step instruction14_closed_before
theorem instruction14_ranked_after : Ranked instruction14After :=
  step_ranked instruction14_step instruction14_closed_before instruction14_ranked_before
theorem instruction14_unique_after : Unique instruction14After :=
  step_unique instruction14_step instruction14_unique_before
theorem instruction14_compatible_after : Compatible instruction14After :=
  step_compatible instruction14_step instruction14_closed_before instruction14_unique_before instruction14_compatible_before
theorem instruction14_no_parent_cycle (name : Nat) : ¬ ParentPath instruction14After name name :=
  ranked_no_parent_cycle instruction14After instruction14_ranked_after name
def instruction15Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction15After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction15Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction15Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction15_borrow_guard : BorrowGuard instruction15Before instruction15Source 3 := by
  simp [BorrowGuard, Ancestor, instruction15Before, instruction15Source]
theorem instruction15_result : instruction15After = loan instruction15Source 1 3 :: instruction15Before := by decide
theorem instruction15_step : Step instruction15Before instruction15After := by
  rw [instruction15_result]
  exact Step.borrowMut (by simp [instruction15Source, instruction15Before]) (by simp [Fresh, instruction15Before]) (by decide) instruction15_borrow_guard
theorem instruction15_closed_before : Closed instruction15Before := by
  simp [Closed, instruction15Before]
theorem instruction15_ranked_before : Ranked instruction15Before := by
  refine ⟨instruction15Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction15Before, instruction15Rank]
theorem instruction15_unique_before : Unique instruction15Before := by
  simp [Unique, instruction15Before]
theorem instruction15_compatible_before : Compatible instruction15Before := by
  simp [Compatible, Comparable, instruction15Before]
theorem instruction15_closed_after : Closed instruction15After :=
  step_closed instruction15_step instruction15_closed_before
theorem instruction15_ranked_after : Ranked instruction15After :=
  step_ranked instruction15_step instruction15_closed_before instruction15_ranked_before
theorem instruction15_unique_after : Unique instruction15After :=
  step_unique instruction15_step instruction15_unique_before
theorem instruction15_compatible_after : Compatible instruction15After :=
  step_compatible instruction15_step instruction15_closed_before instruction15_unique_before instruction15_compatible_before
theorem instruction15_no_parent_cycle (name : Nat) : ¬ ParentPath instruction15After name name :=
  ranked_no_parent_cycle instruction15After instruction15_ranked_after name
theorem instruction15_source_suspended (write : Bool) : ¬ Access instruction15After instruction15Source write := by
  rw [instruction15_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction16Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction16After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction16Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction16Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction16_path0 : ParentPath instruction16Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction16Before]) (by simp [instruction16Before]) rfl
theorem instruction16_access : Access instruction16Before instruction16Source true := by
  simp [Access, Childless, instruction16Before, instruction16Source]
theorem instruction16_result : instruction16After = instruction16Before := by decide
theorem instruction16_step : Step instruction16Before instruction16After := by
  rw [instruction16_result]
  exact Step.access instruction16_access
theorem instruction16_closed_before : Closed instruction16Before := by
  simp [Closed, instruction16Before]
theorem instruction16_ranked_before : Ranked instruction16Before := by
  refine ⟨instruction16Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction16Before, instruction16Rank]
theorem instruction16_unique_before : Unique instruction16Before := by
  simp [Unique, instruction16Before]
theorem instruction16_compatible_before : Compatible instruction16Before := by
  have path0 := instruction16_path0
  simp only [instruction16Before] at path0
  simp [Compatible, Comparable, instruction16Before, path0]
theorem instruction16_closed_after : Closed instruction16After :=
  step_closed instruction16_step instruction16_closed_before
theorem instruction16_ranked_after : Ranked instruction16After :=
  step_ranked instruction16_step instruction16_closed_before instruction16_ranked_before
theorem instruction16_unique_after : Unique instruction16After :=
  step_unique instruction16_step instruction16_unique_before
theorem instruction16_compatible_after : Compatible instruction16After :=
  step_compatible instruction16_step instruction16_closed_before instruction16_unique_before instruction16_compatible_before
theorem instruction16_no_parent_cycle (name : Nat) : ¬ ParentPath instruction16After name name :=
  ranked_no_parent_cycle instruction16After instruction16_ranked_after name
def instruction17Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction17After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction17Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction17Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction17_path0 : ParentPath instruction17Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction17Before]) (by simp [instruction17Before]) rfl
theorem instruction17_result : instruction17After = erase instruction17Source.name instruction17Before := by decide
theorem instruction17_step : Step instruction17Before instruction17After := by
  rw [instruction17_result]
  exact Step.endLoan (c := instruction17Source) (by simp [instruction17Source, instruction17Before]) (by decide) (by decide) (by simp [Unreferenced, instruction17Before, instruction17Source])
theorem instruction17_closed_before : Closed instruction17Before := by
  simp [Closed, instruction17Before]
theorem instruction17_ranked_before : Ranked instruction17Before := by
  refine ⟨instruction17Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction17Before, instruction17Rank]
theorem instruction17_unique_before : Unique instruction17Before := by
  simp [Unique, instruction17Before]
theorem instruction17_compatible_before : Compatible instruction17Before := by
  have path0 := instruction17_path0
  simp only [instruction17Before] at path0
  simp [Compatible, Comparable, instruction17Before, path0]
theorem instruction17_closed_after : Closed instruction17After :=
  step_closed instruction17_step instruction17_closed_before
theorem instruction17_ranked_after : Ranked instruction17After :=
  step_ranked instruction17_step instruction17_closed_before instruction17_ranked_before
theorem instruction17_unique_after : Unique instruction17After :=
  step_unique instruction17_step instruction17_unique_before
theorem instruction17_compatible_after : Compatible instruction17After :=
  step_compatible instruction17_step instruction17_closed_before instruction17_unique_before instruction17_compatible_before
theorem instruction17_no_parent_cycle (name : Nat) : ¬ ParentPath instruction17After name name :=
  ranked_no_parent_cycle instruction17After instruction17_ranked_after name
def instruction18Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction18After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction18Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction18Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction18_borrow_guard : BorrowGuard instruction18Before instruction18Source 3 := by
  simp [BorrowGuard, Ancestor, instruction18Before, instruction18Source]
theorem instruction18_result : instruction18After = loan instruction18Source 1 3 :: instruction18Before := by decide
theorem instruction18_step : Step instruction18Before instruction18After := by
  rw [instruction18_result]
  exact Step.borrowMut (by simp [instruction18Source, instruction18Before]) (by simp [Fresh, instruction18Before]) (by decide) instruction18_borrow_guard
theorem instruction18_closed_before : Closed instruction18Before := by
  simp [Closed, instruction18Before]
theorem instruction18_ranked_before : Ranked instruction18Before := by
  refine ⟨instruction18Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction18Before, instruction18Rank]
theorem instruction18_unique_before : Unique instruction18Before := by
  simp [Unique, instruction18Before]
theorem instruction18_compatible_before : Compatible instruction18Before := by
  simp [Compatible, Comparable, instruction18Before]
theorem instruction18_closed_after : Closed instruction18After :=
  step_closed instruction18_step instruction18_closed_before
theorem instruction18_ranked_after : Ranked instruction18After :=
  step_ranked instruction18_step instruction18_closed_before instruction18_ranked_before
theorem instruction18_unique_after : Unique instruction18After :=
  step_unique instruction18_step instruction18_unique_before
theorem instruction18_compatible_after : Compatible instruction18After :=
  step_compatible instruction18_step instruction18_closed_before instruction18_unique_before instruction18_compatible_before
theorem instruction18_no_parent_cycle (name : Nat) : ¬ ParentPath instruction18After name name :=
  ranked_no_parent_cycle instruction18After instruction18_ranked_after name
theorem instruction18_source_suspended (write : Bool) : ¬ Access instruction18After instruction18Source write := by
  rw [instruction18_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction19Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction19After : List Capability := [⟨3, 0, (some 2), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction19Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction19Source : Capability := ⟨2, 0, (some 1), 3, false, none⟩
theorem instruction19_path0 : ParentPath instruction19Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction19Before]) (by simp [instruction19Before]) rfl
theorem instruction19_path1 : ParentPath instruction19Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 3, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction19Before]) (by simp [instruction19Before]) rfl
theorem instruction19_path2 : ParentPath instruction19Before 2 0 :=
  ParentPath.trans instruction19_path1 instruction19_path0
theorem instruction19_borrow_guard : BorrowGuard instruction19Before instruction19Source 2 := by
  have path0 := instruction19_path0
  simp only [instruction19Before] at path0
  have path1 := instruction19_path1
  simp only [instruction19Before] at path1
  have path2 := instruction19_path2
  simp only [instruction19Before] at path2
  simp [BorrowGuard, Ancestor, instruction19Before, instruction19Source, path0, path1, path2]
theorem instruction19_result : instruction19After = loan instruction19Source 3 2 :: instruction19Before := by decide
theorem instruction19_step : Step instruction19Before instruction19After := by
  rw [instruction19_result]
  exact Step.borrowRead (by simp [instruction19Source, instruction19Before]) (by simp [Fresh, instruction19Before]) (by decide) instruction19_borrow_guard
theorem instruction19_closed_before : Closed instruction19Before := by
  simp [Closed, instruction19Before]
theorem instruction19_ranked_before : Ranked instruction19Before := by
  refine ⟨instruction19Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction19Before, instruction19Rank]
theorem instruction19_unique_before : Unique instruction19Before := by
  simp [Unique, instruction19Before]
theorem instruction19_compatible_before : Compatible instruction19Before := by
  have path0 := instruction19_path0
  simp only [instruction19Before] at path0
  have path1 := instruction19_path1
  simp only [instruction19Before] at path1
  have path2 := instruction19_path2
  simp only [instruction19Before] at path2
  simp [Compatible, Comparable, instruction19Before, path0, path1, path2]
theorem instruction19_closed_after : Closed instruction19After :=
  step_closed instruction19_step instruction19_closed_before
theorem instruction19_ranked_after : Ranked instruction19After :=
  step_ranked instruction19_step instruction19_closed_before instruction19_ranked_before
theorem instruction19_unique_after : Unique instruction19After :=
  step_unique instruction19_step instruction19_unique_before
theorem instruction19_compatible_after : Compatible instruction19After :=
  step_compatible instruction19_step instruction19_closed_before instruction19_unique_before instruction19_compatible_before
theorem instruction19_no_parent_cycle (name : Nat) : ¬ ParentPath instruction19After name name :=
  ranked_no_parent_cycle instruction19After instruction19_ranked_after name
theorem instruction19_source_suspended (write : Bool) : ¬ Access instruction19After instruction19Source write := by
  rw [instruction19_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction20Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction20After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction20Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | _ => 0
def instruction20Source : Capability := ⟨3, 0, (some 2), 2, false, none⟩
theorem instruction20_path0 : ParentPath instruction20Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction20Before]) (by simp [instruction20Before]) rfl
theorem instruction20_path1 : ParentPath instruction20Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 3, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction20Before]) (by simp [instruction20Before]) rfl
theorem instruction20_path2 : ParentPath instruction20Before 3 2 :=
  ParentPath.edge (child := ⟨3, 0, (some 2), 2, false, none⟩) (parent := ⟨2, 0, (some 1), 3, false, none⟩) (by simp [instruction20Before]) (by simp [instruction20Before]) rfl
theorem instruction20_path3 : ParentPath instruction20Before 2 0 :=
  ParentPath.trans instruction20_path1 instruction20_path0
theorem instruction20_path4 : ParentPath instruction20Before 3 1 :=
  ParentPath.trans instruction20_path2 instruction20_path1
theorem instruction20_path5 : ParentPath instruction20Before 3 0 :=
  ParentPath.trans instruction20_path2 instruction20_path3
theorem instruction20_access : Access instruction20Before instruction20Source false := by
  simp [Access, Childless, instruction20Before, instruction20Source]
theorem instruction20_result : instruction20After = instruction20Before := by decide
theorem instruction20_step : Step instruction20Before instruction20After := by
  rw [instruction20_result]
  exact Step.access instruction20_access
theorem instruction20_closed_before : Closed instruction20Before := by
  simp [Closed, instruction20Before]
theorem instruction20_ranked_before : Ranked instruction20Before := by
  refine ⟨instruction20Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction20Before, instruction20Rank]
theorem instruction20_unique_before : Unique instruction20Before := by
  simp [Unique, instruction20Before]
theorem instruction20_compatible_before : Compatible instruction20Before := by
  have path0 := instruction20_path0
  simp only [instruction20Before] at path0
  have path1 := instruction20_path1
  simp only [instruction20Before] at path1
  have path2 := instruction20_path2
  simp only [instruction20Before] at path2
  have path3 := instruction20_path3
  simp only [instruction20Before] at path3
  have path4 := instruction20_path4
  simp only [instruction20Before] at path4
  have path5 := instruction20_path5
  simp only [instruction20Before] at path5
  simp [Compatible, Comparable, instruction20Before, path0, path1, path2, path3, path4, path5]
theorem instruction20_closed_after : Closed instruction20After :=
  step_closed instruction20_step instruction20_closed_before
theorem instruction20_ranked_after : Ranked instruction20After :=
  step_ranked instruction20_step instruction20_closed_before instruction20_ranked_before
theorem instruction20_unique_after : Unique instruction20After :=
  step_unique instruction20_step instruction20_unique_before
theorem instruction20_compatible_after : Compatible instruction20After :=
  step_compatible instruction20_step instruction20_closed_before instruction20_unique_before instruction20_compatible_before
theorem instruction20_no_parent_cycle (name : Nat) : ¬ ParentPath instruction20After name name :=
  ranked_no_parent_cycle instruction20After instruction20_ranked_after name
def instruction21Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction21After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction21Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | _ => 0
def instruction21Source : Capability := ⟨3, 0, (some 2), 2, false, none⟩
theorem instruction21_path0 : ParentPath instruction21Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction21Before]) (by simp [instruction21Before]) rfl
theorem instruction21_path1 : ParentPath instruction21Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 3, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction21Before]) (by simp [instruction21Before]) rfl
theorem instruction21_path2 : ParentPath instruction21Before 3 2 :=
  ParentPath.edge (child := ⟨3, 0, (some 2), 2, false, none⟩) (parent := ⟨2, 0, (some 1), 3, false, none⟩) (by simp [instruction21Before]) (by simp [instruction21Before]) rfl
theorem instruction21_path3 : ParentPath instruction21Before 2 0 :=
  ParentPath.trans instruction21_path1 instruction21_path0
theorem instruction21_path4 : ParentPath instruction21Before 3 1 :=
  ParentPath.trans instruction21_path2 instruction21_path1
theorem instruction21_path5 : ParentPath instruction21Before 3 0 :=
  ParentPath.trans instruction21_path2 instruction21_path3
theorem instruction21_result : instruction21After = erase instruction21Source.name instruction21Before := by decide
theorem instruction21_step : Step instruction21Before instruction21After := by
  rw [instruction21_result]
  exact Step.endLoan (c := instruction21Source) (by simp [instruction21Source, instruction21Before]) (by decide) (by decide) (by simp [Unreferenced, instruction21Before, instruction21Source])
theorem instruction21_closed_before : Closed instruction21Before := by
  simp [Closed, instruction21Before]
theorem instruction21_ranked_before : Ranked instruction21Before := by
  refine ⟨instruction21Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction21Before, instruction21Rank]
theorem instruction21_unique_before : Unique instruction21Before := by
  simp [Unique, instruction21Before]
theorem instruction21_compatible_before : Compatible instruction21Before := by
  have path0 := instruction21_path0
  simp only [instruction21Before] at path0
  have path1 := instruction21_path1
  simp only [instruction21Before] at path1
  have path2 := instruction21_path2
  simp only [instruction21Before] at path2
  have path3 := instruction21_path3
  simp only [instruction21Before] at path3
  have path4 := instruction21_path4
  simp only [instruction21Before] at path4
  have path5 := instruction21_path5
  simp only [instruction21Before] at path5
  simp [Compatible, Comparable, instruction21Before, path0, path1, path2, path3, path4, path5]
theorem instruction21_closed_after : Closed instruction21After :=
  step_closed instruction21_step instruction21_closed_before
theorem instruction21_ranked_after : Ranked instruction21After :=
  step_ranked instruction21_step instruction21_closed_before instruction21_ranked_before
theorem instruction21_unique_after : Unique instruction21After :=
  step_unique instruction21_step instruction21_unique_before
theorem instruction21_compatible_after : Compatible instruction21After :=
  step_compatible instruction21_step instruction21_closed_before instruction21_unique_before instruction21_compatible_before
theorem instruction21_no_parent_cycle (name : Nat) : ¬ ParentPath instruction21After name name :=
  ranked_no_parent_cycle instruction21After instruction21_ranked_after name
def instruction22Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction22After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction22Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction22Source : Capability := ⟨2, 0, (some 1), 3, false, none⟩
theorem instruction22_path0 : ParentPath instruction22Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction22Before]) (by simp [instruction22Before]) rfl
theorem instruction22_path1 : ParentPath instruction22Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 3, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction22Before]) (by simp [instruction22Before]) rfl
theorem instruction22_path2 : ParentPath instruction22Before 2 0 :=
  ParentPath.trans instruction22_path1 instruction22_path0
theorem instruction22_result : instruction22After = erase instruction22Source.name instruction22Before := by decide
theorem instruction22_step : Step instruction22Before instruction22After := by
  rw [instruction22_result]
  exact Step.endLoan (c := instruction22Source) (by simp [instruction22Source, instruction22Before]) (by decide) (by decide) (by simp [Unreferenced, instruction22Before, instruction22Source])
theorem instruction22_closed_before : Closed instruction22Before := by
  simp [Closed, instruction22Before]
theorem instruction22_ranked_before : Ranked instruction22Before := by
  refine ⟨instruction22Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction22Before, instruction22Rank]
theorem instruction22_unique_before : Unique instruction22Before := by
  simp [Unique, instruction22Before]
theorem instruction22_compatible_before : Compatible instruction22Before := by
  have path0 := instruction22_path0
  simp only [instruction22Before] at path0
  have path1 := instruction22_path1
  simp only [instruction22Before] at path1
  have path2 := instruction22_path2
  simp only [instruction22Before] at path2
  simp [Compatible, Comparable, instruction22Before, path0, path1, path2]
theorem instruction22_closed_after : Closed instruction22After :=
  step_closed instruction22_step instruction22_closed_before
theorem instruction22_ranked_after : Ranked instruction22After :=
  step_ranked instruction22_step instruction22_closed_before instruction22_ranked_before
theorem instruction22_unique_after : Unique instruction22After :=
  step_unique instruction22_step instruction22_unique_before
theorem instruction22_compatible_after : Compatible instruction22After :=
  step_compatible instruction22_step instruction22_closed_before instruction22_unique_before instruction22_compatible_before
theorem instruction22_no_parent_cycle (name : Nat) : ¬ ParentPath instruction22After name name :=
  ranked_no_parent_cycle instruction22After instruction22_ranked_after name
def instruction23Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction23After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction23Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction23Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction23_path0 : ParentPath instruction23Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction23Before]) (by simp [instruction23Before]) rfl
theorem instruction23_result : instruction23After = erase instruction23Source.name instruction23Before := by decide
theorem instruction23_step : Step instruction23Before instruction23After := by
  rw [instruction23_result]
  exact Step.endLoan (c := instruction23Source) (by simp [instruction23Source, instruction23Before]) (by decide) (by decide) (by simp [Unreferenced, instruction23Before, instruction23Source])
theorem instruction23_closed_before : Closed instruction23Before := by
  simp [Closed, instruction23Before]
theorem instruction23_ranked_before : Ranked instruction23Before := by
  refine ⟨instruction23Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction23Before, instruction23Rank]
theorem instruction23_unique_before : Unique instruction23Before := by
  simp [Unique, instruction23Before]
theorem instruction23_compatible_before : Compatible instruction23Before := by
  have path0 := instruction23_path0
  simp only [instruction23Before] at path0
  simp [Compatible, Comparable, instruction23Before, path0]
theorem instruction23_closed_after : Closed instruction23After :=
  step_closed instruction23_step instruction23_closed_before
theorem instruction23_ranked_after : Ranked instruction23After :=
  step_ranked instruction23_step instruction23_closed_before instruction23_ranked_before
theorem instruction23_unique_after : Unique instruction23After :=
  step_unique instruction23_step instruction23_unique_before
theorem instruction23_compatible_after : Compatible instruction23After :=
  step_compatible instruction23_step instruction23_closed_before instruction23_unique_before instruction23_compatible_before
theorem instruction23_no_parent_cycle (name : Nat) : ¬ ParentPath instruction23After name name :=
  ranked_no_parent_cycle instruction23After instruction23_ranked_after name
def instruction24Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction24After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction24Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction24Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction24_borrow_guard : BorrowGuard instruction24Before instruction24Source 3 := by
  simp [BorrowGuard, Ancestor, instruction24Before, instruction24Source]
theorem instruction24_result : instruction24After = loan instruction24Source 1 3 :: instruction24Before := by decide
theorem instruction24_step : Step instruction24Before instruction24After := by
  rw [instruction24_result]
  exact Step.borrowMut (by simp [instruction24Source, instruction24Before]) (by simp [Fresh, instruction24Before]) (by decide) instruction24_borrow_guard
theorem instruction24_closed_before : Closed instruction24Before := by
  simp [Closed, instruction24Before]
theorem instruction24_ranked_before : Ranked instruction24Before := by
  refine ⟨instruction24Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction24Before, instruction24Rank]
theorem instruction24_unique_before : Unique instruction24Before := by
  simp [Unique, instruction24Before]
theorem instruction24_compatible_before : Compatible instruction24Before := by
  simp [Compatible, Comparable, instruction24Before]
theorem instruction24_closed_after : Closed instruction24After :=
  step_closed instruction24_step instruction24_closed_before
theorem instruction24_ranked_after : Ranked instruction24After :=
  step_ranked instruction24_step instruction24_closed_before instruction24_ranked_before
theorem instruction24_unique_after : Unique instruction24After :=
  step_unique instruction24_step instruction24_unique_before
theorem instruction24_compatible_after : Compatible instruction24After :=
  step_compatible instruction24_step instruction24_closed_before instruction24_unique_before instruction24_compatible_before
theorem instruction24_no_parent_cycle (name : Nat) : ¬ ParentPath instruction24After name name :=
  ranked_no_parent_cycle instruction24After instruction24_ranked_after name
theorem instruction24_source_suspended (write : Bool) : ¬ Access instruction24After instruction24Source write := by
  rw [instruction24_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction25Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction25After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction25Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction25Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction25_path0 : ParentPath instruction25Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction25Before]) (by simp [instruction25Before]) rfl
theorem instruction25_access : Access instruction25Before instruction25Source true := by
  simp [Access, Childless, instruction25Before, instruction25Source]
theorem instruction25_result : instruction25After = instruction25Before := by decide
theorem instruction25_step : Step instruction25Before instruction25After := by
  rw [instruction25_result]
  exact Step.access instruction25_access
theorem instruction25_closed_before : Closed instruction25Before := by
  simp [Closed, instruction25Before]
theorem instruction25_ranked_before : Ranked instruction25Before := by
  refine ⟨instruction25Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction25Before, instruction25Rank]
theorem instruction25_unique_before : Unique instruction25Before := by
  simp [Unique, instruction25Before]
theorem instruction25_compatible_before : Compatible instruction25Before := by
  have path0 := instruction25_path0
  simp only [instruction25Before] at path0
  simp [Compatible, Comparable, instruction25Before, path0]
theorem instruction25_closed_after : Closed instruction25After :=
  step_closed instruction25_step instruction25_closed_before
theorem instruction25_ranked_after : Ranked instruction25After :=
  step_ranked instruction25_step instruction25_closed_before instruction25_ranked_before
theorem instruction25_unique_after : Unique instruction25After :=
  step_unique instruction25_step instruction25_unique_before
theorem instruction25_compatible_after : Compatible instruction25After :=
  step_compatible instruction25_step instruction25_closed_before instruction25_unique_before instruction25_compatible_before
theorem instruction25_no_parent_cycle (name : Nat) : ¬ ParentPath instruction25After name name :=
  ranked_no_parent_cycle instruction25After instruction25_ranked_after name
def instruction26Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction26After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction26Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction26Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction26_path0 : ParentPath instruction26Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction26Before]) (by simp [instruction26Before]) rfl
theorem instruction26_result : instruction26After = erase instruction26Source.name instruction26Before := by decide
theorem instruction26_step : Step instruction26Before instruction26After := by
  rw [instruction26_result]
  exact Step.endLoan (c := instruction26Source) (by simp [instruction26Source, instruction26Before]) (by decide) (by decide) (by simp [Unreferenced, instruction26Before, instruction26Source])
theorem instruction26_closed_before : Closed instruction26Before := by
  simp [Closed, instruction26Before]
theorem instruction26_ranked_before : Ranked instruction26Before := by
  refine ⟨instruction26Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction26Before, instruction26Rank]
theorem instruction26_unique_before : Unique instruction26Before := by
  simp [Unique, instruction26Before]
theorem instruction26_compatible_before : Compatible instruction26Before := by
  have path0 := instruction26_path0
  simp only [instruction26Before] at path0
  simp [Compatible, Comparable, instruction26Before, path0]
theorem instruction26_closed_after : Closed instruction26After :=
  step_closed instruction26_step instruction26_closed_before
theorem instruction26_ranked_after : Ranked instruction26After :=
  step_ranked instruction26_step instruction26_closed_before instruction26_ranked_before
theorem instruction26_unique_after : Unique instruction26After :=
  step_unique instruction26_step instruction26_unique_before
theorem instruction26_compatible_after : Compatible instruction26After :=
  step_compatible instruction26_step instruction26_closed_before instruction26_unique_before instruction26_compatible_before
theorem instruction26_no_parent_cycle (name : Nat) : ¬ ParentPath instruction26After name name :=
  ranked_no_parent_cycle instruction26After instruction26_ranked_after name
def instruction27Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction27After : List Capability := [⟨1, 0, (some 0), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction27Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction27Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction27_borrow_guard : BorrowGuard instruction27Before instruction27Source 2 := by
  simp [BorrowGuard, Ancestor, instruction27Before, instruction27Source]
theorem instruction27_result : instruction27After = loan instruction27Source 1 2 :: instruction27Before := by decide
theorem instruction27_step : Step instruction27Before instruction27After := by
  rw [instruction27_result]
  exact Step.borrowRead (by simp [instruction27Source, instruction27Before]) (by simp [Fresh, instruction27Before]) (by decide) instruction27_borrow_guard
theorem instruction27_closed_before : Closed instruction27Before := by
  simp [Closed, instruction27Before]
theorem instruction27_ranked_before : Ranked instruction27Before := by
  refine ⟨instruction27Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction27Before, instruction27Rank]
theorem instruction27_unique_before : Unique instruction27Before := by
  simp [Unique, instruction27Before]
theorem instruction27_compatible_before : Compatible instruction27Before := by
  simp [Compatible, Comparable, instruction27Before]
theorem instruction27_closed_after : Closed instruction27After :=
  step_closed instruction27_step instruction27_closed_before
theorem instruction27_ranked_after : Ranked instruction27After :=
  step_ranked instruction27_step instruction27_closed_before instruction27_ranked_before
theorem instruction27_unique_after : Unique instruction27After :=
  step_unique instruction27_step instruction27_unique_before
theorem instruction27_compatible_after : Compatible instruction27After :=
  step_compatible instruction27_step instruction27_closed_before instruction27_unique_before instruction27_compatible_before
theorem instruction27_no_parent_cycle (name : Nat) : ¬ ParentPath instruction27After name name :=
  ranked_no_parent_cycle instruction27After instruction27_ranked_after name
theorem instruction27_source_suspended (write : Bool) : ¬ Access instruction27After instruction27Source write := by
  rw [instruction27_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction28Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction28After : List Capability := [⟨3, 0, (some 2), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction28Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction28Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction28_path0 : ParentPath instruction28Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction28Before]) (by simp [instruction28Before]) rfl
theorem instruction28_path1 : ParentPath instruction28Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 2, false, none⟩) (by simp [instruction28Before]) (by simp [instruction28Before]) rfl
theorem instruction28_path2 : ParentPath instruction28Before 2 0 :=
  ParentPath.trans instruction28_path1 instruction28_path0
theorem instruction28_borrow_guard : BorrowGuard instruction28Before instruction28Source 2 := by
  have path0 := instruction28_path0
  simp only [instruction28Before] at path0
  have path1 := instruction28_path1
  simp only [instruction28Before] at path1
  have path2 := instruction28_path2
  simp only [instruction28Before] at path2
  simp [BorrowGuard, Ancestor, instruction28Before, instruction28Source, path0, path1, path2]
theorem instruction28_result : instruction28After = loan instruction28Source 3 2 :: instruction28Before := by decide
theorem instruction28_step : Step instruction28Before instruction28After := by
  rw [instruction28_result]
  exact Step.borrowRead (by simp [instruction28Source, instruction28Before]) (by simp [Fresh, instruction28Before]) (by decide) instruction28_borrow_guard
theorem instruction28_closed_before : Closed instruction28Before := by
  simp [Closed, instruction28Before]
theorem instruction28_ranked_before : Ranked instruction28Before := by
  refine ⟨instruction28Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction28Before, instruction28Rank]
theorem instruction28_unique_before : Unique instruction28Before := by
  simp [Unique, instruction28Before]
theorem instruction28_compatible_before : Compatible instruction28Before := by
  have path0 := instruction28_path0
  simp only [instruction28Before] at path0
  have path1 := instruction28_path1
  simp only [instruction28Before] at path1
  have path2 := instruction28_path2
  simp only [instruction28Before] at path2
  simp [Compatible, Comparable, instruction28Before, path0, path1, path2]
theorem instruction28_closed_after : Closed instruction28After :=
  step_closed instruction28_step instruction28_closed_before
theorem instruction28_ranked_after : Ranked instruction28After :=
  step_ranked instruction28_step instruction28_closed_before instruction28_ranked_before
theorem instruction28_unique_after : Unique instruction28After :=
  step_unique instruction28_step instruction28_unique_before
theorem instruction28_compatible_after : Compatible instruction28After :=
  step_compatible instruction28_step instruction28_closed_before instruction28_unique_before instruction28_compatible_before
theorem instruction28_no_parent_cycle (name : Nat) : ¬ ParentPath instruction28After name name :=
  ranked_no_parent_cycle instruction28After instruction28_ranked_after name
theorem instruction28_source_suspended (write : Bool) : ¬ Access instruction28After instruction28Source write := by
  rw [instruction28_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction29Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction29After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction29Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | _ => 0
def instruction29Source : Capability := ⟨3, 0, (some 2), 2, false, none⟩
theorem instruction29_path0 : ParentPath instruction29Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction29Before]) (by simp [instruction29Before]) rfl
theorem instruction29_path1 : ParentPath instruction29Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 2, false, none⟩) (by simp [instruction29Before]) (by simp [instruction29Before]) rfl
theorem instruction29_path2 : ParentPath instruction29Before 3 2 :=
  ParentPath.edge (child := ⟨3, 0, (some 2), 2, false, none⟩) (parent := ⟨2, 0, (some 1), 2, false, none⟩) (by simp [instruction29Before]) (by simp [instruction29Before]) rfl
theorem instruction29_path3 : ParentPath instruction29Before 2 0 :=
  ParentPath.trans instruction29_path1 instruction29_path0
theorem instruction29_path4 : ParentPath instruction29Before 3 1 :=
  ParentPath.trans instruction29_path2 instruction29_path1
theorem instruction29_path5 : ParentPath instruction29Before 3 0 :=
  ParentPath.trans instruction29_path2 instruction29_path3
theorem instruction29_access : Access instruction29Before instruction29Source false := by
  simp [Access, Childless, instruction29Before, instruction29Source]
theorem instruction29_result : instruction29After = instruction29Before := by decide
theorem instruction29_step : Step instruction29Before instruction29After := by
  rw [instruction29_result]
  exact Step.access instruction29_access
theorem instruction29_closed_before : Closed instruction29Before := by
  simp [Closed, instruction29Before]
theorem instruction29_ranked_before : Ranked instruction29Before := by
  refine ⟨instruction29Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction29Before, instruction29Rank]
theorem instruction29_unique_before : Unique instruction29Before := by
  simp [Unique, instruction29Before]
theorem instruction29_compatible_before : Compatible instruction29Before := by
  have path0 := instruction29_path0
  simp only [instruction29Before] at path0
  have path1 := instruction29_path1
  simp only [instruction29Before] at path1
  have path2 := instruction29_path2
  simp only [instruction29Before] at path2
  have path3 := instruction29_path3
  simp only [instruction29Before] at path3
  have path4 := instruction29_path4
  simp only [instruction29Before] at path4
  have path5 := instruction29_path5
  simp only [instruction29Before] at path5
  simp [Compatible, Comparable, instruction29Before, path0, path1, path2, path3, path4, path5]
theorem instruction29_closed_after : Closed instruction29After :=
  step_closed instruction29_step instruction29_closed_before
theorem instruction29_ranked_after : Ranked instruction29After :=
  step_ranked instruction29_step instruction29_closed_before instruction29_ranked_before
theorem instruction29_unique_after : Unique instruction29After :=
  step_unique instruction29_step instruction29_unique_before
theorem instruction29_compatible_after : Compatible instruction29After :=
  step_compatible instruction29_step instruction29_closed_before instruction29_unique_before instruction29_compatible_before
theorem instruction29_no_parent_cycle (name : Nat) : ¬ ParentPath instruction29After name name :=
  ranked_no_parent_cycle instruction29After instruction29_ranked_after name
def instruction30Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction30After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction30Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | _ => 0
def instruction30Source : Capability := ⟨3, 0, (some 2), 2, false, none⟩
theorem instruction30_path0 : ParentPath instruction30Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction30Before]) (by simp [instruction30Before]) rfl
theorem instruction30_path1 : ParentPath instruction30Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 2, false, none⟩) (by simp [instruction30Before]) (by simp [instruction30Before]) rfl
theorem instruction30_path2 : ParentPath instruction30Before 3 2 :=
  ParentPath.edge (child := ⟨3, 0, (some 2), 2, false, none⟩) (parent := ⟨2, 0, (some 1), 2, false, none⟩) (by simp [instruction30Before]) (by simp [instruction30Before]) rfl
theorem instruction30_path3 : ParentPath instruction30Before 2 0 :=
  ParentPath.trans instruction30_path1 instruction30_path0
theorem instruction30_path4 : ParentPath instruction30Before 3 1 :=
  ParentPath.trans instruction30_path2 instruction30_path1
theorem instruction30_path5 : ParentPath instruction30Before 3 0 :=
  ParentPath.trans instruction30_path2 instruction30_path3
theorem instruction30_result : instruction30After = erase instruction30Source.name instruction30Before := by decide
theorem instruction30_step : Step instruction30Before instruction30After := by
  rw [instruction30_result]
  exact Step.endLoan (c := instruction30Source) (by simp [instruction30Source, instruction30Before]) (by decide) (by decide) (by simp [Unreferenced, instruction30Before, instruction30Source])
theorem instruction30_closed_before : Closed instruction30Before := by
  simp [Closed, instruction30Before]
theorem instruction30_ranked_before : Ranked instruction30Before := by
  refine ⟨instruction30Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction30Before, instruction30Rank]
theorem instruction30_unique_before : Unique instruction30Before := by
  simp [Unique, instruction30Before]
theorem instruction30_compatible_before : Compatible instruction30Before := by
  have path0 := instruction30_path0
  simp only [instruction30Before] at path0
  have path1 := instruction30_path1
  simp only [instruction30Before] at path1
  have path2 := instruction30_path2
  simp only [instruction30Before] at path2
  have path3 := instruction30_path3
  simp only [instruction30Before] at path3
  have path4 := instruction30_path4
  simp only [instruction30Before] at path4
  have path5 := instruction30_path5
  simp only [instruction30Before] at path5
  simp [Compatible, Comparable, instruction30Before, path0, path1, path2, path3, path4, path5]
theorem instruction30_closed_after : Closed instruction30After :=
  step_closed instruction30_step instruction30_closed_before
theorem instruction30_ranked_after : Ranked instruction30After :=
  step_ranked instruction30_step instruction30_closed_before instruction30_ranked_before
theorem instruction30_unique_after : Unique instruction30After :=
  step_unique instruction30_step instruction30_unique_before
theorem instruction30_compatible_after : Compatible instruction30After :=
  step_compatible instruction30_step instruction30_closed_before instruction30_unique_before instruction30_compatible_before
theorem instruction30_no_parent_cycle (name : Nat) : ¬ ParentPath instruction30After name name :=
  ranked_no_parent_cycle instruction30After instruction30_ranked_after name
def instruction31Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction31After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction31Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction31Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction31_path0 : ParentPath instruction31Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction31Before]) (by simp [instruction31Before]) rfl
theorem instruction31_path1 : ParentPath instruction31Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 2, false, none⟩) (by simp [instruction31Before]) (by simp [instruction31Before]) rfl
theorem instruction31_path2 : ParentPath instruction31Before 2 0 :=
  ParentPath.trans instruction31_path1 instruction31_path0
theorem instruction31_result : instruction31After = erase instruction31Source.name instruction31Before := by decide
theorem instruction31_step : Step instruction31Before instruction31After := by
  rw [instruction31_result]
  exact Step.endLoan (c := instruction31Source) (by simp [instruction31Source, instruction31Before]) (by decide) (by decide) (by simp [Unreferenced, instruction31Before, instruction31Source])
theorem instruction31_closed_before : Closed instruction31Before := by
  simp [Closed, instruction31Before]
theorem instruction31_ranked_before : Ranked instruction31Before := by
  refine ⟨instruction31Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction31Before, instruction31Rank]
theorem instruction31_unique_before : Unique instruction31Before := by
  simp [Unique, instruction31Before]
theorem instruction31_compatible_before : Compatible instruction31Before := by
  have path0 := instruction31_path0
  simp only [instruction31Before] at path0
  have path1 := instruction31_path1
  simp only [instruction31Before] at path1
  have path2 := instruction31_path2
  simp only [instruction31Before] at path2
  simp [Compatible, Comparable, instruction31Before, path0, path1, path2]
theorem instruction31_closed_after : Closed instruction31After :=
  step_closed instruction31_step instruction31_closed_before
theorem instruction31_ranked_after : Ranked instruction31After :=
  step_ranked instruction31_step instruction31_closed_before instruction31_ranked_before
theorem instruction31_unique_after : Unique instruction31After :=
  step_unique instruction31_step instruction31_unique_before
theorem instruction31_compatible_after : Compatible instruction31After :=
  step_compatible instruction31_step instruction31_closed_before instruction31_unique_before instruction31_compatible_before
theorem instruction31_no_parent_cycle (name : Nat) : ¬ ParentPath instruction31After name name :=
  ranked_no_parent_cycle instruction31After instruction31_ranked_after name
def instruction32Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction32After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction32Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction32Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction32_path0 : ParentPath instruction32Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction32Before]) (by simp [instruction32Before]) rfl
theorem instruction32_result : instruction32After = erase instruction32Source.name instruction32Before := by decide
theorem instruction32_step : Step instruction32Before instruction32After := by
  rw [instruction32_result]
  exact Step.endLoan (c := instruction32Source) (by simp [instruction32Source, instruction32Before]) (by decide) (by decide) (by simp [Unreferenced, instruction32Before, instruction32Source])
theorem instruction32_closed_before : Closed instruction32Before := by
  simp [Closed, instruction32Before]
theorem instruction32_ranked_before : Ranked instruction32Before := by
  refine ⟨instruction32Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction32Before, instruction32Rank]
theorem instruction32_unique_before : Unique instruction32Before := by
  simp [Unique, instruction32Before]
theorem instruction32_compatible_before : Compatible instruction32Before := by
  have path0 := instruction32_path0
  simp only [instruction32Before] at path0
  simp [Compatible, Comparable, instruction32Before, path0]
theorem instruction32_closed_after : Closed instruction32After :=
  step_closed instruction32_step instruction32_closed_before
theorem instruction32_ranked_after : Ranked instruction32After :=
  step_ranked instruction32_step instruction32_closed_before instruction32_ranked_before
theorem instruction32_unique_after : Unique instruction32After :=
  step_unique instruction32_step instruction32_unique_before
theorem instruction32_compatible_after : Compatible instruction32After :=
  step_compatible instruction32_step instruction32_closed_before instruction32_unique_before instruction32_compatible_before
theorem instruction32_no_parent_cycle (name : Nat) : ¬ ParentPath instruction32After name name :=
  ranked_no_parent_cycle instruction32After instruction32_ranked_after name
def instruction33Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction33After : List Capability := []
def instruction33Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction33Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction33_result : instruction33After = erase instruction33Source.name instruction33Before := by decide
theorem instruction33_step : Step instruction33Before instruction33After := by
  rw [instruction33_result]
  exact Step.dropOwner (c := instruction33Source) (by simp [instruction33Source, instruction33Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction33Before, instruction33Source])
theorem instruction33_closed_before : Closed instruction33Before := by
  simp [Closed, instruction33Before]
theorem instruction33_ranked_before : Ranked instruction33Before := by
  refine ⟨instruction33Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction33Before, instruction33Rank]
theorem instruction33_unique_before : Unique instruction33Before := by
  simp [Unique, instruction33Before]
theorem instruction33_compatible_before : Compatible instruction33Before := by
  simp [Compatible, Comparable, instruction33Before]
theorem instruction33_closed_after : Closed instruction33After :=
  step_closed instruction33_step instruction33_closed_before
theorem instruction33_ranked_after : Ranked instruction33After :=
  step_ranked instruction33_step instruction33_closed_before instruction33_ranked_before
theorem instruction33_unique_after : Unique instruction33After :=
  step_unique instruction33_step instruction33_unique_before
theorem instruction33_compatible_after : Compatible instruction33After :=
  step_compatible instruction33_step instruction33_closed_before instruction33_unique_before instruction33_compatible_before
theorem instruction33_no_parent_cycle (name : Nat) : ¬ ParentPath instruction33After name name :=
  ranked_no_parent_cycle instruction33After instruction33_ranked_after name
def instruction34Before : List Capability := []
def instruction34After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction34Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction34_result : instruction34After = owner 0 0 :: instruction34Before := by decide
theorem instruction34_step : Step instruction34Before instruction34After := by
  rw [instruction34_result]
  exact Step.allocate (by simp [Fresh, instruction34Before]) (by decide)
theorem instruction34_closed_before : Closed instruction34Before := by
  simp [Closed, instruction34Before]
theorem instruction34_ranked_before : Ranked instruction34Before := by
  refine ⟨instruction34Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction34Before, instruction34Rank]
theorem instruction34_unique_before : Unique instruction34Before := by
  simp [Unique, instruction34Before]
theorem instruction34_compatible_before : Compatible instruction34Before := by
  simp [Compatible, Comparable, instruction34Before]
theorem instruction34_closed_after : Closed instruction34After :=
  step_closed instruction34_step instruction34_closed_before
theorem instruction34_ranked_after : Ranked instruction34After :=
  step_ranked instruction34_step instruction34_closed_before instruction34_ranked_before
theorem instruction34_unique_after : Unique instruction34After :=
  step_unique instruction34_step instruction34_unique_before
theorem instruction34_compatible_after : Compatible instruction34After :=
  step_compatible instruction34_step instruction34_closed_before instruction34_unique_before instruction34_compatible_before
theorem instruction34_no_parent_cycle (name : Nat) : ¬ ParentPath instruction34After name name :=
  ranked_no_parent_cycle instruction34After instruction34_ranked_after name
def instruction35Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction35After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction35Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction35Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction35_borrow_guard : BorrowGuard instruction35Before instruction35Source 3 := by
  simp [BorrowGuard, Ancestor, instruction35Before, instruction35Source]
theorem instruction35_result : instruction35After = loan instruction35Source 1 3 :: instruction35Before := by decide
theorem instruction35_step : Step instruction35Before instruction35After := by
  rw [instruction35_result]
  exact Step.borrowMut (by simp [instruction35Source, instruction35Before]) (by simp [Fresh, instruction35Before]) (by decide) instruction35_borrow_guard
theorem instruction35_closed_before : Closed instruction35Before := by
  simp [Closed, instruction35Before]
theorem instruction35_ranked_before : Ranked instruction35Before := by
  refine ⟨instruction35Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction35Before, instruction35Rank]
theorem instruction35_unique_before : Unique instruction35Before := by
  simp [Unique, instruction35Before]
theorem instruction35_compatible_before : Compatible instruction35Before := by
  simp [Compatible, Comparable, instruction35Before]
theorem instruction35_closed_after : Closed instruction35After :=
  step_closed instruction35_step instruction35_closed_before
theorem instruction35_ranked_after : Ranked instruction35After :=
  step_ranked instruction35_step instruction35_closed_before instruction35_ranked_before
theorem instruction35_unique_after : Unique instruction35After :=
  step_unique instruction35_step instruction35_unique_before
theorem instruction35_compatible_after : Compatible instruction35After :=
  step_compatible instruction35_step instruction35_closed_before instruction35_unique_before instruction35_compatible_before
theorem instruction35_no_parent_cycle (name : Nat) : ¬ ParentPath instruction35After name name :=
  ranked_no_parent_cycle instruction35After instruction35_ranked_after name
theorem instruction35_source_suspended (write : Bool) : ¬ Access instruction35After instruction35Source write := by
  rw [instruction35_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction36Before : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction36After : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction36Rank (n : Nat) : Nat :=
  match n with
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction36Source : Capability := ⟨2, 1, (some 1), 3, false, none⟩
theorem instruction36_path0 : ParentPath instruction36Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction36Before]) (by simp [instruction36Before]) rfl
theorem instruction36_borrow_guard : BorrowGuard instruction36Before instruction36Source 2 := by
  have path0 := instruction36_path0
  simp only [instruction36Before] at path0
  simp [BorrowGuard, Ancestor, instruction36Before, instruction36Source, path0]
theorem instruction36_result : instruction36After = loan instruction36Source 0 2 :: instruction36Before := by decide
theorem instruction36_step : Step instruction36Before instruction36After := by
  rw [instruction36_result]
  exact Step.borrowRead (by simp [instruction36Source, instruction36Before]) (by simp [Fresh, instruction36Before]) (by decide) instruction36_borrow_guard
theorem instruction36_closed_before : Closed instruction36Before := by
  simp [Closed, instruction36Before]
theorem instruction36_ranked_before : Ranked instruction36Before := by
  refine ⟨instruction36Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction36Before, instruction36Rank]
theorem instruction36_unique_before : Unique instruction36Before := by
  simp [Unique, instruction36Before]
theorem instruction36_compatible_before : Compatible instruction36Before := by
  have path0 := instruction36_path0
  simp only [instruction36Before] at path0
  simp [Compatible, Comparable, instruction36Before, path0]
theorem instruction36_closed_after : Closed instruction36After :=
  step_closed instruction36_step instruction36_closed_before
theorem instruction36_ranked_after : Ranked instruction36After :=
  step_ranked instruction36_step instruction36_closed_before instruction36_ranked_before
theorem instruction36_unique_after : Unique instruction36After :=
  step_unique instruction36_step instruction36_unique_before
theorem instruction36_compatible_after : Compatible instruction36After :=
  step_compatible instruction36_step instruction36_closed_before instruction36_unique_before instruction36_compatible_before
theorem instruction36_no_parent_cycle (name : Nat) : ¬ ParentPath instruction36After name name :=
  ranked_no_parent_cycle instruction36After instruction36_ranked_after name
theorem instruction36_source_suspended (write : Bool) : ¬ Access instruction36After instruction36Source write := by
  rw [instruction36_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction37Before : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction37After : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction37Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction37Source : Capability := ⟨0, 1, (some 2), 2, false, none⟩
theorem instruction37_path0 : ParentPath instruction37Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction37Before]) (by simp [instruction37Before]) rfl
theorem instruction37_path1 : ParentPath instruction37Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction37Before]) (by simp [instruction37Before]) rfl
theorem instruction37_path2 : ParentPath instruction37Before 0 1 :=
  ParentPath.trans instruction37_path0 instruction37_path1
theorem instruction37_result : instruction37After = erase instruction37Source.name instruction37Before := by decide
theorem instruction37_step : Step instruction37Before instruction37After := by
  rw [instruction37_result]
  exact Step.endLoan (c := instruction37Source) (by simp [instruction37Source, instruction37Before]) (by decide) (by decide) (by simp [Unreferenced, instruction37Before, instruction37Source])
theorem instruction37_closed_before : Closed instruction37Before := by
  simp [Closed, instruction37Before]
theorem instruction37_ranked_before : Ranked instruction37Before := by
  refine ⟨instruction37Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction37Before, instruction37Rank]
theorem instruction37_unique_before : Unique instruction37Before := by
  simp [Unique, instruction37Before]
theorem instruction37_compatible_before : Compatible instruction37Before := by
  have path0 := instruction37_path0
  simp only [instruction37Before] at path0
  have path1 := instruction37_path1
  simp only [instruction37Before] at path1
  have path2 := instruction37_path2
  simp only [instruction37Before] at path2
  simp [Compatible, Comparable, instruction37Before, path0, path1, path2]
theorem instruction37_closed_after : Closed instruction37After :=
  step_closed instruction37_step instruction37_closed_before
theorem instruction37_ranked_after : Ranked instruction37After :=
  step_ranked instruction37_step instruction37_closed_before instruction37_ranked_before
theorem instruction37_unique_after : Unique instruction37After :=
  step_unique instruction37_step instruction37_unique_before
theorem instruction37_compatible_after : Compatible instruction37After :=
  step_compatible instruction37_step instruction37_closed_before instruction37_unique_before instruction37_compatible_before
theorem instruction37_no_parent_cycle (name : Nat) : ¬ ParentPath instruction37After name name :=
  ranked_no_parent_cycle instruction37After instruction37_ranked_after name
def instruction38Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction38After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction38Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction38Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction38_path0 : ParentPath instruction38Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction38Before]) (by simp [instruction38Before]) rfl
theorem instruction38_result : instruction38After = erase instruction38Source.name instruction38Before := by decide
theorem instruction38_step : Step instruction38Before instruction38After := by
  rw [instruction38_result]
  exact Step.endLoan (c := instruction38Source) (by simp [instruction38Source, instruction38Before]) (by decide) (by decide) (by simp [Unreferenced, instruction38Before, instruction38Source])
theorem instruction38_closed_before : Closed instruction38Before := by
  simp [Closed, instruction38Before]
theorem instruction38_ranked_before : Ranked instruction38Before := by
  refine ⟨instruction38Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction38Before, instruction38Rank]
theorem instruction38_unique_before : Unique instruction38Before := by
  simp [Unique, instruction38Before]
theorem instruction38_compatible_before : Compatible instruction38Before := by
  have path0 := instruction38_path0
  simp only [instruction38Before] at path0
  simp [Compatible, Comparable, instruction38Before, path0]
theorem instruction38_closed_after : Closed instruction38After :=
  step_closed instruction38_step instruction38_closed_before
theorem instruction38_ranked_after : Ranked instruction38After :=
  step_ranked instruction38_step instruction38_closed_before instruction38_ranked_before
theorem instruction38_unique_after : Unique instruction38After :=
  step_unique instruction38_step instruction38_unique_before
theorem instruction38_compatible_after : Compatible instruction38After :=
  step_compatible instruction38_step instruction38_closed_before instruction38_unique_before instruction38_compatible_before
theorem instruction38_no_parent_cycle (name : Nat) : ¬ ParentPath instruction38After name name :=
  ranked_no_parent_cycle instruction38After instruction38_ranked_after name
def instruction39Before : List Capability := [⟨1, 1, none, 0, false, none⟩]
def instruction39After : List Capability := [⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩]
def instruction39Rank (n : Nat) : Nat :=
  match n with
  | 1 => 0
  | _ => 0
def instruction39Source : Capability := ⟨1, 1, none, 0, false, none⟩
theorem instruction39_borrow_guard : BorrowGuard instruction39Before instruction39Source 2 := by
  simp [BorrowGuard, Ancestor, instruction39Before, instruction39Source]
theorem instruction39_result : instruction39After = loan instruction39Source 0 2 :: instruction39Before := by decide
theorem instruction39_step : Step instruction39Before instruction39After := by
  rw [instruction39_result]
  exact Step.borrowRead (by simp [instruction39Source, instruction39Before]) (by simp [Fresh, instruction39Before]) (by decide) instruction39_borrow_guard
theorem instruction39_closed_before : Closed instruction39Before := by
  simp [Closed, instruction39Before]
theorem instruction39_ranked_before : Ranked instruction39Before := by
  refine ⟨instruction39Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction39Before, instruction39Rank]
theorem instruction39_unique_before : Unique instruction39Before := by
  simp [Unique, instruction39Before]
theorem instruction39_compatible_before : Compatible instruction39Before := by
  simp [Compatible, Comparable, instruction39Before]
theorem instruction39_closed_after : Closed instruction39After :=
  step_closed instruction39_step instruction39_closed_before
theorem instruction39_ranked_after : Ranked instruction39After :=
  step_ranked instruction39_step instruction39_closed_before instruction39_ranked_before
theorem instruction39_unique_after : Unique instruction39After :=
  step_unique instruction39_step instruction39_unique_before
theorem instruction39_compatible_after : Compatible instruction39After :=
  step_compatible instruction39_step instruction39_closed_before instruction39_unique_before instruction39_compatible_before
theorem instruction39_no_parent_cycle (name : Nat) : ¬ ParentPath instruction39After name name :=
  ranked_no_parent_cycle instruction39After instruction39_ranked_after name
theorem instruction39_source_suspended (write : Bool) : ¬ Access instruction39After instruction39Source write := by
  rw [instruction39_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction40Before : List Capability := [⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩]
def instruction40After : List Capability := [⟨2, 1, (some 1), 2, false, none⟩, ⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩]
def instruction40Rank (n : Nat) : Nat :=
  match n with
  | 0 => 1
  | 1 => 0
  | _ => 0
def instruction40Source : Capability := ⟨1, 1, none, 0, false, none⟩
theorem instruction40_path0 : ParentPath instruction40Before 0 1 :=
  ParentPath.edge (child := ⟨0, 1, (some 1), 2, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction40Before]) (by simp [instruction40Before]) rfl
theorem instruction40_borrow_guard : BorrowGuard instruction40Before instruction40Source 2 := by
  have path0 := instruction40_path0
  simp only [instruction40Before] at path0
  simp [BorrowGuard, Ancestor, instruction40Before, instruction40Source, path0]
theorem instruction40_result : instruction40After = loan instruction40Source 2 2 :: instruction40Before := by decide
theorem instruction40_step : Step instruction40Before instruction40After := by
  rw [instruction40_result]
  exact Step.borrowRead (by simp [instruction40Source, instruction40Before]) (by simp [Fresh, instruction40Before]) (by decide) instruction40_borrow_guard
theorem instruction40_closed_before : Closed instruction40Before := by
  simp [Closed, instruction40Before]
theorem instruction40_ranked_before : Ranked instruction40Before := by
  refine ⟨instruction40Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction40Before, instruction40Rank]
theorem instruction40_unique_before : Unique instruction40Before := by
  simp [Unique, instruction40Before]
theorem instruction40_compatible_before : Compatible instruction40Before := by
  have path0 := instruction40_path0
  simp only [instruction40Before] at path0
  simp [Compatible, Comparable, instruction40Before, path0]
theorem instruction40_closed_after : Closed instruction40After :=
  step_closed instruction40_step instruction40_closed_before
theorem instruction40_ranked_after : Ranked instruction40After :=
  step_ranked instruction40_step instruction40_closed_before instruction40_ranked_before
theorem instruction40_unique_after : Unique instruction40After :=
  step_unique instruction40_step instruction40_unique_before
theorem instruction40_compatible_after : Compatible instruction40After :=
  step_compatible instruction40_step instruction40_closed_before instruction40_unique_before instruction40_compatible_before
theorem instruction40_no_parent_cycle (name : Nat) : ¬ ParentPath instruction40After name name :=
  ranked_no_parent_cycle instruction40After instruction40_ranked_after name
theorem instruction40_source_suspended (write : Bool) : ¬ Access instruction40After instruction40Source write := by
  rw [instruction40_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction41Before : List Capability := [⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 2, false, none⟩]
def instruction41After : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 2, false, none⟩]
def instruction41Rank (n : Nat) : Nat :=
  match n with
  | 0 => 1
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction41Source : Capability := ⟨0, 1, (some 1), 2, false, none⟩
theorem instruction41_path0 : ParentPath instruction41Before 0 1 :=
  ParentPath.edge (child := ⟨0, 1, (some 1), 2, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction41Before]) (by simp [instruction41Before]) rfl
theorem instruction41_path1 : ParentPath instruction41Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 2, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction41Before]) (by simp [instruction41Before]) rfl
theorem instruction41_result : instruction41After = erase instruction41Source.name instruction41Before := by decide
theorem instruction41_step : Step instruction41Before instruction41After := by
  rw [instruction41_result]
  exact Step.endLoan (c := instruction41Source) (by simp [instruction41Source, instruction41Before]) (by decide) (by decide) (by simp [Unreferenced, instruction41Before, instruction41Source])
theorem instruction41_closed_before : Closed instruction41Before := by
  simp [Closed, instruction41Before]
theorem instruction41_ranked_before : Ranked instruction41Before := by
  refine ⟨instruction41Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction41Before, instruction41Rank]
theorem instruction41_unique_before : Unique instruction41Before := by
  simp [Unique, instruction41Before]
theorem instruction41_compatible_before : Compatible instruction41Before := by
  have path0 := instruction41_path0
  simp only [instruction41Before] at path0
  have path1 := instruction41_path1
  simp only [instruction41Before] at path1
  simp [Compatible, Comparable, instruction41Before, path0, path1]
theorem instruction41_closed_after : Closed instruction41After :=
  step_closed instruction41_step instruction41_closed_before
theorem instruction41_ranked_after : Ranked instruction41After :=
  step_ranked instruction41_step instruction41_closed_before instruction41_ranked_before
theorem instruction41_unique_after : Unique instruction41After :=
  step_unique instruction41_step instruction41_unique_before
theorem instruction41_compatible_after : Compatible instruction41After :=
  step_compatible instruction41_step instruction41_closed_before instruction41_unique_before instruction41_compatible_before
theorem instruction41_no_parent_cycle (name : Nat) : ¬ ParentPath instruction41After name name :=
  ranked_no_parent_cycle instruction41After instruction41_ranked_after name
def instruction42Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction42After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction42Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction42Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction42_path0 : ParentPath instruction42Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 2, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction42Before]) (by simp [instruction42Before]) rfl
theorem instruction42_result : instruction42After = erase instruction42Source.name instruction42Before := by decide
theorem instruction42_step : Step instruction42Before instruction42After := by
  rw [instruction42_result]
  exact Step.endLoan (c := instruction42Source) (by simp [instruction42Source, instruction42Before]) (by decide) (by decide) (by simp [Unreferenced, instruction42Before, instruction42Source])
theorem instruction42_closed_before : Closed instruction42Before := by
  simp [Closed, instruction42Before]
theorem instruction42_ranked_before : Ranked instruction42Before := by
  refine ⟨instruction42Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction42Before, instruction42Rank]
theorem instruction42_unique_before : Unique instruction42Before := by
  simp [Unique, instruction42Before]
theorem instruction42_compatible_before : Compatible instruction42Before := by
  have path0 := instruction42_path0
  simp only [instruction42Before] at path0
  simp [Compatible, Comparable, instruction42Before, path0]
theorem instruction42_closed_after : Closed instruction42After :=
  step_closed instruction42_step instruction42_closed_before
theorem instruction42_ranked_after : Ranked instruction42After :=
  step_ranked instruction42_step instruction42_closed_before instruction42_ranked_before
theorem instruction42_unique_after : Unique instruction42After :=
  step_unique instruction42_step instruction42_unique_before
theorem instruction42_compatible_after : Compatible instruction42After :=
  step_compatible instruction42_step instruction42_closed_before instruction42_unique_before instruction42_compatible_before
theorem instruction42_no_parent_cycle (name : Nat) : ¬ ParentPath instruction42After name name :=
  ranked_no_parent_cycle instruction42After instruction42_ranked_after name
def instruction43Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction43After : List Capability := []
def instruction43Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction43Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction43_result : instruction43After = erase instruction43Source.name instruction43Before := by decide
theorem instruction43_step : Step instruction43Before instruction43After := by
  rw [instruction43_result]
  exact Step.dropOwner (c := instruction43Source) (by simp [instruction43Source, instruction43Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction43Before, instruction43Source])
theorem instruction43_closed_before : Closed instruction43Before := by
  simp [Closed, instruction43Before]
theorem instruction43_ranked_before : Ranked instruction43Before := by
  refine ⟨instruction43Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction43Before, instruction43Rank]
theorem instruction43_unique_before : Unique instruction43Before := by
  simp [Unique, instruction43Before]
theorem instruction43_compatible_before : Compatible instruction43Before := by
  simp [Compatible, Comparable, instruction43Before]
theorem instruction43_closed_after : Closed instruction43After :=
  step_closed instruction43_step instruction43_closed_before
theorem instruction43_ranked_after : Ranked instruction43After :=
  step_ranked instruction43_step instruction43_closed_before instruction43_ranked_before
theorem instruction43_unique_after : Unique instruction43After :=
  step_unique instruction43_step instruction43_unique_before
theorem instruction43_compatible_after : Compatible instruction43After :=
  step_compatible instruction43_step instruction43_closed_before instruction43_unique_before instruction43_compatible_before
theorem instruction43_no_parent_cycle (name : Nat) : ¬ ParentPath instruction43After name name :=
  ranked_no_parent_cycle instruction43After instruction43_ranked_after name
def instruction44Before : List Capability := []
def instruction44After : List Capability := [⟨0, 0, none, 1, false, none⟩]
def instruction44Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction44_result : instruction44After = owner 0 1 :: instruction44Before := by decide
theorem instruction44_step : Step instruction44Before instruction44After := by
  rw [instruction44_result]
  exact Step.allocate (by simp [Fresh, instruction44Before]) (by decide)
theorem instruction44_closed_before : Closed instruction44Before := by
  simp [Closed, instruction44Before]
theorem instruction44_ranked_before : Ranked instruction44Before := by
  refine ⟨instruction44Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction44Before, instruction44Rank]
theorem instruction44_unique_before : Unique instruction44Before := by
  simp [Unique, instruction44Before]
theorem instruction44_compatible_before : Compatible instruction44Before := by
  simp [Compatible, Comparable, instruction44Before]
theorem instruction44_closed_after : Closed instruction44After :=
  step_closed instruction44_step instruction44_closed_before
theorem instruction44_ranked_after : Ranked instruction44After :=
  step_ranked instruction44_step instruction44_closed_before instruction44_ranked_before
theorem instruction44_unique_after : Unique instruction44After :=
  step_unique instruction44_step instruction44_unique_before
theorem instruction44_compatible_after : Compatible instruction44After :=
  step_compatible instruction44_step instruction44_closed_before instruction44_unique_before instruction44_compatible_before
theorem instruction44_no_parent_cycle (name : Nat) : ¬ ParentPath instruction44After name name :=
  ranked_no_parent_cycle instruction44After instruction44_ranked_after name
def instruction45Before : List Capability := [⟨0, 0, none, 1, false, none⟩]
def instruction45After : List Capability := []
def instruction45Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction45Source : Capability := ⟨0, 0, none, 1, false, none⟩
theorem instruction45_result : instruction45After = erase instruction45Source.name instruction45Before := by decide
theorem instruction45_step : Step instruction45Before instruction45After := by
  rw [instruction45_result]
  exact Step.dropOwner (c := instruction45Source) (by simp [instruction45Source, instruction45Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction45Before, instruction45Source])
theorem instruction45_closed_before : Closed instruction45Before := by
  simp [Closed, instruction45Before]
theorem instruction45_ranked_before : Ranked instruction45Before := by
  refine ⟨instruction45Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction45Before, instruction45Rank]
theorem instruction45_unique_before : Unique instruction45Before := by
  simp [Unique, instruction45Before]
theorem instruction45_compatible_before : Compatible instruction45Before := by
  simp [Compatible, Comparable, instruction45Before]
theorem instruction45_closed_after : Closed instruction45After :=
  step_closed instruction45_step instruction45_closed_before
theorem instruction45_ranked_after : Ranked instruction45After :=
  step_ranked instruction45_step instruction45_closed_before instruction45_ranked_before
theorem instruction45_unique_after : Unique instruction45After :=
  step_unique instruction45_step instruction45_unique_before
theorem instruction45_compatible_after : Compatible instruction45After :=
  step_compatible instruction45_step instruction45_closed_before instruction45_unique_before instruction45_compatible_before
theorem instruction45_no_parent_cycle (name : Nat) : ¬ ParentPath instruction45After name name :=
  ranked_no_parent_cycle instruction45After instruction45_ranked_after name
def instruction46Before : List Capability := []
def instruction46After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction46Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction46_result : instruction46After = owner 0 0 :: instruction46Before := by decide
theorem instruction46_step : Step instruction46Before instruction46After := by
  rw [instruction46_result]
  exact Step.allocate (by simp [Fresh, instruction46Before]) (by decide)
theorem instruction46_closed_before : Closed instruction46Before := by
  simp [Closed, instruction46Before]
theorem instruction46_ranked_before : Ranked instruction46Before := by
  refine ⟨instruction46Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction46Before, instruction46Rank]
theorem instruction46_unique_before : Unique instruction46Before := by
  simp [Unique, instruction46Before]
theorem instruction46_compatible_before : Compatible instruction46Before := by
  simp [Compatible, Comparable, instruction46Before]
theorem instruction46_closed_after : Closed instruction46After :=
  step_closed instruction46_step instruction46_closed_before
theorem instruction46_ranked_after : Ranked instruction46After :=
  step_ranked instruction46_step instruction46_closed_before instruction46_ranked_before
theorem instruction46_unique_after : Unique instruction46After :=
  step_unique instruction46_step instruction46_unique_before
theorem instruction46_compatible_after : Compatible instruction46After :=
  step_compatible instruction46_step instruction46_closed_before instruction46_unique_before instruction46_compatible_before
theorem instruction46_no_parent_cycle (name : Nat) : ¬ ParentPath instruction46After name name :=
  ranked_no_parent_cycle instruction46After instruction46_ranked_after name
def instruction47Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction47After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction47Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction47Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction47_borrow_guard : BorrowGuard instruction47Before instruction47Source 3 := by
  simp [BorrowGuard, Ancestor, instruction47Before, instruction47Source]
theorem instruction47_result : instruction47After = loan instruction47Source 1 3 :: instruction47Before := by decide
theorem instruction47_step : Step instruction47Before instruction47After := by
  rw [instruction47_result]
  exact Step.borrowMut (by simp [instruction47Source, instruction47Before]) (by simp [Fresh, instruction47Before]) (by decide) instruction47_borrow_guard
theorem instruction47_closed_before : Closed instruction47Before := by
  simp [Closed, instruction47Before]
theorem instruction47_ranked_before : Ranked instruction47Before := by
  refine ⟨instruction47Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction47Before, instruction47Rank]
theorem instruction47_unique_before : Unique instruction47Before := by
  simp [Unique, instruction47Before]
theorem instruction47_compatible_before : Compatible instruction47Before := by
  simp [Compatible, Comparable, instruction47Before]
theorem instruction47_closed_after : Closed instruction47After :=
  step_closed instruction47_step instruction47_closed_before
theorem instruction47_ranked_after : Ranked instruction47After :=
  step_ranked instruction47_step instruction47_closed_before instruction47_ranked_before
theorem instruction47_unique_after : Unique instruction47After :=
  step_unique instruction47_step instruction47_unique_before
theorem instruction47_compatible_after : Compatible instruction47After :=
  step_compatible instruction47_step instruction47_closed_before instruction47_unique_before instruction47_compatible_before
theorem instruction47_no_parent_cycle (name : Nat) : ¬ ParentPath instruction47After name name :=
  ranked_no_parent_cycle instruction47After instruction47_ranked_after name
theorem instruction47_source_suspended (write : Bool) : ¬ Access instruction47After instruction47Source write := by
  rw [instruction47_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction48Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction48After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction48Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction48Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction48_path0 : ParentPath instruction48Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction48Before]) (by simp [instruction48Before]) rfl
theorem instruction48_access : Access instruction48Before instruction48Source true := by
  simp [Access, Childless, instruction48Before, instruction48Source]
theorem instruction48_result : instruction48After = instruction48Before := by decide
theorem instruction48_step : Step instruction48Before instruction48After := by
  rw [instruction48_result]
  exact Step.access instruction48_access
theorem instruction48_closed_before : Closed instruction48Before := by
  simp [Closed, instruction48Before]
theorem instruction48_ranked_before : Ranked instruction48Before := by
  refine ⟨instruction48Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction48Before, instruction48Rank]
theorem instruction48_unique_before : Unique instruction48Before := by
  simp [Unique, instruction48Before]
theorem instruction48_compatible_before : Compatible instruction48Before := by
  have path0 := instruction48_path0
  simp only [instruction48Before] at path0
  simp [Compatible, Comparable, instruction48Before, path0]
theorem instruction48_closed_after : Closed instruction48After :=
  step_closed instruction48_step instruction48_closed_before
theorem instruction48_ranked_after : Ranked instruction48After :=
  step_ranked instruction48_step instruction48_closed_before instruction48_ranked_before
theorem instruction48_unique_after : Unique instruction48After :=
  step_unique instruction48_step instruction48_unique_before
theorem instruction48_compatible_after : Compatible instruction48After :=
  step_compatible instruction48_step instruction48_closed_before instruction48_unique_before instruction48_compatible_before
theorem instruction48_no_parent_cycle (name : Nat) : ¬ ParentPath instruction48After name name :=
  ranked_no_parent_cycle instruction48After instruction48_ranked_after name
def instruction49Before : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction49After : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction49Rank (n : Nat) : Nat :=
  match n with
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction49Source : Capability := ⟨2, 1, (some 1), 3, false, none⟩
theorem instruction49_path0 : ParentPath instruction49Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction49Before]) (by simp [instruction49Before]) rfl
theorem instruction49_borrow_guard : BorrowGuard instruction49Before instruction49Source 2 := by
  have path0 := instruction49_path0
  simp only [instruction49Before] at path0
  simp [BorrowGuard, Ancestor, instruction49Before, instruction49Source, path0]
theorem instruction49_result : instruction49After = loan instruction49Source 0 2 :: instruction49Before := by decide
theorem instruction49_step : Step instruction49Before instruction49After := by
  rw [instruction49_result]
  exact Step.borrowRead (by simp [instruction49Source, instruction49Before]) (by simp [Fresh, instruction49Before]) (by decide) instruction49_borrow_guard
theorem instruction49_closed_before : Closed instruction49Before := by
  simp [Closed, instruction49Before]
theorem instruction49_ranked_before : Ranked instruction49Before := by
  refine ⟨instruction49Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction49Before, instruction49Rank]
theorem instruction49_unique_before : Unique instruction49Before := by
  simp [Unique, instruction49Before]
theorem instruction49_compatible_before : Compatible instruction49Before := by
  have path0 := instruction49_path0
  simp only [instruction49Before] at path0
  simp [Compatible, Comparable, instruction49Before, path0]
theorem instruction49_closed_after : Closed instruction49After :=
  step_closed instruction49_step instruction49_closed_before
theorem instruction49_ranked_after : Ranked instruction49After :=
  step_ranked instruction49_step instruction49_closed_before instruction49_ranked_before
theorem instruction49_unique_after : Unique instruction49After :=
  step_unique instruction49_step instruction49_unique_before
theorem instruction49_compatible_after : Compatible instruction49After :=
  step_compatible instruction49_step instruction49_closed_before instruction49_unique_before instruction49_compatible_before
theorem instruction49_no_parent_cycle (name : Nat) : ¬ ParentPath instruction49After name name :=
  ranked_no_parent_cycle instruction49After instruction49_ranked_after name
theorem instruction49_source_suspended (write : Bool) : ¬ Access instruction49After instruction49Source write := by
  rw [instruction49_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction50Before : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction50After : List Capability := [⟨3, 1, (some 2), 2, false, none⟩, ⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction50Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction50Source : Capability := ⟨2, 1, (some 1), 3, false, none⟩
theorem instruction50_path0 : ParentPath instruction50Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction50Before]) (by simp [instruction50Before]) rfl
theorem instruction50_path1 : ParentPath instruction50Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction50Before]) (by simp [instruction50Before]) rfl
theorem instruction50_path2 : ParentPath instruction50Before 0 1 :=
  ParentPath.trans instruction50_path0 instruction50_path1
theorem instruction50_borrow_guard : BorrowGuard instruction50Before instruction50Source 2 := by
  have path0 := instruction50_path0
  simp only [instruction50Before] at path0
  have path1 := instruction50_path1
  simp only [instruction50Before] at path1
  have path2 := instruction50_path2
  simp only [instruction50Before] at path2
  simp [BorrowGuard, Ancestor, instruction50Before, instruction50Source, path0, path1, path2]
theorem instruction50_result : instruction50After = loan instruction50Source 3 2 :: instruction50Before := by decide
theorem instruction50_step : Step instruction50Before instruction50After := by
  rw [instruction50_result]
  exact Step.borrowRead (by simp [instruction50Source, instruction50Before]) (by simp [Fresh, instruction50Before]) (by decide) instruction50_borrow_guard
theorem instruction50_closed_before : Closed instruction50Before := by
  simp [Closed, instruction50Before]
theorem instruction50_ranked_before : Ranked instruction50Before := by
  refine ⟨instruction50Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction50Before, instruction50Rank]
theorem instruction50_unique_before : Unique instruction50Before := by
  simp [Unique, instruction50Before]
theorem instruction50_compatible_before : Compatible instruction50Before := by
  have path0 := instruction50_path0
  simp only [instruction50Before] at path0
  have path1 := instruction50_path1
  simp only [instruction50Before] at path1
  have path2 := instruction50_path2
  simp only [instruction50Before] at path2
  simp [Compatible, Comparable, instruction50Before, path0, path1, path2]
theorem instruction50_closed_after : Closed instruction50After :=
  step_closed instruction50_step instruction50_closed_before
theorem instruction50_ranked_after : Ranked instruction50After :=
  step_ranked instruction50_step instruction50_closed_before instruction50_ranked_before
theorem instruction50_unique_after : Unique instruction50After :=
  step_unique instruction50_step instruction50_unique_before
theorem instruction50_compatible_after : Compatible instruction50After :=
  step_compatible instruction50_step instruction50_closed_before instruction50_unique_before instruction50_compatible_before
theorem instruction50_no_parent_cycle (name : Nat) : ¬ ParentPath instruction50After name name :=
  ranked_no_parent_cycle instruction50After instruction50_ranked_after name
theorem instruction50_source_suspended (write : Bool) : ¬ Access instruction50After instruction50Source write := by
  rw [instruction50_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction51Before : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 2), 2, false, none⟩]
def instruction51After : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 2), 2, false, none⟩]
def instruction51Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | 3 => 2
  | _ => 0
def instruction51Source : Capability := ⟨0, 1, (some 2), 2, false, none⟩
theorem instruction51_path0 : ParentPath instruction51Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction51Before]) (by simp [instruction51Before]) rfl
theorem instruction51_path1 : ParentPath instruction51Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction51Before]) (by simp [instruction51Before]) rfl
theorem instruction51_path2 : ParentPath instruction51Before 3 2 :=
  ParentPath.edge (child := ⟨3, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction51Before]) (by simp [instruction51Before]) rfl
theorem instruction51_path3 : ParentPath instruction51Before 0 1 :=
  ParentPath.trans instruction51_path0 instruction51_path1
theorem instruction51_path4 : ParentPath instruction51Before 3 1 :=
  ParentPath.trans instruction51_path2 instruction51_path1
theorem instruction51_access : Access instruction51Before instruction51Source false := by
  simp [Access, Childless, instruction51Before, instruction51Source]
theorem instruction51_result : instruction51After = instruction51Before := by decide
theorem instruction51_step : Step instruction51Before instruction51After := by
  rw [instruction51_result]
  exact Step.access instruction51_access
theorem instruction51_closed_before : Closed instruction51Before := by
  simp [Closed, instruction51Before]
theorem instruction51_ranked_before : Ranked instruction51Before := by
  refine ⟨instruction51Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction51Before, instruction51Rank]
theorem instruction51_unique_before : Unique instruction51Before := by
  simp [Unique, instruction51Before]
theorem instruction51_compatible_before : Compatible instruction51Before := by
  have path0 := instruction51_path0
  simp only [instruction51Before] at path0
  have path1 := instruction51_path1
  simp only [instruction51Before] at path1
  have path2 := instruction51_path2
  simp only [instruction51Before] at path2
  have path3 := instruction51_path3
  simp only [instruction51Before] at path3
  have path4 := instruction51_path4
  simp only [instruction51Before] at path4
  simp [Compatible, Comparable, instruction51Before, path0, path1, path2, path3, path4]
theorem instruction51_closed_after : Closed instruction51After :=
  step_closed instruction51_step instruction51_closed_before
theorem instruction51_ranked_after : Ranked instruction51After :=
  step_ranked instruction51_step instruction51_closed_before instruction51_ranked_before
theorem instruction51_unique_after : Unique instruction51After :=
  step_unique instruction51_step instruction51_unique_before
theorem instruction51_compatible_after : Compatible instruction51After :=
  step_compatible instruction51_step instruction51_closed_before instruction51_unique_before instruction51_compatible_before
theorem instruction51_no_parent_cycle (name : Nat) : ¬ ParentPath instruction51After name name :=
  ranked_no_parent_cycle instruction51After instruction51_ranked_after name
def instruction52Before : List Capability := [⟨0, 2, (some 3), 2, false, none⟩, ⟨2, 2, none, 0, false, none⟩, ⟨3, 2, (some 2), 3, false, none⟩, ⟨4, 2, (some 3), 2, false, none⟩]
def instruction52After : List Capability := [⟨1, 2, (some 0), 2, false, none⟩, ⟨0, 2, (some 3), 2, false, none⟩, ⟨2, 2, none, 0, false, none⟩, ⟨3, 2, (some 2), 3, false, none⟩, ⟨4, 2, (some 3), 2, false, none⟩]
def instruction52Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 2 => 0
  | 3 => 1
  | 4 => 2
  | _ => 0
def instruction52Source : Capability := ⟨0, 2, (some 3), 2, false, none⟩
theorem instruction52_path0 : ParentPath instruction52Before 0 3 :=
  ParentPath.edge (child := ⟨0, 2, (some 3), 2, false, none⟩) (parent := ⟨3, 2, (some 2), 3, false, none⟩) (by simp [instruction52Before]) (by simp [instruction52Before]) rfl
theorem instruction52_path1 : ParentPath instruction52Before 3 2 :=
  ParentPath.edge (child := ⟨3, 2, (some 2), 3, false, none⟩) (parent := ⟨2, 2, none, 0, false, none⟩) (by simp [instruction52Before]) (by simp [instruction52Before]) rfl
theorem instruction52_path2 : ParentPath instruction52Before 4 3 :=
  ParentPath.edge (child := ⟨4, 2, (some 3), 2, false, none⟩) (parent := ⟨3, 2, (some 2), 3, false, none⟩) (by simp [instruction52Before]) (by simp [instruction52Before]) rfl
theorem instruction52_path3 : ParentPath instruction52Before 0 2 :=
  ParentPath.trans instruction52_path0 instruction52_path1
theorem instruction52_path4 : ParentPath instruction52Before 4 2 :=
  ParentPath.trans instruction52_path2 instruction52_path1
theorem instruction52_borrow_guard : BorrowGuard instruction52Before instruction52Source 2 := by
  have path0 := instruction52_path0
  simp only [instruction52Before] at path0
  have path1 := instruction52_path1
  simp only [instruction52Before] at path1
  have path2 := instruction52_path2
  simp only [instruction52Before] at path2
  have path3 := instruction52_path3
  simp only [instruction52Before] at path3
  have path4 := instruction52_path4
  simp only [instruction52Before] at path4
  simp [BorrowGuard, Ancestor, instruction52Before, instruction52Source, path0, path1, path2, path3, path4]
theorem instruction52_result : instruction52After = loan instruction52Source 1 2 :: instruction52Before := by decide
theorem instruction52_step : Step instruction52Before instruction52After := by
  rw [instruction52_result]
  exact Step.borrowRead (by simp [instruction52Source, instruction52Before]) (by simp [Fresh, instruction52Before]) (by decide) instruction52_borrow_guard
theorem instruction52_closed_before : Closed instruction52Before := by
  simp [Closed, instruction52Before]
theorem instruction52_ranked_before : Ranked instruction52Before := by
  refine ⟨instruction52Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction52Before, instruction52Rank]
theorem instruction52_unique_before : Unique instruction52Before := by
  simp [Unique, instruction52Before]
theorem instruction52_compatible_before : Compatible instruction52Before := by
  have path0 := instruction52_path0
  simp only [instruction52Before] at path0
  have path1 := instruction52_path1
  simp only [instruction52Before] at path1
  have path2 := instruction52_path2
  simp only [instruction52Before] at path2
  have path3 := instruction52_path3
  simp only [instruction52Before] at path3
  have path4 := instruction52_path4
  simp only [instruction52Before] at path4
  simp [Compatible, Comparable, instruction52Before, path0, path1, path2, path3, path4]
theorem instruction52_closed_after : Closed instruction52After :=
  step_closed instruction52_step instruction52_closed_before
theorem instruction52_ranked_after : Ranked instruction52After :=
  step_ranked instruction52_step instruction52_closed_before instruction52_ranked_before
theorem instruction52_unique_after : Unique instruction52After :=
  step_unique instruction52_step instruction52_unique_before
theorem instruction52_compatible_after : Compatible instruction52After :=
  step_compatible instruction52_step instruction52_closed_before instruction52_unique_before instruction52_compatible_before
theorem instruction52_no_parent_cycle (name : Nat) : ¬ ParentPath instruction52After name name :=
  ranked_no_parent_cycle instruction52After instruction52_ranked_after name
theorem instruction52_source_suspended (write : Bool) : ¬ Access instruction52After instruction52Source write := by
  rw [instruction52_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction53Before : List Capability := [⟨0, 2, (some 3), 2, false, none⟩, ⟨1, 2, (some 0), 2, false, none⟩, ⟨2, 2, none, 0, false, none⟩, ⟨3, 2, (some 2), 3, false, none⟩, ⟨4, 2, (some 3), 2, false, none⟩]
def instruction53After : List Capability := [⟨0, 2, (some 3), 2, false, none⟩, ⟨1, 2, (some 0), 2, false, none⟩, ⟨2, 2, none, 0, false, none⟩, ⟨3, 2, (some 2), 3, false, none⟩, ⟨4, 2, (some 3), 2, false, none⟩]
def instruction53Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 3
  | 2 => 0
  | 3 => 1
  | 4 => 2
  | _ => 0
def instruction53Source : Capability := ⟨1, 2, (some 0), 2, false, none⟩
theorem instruction53_path0 : ParentPath instruction53Before 0 3 :=
  ParentPath.edge (child := ⟨0, 2, (some 3), 2, false, none⟩) (parent := ⟨3, 2, (some 2), 3, false, none⟩) (by simp [instruction53Before]) (by simp [instruction53Before]) rfl
theorem instruction53_path1 : ParentPath instruction53Before 1 0 :=
  ParentPath.edge (child := ⟨1, 2, (some 0), 2, false, none⟩) (parent := ⟨0, 2, (some 3), 2, false, none⟩) (by simp [instruction53Before]) (by simp [instruction53Before]) rfl
theorem instruction53_path2 : ParentPath instruction53Before 3 2 :=
  ParentPath.edge (child := ⟨3, 2, (some 2), 3, false, none⟩) (parent := ⟨2, 2, none, 0, false, none⟩) (by simp [instruction53Before]) (by simp [instruction53Before]) rfl
theorem instruction53_path3 : ParentPath instruction53Before 4 3 :=
  ParentPath.edge (child := ⟨4, 2, (some 3), 2, false, none⟩) (parent := ⟨3, 2, (some 2), 3, false, none⟩) (by simp [instruction53Before]) (by simp [instruction53Before]) rfl
theorem instruction53_path4 : ParentPath instruction53Before 0 2 :=
  ParentPath.trans instruction53_path0 instruction53_path2
theorem instruction53_path5 : ParentPath instruction53Before 1 3 :=
  ParentPath.trans instruction53_path1 instruction53_path0
theorem instruction53_path6 : ParentPath instruction53Before 4 2 :=
  ParentPath.trans instruction53_path3 instruction53_path2
theorem instruction53_path7 : ParentPath instruction53Before 1 2 :=
  ParentPath.trans instruction53_path1 instruction53_path4
theorem instruction53_access : Access instruction53Before instruction53Source false := by
  simp [Access, Childless, instruction53Before, instruction53Source]
theorem instruction53_result : instruction53After = instruction53Before := by decide
theorem instruction53_step : Step instruction53Before instruction53After := by
  rw [instruction53_result]
  exact Step.access instruction53_access
theorem instruction53_closed_before : Closed instruction53Before := by
  simp [Closed, instruction53Before]
theorem instruction53_ranked_before : Ranked instruction53Before := by
  refine ⟨instruction53Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction53Before, instruction53Rank]
theorem instruction53_unique_before : Unique instruction53Before := by
  simp [Unique, instruction53Before]
theorem instruction53_compatible_before : Compatible instruction53Before := by
  have path0 := instruction53_path0
  simp only [instruction53Before] at path0
  have path1 := instruction53_path1
  simp only [instruction53Before] at path1
  have path2 := instruction53_path2
  simp only [instruction53Before] at path2
  have path3 := instruction53_path3
  simp only [instruction53Before] at path3
  have path4 := instruction53_path4
  simp only [instruction53Before] at path4
  have path5 := instruction53_path5
  simp only [instruction53Before] at path5
  have path6 := instruction53_path6
  simp only [instruction53Before] at path6
  have path7 := instruction53_path7
  simp only [instruction53Before] at path7
  simp [Compatible, Comparable, instruction53Before, path0, path1, path2, path3, path4, path5, path6, path7]
theorem instruction53_closed_after : Closed instruction53After :=
  step_closed instruction53_step instruction53_closed_before
theorem instruction53_ranked_after : Ranked instruction53After :=
  step_ranked instruction53_step instruction53_closed_before instruction53_ranked_before
theorem instruction53_unique_after : Unique instruction53After :=
  step_unique instruction53_step instruction53_unique_before
theorem instruction53_compatible_after : Compatible instruction53After :=
  step_compatible instruction53_step instruction53_closed_before instruction53_unique_before instruction53_compatible_before
theorem instruction53_no_parent_cycle (name : Nat) : ¬ ParentPath instruction53After name name :=
  ranked_no_parent_cycle instruction53After instruction53_ranked_after name
def instruction54Before : List Capability := [⟨0, 2, (some 3), 2, false, none⟩, ⟨1, 2, (some 0), 2, false, none⟩, ⟨2, 2, none, 0, false, none⟩, ⟨3, 2, (some 2), 3, false, none⟩, ⟨4, 2, (some 3), 2, false, none⟩]
def instruction54After : List Capability := [⟨0, 2, (some 3), 2, false, none⟩, ⟨2, 2, none, 0, false, none⟩, ⟨3, 2, (some 2), 3, false, none⟩, ⟨4, 2, (some 3), 2, false, none⟩]
def instruction54Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 3
  | 2 => 0
  | 3 => 1
  | 4 => 2
  | _ => 0
def instruction54Source : Capability := ⟨1, 2, (some 0), 2, false, none⟩
theorem instruction54_path0 : ParentPath instruction54Before 0 3 :=
  ParentPath.edge (child := ⟨0, 2, (some 3), 2, false, none⟩) (parent := ⟨3, 2, (some 2), 3, false, none⟩) (by simp [instruction54Before]) (by simp [instruction54Before]) rfl
theorem instruction54_path1 : ParentPath instruction54Before 1 0 :=
  ParentPath.edge (child := ⟨1, 2, (some 0), 2, false, none⟩) (parent := ⟨0, 2, (some 3), 2, false, none⟩) (by simp [instruction54Before]) (by simp [instruction54Before]) rfl
theorem instruction54_path2 : ParentPath instruction54Before 3 2 :=
  ParentPath.edge (child := ⟨3, 2, (some 2), 3, false, none⟩) (parent := ⟨2, 2, none, 0, false, none⟩) (by simp [instruction54Before]) (by simp [instruction54Before]) rfl
theorem instruction54_path3 : ParentPath instruction54Before 4 3 :=
  ParentPath.edge (child := ⟨4, 2, (some 3), 2, false, none⟩) (parent := ⟨3, 2, (some 2), 3, false, none⟩) (by simp [instruction54Before]) (by simp [instruction54Before]) rfl
theorem instruction54_path4 : ParentPath instruction54Before 0 2 :=
  ParentPath.trans instruction54_path0 instruction54_path2
theorem instruction54_path5 : ParentPath instruction54Before 1 3 :=
  ParentPath.trans instruction54_path1 instruction54_path0
theorem instruction54_path6 : ParentPath instruction54Before 4 2 :=
  ParentPath.trans instruction54_path3 instruction54_path2
theorem instruction54_path7 : ParentPath instruction54Before 1 2 :=
  ParentPath.trans instruction54_path1 instruction54_path4
theorem instruction54_result : instruction54After = erase instruction54Source.name instruction54Before := by decide
theorem instruction54_step : Step instruction54Before instruction54After := by
  rw [instruction54_result]
  exact Step.endLoan (c := instruction54Source) (by simp [instruction54Source, instruction54Before]) (by decide) (by decide) (by simp [Unreferenced, instruction54Before, instruction54Source])
theorem instruction54_closed_before : Closed instruction54Before := by
  simp [Closed, instruction54Before]
theorem instruction54_ranked_before : Ranked instruction54Before := by
  refine ⟨instruction54Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction54Before, instruction54Rank]
theorem instruction54_unique_before : Unique instruction54Before := by
  simp [Unique, instruction54Before]
theorem instruction54_compatible_before : Compatible instruction54Before := by
  have path0 := instruction54_path0
  simp only [instruction54Before] at path0
  have path1 := instruction54_path1
  simp only [instruction54Before] at path1
  have path2 := instruction54_path2
  simp only [instruction54Before] at path2
  have path3 := instruction54_path3
  simp only [instruction54Before] at path3
  have path4 := instruction54_path4
  simp only [instruction54Before] at path4
  have path5 := instruction54_path5
  simp only [instruction54Before] at path5
  have path6 := instruction54_path6
  simp only [instruction54Before] at path6
  have path7 := instruction54_path7
  simp only [instruction54Before] at path7
  simp [Compatible, Comparable, instruction54Before, path0, path1, path2, path3, path4, path5, path6, path7]
theorem instruction54_closed_after : Closed instruction54After :=
  step_closed instruction54_step instruction54_closed_before
theorem instruction54_ranked_after : Ranked instruction54After :=
  step_ranked instruction54_step instruction54_closed_before instruction54_ranked_before
theorem instruction54_unique_after : Unique instruction54After :=
  step_unique instruction54_step instruction54_unique_before
theorem instruction54_compatible_after : Compatible instruction54After :=
  step_compatible instruction54_step instruction54_closed_before instruction54_unique_before instruction54_compatible_before
theorem instruction54_no_parent_cycle (name : Nat) : ¬ ParentPath instruction54After name name :=
  ranked_no_parent_cycle instruction54After instruction54_ranked_after name
def instruction55Before : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 2), 2, false, none⟩]
def instruction55After : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 2), 2, false, none⟩]
def instruction55Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | 3 => 2
  | _ => 0
def instruction55Source : Capability := ⟨0, 1, (some 2), 2, false, none⟩
theorem instruction55_path0 : ParentPath instruction55Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction55Before]) (by simp [instruction55Before]) rfl
theorem instruction55_path1 : ParentPath instruction55Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction55Before]) (by simp [instruction55Before]) rfl
theorem instruction55_path2 : ParentPath instruction55Before 3 2 :=
  ParentPath.edge (child := ⟨3, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction55Before]) (by simp [instruction55Before]) rfl
theorem instruction55_path3 : ParentPath instruction55Before 0 1 :=
  ParentPath.trans instruction55_path0 instruction55_path1
theorem instruction55_path4 : ParentPath instruction55Before 3 1 :=
  ParentPath.trans instruction55_path2 instruction55_path1
theorem instruction55_access : Access instruction55Before instruction55Source false := by
  simp [Access, Childless, instruction55Before, instruction55Source]
theorem instruction55_result : instruction55After = instruction55Before := by decide
theorem instruction55_step : Step instruction55Before instruction55After := by
  rw [instruction55_result]
  exact Step.access instruction55_access
theorem instruction55_closed_before : Closed instruction55Before := by
  simp [Closed, instruction55Before]
theorem instruction55_ranked_before : Ranked instruction55Before := by
  refine ⟨instruction55Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction55Before, instruction55Rank]
theorem instruction55_unique_before : Unique instruction55Before := by
  simp [Unique, instruction55Before]
theorem instruction55_compatible_before : Compatible instruction55Before := by
  have path0 := instruction55_path0
  simp only [instruction55Before] at path0
  have path1 := instruction55_path1
  simp only [instruction55Before] at path1
  have path2 := instruction55_path2
  simp only [instruction55Before] at path2
  have path3 := instruction55_path3
  simp only [instruction55Before] at path3
  have path4 := instruction55_path4
  simp only [instruction55Before] at path4
  simp [Compatible, Comparable, instruction55Before, path0, path1, path2, path3, path4]
theorem instruction55_closed_after : Closed instruction55After :=
  step_closed instruction55_step instruction55_closed_before
theorem instruction55_ranked_after : Ranked instruction55After :=
  step_ranked instruction55_step instruction55_closed_before instruction55_ranked_before
theorem instruction55_unique_after : Unique instruction55After :=
  step_unique instruction55_step instruction55_unique_before
theorem instruction55_compatible_after : Compatible instruction55After :=
  step_compatible instruction55_step instruction55_closed_before instruction55_unique_before instruction55_compatible_before
theorem instruction55_no_parent_cycle (name : Nat) : ¬ ParentPath instruction55After name name :=
  ranked_no_parent_cycle instruction55After instruction55_ranked_after name
def instruction56Before : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 2), 2, false, none⟩]
def instruction56After : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 2), 2, false, none⟩]
def instruction56Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | 3 => 2
  | _ => 0
def instruction56Source : Capability := ⟨0, 1, (some 2), 2, false, none⟩
theorem instruction56_path0 : ParentPath instruction56Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction56Before]) (by simp [instruction56Before]) rfl
theorem instruction56_path1 : ParentPath instruction56Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction56Before]) (by simp [instruction56Before]) rfl
theorem instruction56_path2 : ParentPath instruction56Before 3 2 :=
  ParentPath.edge (child := ⟨3, 1, (some 2), 2, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction56Before]) (by simp [instruction56Before]) rfl
theorem instruction56_path3 : ParentPath instruction56Before 0 1 :=
  ParentPath.trans instruction56_path0 instruction56_path1
theorem instruction56_path4 : ParentPath instruction56Before 3 1 :=
  ParentPath.trans instruction56_path2 instruction56_path1
theorem instruction56_result : instruction56After = erase instruction56Source.name instruction56Before := by decide
theorem instruction56_step : Step instruction56Before instruction56After := by
  rw [instruction56_result]
  exact Step.endLoan (c := instruction56Source) (by simp [instruction56Source, instruction56Before]) (by decide) (by decide) (by simp [Unreferenced, instruction56Before, instruction56Source])
theorem instruction56_closed_before : Closed instruction56Before := by
  simp [Closed, instruction56Before]
theorem instruction56_ranked_before : Ranked instruction56Before := by
  refine ⟨instruction56Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction56Before, instruction56Rank]
theorem instruction56_unique_before : Unique instruction56Before := by
  simp [Unique, instruction56Before]
theorem instruction56_compatible_before : Compatible instruction56Before := by
  have path0 := instruction56_path0
  simp only [instruction56Before] at path0
  have path1 := instruction56_path1
  simp only [instruction56Before] at path1
  have path2 := instruction56_path2
  simp only [instruction56Before] at path2
  have path3 := instruction56_path3
  simp only [instruction56Before] at path3
  have path4 := instruction56_path4
  simp only [instruction56Before] at path4
  simp [Compatible, Comparable, instruction56Before, path0, path1, path2, path3, path4]
theorem instruction56_closed_after : Closed instruction56After :=
  step_closed instruction56_step instruction56_closed_before
theorem instruction56_ranked_after : Ranked instruction56After :=
  step_ranked instruction56_step instruction56_closed_before instruction56_ranked_before
theorem instruction56_unique_after : Unique instruction56After :=
  step_unique instruction56_step instruction56_unique_before
theorem instruction56_compatible_after : Compatible instruction56After :=
  step_compatible instruction56_step instruction56_closed_before instruction56_unique_before instruction56_compatible_before
theorem instruction56_no_parent_cycle (name : Nat) : ¬ ParentPath instruction56After name name :=
  ranked_no_parent_cycle instruction56After instruction56_ranked_after name
def instruction57Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction57After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction57Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction57Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction57_path0 : ParentPath instruction57Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction57Before]) (by simp [instruction57Before]) rfl
theorem instruction57_path1 : ParentPath instruction57Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction57Before]) (by simp [instruction57Before]) rfl
theorem instruction57_path2 : ParentPath instruction57Before 2 0 :=
  ParentPath.trans instruction57_path1 instruction57_path0
theorem instruction57_access : Access instruction57Before instruction57Source false := by
  simp [Access, Childless, instruction57Before, instruction57Source]
theorem instruction57_result : instruction57After = instruction57Before := by decide
theorem instruction57_step : Step instruction57Before instruction57After := by
  rw [instruction57_result]
  exact Step.access instruction57_access
theorem instruction57_closed_before : Closed instruction57Before := by
  simp [Closed, instruction57Before]
theorem instruction57_ranked_before : Ranked instruction57Before := by
  refine ⟨instruction57Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction57Before, instruction57Rank]
theorem instruction57_unique_before : Unique instruction57Before := by
  simp [Unique, instruction57Before]
theorem instruction57_compatible_before : Compatible instruction57Before := by
  have path0 := instruction57_path0
  simp only [instruction57Before] at path0
  have path1 := instruction57_path1
  simp only [instruction57Before] at path1
  have path2 := instruction57_path2
  simp only [instruction57Before] at path2
  simp [Compatible, Comparable, instruction57Before, path0, path1, path2]
theorem instruction57_closed_after : Closed instruction57After :=
  step_closed instruction57_step instruction57_closed_before
theorem instruction57_ranked_after : Ranked instruction57After :=
  step_ranked instruction57_step instruction57_closed_before instruction57_ranked_before
theorem instruction57_unique_after : Unique instruction57After :=
  step_unique instruction57_step instruction57_unique_before
theorem instruction57_compatible_after : Compatible instruction57After :=
  step_compatible instruction57_step instruction57_closed_before instruction57_unique_before instruction57_compatible_before
theorem instruction57_no_parent_cycle (name : Nat) : ¬ ParentPath instruction57After name name :=
  ranked_no_parent_cycle instruction57After instruction57_ranked_after name
def instruction58Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction58After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction58Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction58Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction58_path0 : ParentPath instruction58Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction58Before]) (by simp [instruction58Before]) rfl
theorem instruction58_path1 : ParentPath instruction58Before 2 1 :=
  ParentPath.edge (child := ⟨2, 0, (some 1), 2, false, none⟩) (parent := ⟨1, 0, (some 0), 3, false, none⟩) (by simp [instruction58Before]) (by simp [instruction58Before]) rfl
theorem instruction58_path2 : ParentPath instruction58Before 2 0 :=
  ParentPath.trans instruction58_path1 instruction58_path0
theorem instruction58_result : instruction58After = erase instruction58Source.name instruction58Before := by decide
theorem instruction58_step : Step instruction58Before instruction58After := by
  rw [instruction58_result]
  exact Step.endLoan (c := instruction58Source) (by simp [instruction58Source, instruction58Before]) (by decide) (by decide) (by simp [Unreferenced, instruction58Before, instruction58Source])
theorem instruction58_closed_before : Closed instruction58Before := by
  simp [Closed, instruction58Before]
theorem instruction58_ranked_before : Ranked instruction58Before := by
  refine ⟨instruction58Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction58Before, instruction58Rank]
theorem instruction58_unique_before : Unique instruction58Before := by
  simp [Unique, instruction58Before]
theorem instruction58_compatible_before : Compatible instruction58Before := by
  have path0 := instruction58_path0
  simp only [instruction58Before] at path0
  have path1 := instruction58_path1
  simp only [instruction58Before] at path1
  have path2 := instruction58_path2
  simp only [instruction58Before] at path2
  simp [Compatible, Comparable, instruction58Before, path0, path1, path2]
theorem instruction58_closed_after : Closed instruction58After :=
  step_closed instruction58_step instruction58_closed_before
theorem instruction58_ranked_after : Ranked instruction58After :=
  step_ranked instruction58_step instruction58_closed_before instruction58_ranked_before
theorem instruction58_unique_after : Unique instruction58After :=
  step_unique instruction58_step instruction58_unique_before
theorem instruction58_compatible_after : Compatible instruction58After :=
  step_compatible instruction58_step instruction58_closed_before instruction58_unique_before instruction58_compatible_before
theorem instruction58_no_parent_cycle (name : Nat) : ¬ ParentPath instruction58After name name :=
  ranked_no_parent_cycle instruction58After instruction58_ranked_after name
def instruction59Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction59After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction59Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction59Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction59_path0 : ParentPath instruction59Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction59Before]) (by simp [instruction59Before]) rfl
theorem instruction59_access : Access instruction59Before instruction59Source true := by
  simp [Access, Childless, instruction59Before, instruction59Source]
theorem instruction59_result : instruction59After = instruction59Before := by decide
theorem instruction59_step : Step instruction59Before instruction59After := by
  rw [instruction59_result]
  exact Step.access instruction59_access
theorem instruction59_closed_before : Closed instruction59Before := by
  simp [Closed, instruction59Before]
theorem instruction59_ranked_before : Ranked instruction59Before := by
  refine ⟨instruction59Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction59Before, instruction59Rank]
theorem instruction59_unique_before : Unique instruction59Before := by
  simp [Unique, instruction59Before]
theorem instruction59_compatible_before : Compatible instruction59Before := by
  have path0 := instruction59_path0
  simp only [instruction59Before] at path0
  simp [Compatible, Comparable, instruction59Before, path0]
theorem instruction59_closed_after : Closed instruction59After :=
  step_closed instruction59_step instruction59_closed_before
theorem instruction59_ranked_after : Ranked instruction59After :=
  step_ranked instruction59_step instruction59_closed_before instruction59_ranked_before
theorem instruction59_unique_after : Unique instruction59After :=
  step_unique instruction59_step instruction59_unique_before
theorem instruction59_compatible_after : Compatible instruction59After :=
  step_compatible instruction59_step instruction59_closed_before instruction59_unique_before instruction59_compatible_before
theorem instruction59_no_parent_cycle (name : Nat) : ¬ ParentPath instruction59After name name :=
  ranked_no_parent_cycle instruction59After instruction59_ranked_after name
def instruction60Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction60After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction60Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction60Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction60_path0 : ParentPath instruction60Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction60Before]) (by simp [instruction60Before]) rfl
theorem instruction60_result : instruction60After = erase instruction60Source.name instruction60Before := by decide
theorem instruction60_step : Step instruction60Before instruction60After := by
  rw [instruction60_result]
  exact Step.endLoan (c := instruction60Source) (by simp [instruction60Source, instruction60Before]) (by decide) (by decide) (by simp [Unreferenced, instruction60Before, instruction60Source])
theorem instruction60_closed_before : Closed instruction60Before := by
  simp [Closed, instruction60Before]
theorem instruction60_ranked_before : Ranked instruction60Before := by
  refine ⟨instruction60Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction60Before, instruction60Rank]
theorem instruction60_unique_before : Unique instruction60Before := by
  simp [Unique, instruction60Before]
theorem instruction60_compatible_before : Compatible instruction60Before := by
  have path0 := instruction60_path0
  simp only [instruction60Before] at path0
  simp [Compatible, Comparable, instruction60Before, path0]
theorem instruction60_closed_after : Closed instruction60After :=
  step_closed instruction60_step instruction60_closed_before
theorem instruction60_ranked_after : Ranked instruction60After :=
  step_ranked instruction60_step instruction60_closed_before instruction60_ranked_before
theorem instruction60_unique_after : Unique instruction60After :=
  step_unique instruction60_step instruction60_unique_before
theorem instruction60_compatible_after : Compatible instruction60After :=
  step_compatible instruction60_step instruction60_closed_before instruction60_unique_before instruction60_compatible_before
theorem instruction60_no_parent_cycle (name : Nat) : ¬ ParentPath instruction60After name name :=
  ranked_no_parent_cycle instruction60After instruction60_ranked_after name
def instruction61Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction61After : List Capability := []
def instruction61Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction61Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction61_result : instruction61After = erase instruction61Source.name instruction61Before := by decide
theorem instruction61_step : Step instruction61Before instruction61After := by
  rw [instruction61_result]
  exact Step.dropOwner (c := instruction61Source) (by simp [instruction61Source, instruction61Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction61Before, instruction61Source])
theorem instruction61_closed_before : Closed instruction61Before := by
  simp [Closed, instruction61Before]
theorem instruction61_ranked_before : Ranked instruction61Before := by
  refine ⟨instruction61Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction61Before, instruction61Rank]
theorem instruction61_unique_before : Unique instruction61Before := by
  simp [Unique, instruction61Before]
theorem instruction61_compatible_before : Compatible instruction61Before := by
  simp [Compatible, Comparable, instruction61Before]
theorem instruction61_closed_after : Closed instruction61After :=
  step_closed instruction61_step instruction61_closed_before
theorem instruction61_ranked_after : Ranked instruction61After :=
  step_ranked instruction61_step instruction61_closed_before instruction61_ranked_before
theorem instruction61_unique_after : Unique instruction61After :=
  step_unique instruction61_step instruction61_unique_before
theorem instruction61_compatible_after : Compatible instruction61After :=
  step_compatible instruction61_step instruction61_closed_before instruction61_unique_before instruction61_compatible_before
theorem instruction61_no_parent_cycle (name : Nat) : ¬ ParentPath instruction61After name name :=
  ranked_no_parent_cycle instruction61After instruction61_ranked_after name
def instruction62Before : List Capability := []
def instruction62After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction62Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction62_result : instruction62After = owner 0 0 :: instruction62Before := by decide
theorem instruction62_step : Step instruction62Before instruction62After := by
  rw [instruction62_result]
  exact Step.allocate (by simp [Fresh, instruction62Before]) (by decide)
theorem instruction62_closed_before : Closed instruction62Before := by
  simp [Closed, instruction62Before]
theorem instruction62_ranked_before : Ranked instruction62Before := by
  refine ⟨instruction62Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction62Before, instruction62Rank]
theorem instruction62_unique_before : Unique instruction62Before := by
  simp [Unique, instruction62Before]
theorem instruction62_compatible_before : Compatible instruction62Before := by
  simp [Compatible, Comparable, instruction62Before]
theorem instruction62_closed_after : Closed instruction62After :=
  step_closed instruction62_step instruction62_closed_before
theorem instruction62_ranked_after : Ranked instruction62After :=
  step_ranked instruction62_step instruction62_closed_before instruction62_ranked_before
theorem instruction62_unique_after : Unique instruction62After :=
  step_unique instruction62_step instruction62_unique_before
theorem instruction62_compatible_after : Compatible instruction62After :=
  step_compatible instruction62_step instruction62_closed_before instruction62_unique_before instruction62_compatible_before
theorem instruction62_no_parent_cycle (name : Nat) : ¬ ParentPath instruction62After name name :=
  ranked_no_parent_cycle instruction62After instruction62_ranked_after name
def instruction63Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction63After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction63Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction63Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction63_borrow_guard : BorrowGuard instruction63Before instruction63Source 3 := by
  simp [BorrowGuard, Ancestor, instruction63Before, instruction63Source]
theorem instruction63_result : instruction63After = loan instruction63Source 1 3 :: instruction63Before := by decide
theorem instruction63_step : Step instruction63Before instruction63After := by
  rw [instruction63_result]
  exact Step.borrowMut (by simp [instruction63Source, instruction63Before]) (by simp [Fresh, instruction63Before]) (by decide) instruction63_borrow_guard
theorem instruction63_closed_before : Closed instruction63Before := by
  simp [Closed, instruction63Before]
theorem instruction63_ranked_before : Ranked instruction63Before := by
  refine ⟨instruction63Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction63Before, instruction63Rank]
theorem instruction63_unique_before : Unique instruction63Before := by
  simp [Unique, instruction63Before]
theorem instruction63_compatible_before : Compatible instruction63Before := by
  simp [Compatible, Comparable, instruction63Before]
theorem instruction63_closed_after : Closed instruction63After :=
  step_closed instruction63_step instruction63_closed_before
theorem instruction63_ranked_after : Ranked instruction63After :=
  step_ranked instruction63_step instruction63_closed_before instruction63_ranked_before
theorem instruction63_unique_after : Unique instruction63After :=
  step_unique instruction63_step instruction63_unique_before
theorem instruction63_compatible_after : Compatible instruction63After :=
  step_compatible instruction63_step instruction63_closed_before instruction63_unique_before instruction63_compatible_before
theorem instruction63_no_parent_cycle (name : Nat) : ¬ ParentPath instruction63After name name :=
  ranked_no_parent_cycle instruction63After instruction63_ranked_after name
theorem instruction63_source_suspended (write : Bool) : ¬ Access instruction63After instruction63Source write := by
  rw [instruction63_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction64Before : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction64After : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction64Rank (n : Nat) : Nat :=
  match n with
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction64Source : Capability := ⟨2, 1, (some 1), 3, false, none⟩
theorem instruction64_path0 : ParentPath instruction64Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction64Before]) (by simp [instruction64Before]) rfl
theorem instruction64_borrow_guard : BorrowGuard instruction64Before instruction64Source 3 := by
  have path0 := instruction64_path0
  simp only [instruction64Before] at path0
  simp [BorrowGuard, Ancestor, instruction64Before, instruction64Source, path0]
theorem instruction64_result : instruction64After = loan instruction64Source 0 3 :: instruction64Before := by decide
theorem instruction64_step : Step instruction64Before instruction64After := by
  rw [instruction64_result]
  exact Step.borrowMut (by simp [instruction64Source, instruction64Before]) (by simp [Fresh, instruction64Before]) (by decide) instruction64_borrow_guard
theorem instruction64_closed_before : Closed instruction64Before := by
  simp [Closed, instruction64Before]
theorem instruction64_ranked_before : Ranked instruction64Before := by
  refine ⟨instruction64Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction64Before, instruction64Rank]
theorem instruction64_unique_before : Unique instruction64Before := by
  simp [Unique, instruction64Before]
theorem instruction64_compatible_before : Compatible instruction64Before := by
  have path0 := instruction64_path0
  simp only [instruction64Before] at path0
  simp [Compatible, Comparable, instruction64Before, path0]
theorem instruction64_closed_after : Closed instruction64After :=
  step_closed instruction64_step instruction64_closed_before
theorem instruction64_ranked_after : Ranked instruction64After :=
  step_ranked instruction64_step instruction64_closed_before instruction64_ranked_before
theorem instruction64_unique_after : Unique instruction64After :=
  step_unique instruction64_step instruction64_unique_before
theorem instruction64_compatible_after : Compatible instruction64After :=
  step_compatible instruction64_step instruction64_closed_before instruction64_unique_before instruction64_compatible_before
theorem instruction64_no_parent_cycle (name : Nat) : ¬ ParentPath instruction64After name name :=
  ranked_no_parent_cycle instruction64After instruction64_ranked_after name
theorem instruction64_source_suspended (write : Bool) : ¬ Access instruction64After instruction64Source write := by
  rw [instruction64_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction65Before : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction65After : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction65Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction65Source : Capability := ⟨0, 1, (some 2), 3, false, none⟩
theorem instruction65_path0 : ParentPath instruction65Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 3, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction65Before]) (by simp [instruction65Before]) rfl
theorem instruction65_path1 : ParentPath instruction65Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction65Before]) (by simp [instruction65Before]) rfl
theorem instruction65_path2 : ParentPath instruction65Before 0 1 :=
  ParentPath.trans instruction65_path0 instruction65_path1
theorem instruction65_access : Access instruction65Before instruction65Source true := by
  simp [Access, Childless, instruction65Before, instruction65Source]
theorem instruction65_result : instruction65After = instruction65Before := by decide
theorem instruction65_step : Step instruction65Before instruction65After := by
  rw [instruction65_result]
  exact Step.access instruction65_access
theorem instruction65_closed_before : Closed instruction65Before := by
  simp [Closed, instruction65Before]
theorem instruction65_ranked_before : Ranked instruction65Before := by
  refine ⟨instruction65Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction65Before, instruction65Rank]
theorem instruction65_unique_before : Unique instruction65Before := by
  simp [Unique, instruction65Before]
theorem instruction65_compatible_before : Compatible instruction65Before := by
  have path0 := instruction65_path0
  simp only [instruction65Before] at path0
  have path1 := instruction65_path1
  simp only [instruction65Before] at path1
  have path2 := instruction65_path2
  simp only [instruction65Before] at path2
  simp [Compatible, Comparable, instruction65Before, path0, path1, path2]
theorem instruction65_closed_after : Closed instruction65After :=
  step_closed instruction65_step instruction65_closed_before
theorem instruction65_ranked_after : Ranked instruction65After :=
  step_ranked instruction65_step instruction65_closed_before instruction65_ranked_before
theorem instruction65_unique_after : Unique instruction65After :=
  step_unique instruction65_step instruction65_unique_before
theorem instruction65_compatible_after : Compatible instruction65After :=
  step_compatible instruction65_step instruction65_closed_before instruction65_unique_before instruction65_compatible_before
theorem instruction65_no_parent_cycle (name : Nat) : ¬ ParentPath instruction65After name name :=
  ranked_no_parent_cycle instruction65After instruction65_ranked_after name
def instruction66Before : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction66After : List Capability := [⟨3, 1, (some 0), 2, false, none⟩, ⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction66Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction66Source : Capability := ⟨0, 1, (some 2), 3, false, none⟩
theorem instruction66_path0 : ParentPath instruction66Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 3, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction66Before]) (by simp [instruction66Before]) rfl
theorem instruction66_path1 : ParentPath instruction66Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction66Before]) (by simp [instruction66Before]) rfl
theorem instruction66_path2 : ParentPath instruction66Before 0 1 :=
  ParentPath.trans instruction66_path0 instruction66_path1
theorem instruction66_borrow_guard : BorrowGuard instruction66Before instruction66Source 2 := by
  have path0 := instruction66_path0
  simp only [instruction66Before] at path0
  have path1 := instruction66_path1
  simp only [instruction66Before] at path1
  have path2 := instruction66_path2
  simp only [instruction66Before] at path2
  simp [BorrowGuard, Ancestor, instruction66Before, instruction66Source, path0, path1, path2]
theorem instruction66_result : instruction66After = loan instruction66Source 3 2 :: instruction66Before := by decide
theorem instruction66_step : Step instruction66Before instruction66After := by
  rw [instruction66_result]
  exact Step.borrowRead (by simp [instruction66Source, instruction66Before]) (by simp [Fresh, instruction66Before]) (by decide) instruction66_borrow_guard
theorem instruction66_closed_before : Closed instruction66Before := by
  simp [Closed, instruction66Before]
theorem instruction66_ranked_before : Ranked instruction66Before := by
  refine ⟨instruction66Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction66Before, instruction66Rank]
theorem instruction66_unique_before : Unique instruction66Before := by
  simp [Unique, instruction66Before]
theorem instruction66_compatible_before : Compatible instruction66Before := by
  have path0 := instruction66_path0
  simp only [instruction66Before] at path0
  have path1 := instruction66_path1
  simp only [instruction66Before] at path1
  have path2 := instruction66_path2
  simp only [instruction66Before] at path2
  simp [Compatible, Comparable, instruction66Before, path0, path1, path2]
theorem instruction66_closed_after : Closed instruction66After :=
  step_closed instruction66_step instruction66_closed_before
theorem instruction66_ranked_after : Ranked instruction66After :=
  step_ranked instruction66_step instruction66_closed_before instruction66_ranked_before
theorem instruction66_unique_after : Unique instruction66After :=
  step_unique instruction66_step instruction66_unique_before
theorem instruction66_compatible_after : Compatible instruction66After :=
  step_compatible instruction66_step instruction66_closed_before instruction66_unique_before instruction66_compatible_before
theorem instruction66_no_parent_cycle (name : Nat) : ¬ ParentPath instruction66After name name :=
  ranked_no_parent_cycle instruction66After instruction66_ranked_after name
theorem instruction66_source_suspended (write : Bool) : ¬ Access instruction66After instruction66Source write := by
  rw [instruction66_result]
  exact borrow_suspends_source _ _ _ _ write
def instruction67Before : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 0), 2, false, none⟩]
def instruction67After : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 0), 2, false, none⟩]
def instruction67Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | 3 => 3
  | _ => 0
def instruction67Source : Capability := ⟨3, 1, (some 0), 2, false, none⟩
theorem instruction67_path0 : ParentPath instruction67Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 3, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction67Before]) (by simp [instruction67Before]) rfl
theorem instruction67_path1 : ParentPath instruction67Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction67Before]) (by simp [instruction67Before]) rfl
theorem instruction67_path2 : ParentPath instruction67Before 3 0 :=
  ParentPath.edge (child := ⟨3, 1, (some 0), 2, false, none⟩) (parent := ⟨0, 1, (some 2), 3, false, none⟩) (by simp [instruction67Before]) (by simp [instruction67Before]) rfl
theorem instruction67_path3 : ParentPath instruction67Before 0 1 :=
  ParentPath.trans instruction67_path0 instruction67_path1
theorem instruction67_path4 : ParentPath instruction67Before 3 2 :=
  ParentPath.trans instruction67_path2 instruction67_path0
theorem instruction67_path5 : ParentPath instruction67Before 3 1 :=
  ParentPath.trans instruction67_path2 instruction67_path3
theorem instruction67_access : Access instruction67Before instruction67Source false := by
  simp [Access, Childless, instruction67Before, instruction67Source]
theorem instruction67_result : instruction67After = instruction67Before := by decide
theorem instruction67_step : Step instruction67Before instruction67After := by
  rw [instruction67_result]
  exact Step.access instruction67_access
theorem instruction67_closed_before : Closed instruction67Before := by
  simp [Closed, instruction67Before]
theorem instruction67_ranked_before : Ranked instruction67Before := by
  refine ⟨instruction67Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction67Before, instruction67Rank]
theorem instruction67_unique_before : Unique instruction67Before := by
  simp [Unique, instruction67Before]
theorem instruction67_compatible_before : Compatible instruction67Before := by
  have path0 := instruction67_path0
  simp only [instruction67Before] at path0
  have path1 := instruction67_path1
  simp only [instruction67Before] at path1
  have path2 := instruction67_path2
  simp only [instruction67Before] at path2
  have path3 := instruction67_path3
  simp only [instruction67Before] at path3
  have path4 := instruction67_path4
  simp only [instruction67Before] at path4
  have path5 := instruction67_path5
  simp only [instruction67Before] at path5
  simp [Compatible, Comparable, instruction67Before, path0, path1, path2, path3, path4, path5]
theorem instruction67_closed_after : Closed instruction67After :=
  step_closed instruction67_step instruction67_closed_before
theorem instruction67_ranked_after : Ranked instruction67After :=
  step_ranked instruction67_step instruction67_closed_before instruction67_ranked_before
theorem instruction67_unique_after : Unique instruction67After :=
  step_unique instruction67_step instruction67_unique_before
theorem instruction67_compatible_after : Compatible instruction67After :=
  step_compatible instruction67_step instruction67_closed_before instruction67_unique_before instruction67_compatible_before
theorem instruction67_no_parent_cycle (name : Nat) : ¬ ParentPath instruction67After name name :=
  ranked_no_parent_cycle instruction67After instruction67_ranked_after name
def instruction68Before : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩, ⟨3, 1, (some 0), 2, false, none⟩]
def instruction68After : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction68Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | 3 => 3
  | _ => 0
def instruction68Source : Capability := ⟨3, 1, (some 0), 2, false, none⟩
theorem instruction68_path0 : ParentPath instruction68Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 3, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction68Before]) (by simp [instruction68Before]) rfl
theorem instruction68_path1 : ParentPath instruction68Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction68Before]) (by simp [instruction68Before]) rfl
theorem instruction68_path2 : ParentPath instruction68Before 3 0 :=
  ParentPath.edge (child := ⟨3, 1, (some 0), 2, false, none⟩) (parent := ⟨0, 1, (some 2), 3, false, none⟩) (by simp [instruction68Before]) (by simp [instruction68Before]) rfl
theorem instruction68_path3 : ParentPath instruction68Before 0 1 :=
  ParentPath.trans instruction68_path0 instruction68_path1
theorem instruction68_path4 : ParentPath instruction68Before 3 2 :=
  ParentPath.trans instruction68_path2 instruction68_path0
theorem instruction68_path5 : ParentPath instruction68Before 3 1 :=
  ParentPath.trans instruction68_path2 instruction68_path3
theorem instruction68_result : instruction68After = erase instruction68Source.name instruction68Before := by decide
theorem instruction68_step : Step instruction68Before instruction68After := by
  rw [instruction68_result]
  exact Step.endLoan (c := instruction68Source) (by simp [instruction68Source, instruction68Before]) (by decide) (by decide) (by simp [Unreferenced, instruction68Before, instruction68Source])
theorem instruction68_closed_before : Closed instruction68Before := by
  simp [Closed, instruction68Before]
theorem instruction68_ranked_before : Ranked instruction68Before := by
  refine ⟨instruction68Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction68Before, instruction68Rank]
theorem instruction68_unique_before : Unique instruction68Before := by
  simp [Unique, instruction68Before]
theorem instruction68_compatible_before : Compatible instruction68Before := by
  have path0 := instruction68_path0
  simp only [instruction68Before] at path0
  have path1 := instruction68_path1
  simp only [instruction68Before] at path1
  have path2 := instruction68_path2
  simp only [instruction68Before] at path2
  have path3 := instruction68_path3
  simp only [instruction68Before] at path3
  have path4 := instruction68_path4
  simp only [instruction68Before] at path4
  have path5 := instruction68_path5
  simp only [instruction68Before] at path5
  simp [Compatible, Comparable, instruction68Before, path0, path1, path2, path3, path4, path5]
theorem instruction68_closed_after : Closed instruction68After :=
  step_closed instruction68_step instruction68_closed_before
theorem instruction68_ranked_after : Ranked instruction68After :=
  step_ranked instruction68_step instruction68_closed_before instruction68_ranked_before
theorem instruction68_unique_after : Unique instruction68After :=
  step_unique instruction68_step instruction68_unique_before
theorem instruction68_compatible_after : Compatible instruction68After :=
  step_compatible instruction68_step instruction68_closed_before instruction68_unique_before instruction68_compatible_before
theorem instruction68_no_parent_cycle (name : Nat) : ¬ ParentPath instruction68After name name :=
  ranked_no_parent_cycle instruction68After instruction68_ranked_after name
def instruction69Before : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction69After : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction69Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction69Source : Capability := ⟨0, 1, (some 2), 3, false, none⟩
theorem instruction69_path0 : ParentPath instruction69Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 3, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction69Before]) (by simp [instruction69Before]) rfl
theorem instruction69_path1 : ParentPath instruction69Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction69Before]) (by simp [instruction69Before]) rfl
theorem instruction69_path2 : ParentPath instruction69Before 0 1 :=
  ParentPath.trans instruction69_path0 instruction69_path1
theorem instruction69_access : Access instruction69Before instruction69Source true := by
  simp [Access, Childless, instruction69Before, instruction69Source]
theorem instruction69_result : instruction69After = instruction69Before := by decide
theorem instruction69_step : Step instruction69Before instruction69After := by
  rw [instruction69_result]
  exact Step.access instruction69_access
theorem instruction69_closed_before : Closed instruction69Before := by
  simp [Closed, instruction69Before]
theorem instruction69_ranked_before : Ranked instruction69Before := by
  refine ⟨instruction69Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction69Before, instruction69Rank]
theorem instruction69_unique_before : Unique instruction69Before := by
  simp [Unique, instruction69Before]
theorem instruction69_compatible_before : Compatible instruction69Before := by
  have path0 := instruction69_path0
  simp only [instruction69Before] at path0
  have path1 := instruction69_path1
  simp only [instruction69Before] at path1
  have path2 := instruction69_path2
  simp only [instruction69Before] at path2
  simp [Compatible, Comparable, instruction69Before, path0, path1, path2]
theorem instruction69_closed_after : Closed instruction69After :=
  step_closed instruction69_step instruction69_closed_before
theorem instruction69_ranked_after : Ranked instruction69After :=
  step_ranked instruction69_step instruction69_closed_before instruction69_ranked_before
theorem instruction69_unique_after : Unique instruction69After :=
  step_unique instruction69_step instruction69_unique_before
theorem instruction69_compatible_after : Compatible instruction69After :=
  step_compatible instruction69_step instruction69_closed_before instruction69_unique_before instruction69_compatible_before
theorem instruction69_no_parent_cycle (name : Nat) : ¬ ParentPath instruction69After name name :=
  ranked_no_parent_cycle instruction69After instruction69_ranked_after name
def instruction70Before : List Capability := [⟨0, 1, (some 2), 3, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction70After : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction70Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction70Source : Capability := ⟨0, 1, (some 2), 3, false, none⟩
theorem instruction70_path0 : ParentPath instruction70Before 0 2 :=
  ParentPath.edge (child := ⟨0, 1, (some 2), 3, false, none⟩) (parent := ⟨2, 1, (some 1), 3, false, none⟩) (by simp [instruction70Before]) (by simp [instruction70Before]) rfl
theorem instruction70_path1 : ParentPath instruction70Before 2 1 :=
  ParentPath.edge (child := ⟨2, 1, (some 1), 3, false, none⟩) (parent := ⟨1, 1, none, 0, false, none⟩) (by simp [instruction70Before]) (by simp [instruction70Before]) rfl
theorem instruction70_path2 : ParentPath instruction70Before 0 1 :=
  ParentPath.trans instruction70_path0 instruction70_path1
theorem instruction70_result : instruction70After = erase instruction70Source.name instruction70Before := by decide
theorem instruction70_step : Step instruction70Before instruction70After := by
  rw [instruction70_result]
  exact Step.endLoan (c := instruction70Source) (by simp [instruction70Source, instruction70Before]) (by decide) (by decide) (by simp [Unreferenced, instruction70Before, instruction70Source])
theorem instruction70_closed_before : Closed instruction70Before := by
  simp [Closed, instruction70Before]
theorem instruction70_ranked_before : Ranked instruction70Before := by
  refine ⟨instruction70Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction70Before, instruction70Rank]
theorem instruction70_unique_before : Unique instruction70Before := by
  simp [Unique, instruction70Before]
theorem instruction70_compatible_before : Compatible instruction70Before := by
  have path0 := instruction70_path0
  simp only [instruction70Before] at path0
  have path1 := instruction70_path1
  simp only [instruction70Before] at path1
  have path2 := instruction70_path2
  simp only [instruction70Before] at path2
  simp [Compatible, Comparable, instruction70Before, path0, path1, path2]
theorem instruction70_closed_after : Closed instruction70After :=
  step_closed instruction70_step instruction70_closed_before
theorem instruction70_ranked_after : Ranked instruction70After :=
  step_ranked instruction70_step instruction70_closed_before instruction70_ranked_before
theorem instruction70_unique_after : Unique instruction70After :=
  step_unique instruction70_step instruction70_unique_before
theorem instruction70_compatible_after : Compatible instruction70After :=
  step_compatible instruction70_step instruction70_closed_before instruction70_unique_before instruction70_compatible_before
theorem instruction70_no_parent_cycle (name : Nat) : ¬ ParentPath instruction70After name name :=
  ranked_no_parent_cycle instruction70After instruction70_ranked_after name
def instruction71Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction71After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction71Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction71Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction71_path0 : ParentPath instruction71Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction71Before]) (by simp [instruction71Before]) rfl
theorem instruction71_access : Access instruction71Before instruction71Source true := by
  simp [Access, Childless, instruction71Before, instruction71Source]
theorem instruction71_result : instruction71After = instruction71Before := by decide
theorem instruction71_step : Step instruction71Before instruction71After := by
  rw [instruction71_result]
  exact Step.access instruction71_access
theorem instruction71_closed_before : Closed instruction71Before := by
  simp [Closed, instruction71Before]
theorem instruction71_ranked_before : Ranked instruction71Before := by
  refine ⟨instruction71Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction71Before, instruction71Rank]
theorem instruction71_unique_before : Unique instruction71Before := by
  simp [Unique, instruction71Before]
theorem instruction71_compatible_before : Compatible instruction71Before := by
  have path0 := instruction71_path0
  simp only [instruction71Before] at path0
  simp [Compatible, Comparable, instruction71Before, path0]
theorem instruction71_closed_after : Closed instruction71After :=
  step_closed instruction71_step instruction71_closed_before
theorem instruction71_ranked_after : Ranked instruction71After :=
  step_ranked instruction71_step instruction71_closed_before instruction71_ranked_before
theorem instruction71_unique_after : Unique instruction71After :=
  step_unique instruction71_step instruction71_unique_before
theorem instruction71_compatible_after : Compatible instruction71After :=
  step_compatible instruction71_step instruction71_closed_before instruction71_unique_before instruction71_compatible_before
theorem instruction71_no_parent_cycle (name : Nat) : ¬ ParentPath instruction71After name name :=
  ranked_no_parent_cycle instruction71After instruction71_ranked_after name
def instruction72Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction72After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction72Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction72Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction72_path0 : ParentPath instruction72Before 1 0 :=
  ParentPath.edge (child := ⟨1, 0, (some 0), 3, false, none⟩) (parent := ⟨0, 0, none, 0, false, none⟩) (by simp [instruction72Before]) (by simp [instruction72Before]) rfl
theorem instruction72_result : instruction72After = erase instruction72Source.name instruction72Before := by decide
theorem instruction72_step : Step instruction72Before instruction72After := by
  rw [instruction72_result]
  exact Step.endLoan (c := instruction72Source) (by simp [instruction72Source, instruction72Before]) (by decide) (by decide) (by simp [Unreferenced, instruction72Before, instruction72Source])
theorem instruction72_closed_before : Closed instruction72Before := by
  simp [Closed, instruction72Before]
theorem instruction72_ranked_before : Ranked instruction72Before := by
  refine ⟨instruction72Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction72Before, instruction72Rank]
theorem instruction72_unique_before : Unique instruction72Before := by
  simp [Unique, instruction72Before]
theorem instruction72_compatible_before : Compatible instruction72Before := by
  have path0 := instruction72_path0
  simp only [instruction72Before] at path0
  simp [Compatible, Comparable, instruction72Before, path0]
theorem instruction72_closed_after : Closed instruction72After :=
  step_closed instruction72_step instruction72_closed_before
theorem instruction72_ranked_after : Ranked instruction72After :=
  step_ranked instruction72_step instruction72_closed_before instruction72_ranked_before
theorem instruction72_unique_after : Unique instruction72After :=
  step_unique instruction72_step instruction72_unique_before
theorem instruction72_compatible_after : Compatible instruction72After :=
  step_compatible instruction72_step instruction72_closed_before instruction72_unique_before instruction72_compatible_before
theorem instruction72_no_parent_cycle (name : Nat) : ¬ ParentPath instruction72After name name :=
  ranked_no_parent_cycle instruction72After instruction72_ranked_after name
def instruction73Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction73After : List Capability := []
def instruction73Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction73Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction73_result : instruction73After = erase instruction73Source.name instruction73Before := by decide
theorem instruction73_step : Step instruction73Before instruction73After := by
  rw [instruction73_result]
  exact Step.dropOwner (c := instruction73Source) (by simp [instruction73Source, instruction73Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction73Before, instruction73Source])
theorem instruction73_closed_before : Closed instruction73Before := by
  simp [Closed, instruction73Before]
theorem instruction73_ranked_before : Ranked instruction73Before := by
  refine ⟨instruction73Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction73Before, instruction73Rank]
theorem instruction73_unique_before : Unique instruction73Before := by
  simp [Unique, instruction73Before]
theorem instruction73_compatible_before : Compatible instruction73Before := by
  simp [Compatible, Comparable, instruction73Before]
theorem instruction73_closed_after : Closed instruction73After :=
  step_closed instruction73_step instruction73_closed_before
theorem instruction73_ranked_after : Ranked instruction73After :=
  step_ranked instruction73_step instruction73_closed_before instruction73_ranked_before
theorem instruction73_unique_after : Unique instruction73After :=
  step_unique instruction73_step instruction73_unique_before
theorem instruction73_compatible_after : Compatible instruction73After :=
  step_compatible instruction73_step instruction73_closed_before instruction73_unique_before instruction73_compatible_before
theorem instruction73_no_parent_cycle (name : Nat) : ¬ ParentPath instruction73After name name :=
  ranked_no_parent_cycle instruction73After instruction73_ranked_after name
end HiaCapabilityBorrow
#print axioms HiaCapabilityBorrow.accessible_exclusive
#print axioms HiaCapabilityBorrow.ancestor_blocks_access
#print axioms HiaCapabilityBorrow.borrow_suspends_source
#print axioms HiaCapabilityBorrow.child_blocks_access
#print axioms HiaCapabilityBorrow.comparable_mono
#print axioms HiaCapabilityBorrow.comparable_symm
#print axioms HiaCapabilityBorrow.compatible_erase
#print axioms HiaCapabilityBorrow.compatible_loan
#print axioms HiaCapabilityBorrow.compatible_owner
#print axioms HiaCapabilityBorrow.compatible_projection
#print axioms HiaCapabilityBorrow.compatible_rename
#print axioms HiaCapabilityBorrow.compatible_subgraph
#print axioms HiaCapabilityBorrow.end_restores_access
#print axioms HiaCapabilityBorrow.instruction0_closed_after
#print axioms HiaCapabilityBorrow.instruction0_closed_before
#print axioms HiaCapabilityBorrow.instruction0_compatible_after
#print axioms HiaCapabilityBorrow.instruction0_compatible_before
#print axioms HiaCapabilityBorrow.instruction0_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction0_ranked_after
#print axioms HiaCapabilityBorrow.instruction0_ranked_before
#print axioms HiaCapabilityBorrow.instruction0_result
#print axioms HiaCapabilityBorrow.instruction0_step
#print axioms HiaCapabilityBorrow.instruction0_unique_after
#print axioms HiaCapabilityBorrow.instruction0_unique_before
#print axioms HiaCapabilityBorrow.instruction10_closed_after
#print axioms HiaCapabilityBorrow.instruction10_closed_before
#print axioms HiaCapabilityBorrow.instruction10_compatible_after
#print axioms HiaCapabilityBorrow.instruction10_compatible_before
#print axioms HiaCapabilityBorrow.instruction10_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction10_ranked_after
#print axioms HiaCapabilityBorrow.instruction10_ranked_before
#print axioms HiaCapabilityBorrow.instruction10_result
#print axioms HiaCapabilityBorrow.instruction10_step
#print axioms HiaCapabilityBorrow.instruction10_unique_after
#print axioms HiaCapabilityBorrow.instruction10_unique_before
#print axioms HiaCapabilityBorrow.instruction11_borrow_guard
#print axioms HiaCapabilityBorrow.instruction11_closed_after
#print axioms HiaCapabilityBorrow.instruction11_closed_before
#print axioms HiaCapabilityBorrow.instruction11_compatible_after
#print axioms HiaCapabilityBorrow.instruction11_compatible_before
#print axioms HiaCapabilityBorrow.instruction11_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction11_ranked_after
#print axioms HiaCapabilityBorrow.instruction11_ranked_before
#print axioms HiaCapabilityBorrow.instruction11_result
#print axioms HiaCapabilityBorrow.instruction11_source_suspended
#print axioms HiaCapabilityBorrow.instruction11_step
#print axioms HiaCapabilityBorrow.instruction11_unique_after
#print axioms HiaCapabilityBorrow.instruction11_unique_before
#print axioms HiaCapabilityBorrow.instruction12_borrow_guard
#print axioms HiaCapabilityBorrow.instruction12_closed_after
#print axioms HiaCapabilityBorrow.instruction12_closed_before
#print axioms HiaCapabilityBorrow.instruction12_compatible_after
#print axioms HiaCapabilityBorrow.instruction12_compatible_before
#print axioms HiaCapabilityBorrow.instruction12_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction12_ranked_after
#print axioms HiaCapabilityBorrow.instruction12_ranked_before
#print axioms HiaCapabilityBorrow.instruction12_result
#print axioms HiaCapabilityBorrow.instruction12_source_suspended
#print axioms HiaCapabilityBorrow.instruction12_step
#print axioms HiaCapabilityBorrow.instruction12_unique_after
#print axioms HiaCapabilityBorrow.instruction12_unique_before
#print axioms HiaCapabilityBorrow.instruction13_borrow_guard
#print axioms HiaCapabilityBorrow.instruction13_closed_after
#print axioms HiaCapabilityBorrow.instruction13_closed_before
#print axioms HiaCapabilityBorrow.instruction13_compatible_after
#print axioms HiaCapabilityBorrow.instruction13_compatible_before
#print axioms HiaCapabilityBorrow.instruction13_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction13_ranked_after
#print axioms HiaCapabilityBorrow.instruction13_ranked_before
#print axioms HiaCapabilityBorrow.instruction13_result
#print axioms HiaCapabilityBorrow.instruction13_source_suspended
#print axioms HiaCapabilityBorrow.instruction13_step
#print axioms HiaCapabilityBorrow.instruction13_unique_after
#print axioms HiaCapabilityBorrow.instruction13_unique_before
#print axioms HiaCapabilityBorrow.instruction14_closed_after
#print axioms HiaCapabilityBorrow.instruction14_closed_before
#print axioms HiaCapabilityBorrow.instruction14_compatible_after
#print axioms HiaCapabilityBorrow.instruction14_compatible_before
#print axioms HiaCapabilityBorrow.instruction14_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction14_ranked_after
#print axioms HiaCapabilityBorrow.instruction14_ranked_before
#print axioms HiaCapabilityBorrow.instruction14_result
#print axioms HiaCapabilityBorrow.instruction14_step
#print axioms HiaCapabilityBorrow.instruction14_unique_after
#print axioms HiaCapabilityBorrow.instruction14_unique_before
#print axioms HiaCapabilityBorrow.instruction15_borrow_guard
#print axioms HiaCapabilityBorrow.instruction15_closed_after
#print axioms HiaCapabilityBorrow.instruction15_closed_before
#print axioms HiaCapabilityBorrow.instruction15_compatible_after
#print axioms HiaCapabilityBorrow.instruction15_compatible_before
#print axioms HiaCapabilityBorrow.instruction15_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction15_ranked_after
#print axioms HiaCapabilityBorrow.instruction15_ranked_before
#print axioms HiaCapabilityBorrow.instruction15_result
#print axioms HiaCapabilityBorrow.instruction15_source_suspended
#print axioms HiaCapabilityBorrow.instruction15_step
#print axioms HiaCapabilityBorrow.instruction15_unique_after
#print axioms HiaCapabilityBorrow.instruction15_unique_before
#print axioms HiaCapabilityBorrow.instruction16_access
#print axioms HiaCapabilityBorrow.instruction16_closed_after
#print axioms HiaCapabilityBorrow.instruction16_closed_before
#print axioms HiaCapabilityBorrow.instruction16_compatible_after
#print axioms HiaCapabilityBorrow.instruction16_compatible_before
#print axioms HiaCapabilityBorrow.instruction16_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction16_path0
#print axioms HiaCapabilityBorrow.instruction16_ranked_after
#print axioms HiaCapabilityBorrow.instruction16_ranked_before
#print axioms HiaCapabilityBorrow.instruction16_result
#print axioms HiaCapabilityBorrow.instruction16_step
#print axioms HiaCapabilityBorrow.instruction16_unique_after
#print axioms HiaCapabilityBorrow.instruction16_unique_before
#print axioms HiaCapabilityBorrow.instruction17_closed_after
#print axioms HiaCapabilityBorrow.instruction17_closed_before
#print axioms HiaCapabilityBorrow.instruction17_compatible_after
#print axioms HiaCapabilityBorrow.instruction17_compatible_before
#print axioms HiaCapabilityBorrow.instruction17_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction17_path0
#print axioms HiaCapabilityBorrow.instruction17_ranked_after
#print axioms HiaCapabilityBorrow.instruction17_ranked_before
#print axioms HiaCapabilityBorrow.instruction17_result
#print axioms HiaCapabilityBorrow.instruction17_step
#print axioms HiaCapabilityBorrow.instruction17_unique_after
#print axioms HiaCapabilityBorrow.instruction17_unique_before
#print axioms HiaCapabilityBorrow.instruction18_borrow_guard
#print axioms HiaCapabilityBorrow.instruction18_closed_after
#print axioms HiaCapabilityBorrow.instruction18_closed_before
#print axioms HiaCapabilityBorrow.instruction18_compatible_after
#print axioms HiaCapabilityBorrow.instruction18_compatible_before
#print axioms HiaCapabilityBorrow.instruction18_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction18_ranked_after
#print axioms HiaCapabilityBorrow.instruction18_ranked_before
#print axioms HiaCapabilityBorrow.instruction18_result
#print axioms HiaCapabilityBorrow.instruction18_source_suspended
#print axioms HiaCapabilityBorrow.instruction18_step
#print axioms HiaCapabilityBorrow.instruction18_unique_after
#print axioms HiaCapabilityBorrow.instruction18_unique_before
#print axioms HiaCapabilityBorrow.instruction19_borrow_guard
#print axioms HiaCapabilityBorrow.instruction19_closed_after
#print axioms HiaCapabilityBorrow.instruction19_closed_before
#print axioms HiaCapabilityBorrow.instruction19_compatible_after
#print axioms HiaCapabilityBorrow.instruction19_compatible_before
#print axioms HiaCapabilityBorrow.instruction19_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction19_path0
#print axioms HiaCapabilityBorrow.instruction19_path1
#print axioms HiaCapabilityBorrow.instruction19_path2
#print axioms HiaCapabilityBorrow.instruction19_ranked_after
#print axioms HiaCapabilityBorrow.instruction19_ranked_before
#print axioms HiaCapabilityBorrow.instruction19_result
#print axioms HiaCapabilityBorrow.instruction19_source_suspended
#print axioms HiaCapabilityBorrow.instruction19_step
#print axioms HiaCapabilityBorrow.instruction19_unique_after
#print axioms HiaCapabilityBorrow.instruction19_unique_before
#print axioms HiaCapabilityBorrow.instruction1_borrow_guard
#print axioms HiaCapabilityBorrow.instruction1_closed_after
#print axioms HiaCapabilityBorrow.instruction1_closed_before
#print axioms HiaCapabilityBorrow.instruction1_compatible_after
#print axioms HiaCapabilityBorrow.instruction1_compatible_before
#print axioms HiaCapabilityBorrow.instruction1_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction1_ranked_after
#print axioms HiaCapabilityBorrow.instruction1_ranked_before
#print axioms HiaCapabilityBorrow.instruction1_result
#print axioms HiaCapabilityBorrow.instruction1_source_suspended
#print axioms HiaCapabilityBorrow.instruction1_step
#print axioms HiaCapabilityBorrow.instruction1_unique_after
#print axioms HiaCapabilityBorrow.instruction1_unique_before
#print axioms HiaCapabilityBorrow.instruction20_access
#print axioms HiaCapabilityBorrow.instruction20_closed_after
#print axioms HiaCapabilityBorrow.instruction20_closed_before
#print axioms HiaCapabilityBorrow.instruction20_compatible_after
#print axioms HiaCapabilityBorrow.instruction20_compatible_before
#print axioms HiaCapabilityBorrow.instruction20_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction20_path0
#print axioms HiaCapabilityBorrow.instruction20_path1
#print axioms HiaCapabilityBorrow.instruction20_path2
#print axioms HiaCapabilityBorrow.instruction20_path3
#print axioms HiaCapabilityBorrow.instruction20_path4
#print axioms HiaCapabilityBorrow.instruction20_path5
#print axioms HiaCapabilityBorrow.instruction20_ranked_after
#print axioms HiaCapabilityBorrow.instruction20_ranked_before
#print axioms HiaCapabilityBorrow.instruction20_result
#print axioms HiaCapabilityBorrow.instruction20_step
#print axioms HiaCapabilityBorrow.instruction20_unique_after
#print axioms HiaCapabilityBorrow.instruction20_unique_before
#print axioms HiaCapabilityBorrow.instruction21_closed_after
#print axioms HiaCapabilityBorrow.instruction21_closed_before
#print axioms HiaCapabilityBorrow.instruction21_compatible_after
#print axioms HiaCapabilityBorrow.instruction21_compatible_before
#print axioms HiaCapabilityBorrow.instruction21_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction21_path0
#print axioms HiaCapabilityBorrow.instruction21_path1
#print axioms HiaCapabilityBorrow.instruction21_path2
#print axioms HiaCapabilityBorrow.instruction21_path3
#print axioms HiaCapabilityBorrow.instruction21_path4
#print axioms HiaCapabilityBorrow.instruction21_path5
#print axioms HiaCapabilityBorrow.instruction21_ranked_after
#print axioms HiaCapabilityBorrow.instruction21_ranked_before
#print axioms HiaCapabilityBorrow.instruction21_result
#print axioms HiaCapabilityBorrow.instruction21_step
#print axioms HiaCapabilityBorrow.instruction21_unique_after
#print axioms HiaCapabilityBorrow.instruction21_unique_before
#print axioms HiaCapabilityBorrow.instruction22_closed_after
#print axioms HiaCapabilityBorrow.instruction22_closed_before
#print axioms HiaCapabilityBorrow.instruction22_compatible_after
#print axioms HiaCapabilityBorrow.instruction22_compatible_before
#print axioms HiaCapabilityBorrow.instruction22_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction22_path0
#print axioms HiaCapabilityBorrow.instruction22_path1
#print axioms HiaCapabilityBorrow.instruction22_path2
#print axioms HiaCapabilityBorrow.instruction22_ranked_after
#print axioms HiaCapabilityBorrow.instruction22_ranked_before
#print axioms HiaCapabilityBorrow.instruction22_result
#print axioms HiaCapabilityBorrow.instruction22_step
#print axioms HiaCapabilityBorrow.instruction22_unique_after
#print axioms HiaCapabilityBorrow.instruction22_unique_before
#print axioms HiaCapabilityBorrow.instruction23_closed_after
#print axioms HiaCapabilityBorrow.instruction23_closed_before
#print axioms HiaCapabilityBorrow.instruction23_compatible_after
#print axioms HiaCapabilityBorrow.instruction23_compatible_before
#print axioms HiaCapabilityBorrow.instruction23_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction23_path0
#print axioms HiaCapabilityBorrow.instruction23_ranked_after
#print axioms HiaCapabilityBorrow.instruction23_ranked_before
#print axioms HiaCapabilityBorrow.instruction23_result
#print axioms HiaCapabilityBorrow.instruction23_step
#print axioms HiaCapabilityBorrow.instruction23_unique_after
#print axioms HiaCapabilityBorrow.instruction23_unique_before
#print axioms HiaCapabilityBorrow.instruction24_borrow_guard
#print axioms HiaCapabilityBorrow.instruction24_closed_after
#print axioms HiaCapabilityBorrow.instruction24_closed_before
#print axioms HiaCapabilityBorrow.instruction24_compatible_after
#print axioms HiaCapabilityBorrow.instruction24_compatible_before
#print axioms HiaCapabilityBorrow.instruction24_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction24_ranked_after
#print axioms HiaCapabilityBorrow.instruction24_ranked_before
#print axioms HiaCapabilityBorrow.instruction24_result
#print axioms HiaCapabilityBorrow.instruction24_source_suspended
#print axioms HiaCapabilityBorrow.instruction24_step
#print axioms HiaCapabilityBorrow.instruction24_unique_after
#print axioms HiaCapabilityBorrow.instruction24_unique_before
#print axioms HiaCapabilityBorrow.instruction25_access
#print axioms HiaCapabilityBorrow.instruction25_closed_after
#print axioms HiaCapabilityBorrow.instruction25_closed_before
#print axioms HiaCapabilityBorrow.instruction25_compatible_after
#print axioms HiaCapabilityBorrow.instruction25_compatible_before
#print axioms HiaCapabilityBorrow.instruction25_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction25_path0
#print axioms HiaCapabilityBorrow.instruction25_ranked_after
#print axioms HiaCapabilityBorrow.instruction25_ranked_before
#print axioms HiaCapabilityBorrow.instruction25_result
#print axioms HiaCapabilityBorrow.instruction25_step
#print axioms HiaCapabilityBorrow.instruction25_unique_after
#print axioms HiaCapabilityBorrow.instruction25_unique_before
#print axioms HiaCapabilityBorrow.instruction26_closed_after
#print axioms HiaCapabilityBorrow.instruction26_closed_before
#print axioms HiaCapabilityBorrow.instruction26_compatible_after
#print axioms HiaCapabilityBorrow.instruction26_compatible_before
#print axioms HiaCapabilityBorrow.instruction26_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction26_path0
#print axioms HiaCapabilityBorrow.instruction26_ranked_after
#print axioms HiaCapabilityBorrow.instruction26_ranked_before
#print axioms HiaCapabilityBorrow.instruction26_result
#print axioms HiaCapabilityBorrow.instruction26_step
#print axioms HiaCapabilityBorrow.instruction26_unique_after
#print axioms HiaCapabilityBorrow.instruction26_unique_before
#print axioms HiaCapabilityBorrow.instruction27_borrow_guard
#print axioms HiaCapabilityBorrow.instruction27_closed_after
#print axioms HiaCapabilityBorrow.instruction27_closed_before
#print axioms HiaCapabilityBorrow.instruction27_compatible_after
#print axioms HiaCapabilityBorrow.instruction27_compatible_before
#print axioms HiaCapabilityBorrow.instruction27_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction27_ranked_after
#print axioms HiaCapabilityBorrow.instruction27_ranked_before
#print axioms HiaCapabilityBorrow.instruction27_result
#print axioms HiaCapabilityBorrow.instruction27_source_suspended
#print axioms HiaCapabilityBorrow.instruction27_step
#print axioms HiaCapabilityBorrow.instruction27_unique_after
#print axioms HiaCapabilityBorrow.instruction27_unique_before
#print axioms HiaCapabilityBorrow.instruction28_borrow_guard
#print axioms HiaCapabilityBorrow.instruction28_closed_after
#print axioms HiaCapabilityBorrow.instruction28_closed_before
#print axioms HiaCapabilityBorrow.instruction28_compatible_after
#print axioms HiaCapabilityBorrow.instruction28_compatible_before
#print axioms HiaCapabilityBorrow.instruction28_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction28_path0
#print axioms HiaCapabilityBorrow.instruction28_path1
#print axioms HiaCapabilityBorrow.instruction28_path2
#print axioms HiaCapabilityBorrow.instruction28_ranked_after
#print axioms HiaCapabilityBorrow.instruction28_ranked_before
#print axioms HiaCapabilityBorrow.instruction28_result
#print axioms HiaCapabilityBorrow.instruction28_source_suspended
#print axioms HiaCapabilityBorrow.instruction28_step
#print axioms HiaCapabilityBorrow.instruction28_unique_after
#print axioms HiaCapabilityBorrow.instruction28_unique_before
#print axioms HiaCapabilityBorrow.instruction29_access
#print axioms HiaCapabilityBorrow.instruction29_closed_after
#print axioms HiaCapabilityBorrow.instruction29_closed_before
#print axioms HiaCapabilityBorrow.instruction29_compatible_after
#print axioms HiaCapabilityBorrow.instruction29_compatible_before
#print axioms HiaCapabilityBorrow.instruction29_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction29_path0
#print axioms HiaCapabilityBorrow.instruction29_path1
#print axioms HiaCapabilityBorrow.instruction29_path2
#print axioms HiaCapabilityBorrow.instruction29_path3
#print axioms HiaCapabilityBorrow.instruction29_path4
#print axioms HiaCapabilityBorrow.instruction29_path5
#print axioms HiaCapabilityBorrow.instruction29_ranked_after
#print axioms HiaCapabilityBorrow.instruction29_ranked_before
#print axioms HiaCapabilityBorrow.instruction29_result
#print axioms HiaCapabilityBorrow.instruction29_step
#print axioms HiaCapabilityBorrow.instruction29_unique_after
#print axioms HiaCapabilityBorrow.instruction29_unique_before
#print axioms HiaCapabilityBorrow.instruction2_borrow_guard
#print axioms HiaCapabilityBorrow.instruction2_closed_after
#print axioms HiaCapabilityBorrow.instruction2_closed_before
#print axioms HiaCapabilityBorrow.instruction2_compatible_after
#print axioms HiaCapabilityBorrow.instruction2_compatible_before
#print axioms HiaCapabilityBorrow.instruction2_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction2_path0
#print axioms HiaCapabilityBorrow.instruction2_ranked_after
#print axioms HiaCapabilityBorrow.instruction2_ranked_before
#print axioms HiaCapabilityBorrow.instruction2_result
#print axioms HiaCapabilityBorrow.instruction2_source_suspended
#print axioms HiaCapabilityBorrow.instruction2_step
#print axioms HiaCapabilityBorrow.instruction2_unique_after
#print axioms HiaCapabilityBorrow.instruction2_unique_before
#print axioms HiaCapabilityBorrow.instruction30_closed_after
#print axioms HiaCapabilityBorrow.instruction30_closed_before
#print axioms HiaCapabilityBorrow.instruction30_compatible_after
#print axioms HiaCapabilityBorrow.instruction30_compatible_before
#print axioms HiaCapabilityBorrow.instruction30_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction30_path0
#print axioms HiaCapabilityBorrow.instruction30_path1
#print axioms HiaCapabilityBorrow.instruction30_path2
#print axioms HiaCapabilityBorrow.instruction30_path3
#print axioms HiaCapabilityBorrow.instruction30_path4
#print axioms HiaCapabilityBorrow.instruction30_path5
#print axioms HiaCapabilityBorrow.instruction30_ranked_after
#print axioms HiaCapabilityBorrow.instruction30_ranked_before
#print axioms HiaCapabilityBorrow.instruction30_result
#print axioms HiaCapabilityBorrow.instruction30_step
#print axioms HiaCapabilityBorrow.instruction30_unique_after
#print axioms HiaCapabilityBorrow.instruction30_unique_before
#print axioms HiaCapabilityBorrow.instruction31_closed_after
#print axioms HiaCapabilityBorrow.instruction31_closed_before
#print axioms HiaCapabilityBorrow.instruction31_compatible_after
#print axioms HiaCapabilityBorrow.instruction31_compatible_before
#print axioms HiaCapabilityBorrow.instruction31_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction31_path0
#print axioms HiaCapabilityBorrow.instruction31_path1
#print axioms HiaCapabilityBorrow.instruction31_path2
#print axioms HiaCapabilityBorrow.instruction31_ranked_after
#print axioms HiaCapabilityBorrow.instruction31_ranked_before
#print axioms HiaCapabilityBorrow.instruction31_result
#print axioms HiaCapabilityBorrow.instruction31_step
#print axioms HiaCapabilityBorrow.instruction31_unique_after
#print axioms HiaCapabilityBorrow.instruction31_unique_before
#print axioms HiaCapabilityBorrow.instruction32_closed_after
#print axioms HiaCapabilityBorrow.instruction32_closed_before
#print axioms HiaCapabilityBorrow.instruction32_compatible_after
#print axioms HiaCapabilityBorrow.instruction32_compatible_before
#print axioms HiaCapabilityBorrow.instruction32_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction32_path0
#print axioms HiaCapabilityBorrow.instruction32_ranked_after
#print axioms HiaCapabilityBorrow.instruction32_ranked_before
#print axioms HiaCapabilityBorrow.instruction32_result
#print axioms HiaCapabilityBorrow.instruction32_step
#print axioms HiaCapabilityBorrow.instruction32_unique_after
#print axioms HiaCapabilityBorrow.instruction32_unique_before
#print axioms HiaCapabilityBorrow.instruction33_closed_after
#print axioms HiaCapabilityBorrow.instruction33_closed_before
#print axioms HiaCapabilityBorrow.instruction33_compatible_after
#print axioms HiaCapabilityBorrow.instruction33_compatible_before
#print axioms HiaCapabilityBorrow.instruction33_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction33_ranked_after
#print axioms HiaCapabilityBorrow.instruction33_ranked_before
#print axioms HiaCapabilityBorrow.instruction33_result
#print axioms HiaCapabilityBorrow.instruction33_step
#print axioms HiaCapabilityBorrow.instruction33_unique_after
#print axioms HiaCapabilityBorrow.instruction33_unique_before
#print axioms HiaCapabilityBorrow.instruction34_closed_after
#print axioms HiaCapabilityBorrow.instruction34_closed_before
#print axioms HiaCapabilityBorrow.instruction34_compatible_after
#print axioms HiaCapabilityBorrow.instruction34_compatible_before
#print axioms HiaCapabilityBorrow.instruction34_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction34_ranked_after
#print axioms HiaCapabilityBorrow.instruction34_ranked_before
#print axioms HiaCapabilityBorrow.instruction34_result
#print axioms HiaCapabilityBorrow.instruction34_step
#print axioms HiaCapabilityBorrow.instruction34_unique_after
#print axioms HiaCapabilityBorrow.instruction34_unique_before
#print axioms HiaCapabilityBorrow.instruction35_borrow_guard
#print axioms HiaCapabilityBorrow.instruction35_closed_after
#print axioms HiaCapabilityBorrow.instruction35_closed_before
#print axioms HiaCapabilityBorrow.instruction35_compatible_after
#print axioms HiaCapabilityBorrow.instruction35_compatible_before
#print axioms HiaCapabilityBorrow.instruction35_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction35_ranked_after
#print axioms HiaCapabilityBorrow.instruction35_ranked_before
#print axioms HiaCapabilityBorrow.instruction35_result
#print axioms HiaCapabilityBorrow.instruction35_source_suspended
#print axioms HiaCapabilityBorrow.instruction35_step
#print axioms HiaCapabilityBorrow.instruction35_unique_after
#print axioms HiaCapabilityBorrow.instruction35_unique_before
#print axioms HiaCapabilityBorrow.instruction36_borrow_guard
#print axioms HiaCapabilityBorrow.instruction36_closed_after
#print axioms HiaCapabilityBorrow.instruction36_closed_before
#print axioms HiaCapabilityBorrow.instruction36_compatible_after
#print axioms HiaCapabilityBorrow.instruction36_compatible_before
#print axioms HiaCapabilityBorrow.instruction36_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction36_path0
#print axioms HiaCapabilityBorrow.instruction36_ranked_after
#print axioms HiaCapabilityBorrow.instruction36_ranked_before
#print axioms HiaCapabilityBorrow.instruction36_result
#print axioms HiaCapabilityBorrow.instruction36_source_suspended
#print axioms HiaCapabilityBorrow.instruction36_step
#print axioms HiaCapabilityBorrow.instruction36_unique_after
#print axioms HiaCapabilityBorrow.instruction36_unique_before
#print axioms HiaCapabilityBorrow.instruction37_closed_after
#print axioms HiaCapabilityBorrow.instruction37_closed_before
#print axioms HiaCapabilityBorrow.instruction37_compatible_after
#print axioms HiaCapabilityBorrow.instruction37_compatible_before
#print axioms HiaCapabilityBorrow.instruction37_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction37_path0
#print axioms HiaCapabilityBorrow.instruction37_path1
#print axioms HiaCapabilityBorrow.instruction37_path2
#print axioms HiaCapabilityBorrow.instruction37_ranked_after
#print axioms HiaCapabilityBorrow.instruction37_ranked_before
#print axioms HiaCapabilityBorrow.instruction37_result
#print axioms HiaCapabilityBorrow.instruction37_step
#print axioms HiaCapabilityBorrow.instruction37_unique_after
#print axioms HiaCapabilityBorrow.instruction37_unique_before
#print axioms HiaCapabilityBorrow.instruction38_closed_after
#print axioms HiaCapabilityBorrow.instruction38_closed_before
#print axioms HiaCapabilityBorrow.instruction38_compatible_after
#print axioms HiaCapabilityBorrow.instruction38_compatible_before
#print axioms HiaCapabilityBorrow.instruction38_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction38_path0
#print axioms HiaCapabilityBorrow.instruction38_ranked_after
#print axioms HiaCapabilityBorrow.instruction38_ranked_before
#print axioms HiaCapabilityBorrow.instruction38_result
#print axioms HiaCapabilityBorrow.instruction38_step
#print axioms HiaCapabilityBorrow.instruction38_unique_after
#print axioms HiaCapabilityBorrow.instruction38_unique_before
#print axioms HiaCapabilityBorrow.instruction39_borrow_guard
#print axioms HiaCapabilityBorrow.instruction39_closed_after
#print axioms HiaCapabilityBorrow.instruction39_closed_before
#print axioms HiaCapabilityBorrow.instruction39_compatible_after
#print axioms HiaCapabilityBorrow.instruction39_compatible_before
#print axioms HiaCapabilityBorrow.instruction39_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction39_ranked_after
#print axioms HiaCapabilityBorrow.instruction39_ranked_before
#print axioms HiaCapabilityBorrow.instruction39_result
#print axioms HiaCapabilityBorrow.instruction39_source_suspended
#print axioms HiaCapabilityBorrow.instruction39_step
#print axioms HiaCapabilityBorrow.instruction39_unique_after
#print axioms HiaCapabilityBorrow.instruction39_unique_before
#print axioms HiaCapabilityBorrow.instruction3_access
#print axioms HiaCapabilityBorrow.instruction3_closed_after
#print axioms HiaCapabilityBorrow.instruction3_closed_before
#print axioms HiaCapabilityBorrow.instruction3_compatible_after
#print axioms HiaCapabilityBorrow.instruction3_compatible_before
#print axioms HiaCapabilityBorrow.instruction3_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction3_path0
#print axioms HiaCapabilityBorrow.instruction3_path1
#print axioms HiaCapabilityBorrow.instruction3_path2
#print axioms HiaCapabilityBorrow.instruction3_ranked_after
#print axioms HiaCapabilityBorrow.instruction3_ranked_before
#print axioms HiaCapabilityBorrow.instruction3_result
#print axioms HiaCapabilityBorrow.instruction3_step
#print axioms HiaCapabilityBorrow.instruction3_unique_after
#print axioms HiaCapabilityBorrow.instruction3_unique_before
#print axioms HiaCapabilityBorrow.instruction40_borrow_guard
#print axioms HiaCapabilityBorrow.instruction40_closed_after
#print axioms HiaCapabilityBorrow.instruction40_closed_before
#print axioms HiaCapabilityBorrow.instruction40_compatible_after
#print axioms HiaCapabilityBorrow.instruction40_compatible_before
#print axioms HiaCapabilityBorrow.instruction40_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction40_path0
#print axioms HiaCapabilityBorrow.instruction40_ranked_after
#print axioms HiaCapabilityBorrow.instruction40_ranked_before
#print axioms HiaCapabilityBorrow.instruction40_result
#print axioms HiaCapabilityBorrow.instruction40_source_suspended
#print axioms HiaCapabilityBorrow.instruction40_step
#print axioms HiaCapabilityBorrow.instruction40_unique_after
#print axioms HiaCapabilityBorrow.instruction40_unique_before
#print axioms HiaCapabilityBorrow.instruction41_closed_after
#print axioms HiaCapabilityBorrow.instruction41_closed_before
#print axioms HiaCapabilityBorrow.instruction41_compatible_after
#print axioms HiaCapabilityBorrow.instruction41_compatible_before
#print axioms HiaCapabilityBorrow.instruction41_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction41_path0
#print axioms HiaCapabilityBorrow.instruction41_path1
#print axioms HiaCapabilityBorrow.instruction41_ranked_after
#print axioms HiaCapabilityBorrow.instruction41_ranked_before
#print axioms HiaCapabilityBorrow.instruction41_result
#print axioms HiaCapabilityBorrow.instruction41_step
#print axioms HiaCapabilityBorrow.instruction41_unique_after
#print axioms HiaCapabilityBorrow.instruction41_unique_before
#print axioms HiaCapabilityBorrow.instruction42_closed_after
#print axioms HiaCapabilityBorrow.instruction42_closed_before
#print axioms HiaCapabilityBorrow.instruction42_compatible_after
#print axioms HiaCapabilityBorrow.instruction42_compatible_before
#print axioms HiaCapabilityBorrow.instruction42_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction42_path0
#print axioms HiaCapabilityBorrow.instruction42_ranked_after
#print axioms HiaCapabilityBorrow.instruction42_ranked_before
#print axioms HiaCapabilityBorrow.instruction42_result
#print axioms HiaCapabilityBorrow.instruction42_step
#print axioms HiaCapabilityBorrow.instruction42_unique_after
#print axioms HiaCapabilityBorrow.instruction42_unique_before
#print axioms HiaCapabilityBorrow.instruction43_closed_after
#print axioms HiaCapabilityBorrow.instruction43_closed_before
#print axioms HiaCapabilityBorrow.instruction43_compatible_after
#print axioms HiaCapabilityBorrow.instruction43_compatible_before
#print axioms HiaCapabilityBorrow.instruction43_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction43_ranked_after
#print axioms HiaCapabilityBorrow.instruction43_ranked_before
#print axioms HiaCapabilityBorrow.instruction43_result
#print axioms HiaCapabilityBorrow.instruction43_step
#print axioms HiaCapabilityBorrow.instruction43_unique_after
#print axioms HiaCapabilityBorrow.instruction43_unique_before
#print axioms HiaCapabilityBorrow.instruction44_closed_after
#print axioms HiaCapabilityBorrow.instruction44_closed_before
#print axioms HiaCapabilityBorrow.instruction44_compatible_after
#print axioms HiaCapabilityBorrow.instruction44_compatible_before
#print axioms HiaCapabilityBorrow.instruction44_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction44_ranked_after
#print axioms HiaCapabilityBorrow.instruction44_ranked_before
#print axioms HiaCapabilityBorrow.instruction44_result
#print axioms HiaCapabilityBorrow.instruction44_step
#print axioms HiaCapabilityBorrow.instruction44_unique_after
#print axioms HiaCapabilityBorrow.instruction44_unique_before
#print axioms HiaCapabilityBorrow.instruction45_closed_after
#print axioms HiaCapabilityBorrow.instruction45_closed_before
#print axioms HiaCapabilityBorrow.instruction45_compatible_after
#print axioms HiaCapabilityBorrow.instruction45_compatible_before
#print axioms HiaCapabilityBorrow.instruction45_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction45_ranked_after
#print axioms HiaCapabilityBorrow.instruction45_ranked_before
#print axioms HiaCapabilityBorrow.instruction45_result
#print axioms HiaCapabilityBorrow.instruction45_step
#print axioms HiaCapabilityBorrow.instruction45_unique_after
#print axioms HiaCapabilityBorrow.instruction45_unique_before
#print axioms HiaCapabilityBorrow.instruction46_closed_after
#print axioms HiaCapabilityBorrow.instruction46_closed_before
#print axioms HiaCapabilityBorrow.instruction46_compatible_after
#print axioms HiaCapabilityBorrow.instruction46_compatible_before
#print axioms HiaCapabilityBorrow.instruction46_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction46_ranked_after
#print axioms HiaCapabilityBorrow.instruction46_ranked_before
#print axioms HiaCapabilityBorrow.instruction46_result
#print axioms HiaCapabilityBorrow.instruction46_step
#print axioms HiaCapabilityBorrow.instruction46_unique_after
#print axioms HiaCapabilityBorrow.instruction46_unique_before
#print axioms HiaCapabilityBorrow.instruction47_borrow_guard
#print axioms HiaCapabilityBorrow.instruction47_closed_after
#print axioms HiaCapabilityBorrow.instruction47_closed_before
#print axioms HiaCapabilityBorrow.instruction47_compatible_after
#print axioms HiaCapabilityBorrow.instruction47_compatible_before
#print axioms HiaCapabilityBorrow.instruction47_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction47_ranked_after
#print axioms HiaCapabilityBorrow.instruction47_ranked_before
#print axioms HiaCapabilityBorrow.instruction47_result
#print axioms HiaCapabilityBorrow.instruction47_source_suspended
#print axioms HiaCapabilityBorrow.instruction47_step
#print axioms HiaCapabilityBorrow.instruction47_unique_after
#print axioms HiaCapabilityBorrow.instruction47_unique_before
#print axioms HiaCapabilityBorrow.instruction48_access
#print axioms HiaCapabilityBorrow.instruction48_closed_after
#print axioms HiaCapabilityBorrow.instruction48_closed_before
#print axioms HiaCapabilityBorrow.instruction48_compatible_after
#print axioms HiaCapabilityBorrow.instruction48_compatible_before
#print axioms HiaCapabilityBorrow.instruction48_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction48_path0
#print axioms HiaCapabilityBorrow.instruction48_ranked_after
#print axioms HiaCapabilityBorrow.instruction48_ranked_before
#print axioms HiaCapabilityBorrow.instruction48_result
#print axioms HiaCapabilityBorrow.instruction48_step
#print axioms HiaCapabilityBorrow.instruction48_unique_after
#print axioms HiaCapabilityBorrow.instruction48_unique_before
#print axioms HiaCapabilityBorrow.instruction49_borrow_guard
#print axioms HiaCapabilityBorrow.instruction49_closed_after
#print axioms HiaCapabilityBorrow.instruction49_closed_before
#print axioms HiaCapabilityBorrow.instruction49_compatible_after
#print axioms HiaCapabilityBorrow.instruction49_compatible_before
#print axioms HiaCapabilityBorrow.instruction49_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction49_path0
#print axioms HiaCapabilityBorrow.instruction49_ranked_after
#print axioms HiaCapabilityBorrow.instruction49_ranked_before
#print axioms HiaCapabilityBorrow.instruction49_result
#print axioms HiaCapabilityBorrow.instruction49_source_suspended
#print axioms HiaCapabilityBorrow.instruction49_step
#print axioms HiaCapabilityBorrow.instruction49_unique_after
#print axioms HiaCapabilityBorrow.instruction49_unique_before
#print axioms HiaCapabilityBorrow.instruction4_closed_after
#print axioms HiaCapabilityBorrow.instruction4_closed_before
#print axioms HiaCapabilityBorrow.instruction4_compatible_after
#print axioms HiaCapabilityBorrow.instruction4_compatible_before
#print axioms HiaCapabilityBorrow.instruction4_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction4_path0
#print axioms HiaCapabilityBorrow.instruction4_path1
#print axioms HiaCapabilityBorrow.instruction4_path2
#print axioms HiaCapabilityBorrow.instruction4_ranked_after
#print axioms HiaCapabilityBorrow.instruction4_ranked_before
#print axioms HiaCapabilityBorrow.instruction4_result
#print axioms HiaCapabilityBorrow.instruction4_step
#print axioms HiaCapabilityBorrow.instruction4_unique_after
#print axioms HiaCapabilityBorrow.instruction4_unique_before
#print axioms HiaCapabilityBorrow.instruction50_borrow_guard
#print axioms HiaCapabilityBorrow.instruction50_closed_after
#print axioms HiaCapabilityBorrow.instruction50_closed_before
#print axioms HiaCapabilityBorrow.instruction50_compatible_after
#print axioms HiaCapabilityBorrow.instruction50_compatible_before
#print axioms HiaCapabilityBorrow.instruction50_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction50_path0
#print axioms HiaCapabilityBorrow.instruction50_path1
#print axioms HiaCapabilityBorrow.instruction50_path2
#print axioms HiaCapabilityBorrow.instruction50_ranked_after
#print axioms HiaCapabilityBorrow.instruction50_ranked_before
#print axioms HiaCapabilityBorrow.instruction50_result
#print axioms HiaCapabilityBorrow.instruction50_source_suspended
#print axioms HiaCapabilityBorrow.instruction50_step
#print axioms HiaCapabilityBorrow.instruction50_unique_after
#print axioms HiaCapabilityBorrow.instruction50_unique_before
#print axioms HiaCapabilityBorrow.instruction51_access
#print axioms HiaCapabilityBorrow.instruction51_closed_after
#print axioms HiaCapabilityBorrow.instruction51_closed_before
#print axioms HiaCapabilityBorrow.instruction51_compatible_after
#print axioms HiaCapabilityBorrow.instruction51_compatible_before
#print axioms HiaCapabilityBorrow.instruction51_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction51_path0
#print axioms HiaCapabilityBorrow.instruction51_path1
#print axioms HiaCapabilityBorrow.instruction51_path2
#print axioms HiaCapabilityBorrow.instruction51_path3
#print axioms HiaCapabilityBorrow.instruction51_path4
#print axioms HiaCapabilityBorrow.instruction51_ranked_after
#print axioms HiaCapabilityBorrow.instruction51_ranked_before
#print axioms HiaCapabilityBorrow.instruction51_result
#print axioms HiaCapabilityBorrow.instruction51_step
#print axioms HiaCapabilityBorrow.instruction51_unique_after
#print axioms HiaCapabilityBorrow.instruction51_unique_before
#print axioms HiaCapabilityBorrow.instruction52_borrow_guard
#print axioms HiaCapabilityBorrow.instruction52_closed_after
#print axioms HiaCapabilityBorrow.instruction52_closed_before
#print axioms HiaCapabilityBorrow.instruction52_compatible_after
#print axioms HiaCapabilityBorrow.instruction52_compatible_before
#print axioms HiaCapabilityBorrow.instruction52_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction52_path0
#print axioms HiaCapabilityBorrow.instruction52_path1
#print axioms HiaCapabilityBorrow.instruction52_path2
#print axioms HiaCapabilityBorrow.instruction52_path3
#print axioms HiaCapabilityBorrow.instruction52_path4
#print axioms HiaCapabilityBorrow.instruction52_ranked_after
#print axioms HiaCapabilityBorrow.instruction52_ranked_before
#print axioms HiaCapabilityBorrow.instruction52_result
#print axioms HiaCapabilityBorrow.instruction52_source_suspended
#print axioms HiaCapabilityBorrow.instruction52_step
#print axioms HiaCapabilityBorrow.instruction52_unique_after
#print axioms HiaCapabilityBorrow.instruction52_unique_before
#print axioms HiaCapabilityBorrow.instruction53_access
#print axioms HiaCapabilityBorrow.instruction53_closed_after
#print axioms HiaCapabilityBorrow.instruction53_closed_before
#print axioms HiaCapabilityBorrow.instruction53_compatible_after
#print axioms HiaCapabilityBorrow.instruction53_compatible_before
#print axioms HiaCapabilityBorrow.instruction53_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction53_path0
#print axioms HiaCapabilityBorrow.instruction53_path1
#print axioms HiaCapabilityBorrow.instruction53_path2
#print axioms HiaCapabilityBorrow.instruction53_path3
#print axioms HiaCapabilityBorrow.instruction53_path4
#print axioms HiaCapabilityBorrow.instruction53_path5
#print axioms HiaCapabilityBorrow.instruction53_path6
#print axioms HiaCapabilityBorrow.instruction53_path7
#print axioms HiaCapabilityBorrow.instruction53_ranked_after
#print axioms HiaCapabilityBorrow.instruction53_ranked_before
#print axioms HiaCapabilityBorrow.instruction53_result
#print axioms HiaCapabilityBorrow.instruction53_step
#print axioms HiaCapabilityBorrow.instruction53_unique_after
#print axioms HiaCapabilityBorrow.instruction53_unique_before
#print axioms HiaCapabilityBorrow.instruction54_closed_after
#print axioms HiaCapabilityBorrow.instruction54_closed_before
#print axioms HiaCapabilityBorrow.instruction54_compatible_after
#print axioms HiaCapabilityBorrow.instruction54_compatible_before
#print axioms HiaCapabilityBorrow.instruction54_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction54_path0
#print axioms HiaCapabilityBorrow.instruction54_path1
#print axioms HiaCapabilityBorrow.instruction54_path2
#print axioms HiaCapabilityBorrow.instruction54_path3
#print axioms HiaCapabilityBorrow.instruction54_path4
#print axioms HiaCapabilityBorrow.instruction54_path5
#print axioms HiaCapabilityBorrow.instruction54_path6
#print axioms HiaCapabilityBorrow.instruction54_path7
#print axioms HiaCapabilityBorrow.instruction54_ranked_after
#print axioms HiaCapabilityBorrow.instruction54_ranked_before
#print axioms HiaCapabilityBorrow.instruction54_result
#print axioms HiaCapabilityBorrow.instruction54_step
#print axioms HiaCapabilityBorrow.instruction54_unique_after
#print axioms HiaCapabilityBorrow.instruction54_unique_before
#print axioms HiaCapabilityBorrow.instruction55_access
#print axioms HiaCapabilityBorrow.instruction55_closed_after
#print axioms HiaCapabilityBorrow.instruction55_closed_before
#print axioms HiaCapabilityBorrow.instruction55_compatible_after
#print axioms HiaCapabilityBorrow.instruction55_compatible_before
#print axioms HiaCapabilityBorrow.instruction55_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction55_path0
#print axioms HiaCapabilityBorrow.instruction55_path1
#print axioms HiaCapabilityBorrow.instruction55_path2
#print axioms HiaCapabilityBorrow.instruction55_path3
#print axioms HiaCapabilityBorrow.instruction55_path4
#print axioms HiaCapabilityBorrow.instruction55_ranked_after
#print axioms HiaCapabilityBorrow.instruction55_ranked_before
#print axioms HiaCapabilityBorrow.instruction55_result
#print axioms HiaCapabilityBorrow.instruction55_step
#print axioms HiaCapabilityBorrow.instruction55_unique_after
#print axioms HiaCapabilityBorrow.instruction55_unique_before
#print axioms HiaCapabilityBorrow.instruction56_closed_after
#print axioms HiaCapabilityBorrow.instruction56_closed_before
#print axioms HiaCapabilityBorrow.instruction56_compatible_after
#print axioms HiaCapabilityBorrow.instruction56_compatible_before
#print axioms HiaCapabilityBorrow.instruction56_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction56_path0
#print axioms HiaCapabilityBorrow.instruction56_path1
#print axioms HiaCapabilityBorrow.instruction56_path2
#print axioms HiaCapabilityBorrow.instruction56_path3
#print axioms HiaCapabilityBorrow.instruction56_path4
#print axioms HiaCapabilityBorrow.instruction56_ranked_after
#print axioms HiaCapabilityBorrow.instruction56_ranked_before
#print axioms HiaCapabilityBorrow.instruction56_result
#print axioms HiaCapabilityBorrow.instruction56_step
#print axioms HiaCapabilityBorrow.instruction56_unique_after
#print axioms HiaCapabilityBorrow.instruction56_unique_before
#print axioms HiaCapabilityBorrow.instruction57_access
#print axioms HiaCapabilityBorrow.instruction57_closed_after
#print axioms HiaCapabilityBorrow.instruction57_closed_before
#print axioms HiaCapabilityBorrow.instruction57_compatible_after
#print axioms HiaCapabilityBorrow.instruction57_compatible_before
#print axioms HiaCapabilityBorrow.instruction57_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction57_path0
#print axioms HiaCapabilityBorrow.instruction57_path1
#print axioms HiaCapabilityBorrow.instruction57_path2
#print axioms HiaCapabilityBorrow.instruction57_ranked_after
#print axioms HiaCapabilityBorrow.instruction57_ranked_before
#print axioms HiaCapabilityBorrow.instruction57_result
#print axioms HiaCapabilityBorrow.instruction57_step
#print axioms HiaCapabilityBorrow.instruction57_unique_after
#print axioms HiaCapabilityBorrow.instruction57_unique_before
#print axioms HiaCapabilityBorrow.instruction58_closed_after
#print axioms HiaCapabilityBorrow.instruction58_closed_before
#print axioms HiaCapabilityBorrow.instruction58_compatible_after
#print axioms HiaCapabilityBorrow.instruction58_compatible_before
#print axioms HiaCapabilityBorrow.instruction58_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction58_path0
#print axioms HiaCapabilityBorrow.instruction58_path1
#print axioms HiaCapabilityBorrow.instruction58_path2
#print axioms HiaCapabilityBorrow.instruction58_ranked_after
#print axioms HiaCapabilityBorrow.instruction58_ranked_before
#print axioms HiaCapabilityBorrow.instruction58_result
#print axioms HiaCapabilityBorrow.instruction58_step
#print axioms HiaCapabilityBorrow.instruction58_unique_after
#print axioms HiaCapabilityBorrow.instruction58_unique_before
#print axioms HiaCapabilityBorrow.instruction59_access
#print axioms HiaCapabilityBorrow.instruction59_closed_after
#print axioms HiaCapabilityBorrow.instruction59_closed_before
#print axioms HiaCapabilityBorrow.instruction59_compatible_after
#print axioms HiaCapabilityBorrow.instruction59_compatible_before
#print axioms HiaCapabilityBorrow.instruction59_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction59_path0
#print axioms HiaCapabilityBorrow.instruction59_ranked_after
#print axioms HiaCapabilityBorrow.instruction59_ranked_before
#print axioms HiaCapabilityBorrow.instruction59_result
#print axioms HiaCapabilityBorrow.instruction59_step
#print axioms HiaCapabilityBorrow.instruction59_unique_after
#print axioms HiaCapabilityBorrow.instruction59_unique_before
#print axioms HiaCapabilityBorrow.instruction5_access
#print axioms HiaCapabilityBorrow.instruction5_closed_after
#print axioms HiaCapabilityBorrow.instruction5_closed_before
#print axioms HiaCapabilityBorrow.instruction5_compatible_after
#print axioms HiaCapabilityBorrow.instruction5_compatible_before
#print axioms HiaCapabilityBorrow.instruction5_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction5_path0
#print axioms HiaCapabilityBorrow.instruction5_ranked_after
#print axioms HiaCapabilityBorrow.instruction5_ranked_before
#print axioms HiaCapabilityBorrow.instruction5_result
#print axioms HiaCapabilityBorrow.instruction5_step
#print axioms HiaCapabilityBorrow.instruction5_unique_after
#print axioms HiaCapabilityBorrow.instruction5_unique_before
#print axioms HiaCapabilityBorrow.instruction60_closed_after
#print axioms HiaCapabilityBorrow.instruction60_closed_before
#print axioms HiaCapabilityBorrow.instruction60_compatible_after
#print axioms HiaCapabilityBorrow.instruction60_compatible_before
#print axioms HiaCapabilityBorrow.instruction60_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction60_path0
#print axioms HiaCapabilityBorrow.instruction60_ranked_after
#print axioms HiaCapabilityBorrow.instruction60_ranked_before
#print axioms HiaCapabilityBorrow.instruction60_result
#print axioms HiaCapabilityBorrow.instruction60_step
#print axioms HiaCapabilityBorrow.instruction60_unique_after
#print axioms HiaCapabilityBorrow.instruction60_unique_before
#print axioms HiaCapabilityBorrow.instruction61_closed_after
#print axioms HiaCapabilityBorrow.instruction61_closed_before
#print axioms HiaCapabilityBorrow.instruction61_compatible_after
#print axioms HiaCapabilityBorrow.instruction61_compatible_before
#print axioms HiaCapabilityBorrow.instruction61_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction61_ranked_after
#print axioms HiaCapabilityBorrow.instruction61_ranked_before
#print axioms HiaCapabilityBorrow.instruction61_result
#print axioms HiaCapabilityBorrow.instruction61_step
#print axioms HiaCapabilityBorrow.instruction61_unique_after
#print axioms HiaCapabilityBorrow.instruction61_unique_before
#print axioms HiaCapabilityBorrow.instruction62_closed_after
#print axioms HiaCapabilityBorrow.instruction62_closed_before
#print axioms HiaCapabilityBorrow.instruction62_compatible_after
#print axioms HiaCapabilityBorrow.instruction62_compatible_before
#print axioms HiaCapabilityBorrow.instruction62_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction62_ranked_after
#print axioms HiaCapabilityBorrow.instruction62_ranked_before
#print axioms HiaCapabilityBorrow.instruction62_result
#print axioms HiaCapabilityBorrow.instruction62_step
#print axioms HiaCapabilityBorrow.instruction62_unique_after
#print axioms HiaCapabilityBorrow.instruction62_unique_before
#print axioms HiaCapabilityBorrow.instruction63_borrow_guard
#print axioms HiaCapabilityBorrow.instruction63_closed_after
#print axioms HiaCapabilityBorrow.instruction63_closed_before
#print axioms HiaCapabilityBorrow.instruction63_compatible_after
#print axioms HiaCapabilityBorrow.instruction63_compatible_before
#print axioms HiaCapabilityBorrow.instruction63_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction63_ranked_after
#print axioms HiaCapabilityBorrow.instruction63_ranked_before
#print axioms HiaCapabilityBorrow.instruction63_result
#print axioms HiaCapabilityBorrow.instruction63_source_suspended
#print axioms HiaCapabilityBorrow.instruction63_step
#print axioms HiaCapabilityBorrow.instruction63_unique_after
#print axioms HiaCapabilityBorrow.instruction63_unique_before
#print axioms HiaCapabilityBorrow.instruction64_borrow_guard
#print axioms HiaCapabilityBorrow.instruction64_closed_after
#print axioms HiaCapabilityBorrow.instruction64_closed_before
#print axioms HiaCapabilityBorrow.instruction64_compatible_after
#print axioms HiaCapabilityBorrow.instruction64_compatible_before
#print axioms HiaCapabilityBorrow.instruction64_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction64_path0
#print axioms HiaCapabilityBorrow.instruction64_ranked_after
#print axioms HiaCapabilityBorrow.instruction64_ranked_before
#print axioms HiaCapabilityBorrow.instruction64_result
#print axioms HiaCapabilityBorrow.instruction64_source_suspended
#print axioms HiaCapabilityBorrow.instruction64_step
#print axioms HiaCapabilityBorrow.instruction64_unique_after
#print axioms HiaCapabilityBorrow.instruction64_unique_before
#print axioms HiaCapabilityBorrow.instruction65_access
#print axioms HiaCapabilityBorrow.instruction65_closed_after
#print axioms HiaCapabilityBorrow.instruction65_closed_before
#print axioms HiaCapabilityBorrow.instruction65_compatible_after
#print axioms HiaCapabilityBorrow.instruction65_compatible_before
#print axioms HiaCapabilityBorrow.instruction65_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction65_path0
#print axioms HiaCapabilityBorrow.instruction65_path1
#print axioms HiaCapabilityBorrow.instruction65_path2
#print axioms HiaCapabilityBorrow.instruction65_ranked_after
#print axioms HiaCapabilityBorrow.instruction65_ranked_before
#print axioms HiaCapabilityBorrow.instruction65_result
#print axioms HiaCapabilityBorrow.instruction65_step
#print axioms HiaCapabilityBorrow.instruction65_unique_after
#print axioms HiaCapabilityBorrow.instruction65_unique_before
#print axioms HiaCapabilityBorrow.instruction66_borrow_guard
#print axioms HiaCapabilityBorrow.instruction66_closed_after
#print axioms HiaCapabilityBorrow.instruction66_closed_before
#print axioms HiaCapabilityBorrow.instruction66_compatible_after
#print axioms HiaCapabilityBorrow.instruction66_compatible_before
#print axioms HiaCapabilityBorrow.instruction66_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction66_path0
#print axioms HiaCapabilityBorrow.instruction66_path1
#print axioms HiaCapabilityBorrow.instruction66_path2
#print axioms HiaCapabilityBorrow.instruction66_ranked_after
#print axioms HiaCapabilityBorrow.instruction66_ranked_before
#print axioms HiaCapabilityBorrow.instruction66_result
#print axioms HiaCapabilityBorrow.instruction66_source_suspended
#print axioms HiaCapabilityBorrow.instruction66_step
#print axioms HiaCapabilityBorrow.instruction66_unique_after
#print axioms HiaCapabilityBorrow.instruction66_unique_before
#print axioms HiaCapabilityBorrow.instruction67_access
#print axioms HiaCapabilityBorrow.instruction67_closed_after
#print axioms HiaCapabilityBorrow.instruction67_closed_before
#print axioms HiaCapabilityBorrow.instruction67_compatible_after
#print axioms HiaCapabilityBorrow.instruction67_compatible_before
#print axioms HiaCapabilityBorrow.instruction67_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction67_path0
#print axioms HiaCapabilityBorrow.instruction67_path1
#print axioms HiaCapabilityBorrow.instruction67_path2
#print axioms HiaCapabilityBorrow.instruction67_path3
#print axioms HiaCapabilityBorrow.instruction67_path4
#print axioms HiaCapabilityBorrow.instruction67_path5
#print axioms HiaCapabilityBorrow.instruction67_ranked_after
#print axioms HiaCapabilityBorrow.instruction67_ranked_before
#print axioms HiaCapabilityBorrow.instruction67_result
#print axioms HiaCapabilityBorrow.instruction67_step
#print axioms HiaCapabilityBorrow.instruction67_unique_after
#print axioms HiaCapabilityBorrow.instruction67_unique_before
#print axioms HiaCapabilityBorrow.instruction68_closed_after
#print axioms HiaCapabilityBorrow.instruction68_closed_before
#print axioms HiaCapabilityBorrow.instruction68_compatible_after
#print axioms HiaCapabilityBorrow.instruction68_compatible_before
#print axioms HiaCapabilityBorrow.instruction68_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction68_path0
#print axioms HiaCapabilityBorrow.instruction68_path1
#print axioms HiaCapabilityBorrow.instruction68_path2
#print axioms HiaCapabilityBorrow.instruction68_path3
#print axioms HiaCapabilityBorrow.instruction68_path4
#print axioms HiaCapabilityBorrow.instruction68_path5
#print axioms HiaCapabilityBorrow.instruction68_ranked_after
#print axioms HiaCapabilityBorrow.instruction68_ranked_before
#print axioms HiaCapabilityBorrow.instruction68_result
#print axioms HiaCapabilityBorrow.instruction68_step
#print axioms HiaCapabilityBorrow.instruction68_unique_after
#print axioms HiaCapabilityBorrow.instruction68_unique_before
#print axioms HiaCapabilityBorrow.instruction69_access
#print axioms HiaCapabilityBorrow.instruction69_closed_after
#print axioms HiaCapabilityBorrow.instruction69_closed_before
#print axioms HiaCapabilityBorrow.instruction69_compatible_after
#print axioms HiaCapabilityBorrow.instruction69_compatible_before
#print axioms HiaCapabilityBorrow.instruction69_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction69_path0
#print axioms HiaCapabilityBorrow.instruction69_path1
#print axioms HiaCapabilityBorrow.instruction69_path2
#print axioms HiaCapabilityBorrow.instruction69_ranked_after
#print axioms HiaCapabilityBorrow.instruction69_ranked_before
#print axioms HiaCapabilityBorrow.instruction69_result
#print axioms HiaCapabilityBorrow.instruction69_step
#print axioms HiaCapabilityBorrow.instruction69_unique_after
#print axioms HiaCapabilityBorrow.instruction69_unique_before
#print axioms HiaCapabilityBorrow.instruction6_closed_after
#print axioms HiaCapabilityBorrow.instruction6_closed_before
#print axioms HiaCapabilityBorrow.instruction6_compatible_after
#print axioms HiaCapabilityBorrow.instruction6_compatible_before
#print axioms HiaCapabilityBorrow.instruction6_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction6_path0
#print axioms HiaCapabilityBorrow.instruction6_ranked_after
#print axioms HiaCapabilityBorrow.instruction6_ranked_before
#print axioms HiaCapabilityBorrow.instruction6_result
#print axioms HiaCapabilityBorrow.instruction6_step
#print axioms HiaCapabilityBorrow.instruction6_unique_after
#print axioms HiaCapabilityBorrow.instruction6_unique_before
#print axioms HiaCapabilityBorrow.instruction70_closed_after
#print axioms HiaCapabilityBorrow.instruction70_closed_before
#print axioms HiaCapabilityBorrow.instruction70_compatible_after
#print axioms HiaCapabilityBorrow.instruction70_compatible_before
#print axioms HiaCapabilityBorrow.instruction70_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction70_path0
#print axioms HiaCapabilityBorrow.instruction70_path1
#print axioms HiaCapabilityBorrow.instruction70_path2
#print axioms HiaCapabilityBorrow.instruction70_ranked_after
#print axioms HiaCapabilityBorrow.instruction70_ranked_before
#print axioms HiaCapabilityBorrow.instruction70_result
#print axioms HiaCapabilityBorrow.instruction70_step
#print axioms HiaCapabilityBorrow.instruction70_unique_after
#print axioms HiaCapabilityBorrow.instruction70_unique_before
#print axioms HiaCapabilityBorrow.instruction71_access
#print axioms HiaCapabilityBorrow.instruction71_closed_after
#print axioms HiaCapabilityBorrow.instruction71_closed_before
#print axioms HiaCapabilityBorrow.instruction71_compatible_after
#print axioms HiaCapabilityBorrow.instruction71_compatible_before
#print axioms HiaCapabilityBorrow.instruction71_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction71_path0
#print axioms HiaCapabilityBorrow.instruction71_ranked_after
#print axioms HiaCapabilityBorrow.instruction71_ranked_before
#print axioms HiaCapabilityBorrow.instruction71_result
#print axioms HiaCapabilityBorrow.instruction71_step
#print axioms HiaCapabilityBorrow.instruction71_unique_after
#print axioms HiaCapabilityBorrow.instruction71_unique_before
#print axioms HiaCapabilityBorrow.instruction72_closed_after
#print axioms HiaCapabilityBorrow.instruction72_closed_before
#print axioms HiaCapabilityBorrow.instruction72_compatible_after
#print axioms HiaCapabilityBorrow.instruction72_compatible_before
#print axioms HiaCapabilityBorrow.instruction72_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction72_path0
#print axioms HiaCapabilityBorrow.instruction72_ranked_after
#print axioms HiaCapabilityBorrow.instruction72_ranked_before
#print axioms HiaCapabilityBorrow.instruction72_result
#print axioms HiaCapabilityBorrow.instruction72_step
#print axioms HiaCapabilityBorrow.instruction72_unique_after
#print axioms HiaCapabilityBorrow.instruction72_unique_before
#print axioms HiaCapabilityBorrow.instruction73_closed_after
#print axioms HiaCapabilityBorrow.instruction73_closed_before
#print axioms HiaCapabilityBorrow.instruction73_compatible_after
#print axioms HiaCapabilityBorrow.instruction73_compatible_before
#print axioms HiaCapabilityBorrow.instruction73_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction73_ranked_after
#print axioms HiaCapabilityBorrow.instruction73_ranked_before
#print axioms HiaCapabilityBorrow.instruction73_result
#print axioms HiaCapabilityBorrow.instruction73_step
#print axioms HiaCapabilityBorrow.instruction73_unique_after
#print axioms HiaCapabilityBorrow.instruction73_unique_before
#print axioms HiaCapabilityBorrow.instruction7_borrow_guard
#print axioms HiaCapabilityBorrow.instruction7_closed_after
#print axioms HiaCapabilityBorrow.instruction7_closed_before
#print axioms HiaCapabilityBorrow.instruction7_compatible_after
#print axioms HiaCapabilityBorrow.instruction7_compatible_before
#print axioms HiaCapabilityBorrow.instruction7_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction7_ranked_after
#print axioms HiaCapabilityBorrow.instruction7_ranked_before
#print axioms HiaCapabilityBorrow.instruction7_result
#print axioms HiaCapabilityBorrow.instruction7_source_suspended
#print axioms HiaCapabilityBorrow.instruction7_step
#print axioms HiaCapabilityBorrow.instruction7_unique_after
#print axioms HiaCapabilityBorrow.instruction7_unique_before
#print axioms HiaCapabilityBorrow.instruction8_access
#print axioms HiaCapabilityBorrow.instruction8_closed_after
#print axioms HiaCapabilityBorrow.instruction8_closed_before
#print axioms HiaCapabilityBorrow.instruction8_compatible_after
#print axioms HiaCapabilityBorrow.instruction8_compatible_before
#print axioms HiaCapabilityBorrow.instruction8_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction8_path0
#print axioms HiaCapabilityBorrow.instruction8_ranked_after
#print axioms HiaCapabilityBorrow.instruction8_ranked_before
#print axioms HiaCapabilityBorrow.instruction8_result
#print axioms HiaCapabilityBorrow.instruction8_step
#print axioms HiaCapabilityBorrow.instruction8_unique_after
#print axioms HiaCapabilityBorrow.instruction8_unique_before
#print axioms HiaCapabilityBorrow.instruction9_closed_after
#print axioms HiaCapabilityBorrow.instruction9_closed_before
#print axioms HiaCapabilityBorrow.instruction9_compatible_after
#print axioms HiaCapabilityBorrow.instruction9_compatible_before
#print axioms HiaCapabilityBorrow.instruction9_no_parent_cycle
#print axioms HiaCapabilityBorrow.instruction9_path0
#print axioms HiaCapabilityBorrow.instruction9_ranked_after
#print axioms HiaCapabilityBorrow.instruction9_ranked_before
#print axioms HiaCapabilityBorrow.instruction9_result
#print axioms HiaCapabilityBorrow.instruction9_step
#print axioms HiaCapabilityBorrow.instruction9_unique_after
#print axioms HiaCapabilityBorrow.instruction9_unique_before
#print axioms HiaCapabilityBorrow.loan_ancestor_path
#print axioms HiaCapabilityBorrow.path_endpoints
#print axioms HiaCapabilityBorrow.path_last_child
#print axioms HiaCapabilityBorrow.path_mono
#print axioms HiaCapabilityBorrow.path_rename
#print axioms HiaCapabilityBorrow.path_retained
#print axioms HiaCapabilityBorrow.step_closed
#print axioms HiaCapabilityBorrow.step_compatible
#print axioms HiaCapabilityBorrow.step_ranked
#print axioms HiaCapabilityBorrow.step_structural
#print axioms HiaCapabilityBorrow.step_unique
#print axioms HiaCapabilityBorrow.trace_accessible_exclusive
#print axioms HiaCapabilityBorrow.trace_closed
#print axioms HiaCapabilityBorrow.trace_compatible
#print axioms HiaCapabilityBorrow.trace_no_parent_cycle
#print axioms HiaCapabilityBorrow.trace_ranked
#print axioms HiaCapabilityBorrow.trace_unique
#print axioms HiaCapabilityBorrow.transfer_compatible
#print axioms HiaCapabilityBorrow.unique_same_name
#print axioms HiaCapabilityLifecycle.erase_closed
#print axioms HiaCapabilityLifecycle.erase_ranked
#print axioms HiaCapabilityLifecycle.erase_unique
#print axioms HiaCapabilityLifecycle.erased_member
#print axioms HiaCapabilityLifecycle.extend_rank_old
#print axioms HiaCapabilityLifecycle.fresh_cons_unique
#print axioms HiaCapabilityLifecycle.fresh_not_member
#print axioms HiaCapabilityLifecycle.fresh_parent_absent
#print axioms HiaCapabilityLifecycle.loan_closed
#print axioms HiaCapabilityLifecycle.loan_ranked
#print axioms HiaCapabilityLifecycle.owner_closed
#print axioms HiaCapabilityLifecycle.owner_ranked
#print axioms HiaCapabilityLifecycle.step_closed
#print axioms HiaCapabilityLifecycle.step_ranked
#print axioms HiaCapabilityLifecycle.step_unique
#print axioms HiaCapabilityLifecycle.trace_closed
#print axioms HiaCapabilityLifecycle.trace_no_parent_cycle
#print axioms HiaCapabilityLifecycle.trace_ranked
#print axioms HiaCapabilityLifecycle.trace_unique
#print axioms HiaCapabilityLifecycle.transfer_unique
#print axioms HiaCapabilityLifecycle.unique_projection
#print axioms HiaCapabilityLifecycle.unique_rename
#print axioms HiaCapabilityRenaming.child_of_iff
#print axioms HiaCapabilityRenaming.closed_preserved
#print axioms HiaCapabilityRenaming.exclusive_alias_iff
#print axioms HiaCapabilityRenaming.external_preserved
#print axioms HiaCapabilityRenaming.identity_rename
#print axioms HiaCapabilityRenaming.kind_preserved
#print axioms HiaCapabilityRenaming.local_inventory_projection
#print axioms HiaCapabilityRenaming.local_inventory_rename
#print axioms HiaCapabilityRenaming.local_retained
#print axioms HiaCapabilityRenaming.name_equal_iff
#print axioms HiaCapabilityRenaming.name_preserved
#print axioms HiaCapabilityRenaming.number_preserved
#print axioms HiaCapabilityRenaming.only_external_forgotten
#print axioms HiaCapabilityRenaming.origin_preserved
#print axioms HiaCapabilityRenaming.parent_map_iff
#print axioms HiaCapabilityRenaming.parent_path_descends
#print axioms HiaCapabilityRenaming.projected_member
#print axioms HiaCapabilityRenaming.ranked_no_parent_cycle
#print axioms HiaCapabilityRenaming.ranked_projection
#print axioms HiaCapabilityRenaming.ranked_rename
#print axioms HiaCapabilityRenaming.rename_composes
#print axioms HiaCapabilityRenaming.root_equal_iff
#print axioms HiaCapabilityRenaming.suspended_iff
#print axioms HiaCapabilityRenaming.trace_closed
#print axioms HiaCapabilityRenaming.trace_local_inventory
#print axioms HiaCapabilityRenaming.trace_no_parent_cycle
#print axioms HiaCapabilityRenaming.trace_ranked
#print axioms HiaCapabilityRenaming.transfer_closed
#print axioms HiaCapabilityRenaming.transfer_local_inventory
#print axioms HiaCapabilityRenaming.transfer_ranked
#print axioms HiaCapabilityRenaming.transported_rank_at
