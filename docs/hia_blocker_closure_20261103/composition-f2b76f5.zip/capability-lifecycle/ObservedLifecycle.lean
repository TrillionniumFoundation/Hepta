/-
Sequential Core capability-flow specification. Names are mathematical
naturals; kinds and origins are uninterpreted tags. This proves facts for
ALL finite capability lists and injective maps, without an execution-length
bound. It is not a proof of every instruction, Python, LLVM, FFI, or hardware.
Projection may forget only external capabilities and must keep the selected
graph closed. The trace theorems below compose these edge rules for every
finite trace; they do not model the intervening instructions in a CFG block.
-/
import Lean.Elab.Tactic.Omega

namespace HiaCapabilityRenaming

structure Capability where
  name : Nat
  root : Nat
  parent : Option Nat
  kind : Nat
  external : Bool
  origin : Option Nat
  deriving DecidableEq

def Injective (f : Nat → Nat) : Prop := ∀ a b, f a = f b → a = b

def rename (f : Nat → Nat) (c : Capability) : Capability :=
  { name := f c.name, root := f c.root, parent := c.parent.map f,
    kind := c.kind, external := c.external, origin := c.origin }

def ChildOf (child parent : Capability) : Prop := child.parent = some parent.name

def ExclusiveAlias (mutableKind : Nat) (a b : Capability) : Prop :=
  a.name ≠ b.name ∧ a.root = b.root ∧ (a.kind = mutableKind ∨ b.kind = mutableKind)

def Closed (caps : List Capability) : Prop :=
  ∀ c ∈ caps, (∃ root ∈ caps, root.name = c.root) ∧
    (∀ p, c.parent = some p → ∃ parent ∈ caps, parent.name = p)

theorem name_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).name = f c.name := rfl

theorem kind_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).kind = c.kind := rfl

theorem external_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).external = c.external := rfl

theorem origin_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).origin = c.origin := rfl

theorem name_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).name = (rename f b).name ↔ a.name = b.name := by
  constructor
  · exact inj a.name b.name
  · intro h; exact congrArg f h

theorem root_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).root = (rename f b).root ↔ a.root = b.root := by
  constructor
  · exact inj a.root b.root
  · intro h; exact congrArg f h

theorem parent_map_iff (f : Nat → Nat) (inj : Injective f) (p : Option Nat) (n : Nat) :
    p.map f = some (f n) ↔ p = some n := by
  cases p with
  | none => simp
  | some p =>
      constructor
      · intro h; exact congrArg some (inj p n (Option.some.inj h))
      · intro h; cases h; rfl

theorem child_of_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    ChildOf (rename f a) (rename f b) ↔ ChildOf a b := by
  exact parent_map_iff f inj a.parent b.name

theorem exclusive_alias_iff (f : Nat → Nat) (inj : Injective f)
    (mutableKind : Nat) (a b : Capability) :
    ExclusiveAlias mutableKind (rename f a) (rename f b) ↔
      ExclusiveAlias mutableKind a b := by
  simp only [ExclusiveAlias, ne_eq, name_equal_iff f inj,
             root_equal_iff f inj, kind_preserved]

theorem suspended_iff (f : Nat → Nat) (inj : Injective f)
    (caps : List Capability) (c : Capability) :
    (∃ child ∈ caps.map (rename f), ChildOf child (rename f c)) ↔
      (∃ child ∈ caps, ChildOf child c) := by
  constructor
  · rintro ⟨child, member, relation⟩
    obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
    exact ⟨old, oldMember, (child_of_iff f inj old c).mp relation⟩
  · rintro ⟨child, member, relation⟩
    exact ⟨rename f child, List.mem_map.mpr ⟨child, member, rfl⟩,
      (child_of_iff f inj child c).mpr relation⟩

theorem closed_preserved (f : Nat → Nat) (caps : List Capability)
    (closed : Closed caps) : Closed (caps.map (rename f)) := by
  intro c member
  obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
  obtain ⟨rootExists, parentExists⟩ := closed old oldMember
  obtain ⟨root, rootMember, rootName⟩ := rootExists
  constructor
  · exact ⟨rename f root, List.mem_map.mpr ⟨root, rootMember, rfl⟩,
      congrArg f rootName⟩
  · intro p relation
    cases hp : old.parent with
    | none => simp [rename, hp] at relation
    | some oldParent =>
        have mapped : f oldParent = p := by simpa [rename, hp] using relation
        obtain ⟨parent, parentMember, parentName⟩ := parentExists oldParent hp
        exact ⟨rename f parent, List.mem_map.mpr ⟨parent, parentMember, rfl⟩,
          (congrArg f parentName).trans mapped⟩

theorem number_preserved (f : Nat → Nat) (caps : List Capability) :
    (caps.map (rename f)).length = caps.length := by simp

theorem rename_composes (f g : Nat → Nat) (c : Capability) :
    rename g (rename f c) = rename (fun n => g (f n)) c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

theorem identity_rename (c : Capability) : rename (fun n => n) c = c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

/- The executable helper selects a subset before renaming. Selection is a
filter, so it cannot invent or duplicate capabilities. The explicit retention
premise is exactly the helper's rule for local owners and local loans. -/

def project (keep : Nat → Bool) (caps : List Capability) : List Capability :=
  caps.filter (fun c => keep c.name)

def AdmissibleProjection (caps : List Capability) (keep : Nat → Bool) : Prop :=
  (∀ c ∈ caps, c.external = false → keep c.name = true) ∧ Closed (project keep caps)

def localInventory : List Capability → List (Nat × Option Nat)
  | [] => []
  | c :: rest =>
      if c.external then localInventory rest else (c.kind, c.origin) :: localInventory rest

theorem projected_member (caps : List Capability) (keep : Nat → Bool) (c : Capability) :
    c ∈ project keep caps ↔ c ∈ caps ∧ keep c.name = true := by
  simp [project]

theorem local_retained (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (localCap : c.external = false) : c ∈ project keep caps := by
  exact (projected_member caps keep c).mpr ⟨member, admitted.1 c member localCap⟩

theorem only_external_forgotten (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (forgotten : c ∉ project keep caps) : c.external = true := by
  cases external : c.external with
  | false => exact False.elim (forgotten (local_retained caps keep admitted c member external))
  | true => rfl

theorem local_inventory_projection (caps : List Capability) (keep : Nat → Bool)
    (retained : ∀ c ∈ caps, c.external = false → keep c.name = true) :
    localInventory (project keep caps) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih =>
      have restRetained : ∀ x ∈ rest, x.external = false → keep x.name = true := by
        intro x member external
        exact retained x (List.mem_cons_of_mem c member) external
      have tail := ih restRetained
      cases external : c.external with
      | false =>
          have kept := retained c (by simp) external
          simp [project, localInventory, external, kept] at tail ⊢
          exact tail
      | true =>
          cases kept : keep c.name <;> simp [project, localInventory, external, kept] at tail ⊢
          all_goals exact tail

theorem local_inventory_rename (caps : List Capability) (f : Nat → Nat) :
    localInventory (caps.map (rename f)) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih => simp [localInventory, rename, ih]

/- Parent ranks are witnesses for strict descent, not runtime addresses or
integer counters. Their existence excludes every positive parent cycle. -/

def ParentRanks (caps : List Capability) (rank : Nat → Nat) : Prop :=
  ∀ child ∈ caps, ∀ parent ∈ caps, ChildOf child parent → rank parent.name < rank child.name

def Ranked (caps : List Capability) : Prop := ∃ rank, ParentRanks caps rank

inductive ParentPath (caps : List Capability) : Nat → Nat → Prop where
  | edge {child parent} : child ∈ caps → parent ∈ caps → ChildOf child parent →
      ParentPath caps child.name parent.name
  | trans {a b c} : ParentPath caps a b → ParentPath caps b c → ParentPath caps a c

theorem parent_path_descends (caps : List Capability) (rank : Nat → Nat)
    (ranked : ParentRanks caps rank) {a b : Nat} (path : ParentPath caps a b) :
    rank b < rank a := by
  induction path with
  | edge childMember parentMember relation => exact ranked _ childMember _ parentMember relation
  | trans _ _ left right => exact Nat.lt_trans right left

theorem ranked_no_parent_cycle (caps : List Capability) (ranked : Ranked caps) (name : Nat) :
    ¬ ParentPath caps name name := by
  intro path
  obtain ⟨rank, ordered⟩ := ranked
  exact (Nat.lt_irrefl (rank name)) (parent_path_descends caps rank ordered path)

theorem ranked_projection (caps : List Capability) (keep : Nat → Bool)
    (ranked : Ranked caps) : Ranked (project keep caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((projected_member caps keep child).mp childMember).1
    parent ((projected_member caps keep parent).mp parentMember).1 relation

noncomputable def transportedRank (f rank : Nat → Nat) (name : Nat) : Nat := by
  classical
  exact if witness : ∃ before, f before = name then rank (Classical.choose witness) else 0

theorem transported_rank_at (f rank : Nat → Nat) (inj : Injective f) (name : Nat) :
    transportedRank f rank (f name) = rank name := by
  unfold transportedRank
  split
  next witness =>
    have same : Classical.choose witness = name := inj _ _ (Classical.choose_spec witness)
    rw [same]
  next absent => exact False.elim (absent ⟨name, rfl⟩)

theorem ranked_rename (caps : List Capability) (f : Nat → Nat)
    (inj : Injective f) (ranked : Ranked caps) : Ranked (caps.map (rename f)) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨transportedRank f rank, ?_⟩
  intro child childMember parent parentMember relation
  obtain ⟨oldChild, oldChildMember, rfl⟩ := List.mem_map.mp childMember
  obtain ⟨oldParent, oldParentMember, rfl⟩ := List.mem_map.mp parentMember
  have oldRelation := (child_of_iff f inj oldChild oldParent).mp relation
  simpa only [name_preserved, transported_rank_at f rank inj] using
    ordered oldChild oldChildMember oldParent oldParentMember oldRelation

def Transfer (before after : List Capability) : Prop :=
  ∃ keep f, AdmissibleProjection before keep ∧ Injective f ∧
    after = (project keep before).map (rename f)

theorem transfer_closed {before after : List Capability} (step : Transfer before after) :
    Closed after := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  exact closed_preserved f (project keep before) admitted.2

theorem transfer_local_inventory {before after : List Capability} (step : Transfer before after) :
    localInventory after = localInventory before := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  rw [local_inventory_rename, local_inventory_projection before keep admitted.1]

theorem transfer_ranked {before after : List Capability} (step : Transfer before after)
    (ranked : Ranked before) : Ranked after := by
  obtain ⟨keep, f, _, inj, rfl⟩ := step
  exact ranked_rename (project keep before) f inj (ranked_projection before keep ranked)

inductive EdgeTrace : List Capability → List Capability → Prop where
  | refl (caps) : EdgeTrace caps caps
  | next {before middle after} : EdgeTrace before middle → Transfer middle after →
      EdgeTrace before after

theorem trace_local_inventory {before after : List Capability} (trace : EdgeTrace before after) :
    localInventory after = localInventory before := by
  induction trace with
  | refl => rfl
  | next _ step ih => exact (transfer_local_inventory step).trans ih

theorem trace_closed {before after : List Capability} (trace : EdgeTrace before after)
    (closed : Closed before) : Closed after := by
  cases trace with
  | refl => exact closed
  | next _ step => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | next _ step ih => exact transfer_ranked step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace ranked) name

end HiaCapabilityRenaming

/-
Structural preservation for allocation, borrowing and release. This model
concerns capability graphs, not heap execution or the production checker.
It does not prove alias exclusivity, FFI, calls or concurrent memory safety.
-/

namespace HiaCapabilityLifecycle
open HiaCapabilityRenaming

def Fresh (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name

def Unique (caps : List Capability) : Prop := (caps.map Capability.name).Nodup

def owner (name kind : Nat) : Capability :=
  ⟨name, name, none, kind, false, none⟩

def loan (source : Capability) (name kind : Nat) : Capability :=
  ⟨name, source.root, some source.name, kind, false, source.origin⟩

def erase (name : Nat) (caps : List Capability) : List Capability :=
  caps.filter (fun c => c.name != name)

def Unreferenced (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name → c.root ≠ name ∧ c.parent ≠ some name

def extendRank (rank : Nat → Nat) (name value : Nat) (n : Nat) : Nat :=
  if n = name then value else rank n

theorem fresh_not_member (caps : List Capability) (name : Nat)
    (fresh : Fresh caps name) (c : Capability) (same : c.name = name) : c ∉ caps := by
  intro member
  exact fresh c member same

theorem fresh_parent_absent (caps : List Capability) (name : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    c.parent ≠ some name := by
  intro relation
  obtain ⟨parent, parentMember, parentName⟩ := (closed c member).2 name relation
  exact fresh parent parentMember parentName

theorem extend_rank_old (caps : List Capability) (rank : Nat → Nat) (name value : Nat)
    (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    extendRank rank name value c.name = rank c.name := by
  simp [extendRank, fresh c member]

theorem fresh_cons_unique (caps : List Capability) (c : Capability)
    (unique : Unique caps) (fresh : Fresh caps c.name) : Unique (c :: caps) := by
  simp only [Unique, List.map_cons, List.nodup_cons]
  refine ⟨?_, unique⟩
  intro member
  obtain ⟨old, oldMember, same⟩ := List.mem_map.mp member
  exact fresh old oldMember same

theorem owner_closed (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) : Closed (owner name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · exact ⟨owner name kind, by simp, rfl⟩
    · intro p relation
      simp [owner] at relation
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem loan_closed (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (sourceMember : source ∈ caps) :
    Closed (loan source name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := (closed source sourceMember).1
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      have same : source.name = p := Option.some.inj relation
      exact ⟨source, List.mem_cons_of_mem _ sourceMember, same⟩
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem owner_ranked (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (ranked : Ranked caps) :
    Ranked (owner name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name 0, ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    simp [ChildOf, owner] at relation
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name 0 fresh child childOld,
                  extend_rank_old caps rank name 0 fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem loan_ranked (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (sourceMember : source ∈ caps)
    (ranked : Ranked caps) : Ranked (loan source name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name (rank source.name + 1), ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    have same : source.name = parent.name := Option.some.inj relation
    rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh source sourceMember same)
    · simp only [loan, extendRank, if_pos rfl]
      rw [← same]
      simp [extendRank, fresh source sourceMember]
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name (rank source.name + 1) fresh child childOld,
                  extend_rank_old caps rank name (rank source.name + 1) fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem erased_member (caps : List Capability) (name : Nat) (c : Capability) :
    c ∈ erase name caps ↔ c ∈ caps ∧ c.name ≠ name := by
  simp [erase]

theorem erase_closed (caps : List Capability) (name : Nat)
    (closed : Closed caps) (free : Unreferenced caps name) : Closed (erase name caps) := by
  intro c member
  obtain ⟨oldMember, notName⟩ := (erased_member caps name c).mp member
  obtain ⟨rootExists, parentExists⟩ := closed c oldMember
  constructor
  · obtain ⟨root, rootMember, rootName⟩ := rootExists
    have retained : root.name ≠ name := by
      intro same
      exact (free c oldMember notName).1 (rootName.symm.trans same)
    exact ⟨root, (erased_member caps name root).mpr ⟨rootMember, retained⟩, rootName⟩
  · intro p relation
    obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
    have retained : parent.name ≠ name := by
      intro same
      have pName : p = name := parentName.symm.trans same
      exact (free c oldMember notName).2 (relation.trans (congrArg some pName))
    exact ⟨parent, (erased_member caps name parent).mpr ⟨parentMember, retained⟩, parentName⟩

theorem erase_ranked (caps : List Capability) (name : Nat) (ranked : Ranked caps) :
    Ranked (erase name caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((erased_member caps name child).mp childMember).1
    parent ((erased_member caps name parent).mp parentMember).1 relation

theorem erase_unique (caps : List Capability) (name : Nat) (unique : Unique caps) :
    Unique (erase name caps) := by
  have subset : (erase name caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

/- This is a closed structural slice, not the complete borrow checker.
The borrow rules retain root/origin and prohibit shared-to-mutable escalation.
The separate production checker enforces conflicting alias exclusions. -/
inductive Step : List Capability → List Capability → Prop where
  | allocate {caps name kind} : Fresh caps name → (kind = 0 ∨ kind = 1) →
      Step caps (owner name kind :: caps)
  | borrowRead {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 2 ∨ source.kind = 3) →
      Step caps (loan source name 2 :: caps)
  | borrowMut {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 3) →
      Step caps (loan source name 3 :: caps)
  | endLoan {caps c} : c ∈ caps → c.external = false →
      (c.kind = 2 ∨ c.kind = 3) → Unreferenced caps c.name →
      Step caps (erase c.name caps)
  | dropOwner {caps c} : c ∈ caps → c.external = false →
      (c.kind = 0 ∨ c.kind = 1) → c.root = c.name → c.parent = none →
      Unreferenced caps c.name → Step caps (erase c.name caps)

theorem step_closed {before after : List Capability} (step : Step before after)
    (closed : Closed before) : Closed after := by
  cases step with
  | allocate fresh kind => exact owner_closed _ _ _ closed
  | borrowRead sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | borrowMut sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | endLoan member localCap kind free => exact erase_closed _ _ closed free
  | dropOwner member localCap kind root parent free => exact erase_closed _ _ closed free

theorem step_ranked {before after : List Capability} (step : Step before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  cases step with
  | allocate fresh kind => exact owner_ranked _ _ _ closed fresh ranked
  | borrowRead sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | borrowMut sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | endLoan member localCap kind free => exact erase_ranked _ _ ranked
  | dropOwner member localCap kind root parent free => exact erase_ranked _ _ ranked

theorem step_unique {before after : List Capability} (step : Step before after)
    (unique : Unique before) : Unique after := by
  cases step with
  | allocate fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowRead sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowMut sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | endLoan member localCap kind free => exact erase_unique _ _ unique
  | dropOwner member localCap kind root parent free => exact erase_unique _ _ unique

theorem unique_projection (caps : List Capability) (keep : Nat → Bool)
    (unique : Unique caps) : Unique (project keep caps) := by
  have subset : (project keep caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

theorem unique_rename (caps : List Capability) (f : Nat → Nat) (inj : Injective f)
    (unique : Unique caps) : Unique (caps.map (rename f)) := by
  induction caps with
  | nil => simp [Unique]
  | cons c rest ih =>
      have old : c.name ∉ rest.map Capability.name ∧ Unique rest := by
        simpa only [Unique, List.map_cons, List.nodup_cons] using unique
      simp only [List.map_cons, Unique, List.nodup_cons]
      refine ⟨?_, ih old.2⟩
      intro member
      obtain ⟨renamed, renamedMember, same⟩ := List.mem_map.mp member
      obtain ⟨original, originalMember, rfl⟩ := List.mem_map.mp renamedMember
      have originalName : original.name = c.name := inj _ _ same
      exact old.1 (List.mem_map.mpr ⟨original, originalMember, originalName⟩)

theorem transfer_unique {before after : List Capability} (step : Transfer before after)
    (unique : Unique before) : Unique after := by
  obtain ⟨keep, f, admitted, inj, rfl⟩ := step
  exact unique_rename _ f inj (unique_projection before keep unique)

inductive Trace : List Capability → List Capability → Prop where
  | refl (caps) : Trace caps caps
  | instruction {before middle after} : Trace before middle → Step middle after → Trace before after
  | edge {before middle after} : Trace before middle → Transfer middle after → Trace before after

theorem trace_closed {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) : Closed after := by
  induction trace with
  | refl => exact closed
  | instruction _ step ih => exact step_closed step ih
  | edge _ step ih => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | instruction earlier step ih => exact step_ranked step (trace_closed earlier closed) ih
  | edge _ step ih => exact transfer_ranked step ih

theorem trace_unique {before after : List Capability} (trace : Trace before after)
    (unique : Unique before) : Unique after := by
  induction trace with
  | refl => exact unique
  | instruction _ step ih => exact step_unique step ih
  | edge _ step ih => exact transfer_unique step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) (name : Nat) :
    ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace closed ranked) name

end HiaCapabilityLifecycle

namespace HiaCapabilityLifecycle
open HiaCapabilityRenaming
def instruction0Before : List Capability := []
def instruction0After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction0Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction0_result : instruction0After = owner 0 0 :: instruction0Before := by decide
theorem instruction0_step : Step instruction0Before instruction0After := by
  rw [instruction0_result]
  exact Step.allocate (by simp [Fresh, instruction0Before]) (by decide)
theorem instruction0_closed_before : Closed instruction0Before := by
  simp [Closed, instruction0Before]
theorem instruction0_ranked_before : Ranked instruction0Before := by
  refine ⟨instruction0Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction0Before, instruction0Rank]
theorem instruction0_unique_before : Unique instruction0Before := by
  simp [Unique, instruction0Before]
theorem instruction0_closed_after : Closed instruction0After :=
  step_closed instruction0_step instruction0_closed_before
theorem instruction0_ranked_after : Ranked instruction0After :=
  step_ranked instruction0_step instruction0_closed_before instruction0_ranked_before
theorem instruction0_unique_after : Unique instruction0After :=
  step_unique instruction0_step instruction0_unique_before
theorem instruction0_no_parent_cycle (name : Nat) : ¬ ParentPath instruction0After name name :=
  ranked_no_parent_cycle instruction0After instruction0_ranked_after name
def instruction1Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction1After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction1Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction1Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction1_result : instruction1After = loan instruction1Source 1 3 :: instruction1Before := by decide
theorem instruction1_step : Step instruction1Before instruction1After := by
  rw [instruction1_result]
  exact Step.borrowMut (by simp [instruction1Source, instruction1Before]) (by simp [Fresh, instruction1Before]) (by decide)
theorem instruction1_closed_before : Closed instruction1Before := by
  simp [Closed, instruction1Before]
theorem instruction1_ranked_before : Ranked instruction1Before := by
  refine ⟨instruction1Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction1Before, instruction1Rank]
theorem instruction1_unique_before : Unique instruction1Before := by
  simp [Unique, instruction1Before]
theorem instruction1_closed_after : Closed instruction1After :=
  step_closed instruction1_step instruction1_closed_before
theorem instruction1_ranked_after : Ranked instruction1After :=
  step_ranked instruction1_step instruction1_closed_before instruction1_ranked_before
theorem instruction1_unique_after : Unique instruction1After :=
  step_unique instruction1_step instruction1_unique_before
theorem instruction1_no_parent_cycle (name : Nat) : ¬ ParentPath instruction1After name name :=
  ranked_no_parent_cycle instruction1After instruction1_ranked_after name
def instruction2Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def instruction2After : List Capability := [⟨1, 0, (some 2), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def instruction2Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 2 => 1
  | _ => 0
def instruction2Source : Capability := ⟨2, 0, (some 0), 3, false, none⟩
theorem instruction2_result : instruction2After = loan instruction2Source 1 2 :: instruction2Before := by decide
theorem instruction2_step : Step instruction2Before instruction2After := by
  rw [instruction2_result]
  exact Step.borrowRead (by simp [instruction2Source, instruction2Before]) (by simp [Fresh, instruction2Before]) (by decide)
theorem instruction2_closed_before : Closed instruction2Before := by
  simp [Closed, instruction2Before]
theorem instruction2_ranked_before : Ranked instruction2Before := by
  refine ⟨instruction2Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction2Before, instruction2Rank]
theorem instruction2_unique_before : Unique instruction2Before := by
  simp [Unique, instruction2Before]
theorem instruction2_closed_after : Closed instruction2After :=
  step_closed instruction2_step instruction2_closed_before
theorem instruction2_ranked_after : Ranked instruction2After :=
  step_ranked instruction2_step instruction2_closed_before instruction2_ranked_before
theorem instruction2_unique_after : Unique instruction2After :=
  step_unique instruction2_step instruction2_unique_before
theorem instruction2_no_parent_cycle (name : Nat) : ¬ ParentPath instruction2After name name :=
  ranked_no_parent_cycle instruction2After instruction2_ranked_after name
def instruction3Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction3After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction3Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction3Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction3_result : instruction3After = erase instruction3Source.name instruction3Before := by decide
theorem instruction3_step : Step instruction3Before instruction3After := by
  rw [instruction3_result]
  exact Step.endLoan (c := instruction3Source) (by simp [instruction3Source, instruction3Before]) (by decide) (by decide) (by simp [Unreferenced, instruction3Before, instruction3Source])
theorem instruction3_closed_before : Closed instruction3Before := by
  simp [Closed, instruction3Before]
theorem instruction3_ranked_before : Ranked instruction3Before := by
  refine ⟨instruction3Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction3Before, instruction3Rank]
theorem instruction3_unique_before : Unique instruction3Before := by
  simp [Unique, instruction3Before]
theorem instruction3_closed_after : Closed instruction3After :=
  step_closed instruction3_step instruction3_closed_before
theorem instruction3_ranked_after : Ranked instruction3After :=
  step_ranked instruction3_step instruction3_closed_before instruction3_ranked_before
theorem instruction3_unique_after : Unique instruction3After :=
  step_unique instruction3_step instruction3_unique_before
theorem instruction3_no_parent_cycle (name : Nat) : ¬ ParentPath instruction3After name name :=
  ranked_no_parent_cycle instruction3After instruction3_ranked_after name
def instruction4Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction4After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction4Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction4Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction4_result : instruction4After = erase instruction4Source.name instruction4Before := by decide
theorem instruction4_step : Step instruction4Before instruction4After := by
  rw [instruction4_result]
  exact Step.endLoan (c := instruction4Source) (by simp [instruction4Source, instruction4Before]) (by decide) (by decide) (by simp [Unreferenced, instruction4Before, instruction4Source])
theorem instruction4_closed_before : Closed instruction4Before := by
  simp [Closed, instruction4Before]
theorem instruction4_ranked_before : Ranked instruction4Before := by
  refine ⟨instruction4Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction4Before, instruction4Rank]
theorem instruction4_unique_before : Unique instruction4Before := by
  simp [Unique, instruction4Before]
theorem instruction4_closed_after : Closed instruction4After :=
  step_closed instruction4_step instruction4_closed_before
theorem instruction4_ranked_after : Ranked instruction4After :=
  step_ranked instruction4_step instruction4_closed_before instruction4_ranked_before
theorem instruction4_unique_after : Unique instruction4After :=
  step_unique instruction4_step instruction4_unique_before
theorem instruction4_no_parent_cycle (name : Nat) : ¬ ParentPath instruction4After name name :=
  ranked_no_parent_cycle instruction4After instruction4_ranked_after name
def instruction5Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction5After : List Capability := [⟨1, 0, (some 0), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction5Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction5Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction5_result : instruction5After = loan instruction5Source 1 2 :: instruction5Before := by decide
theorem instruction5_step : Step instruction5Before instruction5After := by
  rw [instruction5_result]
  exact Step.borrowRead (by simp [instruction5Source, instruction5Before]) (by simp [Fresh, instruction5Before]) (by decide)
theorem instruction5_closed_before : Closed instruction5Before := by
  simp [Closed, instruction5Before]
theorem instruction5_ranked_before : Ranked instruction5Before := by
  refine ⟨instruction5Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction5Before, instruction5Rank]
theorem instruction5_unique_before : Unique instruction5Before := by
  simp [Unique, instruction5Before]
theorem instruction5_closed_after : Closed instruction5After :=
  step_closed instruction5_step instruction5_closed_before
theorem instruction5_ranked_after : Ranked instruction5After :=
  step_ranked instruction5_step instruction5_closed_before instruction5_ranked_before
theorem instruction5_unique_after : Unique instruction5After :=
  step_unique instruction5_step instruction5_unique_before
theorem instruction5_no_parent_cycle (name : Nat) : ¬ ParentPath instruction5After name name :=
  ranked_no_parent_cycle instruction5After instruction5_ranked_after name
def instruction6Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction6After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction6Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction6Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction6_result : instruction6After = erase instruction6Source.name instruction6Before := by decide
theorem instruction6_step : Step instruction6Before instruction6After := by
  rw [instruction6_result]
  exact Step.endLoan (c := instruction6Source) (by simp [instruction6Source, instruction6Before]) (by decide) (by decide) (by simp [Unreferenced, instruction6Before, instruction6Source])
theorem instruction6_closed_before : Closed instruction6Before := by
  simp [Closed, instruction6Before]
theorem instruction6_ranked_before : Ranked instruction6Before := by
  refine ⟨instruction6Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction6Before, instruction6Rank]
theorem instruction6_unique_before : Unique instruction6Before := by
  simp [Unique, instruction6Before]
theorem instruction6_closed_after : Closed instruction6After :=
  step_closed instruction6_step instruction6_closed_before
theorem instruction6_ranked_after : Ranked instruction6After :=
  step_ranked instruction6_step instruction6_closed_before instruction6_ranked_before
theorem instruction6_unique_after : Unique instruction6After :=
  step_unique instruction6_step instruction6_unique_before
theorem instruction6_no_parent_cycle (name : Nat) : ¬ ParentPath instruction6After name name :=
  ranked_no_parent_cycle instruction6After instruction6_ranked_after name
def instruction7Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction7After : List Capability := []
def instruction7Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction7Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction7_result : instruction7After = erase instruction7Source.name instruction7Before := by decide
theorem instruction7_step : Step instruction7Before instruction7After := by
  rw [instruction7_result]
  exact Step.dropOwner (c := instruction7Source) (by simp [instruction7Source, instruction7Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction7Before, instruction7Source])
theorem instruction7_closed_before : Closed instruction7Before := by
  simp [Closed, instruction7Before]
theorem instruction7_ranked_before : Ranked instruction7Before := by
  refine ⟨instruction7Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction7Before, instruction7Rank]
theorem instruction7_unique_before : Unique instruction7Before := by
  simp [Unique, instruction7Before]
theorem instruction7_closed_after : Closed instruction7After :=
  step_closed instruction7_step instruction7_closed_before
theorem instruction7_ranked_after : Ranked instruction7After :=
  step_ranked instruction7_step instruction7_closed_before instruction7_ranked_before
theorem instruction7_unique_after : Unique instruction7After :=
  step_unique instruction7_step instruction7_unique_before
theorem instruction7_no_parent_cycle (name : Nat) : ¬ ParentPath instruction7After name name :=
  ranked_no_parent_cycle instruction7After instruction7_ranked_after name
def instruction8Before : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def instruction8After : List Capability := [⟨1, 0, (some 0), 2, false, (some 0)⟩, ⟨0, 0, none, 2, true, (some 0)⟩]
def instruction8Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction8Source : Capability := ⟨0, 0, none, 2, true, (some 0)⟩
theorem instruction8_result : instruction8After = loan instruction8Source 1 2 :: instruction8Before := by decide
theorem instruction8_step : Step instruction8Before instruction8After := by
  rw [instruction8_result]
  exact Step.borrowRead (by simp [instruction8Source, instruction8Before]) (by simp [Fresh, instruction8Before]) (by decide)
theorem instruction8_closed_before : Closed instruction8Before := by
  simp [Closed, instruction8Before]
theorem instruction8_ranked_before : Ranked instruction8Before := by
  refine ⟨instruction8Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction8Before, instruction8Rank]
theorem instruction8_unique_before : Unique instruction8Before := by
  simp [Unique, instruction8Before]
theorem instruction8_closed_after : Closed instruction8After :=
  step_closed instruction8_step instruction8_closed_before
theorem instruction8_ranked_after : Ranked instruction8After :=
  step_ranked instruction8_step instruction8_closed_before instruction8_ranked_before
theorem instruction8_unique_after : Unique instruction8After :=
  step_unique instruction8_step instruction8_unique_before
theorem instruction8_no_parent_cycle (name : Nat) : ¬ ParentPath instruction8After name name :=
  ranked_no_parent_cycle instruction8After instruction8_ranked_after name
def instruction9Before : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def instruction9After : List Capability := [⟨1, 0, (some 0), 2, false, (some 0)⟩, ⟨0, 0, none, 2, true, (some 0)⟩]
def instruction9Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction9Source : Capability := ⟨0, 0, none, 2, true, (some 0)⟩
theorem instruction9_result : instruction9After = loan instruction9Source 1 2 :: instruction9Before := by decide
theorem instruction9_step : Step instruction9Before instruction9After := by
  rw [instruction9_result]
  exact Step.borrowRead (by simp [instruction9Source, instruction9Before]) (by simp [Fresh, instruction9Before]) (by decide)
theorem instruction9_closed_before : Closed instruction9Before := by
  simp [Closed, instruction9Before]
theorem instruction9_ranked_before : Ranked instruction9Before := by
  refine ⟨instruction9Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction9Before, instruction9Rank]
theorem instruction9_unique_before : Unique instruction9Before := by
  simp [Unique, instruction9Before]
theorem instruction9_closed_after : Closed instruction9After :=
  step_closed instruction9_step instruction9_closed_before
theorem instruction9_ranked_after : Ranked instruction9After :=
  step_ranked instruction9_step instruction9_closed_before instruction9_ranked_before
theorem instruction9_unique_after : Unique instruction9After :=
  step_unique instruction9_step instruction9_unique_before
theorem instruction9_no_parent_cycle (name : Nat) : ¬ ParentPath instruction9After name name :=
  ranked_no_parent_cycle instruction9After instruction9_ranked_after name
def instruction10Before : List Capability := [⟨0, 0, none, 3, true, (some 0)⟩]
def instruction10After : List Capability := [⟨1, 0, (some 0), 3, false, (some 0)⟩, ⟨0, 0, none, 3, true, (some 0)⟩]
def instruction10Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction10Source : Capability := ⟨0, 0, none, 3, true, (some 0)⟩
theorem instruction10_result : instruction10After = loan instruction10Source 1 3 :: instruction10Before := by decide
theorem instruction10_step : Step instruction10Before instruction10After := by
  rw [instruction10_result]
  exact Step.borrowMut (by simp [instruction10Source, instruction10Before]) (by simp [Fresh, instruction10Before]) (by decide)
theorem instruction10_closed_before : Closed instruction10Before := by
  simp [Closed, instruction10Before]
theorem instruction10_ranked_before : Ranked instruction10Before := by
  refine ⟨instruction10Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction10Before, instruction10Rank]
theorem instruction10_unique_before : Unique instruction10Before := by
  simp [Unique, instruction10Before]
theorem instruction10_closed_after : Closed instruction10After :=
  step_closed instruction10_step instruction10_closed_before
theorem instruction10_ranked_after : Ranked instruction10After :=
  step_ranked instruction10_step instruction10_closed_before instruction10_ranked_before
theorem instruction10_unique_after : Unique instruction10After :=
  step_unique instruction10_step instruction10_unique_before
theorem instruction10_no_parent_cycle (name : Nat) : ¬ ParentPath instruction10After name name :=
  ranked_no_parent_cycle instruction10After instruction10_ranked_after name
def instruction11Before : List Capability := []
def instruction11After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction11Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction11_result : instruction11After = owner 0 0 :: instruction11Before := by decide
theorem instruction11_step : Step instruction11Before instruction11After := by
  rw [instruction11_result]
  exact Step.allocate (by simp [Fresh, instruction11Before]) (by decide)
theorem instruction11_closed_before : Closed instruction11Before := by
  simp [Closed, instruction11Before]
theorem instruction11_ranked_before : Ranked instruction11Before := by
  refine ⟨instruction11Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction11Before, instruction11Rank]
theorem instruction11_unique_before : Unique instruction11Before := by
  simp [Unique, instruction11Before]
theorem instruction11_closed_after : Closed instruction11After :=
  step_closed instruction11_step instruction11_closed_before
theorem instruction11_ranked_after : Ranked instruction11After :=
  step_ranked instruction11_step instruction11_closed_before instruction11_ranked_before
theorem instruction11_unique_after : Unique instruction11After :=
  step_unique instruction11_step instruction11_unique_before
theorem instruction11_no_parent_cycle (name : Nat) : ¬ ParentPath instruction11After name name :=
  ranked_no_parent_cycle instruction11After instruction11_ranked_after name
def instruction12Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction12After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction12Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction12Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction12_result : instruction12After = loan instruction12Source 1 3 :: instruction12Before := by decide
theorem instruction12_step : Step instruction12Before instruction12After := by
  rw [instruction12_result]
  exact Step.borrowMut (by simp [instruction12Source, instruction12Before]) (by simp [Fresh, instruction12Before]) (by decide)
theorem instruction12_closed_before : Closed instruction12Before := by
  simp [Closed, instruction12Before]
theorem instruction12_ranked_before : Ranked instruction12Before := by
  refine ⟨instruction12Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction12Before, instruction12Rank]
theorem instruction12_unique_before : Unique instruction12Before := by
  simp [Unique, instruction12Before]
theorem instruction12_closed_after : Closed instruction12After :=
  step_closed instruction12_step instruction12_closed_before
theorem instruction12_ranked_after : Ranked instruction12After :=
  step_ranked instruction12_step instruction12_closed_before instruction12_ranked_before
theorem instruction12_unique_after : Unique instruction12After :=
  step_unique instruction12_step instruction12_unique_before
theorem instruction12_no_parent_cycle (name : Nat) : ¬ ParentPath instruction12After name name :=
  ranked_no_parent_cycle instruction12After instruction12_ranked_after name
def instruction13Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction13After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction13Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction13Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction13_result : instruction13After = erase instruction13Source.name instruction13Before := by decide
theorem instruction13_step : Step instruction13Before instruction13After := by
  rw [instruction13_result]
  exact Step.endLoan (c := instruction13Source) (by simp [instruction13Source, instruction13Before]) (by decide) (by decide) (by simp [Unreferenced, instruction13Before, instruction13Source])
theorem instruction13_closed_before : Closed instruction13Before := by
  simp [Closed, instruction13Before]
theorem instruction13_ranked_before : Ranked instruction13Before := by
  refine ⟨instruction13Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction13Before, instruction13Rank]
theorem instruction13_unique_before : Unique instruction13Before := by
  simp [Unique, instruction13Before]
theorem instruction13_closed_after : Closed instruction13After :=
  step_closed instruction13_step instruction13_closed_before
theorem instruction13_ranked_after : Ranked instruction13After :=
  step_ranked instruction13_step instruction13_closed_before instruction13_ranked_before
theorem instruction13_unique_after : Unique instruction13After :=
  step_unique instruction13_step instruction13_unique_before
theorem instruction13_no_parent_cycle (name : Nat) : ¬ ParentPath instruction13After name name :=
  ranked_no_parent_cycle instruction13After instruction13_ranked_after name
def instruction14Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction14After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction14Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction14Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction14_result : instruction14After = loan instruction14Source 1 3 :: instruction14Before := by decide
theorem instruction14_step : Step instruction14Before instruction14After := by
  rw [instruction14_result]
  exact Step.borrowMut (by simp [instruction14Source, instruction14Before]) (by simp [Fresh, instruction14Before]) (by decide)
theorem instruction14_closed_before : Closed instruction14Before := by
  simp [Closed, instruction14Before]
theorem instruction14_ranked_before : Ranked instruction14Before := by
  refine ⟨instruction14Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction14Before, instruction14Rank]
theorem instruction14_unique_before : Unique instruction14Before := by
  simp [Unique, instruction14Before]
theorem instruction14_closed_after : Closed instruction14After :=
  step_closed instruction14_step instruction14_closed_before
theorem instruction14_ranked_after : Ranked instruction14After :=
  step_ranked instruction14_step instruction14_closed_before instruction14_ranked_before
theorem instruction14_unique_after : Unique instruction14After :=
  step_unique instruction14_step instruction14_unique_before
theorem instruction14_no_parent_cycle (name : Nat) : ¬ ParentPath instruction14After name name :=
  ranked_no_parent_cycle instruction14After instruction14_ranked_after name
def instruction15Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction15After : List Capability := [⟨3, 0, (some 2), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction15Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction15Source : Capability := ⟨2, 0, (some 1), 3, false, none⟩
theorem instruction15_result : instruction15After = loan instruction15Source 3 2 :: instruction15Before := by decide
theorem instruction15_step : Step instruction15Before instruction15After := by
  rw [instruction15_result]
  exact Step.borrowRead (by simp [instruction15Source, instruction15Before]) (by simp [Fresh, instruction15Before]) (by decide)
theorem instruction15_closed_before : Closed instruction15Before := by
  simp [Closed, instruction15Before]
theorem instruction15_ranked_before : Ranked instruction15Before := by
  refine ⟨instruction15Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction15Before, instruction15Rank]
theorem instruction15_unique_before : Unique instruction15Before := by
  simp [Unique, instruction15Before]
theorem instruction15_closed_after : Closed instruction15After :=
  step_closed instruction15_step instruction15_closed_before
theorem instruction15_ranked_after : Ranked instruction15After :=
  step_ranked instruction15_step instruction15_closed_before instruction15_ranked_before
theorem instruction15_unique_after : Unique instruction15After :=
  step_unique instruction15_step instruction15_unique_before
theorem instruction15_no_parent_cycle (name : Nat) : ¬ ParentPath instruction15After name name :=
  ranked_no_parent_cycle instruction15After instruction15_ranked_after name
def instruction16Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction16After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction16Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | _ => 0
def instruction16Source : Capability := ⟨3, 0, (some 2), 2, false, none⟩
theorem instruction16_result : instruction16After = erase instruction16Source.name instruction16Before := by decide
theorem instruction16_step : Step instruction16Before instruction16After := by
  rw [instruction16_result]
  exact Step.endLoan (c := instruction16Source) (by simp [instruction16Source, instruction16Before]) (by decide) (by decide) (by simp [Unreferenced, instruction16Before, instruction16Source])
theorem instruction16_closed_before : Closed instruction16Before := by
  simp [Closed, instruction16Before]
theorem instruction16_ranked_before : Ranked instruction16Before := by
  refine ⟨instruction16Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction16Before, instruction16Rank]
theorem instruction16_unique_before : Unique instruction16Before := by
  simp [Unique, instruction16Before]
theorem instruction16_closed_after : Closed instruction16After :=
  step_closed instruction16_step instruction16_closed_before
theorem instruction16_ranked_after : Ranked instruction16After :=
  step_ranked instruction16_step instruction16_closed_before instruction16_ranked_before
theorem instruction16_unique_after : Unique instruction16After :=
  step_unique instruction16_step instruction16_unique_before
theorem instruction16_no_parent_cycle (name : Nat) : ¬ ParentPath instruction16After name name :=
  ranked_no_parent_cycle instruction16After instruction16_ranked_after name
def instruction17Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩, ⟨2, 0, (some 1), 3, false, none⟩]
def instruction17After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction17Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction17Source : Capability := ⟨2, 0, (some 1), 3, false, none⟩
theorem instruction17_result : instruction17After = erase instruction17Source.name instruction17Before := by decide
theorem instruction17_step : Step instruction17Before instruction17After := by
  rw [instruction17_result]
  exact Step.endLoan (c := instruction17Source) (by simp [instruction17Source, instruction17Before]) (by decide) (by decide) (by simp [Unreferenced, instruction17Before, instruction17Source])
theorem instruction17_closed_before : Closed instruction17Before := by
  simp [Closed, instruction17Before]
theorem instruction17_ranked_before : Ranked instruction17Before := by
  refine ⟨instruction17Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction17Before, instruction17Rank]
theorem instruction17_unique_before : Unique instruction17Before := by
  simp [Unique, instruction17Before]
theorem instruction17_closed_after : Closed instruction17After :=
  step_closed instruction17_step instruction17_closed_before
theorem instruction17_ranked_after : Ranked instruction17After :=
  step_ranked instruction17_step instruction17_closed_before instruction17_ranked_before
theorem instruction17_unique_after : Unique instruction17After :=
  step_unique instruction17_step instruction17_unique_before
theorem instruction17_no_parent_cycle (name : Nat) : ¬ ParentPath instruction17After name name :=
  ranked_no_parent_cycle instruction17After instruction17_ranked_after name
def instruction18Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction18After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction18Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction18Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction18_result : instruction18After = erase instruction18Source.name instruction18Before := by decide
theorem instruction18_step : Step instruction18Before instruction18After := by
  rw [instruction18_result]
  exact Step.endLoan (c := instruction18Source) (by simp [instruction18Source, instruction18Before]) (by decide) (by decide) (by simp [Unreferenced, instruction18Before, instruction18Source])
theorem instruction18_closed_before : Closed instruction18Before := by
  simp [Closed, instruction18Before]
theorem instruction18_ranked_before : Ranked instruction18Before := by
  refine ⟨instruction18Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction18Before, instruction18Rank]
theorem instruction18_unique_before : Unique instruction18Before := by
  simp [Unique, instruction18Before]
theorem instruction18_closed_after : Closed instruction18After :=
  step_closed instruction18_step instruction18_closed_before
theorem instruction18_ranked_after : Ranked instruction18After :=
  step_ranked instruction18_step instruction18_closed_before instruction18_ranked_before
theorem instruction18_unique_after : Unique instruction18After :=
  step_unique instruction18_step instruction18_unique_before
theorem instruction18_no_parent_cycle (name : Nat) : ¬ ParentPath instruction18After name name :=
  ranked_no_parent_cycle instruction18After instruction18_ranked_after name
def instruction19Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction19After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction19Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction19Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction19_result : instruction19After = loan instruction19Source 1 3 :: instruction19Before := by decide
theorem instruction19_step : Step instruction19Before instruction19After := by
  rw [instruction19_result]
  exact Step.borrowMut (by simp [instruction19Source, instruction19Before]) (by simp [Fresh, instruction19Before]) (by decide)
theorem instruction19_closed_before : Closed instruction19Before := by
  simp [Closed, instruction19Before]
theorem instruction19_ranked_before : Ranked instruction19Before := by
  refine ⟨instruction19Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction19Before, instruction19Rank]
theorem instruction19_unique_before : Unique instruction19Before := by
  simp [Unique, instruction19Before]
theorem instruction19_closed_after : Closed instruction19After :=
  step_closed instruction19_step instruction19_closed_before
theorem instruction19_ranked_after : Ranked instruction19After :=
  step_ranked instruction19_step instruction19_closed_before instruction19_ranked_before
theorem instruction19_unique_after : Unique instruction19After :=
  step_unique instruction19_step instruction19_unique_before
theorem instruction19_no_parent_cycle (name : Nat) : ¬ ParentPath instruction19After name name :=
  ranked_no_parent_cycle instruction19After instruction19_ranked_after name
def instruction20Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction20After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction20Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction20Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction20_result : instruction20After = erase instruction20Source.name instruction20Before := by decide
theorem instruction20_step : Step instruction20Before instruction20After := by
  rw [instruction20_result]
  exact Step.endLoan (c := instruction20Source) (by simp [instruction20Source, instruction20Before]) (by decide) (by decide) (by simp [Unreferenced, instruction20Before, instruction20Source])
theorem instruction20_closed_before : Closed instruction20Before := by
  simp [Closed, instruction20Before]
theorem instruction20_ranked_before : Ranked instruction20Before := by
  refine ⟨instruction20Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction20Before, instruction20Rank]
theorem instruction20_unique_before : Unique instruction20Before := by
  simp [Unique, instruction20Before]
theorem instruction20_closed_after : Closed instruction20After :=
  step_closed instruction20_step instruction20_closed_before
theorem instruction20_ranked_after : Ranked instruction20After :=
  step_ranked instruction20_step instruction20_closed_before instruction20_ranked_before
theorem instruction20_unique_after : Unique instruction20After :=
  step_unique instruction20_step instruction20_unique_before
theorem instruction20_no_parent_cycle (name : Nat) : ¬ ParentPath instruction20After name name :=
  ranked_no_parent_cycle instruction20After instruction20_ranked_after name
def instruction21Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction21After : List Capability := [⟨1, 0, (some 0), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction21Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction21Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction21_result : instruction21After = loan instruction21Source 1 2 :: instruction21Before := by decide
theorem instruction21_step : Step instruction21Before instruction21After := by
  rw [instruction21_result]
  exact Step.borrowRead (by simp [instruction21Source, instruction21Before]) (by simp [Fresh, instruction21Before]) (by decide)
theorem instruction21_closed_before : Closed instruction21Before := by
  simp [Closed, instruction21Before]
theorem instruction21_ranked_before : Ranked instruction21Before := by
  refine ⟨instruction21Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction21Before, instruction21Rank]
theorem instruction21_unique_before : Unique instruction21Before := by
  simp [Unique, instruction21Before]
theorem instruction21_closed_after : Closed instruction21After :=
  step_closed instruction21_step instruction21_closed_before
theorem instruction21_ranked_after : Ranked instruction21After :=
  step_ranked instruction21_step instruction21_closed_before instruction21_ranked_before
theorem instruction21_unique_after : Unique instruction21After :=
  step_unique instruction21_step instruction21_unique_before
theorem instruction21_no_parent_cycle (name : Nat) : ¬ ParentPath instruction21After name name :=
  ranked_no_parent_cycle instruction21After instruction21_ranked_after name
def instruction22Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction22After : List Capability := [⟨3, 0, (some 2), 2, false, none⟩, ⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction22Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction22Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction22_result : instruction22After = loan instruction22Source 3 2 :: instruction22Before := by decide
theorem instruction22_step : Step instruction22Before instruction22After := by
  rw [instruction22_result]
  exact Step.borrowRead (by simp [instruction22Source, instruction22Before]) (by simp [Fresh, instruction22Before]) (by decide)
theorem instruction22_closed_before : Closed instruction22Before := by
  simp [Closed, instruction22Before]
theorem instruction22_ranked_before : Ranked instruction22Before := by
  refine ⟨instruction22Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction22Before, instruction22Rank]
theorem instruction22_unique_before : Unique instruction22Before := by
  simp [Unique, instruction22Before]
theorem instruction22_closed_after : Closed instruction22After :=
  step_closed instruction22_step instruction22_closed_before
theorem instruction22_ranked_after : Ranked instruction22After :=
  step_ranked instruction22_step instruction22_closed_before instruction22_ranked_before
theorem instruction22_unique_after : Unique instruction22After :=
  step_unique instruction22_step instruction22_unique_before
theorem instruction22_no_parent_cycle (name : Nat) : ¬ ParentPath instruction22After name name :=
  ranked_no_parent_cycle instruction22After instruction22_ranked_after name
def instruction23Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩, ⟨3, 0, (some 2), 2, false, none⟩]
def instruction23After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction23Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | _ => 0
def instruction23Source : Capability := ⟨3, 0, (some 2), 2, false, none⟩
theorem instruction23_result : instruction23After = erase instruction23Source.name instruction23Before := by decide
theorem instruction23_step : Step instruction23Before instruction23After := by
  rw [instruction23_result]
  exact Step.endLoan (c := instruction23Source) (by simp [instruction23Source, instruction23Before]) (by decide) (by decide) (by simp [Unreferenced, instruction23Before, instruction23Source])
theorem instruction23_closed_before : Closed instruction23Before := by
  simp [Closed, instruction23Before]
theorem instruction23_ranked_before : Ranked instruction23Before := by
  refine ⟨instruction23Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction23Before, instruction23Rank]
theorem instruction23_unique_before : Unique instruction23Before := by
  simp [Unique, instruction23Before]
theorem instruction23_closed_after : Closed instruction23After :=
  step_closed instruction23_step instruction23_closed_before
theorem instruction23_ranked_after : Ranked instruction23After :=
  step_ranked instruction23_step instruction23_closed_before instruction23_ranked_before
theorem instruction23_unique_after : Unique instruction23After :=
  step_unique instruction23_step instruction23_unique_before
theorem instruction23_no_parent_cycle (name : Nat) : ¬ ParentPath instruction23After name name :=
  ranked_no_parent_cycle instruction23After instruction23_ranked_after name
def instruction24Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩, ⟨2, 0, (some 1), 2, false, none⟩]
def instruction24After : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction24Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | _ => 0
def instruction24Source : Capability := ⟨2, 0, (some 1), 2, false, none⟩
theorem instruction24_result : instruction24After = erase instruction24Source.name instruction24Before := by decide
theorem instruction24_step : Step instruction24Before instruction24After := by
  rw [instruction24_result]
  exact Step.endLoan (c := instruction24Source) (by simp [instruction24Source, instruction24Before]) (by decide) (by decide) (by simp [Unreferenced, instruction24Before, instruction24Source])
theorem instruction24_closed_before : Closed instruction24Before := by
  simp [Closed, instruction24Before]
theorem instruction24_ranked_before : Ranked instruction24Before := by
  refine ⟨instruction24Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction24Before, instruction24Rank]
theorem instruction24_unique_before : Unique instruction24Before := by
  simp [Unique, instruction24Before]
theorem instruction24_closed_after : Closed instruction24After :=
  step_closed instruction24_step instruction24_closed_before
theorem instruction24_ranked_after : Ranked instruction24After :=
  step_ranked instruction24_step instruction24_closed_before instruction24_ranked_before
theorem instruction24_unique_after : Unique instruction24After :=
  step_unique instruction24_step instruction24_unique_before
theorem instruction24_no_parent_cycle (name : Nat) : ¬ ParentPath instruction24After name name :=
  ranked_no_parent_cycle instruction24After instruction24_ranked_after name
def instruction25Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction25After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction25Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction25Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction25_result : instruction25After = erase instruction25Source.name instruction25Before := by decide
theorem instruction25_step : Step instruction25Before instruction25After := by
  rw [instruction25_result]
  exact Step.endLoan (c := instruction25Source) (by simp [instruction25Source, instruction25Before]) (by decide) (by decide) (by simp [Unreferenced, instruction25Before, instruction25Source])
theorem instruction25_closed_before : Closed instruction25Before := by
  simp [Closed, instruction25Before]
theorem instruction25_ranked_before : Ranked instruction25Before := by
  refine ⟨instruction25Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction25Before, instruction25Rank]
theorem instruction25_unique_before : Unique instruction25Before := by
  simp [Unique, instruction25Before]
theorem instruction25_closed_after : Closed instruction25After :=
  step_closed instruction25_step instruction25_closed_before
theorem instruction25_ranked_after : Ranked instruction25After :=
  step_ranked instruction25_step instruction25_closed_before instruction25_ranked_before
theorem instruction25_unique_after : Unique instruction25After :=
  step_unique instruction25_step instruction25_unique_before
theorem instruction25_no_parent_cycle (name : Nat) : ¬ ParentPath instruction25After name name :=
  ranked_no_parent_cycle instruction25After instruction25_ranked_after name
def instruction26Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction26After : List Capability := []
def instruction26Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction26Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction26_result : instruction26After = erase instruction26Source.name instruction26Before := by decide
theorem instruction26_step : Step instruction26Before instruction26After := by
  rw [instruction26_result]
  exact Step.dropOwner (c := instruction26Source) (by simp [instruction26Source, instruction26Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction26Before, instruction26Source])
theorem instruction26_closed_before : Closed instruction26Before := by
  simp [Closed, instruction26Before]
theorem instruction26_ranked_before : Ranked instruction26Before := by
  refine ⟨instruction26Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction26Before, instruction26Rank]
theorem instruction26_unique_before : Unique instruction26Before := by
  simp [Unique, instruction26Before]
theorem instruction26_closed_after : Closed instruction26After :=
  step_closed instruction26_step instruction26_closed_before
theorem instruction26_ranked_after : Ranked instruction26After :=
  step_ranked instruction26_step instruction26_closed_before instruction26_ranked_before
theorem instruction26_unique_after : Unique instruction26After :=
  step_unique instruction26_step instruction26_unique_before
theorem instruction26_no_parent_cycle (name : Nat) : ¬ ParentPath instruction26After name name :=
  ranked_no_parent_cycle instruction26After instruction26_ranked_after name
def instruction27Before : List Capability := []
def instruction27After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction27Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction27_result : instruction27After = owner 0 0 :: instruction27Before := by decide
theorem instruction27_step : Step instruction27Before instruction27After := by
  rw [instruction27_result]
  exact Step.allocate (by simp [Fresh, instruction27Before]) (by decide)
theorem instruction27_closed_before : Closed instruction27Before := by
  simp [Closed, instruction27Before]
theorem instruction27_ranked_before : Ranked instruction27Before := by
  refine ⟨instruction27Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction27Before, instruction27Rank]
theorem instruction27_unique_before : Unique instruction27Before := by
  simp [Unique, instruction27Before]
theorem instruction27_closed_after : Closed instruction27After :=
  step_closed instruction27_step instruction27_closed_before
theorem instruction27_ranked_after : Ranked instruction27After :=
  step_ranked instruction27_step instruction27_closed_before instruction27_ranked_before
theorem instruction27_unique_after : Unique instruction27After :=
  step_unique instruction27_step instruction27_unique_before
theorem instruction27_no_parent_cycle (name : Nat) : ¬ ParentPath instruction27After name name :=
  ranked_no_parent_cycle instruction27After instruction27_ranked_after name
def instruction28Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction28After : List Capability := [⟨1, 0, (some 0), 3, false, none⟩, ⟨0, 0, none, 0, false, none⟩]
def instruction28Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction28Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction28_result : instruction28After = loan instruction28Source 1 3 :: instruction28Before := by decide
theorem instruction28_step : Step instruction28Before instruction28After := by
  rw [instruction28_result]
  exact Step.borrowMut (by simp [instruction28Source, instruction28Before]) (by simp [Fresh, instruction28Before]) (by decide)
theorem instruction28_closed_before : Closed instruction28Before := by
  simp [Closed, instruction28Before]
theorem instruction28_ranked_before : Ranked instruction28Before := by
  refine ⟨instruction28Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction28Before, instruction28Rank]
theorem instruction28_unique_before : Unique instruction28Before := by
  simp [Unique, instruction28Before]
theorem instruction28_closed_after : Closed instruction28After :=
  step_closed instruction28_step instruction28_closed_before
theorem instruction28_ranked_after : Ranked instruction28After :=
  step_ranked instruction28_step instruction28_closed_before instruction28_ranked_before
theorem instruction28_unique_after : Unique instruction28After :=
  step_unique instruction28_step instruction28_unique_before
theorem instruction28_no_parent_cycle (name : Nat) : ¬ ParentPath instruction28After name name :=
  ranked_no_parent_cycle instruction28After instruction28_ranked_after name
def instruction29Before : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction29After : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction29Rank (n : Nat) : Nat :=
  match n with
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction29Source : Capability := ⟨2, 1, (some 1), 3, false, none⟩
theorem instruction29_result : instruction29After = loan instruction29Source 0 2 :: instruction29Before := by decide
theorem instruction29_step : Step instruction29Before instruction29After := by
  rw [instruction29_result]
  exact Step.borrowRead (by simp [instruction29Source, instruction29Before]) (by simp [Fresh, instruction29Before]) (by decide)
theorem instruction29_closed_before : Closed instruction29Before := by
  simp [Closed, instruction29Before]
theorem instruction29_ranked_before : Ranked instruction29Before := by
  refine ⟨instruction29Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction29Before, instruction29Rank]
theorem instruction29_unique_before : Unique instruction29Before := by
  simp [Unique, instruction29Before]
theorem instruction29_closed_after : Closed instruction29After :=
  step_closed instruction29_step instruction29_closed_before
theorem instruction29_ranked_after : Ranked instruction29After :=
  step_ranked instruction29_step instruction29_closed_before instruction29_ranked_before
theorem instruction29_unique_after : Unique instruction29After :=
  step_unique instruction29_step instruction29_unique_before
theorem instruction29_no_parent_cycle (name : Nat) : ¬ ParentPath instruction29After name name :=
  ranked_no_parent_cycle instruction29After instruction29_ranked_after name
def instruction30Before : List Capability := [⟨0, 1, (some 2), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction30After : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 3, false, none⟩]
def instruction30Rank (n : Nat) : Nat :=
  match n with
  | 0 => 2
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction30Source : Capability := ⟨0, 1, (some 2), 2, false, none⟩
theorem instruction30_result : instruction30After = erase instruction30Source.name instruction30Before := by decide
theorem instruction30_step : Step instruction30Before instruction30After := by
  rw [instruction30_result]
  exact Step.endLoan (c := instruction30Source) (by simp [instruction30Source, instruction30Before]) (by decide) (by decide) (by simp [Unreferenced, instruction30Before, instruction30Source])
theorem instruction30_closed_before : Closed instruction30Before := by
  simp [Closed, instruction30Before]
theorem instruction30_ranked_before : Ranked instruction30Before := by
  refine ⟨instruction30Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction30Before, instruction30Rank]
theorem instruction30_unique_before : Unique instruction30Before := by
  simp [Unique, instruction30Before]
theorem instruction30_closed_after : Closed instruction30After :=
  step_closed instruction30_step instruction30_closed_before
theorem instruction30_ranked_after : Ranked instruction30After :=
  step_ranked instruction30_step instruction30_closed_before instruction30_ranked_before
theorem instruction30_unique_after : Unique instruction30After :=
  step_unique instruction30_step instruction30_unique_before
theorem instruction30_no_parent_cycle (name : Nat) : ¬ ParentPath instruction30After name name :=
  ranked_no_parent_cycle instruction30After instruction30_ranked_after name
def instruction31Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 3, false, none⟩]
def instruction31After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction31Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction31Source : Capability := ⟨1, 0, (some 0), 3, false, none⟩
theorem instruction31_result : instruction31After = erase instruction31Source.name instruction31Before := by decide
theorem instruction31_step : Step instruction31Before instruction31After := by
  rw [instruction31_result]
  exact Step.endLoan (c := instruction31Source) (by simp [instruction31Source, instruction31Before]) (by decide) (by decide) (by simp [Unreferenced, instruction31Before, instruction31Source])
theorem instruction31_closed_before : Closed instruction31Before := by
  simp [Closed, instruction31Before]
theorem instruction31_ranked_before : Ranked instruction31Before := by
  refine ⟨instruction31Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction31Before, instruction31Rank]
theorem instruction31_unique_before : Unique instruction31Before := by
  simp [Unique, instruction31Before]
theorem instruction31_closed_after : Closed instruction31After :=
  step_closed instruction31_step instruction31_closed_before
theorem instruction31_ranked_after : Ranked instruction31After :=
  step_ranked instruction31_step instruction31_closed_before instruction31_ranked_before
theorem instruction31_unique_after : Unique instruction31After :=
  step_unique instruction31_step instruction31_unique_before
theorem instruction31_no_parent_cycle (name : Nat) : ¬ ParentPath instruction31After name name :=
  ranked_no_parent_cycle instruction31After instruction31_ranked_after name
def instruction32Before : List Capability := [⟨1, 1, none, 0, false, none⟩]
def instruction32After : List Capability := [⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩]
def instruction32Rank (n : Nat) : Nat :=
  match n with
  | 1 => 0
  | _ => 0
def instruction32Source : Capability := ⟨1, 1, none, 0, false, none⟩
theorem instruction32_result : instruction32After = loan instruction32Source 0 2 :: instruction32Before := by decide
theorem instruction32_step : Step instruction32Before instruction32After := by
  rw [instruction32_result]
  exact Step.borrowRead (by simp [instruction32Source, instruction32Before]) (by simp [Fresh, instruction32Before]) (by decide)
theorem instruction32_closed_before : Closed instruction32Before := by
  simp [Closed, instruction32Before]
theorem instruction32_ranked_before : Ranked instruction32Before := by
  refine ⟨instruction32Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction32Before, instruction32Rank]
theorem instruction32_unique_before : Unique instruction32Before := by
  simp [Unique, instruction32Before]
theorem instruction32_closed_after : Closed instruction32After :=
  step_closed instruction32_step instruction32_closed_before
theorem instruction32_ranked_after : Ranked instruction32After :=
  step_ranked instruction32_step instruction32_closed_before instruction32_ranked_before
theorem instruction32_unique_after : Unique instruction32After :=
  step_unique instruction32_step instruction32_unique_before
theorem instruction32_no_parent_cycle (name : Nat) : ¬ ParentPath instruction32After name name :=
  ranked_no_parent_cycle instruction32After instruction32_ranked_after name
def instruction33Before : List Capability := [⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩]
def instruction33After : List Capability := [⟨2, 1, (some 1), 2, false, none⟩, ⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩]
def instruction33Rank (n : Nat) : Nat :=
  match n with
  | 0 => 1
  | 1 => 0
  | _ => 0
def instruction33Source : Capability := ⟨1, 1, none, 0, false, none⟩
theorem instruction33_result : instruction33After = loan instruction33Source 2 2 :: instruction33Before := by decide
theorem instruction33_step : Step instruction33Before instruction33After := by
  rw [instruction33_result]
  exact Step.borrowRead (by simp [instruction33Source, instruction33Before]) (by simp [Fresh, instruction33Before]) (by decide)
theorem instruction33_closed_before : Closed instruction33Before := by
  simp [Closed, instruction33Before]
theorem instruction33_ranked_before : Ranked instruction33Before := by
  refine ⟨instruction33Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction33Before, instruction33Rank]
theorem instruction33_unique_before : Unique instruction33Before := by
  simp [Unique, instruction33Before]
theorem instruction33_closed_after : Closed instruction33After :=
  step_closed instruction33_step instruction33_closed_before
theorem instruction33_ranked_after : Ranked instruction33After :=
  step_ranked instruction33_step instruction33_closed_before instruction33_ranked_before
theorem instruction33_unique_after : Unique instruction33After :=
  step_unique instruction33_step instruction33_unique_before
theorem instruction33_no_parent_cycle (name : Nat) : ¬ ParentPath instruction33After name name :=
  ranked_no_parent_cycle instruction33After instruction33_ranked_after name
def instruction34Before : List Capability := [⟨0, 1, (some 1), 2, false, none⟩, ⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 2, false, none⟩]
def instruction34After : List Capability := [⟨1, 1, none, 0, false, none⟩, ⟨2, 1, (some 1), 2, false, none⟩]
def instruction34Rank (n : Nat) : Nat :=
  match n with
  | 0 => 1
  | 1 => 0
  | 2 => 1
  | _ => 0
def instruction34Source : Capability := ⟨0, 1, (some 1), 2, false, none⟩
theorem instruction34_result : instruction34After = erase instruction34Source.name instruction34Before := by decide
theorem instruction34_step : Step instruction34Before instruction34After := by
  rw [instruction34_result]
  exact Step.endLoan (c := instruction34Source) (by simp [instruction34Source, instruction34Before]) (by decide) (by decide) (by simp [Unreferenced, instruction34Before, instruction34Source])
theorem instruction34_closed_before : Closed instruction34Before := by
  simp [Closed, instruction34Before]
theorem instruction34_ranked_before : Ranked instruction34Before := by
  refine ⟨instruction34Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction34Before, instruction34Rank]
theorem instruction34_unique_before : Unique instruction34Before := by
  simp [Unique, instruction34Before]
theorem instruction34_closed_after : Closed instruction34After :=
  step_closed instruction34_step instruction34_closed_before
theorem instruction34_ranked_after : Ranked instruction34After :=
  step_ranked instruction34_step instruction34_closed_before instruction34_ranked_before
theorem instruction34_unique_after : Unique instruction34After :=
  step_unique instruction34_step instruction34_unique_before
theorem instruction34_no_parent_cycle (name : Nat) : ¬ ParentPath instruction34After name name :=
  ranked_no_parent_cycle instruction34After instruction34_ranked_after name
def instruction35Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 0), 2, false, none⟩]
def instruction35After : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction35Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 1
  | _ => 0
def instruction35Source : Capability := ⟨1, 0, (some 0), 2, false, none⟩
theorem instruction35_result : instruction35After = erase instruction35Source.name instruction35Before := by decide
theorem instruction35_step : Step instruction35Before instruction35After := by
  rw [instruction35_result]
  exact Step.endLoan (c := instruction35Source) (by simp [instruction35Source, instruction35Before]) (by decide) (by decide) (by simp [Unreferenced, instruction35Before, instruction35Source])
theorem instruction35_closed_before : Closed instruction35Before := by
  simp [Closed, instruction35Before]
theorem instruction35_ranked_before : Ranked instruction35Before := by
  refine ⟨instruction35Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction35Before, instruction35Rank]
theorem instruction35_unique_before : Unique instruction35Before := by
  simp [Unique, instruction35Before]
theorem instruction35_closed_after : Closed instruction35After :=
  step_closed instruction35_step instruction35_closed_before
theorem instruction35_ranked_after : Ranked instruction35After :=
  step_ranked instruction35_step instruction35_closed_before instruction35_ranked_before
theorem instruction35_unique_after : Unique instruction35After :=
  step_unique instruction35_step instruction35_unique_before
theorem instruction35_no_parent_cycle (name : Nat) : ¬ ParentPath instruction35After name name :=
  ranked_no_parent_cycle instruction35After instruction35_ranked_after name
def instruction36Before : List Capability := [⟨0, 0, none, 0, false, none⟩]
def instruction36After : List Capability := []
def instruction36Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction36Source : Capability := ⟨0, 0, none, 0, false, none⟩
theorem instruction36_result : instruction36After = erase instruction36Source.name instruction36Before := by decide
theorem instruction36_step : Step instruction36Before instruction36After := by
  rw [instruction36_result]
  exact Step.dropOwner (c := instruction36Source) (by simp [instruction36Source, instruction36Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction36Before, instruction36Source])
theorem instruction36_closed_before : Closed instruction36Before := by
  simp [Closed, instruction36Before]
theorem instruction36_ranked_before : Ranked instruction36Before := by
  refine ⟨instruction36Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction36Before, instruction36Rank]
theorem instruction36_unique_before : Unique instruction36Before := by
  simp [Unique, instruction36Before]
theorem instruction36_closed_after : Closed instruction36After :=
  step_closed instruction36_step instruction36_closed_before
theorem instruction36_ranked_after : Ranked instruction36After :=
  step_ranked instruction36_step instruction36_closed_before instruction36_ranked_before
theorem instruction36_unique_after : Unique instruction36After :=
  step_unique instruction36_step instruction36_unique_before
theorem instruction36_no_parent_cycle (name : Nat) : ¬ ParentPath instruction36After name name :=
  ranked_no_parent_cycle instruction36After instruction36_ranked_after name
def instruction37Before : List Capability := []
def instruction37After : List Capability := [⟨0, 0, none, 1, false, none⟩]
def instruction37Rank (n : Nat) : Nat :=
  match n with
  | _ => 0
theorem instruction37_result : instruction37After = owner 0 1 :: instruction37Before := by decide
theorem instruction37_step : Step instruction37Before instruction37After := by
  rw [instruction37_result]
  exact Step.allocate (by simp [Fresh, instruction37Before]) (by decide)
theorem instruction37_closed_before : Closed instruction37Before := by
  simp [Closed, instruction37Before]
theorem instruction37_ranked_before : Ranked instruction37Before := by
  refine ⟨instruction37Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction37Before, instruction37Rank]
theorem instruction37_unique_before : Unique instruction37Before := by
  simp [Unique, instruction37Before]
theorem instruction37_closed_after : Closed instruction37After :=
  step_closed instruction37_step instruction37_closed_before
theorem instruction37_ranked_after : Ranked instruction37After :=
  step_ranked instruction37_step instruction37_closed_before instruction37_ranked_before
theorem instruction37_unique_after : Unique instruction37After :=
  step_unique instruction37_step instruction37_unique_before
theorem instruction37_no_parent_cycle (name : Nat) : ¬ ParentPath instruction37After name name :=
  ranked_no_parent_cycle instruction37After instruction37_ranked_after name
def instruction38Before : List Capability := [⟨0, 0, none, 1, false, none⟩]
def instruction38After : List Capability := []
def instruction38Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def instruction38Source : Capability := ⟨0, 0, none, 1, false, none⟩
theorem instruction38_result : instruction38After = erase instruction38Source.name instruction38Before := by decide
theorem instruction38_step : Step instruction38Before instruction38After := by
  rw [instruction38_result]
  exact Step.dropOwner (c := instruction38Source) (by simp [instruction38Source, instruction38Before]) (by decide) (by decide) (by decide) (by decide) (by simp [Unreferenced, instruction38Before, instruction38Source])
theorem instruction38_closed_before : Closed instruction38Before := by
  simp [Closed, instruction38Before]
theorem instruction38_ranked_before : Ranked instruction38Before := by
  refine ⟨instruction38Rank, ?_⟩
  simp [ParentRanks, ChildOf, instruction38Before, instruction38Rank]
theorem instruction38_unique_before : Unique instruction38Before := by
  simp [Unique, instruction38Before]
theorem instruction38_closed_after : Closed instruction38After :=
  step_closed instruction38_step instruction38_closed_before
theorem instruction38_ranked_after : Ranked instruction38After :=
  step_ranked instruction38_step instruction38_closed_before instruction38_ranked_before
theorem instruction38_unique_after : Unique instruction38After :=
  step_unique instruction38_step instruction38_unique_before
theorem instruction38_no_parent_cycle (name : Nat) : ¬ ParentPath instruction38After name name :=
  ranked_no_parent_cycle instruction38After instruction38_ranked_after name
end HiaCapabilityLifecycle
#print axioms HiaCapabilityLifecycle.erase_closed
#print axioms HiaCapabilityLifecycle.erase_ranked
#print axioms HiaCapabilityLifecycle.erase_unique
#print axioms HiaCapabilityLifecycle.erased_member
#print axioms HiaCapabilityLifecycle.extend_rank_old
#print axioms HiaCapabilityLifecycle.fresh_cons_unique
#print axioms HiaCapabilityLifecycle.fresh_not_member
#print axioms HiaCapabilityLifecycle.fresh_parent_absent
#print axioms HiaCapabilityLifecycle.instruction0_closed_after
#print axioms HiaCapabilityLifecycle.instruction0_closed_before
#print axioms HiaCapabilityLifecycle.instruction0_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction0_ranked_after
#print axioms HiaCapabilityLifecycle.instruction0_ranked_before
#print axioms HiaCapabilityLifecycle.instruction0_result
#print axioms HiaCapabilityLifecycle.instruction0_step
#print axioms HiaCapabilityLifecycle.instruction0_unique_after
#print axioms HiaCapabilityLifecycle.instruction0_unique_before
#print axioms HiaCapabilityLifecycle.instruction10_closed_after
#print axioms HiaCapabilityLifecycle.instruction10_closed_before
#print axioms HiaCapabilityLifecycle.instruction10_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction10_ranked_after
#print axioms HiaCapabilityLifecycle.instruction10_ranked_before
#print axioms HiaCapabilityLifecycle.instruction10_result
#print axioms HiaCapabilityLifecycle.instruction10_step
#print axioms HiaCapabilityLifecycle.instruction10_unique_after
#print axioms HiaCapabilityLifecycle.instruction10_unique_before
#print axioms HiaCapabilityLifecycle.instruction11_closed_after
#print axioms HiaCapabilityLifecycle.instruction11_closed_before
#print axioms HiaCapabilityLifecycle.instruction11_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction11_ranked_after
#print axioms HiaCapabilityLifecycle.instruction11_ranked_before
#print axioms HiaCapabilityLifecycle.instruction11_result
#print axioms HiaCapabilityLifecycle.instruction11_step
#print axioms HiaCapabilityLifecycle.instruction11_unique_after
#print axioms HiaCapabilityLifecycle.instruction11_unique_before
#print axioms HiaCapabilityLifecycle.instruction12_closed_after
#print axioms HiaCapabilityLifecycle.instruction12_closed_before
#print axioms HiaCapabilityLifecycle.instruction12_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction12_ranked_after
#print axioms HiaCapabilityLifecycle.instruction12_ranked_before
#print axioms HiaCapabilityLifecycle.instruction12_result
#print axioms HiaCapabilityLifecycle.instruction12_step
#print axioms HiaCapabilityLifecycle.instruction12_unique_after
#print axioms HiaCapabilityLifecycle.instruction12_unique_before
#print axioms HiaCapabilityLifecycle.instruction13_closed_after
#print axioms HiaCapabilityLifecycle.instruction13_closed_before
#print axioms HiaCapabilityLifecycle.instruction13_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction13_ranked_after
#print axioms HiaCapabilityLifecycle.instruction13_ranked_before
#print axioms HiaCapabilityLifecycle.instruction13_result
#print axioms HiaCapabilityLifecycle.instruction13_step
#print axioms HiaCapabilityLifecycle.instruction13_unique_after
#print axioms HiaCapabilityLifecycle.instruction13_unique_before
#print axioms HiaCapabilityLifecycle.instruction14_closed_after
#print axioms HiaCapabilityLifecycle.instruction14_closed_before
#print axioms HiaCapabilityLifecycle.instruction14_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction14_ranked_after
#print axioms HiaCapabilityLifecycle.instruction14_ranked_before
#print axioms HiaCapabilityLifecycle.instruction14_result
#print axioms HiaCapabilityLifecycle.instruction14_step
#print axioms HiaCapabilityLifecycle.instruction14_unique_after
#print axioms HiaCapabilityLifecycle.instruction14_unique_before
#print axioms HiaCapabilityLifecycle.instruction15_closed_after
#print axioms HiaCapabilityLifecycle.instruction15_closed_before
#print axioms HiaCapabilityLifecycle.instruction15_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction15_ranked_after
#print axioms HiaCapabilityLifecycle.instruction15_ranked_before
#print axioms HiaCapabilityLifecycle.instruction15_result
#print axioms HiaCapabilityLifecycle.instruction15_step
#print axioms HiaCapabilityLifecycle.instruction15_unique_after
#print axioms HiaCapabilityLifecycle.instruction15_unique_before
#print axioms HiaCapabilityLifecycle.instruction16_closed_after
#print axioms HiaCapabilityLifecycle.instruction16_closed_before
#print axioms HiaCapabilityLifecycle.instruction16_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction16_ranked_after
#print axioms HiaCapabilityLifecycle.instruction16_ranked_before
#print axioms HiaCapabilityLifecycle.instruction16_result
#print axioms HiaCapabilityLifecycle.instruction16_step
#print axioms HiaCapabilityLifecycle.instruction16_unique_after
#print axioms HiaCapabilityLifecycle.instruction16_unique_before
#print axioms HiaCapabilityLifecycle.instruction17_closed_after
#print axioms HiaCapabilityLifecycle.instruction17_closed_before
#print axioms HiaCapabilityLifecycle.instruction17_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction17_ranked_after
#print axioms HiaCapabilityLifecycle.instruction17_ranked_before
#print axioms HiaCapabilityLifecycle.instruction17_result
#print axioms HiaCapabilityLifecycle.instruction17_step
#print axioms HiaCapabilityLifecycle.instruction17_unique_after
#print axioms HiaCapabilityLifecycle.instruction17_unique_before
#print axioms HiaCapabilityLifecycle.instruction18_closed_after
#print axioms HiaCapabilityLifecycle.instruction18_closed_before
#print axioms HiaCapabilityLifecycle.instruction18_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction18_ranked_after
#print axioms HiaCapabilityLifecycle.instruction18_ranked_before
#print axioms HiaCapabilityLifecycle.instruction18_result
#print axioms HiaCapabilityLifecycle.instruction18_step
#print axioms HiaCapabilityLifecycle.instruction18_unique_after
#print axioms HiaCapabilityLifecycle.instruction18_unique_before
#print axioms HiaCapabilityLifecycle.instruction19_closed_after
#print axioms HiaCapabilityLifecycle.instruction19_closed_before
#print axioms HiaCapabilityLifecycle.instruction19_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction19_ranked_after
#print axioms HiaCapabilityLifecycle.instruction19_ranked_before
#print axioms HiaCapabilityLifecycle.instruction19_result
#print axioms HiaCapabilityLifecycle.instruction19_step
#print axioms HiaCapabilityLifecycle.instruction19_unique_after
#print axioms HiaCapabilityLifecycle.instruction19_unique_before
#print axioms HiaCapabilityLifecycle.instruction1_closed_after
#print axioms HiaCapabilityLifecycle.instruction1_closed_before
#print axioms HiaCapabilityLifecycle.instruction1_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction1_ranked_after
#print axioms HiaCapabilityLifecycle.instruction1_ranked_before
#print axioms HiaCapabilityLifecycle.instruction1_result
#print axioms HiaCapabilityLifecycle.instruction1_step
#print axioms HiaCapabilityLifecycle.instruction1_unique_after
#print axioms HiaCapabilityLifecycle.instruction1_unique_before
#print axioms HiaCapabilityLifecycle.instruction20_closed_after
#print axioms HiaCapabilityLifecycle.instruction20_closed_before
#print axioms HiaCapabilityLifecycle.instruction20_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction20_ranked_after
#print axioms HiaCapabilityLifecycle.instruction20_ranked_before
#print axioms HiaCapabilityLifecycle.instruction20_result
#print axioms HiaCapabilityLifecycle.instruction20_step
#print axioms HiaCapabilityLifecycle.instruction20_unique_after
#print axioms HiaCapabilityLifecycle.instruction20_unique_before
#print axioms HiaCapabilityLifecycle.instruction21_closed_after
#print axioms HiaCapabilityLifecycle.instruction21_closed_before
#print axioms HiaCapabilityLifecycle.instruction21_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction21_ranked_after
#print axioms HiaCapabilityLifecycle.instruction21_ranked_before
#print axioms HiaCapabilityLifecycle.instruction21_result
#print axioms HiaCapabilityLifecycle.instruction21_step
#print axioms HiaCapabilityLifecycle.instruction21_unique_after
#print axioms HiaCapabilityLifecycle.instruction21_unique_before
#print axioms HiaCapabilityLifecycle.instruction22_closed_after
#print axioms HiaCapabilityLifecycle.instruction22_closed_before
#print axioms HiaCapabilityLifecycle.instruction22_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction22_ranked_after
#print axioms HiaCapabilityLifecycle.instruction22_ranked_before
#print axioms HiaCapabilityLifecycle.instruction22_result
#print axioms HiaCapabilityLifecycle.instruction22_step
#print axioms HiaCapabilityLifecycle.instruction22_unique_after
#print axioms HiaCapabilityLifecycle.instruction22_unique_before
#print axioms HiaCapabilityLifecycle.instruction23_closed_after
#print axioms HiaCapabilityLifecycle.instruction23_closed_before
#print axioms HiaCapabilityLifecycle.instruction23_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction23_ranked_after
#print axioms HiaCapabilityLifecycle.instruction23_ranked_before
#print axioms HiaCapabilityLifecycle.instruction23_result
#print axioms HiaCapabilityLifecycle.instruction23_step
#print axioms HiaCapabilityLifecycle.instruction23_unique_after
#print axioms HiaCapabilityLifecycle.instruction23_unique_before
#print axioms HiaCapabilityLifecycle.instruction24_closed_after
#print axioms HiaCapabilityLifecycle.instruction24_closed_before
#print axioms HiaCapabilityLifecycle.instruction24_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction24_ranked_after
#print axioms HiaCapabilityLifecycle.instruction24_ranked_before
#print axioms HiaCapabilityLifecycle.instruction24_result
#print axioms HiaCapabilityLifecycle.instruction24_step
#print axioms HiaCapabilityLifecycle.instruction24_unique_after
#print axioms HiaCapabilityLifecycle.instruction24_unique_before
#print axioms HiaCapabilityLifecycle.instruction25_closed_after
#print axioms HiaCapabilityLifecycle.instruction25_closed_before
#print axioms HiaCapabilityLifecycle.instruction25_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction25_ranked_after
#print axioms HiaCapabilityLifecycle.instruction25_ranked_before
#print axioms HiaCapabilityLifecycle.instruction25_result
#print axioms HiaCapabilityLifecycle.instruction25_step
#print axioms HiaCapabilityLifecycle.instruction25_unique_after
#print axioms HiaCapabilityLifecycle.instruction25_unique_before
#print axioms HiaCapabilityLifecycle.instruction26_closed_after
#print axioms HiaCapabilityLifecycle.instruction26_closed_before
#print axioms HiaCapabilityLifecycle.instruction26_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction26_ranked_after
#print axioms HiaCapabilityLifecycle.instruction26_ranked_before
#print axioms HiaCapabilityLifecycle.instruction26_result
#print axioms HiaCapabilityLifecycle.instruction26_step
#print axioms HiaCapabilityLifecycle.instruction26_unique_after
#print axioms HiaCapabilityLifecycle.instruction26_unique_before
#print axioms HiaCapabilityLifecycle.instruction27_closed_after
#print axioms HiaCapabilityLifecycle.instruction27_closed_before
#print axioms HiaCapabilityLifecycle.instruction27_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction27_ranked_after
#print axioms HiaCapabilityLifecycle.instruction27_ranked_before
#print axioms HiaCapabilityLifecycle.instruction27_result
#print axioms HiaCapabilityLifecycle.instruction27_step
#print axioms HiaCapabilityLifecycle.instruction27_unique_after
#print axioms HiaCapabilityLifecycle.instruction27_unique_before
#print axioms HiaCapabilityLifecycle.instruction28_closed_after
#print axioms HiaCapabilityLifecycle.instruction28_closed_before
#print axioms HiaCapabilityLifecycle.instruction28_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction28_ranked_after
#print axioms HiaCapabilityLifecycle.instruction28_ranked_before
#print axioms HiaCapabilityLifecycle.instruction28_result
#print axioms HiaCapabilityLifecycle.instruction28_step
#print axioms HiaCapabilityLifecycle.instruction28_unique_after
#print axioms HiaCapabilityLifecycle.instruction28_unique_before
#print axioms HiaCapabilityLifecycle.instruction29_closed_after
#print axioms HiaCapabilityLifecycle.instruction29_closed_before
#print axioms HiaCapabilityLifecycle.instruction29_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction29_ranked_after
#print axioms HiaCapabilityLifecycle.instruction29_ranked_before
#print axioms HiaCapabilityLifecycle.instruction29_result
#print axioms HiaCapabilityLifecycle.instruction29_step
#print axioms HiaCapabilityLifecycle.instruction29_unique_after
#print axioms HiaCapabilityLifecycle.instruction29_unique_before
#print axioms HiaCapabilityLifecycle.instruction2_closed_after
#print axioms HiaCapabilityLifecycle.instruction2_closed_before
#print axioms HiaCapabilityLifecycle.instruction2_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction2_ranked_after
#print axioms HiaCapabilityLifecycle.instruction2_ranked_before
#print axioms HiaCapabilityLifecycle.instruction2_result
#print axioms HiaCapabilityLifecycle.instruction2_step
#print axioms HiaCapabilityLifecycle.instruction2_unique_after
#print axioms HiaCapabilityLifecycle.instruction2_unique_before
#print axioms HiaCapabilityLifecycle.instruction30_closed_after
#print axioms HiaCapabilityLifecycle.instruction30_closed_before
#print axioms HiaCapabilityLifecycle.instruction30_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction30_ranked_after
#print axioms HiaCapabilityLifecycle.instruction30_ranked_before
#print axioms HiaCapabilityLifecycle.instruction30_result
#print axioms HiaCapabilityLifecycle.instruction30_step
#print axioms HiaCapabilityLifecycle.instruction30_unique_after
#print axioms HiaCapabilityLifecycle.instruction30_unique_before
#print axioms HiaCapabilityLifecycle.instruction31_closed_after
#print axioms HiaCapabilityLifecycle.instruction31_closed_before
#print axioms HiaCapabilityLifecycle.instruction31_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction31_ranked_after
#print axioms HiaCapabilityLifecycle.instruction31_ranked_before
#print axioms HiaCapabilityLifecycle.instruction31_result
#print axioms HiaCapabilityLifecycle.instruction31_step
#print axioms HiaCapabilityLifecycle.instruction31_unique_after
#print axioms HiaCapabilityLifecycle.instruction31_unique_before
#print axioms HiaCapabilityLifecycle.instruction32_closed_after
#print axioms HiaCapabilityLifecycle.instruction32_closed_before
#print axioms HiaCapabilityLifecycle.instruction32_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction32_ranked_after
#print axioms HiaCapabilityLifecycle.instruction32_ranked_before
#print axioms HiaCapabilityLifecycle.instruction32_result
#print axioms HiaCapabilityLifecycle.instruction32_step
#print axioms HiaCapabilityLifecycle.instruction32_unique_after
#print axioms HiaCapabilityLifecycle.instruction32_unique_before
#print axioms HiaCapabilityLifecycle.instruction33_closed_after
#print axioms HiaCapabilityLifecycle.instruction33_closed_before
#print axioms HiaCapabilityLifecycle.instruction33_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction33_ranked_after
#print axioms HiaCapabilityLifecycle.instruction33_ranked_before
#print axioms HiaCapabilityLifecycle.instruction33_result
#print axioms HiaCapabilityLifecycle.instruction33_step
#print axioms HiaCapabilityLifecycle.instruction33_unique_after
#print axioms HiaCapabilityLifecycle.instruction33_unique_before
#print axioms HiaCapabilityLifecycle.instruction34_closed_after
#print axioms HiaCapabilityLifecycle.instruction34_closed_before
#print axioms HiaCapabilityLifecycle.instruction34_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction34_ranked_after
#print axioms HiaCapabilityLifecycle.instruction34_ranked_before
#print axioms HiaCapabilityLifecycle.instruction34_result
#print axioms HiaCapabilityLifecycle.instruction34_step
#print axioms HiaCapabilityLifecycle.instruction34_unique_after
#print axioms HiaCapabilityLifecycle.instruction34_unique_before
#print axioms HiaCapabilityLifecycle.instruction35_closed_after
#print axioms HiaCapabilityLifecycle.instruction35_closed_before
#print axioms HiaCapabilityLifecycle.instruction35_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction35_ranked_after
#print axioms HiaCapabilityLifecycle.instruction35_ranked_before
#print axioms HiaCapabilityLifecycle.instruction35_result
#print axioms HiaCapabilityLifecycle.instruction35_step
#print axioms HiaCapabilityLifecycle.instruction35_unique_after
#print axioms HiaCapabilityLifecycle.instruction35_unique_before
#print axioms HiaCapabilityLifecycle.instruction36_closed_after
#print axioms HiaCapabilityLifecycle.instruction36_closed_before
#print axioms HiaCapabilityLifecycle.instruction36_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction36_ranked_after
#print axioms HiaCapabilityLifecycle.instruction36_ranked_before
#print axioms HiaCapabilityLifecycle.instruction36_result
#print axioms HiaCapabilityLifecycle.instruction36_step
#print axioms HiaCapabilityLifecycle.instruction36_unique_after
#print axioms HiaCapabilityLifecycle.instruction36_unique_before
#print axioms HiaCapabilityLifecycle.instruction37_closed_after
#print axioms HiaCapabilityLifecycle.instruction37_closed_before
#print axioms HiaCapabilityLifecycle.instruction37_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction37_ranked_after
#print axioms HiaCapabilityLifecycle.instruction37_ranked_before
#print axioms HiaCapabilityLifecycle.instruction37_result
#print axioms HiaCapabilityLifecycle.instruction37_step
#print axioms HiaCapabilityLifecycle.instruction37_unique_after
#print axioms HiaCapabilityLifecycle.instruction37_unique_before
#print axioms HiaCapabilityLifecycle.instruction38_closed_after
#print axioms HiaCapabilityLifecycle.instruction38_closed_before
#print axioms HiaCapabilityLifecycle.instruction38_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction38_ranked_after
#print axioms HiaCapabilityLifecycle.instruction38_ranked_before
#print axioms HiaCapabilityLifecycle.instruction38_result
#print axioms HiaCapabilityLifecycle.instruction38_step
#print axioms HiaCapabilityLifecycle.instruction38_unique_after
#print axioms HiaCapabilityLifecycle.instruction38_unique_before
#print axioms HiaCapabilityLifecycle.instruction3_closed_after
#print axioms HiaCapabilityLifecycle.instruction3_closed_before
#print axioms HiaCapabilityLifecycle.instruction3_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction3_ranked_after
#print axioms HiaCapabilityLifecycle.instruction3_ranked_before
#print axioms HiaCapabilityLifecycle.instruction3_result
#print axioms HiaCapabilityLifecycle.instruction3_step
#print axioms HiaCapabilityLifecycle.instruction3_unique_after
#print axioms HiaCapabilityLifecycle.instruction3_unique_before
#print axioms HiaCapabilityLifecycle.instruction4_closed_after
#print axioms HiaCapabilityLifecycle.instruction4_closed_before
#print axioms HiaCapabilityLifecycle.instruction4_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction4_ranked_after
#print axioms HiaCapabilityLifecycle.instruction4_ranked_before
#print axioms HiaCapabilityLifecycle.instruction4_result
#print axioms HiaCapabilityLifecycle.instruction4_step
#print axioms HiaCapabilityLifecycle.instruction4_unique_after
#print axioms HiaCapabilityLifecycle.instruction4_unique_before
#print axioms HiaCapabilityLifecycle.instruction5_closed_after
#print axioms HiaCapabilityLifecycle.instruction5_closed_before
#print axioms HiaCapabilityLifecycle.instruction5_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction5_ranked_after
#print axioms HiaCapabilityLifecycle.instruction5_ranked_before
#print axioms HiaCapabilityLifecycle.instruction5_result
#print axioms HiaCapabilityLifecycle.instruction5_step
#print axioms HiaCapabilityLifecycle.instruction5_unique_after
#print axioms HiaCapabilityLifecycle.instruction5_unique_before
#print axioms HiaCapabilityLifecycle.instruction6_closed_after
#print axioms HiaCapabilityLifecycle.instruction6_closed_before
#print axioms HiaCapabilityLifecycle.instruction6_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction6_ranked_after
#print axioms HiaCapabilityLifecycle.instruction6_ranked_before
#print axioms HiaCapabilityLifecycle.instruction6_result
#print axioms HiaCapabilityLifecycle.instruction6_step
#print axioms HiaCapabilityLifecycle.instruction6_unique_after
#print axioms HiaCapabilityLifecycle.instruction6_unique_before
#print axioms HiaCapabilityLifecycle.instruction7_closed_after
#print axioms HiaCapabilityLifecycle.instruction7_closed_before
#print axioms HiaCapabilityLifecycle.instruction7_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction7_ranked_after
#print axioms HiaCapabilityLifecycle.instruction7_ranked_before
#print axioms HiaCapabilityLifecycle.instruction7_result
#print axioms HiaCapabilityLifecycle.instruction7_step
#print axioms HiaCapabilityLifecycle.instruction7_unique_after
#print axioms HiaCapabilityLifecycle.instruction7_unique_before
#print axioms HiaCapabilityLifecycle.instruction8_closed_after
#print axioms HiaCapabilityLifecycle.instruction8_closed_before
#print axioms HiaCapabilityLifecycle.instruction8_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction8_ranked_after
#print axioms HiaCapabilityLifecycle.instruction8_ranked_before
#print axioms HiaCapabilityLifecycle.instruction8_result
#print axioms HiaCapabilityLifecycle.instruction8_step
#print axioms HiaCapabilityLifecycle.instruction8_unique_after
#print axioms HiaCapabilityLifecycle.instruction8_unique_before
#print axioms HiaCapabilityLifecycle.instruction9_closed_after
#print axioms HiaCapabilityLifecycle.instruction9_closed_before
#print axioms HiaCapabilityLifecycle.instruction9_no_parent_cycle
#print axioms HiaCapabilityLifecycle.instruction9_ranked_after
#print axioms HiaCapabilityLifecycle.instruction9_ranked_before
#print axioms HiaCapabilityLifecycle.instruction9_result
#print axioms HiaCapabilityLifecycle.instruction9_step
#print axioms HiaCapabilityLifecycle.instruction9_unique_after
#print axioms HiaCapabilityLifecycle.instruction9_unique_before
#print axioms HiaCapabilityLifecycle.loan_closed
#print axioms HiaCapabilityLifecycle.loan_ranked
#print axioms HiaCapabilityLifecycle.owner_closed
#print axioms HiaCapabilityLifecycle.owner_ranked
#print axioms HiaCapabilityLifecycle.step_closed
#print axioms HiaCapabilityLifecycle.step_ranked
#print axioms HiaCapabilityLifecycle.step_unique
#print axioms HiaCapabilityLifecycle.trace_closed
#print axioms HiaCapabilityLifecycle.trace_no_parent_cycle
#print axioms HiaCapabilityLifecycle.trace_ranked
#print axioms HiaCapabilityLifecycle.trace_unique
#print axioms HiaCapabilityLifecycle.transfer_unique
#print axioms HiaCapabilityLifecycle.unique_projection
#print axioms HiaCapabilityLifecycle.unique_rename
#print axioms HiaCapabilityRenaming.child_of_iff
#print axioms HiaCapabilityRenaming.closed_preserved
#print axioms HiaCapabilityRenaming.exclusive_alias_iff
#print axioms HiaCapabilityRenaming.external_preserved
#print axioms HiaCapabilityRenaming.identity_rename
#print axioms HiaCapabilityRenaming.kind_preserved
#print axioms HiaCapabilityRenaming.local_inventory_projection
#print axioms HiaCapabilityRenaming.local_inventory_rename
#print axioms HiaCapabilityRenaming.local_retained
#print axioms HiaCapabilityRenaming.name_equal_iff
#print axioms HiaCapabilityRenaming.name_preserved
#print axioms HiaCapabilityRenaming.number_preserved
#print axioms HiaCapabilityRenaming.only_external_forgotten
#print axioms HiaCapabilityRenaming.origin_preserved
#print axioms HiaCapabilityRenaming.parent_map_iff
#print axioms HiaCapabilityRenaming.parent_path_descends
#print axioms HiaCapabilityRenaming.projected_member
#print axioms HiaCapabilityRenaming.ranked_no_parent_cycle
#print axioms HiaCapabilityRenaming.ranked_projection
#print axioms HiaCapabilityRenaming.ranked_rename
#print axioms HiaCapabilityRenaming.rename_composes
#print axioms HiaCapabilityRenaming.root_equal_iff
#print axioms HiaCapabilityRenaming.suspended_iff
#print axioms HiaCapabilityRenaming.trace_closed
#print axioms HiaCapabilityRenaming.trace_local_inventory
#print axioms HiaCapabilityRenaming.trace_no_parent_cycle
#print axioms HiaCapabilityRenaming.trace_ranked
#print axioms HiaCapabilityRenaming.transfer_closed
#print axioms HiaCapabilityRenaming.transfer_local_inventory
#print axioms HiaCapabilityRenaming.transfer_ranked
#print axioms HiaCapabilityRenaming.transported_rank_at
