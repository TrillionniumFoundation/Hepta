/-
Sequential Core capability-flow specification. Names are mathematical
naturals; kinds and origins are uninterpreted tags. This proves facts for
ALL finite capability lists and injective maps, without an execution-length
bound. It is not a proof of every instruction, Python, LLVM, FFI, or hardware.
Projection may forget only external capabilities and must keep the selected
graph closed. The trace theorems below compose these edge rules for every
finite trace; they do not model the intervening instructions in a CFG block.
-/
import Lean.Elab.Tactic.Omega

namespace HiaCapabilityRenaming

structure Capability where
  name : Nat
  root : Nat
  parent : Option Nat
  kind : Nat
  external : Bool
  origin : Option Nat
  deriving DecidableEq

def Injective (f : Nat → Nat) : Prop := ∀ a b, f a = f b → a = b

def rename (f : Nat → Nat) (c : Capability) : Capability :=
  { name := f c.name, root := f c.root, parent := c.parent.map f,
    kind := c.kind, external := c.external, origin := c.origin }

def ChildOf (child parent : Capability) : Prop := child.parent = some parent.name

def ExclusiveAlias (mutableKind : Nat) (a b : Capability) : Prop :=
  a.name ≠ b.name ∧ a.root = b.root ∧ (a.kind = mutableKind ∨ b.kind = mutableKind)

def Closed (caps : List Capability) : Prop :=
  ∀ c ∈ caps, (∃ root ∈ caps, root.name = c.root) ∧
    (∀ p, c.parent = some p → ∃ parent ∈ caps, parent.name = p)

theorem name_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).name = f c.name := rfl

theorem kind_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).kind = c.kind := rfl

theorem external_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).external = c.external := rfl

theorem origin_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).origin = c.origin := rfl

theorem name_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).name = (rename f b).name ↔ a.name = b.name := by
  constructor
  · exact inj a.name b.name
  · intro h; exact congrArg f h

theorem root_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).root = (rename f b).root ↔ a.root = b.root := by
  constructor
  · exact inj a.root b.root
  · intro h; exact congrArg f h

theorem parent_map_iff (f : Nat → Nat) (inj : Injective f) (p : Option Nat) (n : Nat) :
    p.map f = some (f n) ↔ p = some n := by
  cases p with
  | none => simp
  | some p =>
      constructor
      · intro h; exact congrArg some (inj p n (Option.some.inj h))
      · intro h; cases h; rfl

theorem child_of_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    ChildOf (rename f a) (rename f b) ↔ ChildOf a b := by
  exact parent_map_iff f inj a.parent b.name

theorem exclusive_alias_iff (f : Nat → Nat) (inj : Injective f)
    (mutableKind : Nat) (a b : Capability) :
    ExclusiveAlias mutableKind (rename f a) (rename f b) ↔
      ExclusiveAlias mutableKind a b := by
  simp only [ExclusiveAlias, ne_eq, name_equal_iff f inj,
             root_equal_iff f inj, kind_preserved]

theorem suspended_iff (f : Nat → Nat) (inj : Injective f)
    (caps : List Capability) (c : Capability) :
    (∃ child ∈ caps.map (rename f), ChildOf child (rename f c)) ↔
      (∃ child ∈ caps, ChildOf child c) := by
  constructor
  · rintro ⟨child, member, relation⟩
    obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
    exact ⟨old, oldMember, (child_of_iff f inj old c).mp relation⟩
  · rintro ⟨child, member, relation⟩
    exact ⟨rename f child, List.mem_map.mpr ⟨child, member, rfl⟩,
      (child_of_iff f inj child c).mpr relation⟩

theorem closed_preserved (f : Nat → Nat) (caps : List Capability)
    (closed : Closed caps) : Closed (caps.map (rename f)) := by
  intro c member
  obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
  obtain ⟨rootExists, parentExists⟩ := closed old oldMember
  obtain ⟨root, rootMember, rootName⟩ := rootExists
  constructor
  · exact ⟨rename f root, List.mem_map.mpr ⟨root, rootMember, rfl⟩,
      congrArg f rootName⟩
  · intro p relation
    cases hp : old.parent with
    | none => simp [rename, hp] at relation
    | some oldParent =>
        have mapped : f oldParent = p := by simpa [rename, hp] using relation
        obtain ⟨parent, parentMember, parentName⟩ := parentExists oldParent hp
        exact ⟨rename f parent, List.mem_map.mpr ⟨parent, parentMember, rfl⟩,
          (congrArg f parentName).trans mapped⟩

theorem number_preserved (f : Nat → Nat) (caps : List Capability) :
    (caps.map (rename f)).length = caps.length := by simp

theorem rename_composes (f g : Nat → Nat) (c : Capability) :
    rename g (rename f c) = rename (fun n => g (f n)) c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

theorem identity_rename (c : Capability) : rename (fun n => n) c = c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

/- The executable helper selects a subset before renaming. Selection is a
filter, so it cannot invent or duplicate capabilities. The explicit retention
premise is exactly the helper's rule for local owners and local loans. -/

def project (keep : Nat → Bool) (caps : List Capability) : List Capability :=
  caps.filter (fun c => keep c.name)

def AdmissibleProjection (caps : List Capability) (keep : Nat → Bool) : Prop :=
  (∀ c ∈ caps, c.external = false → keep c.name = true) ∧ Closed (project keep caps)

def localInventory : List Capability → List (Nat × Option Nat)
  | [] => []
  | c :: rest =>
      if c.external then localInventory rest else (c.kind, c.origin) :: localInventory rest

theorem projected_member (caps : List Capability) (keep : Nat → Bool) (c : Capability) :
    c ∈ project keep caps ↔ c ∈ caps ∧ keep c.name = true := by
  simp [project]

theorem local_retained (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (localCap : c.external = false) : c ∈ project keep caps := by
  exact (projected_member caps keep c).mpr ⟨member, admitted.1 c member localCap⟩

theorem only_external_forgotten (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (forgotten : c ∉ project keep caps) : c.external = true := by
  cases external : c.external with
  | false => exact False.elim (forgotten (local_retained caps keep admitted c member external))
  | true => rfl

theorem local_inventory_projection (caps : List Capability) (keep : Nat → Bool)
    (retained : ∀ c ∈ caps, c.external = false → keep c.name = true) :
    localInventory (project keep caps) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih =>
      have restRetained : ∀ x ∈ rest, x.external = false → keep x.name = true := by
        intro x member external
        exact retained x (List.mem_cons_of_mem c member) external
      have tail := ih restRetained
      cases external : c.external with
      | false =>
          have kept := retained c (by simp) external
          simp [project, localInventory, external, kept] at tail ⊢
          exact tail
      | true =>
          cases kept : keep c.name <;> simp [project, localInventory, external, kept] at tail ⊢
          all_goals exact tail

theorem local_inventory_rename (caps : List Capability) (f : Nat → Nat) :
    localInventory (caps.map (rename f)) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih => simp [localInventory, rename, ih]

/- Parent ranks are witnesses for strict descent, not runtime addresses or
integer counters. Their existence excludes every positive parent cycle. -/

def ParentRanks (caps : List Capability) (rank : Nat → Nat) : Prop :=
  ∀ child ∈ caps, ∀ parent ∈ caps, ChildOf child parent → rank parent.name < rank child.name

def Ranked (caps : List Capability) : Prop := ∃ rank, ParentRanks caps rank

inductive ParentPath (caps : List Capability) : Nat → Nat → Prop where
  | edge {child parent} : child ∈ caps → parent ∈ caps → ChildOf child parent →
      ParentPath caps child.name parent.name
  | trans {a b c} : ParentPath caps a b → ParentPath caps b c → ParentPath caps a c

theorem parent_path_descends (caps : List Capability) (rank : Nat → Nat)
    (ranked : ParentRanks caps rank) {a b : Nat} (path : ParentPath caps a b) :
    rank b < rank a := by
  induction path with
  | edge childMember parentMember relation => exact ranked _ childMember _ parentMember relation
  | trans _ _ left right => exact Nat.lt_trans right left

theorem ranked_no_parent_cycle (caps : List Capability) (ranked : Ranked caps) (name : Nat) :
    ¬ ParentPath caps name name := by
  intro path
  obtain ⟨rank, ordered⟩ := ranked
  exact (Nat.lt_irrefl (rank name)) (parent_path_descends caps rank ordered path)

theorem ranked_projection (caps : List Capability) (keep : Nat → Bool)
    (ranked : Ranked caps) : Ranked (project keep caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((projected_member caps keep child).mp childMember).1
    parent ((projected_member caps keep parent).mp parentMember).1 relation

noncomputable def transportedRank (f rank : Nat → Nat) (name : Nat) : Nat := by
  classical
  exact if witness : ∃ before, f before = name then rank (Classical.choose witness) else 0

theorem transported_rank_at (f rank : Nat → Nat) (inj : Injective f) (name : Nat) :
    transportedRank f rank (f name) = rank name := by
  unfold transportedRank
  split
  next witness =>
    have same : Classical.choose witness = name := inj _ _ (Classical.choose_spec witness)
    rw [same]
  next absent => exact False.elim (absent ⟨name, rfl⟩)

theorem ranked_rename (caps : List Capability) (f : Nat → Nat)
    (inj : Injective f) (ranked : Ranked caps) : Ranked (caps.map (rename f)) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨transportedRank f rank, ?_⟩
  intro child childMember parent parentMember relation
  obtain ⟨oldChild, oldChildMember, rfl⟩ := List.mem_map.mp childMember
  obtain ⟨oldParent, oldParentMember, rfl⟩ := List.mem_map.mp parentMember
  have oldRelation := (child_of_iff f inj oldChild oldParent).mp relation
  simpa only [name_preserved, transported_rank_at f rank inj] using
    ordered oldChild oldChildMember oldParent oldParentMember oldRelation

def Transfer (before after : List Capability) : Prop :=
  ∃ keep f, AdmissibleProjection before keep ∧ Injective f ∧
    after = (project keep before).map (rename f)

theorem transfer_closed {before after : List Capability} (step : Transfer before after) :
    Closed after := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  exact closed_preserved f (project keep before) admitted.2

theorem transfer_local_inventory {before after : List Capability} (step : Transfer before after) :
    localInventory after = localInventory before := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  rw [local_inventory_rename, local_inventory_projection before keep admitted.1]

theorem transfer_ranked {before after : List Capability} (step : Transfer before after)
    (ranked : Ranked before) : Ranked after := by
  obtain ⟨keep, f, _, inj, rfl⟩ := step
  exact ranked_rename (project keep before) f inj (ranked_projection before keep ranked)

inductive EdgeTrace : List Capability → List Capability → Prop where
  | refl (caps) : EdgeTrace caps caps
  | next {before middle after} : EdgeTrace before middle → Transfer middle after →
      EdgeTrace before after

theorem trace_local_inventory {before after : List Capability} (trace : EdgeTrace before after) :
    localInventory after = localInventory before := by
  induction trace with
  | refl => rfl
  | next _ step ih => exact (transfer_local_inventory step).trans ih

theorem trace_closed {before after : List Capability} (trace : EdgeTrace before after)
    (closed : Closed before) : Closed after := by
  cases trace with
  | refl => exact closed
  | next _ step => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | next _ step ih => exact transfer_ranked step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace ranked) name

end HiaCapabilityRenaming

/-
Structural preservation for allocation, borrowing and release. This model
concerns capability graphs, not heap execution or the production checker.
It does not prove alias exclusivity, FFI, calls or concurrent memory safety.
-/

namespace HiaCapabilityLifecycle
open HiaCapabilityRenaming

def Fresh (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name

def Unique (caps : List Capability) : Prop := (caps.map Capability.name).Nodup

def owner (name kind : Nat) : Capability :=
  ⟨name, name, none, kind, false, none⟩

def loan (source : Capability) (name kind : Nat) : Capability :=
  ⟨name, source.root, some name, kind, false, source.origin⟩

def erase (name : Nat) (caps : List Capability) : List Capability :=
  caps.filter (fun c => c.name != name)

def Unreferenced (caps : List Capability) (name : Nat) : Prop :=
  ∀ c ∈ caps, c.name ≠ name → c.root ≠ name ∧ c.parent ≠ some name

def extendRank (rank : Nat → Nat) (name value : Nat) (n : Nat) : Nat :=
  if n = name then value else rank n

theorem fresh_not_member (caps : List Capability) (name : Nat)
    (fresh : Fresh caps name) (c : Capability) (same : c.name = name) : c ∉ caps := by
  intro member
  exact fresh c member same

theorem fresh_parent_absent (caps : List Capability) (name : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    c.parent ≠ some name := by
  intro relation
  obtain ⟨parent, parentMember, parentName⟩ := (closed c member).2 name relation
  exact fresh parent parentMember parentName

theorem extend_rank_old (caps : List Capability) (rank : Nat → Nat) (name value : Nat)
    (fresh : Fresh caps name) (c : Capability) (member : c ∈ caps) :
    extendRank rank name value c.name = rank c.name := by
  simp [extendRank, fresh c member]

theorem fresh_cons_unique (caps : List Capability) (c : Capability)
    (unique : Unique caps) (fresh : Fresh caps c.name) : Unique (c :: caps) := by
  simp only [Unique, List.map_cons, List.nodup_cons]
  refine ⟨?_, unique⟩
  intro member
  obtain ⟨old, oldMember, same⟩ := List.mem_map.mp member
  exact fresh old oldMember same

theorem owner_closed (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) : Closed (owner name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · exact ⟨owner name kind, by simp, rfl⟩
    · intro p relation
      simp [owner] at relation
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem loan_closed (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (sourceMember : source ∈ caps) :
    Closed (loan source name kind :: caps) := by
  intro c member
  rcases List.mem_cons.mp member with same | oldMember
  · subst c
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := (closed source sourceMember).1
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      have same : source.name = p := Option.some.inj relation
      exact ⟨source, List.mem_cons_of_mem _ sourceMember, same⟩
  · obtain ⟨rootExists, parentExists⟩ := closed c oldMember
    constructor
    · obtain ⟨root, rootMember, rootName⟩ := rootExists
      exact ⟨root, List.mem_cons_of_mem _ rootMember, rootName⟩
    · intro p relation
      obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
      exact ⟨parent, List.mem_cons_of_mem _ parentMember, parentName⟩

theorem owner_ranked (caps : List Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (ranked : Ranked caps) :
    Ranked (owner name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name 0, ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    simp [ChildOf, owner] at relation
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name 0 fresh child childOld,
                  extend_rank_old caps rank name 0 fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem loan_ranked (caps : List Capability) (source : Capability) (name kind : Nat)
    (closed : Closed caps) (fresh : Fresh caps name) (sourceMember : source ∈ caps)
    (ranked : Ranked caps) : Ranked (loan source name kind :: caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨extendRank rank name (rank source.name + 1), ?_⟩
  intro child childMember parent parentMember relation
  rcases List.mem_cons.mp childMember with childNew | childOld
  · subst child
    have same : source.name = parent.name := Option.some.inj relation
    rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh source sourceMember same)
    · simp only [loan, extendRank, if_pos rfl]
      rw [← same]
      simp [extendRank, fresh source sourceMember]
  · rcases List.mem_cons.mp parentMember with parentNew | parentOld
    · subst parent
      exact False.elim (fresh_parent_absent caps name closed fresh child childOld relation)
    · simpa only [extend_rank_old caps rank name (rank source.name + 1) fresh child childOld,
                  extend_rank_old caps rank name (rank source.name + 1) fresh parent parentOld] using
        ordered child childOld parent parentOld relation

theorem erased_member (caps : List Capability) (name : Nat) (c : Capability) :
    c ∈ erase name caps ↔ c ∈ caps ∧ c.name ≠ name := by
  simp [erase]

theorem erase_closed (caps : List Capability) (name : Nat)
    (closed : Closed caps) (free : Unreferenced caps name) : Closed (erase name caps) := by
  intro c member
  obtain ⟨oldMember, notName⟩ := (erased_member caps name c).mp member
  obtain ⟨rootExists, parentExists⟩ := closed c oldMember
  constructor
  · obtain ⟨root, rootMember, rootName⟩ := rootExists
    have retained : root.name ≠ name := by
      intro same
      exact (free c oldMember notName).1 (rootName.symm.trans same)
    exact ⟨root, (erased_member caps name root).mpr ⟨rootMember, retained⟩, rootName⟩
  · intro p relation
    obtain ⟨parent, parentMember, parentName⟩ := parentExists p relation
    have retained : parent.name ≠ name := by
      intro same
      have pName : p = name := parentName.symm.trans same
      exact (free c oldMember notName).2 (relation.trans (congrArg some pName))
    exact ⟨parent, (erased_member caps name parent).mpr ⟨parentMember, retained⟩, parentName⟩

theorem erase_ranked (caps : List Capability) (name : Nat) (ranked : Ranked caps) :
    Ranked (erase name caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((erased_member caps name child).mp childMember).1
    parent ((erased_member caps name parent).mp parentMember).1 relation

theorem erase_unique (caps : List Capability) (name : Nat) (unique : Unique caps) :
    Unique (erase name caps) := by
  have subset : (erase name caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

/- This is a closed structural slice, not the complete borrow checker.
The borrow rules retain root/origin and prohibit shared-to-mutable escalation.
The separate production checker enforces conflicting alias exclusions. -/
inductive Step : List Capability → List Capability → Prop where
  | allocate {caps name kind} : Fresh caps name → (kind = 0 ∨ kind = 1) →
      Step caps (owner name kind :: caps)
  | borrowRead {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 2 ∨ source.kind = 3) →
      Step caps (loan source name 2 :: caps)
  | borrowMut {caps source name} : source ∈ caps → Fresh caps name →
      (source.kind = 0 ∨ source.kind = 3) →
      Step caps (loan source name 3 :: caps)
  | endLoan {caps c} : c ∈ caps → c.external = false →
      (c.kind = 2 ∨ c.kind = 3) → Unreferenced caps c.name →
      Step caps (erase c.name caps)
  | dropOwner {caps c} : c ∈ caps → c.external = false →
      (c.kind = 0 ∨ c.kind = 1) → c.root = c.name → c.parent = none →
      Unreferenced caps c.name → Step caps (erase c.name caps)

theorem step_closed {before after : List Capability} (step : Step before after)
    (closed : Closed before) : Closed after := by
  cases step with
  | allocate fresh kind => exact owner_closed _ _ _ closed
  | borrowRead sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | borrowMut sourceMember fresh kind => exact loan_closed _ _ _ _ closed sourceMember
  | endLoan member localCap kind free => exact erase_closed _ _ closed free
  | dropOwner member localCap kind root parent free => exact erase_closed _ _ closed free

theorem step_ranked {before after : List Capability} (step : Step before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  cases step with
  | allocate fresh kind => exact owner_ranked _ _ _ closed fresh ranked
  | borrowRead sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | borrowMut sourceMember fresh kind => exact loan_ranked _ _ _ _ closed fresh sourceMember ranked
  | endLoan member localCap kind free => exact erase_ranked _ _ ranked
  | dropOwner member localCap kind root parent free => exact erase_ranked _ _ ranked

theorem step_unique {before after : List Capability} (step : Step before after)
    (unique : Unique before) : Unique after := by
  cases step with
  | allocate fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowRead sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | borrowMut sourceMember fresh kind => exact fresh_cons_unique _ _ unique fresh
  | endLoan member localCap kind free => exact erase_unique _ _ unique
  | dropOwner member localCap kind root parent free => exact erase_unique _ _ unique

theorem unique_projection (caps : List Capability) (keep : Nat → Bool)
    (unique : Unique caps) : Unique (project keep caps) := by
  have subset : (project keep caps).Sublist caps := List.filter_sublist
  exact (subset.map Capability.name).nodup unique

theorem unique_rename (caps : List Capability) (f : Nat → Nat) (inj : Injective f)
    (unique : Unique caps) : Unique (caps.map (rename f)) := by
  induction caps with
  | nil => simp [Unique]
  | cons c rest ih =>
      have old : c.name ∉ rest.map Capability.name ∧ Unique rest := by
        simpa only [Unique, List.map_cons, List.nodup_cons] using unique
      simp only [List.map_cons, Unique, List.nodup_cons]
      refine ⟨?_, ih old.2⟩
      intro member
      obtain ⟨renamed, renamedMember, same⟩ := List.mem_map.mp member
      obtain ⟨original, originalMember, rfl⟩ := List.mem_map.mp renamedMember
      have originalName : original.name = c.name := inj _ _ same
      exact old.1 (List.mem_map.mpr ⟨original, originalMember, originalName⟩)

theorem transfer_unique {before after : List Capability} (step : Transfer before after)
    (unique : Unique before) : Unique after := by
  obtain ⟨keep, f, admitted, inj, rfl⟩ := step
  exact unique_rename _ f inj (unique_projection before keep unique)

inductive Trace : List Capability → List Capability → Prop where
  | refl (caps) : Trace caps caps
  | instruction {before middle after} : Trace before middle → Step middle after → Trace before after
  | edge {before middle after} : Trace before middle → Transfer middle after → Trace before after

theorem trace_closed {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) : Closed after := by
  induction trace with
  | refl => exact closed
  | instruction _ step ih => exact step_closed step ih
  | edge _ step ih => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | instruction earlier step ih => exact step_ranked step (trace_closed earlier closed) ih
  | edge _ step ih => exact transfer_ranked step ih

theorem trace_unique {before after : List Capability} (trace : Trace before after)
    (unique : Unique before) : Unique after := by
  induction trace with
  | refl => exact unique
  | instruction _ step ih => exact step_unique step ih
  | edge _ step ih => exact transfer_unique step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : Trace before after)
    (closed : Closed before) (ranked : Ranked before) (name : Nat) :
    ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace closed ranked) name

end HiaCapabilityLifecycle

#print axioms HiaCapabilityLifecycle.erase_closed
#print axioms HiaCapabilityLifecycle.erase_ranked
#print axioms HiaCapabilityLifecycle.erase_unique
#print axioms HiaCapabilityLifecycle.erased_member
#print axioms HiaCapabilityLifecycle.extend_rank_old
#print axioms HiaCapabilityLifecycle.fresh_cons_unique
#print axioms HiaCapabilityLifecycle.fresh_not_member
#print axioms HiaCapabilityLifecycle.fresh_parent_absent
#print axioms HiaCapabilityLifecycle.loan_closed
#print axioms HiaCapabilityLifecycle.loan_ranked
#print axioms HiaCapabilityLifecycle.owner_closed
#print axioms HiaCapabilityLifecycle.owner_ranked
#print axioms HiaCapabilityLifecycle.step_closed
#print axioms HiaCapabilityLifecycle.step_ranked
#print axioms HiaCapabilityLifecycle.step_unique
#print axioms HiaCapabilityLifecycle.trace_closed
#print axioms HiaCapabilityLifecycle.trace_no_parent_cycle
#print axioms HiaCapabilityLifecycle.trace_ranked
#print axioms HiaCapabilityLifecycle.trace_unique
#print axioms HiaCapabilityLifecycle.transfer_unique
#print axioms HiaCapabilityLifecycle.unique_projection
#print axioms HiaCapabilityLifecycle.unique_rename
#print axioms HiaCapabilityRenaming.child_of_iff
#print axioms HiaCapabilityRenaming.closed_preserved
#print axioms HiaCapabilityRenaming.exclusive_alias_iff
#print axioms HiaCapabilityRenaming.external_preserved
#print axioms HiaCapabilityRenaming.identity_rename
#print axioms HiaCapabilityRenaming.kind_preserved
#print axioms HiaCapabilityRenaming.local_inventory_projection
#print axioms HiaCapabilityRenaming.local_inventory_rename
#print axioms HiaCapabilityRenaming.local_retained
#print axioms HiaCapabilityRenaming.name_equal_iff
#print axioms HiaCapabilityRenaming.name_preserved
#print axioms HiaCapabilityRenaming.number_preserved
#print axioms HiaCapabilityRenaming.only_external_forgotten
#print axioms HiaCapabilityRenaming.origin_preserved
#print axioms HiaCapabilityRenaming.parent_map_iff
#print axioms HiaCapabilityRenaming.parent_path_descends
#print axioms HiaCapabilityRenaming.projected_member
#print axioms HiaCapabilityRenaming.ranked_no_parent_cycle
#print axioms HiaCapabilityRenaming.ranked_projection
#print axioms HiaCapabilityRenaming.ranked_rename
#print axioms HiaCapabilityRenaming.rename_composes
#print axioms HiaCapabilityRenaming.root_equal_iff
#print axioms HiaCapabilityRenaming.suspended_iff
#print axioms HiaCapabilityRenaming.trace_closed
#print axioms HiaCapabilityRenaming.trace_local_inventory
#print axioms HiaCapabilityRenaming.trace_no_parent_cycle
#print axioms HiaCapabilityRenaming.trace_ranked
#print axioms HiaCapabilityRenaming.transfer_closed
#print axioms HiaCapabilityRenaming.transfer_local_inventory
#print axioms HiaCapabilityRenaming.transfer_ranked
#print axioms HiaCapabilityRenaming.transported_rank_at
