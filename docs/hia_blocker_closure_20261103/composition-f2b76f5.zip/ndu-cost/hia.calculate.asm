
/home/runner/work/_temp/hia-composition/ndu-cost/hia.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	48 85 ff             	test   %rdi,%rdi
    11b7:	74 46                	je     11ff <calculate+0x4f>
    11b9:	89 f5                	mov    %esi,%ebp
    11bb:	48 89 fb             	mov    %rdi,%rbx
    11be:	78 2a                	js     11ea <calculate+0x3a>
    11c0:	48 89 df             	mov    %rbx,%rdi
    11c3:	e8 88 fe ff ff       	call   1050 <__wrap_malloc@plt>
    11c8:	48 85 c0             	test   %rax,%rax
    11cb:	74 1d                	je     11ea <calculate+0x3a>
    11cd:	48 89 c7             	mov    %rax,%rdi
    11d0:	b0 01                	mov    $0x1,%al
    11d2:	a8 01                	test   $0x1,%al
    11d4:	75 1c                	jne    11f2 <calculate+0x42>
    11d6:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    11dc:	48 85 ff             	test   %rdi,%rdi
    11df:	0f 85 90 01 00 00    	jne    1375 <calculate+0x1c5>
    11e5:	e9 90 01 00 00       	jmp    137a <calculate+0x1ca>
    11ea:	31 ff                	xor    %edi,%edi
    11ec:	31 c0                	xor    %eax,%eax
    11ee:	a8 01                	test   $0x1,%al
    11f0:	74 e4                	je     11d6 <calculate+0x26>
    11f2:	48 83 fb 03          	cmp    $0x3,%rbx
    11f6:	77 0f                	ja     1207 <calculate+0x57>
    11f8:	31 c0                	xor    %eax,%eax
    11fa:	e9 3c 01 00 00       	jmp    133b <calculate+0x18b>
    11ff:	45 31 f6             	xor    %r14d,%r14d
    1202:	e9 73 01 00 00       	jmp    137a <calculate+0x1ca>
    1207:	66 0f 6e c5          	movd   %ebp,%xmm0
    120b:	48 83 fb 10          	cmp    $0x10,%rbx
    120f:	73 07                	jae    1218 <calculate+0x68>
    1211:	31 c0                	xor    %eax,%eax
    1213:	e9 bc 00 00 00       	jmp    12d4 <calculate+0x124>
    1218:	48 89 d8             	mov    %rbx,%rax
    121b:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    121f:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    1224:	66 0f 6f 15 d4 1d 00 	movdqa 0x1dd4(%rip),%xmm2        # 3000 <_fini+0xf38>
    122b:	00 
    122c:	66 0f 6f 1d dc 1d 00 	movdqa 0x1ddc(%rip),%xmm3        # 3010 <_fini+0xf48>
    1233:	00 
    1234:	66 0f 6f 25 e4 1d 00 	movdqa 0x1de4(%rip),%xmm4        # 3020 <_fini+0xf58>
    123b:	00 
    123c:	66 0f 6f 2d ec 1d 00 	movdqa 0x1dec(%rip),%xmm5        # 3030 <_fini+0xf68>
    1243:	00 
    1244:	31 c9                	xor    %ecx,%ecx
    1246:	66 0f 6f 35 f2 1d 00 	movdqa 0x1df2(%rip),%xmm6        # 3040 <_fini+0xf78>
    124d:	00 
    124e:	66 0f 6f 3d fa 1d 00 	movdqa 0x1dfa(%rip),%xmm7        # 3050 <_fini+0xf88>
    1255:	00 
    1256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    125d:	00 00 00 
    1260:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    1265:	66 44 0f fe c2       	paddd  %xmm2,%xmm8
    126a:	66 44 0f 6f c9       	movdqa %xmm1,%xmm9
    126f:	66 44 0f fe cb       	paddd  %xmm3,%xmm9
    1274:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    1279:	66 44 0f fe d4       	paddd  %xmm4,%xmm10
    127e:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    1283:	66 44 0f fe dd       	paddd  %xmm5,%xmm11
    1288:	66 44 0f db de       	pand   %xmm6,%xmm11
    128d:	66 44 0f db d6       	pand   %xmm6,%xmm10
    1292:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    1297:	66 44 0f db ce       	pand   %xmm6,%xmm9
    129c:	66 44 0f db c6       	pand   %xmm6,%xmm8
    12a1:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    12a6:	66 45 0f 67 d9       	packuswb %xmm9,%xmm11
    12ab:	f3 44 0f 7f 1c 0f    	movdqu %xmm11,(%rdi,%rcx,1)
    12b1:	48 83 c1 10          	add    $0x10,%rcx
    12b5:	66 0f fe ef          	paddd  %xmm7,%xmm5
    12b9:	66 0f fe e7          	paddd  %xmm7,%xmm4
    12bd:	66 0f fe df          	paddd  %xmm7,%xmm3
    12c1:	66 0f fe d7          	paddd  %xmm7,%xmm2
    12c5:	48 39 c8             	cmp    %rcx,%rax
    12c8:	75 96                	jne    1260 <calculate+0xb0>
    12ca:	48 39 c3             	cmp    %rax,%rbx
    12cd:	74 7f                	je     134e <calculate+0x19e>
    12cf:	f6 c3 0c             	test   $0xc,%bl
    12d2:	74 67                	je     133b <calculate+0x18b>
    12d4:	48 89 c1             	mov    %rax,%rcx
    12d7:	48 89 d8             	mov    %rbx,%rax
    12da:	66 0f 6e c9          	movd   %ecx,%xmm1
    12de:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
    12e3:	66 0f eb 0d 45 1d 00 	por    0x1d45(%rip),%xmm1        # 3030 <_fini+0xf68>
    12ea:	00 
    12eb:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
    12ef:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    12f4:	66 0f 6f 15 44 1d 00 	movdqa 0x1d44(%rip),%xmm2        # 3040 <_fini+0xf78>
    12fb:	00 
    12fc:	66 0f 6f 1d 5c 1d 00 	movdqa 0x1d5c(%rip),%xmm3        # 3060 <_fini+0xf98>
    1303:	00 
    1304:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    130b:	00 00 00 00 00 
    1310:	66 0f 6f e0          	movdqa %xmm0,%xmm4
    1314:	66 0f fe e1          	paddd  %xmm1,%xmm4
    1318:	66 0f db e2          	pand   %xmm2,%xmm4
    131c:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    1320:	66 0f 67 e4          	packuswb %xmm4,%xmm4
    1324:	66 0f 7e 24 0f       	movd   %xmm4,(%rdi,%rcx,1)
    1329:	48 83 c1 04          	add    $0x4,%rcx
    132d:	66 0f fe cb          	paddd  %xmm3,%xmm1
    1331:	48 39 c8             	cmp    %rcx,%rax
    1334:	75 da                	jne    1310 <calculate+0x160>
    1336:	48 39 c3             	cmp    %rax,%rbx
    1339:	74 13                	je     134e <calculate+0x19e>
    133b:	89 e9                	mov    %ebp,%ecx
    133d:	0f 1f 00             	nopl   (%rax)
    1340:	8d 14 01             	lea    (%rcx,%rax,1),%edx
    1343:	88 14 07             	mov    %dl,(%rdi,%rax,1)
    1346:	48 ff c0             	inc    %rax
    1349:	48 39 c3             	cmp    %rax,%rbx
    134c:	75 f2                	jne    1340 <calculate+0x190>
    134e:	31 c0                	xor    %eax,%eax
    1350:	45 31 f6             	xor    %r14d,%r14d
    1353:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    135a:	84 00 00 00 00 00 
    1360:	4c 89 f1             	mov    %r14,%rcx
    1363:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1368:	49 01 ce             	add    %rcx,%r14
    136b:	72 15                	jb     1382 <calculate+0x1d2>
    136d:	48 ff c0             	inc    %rax
    1370:	48 39 c3             	cmp    %rax,%rbx
    1373:	75 eb                	jne    1360 <calculate+0x1b0>
    1375:	e8 16 fd ff ff       	call   1090 <__wrap_free@plt>
    137a:	4c 89 f0             	mov    %r14,%rax
    137d:	5b                   	pop    %rbx
    137e:	41 5e                	pop    %r14
    1380:	5d                   	pop    %rbp
    1381:	c3                   	ret
    1382:	e8 b9 fc ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
