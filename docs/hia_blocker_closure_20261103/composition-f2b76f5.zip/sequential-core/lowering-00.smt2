(declare-fun right () (_ BitVec 32))
(declare-fun left () (_ BitVec 32))
(assert (let ((a!1 (distinct false (or false (and true (distinct 0 0)))))
      (a!2 (distinct (or (and true (= 0 0))) (or true)))
      (a!3 (and (and true (= 0 0))
                true
                (distinct (bvsub (bvadd left right #x00000011) #x00000011)
                          (bvsub (bvadd left right #x00000011) #x00000011)))))
  (or false a!1 a!2 a!3)))

(check-sat)
