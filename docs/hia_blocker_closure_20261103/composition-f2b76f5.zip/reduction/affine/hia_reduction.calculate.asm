
/home/runner/work/_temp/hia-composition/reduction/affine/hia_reduction.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	89 f5                	mov    %esi,%ebp
    11b6:	48 89 fb             	mov    %rdi,%rbx
    11b9:	48 b8 02 01 01 01 01 	movabs $0x101010101010102,%rax
    11c0:	01 01 01 
    11c3:	48 39 c7             	cmp    %rax,%rdi
    11c6:	73 38                	jae    1200 <calculate+0x50>
    11c8:	48 85 db             	test   %rbx,%rbx
    11cb:	0f 84 77 01 00 00    	je     1348 <calculate+0x198>
    11d1:	48 89 df             	mov    %rbx,%rdi
    11d4:	e8 77 fe ff ff       	call   1050 <__wrap_malloc@plt>
    11d9:	48 85 c0             	test   %rax,%rax
    11dc:	0f 84 6e 01 00 00    	je     1350 <calculate+0x1a0>
    11e2:	48 89 c7             	mov    %rax,%rdi
    11e5:	48 ba f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rdx
    11ec:	ff ff 01 
    11ef:	48 83 fb 03          	cmp    $0x3,%rbx
    11f3:	0f 87 62 01 00 00    	ja     135b <calculate+0x1ab>
    11f9:	31 c9                	xor    %ecx,%ecx
    11fb:	e9 7f 02 00 00       	jmp    147f <calculate+0x2cf>
    1200:	48 85 db             	test   %rbx,%rbx
    1203:	78 2a                	js     122f <calculate+0x7f>
    1205:	48 89 df             	mov    %rbx,%rdi
    1208:	e8 43 fe ff ff       	call   1050 <__wrap_malloc@plt>
    120d:	48 85 c0             	test   %rax,%rax
    1210:	74 1d                	je     122f <calculate+0x7f>
    1212:	48 89 c7             	mov    %rax,%rdi
    1215:	b0 01                	mov    $0x1,%al
    1217:	a8 01                	test   $0x1,%al
    1219:	75 1c                	jne    1237 <calculate+0x87>
    121b:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1221:	48 85 ff             	test   %rdi,%rdi
    1224:	0f 85 4b 03 00 00    	jne    1575 <calculate+0x3c5>
    122a:	e9 4b 03 00 00       	jmp    157a <calculate+0x3ca>
    122f:	31 ff                	xor    %edi,%edi
    1231:	31 c0                	xor    %eax,%eax
    1233:	a8 01                	test   $0x1,%al
    1235:	74 e4                	je     121b <calculate+0x6b>
    1237:	48 89 d8             	mov    %rbx,%rax
    123a:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
    123e:	66 0f 6e c5          	movd   %ebp,%xmm0
    1242:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1246:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    124b:	66 0f 70 c8 00       	pshufd $0x0,%xmm0,%xmm1
    1250:	66 0f 6f 15 a8 1d 00 	movdqa 0x1da8(%rip),%xmm2        # 3000 <_fini+0xd38>
    1257:	00 
    1258:	31 c9                	xor    %ecx,%ecx
    125a:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    125e:	66 0f 68 db          	punpckhbw %xmm3,%xmm3
    1262:	66 0f 6f 05 a6 1d 00 	movdqa 0x1da6(%rip),%xmm0        # 3010 <_fini+0xd48>
    1269:	00 
    126a:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    126e:	66 0f 6f 25 aa 1d 00 	movdqa 0x1daa(%rip),%xmm4        # 3020 <_fini+0xd58>
    1275:	00 
    1276:	66 0f 6f 2d b2 1d 00 	movdqa 0x1db2(%rip),%xmm5        # 3030 <_fini+0xd68>
    127d:	00 
    127e:	66 90                	xchg   %ax,%ax
    1280:	66 0f 6f f2          	movdqa %xmm2,%xmm6
    1284:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
    1288:	66 0f d5 f3          	pmullw %xmm3,%xmm6
    128c:	66 0f db f0          	pand   %xmm0,%xmm6
    1290:	66 0f 6f fa          	movdqa %xmm2,%xmm7
    1294:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    1298:	66 0f d5 f9          	pmullw %xmm1,%xmm7
    129c:	66 0f db f8          	pand   %xmm0,%xmm7
    12a0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
    12a4:	66 0f fc fc          	paddb  %xmm4,%xmm7
    12a8:	f3 0f 7f 3c 0f       	movdqu %xmm7,(%rdi,%rcx,1)
    12ad:	48 83 c1 10          	add    $0x10,%rcx
    12b1:	66 0f fc d5          	paddb  %xmm5,%xmm2
    12b5:	48 39 c8             	cmp    %rcx,%rax
    12b8:	75 c6                	jne    1280 <calculate+0xd0>
    12ba:	48 39 c3             	cmp    %rax,%rbx
    12bd:	0f 84 8b 02 00 00    	je     154e <calculate+0x39e>
    12c3:	f6 c3 0c             	test   $0xc,%bl
    12c6:	0f 84 65 02 00 00    	je     1531 <calculate+0x381>
    12cc:	48 89 d9             	mov    %rbx,%rcx
    12cf:	66 0f 6e c8          	movd   %eax,%xmm1
    12d3:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    12d7:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    12dc:	66 0f eb 0d 5c 1d 00 	por    0x1d5c(%rip),%xmm1        # 3040 <_fini+0xd78>
    12e3:	00 
    12e4:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
    12e8:	40 0f b6 d5          	movzbl %bpl,%edx
    12ec:	66 0f 6e d2          	movd   %edx,%xmm2
    12f0:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
    12f4:	f2 0f 70 d2 00       	pshuflw $0x0,%xmm2,%xmm2
    12f9:	66 0f 60 d2          	punpcklbw %xmm2,%xmm2
    12fd:	66 0f 6f 1d 4b 1d 00 	movdqa 0x1d4b(%rip),%xmm3        # 3050 <_fini+0xd88>
    1304:	00 
    1305:	66 0f 6f 25 53 1d 00 	movdqa 0x1d53(%rip),%xmm4        # 3060 <_fini+0xd98>
    130c:	00 
    130d:	0f 1f 00             	nopl   (%rax)
    1310:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    1314:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    1318:	66 0f d5 ea          	pmullw %xmm2,%xmm5
    131c:	66 0f db e8          	pand   %xmm0,%xmm5
    1320:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    1324:	66 0f fc eb          	paddb  %xmm3,%xmm5
    1328:	66 0f 7e 2c 07       	movd   %xmm5,(%rdi,%rax,1)
    132d:	48 83 c0 04          	add    $0x4,%rax
    1331:	66 0f fc cc          	paddb  %xmm4,%xmm1
    1335:	48 39 c1             	cmp    %rax,%rcx
    1338:	75 d6                	jne    1310 <calculate+0x160>
    133a:	48 39 cb             	cmp    %rcx,%rbx
    133d:	0f 85 f1 01 00 00    	jne    1534 <calculate+0x384>
    1343:	e9 06 02 00 00       	jmp    154e <calculate+0x39e>
    1348:	45 31 f6             	xor    %r14d,%r14d
    134b:	e9 2a 02 00 00       	jmp    157a <calculate+0x3ca>
    1350:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1356:	e9 1f 02 00 00       	jmp    157a <calculate+0x3ca>
    135b:	40 0f b6 c5          	movzbl %bpl,%eax
    135f:	48 83 fb 10          	cmp    $0x10,%rbx
    1363:	73 07                	jae    136c <calculate+0x1bc>
    1365:	31 c9                	xor    %ecx,%ecx
    1367:	e9 9c 00 00 00       	jmp    1408 <calculate+0x258>
    136c:	48 89 d9             	mov    %rbx,%rcx
    136f:	48 21 d1             	and    %rdx,%rcx
    1372:	66 0f 6e c0          	movd   %eax,%xmm0
    1376:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    137a:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    137f:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1384:	66 0f 6f 0d 74 1c 00 	movdqa 0x1c74(%rip),%xmm1        # 3000 <_fini+0xd38>
    138b:	00 
    138c:	31 f6                	xor    %esi,%esi
    138e:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    1392:	66 0f 68 d2          	punpckhbw %xmm2,%xmm2
    1396:	66 0f 6f 1d 72 1c 00 	movdqa 0x1c72(%rip),%xmm3        # 3010 <_fini+0xd48>
    139d:	00 
    139e:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    13a2:	66 0f 6f 25 76 1c 00 	movdqa 0x1c76(%rip),%xmm4        # 3020 <_fini+0xd58>
    13a9:	00 
    13aa:	66 0f 6f 2d 7e 1c 00 	movdqa 0x1c7e(%rip),%xmm5        # 3030 <_fini+0xd68>
    13b1:	00 
    13b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    13b9:	1f 84 00 00 00 00 00 
    13c0:	66 0f 6f f1          	movdqa %xmm1,%xmm6
    13c4:	66 0f 68 f6          	punpckhbw %xmm6,%xmm6
    13c8:	66 0f d5 f2          	pmullw %xmm2,%xmm6
    13cc:	66 0f db f3          	pand   %xmm3,%xmm6
    13d0:	66 0f 6f f9          	movdqa %xmm1,%xmm7
    13d4:	66 0f 60 ff          	punpcklbw %xmm7,%xmm7
    13d8:	66 0f d5 f8          	pmullw %xmm0,%xmm7
    13dc:	66 0f db fb          	pand   %xmm3,%xmm7
    13e0:	66 0f 67 fe          	packuswb %xmm6,%xmm7
    13e4:	66 0f fc fc          	paddb  %xmm4,%xmm7
    13e8:	f3 0f 7f 3c 37       	movdqu %xmm7,(%rdi,%rsi,1)
    13ed:	48 83 c6 10          	add    $0x10,%rsi
    13f1:	66 0f fc cd          	paddb  %xmm5,%xmm1
    13f5:	48 39 f1             	cmp    %rsi,%rcx
    13f8:	75 c6                	jne    13c0 <calculate+0x210>
    13fa:	48 39 cb             	cmp    %rcx,%rbx
    13fd:	0f 84 9b 00 00 00    	je     149e <calculate+0x2ee>
    1403:	f6 c3 0c             	test   $0xc,%bl
    1406:	74 77                	je     147f <calculate+0x2cf>
    1408:	48 89 ce             	mov    %rcx,%rsi
    140b:	48 8d 4a 0c          	lea    0xc(%rdx),%rcx
    140f:	66 0f 6e c6          	movd   %esi,%xmm0
    1413:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1417:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    141c:	66 0f eb 05 1c 1c 00 	por    0x1c1c(%rip),%xmm0        # 3040 <_fini+0xd78>
    1423:	00 
    1424:	48 21 d9             	and    %rbx,%rcx
    1427:	66 0f 6e c8          	movd   %eax,%xmm1
    142b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    142f:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    1434:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    1438:	66 0f 6f 15 d0 1b 00 	movdqa 0x1bd0(%rip),%xmm2        # 3010 <_fini+0xd48>
    143f:	00 
    1440:	66 0f 6f 1d 08 1c 00 	movdqa 0x1c08(%rip),%xmm3        # 3050 <_fini+0xd88>
    1447:	00 
    1448:	66 0f 6f 25 10 1c 00 	movdqa 0x1c10(%rip),%xmm4        # 3060 <_fini+0xd98>
    144f:	00 
    1450:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    1454:	66 0f 60 ed          	punpcklbw %xmm5,%xmm5
    1458:	66 0f d5 e9          	pmullw %xmm1,%xmm5
    145c:	66 0f db ea          	pand   %xmm2,%xmm5
    1460:	66 0f 67 ed          	packuswb %xmm5,%xmm5
    1464:	66 0f fc eb          	paddb  %xmm3,%xmm5
    1468:	66 0f 7e 2c 37       	movd   %xmm5,(%rdi,%rsi,1)
    146d:	48 83 c6 04          	add    $0x4,%rsi
    1471:	66 0f fc c4          	paddb  %xmm4,%xmm0
    1475:	48 39 f1             	cmp    %rsi,%rcx
    1478:	75 d6                	jne    1450 <calculate+0x2a0>
    147a:	48 39 cb             	cmp    %rcx,%rbx
    147d:	74 1f                	je     149e <calculate+0x2ee>
    147f:	89 c8                	mov    %ecx,%eax
    1481:	40 f6 e5             	mul    %bpl
    1484:	04 11                	add    $0x11,%al
    1486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    148d:	00 00 00 
    1490:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    1493:	48 ff c1             	inc    %rcx
    1496:	40 00 e8             	add    %bpl,%al
    1499:	48 39 cb             	cmp    %rcx,%rbx
    149c:	75 f2                	jne    1490 <calculate+0x2e0>
    149e:	89 d8                	mov    %ebx,%eax
    14a0:	83 e0 07             	and    $0x7,%eax
    14a3:	48 83 fb 08          	cmp    $0x8,%rbx
    14a7:	73 07                	jae    14b0 <calculate+0x300>
    14a9:	31 c9                	xor    %ecx,%ecx
    14ab:	45 31 f6             	xor    %r14d,%r14d
    14ae:	eb 5a                	jmp    150a <calculate+0x35a>
    14b0:	48 83 c2 08          	add    $0x8,%rdx
    14b4:	48 21 d3             	and    %rdx,%rbx
    14b7:	31 c9                	xor    %ecx,%ecx
    14b9:	45 31 f6             	xor    %r14d,%r14d
    14bc:	0f 1f 40 00          	nopl   0x0(%rax)
    14c0:	0f b6 14 0f          	movzbl (%rdi,%rcx,1),%edx
    14c4:	4c 01 f2             	add    %r14,%rdx
    14c7:	0f b6 74 0f 01       	movzbl 0x1(%rdi,%rcx,1),%esi
    14cc:	44 0f b6 44 0f 02    	movzbl 0x2(%rdi,%rcx,1),%r8d
    14d2:	49 01 f0             	add    %rsi,%r8
    14d5:	49 01 d0             	add    %rdx,%r8
    14d8:	0f b6 54 0f 03       	movzbl 0x3(%rdi,%rcx,1),%edx
    14dd:	0f b6 74 0f 04       	movzbl 0x4(%rdi,%rcx,1),%esi
    14e2:	48 01 d6             	add    %rdx,%rsi
    14e5:	0f b6 54 0f 05       	movzbl 0x5(%rdi,%rcx,1),%edx
    14ea:	48 01 f2             	add    %rsi,%rdx
    14ed:	4c 01 c2             	add    %r8,%rdx
    14f0:	0f b6 74 0f 06       	movzbl 0x6(%rdi,%rcx,1),%esi
    14f5:	44 0f b6 74 0f 07    	movzbl 0x7(%rdi,%rcx,1),%r14d
    14fb:	49 01 f6             	add    %rsi,%r14
    14fe:	49 01 d6             	add    %rdx,%r14
    1501:	48 83 c1 08          	add    $0x8,%rcx
    1505:	48 39 cb             	cmp    %rcx,%rbx
    1508:	75 b6                	jne    14c0 <calculate+0x310>
    150a:	48 85 c0             	test   %rax,%rax
    150d:	74 66                	je     1575 <calculate+0x3c5>
    150f:	48 89 fa             	mov    %rdi,%rdx
    1512:	48 01 ca             	add    %rcx,%rdx
    1515:	31 c9                	xor    %ecx,%ecx
    1517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    151e:	00 00 
    1520:	0f b6 34 0a          	movzbl (%rdx,%rcx,1),%esi
    1524:	49 01 f6             	add    %rsi,%r14
    1527:	48 ff c1             	inc    %rcx
    152a:	48 39 c8             	cmp    %rcx,%rax
    152d:	75 f1                	jne    1520 <calculate+0x370>
    152f:	eb 44                	jmp    1575 <calculate+0x3c5>
    1531:	48 89 c1             	mov    %rax,%rcx
    1534:	89 c8                	mov    %ecx,%eax
    1536:	40 f6 e5             	mul    %bpl
    1539:	04 11                	add    $0x11,%al
    153b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1540:	88 04 0f             	mov    %al,(%rdi,%rcx,1)
    1543:	48 ff c1             	inc    %rcx
    1546:	40 00 e8             	add    %bpl,%al
    1549:	48 39 cb             	cmp    %rcx,%rbx
    154c:	75 f2                	jne    1540 <calculate+0x390>
    154e:	31 c0                	xor    %eax,%eax
    1550:	45 31 f6             	xor    %r14d,%r14d
    1553:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    155a:	84 00 00 00 00 00 
    1560:	4c 89 f1             	mov    %r14,%rcx
    1563:	44 0f b6 34 07       	movzbl (%rdi,%rax,1),%r14d
    1568:	49 01 ce             	add    %rcx,%r14
    156b:	72 15                	jb     1582 <calculate+0x3d2>
    156d:	48 ff c0             	inc    %rax
    1570:	48 39 c3             	cmp    %rax,%rbx
    1573:	75 eb                	jne    1560 <calculate+0x3b0>
    1575:	e8 16 fb ff ff       	call   1090 <__wrap_free@plt>
    157a:	4c 89 f0             	mov    %r14,%rax
    157d:	5b                   	pop    %rbx
    157e:	41 5e                	pop    %r14
    1580:	5d                   	pop    %rbp
    1581:	c3                   	ret
    1582:	e8 b9 fa ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
