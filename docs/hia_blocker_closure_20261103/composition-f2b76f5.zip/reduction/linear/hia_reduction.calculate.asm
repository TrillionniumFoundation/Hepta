
/home/runner/work/_temp/hia-composition/reduction/linear/hia_reduction.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000011b0 <calculate>:
    11b0:	55                   	push   %rbp
    11b1:	41 56                	push   %r14
    11b3:	53                   	push   %rbx
    11b4:	89 f5                	mov    %esi,%ebp
    11b6:	48 89 fb             	mov    %rdi,%rbx
    11b9:	48 b8 02 01 01 01 01 	movabs $0x101010101010102,%rax
    11c0:	01 01 01 
    11c3:	48 39 c7             	cmp    %rax,%rdi
    11c6:	73 35                	jae    11fd <calculate+0x4d>
    11c8:	48 85 db             	test   %rbx,%rbx
    11cb:	0f 84 27 01 00 00    	je     12f8 <calculate+0x148>
    11d1:	48 89 df             	mov    %rbx,%rdi
    11d4:	e8 77 fe ff ff       	call   1050 <__wrap_malloc@plt>
    11d9:	48 85 c0             	test   %rax,%rax
    11dc:	0f 84 1e 01 00 00    	je     1300 <calculate+0x150>
    11e2:	48 b9 f0 ff ff ff ff 	movabs $0x1fffffffffffff0,%rcx
    11e9:	ff ff 01 
    11ec:	48 83 fb 03          	cmp    $0x3,%rbx
    11f0:	0f 87 15 01 00 00    	ja     130b <calculate+0x15b>
    11f6:	31 d2                	xor    %edx,%edx
    11f8:	e9 d2 01 00 00       	jmp    13cf <calculate+0x21f>
    11fd:	48 85 db             	test   %rbx,%rbx
    1200:	78 28                	js     122a <calculate+0x7a>
    1202:	48 89 df             	mov    %rbx,%rdi
    1205:	e8 46 fe ff ff       	call   1050 <__wrap_malloc@plt>
    120a:	48 85 c0             	test   %rax,%rax
    120d:	74 1b                	je     122a <calculate+0x7a>
    120f:	b1 01                	mov    $0x1,%cl
    1211:	f6 c1 01             	test   $0x1,%cl
    1214:	75 1d                	jne    1233 <calculate+0x83>
    1216:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    121c:	48 85 c0             	test   %rax,%rax
    121f:	0f 85 a0 02 00 00    	jne    14c5 <calculate+0x315>
    1225:	e9 a3 02 00 00       	jmp    14cd <calculate+0x31d>
    122a:	31 c0                	xor    %eax,%eax
    122c:	31 c9                	xor    %ecx,%ecx
    122e:	f6 c1 01             	test   $0x1,%cl
    1231:	74 e3                	je     1216 <calculate+0x66>
    1233:	48 89 d9             	mov    %rbx,%rcx
    1236:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
    123a:	66 0f 6e c5          	movd   %ebp,%xmm0
    123e:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1242:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    1247:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    124c:	66 0f 6f 0d ac 1d 00 	movdqa 0x1dac(%rip),%xmm1        # 3000 <_fini+0xde8>
    1253:	00 
    1254:	31 d2                	xor    %edx,%edx
    1256:	66 0f 6f 15 b2 1d 00 	movdqa 0x1db2(%rip),%xmm2        # 3010 <_fini+0xdf8>
    125d:	00 
    125e:	66 90                	xchg   %ax,%ax
    1260:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1264:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1268:	f3 0f 7f 1c 10       	movdqu %xmm3,(%rax,%rdx,1)
    126d:	48 83 c2 10          	add    $0x10,%rdx
    1271:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1275:	48 39 d1             	cmp    %rdx,%rcx
    1278:	75 e6                	jne    1260 <calculate+0xb0>
    127a:	48 39 cb             	cmp    %rcx,%rbx
    127d:	0f 84 1c 02 00 00    	je     149f <calculate+0x2ef>
    1283:	f6 c3 0c             	test   $0xc,%bl
    1286:	0f 84 f5 01 00 00    	je     1481 <calculate+0x2d1>
    128c:	48 89 da             	mov    %rbx,%rdx
    128f:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    1293:	66 0f 6e c1          	movd   %ecx,%xmm0
    1297:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    129b:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    12a0:	66 0f eb 05 78 1d 00 	por    0x1d78(%rip),%xmm0        # 3020 <_fini+0xe08>
    12a7:	00 
    12a8:	40 0f b6 f5          	movzbl %bpl,%esi
    12ac:	66 0f 6e ce          	movd   %esi,%xmm1
    12b0:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    12b4:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    12b9:	66 0f 6f 15 6f 1d 00 	movdqa 0x1d6f(%rip),%xmm2        # 3030 <_fini+0xe18>
    12c0:	00 
    12c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    12c8:	0f 1f 84 00 00 00 00 
    12cf:	00 
    12d0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    12d4:	66 0f fc d9          	paddb  %xmm1,%xmm3
    12d8:	66 0f 7e 1c 08       	movd   %xmm3,(%rax,%rcx,1)
    12dd:	48 83 c1 04          	add    $0x4,%rcx
    12e1:	66 0f fc c2          	paddb  %xmm2,%xmm0
    12e5:	48 39 ca             	cmp    %rcx,%rdx
    12e8:	75 e6                	jne    12d0 <calculate+0x120>
    12ea:	48 39 d3             	cmp    %rdx,%rbx
    12ed:	0f 85 91 01 00 00    	jne    1484 <calculate+0x2d4>
    12f3:	e9 a7 01 00 00       	jmp    149f <calculate+0x2ef>
    12f8:	45 31 f6             	xor    %r14d,%r14d
    12fb:	e9 cd 01 00 00       	jmp    14cd <calculate+0x31d>
    1300:	41 be e9 03 00 00    	mov    $0x3e9,%r14d
    1306:	e9 c2 01 00 00       	jmp    14cd <calculate+0x31d>
    130b:	40 0f b6 f5          	movzbl %bpl,%esi
    130f:	48 83 fb 10          	cmp    $0x10,%rbx
    1313:	73 04                	jae    1319 <calculate+0x169>
    1315:	31 d2                	xor    %edx,%edx
    1317:	eb 5f                	jmp    1378 <calculate+0x1c8>
    1319:	48 89 da             	mov    %rbx,%rdx
    131c:	48 21 ca             	and    %rcx,%rdx
    131f:	66 0f 6e c6          	movd   %esi,%xmm0
    1323:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    1327:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    132c:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    1331:	66 0f 6f 0d c7 1c 00 	movdqa 0x1cc7(%rip),%xmm1        # 3000 <_fini+0xde8>
    1338:	00 
    1339:	31 ff                	xor    %edi,%edi
    133b:	66 0f 6f 15 cd 1c 00 	movdqa 0x1ccd(%rip),%xmm2        # 3010 <_fini+0xdf8>
    1342:	00 
    1343:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    134a:	84 00 00 00 00 00 
    1350:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    1354:	66 0f fc d8          	paddb  %xmm0,%xmm3
    1358:	f3 0f 7f 1c 38       	movdqu %xmm3,(%rax,%rdi,1)
    135d:	48 83 c7 10          	add    $0x10,%rdi
    1361:	66 0f fc ca          	paddb  %xmm2,%xmm1
    1365:	48 39 fa             	cmp    %rdi,%rdx
    1368:	75 e6                	jne    1350 <calculate+0x1a0>
    136a:	48 39 d3             	cmp    %rdx,%rbx
    136d:	0f 84 7c 00 00 00    	je     13ef <calculate+0x23f>
    1373:	f6 c3 0c             	test   $0xc,%bl
    1376:	74 57                	je     13cf <calculate+0x21f>
    1378:	48 89 d7             	mov    %rdx,%rdi
    137b:	48 8d 51 0c          	lea    0xc(%rcx),%rdx
    137f:	48 21 da             	and    %rbx,%rdx
    1382:	66 0f 6e c7          	movd   %edi,%xmm0
    1386:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
    138a:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
    138f:	66 0f eb 05 89 1c 00 	por    0x1c89(%rip),%xmm0        # 3020 <_fini+0xe08>
    1396:	00 
    1397:	66 0f 6e ce          	movd   %esi,%xmm1
    139b:	66 0f 60 c9          	punpcklbw %xmm1,%xmm1
    139f:	f2 0f 70 c9 00       	pshuflw $0x0,%xmm1,%xmm1
    13a4:	66 0f 6f 15 84 1c 00 	movdqa 0x1c84(%rip),%xmm2        # 3030 <_fini+0xe18>
    13ab:	00 
    13ac:	0f 1f 40 00          	nopl   0x0(%rax)
    13b0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    13b4:	66 0f fc d9          	paddb  %xmm1,%xmm3
    13b8:	66 0f 7e 1c 38       	movd   %xmm3,(%rax,%rdi,1)
    13bd:	48 83 c7 04          	add    $0x4,%rdi
    13c1:	66 0f fc c2          	paddb  %xmm2,%xmm0
    13c5:	48 39 fa             	cmp    %rdi,%rdx
    13c8:	75 e6                	jne    13b0 <calculate+0x200>
    13ca:	48 39 d3             	cmp    %rdx,%rbx
    13cd:	74 20                	je     13ef <calculate+0x23f>
    13cf:	89 ee                	mov    %ebp,%esi
    13d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    13d8:	0f 1f 84 00 00 00 00 
    13df:	00 
    13e0:	8d 3c 16             	lea    (%rsi,%rdx,1),%edi
    13e3:	40 88 3c 10          	mov    %dil,(%rax,%rdx,1)
    13e7:	48 ff c2             	inc    %rdx
    13ea:	48 39 d3             	cmp    %rdx,%rbx
    13ed:	75 f1                	jne    13e0 <calculate+0x230>
    13ef:	89 da                	mov    %ebx,%edx
    13f1:	83 e2 07             	and    $0x7,%edx
    13f4:	48 83 fb 08          	cmp    $0x8,%rbx
    13f8:	73 07                	jae    1401 <calculate+0x251>
    13fa:	31 c9                	xor    %ecx,%ecx
    13fc:	45 31 f6             	xor    %r14d,%r14d
    13ff:	eb 59                	jmp    145a <calculate+0x2aa>
    1401:	48 83 c1 08          	add    $0x8,%rcx
    1405:	48 21 cb             	and    %rcx,%rbx
    1408:	31 c9                	xor    %ecx,%ecx
    140a:	45 31 f6             	xor    %r14d,%r14d
    140d:	0f 1f 00             	nopl   (%rax)
    1410:	0f b6 34 08          	movzbl (%rax,%rcx,1),%esi
    1414:	4c 01 f6             	add    %r14,%rsi
    1417:	0f b6 7c 08 01       	movzbl 0x1(%rax,%rcx,1),%edi
    141c:	44 0f b6 44 08 02    	movzbl 0x2(%rax,%rcx,1),%r8d
    1422:	49 01 f8             	add    %rdi,%r8
    1425:	49 01 f0             	add    %rsi,%r8
    1428:	0f b6 74 08 03       	movzbl 0x3(%rax,%rcx,1),%esi
    142d:	0f b6 7c 08 04       	movzbl 0x4(%rax,%rcx,1),%edi
    1432:	48 01 f7             	add    %rsi,%rdi
    1435:	0f b6 74 08 05       	movzbl 0x5(%rax,%rcx,1),%esi
    143a:	48 01 fe             	add    %rdi,%rsi
    143d:	4c 01 c6             	add    %r8,%rsi
    1440:	0f b6 7c 08 06       	movzbl 0x6(%rax,%rcx,1),%edi
    1445:	44 0f b6 74 08 07    	movzbl 0x7(%rax,%rcx,1),%r14d
    144b:	49 01 fe             	add    %rdi,%r14
    144e:	49 01 f6             	add    %rsi,%r14
    1451:	48 83 c1 08          	add    $0x8,%rcx
    1455:	48 39 cb             	cmp    %rcx,%rbx
    1458:	75 b6                	jne    1410 <calculate+0x260>
    145a:	48 85 d2             	test   %rdx,%rdx
    145d:	74 66                	je     14c5 <calculate+0x315>
    145f:	48 89 c6             	mov    %rax,%rsi
    1462:	48 01 ce             	add    %rcx,%rsi
    1465:	31 c9                	xor    %ecx,%ecx
    1467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    146e:	00 00 
    1470:	0f b6 3c 0e          	movzbl (%rsi,%rcx,1),%edi
    1474:	49 01 fe             	add    %rdi,%r14
    1477:	48 ff c1             	inc    %rcx
    147a:	48 39 ca             	cmp    %rcx,%rdx
    147d:	75 f1                	jne    1470 <calculate+0x2c0>
    147f:	eb 44                	jmp    14c5 <calculate+0x315>
    1481:	48 89 ca             	mov    %rcx,%rdx
    1484:	89 e9                	mov    %ebp,%ecx
    1486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    148d:	00 00 00 
    1490:	8d 34 11             	lea    (%rcx,%rdx,1),%esi
    1493:	40 88 34 10          	mov    %sil,(%rax,%rdx,1)
    1497:	48 ff c2             	inc    %rdx
    149a:	48 39 d3             	cmp    %rdx,%rbx
    149d:	75 f1                	jne    1490 <calculate+0x2e0>
    149f:	31 c9                	xor    %ecx,%ecx
    14a1:	45 31 f6             	xor    %r14d,%r14d
    14a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    14ab:	00 00 00 00 00 
    14b0:	4c 89 f2             	mov    %r14,%rdx
    14b3:	44 0f b6 34 08       	movzbl (%rax,%rcx,1),%r14d
    14b8:	49 01 d6             	add    %rdx,%r14
    14bb:	72 18                	jb     14d5 <calculate+0x325>
    14bd:	48 ff c1             	inc    %rcx
    14c0:	48 39 cb             	cmp    %rcx,%rbx
    14c3:	75 eb                	jne    14b0 <calculate+0x300>
    14c5:	48 89 c7             	mov    %rax,%rdi
    14c8:	e8 c3 fb ff ff       	call   1090 <__wrap_free@plt>
    14cd:	4c 89 f0             	mov    %r14,%rax
    14d0:	5b                   	pop    %rbx
    14d1:	41 5e                	pop    %r14
    14d3:	5d                   	pop    %rbp
    14d4:	c3                   	ret
    14d5:	e8 66 fb ff ff       	call   1040 <abort@plt>

Disassembly of section .fini:
