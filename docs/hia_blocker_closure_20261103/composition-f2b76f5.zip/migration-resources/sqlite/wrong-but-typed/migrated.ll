; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i1 %p_0_0) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  ret i32 1
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  ret i32 0
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_1(%hia.buffer %p_0_0) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = icmp ule i64 4, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ 4, %edge_0 ]
  %p_1_2 = phi i64 [ 4, %edge_0 ]
  %p_1_3 = phi i64 [ %t1, %edge_0 ]
  %p_1_4 = phi i1 [ %t2, %edge_0 ]
  %t3 = trunc i64 0 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = extractvalue %hia.buffer %p_1_0, 0
  %t6 = extractvalue %hia.buffer %p_1_0, 1
  %t7 = icmp ult i64 %t4, %t6
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = getelementptr i8, ptr %t5, i64 %t4
  %t10 = load i8, ptr %t9, align 1
  %t11 = zext i8 %t10 to i32
  %t12 = trunc i64 24 to i32
  %t13 = icmp ult i32 %t12, 32
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = shl i32 %t11, %t12
  %t16 = trunc i64 1 to i32
  %t17 = sext i32 %t16 to i64
  %t18 = extractvalue %hia.buffer %p_1_0, 0
  %t19 = extractvalue %hia.buffer %p_1_0, 1
  %t20 = icmp ult i64 %t17, %t19
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  %t22 = getelementptr i8, ptr %t18, i64 %t17
  %t23 = load i8, ptr %t22, align 1
  %t24 = zext i8 %t23 to i32
  %t25 = trunc i64 15 to i32
  %t26 = icmp ult i32 %t25, 32
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  %t28 = shl i32 %t24, %t25
  %t29 = or i32 %t15, %t28
  %t30 = trunc i64 2 to i32
  %t31 = sext i32 %t30 to i64
  %t32 = extractvalue %hia.buffer %p_1_0, 0
  %t33 = extractvalue %hia.buffer %p_1_0, 1
  %t34 = icmp ult i64 %t31, %t33
  br i1 %t34, label %ok_35, label %trap_35
trap_35:
  call void @abort()
  unreachable
ok_35:
  %t36 = getelementptr i8, ptr %t32, i64 %t31
  %t37 = load i8, ptr %t36, align 1
  %t38 = zext i8 %t37 to i32
  %t39 = trunc i64 8 to i32
  %t40 = icmp ult i32 %t39, 32
  br i1 %t40, label %ok_41, label %trap_41
trap_41:
  call void @abort()
  unreachable
ok_41:
  %t42 = shl i32 %t38, %t39
  %t43 = or i32 %t29, %t42
  %t44 = trunc i64 3 to i32
  %t45 = sext i32 %t44 to i64
  %t46 = extractvalue %hia.buffer %p_1_0, 0
  %t47 = extractvalue %hia.buffer %p_1_0, 1
  %t48 = icmp ult i64 %t45, %t47
  br i1 %t48, label %ok_49, label %trap_49
trap_49:
  call void @abort()
  unreachable
ok_49:
  %t50 = getelementptr i8, ptr %t46, i64 %t45
  %t51 = load i8, ptr %t50, align 1
  %t52 = zext i8 %t51 to i32
  %t53 = or i32 %t43, %t52
  ret i32 %t53
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ 4, %edge_1 ]
  %p_2_2 = phi i64 [ 4, %edge_1 ]
  %p_2_3 = phi i64 [ %t1, %edge_1 ]
  %p_2_4 = phi i1 [ %t2, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal void @__hia_fn_2(%hia.buffer %p_0_0, i32 %p_0_1) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = icmp ule i64 4, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i32 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ 4, %edge_0 ]
  %p_1_3 = phi i64 [ 4, %edge_0 ]
  %p_1_4 = phi i64 [ %t1, %edge_0 ]
  %p_1_5 = phi i1 [ %t2, %edge_0 ]
  %t3 = trunc i64 24 to i32
  %t4 = icmp ult i32 %t3, 32
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = lshr i32 %p_1_1, %t3
  %t7 = trunc i32 %t6 to i8
  %t8 = trunc i64 0 to i32
  %t9 = sext i32 %t8 to i64
  %t10 = extractvalue %hia.buffer %p_1_0, 0
  %t11 = extractvalue %hia.buffer %p_1_0, 1
  %t12 = icmp ult i64 %t9, %t11
  br i1 %t12, label %ok_13, label %trap_13
trap_13:
  call void @abort()
  unreachable
ok_13:
  %t14 = getelementptr i8, ptr %t10, i64 %t9
  store i8 %t7, ptr %t14, align 1
  %t15 = trunc i64 16 to i32
  %t16 = icmp ult i32 %t15, 32
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = lshr i32 %p_1_1, %t15
  %t19 = trunc i32 %t18 to i8
  %t20 = trunc i64 1 to i32
  %t21 = sext i32 %t20 to i64
  %t22 = extractvalue %hia.buffer %p_1_0, 0
  %t23 = extractvalue %hia.buffer %p_1_0, 1
  %t24 = icmp ult i64 %t21, %t23
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = getelementptr i8, ptr %t22, i64 %t21
  store i8 %t19, ptr %t26, align 1
  %t27 = trunc i64 8 to i32
  %t28 = icmp ult i32 %t27, 32
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  %t30 = lshr i32 %p_1_1, %t27
  %t31 = trunc i32 %t30 to i8
  %t32 = trunc i64 2 to i32
  %t33 = sext i32 %t32 to i64
  %t34 = extractvalue %hia.buffer %p_1_0, 0
  %t35 = extractvalue %hia.buffer %p_1_0, 1
  %t36 = icmp ult i64 %t33, %t35
  br i1 %t36, label %ok_37, label %trap_37
trap_37:
  call void @abort()
  unreachable
ok_37:
  %t38 = getelementptr i8, ptr %t34, i64 %t33
  store i8 %t31, ptr %t38, align 1
  %t39 = trunc i32 %p_1_1 to i8
  %t40 = trunc i64 3 to i32
  %t41 = sext i32 %t40 to i64
  %t42 = extractvalue %hia.buffer %p_1_0, 0
  %t43 = extractvalue %hia.buffer %p_1_0, 1
  %t44 = icmp ult i64 %t41, %t43
  br i1 %t44, label %ok_45, label %trap_45
trap_45:
  call void @abort()
  unreachable
ok_45:
  %t46 = getelementptr i8, ptr %t42, i64 %t41
  store i8 %t39, ptr %t46, align 1
  ret void
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i32 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ 4, %edge_1 ]
  %p_2_3 = phi i64 [ 4, %edge_1 ]
  %p_2_4 = phi i64 [ %t1, %edge_1 ]
  %p_2_5 = phi i1 [ %t2, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i32 @__hia_fn_3(i32 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 4, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 4, 1
  %t6 = icmp ult i32 24, 32
  br i1 %t6, label %ok_7, label %trap_7
trap_7:
  call void @abort()
  unreachable
ok_7:
  %t8 = lshr i32 %p_0_0, 24
  %t9 = trunc i32 %t8 to i8
  %t10 = extractvalue %hia.buffer %t5, 0
  %t11 = extractvalue %hia.buffer %t5, 1
  %t12 = icmp ult i64 0, %t11
  br i1 %t12, label %ok_13, label %trap_13
trap_13:
  call void @abort()
  unreachable
ok_13:
  %t14 = getelementptr i8, ptr %t10, i64 0
  store i8 %t9, ptr %t14, align 1
  %t15 = icmp ult i32 16, 32
  br i1 %t15, label %ok_16, label %trap_16
trap_16:
  call void @abort()
  unreachable
ok_16:
  %t17 = lshr i32 %p_0_0, 16
  %t18 = trunc i32 %t17 to i8
  %t19 = extractvalue %hia.buffer %t5, 0
  %t20 = extractvalue %hia.buffer %t5, 1
  %t21 = icmp ult i64 1, %t20
  br i1 %t21, label %ok_22, label %trap_22
trap_22:
  call void @abort()
  unreachable
ok_22:
  %t23 = getelementptr i8, ptr %t19, i64 1
  store i8 %t18, ptr %t23, align 1
  %t24 = icmp ult i32 8, 32
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = lshr i32 %p_0_0, 8
  %t27 = trunc i32 %t26 to i8
  %t28 = extractvalue %hia.buffer %t5, 0
  %t29 = extractvalue %hia.buffer %t5, 1
  %t30 = icmp ult i64 2, %t29
  br i1 %t30, label %ok_31, label %trap_31
trap_31:
  call void @abort()
  unreachable
ok_31:
  %t32 = getelementptr i8, ptr %t28, i64 2
  store i8 %t27, ptr %t32, align 1
  %t33 = trunc i32 %p_0_0 to i8
  %t34 = extractvalue %hia.buffer %t5, 0
  %t35 = extractvalue %hia.buffer %t5, 1
  %t36 = icmp ult i64 3, %t35
  br i1 %t36, label %ok_37, label %trap_37
trap_37:
  call void @abort()
  unreachable
ok_37:
  %t38 = getelementptr i8, ptr %t34, i64 3
  store i8 %t33, ptr %t38, align 1
  %t39 = call i32 @__hia_fn_1(%hia.buffer %t5)
  %t40 = extractvalue %hia.buffer %t5, 0
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %drop_nonnull_42, label %drop_after_42
drop_nonnull_42:
  call void @free(ptr %t40) nobuiltin
  br label %drop_after_42
drop_after_42:
  ret i32 %t39
}

define internal i64 @__hia_fn_4(i32 %p_0_0) {
b0:
  %t1 = call %hia.alloc @__hia_allocate(i64 6, i1 true)
  %t2 = extractvalue %hia.alloc %t1, 0
  %t3 = extractvalue %hia.alloc %t1, 1
  br i1 %t3, label %ok_4, label %trap_4
trap_4:
  call void @abort()
  unreachable
ok_4:
  %t5 = insertvalue %hia.buffer %t2, i64 6, 1
  %t6 = extractvalue %hia.buffer %t5, 0
  %t7 = extractvalue %hia.buffer %t5, 1
  %t8 = icmp ult i64 4, %t7
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = getelementptr i8, ptr %t6, i64 4
  store i8 165, ptr %t10, align 1
  %t11 = extractvalue %hia.buffer %t5, 0
  %t12 = extractvalue %hia.buffer %t5, 1
  %t13 = icmp ult i64 5, %t12
  br i1 %t13, label %ok_14, label %trap_14
trap_14:
  call void @abort()
  unreachable
ok_14:
  %t15 = getelementptr i8, ptr %t11, i64 5
  store i8 90, ptr %t15, align 1
  call void @__hia_fn_2(%hia.buffer %t5, i32 %p_0_0)
  %t16 = extractvalue %hia.buffer %t5, 0
  %t17 = extractvalue %hia.buffer %t5, 1
  %t18 = icmp ult i64 0, %t17
  br i1 %t18, label %ok_19, label %trap_19
trap_19:
  call void @abort()
  unreachable
ok_19:
  %t20 = getelementptr i8, ptr %t16, i64 0
  %t21 = load i8, ptr %t20, align 1
  %t22 = zext i8 %t21 to i64
  %t23 = icmp ult i64 40, 64
  br i1 %t23, label %ok_24, label %trap_24
trap_24:
  call void @abort()
  unreachable
ok_24:
  %t25 = shl i64 %t22, 40
  %t26 = extractvalue %hia.buffer %t5, 0
  %t27 = extractvalue %hia.buffer %t5, 1
  %t28 = icmp ult i64 1, %t27
  br i1 %t28, label %ok_29, label %trap_29
trap_29:
  call void @abort()
  unreachable
ok_29:
  %t30 = getelementptr i8, ptr %t26, i64 1
  %t31 = load i8, ptr %t30, align 1
  %t32 = zext i8 %t31 to i64
  %t33 = icmp ult i64 32, 64
  br i1 %t33, label %ok_34, label %trap_34
trap_34:
  call void @abort()
  unreachable
ok_34:
  %t35 = shl i64 %t32, 32
  %t36 = or i64 %t25, %t35
  %t37 = extractvalue %hia.buffer %t5, 0
  %t38 = extractvalue %hia.buffer %t5, 1
  %t39 = icmp ult i64 2, %t38
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = getelementptr i8, ptr %t37, i64 2
  %t42 = load i8, ptr %t41, align 1
  %t43 = zext i8 %t42 to i64
  %t44 = icmp ult i64 24, 64
  br i1 %t44, label %ok_45, label %trap_45
trap_45:
  call void @abort()
  unreachable
ok_45:
  %t46 = shl i64 %t43, 24
  %t47 = or i64 %t36, %t46
  %t48 = extractvalue %hia.buffer %t5, 0
  %t49 = extractvalue %hia.buffer %t5, 1
  %t50 = icmp ult i64 3, %t49
  br i1 %t50, label %ok_51, label %trap_51
trap_51:
  call void @abort()
  unreachable
ok_51:
  %t52 = getelementptr i8, ptr %t48, i64 3
  %t53 = load i8, ptr %t52, align 1
  %t54 = zext i8 %t53 to i64
  %t55 = icmp ult i64 16, 64
  br i1 %t55, label %ok_56, label %trap_56
trap_56:
  call void @abort()
  unreachable
ok_56:
  %t57 = shl i64 %t54, 16
  %t58 = or i64 %t47, %t57
  %t59 = extractvalue %hia.buffer %t5, 0
  %t60 = extractvalue %hia.buffer %t5, 1
  %t61 = icmp ult i64 4, %t60
  br i1 %t61, label %ok_62, label %trap_62
trap_62:
  call void @abort()
  unreachable
ok_62:
  %t63 = getelementptr i8, ptr %t59, i64 4
  %t64 = load i8, ptr %t63, align 1
  %t65 = zext i8 %t64 to i64
  %t66 = icmp ult i64 8, 64
  br i1 %t66, label %ok_67, label %trap_67
trap_67:
  call void @abort()
  unreachable
ok_67:
  %t68 = shl i64 %t65, 8
  %t69 = or i64 %t58, %t68
  %t70 = extractvalue %hia.buffer %t5, 0
  %t71 = extractvalue %hia.buffer %t5, 1
  %t72 = icmp ult i64 5, %t71
  br i1 %t72, label %ok_73, label %trap_73
trap_73:
  call void @abort()
  unreachable
ok_73:
  %t74 = getelementptr i8, ptr %t70, i64 5
  %t75 = load i8, ptr %t74, align 1
  %t76 = zext i8 %t75 to i64
  %t77 = or i64 %t69, %t76
  %t78 = extractvalue %hia.buffer %t5, 0
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %drop_nonnull_80, label %drop_after_80
drop_nonnull_80:
  call void @free(ptr %t78) nobuiltin
  br label %drop_after_80
drop_after_80:
  ret i64 %t77
}

define i32 @c_bool_to_int(i1 zeroext %a0) {
entry:
  %result = call i32 @__hia_fn_0(i1 %a0)
  ret i32 %result
}

define i32 @migrated_get(i32 %a0) {
entry:
  %result = call i32 @__hia_fn_3(i32 %a0)
  ret i32 %result
}

define i64 @migrated_put(i32 %a0) {
entry:
  %result = call i64 @__hia_fn_4(i32 %a0)
  ret i64 %result
}
