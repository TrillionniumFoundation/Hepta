/-
Sequential Core capability-flow specification. Names are mathematical
naturals; kinds and origins are uninterpreted tags. This proves facts for
ALL finite capability lists and injective maps, without an execution-length
bound. It is not a proof of every instruction, Python, LLVM, FFI, or hardware.
Projection may forget only external capabilities and must keep the selected
graph closed. The trace theorems below compose these edge rules for every
finite trace; they do not model the intervening instructions in a CFG block.
-/
import Lean.Elab.Tactic.Omega

namespace HiaCapabilityRenaming

structure Capability where
  name : Nat
  root : Nat
  parent : Option Nat
  kind : Nat
  external : Bool
  origin : Option Nat
  deriving DecidableEq

def Injective (f : Nat → Nat) : Prop := ∀ a b, f a = f b → a = b

def rename (f : Nat → Nat) (c : Capability) : Capability :=
  { name := f c.name, root := f c.root, parent := c.parent.map f,
    kind := c.kind, external := c.external, origin := c.origin }

def ChildOf (child parent : Capability) : Prop := child.parent = some parent.name

def ExclusiveAlias (mutableKind : Nat) (a b : Capability) : Prop :=
  a.name ≠ b.name ∧ a.root = b.root ∧ (a.kind = mutableKind ∨ b.kind = mutableKind)

def Closed (caps : List Capability) : Prop :=
  ∀ c ∈ caps, (∃ root ∈ caps, root.name = c.root) ∧
    (∀ p, c.parent = some p → ∃ parent ∈ caps, parent.name = p)

theorem name_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).name = f c.name := rfl

theorem kind_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).kind = c.kind := rfl

theorem external_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).external = c.external := rfl

theorem origin_preserved (f : Nat → Nat) (c : Capability) :
    (rename f c).origin = c.origin := rfl

theorem name_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).name = (rename f b).name ↔ a.name = b.name := by
  constructor
  · exact inj a.name b.name
  · intro h; exact congrArg f h

theorem root_equal_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    (rename f a).root = (rename f b).root ↔ a.root = b.root := by
  constructor
  · exact inj a.root b.root
  · intro h; exact congrArg f h

theorem parent_map_iff (f : Nat → Nat) (inj : Injective f) (p : Option Nat) (n : Nat) :
    p.map f = some (f n) ↔ p = some n := by
  cases p with
  | none => simp
  | some p =>
      constructor
      · intro h; exact congrArg some (inj p n (Option.some.inj h))
      · intro h; cases h; rfl

theorem child_of_iff (f : Nat → Nat) (inj : Injective f) (a b : Capability) :
    ChildOf (rename f a) (rename f b) ↔ ChildOf a b := by
  exact parent_map_iff f inj a.parent b.name

theorem exclusive_alias_iff (f : Nat → Nat) (inj : Injective f)
    (mutableKind : Nat) (a b : Capability) :
    ExclusiveAlias mutableKind (rename f a) (rename f b) ↔
      ExclusiveAlias mutableKind a b := by
  simp only [ExclusiveAlias, ne_eq, name_equal_iff f inj,
             root_equal_iff f inj, kind_preserved]

theorem suspended_iff (f : Nat → Nat) (inj : Injective f)
    (caps : List Capability) (c : Capability) :
    (∃ child ∈ caps.map (rename f), ChildOf child (rename f c)) ↔
      (∃ child ∈ caps, ChildOf child c) := by
  constructor
  · rintro ⟨child, member, relation⟩
    obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
    exact ⟨old, oldMember, (child_of_iff f inj old c).mp relation⟩
  · rintro ⟨child, member, relation⟩
    exact ⟨rename f child, List.mem_map.mpr ⟨child, member, rfl⟩,
      (child_of_iff f inj child c).mpr relation⟩

theorem closed_preserved (f : Nat → Nat) (caps : List Capability)
    (closed : Closed caps) : Closed (caps.map (rename f)) := by
  intro c member
  obtain ⟨old, oldMember, rfl⟩ := List.mem_map.mp member
  obtain ⟨rootExists, parentExists⟩ := closed old oldMember
  obtain ⟨root, rootMember, rootName⟩ := rootExists
  constructor
  · exact ⟨rename f root, List.mem_map.mpr ⟨root, rootMember, rfl⟩,
      congrArg f rootName⟩
  · intro p relation
    cases hp : old.parent with
    | none => simp [rename, hp] at relation
    | some oldParent =>
        have mapped : f oldParent = p := by simpa [rename, hp] using relation
        obtain ⟨parent, parentMember, parentName⟩ := parentExists oldParent hp
        exact ⟨rename f parent, List.mem_map.mpr ⟨parent, parentMember, rfl⟩,
          (congrArg f parentName).trans mapped⟩

theorem number_preserved (f : Nat → Nat) (caps : List Capability) :
    (caps.map (rename f)).length = caps.length := by simp

theorem rename_composes (f g : Nat → Nat) (c : Capability) :
    rename g (rename f c) = rename (fun n => g (f n)) c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

theorem identity_rename (c : Capability) : rename (fun n => n) c = c := by
  cases c with
  | mk name root parent kind external origin =>
      cases parent <;> rfl

/- The executable helper selects a subset before renaming. Selection is a
filter, so it cannot invent or duplicate capabilities. The explicit retention
premise is exactly the helper's rule for local owners and local loans. -/

def project (keep : Nat → Bool) (caps : List Capability) : List Capability :=
  caps.filter (fun c => keep c.name)

def AdmissibleProjection (caps : List Capability) (keep : Nat → Bool) : Prop :=
  (∀ c ∈ caps, c.external = false → keep c.name = true) ∧ Closed (project keep caps)

def localInventory : List Capability → List (Nat × Option Nat)
  | [] => []
  | c :: rest =>
      if c.external then localInventory rest else (c.kind, c.origin) :: localInventory rest

theorem projected_member (caps : List Capability) (keep : Nat → Bool) (c : Capability) :
    c ∈ project keep caps ↔ c ∈ caps ∧ keep c.name = true := by
  simp [project]

theorem local_retained (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (localCap : c.external = false) : c ∈ project keep caps := by
  exact (projected_member caps keep c).mpr ⟨member, admitted.1 c member localCap⟩

theorem only_external_forgotten (caps : List Capability) (keep : Nat → Bool)
    (admitted : AdmissibleProjection caps keep) (c : Capability)
    (member : c ∈ caps) (forgotten : c ∉ project keep caps) : c.external = true := by
  cases external : c.external with
  | false => exact False.elim (forgotten (local_retained caps keep admitted c member external))
  | true => rfl

theorem local_inventory_projection (caps : List Capability) (keep : Nat → Bool)
    (retained : ∀ c ∈ caps, c.external = false → keep c.name = true) :
    localInventory (project keep caps) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih =>
      have restRetained : ∀ x ∈ rest, x.external = false → keep x.name = true := by
        intro x member external
        exact retained x (List.mem_cons_of_mem c member) external
      have tail := ih restRetained
      cases external : c.external with
      | false =>
          have kept := retained c (by simp) external
          simp [project, localInventory, external, kept] at tail ⊢
          exact tail
      | true =>
          cases kept : keep c.name <;> simp [project, localInventory, external, kept] at tail ⊢
          all_goals exact tail

theorem local_inventory_rename (caps : List Capability) (f : Nat → Nat) :
    localInventory (caps.map (rename f)) = localInventory caps := by
  induction caps with
  | nil => rfl
  | cons c rest ih => simp [localInventory, rename, ih]

/- Parent ranks are witnesses for strict descent, not runtime addresses or
integer counters. Their existence excludes every positive parent cycle. -/

def ParentRanks (caps : List Capability) (rank : Nat → Nat) : Prop :=
  ∀ child ∈ caps, ∀ parent ∈ caps, ChildOf child parent → rank parent.name < rank child.name

def Ranked (caps : List Capability) : Prop := ∃ rank, ParentRanks caps rank

inductive ParentPath (caps : List Capability) : Nat → Nat → Prop where
  | edge {child parent} : child ∈ caps → parent ∈ caps → ChildOf child parent →
      ParentPath caps child.name parent.name
  | trans {a b c} : ParentPath caps a b → ParentPath caps b c → ParentPath caps a c

theorem parent_path_descends (caps : List Capability) (rank : Nat → Nat)
    (ranked : ParentRanks caps rank) {a b : Nat} (path : ParentPath caps a b) :
    rank b < rank a := by
  induction path with
  | edge childMember parentMember relation => exact ranked _ childMember _ parentMember relation
  | trans _ _ left right => exact Nat.lt_trans right left

theorem ranked_no_parent_cycle (caps : List Capability) (ranked : Ranked caps) (name : Nat) :
    ¬ ParentPath caps name name := by
  intro path
  obtain ⟨rank, ordered⟩ := ranked
  exact (Nat.lt_irrefl (rank name)) (parent_path_descends caps rank ordered path)

theorem ranked_projection (caps : List Capability) (keep : Nat → Bool)
    (ranked : Ranked caps) : Ranked (project keep caps) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨rank, ?_⟩
  intro child childMember parent parentMember relation
  exact ordered child ((projected_member caps keep child).mp childMember).1
    parent ((projected_member caps keep parent).mp parentMember).1 relation

noncomputable def transportedRank (f rank : Nat → Nat) (name : Nat) : Nat := by
  classical
  exact if witness : ∃ before, f before = name then rank (Classical.choose witness) else 0

theorem transported_rank_at (f rank : Nat → Nat) (inj : Injective f) (name : Nat) :
    transportedRank f rank (f name) = rank name := by
  unfold transportedRank
  split
  next witness =>
    have same : Classical.choose witness = name := inj _ _ (Classical.choose_spec witness)
    rw [same]
  next absent => exact False.elim (absent ⟨name, rfl⟩)

theorem ranked_rename (caps : List Capability) (f : Nat → Nat)
    (inj : Injective f) (ranked : Ranked caps) : Ranked (caps.map (rename f)) := by
  obtain ⟨rank, ordered⟩ := ranked
  refine ⟨transportedRank f rank, ?_⟩
  intro child childMember parent parentMember relation
  obtain ⟨oldChild, oldChildMember, rfl⟩ := List.mem_map.mp childMember
  obtain ⟨oldParent, oldParentMember, rfl⟩ := List.mem_map.mp parentMember
  have oldRelation := (child_of_iff f inj oldChild oldParent).mp relation
  simpa only [name_preserved, transported_rank_at f rank inj] using
    ordered oldChild oldChildMember oldParent oldParentMember oldRelation

def Transfer (before after : List Capability) : Prop :=
  ∃ keep f, AdmissibleProjection before keep ∧ Injective f ∧
    after = (project keep before).map (rename f)

theorem transfer_closed {before after : List Capability} (step : Transfer before after) :
    Closed after := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  exact closed_preserved f (project keep before) admitted.2

theorem transfer_local_inventory {before after : List Capability} (step : Transfer before after) :
    localInventory after = localInventory before := by
  obtain ⟨keep, f, admitted, _, rfl⟩ := step
  rw [local_inventory_rename, local_inventory_projection before keep admitted.1]

theorem transfer_ranked {before after : List Capability} (step : Transfer before after)
    (ranked : Ranked before) : Ranked after := by
  obtain ⟨keep, f, _, inj, rfl⟩ := step
  exact ranked_rename (project keep before) f inj (ranked_projection before keep ranked)

inductive EdgeTrace : List Capability → List Capability → Prop where
  | refl (caps) : EdgeTrace caps caps
  | next {before middle after} : EdgeTrace before middle → Transfer middle after →
      EdgeTrace before after

theorem trace_local_inventory {before after : List Capability} (trace : EdgeTrace before after) :
    localInventory after = localInventory before := by
  induction trace with
  | refl => rfl
  | next _ step ih => exact (transfer_local_inventory step).trans ih

theorem trace_closed {before after : List Capability} (trace : EdgeTrace before after)
    (closed : Closed before) : Closed after := by
  cases trace with
  | refl => exact closed
  | next _ step => exact transfer_closed step

theorem trace_ranked {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) : Ranked after := by
  induction trace with
  | refl => exact ranked
  | next _ step ih => exact transfer_ranked step ih

theorem trace_no_parent_cycle {before after : List Capability} (trace : EdgeTrace before after)
    (ranked : Ranked before) (name : Nat) : ¬ ParentPath after name name :=
  ranked_no_parent_cycle after (trace_ranked trace ranked) name

end HiaCapabilityRenaming

namespace HiaCapabilityRenaming
def edge0Map (n : Nat) : Nat := n + 3
def edge0FullBefore : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 2), 2, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def edge0Keep (n : Nat) : Bool := decide (n ∈ [0, 1, 2])
def edge0Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 2
  | 2 => 1
  | _ => 0
def edge0Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 2), 2, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def edge0After : List Capability := [⟨3, 3, none, 0, false, none⟩, ⟨4, 3, (some 5), 2, false, none⟩, ⟨5, 3, none, 3, false, none⟩]
theorem edge0_injective : Injective edge0Map := by
  intro a b h
  exact Nat.add_right_cancel h
theorem edge0_closed : Closed edge0Before := by
  simp [Closed, edge0Before]
theorem edge0_result : edge0After = edge0Before.map (rename edge0Map) := by decide
theorem edge0_closed_after : Closed edge0After := by
  rw [edge0_result]
  exact closed_preserved edge0Map edge0Before edge0_closed
theorem edge0_selected_projection : edge0Before = project edge0Keep edge0FullBefore := by decide
theorem edge0_projection : AdmissibleProjection edge0FullBefore edge0Keep := by
  simp [AdmissibleProjection, project, edge0Keep, edge0FullBefore, Closed]
theorem edge0_ranked_before : Ranked edge0FullBefore := by
  refine ⟨edge0Rank, ?_⟩
  simp [ParentRanks, ChildOf, edge0FullBefore, edge0Rank]
theorem edge0_transfer : Transfer edge0FullBefore edge0After := by
  refine ⟨edge0Keep, edge0Map, edge0_projection, edge0_injective, ?_⟩
  rw [edge0_result, edge0_selected_projection]
theorem edge0_local_inventory : localInventory edge0After = localInventory edge0FullBefore :=
  transfer_local_inventory edge0_transfer
theorem edge0_ranked_after : Ranked edge0After :=
  transfer_ranked edge0_transfer edge0_ranked_before
theorem edge0_no_parent_cycle (name : Nat) : ¬ ParentPath edge0After name name :=
  ranked_no_parent_cycle edge0After edge0_ranked_after name
def edge1Map (n : Nat) : Nat := n + 3
def edge1FullBefore : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 2), 2, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def edge1Keep (n : Nat) : Bool := decide (n ∈ [0, 1, 2])
def edge1Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | 1 => 2
  | 2 => 1
  | _ => 0
def edge1Before : List Capability := [⟨0, 0, none, 0, false, none⟩, ⟨1, 0, (some 2), 2, false, none⟩, ⟨2, 0, (some 0), 3, false, none⟩]
def edge1After : List Capability := [⟨3, 3, none, 0, false, none⟩, ⟨4, 3, (some 5), 2, false, none⟩, ⟨5, 3, (some 3), 3, false, none⟩]
theorem edge1_injective : Injective edge1Map := by
  intro a b h
  exact Nat.add_right_cancel h
theorem edge1_closed : Closed edge1Before := by
  simp [Closed, edge1Before]
theorem edge1_result : edge1After = edge1Before.map (rename edge1Map) := by decide
theorem edge1_closed_after : Closed edge1After := by
  rw [edge1_result]
  exact closed_preserved edge1Map edge1Before edge1_closed
theorem edge1_selected_projection : edge1Before = project edge1Keep edge1FullBefore := by decide
theorem edge1_projection : AdmissibleProjection edge1FullBefore edge1Keep := by
  simp [AdmissibleProjection, project, edge1Keep, edge1FullBefore, Closed]
theorem edge1_ranked_before : Ranked edge1FullBefore := by
  refine ⟨edge1Rank, ?_⟩
  simp [ParentRanks, ChildOf, edge1FullBefore, edge1Rank]
theorem edge1_transfer : Transfer edge1FullBefore edge1After := by
  refine ⟨edge1Keep, edge1Map, edge1_projection, edge1_injective, ?_⟩
  rw [edge1_result, edge1_selected_projection]
theorem edge1_local_inventory : localInventory edge1After = localInventory edge1FullBefore :=
  transfer_local_inventory edge1_transfer
theorem edge1_ranked_after : Ranked edge1After :=
  transfer_ranked edge1_transfer edge1_ranked_before
theorem edge1_no_parent_cycle (name : Nat) : ¬ ParentPath edge1After name name :=
  ranked_no_parent_cycle edge1After edge1_ranked_after name
def edge2Map (n : Nat) : Nat := n + 1
def edge2FullBefore : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def edge2Keep (n : Nat) : Bool := decide (n ∈ [0])
def edge2Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def edge2Before : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def edge2After : List Capability := [⟨1, 1, none, 2, true, (some 0)⟩]
theorem edge2_injective : Injective edge2Map := by
  intro a b h
  exact Nat.add_right_cancel h
theorem edge2_closed : Closed edge2Before := by
  simp [Closed, edge2Before]
theorem edge2_result : edge2After = edge2Before.map (rename edge2Map) := by decide
theorem edge2_closed_after : Closed edge2After := by
  rw [edge2_result]
  exact closed_preserved edge2Map edge2Before edge2_closed
theorem edge2_selected_projection : edge2Before = project edge2Keep edge2FullBefore := by decide
theorem edge2_projection : AdmissibleProjection edge2FullBefore edge2Keep := by
  simp [AdmissibleProjection, project, edge2Keep, edge2FullBefore, Closed]
theorem edge2_ranked_before : Ranked edge2FullBefore := by
  refine ⟨edge2Rank, ?_⟩
  simp [ParentRanks, ChildOf, edge2FullBefore, edge2Rank]
theorem edge2_transfer : Transfer edge2FullBefore edge2After := by
  refine ⟨edge2Keep, edge2Map, edge2_projection, edge2_injective, ?_⟩
  rw [edge2_result, edge2_selected_projection]
theorem edge2_local_inventory : localInventory edge2After = localInventory edge2FullBefore :=
  transfer_local_inventory edge2_transfer
theorem edge2_ranked_after : Ranked edge2After :=
  transfer_ranked edge2_transfer edge2_ranked_before
theorem edge2_no_parent_cycle (name : Nat) : ¬ ParentPath edge2After name name :=
  ranked_no_parent_cycle edge2After edge2_ranked_after name
def edge3Map (n : Nat) : Nat := n + 1
def edge3FullBefore : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def edge3Keep (n : Nat) : Bool := decide (n ∈ [0])
def edge3Rank (n : Nat) : Nat :=
  match n with
  | 0 => 0
  | _ => 0
def edge3Before : List Capability := [⟨0, 0, none, 2, true, (some 0)⟩]
def edge3After : List Capability := [⟨1, 1, none, 2, true, (some 0)⟩]
theorem edge3_injective : Injective edge3Map := by
  intro a b h
  exact Nat.add_right_cancel h
theorem edge3_closed : Closed edge3Before := by
  simp [Closed, edge3Before]
theorem edge3_result : edge3After = edge3Before.map (rename edge3Map) := by decide
theorem edge3_closed_after : Closed edge3After := by
  rw [edge3_result]
  exact closed_preserved edge3Map edge3Before edge3_closed
theorem edge3_selected_projection : edge3Before = project edge3Keep edge3FullBefore := by decide
theorem edge3_projection : AdmissibleProjection edge3FullBefore edge3Keep := by
  simp [AdmissibleProjection, project, edge3Keep, edge3FullBefore, Closed]
theorem edge3_ranked_before : Ranked edge3FullBefore := by
  refine ⟨edge3Rank, ?_⟩
  simp [ParentRanks, ChildOf, edge3FullBefore, edge3Rank]
theorem edge3_transfer : Transfer edge3FullBefore edge3After := by
  refine ⟨edge3Keep, edge3Map, edge3_projection, edge3_injective, ?_⟩
  rw [edge3_result, edge3_selected_projection]
theorem edge3_local_inventory : localInventory edge3After = localInventory edge3FullBefore :=
  transfer_local_inventory edge3_transfer
theorem edge3_ranked_after : Ranked edge3After :=
  transfer_ranked edge3_transfer edge3_ranked_before
theorem edge3_no_parent_cycle (name : Nat) : ¬ ParentPath edge3After name name :=
  ranked_no_parent_cycle edge3After edge3_ranked_after name
end HiaCapabilityRenaming
#print axioms HiaCapabilityRenaming.child_of_iff
#print axioms HiaCapabilityRenaming.closed_preserved
#print axioms HiaCapabilityRenaming.edge0_closed
#print axioms HiaCapabilityRenaming.edge0_closed_after
#print axioms HiaCapabilityRenaming.edge0_injective
#print axioms HiaCapabilityRenaming.edge0_local_inventory
#print axioms HiaCapabilityRenaming.edge0_no_parent_cycle
#print axioms HiaCapabilityRenaming.edge0_projection
#print axioms HiaCapabilityRenaming.edge0_ranked_after
#print axioms HiaCapabilityRenaming.edge0_ranked_before
#print axioms HiaCapabilityRenaming.edge0_result
#print axioms HiaCapabilityRenaming.edge0_selected_projection
#print axioms HiaCapabilityRenaming.edge0_transfer
#print axioms HiaCapabilityRenaming.edge1_closed
#print axioms HiaCapabilityRenaming.edge1_closed_after
#print axioms HiaCapabilityRenaming.edge1_injective
#print axioms HiaCapabilityRenaming.edge1_local_inventory
#print axioms HiaCapabilityRenaming.edge1_no_parent_cycle
#print axioms HiaCapabilityRenaming.edge1_projection
#print axioms HiaCapabilityRenaming.edge1_ranked_after
#print axioms HiaCapabilityRenaming.edge1_ranked_before
#print axioms HiaCapabilityRenaming.edge1_result
#print axioms HiaCapabilityRenaming.edge1_selected_projection
#print axioms HiaCapabilityRenaming.edge1_transfer
#print axioms HiaCapabilityRenaming.edge2_closed
#print axioms HiaCapabilityRenaming.edge2_closed_after
#print axioms HiaCapabilityRenaming.edge2_injective
#print axioms HiaCapabilityRenaming.edge2_local_inventory
#print axioms HiaCapabilityRenaming.edge2_no_parent_cycle
#print axioms HiaCapabilityRenaming.edge2_projection
#print axioms HiaCapabilityRenaming.edge2_ranked_after
#print axioms HiaCapabilityRenaming.edge2_ranked_before
#print axioms HiaCapabilityRenaming.edge2_result
#print axioms HiaCapabilityRenaming.edge2_selected_projection
#print axioms HiaCapabilityRenaming.edge2_transfer
#print axioms HiaCapabilityRenaming.edge3_closed
#print axioms HiaCapabilityRenaming.edge3_closed_after
#print axioms HiaCapabilityRenaming.edge3_injective
#print axioms HiaCapabilityRenaming.edge3_local_inventory
#print axioms HiaCapabilityRenaming.edge3_no_parent_cycle
#print axioms HiaCapabilityRenaming.edge3_projection
#print axioms HiaCapabilityRenaming.edge3_ranked_after
#print axioms HiaCapabilityRenaming.edge3_ranked_before
#print axioms HiaCapabilityRenaming.edge3_result
#print axioms HiaCapabilityRenaming.edge3_selected_projection
#print axioms HiaCapabilityRenaming.edge3_transfer
#print axioms HiaCapabilityRenaming.exclusive_alias_iff
#print axioms HiaCapabilityRenaming.external_preserved
#print axioms HiaCapabilityRenaming.identity_rename
#print axioms HiaCapabilityRenaming.kind_preserved
#print axioms HiaCapabilityRenaming.local_inventory_projection
#print axioms HiaCapabilityRenaming.local_inventory_rename
#print axioms HiaCapabilityRenaming.local_retained
#print axioms HiaCapabilityRenaming.name_equal_iff
#print axioms HiaCapabilityRenaming.name_preserved
#print axioms HiaCapabilityRenaming.number_preserved
#print axioms HiaCapabilityRenaming.only_external_forgotten
#print axioms HiaCapabilityRenaming.origin_preserved
#print axioms HiaCapabilityRenaming.parent_map_iff
#print axioms HiaCapabilityRenaming.parent_path_descends
#print axioms HiaCapabilityRenaming.projected_member
#print axioms HiaCapabilityRenaming.ranked_no_parent_cycle
#print axioms HiaCapabilityRenaming.ranked_projection
#print axioms HiaCapabilityRenaming.ranked_rename
#print axioms HiaCapabilityRenaming.rename_composes
#print axioms HiaCapabilityRenaming.root_equal_iff
#print axioms HiaCapabilityRenaming.suspended_iff
#print axioms HiaCapabilityRenaming.trace_closed
#print axioms HiaCapabilityRenaming.trace_local_inventory
#print axioms HiaCapabilityRenaming.trace_no_parent_cycle
#print axioms HiaCapabilityRenaming.trace_ranked
#print axioms HiaCapabilityRenaming.transfer_closed
#print axioms HiaCapabilityRenaming.transfer_local_inventory
#print axioms HiaCapabilityRenaming.transfer_ranked
#print axioms HiaCapabilityRenaming.transported_rank_at
