#include "matrix.h"
#include <assert.h>
#include <stdio.h>
typedef uint8_t ExpectedType0;
typedef int8_t ExpectedType1;
typedef uint16_t ExpectedType2;
typedef int16_t ExpectedType3;
typedef uint32_t ExpectedType4;
typedef int32_t ExpectedType5;
typedef uint64_t ExpectedType6;
typedef int64_t ExpectedType7;
typedef size_t ExpectedType8;
typedef intptr_t ExpectedType9;
typedef float ExpectedType10;
typedef double ExpectedType11;
typedef hepta_Matrix00 ExpectedType12;
typedef hepta_Matrix01 ExpectedType13;
typedef hepta_Matrix02 ExpectedType14;
typedef hepta_Matrix03 ExpectedType15;
typedef hepta_Matrix04 ExpectedType16;
typedef hepta_Matrix05 ExpectedType17;
typedef hepta_Matrix06 ExpectedType18;
typedef hepta_Matrix07 ExpectedType19;
typedef hepta_Matrix08 ExpectedType20;
typedef hepta_Matrix09 ExpectedType21;
typedef hepta_Matrix10 ExpectedType22;
typedef hepta_Matrix11 ExpectedType23;
typedef hepta_Matrix12 ExpectedType24;
typedef hepta_Matrix13 ExpectedType25;
typedef hepta_Matrix14 ExpectedType26;
typedef hepta_Matrix15 ExpectedType27;
typedef hepta_Matrix16 ExpectedType28;
typedef hepta_Matrix17 ExpectedType29;
typedef hepta_Matrix18 ExpectedType30;
typedef hepta_Matrix19 ExpectedType31;
typedef hepta_Matrix20 ExpectedType32;
typedef hepta_Matrix21 ExpectedType33;
typedef hepta_Matrix22 ExpectedType34;
typedef hepta_Matrix23 ExpectedType35;
typedef hepta_Matrix24 ExpectedType36;
typedef hepta_Matrix25 ExpectedType37;
typedef hepta_Matrix26 ExpectedType38;
typedef hepta_Matrix27 ExpectedType39;
typedef hepta_Matrix28 ExpectedType40;
typedef hepta_Matrix29 ExpectedType41;
typedef hepta_Matrix30 ExpectedType42;
typedef hepta_Matrix31 ExpectedType43;
typedef hepta_Matrix32 ExpectedType44;
typedef hepta_Matrix33 ExpectedType45;
typedef hepta_Matrix34 ExpectedType46;
typedef hepta_Matrix35 ExpectedType47;
typedef const ExpectedType4 *ExpectedType48;
typedef ExpectedType4 *ExpectedType49;
typedef const ExpectedType49 *ExpectedType50;
typedef ExpectedType48 *ExpectedType51;
typedef const ExpectedType2 *ExpectedType52;
typedef const ExpectedType52 *ExpectedType53;
typedef ExpectedType4 ExpectedType54[3];
typedef ExpectedType54 *ExpectedType55;
typedef const ExpectedType54 *ExpectedType56;
typedef ExpectedType49 ExpectedType57[2];
typedef const ExpectedType57 *ExpectedType58;
typedef ExpectedType48 ExpectedType59[2];
typedef ExpectedType59 *ExpectedType60;
typedef ExpectedType2 ExpectedType61[2];
typedef const ExpectedType61 *ExpectedType62;
typedef ExpectedType62 *ExpectedType63;
typedef void ExpectedType64;
typedef const ExpectedType64 *ExpectedType65;
typedef ExpectedType65 *ExpectedType66;
typedef ExpectedType2 ExpectedType67[4];
typedef ExpectedType12 ExpectedType68[3];
typedef ExpectedType14 ExpectedType69[1];
typedef ExpectedType69 ExpectedType70[2];
typedef ExpectedType3 ExpectedType71[4];
typedef ExpectedType10 ExpectedType72[3];
typedef ExpectedType12 ExpectedType73[1];
typedef ExpectedType17 ExpectedType74[3];
typedef ExpectedType7 ExpectedType75[1];
typedef ExpectedType10 ExpectedType76[2];
typedef ExpectedType5 ExpectedType77[3];
typedef ExpectedType1 ExpectedType78[4];
typedef ExpectedType6 ExpectedType79[1];
typedef ExpectedType72 ExpectedType80[2];
typedef ExpectedType22 ExpectedType81[3];
typedef ExpectedType22 ExpectedType82[4];
typedef ExpectedType82 ExpectedType83[2];
typedef ExpectedType0 ExpectedType84[2];
typedef ExpectedType73 ExpectedType85[2];
typedef ExpectedType15 ExpectedType86[3];
typedef ExpectedType26 ExpectedType87[3];
typedef ExpectedType87 ExpectedType88[2];
typedef ExpectedType5 ExpectedType89[1];
typedef ExpectedType35 ExpectedType90[2];
typedef ExpectedType90 ExpectedType91[2];
typedef ExpectedType19 ExpectedType92[4];
typedef ExpectedType4 ExpectedType93[1];
typedef ExpectedType93 ExpectedType94[2];
typedef ExpectedType18 ExpectedType95[4];
typedef ExpectedType26 ExpectedType96[4];
typedef ExpectedType96 ExpectedType97[2];
typedef ExpectedType48 ExpectedType98[3];
typedef ExpectedType56 ExpectedType99[2];
static size_t abi_calls = 0;
ExpectedType0 abi_c_scalar0(ExpectedType0 value) { ++abi_calls; return value; }
typedef ExpectedType0 (*ExpectedSignature_scalar0)(ExpectedType0);
_Static_assert(_Generic(&abi_h_scalar0, ExpectedSignature_scalar0: 1, default: 0), "signature scalar0");
ExpectedType1 abi_c_scalar1(ExpectedType1 value) { ++abi_calls; return value; }
typedef ExpectedType1 (*ExpectedSignature_scalar1)(ExpectedType1);
_Static_assert(_Generic(&abi_h_scalar1, ExpectedSignature_scalar1: 1, default: 0), "signature scalar1");
ExpectedType2 abi_c_scalar2(ExpectedType2 value) { ++abi_calls; return value; }
typedef ExpectedType2 (*ExpectedSignature_scalar2)(ExpectedType2);
_Static_assert(_Generic(&abi_h_scalar2, ExpectedSignature_scalar2: 1, default: 0), "signature scalar2");
ExpectedType3 abi_c_scalar3(ExpectedType3 value) { ++abi_calls; return value; }
typedef ExpectedType3 (*ExpectedSignature_scalar3)(ExpectedType3);
_Static_assert(_Generic(&abi_h_scalar3, ExpectedSignature_scalar3: 1, default: 0), "signature scalar3");
ExpectedType4 abi_c_scalar4(ExpectedType4 value) { ++abi_calls; return value; }
typedef ExpectedType4 (*ExpectedSignature_scalar4)(ExpectedType4);
_Static_assert(_Generic(&abi_h_scalar4, ExpectedSignature_scalar4: 1, default: 0), "signature scalar4");
ExpectedType5 abi_c_scalar5(ExpectedType5 value) { ++abi_calls; return value; }
typedef ExpectedType5 (*ExpectedSignature_scalar5)(ExpectedType5);
_Static_assert(_Generic(&abi_h_scalar5, ExpectedSignature_scalar5: 1, default: 0), "signature scalar5");
ExpectedType6 abi_c_scalar6(ExpectedType6 value) { ++abi_calls; return value; }
typedef ExpectedType6 (*ExpectedSignature_scalar6)(ExpectedType6);
_Static_assert(_Generic(&abi_h_scalar6, ExpectedSignature_scalar6: 1, default: 0), "signature scalar6");
ExpectedType7 abi_c_scalar7(ExpectedType7 value) { ++abi_calls; return value; }
typedef ExpectedType7 (*ExpectedSignature_scalar7)(ExpectedType7);
_Static_assert(_Generic(&abi_h_scalar7, ExpectedSignature_scalar7: 1, default: 0), "signature scalar7");
ExpectedType8 abi_c_scalar8(ExpectedType8 value) { ++abi_calls; return value; }
typedef ExpectedType8 (*ExpectedSignature_scalar8)(ExpectedType8);
_Static_assert(_Generic(&abi_h_scalar8, ExpectedSignature_scalar8: 1, default: 0), "signature scalar8");
ExpectedType9 abi_c_scalar9(ExpectedType9 value) { ++abi_calls; return value; }
typedef ExpectedType9 (*ExpectedSignature_scalar9)(ExpectedType9);
_Static_assert(_Generic(&abi_h_scalar9, ExpectedSignature_scalar9: 1, default: 0), "signature scalar9");
ExpectedType10 abi_c_scalar10(ExpectedType10 value) { ++abi_calls; return value; }
typedef ExpectedType10 (*ExpectedSignature_scalar10)(ExpectedType10);
_Static_assert(_Generic(&abi_h_scalar10, ExpectedSignature_scalar10: 1, default: 0), "signature scalar10");
ExpectedType11 abi_c_scalar11(ExpectedType11 value) { ++abi_calls; return value; }
typedef ExpectedType11 (*ExpectedSignature_scalar11)(ExpectedType11);
_Static_assert(_Generic(&abi_h_scalar11, ExpectedSignature_scalar11: 1, default: 0), "signature scalar11");
ExpectedType12 abi_c_record0(ExpectedType12 value) { ++abi_calls; return value; }
typedef ExpectedType12 (*ExpectedSignature_record0)(ExpectedType12);
_Static_assert(_Generic(&abi_h_record0, ExpectedSignature_record0: 1, default: 0), "signature record0");
ExpectedType13 abi_c_record1(ExpectedType13 value) { ++abi_calls; return value; }
typedef ExpectedType13 (*ExpectedSignature_record1)(ExpectedType13);
_Static_assert(_Generic(&abi_h_record1, ExpectedSignature_record1: 1, default: 0), "signature record1");
ExpectedType14 abi_c_record2(ExpectedType14 value) { ++abi_calls; return value; }
typedef ExpectedType14 (*ExpectedSignature_record2)(ExpectedType14);
_Static_assert(_Generic(&abi_h_record2, ExpectedSignature_record2: 1, default: 0), "signature record2");
ExpectedType15 abi_c_record3(ExpectedType15 value) { ++abi_calls; return value; }
typedef ExpectedType15 (*ExpectedSignature_record3)(ExpectedType15);
_Static_assert(_Generic(&abi_h_record3, ExpectedSignature_record3: 1, default: 0), "signature record3");
ExpectedType16 abi_c_record4(ExpectedType16 value) { ++abi_calls; return value; }
typedef ExpectedType16 (*ExpectedSignature_record4)(ExpectedType16);
_Static_assert(_Generic(&abi_h_record4, ExpectedSignature_record4: 1, default: 0), "signature record4");
ExpectedType17 abi_c_record5(ExpectedType17 value) { ++abi_calls; return value; }
typedef ExpectedType17 (*ExpectedSignature_record5)(ExpectedType17);
_Static_assert(_Generic(&abi_h_record5, ExpectedSignature_record5: 1, default: 0), "signature record5");
ExpectedType18 abi_c_record6(ExpectedType18 value) { ++abi_calls; return value; }
typedef ExpectedType18 (*ExpectedSignature_record6)(ExpectedType18);
_Static_assert(_Generic(&abi_h_record6, ExpectedSignature_record6: 1, default: 0), "signature record6");
ExpectedType19 abi_c_record7(ExpectedType19 value) { ++abi_calls; return value; }
typedef ExpectedType19 (*ExpectedSignature_record7)(ExpectedType19);
_Static_assert(_Generic(&abi_h_record7, ExpectedSignature_record7: 1, default: 0), "signature record7");
ExpectedType20 abi_c_record8(ExpectedType20 value) { ++abi_calls; return value; }
typedef ExpectedType20 (*ExpectedSignature_record8)(ExpectedType20);
_Static_assert(_Generic(&abi_h_record8, ExpectedSignature_record8: 1, default: 0), "signature record8");
ExpectedType21 abi_c_record9(ExpectedType21 value) { ++abi_calls; return value; }
typedef ExpectedType21 (*ExpectedSignature_record9)(ExpectedType21);
_Static_assert(_Generic(&abi_h_record9, ExpectedSignature_record9: 1, default: 0), "signature record9");
ExpectedType22 abi_c_record10(ExpectedType22 value) { ++abi_calls; return value; }
typedef ExpectedType22 (*ExpectedSignature_record10)(ExpectedType22);
_Static_assert(_Generic(&abi_h_record10, ExpectedSignature_record10: 1, default: 0), "signature record10");
ExpectedType23 abi_c_record11(ExpectedType23 value) { ++abi_calls; return value; }
typedef ExpectedType23 (*ExpectedSignature_record11)(ExpectedType23);
_Static_assert(_Generic(&abi_h_record11, ExpectedSignature_record11: 1, default: 0), "signature record11");
ExpectedType24 abi_c_record12(ExpectedType24 value) { ++abi_calls; return value; }
typedef ExpectedType24 (*ExpectedSignature_record12)(ExpectedType24);
_Static_assert(_Generic(&abi_h_record12, ExpectedSignature_record12: 1, default: 0), "signature record12");
ExpectedType25 abi_c_record13(ExpectedType25 value) { ++abi_calls; return value; }
typedef ExpectedType25 (*ExpectedSignature_record13)(ExpectedType25);
_Static_assert(_Generic(&abi_h_record13, ExpectedSignature_record13: 1, default: 0), "signature record13");
ExpectedType26 abi_c_record14(ExpectedType26 value) { ++abi_calls; return value; }
typedef ExpectedType26 (*ExpectedSignature_record14)(ExpectedType26);
_Static_assert(_Generic(&abi_h_record14, ExpectedSignature_record14: 1, default: 0), "signature record14");
ExpectedType27 abi_c_record15(ExpectedType27 value) { ++abi_calls; return value; }
typedef ExpectedType27 (*ExpectedSignature_record15)(ExpectedType27);
_Static_assert(_Generic(&abi_h_record15, ExpectedSignature_record15: 1, default: 0), "signature record15");
ExpectedType28 abi_c_record16(ExpectedType28 value) { ++abi_calls; return value; }
typedef ExpectedType28 (*ExpectedSignature_record16)(ExpectedType28);
_Static_assert(_Generic(&abi_h_record16, ExpectedSignature_record16: 1, default: 0), "signature record16");
ExpectedType29 abi_c_record17(ExpectedType29 value) { ++abi_calls; return value; }
typedef ExpectedType29 (*ExpectedSignature_record17)(ExpectedType29);
_Static_assert(_Generic(&abi_h_record17, ExpectedSignature_record17: 1, default: 0), "signature record17");
ExpectedType30 abi_c_record18(ExpectedType30 value) { ++abi_calls; return value; }
typedef ExpectedType30 (*ExpectedSignature_record18)(ExpectedType30);
_Static_assert(_Generic(&abi_h_record18, ExpectedSignature_record18: 1, default: 0), "signature record18");
ExpectedType31 abi_c_record19(ExpectedType31 value) { ++abi_calls; return value; }
typedef ExpectedType31 (*ExpectedSignature_record19)(ExpectedType31);
_Static_assert(_Generic(&abi_h_record19, ExpectedSignature_record19: 1, default: 0), "signature record19");
ExpectedType32 abi_c_record20(ExpectedType32 value) { ++abi_calls; return value; }
typedef ExpectedType32 (*ExpectedSignature_record20)(ExpectedType32);
_Static_assert(_Generic(&abi_h_record20, ExpectedSignature_record20: 1, default: 0), "signature record20");
ExpectedType33 abi_c_record21(ExpectedType33 value) { ++abi_calls; return value; }
typedef ExpectedType33 (*ExpectedSignature_record21)(ExpectedType33);
_Static_assert(_Generic(&abi_h_record21, ExpectedSignature_record21: 1, default: 0), "signature record21");
ExpectedType34 abi_c_record22(ExpectedType34 value) { ++abi_calls; return value; }
typedef ExpectedType34 (*ExpectedSignature_record22)(ExpectedType34);
_Static_assert(_Generic(&abi_h_record22, ExpectedSignature_record22: 1, default: 0), "signature record22");
ExpectedType35 abi_c_record23(ExpectedType35 value) { ++abi_calls; return value; }
typedef ExpectedType35 (*ExpectedSignature_record23)(ExpectedType35);
_Static_assert(_Generic(&abi_h_record23, ExpectedSignature_record23: 1, default: 0), "signature record23");
ExpectedType36 abi_c_record24(ExpectedType36 value) { ++abi_calls; return value; }
typedef ExpectedType36 (*ExpectedSignature_record24)(ExpectedType36);
_Static_assert(_Generic(&abi_h_record24, ExpectedSignature_record24: 1, default: 0), "signature record24");
ExpectedType37 abi_c_record25(ExpectedType37 value) { ++abi_calls; return value; }
typedef ExpectedType37 (*ExpectedSignature_record25)(ExpectedType37);
_Static_assert(_Generic(&abi_h_record25, ExpectedSignature_record25: 1, default: 0), "signature record25");
ExpectedType38 abi_c_record26(ExpectedType38 value) { ++abi_calls; return value; }
typedef ExpectedType38 (*ExpectedSignature_record26)(ExpectedType38);
_Static_assert(_Generic(&abi_h_record26, ExpectedSignature_record26: 1, default: 0), "signature record26");
ExpectedType39 abi_c_record27(ExpectedType39 value) { ++abi_calls; return value; }
typedef ExpectedType39 (*ExpectedSignature_record27)(ExpectedType39);
_Static_assert(_Generic(&abi_h_record27, ExpectedSignature_record27: 1, default: 0), "signature record27");
ExpectedType40 abi_c_record28(ExpectedType40 value) { ++abi_calls; return value; }
typedef ExpectedType40 (*ExpectedSignature_record28)(ExpectedType40);
_Static_assert(_Generic(&abi_h_record28, ExpectedSignature_record28: 1, default: 0), "signature record28");
ExpectedType41 abi_c_record29(ExpectedType41 value) { ++abi_calls; return value; }
typedef ExpectedType41 (*ExpectedSignature_record29)(ExpectedType41);
_Static_assert(_Generic(&abi_h_record29, ExpectedSignature_record29: 1, default: 0), "signature record29");
ExpectedType42 abi_c_record30(ExpectedType42 value) { ++abi_calls; return value; }
typedef ExpectedType42 (*ExpectedSignature_record30)(ExpectedType42);
_Static_assert(_Generic(&abi_h_record30, ExpectedSignature_record30: 1, default: 0), "signature record30");
ExpectedType43 abi_c_record31(ExpectedType43 value) { ++abi_calls; return value; }
typedef ExpectedType43 (*ExpectedSignature_record31)(ExpectedType43);
_Static_assert(_Generic(&abi_h_record31, ExpectedSignature_record31: 1, default: 0), "signature record31");
ExpectedType44 abi_c_record32(ExpectedType44 value) { ++abi_calls; return value; }
typedef ExpectedType44 (*ExpectedSignature_record32)(ExpectedType44);
_Static_assert(_Generic(&abi_h_record32, ExpectedSignature_record32: 1, default: 0), "signature record32");
ExpectedType45 abi_c_record33(ExpectedType45 value) { ++abi_calls; return value; }
typedef ExpectedType45 (*ExpectedSignature_record33)(ExpectedType45);
_Static_assert(_Generic(&abi_h_record33, ExpectedSignature_record33: 1, default: 0), "signature record33");
ExpectedType46 abi_c_record34(ExpectedType46 value) { ++abi_calls; return value; }
typedef ExpectedType46 (*ExpectedSignature_record34)(ExpectedType46);
_Static_assert(_Generic(&abi_h_record34, ExpectedSignature_record34: 1, default: 0), "signature record34");
ExpectedType47 abi_c_record35(ExpectedType47 value) { ++abi_calls; return value; }
typedef ExpectedType47 (*ExpectedSignature_record35)(ExpectedType47);
_Static_assert(_Generic(&abi_h_record35, ExpectedSignature_record35: 1, default: 0), "signature record35");
ExpectedType48 abi_c_pointer0(ExpectedType48 value) { ++abi_calls; return value; }
typedef ExpectedType48 (*ExpectedSignature_pointer0)(ExpectedType48);
_Static_assert(_Generic(&abi_h_pointer0, ExpectedSignature_pointer0: 1, default: 0), "signature pointer0");
ExpectedType49 abi_c_pointer1(ExpectedType49 value) { ++abi_calls; return value; }
typedef ExpectedType49 (*ExpectedSignature_pointer1)(ExpectedType49);
_Static_assert(_Generic(&abi_h_pointer1, ExpectedSignature_pointer1: 1, default: 0), "signature pointer1");
ExpectedType50 abi_c_pointer2(ExpectedType50 value) { ++abi_calls; return value; }
typedef ExpectedType50 (*ExpectedSignature_pointer2)(ExpectedType50);
_Static_assert(_Generic(&abi_h_pointer2, ExpectedSignature_pointer2: 1, default: 0), "signature pointer2");
ExpectedType51 abi_c_pointer3(ExpectedType51 value) { ++abi_calls; return value; }
typedef ExpectedType51 (*ExpectedSignature_pointer3)(ExpectedType51);
_Static_assert(_Generic(&abi_h_pointer3, ExpectedSignature_pointer3: 1, default: 0), "signature pointer3");
ExpectedType53 abi_c_pointer4(ExpectedType53 value) { ++abi_calls; return value; }
typedef ExpectedType53 (*ExpectedSignature_pointer4)(ExpectedType53);
_Static_assert(_Generic(&abi_h_pointer4, ExpectedSignature_pointer4: 1, default: 0), "signature pointer4");
ExpectedType55 abi_c_pointer5(ExpectedType55 value) { ++abi_calls; return value; }
typedef ExpectedType55 (*ExpectedSignature_pointer5)(ExpectedType55);
_Static_assert(_Generic(&abi_h_pointer5, ExpectedSignature_pointer5: 1, default: 0), "signature pointer5");
ExpectedType56 abi_c_pointer6(ExpectedType56 value) { ++abi_calls; return value; }
typedef ExpectedType56 (*ExpectedSignature_pointer6)(ExpectedType56);
_Static_assert(_Generic(&abi_h_pointer6, ExpectedSignature_pointer6: 1, default: 0), "signature pointer6");
ExpectedType58 abi_c_pointer7(ExpectedType58 value) { ++abi_calls; return value; }
typedef ExpectedType58 (*ExpectedSignature_pointer7)(ExpectedType58);
_Static_assert(_Generic(&abi_h_pointer7, ExpectedSignature_pointer7: 1, default: 0), "signature pointer7");
ExpectedType60 abi_c_pointer8(ExpectedType60 value) { ++abi_calls; return value; }
typedef ExpectedType60 (*ExpectedSignature_pointer8)(ExpectedType60);
_Static_assert(_Generic(&abi_h_pointer8, ExpectedSignature_pointer8: 1, default: 0), "signature pointer8");
ExpectedType63 abi_c_pointer9(ExpectedType63 value) { ++abi_calls; return value; }
typedef ExpectedType63 (*ExpectedSignature_pointer9)(ExpectedType63);
_Static_assert(_Generic(&abi_h_pointer9, ExpectedSignature_pointer9: 1, default: 0), "signature pointer9");
ExpectedType65 abi_c_pointer10(ExpectedType65 value) { ++abi_calls; return value; }
typedef ExpectedType65 (*ExpectedSignature_pointer10)(ExpectedType65);
_Static_assert(_Generic(&abi_h_pointer10, ExpectedSignature_pointer10: 1, default: 0), "signature pointer10");
ExpectedType66 abi_c_pointer11(ExpectedType66 value) { ++abi_calls; return value; }
typedef ExpectedType66 (*ExpectedSignature_pointer11)(ExpectedType66);
_Static_assert(_Generic(&abi_h_pointer11, ExpectedSignature_pointer11: 1, default: 0), "signature pointer11");
_Static_assert(_Generic(&((hepta_Matrix00*)0)->field0, ExpectedType6 *: 1, default: 0), "field type Matrix00.field0");
_Static_assert(_Generic(&((hepta_Matrix00*)0)->field1, ExpectedType3 *: 1, default: 0), "field type Matrix00.field1");
_Static_assert(_Generic(&((hepta_Matrix00*)0)->field2, ExpectedType9 *: 1, default: 0), "field type Matrix00.field2");
_Static_assert(_Generic(&((hepta_Matrix00*)0)->field3, ExpectedType1 *: 1, default: 0), "field type Matrix00.field3");
_Static_assert(_Generic(&((hepta_Matrix01*)0)->field0, ExpectedType5 *: 1, default: 0), "field type Matrix01.field0");
_Static_assert(_Generic(&((hepta_Matrix01*)0)->field1, ExpectedType12 *: 1, default: 0), "field type Matrix01.field1");
_Static_assert(_Generic(&((hepta_Matrix01*)0)->field2, ExpectedType67 *: 1, default: 0), "field type Matrix01.field2");
_Static_assert(_Generic(&((hepta_Matrix01*)0)->field3, ExpectedType68 *: 1, default: 0), "field type Matrix01.field3");
_Static_assert(_Generic(&((hepta_Matrix02*)0)->field0, ExpectedType11 *: 1, default: 0), "field type Matrix02.field0");
_Static_assert(_Generic(&((hepta_Matrix03*)0)->field0, ExpectedType70 *: 1, default: 0), "field type Matrix03.field0");
_Static_assert(_Generic(&((hepta_Matrix03*)0)->field1, ExpectedType4 *: 1, default: 0), "field type Matrix03.field1");
_Static_assert(_Generic(&((hepta_Matrix03*)0)->field2, ExpectedType3 *: 1, default: 0), "field type Matrix03.field2");
_Static_assert(_Generic(&((hepta_Matrix03*)0)->field3, ExpectedType0 *: 1, default: 0), "field type Matrix03.field3");
_Static_assert(_Generic(&((hepta_Matrix03*)0)->field4, ExpectedType3 *: 1, default: 0), "field type Matrix03.field4");
_Static_assert(_Generic(&((hepta_Matrix04*)0)->field0, ExpectedType4 *: 1, default: 0), "field type Matrix04.field0");
_Static_assert(_Generic(&((hepta_Matrix04*)0)->field1, ExpectedType71 *: 1, default: 0), "field type Matrix04.field1");
_Static_assert(_Generic(&((hepta_Matrix04*)0)->field2, ExpectedType0 *: 1, default: 0), "field type Matrix04.field2");
_Static_assert(_Generic(&((hepta_Matrix04*)0)->field3, ExpectedType3 *: 1, default: 0), "field type Matrix04.field3");
_Static_assert(_Generic(&((hepta_Matrix05*)0)->field0, ExpectedType72 *: 1, default: 0), "field type Matrix05.field0");
_Static_assert(_Generic(&((hepta_Matrix06*)0)->field0, ExpectedType12 *: 1, default: 0), "field type Matrix06.field0");
_Static_assert(_Generic(&((hepta_Matrix06*)0)->field1, ExpectedType8 *: 1, default: 0), "field type Matrix06.field1");
_Static_assert(_Generic(&((hepta_Matrix06*)0)->field2, ExpectedType73 *: 1, default: 0), "field type Matrix06.field2");
_Static_assert(_Generic(&((hepta_Matrix07*)0)->field0, ExpectedType4 *: 1, default: 0), "field type Matrix07.field0");
_Static_assert(_Generic(&((hepta_Matrix08*)0)->field0, ExpectedType74 *: 1, default: 0), "field type Matrix08.field0");
_Static_assert(_Generic(&((hepta_Matrix09*)0)->field0, ExpectedType5 *: 1, default: 0), "field type Matrix09.field0");
_Static_assert(_Generic(&((hepta_Matrix09*)0)->field1, ExpectedType12 *: 1, default: 0), "field type Matrix09.field1");
_Static_assert(_Generic(&((hepta_Matrix10*)0)->field0, ExpectedType0 *: 1, default: 0), "field type Matrix10.field0");
_Static_assert(_Generic(&((hepta_Matrix10*)0)->field1, ExpectedType6 *: 1, default: 0), "field type Matrix10.field1");
_Static_assert(_Generic(&((hepta_Matrix11*)0)->field0, ExpectedType22 *: 1, default: 0), "field type Matrix11.field0");
_Static_assert(_Generic(&((hepta_Matrix11*)0)->field1, ExpectedType11 *: 1, default: 0), "field type Matrix11.field1");
_Static_assert(_Generic(&((hepta_Matrix11*)0)->field2, ExpectedType21 *: 1, default: 0), "field type Matrix11.field2");
_Static_assert(_Generic(&((hepta_Matrix11*)0)->field3, ExpectedType75 *: 1, default: 0), "field type Matrix11.field3");
_Static_assert(_Generic(&((hepta_Matrix12*)0)->field0, ExpectedType18 *: 1, default: 0), "field type Matrix12.field0");
_Static_assert(_Generic(&((hepta_Matrix12*)0)->field1, ExpectedType17 *: 1, default: 0), "field type Matrix12.field1");
_Static_assert(_Generic(&((hepta_Matrix13*)0)->field0, ExpectedType23 *: 1, default: 0), "field type Matrix13.field0");
_Static_assert(_Generic(&((hepta_Matrix13*)0)->field1, ExpectedType76 *: 1, default: 0), "field type Matrix13.field1");
_Static_assert(_Generic(&((hepta_Matrix14*)0)->field0, ExpectedType77 *: 1, default: 0), "field type Matrix14.field0");
_Static_assert(_Generic(&((hepta_Matrix15*)0)->field0, ExpectedType15 *: 1, default: 0), "field type Matrix15.field0");
_Static_assert(_Generic(&((hepta_Matrix15*)0)->field1, ExpectedType78 *: 1, default: 0), "field type Matrix15.field1");
_Static_assert(_Generic(&((hepta_Matrix15*)0)->field2, ExpectedType79 *: 1, default: 0), "field type Matrix15.field2");
_Static_assert(_Generic(&((hepta_Matrix15*)0)->field3, ExpectedType21 *: 1, default: 0), "field type Matrix15.field3");
_Static_assert(_Generic(&((hepta_Matrix16*)0)->field0, ExpectedType7 *: 1, default: 0), "field type Matrix16.field0");
_Static_assert(_Generic(&((hepta_Matrix16*)0)->field1, ExpectedType17 *: 1, default: 0), "field type Matrix16.field1");
_Static_assert(_Generic(&((hepta_Matrix16*)0)->field2, ExpectedType80 *: 1, default: 0), "field type Matrix16.field2");
_Static_assert(_Generic(&((hepta_Matrix16*)0)->field3, ExpectedType81 *: 1, default: 0), "field type Matrix16.field3");
_Static_assert(_Generic(&((hepta_Matrix16*)0)->field4, ExpectedType26 *: 1, default: 0), "field type Matrix16.field4");
_Static_assert(_Generic(&((hepta_Matrix17*)0)->field0, ExpectedType22 *: 1, default: 0), "field type Matrix17.field0");
_Static_assert(_Generic(&((hepta_Matrix17*)0)->field1, ExpectedType83 *: 1, default: 0), "field type Matrix17.field1");
_Static_assert(_Generic(&((hepta_Matrix17*)0)->field2, ExpectedType2 *: 1, default: 0), "field type Matrix17.field2");
_Static_assert(_Generic(&((hepta_Matrix18*)0)->field0, ExpectedType84 *: 1, default: 0), "field type Matrix18.field0");
_Static_assert(_Generic(&((hepta_Matrix18*)0)->field1, ExpectedType8 *: 1, default: 0), "field type Matrix18.field1");
_Static_assert(_Generic(&((hepta_Matrix18*)0)->field2, ExpectedType18 *: 1, default: 0), "field type Matrix18.field2");
_Static_assert(_Generic(&((hepta_Matrix18*)0)->field3, ExpectedType20 *: 1, default: 0), "field type Matrix18.field3");
_Static_assert(_Generic(&((hepta_Matrix19*)0)->field0, ExpectedType3 *: 1, default: 0), "field type Matrix19.field0");
_Static_assert(_Generic(&((hepta_Matrix20*)0)->field0, ExpectedType19 *: 1, default: 0), "field type Matrix20.field0");
_Static_assert(_Generic(&((hepta_Matrix21*)0)->field0, ExpectedType85 *: 1, default: 0), "field type Matrix21.field0");
_Static_assert(_Generic(&((hepta_Matrix21*)0)->field1, ExpectedType86 *: 1, default: 0), "field type Matrix21.field1");
_Static_assert(_Generic(&((hepta_Matrix21*)0)->field2, ExpectedType88 *: 1, default: 0), "field type Matrix21.field2");
_Static_assert(_Generic(&((hepta_Matrix21*)0)->field3, ExpectedType3 *: 1, default: 0), "field type Matrix21.field3");
_Static_assert(_Generic(&((hepta_Matrix22*)0)->field0, ExpectedType89 *: 1, default: 0), "field type Matrix22.field0");
_Static_assert(_Generic(&((hepta_Matrix22*)0)->field1, ExpectedType4 *: 1, default: 0), "field type Matrix22.field1");
_Static_assert(_Generic(&((hepta_Matrix22*)0)->field2, ExpectedType20 *: 1, default: 0), "field type Matrix22.field2");
_Static_assert(_Generic(&((hepta_Matrix23*)0)->field0, ExpectedType5 *: 1, default: 0), "field type Matrix23.field0");
_Static_assert(_Generic(&((hepta_Matrix23*)0)->field1, ExpectedType4 *: 1, default: 0), "field type Matrix23.field1");
_Static_assert(_Generic(&((hepta_Matrix23*)0)->field2, ExpectedType12 *: 1, default: 0), "field type Matrix23.field2");
_Static_assert(_Generic(&((hepta_Matrix23*)0)->field3, ExpectedType32 *: 1, default: 0), "field type Matrix23.field3");
_Static_assert(_Generic(&((hepta_Matrix24*)0)->field0, ExpectedType69 *: 1, default: 0), "field type Matrix24.field0");
_Static_assert(_Generic(&((hepta_Matrix25*)0)->field0, ExpectedType91 *: 1, default: 0), "field type Matrix25.field0");
_Static_assert(_Generic(&((hepta_Matrix25*)0)->field1, ExpectedType14 *: 1, default: 0), "field type Matrix25.field1");
_Static_assert(_Generic(&((hepta_Matrix25*)0)->field2, ExpectedType21 *: 1, default: 0), "field type Matrix25.field2");
_Static_assert(_Generic(&((hepta_Matrix25*)0)->field3, ExpectedType21 *: 1, default: 0), "field type Matrix25.field3");
_Static_assert(_Generic(&((hepta_Matrix26*)0)->field0, ExpectedType24 *: 1, default: 0), "field type Matrix26.field0");
_Static_assert(_Generic(&((hepta_Matrix26*)0)->field1, ExpectedType92 *: 1, default: 0), "field type Matrix26.field1");
_Static_assert(_Generic(&((hepta_Matrix26*)0)->field2, ExpectedType14 *: 1, default: 0), "field type Matrix26.field2");
_Static_assert(_Generic(&((hepta_Matrix27*)0)->field0, ExpectedType9 *: 1, default: 0), "field type Matrix27.field0");
_Static_assert(_Generic(&((hepta_Matrix27*)0)->field1, ExpectedType22 *: 1, default: 0), "field type Matrix27.field1");
_Static_assert(_Generic(&((hepta_Matrix27*)0)->field2, ExpectedType16 *: 1, default: 0), "field type Matrix27.field2");
_Static_assert(_Generic(&((hepta_Matrix28*)0)->field0, ExpectedType9 *: 1, default: 0), "field type Matrix28.field0");
_Static_assert(_Generic(&((hepta_Matrix28*)0)->field1, ExpectedType26 *: 1, default: 0), "field type Matrix28.field1");
_Static_assert(_Generic(&((hepta_Matrix28*)0)->field2, ExpectedType20 *: 1, default: 0), "field type Matrix28.field2");
_Static_assert(_Generic(&((hepta_Matrix28*)0)->field3, ExpectedType9 *: 1, default: 0), "field type Matrix28.field3");
_Static_assert(_Generic(&((hepta_Matrix29*)0)->field0, ExpectedType94 *: 1, default: 0), "field type Matrix29.field0");
_Static_assert(_Generic(&((hepta_Matrix30*)0)->field0, ExpectedType32 *: 1, default: 0), "field type Matrix30.field0");
_Static_assert(_Generic(&((hepta_Matrix30*)0)->field1, ExpectedType31 *: 1, default: 0), "field type Matrix30.field1");
_Static_assert(_Generic(&((hepta_Matrix30*)0)->field2, ExpectedType20 *: 1, default: 0), "field type Matrix30.field2");
_Static_assert(_Generic(&((hepta_Matrix30*)0)->field3, ExpectedType11 *: 1, default: 0), "field type Matrix30.field3");
_Static_assert(_Generic(&((hepta_Matrix30*)0)->field4, ExpectedType95 *: 1, default: 0), "field type Matrix30.field4");
_Static_assert(_Generic(&((hepta_Matrix31*)0)->field0, ExpectedType20 *: 1, default: 0), "field type Matrix31.field0");
_Static_assert(_Generic(&((hepta_Matrix31*)0)->field1, ExpectedType21 *: 1, default: 0), "field type Matrix31.field1");
_Static_assert(_Generic(&((hepta_Matrix32*)0)->field0, ExpectedType1 *: 1, default: 0), "field type Matrix32.field0");
_Static_assert(_Generic(&((hepta_Matrix33*)0)->field0, ExpectedType7 *: 1, default: 0), "field type Matrix33.field0");
_Static_assert(_Generic(&((hepta_Matrix33*)0)->field1, ExpectedType10 *: 1, default: 0), "field type Matrix33.field1");
_Static_assert(_Generic(&((hepta_Matrix33*)0)->field2, ExpectedType1 *: 1, default: 0), "field type Matrix33.field2");
_Static_assert(_Generic(&((hepta_Matrix33*)0)->field3, ExpectedType22 *: 1, default: 0), "field type Matrix33.field3");
_Static_assert(_Generic(&((hepta_Matrix33*)0)->field4, ExpectedType97 *: 1, default: 0), "field type Matrix33.field4");
_Static_assert(_Generic(&((hepta_Matrix34*)0)->field0, ExpectedType7 *: 1, default: 0), "field type Matrix34.field0");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer0, ExpectedType48 *: 1, default: 0), "field type Matrix35.pointer0");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer1, ExpectedType49 *: 1, default: 0), "field type Matrix35.pointer1");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer2, ExpectedType50 *: 1, default: 0), "field type Matrix35.pointer2");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer3, ExpectedType51 *: 1, default: 0), "field type Matrix35.pointer3");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer4, ExpectedType53 *: 1, default: 0), "field type Matrix35.pointer4");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer5, ExpectedType55 *: 1, default: 0), "field type Matrix35.pointer5");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer6, ExpectedType56 *: 1, default: 0), "field type Matrix35.pointer6");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer7, ExpectedType58 *: 1, default: 0), "field type Matrix35.pointer7");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer8, ExpectedType60 *: 1, default: 0), "field type Matrix35.pointer8");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer9, ExpectedType63 *: 1, default: 0), "field type Matrix35.pointer9");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer10, ExpectedType65 *: 1, default: 0), "field type Matrix35.pointer10");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer11, ExpectedType66 *: 1, default: 0), "field type Matrix35.pointer11");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->pointer_array, ExpectedType98 *: 1, default: 0), "field type Matrix35.pointer_array");
_Static_assert(_Generic(&((hepta_Matrix35*)0)->array_pointer_array, ExpectedType99 *: 1, default: 0), "field type Matrix35.array_pointer_array");
ExpectedType12 abi_c_spill(uint64_t arg0, double arg1, uint64_t arg2, double arg3, uint64_t arg4, double arg5, uint64_t arg6, double arg7, uint64_t arg8, double arg9, uint64_t arg10, double arg11, uint64_t arg12, double arg13, uint64_t arg14, double arg15, uint64_t arg16, double arg17, uint64_t arg18, double arg19, ExpectedType12 record) { assert(arg0 == (uint64_t)37); assert(arg1 == (double)74); assert(arg2 == (uint64_t)111); assert(arg3 == (double)148); assert(arg4 == (uint64_t)185); assert(arg5 == (double)222); assert(arg6 == (uint64_t)259); assert(arg7 == (double)296); assert(arg8 == (uint64_t)333); assert(arg9 == (double)370); assert(arg10 == (uint64_t)407); assert(arg11 == (double)444); assert(arg12 == (uint64_t)481); assert(arg13 == (double)518); assert(arg14 == (uint64_t)555); assert(arg15 == (double)592); assert(arg16 == (uint64_t)629); assert(arg17 == (double)666); assert(arg18 == (uint64_t)703); assert(arg19 == (double)740); ++abi_calls; return record; }
#ifdef ABI_LAYOUT
extern size_t abi_probe_Matrix00_size(void);
/* expression: sizeof(hepta_Matrix00) */
extern size_t abi_probe_Matrix00_align(void);
/* expression: _Alignof(hepta_Matrix00) */
extern size_t abi_probe_Matrix00_field0(void);
/* expression: offsetof(hepta_Matrix00, field0) */
extern size_t abi_probe_Matrix00_field1(void);
/* expression: offsetof(hepta_Matrix00, field1) */
extern size_t abi_probe_Matrix00_field2(void);
/* expression: offsetof(hepta_Matrix00, field2) */
extern size_t abi_probe_Matrix00_field3(void);
/* expression: offsetof(hepta_Matrix00, field3) */
extern size_t abi_probe_Matrix01_size(void);
/* expression: sizeof(hepta_Matrix01) */
extern size_t abi_probe_Matrix01_align(void);
/* expression: _Alignof(hepta_Matrix01) */
extern size_t abi_probe_Matrix01_field0(void);
/* expression: offsetof(hepta_Matrix01, field0) */
extern size_t abi_probe_Matrix01_field1(void);
/* expression: offsetof(hepta_Matrix01, field1) */
extern size_t abi_probe_Matrix01_field2(void);
/* expression: offsetof(hepta_Matrix01, field2) */
extern size_t abi_probe_Matrix01_field3(void);
/* expression: offsetof(hepta_Matrix01, field3) */
extern size_t abi_probe_Matrix02_size(void);
/* expression: sizeof(hepta_Matrix02) */
extern size_t abi_probe_Matrix02_align(void);
/* expression: _Alignof(hepta_Matrix02) */
extern size_t abi_probe_Matrix02_field0(void);
/* expression: offsetof(hepta_Matrix02, field0) */
extern size_t abi_probe_Matrix03_size(void);
/* expression: sizeof(hepta_Matrix03) */
extern size_t abi_probe_Matrix03_align(void);
/* expression: _Alignof(hepta_Matrix03) */
extern size_t abi_probe_Matrix03_field0(void);
/* expression: offsetof(hepta_Matrix03, field0) */
extern size_t abi_probe_Matrix03_field1(void);
/* expression: offsetof(hepta_Matrix03, field1) */
extern size_t abi_probe_Matrix03_field2(void);
/* expression: offsetof(hepta_Matrix03, field2) */
extern size_t abi_probe_Matrix03_field3(void);
/* expression: offsetof(hepta_Matrix03, field3) */
extern size_t abi_probe_Matrix03_field4(void);
/* expression: offsetof(hepta_Matrix03, field4) */
extern size_t abi_probe_Matrix04_size(void);
/* expression: sizeof(hepta_Matrix04) */
extern size_t abi_probe_Matrix04_align(void);
/* expression: _Alignof(hepta_Matrix04) */
extern size_t abi_probe_Matrix04_field0(void);
/* expression: offsetof(hepta_Matrix04, field0) */
extern size_t abi_probe_Matrix04_field1(void);
/* expression: offsetof(hepta_Matrix04, field1) */
extern size_t abi_probe_Matrix04_field2(void);
/* expression: offsetof(hepta_Matrix04, field2) */
extern size_t abi_probe_Matrix04_field3(void);
/* expression: offsetof(hepta_Matrix04, field3) */
extern size_t abi_probe_Matrix05_size(void);
/* expression: sizeof(hepta_Matrix05) */
extern size_t abi_probe_Matrix05_align(void);
/* expression: _Alignof(hepta_Matrix05) */
extern size_t abi_probe_Matrix05_field0(void);
/* expression: offsetof(hepta_Matrix05, field0) */
extern size_t abi_probe_Matrix06_size(void);
/* expression: sizeof(hepta_Matrix06) */
extern size_t abi_probe_Matrix06_align(void);
/* expression: _Alignof(hepta_Matrix06) */
extern size_t abi_probe_Matrix06_field0(void);
/* expression: offsetof(hepta_Matrix06, field0) */
extern size_t abi_probe_Matrix06_field1(void);
/* expression: offsetof(hepta_Matrix06, field1) */
extern size_t abi_probe_Matrix06_field2(void);
/* expression: offsetof(hepta_Matrix06, field2) */
extern size_t abi_probe_Matrix07_size(void);
/* expression: sizeof(hepta_Matrix07) */
extern size_t abi_probe_Matrix07_align(void);
/* expression: _Alignof(hepta_Matrix07) */
extern size_t abi_probe_Matrix07_field0(void);
/* expression: offsetof(hepta_Matrix07, field0) */
extern size_t abi_probe_Matrix08_size(void);
/* expression: sizeof(hepta_Matrix08) */
extern size_t abi_probe_Matrix08_align(void);
/* expression: _Alignof(hepta_Matrix08) */
extern size_t abi_probe_Matrix08_field0(void);
/* expression: offsetof(hepta_Matrix08, field0) */
extern size_t abi_probe_Matrix09_size(void);
/* expression: sizeof(hepta_Matrix09) */
extern size_t abi_probe_Matrix09_align(void);
/* expression: _Alignof(hepta_Matrix09) */
extern size_t abi_probe_Matrix09_field0(void);
/* expression: offsetof(hepta_Matrix09, field0) */
extern size_t abi_probe_Matrix09_field1(void);
/* expression: offsetof(hepta_Matrix09, field1) */
extern size_t abi_probe_Matrix10_size(void);
/* expression: sizeof(hepta_Matrix10) */
extern size_t abi_probe_Matrix10_align(void);
/* expression: _Alignof(hepta_Matrix10) */
extern size_t abi_probe_Matrix10_field0(void);
/* expression: offsetof(hepta_Matrix10, field0) */
extern size_t abi_probe_Matrix10_field1(void);
/* expression: offsetof(hepta_Matrix10, field1) */
extern size_t abi_probe_Matrix11_size(void);
/* expression: sizeof(hepta_Matrix11) */
extern size_t abi_probe_Matrix11_align(void);
/* expression: _Alignof(hepta_Matrix11) */
extern size_t abi_probe_Matrix11_field0(void);
/* expression: offsetof(hepta_Matrix11, field0) */
extern size_t abi_probe_Matrix11_field1(void);
/* expression: offsetof(hepta_Matrix11, field1) */
extern size_t abi_probe_Matrix11_field2(void);
/* expression: offsetof(hepta_Matrix11, field2) */
extern size_t abi_probe_Matrix11_field3(void);
/* expression: offsetof(hepta_Matrix11, field3) */
extern size_t abi_probe_Matrix12_size(void);
/* expression: sizeof(hepta_Matrix12) */
extern size_t abi_probe_Matrix12_align(void);
/* expression: _Alignof(hepta_Matrix12) */
extern size_t abi_probe_Matrix12_field0(void);
/* expression: offsetof(hepta_Matrix12, field0) */
extern size_t abi_probe_Matrix12_field1(void);
/* expression: offsetof(hepta_Matrix12, field1) */
extern size_t abi_probe_Matrix13_size(void);
/* expression: sizeof(hepta_Matrix13) */
extern size_t abi_probe_Matrix13_align(void);
/* expression: _Alignof(hepta_Matrix13) */
extern size_t abi_probe_Matrix13_field0(void);
/* expression: offsetof(hepta_Matrix13, field0) */
extern size_t abi_probe_Matrix13_field1(void);
/* expression: offsetof(hepta_Matrix13, field1) */
extern size_t abi_probe_Matrix14_size(void);
/* expression: sizeof(hepta_Matrix14) */
extern size_t abi_probe_Matrix14_align(void);
/* expression: _Alignof(hepta_Matrix14) */
extern size_t abi_probe_Matrix14_field0(void);
/* expression: offsetof(hepta_Matrix14, field0) */
extern size_t abi_probe_Matrix15_size(void);
/* expression: sizeof(hepta_Matrix15) */
extern size_t abi_probe_Matrix15_align(void);
/* expression: _Alignof(hepta_Matrix15) */
extern size_t abi_probe_Matrix15_field0(void);
/* expression: offsetof(hepta_Matrix15, field0) */
extern size_t abi_probe_Matrix15_field1(void);
/* expression: offsetof(hepta_Matrix15, field1) */
extern size_t abi_probe_Matrix15_field2(void);
/* expression: offsetof(hepta_Matrix15, field2) */
extern size_t abi_probe_Matrix15_field3(void);
/* expression: offsetof(hepta_Matrix15, field3) */
extern size_t abi_probe_Matrix16_size(void);
/* expression: sizeof(hepta_Matrix16) */
extern size_t abi_probe_Matrix16_align(void);
/* expression: _Alignof(hepta_Matrix16) */
extern size_t abi_probe_Matrix16_field0(void);
/* expression: offsetof(hepta_Matrix16, field0) */
extern size_t abi_probe_Matrix16_field1(void);
/* expression: offsetof(hepta_Matrix16, field1) */
extern size_t abi_probe_Matrix16_field2(void);
/* expression: offsetof(hepta_Matrix16, field2) */
extern size_t abi_probe_Matrix16_field3(void);
/* expression: offsetof(hepta_Matrix16, field3) */
extern size_t abi_probe_Matrix16_field4(void);
/* expression: offsetof(hepta_Matrix16, field4) */
extern size_t abi_probe_Matrix17_size(void);
/* expression: sizeof(hepta_Matrix17) */
extern size_t abi_probe_Matrix17_align(void);
/* expression: _Alignof(hepta_Matrix17) */
extern size_t abi_probe_Matrix17_field0(void);
/* expression: offsetof(hepta_Matrix17, field0) */
extern size_t abi_probe_Matrix17_field1(void);
/* expression: offsetof(hepta_Matrix17, field1) */
extern size_t abi_probe_Matrix17_field2(void);
/* expression: offsetof(hepta_Matrix17, field2) */
extern size_t abi_probe_Matrix18_size(void);
/* expression: sizeof(hepta_Matrix18) */
extern size_t abi_probe_Matrix18_align(void);
/* expression: _Alignof(hepta_Matrix18) */
extern size_t abi_probe_Matrix18_field0(void);
/* expression: offsetof(hepta_Matrix18, field0) */
extern size_t abi_probe_Matrix18_field1(void);
/* expression: offsetof(hepta_Matrix18, field1) */
extern size_t abi_probe_Matrix18_field2(void);
/* expression: offsetof(hepta_Matrix18, field2) */
extern size_t abi_probe_Matrix18_field3(void);
/* expression: offsetof(hepta_Matrix18, field3) */
extern size_t abi_probe_Matrix19_size(void);
/* expression: sizeof(hepta_Matrix19) */
extern size_t abi_probe_Matrix19_align(void);
/* expression: _Alignof(hepta_Matrix19) */
extern size_t abi_probe_Matrix19_field0(void);
/* expression: offsetof(hepta_Matrix19, field0) */
extern size_t abi_probe_Matrix20_size(void);
/* expression: sizeof(hepta_Matrix20) */
extern size_t abi_probe_Matrix20_align(void);
/* expression: _Alignof(hepta_Matrix20) */
extern size_t abi_probe_Matrix20_field0(void);
/* expression: offsetof(hepta_Matrix20, field0) */
extern size_t abi_probe_Matrix21_size(void);
/* expression: sizeof(hepta_Matrix21) */
extern size_t abi_probe_Matrix21_align(void);
/* expression: _Alignof(hepta_Matrix21) */
extern size_t abi_probe_Matrix21_field0(void);
/* expression: offsetof(hepta_Matrix21, field0) */
extern size_t abi_probe_Matrix21_field1(void);
/* expression: offsetof(hepta_Matrix21, field1) */
extern size_t abi_probe_Matrix21_field2(void);
/* expression: offsetof(hepta_Matrix21, field2) */
extern size_t abi_probe_Matrix21_field3(void);
/* expression: offsetof(hepta_Matrix21, field3) */
extern size_t abi_probe_Matrix22_size(void);
/* expression: sizeof(hepta_Matrix22) */
extern size_t abi_probe_Matrix22_align(void);
/* expression: _Alignof(hepta_Matrix22) */
extern size_t abi_probe_Matrix22_field0(void);
/* expression: offsetof(hepta_Matrix22, field0) */
extern size_t abi_probe_Matrix22_field1(void);
/* expression: offsetof(hepta_Matrix22, field1) */
extern size_t abi_probe_Matrix22_field2(void);
/* expression: offsetof(hepta_Matrix22, field2) */
extern size_t abi_probe_Matrix23_size(void);
/* expression: sizeof(hepta_Matrix23) */
extern size_t abi_probe_Matrix23_align(void);
/* expression: _Alignof(hepta_Matrix23) */
extern size_t abi_probe_Matrix23_field0(void);
/* expression: offsetof(hepta_Matrix23, field0) */
extern size_t abi_probe_Matrix23_field1(void);
/* expression: offsetof(hepta_Matrix23, field1) */
extern size_t abi_probe_Matrix23_field2(void);
/* expression: offsetof(hepta_Matrix23, field2) */
extern size_t abi_probe_Matrix23_field3(void);
/* expression: offsetof(hepta_Matrix23, field3) */
extern size_t abi_probe_Matrix24_size(void);
/* expression: sizeof(hepta_Matrix24) */
extern size_t abi_probe_Matrix24_align(void);
/* expression: _Alignof(hepta_Matrix24) */
extern size_t abi_probe_Matrix24_field0(void);
/* expression: offsetof(hepta_Matrix24, field0) */
extern size_t abi_probe_Matrix25_size(void);
/* expression: sizeof(hepta_Matrix25) */
extern size_t abi_probe_Matrix25_align(void);
/* expression: _Alignof(hepta_Matrix25) */
extern size_t abi_probe_Matrix25_field0(void);
/* expression: offsetof(hepta_Matrix25, field0) */
extern size_t abi_probe_Matrix25_field1(void);
/* expression: offsetof(hepta_Matrix25, field1) */
extern size_t abi_probe_Matrix25_field2(void);
/* expression: offsetof(hepta_Matrix25, field2) */
extern size_t abi_probe_Matrix25_field3(void);
/* expression: offsetof(hepta_Matrix25, field3) */
extern size_t abi_probe_Matrix26_size(void);
/* expression: sizeof(hepta_Matrix26) */
extern size_t abi_probe_Matrix26_align(void);
/* expression: _Alignof(hepta_Matrix26) */
extern size_t abi_probe_Matrix26_field0(void);
/* expression: offsetof(hepta_Matrix26, field0) */
extern size_t abi_probe_Matrix26_field1(void);
/* expression: offsetof(hepta_Matrix26, field1) */
extern size_t abi_probe_Matrix26_field2(void);
/* expression: offsetof(hepta_Matrix26, field2) */
extern size_t abi_probe_Matrix27_size(void);
/* expression: sizeof(hepta_Matrix27) */
extern size_t abi_probe_Matrix27_align(void);
/* expression: _Alignof(hepta_Matrix27) */
extern size_t abi_probe_Matrix27_field0(void);
/* expression: offsetof(hepta_Matrix27, field0) */
extern size_t abi_probe_Matrix27_field1(void);
/* expression: offsetof(hepta_Matrix27, field1) */
extern size_t abi_probe_Matrix27_field2(void);
/* expression: offsetof(hepta_Matrix27, field2) */
extern size_t abi_probe_Matrix28_size(void);
/* expression: sizeof(hepta_Matrix28) */
extern size_t abi_probe_Matrix28_align(void);
/* expression: _Alignof(hepta_Matrix28) */
extern size_t abi_probe_Matrix28_field0(void);
/* expression: offsetof(hepta_Matrix28, field0) */
extern size_t abi_probe_Matrix28_field1(void);
/* expression: offsetof(hepta_Matrix28, field1) */
extern size_t abi_probe_Matrix28_field2(void);
/* expression: offsetof(hepta_Matrix28, field2) */
extern size_t abi_probe_Matrix28_field3(void);
/* expression: offsetof(hepta_Matrix28, field3) */
extern size_t abi_probe_Matrix29_size(void);
/* expression: sizeof(hepta_Matrix29) */
extern size_t abi_probe_Matrix29_align(void);
/* expression: _Alignof(hepta_Matrix29) */
extern size_t abi_probe_Matrix29_field0(void);
/* expression: offsetof(hepta_Matrix29, field0) */
extern size_t abi_probe_Matrix30_size(void);
/* expression: sizeof(hepta_Matrix30) */
extern size_t abi_probe_Matrix30_align(void);
/* expression: _Alignof(hepta_Matrix30) */
extern size_t abi_probe_Matrix30_field0(void);
/* expression: offsetof(hepta_Matrix30, field0) */
extern size_t abi_probe_Matrix30_field1(void);
/* expression: offsetof(hepta_Matrix30, field1) */
extern size_t abi_probe_Matrix30_field2(void);
/* expression: offsetof(hepta_Matrix30, field2) */
extern size_t abi_probe_Matrix30_field3(void);
/* expression: offsetof(hepta_Matrix30, field3) */
extern size_t abi_probe_Matrix30_field4(void);
/* expression: offsetof(hepta_Matrix30, field4) */
extern size_t abi_probe_Matrix31_size(void);
/* expression: sizeof(hepta_Matrix31) */
extern size_t abi_probe_Matrix31_align(void);
/* expression: _Alignof(hepta_Matrix31) */
extern size_t abi_probe_Matrix31_field0(void);
/* expression: offsetof(hepta_Matrix31, field0) */
extern size_t abi_probe_Matrix31_field1(void);
/* expression: offsetof(hepta_Matrix31, field1) */
extern size_t abi_probe_Matrix32_size(void);
/* expression: sizeof(hepta_Matrix32) */
extern size_t abi_probe_Matrix32_align(void);
/* expression: _Alignof(hepta_Matrix32) */
extern size_t abi_probe_Matrix32_field0(void);
/* expression: offsetof(hepta_Matrix32, field0) */
extern size_t abi_probe_Matrix33_size(void);
/* expression: sizeof(hepta_Matrix33) */
extern size_t abi_probe_Matrix33_align(void);
/* expression: _Alignof(hepta_Matrix33) */
extern size_t abi_probe_Matrix33_field0(void);
/* expression: offsetof(hepta_Matrix33, field0) */
extern size_t abi_probe_Matrix33_field1(void);
/* expression: offsetof(hepta_Matrix33, field1) */
extern size_t abi_probe_Matrix33_field2(void);
/* expression: offsetof(hepta_Matrix33, field2) */
extern size_t abi_probe_Matrix33_field3(void);
/* expression: offsetof(hepta_Matrix33, field3) */
extern size_t abi_probe_Matrix33_field4(void);
/* expression: offsetof(hepta_Matrix33, field4) */
extern size_t abi_probe_Matrix34_size(void);
/* expression: sizeof(hepta_Matrix34) */
extern size_t abi_probe_Matrix34_align(void);
/* expression: _Alignof(hepta_Matrix34) */
extern size_t abi_probe_Matrix34_field0(void);
/* expression: offsetof(hepta_Matrix34, field0) */
extern size_t abi_probe_Matrix35_size(void);
/* expression: sizeof(hepta_Matrix35) */
extern size_t abi_probe_Matrix35_align(void);
/* expression: _Alignof(hepta_Matrix35) */
extern size_t abi_probe_Matrix35_pointer0(void);
/* expression: offsetof(hepta_Matrix35, pointer0) */
extern size_t abi_probe_Matrix35_pointer1(void);
/* expression: offsetof(hepta_Matrix35, pointer1) */
extern size_t abi_probe_Matrix35_pointer2(void);
/* expression: offsetof(hepta_Matrix35, pointer2) */
extern size_t abi_probe_Matrix35_pointer3(void);
/* expression: offsetof(hepta_Matrix35, pointer3) */
extern size_t abi_probe_Matrix35_pointer4(void);
/* expression: offsetof(hepta_Matrix35, pointer4) */
extern size_t abi_probe_Matrix35_pointer5(void);
/* expression: offsetof(hepta_Matrix35, pointer5) */
extern size_t abi_probe_Matrix35_pointer6(void);
/* expression: offsetof(hepta_Matrix35, pointer6) */
extern size_t abi_probe_Matrix35_pointer7(void);
/* expression: offsetof(hepta_Matrix35, pointer7) */
extern size_t abi_probe_Matrix35_pointer8(void);
/* expression: offsetof(hepta_Matrix35, pointer8) */
extern size_t abi_probe_Matrix35_pointer9(void);
/* expression: offsetof(hepta_Matrix35, pointer9) */
extern size_t abi_probe_Matrix35_pointer10(void);
/* expression: offsetof(hepta_Matrix35, pointer10) */
extern size_t abi_probe_Matrix35_pointer11(void);
/* expression: offsetof(hepta_Matrix35, pointer11) */
extern size_t abi_probe_Matrix35_pointer_array(void);
/* expression: offsetof(hepta_Matrix35, pointer_array) */
extern size_t abi_probe_Matrix35_array_pointer_array(void);
/* expression: offsetof(hepta_Matrix35, array_pointer_array) */
#endif
int main(void) {
{
ExpectedType0 v_scalar0_0 = {0};
v_scalar0_0 = (ExpectedType0)(UINT64_C(216));
ExpectedType0 out_v_scalar0_0 = abi_h_scalar0(v_scalar0_0);
assert(v_scalar0_0 == out_v_scalar0_0);
}
{
ExpectedType0 v_scalar0_1 = {0};
v_scalar0_1 = (ExpectedType0)(UINT64_C(251));
ExpectedType0 out_v_scalar0_1 = abi_h_scalar0(v_scalar0_1);
assert(v_scalar0_1 == out_v_scalar0_1);
}
{
ExpectedType0 v_scalar0_2 = {0};
v_scalar0_2 = (ExpectedType0)(UINT64_C(36));
ExpectedType0 out_v_scalar0_2 = abi_h_scalar0(v_scalar0_2);
assert(v_scalar0_2 == out_v_scalar0_2);
}
{
ExpectedType1 v_scalar1_0 = {0};
v_scalar1_0 = (ExpectedType1)(INT64_C(107));
ExpectedType1 out_v_scalar1_0 = abi_h_scalar1(v_scalar1_0);
assert(v_scalar1_0 == out_v_scalar1_0);
}
{
ExpectedType1 v_scalar1_1 = {0};
v_scalar1_1 = (ExpectedType1)((-INT64_C(38)));
ExpectedType1 out_v_scalar1_1 = abi_h_scalar1(v_scalar1_1);
assert(v_scalar1_1 == out_v_scalar1_1);
}
{
ExpectedType1 v_scalar1_2 = {0};
v_scalar1_2 = (ExpectedType1)((-INT64_C(38)));
ExpectedType1 out_v_scalar1_2 = abi_h_scalar1(v_scalar1_2);
assert(v_scalar1_2 == out_v_scalar1_2);
}
{
ExpectedType2 v_scalar2_0 = {0};
v_scalar2_0 = (ExpectedType2)(UINT64_C(52613));
ExpectedType2 out_v_scalar2_0 = abi_h_scalar2(v_scalar2_0);
assert(v_scalar2_0 == out_v_scalar2_0);
}
{
ExpectedType2 v_scalar2_1 = {0};
v_scalar2_1 = (ExpectedType2)(UINT64_C(56334));
ExpectedType2 out_v_scalar2_1 = abi_h_scalar2(v_scalar2_1);
assert(v_scalar2_1 == out_v_scalar2_1);
}
{
ExpectedType2 v_scalar2_2 = {0};
v_scalar2_2 = (ExpectedType2)(UINT64_C(48425));
ExpectedType2 out_v_scalar2_2 = abi_h_scalar2(v_scalar2_2);
assert(v_scalar2_2 == out_v_scalar2_2);
}
{
ExpectedType3 v_scalar3_0 = {0};
v_scalar3_0 = (ExpectedType3)((-INT64_C(22299)));
ExpectedType3 out_v_scalar3_0 = abi_h_scalar3(v_scalar3_0);
assert(v_scalar3_0 == out_v_scalar3_0);
}
{
ExpectedType3 v_scalar3_1 = {0};
v_scalar3_1 = (ExpectedType3)((-INT64_C(20438)));
ExpectedType3 out_v_scalar3_1 = abi_h_scalar3(v_scalar3_1);
assert(v_scalar3_1 == out_v_scalar3_1);
}
{
ExpectedType3 v_scalar3_2 = {0};
v_scalar3_2 = (ExpectedType3)(INT64_C(9335));
ExpectedType3 out_v_scalar3_2 = abi_h_scalar3(v_scalar3_2);
assert(v_scalar3_2 == out_v_scalar3_2);
}
{
ExpectedType4 v_scalar4_0 = {0};
v_scalar4_0 = (ExpectedType4)(UINT64_C(1664019488));
ExpectedType4 out_v_scalar4_0 = abi_h_scalar4(v_scalar4_0);
assert(v_scalar4_0 == out_v_scalar4_0);
}
{
ExpectedType4 v_scalar4_1 = {0};
v_scalar4_1 = (ExpectedType4)(UINT64_C(4097705077));
ExpectedType4 out_v_scalar4_1 = abi_h_scalar4(v_scalar4_1);
assert(v_scalar4_1 == out_v_scalar4_1);
}
{
ExpectedType4 v_scalar4_2 = {0};
v_scalar4_2 = (ExpectedType4)(UINT64_C(1661652436));
ExpectedType4 out_v_scalar4_2 = abi_h_scalar4(v_scalar4_2);
assert(v_scalar4_2 == out_v_scalar4_2);
}
{
ExpectedType5 v_scalar5_0 = {0};
v_scalar5_0 = (ExpectedType5)(INT64_C(1240709813));
ExpectedType5 out_v_scalar5_0 = abi_h_scalar5(v_scalar5_0);
assert(v_scalar5_0 == out_v_scalar5_0);
}
{
ExpectedType5 v_scalar5_1 = {0};
v_scalar5_1 = (ExpectedType5)((-INT64_C(828223921)));
ExpectedType5 out_v_scalar5_1 = abi_h_scalar5(v_scalar5_1);
assert(v_scalar5_1 == out_v_scalar5_1);
}
{
ExpectedType5 v_scalar5_2 = {0};
v_scalar5_2 = (ExpectedType5)(INT64_C(137984829));
ExpectedType5 out_v_scalar5_2 = abi_h_scalar5(v_scalar5_2);
assert(v_scalar5_2 == out_v_scalar5_2);
}
{
ExpectedType6 v_scalar6_0 = {0};
v_scalar6_0 = (ExpectedType6)(UINT64_C(5002313087997713965));
ExpectedType6 out_v_scalar6_0 = abi_h_scalar6(v_scalar6_0);
assert(v_scalar6_0 == out_v_scalar6_0);
}
{
ExpectedType6 v_scalar6_1 = {0};
v_scalar6_1 = (ExpectedType6)(UINT64_C(3638978407368891588));
ExpectedType6 out_v_scalar6_1 = abi_h_scalar6(v_scalar6_1);
assert(v_scalar6_1 == out_v_scalar6_1);
}
{
ExpectedType6 v_scalar6_2 = {0};
v_scalar6_2 = (ExpectedType6)(UINT64_C(5774810984062929865));
ExpectedType6 out_v_scalar6_2 = abi_h_scalar6(v_scalar6_2);
assert(v_scalar6_2 == out_v_scalar6_2);
}
{
ExpectedType7 v_scalar7_0 = {0};
v_scalar7_0 = (ExpectedType7)(INT64_C(7261764645636058812));
ExpectedType7 out_v_scalar7_0 = abi_h_scalar7(v_scalar7_0);
assert(v_scalar7_0 == out_v_scalar7_0);
}
{
ExpectedType7 v_scalar7_1 = {0};
v_scalar7_1 = (ExpectedType7)(INT64_C(1335818517509951501));
ExpectedType7 out_v_scalar7_1 = abi_h_scalar7(v_scalar7_1);
assert(v_scalar7_1 == out_v_scalar7_1);
}
{
ExpectedType7 v_scalar7_2 = {0};
v_scalar7_2 = (ExpectedType7)(INT64_C(7202845110947531608));
ExpectedType7 out_v_scalar7_2 = abi_h_scalar7(v_scalar7_2);
assert(v_scalar7_2 == out_v_scalar7_2);
}
{
ExpectedType8 v_scalar8_0 = {0};
v_scalar8_0 = (ExpectedType8)(UINT64_C(1280547903));
ExpectedType8 out_v_scalar8_0 = abi_h_scalar8(v_scalar8_0);
assert(v_scalar8_0 == out_v_scalar8_0);
}
{
ExpectedType8 v_scalar8_1 = {0};
v_scalar8_1 = (ExpectedType8)(UINT64_C(4209951989));
ExpectedType8 out_v_scalar8_1 = abi_h_scalar8(v_scalar8_1);
assert(v_scalar8_1 == out_v_scalar8_1);
}
{
ExpectedType8 v_scalar8_2 = {0};
v_scalar8_2 = (ExpectedType8)(UINT64_C(557839783));
ExpectedType8 out_v_scalar8_2 = abi_h_scalar8(v_scalar8_2);
assert(v_scalar8_2 == out_v_scalar8_2);
}
{
ExpectedType9 v_scalar9_0 = {0};
v_scalar9_0 = (ExpectedType9)((-INT64_C(532869468)));
ExpectedType9 out_v_scalar9_0 = abi_h_scalar9(v_scalar9_0);
assert(v_scalar9_0 == out_v_scalar9_0);
}
{
ExpectedType9 v_scalar9_1 = {0};
v_scalar9_1 = (ExpectedType9)((-INT64_C(1650223708)));
ExpectedType9 out_v_scalar9_1 = abi_h_scalar9(v_scalar9_1);
assert(v_scalar9_1 == out_v_scalar9_1);
}
{
ExpectedType9 v_scalar9_2 = {0};
v_scalar9_2 = (ExpectedType9)(INT64_C(622689480));
ExpectedType9 out_v_scalar9_2 = abi_h_scalar9(v_scalar9_2);
assert(v_scalar9_2 == out_v_scalar9_2);
}
{
ExpectedType10 v_scalar10_0 = {0};
v_scalar10_0 = (ExpectedType10)(-251.5);
ExpectedType10 out_v_scalar10_0 = abi_h_scalar10(v_scalar10_0);
assert(v_scalar10_0 == out_v_scalar10_0);
}
{
ExpectedType10 v_scalar10_1 = {0};
v_scalar10_1 = (ExpectedType10)(101.25);
ExpectedType10 out_v_scalar10_1 = abi_h_scalar10(v_scalar10_1);
assert(v_scalar10_1 == out_v_scalar10_1);
}
{
ExpectedType10 v_scalar10_2 = {0};
v_scalar10_2 = (ExpectedType10)(675.25);
ExpectedType10 out_v_scalar10_2 = abi_h_scalar10(v_scalar10_2);
assert(v_scalar10_2 == out_v_scalar10_2);
}
{
ExpectedType11 v_scalar11_0 = {0};
v_scalar11_0 = (ExpectedType11)(779.0);
ExpectedType11 out_v_scalar11_0 = abi_h_scalar11(v_scalar11_0);
assert(v_scalar11_0 == out_v_scalar11_0);
}
{
ExpectedType11 v_scalar11_1 = {0};
v_scalar11_1 = (ExpectedType11)(770.0);
ExpectedType11 out_v_scalar11_1 = abi_h_scalar11(v_scalar11_1);
assert(v_scalar11_1 == out_v_scalar11_1);
}
{
ExpectedType11 v_scalar11_2 = {0};
v_scalar11_2 = (ExpectedType11)(933.0);
ExpectedType11 out_v_scalar11_2 = abi_h_scalar11(v_scalar11_2);
assert(v_scalar11_2 == out_v_scalar11_2);
}
{
ExpectedType12 v_record0_0 = {0};
v_record0_0.field0 = (ExpectedType6)(UINT64_C(10247755541316353194));
v_record0_0.field1 = (ExpectedType3)(INT64_C(32501));
v_record0_0.field2 = (ExpectedType9)((-INT64_C(486220369)));
v_record0_0.field3 = (ExpectedType1)(INT64_C(51));
ExpectedType12 out_v_record0_0 = abi_h_record0(v_record0_0);
assert(v_record0_0.field0 == out_v_record0_0.field0);
assert(v_record0_0.field1 == out_v_record0_0.field1);
assert(v_record0_0.field2 == out_v_record0_0.field2);
assert(v_record0_0.field3 == out_v_record0_0.field3);
}
{
ExpectedType12 v_record0_1 = {0};
v_record0_1.field0 = (ExpectedType6)(UINT64_C(15240600850399634025));
v_record0_1.field1 = (ExpectedType3)((-INT64_C(16869)));
v_record0_1.field2 = (ExpectedType9)((-INT64_C(1864739246)));
v_record0_1.field3 = (ExpectedType1)((-INT64_C(35)));
ExpectedType12 out_v_record0_1 = abi_h_record0(v_record0_1);
assert(v_record0_1.field0 == out_v_record0_1.field0);
assert(v_record0_1.field1 == out_v_record0_1.field1);
assert(v_record0_1.field2 == out_v_record0_1.field2);
assert(v_record0_1.field3 == out_v_record0_1.field3);
}
{
ExpectedType12 v_record0_2 = {0};
v_record0_2.field0 = (ExpectedType6)(UINT64_C(11444578667779580827));
v_record0_2.field1 = (ExpectedType3)(INT64_C(3048));
v_record0_2.field2 = (ExpectedType9)((-INT64_C(1054337631)));
v_record0_2.field3 = (ExpectedType1)(INT64_C(63));
ExpectedType12 out_v_record0_2 = abi_h_record0(v_record0_2);
assert(v_record0_2.field0 == out_v_record0_2.field0);
assert(v_record0_2.field1 == out_v_record0_2.field1);
assert(v_record0_2.field2 == out_v_record0_2.field2);
assert(v_record0_2.field3 == out_v_record0_2.field3);
}
{
ExpectedType13 v_record1_0 = {0};
v_record1_0.field0 = (ExpectedType5)(INT64_C(737841983));
v_record1_0.field1.field0 = (ExpectedType6)(UINT64_C(4508477772137456769));
v_record1_0.field1.field1 = (ExpectedType3)((-INT64_C(1850)));
v_record1_0.field1.field2 = (ExpectedType9)((-INT64_C(1402630879)));
v_record1_0.field1.field3 = (ExpectedType1)((-INT64_C(98)));
v_record1_0.field2[0] = (ExpectedType2)(UINT64_C(29912));
v_record1_0.field2[1] = (ExpectedType2)(UINT64_C(25544));
v_record1_0.field2[2] = (ExpectedType2)(UINT64_C(35960));
v_record1_0.field2[3] = (ExpectedType2)(UINT64_C(25768));
v_record1_0.field3[0].field0 = (ExpectedType6)(UINT64_C(12687785519199302019));
v_record1_0.field3[0].field1 = (ExpectedType3)((-INT64_C(31660)));
v_record1_0.field3[0].field2 = (ExpectedType9)((-INT64_C(3988418)));
v_record1_0.field3[0].field3 = (ExpectedType1)(INT64_C(44));
v_record1_0.field3[1].field0 = (ExpectedType6)(UINT64_C(8980556698010485463));
v_record1_0.field3[1].field1 = (ExpectedType3)(INT64_C(26282));
v_record1_0.field3[1].field2 = (ExpectedType9)((-INT64_C(1090980327)));
v_record1_0.field3[1].field3 = (ExpectedType1)((-INT64_C(41)));
v_record1_0.field3[2].field0 = (ExpectedType6)(UINT64_C(6679035497586484720));
v_record1_0.field3[2].field1 = (ExpectedType3)((-INT64_C(2864)));
v_record1_0.field3[2].field2 = (ExpectedType9)(INT64_C(601487187));
v_record1_0.field3[2].field3 = (ExpectedType1)((-INT64_C(97)));
ExpectedType13 out_v_record1_0 = abi_h_record1(v_record1_0);
assert(v_record1_0.field0 == out_v_record1_0.field0);
assert(v_record1_0.field1.field0 == out_v_record1_0.field1.field0);
assert(v_record1_0.field1.field1 == out_v_record1_0.field1.field1);
assert(v_record1_0.field1.field2 == out_v_record1_0.field1.field2);
assert(v_record1_0.field1.field3 == out_v_record1_0.field1.field3);
assert(v_record1_0.field2[0] == out_v_record1_0.field2[0]);
assert(v_record1_0.field2[1] == out_v_record1_0.field2[1]);
assert(v_record1_0.field2[2] == out_v_record1_0.field2[2]);
assert(v_record1_0.field2[3] == out_v_record1_0.field2[3]);
assert(v_record1_0.field3[0].field0 == out_v_record1_0.field3[0].field0);
assert(v_record1_0.field3[0].field1 == out_v_record1_0.field3[0].field1);
assert(v_record1_0.field3[0].field2 == out_v_record1_0.field3[0].field2);
assert(v_record1_0.field3[0].field3 == out_v_record1_0.field3[0].field3);
assert(v_record1_0.field3[1].field0 == out_v_record1_0.field3[1].field0);
assert(v_record1_0.field3[1].field1 == out_v_record1_0.field3[1].field1);
assert(v_record1_0.field3[1].field2 == out_v_record1_0.field3[1].field2);
assert(v_record1_0.field3[1].field3 == out_v_record1_0.field3[1].field3);
assert(v_record1_0.field3[2].field0 == out_v_record1_0.field3[2].field0);
assert(v_record1_0.field3[2].field1 == out_v_record1_0.field3[2].field1);
assert(v_record1_0.field3[2].field2 == out_v_record1_0.field3[2].field2);
assert(v_record1_0.field3[2].field3 == out_v_record1_0.field3[2].field3);
}
{
ExpectedType13 v_record1_1 = {0};
v_record1_1.field0 = (ExpectedType5)((-INT64_C(1516237581)));
v_record1_1.field1.field0 = (ExpectedType6)(UINT64_C(11053179108706218491));
v_record1_1.field1.field1 = (ExpectedType3)((-INT64_C(22033)));
v_record1_1.field1.field2 = (ExpectedType9)((-INT64_C(1201053932)));
v_record1_1.field1.field3 = (ExpectedType1)((-INT64_C(80)));
v_record1_1.field2[0] = (ExpectedType2)(UINT64_C(60677));
v_record1_1.field2[1] = (ExpectedType2)(UINT64_C(31963));
v_record1_1.field2[2] = (ExpectedType2)(UINT64_C(19841));
v_record1_1.field2[3] = (ExpectedType2)(UINT64_C(15037));
v_record1_1.field3[0].field0 = (ExpectedType6)(UINT64_C(12075498444512652928));
v_record1_1.field3[0].field1 = (ExpectedType3)((-INT64_C(19796)));
v_record1_1.field3[0].field2 = (ExpectedType9)((-INT64_C(799053298)));
v_record1_1.field3[0].field3 = (ExpectedType1)((-INT64_C(33)));
v_record1_1.field3[1].field0 = (ExpectedType6)(UINT64_C(2653366797904527642));
v_record1_1.field3[1].field1 = (ExpectedType3)(INT64_C(12068));
v_record1_1.field3[1].field2 = (ExpectedType9)((-INT64_C(579623377)));
v_record1_1.field3[1].field3 = (ExpectedType1)(INT64_C(14));
v_record1_1.field3[2].field0 = (ExpectedType6)(UINT64_C(6093503116428981868));
v_record1_1.field3[2].field1 = (ExpectedType3)(INT64_C(2427));
v_record1_1.field3[2].field2 = (ExpectedType9)(INT64_C(319455611));
v_record1_1.field3[2].field3 = (ExpectedType1)((-INT64_C(6)));
ExpectedType13 out_v_record1_1 = abi_h_record1(v_record1_1);
assert(v_record1_1.field0 == out_v_record1_1.field0);
assert(v_record1_1.field1.field0 == out_v_record1_1.field1.field0);
assert(v_record1_1.field1.field1 == out_v_record1_1.field1.field1);
assert(v_record1_1.field1.field2 == out_v_record1_1.field1.field2);
assert(v_record1_1.field1.field3 == out_v_record1_1.field1.field3);
assert(v_record1_1.field2[0] == out_v_record1_1.field2[0]);
assert(v_record1_1.field2[1] == out_v_record1_1.field2[1]);
assert(v_record1_1.field2[2] == out_v_record1_1.field2[2]);
assert(v_record1_1.field2[3] == out_v_record1_1.field2[3]);
assert(v_record1_1.field3[0].field0 == out_v_record1_1.field3[0].field0);
assert(v_record1_1.field3[0].field1 == out_v_record1_1.field3[0].field1);
assert(v_record1_1.field3[0].field2 == out_v_record1_1.field3[0].field2);
assert(v_record1_1.field3[0].field3 == out_v_record1_1.field3[0].field3);
assert(v_record1_1.field3[1].field0 == out_v_record1_1.field3[1].field0);
assert(v_record1_1.field3[1].field1 == out_v_record1_1.field3[1].field1);
assert(v_record1_1.field3[1].field2 == out_v_record1_1.field3[1].field2);
assert(v_record1_1.field3[1].field3 == out_v_record1_1.field3[1].field3);
assert(v_record1_1.field3[2].field0 == out_v_record1_1.field3[2].field0);
assert(v_record1_1.field3[2].field1 == out_v_record1_1.field3[2].field1);
assert(v_record1_1.field3[2].field2 == out_v_record1_1.field3[2].field2);
assert(v_record1_1.field3[2].field3 == out_v_record1_1.field3[2].field3);
}
{
ExpectedType13 v_record1_2 = {0};
v_record1_2.field0 = (ExpectedType5)(INT64_C(219872136));
v_record1_2.field1.field0 = (ExpectedType6)(UINT64_C(8592145143859487664));
v_record1_2.field1.field1 = (ExpectedType3)(INT64_C(29777));
v_record1_2.field1.field2 = (ExpectedType9)(INT64_C(1909391612));
v_record1_2.field1.field3 = (ExpectedType1)(INT64_C(93));
v_record1_2.field2[0] = (ExpectedType2)(UINT64_C(54332));
v_record1_2.field2[1] = (ExpectedType2)(UINT64_C(22616));
v_record1_2.field2[2] = (ExpectedType2)(UINT64_C(42054));
v_record1_2.field2[3] = (ExpectedType2)(UINT64_C(41523));
v_record1_2.field3[0].field0 = (ExpectedType6)(UINT64_C(17091021258618744134));
v_record1_2.field3[0].field1 = (ExpectedType3)(INT64_C(1643));
v_record1_2.field3[0].field2 = (ExpectedType9)(INT64_C(2090168718));
v_record1_2.field3[0].field3 = (ExpectedType1)((-INT64_C(47)));
v_record1_2.field3[1].field0 = (ExpectedType6)(UINT64_C(16236038840844315699));
v_record1_2.field3[1].field1 = (ExpectedType3)(INT64_C(23651));
v_record1_2.field3[1].field2 = (ExpectedType9)(INT64_C(572944908));
v_record1_2.field3[1].field3 = (ExpectedType1)((-INT64_C(110)));
v_record1_2.field3[2].field0 = (ExpectedType6)(UINT64_C(7137038335571290192));
v_record1_2.field3[2].field1 = (ExpectedType3)((-INT64_C(31587)));
v_record1_2.field3[2].field2 = (ExpectedType9)((-INT64_C(1433739869)));
v_record1_2.field3[2].field3 = (ExpectedType1)(INT64_C(56));
ExpectedType13 out_v_record1_2 = abi_h_record1(v_record1_2);
assert(v_record1_2.field0 == out_v_record1_2.field0);
assert(v_record1_2.field1.field0 == out_v_record1_2.field1.field0);
assert(v_record1_2.field1.field1 == out_v_record1_2.field1.field1);
assert(v_record1_2.field1.field2 == out_v_record1_2.field1.field2);
assert(v_record1_2.field1.field3 == out_v_record1_2.field1.field3);
assert(v_record1_2.field2[0] == out_v_record1_2.field2[0]);
assert(v_record1_2.field2[1] == out_v_record1_2.field2[1]);
assert(v_record1_2.field2[2] == out_v_record1_2.field2[2]);
assert(v_record1_2.field2[3] == out_v_record1_2.field2[3]);
assert(v_record1_2.field3[0].field0 == out_v_record1_2.field3[0].field0);
assert(v_record1_2.field3[0].field1 == out_v_record1_2.field3[0].field1);
assert(v_record1_2.field3[0].field2 == out_v_record1_2.field3[0].field2);
assert(v_record1_2.field3[0].field3 == out_v_record1_2.field3[0].field3);
assert(v_record1_2.field3[1].field0 == out_v_record1_2.field3[1].field0);
assert(v_record1_2.field3[1].field1 == out_v_record1_2.field3[1].field1);
assert(v_record1_2.field3[1].field2 == out_v_record1_2.field3[1].field2);
assert(v_record1_2.field3[1].field3 == out_v_record1_2.field3[1].field3);
assert(v_record1_2.field3[2].field0 == out_v_record1_2.field3[2].field0);
assert(v_record1_2.field3[2].field1 == out_v_record1_2.field3[2].field1);
assert(v_record1_2.field3[2].field2 == out_v_record1_2.field3[2].field2);
assert(v_record1_2.field3[2].field3 == out_v_record1_2.field3[2].field3);
}
{
ExpectedType14 v_record2_0 = {0};
v_record2_0.field0 = (ExpectedType11)(866.25);
ExpectedType14 out_v_record2_0 = abi_h_record2(v_record2_0);
assert(v_record2_0.field0 == out_v_record2_0.field0);
}
{
ExpectedType14 v_record2_1 = {0};
v_record2_1.field0 = (ExpectedType11)(-25.5);
ExpectedType14 out_v_record2_1 = abi_h_record2(v_record2_1);
assert(v_record2_1.field0 == out_v_record2_1.field0);
}
{
ExpectedType14 v_record2_2 = {0};
v_record2_2.field0 = (ExpectedType11)(-961.75);
ExpectedType14 out_v_record2_2 = abi_h_record2(v_record2_2);
assert(v_record2_2.field0 == out_v_record2_2.field0);
}
{
ExpectedType15 v_record3_0 = {0};
v_record3_0.field0[0][0].field0 = (ExpectedType11)(289.25);
v_record3_0.field0[1][0].field0 = (ExpectedType11)(215.25);
v_record3_0.field1 = (ExpectedType4)(UINT64_C(3984775362));
v_record3_0.field2 = (ExpectedType3)((-INT64_C(28121)));
v_record3_0.field3 = (ExpectedType0)(UINT64_C(207));
v_record3_0.field4 = (ExpectedType3)(INT64_C(9011));
ExpectedType15 out_v_record3_0 = abi_h_record3(v_record3_0);
assert(v_record3_0.field0[0][0].field0 == out_v_record3_0.field0[0][0].field0);
assert(v_record3_0.field0[1][0].field0 == out_v_record3_0.field0[1][0].field0);
assert(v_record3_0.field1 == out_v_record3_0.field1);
assert(v_record3_0.field2 == out_v_record3_0.field2);
assert(v_record3_0.field3 == out_v_record3_0.field3);
assert(v_record3_0.field4 == out_v_record3_0.field4);
}
{
ExpectedType15 v_record3_1 = {0};
v_record3_1.field0[0][0].field0 = (ExpectedType11)(15.75);
v_record3_1.field0[1][0].field0 = (ExpectedType11)(-86.0);
v_record3_1.field1 = (ExpectedType4)(UINT64_C(180557504));
v_record3_1.field2 = (ExpectedType3)(INT64_C(15320));
v_record3_1.field3 = (ExpectedType0)(UINT64_C(9));
v_record3_1.field4 = (ExpectedType3)(INT64_C(22669));
ExpectedType15 out_v_record3_1 = abi_h_record3(v_record3_1);
assert(v_record3_1.field0[0][0].field0 == out_v_record3_1.field0[0][0].field0);
assert(v_record3_1.field0[1][0].field0 == out_v_record3_1.field0[1][0].field0);
assert(v_record3_1.field1 == out_v_record3_1.field1);
assert(v_record3_1.field2 == out_v_record3_1.field2);
assert(v_record3_1.field3 == out_v_record3_1.field3);
assert(v_record3_1.field4 == out_v_record3_1.field4);
}
{
ExpectedType15 v_record3_2 = {0};
v_record3_2.field0[0][0].field0 = (ExpectedType11)(-657.0);
v_record3_2.field0[1][0].field0 = (ExpectedType11)(-657.75);
v_record3_2.field1 = (ExpectedType4)(UINT64_C(2109216021));
v_record3_2.field2 = (ExpectedType3)(INT64_C(20119));
v_record3_2.field3 = (ExpectedType0)(UINT64_C(229));
v_record3_2.field4 = (ExpectedType3)(INT64_C(8093));
ExpectedType15 out_v_record3_2 = abi_h_record3(v_record3_2);
assert(v_record3_2.field0[0][0].field0 == out_v_record3_2.field0[0][0].field0);
assert(v_record3_2.field0[1][0].field0 == out_v_record3_2.field0[1][0].field0);
assert(v_record3_2.field1 == out_v_record3_2.field1);
assert(v_record3_2.field2 == out_v_record3_2.field2);
assert(v_record3_2.field3 == out_v_record3_2.field3);
assert(v_record3_2.field4 == out_v_record3_2.field4);
}
{
ExpectedType16 v_record4_0 = {0};
v_record4_0.field0 = (ExpectedType4)(UINT64_C(868129324));
v_record4_0.field1[0] = (ExpectedType3)(INT64_C(10825));
v_record4_0.field1[1] = (ExpectedType3)((-INT64_C(23513)));
v_record4_0.field1[2] = (ExpectedType3)((-INT64_C(3646)));
v_record4_0.field1[3] = (ExpectedType3)((-INT64_C(11024)));
v_record4_0.field2 = (ExpectedType0)(UINT64_C(154));
v_record4_0.field3 = (ExpectedType3)((-INT64_C(12228)));
ExpectedType16 out_v_record4_0 = abi_h_record4(v_record4_0);
assert(v_record4_0.field0 == out_v_record4_0.field0);
assert(v_record4_0.field1[0] == out_v_record4_0.field1[0]);
assert(v_record4_0.field1[1] == out_v_record4_0.field1[1]);
assert(v_record4_0.field1[2] == out_v_record4_0.field1[2]);
assert(v_record4_0.field1[3] == out_v_record4_0.field1[3]);
assert(v_record4_0.field2 == out_v_record4_0.field2);
assert(v_record4_0.field3 == out_v_record4_0.field3);
}
{
ExpectedType16 v_record4_1 = {0};
v_record4_1.field0 = (ExpectedType4)(UINT64_C(2036927966));
v_record4_1.field1[0] = (ExpectedType3)((-INT64_C(14006)));
v_record4_1.field1[1] = (ExpectedType3)((-INT64_C(29748)));
v_record4_1.field1[2] = (ExpectedType3)((-INT64_C(9752)));
v_record4_1.field1[3] = (ExpectedType3)((-INT64_C(24981)));
v_record4_1.field2 = (ExpectedType0)(UINT64_C(50));
v_record4_1.field3 = (ExpectedType3)(INT64_C(3891));
ExpectedType16 out_v_record4_1 = abi_h_record4(v_record4_1);
assert(v_record4_1.field0 == out_v_record4_1.field0);
assert(v_record4_1.field1[0] == out_v_record4_1.field1[0]);
assert(v_record4_1.field1[1] == out_v_record4_1.field1[1]);
assert(v_record4_1.field1[2] == out_v_record4_1.field1[2]);
assert(v_record4_1.field1[3] == out_v_record4_1.field1[3]);
assert(v_record4_1.field2 == out_v_record4_1.field2);
assert(v_record4_1.field3 == out_v_record4_1.field3);
}
{
ExpectedType16 v_record4_2 = {0};
v_record4_2.field0 = (ExpectedType4)(UINT64_C(85883966));
v_record4_2.field1[0] = (ExpectedType3)(INT64_C(1865));
v_record4_2.field1[1] = (ExpectedType3)((-INT64_C(28709)));
v_record4_2.field1[2] = (ExpectedType3)((-INT64_C(10207)));
v_record4_2.field1[3] = (ExpectedType3)((-INT64_C(30621)));
v_record4_2.field2 = (ExpectedType0)(UINT64_C(38));
v_record4_2.field3 = (ExpectedType3)(INT64_C(13142));
ExpectedType16 out_v_record4_2 = abi_h_record4(v_record4_2);
assert(v_record4_2.field0 == out_v_record4_2.field0);
assert(v_record4_2.field1[0] == out_v_record4_2.field1[0]);
assert(v_record4_2.field1[1] == out_v_record4_2.field1[1]);
assert(v_record4_2.field1[2] == out_v_record4_2.field1[2]);
assert(v_record4_2.field1[3] == out_v_record4_2.field1[3]);
assert(v_record4_2.field2 == out_v_record4_2.field2);
assert(v_record4_2.field3 == out_v_record4_2.field3);
}
{
ExpectedType17 v_record5_0 = {0};
v_record5_0.field0[0] = (ExpectedType10)(-974.75);
v_record5_0.field0[1] = (ExpectedType10)(-958.5);
v_record5_0.field0[2] = (ExpectedType10)(-925.75);
ExpectedType17 out_v_record5_0 = abi_h_record5(v_record5_0);
assert(v_record5_0.field0[0] == out_v_record5_0.field0[0]);
assert(v_record5_0.field0[1] == out_v_record5_0.field0[1]);
assert(v_record5_0.field0[2] == out_v_record5_0.field0[2]);
}
{
ExpectedType17 v_record5_1 = {0};
v_record5_1.field0[0] = (ExpectedType10)(-727.25);
v_record5_1.field0[1] = (ExpectedType10)(-414.0);
v_record5_1.field0[2] = (ExpectedType10)(-758.5);
ExpectedType17 out_v_record5_1 = abi_h_record5(v_record5_1);
assert(v_record5_1.field0[0] == out_v_record5_1.field0[0]);
assert(v_record5_1.field0[1] == out_v_record5_1.field0[1]);
assert(v_record5_1.field0[2] == out_v_record5_1.field0[2]);
}
{
ExpectedType17 v_record5_2 = {0};
v_record5_2.field0[0] = (ExpectedType10)(-420.75);
v_record5_2.field0[1] = (ExpectedType10)(729.75);
v_record5_2.field0[2] = (ExpectedType10)(-499.0);
ExpectedType17 out_v_record5_2 = abi_h_record5(v_record5_2);
assert(v_record5_2.field0[0] == out_v_record5_2.field0[0]);
assert(v_record5_2.field0[1] == out_v_record5_2.field0[1]);
assert(v_record5_2.field0[2] == out_v_record5_2.field0[2]);
}
{
ExpectedType18 v_record6_0 = {0};
v_record6_0.field0.field0 = (ExpectedType6)(UINT64_C(14657294802059066153));
v_record6_0.field0.field1 = (ExpectedType3)(INT64_C(21574));
v_record6_0.field0.field2 = (ExpectedType9)(INT64_C(2048409715));
v_record6_0.field0.field3 = (ExpectedType1)((-INT64_C(51)));
v_record6_0.field1 = (ExpectedType8)(UINT64_C(324704041));
v_record6_0.field2[0].field0 = (ExpectedType6)(UINT64_C(5766181718409719305));
v_record6_0.field2[0].field1 = (ExpectedType3)((-INT64_C(24720)));
v_record6_0.field2[0].field2 = (ExpectedType9)(INT64_C(1044886753));
v_record6_0.field2[0].field3 = (ExpectedType1)(INT64_C(53));
ExpectedType18 out_v_record6_0 = abi_h_record6(v_record6_0);
assert(v_record6_0.field0.field0 == out_v_record6_0.field0.field0);
assert(v_record6_0.field0.field1 == out_v_record6_0.field0.field1);
assert(v_record6_0.field0.field2 == out_v_record6_0.field0.field2);
assert(v_record6_0.field0.field3 == out_v_record6_0.field0.field3);
assert(v_record6_0.field1 == out_v_record6_0.field1);
assert(v_record6_0.field2[0].field0 == out_v_record6_0.field2[0].field0);
assert(v_record6_0.field2[0].field1 == out_v_record6_0.field2[0].field1);
assert(v_record6_0.field2[0].field2 == out_v_record6_0.field2[0].field2);
assert(v_record6_0.field2[0].field3 == out_v_record6_0.field2[0].field3);
}
{
ExpectedType18 v_record6_1 = {0};
v_record6_1.field0.field0 = (ExpectedType6)(UINT64_C(2825673899690472210));
v_record6_1.field0.field1 = (ExpectedType3)((-INT64_C(22471)));
v_record6_1.field0.field2 = (ExpectedType9)(INT64_C(164892027));
v_record6_1.field0.field3 = (ExpectedType1)((-INT64_C(37)));
v_record6_1.field1 = (ExpectedType8)(UINT64_C(3080593167));
v_record6_1.field2[0].field0 = (ExpectedType6)(UINT64_C(7798931249069679223));
v_record6_1.field2[0].field1 = (ExpectedType3)(INT64_C(24607));
v_record6_1.field2[0].field2 = (ExpectedType9)((-INT64_C(1270304855)));
v_record6_1.field2[0].field3 = (ExpectedType1)((-INT64_C(109)));
ExpectedType18 out_v_record6_1 = abi_h_record6(v_record6_1);
assert(v_record6_1.field0.field0 == out_v_record6_1.field0.field0);
assert(v_record6_1.field0.field1 == out_v_record6_1.field0.field1);
assert(v_record6_1.field0.field2 == out_v_record6_1.field0.field2);
assert(v_record6_1.field0.field3 == out_v_record6_1.field0.field3);
assert(v_record6_1.field1 == out_v_record6_1.field1);
assert(v_record6_1.field2[0].field0 == out_v_record6_1.field2[0].field0);
assert(v_record6_1.field2[0].field1 == out_v_record6_1.field2[0].field1);
assert(v_record6_1.field2[0].field2 == out_v_record6_1.field2[0].field2);
assert(v_record6_1.field2[0].field3 == out_v_record6_1.field2[0].field3);
}
{
ExpectedType18 v_record6_2 = {0};
v_record6_2.field0.field0 = (ExpectedType6)(UINT64_C(5052449481460783909));
v_record6_2.field0.field1 = (ExpectedType3)(INT64_C(21321));
v_record6_2.field0.field2 = (ExpectedType9)(INT64_C(1640703123));
v_record6_2.field0.field3 = (ExpectedType1)((-INT64_C(96)));
v_record6_2.field1 = (ExpectedType8)(UINT64_C(1445919587));
v_record6_2.field2[0].field0 = (ExpectedType6)(UINT64_C(3016358206900434470));
v_record6_2.field2[0].field1 = (ExpectedType3)(INT64_C(18124));
v_record6_2.field2[0].field2 = (ExpectedType9)((-INT64_C(1808964766)));
v_record6_2.field2[0].field3 = (ExpectedType1)(INT64_C(102));
ExpectedType18 out_v_record6_2 = abi_h_record6(v_record6_2);
assert(v_record6_2.field0.field0 == out_v_record6_2.field0.field0);
assert(v_record6_2.field0.field1 == out_v_record6_2.field0.field1);
assert(v_record6_2.field0.field2 == out_v_record6_2.field0.field2);
assert(v_record6_2.field0.field3 == out_v_record6_2.field0.field3);
assert(v_record6_2.field1 == out_v_record6_2.field1);
assert(v_record6_2.field2[0].field0 == out_v_record6_2.field2[0].field0);
assert(v_record6_2.field2[0].field1 == out_v_record6_2.field2[0].field1);
assert(v_record6_2.field2[0].field2 == out_v_record6_2.field2[0].field2);
assert(v_record6_2.field2[0].field3 == out_v_record6_2.field2[0].field3);
}
{
ExpectedType19 v_record7_0 = {0};
v_record7_0.field0 = (ExpectedType4)(UINT64_C(1925089495));
ExpectedType19 out_v_record7_0 = abi_h_record7(v_record7_0);
assert(v_record7_0.field0 == out_v_record7_0.field0);
}
{
ExpectedType19 v_record7_1 = {0};
v_record7_1.field0 = (ExpectedType4)(UINT64_C(3707049293));
ExpectedType19 out_v_record7_1 = abi_h_record7(v_record7_1);
assert(v_record7_1.field0 == out_v_record7_1.field0);
}
{
ExpectedType19 v_record7_2 = {0};
v_record7_2.field0 = (ExpectedType4)(UINT64_C(2351211558));
ExpectedType19 out_v_record7_2 = abi_h_record7(v_record7_2);
assert(v_record7_2.field0 == out_v_record7_2.field0);
}
{
ExpectedType20 v_record8_0 = {0};
v_record8_0.field0[0].field0[0] = (ExpectedType10)(-629.5);
v_record8_0.field0[0].field0[1] = (ExpectedType10)(52.5);
v_record8_0.field0[0].field0[2] = (ExpectedType10)(948.75);
v_record8_0.field0[1].field0[0] = (ExpectedType10)(660.75);
v_record8_0.field0[1].field0[1] = (ExpectedType10)(-29.5);
v_record8_0.field0[1].field0[2] = (ExpectedType10)(-722.25);
v_record8_0.field0[2].field0[0] = (ExpectedType10)(-916.25);
v_record8_0.field0[2].field0[1] = (ExpectedType10)(924.75);
v_record8_0.field0[2].field0[2] = (ExpectedType10)(966.5);
ExpectedType20 out_v_record8_0 = abi_h_record8(v_record8_0);
assert(v_record8_0.field0[0].field0[0] == out_v_record8_0.field0[0].field0[0]);
assert(v_record8_0.field0[0].field0[1] == out_v_record8_0.field0[0].field0[1]);
assert(v_record8_0.field0[0].field0[2] == out_v_record8_0.field0[0].field0[2]);
assert(v_record8_0.field0[1].field0[0] == out_v_record8_0.field0[1].field0[0]);
assert(v_record8_0.field0[1].field0[1] == out_v_record8_0.field0[1].field0[1]);
assert(v_record8_0.field0[1].field0[2] == out_v_record8_0.field0[1].field0[2]);
assert(v_record8_0.field0[2].field0[0] == out_v_record8_0.field0[2].field0[0]);
assert(v_record8_0.field0[2].field0[1] == out_v_record8_0.field0[2].field0[1]);
assert(v_record8_0.field0[2].field0[2] == out_v_record8_0.field0[2].field0[2]);
}
{
ExpectedType20 v_record8_1 = {0};
v_record8_1.field0[0].field0[0] = (ExpectedType10)(773.25);
v_record8_1.field0[0].field0[1] = (ExpectedType10)(205.5);
v_record8_1.field0[0].field0[2] = (ExpectedType10)(543.5);
v_record8_1.field0[1].field0[0] = (ExpectedType10)(239.5);
v_record8_1.field0[1].field0[1] = (ExpectedType10)(978.25);
v_record8_1.field0[1].field0[2] = (ExpectedType10)(787.5);
v_record8_1.field0[2].field0[0] = (ExpectedType10)(-221.0);
v_record8_1.field0[2].field0[1] = (ExpectedType10)(482.75);
v_record8_1.field0[2].field0[2] = (ExpectedType10)(391.0);
ExpectedType20 out_v_record8_1 = abi_h_record8(v_record8_1);
assert(v_record8_1.field0[0].field0[0] == out_v_record8_1.field0[0].field0[0]);
assert(v_record8_1.field0[0].field0[1] == out_v_record8_1.field0[0].field0[1]);
assert(v_record8_1.field0[0].field0[2] == out_v_record8_1.field0[0].field0[2]);
assert(v_record8_1.field0[1].field0[0] == out_v_record8_1.field0[1].field0[0]);
assert(v_record8_1.field0[1].field0[1] == out_v_record8_1.field0[1].field0[1]);
assert(v_record8_1.field0[1].field0[2] == out_v_record8_1.field0[1].field0[2]);
assert(v_record8_1.field0[2].field0[0] == out_v_record8_1.field0[2].field0[0]);
assert(v_record8_1.field0[2].field0[1] == out_v_record8_1.field0[2].field0[1]);
assert(v_record8_1.field0[2].field0[2] == out_v_record8_1.field0[2].field0[2]);
}
{
ExpectedType20 v_record8_2 = {0};
v_record8_2.field0[0].field0[0] = (ExpectedType10)(-554.5);
v_record8_2.field0[0].field0[1] = (ExpectedType10)(-865.75);
v_record8_2.field0[0].field0[2] = (ExpectedType10)(-900.25);
v_record8_2.field0[1].field0[0] = (ExpectedType10)(190.75);
v_record8_2.field0[1].field0[1] = (ExpectedType10)(131.75);
v_record8_2.field0[1].field0[2] = (ExpectedType10)(-547.0);
v_record8_2.field0[2].field0[0] = (ExpectedType10)(-444.0);
v_record8_2.field0[2].field0[1] = (ExpectedType10)(-97.75);
v_record8_2.field0[2].field0[2] = (ExpectedType10)(-119.75);
ExpectedType20 out_v_record8_2 = abi_h_record8(v_record8_2);
assert(v_record8_2.field0[0].field0[0] == out_v_record8_2.field0[0].field0[0]);
assert(v_record8_2.field0[0].field0[1] == out_v_record8_2.field0[0].field0[1]);
assert(v_record8_2.field0[0].field0[2] == out_v_record8_2.field0[0].field0[2]);
assert(v_record8_2.field0[1].field0[0] == out_v_record8_2.field0[1].field0[0]);
assert(v_record8_2.field0[1].field0[1] == out_v_record8_2.field0[1].field0[1]);
assert(v_record8_2.field0[1].field0[2] == out_v_record8_2.field0[1].field0[2]);
assert(v_record8_2.field0[2].field0[0] == out_v_record8_2.field0[2].field0[0]);
assert(v_record8_2.field0[2].field0[1] == out_v_record8_2.field0[2].field0[1]);
assert(v_record8_2.field0[2].field0[2] == out_v_record8_2.field0[2].field0[2]);
}
{
ExpectedType21 v_record9_0 = {0};
v_record9_0.field0 = (ExpectedType5)(INT64_C(1164510731));
v_record9_0.field1.field0 = (ExpectedType6)(UINT64_C(1551436511076775368));
v_record9_0.field1.field1 = (ExpectedType3)(INT64_C(20403));
v_record9_0.field1.field2 = (ExpectedType9)((-INT64_C(2035194145)));
v_record9_0.field1.field3 = (ExpectedType1)(INT64_C(60));
ExpectedType21 out_v_record9_0 = abi_h_record9(v_record9_0);
assert(v_record9_0.field0 == out_v_record9_0.field0);
assert(v_record9_0.field1.field0 == out_v_record9_0.field1.field0);
assert(v_record9_0.field1.field1 == out_v_record9_0.field1.field1);
assert(v_record9_0.field1.field2 == out_v_record9_0.field1.field2);
assert(v_record9_0.field1.field3 == out_v_record9_0.field1.field3);
}
{
ExpectedType21 v_record9_1 = {0};
v_record9_1.field0 = (ExpectedType5)((-INT64_C(371971907)));
v_record9_1.field1.field0 = (ExpectedType6)(UINT64_C(3409529013089893435));
v_record9_1.field1.field1 = (ExpectedType3)(INT64_C(14333));
v_record9_1.field1.field2 = (ExpectedType9)((-INT64_C(641617718)));
v_record9_1.field1.field3 = (ExpectedType1)((-INT64_C(112)));
ExpectedType21 out_v_record9_1 = abi_h_record9(v_record9_1);
assert(v_record9_1.field0 == out_v_record9_1.field0);
assert(v_record9_1.field1.field0 == out_v_record9_1.field1.field0);
assert(v_record9_1.field1.field1 == out_v_record9_1.field1.field1);
assert(v_record9_1.field1.field2 == out_v_record9_1.field1.field2);
assert(v_record9_1.field1.field3 == out_v_record9_1.field1.field3);
}
{
ExpectedType21 v_record9_2 = {0};
v_record9_2.field0 = (ExpectedType5)(INT64_C(1740745125));
v_record9_2.field1.field0 = (ExpectedType6)(UINT64_C(15642375245711899075));
v_record9_2.field1.field1 = (ExpectedType3)(INT64_C(27992));
v_record9_2.field1.field2 = (ExpectedType9)(INT64_C(293942809));
v_record9_2.field1.field3 = (ExpectedType1)((-INT64_C(14)));
ExpectedType21 out_v_record9_2 = abi_h_record9(v_record9_2);
assert(v_record9_2.field0 == out_v_record9_2.field0);
assert(v_record9_2.field1.field0 == out_v_record9_2.field1.field0);
assert(v_record9_2.field1.field1 == out_v_record9_2.field1.field1);
assert(v_record9_2.field1.field2 == out_v_record9_2.field1.field2);
assert(v_record9_2.field1.field3 == out_v_record9_2.field1.field3);
}
{
ExpectedType22 v_record10_0 = {0};
v_record10_0.field0 = (ExpectedType0)(UINT64_C(137));
v_record10_0.field1 = (ExpectedType6)(UINT64_C(12213722129215673395));
ExpectedType22 out_v_record10_0 = abi_h_record10(v_record10_0);
assert(v_record10_0.field0 == out_v_record10_0.field0);
assert(v_record10_0.field1 == out_v_record10_0.field1);
}
{
ExpectedType22 v_record10_1 = {0};
v_record10_1.field0 = (ExpectedType0)(UINT64_C(79));
v_record10_1.field1 = (ExpectedType6)(UINT64_C(14276113020319390187));
ExpectedType22 out_v_record10_1 = abi_h_record10(v_record10_1);
assert(v_record10_1.field0 == out_v_record10_1.field0);
assert(v_record10_1.field1 == out_v_record10_1.field1);
}
{
ExpectedType22 v_record10_2 = {0};
v_record10_2.field0 = (ExpectedType0)(UINT64_C(101));
v_record10_2.field1 = (ExpectedType6)(UINT64_C(4161876314873207193));
ExpectedType22 out_v_record10_2 = abi_h_record10(v_record10_2);
assert(v_record10_2.field0 == out_v_record10_2.field0);
assert(v_record10_2.field1 == out_v_record10_2.field1);
}
{
ExpectedType23 v_record11_0 = {0};
v_record11_0.field0.field0 = (ExpectedType0)(UINT64_C(182));
v_record11_0.field0.field1 = (ExpectedType6)(UINT64_C(13401105814573224005));
v_record11_0.field1 = (ExpectedType11)(-446.5);
v_record11_0.field2.field0 = (ExpectedType5)(INT64_C(1716219704));
v_record11_0.field2.field1.field0 = (ExpectedType6)(UINT64_C(11920817565177393080));
v_record11_0.field2.field1.field1 = (ExpectedType3)((-INT64_C(915)));
v_record11_0.field2.field1.field2 = (ExpectedType9)((-INT64_C(83102856)));
v_record11_0.field2.field1.field3 = (ExpectedType1)(INT64_C(72));
v_record11_0.field3[0] = (ExpectedType7)(INT64_C(9181363685612590763));
ExpectedType23 out_v_record11_0 = abi_h_record11(v_record11_0);
assert(v_record11_0.field0.field0 == out_v_record11_0.field0.field0);
assert(v_record11_0.field0.field1 == out_v_record11_0.field0.field1);
assert(v_record11_0.field1 == out_v_record11_0.field1);
assert(v_record11_0.field2.field0 == out_v_record11_0.field2.field0);
assert(v_record11_0.field2.field1.field0 == out_v_record11_0.field2.field1.field0);
assert(v_record11_0.field2.field1.field1 == out_v_record11_0.field2.field1.field1);
assert(v_record11_0.field2.field1.field2 == out_v_record11_0.field2.field1.field2);
assert(v_record11_0.field2.field1.field3 == out_v_record11_0.field2.field1.field3);
assert(v_record11_0.field3[0] == out_v_record11_0.field3[0]);
}
{
ExpectedType23 v_record11_1 = {0};
v_record11_1.field0.field0 = (ExpectedType0)(UINT64_C(197));
v_record11_1.field0.field1 = (ExpectedType6)(UINT64_C(7524003965380486601));
v_record11_1.field1 = (ExpectedType11)(-813.25);
v_record11_1.field2.field0 = (ExpectedType5)(INT64_C(989338188));
v_record11_1.field2.field1.field0 = (ExpectedType6)(UINT64_C(2805755248237588101));
v_record11_1.field2.field1.field1 = (ExpectedType3)(INT64_C(3671));
v_record11_1.field2.field1.field2 = (ExpectedType9)(INT64_C(1017601252));
v_record11_1.field2.field1.field3 = (ExpectedType1)((-INT64_C(118)));
v_record11_1.field3[0] = (ExpectedType7)(INT64_C(6938418858935493989));
ExpectedType23 out_v_record11_1 = abi_h_record11(v_record11_1);
assert(v_record11_1.field0.field0 == out_v_record11_1.field0.field0);
assert(v_record11_1.field0.field1 == out_v_record11_1.field0.field1);
assert(v_record11_1.field1 == out_v_record11_1.field1);
assert(v_record11_1.field2.field0 == out_v_record11_1.field2.field0);
assert(v_record11_1.field2.field1.field0 == out_v_record11_1.field2.field1.field0);
assert(v_record11_1.field2.field1.field1 == out_v_record11_1.field2.field1.field1);
assert(v_record11_1.field2.field1.field2 == out_v_record11_1.field2.field1.field2);
assert(v_record11_1.field2.field1.field3 == out_v_record11_1.field2.field1.field3);
assert(v_record11_1.field3[0] == out_v_record11_1.field3[0]);
}
{
ExpectedType23 v_record11_2 = {0};
v_record11_2.field0.field0 = (ExpectedType0)(UINT64_C(191));
v_record11_2.field0.field1 = (ExpectedType6)(UINT64_C(15123967598561782898));
v_record11_2.field1 = (ExpectedType11)(384.0);
v_record11_2.field2.field0 = (ExpectedType5)(INT64_C(2095877983));
v_record11_2.field2.field1.field0 = (ExpectedType6)(UINT64_C(8609410977281175103));
v_record11_2.field2.field1.field1 = (ExpectedType3)(INT64_C(13352));
v_record11_2.field2.field1.field2 = (ExpectedType9)(INT64_C(1984656186));
v_record11_2.field2.field1.field3 = (ExpectedType1)(INT64_C(99));
v_record11_2.field3[0] = (ExpectedType7)((-INT64_C(170235647078722196)));
ExpectedType23 out_v_record11_2 = abi_h_record11(v_record11_2);
assert(v_record11_2.field0.field0 == out_v_record11_2.field0.field0);
assert(v_record11_2.field0.field1 == out_v_record11_2.field0.field1);
assert(v_record11_2.field1 == out_v_record11_2.field1);
assert(v_record11_2.field2.field0 == out_v_record11_2.field2.field0);
assert(v_record11_2.field2.field1.field0 == out_v_record11_2.field2.field1.field0);
assert(v_record11_2.field2.field1.field1 == out_v_record11_2.field2.field1.field1);
assert(v_record11_2.field2.field1.field2 == out_v_record11_2.field2.field1.field2);
assert(v_record11_2.field2.field1.field3 == out_v_record11_2.field2.field1.field3);
assert(v_record11_2.field3[0] == out_v_record11_2.field3[0]);
}
{
ExpectedType24 v_record12_0 = {0};
v_record12_0.field0.field0.field0 = (ExpectedType6)(UINT64_C(16774329128042203913));
v_record12_0.field0.field0.field1 = (ExpectedType3)((-INT64_C(16653)));
v_record12_0.field0.field0.field2 = (ExpectedType9)(INT64_C(806038309));
v_record12_0.field0.field0.field3 = (ExpectedType1)(INT64_C(64));
v_record12_0.field0.field1 = (ExpectedType8)(UINT64_C(3209415100));
v_record12_0.field0.field2[0].field0 = (ExpectedType6)(UINT64_C(3878290985796954085));
v_record12_0.field0.field2[0].field1 = (ExpectedType3)((-INT64_C(2472)));
v_record12_0.field0.field2[0].field2 = (ExpectedType9)(INT64_C(176066093));
v_record12_0.field0.field2[0].field3 = (ExpectedType1)(INT64_C(90));
v_record12_0.field1.field0[0] = (ExpectedType10)(245.0);
v_record12_0.field1.field0[1] = (ExpectedType10)(641.0);
v_record12_0.field1.field0[2] = (ExpectedType10)(-554.75);
ExpectedType24 out_v_record12_0 = abi_h_record12(v_record12_0);
assert(v_record12_0.field0.field0.field0 == out_v_record12_0.field0.field0.field0);
assert(v_record12_0.field0.field0.field1 == out_v_record12_0.field0.field0.field1);
assert(v_record12_0.field0.field0.field2 == out_v_record12_0.field0.field0.field2);
assert(v_record12_0.field0.field0.field3 == out_v_record12_0.field0.field0.field3);
assert(v_record12_0.field0.field1 == out_v_record12_0.field0.field1);
assert(v_record12_0.field0.field2[0].field0 == out_v_record12_0.field0.field2[0].field0);
assert(v_record12_0.field0.field2[0].field1 == out_v_record12_0.field0.field2[0].field1);
assert(v_record12_0.field0.field2[0].field2 == out_v_record12_0.field0.field2[0].field2);
assert(v_record12_0.field0.field2[0].field3 == out_v_record12_0.field0.field2[0].field3);
assert(v_record12_0.field1.field0[0] == out_v_record12_0.field1.field0[0]);
assert(v_record12_0.field1.field0[1] == out_v_record12_0.field1.field0[1]);
assert(v_record12_0.field1.field0[2] == out_v_record12_0.field1.field0[2]);
}
{
ExpectedType24 v_record12_1 = {0};
v_record12_1.field0.field0.field0 = (ExpectedType6)(UINT64_C(4902046640651893967));
v_record12_1.field0.field0.field1 = (ExpectedType3)((-INT64_C(23937)));
v_record12_1.field0.field0.field2 = (ExpectedType9)((-INT64_C(479328509)));
v_record12_1.field0.field0.field3 = (ExpectedType1)((-INT64_C(100)));
v_record12_1.field0.field1 = (ExpectedType8)(UINT64_C(2735540669));
v_record12_1.field0.field2[0].field0 = (ExpectedType6)(UINT64_C(7693142592486815210));
v_record12_1.field0.field2[0].field1 = (ExpectedType3)(INT64_C(27938));
v_record12_1.field0.field2[0].field2 = (ExpectedType9)(INT64_C(1840622548));
v_record12_1.field0.field2[0].field3 = (ExpectedType1)(INT64_C(17));
v_record12_1.field1.field0[0] = (ExpectedType10)(2.5);
v_record12_1.field1.field0[1] = (ExpectedType10)(-61.5);
v_record12_1.field1.field0[2] = (ExpectedType10)(-442.5);
ExpectedType24 out_v_record12_1 = abi_h_record12(v_record12_1);
assert(v_record12_1.field0.field0.field0 == out_v_record12_1.field0.field0.field0);
assert(v_record12_1.field0.field0.field1 == out_v_record12_1.field0.field0.field1);
assert(v_record12_1.field0.field0.field2 == out_v_record12_1.field0.field0.field2);
assert(v_record12_1.field0.field0.field3 == out_v_record12_1.field0.field0.field3);
assert(v_record12_1.field0.field1 == out_v_record12_1.field0.field1);
assert(v_record12_1.field0.field2[0].field0 == out_v_record12_1.field0.field2[0].field0);
assert(v_record12_1.field0.field2[0].field1 == out_v_record12_1.field0.field2[0].field1);
assert(v_record12_1.field0.field2[0].field2 == out_v_record12_1.field0.field2[0].field2);
assert(v_record12_1.field0.field2[0].field3 == out_v_record12_1.field0.field2[0].field3);
assert(v_record12_1.field1.field0[0] == out_v_record12_1.field1.field0[0]);
assert(v_record12_1.field1.field0[1] == out_v_record12_1.field1.field0[1]);
assert(v_record12_1.field1.field0[2] == out_v_record12_1.field1.field0[2]);
}
{
ExpectedType24 v_record12_2 = {0};
v_record12_2.field0.field0.field0 = (ExpectedType6)(UINT64_C(2210515635682001808));
v_record12_2.field0.field0.field1 = (ExpectedType3)((-INT64_C(29364)));
v_record12_2.field0.field0.field2 = (ExpectedType9)(INT64_C(1607666441));
v_record12_2.field0.field0.field3 = (ExpectedType1)(INT64_C(107));
v_record12_2.field0.field1 = (ExpectedType8)(UINT64_C(2718260443));
v_record12_2.field0.field2[0].field0 = (ExpectedType6)(UINT64_C(1655413427097774540));
v_record12_2.field0.field2[0].field1 = (ExpectedType3)(INT64_C(21959));
v_record12_2.field0.field2[0].field2 = (ExpectedType9)(INT64_C(1230092132));
v_record12_2.field0.field2[0].field3 = (ExpectedType1)((-INT64_C(50)));
v_record12_2.field1.field0[0] = (ExpectedType10)(30.25);
v_record12_2.field1.field0[1] = (ExpectedType10)(762.5);
v_record12_2.field1.field0[2] = (ExpectedType10)(-290.5);
ExpectedType24 out_v_record12_2 = abi_h_record12(v_record12_2);
assert(v_record12_2.field0.field0.field0 == out_v_record12_2.field0.field0.field0);
assert(v_record12_2.field0.field0.field1 == out_v_record12_2.field0.field0.field1);
assert(v_record12_2.field0.field0.field2 == out_v_record12_2.field0.field0.field2);
assert(v_record12_2.field0.field0.field3 == out_v_record12_2.field0.field0.field3);
assert(v_record12_2.field0.field1 == out_v_record12_2.field0.field1);
assert(v_record12_2.field0.field2[0].field0 == out_v_record12_2.field0.field2[0].field0);
assert(v_record12_2.field0.field2[0].field1 == out_v_record12_2.field0.field2[0].field1);
assert(v_record12_2.field0.field2[0].field2 == out_v_record12_2.field0.field2[0].field2);
assert(v_record12_2.field0.field2[0].field3 == out_v_record12_2.field0.field2[0].field3);
assert(v_record12_2.field1.field0[0] == out_v_record12_2.field1.field0[0]);
assert(v_record12_2.field1.field0[1] == out_v_record12_2.field1.field0[1]);
assert(v_record12_2.field1.field0[2] == out_v_record12_2.field1.field0[2]);
}
{
ExpectedType25 v_record13_0 = {0};
v_record13_0.field0.field0.field0 = (ExpectedType0)(UINT64_C(213));
v_record13_0.field0.field0.field1 = (ExpectedType6)(UINT64_C(12604683474560045377));
v_record13_0.field0.field1 = (ExpectedType11)(-54.0);
v_record13_0.field0.field2.field0 = (ExpectedType5)(INT64_C(1149226231));
v_record13_0.field0.field2.field1.field0 = (ExpectedType6)(UINT64_C(14019144868706237042));
v_record13_0.field0.field2.field1.field1 = (ExpectedType3)((-INT64_C(32520)));
v_record13_0.field0.field2.field1.field2 = (ExpectedType9)(INT64_C(1825573966));
v_record13_0.field0.field2.field1.field3 = (ExpectedType1)(INT64_C(48));
v_record13_0.field0.field3[0] = (ExpectedType7)(INT64_C(4847124432943989641));
v_record13_0.field1[0] = (ExpectedType10)(-239.25);
v_record13_0.field1[1] = (ExpectedType10)(217.75);
ExpectedType25 out_v_record13_0 = abi_h_record13(v_record13_0);
assert(v_record13_0.field0.field0.field0 == out_v_record13_0.field0.field0.field0);
assert(v_record13_0.field0.field0.field1 == out_v_record13_0.field0.field0.field1);
assert(v_record13_0.field0.field1 == out_v_record13_0.field0.field1);
assert(v_record13_0.field0.field2.field0 == out_v_record13_0.field0.field2.field0);
assert(v_record13_0.field0.field2.field1.field0 == out_v_record13_0.field0.field2.field1.field0);
assert(v_record13_0.field0.field2.field1.field1 == out_v_record13_0.field0.field2.field1.field1);
assert(v_record13_0.field0.field2.field1.field2 == out_v_record13_0.field0.field2.field1.field2);
assert(v_record13_0.field0.field2.field1.field3 == out_v_record13_0.field0.field2.field1.field3);
assert(v_record13_0.field0.field3[0] == out_v_record13_0.field0.field3[0]);
assert(v_record13_0.field1[0] == out_v_record13_0.field1[0]);
assert(v_record13_0.field1[1] == out_v_record13_0.field1[1]);
}
{
ExpectedType25 v_record13_1 = {0};
v_record13_1.field0.field0.field0 = (ExpectedType0)(UINT64_C(46));
v_record13_1.field0.field0.field1 = (ExpectedType6)(UINT64_C(10330574955781385989));
v_record13_1.field0.field1 = (ExpectedType11)(503.25);
v_record13_1.field0.field2.field0 = (ExpectedType5)((-INT64_C(378894850)));
v_record13_1.field0.field2.field1.field0 = (ExpectedType6)(UINT64_C(4552925903580851510));
v_record13_1.field0.field2.field1.field1 = (ExpectedType3)(INT64_C(11833));
v_record13_1.field0.field2.field1.field2 = (ExpectedType9)(INT64_C(504584946));
v_record13_1.field0.field2.field1.field3 = (ExpectedType1)((-INT64_C(31)));
v_record13_1.field0.field3[0] = (ExpectedType7)(INT64_C(2807958492176285864));
v_record13_1.field1[0] = (ExpectedType10)(49.25);
v_record13_1.field1[1] = (ExpectedType10)(-622.75);
ExpectedType25 out_v_record13_1 = abi_h_record13(v_record13_1);
assert(v_record13_1.field0.field0.field0 == out_v_record13_1.field0.field0.field0);
assert(v_record13_1.field0.field0.field1 == out_v_record13_1.field0.field0.field1);
assert(v_record13_1.field0.field1 == out_v_record13_1.field0.field1);
assert(v_record13_1.field0.field2.field0 == out_v_record13_1.field0.field2.field0);
assert(v_record13_1.field0.field2.field1.field0 == out_v_record13_1.field0.field2.field1.field0);
assert(v_record13_1.field0.field2.field1.field1 == out_v_record13_1.field0.field2.field1.field1);
assert(v_record13_1.field0.field2.field1.field2 == out_v_record13_1.field0.field2.field1.field2);
assert(v_record13_1.field0.field2.field1.field3 == out_v_record13_1.field0.field2.field1.field3);
assert(v_record13_1.field0.field3[0] == out_v_record13_1.field0.field3[0]);
assert(v_record13_1.field1[0] == out_v_record13_1.field1[0]);
assert(v_record13_1.field1[1] == out_v_record13_1.field1[1]);
}
{
ExpectedType25 v_record13_2 = {0};
v_record13_2.field0.field0.field0 = (ExpectedType0)(UINT64_C(129));
v_record13_2.field0.field0.field1 = (ExpectedType6)(UINT64_C(3502462091771196688));
v_record13_2.field0.field1 = (ExpectedType11)(1.0);
v_record13_2.field0.field2.field0 = (ExpectedType5)((-INT64_C(220432429)));
v_record13_2.field0.field2.field1.field0 = (ExpectedType6)(UINT64_C(280237878472053131));
v_record13_2.field0.field2.field1.field1 = (ExpectedType3)(INT64_C(16951));
v_record13_2.field0.field2.field1.field2 = (ExpectedType9)(INT64_C(399301232));
v_record13_2.field0.field2.field1.field3 = (ExpectedType1)((-INT64_C(71)));
v_record13_2.field0.field3[0] = (ExpectedType7)(INT64_C(6595339567445603181));
v_record13_2.field1[0] = (ExpectedType10)(-685.25);
v_record13_2.field1[1] = (ExpectedType10)(-417.0);
ExpectedType25 out_v_record13_2 = abi_h_record13(v_record13_2);
assert(v_record13_2.field0.field0.field0 == out_v_record13_2.field0.field0.field0);
assert(v_record13_2.field0.field0.field1 == out_v_record13_2.field0.field0.field1);
assert(v_record13_2.field0.field1 == out_v_record13_2.field0.field1);
assert(v_record13_2.field0.field2.field0 == out_v_record13_2.field0.field2.field0);
assert(v_record13_2.field0.field2.field1.field0 == out_v_record13_2.field0.field2.field1.field0);
assert(v_record13_2.field0.field2.field1.field1 == out_v_record13_2.field0.field2.field1.field1);
assert(v_record13_2.field0.field2.field1.field2 == out_v_record13_2.field0.field2.field1.field2);
assert(v_record13_2.field0.field2.field1.field3 == out_v_record13_2.field0.field2.field1.field3);
assert(v_record13_2.field0.field3[0] == out_v_record13_2.field0.field3[0]);
assert(v_record13_2.field1[0] == out_v_record13_2.field1[0]);
assert(v_record13_2.field1[1] == out_v_record13_2.field1[1]);
}
{
ExpectedType26 v_record14_0 = {0};
v_record14_0.field0[0] = (ExpectedType5)((-INT64_C(1345921824)));
v_record14_0.field0[1] = (ExpectedType5)(INT64_C(1856101469));
v_record14_0.field0[2] = (ExpectedType5)((-INT64_C(1016369029)));
ExpectedType26 out_v_record14_0 = abi_h_record14(v_record14_0);
assert(v_record14_0.field0[0] == out_v_record14_0.field0[0]);
assert(v_record14_0.field0[1] == out_v_record14_0.field0[1]);
assert(v_record14_0.field0[2] == out_v_record14_0.field0[2]);
}
{
ExpectedType26 v_record14_1 = {0};
v_record14_1.field0[0] = (ExpectedType5)(INT64_C(1418822233));
v_record14_1.field0[1] = (ExpectedType5)(INT64_C(1146379392));
v_record14_1.field0[2] = (ExpectedType5)(INT64_C(1754721368));
ExpectedType26 out_v_record14_1 = abi_h_record14(v_record14_1);
assert(v_record14_1.field0[0] == out_v_record14_1.field0[0]);
assert(v_record14_1.field0[1] == out_v_record14_1.field0[1]);
assert(v_record14_1.field0[2] == out_v_record14_1.field0[2]);
}
{
ExpectedType26 v_record14_2 = {0};
v_record14_2.field0[0] = (ExpectedType5)((-INT64_C(225811651)));
v_record14_2.field0[1] = (ExpectedType5)((-INT64_C(2057567361)));
v_record14_2.field0[2] = (ExpectedType5)((-INT64_C(1547162121)));
ExpectedType26 out_v_record14_2 = abi_h_record14(v_record14_2);
assert(v_record14_2.field0[0] == out_v_record14_2.field0[0]);
assert(v_record14_2.field0[1] == out_v_record14_2.field0[1]);
assert(v_record14_2.field0[2] == out_v_record14_2.field0[2]);
}
{
ExpectedType27 v_record15_0 = {0};
v_record15_0.field0.field0[0][0].field0 = (ExpectedType11)(-477.25);
v_record15_0.field0.field0[1][0].field0 = (ExpectedType11)(4.75);
v_record15_0.field0.field1 = (ExpectedType4)(UINT64_C(4264678052));
v_record15_0.field0.field2 = (ExpectedType3)(INT64_C(21721));
v_record15_0.field0.field3 = (ExpectedType0)(UINT64_C(129));
v_record15_0.field0.field4 = (ExpectedType3)((-INT64_C(12549)));
v_record15_0.field1[0] = (ExpectedType1)((-INT64_C(103)));
v_record15_0.field1[1] = (ExpectedType1)(INT64_C(120));
v_record15_0.field1[2] = (ExpectedType1)((-INT64_C(120)));
v_record15_0.field1[3] = (ExpectedType1)(INT64_C(79));
v_record15_0.field2[0] = (ExpectedType6)(UINT64_C(16683018599916389732));
v_record15_0.field3.field0 = (ExpectedType5)(INT64_C(1850276018));
v_record15_0.field3.field1.field0 = (ExpectedType6)(UINT64_C(17066130746484712036));
v_record15_0.field3.field1.field1 = (ExpectedType3)((-INT64_C(5755)));
v_record15_0.field3.field1.field2 = (ExpectedType9)((-INT64_C(236133926)));
v_record15_0.field3.field1.field3 = (ExpectedType1)((-INT64_C(84)));
ExpectedType27 out_v_record15_0 = abi_h_record15(v_record15_0);
assert(v_record15_0.field0.field0[0][0].field0 == out_v_record15_0.field0.field0[0][0].field0);
assert(v_record15_0.field0.field0[1][0].field0 == out_v_record15_0.field0.field0[1][0].field0);
assert(v_record15_0.field0.field1 == out_v_record15_0.field0.field1);
assert(v_record15_0.field0.field2 == out_v_record15_0.field0.field2);
assert(v_record15_0.field0.field3 == out_v_record15_0.field0.field3);
assert(v_record15_0.field0.field4 == out_v_record15_0.field0.field4);
assert(v_record15_0.field1[0] == out_v_record15_0.field1[0]);
assert(v_record15_0.field1[1] == out_v_record15_0.field1[1]);
assert(v_record15_0.field1[2] == out_v_record15_0.field1[2]);
assert(v_record15_0.field1[3] == out_v_record15_0.field1[3]);
assert(v_record15_0.field2[0] == out_v_record15_0.field2[0]);
assert(v_record15_0.field3.field0 == out_v_record15_0.field3.field0);
assert(v_record15_0.field3.field1.field0 == out_v_record15_0.field3.field1.field0);
assert(v_record15_0.field3.field1.field1 == out_v_record15_0.field3.field1.field1);
assert(v_record15_0.field3.field1.field2 == out_v_record15_0.field3.field1.field2);
assert(v_record15_0.field3.field1.field3 == out_v_record15_0.field3.field1.field3);
}
{
ExpectedType27 v_record15_1 = {0};
v_record15_1.field0.field0[0][0].field0 = (ExpectedType11)(-547.75);
v_record15_1.field0.field0[1][0].field0 = (ExpectedType11)(-562.0);
v_record15_1.field0.field1 = (ExpectedType4)(UINT64_C(3612837350));
v_record15_1.field0.field2 = (ExpectedType3)((-INT64_C(24742)));
v_record15_1.field0.field3 = (ExpectedType0)(UINT64_C(78));
v_record15_1.field0.field4 = (ExpectedType3)((-INT64_C(15522)));
v_record15_1.field1[0] = (ExpectedType1)((-INT64_C(112)));
v_record15_1.field1[1] = (ExpectedType1)(INT64_C(98));
v_record15_1.field1[2] = (ExpectedType1)(INT64_C(48));
v_record15_1.field1[3] = (ExpectedType1)((-INT64_C(109)));
v_record15_1.field2[0] = (ExpectedType6)(UINT64_C(16342890061442989140));
v_record15_1.field3.field0 = (ExpectedType5)(INT64_C(321475902));
v_record15_1.field3.field1.field0 = (ExpectedType6)(UINT64_C(17446434265164433296));
v_record15_1.field3.field1.field1 = (ExpectedType3)((-INT64_C(16193)));
v_record15_1.field3.field1.field2 = (ExpectedType9)(INT64_C(1929678038));
v_record15_1.field3.field1.field3 = (ExpectedType1)((-INT64_C(118)));
ExpectedType27 out_v_record15_1 = abi_h_record15(v_record15_1);
assert(v_record15_1.field0.field0[0][0].field0 == out_v_record15_1.field0.field0[0][0].field0);
assert(v_record15_1.field0.field0[1][0].field0 == out_v_record15_1.field0.field0[1][0].field0);
assert(v_record15_1.field0.field1 == out_v_record15_1.field0.field1);
assert(v_record15_1.field0.field2 == out_v_record15_1.field0.field2);
assert(v_record15_1.field0.field3 == out_v_record15_1.field0.field3);
assert(v_record15_1.field0.field4 == out_v_record15_1.field0.field4);
assert(v_record15_1.field1[0] == out_v_record15_1.field1[0]);
assert(v_record15_1.field1[1] == out_v_record15_1.field1[1]);
assert(v_record15_1.field1[2] == out_v_record15_1.field1[2]);
assert(v_record15_1.field1[3] == out_v_record15_1.field1[3]);
assert(v_record15_1.field2[0] == out_v_record15_1.field2[0]);
assert(v_record15_1.field3.field0 == out_v_record15_1.field3.field0);
assert(v_record15_1.field3.field1.field0 == out_v_record15_1.field3.field1.field0);
assert(v_record15_1.field3.field1.field1 == out_v_record15_1.field3.field1.field1);
assert(v_record15_1.field3.field1.field2 == out_v_record15_1.field3.field1.field2);
assert(v_record15_1.field3.field1.field3 == out_v_record15_1.field3.field1.field3);
}
{
ExpectedType27 v_record15_2 = {0};
v_record15_2.field0.field0[0][0].field0 = (ExpectedType11)(780.5);
v_record15_2.field0.field0[1][0].field0 = (ExpectedType11)(922.25);
v_record15_2.field0.field1 = (ExpectedType4)(UINT64_C(1955404571));
v_record15_2.field0.field2 = (ExpectedType3)((-INT64_C(14206)));
v_record15_2.field0.field3 = (ExpectedType0)(UINT64_C(210));
v_record15_2.field0.field4 = (ExpectedType3)((-INT64_C(31955)));
v_record15_2.field1[0] = (ExpectedType1)(INT64_C(14));
v_record15_2.field1[1] = (ExpectedType1)(INT64_C(39));
v_record15_2.field1[2] = (ExpectedType1)(INT64_C(26));
v_record15_2.field1[3] = (ExpectedType1)(INT64_C(123));
v_record15_2.field2[0] = (ExpectedType6)(UINT64_C(17467075335271186485));
v_record15_2.field3.field0 = (ExpectedType5)(INT64_C(546800621));
v_record15_2.field3.field1.field0 = (ExpectedType6)(UINT64_C(3128338741317335037));
v_record15_2.field3.field1.field1 = (ExpectedType3)((-INT64_C(32541)));
v_record15_2.field3.field1.field2 = (ExpectedType9)((-INT64_C(1429659921)));
v_record15_2.field3.field1.field3 = (ExpectedType1)((-INT64_C(54)));
ExpectedType27 out_v_record15_2 = abi_h_record15(v_record15_2);
assert(v_record15_2.field0.field0[0][0].field0 == out_v_record15_2.field0.field0[0][0].field0);
assert(v_record15_2.field0.field0[1][0].field0 == out_v_record15_2.field0.field0[1][0].field0);
assert(v_record15_2.field0.field1 == out_v_record15_2.field0.field1);
assert(v_record15_2.field0.field2 == out_v_record15_2.field0.field2);
assert(v_record15_2.field0.field3 == out_v_record15_2.field0.field3);
assert(v_record15_2.field0.field4 == out_v_record15_2.field0.field4);
assert(v_record15_2.field1[0] == out_v_record15_2.field1[0]);
assert(v_record15_2.field1[1] == out_v_record15_2.field1[1]);
assert(v_record15_2.field1[2] == out_v_record15_2.field1[2]);
assert(v_record15_2.field1[3] == out_v_record15_2.field1[3]);
assert(v_record15_2.field2[0] == out_v_record15_2.field2[0]);
assert(v_record15_2.field3.field0 == out_v_record15_2.field3.field0);
assert(v_record15_2.field3.field1.field0 == out_v_record15_2.field3.field1.field0);
assert(v_record15_2.field3.field1.field1 == out_v_record15_2.field3.field1.field1);
assert(v_record15_2.field3.field1.field2 == out_v_record15_2.field3.field1.field2);
assert(v_record15_2.field3.field1.field3 == out_v_record15_2.field3.field1.field3);
}
{
ExpectedType28 v_record16_0 = {0};
v_record16_0.field0 = (ExpectedType7)(INT64_C(1111001914527950946));
v_record16_0.field1.field0[0] = (ExpectedType10)(589.5);
v_record16_0.field1.field0[1] = (ExpectedType10)(-841.0);
v_record16_0.field1.field0[2] = (ExpectedType10)(-69.25);
v_record16_0.field2[0][0] = (ExpectedType10)(-789.0);
v_record16_0.field2[0][1] = (ExpectedType10)(843.75);
v_record16_0.field2[0][2] = (ExpectedType10)(-1.75);
v_record16_0.field2[1][0] = (ExpectedType10)(-365.5);
v_record16_0.field2[1][1] = (ExpectedType10)(69.0);
v_record16_0.field2[1][2] = (ExpectedType10)(-983.0);
v_record16_0.field3[0].field0 = (ExpectedType0)(UINT64_C(240));
v_record16_0.field3[0].field1 = (ExpectedType6)(UINT64_C(15497587949252247241));
v_record16_0.field3[1].field0 = (ExpectedType0)(UINT64_C(166));
v_record16_0.field3[1].field1 = (ExpectedType6)(UINT64_C(15890192544937576224));
v_record16_0.field3[2].field0 = (ExpectedType0)(UINT64_C(226));
v_record16_0.field3[2].field1 = (ExpectedType6)(UINT64_C(5772197710341757296));
v_record16_0.field4.field0[0] = (ExpectedType5)((-INT64_C(1966498732)));
v_record16_0.field4.field0[1] = (ExpectedType5)((-INT64_C(2135697071)));
v_record16_0.field4.field0[2] = (ExpectedType5)(INT64_C(531696281));
ExpectedType28 out_v_record16_0 = abi_h_record16(v_record16_0);
assert(v_record16_0.field0 == out_v_record16_0.field0);
assert(v_record16_0.field1.field0[0] == out_v_record16_0.field1.field0[0]);
assert(v_record16_0.field1.field0[1] == out_v_record16_0.field1.field0[1]);
assert(v_record16_0.field1.field0[2] == out_v_record16_0.field1.field0[2]);
assert(v_record16_0.field2[0][0] == out_v_record16_0.field2[0][0]);
assert(v_record16_0.field2[0][1] == out_v_record16_0.field2[0][1]);
assert(v_record16_0.field2[0][2] == out_v_record16_0.field2[0][2]);
assert(v_record16_0.field2[1][0] == out_v_record16_0.field2[1][0]);
assert(v_record16_0.field2[1][1] == out_v_record16_0.field2[1][1]);
assert(v_record16_0.field2[1][2] == out_v_record16_0.field2[1][2]);
assert(v_record16_0.field3[0].field0 == out_v_record16_0.field3[0].field0);
assert(v_record16_0.field3[0].field1 == out_v_record16_0.field3[0].field1);
assert(v_record16_0.field3[1].field0 == out_v_record16_0.field3[1].field0);
assert(v_record16_0.field3[1].field1 == out_v_record16_0.field3[1].field1);
assert(v_record16_0.field3[2].field0 == out_v_record16_0.field3[2].field0);
assert(v_record16_0.field3[2].field1 == out_v_record16_0.field3[2].field1);
assert(v_record16_0.field4.field0[0] == out_v_record16_0.field4.field0[0]);
assert(v_record16_0.field4.field0[1] == out_v_record16_0.field4.field0[1]);
assert(v_record16_0.field4.field0[2] == out_v_record16_0.field4.field0[2]);
}
{
ExpectedType28 v_record16_1 = {0};
v_record16_1.field0 = (ExpectedType7)((-INT64_C(5517049937160676108)));
v_record16_1.field1.field0[0] = (ExpectedType10)(676.25);
v_record16_1.field1.field0[1] = (ExpectedType10)(-550.25);
v_record16_1.field1.field0[2] = (ExpectedType10)(-483.0);
v_record16_1.field2[0][0] = (ExpectedType10)(452.0);
v_record16_1.field2[0][1] = (ExpectedType10)(46.0);
v_record16_1.field2[0][2] = (ExpectedType10)(-472.25);
v_record16_1.field2[1][0] = (ExpectedType10)(940.75);
v_record16_1.field2[1][1] = (ExpectedType10)(573.0);
v_record16_1.field2[1][2] = (ExpectedType10)(-1012.75);
v_record16_1.field3[0].field0 = (ExpectedType0)(UINT64_C(235));
v_record16_1.field3[0].field1 = (ExpectedType6)(UINT64_C(18101270150778452269));
v_record16_1.field3[1].field0 = (ExpectedType0)(UINT64_C(133));
v_record16_1.field3[1].field1 = (ExpectedType6)(UINT64_C(3407277067317617801));
v_record16_1.field3[2].field0 = (ExpectedType0)(UINT64_C(51));
v_record16_1.field3[2].field1 = (ExpectedType6)(UINT64_C(12394326932755234390));
v_record16_1.field4.field0[0] = (ExpectedType5)((-INT64_C(1734096895)));
v_record16_1.field4.field0[1] = (ExpectedType5)((-INT64_C(1641028883)));
v_record16_1.field4.field0[2] = (ExpectedType5)(INT64_C(1782516817));
ExpectedType28 out_v_record16_1 = abi_h_record16(v_record16_1);
assert(v_record16_1.field0 == out_v_record16_1.field0);
assert(v_record16_1.field1.field0[0] == out_v_record16_1.field1.field0[0]);
assert(v_record16_1.field1.field0[1] == out_v_record16_1.field1.field0[1]);
assert(v_record16_1.field1.field0[2] == out_v_record16_1.field1.field0[2]);
assert(v_record16_1.field2[0][0] == out_v_record16_1.field2[0][0]);
assert(v_record16_1.field2[0][1] == out_v_record16_1.field2[0][1]);
assert(v_record16_1.field2[0][2] == out_v_record16_1.field2[0][2]);
assert(v_record16_1.field2[1][0] == out_v_record16_1.field2[1][0]);
assert(v_record16_1.field2[1][1] == out_v_record16_1.field2[1][1]);
assert(v_record16_1.field2[1][2] == out_v_record16_1.field2[1][2]);
assert(v_record16_1.field3[0].field0 == out_v_record16_1.field3[0].field0);
assert(v_record16_1.field3[0].field1 == out_v_record16_1.field3[0].field1);
assert(v_record16_1.field3[1].field0 == out_v_record16_1.field3[1].field0);
assert(v_record16_1.field3[1].field1 == out_v_record16_1.field3[1].field1);
assert(v_record16_1.field3[2].field0 == out_v_record16_1.field3[2].field0);
assert(v_record16_1.field3[2].field1 == out_v_record16_1.field3[2].field1);
assert(v_record16_1.field4.field0[0] == out_v_record16_1.field4.field0[0]);
assert(v_record16_1.field4.field0[1] == out_v_record16_1.field4.field0[1]);
assert(v_record16_1.field4.field0[2] == out_v_record16_1.field4.field0[2]);
}
{
ExpectedType28 v_record16_2 = {0};
v_record16_2.field0 = (ExpectedType7)((-INT64_C(4002551388611070250)));
v_record16_2.field1.field0[0] = (ExpectedType10)(-75.75);
v_record16_2.field1.field0[1] = (ExpectedType10)(-467.75);
v_record16_2.field1.field0[2] = (ExpectedType10)(-687.5);
v_record16_2.field2[0][0] = (ExpectedType10)(454.75);
v_record16_2.field2[0][1] = (ExpectedType10)(252.5);
v_record16_2.field2[0][2] = (ExpectedType10)(-486.75);
v_record16_2.field2[1][0] = (ExpectedType10)(464.0);
v_record16_2.field2[1][1] = (ExpectedType10)(378.0);
v_record16_2.field2[1][2] = (ExpectedType10)(-415.25);
v_record16_2.field3[0].field0 = (ExpectedType0)(UINT64_C(206));
v_record16_2.field3[0].field1 = (ExpectedType6)(UINT64_C(16467376552573036791));
v_record16_2.field3[1].field0 = (ExpectedType0)(UINT64_C(127));
v_record16_2.field3[1].field1 = (ExpectedType6)(UINT64_C(17956693690878068649));
v_record16_2.field3[2].field0 = (ExpectedType0)(UINT64_C(229));
v_record16_2.field3[2].field1 = (ExpectedType6)(UINT64_C(14320062387442327994));
v_record16_2.field4.field0[0] = (ExpectedType5)((-INT64_C(1554275879)));
v_record16_2.field4.field0[1] = (ExpectedType5)((-INT64_C(245602773)));
v_record16_2.field4.field0[2] = (ExpectedType5)((-INT64_C(122481177)));
ExpectedType28 out_v_record16_2 = abi_h_record16(v_record16_2);
assert(v_record16_2.field0 == out_v_record16_2.field0);
assert(v_record16_2.field1.field0[0] == out_v_record16_2.field1.field0[0]);
assert(v_record16_2.field1.field0[1] == out_v_record16_2.field1.field0[1]);
assert(v_record16_2.field1.field0[2] == out_v_record16_2.field1.field0[2]);
assert(v_record16_2.field2[0][0] == out_v_record16_2.field2[0][0]);
assert(v_record16_2.field2[0][1] == out_v_record16_2.field2[0][1]);
assert(v_record16_2.field2[0][2] == out_v_record16_2.field2[0][2]);
assert(v_record16_2.field2[1][0] == out_v_record16_2.field2[1][0]);
assert(v_record16_2.field2[1][1] == out_v_record16_2.field2[1][1]);
assert(v_record16_2.field2[1][2] == out_v_record16_2.field2[1][2]);
assert(v_record16_2.field3[0].field0 == out_v_record16_2.field3[0].field0);
assert(v_record16_2.field3[0].field1 == out_v_record16_2.field3[0].field1);
assert(v_record16_2.field3[1].field0 == out_v_record16_2.field3[1].field0);
assert(v_record16_2.field3[1].field1 == out_v_record16_2.field3[1].field1);
assert(v_record16_2.field3[2].field0 == out_v_record16_2.field3[2].field0);
assert(v_record16_2.field3[2].field1 == out_v_record16_2.field3[2].field1);
assert(v_record16_2.field4.field0[0] == out_v_record16_2.field4.field0[0]);
assert(v_record16_2.field4.field0[1] == out_v_record16_2.field4.field0[1]);
assert(v_record16_2.field4.field0[2] == out_v_record16_2.field4.field0[2]);
}
{
ExpectedType29 v_record17_0 = {0};
v_record17_0.field0.field0 = (ExpectedType0)(UINT64_C(168));
v_record17_0.field0.field1 = (ExpectedType6)(UINT64_C(16776907317661942670));
v_record17_0.field1[0][0].field0 = (ExpectedType0)(UINT64_C(42));
v_record17_0.field1[0][0].field1 = (ExpectedType6)(UINT64_C(2746397522908203897));
v_record17_0.field1[0][1].field0 = (ExpectedType0)(UINT64_C(118));
v_record17_0.field1[0][1].field1 = (ExpectedType6)(UINT64_C(572574041991936923));
v_record17_0.field1[0][2].field0 = (ExpectedType0)(UINT64_C(168));
v_record17_0.field1[0][2].field1 = (ExpectedType6)(UINT64_C(4626767226454920872));
v_record17_0.field1[0][3].field0 = (ExpectedType0)(UINT64_C(118));
v_record17_0.field1[0][3].field1 = (ExpectedType6)(UINT64_C(11733312222988642650));
v_record17_0.field1[1][0].field0 = (ExpectedType0)(UINT64_C(82));
v_record17_0.field1[1][0].field1 = (ExpectedType6)(UINT64_C(10111032086610612883));
v_record17_0.field1[1][1].field0 = (ExpectedType0)(UINT64_C(24));
v_record17_0.field1[1][1].field1 = (ExpectedType6)(UINT64_C(7323913517443888403));
v_record17_0.field1[1][2].field0 = (ExpectedType0)(UINT64_C(241));
v_record17_0.field1[1][2].field1 = (ExpectedType6)(UINT64_C(8337386004027162339));
v_record17_0.field1[1][3].field0 = (ExpectedType0)(UINT64_C(9));
v_record17_0.field1[1][3].field1 = (ExpectedType6)(UINT64_C(12328573362734949918));
v_record17_0.field2 = (ExpectedType2)(UINT64_C(17714));
ExpectedType29 out_v_record17_0 = abi_h_record17(v_record17_0);
assert(v_record17_0.field0.field0 == out_v_record17_0.field0.field0);
assert(v_record17_0.field0.field1 == out_v_record17_0.field0.field1);
assert(v_record17_0.field1[0][0].field0 == out_v_record17_0.field1[0][0].field0);
assert(v_record17_0.field1[0][0].field1 == out_v_record17_0.field1[0][0].field1);
assert(v_record17_0.field1[0][1].field0 == out_v_record17_0.field1[0][1].field0);
assert(v_record17_0.field1[0][1].field1 == out_v_record17_0.field1[0][1].field1);
assert(v_record17_0.field1[0][2].field0 == out_v_record17_0.field1[0][2].field0);
assert(v_record17_0.field1[0][2].field1 == out_v_record17_0.field1[0][2].field1);
assert(v_record17_0.field1[0][3].field0 == out_v_record17_0.field1[0][3].field0);
assert(v_record17_0.field1[0][3].field1 == out_v_record17_0.field1[0][3].field1);
assert(v_record17_0.field1[1][0].field0 == out_v_record17_0.field1[1][0].field0);
assert(v_record17_0.field1[1][0].field1 == out_v_record17_0.field1[1][0].field1);
assert(v_record17_0.field1[1][1].field0 == out_v_record17_0.field1[1][1].field0);
assert(v_record17_0.field1[1][1].field1 == out_v_record17_0.field1[1][1].field1);
assert(v_record17_0.field1[1][2].field0 == out_v_record17_0.field1[1][2].field0);
assert(v_record17_0.field1[1][2].field1 == out_v_record17_0.field1[1][2].field1);
assert(v_record17_0.field1[1][3].field0 == out_v_record17_0.field1[1][3].field0);
assert(v_record17_0.field1[1][3].field1 == out_v_record17_0.field1[1][3].field1);
assert(v_record17_0.field2 == out_v_record17_0.field2);
}
{
ExpectedType29 v_record17_1 = {0};
v_record17_1.field0.field0 = (ExpectedType0)(UINT64_C(220));
v_record17_1.field0.field1 = (ExpectedType6)(UINT64_C(9401900614342554393));
v_record17_1.field1[0][0].field0 = (ExpectedType0)(UINT64_C(66));
v_record17_1.field1[0][0].field1 = (ExpectedType6)(UINT64_C(518743663906132401));
v_record17_1.field1[0][1].field0 = (ExpectedType0)(UINT64_C(155));
v_record17_1.field1[0][1].field1 = (ExpectedType6)(UINT64_C(18437167900040000888));
v_record17_1.field1[0][2].field0 = (ExpectedType0)(UINT64_C(194));
v_record17_1.field1[0][2].field1 = (ExpectedType6)(UINT64_C(5263042142901036722));
v_record17_1.field1[0][3].field0 = (ExpectedType0)(UINT64_C(97));
v_record17_1.field1[0][3].field1 = (ExpectedType6)(UINT64_C(7430370302465126568));
v_record17_1.field1[1][0].field0 = (ExpectedType0)(UINT64_C(103));
v_record17_1.field1[1][0].field1 = (ExpectedType6)(UINT64_C(10576969386584795328));
v_record17_1.field1[1][1].field0 = (ExpectedType0)(UINT64_C(191));
v_record17_1.field1[1][1].field1 = (ExpectedType6)(UINT64_C(13169935282155113711));
v_record17_1.field1[1][2].field0 = (ExpectedType0)(UINT64_C(158));
v_record17_1.field1[1][2].field1 = (ExpectedType6)(UINT64_C(13171028530082783938));
v_record17_1.field1[1][3].field0 = (ExpectedType0)(UINT64_C(205));
v_record17_1.field1[1][3].field1 = (ExpectedType6)(UINT64_C(12484366953672385253));
v_record17_1.field2 = (ExpectedType2)(UINT64_C(53187));
ExpectedType29 out_v_record17_1 = abi_h_record17(v_record17_1);
assert(v_record17_1.field0.field0 == out_v_record17_1.field0.field0);
assert(v_record17_1.field0.field1 == out_v_record17_1.field0.field1);
assert(v_record17_1.field1[0][0].field0 == out_v_record17_1.field1[0][0].field0);
assert(v_record17_1.field1[0][0].field1 == out_v_record17_1.field1[0][0].field1);
assert(v_record17_1.field1[0][1].field0 == out_v_record17_1.field1[0][1].field0);
assert(v_record17_1.field1[0][1].field1 == out_v_record17_1.field1[0][1].field1);
assert(v_record17_1.field1[0][2].field0 == out_v_record17_1.field1[0][2].field0);
assert(v_record17_1.field1[0][2].field1 == out_v_record17_1.field1[0][2].field1);
assert(v_record17_1.field1[0][3].field0 == out_v_record17_1.field1[0][3].field0);
assert(v_record17_1.field1[0][3].field1 == out_v_record17_1.field1[0][3].field1);
assert(v_record17_1.field1[1][0].field0 == out_v_record17_1.field1[1][0].field0);
assert(v_record17_1.field1[1][0].field1 == out_v_record17_1.field1[1][0].field1);
assert(v_record17_1.field1[1][1].field0 == out_v_record17_1.field1[1][1].field0);
assert(v_record17_1.field1[1][1].field1 == out_v_record17_1.field1[1][1].field1);
assert(v_record17_1.field1[1][2].field0 == out_v_record17_1.field1[1][2].field0);
assert(v_record17_1.field1[1][2].field1 == out_v_record17_1.field1[1][2].field1);
assert(v_record17_1.field1[1][3].field0 == out_v_record17_1.field1[1][3].field0);
assert(v_record17_1.field1[1][3].field1 == out_v_record17_1.field1[1][3].field1);
assert(v_record17_1.field2 == out_v_record17_1.field2);
}
{
ExpectedType29 v_record17_2 = {0};
v_record17_2.field0.field0 = (ExpectedType0)(UINT64_C(37));
v_record17_2.field0.field1 = (ExpectedType6)(UINT64_C(258068330872904143));
v_record17_2.field1[0][0].field0 = (ExpectedType0)(UINT64_C(245));
v_record17_2.field1[0][0].field1 = (ExpectedType6)(UINT64_C(9685112184963601495));
v_record17_2.field1[0][1].field0 = (ExpectedType0)(UINT64_C(22));
v_record17_2.field1[0][1].field1 = (ExpectedType6)(UINT64_C(3251353365591317376));
v_record17_2.field1[0][2].field0 = (ExpectedType0)(UINT64_C(152));
v_record17_2.field1[0][2].field1 = (ExpectedType6)(UINT64_C(2306138322356961077));
v_record17_2.field1[0][3].field0 = (ExpectedType0)(UINT64_C(240));
v_record17_2.field1[0][3].field1 = (ExpectedType6)(UINT64_C(1670540985342297056));
v_record17_2.field1[1][0].field0 = (ExpectedType0)(UINT64_C(208));
v_record17_2.field1[1][0].field1 = (ExpectedType6)(UINT64_C(739115696923331716));
v_record17_2.field1[1][1].field0 = (ExpectedType0)(UINT64_C(175));
v_record17_2.field1[1][1].field1 = (ExpectedType6)(UINT64_C(15911020903085250716));
v_record17_2.field1[1][2].field0 = (ExpectedType0)(UINT64_C(177));
v_record17_2.field1[1][2].field1 = (ExpectedType6)(UINT64_C(15676803633406517493));
v_record17_2.field1[1][3].field0 = (ExpectedType0)(UINT64_C(196));
v_record17_2.field1[1][3].field1 = (ExpectedType6)(UINT64_C(1261021394589769669));
v_record17_2.field2 = (ExpectedType2)(UINT64_C(59733));
ExpectedType29 out_v_record17_2 = abi_h_record17(v_record17_2);
assert(v_record17_2.field0.field0 == out_v_record17_2.field0.field0);
assert(v_record17_2.field0.field1 == out_v_record17_2.field0.field1);
assert(v_record17_2.field1[0][0].field0 == out_v_record17_2.field1[0][0].field0);
assert(v_record17_2.field1[0][0].field1 == out_v_record17_2.field1[0][0].field1);
assert(v_record17_2.field1[0][1].field0 == out_v_record17_2.field1[0][1].field0);
assert(v_record17_2.field1[0][1].field1 == out_v_record17_2.field1[0][1].field1);
assert(v_record17_2.field1[0][2].field0 == out_v_record17_2.field1[0][2].field0);
assert(v_record17_2.field1[0][2].field1 == out_v_record17_2.field1[0][2].field1);
assert(v_record17_2.field1[0][3].field0 == out_v_record17_2.field1[0][3].field0);
assert(v_record17_2.field1[0][3].field1 == out_v_record17_2.field1[0][3].field1);
assert(v_record17_2.field1[1][0].field0 == out_v_record17_2.field1[1][0].field0);
assert(v_record17_2.field1[1][0].field1 == out_v_record17_2.field1[1][0].field1);
assert(v_record17_2.field1[1][1].field0 == out_v_record17_2.field1[1][1].field0);
assert(v_record17_2.field1[1][1].field1 == out_v_record17_2.field1[1][1].field1);
assert(v_record17_2.field1[1][2].field0 == out_v_record17_2.field1[1][2].field0);
assert(v_record17_2.field1[1][2].field1 == out_v_record17_2.field1[1][2].field1);
assert(v_record17_2.field1[1][3].field0 == out_v_record17_2.field1[1][3].field0);
assert(v_record17_2.field1[1][3].field1 == out_v_record17_2.field1[1][3].field1);
assert(v_record17_2.field2 == out_v_record17_2.field2);
}
{
ExpectedType30 v_record18_0 = {0};
v_record18_0.field0[0] = (ExpectedType0)(UINT64_C(170));
v_record18_0.field0[1] = (ExpectedType0)(UINT64_C(29));
v_record18_0.field1 = (ExpectedType8)(UINT64_C(1618533350));
v_record18_0.field2.field0.field0 = (ExpectedType6)(UINT64_C(14457576310908288040));
v_record18_0.field2.field0.field1 = (ExpectedType3)(INT64_C(14042));
v_record18_0.field2.field0.field2 = (ExpectedType9)((-INT64_C(931315415)));
v_record18_0.field2.field0.field3 = (ExpectedType1)((-INT64_C(116)));
v_record18_0.field2.field1 = (ExpectedType8)(UINT64_C(1047021099));
v_record18_0.field2.field2[0].field0 = (ExpectedType6)(UINT64_C(8691553364506641219));
v_record18_0.field2.field2[0].field1 = (ExpectedType3)(INT64_C(24017));
v_record18_0.field2.field2[0].field2 = (ExpectedType9)(INT64_C(87054162));
v_record18_0.field2.field2[0].field3 = (ExpectedType1)((-INT64_C(120)));
v_record18_0.field3.field0[0].field0[0] = (ExpectedType10)(-598.75);
v_record18_0.field3.field0[0].field0[1] = (ExpectedType10)(-958.25);
v_record18_0.field3.field0[0].field0[2] = (ExpectedType10)(-304.5);
v_record18_0.field3.field0[1].field0[0] = (ExpectedType10)(1021.0);
v_record18_0.field3.field0[1].field0[1] = (ExpectedType10)(349.5);
v_record18_0.field3.field0[1].field0[2] = (ExpectedType10)(-977.5);
v_record18_0.field3.field0[2].field0[0] = (ExpectedType10)(-537.0);
v_record18_0.field3.field0[2].field0[1] = (ExpectedType10)(-347.75);
v_record18_0.field3.field0[2].field0[2] = (ExpectedType10)(-432.25);
ExpectedType30 out_v_record18_0 = abi_h_record18(v_record18_0);
assert(v_record18_0.field0[0] == out_v_record18_0.field0[0]);
assert(v_record18_0.field0[1] == out_v_record18_0.field0[1]);
assert(v_record18_0.field1 == out_v_record18_0.field1);
assert(v_record18_0.field2.field0.field0 == out_v_record18_0.field2.field0.field0);
assert(v_record18_0.field2.field0.field1 == out_v_record18_0.field2.field0.field1);
assert(v_record18_0.field2.field0.field2 == out_v_record18_0.field2.field0.field2);
assert(v_record18_0.field2.field0.field3 == out_v_record18_0.field2.field0.field3);
assert(v_record18_0.field2.field1 == out_v_record18_0.field2.field1);
assert(v_record18_0.field2.field2[0].field0 == out_v_record18_0.field2.field2[0].field0);
assert(v_record18_0.field2.field2[0].field1 == out_v_record18_0.field2.field2[0].field1);
assert(v_record18_0.field2.field2[0].field2 == out_v_record18_0.field2.field2[0].field2);
assert(v_record18_0.field2.field2[0].field3 == out_v_record18_0.field2.field2[0].field3);
assert(v_record18_0.field3.field0[0].field0[0] == out_v_record18_0.field3.field0[0].field0[0]);
assert(v_record18_0.field3.field0[0].field0[1] == out_v_record18_0.field3.field0[0].field0[1]);
assert(v_record18_0.field3.field0[0].field0[2] == out_v_record18_0.field3.field0[0].field0[2]);
assert(v_record18_0.field3.field0[1].field0[0] == out_v_record18_0.field3.field0[1].field0[0]);
assert(v_record18_0.field3.field0[1].field0[1] == out_v_record18_0.field3.field0[1].field0[1]);
assert(v_record18_0.field3.field0[1].field0[2] == out_v_record18_0.field3.field0[1].field0[2]);
assert(v_record18_0.field3.field0[2].field0[0] == out_v_record18_0.field3.field0[2].field0[0]);
assert(v_record18_0.field3.field0[2].field0[1] == out_v_record18_0.field3.field0[2].field0[1]);
assert(v_record18_0.field3.field0[2].field0[2] == out_v_record18_0.field3.field0[2].field0[2]);
}
{
ExpectedType30 v_record18_1 = {0};
v_record18_1.field0[0] = (ExpectedType0)(UINT64_C(212));
v_record18_1.field0[1] = (ExpectedType0)(UINT64_C(245));
v_record18_1.field1 = (ExpectedType8)(UINT64_C(3399845671));
v_record18_1.field2.field0.field0 = (ExpectedType6)(UINT64_C(1002241729068142491));
v_record18_1.field2.field0.field1 = (ExpectedType3)(INT64_C(27556));
v_record18_1.field2.field0.field2 = (ExpectedType9)(INT64_C(1571257702));
v_record18_1.field2.field0.field3 = (ExpectedType1)(INT64_C(122));
v_record18_1.field2.field1 = (ExpectedType8)(UINT64_C(3596912971));
v_record18_1.field2.field2[0].field0 = (ExpectedType6)(UINT64_C(14059293120701183441));
v_record18_1.field2.field2[0].field1 = (ExpectedType3)(INT64_C(2145));
v_record18_1.field2.field2[0].field2 = (ExpectedType9)((-INT64_C(952810439)));
v_record18_1.field2.field2[0].field3 = (ExpectedType1)(INT64_C(112));
v_record18_1.field3.field0[0].field0[0] = (ExpectedType10)(364.25);
v_record18_1.field3.field0[0].field0[1] = (ExpectedType10)(576.75);
v_record18_1.field3.field0[0].field0[2] = (ExpectedType10)(-695.75);
v_record18_1.field3.field0[1].field0[0] = (ExpectedType10)(651.0);
v_record18_1.field3.field0[1].field0[1] = (ExpectedType10)(-844.5);
v_record18_1.field3.field0[1].field0[2] = (ExpectedType10)(-635.0);
v_record18_1.field3.field0[2].field0[0] = (ExpectedType10)(-145.75);
v_record18_1.field3.field0[2].field0[1] = (ExpectedType10)(564.5);
v_record18_1.field3.field0[2].field0[2] = (ExpectedType10)(-978.75);
ExpectedType30 out_v_record18_1 = abi_h_record18(v_record18_1);
assert(v_record18_1.field0[0] == out_v_record18_1.field0[0]);
assert(v_record18_1.field0[1] == out_v_record18_1.field0[1]);
assert(v_record18_1.field1 == out_v_record18_1.field1);
assert(v_record18_1.field2.field0.field0 == out_v_record18_1.field2.field0.field0);
assert(v_record18_1.field2.field0.field1 == out_v_record18_1.field2.field0.field1);
assert(v_record18_1.field2.field0.field2 == out_v_record18_1.field2.field0.field2);
assert(v_record18_1.field2.field0.field3 == out_v_record18_1.field2.field0.field3);
assert(v_record18_1.field2.field1 == out_v_record18_1.field2.field1);
assert(v_record18_1.field2.field2[0].field0 == out_v_record18_1.field2.field2[0].field0);
assert(v_record18_1.field2.field2[0].field1 == out_v_record18_1.field2.field2[0].field1);
assert(v_record18_1.field2.field2[0].field2 == out_v_record18_1.field2.field2[0].field2);
assert(v_record18_1.field2.field2[0].field3 == out_v_record18_1.field2.field2[0].field3);
assert(v_record18_1.field3.field0[0].field0[0] == out_v_record18_1.field3.field0[0].field0[0]);
assert(v_record18_1.field3.field0[0].field0[1] == out_v_record18_1.field3.field0[0].field0[1]);
assert(v_record18_1.field3.field0[0].field0[2] == out_v_record18_1.field3.field0[0].field0[2]);
assert(v_record18_1.field3.field0[1].field0[0] == out_v_record18_1.field3.field0[1].field0[0]);
assert(v_record18_1.field3.field0[1].field0[1] == out_v_record18_1.field3.field0[1].field0[1]);
assert(v_record18_1.field3.field0[1].field0[2] == out_v_record18_1.field3.field0[1].field0[2]);
assert(v_record18_1.field3.field0[2].field0[0] == out_v_record18_1.field3.field0[2].field0[0]);
assert(v_record18_1.field3.field0[2].field0[1] == out_v_record18_1.field3.field0[2].field0[1]);
assert(v_record18_1.field3.field0[2].field0[2] == out_v_record18_1.field3.field0[2].field0[2]);
}
{
ExpectedType30 v_record18_2 = {0};
v_record18_2.field0[0] = (ExpectedType0)(UINT64_C(229));
v_record18_2.field0[1] = (ExpectedType0)(UINT64_C(158));
v_record18_2.field1 = (ExpectedType8)(UINT64_C(413316903));
v_record18_2.field2.field0.field0 = (ExpectedType6)(UINT64_C(16769524024980468388));
v_record18_2.field2.field0.field1 = (ExpectedType3)((-INT64_C(32415)));
v_record18_2.field2.field0.field2 = (ExpectedType9)(INT64_C(1574854241));
v_record18_2.field2.field0.field3 = (ExpectedType1)(INT64_C(103));
v_record18_2.field2.field1 = (ExpectedType8)(UINT64_C(3175695164));
v_record18_2.field2.field2[0].field0 = (ExpectedType6)(UINT64_C(16285070205894283539));
v_record18_2.field2.field2[0].field1 = (ExpectedType3)(INT64_C(17136));
v_record18_2.field2.field2[0].field2 = (ExpectedType9)((-INT64_C(382559376)));
v_record18_2.field2.field2[0].field3 = (ExpectedType1)((-INT64_C(96)));
v_record18_2.field3.field0[0].field0[0] = (ExpectedType10)(153.75);
v_record18_2.field3.field0[0].field0[1] = (ExpectedType10)(830.25);
v_record18_2.field3.field0[0].field0[2] = (ExpectedType10)(100.25);
v_record18_2.field3.field0[1].field0[0] = (ExpectedType10)(5.5);
v_record18_2.field3.field0[1].field0[1] = (ExpectedType10)(-957.5);
v_record18_2.field3.field0[1].field0[2] = (ExpectedType10)(134.0);
v_record18_2.field3.field0[2].field0[0] = (ExpectedType10)(-777.0);
v_record18_2.field3.field0[2].field0[1] = (ExpectedType10)(-495.5);
v_record18_2.field3.field0[2].field0[2] = (ExpectedType10)(-32.75);
ExpectedType30 out_v_record18_2 = abi_h_record18(v_record18_2);
assert(v_record18_2.field0[0] == out_v_record18_2.field0[0]);
assert(v_record18_2.field0[1] == out_v_record18_2.field0[1]);
assert(v_record18_2.field1 == out_v_record18_2.field1);
assert(v_record18_2.field2.field0.field0 == out_v_record18_2.field2.field0.field0);
assert(v_record18_2.field2.field0.field1 == out_v_record18_2.field2.field0.field1);
assert(v_record18_2.field2.field0.field2 == out_v_record18_2.field2.field0.field2);
assert(v_record18_2.field2.field0.field3 == out_v_record18_2.field2.field0.field3);
assert(v_record18_2.field2.field1 == out_v_record18_2.field2.field1);
assert(v_record18_2.field2.field2[0].field0 == out_v_record18_2.field2.field2[0].field0);
assert(v_record18_2.field2.field2[0].field1 == out_v_record18_2.field2.field2[0].field1);
assert(v_record18_2.field2.field2[0].field2 == out_v_record18_2.field2.field2[0].field2);
assert(v_record18_2.field2.field2[0].field3 == out_v_record18_2.field2.field2[0].field3);
assert(v_record18_2.field3.field0[0].field0[0] == out_v_record18_2.field3.field0[0].field0[0]);
assert(v_record18_2.field3.field0[0].field0[1] == out_v_record18_2.field3.field0[0].field0[1]);
assert(v_record18_2.field3.field0[0].field0[2] == out_v_record18_2.field3.field0[0].field0[2]);
assert(v_record18_2.field3.field0[1].field0[0] == out_v_record18_2.field3.field0[1].field0[0]);
assert(v_record18_2.field3.field0[1].field0[1] == out_v_record18_2.field3.field0[1].field0[1]);
assert(v_record18_2.field3.field0[1].field0[2] == out_v_record18_2.field3.field0[1].field0[2]);
assert(v_record18_2.field3.field0[2].field0[0] == out_v_record18_2.field3.field0[2].field0[0]);
assert(v_record18_2.field3.field0[2].field0[1] == out_v_record18_2.field3.field0[2].field0[1]);
assert(v_record18_2.field3.field0[2].field0[2] == out_v_record18_2.field3.field0[2].field0[2]);
}
{
ExpectedType31 v_record19_0 = {0};
v_record19_0.field0 = (ExpectedType3)((-INT64_C(16404)));
ExpectedType31 out_v_record19_0 = abi_h_record19(v_record19_0);
assert(v_record19_0.field0 == out_v_record19_0.field0);
}
{
ExpectedType31 v_record19_1 = {0};
v_record19_1.field0 = (ExpectedType3)(INT64_C(17137));
ExpectedType31 out_v_record19_1 = abi_h_record19(v_record19_1);
assert(v_record19_1.field0 == out_v_record19_1.field0);
}
{
ExpectedType31 v_record19_2 = {0};
v_record19_2.field0 = (ExpectedType3)(INT64_C(22211));
ExpectedType31 out_v_record19_2 = abi_h_record19(v_record19_2);
assert(v_record19_2.field0 == out_v_record19_2.field0);
}
{
ExpectedType32 v_record20_0 = {0};
v_record20_0.field0.field0 = (ExpectedType4)(UINT64_C(3020333384));
ExpectedType32 out_v_record20_0 = abi_h_record20(v_record20_0);
assert(v_record20_0.field0.field0 == out_v_record20_0.field0.field0);
}
{
ExpectedType32 v_record20_1 = {0};
v_record20_1.field0.field0 = (ExpectedType4)(UINT64_C(3584228033));
ExpectedType32 out_v_record20_1 = abi_h_record20(v_record20_1);
assert(v_record20_1.field0.field0 == out_v_record20_1.field0.field0);
}
{
ExpectedType32 v_record20_2 = {0};
v_record20_2.field0.field0 = (ExpectedType4)(UINT64_C(1912918494));
ExpectedType32 out_v_record20_2 = abi_h_record20(v_record20_2);
assert(v_record20_2.field0.field0 == out_v_record20_2.field0.field0);
}
{
ExpectedType33 v_record21_0 = {0};
v_record21_0.field0[0][0].field0 = (ExpectedType6)(UINT64_C(3877690221288090690));
v_record21_0.field0[0][0].field1 = (ExpectedType3)((-INT64_C(30742)));
v_record21_0.field0[0][0].field2 = (ExpectedType9)(INT64_C(309705246));
v_record21_0.field0[0][0].field3 = (ExpectedType1)(INT64_C(65));
v_record21_0.field0[1][0].field0 = (ExpectedType6)(UINT64_C(1850089694365379529));
v_record21_0.field0[1][0].field1 = (ExpectedType3)((-INT64_C(31695)));
v_record21_0.field0[1][0].field2 = (ExpectedType9)(INT64_C(1076833794));
v_record21_0.field0[1][0].field3 = (ExpectedType1)(INT64_C(77));
v_record21_0.field1[0].field0[0][0].field0 = (ExpectedType11)(233.25);
v_record21_0.field1[0].field0[1][0].field0 = (ExpectedType11)(-107.0);
v_record21_0.field1[0].field1 = (ExpectedType4)(UINT64_C(2142558387));
v_record21_0.field1[0].field2 = (ExpectedType3)((-INT64_C(7337)));
v_record21_0.field1[0].field3 = (ExpectedType0)(UINT64_C(28));
v_record21_0.field1[0].field4 = (ExpectedType3)(INT64_C(23931));
v_record21_0.field1[1].field0[0][0].field0 = (ExpectedType11)(842.0);
v_record21_0.field1[1].field0[1][0].field0 = (ExpectedType11)(760.75);
v_record21_0.field1[1].field1 = (ExpectedType4)(UINT64_C(784130869));
v_record21_0.field1[1].field2 = (ExpectedType3)((-INT64_C(28816)));
v_record21_0.field1[1].field3 = (ExpectedType0)(UINT64_C(151));
v_record21_0.field1[1].field4 = (ExpectedType3)((-INT64_C(1847)));
v_record21_0.field1[2].field0[0][0].field0 = (ExpectedType11)(-58.75);
v_record21_0.field1[2].field0[1][0].field0 = (ExpectedType11)(312.0);
v_record21_0.field1[2].field1 = (ExpectedType4)(UINT64_C(1885926614));
v_record21_0.field1[2].field2 = (ExpectedType3)(INT64_C(32349));
v_record21_0.field1[2].field3 = (ExpectedType0)(UINT64_C(201));
v_record21_0.field1[2].field4 = (ExpectedType3)((-INT64_C(6460)));
v_record21_0.field2[0][0].field0[0] = (ExpectedType5)((-INT64_C(876250139)));
v_record21_0.field2[0][0].field0[1] = (ExpectedType5)((-INT64_C(681003410)));
v_record21_0.field2[0][0].field0[2] = (ExpectedType5)(INT64_C(1795549921));
v_record21_0.field2[0][1].field0[0] = (ExpectedType5)(INT64_C(766369553));
v_record21_0.field2[0][1].field0[1] = (ExpectedType5)((-INT64_C(930772358)));
v_record21_0.field2[0][1].field0[2] = (ExpectedType5)(INT64_C(577660339));
v_record21_0.field2[0][2].field0[0] = (ExpectedType5)(INT64_C(1709037373));
v_record21_0.field2[0][2].field0[1] = (ExpectedType5)(INT64_C(2056048150));
v_record21_0.field2[0][2].field0[2] = (ExpectedType5)((-INT64_C(281148385)));
v_record21_0.field2[1][0].field0[0] = (ExpectedType5)((-INT64_C(384345636)));
v_record21_0.field2[1][0].field0[1] = (ExpectedType5)((-INT64_C(25345165)));
v_record21_0.field2[1][0].field0[2] = (ExpectedType5)(INT64_C(702721607));
v_record21_0.field2[1][1].field0[0] = (ExpectedType5)(INT64_C(183550425));
v_record21_0.field2[1][1].field0[1] = (ExpectedType5)(INT64_C(942046197));
v_record21_0.field2[1][1].field0[2] = (ExpectedType5)(INT64_C(137213291));
v_record21_0.field2[1][2].field0[0] = (ExpectedType5)(INT64_C(1625510527));
v_record21_0.field2[1][2].field0[1] = (ExpectedType5)((-INT64_C(1414094748)));
v_record21_0.field2[1][2].field0[2] = (ExpectedType5)((-INT64_C(146842488)));
v_record21_0.field3 = (ExpectedType3)((-INT64_C(1458)));
ExpectedType33 out_v_record21_0 = abi_h_record21(v_record21_0);
assert(v_record21_0.field0[0][0].field0 == out_v_record21_0.field0[0][0].field0);
assert(v_record21_0.field0[0][0].field1 == out_v_record21_0.field0[0][0].field1);
assert(v_record21_0.field0[0][0].field2 == out_v_record21_0.field0[0][0].field2);
assert(v_record21_0.field0[0][0].field3 == out_v_record21_0.field0[0][0].field3);
assert(v_record21_0.field0[1][0].field0 == out_v_record21_0.field0[1][0].field0);
assert(v_record21_0.field0[1][0].field1 == out_v_record21_0.field0[1][0].field1);
assert(v_record21_0.field0[1][0].field2 == out_v_record21_0.field0[1][0].field2);
assert(v_record21_0.field0[1][0].field3 == out_v_record21_0.field0[1][0].field3);
assert(v_record21_0.field1[0].field0[0][0].field0 == out_v_record21_0.field1[0].field0[0][0].field0);
assert(v_record21_0.field1[0].field0[1][0].field0 == out_v_record21_0.field1[0].field0[1][0].field0);
assert(v_record21_0.field1[0].field1 == out_v_record21_0.field1[0].field1);
assert(v_record21_0.field1[0].field2 == out_v_record21_0.field1[0].field2);
assert(v_record21_0.field1[0].field3 == out_v_record21_0.field1[0].field3);
assert(v_record21_0.field1[0].field4 == out_v_record21_0.field1[0].field4);
assert(v_record21_0.field1[1].field0[0][0].field0 == out_v_record21_0.field1[1].field0[0][0].field0);
assert(v_record21_0.field1[1].field0[1][0].field0 == out_v_record21_0.field1[1].field0[1][0].field0);
assert(v_record21_0.field1[1].field1 == out_v_record21_0.field1[1].field1);
assert(v_record21_0.field1[1].field2 == out_v_record21_0.field1[1].field2);
assert(v_record21_0.field1[1].field3 == out_v_record21_0.field1[1].field3);
assert(v_record21_0.field1[1].field4 == out_v_record21_0.field1[1].field4);
assert(v_record21_0.field1[2].field0[0][0].field0 == out_v_record21_0.field1[2].field0[0][0].field0);
assert(v_record21_0.field1[2].field0[1][0].field0 == out_v_record21_0.field1[2].field0[1][0].field0);
assert(v_record21_0.field1[2].field1 == out_v_record21_0.field1[2].field1);
assert(v_record21_0.field1[2].field2 == out_v_record21_0.field1[2].field2);
assert(v_record21_0.field1[2].field3 == out_v_record21_0.field1[2].field3);
assert(v_record21_0.field1[2].field4 == out_v_record21_0.field1[2].field4);
assert(v_record21_0.field2[0][0].field0[0] == out_v_record21_0.field2[0][0].field0[0]);
assert(v_record21_0.field2[0][0].field0[1] == out_v_record21_0.field2[0][0].field0[1]);
assert(v_record21_0.field2[0][0].field0[2] == out_v_record21_0.field2[0][0].field0[2]);
assert(v_record21_0.field2[0][1].field0[0] == out_v_record21_0.field2[0][1].field0[0]);
assert(v_record21_0.field2[0][1].field0[1] == out_v_record21_0.field2[0][1].field0[1]);
assert(v_record21_0.field2[0][1].field0[2] == out_v_record21_0.field2[0][1].field0[2]);
assert(v_record21_0.field2[0][2].field0[0] == out_v_record21_0.field2[0][2].field0[0]);
assert(v_record21_0.field2[0][2].field0[1] == out_v_record21_0.field2[0][2].field0[1]);
assert(v_record21_0.field2[0][2].field0[2] == out_v_record21_0.field2[0][2].field0[2]);
assert(v_record21_0.field2[1][0].field0[0] == out_v_record21_0.field2[1][0].field0[0]);
assert(v_record21_0.field2[1][0].field0[1] == out_v_record21_0.field2[1][0].field0[1]);
assert(v_record21_0.field2[1][0].field0[2] == out_v_record21_0.field2[1][0].field0[2]);
assert(v_record21_0.field2[1][1].field0[0] == out_v_record21_0.field2[1][1].field0[0]);
assert(v_record21_0.field2[1][1].field0[1] == out_v_record21_0.field2[1][1].field0[1]);
assert(v_record21_0.field2[1][1].field0[2] == out_v_record21_0.field2[1][1].field0[2]);
assert(v_record21_0.field2[1][2].field0[0] == out_v_record21_0.field2[1][2].field0[0]);
assert(v_record21_0.field2[1][2].field0[1] == out_v_record21_0.field2[1][2].field0[1]);
assert(v_record21_0.field2[1][2].field0[2] == out_v_record21_0.field2[1][2].field0[2]);
assert(v_record21_0.field3 == out_v_record21_0.field3);
}
{
ExpectedType33 v_record21_1 = {0};
v_record21_1.field0[0][0].field0 = (ExpectedType6)(UINT64_C(7294642818109700214));
v_record21_1.field0[0][0].field1 = (ExpectedType3)(INT64_C(20544));
v_record21_1.field0[0][0].field2 = (ExpectedType9)((-INT64_C(663609765)));
v_record21_1.field0[0][0].field3 = (ExpectedType1)(INT64_C(11));
v_record21_1.field0[1][0].field0 = (ExpectedType6)(UINT64_C(1972441307859907154));
v_record21_1.field0[1][0].field1 = (ExpectedType3)(INT64_C(21410));
v_record21_1.field0[1][0].field2 = (ExpectedType9)(INT64_C(727888310));
v_record21_1.field0[1][0].field3 = (ExpectedType1)(INT64_C(68));
v_record21_1.field1[0].field0[0][0].field0 = (ExpectedType11)(152.0);
v_record21_1.field1[0].field0[1][0].field0 = (ExpectedType11)(889.25);
v_record21_1.field1[0].field1 = (ExpectedType4)(UINT64_C(3267125119));
v_record21_1.field1[0].field2 = (ExpectedType3)((-INT64_C(14007)));
v_record21_1.field1[0].field3 = (ExpectedType0)(UINT64_C(33));
v_record21_1.field1[0].field4 = (ExpectedType3)((-INT64_C(3117)));
v_record21_1.field1[1].field0[0][0].field0 = (ExpectedType11)(677.75);
v_record21_1.field1[1].field0[1][0].field0 = (ExpectedType11)(-140.5);
v_record21_1.field1[1].field1 = (ExpectedType4)(UINT64_C(1485195540));
v_record21_1.field1[1].field2 = (ExpectedType3)((-INT64_C(21270)));
v_record21_1.field1[1].field3 = (ExpectedType0)(UINT64_C(70));
v_record21_1.field1[1].field4 = (ExpectedType3)((-INT64_C(27608)));
v_record21_1.field1[2].field0[0][0].field0 = (ExpectedType11)(450.5);
v_record21_1.field1[2].field0[1][0].field0 = (ExpectedType11)(-568.0);
v_record21_1.field1[2].field1 = (ExpectedType4)(UINT64_C(4115273845));
v_record21_1.field1[2].field2 = (ExpectedType3)(INT64_C(22879));
v_record21_1.field1[2].field3 = (ExpectedType0)(UINT64_C(116));
v_record21_1.field1[2].field4 = (ExpectedType3)(INT64_C(9906));
v_record21_1.field2[0][0].field0[0] = (ExpectedType5)((-INT64_C(188410642)));
v_record21_1.field2[0][0].field0[1] = (ExpectedType5)(INT64_C(2049935383));
v_record21_1.field2[0][0].field0[2] = (ExpectedType5)((-INT64_C(147255945)));
v_record21_1.field2[0][1].field0[0] = (ExpectedType5)(INT64_C(394983434));
v_record21_1.field2[0][1].field0[1] = (ExpectedType5)(INT64_C(1188965085));
v_record21_1.field2[0][1].field0[2] = (ExpectedType5)((-INT64_C(452030545)));
v_record21_1.field2[0][2].field0[0] = (ExpectedType5)((-INT64_C(1537754338)));
v_record21_1.field2[0][2].field0[1] = (ExpectedType5)(INT64_C(1492261091));
v_record21_1.field2[0][2].field0[2] = (ExpectedType5)((-INT64_C(2096148318)));
v_record21_1.field2[1][0].field0[0] = (ExpectedType5)(INT64_C(89311532));
v_record21_1.field2[1][0].field0[1] = (ExpectedType5)(INT64_C(555418556));
v_record21_1.field2[1][0].field0[2] = (ExpectedType5)((-INT64_C(2067734511)));
v_record21_1.field2[1][1].field0[0] = (ExpectedType5)((-INT64_C(877263884)));
v_record21_1.field2[1][1].field0[1] = (ExpectedType5)(INT64_C(330476736));
v_record21_1.field2[1][1].field0[2] = (ExpectedType5)((-INT64_C(2127284208)));
v_record21_1.field2[1][2].field0[0] = (ExpectedType5)(INT64_C(1502019639));
v_record21_1.field2[1][2].field0[1] = (ExpectedType5)(INT64_C(755395400));
v_record21_1.field2[1][2].field0[2] = (ExpectedType5)(INT64_C(1696432360));
v_record21_1.field3 = (ExpectedType3)((-INT64_C(25703)));
ExpectedType33 out_v_record21_1 = abi_h_record21(v_record21_1);
assert(v_record21_1.field0[0][0].field0 == out_v_record21_1.field0[0][0].field0);
assert(v_record21_1.field0[0][0].field1 == out_v_record21_1.field0[0][0].field1);
assert(v_record21_1.field0[0][0].field2 == out_v_record21_1.field0[0][0].field2);
assert(v_record21_1.field0[0][0].field3 == out_v_record21_1.field0[0][0].field3);
assert(v_record21_1.field0[1][0].field0 == out_v_record21_1.field0[1][0].field0);
assert(v_record21_1.field0[1][0].field1 == out_v_record21_1.field0[1][0].field1);
assert(v_record21_1.field0[1][0].field2 == out_v_record21_1.field0[1][0].field2);
assert(v_record21_1.field0[1][0].field3 == out_v_record21_1.field0[1][0].field3);
assert(v_record21_1.field1[0].field0[0][0].field0 == out_v_record21_1.field1[0].field0[0][0].field0);
assert(v_record21_1.field1[0].field0[1][0].field0 == out_v_record21_1.field1[0].field0[1][0].field0);
assert(v_record21_1.field1[0].field1 == out_v_record21_1.field1[0].field1);
assert(v_record21_1.field1[0].field2 == out_v_record21_1.field1[0].field2);
assert(v_record21_1.field1[0].field3 == out_v_record21_1.field1[0].field3);
assert(v_record21_1.field1[0].field4 == out_v_record21_1.field1[0].field4);
assert(v_record21_1.field1[1].field0[0][0].field0 == out_v_record21_1.field1[1].field0[0][0].field0);
assert(v_record21_1.field1[1].field0[1][0].field0 == out_v_record21_1.field1[1].field0[1][0].field0);
assert(v_record21_1.field1[1].field1 == out_v_record21_1.field1[1].field1);
assert(v_record21_1.field1[1].field2 == out_v_record21_1.field1[1].field2);
assert(v_record21_1.field1[1].field3 == out_v_record21_1.field1[1].field3);
assert(v_record21_1.field1[1].field4 == out_v_record21_1.field1[1].field4);
assert(v_record21_1.field1[2].field0[0][0].field0 == out_v_record21_1.field1[2].field0[0][0].field0);
assert(v_record21_1.field1[2].field0[1][0].field0 == out_v_record21_1.field1[2].field0[1][0].field0);
assert(v_record21_1.field1[2].field1 == out_v_record21_1.field1[2].field1);
assert(v_record21_1.field1[2].field2 == out_v_record21_1.field1[2].field2);
assert(v_record21_1.field1[2].field3 == out_v_record21_1.field1[2].field3);
assert(v_record21_1.field1[2].field4 == out_v_record21_1.field1[2].field4);
assert(v_record21_1.field2[0][0].field0[0] == out_v_record21_1.field2[0][0].field0[0]);
assert(v_record21_1.field2[0][0].field0[1] == out_v_record21_1.field2[0][0].field0[1]);
assert(v_record21_1.field2[0][0].field0[2] == out_v_record21_1.field2[0][0].field0[2]);
assert(v_record21_1.field2[0][1].field0[0] == out_v_record21_1.field2[0][1].field0[0]);
assert(v_record21_1.field2[0][1].field0[1] == out_v_record21_1.field2[0][1].field0[1]);
assert(v_record21_1.field2[0][1].field0[2] == out_v_record21_1.field2[0][1].field0[2]);
assert(v_record21_1.field2[0][2].field0[0] == out_v_record21_1.field2[0][2].field0[0]);
assert(v_record21_1.field2[0][2].field0[1] == out_v_record21_1.field2[0][2].field0[1]);
assert(v_record21_1.field2[0][2].field0[2] == out_v_record21_1.field2[0][2].field0[2]);
assert(v_record21_1.field2[1][0].field0[0] == out_v_record21_1.field2[1][0].field0[0]);
assert(v_record21_1.field2[1][0].field0[1] == out_v_record21_1.field2[1][0].field0[1]);
assert(v_record21_1.field2[1][0].field0[2] == out_v_record21_1.field2[1][0].field0[2]);
assert(v_record21_1.field2[1][1].field0[0] == out_v_record21_1.field2[1][1].field0[0]);
assert(v_record21_1.field2[1][1].field0[1] == out_v_record21_1.field2[1][1].field0[1]);
assert(v_record21_1.field2[1][1].field0[2] == out_v_record21_1.field2[1][1].field0[2]);
assert(v_record21_1.field2[1][2].field0[0] == out_v_record21_1.field2[1][2].field0[0]);
assert(v_record21_1.field2[1][2].field0[1] == out_v_record21_1.field2[1][2].field0[1]);
assert(v_record21_1.field2[1][2].field0[2] == out_v_record21_1.field2[1][2].field0[2]);
assert(v_record21_1.field3 == out_v_record21_1.field3);
}
{
ExpectedType33 v_record21_2 = {0};
v_record21_2.field0[0][0].field0 = (ExpectedType6)(UINT64_C(9160585119175980195));
v_record21_2.field0[0][0].field1 = (ExpectedType3)(INT64_C(5915));
v_record21_2.field0[0][0].field2 = (ExpectedType9)(INT64_C(26592742));
v_record21_2.field0[0][0].field3 = (ExpectedType1)(INT64_C(52));
v_record21_2.field0[1][0].field0 = (ExpectedType6)(UINT64_C(9921054850682575561));
v_record21_2.field0[1][0].field1 = (ExpectedType3)(INT64_C(17435));
v_record21_2.field0[1][0].field2 = (ExpectedType9)(INT64_C(663258464));
v_record21_2.field0[1][0].field3 = (ExpectedType1)((-INT64_C(47)));
v_record21_2.field1[0].field0[0][0].field0 = (ExpectedType11)(147.75);
v_record21_2.field1[0].field0[1][0].field0 = (ExpectedType11)(674.75);
v_record21_2.field1[0].field1 = (ExpectedType4)(UINT64_C(3187989417));
v_record21_2.field1[0].field2 = (ExpectedType3)(INT64_C(19235));
v_record21_2.field1[0].field3 = (ExpectedType0)(UINT64_C(85));
v_record21_2.field1[0].field4 = (ExpectedType3)(INT64_C(19683));
v_record21_2.field1[1].field0[0][0].field0 = (ExpectedType11)(890.5);
v_record21_2.field1[1].field0[1][0].field0 = (ExpectedType11)(-499.5);
v_record21_2.field1[1].field1 = (ExpectedType4)(UINT64_C(2557541935));
v_record21_2.field1[1].field2 = (ExpectedType3)((-INT64_C(17867)));
v_record21_2.field1[1].field3 = (ExpectedType0)(UINT64_C(122));
v_record21_2.field1[1].field4 = (ExpectedType3)((-INT64_C(5846)));
v_record21_2.field1[2].field0[0][0].field0 = (ExpectedType11)(-875.75);
v_record21_2.field1[2].field0[1][0].field0 = (ExpectedType11)(-234.75);
v_record21_2.field1[2].field1 = (ExpectedType4)(UINT64_C(3720974951));
v_record21_2.field1[2].field2 = (ExpectedType3)((-INT64_C(29345)));
v_record21_2.field1[2].field3 = (ExpectedType0)(UINT64_C(184));
v_record21_2.field1[2].field4 = (ExpectedType3)(INT64_C(5957));
v_record21_2.field2[0][0].field0[0] = (ExpectedType5)(INT64_C(685963441));
v_record21_2.field2[0][0].field0[1] = (ExpectedType5)(INT64_C(664783941));
v_record21_2.field2[0][0].field0[2] = (ExpectedType5)((-INT64_C(292964276)));
v_record21_2.field2[0][1].field0[0] = (ExpectedType5)(INT64_C(1703569734));
v_record21_2.field2[0][1].field0[1] = (ExpectedType5)(INT64_C(467867594));
v_record21_2.field2[0][1].field0[2] = (ExpectedType5)((-INT64_C(1734945527)));
v_record21_2.field2[0][2].field0[0] = (ExpectedType5)((-INT64_C(506423352)));
v_record21_2.field2[0][2].field0[1] = (ExpectedType5)((-INT64_C(287568175)));
v_record21_2.field2[0][2].field0[2] = (ExpectedType5)(INT64_C(1249363351));
v_record21_2.field2[1][0].field0[0] = (ExpectedType5)((-INT64_C(157861437)));
v_record21_2.field2[1][0].field0[1] = (ExpectedType5)((-INT64_C(409110993)));
v_record21_2.field2[1][0].field0[2] = (ExpectedType5)((-INT64_C(507238665)));
v_record21_2.field2[1][1].field0[0] = (ExpectedType5)((-INT64_C(13053119)));
v_record21_2.field2[1][1].field0[1] = (ExpectedType5)(INT64_C(285741878));
v_record21_2.field2[1][1].field0[2] = (ExpectedType5)(INT64_C(906489036));
v_record21_2.field2[1][2].field0[0] = (ExpectedType5)((-INT64_C(2140195448)));
v_record21_2.field2[1][2].field0[1] = (ExpectedType5)(INT64_C(2008288107));
v_record21_2.field2[1][2].field0[2] = (ExpectedType5)((-INT64_C(1859146572)));
v_record21_2.field3 = (ExpectedType3)((-INT64_C(30062)));
ExpectedType33 out_v_record21_2 = abi_h_record21(v_record21_2);
assert(v_record21_2.field0[0][0].field0 == out_v_record21_2.field0[0][0].field0);
assert(v_record21_2.field0[0][0].field1 == out_v_record21_2.field0[0][0].field1);
assert(v_record21_2.field0[0][0].field2 == out_v_record21_2.field0[0][0].field2);
assert(v_record21_2.field0[0][0].field3 == out_v_record21_2.field0[0][0].field3);
assert(v_record21_2.field0[1][0].field0 == out_v_record21_2.field0[1][0].field0);
assert(v_record21_2.field0[1][0].field1 == out_v_record21_2.field0[1][0].field1);
assert(v_record21_2.field0[1][0].field2 == out_v_record21_2.field0[1][0].field2);
assert(v_record21_2.field0[1][0].field3 == out_v_record21_2.field0[1][0].field3);
assert(v_record21_2.field1[0].field0[0][0].field0 == out_v_record21_2.field1[0].field0[0][0].field0);
assert(v_record21_2.field1[0].field0[1][0].field0 == out_v_record21_2.field1[0].field0[1][0].field0);
assert(v_record21_2.field1[0].field1 == out_v_record21_2.field1[0].field1);
assert(v_record21_2.field1[0].field2 == out_v_record21_2.field1[0].field2);
assert(v_record21_2.field1[0].field3 == out_v_record21_2.field1[0].field3);
assert(v_record21_2.field1[0].field4 == out_v_record21_2.field1[0].field4);
assert(v_record21_2.field1[1].field0[0][0].field0 == out_v_record21_2.field1[1].field0[0][0].field0);
assert(v_record21_2.field1[1].field0[1][0].field0 == out_v_record21_2.field1[1].field0[1][0].field0);
assert(v_record21_2.field1[1].field1 == out_v_record21_2.field1[1].field1);
assert(v_record21_2.field1[1].field2 == out_v_record21_2.field1[1].field2);
assert(v_record21_2.field1[1].field3 == out_v_record21_2.field1[1].field3);
assert(v_record21_2.field1[1].field4 == out_v_record21_2.field1[1].field4);
assert(v_record21_2.field1[2].field0[0][0].field0 == out_v_record21_2.field1[2].field0[0][0].field0);
assert(v_record21_2.field1[2].field0[1][0].field0 == out_v_record21_2.field1[2].field0[1][0].field0);
assert(v_record21_2.field1[2].field1 == out_v_record21_2.field1[2].field1);
assert(v_record21_2.field1[2].field2 == out_v_record21_2.field1[2].field2);
assert(v_record21_2.field1[2].field3 == out_v_record21_2.field1[2].field3);
assert(v_record21_2.field1[2].field4 == out_v_record21_2.field1[2].field4);
assert(v_record21_2.field2[0][0].field0[0] == out_v_record21_2.field2[0][0].field0[0]);
assert(v_record21_2.field2[0][0].field0[1] == out_v_record21_2.field2[0][0].field0[1]);
assert(v_record21_2.field2[0][0].field0[2] == out_v_record21_2.field2[0][0].field0[2]);
assert(v_record21_2.field2[0][1].field0[0] == out_v_record21_2.field2[0][1].field0[0]);
assert(v_record21_2.field2[0][1].field0[1] == out_v_record21_2.field2[0][1].field0[1]);
assert(v_record21_2.field2[0][1].field0[2] == out_v_record21_2.field2[0][1].field0[2]);
assert(v_record21_2.field2[0][2].field0[0] == out_v_record21_2.field2[0][2].field0[0]);
assert(v_record21_2.field2[0][2].field0[1] == out_v_record21_2.field2[0][2].field0[1]);
assert(v_record21_2.field2[0][2].field0[2] == out_v_record21_2.field2[0][2].field0[2]);
assert(v_record21_2.field2[1][0].field0[0] == out_v_record21_2.field2[1][0].field0[0]);
assert(v_record21_2.field2[1][0].field0[1] == out_v_record21_2.field2[1][0].field0[1]);
assert(v_record21_2.field2[1][0].field0[2] == out_v_record21_2.field2[1][0].field0[2]);
assert(v_record21_2.field2[1][1].field0[0] == out_v_record21_2.field2[1][1].field0[0]);
assert(v_record21_2.field2[1][1].field0[1] == out_v_record21_2.field2[1][1].field0[1]);
assert(v_record21_2.field2[1][1].field0[2] == out_v_record21_2.field2[1][1].field0[2]);
assert(v_record21_2.field2[1][2].field0[0] == out_v_record21_2.field2[1][2].field0[0]);
assert(v_record21_2.field2[1][2].field0[1] == out_v_record21_2.field2[1][2].field0[1]);
assert(v_record21_2.field2[1][2].field0[2] == out_v_record21_2.field2[1][2].field0[2]);
assert(v_record21_2.field3 == out_v_record21_2.field3);
}
{
ExpectedType34 v_record22_0 = {0};
v_record22_0.field0[0] = (ExpectedType5)(INT64_C(389707829));
v_record22_0.field1 = (ExpectedType4)(UINT64_C(100550234));
v_record22_0.field2.field0[0].field0[0] = (ExpectedType10)(-708.5);
v_record22_0.field2.field0[0].field0[1] = (ExpectedType10)(174.5);
v_record22_0.field2.field0[0].field0[2] = (ExpectedType10)(-336.5);
v_record22_0.field2.field0[1].field0[0] = (ExpectedType10)(556.0);
v_record22_0.field2.field0[1].field0[1] = (ExpectedType10)(75.75);
v_record22_0.field2.field0[1].field0[2] = (ExpectedType10)(-744.0);
v_record22_0.field2.field0[2].field0[0] = (ExpectedType10)(722.75);
v_record22_0.field2.field0[2].field0[1] = (ExpectedType10)(721.75);
v_record22_0.field2.field0[2].field0[2] = (ExpectedType10)(641.25);
ExpectedType34 out_v_record22_0 = abi_h_record22(v_record22_0);
assert(v_record22_0.field0[0] == out_v_record22_0.field0[0]);
assert(v_record22_0.field1 == out_v_record22_0.field1);
assert(v_record22_0.field2.field0[0].field0[0] == out_v_record22_0.field2.field0[0].field0[0]);
assert(v_record22_0.field2.field0[0].field0[1] == out_v_record22_0.field2.field0[0].field0[1]);
assert(v_record22_0.field2.field0[0].field0[2] == out_v_record22_0.field2.field0[0].field0[2]);
assert(v_record22_0.field2.field0[1].field0[0] == out_v_record22_0.field2.field0[1].field0[0]);
assert(v_record22_0.field2.field0[1].field0[1] == out_v_record22_0.field2.field0[1].field0[1]);
assert(v_record22_0.field2.field0[1].field0[2] == out_v_record22_0.field2.field0[1].field0[2]);
assert(v_record22_0.field2.field0[2].field0[0] == out_v_record22_0.field2.field0[2].field0[0]);
assert(v_record22_0.field2.field0[2].field0[1] == out_v_record22_0.field2.field0[2].field0[1]);
assert(v_record22_0.field2.field0[2].field0[2] == out_v_record22_0.field2.field0[2].field0[2]);
}
{
ExpectedType34 v_record22_1 = {0};
v_record22_1.field0[0] = (ExpectedType5)(INT64_C(346492166));
v_record22_1.field1 = (ExpectedType4)(UINT64_C(1310893430));
v_record22_1.field2.field0[0].field0[0] = (ExpectedType10)(590.25);
v_record22_1.field2.field0[0].field0[1] = (ExpectedType10)(642.0);
v_record22_1.field2.field0[0].field0[2] = (ExpectedType10)(134.75);
v_record22_1.field2.field0[1].field0[0] = (ExpectedType10)(887.5);
v_record22_1.field2.field0[1].field0[1] = (ExpectedType10)(410.25);
v_record22_1.field2.field0[1].field0[2] = (ExpectedType10)(-181.5);
v_record22_1.field2.field0[2].field0[0] = (ExpectedType10)(-511.5);
v_record22_1.field2.field0[2].field0[1] = (ExpectedType10)(996.75);
v_record22_1.field2.field0[2].field0[2] = (ExpectedType10)(874.5);
ExpectedType34 out_v_record22_1 = abi_h_record22(v_record22_1);
assert(v_record22_1.field0[0] == out_v_record22_1.field0[0]);
assert(v_record22_1.field1 == out_v_record22_1.field1);
assert(v_record22_1.field2.field0[0].field0[0] == out_v_record22_1.field2.field0[0].field0[0]);
assert(v_record22_1.field2.field0[0].field0[1] == out_v_record22_1.field2.field0[0].field0[1]);
assert(v_record22_1.field2.field0[0].field0[2] == out_v_record22_1.field2.field0[0].field0[2]);
assert(v_record22_1.field2.field0[1].field0[0] == out_v_record22_1.field2.field0[1].field0[0]);
assert(v_record22_1.field2.field0[1].field0[1] == out_v_record22_1.field2.field0[1].field0[1]);
assert(v_record22_1.field2.field0[1].field0[2] == out_v_record22_1.field2.field0[1].field0[2]);
assert(v_record22_1.field2.field0[2].field0[0] == out_v_record22_1.field2.field0[2].field0[0]);
assert(v_record22_1.field2.field0[2].field0[1] == out_v_record22_1.field2.field0[2].field0[1]);
assert(v_record22_1.field2.field0[2].field0[2] == out_v_record22_1.field2.field0[2].field0[2]);
}
{
ExpectedType34 v_record22_2 = {0};
v_record22_2.field0[0] = (ExpectedType5)((-INT64_C(600638076)));
v_record22_2.field1 = (ExpectedType4)(UINT64_C(3988069879));
v_record22_2.field2.field0[0].field0[0] = (ExpectedType10)(-154.0);
v_record22_2.field2.field0[0].field0[1] = (ExpectedType10)(-507.5);
v_record22_2.field2.field0[0].field0[2] = (ExpectedType10)(-335.75);
v_record22_2.field2.field0[1].field0[0] = (ExpectedType10)(-877.75);
v_record22_2.field2.field0[1].field0[1] = (ExpectedType10)(-952.5);
v_record22_2.field2.field0[1].field0[2] = (ExpectedType10)(43.75);
v_record22_2.field2.field0[2].field0[0] = (ExpectedType10)(7.75);
v_record22_2.field2.field0[2].field0[1] = (ExpectedType10)(-14.25);
v_record22_2.field2.field0[2].field0[2] = (ExpectedType10)(-181.25);
ExpectedType34 out_v_record22_2 = abi_h_record22(v_record22_2);
assert(v_record22_2.field0[0] == out_v_record22_2.field0[0]);
assert(v_record22_2.field1 == out_v_record22_2.field1);
assert(v_record22_2.field2.field0[0].field0[0] == out_v_record22_2.field2.field0[0].field0[0]);
assert(v_record22_2.field2.field0[0].field0[1] == out_v_record22_2.field2.field0[0].field0[1]);
assert(v_record22_2.field2.field0[0].field0[2] == out_v_record22_2.field2.field0[0].field0[2]);
assert(v_record22_2.field2.field0[1].field0[0] == out_v_record22_2.field2.field0[1].field0[0]);
assert(v_record22_2.field2.field0[1].field0[1] == out_v_record22_2.field2.field0[1].field0[1]);
assert(v_record22_2.field2.field0[1].field0[2] == out_v_record22_2.field2.field0[1].field0[2]);
assert(v_record22_2.field2.field0[2].field0[0] == out_v_record22_2.field2.field0[2].field0[0]);
assert(v_record22_2.field2.field0[2].field0[1] == out_v_record22_2.field2.field0[2].field0[1]);
assert(v_record22_2.field2.field0[2].field0[2] == out_v_record22_2.field2.field0[2].field0[2]);
}
{
ExpectedType35 v_record23_0 = {0};
v_record23_0.field0 = (ExpectedType5)(INT64_C(785605757));
v_record23_0.field1 = (ExpectedType4)(UINT64_C(3416974128));
v_record23_0.field2.field0 = (ExpectedType6)(UINT64_C(10223957549403850475));
v_record23_0.field2.field1 = (ExpectedType3)((-INT64_C(32642)));
v_record23_0.field2.field2 = (ExpectedType9)((-INT64_C(854605984)));
v_record23_0.field2.field3 = (ExpectedType1)((-INT64_C(22)));
v_record23_0.field3.field0.field0 = (ExpectedType4)(UINT64_C(4018273722));
ExpectedType35 out_v_record23_0 = abi_h_record23(v_record23_0);
assert(v_record23_0.field0 == out_v_record23_0.field0);
assert(v_record23_0.field1 == out_v_record23_0.field1);
assert(v_record23_0.field2.field0 == out_v_record23_0.field2.field0);
assert(v_record23_0.field2.field1 == out_v_record23_0.field2.field1);
assert(v_record23_0.field2.field2 == out_v_record23_0.field2.field2);
assert(v_record23_0.field2.field3 == out_v_record23_0.field2.field3);
assert(v_record23_0.field3.field0.field0 == out_v_record23_0.field3.field0.field0);
}
{
ExpectedType35 v_record23_1 = {0};
v_record23_1.field0 = (ExpectedType5)((-INT64_C(1597720184)));
v_record23_1.field1 = (ExpectedType4)(UINT64_C(3921495284));
v_record23_1.field2.field0 = (ExpectedType6)(UINT64_C(5491132176301006064));
v_record23_1.field2.field1 = (ExpectedType3)(INT64_C(20086));
v_record23_1.field2.field2 = (ExpectedType9)(INT64_C(1574456124));
v_record23_1.field2.field3 = (ExpectedType1)((-INT64_C(88)));
v_record23_1.field3.field0.field0 = (ExpectedType4)(UINT64_C(1660082137));
ExpectedType35 out_v_record23_1 = abi_h_record23(v_record23_1);
assert(v_record23_1.field0 == out_v_record23_1.field0);
assert(v_record23_1.field1 == out_v_record23_1.field1);
assert(v_record23_1.field2.field0 == out_v_record23_1.field2.field0);
assert(v_record23_1.field2.field1 == out_v_record23_1.field2.field1);
assert(v_record23_1.field2.field2 == out_v_record23_1.field2.field2);
assert(v_record23_1.field2.field3 == out_v_record23_1.field2.field3);
assert(v_record23_1.field3.field0.field0 == out_v_record23_1.field3.field0.field0);
}
{
ExpectedType35 v_record23_2 = {0};
v_record23_2.field0 = (ExpectedType5)((-INT64_C(859865017)));
v_record23_2.field1 = (ExpectedType4)(UINT64_C(1871082139));
v_record23_2.field2.field0 = (ExpectedType6)(UINT64_C(5937623706056108289));
v_record23_2.field2.field1 = (ExpectedType3)((-INT64_C(13379)));
v_record23_2.field2.field2 = (ExpectedType9)(INT64_C(1215971744));
v_record23_2.field2.field3 = (ExpectedType1)(INT64_C(81));
v_record23_2.field3.field0.field0 = (ExpectedType4)(UINT64_C(1851360768));
ExpectedType35 out_v_record23_2 = abi_h_record23(v_record23_2);
assert(v_record23_2.field0 == out_v_record23_2.field0);
assert(v_record23_2.field1 == out_v_record23_2.field1);
assert(v_record23_2.field2.field0 == out_v_record23_2.field2.field0);
assert(v_record23_2.field2.field1 == out_v_record23_2.field2.field1);
assert(v_record23_2.field2.field2 == out_v_record23_2.field2.field2);
assert(v_record23_2.field2.field3 == out_v_record23_2.field2.field3);
assert(v_record23_2.field3.field0.field0 == out_v_record23_2.field3.field0.field0);
}
{
ExpectedType36 v_record24_0 = {0};
v_record24_0.field0[0].field0 = (ExpectedType11)(-626.25);
ExpectedType36 out_v_record24_0 = abi_h_record24(v_record24_0);
assert(v_record24_0.field0[0].field0 == out_v_record24_0.field0[0].field0);
}
{
ExpectedType36 v_record24_1 = {0};
v_record24_1.field0[0].field0 = (ExpectedType11)(-564.75);
ExpectedType36 out_v_record24_1 = abi_h_record24(v_record24_1);
assert(v_record24_1.field0[0].field0 == out_v_record24_1.field0[0].field0);
}
{
ExpectedType36 v_record24_2 = {0};
v_record24_2.field0[0].field0 = (ExpectedType11)(386.25);
ExpectedType36 out_v_record24_2 = abi_h_record24(v_record24_2);
assert(v_record24_2.field0[0].field0 == out_v_record24_2.field0[0].field0);
}
{
ExpectedType37 v_record25_0 = {0};
v_record25_0.field0[0][0].field0 = (ExpectedType5)((-INT64_C(215459290)));
v_record25_0.field0[0][0].field1 = (ExpectedType4)(UINT64_C(2102117509));
v_record25_0.field0[0][0].field2.field0 = (ExpectedType6)(UINT64_C(3627050484071376142));
v_record25_0.field0[0][0].field2.field1 = (ExpectedType3)((-INT64_C(28584)));
v_record25_0.field0[0][0].field2.field2 = (ExpectedType9)(INT64_C(1280717389));
v_record25_0.field0[0][0].field2.field3 = (ExpectedType1)(INT64_C(47));
v_record25_0.field0[0][0].field3.field0.field0 = (ExpectedType4)(UINT64_C(21888436));
v_record25_0.field0[0][1].field0 = (ExpectedType5)((-INT64_C(579622342)));
v_record25_0.field0[0][1].field1 = (ExpectedType4)(UINT64_C(283615715));
v_record25_0.field0[0][1].field2.field0 = (ExpectedType6)(UINT64_C(347548409272745972));
v_record25_0.field0[0][1].field2.field1 = (ExpectedType3)(INT64_C(19893));
v_record25_0.field0[0][1].field2.field2 = (ExpectedType9)(INT64_C(872377578));
v_record25_0.field0[0][1].field2.field3 = (ExpectedType1)(INT64_C(57));
v_record25_0.field0[0][1].field3.field0.field0 = (ExpectedType4)(UINT64_C(2156061121));
v_record25_0.field0[1][0].field0 = (ExpectedType5)((-INT64_C(1062173136)));
v_record25_0.field0[1][0].field1 = (ExpectedType4)(UINT64_C(1508479238));
v_record25_0.field0[1][0].field2.field0 = (ExpectedType6)(UINT64_C(6288213042630128934));
v_record25_0.field0[1][0].field2.field1 = (ExpectedType3)((-INT64_C(30241)));
v_record25_0.field0[1][0].field2.field2 = (ExpectedType9)(INT64_C(255087681));
v_record25_0.field0[1][0].field2.field3 = (ExpectedType1)(INT64_C(110));
v_record25_0.field0[1][0].field3.field0.field0 = (ExpectedType4)(UINT64_C(660242683));
v_record25_0.field0[1][1].field0 = (ExpectedType5)((-INT64_C(812225710)));
v_record25_0.field0[1][1].field1 = (ExpectedType4)(UINT64_C(563474786));
v_record25_0.field0[1][1].field2.field0 = (ExpectedType6)(UINT64_C(14896942776625634181));
v_record25_0.field0[1][1].field2.field1 = (ExpectedType3)(INT64_C(2004));
v_record25_0.field0[1][1].field2.field2 = (ExpectedType9)((-INT64_C(578024404)));
v_record25_0.field0[1][1].field2.field3 = (ExpectedType1)(INT64_C(19));
v_record25_0.field0[1][1].field3.field0.field0 = (ExpectedType4)(UINT64_C(507478800));
v_record25_0.field1.field0 = (ExpectedType11)(798.5);
v_record25_0.field2.field0 = (ExpectedType5)(INT64_C(809176426));
v_record25_0.field2.field1.field0 = (ExpectedType6)(UINT64_C(16788656555101138953));
v_record25_0.field2.field1.field1 = (ExpectedType3)((-INT64_C(23891)));
v_record25_0.field2.field1.field2 = (ExpectedType9)(INT64_C(1075771415));
v_record25_0.field2.field1.field3 = (ExpectedType1)(INT64_C(113));
v_record25_0.field3.field0 = (ExpectedType5)((-INT64_C(86778271)));
v_record25_0.field3.field1.field0 = (ExpectedType6)(UINT64_C(9023961473589036346));
v_record25_0.field3.field1.field1 = (ExpectedType3)(INT64_C(20464));
v_record25_0.field3.field1.field2 = (ExpectedType9)((-INT64_C(1491187756)));
v_record25_0.field3.field1.field3 = (ExpectedType1)(INT64_C(26));
ExpectedType37 out_v_record25_0 = abi_h_record25(v_record25_0);
assert(v_record25_0.field0[0][0].field0 == out_v_record25_0.field0[0][0].field0);
assert(v_record25_0.field0[0][0].field1 == out_v_record25_0.field0[0][0].field1);
assert(v_record25_0.field0[0][0].field2.field0 == out_v_record25_0.field0[0][0].field2.field0);
assert(v_record25_0.field0[0][0].field2.field1 == out_v_record25_0.field0[0][0].field2.field1);
assert(v_record25_0.field0[0][0].field2.field2 == out_v_record25_0.field0[0][0].field2.field2);
assert(v_record25_0.field0[0][0].field2.field3 == out_v_record25_0.field0[0][0].field2.field3);
assert(v_record25_0.field0[0][0].field3.field0.field0 == out_v_record25_0.field0[0][0].field3.field0.field0);
assert(v_record25_0.field0[0][1].field0 == out_v_record25_0.field0[0][1].field0);
assert(v_record25_0.field0[0][1].field1 == out_v_record25_0.field0[0][1].field1);
assert(v_record25_0.field0[0][1].field2.field0 == out_v_record25_0.field0[0][1].field2.field0);
assert(v_record25_0.field0[0][1].field2.field1 == out_v_record25_0.field0[0][1].field2.field1);
assert(v_record25_0.field0[0][1].field2.field2 == out_v_record25_0.field0[0][1].field2.field2);
assert(v_record25_0.field0[0][1].field2.field3 == out_v_record25_0.field0[0][1].field2.field3);
assert(v_record25_0.field0[0][1].field3.field0.field0 == out_v_record25_0.field0[0][1].field3.field0.field0);
assert(v_record25_0.field0[1][0].field0 == out_v_record25_0.field0[1][0].field0);
assert(v_record25_0.field0[1][0].field1 == out_v_record25_0.field0[1][0].field1);
assert(v_record25_0.field0[1][0].field2.field0 == out_v_record25_0.field0[1][0].field2.field0);
assert(v_record25_0.field0[1][0].field2.field1 == out_v_record25_0.field0[1][0].field2.field1);
assert(v_record25_0.field0[1][0].field2.field2 == out_v_record25_0.field0[1][0].field2.field2);
assert(v_record25_0.field0[1][0].field2.field3 == out_v_record25_0.field0[1][0].field2.field3);
assert(v_record25_0.field0[1][0].field3.field0.field0 == out_v_record25_0.field0[1][0].field3.field0.field0);
assert(v_record25_0.field0[1][1].field0 == out_v_record25_0.field0[1][1].field0);
assert(v_record25_0.field0[1][1].field1 == out_v_record25_0.field0[1][1].field1);
assert(v_record25_0.field0[1][1].field2.field0 == out_v_record25_0.field0[1][1].field2.field0);
assert(v_record25_0.field0[1][1].field2.field1 == out_v_record25_0.field0[1][1].field2.field1);
assert(v_record25_0.field0[1][1].field2.field2 == out_v_record25_0.field0[1][1].field2.field2);
assert(v_record25_0.field0[1][1].field2.field3 == out_v_record25_0.field0[1][1].field2.field3);
assert(v_record25_0.field0[1][1].field3.field0.field0 == out_v_record25_0.field0[1][1].field3.field0.field0);
assert(v_record25_0.field1.field0 == out_v_record25_0.field1.field0);
assert(v_record25_0.field2.field0 == out_v_record25_0.field2.field0);
assert(v_record25_0.field2.field1.field0 == out_v_record25_0.field2.field1.field0);
assert(v_record25_0.field2.field1.field1 == out_v_record25_0.field2.field1.field1);
assert(v_record25_0.field2.field1.field2 == out_v_record25_0.field2.field1.field2);
assert(v_record25_0.field2.field1.field3 == out_v_record25_0.field2.field1.field3);
assert(v_record25_0.field3.field0 == out_v_record25_0.field3.field0);
assert(v_record25_0.field3.field1.field0 == out_v_record25_0.field3.field1.field0);
assert(v_record25_0.field3.field1.field1 == out_v_record25_0.field3.field1.field1);
assert(v_record25_0.field3.field1.field2 == out_v_record25_0.field3.field1.field2);
assert(v_record25_0.field3.field1.field3 == out_v_record25_0.field3.field1.field3);
}
{
ExpectedType37 v_record25_1 = {0};
v_record25_1.field0[0][0].field0 = (ExpectedType5)(INT64_C(1079776355));
v_record25_1.field0[0][0].field1 = (ExpectedType4)(UINT64_C(1856532203));
v_record25_1.field0[0][0].field2.field0 = (ExpectedType6)(UINT64_C(115702831849290840));
v_record25_1.field0[0][0].field2.field1 = (ExpectedType3)((-INT64_C(6871)));
v_record25_1.field0[0][0].field2.field2 = (ExpectedType9)((-INT64_C(339278200)));
v_record25_1.field0[0][0].field2.field3 = (ExpectedType1)((-INT64_C(64)));
v_record25_1.field0[0][0].field3.field0.field0 = (ExpectedType4)(UINT64_C(273720236));
v_record25_1.field0[0][1].field0 = (ExpectedType5)((-INT64_C(69170101)));
v_record25_1.field0[0][1].field1 = (ExpectedType4)(UINT64_C(3349604486));
v_record25_1.field0[0][1].field2.field0 = (ExpectedType6)(UINT64_C(726009709909115671));
v_record25_1.field0[0][1].field2.field1 = (ExpectedType3)(INT64_C(4275));
v_record25_1.field0[0][1].field2.field2 = (ExpectedType9)(INT64_C(558862263));
v_record25_1.field0[0][1].field2.field3 = (ExpectedType1)(INT64_C(17));
v_record25_1.field0[0][1].field3.field0.field0 = (ExpectedType4)(UINT64_C(3976115940));
v_record25_1.field0[1][0].field0 = (ExpectedType5)(INT64_C(1171132174));
v_record25_1.field0[1][0].field1 = (ExpectedType4)(UINT64_C(2839415171));
v_record25_1.field0[1][0].field2.field0 = (ExpectedType6)(UINT64_C(18205390978632427537));
v_record25_1.field0[1][0].field2.field1 = (ExpectedType3)(INT64_C(661));
v_record25_1.field0[1][0].field2.field2 = (ExpectedType9)((-INT64_C(666898265)));
v_record25_1.field0[1][0].field2.field3 = (ExpectedType1)(INT64_C(51));
v_record25_1.field0[1][0].field3.field0.field0 = (ExpectedType4)(UINT64_C(646046842));
v_record25_1.field0[1][1].field0 = (ExpectedType5)((-INT64_C(1503825556)));
v_record25_1.field0[1][1].field1 = (ExpectedType4)(UINT64_C(4235021673));
v_record25_1.field0[1][1].field2.field0 = (ExpectedType6)(UINT64_C(439773313108556260));
v_record25_1.field0[1][1].field2.field1 = (ExpectedType3)(INT64_C(15304));
v_record25_1.field0[1][1].field2.field2 = (ExpectedType9)((-INT64_C(214055278)));
v_record25_1.field0[1][1].field2.field3 = (ExpectedType1)((-INT64_C(120)));
v_record25_1.field0[1][1].field3.field0.field0 = (ExpectedType4)(UINT64_C(2918407091));
v_record25_1.field1.field0 = (ExpectedType11)(238.0);
v_record25_1.field2.field0 = (ExpectedType5)(INT64_C(1068181010));
v_record25_1.field2.field1.field0 = (ExpectedType6)(UINT64_C(8350105647027034618));
v_record25_1.field2.field1.field1 = (ExpectedType3)(INT64_C(9095));
v_record25_1.field2.field1.field2 = (ExpectedType9)((-INT64_C(1341754308)));
v_record25_1.field2.field1.field3 = (ExpectedType1)(INT64_C(119));
v_record25_1.field3.field0 = (ExpectedType5)(INT64_C(850353807));
v_record25_1.field3.field1.field0 = (ExpectedType6)(UINT64_C(13863951537748915220));
v_record25_1.field3.field1.field1 = (ExpectedType3)(INT64_C(4599));
v_record25_1.field3.field1.field2 = (ExpectedType9)((-INT64_C(1430630059)));
v_record25_1.field3.field1.field3 = (ExpectedType1)((-INT64_C(120)));
ExpectedType37 out_v_record25_1 = abi_h_record25(v_record25_1);
assert(v_record25_1.field0[0][0].field0 == out_v_record25_1.field0[0][0].field0);
assert(v_record25_1.field0[0][0].field1 == out_v_record25_1.field0[0][0].field1);
assert(v_record25_1.field0[0][0].field2.field0 == out_v_record25_1.field0[0][0].field2.field0);
assert(v_record25_1.field0[0][0].field2.field1 == out_v_record25_1.field0[0][0].field2.field1);
assert(v_record25_1.field0[0][0].field2.field2 == out_v_record25_1.field0[0][0].field2.field2);
assert(v_record25_1.field0[0][0].field2.field3 == out_v_record25_1.field0[0][0].field2.field3);
assert(v_record25_1.field0[0][0].field3.field0.field0 == out_v_record25_1.field0[0][0].field3.field0.field0);
assert(v_record25_1.field0[0][1].field0 == out_v_record25_1.field0[0][1].field0);
assert(v_record25_1.field0[0][1].field1 == out_v_record25_1.field0[0][1].field1);
assert(v_record25_1.field0[0][1].field2.field0 == out_v_record25_1.field0[0][1].field2.field0);
assert(v_record25_1.field0[0][1].field2.field1 == out_v_record25_1.field0[0][1].field2.field1);
assert(v_record25_1.field0[0][1].field2.field2 == out_v_record25_1.field0[0][1].field2.field2);
assert(v_record25_1.field0[0][1].field2.field3 == out_v_record25_1.field0[0][1].field2.field3);
assert(v_record25_1.field0[0][1].field3.field0.field0 == out_v_record25_1.field0[0][1].field3.field0.field0);
assert(v_record25_1.field0[1][0].field0 == out_v_record25_1.field0[1][0].field0);
assert(v_record25_1.field0[1][0].field1 == out_v_record25_1.field0[1][0].field1);
assert(v_record25_1.field0[1][0].field2.field0 == out_v_record25_1.field0[1][0].field2.field0);
assert(v_record25_1.field0[1][0].field2.field1 == out_v_record25_1.field0[1][0].field2.field1);
assert(v_record25_1.field0[1][0].field2.field2 == out_v_record25_1.field0[1][0].field2.field2);
assert(v_record25_1.field0[1][0].field2.field3 == out_v_record25_1.field0[1][0].field2.field3);
assert(v_record25_1.field0[1][0].field3.field0.field0 == out_v_record25_1.field0[1][0].field3.field0.field0);
assert(v_record25_1.field0[1][1].field0 == out_v_record25_1.field0[1][1].field0);
assert(v_record25_1.field0[1][1].field1 == out_v_record25_1.field0[1][1].field1);
assert(v_record25_1.field0[1][1].field2.field0 == out_v_record25_1.field0[1][1].field2.field0);
assert(v_record25_1.field0[1][1].field2.field1 == out_v_record25_1.field0[1][1].field2.field1);
assert(v_record25_1.field0[1][1].field2.field2 == out_v_record25_1.field0[1][1].field2.field2);
assert(v_record25_1.field0[1][1].field2.field3 == out_v_record25_1.field0[1][1].field2.field3);
assert(v_record25_1.field0[1][1].field3.field0.field0 == out_v_record25_1.field0[1][1].field3.field0.field0);
assert(v_record25_1.field1.field0 == out_v_record25_1.field1.field0);
assert(v_record25_1.field2.field0 == out_v_record25_1.field2.field0);
assert(v_record25_1.field2.field1.field0 == out_v_record25_1.field2.field1.field0);
assert(v_record25_1.field2.field1.field1 == out_v_record25_1.field2.field1.field1);
assert(v_record25_1.field2.field1.field2 == out_v_record25_1.field2.field1.field2);
assert(v_record25_1.field2.field1.field3 == out_v_record25_1.field2.field1.field3);
assert(v_record25_1.field3.field0 == out_v_record25_1.field3.field0);
assert(v_record25_1.field3.field1.field0 == out_v_record25_1.field3.field1.field0);
assert(v_record25_1.field3.field1.field1 == out_v_record25_1.field3.field1.field1);
assert(v_record25_1.field3.field1.field2 == out_v_record25_1.field3.field1.field2);
assert(v_record25_1.field3.field1.field3 == out_v_record25_1.field3.field1.field3);
}
{
ExpectedType37 v_record25_2 = {0};
v_record25_2.field0[0][0].field0 = (ExpectedType5)(INT64_C(948489306));
v_record25_2.field0[0][0].field1 = (ExpectedType4)(UINT64_C(4100955032));
v_record25_2.field0[0][0].field2.field0 = (ExpectedType6)(UINT64_C(11684666857526000002));
v_record25_2.field0[0][0].field2.field1 = (ExpectedType3)((-INT64_C(17943)));
v_record25_2.field0[0][0].field2.field2 = (ExpectedType9)((-INT64_C(1944923419)));
v_record25_2.field0[0][0].field2.field3 = (ExpectedType1)(INT64_C(118));
v_record25_2.field0[0][0].field3.field0.field0 = (ExpectedType4)(UINT64_C(1625581281));
v_record25_2.field0[0][1].field0 = (ExpectedType5)(INT64_C(475768900));
v_record25_2.field0[0][1].field1 = (ExpectedType4)(UINT64_C(2907780652));
v_record25_2.field0[0][1].field2.field0 = (ExpectedType6)(UINT64_C(8962231687189136345));
v_record25_2.field0[0][1].field2.field1 = (ExpectedType3)((-INT64_C(1726)));
v_record25_2.field0[0][1].field2.field2 = (ExpectedType9)((-INT64_C(1199898618)));
v_record25_2.field0[0][1].field2.field3 = (ExpectedType1)(INT64_C(9));
v_record25_2.field0[0][1].field3.field0.field0 = (ExpectedType4)(UINT64_C(734722477));
v_record25_2.field0[1][0].field0 = (ExpectedType5)(INT64_C(1491044162));
v_record25_2.field0[1][0].field1 = (ExpectedType4)(UINT64_C(1807517708));
v_record25_2.field0[1][0].field2.field0 = (ExpectedType6)(UINT64_C(9623744006098902512));
v_record25_2.field0[1][0].field2.field1 = (ExpectedType3)(INT64_C(13134));
v_record25_2.field0[1][0].field2.field2 = (ExpectedType9)(INT64_C(1297612932));
v_record25_2.field0[1][0].field2.field3 = (ExpectedType1)(INT64_C(37));
v_record25_2.field0[1][0].field3.field0.field0 = (ExpectedType4)(UINT64_C(2930573642));
v_record25_2.field0[1][1].field0 = (ExpectedType5)((-INT64_C(326969903)));
v_record25_2.field0[1][1].field1 = (ExpectedType4)(UINT64_C(120508044));
v_record25_2.field0[1][1].field2.field0 = (ExpectedType6)(UINT64_C(5806513174117735209));
v_record25_2.field0[1][1].field2.field1 = (ExpectedType3)(INT64_C(20479));
v_record25_2.field0[1][1].field2.field2 = (ExpectedType9)(INT64_C(1285372648));
v_record25_2.field0[1][1].field2.field3 = (ExpectedType1)((-INT64_C(119)));
v_record25_2.field0[1][1].field3.field0.field0 = (ExpectedType4)(UINT64_C(1775363742));
v_record25_2.field1.field0 = (ExpectedType11)(-83.75);
v_record25_2.field2.field0 = (ExpectedType5)(INT64_C(85171032));
v_record25_2.field2.field1.field0 = (ExpectedType6)(UINT64_C(239016683425427603));
v_record25_2.field2.field1.field1 = (ExpectedType3)(INT64_C(3524));
v_record25_2.field2.field1.field2 = (ExpectedType9)(INT64_C(1704365014));
v_record25_2.field2.field1.field3 = (ExpectedType1)(INT64_C(98));
v_record25_2.field3.field0 = (ExpectedType5)(INT64_C(1289790574));
v_record25_2.field3.field1.field0 = (ExpectedType6)(UINT64_C(11706330696325333885));
v_record25_2.field3.field1.field1 = (ExpectedType3)(INT64_C(22880));
v_record25_2.field3.field1.field2 = (ExpectedType9)(INT64_C(151276656));
v_record25_2.field3.field1.field3 = (ExpectedType1)(INT64_C(121));
ExpectedType37 out_v_record25_2 = abi_h_record25(v_record25_2);
assert(v_record25_2.field0[0][0].field0 == out_v_record25_2.field0[0][0].field0);
assert(v_record25_2.field0[0][0].field1 == out_v_record25_2.field0[0][0].field1);
assert(v_record25_2.field0[0][0].field2.field0 == out_v_record25_2.field0[0][0].field2.field0);
assert(v_record25_2.field0[0][0].field2.field1 == out_v_record25_2.field0[0][0].field2.field1);
assert(v_record25_2.field0[0][0].field2.field2 == out_v_record25_2.field0[0][0].field2.field2);
assert(v_record25_2.field0[0][0].field2.field3 == out_v_record25_2.field0[0][0].field2.field3);
assert(v_record25_2.field0[0][0].field3.field0.field0 == out_v_record25_2.field0[0][0].field3.field0.field0);
assert(v_record25_2.field0[0][1].field0 == out_v_record25_2.field0[0][1].field0);
assert(v_record25_2.field0[0][1].field1 == out_v_record25_2.field0[0][1].field1);
assert(v_record25_2.field0[0][1].field2.field0 == out_v_record25_2.field0[0][1].field2.field0);
assert(v_record25_2.field0[0][1].field2.field1 == out_v_record25_2.field0[0][1].field2.field1);
assert(v_record25_2.field0[0][1].field2.field2 == out_v_record25_2.field0[0][1].field2.field2);
assert(v_record25_2.field0[0][1].field2.field3 == out_v_record25_2.field0[0][1].field2.field3);
assert(v_record25_2.field0[0][1].field3.field0.field0 == out_v_record25_2.field0[0][1].field3.field0.field0);
assert(v_record25_2.field0[1][0].field0 == out_v_record25_2.field0[1][0].field0);
assert(v_record25_2.field0[1][0].field1 == out_v_record25_2.field0[1][0].field1);
assert(v_record25_2.field0[1][0].field2.field0 == out_v_record25_2.field0[1][0].field2.field0);
assert(v_record25_2.field0[1][0].field2.field1 == out_v_record25_2.field0[1][0].field2.field1);
assert(v_record25_2.field0[1][0].field2.field2 == out_v_record25_2.field0[1][0].field2.field2);
assert(v_record25_2.field0[1][0].field2.field3 == out_v_record25_2.field0[1][0].field2.field3);
assert(v_record25_2.field0[1][0].field3.field0.field0 == out_v_record25_2.field0[1][0].field3.field0.field0);
assert(v_record25_2.field0[1][1].field0 == out_v_record25_2.field0[1][1].field0);
assert(v_record25_2.field0[1][1].field1 == out_v_record25_2.field0[1][1].field1);
assert(v_record25_2.field0[1][1].field2.field0 == out_v_record25_2.field0[1][1].field2.field0);
assert(v_record25_2.field0[1][1].field2.field1 == out_v_record25_2.field0[1][1].field2.field1);
assert(v_record25_2.field0[1][1].field2.field2 == out_v_record25_2.field0[1][1].field2.field2);
assert(v_record25_2.field0[1][1].field2.field3 == out_v_record25_2.field0[1][1].field2.field3);
assert(v_record25_2.field0[1][1].field3.field0.field0 == out_v_record25_2.field0[1][1].field3.field0.field0);
assert(v_record25_2.field1.field0 == out_v_record25_2.field1.field0);
assert(v_record25_2.field2.field0 == out_v_record25_2.field2.field0);
assert(v_record25_2.field2.field1.field0 == out_v_record25_2.field2.field1.field0);
assert(v_record25_2.field2.field1.field1 == out_v_record25_2.field2.field1.field1);
assert(v_record25_2.field2.field1.field2 == out_v_record25_2.field2.field1.field2);
assert(v_record25_2.field2.field1.field3 == out_v_record25_2.field2.field1.field3);
assert(v_record25_2.field3.field0 == out_v_record25_2.field3.field0);
assert(v_record25_2.field3.field1.field0 == out_v_record25_2.field3.field1.field0);
assert(v_record25_2.field3.field1.field1 == out_v_record25_2.field3.field1.field1);
assert(v_record25_2.field3.field1.field2 == out_v_record25_2.field3.field1.field2);
assert(v_record25_2.field3.field1.field3 == out_v_record25_2.field3.field1.field3);
}
{
ExpectedType38 v_record26_0 = {0};
v_record26_0.field0.field0.field0.field0 = (ExpectedType6)(UINT64_C(14471236113526758));
v_record26_0.field0.field0.field0.field1 = (ExpectedType3)((-INT64_C(19214)));
v_record26_0.field0.field0.field0.field2 = (ExpectedType9)(INT64_C(1684441449));
v_record26_0.field0.field0.field0.field3 = (ExpectedType1)(INT64_C(109));
v_record26_0.field0.field0.field1 = (ExpectedType8)(UINT64_C(2324264769));
v_record26_0.field0.field0.field2[0].field0 = (ExpectedType6)(UINT64_C(3825400132694487793));
v_record26_0.field0.field0.field2[0].field1 = (ExpectedType3)(INT64_C(24059));
v_record26_0.field0.field0.field2[0].field2 = (ExpectedType9)(INT64_C(206592568));
v_record26_0.field0.field0.field2[0].field3 = (ExpectedType1)((-INT64_C(127)));
v_record26_0.field0.field1.field0[0] = (ExpectedType10)(-397.75);
v_record26_0.field0.field1.field0[1] = (ExpectedType10)(-221.25);
v_record26_0.field0.field1.field0[2] = (ExpectedType10)(-93.25);
v_record26_0.field1[0].field0 = (ExpectedType4)(UINT64_C(2438159184));
v_record26_0.field1[1].field0 = (ExpectedType4)(UINT64_C(3321917328));
v_record26_0.field1[2].field0 = (ExpectedType4)(UINT64_C(1816633432));
v_record26_0.field1[3].field0 = (ExpectedType4)(UINT64_C(3879426305));
v_record26_0.field2.field0 = (ExpectedType11)(200.25);
ExpectedType38 out_v_record26_0 = abi_h_record26(v_record26_0);
assert(v_record26_0.field0.field0.field0.field0 == out_v_record26_0.field0.field0.field0.field0);
assert(v_record26_0.field0.field0.field0.field1 == out_v_record26_0.field0.field0.field0.field1);
assert(v_record26_0.field0.field0.field0.field2 == out_v_record26_0.field0.field0.field0.field2);
assert(v_record26_0.field0.field0.field0.field3 == out_v_record26_0.field0.field0.field0.field3);
assert(v_record26_0.field0.field0.field1 == out_v_record26_0.field0.field0.field1);
assert(v_record26_0.field0.field0.field2[0].field0 == out_v_record26_0.field0.field0.field2[0].field0);
assert(v_record26_0.field0.field0.field2[0].field1 == out_v_record26_0.field0.field0.field2[0].field1);
assert(v_record26_0.field0.field0.field2[0].field2 == out_v_record26_0.field0.field0.field2[0].field2);
assert(v_record26_0.field0.field0.field2[0].field3 == out_v_record26_0.field0.field0.field2[0].field3);
assert(v_record26_0.field0.field1.field0[0] == out_v_record26_0.field0.field1.field0[0]);
assert(v_record26_0.field0.field1.field0[1] == out_v_record26_0.field0.field1.field0[1]);
assert(v_record26_0.field0.field1.field0[2] == out_v_record26_0.field0.field1.field0[2]);
assert(v_record26_0.field1[0].field0 == out_v_record26_0.field1[0].field0);
assert(v_record26_0.field1[1].field0 == out_v_record26_0.field1[1].field0);
assert(v_record26_0.field1[2].field0 == out_v_record26_0.field1[2].field0);
assert(v_record26_0.field1[3].field0 == out_v_record26_0.field1[3].field0);
assert(v_record26_0.field2.field0 == out_v_record26_0.field2.field0);
}
{
ExpectedType38 v_record26_1 = {0};
v_record26_1.field0.field0.field0.field0 = (ExpectedType6)(UINT64_C(8982784073414578301));
v_record26_1.field0.field0.field0.field1 = (ExpectedType3)((-INT64_C(10714)));
v_record26_1.field0.field0.field0.field2 = (ExpectedType9)((-INT64_C(98159294)));
v_record26_1.field0.field0.field0.field3 = (ExpectedType1)(INT64_C(87));
v_record26_1.field0.field0.field1 = (ExpectedType8)(UINT64_C(994380812));
v_record26_1.field0.field0.field2[0].field0 = (ExpectedType6)(UINT64_C(578600032943822203));
v_record26_1.field0.field0.field2[0].field1 = (ExpectedType3)((-INT64_C(13879)));
v_record26_1.field0.field0.field2[0].field2 = (ExpectedType9)((-INT64_C(1803474941)));
v_record26_1.field0.field0.field2[0].field3 = (ExpectedType1)((-INT64_C(8)));
v_record26_1.field0.field1.field0[0] = (ExpectedType10)(-706.0);
v_record26_1.field0.field1.field0[1] = (ExpectedType10)(-642.5);
v_record26_1.field0.field1.field0[2] = (ExpectedType10)(-223.0);
v_record26_1.field1[0].field0 = (ExpectedType4)(UINT64_C(3586806211));
v_record26_1.field1[1].field0 = (ExpectedType4)(UINT64_C(4243130456));
v_record26_1.field1[2].field0 = (ExpectedType4)(UINT64_C(1772319404));
v_record26_1.field1[3].field0 = (ExpectedType4)(UINT64_C(2562389170));
v_record26_1.field2.field0 = (ExpectedType11)(335.25);
ExpectedType38 out_v_record26_1 = abi_h_record26(v_record26_1);
assert(v_record26_1.field0.field0.field0.field0 == out_v_record26_1.field0.field0.field0.field0);
assert(v_record26_1.field0.field0.field0.field1 == out_v_record26_1.field0.field0.field0.field1);
assert(v_record26_1.field0.field0.field0.field2 == out_v_record26_1.field0.field0.field0.field2);
assert(v_record26_1.field0.field0.field0.field3 == out_v_record26_1.field0.field0.field0.field3);
assert(v_record26_1.field0.field0.field1 == out_v_record26_1.field0.field0.field1);
assert(v_record26_1.field0.field0.field2[0].field0 == out_v_record26_1.field0.field0.field2[0].field0);
assert(v_record26_1.field0.field0.field2[0].field1 == out_v_record26_1.field0.field0.field2[0].field1);
assert(v_record26_1.field0.field0.field2[0].field2 == out_v_record26_1.field0.field0.field2[0].field2);
assert(v_record26_1.field0.field0.field2[0].field3 == out_v_record26_1.field0.field0.field2[0].field3);
assert(v_record26_1.field0.field1.field0[0] == out_v_record26_1.field0.field1.field0[0]);
assert(v_record26_1.field0.field1.field0[1] == out_v_record26_1.field0.field1.field0[1]);
assert(v_record26_1.field0.field1.field0[2] == out_v_record26_1.field0.field1.field0[2]);
assert(v_record26_1.field1[0].field0 == out_v_record26_1.field1[0].field0);
assert(v_record26_1.field1[1].field0 == out_v_record26_1.field1[1].field0);
assert(v_record26_1.field1[2].field0 == out_v_record26_1.field1[2].field0);
assert(v_record26_1.field1[3].field0 == out_v_record26_1.field1[3].field0);
assert(v_record26_1.field2.field0 == out_v_record26_1.field2.field0);
}
{
ExpectedType38 v_record26_2 = {0};
v_record26_2.field0.field0.field0.field0 = (ExpectedType6)(UINT64_C(16255474097802981606));
v_record26_2.field0.field0.field0.field1 = (ExpectedType3)((-INT64_C(2082)));
v_record26_2.field0.field0.field0.field2 = (ExpectedType9)(INT64_C(950735109));
v_record26_2.field0.field0.field0.field3 = (ExpectedType1)((-INT64_C(52)));
v_record26_2.field0.field0.field1 = (ExpectedType8)(UINT64_C(2397820782));
v_record26_2.field0.field0.field2[0].field0 = (ExpectedType6)(UINT64_C(14225077195229527404));
v_record26_2.field0.field0.field2[0].field1 = (ExpectedType3)(INT64_C(30867));
v_record26_2.field0.field0.field2[0].field2 = (ExpectedType9)(INT64_C(798734811));
v_record26_2.field0.field0.field2[0].field3 = (ExpectedType1)(INT64_C(80));
v_record26_2.field0.field1.field0[0] = (ExpectedType10)(-772.75);
v_record26_2.field0.field1.field0[1] = (ExpectedType10)(359.75);
v_record26_2.field0.field1.field0[2] = (ExpectedType10)(-432.5);
v_record26_2.field1[0].field0 = (ExpectedType4)(UINT64_C(393599109));
v_record26_2.field1[1].field0 = (ExpectedType4)(UINT64_C(3748307637));
v_record26_2.field1[2].field0 = (ExpectedType4)(UINT64_C(3174977480));
v_record26_2.field1[3].field0 = (ExpectedType4)(UINT64_C(3532943746));
v_record26_2.field2.field0 = (ExpectedType11)(1021.5);
ExpectedType38 out_v_record26_2 = abi_h_record26(v_record26_2);
assert(v_record26_2.field0.field0.field0.field0 == out_v_record26_2.field0.field0.field0.field0);
assert(v_record26_2.field0.field0.field0.field1 == out_v_record26_2.field0.field0.field0.field1);
assert(v_record26_2.field0.field0.field0.field2 == out_v_record26_2.field0.field0.field0.field2);
assert(v_record26_2.field0.field0.field0.field3 == out_v_record26_2.field0.field0.field0.field3);
assert(v_record26_2.field0.field0.field1 == out_v_record26_2.field0.field0.field1);
assert(v_record26_2.field0.field0.field2[0].field0 == out_v_record26_2.field0.field0.field2[0].field0);
assert(v_record26_2.field0.field0.field2[0].field1 == out_v_record26_2.field0.field0.field2[0].field1);
assert(v_record26_2.field0.field0.field2[0].field2 == out_v_record26_2.field0.field0.field2[0].field2);
assert(v_record26_2.field0.field0.field2[0].field3 == out_v_record26_2.field0.field0.field2[0].field3);
assert(v_record26_2.field0.field1.field0[0] == out_v_record26_2.field0.field1.field0[0]);
assert(v_record26_2.field0.field1.field0[1] == out_v_record26_2.field0.field1.field0[1]);
assert(v_record26_2.field0.field1.field0[2] == out_v_record26_2.field0.field1.field0[2]);
assert(v_record26_2.field1[0].field0 == out_v_record26_2.field1[0].field0);
assert(v_record26_2.field1[1].field0 == out_v_record26_2.field1[1].field0);
assert(v_record26_2.field1[2].field0 == out_v_record26_2.field1[2].field0);
assert(v_record26_2.field1[3].field0 == out_v_record26_2.field1[3].field0);
assert(v_record26_2.field2.field0 == out_v_record26_2.field2.field0);
}
{
ExpectedType39 v_record27_0 = {0};
v_record27_0.field0 = (ExpectedType9)((-INT64_C(57399522)));
v_record27_0.field1.field0 = (ExpectedType0)(UINT64_C(114));
v_record27_0.field1.field1 = (ExpectedType6)(UINT64_C(1925283582112648945));
v_record27_0.field2.field0 = (ExpectedType4)(UINT64_C(106537997));
v_record27_0.field2.field1[0] = (ExpectedType3)((-INT64_C(2810)));
v_record27_0.field2.field1[1] = (ExpectedType3)(INT64_C(27276));
v_record27_0.field2.field1[2] = (ExpectedType3)((-INT64_C(20677)));
v_record27_0.field2.field1[3] = (ExpectedType3)(INT64_C(18545));
v_record27_0.field2.field2 = (ExpectedType0)(UINT64_C(232));
v_record27_0.field2.field3 = (ExpectedType3)(INT64_C(20907));
ExpectedType39 out_v_record27_0 = abi_h_record27(v_record27_0);
assert(v_record27_0.field0 == out_v_record27_0.field0);
assert(v_record27_0.field1.field0 == out_v_record27_0.field1.field0);
assert(v_record27_0.field1.field1 == out_v_record27_0.field1.field1);
assert(v_record27_0.field2.field0 == out_v_record27_0.field2.field0);
assert(v_record27_0.field2.field1[0] == out_v_record27_0.field2.field1[0]);
assert(v_record27_0.field2.field1[1] == out_v_record27_0.field2.field1[1]);
assert(v_record27_0.field2.field1[2] == out_v_record27_0.field2.field1[2]);
assert(v_record27_0.field2.field1[3] == out_v_record27_0.field2.field1[3]);
assert(v_record27_0.field2.field2 == out_v_record27_0.field2.field2);
assert(v_record27_0.field2.field3 == out_v_record27_0.field2.field3);
}
{
ExpectedType39 v_record27_1 = {0};
v_record27_1.field0 = (ExpectedType9)(INT64_C(1646921127));
v_record27_1.field1.field0 = (ExpectedType0)(UINT64_C(35));
v_record27_1.field1.field1 = (ExpectedType6)(UINT64_C(1772409511694881300));
v_record27_1.field2.field0 = (ExpectedType4)(UINT64_C(3859423256));
v_record27_1.field2.field1[0] = (ExpectedType3)(INT64_C(26988));
v_record27_1.field2.field1[1] = (ExpectedType3)(INT64_C(7837));
v_record27_1.field2.field1[2] = (ExpectedType3)(INT64_C(15424));
v_record27_1.field2.field1[3] = (ExpectedType3)((-INT64_C(18300)));
v_record27_1.field2.field2 = (ExpectedType0)(UINT64_C(25));
v_record27_1.field2.field3 = (ExpectedType3)((-INT64_C(9347)));
ExpectedType39 out_v_record27_1 = abi_h_record27(v_record27_1);
assert(v_record27_1.field0 == out_v_record27_1.field0);
assert(v_record27_1.field1.field0 == out_v_record27_1.field1.field0);
assert(v_record27_1.field1.field1 == out_v_record27_1.field1.field1);
assert(v_record27_1.field2.field0 == out_v_record27_1.field2.field0);
assert(v_record27_1.field2.field1[0] == out_v_record27_1.field2.field1[0]);
assert(v_record27_1.field2.field1[1] == out_v_record27_1.field2.field1[1]);
assert(v_record27_1.field2.field1[2] == out_v_record27_1.field2.field1[2]);
assert(v_record27_1.field2.field1[3] == out_v_record27_1.field2.field1[3]);
assert(v_record27_1.field2.field2 == out_v_record27_1.field2.field2);
assert(v_record27_1.field2.field3 == out_v_record27_1.field2.field3);
}
{
ExpectedType39 v_record27_2 = {0};
v_record27_2.field0 = (ExpectedType9)((-INT64_C(1194181721)));
v_record27_2.field1.field0 = (ExpectedType0)(UINT64_C(201));
v_record27_2.field1.field1 = (ExpectedType6)(UINT64_C(18139384584958540908));
v_record27_2.field2.field0 = (ExpectedType4)(UINT64_C(946359327));
v_record27_2.field2.field1[0] = (ExpectedType3)(INT64_C(11379));
v_record27_2.field2.field1[1] = (ExpectedType3)(INT64_C(18058));
v_record27_2.field2.field1[2] = (ExpectedType3)((-INT64_C(23169)));
v_record27_2.field2.field1[3] = (ExpectedType3)(INT64_C(5043));
v_record27_2.field2.field2 = (ExpectedType0)(UINT64_C(131));
v_record27_2.field2.field3 = (ExpectedType3)((-INT64_C(12528)));
ExpectedType39 out_v_record27_2 = abi_h_record27(v_record27_2);
assert(v_record27_2.field0 == out_v_record27_2.field0);
assert(v_record27_2.field1.field0 == out_v_record27_2.field1.field0);
assert(v_record27_2.field1.field1 == out_v_record27_2.field1.field1);
assert(v_record27_2.field2.field0 == out_v_record27_2.field2.field0);
assert(v_record27_2.field2.field1[0] == out_v_record27_2.field2.field1[0]);
assert(v_record27_2.field2.field1[1] == out_v_record27_2.field2.field1[1]);
assert(v_record27_2.field2.field1[2] == out_v_record27_2.field2.field1[2]);
assert(v_record27_2.field2.field1[3] == out_v_record27_2.field2.field1[3]);
assert(v_record27_2.field2.field2 == out_v_record27_2.field2.field2);
assert(v_record27_2.field2.field3 == out_v_record27_2.field2.field3);
}
{
ExpectedType40 v_record28_0 = {0};
v_record28_0.field0 = (ExpectedType9)(INT64_C(123814822));
v_record28_0.field1.field0[0] = (ExpectedType5)((-INT64_C(1454088633)));
v_record28_0.field1.field0[1] = (ExpectedType5)((-INT64_C(1919176985)));
v_record28_0.field1.field0[2] = (ExpectedType5)(INT64_C(1268276568));
v_record28_0.field2.field0[0].field0[0] = (ExpectedType10)(-869.25);
v_record28_0.field2.field0[0].field0[1] = (ExpectedType10)(197.5);
v_record28_0.field2.field0[0].field0[2] = (ExpectedType10)(1008.5);
v_record28_0.field2.field0[1].field0[0] = (ExpectedType10)(928.25);
v_record28_0.field2.field0[1].field0[1] = (ExpectedType10)(-371.25);
v_record28_0.field2.field0[1].field0[2] = (ExpectedType10)(-97.25);
v_record28_0.field2.field0[2].field0[0] = (ExpectedType10)(355.25);
v_record28_0.field2.field0[2].field0[1] = (ExpectedType10)(-768.75);
v_record28_0.field2.field0[2].field0[2] = (ExpectedType10)(675.0);
v_record28_0.field3 = (ExpectedType9)(INT64_C(1565563051));
ExpectedType40 out_v_record28_0 = abi_h_record28(v_record28_0);
assert(v_record28_0.field0 == out_v_record28_0.field0);
assert(v_record28_0.field1.field0[0] == out_v_record28_0.field1.field0[0]);
assert(v_record28_0.field1.field0[1] == out_v_record28_0.field1.field0[1]);
assert(v_record28_0.field1.field0[2] == out_v_record28_0.field1.field0[2]);
assert(v_record28_0.field2.field0[0].field0[0] == out_v_record28_0.field2.field0[0].field0[0]);
assert(v_record28_0.field2.field0[0].field0[1] == out_v_record28_0.field2.field0[0].field0[1]);
assert(v_record28_0.field2.field0[0].field0[2] == out_v_record28_0.field2.field0[0].field0[2]);
assert(v_record28_0.field2.field0[1].field0[0] == out_v_record28_0.field2.field0[1].field0[0]);
assert(v_record28_0.field2.field0[1].field0[1] == out_v_record28_0.field2.field0[1].field0[1]);
assert(v_record28_0.field2.field0[1].field0[2] == out_v_record28_0.field2.field0[1].field0[2]);
assert(v_record28_0.field2.field0[2].field0[0] == out_v_record28_0.field2.field0[2].field0[0]);
assert(v_record28_0.field2.field0[2].field0[1] == out_v_record28_0.field2.field0[2].field0[1]);
assert(v_record28_0.field2.field0[2].field0[2] == out_v_record28_0.field2.field0[2].field0[2]);
assert(v_record28_0.field3 == out_v_record28_0.field3);
}
{
ExpectedType40 v_record28_1 = {0};
v_record28_1.field0 = (ExpectedType9)((-INT64_C(1124808681)));
v_record28_1.field1.field0[0] = (ExpectedType5)(INT64_C(137248531));
v_record28_1.field1.field0[1] = (ExpectedType5)(INT64_C(598717438));
v_record28_1.field1.field0[2] = (ExpectedType5)(INT64_C(1525536303));
v_record28_1.field2.field0[0].field0[0] = (ExpectedType10)(422.5);
v_record28_1.field2.field0[0].field0[1] = (ExpectedType10)(874.75);
v_record28_1.field2.field0[0].field0[2] = (ExpectedType10)(360.75);
v_record28_1.field2.field0[1].field0[0] = (ExpectedType10)(-403.0);
v_record28_1.field2.field0[1].field0[1] = (ExpectedType10)(659.25);
v_record28_1.field2.field0[1].field0[2] = (ExpectedType10)(-359.25);
v_record28_1.field2.field0[2].field0[0] = (ExpectedType10)(43.25);
v_record28_1.field2.field0[2].field0[1] = (ExpectedType10)(-171.0);
v_record28_1.field2.field0[2].field0[2] = (ExpectedType10)(-350.5);
v_record28_1.field3 = (ExpectedType9)((-INT64_C(1459335439)));
ExpectedType40 out_v_record28_1 = abi_h_record28(v_record28_1);
assert(v_record28_1.field0 == out_v_record28_1.field0);
assert(v_record28_1.field1.field0[0] == out_v_record28_1.field1.field0[0]);
assert(v_record28_1.field1.field0[1] == out_v_record28_1.field1.field0[1]);
assert(v_record28_1.field1.field0[2] == out_v_record28_1.field1.field0[2]);
assert(v_record28_1.field2.field0[0].field0[0] == out_v_record28_1.field2.field0[0].field0[0]);
assert(v_record28_1.field2.field0[0].field0[1] == out_v_record28_1.field2.field0[0].field0[1]);
assert(v_record28_1.field2.field0[0].field0[2] == out_v_record28_1.field2.field0[0].field0[2]);
assert(v_record28_1.field2.field0[1].field0[0] == out_v_record28_1.field2.field0[1].field0[0]);
assert(v_record28_1.field2.field0[1].field0[1] == out_v_record28_1.field2.field0[1].field0[1]);
assert(v_record28_1.field2.field0[1].field0[2] == out_v_record28_1.field2.field0[1].field0[2]);
assert(v_record28_1.field2.field0[2].field0[0] == out_v_record28_1.field2.field0[2].field0[0]);
assert(v_record28_1.field2.field0[2].field0[1] == out_v_record28_1.field2.field0[2].field0[1]);
assert(v_record28_1.field2.field0[2].field0[2] == out_v_record28_1.field2.field0[2].field0[2]);
assert(v_record28_1.field3 == out_v_record28_1.field3);
}
{
ExpectedType40 v_record28_2 = {0};
v_record28_2.field0 = (ExpectedType9)(INT64_C(1674424804));
v_record28_2.field1.field0[0] = (ExpectedType5)(INT64_C(510610957));
v_record28_2.field1.field0[1] = (ExpectedType5)(INT64_C(197695723));
v_record28_2.field1.field0[2] = (ExpectedType5)(INT64_C(1827005685));
v_record28_2.field2.field0[0].field0[0] = (ExpectedType10)(223.5);
v_record28_2.field2.field0[0].field0[1] = (ExpectedType10)(515.75);
v_record28_2.field2.field0[0].field0[2] = (ExpectedType10)(828.25);
v_record28_2.field2.field0[1].field0[0] = (ExpectedType10)(-974.0);
v_record28_2.field2.field0[1].field0[1] = (ExpectedType10)(-850.25);
v_record28_2.field2.field0[1].field0[2] = (ExpectedType10)(383.5);
v_record28_2.field2.field0[2].field0[0] = (ExpectedType10)(-465.25);
v_record28_2.field2.field0[2].field0[1] = (ExpectedType10)(722.25);
v_record28_2.field2.field0[2].field0[2] = (ExpectedType10)(328.25);
v_record28_2.field3 = (ExpectedType9)(INT64_C(1472086180));
ExpectedType40 out_v_record28_2 = abi_h_record28(v_record28_2);
assert(v_record28_2.field0 == out_v_record28_2.field0);
assert(v_record28_2.field1.field0[0] == out_v_record28_2.field1.field0[0]);
assert(v_record28_2.field1.field0[1] == out_v_record28_2.field1.field0[1]);
assert(v_record28_2.field1.field0[2] == out_v_record28_2.field1.field0[2]);
assert(v_record28_2.field2.field0[0].field0[0] == out_v_record28_2.field2.field0[0].field0[0]);
assert(v_record28_2.field2.field0[0].field0[1] == out_v_record28_2.field2.field0[0].field0[1]);
assert(v_record28_2.field2.field0[0].field0[2] == out_v_record28_2.field2.field0[0].field0[2]);
assert(v_record28_2.field2.field0[1].field0[0] == out_v_record28_2.field2.field0[1].field0[0]);
assert(v_record28_2.field2.field0[1].field0[1] == out_v_record28_2.field2.field0[1].field0[1]);
assert(v_record28_2.field2.field0[1].field0[2] == out_v_record28_2.field2.field0[1].field0[2]);
assert(v_record28_2.field2.field0[2].field0[0] == out_v_record28_2.field2.field0[2].field0[0]);
assert(v_record28_2.field2.field0[2].field0[1] == out_v_record28_2.field2.field0[2].field0[1]);
assert(v_record28_2.field2.field0[2].field0[2] == out_v_record28_2.field2.field0[2].field0[2]);
assert(v_record28_2.field3 == out_v_record28_2.field3);
}
{
ExpectedType41 v_record29_0 = {0};
v_record29_0.field0[0][0] = (ExpectedType4)(UINT64_C(836745564));
v_record29_0.field0[1][0] = (ExpectedType4)(UINT64_C(2665549027));
ExpectedType41 out_v_record29_0 = abi_h_record29(v_record29_0);
assert(v_record29_0.field0[0][0] == out_v_record29_0.field0[0][0]);
assert(v_record29_0.field0[1][0] == out_v_record29_0.field0[1][0]);
}
{
ExpectedType41 v_record29_1 = {0};
v_record29_1.field0[0][0] = (ExpectedType4)(UINT64_C(3203510939));
v_record29_1.field0[1][0] = (ExpectedType4)(UINT64_C(66661471));
ExpectedType41 out_v_record29_1 = abi_h_record29(v_record29_1);
assert(v_record29_1.field0[0][0] == out_v_record29_1.field0[0][0]);
assert(v_record29_1.field0[1][0] == out_v_record29_1.field0[1][0]);
}
{
ExpectedType41 v_record29_2 = {0};
v_record29_2.field0[0][0] = (ExpectedType4)(UINT64_C(3581787238));
v_record29_2.field0[1][0] = (ExpectedType4)(UINT64_C(3725132767));
ExpectedType41 out_v_record29_2 = abi_h_record29(v_record29_2);
assert(v_record29_2.field0[0][0] == out_v_record29_2.field0[0][0]);
assert(v_record29_2.field0[1][0] == out_v_record29_2.field0[1][0]);
}
{
ExpectedType42 v_record30_0 = {0};
v_record30_0.field0.field0.field0 = (ExpectedType4)(UINT64_C(3611010405));
v_record30_0.field1.field0 = (ExpectedType3)(INT64_C(17497));
v_record30_0.field2.field0[0].field0[0] = (ExpectedType10)(-627.75);
v_record30_0.field2.field0[0].field0[1] = (ExpectedType10)(-993.75);
v_record30_0.field2.field0[0].field0[2] = (ExpectedType10)(-382.5);
v_record30_0.field2.field0[1].field0[0] = (ExpectedType10)(-795.5);
v_record30_0.field2.field0[1].field0[1] = (ExpectedType10)(566.5);
v_record30_0.field2.field0[1].field0[2] = (ExpectedType10)(345.25);
v_record30_0.field2.field0[2].field0[0] = (ExpectedType10)(40.75);
v_record30_0.field2.field0[2].field0[1] = (ExpectedType10)(-426.5);
v_record30_0.field2.field0[2].field0[2] = (ExpectedType10)(-394.75);
v_record30_0.field3 = (ExpectedType11)(810.0);
v_record30_0.field4[0].field0.field0 = (ExpectedType6)(UINT64_C(70748915561133321));
v_record30_0.field4[0].field0.field1 = (ExpectedType3)(INT64_C(24289));
v_record30_0.field4[0].field0.field2 = (ExpectedType9)(INT64_C(166774975));
v_record30_0.field4[0].field0.field3 = (ExpectedType1)(INT64_C(111));
v_record30_0.field4[0].field1 = (ExpectedType8)(UINT64_C(3608100533));
v_record30_0.field4[0].field2[0].field0 = (ExpectedType6)(UINT64_C(12677189712729208668));
v_record30_0.field4[0].field2[0].field1 = (ExpectedType3)((-INT64_C(24244)));
v_record30_0.field4[0].field2[0].field2 = (ExpectedType9)((-INT64_C(327406382)));
v_record30_0.field4[0].field2[0].field3 = (ExpectedType1)(INT64_C(125));
v_record30_0.field4[1].field0.field0 = (ExpectedType6)(UINT64_C(12319809642013546782));
v_record30_0.field4[1].field0.field1 = (ExpectedType3)(INT64_C(26485));
v_record30_0.field4[1].field0.field2 = (ExpectedType9)((-INT64_C(108434968)));
v_record30_0.field4[1].field0.field3 = (ExpectedType1)((-INT64_C(64)));
v_record30_0.field4[1].field1 = (ExpectedType8)(UINT64_C(295132586));
v_record30_0.field4[1].field2[0].field0 = (ExpectedType6)(UINT64_C(18055096970726856606));
v_record30_0.field4[1].field2[0].field1 = (ExpectedType3)(INT64_C(4832));
v_record30_0.field4[1].field2[0].field2 = (ExpectedType9)(INT64_C(549656165));
v_record30_0.field4[1].field2[0].field3 = (ExpectedType1)((-INT64_C(53)));
v_record30_0.field4[2].field0.field0 = (ExpectedType6)(UINT64_C(15942933127998685110));
v_record30_0.field4[2].field0.field1 = (ExpectedType3)(INT64_C(10879));
v_record30_0.field4[2].field0.field2 = (ExpectedType9)((-INT64_C(143193612)));
v_record30_0.field4[2].field0.field3 = (ExpectedType1)((-INT64_C(122)));
v_record30_0.field4[2].field1 = (ExpectedType8)(UINT64_C(2957902397));
v_record30_0.field4[2].field2[0].field0 = (ExpectedType6)(UINT64_C(15749886758130697092));
v_record30_0.field4[2].field2[0].field1 = (ExpectedType3)(INT64_C(23067));
v_record30_0.field4[2].field2[0].field2 = (ExpectedType9)((-INT64_C(1248340018)));
v_record30_0.field4[2].field2[0].field3 = (ExpectedType1)((-INT64_C(83)));
v_record30_0.field4[3].field0.field0 = (ExpectedType6)(UINT64_C(14653905129634699181));
v_record30_0.field4[3].field0.field1 = (ExpectedType3)((-INT64_C(14392)));
v_record30_0.field4[3].field0.field2 = (ExpectedType9)(INT64_C(2122399982));
v_record30_0.field4[3].field0.field3 = (ExpectedType1)((-INT64_C(80)));
v_record30_0.field4[3].field1 = (ExpectedType8)(UINT64_C(2675907043));
v_record30_0.field4[3].field2[0].field0 = (ExpectedType6)(UINT64_C(5969701878967204808));
v_record30_0.field4[3].field2[0].field1 = (ExpectedType3)(INT64_C(683));
v_record30_0.field4[3].field2[0].field2 = (ExpectedType9)(INT64_C(512906177));
v_record30_0.field4[3].field2[0].field3 = (ExpectedType1)((-INT64_C(56)));
ExpectedType42 out_v_record30_0 = abi_h_record30(v_record30_0);
assert(v_record30_0.field0.field0.field0 == out_v_record30_0.field0.field0.field0);
assert(v_record30_0.field1.field0 == out_v_record30_0.field1.field0);
assert(v_record30_0.field2.field0[0].field0[0] == out_v_record30_0.field2.field0[0].field0[0]);
assert(v_record30_0.field2.field0[0].field0[1] == out_v_record30_0.field2.field0[0].field0[1]);
assert(v_record30_0.field2.field0[0].field0[2] == out_v_record30_0.field2.field0[0].field0[2]);
assert(v_record30_0.field2.field0[1].field0[0] == out_v_record30_0.field2.field0[1].field0[0]);
assert(v_record30_0.field2.field0[1].field0[1] == out_v_record30_0.field2.field0[1].field0[1]);
assert(v_record30_0.field2.field0[1].field0[2] == out_v_record30_0.field2.field0[1].field0[2]);
assert(v_record30_0.field2.field0[2].field0[0] == out_v_record30_0.field2.field0[2].field0[0]);
assert(v_record30_0.field2.field0[2].field0[1] == out_v_record30_0.field2.field0[2].field0[1]);
assert(v_record30_0.field2.field0[2].field0[2] == out_v_record30_0.field2.field0[2].field0[2]);
assert(v_record30_0.field3 == out_v_record30_0.field3);
assert(v_record30_0.field4[0].field0.field0 == out_v_record30_0.field4[0].field0.field0);
assert(v_record30_0.field4[0].field0.field1 == out_v_record30_0.field4[0].field0.field1);
assert(v_record30_0.field4[0].field0.field2 == out_v_record30_0.field4[0].field0.field2);
assert(v_record30_0.field4[0].field0.field3 == out_v_record30_0.field4[0].field0.field3);
assert(v_record30_0.field4[0].field1 == out_v_record30_0.field4[0].field1);
assert(v_record30_0.field4[0].field2[0].field0 == out_v_record30_0.field4[0].field2[0].field0);
assert(v_record30_0.field4[0].field2[0].field1 == out_v_record30_0.field4[0].field2[0].field1);
assert(v_record30_0.field4[0].field2[0].field2 == out_v_record30_0.field4[0].field2[0].field2);
assert(v_record30_0.field4[0].field2[0].field3 == out_v_record30_0.field4[0].field2[0].field3);
assert(v_record30_0.field4[1].field0.field0 == out_v_record30_0.field4[1].field0.field0);
assert(v_record30_0.field4[1].field0.field1 == out_v_record30_0.field4[1].field0.field1);
assert(v_record30_0.field4[1].field0.field2 == out_v_record30_0.field4[1].field0.field2);
assert(v_record30_0.field4[1].field0.field3 == out_v_record30_0.field4[1].field0.field3);
assert(v_record30_0.field4[1].field1 == out_v_record30_0.field4[1].field1);
assert(v_record30_0.field4[1].field2[0].field0 == out_v_record30_0.field4[1].field2[0].field0);
assert(v_record30_0.field4[1].field2[0].field1 == out_v_record30_0.field4[1].field2[0].field1);
assert(v_record30_0.field4[1].field2[0].field2 == out_v_record30_0.field4[1].field2[0].field2);
assert(v_record30_0.field4[1].field2[0].field3 == out_v_record30_0.field4[1].field2[0].field3);
assert(v_record30_0.field4[2].field0.field0 == out_v_record30_0.field4[2].field0.field0);
assert(v_record30_0.field4[2].field0.field1 == out_v_record30_0.field4[2].field0.field1);
assert(v_record30_0.field4[2].field0.field2 == out_v_record30_0.field4[2].field0.field2);
assert(v_record30_0.field4[2].field0.field3 == out_v_record30_0.field4[2].field0.field3);
assert(v_record30_0.field4[2].field1 == out_v_record30_0.field4[2].field1);
assert(v_record30_0.field4[2].field2[0].field0 == out_v_record30_0.field4[2].field2[0].field0);
assert(v_record30_0.field4[2].field2[0].field1 == out_v_record30_0.field4[2].field2[0].field1);
assert(v_record30_0.field4[2].field2[0].field2 == out_v_record30_0.field4[2].field2[0].field2);
assert(v_record30_0.field4[2].field2[0].field3 == out_v_record30_0.field4[2].field2[0].field3);
assert(v_record30_0.field4[3].field0.field0 == out_v_record30_0.field4[3].field0.field0);
assert(v_record30_0.field4[3].field0.field1 == out_v_record30_0.field4[3].field0.field1);
assert(v_record30_0.field4[3].field0.field2 == out_v_record30_0.field4[3].field0.field2);
assert(v_record30_0.field4[3].field0.field3 == out_v_record30_0.field4[3].field0.field3);
assert(v_record30_0.field4[3].field1 == out_v_record30_0.field4[3].field1);
assert(v_record30_0.field4[3].field2[0].field0 == out_v_record30_0.field4[3].field2[0].field0);
assert(v_record30_0.field4[3].field2[0].field1 == out_v_record30_0.field4[3].field2[0].field1);
assert(v_record30_0.field4[3].field2[0].field2 == out_v_record30_0.field4[3].field2[0].field2);
assert(v_record30_0.field4[3].field2[0].field3 == out_v_record30_0.field4[3].field2[0].field3);
}
{
ExpectedType42 v_record30_1 = {0};
v_record30_1.field0.field0.field0 = (ExpectedType4)(UINT64_C(554934822));
v_record30_1.field1.field0 = (ExpectedType3)((-INT64_C(4764)));
v_record30_1.field2.field0[0].field0[0] = (ExpectedType10)(-449.25);
v_record30_1.field2.field0[0].field0[1] = (ExpectedType10)(-144.75);
v_record30_1.field2.field0[0].field0[2] = (ExpectedType10)(336.5);
v_record30_1.field2.field0[1].field0[0] = (ExpectedType10)(-444.75);
v_record30_1.field2.field0[1].field0[1] = (ExpectedType10)(868.75);
v_record30_1.field2.field0[1].field0[2] = (ExpectedType10)(258.0);
v_record30_1.field2.field0[2].field0[0] = (ExpectedType10)(260.0);
v_record30_1.field2.field0[2].field0[1] = (ExpectedType10)(253.5);
v_record30_1.field2.field0[2].field0[2] = (ExpectedType10)(-557.5);
v_record30_1.field3 = (ExpectedType11)(-171.5);
v_record30_1.field4[0].field0.field0 = (ExpectedType6)(UINT64_C(15358866348850578122));
v_record30_1.field4[0].field0.field1 = (ExpectedType3)(INT64_C(31961));
v_record30_1.field4[0].field0.field2 = (ExpectedType9)(INT64_C(1762957248));
v_record30_1.field4[0].field0.field3 = (ExpectedType1)((-INT64_C(28)));
v_record30_1.field4[0].field1 = (ExpectedType8)(UINT64_C(679085071));
v_record30_1.field4[0].field2[0].field0 = (ExpectedType6)(UINT64_C(9870529313412102741));
v_record30_1.field4[0].field2[0].field1 = (ExpectedType3)((-INT64_C(7286)));
v_record30_1.field4[0].field2[0].field2 = (ExpectedType9)((-INT64_C(1980126248)));
v_record30_1.field4[0].field2[0].field3 = (ExpectedType1)((-INT64_C(114)));
v_record30_1.field4[1].field0.field0 = (ExpectedType6)(UINT64_C(17889413320583338353));
v_record30_1.field4[1].field0.field1 = (ExpectedType3)(INT64_C(396));
v_record30_1.field4[1].field0.field2 = (ExpectedType9)((-INT64_C(928714315)));
v_record30_1.field4[1].field0.field3 = (ExpectedType1)(INT64_C(44));
v_record30_1.field4[1].field1 = (ExpectedType8)(UINT64_C(3199470343));
v_record30_1.field4[1].field2[0].field0 = (ExpectedType6)(UINT64_C(11414769531106967234));
v_record30_1.field4[1].field2[0].field1 = (ExpectedType3)(INT64_C(26108));
v_record30_1.field4[1].field2[0].field2 = (ExpectedType9)((-INT64_C(168629960)));
v_record30_1.field4[1].field2[0].field3 = (ExpectedType1)(INT64_C(9));
v_record30_1.field4[2].field0.field0 = (ExpectedType6)(UINT64_C(2415492791465495372));
v_record30_1.field4[2].field0.field1 = (ExpectedType3)(INT64_C(16275));
v_record30_1.field4[2].field0.field2 = (ExpectedType9)(INT64_C(1225822680));
v_record30_1.field4[2].field0.field3 = (ExpectedType1)((-INT64_C(33)));
v_record30_1.field4[2].field1 = (ExpectedType8)(UINT64_C(300743881));
v_record30_1.field4[2].field2[0].field0 = (ExpectedType6)(UINT64_C(16327644467112926524));
v_record30_1.field4[2].field2[0].field1 = (ExpectedType3)(INT64_C(17372));
v_record30_1.field4[2].field2[0].field2 = (ExpectedType9)(INT64_C(1857184963));
v_record30_1.field4[2].field2[0].field3 = (ExpectedType1)((-INT64_C(33)));
v_record30_1.field4[3].field0.field0 = (ExpectedType6)(UINT64_C(1164456462248664543));
v_record30_1.field4[3].field0.field1 = (ExpectedType3)((-INT64_C(3581)));
v_record30_1.field4[3].field0.field2 = (ExpectedType9)(INT64_C(144193095));
v_record30_1.field4[3].field0.field3 = (ExpectedType1)((-INT64_C(33)));
v_record30_1.field4[3].field1 = (ExpectedType8)(UINT64_C(2991925805));
v_record30_1.field4[3].field2[0].field0 = (ExpectedType6)(UINT64_C(17539362713316534262));
v_record30_1.field4[3].field2[0].field1 = (ExpectedType3)(INT64_C(29889));
v_record30_1.field4[3].field2[0].field2 = (ExpectedType9)(INT64_C(243934535));
v_record30_1.field4[3].field2[0].field3 = (ExpectedType1)(INT64_C(84));
ExpectedType42 out_v_record30_1 = abi_h_record30(v_record30_1);
assert(v_record30_1.field0.field0.field0 == out_v_record30_1.field0.field0.field0);
assert(v_record30_1.field1.field0 == out_v_record30_1.field1.field0);
assert(v_record30_1.field2.field0[0].field0[0] == out_v_record30_1.field2.field0[0].field0[0]);
assert(v_record30_1.field2.field0[0].field0[1] == out_v_record30_1.field2.field0[0].field0[1]);
assert(v_record30_1.field2.field0[0].field0[2] == out_v_record30_1.field2.field0[0].field0[2]);
assert(v_record30_1.field2.field0[1].field0[0] == out_v_record30_1.field2.field0[1].field0[0]);
assert(v_record30_1.field2.field0[1].field0[1] == out_v_record30_1.field2.field0[1].field0[1]);
assert(v_record30_1.field2.field0[1].field0[2] == out_v_record30_1.field2.field0[1].field0[2]);
assert(v_record30_1.field2.field0[2].field0[0] == out_v_record30_1.field2.field0[2].field0[0]);
assert(v_record30_1.field2.field0[2].field0[1] == out_v_record30_1.field2.field0[2].field0[1]);
assert(v_record30_1.field2.field0[2].field0[2] == out_v_record30_1.field2.field0[2].field0[2]);
assert(v_record30_1.field3 == out_v_record30_1.field3);
assert(v_record30_1.field4[0].field0.field0 == out_v_record30_1.field4[0].field0.field0);
assert(v_record30_1.field4[0].field0.field1 == out_v_record30_1.field4[0].field0.field1);
assert(v_record30_1.field4[0].field0.field2 == out_v_record30_1.field4[0].field0.field2);
assert(v_record30_1.field4[0].field0.field3 == out_v_record30_1.field4[0].field0.field3);
assert(v_record30_1.field4[0].field1 == out_v_record30_1.field4[0].field1);
assert(v_record30_1.field4[0].field2[0].field0 == out_v_record30_1.field4[0].field2[0].field0);
assert(v_record30_1.field4[0].field2[0].field1 == out_v_record30_1.field4[0].field2[0].field1);
assert(v_record30_1.field4[0].field2[0].field2 == out_v_record30_1.field4[0].field2[0].field2);
assert(v_record30_1.field4[0].field2[0].field3 == out_v_record30_1.field4[0].field2[0].field3);
assert(v_record30_1.field4[1].field0.field0 == out_v_record30_1.field4[1].field0.field0);
assert(v_record30_1.field4[1].field0.field1 == out_v_record30_1.field4[1].field0.field1);
assert(v_record30_1.field4[1].field0.field2 == out_v_record30_1.field4[1].field0.field2);
assert(v_record30_1.field4[1].field0.field3 == out_v_record30_1.field4[1].field0.field3);
assert(v_record30_1.field4[1].field1 == out_v_record30_1.field4[1].field1);
assert(v_record30_1.field4[1].field2[0].field0 == out_v_record30_1.field4[1].field2[0].field0);
assert(v_record30_1.field4[1].field2[0].field1 == out_v_record30_1.field4[1].field2[0].field1);
assert(v_record30_1.field4[1].field2[0].field2 == out_v_record30_1.field4[1].field2[0].field2);
assert(v_record30_1.field4[1].field2[0].field3 == out_v_record30_1.field4[1].field2[0].field3);
assert(v_record30_1.field4[2].field0.field0 == out_v_record30_1.field4[2].field0.field0);
assert(v_record30_1.field4[2].field0.field1 == out_v_record30_1.field4[2].field0.field1);
assert(v_record30_1.field4[2].field0.field2 == out_v_record30_1.field4[2].field0.field2);
assert(v_record30_1.field4[2].field0.field3 == out_v_record30_1.field4[2].field0.field3);
assert(v_record30_1.field4[2].field1 == out_v_record30_1.field4[2].field1);
assert(v_record30_1.field4[2].field2[0].field0 == out_v_record30_1.field4[2].field2[0].field0);
assert(v_record30_1.field4[2].field2[0].field1 == out_v_record30_1.field4[2].field2[0].field1);
assert(v_record30_1.field4[2].field2[0].field2 == out_v_record30_1.field4[2].field2[0].field2);
assert(v_record30_1.field4[2].field2[0].field3 == out_v_record30_1.field4[2].field2[0].field3);
assert(v_record30_1.field4[3].field0.field0 == out_v_record30_1.field4[3].field0.field0);
assert(v_record30_1.field4[3].field0.field1 == out_v_record30_1.field4[3].field0.field1);
assert(v_record30_1.field4[3].field0.field2 == out_v_record30_1.field4[3].field0.field2);
assert(v_record30_1.field4[3].field0.field3 == out_v_record30_1.field4[3].field0.field3);
assert(v_record30_1.field4[3].field1 == out_v_record30_1.field4[3].field1);
assert(v_record30_1.field4[3].field2[0].field0 == out_v_record30_1.field4[3].field2[0].field0);
assert(v_record30_1.field4[3].field2[0].field1 == out_v_record30_1.field4[3].field2[0].field1);
assert(v_record30_1.field4[3].field2[0].field2 == out_v_record30_1.field4[3].field2[0].field2);
assert(v_record30_1.field4[3].field2[0].field3 == out_v_record30_1.field4[3].field2[0].field3);
}
{
ExpectedType42 v_record30_2 = {0};
v_record30_2.field0.field0.field0 = (ExpectedType4)(UINT64_C(220745509));
v_record30_2.field1.field0 = (ExpectedType3)(INT64_C(4411));
v_record30_2.field2.field0[0].field0[0] = (ExpectedType10)(116.75);
v_record30_2.field2.field0[0].field0[1] = (ExpectedType10)(-268.75);
v_record30_2.field2.field0[0].field0[2] = (ExpectedType10)(-5.5);
v_record30_2.field2.field0[1].field0[0] = (ExpectedType10)(-722.5);
v_record30_2.field2.field0[1].field0[1] = (ExpectedType10)(432.0);
v_record30_2.field2.field0[1].field0[2] = (ExpectedType10)(-564.5);
v_record30_2.field2.field0[2].field0[0] = (ExpectedType10)(351.0);
v_record30_2.field2.field0[2].field0[1] = (ExpectedType10)(-347.25);
v_record30_2.field2.field0[2].field0[2] = (ExpectedType10)(-931.25);
v_record30_2.field3 = (ExpectedType11)(-773.5);
v_record30_2.field4[0].field0.field0 = (ExpectedType6)(UINT64_C(12359936747727575909));
v_record30_2.field4[0].field0.field1 = (ExpectedType3)((-INT64_C(6818)));
v_record30_2.field4[0].field0.field2 = (ExpectedType9)((-INT64_C(802017401)));
v_record30_2.field4[0].field0.field3 = (ExpectedType1)(INT64_C(37));
v_record30_2.field4[0].field1 = (ExpectedType8)(UINT64_C(1016713326));
v_record30_2.field4[0].field2[0].field0 = (ExpectedType6)(UINT64_C(9838521367306020382));
v_record30_2.field4[0].field2[0].field1 = (ExpectedType3)(INT64_C(19812));
v_record30_2.field4[0].field2[0].field2 = (ExpectedType9)(INT64_C(436938388));
v_record30_2.field4[0].field2[0].field3 = (ExpectedType1)((-INT64_C(96)));
v_record30_2.field4[1].field0.field0 = (ExpectedType6)(UINT64_C(11327287658816327722));
v_record30_2.field4[1].field0.field1 = (ExpectedType3)(INT64_C(22687));
v_record30_2.field4[1].field0.field2 = (ExpectedType9)(INT64_C(517939365));
v_record30_2.field4[1].field0.field3 = (ExpectedType1)(INT64_C(103));
v_record30_2.field4[1].field1 = (ExpectedType8)(UINT64_C(745896424));
v_record30_2.field4[1].field2[0].field0 = (ExpectedType6)(UINT64_C(14382709878521981469));
v_record30_2.field4[1].field2[0].field1 = (ExpectedType3)(INT64_C(1205));
v_record30_2.field4[1].field2[0].field2 = (ExpectedType9)((-INT64_C(1709609630)));
v_record30_2.field4[1].field2[0].field3 = (ExpectedType1)((-INT64_C(30)));
v_record30_2.field4[2].field0.field0 = (ExpectedType6)(UINT64_C(1275735368452621));
v_record30_2.field4[2].field0.field1 = (ExpectedType3)((-INT64_C(21296)));
v_record30_2.field4[2].field0.field2 = (ExpectedType9)(INT64_C(2012139731));
v_record30_2.field4[2].field0.field3 = (ExpectedType1)((-INT64_C(105)));
v_record30_2.field4[2].field1 = (ExpectedType8)(UINT64_C(2490349633));
v_record30_2.field4[2].field2[0].field0 = (ExpectedType6)(UINT64_C(6735688014225764519));
v_record30_2.field4[2].field2[0].field1 = (ExpectedType3)(INT64_C(2482));
v_record30_2.field4[2].field2[0].field2 = (ExpectedType9)((-INT64_C(759163346)));
v_record30_2.field4[2].field2[0].field3 = (ExpectedType1)(INT64_C(90));
v_record30_2.field4[3].field0.field0 = (ExpectedType6)(UINT64_C(16746226198060340015));
v_record30_2.field4[3].field0.field1 = (ExpectedType3)(INT64_C(5303));
v_record30_2.field4[3].field0.field2 = (ExpectedType9)(INT64_C(1964130671));
v_record30_2.field4[3].field0.field3 = (ExpectedType1)((-INT64_C(72)));
v_record30_2.field4[3].field1 = (ExpectedType8)(UINT64_C(1708342853));
v_record30_2.field4[3].field2[0].field0 = (ExpectedType6)(UINT64_C(18349983006853700935));
v_record30_2.field4[3].field2[0].field1 = (ExpectedType3)((-INT64_C(10120)));
v_record30_2.field4[3].field2[0].field2 = (ExpectedType9)(INT64_C(606444512));
v_record30_2.field4[3].field2[0].field3 = (ExpectedType1)(INT64_C(2));
ExpectedType42 out_v_record30_2 = abi_h_record30(v_record30_2);
assert(v_record30_2.field0.field0.field0 == out_v_record30_2.field0.field0.field0);
assert(v_record30_2.field1.field0 == out_v_record30_2.field1.field0);
assert(v_record30_2.field2.field0[0].field0[0] == out_v_record30_2.field2.field0[0].field0[0]);
assert(v_record30_2.field2.field0[0].field0[1] == out_v_record30_2.field2.field0[0].field0[1]);
assert(v_record30_2.field2.field0[0].field0[2] == out_v_record30_2.field2.field0[0].field0[2]);
assert(v_record30_2.field2.field0[1].field0[0] == out_v_record30_2.field2.field0[1].field0[0]);
assert(v_record30_2.field2.field0[1].field0[1] == out_v_record30_2.field2.field0[1].field0[1]);
assert(v_record30_2.field2.field0[1].field0[2] == out_v_record30_2.field2.field0[1].field0[2]);
assert(v_record30_2.field2.field0[2].field0[0] == out_v_record30_2.field2.field0[2].field0[0]);
assert(v_record30_2.field2.field0[2].field0[1] == out_v_record30_2.field2.field0[2].field0[1]);
assert(v_record30_2.field2.field0[2].field0[2] == out_v_record30_2.field2.field0[2].field0[2]);
assert(v_record30_2.field3 == out_v_record30_2.field3);
assert(v_record30_2.field4[0].field0.field0 == out_v_record30_2.field4[0].field0.field0);
assert(v_record30_2.field4[0].field0.field1 == out_v_record30_2.field4[0].field0.field1);
assert(v_record30_2.field4[0].field0.field2 == out_v_record30_2.field4[0].field0.field2);
assert(v_record30_2.field4[0].field0.field3 == out_v_record30_2.field4[0].field0.field3);
assert(v_record30_2.field4[0].field1 == out_v_record30_2.field4[0].field1);
assert(v_record30_2.field4[0].field2[0].field0 == out_v_record30_2.field4[0].field2[0].field0);
assert(v_record30_2.field4[0].field2[0].field1 == out_v_record30_2.field4[0].field2[0].field1);
assert(v_record30_2.field4[0].field2[0].field2 == out_v_record30_2.field4[0].field2[0].field2);
assert(v_record30_2.field4[0].field2[0].field3 == out_v_record30_2.field4[0].field2[0].field3);
assert(v_record30_2.field4[1].field0.field0 == out_v_record30_2.field4[1].field0.field0);
assert(v_record30_2.field4[1].field0.field1 == out_v_record30_2.field4[1].field0.field1);
assert(v_record30_2.field4[1].field0.field2 == out_v_record30_2.field4[1].field0.field2);
assert(v_record30_2.field4[1].field0.field3 == out_v_record30_2.field4[1].field0.field3);
assert(v_record30_2.field4[1].field1 == out_v_record30_2.field4[1].field1);
assert(v_record30_2.field4[1].field2[0].field0 == out_v_record30_2.field4[1].field2[0].field0);
assert(v_record30_2.field4[1].field2[0].field1 == out_v_record30_2.field4[1].field2[0].field1);
assert(v_record30_2.field4[1].field2[0].field2 == out_v_record30_2.field4[1].field2[0].field2);
assert(v_record30_2.field4[1].field2[0].field3 == out_v_record30_2.field4[1].field2[0].field3);
assert(v_record30_2.field4[2].field0.field0 == out_v_record30_2.field4[2].field0.field0);
assert(v_record30_2.field4[2].field0.field1 == out_v_record30_2.field4[2].field0.field1);
assert(v_record30_2.field4[2].field0.field2 == out_v_record30_2.field4[2].field0.field2);
assert(v_record30_2.field4[2].field0.field3 == out_v_record30_2.field4[2].field0.field3);
assert(v_record30_2.field4[2].field1 == out_v_record30_2.field4[2].field1);
assert(v_record30_2.field4[2].field2[0].field0 == out_v_record30_2.field4[2].field2[0].field0);
assert(v_record30_2.field4[2].field2[0].field1 == out_v_record30_2.field4[2].field2[0].field1);
assert(v_record30_2.field4[2].field2[0].field2 == out_v_record30_2.field4[2].field2[0].field2);
assert(v_record30_2.field4[2].field2[0].field3 == out_v_record30_2.field4[2].field2[0].field3);
assert(v_record30_2.field4[3].field0.field0 == out_v_record30_2.field4[3].field0.field0);
assert(v_record30_2.field4[3].field0.field1 == out_v_record30_2.field4[3].field0.field1);
assert(v_record30_2.field4[3].field0.field2 == out_v_record30_2.field4[3].field0.field2);
assert(v_record30_2.field4[3].field0.field3 == out_v_record30_2.field4[3].field0.field3);
assert(v_record30_2.field4[3].field1 == out_v_record30_2.field4[3].field1);
assert(v_record30_2.field4[3].field2[0].field0 == out_v_record30_2.field4[3].field2[0].field0);
assert(v_record30_2.field4[3].field2[0].field1 == out_v_record30_2.field4[3].field2[0].field1);
assert(v_record30_2.field4[3].field2[0].field2 == out_v_record30_2.field4[3].field2[0].field2);
assert(v_record30_2.field4[3].field2[0].field3 == out_v_record30_2.field4[3].field2[0].field3);
}
{
ExpectedType43 v_record31_0 = {0};
v_record31_0.field0.field0[0].field0[0] = (ExpectedType10)(-809.5);
v_record31_0.field0.field0[0].field0[1] = (ExpectedType10)(-869.5);
v_record31_0.field0.field0[0].field0[2] = (ExpectedType10)(340.5);
v_record31_0.field0.field0[1].field0[0] = (ExpectedType10)(-192.75);
v_record31_0.field0.field0[1].field0[1] = (ExpectedType10)(-397.75);
v_record31_0.field0.field0[1].field0[2] = (ExpectedType10)(-368.5);
v_record31_0.field0.field0[2].field0[0] = (ExpectedType10)(328.5);
v_record31_0.field0.field0[2].field0[1] = (ExpectedType10)(878.5);
v_record31_0.field0.field0[2].field0[2] = (ExpectedType10)(566.5);
v_record31_0.field1.field0 = (ExpectedType5)(INT64_C(178078407));
v_record31_0.field1.field1.field0 = (ExpectedType6)(UINT64_C(5185230148685175761));
v_record31_0.field1.field1.field1 = (ExpectedType3)(INT64_C(17204));
v_record31_0.field1.field1.field2 = (ExpectedType9)((-INT64_C(2010612080)));
v_record31_0.field1.field1.field3 = (ExpectedType1)((-INT64_C(89)));
ExpectedType43 out_v_record31_0 = abi_h_record31(v_record31_0);
assert(v_record31_0.field0.field0[0].field0[0] == out_v_record31_0.field0.field0[0].field0[0]);
assert(v_record31_0.field0.field0[0].field0[1] == out_v_record31_0.field0.field0[0].field0[1]);
assert(v_record31_0.field0.field0[0].field0[2] == out_v_record31_0.field0.field0[0].field0[2]);
assert(v_record31_0.field0.field0[1].field0[0] == out_v_record31_0.field0.field0[1].field0[0]);
assert(v_record31_0.field0.field0[1].field0[1] == out_v_record31_0.field0.field0[1].field0[1]);
assert(v_record31_0.field0.field0[1].field0[2] == out_v_record31_0.field0.field0[1].field0[2]);
assert(v_record31_0.field0.field0[2].field0[0] == out_v_record31_0.field0.field0[2].field0[0]);
assert(v_record31_0.field0.field0[2].field0[1] == out_v_record31_0.field0.field0[2].field0[1]);
assert(v_record31_0.field0.field0[2].field0[2] == out_v_record31_0.field0.field0[2].field0[2]);
assert(v_record31_0.field1.field0 == out_v_record31_0.field1.field0);
assert(v_record31_0.field1.field1.field0 == out_v_record31_0.field1.field1.field0);
assert(v_record31_0.field1.field1.field1 == out_v_record31_0.field1.field1.field1);
assert(v_record31_0.field1.field1.field2 == out_v_record31_0.field1.field1.field2);
assert(v_record31_0.field1.field1.field3 == out_v_record31_0.field1.field1.field3);
}
{
ExpectedType43 v_record31_1 = {0};
v_record31_1.field0.field0[0].field0[0] = (ExpectedType10)(401.25);
v_record31_1.field0.field0[0].field0[1] = (ExpectedType10)(-20.75);
v_record31_1.field0.field0[0].field0[2] = (ExpectedType10)(506.0);
v_record31_1.field0.field0[1].field0[0] = (ExpectedType10)(-839.0);
v_record31_1.field0.field0[1].field0[1] = (ExpectedType10)(-569.75);
v_record31_1.field0.field0[1].field0[2] = (ExpectedType10)(160.0);
v_record31_1.field0.field0[2].field0[0] = (ExpectedType10)(995.0);
v_record31_1.field0.field0[2].field0[1] = (ExpectedType10)(-652.5);
v_record31_1.field0.field0[2].field0[2] = (ExpectedType10)(854.0);
v_record31_1.field1.field0 = (ExpectedType5)(INT64_C(200791777));
v_record31_1.field1.field1.field0 = (ExpectedType6)(UINT64_C(14777248286288293187));
v_record31_1.field1.field1.field1 = (ExpectedType3)((-INT64_C(622)));
v_record31_1.field1.field1.field2 = (ExpectedType9)(INT64_C(1773782598));
v_record31_1.field1.field1.field3 = (ExpectedType1)((-INT64_C(31)));
ExpectedType43 out_v_record31_1 = abi_h_record31(v_record31_1);
assert(v_record31_1.field0.field0[0].field0[0] == out_v_record31_1.field0.field0[0].field0[0]);
assert(v_record31_1.field0.field0[0].field0[1] == out_v_record31_1.field0.field0[0].field0[1]);
assert(v_record31_1.field0.field0[0].field0[2] == out_v_record31_1.field0.field0[0].field0[2]);
assert(v_record31_1.field0.field0[1].field0[0] == out_v_record31_1.field0.field0[1].field0[0]);
assert(v_record31_1.field0.field0[1].field0[1] == out_v_record31_1.field0.field0[1].field0[1]);
assert(v_record31_1.field0.field0[1].field0[2] == out_v_record31_1.field0.field0[1].field0[2]);
assert(v_record31_1.field0.field0[2].field0[0] == out_v_record31_1.field0.field0[2].field0[0]);
assert(v_record31_1.field0.field0[2].field0[1] == out_v_record31_1.field0.field0[2].field0[1]);
assert(v_record31_1.field0.field0[2].field0[2] == out_v_record31_1.field0.field0[2].field0[2]);
assert(v_record31_1.field1.field0 == out_v_record31_1.field1.field0);
assert(v_record31_1.field1.field1.field0 == out_v_record31_1.field1.field1.field0);
assert(v_record31_1.field1.field1.field1 == out_v_record31_1.field1.field1.field1);
assert(v_record31_1.field1.field1.field2 == out_v_record31_1.field1.field1.field2);
assert(v_record31_1.field1.field1.field3 == out_v_record31_1.field1.field1.field3);
}
{
ExpectedType43 v_record31_2 = {0};
v_record31_2.field0.field0[0].field0[0] = (ExpectedType10)(-897.5);
v_record31_2.field0.field0[0].field0[1] = (ExpectedType10)(-91.75);
v_record31_2.field0.field0[0].field0[2] = (ExpectedType10)(-424.0);
v_record31_2.field0.field0[1].field0[0] = (ExpectedType10)(-975.0);
v_record31_2.field0.field0[1].field0[1] = (ExpectedType10)(175.0);
v_record31_2.field0.field0[1].field0[2] = (ExpectedType10)(132.25);
v_record31_2.field0.field0[2].field0[0] = (ExpectedType10)(970.5);
v_record31_2.field0.field0[2].field0[1] = (ExpectedType10)(-649.75);
v_record31_2.field0.field0[2].field0[2] = (ExpectedType10)(-493.25);
v_record31_2.field1.field0 = (ExpectedType5)(INT64_C(1317248737));
v_record31_2.field1.field1.field0 = (ExpectedType6)(UINT64_C(11461521596974018311));
v_record31_2.field1.field1.field1 = (ExpectedType3)((-INT64_C(14062)));
v_record31_2.field1.field1.field2 = (ExpectedType9)((-INT64_C(1682128304)));
v_record31_2.field1.field1.field3 = (ExpectedType1)(INT64_C(50));
ExpectedType43 out_v_record31_2 = abi_h_record31(v_record31_2);
assert(v_record31_2.field0.field0[0].field0[0] == out_v_record31_2.field0.field0[0].field0[0]);
assert(v_record31_2.field0.field0[0].field0[1] == out_v_record31_2.field0.field0[0].field0[1]);
assert(v_record31_2.field0.field0[0].field0[2] == out_v_record31_2.field0.field0[0].field0[2]);
assert(v_record31_2.field0.field0[1].field0[0] == out_v_record31_2.field0.field0[1].field0[0]);
assert(v_record31_2.field0.field0[1].field0[1] == out_v_record31_2.field0.field0[1].field0[1]);
assert(v_record31_2.field0.field0[1].field0[2] == out_v_record31_2.field0.field0[1].field0[2]);
assert(v_record31_2.field0.field0[2].field0[0] == out_v_record31_2.field0.field0[2].field0[0]);
assert(v_record31_2.field0.field0[2].field0[1] == out_v_record31_2.field0.field0[2].field0[1]);
assert(v_record31_2.field0.field0[2].field0[2] == out_v_record31_2.field0.field0[2].field0[2]);
assert(v_record31_2.field1.field0 == out_v_record31_2.field1.field0);
assert(v_record31_2.field1.field1.field0 == out_v_record31_2.field1.field1.field0);
assert(v_record31_2.field1.field1.field1 == out_v_record31_2.field1.field1.field1);
assert(v_record31_2.field1.field1.field2 == out_v_record31_2.field1.field1.field2);
assert(v_record31_2.field1.field1.field3 == out_v_record31_2.field1.field1.field3);
}
{
ExpectedType44 v_record32_0 = {0};
v_record32_0.field0 = (ExpectedType1)(INT64_C(15));
ExpectedType44 out_v_record32_0 = abi_h_record32(v_record32_0);
assert(v_record32_0.field0 == out_v_record32_0.field0);
}
{
ExpectedType44 v_record32_1 = {0};
v_record32_1.field0 = (ExpectedType1)((-INT64_C(83)));
ExpectedType44 out_v_record32_1 = abi_h_record32(v_record32_1);
assert(v_record32_1.field0 == out_v_record32_1.field0);
}
{
ExpectedType44 v_record32_2 = {0};
v_record32_2.field0 = (ExpectedType1)((-INT64_C(63)));
ExpectedType44 out_v_record32_2 = abi_h_record32(v_record32_2);
assert(v_record32_2.field0 == out_v_record32_2.field0);
}
{
ExpectedType45 v_record33_0 = {0};
v_record33_0.field0 = (ExpectedType7)((-INT64_C(284949494143575207)));
v_record33_0.field1 = (ExpectedType10)(761.75);
v_record33_0.field2 = (ExpectedType1)((-INT64_C(7)));
v_record33_0.field3.field0 = (ExpectedType0)(UINT64_C(221));
v_record33_0.field3.field1 = (ExpectedType6)(UINT64_C(16056508986082369588));
v_record33_0.field4[0][0].field0[0] = (ExpectedType5)(INT64_C(1046077980));
v_record33_0.field4[0][0].field0[1] = (ExpectedType5)(INT64_C(1324347310));
v_record33_0.field4[0][0].field0[2] = (ExpectedType5)((-INT64_C(519738283)));
v_record33_0.field4[0][1].field0[0] = (ExpectedType5)((-INT64_C(1725247074)));
v_record33_0.field4[0][1].field0[1] = (ExpectedType5)((-INT64_C(719031172)));
v_record33_0.field4[0][1].field0[2] = (ExpectedType5)(INT64_C(990122369));
v_record33_0.field4[0][2].field0[0] = (ExpectedType5)(INT64_C(113026267));
v_record33_0.field4[0][2].field0[1] = (ExpectedType5)((-INT64_C(2074388824)));
v_record33_0.field4[0][2].field0[2] = (ExpectedType5)((-INT64_C(88365417)));
v_record33_0.field4[0][3].field0[0] = (ExpectedType5)((-INT64_C(1935157515)));
v_record33_0.field4[0][3].field0[1] = (ExpectedType5)((-INT64_C(686572410)));
v_record33_0.field4[0][3].field0[2] = (ExpectedType5)((-INT64_C(313143643)));
v_record33_0.field4[1][0].field0[0] = (ExpectedType5)((-INT64_C(825753659)));
v_record33_0.field4[1][0].field0[1] = (ExpectedType5)((-INT64_C(331080535)));
v_record33_0.field4[1][0].field0[2] = (ExpectedType5)(INT64_C(1103279772));
v_record33_0.field4[1][1].field0[0] = (ExpectedType5)((-INT64_C(1282813940)));
v_record33_0.field4[1][1].field0[1] = (ExpectedType5)(INT64_C(1125055480));
v_record33_0.field4[1][1].field0[2] = (ExpectedType5)((-INT64_C(790569817)));
v_record33_0.field4[1][2].field0[0] = (ExpectedType5)((-INT64_C(2008209562)));
v_record33_0.field4[1][2].field0[1] = (ExpectedType5)((-INT64_C(1584621212)));
v_record33_0.field4[1][2].field0[2] = (ExpectedType5)((-INT64_C(1022571053)));
v_record33_0.field4[1][3].field0[0] = (ExpectedType5)((-INT64_C(568374546)));
v_record33_0.field4[1][3].field0[1] = (ExpectedType5)(INT64_C(872658853));
v_record33_0.field4[1][3].field0[2] = (ExpectedType5)((-INT64_C(1026049027)));
ExpectedType45 out_v_record33_0 = abi_h_record33(v_record33_0);
assert(v_record33_0.field0 == out_v_record33_0.field0);
assert(v_record33_0.field1 == out_v_record33_0.field1);
assert(v_record33_0.field2 == out_v_record33_0.field2);
assert(v_record33_0.field3.field0 == out_v_record33_0.field3.field0);
assert(v_record33_0.field3.field1 == out_v_record33_0.field3.field1);
assert(v_record33_0.field4[0][0].field0[0] == out_v_record33_0.field4[0][0].field0[0]);
assert(v_record33_0.field4[0][0].field0[1] == out_v_record33_0.field4[0][0].field0[1]);
assert(v_record33_0.field4[0][0].field0[2] == out_v_record33_0.field4[0][0].field0[2]);
assert(v_record33_0.field4[0][1].field0[0] == out_v_record33_0.field4[0][1].field0[0]);
assert(v_record33_0.field4[0][1].field0[1] == out_v_record33_0.field4[0][1].field0[1]);
assert(v_record33_0.field4[0][1].field0[2] == out_v_record33_0.field4[0][1].field0[2]);
assert(v_record33_0.field4[0][2].field0[0] == out_v_record33_0.field4[0][2].field0[0]);
assert(v_record33_0.field4[0][2].field0[1] == out_v_record33_0.field4[0][2].field0[1]);
assert(v_record33_0.field4[0][2].field0[2] == out_v_record33_0.field4[0][2].field0[2]);
assert(v_record33_0.field4[0][3].field0[0] == out_v_record33_0.field4[0][3].field0[0]);
assert(v_record33_0.field4[0][3].field0[1] == out_v_record33_0.field4[0][3].field0[1]);
assert(v_record33_0.field4[0][3].field0[2] == out_v_record33_0.field4[0][3].field0[2]);
assert(v_record33_0.field4[1][0].field0[0] == out_v_record33_0.field4[1][0].field0[0]);
assert(v_record33_0.field4[1][0].field0[1] == out_v_record33_0.field4[1][0].field0[1]);
assert(v_record33_0.field4[1][0].field0[2] == out_v_record33_0.field4[1][0].field0[2]);
assert(v_record33_0.field4[1][1].field0[0] == out_v_record33_0.field4[1][1].field0[0]);
assert(v_record33_0.field4[1][1].field0[1] == out_v_record33_0.field4[1][1].field0[1]);
assert(v_record33_0.field4[1][1].field0[2] == out_v_record33_0.field4[1][1].field0[2]);
assert(v_record33_0.field4[1][2].field0[0] == out_v_record33_0.field4[1][2].field0[0]);
assert(v_record33_0.field4[1][2].field0[1] == out_v_record33_0.field4[1][2].field0[1]);
assert(v_record33_0.field4[1][2].field0[2] == out_v_record33_0.field4[1][2].field0[2]);
assert(v_record33_0.field4[1][3].field0[0] == out_v_record33_0.field4[1][3].field0[0]);
assert(v_record33_0.field4[1][3].field0[1] == out_v_record33_0.field4[1][3].field0[1]);
assert(v_record33_0.field4[1][3].field0[2] == out_v_record33_0.field4[1][3].field0[2]);
}
{
ExpectedType45 v_record33_1 = {0};
v_record33_1.field0 = (ExpectedType7)(INT64_C(3065608384622887371));
v_record33_1.field1 = (ExpectedType10)(-669.5);
v_record33_1.field2 = (ExpectedType1)((-INT64_C(119)));
v_record33_1.field3.field0 = (ExpectedType0)(UINT64_C(2));
v_record33_1.field3.field1 = (ExpectedType6)(UINT64_C(18322297691416595571));
v_record33_1.field4[0][0].field0[0] = (ExpectedType5)(INT64_C(2044939530));
v_record33_1.field4[0][0].field0[1] = (ExpectedType5)(INT64_C(1486535929));
v_record33_1.field4[0][0].field0[2] = (ExpectedType5)(INT64_C(419818717));
v_record33_1.field4[0][1].field0[0] = (ExpectedType5)(INT64_C(349734009));
v_record33_1.field4[0][1].field0[1] = (ExpectedType5)(INT64_C(338907821));
v_record33_1.field4[0][1].field0[2] = (ExpectedType5)(INT64_C(237497949));
v_record33_1.field4[0][2].field0[0] = (ExpectedType5)(INT64_C(574887604));
v_record33_1.field4[0][2].field0[1] = (ExpectedType5)(INT64_C(3990818));
v_record33_1.field4[0][2].field0[2] = (ExpectedType5)(INT64_C(1797929800));
v_record33_1.field4[0][3].field0[0] = (ExpectedType5)(INT64_C(1888423437));
v_record33_1.field4[0][3].field0[1] = (ExpectedType5)((-INT64_C(1009217847)));
v_record33_1.field4[0][3].field0[2] = (ExpectedType5)((-INT64_C(1895687881)));
v_record33_1.field4[1][0].field0[0] = (ExpectedType5)(INT64_C(46234782));
v_record33_1.field4[1][0].field0[1] = (ExpectedType5)(INT64_C(369550382));
v_record33_1.field4[1][0].field0[2] = (ExpectedType5)((-INT64_C(718181844)));
v_record33_1.field4[1][1].field0[0] = (ExpectedType5)(INT64_C(1697004931));
v_record33_1.field4[1][1].field0[1] = (ExpectedType5)(INT64_C(781594274));
v_record33_1.field4[1][1].field0[2] = (ExpectedType5)((-INT64_C(1651629479)));
v_record33_1.field4[1][2].field0[0] = (ExpectedType5)((-INT64_C(69008698)));
v_record33_1.field4[1][2].field0[1] = (ExpectedType5)(INT64_C(208212171));
v_record33_1.field4[1][2].field0[2] = (ExpectedType5)(INT64_C(1109196903));
v_record33_1.field4[1][3].field0[0] = (ExpectedType5)((-INT64_C(1059813305)));
v_record33_1.field4[1][3].field0[1] = (ExpectedType5)((-INT64_C(2121930165)));
v_record33_1.field4[1][3].field0[2] = (ExpectedType5)(INT64_C(535587423));
ExpectedType45 out_v_record33_1 = abi_h_record33(v_record33_1);
assert(v_record33_1.field0 == out_v_record33_1.field0);
assert(v_record33_1.field1 == out_v_record33_1.field1);
assert(v_record33_1.field2 == out_v_record33_1.field2);
assert(v_record33_1.field3.field0 == out_v_record33_1.field3.field0);
assert(v_record33_1.field3.field1 == out_v_record33_1.field3.field1);
assert(v_record33_1.field4[0][0].field0[0] == out_v_record33_1.field4[0][0].field0[0]);
assert(v_record33_1.field4[0][0].field0[1] == out_v_record33_1.field4[0][0].field0[1]);
assert(v_record33_1.field4[0][0].field0[2] == out_v_record33_1.field4[0][0].field0[2]);
assert(v_record33_1.field4[0][1].field0[0] == out_v_record33_1.field4[0][1].field0[0]);
assert(v_record33_1.field4[0][1].field0[1] == out_v_record33_1.field4[0][1].field0[1]);
assert(v_record33_1.field4[0][1].field0[2] == out_v_record33_1.field4[0][1].field0[2]);
assert(v_record33_1.field4[0][2].field0[0] == out_v_record33_1.field4[0][2].field0[0]);
assert(v_record33_1.field4[0][2].field0[1] == out_v_record33_1.field4[0][2].field0[1]);
assert(v_record33_1.field4[0][2].field0[2] == out_v_record33_1.field4[0][2].field0[2]);
assert(v_record33_1.field4[0][3].field0[0] == out_v_record33_1.field4[0][3].field0[0]);
assert(v_record33_1.field4[0][3].field0[1] == out_v_record33_1.field4[0][3].field0[1]);
assert(v_record33_1.field4[0][3].field0[2] == out_v_record33_1.field4[0][3].field0[2]);
assert(v_record33_1.field4[1][0].field0[0] == out_v_record33_1.field4[1][0].field0[0]);
assert(v_record33_1.field4[1][0].field0[1] == out_v_record33_1.field4[1][0].field0[1]);
assert(v_record33_1.field4[1][0].field0[2] == out_v_record33_1.field4[1][0].field0[2]);
assert(v_record33_1.field4[1][1].field0[0] == out_v_record33_1.field4[1][1].field0[0]);
assert(v_record33_1.field4[1][1].field0[1] == out_v_record33_1.field4[1][1].field0[1]);
assert(v_record33_1.field4[1][1].field0[2] == out_v_record33_1.field4[1][1].field0[2]);
assert(v_record33_1.field4[1][2].field0[0] == out_v_record33_1.field4[1][2].field0[0]);
assert(v_record33_1.field4[1][2].field0[1] == out_v_record33_1.field4[1][2].field0[1]);
assert(v_record33_1.field4[1][2].field0[2] == out_v_record33_1.field4[1][2].field0[2]);
assert(v_record33_1.field4[1][3].field0[0] == out_v_record33_1.field4[1][3].field0[0]);
assert(v_record33_1.field4[1][3].field0[1] == out_v_record33_1.field4[1][3].field0[1]);
assert(v_record33_1.field4[1][3].field0[2] == out_v_record33_1.field4[1][3].field0[2]);
}
{
ExpectedType45 v_record33_2 = {0};
v_record33_2.field0 = (ExpectedType7)((-INT64_C(7725515070931304354)));
v_record33_2.field1 = (ExpectedType10)(411.75);
v_record33_2.field2 = (ExpectedType1)(INT64_C(90));
v_record33_2.field3.field0 = (ExpectedType0)(UINT64_C(107));
v_record33_2.field3.field1 = (ExpectedType6)(UINT64_C(11347043058720024922));
v_record33_2.field4[0][0].field0[0] = (ExpectedType5)(INT64_C(1962092287));
v_record33_2.field4[0][0].field0[1] = (ExpectedType5)(INT64_C(1716543352));
v_record33_2.field4[0][0].field0[2] = (ExpectedType5)(INT64_C(1137766845));
v_record33_2.field4[0][1].field0[0] = (ExpectedType5)(INT64_C(365447181));
v_record33_2.field4[0][1].field0[1] = (ExpectedType5)(INT64_C(915455522));
v_record33_2.field4[0][1].field0[2] = (ExpectedType5)((-INT64_C(1755440683)));
v_record33_2.field4[0][2].field0[0] = (ExpectedType5)((-INT64_C(1580148777)));
v_record33_2.field4[0][2].field0[1] = (ExpectedType5)((-INT64_C(848581835)));
v_record33_2.field4[0][2].field0[2] = (ExpectedType5)((-INT64_C(805312236)));
v_record33_2.field4[0][3].field0[0] = (ExpectedType5)((-INT64_C(598473591)));
v_record33_2.field4[0][3].field0[1] = (ExpectedType5)((-INT64_C(365267707)));
v_record33_2.field4[0][3].field0[2] = (ExpectedType5)(INT64_C(179454866));
v_record33_2.field4[1][0].field0[0] = (ExpectedType5)((-INT64_C(746528115)));
v_record33_2.field4[1][0].field0[1] = (ExpectedType5)(INT64_C(1973830765));
v_record33_2.field4[1][0].field0[2] = (ExpectedType5)((-INT64_C(1418060396)));
v_record33_2.field4[1][1].field0[0] = (ExpectedType5)(INT64_C(1467959474));
v_record33_2.field4[1][1].field0[1] = (ExpectedType5)((-INT64_C(1282923347)));
v_record33_2.field4[1][1].field0[2] = (ExpectedType5)((-INT64_C(2102278212)));
v_record33_2.field4[1][2].field0[0] = (ExpectedType5)(INT64_C(1952996614));
v_record33_2.field4[1][2].field0[1] = (ExpectedType5)(INT64_C(1692615306));
v_record33_2.field4[1][2].field0[2] = (ExpectedType5)((-INT64_C(1403650270)));
v_record33_2.field4[1][3].field0[0] = (ExpectedType5)((-INT64_C(1404301477)));
v_record33_2.field4[1][3].field0[1] = (ExpectedType5)(INT64_C(997073014));
v_record33_2.field4[1][3].field0[2] = (ExpectedType5)((-INT64_C(1401590967)));
ExpectedType45 out_v_record33_2 = abi_h_record33(v_record33_2);
assert(v_record33_2.field0 == out_v_record33_2.field0);
assert(v_record33_2.field1 == out_v_record33_2.field1);
assert(v_record33_2.field2 == out_v_record33_2.field2);
assert(v_record33_2.field3.field0 == out_v_record33_2.field3.field0);
assert(v_record33_2.field3.field1 == out_v_record33_2.field3.field1);
assert(v_record33_2.field4[0][0].field0[0] == out_v_record33_2.field4[0][0].field0[0]);
assert(v_record33_2.field4[0][0].field0[1] == out_v_record33_2.field4[0][0].field0[1]);
assert(v_record33_2.field4[0][0].field0[2] == out_v_record33_2.field4[0][0].field0[2]);
assert(v_record33_2.field4[0][1].field0[0] == out_v_record33_2.field4[0][1].field0[0]);
assert(v_record33_2.field4[0][1].field0[1] == out_v_record33_2.field4[0][1].field0[1]);
assert(v_record33_2.field4[0][1].field0[2] == out_v_record33_2.field4[0][1].field0[2]);
assert(v_record33_2.field4[0][2].field0[0] == out_v_record33_2.field4[0][2].field0[0]);
assert(v_record33_2.field4[0][2].field0[1] == out_v_record33_2.field4[0][2].field0[1]);
assert(v_record33_2.field4[0][2].field0[2] == out_v_record33_2.field4[0][2].field0[2]);
assert(v_record33_2.field4[0][3].field0[0] == out_v_record33_2.field4[0][3].field0[0]);
assert(v_record33_2.field4[0][3].field0[1] == out_v_record33_2.field4[0][3].field0[1]);
assert(v_record33_2.field4[0][3].field0[2] == out_v_record33_2.field4[0][3].field0[2]);
assert(v_record33_2.field4[1][0].field0[0] == out_v_record33_2.field4[1][0].field0[0]);
assert(v_record33_2.field4[1][0].field0[1] == out_v_record33_2.field4[1][0].field0[1]);
assert(v_record33_2.field4[1][0].field0[2] == out_v_record33_2.field4[1][0].field0[2]);
assert(v_record33_2.field4[1][1].field0[0] == out_v_record33_2.field4[1][1].field0[0]);
assert(v_record33_2.field4[1][1].field0[1] == out_v_record33_2.field4[1][1].field0[1]);
assert(v_record33_2.field4[1][1].field0[2] == out_v_record33_2.field4[1][1].field0[2]);
assert(v_record33_2.field4[1][2].field0[0] == out_v_record33_2.field4[1][2].field0[0]);
assert(v_record33_2.field4[1][2].field0[1] == out_v_record33_2.field4[1][2].field0[1]);
assert(v_record33_2.field4[1][2].field0[2] == out_v_record33_2.field4[1][2].field0[2]);
assert(v_record33_2.field4[1][3].field0[0] == out_v_record33_2.field4[1][3].field0[0]);
assert(v_record33_2.field4[1][3].field0[1] == out_v_record33_2.field4[1][3].field0[1]);
assert(v_record33_2.field4[1][3].field0[2] == out_v_record33_2.field4[1][3].field0[2]);
}
{
ExpectedType46 v_record34_0 = {0};
v_record34_0.field0 = (ExpectedType7)((-INT64_C(4491930399891713298)));
ExpectedType46 out_v_record34_0 = abi_h_record34(v_record34_0);
assert(v_record34_0.field0 == out_v_record34_0.field0);
}
{
ExpectedType46 v_record34_1 = {0};
v_record34_1.field0 = (ExpectedType7)(INT64_C(569532978738696720));
ExpectedType46 out_v_record34_1 = abi_h_record34(v_record34_1);
assert(v_record34_1.field0 == out_v_record34_1.field0);
}
{
ExpectedType46 v_record34_2 = {0};
v_record34_2.field0 = (ExpectedType7)(INT64_C(4893526161034867005));
ExpectedType46 out_v_record34_2 = abi_h_record34(v_record34_2);
assert(v_record34_2.field0 == out_v_record34_2.field0);
}
{
ExpectedType47 v_record35_0 = {0};
v_record35_0.pointer0 = (ExpectedType48)0;
v_record35_0.pointer1 = (ExpectedType49)0;
v_record35_0.pointer2 = (ExpectedType50)0;
v_record35_0.pointer3 = (ExpectedType51)0;
v_record35_0.pointer4 = (ExpectedType53)0;
v_record35_0.pointer5 = (ExpectedType55)0;
v_record35_0.pointer6 = (ExpectedType56)0;
v_record35_0.pointer7 = (ExpectedType58)0;
v_record35_0.pointer8 = (ExpectedType60)0;
v_record35_0.pointer9 = (ExpectedType63)0;
v_record35_0.pointer10 = (ExpectedType65)0;
v_record35_0.pointer11 = (ExpectedType66)0;
v_record35_0.pointer_array[0] = (ExpectedType48)0;
v_record35_0.pointer_array[1] = (ExpectedType48)0;
v_record35_0.pointer_array[2] = (ExpectedType48)0;
v_record35_0.array_pointer_array[0] = (ExpectedType56)0;
v_record35_0.array_pointer_array[1] = (ExpectedType56)0;
ExpectedType47 out_v_record35_0 = abi_h_record35(v_record35_0);
assert(v_record35_0.pointer0 == out_v_record35_0.pointer0);
assert(v_record35_0.pointer1 == out_v_record35_0.pointer1);
assert(v_record35_0.pointer2 == out_v_record35_0.pointer2);
assert(v_record35_0.pointer3 == out_v_record35_0.pointer3);
assert(v_record35_0.pointer4 == out_v_record35_0.pointer4);
assert(v_record35_0.pointer5 == out_v_record35_0.pointer5);
assert(v_record35_0.pointer6 == out_v_record35_0.pointer6);
assert(v_record35_0.pointer7 == out_v_record35_0.pointer7);
assert(v_record35_0.pointer8 == out_v_record35_0.pointer8);
assert(v_record35_0.pointer9 == out_v_record35_0.pointer9);
assert(v_record35_0.pointer10 == out_v_record35_0.pointer10);
assert(v_record35_0.pointer11 == out_v_record35_0.pointer11);
assert(v_record35_0.pointer_array[0] == out_v_record35_0.pointer_array[0]);
assert(v_record35_0.pointer_array[1] == out_v_record35_0.pointer_array[1]);
assert(v_record35_0.pointer_array[2] == out_v_record35_0.pointer_array[2]);
assert(v_record35_0.array_pointer_array[0] == out_v_record35_0.array_pointer_array[0]);
assert(v_record35_0.array_pointer_array[1] == out_v_record35_0.array_pointer_array[1]);
}
{
ExpectedType47 v_record35_1 = {0};
v_record35_1.pointer0 = (ExpectedType48)0;
v_record35_1.pointer1 = (ExpectedType49)0;
v_record35_1.pointer2 = (ExpectedType50)0;
v_record35_1.pointer3 = (ExpectedType51)0;
v_record35_1.pointer4 = (ExpectedType53)0;
v_record35_1.pointer5 = (ExpectedType55)0;
v_record35_1.pointer6 = (ExpectedType56)0;
v_record35_1.pointer7 = (ExpectedType58)0;
v_record35_1.pointer8 = (ExpectedType60)0;
v_record35_1.pointer9 = (ExpectedType63)0;
v_record35_1.pointer10 = (ExpectedType65)0;
v_record35_1.pointer11 = (ExpectedType66)0;
v_record35_1.pointer_array[0] = (ExpectedType48)0;
v_record35_1.pointer_array[1] = (ExpectedType48)0;
v_record35_1.pointer_array[2] = (ExpectedType48)0;
v_record35_1.array_pointer_array[0] = (ExpectedType56)0;
v_record35_1.array_pointer_array[1] = (ExpectedType56)0;
ExpectedType47 out_v_record35_1 = abi_h_record35(v_record35_1);
assert(v_record35_1.pointer0 == out_v_record35_1.pointer0);
assert(v_record35_1.pointer1 == out_v_record35_1.pointer1);
assert(v_record35_1.pointer2 == out_v_record35_1.pointer2);
assert(v_record35_1.pointer3 == out_v_record35_1.pointer3);
assert(v_record35_1.pointer4 == out_v_record35_1.pointer4);
assert(v_record35_1.pointer5 == out_v_record35_1.pointer5);
assert(v_record35_1.pointer6 == out_v_record35_1.pointer6);
assert(v_record35_1.pointer7 == out_v_record35_1.pointer7);
assert(v_record35_1.pointer8 == out_v_record35_1.pointer8);
assert(v_record35_1.pointer9 == out_v_record35_1.pointer9);
assert(v_record35_1.pointer10 == out_v_record35_1.pointer10);
assert(v_record35_1.pointer11 == out_v_record35_1.pointer11);
assert(v_record35_1.pointer_array[0] == out_v_record35_1.pointer_array[0]);
assert(v_record35_1.pointer_array[1] == out_v_record35_1.pointer_array[1]);
assert(v_record35_1.pointer_array[2] == out_v_record35_1.pointer_array[2]);
assert(v_record35_1.array_pointer_array[0] == out_v_record35_1.array_pointer_array[0]);
assert(v_record35_1.array_pointer_array[1] == out_v_record35_1.array_pointer_array[1]);
}
{
ExpectedType47 v_record35_2 = {0};
v_record35_2.pointer0 = (ExpectedType48)0;
v_record35_2.pointer1 = (ExpectedType49)0;
v_record35_2.pointer2 = (ExpectedType50)0;
v_record35_2.pointer3 = (ExpectedType51)0;
v_record35_2.pointer4 = (ExpectedType53)0;
v_record35_2.pointer5 = (ExpectedType55)0;
v_record35_2.pointer6 = (ExpectedType56)0;
v_record35_2.pointer7 = (ExpectedType58)0;
v_record35_2.pointer8 = (ExpectedType60)0;
v_record35_2.pointer9 = (ExpectedType63)0;
v_record35_2.pointer10 = (ExpectedType65)0;
v_record35_2.pointer11 = (ExpectedType66)0;
v_record35_2.pointer_array[0] = (ExpectedType48)0;
v_record35_2.pointer_array[1] = (ExpectedType48)0;
v_record35_2.pointer_array[2] = (ExpectedType48)0;
v_record35_2.array_pointer_array[0] = (ExpectedType56)0;
v_record35_2.array_pointer_array[1] = (ExpectedType56)0;
ExpectedType47 out_v_record35_2 = abi_h_record35(v_record35_2);
assert(v_record35_2.pointer0 == out_v_record35_2.pointer0);
assert(v_record35_2.pointer1 == out_v_record35_2.pointer1);
assert(v_record35_2.pointer2 == out_v_record35_2.pointer2);
assert(v_record35_2.pointer3 == out_v_record35_2.pointer3);
assert(v_record35_2.pointer4 == out_v_record35_2.pointer4);
assert(v_record35_2.pointer5 == out_v_record35_2.pointer5);
assert(v_record35_2.pointer6 == out_v_record35_2.pointer6);
assert(v_record35_2.pointer7 == out_v_record35_2.pointer7);
assert(v_record35_2.pointer8 == out_v_record35_2.pointer8);
assert(v_record35_2.pointer9 == out_v_record35_2.pointer9);
assert(v_record35_2.pointer10 == out_v_record35_2.pointer10);
assert(v_record35_2.pointer11 == out_v_record35_2.pointer11);
assert(v_record35_2.pointer_array[0] == out_v_record35_2.pointer_array[0]);
assert(v_record35_2.pointer_array[1] == out_v_record35_2.pointer_array[1]);
assert(v_record35_2.pointer_array[2] == out_v_record35_2.pointer_array[2]);
assert(v_record35_2.array_pointer_array[0] == out_v_record35_2.array_pointer_array[0]);
assert(v_record35_2.array_pointer_array[1] == out_v_record35_2.array_pointer_array[1]);
}
{
ExpectedType4 object_v_pointer0_0 = {0};
ExpectedType48 v_pointer0_0 = (ExpectedType48)&object_v_pointer0_0;
ExpectedType48 out_v_pointer0_0 = abi_h_pointer0(v_pointer0_0);
assert(v_pointer0_0 == out_v_pointer0_0);
}
{
ExpectedType4 object_v_pointer0_1 = {0};
ExpectedType48 v_pointer0_1 = (ExpectedType48)&object_v_pointer0_1;
ExpectedType48 out_v_pointer0_1 = abi_h_pointer0(v_pointer0_1);
assert(v_pointer0_1 == out_v_pointer0_1);
}
{
ExpectedType4 object_v_pointer0_2 = {0};
ExpectedType48 v_pointer0_2 = (ExpectedType48)&object_v_pointer0_2;
ExpectedType48 out_v_pointer0_2 = abi_h_pointer0(v_pointer0_2);
assert(v_pointer0_2 == out_v_pointer0_2);
}
{
ExpectedType4 object_v_pointer1_0 = {0};
ExpectedType49 v_pointer1_0 = (ExpectedType49)&object_v_pointer1_0;
ExpectedType49 out_v_pointer1_0 = abi_h_pointer1(v_pointer1_0);
assert(v_pointer1_0 == out_v_pointer1_0);
}
{
ExpectedType4 object_v_pointer1_1 = {0};
ExpectedType49 v_pointer1_1 = (ExpectedType49)&object_v_pointer1_1;
ExpectedType49 out_v_pointer1_1 = abi_h_pointer1(v_pointer1_1);
assert(v_pointer1_1 == out_v_pointer1_1);
}
{
ExpectedType4 object_v_pointer1_2 = {0};
ExpectedType49 v_pointer1_2 = (ExpectedType49)&object_v_pointer1_2;
ExpectedType49 out_v_pointer1_2 = abi_h_pointer1(v_pointer1_2);
assert(v_pointer1_2 == out_v_pointer1_2);
}
{
ExpectedType49 object_v_pointer2_0 = {0};
ExpectedType50 v_pointer2_0 = (ExpectedType50)&object_v_pointer2_0;
ExpectedType50 out_v_pointer2_0 = abi_h_pointer2(v_pointer2_0);
assert(v_pointer2_0 == out_v_pointer2_0);
}
{
ExpectedType49 object_v_pointer2_1 = {0};
ExpectedType50 v_pointer2_1 = (ExpectedType50)&object_v_pointer2_1;
ExpectedType50 out_v_pointer2_1 = abi_h_pointer2(v_pointer2_1);
assert(v_pointer2_1 == out_v_pointer2_1);
}
{
ExpectedType49 object_v_pointer2_2 = {0};
ExpectedType50 v_pointer2_2 = (ExpectedType50)&object_v_pointer2_2;
ExpectedType50 out_v_pointer2_2 = abi_h_pointer2(v_pointer2_2);
assert(v_pointer2_2 == out_v_pointer2_2);
}
{
ExpectedType48 object_v_pointer3_0 = {0};
ExpectedType51 v_pointer3_0 = (ExpectedType51)&object_v_pointer3_0;
ExpectedType51 out_v_pointer3_0 = abi_h_pointer3(v_pointer3_0);
assert(v_pointer3_0 == out_v_pointer3_0);
}
{
ExpectedType48 object_v_pointer3_1 = {0};
ExpectedType51 v_pointer3_1 = (ExpectedType51)&object_v_pointer3_1;
ExpectedType51 out_v_pointer3_1 = abi_h_pointer3(v_pointer3_1);
assert(v_pointer3_1 == out_v_pointer3_1);
}
{
ExpectedType48 object_v_pointer3_2 = {0};
ExpectedType51 v_pointer3_2 = (ExpectedType51)&object_v_pointer3_2;
ExpectedType51 out_v_pointer3_2 = abi_h_pointer3(v_pointer3_2);
assert(v_pointer3_2 == out_v_pointer3_2);
}
{
ExpectedType52 object_v_pointer4_0 = {0};
ExpectedType53 v_pointer4_0 = (ExpectedType53)&object_v_pointer4_0;
ExpectedType53 out_v_pointer4_0 = abi_h_pointer4(v_pointer4_0);
assert(v_pointer4_0 == out_v_pointer4_0);
}
{
ExpectedType52 object_v_pointer4_1 = {0};
ExpectedType53 v_pointer4_1 = (ExpectedType53)&object_v_pointer4_1;
ExpectedType53 out_v_pointer4_1 = abi_h_pointer4(v_pointer4_1);
assert(v_pointer4_1 == out_v_pointer4_1);
}
{
ExpectedType52 object_v_pointer4_2 = {0};
ExpectedType53 v_pointer4_2 = (ExpectedType53)&object_v_pointer4_2;
ExpectedType53 out_v_pointer4_2 = abi_h_pointer4(v_pointer4_2);
assert(v_pointer4_2 == out_v_pointer4_2);
}
{
ExpectedType54 object_v_pointer5_0 = {0};
ExpectedType55 v_pointer5_0 = (ExpectedType55)&object_v_pointer5_0;
ExpectedType55 out_v_pointer5_0 = abi_h_pointer5(v_pointer5_0);
assert(v_pointer5_0 == out_v_pointer5_0);
}
{
ExpectedType54 object_v_pointer5_1 = {0};
ExpectedType55 v_pointer5_1 = (ExpectedType55)&object_v_pointer5_1;
ExpectedType55 out_v_pointer5_1 = abi_h_pointer5(v_pointer5_1);
assert(v_pointer5_1 == out_v_pointer5_1);
}
{
ExpectedType54 object_v_pointer5_2 = {0};
ExpectedType55 v_pointer5_2 = (ExpectedType55)&object_v_pointer5_2;
ExpectedType55 out_v_pointer5_2 = abi_h_pointer5(v_pointer5_2);
assert(v_pointer5_2 == out_v_pointer5_2);
}
{
ExpectedType54 object_v_pointer6_0 = {0};
ExpectedType56 v_pointer6_0 = (ExpectedType56)&object_v_pointer6_0;
ExpectedType56 out_v_pointer6_0 = abi_h_pointer6(v_pointer6_0);
assert(v_pointer6_0 == out_v_pointer6_0);
}
{
ExpectedType54 object_v_pointer6_1 = {0};
ExpectedType56 v_pointer6_1 = (ExpectedType56)&object_v_pointer6_1;
ExpectedType56 out_v_pointer6_1 = abi_h_pointer6(v_pointer6_1);
assert(v_pointer6_1 == out_v_pointer6_1);
}
{
ExpectedType54 object_v_pointer6_2 = {0};
ExpectedType56 v_pointer6_2 = (ExpectedType56)&object_v_pointer6_2;
ExpectedType56 out_v_pointer6_2 = abi_h_pointer6(v_pointer6_2);
assert(v_pointer6_2 == out_v_pointer6_2);
}
{
ExpectedType57 object_v_pointer7_0 = {0};
ExpectedType58 v_pointer7_0 = (ExpectedType58)&object_v_pointer7_0;
ExpectedType58 out_v_pointer7_0 = abi_h_pointer7(v_pointer7_0);
assert(v_pointer7_0 == out_v_pointer7_0);
}
{
ExpectedType57 object_v_pointer7_1 = {0};
ExpectedType58 v_pointer7_1 = (ExpectedType58)&object_v_pointer7_1;
ExpectedType58 out_v_pointer7_1 = abi_h_pointer7(v_pointer7_1);
assert(v_pointer7_1 == out_v_pointer7_1);
}
{
ExpectedType57 object_v_pointer7_2 = {0};
ExpectedType58 v_pointer7_2 = (ExpectedType58)&object_v_pointer7_2;
ExpectedType58 out_v_pointer7_2 = abi_h_pointer7(v_pointer7_2);
assert(v_pointer7_2 == out_v_pointer7_2);
}
{
ExpectedType59 object_v_pointer8_0 = {0};
ExpectedType60 v_pointer8_0 = (ExpectedType60)&object_v_pointer8_0;
ExpectedType60 out_v_pointer8_0 = abi_h_pointer8(v_pointer8_0);
assert(v_pointer8_0 == out_v_pointer8_0);
}
{
ExpectedType59 object_v_pointer8_1 = {0};
ExpectedType60 v_pointer8_1 = (ExpectedType60)&object_v_pointer8_1;
ExpectedType60 out_v_pointer8_1 = abi_h_pointer8(v_pointer8_1);
assert(v_pointer8_1 == out_v_pointer8_1);
}
{
ExpectedType59 object_v_pointer8_2 = {0};
ExpectedType60 v_pointer8_2 = (ExpectedType60)&object_v_pointer8_2;
ExpectedType60 out_v_pointer8_2 = abi_h_pointer8(v_pointer8_2);
assert(v_pointer8_2 == out_v_pointer8_2);
}
{
ExpectedType62 object_v_pointer9_0 = {0};
ExpectedType63 v_pointer9_0 = (ExpectedType63)&object_v_pointer9_0;
ExpectedType63 out_v_pointer9_0 = abi_h_pointer9(v_pointer9_0);
assert(v_pointer9_0 == out_v_pointer9_0);
}
{
ExpectedType62 object_v_pointer9_1 = {0};
ExpectedType63 v_pointer9_1 = (ExpectedType63)&object_v_pointer9_1;
ExpectedType63 out_v_pointer9_1 = abi_h_pointer9(v_pointer9_1);
assert(v_pointer9_1 == out_v_pointer9_1);
}
{
ExpectedType62 object_v_pointer9_2 = {0};
ExpectedType63 v_pointer9_2 = (ExpectedType63)&object_v_pointer9_2;
ExpectedType63 out_v_pointer9_2 = abi_h_pointer9(v_pointer9_2);
assert(v_pointer9_2 == out_v_pointer9_2);
}
{
uint8_t object_v_pointer10_0 = 0;
ExpectedType65 v_pointer10_0 = (ExpectedType65)&object_v_pointer10_0;
ExpectedType65 out_v_pointer10_0 = abi_h_pointer10(v_pointer10_0);
assert(v_pointer10_0 == out_v_pointer10_0);
}
{
uint8_t object_v_pointer10_1 = 0;
ExpectedType65 v_pointer10_1 = (ExpectedType65)&object_v_pointer10_1;
ExpectedType65 out_v_pointer10_1 = abi_h_pointer10(v_pointer10_1);
assert(v_pointer10_1 == out_v_pointer10_1);
}
{
uint8_t object_v_pointer10_2 = 0;
ExpectedType65 v_pointer10_2 = (ExpectedType65)&object_v_pointer10_2;
ExpectedType65 out_v_pointer10_2 = abi_h_pointer10(v_pointer10_2);
assert(v_pointer10_2 == out_v_pointer10_2);
}
{
ExpectedType65 object_v_pointer11_0 = {0};
ExpectedType66 v_pointer11_0 = (ExpectedType66)&object_v_pointer11_0;
ExpectedType66 out_v_pointer11_0 = abi_h_pointer11(v_pointer11_0);
assert(v_pointer11_0 == out_v_pointer11_0);
}
{
ExpectedType65 object_v_pointer11_1 = {0};
ExpectedType66 v_pointer11_1 = (ExpectedType66)&object_v_pointer11_1;
ExpectedType66 out_v_pointer11_1 = abi_h_pointer11(v_pointer11_1);
assert(v_pointer11_1 == out_v_pointer11_1);
}
{
ExpectedType65 object_v_pointer11_2 = {0};
ExpectedType66 v_pointer11_2 = (ExpectedType66)&object_v_pointer11_2;
ExpectedType66 out_v_pointer11_2 = abi_h_pointer11(v_pointer11_2);
assert(v_pointer11_2 == out_v_pointer11_2);
}
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix00_size() == sizeof(hepta_Matrix00));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix00_align() == _Alignof(hepta_Matrix00));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix00_field0() == offsetof(hepta_Matrix00, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix00_field1() == offsetof(hepta_Matrix00, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix00_field2() == offsetof(hepta_Matrix00, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix00_field3() == offsetof(hepta_Matrix00, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix01_size() == sizeof(hepta_Matrix01));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix01_align() == _Alignof(hepta_Matrix01));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix01_field0() == offsetof(hepta_Matrix01, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix01_field1() == offsetof(hepta_Matrix01, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix01_field2() == offsetof(hepta_Matrix01, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix01_field3() == offsetof(hepta_Matrix01, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix02_size() == sizeof(hepta_Matrix02));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix02_align() == _Alignof(hepta_Matrix02));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix02_field0() == offsetof(hepta_Matrix02, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_size() == sizeof(hepta_Matrix03));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_align() == _Alignof(hepta_Matrix03));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_field0() == offsetof(hepta_Matrix03, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_field1() == offsetof(hepta_Matrix03, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_field2() == offsetof(hepta_Matrix03, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_field3() == offsetof(hepta_Matrix03, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix03_field4() == offsetof(hepta_Matrix03, field4));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix04_size() == sizeof(hepta_Matrix04));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix04_align() == _Alignof(hepta_Matrix04));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix04_field0() == offsetof(hepta_Matrix04, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix04_field1() == offsetof(hepta_Matrix04, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix04_field2() == offsetof(hepta_Matrix04, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix04_field3() == offsetof(hepta_Matrix04, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix05_size() == sizeof(hepta_Matrix05));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix05_align() == _Alignof(hepta_Matrix05));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix05_field0() == offsetof(hepta_Matrix05, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix06_size() == sizeof(hepta_Matrix06));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix06_align() == _Alignof(hepta_Matrix06));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix06_field0() == offsetof(hepta_Matrix06, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix06_field1() == offsetof(hepta_Matrix06, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix06_field2() == offsetof(hepta_Matrix06, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix07_size() == sizeof(hepta_Matrix07));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix07_align() == _Alignof(hepta_Matrix07));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix07_field0() == offsetof(hepta_Matrix07, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix08_size() == sizeof(hepta_Matrix08));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix08_align() == _Alignof(hepta_Matrix08));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix08_field0() == offsetof(hepta_Matrix08, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix09_size() == sizeof(hepta_Matrix09));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix09_align() == _Alignof(hepta_Matrix09));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix09_field0() == offsetof(hepta_Matrix09, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix09_field1() == offsetof(hepta_Matrix09, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix10_size() == sizeof(hepta_Matrix10));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix10_align() == _Alignof(hepta_Matrix10));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix10_field0() == offsetof(hepta_Matrix10, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix10_field1() == offsetof(hepta_Matrix10, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix11_size() == sizeof(hepta_Matrix11));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix11_align() == _Alignof(hepta_Matrix11));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix11_field0() == offsetof(hepta_Matrix11, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix11_field1() == offsetof(hepta_Matrix11, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix11_field2() == offsetof(hepta_Matrix11, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix11_field3() == offsetof(hepta_Matrix11, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix12_size() == sizeof(hepta_Matrix12));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix12_align() == _Alignof(hepta_Matrix12));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix12_field0() == offsetof(hepta_Matrix12, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix12_field1() == offsetof(hepta_Matrix12, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix13_size() == sizeof(hepta_Matrix13));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix13_align() == _Alignof(hepta_Matrix13));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix13_field0() == offsetof(hepta_Matrix13, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix13_field1() == offsetof(hepta_Matrix13, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix14_size() == sizeof(hepta_Matrix14));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix14_align() == _Alignof(hepta_Matrix14));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix14_field0() == offsetof(hepta_Matrix14, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix15_size() == sizeof(hepta_Matrix15));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix15_align() == _Alignof(hepta_Matrix15));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix15_field0() == offsetof(hepta_Matrix15, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix15_field1() == offsetof(hepta_Matrix15, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix15_field2() == offsetof(hepta_Matrix15, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix15_field3() == offsetof(hepta_Matrix15, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_size() == sizeof(hepta_Matrix16));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_align() == _Alignof(hepta_Matrix16));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_field0() == offsetof(hepta_Matrix16, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_field1() == offsetof(hepta_Matrix16, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_field2() == offsetof(hepta_Matrix16, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_field3() == offsetof(hepta_Matrix16, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix16_field4() == offsetof(hepta_Matrix16, field4));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix17_size() == sizeof(hepta_Matrix17));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix17_align() == _Alignof(hepta_Matrix17));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix17_field0() == offsetof(hepta_Matrix17, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix17_field1() == offsetof(hepta_Matrix17, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix17_field2() == offsetof(hepta_Matrix17, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix18_size() == sizeof(hepta_Matrix18));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix18_align() == _Alignof(hepta_Matrix18));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix18_field0() == offsetof(hepta_Matrix18, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix18_field1() == offsetof(hepta_Matrix18, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix18_field2() == offsetof(hepta_Matrix18, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix18_field3() == offsetof(hepta_Matrix18, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix19_size() == sizeof(hepta_Matrix19));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix19_align() == _Alignof(hepta_Matrix19));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix19_field0() == offsetof(hepta_Matrix19, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix20_size() == sizeof(hepta_Matrix20));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix20_align() == _Alignof(hepta_Matrix20));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix20_field0() == offsetof(hepta_Matrix20, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix21_size() == sizeof(hepta_Matrix21));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix21_align() == _Alignof(hepta_Matrix21));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix21_field0() == offsetof(hepta_Matrix21, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix21_field1() == offsetof(hepta_Matrix21, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix21_field2() == offsetof(hepta_Matrix21, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix21_field3() == offsetof(hepta_Matrix21, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix22_size() == sizeof(hepta_Matrix22));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix22_align() == _Alignof(hepta_Matrix22));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix22_field0() == offsetof(hepta_Matrix22, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix22_field1() == offsetof(hepta_Matrix22, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix22_field2() == offsetof(hepta_Matrix22, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix23_size() == sizeof(hepta_Matrix23));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix23_align() == _Alignof(hepta_Matrix23));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix23_field0() == offsetof(hepta_Matrix23, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix23_field1() == offsetof(hepta_Matrix23, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix23_field2() == offsetof(hepta_Matrix23, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix23_field3() == offsetof(hepta_Matrix23, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix24_size() == sizeof(hepta_Matrix24));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix24_align() == _Alignof(hepta_Matrix24));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix24_field0() == offsetof(hepta_Matrix24, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix25_size() == sizeof(hepta_Matrix25));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix25_align() == _Alignof(hepta_Matrix25));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix25_field0() == offsetof(hepta_Matrix25, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix25_field1() == offsetof(hepta_Matrix25, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix25_field2() == offsetof(hepta_Matrix25, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix25_field3() == offsetof(hepta_Matrix25, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix26_size() == sizeof(hepta_Matrix26));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix26_align() == _Alignof(hepta_Matrix26));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix26_field0() == offsetof(hepta_Matrix26, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix26_field1() == offsetof(hepta_Matrix26, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix26_field2() == offsetof(hepta_Matrix26, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix27_size() == sizeof(hepta_Matrix27));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix27_align() == _Alignof(hepta_Matrix27));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix27_field0() == offsetof(hepta_Matrix27, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix27_field1() == offsetof(hepta_Matrix27, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix27_field2() == offsetof(hepta_Matrix27, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix28_size() == sizeof(hepta_Matrix28));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix28_align() == _Alignof(hepta_Matrix28));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix28_field0() == offsetof(hepta_Matrix28, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix28_field1() == offsetof(hepta_Matrix28, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix28_field2() == offsetof(hepta_Matrix28, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix28_field3() == offsetof(hepta_Matrix28, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix29_size() == sizeof(hepta_Matrix29));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix29_align() == _Alignof(hepta_Matrix29));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix29_field0() == offsetof(hepta_Matrix29, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_size() == sizeof(hepta_Matrix30));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_align() == _Alignof(hepta_Matrix30));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_field0() == offsetof(hepta_Matrix30, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_field1() == offsetof(hepta_Matrix30, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_field2() == offsetof(hepta_Matrix30, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_field3() == offsetof(hepta_Matrix30, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix30_field4() == offsetof(hepta_Matrix30, field4));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix31_size() == sizeof(hepta_Matrix31));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix31_align() == _Alignof(hepta_Matrix31));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix31_field0() == offsetof(hepta_Matrix31, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix31_field1() == offsetof(hepta_Matrix31, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix32_size() == sizeof(hepta_Matrix32));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix32_align() == _Alignof(hepta_Matrix32));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix32_field0() == offsetof(hepta_Matrix32, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_size() == sizeof(hepta_Matrix33));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_align() == _Alignof(hepta_Matrix33));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_field0() == offsetof(hepta_Matrix33, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_field1() == offsetof(hepta_Matrix33, field1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_field2() == offsetof(hepta_Matrix33, field2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_field3() == offsetof(hepta_Matrix33, field3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix33_field4() == offsetof(hepta_Matrix33, field4));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix34_size() == sizeof(hepta_Matrix34));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix34_align() == _Alignof(hepta_Matrix34));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix34_field0() == offsetof(hepta_Matrix34, field0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_size() == sizeof(hepta_Matrix35));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_align() == _Alignof(hepta_Matrix35));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer0() == offsetof(hepta_Matrix35, pointer0));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer1() == offsetof(hepta_Matrix35, pointer1));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer2() == offsetof(hepta_Matrix35, pointer2));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer3() == offsetof(hepta_Matrix35, pointer3));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer4() == offsetof(hepta_Matrix35, pointer4));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer5() == offsetof(hepta_Matrix35, pointer5));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer6() == offsetof(hepta_Matrix35, pointer6));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer7() == offsetof(hepta_Matrix35, pointer7));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer8() == offsetof(hepta_Matrix35, pointer8));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer9() == offsetof(hepta_Matrix35, pointer9));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer10() == offsetof(hepta_Matrix35, pointer10));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer11() == offsetof(hepta_Matrix35, pointer11));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_pointer_array() == offsetof(hepta_Matrix35, pointer_array));
#endif
#ifdef ABI_LAYOUT
assert(abi_probe_Matrix35_array_pointer_array() == offsetof(hepta_Matrix35, array_pointer_array));
#endif
{
ExpectedType12 spill = {0};
spill.field0 = (ExpectedType6)(UINT64_C(10755882399842860261));
spill.field1 = (ExpectedType3)(INT64_C(29488));
spill.field2 = (ExpectedType9)((-INT64_C(1818047186)));
spill.field3 = (ExpectedType1)((-INT64_C(7)));
ExpectedType12 spill_out = abi_h_spill((uint64_t)37, (double)74, (uint64_t)111, (double)148, (uint64_t)185, (double)222, (uint64_t)259, (double)296, (uint64_t)333, (double)370, (uint64_t)407, (double)444, (uint64_t)481, (double)518, (uint64_t)555, (double)592, (uint64_t)629, (double)666, (uint64_t)703, (double)740, spill);
assert(spill.field0 == spill_out.field0);
assert(spill.field1 == spill_out.field1);
assert(spill.field2 == spill_out.field2);
assert(spill.field3 == spill_out.field3);
}
assert(abi_calls == 181);
printf("{\"status\":\"passed\",\"foreign_calls\":%zu}\n", abi_calls);
return 0;
}
