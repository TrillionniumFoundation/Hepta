
/dev/shm/hepta-step21-46d88/evidence/narrowing/narrowed.so:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	endbr64
    1004:	sub    $0x8,%rsp
    1008:	mov    0x2fc1(%rip),%rax        # 3fd0 <__gmon_start__@Base>
    100f:	test   %rax,%rax
    1012:	je     1016 <_init+0x16>
    1014:	call   *%rax
    1016:	add    $0x8,%rsp
    101a:	ret

Disassembly of section .plt:

0000000000001020 <free@plt-0x10>:
    1020:	push   0x2fca(%rip)        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	jmp    *0x2fcc(%rip)        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	nopl   0x0(%rax)

0000000000001030 <free@plt>:
    1030:	jmp    *0x2fca(%rip)        # 4000 <free@GLIBC_2.2.5>
    1036:	push   $0x0
    103b:	jmp    1020 <_init+0x20>

0000000000001040 <abort@plt>:
    1040:	jmp    *0x2fc2(%rip)        # 4008 <abort@GLIBC_2.2.5>
    1046:	push   $0x1
    104b:	jmp    1020 <_init+0x20>

0000000000001050 <calloc@plt>:
    1050:	jmp    *0x2fba(%rip)        # 4010 <calloc@GLIBC_2.2.5>
    1056:	push   $0x2
    105b:	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001060 <__cxa_finalize@plt>:
    1060:	jmp    *0x2f7a(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1066:	xchg   %ax,%ax

Disassembly of section .text:

0000000000001070 <deregister_tm_clones>:
    1070:	lea    0x2fa9(%rip),%rdi        # 4020 <completed.0>
    1077:	lea    0x2fa2(%rip),%rax        # 4020 <completed.0>
    107e:	cmp    %rdi,%rax
    1081:	je     1098 <deregister_tm_clones+0x28>
    1083:	mov    0x2f3e(%rip),%rax        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    108a:	test   %rax,%rax
    108d:	je     1098 <deregister_tm_clones+0x28>
    108f:	jmp    *%rax
    1091:	nopl   0x0(%rax)
    1098:	ret
    1099:	nopl   0x0(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:	lea    0x2f79(%rip),%rdi        # 4020 <completed.0>
    10a7:	lea    0x2f72(%rip),%rsi        # 4020 <completed.0>
    10ae:	sub    %rdi,%rsi
    10b1:	mov    %rsi,%rax
    10b4:	shr    $0x3f,%rsi
    10b8:	sar    $0x3,%rax
    10bc:	add    %rax,%rsi
    10bf:	sar    $1,%rsi
    10c2:	je     10d8 <register_tm_clones+0x38>
    10c4:	mov    0x2f0d(%rip),%rax        # 3fd8 <_ITM_registerTMCloneTable@Base>
    10cb:	test   %rax,%rax
    10ce:	je     10d8 <register_tm_clones+0x38>
    10d0:	jmp    *%rax
    10d2:	nopw   0x0(%rax,%rax,1)
    10d8:	ret
    10d9:	nopl   0x0(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:	endbr64
    10e4:	cmpb   $0x0,0x2f35(%rip)        # 4020 <completed.0>
    10eb:	jne    1118 <__do_global_dtors_aux+0x38>
    10ed:	push   %rbp
    10ee:	cmpq   $0x0,0x2eea(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10f6:	mov    %rsp,%rbp
    10f9:	je     1107 <__do_global_dtors_aux+0x27>
    10fb:	mov    0x2f16(%rip),%rdi        # 4018 <__dso_handle>
    1102:	call   1060 <__cxa_finalize@plt>
    1107:	call   1070 <deregister_tm_clones>
    110c:	movb   $0x1,0x2f0d(%rip)        # 4020 <completed.0>
    1113:	pop    %rbp
    1114:	ret
    1115:	nopl   (%rax)
    1118:	ret
    1119:	nopl   0x0(%rax)

0000000000001120 <frame_dummy>:
    1120:	endbr64
    1124:	jmp    10a0 <register_tm_clones>
    1129:	nopl   0x0(%rax)

0000000000001130 <full_lifecycle>:
    1130:	push   %rbp
    1131:	push   %r14
    1133:	push   %rbx
    1134:	mov    %esi,%ebp
    1136:	mov    %rdi,%rbx
    1139:	cmp    $0x21,%rdi
    113d:	jae    116f <full_lifecycle+0x3f>
    113f:	test   %rbx,%rbx
    1142:	je     1278 <full_lifecycle+0x148>
    1148:	mov    $0x1,%edi
    114d:	mov    %rbx,%rsi
    1150:	call   1050 <calloc@plt>
    1155:	test   %rax,%rax
    1158:	je     1280 <full_lifecycle+0x150>
    115e:	cmp    $0x3,%rbx
    1162:	ja     128b <full_lifecycle+0x15b>
    1168:	xor    %ecx,%ecx
    116a:	jmp    133f <full_lifecycle+0x20f>
    116f:	test   %rbx,%rbx
    1172:	js     11a1 <full_lifecycle+0x71>
    1174:	mov    $0x1,%edi
    1179:	mov    %rbx,%rsi
    117c:	call   1050 <calloc@plt>
    1181:	test   %rax,%rax
    1184:	je     11a1 <full_lifecycle+0x71>
    1186:	mov    $0x1,%cl
    1188:	test   $0x1,%cl
    118b:	jne    11aa <full_lifecycle+0x7a>
    118d:	mov    $0x3e9,%r14d
    1193:	test   %rax,%rax
    1196:	jne    1435 <full_lifecycle+0x305>
    119c:	jmp    143d <full_lifecycle+0x30d>
    11a1:	xor    %eax,%eax
    11a3:	xor    %ecx,%ecx
    11a5:	test   $0x1,%cl
    11a8:	je     118d <full_lifecycle+0x5d>
    11aa:	mov    %rbx,%rcx
    11ad:	and    $0xfffffffffffffff0,%rcx
    11b1:	movd   %ebp,%xmm0
    11b5:	punpcklbw %xmm0,%xmm0
    11b9:	pshuflw $0x0,%xmm0,%xmm0
    11be:	pshufd $0x0,%xmm0,%xmm0
    11c3:	movdqa 0xe35(%rip),%xmm1        # 2000 <_fini+0x530>
    11cb:	xor    %edx,%edx
    11cd:	movdqa 0xe3b(%rip),%xmm2        # 2010 <_fini+0x540>
    11d5:	data16 cs nopw 0x0(%rax,%rax,1)
    11e0:	movdqa %xmm1,%xmm3
    11e4:	paddb  %xmm0,%xmm3
    11e8:	movdqu %xmm3,(%rax,%rdx,1)
    11ed:	add    $0x10,%rdx
    11f1:	paddb  %xmm2,%xmm1
    11f5:	cmp    %rdx,%rcx
    11f8:	jne    11e0 <full_lifecycle+0xb0>
    11fa:	cmp    %rcx,%rbx
    11fd:	je     140f <full_lifecycle+0x2df>
    1203:	test   $0xc,%bl
    1206:	je     13f1 <full_lifecycle+0x2c1>
    120c:	mov    %rbx,%rdx
    120f:	and    $0xfffffffffffffffc,%rdx
    1213:	movd   %ecx,%xmm0
    1217:	punpcklbw %xmm0,%xmm0
    121b:	pshuflw $0x0,%xmm0,%xmm0
    1220:	por    0xdf8(%rip),%xmm0        # 2020 <_fini+0x550>
    1228:	movzbl %bpl,%esi
    122c:	movd   %esi,%xmm1
    1230:	punpcklbw %xmm1,%xmm1
    1234:	pshuflw $0x0,%xmm1,%xmm1
    1239:	movdqa 0xdef(%rip),%xmm2        # 2030 <_fini+0x560>
    1241:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1250:	movdqa %xmm0,%xmm3
    1254:	paddb  %xmm1,%xmm3
    1258:	movd   %xmm3,(%rax,%rcx,1)
    125d:	add    $0x4,%rcx
    1261:	paddb  %xmm2,%xmm0
    1265:	cmp    %rcx,%rdx
    1268:	jne    1250 <full_lifecycle+0x120>
    126a:	cmp    %rdx,%rbx
    126d:	jne    13f4 <full_lifecycle+0x2c4>
    1273:	jmp    140f <full_lifecycle+0x2df>
    1278:	xor    %r14d,%r14d
    127b:	jmp    143d <full_lifecycle+0x30d>
    1280:	mov    $0x3e9,%r14d
    1286:	jmp    143d <full_lifecycle+0x30d>
    128b:	movzbl %bpl,%edx
    128f:	cmp    $0x10,%rbx
    1293:	jae    1299 <full_lifecycle+0x169>
    1295:	xor    %ecx,%ecx
    1297:	jmp    12e1 <full_lifecycle+0x1b1>
    1299:	mov    %ebx,%ecx
    129b:	and    $0x30,%ecx
    129e:	movd   %edx,%xmm0
    12a2:	punpcklbw %xmm0,%xmm0
    12a6:	pshuflw $0x0,%xmm0,%xmm0
    12ab:	pshufd $0x0,%xmm0,%xmm0
    12b0:	movdqa 0xd48(%rip),%xmm1        # 2000 <_fini+0x530>
    12b8:	paddb  %xmm0,%xmm1
    12bc:	movdqu %xmm1,(%rax)
    12c0:	cmp    $0x10,%rcx
    12c4:	je     12d3 <full_lifecycle+0x1a3>
    12c6:	paddb  0xd72(%rip),%xmm0        # 2040 <_fini+0x570>
    12ce:	movdqu %xmm0,0x10(%rax)
    12d3:	cmp    %rcx,%rbx
    12d6:	je     135f <full_lifecycle+0x22f>
    12dc:	test   $0xc,%bl
    12df:	je     133f <full_lifecycle+0x20f>
    12e1:	mov    %rcx,%rsi
    12e4:	mov    %ebx,%ecx
    12e6:	and    $0x3c,%ecx
    12e9:	movd   %esi,%xmm0
    12ed:	punpcklbw %xmm0,%xmm0
    12f1:	pshuflw $0x0,%xmm0,%xmm0
    12f6:	por    0xd22(%rip),%xmm0        # 2020 <_fini+0x550>
    12fe:	movd   %edx,%xmm1
    1302:	punpcklbw %xmm1,%xmm1
    1306:	pshuflw $0x0,%xmm1,%xmm1
    130b:	movdqa 0xd1d(%rip),%xmm2        # 2030 <_fini+0x560>
    1313:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1320:	movdqa %xmm0,%xmm3
    1324:	paddb  %xmm1,%xmm3
    1328:	movd   %xmm3,(%rax,%rsi,1)
    132d:	add    $0x4,%rsi
    1331:	paddb  %xmm2,%xmm0
    1335:	cmp    %rsi,%rcx
    1338:	jne    1320 <full_lifecycle+0x1f0>
    133a:	cmp    %rcx,%rbx
    133d:	je     135f <full_lifecycle+0x22f>
    133f:	mov    %ebp,%edx
    1341:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1350:	lea    (%rdx,%rcx,1),%esi
    1353:	mov    %sil,(%rax,%rcx,1)
    1357:	inc    %rcx
    135a:	cmp    %rcx,%rbx
    135d:	jne    1350 <full_lifecycle+0x220>
    135f:	mov    %ebx,%ecx
    1361:	and    $0x7,%ecx
    1364:	cmp    $0x8,%rbx
    1368:	jae    1371 <full_lifecycle+0x241>
    136a:	xor    %edx,%edx
    136c:	xor    %r14d,%r14d
    136f:	jmp    13ca <full_lifecycle+0x29a>
    1371:	and    $0x38,%ebx
    1374:	xor    %edx,%edx
    1376:	xor    %r14d,%r14d
    1379:	nopl   0x0(%rax)
    1380:	movzbl (%rax,%rdx,1),%esi
    1384:	add    %r14,%rsi
    1387:	movzbl 0x1(%rax,%rdx,1),%edi
    138c:	movzbl 0x2(%rax,%rdx,1),%r8d
    1392:	add    %rdi,%r8
    1395:	add    %rsi,%r8
    1398:	movzbl 0x3(%rax,%rdx,1),%esi
    139d:	movzbl 0x4(%rax,%rdx,1),%edi
    13a2:	add    %rsi,%rdi
    13a5:	movzbl 0x5(%rax,%rdx,1),%esi
    13aa:	add    %rdi,%rsi
    13ad:	add    %r8,%rsi
    13b0:	movzbl 0x6(%rax,%rdx,1),%edi
    13b5:	movzbl 0x7(%rax,%rdx,1),%r14d
    13bb:	add    %rdi,%r14
    13be:	add    %rsi,%r14
    13c1:	add    $0x8,%rdx
    13c5:	cmp    %rdx,%rbx
    13c8:	jne    1380 <full_lifecycle+0x250>
    13ca:	test   %rcx,%rcx
    13cd:	je     1435 <full_lifecycle+0x305>
    13cf:	mov    %rax,%rsi
    13d2:	add    %rdx,%rsi
    13d5:	xor    %edx,%edx
    13d7:	nopw   0x0(%rax,%rax,1)
    13e0:	movzbl (%rsi,%rdx,1),%edi
    13e4:	add    %rdi,%r14
    13e7:	inc    %rdx
    13ea:	cmp    %rdx,%rcx
    13ed:	jne    13e0 <full_lifecycle+0x2b0>
    13ef:	jmp    1435 <full_lifecycle+0x305>
    13f1:	mov    %rcx,%rdx
    13f4:	mov    %ebp,%ecx
    13f6:	cs nopw 0x0(%rax,%rax,1)
    1400:	lea    (%rcx,%rdx,1),%esi
    1403:	mov    %sil,(%rax,%rdx,1)
    1407:	inc    %rdx
    140a:	cmp    %rdx,%rbx
    140d:	jne    1400 <full_lifecycle+0x2d0>
    140f:	xor    %ecx,%ecx
    1411:	xor    %r14d,%r14d
    1414:	data16 data16 cs nopw 0x0(%rax,%rax,1)
    1420:	mov    %r14,%rdx
    1423:	movzbl (%rax,%rcx,1),%r14d
    1428:	add    %rdx,%r14
    142b:	jb     1445 <full_lifecycle+0x315>
    142d:	inc    %rcx
    1430:	cmp    %rcx,%rbx
    1433:	jne    1420 <full_lifecycle+0x2f0>
    1435:	mov    %rax,%rdi
    1438:	call   1030 <free@plt>
    143d:	mov    %r14,%rax
    1440:	pop    %rbx
    1441:	pop    %r14
    1443:	pop    %rbp
    1444:	ret
    1445:	call   1040 <abort@plt>
    144a:	nopw   0x0(%rax,%rax,1)

0000000000001450 <packet_xor>:
    1450:	push   %r15
    1452:	push   %r14
    1454:	push   %rbx
    1455:	mov    %esi,%r15d
    1458:	mov    %rdi,%r14
    145b:	cmp    $0x21,%rdi
    145f:	jae    1494 <packet_xor+0x44>
    1461:	test   %r14,%r14
    1464:	je     15d8 <packet_xor+0x188>
    146a:	mov    $0x1,%edi
    146f:	mov    %r14,%rsi
    1472:	call   1050 <calloc@plt>
    1477:	test   %rax,%rax
    147a:	je     15e0 <packet_xor+0x190>
    1480:	mov    %rax,%rbx
    1483:	cmp    $0x3,%r14
    1487:	ja     15eb <packet_xor+0x19b>
    148d:	xor    %eax,%eax
    148f:	jmp    16bf <packet_xor+0x26f>
    1494:	test   %r14,%r14
    1497:	js     14c8 <packet_xor+0x78>
    1499:	mov    $0x1,%edi
    149e:	mov    %r14,%rsi
    14a1:	call   1050 <calloc@plt>
    14a6:	test   %rax,%rax
    14a9:	je     14c8 <packet_xor+0x78>
    14ab:	mov    %rax,%rbx
    14ae:	mov    $0x1,%al
    14b0:	test   $0x1,%al
    14b2:	jne    14d0 <packet_xor+0x80>
    14b4:	mov    $0x3e9,%r15d
    14ba:	test   %rbx,%rbx
    14bd:	jne    1a37 <packet_xor+0x5e7>
    14c3:	jmp    1a3f <packet_xor+0x5ef>
    14c8:	xor    %ebx,%ebx
    14ca:	xor    %eax,%eax
    14cc:	test   $0x1,%al
    14ce:	je     14b4 <packet_xor+0x64>
    14d0:	mov    %r14,%rax
    14d3:	and    $0xfffffffffffffff0,%rax
    14d7:	movd   %r15d,%xmm0
    14dc:	punpcklbw %xmm0,%xmm0
    14e0:	pshuflw $0x0,%xmm0,%xmm0
    14e5:	pshufd $0x0,%xmm0,%xmm1
    14ea:	movdqa 0xb0e(%rip),%xmm2        # 2000 <_fini+0x530>
    14f2:	xor    %ecx,%ecx
    14f4:	movdqa 0xb54(%rip),%xmm3        # 2050 <_fini+0x580>
    14fc:	movdqa 0xb5c(%rip),%xmm0        # 2060 <_fini+0x590>
    1504:	movdqa 0xb04(%rip),%xmm6        # 2010 <_fini+0x540>
    150c:	nopl   0x0(%rax)
    1510:	movdqa %xmm2,%xmm4
    1514:	punpckhbw %xmm4,%xmm4
    1518:	pmullw %xmm3,%xmm4
    151c:	pand   %xmm0,%xmm4
    1520:	movdqa %xmm2,%xmm5
    1524:	punpcklbw %xmm5,%xmm5
    1528:	pmullw %xmm3,%xmm5
    152c:	pand   %xmm0,%xmm5
    1530:	packuswb %xmm4,%xmm5
    1534:	paddb  %xmm1,%xmm5
    1538:	movdqu %xmm5,(%rbx,%rcx,1)
    153d:	add    $0x10,%rcx
    1541:	paddb  %xmm6,%xmm2
    1545:	cmp    %rcx,%rax
    1548:	jne    1510 <packet_xor+0xc0>
    154a:	cmp    %rax,%r14
    154d:	je     173d <packet_xor+0x2ed>
    1553:	test   $0xc,%r14b
    1557:	je     1721 <packet_xor+0x2d1>
    155d:	mov    %r14,%rcx
    1560:	and    $0xfffffffffffffffc,%rcx
    1564:	movd   %eax,%xmm1
    1568:	punpcklbw %xmm1,%xmm1
    156c:	pshuflw $0x0,%xmm1,%xmm1
    1571:	por    0xaa7(%rip),%xmm1        # 2020 <_fini+0x550>
    1579:	movzbl %r15b,%edx
    157d:	movd   %edx,%xmm2
    1581:	punpcklbw %xmm2,%xmm2
    1585:	pshuflw $0x0,%xmm2,%xmm2
    158a:	movdqa 0xade(%rip),%xmm3        # 2070 <_fini+0x5a0>
    1592:	movdqa 0xa96(%rip),%xmm4        # 2030 <_fini+0x560>
    159a:	nopw   0x0(%rax,%rax,1)
    15a0:	movdqa %xmm1,%xmm5
    15a4:	punpcklbw %xmm5,%xmm5
    15a8:	pmullw %xmm3,%xmm5
    15ac:	pand   %xmm0,%xmm5
    15b0:	packuswb %xmm5,%xmm5
    15b4:	paddb  %xmm2,%xmm5
    15b8:	movd   %xmm5,(%rbx,%rax,1)
    15bd:	add    $0x4,%rax
    15c1:	paddb  %xmm4,%xmm1
    15c5:	cmp    %rax,%rcx
    15c8:	jne    15a0 <packet_xor+0x150>
    15ca:	cmp    %rcx,%r14
    15cd:	jne    1724 <packet_xor+0x2d4>
    15d3:	jmp    173d <packet_xor+0x2ed>
    15d8:	xor    %r15d,%r15d
    15db:	jmp    1a3f <packet_xor+0x5ef>
    15e0:	mov    $0x3e9,%r15d
    15e6:	jmp    1a3f <packet_xor+0x5ef>
    15eb:	movzbl %r15b,%ecx
    15ef:	cmp    $0x10,%r14
    15f3:	jae    15f9 <packet_xor+0x1a9>
    15f5:	xor    %eax,%eax
    15f7:	jmp    1643 <packet_xor+0x1f3>
    15f9:	mov    %r14d,%eax
    15fc:	and    $0x30,%eax
    15ff:	movd   %ecx,%xmm0
    1603:	punpcklbw %xmm0,%xmm0
    1607:	pshuflw $0x0,%xmm0,%xmm0
    160c:	pshufd $0x0,%xmm0,%xmm0
    1611:	movdqa 0xa67(%rip),%xmm1        # 2080 <_fini+0x5b0>
    1619:	paddb  %xmm0,%xmm1
    161d:	movdqu %xmm1,(%rbx)
    1621:	cmp    $0x10,%rax
    1625:	je     1634 <packet_xor+0x1e4>
    1627:	paddb  0xa61(%rip),%xmm0        # 2090 <_fini+0x5c0>
    162f:	movdqu %xmm0,0x10(%rbx)
    1634:	cmp    %rax,%r14
    1637:	je     16de <packet_xor+0x28e>
    163d:	test   $0xc,%r14b
    1641:	je     16bf <packet_xor+0x26f>
    1643:	mov    %rax,%rdx
    1646:	mov    %r14d,%eax
    1649:	and    $0x3c,%eax
    164c:	movd   %edx,%xmm0
    1650:	punpcklbw %xmm0,%xmm0
    1654:	pshuflw $0x0,%xmm0,%xmm0
    1659:	por    0x9bf(%rip),%xmm0        # 2020 <_fini+0x550>
    1661:	movd   %ecx,%xmm1
    1665:	punpcklbw %xmm1,%xmm1
    1669:	pshuflw $0x0,%xmm1,%xmm1
    166e:	movdqa 0x9fa(%rip),%xmm2        # 2070 <_fini+0x5a0>
    1676:	movdqa 0x9e2(%rip),%xmm3        # 2060 <_fini+0x590>
    167e:	movdqa 0x9aa(%rip),%xmm4        # 2030 <_fini+0x560>
    1686:	cs nopw 0x0(%rax,%rax,1)
    1690:	movdqa %xmm0,%xmm5
    1694:	punpcklbw %xmm5,%xmm5
    1698:	pmullw %xmm2,%xmm5
    169c:	pand   %xmm3,%xmm5
    16a0:	packuswb %xmm5,%xmm5
    16a4:	paddb  %xmm1,%xmm5
    16a8:	movd   %xmm5,(%rbx,%rdx,1)
    16ad:	add    $0x4,%rdx
    16b1:	paddb  %xmm4,%xmm0
    16b5:	cmp    %rdx,%rax
    16b8:	jne    1690 <packet_xor+0x240>
    16ba:	cmp    %rax,%r14
    16bd:	je     16de <packet_xor+0x28e>
    16bf:	lea    (%rax,%rax,2),%ecx
    16c2:	lea    (%rax,%rcx,4),%ecx
    16c5:	add    %r15b,%cl
    16c8:	nopl   0x0(%rax,%rax,1)
    16d0:	mov    %cl,(%rbx,%rax,1)
    16d3:	inc    %rax
    16d6:	add    $0xd,%cl
    16d9:	cmp    %rax,%r14
    16dc:	jne    16d0 <packet_xor+0x280>
    16de:	mov    $0x1,%edi
    16e3:	mov    %r14,%rsi
    16e6:	call   1050 <calloc@plt>
    16eb:	test   %rax,%rax
    16ee:	je     1705 <packet_xor+0x2b5>
    16f0:	xor    $0x5a,%r15b
    16f4:	movzbl %r15b,%ecx
    16f8:	cmp    $0x3,%r14
    16fc:	ja     1710 <packet_xor+0x2c0>
    16fe:	xor    %edx,%edx
    1700:	jmp    1a48 <packet_xor+0x5f8>
    1705:	mov    $0x3e9,%r15d
    170b:	jmp    1a37 <packet_xor+0x5e7>
    1710:	cmp    $0x10,%r14
    1714:	jae    193f <packet_xor+0x4ef>
    171a:	xor    %edx,%edx
    171c:	jmp    19a6 <packet_xor+0x556>
    1721:	mov    %rax,%rcx
    1724:	lea    (%rcx,%rcx,2),%eax
    1727:	lea    (%rcx,%rax,4),%eax
    172a:	add    %r15b,%al
    172d:	nopl   (%rax)
    1730:	mov    %al,(%rbx,%rcx,1)
    1733:	inc    %rcx
    1736:	add    $0xd,%al
    1738:	cmp    %rcx,%r14
    173b:	jne    1730 <packet_xor+0x2e0>
    173d:	test   %r14,%r14
    1740:	js     1758 <packet_xor+0x308>
    1742:	mov    $0x1,%edi
    1747:	mov    %r14,%rsi
    174a:	call   1050 <calloc@plt>
    174f:	test   %rax,%rax
    1752:	je     1775 <packet_xor+0x325>
    1754:	mov    $0x1,%cl
    1756:	jmp    1779 <packet_xor+0x329>
    1758:	xor    %eax,%eax
    175a:	xor    %ecx,%ecx
    175c:	test   $0x1,%cl
    175f:	jne    1786 <packet_xor+0x336>
    1761:	mov    $0x3e9,%r15d
    1767:	test   %rax,%rax
    176a:	jne    1a2f <packet_xor+0x5df>
    1770:	jmp    1a37 <packet_xor+0x5e7>
    1775:	xor    %eax,%eax
    1777:	xor    %ecx,%ecx
    1779:	movdqa 0x88f(%rip),%xmm6        # 2010 <_fini+0x540>
    1781:	test   $0x1,%cl
    1784:	je     1761 <packet_xor+0x311>
    1786:	xor    $0x5a,%r15b
    178a:	mov    %rax,%rcx
    178d:	sub    %rbx,%rcx
    1790:	cmp    $0xf,%rcx
    1794:	ja     1844 <packet_xor+0x3f4>
    179a:	xor    %edx,%edx
    179c:	mov    %r14,%rsi
    179f:	mov    %rdx,%rcx
    17a2:	and    $0x3,%rsi
    17a6:	je     17c7 <packet_xor+0x377>
    17a8:	lea    (%r15,%rdx,1),%edi
    17ac:	mov    %rdx,%rcx
    17af:	nop
    17b0:	movzbl (%rbx,%rcx,1),%r8d
    17b5:	xor    %dil,%r8b
    17b8:	mov    %r8b,(%rax,%rcx,1)
    17bc:	inc    %rcx
    17bf:	inc    %dil
    17c2:	dec    %rsi
    17c5:	jne    17b0 <packet_xor+0x360>
    17c7:	sub    %r14,%rdx
    17ca:	cmp    $0xfffffffffffffffc,%rdx
    17ce:	ja     18fc <packet_xor+0x4ac>
    17d4:	mov    %rax,%rdx
    17d7:	add    $0x3,%rdx
    17db:	movzbl %r15b,%esi
    17df:	lea    0x3(%rbx),%rdi
    17e3:	mov    %r14,%r8
    17e6:	cs nopw 0x0(%rax,%rax,1)
    17f0:	lea    (%rcx,%rsi,1),%r9d
    17f4:	movzbl -0x3(%rdi,%rcx,1),%r10d
    17fa:	xor    %r9b,%r10b
    17fd:	mov    %r10b,-0x3(%rdx,%rcx,1)
    1802:	lea    0x1(%r9),%r10d
    1806:	xor    -0x2(%rdi,%rcx,1),%r10b
    180b:	mov    %r10b,-0x2(%rdx,%rcx,1)
    1810:	lea    0x2(%r9),%r10d
    1814:	xor    -0x1(%rdi,%rcx,1),%r10b
    1819:	mov    %r10b,-0x1(%rdx,%rcx,1)
    181e:	add    $0x3,%r9b
    1822:	xor    (%rdi,%rcx,1),%r9b
    1826:	mov    %r9b,(%rdx,%rcx,1)
    182a:	add    $0xfffffffffffffffc,%r8
    182e:	add    $0x4,%rdx
    1832:	add    $0x4,%rsi
    1836:	add    $0x4,%rdi
    183a:	cmp    %r8,%rcx
    183d:	jne    17f0 <packet_xor+0x3a0>
    183f:	jmp    18fc <packet_xor+0x4ac>
    1844:	mov    %r14,%rcx
    1847:	and    $0xfffffffffffffff0,%rcx
    184b:	movzbl %r15b,%edx
    184f:	movd   %edx,%xmm0
    1853:	punpcklbw %xmm0,%xmm0
    1857:	pshuflw $0x0,%xmm0,%xmm0
    185c:	pshufd $0x0,%xmm0,%xmm1
    1861:	movdqa 0x797(%rip),%xmm2        # 2000 <_fini+0x530>
    1869:	xor    %edx,%edx
    186b:	nopl   0x0(%rax,%rax,1)
    1870:	movdqu (%rbx,%rdx,1),%xmm3
    1875:	movdqa %xmm1,%xmm4
    1879:	paddb  %xmm2,%xmm4
    187d:	pxor   %xmm3,%xmm4
    1881:	movdqu %xmm4,(%rax,%rdx,1)
    1886:	add    $0x10,%rdx
    188a:	paddb  %xmm6,%xmm2
    188e:	cmp    %rdx,%rcx
    1891:	jne    1870 <packet_xor+0x420>
    1893:	cmp    %rcx,%r14
    1896:	je     18fc <packet_xor+0x4ac>
    1898:	test   $0xc,%r14b
    189c:	je     1a05 <packet_xor+0x5b5>
    18a2:	mov    %r14,%rdx
    18a5:	and    $0xfffffffffffffffc,%rdx
    18a9:	movd   %ecx,%xmm1
    18ad:	punpcklbw %xmm1,%xmm1
    18b1:	pshuflw $0x0,%xmm1,%xmm1
    18b6:	por    0x762(%rip),%xmm1        # 2020 <_fini+0x550>
    18be:	movdqa 0x76a(%rip),%xmm2        # 2030 <_fini+0x560>
    18c6:	cs nopw 0x0(%rax,%rax,1)
    18d0:	movd   (%rbx,%rcx,1),%xmm3
    18d5:	movdqa %xmm0,%xmm4
    18d9:	paddb  %xmm1,%xmm4
    18dd:	pxor   %xmm3,%xmm4
    18e1:	movd   %xmm4,(%rax,%rcx,1)
    18e6:	add    $0x4,%rcx
    18ea:	paddb  %xmm2,%xmm1
    18ee:	cmp    %rcx,%rdx
    18f1:	jne    18d0 <packet_xor+0x480>
    18f3:	cmp    %rdx,%r14
    18f6:	jne    179c <packet_xor+0x34c>
    18fc:	xor    %ecx,%ecx
    18fe:	xor    %r15d,%r15d
    1901:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    1910:	mov    %r15,%rdx
    1913:	movzbl (%rax,%rcx,1),%r15d
    1918:	add    %rdx,%r15
    191b:	jb     1a0d <packet_xor+0x5bd>
    1921:	inc    %rcx
    1924:	cmp    %rcx,%r14
    1927:	jne    1910 <packet_xor+0x4c0>
    1929:	mov    %rax,%rdi
    192c:	call   1030 <free@plt>
    1931:	test   %rbx,%rbx
    1934:	jne    1a37 <packet_xor+0x5e7>
    193a:	jmp    1a3f <packet_xor+0x5ef>
    193f:	mov    %r14d,%edx
    1942:	and    $0x30,%edx
    1945:	movd   %ecx,%xmm0
    1949:	punpcklbw %xmm0,%xmm0
    194d:	pshuflw $0x0,%xmm0,%xmm0
    1952:	pshufd $0x0,%xmm0,%xmm0
    1957:	movdqa 0x6a1(%rip),%xmm1        # 2000 <_fini+0x530>
    195f:	xor    %esi,%esi
    1961:	movdqa 0x6a7(%rip),%xmm2        # 2010 <_fini+0x540>
    1969:	nopl   0x0(%rax)
    1970:	movdqu (%rbx,%rsi,1),%xmm3
    1975:	movdqa %xmm0,%xmm4
    1979:	paddb  %xmm1,%xmm4
    197d:	pxor   %xmm3,%xmm4
    1981:	movdqu %xmm4,(%rax,%rsi,1)
    1986:	add    $0x10,%rsi
    198a:	paddb  %xmm2,%xmm1
    198e:	cmp    %rsi,%rdx
    1991:	jne    1970 <packet_xor+0x520>
    1993:	cmp    %rdx,%r14
    1996:	je     1a5b <packet_xor+0x60b>
    199c:	test   $0xc,%r14b
    19a0:	je     1a48 <packet_xor+0x5f8>
    19a6:	mov    %rdx,%rsi
    19a9:	mov    %r14d,%edx
    19ac:	and    $0x3c,%edx
    19af:	movd   %esi,%xmm0
    19b3:	punpcklbw %xmm0,%xmm0
    19b7:	pshuflw $0x0,%xmm0,%xmm0
    19bc:	por    0x65c(%rip),%xmm0        # 2020 <_fini+0x550>
    19c4:	movd   %ecx,%xmm1
    19c8:	punpcklbw %xmm1,%xmm1
    19cc:	pshuflw $0x0,%xmm1,%xmm1
    19d1:	movdqa 0x657(%rip),%xmm2        # 2030 <_fini+0x560>
    19d9:	nopl   0x0(%rax)
    19e0:	movd   (%rbx,%rsi,1),%xmm3
    19e5:	movdqa %xmm1,%xmm4
    19e9:	paddb  %xmm0,%xmm4
    19ed:	pxor   %xmm3,%xmm4
    19f1:	movd   %xmm4,(%rax,%rsi,1)
    19f6:	add    $0x4,%rsi
    19fa:	paddb  %xmm2,%xmm0
    19fe:	cmp    %rsi,%rdx
    1a01:	jne    19e0 <packet_xor+0x590>
    1a03:	jmp    1a56 <packet_xor+0x606>
    1a05:	mov    %rcx,%rdx
    1a08:	jmp    179c <packet_xor+0x34c>
    1a0d:	call   1040 <abort@plt>
    1a12:	test   %rcx,%rcx
    1a15:	je     1a2f <packet_xor+0x5df>
    1a17:	mov    %rax,%rsi
    1a1a:	add    %rdx,%rsi
    1a1d:	xor    %edx,%edx
    1a1f:	nop
    1a20:	movzbl (%rsi,%rdx,1),%edi
    1a24:	add    %rdi,%r15
    1a27:	inc    %rdx
    1a2a:	cmp    %rdx,%rcx
    1a2d:	jne    1a20 <packet_xor+0x5d0>
    1a2f:	mov    %rax,%rdi
    1a32:	call   1030 <free@plt>
    1a37:	mov    %rbx,%rdi
    1a3a:	call   1030 <free@plt>
    1a3f:	mov    %r15,%rax
    1a42:	pop    %rbx
    1a43:	pop    %r14
    1a45:	pop    %r15
    1a47:	ret
    1a48:	lea    (%rcx,%rdx,1),%esi
    1a4b:	xor    (%rbx,%rdx,1),%sil
    1a4f:	mov    %sil,(%rax,%rdx,1)
    1a53:	inc    %rdx
    1a56:	cmp    %rdx,%r14
    1a59:	jne    1a48 <packet_xor+0x5f8>
    1a5b:	lea    -0x1(%r14),%rdx
    1a5f:	mov    %r14d,%ecx
    1a62:	and    $0x7,%ecx
    1a65:	cmp    $0x7,%rdx
    1a69:	jae    1a72 <packet_xor+0x622>
    1a6b:	xor    %edx,%edx
    1a6d:	xor    %r15d,%r15d
    1a70:	jmp    1a12 <packet_xor+0x5c2>
    1a72:	and    $0x38,%r14d
    1a76:	xor    %edx,%edx
    1a78:	xor    %r15d,%r15d
    1a7b:	nopl   0x0(%rax,%rax,1)
    1a80:	movzbl (%rax,%rdx,1),%esi
    1a84:	add    %r15,%rsi
    1a87:	movzbl 0x1(%rax,%rdx,1),%edi
    1a8c:	movzbl 0x2(%rax,%rdx,1),%r8d
    1a92:	add    %rdi,%r8
    1a95:	add    %rsi,%r8
    1a98:	movzbl 0x3(%rax,%rdx,1),%esi
    1a9d:	movzbl 0x4(%rax,%rdx,1),%edi
    1aa2:	add    %rsi,%rdi
    1aa5:	movzbl 0x5(%rax,%rdx,1),%esi
    1aaa:	add    %rdi,%rsi
    1aad:	add    %r8,%rsi
    1ab0:	movzbl 0x6(%rax,%rdx,1),%edi
    1ab5:	movzbl 0x7(%rax,%rdx,1),%r15d
    1abb:	add    %rdi,%r15
    1abe:	add    %rsi,%r15
    1ac1:	add    $0x8,%rdx
    1ac5:	cmp    %rdx,%r14
    1ac8:	jne    1a80 <packet_xor+0x630>
    1aca:	jmp    1a12 <packet_xor+0x5c2>

Disassembly of section .fini:

0000000000001ad0 <_fini>:
    1ad0:	endbr64
    1ad4:	sub    $0x8,%rsp
    1ad8:	add    $0x8,%rsp
    1adc:	ret
