#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <time.h>
typedef uint32_t (*kernel_t)(uint32_t, uint32_t);
static uint64_t now(clockid_t kind) {
    struct timespec t;
    if (clock_gettime(kind, &t)) exit(81);
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + (uint64_t)t.tv_nsec;
}
static uint32_t step(uint32_t x) { return x * UINT32_C(1664525) + UINT32_C(1013904223); }
static uint64_t integer(const char *text) {
    if (!*text) exit(82);
    uint64_t out = 0;
    for (; *text; ++text) {
        if (*text < '0' || *text > '9' || out > UINT64_C(429496729)) exit(82);
        out = out * 10 + (uint64_t)(*text - '0');
    }
    if (out > UINT32_MAX) exit(82);
    return out;
}
static void limit(int resource, rlim_t value) {
    struct rlimit l = {value, value};
    if (setrlimit(resource, &l)) exit(83);
}
static uint64_t batch(kernel_t kernel, uint32_t calls, uint32_t seed, uint32_t hot) {
    uint64_t checksum = 0;
    uint32_t x = seed;
    for (uint32_t i = 0; i < calls; ++i) {
        x = step(x);
        uint32_t denominator = i % 10 < 9 ? hot : (x >> 16) % 251 + 1;
        checksum += kernel(x, denominator);
    }
    return checksum;
}
int main(int argc, char **argv) {
    if (argc != 6) return 84;
    uint32_t calls = integer(argv[2]), warmup = integer(argv[3]);
    uint32_t seed = integer(argv[4]), hot = integer(argv[5]);
    if (!calls || calls > 1000000 || warmup > 100000 || (hot != 8 && hot != 10)) return 85;
    limit(RLIMIT_CORE, 0);
    limit(RLIMIT_CPU, 3);
    limit(RLIMIT_FSIZE, 4096);
    limit(RLIMIT_AS, (rlim_t)1024 * 1024 * 1024);
    uint64_t loading = now(CLOCK_MONOTONIC);
    void *library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) return 86;
    kernel_t kernel = (kernel_t)dlsym(library, "calculate");
    if (!kernel) return 87;
    uint64_t load_ns = now(CLOCK_MONOTONIC) - loading;
    volatile uint64_t warming = batch(kernel, warmup, seed, hot);
    (void)warming;
    uint64_t cpu = now(CLOCK_PROCESS_CPUTIME_ID), start = now(CLOCK_MONOTONIC);
    uint64_t checksum = batch(kernel, calls, seed, hot);
    uint64_t elapsed_ns = now(CLOCK_MONOTONIC) - start;
    uint64_t cpu_ns = now(CLOCK_PROCESS_CPUTIME_ID) - cpu;
    uint64_t closing = now(CLOCK_MONOTONIC);
    if (dlclose(library)) return 88;
    uint64_t close_ns = now(CLOCK_MONOTONIC) - closing;
    printf("{\"calls\":%" PRIu32 ",\"checksum\":%" PRIu64 ",\"close_ns\":%" PRIu64
           ",\"cpu_ns\":%" PRIu64 ",\"elapsed_ns\":%" PRIu64 ",\"hot\":%" PRIu32
           ",\"load_ns\":%" PRIu64 ",\"seed\":%" PRIu32 "}\n",
           calls, checksum, close_ns, cpu_ns, elapsed_ns, hot, load_ns, seed);
    return 0;
}
