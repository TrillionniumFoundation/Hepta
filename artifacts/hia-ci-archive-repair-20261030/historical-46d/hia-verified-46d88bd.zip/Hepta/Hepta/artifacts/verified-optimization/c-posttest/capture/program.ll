; Standalone HIA: verified core -> LLVM. No source AST or Rust safety gate.
target triple = "x86_64-unknown-linux-gnu"
%hia.buffer = type { ptr, i64 }
%hia.alloc = type { %hia.buffer, i1 }
declare void @abort() noreturn
declare noalias ptr @calloc(i64, i64) "no-builtins"
declare noalias ptr @malloc(i64) "no-builtins"
declare void @free(ptr) "no-builtins"
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64)

; A failed allocation is an empty, valid owner plus false. Zero length succeeds.
; The independent verifier still requires every resulting owner to be consumed.
define internal %hia.alloc @__hia_allocate(i64 %length, i1 %zero_bytes) {
entry:
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %empty, label %nonempty
empty:
  %empty_result = insertvalue %hia.alloc zeroinitializer, i1 true, 1
  ret %hia.alloc %empty_result
nonempty:
  %valid = icmp ule i64 %length, 9223372036854775807
  br i1 %valid, label %allocate, label %failed
allocate:
  br i1 %zero_bytes, label %zeroed, label %unread
zeroed:
  %zero_pointer = call ptr @calloc(i64 1, i64 %length) nobuiltin
  br label %allocated
unread:
  %unread_pointer = call ptr @malloc(i64 %length) nobuiltin
  br label %allocated
allocated:
  %pointer = phi ptr [ %zero_pointer, %zeroed ], [ %unread_pointer, %unread ]
  %success = icmp ne ptr %pointer, null
  br i1 %success, label %ready, label %failed
ready:
  %b0 = insertvalue %hia.buffer zeroinitializer, ptr %pointer, 0
  %b1 = insertvalue %hia.buffer %b0, i64 %length, 1
  %r0 = insertvalue %hia.alloc zeroinitializer, %hia.buffer %b1, 0
  %r1 = insertvalue %hia.alloc %r0, i1 true, 1
  ret %hia.alloc %r1
failed:
  ret %hia.alloc zeroinitializer
}

define internal i32 @__hia_fn_0(i1 %p_0_0) {
b0:
  br i1 %p_0_0, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i1 [ %p_0_0, %edge_0 ]
  ret i32 1
b2:
  %p_2_0 = phi i1 [ %p_0_0, %edge_1 ]
  ret i32 0
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i64 @__hia_fn_1(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2) {
b0:
  %t1 = icmp ult i64 %p_0_0, %p_0_2
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_5 = phi i1 [ %t1, %edge_0 ]
  %t2 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %p_1_2, i64 %p_1_0)
  %t3 = extractvalue { i64, i1 } %t2, 0
  %t4 = extractvalue { i64, i1 } %t2, 1
  %t5 = xor i1 %t4, true
  br i1 %t5, label %ok_6, label %trap_6
trap_6:
  call void @abort()
  unreachable
ok_6:
  %t7 = icmp ult i64 %p_1_1, %t3
  br i1 %t7, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_5 = phi i1 [ %t1, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_6 = phi i64 [ %t3, %edge_2 ]
  %p_3_7 = phi i64 [ %t3, %edge_2 ]
  %p_3_8 = phi i1 [ %t7, %edge_2 ]
  %t8 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_3_0, i64 %p_3_1)
  %t9 = extractvalue { i64, i1 } %t8, 0
  %t10 = extractvalue { i64, i1 } %t8, 1
  %t11 = xor i1 %t10, true
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  ret i64 %t9
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_4 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_6 = phi i64 [ %t3, %edge_3 ]
  %p_4_7 = phi i64 [ %t3, %edge_3 ]
  %p_4_8 = phi i1 [ %t7, %edge_3 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
}

define internal i64 @__hia_fn_2(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2) {
b0:
  %t1 = icmp sge i64 %p_0_1, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %t2 = icmp ult i64 %p_1_0, %p_1_2
  br i1 %t2, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %t3 = sub i64 0, %p_2_1
  %t4 = icmp ule i64 %t3, %p_2_0
  br i1 %t4, label %edge_4, label %edge_5
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_5 = phi i1 [ %t2, %edge_2 ]
  %t5 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %p_3_2, i64 %p_3_0)
  %t6 = extractvalue { i64, i1 } %t5, 0
  %t7 = extractvalue { i64, i1 } %t5, 1
  %t8 = xor i1 %t7, true
  br i1 %t8, label %ok_9, label %trap_9
trap_9:
  call void @abort()
  unreachable
ok_9:
  %t10 = icmp ult i64 %p_3_1, %t6
  br i1 %t10, label %edge_6, label %edge_7
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_4 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_5 = phi i1 [ %t2, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_6 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_6 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_6 ]
  %p_5_3 = phi i64 [ %p_3_1, %edge_6 ]
  %p_5_4 = phi i64 [ %p_3_1, %edge_6 ]
  %p_5_5 = phi i64 [ %p_3_2, %edge_6 ]
  %p_5_6 = phi i64 [ %p_3_0, %edge_6 ]
  %p_5_7 = phi i64 [ %t6, %edge_6 ]
  %p_5_8 = phi i64 [ %t6, %edge_6 ]
  %p_5_9 = phi i1 [ %t10, %edge_6 ]
  %t11 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_5_0, i64 %p_5_1)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  ret i64 %t12
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_7 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_7 ]
  %p_6_2 = phi i64 [ %p_3_2, %edge_7 ]
  %p_6_3 = phi i64 [ %p_3_1, %edge_7 ]
  %p_6_4 = phi i64 [ %p_3_1, %edge_7 ]
  %p_6_5 = phi i64 [ %p_3_2, %edge_7 ]
  %p_6_6 = phi i64 [ %p_3_0, %edge_7 ]
  %p_6_7 = phi i64 [ %t6, %edge_7 ]
  %p_6_8 = phi i64 [ %t6, %edge_7 ]
  %p_6_9 = phi i1 [ %t10, %edge_7 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i64 [ %p_2_0, %edge_4 ]
  %p_7_1 = phi i64 [ %p_2_1, %edge_4 ]
  %p_7_2 = phi i64 [ %p_2_2, %edge_4 ]
  %p_7_3 = phi i64 [ %t3, %edge_4 ]
  %p_7_4 = phi i64 [ %t3, %edge_4 ]
  %p_7_5 = phi i64 [ %p_2_0, %edge_4 ]
  %p_7_6 = phi i64 [ %p_2_0, %edge_4 ]
  %p_7_7 = phi i1 [ %t4, %edge_4 ]
  %t16 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %p_7_0, i64 %p_7_3)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  %t19 = xor i1 %t18, true
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = icmp ult i64 %t17, %p_7_2
  br i1 %t21, label %edge_8, label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_2_0, %edge_5 ]
  %p_8_1 = phi i64 [ %p_2_1, %edge_5 ]
  %p_8_2 = phi i64 [ %p_2_2, %edge_5 ]
  %p_8_3 = phi i64 [ %t3, %edge_5 ]
  %p_8_4 = phi i64 [ %t3, %edge_5 ]
  %p_8_5 = phi i64 [ %p_2_0, %edge_5 ]
  %p_8_6 = phi i64 [ %p_2_0, %edge_5 ]
  %p_8_7 = phi i1 [ %t4, %edge_5 ]
  call void @abort()
  unreachable
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_8 ]
  %p_9_1 = phi i64 [ %p_7_1, %edge_8 ]
  %p_9_2 = phi i64 [ %p_7_2, %edge_8 ]
  %p_9_3 = phi i64 [ %p_7_3, %edge_8 ]
  %p_9_4 = phi i64 [ %t17, %edge_8 ]
  %p_9_5 = phi i64 [ %t17, %edge_8 ]
  %p_9_6 = phi i64 [ %p_7_2, %edge_8 ]
  %p_9_7 = phi i1 [ %t21, %edge_8 ]
  ret i64 %p_9_4
b10:
  %p_10_0 = phi i64 [ %p_7_0, %edge_9 ]
  %p_10_1 = phi i64 [ %p_7_1, %edge_9 ]
  %p_10_2 = phi i64 [ %p_7_2, %edge_9 ]
  %p_10_3 = phi i64 [ %p_7_3, %edge_9 ]
  %p_10_4 = phi i64 [ %t17, %edge_9 ]
  %p_10_5 = phi i64 [ %t17, %edge_9 ]
  %p_10_6 = phi i64 [ %p_7_2, %edge_9 ]
  %p_10_7 = phi i1 [ %t21, %edge_9 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b7
edge_5:
  br label %b8
edge_6:
  br label %b5
edge_7:
  br label %b6
edge_8:
  br label %b9
edge_9:
  br label %b10
}

define internal i32 @__hia_fn_3(%hia.buffer %p_0_0, i64 %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = icmp ule i64 %p_0_1, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_6 = phi i64 [ %t1, %edge_0 ]
  %p_1_7 = phi i1 [ %t2, %edge_0 ]
  %t3 = extractvalue %hia.buffer %p_1_0, 1
  %t4 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t3, i64 %p_1_1)
  %t5 = extractvalue { i64, i1 } %t4, 0
  %t6 = extractvalue { i64, i1 } %t4, 1
  %t7 = xor i1 %t6, true
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = icmp ule i64 %p_1_4, %t5
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_6 = phi i64 [ %t1, %edge_1 ]
  %p_2_7 = phi i1 [ %t2, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_7 = phi i64 [ %t3, %edge_2 ]
  %p_3_8 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_9 = phi i64 [ %t5, %edge_2 ]
  %p_3_10 = phi i1 [ %t9, %edge_2 ]
  %t10 = extractvalue %hia.buffer %p_3_2, 1
  %t11 = icmp ule i64 %p_3_3, %t10
  br i1 %t11, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi %hia.buffer [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_7 = phi i64 [ %t3, %edge_3 ]
  %p_4_8 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_9 = phi i64 [ %t5, %edge_3 ]
  %p_4_10 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi %hia.buffer [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_6 = phi i64 [ %t10, %edge_4 ]
  %p_5_7 = phi i1 [ %t11, %edge_4 ]
  %t12 = extractvalue %hia.buffer %p_5_2, 1
  %t13 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t12, i64 %p_5_3)
  %t14 = extractvalue { i64, i1 } %t13, 0
  %t15 = extractvalue { i64, i1 } %t13, 1
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = icmp ule i64 %p_5_4, %t14
  br i1 %t18, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi %hia.buffer [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi %hia.buffer [ %p_3_2, %edge_5 ]
  %p_6_3 = phi i64 [ %p_3_3, %edge_5 ]
  %p_6_4 = phi i64 [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_3, %edge_5 ]
  %p_6_6 = phi i64 [ %t10, %edge_5 ]
  %p_6_7 = phi i1 [ %t11, %edge_5 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi %hia.buffer [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_6 ]
  %p_7_3 = phi i64 [ %p_5_3, %edge_6 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_6 ]
  %p_7_5 = phi i64 [ %p_5_4, %edge_6 ]
  %p_7_6 = phi i64 [ %p_5_4, %edge_6 ]
  %p_7_7 = phi i64 [ %t12, %edge_6 ]
  %p_7_8 = phi i64 [ %p_5_3, %edge_6 ]
  %p_7_9 = phi i64 [ %t14, %edge_6 ]
  %p_7_10 = phi i1 [ %t18, %edge_6 ]
  %t19 = call i32 @__hia_fn_5(%hia.buffer %p_7_0, i64 %p_7_1, %hia.buffer %p_7_2, i64 %p_7_3, i64 %p_7_4)
  ret i32 %t19
b8:
  %p_8_0 = phi %hia.buffer [ %p_5_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_8_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_8_3 = phi i64 [ %p_5_3, %edge_7 ]
  %p_8_4 = phi i64 [ %p_5_4, %edge_7 ]
  %p_8_5 = phi i64 [ %p_5_4, %edge_7 ]
  %p_8_6 = phi i64 [ %p_5_4, %edge_7 ]
  %p_8_7 = phi i64 [ %t12, %edge_7 ]
  %p_8_8 = phi i64 [ %p_5_3, %edge_7 ]
  %p_8_9 = phi i64 [ %t14, %edge_7 ]
  %p_8_10 = phi i1 [ %t18, %edge_7 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
}

define internal i32 @__hia_fn_4(i32 %p_0_0, i8 %p_0_1, i32 %p_0_2) {
b0:
  %t1 = zext i8 %p_0_1 to i32
  %t2 = xor i32 %p_0_0, %t1
  %t3 = trunc i64 0 to i32
  br label %edge_0
b1:
  %p_1_0 = phi i32 [ %p_0_0, %edge_0 ], [ %p_9_0, %edge_11 ]
  %p_1_1 = phi i8 [ %p_0_1, %edge_0 ], [ %p_9_1, %edge_11 ]
  %p_1_2 = phi i32 [ %p_0_2, %edge_0 ], [ %p_9_2, %edge_11 ]
  %p_1_3 = phi i32 [ %p_0_0, %edge_0 ], [ %p_9_3, %edge_11 ]
  %p_1_4 = phi i8 [ %p_0_1, %edge_0 ], [ %p_9_4, %edge_11 ]
  %p_1_5 = phi i32 [ %p_0_2, %edge_0 ], [ %p_9_5, %edge_11 ]
  %p_1_6 = phi i32 [ %t2, %edge_0 ], [ %p_9_6, %edge_11 ]
  %p_1_7 = phi i32 [ %t3, %edge_0 ], [ %t20, %edge_11 ]
  %p_1_8 = phi i1 [ true, %edge_0 ], [ %p_9_8, %edge_11 ]
  br i1 %p_1_8, label %edge_1, label %edge_2
b2:
  %p_2_0 = phi i32 [ %p_1_0, %edge_2 ]
  %p_2_1 = phi i8 [ %p_1_1, %edge_2 ]
  %p_2_2 = phi i32 [ %p_1_2, %edge_2 ]
  %p_2_3 = phi i32 [ %p_1_3, %edge_2 ]
  %p_2_4 = phi i8 [ %p_1_4, %edge_2 ]
  %p_2_5 = phi i32 [ %p_1_5, %edge_2 ]
  %p_2_6 = phi i32 [ %p_1_6, %edge_2 ]
  %p_2_7 = phi i32 [ %p_1_7, %edge_2 ]
  %p_2_8 = phi i1 [ %p_1_8, %edge_2 ]
  %p_2_9 = phi i1 [ %p_1_8, %edge_2 ]
  %p_2_10 = phi i1 [ %p_1_8, %edge_2 ]
  %t4 = trunc i64 8 to i32
  %t5 = icmp ult i32 %p_2_7, %t4
  br label %edge_3
b3:
  %p_3_0 = phi i32 [ %p_1_0, %edge_1 ]
  %p_3_1 = phi i8 [ %p_1_1, %edge_1 ]
  %p_3_2 = phi i32 [ %p_1_2, %edge_1 ]
  %p_3_3 = phi i32 [ %p_1_3, %edge_1 ]
  %p_3_4 = phi i8 [ %p_1_4, %edge_1 ]
  %p_3_5 = phi i32 [ %p_1_5, %edge_1 ]
  %p_3_6 = phi i32 [ %p_1_6, %edge_1 ]
  %p_3_7 = phi i32 [ %p_1_7, %edge_1 ]
  %p_3_8 = phi i1 [ %p_1_8, %edge_1 ]
  %p_3_9 = phi i1 [ %p_1_8, %edge_1 ]
  %p_3_10 = phi i1 [ %p_1_8, %edge_1 ]
  br label %edge_4
b4:
  %p_4_0 = phi i32 [ %p_2_0, %edge_3 ], [ %p_3_0, %edge_4 ]
  %p_4_1 = phi i8 [ %p_2_1, %edge_3 ], [ %p_3_1, %edge_4 ]
  %p_4_2 = phi i32 [ %p_2_2, %edge_3 ], [ %p_3_2, %edge_4 ]
  %p_4_3 = phi i32 [ %p_2_3, %edge_3 ], [ %p_3_3, %edge_4 ]
  %p_4_4 = phi i8 [ %p_2_4, %edge_3 ], [ %p_3_4, %edge_4 ]
  %p_4_5 = phi i32 [ %p_2_5, %edge_3 ], [ %p_3_5, %edge_4 ]
  %p_4_6 = phi i32 [ %p_2_6, %edge_3 ], [ %p_3_6, %edge_4 ]
  %p_4_7 = phi i32 [ %p_2_7, %edge_3 ], [ %p_3_7, %edge_4 ]
  %p_4_8 = phi i1 [ %p_2_8, %edge_3 ], [ %p_3_8, %edge_4 ]
  %p_4_9 = phi i1 [ %p_2_9, %edge_3 ], [ %p_3_9, %edge_4 ]
  %p_4_10 = phi i1 [ %t5, %edge_3 ], [ %p_3_9, %edge_4 ]
  br i1 %p_4_10, label %edge_5, label %edge_6
b5:
  %p_5_0 = phi i32 [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i8 [ %p_4_1, %edge_5 ]
  %p_5_2 = phi i32 [ %p_4_2, %edge_5 ]
  %p_5_3 = phi i32 [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i8 [ %p_4_4, %edge_5 ]
  %p_5_5 = phi i32 [ %p_4_5, %edge_5 ]
  %p_5_6 = phi i32 [ %p_4_6, %edge_5 ]
  %p_5_7 = phi i32 [ %p_4_7, %edge_5 ]
  %p_5_8 = phi i1 [ %p_4_8, %edge_5 ]
  %t6 = trunc i64 1 to i32
  %t7 = and i32 %p_5_6, %t6
  %t8 = trunc i64 0 to i32
  %t9 = icmp ne i32 %t7, %t8
  br i1 %t9, label %edge_7, label %edge_8
b6:
  %p_6_0 = phi i32 [ %p_4_0, %edge_6 ]
  %p_6_1 = phi i8 [ %p_4_1, %edge_6 ]
  %p_6_2 = phi i32 [ %p_4_2, %edge_6 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_6 ]
  %p_6_4 = phi i8 [ %p_4_4, %edge_6 ]
  %p_6_5 = phi i32 [ %p_4_5, %edge_6 ]
  %p_6_6 = phi i32 [ %p_4_6, %edge_6 ]
  %p_6_7 = phi i32 [ %p_4_7, %edge_6 ]
  %p_6_8 = phi i1 [ %p_4_8, %edge_6 ]
  ret i32 %p_6_6
b7:
  %p_7_0 = phi i32 [ %p_5_0, %edge_7 ]
  %p_7_1 = phi i8 [ %p_5_1, %edge_7 ]
  %p_7_2 = phi i32 [ %p_5_2, %edge_7 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_7 ]
  %p_7_4 = phi i8 [ %p_5_4, %edge_7 ]
  %p_7_5 = phi i32 [ %p_5_5, %edge_7 ]
  %p_7_6 = phi i32 [ %p_5_6, %edge_7 ]
  %p_7_7 = phi i32 [ %p_5_7, %edge_7 ]
  %p_7_8 = phi i1 [ false, %edge_7 ]
  %t10 = trunc i64 1 to i32
  %t11 = icmp ult i32 %t10, 32
  br i1 %t11, label %ok_12, label %trap_12
trap_12:
  call void @abort()
  unreachable
ok_12:
  %t13 = lshr i32 %p_7_6, %t10
  %t14 = xor i32 %t13, %p_7_5
  br label %edge_9
b8:
  %p_8_0 = phi i32 [ %p_5_0, %edge_8 ]
  %p_8_1 = phi i8 [ %p_5_1, %edge_8 ]
  %p_8_2 = phi i32 [ %p_5_2, %edge_8 ]
  %p_8_3 = phi i32 [ %p_5_3, %edge_8 ]
  %p_8_4 = phi i8 [ %p_5_4, %edge_8 ]
  %p_8_5 = phi i32 [ %p_5_5, %edge_8 ]
  %p_8_6 = phi i32 [ %p_5_6, %edge_8 ]
  %p_8_7 = phi i32 [ %p_5_7, %edge_8 ]
  %p_8_8 = phi i1 [ false, %edge_8 ]
  %t15 = trunc i64 1 to i32
  %t16 = icmp ult i32 %t15, 32
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = lshr i32 %p_8_6, %t15
  br label %edge_10
b9:
  %p_9_0 = phi i32 [ %p_7_0, %edge_9 ], [ %p_8_0, %edge_10 ]
  %p_9_1 = phi i8 [ %p_7_1, %edge_9 ], [ %p_8_1, %edge_10 ]
  %p_9_2 = phi i32 [ %p_7_2, %edge_9 ], [ %p_8_2, %edge_10 ]
  %p_9_3 = phi i32 [ %p_7_3, %edge_9 ], [ %p_8_3, %edge_10 ]
  %p_9_4 = phi i8 [ %p_7_4, %edge_9 ], [ %p_8_4, %edge_10 ]
  %p_9_5 = phi i32 [ %p_7_5, %edge_9 ], [ %p_8_5, %edge_10 ]
  %p_9_6 = phi i32 [ %t14, %edge_9 ], [ %t18, %edge_10 ]
  %p_9_7 = phi i32 [ %p_7_7, %edge_9 ], [ %p_8_7, %edge_10 ]
  %p_9_8 = phi i1 [ %p_7_8, %edge_9 ], [ %p_8_8, %edge_10 ]
  %t19 = trunc i64 1 to i32
  %t20 = add i32 %p_9_7, %t19
  br label %edge_11
edge_0:
  br label %b1
edge_1:
  br label %b3
edge_2:
  br label %b2
edge_3:
  br label %b4
edge_4:
  br label %b4
edge_5:
  br label %b5
edge_6:
  br label %b6
edge_7:
  br label %b7
edge_8:
  br label %b8
edge_9:
  br label %b9
edge_10:
  br label %b9
edge_11:
  br label %b1
}

define internal i32 @__hia_fn_5(%hia.buffer %p_0_0, i64 %p_0_1, %hia.buffer %p_0_2, i64 %p_0_3, i64 %p_0_4) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_0, 1
  %t2 = icmp ule i64 %p_0_1, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi %hia.buffer [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi %hia.buffer [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i64 [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_6 = phi i64 [ %t1, %edge_0 ]
  %p_1_7 = phi i1 [ %t2, %edge_0 ]
  %t3 = extractvalue %hia.buffer %p_1_0, 1
  %t4 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t3, i64 %p_1_1)
  %t5 = extractvalue { i64, i1 } %t4, 0
  %t6 = extractvalue { i64, i1 } %t4, 1
  %t7 = xor i1 %t6, true
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = icmp ule i64 %p_1_4, %t5
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi %hia.buffer [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi %hia.buffer [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i64 [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_6 = phi i64 [ %t1, %edge_1 ]
  %p_2_7 = phi i1 [ %t2, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi %hia.buffer [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi %hia.buffer [ %p_1_2, %edge_2 ]
  %p_3_3 = phi i64 [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_7 = phi i64 [ %t3, %edge_2 ]
  %p_3_8 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_9 = phi i64 [ %t5, %edge_2 ]
  %p_3_10 = phi i1 [ %t9, %edge_2 ]
  %t10 = extractvalue %hia.buffer %p_3_2, 1
  %t11 = icmp ule i64 %p_3_3, %t10
  br i1 %t11, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi %hia.buffer [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi %hia.buffer [ %p_1_2, %edge_3 ]
  %p_4_3 = phi i64 [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_7 = phi i64 [ %t3, %edge_3 ]
  %p_4_8 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_9 = phi i64 [ %t5, %edge_3 ]
  %p_4_10 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi %hia.buffer [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi %hia.buffer [ %p_3_2, %edge_4 ]
  %p_5_3 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_3, %edge_4 ]
  %p_5_6 = phi i64 [ %t10, %edge_4 ]
  %p_5_7 = phi i1 [ %t11, %edge_4 ]
  %t12 = extractvalue %hia.buffer %p_5_2, 1
  %t13 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t12, i64 %p_5_3)
  %t14 = extractvalue { i64, i1 } %t13, 0
  %t15 = extractvalue { i64, i1 } %t13, 1
  %t16 = xor i1 %t15, true
  br i1 %t16, label %ok_17, label %trap_17
trap_17:
  call void @abort()
  unreachable
ok_17:
  %t18 = icmp ule i64 %p_5_4, %t14
  br i1 %t18, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi %hia.buffer [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi %hia.buffer [ %p_3_2, %edge_5 ]
  %p_6_3 = phi i64 [ %p_3_3, %edge_5 ]
  %p_6_4 = phi i64 [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_3, %edge_5 ]
  %p_6_6 = phi i64 [ %t10, %edge_5 ]
  %p_6_7 = phi i1 [ %t11, %edge_5 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi %hia.buffer [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi %hia.buffer [ %p_5_2, %edge_6 ]
  %p_7_3 = phi i64 [ %p_5_3, %edge_6 ]
  %p_7_4 = phi i64 [ %p_5_4, %edge_6 ]
  %p_7_5 = phi i64 [ %p_5_4, %edge_6 ]
  %p_7_6 = phi i64 [ %p_5_4, %edge_6 ]
  %p_7_7 = phi i64 [ %t12, %edge_6 ]
  %p_7_8 = phi i64 [ %p_5_3, %edge_6 ]
  %p_7_9 = phi i64 [ %t14, %edge_6 ]
  %p_7_10 = phi i1 [ %t18, %edge_6 ]
  br label %edge_8
b8:
  %p_8_0 = phi %hia.buffer [ %p_5_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_8_2 = phi %hia.buffer [ %p_5_2, %edge_7 ]
  %p_8_3 = phi i64 [ %p_5_3, %edge_7 ]
  %p_8_4 = phi i64 [ %p_5_4, %edge_7 ]
  %p_8_5 = phi i64 [ %p_5_4, %edge_7 ]
  %p_8_6 = phi i64 [ %p_5_4, %edge_7 ]
  %p_8_7 = phi i64 [ %t12, %edge_7 ]
  %p_8_8 = phi i64 [ %p_5_3, %edge_7 ]
  %p_8_9 = phi i64 [ %t14, %edge_7 ]
  %p_8_10 = phi i1 [ %t18, %edge_7 ]
  call void @abort()
  unreachable
b9:
  %p_9_0 = phi %hia.buffer [ %p_7_0, %edge_8 ], [ %p_17_0, %edge_21 ]
  %p_9_1 = phi i64 [ %p_7_1, %edge_8 ], [ %p_17_1, %edge_21 ]
  %p_9_2 = phi %hia.buffer [ %p_7_2, %edge_8 ], [ %p_17_2, %edge_21 ]
  %p_9_3 = phi i64 [ %p_7_3, %edge_8 ], [ %p_17_3, %edge_21 ]
  %p_9_4 = phi i64 [ %p_7_4, %edge_8 ], [ %p_17_4, %edge_21 ]
  %p_9_5 = phi i64 [ %p_7_4, %edge_8 ], [ %p_17_5, %edge_21 ]
  %p_9_6 = phi i64 [ %p_7_1, %edge_8 ], [ %p_17_6, %edge_21 ]
  %p_9_7 = phi i64 [ %p_7_3, %edge_8 ], [ %p_17_7, %edge_21 ]
  %t19 = icmp ne i64 %p_9_5, 0
  br i1 %t19, label %edge_9, label %edge_10
b10:
  %p_10_0 = phi %hia.buffer [ %p_9_0, %edge_9 ]
  %p_10_1 = phi i64 [ %p_9_1, %edge_9 ]
  %p_10_2 = phi %hia.buffer [ %p_9_2, %edge_9 ]
  %p_10_3 = phi i64 [ %p_9_3, %edge_9 ]
  %p_10_4 = phi i64 [ %p_9_4, %edge_9 ]
  %p_10_5 = phi i64 [ %p_9_5, %edge_9 ]
  %p_10_6 = phi i64 [ %p_9_6, %edge_9 ]
  %p_10_7 = phi i64 [ %p_9_7, %edge_9 ]
  %p_10_8 = phi i64 [ %p_9_5, %edge_9 ]
  %p_10_9 = phi i64 [ 0, %edge_9 ]
  %p_10_10 = phi i64 [ 0, %edge_9 ]
  %p_10_11 = phi i1 [ %t19, %edge_9 ]
  %p_10_12 = phi i1 [ %t19, %edge_9 ]
  %t20 = extractvalue %hia.buffer %p_10_0, 0
  %t21 = extractvalue %hia.buffer %p_10_0, 1
  %t22 = icmp ult i64 %p_10_6, %t21
  br i1 %t22, label %ok_23, label %trap_23
trap_23:
  call void @abort()
  unreachable
ok_23:
  %t24 = getelementptr i8, ptr %t20, i64 %p_10_6
  %t25 = load i8, ptr %t24, align 1
  %t26 = zext i8 %t25 to i32
  %t27 = extractvalue %hia.buffer %p_10_2, 0
  %t28 = extractvalue %hia.buffer %p_10_2, 1
  %t29 = icmp ult i64 %p_10_7, %t28
  br i1 %t29, label %ok_30, label %trap_30
trap_30:
  call void @abort()
  unreachable
ok_30:
  %t31 = getelementptr i8, ptr %t27, i64 %p_10_7
  %t32 = load i8, ptr %t31, align 1
  %t33 = zext i8 %t32 to i32
  %t34 = icmp eq i32 %t26, %t33
  br label %edge_11
b11:
  %p_11_0 = phi %hia.buffer [ %p_9_0, %edge_10 ]
  %p_11_1 = phi i64 [ %p_9_1, %edge_10 ]
  %p_11_2 = phi %hia.buffer [ %p_9_2, %edge_10 ]
  %p_11_3 = phi i64 [ %p_9_3, %edge_10 ]
  %p_11_4 = phi i64 [ %p_9_4, %edge_10 ]
  %p_11_5 = phi i64 [ %p_9_5, %edge_10 ]
  %p_11_6 = phi i64 [ %p_9_6, %edge_10 ]
  %p_11_7 = phi i64 [ %p_9_7, %edge_10 ]
  %p_11_8 = phi i64 [ %p_9_5, %edge_10 ]
  %p_11_9 = phi i64 [ 0, %edge_10 ]
  %p_11_10 = phi i64 [ 0, %edge_10 ]
  %p_11_11 = phi i1 [ %t19, %edge_10 ]
  %p_11_12 = phi i1 [ %t19, %edge_10 ]
  br label %edge_12
b12:
  %p_12_0 = phi %hia.buffer [ %p_10_0, %edge_11 ], [ %p_11_0, %edge_12 ]
  %p_12_1 = phi i64 [ %p_10_1, %edge_11 ], [ %p_11_1, %edge_12 ]
  %p_12_2 = phi %hia.buffer [ %p_10_2, %edge_11 ], [ %p_11_2, %edge_12 ]
  %p_12_3 = phi i64 [ %p_10_3, %edge_11 ], [ %p_11_3, %edge_12 ]
  %p_12_4 = phi i64 [ %p_10_4, %edge_11 ], [ %p_11_4, %edge_12 ]
  %p_12_5 = phi i64 [ %p_10_5, %edge_11 ], [ %p_11_5, %edge_12 ]
  %p_12_6 = phi i64 [ %p_10_6, %edge_11 ], [ %p_11_6, %edge_12 ]
  %p_12_7 = phi i64 [ %p_10_7, %edge_11 ], [ %p_11_7, %edge_12 ]
  %p_12_8 = phi i64 [ %p_10_8, %edge_11 ], [ %p_11_8, %edge_12 ]
  %p_12_9 = phi i64 [ %p_10_9, %edge_11 ], [ %p_11_9, %edge_12 ]
  %p_12_10 = phi i64 [ %p_10_10, %edge_11 ], [ %p_11_10, %edge_12 ]
  %p_12_11 = phi i1 [ %p_10_11, %edge_11 ], [ %p_11_11, %edge_12 ]
  %p_12_12 = phi i1 [ %t34, %edge_11 ], [ %p_11_11, %edge_12 ]
  br i1 %p_12_12, label %edge_13, label %edge_14
b13:
  %p_13_0 = phi %hia.buffer [ %p_12_0, %edge_13 ]
  %p_13_1 = phi i64 [ %p_12_1, %edge_13 ]
  %p_13_2 = phi %hia.buffer [ %p_12_2, %edge_13 ]
  %p_13_3 = phi i64 [ %p_12_3, %edge_13 ]
  %p_13_4 = phi i64 [ %p_12_4, %edge_13 ]
  %p_13_5 = phi i64 [ %p_12_5, %edge_13 ]
  %p_13_6 = phi i64 [ %p_12_6, %edge_13 ]
  %p_13_7 = phi i64 [ %p_12_7, %edge_13 ]
  %t35 = sub i64 %p_13_5, 1
  %t36 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_13_6, i64 1)
  %t37 = extractvalue { i64, i1 } %t36, 0
  %t38 = extractvalue { i64, i1 } %t36, 1
  %t39 = xor i1 %t38, true
  br i1 %t39, label %ok_40, label %trap_40
trap_40:
  call void @abort()
  unreachable
ok_40:
  %t41 = extractvalue %hia.buffer %p_13_0, 1
  %t42 = icmp ule i64 %t37, %t41
  br i1 %t42, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi %hia.buffer [ %p_12_0, %edge_14 ]
  %p_14_1 = phi i64 [ %p_12_1, %edge_14 ]
  %p_14_2 = phi %hia.buffer [ %p_12_2, %edge_14 ]
  %p_14_3 = phi i64 [ %p_12_3, %edge_14 ]
  %p_14_4 = phi i64 [ %p_12_4, %edge_14 ]
  %p_14_5 = phi i64 [ %p_12_5, %edge_14 ]
  %p_14_6 = phi i64 [ %p_12_6, %edge_14 ]
  %p_14_7 = phi i64 [ %p_12_7, %edge_14 ]
  %t43 = icmp ne i64 %p_14_5, 0
  br i1 %t43, label %edge_17, label %edge_18
b15:
  %p_15_0 = phi %hia.buffer [ %p_13_0, %edge_15 ]
  %p_15_1 = phi i64 [ %p_13_1, %edge_15 ]
  %p_15_2 = phi %hia.buffer [ %p_13_2, %edge_15 ]
  %p_15_3 = phi i64 [ %p_13_3, %edge_15 ]
  %p_15_4 = phi i64 [ %p_13_4, %edge_15 ]
  %p_15_5 = phi i64 [ %t35, %edge_15 ]
  %p_15_6 = phi i64 [ %t37, %edge_15 ]
  %p_15_7 = phi i64 [ %p_13_7, %edge_15 ]
  %p_15_8 = phi i64 [ %t37, %edge_15 ]
  %p_15_9 = phi i64 [ %t41, %edge_15 ]
  %p_15_10 = phi i1 [ %t42, %edge_15 ]
  %t44 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_15_7, i64 1)
  %t45 = extractvalue { i64, i1 } %t44, 0
  %t46 = extractvalue { i64, i1 } %t44, 1
  %t47 = xor i1 %t46, true
  br i1 %t47, label %ok_48, label %trap_48
trap_48:
  call void @abort()
  unreachable
ok_48:
  %t49 = extractvalue %hia.buffer %p_15_2, 1
  %t50 = icmp ule i64 %t45, %t49
  br i1 %t50, label %edge_19, label %edge_20
b16:
  %p_16_0 = phi %hia.buffer [ %p_13_0, %edge_16 ]
  %p_16_1 = phi i64 [ %p_13_1, %edge_16 ]
  %p_16_2 = phi %hia.buffer [ %p_13_2, %edge_16 ]
  %p_16_3 = phi i64 [ %p_13_3, %edge_16 ]
  %p_16_4 = phi i64 [ %p_13_4, %edge_16 ]
  %p_16_5 = phi i64 [ %t35, %edge_16 ]
  %p_16_6 = phi i64 [ %t37, %edge_16 ]
  %p_16_7 = phi i64 [ %p_13_7, %edge_16 ]
  %p_16_8 = phi i64 [ %t37, %edge_16 ]
  %p_16_9 = phi i64 [ %t41, %edge_16 ]
  %p_16_10 = phi i1 [ %t42, %edge_16 ]
  call void @abort()
  unreachable
b17:
  %p_17_0 = phi %hia.buffer [ %p_15_0, %edge_19 ]
  %p_17_1 = phi i64 [ %p_15_1, %edge_19 ]
  %p_17_2 = phi %hia.buffer [ %p_15_2, %edge_19 ]
  %p_17_3 = phi i64 [ %p_15_3, %edge_19 ]
  %p_17_4 = phi i64 [ %p_15_4, %edge_19 ]
  %p_17_5 = phi i64 [ %p_15_5, %edge_19 ]
  %p_17_6 = phi i64 [ %p_15_6, %edge_19 ]
  %p_17_7 = phi i64 [ %t45, %edge_19 ]
  %p_17_8 = phi i64 [ %t45, %edge_19 ]
  %p_17_9 = phi i64 [ %t49, %edge_19 ]
  %p_17_10 = phi i1 [ %t50, %edge_19 ]
  br label %edge_21
b18:
  %p_18_0 = phi %hia.buffer [ %p_15_0, %edge_20 ]
  %p_18_1 = phi i64 [ %p_15_1, %edge_20 ]
  %p_18_2 = phi %hia.buffer [ %p_15_2, %edge_20 ]
  %p_18_3 = phi i64 [ %p_15_3, %edge_20 ]
  %p_18_4 = phi i64 [ %p_15_4, %edge_20 ]
  %p_18_5 = phi i64 [ %p_15_5, %edge_20 ]
  %p_18_6 = phi i64 [ %p_15_6, %edge_20 ]
  %p_18_7 = phi i64 [ %t45, %edge_20 ]
  %p_18_8 = phi i64 [ %t45, %edge_20 ]
  %p_18_9 = phi i64 [ %t49, %edge_20 ]
  %p_18_10 = phi i1 [ %t50, %edge_20 ]
  call void @abort()
  unreachable
b19:
  %p_19_0 = phi %hia.buffer [ %p_14_0, %edge_17 ]
  %p_19_1 = phi i64 [ %p_14_1, %edge_17 ]
  %p_19_2 = phi %hia.buffer [ %p_14_2, %edge_17 ]
  %p_19_3 = phi i64 [ %p_14_3, %edge_17 ]
  %p_19_4 = phi i64 [ %p_14_4, %edge_17 ]
  %p_19_5 = phi i64 [ %p_14_5, %edge_17 ]
  %p_19_6 = phi i64 [ %p_14_6, %edge_17 ]
  %p_19_7 = phi i64 [ %p_14_7, %edge_17 ]
  %t51 = extractvalue %hia.buffer %p_19_0, 0
  %t52 = extractvalue %hia.buffer %p_19_0, 1
  %t53 = icmp ult i64 %p_19_6, %t52
  br i1 %t53, label %ok_54, label %trap_54
trap_54:
  call void @abort()
  unreachable
ok_54:
  %t55 = getelementptr i8, ptr %t51, i64 %p_19_6
  %t56 = load i8, ptr %t55, align 1
  %t57 = zext i8 %t56 to i32
  %t58 = extractvalue %hia.buffer %p_19_2, 0
  %t59 = extractvalue %hia.buffer %p_19_2, 1
  %t60 = icmp ult i64 %p_19_7, %t59
  br i1 %t60, label %ok_61, label %trap_61
trap_61:
  call void @abort()
  unreachable
ok_61:
  %t62 = getelementptr i8, ptr %t58, i64 %p_19_7
  %t63 = load i8, ptr %t62, align 1
  %t64 = zext i8 %t63 to i32
  %t65 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %t57, i32 %t64)
  %t66 = extractvalue { i32, i1 } %t65, 0
  %t67 = extractvalue { i32, i1 } %t65, 1
  %t68 = xor i1 %t67, true
  br i1 %t68, label %ok_69, label %trap_69
trap_69:
  call void @abort()
  unreachable
ok_69:
  ret i32 %t66
b20:
  %p_20_0 = phi %hia.buffer [ %p_14_0, %edge_18 ]
  %p_20_1 = phi i64 [ %p_14_1, %edge_18 ]
  %p_20_2 = phi %hia.buffer [ %p_14_2, %edge_18 ]
  %p_20_3 = phi i64 [ %p_14_3, %edge_18 ]
  %p_20_4 = phi i64 [ %p_14_4, %edge_18 ]
  %p_20_5 = phi i64 [ %p_14_5, %edge_18 ]
  %p_20_6 = phi i64 [ %p_14_6, %edge_18 ]
  %p_20_7 = phi i64 [ %p_14_7, %edge_18 ]
  %t70 = trunc i64 0 to i32
  ret i32 %t70
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
edge_8:
  br label %b9
edge_9:
  br label %b10
edge_10:
  br label %b11
edge_11:
  br label %b12
edge_12:
  br label %b12
edge_13:
  br label %b13
edge_14:
  br label %b14
edge_15:
  br label %b15
edge_16:
  br label %b16
edge_17:
  br label %b19
edge_18:
  br label %b20
edge_19:
  br label %b17
edge_20:
  br label %b18
edge_21:
  br label %b9
}

define internal { i8, i64, i64, i64 } @__hia_fn_6(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_7 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_8 = phi i64 [ 1, %edge_0 ]
  %p_1_9 = phi i64 [ 1, %edge_0 ]
  %p_1_10 = phi i64 [ %t2, %edge_0 ]
  %p_1_11 = phi i64 [ %t6, %edge_0 ]
  %p_1_12 = phi i1 [ %t7, %edge_0 ]
  %t8 = extractvalue %hia.buffer %p_1_4, 1
  %t9 = icmp ule i64 %p_1_5, %t8
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_7 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_8 = phi i64 [ 1, %edge_1 ]
  %p_2_9 = phi i64 [ 1, %edge_1 ]
  %p_2_10 = phi i64 [ %t2, %edge_1 ]
  %p_2_11 = phi i64 [ %t6, %edge_1 ]
  %p_2_12 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_7 = phi i64 [ %t8, %edge_2 ]
  %p_3_8 = phi i1 [ %t9, %edge_2 ]
  %t10 = extractvalue %hia.buffer %p_3_4, 1
  %t11 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t10, i64 %p_3_5)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t16 = icmp ule i64 1, %t12
  br i1 %t16, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_7 = phi i64 [ %t8, %edge_3 ]
  %p_4_8 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ]
  %p_5_4 = phi %hia.buffer [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_6 = phi i64 [ 1, %edge_4 ]
  %p_5_7 = phi i64 [ 1, %edge_4 ]
  %p_5_8 = phi i64 [ %t10, %edge_4 ]
  %p_5_9 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_10 = phi i64 [ %t12, %edge_4 ]
  %p_5_11 = phi i1 [ %t16, %edge_4 ]
  %t17 = call i8 @__hia_fn_9(i64 %p_5_0, i64 %p_5_1, i64 %p_5_2, %hia.buffer %p_5_3)
  %t18 = trunc i64 0 to i8
  %t19 = icmp ne i8 %t17, %t18
  br i1 %t19, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi i64 [ %p_3_2, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %p_3_3, %edge_5 ]
  %p_6_4 = phi %hia.buffer [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_6 = phi i64 [ 1, %edge_5 ]
  %p_6_7 = phi i64 [ 1, %edge_5 ]
  %p_6_8 = phi i64 [ %t10, %edge_5 ]
  %p_6_9 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_10 = phi i64 [ %t12, %edge_5 ]
  %p_6_11 = phi i1 [ %t16, %edge_5 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi i64 [ %p_5_2, %edge_6 ]
  %p_7_3 = phi %hia.buffer [ %p_5_3, %edge_6 ]
  %p_7_4 = phi %hia.buffer [ %p_5_4, %edge_6 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_6 ]
  %t20 = trunc i64 0 to i32
  %t21 = trunc i32 %t20 to i8
  %t22 = insertvalue { i8, i64, i64, i64 } zeroinitializer, i8 %t21, 0
  %t23 = insertvalue { i8, i64, i64, i64 } %t22, i64 %p_7_0, 1
  %t24 = insertvalue { i8, i64, i64, i64 } %t23, i64 %p_7_1, 2
  %t25 = insertvalue { i8, i64, i64, i64 } %t24, i64 %p_7_2, 3
  ret { i8, i64, i64, i64 } %t25
b8:
  %p_8_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_8_2 = phi i64 [ %p_5_2, %edge_7 ]
  %p_8_3 = phi %hia.buffer [ %p_5_3, %edge_7 ]
  %p_8_4 = phi %hia.buffer [ %p_5_4, %edge_7 ]
  %p_8_5 = phi i64 [ %p_5_5, %edge_7 ]
  %t26 = extractvalue %hia.buffer %p_8_3, 1
  %t27 = call i64 @__hia_fn_1(i64 0, i64 %p_8_1, i64 %t26)
  %t28 = extractvalue %hia.buffer %p_8_3, 0
  %t29 = extractvalue %hia.buffer %p_8_3, 1
  %t30 = icmp ult i64 %t27, %t29
  br i1 %t30, label %ok_31, label %trap_31
trap_31:
  call void @abort()
  unreachable
ok_31:
  %t32 = getelementptr i8, ptr %t28, i64 %t27
  %t33 = load i8, ptr %t32, align 1
  %t34 = extractvalue %hia.buffer %p_8_4, 0
  %t35 = extractvalue %hia.buffer %p_8_4, 1
  %t36 = icmp ult i64 %p_8_5, %t35
  br i1 %t36, label %ok_37, label %trap_37
trap_37:
  call void @abort()
  unreachable
ok_37:
  %t38 = getelementptr i8, ptr %t34, i64 %p_8_5
  store i8 %t33, ptr %t38, align 1
  %t39 = trunc i64 1 to i32
  %t40 = sext i32 %t39 to i64
  %t41 = add i64 %p_8_1, %t40
  %t42 = and i64 %t41, %p_8_0
  %t43 = trunc i64 1 to i32
  %t44 = trunc i32 %t43 to i8
  %t45 = insertvalue { i8, i64, i64, i64 } zeroinitializer, i8 %t44, 0
  %t46 = insertvalue { i8, i64, i64, i64 } %t45, i64 %p_8_0, 1
  %t47 = insertvalue { i8, i64, i64, i64 } %t46, i64 %t42, 2
  %t48 = insertvalue { i8, i64, i64, i64 } %t47, i64 %p_8_2, 3
  ret { i8, i64, i64, i64 } %t48
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
}

define internal { i64, i64, i64, i64 } @__hia_fn_7(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  %p_1_7 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_8 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_9 = phi i64 [ 1, %edge_0 ]
  %p_1_10 = phi i64 [ 1, %edge_0 ]
  %p_1_11 = phi i64 [ %t2, %edge_0 ]
  %p_1_12 = phi i64 [ %t6, %edge_0 ]
  %p_1_13 = phi i1 [ %t7, %edge_0 ]
  %t8 = extractvalue %hia.buffer %p_1_4, 1
  %t9 = icmp ule i64 %p_1_5, %t8
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_6, %edge_1 ]
  %p_2_7 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_8 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_9 = phi i64 [ 1, %edge_1 ]
  %p_2_10 = phi i64 [ 1, %edge_1 ]
  %p_2_11 = phi i64 [ %t2, %edge_1 ]
  %p_2_12 = phi i64 [ %t6, %edge_1 ]
  %p_2_13 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_6, %edge_2 ]
  %p_3_7 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_8 = phi i64 [ %t8, %edge_2 ]
  %p_3_9 = phi i1 [ %t9, %edge_2 ]
  %t10 = extractvalue %hia.buffer %p_3_4, 1
  %t11 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t10, i64 %p_3_5)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t16 = icmp ule i64 %p_3_6, %t12
  br i1 %t16, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_6, %edge_3 ]
  %p_4_7 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_8 = phi i64 [ %t8, %edge_3 ]
  %p_4_9 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ]
  %p_5_4 = phi %hia.buffer [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_6 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_7 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_8 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_9 = phi i64 [ %t10, %edge_4 ]
  %p_5_10 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_11 = phi i64 [ %t12, %edge_4 ]
  %p_5_12 = phi i1 [ %t16, %edge_4 ]
  %t17 = call i8 @__hia_fn_9(i64 %p_5_0, i64 %p_5_1, i64 %p_5_2, %hia.buffer %p_5_3)
  %t18 = trunc i64 0 to i8
  %t19 = icmp ne i8 %t17, %t18
  br i1 %t19, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi i64 [ %p_3_2, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %p_3_3, %edge_5 ]
  %p_6_4 = phi %hia.buffer [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_6 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_7 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_8 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_9 = phi i64 [ %t10, %edge_5 ]
  %p_6_10 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_11 = phi i64 [ %t12, %edge_5 ]
  %p_6_12 = phi i1 [ %t16, %edge_5 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi i64 [ %p_5_2, %edge_6 ]
  %p_7_3 = phi %hia.buffer [ %p_5_3, %edge_6 ]
  %p_7_4 = phi %hia.buffer [ %p_5_4, %edge_6 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_6 ]
  %p_7_6 = phi i64 [ %p_5_6, %edge_6 ]
  %p_7_7 = phi i64 [ %p_5_6, %edge_6 ]
  %t20 = trunc i64 0 to i32
  %t21 = sext i32 %t20 to i64
  %t22 = insertvalue { i64, i64, i64, i64 } zeroinitializer, i64 %t21, 0
  %t23 = insertvalue { i64, i64, i64, i64 } %t22, i64 %p_7_0, 1
  %t24 = insertvalue { i64, i64, i64, i64 } %t23, i64 %p_7_1, 2
  %t25 = insertvalue { i64, i64, i64, i64 } %t24, i64 %p_7_2, 3
  ret { i64, i64, i64, i64 } %t25
b8:
  %p_8_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_8_2 = phi i64 [ %p_5_2, %edge_7 ]
  %p_8_3 = phi %hia.buffer [ %p_5_3, %edge_7 ]
  %p_8_4 = phi %hia.buffer [ %p_5_4, %edge_7 ]
  %p_8_5 = phi i64 [ %p_5_5, %edge_7 ]
  %p_8_6 = phi i64 [ %p_5_6, %edge_7 ]
  %p_8_7 = phi i64 [ %p_5_6, %edge_7 ]
  %t26 = trunc i64 0 to i32
  %t27 = sext i32 %t26 to i64
  br label %edge_8
b9:
  %p_9_0 = phi i64 [ %p_8_0, %edge_8 ], [ %p_15_0, %edge_17 ]
  %p_9_1 = phi i64 [ %p_8_1, %edge_8 ], [ %p_15_1, %edge_17 ]
  %p_9_2 = phi i64 [ %p_8_2, %edge_8 ], [ %p_15_2, %edge_17 ]
  %p_9_3 = phi %hia.buffer [ %p_8_3, %edge_8 ], [ %p_15_3, %edge_17 ]
  %p_9_4 = phi %hia.buffer [ %p_8_4, %edge_8 ], [ %p_15_4, %edge_17 ]
  %p_9_5 = phi i64 [ %p_8_5, %edge_8 ], [ %p_15_5, %edge_17 ]
  %p_9_6 = phi i64 [ %p_8_6, %edge_8 ], [ %p_15_6, %edge_17 ]
  %p_9_7 = phi i64 [ %p_8_7, %edge_8 ], [ %p_15_7, %edge_17 ]
  %p_9_8 = phi i64 [ %p_8_5, %edge_8 ], [ %p_15_8, %edge_17 ]
  %p_9_9 = phi i64 [ %t27, %edge_8 ], [ %p_15_9, %edge_17 ]
  %t28 = icmp ult i64 %p_9_9, %p_9_7
  br i1 %t28, label %edge_9, label %edge_10
b10:
  %p_10_0 = phi i64 [ %p_9_0, %edge_9 ]
  %p_10_1 = phi i64 [ %p_9_1, %edge_9 ]
  %p_10_2 = phi i64 [ %p_9_2, %edge_9 ]
  %p_10_3 = phi %hia.buffer [ %p_9_3, %edge_9 ]
  %p_10_4 = phi %hia.buffer [ %p_9_4, %edge_9 ]
  %p_10_5 = phi i64 [ %p_9_5, %edge_9 ]
  %p_10_6 = phi i64 [ %p_9_6, %edge_9 ]
  %p_10_7 = phi i64 [ %p_9_7, %edge_9 ]
  %p_10_8 = phi i64 [ %p_9_8, %edge_9 ]
  %p_10_9 = phi i64 [ %p_9_9, %edge_9 ]
  %p_10_10 = phi i64 [ %p_9_9, %edge_9 ]
  %p_10_11 = phi i64 [ %p_9_7, %edge_9 ]
  %p_10_12 = phi i1 [ %t28, %edge_9 ]
  %p_10_13 = phi i1 [ %t28, %edge_9 ]
  %t29 = call { i8, i64, i64, i64 } @__hia_fn_6(i64 %p_10_0, i64 %p_10_1, i64 %p_10_2, %hia.buffer %p_10_3, %hia.buffer %p_10_4, i64 %p_10_8)
  %t30 = extractvalue { i8, i64, i64, i64 } %t29, 0
  %t31 = extractvalue { i8, i64, i64, i64 } %t29, 1
  %t32 = extractvalue { i8, i64, i64, i64 } %t29, 2
  %t33 = extractvalue { i8, i64, i64, i64 } %t29, 3
  %t34 = zext i8 %t30 to i32
  %t35 = trunc i64 0 to i32
  %t36 = icmp ne i32 %t34, %t35
  br label %edge_11
b11:
  %p_11_0 = phi i64 [ %p_9_0, %edge_10 ]
  %p_11_1 = phi i64 [ %p_9_1, %edge_10 ]
  %p_11_2 = phi i64 [ %p_9_2, %edge_10 ]
  %p_11_3 = phi %hia.buffer [ %p_9_3, %edge_10 ]
  %p_11_4 = phi %hia.buffer [ %p_9_4, %edge_10 ]
  %p_11_5 = phi i64 [ %p_9_5, %edge_10 ]
  %p_11_6 = phi i64 [ %p_9_6, %edge_10 ]
  %p_11_7 = phi i64 [ %p_9_7, %edge_10 ]
  %p_11_8 = phi i64 [ %p_9_8, %edge_10 ]
  %p_11_9 = phi i64 [ %p_9_9, %edge_10 ]
  %p_11_10 = phi i64 [ %p_9_9, %edge_10 ]
  %p_11_11 = phi i64 [ %p_9_7, %edge_10 ]
  %p_11_12 = phi i1 [ %t28, %edge_10 ]
  %p_11_13 = phi i1 [ %t28, %edge_10 ]
  br label %edge_12
b12:
  %p_12_0 = phi i64 [ %t31, %edge_11 ], [ %p_11_0, %edge_12 ]
  %p_12_1 = phi i64 [ %t32, %edge_11 ], [ %p_11_1, %edge_12 ]
  %p_12_2 = phi i64 [ %t33, %edge_11 ], [ %p_11_2, %edge_12 ]
  %p_12_3 = phi %hia.buffer [ %p_10_3, %edge_11 ], [ %p_11_3, %edge_12 ]
  %p_12_4 = phi %hia.buffer [ %p_10_4, %edge_11 ], [ %p_11_4, %edge_12 ]
  %p_12_5 = phi i64 [ %p_10_5, %edge_11 ], [ %p_11_5, %edge_12 ]
  %p_12_6 = phi i64 [ %p_10_6, %edge_11 ], [ %p_11_6, %edge_12 ]
  %p_12_7 = phi i64 [ %p_10_7, %edge_11 ], [ %p_11_7, %edge_12 ]
  %p_12_8 = phi i64 [ %p_10_8, %edge_11 ], [ %p_11_8, %edge_12 ]
  %p_12_9 = phi i64 [ %p_10_9, %edge_11 ], [ %p_11_9, %edge_12 ]
  %p_12_10 = phi i64 [ %p_10_10, %edge_11 ], [ %p_11_10, %edge_12 ]
  %p_12_11 = phi i64 [ %p_10_11, %edge_11 ], [ %p_11_11, %edge_12 ]
  %p_12_12 = phi i1 [ %p_10_12, %edge_11 ], [ %p_11_12, %edge_12 ]
  %p_12_13 = phi i1 [ %t36, %edge_11 ], [ %p_11_12, %edge_12 ]
  br i1 %p_12_13, label %edge_13, label %edge_14
b13:
  %p_13_0 = phi i64 [ %p_12_0, %edge_13 ]
  %p_13_1 = phi i64 [ %p_12_1, %edge_13 ]
  %p_13_2 = phi i64 [ %p_12_2, %edge_13 ]
  %p_13_3 = phi %hia.buffer [ %p_12_3, %edge_13 ]
  %p_13_4 = phi %hia.buffer [ %p_12_4, %edge_13 ]
  %p_13_5 = phi i64 [ %p_12_5, %edge_13 ]
  %p_13_6 = phi i64 [ %p_12_6, %edge_13 ]
  %p_13_7 = phi i64 [ %p_12_7, %edge_13 ]
  %p_13_8 = phi i64 [ %p_12_8, %edge_13 ]
  %p_13_9 = phi i64 [ %p_12_9, %edge_13 ]
  %t37 = add i64 %p_13_9, 1
  %t38 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_13_8, i64 1)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = extractvalue %hia.buffer %p_13_4, 1
  %t44 = icmp ule i64 %t39, %t43
  br i1 %t44, label %edge_15, label %edge_16
b14:
  %p_14_0 = phi i64 [ %p_12_0, %edge_14 ]
  %p_14_1 = phi i64 [ %p_12_1, %edge_14 ]
  %p_14_2 = phi i64 [ %p_12_2, %edge_14 ]
  %p_14_3 = phi %hia.buffer [ %p_12_3, %edge_14 ]
  %p_14_4 = phi %hia.buffer [ %p_12_4, %edge_14 ]
  %p_14_5 = phi i64 [ %p_12_5, %edge_14 ]
  %p_14_6 = phi i64 [ %p_12_6, %edge_14 ]
  %p_14_7 = phi i64 [ %p_12_7, %edge_14 ]
  %p_14_8 = phi i64 [ %p_12_8, %edge_14 ]
  %p_14_9 = phi i64 [ %p_12_9, %edge_14 ]
  %t45 = insertvalue { i64, i64, i64, i64 } zeroinitializer, i64 %p_14_9, 0
  %t46 = insertvalue { i64, i64, i64, i64 } %t45, i64 %p_14_0, 1
  %t47 = insertvalue { i64, i64, i64, i64 } %t46, i64 %p_14_1, 2
  %t48 = insertvalue { i64, i64, i64, i64 } %t47, i64 %p_14_2, 3
  ret { i64, i64, i64, i64 } %t48
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_15_1 = phi i64 [ %p_13_1, %edge_15 ]
  %p_15_2 = phi i64 [ %p_13_2, %edge_15 ]
  %p_15_3 = phi %hia.buffer [ %p_13_3, %edge_15 ]
  %p_15_4 = phi %hia.buffer [ %p_13_4, %edge_15 ]
  %p_15_5 = phi i64 [ %p_13_5, %edge_15 ]
  %p_15_6 = phi i64 [ %p_13_6, %edge_15 ]
  %p_15_7 = phi i64 [ %p_13_7, %edge_15 ]
  %p_15_8 = phi i64 [ %t39, %edge_15 ]
  %p_15_9 = phi i64 [ %t37, %edge_15 ]
  %p_15_10 = phi i64 [ %t39, %edge_15 ]
  %p_15_11 = phi i64 [ %t43, %edge_15 ]
  %p_15_12 = phi i1 [ %t44, %edge_15 ]
  br label %edge_17
b16:
  %p_16_0 = phi i64 [ %p_13_0, %edge_16 ]
  %p_16_1 = phi i64 [ %p_13_1, %edge_16 ]
  %p_16_2 = phi i64 [ %p_13_2, %edge_16 ]
  %p_16_3 = phi %hia.buffer [ %p_13_3, %edge_16 ]
  %p_16_4 = phi %hia.buffer [ %p_13_4, %edge_16 ]
  %p_16_5 = phi i64 [ %p_13_5, %edge_16 ]
  %p_16_6 = phi i64 [ %p_13_6, %edge_16 ]
  %p_16_7 = phi i64 [ %p_13_7, %edge_16 ]
  %p_16_8 = phi i64 [ %t39, %edge_16 ]
  %p_16_9 = phi i64 [ %t37, %edge_16 ]
  %p_16_10 = phi i64 [ %t39, %edge_16 ]
  %p_16_11 = phi i64 [ %t43, %edge_16 ]
  %p_16_12 = phi i1 [ %t44, %edge_16 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
edge_8:
  br label %b9
edge_9:
  br label %b10
edge_10:
  br label %b11
edge_11:
  br label %b12
edge_12:
  br label %b12
edge_13:
  br label %b13
edge_14:
  br label %b14
edge_15:
  br label %b15
edge_16:
  br label %b16
edge_17:
  br label %b9
}

define internal { i64, i64, i64 } @__hia_fn_8(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3, i64 %p_0_4, i64 %p_0_5) {
b0:
  %t1 = extractvalue %hia.buffer %p_0_3, 1
  %t2 = icmp ule i64 %p_0_4, %t1
  br i1 %t2, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_4, %edge_0 ]
  %p_1_7 = phi i64 [ %t1, %edge_0 ]
  %p_1_8 = phi i1 [ %t2, %edge_0 ]
  %t3 = extractvalue %hia.buffer %p_1_3, 1
  %t4 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t3, i64 %p_1_4)
  %t5 = extractvalue { i64, i1 } %t4, 0
  %t6 = extractvalue { i64, i1 } %t4, 1
  %t7 = xor i1 %t6, true
  br i1 %t7, label %ok_8, label %trap_8
trap_8:
  call void @abort()
  unreachable
ok_8:
  %t9 = icmp ule i64 %p_1_5, %t5
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_4, %edge_1 ]
  %p_2_7 = phi i64 [ %t1, %edge_1 ]
  %p_2_8 = phi i1 [ %t2, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_7 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_8 = phi i64 [ %t3, %edge_2 ]
  %p_3_9 = phi i64 [ %p_1_4, %edge_2 ]
  %p_3_10 = phi i64 [ %t5, %edge_2 ]
  %p_3_11 = phi i1 [ %t9, %edge_2 ]
  %t10 = trunc i64 1 to i32
  %t11 = sext i32 %t10 to i64
  %t12 = sub i64 %p_3_5, %t11
  %t13 = trunc i64 0 to i32
  %t14 = sext i32 %t13 to i64
  %t15 = trunc i64 0 to i32
  %t16 = sext i32 %t15 to i64
  %t17 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t12, i64 1)
  %t18 = extractvalue { i64, i1 } %t17, 0
  %t19 = extractvalue { i64, i1 } %t17, 1
  %t20 = xor i1 %t19, true
  br i1 %t20, label %ok_21, label %trap_21
trap_21:
  call void @abort()
  unreachable
ok_21:
  %t22 = extractvalue %hia.buffer %p_3_3, 1
  %t23 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t22, i64 %p_3_4)
  %t24 = extractvalue { i64, i1 } %t23, 0
  %t25 = extractvalue { i64, i1 } %t23, 1
  %t26 = xor i1 %t25, true
  br i1 %t26, label %ok_27, label %trap_27
trap_27:
  call void @abort()
  unreachable
ok_27:
  %t28 = icmp ule i64 %t18, %t24
  br i1 %t28, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_7 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_8 = phi i64 [ %t3, %edge_3 ]
  %p_4_9 = phi i64 [ %p_1_4, %edge_3 ]
  %p_4_10 = phi i64 [ %t5, %edge_3 ]
  %p_4_11 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi i64 [ %t12, %edge_4 ]
  %p_5_1 = phi i64 [ %t14, %edge_4 ]
  %p_5_2 = phi i64 [ %t16, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ]
  %p_5_4 = phi i64 [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_6 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_7 = phi i64 [ %t12, %edge_4 ]
  %p_5_8 = phi i64 [ %t12, %edge_4 ]
  %p_5_9 = phi i64 [ 1, %edge_4 ]
  %p_5_10 = phi i64 [ 1, %edge_4 ]
  %p_5_11 = phi i64 [ %t18, %edge_4 ]
  %p_5_12 = phi i64 [ %t22, %edge_4 ]
  %p_5_13 = phi i64 [ %p_3_4, %edge_4 ]
  %p_5_14 = phi i64 [ %t24, %edge_4 ]
  %p_5_15 = phi i1 [ %t28, %edge_4 ]
  %t29 = insertvalue { i64, i64, i64 } zeroinitializer, i64 %p_5_0, 0
  %t30 = insertvalue { i64, i64, i64 } %t29, i64 %p_5_1, 1
  %t31 = insertvalue { i64, i64, i64 } %t30, i64 %p_5_2, 2
  ret { i64, i64, i64 } %t31
b6:
  %p_6_0 = phi i64 [ %t12, %edge_5 ]
  %p_6_1 = phi i64 [ %t14, %edge_5 ]
  %p_6_2 = phi i64 [ %t16, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %p_3_3, %edge_5 ]
  %p_6_4 = phi i64 [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_6 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_7 = phi i64 [ %t12, %edge_5 ]
  %p_6_8 = phi i64 [ %t12, %edge_5 ]
  %p_6_9 = phi i64 [ 1, %edge_5 ]
  %p_6_10 = phi i64 [ 1, %edge_5 ]
  %p_6_11 = phi i64 [ %t18, %edge_5 ]
  %p_6_12 = phi i64 [ %t22, %edge_5 ]
  %p_6_13 = phi i64 [ %p_3_4, %edge_5 ]
  %p_6_14 = phi i64 [ %t24, %edge_5 ]
  %p_6_15 = phi i1 [ %t28, %edge_5 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
}

define internal i8 @__hia_fn_9(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_6 = phi i64 [ 1, %edge_0 ]
  %p_1_7 = phi i64 [ 1, %edge_0 ]
  %p_1_8 = phi i64 [ %t2, %edge_0 ]
  %p_1_9 = phi i64 [ %t6, %edge_0 ]
  %p_1_10 = phi i1 [ %t7, %edge_0 ]
  %t8 = icmp eq i64 %p_1_2, %p_1_1
  %t9 = call i32 @__hia_fn_0(i1 %t8)
  %t10 = trunc i32 %t9 to i8
  ret i8 %t10
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_6 = phi i64 [ 1, %edge_1 ]
  %p_2_7 = phi i64 [ 1, %edge_1 ]
  %p_2_8 = phi i64 [ %t2, %edge_1 ]
  %p_2_9 = phi i64 [ %t6, %edge_1 ]
  %p_2_10 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i8 @__hia_fn_10(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_6 = phi i64 [ 1, %edge_0 ]
  %p_1_7 = phi i64 [ 1, %edge_0 ]
  %p_1_8 = phi i64 [ %t2, %edge_0 ]
  %p_1_9 = phi i64 [ %t6, %edge_0 ]
  %p_1_10 = phi i1 [ %t7, %edge_0 ]
  %t8 = sub i64 %p_1_2, %p_1_1
  %t9 = and i64 %t8, %p_1_0
  %t10 = icmp eq i64 %t9, %p_1_0
  %t11 = call i32 @__hia_fn_0(i1 %t10)
  %t12 = trunc i32 %t11 to i8
  ret i8 %t12
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_6 = phi i64 [ 1, %edge_1 ]
  %p_2_7 = phi i64 [ 1, %edge_1 ]
  %p_2_8 = phi i64 [ %t2, %edge_1 ]
  %p_2_9 = phi i64 [ %t6, %edge_1 ]
  %p_2_10 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal i64 @__hia_fn_11(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_6 = phi i64 [ 1, %edge_0 ]
  %p_1_7 = phi i64 [ 1, %edge_0 ]
  %p_1_8 = phi i64 [ %t2, %edge_0 ]
  %p_1_9 = phi i64 [ %t6, %edge_0 ]
  %p_1_10 = phi i1 [ %t7, %edge_0 ]
  %t8 = sub i64 %p_1_2, %p_1_1
  %t9 = and i64 %t8, %p_1_0
  ret i64 %t9
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_6 = phi i64 [ 1, %edge_1 ]
  %p_2_7 = phi i64 [ 1, %edge_1 ]
  %p_2_8 = phi i64 [ %t2, %edge_1 ]
  %p_2_9 = phi i64 [ %t6, %edge_1 ]
  %p_2_10 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
}

define internal { i8, i64, i64, i64 } @__hia_fn_12(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  %p_1_7 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_8 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_9 = phi i64 [ 1, %edge_0 ]
  %p_1_10 = phi i64 [ 1, %edge_0 ]
  %p_1_11 = phi i64 [ %t2, %edge_0 ]
  %p_1_12 = phi i64 [ %t6, %edge_0 ]
  %p_1_13 = phi i1 [ %t7, %edge_0 ]
  %t8 = extractvalue %hia.buffer %p_1_4, 1
  %t9 = icmp ule i64 %p_1_5, %t8
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_6, %edge_1 ]
  %p_2_7 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_8 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_9 = phi i64 [ 1, %edge_1 ]
  %p_2_10 = phi i64 [ 1, %edge_1 ]
  %p_2_11 = phi i64 [ %t2, %edge_1 ]
  %p_2_12 = phi i64 [ %t6, %edge_1 ]
  %p_2_13 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_6, %edge_2 ]
  %p_3_7 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_8 = phi i64 [ %t8, %edge_2 ]
  %p_3_9 = phi i1 [ %t9, %edge_2 ]
  %t10 = extractvalue %hia.buffer %p_3_4, 1
  %t11 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t10, i64 %p_3_5)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t16 = icmp ule i64 1, %t12
  br i1 %t16, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_6, %edge_3 ]
  %p_4_7 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_8 = phi i64 [ %t8, %edge_3 ]
  %p_4_9 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ]
  %p_5_4 = phi %hia.buffer [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_6 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_7 = phi i64 [ 1, %edge_4 ]
  %p_5_8 = phi i64 [ 1, %edge_4 ]
  %p_5_9 = phi i64 [ %t10, %edge_4 ]
  %p_5_10 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_11 = phi i64 [ %t12, %edge_4 ]
  %p_5_12 = phi i1 [ %t16, %edge_4 ]
  %t17 = call i64 @__hia_fn_11(i64 %p_5_0, i64 %p_5_1, i64 %p_5_2, %hia.buffer %p_5_3)
  %t18 = icmp uge i64 %p_5_6, %t17
  br i1 %t18, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi i64 [ %p_3_2, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %p_3_3, %edge_5 ]
  %p_6_4 = phi %hia.buffer [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_6 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_7 = phi i64 [ 1, %edge_5 ]
  %p_6_8 = phi i64 [ 1, %edge_5 ]
  %p_6_9 = phi i64 [ %t10, %edge_5 ]
  %p_6_10 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_11 = phi i64 [ %t12, %edge_5 ]
  %p_6_12 = phi i1 [ %t16, %edge_5 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi i64 [ %p_5_2, %edge_6 ]
  %p_7_3 = phi %hia.buffer [ %p_5_3, %edge_6 ]
  %p_7_4 = phi %hia.buffer [ %p_5_4, %edge_6 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_6 ]
  %p_7_6 = phi i64 [ %p_5_6, %edge_6 ]
  %p_7_7 = phi i64 [ %p_5_6, %edge_6 ]
  %t19 = trunc i64 0 to i32
  %t20 = trunc i32 %t19 to i8
  %t21 = insertvalue { i8, i64, i64, i64 } zeroinitializer, i8 %t20, 0
  %t22 = insertvalue { i8, i64, i64, i64 } %t21, i64 %p_7_0, 1
  %t23 = insertvalue { i8, i64, i64, i64 } %t22, i64 %p_7_1, 2
  %t24 = insertvalue { i8, i64, i64, i64 } %t23, i64 %p_7_2, 3
  ret { i8, i64, i64, i64 } %t24
b8:
  %p_8_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_8_2 = phi i64 [ %p_5_2, %edge_7 ]
  %p_8_3 = phi %hia.buffer [ %p_5_3, %edge_7 ]
  %p_8_4 = phi %hia.buffer [ %p_5_4, %edge_7 ]
  %p_8_5 = phi i64 [ %p_5_5, %edge_7 ]
  %p_8_6 = phi i64 [ %p_5_6, %edge_7 ]
  %p_8_7 = phi i64 [ %p_5_6, %edge_7 ]
  %t25 = add i64 %p_8_1, %p_8_7
  %t26 = and i64 %t25, %p_8_0
  %t27 = extractvalue %hia.buffer %p_8_3, 1
  %t28 = call i64 @__hia_fn_1(i64 0, i64 %t26, i64 %t27)
  %t29 = extractvalue %hia.buffer %p_8_3, 0
  %t30 = extractvalue %hia.buffer %p_8_3, 1
  %t31 = icmp ult i64 %t28, %t30
  br i1 %t31, label %ok_32, label %trap_32
trap_32:
  call void @abort()
  unreachable
ok_32:
  %t33 = getelementptr i8, ptr %t29, i64 %t28
  %t34 = load i8, ptr %t33, align 1
  %t35 = extractvalue %hia.buffer %p_8_4, 0
  %t36 = extractvalue %hia.buffer %p_8_4, 1
  %t37 = icmp ult i64 %p_8_5, %t36
  br i1 %t37, label %ok_38, label %trap_38
trap_38:
  call void @abort()
  unreachable
ok_38:
  %t39 = getelementptr i8, ptr %t35, i64 %p_8_5
  store i8 %t34, ptr %t39, align 1
  %t40 = trunc i64 1 to i32
  %t41 = trunc i32 %t40 to i8
  %t42 = insertvalue { i8, i64, i64, i64 } zeroinitializer, i8 %t41, 0
  %t43 = insertvalue { i8, i64, i64, i64 } %t42, i64 %p_8_0, 1
  %t44 = insertvalue { i8, i64, i64, i64 } %t43, i64 %p_8_1, 2
  %t45 = insertvalue { i8, i64, i64, i64 } %t44, i64 %p_8_2, 3
  ret { i8, i64, i64, i64 } %t45
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
}

define internal { i64, i64, i64 } @__hia_fn_13(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3, i8 %p_0_4) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi i8 [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_7 = phi i64 [ 1, %edge_0 ]
  %p_1_8 = phi i64 [ 1, %edge_0 ]
  %p_1_9 = phi i64 [ %t2, %edge_0 ]
  %p_1_10 = phi i64 [ %t6, %edge_0 ]
  %p_1_11 = phi i1 [ %t7, %edge_0 ]
  %t8 = call i8 @__hia_fn_10(i64 %p_1_0, i64 %p_1_1, i64 %p_1_2, %hia.buffer %p_1_3)
  %t9 = trunc i64 0 to i8
  %t10 = icmp ne i8 %t8, %t9
  br i1 %t10, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi i8 [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_7 = phi i64 [ 1, %edge_1 ]
  %p_2_8 = phi i64 [ 1, %edge_1 ]
  %p_2_9 = phi i64 [ %t2, %edge_1 ]
  %p_2_10 = phi i64 [ %t6, %edge_1 ]
  %p_2_11 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi i8 [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i8 [ %p_1_4, %edge_2 ]
  %t11 = trunc i64 1 to i32
  %t12 = sext i32 %t11 to i64
  %t13 = add i64 %p_3_1, %t12
  %t14 = and i64 %t13, %p_3_0
  br label %edge_4
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi i8 [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i8 [ %p_1_4, %edge_3 ]
  br label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ], [ %p_4_0, %edge_5 ]
  %p_5_1 = phi i64 [ %t14, %edge_4 ], [ %p_4_1, %edge_5 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_4 ], [ %p_4_2, %edge_5 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ], [ %p_4_3, %edge_5 ]
  %p_5_4 = phi i8 [ %p_3_4, %edge_4 ], [ %p_4_4, %edge_5 ]
  %p_5_5 = phi i8 [ %p_3_5, %edge_4 ], [ %p_4_5, %edge_5 ]
  %t15 = extractvalue %hia.buffer %p_5_3, 1
  %t16 = call i64 @__hia_fn_1(i64 0, i64 %p_5_2, i64 %t15)
  %t17 = extractvalue %hia.buffer %p_5_3, 0
  %t18 = extractvalue %hia.buffer %p_5_3, 1
  %t19 = icmp ult i64 %t16, %t18
  br i1 %t19, label %ok_20, label %trap_20
trap_20:
  call void @abort()
  unreachable
ok_20:
  %t21 = getelementptr i8, ptr %t17, i64 %t16
  store i8 %p_5_5, ptr %t21, align 1
  %t22 = trunc i64 1 to i32
  %t23 = sext i32 %t22 to i64
  %t24 = add i64 %p_5_2, %t23
  %t25 = and i64 %t24, %p_5_0
  %t26 = insertvalue { i64, i64, i64 } zeroinitializer, i64 %p_5_0, 0
  %t27 = insertvalue { i64, i64, i64 } %t26, i64 %p_5_1, 1
  %t28 = insertvalue { i64, i64, i64 } %t27, i64 %t25, 2
  ret { i64, i64, i64 } %t28
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b5
}

define internal { i64, i64, i64 } @__hia_fn_14(i64 %p_0_0, i64 %p_0_1, i64 %p_0_2, %hia.buffer %p_0_3, %hia.buffer %p_0_4, i64 %p_0_5, i64 %p_0_6) {
b0:
  %t1 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_0_0, i64 1)
  %t2 = extractvalue { i64, i1 } %t1, 0
  %t3 = extractvalue { i64, i1 } %t1, 1
  %t4 = xor i1 %t3, true
  br i1 %t4, label %ok_5, label %trap_5
trap_5:
  call void @abort()
  unreachable
ok_5:
  %t6 = extractvalue %hia.buffer %p_0_3, 1
  %t7 = icmp ule i64 %t2, %t6
  br i1 %t7, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i64 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi %hia.buffer [ %p_0_3, %edge_0 ]
  %p_1_4 = phi %hia.buffer [ %p_0_4, %edge_0 ]
  %p_1_5 = phi i64 [ %p_0_5, %edge_0 ]
  %p_1_6 = phi i64 [ %p_0_6, %edge_0 ]
  %p_1_7 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_8 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_9 = phi i64 [ 1, %edge_0 ]
  %p_1_10 = phi i64 [ 1, %edge_0 ]
  %p_1_11 = phi i64 [ %t2, %edge_0 ]
  %p_1_12 = phi i64 [ %t6, %edge_0 ]
  %p_1_13 = phi i1 [ %t7, %edge_0 ]
  %t8 = extractvalue %hia.buffer %p_1_4, 1
  %t9 = icmp ule i64 %p_1_5, %t8
  br i1 %t9, label %edge_2, label %edge_3
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i64 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi %hia.buffer [ %p_0_3, %edge_1 ]
  %p_2_4 = phi %hia.buffer [ %p_0_4, %edge_1 ]
  %p_2_5 = phi i64 [ %p_0_5, %edge_1 ]
  %p_2_6 = phi i64 [ %p_0_6, %edge_1 ]
  %p_2_7 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_8 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_9 = phi i64 [ 1, %edge_1 ]
  %p_2_10 = phi i64 [ 1, %edge_1 ]
  %p_2_11 = phi i64 [ %t2, %edge_1 ]
  %p_2_12 = phi i64 [ %t6, %edge_1 ]
  %p_2_13 = phi i1 [ %t7, %edge_1 ]
  call void @abort()
  unreachable
b3:
  %p_3_0 = phi i64 [ %p_1_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_1_1, %edge_2 ]
  %p_3_2 = phi i64 [ %p_1_2, %edge_2 ]
  %p_3_3 = phi %hia.buffer [ %p_1_3, %edge_2 ]
  %p_3_4 = phi %hia.buffer [ %p_1_4, %edge_2 ]
  %p_3_5 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_6 = phi i64 [ %p_1_6, %edge_2 ]
  %p_3_7 = phi i64 [ %p_1_5, %edge_2 ]
  %p_3_8 = phi i64 [ %t8, %edge_2 ]
  %p_3_9 = phi i1 [ %t9, %edge_2 ]
  %t10 = extractvalue %hia.buffer %p_3_4, 1
  %t11 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t10, i64 %p_3_5)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  %t14 = xor i1 %t13, true
  br i1 %t14, label %ok_15, label %trap_15
trap_15:
  call void @abort()
  unreachable
ok_15:
  %t16 = icmp ule i64 %p_3_6, %t12
  br i1 %t16, label %edge_4, label %edge_5
b4:
  %p_4_0 = phi i64 [ %p_1_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_1_1, %edge_3 ]
  %p_4_2 = phi i64 [ %p_1_2, %edge_3 ]
  %p_4_3 = phi %hia.buffer [ %p_1_3, %edge_3 ]
  %p_4_4 = phi %hia.buffer [ %p_1_4, %edge_3 ]
  %p_4_5 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_6 = phi i64 [ %p_1_6, %edge_3 ]
  %p_4_7 = phi i64 [ %p_1_5, %edge_3 ]
  %p_4_8 = phi i64 [ %t8, %edge_3 ]
  %p_4_9 = phi i1 [ %t9, %edge_3 ]
  call void @abort()
  unreachable
b5:
  %p_5_0 = phi i64 [ %p_3_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_3_1, %edge_4 ]
  %p_5_2 = phi i64 [ %p_3_2, %edge_4 ]
  %p_5_3 = phi %hia.buffer [ %p_3_3, %edge_4 ]
  %p_5_4 = phi %hia.buffer [ %p_3_4, %edge_4 ]
  %p_5_5 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_6 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_7 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_8 = phi i64 [ %p_3_6, %edge_4 ]
  %p_5_9 = phi i64 [ %t10, %edge_4 ]
  %p_5_10 = phi i64 [ %p_3_5, %edge_4 ]
  %p_5_11 = phi i64 [ %t12, %edge_4 ]
  %p_5_12 = phi i1 [ %t16, %edge_4 ]
  %t17 = trunc i64 0 to i32
  %t18 = sext i32 %t17 to i64
  br label %edge_6
b6:
  %p_6_0 = phi i64 [ %p_3_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_3_1, %edge_5 ]
  %p_6_2 = phi i64 [ %p_3_2, %edge_5 ]
  %p_6_3 = phi %hia.buffer [ %p_3_3, %edge_5 ]
  %p_6_4 = phi %hia.buffer [ %p_3_4, %edge_5 ]
  %p_6_5 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_6 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_7 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_8 = phi i64 [ %p_3_6, %edge_5 ]
  %p_6_9 = phi i64 [ %t10, %edge_5 ]
  %p_6_10 = phi i64 [ %p_3_5, %edge_5 ]
  %p_6_11 = phi i64 [ %t12, %edge_5 ]
  %p_6_12 = phi i1 [ %t16, %edge_5 ]
  call void @abort()
  unreachable
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_6 ], [ %t29, %edge_9 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ], [ %t30, %edge_9 ]
  %p_7_2 = phi i64 [ %p_5_2, %edge_6 ], [ %t31, %edge_9 ]
  %p_7_3 = phi %hia.buffer [ %p_5_3, %edge_6 ], [ %p_8_3, %edge_9 ]
  %p_7_4 = phi %hia.buffer [ %p_5_4, %edge_6 ], [ %p_8_4, %edge_9 ]
  %p_7_5 = phi i64 [ %p_5_5, %edge_6 ], [ %p_8_5, %edge_9 ]
  %p_7_6 = phi i64 [ %p_5_6, %edge_6 ], [ %p_8_6, %edge_9 ]
  %p_7_7 = phi i64 [ %p_5_6, %edge_6 ], [ %p_8_7, %edge_9 ]
  %p_7_8 = phi i64 [ %t18, %edge_6 ], [ %t32, %edge_9 ]
  %t19 = icmp ult i64 %p_7_8, %p_7_7
  br i1 %t19, label %edge_7, label %edge_8
b8:
  %p_8_0 = phi i64 [ %p_7_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_7_1, %edge_7 ]
  %p_8_2 = phi i64 [ %p_7_2, %edge_7 ]
  %p_8_3 = phi %hia.buffer [ %p_7_3, %edge_7 ]
  %p_8_4 = phi %hia.buffer [ %p_7_4, %edge_7 ]
  %p_8_5 = phi i64 [ %p_7_5, %edge_7 ]
  %p_8_6 = phi i64 [ %p_7_6, %edge_7 ]
  %p_8_7 = phi i64 [ %p_7_7, %edge_7 ]
  %p_8_8 = phi i64 [ %p_7_8, %edge_7 ]
  %t20 = extractvalue %hia.buffer %p_8_4, 1
  %t21 = call i64 @__hia_fn_1(i64 %p_8_5, i64 %p_8_8, i64 %t20)
  %t22 = extractvalue %hia.buffer %p_8_4, 0
  %t23 = extractvalue %hia.buffer %p_8_4, 1
  %t24 = icmp ult i64 %t21, %t23
  br i1 %t24, label %ok_25, label %trap_25
trap_25:
  call void @abort()
  unreachable
ok_25:
  %t26 = getelementptr i8, ptr %t22, i64 %t21
  %t27 = load i8, ptr %t26, align 1
  %t28 = call { i64, i64, i64 } @__hia_fn_13(i64 %p_8_0, i64 %p_8_1, i64 %p_8_2, %hia.buffer %p_8_3, i8 %t27)
  %t29 = extractvalue { i64, i64, i64 } %t28, 0
  %t30 = extractvalue { i64, i64, i64 } %t28, 1
  %t31 = extractvalue { i64, i64, i64 } %t28, 2
  %t32 = add i64 %p_8_8, 1
  br label %edge_9
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_8 ]
  %p_9_1 = phi i64 [ %p_7_1, %edge_8 ]
  %p_9_2 = phi i64 [ %p_7_2, %edge_8 ]
  %p_9_3 = phi %hia.buffer [ %p_7_3, %edge_8 ]
  %p_9_4 = phi %hia.buffer [ %p_7_4, %edge_8 ]
  %p_9_5 = phi i64 [ %p_7_5, %edge_8 ]
  %p_9_6 = phi i64 [ %p_7_6, %edge_8 ]
  %p_9_7 = phi i64 [ %p_7_7, %edge_8 ]
  %p_9_8 = phi i64 [ %p_7_8, %edge_8 ]
  %t33 = insertvalue { i64, i64, i64 } zeroinitializer, i64 %p_9_0, 0
  %t34 = insertvalue { i64, i64, i64 } %t33, i64 %p_9_1, 1
  %t35 = insertvalue { i64, i64, i64 } %t34, i64 %p_9_2, 2
  ret { i64, i64, i64 } %t35
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
edge_8:
  br label %b9
edge_9:
  br label %b7
}

define internal i64 @__hia_fn_15(i64 %p_0_0, i64 %p_0_1, i32 %p_0_2, i32 %p_0_3) {
b0:
  %t1 = icmp eq i64 %p_0_0, 0
  br i1 %t1, label %edge_0, label %edge_1
b1:
  %p_1_0 = phi i64 [ %p_0_0, %edge_0 ]
  %p_1_1 = phi i64 [ %p_0_1, %edge_0 ]
  %p_1_2 = phi i32 [ %p_0_2, %edge_0 ]
  %p_1_3 = phi i32 [ %p_0_3, %edge_0 ]
  %t2 = zext i32 %p_1_2 to i64
  ret i64 %t2
b2:
  %p_2_0 = phi i64 [ %p_0_0, %edge_1 ]
  %p_2_1 = phi i64 [ %p_0_1, %edge_1 ]
  %p_2_2 = phi i32 [ %p_0_2, %edge_1 ]
  %p_2_3 = phi i32 [ %p_0_3, %edge_1 ]
  %t3 = icmp ugt i64 %p_2_0, 8
  br i1 %t3, label %edge_2, label %edge_3
b3:
  %p_3_0 = phi i64 [ %p_2_0, %edge_2 ]
  %p_3_1 = phi i64 [ %p_2_1, %edge_2 ]
  %p_3_2 = phi i32 [ %p_2_2, %edge_2 ]
  %p_3_3 = phi i32 [ %p_2_3, %edge_2 ]
  ret i64 4294967296
b4:
  %p_4_0 = phi i64 [ %p_2_0, %edge_3 ]
  %p_4_1 = phi i64 [ %p_2_1, %edge_3 ]
  %p_4_2 = phi i32 [ %p_2_2, %edge_3 ]
  %p_4_3 = phi i32 [ %p_2_3, %edge_3 ]
  %t4 = call %hia.alloc @__hia_allocate(i64 16, i1 true)
  %t5 = extractvalue %hia.alloc %t4, 0
  %t6 = extractvalue %hia.alloc %t4, 1
  %t7 = select i1 %t6, i64 16, i64 0
  %t8 = insertvalue %hia.buffer %t5, i64 %t7, 1
  br i1 %t6, label %edge_4, label %edge_5
b5:
  %p_5_0 = phi i64 [ %p_4_0, %edge_4 ]
  %p_5_1 = phi i64 [ %p_4_1, %edge_4 ]
  %p_5_2 = phi i32 [ %p_4_2, %edge_4 ]
  %p_5_3 = phi i32 [ %p_4_3, %edge_4 ]
  %p_5_4 = phi i1 [ %t6, %edge_4 ]
  %p_5_5 = phi i8 [ 1, %edge_4 ]
  %p_5_6 = phi i1 [ %t6, %edge_4 ]
  %p_5_7 = phi %hia.buffer [ %t8, %edge_4 ]
  %p_5_8 = phi i8 [ 1, %edge_4 ]
  %t9 = call %hia.alloc @__hia_allocate(i64 8, i1 true)
  %t10 = extractvalue %hia.alloc %t9, 0
  %t11 = extractvalue %hia.alloc %t9, 1
  %t12 = select i1 %t11, i64 8, i64 0
  %t13 = insertvalue %hia.buffer %t10, i64 %t12, 1
  br i1 %t11, label %edge_6, label %edge_7
b6:
  %p_6_0 = phi i64 [ %p_4_0, %edge_5 ]
  %p_6_1 = phi i64 [ %p_4_1, %edge_5 ]
  %p_6_2 = phi i32 [ %p_4_2, %edge_5 ]
  %p_6_3 = phi i32 [ %p_4_3, %edge_5 ]
  %p_6_4 = phi i1 [ %t6, %edge_5 ]
  %p_6_5 = phi i8 [ 1, %edge_5 ]
  %p_6_6 = phi i1 [ %t6, %edge_5 ]
  %p_6_7 = phi %hia.buffer [ %t8, %edge_5 ]
  %p_6_8 = phi i8 [ 1, %edge_5 ]
  %t14 = extractvalue %hia.buffer %p_6_7, 0
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %drop_nonnull_16, label %drop_after_16
drop_nonnull_16:
  call void @free(ptr %t14) nobuiltin
  br label %drop_after_16
drop_after_16:
  ret i64 8589934592
b7:
  %p_7_0 = phi i64 [ %p_5_0, %edge_6 ]
  %p_7_1 = phi i64 [ %p_5_1, %edge_6 ]
  %p_7_2 = phi i32 [ %p_5_2, %edge_6 ]
  %p_7_3 = phi i32 [ %p_5_3, %edge_6 ]
  %p_7_4 = phi i1 [ %p_5_4, %edge_6 ]
  %p_7_5 = phi i8 [ %p_5_5, %edge_6 ]
  %p_7_6 = phi %hia.buffer [ %p_5_7, %edge_6 ]
  %p_7_7 = phi i1 [ %t11, %edge_6 ]
  %p_7_8 = phi i8 [ 1, %edge_6 ]
  %p_7_9 = phi i1 [ %t11, %edge_6 ]
  %p_7_10 = phi %hia.buffer [ %t13, %edge_6 ]
  %p_7_11 = phi i8 [ 1, %edge_6 ]
  %t17 = call %hia.alloc @__hia_allocate(i64 8, i1 true)
  %t18 = extractvalue %hia.alloc %t17, 0
  %t19 = extractvalue %hia.alloc %t17, 1
  %t20 = select i1 %t19, i64 8, i64 0
  %t21 = insertvalue %hia.buffer %t18, i64 %t20, 1
  br i1 %t19, label %edge_8, label %edge_9
b8:
  %p_8_0 = phi i64 [ %p_5_0, %edge_7 ]
  %p_8_1 = phi i64 [ %p_5_1, %edge_7 ]
  %p_8_2 = phi i32 [ %p_5_2, %edge_7 ]
  %p_8_3 = phi i32 [ %p_5_3, %edge_7 ]
  %p_8_4 = phi i1 [ %p_5_4, %edge_7 ]
  %p_8_5 = phi i8 [ %p_5_5, %edge_7 ]
  %p_8_6 = phi %hia.buffer [ %p_5_7, %edge_7 ]
  %p_8_7 = phi i1 [ %t11, %edge_7 ]
  %p_8_8 = phi i8 [ 1, %edge_7 ]
  %p_8_9 = phi i1 [ %t11, %edge_7 ]
  %p_8_10 = phi %hia.buffer [ %t13, %edge_7 ]
  %p_8_11 = phi i8 [ 1, %edge_7 ]
  %t22 = extractvalue %hia.buffer %p_8_10, 0
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %drop_nonnull_24, label %drop_after_24
drop_nonnull_24:
  call void @free(ptr %t22) nobuiltin
  br label %drop_after_24
drop_after_24:
  %t25 = extractvalue %hia.buffer %p_8_6, 0
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %drop_nonnull_27, label %drop_after_27
drop_nonnull_27:
  call void @free(ptr %t25) nobuiltin
  br label %drop_after_27
drop_after_27:
  ret i64 8589934592
b9:
  %p_9_0 = phi i64 [ %p_7_0, %edge_8 ]
  %p_9_1 = phi i64 [ %p_7_1, %edge_8 ]
  %p_9_2 = phi i32 [ %p_7_2, %edge_8 ]
  %p_9_3 = phi i32 [ %p_7_3, %edge_8 ]
  %p_9_4 = phi i1 [ %p_7_4, %edge_8 ]
  %p_9_5 = phi i8 [ %p_7_5, %edge_8 ]
  %p_9_6 = phi %hia.buffer [ %p_7_6, %edge_8 ]
  %p_9_7 = phi i1 [ %p_7_7, %edge_8 ]
  %p_9_8 = phi i8 [ %p_7_8, %edge_8 ]
  %p_9_9 = phi %hia.buffer [ %p_7_10, %edge_8 ]
  %p_9_10 = phi i1 [ %t19, %edge_8 ]
  %p_9_11 = phi i8 [ 1, %edge_8 ]
  %p_9_12 = phi i1 [ %t19, %edge_8 ]
  %p_9_13 = phi %hia.buffer [ %t21, %edge_8 ]
  %p_9_14 = phi i8 [ 1, %edge_8 ]
  br label %edge_10
b10:
  %p_10_0 = phi i64 [ %p_7_0, %edge_9 ]
  %p_10_1 = phi i64 [ %p_7_1, %edge_9 ]
  %p_10_2 = phi i32 [ %p_7_2, %edge_9 ]
  %p_10_3 = phi i32 [ %p_7_3, %edge_9 ]
  %p_10_4 = phi i1 [ %p_7_4, %edge_9 ]
  %p_10_5 = phi i8 [ %p_7_5, %edge_9 ]
  %p_10_6 = phi %hia.buffer [ %p_7_6, %edge_9 ]
  %p_10_7 = phi i1 [ %p_7_7, %edge_9 ]
  %p_10_8 = phi i8 [ %p_7_8, %edge_9 ]
  %p_10_9 = phi %hia.buffer [ %p_7_10, %edge_9 ]
  %p_10_10 = phi i1 [ %t19, %edge_9 ]
  %p_10_11 = phi i8 [ 1, %edge_9 ]
  %p_10_12 = phi i1 [ %t19, %edge_9 ]
  %p_10_13 = phi %hia.buffer [ %t21, %edge_9 ]
  %p_10_14 = phi i8 [ 1, %edge_9 ]
  %t28 = extractvalue %hia.buffer %p_10_13, 0
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %drop_nonnull_30, label %drop_after_30
drop_nonnull_30:
  call void @free(ptr %t28) nobuiltin
  br label %drop_after_30
drop_after_30:
  %t31 = extractvalue %hia.buffer %p_10_9, 0
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %drop_nonnull_33, label %drop_after_33
drop_nonnull_33:
  call void @free(ptr %t31) nobuiltin
  br label %drop_after_33
drop_after_33:
  %t34 = extractvalue %hia.buffer %p_10_6, 0
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %drop_nonnull_36, label %drop_after_36
drop_nonnull_36:
  call void @free(ptr %t34) nobuiltin
  br label %drop_after_36
drop_after_36:
  ret i64 8589934592
b11:
  %p_11_0 = phi i64 [ %p_9_0, %edge_10 ], [ %p_12_0, %edge_13 ]
  %p_11_1 = phi i64 [ %p_9_1, %edge_10 ], [ %p_12_1, %edge_13 ]
  %p_11_2 = phi i32 [ %p_9_2, %edge_10 ], [ %p_12_2, %edge_13 ]
  %p_11_3 = phi i32 [ %p_9_3, %edge_10 ], [ %p_12_3, %edge_13 ]
  %p_11_4 = phi i1 [ %p_9_4, %edge_10 ], [ %p_12_4, %edge_13 ]
  %p_11_5 = phi i8 [ %p_9_5, %edge_10 ], [ %p_12_5, %edge_13 ]
  %p_11_6 = phi %hia.buffer [ %p_9_6, %edge_10 ], [ %p_12_6, %edge_13 ]
  %p_11_7 = phi i1 [ %p_9_7, %edge_10 ], [ %p_12_7, %edge_13 ]
  %p_11_8 = phi i8 [ %p_9_8, %edge_10 ], [ %p_12_8, %edge_13 ]
  %p_11_9 = phi %hia.buffer [ %p_9_9, %edge_10 ], [ %p_12_9, %edge_13 ]
  %p_11_10 = phi i1 [ %p_9_10, %edge_10 ], [ %p_12_10, %edge_13 ]
  %p_11_11 = phi i8 [ %p_9_11, %edge_10 ], [ %p_12_11, %edge_13 ]
  %p_11_12 = phi %hia.buffer [ %p_9_13, %edge_10 ], [ %p_12_12, %edge_13 ]
  %p_11_13 = phi i64 [ 0, %edge_10 ], [ %t53, %edge_13 ]
  %t37 = icmp ult i64 %p_11_13, %p_11_0
  br i1 %t37, label %edge_11, label %edge_12
b12:
  %p_12_0 = phi i64 [ %p_11_0, %edge_11 ]
  %p_12_1 = phi i64 [ %p_11_1, %edge_11 ]
  %p_12_2 = phi i32 [ %p_11_2, %edge_11 ]
  %p_12_3 = phi i32 [ %p_11_3, %edge_11 ]
  %p_12_4 = phi i1 [ %p_11_4, %edge_11 ]
  %p_12_5 = phi i8 [ %p_11_5, %edge_11 ]
  %p_12_6 = phi %hia.buffer [ %p_11_6, %edge_11 ]
  %p_12_7 = phi i1 [ %p_11_7, %edge_11 ]
  %p_12_8 = phi i8 [ %p_11_8, %edge_11 ]
  %p_12_9 = phi %hia.buffer [ %p_11_9, %edge_11 ]
  %p_12_10 = phi i1 [ %p_11_10, %edge_11 ]
  %p_12_11 = phi i8 [ %p_11_11, %edge_11 ]
  %p_12_12 = phi %hia.buffer [ %p_11_12, %edge_11 ]
  %p_12_13 = phi i64 [ %p_11_13, %edge_11 ]
  %t38 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %p_12_13, i64 8)
  %t39 = extractvalue { i64, i1 } %t38, 0
  %t40 = extractvalue { i64, i1 } %t38, 1
  %t41 = xor i1 %t40, true
  br i1 %t41, label %ok_42, label %trap_42
trap_42:
  call void @abort()
  unreachable
ok_42:
  %t43 = icmp ult i64 %t39, 64
  br i1 %t43, label %ok_44, label %trap_44
trap_44:
  call void @abort()
  unreachable
ok_44:
  %t45 = lshr i64 %p_12_1, %t39
  %t46 = trunc i64 %t45 to i8
  %t47 = extractvalue %hia.buffer %p_12_9, 0
  %t48 = extractvalue %hia.buffer %p_12_9, 1
  %t49 = icmp ult i64 %p_12_13, %t48
  br i1 %t49, label %ok_50, label %trap_50
trap_50:
  call void @abort()
  unreachable
ok_50:
  %t51 = getelementptr i8, ptr %t47, i64 %p_12_13
  store i8 %t46, ptr %t51, align 1
  %t52 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_12_13, i64 1)
  %t53 = extractvalue { i64, i1 } %t52, 0
  %t54 = extractvalue { i64, i1 } %t52, 1
  %t55 = xor i1 %t54, true
  br i1 %t55, label %ok_56, label %trap_56
trap_56:
  call void @abort()
  unreachable
ok_56:
  br label %edge_13
b13:
  %p_13_0 = phi i64 [ %p_11_0, %edge_12 ]
  %p_13_1 = phi i64 [ %p_11_1, %edge_12 ]
  %p_13_2 = phi i32 [ %p_11_2, %edge_12 ]
  %p_13_3 = phi i32 [ %p_11_3, %edge_12 ]
  %p_13_4 = phi i1 [ %p_11_4, %edge_12 ]
  %p_13_5 = phi i8 [ %p_11_5, %edge_12 ]
  %p_13_6 = phi %hia.buffer [ %p_11_6, %edge_12 ]
  %p_13_7 = phi i1 [ %p_11_7, %edge_12 ]
  %p_13_8 = phi i8 [ %p_11_8, %edge_12 ]
  %p_13_9 = phi %hia.buffer [ %p_11_9, %edge_12 ]
  %p_13_10 = phi i1 [ %p_11_10, %edge_12 ]
  %p_13_11 = phi i8 [ %p_11_11, %edge_12 ]
  %p_13_12 = phi %hia.buffer [ %p_11_12, %edge_12 ]
  %p_13_13 = phi i64 [ %p_11_13, %edge_12 ]
  %t57 = call { i64, i64, i64 } @__hia_fn_8(i64 0, i64 0, i64 0, %hia.buffer %p_13_6, i64 0, i64 16)
  %t58 = extractvalue { i64, i64, i64 } %t57, 0
  %t59 = extractvalue { i64, i64, i64 } %t57, 1
  %t60 = extractvalue { i64, i64, i64 } %t57, 2
  %t61 = call i8 @__hia_fn_9(i64 %t58, i64 %t59, i64 %t60, %hia.buffer %p_13_6)
  %t62 = icmp eq i8 %t61, 1
  br i1 %t62, label %edge_14, label %edge_15
b14:
  %p_14_0 = phi i64 [ %p_13_0, %edge_14 ]
  %p_14_1 = phi i64 [ %p_13_1, %edge_14 ]
  %p_14_2 = phi i32 [ %p_13_2, %edge_14 ]
  %p_14_3 = phi i32 [ %p_13_3, %edge_14 ]
  %p_14_4 = phi i1 [ %p_13_4, %edge_14 ]
  %p_14_5 = phi i8 [ %p_13_5, %edge_14 ]
  %p_14_6 = phi %hia.buffer [ %p_13_6, %edge_14 ]
  %p_14_7 = phi i1 [ %p_13_7, %edge_14 ]
  %p_14_8 = phi i8 [ %p_13_8, %edge_14 ]
  %p_14_9 = phi %hia.buffer [ %p_13_9, %edge_14 ]
  %p_14_10 = phi i1 [ %p_13_10, %edge_14 ]
  %p_14_11 = phi i8 [ %p_13_11, %edge_14 ]
  %p_14_12 = phi %hia.buffer [ %p_13_12, %edge_14 ]
  %p_14_13 = phi i64 [ %p_13_13, %edge_14 ]
  %p_14_14 = phi i64 [ %t58, %edge_14 ]
  %p_14_15 = phi i64 [ %t59, %edge_14 ]
  %p_14_16 = phi i64 [ %t60, %edge_14 ]
  %p_14_17 = phi i64 [ %t58, %edge_14 ]
  %p_14_18 = phi i64 [ %t59, %edge_14 ]
  %p_14_19 = phi i64 [ %t60, %edge_14 ]
  %p_14_20 = phi i8 [ %t61, %edge_14 ]
  %p_14_21 = phi i8 [ 1, %edge_14 ]
  %p_14_22 = phi i1 [ %t62, %edge_14 ]
  %t63 = call { i64, i64, i64 } @__hia_fn_14(i64 %p_14_14, i64 %p_14_15, i64 %p_14_16, %hia.buffer %p_14_6, %hia.buffer %p_14_9, i64 0, i64 %p_14_0)
  %t64 = extractvalue { i64, i64, i64 } %t63, 0
  %t65 = extractvalue { i64, i64, i64 } %t63, 1
  %t66 = extractvalue { i64, i64, i64 } %t63, 2
  %t67 = call i64 @__hia_fn_11(i64 %t64, i64 %t65, i64 %t66, %hia.buffer %p_14_6)
  %t68 = icmp eq i64 %t67, %p_14_0
  br i1 %t68, label %edge_16, label %edge_17
b15:
  %p_15_0 = phi i64 [ %p_13_0, %edge_15 ]
  %p_15_1 = phi i64 [ %p_13_1, %edge_15 ]
  %p_15_2 = phi i32 [ %p_13_2, %edge_15 ]
  %p_15_3 = phi i32 [ %p_13_3, %edge_15 ]
  %p_15_4 = phi i1 [ %p_13_4, %edge_15 ]
  %p_15_5 = phi i8 [ %p_13_5, %edge_15 ]
  %p_15_6 = phi %hia.buffer [ %p_13_6, %edge_15 ]
  %p_15_7 = phi i1 [ %p_13_7, %edge_15 ]
  %p_15_8 = phi i8 [ %p_13_8, %edge_15 ]
  %p_15_9 = phi %hia.buffer [ %p_13_9, %edge_15 ]
  %p_15_10 = phi i1 [ %p_13_10, %edge_15 ]
  %p_15_11 = phi i8 [ %p_13_11, %edge_15 ]
  %p_15_12 = phi %hia.buffer [ %p_13_12, %edge_15 ]
  %p_15_13 = phi i64 [ %p_13_13, %edge_15 ]
  %p_15_14 = phi i64 [ %t58, %edge_15 ]
  %p_15_15 = phi i64 [ %t59, %edge_15 ]
  %p_15_16 = phi i64 [ %t60, %edge_15 ]
  %p_15_17 = phi i64 [ %t58, %edge_15 ]
  %p_15_18 = phi i64 [ %t59, %edge_15 ]
  %p_15_19 = phi i64 [ %t60, %edge_15 ]
  %p_15_20 = phi i8 [ %t61, %edge_15 ]
  %p_15_21 = phi i8 [ 1, %edge_15 ]
  %p_15_22 = phi i1 [ %t62, %edge_15 ]
  call void @abort()
  unreachable
b16:
  %p_16_0 = phi i64 [ %p_14_0, %edge_16 ]
  %p_16_1 = phi i64 [ %p_14_1, %edge_16 ]
  %p_16_2 = phi i32 [ %p_14_2, %edge_16 ]
  %p_16_3 = phi i32 [ %p_14_3, %edge_16 ]
  %p_16_4 = phi i1 [ %p_14_4, %edge_16 ]
  %p_16_5 = phi i8 [ %p_14_5, %edge_16 ]
  %p_16_6 = phi %hia.buffer [ %p_14_6, %edge_16 ]
  %p_16_7 = phi i1 [ %p_14_7, %edge_16 ]
  %p_16_8 = phi i8 [ %p_14_8, %edge_16 ]
  %p_16_9 = phi %hia.buffer [ %p_14_9, %edge_16 ]
  %p_16_10 = phi i1 [ %p_14_10, %edge_16 ]
  %p_16_11 = phi i8 [ %p_14_11, %edge_16 ]
  %p_16_12 = phi %hia.buffer [ %p_14_12, %edge_16 ]
  %p_16_13 = phi i64 [ %p_14_13, %edge_16 ]
  %p_16_14 = phi i64 [ %t64, %edge_16 ]
  %p_16_15 = phi i64 [ %t65, %edge_16 ]
  %p_16_16 = phi i64 [ %t66, %edge_16 ]
  %p_16_17 = phi i64 [ %t64, %edge_16 ]
  %p_16_18 = phi i64 [ %t65, %edge_16 ]
  %p_16_19 = phi i64 [ %t66, %edge_16 ]
  %p_16_20 = phi i64 [ %t67, %edge_16 ]
  %p_16_21 = phi i64 [ %p_14_0, %edge_16 ]
  %p_16_22 = phi i1 [ %t68, %edge_16 ]
  %t69 = call i8 @__hia_fn_10(i64 %p_16_14, i64 %p_16_15, i64 %p_16_16, %hia.buffer %p_16_6)
  %t70 = icmp eq i8 %t69, 0
  br i1 %t70, label %edge_18, label %edge_19
b17:
  %p_17_0 = phi i64 [ %p_14_0, %edge_17 ]
  %p_17_1 = phi i64 [ %p_14_1, %edge_17 ]
  %p_17_2 = phi i32 [ %p_14_2, %edge_17 ]
  %p_17_3 = phi i32 [ %p_14_3, %edge_17 ]
  %p_17_4 = phi i1 [ %p_14_4, %edge_17 ]
  %p_17_5 = phi i8 [ %p_14_5, %edge_17 ]
  %p_17_6 = phi %hia.buffer [ %p_14_6, %edge_17 ]
  %p_17_7 = phi i1 [ %p_14_7, %edge_17 ]
  %p_17_8 = phi i8 [ %p_14_8, %edge_17 ]
  %p_17_9 = phi %hia.buffer [ %p_14_9, %edge_17 ]
  %p_17_10 = phi i1 [ %p_14_10, %edge_17 ]
  %p_17_11 = phi i8 [ %p_14_11, %edge_17 ]
  %p_17_12 = phi %hia.buffer [ %p_14_12, %edge_17 ]
  %p_17_13 = phi i64 [ %p_14_13, %edge_17 ]
  %p_17_14 = phi i64 [ %t64, %edge_17 ]
  %p_17_15 = phi i64 [ %t65, %edge_17 ]
  %p_17_16 = phi i64 [ %t66, %edge_17 ]
  %p_17_17 = phi i64 [ %t64, %edge_17 ]
  %p_17_18 = phi i64 [ %t65, %edge_17 ]
  %p_17_19 = phi i64 [ %t66, %edge_17 ]
  %p_17_20 = phi i64 [ %t67, %edge_17 ]
  %p_17_21 = phi i64 [ %p_14_0, %edge_17 ]
  %p_17_22 = phi i1 [ %t68, %edge_17 ]
  call void @abort()
  unreachable
b18:
  %p_18_0 = phi i64 [ %p_16_0, %edge_18 ]
  %p_18_1 = phi i64 [ %p_16_1, %edge_18 ]
  %p_18_2 = phi i32 [ %p_16_2, %edge_18 ]
  %p_18_3 = phi i32 [ %p_16_3, %edge_18 ]
  %p_18_4 = phi i1 [ %p_16_4, %edge_18 ]
  %p_18_5 = phi i8 [ %p_16_5, %edge_18 ]
  %p_18_6 = phi %hia.buffer [ %p_16_6, %edge_18 ]
  %p_18_7 = phi i1 [ %p_16_7, %edge_18 ]
  %p_18_8 = phi i8 [ %p_16_8, %edge_18 ]
  %p_18_9 = phi %hia.buffer [ %p_16_9, %edge_18 ]
  %p_18_10 = phi i1 [ %p_16_10, %edge_18 ]
  %p_18_11 = phi i8 [ %p_16_11, %edge_18 ]
  %p_18_12 = phi %hia.buffer [ %p_16_12, %edge_18 ]
  %p_18_13 = phi i64 [ %p_16_13, %edge_18 ]
  %p_18_14 = phi i64 [ %p_16_14, %edge_18 ]
  %p_18_15 = phi i64 [ %p_16_15, %edge_18 ]
  %p_18_16 = phi i64 [ %p_16_16, %edge_18 ]
  %p_18_17 = phi i64 [ %p_16_14, %edge_18 ]
  %p_18_18 = phi i64 [ %p_16_15, %edge_18 ]
  %p_18_19 = phi i64 [ %p_16_16, %edge_18 ]
  %p_18_20 = phi i8 [ %t69, %edge_18 ]
  %p_18_21 = phi i8 [ 0, %edge_18 ]
  %p_18_22 = phi i1 [ %t70, %edge_18 ]
  %t71 = call { i8, i64, i64, i64 } @__hia_fn_12(i64 %p_18_14, i64 %p_18_15, i64 %p_18_16, %hia.buffer %p_18_6, %hia.buffer %p_18_12, i64 0, i64 0)
  %t72 = extractvalue { i8, i64, i64, i64 } %t71, 0
  %t73 = extractvalue { i8, i64, i64, i64 } %t71, 1
  %t74 = extractvalue { i8, i64, i64, i64 } %t71, 2
  %t75 = extractvalue { i8, i64, i64, i64 } %t71, 3
  %t76 = icmp eq i8 %t72, 1
  br i1 %t76, label %edge_20, label %edge_21
b19:
  %p_19_0 = phi i64 [ %p_16_0, %edge_19 ]
  %p_19_1 = phi i64 [ %p_16_1, %edge_19 ]
  %p_19_2 = phi i32 [ %p_16_2, %edge_19 ]
  %p_19_3 = phi i32 [ %p_16_3, %edge_19 ]
  %p_19_4 = phi i1 [ %p_16_4, %edge_19 ]
  %p_19_5 = phi i8 [ %p_16_5, %edge_19 ]
  %p_19_6 = phi %hia.buffer [ %p_16_6, %edge_19 ]
  %p_19_7 = phi i1 [ %p_16_7, %edge_19 ]
  %p_19_8 = phi i8 [ %p_16_8, %edge_19 ]
  %p_19_9 = phi %hia.buffer [ %p_16_9, %edge_19 ]
  %p_19_10 = phi i1 [ %p_16_10, %edge_19 ]
  %p_19_11 = phi i8 [ %p_16_11, %edge_19 ]
  %p_19_12 = phi %hia.buffer [ %p_16_12, %edge_19 ]
  %p_19_13 = phi i64 [ %p_16_13, %edge_19 ]
  %p_19_14 = phi i64 [ %p_16_14, %edge_19 ]
  %p_19_15 = phi i64 [ %p_16_15, %edge_19 ]
  %p_19_16 = phi i64 [ %p_16_16, %edge_19 ]
  %p_19_17 = phi i64 [ %p_16_14, %edge_19 ]
  %p_19_18 = phi i64 [ %p_16_15, %edge_19 ]
  %p_19_19 = phi i64 [ %p_16_16, %edge_19 ]
  %p_19_20 = phi i8 [ %t69, %edge_19 ]
  %p_19_21 = phi i8 [ 0, %edge_19 ]
  %p_19_22 = phi i1 [ %t70, %edge_19 ]
  call void @abort()
  unreachable
b20:
  %p_20_0 = phi i64 [ %p_18_0, %edge_20 ]
  %p_20_1 = phi i64 [ %p_18_1, %edge_20 ]
  %p_20_2 = phi i32 [ %p_18_2, %edge_20 ]
  %p_20_3 = phi i32 [ %p_18_3, %edge_20 ]
  %p_20_4 = phi i1 [ %p_18_4, %edge_20 ]
  %p_20_5 = phi i8 [ %p_18_5, %edge_20 ]
  %p_20_6 = phi %hia.buffer [ %p_18_6, %edge_20 ]
  %p_20_7 = phi i1 [ %p_18_7, %edge_20 ]
  %p_20_8 = phi i8 [ %p_18_8, %edge_20 ]
  %p_20_9 = phi %hia.buffer [ %p_18_9, %edge_20 ]
  %p_20_10 = phi i1 [ %p_18_10, %edge_20 ]
  %p_20_11 = phi i8 [ %p_18_11, %edge_20 ]
  %p_20_12 = phi %hia.buffer [ %p_18_12, %edge_20 ]
  %p_20_13 = phi i64 [ %p_18_13, %edge_20 ]
  %p_20_14 = phi i64 [ %t73, %edge_20 ]
  %p_20_15 = phi i64 [ %t74, %edge_20 ]
  %p_20_16 = phi i64 [ %t75, %edge_20 ]
  %p_20_17 = phi i64 [ %p_18_14, %edge_20 ]
  %p_20_18 = phi i64 [ %p_18_15, %edge_20 ]
  %p_20_19 = phi i64 [ %p_18_16, %edge_20 ]
  %p_20_20 = phi i64 [ 0, %edge_20 ]
  %p_20_21 = phi i64 [ 0, %edge_20 ]
  %p_20_22 = phi i8 [ %t72, %edge_20 ]
  %p_20_23 = phi i8 [ 1, %edge_20 ]
  %p_20_24 = phi i1 [ %t76, %edge_20 ]
  %t77 = extractvalue %hia.buffer %p_20_12, 0
  %t78 = extractvalue %hia.buffer %p_20_12, 1
  %t79 = icmp ult i64 0, %t78
  br i1 %t79, label %ok_80, label %trap_80
trap_80:
  call void @abort()
  unreachable
ok_80:
  %t81 = getelementptr i8, ptr %t77, i64 0
  %t82 = load i8, ptr %t81, align 1
  %t83 = extractvalue %hia.buffer %p_20_9, 0
  %t84 = extractvalue %hia.buffer %p_20_9, 1
  %t85 = icmp ult i64 0, %t84
  br i1 %t85, label %ok_86, label %trap_86
trap_86:
  call void @abort()
  unreachable
ok_86:
  %t87 = getelementptr i8, ptr %t83, i64 0
  %t88 = load i8, ptr %t87, align 1
  %t89 = icmp eq i8 %t82, %t88
  br i1 %t89, label %edge_22, label %edge_23
b21:
  %p_21_0 = phi i64 [ %p_18_0, %edge_21 ]
  %p_21_1 = phi i64 [ %p_18_1, %edge_21 ]
  %p_21_2 = phi i32 [ %p_18_2, %edge_21 ]
  %p_21_3 = phi i32 [ %p_18_3, %edge_21 ]
  %p_21_4 = phi i1 [ %p_18_4, %edge_21 ]
  %p_21_5 = phi i8 [ %p_18_5, %edge_21 ]
  %p_21_6 = phi %hia.buffer [ %p_18_6, %edge_21 ]
  %p_21_7 = phi i1 [ %p_18_7, %edge_21 ]
  %p_21_8 = phi i8 [ %p_18_8, %edge_21 ]
  %p_21_9 = phi %hia.buffer [ %p_18_9, %edge_21 ]
  %p_21_10 = phi i1 [ %p_18_10, %edge_21 ]
  %p_21_11 = phi i8 [ %p_18_11, %edge_21 ]
  %p_21_12 = phi %hia.buffer [ %p_18_12, %edge_21 ]
  %p_21_13 = phi i64 [ %p_18_13, %edge_21 ]
  %p_21_14 = phi i64 [ %t73, %edge_21 ]
  %p_21_15 = phi i64 [ %t74, %edge_21 ]
  %p_21_16 = phi i64 [ %t75, %edge_21 ]
  %p_21_17 = phi i64 [ %p_18_14, %edge_21 ]
  %p_21_18 = phi i64 [ %p_18_15, %edge_21 ]
  %p_21_19 = phi i64 [ %p_18_16, %edge_21 ]
  %p_21_20 = phi i64 [ 0, %edge_21 ]
  %p_21_21 = phi i64 [ 0, %edge_21 ]
  %p_21_22 = phi i8 [ %t72, %edge_21 ]
  %p_21_23 = phi i8 [ 1, %edge_21 ]
  %p_21_24 = phi i1 [ %t76, %edge_21 ]
  call void @abort()
  unreachable
b22:
  %p_22_0 = phi i64 [ %p_20_0, %edge_22 ]
  %p_22_1 = phi i64 [ %p_20_1, %edge_22 ]
  %p_22_2 = phi i32 [ %p_20_2, %edge_22 ]
  %p_22_3 = phi i32 [ %p_20_3, %edge_22 ]
  %p_22_4 = phi i1 [ %p_20_4, %edge_22 ]
  %p_22_5 = phi i8 [ %p_20_5, %edge_22 ]
  %p_22_6 = phi %hia.buffer [ %p_20_6, %edge_22 ]
  %p_22_7 = phi i1 [ %p_20_7, %edge_22 ]
  %p_22_8 = phi i8 [ %p_20_8, %edge_22 ]
  %p_22_9 = phi %hia.buffer [ %p_20_9, %edge_22 ]
  %p_22_10 = phi i1 [ %p_20_10, %edge_22 ]
  %p_22_11 = phi i8 [ %p_20_11, %edge_22 ]
  %p_22_12 = phi %hia.buffer [ %p_20_12, %edge_22 ]
  %p_22_13 = phi i64 [ %p_20_13, %edge_22 ]
  %p_22_14 = phi i64 [ %p_20_14, %edge_22 ]
  %p_22_15 = phi i64 [ %p_20_15, %edge_22 ]
  %p_22_16 = phi i64 [ %p_20_16, %edge_22 ]
  %p_22_17 = phi i64 [ 0, %edge_22 ]
  %p_22_18 = phi i8 [ %t82, %edge_22 ]
  %p_22_19 = phi i64 [ 0, %edge_22 ]
  %p_22_20 = phi i8 [ %t88, %edge_22 ]
  %p_22_21 = phi i1 [ %t89, %edge_22 ]
  %t90 = call { i64, i64, i64, i64 } @__hia_fn_7(i64 %p_22_14, i64 %p_22_15, i64 %p_22_16, %hia.buffer %p_22_6, %hia.buffer %p_22_12, i64 0, i64 %p_22_0)
  %t91 = extractvalue { i64, i64, i64, i64 } %t90, 0
  %t92 = extractvalue { i64, i64, i64, i64 } %t90, 1
  %t93 = extractvalue { i64, i64, i64, i64 } %t90, 2
  %t94 = extractvalue { i64, i64, i64, i64 } %t90, 3
  %t95 = icmp eq i64 %t91, %p_22_0
  br i1 %t95, label %edge_24, label %edge_25
b23:
  %p_23_0 = phi i64 [ %p_20_0, %edge_23 ]
  %p_23_1 = phi i64 [ %p_20_1, %edge_23 ]
  %p_23_2 = phi i32 [ %p_20_2, %edge_23 ]
  %p_23_3 = phi i32 [ %p_20_3, %edge_23 ]
  %p_23_4 = phi i1 [ %p_20_4, %edge_23 ]
  %p_23_5 = phi i8 [ %p_20_5, %edge_23 ]
  %p_23_6 = phi %hia.buffer [ %p_20_6, %edge_23 ]
  %p_23_7 = phi i1 [ %p_20_7, %edge_23 ]
  %p_23_8 = phi i8 [ %p_20_8, %edge_23 ]
  %p_23_9 = phi %hia.buffer [ %p_20_9, %edge_23 ]
  %p_23_10 = phi i1 [ %p_20_10, %edge_23 ]
  %p_23_11 = phi i8 [ %p_20_11, %edge_23 ]
  %p_23_12 = phi %hia.buffer [ %p_20_12, %edge_23 ]
  %p_23_13 = phi i64 [ %p_20_13, %edge_23 ]
  %p_23_14 = phi i64 [ %p_20_14, %edge_23 ]
  %p_23_15 = phi i64 [ %p_20_15, %edge_23 ]
  %p_23_16 = phi i64 [ %p_20_16, %edge_23 ]
  %p_23_17 = phi i64 [ 0, %edge_23 ]
  %p_23_18 = phi i8 [ %t82, %edge_23 ]
  %p_23_19 = phi i64 [ 0, %edge_23 ]
  %p_23_20 = phi i8 [ %t88, %edge_23 ]
  %p_23_21 = phi i1 [ %t89, %edge_23 ]
  call void @abort()
  unreachable
b24:
  %p_24_0 = phi i64 [ %p_22_0, %edge_24 ]
  %p_24_1 = phi i64 [ %p_22_1, %edge_24 ]
  %p_24_2 = phi i32 [ %p_22_2, %edge_24 ]
  %p_24_3 = phi i32 [ %p_22_3, %edge_24 ]
  %p_24_4 = phi i1 [ %p_22_4, %edge_24 ]
  %p_24_5 = phi i8 [ %p_22_5, %edge_24 ]
  %p_24_6 = phi %hia.buffer [ %p_22_6, %edge_24 ]
  %p_24_7 = phi i1 [ %p_22_7, %edge_24 ]
  %p_24_8 = phi i8 [ %p_22_8, %edge_24 ]
  %p_24_9 = phi %hia.buffer [ %p_22_9, %edge_24 ]
  %p_24_10 = phi i1 [ %p_22_10, %edge_24 ]
  %p_24_11 = phi i8 [ %p_22_11, %edge_24 ]
  %p_24_12 = phi %hia.buffer [ %p_22_12, %edge_24 ]
  %p_24_13 = phi i64 [ %p_22_13, %edge_24 ]
  %p_24_14 = phi i64 [ %t92, %edge_24 ]
  %p_24_15 = phi i64 [ %t93, %edge_24 ]
  %p_24_16 = phi i64 [ %t94, %edge_24 ]
  %p_24_17 = phi i64 [ %p_22_14, %edge_24 ]
  %p_24_18 = phi i64 [ %p_22_15, %edge_24 ]
  %p_24_19 = phi i64 [ %p_22_16, %edge_24 ]
  %p_24_20 = phi i64 [ 0, %edge_24 ]
  %p_24_21 = phi i64 [ %p_22_0, %edge_24 ]
  %p_24_22 = phi i64 [ %t91, %edge_24 ]
  %p_24_23 = phi i64 [ %p_22_0, %edge_24 ]
  %p_24_24 = phi i1 [ %t95, %edge_24 ]
  %t96 = call i32 @__hia_fn_5(%hia.buffer %p_24_9, i64 0, %hia.buffer %p_24_12, i64 0, i64 %p_24_0)
  %t97 = icmp eq i32 %t96, 0
  br i1 %t97, label %edge_26, label %edge_27
b25:
  %p_25_0 = phi i64 [ %p_22_0, %edge_25 ]
  %p_25_1 = phi i64 [ %p_22_1, %edge_25 ]
  %p_25_2 = phi i32 [ %p_22_2, %edge_25 ]
  %p_25_3 = phi i32 [ %p_22_3, %edge_25 ]
  %p_25_4 = phi i1 [ %p_22_4, %edge_25 ]
  %p_25_5 = phi i8 [ %p_22_5, %edge_25 ]
  %p_25_6 = phi %hia.buffer [ %p_22_6, %edge_25 ]
  %p_25_7 = phi i1 [ %p_22_7, %edge_25 ]
  %p_25_8 = phi i8 [ %p_22_8, %edge_25 ]
  %p_25_9 = phi %hia.buffer [ %p_22_9, %edge_25 ]
  %p_25_10 = phi i1 [ %p_22_10, %edge_25 ]
  %p_25_11 = phi i8 [ %p_22_11, %edge_25 ]
  %p_25_12 = phi %hia.buffer [ %p_22_12, %edge_25 ]
  %p_25_13 = phi i64 [ %p_22_13, %edge_25 ]
  %p_25_14 = phi i64 [ %t92, %edge_25 ]
  %p_25_15 = phi i64 [ %t93, %edge_25 ]
  %p_25_16 = phi i64 [ %t94, %edge_25 ]
  %p_25_17 = phi i64 [ %p_22_14, %edge_25 ]
  %p_25_18 = phi i64 [ %p_22_15, %edge_25 ]
  %p_25_19 = phi i64 [ %p_22_16, %edge_25 ]
  %p_25_20 = phi i64 [ 0, %edge_25 ]
  %p_25_21 = phi i64 [ %p_22_0, %edge_25 ]
  %p_25_22 = phi i64 [ %t91, %edge_25 ]
  %p_25_23 = phi i64 [ %p_22_0, %edge_25 ]
  %p_25_24 = phi i1 [ %t95, %edge_25 ]
  call void @abort()
  unreachable
b26:
  %p_26_0 = phi i64 [ %p_24_0, %edge_26 ]
  %p_26_1 = phi i64 [ %p_24_1, %edge_26 ]
  %p_26_2 = phi i32 [ %p_24_2, %edge_26 ]
  %p_26_3 = phi i32 [ %p_24_3, %edge_26 ]
  %p_26_4 = phi i1 [ %p_24_4, %edge_26 ]
  %p_26_5 = phi i8 [ %p_24_5, %edge_26 ]
  %p_26_6 = phi %hia.buffer [ %p_24_6, %edge_26 ]
  %p_26_7 = phi i1 [ %p_24_7, %edge_26 ]
  %p_26_8 = phi i8 [ %p_24_8, %edge_26 ]
  %p_26_9 = phi %hia.buffer [ %p_24_9, %edge_26 ]
  %p_26_10 = phi i1 [ %p_24_10, %edge_26 ]
  %p_26_11 = phi i8 [ %p_24_11, %edge_26 ]
  %p_26_12 = phi %hia.buffer [ %p_24_12, %edge_26 ]
  %p_26_13 = phi i64 [ %p_24_13, %edge_26 ]
  %p_26_14 = phi i64 [ %p_24_14, %edge_26 ]
  %p_26_15 = phi i64 [ %p_24_15, %edge_26 ]
  %p_26_16 = phi i64 [ %p_24_16, %edge_26 ]
  %p_26_17 = phi i64 [ 0, %edge_26 ]
  %p_26_18 = phi i64 [ 0, %edge_26 ]
  %p_26_19 = phi i64 [ %p_24_0, %edge_26 ]
  %p_26_20 = phi i32 [ %t96, %edge_26 ]
  %p_26_21 = phi i32 [ 0, %edge_26 ]
  %p_26_22 = phi i1 [ %t97, %edge_26 ]
  %t98 = call i32 @__hia_fn_3(%hia.buffer %p_26_9, i64 0, %hia.buffer %p_26_12, i64 0, i64 %p_26_0)
  %t99 = icmp eq i32 %t98, 0
  br i1 %t99, label %edge_28, label %edge_29
b27:
  %p_27_0 = phi i64 [ %p_24_0, %edge_27 ]
  %p_27_1 = phi i64 [ %p_24_1, %edge_27 ]
  %p_27_2 = phi i32 [ %p_24_2, %edge_27 ]
  %p_27_3 = phi i32 [ %p_24_3, %edge_27 ]
  %p_27_4 = phi i1 [ %p_24_4, %edge_27 ]
  %p_27_5 = phi i8 [ %p_24_5, %edge_27 ]
  %p_27_6 = phi %hia.buffer [ %p_24_6, %edge_27 ]
  %p_27_7 = phi i1 [ %p_24_7, %edge_27 ]
  %p_27_8 = phi i8 [ %p_24_8, %edge_27 ]
  %p_27_9 = phi %hia.buffer [ %p_24_9, %edge_27 ]
  %p_27_10 = phi i1 [ %p_24_10, %edge_27 ]
  %p_27_11 = phi i8 [ %p_24_11, %edge_27 ]
  %p_27_12 = phi %hia.buffer [ %p_24_12, %edge_27 ]
  %p_27_13 = phi i64 [ %p_24_13, %edge_27 ]
  %p_27_14 = phi i64 [ %p_24_14, %edge_27 ]
  %p_27_15 = phi i64 [ %p_24_15, %edge_27 ]
  %p_27_16 = phi i64 [ %p_24_16, %edge_27 ]
  %p_27_17 = phi i64 [ 0, %edge_27 ]
  %p_27_18 = phi i64 [ 0, %edge_27 ]
  %p_27_19 = phi i64 [ %p_24_0, %edge_27 ]
  %p_27_20 = phi i32 [ %t96, %edge_27 ]
  %p_27_21 = phi i32 [ 0, %edge_27 ]
  %p_27_22 = phi i1 [ %t97, %edge_27 ]
  call void @abort()
  unreachable
b28:
  %p_28_0 = phi i64 [ %p_26_0, %edge_28 ]
  %p_28_1 = phi i64 [ %p_26_1, %edge_28 ]
  %p_28_2 = phi i32 [ %p_26_2, %edge_28 ]
  %p_28_3 = phi i32 [ %p_26_3, %edge_28 ]
  %p_28_4 = phi i1 [ %p_26_4, %edge_28 ]
  %p_28_5 = phi i8 [ %p_26_5, %edge_28 ]
  %p_28_6 = phi %hia.buffer [ %p_26_6, %edge_28 ]
  %p_28_7 = phi i1 [ %p_26_7, %edge_28 ]
  %p_28_8 = phi i8 [ %p_26_8, %edge_28 ]
  %p_28_9 = phi %hia.buffer [ %p_26_9, %edge_28 ]
  %p_28_10 = phi i1 [ %p_26_10, %edge_28 ]
  %p_28_11 = phi i8 [ %p_26_11, %edge_28 ]
  %p_28_12 = phi %hia.buffer [ %p_26_12, %edge_28 ]
  %p_28_13 = phi i64 [ %p_26_13, %edge_28 ]
  %p_28_14 = phi i64 [ %p_26_14, %edge_28 ]
  %p_28_15 = phi i64 [ %p_26_15, %edge_28 ]
  %p_28_16 = phi i64 [ %p_26_16, %edge_28 ]
  %p_28_17 = phi i64 [ 0, %edge_28 ]
  %p_28_18 = phi i64 [ 0, %edge_28 ]
  %p_28_19 = phi i64 [ %p_26_0, %edge_28 ]
  %p_28_20 = phi i32 [ %t98, %edge_28 ]
  %p_28_21 = phi i32 [ 0, %edge_28 ]
  %p_28_22 = phi i1 [ %t99, %edge_28 ]
  br label %edge_30
b29:
  %p_29_0 = phi i64 [ %p_26_0, %edge_29 ]
  %p_29_1 = phi i64 [ %p_26_1, %edge_29 ]
  %p_29_2 = phi i32 [ %p_26_2, %edge_29 ]
  %p_29_3 = phi i32 [ %p_26_3, %edge_29 ]
  %p_29_4 = phi i1 [ %p_26_4, %edge_29 ]
  %p_29_5 = phi i8 [ %p_26_5, %edge_29 ]
  %p_29_6 = phi %hia.buffer [ %p_26_6, %edge_29 ]
  %p_29_7 = phi i1 [ %p_26_7, %edge_29 ]
  %p_29_8 = phi i8 [ %p_26_8, %edge_29 ]
  %p_29_9 = phi %hia.buffer [ %p_26_9, %edge_29 ]
  %p_29_10 = phi i1 [ %p_26_10, %edge_29 ]
  %p_29_11 = phi i8 [ %p_26_11, %edge_29 ]
  %p_29_12 = phi %hia.buffer [ %p_26_12, %edge_29 ]
  %p_29_13 = phi i64 [ %p_26_13, %edge_29 ]
  %p_29_14 = phi i64 [ %p_26_14, %edge_29 ]
  %p_29_15 = phi i64 [ %p_26_15, %edge_29 ]
  %p_29_16 = phi i64 [ %p_26_16, %edge_29 ]
  %p_29_17 = phi i64 [ 0, %edge_29 ]
  %p_29_18 = phi i64 [ 0, %edge_29 ]
  %p_29_19 = phi i64 [ %p_26_0, %edge_29 ]
  %p_29_20 = phi i32 [ %t98, %edge_29 ]
  %p_29_21 = phi i32 [ 0, %edge_29 ]
  %p_29_22 = phi i1 [ %t99, %edge_29 ]
  call void @abort()
  unreachable
b30:
  %p_30_0 = phi i64 [ %p_28_0, %edge_30 ], [ %p_31_0, %edge_33 ]
  %p_30_1 = phi i64 [ %p_28_1, %edge_30 ], [ %p_31_1, %edge_33 ]
  %p_30_2 = phi i32 [ %p_28_2, %edge_30 ], [ %p_31_2, %edge_33 ]
  %p_30_3 = phi i32 [ %p_28_3, %edge_30 ], [ %p_31_3, %edge_33 ]
  %p_30_4 = phi i1 [ %p_28_4, %edge_30 ], [ %p_31_4, %edge_33 ]
  %p_30_5 = phi i8 [ %p_28_5, %edge_30 ], [ %p_31_5, %edge_33 ]
  %p_30_6 = phi %hia.buffer [ %p_28_6, %edge_30 ], [ %p_31_6, %edge_33 ]
  %p_30_7 = phi i1 [ %p_28_7, %edge_30 ], [ %p_31_7, %edge_33 ]
  %p_30_8 = phi i8 [ %p_28_8, %edge_30 ], [ %p_31_8, %edge_33 ]
  %p_30_9 = phi %hia.buffer [ %p_28_9, %edge_30 ], [ %p_31_9, %edge_33 ]
  %p_30_10 = phi i1 [ %p_28_10, %edge_30 ], [ %p_31_10, %edge_33 ]
  %p_30_11 = phi i8 [ %p_28_11, %edge_30 ], [ %p_31_11, %edge_33 ]
  %p_30_12 = phi %hia.buffer [ %p_28_12, %edge_30 ], [ %p_31_12, %edge_33 ]
  %p_30_13 = phi i64 [ 0, %edge_30 ], [ %t109, %edge_33 ]
  %p_30_14 = phi i64 [ %p_28_14, %edge_30 ], [ %p_31_14, %edge_33 ]
  %p_30_15 = phi i64 [ %p_28_15, %edge_30 ], [ %p_31_15, %edge_33 ]
  %p_30_16 = phi i64 [ %p_28_16, %edge_30 ], [ %p_31_16, %edge_33 ]
  %p_30_17 = phi i32 [ %p_28_2, %edge_30 ], [ %t107, %edge_33 ]
  %t100 = icmp ult i64 %p_30_13, %p_30_0
  br i1 %t100, label %edge_31, label %edge_32
b31:
  %p_31_0 = phi i64 [ %p_30_0, %edge_31 ]
  %p_31_1 = phi i64 [ %p_30_1, %edge_31 ]
  %p_31_2 = phi i32 [ %p_30_2, %edge_31 ]
  %p_31_3 = phi i32 [ %p_30_3, %edge_31 ]
  %p_31_4 = phi i1 [ %p_30_4, %edge_31 ]
  %p_31_5 = phi i8 [ %p_30_5, %edge_31 ]
  %p_31_6 = phi %hia.buffer [ %p_30_6, %edge_31 ]
  %p_31_7 = phi i1 [ %p_30_7, %edge_31 ]
  %p_31_8 = phi i8 [ %p_30_8, %edge_31 ]
  %p_31_9 = phi %hia.buffer [ %p_30_9, %edge_31 ]
  %p_31_10 = phi i1 [ %p_30_10, %edge_31 ]
  %p_31_11 = phi i8 [ %p_30_11, %edge_31 ]
  %p_31_12 = phi %hia.buffer [ %p_30_12, %edge_31 ]
  %p_31_13 = phi i64 [ %p_30_13, %edge_31 ]
  %p_31_14 = phi i64 [ %p_30_14, %edge_31 ]
  %p_31_15 = phi i64 [ %p_30_15, %edge_31 ]
  %p_31_16 = phi i64 [ %p_30_16, %edge_31 ]
  %p_31_17 = phi i32 [ %p_30_17, %edge_31 ]
  %t101 = extractvalue %hia.buffer %p_31_12, 0
  %t102 = extractvalue %hia.buffer %p_31_12, 1
  %t103 = icmp ult i64 %p_31_13, %t102
  br i1 %t103, label %ok_104, label %trap_104
trap_104:
  call void @abort()
  unreachable
ok_104:
  %t105 = getelementptr i8, ptr %t101, i64 %p_31_13
  %t106 = load i8, ptr %t105, align 1
  %t107 = call i32 @__hia_fn_4(i32 %p_31_17, i8 %t106, i32 %p_31_3)
  %t108 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %p_31_13, i64 1)
  %t109 = extractvalue { i64, i1 } %t108, 0
  %t110 = extractvalue { i64, i1 } %t108, 1
  %t111 = xor i1 %t110, true
  br i1 %t111, label %ok_112, label %trap_112
trap_112:
  call void @abort()
  unreachable
ok_112:
  br label %edge_33
b32:
  %p_32_0 = phi i64 [ %p_30_0, %edge_32 ]
  %p_32_1 = phi i64 [ %p_30_1, %edge_32 ]
  %p_32_2 = phi i32 [ %p_30_2, %edge_32 ]
  %p_32_3 = phi i32 [ %p_30_3, %edge_32 ]
  %p_32_4 = phi i1 [ %p_30_4, %edge_32 ]
  %p_32_5 = phi i8 [ %p_30_5, %edge_32 ]
  %p_32_6 = phi %hia.buffer [ %p_30_6, %edge_32 ]
  %p_32_7 = phi i1 [ %p_30_7, %edge_32 ]
  %p_32_8 = phi i8 [ %p_30_8, %edge_32 ]
  %p_32_9 = phi %hia.buffer [ %p_30_9, %edge_32 ]
  %p_32_10 = phi i1 [ %p_30_10, %edge_32 ]
  %p_32_11 = phi i8 [ %p_30_11, %edge_32 ]
  %p_32_12 = phi %hia.buffer [ %p_30_12, %edge_32 ]
  %p_32_13 = phi i64 [ %p_30_13, %edge_32 ]
  %p_32_14 = phi i64 [ %p_30_14, %edge_32 ]
  %p_32_15 = phi i64 [ %p_30_15, %edge_32 ]
  %p_32_16 = phi i64 [ %p_30_16, %edge_32 ]
  %p_32_17 = phi i32 [ %p_30_17, %edge_32 ]
  %t113 = extractvalue %hia.buffer %p_32_9, 0
  %t114 = extractvalue %hia.buffer %p_32_9, 1
  %t115 = icmp ult i64 0, %t114
  br i1 %t115, label %ok_116, label %trap_116
trap_116:
  call void @abort()
  unreachable
ok_116:
  %t117 = getelementptr i8, ptr %t113, i64 0
  %t118 = load i8, ptr %t117, align 1
  %t119 = call { i64, i64, i64 } @__hia_fn_13(i64 %p_32_14, i64 %p_32_15, i64 %p_32_16, %hia.buffer %p_32_6, i8 %t118)
  %t120 = extractvalue { i64, i64, i64 } %t119, 0
  %t121 = extractvalue { i64, i64, i64 } %t119, 1
  %t122 = extractvalue { i64, i64, i64 } %t119, 2
  %t123 = call { i8, i64, i64, i64 } @__hia_fn_6(i64 %t120, i64 %t121, i64 %t122, %hia.buffer %p_32_6, %hia.buffer %p_32_12, i64 0)
  %t124 = extractvalue { i8, i64, i64, i64 } %t123, 0
  %t125 = extractvalue { i8, i64, i64, i64 } %t123, 1
  %t126 = extractvalue { i8, i64, i64, i64 } %t123, 2
  %t127 = extractvalue { i8, i64, i64, i64 } %t123, 3
  %t128 = icmp eq i8 %t124, 1
  br i1 %t128, label %edge_34, label %edge_35
b33:
  %p_33_0 = phi i64 [ %p_32_0, %edge_34 ]
  %p_33_1 = phi i64 [ %p_32_1, %edge_34 ]
  %p_33_2 = phi i32 [ %p_32_2, %edge_34 ]
  %p_33_3 = phi i32 [ %p_32_3, %edge_34 ]
  %p_33_4 = phi i1 [ %p_32_4, %edge_34 ]
  %p_33_5 = phi i8 [ %p_32_5, %edge_34 ]
  %p_33_6 = phi %hia.buffer [ %p_32_6, %edge_34 ]
  %p_33_7 = phi i1 [ %p_32_7, %edge_34 ]
  %p_33_8 = phi i8 [ %p_32_8, %edge_34 ]
  %p_33_9 = phi %hia.buffer [ %p_32_9, %edge_34 ]
  %p_33_10 = phi i1 [ %p_32_10, %edge_34 ]
  %p_33_11 = phi i8 [ %p_32_11, %edge_34 ]
  %p_33_12 = phi %hia.buffer [ %p_32_12, %edge_34 ]
  %p_33_13 = phi i64 [ %p_32_13, %edge_34 ]
  %p_33_14 = phi i64 [ %t125, %edge_34 ]
  %p_33_15 = phi i64 [ %t126, %edge_34 ]
  %p_33_16 = phi i64 [ %t127, %edge_34 ]
  %p_33_17 = phi i32 [ %p_32_17, %edge_34 ]
  %p_33_18 = phi i64 [ %t120, %edge_34 ]
  %p_33_19 = phi i64 [ %t121, %edge_34 ]
  %p_33_20 = phi i64 [ %t122, %edge_34 ]
  %p_33_21 = phi i64 [ 0, %edge_34 ]
  %p_33_22 = phi i8 [ %t124, %edge_34 ]
  %p_33_23 = phi i8 [ 1, %edge_34 ]
  %p_33_24 = phi i1 [ %t128, %edge_34 ]
  %t129 = extractvalue %hia.buffer %p_33_12, 0
  %t130 = extractvalue %hia.buffer %p_33_12, 1
  %t131 = icmp ult i64 0, %t130
  br i1 %t131, label %ok_132, label %trap_132
trap_132:
  call void @abort()
  unreachable
ok_132:
  %t133 = getelementptr i8, ptr %t129, i64 0
  %t134 = load i8, ptr %t133, align 1
  %t135 = extractvalue %hia.buffer %p_33_9, 0
  %t136 = extractvalue %hia.buffer %p_33_9, 1
  %t137 = icmp ult i64 0, %t136
  br i1 %t137, label %ok_138, label %trap_138
trap_138:
  call void @abort()
  unreachable
ok_138:
  %t139 = getelementptr i8, ptr %t135, i64 0
  %t140 = load i8, ptr %t139, align 1
  %t141 = icmp eq i8 %t134, %t140
  br i1 %t141, label %edge_36, label %edge_37
b34:
  %p_34_0 = phi i64 [ %p_32_0, %edge_35 ]
  %p_34_1 = phi i64 [ %p_32_1, %edge_35 ]
  %p_34_2 = phi i32 [ %p_32_2, %edge_35 ]
  %p_34_3 = phi i32 [ %p_32_3, %edge_35 ]
  %p_34_4 = phi i1 [ %p_32_4, %edge_35 ]
  %p_34_5 = phi i8 [ %p_32_5, %edge_35 ]
  %p_34_6 = phi %hia.buffer [ %p_32_6, %edge_35 ]
  %p_34_7 = phi i1 [ %p_32_7, %edge_35 ]
  %p_34_8 = phi i8 [ %p_32_8, %edge_35 ]
  %p_34_9 = phi %hia.buffer [ %p_32_9, %edge_35 ]
  %p_34_10 = phi i1 [ %p_32_10, %edge_35 ]
  %p_34_11 = phi i8 [ %p_32_11, %edge_35 ]
  %p_34_12 = phi %hia.buffer [ %p_32_12, %edge_35 ]
  %p_34_13 = phi i64 [ %p_32_13, %edge_35 ]
  %p_34_14 = phi i64 [ %t125, %edge_35 ]
  %p_34_15 = phi i64 [ %t126, %edge_35 ]
  %p_34_16 = phi i64 [ %t127, %edge_35 ]
  %p_34_17 = phi i32 [ %p_32_17, %edge_35 ]
  %p_34_18 = phi i64 [ %t120, %edge_35 ]
  %p_34_19 = phi i64 [ %t121, %edge_35 ]
  %p_34_20 = phi i64 [ %t122, %edge_35 ]
  %p_34_21 = phi i64 [ 0, %edge_35 ]
  %p_34_22 = phi i8 [ %t124, %edge_35 ]
  %p_34_23 = phi i8 [ 1, %edge_35 ]
  %p_34_24 = phi i1 [ %t128, %edge_35 ]
  call void @abort()
  unreachable
b35:
  %p_35_0 = phi i64 [ %p_33_0, %edge_36 ]
  %p_35_1 = phi i64 [ %p_33_1, %edge_36 ]
  %p_35_2 = phi i32 [ %p_33_2, %edge_36 ]
  %p_35_3 = phi i32 [ %p_33_3, %edge_36 ]
  %p_35_4 = phi i1 [ %p_33_4, %edge_36 ]
  %p_35_5 = phi i8 [ %p_33_5, %edge_36 ]
  %p_35_6 = phi %hia.buffer [ %p_33_6, %edge_36 ]
  %p_35_7 = phi i1 [ %p_33_7, %edge_36 ]
  %p_35_8 = phi i8 [ %p_33_8, %edge_36 ]
  %p_35_9 = phi %hia.buffer [ %p_33_9, %edge_36 ]
  %p_35_10 = phi i1 [ %p_33_10, %edge_36 ]
  %p_35_11 = phi i8 [ %p_33_11, %edge_36 ]
  %p_35_12 = phi %hia.buffer [ %p_33_12, %edge_36 ]
  %p_35_13 = phi i64 [ %p_33_13, %edge_36 ]
  %p_35_14 = phi i64 [ %p_33_14, %edge_36 ]
  %p_35_15 = phi i64 [ %p_33_15, %edge_36 ]
  %p_35_16 = phi i64 [ %p_33_16, %edge_36 ]
  %p_35_17 = phi i32 [ %p_33_17, %edge_36 ]
  %p_35_18 = phi i64 [ 0, %edge_36 ]
  %p_35_19 = phi i8 [ %t134, %edge_36 ]
  %p_35_20 = phi i64 [ 0, %edge_36 ]
  %p_35_21 = phi i8 [ %t140, %edge_36 ]
  %p_35_22 = phi i1 [ %t141, %edge_36 ]
  %t142 = call i8 @__hia_fn_9(i64 %p_35_14, i64 %p_35_15, i64 %p_35_16, %hia.buffer %p_35_6)
  %t143 = icmp eq i8 %t142, 1
  br i1 %t143, label %edge_38, label %edge_39
b36:
  %p_36_0 = phi i64 [ %p_33_0, %edge_37 ]
  %p_36_1 = phi i64 [ %p_33_1, %edge_37 ]
  %p_36_2 = phi i32 [ %p_33_2, %edge_37 ]
  %p_36_3 = phi i32 [ %p_33_3, %edge_37 ]
  %p_36_4 = phi i1 [ %p_33_4, %edge_37 ]
  %p_36_5 = phi i8 [ %p_33_5, %edge_37 ]
  %p_36_6 = phi %hia.buffer [ %p_33_6, %edge_37 ]
  %p_36_7 = phi i1 [ %p_33_7, %edge_37 ]
  %p_36_8 = phi i8 [ %p_33_8, %edge_37 ]
  %p_36_9 = phi %hia.buffer [ %p_33_9, %edge_37 ]
  %p_36_10 = phi i1 [ %p_33_10, %edge_37 ]
  %p_36_11 = phi i8 [ %p_33_11, %edge_37 ]
  %p_36_12 = phi %hia.buffer [ %p_33_12, %edge_37 ]
  %p_36_13 = phi i64 [ %p_33_13, %edge_37 ]
  %p_36_14 = phi i64 [ %p_33_14, %edge_37 ]
  %p_36_15 = phi i64 [ %p_33_15, %edge_37 ]
  %p_36_16 = phi i64 [ %p_33_16, %edge_37 ]
  %p_36_17 = phi i32 [ %p_33_17, %edge_37 ]
  %p_36_18 = phi i64 [ 0, %edge_37 ]
  %p_36_19 = phi i8 [ %t134, %edge_37 ]
  %p_36_20 = phi i64 [ 0, %edge_37 ]
  %p_36_21 = phi i8 [ %t140, %edge_37 ]
  %p_36_22 = phi i1 [ %t141, %edge_37 ]
  call void @abort()
  unreachable
b37:
  %p_37_0 = phi i64 [ %p_35_0, %edge_38 ]
  %p_37_1 = phi i64 [ %p_35_1, %edge_38 ]
  %p_37_2 = phi i32 [ %p_35_2, %edge_38 ]
  %p_37_3 = phi i32 [ %p_35_3, %edge_38 ]
  %p_37_4 = phi i1 [ %p_35_4, %edge_38 ]
  %p_37_5 = phi i8 [ %p_35_5, %edge_38 ]
  %p_37_6 = phi %hia.buffer [ %p_35_6, %edge_38 ]
  %p_37_7 = phi i1 [ %p_35_7, %edge_38 ]
  %p_37_8 = phi i8 [ %p_35_8, %edge_38 ]
  %p_37_9 = phi %hia.buffer [ %p_35_9, %edge_38 ]
  %p_37_10 = phi i1 [ %p_35_10, %edge_38 ]
  %p_37_11 = phi i8 [ %p_35_11, %edge_38 ]
  %p_37_12 = phi %hia.buffer [ %p_35_12, %edge_38 ]
  %p_37_13 = phi i64 [ %p_35_13, %edge_38 ]
  %p_37_14 = phi i64 [ %p_35_14, %edge_38 ]
  %p_37_15 = phi i64 [ %p_35_15, %edge_38 ]
  %p_37_16 = phi i64 [ %p_35_16, %edge_38 ]
  %p_37_17 = phi i32 [ %p_35_17, %edge_38 ]
  %p_37_18 = phi i64 [ %p_35_14, %edge_38 ]
  %p_37_19 = phi i64 [ %p_35_15, %edge_38 ]
  %p_37_20 = phi i64 [ %p_35_16, %edge_38 ]
  %p_37_21 = phi i8 [ %t142, %edge_38 ]
  %p_37_22 = phi i8 [ 1, %edge_38 ]
  %p_37_23 = phi i1 [ %t143, %edge_38 ]
  %t144 = extractvalue %hia.buffer %p_37_12, 0
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %drop_nonnull_146, label %drop_after_146
drop_nonnull_146:
  call void @free(ptr %t144) nobuiltin
  br label %drop_after_146
drop_after_146:
  %t147 = extractvalue %hia.buffer %p_37_9, 0
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %drop_nonnull_149, label %drop_after_149
drop_nonnull_149:
  call void @free(ptr %t147) nobuiltin
  br label %drop_after_149
drop_after_149:
  %t150 = extractvalue %hia.buffer %p_37_6, 0
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %drop_nonnull_152, label %drop_after_152
drop_nonnull_152:
  call void @free(ptr %t150) nobuiltin
  br label %drop_after_152
drop_after_152:
  %t153 = zext i32 %p_37_17 to i64
  ret i64 %t153
b38:
  %p_38_0 = phi i64 [ %p_35_0, %edge_39 ]
  %p_38_1 = phi i64 [ %p_35_1, %edge_39 ]
  %p_38_2 = phi i32 [ %p_35_2, %edge_39 ]
  %p_38_3 = phi i32 [ %p_35_3, %edge_39 ]
  %p_38_4 = phi i1 [ %p_35_4, %edge_39 ]
  %p_38_5 = phi i8 [ %p_35_5, %edge_39 ]
  %p_38_6 = phi %hia.buffer [ %p_35_6, %edge_39 ]
  %p_38_7 = phi i1 [ %p_35_7, %edge_39 ]
  %p_38_8 = phi i8 [ %p_35_8, %edge_39 ]
  %p_38_9 = phi %hia.buffer [ %p_35_9, %edge_39 ]
  %p_38_10 = phi i1 [ %p_35_10, %edge_39 ]
  %p_38_11 = phi i8 [ %p_35_11, %edge_39 ]
  %p_38_12 = phi %hia.buffer [ %p_35_12, %edge_39 ]
  %p_38_13 = phi i64 [ %p_35_13, %edge_39 ]
  %p_38_14 = phi i64 [ %p_35_14, %edge_39 ]
  %p_38_15 = phi i64 [ %p_35_15, %edge_39 ]
  %p_38_16 = phi i64 [ %p_35_16, %edge_39 ]
  %p_38_17 = phi i32 [ %p_35_17, %edge_39 ]
  %p_38_18 = phi i64 [ %p_35_14, %edge_39 ]
  %p_38_19 = phi i64 [ %p_35_15, %edge_39 ]
  %p_38_20 = phi i64 [ %p_35_16, %edge_39 ]
  %p_38_21 = phi i8 [ %t142, %edge_39 ]
  %p_38_22 = phi i8 [ 1, %edge_39 ]
  %p_38_23 = phi i1 [ %t143, %edge_39 ]
  call void @abort()
  unreachable
edge_0:
  br label %b1
edge_1:
  br label %b2
edge_2:
  br label %b3
edge_3:
  br label %b4
edge_4:
  br label %b5
edge_5:
  br label %b6
edge_6:
  br label %b7
edge_7:
  br label %b8
edge_8:
  br label %b9
edge_9:
  br label %b10
edge_10:
  br label %b11
edge_11:
  br label %b12
edge_12:
  br label %b13
edge_13:
  br label %b11
edge_14:
  br label %b14
edge_15:
  br label %b15
edge_16:
  br label %b16
edge_17:
  br label %b17
edge_18:
  br label %b18
edge_19:
  br label %b19
edge_20:
  br label %b20
edge_21:
  br label %b21
edge_22:
  br label %b22
edge_23:
  br label %b23
edge_24:
  br label %b24
edge_25:
  br label %b25
edge_26:
  br label %b26
edge_27:
  br label %b27
edge_28:
  br label %b28
edge_29:
  br label %b29
edge_30:
  br label %b30
edge_31:
  br label %b31
edge_32:
  br label %b32
edge_33:
  br label %b30
edge_34:
  br label %b33
edge_35:
  br label %b34
edge_36:
  br label %b35
edge_37:
  br label %b36
edge_38:
  br label %b37
edge_39:
  br label %b38
}

define i32 @c_bool_to_int(i1 zeroext %a0) {
entry:
  %result = call i32 @__hia_fn_0(i1 %a0)
  ret i32 %result
}

define i64 @c_view_index_unsigned(i64 %a0, i64 %a1, i64 %a2) {
entry:
  %result = call i64 @__hia_fn_1(i64 %a0, i64 %a1, i64 %a2)
  ret i64 %result
}

define i64 @c_view_index_signed(i64 %a0, i64 %a1, i64 %a2) {
entry:
  %result = call i64 @__hia_fn_2(i64 %a0, i64 %a1, i64 %a2)
  ret i64 %result
}

define i32 @c_checksum_byte(i32 %a0, i8 zeroext %a1, i32 %a2) {
entry:
  %result = call i32 @__hia_fn_4(i32 %a0, i8 %a1, i32 %a2)
  ret i32 %result
}

define i64 @legacy_checksum_chunk(i64 %a0, i64 %a1, i32 %a2, i32 %a3) {
entry:
  %result = call i64 @__hia_fn_15(i64 %a0, i64 %a1, i32 %a2, i32 %a3)
  ret i64 %result
}
