#include "checksum.h"

unsigned int checksum_byte(unsigned int state, unsigned char byte,
                           unsigned int polynomial) {
    unsigned int value = state ^ (unsigned int)byte;
    unsigned int bit = 0;
    do {
        if ((value & 1U) != 0) {
            value = (value >> 1U) ^ polynomial;
        } else {
            value = value >> 1U;
        }
        bit++;
    } while (bit < 8);
    return value;
}
