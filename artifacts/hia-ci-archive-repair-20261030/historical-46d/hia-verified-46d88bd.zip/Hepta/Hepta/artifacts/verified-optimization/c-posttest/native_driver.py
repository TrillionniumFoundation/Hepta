import ctypes,json,sys
paths=json.loads(sys.argv[1]); cases=json.loads(open(sys.argv[2]).read())
libraries={key:ctypes.CDLL(path) for key,path in paths.items()}
functions={key:getattr(lib,"legacy_checksum_chunk") for key,lib in libraries.items()}
for fn in functions.values():
    fn.argtypes=[ctypes.c_size_t,ctypes.c_uint64,ctypes.c_uint32,ctypes.c_uint32]
    fn.restype=ctypes.c_uint64
for index,case in enumerate(cases):
    print(json.dumps({"index":index,"arguments":case["arguments"],
        "observed":{label:int(fn(*case["arguments"])) for label,fn in functions.items()}}),flush=True)
