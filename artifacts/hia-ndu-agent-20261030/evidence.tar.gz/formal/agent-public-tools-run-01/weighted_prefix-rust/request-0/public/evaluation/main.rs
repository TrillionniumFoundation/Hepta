#![forbid(unsafe_code)]
use std::io::{self,Read};
fn target(x: u32, y: u32) -> u32 {
    let mut sum = 0u32;
    for i in 0..(y % 33) {
        sum = sum.wrapping_add(x.wrapping_add(i) ^ (17 * i));
    }
    sum
}
fn main(){let target_contract:fn(u32,u32)->u32=target;let mut s=String::new();io::stdin().read_to_string(&mut s).unwrap();let mut t=s.split_whitespace();while let Some(a)=t.next(){let x:u32=a.parse().unwrap();let y:u32=t.next().unwrap().parse().unwrap();println!("{}",target_contract(x,y));}}
