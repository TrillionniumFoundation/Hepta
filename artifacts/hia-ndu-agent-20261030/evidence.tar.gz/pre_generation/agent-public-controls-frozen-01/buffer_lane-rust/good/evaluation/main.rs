#![forbid(unsafe_code)]
use std::io::{self,Read};
fn target(x:u32,y:u32)->u32 { let n=(x%17+1) as usize; let mut data=vec![0u8;n]; let index=(y as usize)%n; data[index]=x.wrapping_add(y) as u8; let readback=data[index] as u32; drop(data); 256*n as u32+readback }
fn main(){let mut s=String::new();io::stdin().read_to_string(&mut s).unwrap();let mut t=s.split_whitespace();while let Some(a)=t.next(){let x:u32=a.parse().unwrap();let y:u32=t.next().unwrap().parse().unwrap();println!("{}",target(x,y));}}
