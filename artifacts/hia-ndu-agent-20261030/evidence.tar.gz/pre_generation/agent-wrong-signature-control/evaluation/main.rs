#![forbid(unsafe_code)]
use std::io::{self,Read};
fn target(x:u32,y:u32)->u64 { y.min(1000u32.saturating_sub(x)) as u64 }
fn main(){let mut s=String::new();io::stdin().read_to_string(&mut s).unwrap();let mut t=s.split_whitespace();while let Some(a)=t.next(){let x:u32=a.parse().unwrap();let y:u32=t.next().unwrap().parse().unwrap();println!("{}",target(x,y));}}
