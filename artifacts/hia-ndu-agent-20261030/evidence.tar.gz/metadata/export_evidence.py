#!/usr/bin/env python3
"""Post-run evidence export only: no model, compiler, workload or tuning calls."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import gzip
import io
import json
from pathlib import Path
import subprocess
import tarfile


BASE = Path('/workspace/scratch/793cbcdf54ed')
REPO = BASE / 'Hepta'
OUT = REPO / 'artifacts/hia-ndu-agent-20261030'
REGISTERED = 'e223932a8bf25521db4204883af925dd64acc57a'
SOURCE = '71aff3e9dbaa89601e0e0acacacac6c775e9f7f1'


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def ident(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}


def main():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    assert head == REGISTERED, 'HEAD advanced before frozen source export'
    # Re-encoding this derived evidence package never reruns either study.
    OUT.mkdir(parents=True, exist_ok=True)
    agent_path = BASE / 'agent-public-tools-run-01/RESULT.json'
    ndu_path = BASE / 'ndu-converged-holdout-run-01/RESULT.json'
    agent, ndu = read(agent_path), read(ndu_path)
    af = read(REPO / 'benchmarks/hia_agent_public_tools/FREEZE.json')
    nf = read(REPO / 'benchmarks/hia_ndu_converged_holdout/FREEZE.json')
    assert agent['registration_commit'] == ndu['registration_commit'] == REGISTERED
    assert af['code_commit'] == nf['code_commit'] == SOURCE
    assert agent['identities_unchanged'] and ndu['source_unchanged']
    bindings = {}
    for frozen in (af, nf):
        for name, expected in frozen['bindings'].items():
            assert name not in bindings or bindings[name] == expected
            assert ident(REPO / name)['sha256'] == expected, name
            bindings[name] = expected

    cell_rows = []
    all_usage = Counter()
    for cell in agent['cells']:
        requests = cell['requests']
        usage = {key: sum(q['usage'][key] for q in requests) for key in requests[0]['usage']}
        all_usage.update(usage)
        model_wall = sum(q['process']['wall_ns'] for q in requests)
        tool_wall = sum(t['wall_ns'] for t in cell['tool_calls'])
        hidden = list((BASE / 'agent-public-tools-run-01' / (cell['task']+'-'+cell['language'])).glob('request-*/HIDDEN.json'))
        assert len(hidden) == 1
        h = read(hidden[0])
        assert h['accepted'] and h['correct']
        assert h['execution']['case_count'] == 72
        assert h['execution']['actual'] == h['execution']['expected']
        failures = [{'error': t['public'].get('error'), 'status': t['public'].get('status')}
                    for t in cell['tool_calls'] if 'public' in t and not t['public']['accepted']]
        cell_rows.append({
            'task': cell['task'], 'language': cell['language'], 'correct': cell['correct'],
            'charged_tokens': cell['charged_tokens'], 'observed_usage': usage,
            'complete_usage': cell['complete_usage'], 'requests': len(requests),
            'tool_call_counts': dict(Counter(t['name'] for t in cell['tool_calls'])),
            'public_failed_checks': cell['public_failed_checks'], 'failures': failures,
            'cell_wall_ns': cell['wall_ns'], 'model_process_wall_ns': model_wall,
            'public_rpc_wall_ns': tool_wall, 'terminal_hidden_wall_ns': cell['hidden_wall_ns'],
            'cell_other_observed_wall_ns': cell['wall_ns']-model_wall-tool_wall-cell['hidden_wall_ns'],
            'hidden_case_count': h['execution']['case_count'],
            'hidden_report': ident(hidden[0]),
            'native_values_match_oracle': True,
            'hia_vm_case_count': len(h.get('interpreter', [])),
            'rust_audit_case_count': len(h.get('resource_audit', {}).get('ledgers', [])),
            'model_processes_cleaned': all(q['process']['cleanup_confirmed'] for q in requests),
            'empty_model_workdirs_removed': all(q['empty_cwd_removed'] for q in requests),
            'human_answer_repairs': cell['human_answer_repairs'],
        })
    group = agent['summary']['groups']
    graph = ndu['graph']
    transitions = {arm: sum(len(e['transitions']) for e in graph['episodes'] if e['arm'] == arm)
                   for arm in ndu['costs']['already_built_marginal_total_ns']}
    summary = {
        'schema': 'hepta.hia.ndu-agent.evidence-summary.v1',
        'source_commit': SOURCE, 'registration_commit': REGISTERED,
        'exported_at_utc': datetime.now(timezone.utc).isoformat(),
        'export_did_not_invoke_model_compiler_or_workload': True,
        'formal_study_runs': {'ndu': 1, 'agent': 1}, 'post_observation_reruns': 0,
        'bound_source_files_verified_at_export': len(bindings),
        'agent_result': ident(agent_path), 'ndu_result': ident(ndu_path),
        'agent': {
            'model_cli_alias': agent['model'], 'status': agent['status'],
            'summary': agent['summary'], 'cells': cell_rows,
            'observed_usage': dict(all_usage), 'wall_ns': agent['wall_ns'],
            'shared_observed_wall_ns': agent['wall_ns']-sum(c['wall_ns'] for c in agent['cells']),
            'hia_to_rust_charged_token_ratio': group['hia']['charged_tokens']/group['rust']['charged_tokens'],
            'hia_to_rust_cell_wall_ratio': group['hia']['wall_ns']/group['rust']['wall_ns'],
            'registered_charge_formula': 'input_tokens + output_tokens + reasoning_output_tokens; cached_input_tokens are already a subset of input_tokens',
            'token_accounting_limit': 'This registered charge is not an invoice. Provider output/reasoning overlap and price are not inferred.',
            'human_answer_repairs': agent['human_answer_repairs'],
            'identities_unchanged': agent['identities_unchanged'],
            'task_sampling': 'Four author-prepared tasks, one cell per language per task, no population representativeness or statistical superiority claim.',
            'resource_evidence_scope': 'HIA actual VM events plus native values; Rust selected audited safe Vec API events plus native values. Neither is a general machine-code refinement or whole-process allocator proof.',
            'environment_scope': 'Provider scheduling/cache and exact routed model weights are not controlled or attested. Rust uses the frozen restricted lexical/API profile.',
        },
        'ndu': {
            'status': ndu['status'], 'outer_execution_ns': ndu['outer_execution_ns'],
            'episodes': len(graph['episodes']), 'actual_transitions': graph['actual_transitions'],
            'transitions_by_arm': transitions,
            **{k: graph[k] for k in ('all_actual_budgets_passed','all_episodes_completed','all_outputs_correct','authority','native_binary_sha256','native_transport')},
            'costs': ndu['costs'], 'source_unchanged': ndu['source_unchanged'],
            'interpretation': 'No measured native NDU contribution beyond exact Q32 DP/light control in this two-group finite candidate study; both native variants cost more even with the bridge prebuilt.',
            'fixed_best_scope': 'Best calibrated full plan within the same finite HIA candidate bank; not a strongest cross-language static compiler baseline.',
            'original_build_scope': 'The original observed empty-target build is charged from its historical hash-bound receipts; no new bridge build was run for this study.',
            'decision_input_scope': 'Same candidate bank, initial information and zero-capacity caches. Each episode observes its own actual past costs, so per-arm evolving request/path hashes need not match.',
        },
        'previous_negative_results_replaced': False,
        'development_evidence_scope': 'Pre-generation controls and integration test histories are archived separately and are not counted as model successes or formal holdout replications.',
    }
    commands = {
        'schema': 'hepta.hia.ndu-agent.commands.v1', 'cwd': str(REPO),
        'registration_commit': REGISTERED, 'sequence': ['ndu', 'agent'],
        'environment': {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': '/workspace/scratch/cd43ab608057/hia-python-deps'},
        'execution_context': 'Normal process/network context was approved; the sealed native identity check was not weakened to accommodate sandbox PID namespace differences.',
        'commands': [
            {'name': 'ndu', 'argv': ['python3','tools/qualify_hia_ndu_converged_holdout.py','run','--output',str(BASE/'ndu-converged-holdout-run-01'),'--registration-commit',REGISTERED],
             'combined_output': str(BASE/'ndu-converged-holdout-run-01.log'), 'exit_code': 0},
            {'name': 'agent', 'argv': ['python3','tools/qualify_hia_agent_public_tools.py','run','--output',str(BASE/'agent-public-tools-run-01'),'--review','experiments/agent_public_tools/INDEPENDENT_REVIEW.json','--registration-commit',REGISTERED],
             'combined_output': str(BASE/'agent-public-tools-run-01.log'), 'exit_code': 0},
        ],
        'no_concurrent_native_study': 'Migration/strong-static study owner explicitly handed over the CPU window before NDU. Agent started only after NDU exited.',
        'nested_commands': 'Actual per-request CLI/compiler/linker/native argv, raw streams and process ownership/cleanup receipts are retained inside the evidence archive.',
        'reproduction_note': 'These are recorded commands, not an instruction to repeat registered holdout observations or replace their results.',
    }
    (OUT/'SUMMARY.json').write_bytes(encoded(summary))
    (OUT/'COMMANDS.json').write_bytes(encoded(commands))
    (OUT/'AGENT_RESULT.json').write_bytes(agent_path.read_bytes())
    (OUT/'NDU_COSTS.json').write_bytes(encoded(ndu['costs']))

    rows = []
    for task in ('quota_clip','rotate_lane','weighted_prefix','buffer_lane'):
        pair = {c['language']: c for c in cell_rows if c['task'] == task}
        h, r = pair['hia'], pair['rust']
        rows.append(f"| {task} | {h['requests']} / {r['requests']} | {h['charged_tokens']:,} / {r['charged_tokens']:,} | {h['cell_wall_ns']/1e9:.6f} / {r['cell_wall_ns']/1e9:.6f} | {h['public_failed_checks']} / {r['public_failed_checks']} |")
    cost_rows = []
    for arm in ('fixed-base','fixed-small','fixed-wide','fixed-best-plan','light','q32-dp','ndu','ndu-compact'):
        costs = ndu['costs']
        cost_rows.append(f"| {arm} | {costs['startup_cost_ns'][arm]/1e9:.9f} | {costs['already_built_marginal_total_ns'][arm]/1e9:.9f} | {costs['standalone_with_original_build_total_ns'][arm]/1e9:.9f} | {transitions[arm]} |")
    readme = f"""# Registered NDU and Agent studies — 2026-10-30

Both one-time studies completed on registration `{REGISTERED}` and source `{SOURCE}`. The formal results are negative for the proposed efficiency advantages: native NDU did not beat exact Q32 DP or the lightweight controller, and HIA required more requests, registered token charge and elapsed cell time than Rust despite equal task success.

## NDU: eight arms, two groups

All 16 episodes completed, all native results matched their independent checks, all actual budgets passed, and four transitions executed. The wrapper took **18.990028649 s**. Each standalone arm is charged the same shared preparation; the arm totals below consequently must not be added to estimate the one shared experiment duration.

| Arm | Startup, including historical native build where applicable (s) | Prebuilt marginal total (s) | Standalone total with original native build (s) | Actual transitions |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(cost_rows)}

Full and compact NDU cost **0.114185302 s** and **0.107094016 s** more than exact Q32 DP even with the native bridge already built. Charging the original observed empty-target native build of **21.387330636 s** raises those deficits to **21.501515938 s** and **21.494424652 s**. That build cost comes from the original retained build envelope; this run did not repeat the native build.

Fixed-best-plan, light, Q32 DP and both native variants all stayed on the base candidate in both episodes. This is evidence of no independent NDU benefit in the registered finite problem, not evidence that more complicated future planning problems cannot benefit. The two observed episodes give only short-run amortization: Q32 DP **2.6435031025 s** per episode, full NDU **13.3942610715 s**, and compact NDU **13.3907154285 s** when startup/build are included. Long-run amortization was not measured.

The bank, initial information, budgets and zero-capacity advisory caches were common. Each arm could observe its own completed executions; evolving measured cost/request/path hashes can therefore differ. Frozen future seed observations were withheld until their actual episodes. Shapes were disclosed equally and same-shape calibration was permitted. `fixed-best-plan` is the strongest calibrated plan in this candidate bank; it is not a strongest C/C++/Rust/LTO/PGO baseline. NDU is a finite evaluator here, not a trained planner or a proof of global instruction optimality. Safety decisions remain with independent verification; native NDU has `DENY_ALL` authority.

Preparation, proof, compilation, decisions, switching/loading, execution, graph serialization, native startup/shutdown and the observed wrapper overhead are charged. Toolchain/dependency acquisition, human work, persistent evidence retention and final wrapper-result encoding/write are disclosed exclusions or unknown costs. No lifetime net gain, statistical superiority, cross-language superiority, global optimality or safety-from-NDU claim is made.

## Agent: four fresh tasks, HIA and Rust

Both languages achieved **4/4 accepted tasks**. Each final candidate passed 6 public and 72 terminal hidden native cases; HIA also passed its VM/oracle checks. The buffer task retained actual HIA VM resource events and Rust audited safe-Vec events. All **20 real CLI requests** have complete reported usage, confirmed process cleanup and removed empty model working directories. There were no human answer repairs and no post-observation reruns.

| Task | Requests HIA / Rust | Registered token charge HIA / Rust | Cell wall time HIA / Rust (s) | Failed public checks HIA / Rust |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}
| **Total** | **13 / 7** | **244,188 / 109,290** | **95.565022 / 38.357775** | **1 / 0** |

HIA used **2.2343×** the registered token charge and **2.4914×** the total cell wall time. The full study took **136.001399127 s**, including **2.078602907 s** of observed shared overhead outside cell totals. Per-cell totals include model requests, public tools/compilation, terminal hidden evaluation, protocol work and process cleanup. The negative descriptive HIA-advantage gate is preserved unchanged.

All four HIA cells actually called the complete selected-version instruction catalog. The HIA `weighted_prefix` candidate first failed with `E_HIA_SSA: SSA value count is defined more than once`; the model used the public diagnostic to repair the candidate and passed its next check. This original failed candidate, feedback and additional request/usage remain in the raw archive. Rust had no failed public checks.

The registered token charge is `input + output + reasoning`; cached input is already a subset of input and is not added again. It is not a monetary invoice: output/reasoning overlap and provider prices are not inferred. Raw usage fields are retained. The CLI alias was `gpt-6.1-sol`, with the frozen executable hash; routed model weights, service scheduling and cache state were not controlled or attested. Four author-prepared tasks and the restricted Rust lexical/API profile do not establish population-level productivity. Human review time remains unknown, so no human-cost advantage is claimed.

Resource evidence covers the exercised cases and selected interfaces. HIA VM events do not prove machine-code refinement. Rust audited Vec events do not count every process allocation or prove every machine store; mutable access plus correct readback cannot distinguish zero-to-zero assignment from merely taking a mutable reference. These qualifications were frozen before generation.

## Reproducibility and retained negatives

`SUMMARY.json` is the compact machine-readable readout, `AGENT_RESULT.json` is the unchanged full Agent result, `NDU_COSTS.json` is the unchanged NDU cost ledger, and `COMMANDS.json` records the two formal invocations. `evidence.tar.gz` preserves all formal raw text, source snapshots, prompts, request/response streams, usage, actual compilation/execution records, hidden reports, proof/transition records, freezes, amendment histories, independent review and historical native build receipts. `EVIDENCE_MANIFEST.json` inventories every included file and every omitted ELF/native archive by SHA-256 and byte count. Native binaries are retained at their original run paths but omitted from this compact archive; no text/raw model stream is omitted.

The `pre_generation/` archive tree preserves earlier controls, real acceptance-bypass probes, integration test failures and successful follow-ups. These are author-written/no-generation controls, not human or model benchmark successes. The final independently reviewed controls passed on all 8 reference cells and reject wrong values and signatures. Pre-generation repairs closed actual Rust comment/dead-helper resource bypasses, HIA uncalled-helper resource bypasses, incorrect Rust ABI acceptance, RPC-type crashes, and the HIA parameter-name restriction. The review contributed the Rust audit fixture and is an internal separate-reviewer check, not an external audit. Historical failed results and unpublished registrations remain identifiable and are not replaced by the formal run.

Export is a post-run file/hash operation only. It invokes no model, compiler or benchmark, and it does not change the registered results or source. The exact export script is retained inside the archive.
"""
    (OUT/'README.md').write_text(readme)

    sources = {}
    def add_file(path, name):
        p = Path(path)
        assert p.is_file(), str(p)
        assert name not in sources, name
        sources[name] = p
    def add_tree(path, prefix):
        for p in sorted(Path(path).rglob('*')):
            if p.is_file():
                add_file(p, prefix+'/'+p.relative_to(path).as_posix())
    for run in ('ndu-converged-holdout-run-01','agent-public-tools-run-01'):
        add_tree(BASE/run, 'formal/'+run)
        add_file(BASE/(run+'.log'), 'formal/'+run+'.log')
    dev_dirs = ('agent-public-controls-precommit','agent-public-controls-frozen-01',
                'agent-public-controls-interface-fix-01','agent-public-controls-audited-01',
                'agent-public-controls-audited-02','agent-wrong-signature-control',
                'ndu-integrated-boundaries','ndu-integrated-boundaries-02','ndu-integrated-boundaries-87f3787')
    for name in dev_dirs:
        add_tree(BASE/name, 'pre_generation/'+name)
    for p in sorted(BASE.iterdir()):
        if p.is_file() and p.suffix == '.log' and p.name.startswith(('agent-','ndu-')) and not p.name.endswith('run-01.log'):
            add_file(p, 'pre_generation/'+p.name)
    for name in sorted(bindings):
        add_file(REPO/name, 'source/'+name)
    for name in ('benchmarks/hia_agent_public_tools','benchmarks/hia_ndu_converged_holdout'):
        for p in sorted((REPO/name).rglob('*')):
            if p.is_file() and p.suffix != '.pyc':
                add_file(p, 'registration/'+p.relative_to(REPO).as_posix())
    add_file(REPO/'experiments/agent_public_tools/INDEPENDENT_REVIEW.json', 'registration/INDEPENDENT_REVIEW.json')
    add_file(nf['native_identity']['path'], 'native-build/identity.json')
    add_file(nf['native_envelope']['path'], 'native-build/BUILD_ENVELOPE.json')
    for name in ('SUMMARY.json','COMMANDS.json','README.md'):
        add_file(OUT/name, 'metadata/'+name)
    add_file(Path(__file__), 'metadata/export_evidence.py')

    included, omitted = [], []
    archive = OUT/'evidence.tar.gz'
    with archive.open('wb') as sink, gzip.GzipFile(fileobj=sink, mode='wb', filename='', mtime=0, compresslevel=9) as gz, tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
        for name, path in sorted(sources.items()):
            raw = path.read_bytes()
            item = {'archive_path': name, 'original_path': str(path), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}
            if raw.startswith((b'\x7fELF', b'!<arch>\n')) or '__pycache__' in path.parts or path.suffix == '.pyc':
                item['reason'] = 'native_binary_or_object' if raw.startswith((b'\x7fELF',b'!<arch>\n')) else 'regenerable_python_bytecode'
                omitted.append(item)
                continue
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info,io.BytesIO(raw))
            included.append(item)
    manifest = {
        'schema': 'hepta.hia.ndu-agent.evidence-manifest.v1',
        'source_commit': SOURCE, 'registration_commit': REGISTERED,
        'archive': ident(archive), 'included_files': included, 'omitted_files': omitted,
        'included_file_count': len(included), 'included_bytes': sum(x['bytes'] for x in included),
        'omitted_file_count': len(omitted), 'omitted_bytes': sum(x['bytes'] for x in omitted),
        'external_executables_bound_but_not_packaged': {**af['tools'], 'ndu_native_binary': nf['native_binary']},
        'complete_raw_text_preserved': True,
        'unmodified_registered_source_bindings': bindings,
        'archive_scope': 'All files present under both formal run roots plus listed pre-generation controls/logs, source union, registration records and historical native build receipts. Only individually inventoried native ELF/archive files or Python bytecode are omitted.',
    }
    (OUT/'EVIDENCE_MANIFEST.json').write_bytes(encoded(manifest))
    expected = {x['archive_path']: x for x in included}
    checked = 0
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            raw = tar.extractfile(member).read()
            item = expected.pop(member.name)
            assert len(raw) == item['bytes'] and sha256(raw).hexdigest() == item['sha256']
            checked += 1
    assert not expected and checked == len(included)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip() == REGISTERED
    for name, expected_hash in bindings.items():
        assert ident(REPO/name)['sha256'] == expected_hash
    verification = {
        'schema':'hepta.hia.ndu-agent.export-verification.v1',
        'registration_commit': REGISTERED, 'source_bindings_checked': len(bindings),
        'archive_members_rehashed': checked, 'all_archive_members_match': True,
        'manifest': ident(OUT/'EVIDENCE_MANIFEST.json'), 'archive': ident(archive),
        'metadata': {name: ident(OUT/name) for name in ('README.md','SUMMARY.json','COMMANDS.json','AGENT_RESULT.json','NDU_COSTS.json')},
        'new_model_requests': 0, 'new_compiles_or_workload_runs': 0,
    }
    (OUT/'EXPORT_VERIFICATION.json').write_bytes(encoded(verification))
    print(json.dumps({'output':str(OUT),'archive':ident(archive),'included_files':len(included),'omitted_files':len(omitted),'bound_sources':len(bindings),'agent_gate':agent['summary']['descriptive_hia_advantage_gate'],'ndu_gate':ndu['costs']['measured_scope_net_gain']}))


if __name__ == '__main__':
    main()
