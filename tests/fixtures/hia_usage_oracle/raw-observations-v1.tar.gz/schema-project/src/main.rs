#[path = "/Users/qianqi/work/hia-runtime-archive-oracle-20261127-2807/src/mcp/mod.rs"] mod mcp;
fn main() { println!("{}", serde_json::to_string(&schemars::schema_for!(mcp::runtime::request_audit::UsageStatsParams)).unwrap()); }
