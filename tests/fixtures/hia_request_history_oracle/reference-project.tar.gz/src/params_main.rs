mod mcp { pub mod runtime { pub mod request_audit; } }
use std::io::{BufRead, Write};
fn main() -> anyhow::Result<()> {
    if std::env::args().nth(1).as_deref() == Some("--debug-ranges") {
        let mut ranges = Vec::<(u32,u32)>::new();
        let mut contexts = Vec::new();
        let mut context_count = 0u32;
        let mut scalar_count = 0u32;
        for code in 0..=0x10ffff {
            if let Some(value) = char::from_u32(code) {
                scalar_count += 1;
                let single = format!("{:?}", value.to_string());
                let after = format!("{:?}", format!("x{}", value));
                if after != format!("\"x{}", &single[1..]) {
                    context_count += 1;
                    if contexts.len() < 64 { contexts.push((code,single.clone(),after)); }
                }
                if single.starts_with("\"\\u{") {
                    if let Some(last) = ranges.last_mut() {
                        if last.1 + 1 == code { last.1 = code; continue; }
                    }
                    ranges.push((code,code));
                }
            }
        }
        println!("{}", serde_json::to_string(&serde_json::json!({
            "scalar_count":scalar_count,"context_differences":context_count,
            "context_samples":contexts,"ranges":ranges,
            "unicode_version":char::UNICODE_VERSION
        }))?);
        return Ok(());
    }
    for line in std::io::stdin().lock().lines() {
        let row: serde_json::Value = serde_json::from_str(&line?)?;
        let value: serde_json::Value = serde_json::from_str(row["params_json"].as_str().unwrap())?;
        let result = rmcp::handler::server::tool::parse_json_object::<mcp::runtime::request_audit::RequestHistoryParams>(value.as_object().unwrap().clone());
        let answer = match result {
            Ok(_) => serde_json::json!({"id": row["id"], "parameters": "accepted", "value":value}),
            Err(error) => serde_json::json!({"id": row["id"], "error":error,"value":value}),
        };
        writeln!(std::io::stdout(), "{}", serde_json::to_string(&answer)?)?;
    }
    Ok(())
}
