// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
// Qualification-only exact source projection. Production definitions below are
// copied without edits from request_audit.rs at ae1c7ea593da45f7299c692a2acd44605c35be09.
#![allow(dead_code)]
use anyhow::{anyhow, bail, Result};
use rmcp::schemars;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::{HashMap, VecDeque};
use std::fs::File;
use std::io::Read;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock, Weak};
use std::time::Instant;
#[path="request_audit_trace.rs"]
mod trace;
const MAX_GLOBAL: usize = 512;
const MAX_OWNER: usize = 128;
const MAX_RECORD_BYTES: usize = 2048;
const MAX_PAGE_BYTES: usize = 64 * 1024;
const STORE_NAME: &str = "request-audit";
static STORE_LOCK: OnceLock<AuditStoreLock> = OnceLock::new();
static ACTIVE: OnceLock<Mutex<HashMap<String, Weak<AtomicBool>>>> = OnceLock::new();
#[derive(Debug, Clone, Deserialize, schemars::JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct RequestHistoryParams {
	/// Last returned request id. Expired and other-owner cursors are refused.
	#[serde(default)]
	pub after_id: Option<String>,
	/// At most 32 metadata records; default 32. No parameters or output are returned.
	#[serde(default)]
	pub limit: Option<u16>,
}


#[derive(Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum DurableState {
	Unknown,
	Completed,
	Failed,
}

mod record_schema {
	use super::DurableState;
	use serde::{Deserialize, Serialize};

	// Serde derives its default Visitor diagnostic from the Rust identifier,
	// not serde(rename). Keep the original name for both string specializations.
	#[derive(Clone, Deserialize, Serialize, PartialEq, Eq)]
	#[serde(deny_unknown_fields)]
	pub(super) struct Record<S> {
		pub(super) request_id: S,
		pub(super) owner: S,
		pub(super) tool_name: S,
		pub(super) state: DurableState,
		pub(super) accepted_unix_ms: u128,
		pub(super) elapsed_ms: Option<u64>,
	}
}
// Owned publications, projections and legacy rows keep their original type.
// Complete original verification borrows only the three string fields from its
// current bounded input; both forms share this exact serde field contract.
type RecordFields<S> = record_schema::Record<S>;
type Record = record_schema::Record<String>;


// Writers and recovery paths retain the original mutex and FIFO reservation.
// At most two prepared, read-only archive cohorts may share a turn. Readers
// never pass a queued writer and retain custody until their actual work ends.
#[derive(Clone, Copy, PartialEq, Eq)]
enum AuditStoreAccess {
	Exclusive,
	#[cfg(unix)]
	Shared,
}

#[derive(Default)]
struct AuditStoreQueue {
	next_ticket: u64,
	active: bool,
	readers: usize,
	reader_poisoned: bool,
	waiting: VecDeque<(u64, AuditStoreAccess)>,
}

#[derive(Default)]
struct AuditStoreLock {
	inner: Mutex<()>,
	queue: Mutex<AuditStoreQueue>,
	changed: std::sync::Condvar,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum StoreLockFailure {
	Deadline,
	Unavailable,
}

#[must_use = "the store guard must cover the protected operation"]
struct AuditStoreGuard<'a> {
	lock: &'a AuditStoreLock,
	inner: Option<std::sync::MutexGuard<'a, ()>>,
}

#[cfg(unix)]
#[must_use = "finish the read guard while the final snapshot state remains locked"]
struct AuditSharedGuard<'a> {
	lock: &'a AuditStoreLock,
	deadline: Instant,
	active: bool,
	// A panic must publish poison on the same thread that owns this operation.
	_not_send: std::marker::PhantomData<std::sync::MutexGuard<'a, ()>>,
}

impl AuditStoreLock {
	fn cancel(&self, queue: &mut AuditStoreQueue, ticket: u64) {
		queue.waiting.retain(|queued| queued.0 != ticket);
		self.changed.notify_all();
	}

	fn release(&self) {
		// Cleanup releases custody during unwinding without clearing poison.
		let mut queue = self.queue.lock().unwrap_or_else(|error| error.into_inner());
		queue.active = false;
		self.changed.notify_all();
	}

	fn acquire(
		&self,
		deadline: Option<Instant>,
	) -> std::result::Result<AuditStoreGuard<'_>, StoreLockFailure> {
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		let mut queue = self
			.queue
			.lock()
			.map_err(|_| StoreLockFailure::Unavailable)?;
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		if queue.reader_poisoned {
			return Err(StoreLockFailure::Unavailable);
		}
		let ticket = queue.next_ticket;
		queue.next_ticket = ticket.checked_add(1).ok_or(StoreLockFailure::Unavailable)?;
		queue
			.waiting
			.push_back((ticket, AuditStoreAccess::Exclusive));
		loop {
			if deadline.is_some_and(|limit| Instant::now() >= limit) {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Deadline);
			}
			if queue.reader_poisoned {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Unavailable);
			}
			if !queue.active
				&& queue.readers == 0
				&& queue.waiting.front() == Some(&(ticket, AuditStoreAccess::Exclusive))
			{
				queue.waiting.pop_front();
				queue.active = true;
				break;
			}
			let waited = match deadline {
				Some(limit) => self
					.changed
					.wait_timeout(queue, limit.saturating_duration_since(Instant::now()))
					.map(|(queue, _)| queue)
					.map_err(|error| error.into_inner().0),
				None => self.changed.wait(queue).map_err(|error| error.into_inner()),
			};
			queue = match waited {
				Ok(queue) => queue,
				Err(mut queue) => {
					self.cancel(&mut queue, ticket);
					return Err(StoreLockFailure::Unavailable);
				}
			};
		}
		drop(queue);
		let mut guard = AuditStoreGuard {
			lock: self,
			inner: None,
		};
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		// The former owner drops inner before releasing its FIFO reservation.
		// No second, unbounded wait is introduced after admission.
		match self.inner.try_lock() {
			Ok(inner) => guard.inner = Some(inner),
			Err(std::sync::TryLockError::Poisoned(error)) => {
				drop(error.into_inner());
				return Err(StoreLockFailure::Unavailable);
			}
			Err(std::sync::TryLockError::WouldBlock) => {
				return Err(StoreLockFailure::Unavailable);
			}
		}
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		Ok(guard)
	}

	#[cfg(unix)]
	fn acquire_shared(
		&self,
		deadline: Instant,
	) -> std::result::Result<AuditSharedGuard<'_>, StoreLockFailure> {
		if Instant::now() >= deadline {
			return Err(StoreLockFailure::Deadline);
		}
		let mut queue = self
			.queue
			.lock()
			.map_err(|_| StoreLockFailure::Unavailable)?;
		if Instant::now() >= deadline {
			return Err(StoreLockFailure::Deadline);
		}
		if queue.reader_poisoned || self.inner.is_poisoned() {
			return Err(StoreLockFailure::Unavailable);
		}
		let ticket = queue.next_ticket;
		queue.next_ticket = ticket.checked_add(1).ok_or(StoreLockFailure::Unavailable)?;
		queue.waiting.push_back((ticket, AuditStoreAccess::Shared));
		loop {
			if Instant::now() >= deadline {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Deadline);
			}
			if queue.reader_poisoned || self.inner.is_poisoned() {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Unavailable);
			}
			if !queue.active && queue.waiting.front() == Some(&(ticket, AuditStoreAccess::Shared)) {
				queue.waiting.pop_front();
				queue.readers += 1;
				// Let the next adjacent reader observe its own admission condition.
				self.changed.notify_all();
				break;
			}
			queue = match self
				.changed
				.wait_timeout(queue, deadline.saturating_duration_since(Instant::now()))
			{
				Ok((queue, _)) => queue,
				Err(error) => {
					let (mut queue, _) = error.into_inner();
					self.cancel(&mut queue, ticket);
					return Err(StoreLockFailure::Unavailable);
				}
			};
		}
		drop(queue);
		let guard = AuditSharedGuard {
			lock: self,
			deadline,
			active: true,
			_not_send: std::marker::PhantomData,
		};
		if Instant::now() >= deadline {
			return Err(StoreLockFailure::Deadline);
		}
		Ok(guard)
	}
}

#[cfg(unix)]
impl AuditSharedGuard<'_> {
	fn finish(mut self) -> std::result::Result<(), StoreLockFailure> {
		let mut queue = match self.lock.queue.lock() {
			Ok(queue) => queue,
			Err(error) => {
				drop(error.into_inner());
				return Err(StoreLockFailure::Unavailable);
			}
		};
		// This critical section is the success boundary. A peer that already
		// finished is not retroactively revoked by later poison publication.
		let mut result = if queue.reader_poisoned || self.lock.inner.is_poisoned() {
			Err(StoreLockFailure::Unavailable)
		} else if Instant::now() >= self.deadline {
			Err(StoreLockFailure::Deadline)
		} else {
			Ok(())
		};
		match queue.readers.checked_sub(1) {
			Some(readers) => queue.readers = readers,
			None => {
				queue.reader_poisoned = true;
				result = Err(StoreLockFailure::Unavailable);
			}
		}
		self.active = false;
		self.lock.changed.notify_all();
		result
	}
}

#[cfg(unix)]
impl Drop for AuditSharedGuard<'_> {
	fn drop(&mut self) {
		if !self.active {
			return;
		}
		let mut queue = self
			.lock
			.queue
			.lock()
			.unwrap_or_else(|error| error.into_inner());
		if std::thread::panicking() {
			queue.reader_poisoned = true;
		}
		match queue.readers.checked_sub(1) {
			Some(readers) => queue.readers = readers,
			None => queue.reader_poisoned = true,
		}
		self.active = false;
		self.lock.changed.notify_all();
	}
}

impl Drop for AuditStoreGuard<'_> {
	fn drop(&mut self) {
		// Keep standard mutex poison and release inner before the FIFO turn.
		drop(self.inner.take());
		self.lock.release();
	}
}

fn store_lock() -> Result<AuditStoreGuard<'static>> {
	trace::measure("store_lock_wait", 0, None, || {
		STORE_LOCK
			.get_or_init(AuditStoreLock::default)
			.acquire(None)
			.map_err(|_| anyhow!("request audit state lock unavailable"))
	})
}

fn active_registry() -> Result<std::sync::MutexGuard<'static, HashMap<String, Weak<AtomicBool>>>> {
	ACTIVE
		.get_or_init(|| Mutex::new(HashMap::new()))
		.lock()
		.map_err(|_| anyhow!("request audit active registry unavailable"))
}


fn valid_id(value: &str) -> bool {
	value.len() == 64
		&& value
			.bytes()
			.all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}


fn valid_tool(value: &str) -> bool {
	!value.is_empty()
		&& value.len() <= 64
		&& value
			.bytes()
			.all(|byte| byte.is_ascii_lowercase() || byte == b'_')
}


fn is_dispatch_active(id: &str) -> Result<bool> {
	let mut registry = active_registry()?;
	registry.retain(|_, marker| marker.strong_count() > 0);
	Ok(registry
		.get(id)
		.and_then(Weak::upgrade)
		.is_some_and(|marker| marker.load(Ordering::Acquire)))
}


fn name(value: &str) -> Result<std::ffi::CString> {
	std::ffi::CString::new(value).map_err(|_| anyhow!("invalid private metadata component"))
}


fn open_at(directory: &File, component: &str, flags: i32, mode: u32) -> Result<File> {
	let component = name(component)?;
	open_at_component(directory, &component, flags, mode)
}


fn private_directory(directory: &File) -> Result<()> {
	private_directory_metadata(directory).map(|_| ())
}


fn private_directory_metadata(directory: &File) -> Result<std::fs::Metadata> {
	use std::os::unix::fs::MetadataExt;
	let metadata = directory.metadata()?;
	if !metadata.is_dir()
		|| metadata.uid() != unsafe { libc::geteuid() }
		|| metadata.mode() & 0o7777 != 0o700
	{
		bail!("private request audit directory refused");
	}
	Ok(metadata)
}


fn open_store(root: &Path) -> Result<File> {
	open_named_store(root, STORE_NAME)
}


fn open_named_store(root: &Path, store_name: &str) -> Result<File> {
	let base = audit_root(root)?;
	open_named_store_at(&base, store_name)
}


fn open_named_store_at(base: &File, store_name: &str) -> Result<File> {
	use std::os::fd::AsRawFd;
	let folder = name(store_name)?;
	let made = unsafe { libc::mkdirat(base.as_raw_fd(), folder.as_ptr(), 0o700) };
	if made < 0 {
		let error = std::io::Error::last_os_error();
		if error.kind() != std::io::ErrorKind::AlreadyExists {
			return Err(error.into());
		}
	} else {
		base.sync_all()?;
	}
	let directory = open_at(base, store_name, libc::O_RDONLY | libc::O_DIRECTORY, 0)?;
	private_directory(&directory)?;
	Ok(directory)
}


fn audit_root(root: &Path) -> Result<File> {
	use std::os::fd::FromRawFd;
	use std::os::unix::fs::MetadataExt;
	let raw = root
		.to_str()
		.ok_or_else(|| anyhow!("request audit root is not UTF-8"))?;
	if !root.is_absolute() || raw.split('/').any(|part| part == "." || part == "..") {
		bail!("invalid request audit root");
	}
	let components: Vec<_> = raw.split('/').filter(|part| !part.is_empty()).collect();
	#[cfg(target_os = "linux")]
	let ancestor_access = libc::O_PATH;
	#[cfg(not(target_os = "linux"))]
	let ancestor_access = libc::O_RDONLY;
	let slash = name("/")?;
	let descriptor = unsafe {
		libc::open(
			slash.as_ptr(),
			ancestor_access | libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC,
		)
	};
	if descriptor < 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	let mut base = unsafe { File::from_raw_fd(descriptor) };
	for (index, component) in components.iter().enumerate() {
		// Linux O_PATH needs search permission, not directory-listing permission.
		// Keep explicit denial of non-searchable ancestors even for privileged
		// callers, and open the private final directory as a normal fsync-able FD.
		if base.metadata()?.mode() & 0o111 == 0 {
			bail!("request audit ancestor is not searchable");
		}
		let access = if index + 1 == components.len() {
			libc::O_RDONLY
		} else {
			ancestor_access
		};
		base = open_at(&base, component, access | libc::O_DIRECTORY, 0)?;
	}
	private_directory(&base)?;
	Ok(base)
}


fn validate_file(file: &File) -> Result<()> {
	use std::os::unix::fs::MetadataExt;
	let metadata = file.metadata()?;
	if !metadata.is_file()
		|| metadata.uid() != unsafe { libc::geteuid() }
		|| metadata.mode() & 0o7777 != 0o600
		|| metadata.nlink() != 1
		|| metadata.len() > MAX_RECORD_BYTES as u64
	{
		bail!("private request audit inode refused");
	}
	Ok(())
}


fn read_record(directory: &File, filename: &str) -> Result<Record> {
	let id = filename
		.strip_suffix(".json")
		.filter(|id| valid_id(id))
		.ok_or_else(|| anyhow!("invalid request metadata filename"))?;
	let staging = format!(".{id}-{id}.tmp");
	match open_at(directory, &staging, libc::O_RDONLY | libc::O_NONBLOCK, 0) {
		Ok(_) => cleanup_staging(directory, &staging)?,
		Err(error)
			if error
				.downcast_ref::<std::io::Error>()
				.is_some_and(|e| e.kind() == std::io::ErrorKind::NotFound) => {}
		Err(error) => return Err(error),
	}
	let mut file = open_at(directory, filename, libc::O_RDONLY | libc::O_NONBLOCK, 0)?;
	{
		use std::os::unix::fs::MetadataExt;
		if file.metadata()?.nlink() == 2 {
			// Old versions used random staging names. Only this exceptional
			// interrupted-publication case scans names, never record history.
			let prefix = format!(".{id}-");
			walk_directory(directory, |entry| {
				if entry.starts_with(&prefix) && entry.ends_with(".tmp") {
					cleanup_staging(directory, entry)?;
				}
				Ok(())
			})?;
		}
	}
	validate_file(&file)?;
	let mut bytes = Vec::new();
	Read::by_ref(&mut file)
		.take((MAX_RECORD_BYTES + 1) as u64)
		.read_to_end(&mut bytes)?;
	if bytes.len() > MAX_RECORD_BYTES {
		bail!("request audit metadata size refused");
	}
	let record: Record = serde_json::from_slice(&bytes)?;
	if !valid_id(&record.request_id)
		|| !valid_id(&record.owner)
		|| !valid_tool(&record.tool_name)
		|| filename != format!("{}.json", record.request_id)
	{
		bail!("request audit metadata identity refused");
	}
	Ok(record)
}


fn directory_scan_result(has_entry: bool, error: i32) -> Result<bool> {
	if has_entry {
		return Ok(true);
	}
	if error != 0 {
		return Err(std::io::Error::from_raw_os_error(error).into());
	}
	Ok(false)
}


fn scan_errno(reset: bool) -> Result<i32> {
	#[cfg(target_os = "linux")]
	{
		let pointer = unsafe { libc::__errno_location() };
		if reset {
			unsafe { *pointer = 0 };
		}
		Ok(unsafe { *pointer })
	}
	#[cfg(target_os = "macos")]
	{
		let pointer = unsafe { libc::__error() };
		if reset {
			unsafe { *pointer = 0 };
		}
		Ok(unsafe { *pointer })
	}
	#[cfg(not(any(target_os = "linux", target_os = "macos")))]
	{
		let _ = reset;
		bail!("private audit directory scan is unavailable on this platform")
	}
}


fn entries(directory: &File) -> Result<Vec<Record>> {
	entries_bounded(directory, MAX_GLOBAL)
}


fn walk_directory(directory: &File, mut visit: impl FnMut(&str) -> Result<()>) -> Result<()> {
	walk_directory_with_inode(directory, |filename, _| visit(filename))
}


fn walk_directory_with_inode(
	directory: &File,
	mut visit: impl FnMut(&str, u64) -> Result<()>,
) -> Result<()> {
	use std::os::fd::AsRawFd;
	// A fresh directory file description avoids a shared seek cursor between snapshots.
	let scan = open_at(directory, ".", libc::O_RDONLY | libc::O_DIRECTORY, 0)?;
	let duplicate = unsafe { libc::fcntl(scan.as_raw_fd(), libc::F_DUPFD_CLOEXEC, 0) };
	if duplicate < 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	let pointer = unsafe { libc::fdopendir(duplicate) };
	if pointer.is_null() {
		unsafe { libc::close(duplicate) };
		return Err(std::io::Error::last_os_error().into());
	}
	struct DirectoryStream(*mut libc::DIR);
	impl Drop for DirectoryStream {
		fn drop(&mut self) {
			unsafe { libc::closedir(self.0) };
		}
	}
	let stream = DirectoryStream(pointer);
	loop {
		scan_errno(true)?;
		let item = unsafe { libc::readdir(stream.0) };
		if !directory_scan_result(!item.is_null(), scan_errno(false)?)? {
			break;
		}
		let filename = unsafe { std::ffi::CStr::from_ptr((*item).d_name.as_ptr()) }.to_str()?;
		if filename == "." || filename == ".." {
			continue;
		}
		// This inode is only a scheduling hint. Callers needing metadata still
		// verify the complete named member through the pinned descriptor.
		visit(filename, unsafe { (*item).d_ino } as u64)?;
	}
	Ok(())
}


fn directory_members(directory: &File, maximum: usize) -> Result<Vec<String>> {
	let mut names = Vec::new();
	walk_directory(directory, |filename| {
		if names.len() >= maximum + 32 {
			bail!("request audit retention invariant exceeded");
		}
		names.push(filename.to_owned());
		Ok(())
	})?;
	Ok(names)
}


fn entries_bounded(directory: &File, maximum: usize) -> Result<Vec<Record>> {
	let names = directory_members(directory, maximum)?;
	// Remove only verified private staging inodes after an interrupted publication.
	// This cannot remove an active writer because all mutations use STORE_LOCK.
	for filename in names.iter().filter(|value| value.starts_with('.')) {
		cleanup_staging(directory, filename)?;
	}
	let mut result = Vec::new();
	for filename in names.iter().filter(|value| !value.starts_with('.')) {
		if result.len() >= maximum || !filename.ends_with(".json") {
			bail!("unexpected private request audit entry");
		}
		result.push(read_record(directory, filename)?);
	}
	result.sort_by(|left, right| {
		(left.accepted_unix_ms, &left.request_id).cmp(&(right.accepted_unix_ms, &right.request_id))
	});
	Ok(result)
}


fn cleanup_staging(directory: &File, filename: &str) -> Result<()> {
	use std::os::fd::AsRawFd;
	use std::os::unix::fs::MetadataExt;
	let value = filename
		.strip_prefix('.')
		.and_then(|value| value.strip_suffix(".tmp"))
		.ok_or_else(|| anyhow!("unexpected private audit staging entry"))?;
	let (id, nonce) = value
		.split_once('-')
		.ok_or_else(|| anyhow!("unexpected private audit staging identity"))?;
	if !valid_id(id) || !valid_id(nonce) {
		bail!("unexpected private audit staging identity");
	}
	let file = open_at(directory, filename, libc::O_RDONLY | libc::O_NONBLOCK, 0)?;
	let metadata = file.metadata()?;
	if !metadata.is_file()
		|| metadata.uid() != unsafe { libc::geteuid() }
		|| metadata.mode() & 0o7777 != 0o600
		|| !(1..=2).contains(&metadata.nlink())
		|| metadata.len() > MAX_RECORD_BYTES as u64
	{
		bail!("audit staging inode refused");
	}
	if metadata.nlink() == 2 {
		let published = open_at(
			directory,
			&format!("{id}.json"),
			libc::O_RDONLY | libc::O_NONBLOCK,
			0,
		)?;
		let target = published.metadata()?;
		if target.dev() != metadata.dev() || target.ino() != metadata.ino() {
			bail!("audit staging hard-link binding refused");
		}
	}
	let component = name(filename)?;
	if unsafe { libc::unlinkat(directory.as_raw_fd(), component.as_ptr(), 0) } < 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	directory.sync_all()?;
	Ok(())
}


fn wire_size(value: &Value) -> Result<usize> {
	let text = serde_json::to_string(value)?;
	let result = rmcp::model::CallToolResult::success(vec![rmcp::model::ContentBlock::text(text)]);
	Ok(serde_json::to_vec(&result)?.len())
}


fn history_at(root: &Path, owner: &str, params: RequestHistoryParams) -> Result<String> {
	if !valid_id(owner) {
		bail!("request history unavailable to this session");
	}
	let limit = params.limit.unwrap_or(32) as usize;
	if !(1..=32).contains(&limit) || params.after_id.as_deref().is_some_and(|id| !valid_id(id)) {
		bail!("invalid request history page");
	}
	let _guard = store_lock()?;
	let directory = open_store(root)?;
	let retained = entries(&directory)?;
	let records: Vec<_> = retained
		.iter()
		.filter(|record| record.owner == owner)
		.collect();
	let start = match params.after_id {
		Some(id) => {
			records
				.iter()
				.position(|record| record.request_id == id)
				.ok_or_else(|| {
					anyhow!("request history cursor expired or unavailable to this session")
				})? + 1
		}
		None => 0,
	};
	let mut page = Vec::new();
	for record in records.iter().skip(start).take(limit) {
		let state =
			if record.state == DurableState::Unknown && is_dispatch_active(&record.request_id)? {
				"accepted"
			} else {
				match record.state {
					DurableState::Unknown => "unknown",
					DurableState::Completed => "completed",
					DurableState::Failed => "failed",
				}
			};
		page.push(json!({"request_id":record.request_id,"tool_name":record.tool_name,"state":state,"accepted_unix_ms":record.accepted_unix_ms,"elapsed_ms":record.elapsed_ms}));
	}
	let next = if start + page.len() < records.len() {
		page.last().map(|row| row["request_id"].clone())
	} else {
		None
	};
	let output = json!({"requests":page,"next_after_id":next,"retention":{"global":MAX_GLOBAL,"per_session":MAX_OWNER},
		"status_semantics":"native_request_dispatch_observation_not_side_effect_delivery_or_business_success",
		"session_scope":"native_mcp_session_only","cross_session_resume":false,"history_is_live":true,
		"automatic_operation_retry":false});
	if wire_size(&output)? > MAX_PAGE_BYTES {
		bail!("request history wire page limit exceeded");
	}
	Ok(serde_json::to_string(&output)?)
}

fn open_at_component(
	directory: &File,
	component: &std::ffi::CStr,
	flags: i32,
	mode: u32,
) -> Result<File> {
	use std::os::fd::{AsRawFd, FromRawFd};
	let descriptor = unsafe {
		libc::openat(
			directory.as_raw_fd(),
			component.as_ptr(),
			flags | libc::O_NOFOLLOW | libc::O_CLOEXEC,
			mode,
		)
	};
	if descriptor < 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	Ok(unsafe { File::from_raw_fd(descriptor) })
}

pub fn observe() -> Result<()> {
    use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
    use std::io::{BufRead, Write};
    let root = std::path::PathBuf::from(std::env::args().nth(1).expect("fresh fixture root"));
    std::fs::create_dir(&root)?;
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700))?;
    let schema = schemars::schema_for!(RequestHistoryParams);
    std::fs::write(root.join("params-schema.json"), serde_json::to_vec_pretty(&schema)?)?;
    for (index, line) in std::io::stdin().lock().lines().enumerate() {
        let row: Value = serde_json::from_str(&line?)?;
        let case_root = root.join(format!("{index:04}"));
        std::fs::create_dir(&case_root)?;
        std::fs::set_permissions(&case_root, std::fs::Permissions::from_mode(0o700))?;
        let hot = case_root.join(STORE_NAME);
        std::fs::create_dir(&hot)?;
        std::fs::set_permissions(&hot, std::fs::Permissions::from_mode(0o700))?;
        for member in row["records"].as_array().unwrap() {
            let filename = member["name"].as_str().unwrap();
            assert!(filename.ends_with(".json") && valid_id(filename.strip_suffix(".json").unwrap()));
            let mut file = std::fs::OpenOptions::new().write(true).create_new(true).mode(0o600).open(hot.join(filename))?;
            file.write_all(member["raw"].as_str().unwrap().as_bytes())?;
        }
        let mut markers = Vec::new();
        {
            let mut registry = active_registry()?;
            registry.clear();
            for id in row["active"].as_array().unwrap() {
                let marker = Arc::new(AtomicBool::new(true));
                registry.insert(id.as_str().unwrap().to_owned(), Arc::downgrade(&marker));
                markers.push(marker);
            }
        }
        let typed = serde_json::from_str::<Value>(row["params_json"].as_str().unwrap())
            .and_then(serde_json::from_value::<RequestHistoryParams>);
        let answer = match typed {
            Err(error) => json!({"id":row["id"],"outcome":"params_error","error":error.to_string()}),
            Ok(params) => {
                let owner = row["owner"].as_str().unwrap();
                match std::panic::catch_unwind(|| history_at(&case_root, owner, params)) {
                    Ok(Ok(text)) => {
                        let result = rmcp::model::CallToolResult::success(vec![rmcp::model::ContentBlock::text(text.clone())]);
                        json!({"id":row["id"],"outcome":"ok","text":text,"call_tool_result":serde_json::to_value(result)?})
                    },
                    Ok(Err(error)) => {
                        let raw = error.to_string();
                        let public = if raw == "request history cursor expired or unavailable to this session" {
                            raw.clone()
                        } else {
                            "request history unavailable to this session or private metadata refused".to_owned()
                        };
                        json!({"id":row["id"],"outcome":"tool_error","error":raw,"public_error":public})
                    },
                    Err(_) => json!({"id":row["id"],"outcome":"join_error","public_error":"request history unavailable to this session"}),
                }
            }
        };
        println!("{}", serde_json::to_string(&answer)?);
        drop(markers);
    }
    Ok(())
}
