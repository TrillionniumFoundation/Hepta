mod mcp { pub mod runtime { pub mod request_audit; } }
fn main() -> anyhow::Result<()> { mcp::runtime::request_audit::observe() }
