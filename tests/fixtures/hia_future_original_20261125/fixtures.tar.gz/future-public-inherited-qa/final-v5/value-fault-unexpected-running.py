from pathlib import Path
import ctypes as C,struct,json,importlib.util,resource,os,signal,errno,traceback
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');D=T/'future-public-inherited-qa/final-v5/value-fault-unexpected-running';D.mkdir(exist_ok=False)
sp=importlib.util.spec_from_file_location('publicclient',T/'future-public-inherited-qa/final-v5/regression-client-v1.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
image=(T/'future-public-inherited-qa/public-native-v5/future-public.flat').read_bytes();offset=279+struct.unpack_from('<i',image,275)[0];assert image[offset:offset+577]==(T/'result-value-native-v4/result-value.flat').read_bytes()[:577];code=C.cast(h.entry,C.c_void_p).value+offset
nativebase=C.cast(h.entry,C.c_void_p).value;alloclo=nativebase+2283;allochi=nativebase+2458
lib=C.CDLL(None,use_errno=True);lib.ptrace.argtypes=[C.c_uint,C.c_uint,C.c_void_p,C.c_void_p];lib.ptrace.restype=C.c_long
class Reg(C.Structure):
 _fields_=[(n,C.c_ulonglong)for n in['r15','r14','r13','r12','rbp','rbx','r11','r10','r9','r8','rax','rcx','rdx','rsi','rdi','orig_rax','rip','cs','eflags','rsp','ss','fs_base','gs_base','ds','es','fs','gs']]
def ptrace(req,pid,a=0,b=0):
 C.set_errno(0);r=lib.ptrace(req,pid,C.c_void_p(a),C.cast(b,C.c_void_p)if not isinstance(b,int)else C.c_void_p(b));assert r!=-1 or C.get_errno()==0,(req,pid,C.get_errno());return r
def caps(v):return C.c_uint64.from_address(h.u(v.ctx.raw,16)+88).value
def free_bytes(v):
 p=h.u(v.ctx.raw,16);n=0
 for k in range(6,64):
  at=C.c_uint64.from_address(p+512+k*8).value
  while at:n+=1<<k;at=C.c_uint64.from_address(p+at+16).value
 return n
CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
@CB
def callback(s,sn,o,on,w,wn):
 out=bytearray(128);out[:8]=b'HIAFCBR1';C.memmove(o,bytes(out),128);return 0
rows=[];signal.alarm(160)
for case in('complete',):
 rfd,wfd=os.pipe();pid=os.fork()
 if pid==0:
  try:
   os.close(rfd);v=h.m.Values(entry=h.ve)
   if case=='global':
    p=h.Public.__new__(h.Public);p.v=v;p.ctx=C.create_string_buffer(256);p.fs=[];p.leases=[]
   else:p=h.Public(v)
   fac=None;f=None
   if case not in('global','factory'):fac=p.factory()
   if case in('complete','callback','result'):f=p.make(fac)
   env=v.scalar('env');payload=v.scalar('value')
   if case=='result':p.complete(f,payload)
   p.call(24,*f)
   tokens=[]
   while free_bytes(v)>128:
    r=v.call(21);tokens.append(struct.unpack_from('<3Q',r,24));assert len(tokens)<100000
   before=caps(v);oldmap=(h.u(v.ctx.raw,16),h.u(v.ctx.raw,40))
   op={'global':0,'factory':1,'future':4,'complete':24,'callback':13,'result':10}[case]
   args=((C.addressof(v.ctx),256,0),)if case=='global'else()if case=='factory'else fac if case=='future'else f
   kw={'value':payload,'kind':1}if 24 in(22,23)else{}
   limits=resource.getrlimit(resource.RLIMIT_AS);virtual=int(Path('/proc/self/statm').read_text().split()[0])*os.sysconf('SC_PAGE_SIZE');resource.setrlimit(resource.RLIMIT_AS,(virtual+(64<<20),limits[1]))
   ptrace(0,0);os.kill(os.getpid(),signal.SIGSTOP)
   r=p.call(op,*args,**kw,status=1);assert h.u(r,16)==103,(case,r[:128].hex())
   assert caps(v)==before and(h.u(v.ctx.raw,16),h.u(v.ctx.raw,40))==oldmap,(case,before,caps(v),oldmap)
   os.kill(os.getpid(),signal.SIGSTOP);resource.setrlimit(resource.RLIMIT_AS,limits)
   for cap in tokens:v.call(22,cap)
   r=p.call(op,*args,**kw,status=1);assert h.u(r,16)==200
   if op==1:p.leases.append((struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48)))
   if op==4:p.fs.append((struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48)))
   v.held.append(struct.unpack_from('<3Q',r,72))
   p.finish();v.finish();assert h.u(v.ctx.raw,16)==0
   os.write(wfd,b'OK');os.close(wfd);os._exit(0)
  except BaseException:
   try:os.write(wfd,traceback.format_exc().encode())
   except BaseException:pass
   os._exit(71)
 os.close(wfd);_,st=os.waitpid(pid,0);assert os.WIFSTOPPED(st);ptrace(0x4200,pid,0,0x100001)
 entering=True;armed=True;forced=[];current=False;syscalls=0;owned={};mem_current=None
 while True:
  ptrace(24,pid);_,st=os.waitpid(pid,0)
  if os.WIFEXITED(st)or os.WIFSIGNALED(st):break
  sig=os.WSTOPSIG(st)
  if sig==signal.SIGTRAP|128:
   reg=Reg();ptrace(12,pid,0,C.byref(reg))
   if entering:
    mem_current=(reg.orig_rax,reg.rdi,reg.rsi)if alloclo<=reg.rip<allochi and reg.orig_rax in(9,11)else None
    current=False
    if 0<=reg.rip-code<577 and reg.orig_rax==25:
     syscalls+=1
     if armed:reg.rdx=1<<40;ptrace(13,pid,0,C.byref(reg));current=True
   elif current:
    forced.append(reg.rax-(1<<64));assert forced[-1]==-errno.ENOMEM,(case,forced);current=False
   if not entering and mem_current:
    num,address,size=mem_current
    if num==9 and reg.rax<2**63:owned[reg.rax]=size
    elif num==11 and address in owned:assert reg.rax==0 and owned.pop(address)==size
    mem_current=None
   entering=not entering
  elif sig==signal.SIGSTOP:
   assert armed;armed=False
  else:raise AssertionError((case,'signal',sig))
 out=b''
 while True:
  z=os.read(rfd,65536)
  if not z:break
  out+=z
 assert not owned,('actual native allocator leak',owned)
 os.close(rfd);assert os.WIFEXITED(st)and os.WEXITSTATUS(st)==0 and out==b'OK',(case,st,out.decode(errors='replace'),forced)
 assert forced==[-errno.ENOMEM,-errno.ENOMEM]and not armed,(case,forced,armed)
 row={'case':case,'passed':True,'actual_kernel_enomem':len(forced),'owned_caps_and_arena_unchanged_after_failure':True,'retry_succeeded':True,'final_owned_arena':0};rows.append(row);print('PUBLIC_VALUE_KERNEL',row,flush=True)
signal.alarm(0)
report={'passed':True,'whole_public_future_closed':False,'count':len(rows),'cases':rows,'image_sha256':h.pin,'instrumentation':'Fill actual value arena with real independent context tokens, then alter only fixed embedded value mremap requested size under RLIMIT_AS; real kernel ENOMEM twice per failed growth. No product state/code/return patched.'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PUBLIC_VALUE_KERNEL_PASS',len(rows),flush=True)
