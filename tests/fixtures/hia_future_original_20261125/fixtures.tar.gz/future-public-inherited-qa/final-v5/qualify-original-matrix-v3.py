from pathlib import Path
import importlib.util,json,sys,re,math,ctypes as C,struct,logging
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=Q/'original-matrix-v3';D.mkdir()
sp=importlib.util.spec_from_file_location('h',Q/'client-v3.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sys.path.insert(0,str(T/'future-public-inherited-source'))
from hepta.hia_background_optimizer import _OptimizationFuture,PublicationCancellation
rows=[];total_calls=0
logger=logging.getLogger('concurrent.futures');logger.disabled=True
def value(v,obj):
 if isinstance(obj,BaseException):return h.record(v,type(obj).__name__,str(obj)),2 if isinstance(obj,Exception)else 3
 if type(obj)is list:
  a=v.empty(list)
  for x in obj:v.call(16,a,value(v,x)[0])
  return a,1
 if type(obj)is dict:
  a=v.empty(dict)
  for k,x in obj.items():v.call(10,a,value(v,k)[0],value(v,x)[0])
  return a,1
 return v.scalar(obj),1
def invoke(f,method,arg=None):
 try:return 0,getattr(f,method)()if method in('set_running_or_notify_cancel','cancel')else getattr(f,method)(arg)
 except BaseException as exc:return 2 if not isinstance(exc,Exception)else 1,(type(exc).__name__,str(exc),exc)
def err(v,out,expected,oldid,newid):
 assert h.u(out,16)==200,out[:128].hex()
 got=h.take_error(v,out)
 assert got=={'class':expected[0],'message':expected[1].replace(hex(oldid),hex(newid))},(got,expected[:2])
def state(v,p,n,f,t):
 assert h.u(p.call(14,*n),96)==f.done()
 assert h.u(p.call(15,*n),96)==f.cancelled()
 assert h.u(p.call(25,*n),96)==h.u(p.call(16,*n),96)==f.running()
 assert h.u(p.call(9,*n),120)==(1 if t.cancelled()else 0)
def observe(v,p,n,f,resultcap,exceptioncap,exceptionkind):
 if not f.done():return
 if f.cancelled():
  for mode in(False,True):
   _,out=p.result(n,status=1,exception=mode);assert h.u(out,16)==100
  return
 exc=f.exception()
 ec,out=p.result(n,exception=True)
 if exceptioncap:
  assert ec[0]and v.type(ec)[3:]==v.type(exceptioncap)[3:]
 else:assert ec==(0,0,0)
 try:expected=f.result()
 except BaseException as e:
  cap,out=p.result(n,status=2 if not isinstance(e,Exception)else 1)
  if isinstance(e,TypeError)and str(e)=='exceptions must derive from BaseException':err(v,out,(type(e).__name__,str(e)),id(f),h.u(p.call(21,*n),96))
  else:assert exceptioncap and v.type(cap)[3:]==v.type(exceptioncap)[3:]
 else:
  cap,out=p.result(n)
  if resultcap:assert cap[0]and v.type(cap)[3:]==v.type(resultcap)[3:]
  else:assert expected is None and cap==(0,0,0)

values=[None,False,True,0,1,-1,-0.0,0.5,float('nan'),float('inf'),'','x',b'',b'x',[],[0],{}, {'class':'ValueError','message':'ordinary dict'},ValueError('actual exception'),KeyboardInterrupt('actual base')]
states=['pending','running','cancel-running','cancelled','result','exception']
actions=['set_result','set_exception','set_running_or_notify_cancel','cancel','_complete']
cases=0
for st in states:
 for action in actions:
  # Running/cancel carry no arbitrary value; setters use every original type.
  for x in values if action in('set_result','set_exception','_complete')else [None]:
   v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();n=p.make(fac);t=PublicationCancellation();f=_OptimizationFuture(t);oldid=id(f);newid=h.u(p.call(21,*n),96);rcap=None;ecap=None;ek=0
   if st in('running','cancel-running'):
    assert f.set_running_or_notify_cancel();assert h.u(p.call(24,*n),96)==1
   if st=='cancel-running':assert not f.cancel()and h.u(p.call(7,*n),96)==0
   if st=='cancelled':assert f.cancel()and h.u(p.call(7,*n),96)==1
   if st in('result','exception'):
    z=0 if st=='result'else False;zc,zk=value(v,z)
    getattr(f,'set_'+st)(z);p.call(22 if st=='result'else 23,*n,value=zc,kind=zk)
    if st=='result':rcap=zc
    else:ecap=zc;ek=zk
   ac,ak=value(v,x)
   wasdone=f.done();expected_status,expected=invoke(f,action,x)
   op={'set_result':22,'set_exception':23,'set_running_or_notify_cancel':24,'cancel':7,'_complete':12}[action]
   kw={'value':ac,'kind':ak}if op in(22,23,12)else{}
   # _complete is always a result, even if its supplied value is an Exception.
   if op==12:kw['kind']=1
   out=p.call(op,*n,**kw,status=expected_status)
   if expected_status:err(v,out,expected,oldid,newid)
   elif op in(24,7):assert h.u(out,96)==expected,(st,action,expected,out[:128].hex())
   if not expected_status and op in(22,23,12)and not wasdone:
    if op in(22,12):rcap=ac;ecap=None
    else:ecap=ac;rcap=None;ek=ak
   state(v,p,n,f,t);observe(v,p,n,f,rcap,ecap,ek)
   p.finish();v.finish();total_calls+=v.calls;cases+=1
 rows.append({'case':'state-'+st,'passed':True,'cumulative_pairs':cases})
 (D/'report.json').write_text(json.dumps({'passed':False,'rows':rows,'pairs':cases},indent=2)+'\n')
 print('STATE_MATRIX',st,cases,flush=True)

# Repr re-reads mutable exception truthiness; result keeps is-not-None semantics.
for py in([],{}):
 v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();n=p.make(fac);t=PublicationCancellation();f=_OptimizationFuture(t);a,k=value(v,py);f.set_exception(py);p.call(23,*n,value=a,kind=k)
 for mutate in(False,True,False):
  if type(py)is list:
   if mutate:py.append(1);v.call(16,a,v.scalar(1))
   elif py:py.clear();v.call(15,a,v.scalar(0))
  else:
   if mutate:py['x']=1;v.call(10,a,v.scalar('x'),v.scalar(1))
   elif py:py.clear();v.call(11,a,v.scalar('x'))
  st,e=invoke(f,'set_result',None);out=p.call(22,*n,value=v.scalar(None),kind=1,status=1);err(v,out,e,id(f),h.u(p.call(21,*n),96))
  _,out=p.result(n,status=1);assert h.take_error(v,out)=={'class':'TypeError','message':'exceptions must derive from BaseException'}
 p.finish();v.finish();total_calls+=v.calls
rows.append({'case':'fresh-mutable-list-and-dict-repr-truthiness','passed':True})

# Actual typed exception classes preserve arbitrarily long Unicode names.
for clsname in('Odd\u00e9\U0001f642','Long'+('X'*70000)):
 cls=type(clsname,(ValueError,),{});e=cls('payload');v=h.m.Values(h.ve);p=h.Public(v);fac=p.factory();n=p.make(fac);t=PublicationCancellation();f=_OptimizationFuture(t);a,k=value(v,e)
 f.set_exception(e);p.call(23,*n,value=a,kind=k);st,expected=invoke(f,'set_result',0);out=p.call(22,*n,value=v.scalar(0),kind=1,status=1);err(v,out,expected,id(f),h.u(p.call(21,*n),96))
 got,out=p.result(n,status=1);assert v.type(got)[3:]==v.type(a)[3:]
 p.finish();v.finish();total_calls+=v.calls
rows.append({'case':'actual-typed-class-Unicode-and-70004-byte-name','passed':True})
report={'passed':True,'rows':rows,'pairs':cases,'public_calls':h.calls,'value_calls':total_calls,'image_sha256':h.pin,'python_version':sys.version,'whole_public_future_closed':False,'scope':'actual original OptimizationFuture inherited methods and native source-bound product'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('INHERITED_MATRIX_PASS',cases,h.calls,total_calls,flush=True)

