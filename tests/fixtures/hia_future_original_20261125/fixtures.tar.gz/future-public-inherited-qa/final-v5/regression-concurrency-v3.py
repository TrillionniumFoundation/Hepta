from pathlib import Path
import ctypes as C,struct,importlib.util,json,os,threading,time,traceback
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');D=T/'future-public-inherited-qa/final-v5/regression-concurrency-v3';D.mkdir(exist_ok=False)
sp=importlib.util.spec_from_file_location('publicclient',T/'future-public-inherited-qa/final-v5/regression-client-v1.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);h.D=D
u=h.u;CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
def reply(o,kind=0,cap=(0,0,0)):
 out=bytearray(128);out[:8]=b'HIAFCBR1';struct.pack_into('<Q',out,8,kind);struct.pack_into('<3Q',out,24,*cap);C.memmove(o,bytes(out),128);return 0
def actual(s,sn):
 raw=C.string_at(s,sn);assert sn==192 and raw[:8]==b'HIAFCBQ1';return (struct.unpack_from('<3Q',raw,16),struct.unpack_from('<3Q',raw,40)),struct.unpack_from('<3Q',raw,64)
def thread_group(functions,timeout=40):
 errors=[];threads=[]
 def run(fn):
  try:fn()
  except BaseException:errors.append(traceback.format_exc())
 for fn in functions:
  t=threading.Thread(target=run,args=(fn,));threads.append(t);t.start()
 for t in threads:t.join(timeout)
 assert all(not t.is_alive()for t in threads)and not errors,(len(threads),errors)
v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();fs=[p.make(fac)for _ in range(8)]
errs=[h.record(v,'KeyboardInterrupt','thread-'+str(i))for i in range(8)];envs=[v.scalar(i)for i in range(8)];values=[v.scalar('result-'+str(i))for i in range(8)]
identities=[u(p.call(21,*f),96)for f in fs];barrier=threading.Barrier(8);failures=[];held=[];returned=[None]*8
@CB
def concurrent(s,sn,o,on,w,wn):
 try:
  f,env=actual(s,sn);i=int(v.raw(env));assert u(p.call(21,*f),96)==identities[i]
  barrier.wait(20);keep=p.retain(f);p.drop(fs[i]);held.append(keep)
  cap,r=p.result(f);assert v.raw(cap)==('result-'+str(i)).encode();owned=v.retain(errs[i]);v.held.remove(owned)
  return reply(o,2,owned)
 except BaseException:failures.append(traceback.format_exc());return 99
for f,env in zip(fs,envs):p.call(13,*f,value=env,fn=C.cast(concurrent,C.c_void_p).value)
p.drop_factory(fac)
def complete(i):
 r=p.complete(fs[i],values[i],status=2);assert u(r,16)==200;cap=struct.unpack_from('<3Q',r,72);v.held.append(cap);assert v.type(cap)[3:]==v.type(errs[i])[3:];returned[i]=cap
thread_group([lambda i=i:complete(i)for i in range(8)])
assert not failures and all(returned)and len(held)==8,failures
p.finish();v.finish();h.done('eight-simultaneous-callback-frames-independent-abrupt-results-and-last-caps',threads=8)

for other_factory in(False,True):
 for caught in(False,True):
  v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();fac2=p.factory()if other_factory else fac;a=p.make(fac);b=p.make(fac2);env=v.scalar(None);err=h.record(v,'SystemExit','nested original');events=[];failures=[]
  @CB
  def inner(s,sn,o,on,w,wn):
   try:
    f,e=actual(s,sn);assert u(p.call(14,*f),96)==1;events.append('inner');owned=v.retain(err);v.held.remove(owned);return reply(o,2,owned)
   except BaseException:failures.append(traceback.format_exc());return 99
  @CB
  def outer(s,sn,o,on,w,wn):
   try:
    events.append('outer');r=p.complete(b,env,status=2);assert u(r,16)==200;cap=struct.unpack_from('<3Q',r,72);assert v.type(cap)[3:]==v.type(err)[3:]
    if caught:
     v.held.append(cap);v.drop(cap);return reply(o)
    return reply(o,2,cap)
   except BaseException:failures.append(traceback.format_exc());return 99
  @CB
  def after(s,sn,o,on,w,wn):events.append('after');return reply(o)
  p.call(13,*b,value=env,fn=C.cast(inner,C.c_void_p).value);p.call(13,*a,value=env,fn=C.cast(outer,C.c_void_p).value);p.call(13,*a,value=env,fn=C.cast(after,C.c_void_p).value)
  r=p.complete(a,env,status=0 if caught else 2)
  if not caught:
   cap=struct.unpack_from('<3Q',r,72);v.held.append(cap);assert v.type(cap)[3:]==v.type(err)[3:]
  assert events==(['outer','inner','after']if caught else['outer','inner'])and not failures,(events,failures)
  p.finish();v.finish()
h.done('nested-same-thread-frames-same-and-different-factories-caught-and-rethrown',combinations=4)

for cancel in(False,True):
 v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);g=p.retain(f);kp=u(p.call(21,*f),96);timeout=v.scalar(10.0);payload=v.scalar('wait result');result=[];failures=[]
 def waiter():
  try:result.append(p.result(f,status=1 if cancel else 0,timeout=timeout))
  except BaseException:failures.append(traceback.format_exc())
 t=threading.Thread(target=waiter);t.start();deadline=time.monotonic()+5
 while C.c_uint64.from_address(kp+72).value==0:
  assert time.monotonic()<deadline and t.is_alive();time.sleep(.001)
 p.drop(f);p.drop_factory(fac)
 if cancel:p.call(7,*g)
 else:p.complete(g,payload)
 p.drop(g);t.join(10);assert not t.is_alive()and not failures and len(result)==1,failures
 if cancel:assert u(result[0][1],16)==100
 else:assert v.raw(result[0][0])==b'wait result'
 p.call(18);v.finish()
h.done('blocking-result-owned-pin-survives-external-caps-and-factory-release',variants=2)

for kind in(0,1,2):
 v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);env=v.scalar('closure');err=h.record(v,'ValueError'if kind==1 else'KeyboardInterrupt','immediate detail');p.complete(f,env);saved=[];failures=[];events=[]
 @CB
 def immediate(s,sn,o,on,w,wn):
  try:
   actualf,e=actual(s,sn);saved.append(p.retain(actualf));p.drop(f);p.drop_factory(fac);events.append('immediate');cap,r=p.result(actualf);assert v.raw(cap)==b'closure'
   if kind:
    owned=v.retain(err);v.held.remove(owned);return reply(o,kind,owned)
   return reply(o)
  except BaseException:failures.append(traceback.format_exc());return 99
 fd=os.open(D/('immediate-'+str(kind)+'.stderr'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);old=os.dup(2);os.dup2(fd,2);os.close(fd)
 try:r=p.call(13,*f,value=env,fn=C.cast(immediate,C.c_void_p).value,status=2 if kind==2 else 0)
 finally:os.dup2(old,2);os.close(old)
 assert events==['immediate']and not failures,failures
 if kind==2:
  cap=struct.unpack_from('<3Q',r,72);v.held.append(cap);assert v.type(cap)[3:]==v.type(err)[3:]
 p.finish();v.finish()
h.done('immediate-callback-terminal-observation-reentry-and-owned-errors',variants=3)

v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();fs=[p.make(fac)for _ in range(8)];envs=[v.scalar(i)for i in range(8)]
messages=['A'*510+'\ud800'+str(i)+'\U0001f642'+'\udfff'+'中'*1024+'\x00end\n'+('z'*65536 if i==7 else'') for i in range(8)]
classes=['TypeError'+str(i) for i in range(8)];errs=[h.record(v,c,m)for c,m in zip(classes,messages)];barrier=threading.Barrier(8);failures=[]
@CB
def unicode_error(s,sn,o,on,w,wn):
 try:
  f,e=actual(s,sn);i=int(v.raw(e));barrier.wait(20);owned=v.retain(errs[i]);v.held.remove(owned);return reply(o,1,owned)
 except BaseException:failures.append(traceback.format_exc());return 99
for f,env in zip(fs,envs):p.call(13,*f,value=env,fn=C.cast(unicode_error,C.c_void_p).value)
fd=os.open(D/'unicode-concurrent.stderr',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);old=os.dup(2);os.dup2(fd,2);os.close(fd)
try:thread_group([lambda i=i:p.complete(fs[i],envs[i])for i in range(8)])
finally:os.dup2(old,2);os.close(old)
assert not failures,failures
raw=(D/'unicode-concurrent.stderr').read_bytes();parts=raw.split(b'exception calling callback\n');assert parts[0]==b''
expected=[(c+': '+m+'\n').encode('utf8','backslashreplace')for c,m in zip(classes,messages)];assert sorted(parts[1:])==sorted(expected),(len(raw),[len(x)for x in parts])
p.finish();v.finish();h.done('concurrent-logger-exact-Unicode-surrogates-boundaries-and-long-message',threads=8,bytes=len(raw))
report={'passed':True,'whole_public_future_closed':False,'count':len(h.rows),'calls':h.calls,'image_sha256':h.pin,'cases':h.rows}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PUBLIC_CONCURRENCY_PASS',report,flush=True)
