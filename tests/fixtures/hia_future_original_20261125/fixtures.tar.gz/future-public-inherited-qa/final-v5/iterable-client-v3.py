from pathlib import Path
import ctypes as C,struct,json,hashlib,importlib.util,time,threading
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5'
sp=importlib.util.spec_from_file_location('arrayobserver',Q/'observer-client-v4.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
meta=json.loads((T/'future-public-inherited-qa/iterable-native-v1/build.json').read_text())
entry=m.m.m.load(T/'future-public-inherited-qa/iterable-native-v1/iterable.flat',meta['flat_sha256'])
u=m.u;calls=0
class Iterable:
 def __init__(self,p,arrays):self.p=p;self.arrays=arrays;self.handles=[]
 def call(self,op,fs=(),fn=0,env=(0,0,0),timeout=(0,0,0),when=2,handle=(0,0,0),status=0):
  global calls
  wire=bytearray(192);wire[:8]=b'HIABFA01';struct.pack_into('<Q',wire,8,op)
  if op in(2,3):struct.pack_into('<3Q',wire,16,*handle)
  else:
   struct.pack_into('<Q',wire,16,fn);struct.pack_into('<3Q',wire,24,*env);struct.pack_into('<3Q',wire,48,*timeout)
   struct.pack_into('<2Q',wire,72,when if op in(0,4)else 0,len(fs))
   if op in(4,5):wire+=b''.join(struct.pack('<6Q',*(f[0]+f[1]))for f in fs)
  s=C.create_string_buffer(bytes(wire));o=C.create_string_buffer(b'\xa7'*262144,262144)
  started=time.monotonic();rc=entry(s,len(wire),o,len(o),self.p.ctx,256);elapsed=time.monotonic()-started;calls+=1
  assert rc==0 and o.raw[:8]==b'HIABFAR1',(op,rc,o.raw[:128].hex())
  assert u(o.raw,8)==status,(op,status,o.raw[:128].hex())
  return o.raw,elapsed
 def start(self,fs=(),fn=0,env=(0,0,0),timeout=(0,0,0)):
  r,_=self.call(1 if fn else 5,fs,fn,env,timeout);assert u(r,16)==2
  h=struct.unpack_from('<3Q',r,24);self.handles.append(h);return h
 def wait(self,fs=(),fn=0,env=(0,0,0),timeout=(0,0,0),when=2,status=0):
  r,e=self.call(0 if fn else 4,fs,fn,env,timeout,when,status=status)
  if status:return None,r,e
  assert u(r,16)==1;h=struct.unpack_from('<3Q',r,24);self.arrays.handles.append(h);return h,r,e
 def next(self,h,status=0):
  r,e=self.call(2,handle=h,status=status)
  if status or u(r,16)==4:
   self.handles.remove(h);return None,r,e
  assert u(r,16)==3;f=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));self.p.fs.append(f);return f,r,e
 def close(self,h):
  r,_=self.call(3,handle=h);assert u(r,16)==0;self.handles.remove(h)
 def finish(self):
  for h in self.handles[:]:self.close(h)
def env():
 v,p,a=m.env();return v,p,a,Iterable(p,a)
def finish(v,p,a,i):i.finish();a.finish();p.finish();v.finish()

