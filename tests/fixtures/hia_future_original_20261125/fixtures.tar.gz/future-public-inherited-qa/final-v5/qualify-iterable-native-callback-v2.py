from pathlib import Path
import ctypes as C,struct,json,importlib.util,time,threading,concurrent.futures as cf
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=Q/'iterable-native-callback-v2';D.mkdir()
sp=importlib.util.spec_from_file_location('it',Q/'iterable-client-v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
pm=json.loads((T/'future-public-observers-qa/iterator-producer-native-v2/build.json').read_text())
producer=m.m.m.m.load(T/'future-public-observers-qa/iterator-producer-native-v2/producer.flat',pm['flat_sha256']);fn=C.cast(producer,C.c_void_p).value
u=m.u;rows=[];total_value_calls=0
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});print('ACTUAL_NATIVE_ITERATOR',name,flush=True)
def environment(v,fs,fail_stage=0,fail_at=0,status=1,kind=200,iter_ns=0,next_ns=0):
 state=bytearray(192);state[:8]=b'HIABFIF1'
 for at,n in {32:fail_stage,40:fail_at,48:status,56:kind,64:iter_ns,72:next_ns,80:len(fs)}.items():struct.pack_into('<Q',state,at,n)
 error=m.m.m.record(v,'SystemExit'if status==2 else'MemoryError'if kind==103 else'ValueError','actual native iterator error \u0000\ud800')
 env=v.empty(list)
 for value in (v.scalar(bytes(state)),error,v.scalar(b''.join(struct.pack('<6Q',*(f[0]+f[1]))for f in fs))):v.call(16,env,value)
 return env,error
def state(v,env):
 current=v.take(v.call(12,env,v.scalar(0)));raw=v.raw(current);v.drop(current);assert raw[:8]==b'HIABFIF1';return raw
def finish(v,p,a,i):
 global total_value_calls
 m.finish(v,p,a,i);total_value_calls+=v.calls
def read_values(v,p,refs):
 got=[]
 for f in refs:
  value,_=p.result(f);got.append(int(v.raw(value)))
 return got
class Boom(BaseException):pass
class Original:
 def __init__(self,fs,stage=0,at=0,error=None,delay=0):self.fs=fs;self.stage=stage;self.at=at;self.error=error or ValueError('original');self.delay=delay;self.pos=0;self.iter_calls=0;self.next_calls=0
 def __iter__(self):
  self.iter_calls+=1
  if self.delay:time.sleep(self.delay)
  if self.stage==1:raise self.error
  return self
 def __next__(self):
  self.next_calls+=1
  if self.stage==2 and self.pos==self.at:raise self.error
  if self.pos==len(self.fs):raise StopIteration
  value=self.fs[self.pos];self.pos+=1;return value
def originals(n):
 fs=[cf.Future()for _ in range(n)]
 for j,f in enumerate(fs):f.set_result(j)
 return fs
for mode in('wait','as'):
 for n in(0,1,3,17):
  v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(n)]
  for j,f in enumerate(fs):p.complete(f,v.scalar(j))
  inputs=fs+fs[::-1]+fs[:1];env,error=environment(v,inputs);old=Original(originals(n))
  if mode=='wait':
   old.fs=old.fs+old.fs[::-1]+old.fs[:1];expected=cf.wait(old)
   h,r,_=i.wait(fn=fn,env=env);assert u(r,64)==n and u(r,56)==0
   refs=[a.take(h,j)[0]for j in range(n)];a.close(h)
  else:
   old.fs=old.fs+old.fs[::-1]+old.fs[:1];expected=list(cf.as_completed(old))
   h=i.start(fn=fn,env=env);assert u(state(v,env),16)==0
   refs=[i.next(h)[0]for _ in range(n)];assert i.next(h)[0]is None
  st=state(v,env);assert (u(st,8),u(st,16),u(st,24))==(len(inputs),old.iter_calls,old.next_calls)
  assert sorted(read_values(v,p,refs))==list(range(n))
  finish(v,p,a,i)
 done('actual_iter_next_'+mode+'_duplicates_empty_and_counts')
for mode in('wait','as'):
 for stage in(1,2):
  for status in(1,2):
   v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(5)]
   for j,f in enumerate(fs):p.complete(f,v.scalar(j))
   env,error=environment(v,fs,stage,3,status)
   ex=Boom('base')if status==2 else ValueError('ordinary')
   old=Original(originals(5),stage,3,ex)
   try:
    list(cf.as_completed(old))if mode=='as'else cf.wait(old)
   except BaseException as caught:assert caught is ex
   else:raise AssertionError('missing original exception')
   if mode=='wait':_,r,_=i.wait(fn=fn,env=env,status=status)
   else:h=i.start(fn=fn,env=env);_,r,_=i.next(h,status=status)
   assert u(r,16)==200 and u(r,120)==0 and u(p.ctx.raw,48)==0,r[:128].hex()
   cap=struct.unpack_from('<3Q',r,72);v.held.append(cap);assert v.type(cap)[3:]==v.type(error)[3:]
   st=state(v,env);assert (u(st,16),u(st,24))==(old.iter_calls,old.next_calls)
   finish(v,p,a,i)
 done('owned_'+mode+'_iter_and_next_Exception_BaseException_identity_and_cleanup')
for mode in('wait','as'):
 v,p,a,i=m.env();env,_=environment(v,[],1,0,1,103)
 if mode=='wait':_,r,_=i.wait(fn=fn,env=env,status=1)
 else:h=i.start(fn=fn,env=env);_,r,_=i.next(h,status=1)
 assert u(r,16)==103 and r[72:96]==bytes(24) and u(p.ctx.raw,48)==0
 finish(v,p,a,i)
done('actual_native_callback_builtin_MemoryError_without_error_allocation')
# Generator setup is lazy and timeout arithmetic precedes __iter__ at first next.
for timeout in ('bad',10**310):
 v,p,a,i=m.env();env,_=environment(v,[],1);old=Original([],1)
 it=cf.as_completed(old,timeout=timeout);h=i.start(fn=fn,env=env,timeout=v.scalar(timeout))
 assert old.iter_calls==0 and u(state(v,env),16)==0
 try:next(it)
 except (TypeError,OverflowError)as ex:expected=104 if type(ex)is TypeError else 106
 else:raise AssertionError('missing timeout conversion failure')
 _,r,_=i.next(h,status=1);assert u(r,16)==expected and u(state(v,env),16)==0
 finish(v,p,a,i)
done('first_next_original_timeout_error_before_actual_iter')
# wait enumerates before timeout/return_when checks, and an empty set bypasses both.
v,p,a,i=m.env();env,_=environment(v,[])
h,r,_=i.wait(fn=fn,env=env,timeout=v.scalar('bad'),when=3);assert u(r,64)==0
old=Original([]);assert not cf.wait(old,timeout='bad',return_when='bad').done
assert (u(state(v,env),16),u(state(v,env),24))==(old.iter_calls,old.next_calls)
a.close(h);finish(v,p,a,i);done('wait_empty_iterator_bypasses_bad_timeout_and_condition')
v,p,a,i=m.env();env,_=environment(v,[],1)
_,r,_=i.wait(fn=fn,env=env,timeout=v.scalar('bad'),when=3,status=1);assert u(r,16)==200
v.held.append(struct.unpack_from('<3Q',r,72));finish(v,p,a,i);done('wait_actual_iter_exception_precedes_timeout_and_condition')
# Deadline starts before real native enumeration, not when the captured array is ready.
v,p,a,i=m.env();fac=p.factory();f=p.make(fac);env,_=environment(v,[f],iter_ns=60000000)
h=i.start(fn=fn,env=env,timeout=v.scalar(.025));start=time.monotonic();_,r,elapsed=i.next(h,status=1)
assert u(r,16)==101 and elapsed>=.05 and u(r,96)==1 and u(r,104)==1
st=state(v,env);assert (u(st,16),u(st,24))==(1,2)
finish(v,p,a,i);done('actual_native_enumeration_uses_preexisting_deadline',elapsed=elapsed)
# There is no 128-item cap, and every successful next is an owned reference even for duplicates.
v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(259)]
for j,f in enumerate(fs):p.complete(f,v.scalar(j))
inputs=fs+fs[::-1]+fs[:130];env,_=environment(v,inputs);h=i.start(fn=fn,env=env)
refs=[i.next(h)[0]for _ in fs];assert i.next(h)[0]is None
assert sorted(read_values(v,p,refs))==list(range(259));st=state(v,env);assert (u(st,16),u(st,24))==(1,len(inputs)+1)
finish(v,p,a,i);done('native_iterable_648_owned_yields_259_unique_all_refs_reclaimed')
# The built-in list retains true Futures before first next, independent of input-owner lifetime.
v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(3)]
for j,f in enumerate(fs):p.complete(f,v.scalar(j))
h=i.start(fs)
for f in fs:p.drop(f)
refs=[i.next(h)[0]for _ in range(3)];assert i.next(h)[0]is None
assert sorted(read_values(v,p,refs))==[0,1,2];finish(v,p,a,i);done('builtin_list_owns_inputs_until_transfer')
v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(3)]
for j,f in enumerate(fs):p.complete(f,v.scalar(j))
env,_=environment(v,fs);h=i.start(fn=fn,env=env);f,_,_=i.next(h);i.close(h)
assert u(p.ctx.raw,48)==0;finish(v,p,a,i);done('partly_yielded_generator_close_releases_remaining_set')
report={'passed':True,'cases':rows,'case_groups':len(rows),'adapter_calls':m.calls,'array_calls':m.m.calls,'public_calls':m.m.m.calls,'value_calls':total_value_calls,'adapter_sha256':m.meta['flat_sha256'],'producer_sha256':pm['flat_sha256'],'semantic_callback_execution':'actual compiled HIA; no host callback/effect dispatcher','whole_public_future_closed':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

