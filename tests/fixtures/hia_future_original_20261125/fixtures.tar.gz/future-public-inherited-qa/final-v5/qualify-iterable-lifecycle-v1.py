from pathlib import Path
import ctypes as C,struct,json,hashlib,importlib.util,threading,time,os,subprocess
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=Q/'iterable-lifecycle-v1';D.mkdir()
sp=importlib.util.spec_from_file_location('fixture',Q/'native-iterator-fixture-client-v1.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
m=c.m;u=m.u;rows=[]
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});print('ITERABLE_LIFECYCLE',name,flush=True)
def field(v,obj,key):return v.take(v.call(9,obj,v.scalar(key)))
class SubStop(StopIteration):pass
class FakeStop(Exception):pass
FakeStop.__name__='StopIteration'
for original_class,label in((StopIteration,'base'),(SubStop,'subclass')):
 for mode in('wait','as'):
  ex=original_class('stop object');old=c.Original([],1,error=ex)
  try:c.cf.wait(old)if mode=='wait'else next(c.cf.as_completed(old))
  except BaseException as got:
   if mode=='wait':assert got is ex
   else:assert type(got)is RuntimeError and str(got)=='generator raised StopIteration' and got.__cause__ is ex and got.__context__ is ex and got.__suppress_context__
  else:raise AssertionError('missing original StopIteration effect')
  v,p,a,i=m.env();env,error=c.environment(v,[],fail_stage=1,status=4)
  v.call(10,error,v.scalar('class'),v.scalar(original_class.__name__))
  # An original exception can carry cycles; wrapping preserves its identity.
  v.call(10,error,v.scalar('self'),error)
  if mode=='wait':_,r,_=i.wait(fn=c.fn,env=env,status=1)
  else:h=i.start(fn=c.fn,env=env);_,r,_=i.next(h,status=1);assert u(r,112)==1
  assert u(r,16)==200 and u(r,120)==0
  result=struct.unpack_from('<3Q',r,72);v.held.append(result)
  if mode=='wait':assert v.type(result)[3:]==v.type(error)[3:]
  else:
   assert v.raw(field(v,result,'class'))==b'RuntimeError'
   assert v.raw(field(v,result,'message'))==b'generator raised StopIteration'
   assert v.type(field(v,result,'__cause__'))[3:]==v.type(error)[3:]
   assert v.type(field(v,result,'__context__'))[3:]==v.type(error)[3:]
   assert v.raw(field(v,result,'__suppress_context__'))==b'\x01'
  c.finish(v,p,a,i)
 done('actual_PEP479_'+label+'_cause_context_identity_cycles')
# StopIteration from next is normal exhaustion, even when it carries an owned object.
for mode in('wait','as'):
 v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(5)]
 for j,f in enumerate(fs):p.complete(f,v.scalar(j))
 env,error=c.environment(v,fs,fail_stage=2,fail_at=2,status=4)
 v.call(10,error,v.scalar('class'),v.scalar('SubStop'))
 old=c.Original(c.originals(5),2,2,error=SubStop('next stop'))
 if mode=='wait':
  expected=c.cf.wait(old);h,r,_=i.wait(fn=c.fn,env=env);assert u(r,64)==2
  refs=[a.take(h,j)[0]for j in range(2)];a.close(h)
 else:
  expected=list(c.cf.as_completed(old));h=i.start(fn=c.fn,env=env);refs=[i.next(h)[0]for _ in range(2)];_,r,_=i.next(h);assert u(r,16)==4 and u(r,112)==1
 assert sorted(c.read_values(v,p,refs))==[0,1]
 st=c.state(v,env);assert (u(st,16),u(st,24))==(old.iter_calls,old.next_calls)
 c.finish(v,p,a,i)
done('actual_next_StopIteration_owned_object_is_consumed')
# A class spelling is not an exception-family proof.
v,p,a,i=m.env();env,error=c.environment(v,[],fail_stage=1,status=1)
v.call(10,error,v.scalar('class'),v.scalar('StopIteration'))
old=c.Original([],1,error=FakeStop('not a StopIteration subclass'))
try:next(c.cf.as_completed(old))
except BaseException as ex:assert type(ex)is FakeStop
else:raise AssertionError('missing original fake class exception')
h=i.start(fn=c.fn,env=env);_,r,_=i.next(h,status=1)
result=struct.unpack_from('<3Q',r,72);v.held.append(result);assert v.type(result)[3:]==v.type(error)[3:]
c.finish(v,p,a,i);done('no_family_inference_from_class_string')
# Busy next/close do not consume the generator. Both are actual concurrent calls.
v,p,a,i=m.env();fac=p.factory();f=p.make(fac);p.complete(f,v.scalar(7))
env,_=c.environment(v,[f],iter_ns=150000000);h=i.start(fn=c.fn,env=env);answers=[];errors=[]
def actual():
 try:answers.append(i.next(h))
 except BaseException as ex:errors.append(repr(ex))
t=threading.Thread(target=actual);t.start();deadline=time.monotonic()+2
while u(c.state(v,env),16)==0:
 assert time.monotonic()<deadline;time.sleep(.001)
for op in(2,3):
 r,_=i.call(op,handle=h,status=1);assert u(r,16)==105 and u(r,96)==2 and u(r,112)==0 and u(p.ctx.raw,48)!=0,r[:128].hex()
t.join(2);assert not t.is_alive()and not errors and len(answers)==1
assert c.read_values(v,p,[answers[0][0]])==[7];i.close(h);c.finish(v,p,a,i)
old=c.Original(c.originals(1),delay=.1);it=c.cf.as_completed(old);got=[];t=threading.Thread(target=lambda:got.append(next(it)));t.start()
while old.iter_calls==0:time.sleep(.001)
for action in(lambda:next(it),it.close):
 try:action()
 except ValueError as ex:assert str(ex)=='generator already executing'
 else:raise AssertionError('missing original reentry error')
t.join(2);assert len(got)==1;it.close();done('actual_busy_next_and_close_preserve_capability')
# Inactive lazy nodes coexist with true completion notifications and concurrent closure.
v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(32)];env,_=c.environment(v,[])
hs=[i.start(fn=c.fn,env=env)for _ in range(64)];fail=[]
def closers(group):
 try:
  for h in hs[group::4]:i.close(h)
 except BaseException as ex:fail.append(repr(ex))
threads=[threading.Thread(target=closers,args=(j,))for j in range(4)]
for t in threads:t.start()
for j,f in enumerate(fs):p.complete(f,v.scalar(j))
for t in threads:t.join(3);assert not t.is_alive()
assert not fail and u(c.state(v,env),16)==0 and u(p.ctx.raw,48)==0
c.finish(v,p,a,i);done('64_lazy_nodes_notify_and_four_concurrent_close_threads')
# Actual kernel ENOMEM at collector creation/growth and downstream array allocation.
class Filter(C.Structure):_fields_=[('code',C.c_ushort),('jt',C.c_ubyte),('jf',C.c_ubyte),('k',C.c_uint)]
class Program(C.Structure):_fields_=[('length',C.c_ushort),('filter',C.POINTER(Filter))]
def deny_mmap_size(n):
 lib=C.CDLL(None,use_errno=True);arr=(Filter*8)(Filter(0x20,0,0,0),Filter(0x15,0,5,9),Filter(0x20,0,0,24),Filter(0x15,0,3,n),Filter(0x20,0,0,28),Filter(0x15,0,1,0),Filter(0x06,0,0,0x5000c),Filter(0x06,0,0,0x7fff0000));prog=Program(8,arr)
 assert lib.prctl(38,1,0,0,0)==0;assert lib.prctl(22,2,C.byref(prog),0,0)==0
faults=[]
for amount,expected_next in((544,1),(928,9),(1952,21)):
 rd,wr=os.pipe();pid=os.fork()
 if pid==0:
  os.close(rd)
  try:
   v,p,a,i=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(20)]
   for j,f in enumerate(fs):p.complete(f,v.scalar(j))
   env,_=c.environment(v,fs);h=i.start(fn=c.fn,env=env);deny_mmap_size(amount)
   _,r,_=i.next(h,status=3);assert u(r,16)==103 and u(r,112)==1 and u(r,120)==0 and u(p.ctx.raw,48)==0,r[:128].hex()
   st=c.state(v,env);assert u(st,24)==expected_next,(amount,u(st,24),expected_next)
   c.finish(v,p,a,i);os.write(wr,json.dumps({'bytes':amount,'next_calls':expected_next,'passed':True}).encode());os._exit(0)
  except BaseException as ex:os.write(wr,repr(ex).encode()[:2000]);os._exit(1)
 os.close(wr);raw=os.read(rd,4096);os.close(rd);_,status=os.waitpid(pid,0);assert status==0,(amount,status,raw);faults.append(json.loads(raw))
done('three_actual_kernel_ENOMEM_partial_owned_collection_paths',faults=faults)
# A native test-only value façade injects documented MemoryError replies at each
# PEP479 allocation/set boundary. It delegates every other call to the unchanged
# actual value image. This is protocol fault injection, separate from ENOMEM above.
asm=r'''
.intel_syntax noprefix
.text
.global fault
fault:
 movabs r10,0x1111222233334444
 movabs r11,0x5555666677778888
 cmp [rdi+8],r11
 jne real
 inc qword ptr [r10]
 movabs r11,0x9999aaaabbbbcccc
 cmp [r10],r11
 jne real
 inc qword ptr [r10+8]
 mov r11,rdx
 mov rdi,rdx
 xor eax,eax
 mov ecx,16
 cld
 rep stosq
 movabs rax,0x3130525642414948
 mov [r11],rax
 mov qword ptr [r11+8],5
 xor eax,eax
 ret
real:
 movabs r11,0xddddeeeeffff0000
 jmp r11
'''
(D/'value-fault.S').write_text(asm);subprocess.run(['as','--64','-o',str(D/'value-fault.o'),str(D/'value-fault.S')],check=True);subprocess.run(['objcopy','-O','binary','-j','.text',str(D/'value-fault.o'),str(D/'value-fault.template')],check=True)
template=(D/'value-fault.template').read_bytes();failrows=[]
for op,target in [(4,1)]+[(2,x)for x in range(5,13)]+[(10,x)for x in range(1,6)]:
 v,p,a,i=m.env();env,error=c.environment(v,[],fail_stage=1,status=4);h=i.start(fn=c.fn,env=env)
 actual=u(p.ctx.raw,72);counter=C.create_string_buffer(16);image=template
 for before,after in [(0x1111222233334444,C.addressof(counter)),(0x5555666677778888,op),(0x9999aaaabbbbcccc,target),(0xddddeeeeffff0000,actual)]:
  assert image.count(struct.pack('<Q',before))==1;image=image.replace(struct.pack('<Q',before),struct.pack('<Q',after))
 path=D/f'value-fault-{op}-{target}.flat';path.write_bytes(image);fault=m.m.m.m.load(path,hashlib.sha256(image).hexdigest())
 struct.pack_into('<Q',p.ctx,72,C.cast(fault,C.c_void_p).value)
 _,r,_=i.next(h,status=3)
 struct.pack_into('<Q',p.ctx,72,actual)
 assert u(r,16)==103 and u(r,112)==1 and u(r,120)==0 and r[72:96]==bytes(24)and u(counter.raw,8)==1,(op,target,r[:128].hex(),counter.raw.hex())
 assert u(p.ctx.raw,48)==0;c.finish(v,p,a,i);failrows.append({'op':op,'nth':target,'passed':True})
done('fourteen_native_value_faults_PEP479_partial_wrapper_cleanup',faults=failrows)
report={'passed':True,'cases':rows,'case_groups':len(rows),'adapter_calls':m.calls,'public_calls':m.m.m.calls,'adapter_sha256':m.meta['flat_sha256'],'producer_sha256':c.pm['flat_sha256'],'whole_public_future_closed':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

