from pathlib import Path
import ctypes as C,struct,json,hashlib,importlib.util,time,threading,sys,resource
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=None
resource.setrlimit(resource.RLIMIT_CORE,(0,0));C.CDLL(None).prctl(4,0,0,0,0)
spec=importlib.util.spec_from_file_location('public_future',Q/'client-v3.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
meta=json.loads((T/'future-public-inherited-qa/owner-native-v1/build.json').read_text());entry=m.m.load(T/'future-public-inherited-qa/owner-native-v1/observers.flat',meta['flat_sha256'])
calls=0;rows=[]
def u(b,p):return struct.unpack_from('<Q',b,p)[0]
class Observer:
 def __init__(self,p):self.p=p;self.handles=[]
 def call(self,op,fs=(),timeout=(0,0,0),when=2,handle=(0,0,0),index=0,status=0,version=1):
  global calls
  wire=bytearray(128);wire[:8]=b'HIABFO02'if version==2 else b'HIABFO01';struct.pack_into('<Q',wire,8,op)
  if op<2:
   struct.pack_into('<2Q',wire,16,len(fs),when if op==0 else 0);struct.pack_into('<3Q',wire,32,*timeout)
   wire+=b''.join(struct.pack('<6Q',*(fid+cap))for fid,cap in fs)
  else:struct.pack_into('<4Q',wire,16,*handle,index)
  s=C.create_string_buffer(bytes(wire));o=C.create_string_buffer(b'\xa7'*131072,131072)
  started=time.monotonic();rc=entry(s,len(wire),o,131072,self.p.ctx,256);elapsed=time.monotonic()-started;calls+=1
  assert rc==0 and o.raw[:8]==b'HIABFOR1',(op,rc,o.raw[:128].hex())
  assert u(o.raw,8)==status,(op,status,o.raw[:128].hex())
  return o.raw,elapsed
 def start(self,fs,timeout=(0,0,0)):
  r,_=self.call(1,fs,timeout);assert u(r,16)==2;h=struct.unpack_from('<3Q',r,24);self.handles.append(h);return h
 def wait(self,fs,timeout=(0,0,0),when=2):
  r,e=self.call(0,fs,timeout,when);assert u(r,16)==1;h=struct.unpack_from('<3Q',r,24);self.handles.append(h);return h,r,e
 def take(self,h,index):
  r,_=self.call(3,handle=h,index=index);assert u(r,16)==3
  f=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));self.p.fs.append(f);return f,u(r,96)
 def next(self,h,status=0):
  r,e=self.call(2,handle=h,status=status)
  if status or u(r,16)==4:
   self.handles.remove(h);return None,r,e
  assert u(r,16)==3;f=(struct.unpack_from('<3Q',r,24),struct.unpack_from('<3Q',r,48));self.p.fs.append(f);return f,r,e
 def close(self,h):
  r,_=self.call(4,handle=h);assert u(r,16)==0;self.handles.remove(h)
 def finish(self):
  for h in self.handles[:]:self.close(h)
  assert u(self.p.ctx.raw,48)==0
def env():
 v=m.m.Values(entry=m.ve);p=m.Public(v);ob=Observer(p);return v,p,ob
def done(name,**extra):
 rows.append({'case':name,'passed':True,**extra});print('OBSERVER_CASE',name,calls,flush=True);(D/'report.json').write_text(json.dumps({'passed':False,'cases':rows,'calls':calls},indent=2)+'\n')
