from pathlib import Path
import importlib.util,json,sys,re,math,ctypes
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=Q/'smoke-v2';D.mkdir()
sp=importlib.util.spec_from_file_location('h',Q/'client-v3.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sys.path.insert(0,str(T/'future-public-inherited-source'))
from hepta.hia_background_optimizer import _OptimizationFuture,PublicationCancellation
rows=[]
def original():
 token=PublicationCancellation();return _OptimizationFuture(token),token
def call_error(f,method,arg=None,hasarg=False):
 try:
  result=getattr(f,method)(arg) if hasarg else getattr(f,method)()
  return ('ok',result)
 except BaseException as exc:return (type(exc).__name__,str(exc))
v=h.m.Values(h.ve);p=h.Public(v);factory=p.factory();x=p.make(factory);of,ot=original()
ident=h.u(p.call(21,*x),96)
assert h.u(p.call(25,*x),96)==of.running()==0
assert h.u(p.call(24,*x),96)==of.set_running_or_notify_cancel()==1
assert h.u(p.call(16,*x),96)==of.running()==1
assert h.u(p.call(7,*x),96)==of.cancel()==0
assert h.u(p.call(9,*x),120)==1 and ot.cancelled()
assert h.u(p.call(8,*x),96)==of._settle_token_cancellation()==0
value=v.scalar(42);p.call(22,*x,value=value,kind=1);of.set_result(42)
cap,r=p.result(x);assert v.raw(cap)==b'42' and of.result()==42
expected=call_error(of,'set_result',99,True);r=p.call(22,*x,value=v.scalar(99),kind=1,status=1);got=h.take_error(v,r)
assert got=={'class':expected[0],'message':expected[1].replace(hex(id(of)),hex(ident))},(got,expected)
rows.append({'case':'running-cancel-token-strict-result-and-exact-invalid-state','passed':True})
for i,value in enumerate([None,False,True,0,1,-1,-0.0,0.5,float('nan'),float('inf'),'','x',b'',b'x']):
 x=p.make(factory);of,ot=original();cap=v.scalar(value);of.set_exception(value);p.call(23,*x,value=cap,kind=1)
 q,r=p.result(x,exception=True);assert v.type(q)[3:]==v.type(cap)[3:]
 expected=call_error(of,'result')
 if expected[0]=='ok':
  q,r=p.result(x);assert not q[0] and h.u(r,16)==0 and expected[1] is None
 else:
  q,r=p.result(x,status=1);assert h.take_error(v,r)=={'class':expected[0],'message':expected[1]}
 rows.append({'case':'arbitrary-exception-'+str(i),'passed':True})
x=p.make(factory);of,ot=original();a=[];of.set_exception(a);cap=v.empty(list);p.call(23,*x,value=cap,kind=1);expected=call_error(of,'result');q,r=p.result(x,status=1);assert h.take_error(v,r)=={'class':expected[0],'message':expected[1]}
a.append(1);v.call(16,cap,v.scalar(1));expected=call_error(of,'result');q,r=p.result(x,status=1);assert h.take_error(v,r)=={'class':expected[0],'message':expected[1]}
rows.append({'case':'mutable-nonexception-remains-TypeError','passed':True})
x=p.make(factory);of,ot=original();ident=h.u(p.call(21,*x),96)
assert h.u(p.call(7,*x),96)==of.cancel()==1
expected=call_error(of,'set_running_or_notify_cancel');r=p.call(24,*x,status=1);assert h.take_error(v,r)=={'class':expected[0],'message':expected[1]}
expected=call_error(of,'set_exception',None,True);r=p.call(23,*x,value=v.scalar(None),kind=1,status=1);assert h.take_error(v,r)=={'class':expected[0],'message':expected[1].replace(hex(id(of)),hex(ident))}
rows.append({'case':'cancel-notified-strict-running-and-setter-errors','passed':True})
p.finish();v.finish()
report={'passed':True,'component_only':True,'whole_public_future_closed':False,'image':h.pin,'public_calls':h.calls,'value_calls':v.calls,'rows':rows}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('INHERITED_SMOKE_PASS',len(rows),h.calls,v.calls,flush=True)
