from pathlib import Path
import importlib.util,itertools,concurrent.futures as cf,time,threading,json,struct,math,sys
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=Q/'owner-original-v4';D.mkdir()
sp=importlib.util.spec_from_file_location('observers',Q/'observer-client-v4.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
u=m.u;rows=[]
def argument(v,x):
 return v.empty(type(x))if type(x)in(dict,list)else v.scalar(x)
def finish(v,p,o):o.finish();p.finish();v.finish()
def done(name,**kw):
 rows.append({'case':name,'passed':True,**kw});(D/'report.json').write_text(json.dumps({'passed':False,'cases':rows,'calls':m.calls},indent=2)+'\n');print('OBSERVER_ORIGINAL',name,m.calls,flush=True)
def original(states):
 fs=[]
 for state in states:
  f=cf.Future()
  if state=='r':f.set_result(1)
  elif state=='e':f.set_exception(ValueError('original-error'))
  elif state=='c':f.cancel();f.set_running_or_notify_cancel()
  fs.append(f)
 return fs
for states in itertools.product('prec',repeat=3):
 for when,condition in enumerate((cf.FIRST_COMPLETED,cf.FIRST_EXCEPTION,cf.ALL_COMPLETED,'invalid')):
  pyfs=original(states)
  try:
   a,b=cf.wait(pyfs,timeout=0,return_when=condition);expected={i for i,f in enumerate(pyfs)if f in a};error=False
  except ValueError:expected=None;error=True
  v,p,o=m.env();fac=p.factory();fs=[p.make(fac)for _ in states]
  for f,state in zip(fs,states):
   if state=='r':p.complete(f,v.scalar(1))
   elif state=='e':p.complete(f,m.m.record(v,'ValueError','original-error'),2)
   elif state=='c':p.call(7,*f)
  if error:
   r,_=o.call(0,fs,timeout=v.scalar(0),when=when,status=1);assert u(r,16)==105
  else:
   h,r,_=o.wait(fs,timeout=v.scalar(0),when=when);actual=set()
   for i in range(3):
    _,flag=o.take(h,i)
    if flag:actual.add(i)
   assert actual==expected,(states,condition,actual,expected);o.close(h)
  finish(v,p,o)
done('all_256_three_future_state_and_condition_pairs',pairs=256)
sys.set_int_max_str_digits(0)
values=['text',{},[],float('inf'),float('-inf'),float('nan'),0,-1,-1e300,10**100,-10**1000,None]
for value in values:
 # Pending wait: exclude the sole infinite-wait case, completed case always ignores it.
 if value is not None:
  f=cf.Future()
  try:r=cf.wait([f],timeout=value);expected=None
  except BaseException as e:expected=type(e).__name__
  v,p,o=m.env();fac=p.factory();f=p.make(fac);timeout=argument(v,value)
  if expected:
   r,_=o.call(0,[f],timeout=timeout,status=1)
   assert u(r,16)=={'TypeError':104,'OverflowError':106}[expected],(repr(value),r[:128].hex(),expected)
  else:
   h,r,_=o.wait([f],timeout=timeout);assert u(r,48)==0 and u(r,56)==1;o.close(h)
  finish(v,p,o)
 v,p,o=m.env();fac=p.factory();f=p.make(fac);p.complete(f,v.scalar(1));h,r,_=o.wait([f],timeout=argument(v,value));assert u(r,48)==1;o.close(h);finish(v,p,o)
done('original_wait_timeout_type_sign_nan_and_bypass',values=len(values))
for value in values+[10**1000,-10**1000,True,False]:
 for complete in(False,True):
  # NaN/None and positive small values with pending futures need a separate event test.
  if not complete and(value is None or isinstance(value,float)and math.isnan(value)or value is True):continue
  py=cf.Future()
  if complete:py.set_result(1)
  try:
   out=list(cf.as_completed([py],timeout=value));expected=None
  except BaseException as e:expected=type(e).__name__
  v,p,o=m.env();fac=p.factory();f=p.make(fac)
  if complete:p.complete(f,v.scalar(1))
  timeout=argument(v,value)
  try:
   h=o.start([f],timeout)
  except AssertionError as e:
   # Read the genuine response directly for input-time exceptions.
   r,_=o.call(1,[f],timeout=timeout,status=1)
   assert expected in('TypeError','OverflowError')and u(r,16)=={'TypeError':104,'OverflowError':106}[expected],(repr(value),expected,r[:128].hex())
  else:
   if expected:
    _,r,_=o.next(h,status=1);assert u(r,16)=={'TimeoutError':101,'OverflowError':106}[expected],(repr(value),expected,r[:128].hex())
   else:
    got,r,_=o.next(h);assert got;got,r,_=o.next(h);assert got is None
  finish(v,p,o)
done('original_as_completed_timeout_ordering')
for timeout in(None,float('nan')):
 v,p,o=m.env();fac=p.factory();f=p.make(fac);h=o.start([f],v.scalar(timeout));errors=[]
 def run():
  try:time.sleep(.01);p.complete(f,v.scalar(7))
  except BaseException as e:errors.append(repr(e))
 t=threading.Thread(target=run);t.start();got,r,_=o.next(h);t.join(2);assert got and not t.is_alive()and not errors
 o.next(h);finish(v,p,o)
done('as_completed_None_and_nan_actual_completion')
# More than 128 futures and aliases across factories. No global fixed-N admission.
v,p,o=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(259)]
for f in fs:p.complete(f,v.scalar(1))
inputs=fs+fs[::-1]+[p.retain(f)for f in fs[::2]]
h,r,_=o.wait(inputs,timeout=v.scalar(0));assert u(r,64)==259
for i in range(259):o.take(h,i)
o.close(h);finish(v,p,o)
done('259_unique_648_inputs_no_128_limit')
# One initial condition can be used by multiple unrelated subscriptions.
v,p,o=m.env();fac=p.factory();fs=[p.make(fac)for _ in range(8)];a=o.start(fs);b=o.start(fs)
order=[7,0,5,2,6,1,4,3]
for i in order:p.complete(fs[i],v.scalar(i))
observed=[]
for h in(a,b):
 order2=[]
 for i in order:
  got,_,_=o.next(h);cap,_=p.result(got);order2.append(int(v.raw(cap)))
 o.next(h);observed.append(order2)
assert observed==[order,order];finish(v,p,o)
done('two_live_iterators_identical_completion_order')
# Transfer an earlier real deadline capture rather than restarting after iterable enumeration.
v,p,o=m.env();fac=p.factory();a=p.make(fac);b=p.make(fac);clock=o.start([],v.scalar(.001));time.sleep(.01);p.complete(a,v.scalar(1))
r,_=o.call(1,[a,b],timeout=clock,version=2);h=struct.unpack_from('<3Q',r,24);o.handles.append(h)
got,_,_=o.next(h);assert got
_,r,_=o.next(h,status=1);assert u(r,16)==101 and u(r,96)==1
o.close(clock);finish(v,p,o)
done('earlier_actual_deadline_capture_no_extension')
# Every failed actual cap lookup after a successful retain releases the partial collection.
v,p,o=m.env();fac=p.factory();f=p.make(fac);bad=(f[0],(1,2,3))
expected=p.call(5,*bad,status=3)
r,_=o.call(0,[f,bad],timeout=v.scalar(0),status=3);assert u(r,16)==u(expected,16)==107 and u(p.ctx.raw,48)==0
finish(v,p,o);done('partial_collection_bad_future_cleanup')
report={'passed':True,'cases':rows,'calls':m.calls,'actual_public_calls':m.m.calls,'observer_pin':m.meta['flat_sha256'],'public_future_pin':m.m.pin,'whole_public_iterable':False,'scope':'actual-native array owner vs original concurrent.futures'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
