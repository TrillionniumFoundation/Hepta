from pathlib import Path
import importlib.util,json,ctypes as C,struct
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5'
sp=importlib.util.spec_from_file_location('base',T/'future-public-client-v3.py');base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base)
m=base.m;ve=base.ve;u=base.u;record=base.record
D=T/'future-public-inherited-qa/public-native-v5';meta=json.loads((D/'build.json').read_text());pin=next(x['sha256']for x in meta['products']if x['format']=='flat')
entry=m.load(D/'future-public.flat',pin);calls=0
class Public(base.Public):
 def call(self,op,fid=(0,0,0),cap=(0,0,0),value=(0,0,0),fn=0,kind=0,timeout=(0,0,0),status=0):
  global calls
  raw=bytearray(192);raw[:8]=b'HIABFP02' if op>=22 else b'HIABFP01';struct.pack_into('<Q',raw,8,op)
  for at,x in [(16,fid),(40,cap),(64,value),(104,timeout)]:struct.pack_into('<3Q',raw,at,*x)
  struct.pack_into('<2Q',raw,88,fn,kind);s=C.create_string_buffer(bytes(raw));o=C.create_string_buffer(b'\xb5'*65536,65536)
  rc=entry(s,192,o,65536,self.ctx,256);calls+=1
  assert rc==0 and o.raw[:8]==b'HIABFRP1',(op,rc,o.raw[:128].hex())
  assert status is None or u(o.raw,8)==status,(op,status,o.raw[:128].hex())
  return o.raw
def take_error(v,r):
 assert u(r,16)==200,r[:128].hex()
 cap=struct.unpack_from('<3Q',r,72)
 if cap not in v.held:v.held.append(cap)
 out={}
 for name in ('class','message'):
  key=v.scalar(name);found=v.take(v.call(9,cap,key));out[name]=v.raw(found).decode('utf8','surrogatepass')
 return out

rows=[]
def done(name,**extra):
 rows.append({'case':name,'passed':True,**extra});print('PUBLIC_CASE',name,calls,flush=True);(D/'report.json').write_text(json.dumps({'passed':False,'cases':rows,'calls':calls},indent=2)+'\n')
