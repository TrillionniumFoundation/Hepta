from pathlib import Path
import ctypes as C,struct,json,importlib.util,threading,time,traceback,faulthandler
faulthandler.enable()
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');D=T/'future-public-inherited-qa/final-v5/regression-cleanup-v2';D.mkdir(exist_ok=False)
sp=importlib.util.spec_from_file_location('publicclient',T/'future-public-inherited-qa/final-v5/regression-client-v1.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);h.D=D
CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
@CB
def callback(s,sn,o,on,w,wn):
 out=bytearray(128);out[:8]=b'HIAFCBR1';C.memmove(o,bytes(out),128);return 0
def caps(v):return C.c_uint64.from_address(h.u(v.ctx.raw,16)+88).value
v=h.m.Values(entry=h.ve);p=h.Public(v);fac=p.factory();f=p.make(fac);value=v.scalar('owned result');p.complete(f,value);before=caps(v);magic=h.u(v.ctx.raw,0)
# This deliberately invalidates the actual captured dependency for a private
# cleanup-fault control. It does not forge a provider response or change code.
struct.pack_into('<Q',v.ctx,0,0)
r=p.call(6,*f,status=1);assert h.u(r,16)==107;p.fs.remove(f);assert caps(v)==before
p.drop_factory(fac);p.call(18,status=1)
struct.pack_into('<Q',v.ctx,0,magic)
p.call(20);assert h.u(p.ctx.raw,16)==0;p.call(18);assert v.raw(value)==b'owned result';v.finish()
h.done('actual-rejected-value-context-retains-result-box-cell-factory-until-retry')

v=h.m.Values(entry=h.ve);p=h.Public(v);facilities=[p.factory()for _ in range(3)];futures=[p.make(fac)for fac in facilities for _ in range(3)];env=v.scalar('owned closure')
for f in futures:p.call(13,*f,value=env,fn=C.cast(callback,C.c_void_p).value)
before=caps(v);magic=h.u(v.ctx.raw,0);struct.pack_into('<Q',v.ctx,0,0)
for f in futures:
 r=p.call(6,*f,status=1);assert h.u(r,16)==107;p.fs.remove(f)
for fac in facilities:p.drop_factory(fac)
assert caps(v)==before
for fac in facilities:
 carrier=C.c_uint64.from_address(fac[0][0]+104).value;count=0
 while carrier:
  assert C.c_uint64.from_address(carrier+96).value==3;carrier=C.c_uint64.from_address(carrier+88).value;count+=1
 assert count==3,count
struct.pack_into('<Q',v.ctx,0,magic)
barrier=threading.Barrier(8);errors=[]
def retry():
 try:
  barrier.wait(10)
  for _ in range(8):p.call(20)
 except BaseException:errors.append(traceback.format_exc())
threads=[threading.Thread(target=retry)for _ in range(8)]
for t in threads:t.start()
for t in threads:t.join(20)
assert not errors and all(not t.is_alive()for t in threads),errors
assert h.u(p.ctx.raw,16)==0 and caps(v)==2,(h.u(p.ctx.raw,16),caps(v))
p.call(18);assert caps(v)==1;v.finish();h.done('parallel-quarantined-closure-and-cell-retries-remove-neighbours-once',factories=3,carriers=9,threads=8,retry_calls=64)
report={'passed':True,'count':len(h.rows),'calls':h.calls,'cases':h.rows,'image_sha256':h.pin,'whole_public_future_closed':False,'fault_scope':'Private dependency-integrity control: temporarily set actual value context magic invalid, then restore exact original word. This is not an ordinary MemoryError and does not broaden the callable trust boundary.'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PUBLIC_CLEANUP_PASS',report,flush=True)
