from pathlib import Path
import importlib.util,json,sys,struct,ctypes as C,threading,time,concurrent.futures as cf,traceback
T=Path('/home/qian-qi/.local/state/hia-native-final-custody-20261125');Q=T/'future-public-inherited-qa/final-v5';D=Q/'waiters-inherited-v1';D.mkdir()
sp=importlib.util.spec_from_file_location('o',Q/'observer-client-v4.py');o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o);h=o.m
sys.path.insert(0,str(T/'future-public-inherited-source'))
from hepta.hia_background_optimizer import _OptimizationFuture,PublicationCancellation
rows=[]
def wait_ready(probe):
 until=time.monotonic()+3
 while not probe():
  assert time.monotonic()<until,'waiter did not register'
  time.sleep(.001)
def collect_py(initial,exc,value):
 fs=[_OptimizationFuture(PublicationCancellation()) for _ in range(2)];answer=[];errors=[];done=threading.Event()
 if initial:getattr(fs[0],'set_exception'if exc else'set_result')(value)
 def run():
  try:answer.append(cf.wait(fs,timeout=.4,return_when=cf.FIRST_EXCEPTION))
  except BaseException:errors.append(traceback.format_exc())
  finally:done.set()
 th=threading.Thread(target=run);th.start()
 immediate=initial and exc and value is not None
 if immediate:assert done.wait(2)
 else:
  wait_ready(lambda:bool(fs[1]._waiters))
  if not initial:getattr(fs[0],'set_exception'if exc else'set_result')(value)
 early=done.wait(.04)
 fs[1].set_result('second');th.join(2);assert not th.is_alive()and not errors,errors
 return early,{i for i,f in enumerate(fs)if f in answer[0].done}
def collect_native(initial,exc,value):
 v,p,a=o.env();fac=p.factory();fs=[p.make(fac)for _ in range(2)];answer=[];errors=[];done=threading.Event();payload=v.scalar(value)
 if initial:p.call(23 if exc else 22,*fs[0],value=payload,kind=1)
 def run():
  try:answer.append(a.wait(fs,timeout=v.scalar(.4),when=1))
  except BaseException:errors.append(traceback.format_exc())
  finally:done.set()
 th=threading.Thread(target=run);th.start()
 immediate=initial and exc and value is not None
 if immediate:assert done.wait(2)
 else:
  wait_ready(lambda:bool(o.u(p.ctx.raw,48))and C.c_uint64.from_address(o.u(p.ctx.raw,48)+96).value==1)
  if not initial:p.call(23 if exc else 22,*fs[0],value=payload,kind=1)
 early=done.wait(.04)
 p.call(22,*fs[1],value=v.scalar('second'),kind=1);th.join(2);assert not th.is_alive()and not errors,errors
 handle,r,_=answer[0];mask={i for i in range(2)if a.take(handle,i)[1]};a.close(handle);a.finish();p.finish();v.finish()
 return early,mask
for initial in(False,True):
 for exc in(False,True):
  for value in(None,False,0,''):
   py=collect_py(initial,exc,value);native=collect_native(initial,exc,value)
   assert native==py,(initial,exc,repr(value),native,py)
   rows.append({'case':'FIRST_EXCEPTION','initial':initial,'exception_completion':exc,'value':repr(value),'early':py[0],'done':sorted(py[1]),'passed':True})
print('FIRST_EXCEPTION_MATRIX',len(rows),flush=True)

# The first real native callback publishes observer completion before user callbacks.
CB=C.CFUNCTYPE(C.c_uint32,*([C.c_void_p,C.c_uint64]*3))
for operation in('result','exception','cancel'):
 v,p,a=o.env();fac=p.factory();f=p.make(fac);events=[];errors=[];env=v.scalar(None);it=a.start([f]);identity=o.u(p.call(21,*f),96)
 @CB
 def callback(s,sn,out,on,w,wn):
  try:
   raw=C.string_at(s,sn);same=(struct.unpack_from('<3Q',raw,16),struct.unpack_from('<3Q',raw,40));assert o.u(p.call(21,*same),96)==identity
   assert C.c_uint64.from_address(it[0]+72).value==1
   h0,r,_=a.wait([same],timeout=v.scalar(0),when=2);_,flag=a.take(h0,0);assert flag==1;a.close(h0)
   events.append('user-after-actual-notify')
   answer=bytearray(128);answer[:8]=b'HIAFCBR1';C.memmove(out,bytes(answer),128);return 0
  except BaseException:errors.append(traceback.format_exc());return 99
 p.call(13,*f,value=env,fn=C.cast(callback,C.c_void_p).value)
 if operation=='cancel':p.call(7,*f)
 else:p.call(22 if operation=='result'else 23,*f,value=env,kind=1)
 assert events==['user-after-actual-notify']and not errors,errors
 got,r,_=a.next(it);assert o.u(p.call(21,*got),96)==identity
 got,r,_=a.next(it);assert got is None
 a.finish();p.finish();v.finish()
 rows.append({'case':'actual-notify-precedes-user-'+operation,'passed':True})
report={'passed':True,'rows':rows,'count':len(rows),'observer_calls':o.calls,'public_calls':h.calls,'public_sha256':h.pin,'observer_sha256':o.meta['flat_sha256'],'oracle':'Python3.14 original OptimizationFuture plus concurrent.futures.wait','whole_public_future_closed':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('INHERITED_WAITERS_PASS',len(rows),o.calls,h.calls,flush=True)

