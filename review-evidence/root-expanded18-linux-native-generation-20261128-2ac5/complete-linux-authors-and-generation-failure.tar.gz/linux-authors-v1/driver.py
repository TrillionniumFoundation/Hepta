from pathlib import Path
import sys,json,hashlib,subprocess,time,traceback,os,signal
base=Path('/home/qq/hia-kernel-expanded18-union-20261128-2ac5');base.mkdir(mode=0o700,exist_ok=False)
out=base/'linux-authors-v1';out.mkdir(mode=0o700);(out/'driver.py').write_text(sys.argv[1])
existing=Path('/home/qq/hia-final-native-cold-20261128-2ac5/source');source=base/'source';head='d5f853cabeb7bed4102e2033415e699e8c100d4f'
rows=[];start=time.monotonic()
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C')
def run(label,args,cwd,timeout):
 tick=time.monotonic();p=subprocess.Popen(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:stdout,stderr=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=10)
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
  raise
 (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
 row={'label':label,'argv':args,'returncode':p.returncode,'seconds':time.monotonic()-tick};rows.append(row);(out/'progress.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode:print(stdout.decode(errors='replace')[-4000:]+stderr.decode(errors='replace')[-4000:],flush=True)
 assert p.returncode==0,label
 return stdout
def git(*args):return subprocess.check_output(['git','-C',str(existing),*args])
def dirty_pins():
 names=sorted(set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines()))
 return {n:{'bytes':(existing/n).stat().st_size,'sha256':hashlib.sha256((existing/n).read_bytes()).hexdigest(),'mode':(existing/n).stat().st_mode&0o777} for n in names}
before_dirty=dirty_pins();before_head=git('rev-parse','HEAD').decode().strip();before_status=git('status','--porcelain=v1')
(out/'existing-preservation-before.json').write_text(json.dumps({'head':before_head,'status':before_status.decode(),'files':before_dirty},sort_keys=True,indent=2)+'\n')
try:
 common=Path(git('rev-parse','--git-common-dir').decode().strip())
 if not common.is_absolute():common=existing/common
 assert not (common/'objects/info/alternates').exists()
 run('normal-fetch',['git','-c','core.alternateRefsCommand=/usr/bin/true','fetch','--no-tags','https://github.com/TrillionniumFoundation/Hepta.git',head],existing,300)
 run('isolated-worktree',['git','worktree','add','--detach',str(source),head],existing,120)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
 assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=source)==b''
 protected={'tools/hia_frozen_component_sources.py':'60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774','tools/hia_evaluation_window_history.py':'08054cf59af6e93453fc370d08c64d1b14e9072012f69652cfae747083346cfa','hepta/hia_program_runtime.py':'76f184195ffc37dab2e327a2170e0999aa51349b9e1f62475084719d675686f4'}
 for n,h in protected.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h
 (out/'initial-tree.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source))
 for name,args in [
 ('release-owner',['-m','tools.generate_hia_release_owner']),
 ('native-controller',['-m','tools.generate_hia_native_controller_release']),
 ('native-worker',['-m','tools.generate_hia_native_worker_sources','--native-source-authority',str(source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json')]),
 ('worker-compat',['-m','tools.generate_hia_worker_compat_release'])]:
  run(name,[sys.executable,'-B',*args],source,180)
 for n,h in protected.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h
 changed=subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines()
 generated={n:{'bytes':(source/n).stat().st_size,'sha256':hashlib.sha256((source/n).read_bytes()).hexdigest(),'mode':(source/n).stat().st_mode&0o777} for n in changed}
 for n in changed:
  p=out/'generated'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((source/n).read_bytes());p.chmod((source/n).stat().st_mode&0o777)
 assert before_dirty==dirty_pins() and before_status==git('status','--porcelain=v1') and before_head==git('rev-parse','HEAD').decode().strip()
 report={'status':'ALL_FOUR_LINUX_AUTHORS_COMPLETED','head':head,'source':str(source),'seconds':time.monotonic()-start,'rows':rows,'generated':generated,'frozen_sources_unchanged':True,'existing_worktree_preserved':True,'whole_cold_qualified':False}
except BaseException as e:
 report={'status':'FAILED','rows':rows,'seconds':time.monotonic()-start,'error':repr(e),'traceback':traceback.format_exc(),'whole_cold_qualified':False}
 (out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True);raise
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='generated'},sort_keys=True),flush=True)
