from pathlib import Path
import sys,json,hashlib,subprocess,time,traceback,os,signal
base=Path('/home/qq/hia-kernel-expanded18-union-20261128-2ac5');assert base.is_dir()
out=base/'linux-authors-v4';out.mkdir(mode=0o700);(out/'driver.py').write_text(sys.argv[1])
(out/'previous-syntax-failure-driver.py.txt').write_text(sys.argv[2]);(out/'previous-syntax-failure.json').write_text(sys.argv[3])
existing=Path('/home/qq/hia-final-native-cold-20261128-2ac5/source');source=base/'source';head='d5f853cabeb7bed4102e2033415e699e8c100d4f'
rows=[];start=time.monotonic()
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C')
def run(label,args,cwd,timeout):
 tick=time.monotonic();p=subprocess.Popen(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:stdout,stderr=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=10)
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
  raise
 (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
 row={'label':label,'argv':args,'returncode':p.returncode,'seconds':time.monotonic()-tick};rows.append(row);(out/'progress.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode:print(stdout.decode(errors='replace')[-4000:]+stderr.decode(errors='replace')[-4000:],flush=True)
 assert p.returncode==0,label
 return stdout
def git(*args):return subprocess.check_output(['git','-C',str(existing),*args])
def dirty_pins():
 names=sorted(set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines()))
 return {n:{'bytes':(existing/n).stat().st_size,'sha256':hashlib.sha256((existing/n).read_bytes()).hexdigest(),'mode':(existing/n).stat().st_mode&0o777} for n in names}
before_dirty=dirty_pins();before_head=git('rev-parse','HEAD').decode().strip();before_status=git('status','--porcelain=v1')
(out/'existing-preservation-before.json').write_text(json.dumps({'head':before_head,'status':before_status.decode(),'files':before_dirty},sort_keys=True,indent=2)+'\n')
try:
 common=Path(git('rev-parse','--git-common-dir').decode().strip())
 if not common.is_absolute():common=existing/common
 assert not (common/'objects/info/alternates').exists()
 prior=json.loads((base/'linux-authors-v1/terminal.json').read_bytes());assert prior['status']=='FAILED' and 'TimeoutExpired' in prior['error']
 old_preservation=json.loads((base/'linux-authors-v1/existing-preservation-before.json').read_bytes())
 assert before_dirty==old_preservation['files'] and before_head==old_preservation['head'] and before_status.decode()==old_preservation['status']
 bundle=base/'expanded18.git.bundle';assert bundle.stat().st_size==243560589 and hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest()=='ca4ceaa1875a4730da8cee55fc25fbcf3b5094b32ee84d589aa7e0280f7731ff'
 missing=json.loads((base/'linux-authors-v3/terminal.json').read_bytes());assert missing['status']=='FAILED' and missing['rows'][0]['label']=='verify-explicit-base-bundle'
 complete=base/'complete-object-pack-fb879358a6837b55c85b2dc0ff684d5e0e968898.pack'
 assert complete.stat().st_size==8003104878 and hashlib.file_digest(complete.open('rb'),'sha256').hexdigest()=='52a598ea3a8040752357ff2253958910fd697e759bbf29b9b5419f1a12d87256'
 tick=time.monotonic()
 with complete.open('rb')as si,(out/'index-owned-complete-pack.stdout').open('xb')as so,(out/'index-owned-complete-pack.stderr').open('xb')as se:
  proc=subprocess.Popen(['git','-c','gc.auto=0','index-pack','--stdin','--strict','--threads=2','--keep=hia-expanded18-source-closure-20261128-2ac5'],cwd=existing,env=env,stdin=si,stdout=so,stderr=se,start_new_session=True)
  try:proc.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10);raise
 row={'label':'index-owned-complete-pack','returncode':proc.returncode,'seconds':time.monotonic()-tick};rows.append(row);print(json.dumps(row),flush=True);assert proc.returncode==0
 retained=common/'objects/pack/pack-fb879358a6837b55c85b2dc0ff684d5e0e968898.pack'
 assert retained.stat().st_size==complete.stat().st_size and hashlib.file_digest(retained.open('rb'),'sha256').hexdigest()=='52a598ea3a8040752357ff2253958910fd697e759bbf29b9b5419f1a12d87256'
 (out/'complete-object-pack-readback.json').write_text(json.dumps({'source':str(complete),'retained':str(retained),'bytes':retained.stat().st_size,'sha256':'52a598ea3a8040752357ff2253958910fd697e759bbf29b9b5419f1a12d87256','strict_index_pack':True},sort_keys=True,indent=2)+'\n')
 run('verify-explicit-base-bundle',['git','bundle','verify',str(bundle)],existing,120)
 run('normal-bundle-fetch',['git','-c','core.alternateRefsCommand=/usr/bin/true','fetch','--no-tags',str(bundle),'refs/heads/codex/hia-native-caller-selection-20261127-2ac5'],existing,300)
 run('isolated-worktree',['git','worktree','add','--detach',str(source),head],existing,120)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
 assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=source)==b''
 protected={'tools/hia_frozen_component_sources.py':'60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774','tools/hia_evaluation_window_history.py':'08054cf59af6e93453fc370d08c64d1b14e9072012f69652cfae747083346cfa','hepta/hia_program_runtime.py':'76f184195ffc37dab2e327a2170e0999aa51349b9e1f62475084719d675686f4'}
 for n,h in protected.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h
 (out/'initial-tree.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source))
 for name,args in [
 ('release-owner',['-m','tools.generate_hia_release_owner']),
 ('native-controller',['-m','tools.generate_hia_native_controller_release']),
 ('native-worker',['-m','tools.generate_hia_native_worker_sources','--native-source-authority',str(source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json')]),
 ('worker-compat',['-m','tools.generate_hia_worker_compat_release'])]:
  run(name,[sys.executable,'-B',*args],source,180)
 for n,h in protected.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h
 changed=subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines()
 generated={n:{'bytes':(source/n).stat().st_size,'sha256':hashlib.sha256((source/n).read_bytes()).hexdigest(),'mode':(source/n).stat().st_mode&0o777} for n in changed}
 for n in changed:
  p=out/'generated'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((source/n).read_bytes());p.chmod((source/n).stat().st_mode&0o777)
 assert before_dirty==dirty_pins() and before_status==git('status','--porcelain=v1') and before_head==git('rev-parse','HEAD').decode().strip()
 generation={'status':'ALL_FOUR_LINUX_AUTHORS_COMPLETED','head':head,'generated':generated,'rows':list(rows),'whole_cold_qualified':False}
 (out/'generation.json').write_text(json.dumps(generation,sort_keys=True,indent=2)+'\n')
 python=Path('/home/qq/hia-final-native-cold-20261128-2ac5/original393-qa-prerequisites-v1/venv/bin/python')
 probe=run('original-qa-prerequisites',[str(python),'-B','-c','import z3,jsonschema,sys,json;print(json.dumps(dict(executable=sys.executable,z3=z3.get_version_string())))'],source,30);assert json.loads(probe)['z3']=='4.15.4'
 env={k:v for k,v in env.items()if not k.startswith('HEPTA_HIA_')and k not in('PYTHONPATH','PYTHONHOME')};env.update(PYTHONNOUSERSITE='1',GIT_NO_LAZY_FETCH='1')
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=source).decode().split('\0');paths=[n for n in paths if n]
 def physical_pins():
  answer={}
  for n in paths:
   p=source/n;s=p.lstat();assert p.is_file() and not p.is_symlink() and s.st_nlink==1,n
   answer[n]={'bytes':s.st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'mode':s.st_mode&0o777}
  return answer
 physical=physical_pins();(out/'complete-physical-source-before.json').write_text(json.dumps(physical,sort_keys=True,indent=2)+'\n')
 history=base/'original393-expanded18-v1'
 run('original393-explicit-history',[str(python),'-B','tools/qualify_hia_current_source_generation.py','--source',str(source),'--output',str(history),'--python',str(python)],source,1200)
 historic=json.loads((history/'result.json').read_bytes());assert historic['passed']is True and historic['reported_tests']==393 and historic['timed_out']is False and historic['all_original_test_modules_byte_identical']is True
 import re
 run('current10-physical-source',[str(python),'-B','-m','unittest','-v','tests.test_hia_current_source_generation'],source,120)
 stderr=(out/'current10-physical-source.stderr').read_bytes();assert re.search(rb'^Ran 10 tests in [0-9.]+s$',stderr,re.M)and re.search(rb'^OK$',stderr,re.M)
 run('current47-dispatch-and-owned-children',[str(python),'-B','-m','unittest','-v','tests.test_hia_program_runtime_dispatch','tests.test_hia_bootstrap_case_terminal'],source,120)
 stderr=(out/'current47-dispatch-and-owned-children.stderr').read_bytes();assert re.search(rb'^Ran 47 tests in [0-9.]+s$',stderr,re.M)and re.search(rb'^OK$',stderr,re.M)
 after=physical_pins();(out/'complete-physical-source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');assert after==physical
 assert before_dirty==dirty_pins() and before_status==git('status','--porcelain=v1') and before_head==git('rev-parse','HEAD').decode().strip()
 report={'status':'ALL_FOUR_AUTHORS_AND_393_HISTORY_10_CURRENT_47_LINUX_CONTROLS_PASS','head':head,'source':str(source),'seconds':time.monotonic()-start,'rows':rows,'generated':generated,'physical_source_files':len(physical),'historical_tests':393,'actual_current_tests':57,'current_linux_tests_skipped':0,'frozen_sources_unchanged':True,'existing_worktree_preserved':True,'whole_cold_qualified':False}
except BaseException as e:
 report={'status':'FAILED','rows':rows,'seconds':time.monotonic()-start,'error':repr(e),'traceback':traceback.format_exc(),'whole_cold_qualified':False}
 (out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True);raise
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='generated'},sort_keys=True),flush=True)
