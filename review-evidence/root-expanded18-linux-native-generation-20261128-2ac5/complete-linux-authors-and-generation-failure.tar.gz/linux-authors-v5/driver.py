from pathlib import Path
import sys,json,hashlib,subprocess,time,traceback,os,signal,stat
os.umask(0o022)
base=Path('/home/qq/hia-kernel-expanded18-union-20261128-2ac5');source=base/'source';out=base/'linux-authors-v5';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
existing=Path('/home/qq/hia-final-native-cold-20261128-2ac5/source');head='d5f853cabeb7bed4102e2033415e699e8c100d4f'
rows=[];start=time.monotonic();env=dict(os.environ,GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C')
def run(label,args,cwd,timeout):
 tick=time.monotonic();p=subprocess.Popen(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:stdout,stderr=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=10);(out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr);raise
 (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
 row={'label':label,'argv':args,'returncode':p.returncode,'seconds':time.monotonic()-tick};rows.append(row);(out/'progress.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode:print(stdout.decode(errors='replace')[-4000:]+stderr.decode(errors='replace')[-4000:],flush=True)
 assert p.returncode==0,label
 return stdout
def git(*args):return subprocess.check_output(['git','-C',str(existing),*args])
def dirty_pins():
 names=sorted(set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines()))
 return {n:{'bytes':(existing/n).stat().st_size,'sha256':hashlib.sha256((existing/n).read_bytes()).hexdigest(),'mode':(existing/n).stat().st_mode&0o777} for n in names}
preserved=json.loads((base/'linux-authors-v1/existing-preservation-before.json').read_bytes());before_dirty=preserved['files'];before_head=preserved['head'];before_status=preserved['status'].encode()
try:
 assert dirty_pins()==before_dirty and git('rev-parse','HEAD').decode().strip()==before_head and git('status','--porcelain=v1')==before_status
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
 prior=json.loads((base/'linux-authors-v4/terminal.json').read_bytes());assert prior['status']=='FAILED' and prior['rows'][-1]['label']=='native-worker'
 prefix=[r for r in prior['rows']if r['label']in ['release-owner','native-controller']]
 assert len(prefix)==2 and all(r['returncode']==0 for r in prefix)
 (out/'completed-original-author-prefix.json').write_text(json.dumps(prefix,sort_keys=True,indent=2)+'\n')
 changed_before=subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines()
 prefix_pins={}
 for n in changed_before:
  p=source/n;raw=p.read_bytes();prefix_pins[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':p.stat().st_mode&0o777};target=out/'failed-attempt-complete-prefix'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 (out/'failed-attempt-prefix-pins.json').write_text(json.dumps(prefix_pins,sort_keys=True,indent=2)+'\n')
 correction=[]
 for row in subprocess.check_output(['git','ls-files','-s','-z'],cwd=source).decode().split('\0'):
  if not row:continue
  details,n=row.split('\t',1);mode,oid,stage=details.split();assert stage=='0'and mode in ['100644','100755']
  p=source/n;s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and not p.is_symlink()
  expected=0o755 if mode=='100755'else 0o644;before_hash=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
  if s.st_mode&0o777!=expected:
   p.chmod(expected);assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==before_hash
   correction.append({'path':n,'before_mode':s.st_mode&0o777,'after_mode':expected,'sha256':before_hash})
 (out/'git-checkout-mode-correction.json').write_text(json.dumps({'reason':'Operator daemon umask 077 produced mode0600/0700; restore exact regular Git checkout 0644/0755 expected by the unchanged custody rule. All bytes remain identical.','files':correction,'source_rules_changed':False},sort_keys=True,indent=2)+'\n')
 protected={'tools/hia_frozen_component_sources.py':'60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774','tools/hia_evaluation_window_history.py':'08054cf59af6e93453fc370d08c64d1b14e9072012f69652cfae747083346cfa','hepta/hia_program_runtime.py':'76f184195ffc37dab2e327a2170e0999aa51349b9e1f62475084719d675686f4'}
 for n,h in protected.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h
 run('native-worker',[sys.executable,'-B','-m','tools.generate_hia_native_worker_sources','--native-source-authority',str(source/'docs/HIA_NATIVE_SOURCE_AUTHORITY.json')],source,180)
 run('worker-compat',[sys.executable,'-B','-m','tools.generate_hia_worker_compat_release'],source,180)
 for n,h in protected.items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h
 generated={}
 for n in subprocess.check_output(['git','diff','--name-only'],cwd=source,text=True).splitlines():
  p=source/n;raw=p.read_bytes();generated[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':p.stat().st_mode&0o777};target=out/'generated'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);target.chmod(p.stat().st_mode&0o777)
 generation={'status':'ALL_FOUR_LINUX_AUTHORS_COMPLETED','head':head,'generated':generated,'rows':list(rows),'whole_cold_qualified':False}
 (out/'generation.json').write_text(json.dumps(generation,sort_keys=True,indent=2)+'\n')
 python=Path('/home/qq/hia-final-native-cold-20261128-2ac5/original393-qa-prerequisites-v1/venv/bin/python')
 probe=run('original-qa-prerequisites',[str(python),'-B','-c','import z3,jsonschema,sys,json;print(json.dumps(dict(executable=sys.executable,z3=z3.get_version_string())))'],source,30);assert json.loads(probe)['z3']=='4.15.4'
 env={k:v for k,v in env.items()if not k.startswith('HEPTA_HIA_')and k not in('PYTHONPATH','PYTHONHOME')};env.update(PYTHONNOUSERSITE='1',GIT_NO_LAZY_FETCH='1')
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=source).decode().split('\0');paths=[n for n in paths if n]
 def physical_pins():
  answer={}
  for n in paths:
   p=source/n;s=p.lstat();assert p.is_file() and not p.is_symlink() and s.st_nlink==1,n
   answer[n]={'bytes':s.st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'mode':s.st_mode&0o777}
  return answer
 physical=physical_pins();(out/'complete-physical-source-before.json').write_text(json.dumps(physical,sort_keys=True,indent=2)+'\n')
 history=base/'original393-expanded18-v1'
 run('original393-explicit-history',[str(python),'-B','tools/qualify_hia_current_source_generation.py','--source',str(source),'--output',str(history),'--python',str(python)],source,1200)
 historic=json.loads((history/'result.json').read_bytes());assert historic['passed']is True and historic['reported_tests']==393 and historic['timed_out']is False and historic['all_original_test_modules_byte_identical']is True
 import re
 run('current10-physical-source',[str(python),'-B','-m','unittest','-v','tests.test_hia_current_source_generation'],source,120)
 stderr=(out/'current10-physical-source.stderr').read_bytes();assert re.search(rb'^Ran 10 tests in [0-9.]+s$',stderr,re.M)and re.search(rb'^OK$',stderr,re.M)
 run('current47-dispatch-and-owned-children',[str(python),'-B','-m','unittest','-v','tests.test_hia_program_runtime_dispatch','tests.test_hia_bootstrap_case_terminal'],source,120)
 stderr=(out/'current47-dispatch-and-owned-children.stderr').read_bytes();assert re.search(rb'^Ran 47 tests in [0-9.]+s$',stderr,re.M)and re.search(rb'^OK$',stderr,re.M)
 after=physical_pins();(out/'complete-physical-source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');assert after==physical
 assert before_dirty==dirty_pins() and before_status==git('status','--porcelain=v1') and before_head==git('rev-parse','HEAD').decode().strip()
 report={'status':'ALL_FOUR_AUTHORS_AND_393_HISTORY_10_CURRENT_47_LINUX_CONTROLS_PASS','head':head,'source':str(source),'seconds':time.monotonic()-start,'rows':rows,'generated':generated,'physical_source_files':len(physical),'historical_tests':393,'actual_current_tests':57,'current_linux_tests_skipped':0,'frozen_sources_unchanged':True,'existing_worktree_preserved':True,'whole_cold_qualified':False}
except BaseException as e:
 report={'status':'FAILED','rows':rows,'seconds':time.monotonic()-start,'error':repr(e),'traceback':traceback.format_exc(),'whole_cold_qualified':False}
 (out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True);raise
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='generated'},sort_keys=True),flush=True)
