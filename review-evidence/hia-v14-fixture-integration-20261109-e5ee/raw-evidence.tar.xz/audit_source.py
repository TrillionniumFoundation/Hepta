"""Read-only byte provenance for the complete 2aa + 635 source integration."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OURS = '2aa206882c7d6298d74ddc1ddf3a4ccb052e41a6'
THEIRS = '635c57bd7fd0b9f37480b4da091af4dddfd53a36'
EXPECTED_TREE = '9ff1b36fb59858145e0d46010289a15fb91a3437'
FIXTURES = {
    'tests/test_core_seven_part04_capture.py',
    'tests/test_core_seven_relocation_runner.py',
    'tests/test_core_seven_relocation_timeout.py',
}
OURS_ONLY = {
    'docs/HIA_PART04_FIXTURE_INTEGRATION_20261109.md',
    'review-evidence/hia-part04-fixture-integration-20261109-e5ee/README.md',
    'review-evidence/hia-part04-fixture-integration-20261109-e5ee/archive-manifest.json',
    'review-evidence/hia-part04-fixture-integration-20261109-e5ee/raw-evidence.tar.xz',
    'review-evidence/hia-part04-fixture-integration-20261109-e5ee/validation.json',
}
OURS_PREFERRED = {
    '.github/workflows/hia-initialization-frontier-research.yml',
    'docs/seven-part04-diagnostic.md',
}
PRODUCTION = (
    'tools/core_seven_part04_capture.py',
    'tools/diagnose_core_seven_part04.py',
    'tools/diagnose_core_seven_relocation.py',
)

def git(*args):
    return subprocess.check_output(['git', *args])

def tree(ref):
    values = {}
    for entry in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not entry:
            continue
        info, path = entry.split(b'\t', 1)
        mode, kind, blob = info.decode().split()
        values[path.decode()] = {'mode': mode, 'type': kind, 'git_blob': blob}
    return values

current_tree = git('write-tree').decode().strip()
assert current_tree == EXPECTED_TREE
assert git('diff', '--name-only') == b''
assert git('rev-parse', 'HEAD').decode().strip() == OURS
assert git('rev-parse', 'MERGE_HEAD').decode().strip() == THEIRS
ours, theirs, current = tree(OURS), tree(THEIRS), tree(current_tree)
assert set(current) == set(ours) | set(theirs)
assert set(ours) - set(theirs) == OURS_ONLY
for path, entry in current.items():
    if path in FIXTURES:
        assert entry != ours[path] and entry != theirs[path], path
    elif path in OURS_ONLY | OURS_PREFERRED:
        assert entry == ours[path], path
    else:
        assert entry == theirs[path], path

def identity(path, entry):
    raw = git('cat-file', 'blob', entry['git_blob'])
    return dict(path=path, **entry, sha256=sha256(raw).hexdigest(), bytes=len(raw))

changed = []
for path in sorted(current):
    if current[path] == ours.get(path):
        continue
    row = identity(path, current[path])
    row.update(status='M' if path in ours else 'A',
               provenance='integration_fixture' if path in FIXTURES else 'unchanged_819_blob',
               prior_2aa_blob=ours.get(path, {}).get('git_blob'),
               parent_819_blob=theirs.get(path, {}).get('git_blob'))
    if path in FIXTURES:
        row['local_file'] = str(Path(path).resolve())
        assert sha256(Path(path).read_bytes()).hexdigest() == row['sha256']
    changed.append(row)

preserved = []
for path in sorted(OURS_ONLY | OURS_PREFERRED):
    preserved.append(identity(path, current[path]))
for path in sorted(p for p in theirs if p.startswith('review-evidence/part04-descendant-exit-20261108/')):
    preserved.append(identity(path, current[path]))
production = []
for path in PRODUCTION:
    assert ours[path] == theirs[path] == current[path]
    production.append(identity(path, current[path]))
report = {
    'schema': 'hepta.v14-fixture-integration-source-provenance.v1',
    'status': 'PASS',
    'parents_in_order': [OURS, THEIRS],
    'parent_trees': {OURS: git('rev-parse', OURS + '^{tree}').decode().strip(),
                     THEIRS: git('rev-parse', THEIRS + '^{tree}').decode().strip()},
    'source_tree_before_new_reports': current_tree,
    'full_parent_path_union_preserved': True,
    'only_new_source_blobs': sorted(FIXTURES),
    'unchanged_2aa_choices': sorted(OURS_PREFERRED),
    'unchanged_2aa_unique_evidence': sorted(OURS_ONLY),
    'changed_paths_relative_2aa': changed,
    'preserved_historical_evidence_and_guards': preserved,
    'production_collector_and_readers_unchanged': production,
    'test_methods_executed_by_this_audit': 0,
}
(ROOT/'source-provenance.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'source_tree': current_tree,
                  'changed_paths': len(changed), 'new_source_blobs': len(FIXTURES),
                  'unchanged_819_blobs': sum(r['provenance'] == 'unchanged_819_blob' for r in changed),
                  'preserved_historical_and_guards': len(preserved),
                  'production': production}, indent=2))
