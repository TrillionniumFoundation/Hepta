"""Injected /proc observations around one real owned Python child.

These controls do not claim actual PID reuse or a kernel-race reproduction.
The collector still supplies the real fixture's PID, start time and receipts.
"""
from contextlib import ExitStack
from hashlib import sha256
import json
from pathlib import Path
import time
import unittest
from unittest.mock import patch
from tests import test_core_seven_part04_capture as harness

ROOT = Path(__file__).resolve().parent
METHOD = 'test_held_descendant_descriptors_are_killed_after_leader_exits'
SCENARIOS = (
    ('replaced_identity_different_group', None),
    ('same_identity_different_group', 'descendant process group changed'),
    ('same_identity_persistent_running', 'descendant exit observation exceeded the original total deadline'),
    ('late_replaced_identity', 'descendant exit observation exceeded the original total deadline'),
)
SOURCE = Path('tests/test_core_seven_part04_capture.py')
before = sha256(SOURCE.read_bytes()).hexdigest()
records = []
for scenario, rejection in SCENARIOS:
    target = ROOT / ('identity-' + scenario)
    target.mkdir(exist_ok=False)
    case = harness.Part04CaptureTests(METHOD)
    real_run_child, real_read_text = case.run_child, Path.read_text
    samples = []
    started = time.monotonic()
    print(json.dumps({'scenario': scenario, 'injected_observations': True}), flush=True)
    with ExitStack() as stack:
        def run_child(*args, **kwargs):
            result, files, launches = real_run_child(*args, **kwargs)
            (target/'capture-result.json').write_text(json.dumps(result, indent=2) + '\n')
            for name, data in files.items():
                (target/name).write_bytes(data)
            child, birth = files[harness.capture.DIAGNOSTIC_FILES[0]].strip().decode().split()
            identity = Path('/proc') / child / 'stat'
            def read_text(path, *read_args, **read_kwargs):
                if path != identity:
                    return real_read_text(path, *read_args, **read_kwargs)
                try:
                    actual = real_read_text(path, *read_args, **read_kwargs)
                except FileNotFoundError:
                    actual = None
                replaced = scenario in ('replaced_identity_different_group', 'late_replaced_identity')
                group = result['pid'] + 100000 if 'different_group' in scenario else result['pid']
                observed_birth = str(int(birth) + 1) if replaced else birth
                fields = ['0'] * 20
                fields[0], fields[2], fields[19] = 'R', str(group), observed_birth
                # Parse from the final ')' even when the injected comm has one.
                delivered = child + ' (injected fixture) name) ' + ' '.join(fields) + '\n'
                delay = 1.51 if scenario == 'late_replaced_identity' else 0
                if delay:
                    time.sleep(delay)
                samples.append({
                    'call': len(samples) + 1, 'elapsed_seconds': time.monotonic() - started,
                    'real_child_pid': int(child), 'real_child_starttime': birth,
                    'real_process_group': result['pid'],
                    'actual_raw_before_injected_observation': actual,
                    'injected_raw_observation': delivered,
                    'injected_observation_delay_seconds': delay,
                })
                return delivered
            stack.enter_context(patch.object(Path, 'read_text', read_text))
            return result, files, launches
        case.run_child = run_child
        result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
    correctly_rejected = (len(result.failures) == 1 and not result.errors and
                          rejection is not None and rejection in result.failures[0][1])
    expected = correctly_rejected if rejection else result.wasSuccessful()
    valid = (expected and result.testsRun == 1 and not result.skipped and
             not result.expectedFailures and not result.unexpectedSuccesses)
    record = {
        'scenario': scenario, 'injected_observations': True,
        'actual_pid_reuse_reproduced': False, 'expected_rejection': rejection,
        'method_tests_run': result.testsRun,
        'failures': [(test.id(), detail) for test, detail in result.failures],
        'errors': [(test.id(), detail) for test, detail in result.errors],
        'skips': [(test.id(), reason) for test, reason in result.skipped],
        'elapsed_seconds': time.monotonic() - started,
        'observations': samples, 'control_status': 'PASS' if valid else 'FAIL',
    }
    (target/'observation.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(json.dumps({k: record[k] for k in ('scenario', 'expected_rejection', 'control_status', 'elapsed_seconds')}), flush=True)
after = sha256(SOURCE.read_bytes()).hexdigest()
summary = {
    'schema': 'hepta.v14-identity-observation-controls.v1',
    'method': 'tests.test_core_seven_part04_capture.Part04CaptureTests.' + METHOD,
    'same_method_invocations': 4, 'positive_scenarios': 1, 'expected_rejection_scenarios': 3,
    'actual_pid_reuse_or_kernel_race_reproduced': False,
    'original_total_test_deadline_seconds': 1.5,
    'source_sha256_before': before, 'source_sha256_after': after,
    'scenarios': records,
    'status': 'PASS' if before == after and all(r['control_status'] == 'PASS' for r in records) else 'FAIL',
}
(ROOT/'identity-controls.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'scenarios'}), flush=True)
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
