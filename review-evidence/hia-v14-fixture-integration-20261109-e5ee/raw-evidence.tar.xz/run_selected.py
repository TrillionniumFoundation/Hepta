"""Narrow harmless Python fixture validation for the 2aa + 635 integration."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import time
import unittest

ROOT = Path(__file__).resolve().parent
NAMES = [
    'tests.test_core_seven_part04_capture.Part04CaptureTests.test_held_descendant_descriptors_are_killed_after_leader_exits',
    'tests.test_core_seven_relocation_timeout.RelocationTimeoutTests.test_short_transient_cleanup_delay_keeps_real_two_second_budget',
    'tests.test_core_seven_relocation_timeout.RelocationTimeoutTests.test_cleanup_delay_over_two_seconds_still_fails',
    'tests.test_core_seven_relocation_timeout.RelocationTimeoutTests.test_preoutput_timeout_replays_empty_prefix_without_inventing_markers',
    'tests.test_core_seven_relocation_runner.Part04RunnerTests.test_complete_failure_replay_and_spawn_semantics',
    'tests.test_core_seven_relocation_runner.Part04RunnerTests.test_timeout_replay_waits_for_delayed_child_markers',
    'tests.test_core_seven_relocation_runner.Part04ReplayGrammarTests.test_fixture_timeout_clock_requires_all_persisted_markers',
    'tests.test_core_seven_relocation_runner.Part04ReplayGrammarTests.test_fixture_missing_marker_has_finite_readiness_deadline',
]
PATHS = [
    'tests/test_core_seven_part04_capture.py',
    'tests/test_core_seven_relocation_runner.py',
    'tests/test_core_seven_relocation_timeout.py',
    'tools/core_seven_part04_capture.py',
    'tools/diagnose_core_seven_part04.py',
    'tools/diagnose_core_seven_relocation.py',
    '.github/workflows/hia-initialization-frontier-research.yml',
]

def source():
    return {path: sha256(Path(path).read_bytes()).hexdigest() for path in PATHS}

class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.subtests = []

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        record = {'id': subtest.id(), 'status': 'PASS' if err is None else 'FAIL'}
        self.subtests.append(record)
        print(json.dumps({'subtest': record}), flush=True)

before = source()
prepared_tree = subprocess.check_output(['git', 'write-tree'], text=True).strip()
started = time.monotonic()
suite = unittest.defaultTestLoader.loadTestsFromNames(NAMES)
assert suite.countTestCases() == 8
result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
elapsed = time.monotonic() - started
after = source()
valid = (result.wasSuccessful() and result.testsRun == 8 and not result.skipped
         and not result.expectedFailures and not result.unexpectedSuccesses and before == after)
report = {
    'schema': 'hepta.v14-fixture-integration-tests.v1',
    'status': 'PASS' if valid else 'FAIL',
    'prepared_source_tree_before_report_files': prepared_tree,
    'parents': ['2aa206882c7d6298d74ddc1ddf3a4ccb052e41a6',
                '635c57bd7fd0b9f37480b4da091af4dddfd53a36'],
    'method_ids': NAMES,
    'methods_run': result.testsRun,
    'failures': [(test.id(), detail) for test, detail in result.failures],
    'errors': [(test.id(), detail) for test, detail in result.errors],
    'skips': [(test.id(), detail) for test, detail in result.skipped],
    'expected_failures': [(test.id(), detail) for test, detail in result.expectedFailures],
    'unexpected_successes': [test.id() for test in result.unexpectedSuccesses],
    'elapsed_seconds': elapsed,
    'subtests': result.subtests,
    'source_sha256_before': before,
    'source_sha256_after': after,
    'full_108_suite_rerun': False,
    'compiler_loader_solver_execution': False,
}
(ROOT/'selected-tests.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('subtests', 'source_sha256_before', 'source_sha256_after')}), flush=True)
raise SystemExit(0 if valid else 1)
