"""Read-only byte and arithmetic recheck of the two retained 14b CI artifacts."""
from hashlib import sha256
import json
from pathlib import Path
import zipfile

BASE = Path(__file__).resolve().parent
comparison = json.loads((BASE / "ci-comparison.json").read_text())
source_comparison = json.loads((BASE / "ci-source-byte-comparison.json").read_text())
archive_records = comparison["records"]
archives = []
summaries = []
for item in archive_records:
    path = BASE.parent / item["archive"]
    raw = path.read_bytes()
    assert len(raw) == item["archive_bytes"]
    assert sha256(raw).hexdigest() == item["archive_sha256"]
    archive = zipfile.ZipFile(path)
    archives.append(archive)
    receipts = []
    for row in item["selected_original_members"]:
        original = archive.read(row["archive_member"])
        retained = (BASE / "ci-receipts" / item["label"] / row["relative"]).read_bytes()
        assert original == retained
        assert len(original) == row["bytes"] and sha256(original).hexdigest() == row["sha256"]
        if row["relative"].endswith(".receipt.json"):
            receipt = json.loads(original)
            if "wall_elapsed_ns" in receipt:
                receipts.append(receipt)
    count = len(receipts)
    wall = sum(row["wall_elapsed_ns"] for row in receipts)
    native = sum(row.get("native_elapsed_ns", 0) for row in receipts)
    assert (count, wall, native) == (item["receipt_count_with_wall"], item["receipt_wall_sum_ns"],
                                    item["receipt_native_sum_ns"])
    summaries.append({"label": item["label"], "archive_sha256": item["archive_sha256"],
                      "selected_original_members_byte_equal": len(item["selected_original_members"]),
                      "receipts_with_wall": count, "wall_sum_ns": wall, "native_sum_ns": native})
for row in source_comparison["files"]:
    left, right = (archive.read(member) for archive, member in zip(archives, row["archive_members"]))
    assert left == right and row["byte_equal"] is True
    assert len(left) == row["bytes"] and sha256(left).hexdigest() == row["sha256"]
for archive in archives:
    archive.close()
result = {"schema": "hepta.selfhost.original-ci-evidence-recheck.v1", "status": "PASS",
          "base_commit": comparison["base_commit"], "archives": summaries,
          "source_files_compared_byte_for_byte": len(source_comparison["files"]),
          "source_content_bytes": sum(row["bytes"] for row in source_comparison["files"]),
          "scope": "Actual original ZIP members, selected retained bytes, and reported time sums; no rerun or inferred timeout cleanup."}
(BASE / "original-ci-evidence-recheck.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
print(json.dumps(result, sort_keys=True))
