"""Compare retained old CI inputs with a complete fresh qualification.

Directory spellings and elapsed clocks are not semantic inputs. Every ignored
field is listed in the output; image digests are retained as a separate exact
comparison because normal host linking can differ between Linux environments.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def records(directory, normalize):
    result = {}
    for path in directory.rglob("*.receipt.json"):
        receipt = read(path)
        if "wall_elapsed_ns" not in receipt:
            continue
        name = path.relative_to(directory).as_posix()
        if normalize and name.startswith("phase-runs/"):
            name = name.split("/", 2)[2]
        if name in result:
            raise AssertionError("duplicate logical native receipt: " + name)
        request_path = path.with_name(path.name.replace(".receipt.json", ".request.json"))
        result[name] = {"receipt": receipt, "request": read(request_path),
                        "receipt_path": str(path), "request_path": str(request_path),
                        "receipt_sha256": sha256(path.read_bytes()).hexdigest(),
                        "request_sha256": sha256(request_path.read_bytes()).hexdigest()}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--new-report", type=Path, required=True)
    parser.add_argument("--old-report", type=Path, required=True)
    parser.add_argument("--old-receipts", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    old_report, new_report = read(args.old_report), read(args.new_report)
    old = records(args.old_receipts, False)
    new = records(args.new_report.with_suffix(".evidence"), True)
    ignored_request_paths = {"image", "source", "output", "counters"}
    behavior_fields = ("status", "returncode", "abi_status", "core_u32", "result_u64", "return_encoding",
                       "input_sha256", "input_bytes", "source_sha256", "source_unchanged", "output_unchanged",
                       "output_sha256", "output_hex", "produced_bytes", "produced_sha256",
                       "workspace_header", "limits", "forbidden_compiler_modules_loaded")
    request_differences, image_differences, behavior_differences, rows = [], [], [], []
    for name in sorted(set(old) & set(new)):
        before, after = old[name], new[name]
        left = {k: v for k, v in before["request"].items() if k not in ignored_request_paths | {"image_sha256"}}
        right = {k: v for k, v in after["request"].items() if k not in ignored_request_paths | {"image_sha256"}}
        if left != right:
            request_differences.append({"case": name, "old": left, "new": right})
        if before["request"].get("image_sha256") != after["request"].get("image_sha256"):
            image_differences.append({"case": name, "old": before["request"].get("image_sha256"),
                                      "new": after["request"].get("image_sha256")})
        differences = {field: {"old": before["receipt"].get(field), "new": after["receipt"].get(field)}
                       for field in behavior_fields
                       if before["receipt"].get(field) != after["receipt"].get(field)}
        for key in ("allocator", "shared_output_observation"):
            left, right = before["receipt"].get(key), after["receipt"].get(key)
            if key == "allocator" and left is not None and right is not None:
                left = {k: v for k, v in left.items() if k != "counter_file_sha256"}
                right = {k: v for k, v in right.items() if k != "counter_file_sha256"}
            if left != right:
                differences[key] = {"old": left, "new": right}
        if differences:
            behavior_differences.append({"case": name, "fields": differences})
        rows.append({"logical_receipt": name,
                     "old_receipt_sha256": before["receipt_sha256"],
                     "new_receipt_sha256": after["receipt_sha256"],
                     "old_request_sha256": before["request_sha256"],
                     "new_request_sha256": after["request_sha256"]})
    scheduling = new_report["qualification_scheduling"]
    intervals = sorted((r[k], delta) for r in scheduling["phases"]
                       for k, delta in (("started_monotonic_ns", 1), ("completed_monotonic_ns", -1)))
    live = maximum = 0
    for _, delta in intervals:
        live += delta
        maximum = max(maximum, live)
        assert live >= 0
    checks = {"same_complete_check_map": old_report["checks"] == new_report["checks"],
              "all_1183_checks_pass": len(new_report["checks"]) == 1183 and all(new_report["checks"].values()),
              "same_1699_native_receipt_inventory": set(old) == set(new) and len(old) == 1699,
              "same_nonpath_request_inputs": not request_differences,
              "same_observed_behavior_fields": not behavior_differences,
              "same_compiler_source": old_report["source_sha256"] == new_report["source_sha256"],
              "same_B1_B2_B3_M1_M2_M3_images": all(
                  [r["produced_sha256"] for r in old_report[key]] == [r["produced_sha256"] for r in new_report[key]]
                  for key in ("generations", "modified_generations")),
              "twenty_phase_processes_all_exit_zero": len(scheduling["phases"]) == 20
                  and all(r["returncode"] == 0 for r in scheduling["phases"]),
              "no_more_than_two_host_oracle_workers": maximum <= 2 and live == 0}
    result = {"schema": "hepta.selfhost.qualification-scheduling-comparison.v1",
              "status": "PASS_SCOPED_INPUT_AND_BEHAVIOR_COMPARISON" if all(checks.values()) else "FAIL",
              "old_report": str(args.old_report), "old_report_sha256": sha256(args.old_report.read_bytes()).hexdigest(),
              "new_report": str(args.new_report), "new_report_sha256": sha256(args.new_report.read_bytes()).hexdigest(),
              "checks": checks, "old_native_receipts": len(old), "new_native_receipts": len(new),
              "missing_receipts": sorted(set(old) - set(new)), "additional_receipts": sorted(set(new) - set(old)),
              "request_path_fields_ignored": sorted(ignored_request_paths),
              "receipt_behavior_fields_compared": list(behavior_fields) + ["allocator excluding counter_file_sha256", "shared_output_observation"],
              "old_python_and_host_paths_and_elapsed_clocks_not_equaled": True,
              "old_wall_elapsed_ns": old_report["elapsed_ns"], "new_wall_elapsed_ns": new_report["elapsed_ns"],
              "maximum_observed_host_oracle_workers": maximum,
              "request_differences": request_differences, "native_image_identity_differences": image_differences,
              "behavior_differences": behavior_differences, "records": rows,
              "scope": "The same finite qualification subjects and observed results; no all-input equivalence or compiler speedup claim."}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"], "checks": checks, "image_differences": len(image_differences),
                      "behavior_differences": len(behavior_differences), "output": str(args.output)}, sort_keys=True))
    raise SystemExit(0 if all(checks.values()) else 1)


if __name__ == "__main__":
    main()
