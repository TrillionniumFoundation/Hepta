from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, platform, subprocess, sys, tempfile, time
base=Path('/workspace/scratch/728f6eb06ece')
meta=base/'entry-published-work'
out=Path(tempfile.mkdtemp(prefix='fresh-entry-resumed-',dir=base))
report={'schema':'hepta.hia.independent-entry-discovery.v1','agent':'fresh_entry_trial','execution_arrangement':'new Agent authored and assesses; root executor executes on its behalf','entry_commit':'93dbcc8872f3016dc1a106a3578f4b5772fa0192','expected_entry_tree':'f5bd21bc8957e8f1e8c4ce913bf9f6abe7ccb928','entry_url':'https://github.com/TrillionniumFoundation/Hepta/blob/93dbcc8872f3016dc1a106a3578f4b5772fa0192/INSTALL.md','metadata_root':str(meta),'evidence_root':str(out),'started_utc':datetime.now(timezone.utc).isoformat(),'commands':[],'fresh_network_installation':False,'native_execution_started':False,'prior_tool_failures':[{'cmd':'pwd','cwd':str(meta),'error':'No usable execution environment is available','session_id':None},{'cmd':'/bin/pwd','cwd':str(meta),'login':False,'error':'No usable execution environment is available','session_id':None},{'cmd':'/bin/pwd','cwd':'/','shell':'/bin/sh','login':False,'error':'No usable execution environment is available','session_id':None}]}
def ident(p):
 b=Path(p).read_bytes(); return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save():
 (out/'discovery.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
def run(name,argv,cwd=meta,timeout=60):
 r={'name':name,'argv':[str(a) for a in argv],'cwd':str(cwd),'started_utc':datetime.now(timezone.utc).isoformat(),'exit_code':None}
 report['commands'].append(r); save(); t=time.monotonic()
 try:
  with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
   p=subprocess.run(r['argv'],cwd=cwd,stdout=so,stderr=se,timeout=timeout)
  r['exit_code']=p.returncode
 except Exception as e:
  r['exception']={'type':type(e).__name__,'message':str(e)}
 finally:
  r['elapsed_seconds']=time.monotonic()-t
  for k in ('stdout','stderr'):
   p=out/(name+'.'+k);r[k]=ident(p) if p.exists() else None
  save()
 return r,(out/(name+'.stdout')).read_text(errors='replace') if (out/(name+'.stdout')).exists() else ''
print(json.dumps({'evidence_root':str(out),'status':'STARTED'}),flush=True)
try:
 report['platform']={'system':platform.system(),'machine':platform.machine(),'python':sys.version,'python_executable':sys.executable}
 names=[('metadata-head',['git','rev-parse','HEAD']),('metadata-head-tree',['git','rev-parse','HEAD^{tree}']),('metadata-index-tree',['git','write-tree']),('metadata-status',['git','status','--porcelain','--untracked-files=all']),('metadata-unstaged',['git','diff','--exit-code','--no-ext-diff'])]
 results={name:run(name,argv) for name,argv in names}
 report['metadata_identity']={name:{'exit_code':r['exit_code'],'stdout':s.strip()} for name,(r,s) in results.items()}
 expected={'INSTALL.md':'fa6b0e111d30ee6a6847c340605678e4ae74d0fa','tools/hia_entry_catalog.py':'b28ad70c22423e56de648eb1efb77f211561058e','tools/qualify_hia_entry_proof.py':'74b0bd0521a1904cdf197b32dd0f3c3521dc2f50'}
 report['entry_files']={}
 for name,blob in expected.items():
  b=(meta/name).read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();report['entry_files'][name]={**ident(meta/name),'expected_git_blob':blob,'actual_git_blob':actual,'matches':actual==blob}
 report['metadata_tree_equivalent']=results['metadata-index-tree'][0]['exit_code']==0 and results['metadata-index-tree'][1].strip()==report['expected_entry_tree'] and results['metadata-unstaged'][0]['exit_code']==0 and all(x['matches'] for x in report['entry_files'].values())
 report['metadata_checked_out_at_requested_commit']=results['metadata-head'][1].strip()==report['entry_commit']
 if not report['metadata_tree_equivalent']:
  raise RuntimeError('metadata byte/tree equivalence was not established; no program started')
 r,s=run('entry-catalog',[sys.executable,'-B','tools/hia_entry_catalog.py'])
 if r['exit_code']!=0: raise RuntimeError('entry catalog failed')
 report['catalog_selections']=[{'selection':e['selection'],'sources':e['sources'],'lock':e['lock'],'minimal_program':e['minimal_program'],'syntax':e['syntax']} for e in json.loads(s)['entries']]
 run('dependencies',[sys.executable,'-B','-E','-s','-c',"import importlib.metadata as m,json,sys; print(json.dumps({'python':sys.version,'jsonschema':m.version('jsonschema'),'z3-solver':m.version('z3-solver')}))"])
 r,s=run('repository-markers',['rg','--files','--hidden','--no-ignore','--maxdepth','4','-g','HEAD','-g','.git','-g','Cargo.toml','-g','!**/objects/**','-g','!**/logs/**',str(base)],base)
 candidates={meta,base/'entry-current-source',base/'entry-v16-source'}
 for line in s.splitlines():
  p=Path(line)
  if p.name=='HEAD' and p.parent.name=='.git': candidates.add(p.parent.parent)
  elif p.name=='.git': candidates.add(p.parent)
 for name in ('entry-current-source','entry-v16-source'):
  p=base/name
  report[name+'_top_level']=sorted(x.name for x in p.iterdir()) if p.exists() else None
  for child in ('hepta','runtime'):
   if (p/child/'.git').exists(): candidates.add(p/child)
 report['candidate_repositories']=[]
 for i,p in enumerate(sorted(candidates)):
  if not (p/'.git').exists(): continue
  r,s=run('repository-'+str(i)+'-identity',['git','-C',str(p),'rev-parse','HEAD','HEAD^{tree}'],base)
  report['candidate_repositories'].append({'path':str(p),'exit_code':r['exit_code'],'identity':s.splitlines()})
 report['status']='DISCOVERY_COMPLETE_NO_NATIVE_RUN'
except Exception as e:
 report['status']='DISCOVERY_FAILED';report['error']={'type':type(e).__name__,'message':str(e)}
finally:
 report['completed_utc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'evidence_root':str(out),'status':report['status'],'metadata_identity':report.get('metadata_identity'),'metadata_tree_equivalent':report.get('metadata_tree_equivalent'),'candidate_repositories':report.get('candidate_repositories'),'error':report.get('error')},indent=2),flush=True)
