from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/728f6eb06ece')
EVIDENCE = BASE / 'fresh-entry-resumed-5fzkdby0'
META = BASE / 'entry-published-work'
ROOT = EVIDENCE / 'execution-01'
ROOT.mkdir(exist_ok=False)
EXPECTED_COMMIT = '93dbcc8872f3016dc1a106a3578f4b5772fa0192'
EXPECTED_TREE = 'f5bd21bc8957e8f1e8c4ce913bf9f6abe7ccb928'
PROFILE = 'hia.safe-core.unsigned-acyclic-single-borrow.supplied-elf.x86_64.v1'
REPORT = {'schema':'hepta.hia.independent-entry-execution.v1',
          'execution_arrangement':'new Agent authored and assesses; root executor executes on its behalf',
          'entry_commit':EXPECTED_COMMIT, 'expected_entry_tree':EXPECTED_TREE,
          'metadata_root':str(META), 'evidence_root':str(ROOT),
          'started_utc':datetime.now(timezone.utc).isoformat(),
          'fresh_network_installation':False, 'reused_python_environment':True,
          'reused_hepta_sources':True, 'runtime_materialized_in_this_attempt':False,
          'online_probe_performed':False, 'general_machine_proof':False,
          'adoption_performed':False, 'commands':[], 'reviews':{}, 'status':'STARTED'}

def identity(path):
    b=Path(path).read_bytes()
    return {'bytes':len(b), 'sha256':hashlib.sha256(b).hexdigest()}

def save():
    (ROOT/'EXECUTION.json').write_text(json.dumps(REPORT,indent=2,sort_keys=True)+'\n')

def run(name, argv, cwd=META):
    row={'name':name, 'argv':[str(a) for a in argv], 'cwd':str(cwd),
         'started_utc':datetime.now(timezone.utc).isoformat(), 'pid':None, 'exit_code':None}
    REPORT['commands'].append(row)
    save()
    started=time.monotonic()
    try:
        with (ROOT/(name+'.stdout')).open('xb') as so, (ROOT/(name+'.stderr')).open('xb') as se:
            p=subprocess.Popen(row['argv'],cwd=cwd,stdout=so,stderr=se)
            row['pid']=p.pid
            save()
            row['exit_code']=p.wait()
    except BaseException as e:
        row['execution_error']={'type':type(e).__name__, 'message':str(e)}
        raise
    finally:
        row['elapsed_seconds']=time.monotonic()-started
        for stream in ('stdout','stderr'):
            path=ROOT/(name+'.'+stream)
            row[stream]=identity(path) if path.exists() else None
        save()
    return row, (ROOT/(name+'.stdout')).read_text(errors='replace')

def require(name, argv, cwd=META):
    row,text=run(name,argv,cwd)
    if row['exit_code'] != 0:
        raise RuntimeError(name+' failed with exit '+str(row['exit_code']))
    return text

def metadata_check(label):
    head=require(label+'-head',['git','rev-parse','HEAD']).strip()
    tree=require(label+'-index-tree',['git','write-tree']).strip()
    require(label+'-unstaged',['git','diff','--exit-code','--no-ext-diff'])
    status=require(label+'-status',['git','status','--porcelain','--untracked-files=all'])
    blobs={'INSTALL.md':'fa6b0e111d30ee6a6847c340605678e4ae74d0fa',
           'tools/hia_entry_catalog.py':'b28ad70c22423e56de648eb1efb77f211561058e',
           'tools/qualify_hia_entry_proof.py':'74b0bd0521a1904cdf197b32dd0f3c3521dc2f50'}
    measured={}
    for name,expected in blobs.items():
        b=(META/name).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        measured[name]={'expected_git_blob':expected,'actual_git_blob':actual,**identity(META/name)}
        if actual != expected:
            raise RuntimeError('metadata file differs: '+name)
    if tree != EXPECTED_TREE:
        raise RuntimeError('metadata index tree differs')
    return {'actual_head':head,'index_tree':tree,'status':status,'files':measured,
            'tree_equivalent':True,'checked_out_at_requested_commit':head==EXPECTED_COMMIT}

def copy_input(source, relative):
    target=ROOT/'inputs'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:
        f.write(Path(source).read_bytes())
    return identity(target)

save()
print(json.dumps({'status':'STARTED','evidence_root':str(ROOT)}),flush=True)
try:
    REPORT['metadata_identity_before']=metadata_check('metadata-before')
    catalog=json.loads(require('entry-catalog',[sys.executable,'-B','tools/hia_entry_catalog.py']))
    entries={e['selection']:e for e in catalog['entries']}
    REPORT['selections']=entries
    for name in ('INSTALL.md','tools/hia_entry_catalog.py','tools/qualify_hia_entry_proof.py',
                 'tools/hia_release.py','tools/hia_release_v16_6ecd802.py',
                 'tools/hia_candidate_preflight.py','releases/hia-current.json','releases/hia-v16-6ecd802.json'):
        copy_input(META/name,Path('metadata')/name)
    roots={'current':BASE/'entry-current-source','v16':BASE/'entry-v16-source'}
    want_runtime=entries['current']['sources']['runtime']
    if entries['v16']['sources']['runtime'] != want_runtime:
        raise RuntimeError('the two locks select different runtime identities')
    search=Path('/workspace/scratch/3977a84d79eb')
    marker_row,markers=run('runtime-repository-markers',
        ['rg','--files','--hidden','--no-ignore','--maxdepth','6','-g','HEAD','-g','.git',
         '-g','!**/objects/**','-g','!**/logs/**',str(search)],BASE)
    if marker_row['exit_code'] not in (0,1):
        raise RuntimeError('runtime discovery failed')
    candidates=set()
    for line in markers.splitlines():
        p=Path(line)
        if p.name=='HEAD' and p.parent.name=='.git':
            candidates.add(p.parent.parent)
        elif p.name=='.git':
            candidates.add(p.parent)
    REPORT['runtime_candidates']=[]
    runtime=None
    for i,path in enumerate(sorted(candidates)):
        row,text=run('runtime-candidate-'+str(i),['git','-C',str(path),'rev-parse','HEAD','HEAD^{tree}'],BASE)
        lines=text.splitlines()
        item={'path':str(path),'exit_code':row['exit_code'],'identity':lines}
        REPORT['runtime_candidates'].append(item)
        if row['exit_code']==0 and lines==[want_runtime['commit'],want_runtime['tree']]:
            runtime=path
            break
    if runtime is None:
        destination=ROOT/'runtime-materialization'
        require('materialize-missing-runtime',
                [sys.executable,'-B','tools/hia_release.py','materialize','--directory',str(destination)])
        runtime=destination/'runtime'
        REPORT['runtime_materialized_in_this_attempt']=True
    REPORT['runtime_root']=str(runtime)
    REPORT['runtime_expected_identity']=want_runtime
    save()
    commands={}
    for selection in ('current','v16'):
        e=entries[selection]
        args=[sys.executable,'-B',str(META/e['entry_argv'][2])]
        if selection=='v16':
            args+=['--lock',str(META/e['lock']['path']),'--lock-sha256',e['lock']['sha256']]
        commands[selection]=args
        require(selection+'-reused-source-check',args+['check','--hepta-root',str(roots[selection]),'--runtime-checkout',str(runtime)])
        example=roots[selection]/e['minimal_program']['path']
        if identity(example)['sha256'] != e['minimal_program']['sha256']:
            raise RuntimeError('locked minimum source differs: '+selection)
        copy_input(example,Path(selection)/'scalar_add.hia.json')
        copy_input(roots[selection]/'tools/check_hia_safe_core.py',Path(selection)/'check_hia_safe_core.py')
        copy_input(roots[selection]/'docs/HIA_AGENT_PROOF_RESULTS.md',Path(selection)/'HIA_AGENT_PROOF_RESULTS.md')
    obligation_results={'caller_contract_nonvacuous':'sat','machine_memory_access_bounds':'unsat',
                        'sysv_stack_alignment_and_preservation':'unsat',
                        'all_inputs_reach_a_terminal_model_outcome':'unsat',
                        'core_to_final_image_return_abort_and_caller_bytes':'unsat'}
    wanted_cases=[(2,3),(35,7),(0,0),(4294967295,1),(4294967295,4294967295)]
    wanted_commands=['release-check-before','dependencies','verify','interpret','direct-object',
                     'linker-version','link-proof-image','supplied-proof','native-calls','release-check-after']
    for selection in ('current','v16'):
        dest=ROOT/(selection+'-minimum-proof')
        row,text=run(selection+'-minimum',
            [sys.executable,'-B',str(META/'tools/qualify_hia_entry_proof.py'),
             '--selection',selection,'--hepta-root',str(roots[selection]),
             '--runtime-checkout',str(runtime),'--output',str(dest)])
        review={'adapter_exit_code':row['exit_code'],'adapter_stdout':text,'ok':False}
        REPORT['reviews'][selection]=review
        try:
            inner=json.loads((dest/'REPORT.json').read_text())
            proof=json.loads((dest/'proof/attempt.json').read_text())
            native=json.loads((dest/'native-calls.stdout').read_text())
            vm=json.loads((dest/'interpret.stdout').read_text())
            artifacts={'source':identity(roots[selection]/entries[selection]['minimal_program']['path']),
                       'object':identity(dest/'calculate.o'),'image':identity(dest/'calculate-proof.so')}
            obligations=proof.get('validation',{}).get('obligations',[])
            cases=native.get('cases',[])
            flags={
                'adapter_terminal_success':row['exit_code']==0 and inner.get('ok') is True and inner.get('status')=='PASS_LOCKED_MINIMUM_PROOF_AND_NATIVE_CALLS',
                'all_expected_commands_completed':[(c['name'],c.get('exit_code')) for c in inner.get('commands',[])]==[(name,0) for name in wanted_commands],
                'interpreter_result':vm.get('status')=='returned' and vm.get('values')==[5],
                'raw_proof_complete':proof.get('ok') is True and proof.get('status')=='smt_validated_not_executed' and proof.get('validation',{}).get('ok') is True and proof.get('validation',{}).get('complete') is True and proof.get('validation',{}).get('profile')==PROFILE,
                'all_five_obligations':len(obligations)==5 and {o.get('name') for o in obligations}==set(obligation_results) and all(o.get('expected')==obligation_results.get(o.get('name')) and o.get('result')==obligation_results.get(o.get('name')) for o in obligations),
                'proof_binds_actual_bytes':all(all(proof.get('inputs',{}).get(k,{}).get(field)==value for field,value in v.items()) for k,v in artifacts.items()),
                'proof_subject_binds_actual_bytes':proof.get('validation',{}).get('subject',{}).get('object_sha256')==artifacts['object']['sha256'] and proof.get('validation',{}).get('subject',{}).get('final_image_sha256')==artifacts['image']['sha256'],
                'native_five_cases':len(cases)==len(wanted_cases) and all(c.get('arguments')==list(ab) and c.get('actual')==((ab[0]+ab[1])&0xffffffff) and c.get('expected')==((ab[0]+ab[1])&0xffffffff) for c,ab in zip(cases,wanted_cases)),
                'same_proven_image_called':native.get('ok') is True and native.get('unchanged') is True and native.get('image_sha256')==artifacts['image']['sha256'] and inner.get('same_proven_image_called') is True,
                'proof_execution_scope_separated':all(proof.get(k) is False for k in ('compiler_invoked','linker_invoked','native_execution_observed','adopted')) and bool(proof.get('unproved_obligations')),
                'source_check_after_completed':inner.get('source_unchanged') is True,
                'no_adoption_or_general_claim':inner.get('general_machine_proof') is False and inner.get('adoption_performed') is False and inner.get('execution_authority_granted') is False and inner.get('live_endpoint_probed') is False,
                'published_dependencies':inner.get('dependencies',{}).get('jsonschema')=='4.25.1' and inner.get('dependencies',{}).get('z3-solver')=='4.15.4.0'}
            review.update(ok=all(flags.values()),checks=flags,artifacts=artifacts,native=native,interpreter=vm,
                          proof_status=proof.get('status'),proof_profile=proof.get('validation',{}).get('profile'),
                          obligations=obligations,unproved_obligations=proof.get('unproved_obligations'),
                          dependencies=inner.get('dependencies'),linker=inner.get('linker'),
                          elapsed_seconds=inner.get('elapsed_seconds'),
                          report_identity=identity(dest/'REPORT.json'),proof_receipt_identity=identity(dest/'proof/attempt.json'))
        except Exception as e:
            review['review_error']={'type':type(e).__name__,'message':str(e)}
        save()
    REPORT['metadata_identity_after']=metadata_check('metadata-after')
    REPORT['ok']=len(REPORT['reviews'])==2 and all(x.get('ok') is True for x in REPORT['reviews'].values())
    REPORT['status']='PASS_TWO_LOCKED_MINIMUM_PROGRAMS' if REPORT['ok'] else 'FAILED_MINIMUM_REVIEW'
except Exception as e:
    REPORT['ok']=False
    REPORT['status']='FAILED'
    REPORT['error']={'type':type(e).__name__,'message':str(e)}
finally:
    REPORT['completed_utc']=datetime.now(timezone.utc).isoformat()
    save()
    inventory={str(p.relative_to(ROOT)):identity(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='ARTIFACTS.json'}
    (ROOT/'ARTIFACTS.json').write_text(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:REPORT.get(k) for k in ('status','ok','evidence_root','runtime_root','runtime_materialized_in_this_attempt','metadata_identity_before','metadata_identity_after','reviews','error')},indent=2,sort_keys=True),flush=True)
sys.exit(0 if REPORT.get('ok') is True else 1)
