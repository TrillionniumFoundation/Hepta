"""Reproduce the exact pre-fix ELF load-order discrepancy in isolated children."""
from pathlib import Path
import argparse, hashlib, json, struct, subprocess, sys, time

parser = argparse.ArgumentParser()
parser.add_argument("--source-root", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()
source = Path(args.source_root).resolve()
output = Path(args.output).resolve()
output.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(source))

def blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

expected = {
    "hepta/hia_safe_core_elf.py": "04a3c02d647a78282e64abe8496d06ad30af23c8",
    "hepta/hia_program_native.py": "8265fe71399377e20140989c7f82f6b9158721da",
}
for name, sha in expected.items():
    assert blob_sha((source / name).read_bytes()) == sha, name

from hepta.hia_program import verify_program
from hepta.hia_program_native import emit_program_machine
from hepta.hia_safe_core import validate_safe_core_artifact
from tests.test_hia_program import arithmetic

core = verify_program(arithmetic("int.add.wrap", "u32"))
image = emit_program_machine(core)
(output / "core.json").write_bytes(core.canonical_bytes)
(output / "baseline.o").write_bytes(image.object_bytes)
command = ["ld", "-m", "elf_x86_64", "-shared", "-z", "defs", "-z", "noexecstack",
           "-z", "relro", "-z", "now", "--build-id=none", "--hash-style=both",
           str(output / "baseline.o"), "-lc", "-o", str(output / "baseline.so")]
subprocess.run(command, check=True, capture_output=True, timeout=20)
data = (output / "baseline.so").read_bytes()
phoff = struct.unpack_from("<Q", data, 32)[0]
phnum = struct.unpack_from("<H", data, 56)[0]
loads = [i for i in range(phnum) if struct.unpack_from("<I", data, phoff + 56 * i)[0] == 1]
observations = []
for name, pair in (("baseline", None), ("reverse_first_last", (loads[0], loads[-1])),
                   ("reverse_first_two", (loads[0], loads[1]))):
    changed = bytearray(data)
    if pair:
        a, b = [phoff + 56 * i for i in pair]
        changed[a:a + 56], changed[b:b + 56] = data[b:b + 56], data[a:a + 56]
    path = output / (name + ".so")
    path.write_bytes(changed)
    proof = validate_safe_core_artifact(core, image.object_bytes, bytes(changed))
    (output / (name + ".proof.json")).write_text(json.dumps(proof, indent=2, sort_keys=True) + "\n")
    child = ("import ctypes,resource,sys;"
             "resource.setrlimit(resource.RLIMIT_CORE,(0,0));"
             "resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));"
             "resource.setrlimit(resource.RLIMIT_CPU,(2,2));"
             "lib=ctypes.CDLL(sys.argv[1]);fn=lib.calculate;"
             "fn.argtypes=[ctypes.c_uint32,ctypes.c_uint32];fn.restype=ctypes.c_uint32;"
             "print(fn(17,25))")
    started = time.monotonic_ns()
    result = subprocess.run([sys.executable, "-I", "-B", "-c", child, str(path)],
                            capture_output=True, text=True, timeout=10)
    row = {"case": name, "swapped_headers": pair,
           "image_sha256": hashlib.sha256(changed).hexdigest(),
           "old_checker_ok": proof["ok"], "old_checker_status": proof["status"],
           "native": {"returncode": result.returncode, "stdout": result.stdout,
                      "stderr": result.stderr, "wall_ns": time.monotonic_ns() - started}}
    observations.append(row)
report = {"schema": "hepta.hia.loader-order-counterexample.v1",
          "baseline_source_commit": "2598f4309791d3a023cd5df585ad26810b20c744",
          "baseline_module_git_blobs": expected, "link_command": command,
          "scope": "Reconstructed original checker/producer modules with recorded exact Git blob identities; no production execution",
          "observations": observations}
(output / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({"cases": len(observations),
                  "checker_accepted": sum(row["old_checker_ok"] for row in observations),
                  "native_returncodes": [row["native"]["returncode"] for row in observations]}))
