(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun imul_undefined_zf_step_5 () Bool)
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (and (not (or false))
                (distinct (ite true #x0000000000000001 #x0000000000000000)
                          (ite true
                               (ite imul_undefined_zf_step_5
                                    #x0000000000000001
                                    #x0000000000000000)
                               #x0000000000000000)))))
  (or (distinct (or false) (or false))
      a!1
      (distinct (ite true initial_caller_bytes initial_caller_bytes)
                (ite true initial_caller_bytes initial_caller_bytes)))))

(check-sat)
