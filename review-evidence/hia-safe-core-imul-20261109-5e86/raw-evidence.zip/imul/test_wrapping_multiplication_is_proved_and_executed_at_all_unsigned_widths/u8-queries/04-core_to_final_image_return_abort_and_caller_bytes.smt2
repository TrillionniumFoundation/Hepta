(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (ite true
                (concat #x00000000000000
                        (bvmul ((_ extract 7 0) abi_word_0)
                               ((_ extract 7 0) abi_word_1)))
                #x0000000000000000)))
  (or (distinct (or false) (or false))
      (and (not (or false)) (distinct a!1 a!1))
      (distinct (ite true initial_caller_bytes initial_caller_bytes)
                (ite true initial_caller_bytes initial_caller_bytes)))))

(check-sat)
