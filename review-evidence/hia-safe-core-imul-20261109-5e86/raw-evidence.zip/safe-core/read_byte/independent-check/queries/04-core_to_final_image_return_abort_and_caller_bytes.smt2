(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_2 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (or (= abi_word_1 #x0000000000000000)
               (and (distinct abi_word_0 #x0000000000000000)
                    (bvuge (bvadd abi_word_0 abi_word_1) abi_word_0)))))
  (=> (and (bvule abi_word_1 #x0000000000000040) a!1)
      (or (= abi_word_1 #x0000000000000000)
          (bvule (bvadd abi_word_0 abi_word_1)
                 (bvsub initial_rsp #x0000000000004000))
          (bvuge abi_word_0 (bvadd initial_rsp #x0000000000000008))))))
(assert (let ((a!1 (not (and (not (= abi_word_1 #x0000000000000000))
                     (= abi_word_0 #x0000000000000000))))
      (a!2 (and (not (= abi_word_1 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!4 (or (not (= ((_ extract 63 7) abi_word_1)
                       #b000000000000000000000000000000000000000000000000000000000))
               (bvule #b1000000 ((_ extract 6 0) abi_word_1))))
      (a!10 (and (= ((_ extract 63 7) abi_word_1)
                    #b000000000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 6 0) abi_word_1) #b1000000)
                 (not (= abi_word_1 #x0000000000000000))
                 (= abi_word_0 #x0000000000000000)))
      (a!11 (not (and (= ((_ extract 63 7) abi_word_1)
                         #b000000000000000000000000000000000000000000000000000000000)
                      (bvule ((_ extract 6 0) abi_word_1) #b1000000)))))
(let ((a!3 (and (= ((_ extract 63 7) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 6 0) abi_word_1) #b1000000)
                a!1
                (not a!2)
                (bvule abi_word_1 abi_word_2)))
      (a!5 (not (and a!4 (not (= abi_word_1 #x0000000000000040)))))
      (a!8 (and (= ((_ extract 63 7) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 6 0) abi_word_1) #b1000000)
                a!1
                (not a!2)
                (not (bvule abi_word_1 abi_word_2))))
      (a!9 (and (= ((_ extract 63 7) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 6 0) abi_word_1) #b1000000)
                a!1
                (not (= abi_word_1 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))))))
(let ((a!6 (and a!5
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                (bvule abi_word_1 abi_word_2)))
      (a!12 (ite a!3
                 #x0000000000000000
                 (ite a!9
                      #x0000000300000000
                      (ite a!10
                           #x0000000200000000
                           (ite a!11 #x0000000100000000 #x0000000000000000)))))
      (a!14 (and a!5
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!15 (and a!5
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                 (not (bvule abi_word_1 abi_word_2))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_2))
                 (not (bvule (bvadd abi_word_0 abi_word_1)
                             (bvadd abi_word_0 abi_word_2)))))
      (a!19 (ite a!3
                 initial_caller_bytes
                 (ite a!9
                      initial_caller_bytes
                      (ite a!10
                           initial_caller_bytes
                           (ite a!11 initial_caller_bytes initial_caller_bytes))))))
(let ((a!7 (distinct (or a!3 false)
                     (or a!6
                         (and a!5
                              (= abi_word_1 #x0000000000000000)
                              (bvule abi_word_1 abi_word_2))
                         false)))
      (a!13 (ite a!8
                 (concat #x00000000000000
                         (select initial_caller_bytes
                                 (bvadd abi_word_0 abi_word_2)))
                 a!12))
      (a!16 (ite a!15
                 (concat #x00000000000000
                         (select initial_caller_bytes
                                 (bvadd abi_word_0 abi_word_2)))
                 #x0000000000000000))
      (a!20 (ite (and a!5
                      (not (= abi_word_1 #x0000000000000000))
                      (= abi_word_0 #x0000000000000000))
                 initial_caller_bytes
                 (ite a!14
                      initial_caller_bytes
                      (ite a!6
                           initial_caller_bytes
                           (ite a!15 initial_caller_bytes initial_caller_bytes))))))
(let ((a!17 (ite (and a!5
                      (not (= abi_word_1 #x0000000000000000))
                      (= abi_word_0 #x0000000000000000))
                 #x0000000200000000
                 (ite a!14 #x0000000300000000 (ite a!6 #x0000000000000000 a!16))))
      (a!21 (ite (and a!4 (not (= abi_word_1 #x0000000000000040)))
                 initial_caller_bytes
                 (ite (and a!5
                           (= abi_word_1 #x0000000000000000)
                           (bvule abi_word_1 abi_word_2))
                      initial_caller_bytes
                      a!20))))
(let ((a!18 (ite (and a!4 (not (= abi_word_1 #x0000000000000040)))
                 #x0000000100000000
                 (ite (and a!5
                           (= abi_word_1 #x0000000000000000)
                           (bvule abi_word_1 abi_word_2))
                      #x0000000000000000
                      a!17))))
  (or a!7
      (and (not (or a!3 false)) (distinct a!13 a!18))
      (distinct (ite a!8 initial_caller_bytes a!19) a!21)))))))))

(check-sat)
