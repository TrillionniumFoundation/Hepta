(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_3 () (_ BitVec 64))
(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_4 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (or (= abi_word_1 #x0000000000000000)
               (and (distinct abi_word_0 #x0000000000000000)
                    (bvuge (bvadd abi_word_0 abi_word_1) abi_word_0)))))
  (=> (and (bvule abi_word_1 #x0000000000001000) a!1)
      (or (= abi_word_1 #x0000000000000000)
          (bvule (bvadd abi_word_0 abi_word_1)
                 (bvsub initial_rsp #x0000000000004000))
          (bvuge abi_word_0 (bvadd initial_rsp #x0000000000000008))))))
(assert (let ((a!1 (not (and (not (= abi_word_1 #x0000000000000000))
                     (= abi_word_0 #x0000000000000000))))
      (a!2 (and (not (= abi_word_1 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!3 (bvor (concat #b111111111111111111111111111111111111111111111111111111111111111
                         (bvnot ((_ extract 0 0) abi_word_4)))
                 (ite (bvule abi_word_1 abi_word_2)
                      #xffffffffffffffff
                      #xfffffffffffffffe)))
      (a!5 (or (not (= ((_ extract 63 13) abi_word_1)
                       #b000000000000000000000000000000000000000000000000000))
               (bvule #b1000000000000 ((_ extract 12 0) abi_word_1))))
      (a!7 (not (or (bvule abi_word_1 abi_word_2)
                    (= ((_ extract 0 0) abi_word_4) #b0))))
      (a!11 (concat #x00000000000000
                    (bvadd (select initial_caller_bytes
                                   (bvadd abi_word_0 abi_word_2))
                           ((_ extract 7 0) abi_word_3))))
      (a!14 (and (= ((_ extract 63 13) abi_word_1)
                    #b000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                 (not (= abi_word_1 #x0000000000000000))
                 (= abi_word_0 #x0000000000000000)))
      (a!15 (not (and (= ((_ extract 63 13) abi_word_1)
                         #b000000000000000000000000000000000000000000000000000)
                      (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)))))
(let ((a!4 (and (= ((_ extract 63 13) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                a!1
                (not a!2)
                (not (= (bvnot a!3) #x0000000000000000))
                (bvule abi_word_1 abi_word_2)))
      (a!6 (not (and a!5 (not (= abi_word_1 #x0000000000001000)))))
      (a!10 (and (= ((_ extract 63 13) abi_word_1)
                    #b000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                 a!1
                 (not a!2)
                 (not (= (bvnot a!3) #x0000000000000000))
                 (not (bvule abi_word_1 abi_word_2))))
      (a!12 (and (= ((_ extract 63 13) abi_word_1)
                    #b000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                 a!1
                 (not a!2)
                 (= (bvnot a!3) #x0000000000000000)))
      (a!13 (and (= ((_ extract 63 13) abi_word_1)
                    #b000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                 a!1
                 (not (= abi_word_1 #x0000000000000000))
                 (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))))))
(let ((a!8 (and a!6
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                a!7
                (bvule abi_word_1 abi_word_2)))
      (a!16 (ite a!12
                 #x0000000000000000
                 (ite a!13
                      #x0000000300000000
                      (ite a!14
                           #x0000000200000000
                           (ite a!15 #x0000000100000000 #x0000000000000000)))))
      (a!17 (and a!6
                 (= abi_word_1 #x0000000000000000)
                 (or (bvule abi_word_1 abi_word_2)
                     (= ((_ extract 0 0) abi_word_4) #b0))))
      (a!18 (and a!6
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!19 (and a!6
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                 (or (bvule abi_word_1 abi_word_2)
                     (= ((_ extract 0 0) abi_word_4) #b0))))
      (a!20 (and a!6
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                 a!7
                 (not (bvule abi_word_1 abi_word_2))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_2))
                 (not (bvule (bvadd abi_word_0 abi_word_1)
                             (bvadd abi_word_0 abi_word_2)))))
      (a!26 (ite a!12
                 initial_caller_bytes
                 (ite a!13
                      initial_caller_bytes
                      (ite a!14
                           initial_caller_bytes
                           (ite a!15 initial_caller_bytes initial_caller_bytes))))))
(let ((a!9 (distinct (or a!4 false false)
                     (or a!8
                         (and a!6
                              (= abi_word_1 #x0000000000000000)
                              a!7
                              (bvule abi_word_1 abi_word_2))
                         false)))
      (a!21 (ite a!18
                 #x0000000300000000
                 (ite a!19
                      #x0000000000000000
                      (ite a!8
                           #x0000000000000000
                           (ite a!20 a!11 #x0000000000000000)))))
      (a!27 (ite a!8
                 initial_caller_bytes
                 (ite a!20
                      (store initial_caller_bytes
                             (bvadd abi_word_0 abi_word_2)
                             ((_ extract 7 0) a!11))
                      initial_caller_bytes))))
(let ((a!22 (ite (and a!6
                      (not (= abi_word_1 #x0000000000000000))
                      (= abi_word_0 #x0000000000000000))
                 #x0000000200000000
                 a!21))
      (a!28 (ite (and a!6
                      (not (= abi_word_1 #x0000000000000000))
                      (= abi_word_0 #x0000000000000000))
                 initial_caller_bytes
                 (ite a!18
                      initial_caller_bytes
                      (ite a!19 initial_caller_bytes a!27)))))
(let ((a!23 (ite a!17
                 #x0000000000000000
                 (ite (and a!6
                           (= abi_word_1 #x0000000000000000)
                           a!7
                           (bvule abi_word_1 abi_word_2))
                      #x0000000000000000
                      a!22)))
      (a!29 (ite a!17
                 initial_caller_bytes
                 (ite (and a!6
                           (= abi_word_1 #x0000000000000000)
                           a!7
                           (bvule abi_word_1 abi_word_2))
                      initial_caller_bytes
                      a!28))))
(let ((a!24 (ite (and a!5 (not (= abi_word_1 #x0000000000001000)))
                 #x0000000100000000
                 a!23))
      (a!30 (ite (and a!5 (not (= abi_word_1 #x0000000000001000)))
                 initial_caller_bytes
                 a!29)))
(let ((a!25 (distinct (ite a!10
                           a!11
                           (ite false
                                #x0000000000000000
                                (ite a!4 #x0000000000000000 a!16)))
                      a!24))
      (a!31 (distinct (ite a!10
                           (store initial_caller_bytes
                                  (bvadd abi_word_0 abi_word_2)
                                  ((_ extract 7 0) a!11))
                           (ite false
                                initial_caller_bytes
                                (ite a!4 initial_caller_bytes a!26)))
                      a!30)))
  (or a!9 (and (not (or a!4 false false)) a!25) a!31))))))))))

(check-sat)
