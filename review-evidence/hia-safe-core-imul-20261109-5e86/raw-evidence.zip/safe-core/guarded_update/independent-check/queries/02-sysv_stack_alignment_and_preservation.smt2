(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun native_register_15 () (_ BitVec 64))
(declare-fun native_register_14 () (_ BitVec 64))
(declare-fun native_register_13 () (_ BitVec 64))
(declare-fun native_register_12 () (_ BitVec 64))
(declare-fun native_register_5 () (_ BitVec 64))
(declare-fun native_register_3 () (_ BitVec 64))
(declare-fun abi_word_4 () (_ BitVec 64))
(declare-fun abi_word_2 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (or (= abi_word_1 #x0000000000000000)
               (and (distinct abi_word_0 #x0000000000000000)
                    (bvuge (bvadd abi_word_0 abi_word_1) abi_word_0)))))
  (=> (and (bvule abi_word_1 #x0000000000001000) a!1)
      (or (= abi_word_1 #x0000000000000000)
          (bvule (bvadd abi_word_0 abi_word_1)
                 (bvsub initial_rsp #x0000000000004000))
          (bvuge abi_word_0 (bvadd initial_rsp #x0000000000000008))))))
(assert (let ((a!1 (or (not (= ((_ extract 63 13) abi_word_1)
                       #b000000000000000000000000000000000000000000000000000))
               (bvule #b1000000000000 ((_ extract 12 0) abi_word_1))))
      (a!4 (not (or (bvule abi_word_1 abi_word_2)
                    (= ((_ extract 0 0) abi_word_4) #b0))))
      (a!5 (not (and (= (bvadd #x0000000000000008 initial_rsp)
                        (bvadd initial_rsp #x0000000000000008))
                     (= native_register_3 native_register_3)
                     (= native_register_5 native_register_5)
                     (= native_register_12 native_register_12)
                     (= native_register_13 native_register_13)
                     (= native_register_14 native_register_14)
                     (= native_register_15 native_register_15)))))
(let ((a!2 (not (and a!1 (not (= abi_word_1 #x0000000000001000)))))
      (a!13 (and (and a!1 (not (= abi_word_1 #x0000000000001000))) a!5)))
(let ((a!3 (and a!2
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                (distinct (bvand (bvadd #xffffffffffffffc8 initial_rsp)
                                 #x000000000000000f)
                          #x0000000000000000)))
      (a!6 (and a!2
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                a!4
                (not (bvule abi_word_1 abi_word_2))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_2))
                (not (bvule (bvadd abi_word_0 abi_word_1)
                            (bvadd abi_word_0 abi_word_2)))
                a!5))
      (a!7 (and a!2
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                a!4
                (bvule abi_word_1 abi_word_2)
                (distinct (bvand (bvadd #xfffffffffffffed8 initial_rsp)
                                 #x000000000000000f)
                          #x0000000000000000)))
      (a!8 (and a!2
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                (or (bvule abi_word_1 abi_word_2)
                    (= ((_ extract 0 0) abi_word_4) #b0))
                a!5))
      (a!9 (and a!2
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))
                a!5))
      (a!10 (and a!2
                 (= abi_word_1 #x0000000000000000)
                 (distinct (bvand (bvadd #xffffffffffffffc8 initial_rsp)
                                  #x000000000000000f)
                           #x0000000000000000)))
      (a!11 (and a!2
                 (= abi_word_1 #x0000000000000000)
                 a!4
                 (bvule abi_word_1 abi_word_2)
                 (distinct (bvand (bvadd #xfffffffffffffed8 initial_rsp)
                                  #x000000000000000f)
                           #x0000000000000000)))
      (a!12 (and a!2
                 (= abi_word_1 #x0000000000000000)
                 (or (bvule abi_word_1 abi_word_2)
                     (= ((_ extract 0 0) abi_word_4) #b0))
                 a!5)))
  (or a!3
      a!6
      a!7
      a!8
      a!9
      (and a!2
           (not (= abi_word_1 #x0000000000000000))
           (= abi_word_0 #x0000000000000000)
           a!5)
      a!10
      a!11
      a!12
      a!13
      false)))))

(check-sat)
