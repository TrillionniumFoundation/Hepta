(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun abi_word_4 () (_ BitVec 64))
(declare-fun abi_word_2 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (or (= abi_word_1 #x0000000000000000)
               (and (distinct abi_word_0 #x0000000000000000)
                    (bvuge (bvadd abi_word_0 abi_word_1) abi_word_0)))))
  (=> (and (bvule abi_word_1 #x0000000000001000) a!1)
      (or (= abi_word_1 #x0000000000000000)
          (bvule (bvadd abi_word_0 abi_word_1)
                 (bvsub initial_rsp #x0000000000004000))
          (bvuge abi_word_0 (bvadd initial_rsp #x0000000000000008))))))
(assert (let ((a!1 (not (and (= ((_ extract 63 13) abi_word_1)
                        #b000000000000000000000000000000000000000000000000000)
                     (bvule ((_ extract 12 0) abi_word_1) #b1000000000000))))
      (a!2 (not (and (not (= abi_word_1 #x0000000000000000))
                     (= abi_word_0 #x0000000000000000))))
      (a!4 (and (not (= abi_word_1 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!5 (bvor (concat #b111111111111111111111111111111111111111111111111111111111111111
                         (bvnot ((_ extract 0 0) abi_word_4)))
                 (ite (bvule abi_word_1 abi_word_2)
                      #xffffffffffffffff
                      #xfffffffffffffffe)))
      (a!9 (or (not (= ((_ extract 63 13) abi_word_1)
                       #b000000000000000000000000000000000000000000000000000))
               (bvule #b1000000000000 ((_ extract 12 0) abi_word_1))))
      (a!11 (not (or (bvule abi_word_1 abi_word_2)
                     (= ((_ extract 0 0) abi_word_4) #b0)))))
(let ((a!3 (and (= ((_ extract 63 13) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                a!2
                (not (= abi_word_1 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!6 (and (= ((_ extract 63 13) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                a!2
                (not a!4)
                (not (= (bvnot a!5) #x0000000000000000))
                (bvule abi_word_1 abi_word_2)))
      (a!7 (and (= ((_ extract 63 13) abi_word_1)
                   #b000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                a!2
                (not a!4)
                (not (= (bvnot a!5) #x0000000000000000))
                (not (bvule abi_word_1 abi_word_2))))
      (a!10 (not (and a!9 (not (= abi_word_1 #x0000000000001000))))))
(let ((a!8 (or a!1
               (and (= ((_ extract 63 13) abi_word_1)
                       #b000000000000000000000000000000000000000000000000000)
                    (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                    (not (= abi_word_1 #x0000000000000000))
                    (= abi_word_0 #x0000000000000000))
               a!3
               (and (= ((_ extract 63 13) abi_word_1)
                       #b000000000000000000000000000000000000000000000000000)
                    (bvule ((_ extract 12 0) abi_word_1) #b1000000000000)
                    a!2
                    (not a!4)
                    (= (bvnot a!5) #x0000000000000000))
               a!6
               false
               a!7))
      (a!12 (and a!10
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                 a!11
                 (not (bvule abi_word_1 abi_word_2))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_2))
                 (not (bvule (bvadd abi_word_0 abi_word_1)
                             (bvadd abi_word_0 abi_word_2)))))
      (a!13 (and a!10
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                 (or (bvule abi_word_1 abi_word_2)
                     (= ((_ extract 0 0) abi_word_4) #b0))))
      (a!14 (and a!10
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!15 (and a!10
                 (= abi_word_1 #x0000000000000000)
                 (or (bvule abi_word_1 abi_word_2)
                     (= ((_ extract 0 0) abi_word_4) #b0)))))
(let ((a!16 (or a!12
                (and a!10
                     (not (= abi_word_1 #x0000000000000000))
                     (not (= abi_word_0 #x0000000000000000))
                     (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                     a!11
                     (bvule abi_word_1 abi_word_2))
                a!13
                a!14
                (and a!10
                     (not (= abi_word_1 #x0000000000000000))
                     (= abi_word_0 #x0000000000000000))
                (and a!10
                     (= abi_word_1 #x0000000000000000)
                     a!11
                     (bvule abi_word_1 abi_word_2))
                a!15
                (and a!9 (not (= abi_word_1 #x0000000000001000))))))
  (or (not a!8) (not a!16)))))))

(check-sat)
