(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (and (not (bvule ((_ extract 7 0) abi_word_2)
                            ((_ extract 7 0) abi_word_0)))
                (not (bvule ((_ extract 7 0) abi_word_0)
                            ((_ extract 7 0) abi_word_2)))))
      (a!2 (bvule ((_ extract 7 0) abi_word_1)
                  (bvadd ((_ extract 7 0) abi_word_2)
                         (bvmul #xff ((_ extract 7 0) abi_word_0)))))
      (a!3 (not (bvule ((_ extract 7 0) abi_word_0)
                       (bvadd ((_ extract 7 0) abi_word_0)
                              ((_ extract 7 0) abi_word_1)))))
      (a!5 (bvadd (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                  (bvmul #xffffffffffffffff
                         (concat #x00000000000000 ((_ extract 7 0) abi_word_0)))))
      (a!7 (= (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
              (bvadd #x00000000000000ff
                     (concat #x00000000000000 ((_ extract 7 0) abi_word_0)))))
      (a!8 (bvule (bvadd ((_ extract 7 0) abi_word_2)
                         (bvmul #xff ((_ extract 7 0) abi_word_0)))
                  ((_ extract 7 0) abi_word_1)))
      (a!9 (= ((_ extract 7 0) abi_word_1)
              (bvadd ((_ extract 7 0) abi_word_2)
                     (bvmul #xff ((_ extract 7 0) abi_word_0)))))
      (a!10 ((_ extract 63 8)
              (bvadd (concat #x00000000000000 ((_ extract 7 0) abi_word_0))
                     (concat #x00000000000000 ((_ extract 7 0) abi_word_1)))))
      (a!12 (= ((_ extract 7 0) abi_word_0)
               (bvadd #xff (bvmul #xff ((_ extract 7 0) abi_word_1)))))
      (a!13 (bvadd #x00000000000000ff
                   (bvmul #xffffffffffffffff
                          (concat #x00000000000000 ((_ extract 7 0) abi_word_1))))))
(let ((a!4 (and (not (bvule ((_ extract 7 0) abi_word_2)
                            ((_ extract 7 0) abi_word_0)))
                (bvule ((_ extract 7 0) abi_word_0)
                       ((_ extract 7 0) abi_word_2))
                a!2
                a!3))
      (a!6 (or (not (= ((_ extract 63 8) a!5) #x00000000000000))
               (= ((_ extract 7 0) abi_word_2)
                  (bvadd #xff ((_ extract 7 0) abi_word_0)))))
      (a!11 (or (not (= a!10 #x00000000000000))
                (bvule ((_ extract 7 0) abi_word_0)
                       (bvadd ((_ extract 7 0) abi_word_0)
                              ((_ extract 7 0) abi_word_1)))))
      (a!14 (not (= (concat #x00000000000000 ((_ extract 7 0) abi_word_0)) a!13)))
      (a!18 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 (not a!2)))
      (a!19 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 a!2
                 (bvule ((_ extract 7 0) abi_word_0)
                        (bvadd ((_ extract 7 0) abi_word_0)
                               ((_ extract 7 0) abi_word_1))))))
(let ((a!15 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 (not (and a!6 (not a!7)))
                 (not (and a!8 (not a!9)))
                 a!11
                 (or (not (= a!10 #x00000000000000)) a!12)
                 a!14))
      (a!16 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 (not (and a!6 (not a!7)))
                 (not (and a!8 (not a!9)))
                 (not a!11)))
      (a!17 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 a!6
                 (not a!7)))
      (a!20 (ite a!19
                 (concat #x00000000000000
                         (bvadd ((_ extract 7 0) abi_word_0)
                                ((_ extract 7 0) abi_word_1)))
                 (ite a!4
                      #x0000000000000000
                      (ite a!1 #x0000000000000000 #x0000000000000000))))
      (a!22 (and (or (not (= a!10 #x00000000000000)) a!12) a!14))
      (a!24 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 (not (and a!6 (not a!7)))
                 a!8
                 (not a!9)))
      (a!28 (ite a!18
                 initial_caller_bytes
                 (ite a!19
                      initial_caller_bytes
                      (ite a!4
                           initial_caller_bytes
                           (ite a!1 initial_caller_bytes initial_caller_bytes))))))
(let ((a!21 (ite (bvule ((_ extract 7 0) abi_word_2)
                        ((_ extract 7 0) abi_word_0))
                 (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                 (ite a!18
                      (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                      a!20)))
      (a!23 (and (not (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0)))
                 (bvule ((_ extract 7 0) abi_word_0)
                        ((_ extract 7 0) abi_word_2))
                 (not (and a!6 (not a!7)))
                 (not (and a!8 (not a!9)))
                 a!11
                 (not a!22)))
      (a!25 (ite a!24
                 (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                 (ite (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0))
                      (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                      #x0000000000000000)))
      (a!29 (ite a!24
                 initial_caller_bytes
                 (ite (bvule ((_ extract 7 0) abi_word_2)
                             ((_ extract 7 0) abi_word_0))
                      initial_caller_bytes
                      initial_caller_bytes))))
(let ((a!26 (ite a!23
                 (concat #x00000000000000
                         (bvadd ((_ extract 7 0) abi_word_0)
                                ((_ extract 7 0) abi_word_1)))
                 a!25))
      (a!30 (ite a!17
                 initial_caller_bytes
                 (ite a!16
                      initial_caller_bytes
                      (ite a!15
                           initial_caller_bytes
                           (ite a!23 initial_caller_bytes a!29))))))
(let ((a!27 (ite a!1
                 #x0000000000000000
                 (ite a!17
                      #x0000000000000000
                      (ite a!16
                           #x0000000000000000
                           (ite a!15 #x0000000000000000 a!26)))))
      (a!31 (distinct (ite (bvule ((_ extract 7 0) abi_word_2)
                                  ((_ extract 7 0) abi_word_0))
                           initial_caller_bytes
                           a!28)
                      (ite a!1 initial_caller_bytes a!30))))
  (or (distinct (or a!1 a!4 false) (or a!15 a!16 a!17 a!1 false))
      (and (not (or a!1 a!4 false)) (distinct a!21 a!27))
      a!31))))))))

(check-sat)
