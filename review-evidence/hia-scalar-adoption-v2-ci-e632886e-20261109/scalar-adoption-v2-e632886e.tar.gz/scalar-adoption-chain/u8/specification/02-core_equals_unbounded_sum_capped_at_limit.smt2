(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(assert (let ((a!1 (bvule ((_ extract 7 0) abi_word_1)
                  (bvadd ((_ extract 7 0) abi_word_2)
                         (bvmul #xff ((_ extract 7 0) abi_word_0)))))
      (a!4 (not (bvule ((_ extract 7 0) abi_word_0)
                       (bvadd ((_ extract 7 0) abi_word_0)
                              ((_ extract 7 0) abi_word_1)))))
      (a!6 (and (not (bvule ((_ extract 7 0) abi_word_2)
                            ((_ extract 7 0) abi_word_0)))
                (not (bvule ((_ extract 7 0) abi_word_0)
                            ((_ extract 7 0) abi_word_2)))))
      (a!9 (bvadd ((_ zero_extend 1)
                    (concat #x00000000000000 ((_ extract 7 0) abi_word_0)))
                  ((_ zero_extend 1)
                    (concat #x00000000000000 ((_ extract 7 0) abi_word_1))))))
(let ((a!2 (and (not (bvule ((_ extract 7 0) abi_word_2)
                            ((_ extract 7 0) abi_word_0)))
                (bvule ((_ extract 7 0) abi_word_0)
                       ((_ extract 7 0) abi_word_2))
                (not a!1)))
      (a!3 (and (not (bvule ((_ extract 7 0) abi_word_2)
                            ((_ extract 7 0) abi_word_0)))
                (bvule ((_ extract 7 0) abi_word_0)
                       ((_ extract 7 0) abi_word_2))
                a!1
                (bvule ((_ extract 7 0) abi_word_0)
                       (bvadd ((_ extract 7 0) abi_word_0)
                              ((_ extract 7 0) abi_word_1)))))
      (a!5 (and (not (bvule ((_ extract 7 0) abi_word_2)
                            ((_ extract 7 0) abi_word_0)))
                (bvule ((_ extract 7 0) abi_word_0)
                       ((_ extract 7 0) abi_word_2))
                a!1
                a!4))
      (a!10 (bvule a!9
                   ((_ zero_extend 1)
                     (concat #x00000000000000 ((_ extract 7 0) abi_word_2))))))
(let ((a!7 (ite a!3
                (concat #x00000000000000
                        (bvadd ((_ extract 7 0) abi_word_0)
                               ((_ extract 7 0) abi_word_1)))
                (ite a!5
                     #x0000000000000000
                     (ite a!6 #x0000000000000000 #x0000000000000000)))))
(let ((a!8 (ite (bvule ((_ extract 7 0) abi_word_2)
                       ((_ extract 7 0) abi_word_0))
                (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                (ite a!2
                     (concat #x00000000000000 ((_ extract 7 0) abi_word_2))
                     a!7))))
  (distinct a!8
            (ite a!10
                 ((_ extract 63 0) a!9)
                 (concat #x00000000000000 ((_ extract 7 0) abi_word_2)))))))))

(check-sat)
