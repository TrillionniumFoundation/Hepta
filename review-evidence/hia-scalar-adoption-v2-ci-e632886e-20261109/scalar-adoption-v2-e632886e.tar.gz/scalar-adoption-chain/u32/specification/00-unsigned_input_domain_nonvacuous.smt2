(assert true)

(check-sat)
