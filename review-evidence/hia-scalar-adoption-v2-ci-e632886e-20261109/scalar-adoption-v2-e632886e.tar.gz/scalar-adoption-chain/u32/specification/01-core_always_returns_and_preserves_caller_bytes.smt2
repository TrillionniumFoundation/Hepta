(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(assert (let ((a!1 (and (not (bvule ((_ extract 31 0) abi_word_2)
                            ((_ extract 31 0) abi_word_0)))
                (not (bvule ((_ extract 31 0) abi_word_0)
                            ((_ extract 31 0) abi_word_2)))))
      (a!2 (bvule ((_ extract 31 0) abi_word_1)
                  (bvadd ((_ extract 31 0) abi_word_2)
                         (bvmul #xffffffff ((_ extract 31 0) abi_word_0)))))
      (a!3 (not (bvule ((_ extract 31 0) abi_word_0)
                       (bvadd ((_ extract 31 0) abi_word_0)
                              ((_ extract 31 0) abi_word_1))))))
(let ((a!4 (and (not (bvule ((_ extract 31 0) abi_word_2)
                            ((_ extract 31 0) abi_word_0)))
                (bvule ((_ extract 31 0) abi_word_0)
                       ((_ extract 31 0) abi_word_2))
                a!2
                a!3))
      (a!5 (and (not (bvule ((_ extract 31 0) abi_word_2)
                            ((_ extract 31 0) abi_word_0)))
                (bvule ((_ extract 31 0) abi_word_0)
                       ((_ extract 31 0) abi_word_2))
                a!2
                (bvule ((_ extract 31 0) abi_word_0)
                       (bvadd ((_ extract 31 0) abi_word_0)
                              ((_ extract 31 0) abi_word_1)))))
      (a!6 (and (not (bvule ((_ extract 31 0) abi_word_2)
                            ((_ extract 31 0) abi_word_0)))
                (bvule ((_ extract 31 0) abi_word_0)
                       ((_ extract 31 0) abi_word_2))
                (not a!2))))
(let ((a!7 (not (or a!1
                    a!4
                    a!5
                    a!6
                    (bvule ((_ extract 31 0) abi_word_2)
                           ((_ extract 31 0) abi_word_0)))))
      (a!8 (ite a!6
                initial_caller_bytes
                (ite a!5
                     initial_caller_bytes
                     (ite a!4
                          initial_caller_bytes
                          (ite a!1 initial_caller_bytes initial_caller_bytes))))))
(let ((a!9 (distinct (ite (bvule ((_ extract 31 0) abi_word_2)
                                 ((_ extract 31 0) abi_word_0))
                          initial_caller_bytes
                          a!8)
                     initial_caller_bytes)))
  (or a!7 a!1 a!4 false a!9))))))

(check-sat)
