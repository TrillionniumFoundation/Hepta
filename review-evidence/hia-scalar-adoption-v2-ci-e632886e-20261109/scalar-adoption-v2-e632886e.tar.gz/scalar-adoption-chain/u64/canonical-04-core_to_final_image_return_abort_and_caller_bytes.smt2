(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!3 (not (= abi_word_1
                   (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))))
      (a!7 (not (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))))
      (a!8 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))))
      (a!9 (ite (and (not (bvule abi_word_2 abi_word_0))
                     (not (bvule abi_word_0 abi_word_2)))
                #x0000000000000000
                #x0000000000000000))
      (a!16 (ite (and (not (bvule abi_word_2 abi_word_0))
                      (not (bvule abi_word_0 abi_word_2)))
                 initial_caller_bytes
                 initial_caller_bytes)))
(let ((a!2 (or (and (not (bvule abi_word_2 abi_word_0))
                    (not (bvule abi_word_0 abi_word_2)))
               a!1
               false))
      (a!4 (and (bvule (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0))
                       abi_word_1)
                a!3))
      (a!10 (ite (and (not (bvule abi_word_2 abi_word_0))
                      (bvule abi_word_0 abi_word_2)
                      a!7)
                 abi_word_2
                 (ite a!8
                      (bvadd abi_word_0 abi_word_1)
                      (ite a!1 #x0000000000000000 a!9))))
      (a!12 (and (not (bvule abi_word_2 abi_word_0))
                 (bvule abi_word_0 abi_word_2)
                 (bvule (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0))
                        abi_word_1)
                 a!3))
      (a!17 (ite (and (not (bvule abi_word_2 abi_word_0))
                      (bvule abi_word_0 abi_word_2)
                      a!7)
                 initial_caller_bytes
                 (ite a!8
                      initial_caller_bytes
                      (ite a!1 initial_caller_bytes a!16)))))
(let ((a!5 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (not a!4)
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!11 (and (not (bvule abi_word_2 abi_word_0))
                 (bvule abi_word_0 abi_word_2)
                 (not a!4)
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
(let ((a!6 (or a!5
               (and (not (bvule abi_word_2 abi_word_0))
                    (not (bvule abi_word_0 abi_word_2)))
               false))
      (a!13 (ite a!11
                 (bvadd abi_word_0 abi_word_1)
                 (ite a!12
                      abi_word_2
                      (ite (bvule abi_word_2 abi_word_0)
                           abi_word_2
                           #x0000000000000000))))
      (a!18 (ite a!11
                 initial_caller_bytes
                 (ite a!12
                      initial_caller_bytes
                      (ite (bvule abi_word_2 abi_word_0)
                           initial_caller_bytes
                           initial_caller_bytes)))))
(let ((a!14 (ite (and (not (bvule abi_word_2 abi_word_0))
                      (not (bvule abi_word_0 abi_word_2)))
                 #x0000000000000000
                 (ite a!5 #x0000000000000000 a!13)))
      (a!19 (ite (and (not (bvule abi_word_2 abi_word_0))
                      (not (bvule abi_word_0 abi_word_2)))
                 initial_caller_bytes
                 (ite a!5 initial_caller_bytes a!18))))
(let ((a!15 (and (not a!2)
                 (distinct (ite (bvule abi_word_2 abi_word_0) abi_word_2 a!10)
                           a!14))))
  (or (distinct a!2 a!6)
      a!15
      (distinct (ite (bvule abi_word_2 abi_word_0) initial_caller_bytes a!17)
                a!19)))))))))

(check-sat)
