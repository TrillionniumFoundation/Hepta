(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(assert (let ((a!1 (not (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))))
      (a!2 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))))
      (a!3 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!4 (ite (and (not (bvule abi_word_2 abi_word_0))
                     (not (bvule abi_word_0 abi_word_2)))
                #x0000000000000000
                #x0000000000000000))
      (a!6 (ite (bvule (bvadd ((_ zero_extend 1) abi_word_0)
                              ((_ zero_extend 1) abi_word_1))
                       ((_ zero_extend 1) abi_word_2))
                ((_ extract 63 0)
                  (bvadd ((_ zero_extend 1) abi_word_0)
                         ((_ zero_extend 1) abi_word_1)))
                abi_word_2)))
(let ((a!5 (ite (and (not (bvule abi_word_2 abi_word_0))
                     (bvule abi_word_0 abi_word_2)
                     a!1)
                abi_word_2
                (ite a!2
                     (bvadd abi_word_0 abi_word_1)
                     (ite a!3 #x0000000000000000 a!4)))))
  (distinct (ite (bvule abi_word_2 abi_word_0) abi_word_2 a!5) a!6))))

(check-sat)
