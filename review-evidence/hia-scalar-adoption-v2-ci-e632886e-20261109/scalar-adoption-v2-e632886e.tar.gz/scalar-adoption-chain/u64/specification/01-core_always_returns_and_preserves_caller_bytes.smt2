(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_2 () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(assert (let ((a!1 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!2 (and (not (bvule abi_word_2 abi_word_0))
                (bvule abi_word_0 abi_word_2)
                (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))))
      (a!3 (not (bvule abi_word_1
                       (bvadd abi_word_2 (bvmul #xffffffffffffffff abi_word_0)))))
      (a!5 (ite (and (not (bvule abi_word_2 abi_word_0))
                     (not (bvule abi_word_0 abi_word_2)))
                initial_caller_bytes
                initial_caller_bytes)))
(let ((a!4 (or (and (not (bvule abi_word_2 abi_word_0))
                    (not (bvule abi_word_0 abi_word_2)))
               a!1
               a!2
               (and (not (bvule abi_word_2 abi_word_0))
                    (bvule abi_word_0 abi_word_2)
                    a!3)
               (bvule abi_word_2 abi_word_0)))
      (a!6 (ite (and (not (bvule abi_word_2 abi_word_0))
                     (bvule abi_word_0 abi_word_2)
                     a!3)
                initial_caller_bytes
                (ite a!2
                     initial_caller_bytes
                     (ite a!1 initial_caller_bytes a!5)))))
  (or (not a!4)
      (and (not (bvule abi_word_2 abi_word_0))
           (not (bvule abi_word_0 abi_word_2)))
      a!1
      false
      (distinct (ite (bvule abi_word_2 abi_word_0) initial_caller_bytes a!6)
                initial_caller_bytes)))))

(check-sat)
