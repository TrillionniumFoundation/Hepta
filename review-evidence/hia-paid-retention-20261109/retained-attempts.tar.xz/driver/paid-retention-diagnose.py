"""Retain a fresh regression attempt without replaying any older cell."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path('/workspace/scratch/728f6eb06ece/paid-observation-work')
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('targets', nargs='*')
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
fixtures = args.output / 'fixtures'
fixtures.mkdir()
sys.path.insert(0, str(ROOT))
targets = args.targets or [
    'tests.test_hia_paid_observation.PaidObservationTests.test_full_registered_matrix_keeps_failure_control_and_ndu_not_run',
    'tests.test_hia_paid_observation_retention.PaidObservationRetentionTests.test_effect_completed_then_evaluator_failure_retains_db_and_prior_cells',
    'tests.test_hia_paid_observation_retention.PaidObservationRetentionTests.test_lost_effect_ack_keeps_original_owner_and_pending_operation',
]
paths = ['tools/qualify_hia_paid_observation.py', 'tests/test_hia_paid_observation.py',
         'tests/test_hia_paid_observation_retention.py', 'benchmarks/hia_paid_observation/PROTOCOL.json']
source = {}
for name in paths:
    raw = (ROOT / name).read_bytes()
    target = args.output / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    source[name] = {'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}
protocol = json.loads((ROOT / paths[-1]).read_bytes())
assert protocol['wall_budget_ns'] == 2000000000
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
(args.output / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))
current_test = None
retained = []
original_temporary_directory = tempfile.TemporaryDirectory

class RetainedDirectory(original_temporary_directory):
    def __init__(self, *positional, **keywords):
        keywords.setdefault('dir', str(fixtures))
        super().__init__(*positional, **keywords)
        self._finalizer.detach()
        retained.append({'test': current_test, 'directory': self.name})
        (args.output / 'fixtures.json').write_text(json.dumps(retained, indent=2) + '\n')

    def cleanup(self):
        pass

class Result(unittest.TextTestResult):
    def startTest(self, test):
        global current_test
        current_test = test.id()
        super().startTest(test)

loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(targets)
planned = suite.countTestCases()
state = {'schema': 'hepta.hia.paid-retention.diagnostic.v1', 'status': 'RUNNING',
         'base_commit': base, 'source': source, 'targets': targets, 'planned_tests': planned,
         'registered_wall_budget_ns': protocol['wall_budget_ns'],
         'fixture_wrapper': 'Only TemporaryDirectory cleanup is disabled; original test bodies and registered protocol are unchanged.',
         'old_job_replayed': False, 'ndu_status': 'NOT_RUN'}
(args.output / 'RUNNING.json').write_text(json.dumps(state, indent=2) + '\n')
started = time.perf_counter_ns()
before = [resource.getrusage(kind) for kind in (resource.RUSAGE_SELF, resource.RUSAGE_CHILDREN)]
tempfile.TemporaryDirectory = RetainedDirectory
try:
    result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
finally:
    tempfile.TemporaryDirectory = original_temporary_directory
after = [resource.getrusage(kind) for kind in (resource.RUSAGE_SELF, resource.RUSAGE_CHILDREN)]
state.update(status='PASS' if result.wasSuccessful() and not result.skipped else 'FAIL',
             tests_run=result.testsRun, skipped=[(test.id(), reason) for test, reason in result.skipped],
             failures=[(test.id(), detail) for test, detail in result.failures],
             errors=[(test.id(), detail) for test, detail in result.errors],
             wall_ns=time.perf_counter_ns()-started,
             parent_cpu_ns=round(((after[0].ru_utime+after[0].ru_stime)-(before[0].ru_utime+before[0].ru_stime))*1e9),
             child_cpu_ns=round(((after[1].ru_utime+after[1].ru_stime)-(before[1].ru_utime+before[1].ru_stime))*1e9),
             original_source_unchanged=all(sha256((ROOT/name).read_bytes()).hexdigest()==value['sha256'] for name,value in source.items()),
             retained_fixtures=retained)
(args.output / 'RESULT.json').write_text(json.dumps(state, sort_keys=True, indent=2) + '\n')
print(json.dumps({'status':state['status'], 'tests_run':state['tests_run'], 'failures':len(state['failures']),
                  'errors':len(state['errors']), 'retained_fixtures':len(retained), 'output':str(args.output)}))
raise SystemExit(0 if state['status']=='PASS' else 1)
