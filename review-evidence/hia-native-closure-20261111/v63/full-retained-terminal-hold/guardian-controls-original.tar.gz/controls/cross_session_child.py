import json,os,pathlib,sys,time
ready=pathlib.Path(sys.argv[1]); mode=sys.argv[2]
leader=os.getpid()
pid=os.fork()
if pid==0:
    os.setsid()
    raw=pathlib.Path('/proc/self/stat').read_text()
    fields=raw[raw.rfind(')')+2:].split()
    ready.write_text(json.dumps({'leader':leader,'escaped':os.getpid(),'sid':os.getsid(0),
                                'start_ticks':int(fields[19])})+'\n')
    while True: time.sleep(1)
while not ready.exists(): time.sleep(.005)
if mode=='normal': raise SystemExit(0)
while True: time.sleep(1)
