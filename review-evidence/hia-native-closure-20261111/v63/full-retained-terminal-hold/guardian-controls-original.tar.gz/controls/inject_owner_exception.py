import importlib.util,pathlib,sys
guard_path,ready=sys.argv[1:3]
spec=importlib.util.spec_from_file_location('guard_under_test',guard_path)
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
load=guard.load_owner
class InjectedOwnerFault(BaseException): pass
def altered(path):
    owner=load(path);observe=owner.observe
    def once(pid):
        if pathlib.Path(ready).exists():
            owner.observe=observe
            raise InjectedOwnerFault('real owner observation fault after cross-session fork')
        return observe(pid)
    owner.observe=once
    return owner
guard.load_owner=altered
sys.argv=[guard_path,*sys.argv[3:]]
raise SystemExit(guard.main())
