# External ROG qualification guardian

This is hosted control machinery for the exact published v63 source, not an
additional HIA runtime owner or a whole-native completion claim. The Git source
tree, v5 qualification runner, adjacent `workflow_process.py`, and original
180-second cold owner remain byte-identical to the published source.

The controller uses the frozen `tools/hia_selfhost_process_owner.py` lifecycle
implementation (SHA-256 `36946082b3345f45ee2b28f1f810a22936d182a586cd0404154dfb01b3bd53a2`).
It calls `supervise` in a fresh, single-threaded process with an independent
10,800-second external deadline and a distinct external schema. It does not
call or modify the cold owner's `run_owned` admission or its 180-second limit.
The source copy is retained verbatim as `process_owner_impl.py`.

One child performs the bounded incremental Git fetch, checks the exact published
HEAD and frozen tree, verifies the 583 contract sources plus the contract, copies
and checks both pinned qualification controls, and execs the original v5 runner.
That child's process identity persists across exec. The external subreaper
therefore spans both preparation and the complete qualification, including
descendants that enter different sessions. Git steps retain the original
process-group controls and direct log files; the additional subreaper handles
their owner-interruption gap.

SIGINT, SIGTERM, parent-death notification, a controller deadline, or a caught
owner BaseException produces HOLD, followed by bounded identity-checked kill,
wait/reap and kernel ECHILD verification. A complete outer result also requires
the unchanged v5 report to say `FULL_RETAINED_PASS` for the exact HEAD, tree and
cold contract. It cannot upgrade an interrupted, missing or partial result.

Hard SIGKILL of the external guardian, host loss, privileged interference and
hostile process namespaces are outside the cleanup claim. Cleanup failure is
retained as HOLD. The outer lifecycle receipt is not a substitute for the cold
owner's independent cleanup proof.

The five real local controls fork a descendant that calls `setsid`. They cover
normal leader exit, an actual deadline, SIGTERM, SIGINT, and one injected owner
BaseException after the descendant is running. They verify start identities,
actual process disappearance, leader and adopted-descendant reaping, and kernel
ECHILD. All five passed; no fixture needed cleanup outside the guardian. Raw
receipts and custody hashes are in `../rog-guardian-controls-r1/`. These controls
qualify this external lifecycle mechanism only; they are not retained-product
or native-runtime tests.
