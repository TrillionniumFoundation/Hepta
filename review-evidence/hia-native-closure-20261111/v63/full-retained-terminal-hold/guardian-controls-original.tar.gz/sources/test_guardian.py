"""Real cross-session process controls for the external guardian; no HIA gate claim."""
from hashlib import sha256
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
GUARDIAN = HERE / 'guardian.py'
IMPL = HERE / 'process_owner_impl.py'
EVIDENCE = Path('/workspace/scratch/e26ed3e2edcf/rog-guardian-controls-r1')

FIXTURE = '''import json,os,pathlib,sys,time
ready=pathlib.Path(sys.argv[1]); mode=sys.argv[2]
leader=os.getpid()
pid=os.fork()
if pid==0:
    os.setsid()
    raw=pathlib.Path('/proc/self/stat').read_text()
    fields=raw[raw.rfind(')')+2:].split()
    ready.write_text(json.dumps({'leader':leader,'escaped':os.getpid(),'sid':os.getsid(0),
                                'start_ticks':int(fields[19])})+'\\n')
    while True: time.sleep(1)
while not ready.exists(): time.sleep(.005)
if mode=='normal': raise SystemExit(0)
while True: time.sleep(1)
'''

FAULT_WRAPPER = '''import importlib.util,pathlib,sys
guard_path,ready=sys.argv[1:3]
spec=importlib.util.spec_from_file_location('guard_under_test',guard_path)
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
load=guard.load_owner
class InjectedOwnerFault(BaseException): pass
def altered(path):
    owner=load(path);observe=owner.observe
    def once(pid):
        if pathlib.Path(ready).exists():
            owner.observe=observe
            raise InjectedOwnerFault('real owner observation fault after cross-session fork')
        return observe(pid)
    owner.observe=once
    return owner
guard.load_owner=altered
sys.argv=[guard_path,*sys.argv[3:]]
raise SystemExit(guard.main())
'''


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def current_identity(pid):
    try:
        raw = Path('/proc/%d/stat' % pid).read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = raw[raw.rfind(')') + 2:].split()
    return {'pid': pid, 'state': fields[0], 'start_ticks': int(fields[19])}


class ExternalGuardianControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        EVIDENCE.mkdir(mode=0o700)
        cls.fixture = EVIDENCE / 'cross_session_child.py'
        cls.fixture.write_text(FIXTURE)
        cls.fault = EVIDENCE / 'inject_owner_exception.py'
        cls.fault.write_text(FAULT_WRAPPER)
        cls.records = []

    @classmethod
    def tearDownClass(cls):
        (EVIDENCE / 'observations.json').write_text(json.dumps({
            'schema': 'external-guardian-real-process-controls.v1',
            'guardian_sha256': digest(GUARDIAN), 'implementation_sha256': digest(IMPL),
            'test_sha256': digest(__file__), 'records': cls.records,
            'product_or_cold_qualification_claimed': False,
        }, indent=2, sort_keys=True) + '\n')

    def exercise(self, name, *, interrupt=None, seconds=10, fault=False):
        folder = EVIDENCE / name
        folder.mkdir(mode=0o700)
        ready = folder / 'escaped.ready.json'
        request = {
            'schema': 'hia-external-guardian-request.v1',
            'command': [sys.executable, '-B', str(self.fixture), str(ready),
                        'normal' if name == 'normal' else 'wait'],
            'cwd': str(folder), 'controller_seconds': seconds,
            'source_identities': {str(GUARDIAN): digest(GUARDIAN),
                                  str(IMPL): digest(IMPL),
                                  str(self.fixture): digest(self.fixture)},
        }
        if fault:
            request['source_identities'][str(self.fault)] = digest(self.fault)
        config = folder / 'request.json'
        config.write_text(json.dumps(request, sort_keys=True) + '\n')
        arguments = ['--config', str(config), '--config-sha256', digest(config),
                     '--implementation', str(IMPL)]
        command = ([sys.executable, '-B', str(self.fault), str(GUARDIAN), str(ready)]
                   if fault else [sys.executable, '-B', str(GUARDIAN)]) + arguments
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        info = None
        compensation = False
        try:
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline and not ready.exists() and process.poll() is None:
                time.sleep(.005)
            self.assertTrue(ready.exists(), 'real different-session descendant never became ready')
            info = json.loads(ready.read_text())
            self.assertEqual(info['sid'], info['escaped'])
            if interrupt is not None:
                os.kill(process.pid, interrupt)
            stdout, stderr = process.communicate(timeout=6)
            (folder / 'controller.stdout').write_bytes(stdout)
            (folder / 'controller.stderr').write_bytes(stderr)
            report = json.loads((folder / 'guardian.json').read_text())
            lifecycle = report['lifecycle']
            expected = {'normal': 'OWNED_PROCESS_COMPLETED',
                        'deadline': 'QUALIFICATION_TIMEOUT',
                        'sigterm': 'QUALIFICATION_INTERRUPTED',
                        'sigint': 'QUALIFICATION_INTERRUPTED',
                        'owner_exception': 'OWNER_FAILED'}[name]
            self.assertEqual(lifecycle['status'], expected, report)
            self.assertEqual(process.returncode, 0 if name == 'normal' else 1)
            self.assertEqual(report['status'], 'EXTERNAL_OWNED_PROCESS_COMPLETED'
                             if name == 'normal' else 'HOLD')
            self.assertTrue(lifecycle['cleanup']['complete'], lifecycle)
            self.assertTrue(lifecycle['cleanup']['observed_echild'], lifecycle)
            self.assertTrue(lifecycle['cleanup']['leader_reaped'], lifecycle)
            self.assertEqual(lifecycle['cleanup']['remaining_direct_children'], [])
            observed = {item['pid']: item for item in lifecycle['direct_and_adopted_children']}
            self.assertIn(info['escaped'], observed)
            self.assertEqual(observed[info['escaped']]['start_ticks'], info['start_ticks'])
            self.assertEqual(observed[info['escaped']]['sid'], info['escaped'])
            identity_after = current_identity(info['escaped'])
            self.assertTrue(identity_after is None or identity_after['start_ticks'] != info['start_ticks'],
                            'escaped fixture survived the guardian')
            self.assertTrue(report['input_identity_preserved'])
            if interrupt is not None:
                self.assertIn(int(interrupt), lifecycle['interrupted_signals'])
            if fault:
                self.assertIn('InjectedOwnerFault', lifecycle.get('owner_error', ''))
            if name == 'deadline':
                self.assertTrue(lifecycle['timed_out'])
            self.records.append({'case': name, 'guardian_returncode': process.returncode,
                                 'guardian_status': report['status'], 'lifecycle_status': expected,
                                 'escaped_identity': info, 'escaped_identity_after': identity_after,
                                 'kernel_echild': True, 'cleanup_complete': True,
                                 'receipt_sha256': digest(folder / 'guardian.json')})
        finally:
            # Compensation is only a fixture fail-safe; any use fails this test.
            if process.poll() is None:
                compensation = True
                process.send_signal(signal.SIGTERM)
                try:
                    process.wait(timeout=4)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
            if info is not None:
                identity = current_identity(info['escaped'])
                if identity is not None and identity['start_ticks'] == info['start_ticks']:
                    compensation = True
                    os.kill(info['escaped'], signal.SIGKILL)
            self.assertFalse(compensation, 'fixture required cleanup outside the guardian')

    def test_normal_exit_reaps_different_session_descendant(self):
        self.exercise('normal')

    def test_deadline_reaps_different_session_descendant(self):
        self.exercise('deadline', seconds=.8)

    def test_sigterm_reaps_different_session_descendant(self):
        self.exercise('sigterm', interrupt=signal.SIGTERM)

    def test_sigint_reaps_different_session_descendant(self):
        self.exercise('sigint', interrupt=signal.SIGINT)

    def test_owner_baseexception_reaps_different_session_descendant(self):
        self.exercise('owner_exception', fault=True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
