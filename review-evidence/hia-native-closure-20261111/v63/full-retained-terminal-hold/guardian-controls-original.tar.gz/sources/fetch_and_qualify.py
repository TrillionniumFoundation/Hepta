"""Prepare pinned v63 sources in an owned ROG directory, then exec unchanged v5 qualification.

No operation occurs without a final published-head argument. This program is a
hosted custody driver; it neither changes the product gates nor claims whole HIA delivery.
"""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat
import sys

ROOT = Path('/var/tmp/he26v63')
SOURCE = ROOT / 's'
CONTROL = ROOT / 'control'
TMP = ROOT / 't'
OUTPUT = ROOT / 'q'
OLD_SOURCE = Path('/var/tmp/hia9acdfa/source')
PYTHON = Path('/home/qian-qi/.openclaw/workspaces/azi5/tasks/hia-selfhost-completion-20261109/venv/bin/python')
REPOSITORY = 'https://github.com/TrillionniumFoundation/Hepta.git'
BRANCH = 'refs/heads/codex/hia-native-closure-20261111-e26e'
BASE = 'c80eb2ecc5d08421a3d124c879edb33cefff2267'
TREE = '0a67bf07951505a50e9aeb888f1c2c448d1eb816'
PREP_SHA256 = '8de14e37b792d1f9e5a63107dcf05a4ce56700bc365ff5cbbbb247a0bf6b4ed5'
CONTRACT = 'docs/HIA_SELFHOST_CORE_SUPPORT.json'
CONTRACT_SHA256 = '80ed89ca6806136d8fae8c179992fa3ea72228e75a0f8d4e2439ab29b2b2af1e'
PROFILE = 'selfhost-core-linux-x86_64-v63-native-request-release-signatures-helpers'
RUNNER = 'review-evidence/hia-native-closure-20261111/run_hia_qualification_v5.py'
RUNNER_SHA256 = 'f98b8001c34fc2cc6fd64842de7615727f067abb531f935cf725a6164fb0e4d0'
HELPER = 'review-evidence/hia-native-rewrite-20261111/workflow_process.py'
HELPER_SHA256 = 'f3ebc453de2d2c9ecd3825547e301c122b6c7fa05af1aacd9103b8a67893ee80'
BOOTSTRAP_HELPER_SOURCE = "\"\"\"Bound external test-workflow steps without altering any product qualification gate.\n\nThis supervisor observes only its POSIX process group. It does not replace the\nSelfhost-Core owner's 180-second deadline or its stronger subreaper/ECHILD proof.\n\"\"\"\nfrom hashlib import sha256\nimport json\nimport os\nfrom pathlib import Path\nimport signal\nimport subprocess\nimport time\n\n\ndef run_workflow_step(command, *, cwd, env, stdout_path, stderr_path,\n                      receipt_path, seconds):\n    assert 0 < seconds <= 7200\n    stdout_path, stderr_path, receipt_path = map(Path, (stdout_path, stderr_path, receipt_path))\n    assert not any(p.exists() for p in (stdout_path, stderr_path, receipt_path))\n    started = time.monotonic()\n    timed_out = False\n    cleanup_errors = []\n    signalled = []\n    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:\n        process = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,\n                                   stdout=stdout, stderr=stderr, start_new_session=True)\n        try:\n            returncode = process.wait(timeout=seconds)\n        except subprocess.TimeoutExpired:\n            timed_out = True\n            returncode = None\n        try:\n            os.killpg(process.pid, 0)\n            group_alive = True\n        except ProcessLookupError:\n            group_alive = False\n        if group_alive:\n            for sig, grace in ((signal.SIGTERM, 1), (signal.SIGKILL, 2)):\n                try:\n                    os.killpg(process.pid, sig)\n                    signalled.append(sig.name)\n                except ProcessLookupError:\n                    break\n                deadline = time.monotonic() + grace\n                while time.monotonic() < deadline:\n                    process.poll()\n                    try:\n                        os.killpg(process.pid, 0)\n                    except ProcessLookupError:\n                        break\n                    time.sleep(0.01)\n                else:\n                    continue\n                break\n        try:\n            returncode = process.wait(timeout=1)\n        except subprocess.TimeoutExpired:\n            cleanup_errors.append('workflow leader could not be reaped')\n        try:\n            os.killpg(process.pid, 0)\n            group_gone = False\n        except ProcessLookupError:\n            group_gone = True\n    completed = returncode == 0 and not timed_out and not group_alive and group_gone and not cleanup_errors\n    report = {'schema':'hepta.hia.external-workflow-process.v1',\n              'status':'WORKFLOW_STEP_COMPLETED' if completed else 'WORKFLOW_STEP_HOLD',\n              'command':list(command), 'cwd':str(cwd), 'returncode':returncode,\n              'timed_out':timed_out,'seconds':time.monotonic()-started,\n              'workflow_seconds':seconds,\n              'cleanup':{'scope':'started POSIX process group only','complete':group_gone,\n                         'full_process_tree_claimed':False,'signalled':signalled,'errors':cleanup_errors},\n              'selfhost_qualification_gate_modified':False,\n              'logs':{str(p):sha256(p.read_bytes()).hexdigest() for p in (stdout_path,stderr_path)}}\n    receipt_path.write_text(json.dumps(report,indent=2)+'\\n')\n    return report\n"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def say(record):
    print(json.dumps(record, sort_keys=True), flush=True)


def private_directory(path):
    info = path.lstat()
    require(stat.S_ISDIR(info.st_mode) and info.st_uid == os.geteuid()
            and stat.S_IMODE(info.st_mode) == 0o700,
            'expected owned private directory: ' + str(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--published-head', required=True)
    parser.add_argument('--published-confirmed', action='store_true', required=True)
    args = parser.parse_args()
    require(args.published_confirmed and re.fullmatch(r'[0-9a-f]{40}', args.published_head),
            'a confirmed complete published Git SHA is required')
    expected_head = args.published_head
    os.umask(0o077)
    private_directory(ROOT)
    require(SOURCE.is_dir() and not SOURCE.is_symlink(), 'private source is unavailable')
    require((SOURCE / '.git').is_dir() and not (SOURCE / '.git').is_symlink(),
            'private source Git directory is unavailable')
    prep_raw = (ROOT / 'prep.json').read_bytes()
    require(sha256(prep_raw).hexdigest() == PREP_SHA256, 'original local preparation receipt changed')
    prep = json.loads(prep_raw)
    require(prep['status'] == 'LOCAL_C80_SOURCE_READY_NO_FETCH_NO_TESTS'
            and prep['destination_head'] == BASE and prep['source_head_unchanged'] is True
            and prep['no_alternates'] is True and prep['no_source_object_hardlinks'] is True,
            'original independent preparation was not completed')
    helper_bytes = BOOTSTRAP_HELPER_SOURCE.encode('utf-8')
    require(sha256(helper_bytes).hexdigest() == HELPER_SHA256,
            'pinned bootstrap workflow owner bytes changed')
    require(not any(os.path.lexists(path) for path in (CONTROL, TMP, OUTPUT)),
            'create-only control/temp/output already exists; reconcile the original job')
    CONTROL.mkdir(mode=0o700)
    TMP.mkdir(mode=0o700)
    namespace = {'__name__': 'pinned_workflow_bootstrap'}
    exec(compile(BOOTSTRAP_HELPER_SOURCE, '<pinned-workflow-owner>', 'exec'), namespace)
    run_workflow_step = namespace['run_workflow_step']
    environment = dict(os.environ)
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1',
                       TMPDIR=str(TMP), GIT_TERMINAL_PROMPT='0', GIT_OPTIONAL_LOCKS='0')
    steps = []
    custody = {
        'schema': 'hia-rog-v63-source-fetch-and-qualification-start.v1',
        'published_head': expected_head, 'expected_tree': TREE,
        'root': str(ROOT), 'source': str(SOURCE), 'output': str(OUTPUT),
        'private_tmpdir': str(TMP), 'base_local_preparation_sha256': PREP_SHA256,
        'baseline': BASE, 'git_network_clone_performed': False,
        'workflow_owner_scope': 'started POSIX process group only',
        'cold_180_second_owner_gate_modified': False,
        'whole_native_delivery_qualified': False,
        'steps': steps,
    }
    custody_path = CONTROL / 'fetch-preparation.json'

    def save():
        custody_path.write_text(json.dumps(custody, indent=2, sort_keys=True) + '\n')

    def run(label, command, seconds=60):
        say({'starting_preparation': label})
        stdout = CONTROL / (label + '.stdout.log')
        stderr = CONTROL / (label + '.stderr.log')
        owner = run_workflow_step(command, cwd=SOURCE, env=environment,
                                  stdout_path=stdout, stderr_path=stderr,
                                  receipt_path=CONTROL / (label + '.owner.json'),
                                  seconds=seconds)
        steps.append({'label': label, 'owner': owner})
        save()
        require(owner.get('status') == 'WORKFLOW_STEP_COMPLETED'
                and owner.get('returncode') == 0 and owner.get('timed_out') is False
                and owner.get('cleanup', {}).get('complete') is True,
                'owned preparation step did not complete: ' + label)
        return stdout.read_text().strip()

    def git(*arguments):
        return ['/usr/bin/git', '--no-replace-objects', '-c', 'core.hooksPath=/dev/null',
                '-C', str(SOURCE), *arguments]

    try:
        private_directory(SOURCE)
        require(run('base-head', git('rev-parse', '--verify', 'HEAD')) == BASE,
                'private source changed since local preparation')
        require(not os.path.lexists(SOURCE / '.git/objects/info/alternates')
                and not os.path.lexists(SOURCE / '.git/objects/info/http-alternates'),
                'private source unexpectedly depends on alternates')
        custody['original_source_head_before'] = run(
            'original-head-before', ['/usr/bin/git', '--no-replace-objects', '-C',
                                     str(OLD_SOURCE), 'rev-parse', '--verify', 'HEAD'])
        require(custody['original_source_head_before'] == BASE, 'original c80 source HEAD changed')
        advertised = run('published-branch', git('ls-remote', '--exit-code', '--heads',
                                                REPOSITORY, BRANCH), seconds=90)
        require(advertised.splitlines() == [expected_head + '\t' + BRANCH],
                'public branch is not the operator-confirmed final commit')
        run('private-origin', git('remote', 'set-url', 'origin', REPOSITORY))
        fetch = git('-c', 'http.lowSpeedLimit=1', '-c', 'http.lowSpeedTime=60',
                    'fetch', '--no-tags', REPOSITORY, expected_head)
        run('incremental-fetch', fetch, seconds=900)
        require(run('fetched-head', git('rev-parse', '--verify', 'FETCH_HEAD')) == expected_head,
                'fetch did not produce the exact confirmed commit')
        require(run('fetched-tree', git('rev-parse', '--verify', expected_head + '^{tree}')) == TREE,
                'published commit differs from the frozen complete Git tree')
        run('fetched-object-integrity', git('fsck', '--full', '--no-reflogs', '--no-dangling'),
            seconds=120)
        run('checkout', git('checkout', '--quiet', '--detach', expected_head), seconds=120)
        require(run('checkout-head', git('rev-parse', '--verify', 'HEAD')) == expected_head,
                'checked-out HEAD is not exact')
        require(run('checkout-tree', git('rev-parse', '--verify', 'HEAD^{tree}')) == TREE,
                'checked-out tree is not exact')
        require(run('checkout-clean', git('status', '--porcelain=v1', '--untracked-files=all')) == '',
                'qualification source checkout is not clean')
        contract_raw = (SOURCE / CONTRACT).read_bytes()
        require(sha256(contract_raw).hexdigest() == CONTRACT_SHA256,
                'checked-out cold contract differs from the frozen source')
        contract = json.loads(contract_raw)
        files = contract['source_identity']['files']
        require(contract['profile'] == PROFILE and len(files) == 583,
                'unexpected v63 profile or source closure size')
        for name, expected in files.items():
            path = Path(name)
            require(not path.is_absolute() and '..' not in path.parts,
                    'noncanonical source contract path')
            require(sha256((SOURCE / path).read_bytes()).hexdigest() == expected,
                    'source contract bytes differ: ' + name)
        manifest = {**files, CONTRACT: CONTRACT_SHA256}
        require(len(manifest) == 584, 'cold source manifest does not contain 584 entries')
        (CONTROL / 'cold-source-manifest-before.json').write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + '\n')
        copies = {}
        for relative, filename, expected in (
            (RUNNER, 'run_hia_qualification_v5.py', RUNNER_SHA256),
            (HELPER, 'workflow_process.py', HELPER_SHA256),
        ):
            raw = (SOURCE / relative).read_bytes()
            require(sha256(raw).hexdigest() == expected, 'frozen control source differs: ' + relative)
            target = CONTROL / filename
            with target.open('xb') as stream:
                stream.write(raw)
            require(target.read_bytes() == (SOURCE / relative).read_bytes(),
                    'control copy differs from its pinned source')
            copies[filename] = {'source': relative, 'path': str(target), 'sha256': expected}
        require((CONTROL / 'workflow_process.py').read_bytes() == helper_bytes,
                'source supervisor differs from the supervisor used for preparation')
        custody['original_source_head_after'] = run(
            'original-head-after', ['/usr/bin/git', '--no-replace-objects', '-C',
                                    str(OLD_SOURCE), 'rev-parse', '--verify', 'HEAD'])
        require(custody['original_source_head_after'] == BASE, 'original source HEAD changed')
        custody.update(status='EXACT_SOURCE_READY_FOR_UNCHANGED_V5_FULL_QUALIFICATION',
                       source_contract_sha256=CONTRACT_SHA256, source_count=583,
                       cold_manifest_count=584, controls=copies,
                       original_source_head_unchanged=True,
                       no_shared_alternates=True, production_state_modified=False,
                       qualification_started=False)
        save()
        say({key: custody[key] for key in ('status', 'published_head', 'expected_tree',
                                           'source_count', 'cold_manifest_count')})
        qualified_env = dict(os.environ)
        qualified_env.pop('PYTHONPATH', None)
        qualified_env.pop('PYTHONHOME', None)
        qualified_env.update(
            PATH=str(PYTHON.parent) + os.pathsep + qualified_env.get('PATH', '/usr/bin:/bin'),
            VIRTUAL_ENV=str(PYTHON.parent.parent), TMPDIR=str(TMP),
            PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1', PYTHONNOUSERSITE='1',
            CLANG='/usr/bin/clang-20', HEPTA_CLANG='/usr/bin/clang-20',
        )
        argv = [str(PYTHON), '-B', str(CONTROL / 'run_hia_qualification_v5.py'),
                '--source', str(SOURCE), '--output', str(OUTPUT), '--full']
        custody['qualification_command'] = argv
        custody['qualification_exec_requested'] = True
        save()
        os.execve(str(PYTHON), argv, qualified_env)
    except BaseException as error:
        custody['status'] = 'PREPARATION_FAILED_OR_HOLD'
        custody['error'] = type(error).__name__ + ': ' + str(error)
        save()
        say({'status': custody['status'], 'error': custody['error']})
        raise


if __name__ == '__main__':
    main()
