"""Necessary helper layout, quota, encoding and fail-closed boundary controls.

Synthetic descriptor graphs below are explicitly PRIVATE adapter-contract
controls, issued through the actual HIA type validator. They are not claimed
to be public source programs accepted by the semantic type owner.
"""
from contextlib import ExitStack
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import resource
import struct
import time
import traceback

from helper_harness import ROOT, BASE, Images, HelperSession, NativeIR, MAGIC, HELPER_INIT, BAD, CANARY, frozen_module, no_host_semantics
from hepta import hia_task_helpers_native as helper_module
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_program import HIAProgramRejected
from hepta.hia_composite_types_native import PRIMITIVES
from tests.test_hia_task_helpers_native import helper_owner

resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(1024<<20,1024<<20))
OUT=ROOT/'development/boundaries-reconstructed-r3-attempt1'
OUT.mkdir(exist_ok=False)
own_raw=Path(__file__).read_bytes()
harness_raw=(ROOT/'development/helper_harness.py').read_bytes()
dependencies=json.loads((ROOT/'development/dependencies-ready.json').read_bytes())
helper_row=dependencies['task_helper']
helper_source=Path(helper_row['source_path']).read_bytes()
helper_image=Path(helper_row['image_path']).read_bytes()
assert sha256(helper_source).hexdigest()==helper_row['source_sha256'] and sha256(helper_image).hexdigest()==helper_row['image_sha256']
helper_reference=helper_module.NativeTaskHelpers(helper_image,helper_row['image_sha256'])
actual_helper=NativeHiaJsonImage(helper_image,helper_row['image_sha256'])
type_harness,type_harness_raw=frozen_module('helper_boundary_types',ROOT/'dependencies/types/development/transport_harness.py')
images=Images(ROOT/'development/compile-reconstructed-r3/bundle.json',OUT/'actual-helper-transport')
ir=NativeIR(OUT/'actual-ir')
initial_command=(ROOT/'development/pipeline-reconstructed-r3-attempt1/types-0-0.command.json').read_bytes()
initial_frame=(ROOT/'development/pipeline-reconstructed-r3-attempt1/types-0-0.response.bin').read_bytes()
cases=[]
session=None
transport=None
counter=0
actual_helper_entries=0
reference_helper_entries=0
type_transport_entries=0
templates={}
started=time.monotonic_ns()


def ids(values):
    return [PRIMITIVES.index(value)+1 for value in values]


def private_registry(label, states, results, reverse=False):
    owner,typ=helper_owner(states,results,reverse=reverse,effects=('trap','alloc','read','write'))
    step=owner.signatures['poll'][1][0]
    t=type_harness.NativeTransport(ROOT/'development/type-transport-recovered-bundle.json',
        lease=500+len(cases),ledger=OUT/(label+'.types.jsonl'))
    assert t.begin(json.loads(initial_command),1)[0]==128
    assert t.reply(initial_frame)[0]==128
    variants=[['pending',[['state',17]]],['ready',[['result',18]]]]
    if reverse:variants.reverse()
    desc=[
        type_harness.descriptor(17,'State',flat=ids(states)),
        type_harness.descriptor(18,'Result',flat=ids(results)),
        type_harness.descriptor(19,'Step',kind='enum',flat=ids(step.flat),variants=variants),
        type_harness.descriptor(20,'Task',kind='task',flat=ids(typ.flat),state=17,result=18,
                                poll='poll',cancel='cancel',linear=True)]
    command={'op':'resolve','ref':'PRIVATE_SYNTHETIC_HELPER_TASK'}
    frame=type_harness.frame({'types':desc},identifier=20,counters=(4,0,4))
    assert t.begin(command,3)[0]==128
    result,event,_=t.reply(frame)
    assert result==128 and event[6]==0
    (OUT/(label+'.private-descriptors.json')).write_text(json.dumps(desc,indent=2,sort_keys=True)+'\n')
    (OUT/(label+'.private-type-frame')).write_bytes(frame)
    return t,owner,typ,step


def projected(t, command, *, serial=0, source_reference=True, save_template=False):
    global session,counter
    counter+=1
    metadata,source,lease,stream,slots=ir.encode(command,serial=serial,request=1000+counter,
                                              source_reference=source_reference)
    config=(HELPER_INIT,3000+counter,lease,stream,1000+counter,serial,slots,
            t.lease,t.sequence,t.query_sequence+1,0,0,0,0,0,0)
    session=HelperSession(images,config)
    with no_host_semantics():
        result=session.finish('request',metadata,source)
        if save_template:
            templates.update(metadata=metadata,source=source,config=config)
        while result[0]==256 and result[1][1]==1:
            event=result[1]
            query=session.view(event[14],event[15])
            qresult,qevent,_=t.call('commands',query)
            assert qresult==128 and qevent[1]==0
            qwire=struct.pack('<16Q',*qevent)
            borrowed=ctypes.string_at(t.workspace,t.size)
            if save_template and 'pending' not in templates:
                templates.update(pending=bytes(session.work[:session.size]),query=qwire,query_borrowed=borrowed)
            elif save_template and 'pending_second' not in templates:
                templates.update(pending_second=bytes(session.work[:session.size]),query_second=qwire,query_second_borrowed=borrowed)
            result=session.finish('request',qwire,borrowed)
        if result[0]==256 and result[1][1]==3:
            t.query_sequence=result[1][8]
            if save_template:
                templates['ready']=bytes(session.work[:session.size])
    return result


def helper_call(wire):
    global actual_helper_entries
    source=ctypes.create_string_buffer(wire+CANARY)
    output=ctypes.create_string_buffer((4<<20)+32)
    state=ctypes.create_string_buffer((2<<20)+32)
    ctypes.memset(ctypes.addressof(output)+(4<<20),0xb9,32)
    ctypes.memset(ctypes.addressof(state)+(2<<20),0xb9,32)
    with no_host_semantics():
        extent=actual_helper._entry(source,len(wire),output,4<<20,state,2<<20)
    actual_helper_entries+=1
    assert 64<=extent<=4<<20
    assert ctypes.string_at(source,len(wire)+32)==wire+CANARY
    assert ctypes.string_at(ctypes.addressof(output)+(4<<20),32)==CANARY
    assert ctypes.string_at(ctypes.addressof(state)+(2<<20),32)==CANARY
    return ctypes.string_at(output,extent),ctypes.string_at(state,2<<20)


def completed(label,t,owner,typ,step,operation,serial=0,save_template=False):
    global session,reference_helper_entries
    poll=owner.functions['poll']['effects'];cancel=owner.functions['cancel']['effects']
    expected=helper_module.packet(typ,step,operation,serial,poll,cancel)
    reference=helper_reference.generate_packet(expected,serial=serial)
    reference_helper_entries+=1
    owner.serial=serial;owner.helpers=[];owner.helper_names={}
    old_error=None
    try:
        old_name=owner._reference_helper(typ,operation)
    except HIAProgramRejected as exc:
        old_name=None;old_error=(exc.code,str(exc))
    assert owner.serial==reference.serial
    if reference.error:
        code,message=helper_module.ERRORS[reference.error]
        assert old_error==(code,code+': '+message)
    else:
        assert old_error is None and old_name==reference.name and owner.helpers[-1]==reference.helper
    result=projected(t,[6,20,19,operation,serial,poll,cancel],serial=serial,save_template=save_template)
    assert result[0]==256 and result[1][1]==3,result
    wire=session.view(result[1][14],result[1][15])
    assert wire==expected
    frame,state=helper_call(wire)
    if save_template:
        templates.update(frame=frame,helper_workspace=state,expected_helper=reference.helper)
    with no_host_semantics():
        result=session.finish('reply',frame,state)
    assert result[0]==256 and result[1][1]==4,result
    event=result[1]
    assert event[10:14]==(serial,reference.serial,reference.error,
                          0 if reference.name is None else int(reference.name[11:]))
    name=b'' if reference.name is None else reference.name.encode()
    expected_cont=struct.pack('<8Q',MAGIC(b'HIAFLR01'),session.config[4],6,reference.error,0,
                              reference.serial,len(name),0)+name
    actual_cont=session.view(event[18],event[19])
    assert actual_cont==expected_cont
    payload=session.view(event[16],event[17]) if event[17] else b''
    if reference.error:assert not payload
    else:assert detached_packet_index(payload)[0]==reference.helper
    assert session.view(event[24],event[25])==frame[:64] and event[26]==len(frame)
    (OUT/(label+'.packet')).write_bytes(wire)
    (OUT/(label+'.frame')).write_bytes(frame)
    (OUT/(label+'.helper.packet')).write_bytes(payload)
    row={'case':label,'status':'PASS','private_descriptor_graph':True,'error':reference.error,
         'counter':reference.serial,'packet_bytes':len(wire),'frame_bytes':len(frame),
         'full_old_host_and_old_native_result_equal':True,'helper_transport_entries':session.calls,
         'grows':session.grows,'last_query_sequence':event[8]}
    cases.append(row);print(json.dumps(row,sort_keys=True),flush=True)
    session.close();session=None


def clone(name):
    global session
    if session is not None:session.close()
    snapshot=templates[name]
    session=HelperSession(images,templates['config'],size=len(snapshot))
    ctypes.memmove(session.work,snapshot,len(snapshot))
    return session


def edit_q(raw,index,value):
    out=bytearray(raw);struct.pack_into('<Q',out,index*8,value);return bytes(out)


def permanent(label,which,command,borrowed):
    result=session.finish(which,command,borrowed)
    assert result[0]==BAD,(label,result)
    before=bytes(session.work)
    # Both entry points must refuse every subsequent valid family; no error
    # may retain a usable lease through the other shared-workspace kernel.
    for kernel,wire,lease in [
        ('request',templates['metadata'],templates['source']),
        ('request',templates['query'],templates['query_borrowed']),
        ('reply',templates['frame'],templates['helper_workspace']),
    ]:
        assert session.call(kernel,wire,lease)[0]==BAD,label
        assert bytes(session.work)==before,label
    row={'case':label,'status':'PERMANENT_BAD','both_kernels_after_error_unchanged':True}
    cases.append(row);print(json.dumps(row,sort_keys=True),flush=True)


def payload_frame(payload):
    frame=templates['frame']
    header=list(struct.unpack_from('<8Q',frame));header[4]=len(payload)
    raw=struct.pack('<8Q',*header)+payload
    state=bytearray(templates['helper_workspace']);struct.pack_into('<Q',state,4120,len(raw))
    return raw,bytes(state)


def decode_private_packet(raw):
    # Independent test-only decoding after native forwarding, including JSON
    # floating-number packet tag 3, which the public integer parser does not use.
    def node(at):
        kind,size=struct.unpack_from('<2Q',raw,at);start=at+16;stop=start+size
        assert stop<=len(raw)
        if kind==0:assert size==0;value=None
        elif kind==1:assert size==1;value=bool(raw[start])
        elif kind==2:value=int(raw[start:stop].decode('ascii'))
        elif kind==3:value=json.loads(raw[start:stop])
        elif kind==4:value=raw[start:stop].decode('utf8','surrogatepass')
        elif kind in (5,6):
            count=struct.unpack_from('<Q',raw,start)[0];p=start+8;values=[]
            for _ in range(count*(2 if kind==6 else 1)):
                value,p=node(p);values.append(value)
            assert p==stop
            value=values if kind==5 else dict(zip(values[::2],values[1::2]))
        else:raise AssertionError(kind)
        return value,stop
    value,stop=node(0);assert stop==len(raw);return value


summary=None
try:
    layouts=[
        ('zero-width',[],[],False),
        ('loan-state',['readbuf'],[],False),
        ('loan-result',[],['mutbuf'],True),
        ('all-sixteen-primitives',list(PRIMITIVES),[],True),
        ('max-512-slot-task',[],['buffer']*510,False),
    ]
    for label,states,results,reverse in layouts:
        transport,owner,typ,step=private_registry(label,states,results,reverse)
        for operation in ('start','poll','cancel','join','close'):
            completed(label+'-'+operation,transport,owner,typ,step,operation,
                      save_template=label=='zero-width' and operation=='start')
        type_transport_entries+=transport.calls;transport.close();transport=None
    assert {row['error'] for row in cases if 'error' in row}>={0,2,3}

    # Exact original 128 KiB input bound, with an opaque long operation. These
    # controls exercise transport only; the semantic helper never sees the
    # deliberately unrecognized operation string.
    transport,owner,typ,step=private_registry('packet-boundary',[],[])
    base=len(helper_module.packet(typ,step,'x',0,[],[]))
    for delta in (-1,0,1):
        operation='x'*(131072-base+1+delta)
        expected=helper_module.packet(typ,step,operation,0,[],[])
        result=projected(transport,[6,20,19,operation,0,[],[]])
        assert len(expected)==131072+delta
        if delta<=0:
            assert result[0]==256 and result[1][1]==3
            assert session.view(result[1][14],result[1][15])==expected
            row={'case':'packet-limit-'+str(delta),'status':'PASS','bytes':len(expected),
                 'scope':'PRIVATE_TRANSPORT_BOUNDARY_NO_SEMANTIC_HELPER_CALL'}
            cases.append(row);print(json.dumps(row,sort_keys=True),flush=True)
        else:
            assert result[0]==BAD
            permanent('packet-limit-plus-one','request',templates['query'],templates['query_borrowed'])
            before=bytes(session.work)
            assert session.call('reply',templates['frame'],templates['helper_workspace'])[0]==BAD
            assert bytes(session.work)==before
        session.close();session=None
    type_transport_entries+=transport.calls;transport.close();transport=None

    # Initial metadata and QUERY correlation failures use snapshots from actual
    # native-issued metadata and descriptor events, never a hosted registry.
    for index,value in [(0,1),(1,0),(2,999),(3,999),(4,999),(5,1),(6,1),(7,0),(8,0),(9,0),(10,1)]:
        session=HelperSession(images,templates['config'])
        struct.pack_into('<Q',session.work,256+index*8,value)
        permanent('initial-config-word-'+str(index),'request',templates['metadata'],templates['source'])
    for index,value in [(0,1),(1,1),(2,999),(3,999),(4,1),(5,7),(6,999),(7,1),(8,99),(15,0),(16,1),(17,0),(18,0),(23,1)]:
        session=HelperSession(images,templates['config'])
        permanent('ir-header-word-'+str(index),'request',edit_q(templates['metadata'],index,value),templates['source'])
    for index,value in [(0,1),(1,1),(2,999),(3,999),(4,999),(5,1),(6,1),(7,999),(11,3),(12,2),(13,(1<<64)-1),(14,0),(15,1)]:
        clone('pending')
        permanent('query-word-'+str(index),'request',edit_q(templates['query'],index,value),templates['query_borrowed'])
    for index in (8,9,10):
        clone('pending_second')
        permanent('query-changed-counter-'+str(index),'request',edit_q(templates['query_second'],index,99),templates['query_second_borrowed'])
    for label,wire in [('query-short',templates['query'][:-1]),('query-extra',templates['query']+b'\0')]:
        clone('pending');permanent(label,'request',wire,templates['query_borrowed'])
    clone('pending');permanent('wrong-kernel-while-query-pending','reply',templates['frame'],templates['helper_workspace'])
    clone('ready');permanent('query-replay-after-call-helper','request',templates['query'],templates['query_borrowed'])

    # Complete result header and exact borrowed actual helper state association.
    for index,value in [(0,1),(1,4),(2,8193),(3,2),(4,0),(5,1),(6,1),(7,1)]:
        clone('ready')
        permanent('helper-header-word-'+str(index),'reply',edit_q(templates['frame'],index,value),templates['helper_workspace'])
    for at,value in [(4096,999),(4104,1),(4120,0),(4128,1),(4152,2)]:
        clone('ready');state=bytearray(templates['helper_workspace']);struct.pack_into('<Q',state,at,value)
        permanent('helper-workspace-field-'+str(at),'reply',templates['frame'],bytes(state))
    for label,raw,state in [('helper-short',templates['frame'][:63],templates['helper_workspace']),
                            ('helper-trailing',templates['frame']+b'x',templates['helper_workspace']),
                            ('helper-workspace-short',templates['frame'],templates['helper_workspace'][:-1])]:
        clone('ready');permanent(label,'reply',raw,state)

    # Old full helper envelope and duplicate-key grammar, under actual new parser.
    for index,payload in enumerate([b'',b'null',b'{}',b'{"helper":null}',b'{"helper":{},"extra":0}',
        b'{"helper":{},"helper":{}}',b'{"helper":NaN}',b'{"helper":Infinity}',
        b'{"helper":{"name":"wrong","params":[],"returns":[],"effects":[],"entry":"b","blocks":[]}}',
        b'{"helper":{"name":"h2internal_1","params":0,"returns":[],"effects":[],"entry":"b","blocks":[]}}']):
        clone('ready');raw,state=payload_frame(payload);permanent('payload-reject-'+str(index),'reply',raw,state)

    good={'helper':{'name':'h2internal_1','params':['A\ud800Z','\U0010ffff','\0',1.25,-0.0,1e100],
                    'returns':[],'effects':[],'entry':'entry','blocks':[]}}
    text=json.dumps(good,ensure_ascii=False,separators=(',',':'))
    encodings=[('utf8',text.encode('utf8','surrogatepass')),
               ('utf8-bom',b'\xef\xbb\xbf'+text.encode('utf8','surrogatepass')),
               ('utf8-escaped',json.dumps(good,separators=(',',':')).encode()),
               ('utf16le',text.encode('utf-16-le','surrogatepass')),
               ('utf16be',text.encode('utf-16-be','surrogatepass')),
               ('utf16le-bom',b'\xff\xfe'+text.encode('utf-16-le','surrogatepass')),
               ('utf16be-bom',b'\xfe\xff'+text.encode('utf-16-be','surrogatepass')),
               ('utf32le',text.encode('utf-32-le','surrogatepass')),
               ('utf32be',text.encode('utf-32-be','surrogatepass')),
               ('utf32le-bom',b'\xff\xfe\0\0'+text.encode('utf-32-le','surrogatepass')),
               ('utf32be-bom',b'\0\0\xfe\xff'+text.encode('utf-32-be','surrogatepass'))]
    for label,payload in encodings:
        expected=json.loads(payload,object_pairs_hook=helper_module._pairs,parse_constant=helper_module._constant)
        clone('ready');raw,state=payload_frame(payload)
        with no_host_semantics():result=session.finish('reply',raw,state)
        assert result[0]==256 and result[1][1]==4,(label,result)
        value=decode_private_packet(session.view(result[1][16],result[1][17]))
        assert value==expected['helper']
        assert json.dumps(value,sort_keys=True,separators=(',',':'))==json.dumps(expected['helper'],sort_keys=True,separators=(',',':'))
        row={'case':'private-json-'+label,'status':'PASS','complete_value_equal':True,
             'floating_and_surrogate_private_values_preserved':True,'grows':session.grows,
             'public_integer_parser_unchanged':True}
        cases.append(row);print(json.dumps(row,sort_keys=True),flush=True)

    malformed=[b'\xff',b'\xef\xbb',b'\xff\xfe\0',b'\0\0\xfe\xff\0\x11\0\0',
               b'\x00',b'\0\0',b'{"helper":\x00}',b'{"helper":"\xc0\x80"}',
               b'{"helper":"\xf4\x90\x80\x80"}']
    for index,payload in enumerate(malformed):
        try:json.loads(payload,object_pairs_hook=helper_module._pairs,parse_constant=helper_module._constant)
        except (ValueError,UnicodeError):pass
        else:raise AssertionError('malformed fixture accepted by old JSON parser')
        clone('ready');raw,state=payload_frame(payload);permanent('private-encoding-invalid-'+str(index),'reply',raw,state)

    # The complete old 4 MiB result frame, including trailing JSON whitespace.
    minimal=json.dumps({'helper':templates['expected_helper']},separators=(',',':')).encode()
    for delta in (-1,0,1):
        total=(4<<20)+delta
        payload=minimal+b' '*(total-64-len(minimal))
        raw,state=payload_frame(payload)
        assert len(raw)==total
        clone('ready')
        if delta<=0:
            with no_host_semantics():result=session.finish('reply',raw,state)
            assert result[0]==256 and result[1][1]==4
            assert decode_private_packet(session.view(result[1][16],result[1][17]))==templates['expected_helper']
            row={'case':'result-limit-'+str(delta),'status':'PASS','frame_bytes':total,
                 'private_same_header_workspace_extent_control':True}
            cases.append(row);print(json.dumps(row,sort_keys=True),flush=True)
        else:
            permanent('result-limit-plus-one','reply',raw,state)

    summary={'status':'PASS','scope':'FRESH_RECONSTRUCTED_HELPER_PRIVATE_BOUNDARIES_NOT_PUBLIC_SOURCE_OR_COLD',
             'cases':cases,'actual_helper_entries':actual_helper_entries,'reference_helper_entries':reference_helper_entries,
             'type_transport_entries':type_transport_entries,'helper_transport_entries':images.entries,
             'ir_entries':ir.entries,'issuer_entries':ir.issuer.entries,'wall_elapsed_ns':time.monotonic_ns()-started,
             'original_limits_unchanged':True,'old_helper_r1_raw_not_reused':True,
             'private_float_scope':'Helper response grammar preserves float tag3; the public integer parser and later driver acceptance are separate unchanged boundaries.'}
except BaseException as exc:
    traceback.print_exc()
    summary={'status':'FAIL','cases':cases,'class':type(exc).__name__,'error':str(exc),
             'helper_transport_entries':images.entries}
    raise
finally:
    if session is not None:session.close()
    if transport is not None:transport.close()
    images.close();ir.close()
    assert Path(__file__).read_bytes()==own_raw and (ROOT/'development/helper_harness.py').read_bytes()==harness_raw
    assert Path(helper_row['source_path']).read_bytes()==helper_source and Path(helper_row['image_path']).read_bytes()==helper_image
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':summary['status'],'cases':len(cases),'entries':images.entries},sort_keys=True),flush=True)
