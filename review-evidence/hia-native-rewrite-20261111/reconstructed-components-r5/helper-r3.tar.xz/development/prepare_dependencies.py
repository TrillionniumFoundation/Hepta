"""Recover exact type dependencies and compile the unchanged real task helper."""
from pathlib import Path
from hashlib import sha256
import json
from tools.qualify_hia_selfhost import compile_stage

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-v66-restored')
COMPILER=Path('/workspace/scratch/9acdfa9f5639/native-composite-core-final-recovery-next/dependencies/f50-B3.image.bin')
compiler_raw=COMPILER.read_bytes()
assert sha256(compiler_raw).hexdigest()=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
source=BASE/'examples/hia_bootstrap/task_helpers.hiaasm'
raw=source.read_bytes()
out=ROOT/'development/actual-task-helper'
out.mkdir(parents=True,exist_ok=False)
image,receipt=compile_stage(out,'task-helper',COMPILER,raw)
assert receipt['input_sha256']==receipt['source_sha256']==sha256(raw).hexdigest()
assert receipt['artifact_sha256']==sha256(compiler_raw).hexdigest()
image_raw=image.read_bytes()
assert receipt['produced_sha256']==sha256(image_raw).hexdigest()
assert source.read_bytes()==raw and COMPILER.read_bytes()==compiler_raw
(out/'task_helpers.hiaasm').write_bytes(raw)
manifest={'schema':'hepta.hia.task-helpers-native.v1','source_path':str(source),
          'source_sha256':sha256(raw).hexdigest(),'image_path':str(image),
          'image_sha256':sha256(image_raw).hexdigest(),'compiler_sha256':sha256(compiler_raw).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
types=ROOT/'dependencies/types'
original=types/'development/compile-r2/bundle.json'
bundle=json.loads(original.read_bytes())
for name,row in bundle['components'].items():
    row['source_path']=str(types/'checkpoints/source-r2/examples/hia_bootstrap'/('composite_type_transport_'+name+'.hiaasm'))
    row['image_path']=str(types/'development/compile-r2'/('type-transport-'+name+'.image.bin'))
    assert sha256(Path(row['source_path']).read_bytes()).hexdigest()==row['source_sha256']
    assert sha256(Path(row['image_path']).read_bytes()).hexdigest()==row['image_sha256']
bundle['recovered_original_manifest_sha256']=sha256(original.read_bytes()).hexdigest()
(ROOT/'development/type-transport-recovered-bundle.json').write_text(json.dumps(bundle,indent=2,sort_keys=True)+'\n')
type_receipt=json.loads((types/'development/compile-types-r1/composite-types.receipt.json').read_bytes())
type_image=types/'development/compile-types-r1/composite-types.image.bin'
type_source=BASE/'examples/hia_bootstrap/composite_types.hiaasm'
assert sha256(type_source.read_bytes()).hexdigest()==type_receipt['source_sha256']
assert sha256(type_image.read_bytes()).hexdigest()==type_receipt['produced_sha256']
report={'scope':'RECOVERED_EXACT_DEPENDENCIES_AND_FRESH_TASK_HELPER_DEVELOPMENT','status':'PASS',
        'task_helper':manifest,'types_source':str(type_source),'types_image':str(type_image),
        'types_source_sha256':type_receipt['source_sha256'],'types_image_sha256':type_receipt['produced_sha256'],
        'types_original_receipt':type_receipt}
(ROOT/'development/dependencies-ready.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','task_helper_image_sha256':manifest['image_sha256'],
                  'types_source_sha256':type_receipt['source_sha256'],
                  'types_image_sha256':type_receipt['produced_sha256']},sort_keys=True),flush=True)
