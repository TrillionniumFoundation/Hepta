"""Fresh reconstructed helper transport actual-image harness.

A test-only fixed executor: HIA publishes QUERY / GROW / CALL_HELPER / DONE.
The executor never selects descriptor fields, converts flat slots, builds the
11-item helper packet, or parses the helper result during forwarding.
"""
from contextlib import ExitStack
import ctypes
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
from unittest.mock import patch

from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_composite_function_tokens import ObjectTokenDecoder
from hepta.hia_composite_types_native import NativeCompositeTypeSession
from hepta.hia_instruction_policy_native import transport
from hepta import hia_program_composite as composite
from hepta import hia_task_helpers_native as helpers

ROOT = Path(__file__).resolve().parents[1]
BASE = Path('/workspace/scratch/9acdfa9f5639/Hepta-v66-restored')
COMPILER = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
BAD = 0xfffffffd
CANARY = b'\xb9' * 32
MAGIC = lambda word: int.from_bytes(word, 'little')
HELPER_INIT, HELPER_EVENT = map(MAGIC, (b'HIAHRI01', b'HIAHRE01'))
IR_INIT, IR_CONT, IR_EVENT = map(MAGIC, (b'HIAOII01', b'HIAOIC01', b'HIAOIE01'))


def frozen_module(name, path):
    path = Path(path)
    raw = path.read_bytes()
    spec = importlib.util.spec_from_loader(name, loader=None, origin=str(path))
    module = importlib.util.module_from_spec(spec)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    if path.read_bytes() != raw:
        raise AssertionError('test dependency source changed during import')
    return module, raw


class Images:
    def __init__(self, bundle, evidence):
        self.bundle = Path(bundle).resolve()
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            if path in self.pins and self.pins[path] != raw:
                raise AssertionError('changed bytes for one admitted dependency path')
            self.pins[path] = raw
            return raw
        value = json.loads(read(self.bundle))
        if (value['status'] != 'PASS' or value['scope'] != 'SOURCE_BOUND_RECONSTRUCTED_DEVELOPMENT_NOT_COLD_QUALIFIED'
                or set(value['components']) != {'request', 'reply'}):
            raise AssertionError('not the complete fresh helper development bundle')
        snapshots = {}
        for name in ('request', 'reply'):
            row = value['components'][name]
            if (row['schema'] != 'hepta.hia.composite-helper-transport-' + name + '-native.v1'
                    or row['compiler_sha256'] != COMPILER):
                raise AssertionError('wrong helper component kind/compiler')
            source = read(row['source_path'])
            current = read(ROOT / ('examples/hia_bootstrap/composite_helper_transport_' + name + '.hiaasm'))
            image = read(row['image_path'])
            if (source != current or sha256(source).hexdigest() != row['source_sha256']
                    or sha256(image).hexdigest() != row['image_sha256']):
                raise AssertionError('source/image custody mismatch')
            snapshots[name] = image, row['image_sha256']
        self.readback()
        self.directory = Path(evidence)
        self.directory.mkdir(parents=True, exist_ok=False)
        self.images = {name: NativeHiaJsonImage(*pair) for name, pair in snapshots.items()}
        self.entries = {'request': 0, 'reply': 0}
        self.log = (self.directory / 'helper-entries.jsonl').open('w')
        self.inputs = {}
        (self.directory / 'source-before.json').write_text(json.dumps(
            {str(path): sha256(raw).hexdigest() for path, raw in self.pins.items()}, indent=2, sort_keys=True) + '\n')

    def readback(self):
        for path, raw in self.pins.items():
            if path.read_bytes() != raw:
                raise AssertionError('helper source/image drift: ' + str(path))

    def save(self, raw, suffix):
        digest = sha256(raw).hexdigest()
        if digest not in self.inputs:
            name = digest + suffix
            (self.directory / name).write_bytes(raw)
            self.inputs[digest] = name
        return self.inputs[digest]

    def close(self):
        self.log.close()
        self.readback()
        (self.directory / 'source-after.json').write_text(json.dumps(
            {str(path): sha256(raw).hexdigest() for path, raw in self.pins.items()}, indent=2, sort_keys=True) + '\n')


class HelperSession:
    def __init__(self, native, config, *, size=4096):
        assert len(config) == 16 and config[0] == HELPER_INIT
        self.native = native
        self.config = tuple(config)
        self.size = size
        self.work = ctypes.create_string_buffer(size + 32)
        struct.pack_into('<16Q', self.work, 256, *config)
        ctypes.memset(ctypes.addressof(self.work) + size, 0xb9, 32)
        self.event = None
        self.calls = 0
        self.grows = 0

    def call(self, which, command, borrowed, *, extent=None):
        assert type(command) is bytes and type(borrowed) is bytes
        source = ctypes.create_string_buffer(command + CANARY)
        readonly = ctypes.create_string_buffer(borrowed + CANARY)
        result = self.native.images[which]._entry(source, len(command), readonly, len(borrowed),
                                                  self.work, self.size if extent is None else extent)
        self.native.entries[which] += 1
        self.calls += 1
        assert ctypes.string_at(source, len(command) + 32) == command + CANARY
        assert ctypes.string_at(readonly, len(borrowed) + 32) == borrowed + CANARY
        assert ctypes.string_at(ctypes.addressof(self.work) + self.size, 32) == CANARY
        event = struct.unpack_from('<32Q', self.work, 0)
        row = {'entry': sum(self.native.entries.values()), 'kernel': which, 'return': result,
               'event': event, 'command': self.native.save(command, '.command'),
               'borrowed': self.native.save(borrowed, '.lease'), 'workspace_bytes': self.size,
               'advertised_workspace_bytes': self.size if extent is None else extent,
               'inputs_and_guards_unchanged': True}
        self.native.log.write(json.dumps(row, sort_keys=True) + '\n')
        self.native.log.flush()
        if result != BAD:
            assert result == 256 and event[0] == HELPER_EVENT
            assert event[2:8] == (self.config[1], self.config[4], self.config[2], self.config[3],
                                   self.config[7], self.config[8])
            assert event[27:] == (0,) * 5
        self.event = event
        return result, event

    def finish(self, which, command, borrowed):
        while True:
            result = self.call(which, command, borrowed)
            if result[0] == BAD or result[1][1] != 2:
                return result
            needed = result[1][22]
            assert needed > self.size
            old = self.work
            self.work = ctypes.create_string_buffer(needed + 32)
            ctypes.memmove(self.work, old, self.size)
            self.size = needed
            ctypes.memset(ctypes.addressof(self.work) + needed, 0xb9, 32)
            self.grows += 1

    def view(self, offset, size):
        assert offset <= self.size and size <= self.size - offset
        return ctypes.string_at(ctypes.addressof(self.work) + offset, size)

    def close(self):
        self.work = None
        self.native.readback()


class NativeIR:
    """A bounded mechanical call path to the recovered actual IR image."""
    def __init__(self, directory):
        self.root = ROOT / 'dependencies/requests/dependencies/metadata-ir'
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            if path in self.pins and self.pins[path] != raw:
                raise AssertionError('changed IR dependency')
            self.pins[path] = raw
            return raw
        manifest = json.loads(read(self.root / 'runtime/composite-object-ir.manifest.json'))
        source = read(self.root / 'examples/hia_bootstrap/composite_object_ir.hiaasm')
        frozen = read(self.root / 'checkpoints/object-ir-source-r2/examples/hia_bootstrap/composite_object_ir.hiaasm')
        image = read(self.root / 'runtime' / manifest['image_path'])
        if (manifest['schema'] != 'hepta.hia.composite-object-ir-native.v1'
                or source != frozen or sha256(source).hexdigest() != manifest['source_sha256']
                or sha256(image).hexdigest() != manifest['image_sha256']
                or manifest['compiler_sha256'] != COMPILER):
            raise AssertionError('wrong exact IR dependency')
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=False)
        self.image = NativeHiaJsonImage(image, manifest['image_sha256'])
        issuer_path = ROOT / 'dependencies/requests/dependencies/packet-issuer/tests/test_hia_composite_packet_json.py'
        self.issuer_module, self.issuer_raw = frozen_module('helper_packet_issuer', issuer_path)
        self.issuer = self.issuer_module.ActualPacketJson(self.directory / 'actual-issuer')
        self.entries, self.streams = 0, 0
        self.log = (self.directory / 'actual-ir.jsonl').open('w')
        self.readback()

    def readback(self):
        for path, raw in self.pins.items():
            assert path.read_bytes() == raw

    def encode(self, value, *, serial, request, source_reference=True):
        # Generic test input preparation occurs before forbidden forwarding.
        packet = transport(value)
        result, header, data, index, _ = self.issuer.encode('helper-' + str(self.streams), packet)
        assert result == 64 + len(data) and header[5] == len(packet)
        at = (64 + len(packet) + 7) & ~7
        source_lease = struct.pack('<8Q', MAGIC(b'HIASIL01'), len(packet), len(index), 64, at, at+len(index), 0, 0)
        source_lease += packet + b'\0' * (at-64-len(packet)) + index
        self.streams += 1
        lease, stream, slots = 17, self.streams, 3
        size = 131328
        workspace = ctypes.create_string_buffer(size + 32)
        ctypes.memset(ctypes.addressof(workspace) + size, 0xb9, 32)
        borrowed = ctypes.create_string_buffer(source_lease + CANARY)
        def call(command):
            nonlocal workspace, size
            raw = ctypes.create_string_buffer(command + CANARY)
            extent = self.image._entry(raw, len(command), borrowed, len(source_lease), workspace, size)
            self.entries += 1
            assert ctypes.string_at(raw, len(command)+32) == command + CANARY
            assert ctypes.string_at(borrowed, len(source_lease)+32) == source_lease + CANARY
            assert ctypes.string_at(ctypes.addressof(workspace)+size,32) == CANARY
            event = struct.unpack_from('<16Q', workspace, 1024)
            self.log.write(json.dumps({'entry':self.entries,'return':extent,'event':event,
                'command_hex':command.hex(),'workspace_bytes':size,
                'source_sha256':sha256(source_lease).hexdigest(),'guards_unchanged':True},sort_keys=True)+'\n')
            self.log.flush()
            assert extent == 1152 and event[0] == IR_EVENT and event[3:5] == (lease,stream)
            return event
        command = struct.pack('<8Q',IR_INIT,lease,stream,MAGIC(b'HIAFNC01'),6,request,serial,slots)
        assert call(command)[1] == 1
        if source_reference:
            payload = struct.pack('<2Q',0,0)
        else:
            def tokens(node):
                if node is None:return struct.pack('<2Q',4,0)
                if type(node) is bool:return struct.pack('<2Q',3,int(node))
                if type(node) is int:return struct.pack('<2Q',2,node)
                if type(node) is str:
                    raw=node.encode('utf8');return struct.pack('<2Q',1,len(raw))+raw
                if type(node) is list:return struct.pack('<2Q',5,len(node))+b''.join(tokens(x) for x in node)
                raise TypeError(type(node))
            payload=tokens(value)
        assert len(payload)<=65472
        event=call(struct.pack('<8Q',MAGIC(b'HIAFNC01'),6,0,1,serial,slots,request,len(payload))+payload)
        while event[1]==3:
            needed=event[10];assert needed>size
            old=workspace;workspace=ctypes.create_string_buffer(needed+32)
            ctypes.memmove(workspace,old,size);size=needed
            ctypes.memset(ctypes.addressof(workspace)+size,0xb9,32)
            event=call(struct.pack('<4Q',IR_CONT,lease,stream,event[6]))
        assert event[1:3]==(5,2)
        raw=ctypes.string_at(workspace,event[9])
        (self.directory / ('ir-'+str(stream)+'.bin')).write_bytes(raw)
        (self.directory / ('source-'+str(stream)+'.lease')).write_bytes(source_lease)
        self.readback()
        return raw, source_lease, lease, stream, slots

    def close(self):
        self.issuer.close()
        self.log.close()
        self.readback()


def no_host_semantics():
    def absent(*args, **kwargs):
        raise AssertionError('host type/helper semantic or materialization owner used during forwarding')
    context = ExitStack()
    for owner,name in ((NativeCompositeTypeSession,'_command'),
                       (NativeCompositeTypeSession,'_materialize_value'),
                       (ObjectTokenDecoder,'feed'), (helpers,'packet'),
                       (helpers.NativeTaskHelpers,'generate'),
                       (helpers.NativeTaskHelpers,'generate_packet'),
                       (composite._Elaborator,'_reference_helper')):
        context.enter_context(patch.object(owner,name,new=absent))
    return context
