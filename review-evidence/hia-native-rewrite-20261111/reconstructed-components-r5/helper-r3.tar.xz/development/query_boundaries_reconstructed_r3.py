"""Actual QUERY GROW and issued-ID controls for helper recovery r3."""
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import resource
import struct
import time
import traceback

from helper_harness import ROOT,Images,HelperSession,NativeIR,MAGIC,HELPER_INIT,BAD,frozen_module,no_host_semantics
from hepta import hia_task_helpers_native as helpers
from tests.test_hia_task_helpers_native import helper_owner

resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_AS,(1024<<20,1024<<20))
OUT=ROOT/'development/query-boundaries-reconstructed-r3'
OUT.mkdir(exist_ok=False)
own_raw=Path(__file__).read_bytes()
harness,harness_raw=frozen_module('helper_large_query_types',ROOT/'dependencies/types/development/transport_harness.py')
images=Images(ROOT/'development/compile-reconstructed-r3/bundle.json',OUT/'actual-helper')
ir=NativeIR(OUT/'actual-ir')
transport=harness.NativeTransport(ROOT/'development/type-transport-recovered-bundle.json',
    lease=950,ledger=OUT/'types.jsonl')
initial_command=(ROOT/'development/pipeline-reconstructed-r3-attempt1/types-0-0.command.json').read_bytes()
initial_frame=(ROOT/'development/pipeline-reconstructed-r3-attempt1/types-0-0.response.bin').read_bytes()
session=None
cases=[]
summary=None
started=time.monotonic_ns()
try:
    assert transport.begin(json.loads(initial_command),1)[0]==128
    assert transport.reply(initial_frame)[0]==128
    # The ignored nominal name makes a legal private descriptor ABI larger
    # than a small helper workspace; this is not a public source-name claim.
    descriptor=[
        harness.descriptor(17,'State',flat=[]),
        harness.descriptor(18,'Result',flat=[]),
        harness.descriptor(19,'Step',kind='enum',flat=[9],
            variants=[['pending',[['state',17]]],['ready',[['result',18]]]]),
        harness.descriptor(20,'Task-'+'x'*(300<<10),kind='task',flat=[7,13],
            state=17,result=18,poll='poll',cancel='cancel',linear=True)]
    frame=harness.frame({'types':descriptor},identifier=20,counters=(4,0,4))
    (OUT/'private-large-descriptor-frame.bin').write_bytes(frame)
    assert transport.begin({'op':'resolve','ref':'PRIVATE_LARGE_DESCRIPTOR'},3)[0]==128
    assert transport.reply(frame)[0]==128

    def prepare(command,serial,request):
        metadata,source,lease,stream,slots=ir.encode(command,serial=serial,request=request)
        config=(HELPER_INIT,request+3000,lease,stream,request,serial,slots,
                transport.lease,transport.sequence,transport.query_sequence+1,0,0,0,0,0,0)
        return metadata,source,config

    metadata,source,config=prepare([6,20,19,'start',0,[],[]],0,1)
    session=HelperSession(images,config)
    with no_host_semantics():
        result=session.finish('request',metadata,source)
        assert result[0]==256 and result[1][1]==1
        query=session.view(result[1][14],result[1][15])
        status,event,_=transport.call('commands',query)
        assert status==128
        raw=struct.pack('<16Q',*event)
        borrowed=ctypes.string_at(transport.workspace,transport.size)
        result=session.call('request',raw,borrowed)
        assert result[0]==256 and result[1][1]==2,result
        assert result[1][8]==1
        snapshot=bytes(session.work[:session.size])
        grow=result[1]
        (OUT/'query-grow-workspace.bin').write_bytes(snapshot)
        (OUT/'query-grow-event.bin').write_bytes(raw)
        (OUT/'query-grow-borrowed.bin').write_bytes(borrowed)
        original=session
        for index in (4,8,9,10,13,14):
            altered=bytearray(raw);struct.pack_into('<Q',altered,index*8,struct.unpack_from('<Q',altered,index*8)[0]+1)
            probe=HelperSession(images,config,size=len(snapshot))
            ctypes.memmove(probe.work,snapshot,len(snapshot))
            refusal=probe.call('request',bytes(altered),borrowed)
            assert refusal[0]==BAD,(index,refusal)
            frozen=bytes(probe.work)
            assert probe.call('request',raw,borrowed)[0]==BAD and bytes(probe.work)==frozen
            assert probe.call('reply',b'',b'')[0]==BAD and bytes(probe.work)==frozen
            cases.append({'case':'query-grow-replay-mismatch-'+str(index),'status':'PERMANENT_BAD'})
            probe.close()
        session=original
        # Exact same event and borrow are replayed locally. The QUERY service
        # itself is not called again merely to satisfy a component GROW.
        before=transport.calls
        result=session.finish('request',raw,borrowed)
        assert transport.calls==before
        while result[0]==256 and result[1][1]==1:
            query=session.view(result[1][14],result[1][15])
            status,event,_=transport.call('commands',query);assert status==128
            result=session.finish('request',struct.pack('<16Q',*event),
                                  ctypes.string_at(transport.workspace,transport.size))
        assert result[0]==256 and result[1][1]==3,result
        wire=session.view(result[1][14],result[1][15])
        transport.query_sequence=result[1][8]
    owner,typ=helper_owner([],[])
    step=owner.signatures['poll'][1][0]
    assert wire==helpers.packet(typ,step,'start',0,[],[])
    cases.append({'case':'large-query-grow-completes-with-owned-copy','status':'PASS',
                  'descriptor_json_frame_bytes':len(frame),'query_payload_bytes':len(raw),
                  'helper_packet_bytes':len(wire),'grow_needed':grow[22],
                  'descriptor_query_not_reissued_on_grow':True,'last_query':transport.query_sequence})
    session.close();session=None

    # Valid IDs are checked before the old generate(serial) rejection.
    metadata,source,config=prepare([6,20,19,'start',8193,[],[]],8193,2)
    session=HelperSession(images,config)
    queried=[]
    with no_host_semantics():
        result=session.finish('request',metadata,source)
        while result[0]==256 and result[1][1]==1:
            query=session.view(result[1][14],result[1][15])
            queried.append(struct.unpack_from('<Q',query,32)[0])
            status,event,_=transport.call('commands',query);assert status==128
            transport.query_sequence=event[4]
            result=session.finish('request',struct.pack('<16Q',*event),
                                  ctypes.string_at(transport.workspace,transport.size))
        assert result[0]==BAD and queried==[20,19],(result,queried)
        frozen=bytes(session.work)
        assert session.call('reply',b'',b'')[0]==BAD and bytes(session.work)==frozen
    cases.append({'case':'issued-task-and-step-before-counter-refusal','status':'PASS','queried':queried})
    session.close();session=None

    # An unissued ID must be offered to the real type QUERY owner. That owner
    # refuses and its lease becomes unusable. The fixed driver must dispose the
    # waiting helper too; there is deliberately no fabricated success reply.
    metadata,source,config=prepare([6,21,19,'start',8193,[],[]],8193,3)
    session=HelperSession(images,config)
    with no_host_semantics():
        result=session.finish('request',metadata,source)
        assert result[0]==256 and result[1][1]==1
        query=session.view(result[1][14],result[1][15])
        assert struct.unpack_from('<Q',query,32)[0]==21
        status,event,_=transport.call('commands',query)
        assert status==BAD and event is None
        status,event,_=transport.call('commands',query)
        assert status==BAD and event is None
    session.close();session=None
    cases.append({'case':'unissued-task-query-before-counter-and-driver-disposal','status':'PASS',
                  'actual_type_validator_permanently_refused':True,'no_helper_call_or_fabricated_response':True})
    summary={'status':'PASS','scope':'PRIVATE_QUERY_GROW_AND_ISSUED_ID_CONTRACT_DEVELOPMENT',
             'cases':cases,'helper_entries':images.entries,'ir_entries':ir.entries,
             'issuer_entries':ir.issuer.entries,'type_entries':transport.calls,
             'wall_elapsed_ns':time.monotonic_ns()-started}
except BaseException as exc:
    traceback.print_exc()
    summary={'status':'FAIL','cases':cases,'class':type(exc).__name__,'error':str(exc)}
    raise
finally:
    if session is not None:session.close()
    transport.close();images.close();ir.close()
    assert Path(__file__).read_bytes()==own_raw
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':summary['status'],'cases':len(cases)},sort_keys=True),flush=True)
