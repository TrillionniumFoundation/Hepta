"""Fresh real type-owner -> QUERY -> helper transport -> helper result smoke."""
from contextlib import ExitStack
import ctypes
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import resource
import struct
import time
import traceback
from unittest.mock import patch

from helper_harness import ROOT, BASE, Images, HelperSession, NativeIR, MAGIC, HELPER_INIT, BAD, CANARY, frozen_module, no_host_semantics
from hepta import hia_program_composite as composite
from hepta import hia_composite_constructor_native as ctor_module
from hepta import hia_composite_functions_native as functions_module
from hepta import hia_composite_types_native as type_module
from hepta import hia_task_helpers_native as helper_module
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from tests import test_hia_program_composite as fixtures

resource.setrlimit(resource.RLIMIT_CPU, (60,60))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20,1024 << 20))
OUT=ROOT/'development/pipeline-reconstructed-r3-serial8191'
OUT.mkdir(exist_ok=False)
source_bytes=Path(__file__).read_bytes()
dependencies_path=ROOT/'development/dependencies-ready.json'
dependency_bytes=dependencies_path.read_bytes()
dependencies=json.loads(dependency_bytes)
frozen={}
for prefix in ('types',):
    for field in ('source','image'):
        path=Path(dependencies[prefix+'_'+field]);raw=path.read_bytes()
        assert sha256(raw).hexdigest()==dependencies[prefix+'_'+field+'_sha256']
        frozen[path]=raw
helper_row=dependencies['task_helper']
for field in ('source','image'):
    path=Path(helper_row[field+'_path']);raw=path.read_bytes()
    assert sha256(raw).hexdigest()==helper_row[field+'_sha256']
    frozen[path]=raw
types_native=type_module.NativeCompositeTypes(frozen[Path(dependencies['types_image'])],dependencies['types_image_sha256'])
helper_reference=helper_module.NativeTaskHelpers(frozen[Path(helper_row['image_path'])],helper_row['image_sha256'])
helper_image=NativeHiaJsonImage(frozen[Path(helper_row['image_path'])],helper_row['image_sha256'])
type_harness,type_harness_bytes=frozen_module('helper_issued_types',
    ROOT/'dependencies/types/development/transport_harness.py')
images=Images(ROOT/'development/compile-reconstructed-r3/bundle.json',OUT/'actual-helper-transport')
ir=NativeIR(OUT/'actual-ir')
records=[]
type_actual_entries=0
helper_actual_entries=0
reference_helper_entries=0
owner=None
transport=None
session=None
started=time.monotonic_ns()
all_commands=[]
original_entry=types_native._entry


def capture(source,size,output,capacity,state,state_size):
    global type_actual_entries
    before=ctypes.string_at(source,size)
    result=original_entry(source,size,output,capacity,state,state_size)
    type_actual_entries+=1
    assert ctypes.string_at(source,size)==before
    assert 64<=result<=capacity
    all_commands.append((before,ctypes.string_at(output,result)))
    return result


types_native._entry=capture
ops={'init':1,'parameters':2,'resolve':3,'partial':4,'origins':5,'task_protocol':6}
summary=None
try:
    for fi,factory in enumerate((fixtures.task_program,fixtures.scalar_task_program,fixtures.owned_result_task_program)):
        document=factory()
        start_record=len(all_commands)
        with patch.object(ctor_module,'selected_composite_constructor',return_value=None), \
             patch.object(functions_module,'selected_composite_functions',return_value=None), \
             patch.object(type_module,'selected_composite_types',new=types_native.session):
            owner=composite._Elaborator(deepcopy(document))
        declaration=next(item for item in document['types'] if item['kind']=='task')
        typ=owner.types.resolve(declaration['name'])
        step=owner.check_task(typ)
        task_id=owner.types._ids[id(typ)]
        step_id=owner.types._ids[id(step)]
        poll=list(owner.functions[typ.poll]['effects'])
        cancel=list(owner.functions[typ.cancel]['effects'])
        transport=type_harness.NativeTransport(ROOT/'development/type-transport-recovered-bundle.json',
            lease=100+fi,ledger=OUT/('type-transport-'+str(fi)+'.jsonl'))
        for ci,(command_raw,response_raw) in enumerate(all_commands[start_record:]):
            command=json.loads(command_raw)
            (OUT/('types-'+str(fi)+'-'+str(ci)+'.command.json')).write_bytes(command_raw)
            (OUT/('types-'+str(fi)+'-'+str(ci)+'.response.bin')).write_bytes(response_raw)
            result,event,_=transport.begin(command,ops[command['op']])
            assert result==128 and event[1]==0 and event[6]==0
            result,event,_=transport.reply(response_raw)
            assert result==128 and event[1]==0 and event[6]==0
        owner.native_types.close()
        for oi,operation in enumerate(('start','poll','cancel','join','close')):
            serial=8191
            expected_wire=helper_module.packet(typ,step,operation,serial,poll,cancel)
            reference=helper_reference.generate_packet(expected_wire,serial=serial)
            reference_helper_entries+=1
            command=[6,task_id,step_id,operation,serial,poll,cancel]
            request=10+fi*5+oi
            metadata,source_lease,ir_lease,stream,slots=ir.encode(command,serial=serial,request=request,
                                                               source_reference=oi%2==0)
            config=(HELPER_INIT,2000+request,ir_lease,stream,request,serial,slots,
                    transport.lease,transport.sequence,transport.query_sequence+1,0,0,0,0,0,0)
            session=HelperSession(images,config)
            queries=[]
            with no_host_semantics():
                result=session.finish('request',metadata,source_lease)
                while result[0]==256 and result[1][1]==1:
                    event=result[1]
                    query=session.view(event[14],event[15])
                    assert len(query)==64 and struct.unpack_from('<Q',query)[0]==MAGIC(b'HIATRQ01')
                    queries.append(struct.unpack_from('<8Q',query))
                    result_type,type_event,_=transport.call('commands',query)
                    assert result_type==128 and type_event[1]==0
                    actual_event=struct.pack('<16Q',*type_event)
                    borrowed=ctypes.string_at(transport.workspace,transport.size)
                    result=session.finish('request',actual_event,borrowed)
                assert result[0]==256 and result[1][1]==3,result
                event=result[1]
                actual_wire=session.view(event[14],event[15])
                assert actual_wire==expected_wire,(factory.__name__,operation,'whole packet differs')
                source=ctypes.create_string_buffer(actual_wire+CANARY)
                output=ctypes.create_string_buffer((4<<20)+32)
                state=ctypes.create_string_buffer((2<<20)+32)
                ctypes.memset(ctypes.addressof(output)+(4<<20),0xb9,32)
                ctypes.memset(ctypes.addressof(state)+(2<<20),0xb9,32)
                extent=helper_image._entry(source,len(actual_wire),output,4<<20,state,2<<20)
                helper_actual_entries+=1
                assert 64<=extent<=4<<20
                assert ctypes.string_at(source,len(actual_wire)+32)==actual_wire+CANARY
                assert ctypes.string_at(ctypes.addressof(output)+(4<<20),32)==CANARY
                assert ctypes.string_at(ctypes.addressof(state)+(2<<20),32)==CANARY
                actual_frame=ctypes.string_at(output,extent)
                actual_state=ctypes.string_at(state,2<<20)
                result=session.finish('reply',actual_frame,actual_state)
                assert result[0]==256 and result[1][1]==4,result
                event=result[1]
                typed=session.view(event[16],event[17]) if event[17] else b''
                continuation=session.view(event[18],event[19])
                name=session.view(event[20],event[21])
                header=session.view(event[24],event[25])
            assert header==actual_frame[:64] and event[26]==len(actual_frame)
            assert event[10:14]==(serial,reference.serial,reference.error,
                                 0 if reference.name is None else int(reference.name[11:]))
            expected_name=b'' if reference.name is None else reference.name.encode()
            assert name==expected_name
            expected_cont=struct.pack('<8Q',MAGIC(b'HIAFLR01'),request,6,reference.error,0,
                                      reference.serial,len(expected_name),0)+expected_name
            assert continuation==expected_cont
            if reference.error:
                assert not typed and reference.helper is None
            else:
                actual_value,_=detached_packet_index(typed)
                assert json.dumps(actual_value,separators=(',',':'),sort_keys=True)==json.dumps(reference.helper,separators=(',',':'),sort_keys=True)
            assert event[8]>=transport.query_sequence
            transport.query_sequence=event[8]
            label=factory.__name__+'-'+operation
            (OUT/(label+'.expected-packet')).write_bytes(expected_wire)
            (OUT/(label+'.actual-packet')).write_bytes(actual_wire)
            (OUT/(label+'.actual-helper-frame')).write_bytes(actual_frame)
            (OUT/(label+'.actual-helper.packet')).write_bytes(typed)
            (OUT/(label+'.continuation')).write_bytes(continuation)
            row={'case':label,'result':'PASS','queries':queries,'query_last':event[8],
                 'source_reference_metadata':oi%2==0,'complete_packet_bytes':len(actual_wire),
                 'complete_helper_typed_bytes':len(typed),'complete_helper_frame_bytes':len(actual_frame),
                 'helper_error':reference.error,'final_serial':reference.serial,
                 'host_owners_disabled_during_forwarding':True,'entries':session.calls,'grows':session.grows}
            records.append(row);print(json.dumps(row,sort_keys=True),flush=True)
            session.close();session=None
            del source,output,state
        transport.close();transport=None
        owner=None
    summary={'status':'PASS','scope':'FRESH_RECONSTRUCTED_HELPER_SIX_OWNER_PIPELINE_DEVELOPMENT_NOT_COLD',
             'cases':records,'helper_transport_entries':images.entries,'ir_entries':ir.entries,
             'issuer_entries':ir.issuer.entries,'actual_type_entries':type_actual_entries,
             'actual_helper_entries':helper_actual_entries,'reference_helper_entries':reference_helper_entries,
             'wall_elapsed_ns':time.monotonic_ns()-started,'old_lost_helper_raw_not_counted':True,
             'metadata_scope':'Test-constructed actual generic IR, not a claim of complete function controller execution.'}
except BaseException as exc:
    traceback.print_exc()
    summary={'status':'FAIL','cases':records,'class':type(exc).__name__,'error':str(exc),
             'helper_transport_entries':images.entries,'actual_type_entries':type_actual_entries}
    raise
finally:
    if session is not None:session.close()
    if transport is not None:transport.close()
    if owner is not None and owner.native_types is not None:owner.native_types.close()
    images.close();ir.close()
    assert Path(__file__).read_bytes()==source_bytes
    assert dependencies_path.read_bytes()==dependency_bytes
    for path,raw in frozen.items():assert path.read_bytes()==raw
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':summary['status'],'cases':len(records),'entries':images.entries},sort_keys=True),flush=True)
