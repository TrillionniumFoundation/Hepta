"""Freeze reconstructed helper r3 evidence without rewriting original receipts."""
from pathlib import Path
from hashlib import sha256, sha1
import json, shutil, stat, tarfile, io, os, time

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-composite-helper-transport-recovery-next')
BASE = Path('/workspace/scratch/9acdfa9f5639/Hepta-v66-restored')
DELIVERY = ROOT / 'checkpoints/final-reconstructed-r3'
DELIVERY.mkdir(parents=True, exist_ok=True)

def info(path, name=None):
    raw=path.read_bytes()
    return {'path': str(path if name is None else name), 'bytes':len(raw),
            'sha256':sha256(raw).hexdigest(), 'git_blob_sha':sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
            'mode':stat.S_IMODE(path.stat().st_mode)}

snapshot=ROOT/'checkpoints/source-reconstructed-r3/source.json'
snap=json.loads(snapshot.read_text())
for row in snap['files']:
    live=ROOT/row['path']
    frozen=ROOT/'checkpoints/source-reconstructed-r3'/row['path']
    assert live.read_bytes()==frozen.read_bytes()
    assert info(live)['sha256']==row['sha256']
for row in snap['dependencies']:
    assert info(Path(row['path']))['sha256']==row['sha256']

compiler=Path('/workspace/scratch/9acdfa9f5639/native-composite-core-final-recovery-next/dependencies/f50-B3.image.bin')
copy=ROOT/'dependencies/compiler/f50-B3.image.bin'
copy.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(compiler,copy)
assert copy.read_bytes()==compiler.read_bytes()
assert info(copy)['sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'

references=[
'hepta/hia_task_helpers_native.py','hepta/hia_composite_types_native.py',
'hepta/hia_program_composite.py','hepta/hia_composite_function_tokens.py',
'hepta/hia_instruction_policy_native.py','hepta/hia_json_preflight_native.py',
'hepta/hia_agent_assembly.py','tools/generate_hia_selfhost.py',
'tools/qualify_hia_selfhost.py','tools/hia_selfhost_child.py',
'tools/hia_selfhost_native_observer.py','tests/test_hia_task_helpers_native.py',
'tests/test_hia_program_composite.py','examples/hia_bootstrap/task_helpers.hiaasm',
'examples/hia_bootstrap/composite_types.hiaasm']
ref_rows=[]
for rel in references:
    source=BASE/rel
    target=ROOT/'dependencies/reference-base'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    raw=source.read_bytes()
    shutil.copy2(source,target)
    assert source.read_bytes()==raw==target.read_bytes()
    row=info(target,str(target.relative_to(ROOT)))
    row['original_source_path']=str(source)
    ref_rows.append(row)

groups=[
'pipeline-reconstructed-r3-attempt1','pipeline-reconstructed-r3-serial8191',
'pipeline-reconstructed-r3-serial8192','boundaries-reconstructed-r3-attempt1',
'query-boundaries-reconstructed-r3']
runs=[]
totals={key:0 for key in ['cases','request','reply','ir','issuer','type_transport','semantic_types','helper','reference_helper']}
for group in groups:
    path=ROOT/'development'/group
    summary=json.loads((path/'summary.json').read_text())
    assert summary['status']=='PASS'
    helper_logs=list(path.rglob('helper-entries.jsonl'))
    assert len(helper_logs)==1
    entry_rows=[json.loads(line) for line in helper_logs[0].read_text().splitlines()]
    counts={name:sum(row['kernel']==name for row in entry_rows) for name in ('request','reply')}
    declared=summary.get('helper_transport_entries',summary.get('helper_entries'))
    assert counts==declared
    for row in entry_rows: assert row['inputs_and_guards_unchanged']
    issuer_logs=list(path.rglob('actual-packet-json-ledger.jsonl'))
    ir_logs=list(path.rglob('actual-ir.jsonl'))
    assert len(issuer_logs)==len(ir_logs)==1
    ir_count=len(ir_logs[0].read_text().splitlines())
    issuer_count=len(issuer_logs[0].read_text().splitlines())
    assert ir_count==summary['ir_entries'] and issuer_count==summary['issuer_entries']
    type_logs=[]
    for log in path.glob('*.jsonl'):
        rows=[json.loads(line) for line in log.read_text().splitlines()]
        if rows and 'image' in rows[0] and rows[0]['image'] in ('commands','reply'):
            type_logs.append((log,rows))
    type_count=sum(len(rows) for _,rows in type_logs)
    if group=='boundaries-reconstructed-r3-attempt1':assert type_count==summary['type_transport_entries']
    if group=='query-boundaries-reconstructed-r3':assert type_count==summary['type_entries']
    before=list(path.rglob('source-before.json'))
    for b in before:
        a=b.with_name('source-after.json')
        assert a.is_file() and a.read_bytes()==b.read_bytes()
    count={'cases':len(summary['cases']),**counts,'ir':ir_count,'issuer':issuer_count,
        'type_transport':type_count,'semantic_types':summary.get('actual_type_entries',0),
        'helper':summary.get('actual_helper_entries',0),'reference_helper':summary.get('reference_helper_entries',0)}
    for k,v in count.items():totals[k]+=v
    runs.append({'group':group,'summary':info(path/'summary.json',str((path/'summary.json').relative_to(ROOT))),
                 'log':info(ROOT/'development'/(group+'.log'),'development/'+group+'.log'),
                 'counts':count,'all_local_source_readbacks_equal':True,
                 'wall_elapsed_ns':summary['wall_elapsed_ns']})
assert totals=={'cases':176,'request':720,'reply':217,'ir':396,'issuer':76,'type_transport':531,
               'semantic_types':90,'helper':70,'reference_helper':70},totals
bundle=ROOT/'development/compile-reconstructed-r3/bundle.json'
compiled=json.loads(bundle.read_text())
assert compiled['status']=='PASS'
images={}
for role,row in compiled['components'].items():
    assert info(Path(row['source_path']))['sha256']==row['source_sha256']
    assert info(Path(row['image_path']))['sha256']==row['image_sha256']
    images[role]={'source':info(Path(row['source_path']),str(Path(row['source_path']).relative_to(ROOT))),
                  'image':info(Path(row['image_path']),str(Path(row['image_path']).relative_to(ROOT)))}
script_paths=[
'development/helper_harness.py','development/prepare_dependencies.py',
'development/compile_reconstructed_r2.py','development/compile_reconstructed_r3.py',
'development/pipeline_reconstructed_r3_attempt1.py','development/pipeline_reconstructed_r3_serial8191.py',
'development/pipeline_reconstructed_r3_serial8192.py','development/boundaries_reconstructed_r3_attempt1.py',
'development/query_boundaries_reconstructed_r3.py','development/finalize_reconstructed_r3.py']
final={
'schema':'hepta.hia.composite-helper-transport-reconstructed-development-delivery.v1',
'status':'PASS','scope':'RECONSTRUCTED_R3_COMPONENT_DEVELOPMENT_ONLY',
'production_sources':[info(ROOT/row['path'],row['path']) for row in snap['files']],
'original_source_snapshot':info(snapshot,str(snapshot.relative_to(ROOT))),
'compile_bundle':info(bundle,str(bundle.relative_to(ROOT))),'compiled_images':images,
'reference_snapshots':ref_rows,'compiler_copy':info(copy,str(copy.relative_to(ROOT))),
'run_scripts':[info(ROOT/rel,rel) for rel in script_paths],
'execution_groups':runs,'counts':totals,
'handoff_document':info(ROOT/'docs/HIA_COMPOSITE_HELPER_TRANSPORT_RECONSTRUCTED_R3.md','docs/HIA_COMPOSITE_HELPER_TRANSPORT_RECONSTRUCTED_R3.md'),
'old_lost_helper_r1_raw_available':False,'old_lost_helper_counts_reused':False,
'exact_recovered_authoring':snap['exact_recovered_source_paths'],
'reconstructed_authoring':snap['reconstructed_new_sources'],
'private_issuer_leases_required':True,'original_limits_unchanged':True,
'whole_driver_qualified':False,'cold_qualified':False,'whole_stack_closed':False,
'historical_attempts_preserved':['generation-r2-attempt1.log','generation-r2-attempt2.log',
'checkpoints/source-reconstructed-r2','development/compile-reconstructed-r2'],
'notes':['Public fixture metadata is emitted through real IR but is test-constructed; no full function controller claim.',
'Private descriptor graphs and response mutations are ABI controls, not public language extensions.',
'First QUERY counters establish the private issuer snapshot; matching arbitrary headers do not authenticate buffers.',
'GROW replays the same immutable inputs locally, without another QUERY or helper call.',
'Original receipt absolute paths were not rewritten. Additional reference/compiler copies preserve exact observed bytes.']
}
(DELIVERY/'final.json').write_text(json.dumps(final,indent=2,sort_keys=True)+'\n')
print(json.dumps({'final_manifest':info(DELIVERY/'final.json'),'totals':totals}),flush=True)

