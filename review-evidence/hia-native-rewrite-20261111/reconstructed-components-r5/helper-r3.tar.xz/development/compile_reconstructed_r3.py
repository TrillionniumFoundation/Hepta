"""Fresh actual helper r3 compilation under the unchanged B3 limits."""
from pathlib import Path
from hashlib import sha256
import json
import time
from tools.qualify_hia_selfhost import compile_stage

ROOT = Path(__file__).resolve().parents[1]
CHECKPOINT = ROOT / 'checkpoints/source-reconstructed-r3'
OUT = ROOT / 'development/compile-reconstructed-r3'
COMPILER = Path('/workspace/scratch/9acdfa9f5639/native-composite-core-final-recovery-next/dependencies/f50-B3.image.bin')
pins = {CHECKPOINT / 'source.json': (CHECKPOINT / 'source.json').read_bytes()}
manifest = json.loads(pins[CHECKPOINT / 'source.json'])
for row in manifest['files']:
    raw = (CHECKPOINT / row['path']).read_bytes()
    assert sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes']
    assert (ROOT / row['path']).read_bytes() == raw
    pins[CHECKPOINT / row['path']] = raw
    pins[ROOT / row['path']] = raw
for row in manifest['dependencies']:
    path = Path(row['path'])
    raw = path.read_bytes()
    assert sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes']
    pins[path] = raw
assert sha256(pins[COMPILER]).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
OUT.mkdir(parents=True, exist_ok=False)
components = {}
started = time.monotonic_ns()
summary = None
try:
    for name in ('request', 'reply'):
        path = CHECKPOINT / ('examples/hia_bootstrap/composite_helper_transport_' + name + '.hiaasm')
        output, receipt = compile_stage(OUT, 'helper-transport-' + name, COMPILER, pins[path])
        raw = output.read_bytes()
        assert receipt['source_sha256'] == receipt['input_sha256'] == sha256(pins[path]).hexdigest()
        assert receipt['artifact_sha256'] == receipt['image_sha256'] == sha256(pins[COMPILER]).hexdigest()
        assert receipt['produced_sha256'] == sha256(raw).hexdigest()
        assert receipt['core_u32'] == receipt['produced_bytes'] == len(raw)
        for original, frozen in pins.items():
            assert original.read_bytes() == frozen
        component = {'schema': 'hepta.hia.composite-helper-transport-' + name + '-native.v1',
                     'source_path': str(path), 'source_sha256': sha256(pins[path]).hexdigest(),
                     'image_path': str(output), 'image_sha256': sha256(raw).hexdigest(),
                     'compiler_sha256': sha256(pins[COMPILER]).hexdigest()}
        components[name] = component
        (OUT / (name + '.manifest.json')).write_text(json.dumps(component, indent=2, sort_keys=True) + '\n')
    summary = {'status': 'PASS', 'scope': 'SOURCE_BOUND_RECONSTRUCTED_DEVELOPMENT_NOT_COLD_QUALIFIED',
               'components': components, 'source_checkpoint_sha256': sha256(pins[CHECKPOINT / 'source.json']).hexdigest(),
               'old_lost_helper_identity_not_reused': True, 'all_source_before_after_exact': True,
               'whole_stack_closed': False, 'wall_elapsed_ns': time.monotonic_ns() - started}
    (OUT / 'bundle.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
except BaseException as exc:
    summary = {'status': 'FAIL', 'components': components, 'class': type(exc).__name__, 'error': str(exc)}
    raise
finally:
    for original, frozen in pins.items():
        assert original.read_bytes() == frozen
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
