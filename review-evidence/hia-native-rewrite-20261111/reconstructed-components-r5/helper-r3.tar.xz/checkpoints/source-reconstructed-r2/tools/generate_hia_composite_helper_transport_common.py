"""Reconstructed helper transport shared HIA owner, new recovery revision r2.

This is new source after the old common/request files were lost. The fixed
32-word coordinator ABI is retained; no old generated hash or test result is
claimed for this reconstruction.
"""
from __future__ import annotations

CONSTANTS = {
    'CONFIG_MAGIC': int.from_bytes(b'HIAHRI01', 'little'),
    'EVENT_MAGIC': int.from_bytes(b'HIAHRE01', 'little'),
    'STATE_MAGIC': int.from_bytes(b'HIAHRS01', 'little'),
    'IR_MAGIC': int.from_bytes(b'HIAOIS01', 'little'),
    'SOURCE_MAGIC': int.from_bytes(b'HIASIL01', 'little'),
    'FN_MAGIC': int.from_bytes(b'HIAFNC01', 'little'),
    'QUERY_MAGIC': int.from_bytes(b'HIATRQ01', 'little'),
    'TYPE_EVENT': int.from_bytes(b'HIATRE01', 'little'),
    'HELPER_MAGIC': int.from_bytes(b'HIATHP01', 'little'),
    'CONT_MAGIC': int.from_bytes(b'HIAFLR01', 'little'),
    'NAME_PREFIX': int.from_bytes(b'h2intern', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1, 'REF': 1 << 63,
    'CONTROL_BYTES': 4096, 'PACKET_BASE': 4096, 'PACKET_LIMIT': 128 << 10,
    'ARENA': 135168, 'IR_BASE': 131328, 'IR_STACK': 135168,
    'QUERY_WIRE': 1024, 'CONT_WIRE': 1088, 'HEADER_COPY': 1280,
    'HELPER_WORKSPACE': 2 << 20, 'HELPER_OUTPUT': 4 << 20,
}
FIELDS = (
    'MAGIC', 'BROKEN', 'REASON', 'PHASE', 'LEASE', 'IRLEASE', 'IRSTREAM',
    'REQUEST', 'FSERIAL', 'SLOTS', 'TYPELEASE', 'TYPECMD', 'QSEQ', 'QID',
    'QROLE', 'HEAP', 'META', 'TASK_DESC', 'STEP_DESC', 'CACHE', 'STARTSERIAL',
    'FINAL', 'ERROR', 'NAMEID', 'WIREPTR', 'WIREBYTES', 'HELPERPTR',
    'HELPERBYTES', 'CONTBYTES', 'NAMEBYTES', 'GROW', 'FRAMEBYTES', 'IRSIZE',
    'SRCSIZE', 'IRNODES', 'IRROOT', 'QUERYINPUTBYTES', 'QUERYOFFSET',
    'QUERYBYTES', 'BUILD_STAGE', 'OUTUSED', 'VARIANTS', 'VARIANT_INDEX',
    'VARIANT_PTR', 'FIELDS', 'FIELD_INDEX', 'FIELD_PTR', 'VARIANTS_OUT',
    'VARIANT_OUT', 'FIELDS_OUT', 'ROOT_OUT', 'QUERY_RSIZE', 'CACHED',
    'ACTIVE', 'STEPS',
)
CONSTANTS.update({'H_' + name: 512 + index * 8 for index, name in enumerate(FIELDS)})
CONSTANTS.update({name: 1536 + index * 8 for index, name in enumerate(
    ('IR_MODE', 'IR_CURSOR', 'IR_OUTPUT_BASE', 'IR_LIMIT', 'IR_DEPTH', 'IR_COUNT', 'IR_ERROR'))})
KEYS = ('id', 'kind', 'name', 'args', 'flat', 'fields', 'variants', 'state',
        'result', 'poll', 'cancel', 'linear', 'record',
        'helper', 'entry', 'params', 'returns', 'effects', 'blocks')
CONSTANTS.update({'K_' + name: index + 1 for index, name in enumerate(KEYS)})

COMMON = r'''
def read(s:readbuf, at:u64) -> u64:
    value = 0
    shift = 0
    while shift < 64:
        value = value | (widen(byte(s, at + (shift >> 3))) << shift)
        shift = shift + 8
    return value

def get(w:mutbuf, at:u64) -> u64:
    value = 0
    shift = 0
    while shift < 64:
        value = value | (widen(byte(w, at + (shift >> 3))) << shift)
        shift = shift + 8
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    shift = 0
    while shift < 64:
        store(w, at + (shift >> 3), value >> shift)
        shift = shift + 8
    return 0

def widen(value:u64) -> u64:
    return value

def align8(value:u64) -> u64:
    return (value + 7) & 18446744073709551608

def event(w:mutbuf, action:u64) -> u32:
    put(w, 0, EVENT_MAGIC)
    put(w, 8, action)
    put(w, 16, get(w, H_LEASE))
    put(w, 24, get(w, H_REQUEST))
    put(w, 32, get(w, H_IRLEASE))
    put(w, 40, get(w, H_IRSTREAM))
    put(w, 48, get(w, H_TYPELEASE))
    put(w, 56, get(w, H_TYPECMD))
    put(w, 64, get(w, H_QSEQ))
    put(w, 72, get(w, H_QID))
    put(w, 80, get(w, H_STARTSERIAL))
    put(w, 88, get(w, H_FINAL))
    put(w, 96, get(w, H_ERROR))
    put(w, 104, get(w, H_NAMEID))
    put(w, 112, choose(action == 1, QUERY_WIRE, get(w, H_WIREPTR)))
    put(w, 120, choose(action == 1, 64, get(w, H_WIREBYTES)))
    put(w, 128, choose(action == 4, get(w, H_HELPERPTR), 0))
    put(w, 136, choose(action == 4, get(w, H_HELPERBYTES), 0))
    put(w, 144, choose(action == 4, CONT_WIRE, 0))
    put(w, 152, choose(action == 4, get(w, H_CONTBYTES), 0))
    put(w, 160, choose(action == 4, CONT_WIRE + 64, 0))
    put(w, 168, choose(action == 4, get(w, H_NAMEBYTES), 0))
    put(w, 176, choose(action == 2, get(w, H_GROW), 0))
    put(w, 184, get(w, H_REASON))
    put(w, 192, choose(action == 4, HEADER_COPY, 0))
    put(w, 200, choose(action == 4, 64, 0))
    put(w, 208, choose(action == 4, get(w, H_FRAMEBYTES), 0))
    fill_range(w, 216, 40, 0)
    return 256

def refused(w:mutbuf, reason:u64) -> u32:
    if get(w, H_BROKEN) == 0:
        put(w, H_REASON, reason)
    put(w, H_BROKEN, 1)
    put(w, H_PHASE, 99)
    event(w, 5)
    return BAD

def poison(w:mutbuf, reason:u64) -> u64:
    refused(w, reason)
    return BAD

def pending(w:mutbuf) -> u32:
    if get(w, H_BROKEN) != 0:
        return BAD
    if get(w, H_GROW) <= length(w):
        return refused(w, 90)
    return event(w, 2)

def need(w:mutbuf, required:u64) -> u64:
    if required <= length(w):
        return 1
    doubled = length(w)
    if doubled <= MAX >> 1:
        doubled = doubled * 2
    put(w, H_GROW, choose(doubled > required, doubled, required))
    return 0

def ir_fail(w:mutbuf, error:u64) -> u64:
    if get(w, IR_ERROR) == 0:
        put(w, IR_ERROR, error)
    return 0

def checked_end(w:mutbuf, node:u64) -> u64:
    end = get(w, H_HEAP)
    if node < CONTROL_BYTES or node > end or end - node < 16:
        poison(w, 91)
        return MAX
    size = get(w, node + 8)
    if size > end - node - 16:
        poison(w, 92)
        return MAX
    return node + 16 + size

def list_count(w:mutbuf, node:u64) -> u64:
    stop = checked_end(w, node)
    if stop == MAX or get(w, node) != 5 or get(w, node + 8) < 8:
        return MAX
    count = get(w, node + 16)
    if count > (stop - node - 24) >> 4:
        return MAX
    return count

def nth(w:mutbuf, node:u64, index:u64) -> u64:
    count = list_count(w, node)
    if count == MAX or index >= count:
        return MAX
    stop = checked_end(w, node)
    at = node + 24
    i = 0
    while i < index:
        at = checked_end(w, at)
        if at == MAX or at > stop:
            return MAX
        i = i + 1
    end = checked_end(w, at)
    if end == MAX or end > stop:
        return MAX
    return at

def field(w:mutbuf, node:u64, key:u64) -> u64:
    stop = checked_end(w, node)
    if stop == MAX or get(w, node) != 6 or get(w, node + 8) < 8:
        return MAX
    count = get(w, node + 16)
    if count > (stop - node - 24) >> 5:
        return MAX
    at = node + 24
    i = 0
    while i < count:
        value = checked_end(w, at)
        if value == MAX or value > stop or stop - value < 16:
            return MAX
        next_ = checked_end(w, value)
        if next_ == MAX or next_ > stop:
            return MAX
        if word(w, at, key) != 0:
            return value
        at = next_
        i = i + 1
    return MAX

def number(w:mutbuf, node:u64, maximum:u64) -> u64:
    stop = checked_end(w, node)
    if stop == MAX or get(w, node) != 2:
        return MAX
    size = get(w, node + 8)
    if size == 0 or size > 20:
        return MAX
    if size > 1 and byte(w, node + 16) == 48:
        return MAX
    value = 0
    i = 0
    while i < size:
        unit = byte(w, node + 16 + i)
        if unit < 48 or unit > 57:
            return MAX
        digit = unit - 48
        if value > 1844674407370955161 or (value == 1844674407370955161 and digit > 5):
            return MAX
        value = value * 10 + digit
        if value > maximum:
            return MAX
        i = i + 1
    return value

def identifier(w:mutbuf, node:u64) -> u64:
    value = number(w, node, 4294967295)
    return choose(value == 0, MAX, value)

def cached(w:mutbuf, identifier:u64) -> u64:
    at = get(w, H_CACHE)
    while at != 0:
        if get(w, at + 8) == identifier:
            return get(w, at + 16)
        at = get(w, at)
    return 0

def packet_reserve(w:mutbuf, size:u64) -> u64:
    used = get(w, H_OUTUSED)
    if used > PACKET_LIMIT or size > PACKET_LIMIT - used:
        poison(w, 93)
        return MAX
    put(w, H_OUTUSED, used + size)
    return PACKET_BASE + used

def packet_list(w:mutbuf, count:u64) -> u64:
    at = packet_reserve(w, 24)
    if at == MAX:
        return MAX
    put(w, at, 5)
    put(w, at + 8, 8)
    put(w, at + 16, count)
    return at

def packet_finish(w:mutbuf, at:u64) -> u64:
    if at == MAX or get(w, H_BROKEN) != 0:
        return 0
    put(w, at + 8, PACKET_BASE + get(w, H_OUTUSED) - at - 16)
    return 1

def packet_value(w:mutbuf, node:u64) -> u64:
    stop = checked_end(w, node)
    if stop == MAX:
        return 0
    at = packet_reserve(w, stop - node)
    if at == MAX:
        return 0
    move_bytes(w, at, node, stop - node)
    return 1

def packet_flat(w:mutbuf, descriptor:u64) -> u64:
    node = field(w, descriptor, K_flat)
    if node == MAX or list_count(w, node) == MAX:
        poison(w, 94)
        return 0
    return packet_value(w, node)
'''

def literals_source():
    lines = ['def word(w:mutbuf, node:u64, literal:u64) -> u64:',
             '    if get(w, node) != 4:', '        return 0',
             '    if literal <= K_poll:', '        return word_first(w, node, literal)',
             '    return word_second(w, node, literal)']
    for group, names in (('first', KEYS[:10]), ('second', KEYS[10:])):
        lines += [f'def word_{group}(w:mutbuf, node:u64, literal:u64) -> u64:']
        for name in names:
            raw = name.encode('ascii')
            conditions = [f'literal == K_{name}', f'get(w, node + 8) == {len(raw)}']
            conditions += [f'byte(w, node + {16 + i}) == {unit}' for i, unit in enumerate(raw)]
            lines += ['    if ' + ' and '.join(conditions) + ':', '        return 1']
        lines += ['    return 0']
    return '\n'.join(lines) + '\n'
