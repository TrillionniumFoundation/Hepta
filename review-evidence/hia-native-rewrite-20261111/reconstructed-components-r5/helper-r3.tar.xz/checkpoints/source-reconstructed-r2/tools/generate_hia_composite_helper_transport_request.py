"""Complete reconstructed HIA helper request/issued-QUERY owner, revision r2.

All request projection and descriptor traversal happen in HIA. The fixed host
executor can only copy leases, grow this workspace, call QUERY, call the helper,
and forward the resulting bytes. No hosted registry or helper packet planning.
"""
from __future__ import annotations

BODY = r'''
def helper_request(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < CONTROL_BYTES:
        return BAD
    if get(w, H_BROKEN) != 0:
        return BAD
    if get(w, H_MAGIC) == 0:
        if initial(s, r, w) == 0:
            return refused(w, 1)
    elif get(w, H_MAGIC) != STATE_MAGIC:
        return refused(w, 2)
    if configuration(w) == 0:
        return refused(w, 3)
    put(w, H_GROW, 0)
    phase = get(w, H_PHASE)
    if phase == 1:
        if metadata(s, r, w) == 0:
            return pending(w)
    elif phase == 2:
        if receive_query(s, r, w) == 0:
            return pending(w)
    else:
        return refused(w, 4)
    return continue_request(w)

def configuration(w:mutbuf) -> u64:
    if get(w, 256) != CONFIG_MAGIC:
        return 0
    if get(w, 264) != get(w, H_LEASE) or get(w, 272) != get(w, H_IRLEASE):
        return 0
    if get(w, 280) != get(w, H_IRSTREAM) or get(w, 288) != get(w, H_REQUEST):
        return 0
    if get(w, 296) != get(w, H_FSERIAL) or get(w, 304) != get(w, H_SLOTS):
        return 0
    if get(w, 312) != get(w, H_TYPELEASE) or get(w, 320) != get(w, H_TYPECMD):
        return 0
    if get(w, 328) != get(w, H_QUERYINPUTBYTES):
        return 0
    i = 336
    while i < 384:
        if get(w, i) != 0:
            return 0
        i = i + 8
    return 1

def initial(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    if get(w, 256) != CONFIG_MAGIC or get(w, 264) == 0 or get(w, 272) == 0:
        return 0
    if get(w, 280) == 0 or get(w, 312) == 0 or get(w, 320) == 0 or get(w, 328) == 0:
        return 0
    fill_range(w, 512, 512, 0)
    put(w, H_MAGIC, STATE_MAGIC)
    put(w, H_PHASE, 1)
    put(w, H_LEASE, get(w, 264))
    put(w, H_IRLEASE, get(w, 272))
    put(w, H_IRSTREAM, get(w, 280))
    put(w, H_REQUEST, get(w, 288))
    put(w, H_FSERIAL, get(w, 296))
    put(w, H_SLOTS, get(w, 304))
    put(w, H_TYPELEASE, get(w, 312))
    put(w, H_TYPECMD, get(w, 320))
    put(w, H_QSEQ, get(w, 328) - 1)
    put(w, H_QUERYINPUTBYTES, get(w, 328))
    if metadata_header(s, r, w, 0) == 0:
        return 0
    return 1

def metadata_header(s:readbuf, r:readbuf, w:mutbuf, repeated:u64) -> u64:
    if length(s) < IR_BASE or length(r) < 80:
        return 0
    if read(s, 0) != IR_MAGIC or read(s, 8) != 2 or read(s, 184) != 0:
        return 0
    if read(s, 16) != get(w, H_IRLEASE) or read(s, 24) != get(w, H_IRSTREAM):
        return 0
    if read(s, 32) != FN_MAGIC or read(s, 40) != 6 or read(s, 48) != get(w, H_REQUEST):
        return 0
    if read(s, 56) != get(w, H_FSERIAL) or read(s, 64) != get(w, H_SLOTS):
        return 0
    if read(s, 128) != 0 or read(s, 136) == 0:
        return 0
    used = read(s, 144)
    root = read(s, 120)
    if used < IR_BASE + 80 or used > length(s) or used >= REF:
        return 0
    if root < IR_BASE or root > used - 80 or (root & 7) != 0:
        return 0
    if read(s, 136) > (used - IR_BASE) >> 6:
        return 0
    if read(r, 0) != SOURCE_MAGIC or read(r, 24) != 64:
        return 0
    if read(r, 8) != read(s, 88) or read(r, 16) != read(s, 104):
        return 0
    if read(r, 32) != read(s, 96) or length(r) != read(s, 112):
        return 0
    if read(r, 40) != length(r) or read(r, 48) != 0 or read(r, 56) != 0:
        return 0
    if repeated == 0:
        put(w, H_IRSIZE, used)
        put(w, H_SRCSIZE, length(r))
        put(w, H_IRNODES, read(s, 136))
        put(w, H_IRROOT, root)
    else:
        if used != get(w, H_IRSIZE) or length(r) != get(w, H_SRCSIZE):
            return 0
        if root != get(w, H_IRROOT) or read(s, 136) != get(w, H_IRNODES):
            return 0
    return 1

def metadata(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    if metadata_header(s, r, w, 1) == 0:
        poison(w, 5)
        return 0
    nodes = get(w, H_IRNODES)
    if nodes > (MAX - IR_STACK) >> 5:
        poison(w, 6)
        return 0
    base = IR_STACK + nodes * 32
    if need(w, base) == 0:
        return 0
    root = get(w, H_IRROOT)
    if ir_list_shape(s, r, root, 7) == 0 or ir_unsigned(s, r, ir_child(s, r, root, 0)) != 6:
        poison(w, 7)
        return 0
    put(w, IR_OUTPUT_BASE, base)
    put(w, IR_LIMIT, nodes)
    put(w, IR_MODE, 0)
    put(w, IR_CURSOR, 0)
    put(w, IR_ERROR, 0)
    ir_emit_view(s, r, w, root)
    size = get(w, IR_CURSOR)
    if get(w, IR_ERROR) != 0 or size > MAX - base - 7:
        poison(w, 8)
        return 0
    if need(w, align8(base + size)) == 0:
        return 0
    put(w, IR_MODE, 1)
    put(w, IR_CURSOR, 0)
    ir_emit_view(s, r, w, root)
    if get(w, IR_ERROR) != 0 or get(w, IR_CURSOR) != size:
        poison(w, 9)
        return 0
    put(w, H_META, base)
    put(w, H_HEAP, align8(base + size))
    if list_count(w, base) != 7:
        poison(w, 10)
        return 0
    put(w, H_PHASE, 3)
    return 1

def request_descriptor(w:mutbuf, identifier:u64, role:u64) -> u64:
    if identifier == 0 or identifier > 4294967295:
        poison(w, 11)
        return 0
    descriptor = cached(w, identifier)
    if descriptor != 0:
        return descriptor
    if get(w, H_QSEQ) == MAX:
        poison(w, 12)
        return 0
    put(w, H_QSEQ, get(w, H_QSEQ) + 1)
    put(w, H_QID, identifier)
    put(w, H_QROLE, role)
    put(w, H_QUERYOFFSET, 0)
    put(w, H_QUERYBYTES, 0)
    put(w, H_QUERY_RSIZE, 0)
    put(w, QUERY_WIRE, QUERY_MAGIC)
    put(w, QUERY_WIRE + 8, get(w, H_TYPELEASE))
    put(w, QUERY_WIRE + 16, get(w, H_TYPECMD))
    put(w, QUERY_WIRE + 24, get(w, H_QSEQ))
    put(w, QUERY_WIRE + 32, identifier)
    fill_range(w, QUERY_WIRE + 40, 24, 0)
    put(w, H_PHASE, 2)
    return 0

def query_wait(w:mutbuf) -> u32:
    if get(w, H_BROKEN) != 0:
        return BAD
    if get(w, H_PHASE) != 2:
        return refused(w, 13)
    return event(w, 1)

def receive_query(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    if length(s) != 128 or read(s, 0) != TYPE_EVENT or read(s, 8) != 0:
        poison(w, 14)
        return 0
    if read(s, 16) != get(w, H_TYPELEASE) or read(s, 24) != get(w, H_TYPECMD):
        poison(w, 15)
        return 0
    if read(s, 32) != get(w, H_QSEQ) or read(s, 40) != 0 or read(s, 48) != 0:
        poison(w, 16)
        return 0
    if read(s, 56) != get(w, H_QID) or read(s, 88) != 4 or read(s, 96) != 1 or read(s, 120) != 0:
        poison(w, 17)
        return 0
    at = read(s, 104)
    size = read(s, 112)
    if at > length(r) or size < 24 or size > length(r) - at:
        poison(w, 18)
        return 0
    if get(w, H_QUERYBYTES) == 0:
        put(w, H_QUERYOFFSET, at)
        put(w, H_QUERYBYTES, size)
        put(w, H_QUERY_RSIZE, length(r))
        if get(w, H_CACHE) == 0:
            put(w, H_CACHED, read(s, 64))
            put(w, H_ACTIVE, read(s, 72))
            put(w, H_STEPS, read(s, 80))
    elif at != get(w, H_QUERYOFFSET) or size != get(w, H_QUERYBYTES) or length(r) != get(w, H_QUERY_RSIZE):
        poison(w, 19)
        return 0
    if read(s, 64) != get(w, H_CACHED) or read(s, 72) != get(w, H_ACTIVE) or read(s, 80) != get(w, H_STEPS):
        poison(w, 20)
        return 0
    heap = get(w, H_HEAP)
    if size > MAX - 31 or align8(size) > MAX - heap - 24:
        poison(w, 21)
        return 0
    if need(w, heap + 24 + align8(size)) == 0:
        return 0
    node = heap + 24
    copy_bytes(w, r, node, at, size)
    put(w, H_HEAP, node + align8(size))
    if get(w, node) != 6 or get(w, node + 8) != size - 16 or get(w, node + 16) != 13:
        poison(w, 22)
        return 0
    if descriptor_shape(w, node) == 0 or identifier(w, field(w, node, K_id)) != get(w, H_QID):
        poison(w, 23)
        return 0
    put(w, heap, get(w, H_CACHE))
    put(w, heap + 8, get(w, H_QID))
    put(w, heap + 16, node)
    put(w, H_CACHE, heap)
    put(w, H_PHASE, 3)
    return 1

def descriptor_shape(w:mutbuf, node:u64) -> u64:
    if field(w, node, K_id) == MAX or field(w, node, K_kind) == MAX or field(w, node, K_name) == MAX:
        return 0
    if field(w, node, K_args) == MAX or field(w, node, K_flat) == MAX or field(w, node, K_fields) == MAX:
        return 0
    if field(w, node, K_variants) == MAX or field(w, node, K_state) == MAX or field(w, node, K_result) == MAX:
        return 0
    if field(w, node, K_poll) == MAX or field(w, node, K_cancel) == MAX or field(w, node, K_linear) == MAX or field(w, node, K_record) == MAX:
        return 0
    return choose(get(w, H_BROKEN) == 0, 1, 0)

def continue_request(w:mutbuf) -> u32:
    if get(w, H_TASK_DESC) == 0:
        task = identifier(w, nth(w, get(w, H_META), 1))
        descriptor = request_descriptor(w, task, 1)
        if descriptor == 0:
            return query_wait(w)
        put(w, H_TASK_DESC, descriptor)
    if get(w, H_STEP_DESC) == 0:
        step = identifier(w, nth(w, get(w, H_META), 2))
        descriptor = request_descriptor(w, step, 2)
        if descriptor == 0:
            return query_wait(w)
        put(w, H_STEP_DESC, descriptor)
    # The original adapter resolves both issued task and step before it checks
    # the helper counter; do not move this gate ahead of those QUERYs.
    serial = number(w, nth(w, get(w, H_META), 4), 8192)
    if serial == MAX:
        return refused(w, 24)
    put(w, H_STARTSERIAL, serial)
    return build_packet(w)

def start_packet(w:mutbuf) -> u64:
    put(w, H_OUTUSED, 0)
    put(w, H_ROOT_OUT, packet_list(w, 11))
    if packet_value(w, nth(w, get(w, H_META), 4)) == 0:
        return 0
    if packet_value(w, nth(w, get(w, H_META), 3)) == 0:
        return 0
    if packet_flat(w, get(w, H_TASK_DESC)) == 0:
        return 0
    put(w, H_BUILD_STAGE, 1)
    return 1

def build_packet(w:mutbuf) -> u32:
    while get(w, H_BROKEN) == 0:
        stage = get(w, H_BUILD_STAGE)
        if stage == 0:
            if start_packet(w) == 0:
                return BAD
        elif stage == 1 or stage == 2:
            key = choose(stage == 1, K_state, K_result)
            type_id = identifier(w, field(w, get(w, H_TASK_DESC), key))
            descriptor = request_descriptor(w, type_id, 3)
            if descriptor == 0:
                return query_wait(w)
            if packet_flat(w, descriptor) == 0:
                return BAD
            put(w, H_BUILD_STAGE, stage + 1)
        elif stage == 3:
            if packet_flat(w, get(w, H_STEP_DESC)) == 0:
                return BAD
            variants = field(w, get(w, H_STEP_DESC), K_variants)
            count = list_count(w, variants)
            if count == MAX:
                return refused(w, 25)
            put(w, H_VARIANTS, variants)
            put(w, H_VARIANT_INDEX, 0)
            put(w, H_VARIANTS_OUT, packet_list(w, count))
            put(w, H_BUILD_STAGE, 4)
        elif stage == 4:
            if get(w, H_VARIANT_INDEX) == list_count(w, get(w, H_VARIANTS)):
                if packet_finish(w, get(w, H_VARIANTS_OUT)) == 0:
                    return BAD
                put(w, H_BUILD_STAGE, 6)
            else:
                if start_variant(w) == 0:
                    return BAD
        elif stage == 5:
            if get(w, H_FIELD_INDEX) == list_count(w, get(w, H_FIELDS)):
                if packet_finish(w, get(w, H_FIELDS_OUT)) == 0 or packet_finish(w, get(w, H_VARIANT_OUT)) == 0:
                    return BAD
                put(w, H_VARIANT_INDEX, get(w, H_VARIANT_INDEX) + 1)
                put(w, H_BUILD_STAGE, 4)
            else:
                pair = nth(w, get(w, H_FIELDS), get(w, H_FIELD_INDEX))
                if list_count(w, pair) != 2:
                    return refused(w, 26)
                type_id = identifier(w, nth(w, pair, 1))
                descriptor = request_descriptor(w, type_id, 3)
                if descriptor == 0:
                    return query_wait(w)
                if packet_flat(w, descriptor) == 0:
                    return BAD
                put(w, H_FIELD_INDEX, get(w, H_FIELD_INDEX) + 1)
        elif stage == 6:
            return finish_packet(w)
        else:
            return refused(w, 27)
    return BAD

def start_variant(w:mutbuf) -> u64:
    pair = nth(w, get(w, H_VARIANTS), get(w, H_VARIANT_INDEX))
    if list_count(w, pair) != 2:
        poison(w, 28)
        return 0
    fields = nth(w, pair, 1)
    count = list_count(w, fields)
    if count == MAX:
        poison(w, 29)
        return 0
    put(w, H_VARIANT_OUT, packet_list(w, 2))
    if packet_value(w, nth(w, pair, 0)) == 0:
        return 0
    put(w, H_FIELDS, fields)
    put(w, H_FIELD_INDEX, 0)
    put(w, H_FIELDS_OUT, packet_list(w, count))
    if get(w, H_BROKEN) != 0:
        return 0
    put(w, H_BUILD_STAGE, 5)
    return 1

def finish_packet(w:mutbuf) -> u32:
    if packet_value(w, field(w, get(w, H_TASK_DESC), K_poll)) == 0:
        return BAD
    if packet_value(w, field(w, get(w, H_TASK_DESC), K_cancel)) == 0:
        return BAD
    if packet_value(w, nth(w, get(w, H_META), 5)) == 0:
        return BAD
    if packet_value(w, nth(w, get(w, H_META), 6)) == 0:
        return BAD
    if packet_finish(w, get(w, H_ROOT_OUT)) == 0:
        return BAD
    put(w, H_WIREPTR, PACKET_BASE)
    put(w, H_WIREBYTES, get(w, H_OUTUSED))
    put(w, H_PHASE, 9)
    return event(w, 3)
'''
