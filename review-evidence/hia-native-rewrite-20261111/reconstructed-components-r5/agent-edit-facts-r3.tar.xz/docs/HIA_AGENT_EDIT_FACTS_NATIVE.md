# Native edit selection and exact function facts

This is a development component, not an installed complete Agent query owner.
The generated source is `examples/hia_bootstrap/agent_edit_facts.hiaasm`.
It owns field selection, function/block/output resolution and every byte of
the existing `HIASLC01` function packet. The unchanged native Agent slice owner
then owns the complete data/control-flow slice and its original view limits.

## Private input and continuation

The three-buffer ABI is `(command readbuf, source mutbuf, work mutbuf) -> u32`.
The source mutbuf is borrowed read-only internally. It is an immutable genuine
`HIASIL01` source/index lease whose typed root is `[verified_program, selection]`.
The native packet issuer must actually have validated that exact source and
produced its complete node bitmap. Whole-program admission is a separate
mandatory predecessor. A header, hash or bitmap alone is not authentication.

The command is exactly eight little-endian u64 words:
`[HIAQFC01, action, lease, request, sequence, 0, 0, 0]`. Action 1 begins with
sequence zero; action 2 continues the immediately preceding GROW event. Lease
and request are nonzero. A fresh workspace has at least 512 bytes and its
initial 512 bytes are zero. Storage grows from actual graph counts without
introducing another public graph quota. The coordinator retains the same
immutable source and preserves every prior workspace byte while growing.

Each successful entry returns 384, with this 128-byte event at workspace 256:

| Word | Meaning |
| --- | --- |
| 0 | `HIAQFE01` |
| 1 | 0 DONE, 1 GROW, 2 semantic refusal, 3 permanent private refusal |
| 2–4 | lease, request, monotonically increasing event sequence |
| 5 | complete required workspace bytes |
| 6–7 | fact packet offset and byte length |
| 8–10 | selected function, block and operation source references |
| 11–12 | block declaration index and operation index within that block |
| 13 | fields mask: args=1, attrs=2, op=4 |
| 14–15 | error and reserved zero |

Semantic errors 1–5 retain field, selector-kind, function, block and SSA-output
order. Error 6 is the existing 8 MiB fact transport profile. Private errors
return `0xfffffffd` and poison a sufficiently large workspace permanently.
Too-short workspaces must be discarded immediately because they cannot hold
the poison marker. Replaying a completed or refused invocation is invalid.
The source references and output packet must remain attached to the actual
producing invocation; they are not externally supplied authority.

The fact arrays retain declaration-order values, complete op arguments,
block parameters and all terminators. Terminator argument ranges and edge
argument ranges intentionally repeat the same argument links exactly as the
retained independent implementation does. Names use a native open-addressed
table with full byte comparison after hashing. Hash equality never decides
name identity.

## Actual development evidence

The exact HIA source is 110,153 bytes, SHA-256
`ec46bb572dc374486aa1030de501e665d5a937bdb5ed62db0c2c8fc83a52dfcd`.
It has 42 functions, 471 total blocks, maximum 53 blocks in one function and
1,595 operations. The original compiler limits remain 128/1536/256/8192.

Two independent hand-authored complete fact packets were matched through
four Core VM entries before native compilation. The actual B3 image from
published head `0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5` compiled the component
under the original 1 MiB compiler buffers, 10 CPU seconds and 256 MiB address
space. The resulting 183,147-byte native image has SHA-256
`e37c0870daafe7e5a12fe21629e9affddb07aed8edd29f4700899b58ed953052`.

The third native development attempt passed 130 semantic cases and 19 private
protocol controls in 30.616987736 seconds: 263 fact-kernel entries and 130
actual native packet-issuer entries. Every successful fact packet matched
the independent old encoder byte-for-byte and was consumed by the actual
unchanged native slice image. Four cases also compared every VM workspace
byte. Tests cover resource/no-result operations, returned loans, multiple
results, shuffled CFG declarations, 63/64/65/4096 blocks, 255/256/257 visible
operations, original selector failure order, precise GROW identity and permanent
refusal. Full source, command, workspace-before/workspace-after bytes and
canary observations were retained.

The first native attempt failed because the test executed its independent VM
inside a deliberately disabled host JSON-decoder region. The second completed
47 resource selections, then its random fixture was rejected for duplicate
SSA names across blocks. Both original attempts, stderr and test sources remain
separate. The original compile summary accidentally reported its last fixture's
function/block count; an independent metadata erratum records the actual
42/471 counts from the unchanged source and real compiler receipt. No native
execution or failure was rewritten.

## Remaining integration

Complete query construction, canonical byte budgeting, operation/query hashes,
full query replay, simultaneous batch application and untrusted presentation
are separate work still in progress. The existing integer-only source issuer
does not by itself implement arbitrary external selector/capture semantics.
General object capture must preserve all original kinds and failures, including
finite floats and tuples wherever the public API distinguishes them. All
retained full application tests, current-source cold qualification and complete
native driver custody remain required before activation or old-stack removal.
