"""Preserve the fresh completed cold originals without altering their files."""
from pathlib import Path
from hashlib import sha256
import io, json, os, stat, tarfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
COLD = ROOT / 'hia-v67-0ef-qualification-local-01'
DEV = ROOT / 'hia-v67-workflow-fix-development'
OUT = ROOT / 'hia-v67-0ef-independent-audit'
OUT.mkdir(mode=0o700, exist_ok=False)
ARCHIVE = ROOT / 'HIA-v67-0ef9541-local-cold-20261111.tar.xz'

def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def digest_file(path):
    initial = path.lstat()
    assert stat.S_ISREG(initial.st_mode) and not path.is_symlink()
    h = sha256()
    with path.open('rb') as stream:
        assert identity(os.fstat(stream.fileno())) == identity(initial)
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
        assert identity(os.fstat(stream.fileno())) == identity(initial)
    assert identity(path.lstat()) == identity(initial)
    return h.hexdigest(), initial

paths = {}
directories = {}
for path in sorted(COLD.rglob('*')):
    name = 'qualification/' + path.relative_to(COLD).as_posix()
    if path.is_dir() and not path.is_symlink():
        directories[name] = stat.S_IMODE(path.lstat().st_mode)
    else:
        paths[name] = path
for path in sorted((DEV / 'source-suite-attempt1').rglob('*')):
    if path.is_file():
        paths['source-controls/' + path.relative_to(DEV / 'source-suite-attempt1').as_posix()] = path
for name in ['source-frozen.json', 'freeze-receipt.json', 'publication.json', 'generation.json',
             'run_full_source.py', 'run_published_cold.py', 'source-controller.stdout.log',
             'source-controller.stderr.log', 'cold-controller.stdout.log', 'cold-controller.stderr.log']:
    paths['control/' + name] = DEV / name
rows = {}
identities = {}
for name, path in paths.items():
    digest, info = digest_file(path)
    rows[name] = {'bytes': info.st_size, 'sha256': digest, 'mode': stat.S_IMODE(info.st_mode),
                  'original_path': str(path)}
    identities[name] = identity(info)
manifest = {'schema': 'hia.original-cold-custody.v1',
            'source_head': '0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5',
            'source_tree': '6ef9e1713065436a3b1886fe9edcf0a4a1120773',
            'scope': 'FRESH_LOCAL_PUBLISHED_SOURCE_COLD_AND_COMPLETE_SOURCE_CONTROLS',
            'files': rows, 'directories': directories,
            'retained_suite_or_full_native_stack_claimed': False}
encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
(OUT / 'custody.json').write_bytes(encoded)
with tarfile.open(ARCHIVE, 'x:xz', preset=4) as archive:
    for name, mode in directories.items():
        member = tarfile.TarInfo(name)
        member.type, member.mode = tarfile.DIRTYPE, mode
        archive.addfile(member)
    for name, path in paths.items():
        row = rows[name]
        assert identity(path.lstat()) == identities[name]
        member = tarfile.TarInfo(name)
        member.size, member.mode = row['bytes'], row['mode']
        with path.open('rb') as stream:
            assert identity(os.fstat(stream.fileno())) == identities[name]
            archive.addfile(member, stream)
            assert identity(os.fstat(stream.fileno())) == identities[name]
        assert identity(path.lstat()) == identities[name]
    member = tarfile.TarInfo('CUSTODY.json')
    member.size, member.mode = len(encoded), 0o644
    archive.addfile(member, io.BytesIO(encoded))
with tarfile.open(ARCHIVE, 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(rows) + len(directories) + 1
    assert len({m.name for m in members}) == len(members)
    for member in members:
        if member.name == 'CUSTODY.json':
            assert archive.extractfile(member).read() == encoded
        elif member.name in directories:
            assert member.isdir() and member.mode == directories[member.name]
        else:
            row = rows[member.name]
            assert member.isfile() and member.size == row['bytes'] and member.mode == row['mode']
            h = sha256()
            with archive.extractfile(member) as stream:
                for chunk in iter(lambda: stream.read(1 << 20), b''):
                    h.update(chunk)
            assert h.hexdigest() == row['sha256']
for name, path in paths.items():
    digest, info = digest_file(path)
    assert digest == rows[name]['sha256'] and identity(info) == identities[name]
receipt = {'archive': str(ARCHIVE), 'bytes': ARCHIVE.stat().st_size,
           'sha256': digest_file(ARCHIVE)[0], 'regular_members': len(rows) + 1,
           'directory_members': len(directories), 'original_bytes': sum(r['bytes'] for r in rows.values()),
           'custody_sha256': sha256(encoded).hexdigest(),
           'all_original_bytes_modes_and_live_identities_read_back': True,
           'native_qualification_reexecuted': False, 'nested_phase_audit_separate': True,
           'whole_stack_closed': False}
(OUT / 'seal-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(receipt), flush=True)

