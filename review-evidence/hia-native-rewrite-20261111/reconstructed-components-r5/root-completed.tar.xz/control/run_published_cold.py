"""Fresh cold run of the actual published 0ef head; preserve every outcome."""
from pathlib import Path
from hashlib import sha256
import json, os, platform, subprocess, sys, time, traceback

ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-workflow-qualified')
DEV = Path('/workspace/scratch/9acdfa9f5639/hia-v67-workflow-fix-development')
OUT = Path('/workspace/scratch/9acdfa9f5639/hia-v67-0ef-qualification-local-01')
HEAD = '0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5'
TREE = '6ef9e1713065436a3b1886fe9edcf0a4a1120773'
OUT.mkdir(mode=0o700, exist_ok=False)
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
from tools.hia_core_source_identity import _source_state
from tools.hia_selfhost_contract import validate_contract, CONTRACT_PATH

def dump(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

before = _source_state()
dump('source-before.json', before)
assert before['head'] == HEAD and before['tree'] == TREE and not before['status']
assert len(before['files']) == 2798
contract = validate_contract()
closure = {**contract['source_identity']['files'],
           CONTRACT_PATH: sha256((ROOT / CONTRACT_PATH).read_bytes()).hexdigest()}
assert len(closure) == 644 and all(before['files'][n] == h for n, h in closure.items())
frozen = json.loads((DEV / 'source-frozen.json').read_text())
assert frozen['source_closure'] == closure
suite = json.loads((DEV / 'source-suite-attempt1/summary.json').read_text())
assert suite['passed'] and suite['tests_run'] == 331 and suite['source_preserved']
assert suite['selected_test_ids'] == suite['executed_test_ids']
assert len(suite['selected_test_ids']) == len(set(suite['selected_test_ids'])) == 331
assert not any(suite[k] for k in ('failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes'))
for name in ['source-before.json', 'source-after.json']:
    assert json.loads((DEV / 'source-suite-attempt1' / name).read_text()) == closure
dump('source-suite-prerequisite.json', suite)
dump('frozen-closure.json', closure)
command = [sys.executable, '-I', '-B', str(ROOT / 'tools/replay_hia_selfhost_cold.py'),
           '--output', str(OUT / 'cold.json')]
request = {'scope': 'NEW_LOCAL_PUBLISHED_HEAD_COLD_RUN', 'head': HEAD, 'tree': TREE,
           'source_commit_published_before_launch': True, 'source_files': 2798,
           'source_closure_files': 644, 'command': command, 'python': sys.version,
           'executable': sys.executable, 'platform': platform.platform(),
           'cold_limit_seconds': 180, 'oracle_workers': 2, 'expected_phases': 38,
           'retained_native_suite_claimed': False, 'whole_stack_closed': False}
dump('request.json', request)
started = time.monotonic_ns()
returncode, exception = None, None
try:
    with (OUT / 'stdout.log').open('xb') as out, (OUT / 'stderr.log').open('xb') as err:
        proc = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err,
                              env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    returncode = proc.returncode
except BaseException:
    exception = traceback.format_exc()
finally:
    elapsed = time.monotonic_ns() - started
    after_error, after = None, None
    try:
        after = _source_state()
        dump('source-after.json', after)
    except BaseException:
        after_error = traceback.format_exc()
    cold = json.loads((OUT / 'cold.json').read_text()) if (OUT / 'cold.json').is_file() else None
    summary = {'scope': request['scope'], 'head': HEAD, 'tree': TREE,
               'source_commit_published_before_launch': True, 'returncode': returncode,
               'controller_exception': exception, 'source_after_error': after_error,
               'source_preserved': before == after, 'wrapper_elapsed_ns': elapsed,
               'cold_status': cold.get('status') if cold else None,
               'cold_elapsed_ns': cold.get('wall_elapsed_ns') if cold else None,
               'checks': cold.get('checks') if cold else None,
               'cold_limit_seconds': 180, 'oracle_workers': 2, 'expected_phases': 38,
               'source_closure_matches': bool(cold and cold.get('source_manifest') == closure),
               'retained_native_suite_claimed': False, 'whole_stack_closed': False}
    summary['passed'] = bool(returncode == 0 and exception is None and after_error is None
                             and before == after and cold
                             and cold.get('status') == 'COLD_SELFHOST_REPLAY_PASS'
                             and cold.get('qualification_wall_limit_seconds') == 180
                             and cold.get('source_manifest') == closure
                             and len(cold.get('checks', {})) == 11
                             and all(cold['checks'].values()))
    dump('summary.json', summary)
    print(json.dumps(summary, sort_keys=True), flush=True)
raise SystemExit(0 if summary['passed'] else 1)

