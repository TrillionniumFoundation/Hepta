"""Native edit selection and complete function-fact transport.

This private component requires the actual immutable SourceIndexLease and a
successful whole-program admission for its captured document. It does not
authenticate external packets or replace the complete query coordinator.
"""
from __future__ import annotations
import ast
from hashlib import sha256
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_core_json_frontend import packed
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools import hia_agent_edit_source_views as shared

SHARED_SHA = '555472263213f15deb239fcf3bf8e5b273a28caf3a67bb29ffd037f171d7ae5c'
CONSTANTS = {
    'COMMAND': int.from_bytes(b'HIAQFC01', 'little'),
    'STATE': int.from_bytes(b'HIAQFW01', 'little'),
    'EVENT': int.from_bytes(b'HIAQFE01', 'little'),
    'SOURCE_MAGIC': int.from_bytes(b'HIASIL01', 'little'),
    'FACT_MAGIC': int.from_bytes(b'HIASLC01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1, 'REF': 1 << 63,
}
LITERALS = ('function', 'block', 'output', 'fields', 'functions', 'name', 'blocks', 'id',
            'ops', 'out', 'args', 'op', 'attrs', 'params', 'term', 'ret', 'jump',
            'branch', 'trap', 'values', 'cond', 'then', 'else', 'target')
SOURCE = r'''
def edit_facts(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 512:
        return BAD
    state = get(w, 8)
    if state == 3:
        return BAD
    if state == 2 or state == 4:
        return refuse(w, 256)
    if command(s) == 0 or source_lease(r) == 0:
        return refuse(w, 257)
    if state == 0:
        if word(s, 8) != 1 or word(s, 32) != 0:
            return refuse(w, 258)
        i = 0
        while i < 512:
            if byte(w, i) != 0:
                return refuse(w, 259)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(s, 16))
        put(w, 24, word(s, 24))
        put(w, 48, length(r))
        put(w, 56, word(r, 8))
        put(w, 416, word(r, 32))
        put(w, 424, word(r, 16))
        chosen = select_site(s, r, w)
        if chosen != 0:
            if chosen <= 5:
                return semantic(w, chosen)
            return refuse(w, chosen)
        if measure(s, r, w) == 0:
            return refuse(w, 260)
        if get(w, 184) > 8388608:
            return semantic(w, 6)
    else:
        if state != 1 or get(w, 0) != STATE or word(s, 8) != 2:
            return refuse(w, 261)
        if word(s, 16) != get(w, 16) or word(s, 24) != get(w, 24) or word(s, 32) != get(w, 40):
            return refuse(w, 262)
        if length(r) != get(w, 48) or word(r, 8) != get(w, 56):
            return refuse(w, 263)
        if word(r, 32) != get(w, 416) or word(r, 16) != get(w, 424):
            return refuse(w, 264)
    if get(w, 64) > length(w):
        return event(w, 1, 0)
    if build_graph(s, r, w) == 0:
        return refuse(w, 265)
    put(w, 8, 2)
    return event(w, 0, 0)

def command(s:readbuf) -> u64:
    if length(s) != 64 or word(s, 0) != COMMAND:
        return 0
    if word(s, 16) == 0 or word(s, 24) == 0:
        return 0
    if word(s, 40) != 0 or word(s, 48) != 0 or word(s, 56) != 0:
        return 0
    return 1

def source_lease(r:readbuf) -> u64:
    if length(r) < 82 or word(r, 0) != SOURCE_MAGIC:
        return 0
    size = word(r, 8)
    if size < 16 or size > 67108864 or word(r, 24) != 64:
        return 0
    index = (64 + size + 7) & 18446744073709551608
    amount = (size + 7) >> 3
    if word(r, 16) != amount or word(r, 32) != index:
        return 0
    if word(r, 40) != length(r) or index > length(r) or amount != length(r) - index:
        return 0
    if word(r, 48) != 0 or word(r, 56) != 0 or word(r, 72) != size - 16:
        return 0
    if (byte(r, index) & 1) == 0:
        return 0
    at = 64 + size
    while at < index:
        if byte(r, at) != 0:
            return 0
        at = at + 1
    if (size & 7) != 0 and (byte(r, length(r) - 1) >> (size & 7)) != 0:
        return 0
    return 1

def event(w:mutbuf, action:u64, error:u64) -> u32:
    if get(w, 40) == MAX:
        put(w, 8, 3)
        put(w, 72, 266)
        return BAD
    put(w, 40, get(w, 40) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 40))
    put(w, 296, get(w, 64))
    put(w, 304, get(w, 216))
    put(w, 312, get(w, 184))
    put(w, 320, get(w, 80))
    put(w, 328, get(w, 88))
    put(w, 336, get(w, 96))
    put(w, 344, get(w, 104))
    put(w, 352, get(w, 112))
    put(w, 360, get(w, 120))
    put(w, 368, error)
    put(w, 376, 0)
    return 384

def refuse(w:mutbuf, error:u64) -> u32:
    put(w, 8, 3)
    put(w, 72, error)
    event(w, 3, error)
    return BAD

def semantic(w:mutbuf, error:u64) -> u32:
    put(w, 8, 4)
    put(w, 72, error)
    return event(w, 2, error)

def select_site(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    if list_shape(s, r, REF, 2) == 0:
        return 267
    doc = child(s, r, REF, 0)
    selection = child(s, r, REF, 1)
    if kind(s, r, doc) != 6 or kind(s, r, selection) != 6 or count(s, r, selection) != 4:
        return 268
    fields = field(s, r, selection, L_fields)
    if fields == 0 or kind(s, r, fields) != 5:
        return 1
    amount = count(s, r, fields)
    if amount == 0 or amount > 3:
        return 1
    mask = 0
    at = child(s, r, fields, 0)
    i = 0
    while i < amount:
        bit = 0
        if text_is(s, r, at, L_op) != 0:
            bit = 4
        elif text_is(s, r, at, L_args) != 0:
            bit = 1
        elif text_is(s, r, at, L_attrs) != 0:
            bit = 2
        if bit == 0 or (mask & bit) != 0:
            return 1
        mask = mask | bit
        at = following(s, r, at)
        i = i + 1
    put(w, 120, mask)
    function = field(s, r, selection, L_function)
    block = field(s, r, selection, L_block)
    output = field(s, r, selection, L_output)
    if kind(s, r, function) != 4 or kind(s, r, block) != 4 or kind(s, r, output) != 4:
        return 2
    functions = field(s, r, doc, L_functions)
    fn = named(s, r, functions, function, 0)
    if fn == 0:
        return 3
    put(w, 80, fn)
    blocks = field(s, r, fn, L_blocks)
    if kind(s, r, blocks) != 5:
        return 269
    put(w, 168, blocks)
    node = child(s, r, blocks, 0)
    i = 0
    while i < count(s, r, blocks):
        name = field(s, r, node, L_id)
        if kind(s, r, name) == 4 and text_equal(s, r, name, block) != 0:
            put(w, 88, node)
            put(w, 104, i)
            return select_output(s, r, w, node, output)
        node = following(s, r, node)
        i = i + 1
    return 4

def named(s:readbuf, r:readbuf, items:u64, name:u64, use_id:u64) -> u64:
    if items == 0 or kind(s, r, items) != 5:
        return 0
    item = child(s, r, items, 0)
    i = 0
    while i < count(s, r, items):
        candidate = field(s, r, item, L_name)
        if use_id != 0:
            candidate = field(s, r, item, L_id)
        if kind(s, r, candidate) == 4 and text_equal(s, r, candidate, name) != 0:
            return item
        item = following(s, r, item)
        i = i + 1
    return 0

def select_output(s:readbuf, r:readbuf, w:mutbuf, block:u64, output:u64) -> u64:
    ops = field(s, r, block, L_ops)
    if kind(s, r, ops) != 5:
        return 270
    op = child(s, r, ops, 0)
    i = 0
    while i < count(s, r, ops):
        outs = field(s, r, op, L_out)
        if named(s, r, outs, output, 0) != 0:
            put(w, 96, op)
            put(w, 112, i)
            return 0
        op = following(s, r, op)
        i = i + 1
    return 5

def add_count(w:mutbuf, slot:u64, amount:u64) -> u64:
    if amount > MAX - get(w, slot):
        return 0
    put(w, slot, get(w, slot) + amount)
    return 1

def term_kind(s:readbuf, r:readbuf, term:u64) -> u64:
    op = field(s, r, term, L_op)
    if text_is(s, r, op, L_ret) != 0:
        return 0
    if text_is(s, r, op, L_jump) != 0:
        return 1
    if text_is(s, r, op, L_branch) != 0:
        return 2
    if text_is(s, r, op, L_trap) != 0:
        return 3
    return 4

def edge_term(s:readbuf, r:readbuf, term:u64, k:u64, side:u64) -> u64:
    if k == 1:
        return term
    if side == 0:
        return field(s, r, term, L_then)
    return field(s, r, term, L_else)

def measure(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    blocks = get(w, 168)
    amount = count(s, r, blocks)
    if amount == 0:
        return 0
    put(w, 128, amount)
    block = child(s, r, blocks, 0)
    bi = 0
    while bi < amount:
        params = field(s, r, block, L_params)
        ops = field(s, r, block, L_ops)
        if kind(s, r, params) != 5 or kind(s, r, ops) != 5:
            return 0
        if add_count(w, 144, count(s, r, params)) == 0 or add_count(w, 136, count(s, r, ops)) == 0:
            return 0
        op = child(s, r, ops, 0)
        oi = 0
        while oi < count(s, r, ops):
            args = field(s, r, op, L_args)
            outs = field(s, r, op, L_out)
            if kind(s, r, args) != 5 or kind(s, r, outs) != 5:
                return 0
            if add_count(w, 144, count(s, r, outs)) == 0 or add_count(w, 160, count(s, r, args)) == 0:
                return 0
            op = following(s, r, op)
            oi = oi + 1
        if measure_term(s, r, w, field(s, r, block, L_term)) == 0:
            return 0
        block = following(s, r, block)
        bi = bi + 1
    return layout(w)

def measure_term(s:readbuf, r:readbuf, w:mutbuf, term:u64) -> u64:
    k = term_kind(s, r, term)
    if k == 4:
        return 0
    if k == 0:
        args = field(s, r, term, L_values)
        if kind(s, r, args) != 5:
            return 0
        return add_count(w, 160, count(s, r, args))
    if k == 3:
        return 1
    if k == 2 and add_count(w, 160, 1) == 0:
        return 0
    side = 0
    while side < k:
        edge = edge_term(s, r, term, k, side)
        args = field(s, r, edge, L_args)
        if kind(s, r, args) != 5 or count(s, r, args) > 9223372036854775807:
            return 0
        if add_count(w, 152, 1) == 0 or add_count(w, 160, count(s, r, args) * 2) == 0:
            return 0
        side = side + 1
    return 1

def layout(w:mutbuf) -> u64:
    amount = get(w, 128) + get(w, 144)
    if amount < get(w, 128) or amount > 144115188075855871:
        return 0
    slots = 2
    while slots < amount * 2:
        slots = slots * 2
    put(w, 192, slots)
    put(w, 200, 512)
    put(w, 208, 512 + get(w, 128) * 8)
    base = get(w, 208) + slots * 32
    put(w, 216, base)
    size = 64
    i = 0
    while i < 5:
        amount = get(w, 128 + i * 8)
        scale = 8
        if i == 0:
            scale = 64
        elif i == 1:
            scale = 40
        elif i == 2:
            scale = 16
        elif i == 3:
            scale = 32
        if amount > 288230376151711735:
            return 0
        part = amount * scale
        if size > MAX - part:
            return 0
        size = size + part
        if i < 4:
            put(w, 224 + i * 8, base + size)
        i = i + 1
    if base > MAX - size:
        return 0
    put(w, 184, size)
    put(w, 64, base + size)
    return 1

def name_hash(s:readbuf, r:readbuf, name:u64, scope:u64) -> u64:
    value = 14695981039346656037 ^ scope
    i = 0
    while i < text_size(s, r, name):
        value = (value ^ text_byte(s, r, name, i)) * 1099511628211
        i = i + 1
    return value

def name_slot(s:readbuf, r:readbuf, w:mutbuf, name:u64, scope:u64) -> u64:
    if kind(s, r, name) != 4:
        return 0
    h = name_hash(s, r, name, scope)
    slot = h & (get(w, 192) - 1)
    tried = 0
    while tried < get(w, 192):
        at = get(w, 208) + slot * 32
        previous = get(w, at)
        if previous == 0:
            return at
        if get(w, at + 8) == scope and get(w, at + 24) == h:
            if text_equal(s, r, previous, name) != 0:
                return at
        slot = (slot + 1) & (get(w, 192) - 1)
        tried = tried + 1
    return 0

def name_put(s:readbuf, r:readbuf, w:mutbuf, name:u64, scope:u64, value:u64) -> u64:
    at = name_slot(s, r, w, name, scope)
    if at == 0 or get(w, at) != 0:
        return 0
    put(w, at, name)
    put(w, at + 8, scope)
    put(w, at + 16, value)
    put(w, at + 24, name_hash(s, r, name, scope))
    return 1

def name_get(s:readbuf, r:readbuf, w:mutbuf, name:u64, scope:u64) -> u64:
    at = name_slot(s, r, w, name, scope)
    if at == 0 or get(w, at) == 0:
        return MAX
    return get(w, at + 16)

def emit_names(s:readbuf, r:readbuf, w:mutbuf, names:u64, bi:u64) -> u64:
    if kind(s, r, names) != 5:
        return 0
    at = child(s, r, names, 0)
    i = 0
    while i < count(s, r, names):
        if emit_name(s, r, w, at, bi) == 0:
            return 0
        at = following(s, r, at)
        i = i + 1
    return 1

def emit_name(s:readbuf, r:readbuf, w:mutbuf, name:u64, bi:u64) -> u64:
    value = name_get(s, r, w, name, bi + 1)
    cursor = get(w, 400)
    if value == MAX or cursor >= get(w, 160):
        return 0
    put(w, get(w, 248) + cursor * 8, value)
    put(w, 400, cursor + 1)
    return 1

def emit_values(s:readbuf, r:readbuf, w:mutbuf, values:u64, bi:u64, producer:u64) -> u64:
    item = child(s, r, values, 0)
    i = 0
    while i < count(s, r, values):
        cursor = get(w, 392)
        if cursor >= get(w, 144):
            return 0
        name = field(s, r, item, L_name)
        if name_put(s, r, w, name, bi + 1, cursor) == 0:
            return 0
        at = get(w, 232) + cursor * 16
        put(w, at, bi)
        put(w, at + 8, producer)
        put(w, 392, cursor + 1)
        item = following(s, r, item)
        i = i + 1
    return 1

def build_graph(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    at = get(w, 200)
    while at < get(w, 64):
        put(w, at, 0)
        at = at + 8
    base = get(w, 216)
    put(w, base, FACT_MAGIC)
    i = 0
    while i < 5:
        put(w, base + 8 + i * 8, get(w, 128 + i * 8))
        i = i + 1
    put(w, base + 48, get(w, 104))
    block = child(s, r, get(w, 168), 0)
    bi = 0
    while bi < get(w, 128):
        put(w, get(w, 200) + bi * 8, block)
        if name_put(s, r, w, field(s, r, block, L_id), 0, bi) == 0:
            return 0
        if build_block(s, r, w, block, bi) == 0:
            return 0
        block = following(s, r, block)
        bi = bi + 1
    if get(w, 384) != get(w, 136) or get(w, 392) != get(w, 144):
        return 0
    bi = 0
    while bi < get(w, 128):
        if build_term(s, r, w, get(w, get(w, 200) + bi * 8), bi) == 0:
            return 0
        bi = bi + 1
    if get(w, 408) != get(w, 152) or get(w, 400) != get(w, 160):
        return 0
    return 1

def build_block(s:readbuf, r:readbuf, w:mutbuf, block:u64, bi:u64) -> u64:
    params = field(s, r, block, L_params)
    ops = field(s, r, block, L_ops)
    at = get(w, 216) + 64 + bi * 64
    put(w, at, get(w, 392))
    put(w, at + 8, count(s, r, params))
    put(w, at + 16, get(w, 384))
    put(w, at + 24, count(s, r, ops))
    if emit_values(s, r, w, params, bi, MAX) == 0:
        return 0
    if bi == get(w, 104):
        put(w, get(w, 216) + 56, get(w, 384) + get(w, 112))
    op = child(s, r, ops, 0)
    i = 0
    while i < count(s, r, ops):
        if build_operation(s, r, w, op, bi) == 0:
            return 0
        op = following(s, r, op)
        i = i + 1
    return 1

def build_operation(s:readbuf, r:readbuf, w:mutbuf, op:u64, bi:u64) -> u64:
    cursor = get(w, 384)
    if cursor >= get(w, 136):
        return 0
    args = field(s, r, op, L_args)
    outs = field(s, r, op, L_out)
    at = get(w, 224) + cursor * 40
    put(w, at, bi)
    put(w, at + 8, get(w, 400))
    put(w, at + 16, count(s, r, args))
    put(w, at + 24, get(w, 392))
    put(w, at + 32, count(s, r, outs))
    if emit_names(s, r, w, args, bi) == 0 or emit_values(s, r, w, outs, bi, cursor) == 0:
        return 0
    put(w, 384, cursor + 1)
    return 1

def build_term(s:readbuf, r:readbuf, w:mutbuf, block:u64, bi:u64) -> u64:
    term = field(s, r, block, L_term)
    k = term_kind(s, r, term)
    if k > 3:
        return 0
    at = get(w, 216) + 64 + bi * 64
    put(w, at + 32, k)
    put(w, at + 40, MAX)
    start = get(w, 400)
    put(w, at + 48, start)
    if k == 0:
        if emit_names(s, r, w, field(s, r, term, L_values), bi) == 0:
            return 0
    elif k == 2:
        name = field(s, r, term, L_cond)
        value = name_get(s, r, w, name, bi + 1)
        if value == MAX or emit_name(s, r, w, name, bi) == 0:
            return 0
        put(w, at + 40, value)
    if k == 1 or k == 2:
        side = 0
        while side < k:
            edge = edge_term(s, r, term, k, side)
            if emit_names(s, r, w, field(s, r, edge, L_args), bi) == 0:
                return 0
            side = side + 1
    put(w, at + 56, get(w, 400) - start)
    if k == 1 or k == 2:
        side = 0
        while side < k:
            if build_edge(s, r, w, edge_term(s, r, term, k, side), bi) == 0:
                return 0
            side = side + 1
    return 1

def build_edge(s:readbuf, r:readbuf, w:mutbuf, edge:u64, bi:u64) -> u64:
    cursor = get(w, 408)
    if cursor >= get(w, 152):
        return 0
    target = name_get(s, r, w, field(s, r, edge, L_target), 0)
    if target == MAX or target >= get(w, 128):
        return 0
    args = field(s, r, edge, L_args)
    at = get(w, 240) + cursor * 32
    put(w, at, bi)
    put(w, at + 8, target)
    put(w, at + 16, get(w, 400))
    put(w, at + 24, count(s, r, args))
    if emit_names(s, r, w, args, bi) == 0:
        return 0
    put(w, 408, cursor + 1)
    return 1
'''

COMMON = ('word', 'get', 'put', 'resolved', 'kind', 'count', 'child', 'following',
          'list_shape', 'text_size', 'text_byte', 'text_equal', 'text_is', 'field')


def source_program():
    if sha256(Path(shared.__file__).read_bytes()).hexdigest() != SHARED_SHA:
        raise ValueError('immutable source-view authoring changed')
    literals = {'L_' + value: packed(value) for value in LITERALS}
    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node) if node.id in CONSTANTS else node
        def visit_Call(self, node):
            node = self.generic_visit(node)
            args = []
            for argument in node.args:
                if isinstance(argument, ast.Name) and argument.id in literals:
                    args.extend(ast.Constant(value) for value in literals[argument.id])
                else:
                    args.append(argument)
            node.args = args
            return node
    own = Expand().visit(ast.parse(SOURCE)).body
    common = {node.name: node for node in ast.parse(shared.source_program()).body}
    tree = ast.Module(body=own + [common[name] for name in COMMON], type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(index + 1) for index, node in enumerate(nodes)}
    signatures = {node.name: ([argument.annotation.id for argument in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'},
              {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'],
        'entry': 'b0', 'blocks': [{'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}],
             'attrs': {'function': names['edit_facts']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}],
            'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(value) for value in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'agent_edit_facts',
                                  'functions': functions})


if __name__ == '__main__':
    doc = document()
    path = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap/agent_edit_facts.hiaasm'
    path.write_text(render_assembly(doc))
    print(path.name, path.stat().st_size, len(doc['functions']),
          sum(len(fn['blocks']) for fn in doc['functions']), max(len(fn['blocks']) for fn in doc['functions']))

