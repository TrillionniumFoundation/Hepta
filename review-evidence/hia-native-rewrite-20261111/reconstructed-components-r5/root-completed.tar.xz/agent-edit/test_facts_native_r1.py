"""Native issuer -> native exact facts -> existing native slice, with old
algorithms forbidden while forwarding. Development only; complete queries and
native whole-program admission are separate owners still being integrated.
"""
from contextlib import ExitStack
import copy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import random
import struct
import sys
import time
import traceback
from unittest.mock import patch

from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta import hia_agent_slice_native as old_facts
from hepta import hia_edit_query as old_query
from hepta.hia_agent_slice_native import NativeAgentSlice, encode_function
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import ActualFacts, command, lease, vm_call, BAD, MAX
from tests.test_hia_program import b, c, f, i, m, ret, jump, branch, resource_program, joined_loan_program
from tests.test_hia_edit_query import fixture
from tests.test_hia_returned_loans import multiple_shared, swapped_mutable, fallible_return_program

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
OUT = DEV / 'facts-native-r1'
OUT.mkdir(exist_ok=False)
snapshot = DEV / 'facts-source-and-compile-r1'
checked = assemble_program((snapshot / 'source/examples/hia_bootstrap/agent_edit_facts.hiaasm').read_bytes())
issuer_path = DEV.parent / 'native-composite-core-final-recovery-next/dependencies/packet-issuer/tests/test_hia_composite_packet_json.py'
issuer_raw = issuer_path.read_bytes()
assert sha256(issuer_raw).hexdigest() == 'a3b928ae40bd9730b0a32c79336f53c9b769138d30e229b6dd4e5184a4df4746'
spec = importlib.util.spec_from_file_location('agent_edit_actual_packet_issuer_r1', issuer_path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
issuer = module.ActualPacketJson(OUT / 'issuer')
actual = ActualFacts(snapshot / 'agent-edit-facts.manifest.json', OUT / 'facts')
compiler = snapshot / 'source/compiler/B3.image.bin'
slice_image, slice_compile = compile_stage(OUT, 'agent-slice', compiler, (ROOT / 'examples/hia_bootstrap/agent_slice.hiaasm').read_bytes())
slice_native = NativeAgentSlice(slice_image.read_bytes(), sha256(slice_image.read_bytes()).hexdigest())
cases, failures, source_rows = [], [], []
started = time.monotonic_ns()


def forbid(*args, **kwargs):
    raise AssertionError('host selection/facts/slice/decoder entered actual forwarding')


def issued(value, label):
    packet = transport(value)
    result, header, data, index, state = issuer.encode(label, packet)
    assert result == 64 + len(data) and header[5] == len(packet)
    _, nodes = detached_packet_index(packet)
    independent = bytearray((len(packet) + 7) // 8)
    for at in nodes: independent[at >> 3] |= 1 << (at & 7)
    assert bytes(independent) == index
    return lease(packet, index)


def execute(doc, selection, label, *, compare_vm=False, expected_error=None):
    verified = verify_program(doc)
    admitted = verified.as_dict()
    source = issued([admitted, selection], label)
    if expected_error is None:
        fn = next(x for x in admitted['functions'] if x['name'] == selection['function'])
        block = next(x for x in fn['blocks'] if x['id'] == selection['block'])
        oi = next(j for j, op in enumerate(block['ops']) if any(v['name'] == selection['output'] for v in op['out']))
        expected, _, _ = encode_function(fn, block, oi)
        try:
            expected_slice = ('success', slice_native.run(expected))
        except Exception as exc:
            expected_slice = (type(exc).__name__, str(exc))
    with ExitStack() as guard:
        for owner, name in ((old_facts, 'encode_function'), (old_facts, 'native_edit_slice'),
                            (old_query, 'prepare_edit'), (old_query, '_reference_edit_slice'),
                            (old_query, '_cfg_downstream_slice'), (json, 'loads')):
            guard.enter_context(patch.object(owner, name, new=forbid))
        code, event, workspace = actual.run(label, source, request=len(cases) + 1,
            compare=(lambda cmd, raw, work: vm_call(checked, cmd, raw, work)) if compare_vm else None)
        assert code == 384, (label, code, event)
        if expected_error is not None:
            assert event[1] == 2 and event[14] == expected_error, (label, event)
        else:
            assert event[1] == 0 and event[14] == 0, (label, event)
            fact = workspace[event[6]:event[6] + event[7]]
            assert fact == expected, label
            try:
                got_slice = ('success', slice_native.run(fact))
            except Exception as exc:
                got_slice = (type(exc).__name__, str(exc))
            assert got_slice == expected_slice, label
    cases.append({'case': label, 'native_fact_entries': actual.entries,
                  'semantic_error': expected_error, 'full_VM_workspace_compared': compare_vm,
                  'source_sha256': sha256(source).hexdigest(),
                  'fact_and_slice_exact': expected_error is None,
                  'fact_bytes': len(expected) if expected_error is None else None,
                  'fact_sha256': sha256(expected).hexdigest() if expected_error is None else None,
                  'forwarder_host_semantics_disabled': True})
    return source, workspace


try:
    base = fixture()
    select = {'function': 'calculate', 'block': 'entry', 'output': 'y', 'fields': ['op']}
    good_source, good_work = execute(base, select, 'fixture', compare_vm=True)
    for doc_index, doc in enumerate((resource_program(), joined_loan_program(), multiple_shared(), swapped_mutable(), fallible_return_program())):
        for fn in doc['functions']:
            for block in fn['blocks']:
                for op in block['ops']:
                    for out in op['out']:
                        execute(doc, {'function': fn['name'], 'block': block['id'], 'output': out['name'], 'fields': ['attrs', 'op', 'args']},
                                f'resources-{doc_index}-{fn["name"]}-{block["id"]}-{out["name"]}', compare_vm=False)
    rng = random.Random(0x46414354)
    for case in range(48):
        count = rng.randrange(2, 16)
        blocks = []
        for bi in range(count):
            ops = [c('k', 'u32', rng.randrange(100)), i('int.add.wrap', ['x', 'k'], [('v', 'u32')]),
                   i('compare.lt', ['x', 'v'], [('condition', 'bool')])]
            if bi + 1 == count:
                term = ret('v')
            elif case % 4:
                term = jump('b' + str(bi + 1), 'v')
            else:
                dest = rng.randrange(bi + 1, count)
                term = branch('condition', ('b' + str(bi + 1), 'v'), ('b' + str(dest), 'x'))
            blocks.append(b('b' + str(bi), [('x', 'u32')], ops, term))
        rng.shuffle(blocks)
        fn = f('work', [('x', 'u32')], ['u32'], [], blocks)
        fn['entry'] = 'b0'
        chosen = rng.randrange(count)
        execute(m(fn), {'function': 'work', 'block': 'b' + str(chosen), 'output': 'v' if case % 2 else 'condition', 'fields': ['args', 'attrs']},
                'random-' + str(case), compare_vm=case < 2)
    for count in (63, 64, 65, 4096):
        blocks = [b('b' + str(k), [('x', 'u32')], [i('int.add.wrap', ['x', 'x'], [('chosen', 'u32')])] if k == 0 else [],
                    ret('chosen' if k == 0 else 'x') if k + 1 == count else jump('b' + str(k + 1), 'chosen' if k == 0 else 'x')) for k in range(count)]
        execute(m(f('work', [('x', 'u32')], ['u32'], [], blocks)),
                {'function': 'work', 'block': 'b0', 'output': 'chosen', 'fields': ['op']}, 'blocks-' + str(count))
    for count in (255, 256, 257):
        ops = [i('int.add.wrap', ['x' if j == 0 else 'v' + str(j - 1), 'x'], [('v' + str(j), 'u32')]) for j in range(count)]
        execute(m(f('work', [('x', 'u32')], ['u32'], [], [b('entry', [('x', 'u32')], ops, ret('v' + str(count - 1)))])),
                {'function': 'work', 'block': 'entry', 'output': 'v0', 'fields': ['op']}, 'ops-' + str(count))
    for idx, fields in enumerate(([], ['op', 'op'], ['out'], 'op', [1], [None], [True], {}, ['op', 'args', 'attrs', 'op'])):
        selected = dict(select, fields=fields, function='missing')
        execute(base, selected, 'invalid-fields-' + str(idx), expected_error=1, compare_vm=idx == 0)
    for key in ('function', 'block', 'output'):
        for value in (None, True, 1, [], {}):
            execute(base, dict(select, **{key: value}), f'invalid-selector-{key}-{type(value).__name__}', expected_error=2)
    for key, error in (('function', 3), ('block', 4), ('output', 5)):
        execute(base, dict(select, **{key: 'missing'}), 'missing-' + key, expected_error=error)
    execute(base, dict(select, output='x'), 'block-param-is-not-instruction-output', expected_error=5)
    for label, cmd, raw, before in [
        ('empty-command', b'', good_source, bytes(512)),
        ('short-command', command()[:-1], good_source, bytes(512)),
        ('long-command', command() + b'!', good_source, bytes(512)),
        ('continue-before-begin', command(2), good_source, bytes(512)),
        ('zero-lease', command(lease_id=0), good_source, bytes(512)),
        ('zero-request', command(request=0), good_source, bytes(512)),
        ('begin-sequence', command(sequence=1), good_source, bytes(512)),
        ('done-replay', command(), good_source, good_work),
        ('source-short', command(), good_source[:81], bytes(512)),
        ('source-header', command(), b'!' + good_source[1:], bytes(512)),
        ('dirty-initial', command(), good_source, bytes(511) + b'!'),
    ]:
        code, failed = actual.call(label, cmd, raw, before)
        assert code == BAD, (label, code)
        code2, again = actual.call(label + '-poisoned', command(), good_source, failed)
        assert code2 == BAD and failed == again, label
        failures.append({'case': label, 'permanent_BAD': True})
    for size in (0, 1, 255, 383, 511):
        before = bytes(size)
        code, after = actual.call('too-short-' + str(size), command(), good_source, before)
        assert code == BAD and after == before
        failures.append({'case': 'too-short-' + str(size), 'immediate_discard_required': True})
    code, pending = actual.call('grow-pending', command(), good_source, bytes(512))
    event = struct.unpack_from('<16Q', pending, 256)
    assert code == 384 and event[1] == 1
    for label, cmd in (('wrong-grow-request', command(2, request=2, sequence=event[4])),
                       ('stale-grow-sequence', command(2, sequence=event[4] - 1)),
                       ('begin-during-grow', command())):
        code, after = actual.call(label, cmd, good_source, pending)
        assert code == BAD
        failures.append({'case': label, 'rejected': True})
    summary = {'status': 'PASS', 'scope': 'DEVELOPMENT_ACTUAL_ISSUER_FACTS_SLICE_NOT_COMPLETE_QUERY_OR_COLD',
               'cases': cases, 'private_protocol_controls': failures,
               'native_fact_entries': actual.entries, 'native_issuer_entries': issuer.entries,
               'elapsed_ns': time.monotonic_ns() - started,
               'whole_stack_closed': False, 'no_new_public_graph_limit': True}
except BaseException as exc:
    traceback.print_exc()
    summary = {'status': 'FAIL', 'cases': cases, 'private_protocol_controls': failures,
               'error_class': type(exc).__name__, 'error': str(exc),
               'native_fact_entries': actual.entries, 'native_issuer_entries': issuer.entries}
    raise
finally:
    actual.close()
    issuer.close()
    assert issuer_path.read_bytes() == issuer_raw
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('cases', 'private_protocol_controls')}, sort_keys=True), flush=True)
