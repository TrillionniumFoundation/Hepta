"""Freeze, independent VM controls, then real published B3 component compile."""
from hashlib import sha256
import json
from pathlib import Path
import struct
import time
import traceback

from hepta.hia_agent_assembly import assemble_program, render_assembly
from hepta.hia_program import verify_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index
from tools.generate_hia_agent_edit_facts import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import command, lease, vm_call, MAX

ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta-agent-edit-native')
DEV = Path(__file__).resolve().parent
DEST = DEV / 'facts-source-and-compile-r1'
DEST.mkdir(exist_ok=False)
COMPILER = DEV.parent / 'hia-v67-0ef-qualification-local-01/cold.cold/qualification.evidence/B3.image.bin'
FILES = ('tools/generate_hia_agent_edit_facts.py', 'tools/hia_agent_edit_source_views.py',
         'examples/hia_bootstrap/agent_edit_facts.hiaasm', 'docs/HIA_AGENT_EDIT_NATIVE_REWRITE.md')
frozen = {ROOT / rel: (ROOT / rel).read_bytes() for rel in FILES}
frozen[COMPILER] = COMPILER.read_bytes()
assert sha256(frozen[COMPILER]).hexdigest() == '35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
rows = []
for path, raw in frozen.items():
    rel = path.relative_to(ROOT) if path.is_relative_to(ROOT) else Path('compiler/B3.image.bin')
    target = DEST / 'source' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append({'path': str(path), 'copy': str(target), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()})
(DEST / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
summary = {'status': 'INCOMPLETE', 'scope': 'DEVELOPMENT_FACT_COMPONENT_NOT_COLD_OR_WHOLE_QUERY'}
started = time.monotonic_ns()
try:
    source = frozen[ROOT / FILES[2]]
    doc = document()
    assert render_assembly(doc).encode() == source
    assert len(doc['functions']) <= 128
    assert sum(len(fn['blocks']) for fn in doc['functions']) <= 1536
    assert max(len(fn['blocks']) for fn in doc['functions']) <= 256
    assert sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']) <= 8192
    checked = assemble_program(source)
    from tests.test_hia_program import b, c, f, m, ret, jump, branch
    from tests.test_hia_agent_slice_native import independent_cases
    documents = [
        m(f('work', [], ['u32'], [], [b('b0', [], [c('v0', 'u32', 1)], jump('b1', 'v0')),
                                    b('b1', [('v1', 'u32')], [], ret('v1'))])),
        m(f('work', [], ['u32'], [], [b('b0', [], [c('v0', 'bool', True)], branch('v0', ('b1',), ('b2',))),
                                    b('b1', [], [c('v1', 'u32', 1)], ret('v1')),
                                    b('b2', [], [c('v2', 'u32', 2)], ret('v2'))])),
    ]
    controls = []
    for case, (doc, (expected, _)) in enumerate(zip(documents, independent_cases())):
        verified = verify_program(doc)
        packet = transport([verified.as_dict(), {'function': 'work', 'block': 'b0', 'output': 'v0', 'fields': ['op']}])
        _, nodes = detached_packet_index(packet)
        index = bytearray((len(packet) + 7) // 8)
        for at in nodes: index[at >> 3] |= 1 << (at & 7)
        raw = lease(packet, bytes(index))
        before, cmd, count = bytes(512), command(request=case + 1), 0
        while True:
            result, after = vm_call(checked, cmd, raw, before)
            event = struct.unpack_from('<16Q', after, 256)
            prefix = f'vm-{case}-{count}'
            for suffix, data in (('command', cmd), ('source', raw), ('before', before), ('after', after), ('expected', expected)):
                (DEST / (prefix + '.' + suffix + '.bin')).write_bytes(data)
            count += 1
            assert result == 384, (result, event)
            if event[1] == 0:
                actual = after[event[6]:event[6] + event[7]]
                assert actual == expected, (case, actual.hex(), expected.hex())
                break
            assert event[1] == 1 and event[5] > len(after)
            before = after + bytes(event[5] - len(after))
            cmd = command(2, request=case + 1, sequence=event[4])
        controls.append({'case': case, 'entries': count, 'complete_workspace_sha256': sha256(after).hexdigest(),
                         'fact_sha256': sha256(actual).hexdigest(), 'matches_hand_authored_bytes': True})
    (DEST / 'independent-vm.json').write_text(json.dumps(controls, indent=2, sort_keys=True) + '\n')
    image, receipt = compile_stage(DEST, 'agent-edit-facts', COMPILER, source)
    manifest = {'schema': 'hepta.hia.agent-edit-facts-native.v1', 'source_path': str(DEST / 'source' / FILES[2]),
                'source_sha256': sha256(source).hexdigest(), 'image_path': str(image),
                'image_sha256': sha256(image.read_bytes()).hexdigest(), 'compiler_sha256': sha256(frozen[COMPILER]).hexdigest()}
    (DEST / 'agent-edit-facts.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    summary.update(status='PASS', independent_vm_cases=controls, receipt=receipt, manifest=manifest,
                   functions=len(doc['functions']), blocks=sum(len(f['blocks']) for f in doc['functions']))
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    summary['before_after_sources_unchanged'] = all(path.read_bytes() == raw for path, raw in frozen.items())
    summary['elapsed_ns'] = time.monotonic_ns() - started
    (DEST / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert summary['before_after_sources_unchanged']
