from pathlib import Path
from hashlib import sha256, sha1
import io, json, subprocess, tarfile

ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-workflow-qualified')
OUT = ROOT.parent / 'v67-0ef-rog-source-handoff-r2'
OUT.mkdir(mode=0o700, exist_ok=False)
BASE = 'd5da1eb760454ef3df5153c5e80eb046ddb389d9'
HEAD = '0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5'
TREE = '6ef9e1713065436a3b1886fe9edcf0a4a1120773'

def inventory(ref):
    raw = subprocess.check_output(['git', '--no-replace-objects', 'ls-tree', '-r', '-z', ref], cwd=ROOT)
    rows = {}
    for entry in raw.split(b'\0')[:-1]:
        header, name = entry.split(b'\t', 1)
        mode, kind, digest = header.decode().split()
        assert kind == 'blob' and mode in ('100644', '100755')
        assert name.decode() not in rows
        rows[name.decode()] = {'mode': mode, 'git_sha': digest}
    return rows

base, target = inventory(BASE), inventory(HEAD)
assert len(base) == 2790 and len(target) == 2798
original = json.loads((ROOT.parent / 'v67-0ef-rog-source-handoff/base-tree-original.json').read_text())
assert {r['path']: {'mode': r['mode'], 'git_sha': r['git_sha']} for r in original['files']} == base
changed = sorted(n for n in target if target[n] != base.get(n))
removed = sorted(set(base) - set(target))
assert not removed
hashes = json.loads((ROOT.parent / 'hia-v67-0ef-qualification-local-01/source-after.json').read_text())['files']
assert set(hashes) == set(target)
files, source_rows, contents = [], [], {}
for name, row in sorted(target.items()):
    path = ROOT / name
    data = path.read_bytes()
    assert not path.is_symlink()
    assert sha256(data).hexdigest() == hashes[name]
    assert sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_sha']
    assert ('100755' if path.stat().st_mode & 0o100 else '100644') == row['mode']
    record = {'path': name, **row, 'bytes': len(data), 'sha256': hashes[name]}
    source_rows.append(record)
    if name in changed:
        files.append(record)
        contents[name] = data
raw_commit = subprocess.check_output(['git', '--no-replace-objects', 'cat-file', 'commit', HEAD], cwd=ROOT)
assert sha1(b'commit ' + str(len(raw_commit)).encode() + b'\0' + raw_commit).hexdigest() == HEAD
(OUT / 'published-commit.raw').write_bytes(raw_commit)
plan = {'scope': 'EXACT_PUBLISHED_SOURCE_DELTA_AND_FULL_TREE_FOR_NEW_QUALIFICATION_NOT_A_PASS',
        'base': BASE, 'head': HEAD, 'tree': TREE, 'base_files': len(base), 'target_files': len(target),
        'changed_files': files, 'removed_files': removed, 'all_target_files': source_rows,
        'source_closure_files': 644, 'old_qualification_must_not_be_modified': True,
        'previous_local_preparation_failed_before_archive': 'base Git object was not yet available; no ROG action'}
encoded = (json.dumps(plan, indent=2, sort_keys=True) + '\n').encode()
(OUT / 'manifest.json').write_bytes(encoded)
archive = OUT / 'source-delta.tar.xz'
with tarfile.open(archive, 'x:xz') as tf:
    for name, data in contents.items():
        member = tarfile.TarInfo('source/' + name)
        member.size = len(data)
        member.mode = 0o755 if target[name]['mode'] == '100755' else 0o644
        tf.addfile(member, io.BytesIO(data))
    for name, data in [('MANIFEST.json', encoded), ('published-commit.raw', raw_commit)]:
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(data), 0o644
        tf.addfile(member, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as tf:
    assert len(tf.getmembers()) == len(contents) + 2
    for name, data in contents.items():
        member = tf.getmember('source/' + name)
        assert member.mode == (0o755 if target[name]['mode'] == '100755' else 0o644)
        assert tf.extractfile(member).read() == data
    assert tf.extractfile('MANIFEST.json').read() == encoded
    assert tf.extractfile('published-commit.raw').read() == raw_commit
receipt = {'archive': str(archive), 'bytes': archive.stat().st_size,
           'sha256': sha256(archive.read_bytes()).hexdigest(), 'changed_files': len(files),
           'changed_bytes': sum(r['bytes'] for r in files), 'all_target_files': len(target),
           'all_target_source_bytes': sum(r['bytes'] for r in source_rows), 'head': HEAD, 'tree': TREE,
           'base': BASE, 'all_target_bytes_sha_git_mode_verified': True}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(receipt), flush=True)

