"""Remove only complete, Git-verified duplicate r13 transport fragments."""
from hashlib import sha1, sha256
import json
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parent
plan_raw = (ROOT/'publication-plan-v1.json').read_bytes()
plan = {r['path']:r for r in json.loads(plan_raw)}
proof_raw=(ROOT/'parts-remote-readback.json').read_bytes()
proof=json.loads(proof_raw)
assert proof['commit']=='ef6afe945384d7796c460f984ca858f864d81711'
assert proof['verified']['all_original_and_new_blob_sha_mode_size_verified']
remote={r['path']:r for r in proof['rows']}
objects=json.loads((ROOT/'transport-objects.json').read_text())['objects']
rows=[]; originals=[]
for obj in objects:
    if obj['transport']!='lossless-ordered-parts': continue
    source=Path(obj['source']); before=source.stat(); h=sha256(); total=0
    assert stat.S_IMODE(before.st_mode)==obj['original_mode']
    with source.open('rb') as stream:
        for entry in obj['ordered_parts']:
            row=plan[entry['path']]; rp=remote[entry['path']]; path=Path(row['local_path'])
            assert path.parent==ROOT/'parts' and not path.is_symlink()
            info=path.stat(); raw=path.read_bytes(); same=stream.read(len(raw))
            assert raw==same and len(raw)==row['bytes']==rp['size']
            assert sha256(raw).hexdigest()==row['sha256']==entry['sha256']
            assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==rp['sha']==row['git_sha']
            assert rp['mode']==row['mode']=='100644' and stat.S_IMODE(info.st_mode)==0o644
            h.update(raw); total+=len(raw)
            rows.append(dict(**row,inode=info.st_ino,mtime_ns=info.st_mtime_ns,original=str(source)))
        assert stream.read(1)==b''
    assert h.hexdigest()==obj['original_sha256'] and total==obj['original_bytes']
    after=source.stat(); assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
    originals.append(dict(path=str(source),bytes=total,sha256=h.hexdigest(),retained=True))
assert len(rows)==len(remote)==36
receipt=dict(schema='hia-published-duplicate-transport-retirement-v1',commit=proof['commit'],
             plan_sha256=sha256(plan_raw).hexdigest(),remote_readback_sha256=sha256(proof_raw).hexdigest(),
             files=len(rows),bytes=sum(r['bytes'] for r in rows),
             all_remote_git_sha_mode_size_verified=True,all_originals_and_part_bytes_fresh_equal=True,
             originals=originals,parts=rows)
(ROOT/'parts-verified-before-removal.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
for row in rows:
    path=Path(row['local_path']); s=path.stat()
    assert (s.st_ino,s.st_size,s.st_mtime_ns)==(row['inode'],row['bytes'],row['mtime_ns'])
    path.unlink()
(ROOT/'parts-retirement.json').write_text(json.dumps(dict(status='COMPLETE',files=len(rows),
    removed_duplicate_bytes=receipt['bytes'],originals=originals,
    verified_before_removal_sha256=sha256((ROOT/'parts-verified-before-removal.json').read_bytes()).hexdigest()),
    indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status='COMPLETE',files=len(rows),duplicate_bytes=receipt['bytes'],all_original_archives_retained=True)))
