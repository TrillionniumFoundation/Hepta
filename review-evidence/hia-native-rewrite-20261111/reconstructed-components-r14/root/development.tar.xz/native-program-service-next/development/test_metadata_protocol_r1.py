"""Real native private protocol controls, including every retained r2 counterexample."""
import json
import struct
import time
import traceback
from metadata_harness import Actual, ROOT, command, changed, BAD, GROW, M

OUT = ROOT / 'development/metadata-protocol-r1'; OUT.mkdir(exist_ok=False)
actual = Actual(OUT / 'actual', 'metadata-compile-r3')
source = b'hepta.hia.program.v8'; cmd = command(2, 1, len(source))
rows = []; summary = dict(status='INCOMPLETE', scope='PRIVATE_METADATA_PROTOCOL_NOT_PUBLIC_PROGRAM_ADMISSION')
start = time.monotonic_ns()


def refused(label, src, request, before, permanent=True):
    result, event, after = actual.call(src, request, before, label)
    assert result == BAD, (label, result, event)
    if permanent:
        result, _, _ = actual.call(source, cmd, after, label + '-permanent')
        assert result == BAD, (label, result)
    rows.append(dict(case=label, status='PASS', permanent=permanent))


try:
    result, event, original_grow = actual.call(source, cmd, bytes(3072), 'real-grow')
    assert result == GROW and event[:8] == (M(b'HIAPME01'),1,331,1,2,0,0,actual.constants['REQUIRED'])
    state = original_grow + bytes(event[7] - len(original_grow))
    for label, at, value in [('magic',2048,0), ('closed-phase',2056,2), ('lease',2064,999),
                             ('request',2072,999), ('operation',2080,1), ('schema-flag',2088,0),
                             ('source-size',2096,0), ('schema-version',2104,1),
                             ('version-zero',2104,0), ('version-outside',2104,99), ('unknown-phase',2056,7)]:
        refused('state-' + label, source, cmd, changed(state,{at:value}))
    for at in range(0,96,8):
        value = struct.unpack_from('<Q',cmd,at)[0] ^ 1
        refused('resume-command-' + str(at), source, changed(cmd,{at:value}), state)
    refused('resume-source-version', b'hepta.hia.program.v7', cmd, state)
    refused('resume-source-prefix', b'Hepta.hia.program.v8', cmd, state)
    refused('resume-source-length', source + b' ', cmd, state)
    refused('resume-command-truncated', source, cmd[:-1], state)
    refused('resume-command-extended', source, cmd + b'\0', state)
    invalid = [(0,0),(8,0),(8,2),(16,0),(24,0),(32,0),(32,4),(40,2),(48,0)]
    invalid += [(at,1) for at in range(56,96,8)]
    for i,(at,value) in enumerate(invalid):
        refused('initial-command-' + str(i), source, changed(cmd,{at:value}), bytes(3072))
    refused('caps-cannot-have-schema', source, changed(cmd,{32:1}), bytes(3072))
    refused('registry-cannot-have-schema', source, changed(cmd,{32:3}), bytes(3072))
    refused('default-cannot-have-source', source, changed(cmd,{40:0}), bytes(3072))
    for size in (0,1,95,97,200):
        request = cmd[:size] if size < 96 else cmd + bytes(size-96)
        refused('initial-command-size-' + str(size), source, request, bytes(3072))
    for at in (0,1024,2048,2559,2736,3071):
        before = bytearray(3072); before[at] = 1
        refused('dirty-initial-' + str(at), source, cmd, bytes(before))
    for size in (0,1,2047,2303,2431,3071):
        before = bytes(size)
        result, _, after = actual.call(source,cmd,before,'short-workspace-' + str(size))
        assert result == BAD and after == before
        rows.append(dict(case='short-workspace-'+str(size),status='PASS',unchanged=True))
    # Repeated insufficient growth is an ordinary retry on the same lease.
    result, _, after = actual.call(source,cmd,original_grow,'same-size-grow')
    assert result == GROW
    result, _, almost = actual.call(source,cmd,after + bytes(len(state)-1-len(after)),'one-byte-short-grow')
    assert result == GROW
    result, event, completed = actual.call(source,cmd,almost + b'\0','exact-required-size')
    assert result == 128 and event[1] == 0
    rows.append(dict(case='growth-retries-through-exact-size',status='PASS'))
    refused('completed-lease-replay',source,cmd,completed)
    # Workspace tail bytes are outside the requested fixed component extent.
    before = bytes(3072) + b'\xa9'*(actual.constants['REQUIRED']-3072+257)
    result,event,after = actual.call(source,cmd,before,'extra-workspace-tail')
    assert result == 128 and event[1] == 0 and after[-257:] == b'\xa9'*257
    rows.append(dict(case='extra-workspace-tail',status='PASS',untouched_tail=257))
    # Independent overlapping leases share only immutable code.
    source2=b'hepta.hia.program.v1'; cmd2=command(2,1,len(source2),lease=778,request=551)
    result,event,grow2=actual.call(source2,cmd2,bytes(3072),'interleaved-second-grow')
    assert result == GROW
    result,event,out1=actual.call(source,cmd,state,'interleaved-first-finish')
    assert result == 128 and event[2:4] == (331,1)
    result,event,out2=actual.call(source2,cmd2,grow2+bytes(actual.constants['REQUIRED']-len(grow2)),'interleaved-second-finish')
    assert result == 128 and event[2:4] == (778,551) and out1 != out2
    rows.append(dict(case='independent-interleaved-leases',status='PASS'))
    summary.update(status='PASS', cases=len(rows), actual_entries=len(actual.entries), rows=rows,
                   all_five_retained_private_counterexamples_fixed=True)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc(); raise
finally:
    actual.close(); summary['elapsed_ns'] = time.monotonic_ns()-start
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('rows','completed')},sort_keys=True),flush=True)
