"""Retain actual private-state consistency counterexamples before any fix."""
import json
import time
from metadata_harness import Actual, ROOT, command, changed, BAD, GROW

OUT = ROOT / 'development/metadata-state-probe-r1'; OUT.mkdir(exist_ok=False)
actual = Actual(OUT / 'actual'); rows = []; start = time.monotonic_ns()
source = b'hepta.hia.program.v8'; cmd = command(2, 1, len(source))
try:
    result, event, growing = actual.call(source, cmd, bytes(3072), 'obtain-real-grow')
    assert result == GROW and event[1] == 1
    state = growing + bytes(event[7] - len(growing))
    for label, at, value in [('magic',2048,0), ('closed-phase',2056,2), ('lease',2064,999),
                             ('request',2072,999), ('operation',2080,1), ('schema-flag',2088,0),
                             ('source-size',2096,0), ('schema-version',2104,1)]:
        result, event, after = actual.call(source, cmd, changed(state,{at:value}), label)
        rows.append(dict(case=label, expected=BAD, actual=result, event=event,
                         refused=result == BAD, counterexample=result != BAD))
    (OUT / 'result.json').write_text(json.dumps(dict(status='PRIVATE_PROBE_COMPLETED_NOT_SEMANTIC_PASS',
        actual_entries=len(actual.entries), counterexamples=sum(x['counterexample'] for x in rows),
        rows=rows, elapsed_ns=time.monotonic_ns()-start), indent=2, sort_keys=True)+'\n')
    print(json.dumps(dict(entries=len(actual.entries), counterexamples=sum(x['counterexample'] for x in rows))), flush=True)
finally:
    actual.close()
