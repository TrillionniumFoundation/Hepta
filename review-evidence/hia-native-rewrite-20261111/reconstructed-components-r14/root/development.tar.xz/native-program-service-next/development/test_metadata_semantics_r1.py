"""Complete finite metadata domain and independent original diagnostic oracles."""
from contextlib import ExitStack
from hashlib import sha256
import json
from pathlib import Path
import time
import traceback
from unittest.mock import patch
from metadata_harness import Actual, ROOT
from hepta import cli, hia_opcodes, hia_schema

OUT = ROOT / 'development/metadata-semantics-r1'; OUT.mkdir(exist_ok=False)
actual = Actual(OUT / 'actual')
rows = []; start = time.monotonic_ns()
summary = dict(status='INCOMPLETE', scope='FIXED_PUBLIC_METADATA_NOT_PROGRAM_INSPECTION_OR_FULL_CLI')


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def forbidden(*args, **kwargs):
    raise AssertionError('retained metadata semantic fallback executed')


def exercise(label, op, schema=None, initial=3072):
    original = (cli.agent_capabilities, hia_opcodes.opcode_catalog, hia_schema.schema_registry)[op - 1]
    try:
        value = original(schema) if op == 2 else original()
        expected, error = wire(value), None
    except hia_opcodes.OpcodeRejected as exc:
        expected, error = str(exc).encode(), dict(type=type(exc).__name__, code=exc.code, message=str(exc))
    with ExitStack() as stack:
        stack.enter_context(patch.object(cli, 'agent_capabilities', forbidden))
        stack.enter_context(patch.object(hia_opcodes, 'opcode_catalog', forbidden))
        stack.enter_context(patch.object(hia_schema, 'schema_registry', forbidden))
        result = actual.run(op, schema, label=label, initial=initial, request=len(rows) + 1)
    assert result['payload'] == expected, (label, result['payload'][:500], expected[:500])
    assert result['event'][1] == (2 if error else 0)
    if error:
        assert result['event'][7] == 1
    elif op in (2, 3):
        parsed = json.loads(result['payload'])
        catalog = parsed if op == 2 else parsed['instruction_catalog']
        digest = catalog.pop('catalog_sha256')
        expected_digest = sha256(wire(catalog)).hexdigest()
        assert digest == expected_digest
        assert result['after'][1152:1184].hex() == digest
    row = dict(case=label, status='PASS', operation=op, schema=schema,
               expected=actual.save(expected), output=actual.save(result['payload']),
               error=error, event=result['event'], grows=result['grows'])
    rows.append(row)
    print(json.dumps({k:row[k] for k in ('case','status','operation','grows')}, sort_keys=True), flush=True)


try:
    exercise('capabilities-complete', 1)
    exercise('catalog-default-none', 2)
    for version in range(1, 9):
        exercise('catalog-v' + str(version), 2, 'hepta.hia.program.v' + str(version))
    exercise('registry-complete', 3)
    for op in (1, 2, 3):
        exercise('already-large-workspace-' + str(op), op, initial=actual.constants['REQUIRED'])
    unknown = ['', 'None', 'hepta.hia.program.v0', 'hepta.hia.program.v9', 'hepta.hia.program.v01',
               'hepta.hia.program.v08', 'hepta.hia.program.v8\n', ' hepta.hia.program.v8',
               'hepta.hia.program.v8\0', 'hepta.hia.composite.v1', 'hepta.hia.program.v８', '字',
               'hepta.hia.program.v8' * 1000]
    valid = 'hepta.hia.program.v8'
    for at in range(len(valid)):
        unknown.append(valid[:at] + ('X' if valid[at] != 'X' else 'Y') + valid[at + 1:])
    for schema in hia_schema.COMPOSITE_PROFILES:
        if schema not in unknown: unknown.append(schema)
    for i, schema in enumerate(unknown):
        exercise('unknown-schema-' + str(i), 2, schema)
    # An independently allocated output cannot alter subsequent catalog data.
    exercise('catalog-after-all-refusals', 2)
    summary.update(status='PASS', cases=len(rows), actual_entries=len(actual.entries),
                   all_eight_catalog_profiles_complete=True, full_registry_and_capabilities_equal=True,
                   actual_HIA_catalog_digests_equal=True, rows=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc(); raise
finally:
    actual.close()
    summary['elapsed_ns'] = time.monotonic_ns() - start
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('rows','completed')}, sort_keys=True), flush=True)
