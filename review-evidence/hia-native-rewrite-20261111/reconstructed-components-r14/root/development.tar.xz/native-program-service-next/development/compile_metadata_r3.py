"""Fresh actual B3 compile under the retained compiler admission/runtime limits."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
REFERENCE = BASE / 'Hepta-agent-edit-native'
sys.path[:0] = [str(ROOT / 'tools'), str(REFERENCE)]
from generate_hia_metadata import document
from hepta.hia_agent_assembly import assemble_program, render_assembly
from tools.qualify_hia_selfhost import compile_stage

OUT = ROOT / 'development/metadata-compile-r3'
OUT.mkdir(exist_ok=False)
COMPILER = BASE / 'native-composite-core-final-recovery-next/dependencies/f50-B3.image.bin'
SOURCE = ROOT / 'examples/hia_bootstrap/agent_program_metadata.hiaasm'
paths = [Path(__file__), COMPILER, SOURCE, ROOT / 'tools/generate_hia_metadata.py',
         ROOT / 'development/metadata-authoring-r1.py', ROOT / 'development/metadata-source-r1.json',
         ROOT / 'HIA_PROGRAM_SERVICE_DEVELOPMENT.md', BASE / 'native-edit-controller-next/tools/edit_authoring.py']
paths += [REFERENCE / p for p in ('hepta/cli.py', 'hepta/hia_opcodes.py', 'hepta/hia_schema.py',
          'tools/generate_hia_sha256.py', 'tools/generate_hia_selfhost.py',
          'tools/hia_agent_edit_source_views.py', 'tools/qualify_hia_selfhost.py')]
frozen = {p: p.read_bytes() for p in paths}
assert sha256(frozen[COMPILER]).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
rows = []
for i, (path, raw) in enumerate(frozen.items()):
    copy = OUT / 'source' / str(i) / path.name
    copy.parent.mkdir(parents=True, exist_ok=True); copy.write_bytes(raw)
    rows.append(dict(path=str(path), copy=str(copy), bytes=len(raw), sha256=sha256(raw).hexdigest()))
(OUT / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
summary = dict(status='INCOMPLETE', scope='SHARED_METADATA_DEVELOPMENT_NOT_FULL_PROGRAM_SERVICE_OR_COLD',
               compile_cpu_seconds=10, compile_wall_seconds=20, compile_address_space_bytes=256 << 20)
start = time.monotonic_ns()
try:
    value, expanded, metadata = document()
    raw = render_assembly(value).encode()
    assert raw == frozen[SOURCE] and expanded.encode() == frozen[ROOT / 'development/metadata-authoring-r1.py']
    assemble_program(raw)
    counts = metadata['profile']
    assert counts['functions'] <= 128 and counts['blocks'] <= 1536 and counts['max_blocks'] <= 256
    assert counts['instructions'] <= 8192 and counts['max_block_params'] <= 16
    image, receipt = compile_stage(OUT, 'program-metadata', COMPILER, raw)
    source_copy = OUT / 'program-metadata.hiaasm'; source_copy.write_bytes(raw)
    manifest = dict(schema='hepta.hia.program-metadata-development.v1', scope='DEVELOPMENT_NOT_COLD',
                    source_path=str(source_copy), expected_source_path=str(SOURCE),
                    source_bytes=len(raw), source_sha256=sha256(raw).hexdigest(),
                    image_path=str(image), image_bytes=image.stat().st_size,
                    image_sha256=sha256(image.read_bytes()).hexdigest(),
                    compiler_sha256=sha256(frozen[COMPILER]).hexdigest(),
                    receipt_path=str(OUT / 'program-metadata.receipt.json'))
    (OUT / 'program-metadata.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    summary.update(status='PASS', counts=counts, component=manifest, metadata=metadata)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    summary['source_before_after_equal'] = all(p.read_bytes() == raw for p, raw in frozen.items())
    summary['wall_ns'] = time.monotonic_ns() - start
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in summary.items() if k != 'metadata'}, sort_keys=True), flush=True)
    assert summary['source_before_after_equal']
