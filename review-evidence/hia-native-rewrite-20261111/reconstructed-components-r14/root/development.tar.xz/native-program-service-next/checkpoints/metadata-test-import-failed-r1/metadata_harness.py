"""Mechanical bounded native invocation and lossless development evidence only."""
from hashlib import sha256
import ctypes
import json
import os
from pathlib import Path
import resource
import signal
import struct
import sys
import time
import zlib

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
sys.path[:0] = [str(BASE / 'Hepta-agent-edit-native'), str(BASE / 'native-composite-driver-reconstructed/development')]
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from mechanical_executor import Buffer

M = lambda x: int.from_bytes(x, 'little')
BAD, GROW = 0xfffffffd, 0xfffffffe
LIBC = ctypes.CDLL(None, use_errno=True)


def command(op=2, explicit=0, size=0, lease=331, request=1):
    return struct.pack('<12Q', M(b'HIAPMC01'), 1, lease, request, op, explicit, size, 0, 0, 0, 0, 0)


def changed(raw, updates):
    out = bytearray(raw)
    for at, value in updates.items():
        struct.pack_into('<Q', out, at, value)
    return bytes(out)


class Actual:
    def __init__(self, out, compile_name='metadata-compile-r2'):
        self.out = Path(out); self.out.mkdir(exist_ok=False, parents=True)
        self.cas = self.out / 'cas'; self.cas.mkdir()
        self.pins, self.entries = {}, []
        def read(path):
            path = Path(path).resolve(); raw = path.read_bytes()
            assert path not in self.pins or self.pins[path] == raw
            self.pins[path] = raw
            return raw
        manifest = json.loads(read(ROOT / 'development' / compile_name / 'program-metadata.manifest.json'))
        source = read(manifest['source_path'])
        assert sha256(source).hexdigest() == manifest['source_sha256']
        assert source == read(manifest['expected_source_path'])
        image = read(manifest['image_path'])
        assert sha256(image).hexdigest() == manifest['image_sha256']
        receipt = json.loads(read(manifest['receipt_path']))
        assert receipt['input_sha256'] == manifest['source_sha256']
        assert receipt['produced_sha256'] == manifest['image_sha256']
        assert receipt['image_sha256'] == manifest['compiler_sha256']
        for path in (ROOT / 'tools/generate_hia_metadata.py', ROOT / 'development/metadata-source-r1.json',
                     Path(__file__), BASE / 'Hepta-agent-edit-native/hepta/cli.py',
                     BASE / 'Hepta-agent-edit-native/hepta/hia_opcodes.py',
                     BASE / 'Hepta-agent-edit-native/hepta/hia_schema.py'):
            read(path)
        self.constants = json.loads(self.pins[(ROOT / 'development/metadata-source-r1.json').resolve()])['constants']
        self.image = NativeHiaJsonImage(image, manifest['image_sha256'])
        self.manifest = manifest
        self.log = (self.out / 'entries.jsonl').open('w')
        rows = []
        for i, (p, raw) in enumerate(self.pins.items()):
            copy = self.out / 'source' / str(i) / p.name
            copy.parent.mkdir(parents=True, exist_ok=True); copy.write_bytes(raw)
            rows.append(dict(path=str(p), copy=str(copy), bytes=len(raw), sha256=sha256(raw).hexdigest()))
        (self.out / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')

    def save(self, raw):
        digest = sha256(raw).hexdigest(); path = self.cas / (digest + '.zlib')
        if path.exists():
            assert zlib.decompress(path.read_bytes()) == raw
        else:
            packed = zlib.compress(raw, 9); path.write_bytes(packed)
            assert zlib.decompress(path.read_bytes()) == raw
        return dict(path=str(path), bytes=len(raw), sha256=digest)

    def call(self, source, request, before, label):
        a, b, c = Buffer(len(source), source, True), Buffer(len(request), request, True), Buffer(len(before), before)
        receiver, sender = os.pipe(); started = time.monotonic_ns()
        pid = os.fork()
        if pid == 0:
            os.close(receiver)
            resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
            resource.setrlimit(resource.RLIMIT_AS, (256 << 20, 256 << 20))
            resource.setrlimit(resource.RLIMIT_STACK, (8 << 20, 8 << 20))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            assert LIBC.prctl(4, 0, 0, 0, 0) == 0
            signal.alarm(20)
            result = int(self.image._entry(a.address, a.size, b.address, b.size, c.address, c.size))
            os.write(sender, struct.pack('<Q', result)); os._exit(0)
        os.close(sender)
        returned = b''
        while len(returned) < 8:
            part = os.read(receiver, 8 - len(returned))
            if not part: break
            returned += part
        os.close(receiver)
        _, status, usage = os.wait4(pid, 0)
        try:
            for buf in (a, b, c): buf.check()
            assert a.read(0, a.size) == source and b.read(0, b.size) == request
            after = c.read(0, c.size)
            result = struct.unpack('<Q', returned)[0] if len(returned) == 8 else None
            event = struct.unpack_from('<16Q', after, 2304) if len(after) >= 2432 else None
            row = dict(label=label, pid=pid, parent_pid=os.getpid(), return_u64=result,
                       wait_status=status, exit_code=os.waitstatus_to_exitcode(status),
                       cpu_s=usage.ru_utime + usage.ru_stime, wall_ns=time.monotonic_ns() - started,
                       source=self.save(source), command=self.save(request), before=self.save(before),
                       after=self.save(after), event=event, source_command_canaries_unchanged=True)
            self.entries.append(row); self.log.write(json.dumps(row, sort_keys=True) + '\n'); self.log.flush()
            assert row['exit_code'] == 0 and result is not None, row
            return result, event, after
        finally:
            a.close(); b.close(); c.close()

    def run(self, op, schema=None, *, label, initial=3072, request=1):
        source = b'' if schema is None else schema.encode('utf-8')
        cmd = command(op, int(schema is not None), len(source), request=request)
        before = bytes(initial); grows = 0
        for _ in range(3):
            result, event, after = self.call(source, cmd, before, label)
            assert event[0] == M(b'HIAPME01') and event[2:5] == (331, request, op) and not any(event[8:])
            if event[1] == 1:
                assert result == GROW and event[7] > len(after)
                before = after + bytes(event[7] - len(after)); grows += 1
                continue
            assert result == 128 and event[1] in (0, 2), (result, event)
            at, size = event[5:7]
            assert at <= len(after) and size <= len(after) - at
            return dict(result=result, event=event, payload=after[at:at + size], after=after,
                        source=source, command=cmd, grows=grows)
        raise AssertionError('finite metadata owner did not finish')

    def close(self):
        self.log.close(); self.image._entry = None; self.image._mapping.close()
        assert all(p.read_bytes() == raw for p, raw in self.pins.items())
        (self.out / 'custody.json').write_text(json.dumps(dict(source_before_after_equal=True,
            actual_entries=len(self.entries), distinct_child_pids=len({x['pid'] for x in self.entries}),
            cpu_seconds=10, wall_seconds=20, address_bytes=256 << 20, stack_bytes=8 << 20,
            cores_disabled=True, source_and_command_readonly=True,
            pins={str(p):dict(bytes=len(raw),sha256=sha256(raw).hexdigest()) for p,raw in self.pins.items()}),
            indent=2, sort_keys=True) + '\n')
