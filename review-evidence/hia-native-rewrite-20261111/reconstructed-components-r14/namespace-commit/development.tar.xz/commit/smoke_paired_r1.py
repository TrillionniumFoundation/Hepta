"""Actual-file development smoke; mechanical Python syscalls, HIA decisions.

The pending checksum and active-lock lease are explicitly controlled test
predecessors. The actual native record codec validates the complete spool.
This is not the final fixed native syscall executor or ordinary namespace.
"""
from pathlib import Path
from hashlib import sha256
import ctypes
import fcntl
import gzip
import json
import os
import stat
import struct
import sys
import tempfile
import time
import traceback

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEV = BASE/'namespace-reconstruction/commit-r1'
OUT = DEV/'smoke-paired-r1'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(SOURCE))
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from hepta.hia_json_preflight_native import NativeHiaJsonImage

MAGIC = int.from_bytes(b'HIANCM01', 'little')
HEAD = int.from_bytes(b'HIANHD01', 'little')
LOG = int.from_bytes(b'HIANLG01', 'little')
RECORD = int.from_bytes(b'HIANLR01', 'little')
MASK = (1 << 64)-1
digest = lambda raw: sha256(raw).hexdigest()
pins = {}
for row in json.loads((DEV/'authoring-r1/source.json').read_bytes())['files']:
    p = SOURCE/row['path']; raw = p.read_bytes()
    assert len(raw) == row['bytes'] and digest(raw) == row['sha256'] and (p.stat().st_mode & 0o777) == row['mode']
    pins[str(p)] = digest(raw)
for p in (Path(__file__).resolve(), SOURCE/'hepta/hia_program_runtime.py', SOURCE/'hepta/hia_agent_assembly.py',
          SOURCE/'hepta/hia_json_preflight_native.py', SOURCE/'tools/generate_hia_sha256.py'):
    pins[str(p)] = digest(p.read_bytes())
image_path = BASE/'namespace-reconstruction/log-r1/native-r3/compile/agent-namespace-log.image.bin'
image_bytes = image_path.read_bytes()
assert digest(image_bytes) == '87d2172522f745679b4f3a1197e2b00752445ac9621be15a6438e238e799d174'
pins[str(image_path)] = digest(image_bytes)
codec = NativeHiaJsonImage(image_bytes, digest(image_bytes))
COMPILE = DEV/'native-r1/compile'
manifest = json.loads((COMPILE/'manifest.json').read_bytes())
compiled = json.loads((COMPILE/'summary.json').read_bytes())
assert compiled['status'] == 'PASS' and compiled['source_and_compiler_unchanged']
commit_bytes = (COMPILE/manifest['image_path']).read_bytes()
assert digest(commit_bytes) == manifest['image_sha256'] == 'b6de8ae9f169e71db5012a53fcb8a62253d94a4118b911fa1d44571d807f6099'
assert manifest['source_sha256'] == pins[str(SOURCE/'examples/hia_bootstrap/agent_namespace_commit.hiaasm')]
commit_image = NativeHiaJsonImage(commit_bytes, manifest['image_sha256'])
for path in (COMPILE/manifest['image_path'],COMPILE/'manifest.json',COMPILE/'summary.json'):
    pins[str(path)] = digest(path.read_bytes())
(OUT/'source-before.json').write_text(json.dumps(pins, sort_keys=True, indent=2)+'\n')
program = assemble_program((SOURCE/'examples/hia_bootstrap/agent_namespace_commit.hiaasm').read_bytes())
entry = program.as_dict()['functions'][0]
ledger = gzip.open(OUT/'invocations.jsonl.gz', 'wt', encoding='utf-8')
counts = {'commit_vm_entries': 0, 'commit_native_entries': 0, 'full_native_vm_bytes_equal': 0, 'native_log_entries': 0, 'syscalls': 0}
native_contexts = {}
COMMIT_CANARY = bytes(range(160,192))
phases = []
operations = []


def log(row):
    ledger.write(json.dumps(row, sort_keys=True, separators=(',', ':'))+'\n')
    ledger.flush()


def invoke(raw, work):
    before = bytes(work)
    key = id(work)
    if key not in native_contexts:
        native_contexts[key] = (work,ctypes.create_string_buffer(before+COMMIT_CANARY,len(before)+len(COMMIT_CANARY)))
    held, native_work = native_contexts[key]
    assert held is work and bytes(native_work[:len(before)]) == before
    owners = [_Owner(-1, bytearray(raw)), _Owner(-2, bytearray(4352)), _Owner(-3, work)]
    machine = _Machine(program, 20000000, 128 << 20, None, 96)
    code = machine.invoke(entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
    output = bytes(owners[1].data)
    counts['commit_vm_entries'] += 1
    log({'kind': 'commit_vm', 'entry': counts['commit_vm_entries'], 'input_hex': raw.hex(),
         'workspace_before_hex': before.hex(), 'workspace_after_hex': bytes(work).hex(),
         'output_hex': output.hex(), 'return': code})
    assert bytes(owners[0].data) == raw
    source = ctypes.create_string_buffer(raw+COMMIT_CANARY,len(raw)+len(COMMIT_CANARY))
    target = ctypes.create_string_buffer(bytes(4352)+COMMIT_CANARY,4352+len(COMMIT_CANARY))
    actual_code = commit_image._entry(source,len(raw),target,4352,native_work,len(before))
    actual_output = bytes(target);actual_work = bytes(native_work);actual_source = bytes(source)
    counts['commit_native_entries'] += 1
    log({'kind':'actual_native_commit','entry':counts['commit_native_entries'],
         'image_sha256':manifest['image_sha256'],'input_hex':raw.hex(),
         'pre_workspace_hex':before.hex(),'expected_return':code,'actual_return':actual_code,
         'expected_output_hex':(output+COMMIT_CANARY).hex(),'actual_output_hex':actual_output.hex(),
         'expected_workspace_hex':(bytes(work)+COMMIT_CANARY).hex(),'actual_workspace_hex':actual_work.hex(),
         'actual_input_and_guard_hex':actual_source.hex()})
    assert actual_code == code and actual_output == output+COMMIT_CANARY and actual_work == bytes(work)+COMMIT_CANARY
    assert actual_source == raw+COMMIT_CANARY
    counts['full_native_vm_bytes_equal'] += 1
    header = struct.unpack_from('<32Q', output)
    assert header[0:2] == (MAGIC, code) and header[28:] == (1, 0, 0, 0)
    assert output[256+header[14]:] == bytes(len(output)-256-header[14])
    return code, header, output[256:256+header[14]]


def request(command, call=1, args=(), payload=b''):
    words = [MAGIC, command, 11, 22, call, 0, 0, 0]+list(args)
    assert len(words) <= 32
    return struct.pack('<32Q', *(words+[0]*(32-len(words))))+payload


def ack(h, values=(), payload=b'', status=0):
    words = [MAGIC, 7, *h[2:4], h[4], h[5], h[7], status]+list(values)
    assert len(words) <= 15
    words += [0]*(16-len(words))
    words += [len(payload)]+[0]*15
    return struct.pack('<32Q', *(word&MASK for word in words))+payload


def validate_spool(raw):
    work = ctypes.create_string_buffer(1024)
    canary = bytes(range(32))
    messages = [struct.pack('<16Q', LOG, 4, 71, 72, 1, 0, 0, 91, *([0]*8)),
                struct.pack('<16Q', LOG, 5, 71, 72, 1, 1, 81, 91, 0, 0, 0, 0, 0, len(raw), 0, 0)+raw,
                struct.pack('<16Q', LOG, 6, 71, 72, 1, 2, 0, 91, 0, 0, 0, 0, len(raw), 0, 0, 0)]
    for message, expected in zip(messages, (2, 2, 0)):
        source = ctypes.create_string_buffer(message+canary, len(message)+len(canary))
        output = ctypes.create_string_buffer(256)
        before = bytes(work)
        code = codec._entry(source, len(message), output, 256, work, 1024)
        counts['native_log_entries'] += 1
        log({'kind': 'actual_native_record_codec', 'image_sha256': digest(image_bytes), 'input_hex': message.hex(),
             'workspace_before_hex': before.hex(), 'workspace_after_hex': bytes(work).hex(),
             'output_hex': bytes(output).hex(), 'return': code, 'expected_return': expected})
        assert code == expected and bytes(source) == message+canary


class MechanicalFiles:
    def __init__(self, root):
        self.root = root
        self.handles = {601: os.open(root/'DATA', os.O_RDWR | os.O_CLOEXEC),
                        602: os.open(root/'PENDING', os.O_RDONLY | os.O_CLOEXEC),
                        603: os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC),
                        604: os.open(root/'HEADS', os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)}
        self.next_lease = 1000

    def step(self, h, body):
        opcode = h[7]; a, b, c, d = h[8:12]
        phases.append(h[6]); operations.append(opcode)
        row = {'kind': 'actual_syscall', 'phase': h[6], 'action': h[5], 'opcode': opcode,
               'args': [a, b, c, d], 'input_payload_hex': body.hex()}
        try:
            payload = b''
            if opcode == 1:
                fd = os.open(body, b, c, dir_fd=self.handles[a])
                self.next_lease += 1
                self.handles[self.next_lease] = fd
                values = [self.next_lease]
            elif opcode == 2:
                actual_count = min(c, 17)
                payload = os.pread(self.handles[a], actual_count, b)
                values = [a, b, len(payload)]
                row['explicit_short_io_control_actual_syscall_count'] = actual_count
            elif opcode == 3:
                assert c == len(body)
                actual_count = min(c, 13)
                written = os.pwrite(self.handles[a], body[:actual_count], b)
                values = [a, b, written]
                row['explicit_short_io_control_actual_syscall_count'] = actual_count
            elif opcode == 4:
                s = os.fstat(self.handles[a])
                values = [a, s.st_mode, s.st_size, s.st_dev, s.st_ino, s.st_mtime_ns, s.st_ctime_ns]
            elif opcode == 5:
                os.ftruncate(self.handles[a], b)
                values = [a, b]
            elif opcode == 6:
                os.fsync(self.handles[a])
                values = [a]
            elif opcode == 7:
                assert len(body) == c+d
                os.rename(body[:c], body[c:], src_dir_fd=self.handles[a], dst_dir_fd=self.handles[b])
                values = [a, b]
            elif opcode == 8:
                os.close(self.handles.pop(a))
                values = [a]
            elif opcode == 9:
                os.unlink(body, dir_fd=self.handles[a])
                values = [a]
            else:
                raise AssertionError(('unissued opcode', opcode))
            raw = ack(h, values, payload)
            row.update(status=0, values=values, output_payload_hex=payload.hex())
        except OSError as error:
            raw = ack(h, [error.errno], status=1)
            row.update(status=1, errno=error.errno, message=str(error))
        counts['syscalls'] += 1
        log(row)
        return raw

    def close(self):
        for fd in self.handles.values():
            os.close(fd)
        self.handles.clear()


def complete(files, raw, work):
    code, h, body = invoke(raw, work)
    while code == 1:
        code, h, body = invoke(files.step(h, body), work)
    assert code == 0, (code, h)
    return h, body


started = time.monotonic_ns()
result = {'scope': 'DEVELOPMENT single actual-file commit using exact actual B3 image and same-entry Core VM coordinator, real native log codec and Python mechanical syscalls. Pending page-chain/active-lock lease are controlled private test predecessors; no fixed executor/multiwriter/migration/ordinary-store qualification.'}
try:
    namespace = bytes(range(1, 33))
    code, h, body = invoke(request(9, args=(51,), payload=namespace), bytearray(24576))
    expected_head = struct.pack('<QQ', HEAD, 1)+namespace+bytes(80)
    assert code == 0 and body == expected_head+sha256(expected_head).digest()
    cells = [(3, b'slot'), (1, struct.pack('<q', 7)), (4, b'\xff\x00artifact')]
    payload = struct.pack('<Q', 3)+b''.join(struct.pack('<QQ', kind, len(data))+data for kind, data in cells)
    spool = struct.pack('<8Q', RECORD, 1, 1, 8, (-7)&MASK, len(payload), 80+len(payload), 0)+payload+struct.pack('<QQ', 80+len(payload), RECORD)
    validate_spool(spool)
    chain = bytes(32)
    for at in range(0, len(spool), 4096):
        page = spool[at:at+4096]
        chain = sha256(chain+struct.pack('<Q', len(page))+sha256(page).digest()).digest()
    with tempfile.TemporaryDirectory(prefix='hia-namespace-commit-r1-') as directory:
        root = Path(directory); (root/'HEADS').mkdir(); (root/'DATA').write_bytes(b'uncommitted tail')
        (root/'PENDING').write_bytes(spool); (root/'CURRENT').write_bytes(sha256(expected_head).digest())
        (root/'HEADS'/digest(expected_head)).write_bytes(expected_head)
        lock = os.open(root/'LOCK', os.O_RDWR | os.O_CREAT | os.O_CLOEXEC, 0o600)
        fcntl.flock(lock, fcntl.LOCK_EX)
        log({'kind': 'actual_private_lock_predecessor', 'fd': lock, 'stat_inode': os.fstat(lock).st_ino,
             'scope': 'actual flock held; lease supplied by development fixture, not claimed as fixed native issuer'})
        files = MechanicalFiles(root)
        try:
            work = bytearray(24576)
            initial = request(1, args=(51, 52, 601, 602, 603, 604, 53, 54, 55, len(spool), 56, 57), payload=expected_head+chain)
            h, body = complete(files, initial, work)
            assert body == sha256(expected_head).digest()
            stages = []
            for call, cmd in enumerate((2, 3, 4, 5, 6), 2):
                h, body = complete(files, request(cmd, call, (55, 51, 52, 53, 54)), work)
                stages.append(h[15])
            assert stages == [2, 3, 4, 5, 6]
            assert set(files.handles) == {601, 602, 603, 604}
            new = struct.pack('<QQ', HEAD, 1)+namespace+sha256(expected_head).digest()+struct.pack('<QQ', 0, len(spool))+chain
            assert (root/'DATA').read_bytes() == spool
            assert (root/'CURRENT').read_bytes() == sha256(new).digest()
            assert (root/'HEADS'/digest(new)).read_bytes() == new
            assert (root/'HEADS'/digest(expected_head)).read_bytes() == expected_head
            assert not list(root.glob('.current-*'))
            result.update(status='PASS', completed_stages=stages, native_hashes_match_hashlib=True,
                          raw_spool_hex=spool.hex(), base_head_hex=expected_head.hex(), new_head_hex=new.hex(),
                          native_phase_order=phases, mechanical_opcodes=operations,
                          only_borrowed_descriptors_remain=True, actual_original_head_preserved=True)
        finally:
            files.close(); fcntl.flock(lock, fcntl.LOCK_UN); os.close(lock)
except BaseException as error:
    traceback.print_exc()
    result.update(status='FAIL', exception_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
finally:
    ledger.close()
    after = {p: digest(Path(p).read_bytes()) for p in pins}
    (OUT/'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2)+'\n')
    result.update(counts=counts, source_unchanged=pins == after, wall_elapsed_ns=time.monotonic_ns()-started,
                  ledger_sha256=digest((OUT/'invocations.jsonl.gz').read_bytes()))
    if pins != after or counts['commit_vm_entries'] != counts['commit_native_entries'] or counts['commit_native_entries'] != counts['full_native_vm_bytes_equal'] or counts['commit_native_entries'] != 67:
        result['status'] = 'FAIL'
    raw = (json.dumps(result, sort_keys=True, indent=2)+'\n').encode(); (OUT/'result.json').write_bytes(raw)
    print(json.dumps({'status': result['status'], 'counts': counts, 'result_sha256': digest(raw)}, sort_keys=True), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
