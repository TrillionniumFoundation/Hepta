"""Fresh-r2 initialization, actual-image private fault regression; no syscalls."""
from pathlib import Path
from hashlib import sha256
import ctypes
import gzip
import json
import struct
import sys

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEV = BASE/'namespace-reconstruction/commit-r1'
OUT = DEV/'private-state-probe-r2'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(SOURCE))
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from hepta.hia_json_preflight_native import NativeHiaJsonImage

digest = lambda raw: sha256(raw).hexdigest()
pins = {str(SOURCE/row['path']):row['sha256'] for row in json.loads((DEV/'authoring-r2/source.json').read_bytes())['files']}
manifest = json.loads((DEV/'native-r2/compile/manifest.json').read_bytes())
image_path = DEV/'native-r2/compile'/manifest['image_path']
image_bytes = image_path.read_bytes()
assert digest(image_bytes) == manifest['image_sha256'] == 'e5dbc5d110ec00a36ca027ff822275ed0e392ad1bf767b0ed5a7c02a5df001dd'
for p in [image_path, DEV/'native-r2/compile/manifest.json', Path(__file__).resolve(),
          SOURCE/'hepta/hia_program_runtime.py', SOURCE/'hepta/hia_json_preflight_native.py',
          DEV/'smoke-paired-r2/invocations.jsonl.gz', DEV/'smoke-paired-r2/result.json']:
    pins[str(p)] = digest(p.read_bytes())
assert all(digest(Path(p).read_bytes()) == h for p,h in pins.items())
smoke = json.loads((DEV/'smoke-paired-r2/result.json').read_bytes())
assert smoke['status'] == 'PASS' and smoke['counts']['full_native_vm_bytes_equal'] == 67
program = assemble_program((SOURCE/'examples/hia_bootstrap/agent_namespace_commit.hiaasm').read_bytes())
entry = program.as_dict()['functions'][0]
image = NativeHiaJsonImage(image_bytes, manifest['image_sha256'])
rows = [json.loads(line) for line in gzip.open(DEV/'smoke-paired-r2/invocations.jsonl.gz','rt')]
initialized = next(row for row in rows if row['kind'] == 'commit_vm' and row['entry'] == 2)
prepared = next(row for row in rows if row['kind'] == 'commit_vm' and row['entry'] == 3)
raw = bytes.fromhex(prepared['input_hex'])
original = bytes.fromhex(initialized['workspace_after_hex'])
canary = bytes(range(160,192))
BAD = 0xfffffffd
records = []
def step(name, raw, before, expected):
    work=bytearray(before)
    owners=[_Owner(-1,bytearray(raw)),_Owner(-2,bytearray(4352)),_Owner(-3,work)]
    vm=_Machine(program,20000000,128<<20,None,96)
    code=vm.invoke(entry,[_View(owners[0],False),_View(owners[1],True),_View(owners[2],True)])[0]
    out=bytes(owners[1].data)
    source=ctypes.create_string_buffer(raw+canary,len(raw)+32)
    target=ctypes.create_string_buffer(bytes(4352)+canary,4352+32)
    state=ctypes.create_string_buffer(before+canary,len(before)+32)
    actual=image._entry(source,len(raw),target,4352,state,len(before))
    row={'name':name,'input_hex':raw.hex(),'workspace_before_hex':before.hex(),
         'vm_return':code,'expected_return':expected,'actual_return':actual,
         'vm_output_hex':(out+canary).hex(),'actual_output_hex':bytes(target).hex(),
         'vm_workspace_hex':(bytes(work)+canary).hex(),'actual_workspace_hex':bytes(state).hex(),
         'actual_input_and_guard_hex':bytes(source).hex()}
    records.append(row)
    assert actual == code == expected
    assert bytes(target) == out+canary and bytes(state) == bytes(work)+canary
    assert bytes(source) == raw+canary and bytes(owners[0].data) == raw
    return bytes(work),out
# Reinitialize through the actual r2 entry, rather than copying an r1 layout.
fresh,out=step('fresh_actual_r2_initialization',bytes.fromhex(initialized['input_hex']),bytes(24576),0)
assert fresh == original
step('baseline_prepare',raw,fresh,1)
mutations=[('unpublished_state_claims_published',232,1),
           ('admitted_data_descriptor_replaced_with_zero',88,0),
           ('initial_spool_cursor_advanced_without_read',168,1)]
for name,offset,value in mutations:
    changed=bytearray(fresh);struct.pack_into('<Q',changed,offset,value)
    poisoned,out=step(name,raw,bytes(changed),BAD)
    assert struct.unpack_from('<Q',poisoned,8)[0] == 3
    for suffix,again in [('repeat_original',raw),('attempt_reinit',bytes.fromhex(initialized['input_hex'])),('empty_input',b'')]:
        after,repeated=step(name+'_'+suffix,again,poisoned,BAD)
        assert after == poisoned and repeated == out
with gzip.open(OUT/'invocations.jsonl.gz','wt') as stream:
    for row in records: stream.write(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n')
after={p:digest(Path(p).read_bytes()) for p in pins}
assert pins == after
result={'scope':'ACTUAL R2 PRIVATE WORKSPACE CONSISTENCY REGRESSION; same-entry native/VM; full externally supplied arbitrary-state authentication and ordinary namespace qualification remain out of scope',
        'status':'PASS','image_sha256':manifest['image_sha256'],'actual_native_entries':len(records),
        'full_native_vm_bytes_equal':len(records),'original_r1_mutants':mutations,'persistent_refusal_reentries':9,
        'fresh_actual_initialization':True,'filesystem_operations_executed':0,'before':pins,'after':after,'source_unchanged':True,
        'ledger_sha256':digest((OUT/'invocations.jsonl.gz').read_bytes())}
payload=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode();(OUT/'result.json').write_bytes(payload)
print(json.dumps({'status':'PASS','actual_native_entries':len(records),'result_sha256':digest(payload)},sort_keys=True))
