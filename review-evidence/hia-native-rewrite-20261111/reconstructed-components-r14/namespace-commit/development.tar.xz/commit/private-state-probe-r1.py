from pathlib import Path
from hashlib import sha256
import ctypes
import gzip
import json
import struct
import sys

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEV = BASE/'namespace-reconstruction/commit-r1'
OUT = DEV/'private-state-probe-r1'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(SOURCE))
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from hepta.hia_json_preflight_native import NativeHiaJsonImage

digest = lambda raw: sha256(raw).hexdigest()
pins = {str(SOURCE/row['path']): row['sha256'] for row in json.loads((DEV/'authoring-r1/source.json').read_bytes())['files']}
assert all(digest(Path(p).read_bytes()) == h for p, h in pins.items())
manifest = json.loads((DEV/'native-r1/compile/manifest.json').read_bytes())
image_path = DEV/'native-r1/compile'/manifest['image_path']
image_bytes = image_path.read_bytes()
assert digest(image_bytes) == manifest['image_sha256']
pins[str(image_path)] = digest(image_bytes)
pins[str(Path(__file__).resolve())] = digest(Path(__file__).read_bytes())
program = assemble_program((SOURCE/'examples/hia_bootstrap/agent_namespace_commit.hiaasm').read_bytes())
entry = program.as_dict()['functions'][0]
image = NativeHiaJsonImage(image_bytes, manifest['image_sha256'])
rows = [json.loads(line) for line in gzip.open(DEV/'smoke-paired-r1/invocations.jsonl.gz', 'rt')]
initialized = next(row for row in rows if row['kind'] == 'commit_vm' and row['entry'] == 2)
request_row = next(row for row in rows if row['kind'] == 'commit_vm' and row['entry'] == 3)
raw = bytes.fromhex(request_row['input_hex'])
original = bytes.fromhex(initialized['workspace_after_hex'])
assert struct.unpack_from('<Q', original, 64)[0] == 1
canary = bytes(range(160, 192))
records = []
for name, change in [('baseline', None), ('unpublished_state_claims_published', (232, 1)),
                     ('admitted_data_descriptor_replaced_with_zero', (88, 0)),
                     ('initial_spool_cursor_advanced_without_read', (168, 1))]:
    work = bytearray(original)
    if change:
        struct.pack_into('<Q', work, *change)
    before = bytes(work)
    owners = [_Owner(-1, bytearray(raw)), _Owner(-2, bytearray(4352)), _Owner(-3, work)]
    machine = _Machine(program, 20000000, 128 << 20, None, 96)
    expected_code = machine.invoke(entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
    expected_out = bytes(owners[1].data)
    source = ctypes.create_string_buffer(raw+canary, len(raw)+len(canary))
    output = ctypes.create_string_buffer(bytes(4352)+canary, 4352+len(canary))
    state = ctypes.create_string_buffer(before+canary, len(before)+len(canary))
    actual = image._entry(source, len(raw), output, 4352, state, len(before))
    record = {'name': name, 'scope': 'explicit private workspace fault; no filesystem action executed',
              'mutation': change, 'input_hex': raw.hex(), 'workspace_before_hex': before.hex(),
              'expected_return': expected_code, 'actual_return': actual,
              'expected_output_hex': (expected_out+canary).hex(), 'actual_output_hex': bytes(output).hex(),
              'expected_workspace_hex': (bytes(work)+canary).hex(), 'actual_workspace_hex': bytes(state).hex()}
    assert actual == expected_code == 1 and bytes(output) == expected_out+canary and bytes(state) == bytes(work)+canary
    assert bytes(source) == raw+canary
    records.append(record)
with gzip.open(OUT/'invocations.jsonl.gz', 'wt', encoding='utf-8') as stream:
    for row in records:
        stream.write(json.dumps(row, sort_keys=True, separators=(',', ':'))+'\n')
after = {p: digest(Path(p).read_bytes()) for p in pins}
assert pins == after
result = {'scope': 'ACTUAL PRIVATE STATE CORRELATION COUNTEREXAMPLES ONLY; not an ordinary public namespace failure or external authentication result',
          'image_sha256': manifest['image_sha256'], 'actual_native_entries': len(records), 'baseline_return': records[0]['actual_return'],
          'counterexamples': [{'name': row['name'], 'mutation': row['mutation'], 'actual_return': row['actual_return']} for row in records[1:]],
          'before': pins, 'after': after, 'source_unchanged': True,
          'ledger_sha256': digest((OUT/'invocations.jsonl.gz').read_bytes())}
payload = (json.dumps(result, sort_keys=True, indent=2)+'\n').encode(); (OUT/'result.json').write_bytes(payload)
print(json.dumps({'actual_native_entries': len(records), 'counterexamples': result['counterexamples'], 'result_sha256': digest(payload)}, sort_keys=True))
