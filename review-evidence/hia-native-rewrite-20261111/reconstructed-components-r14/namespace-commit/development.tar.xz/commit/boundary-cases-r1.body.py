import errno
from contextlib import contextmanager

BAD=0xfffffffd
observations=[]
started=time.monotonic_ns()
result={'scope':'DEVELOPMENT actual-file commit/fence/crash-boundary controls with native/VM full bytes; mechanical Python syscalls and explicit injected completion faults. Private lock, pending checksum and head leases remain controlled predecessors; no ordinary namespace or physical power-loss/multiwriter issuer qualification.'}

def drive(files, raw, work, hook=None):
    code,h,body=invoke(raw,work)
    while code==1:
        replacement=hook(files,h,body) if hook else None
        response=files.step(h,body) if replacement is None else replacement
        code,h,body=invoke(response,work)
    return code,h,body

def page_chain(raw):
    c=bytes(32)
    for at in range(0,len(raw),4096):
        p=raw[at:at+4096];c=sha256(c+struct.pack('<Q',len(p))+sha256(p).digest()).digest()
    return c

def fault(h, number=None, unknown=False, detail='', real_effect=False):
    raw=ack(h,(),status=2) if unknown else ack(h,[number],status=1)
    log({'kind':'explicit_control_completion','phase':h[6],'action':h[5],'opcode':h[7],
         'errno':number,'unknown':unknown,'detail':detail,'issued_real_syscall_executed':real_effect,'frame_hex':raw.hex()})
    return raw

def once_at(phase, callback):
    issued=[]
    def hook(files,h,body):
        if h[6]==phase and not issued:
            issued.append(h[5]);return callback(files,h,body)
    hook.issued=issued
    return hook

class Case:
    def __init__(self,name):
        self.name=name;self.tmp=tempfile.TemporaryDirectory(prefix='hia-commit-boundary-');self.root=Path(self.tmp.name)
        (self.root/'HEADS').mkdir();(self.root/'DATA').write_bytes(b'uncommitted tail')
        (self.root/'PENDING').write_bytes(spool);(self.root/'CURRENT').write_bytes(sha256(genesis).digest())
        (self.root/'HEADS'/digest(genesis)).write_bytes(genesis)
        self.lock=os.open(self.root/'LOCK',os.O_RDWR|os.O_CREAT|os.O_CLOEXEC,0o600);fcntl.flock(self.lock,fcntl.LOCK_EX)
        self.files=MechanicalFiles(self.root);self.reset(genesis)
        self.before=self.snapshot();log({'kind':'case_begin','name':name,'snapshot':self.before})
    def reset(self,base,view=53,generation=54,prepared=55):
        self.base=base;self.args=(prepared,51,52,view,generation);self.work=bytearray(24576);self.call=1
        self.expected=struct.pack('<QQ',HEAD,1)+base[16:48]+sha256(base).digest()+struct.pack('<QQ',struct.unpack_from('<Q',base,88)[0],struct.unpack_from('<Q',base,88)[0]+len(spool))+page_chain(spool)
        raw=request(1,args=(51,52,601,602,603,604,view,generation,prepared,len(spool),56,57),payload=base+page_chain(spool))
        code,h,body=drive(self.files,raw,self.work);assert code==0 and body==sha256(base).digest()
    def command(self,cmd,hook=None):
        self.call+=1;return drive(self.files,request(cmd,self.call,self.args),self.work,hook)
    def okay(self,cmd,hook=None):
        code,h,body=self.command(cmd,hook);assert code==0,(self.name,cmd,code,h);return h,body
    def through(self,final):
        for cmd in range(2,final+1):self.okay(cmd)
    def retire(self):
        h,body=self.okay(6);assert h[15]==6 and not body and set(self.files.handles)=={601,602,603,604}
    def snapshot(self):
        rows={}
        for p in sorted(self.root.rglob('*')):
            if p.is_file():
                st=p.stat();b=p.read_bytes();rows[str(p.relative_to(self.root))]={'bytes':len(b),'sha256':digest(b),'hex':b.hex(),'mode':st.st_mode&0o777,'inode':st.st_ino}
        return rows
    def poison_stays(self):
        before=bytes(self.work)
        for raw in (b'',request(8,self.call+1,self.args)):
            code,h,body=invoke(raw,self.work);assert code==BAD and bytes(self.work)==before
    def finish(self,facts):
        after=self.snapshot();row={'kind':'case_complete','name':self.name,'facts':facts,'snapshot':after,'only_borrowed_descriptors':set(self.files.handles)=={601,602,603,604}};observations.append(row);log(row)
    def close(self):
        self.files.close();fcntl.flock(self.lock,fcntl.LOCK_UN);os.close(self.lock);self.tmp.cleanup()
@contextmanager
def case(name):
    c=Case(name)
    try:yield c
    finally:c.close()

def finish_known(c,code,h,expected):
    assert code==2 and h[24]==expected and h[27]==0,(c.name,code,h,expected)
    assert (c.root/'CURRENT').read_bytes()==sha256(c.base).digest()
    c.retire();assert not list(c.root.glob('.current-*'))

try:
    code,h,payload=invoke(request(9,args=(51,),payload=bytes(range(1,33))),bytearray(24576))
    genesis=struct.pack('<QQ',HEAD,1)+bytes(range(1,33))+bytes(80)
    assert code==0 and payload==genesis+sha256(genesis).digest()
    cells=[(3,b'slot'),(1,struct.pack('<q',7)),(4,b'\xff\x00artifact')]
    payload=struct.pack('<Q',3)+b''.join(struct.pack('<QQ',k,len(b))+b for k,b in cells)
    spool=struct.pack('<8Q',RECORD,1,1,8,(-7)&MASK,len(payload),80+len(payload),0)+payload+struct.pack('<QQ',80+len(payload),RECORD)
    validate_spool(spool)

    with case('immutable_existing_head_same_bytes') as c:
        (c.root/'HEADS'/digest(c.expected)).write_bytes(c.expected)
        c.through(5);c.retire()
        assert (c.root/'CURRENT').read_bytes()==sha256(c.expected).digest()
        c.finish({'existing_head_exact_replay_accepted':True,'old_head_preserved':(c.root/'HEADS'/digest(genesis)).read_bytes()==genesis})

    with case('immutable_existing_head_wrong_bytes') as c:
        wrong=c.expected[:-1]+bytes([c.expected[-1]^1]);p=c.root/'HEADS'/digest(c.expected);p.write_bytes(wrong)
        code,h,_=c.command(2);finish_known(c,code,h,11);assert p.read_bytes()==wrong
        c.finish({'conflicting_immutable_head_not_overwritten_or_deleted':True,'sqlite_error':11})

    with case('completed_head_then_stale_snapshot_then_new_epoch') as c:
        c.through(5);c.retire();first=c.expected;old_data=(c.root/'DATA').read_bytes()
        assert old_data==spool
        c.reset(genesis,view=153,generation=154,prepared=155)
        code,h,_=c.command(2);assert code==2 and h[24]==5 and (c.root/'DATA').read_bytes()==old_data
        c.retire()
        assert (c.root/'CURRENT').read_bytes()==sha256(first).digest()
        c.reset(first,view=253,generation=254,prepared=255);c.through(5);c.retire()
        assert (c.root/'DATA').read_bytes()==spool+spool and (c.root/'CURRENT').read_bytes()==sha256(c.expected).digest()
        assert (c.root/'HEADS'/digest(first)).read_bytes()==first
        c.finish({'real_first_commit':True,'stale_snapshot_busy_no_write':True,'fresh_epoch_appended_without_changing_old_prefix':True,'old_prefix_bytes':len(spool)})

    with case('current_changed_after_prepare_before_publish') as c:
        c.through(3);foreign=b'x'*32;(c.root/'CURRENT').write_bytes(foreign)
        code,h,_=c.command(4);assert code==2 and h[24]==5 and h[27]==0
        c.retire();assert (c.root/'CURRENT').read_bytes()==foreign and not list(c.root.glob('.current-*'))
        c.finish({'explicit_external_pointer_change':True,'publish_recheck_busy':True,'foreign_pointer_not_overwritten':True})

    with case('actual_pending_bytes_changed_after_private_admission') as c:
        (c.root/'PENDING').write_bytes(spool[:-1]+bytes([spool[-1]^1]))
        code,h,_=c.command(2);finish_known(c,code,h,11)
        c.finish({'actual_pending_changed':True,'native_full_chain_mismatch_refused':True})

    with case('actual_pending_file_truncated') as c:
        (c.root/'PENDING').write_bytes(b'')
        code,h,_=c.command(2);finish_known(c,code,h,522)
        c.finish({'real_pread_returned_zero':True,'sqlite_error':522})

    for name,number,expected in [('known_pwrite_enospc',errno.ENOSPC,13),('known_pwrite_edquot',errno.EDQUOT,778)]:
        with case(name) as c:
            hook=once_at(31,lambda f,h,b,n=number:fault(h,n,detail='injected known errno, syscall not executed'))
            code,h,_=c.command(2,hook);assert hook.issued;finish_known(c,code,h,expected)
            c.finish({'injected_errno':number,'sqlite_error':expected,'source_policy':'SQLite 3.46.1 unixWrite zero/ENOSPC=>FULL; EDQUOT=>IOERR_WRITE'})

    with case('unknown_after_actual_pwrite') as c:
        def write_unknown(f,h,b):
            f.step(h,b);return fault(h,unknown=True,detail='actual pwrite executed then completion deliberately withheld',real_effect=True)
        hook=once_at(31,write_unknown);code,h,_=c.command(2,hook)
        assert code==BAD and h[27]==0 and (c.root/'DATA').read_bytes()==spool[:13]
        c.poison_stays();c.finish({'actual_partial_write_happened':True,'unknown_completion_permanent_poison':True,'old_head_still_current':(c.root/'CURRENT').read_bytes()==sha256(genesis).digest()})

    with case('known_data_fsync_error_before_publication') as c:
        c.okay(2);hook=once_at(50,lambda f,h,b:fault(h,errno.EIO,detail='injected fsync failure; no actual fsync'))
        code,h,_=c.command(3,hook);finish_known(c,code,h,1034)
        c.finish({'injected_fsync_failure':True,'published':False,'sqlite_error':1034})

    with case('known_root_fsync_error_after_publication') as c:
        c.through(4);hook=once_at(70,lambda f,h,b:fault(h,errno.EIO,detail='injected post-rename root fsync failure'))
        code,h,_=c.command(5,hook);assert code==BAD and h[27]==1 and h[24]==1034
        assert (c.root/'CURRENT').read_bytes()==sha256(c.expected).digest();c.poison_stays()
        c.finish({'actual_publication_happened':True,'no_durable_success_claim':True,'postpublication_unknown_state':True})

    with case('unknown_after_actual_rename') as c:
        c.through(3)
        def rename_unknown(f,h,b):
            f.step(h,b);return fault(h,unknown=True,detail='actual rename executed then ACK deliberately withheld',real_effect=True)
        hook=once_at(68,rename_unknown);code,h,_=c.command(4,hook)
        assert code==BAD and h[27]==1 and (c.root/'CURRENT').read_bytes()==sha256(c.expected).digest();c.poison_stays()
        c.finish({'actual_rename_happened':True,'unknown_ack_cannot_be_retried':True,'no_success_claim':True})

    for name,number,poisoned in [('rename_eio_is_unknown',errno.EIO,True),('rename_eintr_is_unknown',errno.EINTR,True),('rename_eacces_known_unpublished',errno.EACCES,False)]:
        with case(name) as c:
            c.through(3);hook=once_at(68,lambda f,h,b,n=number:fault(h,n,detail='injected rename errno; no actual rename'))
            code,h,_=c.command(4,hook);assert hook.issued
            if poisoned:
                assert code==BAD and h[27]==1;c.poison_stays()
            else:finish_known(c,code,h,10)
            c.finish({'injected_errno':number,'known_unpublished':not poisoned,'permanent_poison':poisoned})

    with case('pread_eintr_reissues_fresh_action') as c:
        hook=once_at(30,lambda f,h,b:fault(h,errno.EINTR,detail='injected interrupted pread before execution'))
        c.okay(2,hook);assert hook.issued;c.okay(3);c.okay(4);c.okay(5);c.retire()
        c.finish({'interrupted_action':hook.issued[0],'fresh_action_identity_observed_in_ledger':True,'final_data_exact':(c.root/'DATA').read_bytes()==spool})

    with case('close_eintr_not_retried_after_actual_close') as c:
        closed=[]
        def close_error(f,h,b):
            closed.append(h[8]);f.step(h,b);return fault(h,errno.EINTR,detail='actual close executed; controlled EINTR completion tests consumed-handle policy',real_effect=True)
        hook=once_at(14,close_error);code,h,_=c.command(2,hook);finish_known(c,code,h,4106)
        assert closed[0] not in c.files.handles;c.finish({'closed_descriptor':closed[0],'no_second_close_of_consumed_handle':True})

    for label,offset in [('wrong_call_ack',32),('wrong_action_ack',40),('wrong_opcode_ack',48),('wrong_session_ack',16)]:
        with case(label) as c:
            def wrong(f,h,b,off=offset):
                original=f.step(h,b);out=bytearray(original);old=struct.unpack_from('<Q',out,off)[0];struct.pack_into('<Q',out,off,old+1)
                log({'kind':'explicit_protocol_mutation','offset':off,'before_hex':original.hex(),'after_hex':bytes(out).hex(),'actual_syscall_executed':True});return bytes(out)
            hook=once_at(10,wrong);code,h,_=c.command(2,hook);assert code==BAD;c.poison_stays();c.finish({'exact_issued_ack_correlation_refused':offset})

    with case('duplicate_already_consumed_ack') as c:
        c.call+=1;raw=request(2,c.call,c.args);code,h,body=invoke(raw,c.work);assert code==1
        response=c.files.step(h,body);code,h,body=invoke(response,c.work);assert code==1
        code,h,body=invoke(response,c.work);assert code==BAD;c.poison_stays();c.finish({'real_open_ack_replay_refused_before_following_stat':True})

    assert len(observations)==22,len(observations)
    result.update(status='PASS',cases=observations,tests_run=len(observations),all_native_vm_bytes_equal=True)
except BaseException as error:
    traceback.print_exc();result.update(status='FAIL',exception_type=type(error).__name__,error=str(error),traceback=traceback.format_exc(),cases=observations,tests_completed=len(observations))
finally:
    ledger.close();after={p:digest(Path(p).read_bytes()) for p in pins};(OUT/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
    result.update(counts=counts,source_unchanged=pins==after,wall_elapsed_ns=time.monotonic_ns()-started,ledger_sha256=digest((OUT/'invocations.jsonl.gz').read_bytes()))
    if pins!=after or not counts['commit_native_entries'] or counts['commit_vm_entries']!=counts['commit_native_entries'] or counts['commit_native_entries']!=counts['full_native_vm_bytes_equal']:result['status']='FAIL'
    raw=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode();(OUT/'result.json').write_bytes(raw);print(json.dumps({'status':result['status'],'tests':len(observations),'counts':counts,'result_sha256':digest(raw)},sort_keys=True),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
