from pathlib import Path
from hashlib import sha256
import gzip, io, json, os, stat, tarfile
B=Path('/workspace/scratch/hia-audit-runtime-recovery-20261111');S=B/'namespace-authoring-next';D=B/'namespace-reconstruction/commit-r1';O=B/'namespace-reconstruction/commit-r2-checkpoint-01';O.mkdir(exist_ok=False)
hashraw=lambda b:sha256(b).hexdigest()
counts={};canary=bytes(range(160,192)).hex()
for name in ['smoke-vm-r1','smoke-paired-r1','smoke-vm-r2','smoke-paired-r2','private-state-probe-r1','private-state-probe-r2']:
 p=D/name; result=json.loads((p/'result.json').read_bytes());assert result.get('status','COUNTEREXAMPLE') in ('PASS','COUNTEREXAMPLE') and result['source_unchanged']
 assert result['ledger_sha256']==hashraw((p/'invocations.jsonl.gz').read_bytes())
 c={'vm':0,'actual_commit':0,'actual_log':0,'actual_syscall':0,'paired_full_equal':0};vms={}
 for line in gzip.open(p/'invocations.jsonl.gz','rt'):
  row=json.loads(line);kind=row.get('kind')
  if kind=='commit_vm':
   vms[row['entry']]=row;c['vm']+=1
  elif kind=='actual_native_commit':
   v=vms[row['entry']];assert row['input_hex']==v['input_hex'];assert row['pre_workspace_hex']==v['workspace_before_hex'];assert row['expected_return']==row['actual_return']==v['return'];assert row['expected_output_hex']==row['actual_output_hex']==v['output_hex']+canary;assert row['expected_workspace_hex']==row['actual_workspace_hex']==v['workspace_after_hex']+canary;assert row['actual_input_and_guard_hex']==v['input_hex']+canary;c['actual_commit']+=1;c['paired_full_equal']+=1
  elif kind=='actual_native_record_codec':
   assert row['return']==row['expected_return'];c['actual_log']+=1
  elif kind=='actual_syscall':c['actual_syscall']+=1
  elif kind=='actual_private_lock_predecessor':pass
  elif name.startswith('private-state-probe-'):
   old=name.endswith('r1');assert row['actual_return']==row['expected_return'];assert row['actual_output_hex']==row['expected_output_hex' if old else 'vm_output_hex'];assert row['actual_workspace_hex']==row['expected_workspace_hex' if old else 'vm_workspace_hex'];c['vm']+=1;c['actual_commit']+=1;c['paired_full_equal']+=1
   if not old:assert row['actual_input_and_guard_hex']==row['input_hex']+canary and row['vm_return']==row['actual_return']
  else:raise AssertionError((name,kind))
 counts[name]=c
assert counts['smoke-paired-r1']['paired_full_equal']==counts['smoke-paired-r2']['paired_full_equal']==67
assert counts['private-state-probe-r1']['actual_commit']==4 and counts['private-state-probe-r2']['actual_commit']==14
for row in json.loads((D/'authoring-r2/source.json').read_bytes())['files']:
 assert hashraw((S/row['path']).read_bytes())==row['sha256']
for name in ['smoke-paired-r2','private-state-probe-r2']:
 r=json.loads((D/name/'result.json').read_bytes());pins=json.loads((D/name/'source-before.json').read_bytes()) if name.startswith('smoke') else r['before'];assert all(hashraw(Path(p).read_bytes())==h for p,h in pins.items())
(O/'ledger-readback.json').write_text(json.dumps(counts,sort_keys=True,indent=2)+'\n')
selected=[('commit/'+str(p.relative_to(D)),p) for p in D.rglob('*') if p.is_file()]
selected += [('controllers/seal_commit_r2_checkpoint.py',Path(__file__).resolve()),('ledger-readback.json',O/'ledger-readback.json')]
for rel in ['docs/HIA_AGENT_NAMESPACE_STORE_ABI.json','tools/generate_hia_agent_namespace_store.py','tools/generate_hia_agent_namespace_objects.py','tools/generate_hia_selfhost.py','tools/generate_hia_sha256.py','hepta/hia_agent_assembly.py','hepta/hia_program_runtime.py','hepta/hia_json_preflight_native.py']:
 selected.append(('authoring-dependencies/'+rel,S/rel))
logimage=B/'namespace-reconstruction/log-r1/native-r3/compile/agent-namespace-log.image.bin';selected.append(('actual-prerequisites/'+logimage.name,logimage));selected.sort();assert len(set(n for n,p in selected))==len(selected)
def snap(p):
 st=p.lstat();assert stat.S_ISREG(st.st_mode);raw=p.read_bytes();end=p.lstat();fields=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mode,q.st_mtime_ns,q.st_ctime_ns);assert fields(st)==fields(end);return raw,{'bytes':len(raw),'sha256':hashraw(raw),'mode':st.st_mode&0o777,'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
rows=[]
for name,p in selected:
 raw,meta=snap(p);rows.append({'name':name,'original':str(p),**meta})
scope='DEVELOPMENT immutable commit component checkpoint. Full actual-file positive path in VM and actual B3 r1/r2 images; explicit three private-state r1 counterexamples and r2 permanent refusal. Controlled private lock/pending/head predecessors and Python mechanical syscall transport; no fixed executor, complete multiwriter, migration, ordinary namespace or qualification closure.'
cust={'schema':'hia.namespace-commit-development-custody.v1','scope':scope,'members':rows,'original_files':len(rows),'original_bytes':sum(x['bytes'] for x in rows),'readback':counts,'r1_image_sha256':'b6de8ae9f169e71db5012a53fcb8a62253d94a4118b911fa1d44571d807f6099','r2_image_sha256':'e5dbc5d110ec00a36ca027ff822275ed0e392ad1bf767b0ed5a7c02a5df001dd','compiler_limits':{'cpu_seconds':10,'wall_seconds':20,'address_bytes':256<<20,'output_bytes':1<<20,'workspace_bytes':1<<20},'actual_commit_entries':sum(x['actual_commit'] for x in counts.values()),'original_qualification':'0ef full remains FAIL/HOLD; this development does not change its outcome'}
craw=(json.dumps(cust,sort_keys=True,indent=2)+'\n').encode();(O/'custody.json').write_bytes(craw);archive=O/'namespace-commit-r2-development.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tf:
 for row,(_,p) in zip(rows,selected):
  raw,meta=snap(p);assert all(meta[k]==row[k] for k in meta);m=tarfile.TarInfo(row['name']);m.size=len(raw);m.mode=row['mode'];m.mtime=0;tf.addfile(m,io.BytesIO(raw))
 m=tarfile.TarInfo('CUSTODY.json');m.size=len(craw);m.mode=0o644;m.mtime=0;tf.addfile(m,io.BytesIO(craw))
with archive.open('rb') as stream:os.fsync(stream.fileno())
with tarfile.open(archive,'r:xz') as tf:
 members=tf.getmembers();assert len(members)==len(rows)+1 and len(set(m.name for m in members))==len(members);expected={r['name']:r for r in rows}
 for m in members:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts;raw=tf.extractfile(m).read()
  if m.name=='CUSTODY.json':assert raw==craw and m.mode==0o644
  else:
   r=expected[m.name];assert len(raw)==r['bytes'] and hashraw(raw)==r['sha256'] and m.mode==r['mode'];live,meta=snap(Path(r['original']));assert live==raw and all(meta[k]==r[k] for k in meta)
raw=archive.read_bytes();summary={'status':'COMPLETE_ORIGINALS_AND_FULL_PAIRED_LEDGERS_READBACK','scope':scope,'archive':str(archive),'archive_bytes':len(raw),'archive_sha256':hashraw(raw),'custody':str(O/'custody.json'),'custody_bytes':len(craw),'custody_sha256':hashraw(craw),'archive_members':len(rows)+1,'original_members':len(rows),'original_bytes':cust['original_bytes'],'actual_commit_entries':cust['actual_commit_entries'],'all_bytes_modes_inode_mtime_ctime_unchanged':True}
(O/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
