"""Actual decoder, request, Graph wire and SHA against original worker.main."""
from contextlib import ExitStack
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import random
import struct
import sys
import time
import traceback
from types import SimpleNamespace
from unittest.mock import patch
import uuid

from worker_request_harness import ActualRequest, ROOT, forbid_retained
from worker_decode_harness import Actual as ActualDecode
from hepta import hia_agent_worker as worker
from hepta import hia_agent_service as service
from hepta.hia_agent_store import wire

OUT = ROOT / 'development/request-semantics-r1'
OUT.mkdir(exist_ok=False)
CATALOG = 'c' * 64
IDENTITIES = dict(worker_sha256='a' * 64, backend_sha256='b' * 64, catalog_sha256=CATALOG)
ORIGINAL = {name: getattr(worker, name) for name in ('main', 'keys', 'wire', 'decode_data', 'AgentRejected')}
actual = ActualRequest(OUT / 'actual')
decoder = ActualDecode(OUT / 'decode')
rows = []
summary = dict(status='INCOMPLETE')
started = time.monotonic_ns()


class Accepted(BaseException):
    pass


def envelope(tool='hia_describe', arguments=None):
    value = dict(schema='hia-agent-worker-request-v1', tool=tool,
                 arguments={'section': 'manifest'} if arguments is None else arguments,
                 profile_sha256='d' * 64, catalog_sha256=CATALOG)
    return renew(value)


def renew(value):
    value['request_sha256'] = sha256(wire({k: v for k, v in value.items() if k != 'request_sha256'})).hexdigest()
    return value


def oracle(raw, digits):
    events = []
    def observed(name):
        def call(*args, **kwargs):
            try:
                return ORIGINAL[name](*args, **kwargs)
            except (ValueError, OSError, TypeError, OverflowError, RecursionError) as exc:
                events.append(dict(type=type(exc).__name__, text=str(exc), code=getattr(exc, 'code', None)))
                raise
        return call
    def rejected(*args, **kwargs):
        exc = ORIGINAL['AgentRejected'](*args, **kwargs)
        events.append(dict(type=type(exc).__name__, text=str(exc), code=exc.code))
        return exc
    def service_entry(*args, **kwargs):
        raise Accepted()
    before = sys.get_int_max_str_digits()
    accepted = False
    try:
        sys.set_int_max_str_digits(digits)
        with ExitStack() as stack:
            stack.enter_context(patch.dict(os.environ, {}, clear=True))
            stack.enter_context(patch.object(worker, 'installation_manifest', new=lambda: IDENTITIES))
            for name in ('keys', 'wire', 'decode_data'):
                stack.enter_context(patch.object(worker, name, new=observed(name)))
            stack.enter_context(patch.object(worker, 'AgentRejected', new=rejected))
            stack.enter_context(patch.object(service, 'HIAAgentService', new=service_entry))
            stack.enter_context(patch.object(worker.uuid, 'uuid4', new=lambda: uuid.UUID(int=0)))
            stack.enter_context(patch.object(sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(raw))))
            stack.enter_context(patch.object(sys, 'stdout', SimpleNamespace(buffer=io.BytesIO())))
            stack.enter_context(patch.object(sys, 'stderr', io.StringIO()))
            try:
                ORIGINAL['main'](['--state-root', str(OUT / 'never-created'), '--request-json-stdin'])
            except Accepted:
                accepted = True
    finally:
        sys.set_int_max_str_digits(before)
    assert not (OUT / 'never-created').exists()
    assert accepted != bool(events), (accepted, events)
    return dict(accepted=accepted, error=events[0] if events else None)


def exercise(label, value, digits=4300):
    raw = value if type(value) is bytes else wire(value)
    expected = oracle(raw, digits)
    with ExitStack() as stack:
        forbid_retained(stack)
        decoded = decoder.run(raw, digits=digits, case=label)
        assert 'graph' in decoded, (label, decoded)
        result = actual.run(decoded['graph'], CATALOG, digits=digits, label=label, request=len(rows) + 1)
    if expected['accepted']:
        assert result['event'][1] == 0 and result['error'] is None, (label, result, expected)
        assert len(result['digest']) == 32
    else:
        assert result['event'][1] == 3 and result['error'] == expected['error']['text'], (label, result, expected)
        types = {1: ('AgentRejected', 'E_HIA_FIELDS'), 2: ('AgentRejected', 'E_HIA_WORKER_SCHEMA'),
                 3: ('AgentRejected', 'E_HIA_WORKER_IDENTITY'), 4: ('HIAEditRejected', None),
                 5: ('AgentRejected', 'E_HIA_WORKER_IDENTITY'), 6: ('AgentRejected', 'E_HIA_CATALOG_STALE'),
                 7: ('AgentRejected', 'E_HIA_WORKER_TOOL')}
        observed = types[result['event'][15]]
        assert observed == (expected['error']['type'], expected['error']['code']), (label, observed, expected)
    row = dict(case=label, status='PASS', outcome='ACCEPT' if expected['accepted'] else 'REJECT',
               input=actual.save(raw), expected=expected, event=result['event'],
               result=result['result'], grows=result['grows'], services=result['services'])
    rows.append(row)
    print(json.dumps({key: row[key] for key in ('case', 'status', 'outcome')}, sort_keys=True), flush=True)


try:
    for tool in ('hia_describe', 'hia_artifact', 'hia_read', 'hia_context', 'hia_inspect',
                 'hia_candidate', 'hia_verify', 'hia_emit', 'hia_evaluate', 'hia_adopt',
                 'hia_rollback', 'hia_resource_read', '', 'not-a-catalog-tool'):
        exercise('tool-forward-' + tool, envelope(tool))
    for i, arguments in enumerate((None, [], {}, True, False, 0, -1, 1.25, -0.0, 1e15, 1e-4,
                                   5e-324, 1.7976931348623157e308, '😀字',
                                   {'request_sha256': 'retain-nested', 'x': [1e15, -0.0, 1.25]})):
        value = envelope(); value['arguments'] = arguments; renew(value)
        exercise('ordinary-arguments-' + str(i), value)
    for root in (None, True, 1, [], ['schema'], 'x', {}):
        exercise('root-' + type(root).__name__ + '-' + str(len(rows)), root)
    for key in ('schema', 'tool', 'arguments', 'request_sha256', 'profile_sha256', 'catalog_sha256'):
        value = envelope(); del value[key]
        exercise('missing-' + key, value)
    value = envelope(); value['extra'] = 1; value['schema'] = None
    exercise('fields-before-schema', value)
    for schema in ('wrong', None, [], {}, True, 7):
        value = envelope(); value['schema'] = schema; value['request_sha256'] = None
        exercise('schema-before-digest-' + str(len(rows)), value)
    for key in ('request_sha256', 'profile_sha256', 'catalog_sha256'):
        for digest in (None, [], True, 0, 'a' * 63, 'a' * 65, 'A' * 64, 'g' * 64, '0' * 63 + ' ', '字' * 64):
            value = envelope(); value[key] = digest
            exercise('canonical-' + key + '-' + str(len(rows)), value)
    value = envelope(); value['request_sha256'] = '0' * 64; value['catalog_sha256'] = 'f' * 64; value['tool'] = []
    exercise('mismatch-before-catalog-and-tool', value)
    value = envelope(); value['catalog_sha256'] = 'f' * 64; value['tool'] = []; renew(value)
    exercise('catalog-before-tool', value)
    for tool in (None, False, 0, 1.25, [], {}, 'x' * 129, '😀' * 129):
        exercise('tool-invalid-' + str(len(rows)), envelope(tool))
    for tool in ('x' * 128, '😀' * 128, 'a\x00b'):
        exercise('tool-valid-codepoint-' + str(len(rows)), envelope(tool))
    value = envelope(arguments={'unicode': '😀汉\n\t', 'number': 1e15})
    exercise('raw-whitespace-and-escaped-unicode', b' \n' + json.dumps(value, ensure_ascii=True, indent=2).encode() + b'\t ')
    randomizer = random.Random(4412001)
    for i in range(20):
        value = envelope(arguments={'b': i + 0.125, 'a': ['b', None, {'request_sha256': i}], '字': i})
        pairs = list(value.items()); randomizer.shuffle(pairs)
        exercise('object-insertion-order-' + str(i), dict(pairs))
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    decoder.close()
    actual.close()
    summary.update(request_entries=actual.entries, decode_entries=decoder.entries,
                   wall_ns=time.monotonic_ns() - started, source_before_after_equal=True,
                   scope='ACTUAL_NATIVE_WORKER_BYTES_TO_COMPLETE_REQUEST_COMPONENT',
                   original_worker_main_oracle=True, complete_worker=False, native_business_service=False)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('results', 'completed')}, sort_keys=True), flush=True)
