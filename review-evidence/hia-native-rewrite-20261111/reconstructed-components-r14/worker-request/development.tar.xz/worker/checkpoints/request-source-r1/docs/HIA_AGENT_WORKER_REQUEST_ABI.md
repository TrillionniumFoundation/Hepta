# Complete ordinary worker request envelope owner

This component consumes the actual immutable Graph produced by the complete worker bytes decoder. It is development work, not an installed worker, an eleven-tool service, a cold qualification, or a replacement for the caller's actual source lease. The HIA source is `examples/hia_bootstrap/agent_worker_request_driver.hiaasm`; its independently compiled peers are the complete Graph wire scan/emit images and incremental SHA-256.

## Original semantic order

The unselected `hia_agent_worker.main` first decodes bytes, then checks exact six fields, exact schema, canonical request/profile/catalog digests in that order, canonical body wire excluding only the top-level request digest, SHA equality, installed catalog equality, and exact string type / 128 Unicode code-point tool length. This owner implements that whole envelope sequence. Arguments remain complete ordinary finite-number JSON and are not prematurely validated as a tool schema. Unknown tool strings and the resource-read alias reach the service unchanged.

Canonical body wire uses the original 8 MiB, UTF-8, sorted-key ordinary profile and the caller's actual integer digit setting. The existing complete native wire owners perform their full snapshot/shape/numeric/string checks before publication. A wire refusal remains the original full `E_HIA_EDIT` message; it is not relabeled as a request hash failure. A complete decoded request remains available to the outer worker for the original correlation decision even when envelope admission fails.

## Private input and workspace

The retained ABI is RWW, with the first Graph and second command actually borrowed read-only. A fresh workspace is at least 2,048 bytes and has a zero state prefix of 1,024 bytes. All growth preserves the full prior bytes. The source Graph's original immutable lease remains alive and unchanged through every continuation. Header equality is a correlation check, not authentication of arbitrary substituted payloads.

The initial 128-byte command is eight little-endian u64 words followed by the actual canonical 64-byte installed catalog digest:

`[HIAWQC01, lease, request, digits, sourceBytes, 0, 0, 0] + catalog`

Lease and request are nonzero. The complete initial command is held across initial GROW. The controller creates a new Graph root for the five body fields, preserving all source values and dictionary order; it does not materialize a Python dictionary. Source scalar bytes and object identities are retained through the shared native Graph representation.

## Event

An ordinary call returns 512. A 32-word event occupies workspace bytes 256..511:

| Word | Meaning |
|---:|---|
| 0 | `HIAWQE01` |
| 1 | action: 0 complete, 1 own GROW, 2 actual peer call, 3 semantic refusal, 4 private refusal |
| 2–4 | lease, request, monotonically increasing event sequence |
| 5–7 | phase, own required extent, peer |
| 8–11 | peer input offset/bytes, peer command offset/bytes |
| 12–14 | exact peer workspace extent, peer output extent, reuse flag |
| 15–16 | semantic category, original wire error identifier |
| 17–18 | terminal value offset and bytes |
| 19–23 | original request root, tool ID, arguments ID, body root, body Graph bytes |
| 24–25 | actual canonical body byte length, private refusal reason |
| 26–31 | zero |

Only the active views indicated by the current action may be borrowed. Body storage is retired before canonical wire and then terminal value storage reuse the same region. A completed result is the actual 32-byte digest; a semantic refusal is full UTF-8 message bytes. The original source Graph still supplies the tool, arguments, and four outer report correlation fields.

Semantic categories are 1 fields (`E_HIA_FIELDS`), 2 schema (`E_HIA_WORKER_SCHEMA`), 3 digest syntax and 5 digest mismatch (`E_HIA_WORKER_IDENTITY`), 6 catalog (`E_HIA_CATALOG_STALE`), 7 tool (`E_HIA_WORKER_TOOL`), and 4 the original `HIAEditRejected` wire error. For category 4 the worker's existing default error code remains `E_HIA_WORKER` because the original exception has no Agent `code` attribute.

## Peer continuations

Peer 1 is Graph wire scan, peer 2 is Graph wire emit, and peer 3 is incremental SHA. The fixed executor selects the exact admitted image for that peer. It allocates the requested exact workspace extent, retains the same workspace on reuse, and preserves bytes on growth. It passes the HIA-authored command and input views without interpreting request data.

Each actual response is:

`[HIAWQA01, lease, request, issuedEventSequence, peer, actualReturn, outputBytes, workspaceBytes] + actualOutput + actualWorkspace`

The Graph peers have no second output payload; the complete native workspace is returned. Every original wire event field and transition is validated. Scan GROW cannot become emit success. The scan-to-emit handoff is explicit. Emit growth cannot move backward. Complete wire has the same root, profile, length, bounded view, and final phase. On the controller's distinct phase-21 copy GROW, it holds the same complete response and retries copying; it does not invoke a producer again or accept a newly computed wire as prior evidence.

SHA uses its original 1,184-byte state and 32-byte output: actual init, then one bounded update containing the complete body, then actual final. The controller checks the state ABI, total, partial count, phase, actual return, and sequence at each step. It reads the digest from the real final output, compares all 64 lowercase hex request bytes, and only then checks catalog and tool.

The caller must preserve the actual immutable input/response lease. Replacing a private source with a different payload having the same header is explicitly outside authentication provided by this ABI; an independent control retains that limitation. The final fixed executor must make those views read-only and forbid replacement.

## Refusal and completion

Any private BAD (`0xfffffffd`) requires permanent caller lease disposal, without retrying a semantic effect. Full-sized active state records private poison; completed state remains completed and permanently refuses all further entries. A workspace advertised shorter than 2,048 bytes cannot safely be poisoned. Event-sequence exhaustion may also leave the prior event unchanged. The caller must inspect the native return before trusting any event and discard in both cases.

## Evidence scope

The source and historical f50 B3 compile identities are in `development/request-compile-r1/`. Original compile limits remain 10 CPU seconds, 20 wall seconds and 256 MiB; authoring limits remain 128 functions, 1,536 blocks, 8,192 instructions and 16 block parameters.

`request-semantics-r1` contains 113 complete raw-bytes→actual decoder→Graph→request→wire→SHA cases compared against the original full worker entry. Retained worker/decode/wire/identity functions and JSON materialization are disabled during native forwarding. `request-protocol-r1` preserves a test assertion failure: completion correctly returned BAD while retaining terminal state 2, whereas the test incorrectly demanded private state 3. The corrected independent run `request-protocol-r2` has 262 actual-image controls, including exact full-state replay, foreign/stale ACKs, permanent rejection, exact GROW, and explicit private lease limitations. No production source changed for that test correction.

The reachable canonical-body late boundary has its own completed three-case development run: 8 MiB−1 and 8 MiB are accepted with the exact real digest; 8 MiB+1 receives the original full wire refusal before SHA. Every original raw request is below 8 MiB: 128 short finite exponent tokens expand under the ordinary canonical binary64 renderer. All three use the actual bytes decoder, Graph wire owners and request controller; the two accepted cases also run the actual SHA owner. The unchanged test envelope is 90 CPU seconds / 1 GiB. This is a boundary result, not a performance comparison.

All eleven business services, journal/namespace execution, installed identity scanning, fixed process execution, and ordinary release activation remain separate work. No independent review of this new request component is claimed at this checkpoint.
