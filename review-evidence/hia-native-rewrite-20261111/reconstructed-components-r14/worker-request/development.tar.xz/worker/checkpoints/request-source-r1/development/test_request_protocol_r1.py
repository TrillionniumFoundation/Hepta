"""Actual-image continuation faults replay immutable real peer observations."""
from contextlib import ExitStack
from hashlib import sha256
import ctypes
import gzip
import json
from pathlib import Path
import struct
import time
import traceback

from worker_request_harness import ActualRequest, ROOT, BAD, forbid_retained
from worker_decode_harness import Actual as ActualDecode
from hepta.hia_agent_store import wire

OUT = ROOT / 'development/request-protocol-r1'
OUT.mkdir(exist_ok=False)
actual = ActualRequest(OUT / 'actual')
decoder = ActualDecode(OUT / 'decode')
rows = []
summary = dict(status='INCOMPLETE')
started = time.monotonic_ns()


def load(row):
    raw = gzip.decompress(Path(row['path']).read_bytes()) if row.get('storage') == 'lossless-gzip' else Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
    return raw


def changed(raw, offset, value):
    data = bytearray(raw)
    struct.pack_into('<Q', data, offset, value)
    return bytes(data)


def reject(label, baseline, *, source=None, command=None, state=None):
    original_source = load(baseline['source'])
    original_command = load(baseline['command'])
    before = load(baseline['before']) if state is None else state
    source = original_source if source is None else source
    command = original_command if command is None else command
    work = actual.buffer(len(before), before)
    ret, event, after, _ = actual.call('controller', source, command, work, len(before), label)
    assert ret == BAD and struct.unpack_from('<Q', after, 8)[0] == 3, (label, ret, event)
    ret2, _, after2, _ = actual.call('controller', original_source, original_command, work, len(before), label + '-poisoned')
    assert ret2 == BAD and after2 == after, label
    rows.append(dict(case=label, status='PASS', outcome='PRIVATE_ABI_REFUSAL_THEN_PERMANENT_REFUSAL',
                     reason=struct.unpack_from('<Q', after, 192)[0]))


try:
    captured = []
    for line in (ROOT / 'development/request-semantics-r1/actual/entries.jsonl').open():
        row = json.loads(line)
        if row['case'] != 'tool-forward-hia_describe':
            break
        if row['role'] == 'controller':
            captured.append(row)
    assert len(captured) == 11
    for i, baseline in enumerate(captured):
        source, command, before = (load(baseline[key]) for key in ('source', 'command', 'before'))
        work = actual.buffer(len(before), before)
        ret, _, after, _ = actual.call('controller', source, command, work, len(before), 'exact-transition-' + str(i))
        assert ret == baseline['result'] and after == load(baseline['after'])
        rows.append(dict(case='exact-transition-' + str(i), status='PASS', outcome='EXACT_FULL_WORKSPACE'))
    initial = captured[0]
    initial_command = load(initial['command'])
    for size in (0, 1, 63, 127, 129):
        reject('initial-command-length-' + str(size), initial, command=(initial_command + b'\0')[:size])
    for at, value in ((0, 0), (8, 0), (16, 0), (32, 0), (40, 1), (48, 1), (56, 1)):
        reject('initial-command-word-' + str(at), initial, command=changed(initial_command, at, value))
    for byte in (ord('A'), ord('g'), 0, 255):
        reject('initial-catalog-byte-' + str(byte), initial, command=initial_command[:64] + bytes([byte]) + initial_command[65:])
    for at in (0, 8, 16, 24, 32, 40, 48, 56, 512, 1016):
        if at == 8:
            continue
        reject('dirty-initial-workspace-' + str(at), initial, state=changed(load(initial['before']), at, 1))
    source = load(initial['source'])
    for at, value in ((0, 0), (8, 0), (16, 0), (24, 0), (32, (1 << 64) - 1), (40, 0), (48, 0), (56, 1)):
        reject('initial-source-header-' + str(at), initial, source=changed(source, at, value))
    grow = captured[1]
    for at in (0, 8, 16, 24, 32, 40, 48, 56, 64, 120):
        command = load(grow['command'])
        reject('initial-grow-command-binding-' + str(at), grow,
               command=changed(command, at, struct.unpack_from('<Q', command, at)[0] ^ 1))
    for at in range(0, 64, 8):
        reject('continuation-source-header-' + str(at), grow,
               source=changed(source, at, struct.unpack_from('<Q', source, at)[0] ^ 1))
    for i, baseline in enumerate(captured[2:]):
        command = load(baseline['command'])
        phase = struct.unpack_from('<Q', load(baseline['before']), 96)[0]
        for at in range(0, 64, 8):
            reject('reply-' + str(i) + '-header-' + str(at), baseline,
                   command=changed(command, at, struct.unpack_from('<Q', command, at)[0] ^ 1))
        if phase == 20:
            event = struct.unpack_from('<16Q', command, 64)
            for at in (64, 80, 88, 96, 104, 112, 120, 184):
                reject('wire-' + str(i) + '-correlation-' + str(at), baseline,
                       command=changed(command, at, struct.unpack_from('<Q', command, at)[0] ^ 1))
            reject('wire-' + str(i) + '-unknown-action', baseline, command=changed(command, 72, 9))
            reject('wire-' + str(i) + '-error-on-success', baseline, command=changed(command, 128, 1))
            reject('wire-' + str(i) + '-cause-on-success', baseline, command=changed(command, 136, 1))
            if event[1] == 1:
                reject('wire-' + str(i) + '-nongrowing-capacity', baseline, command=changed(command, 144, 1))
                for at in (152, 160, 168):
                    reject('wire-' + str(i) + '-grow-payload-' + str(at), baseline, command=changed(command, at, 1))
                reject('wire-' + str(i) + '-grow-unknown-phase', baseline, command=changed(command, 176, 100))
            elif event[1] == 2:
                for at in (144, 152, 160):
                    reject('wire-handoff-field-' + str(at), baseline, command=changed(command, at, 1))
                reject('wire-handoff-kernel', baseline, command=changed(command, 168, 3))
                reject('wire-handoff-phase', baseline, command=changed(command, 176, 1))
            else:
                assert event[1] == 0
                for at, value in ((144, 1), (152, 0), (160, 0), (160, (8 << 20) + 1), (168, 1), (176, 91)):
                    reject('wire-done-' + str(at) + '-' + str(value), baseline, command=changed(command, at, value))
        else:
            assert phase in (30, 31, 32)
            for at in (96 + 1088, 96 + 1096, 96 + 1104, 96 + 1176):
                reject('SHA-' + str(phase) + '-state-' + str(at), baseline,
                       command=changed(command, at, struct.unpack_from('<Q', command, at)[0] ^ 1))
    completed = captured[-1]
    reject('completion-cannot-be-replayed', completed, state=load(completed['after']))
    reject('unknown-controller-phase', grow, state=changed(load(grow['before']), 96, 9999))
    reject('event-sequence-overflow-discard', grow, state=changed(load(grow['before']), 32, (1 << 64) - 1))

    # This is deliberately a private immutable-lease scope witness, not a
    # public attack: equal source headers cannot authenticate substituted bytes.
    original = load(completed['source'])
    replacement = original.replace(b'manifest', b'MANIFEST')
    assert len(original) == len(replacement) and original[:64] == replacement[:64] and original != replacement
    before = load(completed['before'])
    work = actual.buffer(len(before), before)
    ret, event, _, _ = actual.call('controller', replacement, load(completed['command']), work, len(before), 'private-source-lease-replacement')
    assert ret == 512 and event[1] == 0
    rows.append(dict(case='private-source-lease-replacement', status='PASS', outcome='DOCUMENTED_PRIVATE_ISSUER_REQUIREMENT',
                     arbitrary_source_authenticated=False, original=actual.save(original), replacement=actual.save(replacement)))

    # Too-short advertised state cannot be poisoned; the fixed executor must
    # discard any lease after BAD even when the event remains unchanged.
    before = load(grow['before'])
    work = actual.buffer(len(before), before)
    ret, _, _, _ = actual.call('controller', source, load(grow['command']), work, 2047, 'short-workspace-no-poison') if False else (None, None, None, None)
    short = actual.buffer(2047, before[:2047])
    ret, _, after, _ = actual.call('controller', source, load(grow['command']), short, 2047, 'short-workspace-no-poison')
    assert ret == BAD and after == before[:2047]
    rows.append(dict(case='short-workspace-no-poison', status='PASS', outcome='MANDATORY_CALLER_LEASE_DISCARD'))

    # Actual wire expansion beyond the source Graph forces the controller's
    # distinct phase-21 copy continuation; no serialization is repeated.
    value = dict(schema='hia-agent-worker-request-v1', tool='hia_describe', arguments='\0' * 5000,
                 profile_sha256='d' * 64, catalog_sha256='c' * 64)
    value['request_sha256'] = sha256(wire(value)).hexdigest()
    raw = wire(value)
    start = len(actual.records)
    with ExitStack() as stack:
        forbid_retained(stack)
        decoded = decoder.run(raw, case='actual-wire-expansion')
        result = actual.run(decoded['graph'], 'c' * 64, label='actual-wire-expansion')
    assert result['event'][1] == 0
    expanded = [row for row in actual.records[start:] if row['role'] == 'controller']
    held = next(row for row in expanded if struct.unpack_from('<Q', load(row['before']), 96)[0] == 21)
    for at in (0, 24, 40, 56, 64, 72, 96, 120, 144, 152, 160, 176, 184):
        command = load(held['command'])
        reject('wire-copy-grow-header-' + str(at), held,
               command=changed(command, at, struct.unpack_from('<Q', command, at)[0] ^ 1))
    rows.append(dict(case='actual-wire-expansion', status='PASS', outcome='ACTUAL_SUCCESS_WITH_COPY_GROW',
                     event=result['event'], grows=result['grows'], services=result['services']))
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    decoder.close()
    actual.close()
    summary.update(request_entries=actual.entries, decode_entries=decoder.entries,
                   wall_ns=time.monotonic_ns() - started, source_before_after_equal=True,
                   scope='ACTUAL_WORKER_REQUEST_PRIVATE_FRAME_AND_GROW_CONTROLS', complete_worker=False)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('results', 'completed')}, sort_keys=True), flush=True)
