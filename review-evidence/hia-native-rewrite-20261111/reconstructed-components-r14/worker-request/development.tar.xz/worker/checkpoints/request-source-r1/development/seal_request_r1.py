"""Seal immutable completed request evidence and verify every stored raw byte."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
BOUNDARY = Path('/dev/shm/hia-worker-request-boundaries-r1')
ARCHIVE = BASE / 'hia-native-agent-worker-request-r1-development.tar.xz'
assert not ARCHIVE.exists()
files = {}


def add(path):
    path = Path(path).resolve()
    assert path.is_file() and not path.is_symlink()
    if '__pycache__' in path.parts:
        return
    if path.is_relative_to(ROOT):
        name = 'worker/' + path.relative_to(ROOT).as_posix()
    elif path.is_relative_to(BOUNDARY):
        name = 'large-boundaries/' + path.relative_to(BOUNDARY).as_posix()
    else:
        assert path.is_relative_to(BASE)
        name = 'dependencies/' + path.relative_to(BASE).as_posix()
    if name in files:
        assert files[name] == path
    files[name] = path


for rel in ('checkpoints/baseline-r1', 'checkpoints/request-source-r1',
            'development/request-compile-r1', 'development/request-semantics-r1',
            'development/request-protocol-r1', 'development/request-protocol-r2'):
    for path in (ROOT / rel).rglob('*'):
        if path.is_file():
            add(path)
for path in BOUNDARY.rglob('*'):
    if path.is_file():
        add(path)
for rel in ('tools/generate_hia_worker_request_driver.py',
            'examples/hia_bootstrap/agent_worker_request_driver.hiaasm',
            'docs/HIA_AGENT_WORKER_REQUEST_ABI.md', 'REQUEST_HANDOFF_R1.md',
            'development/worker_request_harness.py', 'development/compile_request_r1.py',
            'development/test_request_semantics_r1.py', 'development/test_request_protocol_r1.py',
            'development/test_request_protocol_r2.py', 'development/test_request_boundaries_r1.py',
            'development/request-boundaries-r1-summary.json', 'development/seal_request_r1.py'):
    add(ROOT / rel)
for name in ('worker-request-authoring-r1.log', 'request-compile-r1.log',
             'request-semantics-r1.log', 'request-protocol-r1.log',
             'request-protocol-r2.log', 'request-boundaries-r1.log'):
    add(ROOT / 'development' / name)
for run in (ROOT / 'development/request-semantics-r1', ROOT / 'development/request-protocol-r1',
            ROOT / 'development/request-protocol-r2', BOUNDARY):
    summary = json.loads((run / 'summary.json').read_bytes())
    assert summary['status'] == ('FAIL' if run.name == 'request-protocol-r1' else 'PASS')
    assert summary['source_before_after_equal']
    for sub in ('actual', 'decode'):
        before = json.loads((run / sub / 'source-before.json').read_bytes())
        after = json.loads((run / sub / 'source-after.json').read_bytes())
        assert before == after
        for path, expected in before.items():
            raw = Path(path).read_bytes()
            digest = expected['sha256'] if isinstance(expected, dict) else expected
            assert sha256(raw).hexdigest() == digest
            if isinstance(expected, dict):
                assert len(raw) == expected['bytes']
            add(path)
for row in json.loads((ROOT / 'development/request-compile-r1/source.json').read_bytes()):
    path = Path(row['path'])
    raw = path.read_bytes()
    assert raw == Path(row['copy']).read_bytes()
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
    add(path)

raw_members = {}
def find_raw(value):
    if isinstance(value, dict):
        if value.get('storage') == 'lossless-gzip':
            key = value['path']
            if key in raw_members:
                assert raw_members[key]['sha256'] == value['sha256'] and raw_members[key]['bytes'] == value['bytes']
            raw_members[key] = value
        for child in value.values():
            find_raw(child)
    elif isinstance(value, list):
        for child in value:
            find_raw(child)
for name, path in list(files.items()):
    if path.name == 'entries.jsonl':
        for line in path.read_text().splitlines():
            find_raw(json.loads(line))
    elif path.name == 'summary.json':
        find_raw(json.loads(path.read_bytes()))
for name, row in raw_members.items():
    path = Path(name)
    assert path.is_absolute()
    raw = gzip.decompress(path.read_bytes())
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
    add(path)

members = []
with tarfile.open(ARCHIVE, 'w:xz', preset=6) as writer:
    for name, path in sorted(files.items()):
        raw = path.read_bytes()
        row = dict(name=name, original=str(path), bytes=len(raw), sha256=sha256(raw).hexdigest(),
                   mode=stat.S_IMODE(path.stat().st_mode))
        members.append(row)
        writer.add(path, arcname=name, recursive=False)
with tarfile.open(ARCHIVE, 'r:xz') as reader:
    actual = reader.getmembers()
    assert len(actual) == len(members)
    for entry, row in zip(actual, members):
        raw = reader.extractfile(entry).read()
        assert entry.name == row['name'] and entry.size == row['bytes'] and entry.mode == row['mode']
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        assert Path(row['original']).read_bytes() == raw
manifest = ARCHIVE.with_suffix('.members.json')
manifest.write_text(json.dumps(members, indent=2, sort_keys=True) + '\n')
custody = dict(archive=str(ARCHIVE), bytes=ARCHIVE.stat().st_size,
               sha256=sha256(ARCHIVE.read_bytes()).hexdigest(), members=str(manifest),
               member_manifest_sha256=sha256(manifest.read_bytes()).hexdigest(),
               member_count=len(members), member_bytes=sum(row['bytes'] for row in members),
               all_members_original_bytes_size_mode_sha_readback=True,
               compressed_original_cas_count=len(raw_members), compressed_original_cas_sha_readback=True,
               semantic_cases=113, protocol_cases=262, reachable_late_boundary_cases=3,
               initial_protocol_test_assertion_failure_retained=True,
               scope='DEVELOPMENT_COMPLETE_WORKER_REQUEST_COMPONENT_NOT_WHOLE_WORKER')
ARCHIVE.with_suffix('.custody.json').write_text(json.dumps(custody, indent=2, sort_keys=True) + '\n')
print(json.dumps(custody, sort_keys=True), flush=True)
