"""Fresh source-bound development compiles under the original compiler limits."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
sys.path[:0] = [str(ROOT / 'tools'), str(BASE / 'Hepta-agent-edit-native')]
from generate_hia_worker_request_driver import document
from hepta.hia_agent_assembly import assemble_program, render_assembly
from tools.qualify_hia_selfhost import compile_stage

OUT = ROOT / 'development/request-compile-r1'
OUT.mkdir(exist_ok=False)
COMPILER = BASE / 'native-composite-core-final-recovery-next/dependencies/f50-B3.image.bin'
SOURCE = ROOT / 'examples/hia_bootstrap/agent_worker_request_driver.hiaasm'
HASH_SOURCE = BASE / 'Hepta-agent-edit-native/examples/hia_bootstrap/sha256_stream.hiaasm'
paths = [Path(__file__), COMPILER, SOURCE, HASH_SOURCE,
         ROOT / 'tools/generate_hia_worker_request_driver.py',
         ROOT / 'checkpoints/baseline-r1/source.json']
paths += [BASE / 'Hepta-agent-edit-native' / path for path in (
    'tools/generate_hia_selfhost.py', 'tools/generate_hia_sha256_stream.py',
    'tools/generate_hia_sha256.py', 'tools/generate_hia_agent_edit_apply_graph.py',
    'tools/hia_agent_edit_source_views.py', 'hepta/hia_agent_worker.py',
    'hepta/hia_agent_store.py', 'hepta/hia_program_tools.py')]
frozen = {p: p.read_bytes() for p in paths}
assert sha256(frozen[COMPILER]).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
rows = []
for i, (path, raw) in enumerate(frozen.items()):
    target = OUT / 'source' / str(i) / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append(dict(path=str(path), copy=str(target), bytes=len(raw), sha256=sha256(raw).hexdigest()))
(OUT / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
summary = dict(status='INCOMPLETE', scope='WORKER_REQUEST_COMPONENT_DEVELOPMENT_NOT_COMPLETE_WORKER_OR_COLD',
               compile_cpu_seconds=10, compile_wall_seconds=20,
               compile_address_space_bytes=256 << 20)
started = time.monotonic_ns()
try:
    value = document()
    raw = render_assembly(value).encode()
    assert raw == frozen[SOURCE]
    assemble_program(raw)
    counts = dict(functions=len(value['functions']), blocks=sum(len(f['blocks']) for f in value['functions']),
                  max_blocks=max(len(f['blocks']) for f in value['functions']),
                  instructions=sum(len(b['ops']) for f in value['functions'] for b in f['blocks']),
                  max_block_params=max(len(b['params']) for f in value['functions'] for b in f['blocks']))
    assert counts['functions'] <= 128 and counts['blocks'] <= 1536 and counts['max_blocks'] <= 256
    assert counts['instructions'] <= 8192 and counts['max_block_params'] <= 16
    manifests = {}
    for role, source in (('request-driver', SOURCE), ('sha256-stream', HASH_SOURCE)):
        raw = frozen[source]
        image, receipt = compile_stage(OUT, role, COMPILER, raw)
        source_copy = OUT / (role + '.hiaasm')
        source_copy.write_bytes(raw)
        manifest = dict(schema='hepta.hia.worker-' + role + '-development.v1', scope='DEVELOPMENT_NOT_COLD',
                        source_path=str(source_copy), expected_source_path=str(source),
                        source_bytes=len(raw), source_sha256=sha256(raw).hexdigest(),
                        image_path=str(image), image_bytes=image.stat().st_size,
                        image_sha256=sha256(image.read_bytes()).hexdigest(),
                        compiler_sha256=sha256(frozen[COMPILER]).hexdigest(),
                        receipt_path=str(OUT / (role + '.receipt.json')))
        (OUT / (role + '.manifest.json')).write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
        manifests[role] = manifest
    summary.update(status='PASS', counts=counts, components=manifests)
    (OUT / 'bundle.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    summary['source_before_after_equal'] = all(p.read_bytes() == raw for p, raw in frozen.items())
    summary['wall_ns'] = time.monotonic_ns() - started
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert summary['source_before_after_equal']
