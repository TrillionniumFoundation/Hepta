"""Reachable canonical-body limit after a smaller admitted raw request.

The source uses 128 short finite exponent tokens. Their canonical binary64
spelling is longer, so all three raw requests remain below the existing 8 MiB
stdin/decode limit while their canonical digest bodies cross the late boundary.
"""
from contextlib import ExitStack
from hashlib import sha256
import gzip
import json
from pathlib import Path
import resource
import time
import traceback

from worker_request_harness import ActualRequest, ROOT, forbid_retained
from worker_decode_harness import Actual as ActualDecode
from hepta.hia_agent_store import decode_data, wire

OUT = Path('/dev/shm/hia-worker-request-boundaries-r1')
OUT.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))


class CompressedDecode(ActualDecode):
    def raw(self, value):
        key = sha256(value).hexdigest()
        path = self.rawdir / (key + '.bin.gz')
        if path.exists():
            assert gzip.decompress(path.read_bytes()) == value
        else:
            path.write_bytes(gzip.compress(value, compresslevel=1, mtime=0))
            assert gzip.decompress(path.read_bytes()) == value
        return dict(bytes=len(value), sha256=key, path=str(path), storage='lossless-gzip')


actual = ActualRequest(OUT / 'actual')
decoder = CompressedDecode(OUT / 'decode')
rows = []
summary = dict(status='INCOMPLETE')
started = time.monotonic_ns()


def fixture(target):
    body = dict(schema='hia-agent-worker-request-v1', tool='hia_describe',
                arguments={'numbers': [1e15] * 128, 'padding': ''},
                profile_sha256='d' * 64, catalog_sha256='c' * 64)
    overhead = len(wire(body))
    body['arguments']['padding'] = 'x' * (target - overhead)
    canonical = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    assert len(canonical) == target
    complete = dict(body, request_sha256=sha256(canonical).hexdigest())
    raw = json.dumps(complete, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    assert raw.count(b'1000000000000000.0') == 128
    raw = raw.replace(b'1000000000000000.0', b'1e15')
    assert len(raw) < 8 << 20
    parsed = decode_data(raw)
    assert parsed == complete
    expected_error = None
    try:
        expected = wire({k: v for k, v in parsed.items() if k != 'request_sha256'})
        assert expected == canonical
    except ValueError as exc:
        expected_error = dict(type=type(exc).__name__, text=str(exc))
    return raw, canonical, expected_error


try:
    for target in ((8 << 20) - 1, 8 << 20, (8 << 20) + 1):
        label = 'canonical-body-' + str(target)
        raw, canonical, expected_error = fixture(target)
        with ExitStack() as stack:
            forbid_retained(stack)
            decoded = decoder.run(raw, case=label)
            assert 'graph' in decoded
            result = actual.run(decoded['graph'], 'c' * 64, label=label, request=len(rows) + 1)
        if expected_error is None:
            assert result['event'][1] == 0 and result['digest'] == sha256(canonical).digest(), (label, result)
        else:
            assert result['event'][1] == 3 and result['event'][15] == 4
            assert result['error'] == expected_error['text'], (label, result, expected_error)
        row = dict(case=label, status='PASS', outcome='REJECT' if expected_error else 'ACCEPT',
                   raw=actual.save(raw), canonical_body=actual.save(canonical),
                   raw_below_8MiB=True, expected_error=expected_error, event=result['event'],
                   grows=result['grows'], services=result['services'], result=result['result'])
        rows.append(row)
        print(json.dumps({key: row[key] for key in ('case', 'status', 'outcome', 'services')}, sort_keys=True), flush=True)
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    decoder.close()
    actual.close()
    summary.update(request_entries=actual.entries, decode_entries=decoder.entries,
                   wall_ns=time.monotonic_ns() - started, source_before_after_equal=True,
                   runtime_cpu_seconds=90, runtime_address_bytes=1 << 30,
                   scope='ACTUAL_WORKER_REACHABLE_CANONICAL_BODY_8MiB_LATE_BOUNDARY', complete_worker=False)
    text = json.dumps(summary, indent=2, sort_keys=True) + '\n'
    (OUT / 'summary.json').write_text(text)
    (ROOT / 'development/request-boundaries-r1-summary.json').write_text(text)
    print(json.dumps({k: v for k, v in summary.items() if k not in ('results', 'completed')}, sort_keys=True), flush=True)
