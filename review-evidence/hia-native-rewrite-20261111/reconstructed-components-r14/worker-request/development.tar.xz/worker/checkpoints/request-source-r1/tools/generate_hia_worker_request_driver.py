"""Complete ordinary worker envelope ownership over an actual decoded Graph.

HIA performs every field, canonical-wire, digest, catalog and tool decision.
The fixed peers are the existing two Graph wire images and incremental SHA.
No service call or mutable Python object is accepted as admission evidence.
"""
from __future__ import annotations
import ast
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
sys.path.insert(0, str(BASE / 'Hepta-agent-edit-native'))
from hepta.hia_agent_assembly import render_assembly
from hepta.hia_program import verify_program
from tools.generate_hia_selfhost import compact_authoring_cfg, total_scalar_functions
from tools import generate_hia_agent_edit_apply_graph as graph
from tools.hia_agent_edit_source_views import CopyBuilder

CONSTANTS = dict(COMMAND=int.from_bytes(b'HIAWQC01', 'little'),
    STATE=int.from_bytes(b'HIAWQW01', 'little'), EVENT=int.from_bytes(b'HIAWQE01', 'little'),
    REPLY=int.from_bytes(b'HIAWQA01', 'little'), GRAPH=int.from_bytes(b'HIAGRF01', 'little'),
    WIRE_COMMAND=int.from_bytes(b'HIAGWC01', 'little'), WIRE_EVENT=int.from_bytes(b'HIAGWE01', 'little'),
    SHA_MAGIC=0x3153484132353648, BAD=0xfffffffd, MAX=(1 << 64) - 1)
LITERALS = ('schema', 'tool', 'arguments', 'request_sha256', 'profile_sha256',
            'catalog_sha256', 'hia-agent-worker-request-v1')
MESSAGES = {
    1: 'worker request has missing or unknown fields',
    2: 'unknown worker envelope',
    3: 'invalid worker digest field',
    5: 'worker request digest mismatch',
    6: 'worker request catalog differs from installed bytes',
    7: 'invalid worker tool name',
}
WIRE_ERRORS = (
    'invalid JSON output byte budget', 'JSON string exceeds byte budget before encoding',
    'unpaired Unicode surrogate in UTF-8 JSON', 'JSON input exceeds nesting depth before encoding',
    'JSON input exceeds node/byte budget', 'JSON container exceeds queued-node/byte budget',
    'cyclic JSON container', 'unsupported JSON object key', 'JSON key exceeds numeric byte budget',
    'nonfinite JSON object key', 'JSON key exceeds byte budget', 'JSON object key collision after JSON conversion',
    'JSON integer exceeds byte budget', 'non-JSON in-process value', 'invalid bounded JSON',
    'JSON encoding exceeds byte budget',
)
MESSAGES.update({101 + i: 'E_HIA_EDIT: ' + text for i, text in enumerate(WIRE_ERRORS)})

BODY = r'''
def worker_request(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 2048:
        return BAD
    if get(w, 8) == 2 or get(w, 8) == 3:
        return BAD
    if get(w, 8) == 0:
        if length(r) != 128 or word(r, 0) != COMMAND or word(r, 8) == 0 or word(r, 16) == 0:
            return refuse(w, 1)
        if word(r, 32) != length(s) or word(r, 40) != 0 or word(r, 48) != 0 or word(r, 56) != 0:
            return refuse(w, 2)
        if graph_shape(s, 0, length(s)) == 0:
            return refuse(w, 3)
        i = 0
        while i < 1024:
            if byte(w, i) != 0:
                return refuse(w, 4)
            i = i + 1
        i = 64
        while i < 128:
            value = byte(r, i)
            if (value < 48 or value > 57) and (value < 97 or value > 102):
                return refuse(w, 5)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(r, 8))
        put(w, 24, word(r, 16))
        put(w, 40, length(s))
        put(w, 48, word(r, 24))
        put(w, 72, word(s, 16))
        put(w, 88, word(s, 32))
        put(w, 104, word(s, 40))
        put(w, 200, word(s, 24))
        copy_bytes(w, r, 576, 64, 64)
        copy_bytes(w, r, 640, 0, 128)
        copy_bytes(w, s, 768, 0, 64)
        code = fields(s, w)
        if code != 0:
            return semantic(w, code, 0)
        put(w, 96, 1)
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or length(s) != get(w, 40):
            return refuse(w, 6)
        i = 0
        while i < 64:
            if byte(s, i) != byte(w, 768 + i):
                return refuse(w, 7)
            i = i + 1
    phase = get(w, 96)
    if phase == 1:
        if length(r) != 128:
            return refuse(w, 8)
        i = 0
        while i < 128:
            if byte(r, i) != byte(w, 640 + i):
                return refuse(w, 9)
            i = i + 1
        return body_graph(s, w)
    if phase == 20 or phase == 21:
        return wire_reply(s, r, w)
    if phase >= 30 and phase <= 32:
        return hash_reply(s, r, w)
    return refuse(w, 10)

def canonical_digest(s:readbuf, id_:u64) -> u64:
    if gkind(s, id_) != 4 or word(s, id_ * 64 + 16) != 64 or word(s, id_ * 64 + 48) != 64:
        return 0
    begin = word(s, id_ * 64 + 8)
    if begin > length(s) or 64 > length(s) - begin:
        return 0
    i = 0
    while i < 64:
        value = byte(s, begin + i)
        if (value < 48 or value > 57) and (value < 97 or value > 102):
            return 0
        i = i + 1
    return 1

def fields(s:readbuf, w:mutbuf) -> u64:
    root = get(w, 200)
    if gkind(s, root) != 6 or amount(s, root) != 6:
        return 1
    if field(s, root, L_schema) == 0 or field(s, root, L_tool) == 0 or field(s, root, L_arguments) == 0:
        return 1
    if field(s, root, L_request_sha256) == 0 or field(s, root, L_profile_sha256) == 0 or field(s, root, L_catalog_sha256) == 0:
        return 1
    if text_is(s, field(s, root, L_schema), L_hia_agent_worker_request_v1) == 0:
        return 2
    if canonical_digest(s, field(s, root, L_request_sha256)) == 0:
        return 3
    if canonical_digest(s, field(s, root, L_profile_sha256)) == 0:
        return 3
    if canonical_digest(s, field(s, root, L_catalog_sha256)) == 0:
        return 3
    put(w, 208, field(s, root, L_tool))
    put(w, 216, field(s, root, L_arguments))
    return 0

def projection(s:readbuf, w:mutbuf) -> u64:
    target = new_node(w, 6, 5, 0, 0)
    source = get(w, 200)
    i = 0
    j = 0
    while i < 6:
        key = element(s, source, i * 2)
        if text_is(s, key, L_request_sha256) == 0:
            pair(w, target, j, key, element(s, source, i * 2 + 1))
            j = j + 1
        i = i + 1
    if j != 5:
        put(w, 192, 11)
    put(w, 224, target)
    return 0

def body_graph(s:readbuf, w:mutbuf) -> u32:
    put(w, 160, 0)
    put(w, 168, 0)
    put(w, 176, 0)
    put(w, 184, 0)
    projection(s, w)
    if get(w, 192) != 0 or sizes(w) == 0:
        return refuse(w, 12)
    if get(w, 152) > length(w):
        return event(w, 1)
    fill_range(w, 1024, get(w, 144), 0)
    if clone_graph(s, w, 0, 0, 0, 0) == 0:
        return refuse(w, 13)
    put(w, 160, 1)
    put(w, 168, 0)
    put(w, 176, 0)
    put(w, 184, 0)
    projection(s, w)
    if get(w, 192) != 0 or get(w, 168) != get(w, 56) or get(w, 176) != get(w, 64) or get(w, 184) != get(w, 80):
        return refuse(w, 14)
    put(w, 1024, GRAPH)
    put(w, 1032, get(w, 16))
    put(w, 1040, get(w, 120))
    put(w, 1048, get(w, 224))
    put(w, 1056, get(w, 128))
    put(w, 1064, get(w, 136))
    put(w, 1072, get(w, 144))
    put(w, 512, WIRE_COMMAND)
    put(w, 520, get(w, 16))
    put(w, 528, get(w, 24))
    put(w, 536, get(w, 224))
    put(w, 544, 8388608)
    put(w, 552, 2)
    put(w, 560, get(w, 48))
    put(w, 568, 0)
    put(w, 96, 20)
    put(w, 232, 1)
    put(w, 640, 32768)
    put(w, 648, 0)
    put(w, 656, 0)
    put(w, 664, 1024)
    put(w, 672, get(w, 144))
    put(w, 680, 512)
    put(w, 688, 64)
    put(w, 720, 1)
    put(w, 152, 0)
    return event(w, 2)

def reply_shape(r:readbuf, w:mutbuf, sequence:u64) -> u64:
    if length(r) < 64 or word(r, 0) != REPLY or word(r, 8) != get(w, 16) or word(r, 16) != get(w, 24):
        return 0
    if word(r, 24) != sequence or word(r, 32) != get(w, 232):
        return 0
    if word(r, 48) != get(w, 648) or word(r, 56) != get(w, 640):
        return 0
    if word(r, 48) > length(r) - 64 or word(r, 56) != length(r) - 64 - word(r, 48):
        return 0
    return 1

def wire_reply(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    sequence = get(w, 32)
    if get(w, 96) == 21:
        sequence = get(w, 696)
    if reply_shape(r, w, sequence) == 0 or word(r, 40) != 128 or length(r) < 192:
        return refuse(w, 15)
    if word(r, 64) != WIRE_EVENT or word(r, 80) != get(w, 16) or word(r, 88) != get(w, 24):
        return refuse(w, 16)
    if word(r, 96) != get(w, 224) or word(r, 104) != 8388608 or word(r, 112) != 2 or word(r, 120) != get(w, 48):
        return refuse(w, 17)
    if word(r, 184) != 0:
        return refuse(w, 18)
    action = word(r, 72)
    if action == 3:
        code = word(r, 128)
        cause = word(r, 136)
        if code < 1 or code > 16 or word(r, 176) != 99:
            return refuse(w, 19)
        if (code == 15 and (cause < 1 or cause > 2)) or (code != 15 and cause != 0):
            return refuse(w, 20)
        if word(r, 152) != 0 or word(r, 160) != 0 or word(r, 168) != 0 or get(w, 96) != 20:
            return refuse(w, 21)
        return semantic(w, 4, code)
    if word(r, 128) != 0 or word(r, 136) != 0:
        return refuse(w, 22)
    if action == 1:
        if word(r, 144) <= get(w, 640) or get(w, 96) != 20:
            return refuse(w, 23)
        if word(r, 152) != 0 or word(r, 160) != 0 or word(r, 168) != 0:
            return refuse(w, 24)
        phase = word(r, 176)
        if get(w, 232) == 1:
            if phase != 1:
                return refuse(w, 25)
        elif get(w, 232) == 2:
            if phase < get(w, 720) or phase > 3:
                return refuse(w, 26)
        else:
            return refuse(w, 27)
        put(w, 720, phase)
        put(w, 640, word(r, 144))
        put(w, 656, 1)
        return event(w, 2)
    if action == 2:
        if get(w, 232) != 1 or get(w, 96) != 20 or word(r, 168) != 2 or word(r, 176) != 2:
            return refuse(w, 28)
        if word(r, 144) != 0 or word(r, 152) != 0 or word(r, 160) != 0:
            return refuse(w, 29)
        put(w, 232, 2)
        put(w, 720, 2)
        put(w, 656, 1)
        return event(w, 2)
    if action != 0 or get(w, 232) != 2 or word(r, 168) != 0 or word(r, 176) != 90 or word(r, 144) != 0:
        return refuse(w, 30)
    offset = word(r, 152)
    size = word(r, 160)
    if offset < 32768 or offset > get(w, 640) or size == 0 or size > 8388608 or size > get(w, 640) - offset:
        return refuse(w, 31)
    if get(w, 96) == 20:
        put(w, 696, sequence)
        put(w, 704, length(r))
        put(w, 712, offset)
        put(w, 112, size)
        copy_bytes(w, r, 832, 0, 192)
        put(w, 96, 21)
    else:
        if length(r) != get(w, 704) or offset != get(w, 712) or size != get(w, 112):
            return refuse(w, 32)
        i = 0
        while i < 192:
            if byte(r, i) != byte(w, 832 + i):
                return refuse(w, 33)
            i = i + 1
    put(w, 152, 1025 + size)
    if length(w) < get(w, 152):
        return event(w, 1)
    store(w, 1024, 1)
    copy_bytes(w, r, 1025, 64 + offset, size)
    put(w, 96, 30)
    put(w, 232, 3)
    put(w, 640, 1184)
    put(w, 648, 32)
    put(w, 656, 0)
    put(w, 664, 512)
    put(w, 672, 1)
    put(w, 680, 0)
    put(w, 688, 0)
    store(w, 512, 0)
    put(w, 152, 0)
    return event(w, 2)

def hash_reply(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if reply_shape(r, w, get(w, 32)) == 0 or length(r) != 1280 or get(w, 232) != 3:
        return refuse(w, 34)
    phase = get(w, 96)
    if word(r, 96 + 1176) != SHA_MAGIC:
        return refuse(w, 35)
    total = 0
    if phase != 30:
        total = get(w, 112)
    if word(r, 96 + 1088) != total or word(r, 96 + 1096) != (total & 63):
        return refuse(w, 36)
    if phase == 30 or phase == 31:
        if word(r, 40) != 0 or word(r, 96 + 1104) != 1:
            return refuse(w, 37)
        put(w, 656, 1)
        if phase == 30:
            put(w, 96, 31)
            put(w, 664, 1024)
            put(w, 672, get(w, 112) + 1)
        else:
            put(w, 96, 32)
            put(w, 664, 512)
            put(w, 672, 1)
            store(w, 512, 2)
        return event(w, 2)
    if phase != 32 or word(r, 40) != 32 or word(r, 96 + 1104) != 2:
        return refuse(w, 38)
    root = get(w, 200)
    request = field(s, root, L_request_sha256)
    at = word(s, request * 64 + 8)
    i = 0
    while i < 64:
        value = byte(r, 64 + (i >> 1))
        if (i & 1) == 0:
            value = value >> 4
        value = value & 15
        if byte(s, at + i) != value + choose(value < 10, 48, 87):
            return semantic(w, 5, 0)
        i = i + 1
    catalog = field(s, root, L_catalog_sha256)
    at = word(s, catalog * 64 + 8)
    i = 0
    while i < 64:
        if byte(s, at + i) != byte(w, 576 + i):
            return semantic(w, 6, 0)
        i = i + 1
    tool = get(w, 208)
    if gkind(s, tool) != 4 or word(s, tool * 64 + 48) > 128:
        return semantic(w, 7, 0)
    copy_bytes(w, r, 1024, 64, 32)
    put(w, 8, 2)
    put(w, 96, 90)
    return event(w, 0)

def semantic(w:mutbuf, code:u64, detail:u64) -> u32:
    put(w, 240, code)
    put(w, 248, detail)
    text = code
    if code == 4:
        text = 100 + detail
    size = message(w, text)
    if size == 0:
        return refuse(w, 39)
    put(w, 736, size)
    put(w, 8, 2)
    put(w, 96, 99)
    return event(w, 3)

def event(w:mutbuf, action:u64) -> u32:
    if get(w, 32) == MAX:
        put(w, 8, 3)
        return BAD
    put(w, 32, get(w, 32) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 96))
    put(w, 304, get(w, 152))
    put(w, 312, choose(action == 2, get(w, 232), 0))
    put(w, 320, choose(action == 2, get(w, 664), 0))
    put(w, 328, choose(action == 2, get(w, 672), 0))
    put(w, 336, choose(action == 2, get(w, 680), 0))
    put(w, 344, choose(action == 2, get(w, 688), 0))
    put(w, 352, choose(action == 2, get(w, 640), 0))
    put(w, 360, choose(action == 2, get(w, 648), 0))
    put(w, 368, choose(action == 2, get(w, 656), 0))
    put(w, 376, get(w, 240))
    put(w, 384, get(w, 248))
    put(w, 392, choose(action == 0 or action == 3, 1024, 0))
    put(w, 400, choose(action == 0, 32, choose(action == 3, get(w, 736), 0)))
    put(w, 408, get(w, 200))
    put(w, 416, get(w, 208))
    put(w, 424, get(w, 216))
    put(w, 432, get(w, 224))
    put(w, 440, get(w, 144))
    put(w, 448, get(w, 112))
    put(w, 456, get(w, 192))
    i = 464
    while i < 512:
        put(w, i, 0)
        i = i + 8
    return 512

def refuse(w:mutbuf, reason:u64) -> u32:
    put(w, 8, 3)
    put(w, 192, reason)
    event(w, 4)
    return BAD
'''


def message_node():
    lines = ['def message(w:mutbuf, code:u64) -> u64:']
    for code, text in MESSAGES.items():
        raw = text.encode('utf-8')
        assert len(raw) < 512
        lines.append(f'    if code == {code}:')
        for begin in range(0, len(raw), 8):
            part = raw[begin:begin + 8].ljust(8, b'\0')
            lines.append(f'        put(w, {1024 + begin}, {int.from_bytes(part, "little")})')
        lines.append(f'        return {len(raw)}')
    lines.append('    return 0')
    return ast.parse('\n'.join(lines)).body[0]


def source_program():
    labels = {}
    for value in LITERALS:
        raw = value.encode('ascii')
        assert len(raw) <= 32
        labels['L_' + value.replace('-', '_').replace('.', '_')] = [
            len(raw), *(int.from_bytes(raw[i:i + 8], 'little') for i in (0, 8, 16, 24))]

    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id in CONSTANTS:
                return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node)
            return node

        def visit_Call(self, node):
            node = self.generic_visit(node)
            args = []
            for arg in node.args:
                if isinstance(arg, ast.Name) and arg.id in labels:
                    args.extend(ast.Constant(value) for value in labels[arg.id])
                else:
                    args.append(arg)
            node.args = args
            return node

    previous = {node.name: node for node in ast.parse(graph.source_program()).body}
    keep = ('gkind', 'amount', 'element', 'text_is', 'field', 'sizes', 'new_node',
            'set_edge', 'pair', 'graph_shape', 'clone_graph', 'clone_container',
            'clone_scalar', 'word', 'get', 'put')
    nodes = [Expand().visit(node) for node in ast.parse(BODY).body]
    nodes += [message_node()] + [previous[name] for name in keep]
    return ast.unparse(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i + 1) for i, node in enumerate(nodes)}
    assert len(names) == len(nodes)
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'}, {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'],
        'entry': 'b0', 'blocks': [{'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}],
             'attrs': {'function': names['worker_request']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}],
            'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    result = compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'agent_worker_request_driver',
                                    'functions': functions})
    fs = result['functions']
    limits = (len(fs), sum(len(f['blocks']) for f in fs), sum(len(b['ops']) for f in fs for b in f['blocks']),
              max(len(f['blocks']) for f in fs), max(len(b['params']) for f in fs for b in f['blocks']))
    if any(actual > maximum for actual, maximum in zip(limits, (128, 1536, 8192, 256, 16))):
        raise ValueError({'original_compiler_limits_exceeded': limits})
    verify_program(result)
    return result


if __name__ == '__main__':
    value = document()
    raw = render_assembly(value).encode()
    target = ROOT / 'examples/hia_bootstrap/agent_worker_request_driver.hiaasm'
    target.write_bytes(raw)
    print(json.dumps(dict(path=str(target), bytes=len(raw), sha256=sha256(raw).hexdigest(),
        functions=len(value['functions']), blocks=sum(len(f['blocks']) for f in value['functions']),
        instructions=sum(len(b['ops']) for f in value['functions'] for b in f['blocks']),
        max_function_blocks=max(len(f['blocks']) for f in value['functions']),
        max_block_parameters=max(len(b['params']) for f in value['functions'] for b in f['blocks'])), sort_keys=True))
