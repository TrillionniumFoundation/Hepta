"""Mechanical three-image worker decoder, using immutable actual peer replies."""
from contextlib import ExitStack
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
RENDER = BASE / 'native-agent-edit-render-next'
spec = importlib.util.spec_from_file_location('worker_decode_mechanical_predecessor',
    RENDER / 'development/edit_decode_harness_r2.py')
mechanics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mechanics)
mechanics.COMMAND = int.from_bytes(b'HIAWDC01', 'little')
mechanics.EVENT = int.from_bytes(b'HIAWDE01', 'little')
mechanics.REPLY = int.from_bytes(b'HIAWDR01', 'little')
from hepta.hia_agent_store import decode_data as reference_decode


class Actual(mechanics.Actual):
    def __init__(self, out):
        self.out = Path(out)
        self.pins = {}
        self.entries = dict(controller=0, decoder=0, graph=0)

        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            if path in self.pins:
                assert self.pins[path] == raw
            self.pins[path] = raw
            return raw

        controller = json.loads(read(ROOT / 'development/decode-compile-r1/agent-worker-decode.manifest.json'))
        assert controller['schema'] == 'hepta.hia.worker-decode-development.v1'
        peers = json.loads(read(RENDER / 'development/arena-graph-compile-r2/bundle.json'))
        assert peers['status'] == 'PASS' and peers['scope'] == 'SOURCE_BOUND_ARENA_GRAPH_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD'
        components = dict(controller=controller, decoder=peers['components']['decoder'], graph=peers['components']['bridge'])
        current = dict(controller=ROOT / 'examples/hia_bootstrap/agent_worker_decode.hiaasm',
                       decoder=BASE / 'Hepta-agent-edit-native/examples/hia_bootstrap/agent_data_json.hiaasm',
                       graph=RENDER / 'examples/hia_bootstrap/arena_graph.hiaasm')
        images = {}
        for role, item in components.items():
            source = read(item['source_path'])
            image = read(item['image_path'])
            assert read(current[role]) == source and sha256(source).hexdigest() == item['source_sha256']
            assert sha256(image).hexdigest() == item['image_sha256']
            assert item['compiler_sha256'] == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
            receipt_path = item.get('receipt_path') or str(item['image_path']).replace('.image.bin', '.receipt.json')
            receipt = json.loads(read(receipt_path))
            assert receipt['input_sha256'] == item['source_sha256']
            assert receipt['produced_sha256'] == item['image_sha256']
            assert receipt['image_sha256'] == item['compiler_sha256']
            images[role] = (image, item['image_sha256'])
        read(Path(__file__))
        read(RENDER / 'development/edit_decode_harness_r2.py')
        read(RENDER / 'development/arena_graph_harness_r2.py')
        read(ROOT / 'tools/generate_hia_worker_decode.py')
        self.readback()
        self.out.mkdir(parents=True, exist_ok=False)
        self.images = {role: mechanics.NativeHiaJsonImage(*row) for role, row in images.items()}
        self.rawdir = self.out / 'raw'
        self.rawdir.mkdir()
        self.log = (self.out / 'entries.jsonl').open('w')
        self.pinfile('source-before.json')

    def run(self, raw, *, digits=4300, case='case', initial=512):
        with ExitStack() as stack:
            def disabled(*args, **kwargs):
                raise AssertionError('retained worker semantic owner invoked')
            stack.enter_context(patch('hepta.hia_agent_store.decode_data', new=disabled))
            stack.enter_context(patch('hepta.hia_agent_worker.main', new=disabled))
            return super().run(raw, 9, digits=digits, case=case, initial=initial)

    def check(self, raw, case='case', digits=4300):
        assert type(raw) is bytes
        before = sys.get_int_max_str_digits()
        value = error = error_class = error_code = None
        try:
            sys.set_int_max_str_digits(digits)
            with patch.dict(os.environ, {}, clear=True):
                try:
                    value = reference_decode(raw)
                except (ValueError, OverflowError, RecursionError) as exc:
                    error = str(exc)
                    error_class = type(exc).__name__
                    error_code = getattr(exc, 'code', None)
        finally:
            sys.set_int_max_str_digits(before)
        result = self.run(raw, digits=digits, case=case)
        if error is not None:
            assert result.get('error') == error, (case, result, error_class, error)
            code = result['event'][13]
            actual_class = ('UnicodeDecodeError' if code == 3 else 'OverflowError' if code == 4
                            else 'AgentRejected' if code in (2, 9) else 'ValueError')
            assert actual_class == error_class, (case, actual_class, error_class)
            assert error_code == ('E_HIA_JSON' if code in (2, 9) else None)
        else:
            assert 'graph' in result, (case, result)
            expected = mechanics.ag.gw.capture(value, lease=mechanics.LEASE)
            assert mechanics.ag.shape(result['graph']) == mechanics.ag.shape(expected), case
            self.raw(expected)
        return dict(case=case, status='PASS', outcome='REJECT' if error is not None else 'ACCEPT',
                    raw=self.raw(raw), error=error, original_exception_class=error_class,
                    original_exception_code=error_code, grows=result['grows'], services=result['services'],
                    event=result['event'])

    def close(self):
        super().close()
        for image in self.images.values():
            image._entry = None
            image._mapping.close()
