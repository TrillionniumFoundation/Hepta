"""Complete ordinary worker bytes decode_data owner; no hosted value bridge.

The existing public integer decoder controller is composed at authoring time.
This independent image preserves the worker's different UTF-8-before-size
order, ordinary finite binary64 profile and complete exception text.
"""
from __future__ import annotations

import ast
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
HOST = BASE / 'Hepta-agent-edit-native'
RENDER = BASE / 'native-agent-edit-render-next'
sys.path.insert(0, str(HOST))
import tools
tools.__path__ = [str(RENDER / 'tools'), *list(tools.__path__)]
from hepta.hia_agent_assembly import render_assembly
from hepta.hia_program import verify_program
from tools.generate_hia_selfhost import compact_authoring_cfg, total_scalar_functions
from tools.hia_agent_edit_source_views import CopyBuilder
from tools.generate_hia_json_preflight import SOURCE as PREFLIGHT

spec = importlib.util.spec_from_file_location('worker_decode_integer_predecessor',
    RENDER / 'tools/generate_hia_edit_decode.py')
predecessor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(predecessor)

CONSTANTS = dict(predecessor.CONSTANTS)
CONSTANTS.update(COMMAND=int.from_bytes(b'HIAWDC01', 'little'),
                 EVENT=int.from_bytes(b'HIAWDE01', 'little'),
                 REPLY=int.from_bytes(b'HIAWDR01', 'little'),
                 STATE=int.from_bytes(b'HIAWDW01', 'little'),
                 S_NORM_BASE=432, S_NORM_BYTES=440, S_UTF_START=448,
                 S_UTF_END=456, S_UTF_REASON=464, S_SCAN_FLOAT=472)
MESSAGES = {
    2: 'JSON data exceeds 8 MiB',
    4: 'HIA JSON exceeds node/depth budget before decoding',
    5: 'HIA JSON preflight: duplicate decoded object key',
    6: 'Exceeds the limit (',
    7: ' digits) for integer string conversion: value has ',
    8: ' digits; use sys.set_int_max_str_digits() to increase the limit',
    9: 'nonfinite JSON number',
    200: "'utf-8' codec can't decode byte 0x",
    201: "'utf-8' codec can't decode bytes in position ",
    202: ' in position ',
    203: ': ',
    204: 'invalid start byte',
    205: 'invalid continuation byte',
    206: 'unexpected end of data',
}
MESSAGES.update({100 + code: 'HIA JSON preflight: ' + text
                 for code, text in predecessor.REASONS.items()})

EXTRA = r'''
def worker_utf8(s:readbuf, w:mutbuf) -> u64:
    at = 0
    while at < length(s):
        first = byte(s, at)
        if first < 128:
            at = at + 1
        else:
            width = 0
            low = 128
            high = 191
            if first >= 194 and first <= 223:
                width = 2
            elif first >= 224 and first <= 239:
                width = 3
                if first == 224:
                    low = 160
                if first == 237:
                    high = 159
            elif first >= 240 and first <= 244:
                width = 4
                if first == 240:
                    low = 144
                if first == 244:
                    high = 143
            else:
                put(w, S_UTF_START, at)
                put(w, S_UTF_END, at + 1)
                put(w, S_UTF_REASON, 204)
                return 0
            i = 1
            while i < width:
                if i >= length(s) - at:
                    put(w, S_UTF_START, at)
                    put(w, S_UTF_END, length(s))
                    put(w, S_UTF_REASON, 206)
                    return 0
                part = byte(s, at + i)
                if part < low or part > high:
                    put(w, S_UTF_START, at)
                    put(w, S_UTF_END, at + i)
                    put(w, S_UTF_REASON, 205)
                    return 0
                low = 128
                high = 191
                i = i + 1
            at = at + width
    return 1

def utf_message(s:readbuf, w:mutbuf) -> u64:
    start = get(w, S_UTF_START)
    end = get(w, S_UTF_END)
    at = 0
    if end - start == 1:
        at = copy_message(w, 200, 1024)
        value = byte(s, start)
        hi = value >> 4
        lo = value & 15
        store(w, at, hi + choose(hi < 10, 48, 87))
        store(w, at + 1, lo + choose(lo < 10, 48, 87))
        at = copy_message(w, 202, at + 2)
        at = decimal(w, start, at)
    else:
        at = copy_message(w, 201, 1024)
        at = decimal(w, start, at)
        store(w, at, 45)
        at = decimal(w, end - 1, at + 1)
    at = copy_message(w, 203, at)
    return copy_message(w, get(w, S_UTF_REASON), at)

def number_end(s:readbuf, w:mutbuf, at:u64) -> u64:
    put(w, S_SCAN_FLOAT, 0)
    if byte(s, at) == 45:
        at = at + 1
    if at == length(s) or byte(s, at) < 48 or byte(s, at) > 57:
        return MAX
    if byte(s, at) == 48:
        at = at + 1
    else:
        while at < length(s) and byte(s, at) >= 48 and byte(s, at) <= 57:
            at = at + 1
    if at < length(s) and byte(s, at) == 46:
        next_ = at + 1
        if next_ < length(s) and byte(s, next_) >= 48 and byte(s, next_) <= 57:
            put(w, S_SCAN_FLOAT, 1)
            at = next_ + 1
            while at < length(s) and byte(s, at) >= 48 and byte(s, at) <= 57:
                at = at + 1
    if at < length(s) and (byte(s, at) == 69 or byte(s, at) == 101):
        next_ = at + 1
        if next_ < length(s) and (byte(s, next_) == 43 or byte(s, next_) == 45):
            next_ = next_ + 1
        if next_ < length(s) and byte(s, next_) >= 48 and byte(s, next_) <= 57:
            put(w, S_SCAN_FLOAT, 1)
            at = next_ + 1
            while at < length(s) and byte(s, at) >= 48 and byte(s, at) <= 57:
                at = at + 1
    return at

def normalized(s:readbuf, w:mutbuf) -> u64:
    at = 0
    used = 0
    base = get(w, S_NORM_BASE)
    while at < length(s):
        ch = byte(s, at)
        if ch == 34:
            store(w, base + used, ch)
            used = used + 1
            at = at + 1
            active = True
            while active and at < length(s):
                ch = byte(s, at)
                store(w, base + used, ch)
                used = used + 1
                at = at + 1
                if ch == 34:
                    active = False
                elif ch == 92 and at < length(s):
                    store(w, base + used, byte(s, at))
                    used = used + 1
                    at = at + 1
        elif ch == 45 or (ch >= 48 and ch <= 57):
            end = number_end(s, w, at)
            if end == MAX:
                store(w, base + used, ch)
                used = used + 1
                at = at + 1
            elif get(w, S_SCAN_FLOAT) != 0:
                store(w, base + used, 48)
                used = used + 1
                at = end
            else:
                copy_bytes(w, s, base + used, at, end - at)
                used = used + end - at
                at = end
        else:
            store(w, base + used, ch)
            used = used + 1
            at = at + 1
    put(w, S_NORM_BYTES, used)
    return used
'''


def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def controller_nodes():
    body = predecessor.BODY
    body = replace_once(body, 'word(c, 24) > 9', 'word(c, 24) != 9')
    body = replace_once(body, '''        kind = get(w, S_KIND)
        if kind != 4 and kind != 9:
            return semantic(w, 1, 0)
        if kind == 4 and utf_count(s, 0, length(s)) == MAX:
            return semantic(w, 3, 0)
        if length(s) > 8388608:
            return semantic(w, 2, 0)
        if kind == 9 and utf_count(s, 0, length(s)) == MAX:
            return semantic(w, 3, 0)''', '''        if worker_utf8(s, w) == 0:
            return semantic(s, w, 3, 0)
        if length(s) > 8388608:
            return semantic(s, w, 2, 0)''')
    body = replace_once(body, '''        need = KEY_BASE + slots * 8
        if length(w) < need:
            put(w, S_NEED, need)
            return publish(w, 1)
        put(w, PF_BASE + 48, 262144)''', '''        put(w, S_NORM_BASE, KEY_BASE + slots * 8)
        need = get(w, S_NORM_BASE) + length(s)
        if length(w) < need:
            put(w, S_NEED, need)
            return publish(w, 1)
        normalized(s, w)
        put(w, PF_BASE + 48, 262144)''')
    body = replace_once(body, '''            if word(c, 128) != 1 or word(c, 176) != 99 or word(c, 112) != 0:
                return invalid(w, 20)
            if word(c, 136) >= get(w, S_COUNT) or word(c, 144) > length(s):
                return invalid(w, 36)
            if get(w, S_DIGITS) == 0 or word(c, 144) <= get(w, S_DIGITS):
                return invalid(w, 21)
            return semantic(w, 6, word(c, 144))''', '''            if word(c, 176) != 99 or word(c, 112) != 0:
                return invalid(w, 20)
            if word(c, 136) >= get(w, S_COUNT) or word(c, 144) > length(s):
                return invalid(w, 36)
            if word(c, 128) == 2:
                if word(c, 144) != 0:
                    return invalid(w, 39)
                return semantic(s, w, 9, 0)
            if word(c, 128) != 1 or get(w, S_DIGITS) == 0 or word(c, 144) <= get(w, S_DIGITS):
                return invalid(w, 21)
            return semantic(s, w, 6, word(c, 144))''')
    body = body.replace('return semantic(w,', 'return semantic(s, w,')
    body = replace_once(body, '''def semantic(w:mutbuf, code:u64, detail:u64) -> u32:
    at = copy_message(w, code, 1024)''', '''def semantic(s:readbuf, w:mutbuf, code:u64, detail:u64) -> u32:
    at = 0
    if code == 3:
        at = utf_message(s, w)
    else:
        at = copy_message(w, code, 1024)''')
    return ast.parse(body + EXTRA).body


def preflight_nodes():
    nodes = ast.parse(PREFLIGHT).body
    names = {node.name for node in nodes}
    missing_work = {node.name for node in nodes
                    if all(arg.arg != 'w' for arg in node.args.args)}

    class Relocate(ast.NodeTransformer):
        def visit_FunctionDef(self, node):
            old = node.name
            if old in ('preflight', 'insert_key'):
                node.args.args = [arg for arg in node.args.args if arg.arg != 'o']
            if old in missing_work:
                node.args.args.append(ast.arg(arg='w', annotation=ast.Name(id='mutbuf', ctx=ast.Load())))
            if old == 'preflight':
                node.returns = ast.Name(id='u64', ctx=ast.Load())
            node = self.generic_visit(node)
            node.name = 'pf_' + old
            return node

        def visit_Call(self, node):
            name = node.func.id if isinstance(node.func, ast.Name) else None
            if name == 'byte' and isinstance(node.args[0], ast.Name) and node.args[0].id == 's':
                index = self.visit(node.args[1])
                return ast.Call(func=ast.Name(id='byte', ctx=ast.Load()), args=[
                    ast.Name(id='w', ctx=ast.Load()),
                    ast.BinOp(left=ast.Call(func=ast.Name(id='get', ctx=ast.Load()),
                        args=[ast.Name(id='w', ctx=ast.Load()), ast.Name(id='S_NORM_BASE', ctx=ast.Load())], keywords=[]),
                        op=ast.Add(), right=index)], keywords=[])
            if name == 'length' and isinstance(node.args[0], ast.Name) and node.args[0].id == 's':
                return ast.Call(func=ast.Name(id='get', ctx=ast.Load()), args=[
                    ast.Name(id='w', ctx=ast.Load()), ast.Name(id='S_NORM_BYTES', ctx=ast.Load())], keywords=[])
            if name in ('get', 'put'):
                owner = node.args[0].id
                assert owner in ('w', 'o')
                node.args[0] = ast.Name(id='w', ctx=ast.Load())
                node.args[1] = ast.BinOp(left=ast.Name(id='KEY_BASE' if owner == 'o' else 'PF_BASE', ctx=ast.Load()),
                                       op=ast.Add(), right=node.args[1])
                return self.generic_visit(node)
            if name == 'length' and isinstance(node.args[0], ast.Name) and node.args[0].id in ('w', 'o'):
                owner = node.args[0].id
                return ast.BinOp(left=ast.Call(func=ast.Name(id='length', ctx=ast.Load()),
                    args=[ast.Name(id='w', ctx=ast.Load())], keywords=[]), op=ast.Sub(),
                    right=ast.Name(id='KEY_BASE' if owner == 'o' else 'PF_BASE', ctx=ast.Load()))
            if name in ('preflight', 'insert_key'):
                node.args.pop(1)
            if name in missing_work:
                node.args.append(ast.Name(id='w', ctx=ast.Load()))
            node = self.generic_visit(node)
            if name in names and name not in ('get', 'put'):
                node.func.id = 'pf_' + name
            return node

    return [Relocate().visit(node) for node in nodes if node.name not in ('get', 'put')]


def text_nodes():
    lines = ['def initialize_text(w:mutbuf) -> u64:']
    for i in range(20):
        lines.append(f'    put(w, {768 + i * 8}, {10 ** i})')
    offset = 4096
    for index, (code, text) in enumerate(MESSAGES.items()):
        raw = text.encode('ascii')
        lines.extend([f'    put(w, {2048 + 16 * index}, {offset})',
                      f'    put(w, {2056 + 16 * index}, {len(raw)})'])
        for begin in range(0, len(raw), 8):
            part = raw[begin:begin + 8].ljust(8, b'\0')
            lines.append(f'    put(w, {offset + begin}, {int.from_bytes(part, "little")})')
        offset += (len(raw) + 7) // 8 * 8
    assert offset < 8192
    lines.append('    return 0')
    lines.append('def message_index(code:u64) -> u64:')
    for index, code in enumerate(MESSAGES):
        lines.extend([f'    if code == {code}:', f'        return {index}'])
    lines.append('    return 0')
    return ast.parse('\n'.join(lines)).body


def source_program():
    nodes = controller_nodes() + preflight_nodes() + text_nodes()

    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id in CONSTANTS:
                return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node)
            return node

    return ast.unparse(ast.fix_missing_locations(ast.Module(
        body=[Expand().visit(node) for node in nodes], type_ignores=[]))) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i + 1) for i, node in enumerate(nodes)}
    assert len(names) == len(nodes)
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'},
              {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'],
                  'effects': ['read', 'write', 'trap'], 'entry': 'b0', 'blocks': [
        {'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}],
             'attrs': {'function': names['decode']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}],
         'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    result = compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'agent_worker_decode',
                                    'functions': functions})
    fs = result['functions']
    limits = (len(fs), sum(len(f['blocks']) for f in fs),
              sum(len(b['ops']) for f in fs for b in f['blocks']),
              max(len(f['blocks']) for f in fs), max(len(b['params']) for f in fs for b in f['blocks']))
    if any(actual > maximum for actual, maximum in zip(limits, (128, 1536, 8192, 256, 16))):
        raise ValueError({'original_compiler_limits_exceeded': limits})
    verify_program(result)
    return result


if __name__ == '__main__':
    value = document()
    raw = render_assembly(value).encode()
    target = ROOT / 'examples/hia_bootstrap/agent_worker_decode.hiaasm'
    target.write_bytes(raw)
    print(json.dumps(dict(path=str(target), bytes=len(raw), sha256=sha256(raw).hexdigest(),
        functions=len(value['functions']), blocks=sum(len(f['blocks']) for f in value['functions']),
        instructions=sum(len(b['ops']) for f in value['functions'] for b in f['blocks']),
        max_function_blocks=max(len(f['blocks']) for f in value['functions']),
        max_block_parameters=max(len(b['params']) for f in value['functions'] for b in f['blocks'])), sort_keys=True))
