"""Preserve original development observations, including inaccessible test dirs.

Completed test-owned paths may deliberately lack owner read/search. Record
their original modes, temporarily enable only the access needed to read them,
and restore every mode in finally. Never follow a symlink or touch production.
"""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json,os,stat,tarfile,time

ROOT=Path('/workspace/scratch/9acdfa9f5639')
OUT=ROOT/'hia-agent-state-integration-development'
ARCHIVE=OUT/'native-stage3-development-originals.tar.xz'
roots=[('development-r1',Path('/dev/shm/hia-v65-state-development-r1')),
       ('journal-recheck1',Path('/dev/shm/hia-v65-journal-recheck1')),
       ('reports/development-r1',OUT/'native-stage3-development-attempt1'),
       ('reports/journal-recheck1',OUT/'journal-stage3-recheck1')]
files={};links={};directories={};adjustments=[]
uid=os.geteuid()
def digest(b):return sha256(b).hexdigest()
def capture(t,p,name):
    st=p.lstat();mode=stat.S_IMODE(st.st_mode)
    assert st.st_uid==uid,('non-owned test path',str(p),st.st_uid)
    if stat.S_ISLNK(st.st_mode):
        target=os.readlink(p);links[name]={'target':target,'mode':mode}
        ti=tarfile.TarInfo(name);ti.type=tarfile.SYMTYPE;ti.linkname=target;ti.mode=mode;t.addfile(ti)
    elif stat.S_ISDIR(st.st_mode):
        directories[name]=mode
        ti=tarfile.TarInfo(name);ti.type=tarfile.DIRTYPE;ti.mode=mode;t.addfile(ti)
        adjusted=(mode&0o500)!=0o500
        try:
            if adjusted:p.chmod(mode|0o500);adjustments.append({'path':str(p),'original_mode':mode,'temporary_mode':mode|0o500})
            entries=sorted(os.scandir(p),key=lambda e:e.name)
            for entry in entries:capture(t,Path(entry.path),name+'/'+entry.name)
        finally:
            if adjusted:p.chmod(mode)
        assert stat.S_IMODE(p.lstat().st_mode)==mode
    elif stat.S_ISREG(st.st_mode):
        adjusted=not mode&0o400
        try:
            if adjusted:p.chmod(mode|0o400);adjustments.append({'path':str(p),'original_mode':mode,'temporary_mode':mode|0o400})
            data=p.read_bytes();after=p.stat()
            assert (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
            assert len(data)==st.st_size
            files[name]={'bytes':len(data),'sha256':digest(data),'mode':mode,'original_nlink':st.st_nlink}
            ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=mode;t.addfile(ti,BytesIO(data))
        finally:
            if adjusted:p.chmod(mode)
        assert stat.S_IMODE(p.lstat().st_mode)==mode
    else:raise AssertionError(('unexpected raw file type',str(p),st.st_mode))

with tarfile.open(ARCHIVE,'x:xz',preset=3) as t:
    for prefix,p in roots:capture(t,p,prefix)
    for name in ('development-prerequisites.json','native-stage3-development-attempt1.stdout.log',
                 'native-stage3-development-attempt1.stderr.log','journal-stage3-recheck1.stdout.log',
                 'journal-stage3-recheck1.stderr.log','run_native_stage3_development.py','recheck_journal_stage3.py'):
        capture(t,OUT/name,'reports/'+name)
    manifest={'schema':'hepta.hia.state-native-originals.v1','files':files,'symlinks':links,
              'directories':directories,'temporary_test_owned_access_changes':adjustments,
              'all_original_modes_restored':True,'source_revision':'draft-stage3-source.json',
              'original_58_test_run_passed':False,'targeted_three_setup_errors_recheck_passed':True,
              'matching_source_cold_passed':False,'production_paths_access_changed':False}
    raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    ti=tarfile.TarInfo('ORIGINALS_CUSTODY.json');ti.size=len(raw);ti.mode=0o644;t.addfile(ti,BytesIO(raw))
with tarfile.open(ARCHIVE,'r:xz') as t:
    assert len(t.getmembers())==len(files)+len(links)+len(directories)+1
    for m in t:
        if m.name=='ORIGINALS_CUSTODY.json':assert t.extractfile(m).read()==raw
        elif m.name in files:
            data=t.extractfile(m).read();record=files[m.name]
            assert len(data)==record['bytes'] and digest(data)==record['sha256'] and m.mode==record['mode']
        elif m.name in links:assert m.issym() and m.linkname==links[m.name]['target'] and m.mode==links[m.name]['mode']
        else:assert m.isdir() and m.mode==directories[m.name]
receipt={'schema':'hepta.hia.state-native-originals-seal.v1','archive':str(ARCHIVE),
         'bytes':ARCHIVE.stat().st_size,'sha256':digest(ARCHIVE.read_bytes()),'files':len(files),
         'raw_bytes':sum(v['bytes'] for v in files.values()),'symlinks':len(links),
         'directories':len(directories),'temporary_test_owned_access_changes':adjustments,
         'all_original_modes_restored':True,'all_members_read_back':True,
         'original_58_test_run_passed':False,'targeted_three_recheck_passed':True,
         'matching_source_cold_passed':False}
(OUT/'native-stage3-development-originals-custody.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='temporary_test_owned_access_changes'}),flush=True)
