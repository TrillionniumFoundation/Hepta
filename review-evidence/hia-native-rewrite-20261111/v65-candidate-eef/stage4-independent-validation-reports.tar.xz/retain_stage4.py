"""Read every frozen stage4 member and retain the original validation package."""
from pathlib import Path
from hashlib import sha256
import io, json, os, subprocess, tarfile

ROOT=Path('/workspace/scratch/9acdfa9f5639')
OUT=ROOT/'hia-v65-candidate-checkpoint'
VALIDATION=ROOT/'hia-agent-state-stage4-independent-validation'
def sha(b):return sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
handoff_raw=(VALIDATION/'FINAL_HANDOFF.json').read_bytes()
assert sha(handoff_raw)=='8d406324482cee3531107710692ac645af10d684d8b97f94d2d780abfd095e32'
handoff=json.loads(handoff_raw)
assert handoff['source_manifest_sha256']=='ed0520de19c884648d1ccd5ba2355bc44e5c51f20590d50994089f78df1bcbbf'
assert handoff['source_edits']==[] and handoff['source_preserved']
members=total=0
for row in handoff['raw_archives']:
    p=Path(row['archive']);b=p.read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256']
    custody=json.loads(p.with_name(p.name[:-7]+'-custody.json').read_bytes())
    with tarfile.open(p,'r:xz') as t:
        names=t.getnames();assert len(names)==len(set(names))==len(custody['files'])==row['members']
        for m in t:
            assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            e=custody['files'][m.name];assert m.mode==e['mode']
            if e['type']=='file':
                assert m.isfile();data=t.extractfile(m).read()
                assert len(data)==e['bytes'] and sha(data)==e['sha256'];total+=len(data)
            elif e['type']=='symlink':assert m.issym() and m.linkname==e['target']
            else:assert e['type']=='directory' and m.isdir()
        members+=len(names)
assert members==2569 and total==93259052
frozen=json.loads((ROOT/'hia-agent-state-integration-development/draft-stage4-source.json').read_bytes())
summary=json.loads((VALIDATION/'attempt1/summary.json').read_bytes())
assert len(frozen['source_closure'])==636 and summary['passed'] and summary['source_preserved']
for when in ('before','after'):
    assert json.loads((VALIDATION/f'attempt1/source-{when}.json').read_bytes())==frozen['source_closure']
assert {k:v['tests_run'] for k,v in summary['groups'].items()}=={'installed':2,'observer':18}
for group in summary['groups'].values():
    assert group['passed'] and group['chosen_test_ids']==group['executed_test_ids']
    assert not any(group[k] for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
result={'schema':'hepta.hia.stage4-root-raw-readback.v1','source_manifest_sha256':handoff['source_manifest_sha256'],'source_files':636,'archives':len(handoff['raw_archives']),'members':members,'raw_bytes':total,'every_member_type_bytes_sha_mode_and_link_checked':True,'observer_tests':18,'installed_tests':2,'unchanged_test_ids_and_zero_all_five_anomalies':True,'development_only':True,'matching_current_cold_passed':False,'whole_stack_closed':False}
dump(OUT/'stage4-root-readback.json',result)
paths=[Path(r['archive']) for r in handoff['raw_archives']]+[ROOT/'hia-stage4-independent-validation-metadata.tar.xz',VALIDATION/'FINAL_HANDOFF.json',OUT/'stage4-root-readback.json']
assert sha(paths[6].read_bytes())=='48aa6a9736b679218c6b14f4d9fc1c3ae752c65e9a212b9c4d4647d64df30ff2'
inventory={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode&0o7777} for p in paths}
manifest=(json.dumps({'schema':'hepta.hia.stage4-original-validation-container.v1','files':inventory},indent=2,sort_keys=True)+'\n').encode()
destination=ROOT/'HIA-v65-stage4-independent-validation-20261111.tar'
with tarfile.open(destination,'x:') as t:
    for p in paths:
        data=p.read_bytes();e=inventory[p.name];assert sha(data)==e['sha256']
        ti=tarfile.TarInfo(p.name);ti.size=len(data);ti.mode=e['mode'];t.addfile(ti,io.BytesIO(data))
    ti=tarfile.TarInfo('CONTAINER_CUSTODY.json');ti.size=len(manifest);ti.mode=0o644;t.addfile(ti,io.BytesIO(manifest))
with tarfile.open(destination,'r:') as t:
    assert len(t.getmembers())==len(paths)+1
    for m in t:
        data=t.extractfile(m).read()
        if m.name=='CONTAINER_CUSTODY.json':assert data==manifest
        else:
            e=inventory[m.name];assert len(data)==e['bytes'] and sha(data)==e['sha256'] and m.mode==e['mode']
container={'schema':'hepta.hia.stage4-original-validation-custody.v1','archive':str(destination),'bytes':destination.stat().st_size,'sha256':sha(destination.read_bytes()),'files':inventory,'readback':True,'new_native_calls':0,'whole_stack_closed':False}
dump(OUT/'stage4-validation-container.json',container)
print(json.dumps({k:container[k] for k in ('archive','bytes','sha256','readback')}),flush=True)
request={'uploads':[{'local_path':str(destination),'purpose':'create_library_file'}]}
with (OUT/'stage4-validation-library-upload.result.json').open('x') as stdout,(OUT/'stage4-validation-library-upload.stderr.log').open('x') as stderr:
    process=subprocess.run(['python',str(ROOT/'library-transfer-f50-20261111/library_upload.py')],input=json.dumps(request),text=True,stdout=stdout,stderr=stderr)
print('library_upload_returncode',process.returncode,flush=True)
raise SystemExit(process.returncode)
