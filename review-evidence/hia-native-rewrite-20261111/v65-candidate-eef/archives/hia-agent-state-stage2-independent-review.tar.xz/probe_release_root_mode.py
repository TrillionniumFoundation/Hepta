"""Small independent Core VM witness for the frozen release root policy.

No native image, filesystem mutation by the product, or candidate edit occurs.
"""
from hashlib import sha256
import json
from pathlib import Path
import struct
import sys
import tarfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
OUT = ROOT / 'hia-agent-state-independent-audit'
ARCHIVE = ROOT / 'hia-agent-state-integration-development/draft-stage2-source.tar.xz'
sys.path.insert(0, str(ROOT / 'Hepta'))
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View

with tarfile.open(ARCHIVE) as archive:
    source = archive.extractfile('source/examples/hia_bootstrap/release_install_policy.hiaasm').read()
    doc = archive.extractfile('source/docs/HIA_RELEASE_INSTALL_NATIVE.md').read()
(OUT / 'release-root-policy.hiaasm').write_bytes(source)
program = assemble_program(source)
observations = []
for mode in (0o700, 0o500, 0o702):
    work = bytearray(65536)
    struct.pack_into('<Q', work, 0, 5)
    struct.pack_into('<Q', work, 64, 1000)
    struct.pack_into('<I', work, 440, 0o40000 | mode)
    struct.pack_into('<I', work, 444, 1000)
    (OUT / ('root-mode-' + oct(mode)[2:] + '.state')).write_bytes(work)
    owners = [_Owner(-1, bytearray()), _Owner(-2, bytearray(8192)), _Owner(-3, work)]
    machine = _Machine(program, 100000, 1 << 20, None, 128)
    code = machine.invoke(program.as_dict()['functions'][0],
        [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
    assert code == (10 if mode == 0o702 else 0)
    observations.append({'root_permissions': oct(mode), 'uid': 1000,
                         'effective_uid': 1000, 'phase': 5, 'code': code})
report = {
    'schema': 'hepta.hia.release-root-policy-independent-vm.v1',
    'scope': 'DOCUMENTATION_MISMATCH_CONTROL_NOT_NATIVE_OR_SYSCALL_EXECUTION',
    'archive_sha256': sha256(ARCHIVE.read_bytes()).hexdigest(),
    'policy_source_sha256': sha256(source).hexdigest(),
    'documentation_sha256': sha256(doc).hexdigest(),
    'native_images_loaded': 0,
    'core_vm_calls': len(observations),
    'observations': observations,
    'finding': 'Documentation requires owner readable/writable/searchable root. Phase 5 actually requires owned directory and no group/other write; owned 0500 is admitted. Subsequent actual syscall rights remain kernel-enforced. Clarify separate read-only verify and installation permissions or enforce the documented common owner-bit predicate.',
}
(OUT / 'release-root-mode-observations.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
print(json.dumps(report, indent=2, sort_keys=True))
