"""Independent small Core-VM controls for the shared diagnostic ABI change."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import struct
import sys
import tarfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
OUT = ROOT / 'hia-agent-state-independent-audit'
ARCHIVE = ROOT / 'hia-agent-state-integration-development/draft-stage2-source.tar.xz'
sys.path.insert(0, str(ROOT / 'Hepta'))
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from hepta.hia_json_preflight import _preflight_hia_json_reference
from hepta.hia_json_preflight_native import scratch_sizes

with tarfile.open(ARCHIVE) as archive:
    source = archive.extractfile('source/examples/hia_bootstrap/json_preflight.hiaasm').read()
    adapter = archive.extractfile('source/hepta/hia_json_preflight_native.py').read()
tree = ast.parse(adapter)
assignment = next(n for n in tree.body if isinstance(n, ast.Assign) and
                  any(isinstance(t, ast.Name) and t.id == 'SYNTAX_REASONS' for t in n.targets))
reasons = ast.literal_eval(assignment.value)
program = assemble_program(source)
cases = [('', 32, 8), ('"\\ué"', 32, 8), ('"\\ué日"', 32, 8),
         ('"\\ué日x"', 32, 8), ('"\\u000z"', 32, 8),
         ('"\\ud800\\u00é"', 32, 8), ('{"\\u0061":0,"a":"\\q"}', 32, 8),
         ('[0,"\\q"]', 2, 8), ('["\\q"]', 32, 0),
         ('["\\u0041","😀"]', 32, 8), ('0\u00a0', 32, 8), ('[', 32, 8),
         ('{} {}', 32, 8), ('{"a":01}', 32, 8), ('[-0,0]', 32, 8)]
(OUT / 'preflight-reason-inputs.json').write_text(json.dumps(cases, indent=2, ensure_ascii=True)+'\n')
observations = []
for text, nodes, depth in cases:
    try:
        _preflight_hia_json_reference(text, max_nodes=nodes, max_depth=depth)
        reference = ['accepted']
    except (ValueError, OverflowError) as exc:
        reference = [type(exc).__name__, str(exc)]
    wire = text.encode('utf-8')
    key_size, state_size = scratch_sizes(len(wire), nodes, depth)
    state = bytearray(state_size)
    struct.pack_into('<2Q', state, 48, nodes, depth)
    owners = [_Owner(-1, bytearray(wire)), _Owner(-2, bytearray(key_size)), _Owner(-3, state)]
    machine = _Machine(program, 1000000, 1 << 20, None, 128)
    code = machine.invoke(program.as_dict()['functions'][0],
        [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
    reason = struct.unpack_from('<Q', owners[2].data, 32)[0]
    if code == 0:
        actual = ['accepted']
    elif code == 1:
        actual = ['ValueError', 'HIA JSON preflight: ' + reasons[reason]]
    elif code == 2:
        actual = ['OverflowError', 'HIA JSON exceeds node/depth budget before decoding']
    elif code == 4:
        actual = ['ValueError', 'HIA JSON preflight: duplicate decoded object key']
    else:
        raise AssertionError(('unexpected protocol error', code))
    assert bytes(owners[0].data) == wire
    assert actual == reference, (text, actual, reference)
    assert (code == 1 and reason in reasons) or (code != 1 and reason == 0)
    observations.append({'text': text, 'nodes': nodes, 'depth': depth, 'status': code,
                         'reason': reason, 'reference': reference, 'actual': actual,
                         'input_unchanged': True})
report = {'schema': 'hepta.hia.preflight-diagnostic-independent-vm.v1',
          'scope': 'FROZEN_STAGE2_SHARED_PREFLIGHT_SMALL_VM_CONTROLS_NO_NATIVE_COMPILATION',
          'source_sha256': sha256(source).hexdigest(), 'adapter_sha256': sha256(adapter).hexdigest(),
          'core_vm_calls': len(observations), 'native_images_loaded': 0,
          'exact_outcomes_equal': True, 'observations': observations}
(OUT / 'preflight-reason-observations.json').write_text(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=True)+'\n')
print(json.dumps({'core_vm_calls': len(observations), 'exact_outcomes_equal': True}))
