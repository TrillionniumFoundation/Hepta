"""Run the existing observer suite plus focused differential additions.

This is a development run, not a matching-source cold qualification. Original
runtime/source files are read from the pinned 5831f52 checkout. Only the selected
observer module and its expanded test file come from this independent overlay.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import resource
import stat
import subprocess
import sys
import tarfile
import time
import unittest

OVERLAY = Path(__file__).resolve().parents[1]
REPO = OVERLAY.parent/'Hepta'
parser = argparse.ArgumentParser()
parser.add_argument('--group', choices=('pure', 'native', 'all'), default='all')
parser.add_argument('--output', required=True)
args = parser.parse_args()
out = Path(args.output).resolve()
out.mkdir(parents=True, exist_ok=False)
sys.dont_write_bytecode = True
sys.path.insert(0, str(REPO))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == '5831f52fada45e076f8f68f198a15c0585e6104f'


def digest(raw): return hashlib.sha256(raw).hexdigest()


def pins():
    selected = [OVERLAY/'tools/hia_selfhost_native_observer.py',
                OVERLAY/'tests/test_hia_selfhost_native_observer.py',
                OVERLAY/'tests/hia_native_observer_v64_reference.py',
                OVERLAY/'examples/hia_bootstrap/native_observer_packer.hiaasm',
                REPO/'tools/qualify_hia_selfhost.py',
                REPO/'examples/hia_bootstrap/selfhost.hiaasm',
                REPO/'docs/HIA_SELFHOST_CORE_SUPPORT.json', Path(__file__)]
    return {str(p): {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())} for p in selected}


def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


before = pins()
write('source-before.json', before)
import tools
name = 'tools.hia_selfhost_native_observer'
spec = importlib.util.spec_from_file_location(name, OVERLAY/'tools/hia_selfhost_native_observer.py')
candidate = importlib.util.module_from_spec(spec)
sys.modules[name] = candidate
setattr(tools, 'hia_selfhost_native_observer', candidate)
spec.loader.exec_module(candidate)
test_spec = importlib.util.spec_from_file_location('hia_observer_candidate_tests',
                OVERLAY/'tests/test_hia_selfhost_native_observer.py')
tests = importlib.util.module_from_spec(test_spec)
test_spec.loader.exec_module(tests)

entries = []


def traced(module, version):
    original = module.execute
    def execute(executable_bytes, request, **kwargs):
        begin = time.monotonic_ns()
        process = original(executable_bytes, request, **kwargs)
        entries.append({'implementation': version, 'executable_sha256': digest(executable_bytes),
                        'request_sha256': digest(request), 'returncode': process.returncode,
                        'stdout_bytes': len(process.stdout), 'stdout_sha256': digest(process.stdout),
                        'stderr_sha256': digest(process.stderr),
                        'observed_call_ns': time.monotonic_ns()-begin})
        return process
    module.execute = execute


traced(candidate, 'candidate-r2')
tests.execute = candidate.execute
original_reference_loader = tests._reference_observer
def reference_loader():
    module = original_reference_loader()
    traced(module, 'frozen-v64-reference')
    return module
tests._reference_observer = reference_loader

capture_done = False
def capture(cls):
    global capture_done
    if capture_done or not hasattr(cls, 'root') or not cls.root.exists():
        return
    files = sorted(p for p in cls.root.rglob('*') if p.is_file())
    manifest = {str(p.relative_to(cls.root)): {'bytes': p.stat().st_size,
                 'sha256': digest(p.read_bytes()), 'mode': stat.S_IMODE(p.stat().st_mode)} for p in files}
    archive = out/'native-originals.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=3) as t:
        for p in files:
            t.add(p, arcname=str(p.relative_to(cls.root)), recursive=False)
    with tarfile.open(archive) as t:
        assert set(t.getnames()) == set(manifest)
        for member in t.getmembers():
            raw = t.extractfile(member).read(); row = manifest[member.name]
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256'] and member.mode == row['mode']
    write('native-originals-custody.json', {'archive': str(archive), 'bytes': archive.stat().st_size,
          'sha256': digest(archive.read_bytes()), 'members': len(files),
          'raw_bytes': sum(r['bytes'] for r in manifest.values()),
          'all_original_bytes_sha_mode_replayed': True, 'files': manifest})
    capture_done = True


old_teardown = tests.NativeObserverTests.tearDownClass.__func__
@classmethod
def teardown(cls):
    try:
        capture(cls)
    except BaseException:
        # Leave the original live directory available if evidence capture
        # fails; do not let TemporaryDirectory erase the only raw bytes.
        cls.temp._finalizer.detach()
        raise
    old_teardown(cls)
tests.NativeObserverTests.tearDownClass = teardown
loader = unittest.TestLoader()
suite = unittest.TestSuite()
if args.group in ('pure', 'all'):
    suite.addTests(loader.loadTestsFromTestCase(tests.ObserverFrameDifferentialTests))
if args.group in ('native', 'all'):
    suite.addTests(loader.loadTestsFromTestCase(tests.NativeObserverTests))
begin = time.monotonic_ns()
with (out/'tests.log').open('w') as f:
    result = unittest.TextTestRunner(stream=f, verbosity=2).run(suite)
elapsed = time.monotonic_ns()-begin
capture(tests.NativeObserverTests)
after = pins()
write('source-after.json', after)
write('native-entries.json', entries)
summary = {'schema': 'hepta.hia.observer-pure-development-validation.v1',
           'group': args.group, 'tests': result.testsRun, 'failures': len(result.failures),
           'errors': len(result.errors), 'skips': len(result.skipped),
           'expected_failures': len(result.expectedFailures),
           'unexpected_successes': len(result.unexpectedSuccesses),
           'source_unchanged': before == after,
           'actual_observer_entries': len(entries),
           'entries_by_implementation': {v: sum(r['implementation'] == v for r in entries)
                                         for v in sorted({r['implementation'] for r in entries})},
           'elapsed_ns': elapsed, 'max_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
           'python': sys.version, 'scope': 'DEVELOPMENT_VALIDATION_ONLY_NOT_COLD_QUALIFICATION'}
write('summary.json', summary)
print(json.dumps(summary, indent=2))
sys.exit(0 if result.wasSuccessful() and not result.skipped and before == after else 1)
