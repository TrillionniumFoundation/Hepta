"""Balanced fresh-process A/B of the exact old/new observer wrappers.

The HIA compiler and observer images come from the source-bound development
validation. All images, inputs, invocations and gates are retained. This local
experiment neither reruns cold qualification nor predicts its pass status.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import resource
import shutil
import statistics
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT/'development/bench-fixture'
MANIFEST = FIXTURE/'manifest.json'
parser = argparse.ArgumentParser()
parser.add_argument('--worker', choices=('reference', 'candidate'))
parser.add_argument('--output', required=True)
parser.add_argument('--run-directory')
parser.add_argument('--pairs', type=int, default=6)
args = parser.parse_args()
OUT = Path(args.output).resolve()
sys.dont_write_bytecode = True


def digest(raw): return hashlib.sha256(raw).hexdigest()


def read_manifest():
    raw = MANIFEST.read_bytes()
    value = json.loads(raw)
    assert value['schema'] == 'hepta.hia.observer-pure-benchmark-development.v1'
    for name, expected in value['files'].items():
        data = (ROOT/name).read_bytes()
        assert len(data) == expected['bytes'] and digest(data) == expected['sha256']
    for version, expected in value['modules'].items():
        data = Path(expected['path']).read_bytes()
        assert len(data) == expected['bytes'] and digest(data) == expected['sha256']
    return raw, value


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def remove_clocks(value):
    if isinstance(value, dict):
        return {k: remove_clocks(v) for k, v in value.items()
                if k not in ('wall_elapsed_ns', 'native_elapsed_ns')}
    if isinstance(value, list):
        return [remove_clocks(v) for v in value]
    return value


manifest_raw, manifest = read_manifest()
if args.worker:
    OUT.mkdir(parents=True, exist_ok=False)
    run_directory = Path(args.run_directory).resolve()
    run_directory.mkdir(parents=True, exist_ok=False)
    source_info = manifest['modules'][args.worker]
    source_path = Path(source_info['path'])
    raw = source_path.read_bytes()
    assert digest(raw) == source_info['sha256']
    spec = importlib.util.spec_from_file_location('measured_observer', source_path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(source_path), 'exec'), module.__dict__)
    observer = FIXTURE/'native-observer.elf'
    compiler = FIXTURE/'B1.image.bin'
    compiler_bytes = compiler.read_bytes()
    sample = (FIXTURE/'sample-source.hiaasm').read_bytes()
    compiler_source = (FIXTURE/'compiler-source.hiaasm').read_bytes()
    workloads = [
        ('compiler-sample', compiler, sample, 1 << 20, 1 << 20, 16, None, False),
        ('compiler-self', compiler, compiler_source, 1 << 20, 1 << 20, 2, None, False),
        ('compiler-invalid', compiler, b'invalid', 1 << 20, 1 << 20, 8, None, False),
        ('compiler-short', compiler, sample, 0, 1 << 20, 8, None, False),
        ('foreign-max-frame', FIXTURE/'foreign-max.image.bin', b'C'*(1 << 20),
          1 << 20, 1 << 20, 4, None, False),
        ('write-then-trap', FIXTURE/'write-then-trap.image.bin', b'', 3, 0, 4, b'ABC', True),
    ]
    rows = []
    for name, image, source, capacity, workspace, count, initial, trap in workloads:
        for index in range(count):
            label = name+'-'+str(index)
            host0 = resource.getrusage(resource.RUSAGE_SELF)
            child0 = resource.getrusage(resource.RUSAGE_CHILDREN)
            began = time.monotonic_ns()
            receipt, output = module.invoke(run_directory, label, observer, image, source,
                capacity=capacity, workspace_size=workspace, workspace_fill=90,
                output_initial=initial, observe_trap_writes=trap)
            external_ns = time.monotonic_ns()-began
            child1 = resource.getrusage(resource.RUSAGE_CHILDREN)
            host1 = resource.getrusage(resource.RUSAGE_SELF)
            assert receipt['fresh_native_exec'] is True and receipt['successor_process_reuse'] is False
            if name == 'compiler-self':
                assert receipt['status'] == 'returned' and receipt['abi_status'] == 0
                assert output[:receipt['core_u32']] == compiler_bytes
            elif name == 'compiler-invalid':
                assert receipt['status'] == 'returned' and receipt['core_u32'] == 0xffffffff
            elif name == 'compiler-short':
                assert receipt['status'] == 'returned' and receipt['core_u32'] == 0xfffffffe
            elif name == 'foreign-max-frame':
                assert receipt['status'] == 'returned' and receipt['core_u32'] == 42
                assert output == b'\xa5' * capacity
            elif name == 'write-then-trap':
                assert receipt['status'] == 'child_failed' and receipt['returncode'] == -4
                assert output == b'cBC'
            else:
                assert receipt['status'] == 'returned' and receipt['abi_status'] == 0
            rows.append({'workload': name, 'iteration': index, 'external_wall_ns': external_ns,
                         'parent_cpu_ns': round(((host1.ru_utime-host0.ru_utime)+(host1.ru_stime-host0.ru_stime))*1e9),
                         'children_cpu_ns': round(((child1.ru_utime-child0.ru_utime)+(child1.ru_stime-child0.ru_stime))*1e9),
                         'receipt': receipt, 'output_bytes': len(output), 'output_sha256': digest(output)})
    final_manifest_raw, _ = read_manifest()
    assert manifest_raw == final_manifest_raw
    result = {'schema': 'hepta.hia.observer-pure-local-ab-worker.v1', 'version': args.worker,
              'pid': os.getpid(), 'python': sys.version, 'python_path': sys.executable,
              'source': source_info, 'fixture_manifest_sha256': digest(manifest_raw),
              'fixture_and_module_pins_unchanged': True, 'rows': rows,
              'max_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'scope': 'LOCAL_DEVELOPMENT_AB_NO_COLD_QUALIFICATION'}
    write(OUT/'result.json', result)
    print(json.dumps({'version': args.worker, 'pid': os.getpid(), 'calls': len(rows),
                      'external_wall_ns': sum(r['external_wall_ns'] for r in rows)}))
    sys.exit(0)

OUT.mkdir(parents=True, exist_ok=False)
write(OUT/'fixture-manifest.json', manifest)
results = []
temp_root = Path(tempfile.mkdtemp(prefix='hia-observer-ab-', dir='/dev/shm'))
for pair in range(args.pairs):
    order = ('reference', 'candidate') if pair % 2 == 0 else ('candidate', 'reference')
    for position, version in enumerate(order):
        name = str(pair).zfill(2)+'-'+str(position)+'-'+version
        worker_out = OUT/name
        run_directory = temp_root/name
        command = [sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()), '--worker', version,
                   '--output', str(worker_out), '--run-directory', str(run_directory)]
        with (OUT/(name+'.stdout.log')).open('wb') as stdout, (OUT/(name+'.stderr.log')).open('wb') as stderr:
            process = subprocess.run(command, stdout=stdout, stderr=stderr)
        write(OUT/(name+'.command.json'), {'argv': command, 'returncode': process.returncode})
        if process.returncode:
            write(OUT/'FAILED.json', {'worker': name, 'returncode': process.returncode,
                                     'raw_directory_retained': str(temp_root)})
            raise SystemExit(process.returncode)
        result = json.loads((worker_out/'result.json').read_bytes())
        result['pair'] = pair; result['position'] = position
        results.append(result)
        files = sorted(p for p in run_directory.rglob('*') if p.is_file())
        pins = {str(p.relative_to(run_directory)): {'bytes': p.stat().st_size,
                   'sha256': digest(p.read_bytes()), 'mode': stat.S_IMODE(p.stat().st_mode)} for p in files}
        archive = worker_out/'native-originals.tar.xz'
        with tarfile.open(archive, 'w:xz', preset=3) as t:
            for p in files: t.add(p, arcname=str(p.relative_to(run_directory)), recursive=False)
        with tarfile.open(archive) as t:
            assert set(t.getnames()) == set(pins)
            for item in t.getmembers():
                data = t.extractfile(item).read(); pin = pins[item.name]
                assert len(data) == pin['bytes'] and digest(data) == pin['sha256'] and item.mode == pin['mode']
        write(worker_out/'native-originals-custody.json', {'files': pins, 'members': len(files),
              'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
              'raw_bytes': sum(r['bytes'] for r in pins.values()), 'every_original_bytes_sha_mode_verified': True})
        shutil.rmtree(run_directory)

assert len({r['pid'] for r in results}) == len(results)
pairs = []
for pair in range(args.pairs):
    versions = {r['version']: r for r in results if r['pair'] == pair}
    left, right = versions['reference']['rows'], versions['candidate']['rows']
    assert len(left) == len(right)
    for a, b in zip(left, right):
        assert (a['workload'], a['iteration']) == (b['workload'], b['iteration'])
        assert remove_clocks(a['receipt']) == remove_clocks(b['receipt'])
        assert (a['output_bytes'], a['output_sha256']) == (b['output_bytes'], b['output_sha256'])
    workloads = []
    for workload in dict.fromkeys(r['workload'] for r in left):
        values = {}
        for version, result in versions.items():
            rows = [r for r in result['rows'] if r['workload'] == workload]
            values[version] = {'calls': len(rows),
                'external_wall_ns': sum(r['external_wall_ns'] for r in rows),
                'native_wall_ns': sum(r['receipt'].get('native_elapsed_ns', 0) for r in rows),
                'receipt_wall_ns': sum(r['receipt']['wall_elapsed_ns'] for r in rows),
                'parent_cpu_ns': sum(r['parent_cpu_ns'] for r in rows),
                'children_cpu_ns': sum(r['children_cpu_ns'] for r in rows)}
        workloads.append({'workload': workload, **values})
    pairs.append({'pair': pair, 'all_outputs_and_receipts_equal_except_clocks': True, 'workloads': workloads})

summary = []
for workload in [r['workload'] for r in pairs[0]['workloads']]:
    samples = [next(r for r in pair['workloads'] if r['workload'] == workload) for pair in pairs]
    medians = {}
    for metric in ('external_wall_ns', 'native_wall_ns', 'receipt_wall_ns', 'parent_cpu_ns', 'children_cpu_ns'):
        medians[metric] = {version: statistics.median(s[version][metric] for s in samples)
                           for version in ('reference', 'candidate')}
    ratios = [s['candidate']['external_wall_ns']/s['reference']['external_wall_ns'] for s in samples]
    summary.append({'workload': workload, 'calls_per_worker': samples[0]['reference']['calls'],
                    'medians': medians, 'candidate_over_reference_pair_ratios': ratios,
                    'median_pair_ratio': statistics.median(ratios),
                    'candidate_faster_pairs': sum(r < 1 for r in ratios)})
final_manifest_raw, _ = read_manifest()
assert final_manifest_raw == manifest_raw
report = {'schema': 'hepta.hia.observer-pure-local-ab-summary.v1', 'pairs': args.pairs,
          'workers': len(results), 'actual_observer_invocations': sum(len(r['rows']) for r in results),
          'fresh_worker_pids': [r['pid'] for r in results],
          'all_same_payload_results_equal_except_clocks': True,
          'fixture_manifest_sha256': digest(manifest_raw), 'fixture_and_modules_unchanged': True,
          'python': sys.version, 'summary': summary, 'paired_raw_metrics': pairs,
          'scope': 'LOCAL_DEVELOPMENT_AB_NO_COLD_QUALIFICATION',
          'limits': {'cold_gate_changed': False, 'cold_replayed': False, 'qualified': False},
          'limitations': ['Local Python/CPU/filesystem timings do not predict GitHub 180-second qualification.',
                         'A native elapsed value is a wall clock; scheduling variation remains.',
                         'All workload counts and native calls are the same in each paired worker.',
                         'Archive compression and replay are outside the measured invoke intervals.',
                         'The maximum-frame foreign-code workload is a transport boundary stress control, not a typical compiler case.']}
write(OUT/'summary.json', report)
temp_root.rmdir()
print(json.dumps({'workers': report['workers'], 'calls': report['actual_observer_invocations'],
                  'all_semantics_equal': True, 'summary': summary}, indent=2))
