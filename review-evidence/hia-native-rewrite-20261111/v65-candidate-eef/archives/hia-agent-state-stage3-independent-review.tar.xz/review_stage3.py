"""Read immutable stage3, its actual compile receipts and original run evidence."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import re
import tarfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
EVIDENCE = ROOT / 'hia-agent-state-integration-development'
OUT = ROOT / 'hia-agent-state-stage3-independent-audit'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def source_archive(path):
    with tarfile.open(path, 'r:xz') as archive:
        return {m.name.removeprefix('source/'): archive.extractfile(m).read()
                for m in archive.getmembers() if m.isfile() and m.name.startswith('source/')}

frozen = json.loads((EVIDENCE / 'draft-stage3-source.json').read_bytes())
source = source_archive(EVIDENCE / 'draft-stage3-source.tar.xz')
old = source_archive(EVIDENCE / 'draft-stage2-source.tar.xz')
relation = json.loads((OUT / 'source-relation.json').read_bytes())
assert sha((EVIDENCE / 'draft-stage3-source.json').read_bytes()) == '7be50a756299896d816a5a991485f901abfbbd86c9653e648adf9e1c18e9c90b'
assert len(source) == 52 and len(frozen['source_closure']) == 635

unchanged_test_methods = {}
for name in ('tests/test_hia_worker_request_native.py', 'tests/test_hia_release_install.py'):
    def methods(raw):
        text = raw.decode()
        return {node.name: ast.get_source_segment(text, node)
                for node in ast.walk(ast.parse(text))
                if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
    first, second = methods(old[name]), methods(source[name])
    assert first == second
    unchanged_test_methods[name] = len(first)

compiles = []
for directory, label, source_name, manifest_name in (
    ('/dev/shm/hia-v65-state-development-r1/build', 'worker_request', 'examples/hia_bootstrap/worker_request.hiaasm', 'worker_request.manifest.json'),
    ('/dev/shm/hia-v65-state-development-r1/build', 'agent_journal', 'examples/hia_bootstrap/agent_journal.hiaasm', 'agent_journal.manifest.json'),
    ('/dev/shm/hia-v65-journal-recheck1', 'agent-journal', 'examples/hia_bootstrap/agent_journal.hiaasm', 'manifest.json'),
):
    directory = Path(directory)
    receipt = json.loads((directory / (label + '.receipt.json')).read_bytes())
    request = json.loads((directory / (label + '.request.json')).read_bytes())
    manifest = json.loads((directory / manifest_name).read_bytes())
    raw_source = (directory / (label + '.input.bin')).read_bytes()
    image = (directory / (label + '.image.bin')).read_bytes()
    output = (directory / (label + '.output.bin')).read_bytes()
    compiler = Path(request['image']).read_bytes()
    checks = {
        'source_exact_frozen_bytes': raw_source == source[source_name],
        'source_all_pins': sha(raw_source) == frozen['source_closure'][source_name] == receipt['input_sha256'] == receipt['source_sha256'] == request['source_sha256'] == manifest['source_sha256'],
        'compiler_all_pins': sha(compiler) == request['image_sha256'] == receipt['artifact_sha256'] == receipt['image_sha256'] == manifest['compiler_sha256'],
        'output_pin': sha(output) == receipt['output_sha256'],
        'produced_image_pin': sha(image) == receipt['produced_sha256'] == manifest['image_sha256'],
        'produced_image_actual_output_prefix': image == output[:receipt['produced_bytes']],
        'produced_size': len(image) == receipt['produced_bytes'] == receipt['result_u64'],
        'source_bound_runner': receipt['runner_sha256'] == frozen['source_closure']['tools/hia_selfhost_child.py'],
        'successful_actual_compile': receipt['status'] == 'returned' and receipt['abi_status'] == 0 and receipt['source_unchanged'] and not receipt['forbidden_compiler_modules_loaded'],
        'actual_label': receipt['case'] == label,
        'stderr_empty': not (directory / (label + '.stderr.log')).read_bytes(),
    }
    assert all(checks.values()), checks
    compiles.append({'label': label, 'checks': checks, 'source': source_name,
                     'source_sha256': sha(raw_source), 'image_sha256': sha(image),
                     'compiler_sha256': sha(compiler),
                     'receipt': pin(directory / (label + '.receipt.json')),
                     'request': pin(directory / (label + '.request.json')),
                     'manifest': pin(directory / manifest_name)})

runs = {}
snapshots = []
for name in ('native-stage3-development-attempt1', 'journal-stage3-recheck1'):
    folder = EVIDENCE / name
    before = (folder / 'source-before.json').read_bytes()
    after = (folder / 'source-after.json').read_bytes()
    assert before == after and json.loads(before) == frozen['source_closure']
    snapshots.append({'run': name, 'source_count': 635, 'source_before_after_exact': True,
                      'both_match_frozen_closure': True, 'snapshot_sha256': sha(before)})
    summary = json.loads((folder / 'summary.json').read_bytes())
    log_path = EVIDENCE / (name + '.stdout.log')
    log = log_path.read_text()
    lines = [line for line in log.splitlines() if line.startswith('test_')]
    observed = [re.search(r'\(([^)]+)\)', line).group(1) for line in lines]
    if name.startswith('native-'):
        assert observed == summary['chosen_test_ids'] == summary['executed_test_ids']
        assert len(observed) == len(set(observed)) == summary['tests_loaded'] == summary['tests_run'] == 58
        assert len(summary['failures']) == 4 and len(summary['errors']) == 3
        assert 'FAILED (failures=4, errors=3)' in log and summary['passed'] is False
        for failure in summary['failures']:
            assert 'PTRACE_TRACEME: Operation not permitted' in failure['traceback']
        assert 'agent-journal.request.json' in summary['errors'][0]['traceback']
        assert all("No module named 'rpds.rpds'" in error['traceback'] for error in summary['errors'][1:])
        ledger = json.loads((folder / 'native-entry-ledger.json').read_bytes())
        total = Counter()
        for values in ledger.values():
            total.update(values)
        assert dict(total) == summary['actual_parent_native_image_entries'] and sum(total.values()) == 1448
        native_entries = dict(total)
    else:
        assert observed == summary['selected_tests'] and len(observed) == summary['tests_run'] == 3
        assert summary['passed'] is True and summary['original_58_test_run_still_failed'] is True
        assert '\nOK\n' in log
        native_entries = summary['actual_parent_native_entries']
        assert sum(native_entries.values()) == 118
    skipped = summary.get('skipped', summary.get('skips'))
    assert skipped == [] and summary['expected_failures'] == [] and summary['unexpected_successes'] == []
    runs[name] = {
        'summary': pin(folder / 'summary.json'), 'log': pin(log_path),
        'executed_test_ids': observed, 'tests_run': len(observed),
        'failures': len(summary['failures']), 'errors': len(summary['errors']),
        'skipped': 0, 'expected_failures': 0, 'unexpected_successes': 0,
        'passed': summary['passed'], 'seconds': summary['seconds'],
        'python': summary['python'], 'parent_native_entry_counts': native_entries,
        'isolated_child_entries_not_counted': True,
    }

archive_path = EVIDENCE / 'native-stage3-development-originals.tar.xz'
custody = json.loads((EVIDENCE / 'native-stage3-development-originals-custody.json').read_bytes())
assert sha(archive_path.read_bytes()) == custody['sha256'] and archive_path.stat().st_size == custody['bytes']
selected_archive_members = {}
with tarfile.open(archive_path, 'r:xz') as archive:
    for name, local in (
        ('reports/development-r1/summary.json', EVIDENCE / 'native-stage3-development-attempt1/summary.json'),
        ('reports/journal-recheck1/summary.json', EVIDENCE / 'journal-stage3-recheck1/summary.json'),
        ('development-r1/build/worker_request.receipt.json', Path('/dev/shm/hia-v65-state-development-r1/build/worker_request.receipt.json')),
        ('development-r1/build/agent_journal.receipt.json', Path('/dev/shm/hia-v65-state-development-r1/build/agent_journal.receipt.json')),
    ):
        archived = archive.extractfile(name).read()
        assert archived == local.read_bytes()
        selected_archive_members[name] = {'bytes': len(archived), 'sha256': sha(archived)}

report = {
    'schema': 'hepta.hia.agent-state-stage3-independent-review.v1',
    'scope': 'READ_ONLY_FROZEN_SOURCE_RELATION_AND_ACTUAL_DEVELOPMENT_RAW_REVIEW',
    'source_manifest': pin(EVIDENCE / 'draft-stage3-source.json'),
    'source_archive': pin(EVIDENCE / 'draft-stage3-source.tar.xz'),
    'source_relation': relation,
    'reviewed_semantics': {
        'worker_journal_release_native_bodies_and_host_bridges_unchanged_from_stage2': True,
        'all14_generated_preflight_consumers_unchanged_from_stage2': True,
        'v64_public_lifecycle_and_composite_owners_inherited_exactly_from_base583': True,
        'v64_four_new_resources_builders_native_modules_and_source_classes_restored_in_integration': True,
        'v64_full_runner_five_selector_clearing_and_per_step_evidence_paths_preserved': True,
        'new_state_owner_required_gates_retained': True,
        'worker_release_dev_compile_input_now_frozen_once_and_read_back': True,
        'root_mode_0500_documentation_now_matches_original_phase5_policy': True,
        'all_original_worker_release_test_methods_exact': unchanged_test_methods,
    },
    'source_snapshots': snapshots,
    'actual_compile_receipts_independently_checked': compiles,
    'runs': runs,
    'initial_58_run_status': 'FAIL_RETAINED',
    'four_ptrace_failures': 'The actual strace process could not PTRACE_TRACEME/PTRACE_SETOPTIONS. These fault-injection controls remain unpassed on this host; no skips, substitutions or qualifications are inferred.',
    'three_initial_setup_errors': ['Incorrect agent_journal build label omitted the specifically required agent-journal.request.json', 'Python 3.13 process received Python 3.12 native rpds dependency path in two tests'],
    'targeted_remediation': 'Same frozen source was actually recompiled with agent-journal label and executed with matching Python 3.12 runtime; all three formerly erroneous tests passed. This does not replace the original full-run result.',
    'composition_gate': 'Deferred, not passed: it requires a completed matching-source cold report. The failed cold report was not admitted as authority.',
    'raw_archive': pin(archive_path),
    'raw_archive_selected_members_readback': selected_archive_members,
    'raw_archive_full_member_readback_scope': 'Full byte/mode replay is the separate root seal; this audit checked compressed archive digest and selected report/compile members, and read the actual raw files described above.',
    'reviewer_new_native_runs': 0,
    'current_source_cold_passed': False,
    'whole_stack_closed': False,
    'source_edits': [],
    'remaining_acceptance': ['Four real syscall fault-injection controls require an environment where the unchanged tests can execute ptrace', 'Full matching-source cold qualification and complete required test/composition gates remain necessary', 'Stage4 source modifications require their own source binding and actual targeted validation'],
}
(OUT / 'review.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'report': pin(OUT / 'review.json'), 'initial_run': 'FAIL_58_RUN_4_FAILURE_3_ERROR', 'targeted_recheck': 'PASS_3', 'source_closure': 635, 'source_preserved': True}))
