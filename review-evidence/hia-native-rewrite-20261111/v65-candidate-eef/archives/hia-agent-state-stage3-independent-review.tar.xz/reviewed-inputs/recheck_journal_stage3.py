"""Resolve three recorded development setup errors, without changing tests."""
from hashlib import sha256
from pathlib import Path
from collections import Counter
import json,os,shutil,sys,tempfile,time,unittest
from unittest.mock import patch

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration')
OUT=ROOT.parent/'hia-agent-state-integration-development/journal-stage3-recheck1'
RAW=Path('/dev/shm/hia-v65-journal-recheck1')
OUT.mkdir();RAW.mkdir(mode=0o700);(RAW/'tmp').mkdir()
sys.path.insert(0,str(ROOT));os.chdir(ROOT)
os.environ['TMPDIR']=str(RAW/'tmp');tempfile.tempdir=str(RAW/'tmp')
os.environ.pop('HEPTA_HIA_AGENT_JOURNAL_COLD_REPORT',None)
from jsonschema import Draft202012Validator
from tools.qualify_hia_selfhost import compile_stage
from hepta.hia_agent_journal_native import SOURCE,SCHEMA
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from tests.test_hia_agent_journal_native import JournalNativeTests
frozen=json.loads((OUT.parent/'draft-stage3-source.json').read_bytes())['source_closure']
def sources():return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in frozen}
before=sources();assert before==frozen
compiler=RAW/'compiler.image.bin'
compiler.write_bytes((ROOT.parent/'hia-f50-compiler-custody/B3.image.bin').read_bytes())
compiler_sha=sha256(compiler.read_bytes()).hexdigest()
assert compiler_sha=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
source=SOURCE.read_bytes()
image,receipt=compile_stage(RAW,'agent-journal',compiler,source)
assert (RAW/'agent-journal.input.bin').read_bytes()==source==SOURCE.read_bytes()
manifest=RAW/'manifest.json'
manifest.write_text(json.dumps({'schema':SCHEMA,'source_sha256':sha256(source).hexdigest(),'image_path':image.name,'image_sha256':sha256(image.read_bytes()).hexdigest(),'compiler_sha256':compiler_sha},sort_keys=True)+'\n')
os.environ['HEPTA_HIA_AGENT_JOURNAL_DEVELOPMENT_MANIFEST']=str(manifest)
selected=[
    'test_cached_explicit_selectors_are_readmitted_after_argument_snapshot',
    'test_real_artifact_restart_replay_alias_and_no_effect_cost_or_update',
    'test_real_process_kill_after_effect_preserves_running_intent',
]
ids=['tests.test_hia_agent_journal_native.JournalNativeTests.'+name for name in selected]
suite=unittest.defaultTestLoader.loadTestsFromNames(ids);assert suite.countTestCases()==3
images=Counter();init=NativeHiaJsonImage.__init__
def initialize(instance,data,expected):
    init(instance,data,expected);entry=instance._entry
    def invoke(*args):images[expected]+=1;return entry(*args)
    instance._entry=invoke
cleanup=JournalNativeTests.tearDownClass.__func__
def preserve(cls):
    folder=cls.folder;target=RAW/'journal-originals';shutil.copytree(folder,target,symlinks=True)
    for p in folder.rglob('*'):
        if p.is_file() and not p.is_symlink():assert p.read_bytes()==(target/p.relative_to(folder)).read_bytes()
    cleanup(cls)
start=time.monotonic_ns()
with patch.object(NativeHiaJsonImage,'__init__',initialize),patch.object(JournalNativeTests,'tearDownClass',classmethod(preserve)):
    result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2).run(suite)
after=sources()
value={'schema':'hepta.hia.targeted-journal-development-recheck.v1','scope':'THREE_PRIOR_SETUP_ERRORS_ONLY_NOT_COMPLETE_MODULE_OR_COLD','remediation':['Use the existing Python 3.12 runtime with its matching rpds extension, without altering dependency imports','Actually recompile with the expected agent-journal label; do not rename old receipts'],'selected_tests':ids,'tests_run':result.testsRun,'seconds':(time.monotonic_ns()-start)/1e9,'source_preserved':before==after,'python':sys.version,'manifest_sha256':sha256(manifest.read_bytes()).hexdigest(),'image_sha256':sha256(image.read_bytes()).hexdigest(),'source_sha256':sha256(source).hexdigest(),'actual_parent_native_entries':dict(images),'raw_directory':str(RAW),'errors':[{'test':str(t),'traceback':s} for t,s in result.errors],'failures':[{'test':str(t),'traceback':s} for t,s in result.failures],'skips':[{'test':str(t),'reason':s} for t,s in result.skipped],'expected_failures':[{'test':str(t),'traceback':s} for t,s in result.expectedFailures],'unexpected_successes':[str(t) for t in result.unexpectedSuccesses],'original_58_test_run_still_failed':True}
value['passed']=result.testsRun==3 and result.wasSuccessful() and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses and before==after
(OUT/'summary.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
(OUT/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');(OUT/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:value[k] for k in ('passed','tests_run','seconds','source_preserved')}),flush=True)
raise SystemExit(0 if value['passed'] else 1)
