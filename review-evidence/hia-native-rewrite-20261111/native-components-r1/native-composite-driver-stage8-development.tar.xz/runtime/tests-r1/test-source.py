"""Real metadata IR protocol tests; this is a development harness, not a driver."""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import mmap
import os
from pathlib import Path
import random
import struct
import unittest
from unittest.mock import patch

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_composite_function_tokens import ObjectTokenDecoder, TokenProtocolError, detached_packet_index
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'examples/hia_bootstrap/composite_object_ir.hiaasm'
GENERATOR=ROOT/'tools/generate_hia_composite_object_ir.py'
FROZEN=ROOT/'checkpoints/object-ir-source-r2/examples/hia_bootstrap/composite_object_ir.hiaasm'
MANIFEST=Path('/dev/shm/hia-object-ir-development/compile-r2/composite-object-ir.manifest.json')
SOURCE_SHA='fba2e8b3671dc81ba0a0af3aa550a25506e533800cdfc40a8d39ccf1ca6c0be8'
COMPILER_SHA='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
MAGIC=lambda x:int.from_bytes(x,'little')
INIT,CONT,EVENT,LEASE=map(MAGIC,(b'HIAOII01',b'HIAOIC01',b'HIAOIE01',b'HIASIL01'))
PRODUCER=MAGIC(b'HIAFNC01')
BAD=0xfffffffd
MIN_WORK=131328
CANARY=b'\xa5'*32


def token(kind,value=0):
    return struct.pack('<2Q',kind,value)


def string(value):
    raw=value.encode('utf8')
    return token(1,len(raw))+raw


def tokens(value):
    if value is None:return [token(4)]
    if type(value) is bool:return [token(3,int(value))]
    if type(value) is int:return [token(2,value)]
    if type(value) is str:return [string(value)]
    if type(value) is list:return [token(5,len(value))]+[t for child in value for t in tokens(child)]
    if type(value) is dict:return [token(6,len(value))]+[t for key,val in value.items() for t in [string(key)]+tokens(val)]
    raise TypeError(type(value))


def chunks(items,limit=65472):
    output=[];current=bytearray()
    for item in items:
        if len(item)>limit:raise ValueError('one token exceeds chunk')
        if current and len(current)+len(item)>limit:
            output.append(bytes(current));current.clear()
        current.extend(item)
    if current or not output:output.append(bytes(current))
    return output


def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class ActualIR:
    def __init__(self,directory):
        self.pins={}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes();digest=sha256(raw).hexdigest()
            if str(path) in self.pins and self.pins[str(path)]!=digest:
                raise AssertionError('input changed while admitting image')
            self.pins[str(path)]=digest
            return raw
        manifest=json.loads(read(MANIFEST))
        source=read(SOURCE);frozen=read(FROZEN)
        image=read(MANIFEST.parent/manifest['image_path'])
        if (set(manifest)!={'schema','source_sha256','image_path','image_sha256','compiler_sha256'}
                or manifest['schema']!='hepta.hia.composite-object-ir-native.v1'
                or source!=frozen or sha256(source).hexdigest()!=SOURCE_SHA
                or manifest['source_sha256']!=SOURCE_SHA
                or manifest['compiler_sha256']!=COMPILER_SHA
                or manifest['image_sha256']!=sha256(image).hexdigest()):
            raise AssertionError('source/component/image mismatch')
        read(GENERATOR);read(__file__)
        if any(sha256(Path(path).read_bytes()).hexdigest()!=digest for path,digest in self.pins.items()):
            raise AssertionError('input changed before mapping or evidence')
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=False)
        self.image=NativeHiaJsonImage(image,manifest['image_sha256'])
        self.log=(self.directory/'actual-ir-ledger.jsonl').open('w')
        self.entries=0;self.streams=0
        issuer=load_module('native_packet_issuer',ROOT/'tests/test_hia_composite_packet_json.py')
        self.issuer=issuer.ActualPacketJson(self.directory/'actual-packet-issuer')
        self.sources={}

    def source(self,value):
        raw=transport(value)
        if raw not in self.sources:
            result,header,data,index,state=self.issuer.encode('ir-source-'+str(len(self.sources)),raw)
            if result<64 or result!=64+len(data) or header[5]!=len(raw):
                raise AssertionError('actual native source index issuer refused')
            at=(64+len(raw)+7)&~7
            wire=struct.pack('<8Q',LEASE,len(raw),len(index),64,at,at+len(index),0,0)
            wire+=raw+b'\0'*(at-64-len(raw))+index
            _,nodes=detached_packet_index(raw)
            self.sources[raw]=(wire,nodes)
        return raw,*self.sources[raw]

    def session(self,label,value=None,**kwargs):
        self.streams+=1
        return Session(self,label,self.source(value),self.streams,**kwargs)

    def close(self):
        self.issuer.close();self.log.close()
        after={p:sha256(Path(p).read_bytes()).hexdigest() for p in self.pins}
        result={'scope':'ACTUAL_GENERIC_METADATA_IR_DEVELOPMENT_NOT_WHOLE_DRIVER_OR_COLD',
            'entries':self.entries,'streams':self.streams,'before':self.pins,'after':after,
            'sources_unchanged':after==self.pins,
            'source_lease_scope':'same bytes/index from actual native packet owner; private malformed controls explicitly unissued'}
        (self.directory/'custody.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        if after!=self.pins:raise AssertionError('source/image drift')


class Session:
    def __init__(self,native,label,source,stream,*,size=MIN_WORK,action=0,request=1,serial=8192,slots=512):
        self.native=native;self.label=label
        self.packet,self.source_wire,self.nodes=source
        self.source=ctypes.create_string_buffer(self.source_wire+CANARY)
        self.size=size;self.work=ctypes.create_string_buffer(size+len(CANARY))
        ctypes.memset(ctypes.addressof(self.work)+size,0xa5,len(CANARY))
        self.stream=stream;self.lease=17;self.action=action;self.request=request
        self.serial=serial;self.slots=slots;self.sequence=0
        self.last=None;self.growths=0;self.events=[]
        self.init=struct.pack('<8Q',INIT,self.lease,stream,PRODUCER,action,request,serial,slots)

    def call(self,raw,case='entry',*,extent=None):
        command=ctypes.create_string_buffer(raw+CANARY)
        extent=self.size if extent is None else extent
        result=self.native.image._entry(command,len(raw),self.source,len(self.source_wire),self.work,extent)
        self.native.entries+=1
        unchanged=(bytes(command[:len(raw)])==raw and bytes(self.source[:len(self.source_wire)])==self.source_wire)
        canaries=(bytes(command[len(raw):len(raw)+len(CANARY)])==CANARY
            and bytes(self.source[len(self.source_wire):len(self.source_wire)+len(CANARY)])==CANARY
            and bytes(self.work[self.size:self.size+len(CANARY)])==CANARY)
        if not unchanged or not canaries:raise AssertionError(('input/canary mutation',self.label,case))
        event=struct.unpack_from('<16Q',self.work,1024)
        row={'case':self.label,'call':case,'entry':self.native.entries,'stream':self.stream,
            'return':result,'event':event,'capacity':self.size,'advertised_workspace':extent,
            'command_bytes':len(raw),'command_sha256':sha256(raw).hexdigest(),
            'source_lease_bytes':len(self.source_wire),'source_lease_sha256':sha256(self.source_wire).hexdigest(),
            'input_unchanged':unchanged,'canaries_unchanged':canaries,
            'workspace_sha256':sha256(bytes(self.work[:self.size])).hexdigest()}
        if len(raw)<=4096:row['command_base64']=base64.b64encode(raw).decode()
        self.native.log.write(json.dumps(row,sort_keys=True)+'\n');self.native.log.flush()
        if result!=BAD:
            if result!=1152 or event[0]!=EVENT or event[3:5]!=(self.lease,self.stream) or event[12:]!=(0,0,0,0):
                raise AssertionError(('bad event',row))
            if self.last is not None and event[6]!=self.last[6]+1:
                raise AssertionError(('event sequence',row,self.last))
            self.events.append(event[1])
        self.last=event
        return result,event

    def grow(self,needed,*,exact=False):
        size=needed if exact else max(self.size*2,needed)
        if size<=self.size:raise AssertionError('nonincreasing GROW')
        old=self.work;self.work=ctypes.create_string_buffer(size+len(CANARY))
        ctypes.memmove(self.work,old,self.size)
        self.size=size;self.growths+=1
        ctypes.memset(ctypes.addressof(self.work)+size,0xa5,len(CANARY))

    def finish(self,result,*,exact=False):
        while result[0]!=BAD and result[1][1]==3:
            before_count=result[1][8];needed=result[1][10]
            self.grow(needed,exact=exact)
            command=struct.pack('<4Q',CONT,self.lease,self.stream,self.last[6])
            result=self.call(command,'grow-resume')
            if result[0]!=BAD and result[1][8]<before_count:
                raise AssertionError('GROW lost committed nodes')
        return result

    def initialize(self):
        return self.call(self.init,'initialize')

    def frame(self,payload,*,final,sequence=None):
        sequence=self.sequence if sequence is None else sequence
        return struct.pack('<8Q',PRODUCER,self.action,sequence,int(final),
            self.serial,self.slots,self.request,len(payload))+payload

    def send(self,payload,*,final,exact=False):
        result=self.finish(self.call(self.frame(payload,final=final),'producer'),exact=exact)
        if result[0]!=BAD:self.sequence+=1
        return result

    def materialize(self):
        if self.last[1]!=5 or self.last[2]!=2:raise AssertionError('IR not complete')
        end=self.last[9];root=self.last[7];values={}
        pending=[(root,False)];seen=set()
        while pending:
            node,visited=pending.pop()
            if not MIN_WORK<=node<=end-80:raise AssertionError('node outside issued arena')
            words=struct.unpack_from('<10Q',self.work,node)
            kind,value,count,head,tail,parent,next_,remaining,parity,complete=words
            if not complete or remaining or parity:raise AssertionError(('unfinished node',words))
            if visited:
                children=[];cursor=head
                while cursor:
                    children.append(values[cursor]);cursor=struct.unpack_from('<Q',self.work,cursor+48)[0]
                if kind==5:
                    if len(children)!=count:raise AssertionError('list arity')
                    values[node]=children
                else:
                    if len(children)!=2*count:raise AssertionError('map arity')
                    values[node]={children[i]:children[i+1] for i in range(0,len(children),2)}
                continue
            if node in seen:raise AssertionError('cycle or repeated IR node')
            seen.add(node)
            if kind==0:values[node]=self.nodes[value]
            elif kind==1:
                if not MIN_WORK<=value<=end-count:raise AssertionError('string outside arena')
                values[node]=bytes(self.work[value:value+count]).decode('utf8')
            elif kind==2:values[node]=value
            elif kind==3:values[node]=bool(value)
            elif kind==4:values[node]=None
            elif kind in (5,6):
                pending.append((node,True));items=[];cursor=head;previous=0
                while cursor:
                    if struct.unpack_from('<Q',self.work,cursor+40)[0]!=node:raise AssertionError('parent mismatch')
                    items.append(cursor);previous=cursor;cursor=struct.unpack_from('<Q',self.work,cursor+48)[0]
                    if len(items)>self.last[8]:raise AssertionError('sibling cycle')
                if previous!=tail:raise AssertionError('tail mismatch')
                pending.extend((child,False) for child in reversed(items))
            else:raise AssertionError('bad IR kind')
        if len(seen)!=self.last[8]:raise AssertionError('unaccounted issued node')
        return values[root]


class ObjectIRSourceTests(unittest.TestCase):
    def test_complete_source_fixed_point_and_unchanged_compiler_profile(self):
        doc=load_module('object_ir_author',GENERATOR).document()
        self.assertEqual(render_assembly(doc).encode(),SOURCE.read_bytes())
        self.assertEqual(SOURCE.read_bytes(),FROZEN.read_bytes())
        self.assertEqual([p['type'] for p in doc['functions'][0]['params']],['readbuf','mutbuf','mutbuf'])
        self.assertEqual(doc['functions'][0]['blocks'][0]['ops'][0]['op'],'borrow.read')
        self.assertLessEqual(len(doc['functions']),128)
        self.assertLessEqual(sum(len(f['blocks']) for f in doc['functions']),1536)
        self.assertLessEqual(max(len(f['blocks']) for f in doc['functions']),256)
        self.assertLessEqual(max(len(b['params']) for f in doc['functions'] for b in f['blocks']),16)


class ObjectIRNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        directory=os.environ.get('HEPTA_HIA_OBJECT_IR_EVIDENCE')
        if not directory:raise AssertionError('fresh evidence directory required; no skip')
        cls.native=ActualIR(directory)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def exact(self,label,items,*,source=None,split=65472,exact_growth=False):
        session=self.native.session(label,source)
        self.assertEqual(session.initialize()[1][1],1)
        oracle=ObjectTokenDecoder(session.nodes)
        parts=chunks(items,split)
        for i,part in enumerate(parts):
            oracle.feed(part,final=i+1==len(parts))
            result=session.send(part,final=i+1==len(parts),exact=exact_growth)
            self.assertNotEqual(result[0],BAD,label)
        self.assertEqual(session.materialize(),oracle.root,label)
        self.assertEqual(session.last[8],oracle.token_count,label)
        return session

    def test_all_kinds_unicode_random_and_source_aliases(self):
        atoms=[None,False,True,0,1,(1<<64)-1,'','é中😀','\0\n\t"\\',
            '\u007f\u0080\u07ff\u0800\ud7ff\ue000\uffff\U0010ffff',[],{}]
        for i,value in enumerate(atoms):
            self.exact('atom-'+str(i),tokens(value),split=160)
        rng=random.Random(0x49525f31)
        def value(depth):
            pick=rng.randrange(5 if depth else 3)
            if pick==0:return rng.choice(atoms[:11])
            if pick==1:return rng.getrandbits(64)
            if pick==2:return ''.join(rng.choice('aé😀\0\n"\\') for _ in range(rng.randrange(20)))
            if pick==3:return [value(depth-1) for _ in range(rng.randrange(5))]
            return {'k'+str(i):value(depth-1) for i in range(rng.randrange(5))}
        for i in range(80):self.exact('random-'+str(i),tokens(value(3)),split=160)
        source={'fn':{'blocks':[{'large':list(range(30))}]},'label':'same'}
        raw,lease,nodes=self.native.source(source)
        at=next(k for k,v in nodes.items() if type(v) is dict and 'blocks' in v)
        session=self.exact('same-source-ref', [token(5,2),token(0,at),token(0,at)],source=source)
        result=session.materialize()
        self.assertIs(result[0],result[1])
        self.assertIs(result[0],session.nodes[at])

    def test_source_offset_membership_and_duplicate_keys(self):
        source={'same':1,'nested':['same','e\u0301','é',[]]}
        _,lease,nodes=self.native.source(source)
        for at in nodes:self.exact('source-offset-'+str(at),[token(0,at)],source=source)
        same=next(at for at,v in nodes.items() if v=='same')
        self.exact('mixed-distinct-keys',[token(6,2),token(0,same),token(2,1),string('different'),token(2,2)],source=source)
        bads=[('duplicate-source-native',[token(6,2),token(0,same),token(4),string('same'),token(4)]),
              ('duplicate-native-source',[token(6,2),string('same'),token(4),token(0,same),token(4)]),
              ('non-key-source',[token(6,1),token(0,0),token(4)]),
              ('non-node-offset',[token(0,1)]),('foreign-high-handle',[token(0,1<<63)])]
        for label,items in bads:
            s=self.native.session(label,source);s.initialize()
            oracle=ObjectTokenDecoder(s.nodes)
            with self.assertRaises(TokenProtocolError):oracle.feed(b''.join(items),final=True)
            self.assertEqual(s.send(b''.join(items),final=True)[0],BAD)

    def test_all_token_syntax_refusals_and_persistent_failure(self):
        invalid=[b'\0',token(7),token(1,2)+b'x',token(3,2),token(4,1),
            token(5,1),token(6,1)+string('key'),token(4)+token(4)]
        for raw in [b'\x80',b'\xc0\x80',b'\xe0\x80\x80',b'\xed\xa0\x80',
                    b'\xf0\x80\x80\x80',b'\xf4\x90\x80\x80',b'\xf5\x80\x80\x80',
                    b'\xc2',b'\xe2\x82',b'\xf0\x9f\x92']:
            invalid.append(token(1,len(raw))+raw)
        for i,payload in enumerate(invalid):
            s=self.native.session('bad-token-'+str(i));s.initialize()
            oracle=ObjectTokenDecoder(s.nodes)
            with self.assertRaises(TokenProtocolError):oracle.feed(payload,final=True)
            self.assertEqual(s.send(payload,final=True)[0],BAD)
            state=bytes(s.work[:s.size])
            for command in [s.init,struct.pack('<4Q',CONT,s.lease,s.stream,s.last[6]),s.frame(token(4),final=True)]:
                self.assertEqual(s.call(command,'after-poison')[0],BAD)
                self.assertEqual(bytes(s.work[:s.size]),state)

    def test_full_map_arity_empty_chunks_and_finality(self):
        for count in [0,1,(1<<63)-1,1<<63,(1<<64)-1]:
            for kind in [5,6]:
                s=self.native.session('arity-%d-%d'%(kind,count));s.initialize()
                raw=token(kind,count)
                result=s.send(raw,final=False)
                self.assertNotEqual(result[0],BAD)
                self.assertEqual(s.last[8],1)
                self.assertEqual(s.send(b'',final=False)[1][1],1)
                result=s.send(b'',final=True)
                self.assertEqual(result[0]==BAD,count!=0)
                if not count:self.assertEqual(s.materialize(),[] if kind==5 else {})
        s=self.native.session('trailing-empty');s.initialize()
        self.assertEqual(s.send(token(4),final=False)[1][1],1)
        self.assertEqual(s.send(b'',final=True)[1][1],5)
        self.assertIsNone(s.materialize())
        self.assertEqual(s.send(b'',final=True)[0],BAD)

    def test_grow_every_node_and_stale_continuation(self):
        value={'root':[{'a':i,'b':'é'*i} for i in range(30)],'empty':{}}
        s=self.exact('exact-growth',tokens(value),split=4096,exact_growth=True)
        self.assertGreater(s.growths,100)
        self.assertGreater(s.events.count(3),100)
        small=self.native.session('repeat-grow')
        small.initialize()
        first=small.call(small.frame(token(4),final=True))
        self.assertEqual(first[1][1],3)
        before=struct.unpack_from('<Q',small.work,136)[0]
        old_sequence=small.last[6]
        cont=struct.pack('<4Q',CONT,small.lease,small.stream,old_sequence)
        self.assertEqual(small.call(cont,'without-enlargement')[1][1],3)
        self.assertEqual(struct.unpack_from('<Q',small.work,136)[0],before)
        self.assertEqual(small.call(cont,'stale-event')[0],BAD)

    def test_frame_correlation_and_short_workspace_scope(self):
        for index in range(8):
            s=self.native.session('frame-field-'+str(index));s.initialize()
            words=list(struct.unpack('<8Q',s.frame(token(4),final=True)[:64]))
            words[index]=words[index]+2 if index==3 else words[index]+1
            self.assertEqual(s.call(struct.pack('<8Q',*words)+token(4),'forged-frame')[0],BAD)
        for length in [0,1,7,8,63,65537]:
            s=self.native.session('extent-'+str(length));s.initialize()
            raw=b'\0'*length
            self.assertEqual(s.call(raw,'bad-extent')[0],BAD)
        s=self.native.session('short-workspace-private-control');s.initialize()
        before=bytes(s.work[:s.size])
        raw=s.frame(token(4),final=True)
        self.assertEqual(s.call(raw,'short-borrow',extent=MIN_WORK-1)[0],BAD)
        self.assertEqual(bytes(s.work[:s.size]),before)
        # This invalid borrowed extent cannot store poison. The real fixed
        # driver must drop this lease instead of performing this private retry.
        self.assertNotEqual(s.finish(s.call(raw,'private-restored-borrow'))[0],BAD)
        self.assertIsNone(s.materialize())

    def test_source_lease_framing_controls_are_not_authentication(self):
        for index in [0,1,2,3,4,5,6,7]:
            s=self.native.session('source-header-'+str(index),['same'])
            data=bytearray(s.source_wire)
            struct.pack_into('<Q',data,index*8,struct.unpack_from('<Q',data,index*8)[0]+1)
            s.source_wire=bytes(data);s.source=ctypes.create_string_buffer(s.source_wire+CANARY)
            self.assertEqual(s.initialize()[0],BAD)
        s=self.native.session('source-header-after-init',[1]);s.initialize()
        data=bytearray(s.source_wire);struct.pack_into('<Q',data,48,1)
        s.source_wire=bytes(data);s.source=ctypes.create_string_buffer(s.source_wire+CANARY)
        self.assertEqual(s.send(token(4),final=True)[0],BAD)

    def test_large_source_aliases_are_not_json_materialized(self):
        value={'function':{'body':'x'*(600<<10)}}
        _,lease,nodes=self.native.source(value)
        at=next(at for at,v in nodes.items() if type(v) is dict and 'body' in v)
        count=20
        s=self.exact('large-source-alias',[token(5,count)]+[token(0,at)]*count,source=value)
        self.assertEqual(s.last[8],count+1)
        self.assertEqual(s.last[9]-MIN_WORK,(count+1)*80)
        materialized=s.materialize()
        self.assertTrue(all(item is materialized[0] for item in materialized))
        self.assertGreater(len(json.dumps(materialized,separators=(',',':')).encode()),8<<20)

    def test_actual_hia_fixture_renderer_without_python_token_dispatch(self):
        base=ROOT/'development/compile-object-producer-r1'
        summary=json.loads((base/'summary.json').read_bytes())
        images={}
        pins={}
        for name in ['stream_fixture','render']:
            source=(base/(name+'.hiaasm')).read_bytes()
            image=(base/('object-'+name+'.image.bin')).read_bytes()
            receipt=json.loads((base/('object-'+name+'.receipt.json')).read_bytes())
            self.assertEqual(receipt['source_sha256'],sha256(source).hexdigest())
            self.assertEqual(receipt['produced_sha256'],sha256(image).hexdigest())
            self.assertEqual(receipt['artifact_sha256'],COMPILER_SHA)
            pins[str(base/(name+'.hiaasm'))]=sha256(source).hexdigest()
            pins[str(base/('object-'+name+'.image.bin'))]=sha256(image).hexdigest()
            images[name]=NativeHiaJsonImage(image,sha256(image).hexdigest())
        self.assertTrue(all(sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items()))
        s=self.native.session('actual-HIA-producer',{'source':'immutable'},serial=100,slots=4)
        self.assertEqual(s.initialize()[1][1],1)
        state_map=mmap.mmap(-1,192<<20)
        state=(ctypes.c_ubyte*(192<<20)).from_buffer(state_map)
        output=ctypes.create_string_buffer(65536)
        request=struct.pack('<4Q',8,4,0,100)
        source=ctypes.create_string_buffer(request,len(request))
        self.assertEqual(images['stream_fixture']._entry(source,len(request),output,65536,state,192<<20),0)
        empty=ctypes.create_string_buffer(1)
        frames=0
        try:
            with patch.object(ObjectTokenDecoder,'feed',side_effect=AssertionError('old token owner entered')), \
                 patch('hepta.hia_instruction_policy_native.transport',side_effect=AssertionError('host transport entered')):
                while True:
                    size=images['render']._entry(empty,0,output,65536,state,192<<20)
                    self.assertGreaterEqual(size,64);self.assertLessEqual(size,65536)
                    raw=bytes(output[:size])
                    result=s.finish(s.call(raw,'actual-producer'))
                    self.assertNotEqual(result[0],BAD)
                    frames+=1
                    if struct.unpack_from('<Q',raw,24)[0]:break
            expected={'names':['h2internal_'+str(i) for _ in range(8) for i in range(100,104)],
                'source':s.nodes[0],'null':None,'bool':True,'integer':8192}
            self.assertEqual(s.materialize(),expected)
            self.assertTrue(all(sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items()))
            (self.native.directory/'actual-native-producer.json').write_text(json.dumps({
                'fixture_entries':1,'render_entries':frames,'pins':pins,'sources_unchanged':True,
                'old_token_feed_and_transport_forbidden_during_forwarding':True,
                'scope':'GENERIC_REAL_HIA_FIXTURE_NOT_WHOLE_FUNCTION_OR_DRIVER',
            },indent=2,sort_keys=True)+'\n')
        finally:
            del state
            state_map.close()
