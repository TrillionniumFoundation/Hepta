# Native object-token IR for composite continuations

Status: an unselected development component. The first draft was authored while the shared executor was unavailable. After recovery, the complete source passed generation and the ordinary verifier, then compiled through the retained B3 under its original limits. Eleven actual protocol tests have passed; their exact scope and original records are described below. Installed execution, cold qualification and complete native normalization remain unproved.

## Purpose and scope

The existing constructor and function owners return generic object-token streams. Their service requests and final metadata contain source references: for example a task registry row includes a reference to the complete original function. Materializing those references as JSON and reading the result through the public JSON decoder would introduce an 8 MiB / 262144-node admission point absent from the existing path. This component instead retains an exact source reference as one IR leaf.

The component covers every ordinary object-token kind (source reference, strict UTF-8 string, unsigned 64-bit integer, boolean, null, list, map), the existing 64-byte producer frame and correlation fields, arbitrarily split *frames* with complete tokens in each frame, zero-length chunks, exact final-root completion, map-key type and full-byte duplicate detection, and map arities across the full unsigned 64-bit range. It has no fixed aggregate IR node count, depth, key count, or JSON expansion quota. Storage grows through an explicit GROW event. Finite address arithmetic still refuses overflow.

This is the continuation-metadata path. Complete Core output remains on the separately implemented streaming JSON path, including its trusted internal opaque-Core handles. This component does not accept opaque high-half handles. It does not implement constructor, function, helper, outer, type semantics, or the fixed native coordinator.

## Source lease: an internal pipeline interface

The second entry buffer is a read-only private SourceIndexLease, owned by the fixed coordinator. It is constructed by copying the *same* admitted typed packet and exact node bitmap produced by the complete packet validator. The coordinator retains that pair without replacement and makes the buffer read-only before invoking this component.

The 64-byte header is eight little-endian unsigned words:

1. magic HIASIL01;
2. typed packet byte length, between 16 and 64 MiB inclusive;
3. exact index length, ceil(packet length / 8);
4. packet offset, exactly 64;
5. bitmap offset, align8(64 + packet length);
6. total extent, exactly bitmap offset + index length;
7. zero;
8. zero.

Each bitmap bit marks one exact typed-packet node offset. The packet and bitmap have already been validated by the native packet owner. This component checks the header, root extent, root membership, final padding bits, and each referenced node's membership and extent. It does not independently reproduce full packet validation and does not authenticate a caller-supplied bitmap. A matching length, nonce, bit, or digest is not proof of external provenance. An arbitrary substituted packet/index pair lies outside this internal issued-lease contract.

All source offsets in IR are relative to the original packet, so constructor/function source references are unchanged. No source value is copied or expanded. Source string keys compare their original UTF-8/surrogatepass bytes to inline native string keys. Inline strings must be strict UTF-8, matching ObjectTokenDecoder.

## Entry and commands

The external entry is RWW: command read buffer, source lease borrowed through the second buffer, and private mutable workspace. The second buffer is never written. The fixed executable must enforce disjoint leases and protect the source lease.

Minimum workspace: 131328 bytes. The first 512 bytes hold control state, the event starts at 1024, the immutable copy of the current original producer frame occupies [65536, 131072), and node allocation begins at 131328. Output events contain no language value plan.

INIT is exactly 64 bytes:
[HIAOII01, lease, stream, producerMagic, producerAction, callerRequest, serial, slots].

CONT is exactly 32 bytes:
[HIAOIC01, lease, stream, mostRecentEventSeq].

A producer frame is the existing original 64-byte header plus its payload:
[producerMagic, action, sequence, final, serial, slots, request, payloadBytes].
Its entire extent must be between 64 and 65536 inclusive. Producer magic must differ from the reserved INIT and CONT magics. The initial producer sequence is zero. Every field must agree with INIT, apart from the exact next sequence, final flag and payload size.

A producer frame is copied into the workspace before processing. GROW retains that copy and the exact next token offset. A CONT after enlargement resumes it; it does not ask the producer to generate the frame again. It cannot accept another producer frame while a copied frame remains active. Command and source leases must remain immutable during entry.

INIT is allowed only in fresh zero state. After completion or refusal the state is never reusable for another stream. All BAD statuses require the fixed coordinator to discard the lease immediately, including a too-short workspace on which a poison flag cannot be written.

## Event

A successful control event occupies 128 bytes at workspace offset 1024 and returns the exact extent 1152:

[HIAOIE01, action, status, lease, stream, nextProducerSeq, eventSeq,
 rootOffset, nodeCount, arenaEnd, requiredWorkspace, errorDetail, 0, 0, 0, 0].

Actions: READY=1, GROW=3, DONE=5, FAIL=6. Status: ACTIVE=1, COMPLETE=2, BAD=3.
A protocol refusal returns 0xfffffffd; a current FAIL event is diagnostic only. An invalid short workspace cannot promise that such a frame exists. Event-sequence overflow similarly does not promise a refreshed event. The coordinator must check the return code before consuming any event.

READY asks for the next original producer frame. DONE publishes the complete IR root. GROW publishes an exact minimum extent; doubling is a storage policy, not a semantic quota. The current input copy and all already admitted nodes survive growth by byte-preserving relocation. Every reference is an offset, never a retained pointer.

## IR layout and ordering

Every node occupies 80 bytes:

[kind, value, declaredCountOrStringBytes, firstChild, lastChild,
 parent, nextSibling, remaining, mapParity, completed].

Kind values are the original object-token values. A source leaf's value is the original packet offset. A string's value is an offset to immutable copied bytes in the IR workspace; its length is the third word. Integer and boolean values remain exact unsigned words. Null has value zero. A container's declared count is its original list item or map pair count. Its ordered child list contains every original child, with map keys and values alternating.

Map progress stores a pair count and a one-bit key/value phase instead of multiplying the count by two. Thus a map declaring 2^63 or 2^64-1 pairs remains representable and incomplete, without wraparound. Node creation validates the full token (including strict string UTF-8), source membership, key type, and duplicate keys before committing its attachment. A lack of storage requests GROW before that token's node or parent counters are changed. Earlier successfully processed tokens remain committed, as in the retained decoder.

Duplicate keys are compared by complete bytes. The current draft uses a linear scan of each map's existing keys; this is a cost consideration, not a key-count restriction or a digest-based authority. Native continuation metadata uses small generated maps and source-reference leaves; any later optimization requires full first-error and byte-equivalence checks.

DONE freezes the entire IR. A later native service projector may borrow it together with the same SourceIndexLease. The projector is responsible for creating the exact normalized types command while retaining original references until the relevant field is actually emitted. Only the actual normalized command is subject to the existing types command JSON limit (8 MiB + 128). The raw IR is not admitted as a language program.

## Required verification before integration

The recorded development checks cover source fixed points, original compiler limits, 729 actual consumer entries across 168 streams, and an actual native packet-index issuer. Before integration, the complete coordinator still needs its own end-to-end gates. The component checks include unchanged compiler limits; complete old ObjectTokenDecoder outcomes; frame truncation and correlation; strict UTF-8 boundaries; all token kinds; source offset/non-node controls; source/native duplicate keys; zero and maximal list/map arities; multiple roots; empty chunks; final/incomplete containers; refusal followed by INIT/CONT/producer; GROW before every allocation boundary and midway through an original frame; byte-preserving relocation; canaries; exact source and image pins; real existing constructor/function producer streams; large metadata whose source aliases would expand past public JSON limits; and the complete native service projection/coordinator.

No production selector, installed resource, support contract, language inventory, compiler limit, or public admission gate is changed by this development source.

## Recorded development evidence

The first generated draft had 27 functions, 311 blocks and 1187 operations. The second source revision adds an explicit outer HIA read borrow for the source lease, producing 28 functions, 312 blocks and 1190 operations, with maximum block parameter count 6 and maximum function block count 38. Its 67314-byte HIA source has SHA-256 fba2e8b3671dc81ba0a0af3aa550a25506e533800cdfc40a8d39ccf1ca6c0be8. The actual 95263-byte image has SHA-256 7817c6e98d05533bb633b633fca75130ec52c8c10aa20e9ec5be10077a2daa85. B3 remains 0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8; its 10 CPU seconds, 20 wall seconds and 256 MiB address-space compilation limits were unchanged. This is development compilation, not a matching current-source cold qualification.

The first 10-test run and the expanded 11-test run are separate original records. The expanded run passed all 11 tests with no failures, errors, skips, expected failures or unexpected successes, in 0.6884384420045535 seconds and maximum RSS 54644 KiB. Its 729 consumer entries cover 168 streams. It includes a full 65536-byte producer frame, 2048 nested generated containers, exact node-by-node growth, complete retained decoder partial state before and after a malformed UTF-8 token, maximal unsigned map counts, repeated source aliases and refusal followed by reuse attempts.

The source-alias case points twenty IR leaves to one 600 KiB source body. Expanding that metadata as JSON would exceed 8 MiB, while the generated IR occupies 1680 bytes and preserves the source-object alias in the independent comparison. This is the reason for retaining source references. It does not remove the public raw-JSON limit or the actual normalized types-command limit.

A real HIA compressed-IR fixture and the unchanged production renderer produced a complete stream consumed by this actual image while the old Python ObjectTokenDecoder.feed and transport functions were forbidden inside the forwarding loop. The fixture is not an entire composite function program. Python still performs test orchestration, independent expected-value construction and post-execution IR inspection. The fixed native driver and complete service projector remain to be implemented.

The third source checkpoint changes explanatory text only; the generated HIA source and actual image remain exactly the second revision. Earlier unexecuted draft documents, source generation records, compile requests/receipts and both raw test runs are retained independently.
