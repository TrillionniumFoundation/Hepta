"""Second source generation with explicit read borrow; records failures without changing quotas."""
from pathlib import Path
import hashlib,importlib.util,json,sys,time,traceback,shutil
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
MAIN=ROOT.parent/'Hepta'
sys.path.insert(0,str(MAIN))
directory=ROOT/'development/object-ir-generation-r2'
directory.mkdir(exist_ok=False)
paths=('tools/generate_hia_composite_object_ir.py','docs/HIA_COMPOSITE_OBJECT_TOKEN_IR.md')
before={}
for rel in paths:
    p=ROOT/rel;raw=p.read_bytes();target=directory/'frozen-inputs'/rel
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    before[rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
start=time.monotonic()
try:
    spec=importlib.util.spec_from_file_location('new_object_ir',ROOT/paths[0])
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    from hepta.hia_agent_assembly import render_assembly
    document=module.document()
    raw=render_assembly(document).encode()
    target=ROOT/'examples/hia_bootstrap/composite_object_ir.hiaasm'
    target.write_bytes(raw)
    result={'status':'PASS','functions':len(document['functions']),
        'blocks':sum(len(fn['blocks']) for fn in document['functions']),
        'operations':sum(len(b['ops']) for f in document['functions'] for b in f['blocks']),
        'max_function_blocks':max(len(f['blocks']) for f in document['functions']),
        'max_block_params':max(len(b['params']) for f in document['functions'] for b in f['blocks']),
        'source':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
except BaseException as exc:
    traceback.print_exc()
    result={'status':'FAIL','class':type(exc).__name__,'error':str(exc)}
result.update({'scope':'SOURCE_GENERATION_ONLY_NO_NATIVE_EXECUTION','before':before,
    'elapsed_seconds':time.monotonic()-start,
    'source_inputs_unchanged':all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v['sha256'] for p,v in before.items())})
(directory/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
