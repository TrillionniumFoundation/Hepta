"""Author a native object-token IR for complete composite continuations.

New unexecuted development source.  No production selector is changed.
SourceIndexLease is an internal issued packet/index pair, not authentication
of an arbitrary caller-supplied bitmap.  See the matching design document.
"""
from __future__ import annotations

import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

CONSTANTS = {
    "INIT_MAGIC": int.from_bytes(b"HIAOII01", "little"),
    "CONT_MAGIC": int.from_bytes(b"HIAOIC01", "little"),
    "EVENT_MAGIC": int.from_bytes(b"HIAOIE01", "little"),
    "STATE_MAGIC": int.from_bytes(b"HIAOIS01", "little"),
    "SOURCE_MAGIC": int.from_bytes(b"HIASIL01", "little"),
    "ABI": 0xfffffffd,
    "U64_MAX": (1 << 64) - 1,
    "MIN_WORK": 131328,
    "INPUT_BASE": 65536,
    "ARENA_BASE": 131328,
    "EVENT_BASE": 1024,
    "PACKET_MAX": 64 << 20,
    "S_MAGIC": 0,
    "S_STATUS": 8,
    "S_LEASE": 16,
    "S_STREAM": 24,
    "S_PRODUCER": 32,
    "S_ACTION": 40,
    "S_REQUEST": 48,
    "S_SERIAL": 56,
    "S_SLOTS": 64,
    "S_PSEQ": 72,
    "S_ESEQ": 80,
    "S_SOURCE_SIZE": 88,
    "S_INDEX_AT": 96,
    "S_INDEX_SIZE": 104,
    "S_SOURCE_EXTENT": 112,
    "S_ROOT": 120,
    "S_TOP": 128,
    "S_NODES": 136,
    "S_CURSOR": 144,
    "S_NEED": 152,
    "S_INPUT_SIZE": 160,
    "S_INPUT_AT": 168,
    "S_INPUT_FINAL": 176,
    "S_INPUT_ACTIVE": 184,
    "S_DETAIL": 192,
    "T_KIND": 200,
    "T_VALUE": 208,
    "T_STOP": 216,
    "T_BYTES": 224,
    "T_NEED": 232,
}

SOURCE = r'''
def object_ir(s:readbuf, r:mutbuf, w:mutbuf) -> u32:
    if length(w) < MIN_WORK:
        return ABI
    if get(w, S_STATUS) == 3:
        return ABI
    if length(s) < 8:
        return refuse(w, 1)
    magic = word(s, 0)
    if magic == INIT_MAGIC:
        return initialize(s, r, w)
    if get(w, S_MAGIC) != STATE_MAGIC or get(w, S_STATUS) != 1:
        return refuse(w, 2)
    if source_same(r, w) == 0:
        return refuse(w, 3)
    if magic == CONT_MAGIC:
        return continuation(s, r, w)
    return producer(s, r, w)

def word(s:readbuf, at:u64) -> u64:
    i = 0
    value = 0
    while i < 8:
        value = value | (byte(s, at + i) << (i * 8))
        i = i + 1
    return value

def get(w:mutbuf, at:u64) -> u64:
    i = 0
    value = 0
    while i < 8:
        value = value | (byte(w, at + i) << (i * 8))
        i = i + 1
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(w, at + i, (value >> (i * 8)) & 255)
        i = i + 1
    return 0

def event(w:mutbuf, action:u64) -> u32:
    sequence = get(w, S_ESEQ)
    if sequence == U64_MAX:
        put(w, S_STATUS, 3)
        return ABI
    sequence = sequence + 1
    put(w, S_ESEQ, sequence)
    put(w, EVENT_BASE, EVENT_MAGIC)
    put(w, EVENT_BASE + 8, action)
    put(w, EVENT_BASE + 16, get(w, S_STATUS))
    put(w, EVENT_BASE + 24, get(w, S_LEASE))
    put(w, EVENT_BASE + 32, get(w, S_STREAM))
    put(w, EVENT_BASE + 40, get(w, S_PSEQ))
    put(w, EVENT_BASE + 48, sequence)
    put(w, EVENT_BASE + 56, get(w, S_ROOT))
    put(w, EVENT_BASE + 64, get(w, S_NODES))
    put(w, EVENT_BASE + 72, get(w, S_CURSOR))
    put(w, EVENT_BASE + 80, get(w, S_NEED))
    put(w, EVENT_BASE + 88, get(w, S_DETAIL))
    put(w, EVENT_BASE + 96, 0)
    put(w, EVENT_BASE + 104, 0)
    put(w, EVENT_BASE + 112, 0)
    put(w, EVENT_BASE + 120, 0)
    return EVENT_BASE + 128

def refuse(w:mutbuf, reason:u64) -> u32:
    put(w, S_STATUS, 3)
    put(w, S_DETAIL, reason)
    event(w, 6)
    return ABI

def source_header(r:mutbuf) -> u64:
    if length(r) < 64:
        return 0
    if get(r, 0) != SOURCE_MAGIC or get(r, 24) != 64:
        return 0
    if get(r, 48) != 0 or get(r, 56) != 0:
        return 0
    size = get(r, 8)
    if size < 16 or size > PACKET_MAX:
        return 0
    count = (size + 7) >> 3
    index = (size + 71) & 18446744073709551608
    if get(r, 16) != count or get(r, 32) != index:
        return 0
    if get(r, 40) != index + count or length(r) != index + count:
        return 0
    if get(r, 72) != size - 16:
        return 0
    kind = get(r, 64)
    if kind > 6 or kind == 3:
        return 0
    if (byte(r, index) & 1) == 0:
        return 0
    tail = size & 7
    if tail != 0:
        mask = (255 << tail) & 255
        if (byte(r, index + count - 1) & mask) != 0:
            return 0
    return 1

def source_same(r:mutbuf, w:mutbuf) -> u64:
    if source_header(r) == 0:
        return 0
    if get(r, 8) != get(w, S_SOURCE_SIZE) or get(r, 16) != get(w, S_INDEX_SIZE):
        return 0
    if get(r, 32) != get(w, S_INDEX_AT) or length(r) != get(w, S_SOURCE_EXTENT):
        return 0
    return 1

def source_node(r:mutbuf, w:mutbuf, offset:u64) -> u64:
    size = get(w, S_SOURCE_SIZE)
    if offset > size or size - offset < 16:
        return 0
    position = get(w, S_INDEX_AT) + (offset >> 3)
    if (byte(r, position) & (1 << (offset & 7))) == 0:
        return 0
    node = 64 + offset
    if get(r, node + 8) > size - offset - 16:
        return 0
    kind = get(r, node)
    if kind > 6 or kind == 3:
        return 0
    if kind == 0 and get(r, node + 8) != 0:
        return 0
    if kind == 1:
        if get(r, node + 8) != 1:
            return 0
        if byte(r, node + 16) > 1:
            return 0
    if kind >= 5 and get(r, node + 8) < 8:
        return 0
    return 1

def initialize(s:readbuf, r:mutbuf, w:mutbuf) -> u32:
    if length(s) != 64 or get(w, S_MAGIC) != 0 or get(w, S_STATUS) != 0:
        return refuse(w, 4)
    if source_header(r) == 0:
        return refuse(w, 3)
    if word(s, 24) == INIT_MAGIC or word(s, 24) == CONT_MAGIC:
        return refuse(w, 5)
    fill_range(w, 0, 512, 0)
    put(w, S_MAGIC, STATE_MAGIC)
    put(w, S_STATUS, 1)
    put(w, S_LEASE, word(s, 8))
    put(w, S_STREAM, word(s, 16))
    put(w, S_PRODUCER, word(s, 24))
    put(w, S_ACTION, word(s, 32))
    put(w, S_REQUEST, word(s, 40))
    put(w, S_SERIAL, word(s, 48))
    put(w, S_SLOTS, word(s, 56))
    put(w, S_SOURCE_SIZE, get(r, 8))
    put(w, S_INDEX_SIZE, get(r, 16))
    put(w, S_INDEX_AT, get(r, 32))
    put(w, S_SOURCE_EXTENT, length(r))
    put(w, S_CURSOR, ARENA_BASE)
    return event(w, 1)

def continuation(s:readbuf, r:mutbuf, w:mutbuf) -> u32:
    if length(s) != 32:
        return refuse(w, 6)
    if word(s, 8) != get(w, S_LEASE) or word(s, 16) != get(w, S_STREAM):
        return refuse(w, 7)
    if word(s, 24) != get(w, S_ESEQ) or get(w, S_INPUT_ACTIVE) != 1:
        return refuse(w, 8)
    if get(w, S_NEED) == 0:
        return refuse(w, 9)
    if get(w, S_NEED) > length(w):
        return event(w, 3)
    put(w, S_NEED, 0)
    return pump(r, w)

def producer(s:readbuf, r:mutbuf, w:mutbuf) -> u32:
    if get(w, S_INPUT_ACTIVE) != 0 or get(w, S_NEED) != 0:
        return refuse(w, 10)
    if length(s) < 64 or length(s) > 65536:
        return refuse(w, 11)
    if word(s, 0) != get(w, S_PRODUCER) or word(s, 8) != get(w, S_ACTION):
        return refuse(w, 12)
    if word(s, 16) != get(w, S_PSEQ) or word(s, 24) > 1:
        return refuse(w, 13)
    if word(s, 32) != get(w, S_SERIAL) or word(s, 40) != get(w, S_SLOTS):
        return refuse(w, 14)
    if word(s, 48) != get(w, S_REQUEST) or word(s, 56) != length(s) - 64:
        return refuse(w, 15)
    copy_input(s, 0, w, INPUT_BASE, length(s))
    put(w, S_INPUT_SIZE, length(s))
    put(w, S_INPUT_AT, 64)
    put(w, S_INPUT_FINAL, word(s, 24))
    put(w, S_INPUT_ACTIVE, 1)
    return pump(r, w)

def continuation_byte(w:mutbuf, at:u64) -> u64:
    value = byte(w, at)
    return choose(value >= 128 and value <= 191, 1, 0)

def utf8(w:mutbuf, at:u64, stop:u64) -> u64:
    while at < stop:
        value = byte(w, at)
        if value < 128:
            at = at + 1
        elif value >= 194 and value <= 223:
            if stop - at < 2:
                return 0
            if continuation_byte(w, at + 1) == 0:
                return 0
            at = at + 2
        elif value >= 224 and value <= 239:
            if stop - at < 3:
                return 0
            second = byte(w, at + 1)
            if continuation_byte(w, at + 1) == 0 or continuation_byte(w, at + 2) == 0:
                return 0
            if value == 224 and second < 160:
                return 0
            if value == 237 and second >= 160:
                return 0
            at = at + 3
        elif value >= 240 and value <= 244:
            if stop - at < 4:
                return 0
            second = byte(w, at + 1)
            if continuation_byte(w, at + 1) == 0 or continuation_byte(w, at + 2) == 0:
                return 0
            if continuation_byte(w, at + 3) == 0:
                return 0
            if value == 240 and second < 144:
                return 0
            if value == 244 and second >= 144:
                return 0
            at = at + 4
        else:
            return 0
    return 1

def token_shape(r:mutbuf, w:mutbuf) -> u64:
    cursor = get(w, S_INPUT_AT)
    stop = get(w, S_INPUT_SIZE)
    if cursor > stop or stop - cursor < 16:
        return 16
    kind = get(w, INPUT_BASE + cursor)
    value = get(w, INPUT_BASE + cursor + 8)
    put(w, T_KIND, kind)
    put(w, T_VALUE, value)
    put(w, T_STOP, cursor + 16)
    put(w, T_BYTES, 0)
    put(w, T_NEED, 80)
    if kind == 0:
        if source_node(r, w, value) == 0:
            return 17
    elif kind == 1:
        if value > stop - cursor - 16:
            return 18
        if utf8(w, INPUT_BASE + cursor + 16, INPUT_BASE + cursor + 16 + value) == 0:
            return 19
        put(w, T_BYTES, value)
        put(w, T_STOP, cursor + 16 + value)
        put(w, T_NEED, 80 + ((value + 7) & 18446744073709551608))
    elif kind == 3:
        if value > 1:
            return 20
    elif kind == 4:
        if value != 0:
            return 21
    elif kind > 6:
        return 22
    return 0

def key_size(r:mutbuf, w:mutbuf, node:u64) -> u64:
    if get(w, node) == 1:
        return get(w, node + 16)
    return get(r, 64 + get(w, node + 8) + 8)

def key_byte(r:mutbuf, w:mutbuf, node:u64, at:u64) -> u64:
    if get(w, node) == 1:
        return byte(w, get(w, node + 8) + at)
    return byte(r, 64 + get(w, node + 8) + 16 + at)

def candidate_key_size(r:mutbuf, w:mutbuf) -> u64:
    if get(w, T_KIND) == 1:
        return get(w, T_BYTES)
    return get(r, 64 + get(w, T_VALUE) + 8)

def candidate_key_byte(r:mutbuf, w:mutbuf, at:u64) -> u64:
    if get(w, T_KIND) == 1:
        return byte(w, INPUT_BASE + get(w, S_INPUT_AT) + 16 + at)
    return byte(r, 64 + get(w, T_VALUE) + 16 + at)

def same_candidate_key(r:mutbuf, w:mutbuf, node:u64) -> u64:
    size = candidate_key_size(r, w)
    if key_size(r, w, node) != size:
        return 0
    i = 0
    while i < size:
        left = key_byte(r, w, node, i)
        right = candidate_key_byte(r, w, i)
        if left != right:
            return 0
        i = i + 1
    return 1

def key_valid(r:mutbuf, w:mutbuf, parent:u64) -> u64:
    kind = get(w, T_KIND)
    if kind != 1:
        if kind != 0:
            return 0
        if get(r, 64 + get(w, T_VALUE)) != 4:
            return 0
    previous = get(w, parent + 24)
    while previous != 0:
        if same_candidate_key(r, w, previous) != 0:
            return 0
        value = get(w, previous + 48)
        if value == 0:
            return 0
        previous = get(w, value + 48)
    return 1

def token_position(r:mutbuf, w:mutbuf) -> u64:
    parent = get(w, S_TOP)
    if parent == 0:
        if get(w, S_ROOT) != 0:
            return 23
        return 0
    if get(w, parent + 56) == 0:
        return 24
    if get(w, parent) == 6 and get(w, parent + 64) == 0:
        if key_valid(r, w, parent) == 0:
            return 25
    return 0

def reserve_node(w:mutbuf) -> u64:
    cursor = get(w, S_CURSOR)
    size = get(w, T_NEED)
    if cursor < ARENA_BASE or cursor > length(w):
        return 0
    if size > U64_MAX - cursor:
        return 0
    if size > length(w) - cursor:
        put(w, S_NEED, cursor + size)
        return 2
    return 1

def fill_node(w:mutbuf) -> u64:
    node = get(w, S_CURSOR)
    kind = get(w, T_KIND)
    value = get(w, T_VALUE)
    fill_range(w, node, 80, 0)
    put(w, node, kind)
    if kind == 1:
        put(w, node + 8, node + 80)
        put(w, node + 16, get(w, T_BYTES))
        move_output(w, INPUT_BASE + get(w, S_INPUT_AT) + 16, node + 80, get(w, T_BYTES))
        put(w, node + 72, 1)
    elif kind >= 5:
        put(w, node + 16, value)
        put(w, node + 56, value)
    else:
        put(w, node + 8, value)
        put(w, node + 72, 1)
    put(w, S_CURSOR, node + get(w, T_NEED))
    put(w, S_NODES, get(w, S_NODES) + 1)
    return node

def attach(w:mutbuf, node:u64) -> u64:
    parent = get(w, S_TOP)
    if parent == 0:
        put(w, S_ROOT, node)
    else:
        put(w, node + 40, parent)
        previous = get(w, parent + 32)
        if previous == 0:
            put(w, parent + 24, node)
        else:
            put(w, previous + 48, node)
        put(w, parent + 32, node)
        if get(w, parent) == 5:
            put(w, parent + 56, get(w, parent + 56) - 1)
        elif get(w, parent + 64) == 0:
            put(w, parent + 64, 1)
        else:
            put(w, parent + 64, 0)
            put(w, parent + 56, get(w, parent + 56) - 1)
    if get(w, node) >= 5:
        put(w, S_TOP, node)
    return 0

def close_containers(w:mutbuf) -> u64:
    parent = get(w, S_TOP)
    going = True
    while going:
        if parent == 0:
            going = False
        elif get(w, parent + 56) != 0:
            going = False
        else:
            if get(w, parent + 64) != 0:
                return 0
            put(w, parent + 72, 1)
            parent = get(w, parent + 40)
            put(w, S_TOP, parent)
    return 1

def pump(r:mutbuf, w:mutbuf) -> u32:
    while get(w, S_INPUT_AT) < get(w, S_INPUT_SIZE):
        error = token_shape(r, w)
        if error != 0:
            return refuse(w, error)
        error = token_position(r, w)
        if error != 0:
            return refuse(w, error)
        reserved = reserve_node(w)
        if reserved == 0 or get(w, S_NODES) == U64_MAX:
            return refuse(w, 26)
        if reserved == 2:
            return event(w, 3)
        node = fill_node(w)
        attach(w, node)
        put(w, S_INPUT_AT, get(w, T_STOP))
        if close_containers(w) == 0:
            return refuse(w, 27)
    if get(w, S_INPUT_AT) != get(w, S_INPUT_SIZE):
        return refuse(w, 28)
    if get(w, S_INPUT_FINAL) != 0:
        if get(w, S_ROOT) == 0 or get(w, S_TOP) != 0:
            return refuse(w, 29)
    if get(w, S_PSEQ) == U64_MAX:
        return refuse(w, 30)
    put(w, S_PSEQ, get(w, S_PSEQ) + 1)
    put(w, S_INPUT_ACTIVE, 0)
    if get(w, S_INPUT_FINAL) != 0:
        put(w, S_STATUS, 2)
        return event(w, 5)
    return event(w, 1)
'''


class SpanBuilder(Builder):
    """Lower two existing range-copy operations; no new compiler primitive."""

    def expr(self, expression):
        if isinstance(expression, ast.Call) and isinstance(expression.func, ast.Name):
            name = expression.func.id
            if name == "copy_input":
                source, start, target, destination, size = [
                    self.expr(value) for value in expression.args
                ]
                return self.op("buffer.copy_range", [
                    target, source, self.cast(destination, "usize"),
                    self.cast(start, "usize"), self.cast(size, "usize"),
                ])
            if name == "move_output":
                target, start, destination, size = [
                    self.expr(value) for value in expression.args
                ]
                return self.op("buffer.move_within", [
                    target, self.cast(destination, "usize"),
                    self.cast(start, "usize"), self.cast(size, "usize"),
                ])
        return super().expr(expression)


def source_program():
    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id in CONSTANTS:
                return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node)
            return node

    tree = ast.fix_missing_locations(Expand().visit(ast.parse(SOURCE)))
    return ast.unparse(tree) + "\n"


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: "f" + str(i) for i, node in enumerate(nodes)}
    signatures = {
        node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
        for node in nodes
    }
    total = total_scalar_functions(nodes)
    functions = []
    for node in nodes:
        builder = SpanBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({
            "name": names[node.name],
            "params": [builder.param(value) for value in builder.params],
            "returns": [builder.returns],
            "effects": ["read", "write", "trap"],
            "entry": "b0",
            "blocks": builder.blocks,
        })
    return compact_authoring_cfg({
        "schema": "hepta.hia.program.v8",
        "module": "composite_object_ir",
        "functions": functions,
    })


if __name__ == "__main__":
    target = Path(__file__).resolve().parents[1] / (
        "examples/hia_bootstrap/composite_object_ir.hiaasm"
    )
    target.write_text(render_assembly(document()))
    print(target.name, target.stat().st_size)
