"""Fresh actual IR tests with unchanged development CPU/address limits."""
from pathlib import Path
import hashlib,importlib.util,json,os,resource,sys,time,unittest
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
MAIN=ROOT.parent/'Hepta'
sys.path.insert(0,str(MAIN))
directory=Path('/dev/shm/hia-object-ir-development/tests-r3')
directory.mkdir(parents=True,exist_ok=False)
source=ROOT/'tests/test_hia_composite_object_ir.py'
raw=source.read_bytes();(directory/'test-source.py').write_bytes(raw)
os.environ['HEPTA_HIA_OBJECT_IR_EVIDENCE']=str(directory/'actual')
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
spec=importlib.util.spec_from_file_location('actual_object_ir_tests',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
start=time.monotonic()
result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'scope':'METADATA_OBJECT_TOKEN_IR_WITH_SOURCE_ALIASES_DEVELOPMENT_NOT_WHOLE_DRIVER_OR_COLD',
    'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
    'skips':len(result.skipped),'expected_failures':len(result.expectedFailures),
    'unexpected_successes':len(result.unexpectedSuccesses),'elapsed_seconds':time.monotonic()-start,
    'test_source_sha256':hashlib.sha256(raw).hexdigest(),'test_source_unchanged':source.read_bytes()==raw,
    'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(directory/'result.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(ROOT/'development/object-ir-tests-r3-summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report),flush=True)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses else 1)
