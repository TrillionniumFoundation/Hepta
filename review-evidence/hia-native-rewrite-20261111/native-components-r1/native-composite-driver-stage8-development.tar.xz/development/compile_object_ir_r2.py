"""Compile the new complete metadata IR consumer using the retained B3."""
from pathlib import Path
import hashlib,json,sys,traceback
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
MAIN=ROOT.parent/'Hepta'
sys.path.insert(0,str(MAIN))
from tools.qualify_hia_selfhost import compile_stage
digest=lambda b:hashlib.sha256(b).hexdigest()
base=ROOT/'checkpoints/object-ir-source-r2'
base.mkdir(exist_ok=False)
rows=[]
for rel in ('tools/generate_hia_composite_object_ir.py','docs/HIA_COMPOSITE_OBJECT_TOKEN_IR.md',
            'examples/hia_bootstrap/composite_object_ir.hiaasm'):
    raw=(ROOT/rel).read_bytes();p=base/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    rows.append({'path':rel,'bytes':len(raw),'sha256':digest(raw)})
(base/'source.json').write_text(json.dumps({'scope':'DEV_SOURCE_NOT_COLD_QUALIFIED','files':rows},indent=2,sort_keys=True)+'\n')
compiler=ROOT.parent/'hia-f50-compiler-custody/B3.image.bin'
expected='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
assert digest(compiler.read_bytes())==expected
source=base/'examples/hia_bootstrap/composite_object_ir.hiaasm'
raw=source.read_bytes()
directory=Path('/dev/shm/hia-object-ir-development/compile-r2')
directory.mkdir(parents=True,exist_ok=False)
try:
    image,receipt=compile_stage(directory,'composite-object-ir',compiler,raw)
    assert source.read_bytes()==raw and digest(compiler.read_bytes())==expected
    assert all(digest((ROOT/row['path']).read_bytes())==row['sha256'] for row in rows)
    manifest={'schema':'hepta.hia.composite-object-ir-native.v1','source_sha256':digest(raw),
        'image_path':image.name,'image_sha256':digest(image.read_bytes()),'compiler_sha256':expected}
    (directory/'composite-object-ir.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    result={'scope':'DEV_ONLY_NOT_COLD_OR_WHOLE_DRIVER','status':'PASS','source':str(source),
        'manifest':manifest,'receipt':receipt,'source_unchanged':True}
except BaseException as exc:
    traceback.print_exc()
    result={'scope':'DEV_ONLY_NOT_COLD_OR_WHOLE_DRIVER','status':'FAIL','source':str(source),
        'source_sha256':digest(raw),'class':type(exc).__name__,'error':str(exc)}
(directory/'summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(ROOT/'development/object-ir-compile-r2-summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
