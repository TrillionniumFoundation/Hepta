"""Freeze the complete IR component and all actual development attempts."""
from pathlib import Path
import hashlib,json,stat,tarfile,shutil
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
BASE=ROOT/'checkpoints/stage8'
BASE.mkdir(exist_ok=False)
paths={}
def add(path,name):
    if not path.is_file() or path.is_symlink():raise RuntimeError(str(path))
    if name in paths and paths[name]!=path:raise RuntimeError(name)
    paths[name]=path
for rel in ('docs/HIA_COMPOSITE_OBJECT_TOKEN_IR.md','tools/generate_hia_composite_object_ir.py',
            'examples/hia_bootstrap/composite_object_ir.hiaasm','tests/test_hia_composite_object_ir.py',
            'development/package_stage8.py'):
    add(ROOT/rel,rel)
for pattern in ('development/object-ir-*','development/generate_object_ir_*.py',
                'development/compile_object_ir_*.py','development/run_object_ir_*.py',
                'checkpoints/object-ir-*'):
    for p in ROOT.glob(pattern):
        if p.is_file():add(p,p.relative_to(ROOT).as_posix())
        elif p.is_dir():
            for f in p.rglob('*'):
                if f.is_file() and '__pycache__' not in f.parts:add(f,f.relative_to(ROOT).as_posix())
native=Path('/dev/shm/hia-object-ir-development')
for p in native.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:add(p,'runtime/'+p.relative_to(native).as_posix())
issuer=json.loads((native/'tests-r3/actual/actual-packet-issuer/custody.json').read_bytes())
for name,sha in issuer['before'].items():
    p=Path(name)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
    add(p,'dependencies/packet-issuer/'+p.relative_to(ROOT).as_posix())
producer=ROOT/'development/compile-object-producer-r1'
for name in ('summary.json','render.hiaasm','stream_fixture.hiaasm',
             'object-render.image.bin','object-stream_fixture.image.bin',
             'object-render.receipt.json','object-stream_fixture.receipt.json'):
    add(producer/name,'dependencies/native-producer/'+name)
rows=[]
for name,path in sorted(paths.items()):
    raw=path.read_bytes()
    rows.append({'path':name,'origin':str(path),'bytes':len(raw),
        'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode)})
manifest=BASE/'source.json'
manifest.write_text(json.dumps({'scope':'COMPLETE_GENERIC_METADATA_IR_DEVELOPMENT_NOT_WHOLE_DRIVER_OR_COLD',
    'members':rows,'member_count':len(rows),'raw_bytes':sum(r['bytes'] for r in rows)},indent=2,sort_keys=True)+'\n')
archive=Path('/dev/shm/native-composite-driver-stage8-development.tar.xz')
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for row in rows:tar.add(paths[row['path']],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    assert [m.name for m in tar.getmembers()]==[r['path'] for r in rows]
    for row in rows:
        m=tar.getmember(row['path']);raw=tar.extractfile(m).read();p=paths[row['path']]
        assert raw==p.read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        assert stat.S_IMODE(m.mode)==row['mode']==stat.S_IMODE(p.stat().st_mode)
raw=archive.read_bytes()
persistent=BASE/archive.name
persistent.write_bytes(raw)
assert persistent.read_bytes()==raw
report={'archive':str(archive),'persistent_archive':str(persistent),'bytes':len(raw),
    'sha256':hashlib.sha256(raw).hexdigest(),'member_count':len(rows),
    'raw_bytes':sum(r['bytes'] for r in rows),'source_manifest':str(manifest),
    'source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'every_member_original_bytes_sha256_and_mode_equal':True,
    'persistent_archive_bytes_readback_equal':True}
out=BASE/'custody.json';out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report),flush=True)
print(json.dumps({'custody':str(out),'bytes':out.stat().st_size,
    'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}),flush=True)
