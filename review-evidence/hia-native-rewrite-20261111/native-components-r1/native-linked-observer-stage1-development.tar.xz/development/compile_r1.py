"""Development execution of a new HIA-emitted linked-observer, original limits."""
from pathlib import Path
import hashlib
import json
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
DEPENDENCIES = ROOT.parent / 'native-agent-state-integration'
sys.path[:0] = [str(ROOT), str(DEPENDENCIES)]
from tools import generate_hia_linked_observer as gen
from tools import hia_selfhost_linked_observer as observer

digest = lambda data: hashlib.sha256(data).hexdigest()
directory = Path('/dev/shm/hia-linked-observer-development/compile-r1')
directory.mkdir(parents=True, exist_ok=False)
gen.main()
frozen = ROOT / 'checkpoints/source-r1'
frozen.mkdir(exist_ok=False)
rows = []
for relative in ('tools/generate_hia_linked_observer.py', 'tools/hia_selfhost_linked_observer.py',
        'tools/hia_linked_observer_template.S', 'examples/hia_bootstrap/linked_observer_packer.hiaasm'):
    source = ROOT / relative
    raw = source.read_bytes()
    target = frozen / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append({'path': relative, 'bytes': len(raw), 'sha256': digest(raw)})
source = {'scope': 'DEVELOPMENT_ONLY_NO_CURRENT_COLD_CLOSURE', 'files': rows,
    'dependency_root': str(DEPENDENCIES), 'candidate_commit': 'd5da1eb760454ef3df5153c5e80eb046ddb389d9'}
(frozen / 'source.json').write_text(json.dumps(source, indent=2, sort_keys=True) + '\n')
compiler = ROOT.parent / 'hia-f50-compiler-custody/B3.image.bin'
compiler_pin = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
assert digest(compiler.read_bytes()) == compiler_pin
try:
    reference = observer.independent_reference(before_B0=False)
    reference['development_reference_before_new_packer_compilation'] = True
    (directory / 'independent-reference.json').write_text(json.dumps(reference, indent=2, sort_keys=True) + '\n')
    image, build = observer.build(directory, compiler, reference)
    assert image.read_bytes() == gen.reference_image()
    assert digest(compiler.read_bytes()) == compiler_pin
    assert all(digest((ROOT / row['path']).read_bytes()) == row['sha256'] for row in rows)
    result = {'status': 'PASS', 'scope': source['scope'], 'compiler_sha256': compiler_pin,
        'image': str(image), 'image_bytes': image.stat().st_size,
        'image_sha256': digest(image.read_bytes()), 'source_unchanged': True,
        'native_compilation': build['native_compilation'], 'native_emission': build['native_emission'],
        'vm_windows': len(reference['vm_windows']), 'before_current_cold_B0': False}
except BaseException as exc:
    traceback.print_exc()
    result = {'status': 'FAIL', 'scope': source['scope'], 'class': type(exc).__name__, 'error': str(exc)}
(directory / 'summary.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
(ROOT / 'development/compile-r1-summary.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
