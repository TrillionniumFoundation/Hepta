from pathlib import Path
import hashlib
import json
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT.parent / 'native-agent-state-integration')]
from tools import hia_selfhost_linked_observer as new
from tools.qualify_hia_selfhost import invoke as old

directory = Path('/dev/shm/hia-linked-observer-development/smoke-r1')
directory.mkdir(exist_ok=False)
observer = Path('/dev/shm/hia-linked-observer-development/compile-r1/linked-observer.elf')
source = '.intel_syntax noprefix\n.text\n.global f0\n.type f0,@function\nf0:\n mov eax,42\n ret\n.section .note.GNU-stack,"",@progbits\n'
(directory / 'foreign.S').write_text(source)
commands = [['as', '--64', '-o', str(directory / 'foreign.o'), str(directory / 'foreign.S')],
    ['ld', '-shared', '-z', 'defs', '-z', 'noexecstack', '-z', 'relro', '-z', 'now',
        '--build-id=none', '-o', str(directory / 'foreign.so'), str(directory / 'foreign.o')],
    ['readelf', '-l', '-d', str(observer)]]
records = []
try:
    for i, command in enumerate(commands):
        result = subprocess.run(command, capture_output=True)
        (directory / (str(i) + '.stdout')).write_bytes(result.stdout)
        (directory / (str(i) + '.stderr')).write_bytes(result.stderr)
        records.append({'command': command, 'exit_code': result.returncode})
        result.check_returncode()
    image = directory / 'foreign.so'
    actual, output = new.invoke(directory, 'new', observer, image, b'ABC\0\xff',
        capacity=19, workspace_size=1040, workspace_fill=90)
    expected, old_output = old(directory, 'old', image, b'ABC\0\xff', image_format='linked-selfhost',
        capacity=19, workspace_size=1040, workspace_fill=90)
    compared = ('status', 'result_u64', 'abi_status', 'core_u32', 'source_sha256', 'output_sha256',
        'source_unchanged', 'output_unchanged', 'workspace_header', 'limits', 'return_encoding')
    assert actual['status'] == 'returned', actual
    for key in compared:
        assert actual[key] == expected[key], (key, actual.get(key), expected.get(key))
    assert actual['core_u32'] == 42 and output == old_output
    summary = {'status': 'PASS', 'scope': 'DEVELOPMENT_ONLY', 'compared': compared,
        'commands': records, 'actual': actual, 'legacy': expected,
        'observer_sha256': hashlib.sha256(observer.read_bytes()).hexdigest()}
except BaseException as exc:
    traceback.print_exc()
    summary = {'status': 'FAIL', 'scope': 'DEVELOPMENT_ONLY', 'class': type(exc).__name__,
        'error': str(exc), 'commands': records}
(directory / 'summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
(ROOT / 'development/smoke-r1-summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
