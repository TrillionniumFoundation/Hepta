"""Actual six-operation request projection; Python only supplies test oracles."""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import random
import struct
import unittest

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT=Path(__file__).resolve().parents[1]
GENERATOR=ROOT/'tools/generate_hia_composite_type_requests.py'
SOURCE=ROOT/'examples/hia_bootstrap/composite_type_requests.hiaasm'
FROZEN=ROOT/'checkpoints/type-requests-source-r2/examples/hia_bootstrap/composite_type_requests.hiaasm'
MANIFEST=Path('/dev/shm/hia-type-requests-development/compile-r2/composite-type-requests.manifest.json')
SOURCE_SHA='19763a18d8508d5f5fcadddf059ef5e216e7f9b2163d4d3b2fccf7b8ccf1a768'
BAD=0xfffffffd
MAGIC=lambda b:int.from_bytes(b,'little')
CONFIG,EVENT=map(MAGIC,(b'HIASVP01',b'HIASVE01'))
CTOR_MAGIC=MAGIC(b'HIACTK01')
FN_MAGIC=MAGIC(b'HIAFNC01')
CANARY=b'\xa5'*32


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


class Ref:
    def __init__(self,offset):self.offset=offset


def wire_tokens(ir,value):
    if isinstance(value,Ref):return [ir.token(0,value.offset)]
    if type(value) is list:return [ir.token(5,len(value))]+[t for child in value for t in wire_tokens(ir,child)]
    if type(value) is dict:return [ir.token(6,len(value))]+[t for key,item in value.items() for t in [ir.string(key)]+wire_tokens(ir,item)]
    return ir.tokens(value)


def dereference(value,nodes):
    if isinstance(value,Ref):return nodes[value.offset]
    if type(value) is list:return [dereference(v,nodes) for v in value]
    if type(value) is dict:return {k:dereference(v,nodes) for k,v in value.items()}
    return value


def expected(context,command,registry):
    kind=command[0]
    if kind==1:return {'op':'init','definitions':command[1],'recursive_chain':command[2],'partial_records':command[3]}
    if kind==2:return {'op':'parameters','params':command[1]}
    if kind==3:return {'op':'resolve','ref':command[1]}
    if kind==4 and context==2:return {'op':'partial','base':command[1],'initialized':list(command[2])}
    if kind==4:
        result={'op':'origins','params':command[2],'returns':command[3]}
        if 'return_loans' in command[1]:result['return_loans']=command[1]['return_loans']
        return result
    rows=command[2] if context==1 else registry
    return {'op':'task_protocol','task':command[1],
        'functions':[[row[0],[value for _,value in row[1]],list(row[2])] for row in rows]}


class ActualRequests:
    def __init__(self,directory):
        self.pins={}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes();digest=sha256(raw).hexdigest()
            if str(path) in self.pins and self.pins[str(path)]!=digest:raise AssertionError('admission race')
            self.pins[str(path)]=digest
            return raw
        manifest=json.loads(read(MANIFEST));source=read(SOURCE);frozen=read(FROZEN)
        image=read(MANIFEST.parent/manifest['image_path'])
        if (set(manifest)!={'schema','source_sha256','image_path','image_sha256','compiler_sha256'}
            or manifest['schema']!='hepta.hia.composite-type-requests-native.v1'
            or source!=frozen or sha256(source).hexdigest()!=SOURCE_SHA
            or manifest['source_sha256']!=SOURCE_SHA or manifest['image_sha256']!=sha256(image).hexdigest()
            or manifest['compiler_sha256']!='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'):
            raise AssertionError('component/source/image mismatch')
        read(GENERATOR);read(__file__)
        if any(sha256(Path(p).read_bytes()).hexdigest()!=h for p,h in self.pins.items()):
            raise AssertionError('source changed before image or evidence')
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=False)
        self.image=NativeHiaJsonImage(image,manifest['image_sha256'])
        self.ir_module=module('issued_metadata_ir',ROOT/'tests/test_hia_composite_object_ir.py')
        self.ir=self.ir_module.ActualIR(self.directory/'actual-ir')
        self.log=(self.directory/'actual-type-request-ledger.jsonl').open('w')
        self.entries=0;self.cases=0

    def issue(self,label,context,command,*,source=None,registry=None,split=65472):
        registry=[] if registry is None else registry
        source=([{},False] if context==1 else [{},registry,[],0,0,False,0]) if source is None else source
        self.cases+=1
        kind=command[0]
        serial,slots=(0,0) if context==1 else (100,4)
        s=self.ir.session(label,source,action=kind,request=self.cases,serial=serial,slots=slots)
        producer=CTOR_MAGIC if context==1 else FN_MAGIC
        s.init=struct.pack('<8Q',self.ir_module.INIT,s.lease,s.stream,producer,kind,s.request,serial,slots)
        if s.initialize()[0]==BAD:raise AssertionError('native IR refused source')
        parts=self.ir_module.chunks(wire_tokens(self.ir_module,command),split)
        for i,payload in enumerate(parts):
            raw=struct.pack('<8Q',producer,kind,i,int(i+1==len(parts)),serial,slots,s.request,len(payload))+payload
            if s.finish(s.call(raw,'original-producer'))[0]==BAD:raise AssertionError('native IR refused metadata')
        return s,expected(context,dereference(command,s.nodes),registry)

    def invocation(self,label,context,command,**kwargs):
        session,oracle=self.issue(label,context,command,**kwargs)
        return Invocation(self,label,context,session),oracle

    def close(self):
        self.ir.close();self.log.close()
        after={p:sha256(Path(p).read_bytes()).hexdigest() for p in self.pins}
        report={'scope':'COMPLETE_TYPES_REQUEST_PROJECTION_DEV_NOT_WHOLE_DRIVER_OR_COLD',
            'entries':self.entries,'cases':self.cases,'before':self.pins,'after':after,
            'sources_unchanged':after==self.pins}
        (self.directory/'custody.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        if after!=self.pins:raise AssertionError('projection source drift')


class Invocation:
    def __init__(self,native,label,context,session,*,size=512):
        self.native=native;self.label=label;self.session=session
        self.size=size;self.work=ctypes.create_string_buffer(size+len(CANARY))
        ctypes.memset(ctypes.addressof(self.work)+size,0xa5,len(CANARY))
        config=[CONFIG,context,session.action,session.lease,session.stream,session.request]+[0]*10
        struct.pack_into('<16Q',self.work,128,*config)
        self.growths=0;self.last=None

    def call(self,label='entry',*,extent=None):
        s=self.session
        before_ir=bytes(s.work[:s.size]);before_source=bytes(s.source[:len(s.source_wire)])
        result=self.native.image._entry(s.work,s.size,s.source,len(s.source_wire),self.work,
                                        self.size if extent is None else extent)
        self.native.entries+=1
        unchanged=bytes(s.work[:s.size])==before_ir and bytes(s.source[:len(s.source_wire)])==before_source
        guards=(bytes(s.work[s.size:s.size+len(CANARY)])==CANARY
            and bytes(s.source[len(s.source_wire):len(s.source_wire)+len(CANARY)])==CANARY
            and bytes(self.work[self.size:self.size+len(CANARY)])==CANARY)
        if not unchanged or not guards:raise AssertionError('projection mutated read lease/canary')
        header=struct.unpack_from('<16Q',self.work)
        payload=None
        if result!=BAD:
            if result!=128 or header[0]!=EVENT or header[11:]!=(0,0,0,0,0):
                raise AssertionError(('bad projection frame',header))
            if header[1]==0:
                payload=bytes(self.work[header[7]:header[7]+header[8]])
                if header[7]+header[8]>self.size or header[9]!=header[7]+header[8]:
                    raise AssertionError('bad projection payload extent')
        row={'case':self.label,'call':label,'entry':self.native.entries,'return':result,
            'header':header,'capacity':self.size,'inputs_unchanged':unchanged,'canaries_unchanged':guards,
            'ir_bytes':s.size,'ir_sha256':sha256(before_ir).hexdigest(),
            'source_lease_bytes':len(before_source),'source_lease_sha256':sha256(before_source).hexdigest(),
            'packet_bytes':len(payload) if payload is not None else None,
            'packet_sha256':sha256(payload).hexdigest() if payload is not None else None}
        if payload is not None and len(payload)<=65536:row['packet_base64']=base64.b64encode(payload).decode()
        self.native.log.write(json.dumps(row,sort_keys=True)+'\n');self.native.log.flush()
        self.last=header
        return result,header,payload

    def grow(self,needed):
        if needed<=self.size:raise AssertionError('nonincreasing projection growth')
        old=self.work;self.work=ctypes.create_string_buffer(needed+len(CANARY))
        ctypes.memmove(self.work,old,self.size)
        self.size=needed;self.growths+=1
        ctypes.memset(ctypes.addressof(self.work)+needed,0xa5,len(CANARY))

    def run(self):
        result=self.call()
        while result[0]!=BAD and result[1][1]==1:
            self.grow(result[1][9]);result=self.call('resumed')
        return result


class TypeRequestSourceTests(unittest.TestCase):
    def test_fixed_source_and_compiler_limits(self):
        doc=module('request_authoring',GENERATOR).document()
        self.assertEqual(render_assembly(doc).encode(),SOURCE.read_bytes())
        self.assertEqual(SOURCE.read_bytes(),FROZEN.read_bytes())
        self.assertLessEqual(len(doc['functions']),128)
        self.assertLessEqual(sum(len(f['blocks']) for f in doc['functions']),1536)
        self.assertLessEqual(max(len(f['blocks']) for f in doc['functions']),256)
        self.assertLessEqual(max(len(b['params']) for f in doc['functions'] for b in f['blocks']),16)


class TypeRequestNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        directory=os.environ.get('HEPTA_HIA_TYPE_REQUEST_EVIDENCE')
        if not directory:raise AssertionError('fresh evidence required; no skip')
        cls.native=ActualRequests(directory)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def exact(self,label,context,command,**kwargs):
        invocation,oracle=self.native.invocation(label,context,command,**kwargs)
        result,header,payload=invocation.run()
        self.assertNotEqual(result,BAD,(label,header))
        self.assertEqual(header[1],0)
        self.assertEqual(payload,transport(oracle),label)
        decoded,_=detached_packet_index(payload)
        self.assertEqual(decoded,oracle)
        self.assertEqual(list(decoded),list(oracle))
        # Actual packet owner creates the exact JSON sent to the types owner.
        expected_json=json.dumps(oracle,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
        _,_,actual,index,state=self.native.ir.issuer.encode('normalized-'+label,payload)
        self.assertEqual(actual,expected_json,label)
        return invocation,payload

    def test_all_six_ops_and_every_constructor_function_route(self):
        rows=[['poll',[['p',16],['empty',17]],[5,12],{}],['cancel',[['s',17]],[],{}]]
        constructor=[[1,[],False,False],[2,[{'name':'a','type':'u32'}]],[3,{'name':'Box','args':['u32']}],
            [4,{},[['p',16]],[16]],[5,17,rows]]
        for cmd in constructor:self.exact('ctor-'+str(cmd[0]),1,cmd)
        function=[[2,[]],[3,'u32'],[4,17,['left','right']],[5,17]]
        for cmd in function:self.exact('fn-'+str(cmd[0]),2,cmd,registry=[r[:3] for r in rows])
        for flags in [(False,True),(True,False),(True,True)]:
            self.exact('init-flags-'+str(flags),1,[1,[{'name':'a','fields':[]}],*flags])

    def test_origins_field_presence_registry_order_and_u64_values(self):
        for function in [{},{'return_loans':None},{'return_loans':[]},
                         {'x':0,'return_loans':[['p',['field']]],'y':1}]:
            self.exact('origins-'+str(len(function)),1,[4,function,[['p',16]],[16]])
        values=[0,1,9,10,99,100,1<<63,(1<<64)-1]
        for value in values:self.exact('uint-'+str(value),2,[3,value])
        rows=[['z',[['b',5],['a',6]],[7,8],{}],['a',[],[12],{}]]
        self.exact('registry-order',1,[5,17,rows])

    def test_source_reference_commands_and_discarded_large_function_alias(self):
        fn={'name':'kept','body':'x'*(600<<10)}
        source=[{'function':fn,'definitions':[{'kind':'record','name':'Empty','fields':[]}]},False]
        _,_,nodes=self.native.ir.source(source)
        fn_at=next(at for at,value in nodes.items() if type(value) is dict and value.get('name')=='kept')
        defs_at=next(at for at,value in nodes.items() if type(value) is list and value and type(value[0]) is dict and value[0].get('name')=='Empty')
        self.exact('init-source-ref',1,[1,Ref(defs_at),True,True],source=source)
        rows=[['f'+str(i),[['p',5]],[5],Ref(fn_at)] for i in range(20)]
        invocation,payload=self.exact('registry-fn-alias',1,[5,17,rows],source=source)
        self.assertLess(len(payload),10000)
        self.assertGreater(len(json.dumps(dereference(rows,nodes)).encode()),8<<20)
        self.assertLess(invocation.size,100000)

    def test_long_parameter_and_return_vectors_have_no_private_mini_limit(self):
        params=[['p'+str(i),5] for i in range(4096)]
        returns=[5]*4096
        registry=[['only',params,returns,{}]]
        self.exact('many-origins',1,[4,{},params,returns],split=4096)
        self.exact('many-task-ctor',1,[5,17,registry],split=4096)
        self.exact('many-task-function',2,[5,17],registry=[row[:3] for row in registry])

    def test_complete_shape_rejections_before_types_entry(self):
        invalid=[(1,[1,[],0,False]),(1,[1,[],True]),(1,[2,[],0]),
            (1,[3]),(1,[4,None,[],[]]),(1,[4,{},[['p']],[]]),
            (1,[4,{},[['p',True]],[]]),(1,[4,{},[],[False]]),
            (1,[5,17,[['a',[],[],{}],['a',[],[],{}]]]),
            (1,[5,17,[['a',[],[],None]]]),(1,[5,17,[['a',[['p','u32']],[],{}]]]),
            (2,[4,17,None]),(2,[4,True,[]]),(2,[5,17,[]])]
        for i,(context,command) in enumerate(invalid):
            # Build an independent shape-invalid request; do not call the
            # convenience oracle, which would itself interpret invalid shapes.
            registry=[]
            source=[{},False] if context==1 else [{},registry,[],0,0,False,0]
            kind=command[0];self.native.cases+=1
            serial,slots=(0,0) if context==1 else (100,4)
            session=self.native.ir.session('shape-'+str(i),source,action=kind,
                request=self.native.cases,serial=serial,slots=slots)
            producer=CTOR_MAGIC if context==1 else FN_MAGIC
            session.init=struct.pack('<8Q',self.native.ir_module.INIT,session.lease,session.stream,producer,
                kind,session.request,serial,slots)
            session.initialize()
            parts=self.native.ir_module.chunks(wire_tokens(self.native.ir_module,command))
            for j,part in enumerate(parts):
                raw=struct.pack('<8Q',producer,kind,j,int(j+1==len(parts)),serial,slots,session.request,len(part))+part
                self.assertNotEqual(session.finish(session.call(raw))[0],BAD)
            invocation=Invocation(self.native,'shape-'+str(i),context,session)
            self.assertEqual(invocation.run()[0],BAD)
            self.assertEqual(invocation.call('after-refusal')[0],BAD)

    def test_growth_correlation_completion_and_invalid_short_borrow(self):
        invocation,oracle=self.native.invocation('config-grow',1,[3,'u32'])
        first=invocation.call()
        self.assertEqual(first[1][1],1)
        old=struct.unpack_from('<Q',invocation.work,168)[0]
        struct.pack_into('<Q',invocation.work,168,old+1)
        self.assertEqual(invocation.call('changed-request')[0],BAD)
        invocation,oracle=self.native.invocation('no-capacity-change',1,[3,'u32'])
        first=invocation.call();self.assertEqual(first[1][1],1)
        self.assertEqual(invocation.call('same-small-capacity')[1][1],1)
        self.assertNotEqual(invocation.run()[0],BAD)
        self.assertEqual(invocation.call('replayed-completion')[0],BAD)
        invocation,oracle=self.native.invocation('short-borrow',1,[3,'u32'])
        before=bytes(invocation.work)
        self.assertEqual(invocation.call('private-short-output',extent=511)[0],BAD)
        self.assertEqual(bytes(invocation.work),before)
        # A fixed driver must discard this lease after BAD. This private
        # restored-extent call records why a short buffer cannot store poison.
        self.assertNotEqual(invocation.run()[0],BAD)
