"""Author complete typed-packet validation, node indexing and JSON spelling.

This is generic integer-JSON transport, not nominal-language interpretation.
The caller owns an immutable source lease. The offset index cannot authenticate
an independently substituted packet. Complete validation precedes capacity
refusal; no partial JSON or partial node index grants authority.
"""
from __future__ import annotations
import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

MAGIC = int.from_bytes(b'HIAPJS01', 'little')
INPUT_LIMIT = 64 << 20
SOURCE_PATH = 'examples/hia_bootstrap/composite_packet_json.hiaasm'

SOURCE = r'''
def packet_json(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < 128:
        return 4294967293
    if length(o) < 64:
        put(w, 8, 4294967293)
        return 4294967293
    if get(w, 0) != MAGIC_VALUE:
        return fail(o, w, 4294967293, 0, 0)
    i = 8
    while i < 128:
        if get(w, i) != 0:
            return fail(o, w, 4294967293, 0, 0)
        i = i + 8
    if length(s) < 16 or length(s) > 67108864:
        return fail(o, w, 4294967293, 0, 0)
    if initialize(s, w) == 0:
        return fail(o, w, 4294967293, 0, 0)
    at = 0
    while at < length(s) or get(w, 64) != 0:
        depth = get(w, 64)
        if depth != 0 and get(w, get(w, 56) + (depth - 1) * 32 + 8) == 0:
            frame = get(w, 56) + (depth - 1) * 32
            if at != get(w, frame):
                return fail(o, w, 4294967293, at, 1)
            put(w, 64, depth - 1)
        else:
            following = validate_node(s, w, at)
            if following == 18446744073709551615:
                return fail(o, w, 4294967293, at, 2)
            at = following
    if get(w, 72) != 1 or at != length(s):
        return fail(o, w, 4294967293, at, 3)
    if get(w, 32) > length(o) - 64:
        return fail(o, w, 4294967294, at, 4)
    emit_packet(s, o, w)
    if get(w, 120) != 64 + get(w, 32):
        return fail(o, w, 4294967293, at, 5)
    put(o, 0, MAGIC_VALUE)
    put(o, 8, 0)
    put(o, 16, 64)
    put(o, 24, get(w, 32))
    put(o, 32, get(w, 24))
    put(o, 40, length(s))
    put(o, 48, get(w, 48))
    put(o, 56, get(w, 112))
    return get(w, 120)

def read(s:readbuf, at:u64) -> u64:
    value = 0
    shift = 0
    while shift < 64:
        value = value | (widen(byte(s, at + (shift >> 3))) << shift)
        shift = shift + 8
    return value

def get(w:mutbuf, at:u64) -> u64:
    value = 0
    shift = 0
    while shift < 64:
        value = value | (widen(byte(w, at + (shift >> 3))) << shift)
        shift = shift + 8
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    shift = 0
    while shift < 64:
        store(w, at + (shift >> 3), value >> shift)
        shift = shift + 8
    return 0

def widen(value:u64) -> u64:
    return value

def fail(o:mutbuf, w:mutbuf, code:u64, at:u64, reason:u64) -> u64:
    put(w, 8, code)
    put(w, 96, at)
    put(w, 104, reason)
    put(o, 0, MAGIC_VALUE)
    put(o, 8, code)
    put(o, 16, 0)
    put(o, 24, 0)
    put(o, 32, at)
    put(o, 40, reason)
    put(o, 48, 0)
    put(o, 56, 0)
    return code

def initialize(s:readbuf, w:mutbuf) -> u64:
    slots = 2
    while slots < (length(s) >> 5) * 2:
        slots = slots * 2
    index = 128 + slots * 16
    index_bytes = (length(s) + 7) >> 3
    stack = (index + index_bytes + 7) & 18446744073709551608
    frames = divide24(length(s)) + 1
    required = stack + frames * 32
    if length(w) < required:
        return 0
    put(w, 16, length(s))
    put(w, 40, slots - 1)
    put(w, 48, index)
    put(w, 56, stack)
    put(w, 80, 128)
    put(w, 88, required)
    put(w, 112, index_bytes)
    at = 128
    while at < index:
        put(w, at, 0)
        at = at + 8
    at = index
    while at < index + index_bytes:
        store(w, at, 0)
        at = at + 1
    return 1

def validate_node(s:readbuf, w:mutbuf, at:u64) -> u64:
    if at > length(s) - 16:
        return 18446744073709551615
    kind = read(s, at)
    size = read(s, at + 8)
    if size > length(s) - at - 16:
        return 18446744073709551615
    stop = at + 16 + size
    depth = get(w, 64)
    width = node_width(s, kind, at + 16, size)
    if width == 18446744073709551615:
        return width
    if depth == 0:
        if get(w, 72) != 0:
            return 18446744073709551615
        put(w, 72, 1)
    else:
        frame = get(w, 56) + (depth - 1) * 32
        if stop > get(w, frame) or get(w, frame + 8) == 0:
            return 18446744073709551615
        if get(w, frame + 16) == 6 and (get(w, frame + 8) & 1) == 0:
            if kind != 4 or unique_key(s, w, at, get(w, frame + 24)) == 0:
                return 18446744073709551615
        put(w, frame + 8, get(w, frame + 8) - 1)
    put(w, 24, get(w, 24) + 1)
    put(w, 32, get(w, 32) + width)
    store(w, get(w, 48) + (at >> 3), byte(w, get(w, 48) + (at >> 3)) | (1 << (at & 7)))
    if kind == 5 or kind == 6:
        frame = get(w, 56) + depth * 32
        if frame > get(w, 88) - 32:
            return 18446744073709551615
        put(w, frame, stop)
        put(w, frame + 8, read(s, at + 16) * choose(kind == 6, 2, 1))
        put(w, frame + 16, kind)
        put(w, frame + 24, at)
        put(w, 64, depth + 1)
        return at + 24
    return stop

def node_width(s:readbuf, kind:u64, at:u64, size:u64) -> u64:
    if kind == 0:
        return choose(size == 0, 4, 18446744073709551615)
    if kind == 1:
        if size != 1 or byte(s, at) > 1:
            return 18446744073709551615
        return choose(byte(s, at) == 1, 4, 5)
    if kind == 2:
        return integer_width(s, at, size)
    if kind == 4:
        return string_width(s, at, size)
    if kind == 5 or kind == 6:
        if size < 8:
            return 18446744073709551615
        count = read(s, at)
        if count > ((size - 8) >> choose(kind == 6, 5, 4)):
            return 18446744073709551615
        return 2 + choose(count == 0, 0, count - 1) + choose(kind == 6, count, 0)
    return 18446744073709551615

def integer_width(s:readbuf, at:u64, size:u64) -> u64:
    if size == 0:
        return 18446744073709551615
    negative = byte(s, at) == 45
    begin = at + choose(negative, 1, 0)
    digits = size - choose(negative, 1, 0)
    if digits == 0 or (byte(s, begin) == 48 and (digits != 1 or negative)):
        return 18446744073709551615
    i = begin
    while i < at + size:
        if byte(s, i) < 48 or byte(s, i) > 57:
            return 18446744073709551615
        i = i + 1
    return size
'''

HELPERS = r'''
def divide24(value:u64) -> u64:
    # Only admitted input extents (at most 2^26) reach this exact quotient.
    quotient = 0
    remainder = 0
    bit = 27
    while bit != 0:
        bit = bit - 1
        remainder = (remainder << 1) | ((value >> bit) & 1)
        if remainder >= 24:
            remainder = remainder - 24
            quotient = quotient | (1 << bit)
    return quotient

def string_width(s:readbuf, at:u64, size:u64) -> u64:
    if utf8(s, at, size) == 0:
        return 18446744073709551615
    width = size + 2
    i = at
    while i < at + size:
        unit = byte(s, i)
        if unit < 32:
            width = width + choose(unit == 8 or unit == 9 or unit == 10 or unit == 12 or unit == 13, 1, 5)
        elif unit == 34 or unit == 92:
            width = width + 1
        i = i + 1
    return width

def utf8(s:readbuf, start:u64, size:u64) -> u64:
    i = start
    end = start + size
    while i < end:
        a = byte(s, i)
        if a < 128:
            i = i + 1
        else:
            need = 0
            lower = 128
            upper = 191
            if a >= 194 and a <= 223:
                need = 2
            elif a >= 224 and a <= 239:
                need = 3
                if a == 224:
                    lower = 160
                if a == 237:
                    upper = 159
            elif a >= 240 and a <= 244:
                need = 4
                if a == 240:
                    lower = 144
                if a == 244:
                    upper = 143
            if need == 0 or need > end - i:
                return 0
            if byte(s, i + 1) < lower or byte(s, i + 1) > upper:
                return 0
            j = 2
            while j < need:
                if byte(s, i + j) < 128 or byte(s, i + j) > 191:
                    return 0
                j = j + 1
            i = i + need
    return 1

def same_key(s:readbuf, left:u64, right:u64) -> u64:
    size = read(s, left + 8)
    if size != read(s, right + 8):
        return 0
    i = 0
    while i < size:
        if byte(s, left + 16 + i) != byte(s, right + 16 + i):
            return 0
        i = i + 1
    return 1

def unique_key(s:readbuf, w:mutbuf, at:u64, parent:u64) -> u64:
    hash = 1469598103934665603 ^ parent
    size = read(s, at + 8)
    i = 0
    while i < size:
        hash = (hash ^ byte(s, at + 16 + i)) * 1099511628211
        i = i + 1
    mask = get(w, 40)
    slot = hash & mask
    probes = 0
    while probes <= mask:
        entry = get(w, 80) + slot * 16
        previous = get(w, entry)
        if previous == 0:
            put(w, entry, at + 1)
            put(w, entry + 8, parent)
            return 1
        if get(w, entry + 8) == parent and same_key(s, previous - 1, at) == 1:
            return 0
        slot = (slot + 1) & mask
        probes = probes + 1
    return 0

def append(o:mutbuf, w:mutbuf, value:u64) -> u64:
    at = get(w, 120)
    store(o, at, value)
    put(w, 120, at + 1)
    return 0

def literal(o:mutbuf, w:mutbuf, value:u64, size:u64) -> u64:
    i = 0
    while i < size:
        append(o, w, value >> (i * 8))
        i = i + 1
    return 0

def hex_digit(value:u64) -> u64:
    return choose(value < 10, value + 48, value + 87)

def emit_string(s:readbuf, o:mutbuf, w:mutbuf, at:u64, size:u64) -> u64:
    append(o, w, 34)
    i = 0
    while i < size:
        value = byte(s, at + i)
        if value < 32:
            append(o, w, 92)
            escape = 0
            if value == 8:
                escape = 98
            elif value == 9:
                escape = 116
            elif value == 10:
                escape = 110
            elif value == 12:
                escape = 102
            elif value == 13:
                escape = 114
            if escape != 0:
                append(o, w, escape)
            else:
                append(o, w, 117)
                append(o, w, 48)
                append(o, w, 48)
                append(o, w, hex_digit(value >> 4))
                append(o, w, hex_digit(value & 15))
        else:
            if value == 34 or value == 92:
                append(o, w, 92)
            append(o, w, value)
        i = i + 1
    append(o, w, 34)
    return 0

def parent_prefix(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    depth = get(w, 64)
    if depth == 0:
        return 0
    frame = get(w, 56) + (depth - 1) * 32
    remaining = get(w, frame + 8)
    count = read(s, get(w, frame + 24) + 16)
    if get(w, frame + 16) == 6:
        if (remaining & 1) == 1:
            append(o, w, 58)
        elif remaining != count * 2:
            append(o, w, 44)
    elif remaining != count:
        append(o, w, 44)
    put(w, frame + 8, remaining - 1)
    return 0

def emit_packet(s:readbuf, o:mutbuf, w:mutbuf) -> u64:
    at = 0
    put(w, 64, 0)
    put(w, 120, 64)
    while at < length(s) or get(w, 64) != 0:
        depth = get(w, 64)
        if depth != 0 and get(w, get(w, 56) + (depth - 1) * 32 + 8) == 0:
            frame = get(w, 56) + (depth - 1) * 32
            append(o, w, choose(get(w, frame + 16) == 6, 125, 93))
            put(w, 64, depth - 1)
        else:
            parent_prefix(s, o, w)
            kind = read(s, at)
            size = read(s, at + 8)
            if kind == 5 or kind == 6:
                append(o, w, choose(kind == 6, 123, 91))
                frame = get(w, 56) + depth * 32
                put(w, frame, at + 16 + size)
                put(w, frame + 8, read(s, at + 16) * choose(kind == 6, 2, 1))
                put(w, frame + 16, kind)
                put(w, frame + 24, at)
                put(w, 64, depth + 1)
                at = at + 24
            else:
                emit_scalar(s, o, w, kind, at + 16, size)
                at = at + 16 + size
    return 0

def emit_scalar(s:readbuf, o:mutbuf, w:mutbuf, kind:u64, at:u64, size:u64) -> u64:
    if kind == 0:
        literal(o, w, NULL_LITERAL, 4)
    elif kind == 1:
        if byte(s, at) == 1:
            literal(o, w, TRUE_LITERAL, 4)
        else:
            literal(o, w, FALSE_LITERAL, 5)
    elif kind == 4:
        emit_string(s, o, w, at, size)
    else:
        i = 0
        while i < size:
            append(o, w, byte(s, at + i))
            i = i + 1
    return 0
'''


def source_program():
    source = SOURCE + HELPERS
    for name, value in {'MAGIC_VALUE':MAGIC, 'NULL_LITERAL':int.from_bytes(b'null','little'),
                        'TRUE_LITERAL':int.from_bytes(b'true','little'),
                        'FALSE_LITERAL':int.from_bytes(b'false','little')}.items():
        source = source.replace(name, str(value))
    return source


def document():
    nodes=ast.parse(source_program()).body
    names={node.name:'f'+str(i) for i,node in enumerate(nodes)}
    signatures={node.name:([arg.annotation.id for arg in node.args.args],node.returns.id) for node in nodes}
    total=total_scalar_functions(nodes)
    functions=[]
    for node in nodes:
        b=Builder(node,names,signatures,total);b.statements(node.body)
        functions.append({'name':names[node.name],'params':[b.param(value) for value in b.params],
                          'returns':[b.returns],'effects':['read','write','trap'],
                          'entry':'b0','blocks':b.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8',
                                 'module':'composite_packet_json','functions':functions})


def main():
    path=Path(__file__).resolve().parents[1]/SOURCE_PATH
    path.write_text(render_assembly(document()))
    print(path.name,path.stat().st_size)


if __name__=='__main__':
    main()
