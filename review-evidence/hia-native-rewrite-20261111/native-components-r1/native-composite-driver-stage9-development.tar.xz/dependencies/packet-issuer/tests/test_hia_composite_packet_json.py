"""Actual full integer typed-packet JSON/index checks; no skip path."""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import random
import struct
import subprocess
import sys
import unittest
from unittest.mock import patch

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT=Path(__file__).resolve().parents[1]
GENERATOR=ROOT/'tools/generate_hia_composite_packet_json.py'
SOURCE=ROOT/'examples/hia_bootstrap/composite_packet_json.hiaasm'
MANIFEST=ROOT/'development/compile-packet-json-r1/composite-packet-json.manifest.json'
MAGIC=int.from_bytes(b'HIAPJS01','little')
BAD,SPACE=0xfffffffd,0xfffffffe
CANARY=bytes([0xa5])*32
LIMIT=64<<20


def capacity(size):
    slots=2
    while slots<2*(size//32):
        slots*=2
    index=128+16*slots
    index_bytes=(size+7)//8
    stack=(index+index_bytes+7)&~7
    return stack+32*(size//24+1)


def packet(kind,raw):
    return struct.pack('<2Q',kind,len(raw))+raw


def container(kind,children,count=None):
    if count is None:
        count=len(children)//2 if kind==6 else len(children)
    return packet(kind,struct.pack('<Q',count)+b''.join(children))


class ActualPacketJson:
    def __init__(self,evidence):
        self.pins={}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes();digest=sha256(raw).hexdigest()
            if str(path) in self.pins and self.pins[str(path)]!=digest:
                raise AssertionError('packet writer input changed during admission')
            self.pins[str(path)]=digest
            return raw
        manifest=json.loads(read(MANIFEST))
        source=read(SOURCE)
        image=read(MANIFEST.parent/manifest['image_path'])
        if (manifest['schema']!='hepta.hia.composite-packet-json-native.v1'
                or manifest['source_sha256']!=sha256(source).hexdigest()
                or manifest['image_sha256']!=sha256(image).hexdigest()):
            raise AssertionError('packet writer source/image identity mismatch')
        read(GENERATOR);read(__file__)
        if any(sha256(Path(p).read_bytes()).hexdigest()!=digest for p,digest in self.pins.items()):
            raise AssertionError('packet writer readback mismatch before mapping')
        self.evidence=Path(evidence);self.evidence.mkdir(parents=True,exist_ok=False)
        self.image=NativeHiaJsonImage(image,manifest['image_sha256'])
        self.entries=0
        self.log=(self.evidence/'actual-packet-json-ledger.jsonl').open('w')

    def encode(self,label,raw,*,output_size=None,work_size=None,control=None,extent=None,
               return_state=False,reuse=None):
        work_size=capacity(len(raw)) if work_size is None else work_size
        output_size=64+max(16,6*len(raw)) if output_size is None else output_size
        source=ctypes.create_string_buffer(raw+CANARY)
        if reuse is None:
            output=ctypes.create_string_buffer(output_size+len(CANARY))
            work=ctypes.create_string_buffer(work_size+len(CANARY))
            ctypes.memset(output,0xa5,output_size+len(CANARY))
            ctypes.memset(ctypes.addressof(work)+work_size,0xa5,len(CANARY))
            if work_size>=128:
                struct.pack_into('<16Q',work,0,*(control or (MAGIC,)+(0,)*15))
        else:
            output,work,output_size,work_size=reuse
        result=self.image._entry(source,len(raw) if extent is None else extent,
                                 output,output_size,work,work_size)
        self.entries+=1
        readonly=memoryview(source).cast('B')[:len(raw)]==raw
        guards=(bytes(source[len(raw):len(raw)+len(CANARY)])==CANARY
                and bytes(output[output_size:output_size+len(CANARY)])==CANARY
                and bytes(work[work_size:work_size+len(CANARY)])==CANARY)
        if not readonly or not guards:
            raise AssertionError(('packet writer input/canary mutation',label))
        header=struct.unpack_from('<8Q',output) if output_size>=64 else None
        state=struct.unpack_from('<16Q',work) if work_size>=128 else None
        data=bytes(memoryview(output).cast('B')[64:result]) if 64<=result<=output_size else None
        index=bytes(work[state[6]:state[6]+state[14]]) if data is not None else None
        row={'case':label,'entry':self.entries,'result':result,'header':header,'state_header':state,
             'packet_bytes':len(raw),'packet_sha256':sha256(raw).hexdigest(),
             'output_capacity':output_size,'workspace_capacity':work_size,
             'source_unchanged':readonly,'canaries_unchanged':guards,
             'json_bytes':len(data) if data is not None else None,
             'json_sha256':sha256(data).hexdigest() if data is not None else None,
             'index_bytes':len(index) if index is not None else None,
             'index_sha256':sha256(index).hexdigest() if index is not None else None}
        if len(raw)<=65536:row['packet_base64']=base64.b64encode(raw).decode()
        if data is not None and len(data)<=65536:row['json_base64']=base64.b64encode(data).decode()
        if index is not None and len(index)<=65536:row['index_base64']=base64.b64encode(index).decode()
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
        if return_state:
            return result,header,data,index,state,(output,work,output_size,work_size)
        return result,header,data,index,state

    def close(self):
        self.log.close()
        after={path:sha256(Path(path).read_bytes()).hexdigest() for path in self.pins}
        report={'scope':'GENERIC_BOUNDED_SERVICE_PACKET_CODEC_NOT_COMPLETE_CORE_STREAM_OR_COLD',
                'actual_entries':self.entries,'before':self.pins,'after':after,
                'sources_unchanged':after==self.pins,
                'large_inputs':'Full comparisons run in memory; bytes <=64KiB embedded; larger deterministic cases keep hashes and checked constructors.'}
        (self.evidence/'custody.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        if after!=self.pins:raise AssertionError('packet writer source/image drift')


class PacketJsonSourceTests(unittest.TestCase):
    def test_fixed_point_complete_profile_and_derived_capacity(self):
        spec=importlib.util.spec_from_file_location('packet_json_authoring',GENERATOR)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        document=module.document()
        self.assertEqual(render_assembly(document).encode(),SOURCE.read_bytes())
        self.assertEqual([p['type'] for p in document['functions'][0]['params']],['readbuf','mutbuf','mutbuf'])
        self.assertEqual(capacity(LIMIT),164976096)
        self.assertLessEqual(len(document['functions']),128)
        self.assertLessEqual(sum(len(f['blocks']) for f in document['functions']),1536)
        self.assertLessEqual(max(len(f['blocks']) for f in document['functions']),256)
        self.assertLessEqual(max(len(b['params']) for f in document['functions'] for b in f['blocks']),16)


class PacketJsonNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        evidence=os.environ.get('HEPTA_HIA_PACKET_JSON_EVIDENCE')
        if not evidence:raise AssertionError('explicit fresh packet JSON evidence required; no skip')
        cls.native=ActualPacketJson(evidence)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def exact(self,label,value):
        raw=transport(value)
        expected=json.dumps(value,ensure_ascii=False,separators=(',',':'),sort_keys=False).encode()
        _,nodes=detached_packet_index(raw)
        result,header,data,index,state=self.native.encode(label,raw,output_size=64+len(expected))
        self.assertEqual((result,data),(64+len(expected),expected),label)
        self.assertEqual(header[:6],(MAGIC,0,64,len(expected),len(nodes),len(raw)),label)
        self.assertEqual(state[11],capacity(len(raw)),label)
        expected_index=bytearray((len(raw)+7)//8)
        for at in nodes:expected_index[at>>3]|=1<<(at&7)
        self.assertEqual(index,bytes(expected_index),label)
        self.assertEqual(state[1],0)
        return raw

    def test_full_scalar_container_unicode_and_offset_packets(self):
        atoms=[None,False,True,0,1,-1,1<<129,-(1<<129),'','é😀中',
               ''.join(chr(i) for i in range(32)),'"\\\x7f\x80\u07ff\u0800\ud7ff\ue000\uffff\U0010ffff',
               [],{},[None,False,True],{'z':1,'a':0,'':[], 'é':{'😀':'e\u0301'}}]
        for i,value in enumerate(atoms):self.exact('scalar-%d'%i,value)
        rng=random.Random(0x5041434b)
        def tree(depth):
            kind=rng.randrange(5 if depth else 3)
            if kind==0:return rng.choice(atoms[:14])
            if kind==1:return rng.getrandbits(129)*(-1 if rng.randrange(2) else 1)
            if kind==2:return ''.join(rng.choice('aé😀\x00\n\\"') for _ in range(rng.randrange(30)))
            if kind==3:return [tree(depth-1) for _ in range(rng.randrange(5))]
            return {'key%d-%s'%(i,rng.choice(('a','é','😀',''))):tree(depth-1) for i in range(rng.randrange(5))}
        for i in range(128):self.exact('seed-5041434b-%03d'%i,tree(4))
        for size in (0,1,7,8,15,16,23,24,25,31,32,47,48,49,511,512,513,4095,4096,4097):
            self.exact('layout-%d'%size,'x'*size)
        old=sys.get_int_max_str_digits()
        try:
            sys.set_int_max_str_digits(0)
            self.exact('unbounded-canonical-decimal',int('7'*16384))
        finally:sys.set_int_max_str_digits(old)

    def test_no_hidden_recursion_limit_and_parent_scoped_key_collisions(self):
        raw=transport(0)
        depth=4096
        for _ in range(depth):raw=container(5,[raw])
        expected=b'['*depth+b'0'+b']'*depth
        result,header,data,index,state=self.native.encode('private-valid-packet-depth4096',raw,output_size=64+len(expected))
        self.assertEqual(data,expected)
        self.assertEqual(header[4],depth+1)
        expected_index=bytearray((len(raw)+7)//8)
        for at in range(0,depth*24+1,24):expected_index[at>>3]|=1<<(at&7)
        self.assertEqual(index,expected_index)
        keys=[]
        for number in range(100000):
            key=('k%05d'%number).encode();h=1469598103934665603
            for unit in key:h=((h^unit)*1099511628211)&((1<<64)-1)
            if h&255==0:keys.append(key.decode())
            if len(keys)==64:break
        self.assertEqual(len(keys),64)
        value={key:None for key in keys}
        self.exact('64-one-parent-collisions',value)
        self.exact('same-keys-different-parents',[value,value])

    def test_malformed_entire_packets_refuse_without_output_or_index_authority(self):
        null=packet(0,b'')
        controls=[b'',b'\0'*15,null+b'\0',null+null,packet(0,b'x'),packet(1,b''),
                  packet(1,b'\x02'),packet(1,b'\x00\x00'),packet(3,b'1.0'),packet(7,b''),
                  struct.pack('<2Q',4,(1<<64)-1),packet(5,b''),packet(6,b'1234567'),
                  container(5,[null],0),container(5,[],1),container(5,[null],(1<<64)-1),
                  container(6,[packet(4,b'x'),null],(1<<64)-1),
                  container(6,[packet(2,b'0'),null]),
                  container(6,[packet(4,b'\xc3\xa9'),null,packet(4,'é'.encode()),null])]
        for value in (b'',b'-',b'-0',b'+0',b'00',b'-01',b' 1',b'1 ',b'1.0',b'1e2',b'\xff'):
            controls.append(packet(2,value))
        for value in (b'\x80',b'\xc0\x80',b'\xed\xa0\x80',b'\xf4\x90\x80\x80',b'\xf0\x90',b'\xe0\x80\x80'):
            controls.append(packet(4,value))
        crossing=bytearray(container(5,[container(5,[null]),null]))
        # The first child's nested leaf claims bytes belonging to its aunt.
        struct.pack_into('<Q',crossing,24+24+8,16)
        controls.append(bytes(crossing))
        for i,raw in enumerate(controls):
            result,header,data,index,state=self.native.encode('malformed-%02d'%i,raw,output_size=64)
            self.assertEqual(result,BAD,i)
            self.assertEqual(header[:4],(MAGIC,BAD,0,0),i)
            self.assertIsNone(data);self.assertIsNone(index)
            self.assertEqual(state[1],BAD,i)

    def test_full_validation_precedes_capacity_and_refusal_is_permanent(self):
        raw=container(5,[packet(4,b'x'*1024),packet(0,b'invalid')])
        result,header,data,index,state,reuse=self.native.encode('late-invalid-before-small-output',raw,output_size=64,return_state=True)
        self.assertEqual(result,BAD)
        result,header,data,index,state=self.native.encode('same-failed-workspace-cannot-revive',transport(None),reuse=reuse)
        self.assertEqual((result,data,index),(BAD,None,None))
        good=container(5,[packet(4,b'x'*1024),packet(0,b'')])
        result,header,data,index,state=self.native.encode('valid-but-small-output',good,output_size=64)
        self.assertEqual((result,header[:4],data,index),(SPACE,(MAGIC,SPACE,0,0),None,None))
        value={'first':[None,True],'last':'é😀\x00'}
        raw=transport(value)
        size=len(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode())
        self.assertEqual(self.native.encode('exact-output-minus-one',raw,output_size=63+size)[0],SPACE)
        self.exact('exact-output-capacity',value)
        for which in (0,1,7,15):
            control=[MAGIC]+[0]*15
            control[which]=0 if which==0 else 1
            self.assertEqual(self.native.encode('bad-control-%d'%which,raw,control=tuple(control))[0],BAD)
        for size in (0,63,127,capacity(len(raw))-1):
            self.assertEqual(self.native.encode('short-workspace-%d'%size,raw,work_size=size)[0],BAD)
        for size in (0,1,63):
            self.assertEqual(self.native.encode('short-output-%d'%size,raw,output_size=size)[0],BAD)
        for extent in (0,15,len(raw)-1,len(raw)+1):
            self.assertEqual(self.native.encode('bad-actual-source-extent-%d'%extent,raw,extent=extent)[0],BAD)

    def test_actual_native_prefix_packet_without_host_materialization(self):
        executable=ROOT/'development/lease-run-r1/actual/integer-json-packet-4300.elf'
        before=sha256(executable.read_bytes()).hexdigest()
        self.native.pins[str(executable)]=before
        wire=b'{"z":-0,"a":[true,null,123456789012345678901234567890],"unicode":"\\uD834\\uDD1E"}'
        expected=json.dumps(json.loads(wire),ensure_ascii=False,separators=(',',':')).encode()
        def forbidden(*args,**kwargs):raise AssertionError('host materialization is forbidden in actual native path')
        with patch(__name__+'.transport',new=forbidden),patch(__name__+'.detached_packet_index',new=forbidden),patch('json.loads',new=forbidden):
            child=subprocess.run([str(executable)],input=wire,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                 env={'PATH':'','PYTHONPATH':'/missing'},timeout=20)
            self.assertEqual((child.returncode,child.stderr),(0,b''))
            magic,status,offset,size,*rest=struct.unpack_from('<8Q',child.stdout)
            self.assertEqual((magic,status,offset,size),(int.from_bytes(b'HIAJPK01','little'),0,64,len(child.stdout)-64))
            result,header,data,index,state=self.native.encode('actual-native-prefix-packet',child.stdout[64:])
        self.assertEqual(data,expected)
        self.assertEqual(before,sha256(executable.read_bytes()).hexdigest())
        report={'scope':'ACTUAL_NATIVE_COMPONENTS_WITH_TEST_ONLY_BYTE_FORWARDER',
                'prefix_elf_sha256':before,'wire_sha256':sha256(wire).hexdigest(),
                'packet_sha256':sha256(child.stdout[64:]).hexdigest(),'json_sha256':sha256(data).hexdigest(),
                'exact_json':True,'host_materializers_disabled':True}
        (self.native.evidence/'native-prefix-interop.json').write_text(json.dumps(report,indent=2)+'\n')

    def test_existing_64mib_packet_boundary_and_full_escape_accounting(self):
        # Only this generic source/service transport ABI has a 64MiB ceiling;
        # this is explicitly not a generated-Core aggregate admission gate.
        raw=packet(4,b'x'*(LIMIT-16))
        result,header,data,index,state=self.native.encode('64MiB-packet-boundary',raw,output_size=LIMIT+64)
        self.assertEqual(result,64+LIMIT-14)
        self.assertTrue(data==b'"'+b'x'*(LIMIT-16)+b'"','complete 64MiB JSON output bytes differ')
        self.assertTrue(index==b'\x01'+bytes((LIMIT+7)//8-1),'complete 64MiB source offset bitmap differs')
        self.assertEqual((header[4],state[11]),(1,164976096))
        del raw,data,index,state
        raw=packet(4,b'\0'*(LIMIT-16))
        result,header,data,index,state=self.native.encode('64MiB-full-escape-count-before-capacity',raw,output_size=64)
        self.assertEqual((result,data,index),(SPACE,None,None))
        self.assertEqual(state[4],6*(LIMIT-16)+2)
        del raw,state
        raw=packet(4,b'x'*(LIMIT-15))
        self.assertEqual(self.native.encode('64MiB-packet-plus-one',raw,output_size=64,work_size=128)[0],BAD)
        del raw


if __name__=='__main__':unittest.main()
