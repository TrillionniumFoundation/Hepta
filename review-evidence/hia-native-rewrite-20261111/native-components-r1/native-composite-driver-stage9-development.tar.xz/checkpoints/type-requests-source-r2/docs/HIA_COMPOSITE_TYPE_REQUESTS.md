# Native normalized type-service requests

This is a separate development component of the full native composite driver. It consumes a complete metadata IR produced by the native ObjectToken IR owner and emits the exact normalized typed packet for the existing native types owner. It does not run type semantics, build a Core program, authorize execution, or implement the full coordinator. Its generated output has not yet been compiled or tested at this initial source checkpoint.

The generic input/source/IR components have separate identities and evidence. Nothing here changes their frozen sources or claims they authenticate arbitrary externally supplied arenas.

## Complete six-operation projection

The constructor request kinds map as follows:

| Constructor kind | Normalized type operation | Ordered command fields |
| --- | --- | --- |
| 1 | 1 init | op, definitions, recursive_chain, partial_records |
| 2 | 2 parameters | op, params |
| 3 | 3 resolve | op, ref |
| 4 | 5 origins | op, params, returns, then return_loans only if present |
| 5 | 6 task_protocol | op, task, functions |

The function request kinds map as follows:

| Function kind | Normalized type operation | Ordered command fields |
| --- | --- | --- |
| 2 | 2 parameters | op, params |
| 3 | 3 resolve | op, ref |
| 4 | 4 partial | op, base, initialized |
| 5 | 6 task_protocol | op, task, functions |

Function kind 6 is the distinct complete helper service. It is not a type command and must go through the helper continuation owner. This component refuses it instead of inventing a type operation.

The HIA code performs the old generic transport shape checks, copies primitive/source values without resolving them, retains parameter/return order and registry insertion order, rejects duplicate registry names, and builds each complete command. Constructor task registry rows have four entries; their original function source is checked to be a map, then excluded from the normalized three-entry task registry. Parameter names are excluded from each task parameter-ID vector exactly as in NativeCompositeTypeSession.check_task. Function task requests read the original three-entry registry from position 1 of their issued seven-entry source packet.

Origins include return_loans based on field presence, including an explicitly present null value. No path resolution, loan decision, task protocol check, parameter resolution or type construction is repeated here. The separate type transport validator checks all referenced IDs against the same issued session before the actual native type entry.

## Private leases and entry

The entry ABI is RWW. The first input is the complete ObjectToken IR arena, borrowed read-only. The second input is its exact SourceIndexLease, which the outer HIA entry borrows read-only. The third buffer is this invocation's private mutable output/scratch arena.

Both inputs must be the same immutable, fixed-driver-owned leases used when the metadata stream completed. This component checks their identities, extents and control fields, not a cryptographic claim of external provenance. It does not accept arbitrary caller-built IR as authenticated data. The private IR header and node layout are defined by HIA_COMPOSITE_OBJECT_TOKEN_IR.md.

The output arena must initially be zeroed. At byte offset 128, the coordinator writes sixteen words:

[HIASVP01, context, originalKind, sourceLease, stream, callerRequest, 0,0,0,0,0,0,0,0,0,0].

Context is 1 for the constructor and 2 for the function owner. The configuration must agree with the completed IR's action, lease, stream and caller request. Constructor streams must have the actual HIACTK01 producer magic and zero serial/slot fields. Function streams must have HIAFNC01. Source packet envelope sizes remain two and seven respectively where relevant.

The first 512 bytes are fixed control storage. A traversal stack of 32 bytes per admitted IR node starts at offset 512. The actual normalized typed packet follows that stack. This derives storage from an already complete finite IR; it adds no semantic node/depth quota.

Source views use a private high-bit tag for a packet offset; generated IR offsets use the low range. Source packet offsets remain below the existing 64 MiB private packet limit. A live x86-64 process cannot own a 2^63-byte IR lease. This internal tag is neither an opaque-Core handle nor a cross-session type ID.

## Output and growth

The returned event is always exactly 128 bytes at output offset 0:

[HIASVE01, action, canonicalTypeOp, originalKind, callerRequest, sourceLease, stream,
 packetOffset, packetBytes, requiredArenaBytes, errorDetail, 0,0,0,0,0].

Action 0 publishes the complete packet. Action 1 requests GROW. Action 2 is diagnostic refusal; the native return is 0xfffffffd and the coordinator must discard the invocation. A workspace shorter than 512 bytes cannot be poisoned. After successful completion or a stored refusal, the same output arena cannot be reused for another invocation.

The caller grows the arena by a byte-preserving move, retains the same immutable input leases and configuration, and repeats the same entry. GROW does not publish a packet or advance a language/type-owner command. A retry revalidates the configuration and exact issued IR size/root/node count. Full same-byte input custody comes from the fixed driver; the retained fields alone cannot detect an unauthorized same-shape replacement.

If even the derived traversal stack does not fit, the component first requests its extent. Once traversal storage exists, it completes the projection and measures every output byte before requesting output capacity. On the final pass it creates the entire typed packet. This storage protocol does not replace any public input limit, types command JSON limit, or final Core limit. It does not prematurely truncate a large generated Core: complete Core is never passed through this service-message component.

Strings and containers preserve their original order and bytes. Unsigned native integer tokens become canonical decimal typed-packet scalars, including exact 64-bit extremes. Original source leaves copy their already admitted complete packet representation. The normalizer never expands a discarded original-function source while building a task registry.

## Coordinator responsibilities still outstanding

The full native coordinator must retain source/IR/output leases, bind the actual images and component sources, construct and correlate BEGIN/REPLY messages for the independent type transport validator, invoke the actual types owner, encode constructor/function responses, service complete helper generation, preserve partial state/error order, and apply the unchanged outer/final Core gates.

Python test code may build independent oracles, inspect post-execution packets, and forward opaque native byte buffers. Such tests do not establish that the installed runtime has stopped using Python dispatch. This component is not a cutover or cleanup authorization.
