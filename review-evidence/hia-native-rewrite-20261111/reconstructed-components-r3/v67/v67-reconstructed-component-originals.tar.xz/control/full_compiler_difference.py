"""New run after executor loss: actual full compilers and complete raw frames."""
from pathlib import Path
from hashlib import sha256
import json,struct,sys,time
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-v66-restored')
REPO=Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-reconstructed')
ROOT=Path('/workspace/scratch/9acdfa9f5639/hia-v67-reconstructed-development/full-compiler-attempt1')
sys.path.insert(0,str(REPO))
from tools.hia_selfhost_native_observer import independent_reference,build,frame,execute
from tools.qualify_hia_selfhost import build_seed,compile_stage
from tools.hia_selfhost_cases import HEADER,backward_chain_source,recursion_refusals,call_graph_invalid_sources
from tools.hia_selfhost_capacity import instruction_capacity_source
from tools.hia_selfhost_names import cases as name_cases
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import HIAProgramRejected

def sha(b):return sha256(b).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
ROOT.mkdir(mode=0o700,exist_ok=False);started=time.monotonic_ns()
paths={'previous':BASE/'examples/hia_bootstrap/selfhost.hiaasm','candidate':REPO/'examples/hia_bootstrap/selfhost.hiaasm'}
sources={k:p.read_bytes() for k,p in paths.items()}
identity={k:{'path':str(paths[k]),'bytes':len(b),'sha256':sha(b)} for k,b in sources.items()}
for k,b in sources.items():(ROOT/(k+'.hiaasm')).write_bytes(b)
assert identity['candidate']['sha256']=='6e02fe4e6efbe59d5d4286de6bf3d0d9e22364a10f09d5831355d0c9885d3f4c'
rows=[('previous-selfhost',sources['previous']),('candidate-selfhost',sources['candidate']),('one-function',(HEADER+'  v3:u32 = const() {"value":7}\n  ret(v3)\nend\n').encode()),('backward-128',backward_chain_source())]
rows+=list(recursion_refusals().items())
rows+=list(call_graph_invalid_sources((REPO/'examples/hia_bootstrap/bytesum.hiaasm').read_bytes()).items())
rows+=[('instruction-limit-'+str(n),instruction_capacity_source(n)[0]) for n in (8192,8193)]
rows+=[('named-128',next(r['source'].encode() for r in name_cases() if r['program']=='named-128-functions'))]
reference=[]
for name,source in rows:
 try:checked=assemble_program(source)
 except HIAProgramRejected as exc:reference.append({'id':name,'general_core':'rejected','diagnostic':str(exc)})
 else:reference.append({'id':name,'general_core':'accepted','core_sha256':checked.sha256})
oref=independent_reference();save(ROOT/'before-seed-independent-reference.json',{'cases':reference,'observer':oref})
seed,_=build_seed(ROOT)
new,_=compile_stage(ROOT,'candidate-B1',seed,sources['candidate'],image_format='seed-shared')
old,oreceipt=compile_stage(ROOT,'previous-actual',new,sources['previous'])
assert oreceipt['produced_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
again,_=compile_stage(ROOT,'candidate-by-previous',old,sources['candidate']);assert again.read_bytes()==new.read_bytes()
assert sha(new.read_bytes())=='35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
observer,_=build(ROOT,new,oref);images={'previous':old,'candidate':new};frozen={k:p.read_bytes() for k,p in images.items()};executable=observer.read_bytes();ledger=[]
for index,(name,source) in enumerate(rows):
 observed=[];records=[]
 for variant,image in images.items():
  label=str(index)+'-'+variant;payload=frame(frozen[variant],source,1<<20,1<<20,0xa7);(ROOT/(label+'.frame.bin')).write_bytes(payload)
  t=time.monotonic_ns();proc=execute(executable,payload,cwd=ROOT);wall=time.monotonic_ns()-t
  (ROOT/(label+'.response.bin')).write_bytes(proc.stdout);(ROOT/(label+'.stderr.log')).write_bytes(proc.stderr)
  assert proc.returncode==0 and not proc.stderr,(name,variant,proc.returncode)
  raw=proc.stdout;assert raw[:8]==b'HIAOBR02' and len(raw)==24+len(source)+(2<<20)
  returned,native=struct.unpack_from('<2Q',raw,8);assert raw[24:24+len(source)]==source
  output=raw[24+len(source):24+len(source)+(1<<20)];workspace=raw[-(1<<20):]
  records.append({'variant':variant,'result_u64':returned,'native_elapsed_ns':native,'wall_elapsed_ns':wall,'source_sha256':sha(source),'image_sha256':sha(frozen[variant]),'frame_sha256':sha(payload),'response_sha256':sha(raw),'output_sha256':sha(output),'workspace_sha256':sha(workspace),'complete_output_bytes':len(output),'complete_workspace_bytes':len(workspace)})
  observed.append((returned,output,workspace))
 assert observed[0]==observed[1],name
 ledger.append({'id':name,'actual':records,'every_output_and_workspace_byte_equal':True});save(ROOT/'ledger.json',ledger)
 print(json.dumps({'completed':name}),flush=True)
assert all(paths[k].read_bytes()==b for k,b in sources.items())
assert all(images[k].read_bytes()==b for k,b in frozen.items()) and observer.read_bytes()==executable
summary={'scope':'NEW_RECONSTRUCTED_SOURCE_FULL_COMPILER_DEVELOPMENT_DIFFERENTIAL','status':'PASS','source_identity':identity,'before_seed_reference':True,'cases':len(rows),'actual_full_compiler_entries':2*len(rows),'complete_output_and_workspace_bytes_per_entry':2<<20,'maximum_functions':128,'instruction_boundary':[8192,8193],'no_gate_or_limit_changes':True,'every_output_and_workspace_byte_equal':True,'old_image_matches_published_B3':True,'candidate_image_matches_both_fresh_seed_and_previous_compiler':True,'source_images_observer_unchanged':True,'elapsed_ns':time.monotonic_ns()-started,'old_lost_originals_recreated':False,'whole_stack_closed':False}
save(ROOT/'summary.json',summary);print(json.dumps(summary),flush=True)
