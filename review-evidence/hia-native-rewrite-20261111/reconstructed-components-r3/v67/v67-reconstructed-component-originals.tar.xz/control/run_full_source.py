"""New exact frozen source gate; the interrupted prior run remains unqualified."""
from pathlib import Path
from hashlib import sha256
import ast,json,os,resource,sys,tempfile,time,unittest
ROOT=Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-reconstructed');DEV=Path('/workspace/scratch/9acdfa9f5639/hia-v67-reconstructed-development');OUT=DEV/'source-suite-attempt1';OUT.mkdir(mode=0o700,exist_ok=False)
TMP=DEV/'source-suite-tmp';TMP.mkdir(mode=0o700,exist_ok=False);os.environ['TMPDIR']=str(TMP);tempfile.tempdir=None;os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True;os.chdir(ROOT);sys.path.insert(0,str(ROOT))
def dump(n,v):(OUT/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
frozen=json.loads((DEV/'source-frozen.json').read_text());expected=frozen['source_closure']
def snapshot():return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in expected}
before=snapshot();assert before==expected and len(before)==644;dump('source-before.json',before)
workflow=(ROOT/'.github/workflows/hia-core.yml').read_text();block=workflow.split('      - name: Core source and independent reference controls\n',1)[1].split('  native:\n',1)[0]
lines=block.split("          python -B - <<'PY'\n",1)[1].split('          PY\n',1)[0].splitlines();code='\n'.join(line[10:] for line in lines)+'\n';tree=ast.parse(code);assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets));names=ast.literal_eval(assignment.value);assert len(names)==len(set(names))==79
(OUT/'original-workflow-test-block.py').write_text(code);suite=unittest.defaultTestLoader.loadTestsFromNames(names)
def flatten(v):
 if isinstance(v,unittest.TestSuite):
  for c in v:yield from flatten(c)
 else:yield v
selected=[t.id() for t in flatten(suite)];assert len(selected)==len(set(selected))==331;executed=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):executed.append(test.id());super().startTest(test)
started=time.monotonic_ns()
with (OUT/'suite.log').open('x') as log:result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(suite)
after=snapshot();dump('source-after.json',after)
summary={'scope':'RECONSTRUCTED_CURRENT_SOURCE_COMPLETE_WORKFLOW_SUITE_NOT_COLD','python':sys.version,'executable':sys.executable,'source_count':len(before),'source_preserved':before==after,'source_manifest_sha256':sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'selected_names':list(names),'selected_test_ids':selected,'executed_test_ids':executed,'tests_run':result.testsRun,'failures':[{'test':str(t),'traceback':s} for t,s in result.failures],'errors':[{'test':str(t),'traceback':s} for t,s in result.errors],'skipped':[{'test':str(t),'reason':s} for t,s in result.skipped],'expected_failures':[{'test':str(t),'traceback':s} for t,s in result.expectedFailures],'unexpected_successes':[str(t) for t in result.unexpectedSuccesses],'seconds':(time.monotonic_ns()-started)/1e9,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'old_lost_gate_recreated':False,'whole_stack_closed':False}
summary['passed']=result.wasSuccessful() and before==after and result.testsRun==len(selected) and executed==selected and not any(summary[k] for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
dump('summary.json',summary);print(json.dumps({k:summary[k] for k in ('passed','tests_run','seconds','source_preserved','max_rss_kib')}),flush=True);raise SystemExit(0 if summary['passed'] else 1)
