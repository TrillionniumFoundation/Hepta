"""One exact historical-B3 development compile of the new main controller."""
from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
from tools.qualify_hia_selfhost import compile_stage

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "checkpoints/main-source-r2"
DEST = ROOT / "development/compile-main-r1"
raw_manifest = (SNAPSHOT / "source.json").read_bytes()
manifest = json.loads(raw_manifest)
before = {SNAPSHOT / "source.json": raw_manifest}
for row in manifest["files"]:
    a, b = SNAPSHOT / row["path"], ROOT / row["path"]
    raw = a.read_bytes()
    assert len(raw) == row["bytes"] and sha256(raw).hexdigest() == row["sha256"]
    assert b.read_bytes() == raw
    before[a] = raw
    before[b] = raw
for row in manifest["dependencies"]:
    p = Path(row["path"]); raw = p.read_bytes()
    assert len(raw) == row["bytes"] and sha256(raw).hexdigest() == row["sha256"]
    before[p] = raw
compiler = Path(manifest["dependencies"][-1]["path"])
assert sha256(before[compiler]).hexdigest() == "0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8"
source = SNAPSHOT / "examples/hia_bootstrap/composite_lowering_driver_main.hiaasm"
DEST.mkdir(exist_ok=False)
summary = {"status": "INCOMPLETE", "scope": "DEVELOPMENT_MAIN_CONTROLLER_ONLY_NOT_COLD_NOT_FULL_DRIVER"}
try:
    image, receipt = compile_stage(DEST, "composite-lowering-driver-main", compiler, before[source])
    body = image.read_bytes()
    assert receipt["input_sha256"] == sha256(before[source]).hexdigest()
    assert receipt["artifact_sha256"] == sha256(before[compiler]).hexdigest()
    assert receipt["produced_sha256"] == sha256(body).hexdigest()
    assert receipt["produced_bytes"] == len(body) == receipt["core_u32"]
    component = {
        "schema": "hepta.hia.composite-lowering-driver-main-native.v1",
        "source_path": str(source), "source_sha256": sha256(before[source]).hexdigest(),
        "image_path": str(image), "image_sha256": sha256(body).hexdigest(),
        "compiler_sha256": sha256(before[compiler]).hexdigest(),
    }
    (DEST / "manifest.json").write_text(json.dumps(component, indent=2, sort_keys=True) + "\n")
    summary.update(status="PASS", component=component, receipt=receipt,
                   source_manifest_sha256=sha256(raw_manifest).hexdigest(),
                   production_activation=False, full_driver_executed=False, whole_stack_closed=False)
except BaseException as exc:
    summary.update(status="FAIL", error_class=type(exc).__name__, error=str(exc))
    raise
finally:
    unchanged = all(p.read_bytes() == value for p, value in before.items())
    summary["all_source_and_dependency_bytes_unchanged"] = unchanged
    (DEST / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert unchanged
