"""Actual main-controller protocol probes; all constructor handoffs are synthetic.

These are private wire/state controls, not semantic pipeline cases. No function,
type, helper, outer, JSON, or Core visitor image is called by this probe.
"""
from __future__ import annotations
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import struct

from hepta.hia_json_preflight_native import NativeHiaJsonImage
from tools.hia_composite_lowering_driver_common import CONSTANTS as C

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "development/main-protocol-r1"
MANIFEST = ROOT / "development/compile-main-r1/manifest.json"
raw_manifest = MANIFEST.read_bytes()
component = json.loads(raw_manifest)
image_path, source_path = Path(component["image_path"]), Path(component["source_path"])
image_raw, source_raw = image_path.read_bytes(), source_path.read_bytes()
assert sha256(image_raw).hexdigest() == component["image_sha256"]
assert sha256(source_raw).hexdigest() == component["source_sha256"]
pins = {MANIFEST: raw_manifest, image_path: image_raw, source_path: source_raw}
for row in json.loads((ROOT / "checkpoints/main-source-r2/source.json").read_text())["files"]:
    p = ROOT / row["path"]; data = p.read_bytes()
    assert sha256(data).hexdigest() == row["sha256"]
    pins[p] = data
assert all(p.read_bytes() == b for p, b in pins.items())
DEST.mkdir(exist_ok=False)
native = NativeHiaJsonImage(image_raw, component["image_sha256"])
ledger = []
CANARY = bytes([0xA5]) * 32


def put(work, field, value):
    struct.pack_into("<Q", work, C[field], value)


def make(success=False):
    work = ctypes.create_string_buffer(C["MIN_WORK"] + 32)
    ctypes.memmove(ctypes.addressof(work) + C["MIN_WORK"], CANARY, len(CANARY))
    put(work, "C_LEASE", 7)
    put(work, "C_SEQUENCE", 91)
    put(work, "C_IR_ROOT", 131328)
    put(work, "C_IR_EXTENT", 131408)
    put(work, "C_IR_STREAM", 12)
    struct.pack_into("<Q", work, C["CAPS"] + 2 * 8, C["MIN_WORK"])
    if success:
        put(work, "C_CTOR_STAGE", 3)
        put(work, "C_PROFILE", 4)
        put(work, "C_TYPES_LIVE", 1)
        put(work, "C_FN_PACKET_BYTES", 128)
        put(work, "C_OUT_PACKET_BYTES", 128)
        put(work, "C_FN_SOURCE_BYTES", 208)
        put(work, "C_OUT_SOURCE_BYTES", 208)
        for slot, size in ((14, 4096), (16, 128 << 20), (17, 64 << 20), (20, 128),
                           (21, 128), (22, 208), (23, 208)):
            struct.pack_into("<Q", work, C["CAPS"] + slot * 8, size)
        values = (C["EVENT_MAGIC"], 7, 7, 91, 0, 0, 3, 4, 0, 11,
                  131328, 131408, 1, 128, 128, 0)
    else:
        put(work, "C_ERROR_GROUP", 1)
        put(work, "C_FINAL_ERROR", 1)
        values = (C["EVENT_MAGIC"], 7, 7, 91, 1, 1, 0, 0, 0, 11,
                  131328, 131408, 0, 0, 0, 0)
    return work, struct.pack("<16Q", *values)


def call(label, work, wire, output_bytes=128, workspace_bytes=None):
    source = ctypes.create_string_buffer(wire, max(1, len(wire)))
    out = ctypes.create_string_buffer(output_bytes + 32)
    ctypes.memmove(ctypes.addressof(out) + output_bytes, CANARY, 32)
    before = bytes(source)
    result = int(native._entry(source, len(wire), out, output_bytes, work,
                               C["MIN_WORK"] if workspace_bytes is None else workspace_bytes))
    assert bytes(source) == before
    assert ctypes.string_at(ctypes.addressof(out) + output_bytes, 32) == CANARY
    assert ctypes.string_at(ctypes.addressof(work) + C["MIN_WORK"], 32) == CANARY
    row = {"case": label, "return": result, "wire_bytes": len(wire),
           "wire_sha256": sha256(wire).hexdigest(), "output": bytes(out[:output_bytes]).hex(),
           "workspace_sha256": sha256(bytes(work[:C["MIN_WORK"]])).hexdigest()}
    ledger.append(row)
    (DEST / (str(len(ledger)).zfill(3) + ".input.bin")).write_bytes(wire)
    (DEST / (str(len(ledger)).zfill(3) + ".output.bin")).write_bytes(out[:output_bytes])
    return result, tuple(struct.unpack("<16Q", bytes(out[:128]))) if output_bytes >= 128 else ()


summary = {"status": "INCOMPLETE", "scope": "ACTUAL_MAIN_IMAGE_PRIVATE_SYNTHETIC_HANDOFF_PROTOCOL_ONLY",
           "semantic_pipeline_cases": 0, "whole_stack_closed": False}
try:
    work, wire = make()
    result, frame = call("constructor_semantic_error_forwarded", work, wire)
    assert result == 128 and frame[:6] == (C["EVENT_MAGIC"], 7, 7, 91, 1, 1)
    assert call("completed_replay_refused", work, wire)[0] == C["ABI"]

    for label, position, changed in (
        ("bad_magic", 0, 0), ("bad_opcode", 1, 1), ("bad_lease", 2, 8),
        ("bad_sequence", 3, 90), ("bad_error_group", 4, 2),
        ("bad_stage", 6, 1), ("bad_profile", 7, 1),
        ("bad_ir_slot", 9, 12), ("bad_ir_root", 10, 131329),
        ("bad_tail", 15, 1),
    ):
        work, original = make()
        words = list(struct.unpack("<16Q", original)); words[position] = changed
        bad = struct.pack("<16Q", *words)
        assert call(label, work, bad)[0] == C["ABI"]
        assert call(label + "_permanent", work, original)[0] == C["ABI"]

    work, wire = make()
    assert call("short_output", work, wire, output_bytes=127)[0] == C["ABI"]
    assert call("short_output_permanent_full_workspace", work, wire)[0] == C["ABI"]

    work, wire = make(success=True)
    result, frame = call("first_allocation", work, wire)
    assert result == 128 and frame[:6] == (C["EVENT_MAGIC"], 2, 7, 92, 24, 192 << 20)
    ack = struct.pack("<8Q", C["ACK_MAGIC"], 7, 92, 2, 0, 0, 0, 0)
    result, frame = call("allocation_ack", work, ack)
    assert result == 128 and frame[:6] == (C["EVENT_MAGIC"], 2, 7, 93, 25, 65536)

    for label, position, changed in (
        ("ack_magic", 0, 0), ("ack_lease", 1, 8), ("ack_sequence", 2, 91),
        ("ack_opcode", 3, 1), ("ack_executor_failure", 4, 1),
        ("ack_return", 5, 1), ("ack_observation", 6, 1), ("ack_reserved", 7, 1),
    ):
        work, wire = make(success=True)
        assert call(label + "_start", work, wire)[0] == 128
        words = list(struct.unpack("<8Q", ack)); words[position] = changed
        assert call(label, work, struct.pack("<8Q", *words))[0] == C["ABI"]
        assert call(label + "_permanent", work, ack)[0] == C["ABI"]

    summary.update(status="PASS", actual_main_entries=len(ledger),
                   controls=22, source_canaries_unchanged=True,
                   borrowed_source_is_synthetic=True, forwarding_executor_exercised=False)
except BaseException as exc:
    summary.update(status="FAIL", error_class=type(exc).__name__, error=str(exc))
    raise
finally:
    native._mapping.close()
    unchanged = all(p.read_bytes() == value for p, value in pins.items())
    summary["source_and_image_pins_unchanged"] = unchanged
    (DEST / "ledger.json").write_text(json.dumps(ledger, indent=2, sort_keys=True) + "\n")
    (DEST / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert unchanged
