from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
CHECKOUT = Path('/workspace/scratch/9acdfa9f5639/Hepta')
COMMIT = 'c80eb2ecc5d08421a3d124c879edb33cefff2267'
ZIP = ROOT / 'c80eb2-native-attempt1.zip'
PREFIX = '/home/runner/work/_temp/'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def member(path):
    assert path.startswith(PREFIX)
    return path[len(PREFIX):]


with zipfile.ZipFile(ZIP) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names))
    cold = json.loads(archive.read('hia-cold.json'))
    index = json.loads(archive.read('hia-cold.cold/qualification.evidence/phase-index.json'))
    owner = cold['process_owner']
    began = next(row['monotonic_ns'] for row in owner['events'] if row['kind'] == 'qualification_started')
    source_errors = []
    for path, expected in cold['source_manifest'].items():
        archived = archive.read('hia-cold.cold/source/' + path)
        original = subprocess.check_output(['git', 'show', COMMIT + ':' + path], cwd=CHECKOUT)
        if digest(archived) != expected or digest(original) != expected:
            source_errors.append(path)
    phases = []
    for phase in index['phases']:
        p = {'family': phase['family'], 'label': phase['compiler_label'], 'index_state': phase['state']}
        report_name = member(phase['report'])
        process_name = member(phase['process_receipt'])
        request_name = member(phase['request'])
        p['request_present'] = request_name in names
        p['report_present'] = report_name in names
        p['process_present'] = process_name in names
        if report_name in names:
            raw = archive.read(report_name)
            report = json.loads(raw)
            request = json.loads(archive.read(request_name))
            process = json.loads(archive.read(process_name))
            p.update(status=report['status'], checks=len(report['checks']),
                     false_checks=[k for k,v in report['checks'].items() if v is not True],
                     returncode=process['returncode'],
                     start_seconds=(process['started_monotonic_ns'] - began)/1e9,
                     end_seconds=(process['completed_monotonic_ns'] - began)/1e9,
                     worker_wall_seconds=process['wall_elapsed_ns']/1e9,
                     report_digest_matches=digest(raw)==process['report_sha256'],
                     source_manifest_sha256=report['source_manifest_sha256'],
                     report_inputs_match=report['input_sha256']=={k:v['sha256'] for k,v in request['inputs'].items()})
            inputs = []
            for key, value in request['inputs'].items():
                path = member(value['path'])
                inputs.append(path in names and digest(archive.read(path)) == value['sha256'])
            p['input_bytes_match'] = all(inputs)
            if 'raw_artifacts' in process:
                packed = process['raw_artifacts']
                raw_archive = archive.read(member(packed['archive']))
                p.update(archive_sha256_matches=digest(raw_archive)==packed['archive_sha256'],
                         archive_bytes=len(raw_archive),
                         raw_files=packed['files'],raw_bytes=packed['unpacked_bytes'])
        phases.append(p)
    references = []
    for path in names:
        if '/reference-' in path and path.endswith('.worker.json'):
            report = json.loads(archive.read(path))
            raw = json.dumps(report['reference'], sort_keys=True, separators=(',', ':')).encode()
            references.append({'family':report['family'], 'wall_seconds':report['wall_elapsed_ns']/1e9,
                               'sha256':report['reference_sha256'],
                               'digest_matches':digest(raw)==report['reference_sha256']})
    output = {
        'schema':'hepta.hia.c80eb2-cold-failure-observation.v1',
        'commit':COMMIT,'zip_bytes':ZIP.stat().st_size,'zip_sha256':digest(ZIP.read_bytes()),
        'zip_members':len(names),'source_entries':len(cold['source_manifest']),
        'all_source_bytes_match_pinned_commit':not source_errors,'source_errors':source_errors,
        'status':cold['status'],'cold_wall_seconds':cold['wall_elapsed_ns']/1e9,
        'qualification_seconds':cold['qualification_wall_limit_seconds'],
        'cleanup_seconds':cold['cleanup_wall_limit_seconds'],
        'cleanup':owner['cleanup'],'checks_passed':sum(x is True for x in cold['checks'].values()),
        'checks_total':len(cold['checks']),'indexed_completed':index['completed'],
        'index_exceptions':index['exceptions'],'total_phases':len(index['phases']),
        'phases':phases,'references':references,
        'nested_archives_scope':'Complete packed bytes hashed against producer receipts; individual nested member replay not performed in this failure timing diagnosis.',
        'qualification_pass':False,'rerun_requested':False,'source_modified':False,
    }
    (ROOT/'cold-failure-analysis.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:output[k] for k in ('source_entries','all_source_bytes_match_pinned_commit','cold_wall_seconds','indexed_completed','index_exceptions','total_phases')}))
    print(json.dumps({'references':references,'phases':phases},indent=2))
