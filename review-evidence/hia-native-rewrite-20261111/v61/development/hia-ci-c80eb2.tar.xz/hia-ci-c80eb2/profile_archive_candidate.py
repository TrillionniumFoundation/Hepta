"""Read-only source artifact diagnosis using new, owned reconstruction stages.

Never writes the original CI ZIP, a source checkout, or a retained raw stage.
Reconstructed stages are disposable benchmark inputs, not qualification receipts.
"""
from __future__ import annotations

import argparse
import cProfile
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import pstats
import shutil
import tempfile
import time
from unittest.mock import patch
import zipfile

HERE = Path(__file__).resolve().parent
ARTIFACT = HERE / "c80eb2-native-attempt1.zip"
EXPECTED = "c1d137bf8f54afaff613e725c152e84ecb19cab20fd03f94531e8392ffef11ec"
BASE = HERE / "archive-baseline-c80eb2.py"
CANDIDATE = Path("/workspace/scratch/9acdfa9f5639/Hepta-archive-candidate/tools/hia_evidence_archive.py")


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def populate(packed, root, manifest):
    root.mkdir(mode=0o700)
    with zipfile.ZipFile(io.BytesIO(packed)) as source:
        for name, row in manifest["files"].items():
            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("unsafe original member")
            data = source.read(name)
            if len(data) != row["bytes"] or sha256(data).hexdigest() != row["sha256"]:
                raise ValueError("original member mismatch")
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            target.chmod(row["mode"])
            stamp = datetime(*source.getinfo(name).date_time, tzinfo=timezone.utc).timestamp()
            import os
            os.utime(target, (stamp, stamp))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--family", choices=("signed", "scalar-casts", "chain"), default="signed")
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument("--baseline-only", action="store_true")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--temporary-parent", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = ARTIFACT.read_bytes()
    if sha256(raw).hexdigest() != EXPECTED:
        raise ValueError("original artifact changed")
    with zipfile.ZipFile(io.BytesIO(raw)) as outer:
        packed = outer.read("hia-cold.cold/qualification.evidence/phase-runs/" + args.family + "-original.zip")
    baseline = module(BASE, "archive_baseline")
    candidate = module(CANDIDATE, "archive_candidate")
    manifest = baseline.verify_archive(io.BytesIO(packed))
    rows = []
    with tempfile.TemporaryDirectory(prefix="owned-archive-benchmark-", dir=args.temporary_parent or HERE) as temporary:
        root = Path(temporary) / "stage"
        versions = [("baseline", baseline)] if args.baseline_only else [("baseline", baseline), ("candidate", candidate)]
        for round_index in range(args.rounds):
            ordered = versions if round_index % 2 == 0 else versions[::-1]
            for label, implementation in ordered:
                populate(packed, root, manifest)
                token = (root / implementation.OWNER).read_text()
                profiler = cProfile.Profile() if args.profile else None
                started = time.monotonic_ns()
                cpu_started = time.process_time_ns()
                if profiler:
                    profiler.enable()
                # Only ZIP's synthetic manifest creation time is frozen. Member
                # timestamps still derive from actual source-file metadata; all
                # monotonic budget/mutation checks execute normally.
                with patch("zipfile.time.time", return_value=1700000000):
                    receipt = implementation.archive_completed_stage(root, token)
                if profiler:
                    profiler.disable()
                elapsed = time.monotonic_ns() - started
                cpu_elapsed = time.process_time_ns() - cpu_started
                archive = Path(receipt["archive"])
                replay = baseline.verify_archive(archive)
                assert replay["files"] == manifest["files"]
                assert replay["unpacked_bytes"] == manifest["unpacked_bytes"]
                assert replay["source_directory"] == str(root)
                assert receipt["archive_sha256"] == sha256(archive.read_bytes()).hexdigest()
                row = {"implementation": label, "round": round_index + 1, "wall_elapsed_ns": elapsed,
                       "process_cpu_ns": cpu_elapsed,
                       "files": receipt["files"], "unpacked_bytes": receipt["unpacked_bytes"],
                       "packed_bytes": receipt["packed_bytes"], "archive_sha256": receipt["archive_sha256"],
                       "manifest_sha256": receipt["manifest_sha256"], "all_original_member_hashes_and_modes_equal": True}
                if profiler:
                    summary = io.StringIO()
                    pstats.Stats(profiler, stream=summary).strip_dirs().sort_stats("cumtime").print_stats(30)
                    row["profile"] = summary.getvalue()
                rows.append(row)
                print(json.dumps({key: value for key, value in row.items() if key != "profile"}), flush=True)
                if profiler:
                    print(row["profile"], flush=True)
                # Only these newly reconstructed, owned benchmark products.
                shutil.rmtree(root)
                archive.unlink()
    result = {"schema": "hepta.hia.archive-buffer-benchmark.v1", "original_artifact_sha256": EXPECTED,
              "family": args.family, "baseline_source_sha256": sha256(BASE.read_bytes()).hexdigest(),
              "candidate_source_sha256": sha256(CANDIDATE.read_bytes()).hexdigest(),
              "rows": rows, "qualification_pass": False,
              "zip_manifest_creation_time_frozen": True,
              "scope": "Lossless archive equivalence and local wall time on original CI member bytes; not full cold qualification."}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
