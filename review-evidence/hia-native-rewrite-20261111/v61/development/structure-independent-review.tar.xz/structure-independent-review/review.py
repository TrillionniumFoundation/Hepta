"""Independent targeted c80-versus-candidate traversal controls; no production writes."""
from pathlib import Path
from hashlib import sha256
import ast
import inspect
import json
import linecache
import subprocess
import sys

from hepta import hia_program as core

ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta-structure-candidate')
OUT = Path('/workspace/scratch/9acdfa9f5639/structure-independent-review')
SOURCE = ROOT / 'hepta/hia_program.py'
PIN = '76a222745e13fe29825a661be206243f137ada7b57292b07ab7513a40146fb92'
assert sha256(SOURCE.read_bytes()).hexdigest() == PIN
text = subprocess.check_output(['git', 'show', 'c80eb2e:hepta/hia_program.py'], cwd=ROOT, text=True)
filename = 'c80-independent-hia_program.py'
linecache.cache[filename] = (len(text), None, text.splitlines(True), filename)
defs = [node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef)
        and node.name in {'_structure', '_bounded_detached_snapshot'}]
assert len(defs) == 2
space = dict(core.__dict__)
exec(compile(ast.Module(body=defs, type_ignores=[]), filename, 'exec'), space)
old_structure = space['_structure']
old_snapshot = space['_bounded_detached_snapshot']
records = []


def outcome(call):
    try:
        return {'returned': call()}
    except Exception as error:
        causes = []
        cause = error.__cause__
        while cause is not None:
            causes.append([type(cause).__module__, type(cause).__name__, str(cause)])
            cause = cause.__cause__
        return {'exception': type(error).__name__, 'code': getattr(error, 'code', None),
                'message': str(error), 'causes': causes}


def boundary(function, marker, predicate, mutate, value):
    lines, start = inspect.getsourcelines(function)
    targets = {start + index for index, line in enumerate(lines) if marker in line}
    assert targets
    fired = []
    previous = sys.gettrace()
    def trace(frame, event, arg):
        if (event == 'line' and frame.f_code is function.__code__ and frame.f_lineno in targets
                and not fired and predicate(frame)):
            fired.append(True)
            mutate()
        return trace
    try:
        sys.settrace(trace)
        result = outcome(lambda: function(value))
    finally:
        sys.settrace(previous)
    assert fired
    return result


# A repeated caller alias must be captured separately at each occurrence;
# an immutable-value memo must not accidentally become an object-admission memo.
results = []
for function, marker, variable in [(old_snapshot, 'active.remove(id(node))', 'node'),
        (core._bounded_detached_snapshot, 'active.remove(id(original))', 'original')]:
    shared = ['old']
    root = [shared, shared]
    results.append(boundary(function, marker, lambda frame: frame.f_locals[variable] is shared,
        lambda: shared.__setitem__(slice(None), ['changed']), root))
assert results[0] == results[1] == {'returned': [['old'], ['changed']]}
records.append({'case': 'mutation_between_separate_alias_visits', 'result': results[1]})

# The already captured edge is retained even after its live parent is cleared.
# Active-path checking still sees the captured root->child->root cycle.
results = []
for function in (old_snapshot, core._bounded_detached_snapshot):
    child = []
    root = [child]
    def mutate():
        root.clear()
        child.append(root)
    results.append(boundary(function, 'if parent is None:', lambda frame: frame.f_locals['node'] is root,
                            mutate, root))
assert results[0] == results[1]
assert results[1]['code'] == 'E_HIA_FORMAT' and 'cyclic caller-owned' in results[1]['message']
records.append({'case': 'captured_parent_edge_and_new_nested_cycle', 'result': results[1]})

# Deep empty siblings must restore the enclosing depth, and aliases must leave
# the active set at the exact scope boundary, including alongside invalid nodes.
shared = [[], {'empty': []}]
deep = shared
for _ in range(core.MAX_DEPTH - 3):
    deep = [deep]
for index, value in enumerate(([deep, [], shared, shared],
        {'right': deep, 'empty': [], 'again': shared},
        [deep, '\ud800', object()], [object(), '\ud800', deep])):
    for name, before, after in [('structure', old_structure, core._structure),
                               ('snapshot', old_snapshot, core._bounded_detached_snapshot)]:
        left, right = outcome(lambda: before(value)), outcome(lambda: after(value))
        assert left == right, (index, name, left, right)
        records.append({'case': 'deep_empty_sibling_scope_' + str(index), 'owner': name,
                        'result_kind': 'returned' if 'returned' in right else right})


# Observe the maximum real pre-hash lookup length, not an artificially reduced
# byte cap. Oversized strings must bypass dict.get entirely. Every candidate
# exception must retain the exact c80 message and explicit cause chain.
for name, value in [('ascii_exact', 'x' * (core.MAX_BYTES - 2)),
        ('ascii_one_over', 'x' * (core.MAX_BYTES - 1)),
        ('astral_char_lower_bound_only', '\U00010000' * (core.MAX_BYTES - 2)),
        ('surrogate_first_near_bound', '\ud800' + 'x' * (core.MAX_BYTES - 3))]:
    lookups = []
    def profile(frame, event, arg):
        if (event == 'c_call' and frame.f_code.co_name == 'string_bytes'
                and getattr(arg, '__name__', None) == 'get'):
            lookups.append({'characters': len(frame.f_locals['value']),
                            'remaining': frame.f_locals['remaining']})
    before = outcome(lambda: old_structure(value))
    previous = sys.getprofile()
    try:
        sys.setprofile(profile)
        after = outcome(lambda: core._structure(value))
    finally:
        sys.setprofile(previous)
    assert before == after, (name, before, after)
    if name == 'ascii_one_over':
        assert lookups == []
    else:
        assert lookups == [{'characters': core.MAX_BYTES - 2, 'remaining': core.MAX_BYTES}]
    records.append({'case': name, 'result': after, 'memo_lookups': lookups,
                    'python_string_allocation_bytes': sys.getsizeof(value)})

assert sha256(SOURCE.read_bytes()).hexdigest() == PIN
report = {'candidate_file': str(SOURCE), 'candidate_sha256': PIN,
    'baseline_commit': 'c80eb2ecc5d08421a3d124c879edb33cefff2267',
    'production_modified': False, 'targeted_cases': len(records), 'all_equal': True,
    'records': records}
(OUT / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'all_equal': True, 'targeted_cases': len(records),
                  'report': str(OUT / 'results.json')}, indent=2))
