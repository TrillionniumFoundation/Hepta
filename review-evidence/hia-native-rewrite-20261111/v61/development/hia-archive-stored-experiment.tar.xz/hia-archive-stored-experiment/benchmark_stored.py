"""Compression-only archive experiment; creates only new disposable stages.

All stage inventory, original rereads, independent replay, three packed hashes,
publication identity/custody, and retirement checks run unchanged from c80.
"""
from __future__ import annotations

from collections import Counter
from hashlib import sha256
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import statistics
import sys
import tempfile
import time
from unittest.mock import patch
import zipfile

HERE = Path(__file__).resolve().parent
SOURCE_EVIDENCE = HERE.parent / 'hia-ci-c80eb2'
spec = importlib.util.spec_from_file_location('previous_archive_probe', SOURCE_EVIDENCE / 'profile_archive_candidate.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
BASELINE = HERE / 'archive-baseline-c80eb2.py'
STORED = HERE / 'archive-stored-experimental.py'
ARTIFACT = SOURCE_EVIDENCE / 'c80eb2-native-attempt1.zip'
EXPECTED = 'c1d137bf8f54afaff613e725c152e84ecb19cab20fd03f94531e8392ffef11ec'


def file_digest(path):
    state = sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            state.update(chunk)
    return state.hexdigest()


def measured_module(path, label, observations):
    module = previous.module(path, 'archive_stored_probe_' + label)
    for name in ('_archive_sha256', 'verify_archive'):
        original = getattr(module, name)
        def invoke(*args, _name=name, _original=original, **kwargs):
            started, cpu_started = time.monotonic_ns(), time.process_time_ns()
            result = _original(*args, **kwargs)
            row = {'kind': _name, 'wall_ns': time.monotonic_ns() - started,
                   'cpu_ns': time.process_time_ns() - cpu_started}
            if _name == '_archive_sha256':
                row['packed_bytes_hashed'] = os.fstat(args[0]).st_size
            observations.append(row)
            return result
        setattr(module, name, invoke)
    return module


def summarize(rows):
    summary = {}
    for version in ('deflate_1', 'stored'):
        selected = [row for row in rows if row['version'] == version]
        summary[version] = {'wall_median_ns': statistics.median(row['wall_ns'] for row in selected),
                            'cpu_median_ns': statistics.median(row['cpu_ns'] for row in selected),
                            'wall_sum_ns': sum(row['wall_ns'] for row in selected),
                            'cpu_sum_ns': sum(row['cpu_ns'] for row in selected),
                            'archive_bytes': sorted({row['archive_bytes'] for row in selected}),
                            'packed_hash_wall_median_ns': statistics.median(sum(x['wall_ns'] for x in row['substeps'] if x['kind'] == '_archive_sha256') for row in selected)}
    return summary


def main():
    if file_digest(ARTIFACT) != EXPECTED:
        raise ValueError('original artifact digest mismatch')
    raw = ARTIFACT.read_bytes()
    with zipfile.ZipFile(io.BytesIO(raw)) as outer:
        packed = outer.read('hia-cold.cold/qualification.evidence/phase-runs/signed-original.zip')
    del raw
    baseline = previous.module(BASELINE, 'archive_stored_probe_reference')
    manifest = baseline.verify_archive(io.BytesIO(packed))
    rows = []
    output = HERE / 'benchmark.json'
    initial_disk = {name: shutil.disk_usage(name)._asdict() for name in ('/tmp', str(HERE))}
    with tempfile.TemporaryDirectory(prefix='hia-stored-owned-stage-', dir='/tmp') as temporary:
        root = Path(temporary) / 'stage'
        for round_number in range(1, 4):
            order = [('deflate_1', BASELINE), ('stored', STORED)]
            if round_number == 2:
                order.reverse()
            for label, source in order:
                previous.populate(packed, root, manifest)
                observations = []
                module = measured_module(source, label, observations)
                token = (root / module.OWNER).read_text()
                started, cpu_started = time.monotonic_ns(), time.process_time_ns()
                with patch('zipfile.time.time', return_value=1700000000):
                    receipt = module.archive_completed_stage(root, token)
                wall_ns, cpu_ns = time.monotonic_ns() - started, time.process_time_ns() - cpu_started
                archive = Path(receipt['archive'])
                replay = baseline.verify_archive(archive)
                assert replay['files'] == manifest['files']
                assert replay['unpacked_bytes'] == manifest['unpacked_bytes']
                assert replay['source_directory'] == str(root)
                assert receipt['archive_sha256'] == file_digest(archive)
                assert Counter(x['kind'] for x in observations) == {'_archive_sha256': 3, 'verify_archive': 1}
                with zipfile.ZipFile(archive) as verified:
                    method_counts = Counter(info.compress_type for info in verified.infolist())
                    if label == 'stored':
                        assert method_counts == {zipfile.ZIP_STORED: len(manifest['files']) + 1}
                    else:
                        assert method_counts == {zipfile.ZIP_DEFLATED: len(manifest['files']) + 1}
                row = {'version': label, 'round': round_number, 'wall_ns': wall_ns, 'cpu_ns': cpu_ns,
                       'files': receipt['files'], 'raw_bytes': receipt['unpacked_bytes'],
                       'archive_bytes': receipt['packed_bytes'], 'archive_sha256': receipt['archive_sha256'],
                       'manifest_sha256': receipt['manifest_sha256'], 'source_sha256': file_digest(source),
                       'member_bytes_and_modes_equal': True, 'replay_manifest_equal': True,
                       'fresh_stage_retired_only_after_all_checks': not (root / module.OWNER).exists(),
                       'compression_method_counts': dict(method_counts), 'substeps': observations}
                rows.append(row)
                print(json.dumps(row, sort_keys=True), flush=True)
                # This is only the newly reconstructed benchmark stage; pinned
                # CI archives and original source evidence are never changed.
                shutil.rmtree(root)
                archive.unlink()
    result = {'schema': 'hepta.hia.archive-stored-experiment.v1',
              'original_artifact_sha256': EXPECTED, 'original_nested_signed_sha256': sha256(packed).hexdigest(),
              'baseline_commit': 'c80eb2ecc5d08421a3d124c879edb33cefff2267',
              'baseline_source_sha256': file_digest(BASELINE), 'stored_source_sha256': file_digest(STORED),
              'compression_only_source_change': BASELINE.read_bytes().replace(b'compression=zipfile.ZIP_DEFLATED,compresslevel=1', b'compression=zipfile.ZIP_STORED') == STORED.read_bytes(),
              'rows': rows, 'summary': summarize(rows), 'disk_before': initial_disk,
              'zip_manifest_timestamp_frozen_for_reproducibility': True,
              'full_zip_byte_identity_claimed': False, 'phase_workers_changed': False,
              'qualification_deadline_changed': False, 'qualification_pass': False,
              'production_modified': False, 'python': sys.version,
              'filesystem': 'local /tmp tmpfs; does not model GitHub SSD throughput'}
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'output': str(output), 'summary': result['summary']}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
