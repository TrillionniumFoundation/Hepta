"""Independent full-outcome differential audit of the frozen JSON span candidate.

This runner writes evidence only. It never updates either production checkout,
never supplies a correctness cache, and never executes a selected native image.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import random
import statistics
import sys
import time
import types
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta-json-candidate')
BASELINE = HERE / 'preflight-baseline-c80eb2.py'
CANDIDATE = HERE / 'preflight-candidate-snapshot.py'
PRODUCTION = ROOT / 'hepta/hia_json_preflight.py'
SEED = 20261111031
sys.path.insert(0, str(ROOT))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def encoded(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode()


def kind(value):
    return type(value).__module__ + '.' + type(value).__qualname__


def capture(function, *args, **kwargs):
    try:
        result = function(*args, **kwargs)
    except BaseException as error:
        return {'exception_type': kind(error), 'exception_text': str(error),
                'exception_args': [repr(value) for value in error.args]}
    return {'return_type': kind(result), 'return_value': result}


class Audit:
    def __init__(self, baseline, candidate, ledger):
        self.baseline, self.candidate, self.ledger = baseline, candidate, ledger
        self.groups = defaultdict(lambda: {'cases': 0, 'matched': 0, 'baseline_outcomes': Counter(),
                                          'input_digest': sha256(), 'baseline_digest': sha256(),
                                          'candidate_digest': sha256()})
        self.mismatches = []

    def check(self, group, text, nodes=262144, depth=128, *, public=False, runner=None):
        method = 'preflight_hia_json' if public else '_preflight_hia_json_reference'
        call = runner or (lambda module: capture(getattr(module, method), text,
                                                max_nodes=nodes, max_depth=depth))
        old, new = call(self.baseline), call(self.candidate)
        spec = {'text_type': kind(text), 'text_repr': repr(text),
                'max_nodes_type': kind(nodes), 'max_nodes_repr': repr(nodes),
                'max_depth_type': kind(depth), 'max_depth_repr': repr(depth), 'entry': method}
        raw_spec = encoded(spec)
        input_hash = sha256(raw_spec).hexdigest()
        stats = self.groups[group]
        stats['cases'] += 1
        stats['input_digest'].update(raw_spec + b'\n')
        stats['baseline_digest'].update(encoded(old) + b'\n')
        stats['candidate_digest'].update(encoded(new) + b'\n')
        outcome = old.get('exception_type', old.get('return_type', 'selector'))
        stats['baseline_outcomes'][outcome] += 1
        same = old == new
        stats['matched'] += same
        row = {'group': group, 'case': stats['cases'], 'input_sha256': input_hash,
               'input_characters': len(text) if isinstance(text, (str, bytes, list, dict)) else None,
               'input': spec if len(raw_spec) <= 4096 else {'omitted_long_input': True,
                                                         'reproduce_with_script_seed': SEED},
               'baseline': old, 'candidate': new, 'equal': same}
        self.ledger.write(encoded(row) + b'\n')
        if not same:
            self.mismatches.append(row)

    def group_done(self, group):
        row = self.groups[group]
        print(json.dumps({'group': group, 'cases': row['cases'], 'matched': row['matched']}), flush=True)

    def summary(self):
        return {name: {key: dict(value) if isinstance(value, Counter)
                      else value.hexdigest() if key.endswith('_digest') else value
                      for key, value in row.items()}
                for name, row in self.groups.items()}


def exhaustive_units(audit):
    for unit in range(65536):
        token = '"\\u%04x"' % unit
        audit.check('escaped_bmp_value', token, nodes=1, depth=0)
        audit.check('escaped_bmp_key', '{' + token + ':0}', nodes=2, depth=1)
    audit.group_done('escaped_bmp_value')
    audit.group_done('escaped_bmp_key')
    for unit in range(65536):
        audit.check('raw_bmp_value', '"' + chr(unit) + '"', nodes=1, depth=0)
    audit.group_done('raw_bmp_value')
    for index in range(1024):
        high, low = 0xd800 + index, 0xdc00 + ((index * 251) % 1024)
        token = '"\\u%04x\\u%04x"' % (high, low)
        audit.check('paired_surrogates', token, nodes=1, depth=0)
        character = chr(0x10000 + ((high - 0xd800) << 10) + low - 0xdc00)
        audit.check('paired_surrogate_duplicate', '{' + token + ':0,"' + character + '":1}', nodes=2, depth=1)
        for suffix in ('', '\\u0000', '\\ud7ff', '\\ud800', '\\udbff', '\\ue000', '\\uffff', '\\uGGGG'):
            audit.check('malformed_surrogate_pairs', '"\\u%04x' % high + suffix + '"', nodes=1, depth=0)
    for group in ('paired_surrogates', 'paired_surrogate_duplicate', 'malformed_surrogate_pairs'):
        audit.group_done(group)


def syntax_and_budgets(audit):
    valid = ['null', 'true', 'false', '0', '-0', '1', '-123', '[]', '{}', '[0]', '{"k":0}',
             '"\\b\\f\\n\\r\\t\\/\\\\\\\""', '"\ufeff\u2028\u2029𐐷😀"']
    invalid = ['', ' ', '\n\t', '-', '+0', '00', '01', '-00', '1.0', '1e4', 'NaN', 'Infinity',
               '[', '{', '[,]', '[0,]', '{"x":0,}', '{"x" 0}', '{"x":}', '[]{}', '[0 1]',
               'nul', 'truth', 'truefalse', '"', '"\\', '"\\u', '"\\u0', '"\\u00', '"\\u000',
               '"\\x"', '"\\uG000"', '"\\u00G0"', '"\\ud800a\\udc00"', '"\\udc00\\ud800"',
               '"\\ud800\\uDC00', '"\\ud800\\Udc00"', '"\\ud800\\uDC0g"']
    for value in valid + invalid:
        for nodes in (1, 2, 3, 16):
            for depth in (0, 1, 2, 128):
                audit.check('grammar_budget_error_order', value, nodes, depth)
    for code in range(256):
        audit.check('escape_byte_alphabet', '"\\' + chr(code) + '"')
        for position in range(4):
            digits = '0000'
            digits = digits[:position] + chr(code) + digits[position + 1:]
            audit.check('unicode_escape_byte_alphabet', '"\\u' + digits + '"')
    for character in ['٠', '١', '２', '９', '²', '𝟡', '\u00a0', '\u0085', '\v', '\f', '\ufeff', 'Ω']:
        for wire in [character, ' ' + character, '1' + character, '0' + character,
                     '-' + character, '[' + character + ']', '0' + character + ' ']:
            audit.check('non_ascii_digits_and_whitespace', wire)
    for size in (0, 1, 2, 15, 16, 17, 63, 64, 65, 127, 128, 129, 256, 1024):
        for wire in ['[' * size + '0' + ']' * size, '{"k":' * size + '0' + '}' * size,
                     '[' + ','.join('0' for _ in range(size)) + ']']:
            for nodes in sorted({1, max(1, size), size + 1, size + 2}):
                for depth in sorted({0, max(0, size - 1), size, size + 1}):
                    audit.check('exact_depth_and_node_boundaries', wire, nodes, depth)
    for spelling in ['a', 'Ω', '𐐷', '\x00', '"\\', 'ordinary' * 1024]:
        literal, escaped = json.dumps(spelling, ensure_ascii=False), json.dumps(spelling, ensure_ascii=True)
        wire = '{' + literal + ':0,' + escaped + ':"\ud800"}'
        for nodes in (1, 2, 3):
            for depth in (0, 1, 2):
                audit.check('duplicate_key_precedence', wire, nodes, depth)
        audit.check('nested_key_scopes', '{' + literal + ':{' + escaped + ':0}}', 3, 2)
    class Text(str):
        pass
    class Number(int):
        pass
    for text in [None, b'{}', [], {}, 0, True, Text('{}')]:
        audit.check('invalid_api_types', text, public=True)
    for nodes, depth in [(False, 0), (True, 0), (0, 0), (-1, 0), (1.0, 0), (Number(1), 0),
                         (1, True), (1, -1), (1, 1.0), (1, Number(1)), (None, None)]:
        audit.check('invalid_api_types', '[]', nodes, depth, public=True)
    for group in list(audit.groups):
        if group not in {'escaped_bmp_value', 'escaped_bmp_key', 'raw_bmp_value', 'paired_surrogates',
                          'paired_surrogate_duplicate', 'malformed_surrogate_pairs'}:
            audit.group_done(group)


def long_spans(audit):
    contents = ['a' * 131072, 'Ω漢𐐷😀' * 32768, ('ordinary\\n\\u0041' * 8192)]
    endings = ['"', '', '\\', '\\n"', '\\u0041"', '\\ud800\\udc00"', '\\ud800"',
               '\\udc00"', '\\uG001"', '\x00"', '\x1f"', '\ud800"', '\udfff"', '" junk']
    for content in contents:
        for ending in endings:
            audit.check('long_string_spans', '"' + content + ending, 1, 0)
    whitespace = ' \t\r\n' * 65536
    digits = '1234567890' * 32768
    for wire in [whitespace, whitespace + '0' + whitespace, whitespace + '-' + digits + whitespace,
                 whitespace + '0' + digits, whitespace + digits + '０', whitespace + '\u00a0' + '0',
                 '[' + whitespace + '0,' + whitespace + '1' + whitespace + ']']:
        for nodes in (1, 2, 3):
            audit.check('long_digit_whitespace_spans', wire, nodes, 1)
    audit.group_done('long_string_spans')
    audit.group_done('long_digit_whitespace_spans')


def randomized(audit):
    rng = random.Random(SEED)
    alphabet = ['a', 'z', '0', '[', ']', '{', '}', ':', ',', ' ', '\n', '\t', '\\', '"',
                'Ω', '漢', '😀', '𐐷', '\u2028', '\ufeff', '\x00', '\x1f']
    def tree(depth=0):
        if depth < 5 and rng.randrange(3):
            if rng.randrange(2):
                return [tree(depth + 1) for _ in range(rng.randrange(5))]
            return {str(index) + ''.join(rng.choices(alphabet, k=rng.randrange(12))): tree(depth + 1)
                    for index in range(rng.randrange(5))}
        return rng.choice([None, False, True, rng.randrange(-(1 << 127), 1 << 127),
                           ''.join(rng.choices(alphabet, k=rng.randrange(80)))])
    def shape(value, depth=0):
        children = value.values() if isinstance(value, dict) else value if isinstance(value, list) else []
        descendants = [shape(child, depth + 1) for child in children]
        return (1 + sum(row[0] for row in descendants), max([depth] + [row[1] for row in descendants]))
    mutations = alphabet + ['\ud800', '\udfff', '/', '-', 'e', '９', '\u0085']
    for _ in range(3000):
        value = tree()
        nodes, depth = shape(value)
        for ensure_ascii in (False, True):
            wire = json.dumps(value, ensure_ascii=ensure_ascii, separators=rng.choice([(',', ':'), (', ', ': ')]))
            for node_limit, depth_limit in [(nodes, depth), (max(1, nodes - 1), depth),
                                            (nodes, max(0, depth - 1)), (nodes + 1, depth + 1)]:
                audit.check('fixed_seed_random_trees', wire, node_limit, depth_limit)
            for mutation in range(8):
                at = rng.randrange(len(wire) + 1)
                token = rng.choice(mutations)
                if mutation % 4 == 0:
                    changed = wire[:at] + token + wire[at:]
                elif mutation % 4 == 1:
                    changed = wire[:at] + wire[at + 1:]
                elif mutation % 4 == 2:
                    changed = wire[:at] + token + wire[at + 1:]
                else:
                    changed = wire[:at]
                audit.check('fixed_seed_wire_mutations', changed,
                            rng.choice([1, nodes, nodes + 1, 262144]), rng.choice([0, depth, depth + 1, 128]))
    audit.group_done('fixed_seed_random_trees')
    audit.group_done('fixed_seed_wire_mutations')


def selector(audit):
    cases = [('null', 1, 0), ('invalid native syntax', 1, 0), ('"\ud800"', 1, 0),
             ('null', 1048576, 128), ('null', 1048577, 128), ('null', 1, 129),
             ('null', True, 0), (b'null', 1, 0)]
    for length in (8388607, 8388608, 8388609):
        cases.append(('"' + 'a' * (length - 2) + '"', 1, 0))
    for length in (4194303, 4194304):
        cases.append(('"' + 'Ω' * length + '"', 1, 0))
    for manifest in ('', '/explicit/operator/selected-manifest.json'):
        for native_error in (False, True):
            for text, nodes, depth in cases:
                def run(module):
                    calls = []
                    native = types.ModuleType('hepta.hia_json_preflight_native')
                    def install(path):
                        calls.append({'installed_manifest': path})
                        class Adapter:
                            def admit(self, wire, **budgets):
                                calls.append({'wire_sha256': sha256(wire).hexdigest(), 'wire_bytes': len(wire),
                                              'budgets': budgets})
                                if native_error:
                                    raise ValueError('selected native failure must propagate; no fallback')
                        return Adapter()
                    native.installed_preflight = install
                    with patch.dict(os.environ, {'HEPTA_HIA_JSON_PREFLIGHT_MANIFEST': manifest}), \
                         patch.dict(sys.modules, {'hepta.hia_json_preflight_native': native}):
                        result = capture(module.preflight_hia_json, text, max_nodes=nodes, max_depth=depth)
                    return {'outcome': result, 'native_calls': calls}
                audit.check('public_native_selector_boundaries', text, nodes, depth, public=True, runner=run)
    audit.group_done('public_native_selector_boundaries')


def attributes(audit):
    from hepta import hia_agent_assembly as assembly
    from hepta import hia_json_decode as decoder
    source_path = ROOT / 'examples/hia_bootstrap/selfhost.hiaasm'
    source = source_path.read_bytes()
    work = []
    for line_number, line in enumerate(source.decode('utf-8').splitlines(), 1):
        match = assembly._INSTRUCTION.fullmatch(line.strip())
        if match:
            work.append((match[4], line_number))
    def run(module):
        with patch.object(assembly, 'preflight_hia_json', module.preflight_hia_json), \
             patch.object(decoder, 'preflight_hia_json', module.preflight_hia_json):
            return [assembly._attrs(text, number) for text, number in work]
    old, new = run(audit.baseline), run(audit.candidate)
    if old != new:
        raise AssertionError('actual selfhost attrs return differs')
    result_digest = sha256(encoded(old)).hexdigest()
    assert sys.getprofile() is None and sys.gettrace() is None
    rows = []
    for round_index in range(5):
        sequence = [('baseline', audit.baseline), ('candidate', audit.candidate)]
        if round_index % 2:
            sequence.reverse()
        for label, module in sequence:
            with patch.object(assembly, 'preflight_hia_json', module.preflight_hia_json), \
                 patch.object(decoder, 'preflight_hia_json', module.preflight_hia_json):
                started, cpu_started = time.monotonic_ns(), time.process_time_ns()
                for repeat in range(8):
                    results = [assembly._attrs(text, number) for text, number in work]
                elapsed, cpu_elapsed = time.monotonic_ns() - started, time.process_time_ns() - cpu_started
            assert results == old
            rows.append({'implementation': label, 'round': round_index + 1, 'repetitions': 8,
                         'attrs_calls': len(work) * 8, 'wall_elapsed_ns': elapsed, 'process_cpu_ns': cpu_elapsed,
                         'result_sha256': sha256(encoded(results)).hexdigest()})
            print(json.dumps({'attrs_timing': rows[-1]}), flush=True)
    medians = {label: statistics.median(row['wall_elapsed_ns'] for row in rows if row['implementation'] == label)
               for label in ('baseline', 'candidate')}
    return {'source': str(source_path), 'source_sha256': sha256(source).hexdigest(),
            'attribute_calls_per_program': len(work), 'nonempty_attribute_strings': sum(text is not None for text, _ in work),
            'result_sha256': result_digest, 'all_returns_equal': old == new, 'both_preflights_retained': True,
            'rows': rows, 'median_wall_ns': medians,
            'median_reduction_fraction': 1 - medians['candidate'] / medians['baseline']}


def main():
    before = {name: sha256(path.read_bytes()).hexdigest() for name, path in
              [('baseline', BASELINE), ('candidate', CANDIDATE), ('production', PRODUCTION)]}
    if before['candidate'] != before['production']:
        raise ValueError('candidate snapshot no longer matches production')
    baseline = load(BASELINE, 'hepta._audit_baseline_preflight')
    candidate = load(CANDIDATE, 'hepta._audit_candidate_preflight')
    started = time.monotonic_ns()
    with patch.dict(os.environ, {'HEPTA_HIA_JSON_PREFLIGHT_MANIFEST': '', 'HEPTA_HIA_JSON_DECODE_MANIFEST': ''}), \
         gzip.open(HERE / 'outcomes.jsonl.gz', 'wb') as ledger:
        audit = Audit(baseline, candidate, ledger)
        exhaustive_units(audit)
        syntax_and_budgets(audit)
        long_spans(audit)
        randomized(audit)
        selector(audit)
        attrs = attributes(audit)
    after = {name: sha256(path.read_bytes()).hexdigest() for name, path in
             [('baseline', BASELINE), ('candidate', CANDIDATE), ('production', PRODUCTION)]}
    groups = audit.summary()
    summary = {'schema': 'hepta.hia.json-span-independent-differential.v1',
               'baseline_git_commit': 'c80eb2ecc5d08421a3d124c879edb33cefff2267', 'random_seed': SEED,
               'source_sha256_before': before, 'source_sha256_after': after, 'source_unchanged': before == after,
               'groups': groups, 'cases': sum(row['cases'] for row in groups.values()),
               'matched': sum(row['matched'] for row in groups.values()), 'mismatches': audit.mismatches,
               'attrs': attrs, 'wall_elapsed_ns': time.monotonic_ns() - started,
               'python': sys.version, 'qualification_pass': False,
               'scope': 'Full returns and exception types/text vs c80 reference, selected native routing with inert stub, and real selfhost attrs. No native image admission or full cold replay claim.'}
    (HERE / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'summary': str(HERE / 'summary.json'), 'cases': summary['cases'],
                      'matched': summary['matched'], 'mismatches': len(audit.mismatches),
                      'source_unchanged': summary['source_unchanged'],
                      'attrs_median_reduction_fraction': attrs['median_reduction_fraction']}), flush=True)
    if audit.mismatches or before != after:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
