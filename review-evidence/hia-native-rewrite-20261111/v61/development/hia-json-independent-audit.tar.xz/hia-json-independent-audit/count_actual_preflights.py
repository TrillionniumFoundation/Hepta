"""Count, rather than omit, both actual selfhost attrs preflight calls."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from unittest.mock import patch
import os
import audit_json_spans as audit

from hepta import hia_agent_assembly as assembly
from hepta import hia_json_decode as decoder

source = audit.ROOT / 'examples/hia_bootstrap/selfhost.hiaasm'
work = []
for number, line in enumerate(source.read_text().splitlines(), 1):
    match = assembly._INSTRUCTION.fullmatch(line.strip())
    if match:
        work.append((match[4], number))
rows = []
for label, path in [('baseline', audit.BASELINE), ('candidate', audit.CANDIDATE)]:
    module = audit.load(path, 'hepta._count_' + label)
    calls = Counter()
    def observed(text, *, max_nodes, max_depth):
        calls[max_nodes, max_depth] += 1
        return module.preflight_hia_json(text, max_nodes=max_nodes, max_depth=max_depth)
    with patch.dict(os.environ, {'HEPTA_HIA_JSON_PREFLIGHT_MANIFEST': '', 'HEPTA_HIA_JSON_DECODE_MANIFEST': ''}), \
         patch.object(assembly, 'preflight_hia_json', observed), \
         patch.object(decoder, 'preflight_hia_json', observed):
        outputs = [assembly._attrs(text, number) for text, number in work]
    assert calls == {(2048, 16): 5630, (262144, 128): 5630}
    rows.append({'implementation': label, 'source_sha256': sha256(path.read_bytes()).hexdigest(),
                 'preflight_invocations': [{'max_nodes': n, 'max_depth': d, 'calls': count}
                                          for (n, d), count in sorted(calls.items())],
                 'result_sha256': sha256(audit.encoded(outputs)).hexdigest()})
result = {'schema': 'hepta.hia.actual-attrs-double-preflight-count.v1',
          'assembly_source_sha256': sha256(source.read_bytes()).hexdigest(),
          'attrs_calls': len(work), 'nonempty_attrs': 5630, 'rows': rows,
          'counts_equal': rows[0]['preflight_invocations'] == rows[1]['preflight_invocations'],
          'returns_equal': rows[0]['result_sha256'] == rows[1]['result_sha256']}
(audit.HERE / 'double-preflight-counts.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
