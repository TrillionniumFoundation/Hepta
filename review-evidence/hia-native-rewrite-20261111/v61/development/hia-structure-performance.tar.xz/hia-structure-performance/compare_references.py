"""Development-only exact old/new independent-reference comparison.

Each observation starts a fresh Python process; these are no cold/native
qualification results. The unchanged full reference is actually executed.
"""
import argparse
import ast
import hashlib
import importlib
import json
import lzma
from pathlib import Path
import subprocess
import sys
import time

BASE = "c80eb2ecc5d08421a3d124c879edb33cefff2267"
ROOT = Path("/workspace/scratch/9acdfa9f5639/Hepta-structure-candidate")
OUTPUT = Path(__file__).resolve().parent
FAMILIES = {
    "names": "tools.hia_selfhost_names",
    "signed": "tools.hia_selfhost_signed_cases",
    "scalar-casts": "tools.hia_selfhost_scalar_casts",
}


def child(family, variant):
    sys.path.insert(0, str(ROOT))
    from hepta import hia_program as core
    original = subprocess.check_output(
        ["git", "show", BASE + ":hepta/hia_program.py"], cwd=ROOT)
    if variant == "baseline":
        tree = ast.parse(original)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name in {
                    "_structure", "_bounded_detached_snapshot"}:
                exec(compile(ast.Module(body=[node], type_ignores=[]),
                             "c80eb2-frozen-traversal", "exec"), core.__dict__)
    reference = importlib.import_module(FAMILIES[family]).independent_reference
    wall, cpu = time.perf_counter(), time.process_time()
    report = reference()
    elapsed_wall, elapsed_cpu = time.perf_counter() - wall, time.process_time() - cpu
    raw = json.dumps(report, sort_keys=True, separators=(",", ":")).encode()
    path = OUTPUT / (family + "-" + variant + ".reference.json.xz")
    path.write_bytes(lzma.compress(raw))
    return {"family": family, "variant": variant,
            "wall_seconds": elapsed_wall, "process_cpu_seconds": elapsed_cpu,
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "cases": len(report.get("cases", [])),
            "refusals": len(report.get("refusals", [])),
            "traps": len(report.get("traps", [])),
            "raw_artifact": str(path),
            "baseline_program_sha256": hashlib.sha256(original).hexdigest(),
            "candidate_program_sha256": hashlib.sha256((ROOT / "hepta/hia_program.py").read_bytes()).hexdigest(),
            "cold_qualification": False}


def parent():
    observations = []
    comparisons = []
    for family in FAMILIES:
        # Alternate order to avoid attributing a consistently cold first run
        # to the old implementation. All six actual workers are fresh.
        variants = ("candidate", "baseline") if family == "signed" else ("baseline", "candidate")
        current = {}
        for variant in variants:
            completed = subprocess.run(
                [sys.executable, "-B", str(Path(__file__).resolve()),
                 "--family", family, "--variant", variant],
                cwd=ROOT, capture_output=True, text=True, check=True)
            row = json.loads(completed.stdout)
            observations.append(row); current[variant] = row
            print(json.dumps(row, sort_keys=True), flush=True)
        old, new = current["baseline"], current["candidate"]
        same = (lzma.decompress(Path(old["raw_artifact"]).read_bytes())
                == lzma.decompress(Path(new["raw_artifact"]).read_bytes()))
        comparisons.append({"family": family, "entire_reference_bytes_equal": same,
                            "wall_seconds_saved": old["wall_seconds"] - new["wall_seconds"],
                            "cpu_seconds_saved": old["process_cpu_seconds"] - new["process_cpu_seconds"]})
        report = {"schema": "hepta.hia.structure-efficiency-development.v1",
                  "base_commit": BASE, "observations": observations,
                  "comparisons": comparisons, "cold_qualification": False,
                  "deadline_seconds_unchanged": 180, "qualification_workers_unchanged": 2,
                  "native_witnesses_removed": 0, "admission_results_cached": False,
                  "whole_native_stack_qualified": False}
        (OUTPUT / "comparison.json").write_text(json.dumps(report, indent=2) + "\n")
        if not same:
            raise AssertionError("full independent reference differs: " + family)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--family", choices=FAMILIES)
    parser.add_argument("--variant", choices=("baseline", "candidate"))
    args = parser.parse_args()
    if args.family:
        print(json.dumps(child(args.family, args.variant), sort_keys=True))
    else:
        parent()
