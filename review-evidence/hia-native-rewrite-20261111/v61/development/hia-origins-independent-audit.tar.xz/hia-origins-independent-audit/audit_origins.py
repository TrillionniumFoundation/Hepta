"""Independent bounded DAG/origin differential against the real HIA image.

The native entry is called normally and observed after return. No synthetic
image, returned frame, correctness cache, or production file is supplied.
"""
from __future__ import annotations

import ast
from collections import Counter
from copy import deepcopy
import ctypes
from hashlib import sha256
import json
import os
from pathlib import Path
import random
import struct
import subprocess
import sys
import time
from unittest.mock import patch

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-elaborator-next')
HERE = Path(__file__).resolve().parent
MANIFEST = Path('/workspace/scratch/9acdfa9f5639/native-origins-development/manifest.json')
BASE = 'c80eb2ecc5d08421a3d124c879edb33cefff2267'
SEED = 0x484941_20261111_73
sys.path.insert(0, str(ROOT))


def wire(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return sha256(wire(value)).hexdigest()


def inventory():
    paths = set()
    for command in (['git', 'ls-files', '-z'], ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        paths.update(subprocess.check_output(command, cwd=ROOT).decode().split('\0'))
    paths.discard('')
    result = {}
    for name in sorted(paths):
        path = ROOT / name
        if not path.is_file() or path.is_symlink():
            raise ValueError('unexpected nonordinary source entry: ' + name)
        data = path.read_bytes()
        result[name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
    return result


def bindings():
    manifest = json.loads(MANIFEST.read_bytes())
    image = MANIFEST.parent / manifest['image_path']
    paths = {'manifest': MANIFEST, 'image': image,
             'adapter': ROOT / 'hepta/hia_composite_types_native.py',
             'source': ROOT / 'examples/hia_bootstrap/composite_types.hiaasm',
             'generator': ROOT / 'tools/generate_hia_composite_types.py',
             'reference_owner': ROOT / 'hepta/hia_program_composite.py'}
    result = {name: {'path': str(path), 'bytes': path.stat().st_size,
                     'sha256': sha256(path.read_bytes()).hexdigest()} for name, path in paths.items()}
    assert result['image']['sha256'] == manifest['image_sha256']
    assert result['source']['sha256'] == manifest['source_sha256']
    result['manifest_value'] = manifest
    return result


def reference_helper_ast(source):
    module = ast.parse(source)
    owner = next(node for node in module.body if isinstance(node, ast.ClassDef) and node.name == '_Elaborator')
    method = next(node for node in owner.body if isinstance(node, ast.FunctionDef) and node.name == 'loan_origins')
    return ast.dump(method, include_attributes=False)


def record(name, fields, params=()):
    return {'name': name, 'params': list(params), 'kind': 'record',
            'fields': [{'name': key, 'type': value} for key, value in fields]}


def ref(name, *args):
    return {'name': name, 'args': list(args)}


def shuffled(rng, pairs):
    result = list(pairs)
    rng.shuffle(result)
    return result


def graph(number, rng):
    definitions = [record('Empty', [])]
    zeros = ['Empty']
    for index in range(rng.randrange(2, 6)):
        name = 'Zero' + str(index)
        definitions.append(record(name, [('z' + str(i), rng.choice(zeros)) for i in range(rng.randrange(1, 5))]))
        zeros.append(name)
    definitions += [
        record('GBox', shuffled(rng, [('gap', rng.choice(zeros)), ('pad', rng.choice(['u8', 'unit', 'Empty'])), ('body', 'T')]), ['T']),
        record('GPair', shuffled(rng, [('first', 'T'), ('second', 'U'), ('zero', rng.choice(zeros))]), ['T', 'U']),
        record('GWrap', shuffled(rng, [('pair', ref('GPair', 'T', 'U')), ('empty', rng.choice(zeros))]), ['T', 'U']),
        record('Plain', [('n' + str(i), rng.choice(['u8', 'i16', 'bool', 'unit', 'Empty'])) for i in range(rng.randrange(1, 6))]),
        record('Views', shuffled(rng, [('zero', zeros[-1]), ('prefix', 'Plain'),
            ('inside', ref('GWrap', ref('GBox', 'readbuf'), ref('GBox', 'mutbuf'))), ('tail', 'readbuf')])),
        record('MixedOwner', shuffled(rng, [('views', 'Views'), ('owner', 'buffer'), ('zero', zeros[-1])])),
    ]
    # Every random record refers only to an earlier concrete record or one of
    # the three bounded generic templates. Width bounds prevent accidental
    # quota failures from replacing the origins scenarios under examination.
    pool = [(name, 0) for name in zeros] + [('Plain', 5), ('readbuf', 1), ('mutbuf', 1),
                                         ('buffer', 1), ('u8', 1), ('i32', 1), ('unit', 1)]
    concrete = []
    for index in range(rng.randrange(7, 15)):
        fields, width = [], 0
        for child_index in range(rng.randrange(0, 6)):
            selected, size = rng.choice([(item, width) for item, width in pool if width <= 24])
            selected = deepcopy(selected)
            flavor = rng.randrange(4)
            if flavor == 1:
                selected, size = ref('GBox', selected), size + 1
            elif flavor == 2:
                other, other_size = rng.choice([(item, width) for item, width in pool if width <= 8])
                selected, size = ref('GPair', selected, deepcopy(other)), size + other_size
            elif flavor == 3:
                other = rng.choice(['Empty', 'readbuf', 'mutbuf', 'buffer', 'u8'])
                selected, size = ref('GWrap', selected, other), size + (other != 'Empty')
            fields.append(('f' + str(child_index), selected))
            width += size
        name = 'Node' + str(index)
        definitions.append(record(name, fields))
        pool.append((name, width))
        concrete.append(name)
    special = None
    if number % 16 == 0:
        for level in range(32):
            definitions.append(record('Deep' + str(level), [('next', 'readbuf' if not level else 'Deep' + str(level - 1))]))
        special = ('Deep31', ['next'] * 32, 0)
    elif number % 16 == 1:
        definitions += [record('Eight', [('p' + str(i), 'u8') for i in range(8)]),
                        record('Seven', [('p' + str(i), 'u8') for i in range(7)]),
                        record('Prefix511', [('p' + str(i), 'Eight') for i in range(63)] + [('last', 'Seven')]),
                        record('At511', [('empty', zeros[-1]), ('prefix', 'Prefix511'), ('loan', 'readbuf')])]
        special = ('At511', ['loan'], 511)
    return definitions, concrete, special


def view_signature(typ, memo=None):
    memo = {} if memo is None else memo
    identity = id(typ)
    if identity not in memo:
        memo[identity] = digest({'kind': typ.kind, 'flat': typ.flat,
            'primitive': typ.key if typ.kind == 'primitive' else None,
            'fields': [(name, view_signature(child, memo)) for name, child in typ.fields],
            'owns': typ.owns, 'has_loans': typ.has_loans})
    return memo[identity]


def leaves(typ, path=(), offset=0):
    if typ.kind == 'primitive':
        return [(path, offset, typ.key)]
    result, position = [], offset
    for name, child in typ.fields:
        # Empty products have no primitive leaf and do not advance the offset.
        if child.flat:
            result.extend(leaves(child, (*path, name), position))
        position += len(child.flat)
    return result


def origin(name, path=()):
    return {'param': name, 'fields': list(path)}


def cases(number, rng, original, concrete, special):
    names = {key: 'p' + str(number) + '_' + key for key in ('views', 'owned', 'reader', 'writer', 'plain', 'empty')}
    base_params = [(names['views'], 'Views'), (names['owned'], 'MixedOwner'),
                   (names['reader'], 'readbuf'), (names['writer'], 'mutbuf'),
                   (names['plain'], 'Plain'), (names['empty'], 'Empty')]
    extras = [('extra' + str(i), value) for i, value in enumerate(rng.sample(concrete, min(len(concrete), 5)))]
    if special:
        base_params.append(('special', special[0]))
    view = original.resolve('Views')
    loan_leaves = [row for row in leaves(view) if row[2] in ('readbuf', 'mutbuf')]
    nested = rng.choice([row for row in loan_leaves if len(row[0]) > 1])
    bad_name = rng.choice([None, False, 17, [], {}, '', 'bad-name', 'é', '__hia_reserved', 'h2internal_reserved', 'x' * 129])
    missing = 'absent' + str(rng.randrange(1 << 20))
    prefix = list(nested[0][:rng.randrange(len(nested[0]))])
    data = []
    def add(label, function, returns, expected_id=None, expected_value=None):
        params = base_params + rng.sample(extras, rng.randrange(len(extras) + 1))
        rng.shuffle(params)
        data.append({'label': label, 'function': function, 'params': params, 'returns': returns,
                     'wanted_error_id': expected_id, 'wanted_value': expected_value})
    add('absent-empty', {}, [], 0, ())
    add('absent-nonloan', {}, ['u8', 'Empty', 'buffer'], 0, (None, None, None))
    add('null-with-empty', {'return_loans': None}, [], 37)
    add('arity-short', {'return_loans': []}, ['readbuf'], 37)
    add('absent-borrow', {}, ['readbuf'], 1)
    add('null-borrow', {'return_loans': [None]}, ['readbuf'], 1)
    target_name, target_path, target_offset = (('special', special[1], special[2]) if special else
                                              (names['views'], nested[0], nested[1]))
    result_type = 'readbuf' if special or nested[2] == 'readbuf' else rng.choice(['readbuf', 'mutbuf'])
    add('valid-nested-slot', {'return_loans': [origin(target_name, target_path)]}, [result_type], 0,
        ((target_name, target_offset),))
    add('mutable-to-read', {'return_loans': [origin(names['writer'])]}, ['readbuf'], 0, ((names['writer'], 0),))
    add('read-to-mutable-refusal', {'return_loans': [origin(names['reader'])]}, ['mutbuf'], 44)
    add('lookup-before-path', {'return_loans': [{'param': missing, 'fields': None}]}, ['readbuf'], 39)
    add('owned-before-path', {'return_loans': [{'param': names['owned'], 'fields': None}]}, ['readbuf'], 40)
    add('nonloan-before-origin-shape', {'return_loans': [False]}, ['u8'], 38)
    add('field-name-before-kind', {'return_loans': [origin(names['reader'], [bad_name])]}, ['readbuf'],
        6 if isinstance(bad_name, str) and bad_name.startswith('h2internal_') else 5)
    add('arbitrary-missing-path', {'return_loans': [origin(names['views'], prefix + [missing])]}, ['readbuf'], 43)
    add('zero-width-terminal', {'return_loans': [origin(names['views'], ['zero'])]}, ['readbuf'], 44)
    add('path-length-before-field', {'return_loans': [origin(names['views'], [bad_name] * 33)]}, ['readbuf'], 41)
    add('path-list-shape', {'return_loans': [{'param': names['views'], 'fields': rng.choice([None, False, 1, 'field', {}])}]}, ['readbuf'], 41)
    add('result-order-nonloan-first', {'return_loans': [origin(missing), None]}, ['u8', 'readbuf'], 38)
    add('result-order-borrow-first', {'return_loans': [None, origin(missing)]}, ['readbuf', 'u8'], 1)
    add('name-before-lookup', {'return_loans': [{'param': bad_name, 'fields': None}]}, ['readbuf'],
        6 if isinstance(bad_name, str) and bad_name.startswith('h2internal_') else 5)
    add('inventory-before-name', {'return_loans': [{'param': bad_name, 'fields': [], 'slot': 0}]}, ['readbuf'], 1)
    result_types, annotations, expected = [], [], []
    for _ in range(rng.randrange(2, 9)):
        result = rng.choice(['u8', 'Empty', 'buffer', 'readbuf', 'mutbuf'])
        result_types.append(result)
        if result in ('readbuf', 'mutbuf'):
            eligible = [row for row in loan_leaves if result == 'readbuf' or row[2] == 'mutbuf']
            selected = rng.choice(eligible)
            annotations.append(origin(names['views'], selected[0]))
            expected.append((names['views'], selected[1]))
        else:
            annotations.append(None)
            expected.append(None)
    add('valid-random-multireturn', {'return_loans': annotations}, result_types, 0, tuple(expected))
    add('missing-before-later-bad-name', {'return_loans': [origin(names['views'], prefix + [missing, bad_name])]}, ['readbuf'], 43)
    add('primitive-before-extra-field', {'return_loans': [origin(names['views'], [*nested[0], 'extra'])]}, ['readbuf'], 42)
    assert len(data) == 24
    return data


def counters(reference):
    return {'cache_count': len(reference.cache), 'active_count': len(reference.active),
            'partial_declaration_steps': reference.partial_declaration_steps}


def capture(call, errors, exception_type):
    try:
        result = call()
    except exception_type as error:
        if error.code == 'E_HIA_FORMAT':
            identifier = 1
        elif error.code == 'E_HIA_NAME':
            identifier = 6 if 'identifier uses the elaborator namespace' in str(error) else 5
        else:
            exact = [key for key, (code, text) in errors.items()
                     if key >= 37 and str(error) == code + ': ' + text]
            identifier = exact[0] if len(exact) == 1 else None
        return {'error_category': error.code, 'error_text': str(error), 'error_id': identifier}
    return {'result': result, 'error_category': None, 'error_id': 0}


def main():
    before = inventory()
    bound_before = bindings()
    (HERE / 'source-inventory-before.json').write_bytes(wire(before) + b'\n')
    (HERE / 'bindings-before.json').write_bytes(wire(bound_before) + b'\n')
    baseline_source = subprocess.check_output(['git', 'show', BASE + ':hepta/hia_program_composite.py'], cwd=ROOT).decode()
    current_source = (ROOT / 'hepta/hia_program_composite.py').read_text()
    assert reference_helper_ast(baseline_source) == reference_helper_ast(current_source)
    from hepta import hia_program_composite as composite
    from hepta import hia_composite_types_native as native
    from hepta.hia_program import HIAProgramRejected
    assert Path(composite.__file__).resolve().is_relative_to(ROOT)
    assert Path(native.__file__).resolve().is_relative_to(ROOT)
    image = native.installed_composite_types(str(MANIFEST))
    original_entry = image._entry
    entries, results, graphs, findings = [], [], [], []
    commands = Counter()
    def observe_entry(source, length, output, capacity, state, state_size):
        raw = ctypes.string_at(source, length)
        command = json.loads(raw)
        extent = original_entry(source, length, output, capacity, state, state_size)
        unchanged = ctypes.string_at(source, length) == raw
        header = struct.unpack_from('<8Q', output) if 64 <= extent <= capacity else None
        commands[command['op']] += 1
        entries.append({'command': command['op'], 'input_bytes': length, 'input_sha256': sha256(raw).hexdigest(),
                        'input_unchanged': unchanged, 'extent': extent, 'header': header,
                        'frame_sha256': sha256(ctypes.string_at(output, extent)).hexdigest()
                        if 64 <= extent <= capacity else None})
        if not unchanged:
            raise AssertionError('real HIA entry changed command source bytes')
        return extent
    image._entry = observe_entry
    started = time.monotonic_ns()
    rng = random.Random(SEED)
    ledger = (HERE / 'outcomes.jsonl').open('wb')
    try:
        with patch.dict(os.environ, {native.SELECTOR: '', 'HEPTA_HIA_JSON_PREFLIGHT_MANIFEST': '',
                                     'HEPTA_HIA_JSON_DECODE_MANIFEST': ''}):
            for number in range(64):
                definitions, concrete, special = graph(number, rng)
                original_definitions = deepcopy(definitions)
                old = composite._Types(definitions, recursive_chain=True, partial_records=True)
                items = cases(number, rng, old, concrete, special)
                graph_record = {'graph': number, 'definitions': definitions, 'cases': items,
                                'definitions_sha256': digest(definitions), 'special_boundary': special}
                graphs.append(graph_record)
                with image.session(definitions, recursive_chain=True, partial_records=True) as session:
                    for item in items:
                        saved = deepcopy(item)
                        old_params, new_params = [], []
                        for name, reference in item['params']:
                            old_type, new_type = old.resolve(reference), session.resolve(reference)
                            assert view_signature(old_type) == view_signature(new_type)
                            old_params.append((name, old_type)); new_params.append((name, new_type))
                        old_returns, new_returns = [], []
                        for reference in item['returns']:
                            old_type, new_type = old.resolve(reference), session.resolve(reference)
                            assert view_signature(old_type) == view_signature(new_type)
                            old_returns.append(old_type); new_returns.append(new_type)
                        observed_before = session.observations
                        expected = capture(lambda: composite._Elaborator.loan_origins(item['function'], old_params, old_returns),
                                           native.ERRORS, HIAProgramRejected)
                        assert item == saved
                        actual = capture(lambda: session.loan_origins(item['function'], new_params, new_returns),
                                         native.ERRORS, HIAProgramRejected)
                        observed_after = session.observations
                        entry = entries[-1]
                        comparison = {'category_equal': expected['error_category'] == actual['error_category'],
                                      'first_error_id_equal': expected['error_id'] == actual['error_id'] == entry['header'][1],
                                      'result_equal': expected.get('result') == actual.get('result'),
                                      'specified_first_error': expected['error_id'] == item['wanted_error_id'],
                                      'specified_result': expected['error_id'] != 0 or expected['result'] == item['wanted_value'],
                                      'counters_unchanged': observed_before == observed_after == counters(old),
                                      'input_objects_unchanged': item == saved and definitions == original_definitions,
                                      'native_source_bytes_unchanged': entry['input_unchanged'],
                                      'real_origins_frame': entry['header'][0] == native.ORIGINS_MAGIC,
                                      'session_not_poisoned': not session._broken}
                        row = {'graph': number, 'case': item['label'], 'case_input': item,
                               'reference': expected, 'native': actual, 'before_counters': observed_before,
                               'after_counters': observed_after, 'native_entry': entry, 'checks': comparison,
                               'message_equality_for_errors_1_5_6_claimed': False}
                        ledger.write(wire(row) + b'\n'); ledger.flush()
                        results.append(row)
                        if not all(comparison.values()):
                            findings.append(row)
                            print(json.dumps({'finding': row}, ensure_ascii=True), flush=True)
                            raise AssertionError('new differential or ABI boundary counterexample')
                        # A real subsequent command proves semantic refusals did
                        # not poison the session, without relying only on a flag.
                        assert session.resolve('u8').flat == old.resolve('u8').flat
                        assert session.observations == observed_after == counters(old)
                print(json.dumps({'graph': number, 'definitions': len(definitions), 'cases': len(items),
                                  'completed': len(results), 'findings': len(findings)}), flush=True)
    finally:
        ledger.close()
        image._entry = original_entry
        after = inventory()
        bound_after = bindings()
        (HERE / 'source-inventory-after.json').write_bytes(wire(after) + b'\n')
        (HERE / 'bindings-after.json').write_bytes(wire(bound_after) + b'\n')
        (HERE / 'graphs.json').write_bytes(wire(graphs) + b'\n')
        (HERE / 'native-entries.json').write_bytes(wire(entries) + b'\n')
        (HERE / 'findings.json').write_bytes(wire(findings) + b'\n')
        summary = {'schema': 'hepta.hia.origins-independent-random-dag-differential.v1',
                   'random_seed': SEED, 'baseline_commit': BASE, 'reference_helper_ast_matches_c80': True,
                   'reference_helper_ast_sha256': sha256(reference_helper_ast(current_source).encode()).hexdigest(),
                   'graphs_generated': len(graphs), 'unique_definition_graphs': len({row['definitions_sha256'] for row in graphs}),
                   'cases_completed': len(results), 'findings': len(findings), 'command_counts': dict(commands),
                   'all_command_input_bytes_unchanged': all(row['input_unchanged'] for row in entries),
                   'all_case_checks': all(all(row['checks'].values()) for row in results),
                   'category_counts': dict(Counter(row['native']['error_category'] or 'ACCEPT' for row in results)),
                   'error_id_counts': dict(Counter(row['native']['error_id'] for row in results)),
                   'source_files': len(before), 'source_bytes': sum(row['bytes'] for row in before.values()),
                   'source_inventory_sha256_before': digest(before), 'source_inventory_sha256_after': digest(after),
                   'source_tree_unchanged': before == after, 'bindings_unchanged': bound_before == bound_after,
                   'bindings': bound_before, 'wall_elapsed_ns': time.monotonic_ns() - started,
                   'native_image_executed': True, 'synthetic_image_used': False, 'cold_qualified': False,
                   'production_modified': False, 'python': sys.version}
        (HERE / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
        print(json.dumps({'summary': str(HERE / 'summary.json'), 'cases': len(results),
                          'findings': len(findings), 'source_unchanged': before == after,
                          'bindings_unchanged': bound_before == bound_after}), flush=True)
    if findings or before != after or bound_before != bound_after or len(results) != 64 * 24:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
