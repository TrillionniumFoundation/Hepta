from pathlib import Path
import gzip, json, subprocess, sys
out=Path('/dev/shm/hia-batch-fixture-audit')
for name, root in [('old','/dev/shm/hia-cold-performance-next'),('new','/dev/shm/hia-batch-fixture-next')]:
    command=[sys.executable,'-B',str(out/'trace_reference.py'),'--root',root,'--output',str(out/name)]
    with (out/(name+'.stdout.log')).open('xb') as stdout, (out/(name+'.stderr.log')).open('xb') as stderr:
        result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=180)
    (out/(name+'.process.json')).write_text(json.dumps({'command':command,'returncode':result.returncode},indent=2)+'\n')
    if result.returncode: raise SystemExit(result.returncode)
    print(name+' complete',flush=True)
assert gzip.decompress((out/'old/reference.json.gz').read_bytes()) == gzip.decompress((out/'new/reference.json.gz').read_bytes())
def actual(name):
    rows=[json.loads(line) for line in gzip.decompress((out/name/'events.jsonl.gz').read_bytes()).splitlines()]
    return [{k:v for k,v in row.items() if k!='sequence'} for row in rows if row['scope']=='actual-public-witness']
assert actual('old') == actual('new')
summary={'scope':'DEVELOPMENT_EXACT_REFERENCE_AND_PUBLIC_INVOCATION_COMPARISON',
         'complete_reference_bytes_equal':True,'actual_public_witnesses_equal':True,
         'actual_public_invocation_count':len(actual('old')),'cold_qualification':False,
         'old':json.loads((out/'old/summary.json').read_text()),'new':json.loads((out/'new/summary.json').read_text())}
(out/'comparison.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
