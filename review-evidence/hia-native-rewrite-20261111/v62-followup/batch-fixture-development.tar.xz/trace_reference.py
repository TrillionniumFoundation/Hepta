"""Record actual public admissions/executions separately from fixture spelling."""
from pathlib import Path
import argparse, gzip, hashlib, inspect, json, os, sys, time
from unittest.mock import patch

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()
root, out = Path(a.root), Path(a.output)
out.mkdir()
sys.path.insert(0, str(root)); os.chdir(root)
for name in tuple(os.environ):
    if name.startswith('HEPTA_HIA_') and (name.endswith('_MANIFEST') or name.endswith('_COLD_REPORT')):
        os.environ.pop(name)
from hepta import hia_agent_assembly as assembly, hia_program as core
from tools.hia_selfhost_contract import file_digests
from tools import hia_selfhost_signed_cases as signed, hia_selfhost_scalar_casts as casts

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def identity(value):
    if isinstance(value, bytes):
        raw, kind = value, 'bytes'
    elif isinstance(value, str):
        raw, kind = value.encode(), 'str'
    elif isinstance(value, core.VerifiedProgram):
        raw, kind = canonical(value.as_dict()), 'VerifiedProgram'
    else:
        raw, kind = canonical(value), type(value).__name__
    return {'kind': kind, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

events = []
def observe(kind, original):
    def wrapped(*args, **kwargs):
        frame = inspect.currentframe().f_back
        construction = False
        while frame:
            if frame.f_code.co_filename.endswith('/tools/hia_selfhost_batch.py'):
                construction = True
            frame = frame.f_back
        row = {'sequence': len(events), 'kind': kind,
               'scope': 'fixture-construction' if construction else 'actual-public-witness',
               'input': [identity(arg) for arg in args], 'kwargs': identity(kwargs)}
        events.append(row)
        try:
            result = original(*args, **kwargs)
        except Exception as exc:
            row['outcome'] = {'exception': type(exc).__name__, 'text': str(exc)}
            for key in ('code', 'phase', 'line', 'report'):
                if hasattr(exc, key): row['outcome'][key] = getattr(exc, key)
            raise
        else:
            row['outcome'] = identity(result)
            return result
    return wrapped

before = file_digests()
(out/'source-before.json').write_bytes(canonical(before))
results, summary = {}, {}
with patch.object(assembly, 'assemble_program', observe('assemble', assembly.assemble_program)), \
     patch.object(assembly, 'verify_program', observe('Core', assembly.verify_program)), \
     patch.object(core, 'verify_program', observe('Core', core.verify_program)), \
     patch.object(core, 'execute_program', observe('VM', core.execute_program)):
    for name, module in (('signed', signed), ('scalar-casts', casts)):
        start = len(events)
        result = module.independent_reference()
        results[name] = result
        rows = events[start:]
        for row in rows: row['family'] = name
        summary[name] = {'result': identity(result),
            'counts': {scope: {kind: sum(r['scope']==scope and r['kind']==kind for r in rows)
                              for kind in ('assemble', 'Core', 'VM')}
                       for scope in ('fixture-construction', 'actual-public-witness')},
            'cases': len(result['cases']), 'traps': len(result['traps']),
            'refusals': len(result['refusals'])}
after = file_digests()
assert before == after
(out/'source-after.json').write_bytes(canonical(after))
with gzip.GzipFile(filename=str(out/'events.jsonl.gz'), mode='wb', mtime=0) as stream:
    for row in events: stream.write(canonical(row)+b'\n')
with gzip.GzipFile(filename=str(out/'reference.json.gz'), mode='wb', mtime=0) as stream:
    stream.write(canonical(results))
report = {'scope': 'DEVELOPMENT_INVOCATION_LEDGER_NOT_COLD_QUALIFICATION',
          'sources_preserved': True, 'reference': identity(results), 'families': summary}
(out/'summary.json').write_text(json.dumps(report, sort_keys=True, indent=2)+'\n')
print(json.dumps(report, sort_keys=True), flush=True)
