"""Verify a sealed v61 top-level raw package against immutable Git source bytes."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import json
import tarfile

CONTROL = Path('/dev/shm/hia-v61-qualification-control')
OUT = Path('/dev/shm/hia-v61-final-evidence')
ARCHIVE = OUT / 'raw-qualification.tar.xz'
MANIFEST = OUT / 'remote-manifest.json'
REMOTE_BASE = '/var/tmp/hia9acdfa-v61'
COMMIT = '647885c5c3ff067b6477011123335ad5a1aef78e'
TREE = '1c7679357590a9105c666dea95105780b64098fc'
JOB = '1a1c8d5cede-135c4-27a'
SOURCE_SHA = '6f8bd9f91bd6e10710f53cf4e66d362fec7e5009a62ba5b824f4eef2a04a5dfa'
ANOMALIES = ('errors', 'failures', 'skipped', 'expected_failures', 'unexpected_successes')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    expected = json.loads((CONTROL / 'expected-source.json').read_bytes())
    expected_source_raw = (CONTROL / 'independent-expected-source-state.json').read_bytes()
    assert sha(expected_source_raw) == SOURCE_SHA
    expected_source = json.loads(expected_source_raw)
    object_identity = json.loads((CONTROL / 'independent-git-blob-identity.json').read_bytes())
    assert object_identity['git_blob_count'] == 2587 and object_identity['tree'] == TREE
    assert object_identity['git_blob_sha1_all_checked'] is True
    assert object_identity['all_blob_sha256_recomputed'] is True
    manifest_raw = MANIFEST.read_bytes()
    manifest = json.loads(manifest_raw)
    pack = json.loads((OUT / 'remote-package-summary.json').read_bytes())
    assert sha(manifest_raw) == pack['manifest_sha256']
    assert len(manifest_raw) == pack['manifest_bytes']
    assert manifest['commit'] == COMMIT and manifest['source_tree'] == TREE
    assert manifest['original_qualification_job_id'] == JOB
    assert manifest['every_member_replayed_and_hashed'] is True
    assert manifest['every_original_identity_and_digest_rechecked_after_replay'] is True
    assert manifest['original_files_modified'] is False and manifest['qualification_reexecuted'] is False
    archive_raw = ARCHIVE.read_bytes()
    assert len(archive_raw) == manifest['archive']['bytes'] == pack['archive']['bytes']
    assert sha(archive_raw) == manifest['archive']['sha256'] == pack['archive']['sha256']
    inventory = {r['member']: r for r in manifest['members']}
    assert len(inventory) == manifest['member_count'] == pack['member_count']
    saved = {}
    with tarfile.open(ARCHIVE, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(inventory) and {m.name for m in members} == set(inventory)
        for member in members:
            p = PurePosixPath(member.name)
            assert not p.is_absolute() and all(part not in ('', '.', '..') for part in p.parts)
            rec = inventory[member.name]
            assert member.isreg() and member.size == rec['bytes'] and member.mode == rec['mode']
            with archive.extractfile(member) as f:
                raw = f.read()
            assert len(raw) == rec['bytes'] and sha(raw) == rec['sha256']
            saved[member.name] = raw
    assert sum(len(raw) for raw in saved.values()) == manifest['unpacked_bytes'] == pack['unpacked_bytes']
    report_raw = saved['qualification/QUALIFICATION.json']
    assert sha(report_raw) == manifest['qualification_report_sha256']
    assert len(report_raw) == manifest['qualification_report_bytes']
    report_metadata = json.loads((OUT / 'final-report-file-info.json').read_bytes())
    assert report_metadata['sha256'] == sha(report_raw) and report_metadata['size'] == len(report_raw)
    report = json.loads(report_raw)
    assert report['schema'] == 'hepta.hia.native-rewrite-qualification.v3'
    assert report['status'] == 'HOLD'
    assert report['source_identity']['head'] == COMMIT and report['source_identity']['tree'] == TREE
    assert report['source_identity']['raw_git_tree_blobs_and_modes_checked'] is True
    assert report['source_manifest'] == expected_source['files']
    assert len(report['source_manifest']) == 2587
    assert report['cold_source_manifest'] == expected['cold_closure']
    assert report['source_preserved'] is True and report['harness_preserved'] is True
    assert report['whole_native_delivery_qualified'] is False
    assert report['full_retained_regression_requested'] is True
    assert report['full_retained_regression_executed'] is True
    assert report['full_retained_regression_qualified'] is False

    def bound(record):
        path = record['path']
        assert path.startswith(REMOTE_BASE + '/')
        name = path[len(REMOTE_BASE) + 1:]
        assert name in saved, path
        raw = saved[name]
        assert sha(raw) == record['sha256'], path
        return raw

    before_raw = bound(report['source_identity']['before'])
    after_raw = bound(report['source_identity']['after'])
    assert before_raw == after_raw == expected_source_raw
    assert saved['source-fetch-identity.json'] == expected_source_raw
    assert json.loads(before_raw)['status'] == ''
    reproduction = json.loads(bound(report['source_reproduction']))
    assert reproduction['status'] == 'SOURCE_REPRODUCTION_PASS'
    assert reproduction['expected_snapshot_sha256'] == SOURCE_SHA
    assert reproduction['before'] == reproduction['after'] == expected_source
    assert reproduction['identical_to_tested_source'] is True
    assert reproduction['raw_git_tree_blobs_and_modes_checked'] is True
    assert len(reproduction['generators']) > 0
    harness = report['harness_identity_before']
    assert harness == report['harness_identity_after']
    assert harness == json.loads(saved['qualification/harness-before.json'])
    assert harness['runner']['sha256'] == expected['harness_sha256']['run_hia_qualification_v3.py']
    assert harness['workflow_process']['sha256'] == expected['harness_sha256']['workflow_process.py']
    cold = json.loads(bound(report['cold_report']))
    assert report['cold_qualified'] is True and report['cold_error'] is None
    assert cold['status'] == 'COLD_SELFHOST_REPLAY_PASS'
    assert len(cold['checks']) == 11 and all(value is True for value in cold['checks'].values())
    assert cold['source_manifest'] == expected['cold_closure']
    assert cold['process_owner']['qualification_seconds'] == 180
    assert cold['process_owner']['cleanup']['complete'] is True
    assert cold['process_owner']['cleanup']['observed_echild'] is True
    steps = report['steps']
    assert len(steps) == 22
    assert [s['name'] for s in steps] == [
        'source-reproduction', 'source-contract', 'source-scope', 'source-tests', 'cold',
        'language', 'native-applications', 'module-graph', 'workspace', 'capability',
        'workspace-facts', 'function-shape', 'program-shape', 'instruction-policy',
        'publication', 'core-admission', 'core-cli', 'patch', 'agent-candidate',
        'patch-result-cli', 'composite-types', 'full-retained-regression']
    assert steps == json.loads(saved['qualification/steps.json'])
    suite_rows = []
    for step in steps:
        assert step['timeout'] is False
        assert step['passed'] is (step['name'] != 'full-retained-regression')
        assert step['returncode'] == (1 if step['name'] == 'full-retained-regression' else 0)
        owner = step['owner']
        assert owner == json.loads(saved['qualification/' + step['name'] + '.owner.json'])
        assert owner['status'] == ('WORKFLOW_STEP_HOLD' if step['name'] == 'full-retained-regression' else 'WORKFLOW_STEP_COMPLETED')
        assert owner['timed_out'] is False and owner['returncode'] == step['returncode']
        assert owner['cleanup']['complete'] is True
        bound(step['stdout'])
        bound(step['stderr'])
        if 'suite_result' in step:
            outcome = step['suite_result']
            assert outcome['completed'] is step['passed'] and outcome['passed'] is step['passed']
            result = json.loads(bound(outcome['result']))
            assert type(result['tests_run']) is int and result['tests_run'] > 0
            assert result['tests_run'] == outcome['tests_run']
            counts = {name: len(result[name]) for name in ANOMALIES}
            if step['passed']:
                assert result['successful'] is True and not any(counts.values())
            else:
                assert result['successful'] is False and any(counts.values())
            suite_rows.append(dict(name=step['name'], tests_run=result['tests_run'], successful=result['successful'], anomaly_counts=counts))
    full = report['full_retained_regression']
    assert full == steps[-1]['suite_result'] and full['discovery'] is True
    assert full['tests_run'] >= 3931
    for key in ('state', 'exit_code', 'timed_out', 'cancelled', 'output_complete', 'output_durable'):
        assert key in json.loads((OUT / 'terminal-job-status.json').read_bytes())
    terminal = json.loads((OUT / 'terminal-job-status.json').read_bytes())
    assert terminal['job_id'] == JOB and terminal['state'] == 'failed'
    assert terminal['exit_code'] == 1 and terminal['timed_out'] is False and terminal['cancelled'] is False
    assert terminal['output_complete'] is True and terminal['output_durable'] is True
    assert terminal['terminal_publication_confirmed'] is True
    assert all(v is False for v in terminal['log_truncated'].values())
    assert all(v is True for v in terminal['log_synced'].values())
    assert all(v is None for v in terminal['log_errors'].values())
    process_logs = {}
    for stream in ('stdout', 'stderr'):
        raw = (CONTROL / ('full.' + stream + '.log')).read_bytes()
        assert len(raw) == terminal['log_bytes'][stream]['stored'] == terminal['log_bytes'][stream]['seen']
        process_logs[stream] = dict(bytes=len(raw), sha256=sha(raw))
    result = dict(
        schema='hepta.hia.v61-final-qualification-independent-verification.v1',
        created_utc=datetime.now(timezone.utc).isoformat(), host='rog', original_job_id=JOB,
        commit=COMMIT, tree=TREE, git_blob_count=2587,
        status='HOLD_VERIFIED_FAILURE', qualification_status='HOLD', qualification_pass=False, whole_native_delivery_qualified=False,
        archive=dict(bytes=len(archive_raw), sha256=sha(archive_raw)),
        remote_manifest=dict(bytes=len(manifest_raw), sha256=sha(manifest_raw)),
        final_report=dict(bytes=len(report_raw), sha256=sha(report_raw)),
        source_snapshot=dict(bytes=len(before_raw), sha256=sha(before_raw),
                             before_after_equal=True, matches_raw_git_blobs=True, clean=True),
        harness_preserved=True, cold_checks_passed=11, cold_checks_total=11,
        cold_source_members=564, cold_time_limit_seconds=180,
        cold_wall_elapsed_ns=cold['wall_elapsed_ns'], steps_passed=sum(s['passed'] for s in steps), steps_total=len(steps),
        suite_results=suite_rows, full_tests_run=full['tests_run'], total_suite_anomalies=sum(sum(s['anomaly_counts'].values()) for s in suite_rows),
        all_top_level_raw_logs_retained=True, original_files_modified=False,
        qualification_reexecuted=False, every_archive_member_replayed=True,
        member_count=len(saved), unpacked_bytes=sum(map(len, saved.values())),
        process_logs=process_logs,
        evidence_scope='All qualification top-level regular files, preparation metadata/launcher, and initial source identity. Nested cold/runtime/reproduction directories remain remote and are not included.',
        excluded_nonregular_top_entries=manifest['excluded_nonregular_top_entries'])
    for name in ('QUALIFICATION.json', 'full-retained-regression.json', 'source-before.json',
                 'source-after.json', 'harness-before.json', 'source-reproduction.json', 'cold.json',
                 'full-retained-regression.stdout.log', 'full-retained-regression.stderr.log'):
        path = OUT / 'readback' / name
        path.parent.mkdir(exist_ok=True)
        with path.open('xb') as f:
            f.write(saved['qualification/' + name])
    with (OUT / 'verification.json').open('x') as f:
        json.dump(result, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
