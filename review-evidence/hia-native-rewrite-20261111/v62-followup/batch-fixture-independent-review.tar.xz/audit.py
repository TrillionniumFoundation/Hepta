from pathlib import Path
import ast,gzip,hashlib,json,re,subprocess
ROOT=Path('/dev/shm/hia-batch-fixture-next'); EVIDENCE=Path('/dev/shm/hia-batch-fixture-audit'); OUT=Path('/dev/shm/hia-batch-independent-review'); BASE='d6847ac891e0dd07217d179891bb763162211de2'
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
paths=['tools/hia_selfhost_batch.py','tests/test_hia_reference_fixture_efficiency.py','tests/test_hia_selfhost_signed.py']
pins=[{'path':p,'bytes':len((ROOT/p).read_bytes()),'sha256':sha((ROOT/p).read_bytes())} for p in paths]
class NormalizeConstruction(ast.NodeTransformer):
 def visit_ImportFrom(self,node):
  if node.module=='hepta.hia_agent_assembly':return ast.Pass()
  return self.generic_visit(node)
 def visit_Assign(self,node):
  self.generic_visit(node)
  if len(node.targets)==1 and isinstance(node.targets[0],ast.Subscript) and isinstance(node.targets[0].value,ast.Name) and node.targets[0].value.id=='documents':
   node.value=ast.Name(id='PURE_FIXTURE_PARSE',ctx=ast.Load())
  return node
 def visit_Name(self,node):
  if node.id in ('render_assembly','_render_assembly_document'):node.id='PURE_FIXTURE_RENDER'
  return node
before=NormalizeConstruction().visit(ast.parse(git('show',BASE+':tools/hia_selfhost_batch.py')))
after=NormalizeConstruction().visit(ast.parse((ROOT/'tools/hia_selfhost_batch.py').read_bytes()))
assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)
protected=['hepta/hia_agent_assembly.py','hepta/hia_program.py','hepta/hia_program_runtime.py','tools/hia_selfhost_signed_cases.py','tools/hia_selfhost_scalar_casts.py','tools/hia_selfhost_loans.py','tools/qualify_hia_selfhost.py','tools/hia_selfhost_process_owner.py','tools/hia_evidence_archive.py']
assert all((ROOT/p).read_bytes()==git('show',BASE+':'+p) for p in protected)
test_preservation={}
for p in paths[1:]:
 def methods(raw):
  t=ast.parse(raw);return {(c.name,m.name):ast.dump(m,include_attributes=False) for c in t.body if isinstance(c,ast.ClassDef) for m in c.body if isinstance(m,ast.FunctionDef)}
 a=methods(git('show',BASE+':'+p));b=methods((ROOT/p).read_bytes());assert all(b.get(k)==v for k,v in a.items());test_preservation[p]={'all_existing_methods_ast_unchanged':True,'old_method_count':len(a),'new_method_count':len(b),'added_methods':['.'.join(k) for k in b.keys()-a.keys()]}
comparison_raw=(EVIDENCE/'comparison.json').read_bytes();comparison=json.loads(comparison_raw)
source_inventories={};reference={};events={};ledger_meta={}
for label in ('old','new'):
 p=EVIDENCE/label
 source_before=(p/'source-before.json').read_bytes();source_after=(p/'source-after.json').read_bytes();assert source_before==source_after;source_inventories[label]={'bytes':len(source_before),'sha256':sha(source_before),'before_after_equal':True}
 with gzip.open(p/'reference.json.gz','rb') as f:reference[label]=f.read()
 with gzip.open(p/'events.jsonl.gz','rb') as f:raw=f.read()
 events[label]=[json.loads(line) for line in raw.splitlines()]
 ledger_meta[label]={'event_records':len(events[label]),'event_raw_bytes':len(raw),'event_raw_sha256':sha(raw),'event_gzip_sha256':sha((p/'events.jsonl.gz').read_bytes()),'reference_bytes':len(reference[label]),'reference_sha256':sha(reference[label]),'reference_gzip_sha256':sha((p/'reference.json.gz').read_bytes())}
assert reference['old']==reference['new']
actual={label:[{k:v for k,v in row.items() if k!='sequence'} for row in rows if row['scope']=='actual-public-witness'] for label,rows in events.items()}
assert actual['old']==actual['new'] and len(actual['new'])==1420
old_construct=[row for row in events['old'] if row['scope']=='fixture-construction'];new_construct=[row for row in events['new'] if row['scope']=='fixture-construction'];assert not new_construct
removed_counts={kind:sum(row['kind']==kind for row in old_construct) for kind in ('Core','assemble','VM')};assert removed_counts=={'Core':506,'assemble':396,'VM':0}
value=json.loads(reference['new']);assert set(value)=={'signed','scalar-casts'}
fixed_hashes={'signed':'9173097ab604e5fb04fda2a14ea037d5d9e040aaa2b61b792c159a3bd2be3a74','scalar-casts':'46247c837dbf4925d0d0e5d3bda234079ee19766f82c1f5b25b4f8e7073d4a72'}
family_meta={};types={};volatile=[];host_paths=[]
def walk(v,path=()):
 types[type(v).__name__]=types.get(type(v).__name__,0)+1
 if isinstance(v,dict):
  for k,item in v.items():
   if re.fullmatch(r'(?:elapsed(?:_.*)?|wall(?:_.*)?|duration(?:_.*)?|timestamp|time_ns|seconds|pid|hostname|python_version|cwd|source_path|path)',k):volatile.append('.'.join((*path,k)))
   walk(item,(*path,k))
 elif isinstance(v,list):
  for item in v:walk(item,(*path,'[]'))
 elif isinstance(v,str) and v.startswith(('/workspace/','/dev/shm/','/tmp/','/var/tmp/')):host_paths.append(path)
walk(value)
assert not volatile and not host_paths and 'float' not in types
for family,result in value.items():
 raw=json.dumps(result,sort_keys=True,separators=(',',':')).encode();assert sha(raw)==fixed_hashes[family]
 family_meta[family]={'cases':len(result['cases']),'traps':len(result['traps']),'refusals':len(result['refusals']),'bytes':len(raw),'sha256':sha(raw)}
assert family_meta['signed']['cases']==52 and family_meta['signed']['traps']==100 and family_meta['signed']['refusals']==18
assert family_meta['scalar-casts']['cases']==58 and family_meta['scalar-casts']['traps']==136 and family_meta['scalar-casts']['refusals']==0
log=(EVIDENCE/'regression.log').read_bytes();assert b'Ran 14 tests in 29.760s' in log and log.rstrip().endswith(b'OK')
for pin in pins:assert sha((ROOT/pin['path']).read_bytes())==pin['sha256']
report={'schema':'hepta.hia.batch-fixture-independent-review.v1','scope':'STATIC_BOUNDARY_AND_EXISTING_RAW_LEDGER_REPLAY_NOT_COLD_QUALIFICATION','base_commit':BASE,'verdict':'NO_GATE_LOSS_FOUND_FOR_THE_DEFINED_QUALIFICATION_FIXTURES','source_pins':pins,'all_transformation_logic_ast_identical_after_only_parse_render_call_normalization':True,'public_admission_execution_and_gate_files_byte_unchanged':protected,'existing_test_methods_preserved':test_preservation,'only_runtime_consumers':['tools.hia_selfhost_signed_cases.cases','tools.hia_selfhost_scalar_casts.cases'],'final_witness_admission_vm_refusal_and_native_qualification_consumers_unchanged':True,'full_actual_public_invocation_count':1420,'actual_calls_same_order_input_kwargs_output_or_exception_identities':True,'full_reference_raw_bytes_equal':True,'family_results':family_meta,'removed_pure_construction_calls':removed_counts,'input_source_inventories_unchanged':source_inventories,'raw_ledger_replay':ledger_meta,'comparison_json_sha256':sha(comparison_raw),'deterministic_reference_value_types':types,'reference_contains_float_values':False,'reference_contains_volatile_runtime_keys_or_host_paths':False,'author_tests':{'tests':14,'wall_seconds':29.760,'status':'PASS','raw_bytes':len(log),'raw_sha256':sha(log),'independently_rerun':False},'boundary_qualification':['batch_cases is now syntax fixture construction; it no longer provides general Core admission for arbitrary caller-supplied unbatched source. Invalid-source constructor exception behavior is intentionally different.','The comparison covers every defined signed/scalar-cast witness and its public consumers, not equivalence for arbitrary malformed batch_cases inputs.','Public assemble/render, all actual Core/VM calls, all actual traps/refusals, and native phase boundaries remain unchanged.','Pinned full-reference hashes contain only deterministic project values; no cross-Python-minor run was performed in this independent review.'],'new_qualification_claimed':False,'production_files_modified_by_reviewer':False}
(OUT/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');(OUT/'candidate.diff').write_bytes(git('diff',BASE,'--',*paths));(OUT/'author-comparison.json').write_bytes(comparison_raw)
print(json.dumps({k:report[k] for k in ('verdict','full_actual_public_invocation_count','family_results','removed_pure_construction_calls','deterministic_reference_value_types')},sort_keys=True))
for name in ('review.json','audit.py','candidate.diff'):
 raw=(OUT/name).read_bytes();print(name,len(raw),sha(raw))
