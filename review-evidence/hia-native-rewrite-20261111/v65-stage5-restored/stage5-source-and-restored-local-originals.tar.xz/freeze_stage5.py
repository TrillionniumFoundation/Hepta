"""Freeze the complete tested stage5 source and its four-file candidate delta."""
from pathlib import Path
from hashlib import sha256,sha1
import io,json,os,stat,subprocess,tarfile
BASE=Path('/workspace/scratch/9acdfa9f5639');ROOT=BASE/'native-agent-state-integration';OUT=BASE/'hia-agent-state-integration-development';PUB=BASE/'hia-v65-stage5-publication';PUB.mkdir()
def sha(b):return sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
stage4=json.loads((OUT/'draft-stage4-source.json').read_bytes());tested=json.loads((OUT/'source-stage5-complete-attempt1/summary.json').read_bytes());assert tested['passed'] and tested['tests_run']==327 and tested['source_preserved']
expected=json.loads((OUT/'source-stage5-complete-attempt1/source-after.json').read_bytes());assert len(expected)==636
for p,h in expected.items():assert sha((ROOT/p).read_bytes())==h
paths=sorted(set(stage4['files'])|{'tools/qualify_hia_selfhost.py'});assert len(paths)==62
index=OUT/'stage5-inventory-temporary.index';assert not index.exists();env={**os.environ,'GIT_INDEX_FILE':str(index)}
try:
    subprocess.run(['git','read-tree','HEAD'],cwd=ROOT,env=env,check=True)
    subprocess.run(['git','add','--',*paths],cwd=ROOT,env=env,check=True)
    with (OUT/'stage5-static-inventory.stdout.log').open('x') as stdout,(OUT/'stage5-static-inventory.stderr.log').open('x') as stderr:
        subprocess.run(['python','-B','tools/audit_hia_native_rewrite.py','--output','docs/HIA_NATIVE_REWRITE_INVENTORY.json'],cwd=ROOT,env=env,stdout=stdout,stderr=stderr,check=True)
finally:
    if index.exists():index.unlink()
for p,h in expected.items():assert sha((ROOT/p).read_bytes())==h
files={p:{'bytes':(ROOT/p).stat().st_size,'sha256':sha((ROOT/p).read_bytes()),'mode':stat.S_IMODE((ROOT/p).stat().st_mode)} for p in paths}
frozen={'schema':'hepta.hia.state-integration-source.v1','stage':5,'base_commit':'eef68334b078eb9fcc414f441c35687e33585bba','base_tree':'dc088a3c1f551c353a1bc3a7df1034f92f79aaee','original_main_commit':'5831f52fada45e076f8f68f198a15c0585e6104f','local_git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':files,'files_scope':'All owned changed/new files since original main, including the four-file delta from candidate eef','source_closure':expected,'source_files':636,'source_gate':{'tests_run':327,'test_entries':77,'all_five_anomalies':0,'source_preserved':True,'report_sha256':sha((OUT/'source-stage5-complete-attempt1/summary.json').read_bytes())},'archive_scheduler_sha256':sha((ROOT/'tools/qualify_hia_selfhost.py').read_bytes()),'archive_independent_review_sha256':'f543b69e982e1404d34316bcf9cbc614d29f232f2bc0d2d1899fa8890baf317f','default_enabled':False,'whole_stack_closed':False}
raw=(json.dumps(frozen,indent=2,sort_keys=True)+'\n').encode();(OUT/'draft-stage5-source.json').write_bytes(raw)
archive=OUT/'draft-stage5-source.tar.xz'
with tarfile.open(archive,'x:xz',preset=1) as t:
    for name,e in files.items():
        b=(ROOT/name).read_bytes();assert sha(b)==e['sha256'];i=tarfile.TarInfo('source/'+name);i.size=len(b);i.mode=e['mode'];t.addfile(i,io.BytesIO(b))
    i=tarfile.TarInfo('FROZEN_SOURCE_MANIFEST.json');i.size=len(raw);i.mode=0o644;t.addfile(i,io.BytesIO(raw))
with tarfile.open(archive,'r:xz') as t:
    assert len(t.getmembers())==len(files)+1
    for m in t:
        b=t.extractfile(m).read()
        if m.name=='FROZEN_SOURCE_MANIFEST.json':assert b==raw
        else:
            e=files[m.name[len('source/'):]];assert len(b)==e['bytes'] and sha(b)==e['sha256'] and m.mode==e['mode']
dump(OUT/'draft-stage5-custody.json',{'schema':'hepta.hia.stage5-source-seal.v1','archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(files)+1,'raw_bytes':sum(e['bytes'] for e in files.values()),'source_manifest_sha256':sha(raw),'all_bytes_sha_mode_read_back':True})
previous=json.loads((BASE/'hia-v65-candidate-publication/full-source-snapshot.json').read_bytes());assert len(previous['files'])==2790
current={p:sha((ROOT/p).read_bytes()) for p in previous['files']};changed=[p for p in current if current[p]!=previous['files'][p]]
assert set(changed)=={'tools/qualify_hia_selfhost.py','docs/HIA_SELFHOST_CORE_SUPPORT.json','docs/HIA_NATIVE_REWRITE_STATUS_20261111.md','docs/HIA_NATIVE_REWRITE_INVENTORY.json'},changed
entries=[]
for name in sorted(changed):
    p=ROOT/name;b=p.read_bytes();entries.append({'path':name,'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_sha':sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100755' if stat.S_IMODE(p.stat().st_mode)&0o111 else '100644'})
plan={'schema':'hepta.hia.stage5-candidate-publication-plan.v1','repository':'TrillionniumFoundation/Hepta','branch':'codex/hia-native-v65-state-observer-20261111-9acdfa','parent':previous['head'],'base_tree':previous['tree'],'main_preserved':'5831f52fada45e076f8f68f198a15c0585e6104f','files':entries,'source_closure_files':636,'frozen_manifest_sha256':sha(raw),'source_gate_tests':327,'default_activation':False,'whole_stack_closed':False}
dump(PUB/'publication-plan.json',plan);dump(PUB/'all-current-file-hashes.json',current)
print(json.dumps({'manifest_sha256':sha(raw),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'source_files':636,'owned_files':62,'publication_files':len(entries),'publication_bytes':sum(e['bytes'] for e in entries),'tests_run':327,'whole_stack_closed':False}),flush=True)
