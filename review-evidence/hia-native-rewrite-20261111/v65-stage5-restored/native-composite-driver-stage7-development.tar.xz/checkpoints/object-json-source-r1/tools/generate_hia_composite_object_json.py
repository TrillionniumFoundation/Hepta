"""Author complete incremental ObjectToken JSON transport in HIA.

No nominal instruction or type decisions are made here. The source packet and
opaque registry are issued private leases; this module does not authenticate
arbitrary external registration. Dynamic continuation storage introduces no
new aggregate generated-Core, nesting or dictionary-key language quota.
"""
from __future__ import annotations

import ast
import copy
import importlib.util
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools.generate_hia_sha256 import INITIAL, ROUND
from tools.generate_hia_sha256_stream import source_program as sha_source

SOURCE_PATH = 'examples/hia_bootstrap/composite_object_json.hiaasm'
CONSTANTS = {
    'INIT_MAGIC': int.from_bytes(b'HIAOJI01', 'little'),
    'CONT_MAGIC': int.from_bytes(b'HIAOJC01', 'little'),
    'REGISTER_MAGIC': int.from_bytes(b'HIAOJG01', 'little'),
    'OPAQUE_MAGIC': int.from_bytes(b'HIAOJQ01', 'little'),
    'STATE_MAGIC': int.from_bytes(b'HIAOJS01', 'little'),
    'EVENT_MAGIC': int.from_bytes(b'HIAOJE01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1,
    'OBJECTS': 1 << 63, 'SOURCE_LIMIT': 64 << 20,
    'FBASE': 1024, 'PAYLOAD': 1152, 'OUTPUT_BYTES': 65408,
    'COMMAND_BASE': 73728, 'HASH_BASE': 81920, 'NUMBER_BASE': 86016,
    'POWERS_BASE': 86272, 'TOKEN_BASE': 131072, 'OPAQUE_BASE': 196608,
    'INDEX_BASE': 262144, 'MIN_WORK': 262272,
    'NULL_LITERAL': int.from_bytes(b'null', 'little'),
    'TRUE_LITERAL': int.from_bytes(b'true', 'little'),
    'FALSE_LITERAL': int.from_bytes(b'false', 'little'),
}

# Control offsets are deliberately named in the authoring source. The emitted
# HIA contains only ordinary checked loads, stores, calls and control flow.
FIELDS = (
    'W_MAGIC', 'STATUS', 'PHASE', 'LEASE', 'STREAM', 'PRODUCER_MAGIC',
    'PRODUCER_ACTION', 'REQUEST', 'SERIAL', 'SLOTS', 'PRODUCER_SEQ',
    'EVENT_SEQ', 'SOURCE_LEN', 'HEAP', 'HEAP_BASE', 'TOP', 'ROOT_HAVE',
    'ROOT_KIND', 'REGISTRY', 'REGISTRY_STOP', 'TOKEN_LEN', 'TOKEN_POS',
    'TOKEN_FINAL', 'TOKEN_ACTIVE', 'OUTPUT_LEN', 'TOTAL', 'TOKEN_COUNT',
    'SCALAR_MODE', 'SCALAR_AT', 'SCALAR_END', 'SCALAR_STAGE', 'ESCAPE_BITS',
    'ESCAPE_BYTES', 'PREFIX_BITS', 'PREFIX_BYTES', 'SOURCE_ACTIVE',
    'SOURCE_POS', 'SOURCE_STOP', 'SOURCE_TOP', 'SOURCE_MARK', 'OPAQUE_RECORD',
    'OPAQUE_QUERY', 'OPAQUE_SEQ', 'OPAQUE_SEEN', 'OPAQUE_LEN', 'OPAQUE_POS',
    'OPAQUE_FINAL', 'OPAQUE_STATE', 'NEEDED', 'GROW_KIND', 'T_KIND', 'T_VALUE',
    'T_NEXT', 'T_SEMANTIC', 'T_DATA_KIND', 'T_DATA_AT', 'T_DATA_LEN',
    'T_OPAQUE', 'T_KEY_BYTES', 'T_IS_KEY', 'T_HASH', 'T_PARENT',
)
CONSTANTS.update({name: 128 + i * 8 for i, name in enumerate(FIELDS)})

ENTRY = r'''
def object_json(c:readbuf, p:readbuf, w:mutbuf) -> u32:
    if length(w) < MIN_WORK:
        return BAD
    if get(w, W_MAGIC) == STATE_MAGIC and get(w, STATUS) != 0:
        return BAD
    if length(c) < 8:
        return refuse(w, 1, 0)
    tag = read(c, 0)
    if tag == INIT_MAGIC:
        return start(c, p, w)
    if get(w, W_MAGIC) != STATE_MAGIC or get(w, PHASE) == 0:
        return refuse(w, 2, 0)
    if length(p) != get(w, SOURCE_LEN):
        return refuse(w, 3, 0)
    put(w, OUTPUT_LEN, 0)
    if tag == CONT_MAGIC:
        if length(c) != 32 or correlation(c, w) == 0:
            return refuse(w, 4, 0)
        phase = get(w, PHASE)
        if phase != 3 and phase != 4:
            return refuse(w, 5, 0)
        if phase == 4:
            if length(w) < get(w, NEEDED):
                return refuse(w, 6, 0)
            if get(w, GROW_KIND) == 1:
                return register_saved(w)
        put(w, PHASE, 2)
        return pump(p, w)
    if tag == REGISTER_MAGIC:
        if length(c) != 96 or correlation(c, w) == 0:
            return refuse(w, 7, 0)
        if get(w, PHASE) != 1 or get(w, ROOT_HAVE) != 0 or get(w, PRODUCER_SEQ) != 0:
            return refuse(w, 8, 0)
        i = 0
        while i < 96:
            store(w, COMMAND_BASE + i, byte(c, i))
            i = i + 1
        return register_saved(w)
    if tag == OPAQUE_MAGIC:
        return opaque_reply(c, p, w)
    if tag != get(w, PRODUCER_MAGIC) or get(w, PHASE) != 1:
        return refuse(w, 9, 0)
    if length(c) < 64 or length(c) > 65536:
        return refuse(w, 10, 0)
    if read(c, 8) != get(w, PRODUCER_ACTION) or read(c, 16) != get(w, PRODUCER_SEQ):
        return refuse(w, 11, 0)
    if read(c, 24) > 1 or read(c, 32) != get(w, SERIAL) or read(c, 40) != get(w, SLOTS):
        return refuse(w, 12, 0)
    if read(c, 48) != get(w, REQUEST) or read(c, 56) != length(c) - 64:
        return refuse(w, 13, 0)
    if get(w, PRODUCER_SEQ) == MAX:
        return refuse(w, 14, 0)
    i = 64
    while i < length(c):
        store(w, TOKEN_BASE + i - 64, byte(c, i))
        i = i + 1
    put(w, TOKEN_LEN, length(c) - 64)
    put(w, TOKEN_POS, 0)
    put(w, TOKEN_FINAL, read(c, 24))
    put(w, TOKEN_ACTIVE, 1)
    put(w, PRODUCER_SEQ, get(w, PRODUCER_SEQ) + 1)
    put(w, PHASE, 2)
    return pump(p, w)

def correlation(c:readbuf, w:mutbuf) -> u64:
    if read(c, 8) != get(w, LEASE) or read(c, 16) != get(w, STREAM):
        return 0
    return choose(read(c, 24) == get(w, EVENT_SEQ), 1, 0)

def event(w:mutbuf, action:u64, a:u64, b:u64, d:u64, e:u64) -> u64:
    if get(w, EVENT_SEQ) == MAX:
        put(w, STATUS, BAD)
        return BAD
    put(w, EVENT_SEQ, get(w, EVENT_SEQ) + 1)
    put(w, FBASE, EVENT_MAGIC)
    put(w, FBASE + 8, action)
    put(w, FBASE + 16, get(w, STATUS))
    put(w, FBASE + 24, get(w, LEASE))
    put(w, FBASE + 32, get(w, STREAM))
    put(w, FBASE + 40, get(w, PRODUCER_SEQ))
    put(w, FBASE + 48, get(w, EVENT_SEQ))
    put(w, FBASE + 56, PAYLOAD)
    put(w, FBASE + 64, get(w, OUTPUT_LEN))
    put(w, FBASE + 72, get(w, TOTAL))
    put(w, FBASE + 80, a)
    put(w, FBASE + 88, b)
    put(w, FBASE + 96, d)
    put(w, FBASE + 104, e)
    put(w, FBASE + 112, 0)
    put(w, FBASE + 120, 0)
    return PAYLOAD + get(w, OUTPUT_LEN)

def refuse(w:mutbuf, reason:u64, at:u64) -> u64:
    put(w, W_MAGIC, STATE_MAGIC)
    put(w, STATUS, BAD)
    put(w, PHASE, 7)
    put(w, OUTPUT_LEN, 0)
    event(w, 6, reason, at, 0, 0)
    return BAD

def grow(w:mutbuf, required:u64, kind:u64) -> u64:
    put(w, NEEDED, required)
    put(w, GROW_KIND, kind)
    put(w, PHASE, 4)
    return event(w, 3, required, length(w), kind, 0)

def start(c:readbuf, p:readbuf, w:mutbuf) -> u64:
    if length(c) != 64:
        return refuse(w, 20, 0)
    previous_sequence = 0
    if get(w, W_MAGIC) != 0:
        if get(w, W_MAGIC) != STATE_MAGIC or get(w, PHASE) != 10:
            return refuse(w, 21, 0)
        if same_init(c, p, w) == 0:
            return refuse(w, 22, 0)
        previous_sequence = get(w, EVENT_SEQ)
    else:
        i = 128
        while i < 1024:
            if get(w, i) != 0:
                return refuse(w, 23, i)
            i = i + 8
    if read(c, 8) == 0 or read(c, 16) == 0 or read(c, 24) == 0:
        return refuse(w, 24, 0)
    if read(c, 24) == INIT_MAGIC or read(c, 24) == CONT_MAGIC or read(c, 24) == REGISTER_MAGIC or read(c, 24) == OPAQUE_MAGIC:
        return refuse(w, 25, 0)
    if length(p) < 16 or length(p) > SOURCE_LIMIT:
        return refuse(w, 26, 0)
    required = validation_capacity(length(p))
    if length(w) < required:
        control_init(c, p, w)
        put(w, EVENT_SEQ, previous_sequence)
        put(w, PHASE, 10)
        return event(w, 3, required, length(w), 10, 0)
    i = 0
    while i < 128:
        put(w, i, 0)
        i = i + 8
    if initialize(p, w) == 0:
        control_init(c, p, w)
        put(w, EVENT_SEQ, previous_sequence)
        return refuse(w, 27, 0)
    at = 0
    error = 0
    while (at < length(p) or get(w, 64) != 0) and error == 0:
        depth = get(w, 64)
        if depth != 0 and get(w, get(w, 56) + (depth - 1) * 32 + 8) == 0:
            frame = get(w, 56) + (depth - 1) * 32
            if at != get(w, frame):
                error = 28
            else:
                put(w, 64, depth - 1)
        else:
            following = validate_node(p, w, at)
            if following == MAX:
                error = 29
            else:
                at = following
    if error != 0 or get(w, 72) != 1 or at != length(p):
        control_init(c, p, w)
        put(w, EVENT_SEQ, previous_sequence)
        return refuse(w, choose(error == 0, 30, error), at)
    index = get(w, 48)
    size = get(w, 112)
    if INDEX_BASE > index:
        i = size
        while i != 0:
            i = i - 1
            store(w, INDEX_BASE + i, byte(w, index + i))
    else:
        i = 0
        while i < size:
            store(w, INDEX_BASE + i, byte(w, index + i))
            i = i + 1
    control_init(c, p, w)
    put(w, EVENT_SEQ, previous_sequence)
    put(w, PHASE, 1)
    return event(w, 1, 0, 0, 0, 0)

def same_init(c:readbuf, p:readbuf, w:mutbuf) -> u64:
    if length(p) != get(w, SOURCE_LEN):
        return 0
    if read(c, 8) != get(w, LEASE) or read(c, 16) != get(w, STREAM):
        return 0
    if read(c, 24) != get(w, PRODUCER_MAGIC) or read(c, 32) != get(w, PRODUCER_ACTION):
        return 0
    if read(c, 40) != get(w, REQUEST) or read(c, 48) != get(w, SERIAL) or read(c, 56) != get(w, SLOTS):
        return 0
    return 1

def validation_capacity(size:u64) -> u64:
    slots = 2
    while slots < (size >> 5) * 2:
        slots = slots * 2
    index_bytes = (size + 7) >> 3
    stack = (128 + slots * 16 + index_bytes + 7) & 18446744073709551608
    required = stack + (divide24(size) + 1) * 32
    fixed = ((INDEX_BASE + index_bytes + 7) & 18446744073709551608) + 128
    return choose(required > fixed, required, fixed)

def control_init(c:readbuf, p:readbuf, w:mutbuf) -> u64:
    i = 128
    while i < 1024:
        put(w, i, 0)
        i = i + 8
    put(w, W_MAGIC, STATE_MAGIC)
    put(w, LEASE, read(c, 8))
    put(w, STREAM, read(c, 16))
    put(w, PRODUCER_MAGIC, read(c, 24))
    put(w, PRODUCER_ACTION, read(c, 32))
    put(w, REQUEST, read(c, 40))
    put(w, SERIAL, read(c, 48))
    put(w, SLOTS, read(c, 56))
    put(w, SOURCE_LEN, length(p))
    base = (INDEX_BASE + ((length(p) + 7) >> 3) + 7) & 18446744073709551608
    put(w, HEAP, base)
    put(w, HEAP_BASE, base)
    put(w, REGISTRY_STOP, base)
    number_powers(w)
    return 0

def register_saved(w:mutbuf) -> u64:
    handle = get(w, COMMAND_BASE + 32)
    size = get(w, COMMAND_BASE + 40)
    if handle < OBJECTS or size < 2 or size > 2305843009213693951:
        return refuse(w, 40, 0)
    if get(w, COMMAND_BASE + 80) != 0 or get(w, COMMAND_BASE + 88) != 0:
        return refuse(w, 41, 0)
    if find_opaque(w, handle) != 0:
        return refuse(w, 42, 0)
    if get(w, STATUS) != 0:
        return BAD
    at = get(w, HEAP)
    if at > MAX - 64:
        return refuse(w, 43, 0)
    if length(w) < at + 64:
        return grow(w, at + 64, 1)
    put(w, at, get(w, REGISTRY))
    put(w, at + 8, handle)
    put(w, at + 16, size)
    i = 0
    while i < 32:
        store(w, at + 24 + i, byte(w, COMMAND_BASE + 48 + i))
        i = i + 1
    put(w, at + 56, 0)
    put(w, REGISTRY, at)
    put(w, HEAP, at + 64)
    put(w, REGISTRY_STOP, at + 64)
    put(w, PHASE, 1)
    return event(w, 1, handle, 0, 0, 0)

def find_opaque(w:mutbuf, handle:u64) -> u64:
    at = get(w, REGISTRY)
    bound = get(w, REGISTRY_STOP)
    while at != 0:
        if at < get(w, HEAP_BASE) or at > bound - 64:
            refuse(w, 44, at)
            return 0
        if get(w, at + 8) == handle:
            return at
        bound = at
        at = get(w, at)
    return 0
'''

PUMP = r'''
def pump(p:readbuf, w:mutbuf) -> u64:
    while get(w, OUTPUT_LEN) < OUTPUT_BYTES:
        if get(w, STATUS) != 0:
            return BAD
        if get(w, PREFIX_BYTES) != 0:
            emit(w, get(w, PREFIX_BITS))
            put(w, PREFIX_BITS, get(w, PREFIX_BITS) >> 8)
            put(w, PREFIX_BYTES, get(w, PREFIX_BYTES) - 1)
        elif get(w, SCALAR_MODE) != 0:
            scalar_step(p, w)
        elif get(w, SOURCE_ACTIVE) != 0:
            if source_step(p, w) == 0:
                return grow(w, get(w, NEEDED), 0)
        elif get(w, OPAQUE_STATE) != 0:
            if get(w, OPAQUE_STATE) == 1:
                put(w, PHASE, 5)
                return event(w, 4, get(w, get(w, OPAQUE_RECORD) + 8), get(w, OPAQUE_QUERY), get(w, OPAQUE_SEQ), 65536)
            if get(w, OPAQUE_POS) < get(w, OPAQUE_LEN):
                emit(w, byte(w, OPAQUE_BASE + get(w, OPAQUE_POS)))
                put(w, OPAQUE_POS, get(w, OPAQUE_POS) + 1)
            elif get(w, OPAQUE_FINAL) == 1:
                put(w, OPAQUE_STATE, 0)
            else:
                put(w, OPAQUE_STATE, 1)
        elif get(w, TOP) != 0 and get(w, get(w, TOP) + 16) == 0 and get(w, get(w, TOP) + 24) == 0:
            frame = get(w, TOP)
            prefix(w, choose(get(w, frame + 8) == 6, 125, 93))
            put(w, TOP, get(w, frame))
            put(w, HEAP, frame)
        elif get(w, TOKEN_ACTIVE) != 0:
            if get(w, TOKEN_POS) < get(w, TOKEN_LEN):
                if token_shape(p, w) == 0:
                    return BAD
                if accept_token(p, w) == 0:
                    if get(w, STATUS) != 0:
                        return BAD
                    return grow(w, get(w, NEEDED), 0)
            else:
                put(w, TOKEN_ACTIVE, 0)
                if get(w, TOKEN_FINAL) == 1:
                    if get(w, ROOT_HAVE) != 1 or get(w, TOP) != 0:
                        return refuse(w, 60, get(w, TOKEN_POS))
                    put(w, PHASE, 6)
                    return event(w, 5, get(w, ROOT_KIND), get(w, TOKEN_COUNT), 0, 0)
                put(w, PHASE, 1)
                return event(w, 1, 0, 0, 0, 0)
        else:
            return refuse(w, 61, 0)
    put(w, PHASE, 3)
    return event(w, 2, 0, 0, 0, 0)

def emit(w:mutbuf, value:u64) -> u64:
    if get(w, TOTAL) == MAX:
        return refuse(w, 62, 0)
    store(w, PAYLOAD + get(w, OUTPUT_LEN), value)
    put(w, OUTPUT_LEN, get(w, OUTPUT_LEN) + 1)
    put(w, TOTAL, get(w, TOTAL) + 1)
    return 0

def prefix(w:mutbuf, value:u64) -> u64:
    put(w, PREFIX_BITS, get(w, PREFIX_BITS) | ((value & 255) << (get(w, PREFIX_BYTES) * 8)))
    put(w, PREFIX_BYTES, get(w, PREFIX_BYTES) + 1)
    return 0

def token_shape(p:readbuf, w:mutbuf) -> u64:
    at = get(w, TOKEN_POS)
    size = get(w, TOKEN_LEN)
    if size - at < 16:
        refuse(w, 70, at)
        return 0
    kind = get(w, TOKEN_BASE + at)
    value = get(w, TOKEN_BASE + at + 8)
    put(w, T_KIND, kind)
    put(w, T_VALUE, value)
    put(w, T_NEXT, at + 16)
    put(w, T_DATA_KIND, 0)
    put(w, T_DATA_AT, 0)
    put(w, T_DATA_LEN, 0)
    put(w, T_OPAQUE, 0)
    if kind == 0:
        if value >= OBJECTS:
            record = find_opaque(w, value)
            if record == 0:
                refuse(w, 71, at)
                return 0
            put(w, T_OPAQUE, record)
            put(w, T_SEMANTIC, 6)
        else:
            if value >= length(p):
                refuse(w, 72, at)
                return 0
            if (byte(w, INDEX_BASE + (value >> 3)) & (1 << (value & 7))) == 0:
                refuse(w, 73, at)
                return 0
            put(w, T_SEMANTIC, read(p, value))
            if read(p, value) == 4:
                put(w, T_DATA_KIND, 1)
                put(w, T_DATA_AT, value + 16)
                put(w, T_DATA_LEN, read(p, value + 8))
    elif kind == 1:
        if value > size - at - 16:
            refuse(w, 74, at)
            return 0
        if utf8_mut(w, TOKEN_BASE + at + 16, value) == 0:
            refuse(w, 75, at)
            return 0
        put(w, T_NEXT, at + 16 + value)
        put(w, T_SEMANTIC, 4)
        put(w, T_DATA_KIND, 2)
        put(w, T_DATA_AT, TOKEN_BASE + at + 16)
        put(w, T_DATA_LEN, value)
    elif kind == 2:
        put(w, T_SEMANTIC, 2)
    elif kind == 3:
        if value > 1:
            refuse(w, 76, at)
            return 0
        put(w, T_SEMANTIC, 1)
    elif kind == 4:
        if value != 0:
            refuse(w, 77, at)
            return 0
        put(w, T_SEMANTIC, 0)
    elif kind == 5 or kind == 6:
        put(w, T_SEMANTIC, kind)
    else:
        refuse(w, 78, at)
        return 0
    return 1

def accept_token(p:readbuf, w:mutbuf) -> u64:
    frame = get(w, TOP)
    key_bytes = 0
    is_key = 0
    if frame == 0:
        if get(w, ROOT_HAVE) != 0:
            refuse(w, 80, get(w, TOKEN_POS))
            return 0
    else:
        if frame < get(w, REGISTRY_STOP) or frame > get(w, HEAP) - 64:
            refuse(w, 81, frame)
            return 0
        is_key = choose(get(w, frame + 8) == 6 and (get(w, frame + 16) & 1) == 0, 1, 0)
        if is_key != 0:
            if get(w, T_SEMANTIC) != 4:
                refuse(w, 82, get(w, TOKEN_POS))
                return 0
            if duplicate_key(p, w, get(w, frame + 32)) != 0:
                refuse(w, 83, get(w, TOKEN_POS))
                return 0
            if get(w, STATUS) != 0:
                return 0
            key_bytes = 40
            if get(w, T_DATA_KIND) == 2:
                key_bytes = 40 + ((get(w, T_DATA_LEN) + 7) & 18446744073709551608)
    extra = choose(get(w, T_KIND) == 5 or get(w, T_KIND) == 6, 64, 0)
    required = key_bytes + extra
    if get(w, HEAP) > MAX - required:
        refuse(w, 84, 0)
        return 0
    if length(w) < get(w, HEAP) + required:
        put(w, NEEDED, get(w, HEAP) + required)
        return 0
    if is_key != 0:
        save_key(p, w, frame, key_bytes)
    if frame == 0:
        put(w, ROOT_HAVE, 1)
        put(w, ROOT_KIND, get(w, T_SEMANTIC))
    else:
        native_prefix(w, frame)
    put(w, TOKEN_POS, get(w, T_NEXT))
    put(w, TOKEN_COUNT, get(w, TOKEN_COUNT) + 1)
    activate(w)
    return 1

def key_byte(p:readbuf, w:mutbuf, kind:u64, at:u64) -> u64:
    if kind == 1:
        return byte(p, at)
    return byte(w, at)

def duplicate_key(p:readbuf, w:mutbuf, previous:u64) -> u64:
    hash = 1469598103934665603
    i = 0
    while i < get(w, T_DATA_LEN):
        hash = (hash ^ key_byte(p, w, get(w, T_DATA_KIND), get(w, T_DATA_AT) + i)) * 1099511628211
        i = i + 1
    put(w, T_HASH, hash)
    bound = get(w, HEAP)
    while previous != 0:
        if previous < get(w, REGISTRY_STOP) or previous > bound - 40:
            refuse(w, 85, previous)
            return 0
        if get(w, previous + 8) == hash and get(w, previous + 32) == get(w, T_DATA_LEN):
            i = 0
            equal = 1
            while i < get(w, T_DATA_LEN) and equal != 0:
                if key_byte(p, w, get(w, previous + 16), get(w, previous + 24) + i) != key_byte(p, w, get(w, T_DATA_KIND), get(w, T_DATA_AT) + i):
                    equal = 0
                i = i + 1
            if equal != 0:
                return 1
        bound = previous
        previous = get(w, previous)
    return 0

def save_key(p:readbuf, w:mutbuf, frame:u64, size:u64) -> u64:
    at = get(w, HEAP)
    put(w, at, get(w, frame + 32))
    put(w, at + 8, get(w, T_HASH))
    put(w, at + 16, get(w, T_DATA_KIND))
    put(w, at + 24, get(w, T_DATA_AT))
    put(w, at + 32, get(w, T_DATA_LEN))
    if get(w, T_DATA_KIND) == 2:
        i = 0
        while i < get(w, T_DATA_LEN):
            store(w, at + 40 + i, byte(w, get(w, T_DATA_AT) + i))
            i = i + 1
        put(w, at + 24, at + 40)
    put(w, frame + 32, at)
    put(w, HEAP, at + size)
    return 0

def native_prefix(w:mutbuf, frame:u64) -> u64:
    remaining = get(w, frame + 16)
    if get(w, frame + 8) == 6 and (remaining & 1) == 1:
        prefix(w, 58)
    elif get(w, frame + 40) != 0:
        prefix(w, 44)
    put(w, frame + 40, 1)
    if remaining == 0:
        put(w, frame + 16, MAX)
        put(w, frame + 24, get(w, frame + 24) - 1)
    else:
        put(w, frame + 16, remaining - 1)
    return 0

def activate(w:mutbuf) -> u64:
    kind = get(w, T_KIND)
    value = get(w, T_VALUE)
    if kind == 0:
        if get(w, T_OPAQUE) != 0:
            put(w, OPAQUE_RECORD, get(w, T_OPAQUE))
            put(w, OPAQUE_QUERY, get(w, OPAQUE_QUERY) + 1)
            put(w, OPAQUE_SEQ, 0)
            put(w, OPAQUE_SEEN, 0)
            put(w, OPAQUE_STATE, 1)
            hash_init(w)
        else:
            put(w, SOURCE_ACTIVE, 1)
            put(w, SOURCE_POS, value)
            put(w, SOURCE_STOP, 0)
            put(w, SOURCE_TOP, 0)
            put(w, SOURCE_MARK, get(w, HEAP))
    elif kind == 1:
        scalar(w, 4, get(w, T_DATA_AT), value)
    elif kind == 2:
        number(w, value)
    elif kind == 3:
        scalar(w, 5, choose(value == 1, TRUE_LITERAL, FALSE_LITERAL), choose(value == 1, 4, 5))
    elif kind == 4:
        scalar(w, 5, NULL_LITERAL, 4)
    else:
        frame = get(w, HEAP)
        put(w, frame, get(w, TOP))
        put(w, frame + 8, kind)
        put(w, frame + 16, choose(kind == 6, value << 1, value))
        put(w, frame + 24, choose(kind == 6, value >> 63, 0))
        put(w, frame + 32, 0)
        put(w, frame + 40, 0)
        put(w, frame + 48, 0)
        put(w, frame + 56, 0)
        put(w, TOP, frame)
        put(w, HEAP, frame + 64)
        prefix(w, choose(kind == 6, 123, 91))
    return 0
'''

SERIALIZE = r'''
def scalar(w:mutbuf, mode:u64, at:u64, size:u64) -> u64:
    put(w, SCALAR_MODE, mode)
    put(w, SCALAR_AT, at)
    put(w, SCALAR_END, choose(mode == 5, size, at + size))
    put(w, SCALAR_STAGE, 0)
    put(w, ESCAPE_BITS, 0)
    put(w, ESCAPE_BYTES, 0)
    return 0

def scalar_step(p:readbuf, w:mutbuf) -> u64:
    mode = get(w, SCALAR_MODE)
    at = get(w, SCALAR_AT)
    if get(w, ESCAPE_BYTES) != 0:
        emit(w, get(w, ESCAPE_BITS))
        put(w, ESCAPE_BITS, get(w, ESCAPE_BITS) >> 8)
        put(w, ESCAPE_BYTES, get(w, ESCAPE_BYTES) - 1)
        return 0
    if mode == 5:
        if get(w, SCALAR_END) == 0:
            put(w, SCALAR_MODE, 0)
        else:
            emit(w, at)
            put(w, SCALAR_AT, at >> 8)
            put(w, SCALAR_END, get(w, SCALAR_END) - 1)
        return 0
    if mode == 3 or mode == 4:
        if get(w, SCALAR_STAGE) == 0:
            emit(w, 34)
            put(w, SCALAR_STAGE, 1)
            return 0
        if at == get(w, SCALAR_END):
            emit(w, 34)
            put(w, SCALAR_MODE, 0)
            return 0
        value = key_byte(p, w, choose(mode == 3, 1, 2), at)
        put(w, SCALAR_AT, at + 1)
        if value < 32 or value == 34 or value == 92:
            escape(w, value)
        else:
            emit(w, value)
        return 0
    if at == get(w, SCALAR_END):
        put(w, SCALAR_MODE, 0)
    else:
        emit(w, key_byte(p, w, choose(mode == 1, 1, 2), at))
        put(w, SCALAR_AT, at + 1)
    return 0

def escape(w:mutbuf, value:u64) -> u64:
    short = 0
    if value == 8:
        short = 98
    elif value == 9:
        short = 116
    elif value == 10:
        short = 110
    elif value == 12:
        short = 102
    elif value == 13:
        short = 114
    elif value == 34 or value == 92:
        short = value
    if short != 0:
        put(w, ESCAPE_BITS, 92 | (short << 8))
        put(w, ESCAPE_BYTES, 2)
    else:
        put(w, ESCAPE_BITS, 808482140 | (hex_digit(value >> 4) << 32) | (hex_digit(value & 15) << 40))
        put(w, ESCAPE_BYTES, 6)
    return 0

def number(w:mutbuf, value:u64) -> u64:
    i = 0
    count = 0
    while i < 20:
        power = get(w, POWERS_BASE + i * 8)
        digit = 0
        while value >= power:
            value = value - power
            digit = digit + 1
        if digit != 0 or count != 0 or i == 19:
            store(w, NUMBER_BASE + count, 48 + digit)
            count = count + 1
        i = i + 1
    scalar(w, 2, NUMBER_BASE, count)
    return 0

def source_step(p:readbuf, w:mutbuf) -> u64:
    at = get(w, SOURCE_POS)
    frame = get(w, SOURCE_TOP)
    if get(w, SOURCE_STOP) == 0:
        put(w, SOURCE_STOP, at + 16 + read(p, at + 8))
    if frame != 0 and get(w, frame + 8) == 0:
        if at != get(w, frame + 32):
            refuse(w, 100, at)
            return 1
        prefix(w, choose(get(w, frame + 16) == 6, 125, 93))
        put(w, SOURCE_TOP, get(w, frame))
        put(w, HEAP, frame)
        return 1
    if frame == 0 and at == get(w, SOURCE_STOP):
        put(w, SOURCE_ACTIVE, 0)
        put(w, HEAP, get(w, SOURCE_MARK))
        return 1
    kind = read(p, at)
    size = read(p, at + 8)
    if kind == 5 or kind == 6:
        if get(w, HEAP) > MAX - 48:
            refuse(w, 101, 0)
            return 1
        if length(w) < get(w, HEAP) + 48:
            put(w, NEEDED, get(w, HEAP) + 48)
            return 0
    if frame != 0:
        remaining = get(w, frame + 8)
        if get(w, frame + 16) == 6 and (remaining & 1) == 1:
            prefix(w, 58)
        elif get(w, frame + 24) != 0:
            prefix(w, 44)
        put(w, frame + 24, 1)
        put(w, frame + 8, remaining - 1)
    if kind == 5 or kind == 6:
        fresh = get(w, HEAP)
        put(w, fresh, frame)
        put(w, fresh + 8, read(p, at + 16) * choose(kind == 6, 2, 1))
        put(w, fresh + 16, kind)
        put(w, fresh + 24, 0)
        put(w, fresh + 32, at + 16 + size)
        put(w, fresh + 40, at)
        put(w, SOURCE_TOP, fresh)
        put(w, HEAP, fresh + 48)
        put(w, SOURCE_POS, at + 24)
        prefix(w, choose(kind == 6, 123, 91))
    else:
        put(w, SOURCE_POS, at + 16 + size)
        if kind == 0:
            scalar(w, 5, NULL_LITERAL, 4)
        elif kind == 1:
            scalar(w, 5, choose(byte(p, at + 16) == 1, TRUE_LITERAL, FALSE_LITERAL), choose(byte(p, at + 16) == 1, 4, 5))
        elif kind == 4:
            scalar(w, 3, at + 16, size)
        else:
            scalar(w, 1, at + 16, size)
    return 1
'''

OPAQUE = r'''
def opaque_reply(c:readbuf, p:readbuf, w:mutbuf) -> u64:
    if length(c) < 64 or length(c) > 65600 or correlation(c, w) == 0:
        return refuse(w, 120, 0)
    if get(w, PHASE) != 5 or get(w, OPAQUE_STATE) != 1:
        return refuse(w, 121, 0)
    record = get(w, OPAQUE_RECORD)
    if read(c, 32) != get(w, record + 8) or read(c, 40) != get(w, OPAQUE_QUERY):
        return refuse(w, 122, 0)
    if read(c, 48) != get(w, OPAQUE_SEQ) or read(c, 56) > 1:
        return refuse(w, 123, 0)
    count = length(c) - 64
    if count > get(w, record + 16) - get(w, OPAQUE_SEEN):
        return refuse(w, 124, 0)
    if read(c, 56) == 1 and get(w, OPAQUE_SEEN) + count != get(w, record + 16):
        return refuse(w, 125, 0)
    i = 0
    while i < count:
        store(w, OPAQUE_BASE + i, byte(c, 64 + i))
        i = i + 1
    hash_update(w, OPAQUE_BASE, count)
    if read(c, 56) == 1 and hash_finish(w, record) == 0:
        return refuse(w, 126, 0)
    if get(w, OPAQUE_SEQ) == MAX:
        return refuse(w, 127, 0)
    put(w, OPAQUE_SEEN, get(w, OPAQUE_SEEN) + count)
    put(w, OPAQUE_SEQ, get(w, OPAQUE_SEQ) + 1)
    put(w, OPAQUE_LEN, count)
    put(w, OPAQUE_POS, 0)
    put(w, OPAQUE_FINAL, read(c, 56))
    put(w, OPAQUE_STATE, 2)
    put(w, PHASE, 2)
    return pump(p, w)

def hash_update(w:mutbuf, at:u64, count:u64) -> u64:
    used = get(w, HASH_BASE + 1096)
    i = 0
    while i < count:
        store(w, HASH_BASE + 1112 + used, byte(w, at + i))
        used = used + 1
        if used == 64:
            hash_compress(w)
            used = 0
        i = i + 1
    put(w, HASH_BASE + 1088, get(w, HASH_BASE + 1088) + count)
    put(w, HASH_BASE + 1096, used)
    return 0

def hash_finish(w:mutbuf, record:u64) -> u64:
    used = get(w, HASH_BASE + 1096)
    store(w, HASH_BASE + 1112 + used, 128)
    used = used + 1
    while used != 56:
        if used == 64:
            hash_compress(w)
            used = 0
        else:
            store(w, HASH_BASE + 1112 + used, 0)
            used = used + 1
    bits = get(w, HASH_BASE + 1088) << 3
    i = 0
    while i < 8:
        store(w, HASH_BASE + 1168 + i, (bits >> ((7 - i) * 8)) & 255)
        i = i + 1
    hash_compress(w)
    i = 0
    while i < 8:
        value = get(w, HASH_BASE + 1024 + i * 8)
        j = 0
        while j < 4:
            if byte(w, record + 24 + i * 4 + j) != ((value >> ((3 - j) * 8)) & 255):
                return 0
            j = j + 1
        i = i + 1
    return 1
'''


def source_program():
    spec = importlib.util.spec_from_file_location(
        '_object_json_packet_validator', Path(__file__).with_name('generate_hia_composite_packet_json.py'))
    packet = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(packet)
    keep = {'read', 'get', 'put', 'widen', 'initialize', 'validate_node',
            'node_width', 'integer_width', 'divide24', 'string_width',
            'utf8', 'same_key', 'unique_key', 'hex_digit'}
    validation = [node for node in ast.parse(packet.source_program()).body if node.name in keep]
    utf8_mut = copy.deepcopy(next(node for node in validation if node.name == 'utf8'))
    utf8_mut.name = 'utf8_mut'
    utf8_mut.args.args[0].annotation.id = 'mutbuf'

    class HashOffset(ast.NodeTransformer):
        def visit_Call(self, node):
            node = self.generic_visit(node)
            if isinstance(node.func, ast.Name):
                if node.func.id in ('compress', 'rotate'):
                    node.func.id = 'hash_' + node.func.id
                elif node.func.id in ('get', 'put', 'byte', 'store') and node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == 'w':
                    node.args[1] = ast.BinOp(ast.Name('HASH_BASE', ast.Load()), ast.Add(), node.args[1])
            return node
    sha_nodes = []
    for node in ast.parse(sha_source()).body:
        if node.name in ('compress', 'rotate'):
            node = HashOffset().visit(node)
            node.name = 'hash_' + node.name
            sha_nodes.append(node)
    initial = 'def hash_init(w:mutbuf) -> u64:\n'
    for i, value in enumerate(ROUND):
        initial += f'    put(w, HASH_BASE + {i * 8}, {value})\n'
    for i, value in enumerate(INITIAL):
        initial += f'    put(w, HASH_BASE + {1024 + i * 8}, {value})\n'
    initial += '    put(w, HASH_BASE + 1088, 0)\n    put(w, HASH_BASE + 1096, 0)\n    return 0\n'
    powers = 'def number_powers(w:mutbuf) -> u64:\n'
    for i in range(20):
        powers += f'    put(w, POWERS_BASE + {i * 8}, {10 ** (19 - i)})\n'
    powers += '    return 0\n'
    tree = ast.parse(ENTRY + PUMP + SERIALIZE + OPAQUE + initial + powers)
    tree.body.extend(validation + [utf8_mut] + sha_nodes)

    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node) if node.id in CONSTANTS else node
    tree = ast.fix_missing_locations(Expand().visit(tree))
    return ast.unparse(tree) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    if len({node.name for node in nodes}) != len(nodes):
        raise ValueError('duplicate ObjectToken consumer symbol')
    names = {node.name: 'f' + str(i + 1) for i, node in enumerate(nodes)}
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id) for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'}, {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'],
                  'entry': 'b0', 'blocks': [{'id': 'b0', 'params': params, 'ops': [
                      {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
                      {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}], 'attrs': {'function': names['object_json']}},
                      {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}],
                      'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'composite_object_json', 'functions': functions})


def main():
    target = Path(__file__).resolve().parents[1] / SOURCE_PATH
    target.write_text(render_assembly(document()))
    print(target.name, target.stat().st_size)


if __name__ == '__main__':
    main()
