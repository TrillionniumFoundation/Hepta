# Native ObjectToken JSON continuation

This development component consumes the complete generic ObjectToken grammar
used by the constructor, function and outer HIA owners. It spells ordered,
compact integer JSON incrementally. It does not interpret nominal types,
instructions, function order, helper plans or final Core admission.

The generated HIA entry has the compiler's existing readbuf/mutbuf/mutbuf ABI.
It borrows its second argument read-only: command bytes, the immutable issued
typed source packet, and a mutable offset-based continuation workspace. The
source packet has the existing 64 MiB service-packet ceiling. The generated
Core stream has no such ceiling and never passes through the service codec.

## Byte protocol

All words below are little-endian uint64. A producer frame is the original
64-byte native header followed by at most 65,472 token bytes; a token header
and its inline string stay within that frame, as required by the existing
native renderer. The consumer does not reinterpret the same bytes as a typed
packet. The retained producers start their sequence at zero.

| Command | Words, in order |
| --- | --- |
| INIT, 64 bytes | `HIAOJI01`, lease, stream, producer magic, producer action, request, serial, slots |
| CONTINUE, 32 bytes | `HIAOJC01`, lease, stream, last event sequence |
| REGISTER, 96 bytes | `HIAOJG01`, lease, stream, last event sequence, handle, byte count, four digest words, zero, zero |
| Opaque reply, 64-byte header | `HIAOJQ01`, lease, stream, last event sequence, handle, query, chunk sequence, final bit; then at most 65,536 bytes |
| Producer, unchanged | producer magic, action, sequence, final bit, serial, slots, request, payload bytes; then tokens |

The workspace must initially contain zero control words at offsets 128–1023
and provide at least 262,272 bytes. Its event begins at offset 1024 and contains
16 words: `HIAOJE01`, action, status, lease, stream, next producer sequence,
event sequence, payload offset, payload bytes, total JSON bytes, four action
arguments and two reserved zeros. JSON payload starts at offset 1152 and has
65,408 bytes of capacity. The returned extent includes that offset and payload.
A refusal returns `0xfffffffd` and leaves a refusal event with zero payload.

| Event action | Meaning and continuation |
| --- | --- |
| 1 | Request the next original producer frame; before sequence zero, REGISTER is also allowed |
| 2 | Drain this JSON chunk; resume with the exact last event sequence |
| 3 | Preserve and enlarge workspace to argument 0; argument 2 equal to 10 requires the same INIT, otherwise CONTINUE |
| 4 | Read registered object: arguments are handle, query, next chunk sequence, maximum reply payload |
| 5 | Complete stream; arguments 0 and 1 give the generic JSON root kind and accepted token count |
| 6 | Permanent refusal; arguments 0 and 1 are protocol reason and relevant offset |

All event payloads, including a prefix attached to GROW or an opaque request,
are consumed exactly once. Event sequences remain monotone across initial
validation growth. Source/stream IDs must be nonzero; they are caller-issued
lease identities, not cryptographic proof of external provenance.

## Ownership and continuation

The caller owns one private immutable source lease. INIT validates the entire
packet and builds the exact node-offset bitmap using the complete stage5 HIA
validator. That bitmap does not authenticate an independently replaced source
packet. The public native driver must pass the same privately issued packet
through every call and protect it against mutation.

The native producer's original 64-byte frame is forwarded without converting
tokens to Python values. The consumer checks its producer magic, action,
sequence, final bit, serial, slots, request and actual extent. A copied chunk
remains private in the continuation workspace while output drains or another
native service runs. A new producer chunk cannot overwrite an unfinished one.

Events distinguish producer input, output drain, workspace growth, an opaque
object read, completion and permanent refusal. Every continuation is bound to
the source lease, stream and last issued event sequence. GROW asks the caller
to preserve existing workspace bytes and enlarge the buffer; it is not a
language quota or a semantic rejection. All persistent pointers are offsets.
Native container state scales with active nesting and live dictionary keys,
not with total list length or total JSON output.

All token kinds are supported: immutable source reference, UTF-8 string,
unsigned integer, boolean, null, list and map. Map arity uses a 65-bit counter
so that doubling a valid uint64 pair count cannot wrap. Native dictionary keys
are compared by full UTF-8 content, including equality between a source string
and a newly emitted string. No new fixed nesting or dictionary-key limit is
introduced. Packet source references expand incrementally as one atomic token.

## Opaque issued Core objects

Outer normalization also refers to previously completed function and helper
objects. These handles occupy the high half of uint64 space, disjoint from
source packet offsets. Before its first producer chunk, the trusted native
coordinator registers an issued handle, exact JSON byte count and SHA-256 of
the previously completed dictionary stream. Registration is an internal
issuance interface, not proof that arbitrary external bytes are a Core object.
The final raw-JSON application must not expose registration to its input.

An opaque read carries handle, query and chunk sequence. The consumer hashes
the actual chunks in HIA and checks exact extent and digest before accepting
the final chunk. The original token chunk stays intact throughout the read.
Opaque references cannot become dictionary keys. A caller must keep all emitted
bytes private until DONE; an eventual protocol or hash refusal invalidates the
whole stream, including previously emitted prefixes. Registration and the
opaque reader impose no 64 MiB limit on a complete Core object.

## Scope

This is a generic transport component. It does not replace the eleven complete
native semantic owners, the original late function/block inventory gates,
canonical final Core admission, or legacy/profile selection. Python remains
development-time authoring and test custody until the native driver wires this
continuation protocol to all owners. Compilation uses the retained exact f50
B3 development compiler with its unchanged CPU, wall, stack and memory limits;
that is not current-source cold qualification or whole-stack self-hosting.
