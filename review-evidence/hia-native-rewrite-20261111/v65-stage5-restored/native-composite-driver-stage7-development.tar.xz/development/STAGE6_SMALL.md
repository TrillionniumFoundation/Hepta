# Stage 6 small protocol checkpoint

The complete generic ObjectToken consumer is a new HIA component. Its first
frozen production candidate is `checkpoints/object-json-source-r1/source.json`:
three files, 49 functions, 688 blocks, 3,647 operations, maximum 74 blocks per
function and 10 block parameters. Actual retained f50 B3 compilation passed
with the original 10 CPU seconds, 20 wall seconds, 256 MiB address space,
8 MiB stack and 1 MiB output/workspace limits. The image is 274,602 bytes,
SHA-256 `85770d5e439b205b4e2cfc2d19a4d90a964290bae42489cc0609ec8621d0cdc2`.

The current selected small panel passed 8 tests in 3.071926651 seconds, with
2,347 actual consumer entries in 239 streams and maximum RSS 44,984 KiB.
It covers all token kinds and unsigned integer edges, strict UTF-8 and escaping,
ordered objects, exact source-node bitmap references, source/native duplicate
key equality, dynamic 4,096-level nesting and 1,024-key maps, 65-bit map arity,
empty chunks, malformed source/token/continuation fields, permanent poison,
opaque SHA padding, handle/query/sequence/final/extent binding, and restoration
of the original token chunk after a full 65,536-byte opaque callback. Every
entry checked source/command bytes and buffer canaries; source/image pins were
unchanged before and after the panel. This is selected coverage, not all tests.

The first 2-test smoke passed. The first selected 7-test panel had one real
test assertion failure: the expected count of buffer enlargements was too
strict, because the initial doubling already accommodated the entire 4,096-
level case. Its complete JSON had already matched. The original test bytes,
failure log and native ledger remain in `object-json-small-r1`. The next test
revision starts those growth controls at an exact small valid capacity and
checks an actual post-initialization GROW. The 7-test rerun and current 8-test
panel passed without any production source or image change.

Three initial hosted-authoring failures are preserved with their exact source:
an implicit bool-to-u64 cast, an expression crossing the builder's SSA block
boundary, and a non-bool branch condition. The fourth generation passed; the
fifth generation additionally preserved monotone event numbering across INIT
growth before the first native compile. No compiler limit or retained compiler
source was changed.

The existing development HIA stream fixture and unchanged production renderer
have also been generated, source-bound and actually compiled under the original
limits. Their source, images, receipts and dependency copies are included.
The tests that run that 192 MiB producer and verify a complete stream exceeding
64 MiB, and the 12 MiB / 9 MiB generated-stream controls, are **prepared but not
yet executed** in this checkpoint. They are deliberately separate from the
selected small panel while the parent runs qualification and installed gates.

The component consumes privately issued immutable packets and producer frames.
REGISTER is a trusted internal coordinator interface, not external provenance
authentication. Opaque storage bytes are checked against the registered digest;
all output stays private until complete success. Python still provides test
byte forwarding and development authoring. The eleven semantic owners have
not yet been wired into a complete native normalization application. This
checkpoint does not grant current-source cold qualification, whole-language
self-hosting, deletion authority for the retained host, or final Core admission.
