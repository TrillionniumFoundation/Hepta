"""Freeze new stage6 source and exact small raw evidence, preserving failures."""
from pathlib import Path
import hashlib,json,stat,tarfile

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
DEST=ROOT.parent/'native-composite-driver-stage6-small-development.tar.xz'
BASE=ROOT/'checkpoints/stage6-small'
BASE.mkdir(exist_ok=False)
paths={ROOT/name for name in ('docs/HIA_COMPOSITE_OBJECT_TOKEN_JSON.md',
       'tools/generate_hia_composite_object_json.py','examples/hia_bootstrap/composite_object_json.hiaasm',
       'tests/test_hia_composite_object_json.py','development/STAGE6_SMALL.md',
       'development/package_stage6_small.py')}
for pattern in ('development/object-json-*','development/compile-object-json-*',
                'development/compile-object-producer-*','development/compile_object_json_*.py',
                'development/run_object_json_*.py','checkpoints/object-json-*'):
    for path in ROOT.glob(pattern):
        if path.is_file():paths.add(path)
        elif path.is_dir():paths.update(p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
rows=[]
for path in sorted(paths):
    raw=path.read_bytes()
    rows.append({'path':str(path.relative_to(ROOT)),'bytes':len(raw),
                 'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode)})
report={'scope':'STAGE6_SMALL_PROTOCOL_DEVELOPMENT_LARGE_TESTS_PREPARED_NOT_EXECUTED',
        'members':rows,'member_count':len(rows),'raw_bytes':sum(row['bytes'] for row in rows)}
manifest=BASE/'source.json';manifest.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
with tarfile.open(DEST,'w:xz',preset=6) as tar:
    for row in rows:tar.add(ROOT/row['path'],arcname=row['path'],recursive=False)
checks=[]
with tarfile.open(DEST,'r:xz') as tar:
    assert [member.name for member in tar.getmembers()]==[row['path'] for row in rows]
    for row in rows:
        member=tar.getmember(row['path']);raw=tar.extractfile(member).read()
        assert raw==(ROOT/row['path']).read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        assert stat.S_IMODE(member.mode)==row['mode']
        checks.append({'path':row['path'],'bytes_equal':True,'sha256_equal':True,'mode_equal':True})
raw=DEST.read_bytes()
custody={'archive':DEST.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
         'member_count':len(rows),'raw_bytes':report['raw_bytes'],
         'source_manifest':str(manifest),'source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
         'all_original_bytes_sha_and_modes_equal':True,'checks':checks}
output=DEST.with_suffix('').with_suffix('.custody.json')
output.write_text(json.dumps(custody,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in custody.items() if k!='checks'}),flush=True)
print('custody',len(output.read_bytes()),hashlib.sha256(output.read_bytes()).hexdigest(),flush=True)
