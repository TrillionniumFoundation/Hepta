# Stage 7: complete generic streaming development evidence

This archive preserves the exact files found after the shared environment recovered. It does not reconstruct vanished RAM outputs. All archived members are read back against the original bytes, SHA-256, and mode.

## Frozen implementation and actual execution

The production stream consumer is r2: source SHA-256 3a184f6cf17a3c62fe67c83074f3455f64fb7112f628dc4514cdd98f6e87953c; image SHA-256 b6bb38c19ebf67ae01757fb37459bd18a7dcdf01b43dc86dfcbdb77e9b19ea70. It uses existing HIA range-copy operations for admitted spans. The original scalar routine remains as the overflow-boundary fallback. Compiler limits, protocol fields, original entry boundaries and accepted language are unchanged.

The current small suite passed all 9 tests in 6.592010004998883 seconds, with no failures, errors, skips, expected failures or unexpected successes. The actual historical r1 image and r2 image ran 2421 paired entries, 4842 entries in total. Each pair compared the full workspace, canaries and return value, including refusal state and continuation cursors.

The large suite passed both tests in 74.71619795299921 seconds. Its independent wait4 supervisor observed exit 0, 72.550722 user CPU seconds, 2.056064 system CPU seconds and 499488 KiB maximum RSS. Its original limits remained 90 CPU seconds and 1073741824 address-space bytes. The test includes a 12 MiB source expansion, a 9 MiB opaque JSON value, and actual HIA compressed-IR fixture and production renderer entries producing 71303259 JSON bytes. The complete large output matched the independent expected bytes, SHA-256 f140877751228985814828c94923e1b209924243c53682f1c57cc303618f05db.

The large-output test forwarded 1926 original production-renderer frames for the large fixture, without Python token/value interpretation inside that forwarding loop. The test fixture is not a full composite program. Python still owns this development test harness and its independent oracle; there is not yet a complete native coordinator.

## Failure history remains separate

The r1 large run exited 137 before completing its second test. Its first test was reported successful, but the greater-than-64-MiB case was incomplete. There is no successful teardown custody or final test report for that run. The saved prefix contains 1296 returned entries and stops at 29620775 output bytes. The exact cause of exit 137 was not established; this archive does not rename it as an out-of-memory or semantic failure.

Every one of those 1296 returned entries matches the corresponding r2 prefix across all retained fields: full event, return, source and command bytes/hashes, payload bytes/hash, workspace extent and input/canary observations. This comparison does not imply r1 completed. The full-workspace comparison is from the small paired suite.

Earlier authoring errors and the first small-suite test assertion failure are preserved. That small failure was an overly strict growth-count assertion after correct bytes had already been produced; the test revision forced an actual later growth boundary and retained the original record.

The first persistent r2 supervisor attempt failed with ENOSPC before any native execution. Its scripts and log are retained. The subsequent run changed only evidence paths to RAM. All 12 resulting files, 1717668 bytes, were then copied into the persistent workspace and checked byte-for-byte, SHA-for-SHA and mode-for-mode. They survived environment restart and were checked again before packaging.

## Evidence scope

The raw small differential ledger, raw large ledger, source-before/source-after records, actual compiler requests/receipts/images, test sources and runner sources are included. Large deterministic JSON/token payloads were compared completely in memory; only the resulting hashes, lengths and deterministic fixture/oracle constructors were saved. This package does not claim those whole payloads are present as files.

Both independent static reviews are preserved under independent/. Their zero-native scope remains unchanged. The source-bound r2 native results are separate records.

The new object-token IR authoring files are deliberately outside this freeze. They were authored after the interruption and have only been parsed, not generated or compiled.

This is generic stream development evidence. It is not a current-source cold qualification, a whole-language native compiler qualification, an installed complete driver, or authorization to remove retained Python owners. Earlier decoder/codec components retain their own frozen development identities.
