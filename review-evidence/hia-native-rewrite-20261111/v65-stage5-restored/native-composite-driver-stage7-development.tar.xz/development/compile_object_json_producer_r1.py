"""Bind real HIA fixture and unmodified production stream renderer for replay."""
from pathlib import Path
import hashlib,json,sys,traceback

ROOT=Path('/workspace/scratch/9acdfa9f5639/Hepta')
OVERLAY=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
COMPILER=Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin')
sys.path.insert(0,str(ROOT))
from tools.qualify_hia_selfhost import compile_stage
from tools.generate_hia_composite_functions import document
from hepta.hia_agent_assembly import render_assembly

digest=lambda raw:hashlib.sha256(raw).hexdigest()
expected='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
assert digest(COMPILER.read_bytes())==expected
directory=OVERLAY/'development/compile-object-producer-r1';directory.mkdir(exist_ok=False)
pins={}
for relative in ('tools/generate_hia_composite_functions.py','tools/generate_hia_composite_function_admission.py',
                 'tools/generate_hia_composite_function_lowering.py','tools/generate_hia_composite_function_terms.py',
                 'examples/hia_bootstrap/composite_function_render.hiaasm'):
    path=ROOT/relative;raw=path.read_bytes();pins[str(path)]=digest(raw)
    target=directory/'frozen-main'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
rows=[]
try:
    for kernel in ('stream_fixture','render'):
        doc=document(kernel);raw=render_assembly(doc).encode()
        if kernel=='render':assert raw==(ROOT/'examples/hia_bootstrap/composite_function_render.hiaasm').read_bytes()
        path=directory/(kernel+'.hiaasm');path.write_bytes(raw)
        image,receipt=compile_stage(directory,'object-'+kernel,COMPILER,raw)
        row={'kernel':kernel,'source':path.name,'source_sha256':digest(raw),
             'image':image.name,'image_sha256':digest(image.read_bytes()),'image_bytes':image.stat().st_size,
             'counts':{'functions':len(doc['functions']),'blocks':sum(len(f['blocks']) for f in doc['functions']),
                       'ops':sum(len(b['ops']) for f in doc['functions'] for b in f['blocks'])},'receipt':receipt}
        rows.append(row);print(json.dumps(row),flush=True)
    after={path:digest(Path(path).read_bytes()) for path in pins}
    assert after==pins and digest(COMPILER.read_bytes())==expected
    result={'status':'PASS','scope':'DEVELOPMENT_ONLY_FIXTURE_AND_EXACT_PRODUCTION_RENDERER',
            'compiler_sha256':expected,'kernels':rows,'before':pins,'after':after}
except BaseException as error:
    traceback.print_exc()
    result={'status':'FAIL','scope':'DEVELOPMENT_ONLY_FIXTURE_AND_EXACT_PRODUCTION_RENDERER',
            'kernels':rows,'before':pins,'error':str(error),'class':type(error).__name__}
(directory/'summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
