"""Actual HIA ObjectToken continuation checks, without skipped native paths.

Python constructs the independent oracle and forwards exact protocol bytes in
this development harness. The consumer, all state transitions and JSON bytes
are produced by the source-bound native image. This is not a whole driver.
"""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import random
import struct
import sys
import unittest

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_composite_function_tokens import ObjectTokenDecoder, TokenProtocolError, detached_packet_index
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT=Path(__file__).resolve().parents[1]
GENERATOR=ROOT/'tools/generate_hia_composite_object_json.py'
SOURCE=ROOT/'examples/hia_bootstrap/composite_object_json.hiaasm'
MANIFEST=ROOT/'development/compile-object-json-r1/composite-object-json.manifest.json'
FROZEN=ROOT/'checkpoints/object-json-source-r1/examples/hia_bootstrap/composite_object_json.hiaasm'
MAGIC=lambda text:int.from_bytes(text,'little')
INIT,CONT,REGISTER,OPAQUE,EVENT=map(MAGIC,(b'HIAOJI01',b'HIAOJC01',b'HIAOJG01',b'HIAOJQ01',b'HIAOJE01'))
PRODUCER=MAGIC(b'HIAFNC01')
BAD=0xfffffffd
OBJECTS=1<<63
MIN_WORK=262272
CANARY=b'\xa5'*32


def token(kind,value=0):
    return struct.pack('<2Q',kind,value)


def string(value):
    raw=value.encode('utf-8')
    return token(1,len(raw))+raw


def value_tokens(value):
    if value is None:return [token(4)]
    if type(value) is bool:return [token(3,int(value))]
    if type(value) is int:return [token(2,value)]
    if type(value) is str:return [string(value)]
    if type(value) is list:
        return [token(5,len(value))]+[t for item in value for t in value_tokens(item)]
    if type(value) is dict:
        return [token(6,len(value))]+[t for key,item in value.items() for t in [string(key)]+value_tokens(item)]
    raise TypeError(type(value))


def chunks(tokens,limit=65472):
    output=[];part=bytearray()
    for item in tokens:
        if len(item)>limit:raise ValueError('one token exceeds producer frame')
        if len(part)+len(item)>limit:
            output.append(bytes(part));part.clear()
        part.extend(item)
    if part or not output:output.append(bytes(part))
    return output


class ActualObjectJson:
    def __init__(self,evidence):
        self.pins={}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes();digest=sha256(raw).hexdigest()
            if str(path) in self.pins and self.pins[str(path)]!=digest:
                raise AssertionError('ObjectToken source changed during admission')
            self.pins[str(path)]=digest
            return raw
        manifest=json.loads(read(MANIFEST));source=read(SOURCE)
        frozen=read(FROZEN);image=read(MANIFEST.parent/manifest['image_path'])
        if (manifest['schema']!='hepta.hia.composite-object-json-native.v1'
                or source!=frozen or manifest['source_sha256']!=sha256(source).hexdigest()
                or manifest['image_sha256']!=sha256(image).hexdigest()):
            raise AssertionError('ObjectToken source/image identity mismatch')
        read(GENERATOR);read(__file__)
        if any(sha256(Path(path).read_bytes()).hexdigest()!=digest for path,digest in self.pins.items()):
            raise AssertionError('ObjectToken readback mismatch before map or evidence')
        self.directory=Path(evidence);self.directory.mkdir(parents=True,exist_ok=False)
        self.image=NativeHiaJsonImage(image,manifest['image_sha256'])
        self.log=(self.directory/'actual-object-json-ledger.jsonl').open('w')
        self.entries=0;self.streams=0

    def session(self,label,packet=None,**kwargs):
        self.streams+=1
        return Session(self,label,transport(None) if packet is None else packet,self.streams,**kwargs)

    def close(self):
        self.log.close()
        after={path:sha256(Path(path).read_bytes()).hexdigest() for path in self.pins}
        report={'scope':'COMPLETE_GENERIC_OBJECTTOKEN_TRANSPORT_DEVELOPMENT_NOT_WHOLE_DRIVER_OR_COLD',
                'actual_entries':self.entries,'streams':self.streams,'before':self.pins,'after':after,
                'sources_unchanged':after==self.pins,
                'large_inputs':'Full expected bytes compared in memory; commands/payloads <=4096 B embedded; larger deterministic bytes have SHA and checked constructors.'}
        (self.directory/'custody.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        if after!=self.pins:raise AssertionError('ObjectToken source/image drift')


class Session:
    def __init__(self,native,label,packet,stream,*,size=MIN_WORK,lease=17,
                 producer=PRODUCER,action=0,request=1,serial=8192,slots=512):
        self.native=native;self.label=label;self.packet=packet;self.stream=stream;self.lease=lease
        self.source=ctypes.create_string_buffer(packet+CANARY)
        self.size=size;self.work=ctypes.create_string_buffer(size+len(CANARY))
        ctypes.memset(ctypes.addressof(self.work)+size,0xa5,len(CANARY))
        self.producer=producer;self.action=action;self.request=request;self.serial=serial;self.slots=slots
        self.init_command=struct.pack('<8Q',INIT,lease,stream,producer,action,request,serial,slots)
        self.last=None;self.output=[];self.registry={};self.sequence=0;self.growths=0
        self.opaque_offsets={};self.events=[]

    def call(self,raw,label='entry'):
        command=ctypes.create_string_buffer(raw+CANARY)
        result=self.native.image._entry(command,len(raw),self.source,len(self.packet),self.work,self.size)
        self.native.entries+=1
        unchanged=bytes(command[:len(raw)])==raw and memoryview(self.source).cast('B')[:len(self.packet)]==self.packet
        guards=(bytes(command[len(raw):len(raw)+len(CANARY)])==CANARY
                and bytes(self.source[len(self.packet):len(self.packet)+len(CANARY)])==CANARY
                and bytes(self.work[self.size:self.size+len(CANARY)])==CANARY)
        if not unchanged or not guards:raise AssertionError(('ObjectToken input/canary mutation',self.label,label))
        header=struct.unpack_from('<16Q',self.work,1024) if self.size>=1152 else None
        payload=bytes(self.work[1152:result]) if 1152<=result<=66560 else None
        row={'case':self.label,'call':label,'entry':self.native.entries,'stream':self.stream,
             'returned':result,'event':header,'workspace_bytes':self.size,
             'command_bytes':len(raw),'command_sha256':sha256(raw).hexdigest(),
             'source_bytes':len(self.packet),'source_sha256':sha256(self.packet).hexdigest(),
             'payload_bytes':len(payload) if payload is not None else None,
             'payload_sha256':sha256(payload).hexdigest() if payload is not None else None,
             'inputs_unchanged':unchanged,'canaries_unchanged':guards}
        if len(raw)<=4096:row['command_base64']=base64.b64encode(raw).decode()
        if payload is not None and len(payload)<=4096:row['payload_base64']=base64.b64encode(payload).decode()
        self.native.log.write(json.dumps(row,sort_keys=True)+'\n');self.native.log.flush()
        if result!=BAD:
            if header[:5]!=(EVENT,header[1],0,self.lease,self.stream):raise AssertionError(('invalid event identity',header))
            if header[7:9]!=(1152,len(payload)) or header[14:]!=(0,0):raise AssertionError(('invalid event extent',header))
            if self.last is not None and header[6]!=self.last[6]+1:raise AssertionError(('event sequence drift',self.last,header))
            self.output.append(payload);self.events.append(header[1])
        self.last=header
        return result,header,payload

    def grow(self,needed):
        old=self.work;size=max(needed,self.size*2)
        self.work=ctypes.create_string_buffer(size+len(CANARY))
        ctypes.memmove(self.work,old,self.size)
        self.size=size;self.growths+=1
        ctypes.memset(ctypes.addressof(self.work)+size,0xa5,len(CANARY))

    def initialize(self):
        result=self.call(self.init_command,'initialize')
        while result[0]!=BAD and result[1][1]==3:
            if result[1][12]!=10:raise AssertionError('unexpected init continuation')
            self.grow(result[1][10]);result=self.call(self.init_command,'initialize-grown')
        return result

    def continuation(self):
        return struct.pack('<4Q',CONT,self.lease,self.stream,self.last[6])

    def finish_event(self,result,*,reader=None,chunk_size=65536):
        while result[0]!=BAD and result[1][1] in (2,3,4):
            header=result[1]
            if header[1]==3:
                self.grow(header[10]);result=self.call(self.continuation(),'resume-grown')
            elif header[1]==2:
                result=self.call(self.continuation(),'resume-output')
            else:
                handle,query,seq=header[10:13]
                if reader is None:
                    raw=self.registry[handle];at=self.opaque_offsets.get(query,0)
                    payload=raw[at:at+chunk_size];self.opaque_offsets[query]=at+len(payload)
                    final=at+len(payload)==len(raw)
                else:
                    payload,final=reader(self,handle,query,seq)
                command=struct.pack('<8Q',OPAQUE,self.lease,self.stream,header[6],handle,query,seq,int(final))+payload
                result=self.call(command,'opaque-reply')
        return result

    def register(self,handle,raw,*,digest=None):
        digest=sha256(raw).digest() if digest is None else digest
        command=struct.pack('<6Q',REGISTER,self.lease,self.stream,self.last[6],handle,len(raw))+digest+struct.pack('<2Q',0,0)
        result=self.finish_event(self.call(command,'register'))
        if result[0]!=BAD:self.registry[handle]=raw
        return result

    def producer_frame(self,payload,final):
        raw=struct.pack('<8Q',self.producer,self.action,self.sequence,int(final),self.serial,self.slots,self.request,len(payload))+payload
        self.sequence+=1
        return raw

    def feed(self,payload,final=True,**kwargs):
        return self.finish_event(self.call(self.producer_frame(payload,final),'producer'),**kwargs)

    def bytes(self):
        return b''.join(self.output)


class ObjectJsonSourceTests(unittest.TestCase):
    def test_exact_source_and_original_compiler_profile(self):
        spec=importlib.util.spec_from_file_location('object_json_authoring',GENERATOR)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        document=module.document()
        self.assertEqual(render_assembly(document).encode(),SOURCE.read_bytes())
        self.assertEqual(SOURCE.read_bytes(),FROZEN.read_bytes())
        self.assertEqual([p['type'] for p in document['functions'][0]['params']],['readbuf','mutbuf','mutbuf'])
        self.assertLessEqual(len(document['functions']),128)
        self.assertLessEqual(sum(len(f['blocks']) for f in document['functions']),1536)
        self.assertLessEqual(max(len(f['blocks']) for f in document['functions']),256)
        self.assertLessEqual(max(len(b['params']) for f in document['functions'] for b in f['blocks']),16)


class ObjectJsonNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        evidence=os.environ.get('HEPTA_HIA_OBJECT_JSON_EVIDENCE')
        if not evidence:raise AssertionError('explicit fresh ObjectToken evidence required; no skip')
        cls.native=ActualObjectJson(evidence)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def exact(self,label,value,*,limit=65472,source=None,tokens=None,workspace_size=MIN_WORK):
        wire=transport(None if source is None else source)
        _,index=detached_packet_index(wire)
        session=self.native.session(label,wire,size=workspace_size)
        self.assertEqual(session.initialize()[1][1],1,label)
        decoder=ObjectTokenDecoder(index)
        pieces=chunks(value_tokens(value) if tokens is None else tokens,limit)
        for i,piece in enumerate(pieces):
            final=i==len(pieces)-1
            expected_value=decoder.feed(piece,final=final)
            result,header,_=session.feed(piece,final)
            self.assertNotEqual(result,BAD,(label,header))
            self.assertEqual(header[1],5 if final else 1,label)
        expected=json.dumps(expected_value,ensure_ascii=False,separators=(',',':')).encode()
        self.assertEqual(session.bytes(),expected,label)
        self.assertEqual(header[9],len(expected),label)
        self.assertEqual(header[11],decoder.token_count,label)
        return session

    def test_all_tokens_strings_and_unsigned_integer_boundaries(self):
        values=[None,False,True,0,1,9,10,99,100,(1<<32)-1,1<<63,(1<<64)-1,
                '', 'é😀中', ''.join(chr(i) for i in range(32)), '"\\\x7f\u07ff\u0800\ud7ff\ue000\uffff\U0010ffff',
                [],{},[1,False,None],{'z':[0,1],'a':{'😀':'é'},'':'x'}]
        for i,value in enumerate(values):self.exact('atoms-%02d'%i,value,limit=96)
        rng=random.Random(0x6f626a)
        def tree(depth):
            kind=rng.randrange(5 if depth else 3)
            if kind==0:return rng.choice(values[:16])
            if kind==1:return rng.getrandbits(64)
            if kind==2:return ''.join(rng.choice('aé😀\x00\n\\"') for _ in range(rng.randrange(16)))
            if kind==3:return [tree(depth-1) for _ in range(rng.randrange(6))]
            return {'k%d-%s'%(i,rng.choice(('a','é','😀',''))):tree(depth-1) for i in range(rng.randrange(5))}
        for i in range(80):self.exact('random-6f626a-%03d'%i,tree(4),limit=128)

    def test_every_source_node_and_full_native_source_key_equality(self):
        source={'same':'same','é😀':[-1,1<<130,None,True,{'x':'\x00"\\'}],'empty':[], 'dict':{}}
        wire=transport(source);_,index=detached_packet_index(wire)
        for at,value in index.items():
            self.exact('source-node-%d'%at,value,source=source,tokens=[token(0,at)])
        key_at=next(at for at,value in index.items() if value=='same')
        native=[token(6,2),token(0,key_at),token(2,7),string('different'),token(0,0)]
        self.exact('source-key-and-root',None,source=source,tokens=native,limit=64)
        bad=[token(6,2),token(0,key_at),token(2,7),string('same'),token(4)]
        session=self.native.session('duplicate-source-native-key',wire);session.initialize()
        self.assertEqual(session.feed(b''.join(bad))[0],BAD)
        decoder=ObjectTokenDecoder(index)
        with self.assertRaises(TokenProtocolError):decoder.feed(b''.join(bad),final=True)

    def test_dynamic_depth_keys_empty_chunks_and_large_arity_do_not_wrap(self):
        depth=4096
        session=self.native.session('native-depth4096',size=262288);session.initialize()
        initial_growths=session.growths
        pieces=chunks([token(5,1)]*depth+[token(2,0)])
        for i,piece in enumerate(pieces):result=session.feed(piece,i==len(pieces)-1)
        self.assertEqual(result[1][1],5)
        self.assertEqual(session.bytes(),b'['*depth+b'0'+b']'*depth)
        self.assertGreater(session.growths,initial_growths)
        value={'key-%04d'%i:i for i in range(1024)}
        session=self.exact('native-map1024',value,limit=256,workspace_size=262288)
        self.assertGreater(session.growths,0)
        session=self.native.session('empty-nonfinal-and-final');session.initialize()
        self.assertEqual(session.feed(b'',False)[1][1],1)
        self.assertEqual(session.feed(token(4),False)[1][1],1)
        self.assertEqual(session.feed(b'',True)[1][1],5)
        self.assertEqual(session.bytes(),b'null')
        for kind in (5,6):
            session=self.native.session('arity-u64max-kind%d'%kind);session.initialize()
            self.assertEqual(session.feed(token(kind,(1<<64)-1),False)[1][1],1)
            self.assertEqual(session.feed(b'',True)[0],BAD)

    def test_protocol_refusals_and_permanent_poison(self):
        malformed=[b'',b'x',token(7),token(3,2),token(4,1),token(1,1),token(1,1)+b'\xff',
                   token(1,3)+b'\xed\xa0\x80',token(5,1),token(6,1)+string('x'),token(4)+token(4),
                   token(6,1)+token(2,1)+token(4),token(0,1),token(0,16),token(0,OBJECTS),
                   token(6,2)+string('x')+token(4)+string('x')+token(4)]
        for i,payload in enumerate(malformed):
            session=self.native.session('bad-token-%02d'%i);session.initialize()
            result=session.feed(payload)
            self.assertEqual(result[0],BAD,(i,result[1]))
            before=bytes(session.work)
            self.assertEqual(session.call(session.init_command,'poisoned-init')[0],BAD)
            self.assertEqual(bytes(session.work),before)
            decoder=ObjectTokenDecoder({0:None})
            with self.assertRaises(TokenProtocolError):decoder.feed(payload,final=True)
            with self.assertRaises(TokenProtocolError):decoder.feed(token(4),final=True)
        for field,replacement in ((0,0),(1,9),(2,1),(3,2),(4,8193),(5,513),(6,2),(7,15)):
            session=self.native.session('bad-producer-field%d'%field);session.initialize()
            words=[PRODUCER,0,0,1,8192,512,1,16];words[field]=replacement
            self.assertEqual(session.call(struct.pack('<8Q',*words)+token(4))[0],BAD)
        for field in (1,2,3):
            session=self.native.session('bad-continuation-field%d'%field);session.initialize()
            payload=token(1,65000)+b'\x00'*65000
            result=session.call(session.producer_frame(payload,True),'needs-output')
            self.assertEqual(result[1][1],2)
            words=[CONT,session.lease,session.stream,session.last[6]];words[field]+=1
            self.assertEqual(session.call(struct.pack('<4Q',*words),'wrong-resume')[0],BAD)

    def test_source_validation_growth_custody_and_node_boundaries(self):
        for i,raw in enumerate((b'',b'\0'*15,transport(None)+transport(None),struct.pack('<2Q',4,1)+b'\xff',
                                struct.pack('<2Q',2,2)+b'-0')):
            session=self.native.session('bad-source-%d'%i,raw)
            self.assertEqual(session.initialize()[0],BAD)
        raw=transport('x'*200000)
        session=self.native.session('initial-grow-identity',raw)
        result=session.call(session.init_command)
        self.assertEqual((result[1][1],result[1][12]),(3,10))
        session.grow(result[1][10])
        wrong=bytearray(session.init_command);struct.pack_into('<Q',wrong,8,session.lease+1)
        self.assertEqual(session.call(bytes(wrong))[0],BAD)
        self.exact('overlap-index-copy',{'k':'x'*200000},source={'k':'x'*200000},tokens=[token(0,0)])
        raw=transport([None,1])
        _,index=detached_packet_index(raw)
        for at in range(len(raw)):
            if at in index:continue
            session=self.native.session('non-node-ref-%d'%at,raw);session.initialize()
            self.assertEqual(session.feed(token(0,at))[0],BAD)

    def test_opaque_issued_handles_digest_extent_and_reply_correlation(self):
        for length in (0,1,46,47,54,55,56,63,64,65,4095,4096):
            raw=b'{"x":"'+b'a'*length+b'"}'
            session=self.native.session('opaque-sha-padding-%d'%length);session.initialize()
            self.assertEqual(session.register(OBJECTS,raw)[1][1],1)
            result=session.feed(token(5,2)+token(0,OBJECTS)+token(0,OBJECTS),chunk_size=13)
            self.assertEqual(result[1][1],5)
            self.assertEqual(session.bytes(),b'['+raw+b','+raw+b']')
        raw=b'{"payload":"'+b'x'*1000+b'"}'
        for fault in ('hash','extent','handle','query','sequence','final','lease','stream','event'):
            session=self.native.session('opaque-bad-'+fault);session.initialize()
            session.register(OBJECTS,raw)
            result=session.call(session.producer_frame(token(0,OBJECTS),True))
            self.assertEqual(result[1][1],4)
            words=[OPAQUE,session.lease,session.stream,session.last[6],OBJECTS,session.last[11],0,1]
            payload=raw
            if fault=='hash':payload=raw[:-2]+b'!}'
            elif fault=='extent':payload=raw[:-1]
            else:words[{'handle':4,'query':5,'sequence':6,'final':7,'lease':1,'stream':2,'event':3}[fault]]+=1
            self.assertEqual(session.call(struct.pack('<8Q',*words)+payload)[0],BAD,fault)
        session=self.native.session('opaque-duplicate-register');session.initialize();session.register(OBJECTS,b'{}')
        self.assertEqual(session.register(OBJECTS,b'{}')[0],BAD)
        session=self.native.session('opaque-cannot-be-key');session.initialize();session.register(OBJECTS,b'{}')
        self.assertEqual(session.feed(token(6,1)+token(0,OBJECTS)+token(4))[0],BAD)

    def test_complete_generated_stream_has_no_eight_mib_or_service_packet_limit(self):
        # A small typed source is repeated by the ObjectToken producer. The
        # resulting complete stream exceeds final Core admission's later 8 MiB
        # limit, which this generic transport must not apply prematurely.
        text='z'*(2<<20)
        wire=transport(text)
        session=self.native.session('complete-json-over12MiB',wire);session.initialize()
        result=session.feed(token(5,6)+token(0,0)*6)
        self.assertEqual(result[1][1],5)
        expected=b'['+b','.join([b'"'+text.encode()+b'"']*6)+b']'
        self.assertGreater(len(expected),8<<20)
        self.assertEqual(session.bytes(),expected)
        self.assertGreater(session.events.count(2),100)
        raw=b'{"x":"'+b'o'*(9<<20)+b'"}'
        session=self.native.session('opaque-complete-over9MiB');session.initialize();session.register(OBJECTS,raw)
        result=session.feed(token(0,OBJECTS))
        self.assertEqual(result[1][1],5)
        self.assertEqual(session.bytes(),raw)


if __name__=='__main__':
    unittest.main()
