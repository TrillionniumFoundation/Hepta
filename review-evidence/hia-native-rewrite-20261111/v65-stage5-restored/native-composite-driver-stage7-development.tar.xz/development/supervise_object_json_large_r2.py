"""External wait4 record for the unchanged 90 CPU second / 1 GiB test worker."""
from pathlib import Path
import hashlib,json,os,resource,sys,time

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
OUT=ROOT/'development/object-json-large-r2-supervisor';OUT.mkdir(exist_ok=False)
FILES=[ROOT/name for name in ('tools/generate_hia_composite_object_json.py',
       'examples/hia_bootstrap/composite_object_json.hiaasm','docs/HIA_COMPOSITE_OBJECT_TOKEN_JSON.md',
       'tests/test_hia_composite_object_json.py','development/run_object_json_large_r2.py',
       'development/compile-object-json-r2/composite-object-json.manifest.json',
       'development/compile-object-json-r2/composite-object-json.image.bin',
       'development/compile-object-producer-r1/summary.json')]
producer=json.loads(FILES[-1].read_text())
for row in producer['kernels']:
    FILES.extend(ROOT/'development/compile-object-producer-r1'/row[key] for key in ('source','image'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
before={str(path):{'bytes':path.stat().st_size,'sha256':digest(path)} for path in FILES}
(OUT/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
def memory_events():
    try:return Path('/sys/fs/cgroup/memory.events').read_text()
    except OSError as error:return type(error).__name__
events_before=memory_events()
started=time.monotonic()
pid=os.fork()
if pid==0:
    log=os.open(ROOT/'development/object-json-large-r2.log',os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o644)
    os.dup2(log,1);os.dup2(log,2);os.close(log)
    os.chdir(ROOT)
    os.execv(sys.executable,[sys.executable,str(ROOT/'development/run_object_json_large_r2.py')])
_,status,usage=os.wait4(pid,0)
code=os.waitstatus_to_exitcode(status)
after={str(path):{'bytes':path.stat().st_size,'sha256':digest(path)} for path in FILES}
report={'scope':'ACTUAL_R2_LARGE_GENERIC_STREAM_DEVELOPMENT_NOT_COLD_OR_WHOLE_DRIVER',
        'exit_code':code,'wait_status':status,'signal':-code if code<0 else None,
        'wall_seconds':time.monotonic()-started,'user_cpu_seconds':usage.ru_utime,
        'system_cpu_seconds':usage.ru_stime,'max_rss_kib':usage.ru_maxrss,
        'worker_limits':{'cpu_seconds':90,'address_bytes':1<<30},
        'before':before,'after':after,'all_source_bytes_unchanged':before==after,
        'memory_events_before':events_before,'memory_events_after':memory_events()}
(OUT/'wait4.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({key:value for key,value in report.items() if key not in ('before','after')}),flush=True)
raise SystemExit(0 if code==0 and before==after else 1)
