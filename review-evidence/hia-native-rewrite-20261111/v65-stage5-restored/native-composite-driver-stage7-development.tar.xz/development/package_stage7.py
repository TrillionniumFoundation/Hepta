"""Preserve exact r1/r2 stream source and original evidence after recovery."""
from pathlib import Path
import hashlib
import json
import stat
import tarfile

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
DEST = Path('/dev/shm/native-composite-driver-stage7-development.tar.xz')
BASE = ROOT / 'checkpoints/stage7'
BASE.mkdir(exist_ok=False)
paths = {}

def add(path, name):
    if not path.is_file() or path.is_symlink():
        raise RuntimeError('missing or non-regular original: ' + str(path))
    if name in paths and paths[name] != path:
        raise RuntimeError('archive name collision')
    paths[name] = path

for name in (
    'docs/HIA_COMPOSITE_OBJECT_TOKEN_JSON.md',
    'tools/generate_hia_composite_object_json.py',
    'examples/hia_bootstrap/composite_object_json.hiaasm',
    'tests/test_hia_composite_object_json.py',
    'development/STAGE6_SMALL.md',
    'development/STAGE7.md',
    'development/OBJECT_TOKEN_REVIEW_NOTES_R1.md',
    'development/package_stage6_small.py',
    'development/package_stage7.py',
    'checkpoints/stage6-small/source.json',
):
    add(ROOT / name, name)
for pattern in (
    'development/object-json-*',
    'development/compile-object-json-*',
    'development/compile-object-producer-*',
    'development/compile_object_json_*.py',
    'development/run_object_json_*.py',
    'development/supervise_object_json_*.py',
    'checkpoints/object-json-*',
):
    for path in ROOT.glob(pattern):
        if path.is_file():
            add(path, path.relative_to(ROOT).as_posix())
        elif path.is_dir():
            for member in path.rglob('*'):
                if member.is_file() and '__pycache__' not in member.parts:
                    add(member, member.relative_to(ROOT).as_posix())
for name in ('object-json-independent-r1', 'object-json-independent-r2'):
    directory = ROOT.parent / name
    if not directory.is_dir():
        raise RuntimeError('missing original review: ' + str(directory))
    for path in directory.rglob('*'):
        if path.is_file():
            add(path, 'independent/' + name + '/' + path.relative_to(directory).as_posix())

for rel, expected in {
    'docs/HIA_COMPOSITE_OBJECT_TOKEN_JSON.md': 'fd869859a7da93adcf9acc3405edaf459a8ce92b20daf2c7489d5bfcb9af20d8',
    'tools/generate_hia_composite_object_json.py': '5647df920ba7acfef0f5c9914864ec948f180c5ae228b44df15ce9f4af248376',
    'examples/hia_bootstrap/composite_object_json.hiaasm': '3a184f6cf17a3c62fe67c83074f3455f64fb7112f628dc4514cdd98f6e87953c',
    'tests/test_hia_composite_object_json.py': '95786aeac0186d5bb5474c0d15e1ecce0db1a71333cbd8abd84d805a75db797e',
    'development/compile-object-json-r2/composite-object-json.image.bin': 'b6bb38c19ebf67ae01757fb37459bd18a7dcdf01b43dc86dfcbdb77e9b19ea70',
}.items():
    if hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() != expected:
        raise RuntimeError('frozen source changed: ' + rel)

preserved = ROOT / 'development/object-json-large-r2-ram-custody'
copy_manifest = json.loads((preserved / 'copy-custody.json').read_bytes())
for row in copy_manifest['files']:
    p = preserved / row['path']
    raw = p.read_bytes()
    assert len(raw) == row['bytes']
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    assert stat.S_IMODE(p.stat().st_mode) == row['mode']

rows = []
for name, path in sorted(paths.items()):
    raw = path.read_bytes()
    rows.append({
        'path': name, 'origin': str(path),
        'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
        'mode': stat.S_IMODE(path.stat().st_mode),
    })
report = {
    'scope': 'COMPLETE_GENERIC_STREAM_R2_DEVELOPMENT_NOT_COLD_OR_WHOLE_DRIVER',
    'members': rows, 'member_count': len(rows),
    'raw_bytes': sum(row['bytes'] for row in rows),
    'prior_failures_preserved': True,
    'large_custody_rechecked_after_environment_restart': True,
    'new_unexecuted_object_ir_source_excluded': True,
}
manifest = BASE / 'source.json'
manifest.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
with tarfile.open(DEST, 'w:xz', preset=6) as archive:
    for row in rows:
        archive.add(paths[row['path']], arcname=row['path'], recursive=False)
checks = []
with tarfile.open(DEST, 'r:xz') as archive:
    assert [member.name for member in archive.getmembers()] == [row['path'] for row in rows]
    for row in rows:
        member = archive.getmember(row['path'])
        raw = archive.extractfile(member).read()
        assert raw == paths[row['path']].read_bytes()
        assert len(raw) == row['bytes']
        assert hashlib.sha256(raw).hexdigest() == row['sha256']
        assert stat.S_IMODE(member.mode) == row['mode']
        assert stat.S_IMODE(paths[row['path']].stat().st_mode) == row['mode']
        checks.append({
            'path': row['path'], 'bytes_equal': True,
            'sha256_equal': True, 'mode_equal': True,
        })
raw = DEST.read_bytes()
custody = {
    'archive': str(DEST), 'bytes': len(raw),
    'sha256': hashlib.sha256(raw).hexdigest(),
    'member_count': len(rows), 'raw_bytes': report['raw_bytes'],
    'source_manifest': str(manifest),
    'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'all_original_bytes_sha_and_modes_equal': True,
    'checks': checks,
}
output = BASE / 'custody.json'
output.write_text(json.dumps(custody, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in custody.items() if key != 'checks'}), flush=True)
print(json.dumps({
    'custody': str(output), 'bytes': output.stat().st_size,
    'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
}), flush=True)
