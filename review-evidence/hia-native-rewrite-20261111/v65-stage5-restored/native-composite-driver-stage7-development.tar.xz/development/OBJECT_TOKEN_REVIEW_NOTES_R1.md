# Additional review scope for frozen ObjectToken source r1

The three production files in `object-json-source-r1` and the original small
checkpoint remain unchanged. This note records a precise framing qualification
identified by the independent static reviewer after that checkpoint.

`object_json` checks that the workspace extent is at least 262,272 bytes before
reading or writing its protocol state. An invocation below that minimum returns
`0xfffffffd` immediately. It cannot safely promise to write a persistent poison
flag into a buffer whose advertised extent may not even contain that flag. A
private caller that supplies a truncated extent for an otherwise allocated
workspace and later silently restores the extent can therefore continue that
workspace. The permanent-poison controls in the small panel use the complete
workspace ABI and do not claim to cover this invalid borrow operation.

There is no public raw-JSON driver using this component yet. The final fixed
driver must treat **every** invalid native return as terminal for its issued
lease, close/discard that lease and never retry it with altered extents. The
same driver must preserve the actual immutable source packet and internally
issued opaque registry. Caller-supplied lease IDs and REGISTER messages alone
do not authenticate arbitrary external data.

This is a scope clarification, not a claimed public source-language regression,
not a completed driver lifecycle test and not a production kernel modification.
The future driver must be tested at its own publication and resource boundary.
