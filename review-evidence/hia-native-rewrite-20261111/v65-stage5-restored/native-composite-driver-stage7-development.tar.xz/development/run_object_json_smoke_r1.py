"""First real-image small-buffer smoke; retain actual failure without retries."""
from pathlib import Path
import hashlib,importlib.util,json,os,resource,sys,time,unittest
ROOT=Path('/workspace/scratch/9acdfa9f5639/Hepta')
OVERLAY=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
sys.path.insert(0,str(ROOT))
out=OVERLAY/'development/object-json-smoke-r1';out.mkdir(exist_ok=False)
os.environ['HEPTA_HIA_OBJECT_JSON_EVIDENCE']=str(out/'actual')
path=OVERLAY/'tests/test_hia_composite_object_json.py';raw=path.read_bytes()
(out/'test-source.py').write_bytes(raw)
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
spec=importlib.util.spec_from_file_location('object_json_tests',path)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
names=['test_all_tokens_strings_and_unsigned_integer_boundaries',
       'test_opaque_issued_handles_digest_extent_and_reply_correlation']
suite=unittest.TestSuite(m.ObjectJsonNativeTests(name) for name in names)
started=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'scope':'SMALL_BUFFER_ACTUAL_NATIVE_DEVELOPMENT_SMOKE',
        'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'expected_failures':len(result.expectedFailures),
        'unexpected_successes':len(result.unexpectedSuccesses),
        'elapsed_seconds':time.monotonic()-started,
        'test_source_sha256':hashlib.sha256(raw).hexdigest(),
        'test_source_unchanged':path.read_bytes()==raw,
        'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(out/'result.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report),flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
