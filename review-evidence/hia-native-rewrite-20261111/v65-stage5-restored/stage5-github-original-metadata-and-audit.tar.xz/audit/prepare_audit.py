"""Bind the unchanged full-byte audit algorithm to the original d5 run."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path('/workspace/scratch/9acdfa9f5639')
OUT=ROOT/'v65-stage5-github-independent-audit'
OUT.mkdir(exist_ok=True)
base=ROOT/'v65-github-independent-audit/audit.py'
original=base.read_text()
s=original
pairs=[
("OUT = ROOT / 'v65-github-independent-audit'","OUT = ROOT / 'v65-stage5-github-independent-audit'"),
("/dev/shm/hia-v65-github-original/HIA-v65-eef68334-GitHub-20261111.zip","/dev/shm/hia-v65-stage5-github-original/HIA-v65-d5da1eb-GitHub-20261111.zip"),
("ROOT / 'hia-ci-v65-candidate'","ROOT / 'hia-ci-v65-stage5'"),
("ROOT / 'hia-v65-candidate-publication'","ROOT / 'hia-v65-stage5-publication'"),
("eef68334b078eb9fcc414f441c35687e33585bba","d5da1eb760454ef3df5153c5e80eb046ddb389d9"),
("dc088a3c1f551c353a1bc3a7df1034f92f79aaee","71c9c3effb9ffa45c708e272f374302507d0d65a"),
("c35cddad61e97fc2b2a622d9430a9c9c568e4f3a4dbce598333fd5fe839f1a81","e7fc39688e2fdf03b00b93f11ee6d6353baa3216956a0cf3fe79ed3d14379068"),
("48032028","48390300"),
("42995591456","42999809456"),
("13842954320","13845513358"),
("    assert job['conclusion']=='failure'","    assert job['conclusion']==('success' if job['name']=='source' else 'failure')"),
("[(n,'success') for n in range(1,9)]+[(9,'failure')]","[(n,'success') for n in range(1,10)]"),
("176db1c67497d23092d090c601a0e8d16dafb94674d7e5c098d4220cdf46c669","53697c5ebac2a0aa91e631fb3081f951635322e9b16600150fcd82725a288e6b"),
("draft-stage4-source.tar.xz","draft-stage5-source.tar.xz"),
("99efe8bfe480a44551caec29c73de9c6a02586d65f7e2bc0293dbf623850026e","0605422b4cd42cbab4b200fbc9c47645f022430a0b9c6cfcd9479a231837279e"),
("9ff79d2ac36fcf0059c8d1df5eecd04b61162864346ad8b71fa20755ea8b0ada","01d1df5eca526ed3ae3fd5c56707f90edaad6d3d39a38f65d5beae6b5cae3949"),
("==4662","==4980"),
("180146844994","180173765523"),
("80769164","84159146"),
("352542644","368759152"),
("r'Ran 327 tests in 511\\.619s',source_log) and 'FAILED (errors=3)' in source_log","r'Ran 327 tests in 497\\.666s',source_log) and re.search(r'Z OK$',source_log,re.M)"),
("source_log.count('ImportError: cannot import name')==3","source_log.count('ImportError: cannot import name')==0"),
("assert '_PhaseArchivePool' in source_log and '_PendingPhaseArchive' in source_log","assert all(marker not in source_log for marker in ('FAILED (','unexpected success','expected failure','... skipped'))"),
("CI_HOLD_SOURCE_IMPORT_ERRORS_AND_COLD_TIMEOUT_NATIVE_GROUPS_NOT_EXECUTED","CI_HOLD_COLD_TIMEOUT_NATIVE_GROUPS_NOT_EXECUTED"),
("'seconds':511.619,'passed':False,'errors':3,'cause':'missing integrated archive queue implementation'","'seconds':497.666,'passed':True,'errors':0,'failures':0,'skips':0,'expected_failures':0,'unexpected_successes':0"),
("assert process['schema']=='hepta.hia.selfhost-phase-process.v1'","assert process['archive_completed_monotonic_ns'] >= process['completed_monotonic_ns']\n        assert process['schema']=='hepta.hia.selfhost-phase-process.v1'"),
("'completed_ns':process['completed_monotonic_ns']","'completed_ns':process['completed_monotonic_ns'],'archive_completed_ns':process['archive_completed_monotonic_ns']")
]
records=[]
for old,new in pairs:
    count=s.count(old)
    assert count>=1,(old,count)
    s=s.replace(old,new)
    records.append({'before':old,'after':new,'occurrences':count})
target=OUT/'audit.py'
target.write_text(s)
(OUT/'binding-changes.json').write_text(json.dumps({'base':str(base),'base_sha256':sha256(original.encode()).hexdigest(),'new_sha256':sha256(s.encode()).hexdigest(),'changes':records,'qualification_rerun':False,'original_fixed_limits_unchanged':True},indent=2,sort_keys=True)+'\n')
print(json.dumps({'audit':str(target),'sha256':sha256(s.encode()).hexdigest(),'binding_changes':len(records)}))
