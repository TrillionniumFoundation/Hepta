"""Retain the exact d5 GitHub artifact and inspect its original cold report."""
from pathlib import Path
from hashlib import sha256
import json,os,urllib.request,zipfile
ROOT=Path('/workspace/scratch/9acdfa9f5639')
OUT=ROOT/'hia-ci-v65-stage5'
RAM=Path('/dev/shm/hia-v65-stage5-github-original')
OUT.mkdir(exist_ok=True);RAM.mkdir(mode=0o700,exist_ok=True)
request=json.loads((RAM/'private-download-request.json').read_bytes())
url=request['download_url']
target=RAM/'HIA-v65-d5da1eb-GitHub-20261111.zip'
expected_bytes=48390300
expected_sha='e7fc39688e2fdf03b00b93f11ee6d6353baa3216956a0cf3fe79ed3d14379068'
def dump(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
try:
    if not target.exists():
        partial=target.with_suffix('.zip.partial')
        with partial.open('xb') as f,urllib.request.urlopen(url,timeout=60) as response:
            while True:
                b=response.read(1024*1024)
                if not b:break
                f.write(b)
            f.flush();os.fsync(f.fileno())
        b=partial.read_bytes()
        assert len(b)==expected_bytes and sha256(b).hexdigest()==expected_sha
        partial.rename(target)
    b=target.read_bytes()
    assert len(b)==expected_bytes and sha256(b).hexdigest()==expected_sha
    result={'schema':'hepta.hia.github-original-download.v1','run_id':42999809456,'artifact_id':13845513358,'head':'d5da1eb760454ef3df5153c5e80eb046ddb389d9','path':str(target),'bytes':len(b),'sha256':sha256(b).hexdigest(),'github_expected_digest_matched':True,'tool_file_id':request['file_id']}
    dump('download.json',result)
    with zipfile.ZipFile(target) as z:
        entries=z.infolist();names=[i.filename for i in entries]
        assert len(names)==len(set(names))
        index=[{'path':i.filename,'bytes':i.file_size,'compressed_bytes':i.compress_size,'crc32':i.CRC,'unix_mode':i.external_attr>>16} for i in entries]
        dump('original-outer-index.json',index)
        chosen=[n for n in names if n=='hia-cold.json']
        assert len(chosen)==1
        raw=z.read(chosen[0]);(OUT/'cold-original.json').write_bytes(raw)
        cold=json.loads(raw)
        result.update(outer_members=len(entries),outer_uncompressed_bytes=sum(i.file_size for i in entries),cold_original_bytes=len(raw),cold_original_sha256=sha256(raw).hexdigest(),cold=cold)
    dump('download-and-cold-observation.json',result)
    print(json.dumps(result),flush=True)
    upload={'uploads':[{'local_path':str(target),'purpose':'create_library_file'}]}
    dump('library-upload.request.json',upload)
except BaseException as exc:
    failure={'error_type':type(exc).__name__,'message':str(exc).replace(url,'<redacted-download-url>'),'target_exists':target.exists(),'artifact_id':13845513358}
    dump('download-failure.json',failure)
    print(json.dumps(failure),flush=True)
    raise SystemExit(1)
