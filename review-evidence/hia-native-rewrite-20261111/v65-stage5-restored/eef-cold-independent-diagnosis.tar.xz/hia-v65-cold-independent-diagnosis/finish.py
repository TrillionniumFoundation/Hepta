"""Finish timing scope and source-integration findings; no native execution."""
from collections import Counter,defaultdict
from hashlib import sha256
from pathlib import Path
import ast,gzip,json,subprocess,tarfile,zipfile

ROOT=Path('/workspace/scratch/9acdfa9f5639');OUT=Path(__file__).resolve().parent
j=json.loads((OUT/'report.json').read_bytes());zip_path=Path(j['inputs']['github_zip']['path'])
def sha(raw):return sha256(raw).hexdigest()
def pin(path):return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()))
completed=[row for row in j['phase_records'] if row['state']=='completed']
events=defaultdict(int)
for row in completed:events[row['started_ns']]+=1;events[row['completed_ns']]-=1
active=0;previous=min(events);occupancy=Counter()
for when,change in sorted(events.items()):
    occupancy[active]+=when-previous;active+=change;previous=when
assert active==0 and max(occupancy)<=2
binding_checks=Counter()
fields=('input_bytes','input_sha256','image_sha256','artifact_sha256','status','format','transport','runner_sha256','result_u64','core_u32','output_sha256','source_unchanged','output_unchanged','limits','workspace_header')
with gzip.open(OUT/'paired-receipts.jsonl.gz','rt') as stream:
    for line in stream:
        row=json.loads(line)
        if 'v63' in row:
            assert all(row['v63'].get(k)==row['v65'].get(k) for k in fields)
            binding_checks['full_result_fields_equal_v63']+=1
        if 'v64' in row and not row['binding_differences']:
            assert row['same_semantic_request']
            binding_checks['semantic_requests_equal_v64']+=1
            if row['request'].get('frame_sha256'):
                assert row['same_request_frame_digest'];binding_checks['actual_binary_frame_sha_equal_v64']+=1
            else:binding_checks['legacy_request_without_binary_frame_digest']+=1

prefix='hia-cold.cold/qualification.evidence/';top=[]
with zipfile.ZipFile(zip_path) as z:
    for name in z.namelist():
        if name.startswith(prefix) and '/' not in name[len(prefix):] and name.endswith('.receipt.json'):
            raw=z.read(name);row=json.loads(raw)
            if 'wall_elapsed_ns' in row:
                top.append(dict(member=name,receipt_sha256=sha(raw),receipt=row))
    observer=json.loads(z.read(prefix+'independent-native-observer-reference.json'))
reference_sum=sum(row['v65_wall_ns'] for row in j['reference_workers'])
top_wall=sum(row['receipt']['wall_elapsed_ns'] for row in top)
top_native=sum(row['receipt'].get('native_elapsed_ns',0) for row in top)
prephase=dict(first_phase_start_after_qualification_ns=j['pre_first_phase_ns'],
    seventeen_reference_worker_reported_body_wall_sum_ns=reference_sum,
    two_worker_reference_span_lower_bound_ns=reference_sum/2,
    sequential_top_level_native_receipt_count=len(top),
    sequential_top_level_receipt_wall_sum_ns=top_wall,
    sequential_top_level_native_entry_wall_sum_ns=top_native,
    residual_upper_bound_ns=j['pre_first_phase_ns']-reference_sum/2-top_wall,
    residual_scope='Upper bound, not a B0 measurement: includes observer independent VM, B0 host assembly/backend/link, reference startup/writes/validation and serial framing/receipt overhead outside the captured call clock.',
    unavailable='Reference parent start/end receipts and seed-start timestamp are only in the missing final nested report. No original eef B0/observer-VM wall split exists.',
    observer_vm_windows=len(observer['vm_windows']),observer_vm_steps=sum(r['result']['steps'] for r in observer['vm_windows']),
    top_level_receipts=top)
(OUT/'prephase-originals.json').write_text(json.dumps(prephase,indent=2,sort_keys=True)+'\n')

# Independently confirm the source-CI integration hole from immutable source,
# separate from the cold timeout and the completed native owner tests.
old_qualifier=subprocess.check_output(['git','show','5831f52fada45e076f8f68f198a15c0585e6104f:tools/qualify_hia_selfhost.py'],cwd=ROOT/'Hepta')
with tarfile.open(ROOT/'hia-agent-state-integration-development/draft-stage4-source.tar.xz','r:xz') as tf:
    tests=tf.extractfile('source/tests/test_hia_selfhost.py').read()
defined={node.name for node in ast.parse(old_qualifier).body if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))}
assert '_PhaseArchivePool' not in defined and '_PendingPhaseArchive' not in defined
affected=[]
for node in ast.walk(ast.parse(tests)):
    if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'):
        imports=[name.name for item in ast.walk(node) if isinstance(item,ast.ImportFrom) and item.module=='tools.qualify_hia_selfhost' for name in item.names]
        if set(imports)&{'_PhaseArchivePool','_PendingPhaseArchive'}:affected.append(node.name)
assert len(affected)==3
source_gap=dict(kind='FROZEN_SOURCE_STATICALLY_CONFIRMED_MISSING_IMPORTS',qualifier_sha256=sha(old_qualifier),tests_sha256=sha(tests),missing_symbols=['_PhaseArchivePool','_PendingPhaseArchive'],affected_original_tests=affected,source_CI_run_reported_by_parent=dict(tests=327,errors=3,seconds=511.619),cold_timeout_is_a_separate_job_outcome=True)

findings=dict(schema='hepta.hia.v65-cold-independent-final-findings.v1',
    scope='ORIGINAL_GITHUB_AND_LOCAL_FAILED_COLD_READ_ONLY_DIAGNOSIS',
    report=pin(OUT/'report.json'),prephase=pin(OUT/'prephase-originals.json'),
    source_gap=source_gap,original_gate=dict(seconds=180,host_oracle_workers=2,phase_count=38,changed=False),
    github=dict(status='FAIL',wall_ns=j['github']['wall_ns'],owner_status=j['github']['owner']['status'],cleanup_complete=j['github']['owner']['cleanup']['complete'],remaining_direct_children=j['github']['owner']['cleanup']['remaining_direct_children'],completed_phases=34,completed_checks=3758,reference_hashes_equal_v63_v64=all(row['same_reference_sha_v63_v64'] for row in j['reference_workers']),uncompleted=['names-original','names-modified','exports-original','exports-modified'],final_nested_report_present=False),
    local=dict(status=j['local']['status'],wall_ns=j['local']['wall_ns'],source_exact_stage4=j['local']['source_exact_stage4'],same_four_uncompleted=[row['phase'] for row in j['local']['phase_records'] if row['state']!='completed']),
    receipt_binding_checks=dict(binding_checks),
    descriptive_clock_comparison=dict(timed_native_count=4536,v63_native_ns=j['triple_v63']['native_ns'],v64_native_ns=j['triple_v64']['native_ns'],v65_native_ns=j['triple_v65']['native_ns'],v63_wall_minus_native_ns=j['triple_v63']['wall_minus_native_for_timed_ns'],v64_wall_minus_native_ns=j['triple_v64']['wall_minus_native_for_timed_ns'],v65_wall_minus_native_ns=j['triple_v65']['wall_minus_native_for_timed_ns'],v65_minus_v64_native_ns=j['triple_v65']['native_ns']-j['triple_v64']['native_ns'],v65_minus_v64_wall_minus_native_ns=j['triple_v65']['wall_minus_native_for_timed_ns']-j['triple_v64']['wall_minus_native_for_timed_ns']),
    completed_child_interval_occupancy=dict(interval_ns=j['first_to_last_completed_phase_ns'],zero_completed_group_children_active_ns=occupancy[0],one_active_ns=occupancy[1],two_active_ns=occupancy[2],scope='Only the 34 completed child intervals. At the tail, unclocked pending names children may also be active; this is not pure CPU idle or archive-only time.'),
    prephase_summary={k:v for k,v in prephase.items() if k!='top_level_receipts'},
    actual_unchanged_machine_and_toolchain=dict(all_B0_B1_B2_B3_M1_M2_M3_images_same_v64=all(row['image_same_v64'] for row in j['generations']),seed_build_host_toolchain_python_core_object_machine_fields_all_same_v64=all(row['same_v64'] for row in j['seed_bindings'].values()),only_changed_reviewed_critical_source=[row['path'] for row in j['critical_sources'] if not row['unchanged']]),
    conclusions=[
      'The unchanged 180-second gate still failed. Neither partial names work nor 34 sealed passing phases is a qualification.',
      'Matched native entry wall is effectively unchanged between v64 and eef. The captured host/transport component is lower by 5.337112925 seconds summed over the same 4536 timed calls. The total paired call-wall sum is lower by 5.434736262 seconds over 5154 receipts. These are concurrent totals across different runs, not cold-wall savings or a controlled causal experiment.',
      'The eef complete-phase span fell to 118.194907235 seconds from v64 122.477574518 seconds, while prephase grew slightly to 51.491006211 seconds. The available budget still did not finish names and exports.',
      'The failed artifact has no trustworthy seed-only or observer-independent-VM wall split. The recorded 17 oracle bodies and 83 sequential native receipts already account for a two-worker lower bound of 44.1103061085 seconds before the first phase. At most 7.3807001025 seconds remains for all other serial overhead under those clock scopes; it cannot all be assigned to B0 or repeated parsing.',
      'The three source-CI missing-import errors are an independently confirmed integration defect and do not explain native entry clock growth. The stage5 archive integration is a new candidate, not a reinterpretation of eef as passing.'
    ],
    testable_next_steps=[
      dict(priority=1,owner='Bounded completed-phase archival scheduling',candidate='Separate one archiver with at most two submitted unsealed archives; preserve two fresh oracle workers, all complete archive replays and final waits.',evidence='Original worker slots synchronously include archive_completed_stage. Observed completed-child gaps justify measuring this proposal; no promised wall savings follows from them.',acceptance='Original complete source suite plus exact-source 180-second / two-worker / all38-phase cold gate; index stays pending until verified archival; archive failures cannot be promoted to PASS.'),
      dict(priority=2,owner='Independent reference fixture construction',candidate='Profile the existing signed, scalar-casts, keyword, exports, names and capacity oracle bodies before proposing another pure construction optimization.',evidence='Their actual worker body clocks are individually retained; no native compiler or final VM witness may be removed.',acceptance='Same fresh workers, every original ordinary Core/VM observation, byte-identical reference content and current-source A/B measurement; keep all rejection/custody behavior.'),
      dict(priority=3,owner='Prephase observer reference / B0 attribution',candidate='Add or obtain exact component clocks in a separate development measurement only if residual attribution is needed.',evidence='Nine real observer VM windows remain present, but the failed run did not record their elapsed time separately.',acceptance='Do not call the unmeasured residual a root cause; do not reduce the nine actual VM executions, B0 admission or sequential B/M generations.')
    ],new_native_calls=0,production_edits=[],whole_stack_closed=False)
(OUT/'FINAL_FINDINGS.json').write_text(json.dumps(findings,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(findings=pin(OUT/'FINAL_FINDINGS.json'),prephase_residual_upper_bound_ns=prephase['residual_upper_bound_ns'],binding_checks=dict(binding_checks),source_missing_import_tests=affected)))
