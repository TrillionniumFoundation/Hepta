"""Read original eef GitHub cold evidence and pair preserved prior receipts.

No qualification, native execution or production edits occur here. All prior
v63/v64 clock rows come from the already frozen and raw-checked v64 audit.
"""
from collections import Counter, defaultdict
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import gzip,json,statistics,tarfile,zipfile

ROOT=Path('/workspace/scratch/9acdfa9f5639')
OUT=Path(__file__).resolve().parent
ZIP=Path('/dev/shm/hia-v65-github-original/HIA-v65-eef68334-GitHub-20261111.zip')
EXPECTED='c35cddad61e97fc2b2a622d9430a9c9c568e4f3a4dbce598333fd5fe839f1a81'
P='hia-cold.cold/qualification.evidence/'
M='HIA_ARCHIVE_MANIFEST.json'
PREVIOUS=ROOT/'hia-v64-cold-independent-diagnosis'
V63=ROOT/'v63-github-independent-audit/summary.json'
FROZEN=ROOT/'hia-agent-state-integration-development/draft-stage4-source.json'
LOCAL=Path('/dev/shm/hia-v65-stage4-cold')
def sha(raw):return sha256(raw).hexdigest()
def pin(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()))
def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
inputs={name:pin(path) for name,path in [('github_zip',ZIP),('prior_report',PREVIOUS/'report.json'),('prior_comparison',PREVIOUS/'receipt-comparison.json'),('prior_receipt_ledger',PREVIOUS/'matched-native-receipts.jsonl.gz'),('v63_summary',V63),('stage4_manifest',FROZEN)]}
assert inputs['github_zip']['sha256']==EXPECTED and inputs['github_zip']['bytes']==48032028
assert inputs['prior_receipt_ledger']['sha256']=='ca267ae0b6408ffc5eb32ee2e168c5db3d945a104b106216ca85a5b36e48b8f3'
prior=json.loads((PREVIOUS/'report.json').read_bytes())
prior_comparison=json.loads((PREVIOUS/'receipt-comparison.json').read_bytes())
v63=json.loads(V63.read_bytes());frozen=json.loads(FROZEN.read_bytes())
v64_phases={r['phase']:r for r in prior['phase_records']}
v63_phases={r['phase']:r for r in v63['phases']}
def identity(phase,r):
    return (phase,)+tuple(r.get(k) for k in ('case','input_sha256','image_sha256','format','transport'))
def request_semantics(request):
    return {k:v for k,v in request.items() if k not in ('image','source','output','frame_sha256','shared_output_fd')}
def stats(rows,key='v65'):
    values=[row[key] for row in rows if key in row]
    timed=[row for row in values if 'native_elapsed_ns' in row]
    wall=sum(row['wall_elapsed_ns'] for row in values)
    native=sum(row['native_elapsed_ns'] for row in timed)
    timed_wall=sum(row['wall_elapsed_ns'] for row in timed)
    return dict(retained_receipts=len(values),native_clock_count=len(timed),wall_ns=wall,native_ns=native,
                wall_minus_native_for_timed_ns=timed_wall-native,
                wall_without_native_clock_ns=wall-timed_wall,
                statuses=dict(Counter(row.get('status') for row in values)))

old=defaultdict(list)
with gzip.open(PREVIOUS/'matched-native-receipts.jsonl.gz','rt') as stream:
    for line in stream:
        row=json.loads(line);old[identity(row['phase'],row['new'])].append(row)
selected=[];phases=[];ledger=[];unmatched=[];bindings=[];references=[];commands=[];owners=[]
(OUT/'selected-originals').mkdir(exist_ok=True)
with zipfile.ZipFile(ZIP) as z:
    members=set(z.namelist())
    def read(name,save=False):
        raw=z.read(name);selected.append(dict(member=name,bytes=len(raw),sha256=sha(raw)))
        if save:(OUT/'selected-originals'/name.removeprefix(P).replace('/','__')).write_bytes(raw)
        return json.loads(raw),raw
    cold,cold_raw=read('hia-cold.json',True)
    index,_=read(P+'phase-index.json',True)
    assert cold['source_manifest']==frozen['source_closure']
    owner=cold['process_owner'];start=next(e['monotonic_ns'] for e in owner['events'] if e['kind']=='qualification_started')
    for item in index['phases']:
        name=item['family']+'-'+item['compiler_label']
        row=dict(phase=name,family=item['family'],label=item['compiler_label'],state=item['state'])
        if item['state']=='completed':
            proc,_=read(P+'phase-'+name+'.process.json',True)
            report,raw=read(P+'phase-'+name+'.json')
            assert sha(raw)==proc['report_sha256']
            archive=proc['raw_artifacts'];member='hia-cold.cold/'+archive['archive'].split('/hia-cold.cold/',1)[1]
            packed_raw=z.read(member);assert sha(packed_raw)==archive['archive_sha256']
            row.update(status=report['status'],checks=len(report['checks']),all_checks_true=all(v is True for v in report['checks'].values()),returncode=proc['returncode'],worker_pid=proc['worker_pid'],started_ns=proc['started_monotonic_ns'],completed_ns=proc['completed_monotonic_ns'],phase_process_wall_ns=proc['completed_monotonic_ns']-proc['started_monotonic_ns'],phase_body_ns=report['elapsed_ns'],archive=archive,archive_digest_verified=True)
            assert row['all_checks_true'] and row['status']=='PASS' and row['returncode']==0
            row['v64_phase_wall_ns']=v64_phases[name]['wall_ns']
            row['v63_phase_wall_ns']=v63_phases[name]['completed_ns']-v63_phases[name]['started_ns']
            row['all_check_counts_equal_v63_v64']=row['checks']==v64_phases[name]['checks']==v63_phases[name]['checks']
            with zipfile.ZipFile(BytesIO(packed_raw)) as packed:
                manifest_raw=packed.read(M);assert sha(manifest_raw)==archive['manifest_sha256']
                manifest=json.loads(manifest_raw);files=manifest['files'];assert set(packed.namelist())==set(files)|{M}
                def internal(path):
                    raw=packed.read(path);assert len(raw)==files[path]['bytes'] and sha(raw)==files[path]['sha256']
                    selected.append(dict(archive=member,member=path,bytes=len(raw),sha256=sha(raw)))
                    return json.loads(raw)
                for path in sorted(files):
                    if path.endswith('.receipt.json'):
                        receipt=internal(path)
                        if 'wall_elapsed_ns' not in receipt:continue
                        record=dict(phase=name,member=path,v65=receipt)
                        request_name=path.removesuffix('.receipt.json')+'.request.json'
                        request=internal(request_name) if request_name in files else None
                        if request is not None:record['request']=request
                        choices=old.get(identity(name,receipt),[]) if 'case' in receipt and 'input_sha256' in receipt else []
                        if len(choices)==1:
                            previous=choices[0];record['v64']=previous['new']
                            if 'old' in previous:record['v63']=previous['old']
                            fields=('input_bytes','input_sha256','image_sha256','artifact_sha256','status','format','transport','runner_sha256','result_u64','core_u32','output_sha256','source_unchanged','output_unchanged','limits','workspace_header')
                            differences={k:{'v64':previous['new'].get(k),'v65':receipt.get(k)} for k in fields if previous['new'].get(k)!=receipt.get(k)}
                            if request is not None and 'request' in previous:
                                record['same_semantic_request']=request_semantics(request)==request_semantics(previous['request'])
                                record['same_request_frame_digest']=request.get('frame_sha256')==previous['request'].get('frame_sha256')
                                if not record['same_semantic_request']:differences['request_semantics']={'v64':request_semantics(previous['request']),'v65':request_semantics(request)}
                            record['binding_differences']=differences
                            if differences:bindings.append(dict(phase=name,member=path,differences=differences))
                        else:unmatched.append(dict(phase=name,member=path,case=receipt.get('case'),prior_choices=len(choices),reason='no complete unambiguous payload identity' if not choices else 'ambiguous prior identity'))
                        ledger.append(record)
                    elif path.endswith('.command.json'):
                        value=internal(path)
                        if 'wall_elapsed_ns' in value:commands.append(dict(phase=name,member=path,receipt=value))
                    elif path.endswith('/owner.json'):
                        value=internal(path)
                        begin=next(e['monotonic_ns'] for e in value['events'] if e['kind']=='qualification_started')
                        owners.append(dict(phase=name,member=path,window_ns=value['cleanup']['started_ns']+value['cleanup']['elapsed_ns']-begin))
        else:
            prefix=P+'phase-runs/'+name+'/'
            pending_files=sorted(n for n in members if n.startswith(prefix))
            requests={n.removesuffix('.request.json'):n for n in pending_files if n.endswith('.request.json')}
            receipts={n.removesuffix('.receipt.json'):n for n in pending_files if n.endswith('.receipt.json')}
            retained=[]
            for path in receipts.values():
                receipt,_=read(path)
                retained.append({k:receipt.get(k) for k in ('case','status','input_bytes','input_sha256','image_sha256','native_elapsed_ns','wall_elapsed_ns')})
            outstanding=[]
            for key in sorted(requests.keys()-receipts.keys()):
                request,_=read(requests[key],True);outstanding.append(dict(member=requests[key],request=request))
            row.update(request_files=len(requests),receipt_files=len(receipts),retained_receipts=retained,request_without_receipt=outstanding,raw_files=len(pending_files),raw_bytes=sum(z.getinfo(n).file_size for n in pending_files),nonempty_stderr=[n for n in pending_files if n.endswith('.stderr.log') and z.getinfo(n).file_size],receipt_file_count_is_not_call_count=True)
        phases.append(row)
    for old_ref in prior['reference_workers']:
        family=old_ref['family'];value,_=read(P+'reference-'+family+'.worker.json')
        references.append(dict(family=family,v65_wall_ns=value['wall_elapsed_ns'],v64_wall_ns=old_ref['wall_ns'],reference_sha256=value['reference_sha256'],same_reference_sha_v63_v64=value['reference_sha256']==old_ref['reference_sha256'],before_B0=value['before_B0']))
    generations=[]
    for label in ['B0','B1','B2','B3','M1','M2','M3']:
        receipt,_=read(P+label+'.receipt.json',True);image=z.read(P+label+('.so' if label=='B0' else '.image.bin'))
        assert sha(image)==receipt['artifact_sha256' if label=='B0' else 'produced_sha256']
        old_gen=next(r for r in prior['actual_compiler_artifacts'] if r['label']==label)
        generations.append(dict(label=label,image_sha256=sha(image),image_bytes=len(image),source_sha256=receipt.get('source_sha256'),image_same_v64=sha(image)==old_gen['sha256'],v65_native_ns=receipt.get('native_elapsed_ns'),v64_native_ns=old_gen.get('native_elapsed_ns'),v65_wall_ns=receipt.get('wall_elapsed_ns'),v64_wall_ns=old_gen.get('wall_elapsed_ns')))
        if label=='B0':seed=receipt
    artifact_inventory=dict(members=len(members),raw_outer_bytes=sum(m.file_size for m in z.infolist()),final_nested_report_present='hia-cold.cold/qualification.json' in members)

completed=[row for row in phases if row['state']=='completed']
paired64=[row for row in ledger if 'v64' in row and not row['binding_differences']]
paired63=[row for row in paired64 if 'v63' in row]
families=[]
for family in dict.fromkeys(row['family'] for row in completed):
    rows=[row for row in paired64 if row['phase'].rsplit('-',1)[0]==family]
    ps=[row for row in completed if row['family']==family]
    families.append(dict(family=family,matched_v64=stats(rows,'v64'),matched_v65=stats(rows),matched_v63=stats([r for r in rows if 'v63' in r],'v63'),phase_wall_v63_ns=sum(r['v63_phase_wall_ns'] for r in ps),phase_wall_v64_ns=sum(r['v64_phase_wall_ns'] for r in ps),phase_wall_v65_ns=sum(r['phase_process_wall_ns'] for r in ps),phase_body_ns=sum(r['phase_body_ns'] for r in ps),commands_wall_ns=sum(r['receipt']['wall_elapsed_ns'] for r in commands if r['phase'].rsplit('-',1)[0]==family),cli_owner_windows_ns=sum(r['window_ns'] for r in owners if r['phase'].rsplit('-',1)[0]==family)))
critical=[]
for row in prior['unchanged_critical_sources']:
    path=row['path'];current=cold['source_manifest'][path]
    critical.append(dict(path=path,v64_sha256=row['v64_sha256'],v65_sha256=current,unchanged=current==row['v64_sha256']))
seed_bindings={field:dict(v63=values['v63'],v64=values['v64'],v65=seed.get(field),same_v64=seed.get(field)==values['v64']) for field,values in prior_comparison['seed_bindings'].items()}
local_cold=json.loads((LOCAL/'cold.json').read_bytes());local_index=json.loads((LOCAL/'cold.cold/qualification.evidence/phase-index.json').read_bytes())
local_phases=[]
for row in local_index['phases']:
    name=row['family']+'-'+row['compiler_label'];item=dict(phase=name,state=row['state'])
    if row['state']=='completed':
        receipt=json.loads((LOCAL/'cold.cold/qualification.evidence'/('phase-'+name+'.process.json')).read_bytes())
        item.update(started_ns=receipt['started_monotonic_ns'],completed_ns=receipt['completed_monotonic_ns'],process_wall_ns=receipt['completed_monotonic_ns']-receipt['started_monotonic_ns'])
    local_phases.append(item)
summary=dict(schema='hepta.hia.v65-independent-original-cold-comparison.v1',scope='READ_ONLY_ORIGINAL_RECEIPTS_NOT_CONTROLLED_PERFORMANCE_EXPERIMENT',inputs=inputs,
    github=dict(run_id=42995591456,artifact_id=13842954320,commit='eef68334b078eb9fcc414f441c35687e33585bba',status=cold['status'],wall_ns=cold['wall_elapsed_ns'],qualification_limit=cold['qualification_wall_limit_seconds'],outer_checks=cold['checks'],owner=owner,source_manifest_exact_stage4=True,source_files=len(cold['source_manifest']),**artifact_inventory),
    completed_phases=len(completed),completed_checks=sum(row['checks'] for row in completed),all_completed_counts_equal_prior=all(row['all_check_counts_equal_v63_v64'] for row in completed),phase_index_exceptions=index['exceptions'],phase_records=phases,reference_workers=references,critical_sources=critical,seed_bindings=seed_bindings,generations=generations,
    pre_first_phase_ns=min(row['started_ns'] for row in completed)-start,v64_pre_first_phase_ns=prior['comparison_to_v63']['v64_pre_first_phase_ns'],v63_pre_first_phase_ns=prior['comparison_to_v63']['v63_pre_first_phase_ns'],first_to_last_completed_phase_ns=max(row['completed_ns'] for row in completed)-min(row['started_ns'] for row in completed),
    v65_all_retained_receipts=stats(ledger),paired_v64=stats(paired64,'v64'),paired_v65=stats(paired64),triple_v63=stats(paired63,'v63'),triple_v64=stats(paired63,'v64'),triple_v65=stats(paired63),unmatched=unmatched,binding_differences=bindings,families=families,
    local=dict(report=pin(LOCAL/'cold.json'),status=local_cold['status'],wall_ns=local_cold['wall_elapsed_ns'],source_exact_stage4=local_cold['source_manifest']==frozen['source_closure'],phase_records=local_phases),
    limitations=['Native elapsed is entry wall time, not a CPU sample.', 'Receipt wall excludes initial framing/hash/write and some final readback/receipt writing; wall minus native is not total host overhead.', 'Concurrent two-worker sums are not cold wall-time contributions.', 'Pending phase retained filenames can be overwritten by existing labels; they do not count every actual invocation.', 'Archive hashes and selected internal JSON hashes were checked; full recursive bytes/mode/CRC verification belongs to the separate root audit.', 'Old v63/v64 clocks come from the pinned previous raw-verified ledger; no commit-message claim is used as evidence.', 'These are distinct GitHub hosts/runs. Correlation does not establish CPU contention, frequency, hardware or an implementation change as a cause.'],new_native_invocations=0,whole_stack_closed=False)
assert pin(ZIP)==inputs['github_zip']
write('report.json',summary);write('selected-json-ledger.json',selected)
with gzip.GzipFile(filename='',mode='wb',fileobj=(OUT/'paired-receipts.jsonl.gz').open('wb'),mtime=0) as stream:
    for row in ledger:stream.write(json.dumps(row,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({key:summary[key] for key in ['completed_phases','completed_checks','pre_first_phase_ns','v64_pre_first_phase_ns','v63_pre_first_phase_ns','v65_all_retained_receipts','paired_v64','paired_v65','triple_v63','triple_v64','triple_v65']},indent=2))
print('unmatched',len(unmatched),'binding differences',len(bindings),'all reference exact',all(row['same_reference_sha_v63_v64'] for row in references))
