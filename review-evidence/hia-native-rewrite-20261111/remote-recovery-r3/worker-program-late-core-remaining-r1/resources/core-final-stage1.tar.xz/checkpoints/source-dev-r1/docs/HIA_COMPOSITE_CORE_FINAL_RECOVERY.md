# Native final Core snapshot visitor and late gate: recovery draft r1

This is a new development revision authored after the executor replacement.
The pre-switch proposal and helper test package are not present in this
workspace. Known source identities are historical observations, not claims
that missing raw evidence was recovered. No native execution or cold
qualification has yet been performed for this new visitor.

## Retained public behavior

The exact reference is hepta/hia_program.py, 45,247 bytes, observed SHA-256
76a222745e13fe29825a661be206243f137ada7b57292b07ab7513a40146fb92.
The fixed limits remain 262,144 value nodes, depth 64 with the root at depth
zero, and 8,388,608 compact JSON bytes.

The caller-owned final Core first passes _bounded_detached_snapshot. It visits
container values in preorder, left to right in list order and dictionary
insertion order. Dictionary keys do not count as snapshot nodes. Every node
increments visited and decrements queued; the snapshot/depth check happens
before the current container's complete child arity is queued.

Only after that snapshot succeeds does _structure count compact
ensure_ascii=False JSON bytes. That second traversal charges all dictionary
keys first and visits values right to left. On the actual fixed pipeline's
validated scalar UTF-8/integer/list/map/null/bool domain, snapshot acceptance
already establishes all node, depth, and queue limits. There are no foreign
objects, cycles, non-string map keys or unpaired surrogates in that domain.
An input integer with at most the original input byte limit has fewer than
4 * MAX_BYTES significant bits. Native integer tokens contain only uint64.
The remaining observable size error is therefore the same byte-budget text
regardless of the byte traversal order; total actual native serialized bytes
are sufficient after snapshot admission.

This argument does not apply to arbitrary in-process Python objects, forged
private helper frames, replacement source registries, or invalid string
encodings. The fixed driver must retain the same original public source
admission and canonical detached source order. Canonical-byte equality alone
does not establish intermediate dictionary insertion order.

The final late status is:
- 0: the snapshot and byte gates admit.
- 1: E_HIA_LIMIT, caller-owned tree exceeds snapshot budget.
- 2: E_HIA_LIMIT, caller-owned tree exceeds queued-node budget.
- 3: E_HIA_LIMIT, program exceeds byte budget before encoding.

All semantic owners and the original outer function/block inventory gate run
before this final language decision. A later function's semantic refusal still
wins over an earlier completed function's oversized eventual Core. Generic
transport errors remain BAD, not a successful language summary.

## Independent composition proof

Let A be the cumulative child arities of containers already visited in
snapshot preorder. Then visited + queued = 1 + A. Visiting a queued node leaves
this sum unchanged. Queuing a container's children increases it by precisely
that container's arity. A queued-budget failure is thus the first container
which makes A exceed M - 1. A visited-node overflow cannot precede that check
on a finite acyclic tree. At a too-deep node, depth is checked before charging
that node's own arity.

For a complete object whose eventual root depth is two, record:
- rootKind, using null0/bool1/int2/string4/list5/map6.
- nodesCap = min(actual value-node count, M + 1).
- firstDepthPrefix = the arity prefix before the first relative-depth >62
  node, saturated at M + 1; UINT64_MAX means no witness.

For the outer traversal let P be the arity prefix before an opaque object's
root. Its root is already included in the parent's arity. Add nodesCap - 1
to the arity prefix, with saturation, and add nodesCap to the visited node
count. If no earlier depth witness exists, its witness becomes P plus its
firstDepthPrefix, again saturated. The depth-two restriction is material:
the prefix already contains enclosing container arities, so a capped object's
omitted excess cannot change the final capped summary or first refusal.
Every repeated reference contributes independently; no alias is memoized away.

For the complete outer summary, depth wins exactly when the first witness
prefix is at most M - 1. Otherwise a node count above M means the earlier
queue refusal. Otherwise the snapshot admits. This preserves both the code
and the complete error message, including a deep container whose own arity
would also overflow. It does not attempt to recreate Python temporary objects
or allocation history.

The development proof script is explicitly reconstructed from visible
context and must be rerun fresh. The old session did not produce a retained
terminal receipt, so no pre-switch proof PASS is counted.

## Complete native ownership and memory

One HIA image implements initialization, exact producer framing, generic token
validation, source-reference traversal, duplicate map-key membership, counts,
opaque summary continuation, root inventory and final admission. Python only
combines fixed authoring text; it receives no input Core.

The visitor retains a current copied producer frame, active container frames,
active dictionary keys and source offsets. It does not build a full Core.
Map arities use remaining pairs and a separate key/value parity, so UINT64_MAX
pairs never overflow a doubled token count or cause allocation from a mere
declared arity. Dictionary membership uses a dynamically grown native bucket
table with exact byte equality. GROW allocates by actually encountered frames
and keys. Closing a container reclaims its frame, keys and old table storage.
Inline keys are copied because the producer buffer is reusable; source keys
refer to the same immutable issued source lease.

Memory is proportional to active depth, active map keys and their copied inline
bytes, plus fixed framing. There is no new total output/node/depth/call quota.
Diagnostic counters alone saturate at M + 1; the full actual stream is still
validated after a potential language-limit witness. Compiler limits remain
128 functions, 1536 blocks, 8192 instructions, 256 blocks per function and
16 parameters per block. Actual compilation must establish that the source
fits them; this draft does not claim that result.

## Private stream ABI

Words are little-endian uint64. External entry is RWW; an immediate
borrow.read turns the second lease read-only for all internal calls. The
three arguments are command/producer bytes, the same issued SourceIndexLease,
and a private mutable workspace. Minimum workspace is 131,328 bytes.

BEGIN, 80 bytes:
[HIACSB01, lease, stream, producerMagic, producerAction, request, serial,
 slots, mode, 0]

Mode 1 is one complete object at relative depth zero, intended for later
depth-two placement. Mode 2 is the complete outer program at absolute depth
zero. The driver supplies the actual private producer identities. No source
field selects or authenticates an executable.

CONTINUE, 32 bytes:
[HIACSC01, lease, stream, lastEventSequence]

The original producer frame remains unchanged:
[producerMagic, action, producerSequence, final, serial, slots, request,
 payloadBytes] followed by the full payload. It is 64 through 65536 bytes.
Producer sequence advances only after that entire chunk is consumed.
A chunk is copied once before pumping. Every GROW replays CONTINUE against
the retained chunk and offsets; it never calls the producer twice.

ObjectToken kinds are source/opaque reference0, UTF-8 string1, uint64 integer2,
bool3, null4, list5 and map6. Containers are preorder and must complete exactly.
The existing packet/index issuer supplies SourceIndexLease HIASIL01. That
lease's shape, bounds, exact framing and node membership are checked. Its
private issuance and immutability are a fixed-driver obligation, not
authentication for arbitrary externally supplied arena bytes.

A high-half reference is legal only as a value at depth two in mode 2.
The visitor returns an opaque summary request. The fixed coordinator supplies
the complete result of the actual earlier mode-1 visitor bound to the same
actual object whose native JSON count/hash is retained.

Opaque reply, 128 bytes:
[HIACSO01, lease, stream, lastEventSequence, handle, rootKind, nodesCap,
 firstDepthPrefix, actualJsonBytes, digest0, digest1, digest2, digest3,
 0, 0, 0]

The handle and event sequence must match the pending request. The root kind
is map6. This is an internal issued summary, not an external registration API.
A nonce does not authenticate replacement summaries or output bytes.

The event starts at offset1024, occupies128 bytes and returns1152:
[HIACSE01, action, status, lease, stream, nextProducerSequence,
 eventSequence, rootKind, nodesCap, firstDepthPrefix, growNeeded,
 opaqueHandle, opaqueQuerySequence, snapshotLateStatus, rootKeyMask,
 rootUnknownKey]

Actions: READY1, GROW3, OPAQUE4, DONE5, REFUSED6, ADMITTED7.
Status: active1, complete2, permanently refused3.
Every valid event increments eventSequence once with overflow refused.
A BAD return (0xfffffffd) dominates stale event bytes. A driver discards the
lease on every BAD; an arbitrarily short workspace cannot safely store poison.

Mode1 DONE returns no late decision. Mode2 DONE reports only snapshot status
0,1 or2. The byte gate is a separate later call.

## Root inventory and original transport-error timing

Bits0 through10 are name, params, returns, effects, entry, blocks, return_loans,
schema, module, exports, functions. rootUnknownKey is0 or1. The visitor reports
the complete actual root inventory; it does not reject missing/extra envelope
fields or reinterpret their values.

The function controller checks map6, unknown0 and mask63 or127 only after the
old complete stream then state-mirror point. The outer controller checks map6,
unknown0 and mask1920 after its complete stream and before the final snapshot
gate. This preserves the retained old bridge timing. Duplicate keys and
malformed token frames remain streaming protocol refusals as before.

## Final byte admission

After mode2 DONE, ADMIT is exactly80 bytes:
[HIACSA01, lease, stream, lastEventSequence, actualCompleteJsonBytes,
 digest0, digest1, digest2, digest3, 0]

It requires the still-complete, not-yet-admitted state with no pending producer,
growth or opaque work. The actual native serializer/hash count belongs to
the coordinator-owned output lease. It is never a count copied from user JSON.
The reply is action7/status2 with eventSequence+1. Prior snapshot status1 or2
wins over the byte budget. Otherwise bytes>8388608 returns late status3.
Repeated ADMIT or any replay after DONE/ADMITTED poisons the session.

The driver still must run canonicalization and the complete primitive Core
verifier after these gates. This component alone is not a verified-program
receipt and does not close the whole compiler/runtime/install stack.
