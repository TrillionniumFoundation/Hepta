"""Fresh actual visitor/issuer smoke; references never run in the forwarder."""
from contextlib import ExitStack
import ctypes
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import resource
import struct
import sys
import time
import traceback
from unittest.mock import patch

from native_harness import VisitorImage, Session, BAD, MAX, MAGIC
from hepta import hia_program as reference
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import ObjectTokenDecoder, detached_packet_index

resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20, 1024 << 20))
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'development/smoke-visitor-r1'
OUT.mkdir(exist_ok=False)
source = ROOT / 'dependencies/packet-issuer/tests/test_hia_composite_packet_json.py'
source_raw = source.read_bytes()
assert sha256(source_raw).hexdigest() == 'a3b928ae40bd9730b0a32c79336f53c9b769138d30e229b6dd4e5184a4df4746'
spec = importlib.util.spec_from_loader('core_actual_packet_issuer', loader=None, origin=str(source))
issuer_module = importlib.util.module_from_spec(spec)
issuer_module.__file__ = str(source)
sys.modules[spec.name] = issuer_module
exec(compile(source_raw, str(source), 'exec'), issuer_module.__dict__)
assert source.read_bytes() == source_raw
issuer = issuer_module.ActualPacketJson(OUT / 'actual-issuer')
native = VisitorImage(ROOT / 'development/compile-visitor-r1/composite-core-final.manifest.json',
                      ROOT / 'examples/hia_bootstrap/composite_core_final.hiaasm', OUT / 'actual-visitor')
cases, active, next_stream = [], None, 0
started = time.monotonic_ns()


def source_for(value, label):
    raw = transport(value)
    extent, header, data, index, state = issuer.encode(label, raw)
    assert extent == 64 + len(data) and header[5] == len(raw)
    at = (64 + len(raw) + 7) & ~7
    wire = struct.pack('<8Q', MAGIC(b'HIASIL01'), len(raw), len(index), 64, at, at + len(index), 0, 0)
    wire += raw + b'\0' * (at - 64 - len(raw)) + index
    _, nodes = detached_packet_index(raw)
    (OUT / (label + '.packet')).write_bytes(raw)
    (OUT / (label + '.native.json')).write_bytes(data)
    return wire, data, nodes


def token(kind, value=0):
    return struct.pack('<2Q', kind, value)


def string(value):
    raw = value.encode('utf8')
    return token(1, len(raw)) + raw


def tokens(value):
    if value is None: return [token(4)]
    if type(value) is bool: return [token(3, int(value))]
    if type(value) is int: return [token(2, value)]
    if type(value) is str: return [string(value)]
    if type(value) is list: return [token(5, len(value))] + [item for child in value for item in tokens(child)]
    if type(value) is dict:
        return [token(6, len(value))] + [item for key, val in value.items() for item in [string(key)] + tokens(val)]
    raise TypeError(type(value))


def expected(value, limit):
    pending, count, arity, first = [(value, 0)], 0, 0, MAX
    while pending:
        node, depth = pending.pop()
        count = min(262145, count + 1)
        if depth > limit and first == MAX: first = arity
        if type(node) in (list, dict):
            children = node if type(node) is list else list(node.values())
            arity = min(262145, arity + len(children))
            pending.extend((child, depth + 1) for child in reversed(children))
    mask, unknown = 0, 0
    keys = ('name', 'params', 'returns', 'effects', 'entry', 'blocks', 'return_loans',
            'schema', 'module', 'exports', 'functions')
    if type(value) is dict:
        for key in value:
            if key in keys: mask |= 1 << keys.index(key)
            else: unknown = 1
    return count, first, mask, unknown


def absent(*args, **kwargs):
    raise AssertionError('host snapshot/structure/token decoder entered actual forwarding')


def forward(session, pieces):
    with ExitStack() as forbidden:
        for owner, name in ((reference, '_bounded_detached_snapshot'), (reference, '_structure'),
                            (ObjectTokenDecoder, 'feed'), (json, 'loads')):
            forbidden.enter_context(patch.object(owner, name, new=absent))
        result = session.initialize()
        assert result[0] == 1152 and result[1][1] == 1
        for i, piece in enumerate(pieces):
            result = session.send(piece, final=i + 1 == len(pieces), exact=True)
            assert result[0] == 1152, (result, i)
    return result


try:
    empty, _, _ = source_for(None, 'empty-source')
    atoms = [None, True, False, 0, (1 << 64) - 1, '', '中\0😀', [], {}, [[], {}, 1],
             {'name': 'f', 'params': [], 'returns': [], 'effects': [], 'entry': 'b0', 'blocks': []}]
    for i, value in enumerate(atoms):
        next_stream += 1
        active = Session(native, empty, stream=next_stream)
        result = forward(active, tokens(value))
        assert result[1][1:3] == (5, 2)
        exp = expected(value, 64)
        assert (result[1][8], result[1][9], result[1][14], result[1][15]) == exp, (i, result, exp)
        assert result[1][13] == 0
        raw = json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode()
        admitted = active.admit(len(raw), sha256(raw).digest())
        assert admitted[1][1] == 7 and admitted[1][13] == 0
        assert active.call(active.initial)[0] == BAD
        cases.append({'case': 'inline-' + str(i), 'entries': active.calls, 'grows': active.grows,
                      'exact_summary': True, 'host_semantics_disabled_during_forwarding': True})
        active.close()
        active = None

    value = atoms[-1]
    lease, serialized, nodes = source_for(value, 'function-source')
    next_stream += 1
    active = Session(native, lease, stream=next_stream, mode=1)
    result = forward(active, [token(0, 0)])
    assert (result[1][8], result[1][9], result[1][14], result[1][15]) == expected(value, 62)
    object_summary = result[1]
    cases.append({'case': 'actual-source-reference-function', 'entries': active.calls, 'grows': active.grows,
                  'actual_native_source_index': True, 'exact_summary': True})
    active.close()
    active = None

    outer = {'schema': 'hepta.hia.program.v8', 'module': 'm', 'exports': [], 'functions': [value, value]}
    handle = 1 << 63
    prefix = [token(6, 4), string('schema'), string(outer['schema']), string('module'), string('m'),
              string('exports'), token(5), string('functions'), token(5, 2), token(0, handle), token(0, handle)]
    next_stream += 1
    active = Session(native, empty, stream=next_stream)
    assert active.initialize()[1][1] == 1
    result = active.send(b''.join(prefix), final=True)
    query_count = 0
    while result[0] != BAD and result[1][1] == 4:
        assert result[1][11] == handle
        result = active.summary_reply(handle, object_summary[7], object_summary[8], object_summary[9],
                                      len(serialized), sha256(serialized).digest())
        query_count += 1
    assert result[0] == 1152 and result[1][1:3] == (5, 2) and query_count == 2
    assert (result[1][8], result[1][9], result[1][14], result[1][15]) == expected(outer, 64)
    _, serialized_outer, _ = source_for(outer, 'whole-native-json-for-admission')
    result = active.admit(len(serialized_outer), sha256(serialized_outer).digest())
    assert result[1][1] == 7 and result[1][13] == 0
    cases.append({'case': 'opaque-repeated-composition', 'entries': active.calls, 'grows': active.grows,
                  'actual_native_subtree_summary': True, 'actual_native_JSON_count': True,
                  'digest_scope': 'test reference SHA; this owner does not implement hash algorithm',
                  'exact_summary': True})
    active.close()
    active = None
    summary = {'scope': 'FRESH_POST_RECOVERY_ACTUAL_VISITOR_ISSUER_DEVELOPMENT_NOT_COLD',
               'status': 'PASS', 'cases': cases, 'visitor_entries': native.entries,
               'issuer_entries': issuer.entries, 'wall_elapsed_ns': time.monotonic_ns() - started,
               'no_whole_driver_claim': True}
except BaseException as exc:
    traceback.print_exc()
    summary = {'status': 'FAIL', 'completed_cases': cases, 'class': type(exc).__name__, 'error': str(exc),
               'visitor_entries': native.entries, 'issuer_entries': issuer.entries}
    raise
finally:
    if active is not None: active.close()
    native.close()
    issuer.close()
    assert source.read_bytes() == source_raw
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
