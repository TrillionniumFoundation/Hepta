"""Compile the new visitor with exact recovered B3; development only."""
from hashlib import sha256
import json
from pathlib import Path

from tools.qualify_hia_selfhost import compile_stage

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / 'checkpoints/source-dev-r1'
DEST = ROOT / 'development/compile-visitor-r1'
COMPILER = ROOT / 'dependencies/f50-B3.image.bin'

manifest_raw = (SNAPSHOT / 'source.json').read_bytes()
manifest = json.loads(manifest_raw)
frozen = {SNAPSHOT / 'source.json': manifest_raw}
for row in manifest['files']:
    raw = (SNAPSHOT / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
    assert (ROOT / row['path']).read_bytes() == raw
    frozen[SNAPSHOT / row['path']] = raw
    frozen[ROOT / row['path']] = raw
for row in manifest['dependencies']:
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
    frozen[Path(row['path'])] = raw
assert sha256(frozen[COMPILER]).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
DEST.mkdir(exist_ok=False)
summary = None
try:
    source = SNAPSHOT / 'examples/hia_bootstrap/composite_core_final.hiaasm'
    output, receipt = compile_stage(DEST, 'composite-core-final', COMPILER, frozen[source])
    image = output.read_bytes()
    assert receipt['input_sha256'] == sha256(frozen[source]).hexdigest()
    assert receipt['artifact_sha256'] == sha256(frozen[COMPILER]).hexdigest()
    assert receipt['produced_sha256'] == sha256(image).hexdigest()
    assert receipt['produced_bytes'] == len(image) == receipt['core_u32']
    row = {'schema': 'hepta.hia.composite-core-final-native.v1',
           'source_path': str(source), 'source_sha256': sha256(frozen[source]).hexdigest(),
           'image_path': str(output), 'image_sha256': sha256(image).hexdigest(),
           'compiler_sha256': sha256(frozen[COMPILER]).hexdigest()}
    for path, raw in frozen.items():
        assert path.read_bytes() == raw
    (DEST / 'composite-core-final.manifest.json').write_text(json.dumps(row, indent=2, sort_keys=True) + '\n')
    summary = {'status': 'PASS', 'scope': 'ACTUAL_SOURCE_BOUND_DEVELOPMENT_COMPILE_NOT_COLD',
               'component': row, 'source_manifest_sha256': sha256(manifest_raw).hexdigest(),
               'receipt': receipt, 'all_before_after_bytes_unchanged': True,
               'whole_stack_closed': False}
except BaseException as exc:
    summary = {'status': 'FAIL', 'scope': 'ACTUAL_SOURCE_BOUND_DEVELOPMENT_COMPILE_NOT_COLD',
               'class': type(exc).__name__, 'error': str(exc)}
    raise
finally:
    for path, raw in frozen.items():
        assert path.read_bytes() == raw
    (DEST / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
