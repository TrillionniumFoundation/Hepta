"""Independent actual visitor boundaries and retained public first errors.

All summaries, opaque joins and late decisions under test are HIA output.
Python creates test fixtures and invokes the original snapshot oracle only
outside the forbidden-host forwarding window.
"""
from contextlib import ExitStack
import ast
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import random
import resource
import struct
import sys
import time
import traceback
from unittest.mock import patch

from native_harness import VisitorImage, Session, BAD, MAX, MAGIC
from hepta import hia_program as reference
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import ObjectTokenDecoder, detached_packet_index

resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20, 1024 << 20))
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'development/boundaries-visitor-r1'
OUT.mkdir(exist_ok=False)
reference_raw = Path(reference.__file__).read_bytes()
assert sha256(reference_raw).hexdigest() == '76a222745e13fe29825a661be206243f137ada7b57292b07ab7513a40146fb92'
source = ROOT / 'dependencies/packet-issuer/tests/test_hia_composite_packet_json.py'
source_raw = source.read_bytes()
assert sha256(source_raw).hexdigest() == 'a3b928ae40bd9730b0a32c79336f53c9b769138d30e229b6dd4e5184a4df4746'
spec = importlib.util.spec_from_loader('core_boundary_packet_issuer', loader=None, origin=str(source))
issuer_module = importlib.util.module_from_spec(spec)
issuer_module.__file__ = str(source)
sys.modules[spec.name] = issuer_module
exec(compile(source_raw, str(source), 'exec'), issuer_module.__dict__)
assert source.read_bytes() == source_raw
issuer = issuer_module.ActualPacketJson(OUT / 'actual-issuer')
native = VisitorImage(ROOT / 'development/compile-visitor-r1/composite-core-final.manifest.json',
                      ROOT / 'examples/hia_bootstrap/composite_core_final.hiaasm', OUT / 'actual-visitor')
smoke_source = (ROOT / 'development/smoke_visitor_r1.py').read_bytes()
smoke_ast = ast.parse(smoke_source)
for node in smoke_ast.body:
    if isinstance(node, ast.FunctionDef) and node.name in ('source_for', 'token', 'string', 'tokens', 'expected', 'absent'):
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<frozen-fixture-and-reference-helpers>', 'exec'), globals())
cases, active, stream_number = [], None, 0
started = time.monotonic_ns()


def old_late(value):
    try:
        detached = reference._bounded_detached_snapshot(value)
        reference._structure(detached)
        return 0, None
    except reference.HIAProgramRejected as exc:
        text = str(exc)
        messages = ('caller-owned tree exceeds snapshot budget',
                    'caller-owned tree exceeds queued-node budget',
                    'program exceeds byte budget before encoding')
        assert exc.code == 'E_HIA_LIMIT'
        status = next((i + 1 for i, message in enumerate(messages) if text.endswith(message)), None)
        assert status is not None, (exc.code, text)
        return status, (exc.code, text)


def chunks(items, limit=65472):
    pending = bytearray()
    for item in items:
        assert len(item) <= limit
        if pending and len(pending) + len(item) > limit:
            yield bytes(pending)
            pending.clear()
        pending.extend(item)
    if pending:
        yield bytes(pending)


def protected():
    stack = ExitStack()
    for owner, name in ((reference, '_bounded_detached_snapshot'), (reference, '_structure'),
                        (ObjectTokenDecoder, 'feed'), (json, 'loads')):
        stack.enter_context(patch.object(owner, name, new=absent))
    return stack


def test_value(label, value, *, mode=2, from_source=True, split=65472):
    global active, stream_number
    wanted = expected(value, 62 if mode == 1 else 64)
    late, error = old_late(value) if mode == 2 else (0, None)
    lease, actual_json, nodes = source_for(value if from_source else None, label + '-source')
    if not from_source:
        # An independent actual native serializer supplies the complete count.
        _, actual_json, _ = source_for(value, label + '-actual-json')
    parts = [token(0, 0)] if from_source else list(chunks(tokens(value), split))
    stream_number += 1
    active = Session(native, lease, stream=stream_number, mode=mode)
    with protected():
        assert active.initialize()[1][1] == 1
        for i, part in enumerate(parts):
            result = active.send(part, final=i == len(parts) - 1, exact=True)
            assert result[0] == 1152, (label, i, result)
        assert result[1][1:3] == (5, 2)
        done = result[1]
        if mode == 2:
            result = active.admit(len(actual_json), sha256(actual_json).digest())
            assert result[1][1:3] == (7, 2)
    assert (done[8], done[9], done[14], done[15]) == wanted, (label, done, wanted)
    assert result[1][13] == late, (label, result, error)
    if mode == 1:
        assert done[13] == 0
    row = {'case': label, 'mode': mode, 'source_reference': from_source, 'chunks': len(parts),
           'nodes_cap': done[8], 'first_depth_prefix': done[9], 'root_mask': done[14],
           'root_unknown': done[15], 'late_status': late, 'reference_error': error,
           'actual_native_JSON_bytes': len(actual_json), 'visitor_entries': active.calls,
           'grows': active.grows, 'full_summary_exact': True,
           'host_structure_owners_disabled_during_forwarding': True}
    cases.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
    active.close()
    active = None
    return done, actual_json


def chain(depth):
    value = 0
    for _ in range(depth): value = [value]
    return value


def function(payload):
    return {'name': 'f', 'params': [], 'returns': [], 'effects': [], 'entry': 'b0', 'blocks': payload}


def outer(functions):
    return {'schema': 'hepta.hia.program.v8', 'module': 'm', 'exports': [], 'functions': functions}


def composed(label, functions):
    global active, stream_number
    actual = outer(functions)
    wanted, (late, error) = expected(actual, 64), old_late(actual)
    summaries = [test_value(label + '-object-' + str(i), value, mode=1) for i, value in enumerate(functions)]
    empty, _, _ = source_for(None, label + '-empty')
    _, actual_json, _ = source_for(actual, label + '-whole-native-json')
    stream_number += 1
    active = Session(native, empty, stream=stream_number)
    items = [token(6, 4), string('schema'), string(actual['schema']), string('module'), string('m'),
             string('exports'), token(5), string('functions'), token(5, len(functions))]
    items += [token(0, (1 << 63) + i) for i in range(len(functions))]
    with protected():
        assert active.initialize()[1][1] == 1
        result = active.send(b''.join(items), final=True)
        queries = 0
        while result[0] != BAD and result[1][1] == 4:
            index = result[1][11] - (1 << 63)
            assert index == queries
            summary, serialized = summaries[index]
            result = active.summary_reply(result[1][11], summary[7], summary[8], summary[9],
                                          len(serialized), sha256(serialized).digest())
            queries += 1
        assert result[0] == 1152 and result[1][1:3] == (5, 2) and queries == len(functions)
        done = result[1]
        result = active.admit(len(actual_json), sha256(actual_json).digest())
    assert (done[8], done[9], done[14], done[15]) == wanted, (label, done, wanted)
    assert result[1][13] == late, (label, result, error)
    cases.append({'case': label, 'mode': 2, 'opaque_queries': queries,
                  'late_status': late, 'reference_error': error,
                  'actual_native_JSON_bytes': len(actual_json), 'visitor_entries': active.calls,
                  'grows': active.grows, 'full_summary_exact': True,
                  'all_opaque_summaries_from_actual_native_visitor': True})
    active.close()
    active = None


try:
    for size in (262142, 262143, 262144):
        test_value('list-bound-' + str(size), [None] * size)
    test_value('map-keys-excluded-at-node-limit', {str(i): None for i in range(262143)})
    for depth in (62, 63, 64, 65, 66, 80):
        test_value('depth-source-' + str(depth), chain(depth))
        test_value('depth-chunked-' + str(depth), chain(depth), from_source=False, split=64)
    test_value('alias-counted-every-time', [[None] * 131072] * 2)
    test_value('nested-empty-containers', [[[], {}, [[], {}]] for _ in range(400)], from_source=False, split=128)
    test_value('root-mask-unknown', {'name': 'f', 'return_loans': [], 'unknown': 1}, from_source=False, split=64)
    test_value('active-key-table-across-chunks', {'k' + str(i): i for i in range(8192)}, from_source=False, split=512)
    test_value('source-key-equality-utf8', {'é': 0, 'e\u0301': 1, '😀': 2, '': 3})
    for reverse in (False, True):
        children = [chain(65), [None] * 262144]
        if reverse: children.reverse()
        test_value('list-depth-queue-order-' + str(reverse), children)
        value = {'a': children[0], 'b': children[1]}
        test_value('map-depth-queue-order-' + str(reverse), value)
    for depth in (60, 61, 62, 63, 64):
        composed('opaque-depth-' + str(depth), [function(chain(depth))])
    for reverse in (False, True):
        functions = [function(chain(65)), function([None] * 262144)]
        if reverse: functions.reverse()
        composed('opaque-depth-queue-order-' + str(reverse), functions)
    shared = function([{'const': 7}])
    composed('opaque-repeated-alias', [shared, shared, shared])
    for delta in (-1, 0, 1):
        test_value('exact-native-json-byte-bound-' + str(delta), {'x': 'a' * (8388608 - 8 + delta)})
    rng = random.Random(0x4c4154455f484941)
    def random_value(depth):
        pick = rng.randrange(6 if depth else 4)
        if pick == 0: return None
        if pick == 1: return bool(rng.randrange(2))
        if pick == 2: return rng.randrange(1 << 64)
        if pick == 3: return rng.choice(('', 'quote"', '中😀', '\0\n'))
        if pick == 4: return [random_value(depth - 1) for _ in range(rng.randrange(5))]
        return {'f' + str(i): random_value(depth - 1) for i in range(rng.randrange(5))}
    for index in range(100):
        value = function(random_value(4))
        test_value('deterministic-source-' + str(index), value, mode=1)
        test_value('deterministic-chunked-' + str(index), value, mode=1, from_source=False, split=128)
    summary = {'status': 'PASS', 'scope': 'ACTUAL_NEW_VISITOR_NATIVE_BOUNDARIES_NOT_COLD_OR_WHOLE_DRIVER',
               'cases': cases, 'visitor_entries': native.entries, 'issuer_entries': issuer.entries,
               'wall_elapsed_ns': time.monotonic_ns() - started,
               'retained_reference_sha256': sha256(reference_raw).hexdigest(),
               'all_original_limits_unchanged': [262144, 64, 8388608],
               'digest_scope': 'test reference SHA outside native forwarding; hash owner is separate'}
except BaseException as exc:
    traceback.print_exc()
    summary = {'status': 'FAIL', 'completed_cases': cases, 'class': type(exc).__name__, 'error': str(exc),
               'visitor_entries': native.entries, 'issuer_entries': issuer.entries}
    raise
finally:
    if active is not None: active.close()
    native.close()
    issuer.close()
    assert source.read_bytes() == source_raw
    assert Path(reference.__file__).read_bytes() == reference_raw
    assert (ROOT / 'development/smoke_visitor_r1.py').read_bytes() == smoke_source
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': summary['status'], 'cases': len(cases),
                      'visitor_entries': native.entries, 'issuer_entries': issuer.entries}, sort_keys=True), flush=True)
