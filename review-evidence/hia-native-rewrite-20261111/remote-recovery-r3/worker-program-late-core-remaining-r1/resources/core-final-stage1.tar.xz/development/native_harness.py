"""Mechanical actual-image harness for the Core visitor.

NEW POST-RECOVERY TEST CODE. This module is not a production dispatcher. It
constructs no Core summary and makes no language decision. The caller supplies
a complete source lease issued by the separate actual native packet owner.
"""
from hashlib import sha256
import ctypes
import json
from pathlib import Path
import struct

from hepta.hia_json_preflight_native import NativeHiaJsonImage

BAD = 0xfffffffd
MIN_WORK = 131328
MAX = (1 << 64) - 1
MAGIC = lambda value: int.from_bytes(value, 'little')
INIT, CONT, OPAQUE, ADMIT, EVENT = map(MAGIC, (b'HIACSB01', b'HIACSC01', b'HIACSO01', b'HIACSA01', b'HIACSE01'))
COMPILER_SHA = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
CANARY = b'\xb7' * 32


class VisitorImage:
    def __init__(self, manifest, current_source, directory):
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            if path in self.pins and self.pins[path] != raw:
                raise AssertionError('one path changed across immutable custody roles')
            self.pins[path] = raw
            return raw
        manifest = Path(manifest).resolve()
        value = json.loads(read(manifest))
        if (set(value) != {'schema', 'source_sha256', 'source_path', 'image_sha256', 'image_path', 'compiler_sha256'}
                or value['schema'] != 'hepta.hia.composite-core-final-native.v1'
                or value['compiler_sha256'] != COMPILER_SHA):
            raise AssertionError('not the exact source-bound development component manifest')
        source = read(manifest.parent / value['source_path'])
        current = read(current_source)
        image = read(manifest.parent / value['image_path'])
        if (source != current or sha256(source).hexdigest() != value['source_sha256']
                or sha256(image).hexdigest() != value['image_sha256']):
            raise AssertionError('component/source/image mismatch')
        self.readback()
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=False)
        (self.directory / 'component-manifest.json').write_bytes(self.pins[manifest])
        (self.directory / 'component-source.hiaasm').write_bytes(source)
        (self.directory / 'component-image.bin').write_bytes(image)
        self.image = NativeHiaJsonImage(image, value['image_sha256'])
        self.log = (self.directory / 'entries.jsonl').open('w')
        self.entries = 0
        self.source_leases = {}

    def readback(self):
        for path, raw in self.pins.items():
            if path.read_bytes() != raw:
                raise AssertionError('source/image drift: ' + str(path))

    def close(self):
        self.log.close()
        self.readback()
        result = {'scope': 'ACTUAL_NATIVE_CORE_VISITOR_DEVELOPMENT_NOT_COLD',
                  'entries': self.entries, 'all_source_image_pins_unchanged': True,
                  'pins': {str(path): sha256(raw).hexdigest() for path, raw in self.pins.items()}}
        (self.directory / 'custody.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


class Session:
    def __init__(self, native, source_lease, *, lease=1, stream=1, mode=2,
                 producer=MAGIC(b'HIAFNC01'), action=0, request=1, serial=0,
                 slots=0, size=MIN_WORK):
        if type(source_lease) is not bytes:
            raise TypeError('source lease must be exact frozen bytes')
        self.native, self.source_raw = native, source_lease
        self.source = ctypes.create_string_buffer(source_lease + CANARY)
        digest = sha256(source_lease).hexdigest()
        if digest not in native.source_leases:
            name = 'source-' + digest + '.lease'
            (native.directory / name).write_bytes(source_lease)
            native.source_leases[digest] = name
        self.lease, self.stream, self.mode = lease, stream, mode
        self.producer, self.action, self.request = producer, action, request
        self.serial, self.slots = serial, slots
        self.size = size
        self.work = ctypes.create_string_buffer(size + len(CANARY))
        ctypes.memset(ctypes.addressof(self.work) + size, 0xb7, len(CANARY))
        self.event = None
        self.sequence = 0
        self.calls, self.grows = 0, 0
        self.events = []
        self.initial = struct.pack('<10Q', INIT, lease, stream, producer, action, request, serial, slots, mode, 0)

    def call(self, command, *, extent=None, source=None):
        if type(command) is not bytes:
            raise TypeError('command must be exact frozen bytes')
        source_raw = self.source_raw if source is None else source
        source_buffer = self.source if source is None else ctypes.create_string_buffer(source + CANARY)
        source_digest = sha256(source_raw).hexdigest()
        if source_digest not in self.native.source_leases:
            source_name = 'source-' + source_digest + '.lease'
            (self.native.directory / source_name).write_bytes(source_raw)
            self.native.source_leases[source_digest] = source_name
        buffer = ctypes.create_string_buffer(command + CANARY)
        advertised = self.size if extent is None else extent
        previous = self.event
        result = self.native.image._entry(buffer, len(command), source_buffer, len(source_raw), self.work, advertised)
        self.calls += 1
        self.native.entries += 1
        assert ctypes.string_at(buffer, len(command) + len(CANARY)) == command + CANARY
        assert ctypes.string_at(source_buffer, len(source_raw) + len(CANARY)) == source_raw + CANARY
        assert ctypes.string_at(ctypes.addressof(self.work) + self.size, len(CANARY)) == CANARY
        event = struct.unpack_from('<16Q', self.work, 1024) if self.size >= 1152 else None
        name = f'call-{self.native.entries:06d}.bin'
        (self.native.directory / name).write_bytes(command)
        row = {'entry': self.native.entries, 'return': result, 'lease': self.lease, 'stream': self.stream,
               'command': name, 'command_bytes': len(command), 'command_sha256': sha256(command).hexdigest(),
               'source_sha256': sha256(source_raw).hexdigest(), 'source_bytes': len(source_raw),
               'workspace_bytes': self.size, 'advertised_workspace': advertised,
               'event': event, 'input_and_canary_unchanged': True}
        self.native.log.write(json.dumps(row, sort_keys=True) + '\n')
        self.native.log.flush()
        if result != BAD:
            assert result == 1152 and event[0] == EVENT
            assert event[3:5] == (self.lease, self.stream)
            assert event[2] in (1, 2, 3) and event[15] in (0, 1)
            assert event[6] == (1 if previous is None else previous[6] + 1)
            self.events.append(event)
        self.event = event
        return result, event

    def initialize(self):
        return self.call(self.initial)

    def grow(self, needed, *, exact=False):
        size = needed if exact else max(needed, self.size * 2)
        assert size > self.size
        previous = self.work
        self.work = ctypes.create_string_buffer(size + len(CANARY))
        ctypes.memmove(self.work, previous, self.size)
        self.size = size
        ctypes.memset(ctypes.addressof(self.work) + size, 0xb7, len(CANARY))
        self.grows += 1

    def finish(self, result, *, exact=False):
        while result[0] != BAD and result[1][1] == 3:
            event = result[1]
            self.grow(event[10], exact=exact)
            result = self.call(struct.pack('<4Q', CONT, self.lease, self.stream, event[6]))
        return result

    def producer_frame(self, payload, *, final, sequence=None):
        sequence = self.sequence if sequence is None else sequence
        return struct.pack('<8Q', self.producer, self.action, sequence, int(final),
                           self.serial, self.slots, self.request, len(payload)) + payload

    def send(self, payload, *, final, exact=False):
        result = self.finish(self.call(self.producer_frame(payload, final=final)), exact=exact)
        if result[0] != BAD and result[1][1] in (1, 5):
            self.sequence += 1
            assert result[1][5] == self.sequence
        return result

    def summary_reply(self, handle, kind, nodes, first, json_bytes, digest):
        assert type(digest) is bytes and len(digest) == 32
        event = self.event
        result = self.finish(self.call(struct.pack('<16Q', OPAQUE, self.lease, self.stream, event[6],
            handle, kind, nodes, first, json_bytes, *struct.unpack('<4Q', digest), 0, 0, 0)))
        if result[0] != BAD and result[1][1] in (1, 5):
            self.sequence += 1
            assert result[1][5] == self.sequence
        return result

    def admit(self, json_bytes, digest):
        assert type(digest) is bytes and len(digest) == 32
        return self.call(struct.pack('<10Q', ADMIT, self.lease, self.stream, self.event[6],
                                     json_bytes, *struct.unpack('<4Q', digest), 0))

    def close(self):
        self.work = None
        self.source = None
        self.native.readback()
