"""Seal only completed new Core visitor stage 1; all original bytes retained."""
from hashlib import sha256
from pathlib import Path
import json
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT.parent / "hia-composite-core-final-reconstructed-stage1-development.tar.xz"
CUSTODY = DEST.with_name(DEST.name.removesuffix(".tar.xz") + ".custody.json")
assert not DEST.exists() and not CUSTODY.exists()
paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
rows = []
for path in paths:
    raw = path.read_bytes()
    rows.append({"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
                 "mode": stat.S_IMODE(path.stat().st_mode), "sha256": sha256(raw).hexdigest()})
with tarfile.open(DEST, "w:xz", preset=3) as archive:
    for path in paths:
        archive.add(path, arcname=path.relative_to(ROOT).as_posix(), recursive=False)
with tarfile.open(DEST, "r:xz") as archive:
    members = archive.getmembers()
    assert len(members) == len(rows)
    for member, row in zip(members, rows):
        assert member.isfile() and member.name == row["path"]
        raw = archive.extractfile(member).read()
        assert len(raw) == member.size == row["bytes"]
        assert member.mode == row["mode"]
        assert sha256(raw).hexdigest() == row["sha256"]
        live = ROOT / row["path"]
        assert live.read_bytes() == raw and stat.S_IMODE(live.stat().st_mode) == row["mode"]
encoded = DEST.read_bytes()
result = {"scope": "FRESH_POST_RECOVERY_STAGE1_ONLY_NO_PENDING_CONTROLS_NOT_COLD",
          "archive": str(DEST), "archive_bytes": len(encoded),
          "archive_sha256": sha256(encoded).hexdigest(),
          "members": len(rows), "raw_bytes": sum(row["bytes"] for row in rows),
          "every_member_exact_bytes_hash_mode_and_live_readback": True, "files": rows}
CUSTODY.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "files"}, sort_keys=True), flush=True)
