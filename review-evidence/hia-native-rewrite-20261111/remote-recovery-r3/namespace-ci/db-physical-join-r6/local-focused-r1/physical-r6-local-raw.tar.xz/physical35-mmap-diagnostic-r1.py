"""New bounded local diagnostic of the original fixed executable's mmap frontier.
The immutable original CI evidence remains untouched; this is not qualification.
"""
import sys
sys.dont_write_bytecode=True
import hashlib,importlib.util,json,os,pathlib,resource,shutil,traceback
root=pathlib.Path(sys.argv[1]);root.mkdir(mode=0o700,parents=True,exist_ok=False)
resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.sched_setaffinity(0,{2,3})
base=pathlib.Path('/workspace/scratch/hia-namespace-follow36/originals/physical35-input/hia-namespace-db-physical-join-recovery/namespace-db-physical-join-r1')
source=base/'source/namespace-db-join-r1-client.py';raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()=='e5cad29b23957856c3a3ae08645eb7a14a62f6b0263fe67720a9560b88e58270'
spec=importlib.util.spec_from_file_location('original_f35_client',source);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;exec(compile(raw,str(source),'exec'),mod.__dict__)
original=base/'db-join-build-r1/hia-namespace-db-join';raw_elf=original.read_bytes();assert hashlib.sha256(raw_elf).hexdigest()=='4fc09dba93b970adc69b23516d60be4129d384f2be9ef2cca6b3b744a5e17db6'
exe=root/'original-executable';exe.write_bytes(raw_elf);exe.chmod(0o755)
fixture=root/'fixture';fixture.mkdir();db=fixture/'db';db.write_bytes(b'local-memory-frontier')
report=dict(scope='NEW_LOCAL_ORIGINAL_EXECUTABLE_FRONTIER_DIAGNOSTIC',original_qualification_unchanged=True,inputs=dict(client_sha256=hashlib.sha256(raw).hexdigest(),elf_sha256=hashlib.sha256(raw_elf).hexdigest()),limits=mod.LIMITS)
try:
 with mod.Carrier(exe,root/'native',fixture,launcher=['strace','-qq','-f','-s','256','-o',str(root/'syscalls.strace'),'-e','trace=mmap,munmap,fcntl,ftruncate,openat,close']) as c:
  result,_=c.filesystem(1,b=os.O_RDWR|os.O_CLOEXEC,c=0o600,body=os.fsencode(db));token=result[8]
  head,row=c.database(3,token=token);handle=head[14]
  c.call(8,handle,body=os.fsencode(db))
  c.call(9,handle,a=14,b=0,c=1,d=32768)
  report['outcome']='MMAP_COMPLETED'
except BaseException as e:
 report.update(outcome='REJECTED_OR_INTERRUPTED',error_class=type(e).__name__,error=str(e),traceback=traceback.format_exc())
(root/'summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,sort_keys=True))
