"""Local development process supervision; never changes an original CI result."""
from __future__ import annotations
import argparse, ctypes, hashlib, json, os, resource, signal, subprocess, time
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--cpu",type=int,required=True)
    p.add_argument("--wall",type=int,required=True)
    p.add_argument("--address",type=int,required=True)
    p.add_argument("command",nargs=argparse.REMAINDER)
    a=p.parse_args();command=a.command
    if command and command[0]=="--":command=command[1:]
    assert command and Path(command[0]).is_absolute()
    a.output.mkdir(parents=True,exist_ok=False)
    parent=os.getpid();started=time.monotonic_ns()
    def child():
        os.sched_setaffinity(0,{2,3})
        resource.setrlimit(resource.RLIMIT_CPU,(a.cpu,a.cpu))
        resource.setrlimit(resource.RLIMIT_AS,(a.address,a.address))
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        libc=ctypes.CDLL(None,use_errno=True)
        if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:os._exit(125)
        if os.getppid()!=parent:os._exit(125)
    stdout=(a.output/"stdout.log").open("xb");stderr=(a.output/"stderr.log").open("xb")
    process=None;wait_status=None;usage=None;timed_out=False;failure=None
    try:
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
            close_fds=True,start_new_session=True,preexec_fn=child,
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",LC_ALL="C"))
        (a.output/"start.json").write_text(json.dumps(dict(pid=process.pid,parent=parent,command=command,
            limits=dict(cpu_seconds=a.cpu,wall_seconds=a.wall,address_bytes=a.address,core_bytes=0)),indent=2)+"\n")
        while True:
            pid,status,ru=os.wait4(process.pid,os.WNOHANG)
            if pid:
                wait_status=status;usage=ru;process.returncode=os.waitstatus_to_exitcode(status);break
            if time.monotonic_ns()-started>=a.wall*1_000_000_000:
                timed_out=True
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                _,wait_status,usage=os.wait4(process.pid,0)
                process.returncode=os.waitstatus_to_exitcode(wait_status);break
            time.sleep(.05)
    except BaseException as error:
        failure=dict(type=type(error).__name__,message=str(error))
        raise
    finally:
        if process is not None and process.returncode is None:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            _,wait_status,usage=os.wait4(process.pid,0)
            process.returncode=os.waitstatus_to_exitcode(wait_status)
        stdout.close();stderr.close()
        report=dict(scope="NEW_LOCAL_DEVELOPMENT",command=command,parent=parent,
            pid=None if process is None else process.pid,
            returncode=None if process is None else process.returncode,
            wait_status=wait_status,wall_timed_out=timed_out,wall_ns=time.monotonic_ns()-started,
            cpu_seconds=None if usage is None else usage.ru_utime+usage.ru_stime,
            maxrss_kib=None if usage is None else usage.ru_maxrss,
            limits=dict(cpu_seconds=a.cpu,wall_seconds=a.wall,address_bytes=a.address,core_bytes=0),
            failure=failure,streams={})
        for name in ("stdout.log","stderr.log"):
            raw=(a.output/name).read_bytes()
            report["streams"][name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        (a.output/"process.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
        print(json.dumps(report,sort_keys=True),flush=True)
    return 0 if process is not None and process.returncode==0 and not timed_out else 1
if __name__=="__main__":raise SystemExit(main())
