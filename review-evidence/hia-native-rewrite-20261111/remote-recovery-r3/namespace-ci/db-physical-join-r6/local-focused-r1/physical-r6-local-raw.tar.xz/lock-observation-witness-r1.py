"""New local witness of original test12 observation affecting POSIX inode locks.
No HIA execution or original qualification replay occurs.
"""
import sys
sys.dont_write_bytecode=True
import hashlib,json,os,pathlib,resource,sqlite3,subprocess,time
root=pathlib.Path(sys.argv[1]);root.mkdir(mode=0o700,parents=True,exist_ok=False)
resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(256<<20,256<<20));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
os.sched_setaffinity(0,{2,3})
probe="""import fcntl,json,os,struct,sys
fd=os.open(sys.argv[1],os.O_RDONLY)
try:
 raw=fcntl.fcntl(fd,fcntl.F_GETLK,struct.pack('hh4xqqi4x',fcntl.F_WRLCK,os.SEEK_SET,128,1,0))
 t,w,s,n,p=struct.unpack('hh4xqqi4x',raw);print(json.dumps(dict(type=t,pid=p,start=s,length=n,whence=w,raw_hex=raw.hex())))
finally:os.close(fd)
"""
read="""import hashlib,json,pathlib,sys
b=pathlib.Path(sys.argv[1]).read_bytes();print(json.dumps(dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())))
"""
def child(src,path):
 p=subprocess.run([sys.executable,"-I","-S","-c",src,str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 assert p.returncode==0,(p.returncode,p.stderr);return json.loads(p.stdout)
results=[]
for name,foreign in (("same_process_Path_read_bytes",False),("fresh_process_read_bytes",True)):
 directory=root/name;directory.mkdir();db=directory/"example.sqlite";conn=sqlite3.connect(db,isolation_level=None,timeout=0)
 try:
  assert conn.execute("pragma journal_mode=wal").fetchone()[0]=="wal"
  conn.execute("create table retained(x)");conn.execute("insert into retained values(9)");conn.execute("begin immediate")
  shm=pathlib.Path(str(db)+"-shm")
  before=child(probe,shm);assert before["type"]==0 and before["pid"]==os.getpid(),before
  if foreign:observed=child(read,shm)
  else:
   b=shm.read_bytes();observed=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  after=child(probe,shm)
  if foreign:assert after==before,(before,after)
  else:assert after["type"]==2,after
  results.append(dict(case=name,locks_before=before,observation=observed,locks_after=after))
 finally:conn.close()
value=dict(status="PASS_WITNESS_ONLY",python=sys.version,sqlite=sqlite3.sqlite_version,pid=os.getpid(),platform=sys.platform,
 original_qualification_unchanged=True,new_HIA_entries=0,new_native_target_entries=0,
 explanation="An independent process holds and closes its own descriptor; a same-process close releases this process POSIX locks on that inode.",
 cases=results)
(root/"summary.json").write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
print(json.dumps(value,sort_keys=True))
