"""Seal complete completed local development raw files without changing originals."""
from pathlib import Path
import hashlib, io, json, os, stat, tarfile
base=Path('/workspace/scratch/hia-namespace-follow36')
out=base/'physical-r6-local-checkpoint-r1';out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{2,3})
roots=['physical-r6-source','physical-r6-local-01','physical-r6-focused-01',
       'physical35-mmap-diagnostic-r1','physical35-mmap-diagnostic-r2',
       'physical35-mmap-diagnostic-r3','physical35-mmap-diagnostic-r3-process',
       'physical-r6-mmap-diagnostic-r1','physical-r6-mmap-diagnostic-r1-process',
       'lock-observation-witness-r1']
single=['run-bounded.py','physical-r6-focused-test10-test12.py',
        'physical35-mmap-diagnostic-r1.py','physical35-mmap-diagnostic-r2.py',
        'physical35-mmap-diagnostic-r3.py','physical-r6-mmap-diagnostic-r1.py',
        'lock-observation-witness-r1.py','physical-r6-source-index.json',
        'seal-physical-r6-local-r1.py']
paths=[]
for name in roots:
    root=base/name;assert root.is_dir()
    for p in sorted(root.rglob('*')):
        st=p.lstat();assert not stat.S_ISLNK(st.st_mode),(str(p),'symlink')
        if stat.S_ISDIR(st.st_mode):continue
        assert stat.S_ISREG(st.st_mode),(str(p),st.st_mode)
        paths.append(p)
paths.extend(base/n for n in single)
assert len(paths)==len(set(paths))
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rows=[];archive=out/'physical-r6-local-raw.tar.xz'
with tarfile.open(archive,'w:xz',preset=3) as t:
    for p in sorted(paths):
        st=p.lstat();assert stat.S_ISREG(st.st_mode)
        raw=p.read_bytes();assert len(raw)==st.st_size
        name=p.relative_to(base).as_posix()
        row=dict(name=name,path=str(p),bytes=len(raw),mode=stat.S_IMODE(st.st_mode),sha256=sha(raw),git_blob=git(raw))
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=row['mode'];info.mtime=st.st_mtime_ns//1_000_000_000
        t.addfile(info,io.BytesIO(raw));rows.append(row)
by_name={r['name']:r for r in rows};verified=[]
with tarfile.open(archive,'r:xz') as t:
    members=t.getmembers();assert len(members)==len(rows)
    assert {m.name for m in members}==set(by_name)
    for m in members:
        assert m.isreg();raw=t.extractfile(m).read();r=by_name[m.name]
        assert (len(raw),sha(raw),git(raw),m.mode)==(r['bytes'],r['sha256'],r['git_blob'],r['mode'])
        p=Path(r['path']);assert p.read_bytes()==raw and stat.S_IMODE(p.stat().st_mode)==m.mode
        verified.append(m.name)
index=(json.dumps(rows,sort_keys=True,indent=2)+'\n').encode();(out/'members.json').write_bytes(index)
raw=archive.read_bytes()
custody=dict(scope='NEW_LOCAL_PHYSICAL_R6_FOCUSED_DEVELOPMENT_COMPLETE_RAW',
    archive=dict(path=str(archive),bytes=len(raw),sha256=sha(raw),git_blob=git(raw)),
    member_index=dict(path=str(out/'members.json'),bytes=len(index),sha256=sha(index),git_blob=git(index)),
    members=len(rows),raw_bytes=sum(r['bytes'] for r in rows),all_members_original_and_archive_bytes_mode_SHA_Git_verified=True,
    full18_physical_gate='PENDING_NEW_CI',old_follow35_failure_unchanged=True,
    raw_scope=['6-role + packer fresh B3 build including original33 native packer controls',
               '84 oldVM/newVM/newnative full-buffer cases',
               'focused original test10 and corrected test12, all322 native/VM full-buffer entries',
               'original ELF mmap failure110 and corrected ELF completion0',
               'failed local strace attempts before target entry',
               'POSIX same-process-close vs independent-reader witness'],
    SQLite_versions=dict(original_CI='3.45.1',new_local='3.53.1'),
    original_qualification_zip_included=False,original_qualification_artifact_id=13920641096,
    original_qualification_zip_sha256='37e0e433cf06fd7274189af84a92b2b501355c5a61e2a10ca83fe234cb303f13',
    ordinary_Store_closed=False,cold_qualification=False)
(out/'custody.json').write_text(json.dumps(custody,sort_keys=True,indent=2)+'\n')
print(json.dumps(custody,sort_keys=True))
