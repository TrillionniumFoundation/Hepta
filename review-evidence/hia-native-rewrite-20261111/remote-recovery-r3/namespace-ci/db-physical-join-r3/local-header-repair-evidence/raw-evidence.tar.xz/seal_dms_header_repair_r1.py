from pathlib import Path
import hashlib,io,json,stat,tarfile
ROOT=Path(__file__).resolve().parent
WORK=ROOT/'dms-profile-repair'
OUT=ROOT/'dms-header-repair-checkpoint-r1';OUT.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
    p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
    b=p.read_bytes();return dict(bytes=len(b),sha256=sha(b),mode=stat.S_IMODE(s.st_mode),git_sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
reports={label:json.loads((WORK/path).read_bytes()) for label,path in (
 ('build','candidate-r1-generation-compile-r2/summary.json'),('main','differential-r1/summary.json'),
 ('persistent','differential-continuations-r1/summary.json'),('proof','proof-readback-r2.json'))}
assert reports['build']['status']=='PASS_LOCAL_GENERATION_AND_B3_ONLY'
assert reports['main']['status']==reports['persistent']['status']=='PASS'
assert reports['main']['cases']==564 and reports['persistent']['cases']==8
assert reports['proof']['controls_count']==20
for label in ('main','persistent'):
    d=reports[label];assert d['old_VM_entries']==d['new_VM_entries']==d['new_native_entries']==d['cases']
    assert d['source_pins_unchanged'] and d['resource_counters_equal'] and d['actual_OS_syscalls']==0
summary=dict(schema='hia-dms8-pure-header-repair-local-evidence-v1',status='PASS_LOCAL_COMPONENT_NOT_PHYSICAL_JOIN',
    original_failure=reports['proof']['original_failure'],old_profile=reports['proof']['original_profile']['profile'],
    new_profile=reports['build']['profile'],DSL=reports['build']['dsl'],
    source=reports['build']['source'],image=reports['build']['image'],
    main_cases=564,persistent_cases=8,old_VM_entries=572,new_VM_entries=572,new_DMS_native_entries=572,
    actual_FS_seed_entries=1,actual_B3_compile_entries=1,static_controls=20,
    exact_full_state=True,source_readonly_unchanged=True,all_canaries=True,resource_counters_equal=True,
    VM_step_counts_equal_claimed=False,actual_OS_syscalls=0,physical_join_closed=False,ordinary_AgentStore_closed=False,
    original_18_physical_tests_retained=True,original_33_packer_controls_retained=True,
    original_profile_limits=dict(functions=128,blocks=1536,ops=8192,max_blocks=256,max_block_params=16),
    original_native_limits=dict(cpu_seconds=90,wall_seconds=180,address_bytes=1<<30),
    original_B3_limits=dict(cpu_seconds=10,wall_seconds=20,address_bytes=256<<20,output_bytes=1<<20,workspace_bytes=1<<20),
    retained_local_attempts=[
        dict(name='diagnose-r1',result='SCRIPT_TYPEERROR_AFTER_EXACT_ORIGINAL_REPRODUCTION',native_entries=0),
        dict(name='fixed-header-prototype-r1',result='SCRIPT_ASSERTION_ON_LEGITIMATE_OUTPUT_ALIAS',native_entries=0),
        dict(name='generation-compile-r1',result='MISSING_ORIGINAL_CHILD_IN_103_FILE_IMPORT_SUBSET',B3_entries=0),
        dict(name='proof-readback-r1',result='CONTROL_EXPECTED_WRONG_ALIAS_SET_FOR_GET_HELPER',native_entries=0),
    ],original_ROG_full='FAIL/HOLD unchanged; NDU deletion actor UNKNOWN')
(WORK/'LOCAL-SUMMARY.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
items=[]
for prefix,d in [('work',WORK),('reference',ROOT/'reference-0ef-development-104')]:
    for p in sorted(d.rglob('*')):
        if p.is_file():items.append((prefix+'/'+p.relative_to(d).as_posix(),p))
items.append(('compiler/B3-35ee92b7.image.bin',Path('/workspace/scratch/hia-root-r31/seed/B3-35ee92b7.image.bin')))
fs=ROOT/'dms5-follow27-original/inner/run/namespace-dms-r5/validation-r1/compile'
for n in ('namespace-fs-lifetime-r1.image.bin','namespace-fs-lifetime-r1.input.bin','namespace-fs-lifetime-r1.receipt.json'):
    items.append(('fs-seed/'+n,fs/n))
items.append(('seal_dms_header_repair_r1.py',Path(__file__)))
assert len(items)==len({n for n,p in items})
rows=[];archive=OUT/'raw-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
    for name,p in sorted(items):
        b=p.read_bytes();row=dict(name=name,**pin(p));rows.append(row)
        m=tarfile.TarInfo(name);m.size=len(b);m.mode=row['mode'];m.uid=m.gid=0;m.mtime=0;m.uname=m.gname=''
        t.addfile(m,io.BytesIO(b))
with tarfile.open(archive,'r:xz') as t:
    members=t.getmembers();assert len(members)==len(rows)
    for m,row in zip(members,rows,strict=True):
        assert m.isfile() and m.name==row['name'] and m.size==row['bytes'] and m.mode==row['mode']
        b=t.extractfile(m).read();assert sha(b)==row['sha256']
for name,p in items:assert pin(p)=={k:v for k,v in next(r for r in rows if r['name']==name).items() if k!='name'}
index=OUT/'members.json';index.write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n')
custody=dict(schema='hia-local-dms-repair-custody-v1',status='FULL_MEMBER_READBACK_PASS',archive=pin(archive),index=pin(index),members=len(rows),raw_bytes=sum(r['bytes'] for r in rows),source_before_after_equal=True,
    member_bytes_SHA256_modes_verified=True,original_data_deleted=False,scope=summary['status'])
(OUT/'custody.json').write_text(json.dumps(custody,sort_keys=True,indent=2)+'\n')
(OUT/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(path=str(OUT),**custody),sort_keys=True))
