from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import ast,hashlib,importlib,json,resource,signal,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REF=ROOT.parent/"reference-0ef-subset"
ORIGINAL=ROOT/"original"
OUT=ROOT/"diagnostic-r2"
OUT.mkdir(exist_ok=False)
sys.path[:0]=[str(ORIGINAL),str(REF)]
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
signal.signal(signal.SIGALRM,lambda a,b:(_ for _ in ()).throw(TimeoutError("diagnostic wall180")))
signal.alarm(180)
pin=json.loads((ORIGINAL/"source-pins.json").read_text())
for row in pin["sources"]:
 raw=(ORIGINAL/row["path"]).read_bytes()
 assert len(raw)==row["bytes"] and hashlib.sha256(raw).hexdigest()==row["sha256"],row["path"]
from tools.generate_hia_agent_namespace_objects import ObjectBuilder
from tools.generate_hia_selfhost import total_scalar_functions,compact_authoring_cfg
from hepta.hia_agent_assembly import render_assembly
def save(path,v):
 raw=(json.dumps(v,sort_keys=True,separators=(",",":"))+"\n").encode()
 path.write_bytes(raw)
 return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def profile(d):
 return dict(functions=len(d["functions"]),blocks=sum(len(f["blocks"]) for f in d["functions"]),
  ops=sum(len(b["ops"]) for f in d["functions"] for b in f["blocks"]),
  max_blocks=max(len(f["blocks"]) for f in d["functions"]),
  max_block_params=max(len(b["params"]) for f in d["functions"] for b in f["blocks"]))
roles=["generate_hia_agent_namespace_filesystem_r5","generate_hia_agent_namespace_shm_map_r3",
 "generate_hia_agent_namespace_memory_leases","generate_hia_agent_namespace_dms_map_join_r8",
 "generate_hia_agent_namespace_db_node_r2","generate_hia_agent_namespace_db_fixed_join_r1"]
reports={}
for i,name in enumerate(roles,1):
 author=importlib.import_module("tools."+name)
 d=author.document()
 result=dict(profile=profile(d),document=save(OUT/("role-"+str(i)+".json"),d))
 if i<=4:
  expected=pin["expected_frontiers"]["role-"+str(i)]
  assert result["profile"]==expected["profile"],(i,result,expected)
  assert result["document"]["sha256"]==expected["document"]["sha256"],(i,result,expected)
 reports[str(i)]=result
 print(json.dumps(dict(role=i,**result),sort_keys=True),flush=True)
 if i==4:
  nodes=ast.parse(author.source_program()).body
  names=[n.name for n in nodes]
  reports["dms_names"]=[dict(source_name=n,**row) for n,row in zip(names,expected["functions"],strict=True)]
  reports["dms_source_names"]=names
save(OUT/"old-profiles.json",reports)
print("ORIGINAL_PROFILE_REPRODUCED",flush=True)
