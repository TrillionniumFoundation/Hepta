from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import hashlib,importlib.util,json,resource,signal,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REF=ROOT.parent/'reference-0ef-development-104'
CANDIDATE=ROOT/'candidate-r1'
COMPILER=Path('/workspace/scratch/hia-root-r31/seed/B3-35ee92b7.image.bin')
sys.path[:0]=[str(CANDIDATE),str(REF)]
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
signal.signal(signal.SIGALRM,lambda a,b:(_ for _ in ()).throw(TimeoutError('whole build wall180')))
signal.alarm(180)
OUT=ROOT/'candidate-r1-generation-compile-r2';OUT.mkdir(exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,obj):(OUT/name).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
pins={}
def pin(path):
    p=Path(path);raw=p.read_bytes();row=dict(bytes=len(raw),sha256=sha(raw),mode=p.stat().st_mode&0o777)
    if str(p) in pins:assert pins[str(p)]==row
    pins[str(p)]=row;return raw
for p in sorted(REF.rglob('*.py')):pin(p)
for d in (ROOT/'original/tools',CANDIDATE/'tools'):
    for p in sorted(d.glob('*.py')):pin(p)
assert sha(pin(COMPILER))=='35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
pin(__file__);save('source-before.json',pins)
report=dict(status='INCOMPLETE',scope='LOCAL_DEVELOPMENT_EXACT_0EF_AUTHORING_SUBSET',B3_entries=0,VM_entries=0,native_entries=0,ordinary_store_closed=False)
started=time.monotonic_ns()
try:
    from tools import generate_hia_agent_namespace_dms_map_join_r8 as author
    from hepta.hia_agent_assembly import render_assembly,assemble_program
    from tools.qualify_hia_selfhost import compile_stage,CHILD
    oldpath=ROOT/'original/tools/generate_hia_agent_namespace_dms_map_join_r8.py'
    spec=importlib.util.spec_from_file_location('original_dms_author',oldpath)
    old=importlib.util.module_from_spec(spec);exec(compile(pin(oldpath),str(oldpath),'exec'),old.__dict__)
    assert author.source_program()==old.source_program()
    report['dsl']=dict(bytes=len(author.source_program().encode()),sha256=sha(author.source_program().encode()),unchanged=True)
    doc=author.document();raw=(json.dumps(doc,sort_keys=True,separators=(',',':'))+'\n').encode()
    (OUT/'document.json').write_bytes(raw)
    funcs=doc['functions']
    profile=dict(functions=len(funcs),blocks=sum(len(f['blocks']) for f in funcs),
        ops=sum(len(b['ops']) for f in funcs for b in f['blocks']),max_blocks=max(len(f['blocks']) for f in funcs),
        max_block_params=max(len(b['params']) for f in funcs for b in f['blocks']))
    report['profile']=profile;report['document']=dict(bytes=len(raw),sha256=sha(raw))
    save('profile-before-gate.json',report);print(json.dumps(report,sort_keys=True),flush=True)
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['ops']<=8192
    assert profile['max_blocks']<=256 and profile['max_block_params']<=16
    source=render_assembly(doc).encode();(OUT/'source.hiaasm').write_bytes(source)
    program=assemble_program(source)
    report['source']=dict(bytes=len(source),sha256=sha(source))
    # Only the exact predecessor HIA image creates the new native image.
    pin(CHILD);report['B3_entries']=1
    image,receipt=compile_stage(OUT,'dms-fixed-headers',COMPILER,source)
    assert receipt['limits']==dict(address_bytes=256<<20,cpu_seconds=10,core_dumpable=False,stack_bytes=8<<20,output_capacity=1<<20,workspace_bytes=1<<20)
    assert receipt['input_sha256']==sha(source) and receipt['artifact_sha256']==sha(COMPILER.read_bytes())
    report['compile']=receipt;report['image']=dict(path=str(image),bytes=image.stat().st_size,sha256=sha(image.read_bytes()))
    report['status']='PASS_LOCAL_GENERATION_AND_B3_ONLY'
except BaseException as error:
    report.update(status='FAIL',exception=repr(error),traceback=traceback.format_exc())
    raise
finally:
    for p in list(pins):pin(p)
    report['source_pins_unchanged']=True;report['wall_elapsed_ns']=time.monotonic_ns()-started
    save('source-after.json',pins);save('summary.json',report)
    print(json.dumps(report,sort_keys=True),flush=True)
