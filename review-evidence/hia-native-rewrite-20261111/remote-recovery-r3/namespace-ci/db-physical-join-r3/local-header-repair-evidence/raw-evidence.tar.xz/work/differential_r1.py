"""Exact old/new DMS8 VM and new actual native header/state differential.

All state and output bytes, errors, inputs and canaries are compared. This
private malformed-frame corpus owns no external capability and issues no OS
filesystem operation. Full six-role physical validation is a separate gate.
"""
from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import ast,ctypes,gzip,hashlib,json,random,resource,signal,struct,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REF=ROOT.parent/'reference-0ef-development-104'
sys.path.insert(0,str(REF))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
signal.signal(signal.SIGALRM,lambda a,b:(_ for _ in ()).throw(TimeoutError('differential whole process wall180')))
signal.alarm(180)
from hepta.hia_program import verify_program
from hepta.hia_program_runtime import _Machine,_Owner,_View
from hepta.hia_json_preflight_native import NativeHiaJsonImage
OUT=ROOT/'differential-r1';OUT.mkdir(exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
pins={}
def pin(path,expected=None):
    p=Path(path);b=p.read_bytes();row=dict(bytes=len(b),sha256=sha(b),mode=p.stat().st_mode&0o777)
    if expected is not None:assert row['sha256']==expected
    if str(p) in pins:assert pins[str(p)]==row
    pins[str(p)]=row;return b
oldraw=pin(ROOT/'diagnostic-r2/role-4.json','e726927fe28cd72744778f2ae91ae616a205efcf95eac5516de192018b95e037')
newraw=pin(ROOT/'candidate-r1-generation-compile-r2/document.json','57eb28a962406c720ed230169f2fb33979b937082eec93030c0cdc2e49577f48')
old=verify_program(json.loads(oldraw));new=verify_program(json.loads(newraw))
oldfn=old.as_dict()['functions'][0];newfn=new.as_dict()['functions'][0]
image_path=ROOT/'candidate-r1-generation-compile-r2/dms-fixed-headers.image.bin'
image_raw=pin(image_path,'6996d832efd0e8458da9d98b5343fcab2d6e0b81084893c92f1eafdec3c1117e')
native=NativeHiaJsonImage(image_raw,sha(image_raw))
fs_path=ROOT.parent/'dms5-follow27-original/inner/run/namespace-dms-r5/validation-r1/compile/namespace-fs-lifetime-r1.image.bin'
fsraw=pin(fs_path,'76aee244c79b2d54bdc0c591d222f0265db6e476878901875704575dd52ee070')
fsnative=NativeHiaJsonImage(fsraw,sha(fsraw))
for p in sorted(REF.rglob('*.py')):pin(p)
pin(__file__);save('source-before.json',pins)
libc=ctypes.CDLL(None,use_errno=True)
libc.mmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_long];libc.mmap.restype=ctypes.c_void_p
libc.mprotect.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int];libc.mprotect.restype=ctypes.c_int
libc.munmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t];libc.munmap.restype=ctypes.c_int
CANARY=bytes(range(16))
class Buffer:
    def __init__(self,b,readonly=False):
        self.size=len(b);self.middle=(self.size+32+4095)&~4095;self.total=self.middle+8192
        self.raw=libc.mmap(None,self.total,0,0x22,-1,0)
        if self.raw==ctypes.c_void_p(-1).value:raise OSError(ctypes.get_errno(),'mmap')
        self.base=self.raw+4096;self.address=self.base+16
        try:
            if libc.mprotect(self.base,self.middle,3):raise OSError(ctypes.get_errno(),'mprotect RW')
            ctypes.memmove(self.base,CANARY,16)
            if b:ctypes.memmove(self.address,b,len(b))
            ctypes.memmove(self.address+self.size,CANARY,16)
            if readonly and libc.mprotect(self.base,self.middle,1):raise OSError(ctypes.get_errno(),'mprotect RO')
        except BaseException:
            libc.munmap(self.raw,self.total);raise
    def read(self):return ctypes.string_at(self.address,self.size)
    def check(self):
        assert ctypes.string_at(self.base,16)==CANARY and ctypes.string_at(self.address+self.size,16)==CANARY
    def close(self):
        if libc.munmap(self.raw,self.total):raise OSError(ctypes.get_errno(),'munmap')
def vm(program,entry,s,o,w):
    owners=[_Owner(-1,bytearray(s)),_Owner(-2,bytearray(o)),_Owner(-3,bytearray(w))]
    m=_Machine(program,4000000,32<<20,None,64)
    try:
        value=m.invoke(entry,[_View(owners[0],False),_View(owners[1],True),_View(owners[2],True)])[0]
        outcome=dict(returned=value)
    except BaseException as error:
        outcome=dict(exception_type=type(error).__name__,exception_text=str(error),exception_code=getattr(error,'code',None))
    assert bytes(owners[0].data)==s
    return outcome,bytes(owners[1].data),bytes(owners[2].data),m.steps,m.resources()
def actual(image,s,o,w):
    buffers=[]
    try:
        for raw,ro in ((s,True),(o,False),(w,False)):buffers.append(Buffer(raw,ro))
        a,b,c=buffers
        result=int(image._entry(a.address,a.size,b.address,b.size,c.address,c.size))
        for x in buffers:x.check()
        assert a.read()==s
        return dict(returned=result),b.read(),c.read()
    finally:
        for b in reversed(buffers):b.close()
MAGIC=int.from_bytes(b'HIANDM03','little');CHANNEL=int.from_bytes(b'HIANDX03','little');BAD=0xfffffffd
def packet(words,body=b''):return struct.pack('<32Q',*(list(words)+[0]*(32-len(words))))+body
def channel(raw,origin=1,role=0,result=0,serial=0,page=4096):return struct.pack('<8Q',CHANNEL,origin,role,result,len(raw),serial,page,0)+raw
def mutate(raw,offset,value):
    b=bytearray(raw);struct.pack_into('<Q',b,offset,value);return bytes(b)
def pattern(n):return bytes((i*17+3)%256 for i in range(n))
report=dict(status='INCOMPLETE',scope='PRIVATE_F0_HEADER_AND_STATE_EQUIVALENCE',cases=0,old_VM_entries=0,new_VM_entries=0,new_native_entries=0,actual_FS_seed_entries=0,
    actual_OS_syscalls=0,ordinary_store_closed=False,full_six_role_physical_gate=False,resource_counters_equal=True,steps_required_equal=False,
    limits=dict(cpu_seconds=90,wall_seconds=180,address_bytes=1<<30,VM_steps=4000000,VM_arena_bytes=32<<20))
started=time.monotonic_ns();names=set();ledger=gzip.open(OUT/'cases.jsonl.gz','wt',encoding='utf-8')
def compare(label,s,w,o=None):
    if o is None:o=pattern(1280)
    assert label not in names;names.add(label)
    a=vm(old,oldfn,s,o,w);report['old_VM_entries']+=1
    b=vm(new,newfn,s,o,w);report['new_VM_entries']+=1
    row=dict(label=label,input_hex=s.hex(),pre_output_hex=o.hex(),pre_workspace_hex=w.hex(),
        old=dict(outcome=a[0],output_hex=a[1].hex(),workspace_hex=a[2].hex(),steps=a[3],resources=a[4]),
        new=dict(outcome=b[0],output_hex=b[1].hex(),workspace_hex=b[2].hex(),steps=b[3],resources=b[4]))
    try:
        assert a[:3]==b[:3],label
        assert a[4]==b[4],label
        # All constructed cases have defined returned outcomes; a trap is a
        # real failure of this corpus, not silently omitted native evidence.
        assert set(a[0])=={'returned'},(label,a[0])
        n=actual(native,s,o,w);report['new_native_entries']+=1
        row['native']=dict(outcome=n[0],output_hex=n[1].hex(),workspace_hex=n[2].hex(),all_canaries=True,source_readonly_unchanged=True)
        assert n==a[:3],label
        row['equal']=True;report['cases']+=1
        return a
    finally:
        ledger.write(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n');ledger.flush()
        if report['cases']%50==0:save('progress.json',report);print(json.dumps(report,sort_keys=True),flush=True)
try:
    init=channel(packet([MAGIC,1,71,83,0,0,0,0,941,953,0,0,0,3,420,3]))
    initial=compare('valid-init',init,bytes(8192));assert initial[0]['returned']==1
    fs_input=initial[1][256:512]
    fs_outcome,fsout,fswork=actual(fsnative,fs_input,bytes(256),bytes(512));report['actual_FS_seed_entries']+=1
    assert fs_outcome=={'returned':0}
    (OUT/'actual-fs-seed-input.bin').write_bytes(fs_input);(OUT/'actual-fs-seed-output.bin').write_bytes(fsout);(OUT/'actual-fs-seed-workspace.bin').write_bytes(fswork)
    ack=channel(packet([MAGIC,8,71,83,0,1,0,1,256,256,512,0,1,0,0,0,1024],fs_input+fsout+fswork),2,1,0,1)
    steady=compare('actual-fs-init-completion',ack,initial[2]);assert steady[0]['returned']==0
    probe=channel(packet([MAGIC,3,71,83,1,0,1001,1]))
    compare('missing-row-request',probe,steady[2])
    for size in range(320):compare('short-source-'+str(size),init[:size],bytes(8192))
    for size in (0,1,7,8,15,16,255,256,8191):compare('short-workspace-'+str(size),init,bytes(size))
    for size in (0,1,7,255,256,511,1279,1280):compare('output-size-'+str(size),init,bytes(8192),pattern(size))
    for offset in range(0,320,8):
        for value in (0,(1<<64)-1):compare('ack-header-'+str(offset)+'-'+str(value),mutate(ack,offset,value),initial[2])
    # Exercise the exact constant workspace offsets whose reads may be eager.
    source=(ROOT/'original/tools/generate_hia_agent_namespace_dms_map_join_r8.py').read_text()
    # The original DSL was already separately frozen and compared unchanged.
    spec={}
    import importlib.util
    p=ROOT/'original/tools/generate_hia_agent_namespace_dms_map_join_r8.py'
    sys.path.insert(0,str(ROOT/'original'))
    ms=importlib.util.spec_from_file_location('frozen_old_dms',p);m=importlib.util.module_from_spec(ms);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__)
    offsets=sorted({n.args[1].value for n in ast.walk(ast.parse(m.source_program())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='get' and len(n.args)==2 and isinstance(n.args[0],ast.Name) and n.args[0].id=='w' and isinstance(n.args[1],ast.Constant) and type(n.args[1].value) is int and 0<=n.args[1].value<=8184})
    report['fixed_workspace_offsets']=offsets
    for offset in offsets:
        compare('workspace-word-'+str(offset),probe,mutate(steady[2],offset,(1<<64)-1))
    for value in (0,1,2,3,4,4096,1<<30,(1<<30)+1,1<<63,(1<<64)-1):
        compare('page-'+str(value),mutate(init,48,value),bytes(8192))
    rng=random.Random(0x4849414e)
    for i in range(64):
        raw=ack if i%2 else probe;work=initial[2] if i%2 else steady[2]
        for _ in range(1+i%3):raw=mutate(raw,rng.randrange(40)*8,rng.getrandbits(64))
        if i%3==0:work=mutate(work,rng.choice(offsets),rng.getrandbits(64))
        compare('random-'+str(i),raw,work)
    report['status']='PASS'
except BaseException as error:
    report.update(status='FAIL',exception=repr(error),traceback=traceback.format_exc());raise
finally:
    ledger.close();native._mapping.close();fsnative._mapping.close()
    for p in list(pins):pin(p)
    report['source_pins_unchanged']=True;report['wall_elapsed_ns']=time.monotonic_ns()-started
    report['cpu_usage']=dict(user=resource.getrusage(resource.RUSAGE_SELF).ru_utime,system=resource.getrusage(resource.RUSAGE_SELF).ru_stime)
    raw=(OUT/'cases.jsonl.gz').read_bytes();report['ledger']=dict(bytes=len(raw),sha256=sha(raw))
    save('summary.json',report);save('source-after.json',pins)
    print(json.dumps(report,sort_keys=True),flush=True)
