from pathlib import Path
import ast,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'candidate-r1'),str(ROOT.parent/'reference-0ef-development-104')]
from tools import generate_hia_agent_namespace_dms_map_join_r8 as candidate
from tools.hia_namespace_dms_fixed_header_builder import fixed_header_origins,FixedHeaderBuilder
from tools.generate_hia_selfhost import total_scalar_functions
def sha(b):return hashlib.sha256(b).hexdigest()
p=ROOT/'original/tools/generate_hia_agent_namespace_dms_map_join_r8.py'
spec=importlib.util.spec_from_file_location('proof_original_dms',p);original=importlib.util.module_from_spec(spec)
exec(compile(p.read_bytes(),str(p),'exec'),original.__dict__)
source=candidate.source_program();assert source==original.source_program()
nodes=ast.parse(source).body;origins,bindings=fixed_header_origins(source,nodes)
names={n.name:'f'+str(i) for i,n in enumerate(nodes)}
sigs={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes}
total=total_scalar_functions(nodes)
builders={n.name:FixedHeaderBuilder(n,names,sigs,total,origins) for n in nodes}
controls=[]
def check(fn,text,expected):
    actual=builders[fn].total_scalar_expression(ast.parse(text,mode='eval').body)
    assert actual is expected,(fn,text,actual,expected)
    controls.append(dict(function=fn,expression=text,expected=expected,actual=actual))
for text,value in [('get(w, 0)',True),('get(w, 8184)',True),('get(w, 8185)',False),
                   ('get(w, at)',False),('read64(s, 312)',True),('read64(s, 313)',False),
                   ('dms_read(s, 248)',True),('dms_read(s, 249)',False),('get(o, 0)',False),
                   ('dms_length(s)',True),('1 << 63',True),('1 << 64',False)]:check('dms_owner',text,value)
check('dms_entry','read64(s, 0)',False)
check('dms_entry','dms_read(s, 0)',False)
check('dms_entry','dms_length(s)',True)
check('get','get(w, 0)',True)
check('put','get(w, 0)',False)
builders['dms_owner'].env['fixture32']=('not-emitted','u32')
check('dms_owner','fixture32 << 63',False)
for changed in (source+'\n',source.replace('length(w) < 8192','length(w) < 8191',1)):
    try:fixed_header_origins(changed,ast.parse(changed).body)
    except ValueError as error:controls.append(dict(source_drift_refused=True,exception=str(error)))
    else:raise AssertionError('changed guard/source was accepted')
before=json.loads((ROOT/'diagnostic-r2/role-4.json').read_bytes())
after=json.loads((ROOT/'candidate-r1-generation-compile-r2/document.json').read_bytes())
def signature(fn):return {k:v for k,v in fn.items() if k!='blocks'}
assert [signature(f) for f in before['functions']]==[signature(f) for f in after['functions']]
assert len(before['functions'])==len(after['functions'])==72
original_profile=json.loads((ROOT/'diagnostic-r2/old-profiles.json').read_bytes())['4']
new=json.loads((ROOT/'candidate-r1-generation-compile-r2/summary.json').read_bytes())
report=dict(status='PASS_STATIC_PRECONDITION_READBACK',ordinary_store_closed=False,
    original_profile=original_profile,new_profile=new['profile'],DSL_bytes=len(source.encode()),DSL_sha256=sha(source.encode()),
    original_DSL_unchanged=True,all_72_function_names_signatures_effects_and_entry_preserved=True,
    whole_source_guard_pinned=True,fixed_buffer_alias_origins={n:{k:sorted(v) for k,v in bs.items()} for n,bs in origins.items()},
    direct_buffer_call_bindings=bindings,controls=controls,controls_count=len(controls),native_entries=0,VM_entries=0,
    original_failure=dict(run=43154093882,job=130969885094,role=4,
        original_document_bytes=1129022,original_document_sha256='e726927fe28cd72744778f2ae91ae616a205efcf95eac5516de192018b95e037',
        original_author_sha256='1e687d80d69d4ea69a5be15add0a41f18c0119ee721d6dda1e8dcd7450d0ea8d',
        failed_gate='blocks 1866 > 1536',failure_preserved=True))
(ROOT/'proof-readback-r2.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('fixed_buffer_alias_origins','direct_buffer_call_bindings','controls')},sort_keys=True))
