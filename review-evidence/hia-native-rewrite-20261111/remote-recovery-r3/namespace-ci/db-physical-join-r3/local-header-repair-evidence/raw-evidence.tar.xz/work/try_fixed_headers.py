from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import ast,hashlib,importlib,json,resource,signal
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/"original"),str(ROOT.parent/"reference-0ef-subset")]
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
signal.signal(signal.SIGALRM,lambda a,b:(_ for _ in ()).throw(TimeoutError("diagnostic wall180")))
signal.alarm(180)
from tools.generate_hia_agent_namespace_objects import ObjectBuilder
from tools.generate_hia_selfhost import total_scalar_functions,compact_authoring_cfg
from hepta.hia_agent_assembly import render_assembly,assemble_program
from tools import generate_hia_agent_namespace_dms_map_join_r8 as author
OUT=ROOT/"fixed-header-prototype-r1";OUT.mkdir(exist_ok=False)
class FixedHeaderBuilder(ObjectBuilder):
 def __init__(self,node,*args):
  self.source_function=node.name
  super().__init__(node,*args)
 def total_scalar_expression(self,e):
  if isinstance(e,ast.Call) and isinstance(e.func,ast.Name) and not e.keywords:
   if e.func.id=="length" and len(e.args)==1 and isinstance(e.args[0],ast.Name) and e.args[0].id in ("s","o","w"):
    return True
   if e.func.id=="dms_length" and len(e.args)==1 and isinstance(e.args[0],ast.Name) and e.args[0].id=="s":
    return True
   if len(e.args)==2 and isinstance(e.args[0],ast.Name) and isinstance(e.args[1],ast.Constant) and type(e.args[1].value) is int:
    name=e.func.id;buf=e.args[0].id;offset=e.args[1].value
    if name=="get" and buf=="w" and 0<=offset<=8184:return True
    if self.source_function!="dms_entry":
     if name=="read64" and buf=="s" and 0<=offset<=312:return True
     if name=="dms_read" and buf=="s" and 0<=offset<=248:return True
  if isinstance(e,ast.BinOp) and isinstance(e.op,(ast.LShift,ast.RShift)) and isinstance(e.right,ast.Constant) and type(e.right.value) is int and 0<=e.right.value<64:
   return self.total_scalar_expression(e.left)
  return super().total_scalar_expression(e)
nodes=ast.parse(author.source_program()).body
byname={n.name:n for n in nodes}
# Every same-call source/workspace parameter is passed unchanged through the
# whole authoring graph. This check rejects alias substitution or helper reuse.
bindings=[]
for n in nodes:
 for call in ast.walk(n):
  if isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id in byname:
   target=byname[call.func.id]
   for formal,actual in zip(target.args.args,call.args,strict=True):
    if formal.arg in ("s","w") and formal.annotation.id in ("readbuf","mutbuf"):
     assert isinstance(actual,ast.Name) and actual.id==formal.arg,(n.name,call.func.id,formal.arg,ast.dump(actual))
     bindings.append([n.name,call.func.id,formal.arg])
names={n.name:"f"+str(i) for i,n in enumerate(nodes)}
sigs={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes}
total=total_scalar_functions(nodes);functions=[]
for n in nodes:
 b=FixedHeaderBuilder(n,names,sigs,total);b.statements(n.body)
 functions.append(dict(name=names[n.name],params=[b.param(x) for x in b.params],
   returns=[b.returns],effects=["read","write","trap"],entry="b0",blocks=b.blocks))
doc=compact_authoring_cfg(dict(schema="hepta.hia.program.v8",module="agent_namespace_dms_map_join_r8",functions=functions))
raw=(json.dumps(doc,sort_keys=True,separators=(",",":"))+"\n").encode()
(OUT/"document.json").write_bytes(raw)
profile=dict(functions=len(functions),blocks=sum(len(f["blocks"]) for f in doc["functions"]),
 ops=sum(len(b["ops"]) for f in doc["functions"] for b in f["blocks"]),
 max_blocks=max(len(f["blocks"]) for f in doc["functions"]),
 max_block_params=max(len(b["params"]) for f in doc["functions"] for b in f["blocks"]))
source=render_assembly(doc).encode();(OUT/"source.hiaasm").write_bytes(source)
assemble_program(source)
report=dict(status="PROFILE_EXPERIMENT_NOT_QUALIFIED",profile=profile,
 document_sha256=hashlib.sha256(raw).hexdigest(),document_bytes=len(raw),
 source_bytes=len(source),source_sha256=hashlib.sha256(source).hexdigest(),
 same_call_buffer_bindings=bindings,
 functions=[dict(source_name=n.name,name=names[n.name],blocks=len(f["blocks"]),
  ops=sum(len(b["ops"]) for b in f["blocks"])) for n,f in zip(nodes,doc["functions"],strict=True)],
 VM_entries=0,B3_entries=0,native_entries=0)
(OUT/"summary.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k not in ("same_call_buffer_bindings","functions")},sort_keys=True),flush=True)
