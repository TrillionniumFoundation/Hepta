"""Fresh VM timing on one previously completed recorded native case; zero native executions."""
from __future__ import annotations
import hashlib,importlib.util,json,os,resource,signal,stat,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
SOURCE_ROOT=Path("/workspace/scratch/9acdfa9f5639/runtime-development/nine-role-local-r4")
REFERENCE=Path("/workspace/scratch/9acdfa9f5639/reference0ef")
def sha(raw):return hashlib.sha256(raw).hexdigest()
def identity(path):
 st=path.lstat();assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
 raw=path.read_bytes()
 return dict(bytes=len(raw),sha256=sha(raw),mode=stat.S_IMODE(st.st_mode),gitsha=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest())
def save(path,value):
 raw=(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
 path.write_bytes(raw);assert path.read_bytes()==raw
def main():
 started=time.monotonic_ns();cpu0=time.process_time_ns()
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 def timeout(signum,frame):raise TimeoutError("diagnostic original180wall")
 signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,180)
 pins={};primary=None;rep=None;report=dict(scope="NEW_VM_DIAGNOSTIC_ORIGINAL_RECORDED_CASE_NOT_FRESH_NATIVE_QUALIFICATION",status="INCOMPLETE",native_executions=0,B3=0,new_fixed_processes=0,original_raw_prefix_group_still_FAIL=True)
 def pin(path,expected=None):
  path=Path(path);r=identity(path)
  if expected is not None:assert r["sha256"]==expected
  pins[str(path)]=r;return path.read_bytes()
 try:
  assert sys.version_info[:3]==(3,12,14)
  pin(__file__);timed=ROOT/"timed_replay.py";raw=pin(timed)
  spec=importlib.util.spec_from_file_location("diagnostic_frozen_replay",timed);rep=importlib.util.module_from_spec(spec);sys.modules[spec.name]=rep;exec(compile(raw,str(timed),"exec"),rep.__dict__)
  build_path=SOURCE_ROOT/"evidence/actual-unixopen-build-r1/summary.json"
  build=json.loads(pin(build_path));assert build["status"]=="PASS_BUILD_ONLY" and build["fresh_role_compiles"]==9 and build["packer_entries"]==45
  sys.path.insert(0,str(REFERENCE))
  from hepta.hia_agent_assembly import assemble_program
  program_CPU=time.process_time_ns();programs={}
  for text,row in sorted(build["exact_roles"].items(),key=lambda x:int(x[0])):
   raw=pin(row["source"]["path"],row["source"]["sha256"])
   assert len(raw)==row["source"]["bytes"]
   programs[int(text)]=assemble_program(raw)
  report["nine_original_source_assembly_CPU_ns"]=time.process_time_ns()-program_CPU
  original=SOURCE_ROOT/"evidence/actual-unixopen-raw-prefix-r1/cases/main_PID_match"
  destination=ROOT/"recorded-case";destination.mkdir()
  for path in sorted(original.rglob("*")):
   rel=path.relative_to(original)
   if rel.parts[0]=="full-native-VM-replay":continue
   st=path.lstat()
   if stat.S_ISDIR(st.st_mode):continue
   assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
   raw=pin(path);target=destination/rel;target.parent.mkdir(parents=True,exist_ok=True)
   with target.open("xb") as f:f.write(raw)
   target.chmod(stat.S_IMODE(st.st_mode));assert target.read_bytes()==raw
   pin(target)
  for module in tuple(sys.modules.values()):
   path=getattr(module,"__file__",None)
   if path:
    p=Path(path).resolve()
    if p.is_relative_to(REFERENCE) and p.suffix==".py":pin(p)
  timers={name:dict(CPU_ns=0,calls=0) for name in ["CAS_put","CAS_readback","save_json","decode_next_record"]}
  def timed_call(name,fn):
   def wrapped(*a,**kw):
    t=time.process_time_ns()
    try:return fn(*a,**kw)
    finally:timers[name]["CPU_ns"]+=time.process_time_ns()-t;timers[name]["calls"]+=1
   return wrapped
  rep.CAS.put=timed_call("CAS_put",rep.CAS.put)
  rep.CAS.readback=timed_call("CAS_readback",rep.CAS.readback)
  rep.save=timed_call("save_json",rep.save)
  original_records=rep.records
  def measured_records(path):
   iterator=iter(original_records(path))
   while True:
    t=time.process_time_ns()
    try:row=next(iterator)
    except StopIteration:return
    finally:timers["decode_next_record"]["CPU_ns"]+=time.process_time_ns()-t;timers["decode_next_record"]["calls"]+=1
    yield row
  rep.records=measured_records
  replay_CPU=time.process_time_ns();replay_wall=time.monotonic_ns()
  result=rep.replay(destination,programs)
  replay_CPU=time.process_time_ns()-replay_CPU;replay_wall=time.monotonic_ns()-replay_wall
  assert result["status"]=="PASS" and result["VM_entries"]==result["native_entries"]==31
  assert result["all_native_return_output_workspace_bytes_equal"] and result["no_field_mask"]
  windows=rep.DIAGNOSTIC_WINDOWS;assert len(windows)==31
  by_role={}
  for row in windows:
   acc=by_role.setdefault(str(row["role"]),dict(windows=0,steps=0,as_dict_CPU_ns=0,Machine_init_CPU_ns=0,invoke_CPU_ns=0))
   acc["windows"]+=1
   for k in ["steps","as_dict_CPU_ns","Machine_init_CPU_ns","invoke_CPU_ns"]:acc[k]+=row[k]
  report.update(status="PASS_DIAGNOSTIC_ONLY",replay_result=result,measured_replay_CPU_ns=replay_CPU,measured_replay_elapsed_ns=replay_wall,timers=timers,windows=windows,by_role=by_role,
    source_assembly_performed_once_per_role=True,source_reassembly_in_entry=False,fresh_Machine_every_entry=True,
    all_recorded_return_output_workspace_bytes_equal=True,unchanged_VM_limits=dict(steps=4000000,arena_bytes=32<<20,depth=64),
    group12_success_claimed=False,timer_overhead_included=True)
 except BaseException as exc:
  primary=exc;report.update(status="FAIL",error_class=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
  traceback.print_exc()
 finally:
  if rep is not None:report["completed_window_measurements"]=rep.DIAGNOSTIC_WINDOWS
  after={};errors=[]
  for path,expected in pins.items():
   try:
    observed=identity(Path(path));after[path]=observed;assert observed==expected
   except BaseException as exc:
    after[path]=dict(error=repr(exc));errors.append(dict(path=path,error=repr(exc)))
    if primary is None:primary=exc
    else:primary.add_note("after: "+repr(exc))
  report["source_before"]=pins;report["source_after"]=after;report["after_errors"]=errors
  report["CPU_ns_before_final_output"]=time.process_time_ns()-cpu0
  report["elapsed_ns_before_final_output"]=time.monotonic_ns()-started
  if primary is not None:report["status"]="FAIL"
  try:
   save(ROOT/"summary.json",report)
   print(json.dumps({k:report[k] for k in ["status","native_executions","B3","CPU_ns_before_final_output","elapsed_ns_before_final_output"]},sort_keys=True),flush=True)
   assert 0<=time.process_time_ns()-cpu0<90_000_000_000
   assert 0<=time.monotonic_ns()-started<180_000_000_000
  except BaseException as exc:
   if primary is None:primary=exc
   else:primary.add_note("final output/budget: "+repr(exc))
  if primary is not None:
   report.update(status="FAIL",final_error=repr(primary))
   try:save(ROOT/"summary.json",report)
   except BaseException as exc:primary.add_note("FAIL receipt: "+repr(exc))
  signal.setitimer(signal.ITIMER_REAL,0)
 if primary is not None:raise primary
if __name__=="__main__":main()
