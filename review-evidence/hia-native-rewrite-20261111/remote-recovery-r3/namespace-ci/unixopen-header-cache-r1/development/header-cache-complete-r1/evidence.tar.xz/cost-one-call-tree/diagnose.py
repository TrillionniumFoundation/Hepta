"""One recorded role9 window with inclusive/exclusive HIA-call step accounting; no native calls."""
from __future__ import annotations
import ast,hashlib,importlib.util,json,resource,signal,sys,time,traceback,types
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
BASE=Path("/workspace/scratch/9acdfa9f5639/runtime-development/nine-role-local-r4")
REFERENCE=Path("/workspace/scratch/9acdfa9f5639/reference0ef")
def sha(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 p=Path(p);b=p.read_bytes()
 return dict(bytes=len(b),sha256=sha(b),mode=p.stat().st_mode&0o777,gitsha=hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest())
def save(p,d):
 raw=(json.dumps(d,sort_keys=True,indent=2)+"\n").encode();p.write_bytes(raw);assert p.read_bytes()==raw
def main():
 start=time.monotonic_ns();CPU=time.process_time_ns();primary=None;report=dict(status="INCOMPLETE",scope="ONE_RECORDED_WINDOW_HIA_CALL_COST_DIAGNOSTIC_NOT_QUALIFICATION",native=0,B3=0)
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 def timeout(*a):raise TimeoutError("diagnostic180wall")
 signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,180)
 pins={}
 def pin(p):
  p=Path(p);pins[str(p)]=ident(p);return p.read_bytes()
 def load(name,p):
  raw=pin(p);spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;exec(compile(raw,str(p),"exec"),m.__dict__);return m
 try:
  pin(__file__)
  sys.path[:0]=[str(BASE/"source"),str(REFERENCE)]
  from hepta.hia_agent_assembly import assemble_program
  from hepta.hia_program_runtime import _Machine,_Owner,_View
  replay=load("recorded_window_decoder",BASE/"source/inputs/actual-unixopen-replay.py")
  assert ident(BASE/"source/inputs/actual-unixopen-replay.py")["gitsha"]=="b8854ced763c3df029137ae0e82e586e5f20ea55"
  build=json.loads(pin(BASE/"evidence/actual-unixopen-build-r1/summary.json"));row=build["exact_roles"]["9"]
  source=pin(row["source"]["path"]);assert sha(source)==row["source"]["sha256"]
  program=assemble_program(source);document=program.as_dict()
  author=load("fixed_role9_author_for_names_only",BASE/"source/tools/generate_hia_unixopen_issued_raw_join.py")
  nodes=ast.parse(author.source_program()).body
  assert len(nodes)==len(document["functions"])
  names={"f"+str(i):n.name for i,n in enumerate(nodes)}
  trace=BASE/"evidence/actual-unixopen-raw-prefix-r1/cases/main_PID_match/trace.bin";pin(trace)
  selected=None;expected=None
  for r in replay.records(trace):
   if r["role"]==9 and r["kind"]==1 and r["header"][2]==9:selected=r
   if selected is not None and r["role"]==9 and r["kind"]==2 and r["header"][2]==9:expected=r;break
  assert selected is not None and expected is not None
  owners=[_Owner(-1,bytearray(selected["input"])),_Owner(-2,bytearray(selected["output"])),_Owner(-3,bytearray(selected["workspace"]))]
  machine=_Machine(program,4000000,32<<20,None,64);original=_Machine.invoke
  stack=[];calls={}
  def measured(self,fn,arguments,depth=0):
   frame=dict(start_CPU=time.process_time_ns(),start_steps=self.steps,child_CPU=0,child_steps=0)
   stack.append(frame)
   try:return original(self,fn,arguments,depth)
   finally:
    deltaCPU=time.process_time_ns()-frame["start_CPU"];deltaSteps=self.steps-frame["start_steps"]
    assert stack.pop() is frame
    acc=calls.setdefault(fn["name"],dict(name=names[fn["name"]],calls=0,inclusive_CPU_ns=0,self_CPU_ns=0,inclusive_steps=0,self_steps=0))
    acc["calls"]+=1;acc["inclusive_CPU_ns"]+=deltaCPU;acc["self_CPU_ns"]+=deltaCPU-frame["child_CPU"];acc["inclusive_steps"]+=deltaSteps;acc["self_steps"]+=deltaSteps-frame["child_steps"]
    if stack:stack[-1]["child_CPU"]+=deltaCPU;stack[-1]["child_steps"]+=deltaSteps
  machine.invoke=types.MethodType(measured,machine)
  invoke_start=time.process_time_ns();ret=machine.invoke(document["functions"][0],[_View(owners[0],False),_View(owners[1],True),_View(owners[2],True)])[0];elapsed=time.process_time_ns()-invoke_start
  assert ret==expected["header"][6] and bytes(owners[0].data)==selected["input"]
  assert bytes(owners[1].data)==expected["output"] and bytes(owners[2].data)==expected["workspace"]
  assert machine.steps==1826611 and sum(c["self_steps"] for c in calls.values())==machine.steps
  for name,b in [("input.bin",selected["input"]),("pre-output.bin",selected["output"]),("pre-workspace.bin",selected["workspace"]),("actual-output.bin",expected["output"]),("actual-workspace.bin",expected["workspace"])]:
   (ROOT/name).write_bytes(b);assert (ROOT/name).read_bytes()==b
  report.update(status="PASS_DIAGNOSTIC_ONLY",role=9,entry_serial=9,recorded_offset=selected["offset"],fresh_VM=1,steps=machine.steps,resources=machine.resources(),
   all_input_return_output_workspace_equal=True,invoke_CPU_ns_instrumented=elapsed,
   call_costs=calls,instrumentation_overhead_included=True,not_a_performance_qualification=True)
  for m in tuple(sys.modules.values()):
   f=getattr(m,"__file__",None)
   if f:
    p=Path(f).resolve()
    if (p.is_relative_to(REFERENCE) or p.is_relative_to(BASE/"source")) and p.suffix==".py":pin(p)
 except BaseException as exc:
  primary=exc;report.update(status="FAIL",error=repr(exc),traceback=traceback.format_exc());traceback.print_exc()
 finally:
  after={};errors=[]
  for p,old in pins.items():
   try:after[p]=ident(p);assert after[p]==old
   except BaseException as exc:
    errors.append(dict(path=p,error=repr(exc)))
    if primary is None:primary=exc
    else:primary.add_note("after: "+repr(exc))
  report.update(source_before=pins,source_after=after,after_errors=errors)
  if primary is not None:report["status"]="FAIL"
  try:
   save(ROOT/"summary.json",report);print(json.dumps({k:report.get(k) for k in ["status","role","entry_serial","fresh_VM","steps","native","B3","invoke_CPU_ns_instrumented"]},sort_keys=True),flush=True)
   assert 0<=time.process_time_ns()-CPU<90_000_000_000 and 0<=time.monotonic_ns()-start<180_000_000_000
  except BaseException as exc:
   if primary is None:primary=exc
   else:primary.add_note("final: "+repr(exc))
  if primary is not None:
   report.update(status="FAIL",final_error=repr(primary))
   try:save(ROOT/"summary.json",report)
   except BaseException as exc:primary.add_note("failure receipt:"+repr(exc))
  signal.setitimer(signal.ITIMER_REAL,0)
 if primary is not None:raise primary
if __name__=="__main__":main()
