def local_exact_subject():
 phase_start=None
 try:
  phase_start=time.monotonic_ns()
  details["subject_phase"]=dict(started_monotonic_ns=phase_start,limit_ns=900_000_000_000,
   end_boundary="after every group, original report export and complete subject source-after checks; before independent seal")
  save(evidence/"subject-phase.json",details["subject_phase"])
  def remaining():
   value=900-(time.monotonic_ns()-phase_start)/1_000_000_000
   if value<=0:raise TimeoutError("actual UnixOpen original900 aggregate")
   return value
  def run(label,argv,relative=None,*,cpu=90,wall=180,address=1<<30):
   failure=None;receipt=None
   command=[str(prlimit),"--cpu="+str(cpu)+":"+str(cpu),
    "--as="+str(address)+":"+str(address),"--core=0:0","--",*map(str,argv)]
   try:
    receipt=common.run(label,command,cwd=context["reference"],
     timeout=min(wall,remaining()),env=env)
    details["process_receipts"].append(dict(label=label,receipt=receipt,
     enforced_parent_kernel_limit=dict(CPU_seconds=cpu,address_bytes=address,core_bytes=0)))
    used=receipt["child_cpu_seconds"];elapsed=receipt["elapsed_ns"]
    assert type(used) in (int,float) and 0<=used<cpu,(label,"complete process tree CPU",used,cpu)
    assert type(elapsed) is int and 0<=elapsed<wall*1_000_000_000,(label,"complete process wall",elapsed,wall)
   except BaseException as error:failure=error
   finally:
    output_paths=[common.OUTPUT/"steps"/label/name for name in ("process.json","stdout.log","stderr.log")]
    if relative is not None:output_paths.append(evidence/relative)
    for path in output_paths:
     if path.is_file():
      try:ev.original(path)
      except BaseException as error:
       if failure is None:failure=error
       else:failure.add_note("raw original export "+str(path)+": "+repr(error))
   if failure is not None:raise failure
   return receipt
  def report(relative,status):
   path=evidence/relative;raw=ev.original(path)
   row,_=identity(path);details["original_report_pins"].append(row)
   value=json.loads(raw)
   assert value["status"]==status,(relative,value)
   return value
  run("actual-ui-original-ten-DMS10-source-proofs",
   [context["python"],"-B",paths["validate-dms10-header-proof.py"],
    "--directory",working/"inputs","--output",evidence/"dms10-source-proof"],
   "dms10-source-proof/summary.json",cpu=10,wall=30,address=256<<20)
  proof=report("dms10-source-proof/summary.json","PASS_SOURCE_PROOF_ONLY")
  assert len(proof["controls"])==10 and proof["source_unchanged"]
  for flag in ("one_literal_delta_reversed_byte_identically","origin_bindings_equal",
    "original_builder_class_byte_identical","original_origin_propagation_byte_identical"):
   assert proof[flag] is True
  assert proof["new_HIA_generation"]==proof["new_B3_compiles"]==proof["new_VM_entries"]==proof["new_native_entries"]==0
  assert proof["actual_limits"]==dict(cpu=[10,10],address=[256<<20,256<<20],core=[0,0])
  composed=evidence/"composed-executor.S";composition_report=evidence/"composition.json"
  run("actual-ui-exact-fixed-source-composition",
   [context["python"],"-B",paths["compose_executor.py"],
    "--base",paths["namespace-fixed-fs9.S"],"--capsule",paths["capsules.S"],
    "--dispatch",paths["dispatcher.S"],"--output",composed,"--manifest",composition_report],
   "composition.json")
  composition=json.loads(ev.original(composition_report))
  assert composition["exact_old_source_inverse"] is True and composition["unique_edits"]==5
  assert composition["new_context_metadata_disjoint"] is True
  assert composition["fixed_runtime_roles"]==list(range(1,10))
  assert composed.read_bytes()==sources["native_unixopen_issued_executor.S"][1]
  ev.pin(composed)
  run("actual-ui-nine-fresh-roles-and-native-packer",
   [context["python"],"-B",paths["build_actual_unixopen.py"],"--context",context_path,
    "--executor",composed,"--packer",paths["generate_native_packer.py"]],
   "actual-unixopen-build-r1/summary.json")
  built=report("actual-unixopen-build-r1/summary.json","PASS_BUILD_ONLY")
  assert built["fresh_role_compiles"]==9 and built["packer_entries"]==45
  assert built["actual_carrier_processes"]==0 and built["source_pins_unchanged"] is True
  assert built["actual_process_limits"]==dict(cpu=[90,90],address=[1<<30,1<<30],core=[0,0])
  assert set(built["exact_roles"])==set(map(str,range(1,10)))
  assert built["executable"]["layout"]["relocation_count"]==0
  def compile_receipt(receipt,source,image):
   assert receipt["status"]=="returned" and receipt["abi_status"]==0
   assert receipt["artifact_sha256"]==receipt["image_sha256"]==COMPILER
   assert receipt["source_sha256"]==receipt["input_sha256"]==source["sha256"]
   assert receipt["input_bytes"]==source["bytes"]
   assert receipt["produced_sha256"]==image["sha256"] and receipt["produced_bytes"]==image["bytes"]
   assert receipt["core_u32"]==receipt["result_u64"]==image["bytes"]
   assert receipt["limits"]["cpu_seconds"]==10 and receipt["limits"]["address_bytes"]==256<<20
   assert receipt["source_unchanged"] is True and not receipt["forbidden_compiler_modules_loaded"]
  for number,row in built["exact_roles"].items():
   for field in ("source","image"):
    observed,raw=identity(row[field]["path"])
    assert (observed["bytes"],observed["sha256"])==(row[field]["bytes"],row[field]["sha256"])
    ev.pins[observed["path"]]=observed
   compile_receipt(row["compile_receipt"],row["source"],row["image"])
   profile=row["profile"]
   assert profile["functions"]<=128 and profile["blocks"]<=1536 and profile["ops"]<=8192
   assert profile["max_blocks"]<=256 and profile["max_block_params"]<=16
   assert profile["max_ssa_numeric_suffix"]<2048
  packer_source=evidence/"actual-unixopen-build-r1/packer.hiaasm"
  packer_source_pin,_=identity(packer_source)
  packer_receipt=built["compile_receipt"]
  assert packer_receipt["source_sha256"]==packer_receipt["input_sha256"]==packer_source_pin["sha256"]
  assert packer_receipt["input_bytes"]==packer_source_pin["bytes"]
  assert packer_receipt["produced_sha256"]==built["packer_image_sha256"]
  assert packer_receipt["status"]=="returned" and packer_receipt["abi_status"]==0
  assert packer_receipt["artifact_sha256"]==packer_receipt["image_sha256"]==COMPILER
  assert packer_receipt["limits"]["cpu_seconds"]==10 and packer_receipt["limits"]["address_bytes"]==256<<20
  assert packer_receipt["source_unchanged"] and not packer_receipt["forbidden_compiler_modules_loaded"]
  ev.pins[packer_source_pin["path"]]=packer_source_pin
  packer_images=sorted((evidence/"actual-unixopen-build-r1/compile/namespace-unixopen-issued-packer").glob("*.image.bin"))
  assert len(packer_images)==1
  packer_image_pin,_=identity(packer_images[0])
  assert (packer_image_pin["bytes"],packer_image_pin["sha256"])==(packer_receipt["produced_bytes"],packer_receipt["produced_sha256"])
  ev.pins[packer_image_pin["path"]]=packer_image_pin
  pp=built["profile"]
  assert pp["functions"]<=128 and pp["blocks"]<=1536 and pp["ops"]<=8192
  assert pp["max_blocks"]<=256 and pp["max_block_params"]<=16 and pp["max_ssa_numeric_suffix"]<2048
  executable_pin,executable_raw=identity(built["executable"]["path"])
  assert (executable_pin["bytes"],executable_pin["sha256"])==(built["executable"]["bytes"],built["executable"]["sha256"])
  assert executable_pin["mode"]==0o755 and executable_raw[:4]==b"\x7fELF"
  ev.pins[executable_pin["path"]]=executable_pin
  # Every complete original generated source/image/document/receipt remains in
  # the evidence tree. Neither a frozen image nor an old case outcome is reused.
  completed=[]
  for group,count in GROUPS.items():
   relative="actual-unixopen-"+group+"-r1/summary.json"
   run("actual-ui-native-"+group,[context["python"],"-B",paths["test-actual-unixopen.py"],
    "--context",context_path,"--group",group],relative)
   value=report(relative,"PASS")
   assert value["group"]==group
   assert value["planned_cases"]==value["completed_cases"]==value["actual_ELF_processes"]==value["process_launch_attempts"]==count
   assert value["actual_process_count_complete"] and value["actual_entry_counts_complete"]
   assert len(value["case_results"])==count
   assert value["actual_native_entries"]==value["full_VM_entries"]>0
   assert value["source_inputs_unchanged"] is True
   assert value["limits"]==dict(cpu_seconds=90,wall_seconds=180,address_bytes=1<<30,core_bytes=0)
   assert value["VM_limits"]==dict(steps=4000000,arena_bytes=32<<20,depth=64)
   for flag in ("ordinary_unixOpen_closed","ordinary_Store_closed","non_raw_peer_callbacks_used",
    "host_completion_capsules_supplied","original42_rerun","prior_results_inherited"):
    assert value[flag] is False
   for case in value["case_results"]:
    assert case["status"]=="PASS"
    replay=case["replay"];proc=case["actual_process"]
    assert replay["native_entries"]==replay["VM_entries"]>0
    assert replay["all_native_return_output_workspace_bytes_equal"] and replay["no_field_mask"]
    assert replay["no_cached_VM_results"] and replay["no_native_or_syscall_execution_in_replayer"]
    assert replay["private_issued_capsules_bound_to_actual_begin_and_completed_windows"]
    assert proc["returncode"]==case["expected_exit"] and proc["source_unchanged"]
    assert not proc["wall_watchdog_fired"] and not proc["wall_kill_sent"]
    assert 0<=proc["usage"]["user"]+proc["usage"]["system"]<90
    assert 0<=proc["elapsed_ns"]<180_000_000_000
   completed.append(value)
  cases=[item for group in completed for item in group["case_results"]]
  assert len(cases)==28 and len({case["label"] for case in cases})==28
  assert sum(group["actual_ELF_processes"] for group in completed)==28
  assert sum(group["actual_parent_raw_ACKs"] for group in completed)==14
  assert sum(group["actual_getpid_syscalls"] for group in completed)==15
  # 12 prefix cases produce 13 ACKs (one PID-reset pair); the explicit
  # no-reentry control first produces one real prefix. One direct prior FS
  # getpid in the shared-session case adds the fifteenth actual syscall.
  counts=dict(pure_DMS10_source_proof_controls=10,fresh_role_B3=9,fresh_packer_B3=1,
   new_nine_image_native_packer_controls=45,completed_cases=28,actual_fixed_processes=28,
   actual_native_entries=sum(row["actual_native_entries"] for row in completed),
   full_VM_entries=sum(row["full_VM_entries"] for row in completed),
   actual_native_parent_ACKs=sum(row["actual_parent_raw_ACKs"] for row in completed),
   actual_getpid_syscalls=sum(row["actual_getpid_syscalls"] for row in completed),
   actual_getpid_counter_scope="Role1 primitive trace only; bootstrap/fixture OS getpid calls are not semantic peer entries.",
   inherited_counts=False,old_original42_reexecuted=False)
  assert counts["actual_native_entries"]==counts["full_VM_entries"]
  details.update(status="PASS_RAW_PREFIX_COMPONENT_ONLY",actual_counts=counts,
   actual_native_raw_prefix_subject_pass=True,complete_nine_role_source_and_image_pins=True,
   all_native_windows_return_output_workspace_equal=True,
   actual_private_capsules_bound_to_real_call_source_and_completed_image=True)
 except BaseException as error:
  ev.fail("subject-primary",error)
  details.update(status="FAIL",error_class=type(error).__name__,error=str(error),
   traceback=traceback.format_exc())
  ev.attempt("print-primary",lambda:traceback.print_exception(error))
 finally:
  # Do not let a malformed partial summary replace the original target error.
  # Export complete bytes first, then attempt optional field interpretation.
  if evidence is not None:
   for path in sorted(evidence.rglob("summary.json")):
    if path==evidence/"summary.json":continue
    ev.attempt("partial-original:"+str(path),lambda path=path:ev.original(path))
  details["source_after"]=ev.after()
  details["source_before"]=ev.pins
  details["all_pinned_inputs_copies_and_generated_outputs_unchanged"]=not any(
   row["scope"].startswith("independent-after:") for row in ev.errors)
  details["original_exports"]=ev.exports
  details["errors"]=ev.errors
  if ev.primary is not None:
   details["status"]="FAIL";details["actual_native_raw_prefix_subject_pass"]=False
  if evidence is not None:
   ev.attempt("source-after-receipt",lambda:save(evidence/"source-after.json",details["source_after"]))
   ev.attempt("subject-summary",lambda:save(evidence/"summary.json",details))
   if phase_start is not None:
    end=time.monotonic_ns();elapsed=end-phase_start
    phase=details["subject_phase"]
    phase.update(ended_monotonic_ns=end,elapsed_ns=elapsed,
     source_after_checks_attempted_for_all_pins=True,
     final_subject_summary_write_readback_pass=not any(row["scope"]=="subject-summary" for row in ev.errors),
     within_original900=0<=elapsed<900_000_000_000)
    if not phase["within_original900"]:
     ev.fail("strict-final-subject900",TimeoutError("complete actual UnixOpen subject exceeded original900"))
    ev.attempt("subject-phase-receipt",lambda:save(evidence/"subject-phase.json",phase))
    # Measure again after writing/reading the phase receipt itself.
    if time.monotonic_ns()-phase_start>=900_000_000_000:
     ev.fail("subject900-after-phase-receipt",TimeoutError("actual UnixOpen final phase receipt exceeded original900"))
   if ev.primary is not None:
    details["status"]="FAIL";details["actual_native_raw_prefix_subject_pass"]=False
    ev.attempt("rewrite-FAIL-subject",lambda:save(evidence/"summary.json",details))

 if ev.primary is not None:raise ev.primary
 assert details['status']=='PASS_RAW_PREFIX_COMPONENT_ONLY'
 return details
