def loop_probe(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(o) > 0:
        store(o, 0, 90)
    start = 384 + read64(s, 304)
    at = 0
    while at < get(w, 248):
        if byte(s, start + at) != byte(w, get(w, 240) + at):
            return 0
        at = at + 1
    return 1

def read64(s:readbuf, index:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(s, index + i) << (i * 8))
        i = i + 1
    return value
def get(w:mutbuf, index:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(w, index + i) << (i * 8))
        i = i + 1
    return value
