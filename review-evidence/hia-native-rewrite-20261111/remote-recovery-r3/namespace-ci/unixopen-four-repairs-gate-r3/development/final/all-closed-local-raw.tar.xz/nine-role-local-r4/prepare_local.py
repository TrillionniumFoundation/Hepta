from pathlib import Path
import hashlib,json,shutil,stat
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"nine-role-local-r3"
manifest=json.loads((ROOT/"frozen-inputs.json").read_bytes())
def identity(path):
    st=path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
    raw=path.read_bytes()
    return raw,dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),blob=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest(),mode=stat.S_IMODE(st.st_mode))
rows=[]
for row in manifest["inputs"]:
    old=OLD/"source"/"inputs"/row["path"]
    raw,ident=identity(old)
    assert (ident["bytes"],ident["sha256"],ident["blob"],ident["mode"])==(row["bytes"],row["sha256"],row["blob"],int(row["mode"][-3:],8))
    for relative in ["inputs/"+row["path"]]+([row["working_alias"]] if row["working_alias"] else []):
        dest=ROOT/"source"/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open("xb") as f:f.write(raw)
        dest.chmod(ident["mode"])
        assert identity(dest)==(raw,ident)
        rows.append(dict(path=str(dest),**ident))
compiler=ROOT/"evidence"/"compiler"/"B3.image.bin"
compiler.parent.mkdir(parents=True)
raw,ident=identity(OLD/"evidence"/"compiler"/"B3.image.bin")
assert ident["bytes"]==669556 and ident["sha256"]==manifest["compiler_sha256"]
compiler.write_bytes(raw);compiler.chmod(ident["mode"])
assert identity(compiler)==(raw,ident)
supervisor=ROOT/"supervise_development.py"
raw,ident=identity(OLD/"supervise_development.py")
supervisor.write_bytes(raw);supervisor.chmod(ident["mode"])
assert identity(supervisor)==(raw,ident)
context=json.loads((OLD/"context.json").read_bytes())
context=json.loads(json.dumps(context).replace(str(OLD),str(ROOT)))
(ROOT/"context.json").write_text(json.dumps(context,sort_keys=True,indent=2)+"\n")
(ROOT/"copied-inputs.json").write_text(json.dumps(rows,sort_keys=True,indent=2)+"\n")
print(json.dumps(dict(status="EXACT_COPIES_READY",files=len(rows),scope="LOCAL_DEVELOPMENT_NOT_UBUNTU_CI")))

