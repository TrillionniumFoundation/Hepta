"""Local DB-name alpha differential: original VM/new VM/exact newly compiled image."""
from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import copy,ctypes,hashlib,importlib.util,json,resource,signal,struct,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REF=Path("/workspace/scratch/9acdfa9f5639/reference0ef")
WORK=Path("/workspace/scratch/9acdfa9f5639/runtime-development/twelve-role-local-r2")
OLD_DOCUMENT=Path("/workspace/scratch/9acdfa9f5639/runtime-development/twelve-role-local-r1/evidence/policy-unixopen-build-r1/generation-frontier/role-5.document.json")
OUT=ROOT/"actual-r2";B3="35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b"
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+"\n")
def wire(v):return (json.dumps(v,sort_keys=True,separators=(",",":"))+"\n").encode()
def q(b,a):return struct.unpack_from("<Q",b,a)[0]
def put(b,a,v):struct.pack_into("<Q",b,a,v)
def magic(b):return int.from_bytes(b,"little")
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m
 exec(compile(p.read_bytes(),str(p),"exec"),m.__dict__);return m
def main():
 OUT.mkdir(exist_ok=False);started=time.monotonic_ns()
 resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 report=dict(status="INCOMPLETE",scope="LOCAL_DB_STEADY_ALPHA_DIFFERENTIAL_NOT_PHYSICAL_QUALIFICATION",
  old_VM=0,new_VM=0,new_native=0,direct_steady_VM_pairs=0,new_B3_in_this_comparison=0,physical_OS_syscalls=0)
 pins={};primary=None;image=None
 def pin(p,expected=None):
  raw=p.read_bytes();v=dict(bytes=len(raw),sha256=sha(raw),mode=p.stat().st_mode&0o777)
  if expected:assert v["sha256"]==expected
  if str(p) in pins:assert pins[str(p)]==v
  pins[str(p)]=v;return raw
 cas=OUT/"cas";cas.mkdir()
 def kept(b):
  b=bytes(b);h=sha(b);p=cas/h
  if not p.exists():p.write_bytes(b)
  assert p.read_bytes()==b
  return dict(sha256=h,bytes=len(b),path="cas/"+h)
 try:
  pin(Path(__file__));pin(ROOT/"old.py","f5e4d87baf5046db3b1ec77300b057010b94529a3ea11408bb99abd15fc3f0b3")
  pin(ROOT/"new.py","3ac08c7729c30ff3705c008416020b2ee0b1388785a279200f52abeb5a6f83a7")
  sys.path.insert(0,str(REF))
  for name in ("generate_hia_agent_namespace_store","generate_hia_agent_namespace_objects"):
   p=WORK/"source/tools"/(name+".py");pin(p);load("tools."+name,p)
  old=load("old_db",ROOT/"old.py");new=load("new_db",ROOT/"new.py")
  old_doc=old.document();new_doc=new.document();old_raw=pin(OLD_DOCUMENT)
  assert wire(old_doc)==old_raw and old.source_program()==new.source_program()
  assert [i for i,(a,b) in enumerate(zip(old_doc["functions"],new_doc["functions"],strict=True)) if a!=b]==[5]
  fn=old_doc["functions"][5]
  names=sorted({v["name"] for b in fn["blocks"] for v in b["params"]+[v for o in b["ops"] for v in o["out"]]},key=lambda n:int(n[1:]))
  assert len(names)==1208 and max(int(n[1:]) for n in names)==2257
  inv={"v"+str(i):n for i,n in enumerate(names)};back=copy.deepcopy(new_doc);f=back["functions"][5]
  for v in f["params"]:v["name"]=inv[v["name"]]
  for b in f["blocks"]:
   for v in b["params"]:v["name"]=inv[v["name"]]
   for o in b["ops"]:
    o["args"]=[inv[a] for a in o["args"]]
    for v in o["out"]:v["name"]=inv[v["name"]]
   t=b["term"]
   if t["op"]=="ret":t["values"]=[inv[v] for v in t["values"]]
   elif t["op"]=="jump":t["args"]=[inv[v] for v in t["args"]]
   else:
    assert t["op"]=="branch";t["cond"]=inv[t["cond"]]
    for k in ("then","else"):t[k]["args"]=[inv[v] for v in t[k]["args"]]
  assert wire(back)==old_raw
  save(OUT/"bijection.json",dict(inverse=inv,complete_original_document_inverse=True))
  (OUT/"old.document.json").write_bytes(old_raw);(OUT/"new.document.json").write_bytes(wire(new_doc))
  from hepta.hia_agent_assembly import render_assembly,assemble_program
  from hepta.hia_program_runtime import _Machine,_Owner,_View
  from hepta.hia_json_preflight_native import NativeHiaJsonImage
  old_source=render_assembly(old_doc).encode();new_source=render_assembly(new_doc).encode()
  (OUT/"old.hiaasm").write_bytes(old_source);(OUT/"new.hiaasm").write_bytes(new_source)
  old_program=assemble_program(old_source);new_program=assemble_program(new_source)
  built=json.loads(pin(WORK/"evidence/policy-unixopen-build-r1/summary.json"))
  assert built["status"]=="PASS_BUILD_ONLY" and built["fresh_role_compiles"]==12 and built["packer_entries"]==57
  role=built["exact_roles"]["5"];assert pin(Path(role["source"]["path"]),role["source"]["sha256"])==new_source
  receipt=role["compile_receipt"];assert receipt["artifact_sha256"]==B3 and receipt["limits"]["cpu_seconds"]==10 and receipt["limits"]["address_bytes"]==256<<20
  image_raw=pin(Path(role["image"]["path"]),role["image"]["sha256"]);image=NativeHiaJsonImage(image_raw,sha(image_raw))
  report["actual_image_from_separate_fresh_twelve_role_build"]=role
  canary=bytes(range(160,176))
  def vm(program,src,output,workspace,entry="f0"):
   owners=[_Owner(-1,bytearray(src)),_Owner(-2,bytearray(output)),_Owner(-3,bytearray(workspace))]
   m=_Machine(program,4000000,32<<20,None,64);fn=m.functions[entry]
   args=[_View(owners[2],True)] if entry=="f5" else [_View(owners[0],False),_View(owners[1],True),_View(owners[2],True)]
   status=m.invoke(fn,args)[0]
   assert bytes(owners[0].data)==src
   return status,bytes(owners[1].data),bytes(owners[2].data),m.steps,m.resources()
  def native(src,output,workspace):
   data=[src,output,workspace];bufs=[]
   for b in data:
    buf=ctypes.create_string_buffer(len(b)+32)
    ctypes.memmove(ctypes.addressof(buf),canary,16)
    if b:ctypes.memmove(ctypes.addressof(buf)+16,b,len(b))
    ctypes.memmove(ctypes.addressof(buf)+16+len(b),canary,16)
    bufs.append(buf)
   result=image._entry(*[x for buf,b in zip(bufs,data) for x in (ctypes.addressof(buf)+16,len(b))])
   allbytes=[]
   for buf,b in zip(bufs,data):
    raw=bytes(buf)
    assert raw[:16]==raw[len(b)+16:len(b)+32]==canary
    allbytes.append(raw[16:16+len(b)])
   assert allbytes[0]==src
   return result,allbytes[1],allbytes[2]
  ledger=[]
  def compare(label,src,output,workspace):
   pre=dict(input=kept(src),output=kept(output),workspace=kept(workspace))
   a=vm(old_program,src,output,workspace);report["old_VM"]+=1
   b=vm(new_program,src,output,workspace);report["new_VM"]+=1
   c=native(src,output,workspace);report["new_native"]+=1
   assert a==b,(label,"old/new full VM or steps/resources")
   assert a[:3]==c,(label,"new native complete bytes/return")
   row=dict(label=label,pre=pre,returned=a[0],steps=a[3],resources=a[4],output=kept(a[1]),workspace=kept(a[2]),
    old_new_VM_equal=True,new_native_equal=True,canaries_equal=True)
   ledger.append(row);save(OUT/"entries.json",ledger)
   return a
  init=bytearray(256)
  for at,v in ((0,magic(b"HIANDB01")),(8,1),(16,11),(24,13),(80,17),(88,19)):put(init,at,v)
  initialized=compare("init",bytes(init),bytes([0xa5])*256,bytes(2048));assert initialized[0]==0
  state=initialized[2]
  probe=bytearray(256)
  for at,v in ((0,magic(b"HIANDB01")),(8,9),(16,11),(24,13),(32,1),(64,2),(120,101)):put(probe,at,v)
  compare("take-unused-empty",bytes(probe),bytes([0x3c])*256,state)
  reg=bytearray(probe);put(reg,8,2);put(reg,64,111);put(reg,72,2)
  grown=compare("register-requests-workspace-growth",bytes(reg),bytes([0x3c])*256,state);assert grown[0]==2 and q(grown[1],168)==3584
  pending=compare("register-same-input-after-growth",bytes(reg),grown[1],grown[2]+bytes(3584-len(grown[2])));assert pending[0]==1
  states=[]
  def slot_state(kind):
   w=bytearray(state)
   for at,v in ((48,2),(56,1),(1536,1),(1544,111),(1552,kind)):put(w,at,v)
   if kind==1:put(w,64,1)
   elif kind==2:
    for at,v in ((264,1),(272,1536),(1600,1)):put(w,at,v)
   else:
    for at,v in ((72,1),(80,1),(88,1),(264,1),(1544,0),(1560,1),(1600,1)):put(w,at,v)
   return w
  for kind in (1,2,3):
   w=slot_state(kind);states.append(bytes(w))
   compare("private-row-state-"+str(kind),bytes(probe),bytes([0x3c])*256,bytes(w))
  w=slot_state(2)
  for at,v in ((48,3),(56,2),(264,2),(1592,1664),(1600,2),(1664,2),(1672,112),(1680,2),(1728,1)):put(w,at,v)
  states.append(bytes(w));compare("private-deferred-chain",bytes(probe),bytes([0x3c])*256,bytes(w))
  offsets=(0,8,16,24,32,40,48,56,64,72,80,88,96,104,112,120,128,136,144,152,160,168,176,184,192,200,208,216,224,232,240,248,256,264,272,280,288,296,304,312,320,328,336,344,352,360,368,376,384,512,768,1528)
  assert len(offsets)==52
  for at in offsets:
   w=bytearray(state);put(w,at,q(w,at)^1)
   compare("mutated-idle-field-"+str(at),bytes(probe),bytes([0x3c])*256,bytes(w))
  for n in (0,7,8,1535):compare("short-work-"+str(n),bytes(init),bytes([0x55])*256,bytes(n))
  for n in (0,1,255):compare("short-output-"+str(n),bytes(init),bytes([0x66])*n,bytes(2048))
  for n in (0,7,8,255):compare("short-source-"+str(n),bytes(init[:n]),bytes([0x77])*256,bytes(2048))
  assert len(ledger)==71 and report["old_VM"]==report["new_VM"]==report["new_native"]==71
  direct=[]
  for label,w in [("idle",state),("pending",pending[2]),("zero",bytes(2048))]+[("row-"+str(i),w) for i,w in enumerate(states)]:
   a=vm(old_program,b"",b"",w,"f5");b=vm(new_program,b"",b"",w,"f5");assert a==b
   report["direct_steady_VM_pairs"]+=1
   direct.append(dict(label=label,returned=a[0],steps=a[3],resources=a[4],pre=kept(w),post=kept(a[2])))
  assert len(direct)==7;save(OUT/"direct.json",direct)
  for m in list(sys.modules.values()):
   name=getattr(m,"__file__",None)
   if name and Path(name).resolve().is_relative_to(REF) and Path(name).suffix==".py":pin(Path(name).resolve())
  for path in cas.iterdir():assert sha(path.read_bytes())==path.name
  report.update(status="PASS",controls=71,direct_scope_controls=7,source_DSL_exact=True,
   old_generation_exact_original_document=True,one_function_alpha_inverse_exact=True,
   all_full_return_output_workspace_steps_resources_equal=True,canaries_unchanged=True)
 except BaseException as error:
  primary=error;report.update(status="FAIL",error_class=type(error).__name__,error=str(error),traceback=traceback.format_exc());traceback.print_exc()
 finally:
  if image is not None:
   try:image._mapping.close()
   except BaseException as error:
    if primary is None:primary=error
    else:primary.add_note("image cleanup: "+repr(error))
  errors=[]
  for name,before in pins.items():
   try:
    p=Path(name);r=p.read_bytes();assert dict(bytes=len(r),sha256=sha(r),mode=p.stat().st_mode&0o777)==before
   except BaseException as error:
    errors.append(dict(path=name,error=repr(error)))
    if primary is None:primary=error
    else:primary.add_note("source after: "+repr(error))
  report.update(source_before=pins,after_errors=errors)
  if primary is not None:report["status"]="FAIL"
  save(OUT/"summary.json",report);print(json.dumps({k:v for k,v in report.items() if k not in ("source_before","actual_image_from_separate_fresh_twelve_role_build")},sort_keys=True),flush=True)
  own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN)
  cpu=own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime;elapsed=time.monotonic_ns()-started
  if not(0<=cpu<90 and 0<=elapsed<180_000_000_000):
   report.update(status="FAIL",post_output_budget=dict(cpu=cpu,elapsed_ns=elapsed));save(OUT/"summary.json",report)
   if primary is None:primary=AssertionError("post output budget")
 if primary:raise primary
if __name__=="__main__":main()
