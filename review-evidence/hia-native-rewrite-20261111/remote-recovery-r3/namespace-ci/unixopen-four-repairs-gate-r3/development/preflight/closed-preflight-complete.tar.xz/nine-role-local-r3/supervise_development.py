"""Local development process supervisor; does not confer Ubuntu CI qualification."""
from __future__ import annotations
import ctypes,hashlib,json,os,resource,signal,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def ident(path):
 raw=path.read_bytes()
 return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def main():
 label=sys.argv[1];argv=sys.argv[2:]
 assert label and "/" not in label and argv and Path(argv[0]).is_absolute()
 started=time.monotonic_ns();pid=None;waited=None;timeout=False;primary=None
 stdout=ROOT/(label+".stdout");stderr=ROOT/(label+".stderr")
 assert not stdout.exists() and not stderr.exists()
 with stdout.open("xb") as out,stderr.open("xb") as err:
  try:
   parent=os.getpid();pid=os.fork()
   if pid==0:
    try:
     os.setsid()
     libc=ctypes.CDLL(None,use_errno=True)
     if libc.prctl(1,signal.SIGKILL,0,0,0):raise OSError(ctypes.get_errno(),"PR_SET_PDEATHSIG")
     if os.getppid()!=parent:os._exit(125)
     resource.setrlimit(resource.RLIMIT_CPU,(90,90))
     resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
     resource.setrlimit(resource.RLIMIT_CORE,(0,0))
     os.dup2(out.fileno(),1);os.dup2(err.fileno(),2)
     os.execve(argv[0],argv,dict(os.environ,PYTHONDONTWRITEBYTECODE="1",LC_ALL="C"))
    except BaseException:
     traceback.print_exc();os._exit(126)
   while waited is None:
    got,status,usage=os.wait4(pid,os.WNOHANG)
    if got:waited=(status,usage);break
    if time.monotonic_ns()-started>=180_000_000_000:
     timeout=True
     try:os.killpg(pid,signal.SIGKILL)
     except ProcessLookupError:
      try:os.kill(pid,signal.SIGKILL)
      except ProcessLookupError:pass
     got,status,usage=os.wait4(pid,0);assert got==pid
     waited=(status,usage);break
    time.sleep(0.02)
  except BaseException as exc:primary=exc
  finally:
   if pid is not None and pid>0 and waited is None:
    try:os.killpg(pid,signal.SIGKILL)
    except ProcessLookupError:
     try:os.kill(pid,signal.SIGKILL)
     except ProcessLookupError:pass
    try:
     got,status,usage=os.wait4(pid,0);assert got==pid;waited=(status,usage)
    except BaseException as exc:
     if primary is None:primary=exc
     else:primary.add_note("kill/reap: "+repr(exc))
 elapsed=time.monotonic_ns()-started
 report=dict(scope="LOCAL_DEVELOPMENT_NOT_UBUNTU_CI",label=label,args=argv,
  elapsed_ns=elapsed,wall_timeout=timeout,kernel_limits=dict(cpu_seconds=90,address_bytes=1<<30,core_bytes=0),
  stdout=ident(stdout),stderr=ident(stderr),child_wait4_complete=waited is not None)
 if waited:
  status,usage=waited;rc=os.waitstatus_to_exitcode(status)
  report.update(returncode=rc,raw_wait_status=status,usage=dict(user=usage.ru_utime,system=usage.ru_stime,maxrss_kib=usage.ru_maxrss),
   child_cpu_seconds=usage.ru_utime+usage.ru_stime)
 report["status"]="PASS" if primary is None and waited and rc==0 and not timeout and 0<=elapsed<180_000_000_000 and 0<=report["child_cpu_seconds"]<90 else "FAIL"
 if primary:report["primary"]=dict(type=type(primary).__name__,error=str(primary))
 dest=ROOT/(label+".process.json")
 data=(json.dumps(report,sort_keys=True,indent=2)+"\n").encode()
 dest.write_bytes(data);assert dest.read_bytes()==data
 print(json.dumps(report,sort_keys=True),flush=True)
 return 0 if report["status"]=="PASS" else 1
if __name__=="__main__":raise SystemExit(main())
