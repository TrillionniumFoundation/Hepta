"""NEW source-only UnixOpen actual policy-peer/shared-FS bridge.

Role 12 connects the unchanged robust_open role 10 and create/URI role 11
through the same role-6 FS session. Native completion capsules and retirement
receipts are private issuer facts, not external byte-header authentication.
Original low-FD warning and other unfinished effects remain explicit pending.
No predecessor execution or ordinary Store qualification is inherited.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_agent_namespace_objects import ObjectBuilder
from tools.generate_hia_agent_namespace_store import VALUES
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
ROOT=Path(__file__).resolve().parents[1]
CONSTANTS={
    "PB_MAGIC":int.from_bytes(b"HIAUPW01","little"),
    "PB_BAD":int.from_bytes(b"HIAUPZ01","little"),
    "PB_INPUT":int.from_bytes(b"HIAUPB01","little"),
    "PB_EVENT":int.from_bytes(b"HIAUPX01","little"),
    "PB_RETIRE":int.from_bytes(b"HIAURT01","little"),
    "PB_RO":int.from_bytes(b"HIANRO01","little"),
    "PB_CM":int.from_bytes(b"HIANCM01","little"),
    "PB_FS":int.from_bytes(b"HIANFR03","little"),
    "PB_PSOW":int.from_bytes(b"psow","little"),
    "UI_CAPSULE":int.from_bytes(b"HIAUIC01","little"),
    "UI_PARENT":int.from_bytes(b"HIANUO01","little"),
    "UI_PENDING":int.from_bytes(b"HIANUQ01","little"),
    "UI_JOIN":int.from_bytes(b"HIANDJ01","little"),
    "UI_FS_CHANNEL":int.from_bytes(b"HIANDJX1","little"),
}

POLICY=r'''
def unixopen_policy_fs_bridge(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < 2048:
        if length(w) >= 8:
            put(w, 0, PB_BAD)
        return 4294967293
    if get(w, 0) == PB_BAD:
        return pb_emit(o, w, 4294967293)
    if length(s) < 256 or length(o) < 256:
        return pb_refuse(o, w, 1)
    if read64(s, 0) != PB_INPUT:
        return pb_refuse(o, w, 2)
    command = read64(s, 8)
    if command == 1:
        return pb_begin(s, o, w)
    if get(w, 0) != PB_MAGIC or pb_stored(w) == 0:
        return pb_refuse(o, w, 3)
    at = 16
    while at < 64:
        if read64(s, at) != get(w, at):
            return pb_refuse(o, w, 4)
        at = at + 8
    if command == 2 and (get(w, 8) == 2 or get(w, 8) == 3):
        return pb_completed(s, o, w)
    if command == 3 and get(w, 8) == 4:
        return pb_retired(s, o, w)
    return pb_refuse(o, w, 5)

def pb_selected(op:u64) -> u64:
    if op == 7:
        return 10
    if op == 6 or op == 12:
        return 11
    return 0

def pb_begin_shape(s:readbuf) -> u64:
    if (read64(s, 16) | read64(s, 24)) == 0 or read64(s, 32) == 0 or read64(s, 40) != 0:
        return 0
    if read64(s, 48) == 0 or read64(s, 56) == 0:
        return 0
    if read64(s, 64) == 0 or read64(s, 72) == 0 or read64(s, 80) == 0 or read64(s, 88) == 0 or read64(s, 112) == 0:
        return 0
    if read64(s, 64) == read64(s, 80) or read64(s, 64) == read64(s, 48) or read64(s, 80) == read64(s, 48):
        return 0
    at = 120
    while at < 256:
        if read64(s, at) != 0:
            return 0
        at = at + 8
    pn = read64(s, 96)
    if pn > length(s) - 256 or read64(s, 104) != length(s) - 256 - pn:
        return 0
    f = 256 + pn
    if ui_capsule(s, 256, pn, 7) == 0 or ui_capsule(s, f, read64(s, 104), 6) == 0:
        return 0
    if read64(s, 360) != read64(s, 56) or read64(s, f + 104) != read64(s, 56):
        return 0
    if read64(s, 272) == read64(s, f + 16):
        return 0
    at = 48
    while at < 88:
        if at != 56 and at != 72:
            if read64(s, at) == read64(s, 272) or read64(s, at) == read64(s, f + 16):
                return 0
        at = at + 8
    if ui_parent(s, 256) == 0 or ui_fs_ready(s, f) == 0:
        return 0
    if pb_parent_shape(s) == 0 or pb_initial_fs(s, f) == 0:
        return 0
    return 1

def pb_parent_shape(s:readbuf) -> u64:
    out = 384 + read64(s, 304)
    work = out + read64(s, 312)
    q = out + 256
    if read64(s, out + 152) != 0 or read64(s, out + 248) != read64(s, 112):
        return 0
    if read64(s, work + 416) != read64(s, 112) or read64(s, work + 464) != read64(s, 56):
        return 0
    at = 0
    while at < 256:
        if read64(s, q + at) != read64(s, work + 512 + at):
            return 0
        at = at + 8
    if read64(s, out + 72) != read64(s, work + 160) or read64(s, out + 72) > 4095:
        return 0
    op = read64(s, out + 48)
    stage = read64(s, out + 56)
    if pb_selected(op) == 0:
        return 1
    if (read64(s, q + 88) | read64(s, q + 96) | read64(s, q + 104)) != 0:
        return 0
    n = read64(s, q + 112)
    if op == 6:
        if stage != 30 or read64(s, q + 120) != 2 or read64(s, q + 168) != 8:
            return 0
        if read64(s, q + 64) != read64(s, out + 96) or read64(s, q + 64) > 4294967295:
            return 0
        return choose(read64(s, q + 72) < n and read64(s, q + 80) == 1, 1, 0)
    if op == 7:
        if (stage != 31 and stage != 35) or read64(s, q + 120) != 1 or read64(s, q + 168) != 7:
            return 0
        if read64(s, q + 64) != read64(s, out + 104) or read64(s, q + 64) > 4294967295:
            return 0
        if read64(s, q + 72) != read64(s, work + 352) or read64(s, q + 72) > 511 or read64(s, q + 80) != 0:
            return 0
        at = 0
        while at < n:
            if byte(s, out + 512 + at) == 0:
                return 0
            at = at + 1
        return 1
    if stage != 60 or read64(s, q + 168) != 8 or read64(s, q + 72) > 1 or read64(s, q + 80) > 1:
        return 0
    if read64(s, q + 72) == 0:
        return choose((read64(s, q + 64) | n | read64(s, q + 120)) == 0, 1, 0)
    return choose(read64(s, q + 64) < n and read64(s, q + 120) == 3, 1, 0)

def pb_ready_fields(s:readbuf, work:u64) -> u64:
    if (read64(s, work + 16) | read64(s, work + 24)) == 0 or (read64(s, work + 80) | read64(s, work + 88)) == 0:
        return 0
    if read64(s, work + 48) == 0:
        return 0
    if (read64(s, work + 120) | read64(s, work + 128) | read64(s, work + 136) | read64(s, work + 144) | read64(s, work + 152) | read64(s, work + 160) | read64(s, work + 168) | read64(s, work + 184)) != 0:
        return 0
    return choose((read64(s, work + 192) | read64(s, work + 200) | read64(s, work + 248) | read64(s, work + 256) | read64(s, work + 264)) == 0, 1, 0)

def pb_initial_fs(s:readbuf, cap:u64) -> u64:
    po = 384 + read64(s, 304)
    q = po + 256
    work = cap + 128 + read64(s, cap + 48) + read64(s, cap + 56)
    if pb_ready_fields(s, work) == 0:
        return 0
    if read64(s, work + 80) != read64(s, q + 136) or read64(s, work + 88) != read64(s, q + 144):
        return 0
    if read64(s, work + 216) != read64(s, q + 152) or read64(s, work + 224) != read64(s, q + 160):
        return 0
    return 1

def pb_begin_state(s:readbuf, w:mutbuf) -> u64:
    if get(w, 0) == 0:
        if read64(s, 32) != 1:
            return 0
        at = 0
        while at < 2048:
            if get(w, at) != 0:
                return 0
            at = at + 8
        return 1
    if get(w, 0) != PB_MAGIC or (get(w, 8) != 5 and get(w, 8) != 7):
        return 0
    if get(w, 32) == 18446744073709551615 or read64(s, 32) != get(w, 32) + 1:
        return 0
    if read64(s, 16) != get(w, 16) or read64(s, 24) != get(w, 24) or read64(s, 48) != get(w, 48) or read64(s, 56) != get(w, 56):
        return 0
    if read64(s, 64) != get(w, 64) or read64(s, 80) != get(w, 80) or read64(s, 72) < get(w, 72) or read64(s, 88) < get(w, 88):
        return 0
    po = 384 + read64(s, 304)
    if read64(s, 272) != get(w, 128) or read64(s, 280) != get(w, 136) or read64(s, 288) <= get(w, 144):
        return 0
    if read64(s, po + 32) < get(w, 160):
        return 0
    if read64(s, po + 32) == get(w, 160) and read64(s, po + 40) <= get(w, 168):
        return 0
    f = 256 + read64(s, 96)
    if read64(s, f + 16) != get(w, 216) or read64(s, f + 24) != get(w, 224) or read64(s, f + 32) < get(w, 232):
        return 0
    fw = f + 128 + read64(s, f + 48) + read64(s, f + 56)
    if read64(s, fw + 16) != get(w, 240) or read64(s, fw + 24) != get(w, 248):
        return 0
    if read64(s, fw + 32) < get(w, 256) or read64(s, fw + 40) < get(w, 264):
        return 0
    if read64(s, fw + 216) < get(w, 288) or read64(s, fw + 224) < get(w, 296):
        return 0
    return 1

def pb_begin(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if pb_begin_shape(s) == 0:
        return pb_refuse(o, w, 6)
    if get(w, 0) == PB_MAGIC and get(w, 8) == 1:
        if length(s) != get(w, 304):
            return pb_refuse(o, w, 7)
        at = 0
        while at < 256:
            if read64(s, at) != get(w, 512 + at):
                return pb_refuse(o, w, 7)
            at = at + 8
        f = 256 + read64(s, 96)
        at = 0
        while at < 128:
            if read64(s, 256 + at) != get(w, 1536 + at) or read64(s, f + at) != get(w, 1664 + at):
                return pb_refuse(o, w, 7)
            at = at + 8
        return pb_prepare(s, o, w)
    if pb_begin_state(s, w) == 0:
        return pb_refuse(o, w, 8)
    po = 384 + read64(s, 304)
    role = pb_selected(read64(s, po + 48))
    if role == 10 and read64(s, 72) <= get(w, 456):
        return pb_refuse(o, w, 9)
    if role == 11 and read64(s, 88) <= get(w, 464):
        return pb_refuse(o, w, 9)
    old10 = get(w, 456)
    old11 = get(w, 464)
    ui_zero(w, 0, 2048)
    put(w, 456, old10)
    put(w, 464, old11)
    put(w, 0, PB_MAGIC)
    put(w, 8, 1)
    copy_input(w, s, 16, 16, 80)
    put(w, 96, role)
    if role == 10:
        put(w, 104, read64(s, 64))
        put(w, 112, read64(s, 72))
    elif role == 11:
        put(w, 104, read64(s, 80))
        put(w, 112, read64(s, 88))
    put(w, 128, read64(s, 272))
    put(w, 136, read64(s, 280))
    put(w, 144, read64(s, 288))
    put(w, 152, read64(s, 112))
    put(w, 160, read64(s, po + 32))
    put(w, 168, read64(s, po + 40))
    put(w, 176, read64(s, po + 48))
    put(w, 184, read64(s, po + 56))
    put(w, 192, read64(s, po + 72))
    put(w, 200, 256 + read64(s, po + 128))
    put(w, 208, 2048)
    f = 256 + read64(s, 96)
    fw = f + 128 + read64(s, f + 48) + read64(s, f + 56)
    put(w, 216, read64(s, f + 16))
    put(w, 224, read64(s, f + 24))
    put(w, 232, read64(s, f + 32))
    put(w, 240, read64(s, fw + 16))
    put(w, 248, read64(s, fw + 24))
    put(w, 256, read64(s, fw + 32))
    put(w, 264, read64(s, fw + 40))
    put(w, 272, read64(s, fw + 80))
    put(w, 280, read64(s, fw + 88))
    put(w, 288, read64(s, fw + 216))
    put(w, 296, read64(s, fw + 224))
    put(w, 304, length(s))
    put(w, 416, get(w, 288))
    put(w, 424, get(w, 296))
    copy_input(w, s, 512, 0, 256)
    copy_input(w, s, 768, po + 256, 256)
    copy_input(w, s, 1536, 256, 128)
    copy_input(w, s, 1664, f, 128)
    return pb_prepare(s, o, w)

def pb_command(w:mutbuf) -> u64:
    return ui_align(2048, get(w, 200))

def pb_command_capacity(w:mutbuf) -> u64:
    if get(w, 200) < 512:
        return 0
    n = get(w, 200) - 512
    if n > 18446744073709551355:
        return 0
    size = n + 260
    if size < 656:
        size = 656
    return size

def pb_fs_capacity(w:mutbuf) -> u64:
    if get(w, 200) < 512:
        return 0
    n = get(w, 200) - 512
    if n < 9:
        n = 9
    if n > 18446744073709550975:
        return 0
    return n + 640

def pb_prepare(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    c = pb_command(w)
    cn = pb_command_capacity(w)
    fn = pb_fs_capacity(w)
    if c == 0 or cn == 0 or fn == 0:
        return pb_refuse(o, w, 10)
    f = ui_align(c, cn)
    if f == 0:
        return pb_refuse(o, w, 10)
    a = ui_align(f, fn)
    if a == 0:
        return pb_refuse(o, w, 10)
    v = ui_align(a, 512)
    if v == 0:
        return pb_refuse(o, w, 10)
    n = get(w, 200) - 512
    end = ui_align(v, n + 39)
    if end == 0:
        return pb_refuse(o, w, 10)
    put(w, 312, end)
    put(w, 360, end)
    put(w, 368, a)
    put(w, 408, cn)
    put(w, 440, v)
    put(w, 472, f)
    put(w, 480, fn)
    if length(w) < end:
        return pb_emit(o, w, 2)
    out = 384 + read64(s, 304)
    copy_input(w, s, 2048, out, get(w, 200))
    if get(w, 96) == 0:
        put(w, 8, 7)
        return pb_emit(o, w, 5)
    ui_zero(w, c, 256)
    put(w, c + 8, 1)
    put(w, c + 16, get(w, 16))
    put(w, c + 24, get(w, 24))
    put(w, c + 32, get(w, 32))
    put(w, c + 136, get(w, 104))
    copy_input(w, s, c + 256, out + 512, n)
    size = 256 + n
    if get(w, 96) == 10:
        put(w, c, PB_RO)
        put(w, c + 64, get(w, 832))
        put(w, c + 72, get(w, 840))
        put(w, c + 80, get(w, 192))
        put(w, c + 96, get(w, 272))
        put(w, c + 104, get(w, 280))
        put(w, c + 112, get(w, 288))
        put(w, c + 120, get(w, 296))
        put(w, c + 128, n)
    else:
        put(w, c, PB_CM)
        put(w, c + 80, n)
        put(w, c + 104, get(w, 192))
        put(w, c + 120, get(w, 152))
        if get(w, 176) == 6:
            put(w, c + 48, 1)
            put(w, c + 64, get(w, 832))
            put(w, c + 72, get(w, 840))
            put(w, c + 128, n)
            put(w, c + 144, get(w, 272))
            put(w, c + 152, get(w, 280))
            put(w, c + 160, get(w, 288))
            put(w, c + 168, get(w, 296))
            put(w, c + 176, 1)
        else:
            put(w, c + 48, 3)
            put(w, c + 72, get(w, 832))
            put(w, c + 88, 4)
            put(w, c + 96, get(w, 848))
            put(w, c + 128, n + 4)
            put(w, c + 176, get(w, 840))
            put(w, c + 184, 1)
            i = 0
            while i < 4:
                store(w, c + 256 + n + i, (PB_PSOW >> (i * 8)) & 255)
                i = i + 1
            size = size + 4
    move_workspace(w, 1024, c, 256)
    put(w, 1792, 256)
    put(w, 1800, 1024)
    put(w, 1824, 0)
    put(w, 8, 2)
    return pb_issue(o, w, get(w, 96), c, size, 256, 1024)

def pb_stored(w:mutbuf) -> u64:
    if get(w, 0) != PB_MAGIC or get(w, 8) < 2 or get(w, 8) > 4:
        return 0
    if (get(w, 16) | get(w, 24)) == 0 or get(w, 32) == 0 or get(w, 40) == 0 or get(w, 48) == 0 or get(w, 56) == 0:
        return 0
    if get(w, 96) != pb_selected(get(w, 176)) or (get(w, 96) != 10 and get(w, 96) != 11):
        return 0
    if get(w, 104) != choose(get(w, 96) == 10, get(w, 64), get(w, 80)):
        return 0
    if get(w, 112) != choose(get(w, 96) == 10, get(w, 72), get(w, 88)):
        return 0
    if get(w, 104) == 0 or get(w, 112) == 0 or get(w, 152) == 0 or get(w, 216) == 0 or get(w, 224) == 0 or get(w, 232) == 0:
        return 0
    if get(w, 200) < 512 or get(w, 208) != 2048:
        return 0
    c = pb_command(w)
    cn = pb_command_capacity(w)
    fn = pb_fs_capacity(w)
    if c == 0 or cn == 0 or fn == 0 or get(w, 408) != cn or get(w, 480) != fn:
        return 0
    f = ui_align(c, cn)
    if f == 0 or get(w, 472) != f:
        return 0
    a = ui_align(f, fn)
    if a == 0 or get(w, 368) != a:
        return 0
    v = ui_align(a, 512)
    if v == 0 or get(w, 440) != v:
        return 0
    end = ui_align(v, get(w, 200) - 512 + 39)
    if end == 0 or get(w, 312) != end or get(w, 360) != end or end > length(w):
        return 0
    if get(w, 2048) != UI_PARENT or get(w, 2056) != 1 or get(w, 2176) != get(w, 200) - 256:
        return 0
    if get(w, 2080) != get(w, 160) or get(w, 2088) != get(w, 168) or get(w, 2096) != get(w, 176) or get(w, 2104) != get(w, 184):
        return 0
    if get(w, 2296) != get(w, 152) or get(w, 768) != UI_PENDING:
        return 0
    at = 0
    while at < 256:
        if get(w, 768 + at) != get(w, 2304 + at):
            return 0
        at = at + 8
    if get(w, 1824) == 0 and get(w, 120) != 0 and get(w, 8) == 3:
        return 0
    if get(w, 8) == 3:
        if get(w, 320) != 6 or get(w, 328) != f or get(w, 336) < 640 or get(w, 336) > fn:
            return 0
        if get(w, 344) != 256 or get(w, 352) != 4096:
            return 0
    else:
        if get(w, 320) != get(w, 96) or get(w, 328) != c or get(w, 336) < 256 or get(w, 336) > cn:
            return 0
        if get(w, 344) < 256 or get(w, 352) < 1024:
            return 0
    if get(w, 8) == 4:
        if get(w, 376) != 512 or get(w, 432) == 0 or get(w, 432) != get(w, 120) or get(w, 488) != 1:
            return 0
    return choose(get(w, 384) == 0, 1, 0)

def pb_issue(o:mutbuf, w:mutbuf, role:u64, start:u64, amount:u64, outneed:u64, workneed:u64) -> u32:
    if get(w, 40) == 18446744073709551615:
        return pb_refuse(o, w, 11)
    if ui_span(get(w, 312), start, amount) == 0 or amount < 256 or outneed < 256:
        return pb_refuse(o, w, 11)
    if role == 6:
        if start != get(w, 472) or amount > get(w, 480) or workneed != 4096:
            return pb_refuse(o, w, 11)
    elif role != get(w, 96) or start != pb_command(w) or amount > get(w, 408) or workneed < 1024:
        return pb_refuse(o, w, 11)
    put(w, 40, get(w, 40) + 1)
    put(w, 320, role)
    put(w, 328, start)
    put(w, 336, amount)
    put(w, 344, outneed)
    put(w, 352, workneed)
    return pb_emit(o, w, 1)

def pb_capsule_shape(s:readbuf, w:mutbuf) -> u64:
    if read64(s, 64) != length(s) - 256:
        return 0
    at = 72
    while at < 256:
        if read64(s, at) != 0:
            return 0
        at = at + 8
    role = get(w, 320)
    if ui_capsule(s, 256, read64(s, 64), role) == 0:
        return 0
    context = get(w, 104)
    generation = get(w, 112)
    serial = get(w, 120)
    if role == 6:
        context = get(w, 216)
        generation = get(w, 224)
        serial = get(w, 232)
    if read64(s, 272) != context or read64(s, 280) != generation or read64(s, 288) <= serial:
        return 0
    if role != 6:
        if serial == 18446744073709551615 or read64(s, 288) != serial + 1:
            return 0
        if get(w, 1824) != 0 and read64(s, 328) != get(w, 1824):
            return 0
    if read64(s, 360) != get(w, 56) or read64(s, 368) != get(w, 40) or read64(s, 376) != get(w, 32):
        return 0
    if read64(s, 304) != get(w, 336):
        return 0
    at = 0
    while at < get(w, 336):
        if byte(s, 384 + at) != byte(w, get(w, 328) + at):
            return 0
        at = at + 1
    return 1

def pb_completed(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if pb_capsule_shape(s, w) == 0:
        return pb_refuse(o, w, 12)
    if get(w, 320) == 6:
        return pb_fs_completed(s, o, w)
    if read64(s, 312) < 256 or read64(s, 320) < 1024:
        return pb_refuse(o, w, 13)
    out = 384 + read64(s, 304)
    work = out + read64(s, 312)
    if pb_policy_shape(s, out, work, w) == 0:
        return pb_refuse(o, w, 14)
    status = read64(s, 296)
    if status == 2:
        return pb_policy_grow(s, o, w, out, work)
    if status == 1:
        return pb_policy_request(s, o, w, out, work)
    if status == 0:
        return pb_policy_terminal(s, o, w, out, work)
    if status == 3 and get(w, 96) == 10:
        return pb_policy_warning(s, o, w, out, work)
    return pb_refuse(o, w, 15)

def pb_policy_shape(s:readbuf, out:u64, work:u64, w:mutbuf) -> u64:
    magic = choose(get(w, 96) == 10, PB_RO, PB_CM)
    if read64(s, out) != magic or read64(s, work) != magic or read64(s, out + 8) != read64(s, 296):
        return 0
    at = 16
    while at < 40:
        if read64(s, out + at) != get(w, at) or read64(s, work + at) != get(w, at):
            return 0
        at = at + 8
    if read64(s, out + 40) != read64(s, work + 40) or read64(s, out + 48) != read64(s, work + 48):
        return 0
    if read64(s, out + 128) > read64(s, 312) - 256:
        return 0
    if read64(s, out + 136) < 1024 or read64(s, out + 144) < 256 or read64(s, out + 152) != 0:
        return 0
    if read64(s, 296) != 2:
        if read64(s, out + 136) > read64(s, 320) or read64(s, out + 144) > read64(s, 312):
            return 0
    if get(w, 96) == 10:
        return pb_ro_shape(s, out, work, w)
    return pb_cm_shape(s, out, work, w)

def pb_ro_shape(s:readbuf, out:u64, work:u64, w:mutbuf) -> u64:
    if read64(s, out + 56) != read64(s, work + 56) or read64(s, out + 88) != read64(s, work + 8):
        return 0
    if read64(s, out + 64) != read64(s, work + 128) or read64(s, out + 72) != read64(s, work + 136) or read64(s, out + 80) != read64(s, work + 112):
        return 0
    if read64(s, out + 80) > 4095 or read64(s, out + 96) != read64(s, work + 184) or read64(s, out + 104) != read64(s, work + 192):
        return 0
    if read64(s, out + 112) != read64(s, work + 80) or read64(s, out + 120) != read64(s, work + 88):
        return 0
    if read64(s, out + 136) != read64(s, work + 152) or read64(s, out + 144) != read64(s, work + 160) or read64(s, work + 168) != 0:
        return 0
    if read64(s, out + 160) != 1 or read64(s, out + 168) != get(w, 272) or read64(s, out + 176) != get(w, 280):
        return 0
    if read64(s, work + 64) != get(w, 272) or read64(s, work + 72) != get(w, 280) or read64(s, work + 248) != get(w, 104) or read64(s, out + 184) != get(w, 104):
        return 0
    if read64(s, work + 96) != get(w, 1088) or read64(s, work + 104) != get(w, 1096) or read64(s, work + 120) != get(w, 200) - 512:
        return 0
    at = 192
    while at < 256:
        if read64(s, out + at) != 0:
            return 0
        at = at + 8
    at = 0
    while at < 256:
        if read64(s, work + 256 + at) != get(w, 1024 + at):
            return 0
        at = at + 8
    if read64(s, work + 8) != 1:
        if read64(s, out + 136) > read64(s, 320) or ui_span(read64(s, 320), 1024, get(w, 200) - 512) == 0:
            return 0
        at = 0
        while at < get(w, 200) - 512:
            if byte(s, work + 1024 + at) != byte(w, 2560 + at):
                return 0
            at = at + 1
    return 1

def pb_cm_shape(s:readbuf, out:u64, work:u64, w:mutbuf) -> u64:
    at = 56
    while at < 128:
        if read64(s, out + at) != read64(s, work + at):
            return 0
        at = at + 8
    if read64(s, out + 88) > 4095 or read64(s, out + 136) != read64(s, work + 144) or read64(s, out + 144) != read64(s, work + 152):
        return 0
    if read64(s, work + 160) != 0 or read64(s, out + 160) != read64(s, work + 8):
        return 0
    if read64(s, out + 168) != get(w, 152) or read64(s, work + 248) != get(w, 152):
        return 0
    if read64(s, out + 176) != get(w, 104) or read64(s, work + 168) != get(w, 104):
        return 0
    if read64(s, out + 184) != read64(s, work + 192) or read64(s, out + 192) != read64(s, work + 200):
        return 0
    if read64(s, out + 200) != read64(s, work + 176) or read64(s, out + 208) != read64(s, work + 184):
        return 0
    if read64(s, out + 216) != get(w, 1088) or read64(s, work + 208) != get(w, 1088):
        return 0
    if read64(s, out + 224) != get(w, 1096) or read64(s, work + 224) != get(w, 1096):
        return 0
    if read64(s, out + 232) != get(w, 1104) or read64(s, work + 216) != get(w, 1104):
        return 0
    if read64(s, work + 232) != get(w, 1112) or read64(s, work + 240) != get(w, 1120):
        return 0
    if read64(s, out + 240) != 1 or read64(s, out + 248) != 0 or read64(s, out + 48) != get(w, 1072):
        return 0
    if get(w, 176) == 6:
        if read64(s, out + 200) != get(w, 272) or read64(s, out + 208) != get(w, 280):
            return 0
    elif (read64(s, out + 184) | read64(s, out + 192) | read64(s, out + 200) | read64(s, out + 208)) != 0:
        return 0
    at = 0
    while at < 256:
        if read64(s, work + 512 + at) != get(w, 1024 + at):
            return 0
        at = at + 8
    return 1

def pb_observe_child(s:readbuf, w:mutbuf) -> u64:
    put(w, 120, read64(s, 288))
    put(w, 1824, read64(s, 328))
    return 0

def pb_policy_grow(s:readbuf, o:mutbuf, w:mutbuf, out:u64, work:u64) -> u32:
    if read64(s, out + 128) != 0:
        return pb_refuse(o, w, 16)
    neededw = read64(s, out + 136)
    neededo = read64(s, out + 144)
    if neededw <= read64(s, 320) and neededo <= read64(s, 312):
        return pb_refuse(o, w, 16)
    phase = read64(s, work + 8)
    command = get(w, pb_command(w) + 8)
    if command == 1:
        if phase != 1 or read64(s, out + 40) != 0:
            return pb_refuse(o, w, 17)
    elif command != 2 or get(w, 96) != 10 or phase != 2 or read64(s, out + 40) != get(w, 392):
        return pb_refuse(o, w, 17)
    pb_observe_child(s, w)
    put(w, 1792, neededo)
    put(w, 1800, neededw)
    return pb_issue(o, w, get(w, 96), pb_command(w), get(w, 336), neededo, neededw)

def pb_policy_request(s:readbuf, o:mutbuf, w:mutbuf, out:u64, work:u64) -> u32:
    if read64(s, work + 8) != 2 or get(w, 392) == 18446744073709551615 or read64(s, out + 40) != get(w, 392) + 1:
        return pb_refuse(o, w, 18)
    if get(w, 96) == 11 and get(w, 176) != 6:
        return pb_refuse(o, w, 18)
    amount = read64(s, out + 128)
    if amount < 256 or amount > get(w, 480) - 384:
        return pb_refuse(o, w, 19)
    inner = out + 256
    if pb_fs_request_shape(s, out, inner, amount, w) == 0:
        return pb_refuse(o, w, 19)
    if get(w, 256) == 18446744073709551615:
        return pb_refuse(o, w, 20)
    f = get(w, 472)
    ui_zero(w, f, 384)
    put(w, f, UI_FS_CHANNEL)
    put(w, f + 8, 1)
    put(w, f + 32, 256 + amount)
    put(w, f + 88, 4096)
    put(w, f + 128, UI_JOIN)
    put(w, f + 136, 11)
    put(w, f + 144, get(w, 240))
    put(w, f + 152, get(w, 248))
    put(w, f + 160, get(w, 256) + 1)
    put(w, f + 176, read64(s, inner + 104))
    put(w, f + 240, amount)
    copy_input(w, s, f + 384, inner, amount)
    pb_observe_child(s, w)
    put(w, 392, read64(s, out + 40))
    put(w, 400, read64(s, out + 48))
    put(w, 1792, read64(s, out + 144))
    put(w, 1800, read64(s, out + 136))
    put(w, 8, 3)
    return pb_issue(o, w, 6, f, 384 + amount, 256, 4096)

def pb_fs_request_shape(s:readbuf, out:u64, inner:u64, amount:u64, w:mutbuf) -> u64:
    if read64(s, inner) != PB_FS or read64(s, inner + 8) != 2:
        return 0
    if read64(s, inner + 16) != get(w, 272) or read64(s, inner + 24) != get(w, 280):
        return 0
    if get(w, 288) == 18446744073709551615 or get(w, 296) == 18446744073709551615:
        return 0
    if read64(s, inner + 32) != get(w, 288) + 1 or read64(s, inner + 40) != 0 or read64(s, inner + 56) != 0:
        return 0
    if read64(s, inner + 96) != amount - 256 or read64(s, inner + 104) != read64(s, out + 40):
        return 0
    at = 112
    while at < 256:
        if read64(s, inner + at) != 0:
            return 0
        at = at + 8
    if get(w, 96) == 10:
        op = read64(s, inner + 48)
        if op != read64(s, out + 48) or (op != 28 and op != 9 and op != 8 and op != 15 and op != 21):
            return 0
        return choose(read64(s, out + 112) == get(w, 288) + 1 and read64(s, out + 120) == get(w, 296) + 1, 1, 0)
    if read64(s, inner + 48) != 29 or read64(s, out + 48) != 1:
        return 0
    return choose(read64(s, out + 184) == get(w, 288) + 1 and read64(s, out + 192) == get(w, 296) + 1, 1, 0)

def pb_fs_completed(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if get(w, 8) != 3 or ui_fs_ready(s, 256) == 0:
        return pb_refuse(o, w, 21)
    out = 384 + read64(s, 304)
    work = out + read64(s, 312)
    if pb_ready_fields(s, work) == 0:
        return pb_refuse(o, w, 21)
    if read64(s, work + 16) != get(w, 240) or read64(s, work + 24) != get(w, 248):
        return pb_refuse(o, w, 22)
    if get(w, 256) == 18446744073709551615 or read64(s, work + 32) != get(w, 256) + 1 or read64(s, work + 40) <= get(w, 264):
        return pb_refuse(o, w, 22)
    if read64(s, work + 80) != get(w, 272) or read64(s, work + 88) != get(w, 280):
        return pb_refuse(o, w, 22)
    if get(w, 288) == 18446744073709551615 or get(w, 296) == 18446744073709551615:
        return pb_refuse(o, w, 22)
    if read64(s, work + 216) != get(w, 288) + 1 or read64(s, work + 224) != get(w, 296) + 1:
        return pb_refuse(o, w, 22)
    extent = read64(s, out + 128)
    if extent != 256 and extent != 400:
        return pb_refuse(o, w, 23)
    if read64(s, out + 64) != extent or read64(s, out + 104) != get(w, get(w, 472) + 176) or read64(s, out + 112) != 0 or read64(s, out + 176) != 1:
        return pb_refuse(o, w, 23)
    if (read64(s, out + 48) | read64(s, out + 56) | read64(s, out + 72) | read64(s, out + 80) | read64(s, out + 88) | read64(s, out + 96) | read64(s, out + 120) | read64(s, out + 136) | read64(s, out + 144) | read64(s, out + 152)) != 0:
        return pb_refuse(o, w, 23)
    fs = out + 256
    if pb_fs_reply_shape(s, fs, extent, w) == 0:
        return pb_refuse(o, w, 24)
    c = pb_command(w)
    if 256 + extent > get(w, 408):
        return pb_refuse(o, w, 24)
    ui_zero(w, c, 256)
    put(w, c, choose(get(w, 96) == 10, PB_RO, PB_CM))
    put(w, c + 8, 2)
    put(w, c + 16, get(w, 16))
    put(w, c + 24, get(w, 24))
    put(w, c + 32, get(w, 32))
    put(w, c + 40, get(w, 392))
    put(w, c + 48, get(w, 400))
    put(w, c + 128, extent)
    put(w, c + 136, get(w, 104))
    if get(w, 96) == 11:
        put(w, c + 120, get(w, 152))
    copy_input(w, s, c + 256, fs, extent)
    put(w, 232, read64(s, 288))
    put(w, 256, read64(s, work + 32))
    put(w, 264, read64(s, work + 40))
    put(w, 288, read64(s, work + 216))
    put(w, 296, read64(s, work + 224))
    put(w, 1824, 0)
    put(w, 8, 2)
    return pb_issue(o, w, get(w, 96), c, 256 + extent, get(w, 1792), get(w, 1800))

def pb_fs_reply_shape(s:readbuf, fs:u64, extent:u64, w:mutbuf) -> u64:
    request = get(w, 472) + 384
    if read64(s, fs) != PB_FS or read64(s, fs + 8) != 0:
        return 0
    if read64(s, fs + 16) != get(w, 272) or read64(s, fs + 24) != get(w, 280):
        return 0
    if read64(s, fs + 32) != get(w, 288) + 1 or read64(s, fs + 40) != get(w, 296) + 1:
        return 0
    if read64(s, fs + 48) != get(w, request + 48) or read64(s, fs + 56) > 4095:
        return 0
    if read64(s, fs + 112) != get(w, request + 104) or read64(s, fs + 120) != 1 or read64(s, fs + 128) != extent - 256 or read64(s, fs + 176) != 3:
        return 0
    if (read64(s, fs + 136) | read64(s, fs + 144) | read64(s, fs + 152) | read64(s, fs + 184)) != 0:
        return 0
    at = 200
    while at < 256:
        if read64(s, fs + at) != 0:
            return 0
        at = at + 8
    if read64(s, fs + 56) != 0:
        return choose(extent == 256, 1, 0)
    return 1

def pb_policy_terminal(s:readbuf, o:mutbuf, w:mutbuf, out:u64, work:u64) -> u32:
    if read64(s, out + 128) != 0:
        return pb_refuse(o, w, 25)
    if get(w, 96) == 10:
        if read64(s, work + 8) != 4 or (read64(s, out + 48) | read64(s, out + 56)) != 0:
            return pb_refuse(o, w, 25)
        if read64(s, out + 40) != get(w, 392):
            return pb_refuse(o, w, 25)
        if read64(s, out + 112) != get(w, 288) or read64(s, out + 120) != get(w, 296):
            return pb_refuse(o, w, 25)
        token = read64(s, out + 64)
        fd = read64(s, out + 72)
        if token == 0:
            if fd != 18446744073709551615:
                return pb_refuse(o, w, 26)
        elif fd < 3 or fd > 2147483647:
            return pb_refuse(o, w, 26)
    else:
        if read64(s, work + 8) != 3 or read64(s, out + 40) != get(w, 392):
            return pb_refuse(o, w, 27)
        if get(w, 176) == 6:
            if read64(s, out + 184) != get(w, 288) or read64(s, out + 192) != get(w, 296):
                return pb_refuse(o, w, 27)
            rc = read64(s, out + 56)
            if rc != 0 and rc != 1802:
                return pb_refuse(o, w, 27)
            if rc == 1802 and (read64(s, out + 64) | read64(s, out + 72) | read64(s, out + 80)) != 0:
                return pb_refuse(o, w, 27)
            if read64(s, out + 64) > 511 or read64(s, out + 72) > 4294967295 or read64(s, out + 80) > 4294967295:
                return pb_refuse(o, w, 27)
        elif read64(s, out + 56) != 0 or read64(s, out + 96) > 1 or (read64(s, out + 64) | read64(s, out + 72) | read64(s, out + 80)) != 0:
            return pb_refuse(o, w, 27)
    if get(w, 40) == 18446744073709551615:
        return pb_refuse(o, w, 28)
    pb_observe_child(s, w)
    copy_input(w, s, 1280, out, 256)
    put(w, 432, get(w, 120))
    pb_parent_ack(w)
    put(w, 376, 512)
    put(w, 488, 1)
    put(w, 40, get(w, 40) + 1)
    put(w, 8, 4)
    return pb_emit(o, w, 4)

def pb_parent_ack(w:mutbuf) -> u64:
    a = get(w, 368)
    ui_zero(w, a, 512)
    put(w, a, UI_PARENT)
    put(w, a + 8, 2)
    move_workspace(w, a + 16, 2064, 48)
    if get(w, 96) == 10:
        put(w, a + 64, get(w, 1360))
        put(w, a + 72, get(w, 1344))
        put(w, a + 80, get(w, 1352))
    else:
        put(w, a + 64, get(w, 1368))
        if get(w, 176) == 6:
            put(w, a + 72, get(w, 1336))
            put(w, a + 80, get(w, 1344))
            put(w, a + 88, get(w, 1352))
            put(w, a + 96, get(w, 1360))
        else:
            put(w, a + 72, get(w, 1376))
    put(w, a + 120, get(w, 288))
    put(w, a + 128, get(w, 296))
    put(w, a + 144, choose(get(w, 96) == 10, 7, 8))
    put(w, a + 152, get(w, 104))
    put(w, a + 160, get(w, 112))
    put(w, a + 168, get(w, 432))
    put(w, a + 176, get(w, 152))
    move_workspace(w, a + 256, 768, 256)
    return 0

def pb_policy_warning(s:readbuf, o:mutbuf, w:mutbuf, out:u64, work:u64) -> u32:
    n = get(w, 200) - 512 + 39
    if read64(s, work + 8) != 3 or read64(s, out + 128) != n or read64(s, out + 48) != 28 or read64(s, out + 56) != 22:
        return pb_refuse(o, w, 29)
    if get(w, 392) == 18446744073709551615 or read64(s, out + 40) != get(w, 392) + 1:
        return pb_refuse(o, w, 29)
    if read64(s, out + 112) != get(w, 288) or read64(s, out + 120) != get(w, 296):
        return pb_refuse(o, w, 29)
    if ui_span(get(w, 312), get(w, 440), n) == 0:
        return pb_refuse(o, w, 29)
    pb_observe_child(s, w)
    put(w, 392, read64(s, out + 40))
    copy_input(w, s, 1280, out, 256)
    copy_input(w, s, get(w, 440), out + 256, n)
    put(w, 448, n)
    put(w, 8, 6)
    return pb_emit(o, w, 3)

def pb_retired(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(s) != 320 or read64(s, 64) != 64:
        return pb_refuse(o, w, 30)
    at = 72
    while at < 256:
        if read64(s, at) != 0:
            return pb_refuse(o, w, 30)
        at = at + 8
    if read64(s, 256) != PB_RETIRE or read64(s, 264) != get(w, 96) or read64(s, 272) != get(w, 104) or read64(s, 280) != get(w, 112):
        return pb_refuse(o, w, 31)
    if read64(s, 288) != 0 or read64(s, 296) != get(w, 32) or read64(s, 304) != get(w, 40) or read64(s, 312) != 1:
        return pb_refuse(o, w, 31)
    if get(w, 96) == 10:
        put(w, 456, get(w, 112))
    else:
        put(w, 464, get(w, 112))
    put(w, 8, 5)
    return pb_emit(o, w, 0)

def pb_refuse(o:mutbuf, w:mutbuf, reason:u64) -> u32:
    if get(w, 0) != PB_BAD:
        put(w, 384, reason)
    put(w, 0, PB_BAD)
    put(w, 8, 8)
    return pb_emit(o, w, 4294967293)

def pb_emit(o:mutbuf, w:mutbuf, status:u64) -> u32:
    if length(o) < 256:
        return 4294967293
    ui_zero(o, 0, 256)
    put(o, 0, PB_EVENT)
    put(o, 8, status)
    copy_workspace(o, w, 16, 16, 48)
    put(o, 64, get(w, 8))
    put(o, 72, get(w, 96))
    put(o, 144, get(w, 360))
    put(o, 152, 256)
    if status == 1 or status == 4:
        role = get(w, 320)
        put(o, 80, role)
        if status == 1:
            put(o, 88, get(w, 328))
            put(o, 96, get(w, 336))
        if role == 6:
            put(o, 104, get(w, 216))
            put(o, 112, get(w, 224))
            put(o, 120, get(w, 232))
        else:
            put(o, 104, get(w, 104))
            put(o, 112, get(w, 112))
            put(o, 120, get(w, 120))
        put(o, 128, get(w, 344))
        put(o, 136, get(w, 352))
    if status == 0:
        put(o, 160, get(w, 368))
        put(o, 168, get(w, 376))
    elif status == 3:
        put(o, 160, get(w, 440))
        put(o, 168, get(w, 448))
    elif status == 5:
        put(o, 160, get(w, 208))
        put(o, 168, get(w, 200))
    put(o, 176, get(w, 384))
    put(o, 184, get(w, 176))
    put(o, 192, get(w, 184))
    put(o, 200, get(w, 128))
    put(o, 208, get(w, 136))
    put(o, 216, get(w, 144))
    put(o, 224, get(w, 160))
    put(o, 232, get(w, 168))
    put(o, 240, get(w, 152))
    put(o, 248, 1)
    return status

'''

# Exactly copied helper definitions from issuer abbb7f40338e7b099e855281d7dab9ff64834eed.
INHERITED=r'''
def ui_zero(w:mutbuf, at:u64, size:u64) -> u64:
    end = at + size
    while at < end:
        put(w, at, 0)
        at = at + 8
    return 0

def ui_align(at:u64, size:u64) -> u64:
    if at > 18446744073709551608:
        return 0
    if size > 18446744073709551608 - at:
        return 0
    return (at + size + 7) & 18446744073709551608

def ui_span(total:u64, at:u64, size:u64) -> u64:
    return choose(at <= total and size <= total - at, 1, 0)

def ui_capsule(s:readbuf, at:u64, size:u64, role:u64) -> u64:
    if size < 128 or ui_span(length(s), at, size) == 0:
        return 0
    if read64(s, at) != UI_CAPSULE or read64(s, at + 8) != role:
        return 0
    if read64(s, at + 16) == 0 or read64(s, at + 24) == 0 or read64(s, at + 32) == 0:
        return 0
    if read64(s, at + 40) > 4294967295 or read64(s, at + 72) == 0 or read64(s, at + 104) == 0:
        return 0
    if read64(s, at + 80) != 1 or read64(s, at + 88) != choose(role == 8, 1, 0):
        return 0
    if read64(s, at + 96) != 0:
        return 0
    left = size - 128
    first = read64(s, at + 48)
    second = read64(s, at + 56)
    if first == 0 or first > left:
        return 0
    left = left - first
    if second > left:
        return 0
    return choose(read64(s, at + 64) == left - second, 1, 0)

def ui_parent(s:readbuf, cap:u64) -> u64:
    if read64(s, cap + 40) != 1 or read64(s, cap + 56) < 512 or read64(s, cap + 64) < 4096:
        return 0
    out = cap + 128 + read64(s, cap + 48)
    work = out + read64(s, cap + 56)
    if read64(s, out) != UI_PARENT or read64(s, out + 8) != 1:
        return 0
    if read64(s, out + 128) < 256 or read64(s, out + 128) > read64(s, cap + 56) - 256:
        return 0
    if read64(s, work) != UI_PARENT or read64(s, work + 8) != 2:
        return 0
    at = 16
    while at < 64:
        if read64(s, out + at) != read64(s, work + at):
            return 0
        at = at + 8
    if read64(s, out + 32) == 0 or read64(s, out + 40) == 0 or read64(s, out + 248) == 0:
        return 0
    if read64(s, out + 48) < 1 or read64(s, out + 48) > 18:
        return 0
    q = out + 256
    if read64(s, q) != UI_PENDING or read64(s, q + 8) != 1:
        return 0
    at = 16
    while at < 64:
        if read64(s, q + at) != read64(s, out + at):
            return 0
        at = at + 8
    if read64(s, q + 112) != read64(s, out + 128) - 256:
        return 0
    if read64(s, q + 128) != read64(s, out + 248) or read64(s, q + 176) != read64(s, cap + 104):
        return 0
    if read64(s, q + 184) != read64(s, out + 72):
        return 0
    at = 192
    while at < 256:
        if read64(s, q + at) != 0:
            return 0
        at = at + 8
    return 1

def ui_fs_ready(s:readbuf, cap:u64) -> u64:
    if read64(s, cap + 40) != 0 or read64(s, cap + 56) < 256 or read64(s, cap + 64) < 4096:
        return 0
    out = cap + 128 + read64(s, cap + 48)
    work = out + read64(s, cap + 56)
    if read64(s, out) != UI_JOIN or read64(s, out + 8) != 0:
        return 0
    if read64(s, out + 128) > read64(s, cap + 56) - 256:
        return 0
    if read64(s, work) != UI_JOIN or read64(s, work + 8) != 1:
        return 0
    at = 16
    while at < 48:
        if read64(s, out + at) != read64(s, work + at):
            return 0
        at = at + 8
    return choose(read64(s, work + 56) >= 4096 and read64(s, work + 56) <= read64(s, cap + 64), 1, 0)

'''

def source_program():
    source=POLICY+INHERITED
    for name,value in CONSTANTS.items():
        source=source.replace(name,str(value))
    return source+VALUES[VALUES.index("\ndef read64("):]

def document():
    nodes=ast.parse(source_program()).body
    names={node.name:"f"+str(index) for index,node in enumerate(nodes)}
    if len(names)!=len(nodes):
        raise ValueError("duplicate UnixOpen policy bridge symbol")
    signatures={node.name:([a.annotation.id for a in node.args.args],node.returns.id) for node in nodes}
    total=total_scalar_functions(nodes)
    functions=[]
    for node in nodes:
        b=ObjectBuilder(node,names,signatures,total)
        b.statements(node.body)
        functions.append({"name":names[node.name],"params":[b.param(v) for v in b.params],
            "returns":[b.returns],"effects":["read","write","trap"],"entry":"b0","blocks":b.blocks})
    return compact_authoring_cfg({"schema":"hepta.hia.program.v8",
        "module":"agent_namespace_unixopen_policy_fs_bridge_r1","functions":functions})

if __name__=="__main__":
    path=ROOT/"examples/hia_bootstrap/agent_namespace_unixopen_policy_fs_bridge_r1.hiaasm"
    path.write_text(render_assembly(document()))
    print(path.name,path.stat().st_size)
