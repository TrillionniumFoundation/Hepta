"""NEW private role-12 controls sourced from actual fixed twelve-role windows.

Five original native windows are replayed in fresh CoreVM and the newly
compiled role-12 image. Twenty-four explicitly private mutations and
twenty-three persistent-poison followups keep complete source/output/workspace
bytes and guards. No mutation is supplied to the public transport, no syscall
is issued by this direct kernel gate, and no external capsule authority is
claimed. All cases run under the unchanged one-group 90 CPU / 180 wall budget.
"""
from __future__ import annotations
import argparse,ctypes,hashlib,importlib.util,json,os,resource,signal,stat,struct,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
REPLAY_SHA="f405c4f3777cb162b59e30f04c353e5314a40742cbd4337d3dfa6795e9a01f3f"
B3_SHA="35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b"
BAD=0xfffffffd
CANARY=bytes(range(160,176))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(raw):return hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
def q(raw,offset):return struct.unpack_from("<Q",raw,offset)[0]
def put(raw,offset,value):struct.pack_into("<Q",raw,offset,value)
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 raw=(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
 path.write_bytes(raw);assert path.read_bytes()==raw
def main():
 started=time.monotonic_ns()
 resource.setrlimit(resource.RLIMIT_CPU,(90,90))
 resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 def expired(*unused):raise TimeoutError("private policy protocol original180wall")
 signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,180)
 p=argparse.ArgumentParser();p.add_argument("--context",type=Path,required=True)
 args=p.parse_args();assert sys.version_info[:3]==(3,12,14)
 context=json.loads(args.context.read_bytes());evidence=Path(context["namespace_evidence"])
 out=evidence/"policy-unixopen-private-r1";out.mkdir()
 report=dict(status="INCOMPLETE",planned_original_controls=5,planned_private_mutations=24,
  planned_persistent_followups=23,planned_direct_native_entries=52,planned_fresh_VM_entries=52,
  original_controls=0,private_mutations=0,persistent_followups=0,
  actual_direct_native_entries=0,direct_native_attempts=0,fresh_VM_entries=0,
  all_complete_buffers_compared=False,private_recorded_issuer_windows_only=True,
  ordinary_external_capsules_authenticated=False,actual_fixed_process_cases=0,
  actual_syscalls=0,prior_counts_inherited=False,ordinary_Store_closed=False,
  limits=dict(CPU_seconds=90,wall_seconds=180,address_bytes=1<<30,core_bytes=0),
  VM_limits=dict(steps=4000000,arena_bytes=32<<20,depth=64),cases=[])
 pins={};failure=None;image=None;cas=None;ledger=None
 def identity(path):
  path=Path(path).absolute();st=path.lstat()
  assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
  raw=path.read_bytes()
  return dict(bytes=len(raw),sha256=sha(raw),gitsha=git(raw),mode=stat.S_IMODE(st.st_mode)),raw
 def pin(path,expected=None):
  row,raw=identity(path);path=str(Path(path).absolute())
  if expected is not None:assert row["sha256"]==expected
  if path in pins:assert row==pins[path]
  else:pins[path]=row
  return raw
 def load(name,path,expected):
  raw=pin(path,expected);spec=importlib.util.spec_from_file_location(name,path)
  mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
  exec(compile(raw,str(path),"exec"),mod.__dict__);return mod
 libc=ctypes.CDLL(None,use_errno=True)
 libc.mmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_long]
 libc.mmap.restype=ctypes.c_void_p
 libc.mprotect.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int];libc.mprotect.restype=ctypes.c_int
 libc.munmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t];libc.munmap.restype=ctypes.c_int
 class Buffer:
  def __init__(self,initial,readonly=False):
   self.size=len(initial);self.middle=(self.size+32+4095)&~4095
   self.total=self.middle+8192;self.raw=None
   address=libc.mmap(None,self.total,0,0x22,-1,0)
   if address==ctypes.c_void_p(-1).value:raise OSError(ctypes.get_errno(),"mmap")
   self.raw=address;self.address=address+4112
   try:
    if libc.mprotect(address+4096,self.middle,3):raise OSError(ctypes.get_errno(),"RW")
    ctypes.memmove(self.address-16,CANARY,16);ctypes.memmove(self.address+self.size,CANARY,16)
    if initial:ctypes.memmove(self.address,initial,self.size)
    if readonly and libc.mprotect(address+4096,self.middle,1):raise OSError(ctypes.get_errno(),"RO")
   except BaseException as primary:
    try:self.close()
    except BaseException as error:primary.add_note("initial mapping cleanup: "+repr(error))
    raise
  def read(self):return ctypes.string_at(self.address,self.size)
  def check(self):
   assert ctypes.string_at(self.address-16,16)==CANARY
   assert ctypes.string_at(self.address+self.size,16)==CANARY
  def close(self):
   if self.raw is not None:
    old=self.raw;self.raw=None
    if libc.munmap(old,self.total):raise OSError(ctypes.get_errno(),"munmap")
 try:
  pin(__file__);pin(args.context)
  here=Path(__file__).resolve().parent
  replay=load("policy_private_record_decoder",here/"policy-unixopen-replay.py",REPLAY_SHA)
  ref=Path(context["reference"]);sys.path.insert(0,str(ref))
  from hepta.hia_agent_assembly import assemble_program
  from hepta.hia_program_runtime import _Machine,_Owner,_View
  from hepta.hia_json_preflight_native import NativeHiaJsonImage
  build=json.loads(pin(evidence/"policy-unixopen-build-r1/summary.json"))
  assert build["status"]=="PASS_BUILD_ONLY" and build["fresh_role_compiles"]==12 and build["packer_entries"]==57
  assert set(build["exact_roles"])=={str(r) for r in range(1,13)}
  role=build["exact_roles"]["12"];source=pin(role["source"]["path"],role["source"]["sha256"])
  image_raw=pin(role["image"]["path"],role["image"]["sha256"])
  assert (len(source),len(image_raw))==(role["source"]["bytes"],role["image"]["bytes"])
  receipt=role["compile_receipt"]
  assert receipt["source_sha256"]==receipt["input_sha256"]==sha(source) and receipt["input_bytes"]==len(source)
  assert receipt["produced_sha256"]==sha(image_raw) and receipt["produced_bytes"]==len(image_raw)
  assert receipt["artifact_sha256"]==receipt["image_sha256"]==B3_SHA
  assert receipt["limits"]["cpu_seconds"]==10 and receipt["limits"]["address_bytes"]==256<<20
  assert receipt["status"]=="returned" and receipt["abi_status"]==0
  program=assemble_program(source);image=NativeHiaJsonImage(image_raw,sha(image_raw))
  assert image.image_sha256==sha(image_raw)
  for mod in tuple(sys.modules.values()):
   filename=getattr(mod,"__file__",None)
   if filename:
    path=Path(filename).resolve()
    if path.is_relative_to(ref) and path.suffix==".py":pin(path)
  selected={};observations=[]
  # Both selected originals are from completed new physical cases in this
  # same subject. The original nine-role result is never a predecessor.
  group=json.loads(pin(evidence/"policy-unixopen-open-success-r1/summary.json"))
  assert group["status"]=="PASS" and group["completed_cases"]==8
  for case in ("new_named_temp","WAL_umask_fchmod"):
   directory=evidence/"policy-unixopen-open-success-r1/cases"/case
   process=json.loads(pin(directory/"actual-issuer-process.json"))
   assert process["returncode"]==0 and process["source_unchanged"]
   assert 0<=process["usage"]["user"]+process["usage"]["system"]<90
   assert 0<=process["elapsed_ns"]<180_000_000_000
   trace=directory/"trace.bin";raw=pin(trace);before=None
   observations.append(dict(case=case,path=str(trace),**pins[str(trace.absolute())]))
   for row in replay.records(trace):
    if row["role"]!=12:continue
    if row["kind"]==1:
     assert before is None;before=row
    elif row["kind"]==2:
     assert before is not None and row["header"][2]==before["header"][2]
     item=dict(before=before,after=row,trace=str(trace),case=case)
     s=before["input"];command=q(s,8);status=row["header"][6]
     if command==1 and status==2:selected.setdefault("own_GROW",item)
     if command==1 and status==1:selected.setdefault("BEGIN_ready",item)
     if command==2 and q(s,264)==10 and status==4:
      selected.setdefault("policy_terminal",item)
     if command==2 and q(s,264)==6:selected.setdefault("FS_completed",item)
     if command==3 and status==0:selected.setdefault("retired",item)
     before=None
   assert before is None
  assert set(selected)=={"own_GROW","BEGIN_ready","policy_terminal","FS_completed","retired"}
  report["actual_selected_trace_sources"]=observations
  cas=replay.CAS(out/"cas");ledger=(out/"entries.jsonl").open("x",encoding="utf-8")
  def observe(label,s,pre_o,pre_w,expected_return,expected_after=None):
   s=bytes(s);pre_o=bytes(pre_o);pre_w=bytes(pre_w)
   number=report["fresh_VM_entries"]+1
   before=dict(label=label,index=number,input=cas.put(s),output_before=cas.put(pre_o),
    workspace_before=cas.put(pre_w),expected_return=expected_return)
   ledger.write(json.dumps(dict(kind="before",**before),sort_keys=True)+"\n");ledger.flush()
   save(out/"frontier.json",before);save(out/"summary.json",report)
   owners=[_Owner(-1,bytearray(s)),_Owner(-2,bytearray(pre_o)),_Owner(-3,bytearray(pre_w))]
   machine=_Machine(program,4000000,32<<20,None,64);document=program.as_dict()
   vret=machine.invoke(document["functions"][0],
    [_View(owners[0],False),_View(owners[1],True),_View(owners[2],True)])[0]
   report["fresh_VM_entries"]+=1
   assert bytes(owners[0].data)==s
   vo,vw=bytes(owners[1].data),bytes(owners[2].data)
   ledger.write(json.dumps(dict(kind="after-VM",label=label,returned=vret,steps=machine.steps,
    output=cas.put(vo),workspace=cas.put(vw)),sort_keys=True)+"\n");ledger.flush()
   a=o=w=None
   try:
    a=Buffer(s,readonly=True);o=Buffer(pre_o);w=Buffer(pre_w)
    report["direct_native_attempts"]+=1;save(out/"summary.json",report)
    nret=int(image._entry(a.address,a.size,o.address,o.size,w.address,w.size))
    report["actual_direct_native_entries"]+=1
    no,nw=o.read(),w.read()
    for view in (a,o,w):view.check()
    assert a.read()==s
    row=dict(label=label,VM_return=vret,native_return=nret,steps=machine.steps,
     input=before["input"],output=cas.put(no),workspace=cas.put(nw),
     all_return_output_workspace_bytes_equal=(nret==vret and no==vo and nw==vw),
     source_unchanged=True,guards=True)
    ledger.write(json.dumps(dict(kind="after-native",**row),sort_keys=True)+"\n");ledger.flush()
    report["cases"].append(row);save(out/"summary.json",report)
    assert nret==vret==expected_return and no==vo and nw==vw
    if expected_after is not None:
     assert no==expected_after["output"] and nw==expected_after["workspace"]
    return no,nw
   finally:
    primary=sys.exception();errors=[]
    for view in (w,o,a):
     if view is not None:
      try:view.close()
      except BaseException as error:errors.append(error)
    if errors:
     if primary is None:
      for error in errors[1:]:errors[0].add_note("later cleanup: "+repr(error))
      raise errors[0]
     for error in errors:primary.add_note("buffer cleanup: "+repr(error))
  for label,item in selected.items():
   before,after=item["before"],item["after"]
   observe("original-"+label,before["input"],before["output"],before["workspace"],
    after["header"][6],after)
   report["original_controls"]+=1
  def make(label,base,edits=(),*,short_s=None,short_o=None,short_w=None,post_state=False):
   item=selected[base];before=item["before"];s=bytearray(before["input"])
   for offset,value in edits:put(s,offset,value)
   o=before["output"];w=item["after"]["workspace"] if post_state else before["workspace"]
   if short_s is not None:s=s[:short_s]
   if short_o is not None:o=o[:short_o]
   if short_w is not None:w=w[:short_w]
   return label,bytes(s),bytes(o),bytes(w),before["input"]
  policy=selected["policy_terminal"]["before"]["input"]
  fs=selected["FS_completed"]["before"]["input"]
  retired=selected["retired"]["before"]["input"]
  begin=selected["own_GROW"]["before"]["input"]
  controls=[
   make("BEGIN-zero-session","own_GROW",((16,0),(24,0))),
   make("BEGIN-zero-call","own_GROW",((32,0),)),
   make("BEGIN-zero-context","own_GROW",((48,0),)),
   make("BEGIN-aliased-policy-contexts","own_GROW",((64,q(begin,80)),)),
   make("BEGIN-reserved","own_GROW",((120,1),)),
   make("completed-wrong-call","policy_terminal",((32,q(policy,32)+1),)),
   make("completed-wrong-action","policy_terminal",((40,q(policy,40)+1),)),
   make("completed-wrong-generation","policy_terminal",((280,q(policy,280)+1),)),
   make("completed-wrong-entry","policy_terminal",((288,q(policy,288)+1),)),
   make("completed-original-input-mismatch","policy_terminal",((384,q(policy,384)^1),)),
   make("FS-completed-wrong-role","FS_completed",((264,10),)),
   make("FS-completed-wrong-PID","FS_completed",((360,q(fs,360)+1),)),
   make("retirement-failed-status","retired",((288,1),)),
   make("retirement-wrong-generation","retired",((280,q(retired,280)+1),)),
   make("retirement-wrong-action","retired",((304,q(retired,304)+1),)),
   make("retirement-wrong-version","retired",((312,2),)),
   make("own-GROW-source-lease-mismatch","BEGIN_ready",((112,0),)),
   make("short-source-255","own_GROW",short_s=255),
   make("short-output-255","own_GROW",short_o=255),
   make("short-workspace-7","own_GROW",short_w=7),
   make("short-workspace-8","own_GROW",short_w=8),
   make("short-workspace-2047","own_GROW",short_w=2047),
   make("duplicate-completed-policy","policy_terminal",post_state=True),
   make("duplicate-retirement","retired",post_state=True)]
  assert len(controls)==24 and len({row[0] for row in controls})==24
  report["private_control_labels"]=[row[0] for row in controls]
  for label,s,o,w,valid_source in controls:
   no,nw=observe(label,s,o,w,BAD);report["private_mutations"]+=1
   if len(w)>=8:
    # A short writable view can only store the poison word. Extend its
    # capacity while preserving every original byte before valid reentry.
    extended=nw+bytes(max(0,2048-len(nw)))
    out_again=no+bytes(max(0,256-len(no)))
    observe(label+"-persistent",valid_source,out_again,extended,BAD)
    report["persistent_followups"]+=1
  assert report["original_controls"]==5 and report["private_mutations"]==24
  assert report["persistent_followups"]==23
  assert report["actual_direct_native_entries"]==report["direct_native_attempts"]==report["fresh_VM_entries"]==52
  assert len(report["cases"])==52
  report["all_complete_buffers_compared"]=True;report["status"]="PASS"
 except BaseException as error:
  failure=error;report.update(status="FAIL",error_class=type(error).__name__,error=str(error),
   traceback=traceback.format_exc())
  try:traceback.print_exc()
  except BaseException as secondary:error.add_note("traceback: "+repr(secondary))
 finally:
  def attempt(label,fn):
   nonlocal failure
   try:return fn()
   except BaseException as error:
    report.setdefault("finalization_errors",[]).append(dict(label=label,error=repr(error)))
    if failure is None:failure=error
    else:failure.add_note(label+": "+repr(error))
  if ledger is not None:attempt("close-ledger",ledger.close)
  if image is not None:attempt("close-image",image.close)
  if cas is not None:attempt("full-CAS-readback",cas.readback)
  after={}
  for path,expected in pins.items():
   def check(path=path,expected=expected):
    row,_=identity(path);after[path]=row;assert row==expected
   attempt("independent-after:"+path,check)
  report["source_before"]=pins;report["source_after"]=after
  report["source_inputs_unchanged"]=len(after)==len(pins) and all(after[p]==pins[p] for p in after)
  if failure is not None:report["status"]="FAIL"
  attempt("final-summary",lambda:save(out/"summary.json",report))
  attempt("final-console",lambda:print("HIA_UNIXOPEN_POLICY_PRIVATE "+json.dumps({k:report[k] for k in(
   "status","original_controls","private_mutations","persistent_followups",
   "actual_direct_native_entries","fresh_VM_entries","all_complete_buffers_compared")},sort_keys=True),flush=True))
  def budget():
   own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN)
   save(out/"post-output-budget.json",dict(
    whole_tree_CPU=own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime,
    elapsed_ns=time.monotonic_ns()-started))
   own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN)
   assert 0<=own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime<90
   assert 0<=time.monotonic_ns()-started<180_000_000_000
  attempt("strict-post-output-budget",budget)
  if failure is not None:
   report.update(status="FAIL",final_error_class=type(failure).__name__,final_error=str(failure))
   attempt("write-final-FAIL",lambda:save(out/"summary.json",report))
  signal.setitimer(signal.ITIMER_REAL,0)
 if failure is not None:raise failure
if __name__=="__main__":main()
