"""NEW fixed twelve-role UnixOpen policy carrier composition.
Pure source construction and exact inverse checks; no project execution implied.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path
BASE_GIT="af439d426a8acb1a2bc114077185fc24ca42cc8a"
BASE_SHA="b7dfd47c4887ecb4ba423b75b1d1432f0a28f293cb0ed925aae729f1c54e5ef2"
EXTENSION_GIT="3db3b181f48aeae20db4d2bc3723d283787b8dd8"
EXTENSION_SHA="0097d68f0273bede19ab4fd3dbe76a7d55ea941c96caf5ab9d8b68b0969ef6bb"
OUTPUT_GIT="8cfcf9549a2784d92fcb2d3f96e12d53aba82318"
OUTPUT_SHA="402dd8b4c4735abf27fe8939040b0a0f0ee49b576ee4a17a66647863e9ae24b4"
OUTPUT_BYTES=116926
EDITS=json.loads(r'''[["    mov esi,12288\n    mov edx,3\n    mov r10d,34\n","    mov esi,24576\n    mov edx,3\n    mov r10d,34\n"],["    mov r15,rbx\n    /* This boot record exposes actual process/context identities only.","    mov r15,rbx\n    call .Lupb_initialize_extra\n    /* This boot record exposes actual process/context identities only."],["    cmp r13,[r15+UI_FIXED_FRAMER]\n    jne protocol_failure\n    mov eax,8\n    jmp .Luij_member_selected\n","    cmp r13,[r15+UI_FIXED_FRAMER]\n    je .Lupb_member_framer\n    cmp r13,[r15+UI_FIXED_RO]\n    je .Lupb_member_ro\n    cmp r13,[r15+UI_FIXED_CM]\n    jne protocol_failure\n    mov eax,11\n    jmp .Luij_member_selected\n.Lupb_member_ro:\n    mov eax,10\n    jmp .Luij_member_selected\n.Lupb_member_framer:\n    mov eax,8\n    jmp .Luij_member_selected\n"],["    cmp r10,9\n    ja protocol_failure\n    lea rax,[rip+.Limage_table]","    cmp r10,12\n    ja protocol_failure\n    lea rax,[rip+.Limage_table]"],["    /* No implementation or fabricated ACK for the other ten parent effects. */\n    cmp qword ptr [r12+72],6\n    jne protocol_failure\n    mov r13,[r15+UI_FIXED_PARENT]\n    jmp .Luij_publish_member_output\n","    /* The separate actual HIA bridge retains every unsupported peer pending. */\n    cmp qword ptr [r12+72],6\n    jne protocol_failure\n    jmp .Lupb_begin\n"],["    cmp rax,2\n    jne protocol_failure\n    cmp [r15+UI_PENDING_MEMBER],r13\n","    cmp rax,3\n    je .Lupb_child_capture\n    cmp rax,2\n    jne protocol_failure\n    cmp [r15+UI_PENDING_MEMBER],r13\n"],[".Luij_begin_traced:\n    call .Lnamespace_uij_begin\n    mov rax,UI_CAPSULE_TRACE\n",".Luij_begin_traced:\n    call .Lnamespace_uij_begin\n.Luij_emit_begin_trace:\n    mov rax,UI_CAPSULE_TRACE\n"],["    .zero 80\nexecutor_end:","    .zero 104\nexecutor_end:"]]''')
ANCHOR="\n.balign 16\nimage_table:\n.Limage_table:\n"
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(raw):return hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
def exact(raw,s,g):
 assert sha(raw)==s and git(raw)==g
 return raw.decode("utf-8")
def compose(base,extension):
 old=exact(base,BASE_SHA,BASE_GIT)
 extra=exact(extension,EXTENSION_SHA,EXTENSION_GIT)
 text=old
 for before,after in EDITS:
  assert text.count(before)==1
  text=text.replace(before,after,1)
 assert text.count(ANCHOR)==1
 inserted=extra+ANCHOR
 text=text.replace(ANCHOR,inserted,1)
 recovered=text
 assert recovered.count(inserted)==1
 recovered=recovered.replace(inserted,ANCHOR,1)
 for before,after in reversed(EDITS):
  assert recovered.count(after)==1
  recovered=recovered.replace(after,before,1)
 assert recovered==old
 labels=re.findall(r"^([A-Za-z_.$][\w.$]*):",text,re.M)
 assert len(labels)==len(set(labels))
 jumps=re.findall(r"^\s*(?:j[a-z]+|call)\s+([A-Za-z_.$][\w.$]*)\s*$",text,re.M)
 assert not (set(jumps)-set(labels))
 original_reserved=[(0,200),(256,496),(512,608),(640,672),(1200,1360),
                    (2304,2384),(2400,2488),(2496,2688)]
 addition=(2688,2752)
 assert all(addition[1]<=lo or hi<=addition[0] for lo,hi in original_reserved)
 assert addition[1]<=4096
 assert [4096*i for i in range(6)]==[0,4096,8192,12288,16384,20480]
 output=text.encode("utf-8")
 assert len(output)==OUTPUT_BYTES and sha(output)==OUTPUT_SHA and git(output)==OUTPUT_GIT
 return output,dict(status="SOURCE_COMPOSITION_ONLY",
  source_inverse_complete=True,unique_edits=len(EDITS),unique_labels=len(labels),
  fixed_roles=list(range(1,13)),image_table_slots=13,context_page_bytes=4096,
  new_root_mapping_bytes=24576,root_metadata_addition=list(addition),
  base=dict(git=git(base),sha256=sha(base),bytes=len(base)),
  extension=dict(git=git(extension),sha256=sha(extension),bytes=len(extension)),
  output=dict(git=git(output),sha256=sha(output),bytes=len(output)),
  AST=0,assembler=0,B3=0,VM=0,native=0,
  ordinary_Store_closed=False,remaining_nonraw_effects_pending=True)
def main():
 p=argparse.ArgumentParser()
 for key in ("base","extension","output","manifest"):p.add_argument("--"+key,type=Path,required=True)
 a=p.parse_args()
 before=[a.base.read_bytes(),a.extension.read_bytes()]
 output,report=compose(*before)
 assert not a.output.exists() and not a.manifest.exists()
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(output)
 assert a.output.read_bytes()==output
 raw=(json.dumps(report,sort_keys=True,indent=2)+"\n").encode()
 a.manifest.parent.mkdir(parents=True,exist_ok=True);a.manifest.write_bytes(raw)
 assert a.manifest.read_bytes()==raw
 assert [a.base.read_bytes(),a.extension.read_bytes()]==before
 print(json.dumps(report,sort_keys=True),flush=True)
if __name__=="__main__":main()
