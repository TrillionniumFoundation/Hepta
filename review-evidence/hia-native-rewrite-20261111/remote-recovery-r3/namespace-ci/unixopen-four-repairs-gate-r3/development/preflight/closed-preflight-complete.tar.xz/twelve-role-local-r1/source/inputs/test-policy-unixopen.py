"""First real fixed twelve-role UnixOpen policy/shared-FS composition.

Forty fresh fixed-process cases cover the unchanged parent and original
transport refusals plus real named open/fstat/read/close, creation mode,
URI psow, policy retirement/reuse and explicit remaining pending errors.
Each native window receives full fresh original CoreVM comparison. Private
protocol faults live in a separate bounded script and are not ordinary
Store/SQL authority or additional fixed-process cases.
"""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,os,resource,signal,stat,struct,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
GROUPS={"open-success":8,"uri-lifecycle":8,"pending-error":8,"parent-refusal":8,"transport":8}
CLIENT_SHA="e6a82d6236729b439786c8da1434174ff259562fe5484a5b235c47fbb08c80ce"
REPLAY_SHA="f405c4f3777cb162b59e30f04c353e5314a40742cbd4337d3dfa6795e9a01f3f"
FIXTURE_GIT="feb06cbec0b1acf43ddbd43863cbf74a4bd55d28"
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(raw):return hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
def q(raw,at):return struct.unpack_from("<Q",raw,at)[0]
def put(raw,at,value):struct.pack_into("<Q",raw,at,value)
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
def main():
 started=time.monotonic_ns()
 resource.setrlimit(resource.RLIMIT_CPU,(90,90))
 resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 def expired(*unused):raise TimeoutError("actual UnixOpen complete process group original180wall")
 signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,180)
 p=argparse.ArgumentParser()
 p.add_argument("--context",type=Path,required=True)
 p.add_argument("--group",choices=sorted(GROUPS),required=True)
 args=p.parse_args()
 assert sys.version_info[:3]==(3,12,14)
 context=json.loads(args.context.read_bytes());evidence=Path(context["namespace_evidence"])
 out=evidence/("policy-unixopen-"+args.group+"-r1");out.mkdir()
 pins={};before_raw={}
 def pin(path,expected=None):
  path=Path(path).absolute();st=path.lstat()
  assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
  raw=path.read_bytes();info=dict(bytes=len(raw),sha256=sha(raw),gitsha=git(raw),mode=stat.S_IMODE(st.st_mode))
  if expected is not None:assert info["sha256"]==expected
  key=str(path.resolve())
  if key in pins:assert info==pins[key]
  else:pins[key]=info;before_raw[key]=raw
  return raw
 def load(name,path,expected=None):
  raw=pin(path,expected)
  spec=importlib.util.spec_from_file_location(name,path)
  module=importlib.util.module_from_spec(spec);sys.modules[name]=module
  exec(compile(raw,str(path),"exec"),module.__dict__)
  return module
 report=dict(status="INCOMPLETE",group=args.group,planned_cases=GROUPS[args.group],
  completed_cases=0,actual_ELF_processes=0,process_launch_attempts=0,
  actual_process_count_complete=True,actual_entry_counts_complete=False,
  incomplete_count_scope="Completed replay cases only; partial native traces are authoritative and may contain additional actual entries.",
  actual_native_entries=0,full_VM_entries=0,
  actual_parent_raw_ACKs=0,actual_parent_policy_ACKs=0,actual_policy_retirements=0,
  actual_getpid_syscalls=0,case_results=[],
  ordinary_unixOpen_closed=False,ordinary_Store_closed=False,
  non_raw_peer_callbacks_used=False,host_completion_capsules_supplied=False,
  original42_rerun=False,prior_results_inherited=False,
  limits=dict(cpu_seconds=90,wall_seconds=180,address_bytes=1<<30,core_bytes=0),
  VM_limits=dict(steps=4000000,arena_bytes=32<<20,depth=64))
 failure=None
 try:
  pin(__file__);pin(args.context)
  here=Path(__file__).resolve().parent
  pin(here/"namespace-db-join-r1-client.py",
   "e5cad29b23957856c3a3ae08645eb7a14a62f6b0263fe67720a9560b88e58270")
  client=load("actual_unixopen_client",here/"actual-unixopen-client.py",CLIENT_SHA)
  replay=load("actual_unixopen_replay",here/"policy-unixopen-replay.py",REPLAY_SHA)
  fixture_path=here/"namespace-unixopen-fixtures.py"
  assert git(pin(fixture_path))==FIXTURE_GIT
  fixture=load("original_unixopen_input_fixture_only",fixture_path)
  ref=Path(context["reference"]);sys.path.insert(0,str(ref))
  from hepta.hia_agent_assembly import assemble_program
  build=json.loads(pin(evidence/"policy-unixopen-build-r1/summary.json"))
  assert build["status"]=="PASS_BUILD_ONLY" and build["fresh_role_compiles"]==12
  assert build["packer_entries"]==57 and build["source_pins_unchanged"]
  assert set(build["exact_roles"])=={str(r) for r in range(1,13)}
  assert build["executable"]["layout"]["relocation_count"]==0
  programs={}
  for role_text,row in sorted(build["exact_roles"].items(),key=lambda item:int(item[0])):
   role=int(role_text)
   source=pin(row["source"]["path"],row["source"]["sha256"])
   image=pin(row["image"]["path"],row["image"]["sha256"])
   assert (len(source),len(image))==(row["source"]["bytes"],row["image"]["bytes"])
   receipt=row["compile_receipt"]
   assert receipt["source_sha256"]==receipt["input_sha256"]==sha(source)
   assert receipt["produced_sha256"]==sha(image) and receipt["produced_bytes"]==len(image)
   assert receipt["limits"]["cpu_seconds"]==10 and receipt["limits"]["address_bytes"]==256<<20
   assert receipt["artifact_sha256"]==receipt["image_sha256"]=="35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b"
   assert receipt["status"]=="returned" and receipt["abi_status"]==0
   programs[role]=assemble_program(source)
  executable=Path(build["executable"]["path"]);actual=pin(executable,build["executable"]["sha256"])
  assert len(actual)==build["executable"]["bytes"] and executable.stat().st_mode&0o111
  for module in tuple(sys.modules.values()):
   filename=getattr(module,"__file__",None)
   if filename:
    path=Path(filename).resolve()
    if path.is_relative_to(ref) and path.suffix==".py":pin(path)
  for index,(name,raw) in enumerate(before_raw.items()):
   target=out/"source-before"/str(index)/Path(name).name;target.parent.mkdir(parents=True)
   target.write_bytes(raw);target.chmod(pins[name]["mode"]);assert target.read_bytes()==raw
  save(out/"source-before.json",pins)
  def begin(c,case=None):
   case={} if case is None else dict(case)
   row=replay.latest_shared_FS(c.output/"trace.bin");w=row["workspace"]
   wire=bytearray(fixture.begin(case,random_pid=c.boot["actual_process"],
    counter=7,fsseq=q(w,216),sysseq=q(w,224)))
   put(wire,152,q(w,80));put(wire,160,q(w,88));put(wire,184,0)
   return bytes(wire)
  def full_case(label,run,expected_exit=0):
   directory=out/"cases"/label;directory.parent.mkdir(exist_ok=True)
   item=dict(label=label,status="INCOMPLETE",expected_exit=expected_exit)
   report["case_results"].append(item);save(out/"summary.json",report)
   report["process_launch_attempts"]+=1
   c=None
   try:
    c=client.Carrier(executable,directory,out)
    report["actual_ELF_processes"]+=1
    with c:
     c.expected_exit=expected_exit
     observations=run(c)
   except BaseException as error:
    if c is None:report["actual_process_count_complete"]=False
    item.update(status="FAIL",constructor_returned=c is not None,
     error_class=type(error).__name__,error=str(error),traceback=traceback.format_exc(),
     original_process_evidence_directory=str(directory))
    try:save(out/"summary.json",report)
    except BaseException as secondary:error.add_note("case failure receipt: "+repr(secondary))
    raise
   actual_process=json.loads((directory/"actual-issuer-process.json").read_bytes())
   assert actual_process["returncode"]==expected_exit and actual_process["source_unchanged"]
   assert not actual_process["wall_watchdog_fired"] and not actual_process["wall_kill_sent"]
   assert 0<=actual_process["usage"]["user"]+actual_process["usage"]["system"]<90
   assert 0<=actual_process["elapsed_ns"]<180_000_000_000
   complete=replay.replay(directory,programs,expected_fatal=expected_exit)
   assert complete["native_entries"]==complete["VM_entries"]
   assert complete["all_native_return_output_workspace_bytes_equal"]
   item.update(status="PASS",observations=observations,actual_process=actual_process,replay=complete)
   report["completed_cases"]+=1
   report["actual_native_entries"]+=complete["native_entries"]
   report["full_VM_entries"]+=complete["VM_entries"]
   report["actual_parent_raw_ACKs"]+=complete["actual_native_parent_ACKs"]
   report["actual_parent_policy_ACKs"]+=complete["actual_native_policy_parent_ACKs"]
   report["actual_policy_retirements"]+=len(complete["actual_policy_retirements"])
   report["actual_getpid_syscalls"]+=complete["primitive_counts"].get("1:26",0)
   save(out/"summary.json",report)
   return item
  # Native fixture objects live in an isolated task directory outside the
  # regular-file evidence archive. Complete file bytes and symlink targets
  # are retained below with byte-encoded names; the sealer never follows a
  # test symlink or tries to interpret a non-UTF8 filename as archive text.
  fixture_root=Path(context["base"])/"namespace-policy-fixtures-r1"/args.group
  fixture_root.mkdir(parents=True,exist_ok=False)
  def snapshot_fixture(root,label):
   root=Path(root);assert root.parent==fixture_root
   saved=out/"fixture-originals"/label;saved.mkdir(parents=True,exist_ok=False)
   rows=[]
   def visit(path):
    st=path.lstat();name=os.path.relpath(os.fsencode(path),os.fsencode(root))
    row=dict(relative_path_bytes_hex=name.hex(),absolute_path_bytes_hex=os.fsencode(path).hex(),
     mode=stat.S_IMODE(st.st_mode),kind=stat.S_IFMT(st.st_mode),
     device=st.st_dev,inode=st.st_ino,links=st.st_nlink,size=st.st_size)
    if stat.S_ISREG(st.st_mode):
     raw=path.read_bytes();again=path.lstat()
     assert (again.st_dev,again.st_ino,again.st_mode,again.st_size)==(st.st_dev,st.st_ino,st.st_mode,st.st_size)
     target=saved/(str(len(rows))+".bin");target.write_bytes(raw)
     assert target.read_bytes()==raw
     row.update(raw_copy=str(target),bytes=len(raw),sha256=sha(raw))
    elif stat.S_ISLNK(st.st_mode):
     row["symlink_target_bytes_hex"]=os.readlink(os.fsencode(path)).hex()
    else:assert stat.S_ISDIR(st.st_mode)
    rows.append(row)
    if stat.S_ISDIR(st.st_mode):
     for child in sorted(path.iterdir(),key=lambda p:os.fsencode(p.name)):visit(child)
   visit(root);save(saved/"inventory.json",dict(
    original_fixture_root_bytes_hex=os.fsencode(root).hex(),phase=label,entries=rows,
    symlinks_not_followed=True,all_regular_file_bytes_retained=True))
  def fixture_case(label,run,directory):
   primary=None
   try:
    snapshot_fixture(directory,"before-"+label)
    return full_case(label,run)
   except BaseException as error:
    primary=error;raise
   finally:
    try:snapshot_fixture(directory,"after-"+label)
    except BaseException as error:
     if primary is None:raise
     primary.add_note("complete fixture after snapshot: "+repr(error))
  def latest_fs(c):
   row=replay.latest_shared_FS(c.output/"trace.bin")
   assert row["header"][6]==0
   return row["workspace"]
  def sync_external_call(c):
   # A new original-USER request is built from the actual completed owner
   # sequence. This does not complete any HIA pending effect or forge an ACK.
   w=latest_fs(c);c.call_number=q(w,32)
   return w
  def make_begin(c,case,*,call=1,counter=7):
   w=latest_fs(c)
   wire=bytearray(fixture.begin(case,call=call,random_pid=c.boot["actual_process"],
    counter=counter,fsseq=q(w,216),sysseq=q(w,224)))
   put(wire,152,q(w,80));put(wire,160,q(w,88));put(wire,184,0)
   return bytes(wire)
  def actual_stat_close(c,h,expected_bytes,*,deleted=False,known_path=None):
   assert h[1]==0 and h[8]==0 and h[6:8]==(0,0)
   token,fd=h[10],h[11];assert token>0 and 3<=fd<=2147483647
   procfd=Path("/proc")/str(c.boot["actual_process"])/"fd"/str(fd)
   observed=os.stat(procfd)
   sync_external_call(c)
   fs,raw=c.filesystem(15,a=token)
   assert len(raw)==144 and fs[7]==0
   assert (fs[8],fs[9],fs[10],fs[11],fs[12],fs[13],fs[24])==(
    observed.st_dev,observed.st_ino,observed.st_mode,observed.st_uid,
    observed.st_gid,observed.st_size,observed.st_nlink)
   assert fs[13]==len(expected_bytes)
   sync_external_call(c)
   data,payload=c.filesystem(2,a=token,b=len(expected_bytes),c=0)
   assert data[7]==0 and payload==expected_bytes and data[8]==len(expected_bytes)
   if known_path is not None:
    assert os.path.lexists(known_path)==(not deleted)
    if not deleted:
     st=os.stat(known_path,follow_symlinks=False)
     assert (st.st_dev,st.st_ino)==(observed.st_dev,observed.st_ino)
   sync_external_call(c)
   closed,_=c.filesystem(8,a=token)
   assert closed[7]==0 and closed[20]==0
   assert not procfd.exists()
   return dict(parent_header=list(h),logical_token=token,actual_raw_FD=fd,
    actual_stat=list(fs),actual_stat_payload_sha256=sha(raw),
    complete_expected_file_bytes_sha256=sha(expected_bytes),
    real_close_result=list(closed),own_child_proc_fd_absent_after_close=True,
    no_implicit_policy_retirement_FD_close=True)
  def complete_named(c,path,*,flags=512|2|4,extra=None,call=1,counter=7,
                     expected=b"",deleted=False,psow=True):
   extra={} if extra is None else dict(extra)
   source=extra.pop("source",os.fsencode(path)+b"\0\0")
   case=dict(path=source,flags=flags,**extra)
   h,payload=c.parent_begin(make_begin(c,case,call=call,counter=counter))
   assert payload==b"" and h[1]==h[8]==0,h
   assert h[12]==flags and h[24]==(flags if case.get("want_out",1) else 0)
   assert h[23]==case.get("want_out",1)
   ctrl=128|int(bool(flags&1))*2|int(bool(flags&8))*32|int(bool(flags&64))*64
   if (flags&4) and (flags&0x0fff00) in (2048,16384,524288):ctrl|=8
   if case.get("exclusive_vfs",0):ctrl|=1
   if psow:ctrl|=16
   assert h[26]==ctrl and h[28]==1 and h[29]==counter+1
   assert h[30]==c.boot["actual_process"] and h[31]==1001
   return actual_stat_close(c,h,expected,deleted=deleted,known_path=path)
  if args.group in ("open-success","uri-lifecycle"):
   if args.group=="open-success":
    names=["new_named_temp","existing_nonempty","read_only","exclusive_create",
     "no_output_pointer","delete_after_open","WAL_mode_owner","WAL_umask_fchmod"]
   else:
    names=["psow_default_false","URI_psow_off","URI_psow_on","URI_first_duplicate",
     "filename_allocation_offset","raw_non_UTF8_name","same_process_two_calls",
     "prior_shared_FS_then_open"]
   assert len(names)==GROUPS[args.group]
   for name in names:
    fixture_dir=fixture_root/name;fixture_dir.mkdir()
    path=fixture_dir/"file";data=b"namespace\x00actual\xffpayload"
    if name in ("existing_nonempty","read_only"):path.write_bytes(data)
    elif name=="raw_non_UTF8_name":
     path=os.fsencode(fixture_dir)+b"/raw-\xff-\x80";data=b""
    else:data=b""
    def run(c,name=name,path=path,data=data,fixture_dir=fixture_dir):
     if name=="new_named_temp":
      return complete_named(c,path,expected=b"")
     if name=="existing_nonempty":
      return complete_named(c,path,flags=512|2,expected=data)
     if name=="read_only":
      return complete_named(c,path,flags=512|1,expected=data)
     if name=="exclusive_create":
      return complete_named(c,path,flags=512|2|4|16,expected=b"")
     if name=="no_output_pointer":
      return complete_named(c,path,extra=dict(want_out=0),expected=b"")
     if name=="delete_after_open":
      return complete_named(c,path,flags=512|2|4|8,expected=b"",deleted=True)
     if name in ("WAL_mode_owner","WAL_umask_fchmod"):
      db=fixture_dir/"database";db.write_bytes(b"database owner")
      db.chmod(0o640);wal=fixture_dir/"database-wal"
      result=complete_named(c,wal,flags=524288|2|4,expected=b"")
      statrow=result["actual_stat"]
      assert statrow[10]&0o777==0o640
      assert (statrow[11],statrow[12])==(db.stat().st_uid,db.stat().st_gid)
      return result
     if name=="psow_default_false":
      return complete_named(c,path,extra=dict(psow_default=0),psow=False)
     if name in ("URI_psow_off","URI_psow_on","URI_first_duplicate"):
      tail={"URI_psow_off":b"psow\0off\0\0","URI_psow_on":b"psow\0on\0\0",
       "URI_first_duplicate":b"psow\0off\0psow\0on\0\0"}[name]
      # Original sqlite3_filename allocation has four leading NUL bytes;
      # the filename pointer addresses the first byte after that prefix.
      source=b"\0"*4+os.fsencode(path)+b"\0"+tail
      return complete_named(c,path,flags=512|2|4|64,
       extra=dict(source=source,path_offset=4),psow=name=="URI_psow_on")
     if name=="filename_allocation_offset":
      source=b"prefix\0"+os.fsencode(path)+b"\0\0"
      return complete_named(c,path,extra=dict(source=source,path_offset=7))
     if name=="raw_non_UTF8_name":
      return complete_named(c,path)
     if name=="same_process_two_calls":
      first=complete_named(c,path)
      second=complete_named(c,fixture_dir/"second",call=2,counter=8)
      assert second["logical_token"]>first["logical_token"]
      return dict(first=first,second=second,original_same_process=True)
     assert name=="prior_shared_FS_then_open"
     sync_external_call(c);fs,_=c.filesystem(26)
     assert fs[8]==c.boot["actual_process"]
     return complete_named(c,path,extra=dict(initial_errno=13))
    # Set before Carrier forks, then always restore this test process.
    # Setting umask inside run(c) would not reach the existing child.
    old_mask=os.umask(0o077) if name=="WAL_umask_fchmod" else None
    try:item=fixture_case(name,run,fixture_dir)
    finally:
     if old_mask is not None:os.umask(old_mask)
    assert item["replay"]["actual_native_policy_parent_ACKs"]>=3
    assert len(item["replay"]["actual_policy_retirements"])>=3
    for role in (1,6,7,8,9,10,11,12):assert item["replay"]["entries_by_role"][str(role)]>0
    assert item["replay"]["primitive_counts"].get("1:15",0)>=1
    assert item["replay"]["primitive_counts"].get("1:8",0)>=1
    if name=="WAL_umask_fchmod":assert item["replay"]["primitive_counts"].get("1:21",0)>=1
    if name=="same_process_two_calls":
     assert item["replay"]["actual_native_policy_parent_ACKs"]==6
     assert [11,4] in item["replay"]["retired_policy_generations"]
   assert len(names)==8
  elif args.group=="pending-error":
   names=["missing_readonly","directory_readwrite","non_directory_ancestor",
    "final_symlink_readonly","empty_Cstring_readonly","missing_rw_fallback",
    "WAL_missing_database_STAT","main_database_global_reuse"]
   assert len(names)==GROUPS[args.group]
   for name in names:
    fixture_dir=fixture_root/name;fixture_dir.mkdir()
    path=fixture_dir/"file";flags=512|1
    expected_op,expected_stage,expected_errno=17,36,2
    if name=="directory_readwrite":
     path.mkdir();flags=512|2;expected_errno=21
    elif name=="non_directory_ancestor":
     path.write_bytes(b"x");path=path/"child";expected_errno=20
    elif name=="final_symlink_readonly":
     target=fixture_dir/"target";target.write_bytes(b"x")
     path.symlink_to(target);expected_errno=40
    elif name=="missing_rw_fallback":
     flags=512|2;expected_op,expected_stage=3,33
    elif name=="WAL_missing_database_STAT":
     path=fixture_dir/"database-wal";flags=524288|2|4
     expected_op=expected_stage=0
    elif name=="main_database_global_reuse":
     flags=256|2|4;expected_op,expected_stage,expected_errno=3,20,28
    source=b"\0\0" if name=="empty_Cstring_readonly" else os.fsencode(path)+b"\0\0"
    def run(c,name=name,path=path,flags=flags,source=source,
            expected_op=expected_op,expected_stage=expected_stage,expected_errno=expected_errno):
     h,payload=c.parent_begin(make_begin(c,dict(path=source,flags=flags)))
     if name=="WAL_missing_database_STAT":
      assert h[1]==0 and h[8]==1802 and h[9]==2
      assert h[10]==0 and h[11]==(1<<64)-1 and payload==b""
     else:
      assert h[1]==1 and (h[6],h[7],h[9])==(expected_op,expected_stage,expected_errno),h
      assert len(payload)>=256 and q(payload,48)==expected_op and q(payload,56)==expected_stage
     return dict(actual_parent_header=list(h),actual_original_pending_payload_sha256=sha(payload),
      expected_nonraw_pending=name!="WAL_missing_database_STAT",
      missing_peer_not_host_completed=True,actual_error_not_fabricated=True)
    item=fixture_case(name,run,fixture_dir)
    counts=item["replay"]["primitive_counts"]
    if name=="main_database_global_reuse":
     assert item["replay"]["actual_native_policy_parent_ACKs"]==0
     assert counts.get("1:28",0)==0
    elif name=="WAL_missing_database_STAT":
     assert item["replay"]["actual_native_policy_parent_ACKs"]==1
     assert counts.get("1:29",0)==1 and counts.get("1:28",0)==0
    else:
     assert item["replay"]["actual_native_policy_parent_ACKs"]==2
     assert counts.get("1:28",0)==1

  elif args.group=="parent-refusal":
   rows=[("zero_call",32,0),("zero_source_lease",40,0),("bad_access",48,256),
    ("no_original_vfs",80,0),("invalid_boolean",72,2),("bad_reserved",208,1),
    ("path_offset_at_end",192,None),("missing_NUL",None,None)]
   assert len(rows)==GROUPS[args.group]
   for label,offset,value in rows:
    def run(c,offset=offset,value=value,label=label):
     wire=bytearray(begin(c))
     if label=="missing_NUL":wire[512:]=b"x"*len(wire[512:])
     else:put(wire,offset,len(wire)-512 if value is None else value)
     h,_=c.parent_begin(wire,label=label)
     assert h[1]==client.BAD,h
     valid=bytearray(begin(c));put(valid,32,2)
     again,_=c.parent_begin(valid,label="same-live-parent-remains-poisoned")
     assert again[1]==client.BAD
     return dict(first_refusal=list(h),persistent_refusal=list(again),
      native_parent_calls=2,host_reset=False)
    result=full_case(label,run)
    assert result["replay"]["actual_native_parent_ACKs"]==0
    assert result["replay"]["entries_by_role"]["9"]==0
    assert result["replay"]["primitive_counts"].get("1:26",0)==0
  else:
   rows=["bad_magic","bad_kind","declared_extent","nonzero_transport_reserved",
    "external_parent_ACK","external_process_identity","external_capsule","pending_parent_no_reentry"]
   assert len(rows)==GROUPS[args.group]
   for label in rows:
    def run(c,label=label):
     wire=bytearray(begin(c))
     packet=bytearray(client.envelope(2,wire))
     if label=="bad_magic":put(packet,0,0)
     elif label=="bad_kind":put(packet,8,9)
     elif label=="declared_extent":put(packet,16,len(wire)+1)
     elif label=="nonzero_transport_reserved":put(packet,24,1)
     elif label=="external_parent_ACK":put(packet,72,2)
     elif label=="external_process_identity":put(packet,64+184,c.boot["actual_process"])
     elif label=="external_capsule":
      packet=bytearray(client.envelope(2,bytes(512)));put(packet,64,int.from_bytes(b"HIAUIC01","little"))
     elif label=="pending_parent_no_reentry":
      h,_=c.parent_begin(wire);assert h[1]==1 and h[6]==3
     else:raise AssertionError(label)
     result=c.invalid_transport(packet,label=label,expected_exit=110)
     assert result["returncode"]==110
     return dict(actual_transport_exit=110,original_invalid_frame_sha256=sha(packet),
      no_external_completion_route=True)
    result=full_case(label,run,expected_exit=110)
    if label!="pending_parent_no_reentry":
     assert result["replay"]["entries_by_role"]["7"]==0
     assert result["replay"]["entries_by_role"]["8"]==0
     assert result["replay"]["entries_by_role"]["9"]==0
  assert report["completed_cases"]==report["planned_cases"]==len(report["case_results"])
  assert report["actual_ELF_processes"]==report["process_launch_attempts"]==report["planned_cases"]
  assert report["actual_process_count_complete"]
  assert report["actual_native_entries"]==report["full_VM_entries"]>0
  report["actual_entry_counts_complete"]=True
  report["status"]="PASS"
 except BaseException as error:
  failure=error;report.update(status="FAIL",error_class=type(error).__name__,error=str(error),
   traceback=traceback.format_exc())
  try:traceback.print_exc()
  except BaseException as secondary:error.add_note("traceback output: "+repr(secondary))
 finally:
  after={};errors=[]
  for path,expected in pins.items():
   try:
    p=Path(path);st=p.lstat();assert stat.S_ISREG(st.st_mode) and not p.is_symlink()
    raw=p.read_bytes();observed=dict(bytes=len(raw),sha256=sha(raw),gitsha=git(raw),mode=stat.S_IMODE(st.st_mode))
    after[path]=observed;assert observed==expected
   except BaseException as error:
    after[path]=dict(error=repr(error));errors.append(dict(path=path,error=repr(error)))
    if failure is None:failure=error
    else:failure.add_note("source after: "+repr(error))
  report["source_before"]=pins;report["source_after"]=after
  report["source_inputs_unchanged"]=not errors
  if failure is not None:report["status"]="FAIL"
  try:
   save(out/"summary.json",report)
   print("HIA_UNIXOPEN_POLICY_GROUP "+json.dumps({k:report[k] for k in
    ("status","group","planned_cases","completed_cases","actual_ELF_processes",
     "actual_native_entries","full_VM_entries","actual_parent_raw_ACKs","actual_parent_policy_ACKs",
     "actual_policy_retirements","actual_getpid_syscalls")},sort_keys=True),flush=True)
  except BaseException as error:
   if failure is None:failure=error
   else:failure.add_note("final output: "+repr(error))
  try:
   own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN)
   budget=dict(whole_tree_CPU=own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime,
    elapsed_ns=time.monotonic_ns()-started)
   save(out/"post-output-budget.json",budget)
   own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN)
   assert 0<=own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime<90
   assert 0<=time.monotonic_ns()-started<180_000_000_000
  except BaseException as error:
   if failure is None:failure=error
   else:failure.add_note("strict final budget: "+repr(error))
  if failure is not None:
   report.update(status="FAIL",final_error_class=type(failure).__name__,final_error=str(failure))
   try:save(out/"summary.json",report)
   except BaseException as error:failure.add_note("FAIL receipt: "+repr(error))
  signal.setitimer(signal.ITIMER_REAL,0)
 if failure is not None:raise failure
if __name__=="__main__":main()
