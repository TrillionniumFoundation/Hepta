# UnixOpen policy-peer → shared-FS bridge, source revision 1

Status: NEW AUTHORING. Zero AST, HIA generation, assembler, CoreVM, B3, packer or native execution. This specification does not inherit any old component or original42 result. The complete frozen nine-role candidate remains unchanged.

## Purpose and retained source

The next fixed composition adds role 10 (the unchanged robust_open owner), role 11 (the unchanged create-mode / SQLite filename / URI owner), and role 12 (this new bridge). Role 12 consumes actual native-completion capsules for the same role-7 UnixOpen parent and the same live role-6 shared FS owner. It selects and invokes the policy child, forwards that child's complete FS requests, consumes the actual FS results and produces the actual parent continuation. The carrier copies bytes, manages descriptors and calls fixed images; HIA owns the operation, continuation and field interpretation.

Frozen source identities:

| Role or input | Git blob | Scope |
| --- | --- | --- |
| UnixOpen parent 7 | 27868b292476e4049dd1b4194c3524041ea89953 | Complete selected parent policy; no change |
| Raw framer 8 | 01f7821998991a296f81d398670a4a0be8423d42 | Existing eight raw effects; no change |
| Raw issuer 9 | abbb7f40338e7b099e855281d7dab9ff64834eed | Actual parent/raw-framer/shared-FS continuation; no change |
| robust_open 10 | 135f27cb100ebbf92608fb2c7d0e67285f4db51c | Original retries, low-FD sequence, mode FSTAT/FCHMOD; no change |
| create/URI 11 | 5be027860d59b408a9768610da93693e09b37464 | Original findCreateFileMode and sqlite3_uri_boolean; no change |
| shared FS outer 6 | de8629320367e7e630d671fea433894e4cd0ee28 | Exact registered-FSTAT / USER outer |
| raw FS 1 | f4f8cb15d40089b98040032367ba53b03bca8b2a | FS9, complete logical FD registry and raw primitive policies |
| predecessor C | 9e7ba05d6882b1f3c310b99102e8ecbf7f830af2 | SQLite 3.46.1 os_unix reference; source evidence only |

The shared lower chain is FS9/DMS10. It is not original42's DMS9 identity. The first nine-role proposal still covers getpid and pending/refusal controls only; this new source is the next integration, not retroactive extra coverage.

## Parent effects handled by role 12

| Parent operation | Parent stage | Existing child call | Return projected to parent |
| --- | --- | --- | --- |
| 6 | 30 | role 11 op 1, findCreateFileMode | rc, mode, uid, gid, actual errno and actual FS watermarks |
| 7 | 31 or 35 | role 10, robust_open | actual logical FD token, raw FD or UINT64_MAX, actual errno and FS watermarks |
| 12 | 60 | role 11 op 3, sqlite3_uri_boolean with literal key psow | actual boolean and retained errno, unchanged FS watermarks |

All other nonraw parent operations remain pending. No host fallback supplies their result. For a named non-main file whose first cached PID already matches the actual process and whose open succeeds without a warning callback, these three effects plus the existing raw issuer permit the real parent to complete. The resulting logical FD remains owned by the shared FS registry and can be used for actual FSTAT and CLOSE in the same session. This is not ordinary Store, SQL31, full main-database inode admission, migration or all UnixOpen effects.

A failed robust_open still returns its original result and errno through the real parent. Any subsequent original fallback, logger, allocator or global-reuse request not yet connected remains pending at that actual next effect. No synthetic success or automatic rollback/cleanup is added.

## Private provenance and fixed contexts

The native carrier creates HIAUIC01 capsules only immediately after a real fixed-image invocation. Each capsule contains role, context identity, generation, strictly increasing actual entry serial, returned u32, exact source/output/workspace extents, immutable source lease, version, read-only-second flag, actual PID, caller action and caller call. The full source/output/workspace bytes follow the 128-byte capsule header.

The bridge accepts role 7 and role 6 capsules on BEGIN. Subsequent COMPLETED accepts only the outstanding actual role 10, 11 or 6. It compares the complete issued input byte-for-byte, plus context/generation, actual entry serial, source lease presence, actual PID, bridge call and action. This is a fixed private issuance protocol, not external byte-header authentication. Integer IDs or copied headers do not independently grant Store authority.

The role-10 and role-11 policies are one-shot. A selected child is freshly zeroed only through native context creation, not by a host semantic callback. After its terminal result, HIA emits RETIRE. The native carrier consumes the active child generation, releases that child's source/output/work mappings and issues an actual retirement receipt. Only that receipt allows the bridge to publish the parent ACK. Live raw FD tokens, retained /dev/null refill descriptors and the shared FS owner are not closed by retirement of a policy workspace. A new call requires a fresh selected generation. Exhausted generation/call/action counters reject; they do not wrap or silently restart.

## Bridge input: HIAUPB01

All words are little-endian u64. Header size is 256 bytes. RWW entry; output is a 256-byte event; initial workspace floor is 2048 bytes and grows according to exact required extents. There is no new path, file, row, replay or callback count quota.

Shared header fields:

| Offset | Field |
| --- | --- |
| 0 | HIAUPB01 |
| 8 | 1 BEGIN, 2 COMPLETED, 3 RETIRED |
| 16, 24 | Nonzero bridge session pair |
| 32 | Bridge call, initially 1 and thereafter previous + 1 |
| 40 | BEGIN zero; other commands exact outstanding bridge action |
| 48 | Actual bridge context lease |
| 56 | Actual process PID |

BEGIN adds role-10 context/generation at 64/72, role-11 context/generation at 80/88, parent capsule byte count at 96, ready shared-FS capsule byte count at 104 and original parent source lease at 112. Bytes 120..255 are zero. Tail is exactly the parent capsule followed by the ready FS capsule. Both policy contexts are allocated fixed contexts; the selected one must be fresh. The two contexts, bridge, parent and FS must not alias.

COMPLETED has the exact capsule byte count at 64 and zero bytes 72..255. Its sole tail is the complete native capsule of the outstanding role. Actual source bytes must equal the issued work range. A child GROW resubmits that same immutable child input after mechanical buffer growth. It does not re-enter a previously completed FS primitive.

RETIRED has exactly 64 payload bytes. The tail HIAURT01 contains role, retired context, retired generation, status zero, bridge call, bridge action and version 1. The carrier can issue it only after the actual matching retirement. Repeated, wrong-context, stale-generation or out-of-order retirement rejects.

## Output HIAUPX01 and persistent state

Every output is a 256-byte mechanical event bound to bridge session/call/action and phase.

Status 1 requests one fixed role invocation with a source range in the bridge workspace and minimum output/workspace capacities. HIA chooses role 10, 11 or 6. The carrier cannot change the requested source or infer policy from parent operation numbers.

Status 2 requests growth of the bridge workspace. The same immutable outer input must be replayed. Every reserve is checked for u64 overflow and logical bounds before copying or committing an invocation, parent ACK or retirement.

Status 3 is the original robust_open warning callback pending, with its full original immutable warning bytes and child state. No warning ACK is fabricated. Status 5 is an unsupported parent peer pending, with the full original parent request and no child entry. These are unfinished effects, not failure or success aliases.

Status 4 requests retirement of the completed policy child. Its terminal result has already been checked and the original parent ACK bytes prepared, but those ACK bytes are not exposed as a completed parent continuation yet.

Status 0 exposes exactly 512 parent ACK bytes after retirement. The native carrier must copy these bytes into the same original parent call and invoke role 7. It must not accept an externally supplied replacement ACK.

Protocol errors permanently poison the bridge. Short workspace can record poison only if it has at least the first eight bytes; this physical limitation is explicit. A valid call after poison is rejected. Output capacity errors do not reset a child or consume its live FD.

## Exact parent binding

The input parent capsule must show a real status-1 HIANUO01 result and phase-2 workspace. The full output header and HIANUQ01 request are compared with the saved actual parent workspace fields, including original source lease, actual PID, parent call, action, operation, stage and all eight-word result inputs. The saved 256-byte request is retained byte-for-byte for the final ACK.

For operation 6 the full original filename allocation and original logical pointer are passed to create op 1; no C-string reconstruction discards SQLite's preceding separators or URI tail. For operation 7 the selected raw path without its final NUL is passed unchanged to robust_open; an empty path is legal and preserved. For operation 12 the filename allocation/presence and pointer are preserved and the exact four-byte key psow is appended for create op 3. No host URI parse occurs.

A pure URI completion does not alter shared FS counters. Create-mode may emit zero or one original STAT_CSTR. Robust-open may emit the original unbounded EINTR/refill sequence subject to existing resource budgets; no new retry cap is introduced.

## Shared FS continuation

The child produces the entire original HIANFR03 request, including nonce, call, operation, child action lease and path. The bridge wraps it in the existing HIANDJX1/HIANDJ01 USER command 11 without relabeling that inner request. Outer call increments exactly once per issued FS request. The shared FS nonce and actual FS call/syscall watermarks must equal the previously observed ready owner and advance exactly once in the returned actual result.

The bridge does not parse raw stat bytes to decide mode. It validates outer terminal/ready state, exact issued source, logical FS extent and source identity, then copies the complete 256-byte or 400-byte original FS response into the unchanged child's ACK. The existing child still performs its full stat-field/counter/errno validation and policy decisions.

A child requests output/workspace GROW before its next action is committed. The bridge records the actual entry serial and exact original input, grows only the requested native buffers, and invokes the same child input. A bridge GROW reprocesses the same already-completed immutable capsule and never reissues the previous native child invocation.

## Parent ACK and error order

The final parent ACK copies the original session/call/action/operation/stage and exact saved 256-byte request. It carries actual final errno, actual FS call/syscall counters, the semantic peer ID 7 for robust or 8 for create/URI, and the real policy context, generation and completed entry serial. Physical role numbers 10/11 do not overwrite those original semantic peer IDs.

Create-mode errors preserve rc 1802 and its original zeros and errno. robust_open failure preserves token zero and raw FD UINT64_MAX; successful descriptors preserve actual logical token and raw FD. URI returns the actual boolean only. The parent's original continuation owns any later read-only fallback, logger, inode admission, cleanup or returned error.

No additional COMMIT, ROLLBACK, retry, CLOSE or namespace publication is introduced by this bridge.

## Validation required before any new qualification claim

The final fixed composition must execute fresh B3 builds, a strict zero-relocation assembly gate, actual HIA ELF packing, all new real process cases and complete native/CoreVM byte comparison for every entry. Tests must include repeated parent calls, fresh child generations, actual file open/FSTAT/CLOSE, absence/permission errors, read-only fallback pending state, create-mode STAT and errno branches, empty paths, URI ordering, child and bridge GROW, stale/cross-role/replayed capsules and retirement refusal.

Existing nine-role and original42 evidence remain separate. Proposed validation keeps B3 10 CPU / 20 wall / 256 MiB, fixed native process and complete runtime group 90 CPU / 180 wall / 1 GiB, CoreVM 4,000,000 steps / 32 MiB / depth 64, and the whole subject 900-second aggregate including source-after checks. The streamed seal is separately bounded and cannot replace any original test.
