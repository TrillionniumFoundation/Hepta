"""Read-only source generation diagnostic; profile refusals remain failures."""
from __future__ import annotations
import ast,hashlib,importlib.util,json,sys,traceback
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(name,path):
 raw=path.read_bytes();spec=importlib.util.spec_from_file_location(name,path)
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module
 exec(compile(raw,str(path),"exec"),module.__dict__);return module
def main():
 context=json.loads((ROOT/"context.json").read_bytes())
 ref=Path(context["reference"]);work=Path(context["namespace_working"]);out=ROOT/"generation-all-diagnostic-r1";out.mkdir()
 manifest=json.loads((work/"inputs.json").read_bytes())
 before={}
 for r in manifest["inputs"]:
  path=work/"inputs"/r["path"];raw=path.read_bytes()
  assert len(raw)==r["bytes"] and sha(raw)==r["sha256"]
  before[str(path)]=r["sha256"]
  if r["working_alias"]:
   p=work/r["working_alias"];assert p.read_bytes()==raw;before[str(p)]=r["sha256"]
 sys.path.insert(0,str(ref))
 builder=load("diagnostic_exact_builder",work/"inputs/build_policy_unixopen.py")
 for name,expected in builder.BUILDER_SOURCES.items():
  p=work/"tools"/(name+".py");assert sha(p.read_bytes())==expected
  load("tools."+name,p)
 from hepta.hia_agent_assembly import assemble_program,render_assembly
 rows=[]
 for role,(filename,expected) in builder.ROLE_SOURCES.items():
  result=dict(role=role,author_sha256=expected,status="INCOMPLETE")
  try:
   p=work/"tools"/filename;assert sha(p.read_bytes())==expected
   a=load("diagnostic_role_"+str(role),p);document=a.document()
   raw=(json.dumps(document,sort_keys=True,separators=(",",":"))+"\n").encode()
   (out/("role-"+str(role)+".document.json")).write_bytes(raw)
   names={n.name:"f"+str(i) for i,n in enumerate(ast.parse(a.source_program()).body)} if hasattr(a,"source_program") else {}
   functions=[]
   for f in document["functions"]:
    values=[x["name"] for b in f["blocks"] for x in b["params"]]+[x["name"] for b in f["blocks"] for op in b["ops"] for x in op["out"]]
    functions.append(dict(name=f["name"],author_name=next((n for n,v in names.items() if v==f["name"]),None),
     blocks=len(f["blocks"]),ops=sum(len(b["ops"]) for b in f["blocks"]),definitions=len(values),
     unique_definitions=len(set(values)),max_suffix=max((int(v[1:]) for v in values),default=0)))
   profile=dict(functions=len(functions),blocks=sum(f["blocks"] for f in functions),ops=sum(f["ops"] for f in functions),
    max_blocks=max(f["blocks"] for f in functions),max_ssa_numeric_suffix=max(f["max_suffix"] for f in functions),
    max_block_params=max(len(b["params"]) for f in document["functions"] for b in f["blocks"]))
   result.update(document_bytes=len(raw),document_sha256=sha(raw),profile=profile,functions=functions,
    original_profile_pass=profile["functions"]<=128 and profile["blocks"]<=1536 and profile["ops"]<=8192 and profile["max_blocks"]<=256 and profile["max_block_params"]<=16 and profile["max_ssa_numeric_suffix"]<2048)
   source=render_assembly(document).encode();(out/("role-"+str(role)+".hiaasm")).write_bytes(source)
   assemble_program(source);result["Core_assembly"]="ACCEPTED"
   result["status"]="GENERATED_PROFILE_PASS" if result["original_profile_pass"] else "PROFILE_REFUSAL"
  except BaseException as error:
   result.update(status="FAIL",error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
  rows.append(result);(out/"summary.json").write_text(json.dumps(dict(scope="SOURCE_GENERATION_DIAGNOSTIC_ONLY_NOT_GATE",roles=rows,B3=0,VM=0,native=0),sort_keys=True,indent=2)+"\n")
  print(json.dumps({k:result[k] for k in ("role","status","profile","error") if k in result},sort_keys=True),flush=True)
 after={path:sha(Path(path).read_bytes()) for path in before}
 report=dict(scope="SOURCE_GENERATION_DIAGNOSTIC_ONLY_NOT_GATE",roles=rows,B3=0,VM=0,native=0,
  source_before=before,source_after=after,all_sources_unchanged=after==before,
  status="PROFILE_DIAGNOSTIC_COMPLETE" if len(rows)==12 and after==before else "FAIL")
 (out/"summary.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 assert len(rows)==12 and after==before
if __name__=="__main__":main()
