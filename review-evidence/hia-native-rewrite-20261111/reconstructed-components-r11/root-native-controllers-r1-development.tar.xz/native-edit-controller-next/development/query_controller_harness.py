"""Actual HIA query controller with explicit private predecessor/service fixtures.

The native query image chooses every semantic stage and executor operation.
Program predecessor initialization and service-58 mechanical forwarding remain
development fixtures here. This is not a complete native executable or a test
of the not-yet-installed role-58 implementation.
"""
import ctypes,json,struct,subprocess
from hashlib import sha256
from pathlib import Path
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from core_packet_transport import CorePacketTransport
from bounded_input_harness import Actual,Peers,run as bound_run
from hia_edit_controller_common import CONSTANTS as C

BASE=Path(__file__).resolve().parents[2];DEV=BASE/'native-agent-edit-development';ROOT=BASE/'native-edit-controller-next'
M=lambda s:int.from_bytes(s,'little');CANARY=b'\xbc'*32

class Evidence:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False)
        self.pages=self.out/'pages';self.pages.mkdir();self.maps=self.out/'buffers';self.maps.mkdir()
        self.log=(self.out/'entries.jsonl').open('w');self.saved=set();self.count=0
    def raw(self,data):
        digest=sha256(data).hexdigest()
        if digest not in self.saved:
            chunks=[]
            for at in range(0,len(data),4096):
                block=data[at:at+4096];key=sha256(block).hexdigest();path=self.pages/key
                if not path.exists():path.write_bytes(block)
                else:assert path.read_bytes()==block
                chunks.append(key)
            (self.maps/digest).write_text(json.dumps(dict(bytes=len(data),sha256=digest,chunks=chunks),separators=(',',':'))+'\n')
            self.saved.add(digest)
        return dict(bytes=len(data),sha256=digest)
    def record(self,**row):
        self.count+=1;row['entry']=self.count;self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
    def close(self):self.log.close()

class Buffer:
    def __init__(self,raw,readonly=False):
        self.size=len(raw);self.value=ctypes.create_string_buffer(raw+CANARY);self.readonly=readonly
    @property
    def address(self):return ctypes.addressof(self.value)
    def raw(self):return ctypes.string_at(self.value,self.size)
    def check(self):assert ctypes.string_at(self.address+self.size,32)==CANARY
    def write(self,offset,raw):
        assert not self.readonly and 0<=offset<=self.size and len(raw)<=self.size-offset
        if raw:ctypes.memmove(self.address+offset,raw,len(raw))

class QueryController:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False);self.pins={};self.images={};self.roles={};self.calls=0
        self.evidence=Evidence(self.out/'actual')
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes();self.pins[path]=raw;return raw
        def image(role,row):
            source=read(row['source_path']);raw=read(row['image_path']);assert sha256(source).hexdigest()==row['source_sha256'] and sha256(raw).hexdigest()==row['image_sha256']
            self.images[role]=NativeHiaJsonImage(raw,row['image_sha256']);self.roles[role]=0
        ordinary=json.loads(read(BASE/'native-composite-driver-reconstructed/development/publication-bundle-r2/bundle.json'))
        for role in (2,22):image(role,ordinary['components'][str(role)])
        names={
            35:'input-graph-source-and-compile-r1/agent-edit-input-graph.manifest.json',
            36:'selection-source-and-compile-r3/agent-edit-selection.manifest.json',
            37:'facts-source-and-compile-r1/agent-edit-facts.manifest.json',
            39:'query-source-and-compile-r2/agent-edit-query-packet.manifest.json',
            47:'packet-graph-source-and-compile-r2/packet-graph.manifest.json',
            48:'graph-merge-source-and-compile-r1/graph-merge.manifest.json',
            49:'batch-graph-source-and-compile-r1/agent-edit-batch-graph.manifest.json',
            51:'match-wire-source-and-compile-r1/agent-edit-match-wire.manifest.json',
        }
        for role,name in names.items():image(role,json.loads(read(DEV/name)))
        for role,folder,name in [(38,'facts-native-r3','agent-slice'),(54,'query-native-r2','json_canonical')]:
            receipt=json.loads(read(DEV/folder/(name+'.receipt.json')));raw=read(DEV/folder/(name+'.image.bin'));src=read(DEV/folder/(name+'.input.bin'))
            assert sha256(raw).hexdigest()==receipt['produced_sha256'] and sha256(src).hexdigest()==receipt['input_sha256']
            self.images[role]=NativeHiaJsonImage(raw,sha256(raw).hexdigest());self.roles[role]=0
        image(57,json.loads(read(ROOT/'development/query-compile-r1/agent-edit-query-driver.manifest.json')))
        self.codec=CorePacketTransport(self.out/'codec');self.bound=Actual(DEV/'bounded-input-source-and-compile-r3/agent-edit-bounded-input.manifest.json',self.out/'bounded')
        self.peers=Peers(self.out/'peers');self.read=read
        self.program=BASE/'native-program-admission-next/development/build-r2/hia-admit-program'
        assert sha256(read(self.program)).hexdigest()=='8f3331a1763adbf7630f72e1216493c956ca979010dd6c50c8c29fdb56f1c57d'
        read(Path(__file__))
    def set(self,name,value):struct.pack_into('<Q',self.slots[2].value,C[name],value)
    def get(self,name):return struct.unpack_from('<Q',self.slots[2].value,C[name])[0]
    def view(self,slot,at,size):
        assert slot in self.slots and at<=self.slots[slot].size and size<=self.slots[slot].size-at,(slot,at,size)
        return ctypes.string_at(self.slots[slot].address+at,size)
    def ack(self,operation,result=0,observed=b''):
        return struct.pack('<8Q',M(b'HIACDA01'),self.get('C_LEASE'),self.get('C_SEQUENCE'),operation,0,result,len(observed),0)+observed
    def begin_fixture(self,label,program,query,response,mode,digits):
        completed=subprocess.run([str(self.program)],input=program,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'PATH':'','HOME':''},timeout=20)
        self.evidence.record(case=label,role='actual-program-predecessor-process',stdin=self.evidence.raw(program),stdout=self.evidence.raw(completed.stdout),stderr=self.evidence.raw(completed.stderr),returncode=completed.returncode)
        assert completed.returncode==0 and len(completed.stderr)==256
        core=completed.stdout;receipt=completed.stderr;fields=struct.unpack('<32Q',receipt)
        assert fields[0]==M(b'HIAPRV01') and fields[8]==len(core) and sha256(core).digest()==receipt[112:144]
        packet,source=self.codec.decode(label,core,digits)
        self.slots={0:Buffer(b'\0',True),1:Buffer(program,True),2:Buffer(bytes(1<<20)),4:Buffer(query,True),5:Buffer(response,True),6:Buffer(receipt+core,True),7:Buffer(core,True),8:Buffer(source,True)}
        for slot,buf in self.slots.items():struct.pack_into('<Q',self.slots[2].value,C['CAPS']+8*slot,buf.size)
        for key,value in dict(C_MAGIC=C['EDIT_STATE'],C_STATUS=1,C_LEASE=111,C_SEQUENCE=1,C_PENDING=8,C_NEXT=1000,C_OBSERVE=0,
            L_MAGIC=C['LOWER_MAGIC'],L_STATUS=1,L_DRIVER=56,L_NEXT_DRIVER=57,E_MODE=mode,E_DIGITS=digits,E_REQUEST=1,E_CORE_BYTES=len(core)).items():self.set(key,value)
        self.slots[2].write(C['E_INPUT_HASH'],receipt[80:112]);self.slots[2].write(C['E_CORE_HASH'],receipt[112:144])
        self.evidence.record(case=label,role='explicit-private-predecessor-fixture',workspace=self.evidence.raw(self.slots[2].raw()),
            actual_program_succeeded=True,actual_native_codec_and_bitmap_issuer=True,not_actual_main_controller_handoff=True)
        return self.ack(8)
    def control(self,label,command):
        a=Buffer(command,True);o=Buffer(bytes(128));w=self.slots[2];before=w.raw()
        code=int(self.images[57]._entry(a.address,a.size,o.address,o.size,w.address,w.size));self.roles[57]+=1;self.calls+=1
        a.check();o.check();w.check();assert a.raw()==command
        after=w.raw();event=o.raw()
        self.evidence.record(case=label,role=57,return_code=code,command=self.evidence.raw(command),before=self.evidence.raw(before),after=self.evidence.raw(after),event=self.evidence.raw(event),canaries_and_input_equal=True)
        assert code==128,(label,code,self.get('C_PHASE'),self.get('C_REASON'))
        return struct.unpack('<16Q',event)
    def service_fixture(self,label):
        w=self.slots[2];before=w.raw();kind=self.get('S_KIND');assert kind==3
        source=self.view(self.get('S_SOURCE_SLOT'),self.get('S_SOURCE_OFFSET'),self.get('S_SOURCE_BYTES'))
        command=self.view(self.get('S_COMMAND_SLOT'),self.get('S_COMMAND_OFFSET'),self.get('S_COMMAND_BYTES'))
        observed=bound_run(self.bound.call,self.peers,label,source,command)
        result=observed['workspace'];self.slots[32]=Buffer(command,True);self.slots[33]=Buffer(result,True)
        for slot in (32,33):struct.pack_into('<Q',w.value,C['CAPS']+8*slot,self.slots[slot].size)
        for key,value in dict(S_STATE=2,S_RESULT_SLOT=33,S_RESULT_BYTES=len(result),S_RESULT_CODE=128,S_RESULT_EVENT_OFFSET=0,S_RESULT_EVENT_BYTES=128).items():self.set(key,value)
        w.write(C['S_RESULT_EVENT'],result[:128])
        # This is the explicit, recorded service-role fixture boundary. No
        # assertion here claims that the independent role-58 HIA image ran.
        self.set('L_DRIVER',58);self.set('L_NEXT_DRIVER',57);self.set('C_SEQUENCE',self.get('C_SEQUENCE')+1)
        self.set('C_PENDING',8);self.set('C_NEXT',self.get('S_RETURN_PHASE'));self.set('C_OBSERVE',0)
        self.evidence.record(case=label,role='explicit-foreign-service58-mechanics',before=self.evidence.raw(before),after=self.evidence.raw(w.raw()),
            complete_actual_peer_workspace=self.evidence.raw(result),actual_native_bounded_wire_decode=True,role58_HIA_image_executed=False)
        return self.ack(8)
    def execute(self,label,command):
        while True:
            e=self.control(label,command);assert e[0]==M(b'HIACDE01') and e[2]==111
            op=e[1];args=e[4:]
            if op==7:
                value=self.view(e[6],e[7],e[8]) if e[8] else b''
                assert not e[8] or self.slots[e[6]].readonly
                return dict(kind='terminal',event=e,bytes=value)
            if op==8:
                assert args[0] in (58,59)
                if args[0]==59:
                    return dict(kind='apply-handoff',event=e,query=self.slots[15].raw(),graph=self.slots[14].raw())
                command=self.service_fixture(label);continue
            if op==2:
                slot,size=args[:2];assert 4<=slot<64 and size>0
                old=self.slots.get(slot);assert old is None or (not old.readonly and size>old.size)
                self.slots[slot]=Buffer((old.raw() if old else b'')+bytes(size-(old.size if old else 0)))
                command=self.ack(op);continue
            if op==3:
                slot,at,size=args[:3];self.slots[slot].write(at,bytes(size));command=self.ack(op);continue
            if op==4:
                src,at,dest,to,size=args[:5];assert src!=dest and dest>=4
                self.slots[dest].write(to,self.view(src,at,size));command=self.ack(op);continue
            if op==5:
                slot=args[0];assert 4<=slot<64 and slot in self.slots
                self.slots[slot].check();del self.slots[slot];command=self.ack(op);continue
            if op==6:
                slot,readonly=args[:2];assert readonly in (0,1);self.slots[slot].readonly=bool(readonly);command=self.ack(op);continue
            if op==14:
                slot,at,size=args[:3];assert size<=256;command=self.ack(op,observed=self.view(slot,at,size));continue
            assert op==1,(label,e)
            role,first,at,size,second,secondsize,work,worksize,observe,offset,count,reserved=args
            assert reserved==0 and len({first,second,work})==3 and role in self.images and count<=256
            first_raw=self.view(first,at,size);second_before=self.view(second,0,secondsize);work_before=self.view(work,0,worksize)
            a=self.slots[first];b=self.slots[second];scratch=self.slots[work];assert not scratch.readonly
            code=int(self.images[role]._entry(a.address+at,size,b.address,secondsize,scratch.address,worksize));self.roles[role]+=1
            a.check();b.check();scratch.check();assert self.view(first,at,size)==first_raw
            if role in (35,36,37,39,47,48,49,51):assert self.view(second,0,secondsize)==second_before
            self.evidence.record(case=label,role=role,return_code=code,first=self.evidence.raw(first_raw),second_before=self.evidence.raw(second_before),
                second_after=self.evidence.raw(self.view(second,0,secondsize)),before=self.evidence.raw(work_before),after=self.evidence.raw(self.view(work,0,worksize)),inputs_and_canaries_equal=True)
            assert code!=0xfffffffd,(label,role,code,self.get('C_PHASE'))
            command=self.ack(op,code,self.view(observe,offset,count))
    def close(self):
        self.codec.close();self.bound.close();self.peers.close();self.evidence.close()
        assert all(p.read_bytes()==raw for p,raw in self.pins.items())
        (self.out/'custody.json').write_text(json.dumps(dict(pins={str(p):dict(bytes=len(raw),sha256=sha256(raw).hexdigest()) for p,raw in self.pins.items()},
            sources_unchanged=True,actual_entries=self.roles,control_calls=self.calls,
            scope='ACTUAL_HIA_QUERY_CONTROLLER_WITH_EXPLICIT_PRIVATE_PREDECESSOR_AND_FOREIGN_SERVICE_MECHANICS_NOT_COMPLETE_EXECUTABLE'),indent=2,sort_keys=True)+'\n')
