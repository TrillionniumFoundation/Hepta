"""Whole query-controller result/refusal equality with explicit open fixtures."""
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import copy,json,time,traceback
from hepta.hia_program import verify_program
from hepta.hia_program_tools import bounded_json_wire
from hepta.hia_edit_query import prepare_edit,apply_edit
from hepta.hia_edit_batch import prepare_batch,apply_batch
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans,selected,swaps
from tests.test_hia_program_composite import stored_loan_program
from query_controller_harness import QueryController,M

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'development/query-controller-r1';OUT.mkdir(exist_ok=False)
driver=QueryController(OUT/'actual');capture=driver.peers.wm.capture;cases=[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')
def blocked(*args,**kwargs):raise AssertionError('hosted semantic owner entered actual query-controller path')
def guards():
    stack=ExitStack()
    for name in ['hepta.hia_edit_query.prepare_edit','hepta.hia_edit_query.apply_edit','hepta.hia_edit_query._reference_edit_slice',
        'hepta.hia_edit_query._cfg_downstream_slice','hepta.hia_edit_batch.prepare_batch','hepta.hia_edit_batch.apply_batch',
        'hepta.hia_program.verify_program','hepta.hia_program_tools.bounded_json_wire','hepta.hia_program_tools.decode_json',
        'hepta.hia_instruction_policy_native.transport','hepta.hia_json_decode_native.materialize','json.loads']:
        stack.enter_context(patch(name,new=blocked))
    return stack
def exercise(label,program,query,mode,expected=None,error=None):
    raw=bounded_json_wire(program,8<<20,ensure_ascii=False);graph=capture(query);response=capture({})
    case=OUT/('case-'+str(len(cases)).zfill(3));case.mkdir()
    for name,value in [('program.bin',raw),('query.graph',graph),('response.graph',response)]: (case/name).write_bytes(value)
    expected_wire=bounded_json_wire(expected,1<<20) if expected is not None else None
    if expected_wire is not None:(case/'expected-query.json').write_bytes(expected_wire)
    (case/'expected.json').write_text(json.dumps(dict(error=error,mode=mode),indent=2,sort_keys=True)+'\n')
    command=driver.begin_fixture(label,raw,graph,response,mode,4300)
    with guards():actual=driver.execute(label,command)
    if error is not None:
        assert actual['kind']=='terminal' and actual['event'][4]==1 and actual['bytes']==error.encode(),(label,actual,error)
        outcome='EXACT_FULL_PUBLIC_REFUSAL'
    elif mode in (1,2):
        assert actual['kind']=='apply-handoff' and actual['query']==expected_wire,(label,actual['kind'],actual.get('event'))
        outcome='EXACT_RECONSTRUCTED_QUERY_AND_NATIVE_MATCH_BEFORE_APPLY'
    else:
        import struct
        assert actual['kind']=='terminal' and actual['event'][4]==0
        h=struct.unpack_from('<8Q',actual['bytes']);assert h==(M(b'HIAEDR01'),mode,len(expected_wire),0,0,0,0,0)
        assert actual['bytes'][64:]==expected_wire,(label,actual['bytes'][64:],expected_wire)
        outcome='EXACT_COMPLETE_PREPARED_QUERY'
    for name,value in actual.items():
        if type(value)is bytes:(case/('actual-'+name+'.bin')).write_bytes(value)
    cases.append(dict(case=label,mode=mode,outcome=outcome,actual_native_controller=True,actual_native_semantic_owners=True,
        private_predecessor_fixture=True,foreign_service58_mechanics=True,whole_native_executable_closed=False))
    print(json.dumps(cases[-1],sort_keys=True),flush=True)

try:
    base=fixture();selection=dict(function='calculate',block='entry',output='y',fields=['op']);single=prepare_edit(base,**selection)
    exercise('prepare-single',base,[selection],3,single)
    exercise('apply-single-reconstruction',base,single,1,single)
    bad=copy.deepcopy(single);bad['fields']=None;bad['context']=None
    exercise('fields-first',base,bad,1,error='E_HIA_QUERY: fields must be a unique nonempty subset of op, args, attrs')
    bad=copy.deepcopy(single);bad['context']['dependencies'][0]['operation']['attrs']['value']=True
    exercise('bool-forgery',base,bad,1,error='E_HIA_QUERY: stale or modified edit query')
    b=loans();selections=[selected('reader'),selected('writer')];batch=prepare_batch(b,selections)
    exercise('prepare-batch',b,selections,4,batch)
    exercise('apply-batch-reconstruction',b,batch,2,batch)
    exercise('batch-text-query',b,json.dumps(batch,indent=2),2,batch)
    exercise('prepare-overlap-before-later-bad',b,[selected('reader'),selected('reader'),None],4,error='E_HIA_EDIT_BATCH: selections overlap one instruction')
    bad=copy.deepcopy(batch);bad['sites'][0]['query']['fields']=[];bad['sites'][1]['query']['selector']={}
    exercise('all-shapes-before-first-fields',b,bad,2,error='E_HIA_EDIT_BATCH: invalid nested selection')
    structured=stored_loan_program();core=verify_program(structured).as_dict();fn=core['functions'][0];block=next(v for v in fn['blocks'] if v['id']==fn['entry']);op=next(v for v in block['ops'] if v['out'])
    sel=dict(function=fn['name'],block=block['id'],output=op['out'][0]['name'],fields=['op','args','attrs'])
    q=prepare_edit(structured,**sel);exercise('structured-input-digest-query',structured,q,1,q)
    summary.update(status='PASS',cases=cases,actual_cases=len(cases),whole_stack_closed=False,actual_HIA_service58_executed=False)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc),completed_cases=cases);traceback.print_exc();raise
finally:
    driver.close();summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
