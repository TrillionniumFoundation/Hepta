# Native edit service controller contract — development r1

This fixes the private integration interface for new HIA development. It is not
an executed controller or a public API declaration. All original component
limits and refused-input ordering remain with their existing HIA owners.

## Shared executor and controller memory

Reuse the fixed HIACDE01/HIACDA01 protocol, 64 buffer slots, controller workspace
slot 2 of exactly 1 MiB, empty slot 0 of one byte, CAPS at 4096, bounded OBS at
512, ARGS at 1024 and command scratch WIRE at 2048. Main/query/service/apply
controller image roles are 56/57/58/59. A switch changes only the HIA controller
image and phase; the actual private workspace and mappings are retained.

Role 56 initially owns raw program slot 1, readonly query Graph slot 4 and
readonly response Graph slot 5. Slot 3 is unused. Its private 64-byte INIT is
`[HIAECI01, lease, mode, digits, programBytes, queryGraphBytes,
responseGraphBytes, 0]`. Modes are single apply 1, batch apply 2, single prepare
3, batch prepare 4, single render 5 and batch render 6. The first implementation
may explicitly refuse unimplemented modes as a private development limit; such
a refusal is not public behavior or closure. Program admission precedes query
inspection for modes 1–4. Query/response captures are immutable private inputs;
the ordinary public frontend and foreign-object capture are separate work.

Main/query/apply mappings occupy slots 6–31 and 50–63. The finite nested peer
service exclusively owns 32–49: each depth has `second=32+3*d`,
`work=33+3*d`, `aux=34+3*d`, for d=0..5. Each child finishes and its complete
actual output is copied before its three mappings are released. No arbitrary
service recursion is admitted. The known graph is batch -> single -> bounded
-> wire/decode -> raw/arena, with envelope -> wire as another root.

## Starting and returning a service

The common HIA helper has this signature (including w, 11 parameters):

`edit_service_start(w, kind, sourceSlot, sourceOffset, sourceBytes,
commandSlot, commandOffset, commandBytes, initialWork,
returnDriver, returnPhase) -> u64`

The caller sets the below fields, then issues the ordinary switch event to
role 58 at phase 50000. This helper does not itself issue an event. The input
command is copied immediately into the top service's second mapping, so a
command staged at controller WIRE remains valid. The input source view remains
held and immutable throughout the service. Top service second/work/aux slots
must be absent on entry; the caller releases its retained result before starting
another service. All extents and additions are checked in HIA.

The shared service request fields occupy consecutive u64 words from 28672:

| Offset | Meaning |
| ---: | --- |
| 28672 | service state: 0 idle, 1 requested/running, 2 returned |
| 28680 | kind |
| 28688 | source slot |
| 28696 | source offset |
| 28704 | source bytes |
| 28712 | command slot |
| 28720 | command offset |
| 28728 | command bytes |
| 28736 | initial workspace bytes |
| 28744 | return driver (56, 57 or 59) |
| 28752 | return phase |
| 28760 | result slot |
| 28768 | complete result workspace bytes |
| 28776 | actual component return code |
| 28784 | result event offset (normally zero) |
| 28792 | result event bytes (128, or 256 for batch renderer) |
| 28800..29055 | complete actual terminal event copy, up to 256 bytes |

Service private frame storage begins at 32768 and may extend to 49152.
It must not overwrite controller common fields, request/result fields,
main state at 16384–19999, query state at 20000–23999 or apply state at
24000–27999. The service uses the same C_MAGIC (HIAECS01), L_MAGIC and
acknowledge rules as the other new controllers. It never initializes a new
session from a plausible arbitrary service request.

On top-level completion, role 58 protects the complete actual terminal
workspace readonly, fills result fields, copies its actual full event and
switches to the requested driver/phase. Success and semantic error both return
complete real workspaces. BAD/private protocol status permanently poisons the
whole private controller instead of fabricating a semantic failure.

## Service kinds and exact peer framing

Kinds: 1 Graph wire, 2 Agent JSON decode, 3 caller-bounded input, 4 patch
envelope wire, 5 single renderer, 6 batch renderer. Internal raw decoder and
arena-to-Graph children use kind 7 and 8; callers may not request those internal
kinds as top-level public operations. Kind 1 selects actual scan role 29 then
emit 30. Kind 2 owns role 31 and peers 32/33. Kind 3 owns role 34. Kind 4 owns
52. Kind 5 owns 61. Kind 6 owns 62/63. Existing frozen harnesses define each
actual command/event layout; no projected event replaces the full backing
workspace in a peer reply.

Nested replies retain the requesting parent's actual lease/request. Wire and
Agent decode replies to bounded/envelope owners use HIAQWR01 plus the complete
workspace, including a semantic error terminal. Agent decode internal replies
use HIAJDR01, with the full raw-decoder output or full arena-to-Graph workspace.
Renderer reply framing is the frozen renderer protocol. Growth, peer choice,
switching scan/emit and all frame construction are HIA decisions. The fixed
executor only runs its requested allocation/copy/protection/invocation steps.

The arbitrary raw-byte Graph issuer can be inlined into the final main HIA
controller; its separate completed seven-function image remains a proof
artifact. Final image role 55 is reserved for the new complete Core diagnostic
renderer, paired with replacement Core checker role 27. Frozen program
admission and compiler-qualified bundles are not modified by this design.
