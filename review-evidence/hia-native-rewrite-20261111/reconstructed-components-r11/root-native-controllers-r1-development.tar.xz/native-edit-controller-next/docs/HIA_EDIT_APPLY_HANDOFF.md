# HIA query -> apply continuation, fixed development r1

Role 57 transfers to role 59 with the same private controller workspace and
ordinary HIACDA01 switch acknowledgement at phase 60000. It has not published
any candidate or final receipt. Actual full program admission, Core/source
identity join, complete per-query construction, ordered batch overlap gates,
the original bounded query gates and exact canonical query-byte comparison have
all succeeded before this transition. The newly authored controller is not yet
an executed complete edit pipeline; this describes the intended actual handoff.

The generic constants/helpers are in
`native-edit-controller-next/tools/hia_edit_controller_common.py`; root owns
that file. The apply authoring workspace is separate. Controllers share
C_MAGIC HIAECS01, L_MAGIC HIALDS01, MIN_WORK 1 MiB and the original executor
operation/ACK format. Role 59 calls acknowledge(s,w,59), then dispatches its
own phases 60000+ and common helper phases. The service driver is role 58.

| Buffer slot | Actual immutable value at handoff |
| ---: | --- |
| 0 | one zero byte for unused zero-length views |
| 1 | original raw program submission |
| 2 | common mutable controller workspace |
| 4 | original private query Graph |
| 5 | original private response Graph, not yet inspected |
| 6 | actual 256-byte program receipt followed by canonical Core |
| 7 | exact canonical admitted Core bytes |
| 8 | actual integer codec + bitmap-issuer Core SourceLease |
| 14 | complete reconstructed single query or final batch Graph |
| 15 | complete reconstructed bounded canonical query bytes |
| 16 | complete bounded untrusted canonical query bytes, equal to 15 |
| 24 | normalized batch query Graph, for batch mode 2 only |

All other slots are free, except controller-private caps 0/1/2 and the above
immutable snapshots. Original application mode E_MODE is 1 single or 2 batch;
E_DIGITS is the exact caller integer conversion setting. E_INPUT_HASH at 16768
and E_CORE_HASH at 16800 each hold 32 actual digest bytes. E_QUERY_HASH at 16992
and E_RESPONSE_HASH at 17024 are reserved for apply to fill. E_REQUEST is a
monotone per-session native request counter; advance(w,E_REQUEST) allocates the
next request. A plausible receipt header is not used as proof of successful
program admission or identity.

Fixed suggested output slots already named in common: response raw 17,
response normalized Graph 18, pending envelope/metadata Graph 19, exact patch
envelope 20, canonical candidate 21, private native patch receipt 22, final
complete receipt JSON 23. Slots 25–31, 50–60 are available as apply scratch;
30 is the final publication mapping, and 61–63 are common SHA stream scratch.
Slots 32–49 belong exclusively to the nested service controller. Apply-private
state may use 24000–27999. Do not overwrite shared lower controller fields,
main/query fields, publish fields at 28000, service request at 28672–29055,
generic primitive call at 30464, hash fields at 31232 or service frames at
32768–49151.

Common HIA helpers already authored:

* `edit_bound_start(w, sourceSlot, root, policy, rawTarget, graphTarget,
  returnDriver, returnPhase)` stages the bounded owner and service request.
  Call switch(o,w,58,50000) after its zero return. Dispatch common
  `edit_bound_step` for 42000..42099; it copies the complete actual raw/Graph
  result into owned readonly targets, releases service mappings, then resumes
  returnPhase. A semantic refusal copies the owner's full real UTF-8 text and
  enters publication error phases; private malformed frames poison the context.
* `edit_simple_start` / `edit_simple_step` at 40000..40099 own continuation
  for the action/lease/request/sequence-style private kernels with a 128-byte
  event at offset 256. Slot B_KERNEL=10 must be absent on start. The complete
  actual terminal event is copied to E_SIMPLE_EVENT at 17152. It is the caller's
  responsibility to consume every source-backed range before releasing work.
* `hash_start` and `hash_view_start` use actual SHA stream image 22, with
  phases 300..319, slots 61–63 and no new chunk limit. They release scratch and
  copy the final 32 actual digest bytes to a specified controller offset.
* `index_step` at 26000..26999 uses frozen image 2 and slots 28/29 to issue
  immutable packet SourceLeases. Those are scratch here, not live handoff data.
* `edit_service_start` and its exact result contract are in the separate
  HIA_EDIT_SERVICE_CONTROLLER_ABI document. It supports actual Graph wire,
  Agent integer JSON decode, bounded inputs, patch envelope and renderers.
* `edit_result_start(w, candidateSlot,at,len, receiptSlot,at,len,
  querySlot,at,len)` plus `edit_publish_step` at 45000..45099 constructs
  `[HIAEDR01,mode,len1,len2,len3,0,0,0]` followed by the three complete views.
  It marks the result readonly and emits the sole successful terminal. For
  apply, use exact candidate, exact full receipt and exact prepared query.
* `edit_error_start` publishes the complete actual native diagnostic view
  (domain 1 edit, 2 program, 3 UnicodeEncodeError, 4 AgentRejected). It does not
  manufacture dynamic Core text or foreign cause objects.

Final terminal remains 128-byte HIACDE01: words 0–3 magic/op7/lease/sequence,
4 domain (0 success), 5 native error code, 6 actual readonly output slot,
7 offset, 8 byte length, 9 mode, 10 diagnostic stage, 11–15 currently zero.
The fixed executor copies the indicated view to stdout only on success and
puts the actual terminal on stderr. On a semantic refusal, stdout stays empty
and stderr carries the terminal plus its indicated actual diagnostic view.

Follow the existing completed native composition's order, including extraction
and full base re-admission before patch result mode 2, then full candidate
admission before decoding or publishing the private receipt. Join the new Core
diagnostic context before releasing the actual same-invocation state/arena.
No hosted policy fallback, receipt header authority, candidate-only admission,
shortened diagnostics or new global budget is permitted.
