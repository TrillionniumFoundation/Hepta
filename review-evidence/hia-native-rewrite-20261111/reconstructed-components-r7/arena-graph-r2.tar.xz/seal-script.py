"""Seal only the issued-arena bridge and its exact dependencies/raw controls."""
from pathlib import Path
from hashlib import sha256
import json, tarfile, os, stat
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent
ARCHIVE=BASE/'hia-arena-graph-r2-development.tar.xz'
selected={}
def add(path,name=None):
    path=Path(path)
    if path.is_dir():
        for child in sorted(path.rglob('*')):
            if child.is_file() and '__pycache__' not in child.parts and child.suffix!='.pyc':
                add(child,(Path(name)/child.relative_to(path)).as_posix() if name else None)
    else:
        key=name or path.relative_to(ROOT).as_posix()
        assert key not in selected or selected[key]==path
        selected[key]=path
for rel in ['tools/generate_hia_arena_graph.py','examples/hia_bootstrap/arena_graph.hiaasm',
            'docs/HIA_ARENA_GRAPH_ABI.md','docs/HIA_GRAPH_JSON_WIRE_R3_INTEGRATION_NOTES.md',
            'development/renderer-float-boundary-reference.json','dependencies/f50-B3.image.bin']:
    add(ROOT/rel)
for path in sorted((ROOT/'development').iterdir()):
    if path.name.startswith(('arena-graph-','arena_graph_','compile_arena_graph_')):
        add(path)
for path in sorted((ROOT/'checkpoints').iterdir()):
    if path.name.startswith('arena-graph-'):add(path)
add(ROOT/'checkpoints/source-r3','frozen-graph-wire/source-r3')
add(ROOT/'development/compile-r3','frozen-graph-wire/compile-r3')
add(ROOT/'development/graph_harness_r3.py','frozen-graph-wire/graph_harness_r3.py')
add(ROOT/'reference','frozen-reference')
add(Path(__file__),'seal-script.py')
manifest=[]
for name,path in sorted(selected.items()):
    raw=path.read_bytes()
    manifest.append({'path':name,'source_path':str(path),'bytes':len(raw),'mode':stat.S_IMODE(path.stat().st_mode),
                     'sha256':sha256(raw).hexdigest()})
with tarfile.open(ARCHIVE,'w:xz',preset=6) as tar:
    for row in manifest:tar.add(row['source_path'],arcname=row['path'],recursive=False)
with tarfile.open(ARCHIVE,'r:xz') as tar:
    members=tar.getmembers();assert len(members)==len(manifest)
    expected={row['path']:row for row in manifest}
    for member in members:
        row=expected.pop(member.name);raw=tar.extractfile(member).read()
        assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'] and member.mode==row['mode']
        path=Path(row['source_path']);assert raw==path.read_bytes() and stat.S_IMODE(path.stat().st_mode)==row['mode']
    assert not expected
raw=ARCHIVE.read_bytes()
custody={'schema':'hepta.hia.arena-graph-development-custody.v1','status':'PASS',
         'archive_path':str(ARCHIVE),'archive_bytes':len(raw),'archive_sha256':sha256(raw).hexdigest(),
         'member_count':len(manifest),'uncompressed_file_bytes':sum(row['bytes'] for row in manifest),
         'archive_members_equal_live_bytes_sha256_and_mode':True,
         'scope':'ARENA_GRAPH_R2_DEVELOPMENT_WITH_ORIGINAL_FAILURES_NOT_COLD_QUALIFIED',
         'actual_final_cases':262,'actual_final_entries':{'bridge':533,'decoder':223,'scan':252,'emit':502},
         'public_foreign_capture_closed':False,'full_renderer_implemented':False,'members':manifest}
path=Path(str(ARCHIVE)+'.custody.json');path.write_text(json.dumps(custody,indent=2,sort_keys=True)+'\n')
print(json.dumps({key:value for key,value in custody.items() if key!='members'},indent=2,sort_keys=True))
print(json.dumps({'custody_path':str(path),'custody_bytes':path.stat().st_size,'custody_sha256':sha256(path.read_bytes()).hexdigest()}))

