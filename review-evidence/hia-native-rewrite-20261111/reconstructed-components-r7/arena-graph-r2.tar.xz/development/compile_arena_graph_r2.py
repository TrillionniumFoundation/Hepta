"""Source-bound actual development compilation of the arena bridge and issuer."""
from pathlib import Path
from hashlib import sha256
import json, shutil, sys, time

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-agent-edit-native')
sys.path.insert(0,str(BASE))
from tools.qualify_hia_selfhost import compile_stage
OUT=ROOT/'development/arena-graph-compile-r2'
SNAP=ROOT/'checkpoints/arena-graph-source-r2'
OUT.mkdir(parents=True,exist_ok=False);SNAP.mkdir(parents=True,exist_ok=False)
files=['tools/generate_hia_arena_graph.py','examples/hia_bootstrap/arena_graph.hiaasm',
       'docs/HIA_ARENA_GRAPH_ABI.md']
pins={}
def save(path,dest):
    raw=path.read_bytes()
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
    assert dest.read_bytes()==path.read_bytes()==raw
    pins[path]=raw;pins[dest]=raw
    return raw
for relative in files:save(ROOT/relative,SNAP/relative)
for relative in ['tools/generate_hia_agent_data_json.py','tools/generate_hia_json_decode.py',
                 'tools/generate_hia_agent_binary64.py','tools/generate_hia_selfhost.py',
                 'tools/qualify_hia_selfhost.py','tools/hia_selfhost_child.py',
                 'examples/hia_bootstrap/agent_data_json.hiaasm',
                 'hepta/hia_agent_data_json_native.py','hepta/hia_json_decode_native.py']:
    save(BASE/relative,SNAP/'dependencies'/relative)
compiler=ROOT/'dependencies/f50-B3.image.bin'
pins[compiler]=compiler.read_bytes()
assert sha256(pins[compiler]).hexdigest()=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
source_manifest={'scope':'UNEXECUTED_ARENA_GRAPH_R2_SOURCE_FREEZE',
 'files':[{ 'path':str(path.relative_to(SNAP)), 'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
          for path,raw in pins.items() if path.is_relative_to(SNAP)],
 'compiler_sha256':sha256(pins[compiler]).hexdigest()}
(SNAP/'source.json').write_text(json.dumps(source_manifest,indent=2,sort_keys=True)+'\n')
pins[SNAP/'source.json']=(SNAP/'source.json').read_bytes()
start=time.monotonic_ns();components={};summary=None
try:
    inputs={'bridge':SNAP/'examples/hia_bootstrap/arena_graph.hiaasm',
            'decoder':SNAP/'dependencies/examples/hia_bootstrap/agent_data_json.hiaasm'}
    for role,source in inputs.items():
        artifact,receipt=compile_stage(OUT,'arena-graph-'+role,compiler,pins[source])
        actual=artifact.read_bytes()
        assert receipt['source_sha256']==receipt['input_sha256']==sha256(pins[source]).hexdigest()
        assert receipt['artifact_sha256']==receipt['image_sha256']==sha256(pins[compiler]).hexdigest()
        assert receipt['produced_sha256']==sha256(actual).hexdigest()
        assert receipt['produced_bytes']==receipt['core_u32']==len(actual)
        for path,raw in pins.items():assert path.read_bytes()==raw
        row={'schema':'hepta.hia.arena-graph-'+role+'-native.v1',
             'source_path':str(source),'source_sha256':sha256(pins[source]).hexdigest(),
             'image_path':str(artifact),'image_sha256':sha256(actual).hexdigest(),
             'compiler_sha256':sha256(pins[compiler]).hexdigest()}
        (OUT/(role+'.manifest.json')).write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
        components[role]=row
    summary={'status':'PASS','scope':'SOURCE_BOUND_ARENA_GRAPH_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD',
             'components':components,'all_source_before_after_exact':True,
             'source_manifest_sha256':sha256(pins[SNAP/'source.json']).hexdigest(),
             'wall_elapsed_ns':time.monotonic_ns()-start}
    (OUT/'bundle.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
except BaseException as exc:
    summary={'status':'FAIL','error_type':type(exc).__name__,'error':str(exc),'components':components}
    raise
finally:
    for path,raw in pins.items():assert path.read_bytes()==raw
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)

