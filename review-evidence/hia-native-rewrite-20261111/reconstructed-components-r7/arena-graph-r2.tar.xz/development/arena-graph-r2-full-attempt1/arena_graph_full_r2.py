"""Independent full representation differential and malformed arena controls."""
from pathlib import Path
from hashlib import sha256
import ctypes, json, math, random, struct, sys, time
from arena_graph_harness_r2 import Actual, CANARY, COMMAND, BAD
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'development/arena-graph-r2-full-attempt1'
a=Actual(OUT);start=time.monotonic_ns();cases=[];rng=random.Random(731029)
def checked(wire,name,**options):cases.append(a.check(wire,name,**options))
def encoded(value):return json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf-8')
def tree(depth=0):
    if depth>=4:kind=rng.randrange(6)
    else:kind=rng.randrange(8)
    if kind==0:return None
    if kind==1:return bool(rng.randrange(2))
    if kind==2:return rng.randrange(-(1<<rng.randrange(1,700)),1<<rng.randrange(1,700))
    if kind==3:
        while True:
            x=struct.unpack('<d',rng.getrandbits(64).to_bytes(8,'little'))[0]
            if math.isfinite(x):return x
    if kind==4:return ''.join(rng.choice('aä😀\x00\n\\"') for _ in range(rng.randrange(30)))
    if kind==5:return ''
    if kind==6:return [tree(depth+1) for _ in range(rng.randrange(6))]
    return {str(i)+rng.choice('abcä😀'):tree(depth+1) for i in range(rng.randrange(6))}
def work(size=512):
    value=ctypes.create_string_buffer(size+32)
    ctypes.memset(ctypes.addressof(value)+size,0xad,32)
    return value
def command(wire,arena,**changes):
    fields=[COMMAND,31,1,len(wire),len(arena),4300,1,0]
    for key,value in changes.items():fields[int(key)]=value
    return struct.pack('<8Q',*fields)+wire
def mutate(raw,offset,value):
    raw=bytearray(raw);struct.pack_into('<Q',raw,offset,value);return bytes(raw)
def negative(arena,wire,name,cmd=None):
    raw=cmd or command(wire,arena);size=512;w=work(size);calls=0
    while True:
        ret,event=a.call(arena,raw,w,size,name);calls+=1
        if ret==128 and event[1]==1:
            n=event[4];nw=work(n);ctypes.memmove(nw,w,size);w=nw;size=n;continue
        assert ret==BAD,(name,ret,event)
        corrected=command(valid_wire,valid_arena)
        retry,revent=a.call(valid_arena,corrected,w,size,name+'-poison-followup')
        assert retry==BAD,(name,retry,revent)
        cases.append({'case':name,'status':'PASS','bad_return':ret,'followup':retry,'calls':calls+1})
        return
try:
    for index,wire in enumerate([b'null',b'false',b'true',b'0',b'-0',b'1',b'-1',b'18446744073709551616',
              b'1.25',b'-0.0',b'1e-999',b'1e999',b'[]',b'{}',
              b'{"b":1,"a":[true,null,"x",1.25]}',b'"\\ud83d\\ude00"',b'""']):
        checked(wire,'scalar-'+str(index))
    for i in range(180):checked(encoded(tree()),'tree-'+str(i))
    floats=[]
    for i in range(2048):
        while True:
            value=struct.unpack('<d',rng.getrandbits(64).to_bytes(8,'little'))[0]
            if math.isfinite(value):floats.append(value);break
    checked(encoded(floats),'2048-independent-binary64')
    for i,text in enumerate(['2.4703282292062327e-324','2.4703282292062328e-324',
                            '4.9406564584124654e-324','1.7976931348623157e308',
                            '1.7976931348623158e308','1.7976931348623159e308',
                            '-1.7976931348623159e308','0e9999999999999999',
                            '-0e-9999999999999999','1e-9999999999999999']):
        checked(text.encode(),'rounding-'+str(i))
    checked(b'1e999','generic-positive-infinity',finite=0)
    checked(b'-1e999','generic-negative-infinity',finite=0)
    for digits in [639,640,641]:
        checked(b'9'*digits,'int-runtime640-'+str(digits),digits=640)
    for digits in [4299,4300,4301]:
        checked(b'9'*digits,'int-runtime4300-'+str(digits))
    checked(b'1'+b'0'*5000,'int-runtime-disabled',digits=0)
    checked(b'['+b'9'*4301+b',1e999]','first-integer-error')
    checked(b'[1e999,'+b'9'*4301+b']','first-floating-error')
    checked(encoded({'wide':{str(i):i for i in range(2048)},'small':[{str(i):i} for i in range(1024)]}),
            'wide-and-many-small-key-tables')
    checked(encoded({'key😀': 'ä😀\\\x00'*10000,'tail':1.125}),'large-unicode-count')
    checked(b'"'+b'a'*1048576+b'"','one-MiB-string')
    valid_wire=b'{"a":[1,2.5],"b":true}'
    _,valid_arena=a.decoder(valid_wire,'protocol-valid')
    assert valid_arena is not None
    for offset,value in [(0,0),(8,0),(8,1048577),(16,0),(24,len(valid_arena)-1),
                         (32,len(valid_arena)+1),(40,len(valid_wire)+1),(48,2),(56,1)]:
        negative(mutate(valid_arena,offset,value),valid_wire,'bad-header-'+str(offset))
    negative(valid_arena[:-1],valid_wire,'truncated-arena')
    negative(valid_arena+b'\0',valid_wire,'trailing-arena')
    for field,value in [(0,8),(1,0),(2,1),(3,0),(4,999),(5,1),(6,1)]:
        negative(mutate(valid_arena,64+field*8,value),valid_wire,'bad-root-'+str(field))
    # Locate actual child rows in the already issued frame; malformed controls
    # alter fields only, never infer admission in the forwarding code.
    count=struct.unpack_from('<Q',valid_arena,8)[0]
    rows=[struct.unpack_from('<7Q',valid_arena,64+56*i) for i in range(count)]
    for i,row in enumerate(rows[1:],1):
        negative(mutate(valid_arena,64+56*i+8,i),valid_wire,'self-parent-'+str(i))
    # Reuse the exact key span of first root child for the second root child.
    root_children=[i for i,row in enumerate(rows) if row[1]==0]
    left,right=root_children
    bad=mutate(valid_arena,64+56*right+40,rows[left][5])
    bad=mutate(bad,64+56*right+48,rows[left][6])
    negative(bad,valid_wire,'duplicate-decoded-key')
    first_number=next(i for i,row in enumerate(rows) if row[0]==3)
    badwire=bytearray(valid_wire);badwire[rows[first_number][3]]=ord('x')
    negative(valid_arena,bytes(badwire),'forged-numeric-source')
    float_index=next(i for i,row in enumerate(rows) if row[0]==7)
    negative(mutate(valid_arena,64+56*float_index,3),valid_wire,'float-labeled-integer')
    negative(mutate(valid_arena,64+56*first_number,7),valid_wire,'integer-labeled-float')
    for field,value in [(0,0),(1,0),(2,0),(3,len(valid_wire)+1),(4,len(valid_arena)-1),(6,2),(7,1)]:
        negative(valid_arena,valid_wire,'bad-command-'+str(field),command(valid_wire,valid_arena,**{str(field):value}))
    negative(valid_arena,valid_wire,'short-command',command(valid_wire,valid_arena)[:63])
    # GROW correlation and completed-session disposal.
    for field,value in [(1,32),(2,2),(5,640),(6,0)]:
        w=work();ret,event=a.call(valid_arena,command(valid_wire,valid_arena),w,512,'grow-'+str(field))
        assert ret==128 and event[1]==1
        size=event[4];nw=work(size);ctypes.memmove(nw,w,512)
        ret,event=a.call(valid_arena,command(valid_wire,valid_arena,**{str(field):value}),nw,size,'grow-mismatch-'+str(field))
        assert ret==BAD
        ret,event=a.call(valid_arena,command(valid_wire,valid_arena),nw,size,'grow-poison-'+str(field));assert ret==BAD
        cases.append({'case':'grow-mismatch-'+str(field),'status':'PASS'})
    w=work();cmd=command(valid_wire,valid_arena)
    ret,event=a.call(valid_arena,cmd,w,512,'complete-grow');assert event[1]==1
    size=event[4];nw=work(size);ctypes.memmove(nw,w,512)
    ret,event=a.call(valid_arena,cmd,nw,size,'complete');assert ret==128 and event[1]==0
    ret,event=a.call(valid_arena,cmd,nw,size,'completed-replay');assert ret==BAD
    cases.append({'case':'completed-replay','status':'PASS'})
    # A short buffer cannot safely hold a poison marker; the driver discards it.
    short=work(511);ret,event=a.call(valid_arena,cmd,short,511,'short-workspace')
    assert ret==BAD;cases.append({'case':'short-workspace-disposal','status':'PASS'})
    a.close()
    summary={'status':'PASS','scope':'SOURCE_BOUND_ARENA_GRAPH_R2_DEVELOPMENT',
             'cases':cases,'case_count':len(cases),'entries':a.entries,'wire_entries':a.graph.entries,
             'wall_elapsed_ns':time.monotonic_ns()-start,'public_foreign_capture_closed':False}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({key:value for key,value in summary.items() if key!='cases'},sort_keys=True),flush=True)
except BaseException as exc:
    a.close();failure={'status':'FAIL','class':type(exc).__name__,'error':str(exc),'cases_completed':cases,
                      'entries':a.entries,'wire_entries':a.graph.entries}
    (OUT/'failure.json').write_text(json.dumps(failure,indent=2,sort_keys=True)+'\n')
    raise

