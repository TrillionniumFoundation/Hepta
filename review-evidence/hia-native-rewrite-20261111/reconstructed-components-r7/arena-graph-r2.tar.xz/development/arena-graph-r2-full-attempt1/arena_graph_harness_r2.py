"""Actual issuer -> native arena bridge -> frozen Graph wire development harness."""
from pathlib import Path
from hashlib import sha256
import ctypes, importlib.util, json, math, struct, sys
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-agent-edit-native')
sys.path.insert(0,str(BASE))
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_json_decode_native import arena_sizes
from hepta.hia_program_tools import bounded_json_wire
spec=importlib.util.spec_from_file_location('frozen_graph_wire_r3',ROOT/'development/graph_harness_r3.py')
gw=importlib.util.module_from_spec(spec);spec.loader.exec_module(gw)
MAGIC=lambda name:int.from_bytes(name,'little')
COMMAND=MAGIC(b'HIAGAC01');EVENT=MAGIC(b'HIAGAE01');BAD=0xfffffffd
CANARY=b'\xad'*32

class Actual:
    def __init__(self,out,bundle=None):
        self.out=Path(out);self.pins={};self.entries={'decoder':0,'bridge':0};self.index=0
        bundle=Path(bundle or ROOT/'development/arena-graph-compile-r2/bundle.json')
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes()
            if path in self.pins:assert self.pins[path]==raw
            self.pins[path]=raw;return raw
        rows=json.loads(read(bundle))
        assert rows['status']=='PASS' and rows['scope']=='SOURCE_BOUND_ARENA_GRAPH_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD'
        images={}
        for role,row in rows['components'].items():
            assert role in ('bridge','decoder') and row['schema']=='hepta.hia.arena-graph-'+role+'-native.v1'
            source=read(row['source_path']);image=read(row['image_path'])
            current=read(ROOT/'examples/hia_bootstrap/arena_graph.hiaasm' if role=='bridge'
                         else BASE/'examples/hia_bootstrap/agent_data_json.hiaasm')
            assert source==current and sha256(source).hexdigest()==row['source_sha256']
            assert sha256(image).hexdigest()==row['image_sha256']
            assert row['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
            images[role]=(image,row['image_sha256'])
        assert set(images)=={'bridge','decoder'}
        self.readback();self.out.mkdir(parents=True,exist_ok=False)
        self.images={role:NativeHiaJsonImage(*row) for role,row in images.items()}
        self.log=(self.out/'entries.jsonl').open('w');self.rawdir=self.out/'raw';self.rawdir.mkdir()
        self.graph=gw.Actual(self.out/'wire')
        self.pinfile('source-before.json')
    def readback(self):
        for path,raw in self.pins.items():assert path.read_bytes()==raw
    def pinfile(self,name):
        (self.out/name).write_text(json.dumps({str(p):sha256(v).hexdigest() for p,v in self.pins.items()},indent=2,sort_keys=True)+'\n')
    def raw(self,value,suffix):
        name=sha256(value).hexdigest()+suffix;p=self.rawdir/name
        if not p.exists():p.write_bytes(value)
        else:assert p.read_bytes()==value
        return name
    def decoder(self,wire,case='case',maximum=262144,depth=128):
        osize,wsize=arena_sizes(len(wire),maximum,depth)
        s=ctypes.create_string_buffer(wire+CANARY);o=ctypes.create_string_buffer(osize+32);w=ctypes.create_string_buffer(wsize+32)
        ctypes.memset(ctypes.addressof(o)+osize,0xad,32);ctypes.memset(ctypes.addressof(w)+wsize,0xad,32)
        struct.pack_into('<QQ',w,48,maximum,depth)
        before=ctypes.string_at(w,wsize)
        ret=self.images['decoder']._entry(s,len(wire),o,osize,w,wsize)
        self.entries['decoder']+=1
        assert ctypes.string_at(s,len(wire)+32)==wire+CANARY
        assert ctypes.string_at(ctypes.addressof(o)+osize,32)==CANARY
        assert ctypes.string_at(ctypes.addressof(w)+wsize,32)==CANARY
        row={'case':case,'role':'decoder','return':ret,'wire':self.raw(wire,'.wire'),
             'workspace_before':self.raw(before,'.before'),'workspace_after':self.raw(ctypes.string_at(w,wsize),'.after'),
             'output_bytes':osize,'input_and_canaries_unchanged':True}
        if 64<=ret<=osize:
            arena=ctypes.string_at(o,ret);row['arena']=self.raw(arena,'.arena')
        else:arena=None
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
        return ret,arena
    def call(self,arena,command,work,size,case):
        a=ctypes.create_string_buffer(arena+CANARY);c=ctypes.create_string_buffer(command+CANARY)
        before=ctypes.string_at(work,size)
        ret=self.images['bridge']._entry(a,len(arena),c,len(command),work,size)
        self.entries['bridge']+=1
        event=struct.unpack_from('<16Q',work,0) if size>=128 else None
        assert ctypes.string_at(a,len(arena)+32)==arena+CANARY
        assert ctypes.string_at(c,len(command)+32)==command+CANARY
        assert ctypes.string_at(ctypes.addressof(work)+size,32)==CANARY
        row={'case':case,'role':'bridge','return':ret,'event':event,
             'arena':self.raw(arena,'.arena'),'command':self.raw(command,'.command'),
             'workspace_before':self.raw(before,'.before'),'workspace_after':self.raw(ctypes.string_at(work,size),'.after'),
             'input_and_canaries_unchanged':True}
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
        return ret,event
    def bridge(self,arena,wire,*,case='case',digits=4300,finite=1,initial=512):
        command=struct.pack('<8Q',COMMAND,31,1,len(wire),len(arena),digits,finite,0)+wire
        size=initial;w=ctypes.create_string_buffer(size+32);ctypes.memset(ctypes.addressof(w)+size,0xad,32)
        grows=0
        with patch('hepta.hia_agent_data_json_native.materialize_data',side_effect=AssertionError('host arena materialize disabled')), \
             patch('hepta.hia_json_decode_native.materialize',side_effect=AssertionError('host materialize disabled')):
            while True:
                ret,event=self.call(arena,command,w,size,case)
                assert ret==128,{'case':case,'return':ret,'event':event}
                assert event[0]==EVENT and event[2:4]==(31,1) and event[11:13]==(digits,finite)
                if event[1]==1:
                    assert event[4]>size
                    n=max(size*2,event[4]);nw=ctypes.create_string_buffer(n+32)
                    ctypes.memmove(nw,w,size);ctypes.memset(ctypes.addressof(nw)+n,0xad,32)
                    w=nw;size=n;grows+=1;continue
                if event[1]==3:
                    assert event[8] in (1,2) and event[6]==0
                    return {'error':event[8],'index':event[9],'value':event[10],'grows':grows}
                assert event[1]==0 and event[8]==0 and event[13]==0
                assert event[5]<=size and event[6]<=size-event[5]
                graph=ctypes.string_at(ctypes.addressof(w)+event[5],event[6])
                self.raw(graph,'.graph')
                return {'graph':graph,'grows':grows}
    def check(self,wire,case='case',*,finite=1,digits=None,maximum=8388608):
        if digits is None:digits=sys.get_int_max_str_digits()
        old=sys.get_int_max_str_digits()
        expected_error=None;expected=None
        try:
            if old!=digits:sys.set_int_max_str_digits(digits)
            def floating(value):
                result=float(value)
                if finite and not math.isfinite(result):raise ValueError('nonfinite JSON number')
                return result
            expected=json.loads(wire,parse_float=floating)
        except ValueError as exc:
            expected_error=2 if str(exc)=='nonfinite JSON number' else 1
        finally:
            if old!=digits:sys.set_int_max_str_digits(old)
        ret,arena=self.decoder(wire,case)
        assert arena is not None,{'case':case,'decoder':ret}
        actual=self.bridge(arena,wire,case=case,digits=digits,finite=finite)
        if expected_error is not None:
            assert actual.get('error')==expected_error,(case,actual,expected_error)
            return {'case':case,'status':'PASS','error':expected_error,'grows':actual['grows']}
        expected_graph=gw.capture(expected,lease=31)
        reference_wire=None;reference_error=None
        try:reference_wire=bounded_json_wire(expected,maximum)
        except ValueError as exc:reference_error=str(exc)
        result=self.graph.serialize_graph(actual['graph'],maximum,digits=digits,case=case)
        if reference_error is not None:assert result.get('error')==reference_error,(case,result,reference_error)
        else:assert result.get('wire')==reference_wire,(case,result,reference_wire)
        # Compare complete value representations, including float bits and map order,
        # independently of graph numbering/table order.
        assert shape(actual['graph'])==shape(expected_graph),(case,shape(actual['graph']),shape(expected_graph))
        self.raw(expected_graph,'.expected-graph')
        return {'case':case,'status':'PASS','grows':actual['grows'],'wire_bytes':len(reference_wire) if reference_wire is not None else None,
                'wire_error':reference_error,'graph_sha256':sha256(actual['graph']).hexdigest()}
    def close(self):
        self.graph.close();self.log.close();self.readback();self.pinfile('source-after.json')

def shape(graph):
    h=struct.unpack_from('<8Q',graph)
    assert h[0]==MAGIC(b'HIAGRF01') and h[6]==len(graph)
    nodes=[struct.unpack_from('<8Q',graph,64+64*i) for i in range(h[2])]
    edges=64+64*h[2]
    def value(identifier):
        kind,at,size,edge,arity,identity,aux,reserved=nodes[identifier-1]
        assert reserved==0
        if kind in (0,1):return(kind,aux)
        if kind in (2,3,4,9):return(kind,aux,graph[at:at+size])
        ids=[struct.unpack_from('<Q',graph,edges+(edge+i)*8)[0] for i in range(arity*(2 if kind==6 else 1))]
        return(kind,tuple(value(i) for i in ids))
    return value(h[3])

