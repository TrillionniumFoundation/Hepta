"""Native issued general JSON arena to GraphLease, with no hosted materializer.

The two inputs are an actually issued HIADATA1 arena and its immutable original
wire. This private bridge does not authenticate arbitrary supplied memory.
"""
from __future__ import annotations
import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_program import verify_program
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools.generate_hia_agent_binary64 import source_program as float_source

CONSTANTS = {
    'ARENA': int.from_bytes(b'HIADATA1', 'little'),
    'COMMAND': int.from_bytes(b'HIAGAC01', 'little'),
    'STATE': int.from_bytes(b'HIAGAW01', 'little'),
    'EVENT': int.from_bytes(b'HIAGAE01', 'little'),
    'GRAPH': int.from_bytes(b'HIAGRF01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1,
    'FLOAT_BASE': 8192,
}
_STATE = ('MAGIC PHASE BAD LEASE SEQ RAW ARENA DIGITS FLAGS COUNT BASE NODES KEYS '
          'EDGES POOL_BOUND NEED GRAPH EDGE_BASE POOL_BASE USED EDGE_CURSOR '
          'KEY_MAP OWNED RESULT ERROR ERROR_INDEX ERROR_VALUE HASH HASH_SLOTS').split()
CONSTANTS.update({'S_' + name: 128 + index * 8 for index, name in enumerate(_STATE)})

BODY = r'''
def arena_graph(a:readbuf, c:readbuf, w:mutbuf) -> u32:
    if length(w) < 512:
        return BAD
    if get(w, S_BAD) != 0 or get(w, S_PHASE) >= 90:
        return BAD
    if length(c) < 64 or word(c, 0) != COMMAND or word(c, 8) == 0 or word(c, 16) == 0:
        return invalid(w, 1)
    if word(c, 24) != length(c) - 64 or word(c, 32) != length(a):
        return invalid(w, 2)
    if word(c, 48) > 1 or word(c, 56) != 0:
        return invalid(w, 3)
    if get(w, S_MAGIC) == 0:
        at = 128
        while at < 512:
            if byte(w, at) != 0:
                return invalid(w, 4)
            at = at + 1
        put(w, S_MAGIC, STATE)
        put(w, S_PHASE, 1)
        put(w, S_LEASE, word(c, 8))
        put(w, S_SEQ, word(c, 16))
        put(w, S_RAW, word(c, 24))
        put(w, S_ARENA, length(a))
        put(w, S_DIGITS, word(c, 40))
        put(w, S_FLAGS, word(c, 48))
        copy_bytes(w, c, 384, 0, 64)
        if measure(a, c, w) == 0:
            return invalid(w, 5)
        copy_bytes(w, a, 448, 0, 64)
    else:
        if get(w, S_MAGIC) != STATE or get(w, S_PHASE) != 1:
            return invalid(w, 6)
        if length(a) != get(w, S_ARENA) or length(c) - 64 != get(w, S_RAW):
            return invalid(w, 7)
        at = 0
        while at < 64:
            if byte(c, at) != byte(w, 384 + at) or byte(a, at) != byte(w, 448 + at):
                return invalid(w, 8)
            at = at + 1
    if get(w, S_NEED) > length(w):
        return publish(w, 1)
    fill_range(w, 16384, get(w, S_NEED) - 16384, 0)
    if validate_tree(a, w) == 0:
        return invalid(w, 9)
    if build(a, c, w) == 0:
        if get(w, S_ERROR) != 0:
            put(w, S_PHASE, 99)
            return publish(w, 3)
        return invalid(w, 10)
    base = get(w, S_GRAPH)
    put(w, base, GRAPH)
    put(w, base + 8, get(w, S_LEASE))
    put(w, base + 16, get(w, S_NODES))
    put(w, base + 24, 1)
    put(w, base + 32, get(w, S_EDGES))
    put(w, base + 40, get(w, S_USED))
    put(w, base + 48, get(w, S_POOL_BASE) + get(w, S_USED))
    put(w, S_RESULT, get(w, S_POOL_BASE) + get(w, S_USED))
    put(w, S_PHASE, 90)
    return publish(w, 0)

def publish(w:mutbuf, action:u64) -> u32:
    put(w, 0, EVENT)
    put(w, 8, action)
    put(w, 16, get(w, S_LEASE))
    put(w, 24, get(w, S_SEQ))
    put(w, 32, get(w, S_NEED))
    put(w, 40, get(w, S_GRAPH))
    put(w, 48, get(w, S_RESULT))
    put(w, 56, get(w, S_NODES))
    put(w, 64, get(w, S_ERROR))
    put(w, 72, get(w, S_ERROR_INDEX))
    put(w, 80, get(w, S_ERROR_VALUE))
    put(w, 88, get(w, S_DIGITS))
    put(w, 96, get(w, S_FLAGS))
    put(w, 104, get(w, S_BAD))
    put(w, 112, get(w, S_PHASE))
    put(w, 120, 0)
    return 128

def invalid(w:mutbuf, reason:u64) -> u32:
    put(w, S_BAD, reason)
    put(w, S_PHASE, 99)
    publish(w, 3)
    return BAD

def row(a:readbuf, index:u64, field:u64) -> u64:
    return word(a, 64 + index * 56 + field * 8)

def utf_count(a:readbuf, begin:u64, size:u64) -> u64:
    if begin > length(a) or size > length(a) - begin:
        return MAX
    at = begin
    end = begin + size
    count = 0
    while at < end:
        first = byte(a, at)
        if first < 128:
            at = at + 1
        else:
            width = 0
            value = 0
            minimum = 0
            if first >= 194 and first <= 223:
                width = 2
                value = first & 31
                minimum = 128
            elif first >= 224 and first <= 239:
                width = 3
                value = first & 15
                minimum = 2048
            elif first >= 240 and first <= 244:
                width = 4
                value = first & 7
                minimum = 65536
            else:
                return MAX
            if width > end - at:
                return MAX
            i = 1
            while i < width:
                unit = byte(a, at + i)
                if unit < 128 or unit > 191:
                    return MAX
                value = (value << 6) | (unit & 63)
                i = i + 1
            if value < minimum or value > 1114111 or (value >= 55296 and value <= 57343):
                return MAX
            at = at + width
        count = count + 1
    return count

def add_pool(w:mutbuf, size:u64) -> u64:
    if size > MAX - get(w, S_POOL_BOUND):
        return 0
    put(w, S_POOL_BOUND, get(w, S_POOL_BOUND) + size)
    return 1

def measure_row(a:readbuf, c:readbuf, w:mutbuf, index:u64) -> u64:
    kind = row(a, index, 0)
    parent = row(a, index, 1)
    sibling = row(a, index, 2)
    start = row(a, index, 3)
    size = row(a, index, 4)
    if kind > 7 or (index != 0 and parent >= index):
        return 0
    if sibling != MAX and (sibling <= index or sibling >= get(w, S_COUNT)):
        return 0
    if kind == 5 or kind == 6:
        if size > get(w, S_COUNT):
            return 0
        if kind == 6 and size > get(w, S_HASH_SLOTS):
            put(w, S_HASH_SLOTS, size)
    elif kind == 4:
        if start < get(w, S_BASE) or utf_count(a, start, size) == MAX or add_pool(w, size) == 0:
            return 0
    elif kind == 3 or kind == 7:
        if start > get(w, S_RAW) or size == 0 or size > get(w, S_RAW) - start:
            return 0
        if add_pool(w, choose(kind == 3, size, 8)) == 0:
            return 0
    if index != 0 and row(a, parent, 0) == 6:
        start = row(a, index, 5)
        size = row(a, index, 6)
        if start < get(w, S_BASE) or utf_count(a, start, size) == MAX or add_pool(w, size) == 0:
            return 0
        put(w, S_KEYS, get(w, S_KEYS) + 1)
    elif row(a, index, 5) != 0 or row(a, index, 6) != 0:
        return 0
    return 1

def measure(a:readbuf, c:readbuf, w:mutbuf) -> u64:
    if length(a) < 120 or word(a, 0) != ARENA:
        return 0
    count = word(a, 8)
    if count == 0 or count > 1048576 or count > (length(a) - 64) // 56:
        return 0
    base = 64 + count * 56
    if word(a, 16) != base or word(a, 24) != length(a) or word(a, 32) != length(a):
        return 0
    if word(a, 40) != get(w, S_RAW) or word(a, 48) != 1 or word(a, 56) != 0:
        return 0
    if row(a, 0, 1) != MAX or row(a, 0, 2) != MAX:
        return 0
    put(w, S_COUNT, count)
    put(w, S_BASE, base)
    i = 0
    while i < count:
        if measure_row(a, c, w, i) == 0:
            return 0
        i = i + 1
    nodes = count + get(w, S_KEYS)
    put(w, S_NODES, nodes)
    put(w, S_EDGES, nodes - 1)
    put(w, S_OWNED, 16384)
    put(w, S_KEY_MAP, (16384 + count + 7) & 18446744073709551608)
    slots = 2
    while slots < get(w, S_HASH_SLOTS) * 2:
        slots = slots * 2
    put(w, S_HASH_SLOTS, slots)
    put(w, S_HASH, get(w, S_KEY_MAP) + count * 8)
    put(w, S_GRAPH, get(w, S_HASH) + slots * 8)
    put(w, S_EDGE_BASE, 64 + nodes * 64)
    put(w, S_POOL_BASE, get(w, S_EDGE_BASE) + (nodes - 1) * 8)
    if get(w, S_POOL_BOUND) > MAX - get(w, S_POOL_BASE) - get(w, S_GRAPH):
        return 0
    put(w, S_NEED, get(w, S_GRAPH) + get(w, S_POOL_BASE) + get(w, S_POOL_BOUND))
    return 1

def key_equal(a:readbuf, left:u64, right:u64) -> u64:
    size = row(a, left, 6)
    if size != row(a, right, 6):
        return 0
    x = row(a, left, 5)
    y = row(a, right, 5)
    i = 0
    while i < size:
        if byte(a, x + i) != byte(a, y + i):
            return 0
        i = i + 1
    return 1

def add_key(a:readbuf, w:mutbuf, child:u64) -> u64:
    hash_ = 14695981039346656037
    i = 0
    while i < row(a, child, 6):
        hash_ = (hash_ ^ byte(a, row(a, child, 5) + i)) * 1099511628211
        i = i + 1
    index = hash_ & (get(w, S_HASH_SLOTS) - 1)
    tried = 0
    while tried < get(w, S_HASH_SLOTS):
        at = get(w, S_HASH) + index * 8
        other = get(w, at)
        if other == 0:
            put(w, at, child + 1)
            return 1
        if key_equal(a, child, other - 1) != 0:
            return 0
        index = (index + 1) & (get(w, S_HASH_SLOTS) - 1)
        tried = tried + 1
    return 0

def validate_tree(a:readbuf, w:mutbuf) -> u64:
    store(w, get(w, S_OWNED), 1)
    i = 0
    while i < get(w, S_COUNT):
        kind = row(a, i, 0)
        if kind == 5 or kind == 6:
            if kind == 6:
                fill_range(w, get(w, S_HASH), get(w, S_HASH_SLOTS) * 8, 0)
            child = row(a, i, 3)
            left = row(a, i, 4)
            while left != 0:
                if child <= i or child >= get(w, S_COUNT) or row(a, child, 1) != i:
                    return 0
                if byte(w, get(w, S_OWNED) + child) != 0:
                    return 0
                store(w, get(w, S_OWNED) + child, 1)
                if kind == 6 and add_key(a, w, child) == 0:
                    return 0
                child = row(a, child, 2)
                left = left - 1
            if child != MAX:
                return 0
        i = i + 1
    i = 0
    while i < get(w, S_COUNT):
        if byte(w, get(w, S_OWNED) + i) != 1:
            return 0
        i = i + 1
    return 1

def string_node(a:readbuf, w:mutbuf, source:u64, size:u64, target:u64) -> u64:
    begin = get(w, S_POOL_BASE) + get(w, S_USED)
    put(w, target, 4)
    put(w, target + 8, begin)
    put(w, target + 16, size)
    put(w, target + 48, utf_count(a, source, size))
    copy_bytes(w, a, get(w, S_GRAPH) + begin, source, size)
    put(w, S_USED, get(w, S_USED) + size)
    return 1

def integer_node(c:readbuf, w:mutbuf, source:u64, size:u64, target:u64, index:u64) -> u64:
    sign = 0
    i = 0
    if byte(c, source) == 45:
        sign = 1
        i = 1
    if i == size:
        return 0
    digits = size - i
    if byte(c, source + i) == 48 and digits != 1:
        return 0
    if get(w, S_DIGITS) != 0 and digits > get(w, S_DIGITS):
        put(w, S_ERROR, 1)
        put(w, S_ERROR_INDEX, index)
        put(w, S_ERROR_VALUE, digits)
        return 0
    begin = get(w, S_POOL_BASE) + get(w, S_USED)
    base = get(w, S_GRAPH) + begin
    put(w, target, 2)
    put(w, target + 8, begin)
    used = 0
    while i < size:
        digit = byte(c, source + i)
        if digit < 48 or digit > 57:
            return 0
        carry = digit - 48
        j = 0
        while j < used:
            value = byte(w, base + j) * 10 + carry
            store(w, base + j, value & 255)
            carry = value >> 8
            j = j + 1
        if carry != 0:
            store(w, base + used, carry)
            used = used + 1
        i = i + 1
    put(w, target + 16, used)
    if used != 0:
        put(w, target + 48, sign)
    put(w, S_USED, get(w, S_USED) + used)
    return 1

def float_node(c:readbuf, w:mutbuf, source:u64, size:u64, target:u64, index:u64) -> u64:
    found = 0
    i = 0
    while i < size:
        unit = byte(c, source + i)
        if unit == 46 or unit == 69 or unit == 101:
            found = 1
        i = i + 1
    if found == 0:
        return 0
    begin = get(w, S_POOL_BASE) + get(w, S_USED)
    status = fp_convert(c, source, size, w, get(w, S_GRAPH) + begin)
    if status == 4294967292:
        if get(w, S_FLAGS) == 1:
            put(w, S_ERROR, 2)
            put(w, S_ERROR_INDEX, index)
            return 0
        value = 9218868437227405312
        if byte(c, source) == 45:
            value = value | 9223372036854775808
        put(w, get(w, S_GRAPH) + begin, value)
    elif status != 8:
        return 0
    put(w, target, 3)
    put(w, target + 8, begin)
    put(w, target + 16, 8)
    put(w, S_USED, get(w, S_USED) + 8)
    return 1

def value_node(a:readbuf, c:readbuf, w:mutbuf, index:u64) -> u64:
    target = get(w, S_GRAPH) + 64 + index * 64
    kind = row(a, index, 0)
    if kind < 3:
        if kind != 0:
            put(w, target, 1)
            put(w, target + 48, kind - 1)
        return 1
    start = row(a, index, 3)
    size = row(a, index, 4)
    if kind == 3:
        return integer_node(c, w, 64 + start, size, target, index)
    if kind == 7:
        return float_node(c, w, 64 + start, size, target, index)
    if kind == 4:
        return string_node(a, w, start, size, target)
    put(w, target, kind)
    put(w, target + 24, get(w, S_EDGE_CURSOR))
    put(w, target + 32, size)
    put(w, target + 40, index + 1)
    put(w, S_EDGE_CURSOR, get(w, S_EDGE_CURSOR) + choose(kind == 6, size * 2, size))
    return 1

def build_edges(a:readbuf, w:mutbuf, index:u64) -> u64:
    kind = row(a, index, 0)
    if kind != 5 and kind != 6:
        return 1
    graph = get(w, S_GRAPH)
    at = graph + get(w, S_EDGE_BASE) + get(w, graph + 64 + index * 64 + 24) * 8
    child = row(a, index, 3)
    count = row(a, index, 4)
    i = 0
    while i < count:
        if kind == 6:
            put(w, at, get(w, get(w, S_KEY_MAP) + child * 8))
            at = at + 8
        put(w, at, child + 1)
        at = at + 8
        child = row(a, child, 2)
        i = i + 1
    return 1

def build(a:readbuf, c:readbuf, w:mutbuf) -> u64:
    key = get(w, S_COUNT)
    i = 0
    while i < get(w, S_COUNT):
        if value_node(a, c, w, i) == 0:
            return 0
        if i != 0 and row(a, row(a, i, 1), 0) == 6:
            target = get(w, S_GRAPH) + 64 + key * 64
            string_node(a, w, row(a, i, 5), row(a, i, 6), target)
            put(w, get(w, S_KEY_MAP) + i * 8, key + 1)
            key = key + 1
        i = i + 1
    if key != get(w, S_NODES) or get(w, S_EDGE_CURSOR) != get(w, S_EDGES):
        return 0
    i = 0
    while i < get(w, S_COUNT):
        build_edges(a, w, i)
        i = i + 1
    return 1

def word(a:readbuf, at:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(a, at + i) << (i * 8))
        i = i + 1
    return value

def get(w:mutbuf, at:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(w, at + i) << (i * 8))
        i = i + 1
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(w, at + i, value & 255)
        value = value >> 8
        i = i + 1
    return 0
'''


def floating_functions():
    nodes = ast.parse(float_source()).body
    names = {node.name for node in nodes}

    class Relocate(ast.NodeTransformer):
        def visit_FunctionDef(self, node):
            if node.name == 'convert':
                node.body = [item for item in node.body if not
                             (isinstance(item, ast.If) and any(
                                 isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                                 and n.func.id == 'length' and n.args[0].id in ('o', 'w')
                                 for n in ast.walk(item.test)))]
                node.args.args = [ast.arg(arg=name, annotation=ast.Name(id=kind, ctx=ast.Load()))
                                  for name, kind in [('s', 'readbuf'), ('source', 'u64'),
                                                     ('size', 'u64'), ('w', 'mutbuf'),
                                                     ('target', 'u64')]]
            node = self.generic_visit(node)
            node.name = 'fp_' + node.name
            return node

        def visit_Call(self, node):
            node = self.generic_visit(node)
            if isinstance(node.func, ast.Name):
                name = node.func.id
                if name == 'length' and node.args[0].id == 's':
                    return ast.Name(id='size', ctx=ast.Load())
                if name == 'byte' and node.args[0].id == 's':
                    node.args[1] = ast.BinOp(left=ast.Name(id='source', ctx=ast.Load()),
                                           op=ast.Add(), right=node.args[1])
                if name in ('byte', 'store') and node.args[0].id == 'w':
                    node.args[1] = ast.BinOp(left=ast.Name(id='FLOAT_BASE', ctx=ast.Load()),
                                           op=ast.Add(), right=node.args[1])
                if name == 'put' and node.args[0].id == 'o':
                    return ast.Call(func=ast.Name(id='put', ctx=ast.Load()),
                                    args=[ast.Name(id='w', ctx=ast.Load()),
                                          ast.Name(id='target', ctx=ast.Load()), node.args[2]],
                                    keywords=[])
                if name in names:
                    node.func.id = 'fp_' + name
            return node
    return [Relocate().visit(node) for node in nodes]


def document():
    nodes = ast.parse(BODY).body + floating_functions()

    class Constants(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node) if node.id in CONSTANTS else node
    nodes = [Constants().visit(node) for node in nodes]
    names = {node.name: 'f' + str(index + 1) for index, node in enumerate(nodes)}
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'},
              {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'],
                  'effects': ['read', 'write', 'trap'], 'entry': 'b0', 'blocks': [{
                      'id': 'b0', 'params': params, 'ops': [
                          {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
                          {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}],
                           'attrs': {'function': names['arena_graph']}},
                          {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}],
                      'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    result = compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'arena_graph',
                                   'functions': functions})
    fs = result['functions']
    limits = (len(fs), sum(len(f['blocks']) for f in fs),
              sum(len(b['ops']) for f in fs for b in f['blocks']),
              max(len(f['blocks']) for f in fs),
              max(len(b['params']) for f in fs for b in f['blocks']))
    if any(actual > maximum for actual, maximum in zip(limits, (128, 1536, 8192, 256, 16))):
        raise ValueError({'original_compiler_limits_exceeded': limits})
    verify_program(result)
    return result


def main():
    doc = document()
    path = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap/arena_graph.hiaasm'
    raw = render_assembly(doc)
    path.write_text(raw)
    fs = doc['functions']
    print(len(raw.encode()), len(fs), sum(len(f['blocks']) for f in fs),
          sum(len(b['ops']) for f in fs for b in f['blocks']),
          max(len(f['blocks']) for f in fs), max(len(b['params']) for f in fs for b in f['blocks']))


if __name__ == '__main__':
    main()
