"""New reconstructed row-owner development tests, with a whole-SQL oracle.

The HIA owner decides every predicate, projection, constraint and write. The
test peer only implements generic scalar/cursor/log primitives. It is not a
native store, a production fallback, or a qualification result.
"""
from __future__ import annotations

import copy
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sqlite3
import struct
import unittest

from hepta.hia_agent_assembly import assemble_program, render_assembly
from hepta.hia_program_runtime import _Machine, _Owner, _View

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANRW01', 'little')
BAD = 0xfffffffd
MASK = (1 << 64) - 1
CANARY = bytes(range(160, 192))
ABI = json.loads((ROOT / 'docs/HIA_AGENT_NAMESPACE_STORE_ABI.json').read_bytes())
TABLES = {r['id']: r for r in ABI['tables']}
OPS = {r['id']: r for r in ABI['relational_operations']}


def typed(value):
    if value is None:
        return ['null']
    if isinstance(value, bytes):
        return ['blob', value.hex()]
    if isinstance(value, str):
        return ['text', value]
    if isinstance(value, int):
        return ['integer', str(value)]
    if isinstance(value, float):
        return ['real', struct.pack('<d', value).hex()]
    if isinstance(value, dict):
        return {str(k): typed(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [typed(v) for v in value]
    raise TypeError(type(value))


def signed(value):
    return value if value < 1 << 63 else value - (1 << 64)


def init_frame(operation, binds=1, view=2, generation=1):
    return struct.pack('<16Q', MAGIC, 1, 0xabc, 0xdef, generation,
                       0, 0, 0, operation, binds, view, 0, 0, 0, 0, 0)


def ack_frame(out, status=0, first=0, second=0, third=0):
    return struct.pack('<16Q', MAGIC, 2, *out[2:5], out[5], out[8],
                       status, first & MASK, second & MASK, third & MASK,
                       0, 0, 0, 0, 0)


def seeded_database():
    db = sqlite3.connect(':memory:', isolation_level=None)
    for table in TABLES.values():
        db.execute(table['ddl'])
    seed = {
        1: [('a0', 's0', 'u0', 'kind', '{}', 'k0'),
            ('a1', 's1', 'u1', 'kind', '{}', 'k1')],
        2: [('p0', 's0', '{}'), ('p0', 's1', '{"v":1}'), ('p1', 's0', '{}')],
        3: [('c0', 's0', '{}', str(10**90 + 7), 0),
            ('c1', 's1', '{}', '100', 5), ('c2', 's2', '{}', '200', 2)],
        4: [('r0', 'd0', 'tool', 'running', None, '100'),
            ('r1', 'd1', 'tool', 'completed', '{}', '200')],
        5: [(1, None, 'tool', 'q0', '3', 'ok', '{}'),
            (3, 'c0', 'tool', 'q1', '4', 'ok', '{}'),
            (7, 'c1', 'tool', 'q2', '5', 'ok', '{}')],
        6: [('cu0', 'a0', 's0', 0), ('cu1', 'a1', 's1', 256)],
        7: [('s0', 'c0', '0', '3', 'abi0'), ('s1', 'c1', '12', '12', 'abi1')],
        8: [('s0', '0', '{}'), ('s0', '2', '{}'), ('s0', '10', '{}'), ('s1', '0', '{}')],
        9: [('l0', 's0', '0', '{}', 1), ('l1', 's0', '0', '{}', 0),
            ('l2', 's0', '2', '{}', 1), ('l3', 's1', '0', '{}', 1)],
        10: [('c0', '123', None), ('c1', '10', 'busy'), ('c2', str(10**100), 'owner')],
    }
    for table, rows in seed.items():
        width = len(TABLES[table]['columns'])
        db.executemany('INSERT INTO ' + TABLES[table]['name'] + ' VALUES (' + ','.join('?'*width) + ')', rows)
    db.execute("UPDATE sqlite_sequence SET seq=12 WHERE name='costs'")
    return db


def database_state(db):
    rows = {i: {r[0]: tuple(r[1:]) for r in db.execute(
        'SELECT rowid,* FROM ' + t['name'] + ' ORDER BY rowid')}
        for i, t in TABLES.items()}
    high = db.execute("SELECT seq FROM sqlite_sequence WHERE name='costs'").fetchone()
    return rows, None if high is None else high[0]


class GenericReferencePeers:
    """Mechanical test peers. No catalog WHERE, constraint or assignment code."""

    def __init__(self, rows, high_water, binds, generation=1):
        self.rows = copy.deepcopy(rows)
        self.high_water = high_water
        self.objects = {1: ('vector', tuple(binds)), 2: ('view', generation)}
        self.next_handle = 3
        self.scalar = sqlite3.connect(':memory:', isolation_level=None)
        self.scalar.execute('CREATE TABLE numeric_value (v NUMERIC)')
        self.scalar.execute('CREATE TABLE text_value (v TEXT)')
        self.actions = []
        self.cleanups = []
        self.inject = None

    def close(self):
        self.scalar.close()

    def make(self, kind, value):
        handle = self.next_handle
        self.next_handle += 1
        self.objects[handle] = (kind, value)
        return handle

    def get(self, handle, kind):
        actual_kind, value = self.objects[handle]
        if actual_kind != kind:
            raise AssertionError((handle, actual_kind, kind))
        return value

    def normalize(self, value, affinity):
        table = {1: 'numeric_value', 2: 'text_value'}[affinity]
        self.scalar.execute('DELETE FROM ' + table)
        self.scalar.execute('INSERT INTO ' + table + ' VALUES (?)', (value,))
        return self.scalar.execute('SELECT v FROM ' + table).fetchone()[0]

    def compare(self, left, right):
        equal, less, greater = self.scalar.execute('SELECT ? = ?, ? < ?, ? > ?',
                                                  (left, right, left, right, left, right)).fetchone()
        return 1 if equal else 0 if less else 2 if greater else 3

    def cursor_rows(self, table, order):
        rows = list(sorted(self.rows[table].items()))
        if order == 1:
            return rows
        if order != 2:
            raise AssertionError(order)
        # This is a generic primary index, not the operation's WHERE clause.
        columns = [c['ordinal'] for c in sorted(TABLES[table]['columns'],
                   key=lambda c: c['primary_key_position']) if c['primary_key_position']]
        def key(value):
            if value is None:
                return (0, 0)
            if isinstance(value, (int, float)):
                return (1, value)
            if isinstance(value, str):
                return (2, value.encode('utf-8'))
            return (3, value)
        rows.sort(key=lambda pair: tuple(key(pair[1][c]) for c in columns) + ((4, pair[0]),))
        return rows

    def reply(self, out):
        action, args = out[8], out[9:15]
        self.actions.append((out[5], action, tuple(args)))
        if self.inject is not None:
            result = self.inject(self, out)
            if result is not None:
                return result
        a, b, c, d, e, f = args
        if action == 1:
            self.get(a, 'view')
            return (0, self.make('mark', (copy.deepcopy(self.rows), self.high_water)), 0, 0)
        if action == 2:
            return (0, self.make('vector', (self.normalize(self.get(a, 'vector')[b], c),)), 0, 0)
        if action == 3:
            return (0, self.make('builder', []), 0, 0)
        if action == 4:
            self.get(a, 'view')
            return (0, self.make('cursor', iter(self.cursor_rows(b, c))), 0, 0)
        if action == 5:
            try:
                rowid, row = next(self.get(a, 'cursor'))
            except StopIteration:
                return (3, 0, 0, 0)
            return (0, self.make('vector', row), rowid & MASK, len(row))
        if action == 6:
            return (0, self.compare(self.get(a, 'vector')[b], self.get(c, 'vector')[d]), 0, 0)
        if action == 7:
            value = self.get(a, 'vector')[b]
            kind = 0 if value is None else 1 if isinstance(value, int) else 2 if isinstance(value, float) else 3 if isinstance(value, str) else 4
            return (0, kind, 0, 0)
        if action == 8:
            return (0, self.make('vector', (None,) * a), 0, 0)
        if action == 9:
            row = list(self.get(a, 'vector'))
            row[b] = self.normalize(self.get(c, 'vector')[0], d)
            return (0, self.make('vector', tuple(row)), 0, 0)
        if action == 10:
            value = (None, 0, 1, '0', 'completed', b)[a]
            return (0, self.make('vector', (value,)), 0, 0)
        if action == 11:
            value = self.scalar.execute('SELECT ? + 1', (self.get(a, 'vector')[b],)).fetchone()[0]
            return (0, self.make('vector', (value,)), 0, 0)
        if action == 12:
            self.get(a, 'view')
            largest = max(self.rows[b], default=0)
            next_rowid = max(largest, self.high_water or 0) + 1 if c else largest + 1
            if next_rowid > (1 << 63) - 1:
                # Original AUTOINCREMENT exhaustion. Non-cost random fallback
                # is not exercised by this peer and is not claimed complete.
                if c:
                    return (1, sqlite3.SQLITE_FULL, 0, 0)
                raise AssertionError('non-cost randomized allocator requires its native peer test')
            return (0, next_rowid & MASK, self.make('vector', (next_rowid,)), 0)
        if action == 13:
            self.get(a, 'view')
            rowid = signed(c)
            self.rows[b][rowid] = self.get(d, 'vector')
            if e:
                self.high_water = max(self.high_water or 0, rowid)
            return (0, 0, 0, 0)
        if action == 14:
            builder = self.get(a, 'builder')
            row = self.get(b, 'vector')
            builder.append(tuple(value for i, value in enumerate(row) if c & (1 << i)))
            return (0, a, 0, 0)
        if action == 15:
            return (0, self.make('result', {'rows': tuple(self.get(a, 'builder')), 'changes': b, 'matches': c}), 0, 0)
        if action == 16:
            self.get(b, 'view')
            self.rows, self.high_water = copy.deepcopy(self.get(a, 'mark'))
            return (0, 0, 0, 0)
        if action == 17:
            kept = self.objects[a]
            if kept[0] != 'result':
                raise AssertionError(kept)
            self.cleanups.append((a, b, c))
            self.objects = {a: kept}
            return (0, 0, 0, 0)
        if action == 18:
            return (0, self.make('result', {'error_code': a, 'operation': b, 'table': c, 'detail': d}), 0, 0)
        raise AssertionError(('unknown action', action))


NORMAL = {
    1: ('k0',), 2: ('a2', 's2', 'u2', 'kind', '{}', 'k2'),
    3: ('a0',), 4: ('u1',), 5: ('p2', 's2', '{}'), 6: ('p0', 's1'),
    7: ('r0',), 8: ('r2', 'd2', 'tool', 'running', None, '300'),
    9: ('{"answer":1}', 'r0'), 10: ('c0', 'tool2', 'q3', '123', 'ok', '{}'),
    11: ('c0',), 12: ('c0', 1), 13: ('c0',), 14: ('cu1',),
    15: ('cu2', 'a2', 's2', 512), 16: ('c3', 's3', '{}', str(10**99)),
    17: ('c3',), 18: ('c0',), 19: ('c2',), 20: ('owner2', 'c0'),
    21: (str(10**101 + 3), 'c1', 'busy'), 22: ('s0',), 23: ('s0', '2'),
    24: ('s0',), 25: ('s2', 'c2', '0', '0', 'abi2'),
    26: ('s0', '20', '{}'), 27: ('s0',), 28: ('2', '4', 'c2', 's0'),
    29: ('l4', 's0', '2', '{}'), 30: ('l2',), 31: ('l0',),
}


class NamespaceRowsSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'examples/hia_bootstrap/agent_namespace_rows.hiaasm').read_bytes()
        cls.program = assemble_program(cls.raw)
        cls.entry = cls.program.as_dict()['functions'][0]
        cls.entries = 0
        cls.cases = 0
        cls.ledger = None
        directory = os.environ.get('HIA_NAMESPACE_ROWS_LEDGER')
        if directory:
            cls.evidence = Path(directory)
            cls.evidence.mkdir(parents=True, exist_ok=False)
            cls.ledger = gzip.open(cls.evidence / 'invocations.jsonl.gz', 'xt', encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        if cls.ledger is not None:
            cls.ledger.close()
            (cls.evidence / 'counts.json').write_text(json.dumps({
                'scope': 'NEW RECONSTRUCTED CORE VM ROW OWNER; GENERIC REFERENCE PEERS',
                'source_sha256': hashlib.sha256(cls.raw).hexdigest(),
                'entries': cls.entries, 'whole_operation_cases': cls.cases,
            }, sort_keys=True, indent=2) + '\n')

    def log(self, row):
        if self.ledger is not None:
            self.ledger.write(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n')
            self.ledger.flush()

    def invoke(self, raw, work, output_size=192):
        original, before = bytes(raw), bytes(work)
        owners = [_Owner(-1, bytearray(raw)), _Owner(-2, bytearray(output_size) + CANARY), _Owner(-3, work)]
        machine = _Machine(self.program, 500000, 8 << 20, None, 64)
        code = machine.invoke(self.entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
        type(self).entries += 1
        self.assertEqual(bytes(owners[0].data), original)
        self.assertEqual(bytes(owners[1].data[output_size:]), CANARY)
        if len(work) == 1056:
            self.assertEqual(bytes(work[1024:]), CANARY)
        output = bytes(owners[1].data[:output_size])
        self.log({'test': self.id(), 'entry': type(self).entries, 'input_hex': original.hex(),
                  'workspace_before_hex': before.hex(), 'workspace_after_hex': bytes(work).hex(),
                  'output_hex': output.hex(), 'code': code})
        return code, struct.unpack('<24Q', output) if output_size == 192 else output

    def operation(self, operation, binds, peer):
        work = bytearray(1024) + CANARY
        raw = init_frame(operation)
        for _ in range(2000000):
            code, out = self.invoke(raw, work)
            self.assertEqual(code, out[1])
            if code != 1:
                self.assertIn(code, (0, 2), (out, peer.actions[-5:]))
                self.assertEqual(len(peer.cleanups), 1)
                self.assertEqual(set(peer.objects), {out[15]})
                self.assertEqual(peer.cleanups[0][1], 1)
                self.assertEqual(peer.cleanups[0][2] + 1, out[5])
                return code, out, peer.get(out[15], 'result'), work
            raw = ack_frame(out, *peer.reply(out))
        self.fail('test supervisor did not observe completion')

    def compare_operation(self, operation, binds, mutate=None, peer_mutate=None):
        self.assertEqual(len(binds), OPS[operation]['bind_count'])
        db = seeded_database()
        peer = None
        try:
            if mutate:
                mutate(db)
            initial = database_state(db)
            peer = GenericReferencePeers(*initial, binds)
            if peer_mutate:
                peer_mutate(peer)
            error = None
            try:
                cursor = db.execute(OPS[operation]['sql_reference'], binds)
                rows, changes = tuple(cursor.fetchall()), max(0, cursor.rowcount)
            except sqlite3.Error as exc:
                error = {'code': exc.sqlite_errorcode, 'name': exc.sqlite_errorname, 'message': str(exc)}
                rows, changes = (), 0
            final = database_state(db)
            code, out, result, work = self.operation(operation, binds, peer)
            self.log({'test': self.id(), 'case': type(self).cases, 'operation': operation,
                      'binds': typed(binds), 'initial': typed(initial), 'expected_state': typed(final),
                      'actual_state': typed((peer.rows, peer.high_water)), 'expected_rows': typed(rows),
                      'actual_result': typed(result), 'error': error, 'changes': changes,
                      'peer_actions': typed(peer.actions), 'cleanup': typed(peer.cleanups)})
            type(self).cases += 1
            self.assertEqual(typed((peer.rows, peer.high_water)), typed(final), operation)
            self.assertEqual(out[16], changes, operation)
            if error is None:
                self.assertEqual(code, 0, (operation, result))
                self.assertEqual(typed(result['rows']), typed(rows), operation)
                self.assertEqual(result['changes'], changes, operation)
            else:
                self.assertEqual(code, 2, (operation, error, result))
                self.assertEqual(result['error_code'], error['code'], (operation, error, result))
                self.assertEqual((result['operation'], result['table']), (operation, OPS[operation]['table_id']))
                if error['code'] == sqlite3.SQLITE_CONSTRAINT_NOTNULL:
                    expected_column = error['message'].split(': ', 1)[1].split('.')[-1]
                    self.assertEqual(TABLES[result['table']]['columns'][result['detail']]['name'], expected_column)
            return peer.actions
        finally:
            if peer is not None:
                peer.close()
            db.close()

    def test_all_31_operations_against_whole_sql_and_complete_database(self):
        self.assertEqual(set(NORMAL), set(OPS))
        for operation, binds in NORMAL.items():
            with self.subTest(operation=operation):
                self.compare_operation(operation, binds)

    def test_missing_null_and_zero_changed_paths_still_cleanup(self):
        cases = [(i, tuple(None for _ in range(OPS[i]['bind_count']))) for i in
                 (1, 3, 4, 6, 7, 11, 13, 14, 18, 19, 22, 23, 24, 27, 30)]
        cases += [(9, ('response', 'missing')), (12, ('c1', 5)), (12, ('missing', 100)),
                  (20, ('owner', 'missing')), (21, ('4', 'c1', 'wrong')),
                  (21, ('4', 'c0', None)), (28, ('1', '1', 'c0', 'missing')),
                  (31, ('missing',)), (31, ('l1',))]
        for operation, binds in cases:
            with self.subTest(operation=operation, binds=binds):
                actions = self.compare_operation(operation, binds)
                self.assertEqual(actions[-1][1], 17)

    def test_ignore_constraints_and_original_extended_errors(self):
        cases = [
            (2, ('a0', 's2', 'new-uri', 'kind', '{}', 'new-key')),
            (2, ('new-id', 's2', 'u1', 'kind', '{}', 'k0')),
            (2, ('new-id', None, 'new-uri', 'kind', '{}', 'new-key')),
            (5, ('p0', 's0', '{}')), (5, (None, 's0', '{}')),
            (15, ('cu0', 'a0', 's0', 100)), (15, ('cu2', None, 's2', 0)),
            (8, ('r0', 'd2', 'tool', 'running', None, '3')),
            (8, ('r2', None, 'tool', 'running', None, '3')),
            (16, ('c0', 's2', '{}', '3')), (16, ('c3', None, None, '3')),
            (17, ('c0',)), (25, ('s0', 'c0', '0', '0', 'abi')),
            (25, ('s2', None, None, None, None)), (26, ('s0', '0', '{}')),
            (26, ('s2', None, '{}')), (29, ('l0', 's0', '0', '{}')),
            (29, ('l5', None, '0', '{}')), (28, (None, None, None, 's0')),
            (21, (None, 'c1', 'busy')),
            (8, (None, 'd', 'tool', 'running', None, '4')),
        ]
        for operation, binds in cases:
            with self.subTest(operation=operation, binds=binds):
                self.compare_operation(operation, binds)

    def test_storage_classes_affinity_decimal_text_and_numeric_addition(self):
        cases = [(9, (b'\xff\0response', 'r0')), (20, (b'\x00owner', 'c0')),
                 (21, (str(10**500 + 7), 'c1', 'busy')),
                 (28, (str(10**400 + 3), 3.5, b'context', 's0')),
                 (15, ('cu2', 42, 3.5, '00042')),
                 (15, ('cu2', 'a2', 's2', '4.5e0')),
                 (15, ('cu2', 'a2', 's2', b'42')),
                 (12, ('c0', '1.0')), (12, ('c0', 'not numeric')),
                 (10, (None, 7, 3.5, str(10**400), b'ok', b'\xff'))]
        for operation, binds in cases:
            with self.subTest(operation=operation, binds=binds):
                self.compare_operation(operation, binds)
        for value in (0.5, '7.5', 'bad', b'2', (1 << 63)-1):
            with self.subTest(attempts=value):
                self.compare_operation(12, ('c0', 'zzz'),
                    lambda db, value=value: db.execute('UPDATE contexts SET attempts=? WHERE id=?', (value, 'c0')))
        self.compare_operation(10, NORMAL[10],
            lambda db: db.execute("UPDATE sqlite_sequence SET seq=1000 WHERE name='costs'"))
        self.compare_operation(10, NORMAL[10],
            lambda db: db.execute("UPDATE sqlite_sequence SET seq=9223372036854775807 WHERE name='costs'"))

    def test_fixed_seed_mixed_binds(self):
        rng = random.Random(0x524f575331)
        pool = [None, 0, -7, 1.25, '0', '001', '1e2', '', 'missing', b'\x00\xff']
        for case in range(64):
            operation = rng.randrange(1, 32)
            binds = list(NORMAL[operation])
            if binds:
                binds[rng.randrange(len(binds))] = rng.choice(pool)
            with self.subTest(case=case, operation=operation, binds=binds):
                self.compare_operation(operation, tuple(binds))

    def test_statement_error_rolls_back_pending_write_before_owned_result(self):
        db = seeded_database()
        initial = database_state(db)
        peer = GenericReferencePeers(*initial, NORMAL[10])
        try:
            def inject(peer, out):
                if out[8] != 13:
                    return None
                _, table, rowid, row, high, _ = out[9:15]
                peer.rows[table][signed(rowid)] = peer.get(row, 'vector')
                if high:
                    peer.high_water = signed(rowid)
                return (1, sqlite3.SQLITE_FULL, 123, 0)
            peer.inject = inject
            code, out, result, _ = self.operation(10, NORMAL[10], peer)
            self.assertEqual((code, result['error_code'], result['detail']), (2, sqlite3.SQLITE_FULL, 123))
            self.assertEqual(typed((peer.rows, peer.high_water)), typed(initial))
            self.assertEqual(out[16], 0)
            self.assertEqual([action for _, action, _ in peer.actions][-3:], [16, 18, 17])
        finally:
            peer.close()
            db.close()

    def test_protocol_identity_sequence_shape_and_persistent_poison(self):
        for word, value in [(0, 0), (1, 1), (2, 0x100), (3, 0x100), (4, 2),
                            (5, 0), (6, 9), (7, 4), (10, 1), (11, 1)]:
            with self.subTest(word=word, value=value):
                work = bytearray(1024) + CANARY
                code, out = self.invoke(init_frame(1), work)
                self.assertEqual(code, 1)
                raw = bytearray(ack_frame(out, 0, 3, 0, 0))
                struct.pack_into('<Q', raw, word*8, value)
                code, bad = self.invoke(raw, work)
                self.assertEqual(code, BAD)
                frozen = bytes(work)
                self.assertEqual(self.invoke(ack_frame(out, 0, 3), work)[0], BAD)
                self.assertEqual(bytes(work), frozen)
                self.assertEqual(self.invoke(init_frame(1, generation=2), work)[0], BAD)
                self.assertEqual(bytes(work), frozen)
        for offset, value in [(40, 32), (48, 9), (152, 1), (160, 8), (168, 9), (352, 30)]:
            with self.subTest(private_workspace_offset=offset):
                work = bytearray(1024) + CANARY
                _, out = self.invoke(init_frame(1), work)
                struct.pack_into('<Q', work, offset, value)
                self.assertEqual(self.invoke(ack_frame(out, 0, 3), work)[0], BAD)
        work = bytearray(1024) + CANARY
        _, out = self.invoke(init_frame(1), work)
        self.assertEqual(self.invoke(ack_frame(out, 3), work)[0], BAD)


if __name__ == '__main__':
    unittest.main()
