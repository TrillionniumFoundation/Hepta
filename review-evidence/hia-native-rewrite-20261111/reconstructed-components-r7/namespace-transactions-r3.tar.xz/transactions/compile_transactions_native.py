"""Actual new transaction compile using the qualified immutable local 0ef B3.

No new cold qualification is inferred. The original 10 CPU / 20 wall /
256 MiB / 1 MiB output+workspace compiler gates are unchanged.
"""
from pathlib import Path
from hashlib import sha256
import json
import sys
import traceback

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEVELOPMENT = BASE/'namespace-reconstruction/transactions-reconstructed-r3'
OUT = DEVELOPMENT/'local-native-r2/compile'
COLD = Path('/workspace/scratch/9acdfa9f5639/hia-v67-0ef-qualification-local-01')
QUALIFIED_SOURCE = Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-workflow-qualified')
COMPILER = COLD/'cold.cold/qualification.evidence/B3.image.bin'
COMPILER_SHA = '35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
sys.path.insert(0, str(QUALIFIED_SOURCE))
from tools.qualify_hia_selfhost import compile_stage, CHILD

digest = lambda b: sha256(b).hexdigest()
vm = json.loads((DEVELOPMENT/'local-vm-r2/result.json').read_bytes())
assert vm['passed'] and vm['tests']==vm['loaded_tests']==11
assert not any(vm[k] for k in ('errors','failures','skips','expected_failures','unexpected_successes'))
expected = json.loads((DEVELOPMENT/'local-vm-r2/source-before.json').read_bytes())
assert expected == json.loads((DEVELOPMENT/'local-vm-r2/source-after.json').read_bytes())
OUT.mkdir(parents=True, exist_ok=False)
pins = {}
for row in expected:
    p = SOURCE/row['path']; raw = p.read_bytes()
    assert len(raw)==row['bytes'] and digest(raw)==row['sha256'] and p.stat().st_mode & 0o777 == row['mode']
    pins[str(p)] = digest(raw)
    q = OUT/'source'/row['path']; q.parent.mkdir(parents=True,exist_ok=True)
    q.write_bytes(raw); q.chmod(row['mode'])
wrapper_raw = (COLD/'cold.json').read_bytes()
assert digest(wrapper_raw)=='c3b4b66e01ddf14f15ab62260591b6ecdee27941affe1355e487f594a90745ea'
wrapper = json.loads(wrapper_raw)
assert len(wrapper['checks'])==11 and all(wrapper['checks'].values())
assert wrapper['generation_sha256']==[COMPILER_SHA]*3
assert wrapper['wall_elapsed_ns']==134765704630 and wrapper['qualification_wall_limit_seconds']==180
assert digest(Path(wrapper['nested_report']).read_bytes())==wrapper['nested_report_sha256']=='78b3f4abae59088e6a709b4991f0e1dd1ef8e6e9d3ec4f124cfaf21639561598'
receipt_raw = (COMPILER.parent/'B3.receipt.json').read_bytes()
assert digest(receipt_raw)=='24f3dfe375a79df29c9ca44159676bb5c95020a84c1dad7dce6d8a3b4e71e237'
prior = json.loads(receipt_raw)
compiler_raw = COMPILER.read_bytes()
assert len(compiler_raw)==prior['produced_bytes']==669556
assert digest(compiler_raw)==prior['produced_sha256']==prior['image_sha256']==prior['artifact_sha256']==COMPILER_SHA
assert prior['source_unchanged'] and not prior['forbidden_compiler_modules_loaded']
assert digest(CHILD.read_bytes())==prior['runner_sha256']=='1d298396e97b6d362bcd51121eff1d2f411305133fadb1c974477b2dd9052c29'
compiler_input = (COMPILER.parent/'B3.input.bin').read_bytes()
assert len(compiler_input)==prior['input_bytes'] and digest(compiler_input)==prior['source_sha256']==prior['input_sha256']
(OUT/'compiler.image.bin').write_bytes(compiler_raw)
(OUT/'compiler.input.original.bin').write_bytes(compiler_input)
(OUT/'compiler.receipt.original.json').write_bytes(receipt_raw)
(OUT/'compiler.cold.original.json').write_bytes(wrapper_raw)
(OUT/'compiler-child.original.py').write_bytes(CHILD.read_bytes())
for p in (COMPILER, COMPILER.parent/'B3.receipt.json', COLD/'cold.json', CHILD,
          QUALIFIED_SOURCE/'tools/qualify_hia_selfhost.py', Path(__file__).resolve()):
    pins[str(p)] = digest(p.read_bytes())
source = (SOURCE/'examples/hia_bootstrap/agent_namespace_transactions.hiaasm').read_bytes()
result = {'scope':'DEVELOPMENT ONLY transaction reconstruction r3 source-r2; exact local 0ef qualified B3; no new cold or installed-store claim',
          'before':pins,'compiler_sha256':COMPILER_SHA,'source_sha256':digest(source)}
try:
    image, receipt = compile_stage(OUT, 'agent-namespace-transactions', OUT/'compiler.image.bin', source)
    raw = image.read_bytes()
    assert receipt['input_sha256']==receipt['source_sha256']==digest(source)
    assert receipt['artifact_sha256']==receipt['image_sha256']==COMPILER_SHA
    assert receipt['produced_sha256']==digest(raw)
    assert receipt['produced_bytes']==receipt['core_u32']==len(raw)
    assert receipt['limits']['cpu_seconds']==10 and receipt['limits']['address_bytes']==256<<20
    assert receipt['limits']['output_capacity']==receipt['limits']['workspace_bytes']==1<<20
    assert receipt['source_unchanged'] and not receipt['forbidden_compiler_modules_loaded']
    output = (OUT/'agent-namespace-transactions.output.bin').read_bytes()
    assert output[:len(raw)]==raw and digest(output)==receipt['output_sha256']
    manifest = {'schema':'hepta.hia.agent-namespace-transactions-native-development.v1',
                'source_sha256':digest(source),'image_path':image.name,
                'image_sha256':digest(raw),'compiler_sha256':COMPILER_SHA}
    (OUT/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    result.update(status='PASS',receipt=receipt,manifest=manifest)
except BaseException as exc:
    traceback.print_exc()
    result.update(status='FAIL',exception_type=type(exc).__name__,error=str(exc))
finally:
    result['after'] = {path:digest(Path(path).read_bytes()) for path in pins}
    result['source_and_compiler_unchanged'] = result['after']==pins
    if not result['source_and_compiler_unchanged']:
        result['status'] = 'FAIL'
    payload = (json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
    (OUT/'summary.json').write_bytes(payload)
    print(json.dumps({'status':result['status'],'summary':str(OUT/'summary.json'),
                     'bytes':len(payload),'sha256':digest(payload)},sort_keys=True),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
