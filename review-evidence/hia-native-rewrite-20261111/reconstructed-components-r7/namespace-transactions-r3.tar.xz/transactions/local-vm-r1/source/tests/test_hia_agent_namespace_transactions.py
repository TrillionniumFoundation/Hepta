"""Transaction-owner development corpus; physical/row peers are references.

The independent observable oracle executes the original SQLite operations and
transaction commands. Simulated filesystem events test continuation order, not
physical durability or installed-store qualification.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import struct
import unittest

from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from tests.test_hia_agent_namespace_rows import ABI, NORMAL, OPS, database_state, seeded_database, typed

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANTX03', 'little')
BAD = 0xfffffffd
MAX = (1 << 64) - 1
CANARY = bytes(range(128, 160))


def frame(command, call, *args, session=(0x1122, 0x3344)):
    return struct.pack('<20Q', MAGIC, command, *session, call, 0, 0, 0,
                       *args, *([0] * (12 - len(args))))


def ack(out, status=0, *args):
    return struct.pack('<20Q', MAGIC, 7, out[2], out[3], out[4], out[5], out[8], status,
                       *args, *([0] * (12 - len(args))))


def copy_database(source):
    target = sqlite3.connect(':memory:', isolation_level=None)
    source.backup(target)
    return target


class PhysicalReference:
    """Reference objects, no transaction/rollback/commit decision callbacks."""

    def __init__(self):
        self.committed = seeded_database()
        self.objects = {1: ('root', None)}
        self.next_id = 2
        self.locked = 0
        self.events = []
        self.retired = []
        self.closed = []
        self.inject = None
        self.publish_count = 0

    def close(self):
        seen = {id(self.committed)}
        self.committed.close()
        for kind, value in self.objects.values():
            if kind in ('view', 'pending') and id(value) not in seen:
                value.close(); seen.add(id(value))

    def make(self, kind, value):
        handle = self.next_id; self.next_id += 1
        self.objects[handle] = (kind, value)
        return handle

    def get(self, handle, *kinds):
        kind, value = self.objects[handle]
        if kind not in kinds:
            raise AssertionError((handle, kind, kinds))
        return value

    def remove(self, handle):
        if not handle:
            return
        kind, value = self.objects.pop(handle)
        if kind in ('view', 'pending'):
            value.close()
        self.retired.append((handle, kind))

    def respond(self, out):
        self.events.append({'call': out[4], 'sequence': out[5], 'action': out[8],
                            'arguments': list(out[9:15]), 'frame': list(out)})
        if self.inject is not None:
            supplied = self.inject(self, out)
            if supplied is not None:
                return supplied
        return self.perform(out)

    def perform(self, out):
        action, args = out[8], out[9:15]
        a, b, c, d, e, f = args
        if action == 1:
            self.get(a, 'root')
            return (0, self.make('namespace', None))
        if action == 2:
            self.get(a, 'namespace')
            if b != 10_000_000_000:
                raise AssertionError(b)
            if self.locked:
                return (1, sqlite3.SQLITE_BUSY, 0)
            self.locked = self.make('lock', out[2:4])
            return (0, self.locked)
        if action == 3:
            self.get(a, 'namespace')
            if b:
                self.get(b, 'lock')
            return (0, self.make('view', copy_database(self.committed)),
                    self.make('head', self.publish_count))
        if action == 4:
            view = self.get(a, 'view'); self.get(b, 'lock')
            return (0, self.make('pending', copy_database(view)))
        if action == 5:
            values = self.get(b, 'binds')
            database = self.get(c, 'view', 'pending')
            try:
                cursor = database.execute(OPS[a]['sql_reference'], values)
                rows = tuple(cursor.fetchall()); changes = max(0, cursor.rowcount)
                result = {'rows': typed(rows), 'changes': changes}
                return (0, self.make('result', result), changes, max(changes, len(rows)))
            except sqlite3.Error as exc:
                result = {'code': exc.sqlite_errorcode, 'name': exc.sqlite_errorname,
                          'message': str(exc)}
                return (1, exc.sqlite_errorcode, 0, self.make('result', result))
        if action == 6:
            self.get(a, 'pending'); self.get(b, 'view'); self.get(c, 'lock')
            return (0, self.make('prepared', a))
        if action == 7:
            self.get(a, 'prepared')
            return (0,)
        if action == 8:
            pending = self.get(self.get(a, 'prepared'), 'pending')
            self.get(b, 'view'); self.get(c, 'lock')
            old = self.committed; self.committed = copy_database(pending); old.close()
            self.publish_count += 1
            return (0, self.make('published', self.publish_count))
        if action == 9:
            self.get(a, 'published'); self.get(b, 'namespace')
            return (0,)
        if action == 10:
            if a == 1:
                self.get(b, 'view'); self.get(c, 'pending'); self.remove(d)
            elif a == 2:
                if c or d:
                    raise AssertionError(args)
                self.remove(b)
            elif a == 3:
                self.remove(d); self.remove(c); self.remove(b)
            else:
                raise AssertionError(a)
            if e:
                self.get(e, 'result')
            return (0,)
        if action == 11:
            self.get(a, 'lock')
            if a != self.locked:
                raise AssertionError((a, self.locked))
            self.remove(a); self.locked = 0
            return (0,)
        if action == 12:
            self.get(a, 'namespace'); self.remove(a); self.closed.append(a)
            return (0,)
        if action == 13:
            self.get(a, 'pending'); self.get(b, 'view'); self.get(c, 'lock')
            return (0,)
        raise AssertionError(('action', action))


class Session:
    def __init__(self, test, physical=None, session=(0x1122, 0x3344)):
        self.test = test
        self.physical = physical or PhysicalReference()
        self.work = bytearray(512) + CANARY
        self.call = 0
        self.session = session
        self.final = None
        self.pending = None

    def start(self, command, *args):
        self.call += 1
        code, out = self.test.invoke(frame(command, self.call, *args, session=self.session), self.work)
        self.pending = out if code == 1 else None
        return code, out

    def run(self, command, *args):
        code, out = self.start(command, *args)
        for _ in range(32):
            if code != 1:
                self.pending = None; self.final = out
                return code, out
            supplied = self.physical.respond(out)
            code, out = self.test.invoke(ack(out, *supplied), self.work)
            self.pending = out if code == 1 else None
        raise AssertionError('test supervisor observed no terminal frame')

    def execute(self, operation, values):
        return self.run(3, operation, self.physical.make('binds', tuple(values)))


class NamespaceTransactionsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'examples/hia_bootstrap/agent_namespace_transactions.hiaasm').read_bytes()
        cls.program = assemble_program(cls.raw)
        cls.entry = cls.program.as_dict()['functions'][0]
        cls.entries = 0; cls.calls = 0; cls.ledger = None
        directory = os.environ.get('HIA_NAMESPACE_TRANSACTIONS_LEDGER')
        if directory:
            cls.evidence = Path(directory)
            cls.evidence.mkdir(parents=True, exist_ok=False)
            cls.ledger = gzip.open(cls.evidence / 'invocations.jsonl.gz', 'xt', encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        if cls.ledger is not None:
            cls.ledger.close()
            (cls.evidence / 'counts.json').write_text(json.dumps({
                'scope': 'Transaction Core VM only; row/physical peers are test references',
                'entries': cls.entries, 'public_calls_compared': cls.calls,
                'sqlite_version': sqlite3.sqlite_version,
                'source_sha256': hashlib.sha256(cls.raw).hexdigest()}, sort_keys=True, indent=2)+'\n')

    def log(self, event):
        if self.ledger is not None:
            self.ledger.write(json.dumps(event, sort_keys=True, separators=(',', ':'))+'\n')
            self.ledger.flush()

    def invoke(self, raw, work, output_size=256):
        original, before = bytes(raw), bytes(work)
        owners = [_Owner(-1, bytearray(raw)), _Owner(-2, bytearray(output_size)+CANARY), _Owner(-3, work)]
        machine = _Machine(self.program, 500000, 8 << 20, None, 64)
        code = machine.invoke(self.entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
        type(self).entries += 1
        self.assertEqual(bytes(owners[0].data), original)
        self.assertEqual(bytes(owners[1].data[output_size:]), CANARY)
        if len(work) == 544:
            self.assertEqual(bytes(work[512:]), CANARY)
        output = bytes(owners[1].data[:output_size])
        self.log({'test': self.id(), 'entry': type(self).entries, 'input_hex': original.hex(),
                  'workspace_before_hex': before.hex(), 'workspace_after_hex': bytes(work).hex(),
                  'output_hex': output.hex(), 'code': code})
        return code, struct.unpack('<32Q', output) if output_size == 256 else output

    def new(self, physical=None, session=(0x1122, 0x3344)):
        result = Session(self, physical, session)
        self.assertEqual(result.run(1, 1)[0], 0)
        self.addCleanup(result.physical.close)
        return result

    def compare(self, session, oracle, command, operation=None, values=()):
        error = None; expected_rows = (); expected_changes = 0
        try:
            if command == 3:
                cursor = oracle.execute(OPS[operation]['sql_reference'], values)
                expected_rows = tuple(cursor.fetchall()); expected_changes = max(0, cursor.rowcount)
            else:
                oracle.execute({2: 'BEGIN IMMEDIATE', 4: 'COMMIT', 5: 'ROLLBACK'}[command])
        except sqlite3.Error as exc:
            error = {'code': exc.sqlite_errorcode, 'name': exc.sqlite_errorname, 'message': str(exc)}
        code, out = session.execute(operation, values) if command == 3 else session.run(command)
        actual = session.physical.get(out[15], 'result') if out[15] else None
        self.log({'test': self.id(), 'case': type(self).calls, 'command': command,
                  'operation': operation, 'values': typed(values), 'expected_error': error,
                  'expected_rows': typed(expected_rows), 'expected_changes': expected_changes,
                  'actual_result': actual, 'final': list(out),
                  'expected_transaction': oracle.in_transaction,
                  'oracle_state': typed(database_state(oracle)),
                  'committed_state': typed(database_state(session.physical.committed))})
        type(self).calls += 1
        self.assertEqual(code, 2 if error else 0, (command, operation, error, out))
        self.assertEqual(out[20] == 1, oracle.in_transaction, (command, operation, error, out))
        if error:
            self.assertEqual(out[18], error['code'])
            if command == 3:
                self.assertEqual(actual['code'], error['code'])
                self.assertEqual(actual['message'], error['message'])
        elif command == 3:
            self.assertEqual(actual, {'rows': typed(expected_rows), 'changes': expected_changes})
            self.assertEqual(out[16], expected_changes)
        view = session.physical.get(out[23], 'pending') if oracle.in_transaction else session.physical.committed
        self.assertEqual(typed(database_state(view)), typed(database_state(oracle)))
        return code, out

    def test_all_31_autocommit_operations_match_whole_sql(self):
        for operation, values in NORMAL.items():
            with self.subTest(operation=operation):
                s = self.new(); oracle = seeded_database(); self.addCleanup(oracle.close)
                self.compare(s, oracle, 3, operation, values)
                actions = [e['action'] for e in s.physical.events if e['call'] == s.call]
                self.assertEqual(2 in actions, OPS[operation]['kind'] != 'SELECT')
                self.assertEqual(s.final[20], 0)
                self.assertEqual((s.final[21], s.final[22], s.final[23], s.final[29]), (0, 0, 0, 0))

    def test_explicit_history_nested_begin_constraints_commit_rollback(self):
        s = self.new(); oracle = seeded_database(); self.addCleanup(oracle.close)
        for command, operation, values in [
            (4, None, ()), (5, None, ()), (2, None, ()),
            (3, 16, NORMAL[16]), (3, 11, ('c3',)), (2, None, ()),
            (3, 16, NORMAL[16]), (3, 17, ('c3',)), (4, None, ()),
            (2, None, ()), (3, 20, ('held', 'c0')), (3, 19, ('c0',)),
            (5, None, ()), (3, 19, ('c0',)), (4, None, ())]:
            self.compare(s, oracle, command, operation, values)
        # Each row acknowledgment inside the explicit transaction finished
        # without issuing prepare/publish before the explicit COMMIT call.
        for event in s.physical.events:
            if event['action'] in (6, 7, 8, 9):
                self.assertEqual(event['frame'][6], 4)

    def test_clean_commit_retirement_and_fresh_read_generations(self):
        s = self.new()
        self.assertEqual(s.run(2)[0], 0)
        original_view, original_pending, original_lock = s.final[22], s.final[23], s.final[29]
        self.assertEqual(s.execute(2, ('a0', 'other', 'uri', 'kind', '{}', 'new'))[0], 0)
        kept = s.final[15]
        self.assertEqual(s.final[16], 0)
        self.assertEqual(s.run(4)[0], 0)
        actions = [e['action'] for e in s.physical.events if e['call'] == s.call]
        self.assertEqual(actions, [13, 10, 11])
        for old in (original_view, original_pending, original_lock):
            self.assertNotIn(old, s.physical.objects)
        self.assertEqual(s.physical.get(kept, 'result')['changes'], 0)
        self.assertEqual(s.physical.publish_count, 0)
        snapshots, generations = [], []
        for _ in range(3):
            self.assertEqual(s.execute(11, ('c0',))[0], 0)
            events = [e for e in s.physical.events if e['call'] == s.call]
            self.assertEqual([e['action'] for e in events], [3, 5, 10])
            generations.append(events[1]['arguments'][3]); snapshots.append(events[1]['arguments'][2])
        self.assertEqual(len(set(generations)), 3); self.assertEqual(len(set(snapshots)), 3)

    def test_full_autoincrement_rolls_back_previous_statement(self):
        s = self.new(); oracle = seeded_database(); self.addCleanup(oracle.close)
        for db in (s.physical.committed, oracle):
            db.execute("UPDATE sqlite_sequence SET seq=9223372036854775807 WHERE name='costs'")
        self.compare(s, oracle, 2)
        self.compare(s, oracle, 3, 20, ('not-committed', 'c0'))
        self.compare(s, oracle, 3, 10, NORMAL[10])
        self.assertFalse(oracle.in_transaction)
        self.compare(s, oracle, 5)

    def test_busy_commit_preserves_pending_and_explicit_retry(self):
        for fail_action in (6, 7, 8):
            with self.subTest(action=fail_action):
                s = self.new(); self.assertEqual(s.run(2)[0], 0)
                self.assertEqual(s.execute(20, ('busy-then-commit', 'c0'))[0], 0)
                old = s.final[21:24]
                s.physical.inject = lambda peer, out: (1, sqlite3.SQLITE_BUSY, 0) if out[8] == fail_action else None
                self.assertEqual(s.run(4)[0], 2)
                self.assertEqual(s.final[18], sqlite3.SQLITE_BUSY)
                self.assertEqual(s.final[20], 1); self.assertEqual(s.final[21:24], old)
                self.assertEqual(s.final[30], 0)
                row_calls = sum(e['action'] == 5 for e in s.physical.events)
                s.physical.inject = None
                self.assertEqual(s.run(4)[0], 0)
                self.assertEqual(row_calls, sum(e['action'] == 5 for e in s.physical.events))
                self.assertEqual(s.physical.committed.execute("SELECT owner FROM execution_budgets WHERE context_id='c0'").fetchone()[0], 'busy-then-commit')

    def test_unknown_publication_and_postpublication_errors_never_retry(self):
        for point, published in ((6, False), (8, False), (8, True), (9, True), (10, True), (11, True)):
            with self.subTest(action=point, published=published):
                s = self.new(); self.assertEqual(s.run(2)[0], 0)
                self.assertEqual(s.execute(20, ('uncertain', 'c0'))[0], 0)
                def inject(peer, out):
                    if out[8] != point:
                        return None
                    if point == 8 and published:
                        peer.perform(out)
                    return (2,)
                s.physical.inject = inject
                code, final = s.run(4)
                self.assertEqual(code, BAD)
                self.assertEqual(final[24], 3)
                self.assertEqual(s.physical.publish_count > 0, published)
                self.assertEqual(self.invoke(frame(4, s.call + 1), s.work)[0], BAD)
                self.assertEqual(self.invoke(frame(5, s.call + 1), s.work)[0], BAD)
        s = self.new(); self.assertEqual(s.run(2)[0], 0)
        self.assertEqual(s.execute(20, ('root-sync-failed', 'c0'))[0], 0)
        s.physical.inject = lambda peer, out: (1, sqlite3.SQLITE_IOERR_FSYNC, 99) if out[8] == 9 else None
        self.assertEqual(s.run(4)[0], BAD)
        self.assertEqual((s.final[18], s.final[25]), (sqlite3.SQLITE_IOERR_FSYNC, 2))

    def test_two_connections_read_committed_and_writer_busy(self):
        p = PhysicalReference(); self.addCleanup(p.close)
        a = Session(self, p, (1, 2)); b = Session(self, p, (3, 4))
        self.assertEqual(a.run(1, 1)[0], 0); self.assertEqual(b.run(1, 1)[0], 0)
        self.assertEqual(a.run(2)[0], 0)
        self.assertEqual(a.execute(20, ('not-visible-yet', 'c0'))[0], 0)
        self.assertEqual(b.run(2)[0], 2); self.assertEqual(b.final[18], sqlite3.SQLITE_BUSY)
        self.assertEqual(b.execute(19, ('c0',))[0], 0)
        first = p.get(b.final[15], 'result')
        self.assertEqual(first['rows'][0][2], ['null'])
        self.assertEqual(a.run(4)[0], 0)
        self.assertEqual(b.execute(19, ('c0',))[0], 0)
        self.assertEqual(p.get(b.final[15], 'result')['rows'][0][2], ['text', 'not-visible-yet'])
        self.assertEqual(first['rows'][0][2], ['null'])

    def test_close_rolls_back_and_repeated_close_is_not_new_open(self):
        s = self.new(); self.assertEqual(s.run(2)[0], 0)
        self.assertEqual(s.execute(20, ('discard-on-close', 'c0'))[0], 0)
        self.assertEqual(s.run(6)[0], 0)
        self.assertEqual(s.final[24], 2); self.assertEqual(s.physical.locked, 0)
        self.assertIsNone(s.physical.committed.execute("SELECT owner FROM execution_budgets WHERE context_id='c0'").fetchone()[0])
        self.assertEqual(s.run(6)[0], 0)
        self.assertEqual(len(s.physical.closed), 1)
        self.assertEqual(s.execute(19, ('c0',))[0], 2)
        self.assertEqual((s.final[18], s.final[19]), (0, 4))

    def test_protocol_mutations_poison_permanently(self):
        mutations = [lambda b: b[:-1], lambda b: b+b'\0']
        for index in (0, 1, 2, 3, 4, 5, 6, 7, 16, 17, 18, 19):
            mutations.append(lambda b, i=index: b[:i*8]+struct.pack('<Q',struct.unpack_from('<Q',b,i*8)[0]^1)+b[i*8+8:])
        for mutate in mutations:
            s = Session(self); self.addCleanup(s.physical.close)
            code, out = s.start(1, 1); self.assertEqual(code, 1)
            raw = ack(out, 0, 100)
            self.assertEqual(self.invoke(mutate(raw), s.work)[0], BAD)
            self.assertEqual(self.invoke(raw, s.work)[0], BAD)
        s = self.new(); code, out = s.start(2); self.assertEqual(code, 1)
        self.assertEqual(self.invoke(frame(3, s.call + 1, 11, 100), s.work)[0], BAD)
        self.assertEqual(self.invoke(ack(out, 0, 100), s.work)[0], BAD)

    def test_fatal_error_policy_and_short_buffers_counters(self):
        for operation in (11, 20):
            for code in (7, 10, 13, 9, 1299):
                s = self.new(); self.assertEqual(s.run(2)[0], 0)
                self.assertEqual(s.execute(20, ('earlier', 'c0'))[0], 0)
                error_result = s.physical.make('result', {'code': code})
                s.physical.inject = lambda peer, out, c=code, r=error_result: (1, c, 0, r) if out[8] == 5 else None
                self.assertEqual(s.execute(operation, NORMAL[operation])[0], 2)
                should_abort = code in (7, 10, 13) or code == 9 and OPS[operation]['kind'] != 'SELECT'
                self.assertEqual(s.final[20] == 0, should_abort)
        for size in (0, 8, 511):
            work = bytearray(size)
            self.assertEqual(self.invoke(frame(1, 1, 1), work)[0], BAD)
        for size in (0, 8, 224):
            work = bytearray(512)+CANARY
            self.assertEqual(self.invoke(frame(1, 1, 1), work, output_size=size)[0], BAD)
            self.assertEqual(self.invoke(frame(1, 1, 1), work)[0], BAD)
        for at in (32, 40):
            s = self.new(); struct.pack_into('<Q', s.work, at, MAX)
            self.assertEqual(self.invoke(frame(2, 2), s.work)[0], BAD)


if __name__ == '__main__':
    unittest.main()
