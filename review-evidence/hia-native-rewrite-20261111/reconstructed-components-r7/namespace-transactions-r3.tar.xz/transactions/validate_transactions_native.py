"""Actual retained-B3 image paired with every frozen Core VM invocation."""
from pathlib import Path
from hashlib import sha256
import ctypes
import gzip
import json
import os
import resource
import struct
import sys
import time
import unittest

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEVELOPMENT = BASE/'namespace-reconstruction/transactions-reconstructed-r3'
COMPILE = DEVELOPMENT/'local-native-r2/compile'
OUT = COMPILE.parent/'paired-validation'
OUT.mkdir(exist_ok=False)
os.environ['HIA_NAMESPACE_TRANSACTIONS_LEDGER'] = str(OUT/'vm-entries')
sys.path.insert(0,str(SOURCE))
from tests.test_hia_agent_namespace_transactions import NamespaceTransactionsTests, CANARY
from hepta.hia_json_preflight_native import NativeHiaJsonImage

digest = lambda raw:sha256(raw).hexdigest()
pins = {}
for row in json.loads((DEVELOPMENT/'local-vm-r2/source-before.json').read_bytes()):
    path = SOURCE/row['path']
    raw = path.read_bytes()
    assert len(raw)==row['bytes'] and digest(raw)==row['sha256'] and path.stat().st_mode&0o777==row['mode']
    pins[str(path)]=digest(raw)
manifest = json.loads((COMPILE/'manifest.json').read_bytes())
assert manifest['source_sha256']==pins[str(SOURCE/'examples/hia_bootstrap/agent_namespace_transactions.hiaasm')]
image_path=COMPILE/manifest['image_path']
for path in (COMPILE/'manifest.json',COMPILE/'summary.json',image_path,
             SOURCE/'hepta/hia_json_preflight_native.py',SOURCE/'hepta/hia_program_runtime.py',Path(__file__).resolve()):
    pins[str(path)]=digest(path.read_bytes())
assert json.loads((COMPILE/'summary.json').read_bytes())['status']=='PASS'
image_raw=image_path.read_bytes()
assert digest(image_raw)==manifest['image_sha256']
image=NativeHiaJsonImage(image_raw,manifest['image_sha256'])
assert image.image_sha256==manifest['image_sha256']
resource.setrlimit(resource.RLIMIT_AS,(1024<<20,1024<<20))
resource.setrlimit(resource.RLIMIT_CPU,(300,300))
ledger=gzip.open(OUT/'native-invocations.jsonl.gz','wt',encoding='utf-8')
contexts={}
counters={'actual_native_entries':0,'full_entry_bytes_equal':0,'persistent_workspaces':0,'explicit_private_workspace_mutations':0}


class PairedNativeTests(NamespaceTransactionsTests):
    def invoke(self,raw,work,output_size=256):
        before=bytes(work)
        key=id(work)
        mutation=None
        if key not in contexts:
            buf=ctypes.create_string_buffer(before,max(1,len(before)))
            contexts[key]=(work,buf,len(contexts)+1)
            counters['persistent_workspaces']+=1
        else:
            held,buf,_=contexts[key]
            self.assertIs(held,work)
            previous=bytes(buf[:len(work)])
            if previous!=before:
                mutation={'before_hex':previous.hex(),'after_hex':before.hex(),
                          'scope':'explicit private workspace control from frozen test, not external authentication'}
                counters['explicit_private_workspace_mutations']+=1
                ctypes.memmove(buf,before,len(before))
        _,buf,serial=contexts[key]
        expected_code,expected_header=super().invoke(raw,work,output_size)
        expected_work=bytes(work)
        initial=bytes(output_size)+CANARY
        output=ctypes.create_string_buffer(initial,max(1,len(initial)))
        original=bytes(raw)
        source=ctypes.create_string_buffer(original+CANARY,len(original)+len(CANARY))
        started=time.monotonic_ns()
        code=image._entry(source,len(original),output,output_size,buf,len(before))
        elapsed=time.monotonic_ns()-started
        counters['actual_native_entries']+=1
        actual_output=bytes(output[:len(initial)])
        actual_work=bytes(buf[:len(before)])
        expected_output=(struct.pack('<32Q',*expected_header) if output_size==256 else expected_header)+CANARY
        row={'entry':counters['actual_native_entries'],'test_id':self.id(),'workspace_id':serial,
             'input_hex':original.hex(),'pre_workspace_hex':before.hex(),'private_mutation':mutation,
             'expected_return':expected_code,'actual_return':code,
             'expected_output_hex':expected_output.hex(),'actual_output_hex':actual_output.hex(),
             'expected_workspace_hex':expected_work.hex(),'actual_workspace_hex':actual_work.hex(),
             'output_descriptor_bytes':output_size,'input_and_canary_unchanged':bytes(source[:len(original)+len(CANARY)])==original+CANARY,
             'native_elapsed_ns':elapsed}
        ledger.write(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n')
        ledger.flush()
        self.assertEqual(code,expected_code)
        self.assertEqual(actual_output,expected_output)
        self.assertEqual(actual_work,expected_work)
        self.assertTrue(row['input_and_canary_unchanged'])
        counters['full_entry_bytes_equal']+=1
        return expected_code,expected_header


started=time.monotonic_ns()
suite=unittest.defaultTestLoader.loadTestsFromTestCase(PairedNativeTests)
ids=[test.id() for test in suite]
result=unittest.TextTestRunner(verbosity=2).run(suite)
ledger.close()
after={path:digest(Path(path).read_bytes()) for path in pins}
value={'scope':'DEVELOPMENT ONLY actual reconstructed transaction image vs CoreVM; reference row/physical peers; no physical database/installed store or cold qualification',
       'image_sha256':manifest['image_sha256'],'compiler_sha256':manifest['compiler_sha256'],
       'loaded_image_sha256':image.image_sha256,'sqlite_version':__import__('sqlite3').sqlite_version,'pid':os.getpid(),'before':pins,'after':after,
       'source_unchanged':pins==after,'test_ids':ids,'tests_loaded':len(ids),'tests_run':result.testsRun,
       'failures':[(t.id(),s) for t,s in result.failures],'errors':[(t.id(),s) for t,s in result.errors],
       'skipped':[(t.id(),s) for t,s in result.skipped],
       'expected_failures':[(t.id(),s) for t,s in result.expectedFailures],
       'unexpected_successes':[t.id() for t in result.unexpectedSuccesses],
       'paired_vm_entries':PairedNativeTests.entries,'whole_public_calls':PairedNativeTests.calls,
       'counters':counters,'wall_elapsed_ns':time.monotonic_ns()-started,
       'ledger':{'path':str(OUT/'native-invocations.jsonl.gz'),
                 'bytes':(OUT/'native-invocations.jsonl.gz').stat().st_size,
                 'sha256':digest((OUT/'native-invocations.jsonl.gz').read_bytes())}}
passed=(0<result.testsRun==len(ids)==11 and not any(value[k] for k in
    ('failures','errors','skipped','expected_failures','unexpected_successes')) and pins==after
    and counters['actual_native_entries']==counters['full_entry_bytes_equal']==PairedNativeTests.entries==1162
    and PairedNativeTests.calls==50)
value['status']='PASS' if passed else 'FAIL'
raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
(OUT/'result.json').write_bytes(raw)
print(json.dumps({'status':value['status'],'counters':counters,'result_sha256':digest(raw)},sort_keys=True),flush=True)
raise SystemExit(0 if passed else 1)
