"""Development-only original VM ledger; never a cold/full qualification."""
from pathlib import Path
from hashlib import sha256
import contextlib
import json
import os
import shutil
import sqlite3
import sys
import time
import unittest

SOURCE = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
assert not OUT.is_relative_to(SOURCE)
OUT.mkdir(parents=True, exist_ok=False)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['HIA_NAMESPACE_TRANSACTIONS_LEDGER'] = str(OUT/'raw-entries')
sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE))
files = ('docs/HIA_AGENT_NAMESPACE_STORE_ABI.json',
         'docs/HIA_AGENT_NAMESPACE_TRANSACTIONS.md',
         'tools/generate_hia_agent_namespace_store.py',
         'tools/generate_hia_agent_namespace_transactions.py',
         'tools/generate_hia_selfhost.py',
         'examples/hia_bootstrap/agent_namespace_transactions.hiaasm',
         'tests/test_hia_agent_namespace_rows.py',
         'tests/test_hia_agent_namespace_transactions.py',
         'hepta/hia_agent_assembly.py', 'hepta/hia_program_runtime.py')
def state():
    return [{'path': name, 'bytes': (SOURCE/name).stat().st_size,
             'mode': (SOURCE/name).stat().st_mode & 0o777,
             'sha256': sha256((SOURCE/name).read_bytes()).hexdigest()}
            for name in files]
def save(name, value):
    raw = (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    (OUT/name).write_bytes(raw)
    return {'path':str(OUT/name),'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
before = state(); save('source-before.json', before)
for row in before:
    p = OUT/'source'/row['path']; p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE/row['path'], p); p.chmod(row['mode'])
loader = unittest.TestLoader()
suite = loader.loadTestsFromName('tests.test_hia_agent_namespace_transactions')
def ids(node):
    if isinstance(node, unittest.TestSuite):
        return [identity for item in node for identity in ids(item)]
    return [node.id()]
identities = ids(suite)
assert len(identities) == len(set(identities)) == 11 and not loader.errors
save('test-ids.json', identities)
started = time.perf_counter()
with (OUT/'stdout.log').open('w') as stdout, (OUT/'stderr.log').open('w') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
seconds = time.perf_counter()-started
after = state(); save('source-after.json', after)
outcome = {'scope':'NEW RECONSTRUCTED TRANSACTION R3 CORE VM DEVELOPMENT; row/physical reference peers',
           'tests':result.testsRun,'loaded_tests':len(identities),'test_ids':identities,
           'errors':[(t.id(),e)for t,e in result.errors],
           'failures':[(t.id(),e)for t,e in result.failures],
           'skips':[(t.id(),e)for t,e in result.skipped],
           'expected_failures':[(t.id(),e)for t,e in result.expectedFailures],
           'unexpected_successes':[t.id()for t in result.unexpectedSuccesses],
           'seconds':seconds,'sqlite_version':sqlite3.sqlite_version,
           'source_before_after_equal':before==after}
outcome['passed'] = (0<result.testsRun==len(identities) and before==after and not any(
    outcome[k]for k in ('errors','failures','skips','expected_failures','unexpected_successes')))
receipt = save('result.json', outcome)
print(json.dumps({'passed':outcome['passed'],'tests':result.testsRun,'seconds':seconds,**receipt},sort_keys=True),flush=True)
raise SystemExit(0 if outcome['passed'] else 1)
