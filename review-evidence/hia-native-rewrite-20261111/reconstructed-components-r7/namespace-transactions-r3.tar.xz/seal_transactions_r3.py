"""Seal the complete bounded transaction development stage, never qualify it."""
from pathlib import Path
from hashlib import sha256
import io
import json
import os
import stat
import tarfile

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111/namespace-reconstruction')
DEV = BASE/'transactions-reconstructed-r3'
OUT = BASE/'transactions-r3-complete-01'
OUT.mkdir(exist_ok=False)
def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    raw = path.read_bytes(); after = path.lstat()
    signature = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
    assert signature(before)==signature(after) and len(raw)==before.st_size
    return raw,before
def load(path):
    return json.loads(read(path)[0])
vm1 = load(DEV/'local-vm-r1/result.json')
assert vm1['tests']==10 and not vm1['passed'] and len(vm1['failures'])==1 and not vm1['errors']
assert vm1['source_before_after_equal']
assert load(DEV/'private-phase-r1/counterexample.json')['counterexample'] is True
vm2 = load(DEV/'local-vm-r2/result.json')
assert vm2['passed'] and vm2['tests']==vm2['loaded_tests']==11 and vm2['source_before_after_equal']
compiled = load(DEV/'local-native-r2/compile/summary.json')
assert compiled['status']=='PASS' and compiled['source_and_compiler_unchanged'] and compiled['before']==compiled['after']
native = load(DEV/'local-native-r2/paired-validation/result.json')
assert native['status']=='PASS' and native['source_unchanged'] and native['before']==native['after']
assert native['tests_loaded']==native['tests_run']==11 and native['whole_public_calls']==50
assert native['paired_vm_entries']==native['counters']['actual_native_entries']==native['counters']['full_entry_bytes_equal']==1162
for name in ('errors','failures','skipped','expected_failures','unexpected_successes'):
    assert native[name]==[]
assert native['image_sha256']=='c9038bb553bf00ac298795c220f39bb9e51972b8aadbcbf05f59d1138fff4698'
assert native['loaded_image_sha256']==native['image_sha256']
assert compiled['source_sha256']=='50ac1d44e6884d30b2ed6e67e14848b54b18364ddf6b6468f6d6210bfa1ed204'
flags = load(BASE/'sqlite-3.46.1-reference-oracle/statement-flags.json')
assert flags['version']=='3.46.1' and len(flags['operations'])==31
assert all(row['uses_statement_journal']==0 for row in flags['operations'])
paths=[]
for path in sorted(DEV.rglob('*')):
    assert not path.is_symlink()
    if path.is_file():
        assert '__pycache__' not in path.parts
        paths.append(('transactions/'+str(path.relative_to(DEV)),path))
for name in ('source.json','statement_oracle.c','statement-flags.json','statement-oracle'):
    paths.append(('sqlite-3.46.1-reference/'+name,BASE/'sqlite-3.46.1-reference-oracle'/name))
paths.append(('sqlite-3.46.1-reference/sqlite-amalgamation-3460100.zip',BASE/'sqlite-amalgamation-3460100.zip'))
paths.append(('sqlite-3.46.1-reference/vdbeaux.c',BASE/'sqlite-3.46.1-vdbeaux.c'))
paths.append(('seal_transactions_r3.py',Path(__file__).resolve()))
paths.sort()
members=[]
for name,path in paths:
    raw,info=read(path)
    members.append({'name':name,'original':str(path),'bytes':len(raw),'mode':stat.S_IMODE(info.st_mode),
                    'sha256':sha256(raw).hexdigest(),'device':info.st_dev,'inode':info.st_ino,
                    'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns})
custody={'schema':'hia.namespace.transactions.reconstructed-r3.complete-development.v1',
        'scope':'Development transaction state owner only. All physical/value/log peers remain references; no actual durable native database, installed owner, migration or cold/full qualification claim.',
        'source_revision':'r3/source-r2','image_sha256':native['image_sha256'],
        'compiler_sha256':native['compiler_sha256'],
        'r1_original_vm_failure_retained':True,'r1_private_phase_counterexample_retained':True,
        'authoring_modulo_failure_summary_is_not_original_stderr':True,
        'core_vm_tests':11,'actual_native_tests':11,'actual_native_entries':1162,
        'all_native_vm_return_output_workspace_input_equal':1162,
        'whole_sql_and_transaction_calls':50,
        'oracle_versions':{'whole_vm_and_native_sql':native['sqlite_version'],
                           'independent_prepared_statement_flags':flags['version'],
                           'retained_rog_sqlite_whole_transaction_run':'not performed in this checkpoint'},
        'original_files':len(members),'original_bytes':sum(m['bytes']for m in members),
        'members':members}
custody_raw=(json.dumps(custody,sort_keys=True,indent=2)+'\n').encode()
(OUT/'custody.json').write_bytes(custody_raw)
archive=OUT/'namespace-transactions-reconstructed-r3-development.tar.xz'
with tarfile.open(archive,'w:xz',preset=1)as tar:
    for row in members:
        raw,info=read(Path(row['original']))
        assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
        item=tarfile.TarInfo(row['name']);item.size=len(raw);item.mode=row['mode'];item.mtime=0
        tar.addfile(item,io.BytesIO(raw))
    item=tarfile.TarInfo('CUSTODY.json');item.size=len(custody_raw);item.mode=0o600
    tar.addfile(item,io.BytesIO(custody_raw))
with tarfile.open(archive)as tar:
    assert tar.getnames()==[r['name']for r in members]+['CUSTODY.json']
    for row in members:
        item=tar.getmember(row['name']);raw=tar.extractfile(item).read()
        assert item.isfile() and item.mode==row['mode'] and len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
        original,info=read(Path(row['original']))
        assert original==raw and info.st_dev==row['device'] and info.st_ino==row['inode']
        assert info.st_mtime_ns==row['mtime_ns'] and info.st_ctime_ns==row['ctime_ns']
    assert tar.extractfile('CUSTODY.json').read()==custody_raw
raw,_=read(archive)
summary={'status':'ALL_SELECTED_ORIGINAL_MEMBERS_REPLAYED',
         'scope':custody['scope'],'archive':str(archive),'archive_bytes':len(raw),
         'archive_sha256':sha256(raw).hexdigest(),'custody':str(OUT/'custody.json'),
         'custody_bytes':len(custody_raw),'custody_sha256':sha256(custody_raw).hexdigest(),
         'original_members':len(members),'archive_members':len(members)+1,
         'original_raw_bytes':sum(m['bytes']for m in members),
         'original_bytes_modes_inode_mtime_ctime_unchanged':True}
(OUT/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
