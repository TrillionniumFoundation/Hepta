"""Native ordered overlap checks and complete batch-query Graph construction.

The fixed coordinator calls PREFIX after each actual native single query, before
starting the next one. FINAL constructs the complete batch only after all such
checks; the original complete bounded JSON gate still follows. Sources are
immutable admitted native queries, not externally authenticated by this header.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg, total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_apply_graph as apply

CONSTANTS = {'COMMAND': int.from_bytes(b'HIAQBC01','little'),
             'STATE': int.from_bytes(b'HIAQBW01','little'),
             'EVENT': int.from_bytes(b'HIAQBE01','little'),
             'GRAPH': int.from_bytes(b'HIAGRF01','little'), 'BAD':0xfffffffd,'MAX':(1<<64)-1}
LITERALS = ('schema','base_sha256','input_sha256','selector','function','block','context','operation_index',
            'sites','site','query','application','scope','hepta.hia.edit-query.v2','hepta.hia.edit-query.v3',
            'hepta.hia.edit-batch-query.v2','hepta.hia.edit-batch-query.v3')
SOURCE = r'''
def batch_graph(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) == 2:
        return refuse(w, 1)
    if length(r) < 136 or word(r, 0) != COMMAND or word(r, 16) == 0 or word(r, 24) == 0:
        return refuse(w, 2)
    if word(r, 40) > 1 or word(r, 48) == 0 or word(r, 48) > 16 or length(r) != 128 + word(r, 48) * 8:
        return refuse(w, 3)
    if graph_shape(s, 0, length(s)) == 0:
        return refuse(w, 4)
    i = 56
    while i < 128:
        if word(r, i) != 0:
            return refuse(w, 5)
        i = i + 8
    if get(w, 8) == 0:
        if word(r, 8) != 1 or word(r, 32) != 0:
            return refuse(w, 6)
        i = 0
        while i < 1024:
            if byte(w, i) != 0:
                return refuse(w, 7)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(r, 16))
        put(w, 24, word(r, 24))
        put(w, 40, length(s))
        put(w, 48, length(r))
        put(w, 72, word(s, 16))
        put(w, 88, word(s, 32))
        put(w, 104, word(s, 40))
        put(w, 240, word(r, 40))
        put(w, 248, word(r, 48))
        copy_bytes(w, r, 448, 40, length(r) - 40)
        copy_bytes(w, s, 704, 0, 64)
        status = validate(s, r, w)
        if status >= 256:
            return refuse(w, status)
        if status != 0:
            put(w, 192, status)
            put(w, 8, 2)
            return event(w, 2)
        if get(w, 240) == 0:
            put(w, 8, 2)
            return event(w, 0)
        project(s, r, w)
        if sizes(w) == 0:
            return refuse(w, 8)
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or word(r, 8) != 2:
            return refuse(w, 9)
        if word(r, 16) != get(w, 16) or word(r, 24) != get(w, 24) or word(r, 32) != get(w, 32):
            return refuse(w, 10)
        if length(s) != get(w, 40) or length(r) != get(w, 48):
            return refuse(w, 11)
        i = 40
        while i < length(r):
            if byte(r, i) != byte(w, 448 + i - 40):
                return refuse(w, 12)
            i = i + 1
        i = 0
        while i < 64:
            if byte(s, i) != byte(w, 704 + i):
                return refuse(w, 13)
            i = i + 1
    if get(w, 152) > length(w):
        return event(w, 1)
    fill_range(w, 1024, get(w, 144), 0)
    if clone_graph(s, w, 0, 0, 0, 0) == 0:
        return refuse(w, 14)
    put(w, 160, 1)
    put(w, 168, 0)
    put(w, 176, 0)
    put(w, 184, 0)
    project(s, r, w)
    if get(w, 168) != get(w, 56) or get(w, 176) != get(w, 64) or get(w, 184) != get(w, 80):
        return refuse(w, 15)
    put(w, 1024, GRAPH)
    put(w, 1032, get(w, 16))
    put(w, 1040, get(w, 120))
    put(w, 1048, get(w, 224))
    put(w, 1056, get(w, 128))
    put(w, 1064, get(w, 136))
    put(w, 1072, get(w, 144))
    put(w, 8, 2)
    return event(w, 0)

def validate(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    first = word(r, 128)
    schema = field(s, first, L_schema)
    if text_is(s, schema, L_hepta_hia_edit_query_v2) == 0 and text_is(s, schema, L_hepta_hia_edit_query_v3) == 0:
        return 256
    base = field(s, first, L_base_sha256)
    input_ = field(s, first, L_input_sha256)
    if gkind(s, base) != 4 or gkind(s, input_) != 4:
        return 257
    i = 0
    while i < word(r, 48):
        query = word(r, 128 + i * 8)
        if gkind(s, query) != 6 or text_equal(s, field(s, query, L_schema), schema) == 0:
            return 258
        if text_equal(s, field(s, query, L_base_sha256), base) == 0 or text_equal(s, field(s, query, L_input_sha256), input_) == 0:
            return 259
        selector = field(s, query, L_selector)
        function = field(s, selector, L_function)
        block = field(s, selector, L_block)
        index = small_integer(s, field(s, field(s, query, L_context), L_operation_index))
        if gkind(s, function) != 4 or gkind(s, block) != 4 or index == MAX:
            return 260
        j = 0
        while j < i:
            old = word(r, 128 + j * 8)
            old_selector = field(s, old, L_selector)
            if text_equal(s, function, field(s, old_selector, L_function)) != 0:
                if text_equal(s, block, field(s, old_selector, L_block)) != 0:
                    if index == small_integer(s, field(s, field(s, old, L_context), L_operation_index)):
                        return 1
            j = j + 1
        i = i + 1
    return 0

def project(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    first = word(r, 128)
    root = new_node(w, 6, 6, 0, 0)
    schema = literal(w, L_hepta_hia_edit_batch_query_v2)
    if text_is(s, field(s, first, L_schema), L_hepta_hia_edit_query_v3) != 0:
        schema = literal(w, L_hepta_hia_edit_batch_query_v3)
    pair(w, root, 0, literal(w, L_schema), schema)
    pair(w, root, 1, literal(w, L_base_sha256), field(s, first, L_base_sha256))
    pair(w, root, 2, literal(w, L_input_sha256), field(s, first, L_input_sha256))
    sites = new_node(w, 5, word(r, 48), 0, 0)
    i = 0
    while i < word(r, 48):
        site = new_node(w, 6, 2, 0, 0)
        pair(w, site, 0, literal(w, L_site), integer(w, i))
        pair(w, site, 1, literal(w, L_query), word(r, 128 + i * 8))
        set_edge(w, sites, i, site)
        i = i + 1
    pair(w, root, 3, literal(w, L_sites), sites)
    pair(w, root, 4, literal(w, L_application), application_text(w))
    pair(w, root, 5, literal(w, L_scope), scope_text(w))
    put(w, 224, root)
    return 0

def event(w:mutbuf, action:u64) -> u32:
    if get(w, 32) == MAX:
        put(w, 8, 3)
        return BAD
    put(w, 32, get(w, 32) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 152))
    put(w, 304, 1024)
    put(w, 312, get(w, 144))
    put(w, 320, get(w, 192))
    put(w, 328, get(w, 224))
    put(w, 336, get(w, 248))
    put(w, 344, get(w, 240))
    i = 352
    while i < 384:
        put(w, i, 0)
        i = i + 8
    return 384

def refuse(w:mutbuf, reason:u64) -> u32:
    put(w, 8, 3)
    put(w, 192, reason)
    event(w, 3)
    return BAD
'''

def long_literal(name, value):
    raw=value.encode('ascii')
    lines=[f'def {name}(w:mutbuf) -> u64:', f'    id_ = new_node(w, 4, 0, {len(raw)}, {len(raw)})',
           '    if get(w, 160) == 0:', '        return id_', '    at = 1024 + get(w, 1024 + id_ * 64 + 8)']
    p=0
    while p+8<=len(raw):
        lines.append(f'    put(w, at + {p}, {int.from_bytes(raw[p:p+8],"little")})');p+=8
    for i in range(p,len(raw)):lines.append(f'    store(w, at + {i}, {raw[i]})')
    lines.append('    return id_');return '\n'.join(lines)

COMMON=('gkind','amount','element','text_equal','text_is','field','small_integer','sizes',
        'new_node','set_edge','pair','literal','integer','graph_shape','clone_graph','clone_container','clone_scalar','word','get','put')

def source_program():
    labels={}
    for v in LITERALS:
        raw=v.encode('ascii');assert len(raw)<=32
        labels['L_'+v.replace('.','_').replace('-','_')]=[len(raw),*(int.from_bytes(raw[i:i+8],'little') for i in (0,8,16,24))]
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
        def visit_Call(self,node):
            node=self.generic_visit(node);args=[]
            for arg in node.args:
                if isinstance(arg,ast.Name) and arg.id in labels:args.extend(ast.Constant(v) for v in labels[arg.id])
                else:args.append(arg)
            node.args=args;return node
    own=SOURCE+'\n'+long_literal('application_text','simultaneous_preserving_interfaces')+'\n'+long_literal('scope_text','selected fields only; whole module reverified after all replacements')
    nodes=Expand().visit(ast.parse(own)).body
    helpers={n.name:n for n in ast.parse(apply.source_program()).body}
    tree=ast.Module(body=nodes+[helpers[n] for n in COMMON],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body
    names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes}
    total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['batch_graph']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=shared.CopyBuilder(node,names,signatures,total);builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],'returns':[builder.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_batch_graph','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_batch_graph.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
