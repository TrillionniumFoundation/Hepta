"""Exact-byte native merge and native wire checks, including all Graph kinds."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import random
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_tools import bounded_json_wire
from facts_harness import vm_call
from graph_merge_harness import Actual, frame, merge, reference
from packet_graph_harness import BAD

DEV = Path(__file__).resolve().parent
OUT = DEV / 'graph-merge-native-r1'; OUT.mkdir(exist_ok=False)
COMPILE = DEV / 'graph-merge-source-and-compile-r1'
native = Actual(COMPILE / 'graph-merge.manifest.json', OUT / 'merge')
checked = assemble_program((COMPILE / 'source/examples/hia_bootstrap/graph_merge.hiaasm').read_bytes())
wire_path = DEV.parent / 'native-agent-edit-render-next/development/graph_harness_r3.py'
spec = importlib.util.spec_from_file_location('graph_merge_actual_wire_r3', wire_path)
module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
wire = module.Actual(OUT / 'wire')
pins = {p: p.read_bytes() for p in (Path(__file__), DEV / 'graph_merge_harness.py', DEV / 'packet_graph_harness.py', wire_path)}
cases, controls = [], []
started = time.monotonic_ns()
summary = dict(status='INCOMPLETE')
try:
    shared = [17, {'z': 'same'}]
    cycle = []; cycle.append(cycle)
    examples = [(None, 0), (True, False), (-(1 << 128), (1 << 128) + 1),
                (1.25, -0.0), (float('inf'), None), (float('nan'), 1),
                ('汉\n字𝄞', '\ud800'), ('\u007f', b'bytes'),
                ({None: 3, 17: [False, 'x']}, (1, 2, 3)),
                ({'1': 0, 1: 2}, {}), ({1: 0, 'a': 1}, []),
                ([shared, shared], shared), (cycle, None), (None, [cycle, cycle]),
                (object(), 0), ({'nested': [{'v': 3.4}]}, {'empty': []})]
    rng = random.Random(0x9acdfa)
    for i in range(24):
        a = {'i': i, 'n': rng.randrange(-(1 << 128), 1 << 128), 'v': [rng.random(), bool(i & 1), 'λ']}
        b = [rng.randrange(0, 10000), (rng.random(), 'x' * (i + 1))]
        examples.append((a, b))
    for i, (a, b) in enumerate(examples):
        ga, gb = module.capture(a, 51), module.capture(b, 52)
        expected_graph = reference(ga, gb)
        try:
            expected = {'wire': bounded_json_wire([a, b], 1 << 20)}
        except Exception as exc:
            expected = {'error': str(exc)}
        with patch.object(module, 'capture', side_effect=AssertionError('host capture forbidden during native pipeline')):
            result, after = merge(native.call, 'case-' + str(i), ga, gb, request=i + 1,
                                  compare=(lambda x, y, w: vm_call(checked, x, y, w)) if i in (0, 11, 12) else None)
            assert result == expected_graph
            got = wire.serialize_graph(result, 1 << 20, case='case-' + str(i))
            if 'wire' in expected:
                assert got.get('wire') == expected['wire']
            else:
                assert got.get('error') == expected['error'], (i, expected, got)
        (OUT / f'{i}.graph').write_bytes(result)
        cases.append(dict(case=i, graph_bytes=len(result), complete_graph_bytes_equal=True,
                          wire_or_first_error_equal=True, full_workspace_VM_pair=i in (0, 11, 12)))
    ga, gb = module.capture([19, 23], 61), module.capture({'r': 'value'}, 62)
    result, completed = merge(native.call, 'selected-subroot', ga, gb, request=900, left=2)
    assert result == reference(ga, gb, left=2)
    assert wire.serialize_graph(result, 1 << 20, case='selected-subroot')['wire'] == bounded_json_wire([19, {'r': 'value'}], 1 << 20)
    cases.append(dict(case='selected-subroot', complete_graph_bytes_equal=True, wire_or_first_error_equal=True))
    good = frame(ga, gb, request=1000)
    for label, command, before in (
        ('empty-frame', b'', bytes(512)),
        ('zero-root', good[:40] + bytes(8) + good[48:], bytes(512)),
        ('reserved-field', good[:56] + struct.pack('<Q', 1) + good[64:], bytes(512)),
        ('dirty-workspace', good, bytes(511) + b'!'),
        ('replay-completed', good, completed),
    ):
        code, poisoned = native.call(label, command, gb, before)
        assert code == BAD
        code, retained = native.call(label + '-permanent', good, gb, poisoned)
        assert code == BAD and retained == poisoned
        controls.append(dict(case=label, permanent_refusal=True))
    code, pending = native.call('pending', good, gb, bytes(512))
    event = struct.unpack_from('<16Q', pending, 256)
    assert code == 384 and event[1] == 1
    for label, control in (
        ('changed-selection', frame(ga, gb, action=2, request=1000, sequence=event[4], left=2)),
        ('changed-request', frame(ga, gb, action=2, request=1001, sequence=event[4])),
        ('stale-sequence', frame(ga, gb, action=2, request=1000, sequence=event[4] - 1)),
    ):
        code, poisoned = native.call(label, control, gb, pending)
        assert code == BAD
        again, retained = native.call(label + '-permanent', good, gb, poisoned)
        assert again == BAD and retained == poisoned
        controls.append(dict(case=label, permanent_refusal=True))
    summary = dict(status='PASS', scope='DEVELOPMENT_PRIVATE_GRAPH_MERGE_NOT_PUBLIC_CAPTURE',
                   cases=cases, private_controls=controls, all_Graph_kinds_aliases_cycles_retained=True,
                   capture_is_reference_in_this_test=True, whole_stack_closed=False)
except BaseException as exc:
    summary = dict(status='FAIL', cases=cases, private_controls=controls,
                   error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc(); raise
finally:
    native.close(); wire.close()
    summary.update(native_merge_entries=native.entries, native_wire_entries=wire.entries,
                   elapsed_ns=time.monotonic_ns() - started, source_pins_unchanged=all(p.read_bytes() == b for p,b in pins.items()),
                   pins={str(p):sha256(b).hexdigest() for p,b in pins.items()})
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','private_controls','pins')},sort_keys=True),flush=True)
    assert summary['source_pins_unchanged']
