"""Whole native apply plan independent VM before actual qualified B3 compile."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program, render_assembly
from hepta.hia_program import verify_program
from hepta.hia_program_tools import bounded_json_wire
from hepta import hia_edit_query, hia_edit_batch
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans, selected, swaps
from tools.generate_hia_agent_edit_apply_graph import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from packet_graph_harness import decode_graph_reference
from apply_graph_harness import command, run, triple_roots_reference

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
OUT = DEV / 'apply-graph-source-and-compile-r1'; OUT.mkdir(exist_ok=False)
COMPILER = DEV / 'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths = [ROOT / 'tools/generate_hia_agent_edit_apply_graph.py', ROOT / 'tools/generate_hia_graph_merge.py',
         ROOT / 'tools/hia_agent_edit_source_views.py', ROOT / 'examples/hia_bootstrap/agent_edit_apply_graph.hiaasm',
         COMPILER, Path(__file__), DEV / 'apply_graph_harness.py']
frozen = {p:p.read_bytes() for p in paths}; rows = []
for path, raw in frozen.items():
    rel = path.relative_to(ROOT) if path.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if path == COMPILER else Path('harness') / path.name
    target = OUT / 'source' / rel; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
    rows.append(dict(path=str(path),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT / 'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
wire_path = DEV.parent / 'native-agent-edit-render-next/development/graph_harness_r3.py'
spec = importlib.util.spec_from_file_location('apply_graph_vm_wire_r3',wire_path)
wire = importlib.util.module_from_spec(spec);sys.modules[spec.name]=wire;spec.loader.exec_module(wire)
summary = dict(status='INCOMPLETE',scope='DEVELOPMENT_PRIVATE_APPLY_PLANNER_NOT_PUBLIC_CAPTURE_RECONSTRUCTION_OR_ADMISSION')
started=time.monotonic_ns()
try:
    doc=document(); source=frozen[paths[3]]; assert render_assembly(doc).encode()==source
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),
                 max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),
                 max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    checked=assemble_program(source); entries=[0]; observations=[]
    def execute(label,a,b,before):
        code,after=vm_call(checked,a,b,before);entries[0]+=1
        for suffix,raw in (('graph',a),('command',b),('before',before),('after',after)):
            (OUT/f'vm-{entries[0]}.{suffix}.bin').write_bytes(raw)
        return code,after
    for mode in (1,2):
        original=verify_program(fixture() if mode==1 else loans())
        if mode==1:
            query=hia_edit_query.prepare_edit(original,function='calculate',block='entry',output='y',fields=['op'])
            response={'op':'int.sub.wrap'}; owner=hia_edit_query; apply=owner.apply_edit; receipt_key='edit_query'
        else:
            query=hia_edit_batch.prepare_batch(original,[selected('reader'),selected('writer')])
            response=swaps();owner=hia_edit_batch;apply=owner.apply_batch;receipt_key='edit_batch'
        patches=[];real=owner.apply_program_patch
        def observe(base,payload):
            patches.append(payload)
            return real(base,payload)
        with patch.object(owner,'apply_program_patch',new=observe):
            changed,receipt=apply(original,query,response)
        assert len(patches)==1
        raw=bounded_json_wire(response,16384 if mode==1 else 65536)
        qraw=bounded_json_wire(query,1<<20)
        graph=wire.capture([original.as_dict(),query,response],lease=19)
        control=command(mode,triple_roots_reference(graph),len(raw),sha256(qraw).digest(),sha256(raw).digest(),request=mode)
        event,after=run(execute,str(mode),graph,control)
        assert event[1]==0
        result=after[event[6]:event[6]+event[7]]
        expected=[[original.as_dict(),patches[0]],receipt[receipt_key]]
        assert decode_graph_reference(result)==expected
        (OUT/f'vm-{mode}.result.graph').write_bytes(result)
        (OUT/f'vm-{mode}.expected.json').write_bytes(bounded_json_wire(expected,8<<20))
        observations.append(dict(mode=mode,complete_patch_and_pending_metadata_equal=True,final_candidate_oracle_sha256=changed.sha256))
    compiled,receipt=compile_stage(OUT,'agent-edit-apply-graph',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-apply-graph-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_apply_graph.hiaasm'),source_sha256=sha256(source).hexdigest(),image_path=str(compiled),image_sha256=sha256(compiled.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-apply-graph.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=observations,independent_VM_entries=entries[0],receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    summary['source_before_after_equal']=all(p.read_bytes()==raw for p,raw in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
