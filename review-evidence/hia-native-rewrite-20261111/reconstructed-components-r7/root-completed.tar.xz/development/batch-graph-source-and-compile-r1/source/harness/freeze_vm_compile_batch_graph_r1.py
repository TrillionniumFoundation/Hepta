"""Independent VM for ordered prefix/whole batch; then actual qualified B3."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from hepta.hia_agent_assembly import assemble_program,render_assembly
from hepta.hia_program import verify_program
from hepta.hia_edit_query import prepare_edit
from hepta.hia_edit_batch import prepare_batch
from tests.test_hia_edit_batch import loans,selected
from tools.generate_hia_agent_edit_batch_graph import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from packet_graph_harness import decode_graph_reference
from batch_graph_harness import command,run

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'batch-graph-source-and-compile-r1';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_batch_graph.py',ROOT/'tools/generate_hia_agent_edit_apply_graph.py',
       ROOT/'tools/generate_hia_graph_merge.py',ROOT/'tools/hia_agent_edit_source_views.py',
       ROOT/'examples/hia_bootstrap/agent_edit_batch_graph.hiaasm',COMPILER,Path(__file__),DEV/'batch_graph_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
path=DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py';spec=importlib.util.spec_from_file_location('batch_graph_vm_wire',path)
wire=importlib.util.module_from_spec(spec);sys.modules[spec.name]=wire;spec.loader.exec_module(wire)
summary=dict(status='INCOMPLETE',scope='DEVELOPMENT_PRIVATE_BATCH_OWNER_NOT_PUBLIC_CAPTURE_OR_COORDINATOR');started=time.monotonic_ns()
try:
    doc=document();source=frozen[paths[4]];assert render_assembly(doc).encode()==source
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    checked=assemble_program(source);entries=[0];observations=[]
    def call(label,a,b,before):
        code,after=vm_call(checked,a,b,before);entries[0]+=1
        for suffix,raw in (('graph',a),('command',b),('before',before),('after',after)):(OUT/f'vm-{entries[0]}.{suffix}.bin').write_bytes(raw)
        return code,after
    original=verify_program(loans());selections=[selected('reader'),selected('writer')]
    queries=[prepare_edit(original,**v) for v in selections]
    for n in (1,2):
        graph=wire.capture(queries[:n]);node_count=struct.unpack_from('<Q',graph,16)[0]
        roots=struct.unpack_from('<'+'Q'*n,graph,64+node_count*64)
        event,after=run(call,'prefix-'+str(n),graph,command(roots,0,request=n))
        assert event[1]==0 and event[7]==0 and event[9]==0
        event,after=run(call,'final-'+str(n),graph,command(roots,1,request=10+n))
        assert event[1]==0
        result=after[event[6]:event[6]+event[7]]
        assert decode_graph_reference(result)==prepare_batch(original,selections[:n])
        observations.append(dict(sites=n,prefix_and_complete_batch_equal=True))
    graph=wire.capture([queries[0],queries[0]]);node_count=struct.unpack_from('<Q',graph,16)[0]
    roots=struct.unpack_from('<2Q',graph,64+node_count*64)
    event,after=run(call,'overlap',graph,command(roots,0,request=30));assert event[1]==2 and event[8]==1
    compiled,receipt=compile_stage(OUT,'agent-edit-batch-graph',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-batch-graph-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_batch_graph.hiaasm'),source_sha256=sha256(source).hexdigest(),image_path=str(compiled),image_sha256=sha256(compiled.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-batch-graph.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=observations,independent_overlap_refusal=True,independent_VM_entries=entries[0],receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
