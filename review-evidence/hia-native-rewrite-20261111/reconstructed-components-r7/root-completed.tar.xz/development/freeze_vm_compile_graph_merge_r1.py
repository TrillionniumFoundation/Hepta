"""Freeze, independently interpret and actually compile the complete merger."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback
from hepta.hia_agent_assembly import assemble_program, render_assembly
from tools.generate_hia_graph_merge import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from graph_merge_harness import merge, reference

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
OUT = DEV / 'graph-merge-source-and-compile-r1'
OUT.mkdir(exist_ok=False)
COMPILER = DEV / 'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths = [ROOT / 'tools/generate_hia_graph_merge.py', ROOT / 'tools/hia_agent_edit_source_views.py',
         ROOT / 'examples/hia_bootstrap/graph_merge.hiaasm', COMPILER,
         DEV / 'graph_merge_harness.py', DEV / 'packet_graph_harness.py', Path(__file__)]
frozen = {p: p.read_bytes() for p in paths}
rows = []
for p, raw in frozen.items():
    rel = p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p == COMPILER else Path('harness') / p.name
    target = OUT / 'source' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append(dict(path=str(p), copy=str(target), bytes=len(raw), sha256=sha256(raw).hexdigest()))
(OUT / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
wire_path = DEV.parent / 'native-agent-edit-render-next/development/graph_harness_r3.py'
spec = importlib.util.spec_from_file_location('graph_merge_vm_wire_r3', wire_path)
wire = importlib.util.module_from_spec(spec); sys.modules[spec.name] = wire; spec.loader.exec_module(wire)
summary = dict(status='INCOMPLETE', scope='DEVELOPMENT_PRIVATE_GRAPH_MERGER_NOT_PUBLIC_CAPTURE')
started = time.monotonic_ns()
try:
    doc = document(); source = frozen[paths[2]]
    assert render_assembly(doc).encode() == source
    profile = dict(functions=len(doc['functions']), blocks=sum(len(f['blocks']) for f in doc['functions']),
                   max_blocks=max(len(f['blocks']) for f in doc['functions']),
                   ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),
                   max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions'] <= 128 and profile['blocks'] <= 1536 and profile['max_blocks'] <= 256
    assert profile['ops'] <= 8192 and profile['max_block_params'] <= 16
    checked = assemble_program(source)
    cyclic = []; cyclic.append(cyclic)
    pairs = [(None, 0), ({'x': [2.25, True, '字']}, (False, b'bytes', -17)), (cyclic, [cyclic, cyclic])]
    entries = [0]
    def execute(label, a, b, before):
        code, after = vm_call(checked, a, b, before)
        entries[0] += 1
        for suffix, raw in (('left', a), ('right', b), ('before', before), ('after', after)):
            (OUT / f'vm-{entries[0]}.{suffix}.bin').write_bytes(raw)
        return code, after
    for case, (a, b) in enumerate(pairs):
        ga, gb = wire.capture(a, 17), wire.capture(b, 18)
        result, after = merge(execute, str(case), ga, gb, request=case + 1)
        assert result == reference(ga, gb)
    compiled, receipt = compile_stage(OUT, 'graph-merge', COMPILER, source)
    manifest = dict(schema='hepta.hia.graph-merge-native.v1',
                    source_path=str(OUT / 'source/examples/hia_bootstrap/graph_merge.hiaasm'),
                    source_sha256=sha256(source).hexdigest(), image_path=str(compiled),
                    image_sha256=sha256(compiled.read_bytes()).hexdigest(),
                    compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT / 'graph-merge.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    summary.update(status='PASS', profile=profile, independent_VM_cases=3, independent_VM_entries=entries[0],
                   capture_is_development_reference_not_public_issuer=True, receipt=receipt, manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc(); raise
finally:
    summary['source_before_after_equal'] = all(p.read_bytes() == raw for p, raw in frozen.items())
    summary['elapsed_ns'] = time.monotonic_ns() - started
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert summary['source_before_after_equal']
