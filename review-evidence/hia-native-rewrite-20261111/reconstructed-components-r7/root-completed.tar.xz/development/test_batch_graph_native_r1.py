"""Actual native single queries, prefix checks, whole batch and atomic apply."""
from contextlib import ExitStack
import copy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_program_tools import bounded_json_wire
from hepta import hia_edit_query,hia_edit_batch,hia_program,hia_program_tools
from hepta.hia_composite_function_tokens import ObjectTokenDecoder
from hepta.hia_core_patch_native import NativeCorePatch
from hepta.hia_core_admission_native import NativeCoreAdmission
from tests.test_hia_edit_batch import loans,selected,swaps
from tests.test_hia_program import b,c,f,i,ret
from packet_graph_harness import Actual,BAD
from graph_merge_harness import merge
from batch_graph_harness import command,run
from apply_graph_harness import command as apply_command,run as apply_run,serialize_root
from facts_harness import vm_call
from native_query_pipeline import NativeQueryPipeline

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'batch-graph-native-r1';OUT.mkdir(exist_ok=False)
pipeline=NativeQueryPipeline(OUT/'single-queries')
batch=Actual(DEV/'batch-graph-source-and-compile-r1/agent-edit-batch-graph.manifest.json',OUT/'batch')
merger=Actual(DEV/'graph-merge-source-and-compile-r1/graph-merge.manifest.json',OUT/'merge')
apply=Actual(DEV/'apply-graph-source-and-compile-r1/agent-edit-apply-graph.manifest.json',OUT/'apply')
checked=assemble_program((DEV/'batch-graph-source-and-compile-r1/source/examples/hia_bootstrap/agent_edit_batch_graph.hiaasm').read_bytes())
path=DEV.parent/'native-agent-edit-render-next/development/arena_graph_harness_r2.py';spec=importlib.util.spec_from_file_location('batch_graph_arena_r2',path)
arena_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=arena_module;spec.loader.exec_module(arena_module)
arena=arena_module.Actual(OUT/'arena')
raw=(DEV/'apply-graph-native-r1/core_patch.image.bin').read_bytes();patcher=NativeCorePatch(raw,sha256(raw).hexdigest())
raw=(DEV/'apply-graph-native-r1/core_admission.image.bin').read_bytes();admission=NativeCoreAdmission(raw,sha256(raw).hexdigest())
pins={p:p.read_bytes() for p in (Path(__file__),DEV/'batch_graph_harness.py',DEV/'apply_graph_harness.py',DEV/'native_query_pipeline.py',
      ROOT/'hepta/hia_edit_batch.py',ROOT/'hepta/hia_edit_query.py')}
cases,controls=[],[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')

def forbidden(*args,**kwargs):raise AssertionError('host semantic owner entered actual batch chain')
def native_graph(label,wire):
    code,data=arena.decoder(wire,label);assert data is not None,(code,label)
    return arena.bridge(data,wire,case=label)['graph']

def exercise(label,document,selections,response=None,pair_vm=False):
    original=verify_program(document);base_wire=original.canonical_bytes
    expected_error=None;expected_batch=None;expected_candidate=None;expected_metadata=None
    try:
        expected_batch=hia_edit_batch.prepare_batch(original,selections)
        expected_wire=bounded_json_wire(expected_batch,1<<20)
        if response is not None:
            candidate,receipt=hia_edit_batch.apply_batch(original,expected_batch,response)
            expected_candidate=candidate.canonical_bytes
            expected_metadata=bounded_json_wire(receipt['edit_batch'],1<<20)
    except Exception as exc:expected_error=str(exc)
    source_packets=[transport([original.as_dict(),selection]) for selection in selections]
    response_wire=bounded_json_wire(response,65536) if response is not None else None
    case_dir=OUT/('case-'+str(len(cases)));case_dir.mkdir()
    (case_dir/'base.json').write_bytes(base_wire)
    for n,packet in enumerate(source_packets):(case_dir/f'input-{n}.packet').write_bytes(packet)
    begin=pipeline.requests;prefixes=0;graph=None;roots=[];observations=[]
    with ExitStack() as guards:
        for mod,name in ((hia_program,'verify_program'),(hia_edit_query,'prepare_edit'),(hia_edit_query,'apply_edit'),
                         (hia_edit_batch,'prepare_batch'),(hia_edit_batch,'apply_batch'),
                         (hia_program_tools,'apply_program_patch'),(ObjectTokenDecoder,'feed'),(json,'loads')):
            guards.enter_context(patch.object(mod,name,new=forbidden))
        assert admission.status(base_wire)==0
        base_digest=pipeline.hasher.digest(base_wire)
        assert base_digest.hex()==original.sha256
        for n,packet in enumerate(source_packets):
            query_graph,query_wire=pipeline.prepare(label+'-single-'+str(n),packet,base_digest,base_digest)
            if graph is None:
                graph=query_graph;roots=[struct.unpack_from('<Q',query_graph,24)[0]]
            else:
                old_count=struct.unpack_from('<Q',graph,16)[0]
                graph,unused=merge(merger.call,label+'-merge-'+str(n),graph,query_graph,request=pipeline.requests)
                roots=[v+1 for v in roots]+[struct.unpack_from('<Q',query_graph,24)[0]+old_count+1]
            control=command(roots,0,request=pipeline.requests)
            event,after=run(batch.call,label+'-prefix-'+str(n),graph,control)
            observations.append((graph,control,event,after));prefixes+=1
            if event[1]==2:
                assert event[8]==1 and expected_error=='E_HIA_EDIT_BATCH: selections overlap one instruction'
                break
            assert event[1]==0 and event[7]==0 and event[9]==0
        if event[1]==2:
            outcome='EXACT_OVERLAP_REFUSAL_BEFORE_NEXT_QUERY'
            assert pipeline.requests-begin==prefixes
            if len(selections)>prefixes:assert prefixes==2
        else:
            assert expected_error is None and expected_batch is not None
            control=command(roots,1,request=pipeline.requests+1000)
            event,after=run(batch.call,label+'-final',graph,control)
            observations.append((graph,control,event,after));assert event[1]==0
            result_graph=after[event[6]:event[6]+event[7]]
            wire=pipeline.wire.serialize_graph(result_graph,1<<20,case=label+'-batch-wire')['wire']
            assert wire==expected_wire
            (case_dir/'actual-batch.json').write_bytes(wire);(case_dir/'expected-batch.json').write_bytes(expected_wire)
            outcome='EXACT_COMPLETE_BATCH_FROM_ACTUAL_NATIVE_SINGLE_QUERIES'
            if response_wire is not None:
                bg=native_graph(label+'-base',base_wire);rg=native_graph(label+'-response',response_wire)
                first,unused=merge(merger.call,label+'-apply-base-query',bg,result_graph,request=pipeline.requests+2000)
                combined,unused=merge(merger.call,label+'-apply-response',first,rg,request=pipeline.requests+3000)
                bnode=struct.unpack_from('<Q',bg,24)[0]+2
                qnode=struct.unpack_from('<Q',result_graph,24)[0]+struct.unpack_from('<Q',bg,16)[0]+2
                rnode=struct.unpack_from('<Q',rg,24)[0]+struct.unpack_from('<Q',first,16)[0]+1
                ctl=apply_command(2,(bnode,qnode,rnode),len(response_wire),pipeline.hasher.digest(wire),pipeline.hasher.digest(response_wire),request=pipeline.requests+4000)
                ae,aw=apply_run(apply.call,label+'-apply',combined,ctl);assert ae[1]==0
                pg=aw[ae[6]:ae[6]+ae[7]]
                envelope=serialize_root(pipeline.wire,pg,ae[10],8<<20,label+'-envelope')
                extracted,version,policy,edits=patcher.transform(envelope,extract=True)
                assert extracted==base_wire and admission.status(extracted)==0
                candidate,version,policy,edits=patcher.transform(envelope)
                assert version==1 and policy==0 and edits==len(selections)
                assert admission.status(candidate)==0 and candidate==expected_candidate
                metadata=serialize_root(pipeline.wire,pg,ae[11],1<<20,label+'-metadata-after-admission')
                assert metadata==expected_metadata
                (case_dir/'actual-candidate.json').write_bytes(candidate);(case_dir/'actual-metadata.json').write_bytes(metadata)
                outcome='EXACT_NATIVE_PREPARE_BATCH_APPLY_PATCH_AND_FINAL_ADMISSION'
    if pair_vm:
        for g,ctl,e,w in observations:
            ee,ww=run(batch.call,label+'-VM-pair',g,ctl,compare=lambda s,c,w:vm_call(checked,s,c,w))
            assert ee==e and ww==w
    cases.append(dict(case=label,outcome=outcome,actual_single_queries=pipeline.requests-begin,prefix_checks=prefixes,
                      requested_selections=len(selections),full_workspace_VM_pair=pair_vm,
                      host_semantic_owners_disabled=True))
    return graph,control,after

try:
    source=loans()
    graph,control,completed=exercise('loans-two-atomic',source,[selected('reader'),selected('writer')],swaps(),True)
    graph,control,completed=exercise('loans-reversed-selections',source,[selected('writer'),selected('reader')],
        {'edits':[{'site':1,'changes':{'args':['z']}},{'site':0,'changes':{'args':['a']}}]})
    graph,control,completed=exercise('same-output-overlap',source,[selected('reader'),selected('reader')])
    graph,control,completed=exercise('overlap-before-invalid-later-selector',source,[selected('reader'),selected('reader'),
        {'function':'missing','block':'entry','output':'absent','fields':[]}])
    source=loans();source['functions'][0]['blocks'][0]['ops'][1]=i('buffer.try_new',['size'],[('a','buffer'),('ok','bool')])
    graph,control,completed=exercise('multiresult-alias-overlap',source,[selected('a'),selected('ok','op')])
    for n in (1,16):
        source={'schema':'hepta.hia.program.v8','module':'native_batch','functions':[
            f('work',[],['u32'],[],[b('entry',[],[c('k'+str(i),'u32',i) for i in range(n)],ret('k'+str(n-1)))])]}
        selections=[selected('k'+str(i),'attrs') for i in range(n)]
        response={'edits':[{'site':i,'changes':{'attrs':{'value':i+100}}} for i in reversed(range(n))]}
        graph,control,completed=exercise('native-sites-'+str(n),source,selections,response,pair_vm=n==1)
    for label,ctl,before in (
        ('empty-command',b'',bytes(1024)),('dirty-initial',control,bytes(1023)+b'!'),
        ('replay-complete',control,completed),('zero-count',control[:48]+bytes(8)+control[56:],bytes(1024)),
        ('reserved-command',control[:56]+struct.pack('<Q',1)+control[64:],bytes(1024))):
        code,poisoned=batch.call(label,graph,ctl,before);assert code==BAD
        again,retained=batch.call(label+'-permanent',graph,control,poisoned);assert again==BAD and retained==poisoned
        controls.append(dict(case=label,permanent_poison=True))
    code,pending=batch.call('grow-original',graph,control,bytes(1024));event=struct.unpack_from('<16Q',pending,256);assert code==384 and event[1]==1
    continuation=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',event[4])+control[40:]
    for label,ctl in (('changed-prefix',continuation[:40]+bytes(8)+continuation[48:]),
                      ('stale-sequence',continuation[:32]+struct.pack('<Q',event[4]-1)+continuation[40:]),
                      ('changed-query-roots',continuation[:128]+continuation[136:144]+continuation[128:136]+continuation[144:])):
        code,poisoned=batch.call(label,graph,ctl,pending);assert code==BAD
        controls.append(dict(case=label,rejected=True))
    summary=dict(status='PASS',scope='DEVELOPMENT_NATIVE_COMPLETE_BATCH_AND_ATOMIC_APPLY_NOT_PUBLIC_CAPTURE_OR_FIXED_COORDINATOR',
                 cases=cases,private_controls=controls,whole_stack_closed=False,
                 original_query_first_error_order_preserved_by_prefix_calls=True,
                 full_public_selection_validation_and_coordinator_still_required=True)
except BaseException as exc:
    summary=dict(status='FAIL',cases=cases,private_controls=controls,error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    pipeline.close();batch.close();merger.close();apply.close();arena.close()
    summary.update(actual_single_queries=pipeline.requests,native_batch_entries=batch.entries,native_merge_entries=merger.entries,
                   native_apply_entries=apply.entries,native_facts_entries=pipeline.facts.entries,native_query_entries=pipeline.query.entries,
                   native_packet_graph_entries=pipeline.bridge.entries,native_issuer_entries=pipeline.issuer.entries,
                   native_wire_entries=pipeline.wire.entries,native_arena_entries=arena.entries,
                   elapsed_ns=time.monotonic_ns()-started,source_pins_unchanged=all(p.read_bytes()==v for p,v in pins.items()),
                   pins={str(p):sha256(v).hexdigest() for p,v in pins.items()})
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','private_controls','pins')},sort_keys=True),flush=True)
    assert summary['source_pins_unchanged']
