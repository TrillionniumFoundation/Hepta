"""Actual JSON -> Graph -> merge -> apply -> bounded wire -> patch -> Core.

This validates the private apply owner. Native public query reconstruction and
first-error raw/capture orchestration remain separate, explicit obligations.
"""
from contextlib import ExitStack
import copy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program, HIAProgramRejected
from hepta.hia_program_tools import bounded_json_wire
from hepta.hia_composite_function_tokens import detached_packet_index, ObjectTokenDecoder
from hepta.hia_sha256_native import NativeSha256
from hepta.hia_core_patch_native import NativeCorePatch
from hepta.hia_core_admission_native import NativeCoreAdmission, ERROR_CODES
from hepta import hia_edit_query, hia_edit_batch, hia_program_tools, hia_program
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans, selected, swaps
from tests.test_hia_program import b, c, f, ret
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from packet_graph_harness import Actual, BAD
from graph_merge_harness import merge
from apply_graph_harness import command, run, serialize_root, ERRORS

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
OUT = DEV / 'apply-graph-native-r1'; OUT.mkdir(exist_ok=False)
COMPILER = DEV / 'facts-source-and-compile-r1/source/compiler/B3.image.bin'
pins = {p:p.read_bytes() for p in (Path(__file__), DEV/'apply_graph_harness.py', DEV/'graph_merge_harness.py', DEV/'packet_graph_harness.py',
        ROOT/'hepta/hia_edit_query.py',ROOT/'hepta/hia_edit_batch.py',ROOT/'hepta/hia_program_tools.py')}
def load(name,path):
    pins[path]=path.read_bytes(); spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
arena_module=load('apply_graph_actual_arena_r2',DEV.parent/'native-agent-edit-render-next/development/arena_graph_harness_r2.py')
arena=arena_module.Actual(OUT/'arena')
merger=Actual(DEV/'graph-merge-source-and-compile-r1/graph-merge.manifest.json',OUT/'merge')
planner=Actual(DEV/'apply-graph-source-and-compile-r1/agent-edit-apply-graph.manifest.json',OUT/'apply')
checked=assemble_program((DEV/'apply-graph-source-and-compile-r1/source/examples/hia_bootstrap/agent_edit_apply_graph.hiaasm').read_bytes())
images={}
for name in ('core_patch','core_admission'):
    source=ROOT/'examples/hia_bootstrap'/(name+'.hiaasm');pins[source]=source.read_bytes()
    image,receipt=compile_stage(OUT,name,COMPILER,pins[source]);images[name]=image.read_bytes()
patcher=NativeCorePatch(images['core_patch'],sha256(images['core_patch']).hexdigest())
admission=NativeCoreAdmission(images['core_admission'],sha256(images['core_admission']).hexdigest())
hash_image=(DEV/'query-native-r2/sha256.image.bin').read_bytes();hasher=NativeSha256(hash_image,sha256(hash_image).hexdigest())
cases,controls=[],[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')

def forbidden(*args,**kwargs):
    raise AssertionError('host semantic/JSON/edit owner entered actual apply pipeline')

def native_graph(label,wire):
    status,raw_arena=arena.decoder(wire,label)
    assert raw_arena is not None,(label,status)
    result=arena.bridge(raw_arena,wire,case=label)
    assert 'graph' in result,result
    return result['graph']

def exercise(label,original,query,response,mode,query_provenance,vm_pair=False):
    owner=hia_edit_query if mode==1 else hia_edit_batch
    apply=owner.apply_edit if mode==1 else owner.apply_batch
    receipt_key='edit_query' if mode==1 else 'edit_batch'
    patches=[];real=owner.apply_program_patch
    def capture_patch(base,payload):
        patches.append(copy.deepcopy(payload));return real(base,payload)
    expected_error=None;expected_candidate=None;expected_metadata=None
    with patch.object(owner,'apply_program_patch',new=capture_patch):
        try:
            candidate,receipt=apply(original,query,response)
            expected_candidate=candidate.canonical_bytes;expected_metadata=bounded_json_wire(receipt[receipt_key],1<<20)
        except Exception as exc:
            expected_error=dict(type=type(exc).__name__,message=str(exc),code=getattr(exc,'code',None))
    base_wire=original.canonical_bytes
    query_wire=bounded_json_wire(query,1<<20)
    response_wire=bounded_json_wire(response,16384 if mode==1 else 65536)
    expected_patch=bounded_json_wire([original.as_dict(),patches[0]],8<<20) if patches else None
    case_dir=OUT/('case-'+str(len(cases)).zfill(3));case_dir.mkdir()
    for name,raw in (('base.json',base_wire),('query.json',query_wire),('response.json',response_wire)):
        (case_dir/name).write_bytes(raw)
    if expected_patch is not None:(case_dir/'expected-envelope.json').write_bytes(expected_patch)
    if expected_candidate is not None:(case_dir/'expected-candidate.json').write_bytes(expected_candidate)
    if expected_metadata is not None:(case_dir/'expected-metadata.json').write_bytes(expected_metadata)
    with ExitStack() as guards:
        for mod,name in ((hia_program,'verify_program'),(hia_edit_query,'prepare_edit'),(hia_edit_query,'apply_edit'),
                         (hia_edit_batch,'prepare_batch'),(hia_edit_batch,'apply_batch'),
                         (hia_program_tools,'apply_program_patch'),(ObjectTokenDecoder,'feed'),(json,'loads')):
            guards.enter_context(patch.object(mod,name,new=forbidden))
        assert admission.status(base_wire)==0
        bg=native_graph(label+'-base',base_wire)
        qg=native_graph(label+'-query',query_wire)
        rg=native_graph(label+'-response',response_wire)
        qwire=arena.graph.serialize_graph(qg,1<<20,case=label+'-query-wire')['wire']
        assert qwire==query_wire
        first,first_work=merge(merger.call,label+'-merge-base-query',bg,qg,request=len(cases)*2+1)
        graph,merge_work=merge(merger.call,label+'-merge-response',first,rg,request=len(cases)*2+2)
        root_base=struct.unpack_from('<Q',bg,24)[0]+2
        root_query=struct.unpack_from('<Q',qg,24)[0]+struct.unpack_from('<Q',bg,16)[0]+2
        root_response=struct.unpack_from('<Q',rg,24)[0]+struct.unpack_from('<Q',first,16)[0]+1
        control=command(mode,(root_base,root_query,root_response),len(response_wire),hasher.digest(qwire),hasher.digest(response_wire),request=len(cases)+1)
        event,after=run(planner.call,label,graph,control)
        if event[1]==2:
            assert not patches and expected_error is not None
            assert ERRORS[event[8]]==expected_error['message'],(label,event,expected_error)
            outcome='EXACT_RESPONSE_POLICY_REFUSAL';status=None
        else:
            assert event[1]==0 and expected_patch is not None,(label,event,expected_error)
            result_graph=after[event[6]:event[6]+event[7]]
            envelope=serialize_root(arena.graph,result_graph,event[10],8<<20,label+'-envelope')
            assert envelope==expected_patch,label
            (case_dir/'actual-envelope.json').write_bytes(envelope)
            base,version,policy,count=patcher.transform(envelope,extract=True)
            assert base==base_wire and admission.status(base)==0
            candidate,version,policy,count=patcher.transform(envelope)
            assert version==1 and policy==0
            status=admission.status(candidate)
            (case_dir/'actual-candidate.json').write_bytes(candidate)
            if expected_error is not None:
                assert expected_error['type']=='HIAProgramRejected' and ERROR_CODES.get(status)==expected_error['code'],(label,status,expected_error)
                outcome='EXACT_CORE_REFUSAL_CATEGORY_AFTER_COMPLETE_PATCH'
            else:
                assert status==0 and candidate==expected_candidate,(label,status)
                # Receipt fields are only exposed after actual final admission.
                meta=serialize_root(arena.graph,result_graph,event[11],1<<20,label+'-metadata-after-admission')
                assert meta==expected_metadata,label
                (case_dir/'actual-metadata-after-admission.json').write_bytes(meta)
                outcome='EXACT_PATCH_CANDIDATE_AND_METADATA_AFTER_NATIVE_ADMISSION'
    if vm_pair:
        paired,paired_after=run(planner.call,label+'-VM-pair',graph,control,
                               compare=lambda s,c,w:vm_call(checked,s,c,w))
        assert paired==event and paired_after==after
    cases.append(dict(case=label,mode=mode,outcome=outcome,query_provenance=query_provenance,
                      original_and_final_native_admission=True if expected_candidate is not None else None,
                      final_core_status=status,full_workspace_VM_pair=vm_pair,
                      hosted_semantic_owners_disabled=True))
    if len(cases)%20==0:print(json.dumps({'completed_cases':len(cases)}),flush=True)
    return graph,control,after

try:
    old=DEV/'query-native-r2'; prior=json.loads((old/'summary.json').read_text())['cases']
    ledger=[json.loads(line) for line in (DEV/'facts-native-r3/facts/entries.jsonl').read_text().splitlines()]
    source_rows={row['case']:row for row in ledger if row['event'] and row['event'][1]==0}
    for index,row in enumerate(prior):
        if row['outcome']!='EXACT_COMPLETE_QUERY':continue
        origin=source_rows[row['case']]
        source=(DEV/'facts-native-r3/facts'/('source-'+origin['source_sha256']+'.lease')).read_bytes()
        length=struct.unpack_from('<Q',source,8)[0]
        (base,selection),unused=detached_packet_index(source[64:64+length])
        original=verify_program(base)
        query=json.loads((old/f'query-{index}.json').read_bytes())
        field=query['fields'][0]
        response={field:query['context']['operation'][field]}
        graph,control,after=exercise('native-query-'+row['case'],original,query,response,1,'ACTUAL_PRIOR_NATIVE_QUERY',vm_pair=row['case']=='fixture')
    original=verify_program(fixture());query=hia_edit_query.prepare_edit(original,function='calculate',block='entry',output='y',fields=['op','args','attrs'])
    for i,response in enumerate(({'op':'int.sub.wrap'},{'args':['x','x']},{'args':['missing','x']},{'op':'bad.op'}, {}, [],
                                 {'out':[]},{'unknown':0},{'args':['x','x'],'op':'int.mul.wrap'})):
        graph,control,after=exercise('single-response-'+str(i),original,query,response,1,'REFERENCE_PREPARED_ADMITTED_INPUT')
    original=verify_program(loans());query=hia_edit_batch.prepare_batch(original,[selected('reader'),selected('writer')])
    responses=[swaps(),{'edits':list(reversed(swaps()['edits']))}, {}, [], {'edits':[]},
               {'edits':[{'site':0,'changes':{'args':['z']}},{'site':0,'changes':{'args':['a']}}]},
               {'edits':[{'site':True,'changes':{'args':['z']}},{'site':1,'changes':{'args':['a']}}]},
               {'edits':[{'site':16,'changes':{'args':['z']}},{'site':1,'changes':{'args':['a']}}]},
               {'edits':[{'site':0,'changes':{}},{'site':1,'changes':{'args':['a']}}]},
               {'edits':[{'site':0,'changes':{'out':[]}},{'site':1,'changes':{'args':['a']}}]},
               {'edits':[{'site':0,'extra':0,'changes':{'args':['z']}},{'site':1,'changes':{'args':['a']}}]},
               {'edits':[{'site':0,'changes':{'args':['z']}},{'site':1,'changes':{'args':['missing']}}]}]
    for i,response in enumerate(responses):
        graph,control,after=exercise('batch-response-'+str(i),original,query,response,2,'REFERENCE_PREPARED_ADMITTED_INPUT',vm_pair=i==0)
    for n in (1,16):
        original=verify_program({'schema':'hepta.hia.program.v8','module':'apply_sites','functions':[
            f('work',[],['u32'],[],[b('entry',[],[c('k'+str(i),'u32',i) for i in range(n)],ret('k'+str(n-1)))])]})
        selections=[selected('k'+str(i),'attrs') for i in range(n)]
        query=hia_edit_batch.prepare_batch(original,selections)
        response={'edits':[{'site':i,'changes':{'attrs':{'value':i+100}}} for i in reversed(range(n))]}
        graph,control,after=exercise('batch-sites-'+str(n),original,query,response,2,'REFERENCE_PREPARED_ADMITTED_INPUT')
    for label,ctl,before in (
        ('empty-command',b'',bytes(1024)),('dirty-initial',control,bytes(1023)+b'!'),
        ('replay-completed',control,after),('reserved-command',control[:80]+struct.pack('<Q',1)+control[88:],bytes(1024))):
        code,poisoned=planner.call(label,graph,ctl,before);assert code==BAD
        code,retained=planner.call(label+'-permanent',graph,control,poisoned);assert code==BAD and retained==poisoned
        controls.append(dict(case=label,permanent_poison=True))
    code,pending=planner.call('grow-original',graph,control,bytes(1024));event=struct.unpack_from('<16Q',pending,256);assert code==384 and event[1]==1
    continuation=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',event[4])+control[40:]
    for label,ctl in (
        ('changed-query-digest',continuation[:128]+bytes([continuation[128]^1])+continuation[129:]),
        ('changed-response-digest',continuation[:160]+bytes([continuation[160]^1])+continuation[161:]),
        ('changed-mode',continuation[:40]+struct.pack('<Q',1)+continuation[48:]),
        ('stale-sequence',continuation[:32]+struct.pack('<Q',event[4]-1)+continuation[40:])):
        code,poisoned=planner.call(label,graph,ctl,pending);assert code==BAD
        controls.append(dict(case=label,rejected=True))
    summary=dict(status='PASS',scope='DEVELOPMENT_NATIVE_APPLY_POLICY_PATCH_AND_FINAL_CORE_NOT_PUBLIC_QUERY_RECONSTRUCTION_OR_CAPTURE',
                 cases=cases,private_controls=controls,whole_stack_closed=False,full_native_public_coordinator_required=True,
                 native_batch_prepare_still_required=True,raw_response_preflight_error_order_not_claimed=True)
except BaseException as exc:
    summary=dict(status='FAIL',cases=cases,private_controls=controls,error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    planner.close();merger.close();arena.close()
    summary.update(native_apply_entries=planner.entries,native_merge_entries=merger.entries,native_arena_entries=arena.entries,
                   native_wire_entries=arena.graph.entries,elapsed_ns=time.monotonic_ns()-started,
                   source_pins_unchanged=all(p.read_bytes()==v for p,v in pins.items()),pins={str(p):sha256(v).hexdigest() for p,v in pins.items()})
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','private_controls','pins')},sort_keys=True),flush=True)
    assert summary['source_pins_unchanged']
