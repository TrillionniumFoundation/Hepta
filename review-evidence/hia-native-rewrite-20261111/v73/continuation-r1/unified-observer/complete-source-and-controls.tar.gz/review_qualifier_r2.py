"""Read-only AST comparison; no qualification or child is executed."""
from pathlib import Path
from hashlib import sha256
import ast,json
BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
before=BASE/'pinned-pr888-source/tools/qualify_hia_selfhost.py'
after=BASE/'source-r1/tools/qualify_hia_selfhost.py'
a=ast.parse(before.read_text());b=ast.parse(after.read_text())
af={n.name:n for n in a.body if isinstance(n,ast.FunctionDef)}
bf={n.name:n for n in b.body if isinstance(n,ast.FunctionDef)}
def norm(n):return ast.dump(n,include_attributes=False)
assert set(af)==set(bf)
changed=[n for n in af if norm(af[n])!=norm(bf[n])]
assert set(changed)=={'invoke','_phase_inputs','qualification_phase','qualify'},changed
constants={}
for name in ['QUALIFICATION_WORKERS','QUALIFICATION_FAMILIES','PHASE_REFERENCE_FILES','CAPACITY','INVALID','NO_SPACE']:
 def assignment(tree):
  return next(n for n in tree.body if isinstance(n,ast.Assign) and any(
   isinstance(t,ast.Name) and t.id==name or isinstance(t,ast.Tuple) and any(isinstance(u,ast.Name) and u.id==name for u in t.elts)
   for t in n.targets))
 assert norm(assignment(a))==norm(assignment(b)),name
 constants[name]={'AST_equal':True,'expression':ast.unparse(assignment(a).value)}
 if name=='QUALIFICATION_FAMILIES':families=ast.literal_eval(assignment(a).value)
loops=[]
for labels in [('B1','B2','B3'),('M1','M2','M3')]:
 def loop(tree):
  return next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.iter,ast.Tuple)
   and [getattr(v,'value',None) for v in n.iter.elts]==list(labels))
 assert norm(loop(af['qualify']))==norm(loop(bf['qualify'])),labels
 loops.append({'labels':labels,'AST_equal':True,'sha256':sha256(norm(loop(af['qualify'])).encode()).hexdigest()})
def checks(tree):
 return {norm(n.targets[0].slice):norm(n.value) for n in ast.walk(tree)
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Subscript)
  and isinstance(n.targets[0].value,ast.Name) and n.targets[0].value.id=='checks'}
old_checks=checks(af['qualify']);new_checks=checks(bf['qualify'])
assert all(new_checks.get(k)==v for k,v in old_checks.items())
raw={'schema':'hia.linked-observer.qualifier-integration-source-review.v1',
 'old_sha256':sha256(before.read_bytes()).hexdigest(),'new_sha256':sha256(after.read_bytes()).hexdigest(),
 'functions_before':len(af),'functions_after':len(bf),'changed_functions':changed,
 'unchanged_functions':[n for n in af if n not in changed],
 'old_constants_unchanged':constants,'generation_loop_AST_equal':loops,
 'original_named_check_assignment_count':len(old_checks),'all_original_named_check_values_AST_equal':True,
 'additional_named_checks':sorted(set(new_checks)-set(old_checks)),
 'phase_families':len(families),'phase_instances':2*len(families),
 'source_only':True,'full_qualification_performed':False,
 'prior_readonly_harness_failure':'r1 ast.literal_eval did not admit the existing CAPACITY=1<<20 BinOp; source comparison itself did not fail'}
p=BASE/'evidence/qualifier-source-review-r2.json'
with p.open('x') as f:f.write(json.dumps(raw,indent=2,sort_keys=True)+'\n')
print(json.dumps(raw,indent=2,sort_keys=True))
