from pathlib import Path
import ast
BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
target=BASE/'source-r1/tools/hia_selfhost_linked_observer.py'
old=Path('/tmp/hia-linked-observer-local-v71-20261112-r1/source-r4/tools/hia_selfhost_linked_native_observer.py').read_text()
prefix=old[:old.index('def independent_reference(')]
prefix=prefix.replace('PACKER = ROOT / "examples/hia_bootstrap/linked_native_observer_packer.hiaasm"',
'''POLICY = ROOT / "examples/hia_bootstrap/linked_observer_policy.hiaasm"
PACKER = ROOT / "examples/hia_bootstrap/linked_observer_packer.hiaasm"
SOURCE_PATHS = (POLICY, PACKER, ROOT / "tools/generate_hia_linked_observer.py",
                ROOT / "tools/hia_linked_observer_bridge.S")''')
prefix=prefix.replace('Each call execs a fresh HIA-emitted adapter, dlopens',
    'Each call execs a fresh HIA-policy-directed adapter, dlopens')
runtime=old[old.index('def _runtime_interpreter('):old.index('def build(')]
transport=old[old.index('def execute('):]
transport=transport.replace('HIA-emitted-linked-ELF-observer-v1','HIA-policy-linked-ELF-observer-v2')
pinned=(BASE/'pinned-pr888-source/tools/hia_selfhost_linked_observer.py').read_text()
tree=ast.parse(pinned)
vm=ast.get_source_segment(pinned,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_vm'))
middle=r'''
def source_identity():
    return {p.relative_to(ROOT).as_posix(): digest(p.read_bytes()) for p in SOURCE_PATHS}


def vm_packer(checked, policy):
    from tools.generate_hia_linked_observer import reference_object
    expected = reference_object(policy)
    values, output, workspace, steps = _vm(checked, policy, b'\xa5'*len(expected), b'')
    if values != [len(expected)] or output != expected or workspace:
        raise AssertionError('linked observer VM did not reproduce every actual object byte')
    return output, {'input_bytes':len(policy),'input_sha256':digest(policy),
                    'output_bytes':len(output),'output_sha256':digest(output),
                    'result':values,'steps':steps,'every_output_byte_compared':True}


def independent_reference(*, before_B0=False):
    """All continuation actions and complete object bytes precede compilation."""
    from hepta.hia_agent_assembly import assemble_program
    before = source_identity()
    policy = assemble_program(POLICY.read_bytes())
    packer = assemble_program(PACKER.read_bytes())
    packing = []
    for actual in (b'\xc3', bytes(range(256))*17):
        _, receipt = vm_packer(packer, actual)
        packing.append(receipt)
    workspace, control = bytearray(512), bytes(512)
    struct.pack_into('<Q', workspace, 8, 1)
    request = _linked_frame(b'complete ELF remains opaque to policy',b'source\0\xff',17,40,90,None,11)
    observations = []
    def step(source, expected, feedback=()):
        nonlocal workspace, control
        for at, value in feedback:
            struct.pack_into('<Q',workspace,at,value)
        values, control, updated, steps = _vm(policy,source,control,bytes(workspace))
        workspace = bytearray(updated)
        if values != [expected]:
            raise AssertionError('linked observer VM continuation differs')
        observations.append({'action':expected,'output_hex':control.hex(),
                             'workspace_hex':updated.hex(),'steps':steps})
        return control
    first = step(b'',1)
    if struct.unpack_from('<8Q',first) != (5242937,10,256<<20,8<<20,16<<20,32,0,0):
        raise AssertionError('linked observer resource limits differ')
    step(request,2,((16,0),))
    path = step(request,3,((16,0),(24,7),(32,15)))
    if path[64:80] != b'/proc/self/fd/7\0':
        raise AssertionError('linked observer descriptor path differs')
    symbol = step(request,4,((16,0x12340000),))
    if symbol[64:67] != b'f0\0':
        raise AssertionError('linked observer symbol differs')
    step(request,5,((16,0),(32,0x12340100)))
    step(request,6,((16,0),))
    snapshot = step(request,8,((16,0),(24,11),(32,999999990),(40,12),(48,10),(56,0xdeadbeef0000002a)))
    if struct.unpack_from('<2Q',snapshot,32) != (11,18):
        raise AssertionError('linked observer return-snapshot custody differs')
    if snapshot[128:152] != b'HIAOBR03'+struct.pack('<QQ',0xdeadbeef0000002a,20):
        raise AssertionError('linked observer result/time framing differs')
    response = step(request,7,((16,0),))
    if response[128:152] != snapshot[128:152]:
        raise AssertionError('linked observer changed its committed response')
    final = step(request,0,((16,0),))
    if struct.unpack_from('<Q',final)[0] != 0:
        raise AssertionError('linked observer completion differs')
    if source_identity() != before:
        raise AssertionError('linked observer source changed during independent VM')
    return {'before_B0':before_B0,'before_native_compilation':True,'source_sha256':before,
            'policy_core_sha256':policy.sha256,'packer_core_sha256':packer.sha256,
            'policy_observations':observations,'packer_observations':packing,
            'every_output_byte_compared':True,
            'actual_policy_bytes_checked_again_after_native_compilation':True,
            'whole_stack_rewritten_in_hia':False,'all_input_equivalence_proved':False}


def build(directory, compiler, reference):
    """HIA emits policy and full ET_REL; the real linker resolves the foreign ABI."""
    from hepta.hia_agent_assembly import assemble_program
    from tools.qualify_hia_selfhost import compile_stage, invoke, observe_native_tool
    if (reference.get('before_native_compilation') is not True
            or reference.get('source_sha256') != source_identity()):
        raise ValueError('linked observer independent source identity differs')
    directory = Path(directory)
    policy, policy_receipt = compile_stage(directory,'linked-observer-policy',compiler,POLICY.read_bytes())
    packer, packer_receipt = compile_stage(directory,'linked-observer-packer',compiler,PACKER.read_bytes())
    actual_policy = policy.read_bytes()
    independent, vm_receipt = vm_packer(assemble_program(PACKER.read_bytes()),actual_policy)
    execution, raw = invoke(directory,'linked-observer-emit',packer,actual_policy)
    if (execution.get('status') != 'returned' or execution.get('abi_status') != 0
            or execution.get('core_u32') != len(independent) or not execution.get('source_unchanged')
            or raw[:len(independent)] != independent):
        raise AssertionError('linked observer native ET_REL differs from independent Core VM output')
    obj = directory/'linked-observer.o'
    obj.write_bytes(raw[:len(independent)])
    interpreter, runtime = _runtime_interpreter()
    executable = directory/'linked-observer.elf'
    observations = [
        observe_native_tool(directory,'linked-observer-object-readelf','readelf',['-W','-h','-S','-s','-r',obj]),
        observe_native_tool(directory,'linked-observer-link','ld',[
            '-m','elf_x86_64','-pie','-e','_start','--dynamic-linker',interpreter,
            '-z','defs','-z','noexecstack','-z','relro','-z','now','--build-id=none',obj,'-ldl','-lc','-o',executable]),
        observe_native_tool(directory,'linked-observer-executable-readelf','readelf',['-W','-h','-l','-s','-r','-d',executable]),
    ]
    if (source_identity() != reference['source_sha256']
            or digest(interpreter.read_bytes()) != runtime['interpreter_sha256']):
        raise AssertionError('linked observer source or loader changed during construction')
    image = executable.read_bytes(); executable.chmod(0o700)
    receipt = {'source_sha256':reference['source_sha256'],
        'compiler_sha256':digest(Path(compiler).read_bytes()),
        'policy_sha256':digest(actual_policy),'object_sha256':digest(independent),'object_bytes':len(independent),
        'executable_sha256':digest(image),'executable_bytes':len(image),
        'native_policy_compilation':policy_receipt,'native_packer_compilation':packer_receipt,
        'native_emission':execution,'actual_policy_vm_packing':vm_receipt,
        'independent_reference_before_B0':reference['before_B0'],
        'independent_reference_before_native_compilation':reference['before_native_compilation'],
        'native_tool_observations':observations,'runtime_loader':runtime,
        'target_loading':'complete sealed target shared object; RTLD_LOCAL|RTLD_NOW; dlsym(f0)',
        'lifecycle':'HIA policy; libc startup/exit; no eager dlclose; real signal termination',
        'production_activated':False,'whole_stack_rewritten_in_hia':False}
    (directory/'linked-observer-build.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    return executable, receipt


'''
source=prefix+vm+'\n\n'+middle+runtime+transport
compile(source,str(target),'exec');target.write_text(source)
print(target,len(source.encode()))
