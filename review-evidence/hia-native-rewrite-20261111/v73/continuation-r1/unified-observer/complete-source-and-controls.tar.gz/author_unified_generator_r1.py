"""Source construction checkpoint; not part of runtime or qualification."""
from pathlib import Path
import ast,json
BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
old=BASE/'pinned-pr888-source/tools/generate_hia_linked_observer.py'
parsed=ast.parse(old.read_text())
policy=next(ast.literal_eval(n.value) for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='POLICY_SOURCE' for t in n.targets))
changes=[]
def replace(before,after):
 global policy
 assert policy.count(before)==1,before
 policy=policy.replace(before,after);changes.append({'before':before,'after':after})
replace('        descriptor = uint(s, 48)\n','        descriptors = uint(s, 48)\n        descriptor = descriptors & 4294967295\n        snapshot = descriptors >> 32\n')
replace('        if descriptor != 18446744073709551615:\n            if descriptor < 3 or descriptor > 2147483647:\n                return finish(o, 2)\n',
'''        if snapshot < 3 or snapshot > 2147483647:
            return finish(o, 2)
        if descriptor != 4294967295:
            if descriptor < 3 or descriptor > 2147483647 or descriptor == snapshot:
                return finish(o, 2)
''')
replace('        put(w, 104, descriptor)\n','        put(w, 104, descriptor)\n        put(w, 112, snapshot)\n')
replace('        if get(w, 16) == 0:\n            return finish(o, 1)\n',
        '        if get(w, 16) == 0:\n            put(w, 0, 10)\n            return 9\n')
replace('        if get(w, 16) != 0 or get(w, 32) == 0:\n            return finish(o, 1)\n',
'''        if get(w, 16) != 0:
            return finish(o, 1)
        if get(w, 32) == 0:
            put(w, 0, 10)
            return 9
''')
replace('        if get(w, 104) == 18446744073709551615:\n','        if get(w, 104) == 4294967295:\n')
replace('''        arguments(o, w)
        put(w, 0, 7)
        return 7
    if phase == 7:
        if get(w, 16) != 0:
            return finish(o, 4)
        put(w, 0, 8)
        return 8
    if phase == 8:
        if get(w, 16) != 0:
            return finish(o, 1)
        return finish(o, 0)
''','''        arguments(o, w)
        put(o, 32, get(w, 112))
        put(o, 40, get(w, 80) + 1)
        put(w, 0, 7)
        return 8
    if phase == 7:
        if get(w, 16) != 0:
            return finish(o, 4)
        arguments(o, w)
        put(w, 0, 8)
        return 7
    if phase == 8:
        if get(w, 16) != 0:
            return finish(o, 4)
        return finish(o, 0)
    if phase == 10:
        if get(w, 16) != 0:
            return finish(o, 4)
        return finish(o, 1)
''')
meta=json.loads((BASE/'evidence/unified-authoring-r1/bridge.json').read_text())
head='''"""HIA continuation policy and complete ET_REL packer for linked observation.

The policy originates in the published linked observer and owns all private
frame admission, resource-limit values, foreign-action sequencing, response
construction and terminal decisions. The fixed Linux/SysV bridge preserves
libc startup/exit and the exact complete shared object lifetime. It exposes
physical loader, memory, time and write operations; it does not reimplement
the HIA state machine. A real system linker constructs the dynamic executable.
"""
from __future__ import annotations

from pathlib import Path
import struct
import subprocess
import tempfile

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_artifact_publication import document

ROOT = Path(__file__).resolve().parents[1]
IMPORTS = ("__libc_start_main", "dlopen", "dlsym", "dlerror", "exit")
RESPONSE_MAGIC = int.from_bytes(b'HIAOBR03', 'little')
FRAME_MAGIC = int.from_bytes(b'HIAOBS03', 'little')
'''
head+='BRIDGE = bytes.fromhex(\n'+''.join('    '+repr(meta['text_hex'][i:i+64])+'\n' for i in range(0,len(meta['text_hex']),64))+')\n'
head+='BRIDGE_RELOCATIONS = '+repr(tuple((r[0],r[2]) for r in meta['relocations']))+'\n'
head+='POLICY_HOLE = '+str(meta['policy_hole'])+'\nSTART_SIZE = '+str(meta['start_size'])+'\n'
head+='POLICY_SOURCE = '+repr(policy)+'\n'
tail=r"""

def policy_source():
    return (POLICY_SOURCE.replace('FRAME_MAGIC_VALUE', str(FRAME_MAGIC))
            .replace('RESPONSE_MAGIC_VALUE', str(RESPONSE_MAGIC))
            .replace('PATH_PREFIX_FIRST', str(int.from_bytes(b'/proc/se', 'little')))
            .replace('PATH_PREFIX_SECOND', str(int.from_bytes(b'lf/fd/', 'little'))))


def _parts():
    text = bytearray(BRIDGE)
    struct.pack_into('<i', text, POLICY_HOLE, len(text) - POLICY_HOLE - 4)
    names = ['', '_start', *IMPORTS]
    strings = bytearray(b'\0')
    positions = {'': 0}
    for name in names[1:]:
        positions[name] = len(strings)
        strings.extend(name.encode('ascii') + b'\0')
    symbols = [bytes(24), struct.pack('<IBBHQQ', 0, 3, 0, 1, 0, 0),
               struct.pack('<IBBHQQ', positions['_start'], 18, 0, 1, 0, START_SIZE)]
    symbol_at = {'_start': 2}
    for name in IMPORTS:
        symbol_at[name] = len(symbols)
        symbols.append(struct.pack('<IBBHQQ', positions[name], 18, 0, 0, 0, 0))
    relas = b''.join(struct.pack('<QQq', at, (symbol_at[name] << 32) | 4, -4)
                     for at, name in BRIDGE_RELOCATIONS)
    section_strings = b'\0.text\0.rela.text\0.symtab\0.strtab\0.shstrtab\0.note.GNU-stack\0'
    return bytes(text), relas, b''.join(symbols), bytes(strings), section_strings


def _header(section_offset):
    return struct.pack('<16sHHIQQQIHHHHHH', b'\x7fELF\x02\x01\x01' + bytes(9),
                       1, 62, 1, 0, 0, section_offset, 0, 64, 0, 0, 64, 7, 5)


def _sections(policy, rela_at, symbols_at, strings_at, shstrings_at, stack_at):
    text, relas, symbols, strings, section_strings = _parts()
    name = {key: section_strings.index(key.encode() + b'\0')
            for key in ('.text', '.rela.text', '.symtab', '.strtab', '.shstrtab', '.note.GNU-stack')}
    rows = [
        bytes(64),
        struct.pack('<IIQQQQIIQQ', name['.text'], 1, 6, 0, 64, len(text)+policy, 0, 0, 16, 0),
        struct.pack('<IIQQQQIIQQ', name['.rela.text'], 4, 64, 0, rela_at, len(relas), 3, 1, 8, 24),
        struct.pack('<IIQQQQIIQQ', name['.symtab'], 2, 0, 0, symbols_at, len(symbols), 4, 2, 8, 24),
        struct.pack('<IIQQQQIIQQ', name['.strtab'], 3, 0, 0, strings_at, len(strings), 0, 0, 1, 0),
        struct.pack('<IIQQQQIIQQ', name['.shstrtab'], 3, 0, 0, shstrings_at, len(section_strings), 0, 0, 1, 0),
        struct.pack('<IIQQQQIIQQ', name['.note.GNU-stack'], 1, 0, 0, stack_at, 0, 0, 0, 1, 0),
    ]
    return b''.join(rows)


def reference_object(policy):
    'Independent struct-based whole-object representation for actual bytes.'
    if type(policy) is not bytes or not policy or len(policy) > 1 << 20:
        raise ValueError('nonempty bounded actual policy image required')
    text, relas, symbols, strings, section_strings = _parts()
    raw = bytearray(bytes(64) + text + policy)
    raw.extend(bytes((-len(raw)) % 8))
    rela_at = len(raw); raw.extend(relas)
    symbols_at = len(raw); raw.extend(symbols)
    strings_at = len(raw); raw.extend(strings)
    shstrings_at = len(raw); raw.extend(section_strings)
    stack_at = len(raw)
    raw.extend(bytes((-len(raw)) % 8))
    section_offset = len(raw)
    raw.extend(_sections(len(policy), rela_at, symbols_at, strings_at, shstrings_at, stack_at))
    if len(raw) > 1 << 20:
        raise ValueError('observer object exceeds existing one MiB output capacity')
    raw[:64] = _header(section_offset)
    return bytes(raw)


def packer_source():
    text, relas, symbols, strings, section_strings = _parts()
    parts = [('prefix', _header(0) + text),
             ('tail', relas + symbols + strings + section_strings),
             ('sections', _sections(0, 0, 0, 0, 0, 0))]
    functions = []
    calls = {}
    for name, data in parts:
        names = []
        for group, begin in enumerate(range(0, len(data), 48 * 8)):
            function = f'emit_{name}_{group}'
            names.append(function)
            lines = [f'def {function}(o:mutbuf, base:u64) -> u64:']
            for at in range(begin, min(begin + 48 * 8, len(data)), 8):
                chunk = data[at:at+8]
                if any(chunk):
                    lines.append(f'    write(o, base + {at}, {int.from_bytes(chunk,"little")}, {len(chunk)})')
            lines.append('    return 0')
            functions.append('\n'.join(lines))
        calls[name] = names
    result = f'''def pack(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    policy = length(s)
    if policy == 0 or policy > 1048576:
        return 4294967295
    relas = ({64+len(text)} + policy + 7) & 18446744073709551608
    symbols = relas + {len(relas)}
    strings = symbols + {len(symbols)}
    shstrings = strings + {len(strings)}
    stack = shstrings + {len(section_strings)}
    sections = (stack + 7) & 18446744073709551608
    size = sections + 448
    if size > 1048576 or length(o) < size:
        return 4294967294
    i = 0
    while i < size:
        store(o, i, 0)
        i = i + 1
'''
    for key, base in (('prefix','0'), ('tail','relas'), ('sections','sections')):
        for function in calls[key]:
            result += f'    {function}(o, {base})\n'
    result += f'''    write(o, 40, sections, 8)
    write(o, sections + 96, {len(text)} + policy, 8)
    write(o, sections + 152, relas, 8)
    write(o, sections + 216, symbols, 8)
    write(o, sections + 280, strings, 8)
    write(o, sections + 344, shstrings, 8)
    write(o, sections + 408, stack, 8)
    i = 0
    while i < policy:
        store(o, {64+len(text)} + i, byte(s, i))
        i = i + 1
    return size
'''
    return result + '\n\n' + '\n\n'.join(functions) + POLICY_SOURCE[POLICY_SOURCE.index('\ndef write('):]


def assembled_bridge():
    'Assemble the independent oracle only in source tests, never building.'
    with tempfile.TemporaryDirectory(prefix='hia-linked-observer-reference-') as folder:
        obj = Path(folder)/'reference.o'
        subprocess.run(['as','--64',str(ROOT/'tools/hia_linked_observer_bridge.S'),'-o',str(obj)],
                       check=True,capture_output=True,timeout=30)
        raw = obj.read_bytes()
    header = struct.unpack_from('<16sHHIQQQIHHHHHH',raw)
    rows = [struct.unpack_from('<IIQQQQIIQQ',raw,header[6]+i*header[11]) for i in range(header[12])]
    r = rows[header[13]]; names = raw[r[4]:r[4]+r[5]]
    def string(data,at): return data[at:data.index(0,at)].decode('ascii')
    named = {string(names,r[0]):r for r in rows}
    text = named['.text']; table = named['.symtab']; r = rows[table[6]]
    strings = raw[r[4]:r[4]+r[5]]
    symbols = [struct.unpack_from('<IBBHQQ',raw,table[4]+i) for i in range(0,table[5],24)]
    values = {string(strings,row[0]):row for row in symbols}
    relas = []
    for row in rows:
        if row[1] == 4 and rows[row[7]] == text:
            for i in range(0,row[5],24):
                at,info,addend = struct.unpack_from('<QQq',raw,row[4]+i)
                if info & 0xffffffff != 4 or addend != -4:
                    raise AssertionError('foreign relocation representation differs')
                relas.append((at,string(strings,symbols[info>>32][0])))
    return (raw[text[4]:text[4]+text[5]],tuple(relas),values['policy_hole'][4],values['_start'][5])


def main():
    for name, source in (('linked_observer_policy',policy_source()), ('linked_observer_packer',packer_source())):
        path = ROOT/'examples/hia_bootstrap'/f'{name}.hiaasm'
        path.write_text(render_assembly(document(source,name)))
        print(path.name,path.stat().st_size)


if __name__ == '__main__':
    main()
"""
target=BASE/'source-r1/tools/generate_hia_linked_observer.py'
source=head+tail;compile(source,str(target),'exec');target.write_text(source)
(BASE/'evidence/unified-authoring-r1/policy-edits.json').write_text(json.dumps(changes,indent=2,sort_keys=True)+'\n')
print(target,len(source.encode()))
