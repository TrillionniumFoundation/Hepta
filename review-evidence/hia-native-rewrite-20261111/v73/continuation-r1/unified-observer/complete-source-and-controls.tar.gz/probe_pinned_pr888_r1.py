"""Pinned component differential; not PR-wide or matching-source qualification."""
from pathlib import Path
from hashlib import sha256
import ast, json, os, platform, shutil, struct, subprocess, sys, time, traceback

BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
ROOT=BASE/'pinned-pr888-source'
OUT=BASE/'evidence/pinned-pr888-r1'
COMPILER=BASE/'retained-8aade-CI-development-compiler.bin'
FIXTURE=Path('/tmp/hia-linked-observer-local-v71-20261112-r1/source-r4/tests/test_hia_selfhost_linked_native_observer.py')
OUT.mkdir(mode=0o700,parents=True,exist_ok=False)
os.umask(0o077)

def digest(b):return sha256(b).hexdigest()
def identity(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b),'mode':p.stat().st_mode&0o777}
def write(name,value):
 b=value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
 with (OUT/name).open('xb') as f:f.write(b)
def state():return {p.relative_to(ROOT).as_posix():identity(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
before=state();write('source-before.json',before)
held={str(p):identity(p) for p in (COMPILER,FIXTURE,Path(sys.executable).resolve(strict=True),Path(__file__))}
report={'schema':'hia.linked-observer.pinned-pr888.component-differential.v1','status':'HOLD',
 'scope':'DISTINCT_ENVIRONMENT_RETAINED_COMPILER_DEVELOPMENT',
 'source_scope':'eight exact acffa926 PR888 files over an explicit exact673 minimal import closure; not a full PR888 checkout',
 'pinned_component_ref':'acffa9262f31d073f8f0a6f0201eae201039f619','python':sys.version,
 'platform':platform.platform(),'cases':[], 'actual_HIA_compilation':False,
 'ordinary_Core_VM_before_native':False,'before_B0_actual':False,
 'current_source_cold_qualification':False,'PR_wide_qualification':False,
 'original_ai395_18_test_status':'UNKNOWN','original_ai395_18_replayed':False,
 'whole_native_delivery':False,'default_activation':False,'legacy_deletion':False,
 'supervision':{'mechanism':'GNU timeout outer command','seconds':600,'TERM_to_KILL_grace_seconds':3},
 'limits':{'child_wall_seconds':20,'CPU_seconds':10,'AS_bytes':256<<20,'stack_bytes':8<<20,'file_bytes':16<<20,'open_files':32}}
began=time.monotonic_ns()
try:
 assert held[str(COMPILER)]['sha256']=='81b6fad94493546b5bf3f858248f25b19aded88bf8f3aaad18140aa317dac109'
 assert held[str(FIXTURE)]['sha256']=='a87fc29b4428686b3e350901b13167a6b269ab0593b6716d0aa871e394a4612b'
 pinned=[json.loads(line) for line in (BASE/'pr888-pinned-inputs.jsonl').read_text().splitlines()]
 for row in pinned:assert before[row['path']]['sha256']==row['sha256'],row['path']
 report['pinned_files']=pinned
 report['removed_selector_names']=sorted(key for key in os.environ if key.startswith('HEPTA_HIA_'))
 for key in report['removed_selector_names']:os.environ.pop(key)
 os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.path.insert(0,str(ROOT))
 from tools import hia_selfhost_linked_observer as linked
 from tools import hia_selfhost_native_observer as native
 from tools import qualify_hia_selfhost as original
 from tools import generate_hia_linked_observer as generator
 from tools.generate_hia_artifact_publication import document
 from hepta.hia_agent_assembly import render_assembly
 assert Path(linked.__file__).resolve()==ROOT/'tools/hia_selfhost_linked_observer.py'
 original.NATIVE_OBSERVER=None
 for name,source in (('policy',generator.policy_source()),('packer',generator.packer_source())):
  assert getattr(linked,name.upper()).read_text()==render_assembly(document(source,'linked_observer_'+name))
 assert generator.assembled_bridge()==(generator.BRIDGE,generator.BRIDGE_HOLES)
 reference=linked.independent_reference()
 write('ordinary-Core-VM-reference.json',reference)
 report['ordinary_Core_VM_before_native']=True
 report['literal_before_B0_in_pinned_receipt_is_not_an_actual_new_bootstrap']=True
 build=OUT/'build';build.mkdir(mode=0o700)
 observer,receipt=linked.build(build,COMPILER,reference)
 report['actual_HIA_compilation']=True
 report['build_receipt']=identity(build/'linked-observer-build.json')
 report['observer']=identity(observer)
 # A retained source fixture with full actual ctor/f0/fini and independently
 # owned shared-map clone. No new semantic interpreter replaces either path.
 tree=ast.parse(FIXTURE.read_text())
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='lifetime_source']
 fixtures={'os':os};exec(compile(ast.Module(nodes,type_ignores=[]),str(FIXTURE),'exec'),fixtures)
 page=os.sysconf('SC_PAGE_SIZE')
 def library(folder,source):
  assembly=folder/'fixture.S';assembly.write_text(source)
  obj=folder/'fixture.o';image=folder/'fixture.so'
  original.observe_native_tool(folder,'fixture-as','as',['--64',assembly,'-o',obj])
  original.observe_native_tool(folder,'fixture-link','ld',['-m','elf_x86_64','-shared','-z','defs','-z','noexecstack','-z','relro','-z','now','--build-id=none',obj,'-lc','-o',image])
  return image
 def call_side(folder,fn):
  try:
   result,output=fn()
   return {'result':result,'output_bytes':len(output),'output_sha256':digest(output),'output_prefix_hex':output[:8].hex()}
  except BaseException as e:
   return {'exception':{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}}
 def observe(name,assembly,*,shared=False,initial=None,capacity=page):
  folder=OUT/name;folder.mkdir(mode=0o700);image=library(folder,assembly)
  old=folder/'old';new=folder/'new';old.mkdir(mode=0o700);new.mkdir(mode=0o700)
  kwargs=dict(capacity=capacity,workspace_size=0,workspace_fill=0,output_initial=initial,observe_trap_writes=shared)
  a=call_side(old,lambda:original.invoke(old,'call',image,b'',image_format='linked-selfhost',**kwargs))
  b=call_side(new,lambda:native.invoke(new,'call',observer,image,b'',image_format='linked-selfhost',**kwargs))
  for path,row in ((old,a),(new,b)):
   p=path/'events.bin';row['events_hex']=p.read_bytes().hex() if p.exists() else None
  fields=('status','result_u64','abi_status','core_u32','returncode','source_unchanged','output_unchanged','output_sha256')
  av={k:a.get('result',{}).get(k) for k in fields};bv={k:b.get('result',{}).get(k) for k in fields}
  equal=not a.get('exception') and not b.get('exception') and av==bv and a['output_sha256']==b['output_sha256'] and a['events_hex']==b['events_hex']
  row={'name':name,'image':identity(image),'old':a,'pinned':b,'same_observed_fields':equal,'shared':shared}
  (folder/'comparison.json').write_text(json.dumps(row,indent=2,sort_keys=True)+'\n');report['cases'].append(row)
 for kind,shared,initial in (('ordinary',False,None),('explicit-initial',False,b' '*page),('shared',True,b' '*page)):
  observe('normal-'+kind,fixtures['lifetime_source'](),shared=shared,initial=initial)
 observe('allowed-stderr',fixtures['lifetime_source'](stderr=True))
 for byte in (32,9,13,10):
  for where in (1,2,3):
   code=fixtures['lifetime_source'](noise=where).replace('stdout_byte: .ascii "!"','stdout_byte: .byte '+str(byte))
   observe('whitespace-'+str(byte)+'-'+str(where),code)
 ending=' pop rbx\n ret\nappend_event:'
 for kind,noise in (('exit',0),('exit-noise',3),('signal',0)):
  code=fixtures['lifetime_source'](noise=noise);assert code.count(ending)==1
  tail=' pop rbx\n'+(' ud2\n' if kind=='signal' else ' mov edi,23\n mov eax,231\n syscall\n ud2\n')+'append_event:'
  for shared in (False,True):observe('finalizer-'+kind+'-'+str(int(shared)),code.replace(ending,tail),shared=shared,initial=None if not shared else b' '*page)
 # An actual loader failure after ctor but before f0 must still finalize the
 # foreign image at process exit in the original Python/libc loader.
 code=fixtures['lifetime_source']().replace('.global f0','.global different').replace('.type f0,','.type different,').replace('\nf0:\n','\ndifferent:\n').replace('.size f0,.-f0','.size different,.-different')
 observe('missing-entry-finalization',code)
 # Process exit callbacks without a DSO handle are deliberately not dlclose
 # callbacks. This distinguishes libc exit from eager dlclose + syscall exit.
 code=fixtures['lifetime_source']();anchor='construct:\n sub rsp,8\n mov edi,67\n call append_event\n';assert code.count(anchor)==1
 code=code.replace(anchor,anchor+' lea rdi,[rip+process_exit_callback]\n xor esi,esi\n xor edx,edx\n call __cxa_atexit@PLT\n test eax,eax\n jne fixture_failure\n')
 code+='\n.text\nprocess_exit_callback:\n sub rsp,8\n mov edi,65\n call append_event\n add rsp,8\n ret\n'
 observe('process-exit-callback',code)
 report['observed_case_count']=len(report['cases'])
 report['differences']=sum(not row['same_observed_fields'] for row in report['cases'])
 report['equal_controls']=sum(row['same_observed_fields'] for row in report['cases'])
 report['status']='COMPONENT_OBSERVATIONS_COMPLETED'
except BaseException as error:
 report['harness_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 after=state();write('source-after.json',after);report['source_unchanged']=before==after
 report['held_inputs_before']=held;report['held_inputs_after']={p:identity(Path(p)) for p in held}
 report['held_inputs_unchanged']=report['held_inputs_after']==held
 if not report['source_unchanged'] or not report['held_inputs_unchanged']:report['status']='HOLD'
 report['elapsed_ns']=time.monotonic_ns()-began
 write('report.json',report)
print(json.dumps({k:report.get(k) for k in ('status','observed_case_count','differences','equal_controls','elapsed_ns','source_unchanged','held_inputs_unchanged','harness_error')},sort_keys=True),flush=True)
raise SystemExit(0 if report['status']=='COMPONENT_OBSERVATIONS_COMPLETED' else 1)
