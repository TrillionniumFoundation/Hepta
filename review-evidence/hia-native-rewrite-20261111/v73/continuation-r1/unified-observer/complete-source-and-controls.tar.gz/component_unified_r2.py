from pathlib import Path
from hashlib import sha256
import contextlib,importlib.util,json,os,platform,shutil,subprocess,sys,time,traceback,unittest
BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
ROOT=BASE/'source-r1'; OUT=BASE/'evidence/unified-component-r2'
OUT.mkdir(mode=0o700,exist_ok=False);os.umask(0o077)
COMPILER=BASE/'retained-8aade-CI-development-compiler.bin'
EXPECTED={'tools/generate_hia_linked_observer.py': 'd148bc1b22fc3aa698f9185e1bcb85cd9871c3bbf327ec17b9ff43c076f42954', 'tools/hia_selfhost_linked_observer.py': '4c89068e563340677badfaa016302d043a20c05020ed57ec26cb121d2b921cc0', 'tools/hia_linked_observer_bridge.S': '2c93f8d941a18baac5a3567945652edbba8d956461e2c2ec6b13e471e5c679c5', 'examples/hia_bootstrap/linked_observer_policy.hiaasm': 'effce43d19b4045e4502c8724f61db57ca54158f6f28eed99e0f40ae7e8f3d9e', 'examples/hia_bootstrap/linked_observer_packer.hiaasm': '298c83613c701a6095822727d09f3e014ec554417befcfbc9704ea97286cdf5f', 'tests/test_hia_selfhost_linked_observer.py': '066c6428736863bbadbe78f92f8c384d68c7e033f7a11a81737d316920f2bd02', 'docs/HIA_LINKED_OBSERVER.md': '9f1e8237a67b75c214f8e0d307b095285e47ebc8946d04ea9d33ca267501b2ad', 'tools/hia_selfhost_native_observer.py': 'ffda94627d2d42645bcb26748972cffb4c2598f22277070e74b2e1a76ebbf6e1', 'tools/qualify_hia_selfhost.py': 'f4f0eb0901d9a03d75ee7bca8ba62e40cb5edb9e88f99893a2e667aa7629d527'}
def digest(data):return sha256(data).hexdigest()
def record(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':digest(b),'mode':path.stat().st_mode&0o777}
def write(name,value):
 b=value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
 with (OUT/name).open('xb') as f:f.write(b)
def state():
 return {p.relative_to(ROOT).as_posix():record(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
started=time.monotonic_ns();before=state();write('source-before.json',before)
compiler_before=record(COMPILER)
python_path=Path(sys.executable).resolve(strict=True);python_before=record(python_path)
report={'schema':'hia.linked-observer.unified-complete-development-gate.v1','status':'HOLD',
 'scope':'DISTINCT_ENVIRONMENT_RETAINED_COMPILER_DEVELOPMENT',
 'source_scope':'explicit restored pin673 import closure; pinned PR888 HIA policy integrated with revised r4 lifecycle, real system linker, and unique published-named dispatch; not a complete Git checkout',
 'original_remote18_status':'UNKNOWN','original_remote18_replayed':False,
 'prior_local_gate':{'report_git_blob':'8abd851a4c64c0b6e23c388eb3707eadae925938',
  'status':'HOLD','tests':24,'pass':23,'fail':1,'reason':'sandbox refused ptrace before injected target entry; original retained'},
 'supervision':{'mechanism':'GNU timeout outer command','seconds':600,'TERM_to_KILL_grace_seconds':3},

 'python':sys.version,'platform':platform.platform(),'compiler_provenance':'8aade GitHub CI43098596489 artifact13891487322 B3; no matching-source cold qualification',
 'compiler_before':compiler_before,'python_before':python_before,
 'current_source_cold_qualification':False,'whole_native_delivery':False,'default_activation':False,
 'live_migration':False,'legacy_deletion':False,'limits':{'child_wall_seconds':20,'CPU_seconds':10,'AS_bytes':256<<20,'stack_bytes':8<<20,'file_bytes':16<<20,'open_files':32,'component_outer_seconds':600},
 'declared_tests':31,'tests_run':0,'failures':[],'errors':[],'skipped':[],'expected_failures':[],'unexpected_successes':[]}
try:
 for name,wanted in EXPECTED.items():assert before[name]['sha256']==wanted,('frozen product differs',name)
 assert compiler_before['bytes']==669494 and compiler_before['sha256']=='81b6fad94493546b5bf3f858248f25b19aded88bf8f3aaad18140aa317dac109'
 tools={}
 for name in ('as','ld','strace'):
  path=Path(shutil.which(name)).resolve(strict=True)
  actual=subprocess.run([str(path),'--version'],capture_output=True,timeout=30)
  write(name+'.version.stdout',actual.stdout);write(name+'.version.stderr',actual.stderr)
  assert actual.returncode==0
  tools[name]=record(path)
 report['tools_before']=tools
 report['removed_selector_names']=sorted(key for key in os.environ if key.startswith('HEPTA_HIA_'))
 for key in report['removed_selector_names']:os.environ.pop(key)
 os.environ['HEPTA_HIA_LINKED_OBSERVER_DEVELOPMENT_COMPILER']=str(COMPILER)
 os.environ['HEPTA_HIA_LINKED_OBSERVER_EVIDENCE']=str(OUT/'actual')
 os.environ['PYTHONDONTWRITEBYTECODE']='1'
 sys.path.insert(0,str(ROOT))
 with (OUT/'tests.log').open('x') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  spec=importlib.util.spec_from_file_location('linked_observer_unified_r2_frozen_tests',ROOT/'tests/test_hia_selfhost_linked_observer.py')
  module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
  suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(module.LinkedObserverSourceTests),
                           unittest.defaultTestLoader.loadTestsFromTestCase(module.LinkedObserverNativeTests)])
  assert suite.countTestCases()==31
  result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 report.update(tests_run=result.testsRun,failures=[{'test':str(t),'traceback':error} for t,error in result.failures],
  errors=[{'test':str(t),'traceback':error} for t,error in result.errors],
  skipped=[{'test':str(t),'reason':reason} for t,reason in result.skipped],
  expected_failures=[str(t) for t,_ in result.expectedFailures],
  unexpected_successes=[str(t) for t in result.unexpectedSuccesses])
 if result.wasSuccessful() and result.testsRun==31 and not any((result.skipped,result.expectedFailures,result.unexpectedSuccesses)):
  report['status']='PASS_DEVELOPMENT_COMPONENT'
except BaseException as error:
 report['harness_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 after=state();write('source-after.json',after);report['source_unchanged']=after==before
 report['compiler_after']=record(COMPILER);report['python_after']=record(python_path)
 report['held_inputs_unchanged']=report['compiler_after']==compiler_before and report['python_after']==python_before
 if 'tools_before' in report:
  report['tools_after']={name:record(Path(row['path'])) for name,row in report['tools_before'].items()}
  report['held_inputs_unchanged']&=report['tools_before']==report['tools_after']
 if not report['source_unchanged'] or not report['held_inputs_unchanged']:report['status']='HOLD'
 observations=OUT/'actual/candidate/observations.json'
 if observations.exists():report['component_observations']=json.loads(observations.read_bytes())
 report['elapsed_ns']=time.monotonic_ns()-started
 report['source_before']=record(OUT/'source-before.json');report['source_after']=record(OUT/'source-after.json')
 if (OUT/'tests.log').exists():report['test_log']=record(OUT/'tests.log')
 write('report.json',report)
print(json.dumps({k:report[k] for k in ('status','tests_run','declared_tests','source_unchanged','held_inputs_unchanged','elapsed_ns','failures','errors','skipped')},sort_keys=True),flush=True)
raise SystemExit(0 if report['status']=='PASS_DEVELOPMENT_COMPONENT' else 1)
