from pathlib import Path
BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
old=Path('/tmp/hia-linked-observer-local-v71-20261112-r1/source-r4/tests/test_hia_selfhost_linked_native_observer.py')
s=old.read_text()
s=s.replace('generate_hia_linked_native_observer','generate_hia_linked_observer').replace('hia_selfhost_linked_native_observer','hia_selfhost_linked_observer').replace('hia_linked_native_observer_reference.S','hia_linked_observer_bridge.S').replace('linked_native_observer_packer.hiaasm','linked_observer_packer.hiaasm')
s=s.replace('"LINKED_NATIVE_OBSERVER",None,create=True','"NATIVE_LINKED_OBSERVER",None,create=True')
s=s.replace('    "examples/hia_bootstrap/linked_observer_packer.hiaasm",','    "examples/hia_bootstrap/linked_observer_packer.hiaasm",\n    "examples/hia_bootstrap/linked_observer_policy.hiaasm",\n    "tools/generate_hia_artifact_publication.py",')
before='''        self.assertEqual(generator.PACKER.read_text(),render_assembly(generator.document()))
        checked=assemble_program(generator.PACKER.read_bytes()).as_dict()
        self.assertLessEqual(len(checked["functions"]),128)
        self.assertLessEqual(sum(len(f["blocks"]) for f in checked["functions"]),1536)
        self.assertLessEqual(sum(len(b["ops"]) for f in checked["functions"] for b in f["blocks"]),8192)
        self.assertLessEqual(max(len(f["blocks"]) for f in checked["functions"]),256)
        self.assertLessEqual(max(len(b["params"]) for f in checked["functions"] for b in f["blocks"]),16)'''
after='''        for name,authoring in (("policy",generator.policy_source()),("packer",generator.packer_source())):
            path=getattr(native,name.upper())
            self.assertEqual(path.read_text(),render_assembly(generator.document(authoring,"linked_observer_"+name)))
            checked=assemble_program(path.read_bytes()).as_dict()
            self.assertLessEqual(len(checked["functions"]),128)
            self.assertLessEqual(sum(len(f["blocks"]) for f in checked["functions"]),1536)
            self.assertLessEqual(sum(len(b["ops"]) for f in checked["functions"] for b in f["blocks"]),8192)
            self.assertLessEqual(max(len(f["blocks"]) for f in checked["functions"]),256)
            self.assertLessEqual(max(len(b["params"]) for f in checked["functions"] for b in f["blocks"]),16)'''
assert s.count(before)==1;s=s.replace(before,after)
before='''        expected=elf_contents(generator.reference_object())
        self.assertEqual(actual["text"],expected["text"])'''
after='''        policy=b"\\xc3"
        expected=elf_contents(generator.reference_object(policy))
        patched=bytearray(actual["text"])
        self.assertEqual(patched[generator.POLICY_HOLE:generator.POLICY_HOLE+4],bytes(4))
        struct.pack_into("<i",patched,generator.POLICY_HOLE,len(patched)-generator.POLICY_HOLE-4)
        self.assertEqual(bytes(patched)+policy,expected["text"])
        self.assertEqual(generator.assembled_bridge(),
            (generator.BRIDGE,generator.BRIDGE_RELOCATIONS,generator.POLICY_HOLE,generator.START_SIZE))'''
assert s.count(before)==1;s=s.replace(before,after)
s=s.replace('        cls.pids=[]','        cls.pids=[]\n        cls.policy_native_entries=0')
s=s.replace('"ordinary_vm_windows":len(cls.reference["vm_windows"]),','"ordinary_vm_full_packer_cases":len(cls.reference["packer_observations"]),\n             "ordinary_vm_policy_frames":len(cls.reference["policy_observations"]),\n             "native_policy_frames":cls.policy_native_entries,')
s=s.replace('        self.assertEqual((self.build_dir/"linked-native-observer.o").read_bytes(),generator.reference_object())',
'''        actual_policy=(self.build_dir/"linked-observer-policy.image.bin").read_bytes()
        self.assertEqual((self.build_dir/"linked-observer.o").read_bytes(),generator.reference_object(actual_policy))
        self.assertTrue(self.build["actual_policy_vm_packing"]["every_output_byte_compared"])''')
begin=s.index('        # Sensitive negative: remove only the signed-errno guard')
end=s.index('        outcomes=[]',begin)
s=s[:begin]+'''        # Sensitive transport negative: forge BOTH foreign feedback words as
        # success in a separate executable. HIA normally observes the full
        # negative errno and exact seal word; one missing bridge branch alone
        # cannot bypass its second independent seal check.
        raw=self.executable.read_bytes()
        prefix=bytes.fromhex("be0a04000031d2b8480000000f05")
        self.assertEqual(raw.count(prefix),1)
        at=raw.index(prefix)+len(prefix)
        self.assertEqual(raw[at:at+9],bytes.fromhex("498946204885c00f88"))
        self.assertEqual(raw[at+13:at+15],bytes.fromhex("31c0"))
        mutant=folder/"sensitive-forged-errno-feedback.elf"
        replacement=bytes.fromhex("49c746200f00000031c0")+b"\\x90"*5
        mutant.write_bytes(raw[:at]+replacement+raw[at+15:]);mutant.chmod(0o700)
        policy["sensitivity"]={"offset":at,"original_hex":raw[at:at+15].hex(),
                              "replacement_hex":replacement.hex(),
                              "scope":"deliberately forged trusted foreign feedback, not a sandbox claim",
                              "mutant_sha256":digest(mutant.read_bytes())}
'''+s[end:]
extra=r"""
    @contextmanager
    def native_policy(self):
        from hepta.hia_json_preflight_native import NativeHiaJsonImage
        raw=(self.build_dir/"linked-observer-policy.image.bin").read_bytes()
        image=NativeHiaJsonImage(raw,digest(raw))
        try:yield image
        finally:
            image._entry=None
            image._mapping.close()

    def policy_frame(self,image,wire,control,state):
        import ctypes
        buffers=[bytearray(b"A"*16+raw+b"Z"*16) for raw in (wire,control,state)]
        pointers=[ctypes.addressof(ctypes.c_char.from_buffer(raw))+16 for raw in buffers]
        action=image._entry(pointers[0],len(wire),pointers[1],len(control),pointers[2],len(state))
        type(self).policy_native_entries+=1
        for raw in buffers:
            self.assertEqual(raw[:16],b"A"*16);self.assertEqual(raw[-16:],b"Z"*16)
        self.assertEqual(bytes(buffers[0][16:-16]),wire)
        return [action],bytes(buffers[1][16:-16]),bytes(buffers[2][16:-16])

    def test_actual_policy_all_continuations_and_complete_bytes_match_independent_VM(self):
        from hepta.hia_agent_assembly import assemble_program
        checked=assemble_program(native.POLICY.read_bytes())
        request=native._linked_frame(b"complete ELF remains opaque to policy",b"source\0\xff",17,40,90,None,11)
        frames=[(b"",1,()),(request,2,((16,0),)),
            (request,3,((16,0),(24,7),(32,15))),
            (request,4,((16,0x12340000),)),(request,5,((16,0),(32,0x12340100))),
            (request,6,((16,0),)),
            (request,8,((16,0),(24,11),(32,999999990),(40,12),(48,10),(56,0xdeadbeef0000002a))),
            (request,7,((16,0),)),(request,0,((16,0),))]
        state=bytearray(512);struct.pack_into("<Q",state,8,1);control=bytes(512)
        observations=[]
        with self.native_policy() as image:
            for wire,action,feedback in frames:
                for at,value in feedback:struct.pack_into("<Q",state,at,value)
                vm,vo,vw,steps=native._vm(checked,wire,control,bytes(state))
                actual,ao,aw=self.policy_frame(image,wire,control,bytes(state))
                self.assertEqual((actual,ao,aw),(vm,vo,vw))
                self.assertEqual(actual,[action])
                observations.append({"action":action,"source_sha256":digest(wire),
                    "output_hex":ao.hex(),"workspace_hex":aw.hex(),"VM_steps":steps})
                control=ao;state=bytearray(aw)
        folder=self.folder("policy-positive-frames")
        (folder/"complete-frames.json").write_text(json.dumps(observations,indent=2,sort_keys=True)+"\n")
        self.assertEqual([x["action"] for x in observations],[1,2,3,4,5,6,8,7,0])

    def test_actual_policy_refusals_and_loader_diagnostic_are_HIA_decisions(self):
        from hepta.hia_agent_assembly import assemble_program
        checked=assemble_program(native.POLICY.read_bytes())
        good=native._linked_frame(b"ELF",b"x",0,0,0,None,11)
        cases=[(0,2,(),b"",0,64),(99,1,(),good,0,70)]
        for phase in (1,2,4,5,6,7,8,10):
            cases.append((phase,1,((16,(1<<64)-5),),good,0,1 if phase==4 else 4))
        cases += [(3,1,((16,0),),good,9,None),
                  (4,1,((16,0),(32,0)),good,9,None),
                  (10,1,((16,0),),good,0,1),
                  (2,1,((16,0),(24,7),(32,7)),good,0,4),
                  (2,1,((16,0),(24,7),(32,(1<<64)-1)),good,0,4)]
        for bad in (b"",good[:-1],good+b"x",b"BADMAGIC"+good[8:]):
            cases.append((1,1,(),bad,0,2))
        for at,values in ((48,(0,1,2,2147483648,0xfffffffe,11)),(52,(0,1,2,2147483648,0xffffffff))):
            for value in values:
                bad=bytearray(good);struct.pack_into("<I",bad,at,value)
                cases.append((1,1,(),bytes(bad),0,2))
        observations=[]
        with self.native_policy() as image:
            for phase,argc,feedback,wire,action,status in cases:
                state=bytearray(512);struct.pack_into("<2Q",state,0,phase,argc)
                for at,value in feedback:struct.pack_into("<Q",state,at,value)
                vm,vo,vw,steps=native._vm(checked,wire,bytes(512),bytes(state))
                actual,ao,aw=self.policy_frame(image,wire,bytes(512),bytes(state))
                self.assertEqual((actual,ao,aw),(vm,vo,vw));self.assertEqual(actual,[action])
                if status is not None:self.assertEqual(struct.unpack_from("<Q",ao)[0],status)
                observations.append({"phase":phase,"action":action,"status":status,
                    "source_hex":wire.hex(),"output_hex":ao.hex(),"workspace_hex":aw.hex(),"VM_steps":steps})
            for output,state in ((bytes(511),bytes(512)),(bytes(512),bytes(511))):
                vm,vo,vw,_=native._vm(checked,b"",output,state)
                actual,ao,aw=self.policy_frame(image,b"",output,state)
                self.assertEqual((actual,ao,aw),(vm,vo,vw));self.assertEqual(actual,[70])
        folder=self.folder("policy-refusal-frames")
        (folder/"complete-frames.json").write_text(json.dumps(observations,indent=2,sort_keys=True)+"\n")

    def test_missing_entry_and_process_exit_callbacks_keep_original_lifecycle(self):
        folder=self.folder("process-lifetime")
        source=lifetime_source().replace('.global f0','.global different').replace('.type f0,','.type different,').replace('\nf0:\n','\ndifferent:\n').replace('.size f0,.-f0','.size different,.-different')
        image=assemble(folder,"missing-f0",source,shared=True)
        pair=folder/"missing";pair.mkdir()
        _,new,out=self.pair(pair,image,capacity=4096,workspace_size=0,workspace_fill=0)
        self.assertEqual((new["status"],new["returncode"],out),("child_failed",1,b""))
        for side in ("old","new"):self.assertEqual((pair/side/"events.bin").read_bytes(),b"CD")
        source=lifetime_source();anchor='construct:\n sub rsp,8\n mov edi,67\n call append_event\n'
        self.assertEqual(source.count(anchor),1)
        source=source.replace(anchor,anchor+' lea rdi,[rip+process_exit_callback]\n xor esi,esi\n xor edx,edx\n call __cxa_atexit@PLT\n test eax,eax\n jne fixture_failure\n')
        source+='\n.text\nprocess_exit_callback:\n sub rsp,8\n mov edi,65\n call append_event\n add rsp,8\n ret\n'
        image=assemble(folder,"exit-callback",source,shared=True)
        pair=folder/"exit";pair.mkdir()
        _,new,_=self.pair(pair,image,capacity=4096,workspace_size=0,workspace_fill=0)
        self.assertEqual(new["status"],"returned")
        for side in ("old","new"):self.assertEqual((pair/side/"events.bin").read_bytes(),b"CFAD")

    def test_selected_dispatch_has_no_fallback_and_seed_remains_independent(self):
        folder=self.folder("selected-dispatch")
        image=foreign_bytes(folder,"scalar",bytes.fromhex("b8 25 00 00 00 c3"))
        selected=folder/"selected";selected.mkdir()
        seed=folder/"seed";seed.mkdir()
        with patch.object(original,"NATIVE_LINKED_OBSERVER",self.executable):
            observed,out=original.invoke(selected,"call",image,b"",image_format="linked-selfhost",capacity=0,workspace_size=0)
            independent,raw=original.invoke(seed,"call",image,b"",image_format="seed-shared",capacity=0,workspace_size=0)
        self.assertEqual((observed["status"],observed["core_u32"],out),("returned",37,b""))
        self.assertTrue(observed["fresh_native_exec"]);self.assertNotIn("transport",independent)
        self.assertEqual((independent["core_u32"],raw),(37,b""))
        with patch.object(original,"NATIVE_LINKED_OBSERVER",folder/"missing"), \
             patch.object(subprocess,"run",side_effect=AssertionError("no fallback child")) as child:
            with self.assertRaises(FileNotFoundError):
                original.invoke(folder,"no-fallback",image,b"",image_format="linked-selfhost",capacity=0,workspace_size=0)
        child.assert_not_called()
        # The published shared invoke API has one linked route as well.
        from tools.hia_selfhost_native_observer import invoke as generic_invoke
        routed=folder/"shared-api";routed.mkdir()
        result,_=generic_invoke(routed,"call",self.executable,image,b"",image_format="linked-selfhost",capacity=0,workspace_size=0,workspace_fill=0)
        self.assertEqual((result["status"],result["core_u32"]),("returned",37))

    def test_phase_manifest_binds_actual_linked_observer_and_rejects_drift(self):
        folder=self.folder("phase-inputs")
        for name,raw in (("native-observer.elf",b"flat held bytes"),("linked-observer.elf",self.executable_bytes),
                         ("modified-selfhost.hiaasm",b"modified source"),("independent-names-reference.json",b"{}")):
            (folder/name).write_bytes(raw)
        inputs=original._phase_inputs(folder,"names",self.compiler,"original")
        self.assertEqual(set(inputs),{"native_observer","linked_observer","compiler","source","sample","modified_source","reference"})
        self.assertEqual(inputs["linked_observer"]["sha256"],digest(self.executable_bytes))
        self.assertEqual(original._read_phase_inputs(inputs)["linked_observer"],self.executable_bytes)
        (folder/"linked-observer.elf").write_bytes(self.executable_bytes+b"x")
        with self.assertRaisesRegex(ValueError,"input changed: linked_observer"):
            original._read_phase_inputs(inputs)
        self.assertEqual(len(original.QUALIFICATION_FAMILIES),19)

    def test_actual_packer_refusal_and_short_output_are_transactional(self):
        import ctypes
        from hepta.hia_agent_assembly import assemble_program
        from hepta.hia_json_preflight_native import NativeHiaJsonImage
        raw=(self.build_dir/"linked-observer-packer.image.bin").read_bytes()
        image=NativeHiaJsonImage(raw,digest(raw))
        checked=assemble_program(native.PACKER.read_bytes())
        try:
            for source,output,status in ((b"",b"UNCHANGED",0xffffffff),
                    (b"\xc3",b"x"*(len(generator.reference_object(b"\xc3"))-1),0xfffffffe)):
                vm,vo,vw,_=native._vm(checked,source,output,b"")
                actual,ao,aw=self.policy_frame(image,source,output,b"")
                self.assertEqual((actual,ao,aw),(vm,vo,vw))
                self.assertEqual((actual,ao,aw),([status],output,b""))
        finally:
            image._entry=None;image._mapping.close()

    def test_timeout_kills_and_reaps_actual_child_and_closes_descriptors(self):
        folder=self.folder("native-timeout")
        image=assemble(folder,"blocks",'''
.text
.global f0
f0:
 sub $8,%rsp
 mov $39,%eax
 syscall
 mov %rax,(%rsp)
 mov $1,%edi
 mov %rsp,%rsi
 mov $8,%edx
 mov $1,%eax
 syscall
1:
 mov $34,%eax
 syscall
 jmp 1b
.section .note.GNU-stack,"",@progbits
''',shared=True)
        before=len(list(Path("/proc/self/fd").iterdir()))
        with native.output_snapshot(0) as snapshot:
            request=native._linked_frame(image.read_bytes(),b"",0,0,0,None,snapshot)
            with self.assertRaises(subprocess.TimeoutExpired) as observed:
                native.execute(self.executable_bytes,request,cwd=folder,timeout=.1,snapshot_fd=snapshot)
            pid=int.from_bytes(observed.exception.stdout,"little")
            self.assertGreater(pid,1)
            with self.assertRaises(ProcessLookupError):os.kill(pid,0)
            self.assertIsNone(native.read_output_snapshot(snapshot,0))
        self.assertEqual(len(list(Path("/proc/self/fd").iterdir())),before)

"""
s=s.replace('\n\nif __name__=="__main__":', '\n'+extra+'\nif __name__=="__main__":')
target=BASE/'source-r1/tests/test_hia_selfhost_linked_observer.py';compile(s,str(target),'exec');target.write_text(s);print(target,len(s.encode()))
