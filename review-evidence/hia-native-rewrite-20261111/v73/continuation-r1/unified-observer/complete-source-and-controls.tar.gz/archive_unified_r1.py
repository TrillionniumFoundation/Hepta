"""Preserve all written source and control files; no source mutation."""
from pathlib import Path
from hashlib import sha256,sha1
import io,json,stat,tarfile
BASE=Path('/tmp/hia-linked-observer-unified-v71-20261112-r1')
OUT=BASE/'archives';OUT.mkdir(mode=0o700,exist_ok=False)
archive=OUT/'linked-observer-unified-source-and-controls-r1.tar.gz'
paths=[p for p in sorted(BASE.rglob('*')) if OUT not in p.parents and p!=OUT]
rows=[]
for p in paths:
 st=p.lstat();mode=stat.S_IMODE(st.st_mode)
 if p.is_symlink():raise AssertionError(('unexpected symlink',p))
 if p.is_dir():rows.append({'path':p.relative_to(BASE).as_posix(),'type':'directory','mode':mode})
 elif p.is_file():
  raw=p.read_bytes();rows.append({'path':p.relative_to(BASE).as_posix(),'type':'file','mode':mode,'bytes':len(raw),'sha256':sha256(raw).hexdigest()})
 else:raise AssertionError(('unexpected entry',p))
manifest={'schema':'hia.linked-observer.unified-raw-custody.v1','scope':'all actually written files in the owned new unified scope',
 'current_component':'31/31 retained-compiler DEVELOPMENT; not current-source cold or full repository qualification',
 'preserved_originals':['exact PR888 component24 cases /20 differences','unified smoke24/24','componentr1 first31/31 plus original mixed counter label','componentr2 final31/31 split41policy2packer','source generation and read-only harness error observations'],
 'not_reclassified':['old ai39518 UNKNOWN','old r4 ptrace sandbox refusal','old r3 differences'],
 'external_prior_artifacts':{'r4_archive_blob':'187cf02ef7a1acd067d45d8ecefe5125401bd618','r3_archive_wrapper':'882acb921fae9fdf8a8723102f78257f7768a644'},
 'source_packet_blob':'6a5a40f4262c55b6932eec8c7c8cd69ae3994c8e','files':rows}
body=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 info=tarfile.TarInfo('MANIFEST.json');info.mode=0o600;info.size=len(body);info.mtime=0
 tar.addfile(info,io.BytesIO(body))
 for row in rows:
  p=BASE/row['path'];info=tarfile.TarInfo(row['path']);info.mode=row['mode'];info.mtime=0
  if row['type']=='directory':info.type=tarfile.DIRTYPE;tar.addfile(info)
  else:
   raw=p.read_bytes();assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'],row['path']
   info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 assert tar.extractfile(members[0]).read()==body
 for row,member in zip(rows,members[1:]):
  assert member.name==row['path'] and member.mode==row['mode'],row['path']
  if row['type']=='directory':assert member.isdir()
  else:
   raw=tar.extractfile(member).read();assert member.isfile() and len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'],row['path']
   current=(BASE/row['path']).read_bytes();assert current==raw,row['path']
raw=archive.read_bytes()
receipt={'schema':'hia.linked-observer.unified-archive-receipt.v1','path':str(archive),'bytes':len(raw),'sha256':sha256(raw).hexdigest(),
 'git_blob_sha1':sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
 'members':len(rows)+1,'uncompressed_file_bytes':sum(r.get('bytes',0) for r in rows)+len(body),
 'manifest_sha256':sha256(body).hexdigest(),'all_members_size_sha_mode_type_verified':True,'all_original_files_unchanged':True}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,sort_keys=True))
