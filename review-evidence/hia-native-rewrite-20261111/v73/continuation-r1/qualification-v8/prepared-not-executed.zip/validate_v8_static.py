"""AST and byte-identity checks only: never imports or executes the runner."""
from __future__ import annotations

import ast
from hashlib import sha256
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
BASE = Path('/tmp/hia-root-v71-20261112-dda7-w_b7tdde/candidate-8b9-verified-source')
NORM = Path('/tmp/hia-normalization-permanent-r9-development-20261112-r3/source')
OBSERVER = Path('/tmp/hia-linked-observer-unified-v71-20261112-r1/source-r1')
RECEIPTS = Path('/workspace/scratch/hia-receipt-closure-8b9-20261112-r1/source')
checks = []


def check(name, condition, **details):
    if not condition:
        raise AssertionError(name)
    checks.append({'name': name, 'passed': True, **details})


def tree(path):
    raw = path.read_bytes()
    compile(raw, str(path), 'exec')
    return ast.parse(raw)


def assignments(node, name):
    return [item.value for item in ast.walk(node)
            if isinstance(item, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == name for target in item.targets)]


def one_assignment(node, name):
    values = assignments(node, name)
    assert len(values) == 1, name
    return values[0]


def function(node, name):
    values = [item for item in ast.walk(node) if isinstance(item, ast.FunctionDef) and item.name == name]
    assert len(values) == 1, name
    return values[0]


def dump(node):
    return ast.dump(node, include_attributes=False)


def keyword(call, name):
    values = [item.value for item in call.keywords if item.arg == name]
    assert len(values) == 1, name
    return ast.literal_eval(values[0])


def calls(node, name):
    return [item for item in ast.walk(node) if isinstance(item, ast.Call)
            and isinstance(item.func, ast.Name) and item.func.id == name]


def method_count(path, cls=None):
    module = tree(path)
    return sum(1 for item in module.body if isinstance(item, ast.ClassDef)
               and (cls is None or item.name == cls) for method in item.body
               if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'))


old = tree(ROOT / 'original_run_hia_qualification_v7.py')
new = tree(ROOT / 'run_hia_qualification_v8.py')
originals = json.loads((ROOT / 'original-inputs.json').read_bytes())
for row in originals:
    original = Path(row['source']).read_bytes()
    copy = (ROOT / row['copy']).read_bytes()
    check('unchanged-original-' + row['copy'], original == copy
          and len(copy) == row['bytes'] and sha256(copy).hexdigest() == row['sha256'])
py_files = sorted(ROOT.glob('*.py'))
for path in py_files:
    tree(path)
check('all-python-files-parse-and-compile-without-execution', True, files=[path.name for path in py_files])
groups = ast.literal_eval(one_assignment(old, 'groups'))
check('all-original-component-groups-identical', len(groups) == 27
      and dump(one_assignment(new, 'groups')) == dump(one_assignment(old, 'groups')),
      groups=list(groups), groups_count=len(groups))
check('original-full-discovery-subprocess-code-identical',
      ast.literal_eval(one_assignment(function(old, 'suite'), 'source'))
      == ast.literal_eval(one_assignment(function(new, 'suite'), 'source')))
check('original-source-reproduction-code-identical',
      ast.literal_eval(assignments(old, 'reproduce_code')[0])
      == ast.literal_eval(assignments(new, 'reproduce_code')[0]))
check('pinned-source-function-identical', dump(function(old, '_pinned_state')) == dump(function(new, '_pinned_state')))

run_old, run_new = function(old, 'run'), function(new, 'run')
check('ordinary-timeout-unchanged', ast.literal_eval(run_old.args.kw_defaults[0]) == 1800
      and ast.literal_eval(run_new.args.kw_defaults[0]) == 1800)
suite_run = calls(function(new, 'suite'), 'run')
check('full-and-component-suite-timeouts-unchanged', len(suite_run) == 1
      and dump([kw.value for kw in suite_run[0].keywords if kw.arg == 'timeout'][0])
      == dump(ast.parse('5400 if discover else 1800', mode='eval').body))
cold_calls = [call for call in calls(new, 'run') if call.args and isinstance(call.args[0], ast.Constant)
              and call.args[0].value == 'cold']
check('cold-outer-timeout-unchanged', len(cold_calls) == 1 and keyword(cold_calls[0], 'timeout') == 240)
cold_source = (BASE / 'tools/replay_hia_selfhost_cold.py').read_bytes()
cold_ast = ast.parse(cold_source)
owners = calls(cold_ast, 'run_owned')
check('source-cold-original-internal-timeouts', len(owners) == 1
      and keyword(owners[0], 'qualification_seconds') == 180
      and keyword(owners[0], 'cleanup_seconds') == 3,
      source_sha256=sha256(cold_source).hexdigest())
check('cold-readback-admission-precedes-compiler-selection',
      new is not None and (ROOT / 'run_hia_qualification_v8.py').read_text().index('cold_compiler_admission = admit_fresh_cold_compiler(cold_raw)')
      < (ROOT / 'run_hia_qualification_v8.py').read_text().index('environment.update(compiler_selectors)'))
admit = function(new, 'admit_fresh_cold_compiler')
check('actual-cold-admission-used', len(calls(admit, 'admit_cold_build')) == 1)

family = ast.literal_eval(one_assignment(new, 'COLD_REPORT_FAMILIES'))
configured = {'HEPTA_HIA_' + name + '_COLD_REPORT' for name in family}
found = set()
for base in (BASE, NORM, OBSERVER):
    for directory in ('tests', 'hepta', '.github/workflows'):
        if not (base / directory).exists():
            continue
        for path in (base / directory).rglob('*'):
            if path.is_file() and path.suffix in {'.py', '.yml'}:
                found.update(re.findall(r'HEPTA_HIA_[A-Z0-9_]+_COLD_REPORT', path.read_text()))
negative_controls = {'HEPTA_HIA_FUNCTION_SHAPE_WRONG_COLD_REPORT',
                     'HEPTA_HIA_PROGRAM_SHAPE_WRONG_COLD_REPORT'}
check('complete-current-cold-selector-coverage', len(family) == len(set(family)) == 44
      and found - negative_controls == configured,
      configured=sorted(configured), deliberately_wrong_test_names=sorted(found & negative_controls))
environment_ast = function(new, 'qualification_environment')
environment_text = ast.unparse(environment_ast)
check('inherited-development-manifest-cold-and-receipt-compiler-choices-cleared',
      all(token in environment_text for token in (
          "'_DEVELOPMENT_'", "'_DEVELOPMENT'", "'_MANIFEST'", "'_COLD_REPORT'",
          "'HEPTA_HIA_COMPILE_RECEIPT_COMPILER'", "'HEPTA_HIA_COMPILE_RECEIPT_COMPILER_SHA256'")))
new_evidence = {
    'HEPTA_HIA_LINKED_OBSERVER_EVIDENCE': 'linked-observer',
    'HEPTA_HIA_COMPILE_RECEIPT_OBSERVATIONS': 'compile-receipts',
    'HEPTA_HIA_PROGRAM_NORMALIZATION_EVIDENCE': 'normalization',
    'HEPTA_HIA_CORE_JSON_BYTES_EVIDENCE': 'core-json-bytes',
    'HEPTA_HIA_NOMINAL_JSON_EVIDENCE': 'nominal-json',
}
evidence_tuples = [ast.literal_eval(item) for item in ast.walk(run_new)
                   if isinstance(item, ast.Tuple) and len(item.elts) == 2
                   and all(isinstance(value, ast.Constant) and isinstance(value.value, str) for value in item.elts)]
check('per-group-exclusive-evidence-names-for-new-families',
      all((key, value) in evidence_tuples for key, value in new_evidence.items())
      and "name + '-' + suffix" in ast.unparse(run_new), selectors=new_evidence)

linked_count = method_count(OBSERVER / 'tests/test_hia_selfhost_linked_observer.py')
receipt_count = sum(method_count(RECEIPTS / 'tests' / name) for name in (
    'test_hia_original_select_fragments.py', 'test_hia_agent_identity_source_binding.py',
    'test_hia_compile_receipt_binding.py'))
a_count = (method_count(NORM / 'tests/test_hia_program_normalization_native.py', 'ProgramNormalizationNativeTests')
           + 1 + method_count(NORM / 'tests/test_hia_core_json_bytes_native.py', 'CoreJSONBytesNativeTests')
           + method_count(NORM / 'tests/test_hia_nominal_json_native.py', 'NominalJSONNativeTests'))
check('new-exact-component-inventories', linked_count == 31 and receipt_count == 19 and a_count == 33,
      linked=linked_count, source_select_compile_receipts=receipt_count, normalization_A=a_count)
expected_counts = [keyword(call, 'expected_tests') for call in calls(new, 'suite')
                   if any(kw.arg == 'expected_tests' for kw in call.keywords)]
check('explicit-new-count-admission', sorted(expected_counts) == [1, 19, 31, 33], expected_counts=expected_counts)

wrapper = (ROOT / 'run_python_frame_observations.py').read_bytes()
wrapper_ast = ast.parse(wrapper)
child = ast.literal_eval(one_assignment(wrapper_ast, 'CHILD')).encode()
check('original-P-wrapper-and-CHILD-exact-bytes',
      sha256(wrapper).hexdigest() == '666d8198a171e6db723860606d337600a362557d9526bc5eab431fe376ab7ac5'
      and len(child) == 2326
      and sha256(child).hexdigest() == '416b082d24b997246f6e2eb2dd94103947517684391670becf14ea2e085a6718')
offsets = [ast.literal_eval(node.iter) for node in ast.walk(wrapper_ast)
           if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == 'offset']
p_calls = [call for call in calls(new, 'run') if call.args and isinstance(call.args[0], ast.Constant)
           and call.args[0].value == 'normalization-P']
child_calls = [call for call in ast.walk(wrapper_ast) if isinstance(call, ast.Call)
               and isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name)
               and call.func.value.id == 'subprocess' and call.func.attr == 'run']
check('P-original-offsets-and-90-10-timeouts', offsets == [(32, 24, 16, 12, 8, 4)]
      and len(p_calls) == 1 and keyword(p_calls[0], 'timeout') == 90
      and len(child_calls) == 1 and keyword(child_calls[0], 'timeout') == 10)

preflight_ast = tree(ROOT / 'check_normalization_note_reference.py')
note_ast = tree(NORM / 'tests/test_hia_cpython_note_packer_native.py')
b_test = function(note_ast, 'test_original_35_hosted_mechanism_controls_on_HIA_produced_bytes')
original_command_calls = [call for call in ast.walk(b_test) if isinstance(call, ast.Call)
                          and isinstance(call.func, ast.Attribute) and call.func.attr == '_command']
original_flags = {call.args[0].value: [item.value for item in call.args[1].elts if isinstance(item, ast.Constant)]
                  for call in original_command_calls}
new_commands = one_assignment(preflight_ast, 'commands')
new_flags = {item.elts[0].value: [arg.value for arg in item.elts[1].elts if isinstance(arg, ast.Constant)]
             for item in new_commands.elts}
preflight_runs = [call for call in ast.walk(preflight_ast) if isinstance(call, ast.Call)
                  and isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name)
                  and call.func.value.id == 'subprocess' and call.func.attr == 'run']
check('B-prerequisite-original-compiler-linker-flags-and-30-second-limits',
      new_flags['compile'] == original_flags['old-reference-compile']
      and new_flags['link'] == original_flags['old-reference-link']
      and len(preflight_runs) == 1 and keyword(preflight_runs[0], 'timeout') == 30
      and keyword([call for call in ast.walk(function(note_ast, '_command'))
                   if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                   and call.func.attr == 'run'][0], 'timeout') == 30,
      flags=new_flags)
check('B-prerequisite-exact-historical-image',
      ast.literal_eval(one_assignment(preflight_ast, 'EXPECTED_BYTES')) == 260
      and ast.literal_eval(one_assignment(preflight_ast, 'EXPECTED_SHA256'))
      == 'e82fd51964ce25990f24e723fb0b3270b2e8b69c7fdc2e1b3999648df070db61')

parent = {child: node for node in ast.walk(new) for child in ast.iter_child_nodes(node)}
discovery_calls = [call for call in calls(new, 'suite') if any(kw.arg == 'discover' for kw in call.keywords)]
ancestors = []
node = discovery_calls[0]
while node in parent:
    node = parent[node]
    if isinstance(node, ast.If):
        ancestors.append(ast.unparse(node.test))
check('full-discovery-unfiltered-and-not-gated-by-B', len(discovery_calls) == 1
      and keyword(discovery_calls[0], 'discover') is True and ancestors == ['a.full', 'cold_ok'],
      conditions=ancestors)
text = (ROOT / 'run_hia_qualification_v8.py').read_text()
check('B-prerequisite-HOLD-does-not-gate-A-or-P',
      text.index("a_name = 'normalization-A'") < text.index("p_output = out / 'normalization-P-observations'")
      < text.index("b_preflight_output = out / 'normalization-B-reference-prerequisite'")
      and "ok = b_outcome['passed'] and ok" in text)
check('final-source-harness-and-input-preservation-required',
      "all_passed = ok and preserved and harness_preserved and held_inputs_preserved" in text)
check('whole-normalization-and-physical-recursion-remain-unqualified',
      "'normalization_physical_recursion_qualified': False" in text
      and "'normalization_whole_owner_qualified': False" in text
      and "'whole_native_delivery_qualified': False" in text)

files = {path.name: {'bytes': len(path.read_bytes()), 'sha256': sha256(path.read_bytes()).hexdigest()}
         for path in sorted(ROOT.iterdir()) if path.is_file() and path.suffix in {'.py', '.patch'}}
report = {'schema': 'hepta.hia.qualification-v8-static-review.v1',
          'status': 'AST_AND_BYTE_IDENTITY_PASS_NOT_EXECUTED', 'checks': checks,
          'checks_passed': len(checks), 'checks_total': len(checks), 'files': files,
          'python': sys.version, 'runner_executed': False, 'qualification_started': False,
          'new_compile_count': 0, 'native_tests_executed': 0, 'source_contract_modified': False,
          'product_refs_modified': False}
raw = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
(ROOT / 'STATIC-REVIEW.json').write_bytes(raw)
print(json.dumps({'status': report['status'], 'checks': len(checks), 'bytes': len(raw),
                  'sha256': sha256(raw).hexdigest()}, sort_keys=True))
