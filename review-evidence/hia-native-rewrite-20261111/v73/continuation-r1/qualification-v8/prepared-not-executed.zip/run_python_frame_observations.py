"""New-host r9 near-Python-frame observations; old remote r8 task stays unknown."""
from __future__ import annotations
import argparse,hashlib,json,os,subprocess,sys,sysconfig,time,traceback
from pathlib import Path
CHILD="\nimport hashlib,json,os,sys\nfrom pathlib import Path\nsource=Path(sys.argv[1]);manifest=Path(sys.argv[2]);offset=int(sys.argv[3])\nsys.dont_write_bytecode=True;sys.path.insert(0,str(source));os.chdir(source)\nfor name in list(os.environ):\n    if name.startswith(\"HEPTA_HIA_\"):del os.environ[name]\nfrom hepta.hia_program import _decode\nfrom hepta.hia_program_normalization_native import installed_program_normalization\nowner=installed_program_normalization(manifest)\nlimit=sys.getrecursionlimit()\nassert limit>=100 and 1<=offset<limit\ndepth=limit-offset\nentered=[False]\ndef descend(left,call):\n    if left:\n        return descend(left-1,call)\n    entered[0]=True\n    try:return (False,call(None))\n    except BaseException as error:return (True,error)\ndef error_state(error,seen=None):\n    if error is None:return None\n    if seen is None:seen=set()\n    if id(error) in seen:return {\"cycle\":True}\n    seen.add(id(error))\n    trace=[]\n    tb=error.__traceback__\n    while tb is not None:\n        trace.append({\"function\":tb.tb_frame.f_code.co_name,\"line\":tb.tb_lineno,\n            \"filename\":tb.tb_frame.f_code.co_filename})\n        tb=tb.tb_next\n    return {\"type\":type(error).__module__+\".\"+type(error).__qualname__,\n        \"message\":str(error),\"code\":getattr(error,\"code\",None),\n        \"notes\":getattr(error,\"__notes__\",None),\"cause\":error_state(error.__cause__,seen),\n        \"context\":error_state(error.__context__,seen),\"traceback\":trace}\nobservations={}\nfor name,call in ((\"original\",_decode),(\"native\",owner.normalize_program)):\n    entered[0]=False\n    try:raised,value=descend(depth,call)\n    except BaseException as error:raised,value=True,error\n    if raised:\n        result={\"returned\":False,\"error\":error_state(value)}\n    else:\n        actual,wire=value\n        assert actual is None and wire==b\"null\"\n        result={\"returned\":True,\"wire_hex\":wire.hex(),\"value_is_None\":actual is None}\n    result[\"reached_call\"]=entered[0]\n    observations[name]=result\n    value=None\nassert sys.getrecursionlimit()==limit\nrecord={\"offset_from_original_limit\":offset,\"descent\":depth,\"recursion_limit\":limit,\n    \"recursion_limit_unchanged\":True,\"observations\":observations,\n    \"same_acceptance\":observations[\"original\"][\"returned\"]==observations[\"native\"][\"returned\"]}\nprint(json.dumps(record,ensure_ascii=True,sort_keys=True))\n"
ORIGINAL_CHILD_SHA256="416b082d24b997246f6e2eb2dd94103947517684391670becf14ea2e085a6718"
def digest(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2)+"\n").encode("ascii")
def put(path,raw):
    with path.open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--cold-report",type=Path,required=True)
    parser.add_argument("--manifest",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    source=args.source.resolve(strict=True);cold=args.cold_report.resolve(strict=True)
    manifest=args.manifest.resolve(strict=True);case=args.output.resolve()
    case.mkdir(mode=0o700,exist_ok=False)
    started=time.monotonic_ns()
    report={"schema":"hia.normalization.r9.independent-host-python-frame-observations.v1",
        "scope":"Six original child definitions and offsets, new source/manifest/interpreter admission; not original remote task reconciliation.",
        "original_probe_git_blob":"80352f416d5f3c643478ae800f00965e96515d83",
        "original_remote_r8_acknowledgement":"UNKNOWN_UNCHANGED_NO_REPLAY",
        "original_child_sha256":ORIGINAL_CHILD_SHA256,
        "new_compile_count":0,"timing_qualification":False,"cold_reexecuted":False,
        "physical_C_stack_qualified":False,"whole_owner_qualified":False,"default_changed":False,
        "observations":[],"differences":[],"failures":[]}
    before=None;inputs=None
    try:
        if (sys.implementation.name!="cpython" or sys.version_info[:3]!=(3,14,4)
                or sysconfig.get_config_var("Py_GIL_DISABLED") or sys.flags.optimize):
            raise RuntimeError("the independent frame observations require actual unoptimized CPython3.14.4 with GIL")
        assert digest(CHILD.encode())==ORIGINAL_CHILD_SHA256
        sys.path.insert(0,str(source))
        from tools.build_hia_json_preflight import admit_cold_build,current_sources
        cold_raw=cold.read_bytes();cold_doc=json.loads(cold_raw)
        nested_path=Path(cold_doc["nested_report"]);nested_raw=nested_path.read_bytes()
        nested=json.loads(nested_raw);compiler=Path(nested["generations"][-1]["produced_image"])
        compiler_raw=compiler.read_bytes()
        before=admit_cold_build(compiler_raw,cold_raw)
        assert before==current_sources()
        raw_manifest=manifest.read_bytes();meta=json.loads(raw_manifest)
        assert meta["schema"]=="hepta.hia.program-normalization-native.v4-development-permanent"
        assert set(meta["images"])=={"normalization","front","binary64","binary64_format"}
        note=meta["hosted_mechanisms"]["cpython_notes"]
        names=[row["image_path"] for row in meta["images"].values()]
        names += [note["image_path"],note["production"]["receipt_path"],note["production"]["packer_image_path"]]
        paths={manifest,cold,nested_path,compiler,Path(sys.executable).resolve(strict=True)}
        for name in names:
            rel=Path(name)
            assert not rel.is_absolute() and len(rel.parts)==1 and rel.name==name
            paths.add(manifest.parent/rel)
        inputs={str(path):digest(path.read_bytes()) for path in paths}
        report["interpreter"]={"path":str(Path(sys.executable).resolve()),"version":sys.version,
            "soabi":sysconfig.get_config_var("SOABI"),"sha256":inputs[str(Path(sys.executable).resolve())]}
        report["source_before"]=before;report["inputs_before"]=inputs
        put(case/"child.py",CHILD.encode())
        for offset in (32,24,16,12,8,4):
            command=[sys.executable,"-I","-B","-c",CHILD,str(source),str(manifest),str(offset)]
            try:
                child=subprocess.run(command,capture_output=True,timeout=10)
            except subprocess.TimeoutExpired as error:
                put(case/("child-"+str(offset)+".stdout"),error.stdout or b"")
                put(case/("child-"+str(offset)+".stderr"),error.stderr or b"")
                report["child_timeout_offset"]=offset
                raise
            put(case/("child-"+str(offset)+".stdout"),child.stdout)
            put(case/("child-"+str(offset)+".stderr"),child.stderr)
            assert child.returncode==0,(offset,child.returncode,child.stderr.decode("utf-8","replace"))
            row=json.loads(child.stdout);assert row["recursion_limit_unchanged"] is True
            row["child_returncode"]=child.returncode
            row["stdout_sha256"]=digest(child.stdout);row["stderr_sha256"]=digest(child.stderr)
            report["observations"].append(row)
            if not row["same_acceptance"]:report["differences"].append(offset)
        assert len(report["observations"])==6
        report["status"]="ACCEPTANCE_DIFFERENCES_CONFIRMED" if report["differences"] else "NO_ACCEPTANCE_DIFFERENCE_IN_SELECTED_CASES"
    except BaseException:
        report["status"]="HARNESS_OR_CHILD_FAILURE";report["failures"].append(traceback.format_exc())
    finally:
        try:
            if before is not None:
                after=current_sources();report["source_after"]=after
                assert after==before;report["source_unchanged"]=True
            if inputs is not None:
                assert all(digest(Path(path).read_bytes())==value for path,value in inputs.items())
                report["held_inputs_unchanged"]=True
        except BaseException:
            report["status"]="HARNESS_OR_CHILD_FAILURE";report["failures"].append(traceback.format_exc())
        report["elapsed_ns"]=time.monotonic_ns()-started
        report["driver_sha256"]=digest(Path(__file__).read_bytes())
        raw=encoded(report);put(case/"RESULT.json",raw)
        print(json.dumps({"status":report["status"],"observations":len(report["observations"]),
            "differences":report["differences"],"bytes":len(raw),"sha256":digest(raw)},sort_keys=True))
    return 0 if report["status"]=="NO_ACCEPTANCE_DIFFERENCE_IN_SELECTED_CASES" else 1
if __name__=="__main__":raise SystemExit(main())

