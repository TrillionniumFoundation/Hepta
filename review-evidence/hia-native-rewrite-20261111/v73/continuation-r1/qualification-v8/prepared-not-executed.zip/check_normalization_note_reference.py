"""Check the exact historical B35 C-reference prerequisite; execute no note ABI.

This is an independent preflight, not one of the original 35 observations.
The original test still rebuilds and verifies its own reference if this passes.
A compiler name or version never substitutes for the retained 260-byte hash.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

EXPECTED_BYTES = 260
EXPECTED_SHA256 = 'e82fd51964ce25990f24e723fb0b3270b2e8b69c7fdc2e1b3999648df070db61'


def digest(raw):
    return sha256(raw).hexdigest()


def write(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    output = args.output.resolve()
    if output == source or output.is_relative_to(source):
        raise ValueError('reference evidence must be outside the pinned source')
    output.mkdir(mode=0o700, exist_ok=False)
    report = {
        'schema': 'hepta.hia.normalization-retained-note-prerequisite.v1',
        'status': 'HOLD', 'observations_executed': 0,
        'expected_image_bytes': EXPECTED_BYTES,
        'expected_image_sha256': EXPECTED_SHA256,
        'commands': [], 'failures': [], 'reference_abi_executed': False,
        'original_35_qualified': False,
        'compiler_version_name_is_not_admission': True,
    }
    inputs = {}
    try:
        sys.path.insert(0, str(source))
        test = source / 'tests/test_hia_cpython_note_packer_native.py'
        spec = importlib.util.spec_from_file_location('_hia_note_reference_preflight', test)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        fixture = module.retained_fixture()
        for key, name in (('original_flat_note_r1.c', 'note.c'),
                          ('original_flat_note_r1.ld', 'note.ld')):
            raw = fixture['sources'][key]['text'].encode('utf-8')
            write(output / name, raw)
        cc_name, ld_name = shutil.which('cc'), shutil.which('ld')
        if cc_name is None or ld_name is None:
            raise RuntimeError('the historical C reference requires explicit cc and ld prerequisites')
        cc, ld = Path(cc_name).resolve(strict=True), Path(ld_name).resolve(strict=True)
        paths = (cc, ld, test, module._support_path, module._support.FIXTURE,
                 output / 'note.c', output / 'note.ld')
        inputs = {str(path): digest(path.read_bytes()) for path in paths}
        report['inputs_before'] = inputs
        report['tool_inputs'] = {str(path): inputs[str(path)] for path in (cc, ld)}
        commands = (
            ('compile', [str(cc), '-std=c11', '-c', '-Os', '-fPIC', '-ffreestanding',
                         '-fno-builtin', '-fno-stack-protector', '-fno-asynchronous-unwind-tables',
                         '-fno-unwind-tables', '-fno-ident', '-fcf-protection=none',
                         '-march=x86-64', '-mtune=generic', '-Wall', '-Wextra',
                         str(output / 'note.c'), '-o', str(output / 'note.o')]),
            ('link', [str(ld), '-nostdlib', '-T', str(output / 'note.ld'), '-o',
                      str(output / 'note.elf'), str(output / 'note.o')]),
        )
        for label, command in commands:
            try:
                child = subprocess.run(command, capture_output=True, timeout=30)
            except subprocess.TimeoutExpired as error:
                write(output / (label + '.stdout'), error.stdout or b'')
                write(output / (label + '.stderr'), error.stderr or b'')
                report['commands'].append({'label': label, 'command': command,
                                           'timeout_seconds': 30, 'timed_out': True})
                raise
            write(output / (label + '.stdout'), child.stdout)
            write(output / (label + '.stderr'), child.stderr)
            report['commands'].append({'label': label, 'command': command,
                                       'timeout_seconds': 30, 'timed_out': False,
                                       'returncode': child.returncode})
            if child.returncode != 0:
                raise RuntimeError('historical reference ' + label + ' failed')
        image = module.elf_image((output / 'note.elf').read_bytes())
        write(output / 'note.image.bin', image)
        report['actual_image_bytes'] = len(image)
        report['actual_image_sha256'] = digest(image)
        if len(image) != EXPECTED_BYTES or digest(image) != EXPECTED_SHA256:
            raise RuntimeError('current cc/ld did not reproduce the exact historical 260-byte reference')
        report['status'] = 'EXACT_HISTORICAL_REFERENCE_AVAILABLE'
    except BaseException:
        report['status'] = 'HOLD'
        report['failures'].append(traceback.format_exc())
    finally:
        try:
            after = {path: digest(Path(path).read_bytes()) for path in inputs}
            report['inputs_after'] = after
            report['held_inputs_unchanged'] = bool(inputs) and after == inputs
            if not report['held_inputs_unchanged']:
                report['status'] = 'HOLD'
        except BaseException:
            report['status'] = 'HOLD'
            report['failures'].append(traceback.format_exc())
        raw = (json.dumps(report, ensure_ascii=True, sort_keys=True, indent=2) + '\n').encode('ascii')
        write(output / 'RESULT.json', raw)
        print(json.dumps({'status': report['status'], 'bytes': len(raw), 'sha256': digest(raw)}, sort_keys=True))
    return 0 if report['status'] == 'EXACT_HISTORICAL_REFERENCE_AVAILABLE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
