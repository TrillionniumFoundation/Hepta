# Qualification v8 — prepared, not executed

This is an external harness revision. No source contract, product selector,
workflow, branch, or product ref was changed. The runner has not been launched;
there is no new cold, native, installed-wheel, full-regression, or physical-stack
qualification in this package.

## Required adjacent files

- `run_hia_qualification_v8.py`: new runner.
- `workflow_process.py`: the original 3,268-byte supervisor, copied exactly.
- `run_python_frame_observations.py`: the original 8,817-byte P wrapper, copied
  exactly, including its original 2,326-byte CHILD.
- `check_normalization_note_reference.py`: new, independent B prerequisite
  preflight. It only compiles and reads the historical reference; it never maps
  or executes the CPython note ABI.

The runner checks the two unchanged helper hashes before any source gate. It
also records and verifies all four harness files before/after qualification.
Keep the four files adjacent. The preparation script and static validator are
review aids, not dependencies of a qualification run.

An eventual invocation, after the parent freezes and prepares the complete
current checkout and real prerequisites, is:

```sh
/absolute/path/to/python3.14.4 -B /absolute/harness/run_hia_qualification_v8.py \
  --source /absolute/clean/current-checkout \
  --output /absolute/new/outside-git/qualification-v8 --full
```

This command has **not** been executed. A/P/B hosted-note tests retain the exact
unoptimized CPython 3.14.4 with GIL admission. No version is impersonated. All
existing Clang, Rust/Lean/bridge, strace, assembler/linker, packaging, and other
retained test prerequisites remain the caller's responsibility; v8 does not
change PATH, install tools, or weaken those tests.

## Preserved gates

The original 27 component-group dictionary is AST-identical to v7, including
all existing test-module names. Source reproduction, the pinned complete Git
source check, workflow source/native-name extraction, and the full unittest
discovery subprocess body are unchanged. Full discovery remains:

```python
loader.discover('tests', top_level_dir='.')
```

There are no filters, skip replacements, or reduced inventories. Ordinary
steps retain 1,800 seconds; full discovery retains 5,400 seconds; the cold
outer step retains 240 seconds. The existing cold implementation still owns
180 seconds plus its separate 3-second cleanup bound. v8 additionally checks
those recorded internal values before using the compiler.

## New complete component groups

| Group | Actual retained inventory | Outer bound |
|---|---|---:|
| `linked-observer` | Full module: Source 4 + Native 27 = 31 unittest cases | 1,800 s |
| `source-select-compile-receipts` | Select 8 + identity 5 + compile-receipt 6 = 19 unittest cases | 1,800 s |
| `normalization-A` | Coordinator Native 8 + HIA/GNU/VM note packer 1 + front 12 + nominal JSON 12 = 33 unittest cases | 1,800 s |
| `normalization-P` | Original CHILD at offsets 32, 24, 16, 12, 8, 4; six observations | 90 s total / 10 s per child |
| `normalization-B-prerequisite` | Exact retained C/LD source and original flags; requires actual 260 bytes and SHA `e82fd51964ce25990f24e723fb0b3270b2e8b69c7fdc2e1b3999648df070db61` | 1,800 s outer / original 30 s per command |
| `normalization-B` | Original single unittest containing all 35 hosted controls; raw teardown observations must also number 35 | 1,800 s |

The normal component loop still executes all 27 old groups. New complete
groups are appended. Source/native workflow groups remain in addition to this
explicit inventory, as in v7.

## Cold compiler, selectors, and evidence

The new receipt fixture is not given an inherited compiler. v8 clears inherited
`HEPTA_HIA_COMPILE_RECEIPT_COMPILER` and its SHA selector, in addition to all
existing development, manifest, and cold selectors. After the fresh cold step,
it reads the exact nested report, verifies its recorded SHA, source map and
three generations, reads all B1/B2/B3 files, checks their exact lengths/hashes,
and applies the existing `admit_cold_build` to the actual B3 bytes. Only then
does it set the receipt compiler path and SHA for subsequent components and
full discovery. It never hardcodes an old retained development image.

The cold/nested/three image files are rehashed before subsequent steps and at
completion. Successful B prerequisite compiler/linker files also enter that
held-input guard. Mutation becomes HOLD; no late successful report converts it
to PASS.

All 44 current cold families are configured, including `LINKED_OBSERVER`,
`PROGRAM_NORMALIZATION`, `CORE_JSON_BYTES`, and `NOMINAL_JSON`. Static source
scanning also sees two intentionally wrong-selector negative-test names; those
are not production selectors and are not populated. Every group, including
full discovery, receives its own evidence directory for the new fixtures.
The existing fixture's exclusive class/candidate subdirectory then prevents
accidental reuse. P consumes only A's same-run, source-bound manifest; it does
not synthesize or relocate a manifest.

## B HOLD and complete discovery

The historical C reference is an independent prerequisite. A compiler labeled
GCC 15 is insufficient: the actual linked section must be exactly 260 bytes
with the retained hash. Both source snippets, the original compile/link flags,
the exact ELF section parser, and the original 30-second child limits are
retained. The new preflight saves the actual output and tool identities even
on mismatch. It executes zero hosted-note observations.

If the prerequisite is unavailable, standalone B records `HOLD`, zero executed
tests/observations, and the reason. A and P have already run, all old groups
have run, and `--full` still starts the **unfiltered** original discovery.
Discovery will attempt the original B unittest as normal; it is neither
deleted nor converted into a skip. Its actual result is preserved. Overall
qualification cannot pass while standalone B is HOLD.

If the prerequisite passes, the original B unittest still rebuilds and checks
its own reference. The preflight output is never injected to bypass that
assertion. A/P do not depend on B's compiler. P only describes acceptance in
the six selected Python-frame cases; `physical_C_stack_qualified` and whole
normalization remain false regardless of their result.

## Static evidence and limits

`STATIC-REVIEW.json` records 27 AST/byte-identity checks. It confirms original
group equality, exact full-discovery and reproduction bodies, old deadlines,
44-family coverage, fixture test inventories, all unchanged P bytes and
offsets, the original B command flags, nonblocking B routing, and preservation
requirements. It does not import or execute the runner or product modules.
The linked-observer owner separately reviewed its selector/evidence wiring
without executing it; that text is preserved in `peer-linked-wiring-review.json`.

The first static-validator run failed because its own AST inventory assertion
incorrectly depended on breadth-first traversal order. Its source and stderr
are preserved. The validator was corrected to compare the exact count
multiset; the runner did not change. The second static run passed 27/27.

The old 260-byte binary was not recovered from the actually inspected retained
fixture or r9 89-member archive. Those contain source text, the HIA-produced
298-byte image, and a different-environment GCC14 261-byte negative result.
This is not a claim about unseen older archives. No paused remote UNKNOWN job
was replayed and no newly compiled bytes were mislabeled as recovered originals.

The original v7, original P wrapper, and original supervisor files at their
source paths remain byte-identical. All artifacts here are independent harness
work; the parent owns final source registration, workflow changes, freezing,
and any actual qualification launch.
