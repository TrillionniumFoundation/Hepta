"""Reproducible narrow v7-to-v8 harness transformation; never runs qualification."""
from pathlib import Path
from hashlib import sha256
import difflib

ROOT = Path(__file__).resolve().parent
old = (ROOT / 'original_run_hia_qualification_v7.py').read_bytes()
assert sha256(old).hexdigest() == 'c59b3b0d27b6022a4292c918962785205adf4a732c9d97c56f4bbd6587b3f701'
text = old.decode('utf-8')


def replace(before, after):
    global text
    assert text.count(before) == 1, before[:160]
    text = text.replace(before, after)


replace("    'STATIC_BUDGET', 'HEAP_BOUND',\n", "    'STATIC_BUDGET', 'HEAP_BOUND',\n    'LINKED_OBSERVER', 'PROGRAM_NORMALIZATION', 'CORE_JSON_BYTES', 'NOMINAL_JSON',\n")
replace("discarded = {'development': {}, 'production': {}, 'cold_report': {}}", "discarded = {'development': {}, 'production': {}, 'cold_report': {}, 'compiler': {}}")
replace("        if '_DEVELOPMENT_' in name or name.endswith('_DEVELOPMENT'):\n", "        if name in {'HEPTA_HIA_COMPILE_RECEIPT_COMPILER',\n                    'HEPTA_HIA_COMPILE_RECEIPT_COMPILER_SHA256'}:\n            category = 'compiler'\n        elif '_DEVELOPMENT_' in name or name.endswith('_DEVELOPMENT'):\n")
replace("'schema': 'hepta.hia.qualification-environment.v1'", "'schema': 'hepta.hia.qualification-environment.v2'")
replace("'policy': 'Discard inherited HIA development choices, production manifests and cold reports; select only this run fresh cold report.'", "'policy': 'Discard inherited HIA artifact choices and receipt compilers; select this run fresh cold report, then admit its actual B3 before selecting a compiler.'")
replace("        'effective_cold_report_selectors': selected,\n", "        'effective_cold_report_selectors': selected,\n        'effective_qualified_compiler_selectors': {},\n")
replace("discarded_cold_report_selectors = sorted(environment_selection['discarded']['cold_report'])", "discarded_cold_report_selectors = sorted(environment_selection['discarded']['cold_report'])\ndiscarded_compiler_selectors = sorted(environment_selection['discarded']['compiler'])")
replace("harness_paths = {'runner': Path(__file__).resolve(),\n                 'workflow_process': Path(workflow_process.__file__).resolve()}", "harness_paths = {'runner': Path(__file__).resolve(),\n                 'workflow_process': Path(workflow_process.__file__).resolve(),\n                 'python_frame_observations': Path(__file__).resolve().with_name('run_python_frame_observations.py'),\n                 'historical_note_prerequisite': Path(__file__).resolve().with_name('check_normalization_note_reference.py')}")
replace("harness_before = {name: file_record(path) for name, path in harness_paths.items()}\n", "harness_before = {name: file_record(path) for name, path in harness_paths.items()}\nif harness_before['workflow_process']['sha256'] != 'f3ebc453de2d2c9ecd3825547e301c122b6c7fa05af1aacd9103b8a67893ee80':\n    raise ValueError('original workflow process supervisor changed')\nif harness_before['python_frame_observations']['sha256'] != '666d8198a171e6db723860606d337600a362557d9526bc5eab431fe376ab7ac5':\n    raise ValueError('original independent Python-frame wrapper changed')\n")
replace("steps = []\nsuite_outcomes = {}\n", """steps = []
suite_outcomes = {}
held_inputs_before = {}
normalization_outcomes = {}
cold_compiler_admission = None


def input_guard():
    return {path: sha256(Path(path).read_bytes()).hexdigest()
            for path in held_inputs_before} == held_inputs_before


def hold(name, reason, *, expected_tests=None, expected_observations=None):
    result = {'name': name, 'status': 'HOLD', 'passed': False,
              'execution_started': False, 'owner': None, 'reason': reason}
    if expected_tests is not None:
        result['expected_tests'] = expected_tests
    if expected_observations is not None:
        result['expected_observations'] = expected_observations
    steps.append(result)
    (out / 'steps.json').write_text(json.dumps(steps, indent=2) + '\\n')
    print(json.dumps({'not_started': name, 'status': 'HOLD', 'reason': reason}), flush=True)
    return False


def admit_fresh_cold_compiler(raw):
    # Read actual fresh outputs, never inherit a retained development binary.
    from tools.build_hia_json_preflight import admit_cold_build
    record = json.loads(raw)
    if (type(record) is not dict
            or type(record.get('qualification_wall_limit_seconds')) is not int
            or record['qualification_wall_limit_seconds'] != 180
            or type(record.get('cleanup_wall_limit_seconds')) is not int
            or record['cleanup_wall_limit_seconds'] != 3
            or type(record.get('nested_report')) is not str):
        raise ValueError('cold report changed the original time limits or nested identity')
    nested_path = Path(record['nested_report']).resolve(strict=True)
    if not nested_path.is_relative_to(out):
        raise ValueError('nested qualification is outside this fresh run')
    nested_raw = nested_path.read_bytes()
    if sha256(nested_raw).hexdigest() != record.get('nested_report_sha256'):
        raise ValueError('nested qualification bytes do not match the cold report')
    nested = json.loads(nested_raw)
    if (type(nested) is not dict or nested.get('status') != 'SELF_HOSTED_FIXED_CORE_PASS'
            or nested.get('source_manifest') != cold_sources
            or type(nested.get('generations')) is not list or len(nested['generations']) != 3):
        raise ValueError('nested generations do not bind the current complete source')
    pins = {str(cold): sha256(raw).hexdigest(), str(nested_path): sha256(nested_raw).hexdigest()}
    generations = []
    for index, row in enumerate(nested['generations'], 1):
        if type(row) is not dict or type(row.get('produced_image')) is not str:
            raise ValueError('invalid actual generation image reference')
        path = Path(row['produced_image']).resolve(strict=True)
        if not path.is_relative_to(out):
            raise ValueError('generation image is outside this fresh run')
        image = path.read_bytes()
        digest = sha256(image).hexdigest()
        if (not image or type(row.get('produced_bytes')) is not int
                or row['produced_bytes'] != len(image) or row.get('produced_sha256') != digest):
            raise ValueError('generation image length/hash differs from actual bytes')
        pins[str(path)] = digest
        generations.append({'generation': index, 'path': str(path),
                            'bytes': len(image), 'sha256': digest})
    if admit_cold_build(image, raw) != cold_sources:
        raise ValueError('fresh compiler admission differs from the pinned source')
    if ([row['sha256'] for row in generations] != record.get('generation_sha256')
            or any(sha256(Path(path).read_bytes()).hexdigest() != digest for path, digest in pins.items())):
        raise ValueError('fresh compiler/report inputs changed during admission')
    held_inputs_before.update(pins)
    return {'schema': 'hepta.hia.qualification-actual-cold-compiler.v1',
            'status': 'CURRENT_COLD_B3_ADMITTED', 'generations': generations,
            'selected': generations[-1], 'inputs': pins,
            'source_manifest': cold_sources, 'inherited_compiler_used': False}
""")
replace("def run(name, args, *, timeout=1800):\n    started = time.monotonic()", "def run(name, args, *, timeout=1800):\n    try:\n        if not input_guard():\n            return hold(name, 'held cold or prerequisite inputs changed before execution')\n    except OSError as error:\n        return hold(name, 'held input readback failed: ' + repr(error))\n    started = time.monotonic()")
replace("        ('HEPTA_HIA_HEAP_LIVE_ENGINE_EVIDENCE', 'heap-live-engine'),\n", "        ('HEPTA_HIA_HEAP_LIVE_ENGINE_EVIDENCE', 'heap-live-engine'),\n        ('HEPTA_HIA_LINKED_OBSERVER_EVIDENCE', 'linked-observer'),\n        ('HEPTA_HIA_COMPILE_RECEIPT_OBSERVATIONS', 'compile-receipts'),\n        ('HEPTA_HIA_PROGRAM_NORMALIZATION_EVIDENCE', 'normalization'),\n        ('HEPTA_HIA_CORE_JSON_BYTES_EVIDENCE', 'core-json-bytes'),\n        ('HEPTA_HIA_NOMINAL_JSON_EVIDENCE', 'nominal-json'),\n")
replace("def suite(name, names=None, discover=False):", "def suite(name, names=None, discover=False, expected_tests=None):")
replace("    outcome = {'completed': completed, 'passed': False, 'discovery': discover}", "    outcome = {'completed': completed, 'passed': False, 'discovery': discover,\n               'expected_tests': expected_tests}")
replace("                             and value['tests_run'] > 0 and value.get('successful') is True\n", "                             and value['tests_run'] > 0 and value.get('successful') is True\n                             and (expected_tests is None or value['tests_run'] == expected_tests)\n")
replace("    record = json.loads(cold.read_text())\n", "    cold_raw = cold.read_bytes()\n    record = json.loads(cold_raw)\n")
replace("               and record.get('source_manifest') == cold_sources)\nexcept (OSError, ValueError, AttributeError) as error:\n", """               and record.get('source_manifest') == cold_sources)
    if cold_ok:
        cold_compiler_admission = admit_fresh_cold_compiler(cold_raw)
        selected = cold_compiler_admission['selected']
        compiler_selectors = {'HEPTA_HIA_COMPILE_RECEIPT_COMPILER': selected['path'],
                              'HEPTA_HIA_COMPILE_RECEIPT_COMPILER_SHA256': selected['sha256']}
        environment.update(compiler_selectors)
        os.environ.update(compiler_selectors)
        environment_selection['effective_qualified_compiler_selectors'] = compiler_selectors
        environment_record.write_text(json.dumps(environment_selection, indent=2, sort_keys=True) + '\\n')
        (out / 'cold-compiler-admission.json').write_text(json.dumps(cold_compiler_admission, indent=2, sort_keys=True) + '\\n')
except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
""")
replace("    for name, names in groups.items():\n        ok = suite(name, names) and ok\n    if a.full:\n", """    for name, names in groups.items():
        ok = suite(name, names) and ok
    # Append complete new families; the 27 retained groups above are unchanged.
    ok = suite('linked-observer', ['tests.test_hia_selfhost_linked_observer'], expected_tests=31) and ok
    ok = suite('source-select-compile-receipts', [
        'tests.test_hia_original_select_fragments',
        'tests.test_hia_agent_identity_source_binding',
        'tests.test_hia_compile_receipt_binding'], expected_tests=19) and ok
    a_name = 'normalization-A'
    a_ok = suite(a_name, [
        'tests.test_hia_program_normalization_native.ProgramNormalizationNativeTests',
        'tests.test_hia_cpython_note_packer_native.CPythonNotePackerNativeTests.test_independent_assembler_VM_and_actual_HIA_packer_complete_bytes',
        'tests.test_hia_core_json_bytes_native.CoreJSONBytesNativeTests',
        'tests.test_hia_nominal_json_native.NominalJSONNativeTests'], expected_tests=33)
    normalization_outcomes['A'] = suite_outcomes[a_name]
    ok = a_ok and ok
    # P reuses only A's source-bound production fixture; B never gates P.
    a_manifest = out / (a_name + '-normalization') / 'ProgramNormalizationNativeTests/native/manifest.json'
    p_output = out / 'normalization-P-observations'
    p_outcome = {'passed': False, 'expected_observations': 6,
                 'physical_C_stack_qualified': False, 'whole_owner_qualified': False}
    if a_manifest.is_file():
        p_completed = run('normalization-P', [str(harness_paths['python_frame_observations']),
            '--source', str(root), '--cold-report', str(cold), '--manifest', str(a_manifest),
            '--output', str(p_output)], timeout=90)
        p_outcome['completed'] = p_completed
        try:
            p_record = json.loads((p_output / 'RESULT.json').read_bytes())
            rows = p_record.get('observations')
            p_outcome['result'] = file_record(p_output / 'RESULT.json')
            p_outcome['observations'] = len(rows) if type(rows) is list else None
            p_outcome['passed'] = (p_completed
                and p_record.get('status') == 'NO_ACCEPTANCE_DIFFERENCE_IN_SELECTED_CASES'
                and type(rows) is list and len(rows) == 6
                and [row.get('offset_from_original_limit') for row in rows] == [32, 24, 16, 12, 8, 4]
                and all(row.get('same_acceptance') is True and row.get('recursion_limit_unchanged') is True for row in rows)
                and p_record.get('differences') == [] and p_record.get('failures') == []
                and p_record.get('source_unchanged') is True
                and p_record.get('held_inputs_unchanged') is True
                and p_record.get('physical_C_stack_qualified') is False)
        except (OSError, ValueError, TypeError, AttributeError) as error:
            p_outcome['result_error'] = repr(error)
    else:
        hold('normalization-P', 'A did not produce its required source-bound manifest', expected_observations=6)
        p_outcome['completed'] = False
        p_outcome['dependency_hold'] = 'A manifest unavailable; no child observations executed'
    steps[-1]['normalization_result'] = p_outcome
    steps[-1]['passed'] = p_outcome['passed']
    normalization_outcomes['P'] = p_outcome
    ok = p_outcome['passed'] and ok

    # B is an independent historical-reference prerequisite. A/P and full
    # discovery continue even if it is unavailable; a HOLD is never a PASS.
    b_preflight_output = out / 'normalization-B-reference-prerequisite'
    b_preflight_ok = run('normalization-B-prerequisite', [
        str(harness_paths['historical_note_prerequisite']), '--source', str(root),
        '--output', str(b_preflight_output)])
    b_prerequisite = {'passed': False}
    try:
        b_record = json.loads((b_preflight_output / 'RESULT.json').read_bytes())
        b_prerequisite['result'] = file_record(b_preflight_output / 'RESULT.json')
        b_prerequisite['passed'] = (b_preflight_ok
            and b_record.get('status') == 'EXACT_HISTORICAL_REFERENCE_AVAILABLE'
            and type(b_record.get('actual_image_bytes')) is int and b_record['actual_image_bytes'] == 260
            and b_record.get('actual_image_sha256') == 'e82fd51964ce25990f24e723fb0b3270b2e8b69c7fdc2e1b3999648df070db61'
            and b_record.get('held_inputs_unchanged') is True and b_record.get('failures') == [])
        if b_prerequisite['passed']:
            tools = b_record.get('tool_inputs')
            if type(tools) is not dict or not tools or any(
                    type(path) is not str or type(digest) is not str
                    or sha256(Path(path).read_bytes()).hexdigest() != digest for path, digest in tools.items()):
                raise ValueError('historical reference tools changed after preflight')
            held_inputs_before.update(tools)
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        b_prerequisite['passed'] = False
        b_prerequisite['result_error'] = repr(error)
    normalization_outcomes['B_prerequisite'] = b_prerequisite
    steps[-1]['prerequisite_result'] = b_prerequisite
    steps[-1]['passed'] = b_prerequisite['passed']
    if b_prerequisite['passed']:
        b_ok = suite('normalization-B', [
            'tests.test_hia_cpython_note_packer_native.CPythonNotePackerNativeTests.test_original_35_hosted_mechanism_controls_on_HIA_produced_bytes'],
            expected_tests=1)
        b_outcome = dict(suite_outcomes['normalization-B'], expected_observations=35)
        try:
            b_observations = out / 'normalization-B-normalization/CPythonNotePackerNativeTests/observations.json'
            b_observation_record = json.loads(b_observations.read_bytes())
            rows = b_observation_record.get('observations')
            b_outcome['observation_result'] = file_record(b_observations)
            b_outcome['observations'] = len(rows) if type(rows) is list else None
            b_outcome['passed'] = (b_ok and type(rows) is list and len(rows) == 35
                and b_observation_record.get('source_inputs_unchanged') is True)
        except (OSError, ValueError, TypeError, AttributeError) as error:
            b_outcome['passed'] = False
            b_outcome['result_error'] = repr(error)
        steps[-1]['normalization_result'] = b_outcome
        steps[-1]['passed'] = b_outcome['passed']
    else:
        hold('normalization-B', 'exact historical 260-byte C reference prerequisite unavailable; original 35 not executed',
             expected_tests=1, expected_observations=35)
        b_outcome = {'passed': False, 'status': 'HOLD', 'execution_started': False,
                     'tests_run': 0, 'observations': 0, 'expected_tests': 1, 'expected_observations': 35}
    normalization_outcomes['B'] = b_outcome
    ok = b_outcome['passed'] and ok
    (out / 'steps.json').write_text(json.dumps(steps, indent=2) + '\\n')
    if a.full:
""")
replace("harness_preserved = harness_after == harness_before\nall_passed = ok and preserved and harness_preserved", """harness_preserved = harness_after == harness_before
held_inputs_after = {}
for path in held_inputs_before:
    try:
        held_inputs_after[path] = sha256(Path(path).read_bytes()).hexdigest()
    except OSError as error:
        held_inputs_after[path] = {'error': repr(error)}
held_inputs_preserved = held_inputs_after == held_inputs_before
all_passed = ok and preserved and harness_preserved and held_inputs_preserved""")
replace("'schema': 'hepta.hia.native-rewrite-qualification.v7'", "'schema': 'hepta.hia.native-rewrite-qualification.v8'")
replace("          'cold_error': cold_error,\n", "          'cold_error': cold_error, 'cold_compiler_admission': cold_compiler_admission,\n          'held_inputs_before': held_inputs_before, 'held_inputs_after': held_inputs_after,\n          'held_inputs_preserved': held_inputs_preserved,\n")
replace("          'discarded_cold_report_selectors': discarded_cold_report_selectors,\n", "          'discarded_cold_report_selectors': discarded_cold_report_selectors,\n          'discarded_compiler_selectors': discarded_compiler_selectors,\n")
replace("          'whole_native_delivery_qualified': False,\n", "          'normalization': normalization_outcomes,\n          'normalization_physical_recursion_qualified': False,\n          'normalization_whole_owner_qualified': False,\n          'whole_native_delivery_qualified': False,\n")
(ROOT / 'run_hia_qualification_v8.py').write_text(text)
diff = ''.join(difflib.unified_diff(old.decode().splitlines(True), text.splitlines(True),
                                  fromfile='run_hia_qualification_v7.py', tofile='run_hia_qualification_v8.py'))
(ROOT / 'v7-to-v8.patch').write_text(diff)
print(sha256(text.encode()).hexdigest(), len(text.encode()))
