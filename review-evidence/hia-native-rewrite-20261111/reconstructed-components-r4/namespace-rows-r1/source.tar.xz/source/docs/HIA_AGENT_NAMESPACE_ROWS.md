# Native namespace row owner: reconstructed revision 1

This new development revision follows an interrupted cloud instance. The old
all-31 Core VM test has no known terminal result and is not reused. The durable
values r2 source/evidence is restored from recovery commit 59b6e74c. The earlier
transactions r2 raw archive was not durably saved and must be reconstructed and
retested as a distinct revision.

This HIA controller owns all 31 retained relational operations from the frozen
ten-table / 51-call catalog. It chooses predicates, projections, insert/update
fields, constants, constraints, ignore behavior, statement rollback and result
completion. Scalar, index, log and syscall peers are explicit remaining native
composition work. Development reference peers are not production fallback.
Nothing here installs a database or removes a retained owner.

## Fixed invocation boundary

The RWW entry has input128/output192/workspace1024 minimum bytes. INIT is 16
little-endian u64 words:

    [HIANRW01,1,sessionLo,sessionHi,rowActionGeneration,0,0,0,
     operation,bindLease,viewLease,0,0,0,0,0]

Both leases and the actual parent-issued row-action generation are nonzero.
The session pair is not both zero. Operation is 1..31. The zeroed workspace is
used for one row action only; another autocommit read gets a new workspace and
distinct actual action generation even if its transaction sequence is unchanged.

An ACK is:

    [HIANRW01,2,sessionLo,sessionHi,rowActionGeneration,
     issuedSequence,issuedAction,status,first,second,third,0,0,0,0,0]

Status0 is completion,1 a semantic storage error,2 mechanical I/O failure,3 EOF
only for cursor-next. One action is outstanding. Exact header/length/sequence/
action/reserved data and typed result shape are checked. Protocol/mechanical
failure permanently refuses; completed workspaces cannot be restarted. BAD
0xfffffffd takes precedence over output; a workspace too short to record poison
must be discarded by the fixed executor.

The 24 output words are magic,status,session pair,generation,action sequence,
operation,table,action,six action arguments,result lease,changes,matches,error
code,error detail,current rowid,continuation phase,framing reason,zero.
Status1 requests a peer action;0 is success;2 is a completed semantic error.
The independently owned result is published only after native scope cleanup.

## Native peer contract

All peers are fixed HIA implementations to be composed. A handle or header echo
is not authentication for externally supplied buffers. The executor binds each
handle to its actual issued object, completed native action and lease generation.
No peer accepts a Python row-selection callback or a retained SQL statement.

| Action | Inputs | Completed result |
| --- | --- | --- |
| 1 mark | transaction view | pending statement mark |
| 2 affinity | vector,field,NUMERIC1/TEXT2 | one-cell lease |
| 3 result begin | operation,projection mask | builder |
| 4 cursor begin | view,table,native order | cursor |
| 5 next | cursor | row,rowid,width; or EOF |
| 6 compare | left vector/field,right vector/field | LT0/EQ1/GT2/UNKNOWN3 |
| 7 storage class | vector,field | NULL0/INTEGER1/REAL2/TEXT3/BLOB4 |
| 8 row begin | schema width | all-NULL row |
| 9 assign | row,column,one-cell lease,column affinity | new row |
| 10 constant | NULL0/int0=1/int1=2/text0=3/completed=4/count=5, count value | one-cell lease |
| 11 add one | row,column | SQL arithmetic result |
| 12 rowid | view,table,AUTOINCREMENT flag | signed rowid bits,one-cell lease |
| 13 pending write | view,table,rowid,whole row,cost-high-water flag | zero ACK |
| 14 append | result builder,row,projection mask | builder |
| 15 result finish | builder,changes,matches | independently owned result |
| 16 rollback statement | mark,view | zero ACK after rollback |
| 17 scope cleanup | kept result,row generation,last completed action sequence | zero ACK after retirement |
| 18 error result | original extended code,operation,table,detail | owned error |

The scalar owner must implement all five storage classes, original SQL affinity,
BINARY text/blob comparison, integer/real comparison, SQL NULL and numeric
addition. The row owner requests affinity for every bind and assignment,
including the result of attempts+1. Arbitrary-length decimal TEXT is not
narrowed to u64. The value stream has no store-wide record/byte quota.

Order1 is signed rowid order; order2 is the complete primary-index order used
for SELECT generation FROM versions. Costs use their INTEGER PRIMARY KEY order.
The native view must preserve original rowids, BINARY/index storage-class order,
tie breaking, current committed head and this transaction's pending writes.
It must not return records from another lease or a stale action generation.

## Complete retained decisions

All predicates and assignments are authored in the HIA generator and bound to
the frozen ABI table columns. Generic comparisons cannot choose the WHERE
clause. SQL NULL equality remains UNKNOWN. The cost query also admits NULL
context and stops only after 10,001 matching records, its existing truncation
detector; the namespace itself has no new limit. Lease COUNT emits one row
including zero. The retained single-column projections are exact.

INSERT builds each field, including attempts0, budget TEXT0/NULL owner, lease
active1, and cost sequence from the actual native rowid allocator. NOT NULL
checks precede unique checks. Unique checks use the original index ordering;
any NULL key element does not conflict. Only artifacts/profiles/cursors keep
IGNORE behavior. Other failures keep the original extended constraint category
and column/index detail. The original rowid allocator and cost high-water rules,
including non-cost random fallback when needed, remain peer obligations and
may not be replaced by row count or new record quotas.

UPDATE performs all WHERE tests before changing a row, builds immutable
intermediate rows, applies assignment affinity and checks modified NOT NULL
columns. No retained update changes an indexed key. CAS attempts has both
predicates and increments only a match. A matched write counts once even when
the assigned bytes are unchanged. The original request completion, budget
release, slot generation/epoch/context and lease state assignments are retained.

Each write starts with a native pending-log statement mark. A semantic failure
rolls back to that mark before returning its owned error result, preserving
earlier statements in the surrounding explicit transaction. A full transaction
rollback belongs to the transaction owner. Pending writes are not durable
publication; the transaction/log owner retains fsync order and unknown-commit
handling. Successful, ignored and semantic-error paths all clean up temporary
values, cursors, row copies and marks while retaining only a separately owned
final result. A cleanup failure cannot be reinterpreted as success.

## Evidence boundaries

A Core VM/native continuation comparison with reference scalar/view/log peers
tests this controller's decisions and framing. It does not prove native scalar
affinity, physical log/index correctness, crash/race behavior, migration or
installed store qualification. The real native composition must still pass all
retained storage and Agent tests, including journal ACK before COMMIT and
unknown/replayed request behavior, before public selection.
