"""Development source/VM checks; no native database qualification claimed."""
from pathlib import Path
import json
import struct
import unittest

from hepta.hia_agent_assembly import assemble_program, render_assembly
from hepta.hia_program_runtime import _Machine, _Owner, _View
from tools.generate_hia_agent_namespace_store import document

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANSC01', 'little')
REFUSED = 4294967293
CANARY = bytes(range(160, 192))


def frame(command, *, serial=1, operation=101, table=0, count=0, sequence=0, body=b''):
    return struct.pack('<8Q', MAGIC, command, serial, operation, table, count, len(body), sequence) + body


def cell(kind, payload=b''):
    return struct.pack('<2Q', kind, len(payload)) + payload


class NamespaceValueSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'examples/hia_bootstrap/agent_namespace_values.hiaasm').read_bytes()
        cls.program = assemble_program(cls.raw)
        cls.entry = cls.program.as_dict()['functions'][0]
        cls.abi = json.loads((ROOT / 'docs/HIA_AGENT_NAMESPACE_STORE_ABI.json').read_bytes())

    def invoke(self, raw, work, *, steps=200000, output_size=128):
        original = bytes(raw)
        output_canary = CANARY if output_size == 128 else b''
        owners = [_Owner(-1, bytearray(raw)),
                  _Owner(-2, bytearray(output_size) + bytearray(output_canary)),
                  _Owner(-3, work)]
        output = _View(owners[1], True)
        machine = _Machine(self.program, steps, 4 << 20, None, 64)
        code = machine.invoke(self.entry, [_View(owners[0], False), output, _View(owners[2], True)])[0]
        self.assertEqual(bytes(owners[0].data), original)
        self.assertEqual(bytes(owners[1].data[output_size:]), output_canary)
        if len(work) == 160:
            self.assertEqual(bytes(work[128:]), CANARY)
        result = bytes(owners[1].data[:output_size])
        return code, struct.unpack('<16Q', result) if output_size == 128 else result

    @staticmethod
    def workspace():
        return bytearray(128) + bytearray(CANARY)

    def test_source_reproduces_complete_catalog_and_bounds(self):
        self.assertEqual(self.raw, render_assembly(document()).encode())
        self.assertEqual(len(self.abi['tables']), 10)
        self.assertEqual(len(self.abi['relational_operations']), 31)
        self.assertEqual(sum(len(row['call_sites']) for row in self.abi['relational_operations']), 45)
        self.assertEqual(len(self.abi['non_DML_sites']), 6)
        for row in self.abi['relational_operations']:
            with self.subTest(operation=row['id']):
                w = self.workspace()
                code, out = self.invoke(frame(1, operation=row['id'], table=row['table_id'],
                                              count=row['bind_count']), w)
                self.assertEqual(code, 1)
                self.assertEqual(out[4:7], (row['id'], row['table_id'], row['bind_count']))
                wrong = self.workspace()
                code, out = self.invoke(frame(1, operation=row['id'], table=row['table_id'],
                                              count=row['bind_count'] + 1), wrong)
                self.assertEqual((code, out[11]), (REFUSED, 6))
        for table in self.abi['tables']:
            code, _ = self.invoke(frame(1, operation=100, table=table['id'],
                                         count=len(table['columns'])), self.workspace())
            self.assertEqual(code, 1)

    def test_all_storage_classes_and_fragmented_envelopes(self):
        values = [cell(0), cell(1, struct.pack('<q', -(1 << 63))),
                  cell(2, struct.pack('<Q', 0x7ff8000000000042)),
                  cell(3, b'100000000000000000000000000000000000000000007'),
                  cell(3, b'\xff\x00raw persisted text bytes'),
                  cell(4, bytes(range(73))), cell(3), cell(4)]
        raw = b''.join(values)
        for size in (1, 7, 16, 31, 64, 257):
            with self.subTest(chunk=size):
                w = self.workspace()
                code, out = self.invoke(frame(1, count=len(values)), w)
                self.assertEqual((code, out[7], out[10]), (1, 0, 0))
                sequence = 0
                for offset in range(0, len(raw), size):
                    sequence += 1
                    code, out = self.invoke(frame(2, count=len(values), sequence=sequence,
                                                  body=raw[offset:offset + size]), w)
                    self.assertEqual(code, 1)
                    self.assertEqual(out[10], min(offset + size, len(raw)))
                code, out = self.invoke(frame(3, count=len(values), sequence=sequence + 1), w)
                self.assertEqual((code, out[7], out[8], out[9], out[10]),
                                 (0, len(values), 0, 0, len(raw)))
                self.assertEqual(out[11:], (0, 1, 0, 0, 0))

    def test_wrong_tags_lengths_truncation_extra_bytes_and_poison(self):
        cases = [(struct.pack('<2Q', 5, 0), 10),
                 (struct.pack('<2Q', 0, 1), 11),
                 (struct.pack('<2Q', 1, 7), 11),
                 (struct.pack('<2Q', 2, 9), 11),
                 (cell(0) + b'x', 9)]
        for body, reason in cases:
            with self.subTest(reason=reason, body=body.hex()):
                w = self.workspace()
                self.assertEqual(self.invoke(frame(1, count=1), w)[0], 1)
                code, out = self.invoke(frame(2, count=1, sequence=1, body=body), w)
                self.assertEqual((code, out[11]), (REFUSED, reason))
                frozen = bytes(w)
                code, later = self.invoke(frame(1, serial=2, count=0), w)
                self.assertEqual((code, later[11]), (REFUSED, reason))
                self.assertEqual(bytes(w), frozen)
        for body in (b'\0', struct.pack('<2Q', 4, 3) + b'xy'):
            w = self.workspace()
            self.invoke(frame(1, count=1), w)
            self.invoke(frame(2, count=1, sequence=1, body=body), w)
            code, out = self.invoke(frame(3, count=1, sequence=2), w)
            self.assertEqual((code, out[11]), (REFUSED, 7))

    def test_request_and_chunk_replay_never_reset_a_live_or_broken_lease(self):
        w = self.workspace()
        self.assertEqual(self.invoke(frame(1), w)[0], 1)
        self.assertEqual(self.invoke(frame(3, sequence=1), w)[0], 0)
        self.assertEqual(self.invoke(frame(1, serial=2), w)[0], 1)
        self.assertEqual(self.invoke(frame(2, serial=2, sequence=1), w)[0], 1)
        code, out = self.invoke(frame(2, serial=2, sequence=1), w)
        self.assertEqual((code, out[11]), (REFUSED, 5))
        self.assertEqual(self.invoke(frame(3, serial=2, sequence=2), w)[0], REFUSED)
        w = self.workspace()
        self.invoke(frame(1), w)
        self.assertEqual(self.invoke(frame(1), w)[0], REFUSED)

    def test_invalid_private_cursor_state_refuses_without_a_VM_budget_exhaustion(self):
        w = self.workspace()
        self.invoke(frame(1, count=1), w)
        struct.pack_into('<Q', w, 56, 17)
        code, out = self.invoke(frame(2, count=1, sequence=1, body=b'x'), w, steps=20000)
        self.assertEqual((code, out[11]), (REFUSED, 12))

    def test_inconsistent_partial_state_and_reserved_words_refuse(self):
        for offset, value in ((48, 2), (64, 1), (80, 1), (88, 1), (104, 1), (112, 1), (120, 1)):
            with self.subTest(offset=offset):
                w = self.workspace()
                self.invoke(frame(1, count=1), w)
                struct.pack_into('<Q', w, offset, value)
                code, out = self.invoke(frame(2, count=1, sequence=1), w)
                self.assertEqual((code, out[11]), (REFUSED, 12))
        w = self.workspace()
        self.invoke(frame(1, count=1), w)
        self.invoke(frame(2, count=1, sequence=1, body=b'\x03'), w)
        struct.pack_into('<Q', w, 64, 0x103)
        self.assertEqual(self.invoke(frame(2, count=1, sequence=2), w)[1][11], 12)
        for remaining in (0, 11, 1):
            w = self.workspace()
            self.invoke(frame(1, count=1), w)
            self.invoke(frame(2, count=1, sequence=1, body=struct.pack('<2Q', 4, 10)), w)
            struct.pack_into('<Q', w, 80, remaining)
            self.assertEqual(self.invoke(frame(2, count=1, sequence=2), w)[1][11], 12)

    def test_short_buffers_and_inherent_serial_boundary(self):
        short = bytearray(127)
        before = bytes(short)
        code, out = self.invoke(frame(1), short)
        self.assertEqual(code, REFUSED)
        self.assertEqual(out, (0,) * 16)
        self.assertEqual(bytes(short), before)
        w = self.workspace()
        code, out = self.invoke(frame(1), w, output_size=127)
        self.assertEqual((code, out), (REFUSED, bytes(127)))
        code, out = self.invoke(frame(1), w)
        self.assertEqual((code, out[11]), (REFUSED, 1))
        w = self.workspace()
        self.invoke(frame(1), w)
        self.invoke(frame(3, sequence=1), w)
        # A synthetic near-u64 state checks arithmetic, not a claim to have
        # executed 2**64 requests or authenticated externally supplied state.
        struct.pack_into('<Q', w, 16, (1 << 64) - 1)
        code, out = self.invoke(frame(1, serial=0), w)
        self.assertEqual((code, out[11]), (REFUSED, 5))


if __name__ == '__main__':
    unittest.main()

