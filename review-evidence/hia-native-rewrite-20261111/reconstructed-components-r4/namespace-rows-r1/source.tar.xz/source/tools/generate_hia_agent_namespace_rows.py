"""Complete retained namespace row-decision owner, reconstructed revision 1.

The interrupted cloud revision has no reusable test result. This revision is
independently pinned and tested. Scalar/index/log peers remain explicit native
composition work; no public store or SQLite replacement is installed here.
"""
from __future__ import annotations
import ast
import json
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools.generate_hia_agent_namespace_store import VALUES

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANRW01', 'little')
PREDICATES = {
    1:[(5,0,0)],3:[(0,0,0)],4:[(2,0,0)],6:[(0,0,0),(1,1,0)],
    7:[(0,0,0)],9:[(0,1,0)],11:[(0,0,0)],12:[(0,0,0),(4,1,1)],
    13:[(0,0,0)],14:[(0,0,0)],18:[(1,0,0)],19:[(0,0,0)],
    20:[(0,1,0)],21:[(0,1,0),(2,2,0)],22:[(0,0,0)],
    23:[(0,0,0),(1,1,0)],24:[(1,0,0),(4,100,0)],27:[(0,0,0)],
    28:[(0,3,0)],30:[(0,0,0)],31:[(0,0,0)],
}
# Sources 0..5 are normalized binds. Constants 100 NULL,101 int0,102 int1,
# 103 text '0',104 text 'completed',105 allocated rowid,106 old value+1.
INSERTS = {
    2:list(range(6)),5:list(range(3)),8:list(range(6)),
    10:[105,0,1,2,3,4,5],15:list(range(4)),16:[0,1,2,3,101],
    17:[0,103,100],25:list(range(5)),26:list(range(3)),29:[0,1,2,3,102],
}
UPDATES = {
    9:[(3,104),(4,0)],12:[(4,106)],20:[(2,0)],21:[(2,100),(1,0)],
    28:[(2,0),(3,1),(1,2)],31:[(4,101)],
}
PROJECTIONS = {6:[2],13:[3],23:[2],27:[1]}
IGNORE = {2,5,15}

ROWS = r'''
def namespace_rows(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return 4294967293
    if get(w, 8) == 3:
        return emit(o, w, 4294967293)
    if length(o) < 192:
        return poison(w, 1)
    if get(w, 8) == 0:
        if initialize(s, w) == 0:
            poison(w, 2)
            return emit(o, w, 4294967293)
    else:
        if get(w, 8) != 1 or acknowledge(s, w) == 0:
            poison(w, 3)
            return emit(o, w, 4294967293)
        status = get(w, 536)
        if status == 2:
            if get(w, 208) == 0:
                put(w, 208, get(w, 512))
            poison(w, 4)
            return emit(o, w, 4294967293)
        if status == 1:
            if get(w, 512) == 0 or get(w, 208) != 0:
                poison(w, 5)
                return emit(o, w, 4294967293)
            if get(w, 88) == 1 or get(w, 88) == 16 or get(w, 88) == 17 or get(w, 88) == 18:
                poison(w, 5)
                return emit(o, w, 4294967293)
            return semantic_error(o, w, get(w, 512), get(w, 520))
    return drive(o, w)

def initialize(s:readbuf, w:mutbuf) -> u64:
    if length(s) != 128 or read64(s, 0) != ROW_MAGIC or read64(s, 8) != 1:
        return 0
    if (read64(s, 16) == 0 and read64(s, 24) == 0) or read64(s, 32) == 0:
        return 0
    if read64(s, 40) != 0 or read64(s, 48) != 0 or read64(s, 56) != 0:
        return 0
    operation = read64(s, 64)
    if operation < 1 or operation > 31 or read64(s, 72) == 0 or read64(s, 80) == 0:
        return 0
    at = 88
    while at < 128:
        if read64(s, at) != 0:
            return 0
        at = at + 8
    at = 0
    while at < 1024:
        if byte(w, at) != 0:
            return 0
        at = at + 1
    put(w, 0, ROW_MAGIC)
    put(w, 8, 1)
    put(w, 16, read64(s, 16))
    put(w, 24, read64(s, 24))
    put(w, 32, read64(s, 32))
    put(w, 40, operation)
    put(w, 48, operation_table(operation))
    put(w, 56, read64(s, 72))
    put(w, 64, read64(s, 80))
    put(w, 144, choose(operation == 18, 10001, 0))
    put(w, 152, row_width(operation_table(operation)))
    put(w, 160, operation_arity(operation))
    put(w, 240, choose(operation_mode(operation) == 0, 20, 10))
    return 1

def acknowledge(s:readbuf, w:mutbuf) -> u64:
    if get(w, 0) != ROW_MAGIC or length(s) != 128 or get(w, 80) == 0 or get(w, 80) > 18:
        return 0
    operation = get(w, 40)
    if operation < 1 or operation > 31 or get(w, 48) != operation_table(operation):
        return 0
    if get(w, 152) != row_width(get(w, 48)) or get(w, 160) != operation_arity(operation):
        return 0
    if get(w, 168) > get(w, 160) or get(w, 184) > get(w, 152):
        return 0
    if get(w, 352) >= get(w, 152):
        return 0
    if read64(s, 0) != ROW_MAGIC or read64(s, 8) != 2:
        return 0
    if read64(s, 16) != get(w, 16) or read64(s, 24) != get(w, 24) or read64(s, 32) != get(w, 32):
        return 0
    if read64(s, 40) != get(w, 72) or read64(s, 48) != get(w, 80):
        return 0
    status = read64(s, 56)
    if status > 3 or (status == 3 and get(w, 80) != 5):
        return 0
    if status != 0 and read64(s, 80) != 0:
        return 0
    at = 88
    while at < 128:
        if read64(s, at) != 0:
            return 0
        at = at + 8
    put(w, 512, read64(s, 64))
    put(w, 520, read64(s, 72))
    put(w, 528, read64(s, 80))
    put(w, 536, status)
    put(w, 88, get(w, 80))
    put(w, 80, 0)
    return 1

def poison(w:mutbuf, reason:u64) -> u64:
    if get(w, 8) != 3:
        put(w, 8, 3)
        put(w, 248, reason)
    return 4294967293

def emit(o:mutbuf, w:mutbuf, status:u64) -> u64:
    if length(o) < 192:
        return 4294967293
    at = 0
    while at < 192:
        put(o, at, 0)
        at = at + 8
    put(o, 0, ROW_MAGIC)
    put(o, 8, status)
    put(o, 16, get(w, 16))
    put(o, 24, get(w, 24))
    put(o, 32, get(w, 32))
    put(o, 40, get(w, 72))
    put(o, 48, get(w, 40))
    put(o, 56, get(w, 48))
    put(o, 64, get(w, 80))
    at = 0
    while at < 48:
        put(o, 72 + at, get(w, 576 + at))
        at = at + 8
    put(o, 120, get(w, 120))
    put(o, 128, get(w, 128))
    put(o, 136, get(w, 136))
    put(o, 144, get(w, 208))
    put(o, 152, get(w, 224))
    put(o, 160, get(w, 112))
    put(o, 168, get(w, 240))
    put(o, 176, get(w, 248))
    return status

def issue(o:mutbuf, w:mutbuf, phase:u64, action:u64, a:u64, b:u64, c:u64, d:u64, e:u64, f:u64) -> u64:
    if get(w, 72) == 18446744073709551615 or get(w, 80) != 0:
        poison(w, 6)
        return emit(o, w, 4294967293)
    put(w, 72, get(w, 72) + 1)
    put(w, 80, action)
    put(w, 240, phase)
    put(w, 576, a)
    put(w, 584, b)
    put(w, 592, c)
    put(w, 600, d)
    put(w, 608, e)
    put(w, 616, f)
    return emit(o, w, 1)

def handle(w:mutbuf) -> u64:
    if get(w, 512) == 0 or get(w, 520) != 0 or get(w, 528) != 0 or get(w, 536) != 0:
        return 0
    return get(w, 512)

def zero_reply(w:mutbuf) -> u64:
    return choose(get(w, 512) == 0 and get(w, 520) == 0 and get(w, 528) == 0 and get(w, 536) == 0, 1, 0)

def semantic_error(o:mutbuf, w:mutbuf, code:u64, detail:u64) -> u64:
    put(w, 208, code)
    put(w, 224, detail)
    if get(w, 216) != 0:
        return issue(o, w, 900, 16, get(w, 216), get(w, 64), 0, 0, 0, 0)
    return issue(o, w, 901, 18, code, get(w, 40), get(w, 48), detail, 0, 0)

def ignored_or_error(o:mutbuf, w:mutbuf, code:u64, detail:u64) -> u64:
    if operation_ignore(get(w, 40)) == 1:
        put(w, 240, 500)
        return 0
    return semantic_error(o, w, code, detail)

def invalid(o:mutbuf, w:mutbuf) -> u64:
    poison(w, 7)
    return emit(o, w, 4294967293)

def drive(o:mutbuf, w:mutbuf) -> u64:
    while True:
        phase = get(w, 240)
        if phase < 100:
            result = prepare(o, w)
        elif phase < 200:
            result = build(o, w)
        elif phase < 300:
            result = filter_row(o, w)
        elif phase < 400:
            result = unique_row(o, w)
        elif phase < 600:
            result = finish(o, w)
        else:
            result = failure(o, w)
        if result != 0:
            return result
        if get(w, 8) == 2:
            return emit(o, w, choose(get(w, 208) == 0, 0, 2))
    return 4294967293

def open_view(o:mutbuf, w:mutbuf, after:u64) -> u64:
    return issue(o, w, after, 4, get(w, 64), get(w, 48), choose(get(w, 40) == 27, 2, 1), 0, 0, 0)

def next_row(o:mutbuf, w:mutbuf, after:u64) -> u64:
    return issue(o, w, after, 5, get(w, 96), 0, 0, 0, 0, 0)

def prepare(o:mutbuf, w:mutbuf) -> u64:
    phase = get(w, 240)
    operation = get(w, 40)
    if phase == 10:
        return issue(o, w, 11, 1, get(w, 64), 0, 0, 0, 0, 0)
    if phase == 11:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 216, get(w, 512))
        put(w, 240, 20)
        return 0
    if phase == 20:
        index = get(w, 168)
        if index == get(w, 160):
            return issue(o, w, 30, 3, operation, projection_mask(operation), 0, 0, 0, 0)
        return issue(o, w, 21, 2, get(w, 56), index, bind_affinity(operation, index), 0, 0, 0)
    if phase == 21:
        if handle(w) == 0 or get(w, 168) >= get(w, 160):
            return invalid(o, w)
        put(w, 256 + get(w, 168) * 8, get(w, 512))
        put(w, 168, get(w, 168) + 1)
        put(w, 240, 20)
        return 0
    if phase == 30:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 120, get(w, 512))
        if operation_mode(operation) == 1:
            return issue(o, w, 100, 8, get(w, 152), 0, 0, 0, 0, 0)
        return open_view(o, w, 200)
    return invalid(o, w)

def assign(o:mutbuf, w:mutbuf, column:u64, value:u64) -> u64:
    return issue(o, w, 113, 9, get(w, 176), column, value, column_affinity(get(w, 48), column), 0, 0)

def build(o:mutbuf, w:mutbuf) -> u64:
    phase = get(w, 240)
    operation = get(w, 40)
    if phase == 100:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 176, get(w, 512))
        return issue(o, w, 101, 12, get(w, 64), get(w, 48), choose(operation == 10, 1, 0), 0, 0, 0)
    if phase == 101:
        if get(w, 520) == 0 or get(w, 528) != 0 or get(w, 536) != 0:
            return invalid(o, w)
        if operation == 10 and (get(w, 512) == 0 or get(w, 512) > 9223372036854775807):
            return invalid(o, w)
        put(w, 112, get(w, 512))
        put(w, 320, get(w, 520))
        put(w, 184, 0)
        put(w, 240, 110)
        return 0
    if phase == 110:
        index = get(w, 184)
        count = choose(operation_mode(operation) == 1, get(w, 152), update_count(operation))
        if index == count:
            put(w, 184, 0)
            put(w, 240, 150)
            return 0
        column = choose(operation_mode(operation) == 1, index, update_column(operation, index))
        source = choose(operation_mode(operation) == 1, insert_source(operation, index), update_source(operation, index))
        if column >= get(w, 152):
            return invalid(o, w)
        put(w, 352, column)
        if source < 6:
            return assign(o, w, column, get(w, 256 + source * 8))
        if source == 105:
            return assign(o, w, column, get(w, 320))
        if source == 106:
            return issue(o, w, 112, 11, get(w, 104), column, 0, 0, 0, 0)
        if source < 100 or source > 104:
            return invalid(o, w)
        return issue(o, w, 112, 10, source - 100, 0, 0, 0, 0, 0)
    if phase == 112:
        if handle(w) == 0:
            return invalid(o, w)
        return assign(o, w, get(w, 352), get(w, 512))
    if phase == 113:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 176, get(w, 512))
        put(w, 184, get(w, 184) + 1)
        put(w, 240, 110)
        return 0
    if phase == 150:
        index = get(w, 184)
        if index == get(w, 152):
            if operation_mode(operation) == 1 and unique_count(get(w, 48)) != 0:
                return open_view(o, w, 300)
            return write_row(o, w)
        put(w, 184, index + 1)
        if checked_not_null(operation, index) == 1:
            return issue(o, w, 151, 7, get(w, 176), index, 0, 0, 0, 0)
        return 0
    if phase == 151:
        if get(w, 512) > 4 or get(w, 520) != 0 or get(w, 528) != 0 or get(w, 536) != 0:
            return invalid(o, w)
        if get(w, 512) == 0:
            return ignored_or_error(o, w, 1299, get(w, 184) - 1)
        put(w, 240, 150)
        return 0
    return invalid(o, w)

def compare_predicate(o:mutbuf, w:mutbuf) -> u64:
    return issue(o, w, 212, 6, get(w, 104), predicate_column(get(w, 40), get(w, 192)), get(w, 336), 0, 0, 0)

def filter_row(o:mutbuf, w:mutbuf) -> u64:
    phase = get(w, 240)
    operation = get(w, 40)
    if phase == 200:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 96, get(w, 512))
        return next_row(o, w, 201)
    if phase == 201:
        if get(w, 536) == 3:
            if get(w, 512) != 0 or get(w, 520) != 0 or get(w, 528) != 0:
                return invalid(o, w)
            put(w, 240, choose(operation == 24, 450, 500))
            return 0
        if get(w, 536) != 0 or get(w, 512) == 0 or get(w, 528) != get(w, 152):
            return invalid(o, w)
        put(w, 104, get(w, 512))
        put(w, 112, get(w, 520))
        put(w, 192, 0)
        put(w, 240, 210)
        return 0
    if phase == 210:
        index = get(w, 192)
        if index == predicate_count(operation):
            put(w, 240, 220)
            return 0
        source = predicate_bind(operation, index)
        if source == 100:
            if get(w, 328) == 0:
                return issue(o, w, 211, 10, 2, 0, 0, 0, 0, 0)
            put(w, 336, get(w, 328))
        else:
            if source >= get(w, 160):
                return invalid(o, w)
            put(w, 336, get(w, 256 + source * 8))
        return compare_predicate(o, w)
    if phase == 211:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 328, get(w, 512))
        put(w, 336, get(w, 512))
        return compare_predicate(o, w)
    if phase == 212:
        if get(w, 512) > 3 or get(w, 520) != 0 or get(w, 528) != 0 or get(w, 536) != 0:
            return invalid(o, w)
        want = choose(predicate_test(operation, get(w, 192)) == 0, 1, 0)
        if get(w, 512) != want:
            if operation == 18:
                return issue(o, w, 214, 7, get(w, 104), 1, 0, 0, 0, 0)
            return next_row(o, w, 201)
        put(w, 192, get(w, 192) + 1)
        put(w, 240, 210)
        return 0
    if phase == 214:
        if get(w, 512) > 4 or get(w, 520) != 0 or get(w, 528) != 0 or get(w, 536) != 0:
            return invalid(o, w)
        if get(w, 512) != 0:
            return next_row(o, w, 201)
        put(w, 240, 220)
        return 0
    if phase == 220:
        if operation_mode(operation) == 2:
            put(w, 176, get(w, 104))
            put(w, 184, 0)
            put(w, 240, 110)
            return 0
        if operation == 24:
            if get(w, 136) == 9223372036854775807:
                return semantic_error(o, w, 18, 0)
            put(w, 136, get(w, 136) + 1)
            return next_row(o, w, 201)
        return issue(o, w, 225, 14, get(w, 120), get(w, 104), projection_mask(operation), 0, 0, 0)
    if phase == 225:
        if handle(w) == 0 or get(w, 136) == 18446744073709551615:
            return invalid(o, w)
        put(w, 120, get(w, 512))
        put(w, 136, get(w, 136) + 1)
        if get(w, 144) != 0 and get(w, 136) == get(w, 144):
            put(w, 240, 500)
            return 0
        return next_row(o, w, 201)
    return invalid(o, w)

def unique_row(o:mutbuf, w:mutbuf) -> u64:
    phase = get(w, 240)
    if phase == 300:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 96, get(w, 512))
        return next_row(o, w, 301)
    if phase == 301:
        if get(w, 536) == 3:
            if get(w, 512) != 0 or get(w, 520) != 0 or get(w, 528) != 0:
                return invalid(o, w)
            return write_row(o, w)
        if get(w, 536) != 0 or get(w, 512) == 0 or get(w, 528) != get(w, 152):
            return invalid(o, w)
        put(w, 104, get(w, 512))
        put(w, 344, 0)
        put(w, 192, 0)
        put(w, 240, 310)
        return 0
    if phase == 310:
        group = get(w, 344)
        index = get(w, 192)
        if group == unique_count(get(w, 48)):
            return next_row(o, w, 301)
        if index == unique_width(get(w, 48), group):
            return ignored_or_error(o, w, unique_error(get(w, 48), group), group)
        column = unique_column(get(w, 48), group, index)
        if column >= get(w, 152):
            return invalid(o, w)
        return issue(o, w, 311, 6, get(w, 104), column, get(w, 176), column, 0, 0)
    if phase == 311:
        if get(w, 512) > 3 or get(w, 520) != 0 or get(w, 528) != 0 or get(w, 536) != 0:
            return invalid(o, w)
        if get(w, 512) == 1:
            put(w, 192, get(w, 192) + 1)
        else:
            put(w, 344, get(w, 344) + 1)
            put(w, 192, 0)
        put(w, 240, 310)
        return 0
    return invalid(o, w)

def write_row(o:mutbuf, w:mutbuf) -> u64:
    return issue(o, w, 400, 13, get(w, 64), get(w, 48), get(w, 112), get(w, 176), choose(get(w, 40) == 10, 1, 0), 0)

def finish(o:mutbuf, w:mutbuf) -> u64:
    phase = get(w, 240)
    if phase == 400:
        if zero_reply(w) == 0 or get(w, 128) == 18446744073709551615:
            return invalid(o, w)
        put(w, 128, get(w, 128) + 1)
        if operation_mode(get(w, 40)) == 1:
            put(w, 240, 500)
            return 0
        return next_row(o, w, 201)
    if phase == 450:
        return issue(o, w, 451, 10, 5, get(w, 136), 0, 0, 0, 0)
    if phase == 451:
        if handle(w) == 0:
            return invalid(o, w)
        return issue(o, w, 452, 14, get(w, 120), get(w, 512), 1, 0, 0, 0)
    if phase == 452:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 120, get(w, 512))
        put(w, 240, 500)
        return 0
    if phase == 500:
        return issue(o, w, 501, 15, get(w, 120), get(w, 128), get(w, 136), 0, 0, 0)
    if phase == 501:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 120, get(w, 512))
        return issue(o, w, 502, 17, get(w, 120), get(w, 32), get(w, 72), 0, 0, 0)
    if phase == 502:
        if zero_reply(w) == 0:
            return invalid(o, w)
        put(w, 8, 2)
        put(w, 240, 2000)
        return 0
    return invalid(o, w)

def failure(o:mutbuf, w:mutbuf) -> u64:
    phase = get(w, 240)
    if phase == 900:
        if zero_reply(w) == 0 or get(w, 208) == 0:
            return invalid(o, w)
        put(w, 128, 0)
        return issue(o, w, 901, 18, get(w, 208), get(w, 40), get(w, 48), get(w, 224), 0, 0)
    if phase == 901:
        if handle(w) == 0:
            return invalid(o, w)
        put(w, 120, get(w, 512))
        return issue(o, w, 902, 17, get(w, 120), get(w, 32), get(w, 72), 0, 0, 0)
    if phase == 902:
        if zero_reply(w) == 0:
            return invalid(o, w)
        put(w, 8, 2)
        put(w, 240, 2000)
        return 0
    return invalid(o, w)
'''


def table_source():
    abi = json.loads((ROOT / 'docs/HIA_AGENT_NAMESPACE_STORE_ABI.json').read_bytes())
    ops = {r['id']: r for r in abi['relational_operations']}
    tables = {r['id']: r for r in abi['tables']}
    assert set(ops) == set(range(1, 32))
    assert set(PREDICATES) == set(ops) - set(INSERTS)
    assert set(INSERTS) == {i for i, r in ops.items() if r['kind'] == 'INSERT'}
    assert set(UPDATES) == {i for i, r in ops.items() if r['kind'] == 'UPDATE'}
    lines = []
    def scalar(name, values, arg='operation'):
        lines.append(f'def {name}({arg}:u64) -> u64:')
        for key, value in values.items():
            lines.extend((f'    if {arg} == {key}:', f'        return {value}'))
        lines.append('    return 18446744073709551615\n')
    def indexed(name, values, arg='operation'):
        lines.append(f'def {name}({arg}:u64, index:u64) -> u64:')
        for key, row in values.items():
            if not row:
                continue
            lines.append(f'    if {arg} == {key}:')
            for index, value in enumerate(row):
                lines.extend((f'        if index == {index}:', f'            return {value}'))
        lines.append('    return 18446744073709551615\n')
    scalar('operation_table', {i:r['table_id'] for i,r in ops.items()})
    scalar('operation_arity', {i:r['bind_count'] for i,r in ops.items()})
    scalar('row_width', {i:len(r['columns']) for i,r in tables.items()}, 'table')
    scalar('operation_mode', {i:{'SELECT':0,'INSERT':1,'UPDATE':2}[r['kind']] for i,r in ops.items()})
    scalar('operation_ignore', {i:int(i in IGNORE) for i in ops})
    scalar('projection_mask', {i:0 if r['kind'] != 'SELECT' else 1 if i == 24 else
        sum(1 << c for c in PROJECTIONS.get(i, range(len(tables[r['table_id']]['columns'])))) for i,r in ops.items()})
    scalar('predicate_count', {i:len(v) for i,v in PREDICATES.items()})
    for field,name in enumerate(('column','bind','test')):
        indexed('predicate_'+name, {i:[p[field] for p in v] for i,v in PREDICATES.items()})
    indexed('insert_source', INSERTS)
    scalar('update_count', {i:len(v) for i,v in UPDATES.items()})
    indexed('update_column', {i:[p[0] for p in v] for i,v in UPDATES.items()})
    indexed('update_source', {i:[p[1] for p in v] for i,v in UPDATES.items()})
    affinities,checks = {},{}
    for operation,op in ops.items():
        columns=tables[op['table_id']]['columns']
        affinities[operation]=[None]*op['bind_count']
        assignments=list(enumerate(INSERTS.get(operation,[])))+UPDATES.get(operation,[])
        uses=assignments+[(c,b) for c,b,comparison in PREDICATES.get(operation,[])]
        for column,bind in uses:
            if bind >= 100:
                continue
            affinity=1 if columns[column]['declared_type']=='INTEGER' else 2
            assert affinities[operation][bind] in (None,affinity)
            affinities[operation][bind]=affinity
        assert all(v is not None for v in affinities[operation])
        changed={c for c,b in assignments}
        checks[operation]=[int(col['not_null'] and i in changed) for i,col in enumerate(columns)]
    indexed('bind_affinity',affinities)
    indexed('column_affinity',{i:[1 if c['declared_type']=='INTEGER' else 2 for c in t['columns']] for i,t in tables.items()},'table')
    indexed('checked_not_null',checks)
    unique={}
    for i,table in tables.items():
        positions={col['name']:j for j,col in enumerate(table['columns'])}
        unique[i]=[(index['origin'],[positions[c['name']] for c in index['columns'] if c['key']]) for index in table['indexes']]
    scalar('unique_count',{i:len(v) for i,v in unique.items()},'table')
    indexed('unique_width',{i:[len(c) for origin,c in v] for i,v in unique.items()},'table')
    indexed('unique_error',{i:[1555 if origin=='pk' else 2067 for origin,c in v] for i,v in unique.items()},'table')
    lines.append('def unique_column(table:u64, group:u64, index:u64) -> u64:')
    for table,groups in unique.items():
        if not groups:
            continue
        lines.append(f'    if table == {table}:')
        for group,(origin,cols) in enumerate(groups):
            lines.append(f'        if group == {group}:')
            for index,column in enumerate(cols):
                lines.extend((f'            if index == {index}:',f'                return {column}'))
    lines.append('    return 18446744073709551615\n')
    return '\n'.join(lines)


def source_program():
    utilities='\n'.join(ast.unparse(n) for n in ast.parse(VALUES).body
                        if isinstance(n,ast.FunctionDef) and n.name in ('get','put','read64'))
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(MAGIC),node) if node.id=='ROW_MAGIC' else node
    source=ROWS+'\n'+utilities+'\n'+table_source()
    return ast.unparse(ast.fix_missing_locations(Expand().visit(ast.parse(source))))+'\n'


def document():
    nodes=ast.parse(source_program()).body
    names={n.name:'f'+str(i) for i,n in enumerate(nodes)}
    assert len(names)==len(nodes)
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes}
    total=total_scalar_functions(nodes)
    functions=[]
    for node in nodes:
        builder=Builder(node,names,signatures,total)
        builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],
            'returns':[builder.returns],'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_namespace_rows','functions':functions})


if __name__=='__main__':
    path=ROOT/'examples/hia_bootstrap/agent_namespace_rows.hiaasm'
    path.write_text(render_assembly(document()))
    print(path.name,path.stat().st_size)
