"""Actual-image protocol controls for new Core final visitor r1.

This is a fresh post-recovery revision. All source leases used as positive
controls come from the actual native packet issuer. Deliberately corrupted
lease/state bytes are PRIVATE fault controls, not claims of public reachability.
"""
from contextlib import ExitStack
import ctypes
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import resource
import struct
import sys
import time
import traceback
from unittest.mock import patch

from native_harness import VisitorImage, Session, BAD, MAX, MAGIC, INIT, CONT, OPAQUE, ADMIT, MIN_WORK
from hepta import hia_program as old_reference
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import ObjectTokenDecoder, detached_packet_index

resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20, 1024 << 20))
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'development/protocol-visitor-r1'
OUT.mkdir(exist_ok=False)
own_raw = Path(__file__).read_bytes()
source_path = ROOT / 'dependencies/packet-issuer/tests/test_hia_composite_packet_json.py'
issuer_raw = source_path.read_bytes()
assert sha256(issuer_raw).hexdigest() == 'a3b928ae40bd9730b0a32c79336f53c9b769138d30e229b6dd4e5184a4df4746'
spec = importlib.util.spec_from_loader('core_protocol_packet_issuer', loader=None, origin=str(source_path))
module = importlib.util.module_from_spec(spec)
module.__file__ = str(source_path)
sys.modules[spec.name] = module
exec(compile(issuer_raw, str(source_path), 'exec'), module.__dict__)
assert source_path.read_bytes() == issuer_raw
issuer = module.ActualPacketJson(OUT / 'actual-issuer')
native = VisitorImage(ROOT / 'development/compile-visitor-r1/composite-core-final.manifest.json',
                      ROOT / 'examples/hia_bootstrap/composite_core_final.hiaasm', OUT / 'actual-visitor')
cases, active, serial = [], None, 0
started = time.monotonic_ns()


def token(kind, value=0):
    return struct.pack('<2Q', kind, value)


def string(value):
    raw = value.encode('utf8')
    return token(1, len(raw)) + raw


def edit_q(raw, index, value):
    result = bytearray(raw)
    struct.pack_into('<Q', result, index * 8, value)
    return bytes(result)


def issued(value, label):
    raw = transport(value)
    extent, header, data, index, state = issuer.encode(label, raw)
    assert extent == 64 + len(data) and header[5] == len(raw)
    at = (64 + len(raw) + 7) & ~7
    lease = struct.pack('<8Q', MAGIC(b'HIASIL01'), len(raw), len(index), 64, at, at + len(index), 0, 0)
    lease += raw + b'\0' * (at - 64 - len(raw)) + index
    _, nodes = detached_packet_index(raw)
    (OUT / (label + '.packet')).write_bytes(raw)
    (OUT / (label + '.native.json')).write_bytes(data)
    return lease, data, nodes


def new(source=None, mode=2, initialized=True, size=MIN_WORK):
    global active, serial
    if active is not None:
        active.close()
    serial += 1
    active = Session(native, empty if source is None else source, stream=serial, mode=mode, size=size)
    if initialized:
        result = active.initialize()
        assert result[0] == 1152 and result[1][1] == 1
    return active


def refused(label, result, session=None):
    session = active if session is None else session
    result = session.finish(result)
    assert result[0] == BAD, (label, result)
    assert struct.unpack_from('<Q', session.work, 8)[0] == 3, (label, 'not permanently poisoned')
    before = bytes(session.work)
    event = session.event
    sequence = event[6]
    # Every dispatch family must refuse after the first ABI error; the stale
    # event must not be interpreted as an acknowledgement.
    attempts = [
        session.initial,
        session.producer_frame(token(4), final=True),
        struct.pack('<4Q', CONT, session.lease, session.stream, sequence),
        struct.pack('<16Q', OPAQUE, session.lease, session.stream, sequence,
                    1 << 63, 6, 1, MAX, 2, 0, 0, 0, 0, 0, 0, 0),
        struct.pack('<10Q', ADMIT, session.lease, session.stream, sequence, 4, 0, 0, 0, 0, 0),
        b'',
    ]
    for attempt in attempts:
        assert session.call(attempt)[0] == BAD, label
        assert bytes(session.work) == before, (label, 'poison entry changed state')
    row = {'case': label, 'result': 'PERMANENT_BAD',
           'all_six_followups_refused_with_unchanged_workspace': True,
           'input_source_and_workspace_canaries': 'unchanged',
           'entries': session.calls}
    cases.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)


def accepted(label, result, extra=None):
    assert result[0] == 1152, (label, result)
    row = {'case': label, 'result': 'ACCEPTED_CONTROL', 'event': result[1]}
    if extra:
        row.update(extra)
    cases.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)


def pending_opaque():
    session = new()
    frame = session.producer_frame(token(5, 1) + token(5, 1) + token(0, 1 << 63), final=True)
    result = session.finish(session.call(frame))
    assert result[0] == 1152 and result[1][1] == 4
    reply = struct.pack('<16Q', OPAQUE, session.lease, session.stream, result[1][6],
                        1 << 63, 6, 1, MAX, 2, 0, 0, 0, 0, 0, 0, 0)
    return session, reply


def absent(*args, **kwargs):
    raise AssertionError('host structure or token decoder entered native forwarding')


summary = None
try:
    empty, _, _ = issued(None, 'native-empty')
    source, _, node_offsets = issued({'same': 'value', 'tail': [True, False, None]}, 'native-source')
    alternate, _, _ = issued({'same': 'VALUE', 'tail': [True, False, None]}, 'native-alternate-same-extent')
    # Inspect only known test inputs outside forwarding to choose exact actual
    # issued node offsets. No registry or summary is interpreted by a host driver.
    raw_packet = source[64:64 + struct.unpack_from('<Q', source, 8)[0]]
    key_packet = transport('same')
    key_offset = next(at for at in node_offsets if raw_packet[at:at+len(key_packet)] == key_packet)
    true_offset = next(at for at in node_offsets if raw_packet[at:at+17] == transport(True))
    missing_offset = next(at for at in range(len(raw_packet)) if at not in node_offsets)

    with ExitStack() as forbidden:
        for owner, name in ((old_reference, '_bounded_detached_snapshot'),
                            (old_reference, '_structure'), (ObjectTokenDecoder, 'feed')):
            forbidden.enter_context(patch.object(owner, name, new=absent))

        # Fresh-state and initializer checks, including refusing all later tags.
        for label, mutate in [
            ('init-truncated', lambda p: p[:-1]),
            ('init-extra', lambda p: p + b'\0'),
            ('init-unknown-magic', lambda p: edit_q(p, 0, 1)),
            ('init-zero-lease', lambda p: edit_q(p, 1, 0)),
            ('init-zero-stream', lambda p: edit_q(p, 2, 0)),
            ('init-zero-producer', lambda p: edit_q(p, 3, 0)),
            ('init-mode-zero', lambda p: edit_q(p, 8, 0)),
            ('init-mode-three', lambda p: edit_q(p, 8, 3)),
            ('init-reserved', lambda p: edit_q(p, 9, 1)),
        ]:
            session = new(initialized=False)
            refused(label, session.call(mutate(session.initial)))
        for magic in (INIT, CONT, OPAQUE, ADMIT):
            session = new(initialized=False)
            refused('producer-collides-' + str(magic), session.call(edit_q(session.initial, 3, magic)))
        for label, raw in [('source-short', b''), ('source-truncated', source[:-1]),
                           ('source-extra', source + b'\0')]:
            session = new(source=source, initialized=False)
            refused(label, session.call(session.initial, source=raw))
        for index, value in [(0, 0), (1, 0), (2, 0), (3, 63), (4, 64), (5, 0), (6, 1), (7, 1)]:
            session = new(source=source, initialized=False)
            refused('source-header-word-' + str(index), session.call(session.initial, source=edit_q(source, index, value)))
        session = new()
        refused('double-init', session.call(session.initial))
        session = new(initialized=False)
        refused('producer-before-init', session.call(session.producer_frame(token(4), final=True)))

        # Exact producer extent, fields, finalization and individual token rules.
        for index, value in [(0, 1), (1, 1), (2, 1), (3, 2), (4, 1), (5, 1), (6, 2), (7, 15)]:
            session = new()
            frame = session.producer_frame(token(4), final=True)
            refused('producer-word-' + str(index), session.call(edit_q(frame, index, value)))
        for label, raw in [
            ('frame-empty', b''), ('frame-seven', b'x' * 7), ('frame-63', b'x' * 63),
            ('frame-over-65536', b'x' * 65537),
        ]:
            session = new()
            refused(label, session.call(raw))
        for label, payload in [
            ('empty-final', b''), ('short-token', b'x' * 15),
            ('extra-root', token(4) + token(4)), ('unknown-token', token(7)),
            ('unknown-token-max', token(MAX)), ('bool-two', token(3, 2)),
            ('null-nonzero', token(4, 1)), ('string-truncated', token(1, 1)),
            ('string-huge', token(1, MAX)), ('unclosed-list', token(5, 1)),
            ('unclosed-map', token(6, 1)), ('map-key-missing-value', token(6, 1) + string('k')),
            ('nonstring-key-null', token(6, 1) + token(4) + token(4)),
            ('nonstring-key-list', token(6, 1) + token(5) + token(4)),
            ('duplicate-inline', token(6, 2) + string('same') + token(4) + string('same') + token(4)),
        ]:
            session = new()
            refused(label, session.call(session.producer_frame(payload, final=True)))
        for raw in (b'\x80', b'\xc0\x80', b'\xc1\xbf', b'\xc2', b'\xe0\x80\x80',
                    b'\xed\xa0\x80', b'\xed\xbf\xbf', b'\xf0\x80\x80\x80',
                    b'\xf4\x90\x80\x80', b'\xf5\x80\x80\x80', b'\xff'):
            session = new()
            refused('bad-utf8-' + raw.hex(),
                    session.call(session.producer_frame(token(1, len(raw)) + raw, final=True)))

        # Exact native-issued membership and cross-inline/source duplicate keys.
        for offset in (missing_offset, len(raw_packet), len(raw_packet) - 1, (1 << 63) - 1):
            session = new(source=source)
            refused('unissued-source-offset-' + str(offset),
                    session.call(session.producer_frame(token(0, offset), final=True)))
        for reversed_keys in (False, True):
            keys = [token(0, key_offset), string('same')]
            if reversed_keys:
                keys.reverse()
            session = new(source=source)
            payload = token(6, 2) + keys[0] + token(4) + keys[1] + token(4)
            refused('duplicate-inline-source-' + str(reversed_keys),
                    session.call(session.producer_frame(payload, final=True)))
        session = new(source=source)
        malformed = bytearray(source)
        malformed[64 + true_offset + 16] = 2
        refused('private-forged-source-bool',
                session.call(session.producer_frame(token(0, true_offset), final=True), source=bytes(malformed)))
        session = new(source=source)
        refused('changed-source-header-after-init',
                session.call(session.producer_frame(token(4), final=True), source=edit_q(source, 6, 1)))

        # Source identity is a private immutable issuer lease, not a header hash.
        # Same-shape replacement is intentionally not claimed to be authenticated.
        session = new(source=source)
        result = session.finish(session.call(session.producer_frame(token(0, 0), final=True), source=alternate))
        accepted('PRIVATE-UNISSUED-same-shape-alternate-is-not-authenticated', result,
                 {'not_public_pipeline': True, 'fixed_driver_must_retain_exact_source_lease': True})

        # GROW is an internal replay of copied producer bytes. It must not consume
        # a second producer frame or advance its sequence before completion.
        for index, value in [(1, 999), (2, 999), (3, 999)]:
            session = new()
            result = session.call(session.producer_frame(token(5), final=True))
            assert result[1][1] == 3 and result[1][5] == 0
            continuation = struct.pack('<4Q', CONT, session.lease, session.stream, result[1][6])
            refused('grow-wrong-correlation-' + str(index), session.call(edit_q(continuation, index, value)))
        for label, kind in [('grow-truncated-cont', 0), ('grow-extra-cont', 1),
                            ('grow-replayed-producer', 2), ('grow-admission', 3)]:
            session = new()
            producer = session.producer_frame(token(5), final=True)
            result = session.call(producer)
            assert result[1][1] == 3
            continuation = struct.pack('<4Q', CONT, session.lease, session.stream, result[1][6])
            command = [continuation[:-1], continuation + b'\0', producer,
                       struct.pack('<10Q', ADMIT, session.lease, session.stream, result[1][6], 2, 0, 0, 0, 0, 0)][kind]
            refused(label, session.call(command))
        session = new()
        result = session.call(session.producer_frame(token(5), final=True))
        first = result[1]
        result = session.call(struct.pack('<4Q', CONT, session.lease, session.stream, first[6]))
        assert result[1][1] == 3 and result[1][5] == 0 and result[1][10] == first[10]
        result = session.finish(result, exact=True)
        assert result[1][1] == 5 and result[1][5] == 1 and result[1][8] == 1
        accepted('grow-without-capacity-repeats-needed-then-completes-once', result)
        session = new()
        result = session.send(b'', final=False)
        assert result[1][1] == 1 and result[1][5] == 1
        result = session.send(token(4), final=True)
        accepted('empty-nonfinal-then-one-root', result)

        # Declared huge arity consumes constant state; map pairs never multiply
        # arity by 2 in u64 or allocate a declared-size table.
        for kind in (5, 6):
            session = new()
            result = session.send(token(kind, MAX), final=False)
            assert result[1][1] == 1 and result[1][8] == 1 and session.size <= MIN_WORK * 2
            row = {'case': 'u64-max-arity-' + str(kind), 'result': 'BOUNDED_OPEN_CONTAINER',
                   'workspace_bytes': session.size, 'no_declared_arity_allocation': True}
            cases.append(row)
            print(json.dumps(row, sort_keys=True), flush=True)
            refused('u64-max-arity-final-truncation-' + str(kind), session.call(session.producer_frame(b'', final=True)))

        # Opaque handles are legal only for depth-two values in program mode.
        for label, mode, payload in [
            ('opaque-mode1', 1, token(5, 1) + token(5, 1) + token(0, 1 << 63)),
            ('opaque-root', 2, token(0, 1 << 63)),
            ('opaque-depth1', 2, token(5, 1) + token(0, 1 << 63)),
            ('opaque-depth3', 2, token(5, 1) * 3 + token(0, 1 << 63)),
            ('opaque-map-key', 2, token(5, 1) + token(6, 1) + token(0, 1 << 63)),
        ]:
            session = new(mode=mode)
            refused(label, session.call(session.producer_frame(payload, final=True)))
        for index, value in [(0, 1), (1, 999), (2, 999), (3, 999), (4, (1 << 63) + 1),
                             (5, 5), (6, 0), (6, 262146), (7, 262146), (7, 1),
                             (8, 0), (13, 1), (14, 1), (15, 1)]:
            session, reply = pending_opaque()
            refused('opaque-reply-word-' + str(index) + '-' + str(value),
                    session.call(edit_q(reply, index, value)))
        for label, mutate in [('opaque-truncated', lambda p: p[:-1]),
                              ('opaque-extra', lambda p: p+b'\0')]:
            session, reply = pending_opaque()
            refused(label, session.call(mutate(reply)))
        for label, which in [('opaque-pending-producer', 0), ('opaque-pending-cont', 1),
                             ('opaque-pending-admit', 2)]:
            session, reply = pending_opaque()
            command = [session.producer_frame(token(4), final=True),
                       struct.pack('<4Q', CONT, session.lease, session.stream, session.event[6]),
                       struct.pack('<10Q', ADMIT, session.lease, session.stream, session.event[6], 4, 0, 0, 0, 0, 0)][which]
            refused(label, session.call(command))
        session, reply = pending_opaque()
        result = session.call(reply)
        assert result[1][1] == 5 and result[1][8] == 3
        accepted('opaque-actual-pending-valid-minimal-summary', result,
                 {'private_summary_wire_control_only': True})
        refused('opaque-replay-after-complete', session.call(reply))

        # Completion and admission are distinct. Structural failure takes
        # precedence over the final JSON-byte gate and never truncates stream.
        for mode in (1, 2):
            session = new(mode=mode)
            result = session.send(token(4), final=True)
            if mode == 1:
                refused('object-summary-cannot-admit-program', session.admit(4, b'\0' * 32))
            else:
                result = session.admit(8388609, b'\0' * 32)
                assert result[1][1] == 7 and result[1][13] == 3
                accepted('byte-gate-after-valid-structure', result)
                refused('admit-replay', session.admit(4, b'\0' * 32))
        for index, value in [(1, 999), (2, 999), (3, 999), (4, 0), (9, 1)]:
            session = new()
            session.send(token(4), final=True)
            raw = struct.pack('<10Q', ADMIT, session.lease, session.stream, session.event[6], 4, 0, 0, 0, 0, 0)
            refused('admit-word-' + str(index), session.call(edit_q(raw, index, value)))
        for label, extra in [('admit-short', -1), ('admit-extra', 1)]:
            session = new()
            session.send(token(4), final=True)
            raw = struct.pack('<10Q', ADMIT, session.lease, session.stream, session.event[6], 4, 0, 0, 0, 0, 0)
            refused(label, session.call(raw[:-1] if extra < 0 else raw+b'\0'))
        session = new()
        refused('admit-before-complete', session.admit(4, b'\0' * 32))
        session = new()
        session.send(token(4), final=True)
        refused('producer-after-final', session.call(session.producer_frame(token(4), final=True)))

        for label, depth, mode, expected_status in [('program-depth-first', 65, 2, 1),
                                                   ('summary-depth-deferred', 65, 1, 0)]:
            session = new(mode=mode)
            result = session.send(token(5, 1) * depth + token(4), final=True)
            assert result[1][1] == 5 and result[1][13] == expected_status
            if mode == 2:
                result = session.admit(MAX, b'\0' * 32)
                assert result[1][13] == 1
            accepted(label, result)
        session, reply = pending_opaque()
        reply = edit_q(reply, 6, 262145)
        result = session.call(reply)
        assert result[1][1] == 5 and result[1][13] == 2
        result = session.admit(MAX, b'\0' * 32)
        assert result[1][13] == 2
        accepted('node-first-not-replaced-by-byte-gate', result,
                 {'private_summary_wire_control_only': True})

        # Sequence counters cannot wrap into accepted correlation values.
        session = new()
        struct.pack_into('<Q', session.work, 11*8, MAX)  # private S_PSEQ fault
        (OUT / 'private-pseq-max.state-prefix.bin').write_bytes(bytes(session.work[:1152]))
        refused('private-producer-sequence-overflow', session.call(session.producer_frame(token(4), final=True, sequence=MAX)))
        session = new()
        struct.pack_into('<Q', session.work, 12*8, MAX)  # private S_ESEQ fault
        (OUT / 'private-eseq-max.state-prefix.bin').write_bytes(bytes(session.work[:1152]))
        refused('private-event-sequence-overflow', session.call(session.producer_frame(token(4), final=False)))

        # The raw borrow ABI cannot poison a workspace too short to hold state.
        # Fixed executor disposal after every BAD is therefore mandatory.
        session = new()
        before = bytes(session.work)
        assert session.call(session.producer_frame(token(4), final=True), extent=MIN_WORK-1)[0] == BAD
        assert bytes(session.work) == before
        result = session.send(token(4), final=True)
        accepted('PRIVATE-short-borrow-needs-driver-disposal', result,
                 {'not_public_pipeline': True, 'no_claim_of_native_poison_for_unavailable_state': True})

    summary = {'status': 'PASS', 'scope': 'FRESH_ACTUAL_VISITOR_PROTOCOL_CONTROLS_NOT_COLD_OR_FULL_DRIVER',
               'cases': cases, 'visitor_entries': native.entries, 'issuer_entries': issuer.entries,
               'wall_elapsed_ns': time.monotonic_ns() - started,
               'production_source_unchanged': True,
               'private_lease_scope': 'Header correlation does not authenticate arbitrary source/summary bytes; fixed driver must preserve exact native-issued immutable leases.',
               'short_workspace_scope': 'BAD before writable state exists requires fixed-driver disposal, not an impossible persistent write.',
               'original_limits_unchanged': True}
except BaseException as exc:
    traceback.print_exc()
    summary = {'status': 'FAIL', 'cases': cases, 'class': type(exc).__name__, 'error': str(exc),
               'visitor_entries': native.entries, 'issuer_entries': issuer.entries}
    raise
finally:
    if active is not None:
        active.close()
    native.close()
    issuer.close()
    assert Path(__file__).read_bytes() == own_raw and source_path.read_bytes() == issuer_raw
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': summary['status'], 'case_count': len(cases),
                      'visitor_entries': native.entries, 'issuer_entries': issuer.entries}, sort_keys=True), flush=True)
