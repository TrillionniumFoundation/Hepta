from pathlib import Path
from hashlib import sha256,sha1
import io,json,os,stat,subprocess,sys,tarfile,time
ROOT=Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-workflow-fix')
OUT=Path('/workspace/scratch/9acdfa9f5639/hia-v67-workflow-fix-development')
BASE='5bd14b2cddcab29fb286b028c2e6ae0b10feee65'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
tracked=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
def snapshot():return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(set(tracked+new))}
before=snapshot();workflow=(ROOT/'.github/workflows/hia-core.yml').read_text()
components=workflow.split('for component in ',1)[1].split('; do',1)[0].split();assert len(components)==47
steps=[('regenerate-'+n,[sys.executable,'-B','-m','tools.generate_hia_'+n]) for n in components]
steps += [('contract-check',[sys.executable,'-B','tools/generate_hia_selfhost_contract.py','--check']),('language-inventory',[sys.executable,'-B','tests/test_hia_selfhost_language_coverage.py','--generate-inventory']),('core-only-audit',[sys.executable,'-B','tools/check_hia_core_only.py'])]
LOG=OUT/'prepare-attempt1-logs';LOG.mkdir(exist_ok=False)
records=[];began=time.monotonic_ns()
for label,command in steps:
 t=time.monotonic_ns()
 with (LOG/(label+'.stdout.log')).open('xb') as out,(LOG/(label+'.stderr.log')).open('xb') as err:
  proc=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(OUT/'tmp')})
 records.append({'label':label,'command':command,'returncode':proc.returncode,'elapsed_ns':time.monotonic_ns()-t})
 (LOG/'progress.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
 assert proc.returncode==0,(label,proc.returncode)
after=snapshot();assert before==after
(OUT/'generation.json').write_text(json.dumps({'all_50_steps_passed':True,'source_unchanged':True,'steps':records,'elapsed_ns':time.monotonic_ns()-began},indent=2,sort_keys=True)+'\n')
names=sorted(set(subprocess.check_output(['git','diff','--name-only',BASE],cwd=ROOT,text=True).splitlines()+new));assert set(names)=={'.github/workflows/hia-core.yml','tests/test_hia_integrated_workflow.py','docs/HIA_SELFHOST_CORE_SUPPORT.json'},names
raws={n:(ROOT/n).read_bytes() for n in names}
owned=[{'path':n,'bytes':len(raws[n]),'sha256':sha256(raws[n]).hexdigest(),'git_sha':sha1(b'blob '+str(len(raws[n])).encode()+b'\0'+raws[n]).hexdigest(),'mode':stat.S_IMODE((ROOT/n).stat().st_mode)} for n in names]
cp='docs/HIA_SELFHOST_CORE_SUPPORT.json';cr=(ROOT/cp).read_bytes();contract=json.loads(cr);closure={**contract['source_identity']['files'],cp:sha256(cr).hexdigest()};assert len(closure)==644 and all(after[n]==h for n,h in closure.items())
manifest={'scope':'V67_WORKFLOW_ENVIRONMENT_REPAIR_SOURCE_FROZEN_BEFORE_GATES','base_commit':BASE,'base_tree':'080d445487e2944b49715ef83d37aa8ccf9ca407','root':str(ROOT),'owned_files':owned,'source_count':len(closure),'source_closure':closure,'previous_5bd_ci_workflow_rejected_before_jobs':True,'whole_stack_closed':False}
encoded=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();(OUT/'source-frozen.json').write_bytes(encoded)
archive=OUT/'source-frozen.tar.xz'
with tarfile.open(archive,'x:xz') as tf:
 for r in owned:
  i=tarfile.TarInfo('source/'+r['path']);i.size=r['bytes'];i.mode=r['mode'];tf.addfile(i,io.BytesIO(raws[r['path']]))
 i=tarfile.TarInfo('SOURCE_MANIFEST.json');i.size=len(encoded);i.mode=0o644;tf.addfile(i,io.BytesIO(encoded))
with tarfile.open(archive,'r:xz') as tf:
 assert len(tf.getmembers())==len(owned)+1
 for r in owned:
  m=tf.getmember('source/'+r['path']);assert m.mode==r['mode'] and tf.extractfile(m).read()==raws[r['path']]
 assert tf.extractfile('SOURCE_MANIFEST.json').read()==encoded
receipt={'scope':'COMPLETE_REPRODUCTION_AND_SOURCE_FREEZE_NOT_COLD','source_manifest_sha256':sha256(encoded).hexdigest(),'archive_sha256':sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'owned_files':len(owned),'source_count':len(closure),'source_files':len(after),'source_preserved':snapshot()==after,'gates_or_limits_weakened':False,'whole_stack_closed':False}
(OUT/'freeze-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps(receipt),flush=True)
