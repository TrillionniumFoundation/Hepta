"""Actual receipt constructor replay and immutable continuation controls."""
from hashlib import sha256
import json,struct,time,traceback
from pathlib import Path
from hepta.hia_agent_assembly import assemble_program
from bounded_input_harness import Actual,BAD
from receipt_graph_harness import run
from facts_harness import vm_call

DEV=Path(__file__).resolve().parent;OUT=DEV/'receipt-graph-protocol-r1';OUT.mkdir(exist_ok=False)
prior=DEV/'complete-edit-native-r3/actual/receipt';rows=[json.loads(x) for x in (prior/'entries.jsonl').read_text().splitlines()]
row=rows[0];graph=(prior/('source-'+row['source_sha256']+'.lease')).read_bytes();ctl=(prior/(row['prefix']+'.command.bin')).read_bytes()
before=(prior/(row['prefix']+'.before.bin')).read_bytes();expected=(prior/(row['prefix']+'.after.bin')).read_bytes()
native=Actual(DEV/'receipt-graph-source-and-compile-r1/agent-edit-receipt-graph.manifest.json',OUT/'actual')
checked=assemble_program((DEV/'receipt-graph-source-and-compile-r1/source/examples/hia_bootstrap/agent_edit_receipt_graph.hiaasm').read_bytes())
pins={p:p.read_bytes() for p in (Path(__file__),DEV/'receipt_graph_harness.py')};controls=[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')
def refuse(label,a,b,w,vm=False):
    code,after=native.call(label,a,b,w);assert code==BAD,(label,code)
    if vm:assert vm_call(checked,a,b,w)==(code,after)
    if len(w)>=1024:
        assert struct.unpack_from('<Q',after,8)[0]==3
        repeated,last=native.call(label+'-permanent',a,b,after);assert repeated==BAD and last==after
    else:assert after==w
    controls.append(dict(case=label,complete_workspace_VM_pair=vm,permanent_poison_or_short_discard=True))
try:
    code,after=native.call('actual-original-first-growth',graph,ctl,before);assert code==384 and after==expected
    assert vm_call(checked,graph,ctl,before)==(code,after)
    event,terminal,result=run(native.call,'complete-original-receipt',graph,ctl)
    grown=expected+bytes(struct.unpack_from('<Q',expected,296)[0]-len(expected))
    continuation=ctl[:8]+struct.pack('<Q',2)+ctl[16:32]+struct.pack('<Q',struct.unpack_from('<Q',expected,288)[0])+ctl[40:]
    for offset,value in [(0,0),(8,0),(16,0),(24,0),(32,1),(40,0),(40,3),(48,0),(56,0),(64,1),(72,1),(160,1)]:
        changed=bytearray(ctl);struct.pack_into('<Q',changed,offset,value);refuse('initial-'+str(offset)+'-'+str(value),graph,bytes(changed),bytes(1024),vm=offset==0)
    for offset in (16,24,32,128,159):
        changed=bytearray(continuation);changed[offset]^=1;refuse('grow-command-'+str(offset),graph,bytes(changed),grown,vm=offset==128)
    for offset in (0,8,24,48):
        changed=bytearray(graph);changed[offset]^=1;refuse('grow-header-'+str(offset),bytes(changed),continuation,grown)
    dirty=bytearray(1024);dirty[1009]=1;refuse('dirty-initial',graph,ctl,bytes(dirty))
    refuse('terminal-replay',graph,ctl,terminal,vm=True)
    for size in (0,511,1023):refuse('short-'+str(size),graph,ctl,bytes(size))
    summary.update(status='PASS',successful_original_replays=1,private_controls=controls,actual_entries=native.entries,
        complete_first_growth_VM_pair=True,source_and_canaries_unchanged=True,whole_stack_closed=False)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc),completed_controls=controls);traceback.print_exc();raise
finally:
    native.close();summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in pins.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('private_controls','completed_controls')},sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
