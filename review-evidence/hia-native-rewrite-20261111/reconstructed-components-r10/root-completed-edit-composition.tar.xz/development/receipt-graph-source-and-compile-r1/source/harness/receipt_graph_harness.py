"""Mechanical private final receipt composition after actual admission."""
import struct
from packet_graph_harness import MAGIC

def command(mode,receipt,metadata,input_hash,*,request=1,sequence=0,action=1):
    assert len(input_hash)==32
    return struct.pack('<16Q',MAGIC(b'HIAQRC01'),action,107,request,sequence,mode,receipt,metadata,*([0]*8))+input_hash+bytes(32)

def run(call,label,graph,control):
    before=bytes(1024)
    while True:
        code,after=call(label,graph,control,before);event=struct.unpack_from('<16Q',after,256)
        assert code==384 and event[0]==MAGIC(b'HIAQRE01'),(label,code,event)
        if event[1]==0:return event,after,after[event[6]:event[6]+event[7]]
        assert event[1]==1 and event[5]>len(after),(label,event)
        before=after+bytes(event[5]-len(after))
        control=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',event[4])+control[40:]
