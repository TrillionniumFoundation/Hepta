"""Complete actual native semantic chain against the retained public entries.

Foreign Graph capture is outside the guarded execution. Detailed Core dynamic
diagnostics and the final fixed HIA coordinator remain explicit open boundaries.
"""
from contextlib import ExitStack
import copy,json,sys,time,traceback
from pathlib import Path
from unittest.mock import patch
from hepta import hia_edit_query,hia_edit_batch,hia_program,hia_program_tools,hia_instruction_policy_native,hia_json_decode_native,hia_composite_function_tokens
from hepta.hia_program import verify_program
from hepta.hia_program_tools import bounded_json_wire
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans,selected,swaps
from tests.test_hia_program_composite import stored_loan_program
from complete_edit_pipeline import CompleteEditPipeline,NativeRefusal

DEV=Path(__file__).resolve().parent;OUT=DEV/'complete-edit-native-r1';OUT.mkdir(exist_ok=False)
pipeline=CompleteEditPipeline(OUT/'actual');gm=pipeline.peers.wm;cases=[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')
def forbidden(*args,**kwargs):raise AssertionError('host semantic/JSON/edit/receipt owner entered actual native chain')
def guards():
    stack=ExitStack()
    for owner,name in [(hia_program,'verify_program'),(hia_edit_query,'prepare_edit'),(hia_edit_query,'apply_edit'),
        (hia_edit_batch,'prepare_batch'),(hia_edit_batch,'apply_batch'),(hia_edit_query,'_reference_edit_slice'),
        (hia_edit_query,'_cfg_downstream_slice'),(hia_program_tools,'bounded_json_wire'),(hia_program_tools,'decode_json'),
        (hia_program_tools,'apply_program_patch'),(hia_instruction_policy_native,'transport'),
        (hia_composite_function_tokens,'detached_packet_index'),(hia_composite_function_tokens.ObjectTokenDecoder,'feed'),
        (hia_json_decode_native,'materialize'),(json,'loads')]:stack.enter_context(patch.object(owner,name,new=forbidden))
    return stack
def exercise(label,document,query,response,mode):
    raw=document if type(document) is bytes else bounded_json_wire(document,8<<20,ensure_ascii=False)
    expected=None;error=None
    try:
        changed,receipt=(hia_edit_query.apply_edit if mode==1 else hia_edit_batch.apply_batch)(document,query,response)
        expected=(changed.canonical_bytes,bounded_json_wire(receipt,8<<20))
    except Exception as exc:
        error=dict(type=type(exc).__name__,message=str(exc),code=getattr(exc,'code',None),cause_type=type(exc.__cause__).__name__ if exc.__cause__ else None)
    qg=gm.capture(query);rg=gm.capture(response);index=len(cases);case=OUT/('case-'+str(index).zfill(3));case.mkdir()
    for name,value in [('program',raw),('query.graph',qg),('response.graph',rg)]: (case/name).write_bytes(value)
    (case/'oracle.json').write_text(json.dumps(dict(error=error,accepted=expected is not None),indent=2,sort_keys=True)+'\n')
    if expected:
        (case/'expected-candidate.json').write_bytes(expected[0]);(case/'expected-receipt.json').write_bytes(expected[1])
    actual_error=None;actual=None;stage_start=len(pipeline.stages)
    with guards():
        try:actual=pipeline.execute(label,raw,qg,rg,mode)
        except NativeRefusal as exc:actual_error=exc
    if error is not None:
        assert actual is None and actual_error is not None,(label,error,actual)
        assert actual_error.domain==error['type'],(label,actual_error.__dict__,error)
        if error['type']=='HIAProgramRejected':
            assert actual_error.code==error['code'],(label,actual_error.__dict__,error)
            outcome='EXACT_CORE_CATEGORY_DYNAMIC_TEXT_OPEN'
        else:
            assert actual_error.text==error['message'],(label,actual_error.__dict__,error)
            outcome='EXACT_PUBLIC_ERROR_TEXT_AND_ORDER'
    else:
        assert actual_error is None and actual is not None,(label,actual_error.__dict__ if actual_error else None)
        assert actual['candidate']==expected[0],label
        assert actual['receipt']==expected[1],(label,actual['receipt'],expected[1])
        for name,value in actual.items():
            if type(value) is bytes:(case/('actual-'+name+'.bin')).write_bytes(value)
        outcome='EXACT_COMPLETE_CANDIDATE_AND_FULL_RECEIPT'
    observed=pipeline.stages[stage_start:]
    if actual_error is not None:assert not any(v['stage'] in ('final-native-receipt','complete') for v in observed)
    cases.append(dict(case=label,mode=mode,outcome=outcome,expected_error=error,
        actual_error=actual_error.__dict__ if actual_error else None,stages=observed,
        hosted_owners_disabled=True,public_capture_and_fixed_coordinator_closed=False))
    print(json.dumps(dict(completed=len(cases),case=label,outcome=outcome)),flush=True)

try:
    base=fixture();single=hia_edit_query.prepare_edit(base,function='calculate',block='entry',output='y',fields=['op'])
    exercise('single-object',base,single,{'op':'int.sub.wrap'},1)
    exercise('single-text-exact-raw-hash',base,single,' { "op" : "int.mul.wrap" } \n',1)
    exercise('single-bytes',base,single,b'{"op":"int.add.wrap"}',1)
    exercise('single-duplicate-response',base,single,b'{"op":"int.add.wrap","op":"int.sub.wrap"}',1)
    forged=copy.deepcopy(single);forged['context']['dependencies'][0]['operation']['attrs']['value']=True
    exercise('bool-forgery-before-invalid-response',base,forged,b'!\xff',1)
    forged=copy.deepcopy(single);forged['fields']=None;forged['context']=None
    exercise('fields-before-unencodable-response',base,forged,'\ud800',1)
    exercise('single-native-core-refusal',base,single,{'op':'not.real'},1)
    batch_base=loans();batch=hia_edit_batch.prepare_batch(batch_base,[selected('reader'),selected('writer')])
    exercise('atomic-batch',batch_base,batch,swaps(),2)
    exercise('atomic-batch-text-query',batch_base,json.dumps(batch,ensure_ascii=False,indent=2),json.dumps(swaps(),indent=1),2)
    reverse=swaps();reverse['edits'].reverse()
    exercise('atomic-batch-reverse-response',batch_base,batch,reverse,2)
    exercise('batch-invalid-query-before-response',batch_base,b'!\xff','\ud800',2)
    repeated=hia_edit_batch.prepare_batch(batch_base,[selected('reader')]);repeated['sites'].append({'site':1,'query':copy.deepcopy(repeated['sites'][0]['query'])})
    exercise('batch-overlap-before-invalid-response',batch_base,repeated,b'!\xff',2)
    broken=copy.deepcopy(batch);broken['sites'][0]['query']['fields']=[];broken['sites'][1]['query']['selector']={}
    exercise('all-nested-shapes-before-first-fields',batch_base,broken,swaps(),2)
    changed=fixture();changed['functions'][1]['blocks'][0]['ops'][0]['attrs']['function']='absent'
    exercise('invalid-original-before-query',changed,None,b'!\xff',1)
    structured=stored_loan_program();admitted=verify_program(structured);core=admitted.as_dict();fn=core['functions'][0]
    block=next(v for v in fn['blocks'] if v['id']==fn['entry']);operation=next(v for v in block['ops'] if v['out'])
    selection=dict(function=fn['name'],block=block['id'],output=operation['out'][0]['name'],fields=['op','args','attrs'])
    query=hia_edit_query.prepare_edit(structured,**selection)
    response={k:copy.deepcopy(operation[k]) for k in selection['fields']}
    exercise('structured-original-digest-single',structured,query,response,1)
    batch=hia_edit_batch.prepare_batch(structured,[selection])
    exercise('structured-original-digest-batch',structured,batch,{'edits':[{'site':0,'changes':response}]},2)
    summary.update(status='PASS',cases=cases,case_count=len(cases),whole_stack_closed=False,
        entire_receipts_compared=True,all_native_source_pins_unchanged=True,full_dynamic_core_text_closed=False)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc),completed_cases=cases);traceback.print_exc();raise
finally:
    pipeline.close();summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
