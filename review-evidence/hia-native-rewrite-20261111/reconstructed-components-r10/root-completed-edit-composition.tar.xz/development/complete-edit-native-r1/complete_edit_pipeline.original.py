"""Development mechanical composition of actual native edit owners.

No hosted schema, selector, query, response, patch or receipt policy runs in
this path. Native events are forwarded by Python for this integration proof;
this file is not the final HIA public controller or fixed executable. Graph
capture occurs outside this path and remains an explicit foreign boundary.
Constant error-code presentation and dynamic Core error text remain separate.
"""
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import struct
import subprocess
from hepta.hia_core_admission_native import NativeCoreAdmission,ERROR_CODES
from hepta.hia_core_patch_native import NativeCorePatch
from hepta.hia_agent_candidate_native import NativeAgentCandidatePatch
from packet_graph_harness import Actual,MAGIC
from bounded_input_harness import Actual as ContentActual,Peers,Evidence,command as bound_command,run as bound_run
from input_graph_harness import command as prefix_command,run as prefix_run,ERRORS as PREFIX_ERRORS
from selection_harness import command as select_command,run as select_run,ERRORS as SELECT_ERRORS
from batch_graph_harness import command as batch_command,run as batch_run
from match_wire_harness import run as match_run
from graph_merge_harness import merge
from apply_graph_harness import command as apply_command,run as apply_run,serialize_root,ERRORS as APPLY_ERRORS
from receipt_graph_harness import command as receipt_command,run as receipt_run
from native_query_pipeline import NativeQueryPipeline
from core_packet_transport import CorePacketTransport
from facts_harness import lease

DEV=Path(__file__).resolve().parent
ADMISSION_ELF=DEV.parent/'native-program-admission-next/development/build-r2/hia-admit-program'
ADMISSION_SHA='8f3331a1763adbf7630f72e1216493c956ca979010dd6c50c8c29fdb56f1c57d'

class NativeRefusal(Exception):
    def __init__(self,stage,text=None,*,domain='HIAEditRejected',code=None,native_status=None):
        super().__init__(text);self.stage=stage;self.text=text;self.domain=domain;self.code=code;self.native_status=native_status

class AllEntryEvidence(Evidence):
    """Guard and record low-level peers whose convenience wrappers omit a log."""
    def __init__(self,out):super().__init__(out);self.stage='initial';self.roles={}
    def attach(self,owner,role):
        entry=owner._entry
        def invoke(a,an,b,bn,w,wn):
            first=ctypes.string_at(a,an);second=ctypes.string_at(b,bn);before=ctypes.string_at(w,wn);guard=b'\xd9'*32
            ca=ctypes.create_string_buffer(first+guard);cb=ctypes.create_string_buffer(second+guard);cw=ctypes.create_string_buffer(before+guard)
            result=int(entry(ca,an,cb,bn,cw,wn));out=ctypes.string_at(cb,bn);after=ctypes.string_at(cw,wn)
            assert ctypes.string_at(ca,an+32)==first+guard
            assert ctypes.string_at(ctypes.addressof(cb)+bn,32)==guard
            assert ctypes.string_at(ctypes.addressof(cw)+wn,32)==guard
            ctypes.memmove(b,cb,bn);ctypes.memmove(w,cw,wn)
            self.roles[role]=self.roles.get(role,0)+1
            self.record(self.stage,first,second,before,after,result,role=role,second_after=self.raw(out),readonly_input_and_canaries_unchanged=True)
            return result
        owner._entry=invoke

class NativeQueryParts(NativeQueryPipeline):
    def prepare_graph(self,label,source_packet,base_digest,input_digest):
        self.requests+=1;unused,index=self.encode(label+'-source',source_packet);source=lease(source_packet,index)
        code,event,state=self.facts.run(label,source,request=self.requests)
        assert code==384 and event[1]==0,(label,code,event)
        fact=state[event[6]:event[6]+event[7]];sliced=self.slice.run(fact)
        at=event[10]-(1<<63);size=16+struct.unpack_from('<Q',source_packet,at+8)[0]
        opwire,unused=self.encode(label+'-operation',source_packet[at:at+size])
        opwire=self.canonical.canonicalize(opwire,max_nodes=262144,max_depth=64);digest=self.hasher.digest(opwire)
        control=(struct.pack('<16Q',MAGIC(b'HIAQQC01'),1,73,self.requests,0,len(fact),len(sliced),
                    *event[8:11],event[11],event[12],event[13],0,0,0)+base_digest+input_digest+digest+bytes(32)+fact+sliced)
        before=bytes(1024)
        while True:
            code,after=self.query.call(label,control,source,before);qevent=struct.unpack_from('<16Q',after,256);assert code==384
            if qevent[1]==0:break
            assert qevent[1]==1 and qevent[5]>len(after);before=after+bytes(qevent[5]-len(after))
            control=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',qevent[4])+control[40:]
        packet=after[qevent[6]:qevent[6]+qevent[7]];unused,index=self.encode(label+'-query',packet)
        graph,unused=self.bridge.run(label,lease(packet,index),request=self.requests)
        return graph

class CompleteEditPipeline:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False);self.pins={};self.sequence=0;self.stages=[]
        self.all=AllEntryEvidence(self.out/'other-actual-entries')
        self.prefix=Actual(DEV/'input-graph-source-and-compile-r1/agent-edit-input-graph.manifest.json',self.out/'prefix')
        self.selector=Actual(DEV/'selection-source-and-compile-r3/agent-edit-selection.manifest.json',self.out/'selector')
        self.batch=Actual(DEV/'batch-graph-source-and-compile-r1/agent-edit-batch-graph.manifest.json',self.out/'batch')
        self.merger=Actual(DEV/'graph-merge-source-and-compile-r1/graph-merge.manifest.json',self.out/'merge')
        self.apply=Actual(DEV/'apply-graph-source-and-compile-r1/agent-edit-apply-graph.manifest.json',self.out/'apply')
        self.receipt=Actual(DEV/'receipt-graph-source-and-compile-r1/agent-edit-receipt-graph.manifest.json',self.out/'receipt')
        self.bounded=ContentActual(DEV/'bounded-input-source-and-compile-r3/agent-edit-bounded-input.manifest.json',self.out/'bounded')
        self.match=ContentActual(DEV/'match-wire-source-and-compile-r1/agent-edit-match-wire.manifest.json',self.out/'match')
        self.peers=Peers(self.out/'peers');self.codec=CorePacketTransport(self.out/'core-codec');self.queries=NativeQueryParts(self.out/'queries')
        for name,typ,attr in [('core_admission',NativeCoreAdmission,'admission'),('core_patch',NativeCorePatch,'patcher'),('core_patch',NativeAgentCandidatePatch,'candidate')]:
            path=DEV/'apply-graph-native-r1'/(name+'.image.bin');raw=path.read_bytes();self.pins[path]=raw
            obj=typ(raw,sha256(raw).hexdigest());setattr(self,attr,obj);self.all.attach(obj,attr)
        for name in ('slice','canonical','hasher'):self.all.attach(getattr(self.queries,name),name)
        image=ADMISSION_ELF.read_bytes();assert sha256(image).hexdigest()==ADMISSION_SHA;self.pins[ADMISSION_ELF]=image
        self.process_log=(self.out/'program-admission.jsonl').open('w')
        for p in [Path(__file__),DEV/'receipt_graph_harness.py',DEV/'native_query_pipeline.py',DEV/'core_packet_transport.py']:
            self.pins[p]=p.read_bytes()
    def step(self,label,stage):
        self.sequence+=1;self.all.stage=label+':'+stage;self.stages.append(dict(sequence=self.sequence,case=label,stage=stage));return self.sequence
    def bounded_value(self,label,stage,graph,policy,digits):
        request=self.step(label,stage);result=bound_run(self.bounded.call,self.peers,label+':'+stage,graph,bound_command(graph,policy,digits=digits,request=request))
        if result['error'] is not None:
            raise NativeRefusal(stage,result['error'],domain='UnicodeEncodeError' if result['result'][2]==2 else 'HIAEditRejected')
        return result
    def native_program(self,label,raw):
        self.step(label,'program-admission')
        completed=subprocess.run([str(ADMISSION_ELF)],input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'PATH':'','HOME':''},timeout=20)
        self.process_log.write(json.dumps(dict(case=label,returncode=completed.returncode,stdin=self.all.raw(raw),stdout=self.all.raw(completed.stdout),stderr=self.all.raw(completed.stderr),elf_sha256=ADMISSION_SHA,empty_path_home=True),sort_keys=True)+'\n');self.process_log.flush()
        if completed.returncode==2:
            assert not completed.stdout and len(completed.stderr)==128
            event=struct.unpack('<16Q',completed.stderr);assert event[0]==MAGIC(b'HIACDE01')
            raise NativeRefusal('program-admission',domain='HIAProgramRejected',code=ERROR_CODES.get(event[5]) if event[4]==8 else None,native_status=event[4:6])
        assert completed.returncode==0 and len(completed.stderr)==256,(label,completed.returncode,completed.stderr[:128])
        fields=struct.unpack('<32Q',completed.stderr);assert fields[0]==MAGIC(b'HIAPRV01') and fields[1]==1 and fields[2]==72
        assert fields[8]==len(completed.stdout) and fields[18:27]==(45,52 if fields[4] else 0,56,256,1,fields[4],0,0,0) and fields[27:]==(0,)*5
        core_digest=completed.stderr[112:144];input_digest=completed.stderr[80:112]
        # Complete successful process + complete source-specific Core are joined.
        assert self.queries.hasher.digest(completed.stdout)==core_digest
        return completed.stdout,core_digest,input_digest,completed.stderr
    def prefix_value(self,label,graph,mode,index=0):
        request=self.step(label,'input-prefix-'+str(mode)+'-'+str(index));event,roots,after=prefix_run(self.prefix.call,label,graph,prefix_command(graph,mode,index,request))
        if event[1]==2:raise NativeRefusal('input-prefix',PREFIX_ERRORS[event[9]])
        return event,roots
    def single(self,label,source,graph,roots,core_digest,input_digest,digits):
        request=self.step(label,'selector');event,after=select_run(self.selector.call,label,source,select_command(graph,roots,request=request))
        if event[1]==2:raise NativeRefusal('selector',SELECT_ERRORS[event[8]])
        packet=after[event[6]:event[6]+event[7]];self.step(label,'query-facts-slice-projection')
        query=self.queries.prepare_graph(label,packet,core_digest,input_digest)
        wire=self.bounded_value(label,'prepared-query-wire',query,5,digits)['raw']
        return query,wire
    def batch_queries(self,label,source,graph,core_digest,input_digest,digits,*,from_query):
        event,roots=self.prefix_value(label,graph,3 if from_query else 2);count=event[5];joined=None;query_roots=[]
        for index in range(count):
            if from_query:selection=roots[index]
            else:
                if index:event,roots=self.prefix_value(label,graph,2,index)
                selection=roots[0]
            query,unused=self.single(label+'-site-'+str(index),source,graph,selection,core_digest,input_digest,digits)
            if joined is None:joined=query;query_roots=[struct.unpack_from('<Q',query,24)[0]]
            else:
                count_before=struct.unpack_from('<Q',joined,16)[0]
                joined,unused=merge(self.merger.call,label+'-query-merge',joined,query,request=self.step(label,'batch-query-merge'))
                query_roots=[x+1 for x in query_roots]+[struct.unpack_from('<Q',query,24)[0]+count_before+1]
            event,after=batch_run(self.batch.call,label,joined,batch_command(query_roots,0,request=self.step(label,'batch-overlap')))
            if event[1]==2:
                assert event[8]==1;raise NativeRefusal('batch-overlap','E_HIA_EDIT_BATCH: selections overlap one instruction')
        event,after=batch_run(self.batch.call,label,joined,batch_command(query_roots,1,request=self.step(label,'batch-final')));assert event[1]==0
        result=after[event[6]:event[6]+event[7]];wire=self.bounded_value(label,'prepared-batch-wire',result,5,digits)['raw']
        return result,wire
    def execute(self,label,program_wire,query_graph,response_graph,mode,*,digits=4300):
        core,core_digest,input_digest,program_receipt=self.native_program(label,program_wire)
        self.step(label,'core-typed-codec');packet,source=self.codec.decode(label,core)
        if mode==1:
            event,roots=self.prefix_value(label,query_graph,1)
            query,query_wire=self.single(label,source,query_graph,roots[0],core_digest,input_digest,digits)
            untrusted=self.bounded_value(label,'untrusted-query-wire',query_graph,4,digits)['raw']
        else:
            normalized=self.bounded_value(label,'batch-query-input',query_graph,2,digits)['graph']
            query,query_wire=self.batch_queries(label,source,normalized,core_digest,input_digest,digits,from_query=True)
            untrusted=self.bounded_value(label,'normalized-query-wire',normalized,5,digits)['raw']
        self.step(label,'exact-query-comparison');event,unused,error=match_run(self.match.call,label,untrusted,query_wire,mode=mode,request=self.sequence)
        if error is not None:raise NativeRefusal('exact-query-comparison',error)
        response=self.bounded_value(label,'response-input',response_graph,1 if mode==1 else 3,digits)
        self.step(label,'base-graph');base_graph,unused=self.queries.bridge.run(label,source,request=self.sequence)
        first,unused=merge(self.merger.call,label+'-base-query',base_graph,query,request=self.step(label,'base-query-merge'))
        triple,unused=merge(self.merger.call,label+'-response',first,response['graph'],request=self.step(label,'response-merge'))
        roots=(struct.unpack_from('<Q',base_graph,24)[0]+2,
               struct.unpack_from('<Q',query,24)[0]+struct.unpack_from('<Q',base_graph,16)[0]+2,
               struct.unpack_from('<Q',response['graph'],24)[0]+struct.unpack_from('<Q',first,16)[0]+1)
        qhash=self.queries.hasher.digest(query_wire);rhash=self.queries.hasher.digest(response['raw'])
        request=self.step(label,'response-policy-and-patch')
        event,after=apply_run(self.apply.call,label,triple,apply_command(mode,roots,len(response['raw']),qhash,rhash,request=request))
        if event[1]==2:raise NativeRefusal('response-policy',APPLY_ERRORS[event[8]])
        assert event[1]==0;pending=after[event[6]:event[6]+event[7]]
        self.step(label,'patch-envelope-wire');envelope=serialize_root(self.queries.wire,pending,event[10],(16<<20)+3,label+'-envelope')
        self.step(label,'extract-base');extracted,version,policy,count=self.patcher.transform(envelope,extract=True);assert extracted==core
        self.step(label,'recheck-extracted-base');status=self.admission.status(extracted);assert status==0
        self.step(label,'patch-candidate-and-private-receipt');candidate,patch_receipt=self.candidate.result(envelope,1)
        self.step(label,'whole-candidate-admission');status=self.admission.status(candidate)
        if status:
            raise NativeRefusal('whole-candidate-admission',domain='HIAProgramRejected',code=ERROR_CODES.get(status),native_status=status)
        # No receipt is exposed before the exact candidate's complete admission.
        self.step(label,'admitted-patch-receipt-graph');decoded=self.peers.decode.run(patch_receipt,9,case=label+'-patch-receipt');assert 'graph' in decoded
        receipt_graph=decoded['graph'];joined,unused=merge(self.merger.call,label+'-final-receipt',receipt_graph,pending,request=self.step(label,'receipt-merge'))
        receipt_root=struct.unpack_from('<Q',receipt_graph,24)[0]+1
        metadata_root=event[11]+struct.unpack_from('<Q',receipt_graph,16)[0]+1
        re,unused,final_graph=receipt_run(self.receipt.call,label,joined,receipt_command(mode,receipt_root,metadata_root,input_digest,request=self.step(label,'final-native-receipt')))
        final_receipt=serialize_root(self.queries.wire,final_graph,re[9],8<<20,label+'-full-receipt')
        self.step(label,'complete')
        return dict(core=core,candidate=candidate,receipt=final_receipt,query=query_wire,response_raw=response['raw'],
                    original_input_digest=input_digest,core_digest=core_digest,program_receipt=program_receipt)
    def close(self):
        for name in ('prefix','selector','batch','merger','apply','receipt','bounded','match','peers','codec','queries'):getattr(self,name).close()
        self.process_log.close();self.all.close();assert all(p.read_bytes()==raw for p,raw in self.pins.items())
        (self.out/'custody.json').write_text(json.dumps(dict(pins={str(p):sha256(v).hexdigest() for p,v in self.pins.items()},
            source_before_after_equal=True,stages=self.stages,other_actual_entries=self.all.roles,
            scope='DEVELOPMENT_MECHANICAL_NATIVE_COMPOSITION_NOT_PUBLIC_HIA_COORDINATOR'),indent=2,sort_keys=True)+'\n')
