"""Freeze receipt constructor and execute independently before real B3."""
from hashlib import sha256
import importlib.util,json,struct,sys,time,traceback
from pathlib import Path
from hepta.hia_agent_assembly import assemble_program,render_assembly
from hepta.hia_edit_query import prepare_edit,apply_edit
from hepta.hia_edit_batch import prepare_batch,apply_batch
from hepta.hia_program_tools import bounded_json_wire
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans,selected,swaps
from tools.generate_hia_agent_edit_receipt_graph import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from packet_graph_harness import decode_graph_reference,Actual
from receipt_graph_harness import command,run

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native';OUT=DEV/'receipt-graph-source-and-compile-r1';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_receipt_graph.py',ROOT/'tools/generate_hia_agent_edit_apply_graph.py',
       ROOT/'tools/generate_hia_graph_merge.py',ROOT/'tools/hia_agent_edit_source_views.py',
       ROOT/'examples/hia_bootstrap/agent_edit_receipt_graph.hiaasm',COMPILER,Path(__file__),DEV/'receipt_graph_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
spec=importlib.util.spec_from_file_location('receipt_vm_capture',DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py')
gm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gm;spec.loader.exec_module(gm)
summary=dict(status='INCOMPLETE',scope='PRIVATE_RECEIPT_CONSTRUCTION_NOT_ADMISSION_AUTHORITY');started=time.monotonic_ns();cases=[]
try:
    doc=document();source=frozen[paths[4]];assert render_assembly(doc).encode()==source;checked=assemble_program(source)
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),max_blocks=max(len(f['blocks']) for f in doc['functions']),
        ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    entries=[0]
    def call(label,a,b,w):
        code,after=vm_call(checked,a,b,w);entries[0]+=1
        for suffix,raw in [('source',a),('command',b),('before',w),('after',after)]:(OUT/(str(entries[0])+'.'+suffix+'.bin')).write_bytes(raw)
        return code,after
    for mode in (1,2):
        if mode==1:
            original=fixture();query=prepare_edit(original,function='calculate',block='entry',output='y',fields=['op']);unused,receipt=apply_edit(original,query,{'op':'int.sub.wrap'})
        else:
            original=loans();query=prepare_batch(original,[selected('reader'),selected('writer')]);unused,receipt=apply_batch(original,query,swaps())
        key='edit_query' if mode==1 else 'edit_batch';meta=receipt.pop(key)
        for distinct in (False,True):
            # The distinct input value tests private constructor transport only;
            # the public chain must obtain it from actual program admission.
            digest=bytes(range(32)) if distinct else bytes.fromhex(receipt['original_input_sha256'])
            graph=gm.capture([receipt,meta]);nodes=struct.unpack_from('<Q',graph,16)[0];a,b=struct.unpack_from('<2Q',graph,64+nodes*64)
            ctl=command(mode,a,b,digest,request=len(cases)+1);event,after,result=run(call,str(len(cases)),graph,ctl)
            expected=dict(receipt,original_input_sha256=digest.hex());expected[key]=meta
            assert decode_graph_reference(result)==expected
            cases.append(dict(mode=mode,distinct_input_digest=distinct,event=event,exact_complete_receipt=True))
    image,receipt=compile_stage(OUT,'agent-edit-receipt-graph',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-receipt-graph-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_receipt_graph.hiaasm'),
        source_sha256=sha256(source).hexdigest(),image_path=str(image),image_sha256=sha256(image.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    path=OUT/'agent-edit-receipt-graph.manifest.json';path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    native=Actual(path,OUT/'native-smoke')
    try:
        e,w,result=run(native.call,'same-actual-final-case',graph,ctl)
        assert e==event and w==after and decode_graph_reference(result)==expected
    finally:native.close()
    summary.update(status='PASS',profile=profile,independent_VM_cases=cases,independent_VM_entries=entries[0],actual_full_workspace_pair=True,receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
