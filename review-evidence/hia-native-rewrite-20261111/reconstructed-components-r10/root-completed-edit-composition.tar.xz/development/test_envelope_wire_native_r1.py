"""Actual per-component wire limits, 16 MiB framing and private continuation."""
from hashlib import sha256
import json,struct,time,traceback
from pathlib import Path
from hepta.hia_program_tools import bounded_json_wire
from hepta.hia_agent_assembly import assemble_program
from bounded_input_harness import Actual,Peers,BAD
from facts_harness import vm_call
from envelope_wire_harness import command,run

DEV=Path(__file__).resolve().parent;OUT=DEV/'envelope-wire-native-r1';OUT.mkdir(exist_ok=False)
native=Actual(DEV/'envelope-wire-source-and-compile-r1/agent-edit-envelope-wire.manifest.json',OUT/'actual');peers=Peers(OUT/'peers')
checked=assemble_program((DEV/'envelope-wire-source-and-compile-r1/source/examples/hia_bootstrap/agent_edit_envelope_wire.hiaasm').read_bytes())
pins={p:p.read_bytes() for p in (Path(__file__),DEV/'envelope_wire_harness.py',DEV/'bounded_input_harness.py')}
cases=[];controls=[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE');pending=None
def exercise(label,base,patch,vm=False,record=False):
    global pending
    core=bounded_json_wire(base,8<<20,ensure_ascii=False);graph=peers.wm.capture([base,patch]);root=struct.unpack_from('<Q',graph,24)[0]
    ctl=command(root,core,request=len(cases)+1);error=None
    try:expected=b'['+core+b','+bounded_json_wire(patch,8<<20,ensure_ascii=False,sort_keys=False)+b']'
    except Exception as exc:error=str(exc)
    observations=[] if vm or record else None
    actual=run(native.call,peers,label,graph,ctl,observe=observations)
    if error is not None:assert actual['error']==error,(label,actual['event'],actual['error'],error)
    else:assert actual['wire']==expected,(label,len(actual['wire']),len(expected))
    if vm:
        for a,b,w,code,after in observations:assert vm_call(checked,a,b,w)==(code,after)
    if record:
        pending=next((a,b,after+bytes(struct.unpack_from('<Q',after,40)[0]-len(after))) for a,b,w,code,after in observations
                     if struct.unpack_from('<2Q',after,8)==(1,109) and struct.unpack_from('<Q',after,32)[0]==11)
    cases.append(dict(case=label,event=actual['event'],error=error,output_bytes=len(actual['wire']) if actual['wire'] else None,
        exact_component_bytes=True,complete_workspace_VM_pair=vm,actual_core_semantic_admission_claimed=False))
    return graph,ctl,actual['workspace']
def refuse(label,a,b,w):
    code,after=native.call(label,a,b,w);assert code==BAD,(label,code)
    if len(w)>=1024:
        assert struct.unpack_from('<Q',after,264)[0]!=0
        repeated,end=native.call(label+'-permanent',a,b,after);assert repeated==BAD and end==after
    else:assert w==after
    controls.append(dict(case=label,permanent_bad_or_short_discard=True))
try:
    graph,ctl,terminal=exercise('ordered-patch-and-private-growth',{}, {'z':1,'a':[False,None,'中文']},vm=True,record=True)
    for label,patch in [('empty',{}),('unicode',{'水':'😀'}),('tuple',{'x':(1,2,3)}),('surrogate',{'x':'\ud800'}),
        ('nonfinite',{'x':float('nan')}),('unsupported',{'x':object()}),('key-collision',{1:'a','1':'b'}),
        ('huge-int',{'x':10**600}),('numeric-key',{123:'n'}),('escaped',{'x':'\x00\n"\\'})]:exercise(label,{},patch)
    cycle={};cycle['x']=cycle;exercise('cycle',{},cycle)
    a,b,w=pending
    for offset,value in [(0,0),(8,0),(16,0),(24,2),(32,64),(40,0),(48,1),(56,1),(64,0),(80,0),(88,0),
                         (96,0),(104,1),(112,3),(120,0),(128,1),(136,1),(144,1),(152,32769),(160,2),(168,1),(176,99),(184,1)]:
        changed=bytearray(b);struct.pack_into('<Q',changed,offset,value);refuse('pending-field-'+str(offset),a,bytes(changed),w)
    changed=bytearray(b)
    for offset,value in [(72,3),(128,15),(136,1),(152,0),(160,0),(176,99)]:struct.pack_into('<Q',changed,offset,value)
    refuse('pending-success-replaced-by-error',a,bytes(changed),w)
    for offset,value in [(0,0),(8,0),(16,0),(24,0),(32,3),(48,1),(56,1)]:
        changed=bytearray(ctl);struct.pack_into('<Q',changed,offset,value);refuse('initial-field-'+str(offset),graph,bytes(changed),bytes(1024))
    for size in (0,511,1023):refuse('short-'+str(size),graph,ctl,bytes(size))
    dirty=bytearray(1024);dirty[1019]=1;refuse('dirty-initial',graph,ctl,bytes(dirty));refuse('terminal-replay',graph,ctl,terminal)
    # These are exact private framing boundaries, not forged Core admission.
    maximum=8<<20;large={'x':'a'*(maximum-8)}
    exercise('two-exact-eight-MiB-components',large,large)
    exercise('patch-eight-MiB-plus-one',{}, {'x':'a'*(maximum-7)})
    summary.update(status='PASS',cases=cases,private_controls=controls,actual_entries=native.entries,
        complete_maximum_frame_bytes=(16<<20)+3,original_limits_unchanged=True,whole_stack_closed=False)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc),completed_cases=cases,completed_controls=controls);traceback.print_exc();raise
finally:
    native.close();peers.close();summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in pins.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','private_controls','completed_cases','completed_controls')},sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
