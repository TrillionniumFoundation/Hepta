"""Durable wait4 receipt for one explicitly named development test script."""
from pathlib import Path
from hashlib import sha256
import json,os,resource,sys,time
root=Path(__file__).resolve().parent;script=Path(sys.argv[1]).resolve();prefix=Path(sys.argv[2]).resolve()
assert script.is_file();pin=script.read_bytes();stdout=prefix.with_suffix('.stdout.log');stderr=prefix.with_suffix('.stderr.log');receipt=prefix.with_suffix('.process.json')
assert not stdout.exists() and not stderr.exists() and not receipt.exists();started=time.monotonic_ns()
pid=os.fork()
if pid==0:
    with stdout.open('xb') as out,stderr.open('xb') as err:
        os.dup2(out.fileno(),1);os.dup2(err.fileno(),2)
        resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
        os.execv(sys.executable,[sys.executable,str(script)])
actual,status,usage=os.wait4(pid,0);assert actual==pid
result=dict(script=str(script),script_sha256=sha256(pin).hexdigest(),source_unchanged=script.read_bytes()==pin,
    wait_status=status,exitcode=os.waitstatus_to_exitcode(status),elapsed_ns=time.monotonic_ns()-started,
    user_cpu_s=usage.ru_utime,system_cpu_s=usage.ru_stime,max_rss_kib=usage.ru_maxrss,
    cpu_limit_s=90,address_space_limit_bytes=1<<30,stdout_bytes=stdout.stat().st_size,stderr_bytes=stderr.stat().st_size,
    stdout_sha256=sha256(stdout.read_bytes()).hexdigest(),stderr_sha256=sha256(stderr.read_bytes()).hexdigest(),
    scope='DEVELOPMENT_PROCESS_RECEIPT_NOT_COLD_OR_COMPLETE_RETAINED_QUALIFICATION')
receipt.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
sys.exit(0 if result['exitcode']==0 else 1)
