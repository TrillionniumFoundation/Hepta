"""Mechanical actual patch-wire peer replay; all framing stays in HIA."""
import struct
from packet_graph_harness import MAGIC

def command(root,core,*,digits=4300,request=1):
    return struct.pack('<8Q',MAGIC(b'HIAQEC01'),109,request,root,len(core),digits,0,0)+core

def run(call,peers,label,graph,control,*,observe=None):
    before=bytes(1024)
    while True:
        code,after=call(label,graph,control,before)
        if observe is not None:observe.append((graph,control,before,code,after))
        event=struct.unpack_from('<16Q',after);assert code==128 and event[0]==MAGIC(b'HIAQEE01'),(label,code,event)
        if event[1]==1:
            assert event[5]>len(after);before=after+bytes(event[5]-len(after));continue
        if event[1]==2:
            assert event[6:9]==(512,64,32768)
            control=peers.wire_run(graph,after[512:576],32768,event[2],event[3],label);before=after;continue
        assert event[1] in (0,3)
        result=after[event[9]:event[9]+event[10]]
        return dict(event=event,wire=result if event[1]==0 else None,error=result.decode('utf8') if event[1]==3 else None,workspace=after)
