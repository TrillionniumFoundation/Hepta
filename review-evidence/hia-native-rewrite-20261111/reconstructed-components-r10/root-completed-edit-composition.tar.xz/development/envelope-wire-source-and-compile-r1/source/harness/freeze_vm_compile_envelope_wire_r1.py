"""Independent VM framing and original-limit B3 compilation."""
from hashlib import sha256
import json,struct,time,traceback
from pathlib import Path
from hepta.hia_agent_assembly import assemble_program,render_assembly
from hepta.hia_program_tools import bounded_json_wire
from tools.generate_hia_agent_edit_envelope_wire import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from bounded_input_harness import Peers
from envelope_wire_harness import command,run

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native';OUT=DEV/'envelope-wire-source-and-compile-r1';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_envelope_wire.py',ROOT/'tools/generate_hia_agent_edit_apply_graph.py',
       ROOT/'tools/generate_hia_agent_edit_bounded_input.py',ROOT/'tools/generate_hia_graph_merge.py',ROOT/'tools/hia_agent_edit_source_views.py',
       ROOT/'examples/hia_bootstrap/agent_edit_envelope_wire.hiaasm',COMPILER,Path(__file__),DEV/'envelope_wire_harness.py',DEV/'bounded_input_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
peers=Peers(OUT/'actual-wire-peers');entries=[0];cases=[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')
try:
    doc=document();source=frozen[paths[5]];assert render_assembly(doc).encode()==source;checked=assemble_program(source)
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),max_blocks=max(len(f['blocks']) for f in doc['functions']),
        ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    def call(label,a,b,w):
        code,after=vm_call(checked,a,b,w);entries[0]+=1
        for suffix,raw in [('source',a),('second',b),('before',w),('after',after)]:(OUT/(str(entries[0])+'.'+suffix+'.bin')).write_bytes(raw)
        return code,after
    for index,patch in enumerate([{}, {'z':1,'a':[False,None,2]}, {'水':'中文','emoji':'😀'}, {'bad':'\ud800'}]):
        base={'native':'private framing fixture'};core=bounded_json_wire(base,8<<20,ensure_ascii=False)
        graph=peers.wm.capture([base,patch]);root=struct.unpack_from('<Q',graph,24)[0];expected_error=None
        try:expected=b'['+core+b','+bounded_json_wire(patch,8<<20,ensure_ascii=False,sort_keys=False)+b']'
        except Exception as exc:expected_error=str(exc)
        result=run(call,peers,str(index),graph,command(root,core,request=index+1))
        if expected_error is not None:assert result['error']==expected_error
        else:assert result['wire']==expected
        cases.append(dict(case=index,event=result['event'],error=expected_error,exact_original_component_serialization=True))
    image,receipt=compile_stage(OUT,'agent-edit-envelope-wire',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-envelope-wire-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_envelope_wire.hiaasm'),
        source_sha256=sha256(source).hexdigest(),image_path=str(image),image_sha256=sha256(image.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-envelope-wire.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=cases,independent_VM_entries=entries[0],receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    peers.close();summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
