"""Reclaim only exact archived redundant CAS payloads after durable Git readback.

No production source/image, command, manifest, summary or active run is removed.
Every removed object remains in the complete independently verified archive at
the named reachable recovery commit. Original relative paths are recorded.
"""
from pathlib import Path
from hashlib import sha256
import json,tarfile,time
ROOT=Path('/workspace/scratch/9acdfa9f5639');OUT=ROOT/'recovery-completed-r9'
archive=OUT/'root-completed-edit-inputs.tar.xz'
assert sha256(archive.read_bytes()).hexdigest()=='c17f44870f1b58e597b1af7472c80bc9947cd2aa63b1f34e12995be62839de53'
publication=json.loads((OUT/'publication.json').read_text())
assert publication['commit']=='0706112dcb04b853b989d2c1f048eb7d0563eb69' and publication['all_3066_base_and_new_blob_SHA_modes_sizes_read_back']
with tarfile.open(archive,'r:xz') as tf:manifest=json.load(tf.extractfile('MANIFEST.json'))
prefixes=('development/bounded-input-native-r2/','development/bounded-input-native-r3/')
selected=[row for row in manifest['files'] if row['path'].startswith(prefixes) and '/raw/' in row['path'] and len(Path(row['path']).name)==64]
removed=[];started=time.monotonic_ns()
for row in selected:
    p=ROOT/'native-agent-edit-development'/Path(row['path']).relative_to('development')
    assert p.is_file() and not p.is_symlink();raw=p.read_bytes()
    assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
    p.unlink();removed.append(row)
receipt=dict(scope='ONLY_EXACT_DURABLY_ARCHIVED_DUPLICATE_TEST_PAYLOAD_RECLAMATION',commit=publication['commit'],
    archive=str(archive),archive_sha256=sha256(archive.read_bytes()).hexdigest(),removed_count=len(removed),
    reclaimed_bytes=sum(r['bytes'] for r in removed),removed=removed,elapsed_ns=time.monotonic_ns()-started,
    production_sources_images_manifests_summaries_and_active_runs_unchanged=True)
(OUT/'reclaimed-duplicate-payloads.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='removed'},sort_keys=True),flush=True)
