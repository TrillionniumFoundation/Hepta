"""Native framing of admitted Core plus separately bounded native patch wire.

Two independent original 8 MiB components retain their own gates. Framing
adds exactly three bytes; it does not raise bounded_json_wire's 8 MiB limit.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_apply_graph as graph
from tools.generate_hia_agent_edit_bounded_input import WIRE_ERRORS
CONSTANTS={'COMMAND':int.from_bytes(b'HIAQEC01','little'),'STATE':int.from_bytes(b'HIAQEW01','little'),
           'EVENT':int.from_bytes(b'HIAQEE01','little'),'REPLY':int.from_bytes(b'HIAQWR01','little'),
           'WIRE_COMMAND':int.from_bytes(b'HIAGWC01','little'),'WIRE_EVENT':int.from_bytes(b'HIAGWE01','little'),
           'BAD':0xfffffffd}
NAMES='MAGIC BAD PHASE LEASE REQUEST ROOT PATCH DIGITS SIZE GLEASE CORE NEED ERROR CAUSE OUTLEN'.split()
CONSTANTS.update({'S_'+name:256+8*i for i,name in enumerate(NAMES)})
BODY=r'''
def envelope(s:readbuf, c:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, S_BAD) != 0:
        return BAD
    if get(w, S_PHASE) >= 90:
        return invalid(w, 1)
    if get(w, S_MAGIC) == 0:
        if length(c) < 66 or word(c, 0) != COMMAND or word(c, 8) == 0 or word(c, 16) == 0:
            return invalid(w, 2)
        if word(c, 32) < 2 or word(c, 32) > 8388608 or word(c, 32) != length(c) - 64 or word(c, 48) != 0 or word(c, 56) != 0:
            return invalid(w, 3)
        if graph_shape(s, 0, length(s)) == 0 or gkind(s, word(c, 24)) != 5 or amount(s, word(c, 24)) != 2:
            return invalid(w, 4)
        if gkind(s, element(s, word(c, 24), 0)) != 6 or gkind(s, element(s, word(c, 24), 1)) != 6:
            return invalid(w, 5)
        at = 0
        while at < 1024:
            if byte(w, at) != 0:
                return invalid(w, 6)
            at = at + 1
        put(w, S_MAGIC, STATE)
        put(w, S_PHASE, 1)
        put(w, S_LEASE, word(c, 8))
        put(w, S_REQUEST, word(c, 16))
        put(w, S_ROOT, word(c, 24))
        put(w, S_PATCH, element(s, word(c, 24), 1))
        put(w, S_DIGITS, word(c, 40))
        put(w, S_SIZE, length(s))
        put(w, S_GLEASE, word(s, 8))
        put(w, S_CORE, word(c, 32))
        copy_bytes(w, s, 640, 0, 64)
        copy_bytes(w, c, 704, 0, 64)
    elif get(w, S_MAGIC) != STATE:
        return invalid(w, 7)
    if length(s) != get(w, S_SIZE):
        return invalid(w, 8)
    at = 0
    while at < 64:
        if byte(s, at) != byte(w, 640 + at):
            return invalid(w, 9)
        at = at + 1
    if get(w, S_PHASE) == 1:
        if length(c) != 64 + get(w, S_CORE):
            return invalid(w, 10)
        at = 0
        while at < 64:
            if byte(c, at) != byte(w, 704 + at):
                return invalid(w, 11)
            at = at + 1
        if length(w) < 8195 + get(w, S_CORE):
            put(w, S_NEED, 8195 + get(w, S_CORE))
            return publish(w, 1)
        store(w, 8192, 91)
        copy_bytes(w, c, 8193, 64, get(w, S_CORE))
        store(w, 8193 + get(w, S_CORE), 44)
        put(w, 512, WIRE_COMMAND)
        put(w, 520, get(w, S_GLEASE))
        put(w, 528, get(w, S_REQUEST))
        put(w, 536, get(w, S_PATCH))
        put(w, 544, 8388608)
        put(w, 552, 0)
        put(w, 560, get(w, S_DIGITS))
        put(w, 568, 0)
        put(w, S_PHASE, 10)
        put(w, S_NEED, 0)
        return publish(w, 2)
    if get(w, S_PHASE) != 10 and get(w, S_PHASE) != 11:
        return invalid(w, 12)
    return wire_reply(c, w)

def wire_reply(c:readbuf, w:mutbuf) -> u32:
    if length(c) < 192 or word(c, 0) != REPLY or word(c, 8) != get(w, S_LEASE) or word(c, 16) != get(w, S_REQUEST):
        return invalid(w, 13)
    if word(c, 24) != 1 or word(c, 32) != 128 or word(c, 40) != length(c) - 64 or word(c, 40) < 32768 or word(c, 48) != 0 or word(c, 56) != 0:
        return invalid(w, 14)
    if word(c, 64) != WIRE_EVENT or word(c, 80) != get(w, S_GLEASE) or word(c, 88) != get(w, S_REQUEST):
        return invalid(w, 15)
    if word(c, 96) != get(w, S_PATCH) or word(c, 104) != 8388608 or word(c, 112) != 0 or word(c, 120) != get(w, S_DIGITS):
        return invalid(w, 16)
    if word(c, 144) > word(c, 40) or word(c, 168) != 0 or word(c, 184) != 0:
        return invalid(w, 17)
    if get(w, S_PHASE) == 10:
        copy_bytes(w, c, 768, 0, 192)
    else:
        at = 0
        while at < 192:
            if byte(c, at) != byte(w, 768 + at):
                return invalid(w, 18)
            at = at + 1
    if word(c, 72) == 3:
        code = word(c, 128)
        if word(c, 176) != 99 or code < 1 or code > 16 or word(c, 136) > 2 or word(c, 152) != 0 or word(c, 160) != 0:
            return invalid(w, 19)
        put(w, S_ERROR, code)
        put(w, S_CAUSE, word(c, 136))
        put(w, S_OUTLEN, diagnostic(w, code))
        put(w, S_PHASE, 99)
        put(w, S_NEED, 0)
        return publish(w, 3)
    if word(c, 72) != 0 or word(c, 128) != 0 or word(c, 136) != 0 or word(c, 144) != 0 or word(c, 176) != 90:
        return invalid(w, 20)
    offset = word(c, 152)
    size = word(c, 160)
    if size < 2 or size > 8388608 or offset < 32768 or offset > word(c, 40) or size > word(c, 40) - offset:
        return invalid(w, 21)
    put(w, S_PHASE, 11)
    if length(w) < 8195 + get(w, S_CORE) + size:
        put(w, S_NEED, 8195 + get(w, S_CORE) + size)
        return publish(w, 1)
    copy_bytes(w, c, 8194 + get(w, S_CORE), 64 + offset, size)
    store(w, 8194 + get(w, S_CORE) + size, 93)
    put(w, S_OUTLEN, get(w, S_CORE) + size + 3)
    put(w, S_PHASE, 90)
    put(w, S_NEED, 0)
    return publish(w, 0)

def publish(w:mutbuf, action:u64) -> u32:
    put(w, 0, EVENT)
    put(w, 8, action)
    put(w, 16, get(w, S_LEASE))
    put(w, 24, get(w, S_REQUEST))
    put(w, 32, get(w, S_PHASE))
    put(w, 40, get(w, S_NEED))
    put(w, 48, choose(action == 2, 512, 0))
    put(w, 56, choose(action == 2, 64, 0))
    put(w, 64, choose(action == 2, 32768, 0))
    put(w, 72, choose(action == 0, 8192, choose(action == 3, 2048, 0)))
    put(w, 80, choose(action == 0 or action == 3, get(w, S_OUTLEN), 0))
    put(w, 88, get(w, S_ERROR))
    put(w, 96, get(w, S_CAUSE))
    put(w, 104, 0)
    put(w, 112, 0)
    put(w, 120, 0)
    return 128

def invalid(w:mutbuf, reason:u64) -> u32:
    put(w, S_BAD, reason)
    publish(w, 4)
    return BAD
'''

def source_program():
    lines=['def diagnostic(w:mutbuf, code:u64) -> u64:']
    for code,message in enumerate(WIRE_ERRORS,1):
        raw=('E_HIA_EDIT: '+message).encode();lines.append(f'    if code == {code}:')
        for at in range(0,len(raw),8):
            part=raw[at:at+8]
            if len(part)==8:lines.append(f'        put(w, {2048+at}, {int.from_bytes(part,"little")})')
            else:
                for i,value in enumerate(part):lines.append(f'        store(w, {2048+at+i}, {value})')
        lines.append(f'        return {len(raw)}')
    lines.append('    return 0')
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
    own=Expand().visit(ast.parse(BODY+'\n'+'\n'.join(lines)+'\n')).body
    old={n.name:n for n in ast.parse(graph.source_program()).body}
    tree=ast.Module(body=own+[old[n] for n in ('graph_shape','gkind','amount','element','word','get','put')],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['envelope']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        b=shared.CopyBuilder(node,names,signatures,total);b.statements(node.body)
        functions.append({'name':names[node.name],'params':[b.param(v) for v in b.params],'returns':[b.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':b.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_envelope_wire','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_envelope_wire.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
