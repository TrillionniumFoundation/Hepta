"""Native final receipt composition after actual complete candidate admission.

The fixed issuer supplies actual patch-result and pending edit metadata Graphs,
plus the independently admitted original-input digest. This private constructor
is invoked only after the same candidate passes whole Core admission. A caller-
supplied header or digest cannot grant that publication authority.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_apply_graph as graph

CONSTANTS={'COMMAND':int.from_bytes(b'HIAQRC01','little'),'STATE':int.from_bytes(b'HIAQRW01','little'),
           'EVENT':int.from_bytes(b'HIAQRE01','little'),'GRAPH':int.from_bytes(b'HIAGRF01','little'),
           'BAD':0xfffffffd,'MAX':(1<<64)-1}
LITERALS=('after_sha256','before_sha256','claims','edit_domain','edits','interface_changes','ok',
          'original_input_sha256','schema','status','hepta.hia.patch-result.v1','edit_query','edit_batch')
BODY=r'''
def receipt_graph(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) == 2:
        return refuse(w, 1)
    if length(r) != 192 or word(r, 0) != COMMAND or word(r, 16) == 0 or word(r, 24) == 0:
        return refuse(w, 2)
    if graph_shape(s, 0, length(s)) == 0:
        return refuse(w, 3)
    if word(r, 40) == 0 or word(r, 40) > 2:
        return refuse(w, 4)
    i = 48
    while i < 64:
        if word(r, i) == 0 or word(r, i) > word(s, 16):
            return refuse(w, 5)
        i = i + 8
    i = 64
    while i < 128:
        if word(r, i) != 0:
            return refuse(w, 6)
        i = i + 8
    i = 160
    while i < 192:
        if word(r, i) != 0:
            return refuse(w, 7)
        i = i + 8
    if get(w, 8) == 0:
        if word(r, 8) != 1 or word(r, 32) != 0:
            return refuse(w, 8)
        i = 0
        while i < 1024:
            if byte(w, i) != 0:
                return refuse(w, 9)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(r, 16))
        put(w, 24, word(r, 24))
        put(w, 40, length(s))
        put(w, 72, word(s, 16))
        put(w, 88, word(s, 32))
        put(w, 104, word(s, 40))
        put(w, 200, word(r, 48))
        put(w, 208, word(r, 56))
        put(w, 248, word(r, 40))
        copy_bytes(w, r, 448, 40, 152)
        copy_bytes(w, s, 640, 0, 64)
        if validate(s, w) == 0:
            return refuse(w, 10)
        put(w, 160, 0)
        project(s, r, w)
        if sizes(w) == 0:
            return refuse(w, 11)
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or word(r, 8) != 2:
            return refuse(w, 12)
        if word(r, 16) != get(w, 16) or word(r, 24) != get(w, 24) or word(r, 32) != get(w, 32):
            return refuse(w, 13)
        if length(s) != get(w, 40):
            return refuse(w, 14)
        i = 0
        while i < 152:
            if byte(r, 40 + i) != byte(w, 448 + i):
                return refuse(w, 15)
            i = i + 1
        i = 0
        while i < 64:
            if byte(s, i) != byte(w, 640 + i):
                return refuse(w, 16)
            i = i + 1
    if get(w, 152) > length(w):
        return event(w, 1)
    fill_range(w, 1024, get(w, 144), 0)
    if clone_graph(s, w, 0, 0, 0, 0) == 0:
        return refuse(w, 17)
    put(w, 160, 1)
    put(w, 168, 0)
    put(w, 176, 0)
    put(w, 184, 0)
    project(s, r, w)
    if get(w, 168) != get(w, 56) or get(w, 176) != get(w, 64) or get(w, 184) != get(w, 80):
        return refuse(w, 18)
    put(w, 1024, GRAPH)
    put(w, 1032, get(w, 16))
    put(w, 1040, get(w, 120))
    put(w, 1048, get(w, 224))
    put(w, 1056, get(w, 128))
    put(w, 1064, get(w, 136))
    put(w, 1072, get(w, 144))
    put(w, 8, 2)
    return event(w, 0)

def validate(s:readbuf, w:mutbuf) -> u64:
    receipt = get(w, 200)
    meta = get(w, 208)
    if gkind(s, receipt) != 6 or amount(s, receipt) != 10 or gkind(s, meta) != 6 or amount(s, meta) != 7:
        return 0
    if text_is(s, field(s, receipt, L_schema), L_hepta_hia_patch_result_v1) == 0:
        return 0
    if field(s, receipt, L_after_sha256) == 0 or field(s, receipt, L_before_sha256) == 0 or field(s, receipt, L_claims) == 0:
        return 0
    if field(s, receipt, L_edit_domain) == 0 or field(s, receipt, L_edits) == 0 or field(s, receipt, L_interface_changes) == 0:
        return 0
    if field(s, receipt, L_ok) == 0 or field(s, receipt, L_original_input_sha256) == 0 or field(s, receipt, L_status) == 0:
        return 0
    return 1

def project(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    source = get(w, 200)
    root = new_node(w, 6, 11, 0, 0)
    i = 0
    while i < 10:
        key = element(s, source, i * 2)
        value = element(s, source, i * 2 + 1)
        if text_is(s, key, L_original_input_sha256) != 0:
            value = digest(r, w, 128)
        pair(w, root, i, key, value)
        i = i + 1
    key = 0
    if get(w, 248) == 1:
        key = literal(w, L_edit_query)
    else:
        key = literal(w, L_edit_batch)
    pair(w, root, 10, key, get(w, 208))
    put(w, 224, root)
    return 0
'''

def source_program():
    def packed(value):
        raw=value.encode('ascii');assert len(raw)<=32
        return [len(raw),*(int.from_bytes(raw[i:i+8],'little') for i in (0,8,16,24))]
    labels={'L_'+v.replace('.','_').replace('-','_'):packed(v) for v in LITERALS}
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
        def visit_Call(self,node):
            node=self.generic_visit(node);args=[]
            for arg in node.args:
                args.extend(ast.Constant(v) for v in labels[arg.id]) if isinstance(arg,ast.Name) and arg.id in labels else args.append(arg)
            node.args=args;return node
    own=Expand().visit(ast.parse(BODY)).body
    old={n.name:n for n in ast.parse(graph.source_program()).body}
    class Events(ast.NodeTransformer):
        def visit_Constant(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS['EVENT']),node) if node.value==graph.CONSTANTS['EVENT'] else node
    keep=('gkind','amount','element','text_is','field','sizes','new_node','set_edge','pair','literal','digest',
          'graph_shape','clone_graph','clone_container','clone_scalar','word','get','put','event','refuse')
    tree=ast.Module(body=own+[Events().visit(old[n]) for n in keep],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['receipt_graph']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        b=shared.CopyBuilder(node,names,signatures,total);b.statements(node.body)
        functions.append({'name':names[node.name],'params':[b.param(v) for v in b.params],'returns':[b.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':b.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_receipt_graph','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_receipt_graph.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
