# Native edit composition: actual program admission through complete receipts

The current completed evidence is a development composition of real HIA images.
The Python executor forwards their bounded buffers and events; it is not the
final public HIA controller. Original arbitrary foreign-object capture, complete
dynamic Core diagnostics, filesystem publication and ordinary installation remain
explicit work. No default selector or product main has changed.

## Complete observed chain

The actual program-admission ELF receives raw program bytes with empty PATH and
HOME. Its successful exit, complete Core stdout and actual 256-byte receipt must
all agree. Original canonical input SHA and normalized Core SHA remain distinct.
The complete Core then passes the actual decoder, integer packet codec and index
issuer. Native prefixes select the original single/batch validation order.

Selection, facts, complete SSA/CFG slice, operation canonicalization, native SHA,
query projection, packet-to-Graph and bounded wire reconstruct the entire query.
Batch apply checks all nested selector shapes before any reconstruction; prepare
batch checks overlap after the current query before inspecting the next selection.
The actual complete canonical query bytes are compared before response parsing.

The caller-specific input owner preserves raw response bytes and the original
16 KiB or 64 KiB limit. Native response policy creates the complete patch and
private pending edit metadata. Native framing separately serializes the patch
under its original 8 MiB/UTF-8/insertion-order contract and pairs it with the
already admitted exact Core bytes. The existing patch kernel extracts and
rechecks its base, then mode 2 generates a candidate plus a private patch receipt.
The entire actual candidate passes Core admission before any final receipt is
exposed. A small native Graph constructor replaces original_input_sha256 with
the actual program-admission input digest and attaches the native edit metadata.
General native wire produces the complete final receipt.

During actual execution, the retained program verifier, query/slice owners,
bounded serializer, Agent decoder, typed encoder, materializer, patch owner and
json.loads are disabled. Low-level peers save complete original inputs, outputs
and before/after workspaces; all actual source/image pins and canaries are checked.
Convenience adapters still map some existing native constant error codes for
development observation. They are not represented as a final HIA error interface.

## Results and original failures

The first integration attempt failed at its patch envelope wire step: it passed
16 MiB + 3 as a maximum to the existing wire kernel, whose original supported
maximum is 8 MiB. That complete failed run is retained. The new envelope owner
preserves the two component limits and adds exactly three framing bytes.

Integration r2 reached a durable terminal summary with all 16 cases equal in
8.121206166 seconds. Its later process-tool wait returned an expired/unknown
session, so no observed exit-zero status is invented for that run. Integration
r3 repeats the complete cases and adds all primitive versions v1–v8. Its 24
cases all passed, with an actual wait4 exit 0, 90 CPU second and 1 GiB address-space
development limits. The test body took 10.476506855 seconds; parent wall was
10.695304841 seconds. Sixteen successful candidates and entire receipts are
byte-for-byte equal to the retained entries; six public refusals match complete
text and order; two original/final Core refusals match category with dynamic
text explicitly still open. Structured single and batch cases use the actual
distinct input/Core digests, not fabricated test digests.

## Final receipt Graph owner

agent_edit_receipt_graph.hiaasm is 80,931 bytes, SHA-256
4747e8ed0e38761700db81fc3015bdeedd309ccbe3a348d8dfd19a8f1fca6d69;
actual image SHA-256 is cc631a167f4eeb0868b5b594b38e52480de9c8ee850d92b7ec29daf685b60f23.
It has 24 functions, 312 blocks, 1,313 operations, at most 86 blocks per function
and 16 block parameters. Four independent VM cases made eight entries before
actual B3 compilation; a complete actual workspace matched the VM. The native
protocol run passed 26 private controls in 52 entries with actual exit 0.

Its private RWW input is an immutable issued Graph containing the actual native
patch-result dictionary and pending edit metadata. The 192-byte command is:

    [HIAQRC01, action, lease, request, sequence, mode, patchReceiptRoot,
     editMetadataRoot, 0,0,0,0,0,0,0,0] + actualInputSHA32 + zero32

The sixteen-u64 HIAQRE01 event at workspace offset 256 returns 384, using the
shared Graph-owner DONE/GROW/private-BAD protocol. It publishes the complete
Graph at offset 1,024 and its new receipt root in word 9. It copies every old
patch receipt value except the actual original-input digest, then adds edit_query
or edit_batch. The fixed issuer owns the source's provenance and the mode/metadata
pair, and must invoke it only after the same complete candidate is admitted.
A header or digest alone does not authorize publishing a receipt.

## Separate-component envelope owner

agent_edit_envelope_wire.hiaasm is 73,681 bytes, SHA-256
7b8ecfd402dfb713cb60fcde24a4bf740293d44d62a6f0aeb1578744c08ce82b;
actual image SHA-256 is 673f1847340b70fa7d275f8135dac8d224a6ce1205d7c916d14bf2166562426a.
It has 13 functions, 242 blocks, 1,377 operations, at most 84 blocks per function
and 6 block parameters. Four independent VM cases made 15 entries with actual
native wire peers before B3 compilation.

Its first native panel failed after ten completed cases when saving an original
buffer exhausted temporary disk space. The original error, partial object, full
completed records and wait4 exit 1 are retained. Only exact previously archived
duplicate payloads were reclaimed, with per-file hashes and recovery locations.
The unchanged source's new panel then passed 14 cases and 36 private controls
in 119 actual entries, with wait4 exit 0 and unchanged 90 CPU second/1 GiB
development limits. Test body wall was 23.020467797 seconds. It produced the
complete 16,777,219-byte envelope from two separately exact 8,388,608-byte
components and rejected the oversized patch under the original wire gate.
Those large private framing fixtures do not claim Core semantic admission.

RWW input is the actual native apply-result Graph, command-or-real-wire-reply
borrowed read-only, and a zero workspace of at least 1,024 bytes. BEGIN is:

    [HIAQEC01, lease, request, envelopeRoot, actualCoreBytes, digits, 0, 0]
    + complete actual admitted canonical Core bytes

HIA locates the patch root in its own envelope Graph, retains the complete Core,
and issues the actual Graph wire command with maximum 8 MiB, ensure_ascii false
and sort_keys false. The complete wire peer workspace returns under the existing
HIAQWR01 header; all correlation/terminal metadata is validated. Pending complete
frames are pinned before either successful or error terminal branches.

The sixteen-u64 event at offset zero returns 128:

    [HIAQEE01, action, lease, request, phase, neededWorkspace,
     commandOffset, commandBytes, peerInitialWorkspace, resultOffset,
     resultBytes, errorCode, cause, 0, 0, 0]

Action 0 returns the complete owned envelope, 1 requests growth, 2 requests the
fixed wire peer and 3 returns complete original HIA-owned wire error text.
Private BAD permanently discards the invocation. The component uses no new
semantic limit on the two-component frame and preserves every old compiler cap.

All these results remain component/development evidence. The current full 0ef
retained qualification is still FAIL/HOLD, and none of these results permits
deleting active hosted owners or claiming a whole-stack native release.
