"""HIA owns public schema dispatch; complete checking remains in frozen owners."""
import ast
from hashlib import sha256
from pathlib import Path
from tools.program_authoring import source,document as build,write_document
from tools.hia_composite_lowering_driver_common import COMMON

ROOT=Path(__file__).resolve().parents[1]
FROZEN=ROOT.parent/'native-composite-legacy-import-next/tools/generate_hia_legacy_projection.py'
CONSTANTS={'BAD':0xfffffffd,'MAX':(1<<64)-1,'SOURCE_MAGIC':int.from_bytes(b'HIASIL01','little'),
           'MAGIC':int.from_bytes(b'HIAPDP01','little'),'PACKET_MAX':64<<20}

BODY=r'''
def dispatch(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(o) < 64 or length(w) < 64:
        return BAD
    if source_lease(s) == 0:
        return BAD
    packet = word(s, 8)
    kind = 0
    version = 0
    core = 0
    if word(s, 64) == 6:
        if packet < 24:
            return BAD
        count = word(s, 80)
        if count > ((packet - 24) >> 5):
            return BAD
        at = 88
        schema = 0
        seen_schema = 0
        seen_types = 0
        i = 0
        while i < count:
            key = at
            if key > 64 + packet - 16 or word(s, key) != 4:
                return BAD
            key_bytes = word(s, key + 8)
            if key_bytes > 64 + packet - key - 16:
                return BAD
            value = key + 16 + key_bytes
            if value > 64 + packet - 16:
                return BAD
            size = word(s, value + 8)
            if size > 64 + packet - value - 16:
                return BAD
            if is_schema(s, key) != 0:
                if seen_schema != 0:
                    return BAD
                schema = value
                seen_schema = 1
            if is_types(s, key) != 0:
                if seen_types != 0:
                    return BAD
                seen_types = 1
            at = value + 16 + size
            i = i + 1
        if at != 64 + packet:
            return BAD
        if seen_schema != 0:
            version = schema_version(s, schema)
            if version >= 17 and version <= 20:
                kind = 1
                version = version - 16
                core = 7
                if version == 1:
                    core = 6
                if version == 4:
                    core = 8
            else:
                core = version
                if version == 2 and seen_types != 0:
                    kind = 2
    put(o, 0, MAGIC)
    put(o, 8, kind)
    put(o, 16, version)
    put(o, 24, core)
    put(o, 32, packet)
    put(o, 40, length(s))
    put(o, 48, 0)
    put(o, 56, 0)
    return 64
'''

def literal_args(value):
    raw=value.encode()
    return ', '.join(map(str,[len(raw)]+[int.from_bytes(raw[i:i+8],'little') for i in (0,8,16)]))

def source_program():
    raw=FROZEN.read_bytes()
    assert sha256(raw).hexdigest()=='3b502f9e42e68844de18c0c4800b34342a553c6e81fd303dfe1c41d08a7dfd07'
    body=next(ast.literal_eval(n.value) for n in ast.parse(raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BODY' for t in n.targets))
    helpers='\n'.join(ast.unparse(n) for n in ast.parse(body).body if n.name in ('source_lease','text'))
    extra=''
    for name,key in [('is_schema','schema'),('is_types','types')]:
        extra+=f'\ndef {name}(s:readbuf, at:u64) -> u64:\n    return text(s, at, {literal_args(key)})\n'
    extra+='\ndef schema_version(s:readbuf, at:u64) -> u64:\n'
    for prefix,versions,start in [('hepta.hia.program.v',range(1,9),0),('hepta.hia.composite.v',range(1,5),16)]:
        for version in versions:
            extra+=f'    if text(s, at, {literal_args(prefix+str(version))}) != 0:\n        return {start+version}\n'
    extra+='    return 0\n'
    return source(BODY+'\n'+helpers+extra+'\n'+COMMON,CONSTANTS,'dispatch')

def document():return build(source_program(),'program_dispatch')
if __name__=='__main__':write_document(document(),'program_dispatch.hiaasm')
