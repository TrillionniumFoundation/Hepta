"""Exact fixed-template extension for complete program admission results."""
from hashlib import sha256
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ORIGINAL=ROOT.parent/'native-composite-legacy-import-next/tools/legacy_native_executor.S'
ORIGINAL_SHA='9e94102fe9001493ca7bf175a9e97e066d4cb1e9f4d65239985f43a00f1eb22f'

def replace(text,old,new,count=1):
    assert text.count(old)==count,(old,text.count(old))
    return text.replace(old,new)

RECEIPT=r'''
    /* The HIA result supplies a complete readonly receipt and Core view.
     * A consumer must require successful exit and both complete extents. */
    cmp qword ptr [r15+ROLE],46
    jne abi_error
    cmp qword ptr [r12+48],56
    jne abi_error
    cmp qword ptr [r12+56],256
    jne abi_error
    cmp qword ptr [r15+56*32+24],1
    jne abi_error
    mov edi,56
    xor esi,esi
    mov edx,256
    call range_view
    mov [r15+IO_PTR],rax
    mov [r15+IO_LEFT],rdx
receipt_loop:
    cmp qword ptr [r15+IO_LEFT],0
    je receipt_complete
    mov edi,2
    mov rsi,[r15+IO_PTR]
    mov rdx,[r15+IO_LEFT]
    mov eax,1
    syscall
    cmp rax,-4
    je receipt_loop
    test rax,rax
    jle io_error
    cmp rax,[r15+IO_LEFT]
    ja abi_error
    add [r15+IO_PTR],rax
    sub [r15+IO_LEFT],rax
    jmp receipt_loop
receipt_complete:
'''

def author():
    raw=ORIGINAL.read_bytes();assert sha256(raw).hexdigest()==ORIGINAL_SHA
    text=raw.decode()
    text=replace(text,'.equ TWO_READ_MASK,0x0000000022ac0462','.equ TWO_READ_MASK,0x0000000002ac0462')
    text=replace(text,'.equ IMPORT_INIT,0x313049494c414948','.equ PROGRAM_INIT,0x3130494150414948')
    text=replace(text,'    mov rax,IMPORT_INIT','    mov rax,PROGRAM_INIT')
    text=replace(text,'    cmp qword ptr [rip+executable_policy],2','    cmp qword ptr [rip+executable_policy],3')
    text=replace(text,'    .quad 2,4300','    .quad 3,4300')
    text=replace(text,'    cmp rax,47\n    ja abi_error','    cmp rax,46\n    ja abi_error')
    text=replace(text,'    cmp rax,29\n    ja abi_error','    cmp rax,28\n    ja abi_error')
    text=replace(text,'    cmp qword ptr [r15+ROLE],47\n    je final_publication\n','')
    text=replace(text,'    cmp qword ptr [r12+32],1\n    ja abi_error\n    cmp qword ptr [r12+48],0',
        '    cmp qword ptr [r12+32],0\n    jne abi_error\n    cmp qword ptr [r12+48],0')
    text=replace(text,'    cmp qword ptr [r10+RUN_MODE],0\n    je child_select_source\n    mov edx,1\n    mov qword ptr [r10+PUB_ROLE],47\nchild_select_source:\n','')
    text=replace(text,'    cmp qword ptr [r15+RUN_MODE],0\n    jne child_constructor_start\n','')
    start=text.index('child_constructor_start:\n')
    end=text.index('/* Copy only actual terminal bytes',start)
    text=text[:start]+text[end:]
    text=replace(text,'    cmp rax,45\n    je selected_publication\n    cmp rax,47\n    jne abi_error\nselected_publication:',
        '    cmp rax,45\n    jne abi_error\nselected_publication:')
    text=replace(text,'    cmp qword ptr [r15+PARENT],0\n    jne child_complete\n    cmp qword ptr [r15+45*32+24],1',
        '    cmp qword ptr [r15+PARENT],0\n    jne child_complete\n'+RECEIPT+'    cmp qword ptr [r15+45*32+24],1')
    return text

if __name__=='__main__':
    path=ROOT/'tools/program_native_executor.S';path.write_text(author())
    print(path,len(path.read_bytes()),sha256(path.read_bytes()).hexdigest())
