# Complete raw program admission: independent native development

This component implements the raw-byte entry of `hepta.hia_program.verify_program`.
The frozen input contract is recorded in `checkpoints/initial-contract-pins.json`.
It reuses the exact existing raw JSON, source issuer, complete composite lowering,
and whole primitive Core images. It is not an implicit legacy importer.

## Original semantic order

1. A raw byte input larger than 8 MiB fails before UTF-8 decoding. Otherwise all
   UTF-8 is checked before JSON parsing. Integer JSON parsing retains duplicate
   key, float/nonfinite, surrogate, digit, 262144-node and depth-64 rules.
   Canonical JSON and the detached value graph are completed before dispatch.
2. A dict whose schema is an exact string in `hepta.hia.composite.v1` through
   `.v4` runs complete composite elaboration, the existing late expanded Core
   snapshot/node/depth/byte gates and independent primitive verification. Targets
   are Core v6, v7, v7 and v8 respectively.
3. Any other dict with schema `hepta.hia.program.v2` and a direct `types` field
   fails with `E_HIA_VERSION_COLLISION`, even if that field is null or another
   malformed key would otherwise fail primitive shape. Historical nominal v2 is
   admitted only by the separate explicit importer.
4. Every other value reaches the existing complete primitive v1-v8 checker.
   Shape precedes unsupported-schema errors as before; the dispatch component
   does not impose an earlier primitive shape or version check. Complete
   declarations, all instructions, interfaces, effects, resource and loan flow,
   CFG, reachability and exports remain in the existing Core owner.

`input_sha256` means SHA-256 of the canonical primitive input, or the canonical
original structured input if elaboration took place. It is not the hash of raw
submitted whitespace. `core_sha256` means the complete normalized canonical
primitive Core. Both are independently exposed; they are equal on a primitive
input. The complete canonical structured input is retained for structured
results, matching `VerifiedProgram.structured_bytes`.

Python's caller-owned dict/list snapshot and custom class handling are outside
this raw wire entry. The existing `VerifiedProgram` bridge also rechecks its
structured bytes and compares both retained byte strings; a Python wrapper is
not an authority and is not newly trusted here.

## Reused owners and new boundary

The unchanged raw controller 44 owns UTF-8, integer JSON decoding, full typed
packet creation, canonicalization, a second real decoder and the issued source
bitmap. It hands its exact private readonly SourceIndexLease to new controller
46. New image 28 reads only root/schema discrimination and direct presence of
`types`. It does not substitute for primitive or composite validation.

Controller 46 converts that actual source packet to its exact canonical bytes
using the existing packet-to-JSON image. Primitive values are passed to actual
Core image 27. Structured inputs invoke the unchanged complete ordinary child
pipeline: a fresh type registry, constructor, every function/helper, outer owner,
complete final snapshot gate, canonical publication and Core image 27. The
ordinary child receives this controller's immutable canonical source. Its
independent repeated raw admission cannot turn an already admitted source into
a different language input; no qualification result or verified object is cached.

The fixed executor supports only ordinary child mode zero for this application.
It copies/borrows buffer views and invokes fixed embedded images. All schema
choice and semantic continuation remain in HIA. The existing explicit legacy
importer and its images are not embedded or selected.

## Immutable successful result and receipt

Successful terminal event is the usual 128-byte HIACDE01 frame with action 7,
lease and final sequence, error group/code zero, then receipt slot 56, receipt
length 256, input kind, input version, Core version, Core byte length and the
four little-endian words of the Core SHA-256. Complete canonical Core is in
readonly slot 45. For structured input, readonly slot 52 retains the complete
canonical original structured bytes. These views belong to the same fixed
private invocation and are borrowed only while it is alive.

Receipt slot 56 contains 32 little-endian u64 words, 256 bytes:

| Words | Meaning |
| --- | --- |
| 0-3 | HIAPRV01 magic, ABI version 1, invocation lease, final event sequence |
| 4-9 | input kind (0 primitive / 1 structured), input version, Core version, canonical input byte length, canonical Core byte length, structured byte length (zero for primitive) |
| 10-13 | input SHA-256 bytes, represented as four little-endian words |
| 14-17 | Core SHA-256 bytes, represented as four little-endian words |
| 18-21 | Core slot 45, structured slot 52 or zero, receipt slot 56, receipt bytes 256 |
| 22-26 | primitive rechecked = 1, structured elaboration rechecked = input kind, implicit legacy import = 0, externally authenticated source = 0, complete dynamic diagnostic text = 0 |
| 27-31 | reserved zero |

The standalone executable emits the complete canonical Core on stdout and the
256-byte receipt on stderr on success. A compound native application borrows
these same immutable mappings directly instead of executing a subprocess or
reinterpreting values in Python. The receipt does not authenticate externally
supplied buffers or replace full verification of a future input.

Refusal retains the complete actual 128-byte first-failure frame and publishes
no Core. Raw/source, primitive and composite stage information is preserved.
The complete original dynamic English diagnostic is not available from the
frozen Core image's status-only ABI. Fixed raw/collision messages can be rendered
from the native reason, but arbitrary instruction/function context needs a
separate complete native diagnostics owner. Test evidence preserves the original
oracle text and actual native frame; category equivalence must not be described
as complete diagnostic-text closure or a finished edit-error renderer.

## Limits and lifecycle

No original language, compiler or cold limit is changed. All scratch capacities
are the already established bounds of the reused component, not new accepted
input quotas. A child returns only its actual complete readonly Core mapping;
other child mappings and descriptors are discarded before ACK. An ABI refusal,
short advertised workspace, syscall failure, invalid/replayed acknowledgement
or provenance mismatch ends the current invocation. Private source offsets,
leases, hashes and nonces are correlation facts, not external authentication.

The initial source design is not execution evidence. Exact source/image pins,
actual B3 receipts, full ELF results and all original failures will be retained
as separate development stages. Default activation, installed routes, exact
current cold/full qualification, syscall tracing and whole-stack native-only
closure remain separate gates.
