"""All public version routes, independent full oracle, actual 35-image ELF."""
from program_panel_support import Panel,compact,BASE
import sys
sys.path.insert(0,str(BASE))
from tests.test_hia_core_upgrade import scalar
from tests.test_hia_program_composite import stored_loan_program

panel=Panel('smoke-r1',__file__);error=None
try:
    for version in range(1,9):panel.run(f'primitive-v{version}',compact(scalar(f'hepta.hia.program.v{version}')))
    for version in range(1,5):
        value=stored_loan_program();value['schema']=f'hepta.hia.composite.v{version}'
        panel.run(f'structured-v{version}',compact(value))
    value=scalar('hepta.hia.program.v2');value['types']=None;value['unrecognized']=True
    panel.run('collision-before-primitive-shape',compact(value),expected_stage=(10,1))
    panel.run('duplicate-before-schema',b'{"schema":"hepta.hia.program.v2","schema":0}')
    value=scalar('hepta.hia.program.v8');value['functions'][0]['returns']=['not_a_type']
    panel.run('primitive-type-refusal',compact(value))
except BaseException as exc:
    error=exc;raise
finally:panel.close(error)
