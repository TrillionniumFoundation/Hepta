"""Actual full-profile admission limits, final Core ordering and exact hashes."""
from program_panel_support import Panel,compact,BASE,OLD
import copy
import random
import sys
sys.path.insert(0,str(BASE))
from tests.test_hia_core_admission_native import VALID
from tests.test_hia_program import f,b,ret
from tests.test_hia_program_composite import record,enum

LIMIT=8<<20

def exact_primitive(size):
    value=copy.deepcopy(VALID);fn=value['functions'][0]
    fn['params']=[{'name':'p'+str(i),'type':'u32'} for i in range(30000)]
    fn['blocks'][0]['params']=copy.deepcopy(fn['params'])
    need=size-len(compact(value));assert need>=0
    if need&1:value['module']+='x';need-=1
    for p,q in zip(fn['params'],fn['blocks'][0]['params']):
        add=min(128-len(p['name']),need//2);p['name']+='x'*add;q['name']=p['name'];need-=2*add
    assert need==0
    raw=compact(value);assert len(raw)==size;return raw

def exact_composite(size):
    empty='E'*128;definitions=[record(empty,[])]
    for n in range(15):
        definitions.append(enum('Choice'+str(n),[(f'v{v}',[(f'f{i:02d}',empty) for i in range(64)]) for v in range(32)]))
    value={'schema':'hepta.hia.composite.v1','module':'boundary','types':definitions,
        'functions':[f('ok',[],[],[],[b('entry',[],[],ret())])]}
    need=size-len(compact(value));assert need>=0
    for definition in definitions[1:]:
        for variant in definition['variants']:
            for field in variant['fields']:
                add=min(128-len(field['name']),need);field['name']+='x'*add;need-=add
    assert need==0
    raw=compact(value);assert len(raw)==size;return raw

panel=Panel('boundaries-r1',__file__);error=None
try:
    template=copy.deepcopy(VALID['functions'][0]);doc=copy.deepcopy(VALID)
    doc['functions']=[{**copy.deepcopy(template),'name':'f'+str(i)} for i in range(1024)]
    panel.run('functions-1024',compact(doc))
    doc['functions'].append({**copy.deepcopy(template),'name':'extra'});panel.run('functions-1025',compact(doc))
    doc=copy.deepcopy(VALID);fn=doc['functions'][0]
    fn['blocks']=[{'id':'b'+str(i),'params':[],'ops':[],
        'term':{'op':'jump','target':'b'+str(i+1),'args':[]} if i<4095 else {'op':'ret','values':[]}} for i in range(4096)]
    fn['entry']='b0';random.Random(824).shuffle(fn['blocks'])
    panel.run('blocks-4096',compact(doc))
    fn['blocks'].append({'id':'extra','params':[],'ops':[],'term':{'op':'ret','values':[]}});panel.run('blocks-4097',compact(doc))
    doc=copy.deepcopy(VALID);fn=doc['functions'][0]
    fn['params']=[{'name':'p'+str(i),'type':'u32'} for i in range(16384)]
    fn['blocks'][0]['params']=copy.deepcopy(fn['params']);fn['returns']=['u32']*1024
    fn['blocks'][0]['term']['values']=['p'+str(i) for i in range(1024)]
    panel.run('full-parameter-return-arity',compact(doc))
    for count in (262144,262145):
        wire=b'['+b'0,'*(count-2)+b'0]';panel.run('raw-nodes-'+str(count),wire)
    for depth in (64,65):panel.run('raw-depth-'+str(depth),b'['*depth+b'0'+b']'*depth)
    row=panel.run('primitive-exact-8MiB',exact_primitive(LIMIT));assert row['oracle']['accepted'] and row['stdout_bytes']==LIMIT
    row=panel.run('structured-exact-8MiB',exact_composite(LIMIT));assert row['oracle']['accepted'] and row['oracle']['canonical_input_bytes']==LIMIT
    for name in ('complete-Core-byte-gate-after-all-functions','later-function-error-before-Core-byte-gate'):
        p=OLD/'development/complete-boundary-panel-r1'/name/'source-document.json'
        panel.run('late-'+name,p.read_bytes())
except BaseException as exc:
    error=exc;raise
finally:panel.close(error)
