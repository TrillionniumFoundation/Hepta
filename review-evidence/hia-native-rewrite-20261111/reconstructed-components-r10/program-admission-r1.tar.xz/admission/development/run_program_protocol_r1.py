"""Actual private receipt views, native child handoff and permanent refusal.

The forwarding executor below is development instrumentation. The actual ELF
panels separately exercise the syscall-only template. No source lease in this
script is claimed to authenticate arbitrary external bytes.
"""
from collections import Counter
from contextlib import ExitStack
from hashlib import sha256
import gzip
import json
from pathlib import Path
import struct
import sys
import time
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/'native-composite-driver-reconstructed';BASE=ROOT.parent/'Hepta-v66-restored'
sys.path[:0]=[str(ROOT),str(OLD/'development'),str(OLD),str(BASE)]
from publication_mechanical_executor import PublicBundle,PublicExecutor,Buffer,C
from mechanical_executor import Executor,actual_source_lease
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_instruction_policy_native import transport
from hepta.hia_program import verify_program
from tests.test_hia_core_upgrade import scalar
from tests.test_hia_program_composite import stored_loan_program

compact=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
dest=ROOT/'development/protocol-r1';dest.mkdir(exist_ok=False)
bundle=PublicBundle(OLD/'development/publication-bundle-r2/bundle.json')
pins=bundle.pins
bp=ROOT/'development/build-r2/bundle.json';raw=bp.read_bytes();pins[bp]=raw;value=json.loads(raw)
pins[Path(__file__)]=Path(__file__).read_bytes()
frozen=ROOT/'checkpoints/source-r1/source.json';pins[frozen]=frozen.read_bytes()
for name,row in json.loads(pins[frozen])['files'].items():
    p=ROOT/name;r=p.read_bytes();assert len(r)==row['bytes'] and sha256(r).hexdigest()==row['sha256'];pins[p]=r
for role,name in ((28,'program_dispatch'),(46,'program_admission_driver')):
    row=value['components'][str(role)];assert row['role']==role
    expected=ROOT/'examples/hia_bootstrap'/f'{name}.hiaasm'
    assert Path(row['expected_source_path']).resolve()==expected.resolve()
    for key,hashkey in [('source_path','source_sha256'),('expected_source_path','source_sha256'),('image_path','image_sha256')]:
        p=Path(row[key]);r=p.read_bytes();assert sha256(r).hexdigest()==row[hashkey]
        if p in pins:assert pins[p]==r
        pins[p]=r
    p=Path(row['receipt_path']);pins[p]=p.read_bytes();receipt=json.loads(pins[p])
    assert receipt['input_sha256']==row['source_sha256'] and receipt['produced_sha256']==row['image_sha256']
    assert receipt['artifact_sha256']==row['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
    bundle.components[role]=row
bundle.readback()
for role in (28,46):
    row=bundle.components[role];bundle.images[role]=NativeHiaJsonImage(pins[Path(row['image_path'])],row['image_sha256'])
(dest/'source-before.json').write_text(json.dumps({str(p):{'bytes':len(r),'sha256':sha256(r).hexdigest()} for p,r in pins.items()},indent=2,sort_keys=True)+'\n')
rows=[];calls=Counter();start=time.monotonic_ns();error=None

def actual(role,s,o,w,*,worksize=None,outsize=None):
    before=s.read(0,s.size)
    result=int(bundle.images[role]._entry(s.address,s.size,o.address,o.size if outsize is None else outsize,
        w.address,w.size if worksize is None else worksize))
    calls[role]+=1
    for buf in (s,o,w):buf.check()
    assert s.read(0,s.size)==before
    return result

def record(name,**row):
    row.update(case=name,status='PASS');rows.append(row)
    (dest/(name+'.json')).write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')

class PrivateExecutor(Executor):
    def __init__(self,lease,directory):
        super().__init__(bundle,lease,directory,identifier=72)
        self.controller=46
        self.command=struct.pack('<8Q',int.from_bytes(b'HIAPAI01','little'),72,0,len(lease),0,0,0,0)
        self.child_resume=None

    def operate(self,frame):
        if frame[1]==1:
            image,first,at,size,second,secondsize,work,worksize,observe,offset,count,zero=frame[4:]
            assert image in bundle.images and image<=28 and zero==0 and count<=256
            self.events[1]+=1
            result=self.native(image,first,at,size,second,secondsize,work,worksize)
            observed=self.buffers[observe].read(offset,count)
            return struct.pack('<8Q',C['ACK_MAGIC'],frame[2],frame[3],1,0,result,len(observed),0)+observed
        if frame[1]!=15:return super().operate(frame)
        mode,source,offset,extent,target,lease,*reserved=frame[4:]
        assert mode==0 and offset==0 and not any(reserved) and target not in self.buffers
        original=self.buffers[source].read(0,extent);assert self.buffers[source].readonly
        before=self.buffers[2].read(0,C['MIN_WORK'])
        child=PublicExecutor(bundle,original,self.directory/'child')
        child.identifier=lease
        child.buffers[2].write(12288+24,struct.pack('<Q',lease))
        try:
            terminal=child.run();raw=struct.pack('<16Q',*terminal)
            capacity=0
            if terminal[4:6]==(0,0):
                self.buffers[target]=child.buffers.pop(45)
                assert self.buffers[target].readonly
                capacity=self.buffers[target].size
            observed=raw+struct.pack('<4Q',capacity,target,child.controller,0)
        finally:child.close()
        assert self.buffers[source].read(0,extent)==original
        self.events[15]+=1
        ack=struct.pack('<8Q',C['ACK_MAGIC'],frame[2],frame[3],15,0,128,160,0)+observed
        self.child_resume=(before,ack)
        (self.directory/'actual-child-ack.bin').write_bytes(ack)
        (self.directory/'before-child-ack.state.gz').write_bytes(gzip.compress(before,mtime=0))
        return ack

    def run(self):
        while True:
            command=Buffer(len(self.command),self.command,True);out=Buffer(128)
            try:
                result=actual(46,command,out,self.buffers[2]);raw=out.read(0,128)
            finally:command.close();out.close()
            frame=struct.unpack('<16Q',raw)
            self.log({'role':46,'return':result,'frame':raw.hex(),'input_sha256':sha256(self.command).hexdigest()})
            assert result==128 and frame[:1]==(C['EVENT_MAGIC'],) and frame[2]==72,(result,frame)
            if frame[1]==7:
                assert frame[3]==self.sequence;self.final=frame;return frame
            assert frame[3]==self.sequence+1
            self.sequence=frame[3];self.command=self.operate(frame)

try:
    for kind,doc in [('primitive',scalar('hepta.hia.program.v8')),('structured',stored_loan_program())]:
        canonical=compact(doc);doc=json.loads(canonical);checked=verify_program(canonical)
        lease,issued=actual_source_lease(bundle,transport(doc))
        (dest/(kind+'-source-issuance.json')).write_text(json.dumps(issued,indent=2)+'\n')
        executor=PrivateExecutor(lease,dest/(kind+'-forwarder'))
        try:
            with ExitStack() as stack:
                for target in ['hepta.hia_program.verify_program','hepta.hia_program_composite.elaborate_program',
                    'hepta.hia_composite_function_tokens.ObjectTokenDecoder.feed',
                    'hepta.hia_composite_types_native.NativeCompositeTypeSession._command','json.loads']:
                    stack.enter_context(patch(target,side_effect=AssertionError('retained semantic owner used: '+target)))
                frame=executor.run()
            assert frame[4:6]==(0,0) and frame[6:8]==(56,256)
            core=executor.buffers[45].read(0,frame[11]);receipt=executor.buffers[56].read(0,256)
            words=struct.unpack('<32Q',receipt)
            assert core==checked.canonical_bytes and words[2:4]==(72,frame[3])
            assert receipt[80:112].hex()==checked.input_sha256 and receipt[112:144].hex()==checked.sha256
            assert executor.buffers[45].readonly and executor.buffers[56].readonly
            structured=b''
            if kind=='structured':
                assert executor.buffers[52].readonly
                structured=executor.buffers[52].read(0,words[9]);assert structured==checked.structured_bytes
                child_resume=executor.child_resume
            else:assert 52 not in executor.buffers
            (dest/(kind+'-receipt.bin')).write_bytes(receipt)
            (dest/(kind+'-core.json')).write_bytes(core)
            if structured:(dest/(kind+'-structured.json')).write_bytes(structured)
            record(kind+'-complete-private-views',core_sha256=sha256(core).hexdigest(),input_sha256=checked.input_sha256,
                receipt_sha256=sha256(receipt).hexdigest(),readonly=True,host_semantics_poisoned=True,
                calls=dict(executor.calls),events=dict(executor.events),actual_child=kind=='structured')
            command=Buffer(64,struct.pack('<8Q',int.from_bytes(b'HIAPAI01','little'),72,0,len(lease),0,0,0,0),True);out=Buffer(128)
            try:assert actual(46,command,out,executor.buffers[2])==0xfffffffd
            finally:command.close();out.close()
            record(kind+'-completed-lease-refuses-reuse',permanent_refusal=True)
        finally:executor.close()
    canonical=compact(scalar());lease,issued=actual_source_lease(bundle,transport(json.loads(canonical)))
    init=struct.pack('<8Q',int.from_bytes(b'HIAPAI01','little'),72,0,len(lease),0,0,0,0)
    ack=struct.pack('<8Q',C['ACK_MAGIC'],72,1,2,0,0,0,0)
    def state(raw=None):
        w=Buffer(C['MIN_WORK'],raw or b'')
        if raw is None:
            for slot,size in [(0,1),(1,len(lease)),(2,C['MIN_WORK'])]:w.write(C['CAPS']+slot*8,struct.pack('<Q',size))
        return w
    for name,index,value in [('magic',0,0),('lease-zero',1,0),('lease-wrap',1,(1<<64)-1),('legacy',2,1),('extent',3,len(lease)-1),('reserved',4,1)]:
        words=list(struct.unpack('<8Q',init));words[index]=value
        s=Buffer(64,struct.pack('<8Q',*words),True);good=Buffer(64,init,True);o=Buffer(128);w=state()
        try:
            assert actual(46,s,o,w)==0xfffffffd and actual(46,good,o,w)==0xfffffffd
            record('init-'+name,permanent_refusal=True)
        finally:s.close();good.close();o.close();w.close()
    for name,index,value in [('magic',0,0),('lease',1,73),('sequence',2,2),('opcode',3,1),('status',4,1),('return',5,1),('extent',6,64),('reserved',7,1)]:
        s=Buffer(64,init,True);o=Buffer(128);w=state();words=list(struct.unpack('<8Q',ack));words[index]=value
        bad=Buffer(64,struct.pack('<8Q',*words),True);good=Buffer(64,ack,True)
        try:
            assert actual(46,s,o,w)==128 and struct.unpack('<16Q',o.read(0,128))[1:4]==(2,72,1)
            assert actual(46,bad,o,w)==0xfffffffd and actual(46,good,o,w)==0xfffffffd
            record('ack-'+name,permanent_refusal=True)
        finally:s.close();o.close();w.close();bad.close();good.close()
    original_state,original_ack=child_resume
    for name,offset,value in [('header-sequence',16,0),('header-extent',48,0),('child-magic',64,0),
        ('child-lease',80,999),('child-error-in-success',104,1),('child-output-empty',152,0),
        ('transferred-capacity',192,0),('target-slot',200,44),('actual-role',208,47),('reserved',216,1)]:
        bad=bytearray(original_ack);struct.pack_into('<Q',bad,offset,value)
        s=Buffer(len(bad),bytes(bad),True);good=Buffer(len(original_ack),original_ack,True);o=Buffer(128);w=state(original_state)
        try:
            assert actual(46,s,o,w)==0xfffffffd and actual(46,good,o,w)==0xfffffffd,name
            record('actual-child-'+name,permanent_refusal=True,actual_child_frame=True)
        finally:s.close();good.close();o.close();w.close()
    s=Buffer(64,init,True);o=Buffer(128);w=state()
    try:
        before=w.read(0,w.size);assert actual(46,s,o,w,worksize=C['MIN_WORK']-1)==0xfffffffd
        assert before==w.read(0,w.size)
        record('short-workspace',permanent_native_poison_claimed=False,fixed_driver_must_discard_lease=True)
    finally:s.close();o.close();w.close()
except BaseException as exc:error=exc;raise
finally:
    bundle.close()
    summary={'scope':'ACTUAL_NATIVE_PRIVATE_PROGRAM_VIEWS_AND_PROTOCOL','status':'PASS' if error is None else 'FAIL',
        'cases':len(rows),'results':rows,'direct_entries':dict(calls),'all_source_image_pins_unchanged':True,
        'fixed_executor_syscall_fault_injection':False,'arbitrary_external_lease_authentication':False,'wall_ns':time.monotonic_ns()-start}
    if error is not None:summary.update(error_class=type(error).__name__,error=str(error))
    (dest/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='results'},sort_keys=True),flush=True)
