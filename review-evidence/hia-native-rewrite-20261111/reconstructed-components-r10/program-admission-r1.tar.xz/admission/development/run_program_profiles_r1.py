"""Complete existing nominal corpus and primitive dispatch/error precedence."""
from program_panel_support import Panel,compact,OLD,BASE
import copy
import json
import random
import sys
sys.path.insert(0,str(BASE))
from tests.test_hia_core_upgrade import scalar,owned
from tests.test_hia_bulk_memory import bulk_program
from tests.test_hia_overlap_move import move_program
from tests.test_hia_swap_v4 import swap_program
from tests.test_hia_offset_copy_v5 import copy_program
from tests.test_hia_range_fill_v6 import fill_program
from tests.test_hia_returned_loans import loan_program
from tests.test_hia_core_admission_native import borrowed_owner,returned_aliases
from tests.test_hia_program import f,b,i,ret,joined_loan_program

panel=Panel('profiles-r1',__file__);error=None
try:
    directory=OLD/'development/complete-profile-panel-r2'
    original=json.loads((directory/'summary.json').read_bytes());assert original['status']=='PASS'
    for row in original['results']:
        panel.run('nominal-'+row['case'],(directory/row['case']/'source-document.json').read_bytes())
    chain={'schema':'hepta.hia.program.v7','module':'chain','functions':[
        f('ok',[],[],[],[b('entry',[],[i('chain.empty',[],[('c','chain')]),i('owner.drop',['c'])],ret())])]}
    fixtures=[owned(),bulk_program(),move_program(),swap_program(),copy_program(),fill_program(),chain,loan_program()]
    for index,doc in enumerate(fixtures):
        panel.run('primitive-feature-'+str(index),compact(doc))
        if index:
            bad=copy.deepcopy(doc);bad['schema']='hepta.hia.program.v'+str(int(doc['schema'][-1])-1)
            panel.run('primitive-downgrade-'+str(index),compact(bad))
    for index,types in enumerate([('mutbuf','mutbuf'),('mutbuf','readbuf'),('readbuf','readbuf'),('u32','readbuf','buffer','readbuf')]):
        panel.run('returned-aliases-'+str(index),compact(returned_aliases(types)))
    panel.run('borrowed-live-owner',compact(borrowed_owner()))
    for index,doc in enumerate([None,False,[],{},['hepta.hia.program.v2']]):panel.run('root-'+str(index),compact(doc))
    for index,version in enumerate([None,False,0,[],{},['hepta.hia.composite.v1'],'hepta.hia.program.v9','hepta.hia.composite.v5']):
        doc=scalar();doc['schema']=version;panel.run('schema-'+str(index),compact(doc))
    for index,value in enumerate([None,False,0,[],{},'anything']):
        doc={'schema':'hepta.hia.program.v2','types':value,'unrecognized':True}
        panel.run('collision-presence-'+str(index),compact(doc),expected_stage=(10,1))
    for schema in ['hepta.hia.program.v1','hepta.hia.program.v3','hepta.hia.composite.v1']:
        panel.run('no-implicit-legacy-'+schema[-1]+schema.split('.')[2],compact({'schema':schema,'types':None}))
    for index,raw in enumerate([b'',b'{',b'{"x":1,"x":2}',b'1.0',b'1e0',b'NaN',b'Infinity',b'"\\ud800"',
        b'"\\udc00"',b'"\\ud800x"',b'"\xff"',b'"\xed\xa0\x80"',b'{}\xff',b'\xef\xbb\xbf{}',b'0'*4301,
        b'1'+b'0'*4299,b'1'+b'0'*4300,b'['*65+b'0'+b']'*65,b'0'+b' '*((8<<20)),b'0'+b'\xff'*((8<<20))]):
        panel.run('raw-'+str(index),raw)
    for index,raw in enumerate([json.dumps(scalar(),indent=2).encode(),b' \n'+compact(scalar())+b'\r\t',
        json.dumps(scalar(),sort_keys=False).encode(),compact(scalar()).replace(b'compute',b'\\u0063ompute')]):
        panel.run('canonical-digest-'+str(index),raw)
    rng=random.Random(734162)
    for index in range(48):
        value=copy.deepcopy(joined_loan_program());fn=value['functions'][0];block=rng.choice(fn['blocks'])
        if rng.randrange(3)==0:
            term=block['term'];term[rng.choice(tuple(term))]=rng.choice((None,False,0,'missing',[],{}))
        elif block['ops']:
            ins=rng.choice(block['ops']);ins[rng.choice(tuple(ins))]=rng.choice((None,False,0,'missing',[],{}))
        else:fn['effects']=rng.choice(([],['alloc'],['read'],['trap'],['bogus']))
        panel.run('primitive-mutation-'+str(index),compact(value))
except BaseException as exc:
    error=exc;raise
finally:panel.close(error)
