"""Development-only full retained oracle and actual immutable ELF runner."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import resource
import struct
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'Hepta-v66-restored'
OLD=ROOT.parent/'native-composite-driver-reconstructed'
sys.path[:0]=[str(ROOT),str(OLD/'development'),str(OLD),str(BASE)]
from hepta.hia_program import HIAProgramRejected,verify_program
from hepta.hia_core_admission_native import ERROR_CODES
from pipeline_panel_support import native_error

def compact(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode()

def limits():
    resource.setrlimit(resource.RLIMIT_AS,(1536<<20,1536<<20))
    resource.setrlimit(resource.RLIMIT_STACK,(8<<20,8<<20))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def diagnosis(frame):
    group,error=frame[4:6]
    if group==10:
        assert error==1
        return 'E_HIA_VERSION_COLLISION'
    if group==8:return ERROR_CODES[error]
    if group==7:return 'E_HIA_LIMIT' if error in (1,3) else 'E_HIA_FORMAT'
    return native_error(frame)[0]

class Panel:
    def __init__(self,name,script):
        self.dest=ROOT/'development'/name;self.dest.mkdir(exist_ok=False)
        self.empty=self.dest/'empty';self.empty.mkdir()
        path=ROOT/'development/build-r2/bundle.json';raw=path.read_bytes();self.bundle=json.loads(raw)
        assert self.bundle['status']=='PASS' and len(self.bundle['components'])==35
        self.exe=Path(self.bundle['executable']['path']);exe=self.exe.read_bytes()
        assert sha256(exe).hexdigest()==self.bundle['executable']['sha256']
        self.pins={path:raw,self.exe:exe,Path(script):Path(script).read_bytes(),Path(__file__):Path(__file__).read_bytes()}
        for row in self.bundle['components'].values():
            for key,hashkey in [('source_path','source_sha256'),('expected_source_path','source_sha256'),('image_path','image_sha256')]:
                p=Path(row[key]);raw=p.read_bytes();assert sha256(raw).hexdigest()==row[hashkey]
                if p in self.pins:assert self.pins[p]==raw
                self.pins[p]=raw
        frozen=ROOT/'checkpoints/source-r1/source.json';self.pins[frozen]=frozen.read_bytes()
        for name,row in json.loads(self.pins[frozen])['files'].items():
            p=ROOT/name;raw=p.read_bytes();assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'];self.pins[p]=raw
        for p in (BASE/'hepta').glob('*.py'):self.pins[p]=p.read_bytes()
        (self.dest/'source-before.json').write_text(json.dumps({str(p):{'bytes':len(raw),'sha256':sha256(raw).hexdigest()} for p,raw in self.pins.items()},indent=2,sort_keys=True)+'\n')
        self.rows=[];self.started=time.monotonic_ns()

    def run(self,label,wire,*,expected_stage=None,timeout=180):
        folder=self.dest/label;folder.mkdir()
        (folder/'input.json.gz').write_bytes(gzip.compress(wire,compresslevel=1,mtime=0))
        checked=None
        try:
            checked=verify_program(wire)
            original=json.loads(checked.structured_bytes if checked.structured_bytes is not None else checked.canonical_bytes)
            oracle={'accepted':True,'bytes':len(checked.canonical_bytes),'core_sha256':checked.sha256,'input_sha256':checked.input_sha256,
                'input_schema':original['schema'],'core_schema':checked.as_dict()['schema'],
                'structured_bytes':len(checked.structured_bytes or b''),
                'canonical_input_bytes':len(checked.structured_bytes if checked.structured_bytes is not None else checked.canonical_bytes)}
            (folder/'expected.core.json.gz').write_bytes(gzip.compress(checked.canonical_bytes,compresslevel=1,mtime=0))
            if checked.structured_bytes is not None:(folder/'expected.structured.json.gz').write_bytes(gzip.compress(checked.structured_bytes,compresslevel=1,mtime=0))
        except HIAProgramRejected as exc:
            oracle={'accepted':False,'code':exc.code,'error':str(exc)}
        (folder/'oracle.json').write_text(json.dumps(oracle,indent=2)+'\n')
        started=time.monotonic_ns();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        try:
            p=subprocess.run([str(self.exe)],input=wire,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=self.empty,
                env={'PATH':str(self.empty),'HOME':str(self.empty),'LANG':'C'},preexec_fn=limits,timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            (folder/'timeout.stdout').write_bytes(exc.stdout or b'');(folder/'timeout.stderr').write_bytes(exc.stderr or b'')
            (folder/'timeout.json').write_text(json.dumps({'timeout_seconds':timeout,'wall_ns':time.monotonic_ns()-started,'error':str(exc)},indent=2)+'\n')
            raise
        after=resource.getrusage(resource.RUSAGE_CHILDREN)
        (folder/'stdout.bin.gz').write_bytes(gzip.compress(p.stdout,compresslevel=1,mtime=0));(folder/'stderr.bin').write_bytes(p.stderr)
        row={'case':label,'input_bytes':len(wire),'input_sha256':sha256(wire).hexdigest(),'oracle':oracle,'returncode':p.returncode,
            'stdout_bytes':len(p.stdout),'stdout_sha256':sha256(p.stdout).hexdigest(),'stderr_bytes':len(p.stderr),'stderr_sha256':sha256(p.stderr).hexdigest(),
            'wall_ns':time.monotonic_ns()-started,'user_cpu_seconds':after.ru_utime-usage.ru_utime,'system_cpu_seconds':after.ru_stime-usage.ru_stime,
            'development_timeout_seconds':timeout}
        if len(p.stderr)%8==0:row['stderr_words']=list(struct.unpack('<'+'Q'*(len(p.stderr)//8),p.stderr))
        (folder/'actual.json').write_text(json.dumps(row,indent=2)+'\n')
        if checked is not None:
            assert p.returncode==0 and len(p.stderr)==256 and p.stdout==checked.canonical_bytes,row
            words=struct.unpack('<32Q',p.stderr)
            kind=int(checked.structured_bytes is not None)
            assert words[:3]==(int.from_bytes(b'HIAPRV01','little'),1,72) and words[3]>0,row
            assert words[4:10]==(kind,int(oracle['input_schema'][-1]),int(oracle['core_schema'][-1]),oracle['canonical_input_bytes'],len(p.stdout),oracle['structured_bytes']),row
            assert p.stderr[80:112].hex()==checked.input_sha256 and p.stderr[112:144].hex()==checked.sha256,row
            assert words[18:27]==(45,52 if kind else 0,56,256,1,kind,0,0,0) and words[27:]==(0,)*5,row
        else:
            assert p.returncode==2 and p.stdout==b'' and len(p.stderr)==128,row
            frame=struct.unpack('<16Q',p.stderr)
            assert diagnosis(frame)==oracle['code'],(row,diagnosis(frame))
            if expected_stage is not None:assert tuple(frame[4:6])==tuple(expected_stage),(row,expected_stage)
        row['status']='PASS';self.rows.append(row)
        (folder/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,sort_keys=True),flush=True)
        return row

    def close(self,error=None):
        assert all(p.read_bytes()==raw for p,raw in self.pins.items())
        result={'scope':'COMPLETE_RAW_PROGRAM_ADMISSION_FIXED_NATIVE_ELF_DEVELOPMENT','status':'PASS' if error is None else 'FAIL',
            'cases_completed':len(self.rows),'results':self.rows,'all_source_and_image_pins_unchanged':True,
            'retained_child_runtime':False,'strace_observed':False,'complete_dynamic_diagnostic_text':False,
            'original_cold_compiler_language_limits_unchanged':True,'whole_stack_closed':False,'wall_ns':time.monotonic_ns()-self.started}
        if error is not None:result.update(error_class=type(error).__name__,error=str(error))
        (self.dest/'summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print(json.dumps({k:v for k,v in result.items() if k!='results'},sort_keys=True),flush=True)
