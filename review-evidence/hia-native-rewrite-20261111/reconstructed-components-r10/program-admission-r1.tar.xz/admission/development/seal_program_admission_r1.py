"""Seal completed admission evidence; stdout must be outside the overlay."""
from hashlib import sha256
import json
from pathlib import Path
import stat
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT.parent
OLD = WORK / 'native-composite-driver-reconstructed'
IMPORTER = WORK / 'native-composite-legacy-import-next'
BASE = WORK / 'Hepta-v66-restored'
ARCHIVE = WORK / 'hia-program-admission-native-r1-development.tar.xz'
assert not ARCHIVE.exists()


def facts(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
            'mode': stat.S_IMODE(path.stat().st_mode)}


def write(name, value):
    path = ROOT / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


current = ROOT / 'checkpoints/source-r1/source.json'
source = json.loads(current.read_bytes())
for name, record in source['files'].items():
    assert facts(ROOT / name) == record, name

reports = {}
for name, count, key in [('smoke-r1', 15, 'cases_completed'),
                         ('profiles-r1', 196, 'cases_completed'),
                         ('boundaries-r1', 13, 'cases_completed'),
                         ('protocol-r1', 29, 'cases')]:
    path = ROOT / 'development' / name / 'summary.json'
    row = json.loads(path.read_bytes())
    assert row['status'] == 'PASS' and row[key] == count
    assert row.get('all_source_and_image_pins_unchanged',
                   row.get('all_source_image_pins_unchanged')) is True
    reports[name] = {'path': str(path.relative_to(ROOT)), **facts(path),
                     'cases': count, 'wall_ns': row['wall_ns']}

bundlepath = ROOT / 'development/build-r2/bundle.json'
bundle = json.loads(bundlepath.read_bytes())
assert bundle['status'] == 'PASS' and len(bundle['components']) == 35
exe = Path(bundle['executable']['path'])
exefacts = facts(exe)
assert exefacts['sha256'] == bundle['executable']['sha256']
assert exefacts['bytes'] == bundle['executable']['bytes']

external = {}
for name in ['build-r2', 'smoke-r1', 'profiles-r1', 'boundaries-r1', 'protocol-r1']:
    path = ROOT / 'development' / name / 'source-before.json'
    for filename, record in json.loads(path.read_bytes()).items():
        p = Path(filename)
        actual = facts(p)
        assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], filename
        if not p.is_relative_to(ROOT):
            if p in external:
                assert external[p] == actual
            external[p] = actual

original = OLD / 'checkpoints/public-native-source-r1/source.json'
extras = [original, OLD / 'development/publication-bundle-r2/bundle.json',
          IMPORTER / 'checkpoints/importer-source-r3/source.json']
extras += [OLD / row['path'] for row in json.loads(original.read_bytes())['files']]
extras += [IMPORTER / 'tools' / name for name in (
    'legacy_authoring.py', 'author_legacy_executor.py', 'legacy_native_executor.S')]
extras += [OLD / 'development' / name for name in (
    'mechanical_executor.py', 'raw_mechanical_executor.py',
    'publication_mechanical_executor.py', 'pipeline_panel_support.py')]
extras += [BASE / 'tests' / name for name in (
    'test_hia_program_composite.py', 'test_hia_composite_v6_resources.py',
    'test_hia_core_upgrade.py')]
extras += [BASE / 'tools' / name for name in (
    'generate_hia_selfhost.py', 'qualify_hia_selfhost.py')]
panel = OLD / 'development/complete-profile-panel-r2'
extras.append(panel / 'summary.json')
for row in json.loads((panel / 'summary.json').read_bytes())['results']:
    extras.append(panel / row['case'] / 'source-document.json')
for p in extras:
    actual = facts(p)
    if p in external:
        assert external[p] == actual
    external[p] = actual

dependency_map = {
    str(p): {'archive_path': 'dependencies/' + str(p.relative_to(WORK)), **record}
    for p, record in sorted(external.items())
}
write('DEPENDENCY_CUSTODY.json', {
    'scope': 'EXACT_CURRENT_NATIVE_COMPONENT_COMPILER_ORACLE_AUTHORING_DEPENDENCIES',
    'files': dependency_map,
    'baseline_git_commit': 'e2f392e5658d3cb2d6867a14b88c6335b5975f96',
    'prior_ordinary_archive': {
        'sha256': '7b511739276154447217574595291a23557a40582cc556b7be4e5f7c55d224ed',
        'bytes': 122722348, 'git_custody_commit': '9be384e9a01096081730c3012ecad773326a323d'},
    'prior_importer_archive': {
        'sha256': '19c16b47ab03bad544bca724a23988ff65600e3739cfd0fde3052472a2fed1db',
        'bytes': 4595336, 'git_custody_commit': '0706112dcb04b853b989d2c1f048eb7d0563eb69'},
    'note': 'Exact current runtime sources/images/receipts/compiler are embedded. This is not a whole repository copy.'})
write('FINAL_SOURCE_MANIFEST.json', {
    'scope': 'COMPLETE_RAW_PROGRAM_ADMISSION_NATIVE_DEVELOPMENT_R1',
    'production_files': source['files'],
    'source_manifest': {'path': str(current.relative_to(ROOT)), **facts(current)},
    'bundle': {'path': str(bundlepath.relative_to(ROOT)), **facts(bundlepath)},
    'executable': {'path': str(exe.relative_to(ROOT)), **exefacts},
    'components': bundle['components'], 'packer': bundle['packer'],
    'compiler_sha256': bundle['compiler_sha256'], 'completed_reports': reports,
    'public_fixed_elf_cases': 224, 'private_protocol_cases': 29,
    'complete_dynamic_diagnostic_text': False, 'whole_stack_closed': False,
    'production_activation': False, 'cold_qualified': False,
    'nested_executor_independent_review_complete': False,
    'external_syscall_trace_observed': False})

members = {'admission': ROOT}
for p in sorted(ROOT.rglob('*')):
    if '__pycache__' in p.parts or p.suffix == '.pyc':
        continue
    assert not p.is_symlink(), p
    members['admission/' + str(p.relative_to(ROOT))] = p
for p in external:
    members[dependency_map[str(p)]['archive_path']] = p
for archive_name, p in list(members.items()):
    parent_name, parent = Path(archive_name).parent, p.parent
    while str(parent_name) not in ('.', ''):
        name = str(parent_name)
        if name not in members:
            members[name] = parent
        parent_name, parent = parent_name.parent, parent.parent

ledger = []
for name, p in sorted(members.items()):
    row = {'path': name, 'original_path': str(p),
           'kind': 'directory' if p.is_dir() else 'file',
           'mode': stat.S_IMODE(p.stat().st_mode)}
    if p.is_file():
        row.update(facts(p))
    ledger.append(row)

started = time.monotonic_ns()
with tarfile.open(ARCHIVE, 'w:xz', preset=6) as tar:
    for row in ledger:
        tar.add(row['original_path'], arcname=row['path'], recursive=False)
with tarfile.open(ARCHIVE, 'r:xz') as tar:
    actual = tar.getmembers()
    assert len(actual) == len(ledger)
    for member, row in zip(actual, ledger):
        assert member.name == row['path'] and member.mode == row['mode']
        p = Path(row['original_path'])
        if row['kind'] == 'directory':
            assert member.isdir() and p.is_dir()
        else:
            assert member.isfile() and member.size == row['bytes']
            raw = tar.extractfile(member).read()
            assert raw == p.read_bytes() and sha256(raw).hexdigest() == row['sha256']
            assert facts(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}

ledgerpath = WORK / 'hia-program-admission-native-r1-development.members.json'
custodypath = WORK / 'hia-program-admission-native-r1-development.custody.json'
assert not ledgerpath.exists() and not custodypath.exists()
ledgerpath.write_text(json.dumps({'scope': 'FULL_ARCHIVE_MEMBER_READBACK', 'members': ledger},
                                 indent=2, sort_keys=True) + '\n')
custody = {
    'scope': 'COMPLETE_RAW_PROGRAM_ADMISSION_NATIVE_DEVELOPMENT_R1_CUSTODY',
    'archive': str(ARCHIVE), **facts(ARCHIVE),
    'members': len(ledger), 'file_members': sum(r['kind'] == 'file' for r in ledger),
    'raw_file_bytes': sum(r.get('bytes', 0) for r in ledger),
    'member_manifest': {'path': str(ledgerpath), **facts(ledgerpath)},
    'readback_all_original_bytes_sha256_mode': True,
    'source_manifest': facts(current), 'completed_reports': reports,
    'whole_stack_closed': False, 'complete_dynamic_diagnostic_text': False,
    'production_activation': False, 'wall_ns': time.monotonic_ns() - started}
custodypath.write_text(json.dumps(custody, indent=2, sort_keys=True) + '\n')
print(json.dumps(custody, sort_keys=True), flush=True)
