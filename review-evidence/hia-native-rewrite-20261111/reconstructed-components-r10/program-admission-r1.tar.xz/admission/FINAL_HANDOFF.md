# Complete raw program admission: native development r1

## Delivered boundary

`development/build-r2/hia-admit-program` is an actual fixed x86-64 ELF emitted by an actual HIA packer. It embeds 35 exact HIA images and reads one raw integer-JSON program from stdin. HIA performs the public raw-input admission, primitive v1–v8 versus composite v1–v4 selection, complete normalization, complete primitive Core admission, and both canonical hashes. The executable runs with empty `PATH` and `HOME`. Its template performs memory, file and image-call operations; it does not invoke Python or an external child process.

This preserves the public byte-input contract of `verify_program`. Original byte size is checked before full UTF-8 decoding; strict JSON, duplicate keys, surrogates, integer digits, node/depth budgets and canonical detached input precede schema selection. Only exact composite schema strings select the complete composite pipeline. A primitive-v2 object containing the direct `types` key retains the historical collision rejection, including a null value. Other inputs reach the whole primitive Core checker in its original order. Legacy import remains a separate explicit entry and is not selected automatically.

Structured input runs a fresh complete ordinary child invocation in the same native process. The child preserves constructor, type, function, task-helper, outer, late expanded-Core and final primitive admission ownership. It transfers only its successful readonly canonical Core mapping. It does not reuse a qualification result or skip the final Core check. Composite v1 maps to Core v6, v2/v3 to v7, and v4 to v8.

Private Python object input, arbitrary `VerifiedProgram` wrappers, installation/default-route switching, and full dynamic English diagnostic text are outside this completed wire component. No fallback host semantic check is used at runtime. Those distinctions are not claims that the whole project is closed.

## Exact source and image identity

The production freeze is `checkpoints/source-r1/source.json`, SHA-256 `f69cb7819a17f8dd3c13794510b0640716714ee4f013fc17f04511da6bb1eae2`, covering twelve files. The actual build manifest is `development/build-r2/bundle.json`. It binds all 35 images, their exact current/frozen HIA sources, original receipts, the historical f50 B3 compiler and the actual HIA packer output.

The actual ELF is 7,133,812 bytes, SHA-256 `8f3331a1763adbf7630f72e1216493c956ca979010dd6c50c8c29fdb56f1c57d`. New role 28 is native schema dispatch; role 46 is complete admission and receipt continuation. Existing roles 1–27 and 40–45 remain byte-identical to the frozen ordinary 33-image dependency. There is no legacy-importer image in this executable.

The historical B3 compiler is 668,608 bytes, SHA-256 `0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8`. New images and the packer were compiled under the unchanged 10-second CPU, 20-second wall, 256 MiB address-space, 8 MiB stack, and original 1 MiB compiler capacities. This is development provenance, not matching-current cold qualification.

## Actual results

All twelve production files and every used image/source pin remained unchanged across the completed tests.

| Actual gate | Result | Recorded elapsed time |
| --- | --- | --- |
| Fixed-ELF smoke, eight primitive and four composite profiles plus priority controls | 15 / 15 PASS | 2.206585354 s |
| Fixed-ELF full profile, raw-input and mutation panel | 196 / 196 PASS | 28.019126671 s |
| Fixed-ELF full limits and late-error panel | 13 / 13 PASS | 251.546298632 s |
| Actual private readonly views and protocol refusal controls | 29 / 29 PASS | 0.831265440 s |

The 224 public fixed-ELF cases compare every accepted Core byte, the complete receipt layout, canonical input size and both independent digest fields. Refusals compare the first error category and retain the full hosted diagnostic oracle alongside the actual native frame. This does not claim dynamic diagnostic-text equality. Each ELF process had empty `PATH`/`HOME`, a 1.5 GiB address-space limit, and an independent bounded development timeout of 180 seconds. No cold, retained-test, compiler or language limit was changed.

The 196-case panel includes the previously frozen 82 nominal fixtures with their original schema, all primitive capability versions and downgrades, returned loans and borrowed owners, ordinary version collision, unsupported schemas, duplicate keys, malformed UTF-8/JSON, integer/depth/byte limits, canonical-hash equivalence and 48 seeded Core mutations.

The thirteen-case boundary panel covers 1,024/1,025 functions, 4,096/4,097 blocks, full 16,384 parameter and 1,024 return arity, 262,144/262,145 input nodes and depth 64/65. Both exact 8 MiB accepted inputs actually completed:

* Primitive input and returned Core are both 8,388,608 bytes, SHA-256 `c23419869667a330ccee52ecbd1d1c1d6bdafe036243cc4d65ce16cca643794d` (42.251472698 s).
* Structured input is 8,388,608 bytes, input SHA-256 `45a61fda076e92501104b4cd5819672a1eb38f1d5c8b8aba6a37120ff57acb0c`; its complete 231-byte Core has SHA-256 `8b10e85954224e11b93128444289ce2c2ffbcdbbfd2ca42b92c03a96ac7c96cc` (72.671201128 s).

The final two original cases prove the late gate order. A complete 8,473,644-byte expanded Core is rejected after all functions by the byte-budget error (55.314650585 s). With a later invalid function, its `E_HIA_CFG` rejection precedes that expanded-Core error (41.294907385 s). Both actual processes exited 2 with no stdout. The original runner's terminal thirteen-case summary and all case bytes survived the subsequent shared-disk ENOSPC event. A later independent readback rechecked all 224 inputs, outputs, errors and oracle/result records without executing them again.

The 29 protocol controls use the actual new image and actual child response, not a fabricated success frame. They cover primitive/structured readonly Core and receipt views, complete source-view preservation, completion replay, six malformed initializations, eight malformed initial ACKs and ten altered fields of an actual native child ACK. Retained verification, elaboration, type service, ObjectToken decoding and `json.loads` are poisoned during mechanical forwarding. A short advertised workspace cannot persist native poison; the fixed caller must immediately discard that lease. Arbitrary external source-lease authentication and fixed-template syscall fault injection are not claimed.

## Callable success and failure contract

Invoke the ELF with no extra arguments and provide stdin through EOF. Success is exit 0, complete canonical Core bytes on stdout without an added newline, and a 256-byte little-endian receipt on stderr. Receipt publication happens before Core stdout, so a caller must require successful exit, complete output extent and the output hash; a receipt alone does not authorize a partial write.

The receipt begins with `HIAPRV01` and version 1. Its words 4–9 give primitive/structured kind, input version, Core version, canonical input bytes, Core bytes and structured bytes. The canonical input SHA occupies bytes 80–111 and the normalized Core SHA occupies bytes 112–143. Words 18–20 identify readonly Core slot 45, structured slot 52 (or zero for primitive), and receipt slot 56. Word 22 marks complete primitive rechecking; word 23 marks structured rechecking. Words 24–26 explicitly report no implicit legacy import, no external authentication and no full dynamic diagnostic text.

For same-process composition, the final HIA event is 128 bytes with action 7 and zero error group/code. It identifies the same immutable Core, structured-source and receipt buffers. Their lifetime belongs to the current invocation. A fixed coordinator can borrow these views without Python values or a schema decision in the host.

Semantic refusal is exit 2, empty stdout and a complete 128-byte diagnostic frame. Group 7 represents raw JSON rejection, group 8 whole primitive Core rejection, group 10 the historical version collision, and groups 1–6 the existing complete composite phases. ABI refusal and I/O refusal are separate exits. Full English diagnostic context remains the next native owner; current group/code reporting must not be advertised as that completion.

## Preserved failures and remaining review

The original authoring `/` operation was rejected by the existing builder, and the unchanged failing source was replayed and saved under `development/authoring-r1`. The equivalent unsigned shift correction changes no language quota. The first build attempt failed because the mechanical assembly template had not yet been generated; `development/build-r1.log` is retained. New build identity r2 includes the generated template and successful actual compilation. No original failure was overwritten.

The syscall template uses the established same-process `RUN_CHILD` operation. Parent role 46 admits only ordinary mode 0; it creates fresh child state, borrows only the selected immutable source, closes child-only mappings/descriptors and transfers the successful Core mapping. Prior independent review of the ordinary template does not constitute review of this fork. New nested-template independent review and external tracing remain outstanding. Local ptrace was previously denied and is not treated as a product pass or failure.

This candidate has not been activated as an ordinary installed default, has not passed an integrated matching-current cold/full suite, and does not remove retained owners. Python generators, assembly authoring and development oracles are still present. No whole-stack closure is asserted.

## Recovery and custody

The archive contains the complete current overlay, original failed authoring/build records, all actual compiler and packer inputs/receipts/images, the emitted ELF, all 224 original public cases, the 29 protocol controls and the post-ENOSPC readback. Exact live dependency sources/images/compiler/receipts and hosted oracle files are embedded under `dependencies/` with original paths recorded in `DEPENDENCY_CUSTODY.json`; the remaining baseline is exact Git commit `e2f392e5658d3cb2d6867a14b88c6335b5975f96`.

Prior ordinary and importer original archives are already held by recovery commits `9be384e9a01096081730c3012ecad773326a323d` and `0706112dcb04b853b989d2c1f048eb7d0563eb69`. After matching local and archived bytes, SHA-256 and modes, only 57 redundant one-MiB compiler output buffers were removed from the old ordinary overlay; all images, sources, manifests and current originals remain. The cleanup ledger is included here. The complete new archive is independently read back member by member, including modes.
