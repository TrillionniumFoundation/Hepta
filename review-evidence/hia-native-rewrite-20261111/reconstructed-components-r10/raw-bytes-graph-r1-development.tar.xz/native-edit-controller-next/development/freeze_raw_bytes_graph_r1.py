"""Freeze and independently check the native raw-byte Graph issuer.

This proves exact private transport, not public frontend/object authority.
"""
from pathlib import Path
from hashlib import sha256
import importlib.util,json,struct,sys,time,traceback
from hepta.hia_agent_assembly import assemble_program,render_assembly
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from bounded_input_harness import Actual

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
OUT=ROOT/'development/raw-bytes-graph-r1';OUT.mkdir(parents=True,exist_ok=False)
GEN=ROOT/'tools/generate_hia_raw_bytes_graph.py'
COMPILER=BASE/'native-agent-edit-development/facts-source-and-compile-r1/source/compiler/B3.image.bin'
SOURCE=ROOT/'examples/hia_bootstrap/agent_raw_bytes_graph.hiaasm'
spec=importlib.util.spec_from_file_location('raw_bytes_graph_generator',GEN)
author=importlib.util.module_from_spec(spec);spec.loader.exec_module(author)
paths=[GEN,SOURCE,COMPILER,Path(__file__),
       BASE/'Hepta-agent-edit-native/tools/hia_agent_edit_source_views.py',
       BASE/'Hepta-agent-edit-native/tools/generate_hia_agent_edit_apply_graph.py',
       BASE/'native-agent-edit-development/facts_harness.py',
       BASE/'native-agent-edit-development/bounded_input_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for i,(p,raw) in enumerate(frozen.items()):
    target=OUT/'source'/str(i)/p.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
M=lambda s:int.from_bytes(s,'little');BAD=0xfffffffd
def command(action=1,lease=113,request=1,sequence=0):
    return struct.pack('<8Q',M(b'HIABGC01'),action,lease,request,sequence,0,0,0)
def expected(raw,lease=113):
    return struct.pack('<16Q',M(b'HIAGRF01'),lease,1,1,0,len(raw),128+len(raw),0,9,128,len(raw),0,0,0,0,0)+raw
def run(call,label,raw,request,*,compare=None):
    c=command(request=request);w=bytes(1024);entries=0
    while True:
        code,after=call(label,raw,c,w);entries+=1
        if compare is not None:assert compare(raw,c,w)==(code,after)
        e=struct.unpack_from('<16Q',after,256)
        assert code==384 and e[0]==M(b'HIABGE01') and e[2:4]==(113,request) and e[8:]==(0,)*8
        if e[1]==0:
            assert after[e[6]:e[6]+e[7]]==expected(raw)
            return after,c,entries
        assert e[1]==1 and e[5]>len(after) and e[5]==1152+len(raw)
        w=after+bytes(e[5]-len(after));c=command(2,request=request,sequence=e[4])

summary=dict(status='INCOMPLETE',scope='PRIVATE_EXACT_BYTES_GRAPH_TRANSPORT_NOT_PUBLIC_FRONTEND')
start=time.monotonic_ns();native=None
try:
    doc=author.document();assert render_assembly(doc).encode()==frozen[SOURCE];checked=assemble_program(frozen[SOURCE])
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),
        max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),
        max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    vm_entries=[0]
    def vcall(label,a,b,w):
        code,after=vm_call(checked,a,b,w);vm_entries[0]+=1
        for suffix,raw in [('source',a),('command',b),('before',w),('after',after)]:
            (OUT/('vm-'+str(vm_entries[0])+'.'+suffix+'.bin')).write_bytes(raw)
        return code,after
    raws=[b'',b'\xff\x00\xed\xa0\x80',bytes(range(256))+b'\x00',b'{"uninterpreted":true}']
    for n,raw in enumerate(raws,1):run(vcall,'vm-'+str(n),raw,n)
    image,receipt=compile_stage(OUT,'agent-raw-bytes-graph',COMPILER,frozen[SOURCE])
    manifest=dict(schema='hepta.hia.agent-raw-bytes-graph-native.v1',source_path=rows[1]['copy'],
        source_sha256=sha256(frozen[SOURCE]).hexdigest(),image_path=str(image),image_sha256=sha256(image.read_bytes()).hexdigest(),
        compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    mp=OUT/'agent-raw-bytes-graph.manifest.json';mp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    native=Actual(mp,OUT/'native');cases=[];controls=[]
    for n,raw in enumerate(raws,1):
        w,c,count=run(native.call,'native-'+str(n),raw,n,compare=lambda a,b,w:vm_call(checked,a,b,w))
        cases.append(dict(bytes=len(raw),sha256=sha256(raw).hexdigest(),actual_entries=count,full_VM_workspace_equal=True))
    # No private issuer quota is silently introduced at the public program cap.
    raw=(b'\x00\xff012345'*((8*1024*1024)//8+1))[:8*1024*1024+1]
    w,c,count=run(native.call,'raw-eight-mib-plus-one',raw,100)
    cases.append(dict(bytes=len(raw),sha256=sha256(raw).hexdigest(),actual_entries=count,full_exact_graph=True))
    def bad(label,raw,c,w):
        code,after=native.call(label,raw,c,w);assert code==BAD,(label,code)
        if len(w)>=1024:
            assert struct.unpack_from('<Q',after,8)[0]==3
            assert native.call(label+'-persistent',raw,command(),after)==(BAD,after)
        controls.append(label)
    raw=b'private';begin=command();zero=bytes(1024)
    for size in (0,511,1023):bad('short-work-'+str(size),raw,begin,bytes(size))
    bad('short-command',raw,begin[:-1],zero)
    for at,value in [(0,0),(8,2),(16,0),(24,0),(32,1),(40,1),(48,1),(56,1)]:
        c=bytearray(begin);struct.pack_into('<Q',c,at,value);bad('bad-init-'+str(at),raw,bytes(c),zero)
    dirt=bytearray(zero);dirt[999]=1;bad('dirty-init',raw,begin,bytes(dirt))
    code,pending=native.call('pending-seed',raw,begin,zero);assert code==384
    pe=struct.unpack_from('<16Q',pending,256);continuation=command(2,sequence=pe[4]);grown=pending+bytes(pe[5]-len(pending))
    for at,value in [(0,0),(8,1),(16,114),(24,2),(32,0),(40,1),(48,1),(56,1)]:
        c=bytearray(continuation);struct.pack_into('<Q',c,at,value);bad('bad-pending-'+str(at),raw,bytes(c),grown)
    bad('changed-extent',raw+b'!',continuation,grown)
    for at,value in [(0,0),(8,4),(32,(1<<64)-1)]:
        cw=bytearray(grown);struct.pack_into('<Q',cw,at,value)
        cc=command(2,sequence=value) if at==32 else continuation
        bad('corrupt-state-'+str(at),raw,cc,bytes(cw))
    code,done=native.call('terminal-seed',raw,continuation,grown);assert code==384
    bad('terminal-replay',raw,continuation,done)
    summary.update(status='PASS',profile=profile,independent_VM_cases=len(raws),independent_VM_entries=vm_entries[0],
        actual_cases=cases,private_controls=controls,actual_entries=native.entries,manifest=manifest,compiler_receipt=receipt)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    if native is not None:native.close()
    summary['source_before_after_equal']=all(p.read_bytes()==raw for p,raw in frozen.items())
    summary['elapsed_ns']=time.monotonic_ns()-start
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
