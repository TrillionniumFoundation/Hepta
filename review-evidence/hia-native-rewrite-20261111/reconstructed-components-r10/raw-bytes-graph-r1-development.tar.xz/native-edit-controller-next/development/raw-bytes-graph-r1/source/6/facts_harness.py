"""Fresh development observation of actual HIA edit-fact entries.

The lease is private and must have been issued by the actual native packet
validator. This harness transports immutable bytes and records complete buffers;
it contains no selector, name resolution, fact layout, or slice decisions.
"""
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import struct

from hepta.hia_json_preflight_native import NativeHiaJsonImage

MAGIC = lambda x: int.from_bytes(x, 'little')
COMMAND, EVENT, SOURCE_MAGIC = map(MAGIC, (b'HIAQFC01', b'HIAQFE01', b'HIASIL01'))
BAD, MAX = 0xfffffffd, (1 << 64) - 1
CANARY = b'\xd6' * 32


def lease(raw, index):
    assert type(raw) is bytes and type(index) is bytes
    at = (64 + len(raw) + 7) & ~7
    assert len(index) == (len(raw) + 7) // 8
    return (struct.pack('<8Q', SOURCE_MAGIC, len(raw), len(index), 64, at, at + len(index), 0, 0)
            + raw + bytes(at - 64 - len(raw)) + index)


def command(action=1, *, lease_id=1, request=1, sequence=0):
    return struct.pack('<8Q', COMMAND, action, lease_id, request, sequence, 0, 0, 0)


class ActualFacts:
    def __init__(self, manifest, destination):
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            if path in self.pins and raw != self.pins[path]:
                raise AssertionError('source identity changed')
            self.pins[path] = raw
            return raw
        manifest = Path(manifest).resolve()
        data = json.loads(read(manifest))
        source, image = read(data['source_path']), read(data['image_path'])
        assert data['source_sha256'] == sha256(source).hexdigest()
        assert data['image_sha256'] == sha256(image).hexdigest()
        assert data['compiler_sha256'] == '35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
        self.destination = Path(destination)
        self.destination.mkdir(parents=True, exist_ok=False)
        (self.destination / 'source.hiaasm').write_bytes(source)
        (self.destination / 'image.bin').write_bytes(image)
        (self.destination / 'manifest.json').write_bytes(self.pins[manifest])
        self.native = NativeHiaJsonImage(image, sha256(image).hexdigest())
        self.entries = 0
        self.log = (self.destination / 'entries.jsonl').open('w')
        self.sources = set()

    def call(self, label, cmd, source, before):
        assert all(type(x) is bytes for x in (cmd, source, before))
        src = ctypes.create_string_buffer(source + CANARY)
        ctl = ctypes.create_string_buffer(cmd + CANARY)
        work = ctypes.create_string_buffer(before + CANARY)
        result = self.native._entry(ctl, len(cmd), src, len(source), work, len(before))
        self.entries += 1
        after = ctypes.string_at(work, len(before))
        assert ctypes.string_at(ctl, len(cmd) + len(CANARY)) == cmd + CANARY
        assert ctypes.string_at(src, len(source) + len(CANARY)) == source + CANARY
        assert ctypes.string_at(ctypes.addressof(work) + len(before), len(CANARY)) == CANARY
        prefix = f'{self.entries:06d}'
        source_sha = sha256(source).hexdigest()
        if source_sha not in self.sources:
            (self.destination / ('source-' + source_sha + '.lease')).write_bytes(source)
            self.sources.add(source_sha)
        for suffix, value in (('command', cmd), ('before', before), ('after', after)):
            (self.destination / (prefix + '.' + suffix + '.bin')).write_bytes(value)
        row = {'case': label, 'entry': self.entries, 'prefix': prefix, 'return': result,
               'source_sha256': source_sha, 'source_bytes': len(source),
               'command_sha256': sha256(cmd).hexdigest(), 'command_bytes': len(cmd),
               'workspace_bytes': len(before), 'before_sha256': sha256(before).hexdigest(),
               'after_sha256': sha256(after).hexdigest(), 'input_and_canaries_unchanged': True,
               'event': struct.unpack_from('<16Q', after, 256) if len(after) >= 384 else None}
        self.log.write(json.dumps(row, sort_keys=True) + '\n')
        self.log.flush()
        return result, after

    def run(self, label, source, *, request=1, initial_size=512, compare=None):
        cmd, before = command(request=request), bytes(initial_size)
        while True:
            result, after = self.call(label, cmd, source, before)
            if compare is not None:
                assert (result, after) == compare(cmd, source, before), label
            event = struct.unpack_from('<16Q', after, 256)
            if result == BAD or event[1] != 1:
                return result, event, after
            assert result == 384 and event[0] == EVENT and event[5] > len(after)
            before = after + bytes(event[5] - len(after))
            cmd = command(2, request=request, sequence=event[4])

    def close(self):
        self.log.close()
        assert all(path.read_bytes() == raw for path, raw in self.pins.items())
        (self.destination / 'custody.json').write_text(json.dumps({
            'scope': 'DEVELOPMENT_ACTUAL_FACTS_ONLY_NOT_WHOLE_QUERY_OR_COLD',
            'entries': self.entries, 'full_buffers_saved': True,
            'source_and_image_unchanged': True,
            'pins': {str(p): sha256(raw).hexdigest() for p, raw in self.pins.items()},
        }, indent=2, sort_keys=True) + '\n')


def vm_call(checked, cmd, source, before):
    from hepta.hia_program_runtime import _Machine, _Owner, _View
    owners = [_Owner(-1, bytearray(cmd)), _Owner(-2, bytearray(source)), _Owner(-3, bytearray(before))]
    machine = _Machine(checked, 10_000_000, 256 << 20, None, 256)
    result = machine.invoke(checked.as_dict()['functions'][0],
                           [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
    assert bytes(owners[0].data) == cmd and bytes(owners[1].data) == source
    assert machine.loans_started == machine.loans_ended
    return result, bytes(owners[2].data)
