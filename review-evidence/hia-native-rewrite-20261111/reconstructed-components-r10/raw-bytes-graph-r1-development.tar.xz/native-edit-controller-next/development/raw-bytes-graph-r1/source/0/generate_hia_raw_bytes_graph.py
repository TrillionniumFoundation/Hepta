"""HIA exact-byte Graph issuer for the fixed native edit frontend.

No decoding or caller policy is performed here. The exact raw view, including
invalid UTF-8 and empty bytes, reaches the proper later native input gate.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_apply_graph as helpers
CONSTANTS={'COMMAND':int.from_bytes(b'HIABGC01','little'),'STATE':int.from_bytes(b'HIABGW01','little'),
           'EVENT':int.from_bytes(b'HIABGE01','little'),'GRAPH':int.from_bytes(b'HIAGRF01','little'),
           'BAD':0xfffffffd,'MAX':(1<<64)-1}
BODY=r'''
def bytes_graph(s:readbuf, c:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) == 2:
        return invalid(w, 1)
    if length(c) != 64 or word(c, 0) != COMMAND or word(c, 16) == 0 or word(c, 24) == 0:
        return invalid(w, 2)
    if word(c, 40) != 0 or word(c, 48) != 0 or word(c, 56) != 0 or length(s) > MAX - 1152:
        return invalid(w, 3)
    if get(w, 8) == 0:
        if word(c, 8) != 1 or word(c, 32) != 0:
            return invalid(w, 4)
        at = 0
        while at < 1024:
            if byte(w, at) != 0:
                return invalid(w, 5)
            at = at + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(c, 16))
        put(w, 24, word(c, 24))
        put(w, 40, length(s))
        put(w, 48, 1152 + length(s))
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or word(c, 8) != 2:
            return invalid(w, 6)
        if word(c, 16) != get(w, 16) or word(c, 24) != get(w, 24) or word(c, 32) != get(w, 32) or length(s) != get(w, 40):
            return invalid(w, 7)
    if length(w) < get(w, 48):
        return event(w, 1)
    fill_range(w, 1024, 128, 0)
    put(w, 1024, GRAPH)
    put(w, 1032, get(w, 16))
    put(w, 1040, 1)
    put(w, 1048, 1)
    put(w, 1064, length(s))
    put(w, 1072, 128 + length(s))
    put(w, 1088, 9)
    put(w, 1096, 128)
    put(w, 1104, length(s))
    copy_bytes(w, s, 1152, 0, length(s))
    put(w, 8, 2)
    return event(w, 0)

def event(w:mutbuf, action:u64) -> u32:
    if get(w, 32) == MAX:
        put(w, 8, 3)
        return BAD
    put(w, 32, get(w, 32) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 48))
    put(w, 304, 1024)
    put(w, 312, 128 + get(w, 40))
    put(w, 320, get(w, 56))
    at = 328
    while at < 384:
        put(w, at, 0)
        at = at + 8
    return 384

def invalid(w:mutbuf, reason:u64) -> u32:
    put(w, 8, 3)
    put(w, 56, reason)
    event(w, 3)
    return BAD
'''
def source_program():
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
    own=Expand().visit(ast.parse(BODY)).body;old={n.name:n for n in ast.parse(helpers.source_program()).body}
    return ast.unparse(ast.fix_missing_locations(ast.Module(body=own+[old[n] for n in ('word','get','put')],type_ignores=[])))+'\n'
def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['bytes_graph']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        b=shared.CopyBuilder(node,names,signatures,total);b.statements(node.body)
        functions.append({'name':names[node.name],'params':[b.param(v) for v in b.params],'returns':[b.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':b.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_raw_bytes_graph','functions':functions})
if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_raw_bytes_graph.hiaasm';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
