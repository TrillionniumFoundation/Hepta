"""Fixed mechanical native peer forwarding and complete content-addressed logs."""
import ctypes
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
from hepta.hia_json_preflight_native import NativeHiaJsonImage

DEV=Path(__file__).resolve().parent
MAGIC=lambda value:int.from_bytes(value,'little')
EVENT=MAGIC(b'HIAQWE01');REPLY=MAGIC(b'HIAQWR01');RESULT=MAGIC(b'HIAQWO01')
CANARY=b'\xb7'*32;BAD=0xfffffffd

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value

def command(graph,policy,*,digits=4300,request=1):
    root=struct.unpack_from('<Q',graph,24)[0]
    return struct.pack('<8Q',MAGIC(b'HIAQWC01'),101,request,root,policy,digits,0,0)

class Evidence:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False);(self.out/'raw').mkdir()
        self.log=(self.out/'entries.jsonl').open('w');self.entries=0;self.saved=set()
    def raw(self,value):
        key=sha256(value).hexdigest()
        if key not in self.saved:(self.out/'raw'/key).write_bytes(value);self.saved.add(key)
        return dict(sha256=key,bytes=len(value))
    def record(self,label,source,second,before,after,code,**extra):
        self.entries+=1
        row=dict(entry=self.entries,case=label,source=self.raw(source),second=self.raw(second),
                 before=self.raw(before),after=self.raw(after),return_code=code,**extra)
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
    def close(self):self.log.close()

class Actual(Evidence):
    def __init__(self,manifest,out):
        super().__init__(out);self.pins={}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes();self.pins[path]=raw;return raw
        row=json.loads(read(manifest));source=read(row['source_path']);image=read(row['image_path'])
        assert sha256(source).hexdigest()==row['source_sha256'] and sha256(image).hexdigest()==row['image_sha256']
        assert row['compiler_sha256']=='35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
        self.native=NativeHiaJsonImage(image,row['image_sha256'])
    def call(self,label,graph,control,before):
        a=ctypes.create_string_buffer(graph+CANARY);b=ctypes.create_string_buffer(control+CANARY);w=ctypes.create_string_buffer(before+CANARY)
        code=int(self.native._entry(a,len(graph),b,len(control),w,len(before)))
        after=ctypes.string_at(w,len(before))
        assert ctypes.string_at(a,len(graph)+32)==graph+CANARY
        assert ctypes.string_at(b,len(control)+32)==control+CANARY
        assert ctypes.string_at(ctypes.addressof(w)+len(before),32)==CANARY
        self.record(label,graph,control,before,after,code,inputs_and_canaries_unchanged=True)
        return code,after
    def close(self):
        super().close();assert all(path.read_bytes()==raw for path,raw in self.pins.items())
        (self.out/'custody.json').write_text(json.dumps(dict(entries=self.entries,pins={str(p):sha256(v).hexdigest() for p,v in self.pins.items()},unchanged=True),indent=2,sort_keys=True)+'\n')

class Peers:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False)
        render=DEV.parent/'native-agent-edit-render-next/development'
        self.wm=module('bounded_actual_graph_wire',render/'graph_harness_r3.py')
        self.dm=module('bounded_actual_edit_decode',render/'edit_decode_harness_r2.py')
        self.wire=self.wm.Actual(self.out/'wire')
        self.decode=self.dm.Actual(self.out/'decode')
        self.raw=Evidence(self.out/'wire-workspaces')
    def wire_run(self,source,control,initial,lease,request,label):
        size=initial;w=ctypes.create_string_buffer(size+32)
        ctypes.memset(ctypes.addressof(w)+size,0xb9,32);role='scan'
        while True:
            before=ctypes.string_at(w,size)
            code,event=self.wire.call(role,source,control,w,size,label)
            after=ctypes.string_at(w,size)
            self.raw.record(label,source,control,before,after,code,role=role)
            assert code==128
            if event[1]==1:
                assert event[10]>size
                n=max(size*2,event[10]);new=ctypes.create_string_buffer(n+32)
                ctypes.memmove(new,w,size);ctypes.memset(ctypes.addressof(new)+n,0xb9,32);w=new;size=n
            elif event[1]==2:
                assert role=='scan' and event[13]==2;role='emit'
            else:
                assert event[1] in (0,3)
                return struct.pack('<8Q',REPLY,lease,request,1,code,size,0,0)+after
    def raw_decoder(self,raw,config,osize,wsize,lease,request,label):
        dm=self.dm;s=dm.buffer(raw);o=dm.workspace(osize);w=dm.workspace(wsize)
        ctypes.memmove(ctypes.addressof(w)+48,config,len(config));before=ctypes.string_at(w,wsize)
        code=int(self.decode.images['decoder']._entry(s,len(raw),o,osize,w,wsize));self.decode.entries['decoder']+=1
        assert ctypes.string_at(s,len(raw)+32)==raw+dm.CANARY
        for buf,n in ((o,osize),(w,wsize)):assert ctypes.string_at(ctypes.addressof(buf)+n,32)==dm.CANARY
        output=ctypes.string_at(o,osize)
        self.decode.record(dict(case=label,role='decoder',return_code=code,source=self.decode.raw(raw),config=self.decode.raw(config),
            output=self.decode.raw(output),before=self.decode.raw(before),after=self.decode.raw(ctypes.string_at(w,wsize)),
            inputs_and_canaries_unchanged=True))
        return struct.pack('<8Q',dm.REPLY,lease,request,1,code,osize,0,0)+output
    def arena_graph(self,arena,control,initial,lease,request,label):
        dm=self.dm;size=initial;w=dm.workspace(size)
        while True:
            a=dm.buffer(arena);c=dm.buffer(control);before=ctypes.string_at(w,size)
            code=int(self.decode.images['graph']._entry(a,len(arena),c,len(control),w,size));self.decode.entries['graph']+=1
            assert ctypes.string_at(a,len(arena)+32)==arena+dm.CANARY
            assert ctypes.string_at(c,len(control)+32)==control+dm.CANARY
            assert ctypes.string_at(ctypes.addressof(w)+size,32)==dm.CANARY
            after=ctypes.string_at(w,size);event=struct.unpack_from('<16Q',after)
            self.decode.record(dict(case=label,role='graph',return_code=code,event=event,arena=self.decode.raw(arena),
                command=self.decode.raw(control),before=self.decode.raw(before),after=self.decode.raw(after),
                inputs_and_canaries_unchanged=True))
            assert code==128 and event[0]==dm.GRAPH_EVENT
            if event[1]!=1:return struct.pack('<8Q',dm.REPLY,lease,request,2,code,size,0,0)+after
            assert event[4]>size
            n=max(size*2,event[4]);new=dm.workspace(n);ctypes.memmove(new,w,size);w=new;size=n
    def decode_run(self,raw,control,initial,lease,request,label):
        dm=self.dm;size=initial;w=dm.workspace(size)
        while True:
            code,event=self.decode.invoke(raw,control,w,size,label)
            assert code==128 and event[0]==dm.EVENT
            if event[1]==1:
                assert event[5]>size
                n=max(size*2,event[5]);new=dm.workspace(n);ctypes.memmove(new,w,size);w=new;size=n
            elif event[1]==2:
                start,length=event[7:9];offset,extent=event[9:11]
                assert offset<=size and extent<=size-offset
                cmd=ctypes.string_at(ctypes.addressof(w)+offset,extent)
                if event[6]==1:
                    assert start<=len(raw) and length<=len(raw)-start
                    control=self.raw_decoder(raw[start:start+length],cmd,event[11],event[12],lease,request,label)
                else:
                    assert event[6]==2 and start<=len(control) and length<=len(control)-start
                    control=self.arena_graph(control[start:start+length],cmd,event[12],lease,request,label)
            else:
                assert event[1] in (0,3)
                return struct.pack('<8Q',REPLY,lease,request,2,code,size,0,0)+ctypes.string_at(w,size)
    def close(self):self.wire.close();self.decode.close();self.raw.close()

def run(call,peers,label,graph,control,*,observe=None):
    before=bytes(1024);entries=0;calls=[]
    while True:
        code,after=call(label,graph,control,before);entries+=1
        if observe is not None:observe.append((graph,control,before,code,after))
        event=struct.unpack_from('<16Q',after)
        assert code==128 and event[0]==EVENT,(label,code,event)
        if event[1]==1:
            assert event[5]>len(after);before=after+bytes(event[5]-len(after));continue
        if event[1]==2:
            peer=event[6];source=graph if event[7]==0 else after
            start,size=event[8:10];at,n=event[10:12]
            assert start<=len(source) and size<=len(source)-start and at<=len(after) and n<=len(after)-at
            calls.append(peer)
            if peer==1:control=peers.wire_run(source[start:start+size],after[at:at+n],event[12],event[2],event[3],label)
            else:
                assert peer==2
                control=peers.decode_run(source[start:start+size],after[at:at+n],event[12],event[2],event[3],label)
            before=after;continue
        assert event[1] in (0,3) and event[14]==1024 and event[15]==96
        result=struct.unpack_from('<12Q',after,event[14]);assert result[0]==RESULT
        raw=after[result[5]:result[5]+result[6]]
        normalized=after[result[7]:result[7]+result[8]]
        error=after[result[9]:result[9]+result[10]].decode('utf8') if event[1]==3 else None
        return dict(event=event,result=result,raw=raw,graph=normalized,error=error,entries=entries,peers=calls,workspace=after)
