from pathlib import Path
import json, traceback, time
from hepta.hia_program_composite import _Types
from hepta.hia_composite_types_native import NativeCompositeTypeSession, installed_composite_types
from tests.test_hia_partial_record import record, ref, partial
ROOT=Path('/workspace/scratch/623459b0e1bc/types-native-development')
image=installed_composite_types(ROOT/'manifest.json')
rows=[]
def construct(cls,*args,**kwargs):
 obj=cls.__new__(cls)
 try:
  cls.__init__(obj,*args,**kwargs);exc=None
 except Exception as e:exc=e
 return obj,exc

def init_case(name,definitions,recursive_chain=True,partial_records=True):
 old,oe=construct(_Types,definitions,recursive_chain=recursive_chain,partial_records=partial_records)
 native,ne=construct(NativeCompositeTypeSession,image,definitions,recursive_chain=recursive_chain,partial_records=partial_records)
 om={'cache_count':len(old.cache),'active_count':len(old.active),'partial_declaration_steps':old.partial_declaration_steps} if hasattr(old,'cache') else None
 nm=getattr(native,'_observations',None)
 oc=getattr(oe,'code',type(oe).__name__) if oe else None
 nc=getattr(ne,'code',type(ne).__name__) if ne else None
 row={'name':name,'old_error':str(oe) if oe else None,'native_error':str(ne) if ne else None,'old':om,'native':nm}
 rows.append(row)
 assert oc==nc,(name,oc,nc,row)
 if om is not None:assert om==nm,(name,om,nm,row)
 print('PASS',name,oc,om,flush=True)
 native.close()

for v in range(1,5):
 init_case('empty-v'+str(v),[],v>=2,v>=3)
 init_case('unused-enum-loan-v'+str(v),[{'kind':'enum','name':'Maybe','params':[],'variants':[{'name':'borrowed','fields':[{'name':'x','type':'readbuf'}]}]}],v>=2,v>=3)

for loan in ('u8','buffer','readbuf','mutbuf'):
 init_case('generic-known-'+loan,[record('Box',[('value','T'),('extra',loan)],['T']),record('Unused',[('p',partial(ref('Box','U')))],['U'])])
 init_case('generic-substitution-'+loan,[record('Inner',[('value','T'),('extra',loan)],['T']),record('Box',[('inside',ref('Inner','U'))],['U']),record('Unused',[('p',partial(ref('Box','V')))],['V'])])
 init_case('unused-concrete-'+loan,[record('Box',[('value',loan)]),record('Unused',[('p',partial('Box'))])])

for levels in (0,1,2,4,8,16,30):
 nested='U'
 for _ in range(levels):nested=ref('Repeated',nested)
 definitions=[record('Repeated',[('f'+str(i),'T') for i in range(4)],['T']),record('Unused',[('p',partial(nested))],['U'])]
 init_case('repeated-symbolic-'+str(levels),definitions)

for levels in (1,3,6,8):
 definitions=[record('Wrap'+str(i),[('value','T')],['T']) for i in range(4)]
 for level in range(levels):definitions.append(record('Level'+str(level),[('f'+str(i),ref('Level'+str(level+1),ref('Wrap'+str(i),'T'))) for i in range(4)],['T']))
 definitions += [record('Level'+str(levels),[('value','T')],['T']),record('Unused',[('p',partial(ref('Level0','U')))],['U'])]
 init_case('distinct-symbolic-'+str(levels),definitions)

for nest in (1,8,16,25):
 nested='T'
 for _ in range(nest):nested=ref('Wrap',nested)
 definitions=[record('Wrap',[('value','T')],['T'])]
 for level in range(3):definitions.append(record('Layer'+str(level),[('value',ref('Layer'+str(level+1),nested))],['T']))
 definitions += [record('Layer3',[('value','T')],['T']),record('Unused',[('p',partial(ref('Layer0','U')))],['U'])]
 init_case('symbolic-lexical-depth-'+str(nest),definitions)

for initialized in ([],['x'],['x','y'],['y'],['y','x'],['x','x'],['bad']):
 init_case('concrete-partial-'+repr(initialized),[record('Pair',[('x','buffer'),('y','u8')]),record('Unused',[('p',{'partial':'Pair','initialized':initialized})])])

(ROOT/'kernel-differential.json').write_text(json.dumps({'scope':'development real native image / Python reference differential','count':len(rows),'rows':rows},indent=2)+'\n')
print('ALL PASS',len(rows),flush=True)
