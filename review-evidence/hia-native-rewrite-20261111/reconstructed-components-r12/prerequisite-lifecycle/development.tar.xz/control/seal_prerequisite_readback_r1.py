"""Freeze only actually received prerequisite controls and summary originals."""
from pathlib import Path
from hashlib import sha256
import io
import json
import stat
import tarfile

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
CONTROL = BASE/'v67-qualification-control'
OUT = BASE/'prerequisite-lifecycle-readback-r1'
SOURCE = Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-workflow-qualified')


def read(path):
    before = path.lstat(); assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    raw = path.read_bytes(); after = path.lstat()
    sig = lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert sig(before) == sig(after) and len(raw) == before.st_size
    return raw,before


def payload(path):
    sdk = json.loads(read(path)[0])
    value = sdk.get('structuredContent')
    if value is None:
        for item in sdk.get('content',[]):
            if item.get('type') == 'text':
                try:value=json.loads(item['text']);break
                except ValueError:pass
    return sdk,value


after_raw,_ = read(CONTROL/'prerequisite-after.stdout.log')
assert len(after_raw) == 8038
after = json.loads(after_raw)
assert after['expected_bindings'] == 710 and after['matching_stable'] == 698
assert len([r for r in after['changed_or_unavailable'] if r.get('error')]) == 3
assert after['report_bytes'] == 2839390 and after['report_sha256'] == 'f4b1586c00f00f939aedcbbde7f2b76304f2ba8848848f9096e3a13b8027bf2d'
sdk,authority = payload(CONTROL/'prerequisite-after-reconcile2.raw.json')
assert not sdk.get('isError') and authority['reused'] is True
assert authority['job']['id'] == '1a1cb1aacb6-2564-a00'
assert authority['job']['request_digest'] == 'cfde5fef036ad2aa3020c27ecdd0c56b9700847e3c2f6105f3cbfdc71bcdea33'
status = authority['status']
assert status['state'] == 'succeeded' and status['exit_code'] == 0 and status['output_complete'] and status['output_durable']
assert status['terminal_publication_confirmed'] and not status['timed_out'] and not status['cancelled']
window_raw,_ = read(CONTROL/'prerequisite-window-summary.original.json')
assert len(window_raw) == 31419 and sha256(window_raw).hexdigest() == 'e0158983359f0ecd34644f52e5bbe38b74dc55aee5ebd10957130241af813c6e'
window = json.loads(window_raw)
assert (window['matching_regular_bindings'],window['missing_regular_count'],window['explicit_symlink_count'],window['matching_stable_symlink_targets']) == (698,3,9,9)
assert window['report_bytes'] == 128123 and window['report_sha256'] == '67e14bead70ba5bb1fd768d3795ef772f7814cba573113963fd52d2fe73713b2'
assert sum(g['count'] for g in after['exception_chain_groups'] if g['category'] == 'errors') == 187
assert sum(g['count'] for g in after['exception_chain_groups'] if g['category'] == 'failures') == 1
for group in after['exception_chain_groups']:
    if group['category'] in ('errors','failures'):
        assert any(line.startswith('FileNotFoundError: [Errno 2]') for line in group['original_exception_lines'])

names = ['environment.json','preparation.json','full-final-authority-status.json',
         'prerequisite-lifecycle-static-facts.json','observe_prerequisites_after_v67.py',
         'prerequisite-after-observation.request.json','prerequisite-after-observation.pin.json',
         'prerequisite-after-start.raw.json','prerequisite-after-reconcile.raw.json','prerequisite-after-reconcile2.raw.json',
         'prerequisite-after-summary-read0.raw.json','prerequisite-after-page-host-reset.json',
         'prerequisite-after-read0.raw.json','prerequisite-after.stdout.log','prerequisite-after.stderr.log','prerequisite-after-summary.json',
         'derive_prerequisite_window_v67.py','prerequisite-window.request.json','prerequisite-window.pin.json',
         'prerequisite-window-start.raw.json','prerequisite-window-read0.raw.json','prerequisite-window-summary-batch.raw.json',
         'prerequisite-window-summary.original.json','prerequisite-window-summary.readback.json',
         'cleanup-source-search.txt','seal_prerequisite_readback_r1.py']
window_status = 'NOT_YET_RECEIVED'
if (CONTROL/'prerequisite-window-status.raw.json').exists():
    names.append('prerequisite-window-status.raw.json')
    sdk,p = payload(CONTROL/'prerequisite-window-status.raw.json')
    if not sdk.get('isError') and p:
        s = p.get('status',p)
        window_status = s.get('state','UNRECOGNIZED_RETURNED_SHAPE')

OUT.mkdir(exist_ok=False)
source_names = ['review-evidence/hia-native-rewrite-20261111/prepare_remote_qualification_v2.py',
                'review-evidence/hia-native-rewrite-20261111/run_hia_qualification_v3.py',
                'review-evidence/hia-native-rewrite-20261111/workflow_process.py',
                'tests/test_hia_ndu_bridge.py','tests/test_hia_ndu_raw_session.py','tests/test_hia_optimization_cli.py']
paths = [('control/'+n,CONTROL/n) for n in names] + [('source/'+n,SOURCE/n) for n in source_names]
summary = {'schema':'hia.v67.prerequisite-lifecycle-completed-readback.v1',
           'qualification':{'job_id':'1a1cab94f66-2564-82c','source':'0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5',
                            'status':'HOLD','tests':4157,'errors':187,'failures':1,'skips':18},
           'after_observation':{'job_id':authority['job']['id'],'key':authority['job']['idempotency_key'],
                                'request_digest':authority['job']['request_digest'],'terminal':'succeeded/exit0',
                                'stdout_bytes':8038,'stdout_sha256':sha256(after_raw).hexdigest()},
           'current_binding_evidence':{'expected':710,'regular_files_original_sha_equal_and_stable_during_read':698,
                                       'explicit_symlink_target_original_sha_equal_and_stable_during_read':9,
                                       'missing_ndu_regular_binaries':3},
           'exception_chain_evidence':'All 187 error traces and the one failure trace directly contain ENOENT for the three original NDU paths. Skip reasons are retained; the four conjunctive Z3/NDU skips do not isolate the failing conjunct.',
           'directory_metadata_window_utc':['2026-11-11T13:14:56.527978Z','2026-11-11T13:14:56.921501Z'],
           'time_relationship':'Three prerequisite parent directory mtime/ctime observations fall within original native-applications log file times 13:13:52.985250Z to 13:16:44.776200Z. This is temporal correlation, not proof that the suite or any particular process removed targets.',
           'deleting_or_replacing_actor':'UNKNOWN',
           'window_observation':{'job_id':'1a1cb354d05-2564-a66','request_digest':'65e680a0dcf0b115b1d5d3acea778c27d8cab32a3fb40d1a99696d1f1407f8dc',
                                 'summary_file_bytes':31419,'summary_file_sha256':sha256(window_raw).hexdigest(),
                                 'status_readback':window_status,'summary_scope':'Complete original regular file readback; not substituted as process stdout.'},
           'remote_complete_reports_not_in_this_local_package':[
               {'path':after['report_path'],'bytes':after['report_bytes'],'sha256':after['report_sha256'],'durable_mirror':after['durable_path']},
               {'path':window['report_path'],'bytes':window['report_bytes'],'sha256':window['report_sha256'],'durable_mirror':window['durable_path']}],
           'original_qualification_archive_transfer':{'total_bytes':666816,'verified_local_bytes':65536,'scope':'incomplete transfer deliberately excluded; original remote seal remains intact'},
           'actions':{'qualification_rerun':False,'prerequisite_restore_or_rebuild':False,'original_source_or_results_modified':False},
           'scope':'Only actually received original controls, bytes, source pins, timeout records and independent summary files. This is diagnostic evidence, not qualification success or a completed full-archive transfer.'}
summary_raw = (json.dumps(summary,sort_keys=True,indent=2)+'\n').encode()
(OUT/'summary.json').write_bytes(summary_raw)
paths.append(('DERIVED-SCOPE.json',OUT/'summary.json'))
paths.sort(); members = []
for name,path in paths:
    raw,s = read(path)
    members.append({'name':name,'original':str(path),'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(s.st_mode),
                    'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns})
custody = {'schema':'hia.v67.prerequisite-lifecycle-custody.v1','members':members,
           'original_files':len(members),'original_bytes':sum(m['bytes'] for m in members),'scope':summary['scope']}
custody_raw = (json.dumps(custody,sort_keys=True,indent=2)+'\n').encode();(OUT/'custody.json').write_bytes(custody_raw)
archive = OUT/'ndu-prerequisite-lifecycle-readback-r1.tar.xz'
with tarfile.open(archive,'w:xz',preset=1) as tar:
    for m in members:
        raw,s = read(Path(m['original'])); assert len(raw) == m['bytes'] and sha256(raw).hexdigest() == m['sha256']
        item = tarfile.TarInfo(m['name']);item.size=len(raw);item.mode=m['mode'];tar.addfile(item,io.BytesIO(raw))
    item=tarfile.TarInfo('CUSTODY.json');item.size=len(custody_raw);item.mode=0o600;tar.addfile(item,io.BytesIO(custody_raw))
with tarfile.open(archive) as tar:
    assert tar.getnames() == [m['name'] for m in members]+['CUSTODY.json']
    for m in members:
        item=tar.getmember(m['name']);raw=tar.extractfile(item).read();live,s=read(Path(m['original']))
        assert item.isfile() and item.mode == m['mode'] and raw == live and len(raw) == m['bytes'] and sha256(raw).hexdigest() == m['sha256']
        assert (s.st_dev,s.st_ino,s.st_mtime_ns,s.st_ctime_ns) == (m['device'],m['inode'],m['mtime_ns'],m['ctime_ns'])
    assert tar.extractfile('CUSTODY.json').read() == custody_raw
raw,_=read(archive)
receipt={'status':'ALL_SELECTED_MEMBERS_REPLAYED','archive':str(archive),'archive_bytes':len(raw),'archive_sha256':sha256(raw).hexdigest(),
         'custody':str(OUT/'custody.json'),'custody_bytes':len(custody_raw),'custody_sha256':sha256(custody_raw).hexdigest(),
         'members':len(members)+1,'original_raw_bytes':custody['original_bytes'],'scope':summary['scope']}
(OUT/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt,sort_keys=True),flush=True)
