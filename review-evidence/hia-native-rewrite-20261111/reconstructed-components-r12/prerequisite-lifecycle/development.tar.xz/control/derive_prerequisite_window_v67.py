"""Read immutable after-observation and explicit originally pinned tool targets.

Create a separate diagnostic only. No source, prerequisite, qualification,
mount, process or environment is changed or executed by this script.
"""
from pathlib import Path
from hashlib import sha256
import json
import os
import stat

BASE = Path('/var/tmp/hia9acdfa-v67-0ef9541b')
ORIGINAL = BASE/'diagnostics/prerequisites-after-01/observation.json'
EXPECTED = 'f4b1586c00f00f939aedcbbde7f2b76304f2ba8848848f9096e3a13b8027bf2d'
OUT = BASE/'diagnostics/prerequisite-window-01'
DURABLE = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia9acdfa-v67-0ef9541b-evidence/diagnostics/prerequisite-window-01')


def metadata(s):
    return {'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),
            'kind':stat.S_IFMT(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'links':s.st_nlink,
            'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}


raw = ORIGINAL.read_bytes()
assert len(raw) == 2839390 and sha256(raw).hexdigest() == EXPECTED
data = json.loads(raw)
assert data['expected_bindings'] == 710
ancestors = {}
for name, record in data['ndu_binary_ancestors'].items():
    items = []
    for item in record['ancestors']:
        row = {k:v for k,v in item.items() if k != 'immediate_entries'}
        entries = item.get('immediate_entries')
        if entries is not None:
            row['immediate_entry_count'] = len(entries)
            if Path(item['path']).name == 'evidence':
                row['selected_entries_only'] = [n for n in entries if n in (
                    'core-controls-ndu-dynamic-prerequisite-01',
                    'core-controls-ndu-original-prerequisite-01',
                    'core-retained-ndu-raw-model-prerequisite-01')]
                row['scope'] = 'all immediate names remain in original observation; this derivative includes the three pinned prerequisite directories only'
            else:
                row['immediate_entries'] = entries
        items.append(row)
    ancestors[name] = {'file':record['file'],'ancestors':items}

links = []
for old in data['changed_or_unavailable']:
    if 'symlink_target' not in old:
        continue
    path = Path(old['path'])
    row = {'path':str(path),'original_symlink_observation':old,'expected_sha256':old['expected_sha256']}
    try:
        before = path.lstat()
        assert stat.S_ISLNK(before.st_mode)
        target = os.readlink(path)
        resolved = path.resolve(strict=True)
        fd = os.open(resolved, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as stream:
            opened = os.fstat(stream.fileno())
            assert stat.S_ISREG(opened.st_mode)
            digest = sha256(); count = 0
            while True:
                block = stream.read(1024*1024)
                if not block:
                    break
                count += len(block); digest.update(block)
            ended = os.fstat(stream.fileno())
        after = path.lstat()
        row.update(current_link_before=metadata(before),current_link_after=metadata(after),
                   symlink_target=target,resolved_path=str(resolved),target_before=metadata(opened),
                   target_after=metadata(ended),read_bytes=count,actual_sha256=digest.hexdigest(),
                   original_link_metadata_equal=metadata(before)==old['before'],
                   stable_link_and_target=metadata(before)==metadata(after) and metadata(opened)==metadata(ended)
                       and path.resolve(strict=True)==resolved and os.readlink(path)==target,
                   hash_matches_original=old['expected_sha256']==digest.hexdigest())
    except BaseException as exc:
        row['error'] = {'type':type(exc).__name__,'message':str(exc),'errno':getattr(exc,'errno',None)}
    links.append(row)

stages = []
for item in data['original_stage_files']:
    step = item['recorded_step']
    stages.append({'name':item['name'],
                   'recorded_step':{k:step[k] for k in ('returncode','timeout','seconds') if k in step},
                   'files':item['files']})

result = {'schema':'hia.v67.prerequisite-window-derivative.v1',
          'scope':'after metadata and original-stage file observations; no deleting-actor attribution and no rerun',
          'original_observation':{'path':str(ORIGINAL),'bytes':len(raw),'sha256':EXPECTED,
                                  'started_unix_ns':data['started_unix_ns'],'ended_unix_ns':data['ended_unix_ns']},
          'binary_ancestors':ancestors,'explicit_pinned_symlink_targets':links,
          'original_stage_file_observations':stages,
          'missing_regular_bindings':[r for r in data['changed_or_unavailable'] if r.get('error')],
          'matching_regular_bindings':710-len(data['changed_or_unavailable'])}
summary = {'kind':'V67_PREREQUISITE_WINDOW_READ_ONLY',
           'missing_regular_count':len(result['missing_regular_bindings']),
           'matching_regular_bindings':result['matching_regular_bindings'],
           'explicit_symlink_count':len(links),
           'matching_stable_symlink_targets':sum(bool(r.get('hash_matches_original') and r.get('stable_link_and_target')) for r in links),
           'binary_ancestor_metadata':[{ 'binary':n,
              'ancestors':[{k:v for k,v in r.items() if k in ('path','before','after','error','immediate_entry_count','immediate_entries')} for r in a['ancestors']]}
              for n,a in ancestors.items()],
           'original_stage_times':[{ 'name':r['name'],'recorded_step':r['recorded_step'],
               'files':[{'path':f['path'],'stat':f.get('before'),'error':f.get('error')} for f in r['files']]}
               for r in stages],
           'cause_attribution':'UNKNOWN; directory ctime/mtime does not name the actor or prove deletion rather than another namespace change',
           'report_path':str(OUT/'observation.json'),'durable_path':str(DURABLE/'observation.json')}
record = (json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
summary.update(report_bytes=len(record),report_sha256=sha256(record).hexdigest())
compact = (json.dumps(summary,sort_keys=True,separators=(',',':'))+'\n').encode()
assert not OUT.exists() and not DURABLE.exists()
assert DURABLE.parent.parent.stat().st_dev == 2049
for directory in (OUT,DURABLE):
    directory.mkdir(parents=True,mode=0o700,exist_ok=False)
    for name,value in (('observation.json',record),('summary.json',compact)):
        with (directory/name).open('xb') as stream:
            stream.write(value);stream.flush();os.fchmod(stream.fileno(),0o600);os.fsync(stream.fileno())
        assert (directory/name).read_bytes() == value
    fd = os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    try:os.fsync(fd)
    finally:os.close(fd)
print(compact.decode(),end='',flush=True)
