"""Read-only provenance observation after the terminal failed 0ef run.

Only new task-scoped diagnostic files are created. No dependency is rebuilt,
removed, restored, renamed, or executed. Qualification originals are read only.
"""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json
import os
import stat
import time

BASE = Path('/var/tmp/hia9acdfa-v67-0ef9541b')
OUT = BASE/'diagnostics/prerequisites-after-01'
DURABLE = Path('/run/media/qian-qi/TOSHIBA_DEV_1TB/hia9acdfa-v67-0ef9541b-evidence/diagnostics/prerequisites-after-01')
ENV_SHA = '08c6b342889fc9864a79686936de0f267e81604e4d9f445a00a3992576f32dd6'
RESULT_SHA = '95f77891c23becf71f6ab5d554f4be12e30ac14d3bd14f284ddf112788ab6a5f'


def metadata(info):
    return {'device':info.st_dev,'inode':info.st_ino,'mode':stat.S_IMODE(info.st_mode),
            'kind':stat.S_IFMT(info.st_mode),'bytes':info.st_size,'links':info.st_nlink,
            'uid':info.st_uid,'gid':info.st_gid,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns}


def observe(path, expected=None):
    row = {'path':str(path),'expected_sha256':expected,'observed_unix_ns':time.time_ns()}
    try:
        before=path.lstat();row['before']=metadata(before)
        if stat.S_ISREG(before.st_mode):
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
            with os.fdopen(fd,'rb') as stream:
                opened=os.fstat(stream.fileno());digest=sha256();count=0
                while True:
                    raw=stream.read(1024*1024)
                    if not raw:break
                    digest.update(raw);count+=len(raw)
                ended=os.fstat(stream.fileno())
            after=path.lstat();row['after']=metadata(after)
            row['stable_identity']=metadata(before)==metadata(opened)==metadata(ended)==metadata(after)
            row['read_bytes']=count;row['actual_sha256']=digest.hexdigest()
            row['matches_expected']=expected is None or expected==digest.hexdigest()
        elif stat.S_ISLNK(before.st_mode):
            row['symlink_target']=os.readlink(path);row['not_followed']=True
    except OSError as error:
        row['error']={'type':type(error).__name__,'errno':error.errno,'message':str(error)}
    return row


assert not OUT.exists() and not OUT.is_symlink()
OUT.mkdir(mode=0o700,parents=True,exist_ok=False)
started=time.time_ns()
env_raw=(BASE/'preparation/environment.json').read_bytes()
assert sha256(env_raw).hexdigest()==ENV_SHA
env=json.loads(env_raw);assert len(env['recheck_sha256'])==710
result_raw=(BASE/'qualification/full-retained-regression.json').read_bytes()
assert sha256(result_raw).hexdigest()==RESULT_SHA
result=json.loads(result_raw)
qualification=json.loads((BASE/'qualification/QUALIFICATION.json').read_bytes())
assert qualification['status']=='HOLD' and len(qualification['steps'])==28
observations=[observe(Path(path),wanted) for path,wanted in sorted(env['recheck_sha256'].items())]
changed=[row for row in observations if row.get('error') or not row.get('matches_expected',False) or not row.get('stable_identity',False)]

paths={}
for row in observations:
    if '/target/' in row['path'] and row['path'].endswith('hia-ndu-bridge'):
        path=Path(row['path']);ancestors=[]
        for parent in path.parents:
            if parent==Path('/home/qian-qi/.openclaw/workspaces/azi5/tasks/hia-selfhost-completion-20261109/evidence').parent:break
            item=observe(parent)
            if item.get('before',{}).get('kind')==stat.S_IFDIR:
                item['immediate_entries']=sorted(child.name for child in parent.iterdir())
            ancestors.append(item)
        paths[str(path)]={'file':row,'ancestors':ancestors}

causes=defaultdict(list)
for category in ('errors','failures','skipped','expected_failures','unexpected_successes'):
    for row in result[category]:
        text=row.get('traceback',row.get('reason','')) if isinstance(row,dict) else str(row)
        lines=[line for line in text.splitlines() if line.strip()]
        exceptions=[line for line in lines if line.startswith(('FileNotFoundError:','PermissionError:','OSError:','AssertionError:','hepta.'))]
        key=(category,tuple(exceptions) if exceptions else tuple(lines[-1:]))
        causes[key].append({'test':row.get('test') if isinstance(row,dict) else None,
                            'traceback_bytes':len(text.encode()),'traceback_sha256':sha256(text.encode()).hexdigest()})
groups=[{'category':category,'original_exception_lines':list(lines),'count':len(tests),'tests':tests}
        for (category,lines),tests in causes.items()]
stage_files=[]
for step in qualification['steps']:
    name=step['name']
    files=[observe(BASE/'qualification'/(name+suffix)) for suffix in ('.stdout.log','.stderr.log','.json')]
    stage_files.append({'name':name,'recorded_step':step,'files':files})
record={'schema':'hia.v67.prerequisite-after-observation.v1','scope':'current read-only observation after original HOLD; no inference of who removed paths, no restoration/rebuild/rerun',
        'started_unix_ns':started,'ended_unix_ns':time.time_ns(),'environment_original_sha256':ENV_SHA,
        'full_result_original_sha256':RESULT_SHA,'original_full_job':'1a1cab94f66-2564-82c',
        'expected_bindings':710,'observations':observations,'changed_or_unavailable':changed,
        'ndu_binary_ancestors':paths,'exact_exception_chain_groups':groups,'original_stage_files':stage_files}
summary={'kind':'V67_PREREQUISITE_AFTER_READ_ONLY','expected_bindings':710,'matching_stable':710-len(changed),
         'changed_or_unavailable':[{'path':row['path'],'expected_sha256':row['expected_sha256'],
                                    'actual_sha256':row.get('actual_sha256'),'error':row.get('error')} for row in changed],
         'exception_chain_groups':[{'category':g['category'],'count':g['count'],'original_exception_lines':g['original_exception_lines'],'first_test':g['tests'][0]['test']} for g in groups],
         'cause_attribution':'UNKNOWN unless independently evidenced; after metadata cannot identify the deleting actor',
         'report_path':str(OUT/'observation.json'),'durable_path':str(DURABLE/'observation.json')}
raw=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
summary['report_bytes']=len(raw);summary['report_sha256']=sha256(raw).hexdigest()
summary_raw=(json.dumps(summary,sort_keys=True,indent=2)+'\n').encode()
assert DURABLE.parent.parent.stat().st_dev==2049
DURABLE.mkdir(mode=0o700,parents=True,exist_ok=False)
for directory in (OUT,DURABLE):
    for name,data in (('observation.json',raw),('summary.json',summary_raw)):
        with (directory/name).open('xb') as stream:
            stream.write(data);stream.flush();os.fchmod(stream.fileno(),0o600);os.fsync(stream.fileno())
        assert (directory/name).read_bytes()==data
    fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    try:os.fsync(fd)
    finally:os.close(fd)
print(json.dumps(summary,sort_keys=True,separators=(',',':')),flush=True)
