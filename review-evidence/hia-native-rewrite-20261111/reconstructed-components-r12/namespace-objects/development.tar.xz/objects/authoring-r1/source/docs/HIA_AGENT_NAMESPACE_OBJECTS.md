# Native namespace object and result owner, revision 1

This is the next implementation layer below the complete ten-table / 31-operation
row owner. It implements transient cells, vectors, constants, projection,
builders, detached results, result cursors and logical retirement in HIA. It is
not a physical database, an index, a migration implementation, a selected public
owner, or a qualification result. The frozen comparison and SQLite 3.46.1
binary80 affinity images remain the scalar owners. Their source and evidence
are not changed by this revision.

## Complete continuation mapping

| Row action | Native implementation responsibility |
| --- | --- |
| 1 statement mark | Pending/view owner, still separate |
| 2 affinity | Object field/read, actual affinity image, object import |
| 3 result begin | This owner, command 7 |
| 4 / 5 cursor begin / next | Native committed/pending index owner, still separate |
| 6 comparison | Object field/read and actual comparison image |
| 7 storage class | Issued cell metadata; imported NaN becomes SQLite NULL |
| 8 row begin | This owner, command 3 |
| 9 row assignment | Actual affinity image followed by command 6 |
| 10 constant | This owner, command 4 |
| 11 addition | Object field/read, actual ADD_ONE image, object import |
| 12 rowid / high-water | Native view/allocation owner, still separate |
| 13 pending write | Pending/view owner, still separate |
| 14 append projection | This owner, command 8 |
| 15 finished result | This owner, command 9 |
| 16 statement rollback | Pending/view owner, still separate |
| 17 scope cleanup | This owner, command 11, plus view/mark retirement |
| 18 independent error result | This owner, command 10 |

The fixed native coordinator must join these images using their actual completed
frames and private buffers. A Python registry, row-selection callback, numeric
conversion callback or fabricated handle is not an implementation of this
mapping. There is no production fallback for an absent peer.

## Private input and object custody

The RWW invocation receives one exact input frame, an output buffer of at least
192 bytes, and a growable workspace with a 512-byte fixed prefix. All source
spans are owned by the fixed coordinator. An import lease names the actual
immutable source span issued by that coordinator, not an arbitrary external
claim about bytes. Its binding includes the real session, row scope, action and
producer completion. The complete source is validated before any object is
published.

GROW does not commit the service call, append a result row, consume an object ID
or repeat an external producer. The coordinator preserves the exact input
allocation and bytes, grows only the requested allocation, copies the old
workspace prefix exactly, and calls the same image again. The pending header
must match word for word. This header check does not authenticate a substituted
private payload; the actual immutable lease is an additional required boundary.
This kernel is not exposed as an arbitrary arena/header authentication API.

The 16 little-endian input words are:

    [HIANOB01, command, sessionLo, sessionHi, call,
     rowScope, rowAction, sourceLease, a,b,c,d,e,f,payloadBytes,0]

The session pair is not both zero. Calls are strictly consecutive, beginning at
one. A row scope is issued monotonically and is never reused in the session;
BEGIN also records the strictly increasing parent transaction call. Within a
scope, row-action numbers never decrease, and several object services may serve
one actual row action. Outside a scope the context is scope0/action0. Objects
have native-issued nonzero IDs that are not reused. Counter exhaustion requires
a fresh live session; it is not a persistent namespace-size quota.

The 24-word output is:

    [magic,status,sessionLo,sessionHi,call,command,rowScope,rowAction,
     result0,result1,result2,result3,requiredWorkspace,requiredOutput,
     payloadBytes,reason,sourceLease,liveScope,usedWorkspace,nextObjectId,
     schema1,0,0,0]

Status0 completes a service; status1 requests growth; status2 completes a partial
cell read with more immutable bytes remaining; status3 is result-cursor EOF.
BAD0xfffffffd permanently refuses a usable workspace. A workspace shorter than
512 cannot record poison and must be discarded. A malformed frame, stale or
foreign object, wrong role, retired scope, altered continuation, incoherent
arena or insufficient fixed output poisons the workspace. A closed workspace
cannot be restarted. Unused output header words and the exposed output tail are
zeroed on each invocation.

## Commands

All unspecified argument words and payloads are zero. Only IMPORT has a nonzero
source lease. Allocation growth is based on the actual request and live arena;
there is no new store-wide byte, row, digit, history or result-count limit.

| Command | Arguments and payload | Result |
| --- | --- | --- |
| 1 BEGIN_SCOPE | a=actual parent call, new rowScope, rowAction0 | scope |
| 2 IMPORT_VECTOR | payload=count:u64 followed by exact kind/length/raw cells | vector ID, width |
| 3 NULL_VECTOR | a=width | vector ID, width |
| 4 CONSTANT | a=selector, b=count for selector5 | one-cell vector |
| 5 FIELD | a=vector, b=column | cell ID, storage class, byte length |
| 6 REPLACE | a=vector, b=column, c=already normalized cell | new immutable vector |
| 7 BUILDER | a=row operation, b=projection mask | builder ID |
| 8 APPEND | a=builder, b=vector, c=the same projection mask | same builder, row count |
| 9 FINISH | a=builder, b=changes, c=matches | detached result ID, row count |
| 10 ERROR | a=code, b=operation, c=table, d=detail | detached error result |
| 11 CLEAN_SCOPE | a=kept result, b=rowScope, c=last completed row action | zero |
| 12 DESCRIBE | a=live object | kind and role-specific metadata; error detail is an additional eight raw bytes |
| 13 CELL_READ | a=cell, b=byte offset | class, full length, offset, next offset; raw chunk |
| 14 RESULT_CURSOR | a=finished result | detached cursor ID |
| 15 RESULT_NEXT | a=cursor | next vector ID/width or EOF |
| 16 DROP | a=detached result/error/cursor root | zero after collection |
| 17 CLOSE | no arguments | closed state; all objects retired |
| 18 COLLECT | no arguments | live object count |

CONSTANT selectors are NULL0, integer-zero1, integer-one2, TEXT-`0`3,
TEXT-`completed`4 and signed integer count5. Cells use the existing five-class
envelope: NULL has zero bytes, INTEGER and REAL have eight, TEXT and BLOB carry
all supplied bytes. IEEE NaN imported from a binding becomes NULL, as in the
retained SQLite binding boundary; infinity and signed zero remain REAL. No
UTF-8 repair, decimal normalization or blob/text conversion is performed here.
Affinity is the separate actual HIA component.

Projection preserves column order and uses exactly the supplied u64 mask.
All ten retained schemas fit this mask. Fields above bit63 are unselected in a
generic wider vector; this is not a new schema-width restriction. FINISH takes
a snapshot of the builder's current row count: later appends cannot alter an
already finished result. Changes and matches are preserved independently.

CLEAN_SCOPE requires the actual kept result produced in that scope, the exact
scope, and `rowAction == lastCompletedAction + 1`. It retires every other
temporary in that scope. Previously detached results and explicitly detached
cursors remain owned. Clean COMMIT
and read-only calls must still invoke the outer transaction/view cleanup; an
unchanged durable transaction sequence does not preserve a temporary lease.

## Native arena and independent result lifetime

The workspace contains native records for cells, vectors, builders, list links,
results, errors and result cursors. IDs, roles, extents and reachability are
chosen and validated by HIA. Vector fields refer to immutable cells. Builder
links refer to projected immutable vectors. A finished result holds a first
link and a row-count snapshot, so a subsequent builder append is outside that
snapshot. A result cursor owns its result until EOF or explicit DROP.

Collection begins from the active scope and every detached result/error/cursor
root, marks only their real closure, and retires unreachable records. Compaction
moves live records while keeping their native IDs and all references stable.
No retired ID is reassigned. GROW can therefore be satisfied without exposing
stale offsets as object identities. CELL_READ returns bounded raw chunks; an
arbitrarily long TEXT/BLOB does not require an equally large output buffer or a
new total-output quota.

This is transient ownership for bindings, currently visited rows and materialized
results. It is not permission to load an entire committed namespace into one
bounded arena. The pending/index/log peers must page the physical database and
preserve signed rowids, primary-index ordering, non-AUTOINCREMENT random
allocation, AUTOINCREMENT high-water and statement rollback. Native migration
must also fence real old SQLite writers; a cooperative new lock or rename alone
does not provide that guarantee.

## Required validation

Core VM and actual B3/native runs are separate evidence. Every paired call must
compare return code, all exposed output/workspace bytes, immutable input and
guards. The corpus must cover all commands, all five classes, long decimal TEXT
and arbitrary BLOB, scope cleanup with retained results, builder snapshots,
cursor ownership after dropping its result root, stale IDs after collection and
compaction, growth at exact boundaries, unmodified input across growth,
wrong-session/scope/action/call/role, malformed cells and permanent refusal.
The next joint corpus must replace all corresponding reference object/scalar
actions beneath all 31 row operations. Passing this object component alone does
not complete the physical engine or ordinary callers.
