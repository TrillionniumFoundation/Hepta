"""Transient object semantics and private-protocol controls, not a database gate."""
from __future__ import annotations

import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import random
import struct
import unittest

from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANOB01', 'little')
BAD = 0xfffffffd
MASK = (1 << 64) - 1
CANARY = bytes(range(160, 192))


def typed(value):
    if value is None:
        return 0, b''
    if type(value) is int:
        return 1, struct.pack('<Q', value & MASK)
    if type(value) is float:
        return 2, struct.pack('<d', value)
    if type(value) is str:
        return 3, value.encode()
    if type(value) is bytes:
        return 4, value
    raise TypeError(type(value))


def normalized(value):
    kind, raw = value
    if kind == 2:
        bits = struct.unpack('<Q', raw)[0]
        if (bits >> 52) & 2047 == 2047 and bits & ((1 << 52)-1):
            return 0, b''
    return kind, raw


def vector_wire(values):
    return struct.pack('<Q', len(values)) + b''.join(struct.pack('<QQ', k, len(b))+b for k, b in values)


def frame(command, call=1, scope=0, action=0, args=(), payload=b'', session=(0xabc, 0xdef), lease=0):
    return struct.pack('<16Q', MAGIC, command, *session, call, scope, action, lease,
                       *args, *([0]*(6-len(args))), len(payload), 0) + payload


class Session:
    def __init__(self, test, capacity=512):
        self.test = test
        self.work = bytearray(capacity)
        self.call = self.scope = self.action = self.last_scope = self.parent = 0
        self.grows = []

    def send(self, command, *args, payload=b'', scope=None, action=None, output_size=256, grow=True):
        scope = self.scope if scope is None else scope
        action = (self.action+1 if scope else 0) if action is None else action
        raw = frame(command, self.call+1, scope, action, args, payload, lease=0x1234 if command == 2 else 0)
        original = bytes(raw)
        while True:
            before = bytes(self.work)
            code, output = self.test.invoke(raw, self.work, output_size)
            self.test.assertEqual(raw, original)
            head = struct.unpack_from('<24Q', output)
            self.test.assertEqual(head[:8], (MAGIC, code, 0xabc, 0xdef, self.call+1, command, scope, action))
            self.test.assertEqual(head[20:], (1, 0, 0, 0))
            self.test.assertEqual(head[16], 0x1234 if command == 2 else 0)
            self.test.assertEqual(output[192+head[14]:], bytes(output_size-192-head[14]))
            if code != 1 or not grow:
                break
            self.test.assertEqual(struct.unpack_from('<Q', self.work, 32)[0], self.call)
            self.test.assertEqual(struct.unpack_from('<Q', self.work, 40)[0], struct.unpack_from('<Q', before, 40)[0])
            new_work = max(len(self.work), head[12])
            new_output = max(output_size, head[13])
            self.test.assertTrue(new_work > len(self.work) or new_output > output_size)
            self.grows.append({'call': self.call+1, 'input_sha256': hashlib.sha256(raw).hexdigest(),
                               'before': len(self.work), 'after': new_work,
                               'output_before': output_size, 'output_after': new_output})
            self.work.extend(bytes(new_work-len(self.work)))
            output_size = new_output
        if code not in (1, BAD):
            self.call += 1
            self.scope = head[17]
            self.action = action if self.scope else 0
        return code, head, output[192:192+head[14]]

    def ok(self, command, *args, **kwargs):
        code, head, payload = self.send(command, *args, **kwargs)
        self.test.assertEqual(code, 0, (command, args, head))
        return head[8:12], payload

    def begin(self):
        self.last_scope += 1
        self.parent += 1
        self.ok(1, self.parent, scope=self.last_scope, action=0)

    def import_values(self, values):
        result, _ = self.ok(2, payload=vector_wire(values))
        self.test.assertEqual(result[1], len(values))
        return result[0]

    def read_cell(self, identity, output_size=2048):
        payload = bytearray()
        offset = 0
        kind = size = None
        while True:
            code, head, raw = self.send(13, identity, offset, output_size=output_size)
            self.test.assertIn(code, (0, 2))
            cls, full, start, end = head[8:12]
            self.test.assertEqual(start, offset)
            self.test.assertEqual(end, offset+len(raw))
            if kind is None:
                kind, size = cls, full
            self.test.assertEqual((cls, full), (kind, size))
            payload.extend(raw)
            offset = end
            if code == 0:
                break
            self.test.assertGreater(len(raw), 0)
        self.test.assertEqual(len(payload), size)
        return kind, bytes(payload)

    def values(self, identity):
        info, _ = self.ok(12, identity)
        self.test.assertEqual(info[0], 2)
        out = []
        for column in range(info[1]):
            cell, _ = self.ok(5, identity, column)
            value = self.read_cell(cell[0])
            self.test.assertEqual((cell[1], cell[2]), (value[0], len(value[1])))
            out.append(value)
        return tuple(out)

    def make_result(self, rows, mask=MASK, changes=0, matches=0):
        result, _ = self.ok(7, 31, mask)
        builder = result[0]
        for row in rows:
            self.ok(8, builder, row, mask)
        result, _ = self.ok(9, builder, changes, matches)
        return result[0]

    def clean(self, result):
        old = self.action
        self.ok(11, result, self.scope, old, action=old+1)

    def rows(self, result):
        info, _ = self.ok(12, result)
        self.test.assertEqual(info[0], 4)
        created, _ = self.ok(14, result)
        cursor = created[0]
        rows = []
        while True:
            code, head, _ = self.send(15, cursor)
            if code == 3:
                break
            self.test.assertEqual(code, 0)
            row = self.values(head[8])
            self.test.assertEqual(len(row), head[9])
            rows.append(row)
        self.test.assertEqual(len(rows), info[1])
        return tuple(rows), info[2:4]


class NamespaceObjectsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT/'examples/hia_bootstrap/agent_namespace_objects.hiaasm').read_bytes()
        cls.program = assemble_program(cls.raw)
        cls.entry = cls.program.as_dict()['functions'][0]
        cls.entries = cls.observations = 0
        cls.commands = set()
        cls.evidence = Path(os.environ['HIA_NAMESPACE_OBJECTS_LEDGER']) if os.environ.get('HIA_NAMESPACE_OBJECTS_LEDGER') else None
        cls.ledger = None
        if cls.evidence:
            cls.evidence.mkdir(parents=True, exist_ok=False)
            cls.ledger = gzip.open(cls.evidence/'invocations.jsonl.gz', 'wt', encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        if cls.ledger:
            cls.ledger.close()
            (cls.evidence/'counts.json').write_text(json.dumps({
                'scope': 'TRANSIENT OBJECT DEVELOPMENT; PHYSICAL VIEWS/LOG/MIGRATION NOT CLAIMED',
                'source_sha256': hashlib.sha256(cls.raw).hexdigest(),
                'entries': cls.entries, 'observations': cls.observations,
                'completed_commands': sorted(cls.commands),
            }, sort_keys=True, indent=2)+'\n')

    def log(self, row):
        if self.ledger:
            self.ledger.write(json.dumps(row, sort_keys=True, separators=(',', ':'))+'\n')
            self.ledger.flush()

    def invoke(self, raw, work, output_size=256):
        original, before = bytes(raw), bytes(work)
        owners = [_Owner(-1, bytearray(original)), _Owner(-2, bytearray(output_size)), _Owner(-3, work)]
        machine = _Machine(self.program, 8000000, 128 << 20, None, 64)
        result = machine.invoke(self.entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
        output = bytes(owners[1].data)
        type(self).entries += 1
        self.assertEqual(bytes(owners[0].data), original)
        if result in (0, 2, 3) and len(raw) >= 16:
            type(self).commands.add(struct.unpack_from('<Q', raw, 8)[0])
        self.log({'kind': 'vm_entry', 'entry': type(self).entries, 'test_id': self.id(),
                  'input_hex': original.hex(), 'workspace_before_hex': before.hex(),
                  'workspace_after_hex': bytes(work).hex(), 'output_hex': output.hex(),
                  'return': result, 'output_descriptor_bytes': output_size})
        return result, output

    def equal_values(self, session, identity, expected):
        actual = session.values(identity)
        expected = tuple(normalized(v) for v in expected)
        self.log({'kind': 'independent_value_observation', 'test_id': self.id(), 'object': identity,
                  'expected': [(k, b.hex()) for k, b in expected],
                  'actual': [(k, b.hex()) for k, b in actual]})
        type(self).observations += 1
        self.assertEqual(actual, expected)

    def reject(self, raw, state=None):
        work = bytearray(512 if state is None else state)
        self.assertEqual(self.invoke(raw, work)[0], BAD)
        saved = bytes(work)
        valid = frame(1, scope=1, args=(1,))
        self.assertEqual(self.invoke(valid, work)[0], BAD)
        self.assertEqual(bytes(work), saved)

    def test_five_classes_constants_null_vectors_and_arbitrary_raw_bytes(self):
        s = Session(self)
        s.begin()
        values = [typed(v) for v in (None, -(1 << 63), -1, 0, (1 << 63)-1,
                                     -math.inf, -0.0, 0.0, 1.25, math.inf,
                                     '', '0'*100+'1', 'é\0z', b'', b'\xff\0\xed')]
        values += [(3, b'\xff\xc0\0'), (2, struct.pack('<Q', 0x7ff8000000000001))]
        vector = s.import_values(values)
        self.equal_values(s, vector, values)
        for selector, value in enumerate((None, 0, 1, '0', 'completed', -(1 << 63))):
            row, _ = s.ok(4, selector, ((1 << 63) if selector == 5 else 0))
            self.equal_values(s, row[0], [typed(value)])
        for width in (0, 1, 7, 65):
            row, _ = s.ok(3, width)
            self.equal_values(s, row[0], [typed(None)]*width)
        result = s.make_result([vector], changes=7, matches=9)
        s.clean(result)
        rows, counts = s.rows(result)
        self.assertEqual(rows, (tuple(normalized(v) for v in values),))
        self.assertEqual(counts, (7, 9))
        self.assertTrue(s.grows)

    def test_projection_replacement_builder_snapshots_and_cleanup(self):
        s = Session(self, 4096)
        s.begin()
        values = tuple(map(typed, (1, 'a', b'b', None, -2)))
        source = s.import_values(values)
        constant, _ = s.ok(4, 4)
        cell, _ = s.ok(5, constant[0], 0)
        replacement, _ = s.ok(6, source, 2, cell[0])
        expected = values[:2] + (typed('completed'),) + values[3:]
        self.equal_values(s, source, values)
        self.equal_values(s, replacement[0], expected)
        made, _ = s.ok(7, 5, 0b10101)
        builder = made[0]
        s.ok(8, builder, source, 0b10101)
        s.ok(8, builder, replacement[0], 0b10101)
        first, _ = s.ok(9, builder, 2, 4)
        s.ok(8, builder, source, 0b10101)
        second, _ = s.ok(9, builder, 3, 6)
        projected = tuple(values[i] for i in (0, 2, 4))
        projected_new = tuple(expected[i] for i in (0, 2, 4))
        self.assertEqual(s.rows(first[0]), ((projected, projected_new), (2, 4)))
        self.assertEqual(s.rows(second[0]), ((projected, projected_new, projected), (3, 6)))
        s.clean(first[0])
        self.assertEqual(s.rows(first[0]), ((projected, projected_new), (2, 4)))
        saved = bytes(s.work)
        for identity in (source, replacement[0], builder, second[0]):
            self.reject(frame(12, s.call+1, args=(identity,)), saved)

    def test_cursor_retains_dropped_result_then_retires_without_id_reuse(self):
        s = Session(self)
        s.begin()
        row = s.import_values([typed('alive'), typed(b'\0\xff')])
        result = s.make_result([row, row])
        s.clean(result)
        cursor, _ = s.ok(14, result)
        s.ok(16, result)
        saved = bytes(s.work)
        self.reject(frame(12, s.call+1, args=(result,)), saved)
        self.reject(frame(14, s.call+1, args=(result,)), saved)
        seen = []
        while True:
            code, out, _ = s.send(15, cursor[0])
            if code == 3:
                break
            self.assertEqual(code, 0)
            seen.append(s.values(out[8]))
        self.assertEqual(seen, [(typed('alive'), typed(b'\0\xff'))]*2)
        old_next = struct.unpack_from('<Q', s.work, 40)[0]
        s.ok(18)
        self.assertEqual(struct.unpack_from('<Q', s.work, 48)[0], 512)
        self.reject(frame(12, s.call+1, args=(cursor[0],)), s.work)
        s.begin()
        new, _ = s.ok(4, 1)
        self.assertGreaterEqual(new[0], old_next)
        self.reject(frame(12, s.call+1, s.scope, s.action+1, (row,)), s.work)

    def test_growth_keeps_exact_uncommitted_request_and_chunked_large_cells(self):
        s = Session(self)
        s.begin()
        values = [(3, b'9'*16385), (4, bytes(range(256))*4096)]
        body = vector_wire(values)
        raw = frame(2, 2, 1, 1, payload=body, lease=0x1234)
        before = bytes(s.work)
        code, output = self.invoke(raw, s.work, 192)
        self.assertEqual(code, 1)
        head = struct.unpack_from('<24Q', output)
        self.assertEqual(head[12], 512 + 64 + 16 + (64+16392) + (64+1048576))
        self.assertEqual(struct.unpack_from('<Q', s.work, 32)[0], 1)
        self.assertEqual(struct.unpack_from('<Q', s.work, 40)[0], 1)
        for word in (4, 5, 6, 7, 8):
            bad = bytearray(raw)
            struct.pack_into('<Q', bad, word*8, struct.unpack_from('<Q', bad, word*8)[0]+1)
            self.reject(bytes(bad), s.work)
        s.work.extend(bytes(head[12]-len(s.work)))
        code, output = self.invoke(raw, s.work, 256)
        self.assertEqual(code, 0)
        s.call, s.scope, s.action = 2, 1, 1
        vector = struct.unpack_from('<Q', output, 64)[0]
        self.assertEqual(raw, frame(2, 2, 1, 1, payload=body, lease=0x1234))
        for column, expected in enumerate(values):
            found, _ = s.ok(5, vector, column)
            self.assertEqual(s.read_cell(found[0], 131264), expected)
        short = s.import_values([typed(b'abc')])
        found, _ = s.ok(5, short, 0)
        code, out, data = s.send(13, found[0], 0, output_size=192)
        self.assertEqual((code, data, out[11]), (2, b'a', 1))
        self.assertEqual(s.grows[-1]['output_after'], 193)

    def test_fixed_seed_vector_projection_and_repeated_scope_collection(self):
        rng = random.Random(0x4849414e4f423031)
        previous = None
        maximum = 0
        for scope in range(1, 7):
            if scope == 1:
                s = Session(self, 2048)
            s.begin()
            vectors = []
            expected = []
            mask = rng.getrandbits(12)
            for _ in range(6):
                width = rng.randrange(0, 10)
                values = []
                for index in range(width):
                    choice = rng.randrange(5)
                    value = None if choice == 0 else rng.randrange(-(1 << 63), 1 << 63) if choice == 1 else rng.uniform(-1000, 1000) if choice == 2 else str(rng.getrandbits(100)) if choice == 3 else rng.randbytes(rng.randrange(0, 40))
                    values.append(typed(value))
                identity = s.import_values(values)
                vectors.append(identity)
                expected.append(tuple(v for i, v in enumerate(values) if mask & (1 << i)))
            result = s.make_result(vectors, mask, scope, 2*scope)
            s.clean(result)
            self.assertEqual(s.rows(result), (tuple(expected), (scope, 2*scope)))
            if previous is not None:
                s.ok(16, previous)
            count, _ = s.ok(18)
            self.assertGreater(count[0], 0)
            next_id = struct.unpack_from('<Q', s.work, 40)[0]
            self.assertGreater(next_id, maximum)
            maximum = next_id
            previous = result
            type(self).observations += len(expected)
        s.ok(16, previous)
        s.ok(18)
        self.assertEqual(struct.unpack_from('<Q', s.work, 48)[0], 512)

    def test_malformed_frames_cells_roles_and_persistent_poison(self):
        valid = frame(1, scope=1, args=(1,))
        invalid = [valid[:n] for n in range(128)] + [valid+b'\0']
        for word, value in ((0, 0), (1, 0), (1, 19), (4, 0), (4, 2), (5, 0),
                            (6, 1), (7, 1), (8, 0), (9, 1), (14, 1), (15, 1)):
            changed = bytearray(valid);struct.pack_into('<Q', changed, word*8, value);invalid.append(bytes(changed))
        changed = bytearray(valid);changed[16:32] = bytes(16);invalid.append(bytes(changed))
        for raw in invalid:
            self.reject(raw)
        s = Session(self, 2048)
        s.begin()
        for raw_body in (b'', bytes(7), struct.pack('<Q', 1),
                         struct.pack('<QQQ', 1, 5, 0),
                         struct.pack('<QQQ', 1, 0, 1)+b'x',
                         struct.pack('<QQQ', 1, 1, 7)+bytes(7),
                         struct.pack('<QQQ', 1, 2, 9)+bytes(9),
                         struct.pack('<QQQ', 1, 3, MASK),
                         struct.pack('<Q', 0)+b'x'):
            self.reject(frame(2, 2, 1, 1, payload=raw_body, lease=9), s.work)
        vector = s.import_values([typed(1)])
        for command, args in ((5, (vector, 1)), (6, (vector, 0, vector)), (8, (vector, vector, 1)),
                               (9, (vector, 0, 0)), (14, (vector,)), (16, (vector,)),
                               (4, (6,)), (3, (MASK,))):
            self.reject(frame(command, s.call+1, s.scope, s.action+1, args), s.work)

    def test_private_context_mutations_short_descriptors_and_exhaustion(self):
        valid = frame(1, scope=1, args=(1,))
        for size in (0, 1, 127, 511):
            work = bytearray(size)
            self.assertEqual(self.invoke(valid, work), (BAD, bytes(256)))
            self.assertEqual(work, bytes(size))
        for size in (0, 1, 128, 191):
            work = bytearray(512)
            self.assertEqual(self.invoke(valid, work, size), (BAD, bytes(size)))
            self.assertEqual(self.invoke(valid, work)[0], BAD)
        s = Session(self, 2048)
        s.begin()
        row = s.import_values([typed('x')])
        valid = frame(12, s.call+1, s.scope, s.action+1, (row,))
        for word, value in ((2, 0x123), (3, 0x321), (4, s.call), (4, s.call+2),
                            (5, 0), (6, 0), (7, 1), (9, 1)):
            raw = bytearray(valid);struct.pack_into('<Q', raw, word*8, value)
            self.reject(bytes(raw), s.work)
        for offset, value in ((0, 0), (8, 0), (40, 0), (48, 511), (48, 2049),
                              (56, 2), (72, 0), (88, 1), (96, 1), (104, 1), (112, 1),
                              (512, 63), (520, 8), (528, 0), (544, 1)):
            work = bytearray(s.work);struct.pack_into('<Q', work, offset, value)
            self.reject(valid, work)
        work = bytearray(s.work);struct.pack_into('<Q', work, 32, MASK)
        self.reject(frame(12, 0, s.scope, s.action+1, (row,)), work)
        work = bytearray(s.work);struct.pack_into('<Q', work, 40, MASK)
        self.reject(frame(3, s.call+1, s.scope, s.action+1, (1,)), work)

    def test_independent_error_fields_exact_output_growth_and_close(self):
        s = Session(self)
        s.begin()
        error, _ = s.ok(10, 1299, 31, 10, MASK)
        result = error[0]
        info, payload = s.ok(12, result, output_size=192)
        self.assertEqual(info, (5, 1299, 31, 10))
        self.assertEqual(payload, struct.pack('<Q', MASK))
        self.assertEqual(s.grows[-1]['output_after'], 200)
        s.clean(result)
        self.assertEqual(s.ok(12, result), (info, payload))
        s.ok(16, result)
        s.ok(18)
        s.ok(17)
        saved = bytes(s.work)
        self.assertEqual(self.invoke(frame(1, s.call+1, 2, 0, (2,)), s.work)[0], BAD)
        self.assertEqual(bytes(s.work), saved)


if __name__ == '__main__':
    unittest.main(verbosity=2)
