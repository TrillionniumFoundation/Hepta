"""Seal all physical record codec revisions and actual counterexamples."""
from pathlib import Path
from hashlib import sha256
import io
import json
import stat
import tarfile

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111/namespace-reconstruction')
DEV = BASE/'log-r1'
SOURCE = BASE.parent/'namespace-authoring-next'
OUT = BASE/'log-r2-complete-01'
OUT.mkdir(exist_ok=False)


def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    raw = path.read_bytes(); after = path.lstat()
    signature = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
    assert signature(before) == signature(after) and len(raw) == before.st_size
    return raw,before


def load(path):
    return json.loads(read(path)[0])


vm = load(DEV/'vm-r2/result.json')
compiled = load(DEV/'native-r3/compile/summary.json')
native = load(DEV/'native-r3/paired-validation/result.json')
original_vm = load(DEV/'vm-r1/result.json')
original_native = load(DEV/'native-r2/paired-validation/result.json')
original_faults = load(DEV/'private-idle-probe-r1-complete/result.json')
fixed_faults = load(DEV/'private-idle-fixed-r2/result.json')
assert vm['status'] == compiled['status'] == native['status'] == original_vm['status'] == original_native['status'] == 'PASS'
assert vm['source_unchanged'] and compiled['source_and_compiler_unchanged'] and native['source_unchanged']
assert native['before'] == native['after'] and compiled['before'] == compiled['after']
assert vm['tests_run'] == vm['tests_loaded'] == native['tests_run'] == native['tests_loaded'] == 8
assert native['paired_vm_entries'] == native['counters']['actual_native_entries'] == native['counters']['full_entry_bytes_equal'] == vm['entries'] == 3061
assert native['observations'] == vm['observations'] == 338
assert native['completed_commands'] == vm['completed_commands'] == list(range(1,8))
assert native['image_sha256'] == native['loaded_image_sha256'] == '87d2172522f745679b4f3a1197e2b00752445ac9621be15a6438e238e799d174'
assert original_vm['entries'] == original_native['counters']['actual_native_entries'] == 3048
assert all(c['observed_accept_after_incoherent_phase'] for c in original_faults['cases']) and original_faults['actual_native_entries'] == 8
assert fixed_faults['all_three_recorded_faults_permanently_refused'] and fixed_faults['actual_native_entries'] == 6
for value in (vm,native,original_vm,original_native):
    for name in ('errors','failures','skipped','expected_failures','unexpected_successes'):
        assert value[name] == []
manifest_raw,_ = read(DEV/'authoring-r2/source.json')
for row in json.loads(manifest_raw)['files']:
    raw,info = read(SOURCE/row['path'])
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256'] and stat.S_IMODE(info.st_mode) == row['mode']
paths = []
for p in sorted(DEV.rglob('*')):
    assert not p.is_symlink()
    if p.is_file():
        assert '__pycache__' not in p.parts
        paths.append(('log/'+str(p.relative_to(DEV)),p))
for name in ('tools/generate_hia_agent_namespace_store.py','docs/HIA_AGENT_NAMESPACE_STORE_ABI.json','tools/generate_hia_selfhost.py','tools/generate_hia_agent_namespace_objects.py'):
    paths.append(('authoring-dependencies/'+name,SOURCE/name))
paths.append(('seal_log_r2.py',Path(__file__).resolve()))
paths.sort(); members = []
for name,p in paths:
    raw,info = read(p)
    members.append({'name':name,'original':str(p),'bytes':len(raw),'mode':stat.S_IMODE(info.st_mode),'sha256':sha256(raw).hexdigest(),
                    'device':info.st_dev,'inode':info.st_ino,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns})
custody = {'schema':'hia.namespace.log-records.complete-development.v1',
           'scope':'Streaming physical record codec only, all ten schemas/five classes. Actual immutable commit/view/index/rowid/migration/ordinary-store composition remains open. Private source leases are required; header validation is not external authentication. No cold/full qualification claim.',
           'source_manifest_sha256':sha256(manifest_raw).hexdigest(),'production_source_unchanged':True,
           'original_r1_vm_and_native_tests':8,'original_r1_native_entries':3048,
           'original_r1_three_private_faults_accepted':True,'original_r1_complete_fault_probe_native_entries':8,
           'initial_controller_failure':load(DEV/'native-r1/authoring-failure.json'),
           'core_vm_tests':8,'actual_native_tests':8,'actual_native_entries':3061,
           'all_native_vm_return_output_workspace_input_and_guards_equal':3061,
           'independent_wire_observations':338,'completed_commands':list(range(1,8)),
           'same_original_fault_frames_fixed_native_entries':6,'all_three_original_faults_permanently_refused':True,
           'native_workspace_instances':native['counters']['persistent_workspaces'],
           'explicit_private_nonzero_initial_controls':native['counters']['initial_nonzero_private_workspaces'],
           'image_sha256':native['image_sha256'],'compiler_sha256':native['compiler_sha256'],
           'original_files':len(members),'original_bytes':sum(r['bytes'] for r in members),'members':members}
custody_raw = (json.dumps(custody,sort_keys=True,indent=2)+'\n').encode()
(OUT/'custody.json').write_bytes(custody_raw)
archive = OUT/'namespace-log-r2-development.tar.xz'
with tarfile.open(archive,'w:xz',preset=1) as tar:
    for row in members:
        raw,info = read(Path(row['original']))
        assert sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes']
        item = tarfile.TarInfo(row['name']); item.size = len(raw); item.mode = row['mode']; item.mtime = 0
        tar.addfile(item,io.BytesIO(raw))
    item = tarfile.TarInfo('CUSTODY.json'); item.size = len(custody_raw); item.mode = 0o600
    tar.addfile(item,io.BytesIO(custody_raw))
with tarfile.open(archive) as tar:
    assert tar.getnames() == [r['name'] for r in members]+['CUSTODY.json']
    for row in members:
        item = tar.getmember(row['name']); raw = tar.extractfile(item).read(); original,info = read(Path(row['original']))
        assert item.isfile() and item.mode == row['mode'] and len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256'] and original == raw
        assert info.st_dev == row['device'] and info.st_ino == row['inode'] and info.st_mtime_ns == row['mtime_ns'] and info.st_ctime_ns == row['ctime_ns']
    assert tar.extractfile('CUSTODY.json').read() == custody_raw
raw,_ = read(archive)
summary = {'status':'ALL_SELECTED_ORIGINAL_MEMBERS_REPLAYED','scope':custody['scope'],'archive':str(archive),
           'archive_bytes':len(raw),'archive_sha256':sha256(raw).hexdigest(),'custody':str(OUT/'custody.json'),
           'custody_bytes':len(custody_raw),'custody_sha256':sha256(custody_raw).hexdigest(),
           'original_members':len(members),'archive_members':len(members)+1,'original_raw_bytes':custody['original_bytes'],
           'original_bytes_modes_inode_mtime_ctime_unchanged':True}
(OUT/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
