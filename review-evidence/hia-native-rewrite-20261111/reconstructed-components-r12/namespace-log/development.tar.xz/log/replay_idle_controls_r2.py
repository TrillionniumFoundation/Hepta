"""Replay exact recorded r1 private fault frames against the real r2 image."""
from pathlib import Path
from hashlib import sha256
import ctypes
import json
import sys

BASE=Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE=BASE/'namespace-authoring-next';DEV=BASE/'namespace-reconstruction/log-r1'
OUT=DEV/'private-idle-fixed-r2';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(SOURCE))
from tests.test_hia_agent_namespace_log import NamespaceLogTests,frame,BAD
from hepta.hia_json_preflight_native import NativeHiaJsonImage

manifest=json.loads((DEV/'native-r3/compile/manifest.json').read_bytes())
image_path=DEV/'native-r3/compile'/manifest['image_path'];image_raw=image_path.read_bytes()
assert sha256(image_raw).hexdigest()==manifest['image_sha256']
source_manifest=json.loads((DEV/'authoring-r2/source.json').read_bytes())
pins={r['path']:r['sha256'] for r in source_manifest['files']}
assert all(sha256((SOURCE/p).read_bytes()).hexdigest()==h for p,h in pins.items())
old_raw=(DEV/'private-idle-probe-r1-complete/result.json').read_bytes();old=json.loads(old_raw)
assert sha256(old_raw).hexdigest()=='22e32dbfbfbae275936229734973c3bbfd7b7004da403f507c212b7a6176280f'
image=NativeHiaJsonImage(image_raw,manifest['image_sha256'])
NamespaceLogTests.setUpClass();test=NamespaceLogTests('test_session_sequence_extent_and_counter_refusals')
canary=bytes(range(160,192));rows=[]
for case in old['cases']:
    prior=case['entries'][-1];assert case['observed_accept_after_incoherent_phase'] and prior['return']==2
    work=bytearray.fromhex(prior['before_hex']);native=ctypes.create_string_buffer(bytes(work)+canary,1056)
    entries=[]
    for request in [bytes.fromhex(prior['input_hex']),frame(4)]:
        before=bytes(work);vm_code,vm_out=test.invoke(request,work,256)
        s=ctypes.create_string_buffer(request+canary,len(request)+32);o=ctypes.create_string_buffer(bytes(256)+canary,288)
        code=image._entry(s,len(request),o,256,native,1024)
        actual=bytes(o[:288]);after=bytes(native[:1056])
        assert code==vm_code==BAD and actual==vm_out+canary and after==bytes(work)+canary
        assert bytes(s[:len(request)+32])==request+canary
        if entries:assert before==bytes(work)
        entries.append({'input_hex':request.hex(),'pre_workspace_hex':before.hex(),'post_workspace_hex':bytes(work).hex(),
                        'output_hex':actual.hex(),'return':code,'full_actual_native_vm_and_guards_equal':True})
    rows.append({'case':case['case'],'same_recorded_r1_input_and_pre_workspace':True,'r1_return':prior['return'],'r2_return':entries[0]['return'],'entries':entries})
NamespaceLogTests.tearDownClass();after={p:sha256((SOURCE/p).read_bytes()).hexdigest() for p in pins}
assert after==pins and sha256(image_path.read_bytes()).hexdigest()==manifest['image_sha256']
result={'schema':'hia.namespace-log.private-idle-fixed.v1','scope':'EXACT PRIVATE WORKSPACE FAULT REGRESSION; NOT ORDINARY INPUT AUTHENTICATION',
        'source_before':pins,'source_after':after,'original_counterexample_sha256':sha256(old_raw).hexdigest(),'image_sha256':manifest['image_sha256'],
        'actual_native_entries':6,'all_three_recorded_faults_permanently_refused':True,'cases':rows}
raw=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode();(OUT/'result.json').write_bytes(raw)
print(json.dumps({'status':'PASS','actual_native_entries':6,'result_sha256':sha256(raw).hexdigest()},sort_keys=True))
