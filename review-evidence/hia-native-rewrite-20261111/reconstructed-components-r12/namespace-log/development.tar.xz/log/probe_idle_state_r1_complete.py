"""Private-workspace phase controls against the frozen real record image.

This is explicit internal state mutation, not an ordinary input counterexample.
"""
from pathlib import Path
from hashlib import sha256
import ctypes
import json
import struct
import sys

BASE=Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE=BASE/'namespace-authoring-next'
DEV=BASE/'namespace-reconstruction/log-r1'
OUT=DEV/'private-idle-probe-r1-complete'
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(SOURCE))
from tests.test_hia_agent_namespace_log import NamespaceLogTests,frame,BAD,record
from hepta.hia_json_preflight_native import NativeHiaJsonImage

manifest=json.loads((DEV/'native-r2/compile/manifest.json').read_bytes())
image_path=DEV/'native-r2/compile'/manifest['image_path'];raw_image=image_path.read_bytes()
assert sha256(raw_image).hexdigest()==manifest['image_sha256']
source_manifest=json.loads((DEV/'authoring-r1/source.json').read_bytes())
pins={r['path']:r['sha256'] for r in source_manifest['files']}
assert all(sha256((SOURCE/p).read_bytes()).hexdigest()==h for p,h in pins.items())
image=NativeHiaJsonImage(raw_image,manifest['image_sha256'])
NamespaceLogTests.setUpClass()
test=NamespaceLogTests('test_session_sequence_extent_and_counter_refusals')
rows=[]
for name,frames,next_frame in [
    ('complete_decode_missing_end',[frame(4),frame(5,sequence=1,source=9,body=record(2,1,1,b''))],frame(4,operation=2,lease=2)),
    ('incomplete_decode_header',[frame(4),frame(5,sequence=1,source=9,body=b'H')],frame(4,operation=2,lease=2)),
    ('missing_encode_footer',[frame(1,meta=(2,1,1,0))],frame(1,operation=2,lease=2,meta=(2,1,2,0))),
]:
    work=bytearray(1024);native=ctypes.create_string_buffer(1024)
    entries=[]
    for request in frames+[next_frame]:
        mutation=None
        if request is next_frame:
            before=bytes(work);struct.pack_into('<Q',work,8,1)
            ctypes.memmove(native,bytes(work),len(work))
            mutation={'before_hex':before.hex(),'after_hex':bytes(work).hex(),'field':'workspace phase active2 -> idle1'}
        before=bytes(work);vm_code,vm_output=test.invoke(request,work,256)
        s=ctypes.create_string_buffer(request,len(request));o=ctypes.create_string_buffer(256)
        code=image._entry(s,len(request),o,256,native,1024)
        actual=bytes(o[:256]);after=bytes(native[:1024])
        assert code==vm_code and actual==vm_output and after==bytes(work) and bytes(s[:len(request)])==request
        entries.append({'input_hex':request.hex(),'before_hex':before.hex(),'after_hex':after.hex(),'output_hex':actual.hex(),
                        'return':code,'actual_native_vm_equal':True,'explicit_private_mutation':mutation})
    rows.append({'case':name,'observed_accept_after_incoherent_phase':entries[-1]['return']!=BAD,'entries':entries})
NamespaceLogTests.tearDownClass()
after={p:sha256((SOURCE/p).read_bytes()).hexdigest() for p in pins}
assert after==pins and sha256(image_path.read_bytes()).hexdigest()==manifest['image_sha256']
value={'schema':'hia.namespace-log.private-idle-probe.v1','scope':'EXPLICIT PRIVATE WORKSPACE CORRUPTION; NOT ORDINARY PUBLIC INPUT',
       'source_before':pins,'source_after':after,'image_sha256':manifest['image_sha256'],'actual_native_entries':sum(len(r['entries']) for r in rows),'cases':rows}
raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();(OUT/'result.json').write_bytes(raw)
print(json.dumps({'result_sha256':sha256(raw).hexdigest(),'actual_native_entries':value['actual_native_entries'],'accepted':[r['observed_accept_after_incoherent_phase'] for r in rows]},sort_keys=True))
