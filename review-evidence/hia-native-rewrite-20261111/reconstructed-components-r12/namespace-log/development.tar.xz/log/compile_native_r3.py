from pathlib import Path
from hashlib import sha256
import json
import sys
import traceback

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEV = BASE/'namespace-reconstruction/log-r1'
OUT = DEV/'native-r3/compile'
COLD = Path('/workspace/scratch/9acdfa9f5639/hia-v67-0ef-qualification-local-01')
QUALIFIED = Path('/workspace/scratch/9acdfa9f5639/Hepta-v67-workflow-qualified')
COMPILER = COLD/'cold.cold/qualification.evidence/B3.image.bin'
COMPILER_SHA = '35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
sys.path.insert(0, str(QUALIFIED))
from tools.qualify_hia_selfhost import compile_stage, CHILD

digest = lambda b: sha256(b).hexdigest()
vm = json.loads((DEV/'vm-r2/result.json').read_bytes())
assert vm['status'] == 'PASS' and vm['tests_run'] == vm['tests_loaded'] == 8
assert vm['entries'] == 3061 and vm['observations'] == 338 and vm['completed_commands'] == list(range(1, 8))
assert not any(vm[k] for k in ('errors','failures','skipped','expected_failures','unexpected_successes'))
pins = json.loads((DEV/'vm-r2/source-before.json').read_bytes())
assert pins == json.loads((DEV/'vm-r2/source-after.json').read_bytes())
assert all(digest(Path(p).read_bytes()) == h for p,h in pins.items())
OUT.mkdir(parents=True, exist_ok=False)
for row in json.loads((DEV/'authoring-r2/source.json').read_bytes())['files']:
    p = SOURCE/row['path']; raw = p.read_bytes(); q = OUT/'source'/row['path']; q.parent.mkdir(parents=True, exist_ok=True)
    assert len(raw) == row['bytes'] and digest(raw) == row['sha256'] and p.stat().st_mode & 0o777 == row['mode']
    q.write_bytes(raw); q.chmod(row['mode'])
wrapper_raw = (COLD/'cold.json').read_bytes()
assert digest(wrapper_raw) == 'c3b4b66e01ddf14f15ab62260591b6ecdee27941affe1355e487f594a90745ea'
wrapper = json.loads(wrapper_raw)
assert len(wrapper['checks']) == 11 and all(wrapper['checks'].values())
assert wrapper['generation_sha256'] == [COMPILER_SHA]*3 and wrapper['qualification_wall_limit_seconds'] == 180
assert digest(Path(wrapper['nested_report']).read_bytes()) == wrapper['nested_report_sha256'] == '78b3f4abae59088e6a709b4991f0e1dd1ef8e6e9d3ec4f124cfaf21639561598'
receipt_raw = (COMPILER.parent/'B3.receipt.json').read_bytes(); prior = json.loads(receipt_raw)
assert digest(receipt_raw) == '24f3dfe375a79df29c9ca44159676bb5c95020a84c1dad7dce6d8a3b4e71e237'
compiler_raw = COMPILER.read_bytes()
assert len(compiler_raw) == prior['produced_bytes'] == 669556 and digest(compiler_raw) == prior['produced_sha256'] == prior['image_sha256'] == prior['artifact_sha256'] == COMPILER_SHA
assert prior['source_unchanged'] and not prior['forbidden_compiler_modules_loaded']
assert digest(CHILD.read_bytes()) == prior['runner_sha256'] == '1d298396e97b6d362bcd51121eff1d2f411305133fadb1c974477b2dd9052c29'
compiler_input = (COMPILER.parent/'B3.input.bin').read_bytes()
assert len(compiler_input) == prior['input_bytes'] and digest(compiler_input) == prior['source_sha256'] == prior['input_sha256']
for name, raw in [('compiler.image.bin', compiler_raw), ('compiler.input.original.bin', compiler_input),
                  ('compiler.receipt.original.json', receipt_raw), ('compiler.cold.original.json', wrapper_raw),
                  ('compiler-child.original.py', CHILD.read_bytes())]:
    (OUT/name).write_bytes(raw)
for p in (COMPILER, COMPILER.parent/'B3.receipt.json', COLD/'cold.json', CHILD, QUALIFIED/'tools/qualify_hia_selfhost.py',
          Path(__file__).resolve(), SOURCE/'tools/generate_hia_agent_namespace_store.py', SOURCE/'tools/generate_hia_selfhost.py', SOURCE/'hepta/hia_agent_assembly.py'):
    pins[str(p)] = digest(p.read_bytes())
source = (SOURCE/'examples/hia_bootstrap/agent_namespace_log.hiaasm').read_bytes()
result = {'scope':'DEVELOPMENT streaming physical record codec with actual local 0ef B3; no new cold/physical namespace qualification',
          'before':pins,'compiler_sha256':COMPILER_SHA,'source_sha256':digest(source)}
try:
    image, receipt = compile_stage(OUT, 'agent-namespace-log', OUT/'compiler.image.bin', source)
    raw = image.read_bytes()
    assert receipt['input_sha256'] == receipt['source_sha256'] == digest(source)
    assert receipt['artifact_sha256'] == receipt['image_sha256'] == COMPILER_SHA
    assert receipt['produced_sha256'] == digest(raw) and receipt['produced_bytes'] == receipt['core_u32'] == len(raw)
    assert receipt['limits']['cpu_seconds'] == 10 and receipt['limits']['address_bytes'] == 256 << 20
    assert receipt['limits']['output_capacity'] == receipt['limits']['workspace_bytes'] == 1 << 20
    assert receipt['source_unchanged'] and not receipt['forbidden_compiler_modules_loaded']
    output = (OUT/'agent-namespace-log.output.bin').read_bytes()
    assert output[:len(raw)] == raw and digest(output) == receipt['output_sha256']
    manifest = {'schema':'hepta.hia.agent-namespace-log-native-development.v1','source_sha256':digest(source),
                'image_path':image.name,'image_sha256':digest(raw),'compiler_sha256':COMPILER_SHA}
    (OUT/'manifest.json').write_text(json.dumps(manifest, sort_keys=True, indent=2)+'\n')
    result.update(status='PASS',receipt=receipt,manifest=manifest)
except BaseException as exc:
    traceback.print_exc(); result.update(status='FAIL',exception_type=type(exc).__name__,error=str(exc))
finally:
    result['after'] = {p:digest(Path(p).read_bytes()) for p in pins}
    result['source_and_compiler_unchanged'] = result['after'] == pins
    if not result['source_and_compiler_unchanged']:
        result['status'] = 'FAIL'
    raw = (json.dumps(result,sort_keys=True,indent=2)+'\n').encode(); (OUT/'summary.json').write_bytes(raw)
    print(json.dumps({'status':result['status'],'summary_sha256':digest(raw),'manifest':result.get('manifest')},sort_keys=True),flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
