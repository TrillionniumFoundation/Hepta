"""Replay the original public held-exception witness against the cleanup patch."""
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
from collections import Counter
import gc
import hashlib
import json
import os
import sys
import weakref

BASE = Path(__file__).resolve().parent.parent
ROOT = BASE / "Hepta"
INPUTS = BASE / "hia-function-recovery/frozen-inputs/native-inputs"
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
for key in tuple(os.environ):
    if key.startswith("HEPTA_HIA_") and key.endswith(("_MANIFEST", "_COLD_REPORT")):
        del os.environ[key]
os.environ.update({
    "HEPTA_HIA_COMPOSITE_TYPES_MANIFEST": str(INPUTS / "native-signature-development/manifest-r2.json"),
    "HEPTA_HIA_TASK_HELPERS_MANIFEST": str(INPUTS / "native-helper-development/manifest.json"),
    "HEPTA_HIA_COMPOSITE_FUNCTIONS_MANIFEST": str(INPUTS / "hia-function-native-development/bundle-current.json"),
})
from hepta import hia_program_composite as composite
from hepta import hia_composite_functions_native as function_native
from hepta import hia_composite_types_native as type_native
from hepta.hia_program import HIAProgramRejected, verify_program

def source_pins():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (
        "hepta/hia_program_composite.py", "hepta/hia_composite_functions_native.py",
        "hepta/hia_composite_types_native.py",
    )}

before = source_pins()
original = json.loads((BASE / "hia-function-v63-integration/public-rejection-lifetime-original.json").read_text())
document = original["document"]
type_image = type_native.installed_composite_types(os.environ[type_native.SELECTOR])
bundle = function_native.installed_composite_functions(os.environ[function_native.SELECTOR])
entries = Counter()
session_refs = {"types": [], "function": []}
buffer_refs = []

def observe_init(kind, original_init, buffers):
    def called(self, *args, **kwargs):
        session_refs[kind].append(weakref.ref(self))
        result = original_init(self, *args, **kwargs)
        for name in buffers:
            buffer_refs.append({"kind": kind, "field": name, "ref": weakref.ref(getattr(self, name))})
        return result
    return called

def observe_entry(name, original_entry):
    def called(*args):
        result = original_entry(*args)
        entries[name] += 1
        return result
    return called

def forbidden(*args, **kwargs):
    raise AssertionError("retained semantic owner used")

held = []
with ExitStack() as context:
    context.enter_context(patch.object(type_native.NativeCompositeTypeSession, "__init__", new=observe_init(
        "types", type_native.NativeCompositeTypeSession.__init__, ("_state", "_output"))))
    context.enter_context(patch.object(function_native.NativeFunctionSession, "__init__", new=observe_init(
        "function", function_native.NativeFunctionSession.__init__, ("_workspace", "_output"))))
    context.enter_context(patch.object(type_image, "_entry", new=observe_entry("types", type_image._entry)))
    for name, image in bundle.images.items():
        context.enter_context(patch.object(image, "_entry", new=observe_entry(name, image._entry)))
    context.enter_context(patch.object(composite, "_Types", new=forbidden))
    for name in ("_reference_function", "_reference_parameters", "_reference_check_task", "_reference_helper", "loan_origins"):
        context.enter_context(patch.object(composite._Elaborator, name, new=forbidden))
    try:
        verify_program(document)
    except HIAProgramRejected as error:
        held.append(error)
    assert len(held) == 1
    gc.collect()
    result = {
        "scope": "ACTUAL_PUBLIC_REJECTION_WITH_CALLER_HELD_EXCEPTION_WEAK_REFERENCE_OBSERVATION",
        "source_before": before,
        "document": document,
        "exception": {"code": held[0].code, "text": str(held[0])},
        "exception_matches_original": {"code": held[0].code, "text": str(held[0])} == original["exception"],
        "exception_still_retained": True,
        "sessions": {kind: [{"alive": ref() is not None, "closed": None if ref() is None else ref()._closed}
                              for ref in refs] for kind, refs in session_refs.items()},
        "buffers": [{"kind": row["kind"], "field": row["field"], "collected": row["ref"]() is None}
                    for row in buffer_refs],
        "actual_native_entries": dict(entries),
        "probe_holds_strong_session_or_buffer_references": False,
        "cold_qualified": False,
    }
    assert result["exception_matches_original"]
    assert len(buffer_refs) == 4 and all(row["collected"] for row in result["buffers"])
    assert all(not row["alive"] or row["closed"] for rows in result["sessions"].values() for row in rows)
    assert entries["types"] > 0 and entries["admit"] > 0
held.clear()
gc.collect()
result["sessions_collectible_after_exception_released"] = all(ref() is None for refs in session_refs.values() for ref in refs)
result["source_after"] = source_pins()
assert result["sessions_collectible_after_exception_released"] and result["source_before"] == result["source_after"]
result["status"] = "ORIGINAL_PUBLIC_LIFETIME_WITNESS_FIXED"
out = Path(__file__).resolve().parent / "independent-public-rejection-fixed.json"
out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, indent=2, sort_keys=True))
