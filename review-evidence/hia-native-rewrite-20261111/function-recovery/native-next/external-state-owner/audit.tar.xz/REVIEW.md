# Independent read-only audit: Agent journal native owner

## Decision

The journal implementation is a useful, substantive HIA component and is worth migrating into the current line through an isolated integration. It does **not** close the Agent runtime or replace its Python service/SQLite ownership. The audited branch is **not ready to merge or qualify as current-source native execution**: its fresh CI has failed before cold execution, its journal source and tests are absent from the cold source closure, and no journal CI execution gate is wired.

No remote file, branch, comment or message was changed. This reviewer ran no native image, compiler, cold qualification or performance panel. Findings below combine immutable Git source inspection, exact blob readback, actual GitHub job logs and explicitly identified author claims.

## Exact revision and divergence

- Repository: TrillionniumFoundation/Hepta.
- Branch: `codex/hia-native-state-owner-20261111-e26e`.
- Initially supplied revision: `3335436fddece200bb466374211ef4ea0fe59a2d`, parent `b48042943f3dbc3e9232a2f61ab8f9a1f58567aa`.
- Audited current head: **`3ed860043d537305b20aea3abb39c0daa2d2b966`**, parent 3335436. Its changes are the immutable-image cache test distinction and documentation; the journal HIA and adapter bytes remain those of 3335436.
- Main comparison: `31d81594997cfb6cce5ab62ea5aaba3bb7757af1`.
- Merge base: **`d6847ac891e0dd07217d179891bb763162211de2`**.
- GitHub compare reports divergence: **18 commits ahead, 2 behind, 142 changed paths**. Six files describes the one 3335436 commit, not the branch.
- The exact 14 paths changed on both sides are listed in `audit-facts.json`. They include workflow, MANIFEST, resource registry, shared builder, support contract/inventory/status, JSON diagnostics tests and fixture-efficiency tests.

A normal three-way merge need not remove main-only function files, but wholesale replacement with the older branch's workflow/resource/contract files would lose current v63 function coverage. The same risk applies to v64 constructor/outer resources during later integration.

## Observed fresh CI failure

[Run 42979964695](https://github.com/TrillionniumFoundation/Hepta/actions/runs/42979964695) is attached to exact head 3ed8600 and completed with failure.

| Job | Observation | Consequence |
| --- | --- | --- |
| source, 130387852028 | Python 3.14.10; listed source generators and core-only check pass, then `validate_contract()` raises “Selfhost-Core support contract differs from the current source closure” | No subsequent source/reference suite result; the generator list itself does not include journal |
| native, 130387851757 | The initial `replay_hia_selfhost_cold.py` invocation raises the same contract mismatch before creating cold output | No 38-phase cold attempt and no subsequent native application tests |
| artifact preservation | Upload reports no files in the listed cold/evidence paths; API reports zero artifacts | The available fresh evidence is the two job logs, not a cold report or archive |

Decoded GitHub logs are preserved exactly as returned by the connector:
- `head-source-log.txt`: 21,431 bytes, SHA-256 `6900e30855e33a76270d9af5e76851f6dd9414988f1c6965514e988b7b82e9dd`.
- `head-native-log.txt`: 38,199 bytes, SHA-256 `273f0fc157cc32ef9e11ec016b5fd6082b294f7b1d4a929f4815236b98855159`.

This failure is a source-contract rejection, **not** a 180-second timeout or a failed journal semantic case.

## Actual HIA ownership

The generated HIA is executable logic, not a fixture lookup table. `tools/generate_hia_agent_journal.py` composes the ordinary JSON arena, exact binary64 conversion/formatting, SHA-256 and a state machine; `prepare`, `observe_row`, `dispatch`, `inline_response` and `terminal_response` implement the decisions.

| Responsibility | Actual owner at audited head |
| --- | --- |
| Canonical request hash, request ID, known-tool decision, top-level request-key admission and key hash | HIA journal image |
| Digest-conflict-before-state priority; reserve / completed replay / unknown intent | HIA journal image |
| Reservation and atomic-update ACK ordering; selected verification replay instruction | HIA decisions, Python SQL/verification bridge executes the requested effects |
| Terminal canonical response and cost-detail bytes, write flags and status | HIA journal image |
| Original Python argument snapshot, bounded object wire encoding | Python `decode_data(wire(arguments))`; optional existing native JSON/number subcomponents may be selected |
| Cached native arena materialization; ordinary float conversion when no separate converter is selected | Python generic object bridge and Python `float` |
| SQLite transaction, locking, commit/rollback, query/update, durable recovery | Python bridge plus SQLite |
| Resource URI resolution, catalog/schema validation, installation freshness, context/budget policy, error response construction | Existing Python service/store/contract |
| Eleven business methods, evidence replay checks, slots/leases/CAS, artifact namespace | Existing Python service/store or their separately selected components |
| Default `HIAAgentService.call` | Still retained Python `_reference_call` unless `HEPTA_HIA_AGENT_JOURNAL_MANIFEST` is explicitly selected |

The new ordinary driver still calls hosted `wire(response)` before sending a response to HIA. HIA independently canonicalizes and hashes its actual bytes, but this does not remove Python's preceding serialization/snapshot ownership.

The selected driver correctly distinguishes domain rejection from new native protocol/ACK failures and avoids issuing terminal writes after a protocol failure. The source preserves ACK-before-COMMIT placement, arbitrary-precision clock TEXT, conflict-before-state, exact replay without a new cost, and verification replay routing. These are strong design choices, also covered by dedicated tests; this review did not independently re-execute those native tests.

## Integration blockers and dependency closure

### 1. Journal is missing from the whole-source cold closure

`tools/hia_selfhost_contract.py:file_digests` takes explicit `SOURCE_FILES` plus `hepta/**/*.py`. The adapter is included by that second rule, but all four following paths are missing:

- `examples/hia_bootstrap/agent_journal.hiaasm`
- `tools/generate_hia_agent_journal.py`
- `tests/test_hia_agent_journal_native.py`
- `tools/qualify_hia_agent_journal_callers.py`

The generator, actual native program and both test gates would therefore remain unbound even if the existing contract were merely regenerated. Add all relevant journal source, authoring, qualification, test and documentation inputs before freezing and regenerating the source contract.

### 2. There is no journal CI gate

The workflow does not list the journal generator, either journal test class or the selected-callers qualifier. `JournalNativeTests.setUpClass` raises `unittest.SkipTest` when neither explicit development manifest nor matching cold report is supplied. Generic discovery can consequently skip the whole native class.

A proper integration must invoke the source group and a strict native group with the same-source cold report, require zero skips/expected failures/unexpected successes, and run the selected-owner existing callers separately from the default retained regression. The qualifier's eight-module default, loaded/chosen/executed ID ledger and all-eleven-tool requirement are useful, but no exact-head run of it was found in the committed evidence reviewed here.

### 3. Six journal files alone do not import or regenerate on main

The adapter imports `SYNTAX_REASONS` from `hepta.hia_json_preflight_native`. Exact main31d and merge-base d684 lack this symbol; the journal adapter cannot simply be copied over.

The generator imports `tools.generate_hia_worker_request`, which does not exist on main31d. That module composes existing JSON, binary64 and SHA authoring code, and the journal further composes the branch's new shared-preflight diagnostic reason ABI.

Either integrate these complete reviewed dependencies, or extract an equivalent private authoring dependency with exact regeneration and fresh compile evidence. Substituting old main preflight code silently would change diagnostics. Shared preflight changes also alter generated decoder consumers, including composite type HIA bytes; do not overwrite current v63/v64 semantics with an older generated source.

### 4. Packaging and regression evidence require refresh

`NATIVE_SOURCE_FILES` and the shared builder include journal, which is useful. The installed test builds a wheel from a source directory, forbids `tools` and the retained call owner, performs one actual installed describe call and checks source/catalog drift. It does not test the real sdist-to-wheel chain, all installed journal dependency fault cases, or current-main full selection.

Preserve main's complete-function/public-cleanup work and v64's pending constructor/outer integration. Add journal resources, selectors, builders and source-contract entries by method/registry changes, then regenerate the actual complete source tree.

## Evidence boundaries

The current journal HIA bytes were independently decoded from the Git blob and hash to:
`c9f03a97e9c190751b16cea03f119854708404900ce0e33e990e201030f3c96d`.

Commit 3335436 claims current image `7846c445c22236e2c9c694af5bb5928588c67ade966cbf8b0f96e389c09bcac8` and local 21/21 PASS in 63.711 seconds; 3ed8600 claims its focused test passed in 3.074 seconds. These remain **commit-message claims** in this audit: the current image and corresponding raw logs/receipts were not obtained here.

The committed `experiments/hia_agent_journal_development_20261111/r4/` does contain raw 20/20 PASS output and a native compilation receipt, but they bind **older** source `ca7813173c54a35dec91b180269b171afb6d6e17cf6582758df47d0750987c43` and image `44ef61d893e0c882642f2b2c4c394db7d1b10845db275457ef1ac391dc7835d5`, on Python 3.12.14. They cannot qualify the current source.

The prior Python 3.14 wording failure is acknowledged in commit333; this audit did not retrieve its original ROG ledger. The fresh head's Python3.14 jobs were blocked at the contract gate and provide no selected-journal result.

The latest test distinguishes immutable, already admitted code from a changed backing file: unchanged manifest and mapping replay remains allowed; a new manifest pointing to corrupted bytes must fresh-admit and refuse. This matches the shared loader's documented cache semantics and is not evidence that arbitrary new images bypass admission.

## Remaining risks to cover before adoption

1. Re-execute exact-source native dedicated tests and all eight selected-caller modules on the supported Python versions, with current main/v64 code and no exclusions.
2. Retain current-source compiler receipt, image, manifest, full IDs and actual entry evidence. Re-run fixed source cold qualification only after closure and workflow integration.
3. Exercise selected JSON-data/preflight/binary64 combinations and malformed cached values with exact exception text/order; this code intentionally preserves lazy selection and foreign materialization behavior.
4. Keep real transaction commit-fault, crash and concurrent service tests. A HIA decision engine alone is no proof of SQLite durability, multiwriter recovery or complete Agent state replacement.
5. Preserve public driver fail-stop guarantees while documenting the narrower private session contract. `JournalSession` itself has no permanent broken flag; the ordinary driver owns stop-on-protocol-failure. Do not advertise reusable-session poisoning that is not implemented or tested.
6. Keep original failed/pending evidence. A passing older development image or a regeneration-only job is not a matching cold qualification.

## Recommended next independent owner

Keep the journal integration separate from the next compiler vertical slice. After v64, the largest contiguous nominal path still hosted is the generic value transport and continuation driver around the eleven already-HIA semantic kernels.

The next target should be a complete **raw JSON to composite normalization native application**, preserving every v1–v4/legacy schema and the existing error priorities. The first independently deliverable component is a HIA **JSON-arena to generic typed-packet codec**: emit the existing kind/extent/container transport directly from the admitted integer-JSON arena, including exact strings, canonical integer bytes, source ordering and subtree offsets. It replaces Python `transport` plus the detached packet reconstruction for source inputs without deciding nominal semantics.

Then replace generic stream materialization/custody and the constructor/type/helper/function/outer continuation scheduler with HIA-owned state and exact issued handles. Large generated Core must remain streamable until the existing late inventory and final byte gates; do not impose a convenient early 8 MiB limit. The final executable can use the existing HIA ELF packaging/fixed syscall boundary, with no Python object graph or Python session dispatcher at runtime. Reusing eleven images alone is insufficient: their current adapters encode request/response shapes and custody that must be reproduced explicitly and qualified.

## Custody

`head-source-manifest.json` binds the 27 retrieved head files to Git blob SHA-1 and SHA-256. `comparison-source-manifest.json` binds exact local object-store base/main bytes to their commit and Git blob IDs. API responses, decoded logs, old committed development evidence and compact static facts are retained in this directory. The accompanying archive custody verifies every archived member byte, SHA-256 and mode against the persistent source.

