"""Actual outer adapter/decoder, synthetic frames only; NO native image run.

These controls can establish transport rejection, not compiled HIA semantics.
The HIA state-machine source is separately reviewed at the exact stage3 pin.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parent / 'native-outer-next'
AUTHOR = BASE.parent / 'hia-outer-native-development'
for key in tuple(os.environ):
    if key.startswith('HEPTA_HIA_') and (key.endswith('_MANIFEST') or key.endswith('_COLD_REPORT')):
        os.environ.pop(key)
sys.path.insert(0, str(ROOT))
from hepta import hia_composite_outer_native as outer
from hepta.hia_composite_function_tokens import ObjectTokenDecoder, TokenProtocolError
from hepta.hia_json_preflight_native import _load_manifest
from hepta.hia_program import HIAProgramRejected


def digest(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


stage = json.loads((AUTHOR / 'stage3-source.json').read_bytes())
source_paths = [ROOT / name for name in stage['files']]
source_paths += [ROOT / name for name in (
    'hepta/hia_composite_functions_native.py', 'hepta/hia_composite_constructor_native.py',
    'hepta/hia_composite_function_tokens.py', 'hepta/hia_composite_types_native.py',
    'hepta/hia_task_helpers_native.py', 'hepta/hia_instruction_policy_native.py',
    'tools/generate_hia_composite_function_admission.py',
    'tools/generate_hia_composite_function_lowering.py',
    'tools/generate_hia_composite_function_terms.py', 'tools/generate_hia_task_helpers.py',
    'hepta/hia_schema.py')]
source_paths += [AUTHOR / name for name in ('stage3-source.json', 'bundle-r2.json',
    'compile-r2.json', 'owner-r2/manifest.json', 'owner-r2/owner.image.bin',
    'render-r2/manifest.json', 'render-r2/render.image.bin')]
source_paths += [Path(__file__)]
before = {str(path): digest(path) for path in source_paths}
for name, expected in stage['files'].items():
    assert before[str(ROOT / name)] == {key: expected[key] for key in ('bytes', 'sha256')}
    target = BASE / 'frozen-stage3' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_bytes((ROOT / name).read_bytes())
assert Path(outer.__file__).resolve() == ROOT / 'hepta/hia_composite_outer_native.py'
assert _load_manifest.cache_info().misses == 0
dump(BASE / 'source-before.json', before)

M, O = outer.OUTER_MAGIC, outer.OBJECTS
initial = [M, 0, 0, 0, 0, 0, 0, 0]
request = [M, 2, 0, 10, 1, 0, 0, 0]
lease = [M, 3, 0, 20, 1, 0, 0, 0]
header = [M, 7, 0, 22, 1, 0, 0, 0]
helper = [M, 5, 0, 21, 1, O + 1024, 0, 1]
helper_ack = [M, 0, 0, 10, 1, 0, 0, 1]
function = [M, 4, 0, 11, 1, O, 1, 1]
function_ack = [M, 0, 0, 0, 1, 0, 1, 1]
complete = [M, 2, 0, 2000, 1, 0, 1, 1]
valid = [initial, request, lease, header, helper, helper_ack, function, function_ack, complete]


def invocation():
    value = outer.NativeOuterInvocation.__new__(outer.NativeOuterInvocation)
    value._phase = None
    value._request = value._functions = value._helpers = 0
    value._broken = value._completed = False
    value._source_index = {}
    value._output = ctypes.create_string_buffer(64)
    return value


def feed(value, frame, extent=64):
    value._output = ctypes.create_string_buffer(struct.pack('<8Q', *frame))
    return value._frame(extent)


rows = []
def probe(label, prefix, final, *, reject, extent=64):
    item = invocation()
    for frame in prefix:
        assert feed(item, frame) == tuple(frame)
    try:
        result = feed(item, final, extent)
    except HIAProgramRejected as error:
        outcome = {'status': 'rejected', 'class': type(error).__name__,
                   'code': error.code, 'text': str(error), 'broken': item._broken}
        assert reject and item._broken, label
    else:
        outcome = {'status': 'accepted', 'frame': list(result)}
        assert not reject, label
    rows.append({'label': label, 'prefix': prefix, 'frame': final,
                 'extent': extent, 'expected_refusal': reject, 'outcome': outcome})


probe('complete_one_function_one_helper', valid[:-1], valid[-1], reject=False)
probe('late_inventory_refusal', valid[:-1], [M,1,1,2000,1,0,1,1], reject=False)
probe('delegated_function_refusal', [initial,request], [M,1,999,2000,1,0,0,0], reject=False)
probe('helper_refusal_preserves_counts', [initial,request,lease,header], [M,6,0,10,1,0,0,0], reject=False)
probe('unknown_phase', [initial], [M,2,0,123456,1,0,0,0], reject=True)
probe('wrong_magic', [], [0,*initial[1:]], reject=True)
probe('short_frame', [], initial, reject=True, extent=63)
probe('replayed_initial', [initial], initial, reject=True)
probe('request_skipped', [initial], [M,2,0,10,2,0,0,0], reject=True)
probe('request_replayed', [initial,request], request, reject=True)
probe('crossed_helper_completion', [initial,request], helper, reject=True)
probe('helper_wrong_namespace', [initial,request,lease,header], [M,5,0,21,1,O,0,1], reject=True)
probe('helper_skipped_count', [initial,request,lease,header], [M,5,0,21,1,O+1025,0,2], reject=True)
probe('helper_stale_request', [initial,request,lease,header], [M,5,0,21,0,O+1024,0,1], reject=True)
probe('function_wrong_handle', valid[:6], [M,4,0,11,1,O+1,1,1], reject=True)
probe('function_skipped_count', valid[:6], [M,4,0,11,1,O,2,1], reject=True)
probe('helper_counter_rewind', valid[:6], [M,4,0,11,1,O,1,0], reject=True)
probe('completion_before_function_ack', valid[:7], complete, reject=True)
probe('delegated_error_outside_active_function', [initial], [M,1,999,2000,0,0,0,0], reject=True)
probe('inventory_error_before_functions_finish', [initial,request], [M,1,1,2000,1,0,0,0], reject=True)
probe('replayed_completed_frame', valid, complete, reject=True)

probe('helper_success_without_header_verification', [initial,request,lease], helper, reject=True)
probe('helper_refusal_without_header_verification', [initial,request,lease], [M,6,0,10,1,0,0,0], reject=True)
probe('header_verification_replayed', [initial,request,lease,header], header, reject=True)
probe('header_verification_wrong_request', [initial,request,lease], [M,7,0,22,2,0,0,0], reject=True)

poison_rows = []
for method, args in (('_frame',(64,)),('_invoke',(b'',)),('_borrow_function',()),
                     ('_borrow_helper',(None,)),('_next',()),('_bind',(O,{},1)),('_stream',(0,))):
    value = outer.NativeOuterInvocation.__new__(outer.NativeOuterInvocation)
    value._broken = True
    value._source_index = {}
    try:
        getattr(value,method)(*args)
    except HIAProgramRejected as error:
        assert str(error).endswith('protocol has already refused')
        assert value._source_index == {}
        poison_rows.append({'method':method,'error':str(error),'refused_before_other_attributes_or_entry':True,'custody_map_unchanged':True})
    else:
        raise AssertionError('poisoned method accepted: '+method)
value=invocation()
try:
    feed(value,[0,0,0,0,0,0,0,0])
except HIAProgramRejected:
    pass
else:
    raise AssertionError('bad frame did not refuse')
assert value._broken
try:
    feed(value,initial)
except HIAProgramRejected as error:
    assert str(error).endswith('protocol has already refused')
else:
    raise AssertionError('r1 persistent-refusal counterexample still accepted')

opaque_rows = []
def reference(offset):
    return struct.pack('<2Q', 0, offset)

left, right = {'name': 'left'}, {'name': 'right'}
a, b = ObjectTokenDecoder({O:left}), ObjectTokenDecoder({O:right})
assert a.feed(reference(O), final=True) is left
assert b.feed(reference(O), final=True) is right
opaque_rows.append({'label':'same_numeric_handle_is_local_to_decoder_custody_map',
                    'passed':True, 'global_nonce_claim':False})
for label, decoder, payload in (
    ('future_unissued_opaque', ObjectTokenDecoder({O:left}), reference(O+1)),
    ('foreign_only_handle', ObjectTokenDecoder({O:right}), reference(O+1024)),
    ('unissued_source_offset', ObjectTokenDecoder({}), reference(24)),
    ('completed_chunk_replay', a, reference(O)),
):
    try:
        decoder.feed(payload, final=True)
    except TokenProtocolError as error:
        opaque_rows.append({'label':label,'passed':True,'error':str(error)})
    else:
        raise AssertionError(label)

for label, handle, value in (
    ('bind_duplicate_opaque', O, {}), ('bind_input_offset', 24, {}),
    ('bind_bool_identity', True, {}), ('bind_nonobject', O+1, []),
):
    inv = invocation(); inv._source_index[O] = left
    try:
        inv._bind(handle, value, 1)
    except HIAProgramRejected as error:
        opaque_rows.append({'label':label,'passed':True,'error':str(error),
                            'native_ack_never_called':True})
    else:
        raise AssertionError(label)

after = {str(path): digest(path) for path in source_paths}
assert before == after
assert _load_manifest.cache_info().misses == 0
dump(BASE / 'source-after.json', after)
result = {'scope':'SYNTHETIC_NONEXECUTING_TRANSPORT_CONTROLS_ONLY',
          'passed':True, 'frame_probes':rows, 'opaque_probes':opaque_rows, 'poison_entry_probes':poison_rows, 'real_rejection_then_valid_frame_refused':True,
          'native_images_loaded':0, 'native_entries':0,
          'source_preserved':True,
          'source_checkpoint':'stage3-source.json',
          'adapter_sha256':before[str(ROOT/'hepta/hia_composite_outer_native.py')]['sha256'],
          'note':'Same numeric handles resolve only within the current custody map; no claim of cross-session global numeric uniqueness.'}
dump(BASE / 'protocol-probes.json', result)
print(json.dumps({'passed':True,'frames':len(rows),'opaque':len(opaque_rows),'poison_entries':len(poison_rows),
                  'native_images_loaded':0,'native_entries':0,'source_preserved':True}))
