"""Actual frozen r1 _frame, synthetic bytes, no image loaded or executed."""
import ctypes
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parent / 'native-outer-next'
SOURCE = BASE.parent / 'outer-static-independent-r1/frozen-stage2/hepta/hia_composite_outer_native.py'
PIN = '41bcdc9eda63294b1424b353cc65b0d32f61c3a188431a710d9da6e02affbbe8'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == PIN
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('hepta._audit_frozen_r1_outer', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
from hepta.hia_program import HIAProgramRejected
from hepta.hia_json_preflight_native import _load_manifest
assert _load_manifest.cache_info().misses == 0
inv = module.NativeOuterInvocation.__new__(module.NativeOuterInvocation)
inv._phase = None
inv._request = inv._functions = inv._helpers = 0
inv._broken = inv._completed = False
bad = [0,0,0,0,0,0,0,0]
valid = [module.OUTER_MAGIC,0,0,0,0,0,0,0]
inv._output = ctypes.create_string_buffer(struct.pack('<8Q', *bad))
try:
    inv._frame(64)
except HIAProgramRejected as error:
    first = {'class':type(error).__name__, 'code':error.code, 'text':str(error)}
else:
    raise AssertionError('the invalid initial magic did not refuse')
assert inv._broken
inv._output = ctypes.create_string_buffer(struct.pack('<8Q', *valid))
accepted = list(inv._frame(64))
assert accepted == valid and inv._broken
assert SOURCE.read_bytes() == raw and _load_manifest.cache_info().misses == 0
report = {
    'scope':'SYNTHETIC_TRANSPORT_STATE_COUNTEREXAMPLE_NO_NATIVE_EXECUTION',
    'finding':'R1 broken invocation accepts a later valid _frame instead of permanently refusing',
    'finding_reproduced':True,'source':str(SOURCE),'source_sha256':PIN,
    'first_frame':bad,'first_refusal':first,'broken_after_first_refusal':True,
    'second_frame':valid,'second_result':accepted,'broken_after_acceptance':True,
    'native_images_loaded':0,'native_entries':0,'source_unchanged':True,
    'ordinary_public_reuse_claim':False,
    'scope_note':'The ordinary lower finally clears workspace after an error; this demonstrates private protocol object behavior, not an ordinary public source regression.',
}
output=BASE/'counterexample-r1.json'
output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'finding_reproduced':True,'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'native_images_loaded':0,'native_entries':0}))
