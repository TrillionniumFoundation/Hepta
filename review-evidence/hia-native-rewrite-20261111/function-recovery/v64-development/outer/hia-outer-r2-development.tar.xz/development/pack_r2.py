"""Preserve exact completed outer development and independent review evidence."""
from hashlib import sha256
import json
from pathlib import Path
import stat
import tarfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ARCHIVE = BASE / 'hia-outer-r2-development.tar.xz'
CUSTODY = BASE / 'hia-outer-r2-development-custody.json'
assert not ARCHIVE.exists() and not CUSTODY.exists()

source = json.loads((HERE / 'stage4-source.json').read_bytes())
for name, row in source['files'].items():
    data = Path(row['path']).read_bytes()
    assert data == Path(row['snapshot']).read_bytes()
    assert len(data) == row['bytes'] and sha256(data).hexdigest() == row['sha256']

paths = {}
groups = {
    'development': HERE,
    'independent-r1': BASE / 'outer-static-independent-r1',
    'independent-r2': BASE / 'outer-static-independent-r2',
    'persistent-refusal-r1': BASE / 'outer-persistent-refusal-independent',
}
for prefix, directory in groups.items():
    for path in directory.rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        assert not path.is_symlink()
        relative = path.relative_to(directory).as_posix()
        paths[prefix + '/' + relative] = path
paths['integration-static-review/outer-r2-independent-static-review.json'] = (
    BASE / 'hia-v64-integration-plan/outer-r2-independent-static-review.json')
for name in ('hia-outer-stage2-development.tar.xz', 'hia-outer-stage2-development-custody.json'):
    paths['prior-stage2/' + name] = BASE / name

members = {}
for name, path in sorted(paths.items()):
    raw = path.read_bytes()
    members[name] = {'origin': str(path), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
                     'mode': stat.S_IMODE(path.stat().st_mode)}
with tarfile.open(ARCHIVE, 'w:xz', preset=6) as archive:
    for name, path in sorted(paths.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(ARCHIVE, 'r:xz') as archive:
    items = archive.getmembers()
    assert [item.name for item in items] == sorted(paths)
    for item in items:
        raw = archive.extractfile(item).read()
        row = members[item.name]
        assert item.isfile() and item.mode == row['mode']
        assert raw == paths[item.name].read_bytes()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
for name, row in source['files'].items():
    assert sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], name
raw = ARCHIVE.read_bytes()
value = {'archive': str(ARCHIVE), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
    'member_count': len(members), 'raw_bytes': sum(row['bytes'] for row in members.values()),
    'all_members_exact_original_bytes_sha256_mode_readback': True,
    'source_files': len(source['files']),
    'source_manifest_sha256': sha256((HERE / 'stage4-source.json').read_bytes()).hexdigest(),
    'scope': 'DEVELOPMENT_ONLY_NOT_CURRENT_COLD_DEFAULT_OR_WHOLE_STACK_PROMOTION',
    'members': members}
CUSTODY.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({key: item for key, item in value.items() if key != 'members'}, indent=2))
