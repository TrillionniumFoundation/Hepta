"""Record actual outer-owner development tests without widening any language gate."""
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
HERE = Path(__file__).resolve().parent
RECOVERED = HERE.parent / 'hia-function-recovery/frozen-inputs/native-inputs'
attempt = sys.argv[1]
folder = HERE / attempt
folder.mkdir()
manifests = {
    'HEPTA_HIA_COMPOSITE_OUTER_DEVELOPMENT_MANIFEST': HERE / 'bundle-r2.json',
    'HEPTA_HIA_COMPOSITE_CONSTRUCTOR_DEVELOPMENT_MANIFEST': HERE.parent / 'hia-constructor-native-development/bundle-r1.json',
    'HEPTA_HIA_COMPOSITE_FUNCTIONS_DEVELOPMENT_MANIFEST': RECOVERED / 'hia-function-native-development/bundle-current.json',
    'HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST': RECOVERED / 'native-signature-development/manifest-r2.json',
    'HEPTA_HIA_TASK_HELPERS_DEVELOPMENT_MANIFEST': RECOVERED / 'native-helper-development/manifest.json',
}
os.environ.update({name: str(path) for name, path in manifests.items()})
os.environ['HEPTA_HIA_OUTER_INTEGRATION_EVIDENCE'] = str(folder)
sys.path.insert(0, str(ROOT))
pins = json.loads((HERE / 'stage4-source.json').read_bytes())['files']
paths = {ROOT / name for name in pins}
paths.update((ROOT / 'hepta').glob('*.py'))
paths.update([Path(sys.executable).resolve(), Path(__file__),
              ROOT / 'tests/test_hia_composite_outer_integration.py'])
for path in manifests.values():
    paths.add(path)
    manifest = json.loads(path.read_bytes())
    if 'kernels' in manifest:
        for component in manifest['kernels'].values():
            component_path = path.parent / component
            paths.add(component_path)
            component_manifest = json.loads(component_path.read_bytes())
            paths.add(component_path.parent / component_manifest['image_path'])
    else:
        paths.add(path.parent / manifest['image_path'])
paths.update((ROOT / 'examples/hia_bootstrap').glob('composite_*.hiaasm'))
paths.add(ROOT / 'examples/hia_bootstrap/task_helpers.hiaasm')

def hashes():
    return {str(path): {'bytes': path.stat().st_size, 'sha256': sha256(path.read_bytes()).hexdigest()}
            for path in sorted(paths)}

before = hashes()
for name, row in pins.items():
    assert before[str(ROOT / name)]['sha256'] == row['sha256'], name
(folder / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_hia_composite_outer_integration.NativeOuterIntegrationTests')
assert suite.countTestCases() == 2
started = time.monotonic()
with (folder / 'tests.log').open('w') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
after = hashes()
(folder / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
value = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
    skips=len(result.skipped), expected_failures=len(result.expectedFailures),
    unexpected_successes=len(result.unexpectedSuccesses), elapsed_seconds=time.monotonic()-started,
    source_unchanged=before == after, max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    python=sys.version, scope='DEVELOPMENT_ONLY_F50_COMPILER_NOT_CURRENT_COLD',
    scheduling='Overlaps the separate sequential native outer boundary panel; no performance conclusion.')
(folder / 'runner-summary.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)
sys.exit(0 if result.wasSuccessful() and not result.skipped and before == after else 1)
