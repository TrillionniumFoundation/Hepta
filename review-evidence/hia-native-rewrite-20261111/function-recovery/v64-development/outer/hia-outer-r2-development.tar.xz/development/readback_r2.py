"""Read the complete stored old/new outcomes and exact source/image custody."""
import gzip
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
target = HERE / 'final-readback-r2.json'
assert not target.exists()
sources = json.loads((HERE / 'stage4-source.json').read_bytes())
for name, row in sources['files'].items():
    raw = (ROOT / name).read_bytes()
    assert raw == Path(row['snapshot']).read_bytes()
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']

panels = {}
for attempt, expected_tests in (('native-r2-attempt1', 8), ('integration-r2-attempt1', 2)):
    folder = HERE / attempt
    summary = json.loads((folder / 'runner-summary.json').read_bytes())
    assert summary['tests'] == expected_tests
    assert not any(summary[name] for name in ('failures', 'errors', 'skips', 'expected_failures', 'unexpected_successes'))
    before = json.loads((folder / 'source-before.json').read_bytes())
    after = json.loads((folder / 'source-after.json').read_bytes())
    assert before == after and summary['source_unchanged']
    for name, row in after.items():
        raw = Path(name).read_bytes()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256'], name
    panels[attempt] = {**summary, 'fixed_inputs': len(after)}

ledger = HERE / 'native-r2-attempt1/outcomes.jsonl.gz'
cases = []
with gzip.open(ledger, 'rt', encoding='utf-8') as stream:
    for line in stream:
        row = json.loads(line)
        assert row['expected'] == row['actual'] and row['orders'][0] == row['orders'][1] and row['equal']
        record = {'label': row['label'], 'status': row['actual']['status'],
                  'function_calls': len(row['orders'][1])}
        if row['actual']['status'] == 'rejected':
            record['error'] = row['actual']['error']
        elif row['label'] == 'opaque-core-larger-than-eight-mib':
            record['complete_core_json_bytes'] = len(json.dumps(row['actual']['core'], separators=(',', ':')).encode())
            assert record['complete_core_json_bytes'] > 8 << 20
        cases.append(record)
summary = json.loads((HERE / 'native-r2-attempt1/summary.json').read_bytes())
assert summary['comparisons'] == summary['equal'] == len(cases)
assert len(summary['helper_header_fault_controls']) == 7
assert all(row['before'] == row['after'] for row in summary['borrowed'])
value = {'scope': 'COMPLETE_OUTER_OWNER_DEVELOPMENT_NOT_COLD_OR_DEFAULT_PROMOTION',
    'source_files': len(sources['files']), 'source_manifest_sha256': sha256((HERE / 'stage4-source.json').read_bytes()).hexdigest(),
    'panels': panels, 'source_and_frame_tests': 7, 'total_tests': 17,
    'cases': cases, 'comparisons': len(cases), 'exact': len(cases),
    'outer_native_entries': summary['entries'],
    'read_only_borrowed_calls_with_full_buffer_sha': len(summary['borrowed']),
    'actual_helper_header_fault_refusals': len(summary['helper_header_fault_controls']),
    'ledger': {'path': str(ledger), 'bytes': ledger.stat().st_size, 'sha256': sha256(ledger.read_bytes()).hexdigest()},
    'r1_history_preserved': ['native-r1-attempt1', 'helper-header-fault-r1.json',
        'partial-allocation-lifetime-r1.json', 'lifetime-preclosure-r2'],
    'r1_source_test_failure': 'Two fixture-author IndexErrors before later-error cases; not a pass.',
    'public_lifetime_scope': 'Real public late error; explicit v63 close operation in the isolated f50 baseline.'}
target.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({key: value for key, value in value.items() if key not in ('panels', 'cases')}, indent=2))
