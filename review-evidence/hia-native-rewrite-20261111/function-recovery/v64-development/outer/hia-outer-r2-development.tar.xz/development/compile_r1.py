"""Development-only B3 compilation under the unchanged isolated child gates."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
OUT = Path(__file__).resolve().parent
COMPILER = OUT.parent / 'hia-f50-compiler-custody/B3.image.bin'
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_selfhost import compile_stage


def digest(data):
    return hashlib.sha256(data).hexdigest()


compiler = COMPILER.read_bytes()
assert digest(compiler) == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
pins = json.loads((OUT / 'stage1-source.json').read_bytes())
for name, row in pins['files'].items():
    assert digest((ROOT / name).read_bytes()) == row['sha256'], name
components, results = {}, {}
for kernel in ('owner', 'render'):
    sourcepath = ROOT / ('examples/hia_bootstrap/composite_outer_' + kernel + '.hiaasm')
    source = sourcepath.read_bytes()
    destination = OUT / (kernel + '-r1')
    destination.mkdir()
    with tempfile.TemporaryDirectory(prefix='hia-outer-compile-', dir='/dev/shm') as temporary:
        folder = Path(temporary)
        try:
            image, receipt = compile_stage(folder, kernel, COMPILER, source)
        finally:
            for path in folder.iterdir():
                if path.name.endswith('.output.bin'):
                    continue
                if path.is_file():
                    shutil.copyfile(path, destination / path.name)
        imagebytes = image.read_bytes()
    assert sourcepath.read_bytes() == source and COMPILER.read_bytes() == compiler
    manifest = {'schema': 'hepta.hia.composite-outer-' + kernel + '-native.v1',
        'source_sha256': digest(source), 'image_path': kernel + '.image.bin',
        'image_sha256': digest(imagebytes), 'compiler_sha256': digest(compiler)}
    manifestpath = destination / 'manifest.json'
    manifestpath.write_text(json.dumps(manifest, indent=2) + '\n')
    components[kernel] = str(manifestpath.relative_to(OUT))
    results[kernel] = {'receipt': receipt, 'manifest': manifest,
        'scope': 'DEVELOPMENT_ONLY_WITH_F50_COMPILER_NOT_CURRENT_COLD_QUALIFICATION'}
    print(kernel, len(imagebytes), digest(imagebytes), flush=True)
bundle = {'schema': 'hepta.hia.composite-outer-native.v1', 'kernels': components,
    'types_source_sha256': digest((ROOT/'examples/hia_bootstrap/composite_types.hiaasm').read_bytes())}
(OUT/'bundle-r1.json').write_text(json.dumps(bundle,indent=2)+'\n')
for name, row in pins['files'].items():
    assert digest((ROOT/name).read_bytes()) == row['sha256'], name
(OUT/'compile-r1.json').write_text(json.dumps(results,indent=2)+'\n')
