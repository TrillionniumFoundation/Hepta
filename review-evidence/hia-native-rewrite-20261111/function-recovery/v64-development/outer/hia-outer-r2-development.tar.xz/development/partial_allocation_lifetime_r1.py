"""Held-error ownership witness with a small stand-in for the first allocation.

No native image is executed and no large buffer is allocated by this probe.
The stand-in isolates the strong-reference lifetime after the second allocation
fails; its requested size is recorded without claiming a large-RSS measurement.
"""
import ctypes
import gc
from hashlib import sha256
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch
import weakref

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from hepta.hia_composite_constructor_native import NativeConstructorInvocation
from hepta.hia_composite_outer_native import NativeOuterInvocation
from hepta.hia_composite_functions_native import NativeFunctionSession

output = HERE / 'partial-allocation-lifetime-r1.json'
assert not output.exists()
paths = [ROOT / 'hepta/hia_composite_constructor_native.py', ROOT / 'hepta/hia_composite_outer_native.py']
before = {str(path): sha256(path.read_bytes()).hexdigest() for path in paths}
real_create = ctypes.create_string_buffer
rows, held = [], []
for kind in ('constructor', 'outer'):
    refs, calls = [], []
    types = SimpleNamespace()
    session = NativeFunctionSession.__new__(NativeFunctionSession)
    session.types, session._workspace, session.helpers = types, object(), object()
    owner = SimpleNamespace(_native_function_session=session, native_types=types,
        signatures={}, document={}, serial=0, value_slots=0, helpers=[], helper_names={})
    def allocated(*args):
        calls.append(list(args))
        if len(calls) == 2:
            raise MemoryError('injected second-buffer allocation failure')
        result = real_create(32)
        refs.append(weakref.ref(result))
        return result
    try:
        with patch.object(ctypes, 'create_string_buffer', new=allocated):
            if kind == 'constructor':
                NativeConstructorInvocation({}, owner, {})
            else:
                NativeOuterInvocation({}, owner)
    except MemoryError as error:
        held.append(error)
    else:
        raise AssertionError('allocation failure did not propagate')
    gc.collect()
    rows.append({'kind': kind, 'requested_sizes': calls,
                 'first_buffer_retained_with_error': refs[0]() is not None,
                 'actual_first_buffer_bytes': 32, 'native_entries': 0})
after = {str(path): sha256(path.read_bytes()).hexdigest() for path in paths}
assert before == after
value = {'scope': 'CONTROLLED_ALLOCATION_FAILURE_NO_NATIVE_OR_LARGE_RSS_CLAIM',
         'source_before': before, 'source_after': after, 'rows': rows}
output.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(rows))
