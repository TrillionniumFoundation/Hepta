"""Strengthen stored differential readback with exact canonical JSON bytes.

JSON encoding distinguishes bool/int/float values that Python equality alone
could conflate. This reads the original recorded results; it does not rerun or
replace a native admission.
"""
import gzip
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
target = HERE / 'exact-outcome-wire-readback.json'
assert not target.exists()
rows = []
ledger = HERE / 'native-r2-attempt1/outcomes.jsonl.gz'
raw_digest, raw_size = sha256(), 0
with gzip.open(ledger, 'rb') as stream:
    for line in stream:
        raw_digest.update(line)
        raw_size += len(line)
        case = json.loads(line)
        before = json.dumps(case['expected'], sort_keys=True, separators=(',', ':'),
                            ensure_ascii=False, allow_nan=False).encode('utf-8')
        after = json.dumps(case['actual'], sort_keys=True, separators=(',', ':'),
                           ensure_ascii=False, allow_nan=False).encode('utf-8')
        assert before == after, case['label']
        assert case['orders'][0] == case['orders'][1]
        rows.append({'label': case['label'], 'bytes': len(before),
                     'expected_sha256': sha256(before).hexdigest(),
                     'actual_sha256': sha256(after).hexdigest(), 'byte_equal': True})
value = {'scope': 'OFFLINE_EXACT_READBACK_OF_ACTUAL_NATIVE_RESULTS_NO_NEW_ADMISSION',
         'rows': rows, 'comparisons': len(rows), 'all_bytes_equal': True,
         'compressed_ledger_sha256': sha256(ledger.read_bytes()).hexdigest(),
         'uncompressed_ledger_bytes': raw_size, 'uncompressed_ledger_sha256': raw_digest.hexdigest()}
target.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({key: item for key, item in value.items() if key != 'rows'}, indent=2))
