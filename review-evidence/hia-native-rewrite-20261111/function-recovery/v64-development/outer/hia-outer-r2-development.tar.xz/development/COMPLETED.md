# Outer owner development delivery: r2

The complete `_Elaborator.lower` owner is implemented in two HIA kernels. HIA
chooses source-function order, successful helper append order, the final
function/block inventory checks, scalar export eligibility, export sorting and
the complete Core program envelope. Python transports typed requests and
materializes native-issued complete Core object references. It does not count
blocks, classify exports or interpret a lowering plan.

The frozen candidate is `/workspace/scratch/9acdfa9f5639/native-outer-next`.
`stage4-source.json` binds 14 exact files and their `source-r2/` copies; SHA-256
is `fa544a26e412cf45f26d1d29817f770d08ccb0426889ff998a3e42517d356c5e`.
This remains a development candidate with explicit selection. The retained
owners remain present. There is no matching current-source cold qualification,
default activation, whole-language rewrite or whole-stack rewrite claim.

## Native compilation and boundaries

The actual restored f50 B3 compiler was used under the unchanged 10-second CPU,
20-second wall and 256 MiB child address-space limits. It compiled both r2
kernels; the original input, request, receipt, logs and emitted image bytes are
preserved in `owner-r2/` and `render-r2/`.

| Kernel | Functions / blocks / instructions | Source SHA-256 | Image bytes / SHA-256 |
| --- | --- | --- | --- |
| owner | 46 / 487 / 1952 | `50d5b8d4c85f16ed6b6c27fa2a42b408b8adfd89680f90aa134d83adaff7f513` | 177536 / `52dbc8312578e1c46aaf67059a9435a74f50078ccdf20acde1e0214ef5a0b1e9` |
| render | 8 / 71 / 402 | `bdf76034b1cec3612c4681b018ad23306dbdc4e2289041d01d5e485e96b774ff` | 28278 / `b425436d7e87443a6b68e09b1d2898ea235f4cc2477105176e83fd47b13d2dee` |

The complete function, task-helper and native-type kernels retain their
original bytes and interfaces. A new outer phase checks the helper's exact
output header and returned extent against its actual workspace metadata before
issuing an object handle. Every borrowed function/type/helper buffer has an
issued session and phase. The wrapper's frozen retained `lower` body is
unchanged apart from its `_reference_lower` name.

`HIA_COMPOSITE_OUTER_BOUNDS.md` supplies conservative finite bounds: an ordinary
initial packet is at most 60817538 bytes within the existing 64 MiB source
region, and outer arena allocations are at most 452608 bytes within 16711680
available bytes. Complete expanded Core functions are opaque issued objects;
they never pass through that fixed-size input packet. These are source/arena
bounds, not measured RSS or a qualification certificate.

## Completed validation

All 17 final tests passed, with no skips or expected/unexpected failures:

- Seven source, frame and allocation-lifetime tests cover exact HIA reproduction
  within original limits, the unchanged retained oracle, the full cold gate
  before any output-directory change, poisoned bridge entries and partial
  allocation failures while the exception remains held.
- Eight actual native groups made 23 complete differential comparisons. Full
  Core/error text, counters, helper/cache state, type observations and function
  call order match. Offline readback additionally compares exact canonical JSON
  bytes, so Python equality cannot conceal a bool/int/float distinction.
- Two public/installed-wheel tests cover 11 ordinary source fixtures, actual
  Core VM execution, an installed package with authoring imports and all old
  nominal constructor/function/helper/outer semantic methods disabled, and six
  source/image tamper controls that actually refuse with `E_HIA_TYPE`.

The native groups recorded 6559 outer-owner and 2145 renderer entries, 11
borrowed calls with full-buffer SHA readback, and seven actual helper-header
fault refusals. They include all ordinary profiles, a legacy v1 lowering
control, zero-width nominal export exclusion, 1024 source functions plus helpers,
generated blocks crossing the 4096 final limit, later function errors retaining
priority, and a complete 11194928-byte Core object whose final primitive
admission correctly refuses. The later-error case still reports its original
CFG error before that final large-output admission.

The final native run took 238.496 seconds with maximum RSS 708048 KiB; the public
and wheel run took 21.204 seconds with maximum RSS 509180 KiB. They overlapped;
these are execution records, not performance comparisons. Every recorded source,
manifest, executable image and interpreter pin matches its before/after readback.

The 23 original old/new outcomes are preserved as `outcomes.jsonl.gz`, 206683
bytes, SHA-256
`95aa1abb5bc1b0dcf407a9800133a9f31a218cf5cc6b5515f27983abc71fdf71`.
Its decompressed 23850622 bytes have SHA-256
`ab8f99f5971b77e180d7894e64e8928e4b803d2ec86368d12184943bc7256d13`.
`exact-outcome-wire-readback.json` records the separate old/new canonical hashes.

## Preserved defects and fixes

The first r1 complete run is retained as four passing groups and two authoring
`IndexError`s. Both errors occurred while constructing a later-error fixture;
they are not relabeled as successful tests. The original test file, logs and
21 already completed equal comparisons remain available. The final fixtures
construct a valid entry block before deliberately replacing the block field.

An actual r1 helper-image control changed only a returned header serial by one.
The original image had run, and its workspace/payload were untouched; r1 still
accepted the result. R2 rejects the same fault and preserves the normal result.
The r1 log's `workspace_prefix_hex` sampled offset zero; its original bytes are
retained. The r2 log additionally records the real metadata at offset 4096,
including the workspace value 44 against the corrupted header value 45.

Independent non-executing controls also found that r1 could accept a valid
frame after an earlier bridge refusal. R2 checks the poisoned state before every
native call, object binding or stream operation. The independent r2 review ran
25 frame, nine opaque-reference and seven poisoned-entry controls with zero
native entries; it is separate from the actual-image test counts above.

Controlled second-allocation failures originally retained an already allocated
buffer through a held traceback. That probe used a 32-byte stand-in for the
large allocation and is labeled accordingly. R2 releases the partially created
buffers. Two separate actual-image probes then confirmed and fixed unpublished
type-session retention and retention of a borrowed function workspace. Their
pre-fix and post-fix snapshots/results are both retained.

The constructor adapter change closes only a type session not transferred by
object identity to the elaborator. Already committed private partial state is
preserved. The outer bridge releases its borrowed workspace reference as well
as its own arena. This isolated f50 baseline does not include the separate v63
public wrapper cleanup: the real public-error probe explicitly performs that
session-close operation and records the distinction. Integration must preserve
the v63 public and underlying type/function initialization cleanup.

## Integration handoff

Apply the constructor and outer wrapper methods to the v63 file by method-level
diff; do not overwrite its public cleanup with the whole f50-based module.
`stage4-source.json` includes two outer resources, two shared-builder mappings,
the strict outer bundle builder and all new tests. Global inventories, support
contract, CI and retained runner changes remain the integrating agent's work.
The development-test manifests must be replaced by the unified ordinary/cold
fixture for those runs; this evidence does not turn development env variables
into cold qualification.

The complete selected nominal chain uses five bundles and eleven images:
constructor 2, function 5, outer 2, type 1 and helper 1. Public source custody,
primitive verification, execution/runtime and authoring/build orchestration
remain separate owners. No retained implementation is deleted in this delivery.
