"""Freeze the r2 outer owner plus isolated constructor transport-lifetime fix."""
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.generate_hia_composite_outer import document

names = [
    'docs/HIA_COMPOSITE_OUTER_NATIVE_DESIGN.md',
    'docs/HIA_COMPOSITE_OUTER_BOUNDS.md',
    'tools/generate_hia_composite_outer.py',
    'tools/build_hia_composite_outer.py',
    'examples/hia_bootstrap/composite_outer_owner.hiaasm',
    'examples/hia_bootstrap/composite_outer_render.hiaasm',
    'hepta/hia_composite_outer_native.py',
    'hepta/hia_composite_constructor_native.py',
    'hepta/hia_program_composite.py',
    'hepta/hia_agent_contract.py',
    'tools/build_hia_json_preflight.py',
    'tests/test_hia_composite_outer_source.py',
    'tests/test_hia_composite_outer_native.py',
]
target = HERE / 'stage3-source.json'
assert not target.exists()
rows = {}
for name in names:
    data = (ROOT / name).read_bytes()
    destination = HERE / 'source-r2' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    destination.write_bytes(data)
    rows[name] = {'path': str(ROOT / name), 'snapshot': str(destination),
                  'bytes': len(data), 'sha256': sha256(data).hexdigest()}
structure = {}
for kernel in ('owner', 'render'):
    doc = document(kernel)
    functions = doc['functions']
    blocks = [block for fn in functions for block in fn['blocks']]
    structure[kernel] = {'functions': len(functions), 'blocks': len(blocks),
        'instructions': sum(len(block['ops']) for block in blocks),
        'max_function_blocks': max(len(fn['blocks']) for fn in functions),
        'max_block_parameters': max(len(block['params']) for block in blocks)}
value = {'status': 'R2_HEADER_AND_LIFETIME_COMPILED_SOURCE_FRAME_PASS_FULL_NATIVE_PENDING',
    'scope': 'DEVELOPMENT_ONLY_NOT_CURRENT_COLD', 'files': rows, 'structure': structure,
    'constructor_note': 'Only transport poison and owned/unpublished buffer cleanup changed; HIA images unchanged.',
    'integration_note': 'F50-based isolated wrapper; v63 public cleanup must be retained during later integration.'}
target.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'manifest': str(target), 'sha256': sha256(target.read_bytes()).hexdigest(),
                  'files': len(rows), 'structure': structure}, indent=2))
