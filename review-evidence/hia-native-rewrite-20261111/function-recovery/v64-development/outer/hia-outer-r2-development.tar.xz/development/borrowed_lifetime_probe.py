"""Real-image held-refusal controls for unpublished types and borrowed workspace."""
import ctypes
import gc
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import sys
from unittest.mock import patch
import weakref

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
HERE = Path(__file__).resolve().parent
RECOVERED = HERE.parent / 'hia-function-recovery/frozen-inputs/native-inputs'
label = sys.argv[1]
folder = HERE / label
folder.mkdir()
sys.path.insert(0, str(ROOT))
from hepta import hia_program_composite as c
from hepta.hia_composite_constructor_native import installed_composite_constructor, NativeConstructorInvocation
from hepta.hia_program import HIAProgramRejected, verify_core
from tests.test_hia_composite_constructor_native import simple

env = {
    'HEPTA_HIA_COMPOSITE_CONSTRUCTOR_MANIFEST': str(HERE.parent / 'hia-constructor-native-development/bundle-r1.json'),
    'HEPTA_HIA_COMPOSITE_FUNCTIONS_MANIFEST': str(RECOVERED / 'hia-function-native-development/bundle-current.json'),
    'HEPTA_HIA_COMPOSITE_TYPES_MANIFEST': str(RECOVERED / 'native-signature-development/manifest-r2.json'),
    'HEPTA_HIA_TASK_HELPERS_MANIFEST': str(RECOVERED / 'native-helper-development/manifest.json'),
    'HEPTA_HIA_COMPOSITE_OUTER_MANIFEST': str(HERE / 'bundle-r2.json'),
}
os.environ.update(env)
source_names = ['hepta/hia_composite_constructor_native.py', 'hepta/hia_composite_outer_native.py',
                'examples/hia_bootstrap/composite_outer_owner.hiaasm',
                'examples/hia_bootstrap/composite_outer_render.hiaasm']
before = {}
for name in source_names:
    raw = (ROOT / name).read_bytes()
    destination = folder / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    before[name] = sha256(raw).hexdigest()

held, rows = [], []
bundle = installed_composite_constructor(env['HEPTA_HIA_COMPOSITE_CONSTRUCTOR_MANIFEST'])
active, refs, sessions, entries = [], [], [], []
images = dict(bundle.images)
delegate = images['owner']._entry
proxy = type('ActualConstructorFrameFault', (), {})()
def entry(*args):
    result = delegate(*args)
    entries.append(result)
    invocation = active[0]
    if invocation.types is not None and not refs:
        refs.extend([weakref.ref(invocation.types._state), weakref.ref(invocation.types._output)])
        sessions.append(weakref.ref(invocation.types))
        # The real init response is complete; invalidate only its output magic.
        struct.pack_into('<Q', args[2], 0, 0)
    return result
proxy._entry = entry
images['owner'] = proxy
owner = c._Elaborator.__new__(c._Elaborator)
invocation = NativeConstructorInvocation(images, owner, simple(version=4))
active.append(invocation)
try:
    invocation.initialize()
except HIAProgramRejected as error:
    held.append(error)
else:
    raise AssertionError('invalid real constructor frame was accepted')
active.clear()
del invocation
gc.collect()
rows.append({'case': 'unpublished_types_after_real_init_bad_frame',
    'owner_has_native_types': hasattr(owner, 'native_types'),
    'buffer_alive_with_held_error': [ref() is not None for ref in refs],
    'buffer_bytes': [128 << 20, 64 << 20], 'actual_constructor_owner_entries': len(entries)})
if sessions[0]() is not None:
    sessions[0]().close()

# Exercise the actual public verification route. This isolated baseline still
# has the old public lifetime wrapper, so explicitly execute its planned
# v63 finally-close operation after catching the public error; do not claim
# the wrapper was already integrated into this candidate.
owners, borrowed = [], []
original_init = c._Elaborator.__init__
def capture(owner, *args, **kwargs):
    original_init(owner, *args, **kwargs)
    owners.append(owner)
    borrowed.append(weakref.ref(owner._native_function_session._workspace))
document = simple(version=4)
later = dict(document['functions'][0])
later['name'], later['blocks'] = 'later', None
document['functions'].append(later)
try:
    with patch.object(c._Elaborator, '__init__', new=capture):
        verify_core(document)
except HIAProgramRejected as error:
    held.append(error)
else:
    raise AssertionError('late malformed source block inventory was accepted')
assert len(owners) == len(borrowed) == 1
owners[0]._native_function_session.close()
owners[0].native_types.close()
owners.clear()
gc.collect()
rows.append({'case': 'public_late_function_error_after_explicit_session_close',
             'error': [held[-1].code, str(held[-1])],
             'borrowed_function_buffer_alive_with_held_error': borrowed[0]() is not None,
             'buffer_bytes': 192 << 20,
             'public_cleanup_emulated_explicitly_in_this_control': True})
after = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in source_names}
assert before == after
result = {'scope': 'ACTUAL_DEVELOPMENT_LIFETIME_CONTROLS_NOT_COLD',
          'source_before': before, 'source_after': after, 'rows': rows,
          'selectors': env}
(folder / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(rows))
