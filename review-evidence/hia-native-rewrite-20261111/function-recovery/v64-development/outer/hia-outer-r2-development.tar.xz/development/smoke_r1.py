"""Two actual-image outer owner smoke comparisons with all lower semantics native."""
from contextlib import ExitStack
from copy import deepcopy
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
OUT=Path(__file__).resolve().parent
RECOVERED=OUT.parent/'hia-function-recovery/frozen-inputs/native-inputs'
sys.path.insert(0,str(ROOT))
from hepta import hia_program_composite as c
from hepta.hia_composite_outer_native import installed_composite_outer
from tests.test_hia_composite_constructor_native import simple
from tests.test_hia_program_composite import scalar_task_program
from tests.test_hia_composite_function_terms_native import state
from hepta.hia_program import HIAProgramRejected

os.environ.update(
 HEPTA_HIA_COMPOSITE_CONSTRUCTOR_MANIFEST=str(OUT.parent/'hia-constructor-native-development/bundle-r1.json'),
 HEPTA_HIA_COMPOSITE_FUNCTIONS_MANIFEST=str(RECOVERED/'hia-function-native-development/bundle-current.json'),
 HEPTA_HIA_COMPOSITE_TYPES_MANIFEST=str(RECOVERED/'native-signature-development/manifest-r2.json'),
 HEPTA_HIA_TASK_HELPERS_MANIFEST=str(RECOVERED/'native-helper-development/manifest.json'),
 HEPTA_HIA_COMPOSITE_OUTER_MANIFEST='')
pins=json.loads((OUT/'stage2-source.json').read_bytes())['files']
before={n:sha256((ROOT/n).read_bytes()).hexdigest() for n in pins}
for n,r in pins.items():assert before[n]==r['sha256'],n
bundle=installed_composite_outer(OUT/'bundle-r1.json')
entries={name:0 for name in bundle.images}
for name,image in bundle.images.items():
 delegate=image._entry
 def counted(*args,name=name,delegate=delegate):
  entries[name]+=1
  return delegate(*args)
 image._entry=counted
def absent(*args,**kwargs):raise AssertionError('retained nominal owner invoked')
rows=[];start=time.monotonic()
for label,source in [('scalar',simple(version=4)),('task',scalar_task_program())]:
 outcomes=[]
 for native in (False,True):
  owner=None
  with ExitStack() as stack:
   for name in ('_reference_initialize','_reference_function','_reference_parameters','_reference_check_task',
                'loan_origins','_reference_helper','parameters','check_task','fresh','reserve_values',
                'flat_parameters','constant','zeros','drop_padding','helper'):
    stack.enter_context(patch.object(c._Elaborator,name,new=absent))
   if native:stack.enter_context(patch.object(c._Elaborator,'_reference_lower',new=absent))
   try:
    document=deepcopy(source);owner=c._Elaborator(document)
    try:
     result=bundle.lower(owner) if native else owner._reference_lower()
     value={'status':'accepted','core':result}
    except HIAProgramRejected as error:
     value={'status':'rejected','code':error.code,'text':str(error)}
    value['state']=state(owner);outcomes.append(value)
   finally:
    if owner is not None:
     owner._native_function_session.close();owner.types.close()
  row={'label':label,'native':native,'result':outcomes[-1]}
  with (OUT/'smoke-r1-outcomes.jsonl').open('a') as f:f.write(json.dumps(row,sort_keys=True)+'\n')
 assert outcomes[0]==outcomes[1],(label,outcomes)
 rows.append({'label':label,'equal':True,'status':outcomes[1]['status']})
after={n:sha256((ROOT/n).read_bytes()).hexdigest() for n in pins};assert before==after
value={'rows':rows,'native_entries':entries,'seconds':time.monotonic()-start,'source_before':before,'source_after':after,
       'scope':'TWO_DEVELOPMENT_SMOKE_CASES_NOT_FULL_OUTER_ACCEPTANCE'}
(OUT/'smoke-r1-summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
