"""Freeze the already completed stage2 source, compile and smoke evidence only."""
from hashlib import sha256
import json
from pathlib import Path
import stat
import tarfile

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE.parent / 'hia-outer-stage2-development.tar.xz'
CUSTODY = HERE.parent / 'hia-outer-stage2-development-custody.json'

assert not ARCHIVE.exists() and not CUSTODY.exists()
stage = json.loads((HERE / 'stage2-source.json').read_bytes())
for name, row in stage['files'].items():
    original = Path(row['path']).read_bytes()
    snapshot = Path(row['snapshot']).read_bytes()
    assert original == snapshot and len(snapshot) == row['bytes']
    assert sha256(snapshot).hexdigest() == row['sha256'], name

note = {
    'scope': 'DEVELOPMENT_ONLY_WITH_F50_B3_NOT_CURRENT_COLD_QUALIFICATION',
    'stage2_source_status_is_historical': True,
    'later_smoke': 'two actual comparisons; 28 outer entries; complete group pending',
    'production_files': list(stage['files']),
    'excluded': ['new tests and frame log', 'future native acceptance runs',
                 'external existing function/type/helper dependency bodies'],
    'bundle_recipe_note': ('compile_r1.py is the exact historical two-image compiler driver. '
        'Its initial bundle only included types_source_sha256; the frozen bundle-r1.json '
        'also binds helpers_source_sha256 and all five function_sources_sha256, added before '
        'the smoke. The recorded compiler outputs and receipts are unchanged.'),
    'compiler': {'path': str(HERE.parent / 'hia-f50-compiler-custody/B3.image.bin'),
                 'bytes': 668608,
                 'sha256': '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'},
}
(HERE / 'stage2-package-note.json').write_text(json.dumps(note, indent=2) + '\n')
names = ['baseline.json', 'design-stage0.json', 'stage1-source.json', 'stage2-source.json',
         'stage2-package-note.json', 'compile_r1.py', 'compile-r1.json', 'compile-r1.log',
         'bundle-r1.json', 'generation-r1.log', 'generation-r1-final.log',
         'smoke_r1.py', 'smoke-r1.log', 'smoke-r1-outcomes.jsonl', 'smoke-r1-summary.json',
         'pack_stage2.py']
for directory in ('source-r1', 'owner-r1', 'render-r1'):
    names.extend(str(path.relative_to(HERE)) for path in (HERE / directory).rglob('*') if path.is_file())
names = sorted(names)
assert len(names) == len(set(names))
members = {}
for name in names:
    path = HERE / name
    data = path.read_bytes()
    members[name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest(),
                     'mode': stat.S_IMODE(path.stat().st_mode)}
with tarfile.open(ARCHIVE, 'w:xz', preset=6) as archive:
    for name in names:
        archive.add(HERE / name, arcname=name, recursive=False)
with tarfile.open(ARCHIVE, 'r:xz') as archive:
    observed = archive.getmembers()
    assert [member.name for member in observed] == names
    for member in observed:
        expected = members[member.name]
        raw = archive.extractfile(member).read()
        assert raw == (HERE / member.name).read_bytes()
        assert len(raw) == expected['bytes'] and sha256(raw).hexdigest() == expected['sha256']
        assert member.mode == expected['mode'] and member.isfile()
for name, row in stage['files'].items():
    assert sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], name
raw = ARCHIVE.read_bytes()
custody = {'archive': str(ARCHIVE), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
           'member_count': len(members), 'raw_bytes': sum(row['bytes'] for row in members.values()),
           'each_member_original_bytes_sha256_mode_readback': True, 'members': members,
           'scope': note['scope']}
CUSTODY.write_text(json.dumps(custody, indent=2) + '\n')
print(json.dumps({key: value for key, value in custody.items() if key != 'members'}, indent=2))
