"""Actual-image witness of the independently identified r1 lease/header gap."""
from copy import deepcopy
import ctypes
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import struct

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-outer-next')
HERE = Path(__file__).resolve().parent
RECOVERED = HERE.parent / 'hia-function-recovery/frozen-inputs/native-inputs'
sys.path.insert(0, str(ROOT))
from hepta import hia_program_composite as c
from hepta.hia_composite_outer_native import installed_composite_outer
from hepta.hia_program import HIAProgramRejected
from tests.test_hia_program_composite import scalar_task_program
from tests.test_hia_composite_function_terms_native import state

os.environ.update(
    HEPTA_HIA_COMPOSITE_CONSTRUCTOR_MANIFEST=str(HERE.parent / 'hia-constructor-native-development/bundle-r1.json'),
    HEPTA_HIA_COMPOSITE_FUNCTIONS_MANIFEST=str(RECOVERED / 'hia-function-native-development/bundle-current.json'),
    HEPTA_HIA_COMPOSITE_TYPES_MANIFEST=str(RECOVERED / 'native-signature-development/manifest-r2.json'),
    HEPTA_HIA_TASK_HELPERS_MANIFEST=str(RECOVERED / 'native-helper-development/manifest.json'),
    HEPTA_HIA_COMPOSITE_OUTER_MANIFEST='')
output = HERE / 'helper-header-fault-r1.json'
assert not output.exists()
pins = json.loads((HERE / 'stage2-source.json').read_bytes())['files']
before = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in pins}
assert all(before[name] == row['sha256'] for name, row in pins.items())
bundle = installed_composite_outer(HERE / 'bundle-r1.json')
rows = []
for changed in (False, True):
    owner = c._Elaborator(deepcopy(scalar_task_program()))
    original = owner._native_function_session.helpers
    calls = []
    replacement = type('ActualHelperFaultControl', (), {})()
    def actual_entry(source, size, target, capacity, workspace, workspace_size):
        raw = ctypes.string_at(source, size)
        extent = original._entry(source, size, target, capacity, workspace, workspace_size)
        initial = struct.unpack_from('<8Q', target)
        # The only injected fault: a fresh, in-range header serial one above the
        # real image's serial; original workspace and complete payload untouched.
        if changed and not calls:
            assert 64 <= extent <= capacity and 0 <= initial[2] < 8192
            struct.pack_into('<Q', target, 16, initial[2] + 1)
        calls.append({'extent': extent, 'header_before': list(initial),
                      'header_after': list(struct.unpack_from('<8Q', target)),
                      'workspace_prefix_hex': ctypes.string_at(workspace, 64).hex(),
                      'source_sha256': sha256(raw).hexdigest(),
                      'source_unchanged': ctypes.string_at(source, size) == raw})
        return extent
    replacement._entry = actual_entry
    owner._native_function_session.helpers = replacement
    try:
        try:
            core = bundle.lower(owner)
            outcome = {'status': 'accepted', 'core': core}
        except HIAProgramRejected as error:
            outcome = {'status': 'rejected', 'error': [error.code, str(error)]}
        outcome['state'] = state(owner)
        rows.append({'fault_injected': changed, 'calls': calls, 'outcome': outcome})
    finally:
        owner._native_function_session.close()
        owner.types.close()
after = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in pins}
assert before == after
value = {'scope': 'DEVELOPMENT_ABI_FAULT_WITNESS_NOT_PUBLIC_SOURCE_REGRESSION',
         'source_before': before, 'source_after': after, 'rows': rows,
         'initial_control_accepted': rows[0]['outcome']['status'] == 'accepted',
         'fault_was_accepted': rows[1]['outcome']['status'] == 'accepted'}
output.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({key: value for key, value in value.items() if key not in ('rows', 'source_before', 'source_after')}))
