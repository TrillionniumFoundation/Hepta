"""Seal a new top-level evidence package without rewriting any source file."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import tarfile

BASE = Path('/var/tmp/hia9acdfa-v62-f50b3754')
QUALIFICATION = BASE / 'qualification'
PREPARATION = BASE / 'preparation/preparation.json'
ARCHIVE = BASE / 'f50b3754-top-level-qualification-evidence-20261111.tar.xz'
MANIFEST = BASE / 'f50b3754-top-level-qualification-evidence-20261111.manifest.json'
PARTIAL = BASE / 'f50b3754-top-level-qualification-evidence-20261111.tar.xz.partial'
MANIFEST_PARTIAL = BASE / 'f50b3754-top-level-qualification-evidence-20261111.manifest.json.partial'
REPORT_SHA256 = '350642894d8a0e42cf686661a1f42f1ad49c1a25324f99fbea4d37bdc1aa1ff4'
REPORT_BYTES = 508277
PREPARATION_SHA256 = 'b79286480cf85f5a0d6299bfed0fb08d231e33c65dc1a747dc3ed848d15da36c'


def identity(info):
    return {'device': info.st_dev, 'inode': info.st_ino, 'mode': info.st_mode,
            'uid': info.st_uid, 'gid': info.st_gid, 'links': info.st_nlink,
            'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}


def ordinary_open(path, expected=None):
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise ValueError('symlink in evidence path: ' + str(path))
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    info = os.fstat(descriptor)
    if not stat.S_ISREG(info.st_mode):
        os.close(descriptor)
        raise ValueError('evidence is not an ordinary file: ' + str(path))
    if identity(path.lstat()) != identity(info) or (expected is not None and identity(info) != expected):
        os.close(descriptor)
        raise ValueError('evidence identity changed: ' + str(path))
    return os.fdopen(descriptor, 'rb'), identity(info)


def hash_ordinary(path, expected=None):
    stream, before = ordinary_open(path, expected)
    state, size = sha256(), 0
    with stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            state.update(block)
            size += len(block)
        if size != before['bytes'] or identity(os.fstat(stream.fileno())) != before or identity(path.lstat()) != before:
            raise ValueError('evidence changed during read: ' + str(path))
    return state.hexdigest(), before


class ObservedReader:
    def __init__(self, stream):
        self.stream, self.digest, self.bytes = stream, sha256(), 0

    def read(self, size):
        block = self.stream.read(size)
        self.digest.update(block)
        self.bytes += len(block)
        return block


def main():
    for path in (ARCHIVE, MANIFEST, PARTIAL, MANIFEST_PARTIAL):
        if path.exists() or path.is_symlink():
            raise FileExistsError('new evidence paths required: ' + str(path))
    top = sorted(QUALIFICATION.iterdir(), key=lambda path: path.name)
    sources, excluded = [], []
    for path in top:
        info = path.lstat()
        if stat.S_ISREG(info.st_mode):
            sources.append((path, 'qualification/' + path.name, identity(info)))
        else:
            excluded.append({'path': str(path), 'reason': 'not a top-level regular file',
                             'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'symlink' if stat.S_ISLNK(info.st_mode) else 'other'})
    report = QUALIFICATION / 'QUALIFICATION.json'
    report_hash, report_info = hash_ordinary(report)
    if report_hash != REPORT_SHA256 or report_info['bytes'] != REPORT_BYTES:
        raise ValueError('completed f50 final report identity differs')
    qualification = json.loads(report.read_bytes())
    if (qualification['schema'] != 'hepta.hia.native-rewrite-qualification.v3'
            or qualification['status'] != 'FULL_RETAINED_PASS'
            or qualification['source_identity']['head'] != 'f50b37543d1a379353267ce0ab7111242806b8b4'
            or qualification['source_identity']['tree'] != 'dcecb93e67ee4b9a7d9b26458dbcffbd602a7b09'
            or len(qualification['source_manifest']) != 2628
            or len(qualification['cold_source_manifest']) != 570
            or qualification['whole_native_delivery_qualified'] is not False
            or any(qualification[key] is not True for key in (
                'source_preserved', 'harness_preserved', 'cold_qualified',
                'full_retained_regression_requested', 'full_retained_regression_executed',
                'full_retained_regression_qualified'))
            or len(qualification['steps']) != 22
            or any(step['passed'] is not True or step['returncode'] != 0 or step['timeout'] is not False
                   for step in qualification['steps'])):
        raise ValueError('completed f50 qualification claims do not match the bound run')
    snapshot_hash = '2c90fbb9a45472707d3daf09b594174626af357704bf266a40943d970b6902cd'
    for name in ('source-before.json', 'source-after.json'):
        current, _ = hash_ordinary(QUALIFICATION / name)
        if current != snapshot_hash:
            raise ValueError('complete f50 source snapshot differs: ' + name)
    suite_raw = (QUALIFICATION / 'full-retained-regression.json').read_bytes()
    if sha256(suite_raw).hexdigest() != 'a84a8a4a05a73655448ddf6c7e5dcc6b36b9a3e376319aab95b6ec458f230ab5':
        raise ValueError('full retained result differs from the independently read record')
    suite = json.loads(suite_raw)
    if (suite['tests_run'] != 3985 or suite['successful'] is not True or any(suite[key] != [] for key in (
            'errors', 'failures', 'skipped', 'expected_failures', 'unexpected_successes'))):
        raise ValueError('full retained result contains an anomaly')
    preparation_hash, preparation_info = hash_ordinary(PREPARATION)
    if preparation_hash != PREPARATION_SHA256:
        raise ValueError('reviewed preparation JSON changed')
    sources.append((PREPARATION, 'preparation/preparation.json', preparation_info))
    additional = [
        (BASE / 'source-fetch.json', 'source-fetch.json',
         '91990e24b1b6ce274989e250dd4d861e91518997c9a9e979c034f3013a9faaa9'),
        (BASE / 'source-fetch-identity.json', 'source-fetch-identity.json',
         '2c90fbb9a45472707d3daf09b594174626af357704bf266a40943d970b6902cd'),
        (BASE / 'preparation/launch.py', 'preparation/launch.py',
         '8bd77bec75bf3a570699db583ae955018d1d1e2cc78d52d117df15d7ebf06051')]
    for path, name, expected_sha256 in additional:
        actual, info = hash_ordinary(path)
        if actual != expected_sha256:
            raise ValueError('reviewed source/preparation binding changed: ' + name)
        sources.append((path, name, info))
    rows = []
    with PARTIAL.open('xb') as packed:
        with tarfile.open(fileobj=packed, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for path, name, expected in sources:
                stream, before = ordinary_open(path, expected)
                with stream:
                    reader = ObservedReader(stream)
                    info = tarfile.TarInfo(name)
                    info.type = tarfile.REGTYPE
                    info.size = before['bytes']
                    info.mode = stat.S_IMODE(before['mode'])
                    info.uid, info.gid = before['uid'], before['gid']
                    seconds, nanoseconds = divmod(before['mtime_ns'], 1000000000)
                    info.mtime = seconds
                    info.pax_headers = {'mtime': str(seconds) + '.' + str(nanoseconds).zfill(9)}
                    archive.addfile(info, reader)
                    if (reader.bytes != before['bytes'] or identity(os.fstat(stream.fileno())) != before
                            or identity(path.lstat()) != before):
                        raise ValueError('evidence changed while packaging: ' + str(path))
                    rows.append({'member': name, 'source_path': str(path), 'bytes': reader.bytes,
                                 'sha256': reader.digest.hexdigest(), 'mode': info.mode,
                                 'source_identity': before})
        packed.flush()
        os.fsync(packed.fileno())
    expected_members = {row['member']: row for row in rows}
    with tarfile.open(PARTIAL, 'r:xz') as archive:
        members = archive.getmembers()
        if len(members) != len(expected_members) or {member.name for member in members} != set(expected_members):
            raise ValueError('archive member inventory differs')
        for member in members:
            expected = expected_members[member.name]
            if not member.isreg() or member.size != expected['bytes'] or member.mode != expected['mode']:
                raise ValueError('archive member type/size/mode differs')
            state = sha256()
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    state.update(block)
            if state.hexdigest() != expected['sha256']:
                raise ValueError('archive member bytes differ')
    for row in rows:
        current, _ = hash_ordinary(Path(row['source_path']), row['source_identity'])
        if current != row['sha256']:
            raise ValueError('original evidence changed after archive replay')
    if [path.name for path in sorted(QUALIFICATION.iterdir(), key=lambda path: path.name)] != [path.name for path in top]:
        raise ValueError('qualification top-level inventory changed')
    packed_hash, packed_info = hash_ordinary(PARTIAL)
    document = {'schema': 'hepta.hia.f50-top-level-qualification-evidence.v1',
                'created_utc': datetime.now(timezone.utc).isoformat(), 'host': 'rog',
                'commit': 'f50b37543d1a379353267ce0ab7111242806b8b4',
                'original_qualification_job_id': '1a1c9212aad-135c4-408',
                'qualification_report_sha256': REPORT_SHA256,
                'qualification_report_bytes': REPORT_BYTES,
                'source_tree': 'dcecb93e67ee4b9a7d9b26458dbcffbd602a7b09',
                'source_git_blob_count': 2628,
                'archive': {'path': str(ARCHIVE), 'bytes': packed_info['bytes'], 'sha256': packed_hash,
                            'format': 'tar.xz'},
                'members': rows, 'member_count': len(rows), 'unpacked_bytes': sum(row['bytes'] for row in rows),
                'excluded_nonregular_top_entries': excluded,
                'preparation': {'included': True, 'source_sha256': PREPARATION_SHA256,
                                'review_scope': 'Preparation metadata, executable/package identities and test environment variable names; no credential values identified.'},
                'every_member_replayed_and_hashed': True,
                'every_original_identity_and_digest_rechecked_after_replay': True,
                'original_files_modified': False, 'qualification_reexecuted': False,
                'qualification_child_directories_included': False,
                'explicit_additional_members': [name for _, name, _ in additional],
                'new_qualification_authority_claimed': False}
    with MANIFEST_PARTIAL.open('x', encoding='utf-8') as stream:
        json.dump(document, stream, indent=2, sort_keys=True)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    # No replacement. Each hard-link publication names the sealed new inode;
    # only the temporary names created by this operation are then removed.
    os.link(PARTIAL, ARCHIVE)
    os.link(MANIFEST_PARTIAL, MANIFEST)
    PARTIAL.unlink()
    MANIFEST_PARTIAL.unlink()
    parent = os.open(BASE, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)
    final_hash, final_info = hash_ordinary(ARCHIVE)
    if final_hash != packed_hash or final_info['bytes'] != packed_info['bytes'] or final_info['links'] != 1:
        raise ValueError('published archive differs')
    manifest_hash, manifest_info = hash_ordinary(MANIFEST)
    print(json.dumps({'status': 'SEALED_TOP_LEVEL_EVIDENCE', 'archive': document['archive'],
                      'manifest_path': str(MANIFEST), 'manifest_bytes': manifest_info['bytes'],
                      'manifest_sha256': manifest_hash, 'member_count': len(rows),
                      'unpacked_bytes': document['unpacked_bytes'],
                      'excluded_entry_count': len(excluded)}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
