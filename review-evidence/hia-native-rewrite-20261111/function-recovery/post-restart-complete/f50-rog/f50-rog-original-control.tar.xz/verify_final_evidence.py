"""Independently replay the f50 top-level evidence archive and its source pins.

This does not rerun native code, a test, or a qualification. Child evidence
directories are deliberately outside this package and are named as such.
"""
from decimal import Decimal
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import re
import subprocess
import tarfile

CONTROL = Path(__file__).resolve().parent
BASE = CONTROL.parent
OUT = BASE / 'f50-rog-final-evidence'
REMOTE = '/var/tmp/hia9acdfa-v62-f50b3754'
PIN = 'f50b37543d1a379353267ce0ab7111242806b8b4'
TREE = 'dcecb93e67ee4b9a7d9b26458dbcffbd602a7b09'
SNAPSHOT_SHA = '2c90fbb9a45472707d3daf09b594174626af357704bf266a40943d970b6902cd'
REPORT_SHA = '350642894d8a0e42cf686661a1f42f1ad49c1a25324f99fbea4d37bdc1aa1ff4'
ARCHIVE_SHA = '4a502c4b6d8543c83ad3eb18edcc0dedf55dd20e9e847ac0e99d6a19163e7155'
MANIFEST_SHA = '5a7329df02d4439067ba18f0a98bb940ee9b0fb02e27c6fe60b03fc31ffd4189'
ANOMALIES = ('errors', 'failures', 'skipped', 'expected_failures', 'unexpected_successes')


def digest(raw):
    return sha256(raw).hexdigest()


def json_save(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    if path.exists():
        assert path.read_bytes() == raw, str(path)
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def raw_save(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, str(path)
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def main():
    packed = (OUT / 'raw-qualification.tar.xz').read_bytes()
    manifest_raw = (OUT / 'remote-member-manifest.json').read_bytes()
    assert len(packed) == 349432 and digest(packed) == ARCHIVE_SHA
    assert len(manifest_raw) == 56202 and digest(manifest_raw) == MANIFEST_SHA
    manifest = json.loads(manifest_raw)
    assert manifest['schema'] == 'hepta.hia.f50-top-level-qualification-evidence.v1'
    assert manifest['commit'] == PIN and manifest['source_tree'] == TREE
    assert manifest['source_git_blob_count'] == 2628
    assert manifest['original_qualification_job_id'] == '1a1c9212aad-135c4-408'
    assert manifest['archive']['sha256'] == ARCHIVE_SHA and manifest['archive']['bytes'] == len(packed)
    assert manifest['qualification_report_sha256'] == REPORT_SHA and manifest['qualification_report_bytes'] == 508277
    for key in ('every_member_replayed_and_hashed', 'every_original_identity_and_digest_rechecked_after_replay'):
        assert manifest[key] is True
    for key in ('original_files_modified', 'qualification_reexecuted', 'qualification_child_directories_included', 'new_qualification_authority_claimed'):
        assert manifest[key] is False
    expected_members = {row['member']: row for row in manifest['members']}
    assert len(expected_members) == len(manifest['members']) == manifest['member_count']
    payloads, ledger = {}, []
    with tarfile.open(OUT / 'raw-qualification.tar.xz', 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(expected_members) and {m.name for m in members} == set(expected_members)
        for member in members:
            parts = PurePosixPath(member.name)
            assert not parts.is_absolute() and '..' not in parts.parts and member.isreg()
            row = expected_members[member.name]
            assert member.size == row['bytes'] and member.mode == row['mode']
            identity = row['source_identity']
            assert member.uid == identity['uid'] and member.gid == identity['gid']
            assert int(Decimal(member.pax_headers['mtime']) * 1000000000) == identity['mtime_ns']
            assert row['source_path'] == REMOTE + '/' + member.name
            with archive.extractfile(member) as stream:
                raw = stream.read()
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
            payloads[member.name] = raw
            ledger.append({'member': member.name, 'bytes': len(raw), 'sha256': digest(raw),
                           'mode': member.mode, 'uid': member.uid, 'gid': member.gid,
                           'mtime_ns': identity['mtime_ns']})
    assert sum(len(raw) for raw in payloads.values()) == manifest['unpacked_bytes']
    for name in payloads:
        if name.startswith('qualification/'):
            assert len(PurePosixPath(name).parts) == 2

    def get(name):
        return json.loads(payloads[name])

    def recorded(record):
        assert record['path'].startswith(REMOTE + '/')
        name = record['path'][len(REMOTE) + 1:]
        raw = payloads[name]
        assert digest(raw) == record['sha256']
        return raw

    report_raw = payloads['qualification/QUALIFICATION.json']
    assert len(report_raw) == 508277 and digest(report_raw) == REPORT_SHA
    report = json.loads(report_raw)
    assert report['schema'] == 'hepta.hia.native-rewrite-qualification.v3'
    assert report['status'] == 'FULL_RETAINED_PASS'
    assert report['whole_native_delivery_qualified'] is False
    for key in ('source_preserved', 'harness_preserved', 'cold_qualified', 'full_retained_regression_requested',
                'full_retained_regression_executed', 'full_retained_regression_qualified'):
        assert report[key] is True
    assert report['cold_error'] is None
    source_raw = (CONTROL / 'independent-expected-source-state.json').read_bytes()
    assert len(source_raw) == 344476 and digest(source_raw) == SNAPSHOT_SHA
    expected_source = json.loads(source_raw)
    assert expected_source['head'] == PIN and expected_source['tree'] == TREE and expected_source['status'] == ''
    assert len(expected_source['files']) == 2628 and report['source_manifest'] == expected_source['files']
    for name in ('qualification/source-before.json', 'qualification/source-after.json', 'source-fetch-identity.json'):
        assert payloads[name] == source_raw
    assert report['source_identity']['head'] == PIN and report['source_identity']['tree'] == TREE
    assert report['source_identity']['raw_git_tree_blobs_and_modes_checked'] is True
    assert recorded(report['source_identity']['before']) == recorded(report['source_identity']['after']) == source_raw
    expected_harness = {
        'runner': {'path': REMOTE + '/source/review-evidence/hia-native-rewrite-20261111/run_hia_qualification_v3.py',
                   'sha256': '52e1fa90009fe329c57806e1e4006c09bba9635e2c4394e9f71fcafe59862838'},
        'workflow_process': {'path': REMOTE + '/source/review-evidence/hia-native-rewrite-20261111/workflow_process.py',
                             'sha256': 'f3ebc453de2d2c9ecd3825547e301c122b6c7fa05af1aacd9103b8a67893ee80'}}
    assert report['harness_identity_before'] == report['harness_identity_after'] == expected_harness
    assert get('qualification/harness-before.json') == expected_harness
    assert digest(payloads['preparation/preparation.json']) == 'b79286480cf85f5a0d6299bfed0fb08d231e33c65dc1a747dc3ed848d15da36c'
    assert digest(payloads['preparation/launch.py']) == '8bd77bec75bf3a570699db583ae955018d1d1e2cc78d52d117df15d7ebf06051'
    assert digest(payloads['source-fetch.json']) == '91990e24b1b6ce274989e250dd4d861e91518997c9a9e979c034f3013a9faaa9'
    preparation = get('preparation/preparation.json')
    assert preparation['status'] == 'READY' and preparation['missing'] == [] and preparation['source'] == REMOTE + '/source'
    temp = preparation['checks']['temporary_directory']
    assert temp['path'] == '/var/tmp/h9v62f' and temp['actual_AF_UNIX_round_trip'] is True
    reproduction = json.loads(recorded(report['source_reproduction']))
    assert reproduction['schema'] == 'hepta.hia.complete-source-reproduction.v1'
    assert reproduction['status'] == 'SOURCE_REPRODUCTION_PASS'
    assert reproduction['before'] == reproduction['after'] == expected_source
    assert reproduction['expected_snapshot_sha256'] == SNAPSHOT_SHA
    assert reproduction['identical_to_tested_source'] is True and reproduction['raw_git_tree_blobs_and_modes_checked'] is True
    workflow = subprocess.check_output(['git', '--no-replace-objects', '-C', str(BASE / 'Hepta'),
                                        'show', PIN + ':.github/workflows/hia-core.yml']).decode()
    generators = re.search(r'for component in ([^;]+); do', workflow).group(1).split()
    assert generators and reproduction['generators'] == generators
    contract_raw = subprocess.check_output(['git', '--no-replace-objects', '-C', str(BASE / 'Hepta'),
                                            'show', PIN + ':docs/HIA_SELFHOST_CORE_SUPPORT.json'])
    assert digest(contract_raw) == '61406b5741d467e0041d8c76d0ecc14372bad7e4963dbd1846ce8b6a790e27aa'
    cold_sources = {**json.loads(contract_raw)['source_identity']['files'],
                    'docs/HIA_SELFHOST_CORE_SUPPORT.json': digest(contract_raw)}
    assert len(cold_sources) == 570 and report['cold_source_manifest'] == cold_sources
    assert digest(json.dumps(cold_sources, sort_keys=True, separators=(',', ':')).encode()) == '6bd4071a2e94eb8ec0ae305cd92861a15a9f53263ba397712b3a2f27b3c9700f'
    cold_raw = recorded(report['cold_report'])
    assert digest(cold_raw) == '9fd729d54bf593bde43db65c415653f4147ca9675618d36ef6ea0a80bd70cd28'
    cold = json.loads(cold_raw)
    assert cold['status'] == 'COLD_SELFHOST_REPLAY_PASS' and cold['returncode'] == 0
    assert cold['source_manifest'] == cold_sources and len(cold['checks']) == 11 and all(v is True for v in cold['checks'].values())
    assert cold['qualification_wall_limit_seconds'] == 180 and cold['cleanup_wall_limit_seconds'] == 3
    assert cold['wall_elapsed_ns'] == 95514395310
    cleanup = cold['process_owner']['cleanup']
    assert cleanup['complete'] is True and cleanup['observed_echild'] is True
    assert cleanup['errors'] == cleanup['remaining_direct_children'] == [] and cleanup['elapsed_ns'] == 22512346
    language = get('qualification/language.json')
    assert language['schema'] == 'hepta.hia.selfhost-language-qualification.v1'
    assert language['status'] == 'SELFHOST_LANGUAGE_COVERAGE_PASS' and language['source_manifest'] == cold_sources
    assert len(language['checks']) == 1242 and all(v is True for v in language['checks'].values())
    expected_steps = ['source-reproduction', 'source-contract', 'source-scope', 'source-tests', 'cold', 'language',
                      'native-applications', 'module-graph', 'workspace', 'capability', 'workspace-facts',
                      'function-shape', 'program-shape', 'instruction-policy', 'publication', 'core-admission',
                      'core-cli', 'patch', 'agent-candidate', 'patch-result-cli', 'composite-types', 'full-retained-regression']
    assert [step['name'] for step in report['steps']] == expected_steps
    assert get('qualification/steps.json') == report['steps']
    suites, owners = [], []
    for step in report['steps']:
        name = step['name']
        assert step['passed'] is True and step['returncode'] == 0 and step['timeout'] is False
        stdout, stderr = recorded(step['stdout']), recorded(step['stderr'])
        owner = get('qualification/' + name + '.owner.json')
        assert owner == step['owner'] and owner['schema'] == 'hepta.hia.external-workflow-process.v1'
        assert owner['status'] == 'WORKFLOW_STEP_COMPLETED' and owner['returncode'] == 0 and owner['timed_out'] is False
        assert owner['command'] == step['command'] and owner['cwd'] == REMOTE + '/source'
        assert owner['workflow_seconds'] == (5400 if name == 'full-retained-regression' else 240 if name == 'cold' else 1800)
        assert owner['cleanup']['complete'] is True and owner['cleanup']['errors'] == owner['cleanup']['signalled'] == []
        assert owner['cleanup']['full_process_tree_claimed'] is False and owner['selfhost_qualification_gate_modified'] is False
        assert owner['logs'] == {step['stdout']['path']: digest(stdout), step['stderr']['path']: digest(stderr)}
        owners.append({'name': name, 'seconds': step['seconds'], 'owner_sha256': digest(payloads['qualification/' + name + '.owner.json']),
                       'stdout_bytes': len(stdout), 'stdout_sha256': digest(stdout), 'stderr_bytes': len(stderr), 'stderr_sha256': digest(stderr)})
        if 'suite_result' in step:
            summary = step['suite_result']
            assert summary['completed'] is True and summary['passed'] is True
            value = json.loads(recorded(summary['result']))
            assert type(value['tests_run']) is int and value['tests_run'] > 0 and value['successful'] is True
            assert summary['tests_run'] == value['tests_run'] and all(value[key] == [] for key in ANOMALIES)
            matches = list(re.finditer(r'^Ran (\d+) tests? in ([\d.]+)s\s*$', stderr.decode(), re.M))
            assert matches and int(matches[-1].group(1)) == value['tests_run']
            following = [line.strip() for line in stderr.decode()[matches[-1].end():].splitlines() if line.strip()]
            assert following and following[0] == 'OK'
            suites.append({'name': name, 'tests': value['tests_run'], 'all_five_anomaly_arrays_empty': True,
                           'structured_result_sha256': summary['result']['sha256'], 'outer_raw_unittest_summary': 'OK'})
    full = get('qualification/full-retained-regression.json')
    assert full['tests_run'] == 3985 and report['full_retained_regression'] == report['steps'][-1]['suite_result']
    assert digest(payloads['qualification/full-retained-regression.json']) == 'a84a8a4a05a73655448ddf6c7e5dcc6b36b9a3e376319aab95b6ec458f230ab5'
    assert any(s['name'] == 'source-tests' and s['tests'] == 280 for s in suites)
    assert any(s['name'] == 'native-applications' and s['tests'] == 242 for s in suites)
    assert any(s['name'] == 'composite-types' and s['tests'] == 53 for s in suites)
    selected = ('QUALIFICATION.json', 'full-retained-regression.json', 'full-retained-regression.stdout.log',
                'full-retained-regression.stderr.log', 'source-before.json', 'source-after.json',
                'harness-before.json', 'source-reproduction.json', 'cold.json', 'language.json')
    for name in selected:
        raw_save(OUT / name, payloads['qualification/' + name])
    json_save(OUT / 'harness-after-derived-from-report.json', {'origin': 'QUALIFICATION.json.harness_identity_after',
              'original_report_sha256': REPORT_SHA, 'value': report['harness_identity_after'], 'separate_remote_file_claimed': False})
    summary = {'schema': 'hepta.hia.f50-full-retained-independent-evidence-review.v1',
               'status': 'FULL_RETAINED_PASS_EVIDENCE_VERIFIED', 'commit': PIN, 'tree': TREE,
               'original_qualification_job': '1a1c9212aad-135c4-408', 'full_retained_tests': 3985,
               'all_five_anomaly_arrays_empty': True, 'all_22_steps_and_raw_owner_logs_verified': True,
               'full_source_blobs': 2628, 'source_snapshot_sha256': SNAPSHOT_SHA, 'source_before_after_exact_bytes_equal': True,
               'source_matches_independent_immutable_git_snapshot': True, 'harness_before_after_matches_pins': True,
               'source_reproduction_generators': len(generators), 'cold_source_files': 570,
               'cold': {'checks_passed': 11, 'checks_total': 11, 'wall_elapsed_ns': cold['wall_elapsed_ns'],
                        'qualification_seconds': 180, 'cleanup_seconds': 3, 'cleanup_elapsed_ns': cleanup['elapsed_ns'],
                        'echild_complete': True}, 'language_checks_passed': 1242, 'suites': suites, 'steps': owners,
               'archive': {'bytes': len(packed), 'sha256': ARCHIVE_SHA, 'members': len(ledger),
                           'raw_bytes': manifest['unpacked_bytes'], 'every_member_payload_size_mode_uid_gid_mtime_verified': True},
               'original_qualification_files_modified': False, 'qualification_rerun': False,
               'whole_native_delivery_qualified': False,
               'scope_limits': ['This package contains top-level qualification regular files and four explicit preparation/source additions only.',
                                'ROG cold/language raw phase archives and other child evidence directories remain outside this package; no local replay of those child members is claimed here.',
                                'The independent GitHub f50 archive audit separately replayed all 38 of its cold phase archives; that is a distinct run.',
                                'A complete retained regression is not whole-language or whole-stack native closure.'],
               'excluded_remote_children': manifest['excluded_nonregular_top_entries']}
    json_save(OUT / 'summary.json', summary)
    json_save(OUT / 'member-readback.json', {'schema': 'hepta.hia.f50-all-member-readback.v1', 'archive_sha256': ARCHIVE_SHA,
              'remote_manifest_sha256': MANIFEST_SHA, 'members': ledger, 'all_verified': True})
    json_save(OUT / 'custody.json', {'schema': 'hepta.hia.f50-full-retained-evidence-custody.v1',
              'qualification_job': '1a1c9212aad-135c4-408', 'evidence_package_job': '1a1c94d581d-2564-45',
              'evidence_package_request_digest': 'd7352a9eaa765a11018aab7c054116faa126a507714b28fcaca630407e3fae9e',
              'source_and_report_pins': {'commit': PIN, 'tree': TREE, 'complete_source_snapshot_sha256': SNAPSHOT_SHA,
                                        'qualification_report_sha256': REPORT_SHA},
              'remote_archive_sha256': ARCHIVE_SHA, 'remote_manifest_sha256': MANIFEST_SHA,
              'all_members_replayed': True, 'source_before_after_readback_equal': True,
              'qualification_status': summary['status'], 'whole_native_delivery_qualified': False,
              'outputs': {p.name: {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
                          for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'custody.json'},
              'transport_evidence_directory': str(CONTROL), 'child_evidence_directories_included': False})
    print(json.dumps({'status': summary['status'], 'tests': 3985, 'members': len(ledger),
                      'raw_bytes': manifest['unpacked_bytes'], 'archive_sha256': ARCHIVE_SHA,
                      'summary_sha256': digest((OUT / 'summary.json').read_bytes()),
                      'custody_sha256': digest((OUT / 'custody.json').read_bytes())}, sort_keys=True))


if __name__ == '__main__':
    main()
