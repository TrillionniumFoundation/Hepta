"""Reassemble immutable h.binary_read pages without trusting display text."""
from hashlib import sha256
from pathlib import Path
import argparse
import base64
import json

CONTROL = Path(__file__).resolve().parent
OUTPUT = CONTROL.parent / 'f50-rog-final-evidence'


def native(sdk):
    if sdk.get('isError'):
        return None
    return json.loads(''.join(c['text'] for c in sdk['content'] if c['type'] == 'text'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=('archive', 'manifest'))
    args = parser.parse_args()
    receipt = json.loads((CONTROL / 'remote-package-metadata.json').read_bytes())
    if args.kind == 'archive':
        expected = receipt['archive']
        target = OUTPUT / 'raw-qualification.tar.xz'
    else:
        expected = {'path': receipt['manifest_path'], 'bytes': receipt['manifest_bytes'],
                    'sha256': receipt['manifest_sha256']}
        target = OUTPUT / 'remote-member-manifest.json'
    pages, attempts, version = {}, [], None
    for path in sorted(CONTROL.glob('download-' + args.kind + '-*.sdk.json')):
        sdk_bytes = path.read_bytes()
        result = native(json.loads(sdk_bytes))
        row = {'sdk': path.name, 'sdk_bytes': len(sdk_bytes), 'sdk_sha256': sha256(sdk_bytes).hexdigest()}
        if result is None:
            row['tool_error'] = True
            attempts.append(row)
            continue
        raw = base64.b64decode(result['data_base64'], validate=True)
        assert result['path'] == expected['path'] and result['size'] == expected['bytes']
        assert result['next_offset'] - result['offset'] == len(raw)
        assert sha256(raw).hexdigest() == result['chunk_sha256']
        assert result['eof'] is (result['next_offset'] == expected['bytes'])
        if version is None:
            version = result['version']
        assert result['version'] == version
        if result['offset'] in pages:
            assert pages[result['offset']] == raw
        pages[result['offset']] = raw
        row.update(offset=result['offset'], bytes=len(raw), sha256=sha256(raw).hexdigest(),
                   next_offset=result['next_offset'], version=version)
        attempts.append(row)
    cursor, digest = 0, sha256()
    chunks = []
    for offset, raw in sorted(pages.items()):
        if offset != cursor:
            break
        chunks.append(raw)
        digest.update(raw)
        cursor += len(raw)
    complete = cursor == expected['bytes']
    if complete:
        assert digest.hexdigest() == expected['sha256']
        OUTPUT.mkdir(exist_ok=True)
        if target.exists():
            assert target.stat().st_size == cursor and sha256(target.read_bytes()).hexdigest() == expected['sha256']
        else:
            with target.open('xb') as stream:
                for raw in chunks:
                    stream.write(raw)
            assert target.stat().st_size == cursor and sha256(target.read_bytes()).hexdigest() == expected['sha256']
    proof = {'schema': 'hepta.hia.immutable-chunk-download-replay.v1', 'kind': args.kind,
             'remote': expected, 'version': version, 'contiguous_bytes_verified': cursor,
             'unique_chunks': len(pages), 'attempt_count': len(attempts), 'complete': complete,
             'whole_sha256_verified': complete, 'target': str(target), 'attempts': attempts}
    (CONTROL / (args.kind + '-download-custody.json')).write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in proof.items() if key != 'attempts'}, sort_keys=True))


if __name__ == '__main__':
    main()
