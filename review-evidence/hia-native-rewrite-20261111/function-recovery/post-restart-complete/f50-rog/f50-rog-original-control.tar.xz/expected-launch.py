#!/usr/bin/env python3
"""Apply freshly observed environment; execute only the caller's NEW command."""
from hashlib import sha256
import json, os
from pathlib import Path
import sys
here=Path(__file__).resolve().parent
value=json.loads((here/"environment.json").read_text())
if not value.get("python"):
    raise SystemExit("No pinned user-owned Python venv was admitted; read preparation.json")
temporary=value["temporary_directory"]
temporary_path=Path(temporary["path"])
if any(p.is_symlink() or (p/".git").exists() or (p/".git").is_symlink()
       for p in (temporary_path,*temporary_path.parents)):
    raise SystemExit("Temporary directory gained a symlink or Git ancestor")
observed=temporary_path.stat()
if {"device":observed.st_dev,"inode":observed.st_ino,"uid":observed.st_uid,
    "mode":observed.st_mode} != temporary["identity"]:
    raise SystemExit("Temporary directory identity changed after preparation")
for path,expected in value["recheck_sha256"].items():
    digest=sha256()
    with open(path,"rb") as stream:
        for block in iter(lambda:stream.read(1024*1024),b""): digest.update(block)
    if digest.hexdigest()!=expected:
        raise SystemExit("Prerequisite changed after preparation: "+path)
if len(sys.argv)<2:
    raise SystemExit("usage: launch.py NEW_RUNNER.py [arguments...]")
env={key:val for key,val in os.environ.items()
     if key not in value["unset"] and not key.startswith(tuple(value["unset_prefixes"]))}
env.update(value["set"])
os.chdir(value["source"])
os.execve(value["python"],[value["python"],"-B",*sys.argv[1:]],env)
