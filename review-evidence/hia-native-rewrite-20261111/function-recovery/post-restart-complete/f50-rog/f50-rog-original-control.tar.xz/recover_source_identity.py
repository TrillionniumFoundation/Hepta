from pathlib import Path
from hashlib import sha1,sha256
import json,re,subprocess

out=Path('/dev/shm/hia-v62-f50b3754-qualification-control')
repo=Path('/workspace/scratch/9acdfa9f5639/Hepta')
pin='f50b37543d1a379353267ce0ab7111242806b8b4'
tree='dcecb93e67ee4b9a7d9b26458dbcffbd602a7b09'
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(repo),*args])
raw=git('cat-file','commit',pin)
assert sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin
assert raw.startswith(('tree '+tree+'\n').encode())
(out/'commit.raw').write_bytes(raw)
rows=[]
for entry in git('ls-tree','-r','-z',tree).rstrip(b'\0').split(b'\0'):
 meta,name=entry.split(b'\t');mode,kind,oid=meta.decode().split()
 assert kind=='blob' and mode in ('100644','100755')
 rows.append({'path':name.decode(),'mode':mode,'git_blob_sha':oid})
assert len(rows)==len({r['path'] for r in rows})==2628
ids=sorted({r['git_blob_sha'] for r in rows})
raw=subprocess.check_output(['git','--no-replace-objects','-C',str(repo),'cat-file','--batch'],input=('\n'.join(ids)+'\n').encode())
blobs={};offset=0
for oid in ids:
 end=raw.index(b'\n',offset);head=raw[offset:end].decode().split();assert head[:2]==[oid,'blob']
 n=int(head[2]);offset=end+1;data=raw[offset:offset+n]
 assert len(data)==n and raw[offset+n:offset+n+1]==b'\n';offset+=n+1
 assert sha1(b'blob '+str(n).encode()+b'\0'+data).hexdigest()==oid
 blobs[oid]={'bytes':n,'sha256':sha256(data).hexdigest()}
assert offset==len(raw)
del raw
for row in rows:row.update(blobs[row['git_blob_sha']])
files={r['path']:r['sha256'] for r in rows}
state={'head':pin,'tree':tree,'status':'','files':files}
raw=(json.dumps(state,indent=2,sort_keys=True)+'\n').encode()
assert len(raw)==344476 and sha256(raw).hexdigest()=='2c90fbb9a45472707d3daf09b594174626af357704bf266a40943d970b6902cd'
(out/'independent-expected-source-state.json').write_bytes(raw)
contract_path='docs/HIA_SELFHOST_CORE_SUPPORT.json'
contract=json.loads(git('show',pin+':'+contract_path))
assert files[contract_path]=='61406b5741d467e0041d8c76d0ecc14372bad7e4963dbd1846ce8b6a790e27aa'
cold={**contract['source_identity']['files'],contract_path:files[contract_path]}
assert len(cold)==570 and all(files[k]==v for k,v in cold.items())
assert sha256(json.dumps(cold,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='6bd4071a2e94eb8ec0ae305cd92861a15a9f53263ba397712b3a2f27b3c9700f'
actual=json.loads((out/'cold.json').read_bytes())
assert actual['source_manifest']==cold
result={'schema':'hepta.hia.recovered-immutable-git-identity.v1','commit':pin,'tree':tree,'git_blobs':len(rows),'distinct_blobs':len(ids),'raw_git_blob_sha1_all_checked':True,'content_sha256_all_checked':True,'all_modes_checked':True,'source_snapshot_bytes':len(raw),'source_snapshot_sha256':sha256(raw).hexdigest(),'original_pre_reset_snapshot_exact_match':True,'actual_rog_cold_source_manifest_exact_match':True,'working_tree_files_used':False,'members':rows}
(out/'independent-git-blob-identity.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
workflow=git('show',pin+':.github/workflows/hia-core.yml').decode()
blocks=re.findall(r'          names = \((.*?)\n          \)',workflow,re.S)
names=[re.findall(r"'(tests\.[^']+)'",block) for block in blocks]
assert len(names)==2 and all(names) and 'tests.test_hia_json_preflight_native' in names[1]
prefix='review-evidence/hia-native-rewrite-20261111/'
harness={name:files[prefix+name] for name in ('prepare_remote_qualification_v2.py','run_hia_qualification_v3.py','workflow_process.py')}
expected={'commit':pin,'tree':tree,'git_blob_count':2628,'cold_closure':cold,'cold_closure_member_count':570,'cold_contract_member_count':569,'cold_contract_path':contract_path,'cold_contract_sha256':files[contract_path],'cold_closure_sha256':sha256(json.dumps(cold,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'harness_sha256':harness,'expected_source_snapshot_bytes':len(raw),'expected_source_snapshot_sha256':sha256(raw).hexdigest(),'workflow_groups':names}
(out/'expected-source.json').write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'},sort_keys=True))
