from pathlib import Path
from hashlib import sha256
import base64,json,sys

base=Path('/dev/shm/hia-v62-f50b3754-qualification-control')
label=sys.argv[1]
assert '/' not in label

def text(value):
    assert value.get('isError') is not True,value
    return ''.join(x['text'] for x in value['content'] if x['type']=='text')

outer=json.loads((base/(label+'-operation-result.sdk.json')).read_bytes())
page=json.loads(text(outer))
assert page['offset']==0 and page['eof'] is True
data=base64.b64decode(page['data_base64'],validate=True)
assert len(data)==page['next_offset']==page['total_bytes']
assert sha256(data).hexdigest()==page['result_sha256']
(base/(label+'.native-sdk.raw.json')).write_bytes(data)
native=json.loads(data)
result=json.loads(text(native))
assert result['job_id']=='1a1c9212aad-135c4-408'
(base/(label+'.json')).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
proof={'operation_id':page['operation_id'],'original_sdk_bytes':len(data),'original_sdk_sha256':sha256(data).hexdigest(),'job_id':result['job_id'],'streams':{}}
new={}
for name in ('stdout','stderr'):
    row=result[name]
    raw=bytes.fromhex(row['bytes_hex'])
    assert len(raw)==row['next_offset']-row['offset']
    target=base/('full.'+name+'.log')
    previous=target.read_bytes() if target.exists() else b''
    assert row['offset']<=len(previous)<=row['next_offset']
    assert previous[row['offset']:]==raw[:len(previous)-row['offset']]
    addition=raw[len(previous)-row['offset']:]
    with target.open('ab') as out:out.write(addition)
    actual=target.read_bytes()
    assert len(actual)==row['next_offset']
    proof['streams'][name]={'offset':row['offset'],'next_offset':row['next_offset'],'observed_size':row['size'],'eof_at_observation':row['eof'],'raw_chunk_sha256':sha256(raw).hexdigest(),'accumulated_bytes':len(actual),'accumulated_sha256':sha256(actual).hexdigest()}
    new[name]=addition.decode('utf-8')
(base/(label+'-verified.json')).write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps({'proof':proof,'new_output':new},sort_keys=True))
