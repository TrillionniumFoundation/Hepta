"""Seal a new top-level evidence package without rewriting any source file."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import tarfile

BASE = Path('/var/tmp/hia9acdfa-v61')
QUALIFICATION = BASE / 'qualification'
PREPARATION = BASE / 'preparation/preparation.json'
ARCHIVE = BASE / 'v61-647885c5-top-level-qualification-evidence-20261111.tar.xz'
MANIFEST = BASE / 'v61-647885c5-top-level-qualification-evidence-20261111.manifest.json'
PARTIAL = BASE / 'v61-647885c5-top-level-qualification-evidence-20261111.tar.xz.partial'
MANIFEST_PARTIAL = BASE / 'v61-647885c5-top-level-qualification-evidence-20261111.manifest.json.partial'
REPORT_SHA256 = '902409a9ed1c792f66eb264566b985ad9db6359d325fc49b66706f015e74536e'
REPORT_BYTES = 498912
PREPARATION_SHA256 = '8a0afcd8a80cbb6431a4fbc994e3b78383ab221b8ad3dd0251709c31b424bebb'


def identity(info):
    return {'device': info.st_dev, 'inode': info.st_ino, 'mode': info.st_mode,
            'uid': info.st_uid, 'gid': info.st_gid, 'links': info.st_nlink,
            'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}


def ordinary_open(path, expected=None):
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise ValueError('symlink in evidence path: ' + str(path))
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    info = os.fstat(descriptor)
    if not stat.S_ISREG(info.st_mode):
        os.close(descriptor)
        raise ValueError('evidence is not an ordinary file: ' + str(path))
    if identity(path.lstat()) != identity(info) or (expected is not None and identity(info) != expected):
        os.close(descriptor)
        raise ValueError('evidence identity changed: ' + str(path))
    return os.fdopen(descriptor, 'rb'), identity(info)


def hash_ordinary(path, expected=None):
    stream, before = ordinary_open(path, expected)
    state, size = sha256(), 0
    with stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            state.update(block)
            size += len(block)
        if size != before['bytes'] or identity(os.fstat(stream.fileno())) != before or identity(path.lstat()) != before:
            raise ValueError('evidence changed during read: ' + str(path))
    return state.hexdigest(), before


class ObservedReader:
    def __init__(self, stream):
        self.stream, self.digest, self.bytes = stream, sha256(), 0

    def read(self, size):
        block = self.stream.read(size)
        self.digest.update(block)
        self.bytes += len(block)
        return block


def main():
    for path in (ARCHIVE, MANIFEST, PARTIAL, MANIFEST_PARTIAL):
        if path.exists() or path.is_symlink():
            raise FileExistsError('new evidence paths required: ' + str(path))
    top = sorted(QUALIFICATION.iterdir(), key=lambda path: path.name)
    sources, excluded = [], []
    for path in top:
        info = path.lstat()
        if stat.S_ISREG(info.st_mode):
            sources.append((path, 'qualification/' + path.name, identity(info)))
        else:
            excluded.append({'path': str(path), 'reason': 'not a top-level regular file',
                             'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'symlink' if stat.S_ISLNK(info.st_mode) else 'other'})
    report = QUALIFICATION / 'QUALIFICATION.json'
    report_hash, report_info = hash_ordinary(report)
    if report_hash != REPORT_SHA256 or report_info['bytes'] != REPORT_BYTES:
        raise ValueError('completed v61 final report identity differs')
    preparation_hash, preparation_info = hash_ordinary(PREPARATION)
    if preparation_hash != PREPARATION_SHA256:
        raise ValueError('reviewed preparation JSON changed')
    sources.append((PREPARATION, 'preparation/preparation.json', preparation_info))
    additional = [
        (BASE / 'source-fetch.json', 'source-fetch.json',
         'c96177401ff4741a2f7b5f1727308f7f8ca10a1ccaf205ada0a97e403574b873'),
        (BASE / 'source-fetch-identity.json', 'source-fetch-identity.json',
         '6f8bd9f91bd6e10710f53cf4e66d362fec7e5009a62ba5b824f4eef2a04a5dfa'),
        (BASE / 'preparation/launch.py', 'preparation/launch.py',
         '8bd77bec75bf3a570699db583ae955018d1d1e2cc78d52d117df15d7ebf06051')]
    for path, name, expected_sha256 in additional:
        actual, info = hash_ordinary(path)
        if actual != expected_sha256:
            raise ValueError('reviewed source/preparation binding changed: ' + name)
        sources.append((path, name, info))
    rows = []
    with PARTIAL.open('xb') as packed:
        with tarfile.open(fileobj=packed, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for path, name, expected in sources:
                stream, before = ordinary_open(path, expected)
                with stream:
                    reader = ObservedReader(stream)
                    info = tarfile.TarInfo(name)
                    info.type = tarfile.REGTYPE
                    info.size = before['bytes']
                    info.mode = stat.S_IMODE(before['mode'])
                    info.uid, info.gid = before['uid'], before['gid']
                    seconds, nanoseconds = divmod(before['mtime_ns'], 1000000000)
                    info.mtime = seconds
                    info.pax_headers = {'mtime': str(seconds) + '.' + str(nanoseconds).zfill(9)}
                    archive.addfile(info, reader)
                    if (reader.bytes != before['bytes'] or identity(os.fstat(stream.fileno())) != before
                            or identity(path.lstat()) != before):
                        raise ValueError('evidence changed while packaging: ' + str(path))
                    rows.append({'member': name, 'source_path': str(path), 'bytes': reader.bytes,
                                 'sha256': reader.digest.hexdigest(), 'mode': info.mode,
                                 'source_identity': before})
        packed.flush()
        os.fsync(packed.fileno())
    expected_members = {row['member']: row for row in rows}
    with tarfile.open(PARTIAL, 'r:xz') as archive:
        members = archive.getmembers()
        if len(members) != len(expected_members) or {member.name for member in members} != set(expected_members):
            raise ValueError('archive member inventory differs')
        for member in members:
            expected = expected_members[member.name]
            if not member.isreg() or member.size != expected['bytes'] or member.mode != expected['mode']:
                raise ValueError('archive member type/size/mode differs')
            state = sha256()
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    state.update(block)
            if state.hexdigest() != expected['sha256']:
                raise ValueError('archive member bytes differ')
    for row in rows:
        current, _ = hash_ordinary(Path(row['source_path']), row['source_identity'])
        if current != row['sha256']:
            raise ValueError('original evidence changed after archive replay')
    if [path.name for path in sorted(QUALIFICATION.iterdir(), key=lambda path: path.name)] != [path.name for path in top]:
        raise ValueError('qualification top-level inventory changed')
    packed_hash, packed_info = hash_ordinary(PARTIAL)
    document = {'schema': 'hepta.hia.v61-top-level-qualification-evidence.v1',
                'created_utc': datetime.now(timezone.utc).isoformat(), 'host': 'rog',
                'commit': '647885c5c3ff067b6477011123335ad5a1aef78e',
                'original_qualification_job_id': '1a1c8d5cede-135c4-27a',
                'qualification_report_sha256': REPORT_SHA256,
                'qualification_report_bytes': REPORT_BYTES,
                'source_tree': '1c7679357590a9105c666dea95105780b64098fc',
                'source_git_blob_count': 2587,
                'archive': {'path': str(ARCHIVE), 'bytes': packed_info['bytes'], 'sha256': packed_hash,
                            'format': 'tar.xz'},
                'members': rows, 'member_count': len(rows), 'unpacked_bytes': sum(row['bytes'] for row in rows),
                'excluded_nonregular_top_entries': excluded,
                'preparation': {'included': True, 'source_sha256': PREPARATION_SHA256,
                                'review_scope': 'Preparation metadata, executable/package identities and test environment variable names; no credential values identified.'},
                'every_member_replayed_and_hashed': True,
                'every_original_identity_and_digest_rechecked_after_replay': True,
                'original_files_modified': False, 'qualification_reexecuted': False,
                'qualification_child_directories_included': False,
                'explicit_additional_members': [name for _, name, _ in additional],
                'new_qualification_authority_claimed': False}
    with MANIFEST_PARTIAL.open('x', encoding='utf-8') as stream:
        json.dump(document, stream, indent=2, sort_keys=True)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    # No replacement. Each hard-link publication names the sealed new inode;
    # only the temporary names created by this operation are then removed.
    os.link(PARTIAL, ARCHIVE)
    os.link(MANIFEST_PARTIAL, MANIFEST)
    PARTIAL.unlink()
    MANIFEST_PARTIAL.unlink()
    parent = os.open(BASE, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)
    final_hash, final_info = hash_ordinary(ARCHIVE)
    if final_hash != packed_hash or final_info['bytes'] != packed_info['bytes'] or final_info['links'] != 1:
        raise ValueError('published archive differs')
    manifest_hash, manifest_info = hash_ordinary(MANIFEST)
    print(json.dumps({'status': 'SEALED_TOP_LEVEL_EVIDENCE', 'archive': document['archive'],
                      'manifest_path': str(MANIFEST), 'manifest_bytes': manifest_info['bytes'],
                      'manifest_sha256': manifest_hash, 'member_count': len(rows),
                      'unpacked_bytes': document['unpacked_bytes'],
                      'excluded_entry_count': len(excluded)}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
