from hashlib import sha256
from pathlib import Path
import ast,json,os,re,subprocess,sys
base=Path('/var/tmp/hia9acdfa-v62-f50b3754')
source=base/'source'
commit='f50b37543d1a379353267ce0ab7111242806b8b4'
tree='dcecb93e67ee4b9a7d9b26458dbcffbd602a7b09'
assert subprocess.check_output(['/usr/bin/git','--no-replace-objects','-C',str(source),'rev-parse','HEAD']).decode().strip()==commit
assert subprocess.check_output(['/usr/bin/git','--no-replace-objects','-C',str(source),'rev-parse','HEAD^{tree}']).decode().strip()==tree
preparation_raw=(base/'preparation/preparation.json').read_bytes()
assert sha256(preparation_raw).hexdigest()=='b79286480cf85f5a0d6299bfed0fb08d231e33c65dc1a747dc3ed848d15da36c'
preparation=json.loads(preparation_raw)
assert preparation['status']=='READY' and preparation['missing']==[]
assert preparation['source']==str(source)
assert preparation['checks']['temporary_directory']['path']=='/var/tmp/h9v62f'
assert preparation['checks']['temporary_directory']['actual_AF_UNIX_round_trip'] is True
environment_raw=(base/'preparation/environment.json').read_bytes()
assert sha256(environment_raw).hexdigest()=='358923b4a620e50dcb4739b3055678934ef52e6019c6ede65a58499324f673ad'
environment=json.loads(environment_raw)
assert environment['source']==str(source)
assert environment['temporary_directory']['path']=='/var/tmp/h9v62f'
assert environment['python']=='/home/qian-qi/.openclaw/workspaces/azi5/tasks/hia-selfhost-completion-20261109/venv/bin/python'
prepare_script=source/'review-evidence/hia-native-rewrite-20261111/prepare_remote_qualification_v2.py'
prepare_raw=prepare_script.read_bytes()
assert sha256(prepare_raw).hexdigest()=='972dffc85f53093aa8d06f53a1a2154dc1731e7ad93c0ca39c93f0b03a91ffbc'
assignment=next(n for n in ast.parse(prepare_raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LAUNCHER' for t in n.targets))
expected_launcher=ast.literal_eval(assignment.value).encode()
launcher=base/'preparation/launch.py'
assert launcher.read_bytes()==expected_launcher
assert sha256(expected_launcher).hexdigest()=='8bd77bec75bf3a570699db583ae955018d1d1e2cc78d52d117df15d7ebf06051'
expected=(base/'source-fetch-identity.json').read_bytes()
assert sha256(expected).hexdigest()=='2c90fbb9a45472707d3daf09b594174626af357704bf266a40943d970b6902cd'
os.chdir(source)
sys.path.insert(0,str(source))
from tools.hia_core_source_identity import ROOT,_source_state
assert ROOT.resolve()==source.resolve()
state=_source_state()
assert state==json.loads(expected) and len(state['files'])==2628 and state['status']==''
runner=source/'review-evidence/hia-native-rewrite-20261111/run_hia_qualification_v3.py'
supervisor=runner.with_name('workflow_process.py')
assert sha256(runner.read_bytes()).hexdigest()=='52e1fa90009fe329c57806e1e4006c09bba9635e2c4394e9f71fcafe59862838'
assert sha256(supervisor.read_bytes()).hexdigest()=='f3ebc453de2d2c9ecd3825547e301c122b6c7fa05af1aacd9103b8a67893ee80'
workflow=(source/'.github/workflows/hia-core.yml').read_text()
blocks=re.findall(r'          names = \((.*?)\n          \)',workflow,re.S)
assert len(blocks)==2
names=[re.findall(r"'(tests\.[^']+)'",block) for block in blocks]
assert all(names) and 'tests.test_hia_json_preflight_native' in names[1]
assert not (base/'qualification').exists() and not (base/'qualification').is_symlink()
command=['/usr/bin/python3','-I','-B',str(launcher),str(runner),'--source',str(source),'--output',str(base/'qualification'),'--full']
os.umask(0o077)
record={'schema':'hepta.hia.f50-fresh-full-launch-control.v1','commit':commit,'tree':tree,'source_snapshot_sha256':sha256(expected).hexdigest(),'source_git_blob_count':len(state['files']),'source_clean':True,'preparation_sha256':sha256(preparation_raw).hexdigest(),'environment_sha256':sha256(environment_raw).hexdigest(),'launcher_sha256':sha256(expected_launcher).hexdigest(),'runner_sha256':sha256(runner.read_bytes()).hexdigest(),'supervisor_sha256':sha256(supervisor.read_bytes()).hexdigest(),'source_modules':names[0],'native_modules':names[1],'command':command,'idempotency_key':'hia-v62-f50b3754-full-qualification-20261111-v1','old_source_or_output_modified':False}
with (base/'full-launch-control.json').open('x') as stream:
    json.dump(record,stream,sort_keys=True,indent=2)
    stream.write('\n')
print(json.dumps({'launch_preflight':'VERIFIED','commit':commit,'tree':tree,'source_git_blobs':2628,'source_snapshot_sha256':sha256(expected).hexdigest(),'full':True}),flush=True)
os.execv(command[0],command)
