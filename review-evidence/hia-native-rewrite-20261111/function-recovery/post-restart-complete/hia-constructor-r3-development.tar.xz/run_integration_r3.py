"""Two complete-pipeline/installed-wheel tests, with exact source custody."""
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-constructor-next')
OUT=Path(__file__).resolve().parent
RECOVERED=OUT.parent/'hia-function-recovery/frozen-inputs/native-inputs'
folder=OUT/sys.argv[1];folder.mkdir()
manifests={
 'HEPTA_HIA_COMPOSITE_CONSTRUCTOR_DEVELOPMENT_MANIFEST':OUT/'bundle-r1.json',
 'HEPTA_HIA_COMPOSITE_FUNCTIONS_DEVELOPMENT_MANIFEST':RECOVERED/'hia-function-native-development/bundle-current.json',
 'HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST':RECOVERED/'native-signature-development/manifest-r2.json',
 'HEPTA_HIA_TASK_HELPERS_DEVELOPMENT_MANIFEST':RECOVERED/'native-helper-development/manifest.json'}
os.environ.update({name:str(path) for name,path in manifests.items()})
os.environ['HEPTA_HIA_CONSTRUCTOR_INTEGRATION_EVIDENCE']=str(folder)
sys.path.insert(0,str(ROOT))
pins=json.loads((OUT/'stage5-source.json').read_bytes())['files']
paths=[ROOT/name for name in pins]+sorted((ROOT/'hepta').glob('*.py'))+[Path(__file__),Path(sys.executable).resolve()]
for manifest in manifests.values():
 paths.append(manifest);value=json.loads(manifest.read_bytes())
 if 'kernels' in value:
  for rel in value['kernels'].values():
   component=manifest.parent/rel;paths.append(component)
   paths.append(component.parent/json.loads(component.read_bytes())['image_path'])
 else:paths.append(manifest.parent/value['image_path'])
paths+=sorted((ROOT/'examples/hia_bootstrap').glob('*.hiaasm'))
def hashes():
 return {str(p):{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in paths}
before=hashes()
for name,row in pins.items():assert before[str(ROOT/name)]['sha256']==row['sha256'],name
(folder/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_hia_composite_constructor_integration.NativeConstructorIntegrationTests')
started=time.monotonic()
with (folder/'tests.log').open('w') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
after=hashes();(folder/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),
 expected_failures=len(result.expectedFailures),unexpected_successes=len(result.unexpectedSuccesses),
 elapsed_seconds=time.monotonic()-started,source_unchanged=before==after,
 max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,python=sys.version,
 scope='DEVELOPMENT_COMPLETE_NOMINAL_CTOR_FUNCTION_OWNERS_WITH_RETAINED_OUTER_AND_PRIMITIVE_VERIFIER')
(folder/'runner-summary.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
sys.exit(0 if result.wasSuccessful() and not result.skipped and before==after else 1)
