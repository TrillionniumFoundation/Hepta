"""Record the actual constructor development boundary panel and custody."""
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-constructor-next')
OUT = Path(__file__).resolve().parent
RECOVERED = OUT.parent / 'hia-function-recovery/frozen-inputs/native-inputs'
attempt = sys.argv[1]
folder = OUT / attempt
folder.mkdir()
os.environ.update(HEPTA_HIA_COMPOSITE_CONSTRUCTOR_DEVELOPMENT_MANIFEST=str(OUT/'bundle-r1.json'),
    HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST=str(RECOVERED/'native-signature-development/manifest-r2.json'),
    HEPTA_HIA_CONSTRUCTOR_EVIDENCE=str(folder))
sys.path.insert(0,str(ROOT))
pins = json.loads((OUT/'stage2-source.json').read_bytes())
pins['files'].update(json.loads((OUT/'stage3-source.json').read_bytes())['files'])
pins['files'].update(json.loads((OUT/'stage4-source.json').read_bytes())['files'])
paths = [ROOT/name for name in pins['files']]
paths += sorted((ROOT/'hepta').glob('*.py')) + [Path(sys.executable).resolve()]
paths += [ROOT/'tests/test_hia_composite_constructor_native.py', Path(__file__), OUT/'bundle-r1.json']
for name in ('owner','render'):
    paths += [OUT/(name+'-r1')/'manifest.json', OUT/(name+'-r1')/(name+'.image.bin')]
type_manifest = RECOVERED/'native-signature-development/manifest-r2.json'
paths += [type_manifest, type_manifest.parent/json.loads(type_manifest.read_bytes())['image_path'],
          ROOT/'examples/hia_bootstrap/composite_types.hiaasm']
def hashes():
    return {str(p): {'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in paths}
before = hashes()
for name,row in pins['files'].items():
    assert before[str(ROOT/name)]['sha256'] == row['sha256'], name
(folder/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_hia_composite_constructor_native.NativeConstructorTests')
if len(sys.argv)>2:
    suite = unittest.defaultTestLoader.loadTestsFromName(
        'tests.test_hia_composite_constructor_native.NativeConstructorTests.'+sys.argv[2])
started=time.monotonic()
with (folder/'tests.log').open('w') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
after=hashes()
(folder/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    skips=len(result.skipped),expected_failures=len(result.expectedFailures),
    unexpected_successes=len(result.unexpectedSuccesses),elapsed_seconds=time.monotonic()-started,
    source_unchanged=before==after,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    python=sys.version,scope='DEVELOPMENT_ONLY_F50_COMPILER_NOT_CURRENT_COLD')
(folder/'runner-summary.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value),flush=True)
sys.exit(0 if result.wasSuccessful() and not result.skipped and before==after else 1)
