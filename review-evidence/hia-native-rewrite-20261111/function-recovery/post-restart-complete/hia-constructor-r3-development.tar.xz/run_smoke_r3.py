"""Two authorized actual-image smoke comparisons; no large inventory panel."""
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-constructor-next')
OUT=Path(__file__).resolve().parent
folder=OUT/'smoke-r3';folder.mkdir()
os.environ.update(HEPTA_HIA_COMPOSITE_CONSTRUCTOR_DEVELOPMENT_MANIFEST=str(OUT/'bundle-r1.json'),
 HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST=str(OUT.parent/'hia-function-recovery/frozen-inputs/native-inputs/native-signature-development/manifest-r2.json'),
 HEPTA_HIA_CONSTRUCTOR_EVIDENCE=str(folder))
sys.path.insert(0,str(ROOT))
from tests.test_hia_composite_constructor_native import NativeConstructorTests, simple, nominal

class Smoke(NativeConstructorTests):
 def test_two_actual_smoke_boundaries(self):
  self.assertEqual(self.compare('stored-loan-positive',nominal.stored_loan_program())['status'],'accepted')
  doc=simple();doc['schema']='bad-schema'
  row=self.compare('early-schema-negative',doc)
  self.assertEqual(row['error'][0],'E_HIA_SCHEMA')
  self.assertEqual(row['state']['attributes'],[])

pins=json.loads((OUT/'stage2-source.json').read_bytes())['files']
pins.update(json.loads((OUT/'stage4-source.json').read_bytes())['files'])
def hashes():
 return {name:sha256((ROOT/name).read_bytes()).hexdigest() for name in pins}
before=hashes()
for name,row in pins.items():assert before[name]==row['sha256'],name
(folder/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
start=time.monotonic()
with (folder/'tests.log').open('w') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite([Smoke('test_two_actual_smoke_boundaries')]))
after=hashes();(folder/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
row=dict(tests=result.testsRun,errors=len(result.errors),failures=len(result.failures),skips=len(result.skipped),
 elapsed_seconds=time.monotonic()-start,source_unchanged=before==after,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 scope='TWO_DEVELOPMENT_SMOKE_COMPARISONS_NOT_FULL_CTOR_ACCEPTANCE')
(folder/'runner-summary.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
sys.exit(0 if result.wasSuccessful() and not result.skipped and before==after else 1)
