# Complete HIA constructor development evidence

This directory records an isolated candidate based on public main f50 plus
the recovered, separately frozen complete-function overlay. It is not a
current-source cold qualification, default activation, or whole-stack rewrite.
The retained constructor and outer lower remain available.

The owner and generic renderer were actually compiled by the restored f50 B3
image, SHA `0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8`,
under the unchanged 10-second CPU, 20-second wall and 256 MiB child limits.
Both returned successfully with source readback intact. The owner image is
163813 bytes, SHA `b2ba27931954815f5e89efca0a7bbcd43afabd3dbd71b295cc0379edd659273d`;
the renderer is 28278 bytes, SHA
`b392351ea2cbe4bbe1e534179bde8f94e227df882a23cec6c82c2b2a5b170539`.
Original compile requests, inputs, receipts and standard streams are retained
beside the actual images. The reproducible padded temporary output buffers are
not included; the produced image bytes are retained exactly.

## Preserved revisions

`stage1-source.json` is the first source-generation manifest, before a bridge
custody refinement. Its original bridge bytes were not separately frozen;
do not bind that historical SHA to a newer file. `stage2-source.json` and
`source-r1/` freeze the complete first bridge and both HIA sources. The first
bridge's missing unknown-phase validation was independently reported.

`source-r2/` and `stage3-source.json` retain the first framing correction.
`historical-frame-r2-actual-probe.json` actually executes that saved Python
frame parser and demonstrates its remaining crossed-response-phase defect.
It loads no native image. `source-r3/` and `stage4-source.json` add exact
issued-phase/profile and single-response correlation. Both HIA source files
and native images remained unchanged throughout these bridge revisions.

`checkpoint-r3/` and `stage5-source.json` include the same r3 owner plus source
tests, package resources, complete cold-gated builder, integration tests and
the arena/outer-owner design. The original design document's pre-restart base
is historical; the recovered baseline is identified in the baseline manifest
and current bounds document.

## Completed checks

- Two actual smoke inputs passed: a stored-loan program and an early schema
  refusal. Complete state, original input aliases and native type command
  traces matched the retained constructor using the same native type image.
- Seven actual native tests passed in 68.348 seconds with no errors, failures,
  skips or expected failures. All 150 complete constructor outcomes matched.
  They made 22911 actual constructor entries (15211 owner, 7700 renderer).
  Peak process RSS was 456652 KiB; this is a test process observation, not a
  production memory bound.
- The actual panel includes 4096 returns, 2048 parameters and the 1024-function
  boundary; source-stage missing attributes, partial maps, ordered type cache
  changes, origins before effects, unused tasks, malformed/replayed responses,
  unissued IDs, and persistent ABI poison were exercised.
- All pinned package Python sources, interpreter, tests, native sources,
  manifests and images were unchanged before and after that panel.
- Two pure framing tests passed for r3, including sequential crossed phase,
  profile drift, replay and unanswered-request controls. Three source tests
  passed for exact HIA regeneration, unchanged bootstrap limits, exact retained
  constructor body, indivisible bundle and rejection before artifact writes.

The complete raw 150-case source/outcome/type-command ledger is retained as
`native-r3-attempt1/outcomes.jsonl` (5395433 bytes, SHA
`79c0f254c2deb36c09c0deb5f1fa93de437e9afbfa233166db5fa6fcfd700704`).
The complete public pipeline and installed-wheel tests are written but have
not yet run at this checkpoint. Their later results must be added explicitly;
the passing isolated constructor panel is not their substitute.
