from pathlib import Path
from hashlib import sha256
import gzip,json,tarfile

p=Path('/dev/shm/hia-v62-performance-independent')
a=json.loads((p/'analysis.json').read_bytes())
calls=[json.loads(line) for line in gzip.open(p/'native-execution-receipts.jsonl.gz','rt')]
flat=[r for r in calls if r.get('transport')=='HIA-emitted-static-ELF-observer-v2' and 'native_elapsed_ns' in r]
workspace=sum(r['request_configuration']['workspace_size'] for r in flat)
assert workspace==2789212160
findings={
 'schema':'hepta.hia.cold-performance-readonly-findings.v1',
 'commit':a['commit'],'qualification_pass':False,'scope':'Observation of the original failed d684 GitHub cold run only; not the separate f50 ROG/GitHub runs',
 'main_findings':[
  'The first phase starts at 56.738238988 s. Seventeen reference families were already run through a two-worker subprocess pool; their durations are worker totals, not a serial prefix.',
  '34 completed workers contain 5182 distinct native call receipts. ABI wall clocks total 83.357227726 s across 4556 returned calls; 626 expected child-failure/trap calls have no native-return clock.',
  'The selected call wall clocks total 147.702814674 s. For calls with both clocks, wall minus native totals 58.171164072 s. The other 6.174422876 s belong to calls without a returned native clock, and must not all be called startup overhead.',
  'Signed, scalar-casts, capacity and cfg dominate measured native ABI work. Chain and owned are primarily wrapper/host-oracle/command work; their long phase times must not be mistaken for slow HIA ABI execution.',
  'The completed-phase receipts clock child exit before parent validation and stage packing. No archive-only start/end stopwatch exists. Pair-frontier gaps are combined validation/reread/seal/archive/scheduling envelopes.',
  'Names original and modified are indexed pending but already have 1438 and 513 unsealed raw paths. Exports has no raw paths. Pending does not establish that names had not started.',
  'Three concrete per-invocation immutable-byte operations can be reduced without caching a correctness conclusion: discarded frame allocation, repeated hashing of the same already-held bytes, and the full-workspace slice used only for header reads. No implementation was changed and no speedup was measured.'
 ],
 'family_two_worker_sums':a['families'],
 'archive_frontier_envelopes':a['frontier_gaps'],
 'candidate_pure_operations':[
  {'path':'tools/hia_selfhost_native_observer.py','function':'invoke/frame','locations':[92,159,164],
   'observation':'invoke calls frame once solely to validate fields, discards its complete immutable payload, then builds the real frame inside shared_output.',
   'observed_calls':4158,'discarded_payload_length_sum_bytes':1830408310,
   'proposal':'Factor exactly the same field validation from frame; validate before allocating capture buffers as today, construct the actual frame once at the existing position, and preserve the later output-fd validation.',
   'required_preservation':['same invalid-input exception category/text and order','same frame bytes and frame SHA','same shared-output and fresh-exec behavior','all immutable before/after reads','every request/receipt/raw file'],
   'elapsed_savings_measured':False,
   'qualification':'The byte count is the sum of discarded logical payload extents; it is not a measured memory-bandwidth figure or a runtime-saving estimate.'},
  {'path':'tools/hia_selfhost_native_observer.py','function':'invoke','locations':[168,209,234],
   'observation':'Image and source immutable bytes are hashed for the request, again for returned result fields, and again in result.update. The observer executable is also hashed repeatedly.',
   'repeated_image_and_source_hash_input_bytes':3658922088,
   'proposal':'Compute image/source/executable digest strings once within each invocation, reuse only those strings, and retain every actual path reread and byte comparison at the current mutation boundary.',
   'required_preservation':['no cross-invocation cache','no reuse of acceptance/refusal decisions','unchanged all request/result fields','unchanged original file rechecks and native call count'],
   'elapsed_savings_measured':False},
  {'path':'tools/hia_selfhost_native_observer.py','function':'invoke','locations':[204,213],
   'observation':'A valid response slices the entire immutable workspace from raw, but subsequent code only reads the fixed header fields. 2660 returned flat calls each slice a one-MiB workspace; 934 have zero workspace.',
   'workspace_slice_payload_bytes':workspace,
   'proposal':'Read the same fixed eight-byte header windows directly from the immutable raw response or a read-only memoryview. Preserve full subprocess stdout capture, exact response framing, all header offsets and integer encodings, and output byte ownership.',
   'required_preservation':['no change to response bytes consumed','no omission of workspace header fields','unchanged malformed-response and stderr refusal paths','output remains bytes and all source/output mutation observations remain'],
   'elapsed_savings_measured':False}
 ],
 'do_not_infer_or_change':[
  'Do not sum report references to cached build receipts as if they were distinct native calls.',
  'Do not subtract parallel worker sums directly from cold elapsed time.',
  'Do not label wall-minus-native as a separately measured process-startup duration.',
  'Do not remove Core/VM/direct-backend admissions in chain/owned merely because source bytes look repeated; these are actual independent oracle boundaries.',
  'Do not remove short-output, trap, capacity, original/modified or mutation witnesses, extend 180 seconds, change two workers, or reuse children.',
  'Do not revive ZIP_STORED or 64-KiB archive-buffer experiments already rejected on measured results.',
  'Do not claim all raw-member replay: only the documented JSON selections were replayed, while all container SHA/manifest/inventory/size/mode checks were performed.'
 ],
 'scope_checked':a['scope'],
 'input_archive':a['input_archive'],
 'interpretation_sources':a['interpretation_sources'],
 'local_reset_handling':'The first temporary analysis files were lost when the execution environment reset. The second analysis rereads the unchanged original ZIP and asserts exact equality with the previously observed aggregate counts, bytes and nanoseconds. No qualification was rerun.'
}
(p/'findings.json').write_text(json.dumps(findings,indent=2,sort_keys=True)+'\n')
members={}
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name not in {'package-manifest.json','custody.json','performance-d684-readonly.tar.xz'}:
  raw=f.read_bytes();members[f.relative_to(p).as_posix()]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':f.stat().st_mode&0o777}
manifest={'schema':'hepta.hia.readonly-analysis-package.v1','files':members,'input':a['input_archive'],'all_selected_json_payloads_replayed':True,'all_inner_raw_members_replayed':False,'qualification_executed':False,'production_source_changed':False}
(p/'package-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
package=p/'performance-d684-readonly.tar.xz'
with tarfile.open(package,'w:xz',preset=3) as t:
 for name in [*members,'package-manifest.json']:
  t.add(p/name,arcname=name,recursive=False)
with tarfile.open(package,'r:xz') as t:
 assert set(t.getnames())==set(members)|{'package-manifest.json'}
 for name,row in members.items():
  m=t.getmember(name);raw=t.extractfile(m).read()
  assert m.isfile() and m.size==len(raw)==row['bytes'] and m.mode==row['mode'] and sha256(raw).hexdigest()==row['sha256']
 raw=t.extractfile('package-manifest.json').read();assert raw==(p/'package-manifest.json').read_bytes()
raw=package.read_bytes()
custody={'schema':'hepta.hia.readonly-analysis-custody.v1','archive':str(package),'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'members':len(members)+1,'all_package_members_replayed':True,'original_failed_run_archive':a['input_archive'],'failed_run_selected_json_replay':a['scope'],'claim':'Read-only performance audit; no new test/native execution or qualification'}
(p/'custody.json').write_text(json.dumps(custody,indent=2,sort_keys=True)+'\n')
print(json.dumps(custody,sort_keys=True))
