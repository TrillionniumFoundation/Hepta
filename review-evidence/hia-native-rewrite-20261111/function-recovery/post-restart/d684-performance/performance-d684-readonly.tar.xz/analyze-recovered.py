"""Read-only reconstruction after the local temporary filesystem was reset.

The input ZIP is the original failed CI artifact. Read and verify every sealed
archive container and its manifest; replay only receipt/request/command/owner
JSON payloads. Inventory metadata for other members is checked, but their full
raw payloads are not replayed. No native execution or qualification is run.
"""
from collections import Counter,defaultdict
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import gzip,json,subprocess,zipfile

OUT=Path('/dev/shm/hia-v62-performance-independent')
REPO=Path('/workspace/scratch/9acdfa9f5639/Hepta')
PIN='d6847ac891e0dd07217d179891bb763162211de2'
RAW=Path('/workspace/scratch/9acdfa9f5639/HIA-d6847ac8-GitHub-native-failure-20261111.zip')
EXPECTED='345ea7e8635b6a4603e56eb6fa3f638bc2241e385983652bcb01fb4770929db6'
P='hia-cold.cold/qualification.evidence/'
M='HIA_ARCHIVE_MANIFEST.json'

def sha(data):return sha256(data).hexdigest()
def dump(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2,sort_keys=True);f.write('\n')
def stats(rows):
    measured=[r for r in rows if 'native_elapsed_ns' in r]
    total=sum(r['wall_elapsed_ns'] for r in rows)
    native=sum(r['native_elapsed_ns'] for r in measured)
    measured_wall=sum(r['wall_elapsed_ns'] for r in measured)
    return dict(count=len(rows),wall_elapsed_ns=total,native_elapsed_ns=native,
                native_timed_count=len(measured),no_native_clock_count=len(rows)-len(measured),
                envelope_for_native_timed_calls_ns=measured_wall-native,
                wall_for_calls_without_native_clock_ns=total-measured_wall,
                statuses=dict(Counter(r.get('status') for r in rows)))

before=RAW.stat();assert before.st_size==46307599 and sha(RAW.read_bytes())==EXPECTED
phases=[];calls=[];commands=[];owners=[];inner_ledger=[];outer_ledger=[];references=[];pending=[]
with zipfile.ZipFile(RAW) as z:
    assert len(z.namelist())==len(set(z.namelist()))==3360
    def read_outer(name):
        b=z.read(name);outer_ledger.append(dict(member=name,bytes=len(b),sha256=sha(b)));return b
    cold=json.loads(read_outer('hia-cold.json'))
    owner=json.loads(read_outer('hia-cold.cold/process-owner.json'))
    index=json.loads(read_outer(P+'phase-index.json'))
    start=next(e['monotonic_ns'] for e in owner['events'] if e['kind']=='qualification_started')
    for name in z.namelist():
        if name.startswith(P+'reference-') and name.endswith('.worker.json'):
            r=json.loads(read_outer(name));references.append({k:v for k,v in r.items() if k!='reference'})
    for row in index['phases']:
        name=row['family']+'-'+row['compiler_label'];stem=P+'phase-'+name
        if row['state']!='completed':
            pending.append(dict(name=name,state=row['state'],raw_members_observed=sum(n.startswith(P+'phase-runs/'+name+'/') for n in z.namelist()),request_present=stem+'.request.json' in z.namelist(),process_receipt_present=stem+'.process.json' in z.namelist(),report_present=stem+'.json' in z.namelist()))
            continue
        process=json.loads(read_outer(stem+'.process.json'))
        request=json.loads(read_outer(stem+'.request.json'))
        report_raw=read_outer(stem+'.json');report=json.loads(report_raw)
        assert sha(report_raw)==process['report_sha256']
        assert report['worker_pid']==process['worker_pid']
        assert report['source_manifest_sha256']==request['source_manifest_sha256']
        assert report['input_sha256']=={k:v['sha256'] for k,v in request['inputs'].items()}
        receipt=process['raw_artifacts'];archive_name=P+'phase-runs/'+name+'.zip'
        compressed=read_outer(archive_name)
        assert len(compressed)==receipt['packed_bytes'] and sha(compressed)==receipt['archive_sha256']
        pc=[];pt=[];po=[];selected=set();frames=0;frame_bytes=0;repeat_sha_bytes=0
        with zipfile.ZipFile(BytesIO(compressed)) as packed:
            raw=packed.read(M);assert sha(raw)==receipt['manifest_sha256']
            manifest=json.loads(raw);files=manifest['files'];names=packed.namelist()
            assert len(names)==len(set(names)) and set(names)==set(files)|{M}
            assert len(files)==receipt['files']
            assert manifest['source_directory']==request['directory']
            assert sum(f['bytes'] for f in files.values())==manifest['unpacked_bytes']==receipt['unpacked_bytes']
            for member,info in files.items():
                zi=packed.getinfo(member)
                assert zi.file_size==info['bytes'] and (zi.external_attr>>16)&0o777==info['mode']
                assert not Path(member).is_absolute() and '..' not in Path(member).parts
            def read_inner(member):
                b=packed.read(member);assert len(b)==files[member]['bytes'] and sha(b)==files[member]['sha256']
                if member not in selected:
                    selected.add(member);inner_ledger.append(dict(archive=archive_name,member=member,**files[member]))
                return json.loads(b)
            for member in sorted(names):
                if member.endswith('.receipt.json'):
                    r=read_inner(member)
                    if 'wall_elapsed_ns' not in r:continue
                    keys=('case','status','format','transport','wall_elapsed_ns','native_elapsed_ns','input_bytes','input_sha256','image_sha256','artifact_sha256','core_u32','returncode','produced_bytes','produced_sha256','limits')
                    item=dict(phase=name,member=member,**{k:r[k] for k in keys if k in r})
                    if 'native_elapsed_ns' in item:assert 0<=item['native_elapsed_ns']<=item['wall_elapsed_ns']
                    req_name=member[:-len('.receipt.json')]+'.request.json'
                    if req_name in files:
                        req=read_inner(req_name)
                        item['request_configuration']={k:req[k] for k in ('format','transport','image_sha256','source_sha256','capacity','workspace_size','workspace_fill','output_initial_sha256','observe_trap_writes') if k in req}
                        if r.get('transport')=='HIA-emitted-static-ELF-observer-v2':
                            image=req['image'];prefix=manifest['source_directory']+'/'
                            n=files[image[len(prefix):]]['bytes'] if image.startswith(prefix) else z.getinfo(image.removeprefix('/home/runner/work/_temp/')).file_size
                            s=r['input_bytes'];frames+=1;frame_bytes+=56+n+s
                            repeat_sha_bytes+=(2 if r.get('status')=='returned' else 1)*(n+s)
                            item['image_bytes_from_inventory']=n
                    pc.append(item)
                elif member.endswith('.command.json'):
                    r=read_inner(member)
                    if 'wall_elapsed_ns' in r:pt.append(dict(phase=name,member=member,**r))
                elif member.endswith('/owner.json'):
                    r=read_inner(member)
                    began=next(e['monotonic_ns'] for e in r['events'] if e['kind']=='qualification_started')
                    end=next(e['monotonic_ns'] for e in r['events'] if e['kind']=='qualification_exit_observed')
                    po.append(dict(phase=name,member=member,status=r['status'],returncode=r['returncode'],observed_child_interval_ns=end-began,cleanup_elapsed_ns=r['cleanup']['elapsed_ns'],start_to_cleanup_end_ns=r['cleanup']['started_ns']+r['cleanup']['elapsed_ns']-began,native_clock_available=False))
        grouped=defaultdict(list)
        for r in pc:grouped[r.get('transport') or 'python-child:'+str(r.get('format'))].append(r)
        calls.extend(pc);commands.extend(pt);owners.extend(po)
        p=dict(name=name,family=row['family'],label=row['compiler_label'],worker_pid=process['worker_pid'],started_ns=process['started_monotonic_ns'],completed_ns=process['completed_monotonic_ns'],start_from_cold_ns=process['started_monotonic_ns']-start,complete_from_cold_ns=process['completed_monotonic_ns']-start,worker_wall_ns=process['wall_elapsed_ns'],body_ns=report['elapsed_ns'],setup_report_exit_envelope_ns=process['wall_elapsed_ns']-report['elapsed_ns'],report_sha256=process['report_sha256'],check_count=len(report['checks']),all_report_checks_true=all(v is True for v in report['checks'].values()),execution=stats(pc),transport={k:stats(v) for k,v in grouped.items()},command_count=len(pt),command_wall_ns=sum(r['wall_elapsed_ns'] for r in pt),cli_owner_count=len(po),cli_owner_window_ns=sum(r['start_to_cleanup_end_ns'] for r in po),archive={k:receipt[k] for k in ('archive_sha256','manifest_sha256','files','unpacked_bytes','packed_bytes')},selected_members=len(selected),selected_bytes=sum(files[n]['bytes'] for n in selected),discarded_frame_calls=frames,discarded_frame_payload_bytes=frame_bytes,repeated_sha_input_bytes=repeat_sha_bytes)
        p['body_outside_selected_clocks_ns']=p['body_ns']-p['execution']['wall_elapsed_ns']-p['command_wall_ns']-p['cli_owner_window_ns']
        phases.append(p)

assert len(phases)==34 and len(pending)==4
total=stats(calls)
assert total['count']==5182 and total['native_timed_count']==4556
assert total['wall_elapsed_ns']==147702814674 and total['native_elapsed_ns']==83357227726
assert len(inner_ledger)==11259 and sum(r['bytes'] for r in inner_ledger)==26154319
assert sum(p['discarded_frame_calls'] for p in phases)==4158
assert sum(p['discarded_frame_payload_bytes'] for p in phases)==1830408310
assert sum(p['repeated_sha_input_bytes'] for p in phases)==3658922088
after=RAW.stat();assert (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_ctime_ns,before.st_size)==(after.st_dev,after.st_ino,after.st_mtime_ns,after.st_ctime_ns,after.st_size)
assert sha(RAW.read_bytes())==EXPECTED
family_order=list(dict.fromkeys(p['family'] for p in phases));families=[];frontiers=[]
for f in family_order:
    items=[p for p in phases if p['family']==f]
    rows=[r for r in calls if r['phase'].startswith(f+'-')]
    families.append(dict(family=f,worker_wall_ns=sum(p['worker_wall_ns'] for p in items),body_ns=sum(p['body_ns'] for p in items),execution=stats(rows),command_wall_ns=sum(p['command_wall_ns'] for p in items),cli_owner_window_ns=sum(p['cli_owner_window_ns'] for p in items),body_outside_selected_clocks_ns=sum(p['body_outside_selected_clocks_ns'] for p in items),raw_bytes=sum(p['archive']['unpacked_bytes'] for p in items)))
for f,n in zip(family_order,family_order[1:]):
    previous=max(p['completed_ns'] for p in phases if p['family']==f)
    following=min(p['started_ns'] for p in phases if p['family']==n)
    frontiers.append(dict(after_family=f,before_family=n,gap_ns=following-previous,scope='combined validation/reread/sealing/archive/scheduling envelope, not archive-only clock'))
sources={}
for name in ('qualify_hia_selfhost.py','hia_selfhost_native_observer.py','hia_selfhost_child.py','hia_evidence_archive.py','qualify_hia_selfhost_cli.py','hia_selfhost_process_owner.py','hia_selfhost_signed_cases.py','hia_selfhost_scalar_casts.py','hia_selfhost_capacity.py','qualify_hia_selfhost_chain_elf.py','qualify_hia_selfhost_chain_flow.py','qualify_hia_selfhost_owned_elf.py'):
    path='tools/'+name;data=subprocess.check_output(['git','--no-replace-objects','-C',str(REPO),'show',PIN+':'+path]);sources[path]={'bytes':len(data),'sha256':sha(data)}
    dest=OUT/'interpretation-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
report=dict(schema='hepta.hia.readonly-cold-phase-performance-reconstruction.v1',commit=PIN,input_archive={'path':str(RAW),'bytes':before.st_size,'sha256':EXPECTED},input_unchanged=True,local_environment_reset_lost_first_analysis_files=True,regenerated_from_same_original_archive=True,previous_observed_aggregate_counts_and_nanoseconds_exact_match=True,cold_status=cold['status'],cold_wall_ns=cold['wall_elapsed_ns'],cold_checks_passed=sum(v is True for v in cold['checks'].values()),cold_checks_total=len(cold['checks']),owner_status=owner['status'],qualification_seconds=owner['qualification_seconds'],cleanup=owner['cleanup'],first_completed_phase_start_from_cold_ns=min(p['started_ns'] for p in phases)-start,completed_phases=34,pending=pending,phases=phases,families=families,frontier_gaps=frontiers,execution_total=total,command_total={'count':len(commands),'wall_ns':sum(r['wall_elapsed_ns'] for r in commands)},cli_owner_total={'count':len(owners),'observed_child_interval_ns':sum(r['observed_child_interval_ns'] for r in owners),'cleanup_ns':sum(r['cleanup_elapsed_ns'] for r in owners),'window_ns':sum(r['start_to_cleanup_end_ns'] for r in owners)},references=references,pure_work_counts={'discarded_frame_calls':4158,'discarded_frame_payload_bytes':1830408310,'repeated_same_bytes_sha256_input_bytes':3658922088,'time_savings_measured':False},top_native_calls=sorted(calls,key=lambda r:r.get('native_elapsed_ns',0),reverse=True)[:40],scope={'sealed_archives_full_compressed_sha_verified':34,'all_manifest_sha_verified':True,'all_central_inventory_sizes_modes_verified':True,'all_raw_members_replayed':False,'raw_files_inventory_total':sum(p['archive']['files'] for p in phases),'raw_bytes_inventory_total':sum(p['archive']['unpacked_bytes'] for p in phases),'selected_json_members_replayed':len(inner_ledger),'selected_json_bytes_replayed':sum(r['bytes'] for r in inner_ledger),'physical_unique_receipt_calls_counted':True,'report_references_not_summed':True},interpretation_sources=sources,limitations=['Elapsed ABI clocks are wall time, not CPU/per-function profiles.','Observer wall minus native includes exec, capture/I/O/hash/write and scheduling, not separately timed startup.','Per-call wall excludes initial request framing/hash/write and final immutable rereads/receipt writes.','CLI owner ranges omit supervisor setup and do not separate Python setup/native execution.','Two concurrent worker totals are not critical-path savings.','Archive start/end clocks are absent; inter-family gaps combine validation/archive/sealing/scheduling.','Names pending already has raw members and started work; no complete names/exports timing total is claimed.','No qualification, native run, worker reuse, implementation/budget/concurrency/observation change or evidence retirement occurred.'])
dump('analysis.json',report)
for name,rows in [('outer-read-ledger.jsonl.gz',outer_ledger),('selected-inner-replay-ledger.jsonl.gz',inner_ledger),('native-execution-receipts.jsonl.gz',calls),('native-command-receipts.jsonl.gz',commands),('cli-owner-intervals.jsonl.gz',owners)]:
    with (OUT/name).open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as f:
            for r in rows:f.write(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'status':'READONLY_RECONSTRUCTION_COMPLETED','phases':len(phases),'execution_total':total,'scope':report['scope']},sort_keys=True))
