"""Private-only replacement witness, before/after the explicit custody gate.

Public verify -> detached document -> lower never substitutes a different fn.
Neither native bridge is claimed to preserve arbitrary private substitutions.
"""
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT=Path('/dev/shm/hia-function-native-next')
sys.path.insert(0,str(ROOT))
from hepta import hia_program_composite as composite
from hepta.hia_composite_functions_native import installed_composite_functions, NativeFunctionSession
from hepta.hia_composite_types_native import installed_composite_types
from hepta.hia_task_helpers_native import installed_task_helpers
from hepta.hia_program import HIAProgramRejected

old_path=Path('/dev/shm/hia-function-native-development/frozen-source-r1/hepta/hia_composite_functions_native.py')
spec=importlib.util.spec_from_file_location('hepta._terms_audit_old_bridge',old_path)
old=importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
bundle=installed_composite_functions('/dev/shm/hia-function-native-development/bundle-current.json')
types=installed_composite_types('/workspace/scratch/9acdfa9f5639/native-signature-development/manifest-r2.json')
helpers=installed_task_helpers('/workspace/scratch/9acdfa9f5639/native-helper-development/manifest.json')
params=[dict(name='x',type='u8')]
fn=dict(name='main',params=params,returns=['u8'],effects=[],entry='entry',
        blocks=[dict(id='entry',params=deepcopy(params),ops=[],term=dict(op='ret',values=['x']))])
document=dict(schema='hepta.hia.composite.v4',module='private_selection',types=[],functions=[fn])
replacement=deepcopy(fn);replacement['blocks']=0
results={}
for label,cls in [('reference',None),('r1_name_only',old.NativeFunctionSession),('r2_custody',NativeFunctionSession)]:
    with patch('hepta.hia_composite_functions_native.selected_composite_functions',return_value=None), patch(
        'hepta.hia_composite_types_native.selected_composite_types',
        side_effect=lambda defs,**flags:types.session(defs,**flags)):
        owner=composite._Elaborator(deepcopy(document))
    session=None
    try:
        if cls is None:
            callback=lambda:composite._Elaborator._reference_function(owner,replacement)
        else:
            session=cls(bundle.images,owner,helpers)
            callback=lambda:session.function(replacement)
        try: result=dict(status='accepted',core=callback())
        except HIAProgramRejected as error:
            result=dict(status='rejected',code=error.code,message=str(error))
        result.update(serial=owner.serial,value_slots=owner.value_slots)
        results[label]=result
    finally:
        if session is not None:session.close()
        owner.types.close()
current=ROOT/'hepta/hia_composite_functions_native.py'
result=dict(scope='private-only replacement: outside public detached-document lowering contract',
    document=document,replacement=replacement,results=results,
    old_adapter_sha256=sha256(old_path.read_bytes()).hexdigest(),
    current_adapter_sha256=sha256(current.read_bytes()).hexdigest())
Path('/dev/shm/hia-function-terms-development/private-function-selection.json').write_text(json.dumps(result,indent=2)+'\n')
assert results['reference']['code']=='E_HIA_CFG'
assert results['r1_name_only']['status']=='accepted'
assert results['r2_custody']['code']=='E_HIA_TYPE'
print(json.dumps({k:{p:v for p,v in row.items() if p!='core'} for k,row in results.items()},indent=2))
