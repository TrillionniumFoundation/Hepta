"""Execute all eight unchanged tests sequentially in isolated processes."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/dev/shm/hia-function-native-next')
FOLDER = Path('/dev/shm/hia-function-terms-development')
sys.path.insert(0, str(ROOT))
from tests.test_hia_composite_function_terms_native import NativeFunctionTermsTests
names = sorted(name for name in dir(NativeFunctionTermsTests) if name.startswith('test_'))
assert len(names) == 8
result = []
for index, name in enumerate(names):
    attempt = 'attempt3-' + str(index + 1)
    command = [sys.executable, '-B', str(FOLDER / 'run_tests.py'), attempt,
               'NativeFunctionTermsTests.' + name]
    started = time.monotonic()
    with (FOLDER / (attempt + '-runner.log')).open('wb') as output:
        process = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    summary = FOLDER / attempt / 'summary.json'
    row = dict(test=name, exit_code=process.returncode, wall_seconds=time.monotonic()-started,
               summary=None if not summary.exists() else json.loads(summary.read_text()))
    result.append(row)
    (FOLDER / 'attempt3-isolated-summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(name, process.returncode, flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
print('All eight tests completed without changing the test corpus or assertions.', flush=True)
