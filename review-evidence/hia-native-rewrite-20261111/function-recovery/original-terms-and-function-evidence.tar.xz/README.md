# Independent complete-function terminator audit

This evidence covers the complete HIA terminator/CFG and function-envelope
implementation in `tools/generate_hia_composite_function_terms.py`, together
with the indivisible five-kernel function bundle. It is development evidence
using retained direct x86 images, not a new cold qualification, native compiler
qualification, whole-language self-hosting result, or authority to delete the
retained owner.

## Frozen implementation

- Terms authoring source: `fe928a6f0bcd75fc7a3d94b4a76bf68836a5e5a9c8234b6a0fd66a9d705fcb92`.
- Generated HIA source: `bfbe46d83fa6aceaee0eb538e0540383f6ce2665896cb01b7dc6444cfa683bc4`.
- Actual terms image: `302d915f694de2891f0685f610dcb7004a49e4eb20890d2566e1f32d5a7bf7d5`.
- Unchanged compiler limits admitted 107 functions, 945 blocks and 3727
  instructions; the largest function has 181 blocks. Source is 221724 bytes;
  the image is 310584 bytes.
- Final independent test source: `a87c1c063b5444a28b099367b2f79e4e8a0c48152450dacf7eb04adecbcb43d4`.
- Final tested bridge custody revision:
  `07cc5995421141840b4af60d43e0dd0c9712bb58aabe5b2993be465961afbc56`.
  All five kernels remained unchanged from the original complete bundle.

The HIA implementation owns jump, branch, return, trap, complete enum match,
edge type/liveness checks, fresh-name allocation, inactive owner cleanup, all
generated CFG blocks, the complete function envelope, and v4 returned-loan
names. It returns concrete generic Core objects, not a host-interpreted plan.

## Completed independent observations

`attempt3-isolated-summary.json` and `attempt3-aggregate.json` retain the final
eight tests, executed in separate sequential processes without reducing any
case or assertion. All eight passed with zero errors, failures or skips.
There were 183 complete function calls: 40 accepted and 143 rejected. Each
complete Core or error, error text, serial, value-slot count, helper cache order,
helper list and native type observations exactly matched the retained full
function oracle. Full serialized outcomes were compared as bytes as well.

The retained oracle body was independently compared by AST with the worktree's
baseline; only its method name changed. Both sides used separate selected
native type sessions to isolate function semantics from the existing native
type diagnostic policy. This is not a claim that every native type constructor
diagnostic has identical English context to the older hosted type resolver.

The native path poisoned every hosted function/local semantic helper. It made
4259 actual function-kernel calls: admit 1520, records 893, advanced 280, terms
242, render 1324. Every checked source snapshot stayed byte-identical. Selected
terms calls also read back the complete borrowed 128 MiB type buffer and found
identical SHA-256 values. Every final process retained exact before/after hashes
for authoring, installed sources, images, bridge, dependency sources, tests and
runner; all matched.

Covered boundaries include all terminator shapes and name errors, all-argument
lookup before return type checks, duplicate/missing live resources, consumed
values, branch-side order, exhaustive/duplicate/misordered enum cases, scalar
aliases in carry sets, buffer and chain cleanup, 32 zero-width variants,
serial 8191/8192 and exact final-name exhaustion, refusal followed by another
function or repeated refusal, and returned-loan names from a nonfirst entry.

Three additional accepted stress cases exercised the maximum legal 512-slot
enum, 48 repeated 64-slot arguments on each of two match arms, and 1024 repeated
zero-width arguments with 2048 nominal target formals. The latter retains one
reserved primitive slot; zero-width values are still bounded by source nodes.

The native implementation fully materialized an 11194841-byte function with
512000 return types and 512000 return values. A later invalid function still
produced `E_HIA_CFG: invalid nominal block inventory` first. When that completed
Core was admitted alone, the existing outer structure gate produced E_HIA_LIMIT.
No new per-function output quota was added. A separately constructed scalar
program's generated match CFG was verified and executed for both variants and
four input values; all eight runtime results matched the direct expectation.

The tests took 53.406309 seconds in total, or 56.439896 seconds including
process startup. This is a semantic test duration, not a comparative benchmark.
Peak observed test-process RSS was 689488 KiB, including two native type sessions,
the candidate, its independent oracle and complete Core objects. It is not a
production process-memory upper bound. The largest recorded final arena cursor
was 72720360 (5545960 bytes above ARENA=67174400); these final cursor observations
do not replace a proof of maximum arena use at every intermediate instruction.

## Retained unsuccessful attempts

`attempt1.log`, `test-attempt1.py` and all six initial test outcome panels are
retained. Their old/new full outcomes were equal, but two final assertions used
error text without the standard `E_HIA_*: ` prefix. Those assertion mistakes
were corrected; production terms source and images did not change.

`attempt2/` and its runner log retain a later full-suite attempt that completed
three tests, then was killed with exit 137 during the scalar-match test. There
was no Python traceback or observed semantic mismatch. The reason for the kill
was not established; cgroup memory event files were unavailable. It is not
reported as a passing run or as a demonstrated native semantic defect. The
subsequent eight-process run retained the same tests, assertions and input
boundaries. Its bridge revision is separately pinned; it includes the pure
membership/copy custody guard described below.

## Private invocation scope

`private_function_selection.py` and its original JSON/log reproduce a private
API difference. Passing a replacement dictionary with the same function name
and invalid blocks makes the retained private function inspect that replacement.
The initial native bridge selected the constructor-frozen function by name and
therefore accepted the original function. This substitution is outside the
public verify -> bounded detached document -> complete lower path.

The final tested bridge refuses nonmember or modified function dictionaries by
exact representation custody before native NEXT. It no longer silently ignores
that substitution, but arbitrary private function replacements are explicitly
not claimed equivalent: the new guard's transport E_HIA_TYPE differs from the
old body's E_HIA_CFG. Normal document members retain complete semantic equality.

## Arena accounting notes

Let N be the original 262144 source-node ceiling, V the 32768 reserved-slot
ceiling and F the 8192 fresh-name ceiling. These existing ceilings are not new
limits. A match's carry capacity includes all active aliases; summing it across
source blocks is bounded by V. Three vectors cost 24 bytes per slot and the
open-addressed table costs less than 64, hence at most 88V plus fixed headers.

Each source case's arguments enter their mapping once. Its table plus list
views cost at most 96 bytes per source argument, with the empty-case constant
charged separately. Each variant maps each distinct Value record once, giving
at most 32V*8 bytes of mapped vectors even with repeated wide arguments. The
temporary transfer/case tables restore the arena mark after their read-only
checks and do not accumulate.

Arm/decision name vectors and generated parameter/block/instruction IR are
charged to F. Reachable owned enum payloads cannot alias owner names: incoming
nominal parameters allocate unique names, scalar projection rejects linear
fields, and make/insert/unpack consumption and moves preserve this invariant.
Thus inactive owner drops can be charged to the arm's fresh carry names;
deduplicated scalar aliases do not generate owner drops. Return argument
vectors/views cost 8/32 bytes per source occurrence. Function return-type views
cost 32 per signature return; explicit v4 origin views use their corresponding
source annotation nodes plus one 4096-byte null vector. Native flat type vectors
are cached per issued descriptor, at most 144*512*8 bytes. The full bundle's
remaining source/IR charging proof is owned by its integrator.

No constructor, full lower, backend, compiler qualification or retained-owner
deletion claim is made by this isolated terms deliverable.
