"""Read back every archived member against its exact prepack bytes/hash."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import tarfile

ROOT=Path('/dev/shm/hia-function-terms-development')
PROJECT=Path('/dev/shm/hia-function-native-next')
DEST=Path('/workspace/scratch/9acdfa9f5639/hia-function-terms-development')
DEST.mkdir(parents=True,exist_ok=True)
pins=json.loads((ROOT/'attempt3-1/source-before.json').read_text())
frozen=ROOT/'frozen-inputs'
members={}
for raw,identity in pins.items():
    source=Path(raw)
    if source.is_relative_to(ROOT):
        continue
    if source.is_relative_to(PROJECT):
        name=Path('project')/source.relative_to(PROJECT)
    else:
        name=Path('native-inputs')/source.parent.name/source.name
    content=source.read_bytes()
    assert len(content)==identity['bytes'] and sha256(content).hexdigest()==identity['sha256'],raw
    target=frozen/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(content)
    members[raw]=dict(member=str(Path('frozen-inputs')/name),**identity)
for name in ('terms-compile-r1.json','terms-r1.receipt.json','terms-r1.request.json',
             'terms-r1.stdout.log','terms-r1.stderr.log','bundle-development-r1.json'):
    source=Path('/dev/shm/hia-function-native-development')/name
    target=frozen/'compilation'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
old=Path('/dev/shm/hia-function-native-development/frozen-source-r1/hepta/hia_composite_functions_native.py')
(frozen/'private-r1-bridge.py').write_bytes(old.read_bytes())
(frozen/'source-members.json').write_text(json.dumps(members,indent=2)+'\n')
files=sorted(path for path in ROOT.rglob('*') if path.is_file())
expected={str(path.relative_to(ROOT)):dict(bytes=path.stat().st_size,sha256=sha256(path.read_bytes()).hexdigest()) for path in files}
archive=DEST/'hia-function-terms-development.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as output:
    for path in files:
        output.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
seen=set()
with tarfile.open(archive,'r:xz') as source:
    for member in source:
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        data=source.extractfile(member).read()
        assert data==(ROOT/member.name).read_bytes(),member.name
        assert len(data)==expected[member.name]['bytes']
        assert sha256(data).hexdigest()==expected[member.name]['sha256']
assert seen==set(expected)
custody=dict(archive=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha256(archive.read_bytes()).hexdigest()),
    members=expected,member_count=len(expected),raw_bytes=sum(row['bytes'] for row in expected.values()),
    every_member_readback_exact=True)
(DEST/'custody.json').write_text(json.dumps(custody,indent=2)+'\n')
for name in ('README.md','attempt3-aggregate.json','attempt3-isolated-summary.json',
             'retained-attempts.json','private-function-selection.json'):
    shutil.copyfile(ROOT/name,DEST/name)
print(json.dumps({key:value for key,value in custody.items() if key!='members'},indent=2))
