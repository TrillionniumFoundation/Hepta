"""Retain independent full-bundle terms outcomes and exact source custody."""
import ast
from hashlib import sha256
import inspect
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import unittest

ROOT = Path('/dev/shm/hia-function-native-next')
FOLDER = Path('/dev/shm/hia-function-terms-development')
NAME = sys.argv[1]
DEST = FOLDER / NAME
DEST.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT))
os.environ.update(
    HEPTA_HIA_COMPOSITE_FUNCTIONS_DEVELOPMENT_MANIFEST='/dev/shm/hia-function-native-development/bundle-current.json',
    HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST='/workspace/scratch/9acdfa9f5639/native-signature-development/manifest-r2.json',
    HEPTA_HIA_TASK_HELPERS_DEVELOPMENT_MANIFEST='/workspace/scratch/9acdfa9f5639/native-helper-development/manifest.json',
    HEPTA_HIA_FUNCTION_TERMS_EVIDENCE=str(DEST))

paths = [ROOT / name for name in (
    'hepta/hia_program_composite.py', 'hepta/hia_composite_functions_native.py',
    'hepta/hia_composite_function_tokens.py', 'hepta/hia_composite_functions_errors.py',
    'hepta/hia_composite_types_native.py', 'hepta/hia_task_helpers_native.py',
    'tools/generate_hia_composite_function_terms.py', 'tools/generate_hia_composite_functions.py',
    'tools/generate_hia_composite_function_admission.py', 'tools/generate_hia_composite_function_lowering.py',
    'tests/test_hia_composite_function_terms_native.py',
    'examples/hia_bootstrap/composite_types.hiaasm', 'examples/hia_bootstrap/task_helpers.hiaasm')]
bundle = Path(os.environ['HEPTA_HIA_COMPOSITE_FUNCTIONS_DEVELOPMENT_MANIFEST'])
paths.append(bundle)
for kernel, member in json.loads(bundle.read_text())['kernels'].items():
    manifest = bundle.parent / member
    paths.append(manifest)
    paths.append(ROOT / ('examples/hia_bootstrap/composite_function_' + kernel + '.hiaasm'))
    row = json.loads(manifest.read_text())
    paths.append(manifest.parent / row['image_path'])
for key in ('HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST', 'HEPTA_HIA_TASK_HELPERS_DEVELOPMENT_MANIFEST'):
    manifest = Path(os.environ[key]); paths.append(manifest)
    row = json.loads(manifest.read_text())
    paths.append(manifest.parent / row['image_path'])
paths.append(Path(__file__))
def pins():
    return {str(path): dict(bytes=path.stat().st_size, sha256=sha256(path.read_bytes()).hexdigest())
            for path in paths}
before = pins()
(DEST / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')

previous = subprocess.check_output(['git', 'show', 'HEAD:hepta/hia_program_composite.py'], cwd=ROOT).decode()
def method(text, name):
    cls = next(node for node in ast.parse(text).body if isinstance(node, ast.ClassDef) and node.name == '_Elaborator')
    return next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == name)
old = method(previous, 'function')
new = method((ROOT / 'hepta/hia_program_composite.py').read_text(), '_reference_function')
old.name = new.name
oracle_same = ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False)
assert oracle_same, 'the retained full oracle changed beyond its method name'

from tests import test_hia_composite_function_terms_native as tests
started = time.monotonic()
with (DEST / 'tests.log').open('w') as output:
    suite = (unittest.defaultTestLoader.loadTestsFromNames(sys.argv[2:], tests) if len(sys.argv) > 2
             else unittest.defaultTestLoader.loadTestsFromModule(tests))
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
elapsed = time.monotonic() - started
after = pins()
(DEST / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
summary = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
    skips=len(result.skipped), expected_failures=len(result.expectedFailures),
    unexpected_successes=len(result.unexpectedSuccesses), elapsed_seconds=elapsed,
    max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    source_unchanged=before == after, oracle_body_exact_ast_equal=oracle_same,
    native_entries=tests.NativeFunctionTermsTests.entries,
    backend='retained direct x86 development images; no cold/whole-native qualification claim')
for path in DEST.glob('*.summary.json'):
    row = json.loads(path.read_text())
    summary.setdefault('panels', {})[path.stem] = {key: row[key] for key in ('calls', 'accepted', 'source_bytes', 'final_native_arena_cursor')}
(DEST / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
if not result.wasSuccessful() or before != after:
    raise SystemExit(1)
