from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import unittest

root = Path('/workspace/scratch/9acdfa9f5639/native-fixture-construction-next')
output = Path('/dev/shm/hia-fixture-construction-performance')
sys.path.insert(0, str(root))
from tools.hia_selfhost_contract import file_digests
before = file_digests()
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'tests.test_hia_agent_assembly', 'tests.test_hia_selfhost_names',
    'tests.test_hia_reference_fixture_efficiency'])
started = time.monotonic()
with (output / 'focused-tests.log').open('w') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
record = {'tests': result.testsRun, 'errors': len(result.errors),
          'failures': len(result.failures), 'skipped': len(result.skipped),
          'expected_failures': len(result.expectedFailures),
          'unexpected_successes': len(result.unexpectedSuccesses),
          'wall_seconds': time.monotonic() - started,
          'sources_preserved': file_digests() == before,
          'source_manifest_sha256': sha256(json.dumps(before, sort_keys=True).encode()).hexdigest()}
(output / 'focused-tests.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True), flush=True)
raise SystemExit(0 if result.wasSuccessful() and record['sources_preserved'] else 1)
