from pathlib import Path
from hashlib import sha256
import json
import os
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
roots = {'old': '/dev/shm/hia-fixture-baseline',
         'new': '/workspace/scratch/9acdfa9f5639/native-fixture-construction-next'}
records = []
baseline = None
for index, kind in enumerate(('old', 'new', 'new', 'old', 'old', 'new')):
    name = kind + '-' + str(index)
    started = time.monotonic()
    result = subprocess.run([sys.executable, '-I', '-S', '-B', str(out / 'measure_names.py'),
        '--root', roots[kind], '--output', str(out), '--name', name],
        cwd=out, capture_output=True, text=True, timeout=120,
        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    record = {'name': name, 'process_wall_seconds': time.monotonic() - started,
              'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    (out / (name + '.process.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    if result.returncode:
        print(json.dumps(record), flush=True)
        raise SystemExit(result.returncode)
    value = json.loads(result.stdout)
    raw = (out / (name + '.reference.json')).read_bytes()
    if baseline is None:
        baseline = raw
    assert raw == baseline, name
    records.append(value)
    print(json.dumps(value, sort_keys=True), flush=True)
(out / 'unprofiled-comparison.json').write_text(json.dumps({
    'scope': 'DEVELOPMENT_COMPARISON', 'complete_reference_bytes_equal': True,
    'bytes': len(baseline), 'sha256': sha256(baseline).hexdigest(), 'runs': records,
    'cold_qualification': False, 'deadline_seconds_unchanged': 180, 'workers_unchanged': 2},
    sort_keys=True, indent=2) + '\n')
