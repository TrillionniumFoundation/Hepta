from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import time

output = Path('/dev/shm/hia-fixture-construction-performance')
roots = {'old': '/dev/shm/hia-fixture-baseline',
         'new': '/workspace/scratch/9acdfa9f5639/native-fixture-construction-next'}
records = []
reference = None
for i, variant in enumerate(('old', 'new', 'new', 'old')):
    name = 'panel-' + variant + '-' + str(i)
    command = [sys.executable, '-I', '-S', '-B', str(output / 'measure_panel.py'),
               '--root', roots[variant], '--output', str(output), '--name', name]
    start = time.monotonic()
    process = subprocess.run(command, cwd=output, capture_output=True, text=True, timeout=180)
    (output / (name + '.process.json')).write_text(json.dumps({
        'command': command, 'returncode': process.returncode,
        'stdout': process.stdout, 'stderr': process.stderr,
        'whole_process_wall_seconds': time.monotonic() - start}, sort_keys=True, indent=2) + '\n')
    if process.returncode:
        print(process.stdout, process.stderr, flush=True)
        raise SystemExit(process.returncode)
    record = json.loads((output / (name + '.summary.json')).read_bytes())
    raw = (output / name / 'complete-references.json').read_bytes()
    if reference is None:
        reference = raw
    assert raw == reference
    records.append(record)
    print(json.dumps(record, sort_keys=True), flush=True)
summary = {'scope': 'DEVELOPMENT_COMPLETE_PRE_B0_REFERENCE_PANEL',
           'runs': records, 'complete_reference_bytes_equal': True,
           'complete_reference_bytes': len(reference),
           'complete_reference_sha256': sha256(reference).hexdigest(),
           'workers': 2, 'deadline_seconds_unchanged': 180,
           'all_17_fresh_oracles_and_admissions_retained': True,
           'cold_qualification': False}
(output / 'complete-panel-comparison.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
