from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--output', required=True)
p.add_argument('--name', required=True)
a = p.parse_args()
root, output = Path(a.root), Path(a.output)
sys.path.insert(0, str(root))
from tools.hia_selfhost_contract import validate_contract
from tools.hia_selfhost_references import BUILDERS, build_references, digest, snapshot
from tools.qualify_hia_selfhost import PHASE_REFERENCE_FILES, QUALIFICATION_WORKERS
validate_contract()
before = snapshot()
directory = output / a.name
directory.mkdir()
started = time.monotonic()
references, receipts = build_references(directory, before, PHASE_REFERENCE_FILES, QUALIFICATION_WORKERS)
wall = time.monotonic() - started
assert snapshot() == before
validate_contract()
assert set(references) == set(BUILDERS)
assert len(receipts) == 17
encoded = json.dumps(references, sort_keys=True, separators=(',', ':')).encode()
(directory / 'complete-references.json').write_bytes(encoded)
(directory / 'receipts.json').write_text(json.dumps(receipts, sort_keys=True, indent=2) + '\n')
(directory / 'source-manifest.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
record = {'scope': 'DEVELOPMENT_COMPLETE_PRE_B0_REFERENCE_PANEL', 'root': str(root),
          'name': a.name, 'workers': QUALIFICATION_WORKERS, 'wall_seconds': wall,
          'families': list(BUILDERS), 'family_count': len(references),
          'complete_reference_bytes': len(encoded), 'complete_reference_sha256': sha256(encoded).hexdigest(),
          'references': {name: digest(references[name]) for name in BUILDERS},
          'source_manifest_sha256': digest(before), 'sources_preserved': True,
          'fresh_reference_workers': len({r['worker_pid'] for r in receipts}),
          'cold_qualification': False, 'native_phase_inventory_or_deadline_changed': False}
(output / (a.name + '.summary.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True), flush=True)
