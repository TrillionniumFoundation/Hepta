from __future__ import annotations
from contextlib import ExitStack
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

root = Path('/workspace/scratch/9acdfa9f5639/native-fixture-construction-next')
baseline = Path('/dev/shm/hia-fixture-baseline')
output = Path('/dev/shm/hia-fixture-construction-performance')
sys.path.insert(0, str(root))
from hepta import hia_agent_assembly as new
from hepta.hia_program import VerifiedProgram
from tests.test_hia_agent_assembly import SOURCE
from tests.test_hia_program import arithmetic, resource_program, joined_loan_program
from tools.hia_selfhost_contract import file_digests
from tools import hia_selfhost_names as names

spec = importlib.util.spec_from_file_location('hepta._fixture_boundary_baseline', baseline / 'hepta/hia_agent_assembly.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
source_before = {'old': file_digests(baseline), 'new': file_digests(root)}
different_sources = [name for name in source_before['old']
                     if source_before['old'][name] != source_before['new'][name]]
assert set(different_sources) == {'hepta/hia_agent_assembly.py', 'tools/hia_selfhost_names.py',
                                  'tests/test_hia_reference_fixture_efficiency.py'}
rows = []
started = time.monotonic()

def outcome(module, method, value, limits):
    calls = []
    verify = module.verify_program
    def counted(document):
        calls.append('complete_core_verification')
        return verify(document)
    with ExitStack() as stack:
        stack.enter_context(patch.object(module, 'verify_program', counted))
        for key, amount in limits.items():
            stack.enter_context(patch.object(module, key, amount))
        try:
            result = getattr(module, method)(value)
        except Exception as exc:
            result = {'accepted': False, 'type': type(exc).__name__,
                      'code': getattr(exc, 'code', None), 'message': str(exc),
                      'phase': getattr(exc, 'phase', None), 'line': getattr(exc, 'line', None)}
        else:
            if type(result) is VerifiedProgram:
                result = {'accepted': True, 'canonical': result.canonical_bytes.decode(),
                          'structured': None if result.structured_bytes is None else result.structured_bytes.decode()}
            else:
                result = {'accepted': True, 'result': result}
    return {'outcome': result, 'complete_core_verifications': len(calls)}

def compare(label, method, make_value, limits=None):
    limits = limits or {}
    left, right = make_value(), make_value()
    a = outcome(old, method, left, limits)
    b = outcome(new, method, right, limits)
    assert a == b, (label, method, a, b)
    row = {'id': label, 'api': method, 'limits': limits, **a}
    if type(left) in (str, bytes):
        raw = left.encode('utf-8', errors='surrogatepass') if type(left) is str else left
        row['input_bytes'] = len(raw)
        row['input_sha256'] = sha256(raw).hexdigest()
    rows.append(row)

def source(label, value, limits=None):
    for api in ('assemble_program', 'diagnose_assembly'):
        compare(label, api, lambda: value, limits)

source('ordinary', SOURCE)
source('ordinary-bytes', SOURCE.encode())
source('crlf', SOURCE.replace('\n', '\r\n'))
source('tabs-and-whitespace', '\n\t' + SOURCE.replace('  ', '\t') + '\n')
source('no-exports', SOURCE.replace('exports(total)\n', ''))
source('empty-exports', SOURCE.replace('exports(total)', 'exports()'))
for schema in ('hepta.hia.program.v2', 'hepta.hia.program.v6', 'hepta.hia.program.v7',
               'hepta.hia.program.v8', 'hepta.hia.program.v99', 'hepta.hia.composite.v4'):
    source('schema-' + schema, SOURCE.replace('hepta.hia.program.v6', schema))
for cp in (*range(0, 33), 0x7f, 0x85, 0xa0, 0x2028, 0x2029, 0xfeff, 0xd800, 0xdfff, 0x10ffff):
    source('trailing-codepoint-' + str(cp), SOURCE + chr(cp))
for raw in (b'\xff', b'\x80', b'\xc0\x80', b'\xed\xa0\x80', b'\xf4\x90\x80\x80', b'\xe2\x82'):
    source('utf8-' + raw.hex(), raw)
for label, value in (
    ('empty', ''), ('only-whitespace', '\t \n\r\n'), ('header-only', SOURCE.split('\n')[0]),
    ('missing-end', SOURCE.removesuffix('end\n')),
    ('missing-terminator', SOURCE.replace('  ret(answer)\n', '')),
    ('double-terminator', SOURCE.replace('  ret(answer)', '  ret(answer)\n  ret(answer)')),
    ('unknown-op', SOURCE.replace('int.add.wrap', 'int.add.unknown')),
    ('missing-attr', SOURCE.replace(' {"mode":"wrap"}', '')),
    ('signature-mismatch', SOURCE.replace('block entry(a:u32', 'block entry(a:u64')),
    ('undefined-value', SOURCE.replace('ret(answer)', 'ret(unknown)')),
    ('duplicate-value', SOURCE.replace('b64:u64', 'a64:u64')),
    ('duplicate-exports', SOURCE.replace('exports(total)', 'exports(total)\nexports(total)')),
    ('post-functions-export', SOURCE + 'exports(total)\n'),
    ('empty-list-item', SOURCE.replace('b:u32)', 'b:u32,)')),
    ('unknown-type', SOURCE.replace('u32', 'unknown')),
    ('long-name', SOURCE.replace('answer', 'n' * 129)),
    ('max-name', SOURCE.replace('answer', 'n' * 128)),
    ('source-max', ' ' * new.MAX_SOURCE_BYTES),
    ('source-over', ' ' * (new.MAX_SOURCE_BYTES + 1)),
    ('unicode-byte-over', '\u00e9' * (new.MAX_SOURCE_BYTES // 2 + 1)),
    ('unicode-before-byte-limit', '\ud800' * (new.MAX_SOURCE_BYTES + 1)),
    ('line-max', ' ' * new.MAX_LINE_BYTES),
    ('line-over', ' ' * (new.MAX_LINE_BYTES + 1)),
    ('line-count-max', '\n' * (new.MAX_LINES - 1)),
    ('line-count-over', '\n' * new.MAX_LINES),
):
    source(label, value)
for attrs in ('{}', '{"mode":"wrap"}', '{"mode":"wrap","mode":"checked"}',
              '{"mode":NaN}', '{"mode":Infinity}', '[]', 'null', '{',
              '{"mode":"\\ud800"}', '{"mode":"\\ud83d\\ude00"}',
              '{"mode":' + '[' * 16 + '0' + ']' * 16 + '}',
              '{"mode":' + '[' * 17 + '0' + ']' * 17 + '}',
              '{"mode":1e999}', '{"mode":0.1}', '{"mode":-0}'):
    source('attrs-' + sha256(attrs.encode()).hexdigest()[:12], SOURCE.replace('{"mode":"wrap"}', attrs, 1))
for origin in ('[]', '[null]', '["a"]', '["missing"]', '[0]', 'null', '{}',
               '["a",]', '["a","a"]', '["' + 'a' * 129 + '"]', '[NaN]', '[[]]'):
    for version in ('v6', 'v8'):
        text = SOURCE.replace('program.v6', 'program.' + version).replace(
            'effects() entry(entry)', 'effects() entry(entry) return_loans(' + origin + ')')
        source('origins-' + version + '-' + sha256(origin.encode()).hexdigest()[:12], text)
for limit, values in {
    'MAX_SOURCE_BYTES': (0, len(SOURCE.encode()) - 1, len(SOURCE.encode())),
    'MAX_LINES': (0, len(SOURCE.split('\n')) - 1, len(SOURCE.split('\n'))),
    'MAX_LINE_BYTES': (0, 5, max(map(len, SOURCE.split('\n')))),
    'MAX_FUNCTIONS': (0, 1), 'MAX_BLOCKS': (0, 1), 'MAX_OPERATIONS': (0, 2, 3),
    'MAX_LIST_ITEMS': (0, 1, 2), 'MAX_ATTRIBUTE_NODES': (0, 1, 2, 3),
    'MAX_ATTRIBUTE_DEPTH': (0, 1, 2),
}.items():
    for value in values:
        source('budget-' + limit + '-' + str(value), SOURCE, {limit: value})

class Explosive:
    def __len__(self):
        raise AssertionError('custom __len__ invoked')
    def __str__(self):
        raise AssertionError('custom __str__ invoked')
    def __iter__(self):
        raise AssertionError('custom __iter__ invoked')
class StringSubclass(str):
    def encode(self, *args, **kwargs):
        raise AssertionError('subclass encode invoked')
class DictSubclass(dict):
    def items(self):
        raise AssertionError('subclass items invoked')
for label, factory in (
    ('none', lambda: None), ('integer', lambda: 0), ('list', list), ('dict', dict),
    ('custom-object', Explosive), ('str-subclass', lambda: StringSubclass(SOURCE)),
    ('mutable-bytes', lambda: bytearray(SOURCE.encode())),
    ('memory-view', lambda: memoryview(SOURCE.encode()))):
    for api in ('assemble_program', 'diagnose_assembly', 'render_assembly'):
        compare('input-type-' + label, api, factory)

corpus = [*names.cases(), *names.value_cases(), *names.block_cases(), *names.entry_order_cases(),
          *names.refusals(), *names.value_refusals(), *names.block_refusals(), *names.entry_order_refusals()]
for i, row in enumerate(corpus):
    source('names-' + str(i) + '-' + row['id'], row['source'])

plain = old.assemble_program(SOURCE).as_dict()
documents = [('ordinary', plain), ('historical', arithmetic()),
             ('resource', {**resource_program(), 'schema': 'hepta.hia.program.v6'}),
             ('joined-loan', {**joined_loan_program(), 'schema': 'hepta.hia.program.v6'})]
for version in ('v6', 'v7', 'v8'):
    documents.append(('version-' + version, {**deepcopy(plain), 'schema': 'hepta.hia.program.' + version}))
for exports in (None, [], ['total'], ['missing'], ['total', 'total']):
    value = deepcopy(plain)
    if exports is None:
        value.pop('exports')
    else:
        value['exports'] = exports
    documents.append(('exports-' + str(exports), value))
for label, value in documents:
    compare('render-' + label, 'render_assembly', lambda value=value: deepcopy(value))
    raw = json.dumps(value).encode()
    compare('render-json-' + label, 'render_assembly', lambda raw=raw: raw)
    compare('render-forged-verified-' + label, 'render_assembly', lambda raw=raw: VerifiedProgram(raw))
for field in ('schema', 'module', 'functions', 'exports'):
    for value in (None, [], {}, 1, True, Explosive(), DictSubclass()):
        def make(field=field, value=value):
            data = deepcopy(plain)
            data[field] = value
            return data
        compare('render-field-' + field + '-' + type(value).__name__, 'render_assembly', make)
def cycle():
    value = deepcopy(plain)
    value['cycle'] = value
    return value
def alias():
    value = deepcopy(plain)
    value['functions'][0]['blocks'][0]['params'] = value['functions'][0]['params']
    return value
compare('render-cycle', 'render_assembly', cycle)
compare('render-alias', 'render_assembly', alias)
for path in ('examples/hia_recursive_chain/core_v7.json', 'examples/hia_recursive_chain/composite_v2.json'):
    raw = (root / path).read_bytes()
    compare('render-real-' + path, 'render_assembly', lambda raw=raw: raw)

assert source_before == {'old': file_digests(baseline), 'new': file_digests(root)}
encoded = json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()
(output / 'public-boundary-outcomes.json').write_bytes(encoded)
summary = {'scope': 'PUBLIC_ASSEMBLY_API_DIFFERENTIAL', 'cases': len(rows),
           'differences': 0, 'exact_outcomes_and_core_invocation_counts_equal': True,
           'wall_seconds': time.monotonic() - started, 'outcome_bytes': len(encoded),
           'outcome_sha256': sha256(encoded).hexdigest(), 'sources_preserved': True,
           'source_manifest_sha256': sha256(json.dumps(source_before, sort_keys=True).encode()).hexdigest(),
           'shared_dependency_bytes_equal': True, 'changed_sources': different_sources,
           'fixture_helper_invalid_input_behavior_claimed_equal': False,
           'cold_qualification': False}
(output / 'public-boundary-summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
print(json.dumps(summary, sort_keys=True), flush=True)
