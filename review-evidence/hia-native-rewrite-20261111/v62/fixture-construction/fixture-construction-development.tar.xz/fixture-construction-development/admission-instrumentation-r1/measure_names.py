from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--output', required=True)
p.add_argument('--name', required=True)
p.add_argument('--ledger', action='store_true')
a = p.parse_args()
root, output = Path(a.root), Path(a.output)
sys.path.insert(0, str(root))
from tools.hia_selfhost_contract import file_digests, CONTRACT_PATH
from tools.hia_selfhost_names import independent_reference
from hepta import hia_agent_assembly as assembly

def snapshot():
    return {**file_digests(), CONTRACT_PATH: sha256((root / CONTRACT_PATH).read_bytes()).hexdigest()}

before = snapshot()
records, counts = [], {'assembly': 0, 'core_verification': 0}
if a.ledger:
    original_assembly, original_verifier = assembly.assemble_program, assembly.verify_program
    def observed_assembly(source):
        caller = sys._getframe(1)
        raw = source.encode() if type(source) is str else source
        record = {'caller': caller.f_code.co_name,
            'module': str(Path(caller.f_code.co_filename).relative_to(root)),
            'source_bytes': len(raw), 'source_sha256': sha256(raw).hexdigest()}
        counts['assembly'] += 1
        try:
            result = original_assembly(source)
        except assembly.HIAProgramRejected as exc:
            record.update(accepted=False, code=exc.code, message=str(exc),
                          phase=getattr(exc, 'phase', None), line=getattr(exc, 'line', None))
            records.append(record)
            raise
        record.update(accepted=True, canonical_sha256=result.sha256)
        records.append(record)
        return result
    def observed_verifier(value):
        counts['core_verification'] += 1
        return original_verifier(value)
    assembly.assemble_program, assembly.verify_program = observed_assembly, observed_verifier
wall, cpu = time.monotonic(), time.process_time()
reference = independent_reference()
wall, cpu = time.monotonic() - wall, time.process_time() - cpu
encoded = json.dumps(reference, sort_keys=True, separators=(',', ':')).encode()
assert snapshot() == before
output.mkdir(exist_ok=True)
(output / (a.name + '.reference.json')).write_bytes(encoded)
if a.ledger:
    (output / (a.name + '.ledger.json')).write_text(json.dumps(records, sort_keys=True, indent=2) + '\n')
record = {'root': str(root), 'name': a.name, 'instrumented': a.ledger,
          'wall_seconds': wall, 'cpu_seconds': cpu,
          'reference_bytes': len(encoded), 'reference_sha256': sha256(encoded).hexdigest(),
          'source_manifest_sha256': sha256(json.dumps(before, sort_keys=True).encode()).hexdigest(),
          'sources_preserved': True, 'case_count': len(reference['cases']),
          'refusal_count': len(reference['refusals']), 'alpha_count': len(reference['alpha_compiler']),
          'counts': counts if a.ledger else None}
(output / (a.name + '.timing.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True), flush=True)
