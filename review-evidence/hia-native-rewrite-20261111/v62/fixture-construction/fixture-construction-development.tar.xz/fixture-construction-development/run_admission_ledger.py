from __future__ import annotations
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

output = Path('/dev/shm/hia-fixture-construction-performance')
roots = {'old': '/dev/shm/hia-fixture-baseline',
         'new': '/workspace/scratch/9acdfa9f5639/native-fixture-construction-next'}
ledgers, core_ledgers, timings, references = {}, {}, {}, {}
for variant, root in roots.items():
    name = 'ledger-' + variant
    command = [sys.executable, '-I', '-S', '-B', str(output / 'measure_names.py'),
               '--root', root, '--output', str(output), '--name', name, '--ledger']
    process = subprocess.run(command, cwd=output, capture_output=True, text=True, timeout=180)
    (output / (name + '.process.json')).write_text(json.dumps({
        'command': command, 'returncode': process.returncode,
        'stdout': process.stdout, 'stderr': process.stderr}, sort_keys=True, indent=2) + '\n')
    if process.returncode:
        print(process.stdout, process.stderr, flush=True)
        raise SystemExit(process.returncode)
    ledgers[variant] = json.loads((output / (name + '.ledger.json')).read_bytes())
    core_ledgers[variant] = json.loads((output / (name + '.core-ledger.json')).read_bytes())
    timings[variant] = json.loads((output / (name + '.timing.json')).read_bytes())
    references[variant] = (output / (name + '.reference.json')).read_bytes()
    print(json.dumps(timings[variant], sort_keys=True), flush=True)
assert references['old'] == references['new'] == (output / 'old-0.reference.json').read_bytes()
real = lambda row: row['caller'] == 'independent_reference' and row['module'] == 'tools/hia_selfhost_names.py'
old_witnesses = [row for row in ledgers['old'] if real(row)]
new_witnesses = [row for row in ledgers['new'] if real(row)]
assert old_witnesses == new_witnesses
assert len(old_witnesses) == 150
assert ledgers['new'] == new_witnesses
removed = [row for row in ledgers['old'] if not real(row)]
assert all(row['caller'] in {'renamed_source', 'renamed_values', 'renamed_blocks',
                            'reordered_blocks', 'render_assembly', 'cases'} for row in removed)
assert timings['old']['counts'] == {'assembly': 510, 'core_verification': 611}
assert timings['new']['counts'] == {'assembly': 150, 'core_verification': 137}
retained_core = [row for row in core_ledgers['old'] if not row['fixture_construction']]
assert retained_core == core_ledgers['new']
assert len(retained_core) == 137
assert len([row for row in core_ledgers['old'] if row['fixture_construction']]) == 474
encoded = json.dumps(new_witnesses, sort_keys=True, separators=(',', ':')).encode()
(output / 'actual-witnesses.json').write_bytes(encoded)
summary = {'scope': 'EXACT_FRESH_PUBLIC_ADMISSION_LEDGER',
           'complete_reference_bytes_equal': True, 'reference_bytes': len(references['new']),
           'reference_sha256': sha256(references['new']).hexdigest(),
           'actual_witness_count': len(new_witnesses),
           'actual_witnesses_byte_equal': True,
           'actual_witnesses_sha256': sha256(encoded).hexdigest(),
           'actual_core_gates_including_direct_generator_calls': len(retained_core),
           'actual_core_gate_ledger_equal': True,
           'old_counts': timings['old']['counts'], 'new_counts': timings['new']['counts'],
           'removed_public_calls_by_construction_caller': dict(Counter(row['caller'] for row in removed)),
           'removed_core_verification_calls': 474,
           'syntax_rejections_before_core': 15,
           'cold_qualification': False}
(output / 'admission-ledger-comparison.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
print(json.dumps(summary, sort_keys=True), flush=True)
