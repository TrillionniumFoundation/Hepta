from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tarfile

root = Path('/workspace/scratch/9acdfa9f5639/native-fixture-construction-next')
base = Path('/dev/shm/hia-fixture-baseline')
data = Path('/dev/shm/hia-fixture-construction-performance')
delivery = Path('/workspace/scratch/9acdfa9f5639/native-fixture-construction-development')
delivery.mkdir(exist_ok=True)
sys.path.insert(0, str(root))
from tools.hia_selfhost_contract import file_digests, CONTRACT_PATH

def digest(raw):
    return sha256(raw).hexdigest()

def read(name):
    return json.loads((data / name).read_bytes())

pins = read('candidate-source-pins.json')
for name, expected in pins.items():
    raw = (root / name).read_bytes()
    assert {'bytes': len(raw), 'sha256': digest(raw)} == expected
    for variant, folder in (('baseline', base), ('candidate', root)):
        target = data / 'inputs' / variant / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(folder / name, target)
for variant, folder in (('old', base), ('new', root)):
    snapshot = {**file_digests(folder), CONTRACT_PATH: digest((folder / CONTRACT_PATH).read_bytes())}
    identity = digest(json.dumps(snapshot, sort_keys=True).encode())
    assert identity == read('ledger-' + variant + '.timing.json')['source_manifest_sha256']
    (data / ('ledger-' + variant + '-source-manifest.json')).write_text(json.dumps(snapshot, sort_keys=True, indent=2) + '\n')
    target = data / 'inputs' / variant / CONTRACT_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(folder / CONTRACT_PATH, target)
shutil.copyfile('/dev/shm/hia-fixture-construction-static-review.json', data / 'independent-static-review.json')
patch = subprocess.run(['git', 'diff', '--', *pins], cwd=root, capture_output=True, check=True).stdout
(data / 'candidate.patch').write_bytes(patch)

names, panel = read('unprofiled-comparison.json'), read('complete-panel-comparison.json')
names_old = [r['wall_seconds'] for r in names['runs'] if r['name'].startswith('old')]
names_new = [r['wall_seconds'] for r in names['runs'] if r['name'].startswith('new')]
panel_old = [r['wall_seconds'] for r in panel['runs'] if r['name'].startswith('panel-old')]
panel_new = [r['wall_seconds'] for r in panel['runs'] if r['name'].startswith('panel-new')]
def performance(old, new):
    before, after = statistics.median(old), statistics.median(new)
    return {'old_wall_seconds': old, 'new_wall_seconds': new,
            'old_median_seconds': before, 'new_median_seconds': after,
            'median_seconds_saved': before - after, 'median_reduction_percent': 100 * (before - after) / before}
summary = {
    'schema': 'hepta.hia.fixture-construction-development.v1',
    'baseline_commit': '647885c5c3ff067b6477011123335ad5a1aef78e',
    'candidate_source_pins': pins,
    'names': {**performance(names_old, names_new), 'full_reference_bytes': names['bytes'],
              'full_reference_sha256': names['sha256'], 'all_six_reference_bytes_equal': True},
    'complete_pre_B0_panel': {**performance(panel_old, panel_new), 'families': 17, 'workers': 2,
        'full_reference_bytes': panel['complete_reference_bytes'],
        'full_reference_sha256': panel['complete_reference_sha256'],
        'all_four_complete_reference_bytes_equal': True,
        'contract_envelope_source_before_after_checks_executed': True},
    'admission_ledger': read('admission-ledger-comparison.json'),
    'public_boundary_differential': read('public-boundary-summary.json'),
    'focused_tests': read('focused-tests.json'),
    'independent_static_review_sha256': digest((data / 'independent-static-review.json').read_bytes()),
    'scope': 'DEVELOPMENT_PERFORMANCE_AND_EQUIVALENCE_ONLY',
    'public_admission_and_execute_gates_removed': False,
    'cached_verified_program_or_qualification_results': False,
    'budgets_selectors_workers_or_deadline_changed': False,
    'new_HIA_native_owner_claimed': False,
    'cold_qualification': False,
    'whole_native_delivery_qualified': False,
    'compatibility': 'The four tools.hia_selfhost_names fixture authoring helpers now construct syntax bytes only. Their invalid-input refusal behavior is intentionally not claimed identical; actual consumers and public assemble/render retain all complete admissions.',
    'retained_instrumentation_correction': 'admission-instrumentation-r1 retains initial alias-only verifier ledger and failed expected-count assertion. The corrected global ledger also observes two unchanged direct generator Core checks: 611->137, not alias-only 609->135; 15 syntax rejections, not the initial estimated 13.',
    'original_unprofiled_names_measure_script': 'admission-instrumentation-r1/measure_names.py',
}
(data / 'summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
readme = f'''# Fixture construction development evidence

This candidate removes repeated semantic admission from author-only name/SSA/block fixture transformations. The public assembly parser and renderer retain their complete Core admissions, syntax budgets, JSON attribute checks, profile checks, detached snapshot, and canonical round trip. Every actual reference/native qualification witness remains in place. The four tool fixture helpers now return construction bytes; their refusal behavior on invalid caller input is deliberately not represented as the public API contract.

## Measured outcomes

- Names, six fresh interleaved runs: old {names_old}; new {names_new} seconds. All six complete {names['bytes']:,}-byte reference reports are byte-identical.
- Complete 17-family pre-B0 panel, four fresh runs through the unchanged two-worker scheduler: old {panel_old}; new {panel_new} seconds. All four complete {panel['complete_reference_bytes']:,}-byte payloads are byte-identical. Every fresh worker performed normal contract/envelope/source checks.
- The retained admission ledger is identical for all 150 real public assembly calls and all 137 real Core verification calls. It retains 106 VM inputs, 40 profile refusal controls, four alpha assemblies, and two generator direct checks. Removed constructor-only Core calls: 474.
- Public API boundary differential: 684 cases, exact bytes or complete diagnostic plus verifier invocation counts; zero differences. Shared dependency bytes and source-before/source-after bindings were checked.
- Focused assembly/names/efficiency tests: 33 run, zero errors, failures, skips, expected failures, or unexpected successes.

This evidence measures development performance and finite equivalence. It is not a successful whole cold run, a native compiler qualification, a new native owner, an all-input proof, or authorization to delete a Python owner. The 180-second deadline, two-worker budget, selectors, phase inventory and validation limits are unchanged. The main integration must regenerate its own v62 contract/inventories and perform fresh qualification.

## Custody

`summary.json` records source pins and exact payload hashes. `inputs/` stores the three baseline/candidate files and the actual old/new contracts used by the panel. Source manifests preserve every bound payload. All six names runs, all four complete panel directories (17 worker envelopes and receipts each), complete reference JSON, focused logs, public outcomes, direct/public verifier ledgers and the independent static review are retained. The initial external instrumentation count assertion failure is also retained under `admission-instrumentation-r1`; it was corrected by observing the two direct generator checks, without changing candidate code or any admission.

Only these three repository files are proposed for integration: `hepta/hia_agent_assembly.py`, `tools/hia_selfhost_names.py`, and `tests/test_hia_reference_fixture_efficiency.py`. The candidate's regenerated v61 support JSON is retained as experimental input custody, not proposed as the integrated v62 support file.
'''
(data / 'README.md').write_text(readme)
members = []
for path in sorted(data.rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        members.append({'path': path.relative_to(data).as_posix(), 'bytes': len(raw), 'sha256': digest(raw)})
manifest = {'schema': 'hepta.hia.fixture-construction-evidence-custody.v1',
            'member_count': len(members), 'raw_bytes': sum(r['bytes'] for r in members), 'members': members}
archive = delivery / 'fixture-construction-development.tar.xz'
with tarfile.open(archive, 'w:xz', preset=1) as tar:
    for member in members:
        tar.add(data / member['path'], arcname='fixture-construction-development/' + member['path'], recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    actual = tar.getmembers()
    assert len(actual) == len(members)
    for expected, member in zip(members, actual):
        assert member.name == 'fixture-construction-development/' + expected['path']
        raw = tar.extractfile(member).read()
        assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256']
        assert raw == (data / expected['path']).read_bytes()
raw = archive.read_bytes()
manifest.update(archive=archive.name, archive_bytes=len(raw), archive_sha256=digest(raw),
                every_member_original_bytes_and_sha_verified=True)
(delivery / 'custody.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
shutil.copyfile(data / 'summary.json', delivery / 'summary.json')
shutil.copyfile(data / 'README.md', delivery / 'README.md')
shutil.copyfile(data / 'candidate.patch', delivery / 'candidate.patch')
print(json.dumps({k: v for k, v in manifest.items() if k != 'members'}, sort_keys=True), flush=True)
