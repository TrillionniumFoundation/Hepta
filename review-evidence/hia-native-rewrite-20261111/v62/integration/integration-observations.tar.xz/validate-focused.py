from pathlib import Path
import hashlib,json,os,sys,time,unittest
root=Path('/workspace/scratch/9acdfa9f5639/Hepta');sys.path.insert(0,str(root));os.chdir(root)
out=Path('/dev/shm/hia-v62-integration/focused');out.mkdir(exist_ok=True)
for key in tuple(os.environ):
 if key.startswith('HEPTA_HIA_') and (key.endswith('_COLD_REPORT') or key.endswith('_MANIFEST')): os.environ.pop(key)
os.environ['HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST']='/workspace/scratch/9acdfa9f5639/native-signature-development/manifest-r2.json'
os.environ['HEPTA_HIA_TASK_HELPERS_DEVELOPMENT_MANIFEST']='/workspace/scratch/9acdfa9f5639/native-helper-development/manifest.json'
from tools.hia_selfhost_contract import file_digests,CONTRACT_PATH

def sources():
 d=file_digests();d[CONTRACT_PATH]=hashlib.sha256((root/CONTRACT_PATH).read_bytes()).hexdigest();return d
before=sources();(out/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
groups={
 'source-adapter':[
  'tests.test_hia_core_only','tests.test_hia_selfhost_contract.SelfhostContractTests','tests.test_hia_integrated_workflow',
  'tests.test_hia_native_builder_source_binding','tests.test_hia_agent_installed_resources.AgentInstalledResourceSourceTests'],
 'joint-native':[
  'tests.test_hia_composite_types_native','tests.test_hia_composite_origins_native',
  'tests.test_hia_composite_signatures_native','tests.test_hia_task_helpers_native']}
summary={'scope':'DEVELOPMENT_ONLY_NOT_COLD_QUALIFICATION','groups':[]}
for label,names in groups.items():
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as stream:
  suite=unittest.defaultTestLoader.loadTestsFromNames(names)
  result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 rec={'name':label,'names':names,'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses),'wall_seconds':time.monotonic()-start}
 rec['pass']=result.wasSuccessful() and not any(rec[k] for k in ('errors','failures','skipped','expected_failures','unexpected_successes'))
 summary['groups'].append(rec);(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if not rec['pass']: break
after=sources();(out/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
summary['source_unchanged']=before==after
summary['status']='PASS' if len(summary['groups'])==len(groups) and all(r['pass'] for r in summary['groups']) and before==after else 'FAIL'
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
raise SystemExit(0 if summary['status']=='PASS' else 1)
