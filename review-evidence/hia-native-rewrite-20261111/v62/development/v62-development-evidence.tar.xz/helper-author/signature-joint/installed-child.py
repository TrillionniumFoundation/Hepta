import sys,importlib.abc
sys.path.insert(0,sys.argv[1])
class NoTools(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='tools' or fullname.startswith('tools.'):
            raise AssertionError('installed owners imported checkout tools')
sys.meta_path.insert(0,NoTools())
from pathlib import Path
from hepta import hia_program_composite as composite
from hepta.hia_program import verify_core,HIAProgramRejected
from hepta.hia_composite_types_native import SOURCE as TYPES
from hepta.hia_task_helpers_native import SOURCE as HELPERS
assert all(Path(sys.argv[1]) in p.parents for p in (TYPES,HELPERS))
def absent(*args,**kwargs):raise AssertionError('hosted semantic owner called')
composite._Types=absent
for name in ('_reference_parameters','_reference_check_task','_reference_helper','loan_origins'):
    setattr(composite._Elaborator,name,absent)
try:checked=verify_core(Path(sys.argv[2]).read_bytes())
except HIAProgramRejected:
    if sys.argv[3]=='refuse':print('REFUSED')
    else:raise
else:
    assert sys.argv[3]=='accept'
    sys.stdout.buffer.write(checked.canonical_bytes)
