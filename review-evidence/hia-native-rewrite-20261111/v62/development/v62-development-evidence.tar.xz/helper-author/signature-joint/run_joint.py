from __future__ import annotations
from contextlib import ExitStack
from hashlib import sha256
from pathlib import Path
import ast
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
from unittest.mock import patch

BASE = Path('/workspace/scratch/9acdfa9f5639/native-helper-next')
SIGNATURES = Path('/workspace/scratch/9acdfa9f5639/native-signature-next')
OUT = Path(__file__).resolve().parent
ROOT = OUT / 'overlay'
HELPER_MANIFEST = Path('/workspace/scratch/9acdfa9f5639/native-helper-development/manifest.json')
SIGNATURE_MANIFEST = Path('/workspace/scratch/9acdfa9f5639/native-signature-development/manifest-r2.json')


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def wire(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def segment(text, name):
    cls = next(node for node in ast.parse(text).body if isinstance(node, ast.ClassDef) and node.name == '_Elaborator')
    method = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == name)
    return ''.join(text.splitlines(keepends=True)[method.lineno - 1:method.end_lineno])


pins = {
    str(BASE / 'tools/generate_hia_task_helpers.py'): 'd77fce280b3cd0a56f770aeab88d4f009da079a2117cf6a4cc5c15f94e61541c',
    str(BASE / 'hepta/hia_task_helpers_native.py'): 'afc071582363f01f5a98f5c247101b9d4ddee4928361f60f5c5cc7adf12ae290',
    str(BASE / 'hepta/hia_program_composite.py'): 'beb27957c5ae0f56e520d8453742934149e5ef17f67a36a3008f4343d3110504',
    str(BASE / 'examples/hia_bootstrap/task_helpers.hiaasm'): '1f0a38ab1235de3ffc35ca3ca01ac327bbea3ceadac99a995d3b550b630790cd',
    str(SIGNATURES / 'hepta/hia_composite_types_native.py'): '56cd4eebefcc5b7a77b496829b6e9d0c62435630432bed9eaf46c00cb27b54c2',
    str(SIGNATURES / 'hepta/hia_program_composite.py'): '4adaa029918ff2b7faeda5d6e611724e4260f2911dfb03580c68dcd5ad17b94d',
    str(SIGNATURES / 'examples/hia_bootstrap/composite_types.hiaasm'): '8fec677e2a7be2292241a4ecf51c0e4c807a63f945928dd3c8eb03a79a42d749',
}
for path, expected in pins.items():
    assert digest(path) == expected, path
for manifest in (HELPER_MANIFEST, SIGNATURE_MANIFEST):
    value = json.loads(manifest.read_bytes())
    image = manifest.parent / value['image_path']
    assert digest(image) == value['image_sha256']
    pins[str(manifest)], pins[str(image)] = digest(manifest), digest(image)
ROOT.mkdir()
shutil.copytree(BASE / 'hepta', ROOT / 'hepta', ignore=shutil.ignore_patterns('__pycache__'))
for name in ('setup.py', 'pyproject.toml', 'MANIFEST.in'):
    shutil.copyfile(BASE / name, ROOT / name)
resources = ast.parse((BASE / 'hepta/hia_agent_contract.py').read_bytes())
for node in resources.body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ('DISCOVERY_FILES', 'NATIVE_SOURCE_FILES', 'PUBLICATION_BUILD_FILES'):
                for name in ast.literal_eval(node.value):
                    if target.id == 'DISCOVERY_FILES':
                        name = 'docs/' + name
                    destination = ROOT / name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(BASE / name, destination)
for name in ('hepta/hia_composite_types_native.py', 'examples/hia_bootstrap/composite_types.hiaasm'):
    shutil.copyfile(SIGNATURES / name, ROOT / name)
signature_text = (SIGNATURES / 'hepta/hia_program_composite.py').read_text()
helper_text = (BASE / 'hepta/hia_program_composite.py').read_text()
old = segment(signature_text, 'helper')
reference = segment(helper_text, '_reference_helper')
assert old.replace('def helper(', 'def _reference_helper(', 1) == reference
merged = signature_text.replace(old, segment(helper_text, 'helper') + '\n\n' + reference, 1)
(ROOT / 'hepta/hia_program_composite.py').write_text(merged)
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(ROOT))
from hepta import hia_program_composite as composite
from hepta.hia_program import verify_core
from hepta.hia_program_runtime import execute_program
from hepta.hia_composite_types_native import SELECTOR as TYPE_SELECTOR, installed_composite_types
from hepta.hia_task_helpers_native import SELECTOR as HELPER_SELECTOR, installed_task_helpers
from tests import test_hia_program_composite as fixtures
from tests import test_hia_partial_record as partials
from tests import test_hia_composite_returned_loans as loans
from tests import test_hia_composite_v6_resources as resources

selected = {TYPE_SELECTOR: str(SIGNATURE_MANIFEST), HELPER_SELECTOR: str(HELPER_MANIFEST)}
native_types = installed_composite_types(str(SIGNATURE_MANIFEST))
native_helper = installed_task_helpers(str(HELPER_MANIFEST))
entered = {'types': 0, 'helper': 0}


def observe(name, original):
    def entry(source, size, *buffers):
        before = ctypes.string_at(source, size)
        result = original(source, size, *buffers)
        assert ctypes.string_at(source, size) == before
        entered[name] += 1
        return result
    return entry


def absent(*args, **kwargs):
    raise AssertionError('disabled hosted nominal semantic owner called')


cases = [
    ('ordinary', fixtures.task_program, 'task_case', [[0], [1], [2], [255]]),
    ('scalar', fixtures.scalar_task_program, 'scalar_task', [[]]),
    ('owned_result', fixtures.owned_result_task_program, 'owned_result', [[0], [9]]),
    ('partial', partials.task_partial_program, 'partial_task', [[9, 0], [9, 1], [9, 2]]),
    ('returned_loan', loans.task_program, 'task_probe', [[9, 0], [9, 1], [9, 2]]),
    ('range', resources.composite_range_task_program, 'task_case', [[0], [1], [2], [255]]),
]
records = []
started = time.monotonic()
for label, factory, function, args_list in cases:
    source = wire(factory())
    (OUT / (label + '.input.json')).write_bytes(source)
    with patch.dict(os.environ, {TYPE_SELECTOR: '', HELPER_SELECTOR: ''}):
        expected = verify_core(source)
    with ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, selected))
        stack.enter_context(patch.object(composite, '_Types', side_effect=absent))
        for name in ('_reference_parameters', '_reference_check_task', '_reference_helper', 'loan_origins'):
            stack.enter_context(patch.object(composite._Elaborator, name, side_effect=absent))
        stack.enter_context(patch.object(native_types, '_entry', side_effect=observe('types', native_types._entry)))
        stack.enter_context(patch.object(native_helper, '_entry', side_effect=observe('helper', native_helper._entry)))
        actual = verify_core(source)
    assert (actual.canonical_bytes, actual.structured_bytes) == (expected.canonical_bytes, expected.structured_bytes)
    (OUT / (label + '.canonical.json')).write_bytes(actual.canonical_bytes)
    runs = []
    for args in args_list:
        for failure in (None, 1):
            old = execute_program(expected, function, args, allocation_fail_at=failure)
            new = execute_program(actual, function, args, allocation_fail_at=failure)
            assert old == new and new['resources']['live_owners'] == new['resources']['live_local_loans'] == 0
            runs.append({'args': args, 'allocation_fail_at': failure, 'report': new})
    records.append({'label': label, 'source_sha256': sha256(source).hexdigest(),
                    'canonical_sha256': actual.sha256, 'normalized_bytes_equal': True, 'executions': runs})

wheels, installed = OUT / 'wheels', OUT / 'installed'
build = subprocess.run([sys.executable, '-B', '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
    '--wheel-dir', str(wheels), str(ROOT)], cwd=ROOT, capture_output=True, timeout=120,
    env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': '/dev/shm'})
(OUT / 'wheel-build.stdout.log').write_bytes(build.stdout)
(OUT / 'wheel-build.stderr.log').write_bytes(build.stderr)
assert build.returncode == 0
wheel, = wheels.glob('*.whl')
install = subprocess.run([sys.executable, '-B', '-m', 'pip', 'install', '--no-deps', '--no-index',
    '--target', str(installed), str(wheel)], cwd=OUT, capture_output=True, timeout=120,
    env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': '/dev/shm'})
(OUT / 'wheel-install.stdout.log').write_bytes(install.stdout)
(OUT / 'wheel-install.stderr.log').write_bytes(install.stderr)
assert install.returncode == 0
child = '''import sys,importlib.abc
sys.path.insert(0,sys.argv[1])
class NoTools(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='tools' or fullname.startswith('tools.'):
            raise AssertionError('installed owners imported checkout tools')
sys.meta_path.insert(0,NoTools())
from pathlib import Path
from hepta import hia_program_composite as composite
from hepta.hia_program import verify_core,HIAProgramRejected
from hepta.hia_composite_types_native import SOURCE as TYPES
from hepta.hia_task_helpers_native import SOURCE as HELPERS
assert all(Path(sys.argv[1]) in p.parents for p in (TYPES,HELPERS))
def absent(*args,**kwargs):raise AssertionError('hosted semantic owner called')
composite._Types=absent
for name in ('_reference_parameters','_reference_check_task','_reference_helper','loan_origins'):
    setattr(composite._Elaborator,name,absent)
try:checked=verify_core(Path(sys.argv[2]).read_bytes())
except HIAProgramRejected:
    if sys.argv[3]=='refuse':print('REFUSED')
    else:raise
else:
    assert sys.argv[3]=='accept'
    sys.stdout.buffer.write(checked.canonical_bytes)
'''
(OUT / 'installed-child.py').write_text(child)
installed_records = []
for label, *_ in cases:
    result = subprocess.run([sys.executable, '-I', '-S', '-B', '-c', child,
        str(installed), str(OUT / (label + '.input.json')), 'accept'], cwd=OUT,
        env={'PATH': '', 'LANG': 'C', 'LC_ALL': 'C', **selected}, capture_output=True, timeout=30)
    (OUT / (label + '.installed.stdout.bin')).write_bytes(result.stdout)
    (OUT / (label + '.installed.stderr.log')).write_bytes(result.stderr)
    assert result.returncode == 0 and result.stderr == b''
    assert result.stdout == (OUT / (label + '.canonical.json')).read_bytes()
    installed_records.append({'label': label, 'returncode': result.returncode,
        'canonical_sha256': sha256(result.stdout).hexdigest(), 'exact_bytes_equal': True})
refusals = []
for name in ('composite_types', 'task_helpers'):
    path = installed / 'hepta/_data/examples/hia_bootstrap' / (name + '.hiaasm')
    original = path.read_bytes()
    for missing in (False, True):
        try:
            path.unlink() if missing else path.write_bytes(original + b'\n')
            result = subprocess.run([sys.executable, '-I', '-S', '-B', '-c', child,
                str(installed), str(OUT / 'returned_loan.input.json'), 'refuse'], cwd=OUT,
                env={'PATH': '', 'LANG': 'C', 'LC_ALL': 'C', **selected}, capture_output=True, timeout=30)
            assert (result.returncode, result.stdout, result.stderr) == (0, b'REFUSED\n', b'')
            refusals.append({'resource': name, 'missing': missing, 'refused': True})
        finally:
            path.write_bytes(original)
for path, expected in pins.items():
    assert digest(path) == expected, path
summary = {'scope': 'DEVELOPMENT_ONLY', 'status': 'PASS', 'wall_seconds': time.monotonic() - started,
    'matching_source_cold_qualified': False, 'whole_native_delivery_qualified': False,
    'source_pins_before_and_after': pins,
    'merged_composite_sha256': digest(ROOT / 'hepta/hia_program_composite.py'),
    'actual_native_entry_counts': entered, 'normalized_documents': len(records),
    'execution_comparisons': sum(len(row['executions']) for row in records),
    'host_owners_disabled': ['_Types', '_reference_parameters', '_reference_check_task', 'loan_origins', '_reference_helper'],
    'records': records, 'installed_records': installed_records, 'installed_resource_refusals': refusals,
    'wheel_sha256': digest(wheel)}
(OUT / 'summary.json').write_bytes(wire(summary) + b'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('records', 'source_pins_before_and_after')}, sort_keys=True), flush=True)
