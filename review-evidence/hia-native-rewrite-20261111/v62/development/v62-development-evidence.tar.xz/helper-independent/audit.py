from __future__ import annotations
from collections import Counter
from copy import deepcopy
import ctypes
import gzip
from hashlib import sha256
import json
import os
from pathlib import Path
import random
import struct
import sys
import time
from unittest.mock import patch

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-helper-next')
OUT = Path(__file__).resolve().parent
MANIFEST = Path('/workspace/scratch/9acdfa9f5639/native-helper-development/manifest.json')
sys.path.insert(0, str(ROOT))
from hepta import hia_program_composite as c
from hepta.hia_program import HIAProgramRejected, EFFECTS
from hepta.hia_task_helpers_native import installed_task_helpers, SELECTOR

PINNED = {
    'tools/generate_hia_task_helpers.py': 'd77fce280b3cd0a56f770aeab88d4f009da079a2117cf6a4cc5c15f94e61541c',
    'examples/hia_bootstrap/task_helpers.hiaasm': '1f0a38ab1235de3ffc35ca3ca01ac327bbea3ceadac99a995d3b550b630790cd',
    'hepta/hia_task_helpers_native.py': 'afc071582363f01f5a98f5c247101b9d4ddee4928361f60f5c5cc7adf12ae290',
    'hepta/hia_program_composite.py': 'beb27957c5ae0f56e520d8453742934149e5ef17f67a36a3008f4343d3110504',
}


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def snapshot():
    return {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in PINNED}


def record(name, fields):
    return {'name': name, 'params': [], 'kind': 'record',
            'fields': [{'name': n, 'type': t} for n, t in fields]}


def make_graph(seed, *, state_width=None, result_width=None, loan=None):
    rng = random.Random(seed)
    scalars = ['bool', 'unit', 'i8', 'u16', 'i32', 'u64', 'isize', 'usize', 'buffer', 'chain']
    state_width = rng.randrange(0, 48) if state_width is None else state_width
    result_width = rng.randrange(0, 48) if result_width is None else result_width
    fields = lambda count: [('v' + str(i), rng.choice(scalars)) for i in range(count)]
    definitions = [record('Empty', [])]
    for label, width in [('State', state_width), ('Result', result_width)]:
        pieces = []
        for begin in range(0, width, 64):
            name = label + 'Part' + str(begin // 64)
            definitions.append(record(name, fields(min(64, width - begin))))
            pieces.append(('part' + str(begin // 64), name))
        definitions.append(record(label, pieces))
    variants = [dict(name='pending', fields=[dict(name='s', type='State')]),
                dict(name='ready', fields=[dict(name='r', type='Result')])]
    if seed & 1:
        variants.reverse()
    poll_name = 'p' * (128 if seed % 7 == 0 else 5)
    cancel_name = 'c' * (128 if seed % 11 == 0 else 7)
    definitions += [dict(name='Step', params=[], kind='enum', variants=variants),
        dict(name='Job', params=[], kind='task', state='State', result='Result',
             poll=poll_name, cancel=cancel_name)]
    types = c._Types(definitions, recursive_chain=True, partial_records=True)
    task, step = types.resolve('Job'), types.resolve('Step')
    if loan is not None:
        # Explicitly unreachable direct-helper controls, not public task declarations.
        state = c._Type('PrivateState', 'record', task.state.flat + (loan,))
        result = c._Type('PrivateResult', 'record', task.result.flat + (loan,))
        pairs = [('pending', (('s', state),)), ('ready', (('r', result),))]
        if seed & 1:
            pairs.reverse()
        step = c._Type('PrivateStep', 'enum', ('u32',) + tuple(
            slot for _, fs in pairs for _, typ in fs for slot in typ.flat), variants=tuple(pairs))
        task = c._Type('PrivateJob', 'task', ('u8', 'buffer') + state.flat + result.flat,
            state=state, result=result, poll=poll_name, cancel=cancel_name, linear=True)
    effects = sorted(EFFECTS)
    poll_effects = rng.sample(effects, rng.randrange(len(effects) + 1))
    cancel_effects = rng.sample(effects, rng.randrange(len(effects) + 1))
    return task, step, definitions, poll_effects, cancel_effects


def owner(task, step, poll_effects, cancel_effects, serial):
    value = object.__new__(c._Elaborator)
    value.native_types = None
    value.serial, value.value_slots = serial, 0
    value.helpers, value.helper_names = [], {}
    value.functions = {task.poll: {'effects': deepcopy(poll_effects)},
                       task.cancel: {'effects': deepcopy(cancel_effects)}}
    value.signatures = {task.poll: ((('incoming', task.state),), (step,)),
                        task.cancel: ((('incoming', task.state),), ())}
    return value


def observed(value, typ, operation, method):
    try:
        result, error = method(value, typ, operation), None
    except HIAProgramRejected as exc:
        result, error = None, [exc.code, str(exc)]
    return {'result': result, 'error': error, 'serial': value.serial,
            'helpers': deepcopy(value.helpers),
            'cache': sorted([list(k) + [v] for k, v in value.helper_names.items()])}


def unavailable(*args, **kwargs):
    raise AssertionError('selected native helper invoked the hosted semantic owner')


def main():
    before = snapshot()
    if before != PINNED:
        raise AssertionError({'source_changed_before_audit': before})
    native = installed_task_helpers(MANIFEST)
    entry = native._entry
    original = c._Elaborator._reference_helper
    selected = c._Elaborator.helper
    counts = Counter()
    start = time.monotonic()
    case_index = 0
    invocation_index = 0
    with gzip.open(OUT / 'cases.jsonl.gz', 'wt', encoding='utf-8') as cases, \
         gzip.open(OUT / 'native-entries.jsonl.gz', 'wt', encoding='utf-8') as entries:
        def traced(source, size, output, output_size, work, work_size):
            nonlocal invocation_index
            payload = ctypes.string_at(source, size)
            extent = entry(source, size, output, output_size, work, work_size)
            unchanged = ctypes.string_at(source, size) == payload
            if not unchanged:
                raise AssertionError('native modified input bytes')
            frame = ctypes.string_at(output, extent) if 64 <= extent <= output_size else b''
            entries.write(json.dumps({'index': invocation_index, 'case': case_index,
                'input_bytes': size, 'input_sha256': sha256(payload).hexdigest(),
                'output_extent': extent, 'output_sha256': sha256(frame).hexdigest(),
                'header': list(struct.unpack_from('<8Q', frame)) if frame else [],
                'input_unchanged': unchanged}, sort_keys=True) + '\n')
            invocation_index += 1
            return extent
        native._entry = traced
        def compare(graph, serial, operations, scope):
            nonlocal case_index
            task, step, definitions, pe, ce = graph
            left, right = owner(task, step, pe, ce, serial), owner(task, step, pe, ce, serial)
            for operation in operations:
                expected = observed(left, task, operation, original)
                with patch.object(c._Elaborator, '_reference_helper', unavailable), \
                     patch('hepta.hia_task_helpers_native.selected_task_helpers', return_value=native):
                    actual = observed(right, task, operation, selected)
                equal = expected == actual
                row = {'case': case_index, 'scope': scope, 'operation': operation,
                    'initial_history_serial': serial, 'definitions': definitions,
                    'state_flat': task.state.flat, 'result_flat': task.result.flat,
                    'poll_effects': pe, 'cancel_effects': ce,
                    'expected': expected, 'actual': actual, 'equal': equal}
                cases.write(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n')
                counts['cases'] += 1
                counts['accepted' if expected['error'] is None else expected['error'][0]] += 1
                counts[scope] += 1
                case_index += 1
                if not equal:
                    raise AssertionError({'case': case_index - 1, 'operation': operation})
        operations = ['poll', 'cancel', 'start', 'join', 'close', 'poll', 'cancel']
        for seed in range(48):
            graph = make_graph(803000 + seed)
            compare(graph, random.Random(seed).randrange(500), operations, 'reachable_declaration_graph')
            for operation in operations[:5]:
                task, step, _, pe, ce = graph
                baseline = owner(task, step, pe, ce, 0)
                observed(baseline, task, operation, original)
                delta = baseline.serial
                for serial in (8192 - delta, 8193 - delta, 8191, 8192):
                    compare(graph, serial, [operation, operation], 'fresh_counter_boundary')
        for state_width, result_width in [(0, 0), (0, 510), (510, 0), (255, 255), (63, 447)]:
            for reverse in (0, 1):
                compare(make_graph(901000 + reverse, state_width=state_width, result_width=result_width),
                        0, operations, 'maximum_public_layout')
        for seed in range(16):
            graph = make_graph(902000 + seed, loan='mutbuf' if seed & 2 else 'readbuf')
            for serial in (0, 8100, 8191, 8192):
                compare(graph, serial, operations, 'unreachable_direct_loan_control')
    after = snapshot()
    if after != before:
        raise AssertionError('candidate source changed during audit')
    summary = {'schema': 'hepta.hia.independent-task-helper-audit.v1',
        'status': 'DEVELOPMENT_DIFFERENTIAL_PASS', 'source': before,
        'manifest_sha256': sha256(MANIFEST.read_bytes()).hexdigest(),
        'image_sha256': sha256(Path('/workspace/scratch/9acdfa9f5639/native-helper-development/task-helpers.image.bin').read_bytes()).hexdigest(),
        'counts': dict(counts), 'native_entries': invocation_index,
        'source_preserved': after == before, 'input_bytes_preserved': True,
        'complete_core_and_error_text_and_serial_and_cache_compared': True,
        'host_helper_disabled_on_selected_path': True,
        'cold_qualification': False, 'whole_native_delivery_qualified': False,
        'seconds': time.monotonic() - start,
        'raw_records': {p.name: {'bytes': p.stat().st_size, 'sha256': sha256(p.read_bytes()).hexdigest()}
                        for p in (OUT / 'cases.jsonl.gz', OUT / 'native-entries.jsonl.gz')}}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True))


if __name__ == '__main__':
    main()
