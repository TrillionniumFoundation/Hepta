"""Independent actual-HIA constructor replay of the root's public 134 corpus.

This is a development differential, not a cold or whole-stack qualification.
The retained initializer and HIA initializer use the SAME native Types image.
Only the root observer function is AST-extracted: importing its script would
silently redirect sys.path to a different, frozen function checkout.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from contextlib import ExitStack
from copy import deepcopy
import ctypes
import gc
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import subprocess
import sys
import time
import traceback
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/9acdfa9f5639')
ROOT = BASE / 'native-constructor-next'
EVIDENCE = Path(__file__).resolve().parent
AUTHOR = BASE / 'hia-constructor-native-development'
STAGE = AUTHOR / 'stage5-source.json'
CORPUS = BASE / 'hia-function-independent-recovery/public-cases.json'
ROOT_OBSERVER = BASE / 'hia-function-independent-recovery/replay_functions_fresh.py'
TYPE_MANIFEST = (BASE / 'hia-function-recovery/frozen-inputs/native-inputs/'
                 'native-signature-development/manifest-r2.json')
BUNDLE_MANIFEST = AUTHOR / 'bundle-r1.json'
EXPECTED_CORPUS_SHA = '2412f165cb55638b98f86f0a41f93a1cc6aa7231d45e4aca7822fa39d0802373'
EXPECTED_TYPE_SOURCE = '8fec677e2a7be2292241a4ecf51c0e4c807a63f945928dd3c8eb03a79a42d749'
EXPECTED_TYPE_IMAGE = '504298b05b0d1c87469525c6e5ffa960c6dc1b72367eceb482dacee6c8c33dbc'
EXPECTED_ADAPTER = '2a4642a50aa99a8ddea9881b76fb6a8ddb716ce4c338f1e981b634f42b26e021'

REMOVED_SELECTORS = {}
for name in tuple(os.environ):
    if name.startswith('HEPTA_HIA_') and (name.endswith('_MANIFEST') or name.endswith('_COLD_REPORT')):
        REMOVED_SELECTORS[name] = os.environ.pop(name)
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
from hepta import hia_program_composite as composite
from hepta import hia_composite_types_native as native_types
from hepta import hia_composite_constructor_native as native_constructor
from hepta import hia_composite_functions_native as native_functions
from hepta.hia_program import HIAProgramRejected, _decode
from tests.test_hia_composite_types_native import native_key, snapshot

RETAINED = composite._Elaborator._reference_initialize
ATTRIBUTES = ('document', 'serial', 'value_slots', 'nominal_operations', 'native_types',
              'types', 'parameter_loan_returns', 'functions', 'signatures',
              'return_origins', 'helpers', 'helper_names')


def wire(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode()


def detached(value):
    return json.loads(wire(value))


def rejected(error):
    return {'class_name': type(error).__name__, 'code': getattr(error, 'code', None),
            'text': str(error)}


def forbidden(*args, **kwargs):
    raise AssertionError('retained semantic owner invoked on isolated native constructor path')


def digest(path):
    path = Path(path)
    raw = path.read_bytes()
    info = path.stat()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'mode': stat.S_IMODE(info.st_mode)}


def write_json(path, value):
    path.write_bytes(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode() + b'\n')


def first_difference(left, right, path=''):
    if type(left) is not type(right):
        return {'path': path, 'expected': left, 'actual': right}
    if isinstance(left, dict):
        if set(left) != set(right):
            return {'path': path, 'expected_keys': sorted(left), 'actual_keys': sorted(right)}
        for key in left:
            if left[key] != right[key]:
                return first_difference(left[key], right[key], path + '/' + str(key))
    elif isinstance(left, list):
        if len(left) != len(right):
            return {'path': path, 'expected_length': len(left), 'actual_length': len(right)}
        for index, (a, b) in enumerate(zip(left, right)):
            if a != b:
                return first_difference(a, b, path + '/' + str(index))
    elif left != right:
        return {'path': path, 'expected': left, 'actual': right}
    return None


# Preserve the exact root observation logic without executing its imports,
# sys.path insertion, chdir, or main. The function sees THIS candidate's types.
_root_ast = ast.parse(ROOT_OBSERVER.read_bytes(), filename=str(ROOT_OBSERVER))
_owner_ast = next(node for node in _root_ast.body
                  if isinstance(node, ast.FunctionDef) and node.name == 'owner_state')
_owner_module = ast.Module(body=[_owner_ast], type_ignores=[])
exec(compile(ast.fix_missing_locations(_owner_module), str(ROOT_OBSERVER), 'exec'), globals())
root_owner_state = owner_state


def session_state(session):
    return detached({
        'attributes': sorted(vars(session)),
        'closed': session._closed,
        'broken': session._broken,
        'observations': session.observations,
        'descriptor_order': list(session._descriptors),
        'descriptors': [[key, value] for key, value in session._descriptors.items()],
        'issued_type_order': list(session._types),
        'identity_mapping_exact': all(session._ids.get(id(typ)) == key
                                      for key, typ in session._types.items()),
        'inverse_identity_mapping_exact': len(session._ids) == len(session._types),
        'live_state': session._state is not None,
        'live_output': session._output is not None,
    })


def complete_owner_state(owner, document):
    result = root_owner_state(owner)
    result['all_attributes'] = sorted(vars(owner))
    if hasattr(owner, 'document'):
        result['document'] = deepcopy(owner.document)
        result['document_identity'] = owner.document is document
    if hasattr(owner, 'types'):
        result['types_native_identity'] = owner.types is owner.native_types
        result['session'] = session_state(owner.native_types)
    if hasattr(owner, 'functions'):
        members = document['functions']
        result['function_alias_indices'] = [
            [name, [index for index, item in enumerate(members) if fn is item]]
            for name, fn in owner.functions.items()]
        result['function_values'] = [[name, deepcopy(fn)] for name, fn in owner.functions.items()]
    if hasattr(owner, 'signatures'):
        session = owner.native_types
        result['signature_ids'] = [
            [name, [[name, session._ids[id(typ)]] for name, typ in params],
             [session._ids[id(typ)] for typ in returns]]
            for name, (params, returns) in owner.signatures.items()]
    for name in ('functions', 'signatures', 'return_origins', 'helper_names'):
        if hasattr(owner, name):
            result[name + '_key_order'] = list(getattr(owner, name))
    if hasattr(owner, '_native_function_session'):
        result['function_session_is_none'] = owner._native_function_session is None
    return detached(result)


def source_paths():
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
                                     '--exclude-standard', '-z'], cwd=ROOT).split(b'\0')
    paths = {ROOT / os.fsdecode(name) for name in names if name}
    paths.update((STAGE, CORPUS, ROOT_OBSERVER, Path(__file__), TYPE_MANIFEST,
                  BUNDLE_MANIFEST, AUTHOR / 'compile-r1.json'))
    type_manifest = json.loads(TYPE_MANIFEST.read_bytes())
    paths.add(TYPE_MANIFEST.parent / type_manifest['image_path'])
    bundle = json.loads(BUNDLE_MANIFEST.read_bytes())
    for name, relative in bundle['kernels'].items():
        manifest_path = BUNDLE_MANIFEST.parent / relative
        paths.add(manifest_path)
        component = json.loads(manifest_path.read_bytes())
        paths.add(manifest_path.parent / component['image_path'])
    return sorted(paths)


def pins():
    # The candidate is a partial checkout: some tracked historical evidence
    # paths were never materialized. Preserve that fact instead of pretending
    # their bytes were read, or silently omitting them from the before/after.
    return {str(path): digest(path) if path.exists() else {'absent_in_checkout': True}
            for path in source_paths()}


def verify_preconditions():
    imported = {}
    for name, module in sorted(sys.modules.items()):
        if name == 'hepta' or name.startswith('hepta.') or name == 'tests' or name.startswith('tests.'):
            path = getattr(module, '__file__', None)
            if path:
                path = Path(path).resolve()
                assert path.is_relative_to(ROOT), (name, str(path))
                imported[name] = {'path': str(path), **digest(path)}
    stage = json.loads(STAGE.read_bytes())
    assert len(stage['files']) == 14
    for name, expected in stage['files'].items():
        actual = digest(ROOT / name)
        assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes'], name
    assert digest(ROOT / 'hepta/hia_composite_constructor_native.py')['sha256'] == EXPECTED_ADAPTER
    assert digest(CORPUS)['sha256'] == EXPECTED_CORPUS_SHA
    assert digest(native_types.SOURCE)['sha256'] == EXPECTED_TYPE_SOURCE
    manifest = json.loads(TYPE_MANIFEST.read_bytes())
    assert manifest['source_sha256'] == EXPECTED_TYPE_SOURCE
    assert manifest['image_sha256'] == EXPECTED_TYPE_IMAGE
    assert digest(TYPE_MANIFEST.parent / manifest['image_path'])['sha256'] == EXPECTED_TYPE_IMAGE
    bundle = json.loads(BUNDLE_MANIFEST.read_bytes())
    assert bundle['types_source_sha256'] == EXPECTED_TYPE_SOURCE
    image_pins = {}
    for name, relative in bundle['kernels'].items():
        component_path = BUNDLE_MANIFEST.parent / relative
        component = json.loads(component_path.read_bytes())
        source = native_constructor.SOURCES[name]
        image = component_path.parent / component['image_path']
        assert digest(source)['sha256'] == component['source_sha256']
        assert digest(image)['sha256'] == component['image_sha256']
        image_pins[name] = {'manifest': str(component_path), 'source': str(source),
                            'image': str(image), **component}
    cases = json.loads(CORPUS.read_bytes())
    assert len(cases) == 134
    for key, value in cases.items():
        assert type(value['legacy']) is bool
        captured = json.dumps({'document': value['document'], 'legacy': value['legacy']},
                              sort_keys=True, separators=(',', ':')).encode()
        assert hashlib.sha256(captured).hexdigest() == key
    return {'scope': 'DEVELOPMENT_ONLY_PUBLIC_CORPUS_CONSTRUCTOR_DIFFERENTIAL',
            'candidate': str(ROOT), 'corpus': {'path': str(CORPUS), **digest(CORPUS)},
            'cases': len(cases), 'stage_checkpoint': {'path': str(STAGE), **digest(STAGE)},
            'imported_modules': imported, 'image_pins': image_pins,
            'type_manifest': {'path': str(TYPE_MANIFEST), **manifest},
            'observer': {'path': str(ROOT_OBSERVER), **digest(ROOT_OBSERVER),
                         'method': 'AST-extracted owner_state function only; no script import'},
            'source_tree_scope': 'all present tracked and nonignored untracked files; absent tracked history recorded explicitly',
            'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
            'removed_ambient_selectors': sorted(REMOVED_SELECTORS),
            'function_lowering_run': False, 'main_lifetime_fix_overlaid': False,
            'cold_qualified': False, 'whole_stack_hia': False, 'python': sys.version}


class Observer:
    def __init__(self, path):
        self.stream = gzip.GzipFile(filename=str(path), mode='wb', mtime=0)
        self.counts = Counter()
        self.case = self.variant = self.phase = None
        self.sequence = 0
        self.type_entries = []

    def wrap(self, image, label):
        entry = image._entry
        def invoke(source, length, output, capacity, workspace, workspace_size):
            borrowed = label == 'owner' and length == native_types.SESSION_BYTES
            before = None if borrowed else ctypes.string_at(source, length)
            started = time.perf_counter_ns()
            result = entry(source, length, output, capacity, workspace, workspace_size)
            elapsed = time.perf_counter_ns() - started
            after = None if borrowed else ctypes.string_at(source, length)
            assert borrowed or before == after, 'native image modified ordinary input'
            response = ctypes.string_at(output, result) if 0 <= result <= capacity else None
            row = {'case': self.case, 'variant': self.variant, 'phase': self.phase,
                   'sequence': self.sequence, 'kernel': label,
                   'image_sha256': image.image_sha256, 'input_bytes': length,
                   'output_capacity': capacity, 'workspace_bytes': workspace_size,
                   'result': result, 'entry_wall_ns': elapsed,
                   'response_hex': None if response is None else response.hex()}
            if borrowed:
                row.update(input_kind='borrowed-type-state', full_state_snapshot=False)
            else:
                row.update(input_kind='complete-ordinary-input', input_hex=before.hex(),
                           input_sha256=hashlib.sha256(before).hexdigest(), input_unchanged=True)
            self.stream.write(wire(row) + b'\n')
            self.sequence += 1
            self.counts[(self.variant, self.phase, label)] += 1
            if label == 'types':
                self.type_entries.append({key: value for key, value in row.items()
                    if key not in ('case', 'variant', 'sequence', 'entry_wall_ns')})
            return result
        return invoke

    def close(self):
        self.stream.close()


def evaluate(case, variant, bundle, observer):
    submitted = deepcopy(case['document'])
    original = wire(submitted)
    result = {}
    observer.variant, observer.phase = variant, 'source_gate'
    observer.type_entries = []
    try:
        document, raw = _decode(submitted)
    except HIAProgramRejected as error:
        assert wire(submitted) == original
        return {'source_gate': {'status': 'rejected', 'error': rejected(error)},
                'source_unchanged': True, 'constructor_reached': False}
    assert wire(document) == raw
    result['source_gate'] = {'status': 'accepted', 'canonical_sha256': hashlib.sha256(raw).hexdigest(),
                             'bytes': len(raw), 'detached_from_caller': document is not submitted}
    result['constructor_reached'] = True
    owner = composite._Elaborator.__new__(composite._Elaborator)
    sessions, commands = [], []
    original_init = native_types.NativeCompositeTypeSession.__init__
    original_command = native_types.NativeCompositeTypeSession._command

    def capture_init(session, *args, **kwargs):
        sessions.append(session)
        assert args[0].image_sha256 == EXPECTED_TYPE_IMAGE
        return original_init(session, *args, **kwargs)

    def capture_command(session, command, **kwargs):
        item = {'phase': observer.phase, 'command': deepcopy(command), 'flags': deepcopy(kwargs),
                'before': session_state(session)}
        commands.append(item)
        try:
            value = original_command(session, command, **kwargs)
            if isinstance(value, composite._Type):
                item['result'] = {'issued_type_id': session._ids[id(value)]}
            elif value is None:
                item['result'] = None
            elif kwargs.get('parameters'):
                item['result'] = [[name, session._ids[id(typ)]] for name, typ in value]
            else:
                item['result'] = deepcopy(value)
            return value
        except HIAProgramRejected as error:
            item['error'] = rejected(error)
            raise
        finally:
            item['after'] = session_state(session)

    try:
        with ExitStack() as context:
            context.enter_context(patch.dict(os.environ, {native_types.SELECTOR: str(TYPE_MANIFEST),
                                                         native_constructor.SELECTOR: ''}))
            context.enter_context(patch.object(native_functions, 'selected_composite_functions', new=lambda: None))
            context.enter_context(patch.object(native_types.NativeCompositeTypeSession, '__init__', new=capture_init))
            context.enter_context(patch.object(native_types.NativeCompositeTypeSession, '_command', new=capture_command))
            context.enter_context(patch.object(composite, '_Types', new=forbidden))
            for name in ('_reference_parameters', '_reference_check_task', 'loan_origins'):
                context.enter_context(patch.object(composite._Elaborator, name, new=forbidden))
            context.enter_context(patch.object(native_constructor, 'selected_composite_constructor',
                                              new=lambda: bundle if variant == 'native-constructor' else None))
            if variant == 'native-constructor':
                for name in ('_reference_initialize', 'parameters', 'check_task'):
                    context.enter_context(patch.object(composite._Elaborator, name, new=forbidden))
            observer.phase = 'constructor'
            try:
                if variant == 'retained-same-native-types':
                    RETAINED(owner, document, legacy=case['legacy'])
                else:
                    composite._Elaborator.__init__(owner, document, legacy=case['legacy'])
            except HIAProgramRejected as error:
                result['constructor'] = {'status': 'rejected', 'error': rejected(error)}
            else:
                result['constructor'] = {'status': 'accepted'}
            result['constructor']['state'] = complete_owner_state(owner, document)
            result['constructed_type_sessions'] = [session_state(session) for session in sessions]
            # An independent follow-up on the same committed live type session
            # is observed separately; it cannot change the recorded ctor state.
            session = getattr(owner, 'native_types', None)
            if session is not None and not session._closed and not session._broken:
                observer.phase = 'post_constructor_continuation'
                continuation = {'before': session_state(session), 'command': {'op': 'resolve', 'ref': 'u32'}}
                try:
                    typ = session.resolve('u32')
                    continuation['result'] = {'issued_type_id': session._ids[id(typ)]}
                except HIAProgramRejected as error:
                    continuation['error'] = rejected(error)
                continuation['after'] = session_state(session)
                result['continuation'] = continuation
            else:
                result['continuation'] = {'issued': False, 'reason': 'no committed live native type session'}
        result['type_commands'] = commands
        result['type_entry_bytes'] = deepcopy(observer.type_entries)
        assert len(commands) == len(observer.type_entries), 'unobserved actual native type command'
        result['source_unchanged'] = wire(submitted) == original
        result['detached_document_unchanged'] = wire(document) == raw
        assert result['source_unchanged'] and result['detached_document_unchanged']
        return detached(result)
    finally:
        # Cleanup is solely audit ownership after complete state capture. It is
        # not a claim that the candidate public failure lifetime bug is fixed.
        for session in sessions:
            if hasattr(session, '_lock'):
                session.close()
        if getattr(owner, '_native_function_session', None) is not None:
            owner._native_function_session.close()
        owner.__dict__.clear()
        sessions.clear()
        gc.collect()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    plan = verify_preconditions()
    if args.prepare:
        write_json(EVIDENCE / 'plan.json', plan)
        write_json(EVIDENCE / 'preparation-source-pins.json', pins())
        print(json.dumps({'prepared': True, 'cases': 134, 'native_executed': False,
                          'driver': digest(__file__), 'candidate': str(ROOT)}), flush=True)
        return 0
    if args.output is None:
        parser.error('--output is required for replay')
    assert json.loads((EVIDENCE / 'plan.json').read_bytes()) == plan
    before = pins()
    assert before == json.loads((EVIDENCE / 'preparation-source-pins.json').read_bytes())
    args.output.mkdir(exist_ok=False)
    write_json(args.output / 'source-before.json', before)
    cases_raw = CORPUS.read_bytes()
    (args.output / 'public-cases.json').write_bytes(cases_raw)
    cases = json.loads(cases_raw)
    types_image = native_types.installed_composite_types(TYPE_MANIFEST)
    bundle = native_constructor.installed_composite_constructor(BUNDLE_MANIFEST)
    assert types_image.image_sha256 == EXPECTED_TYPE_IMAGE
    for name, image in bundle.images.items():
        assert image.image_sha256 == plan['image_pins'][name]['image_sha256']
    observer = Observer(args.output / 'native-entries.jsonl.gz')
    counts, differences, audit_exceptions = Counter(), [], []
    started = time.monotonic()
    with ExitStack() as context, gzip.GzipFile(filename=str(args.output / 'outcomes.jsonl.gz'),
                                              mode='wb', mtime=0) as output:
        context.enter_context(patch.object(types_image, '_entry', new=observer.wrap(types_image, 'types')))
        for name, image in bundle.images.items():
            context.enter_context(patch.object(image, '_entry', new=observer.wrap(image, name)))
        try:
            for index, (identity, case) in enumerate(cases.items(), 1):
                observer.case = identity
                row = {'identity': identity, 'source': case, 'outcomes': {}}
                for variant in ('retained-same-native-types', 'native-constructor'):
                    try:
                        row['outcomes'][variant] = evaluate(case, variant, bundle, observer)
                    except Exception as error:
                        failure = {'case': identity, 'variant': variant, 'error': rejected(error),
                                   'traceback': traceback.format_exc()}
                        audit_exceptions.append(failure)
                        row['outcomes'][variant] = {'audit_exception': failure}
                left, right = row['outcomes']['retained-same-native-types'], row['outcomes']['native-constructor']
                delta = first_difference(left, right)
                if delta:
                    differences.append({'case': identity, 'first_difference': delta})
                    write_json(args.output / (identity + '.counterexample.json'), row)
                else:
                    counts['exact_equal'] += 1
                counts['cases'] += 1
                counts['source_gate_accepted'] += right.get('source_gate', {}).get('status') == 'accepted'
                counts['source_gate_excluded'] += right.get('source_gate', {}).get('status') == 'rejected'
                counts['constructor_accepted'] += right.get('constructor', {}).get('status') == 'accepted'
                counts['constructor_rejected'] += right.get('constructor', {}).get('status') == 'rejected'
                counts['native_type_constructor_commands'] += sum(
                    item.get('phase') == 'constructor' for item in right.get('type_commands', []))
                counts['native_type_continuation_commands'] += sum(
                    item.get('phase') == 'post_constructor_continuation' for item in right.get('type_commands', []))
                output.write(wire(row) + b'\n')
                if index % 20 == 0 or index == len(cases):
                    output.flush(); observer.stream.flush()
                    print(json.dumps({'completed': index, 'total': len(cases), 'differences': len(differences),
                                      'audit_exceptions': len(audit_exceptions),
                                      'elapsed_seconds': time.monotonic() - started,
                                      'max_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}), flush=True)
        finally:
            observer.close()
    after = pins()
    write_json(args.output / 'source-after.json', after)
    summary = {**plan, 'counts': dict(counts), 'differences': differences,
               'audit_exceptions': audit_exceptions, 'source_preserved': before == after,
               'native_entries': [{'variant': variant, 'phase': phase, 'kernel': kernel, 'count': count}
                                  for (variant, phase, kernel), count in sorted(observer.counts.items())],
               'elapsed_seconds': time.monotonic() - started,
               'max_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               'ordinary_native_input_scope': 'complete before/after bytes and raw response for every ordinary entry',
               'borrowed_type_state_scope': 'actual borrowed arena lease; no 128 MiB raw snapshot',
               'type_observation_scope': 'exact command order/flags/results, raw ABI responses, descriptor IDs and counters',
               'first_error_scope': 'class, code and complete text relative to the SAME selected native Types baseline',
               'lifetime_scope': 'audit closes its explicitly retained sessions after state capture; no public lifetime claim',
               'performance_claim': False}
    summary['passed'] = (counts['cases'] == 134 and counts['exact_equal'] == 134 and before == after
                         and not differences and not audit_exceptions)
    write_json(args.output / 'summary.json', summary)
    print(json.dumps({'passed': summary['passed'], 'counts': dict(counts), 'differences': len(differences),
                      'audit_exceptions': len(audit_exceptions), 'source_preserved': before == after,
                      'summary': str(args.output / 'summary.json')}), flush=True)
    return 0 if summary['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
