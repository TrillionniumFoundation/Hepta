"""Independent fresh differential; development images, never cold qualification.

Every case gets fresh resolver/function state. Plain entry wrappers retain only
serialized bytes, never ctypes arrays or mock argument histories. The two native
dependency variants isolate the new function owner; the fully retained variant
also records earlier type-diagnostic differences without excusing new ones.
"""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import argparse
import collections
import ctypes
import gc
import gzip
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-function-recovered')
BASE = Path('/workspace/scratch/9acdfa9f5639/hia-function-independent-recovery')
INPUTS = Path('/workspace/scratch/9acdfa9f5639/hia-function-recovery/frozen-inputs/native-inputs')
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
for key in tuple(os.environ):
    if key.startswith('HEPTA_HIA_') and (key.endswith('_MANIFEST') or key.endswith('_COLD_REPORT')):
        os.environ.pop(key)

from hepta import hia_program_composite as composite
from hepta import hia_composite_types_native as native_types
from hepta import hia_composite_functions_native as native_functions
from hepta import hia_task_helpers_native as native_helpers
from hepta.hia_program import HIAProgramRejected, _decode, verify_program
from tests.test_hia_composite_types_native import native_key, snapshot

TYPE_MANIFEST = INPUTS / 'native-signature-development/manifest-r2.json'
HELPER_MANIFEST = INPUTS / 'native-helper-development/manifest.json'
FUNCTION_MANIFEST = INPUTS / 'hia-function-native-development/bundle-current.json'
ORACLE = composite._Elaborator._reference_function
NATIVE_DEPENDENCY_HOST_OWNERS = ('_reference_parameters', '_reference_check_task',
                                '_reference_helper', 'loan_origins')
NATIVE_FUNCTION_HOST_OWNERS = ('function', '_reference_function', 'fresh', 'reserve_values',
                             'flat_parameters', 'constant', 'zeros', 'drop_padding', 'helper')
ATTRIBUTES = ('document', 'serial', 'value_slots', 'nominal_operations', 'native_types',
              'types', 'parameter_loan_returns', 'functions', 'signatures',
              'return_origins', 'helpers', 'helper_names')


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode()


def detached(value):
    return json.loads(wire(value))


def rejected(error):
    return dict(class_name=type(error).__name__, code=getattr(error, 'code', None), text=str(error))


def forbidden(*args, **kwargs):
    raise AssertionError('retained semantic owner called on a native path')


def owner_state(owner):
    value = {'attributes': [key for key in ATTRIBUTES if hasattr(owner, key)]}
    for name in ('serial', 'value_slots', 'parameter_loan_returns', 'helpers', 'return_origins'):
        if hasattr(owner, name):
            value[name] = deepcopy(getattr(owner, name))
    if hasattr(owner, 'nominal_operations'):
        value['nominal_operations'] = sorted(owner.nominal_operations)
    if hasattr(owner, 'functions'):
        value['function_order'] = list(owner.functions)
        value['function_member_aliases'] = [
            any(item is fn for item in owner.document['functions']) for fn in owner.functions.values()]
    if hasattr(owner, 'types'):
        session = owner.native_types
        memo = {}
        def key(typ):
            return typ.key if session is None else native_key(session, session._ids[id(typ)], memo)
        if session is None:
            roots = [typ for typ in owner.types.cache.values() if typ.kind != 'primitive']
            observation = dict(cache_count=len(owner.types.cache), active_count=len(owner.types.active),
                               partial_declaration_steps=owner.types.partial_declaration_steps)
        else:
            roots = [typ for typ in session._types.values() if typ.kind != 'primitive']
            observation = session.observations
        graph = {}
        for typ in roots:
            _, nodes = snapshot(typ, session)
            for name, node in nodes.items():
                if name in graph:
                    assert graph[name] == node
                graph[name] = node
        value['type_cache_roots'] = sorted(key(typ) for typ in roots)
        value['type_graph'] = graph
        value['type_observations'] = observation
        if hasattr(owner, 'signatures'):
            value['signatures'] = [[name, [[pname, key(typ)] for pname, typ in params],
                                    [key(typ) for typ in returns]]
                                   for name, (params, returns) in owner.signatures.items()]
        if hasattr(owner, 'helper_names'):
            lookup = {} if session is None else {typ.key: key(typ) for typ in session._types.values()}
            value['helper_cache'] = [[name if session is None else lookup[name], op, output]
                                    for (name, op), output in owner.helper_names.items()]
    return detached(value)


def pins():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    paths = {ROOT / os.fsdecode(name) for name in names if name}
    manifest = BASE.parent / 'hia-function-recovery/source-ready-r3.json'
    paths.update(ROOT / name for name in json.loads(manifest.read_bytes())['files'])
    paths.update(path for path in INPUTS.rglob('*') if path.is_file())
    paths.update((Path(__file__), manifest))
    return {str(p): dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            for p in sorted(paths)}


class Observer:
    def __init__(self, target):
        self.stream = gzip.GzipFile(filename=str(target), mode='wb', mtime=0)
        self.counts = collections.Counter()
        self.source = None
        self.variant = None
        self.sequence = 0

    def wrap(self, image, label):
        entry = image._entry
        def invoke(source, length, output, capacity, workspace, workspace_size):
            borrowed = length == native_types.SESSION_BYTES
            before = None if borrowed else ctypes.string_at(source, length)
            started = time.perf_counter_ns()
            result = entry(source, length, output, capacity, workspace, workspace_size)
            elapsed = time.perf_counter_ns() - started
            after = None if borrowed else ctypes.string_at(source, length)
            if not borrowed and before != after:
                raise AssertionError('native image modified ordinary immutable input')
            row = dict(case=self.source, variant=self.variant, sequence=self.sequence, kernel=label,
                       input_bytes=length, output_capacity=capacity, result=result,
                       entry_wall_ns=elapsed, workspace_bytes=workspace_size)
            if borrowed:
                row.update(input_kind='borrowed-type-arena-lease-only',
                           arena_address=ctypes.addressof(source), full_arena_snapshot=False)
            else:
                row.update(input_kind='complete-ordinary-input', input_hex=before.hex(),
                           input_sha256=hashlib.sha256(before).hexdigest(), input_preserved=True)
            row['response_hex'] = ctypes.string_at(output, result).hex() if 0 <= result <= capacity else None
            self.stream.write(wire(row) + b'\n')
            self.sequence += 1
            self.counts[(self.variant, label)] += 1
            return result
        return invoke

    def close(self):
        self.stream.close()


def evaluate(case, variant, types_image, helpers_image, bundle, observer):
    document = deepcopy(case['document'])
    original = wire(document)
    # The same public structural gate applies before the private elaborator.
    decoded, raw = _decode(document)
    assert raw == wire(decoded)
    legacy = case.get('legacy', False)
    owner = object.__new__(composite._Elaborator)
    session = None
    result = {'functions': [], 'public_input_sha256': hashlib.sha256(raw).hexdigest()}
    observer.variant = variant
    with ExitStack() as context:
        context.enter_context(patch.object(native_functions, 'selected_composite_functions', new=lambda: None))
        if variant == 'retained':
            context.enter_context(patch.object(native_types, 'selected_composite_types', new=lambda *a, **kw: None))
            context.enter_context(patch.object(native_helpers, 'selected_task_helpers', new=lambda: None))
        else:
            context.enter_context(patch.object(native_types, 'selected_composite_types',
                new=lambda definitions, **flags: types_image.session(definitions, **flags)))
            context.enter_context(patch.object(native_helpers, 'selected_task_helpers', new=lambda: helpers_image))
            context.enter_context(patch.object(native_functions, 'selected_task_helpers', new=lambda: helpers_image))
            context.enter_context(patch.object(composite, '_Types', new=forbidden))
            for name in NATIVE_DEPENDENCY_HOST_OWNERS:
                context.enter_context(patch.object(composite._Elaborator, name, new=forbidden))
        try:
            try:
                composite._Elaborator.__init__(owner, decoded, legacy=legacy)
            except HIAProgramRejected as error:
                result['constructor'] = dict(status='rejected', error=rejected(error), state=owner_state(owner))
                return result
            result['constructor'] = dict(status='accepted', state=owner_state(owner))
            if variant == 'native-function':
                session = bundle.session(owner, legacy=legacy)
            def function(fn):
                call = dict(name=fn['name'], before=owner_state(owner))
                result['functions'].append(call)
                try:
                    value = session.function(fn) if session is not None else ORACLE(owner, fn)
                    call['result'] = deepcopy(value)
                    return value
                except HIAProgramRejected as error:
                    call['error'] = rejected(error)
                    raise
                finally:
                    call['after'] = owner_state(owner)
            owner.function = function
            if variant == 'native-function':
                for name in NATIVE_FUNCTION_HOST_OWNERS:
                    context.enter_context(patch.object(composite._Elaborator, name, new=forbidden))
            try:
                value = owner.lower()
                result['lower'] = dict(status='accepted', core=value, state=owner_state(owner))
                try:
                    checked = verify_program(value)
                    result['core_admission'] = dict(status='accepted', canonical_hex=checked.canonical_bytes.hex(),
                                                   sha256=checked.sha256)
                except HIAProgramRejected as error:
                    result['core_admission'] = dict(status='rejected', error=rejected(error))
            except HIAProgramRejected as error:
                result['lower'] = dict(status='rejected', error=rejected(error), state=owner_state(owner))
            return result
        finally:
            assert wire(document) == original
            assert wire(decoded) == raw
            if session is not None:
                session.close()
            if getattr(owner, 'native_types', None) is not None:
                owner.native_types.close()
            owner.function = None


def first_difference(a, b, path=''):
    if type(a) is not type(b):
        return dict(path=path, expected=a, actual=b)
    if isinstance(a, dict):
        if set(a) != set(b):
            return dict(path=path, expected_keys=sorted(a), actual_keys=sorted(b))
        for key in a:
            if a[key] != b[key]:
                return first_difference(a[key], b[key], path + '/' + key)
    elif isinstance(a, list):
        if len(a) != len(b):
            return dict(path=path, expected_length=len(a), actual_length=len(b))
        for index, (left, right) in enumerate(zip(a, b)):
            if left != right:
                return first_difference(left, right, path + '/' + str(index))
    elif a != b:
        return dict(path=path, expected=a, actual=b)
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cases', type=Path, default=BASE / 'public-cases.json')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--same-dependencies-only', action='store_true')
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    cases = json.loads(args.cases.read_bytes())
    if args.limit:
        cases = dict(list(cases.items())[:args.limit])
    before = pins()
    (args.output / 'source-before.json').write_bytes(wire(before))
    types_image = native_types.installed_composite_types(TYPE_MANIFEST)
    helpers_image = native_helpers.installed_task_helpers(HELPER_MANIFEST)
    bundle = native_functions.installed_composite_functions(FUNCTION_MANIFEST)
    observer = Observer(args.output / 'native-entries.jsonl.gz')
    variants = ['same-native-dependencies', 'native-function']
    if not args.same_dependencies_only:
        variants.insert(0, 'retained')
    differences, old_type_differences, counts = [], [], collections.Counter()
    started = time.monotonic()
    with ExitStack() as wrappers, gzip.GzipFile(filename=str(args.output / 'outcomes.jsonl.gz'), mode='wb', mtime=0) as output:
        for image, label in [(types_image, 'types'), (helpers_image, 'helpers'), *[(image, kernel) for kernel, image in bundle.images.items()]]:
            wrappers.enter_context(patch.object(image, '_entry', new=observer.wrap(image, label)))
        try:
            for index, (identity, case) in enumerate(cases.items(), 1):
                observer.source = identity
                row = dict(identity=identity, source=case, outcomes={})
                for variant in variants:
                    try:
                        row['outcomes'][variant] = detached(evaluate(case, variant, types_image, helpers_image, bundle, observer))
                    except Exception as error:
                        import traceback
                        row['outcomes'][variant] = dict(audit_exception=rejected(error), traceback=traceback.format_exc())
                        counts['audit_exceptions'] += 1
                left, right = row['outcomes']['same-native-dependencies'], row['outcomes']['native-function']
                delta = first_difference(left, right)
                if delta:
                    differences.append(dict(identity=identity, difference=delta))
                    (args.output / (identity + '.counterexample.json')).write_bytes(wire(row))
                else:
                    counts['same_dependency_exact'] += 1
                if 'retained' in row['outcomes']:
                    delta = first_difference(row['outcomes']['retained'], right)
                    if delta:
                        old_type_differences.append(dict(identity=identity, difference=delta))
                    else:
                        counts['fully_retained_exact'] += 1
                counts['cases'] += 1
                counts['legacy_cases'] += bool(case.get('legacy'))
                counts['native_function_calls'] += len(right.get('functions', []))
                counts['native_constructor_rejections'] += right.get('constructor', {}).get('status') == 'rejected'
                counts['native_core_accepts'] += right.get('core_admission', {}).get('status') == 'accepted'
                output.write(wire(row) + b'\n')
                if index % 25 == 0:
                    output.flush(); observer.stream.flush(); gc.collect()
                    print(json.dumps(dict(completed=index, total=len(cases), differences=len(differences),
                                          exceptions=counts['audit_exceptions'], elapsed=time.monotonic()-started,
                                          max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)), flush=True)
        finally:
            observer.close()
    after = pins()
    (args.output / 'source-after.json').write_bytes(wire(after))
    summary = dict(scope='FRESH_INDEPENDENT_PUBLIC_INPUT_DIFFERENTIAL_AFTER_RESET',
        source_checkpoint='36290008a699c021ff583b88f9807086e18029b9',
        case_file=dict(path=str(args.cases), sha256=hashlib.sha256(args.cases.read_bytes()).hexdigest()),
        counts=dict(counts), same_dependency_differences=differences,
        fully_retained_differences=old_type_differences, source_preserved=before == after,
        native_entries=[dict(variant=variant, kernel=kernel, count=count)
                        for (variant, kernel), count in sorted(observer.counts.items())],
        elapsed_seconds=time.monotonic()-started, max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        ordinary_input_full_bytes_preserved=True, borrowed_type_state_scope='lease identity only; not full memory snapshots',
        reference_function_isolated_from_candidate=True, cold_qualified=False, whole_stack_hia=False,
        lost_historical_raw_evidence_claimed_restored=False, python=sys.version)
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0 if before == after and counts['cases'] > 0 and not differences and not counts['audit_exceptions'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
