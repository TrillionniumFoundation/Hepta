"""Read back the completed constructor audit and seal its finite raw evidence."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tarfile

BASE = Path(__file__).resolve().parent
RUN = BASE / 'replay-r1'
ROOT = BASE.parent / 'native-constructor-next'
AUTHOR = BASE.parent / 'hia-constructor-native-development'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def info(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert not (BASE / 'raw-public134-audit.tar.xz').exists()
summary = json.loads((RUN / 'summary.json').read_bytes())
assert summary['passed'] and summary['counts']['cases'] == summary['counts']['exact_equal'] == 134
assert summary['source_preserved'] and not summary['differences'] and not summary['audit_exceptions']
assert (RUN / 'source-before.json').read_bytes() == (RUN / 'source-after.json').read_bytes()
assert (RUN / 'source-before.json').read_bytes() == (BASE / 'preparation-source-pins.json').read_bytes()
assert not (BASE / 'replay-r1.stderr.log').read_bytes()
corpus = json.loads((RUN / 'public-cases.json').read_bytes())
assert len(corpus) == 134
before = json.loads((RUN / 'source-before.json').read_bytes())
ledger_entries, by_case = 0, defaultdict(list)
entry_counts, input_counts = Counter(), Counter()
with gzip.open(RUN / 'native-entries.jsonl.gz', 'rb') as stream:
    for expected_sequence, line in enumerate(stream):
        entry = json.loads(line)
        assert entry['sequence'] == expected_sequence
        assert entry['case'] in corpus
        assert type(entry['result']) is int and 0 <= entry['result'] <= entry['output_capacity']
        assert len(bytes.fromhex(entry['response_hex'])) == entry['result']
        if entry['input_kind'] == 'complete-ordinary-input':
            raw = bytes.fromhex(entry['input_hex'])
            assert len(raw) == entry['input_bytes'] and sha(raw) == entry['input_sha256']
            assert entry['input_unchanged'] is True
        else:
            assert entry['input_kind'] == 'borrowed-type-state'
            assert entry['kernel'] == 'owner' and entry['input_bytes'] == 128 << 20
            assert entry['full_state_snapshot'] is False
        entry_counts[(entry['variant'], entry['phase'], entry['kernel'])] += 1
        input_counts[entry['input_kind']] += 1
        if entry['kernel'] == 'types':
            by_case[(entry['case'], entry['variant'])].append({key: value for key, value in entry.items()
                if key not in ('case', 'variant', 'sequence', 'entry_wall_ns')})
        ledger_entries += 1
assert ledger_entries == 3535
assert [{'variant': v, 'phase': p, 'kernel': k, 'count': c}
        for (v, p, k), c in sorted(entry_counts.items())] == summary['native_entries']

identities, statuses, codes, schema_counts, attr_counts = set(), Counter(), Counter(), Counter(), Counter()
with gzip.open(RUN / 'outcomes.jsonl.gz', 'rb') as stream:
    for line in stream:
        row = json.loads(line)
        key = row['identity']
        assert key not in identities and row['source'] == corpus[key]
        identities.add(key)
        left, right = row['outcomes']['retained-same-native-types'], row['outcomes']['native-constructor']
        assert left == right
        assert right['source_gate']['status'] == 'accepted'
        assert right['source_unchanged'] and right['detached_document_unchanged']
        state = right['constructor']['state']
        statuses[right['constructor']['status']] += 1
        if 'error' in right['constructor']:
            codes[(right['constructor']['error']['class_name'], right['constructor']['error']['code'])] += 1
        schema_counts[row['source']['document']['schema']] += 1
        attr_counts[tuple(state['all_attributes'])] += 1
        for variant, outcome in row['outcomes'].items():
            actual = by_case.pop((key, variant), [])
            assert actual == outcome['type_entry_bytes']
            assert len(actual) == len(outcome['type_commands'])
            for command, entry in zip(outcome['type_commands'], actual):
                assert command['phase'] == entry['phase']
                assert json.loads(bytes.fromhex(entry['input_hex'])) == command['command']
assert identities == set(corpus) and not by_case
assert statuses == {'accepted': 82, 'rejected': 52}

# Preserve the exact relevant frozen checkpoint and actual compiled images.
# This package is still an audit record, not a self-contained wheel/runtime.
copied = {}
def preserve(source, relative):
    source = Path(source)
    expected = before.get(str(source))
    actual = info(source)
    if expected is not None:
        assert actual == expected
    target = BASE / 'pinned-inputs' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    shutil.copy2(source, target)
    assert target.read_bytes() == source.read_bytes()
    copied[str(target.relative_to(BASE))] = {'source_path': str(source), **actual}

stage = json.loads((AUTHOR / 'stage5-source.json').read_bytes())
for name, metadata in stage['files'].items():
    assert info(ROOT / name)['sha256'] == metadata['sha256']
    preserve(ROOT / name, 'candidate/' + name)
for name in ('hepta/hia_composite_types_native.py', 'hepta/hia_composite_function_tokens.py',
             'hepta/hia_json_preflight_native.py', 'hepta/hia_instruction_policy_native.py',
             'hepta/hia_program.py', 'hepta/hia_schema.py', 'tests/test_hia_composite_types_native.py',
             'examples/hia_bootstrap/composite_types.hiaasm'):
    preserve(ROOT / name, 'candidate/' + name)
for name in ('stage5-source.json', 'compile-r1.json', 'bundle-r1.json',
             'owner-r1/manifest.json', 'owner-r1/owner.image.bin',
             'render-r1/manifest.json', 'render-r1/render.image.bin'):
    preserve(AUTHOR / name, 'constructor-development/' + name)
type_manifest = Path(summary['type_manifest']['path'])
preserve(type_manifest, 'types-development/manifest-r2.json')
preserve(type_manifest.parent / summary['type_manifest']['image_path'],
         'types-development/' + summary['type_manifest']['image_path'])
preserve(Path(summary['observer']['path']), 'root-observer/replay_functions_fresh.py')

write(BASE / 'run-control.json', {
    'scope': 'LOCAL_DEVELOPMENT_DIFFERENTIAL_NOT_QUALIFICATION',
    'command': ['python', 'constructor-public134-independent/replay_public134.py', '--output', str(RUN)],
    'cwd': str(BASE.parent), 'environment_override': {'PYTHONDONTWRITEBYTECODE': '1'},
    'exec_session_id': 38511, 'terminal_tool_chunk_id': '893d24', 'exit_code': 0,
    'stdout': 'replay-r1.stdout.log', 'stderr': 'replay-r1.stderr.log',
    'actual_image_execution_runs': 1,
    'preparation_failure': 'First prepare attempted to read absent historical checkout files; no native image loaded/executed. Original driver and stderr preserved.',
})
readback = {
    'scope': 'INDEPENDENT_CONSTRUCTOR_PUBLIC134_FINITE_DIFFERENTIAL',
    'passed': True, 'unique_cases': len(identities), 'source_gate_admitted': 134,
    'source_gate_excluded': 0, 'constructor_statuses': dict(statuses),
    'error_categories': [{'class': cls, 'code': code, 'count': count} for (cls, code), count in sorted(codes.items())],
    'profiles': dict(schema_counts), 'legacy_true_cases': 0,
    'attribute_presence_groups': [{'attributes': list(attrs), 'count': count} for attrs, count in attr_counts.items()],
    'native_entry_rows': ledger_entries, 'native_entry_counts': summary['native_entries'],
    'input_kinds': dict(input_counts),
    'all_raw_type_requests_and_responses_match_outcome_ledger': True,
    'full_outcome_equality': True,
    'before_after_present_files': sum('sha256' in item for item in before.values()),
    'absent_tracked_history_paths_explicitly_recorded': sum(item.get('absent_in_checkout', False) for item in before.values()),
    'source_pins_byte_equal': True, 'all_14_frozen_checkpoint_files_match': True,
    'loaded_imports_resolved_to_actual_constructor_checkout': True,
    'same_native_type_dependency': summary['type_manifest'],
    'elapsed_seconds_including_source_recheck': summary['elapsed_seconds'],
    'elapsed_seconds_is_not_performance_claim': True,
    'preserved_inputs': copied,
    'limits': [
        'No function lowering/Core execution replay in this constructor-only audit.',
        'All 134 public source cases use legacy=False; author legacy coverage is separate evidence.',
        'No raw 128 MiB borrowed type arena snapshots; descriptors, counters, exact commands/responses and post-constructor query are compared.',
        'Audit closes explicitly retained sessions only after state capture; it does not claim the public exception lifetime bug is fixed.',
        'Development compiler/images, not a current-source cold qualification or whole-stack native closure.',
    ],
}
write(BASE / 'readback.json', readback)

files = sorted(path for path in BASE.rglob('*') if path.is_file())
members = {str(path.relative_to(BASE)): info(path) for path in files}
write(BASE / 'member-manifest.json', {'schema': 'hia.independent-audit-members.v1', 'members': members})
files.append(BASE / 'member-manifest.json')
archive = BASE / 'raw-public134-audit.tar.xz'
with tarfile.open(archive, 'w:xz', preset=3) as output:
    for path in sorted(files):
        output.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
verified = []
with tarfile.open(archive, 'r:xz') as packed:
    for member in packed:
        assert member.isfile()
        raw = packed.extractfile(member).read()
        original = BASE / member.name
        assert raw == original.read_bytes()
        assert member.mode == stat.S_IMODE(original.stat().st_mode)
        verified.append({'path': member.name, 'bytes': len(raw), 'sha256': sha(raw), 'mode': member.mode})
assert {item['path'] for item in verified} == {str(path.relative_to(BASE)) for path in files}
custody = {
    'scope': readback['scope'], 'passed': True,
    'archive': {'path': str(archive), **info(archive)},
    'member_manifest': {'path': str(BASE / 'member-manifest.json'), **info(BASE / 'member-manifest.json')},
    'summary': {'path': str(RUN / 'summary.json'), **info(RUN / 'summary.json')},
    'readback': {'path': str(BASE / 'readback.json'), **info(BASE / 'readback.json')},
    'member_count_including_manifest': len(verified),
    'uncompressed_member_bytes': sum(item['bytes'] for item in verified),
    'all_members_bytes_sha256_mode_replayed': True,
    'source_tree_unchanged': True,
    'native_source_overlay_from_main_lifetime_fix': False,
    'original_failed_preparation_preserved': True,
    'custody_not_inside_its_own_archive': True,
}
write(BASE / 'custody.json', custody)
print(json.dumps(custody, sort_keys=True))
