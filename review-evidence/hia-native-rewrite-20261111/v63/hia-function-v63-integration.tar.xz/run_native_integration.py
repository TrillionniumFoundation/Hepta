"""Fresh real bootstrap-development run; never a cold qualification receipt."""
from pathlib import Path
from hashlib import sha256
from contextlib import ExitStack
import ctypes
import json
import os
import resource
import sys
import tarfile
import time
import traceback
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta')
OUT = Path('/workspace/scratch/9acdfa9f5639/hia-function-v63-integration/native-bootstrap-r1')
OUT.mkdir(exist_ok=False)
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
from tests import hia_composite_function_fixture as fixtures
from tools.hia_selfhost_contract import file_digests, validate_contract, CONTRACT_PATH
from hepta.hia_json_preflight_native import NativeHiaJsonImage

selectors = (*fixtures.DEVELOPMENT_KEYS, *fixtures.COLD_KEYS,
             fixtures.SELECTOR, fixtures.TYPE_SELECTOR, fixtures.HELPER_SELECTOR)
removed = {key: os.environ.pop(key) for key in selectors if key in os.environ}
(OUT / 'environment.json').write_text(json.dumps({
    'cleared_selector_names': sorted(removed), 'python': sys.version,
    'requested_scope': 'BOOTSTRAP_DEVELOPMENT_ONLY', 'matching_source_cold_qualified': False,
}, indent=2) + '\n')


def source_pins():
    return {**file_digests(), CONTRACT_PATH: sha256((ROOT / CONTRACT_PATH).read_bytes()).hexdigest()}


def artifact_pins(folder):
    return {path.relative_to(folder).as_posix(): {
        'bytes': path.stat().st_size, 'sha256': sha256(path.read_bytes()).hexdigest()}
        for path in sorted(folder.rglob('*')) if path.is_file()}


started = time.monotonic()
before = source_pins()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
validate_contract()
try:
    fixture = fixtures.composite_function_fixture()
    assert fixture.scope == 'BOOTSTRAP_DEVELOPMENT_ONLY'
    folder = fixture.manifest.parent
    artifacts_before = artifact_pins(folder)
    (OUT / 'artifacts-before.json').write_text(json.dumps(artifacts_before, indent=2, sort_keys=True) + '\n')
    archive = OUT / 'bootstrap-artifacts.tar.xz'
    with tarfile.open(archive, 'w:xz') as package:
        for name in artifacts_before:
            package.add(folder / name, arcname=name, recursive=False)
    with tarfile.open(archive, 'r:xz') as package:
        assert len(package.getmembers()) == len(artifacts_before)
        for name, expected in artifacts_before.items():
            raw = package.extractfile(name).read()
            assert raw == (folder / name).read_bytes()
            assert len(raw) == expected['bytes'] and sha256(raw).hexdigest() == expected['sha256']
    custody = dict(path=str(archive), bytes=archive.stat().st_size,
        sha256=sha256(archive.read_bytes()).hexdigest(), members=len(artifacts_before),
        raw_bytes=sum(item['bytes'] for item in artifacts_before.values()), all_members_byte_equal=True,
        scope=fixture.scope, matching_source_cold_qualified=False)
    (OUT / 'bootstrap-custody.json').write_text(json.dumps(custody, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'bootstrap_saved': custody, 'build_seconds': time.monotonic() - started}), flush=True)

    images = {**fixture.bundle.images, 'types': fixture.types_image, 'helpers': fixture.helpers_image}
    by_sha = {image.image_sha256: name for name, image in images.items()}
    ledger = dict.fromkeys(images, 0)

    def observe(image):
        name = by_sha.get(image.image_sha256)
        if name is None:
            return
        entry = image._entry
        def counted(source, size, output, capacity, workspace, workspace_size):
            ledger[name] += 1
            return entry(source, size, output, capacity, workspace, workspace_size)
        image._entry = counted

    for image in images.values():
        observe(image)
    original_init = NativeHiaJsonImage.__init__
    def observed_init(image, raw, expected_sha):
        original_init(image, raw, expected_sha)
        observe(image)

    names = (
        'tests.test_hia_composite_function_tokens',
        'tests.test_hia_composite_function_admission',
        'tests.test_hia_composite_function_protocol_audit',
        'tests.test_hia_composite_function_terms_native',
        'tests.test_hia_composite_functions_native',
    )
    tests_started = time.monotonic()
    with patch.object(NativeHiaJsonImage, '__init__', new=observed_init):
        with (OUT / 'tests.log').open('w') as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
                unittest.defaultTestLoader.loadTestsFromNames(names))
    fixture.check_custody()
    artifacts_after = artifact_pins(folder)
    after = source_pins()
    (OUT / 'artifacts-after.json').write_text(json.dumps(artifacts_after, indent=2, sort_keys=True) + '\n')
    (OUT / 'source-after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    (OUT / 'native-entry-ledger.json').write_text(json.dumps({
        'scope': 'actual in-process image entries; installed child processes excluded',
        'images': {name: image.image_sha256 for name, image in images.items()},
        'entries': ledger, 'total': sum(ledger.values()),
    }, indent=2, sort_keys=True) + '\n')
    summary = dict(schema='hepta.hia.function-v63-bootstrap-development-tests.v1',
        fixture_scope=fixture.scope, tests_run=result.testsRun, failures=len(result.failures),
        errors=len(result.errors), skips=len(result.skipped),
        expected_failures=len(result.expectedFailures), unexpected_successes=len(result.unexpectedSuccesses),
        tests_seconds=time.monotonic() - tests_started, total_seconds=time.monotonic() - started,
        max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        source_preserved=before == after, artifacts_preserved=artifacts_before == artifacts_after,
        shared_fixture_count=len(fixtures._FIXTURES), in_process_native_entries=sum(ledger.values()),
        matching_source_cold_qualified=False, whole_stack_rewritten_in_hia=False,
        archive=custody, modules=names)
    passed = (result.wasSuccessful() and result.testsRun == 33 and not result.skipped
              and not result.expectedFailures and not result.unexpectedSuccesses
              and before == after and artifacts_before == artifacts_after)
    summary['status'] = 'BOOTSTRAP_DEVELOPMENT_TESTS_PASS' if passed else 'HOLD'
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary), flush=True)
    raise SystemExit(0 if passed else 1)
except Exception:
    (OUT / 'runner-error.txt').write_text(traceback.format_exc())
    raise
