# Reconstructed protocol tests: fresh native execution

This is a new test revision after the transient environment restart. It does
not restore or claim the hash of the lost original protocol test or its early
raw evidence. Test source SHA-256:
`55e69ab315029ab4ab030c687b59a854e4a0b6c52258f89f0b4090875131eccd`.
The candidate was checkpointed on the recovery branch at
`36290008a699c021ff583b88f9807086e18029b9`; the production main path was not
activated by this checkpoint.

All seven tests passed: zero failures, errors, skips, expected failures or
unexpected successes. The run took 8.441470681998908 seconds under Python
3.12.14. Peak test-process RSS was 415424 KiB. There were 50 actual function
kernel entries. The new test exercised the recovered admit-r3 and render-r2
images through the source-bound complete bundle, with the recovered native
type image as its real dependency.

The two codec properties are permanent refusal after the first token protocol
error and immutable caller isolation through a detached packet. Repeated source
references intentionally share that detached snapshot, not the mutable caller.

The five native properties cover four malformed-response controls followed by
a correct response, refused initialization followed by reinitialization,
response replay followed by the original resume, an in-range descriptor ID
that the type session never issued, and a renderer short-output refusal whose
poison must also reject admission. The renderer control begins with a live,
incomplete stream; an already-completed stream is not used as an alternative
reason for its initial refusal.

The raw native-entry ledger records status, continuation frames, phase, pending
request kind and fatal flag using plain wrappers. It does not retain native
ctypes buffers in a mock call history. The tests read back every borrowed type
buffer and native source snapshot and verify every caller-owned input buffer.
All recorded source, image, manifest, test and runner hashes remained unchanged
before and after execution.

These are development protocol results using retained direct x86 images. They
do not claim fresh compiler/cold qualification, whole-language self hosting,
complete-stack replacement, or authority to remove retained owners.
