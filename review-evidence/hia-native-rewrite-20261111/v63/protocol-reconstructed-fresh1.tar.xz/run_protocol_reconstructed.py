"""Fresh execution ledger for the explicitly reconstructed protocol tests."""
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import struct
import sys
import time
import unittest

ROOT=Path('/workspace/scratch/9acdfa9f5639/native-function-recovered')
RECOVERY=Path('/workspace/scratch/9acdfa9f5639/hia-function-recovery')
INPUTS=RECOVERY/'frozen-inputs/native-inputs'
DEST=RECOVERY/('protocol-' + sys.argv[1])
DEST.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT))
os.environ.update(
    HEPTA_HIA_COMPOSITE_FUNCTIONS_DEVELOPMENT_MANIFEST=str(INPUTS/'hia-function-native-development/bundle-current.json'),
    HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST=str(INPUTS/'native-signature-development/manifest-r2.json'))
test=ROOT/'tests/test_hia_composite_function_protocol_audit.py'
assert sha256(test.read_bytes()).hexdigest()=='55e69ab315029ab4ab030c687b59a854e4a0b6c52258f89f0b4090875131eccd'
paths=[test,Path(__file__)]
paths += [ROOT/name for name in (
    'hepta/hia_composite_function_tokens.py','hepta/hia_composite_functions_native.py',
    'hepta/hia_composite_types_native.py','hepta/hia_instruction_policy_native.py',
    'hepta/hia_json_preflight_native.py','hepta/hia_program_composite.py',
    'hepta/hia_composite_functions_errors.py','hepta/hia_task_helpers_native.py',
    'examples/hia_bootstrap/composite_types.hiaasm','examples/hia_bootstrap/task_helpers.hiaasm')]
bundle=Path(os.environ['HEPTA_HIA_COMPOSITE_FUNCTIONS_DEVELOPMENT_MANIFEST'])
paths.append(bundle)
for name,raw in json.loads(bundle.read_text())['kernels'].items():
    manifest=bundle.parent/raw
    paths.extend((manifest,manifest.parent/json.loads(manifest.read_text())['image_path'],
                  ROOT/('examples/hia_bootstrap/composite_function_'+name+'.hiaasm')))
types=Path(os.environ['HEPTA_HIA_COMPOSITE_TYPES_DEVELOPMENT_MANIFEST'])
paths.extend((types,types.parent/json.loads(types.read_text())['image_path']))
def pins():
    return {str(path):dict(bytes=path.stat().st_size,sha256=sha256(path.read_bytes()).hexdigest())
            for path in paths}
before=pins()
(DEST/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
from tests import test_hia_composite_function_protocol_audit as tests
ledger=[]
original_send=tests._RawFunctionHarness.send
original_borrowed=tests._RawFunctionHarness.borrowed_entry
def state(harness):
    return dict(fatal=struct.unpack_from('<Q',harness.workspace,4096+96)[0],
                phase=struct.unpack_from('<Q',harness.workspace,4096+120)[0],
                pending=struct.unpack_from('<Q',harness.workspace,4096+312)[0])
def send(harness,wire):
    result=original_send(harness,wire)
    ledger.append(dict(test=harness.case.id(),subtest=str(harness.case._subtest),
        kernel='admit',input_bytes=len(wire),input_sha256=sha256(wire).hexdigest(),
        status=result[0],frame=result[1],state=state(harness)))
    return result
def borrowed(harness,kernel,**kwargs):
    result=original_borrowed(harness,kernel,**kwargs)
    ledger.append(dict(test=harness.case.id(),subtest=str(harness.case._subtest),
        kernel=kernel,borrowed_type_state=True,output_capacity=kwargs.get('capacity',65536),
        status=result,frame=struct.unpack_from('<8Q',harness.output) if 64<=result<=65536 else None,
        state=state(harness)))
    return result
tests._RawFunctionHarness.send=send
tests._RawFunctionHarness.borrowed_entry=borrowed
started=time.monotonic()
try:
    with (DEST/'tests.log').open('w') as output:
        result=unittest.TextTestRunner(stream=output,verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromModule(tests))
finally:
    tests._RawFunctionHarness.send=original_send
    tests._RawFunctionHarness.borrowed_entry=original_borrowed
elapsed=time.monotonic()-started
after=pins()
(DEST/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(DEST/'native-entry-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
summary=dict(revision='post-restart reconstruction; not original lost test bytes',
    tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    skips=len(result.skipped),expected_failures=len(result.expectedFailures),
    unexpected_successes=len(result.unexpectedSuccesses),source_unchanged=before==after,
    elapsed_seconds=elapsed,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    native_function_entries=len(ledger),python=sys.version,
    backend='retained direct x86 development images; no cold/whole-native qualification claim')
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
if not result.wasSuccessful() or before!=after or result.testsRun!=7 or result.skipped:
    raise SystemExit(1)
