# Exact v63 GitHub failure and cold/language audit

Commit 31d81594997cfb6cce5ab62ea5aaba3bb7757af1; HIA run 42977949269; CodeQL run 42977948746. Source 292 tests passed. Native language assertions 10 passed. Native application/memory group ran 242 tests with one installed-resource mapping failure; 13 subsequent native workflow groups were skipped. The entire workflow remains FAIL/HOLD.

The exact-source cold wrapper passed 11/11 in 160.646645785 seconds under the original 180-second limit, 38 fresh worker phases, maximum two concurrent workers, and 5,049 nested checks. All 591 source payloads match pinned Git source. Independent streaming replay verified all 42,623 cold-stage raw files (2,396,513,355 bytes) and all 12,234 language raw files (732,565,752 bytes), including size/hash/mode/ZIP CRC. No native execution was repeated by the audit.

Original artifact: HIA-v63-31d81594-GitHub-20261111.zip, 63,699,718 bytes, SHA-256 42963e72756802cce1e839c7b69122911ff626e902afb319f1575a6dbf795ab1, GitHub artifact 13837280236. Its complete original ZIP is separately retained; the receipt is included, not a claim that this smaller audit archive contains every ZIP member.

The native failure is ModuleNotFoundError for hepta.hia_composite_function_admit_native: the installed-source test inferred one module per source, while the five HIA function kernels share hepta.hia_composite_functions_native. Repair must preserve the complete source inventory and byte/source binding assertions, then run new exact-source acceptance. This evidence does not mark v63, v64 or the whole stack fully qualified.
