# Public native-session lifetime regression evidence

This bundle records a bounded public-resource fix on the v63 function candidate.
It is development regression evidence, not matching-source cold qualification or
whole-stack native completion. No old production owner was removed.

## Production scope

`elaborate_program` now retains the partially constructed owner and closes its
native function and type sessions in `finally`. The two native session
initializers close their own partial allocations if construction raises. Close
is idempotent, has no native operation, and does not allocate replacement
reference dictionaries. All 17 private `_Elaborator` methods remain byte equal;
all five HIA kernel sources and the generated error table reproduce unchanged.

`production-r1.diff`, `production-r1-pins.json`, `before/`, and `source-r1/`
preserve both sides of the three-file production change. The independent source
review and public rejection replay are included without alteration.

## Real execution and exact scope

`lifecycle-r2/` records three passing tests: two accepted public programs, six
public rejection paths, private repeated-failure state equality, and two
explicit allocation-fault controls after real preceding buffers had been
allocated. It records ten weak-reference observations, 1,402 actual in-process
native entries, and exact code/text or complete Core comparisons. Exceptions
remain held during cleanup assertions. The observer retains no strong session
or buffer references. The injected `MemoryError` controls do not claim OS OOM.

`retained-r1/` records the original 33 passing function tests after the fix,
including real sdist-to-wheel installation and source/image refusal controls.
The actual test time is 138.497 seconds; 21,449 in-process native entries were
observed. Both successful native runs have no failures, errors, skips, expected
failures or unexpected successes, and preserve all source and image pins.

`source-final/` records 26 passing pure source, resource, contract and workflow
controls on the final source. `source-reproduction-fixedpoint.json` records
unchanged generated HIA bytes, two identical inventory/contract generations,
the contract check and Core-only check. The complete contract has 590 source
files. All six function/lifecycle test modules are required by native CI and the
external full runner. The original time and language limits remain unchanged.

## Preserved unsuccessful observations

`lifecycle-r1/` contains the first complete three-test run and original test
source. The sole failure was a test assertion that a primitive-only fixture
must allocate fresh names; complete old/new state already agreed. The updated
test adds a nominal parameter that requires fresh names, retaining the same
full state and retry assertions. No production change followed this failure.

The independent observer's first counter assertion failed because it observed
a separately loaded image, rather than the image selected by the public path.
Both scripts and the failure explanation are retained. The corrected observer
reran the original public `blocks=None` witness without production changes:
the exact original exception remained held, both sessions were closed, and all
four native buffer weak references were collected.

## Source and image custody

`bootstrap-artifacts-original.tar.xz` is an exact copy of the earlier retained
81-member real bootstrap archive. Its SHA-256 is
`ac721ceaf174591f77db7f85db446941edba7a1d35809c0285e9cf7e42fbe457`.
The archive includes B0/B1/B2, all seven kernel images, inputs, receipts and logs.
Every member was verified before restoring the current development fixture;
no old source snapshot is promoted to a current-source cold receipt.

`source-manifest-final.json` and `final-source/` pin 34 integration files. After
the successful native tests, only the design document received the new result
description and its derived support digest changed. Final pure controls ran on
those final bytes. Production and test files match their successful native runs.
All original private methods, image identities, source pins, weak observations,
raw logs, failed attempts and the before/after public witness are retained here.

The published final revision still requires its own exact cold/full workflow.
