"""Final pure source/resource/contract/workflow controls for public cleanup."""
from pathlib import Path
from hashlib import sha256
import json
import os
import sys
import time
import unittest

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent / 'Hepta'
OUT = BASE / 'source-final'
OUT.mkdir(exist_ok=False)
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
from tools.hia_selfhost_contract import file_digests, validate_contract, CONTRACT_PATH

def sources():
    return {**file_digests(), CONTRACT_PATH: sha256((ROOT / CONTRACT_PATH).read_bytes()).hexdigest()}

names = ['tests.test_hia_composite_functions_native.FunctionSourceTests',
         'tests.test_hia_composite_function_tokens.TokenCodecTests',
         'tests.test_hia_composite_function_protocol_audit.FunctionTokenProtocolAuditTests',
         'tests.test_hia_agent_installed_resources.AgentInstalledResourceSourceTests',
         'tests.test_hia_selfhost_contract.SelfhostContractTests',
         'tests.test_hia_integrated_workflow.CoreWorkflowContractTests']
before = sources()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
validate_contract()
started = time.monotonic()
with (OUT / 'tests.log').open('w') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames(names))
after = sources()
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
passed = (result.wasSuccessful() and result.testsRun == 26 and not result.skipped
          and not result.expectedFailures and not result.unexpectedSuccesses and before == after)
summary = {'status': 'PASS' if passed else 'HOLD', 'modules': names,
    'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
    'unexpected_successes': len(result.unexpectedSuccesses), 'source_preserved': before == after,
    'seconds': time.monotonic() - started, 'native_execution': False}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary))
raise SystemExit(0 if passed else 1)
