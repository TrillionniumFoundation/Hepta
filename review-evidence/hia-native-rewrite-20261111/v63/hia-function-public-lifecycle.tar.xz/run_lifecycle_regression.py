"""Real development-image lifecycle and retained-suite runs, with exact custody."""
from pathlib import Path
from hashlib import sha256
import argparse
import json
import os
import resource
import sys
import time
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent / 'Hepta'
INPUTS = Path('/dev/shm/hia-lifecycle-native-inputs-r1')
parser = argparse.ArgumentParser()
parser.add_argument('group', choices=('lifecycle', 'retained'))
parser.add_argument('revision')
options = parser.parse_args()
OUT = BASE / (options.group + '-' + options.revision)
OUT.mkdir(exist_ok=False)
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
from tests import hia_composite_function_fixture as fixtures
from tools.hia_selfhost_contract import file_digests, validate_contract, CONTRACT_PATH
from hepta.hia_json_preflight_native import NativeHiaJsonImage

for key in (*fixtures.DEVELOPMENT_KEYS, *fixtures.COLD_KEYS,
            fixtures.SELECTOR, fixtures.TYPE_SELECTOR, fixtures.HELPER_SELECTOR):
    os.environ.pop(key, None)
for key, name in zip(fixtures.DEVELOPMENT_KEYS,
                     ('manifest.json', 'types.manifest.json', 'helpers.manifest.json')):
    os.environ[key] = str(INPUTS / name)
os.environ['TMPDIR'] = '/dev/shm'


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def sources():
    return {**file_digests(), CONTRACT_PATH: sha256((ROOT / CONTRACT_PATH).read_bytes()).hexdigest()}


def artifacts():
    return {p.relative_to(INPUTS).as_posix(): {'bytes': p.stat().st_size,
             'sha256': sha256(p.read_bytes()).hexdigest()}
            for p in sorted(INPUTS.rglob('*')) if p.is_file()}


started = time.monotonic()
before, inputs_before = sources(), artifacts()
write('source-before.json', before)
write('artifacts-before.json', inputs_before)
validate_contract()
fixture = fixtures.composite_function_fixture()
assert fixture.scope == 'DEVELOPMENT_ONLY'
images = {**fixture.bundle.images, 'types': fixture.types_image, 'helpers': fixture.helpers_image}
by_sha = {value.image_sha256: name for name, value in images.items()}
ledger = dict.fromkeys(images, 0)


def observe(image):
    name = by_sha.get(image.image_sha256)
    if name is None:
        return
    entry = image._entry
    def counted(source, size, output, capacity, workspace, workspace_size):
        ledger[name] += 1
        return entry(source, size, output, capacity, workspace, workspace_size)
    image._entry = counted


for image in images.values():
    observe(image)
original_init = NativeHiaJsonImage.__init__
def observed_init(image, raw, expected_sha):
    original_init(image, raw, expected_sha)
    observe(image)


observations = []
if options.group == 'lifecycle':
    names = ['tests.test_hia_composite_public_lifecycle']
    expected_count = 3
    from tests import test_hia_composite_public_lifecycle as lifecycle
    original_assert = lifecycle._WeakLifetimeObservation.assert_released
    def record_assert(observer, case):
        original_assert(observer, case)
        observations.append({'case': str(case._subtest),
            'sessions': {name: [{'alive': ref() is not None,
                                'closed': None if ref() is None else ref()._closed}
                               for ref in refs] for name, refs in observer.sessions.items()},
            'buffers': [{'bytes': size, 'collected': ref() is None} for size, ref in observer.buffers],
            'close_results': observer.closed.copy(), 'allocation_fault_injected': observer.injected,
            'assertions_passed': True})
    lifecycle._WeakLifetimeObservation.assert_released = record_assert
else:
    names = ['tests.test_hia_composite_function_tokens',
             'tests.test_hia_composite_function_admission',
             'tests.test_hia_composite_function_protocol_audit',
             'tests.test_hia_composite_function_terms_native',
             'tests.test_hia_composite_functions_native']
    expected_count = 33

with patch.object(NativeHiaJsonImage, '__init__', new=observed_init):
    with (OUT / 'tests.log').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames(names))
fixture.check_custody()
after, inputs_after = sources(), artifacts()
write('source-after.json', after)
write('artifacts-after.json', inputs_after)
write('weak-lifetime-observations.json', observations)
write('native-entry-ledger.json', {'entries': ledger, 'total': sum(ledger.values()),
    'image_sha256': {name: image.image_sha256 for name, image in images.items()},
    'scope': 'actual in-process entries; installed child processes excluded'})
passed = (result.wasSuccessful() and result.testsRun == expected_count and not result.skipped
          and not result.expectedFailures and not result.unexpectedSuccesses
          and before == after and inputs_before == inputs_after)
summary = {'status': 'PASS' if passed else 'HOLD', 'group': options.group,
    'python': sys.version, 'fixture_scope': fixture.scope,
    'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
    'unexpected_successes': len(result.unexpectedSuccesses),
    'seconds': time.monotonic() - started,
    'max_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'source_preserved': before == after, 'native_artifacts_preserved': inputs_before == inputs_after,
    'actual_in_process_native_entries': sum(ledger.values()), 'weak_observations': len(observations),
    'matching_source_cold_qualified': False, 'whole_stack_rewritten_in_hia': False}
write('summary.json', summary)
print(json.dumps(summary), flush=True)
raise SystemExit(0 if passed else 1)
