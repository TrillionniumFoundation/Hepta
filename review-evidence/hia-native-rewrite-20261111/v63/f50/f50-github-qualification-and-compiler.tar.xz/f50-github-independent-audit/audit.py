"""Independent read-only final f50 CI audit, without filesystem extraction.

Each sealed cold-stage raw member is decompressed through bounded stream reads,
hashed, and discarded. No native witness or qualification is rerun. Language
fixture archives absent from the uploaded artifact are explicitly out of scope.
"""
from collections import Counter
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import gzip,json,re,subprocess,time,zipfile

ROOT=Path('/workspace/scratch/9acdfa9f5639')
OUT=ROOT/'f50-github-independent-audit'
ZIP=ROOT/'HIA-f50b3754-GitHub-native-pass-20261111.zip'
LOGS=ROOT/'hia-ci-f50-final'
CONTROL=ROOT/'f50-rog-qualification-control'
PIN='f50b37543d1a379353267ce0ab7111242806b8b4'
TREE='dcecb93e67ee4b9a7d9b26458dbcffbd602a7b09'
ZIP_SHA='a94a13f74c3ac5ee1aee30a6d5ae0f05e2903f77e7a880b5c30710efa6c2ea59'
P='hia-cold.cold/qualification.evidence/'
SOURCE='hia-cold.cold/source/'
FAMILIES=('capacity','cfg','elf','chain','owned','bulk','loan','resource','tail','select','effects','multi','keyword','signed','scalar-casts','explicit-traps','cli','names','exports')
started=time.monotonic_ns()

def sha(b):return sha256(b).hexdigest()
def hash_stream(stream):
    h=sha256();n=0
    for block in iter(lambda:stream.read(1024*1024),b''):h.update(block);n+=len(block)
    return h.hexdigest(),n
def file_info(path):
    s=path.stat()
    with path.open('rb') as f:h,n=hash_stream(f)
    assert n==s.st_size
    return dict(path=str(path),bytes=n,sha256=h,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
def save(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
def compact_sha(value):return sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode())

inputs={name:file_info(path) for name,path in [('artifact',ZIP),('jobs',LOGS/'jobs.json'),('artifact_metadata',LOGS/'artifacts.json'),('source_log',LOGS/'source-job.log'),('native_log',LOGS/'native-job.log')]}
assert inputs['artifact']['bytes']==56338188 and inputs['artifact']['sha256']==ZIP_SHA
jobdoc=json.loads((LOGS/'jobs.json').read_bytes())
jobs=jobdoc['jobs'];assert len(jobs)==2 and {r['name'] for r in jobs}=={'source','native'}
for job in jobs:
    assert job['head_sha']==PIN and job['run_id']==42966395957
    assert job['status']=='completed' and job['conclusion']=='success'
    assert all(s['status']=='completed' and s['conclusion']=='success' for s in job['steps'])
artifacts=json.loads((LOGS/'artifacts.json').read_bytes())['artifacts']
artifact=next(a for a in artifacts if a['id']==13831234361)
assert artifact['digest']=='sha256:'+ZIP_SHA and artifact['size_in_bytes']==56338188 and artifact['expired'] is False
state_raw=(CONTROL/'independent-expected-source-state.json').read_bytes()
assert len(state_raw)==344476 and sha(state_raw)=='2c90fbb9a45472707d3daf09b594174626af357704bf266a40943d970b6902cd'
state=json.loads(state_raw);assert state['head']==PIN and state['tree']==TREE and len(state['files'])==2628
contract_path='docs/HIA_SELFHOST_CORE_SUPPORT.json'
contract_raw=subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT/'Hepta'),'show',PIN+':'+contract_path])
assert sha(contract_raw)=='61406b5741d467e0041d8c76d0ecc14372bad7e4963dbd1846ce8b6a790e27aa'
contract=json.loads(contract_raw)
expected={**contract['source_identity']['files'],contract_path:sha(contract_raw)}
assert len(expected)==570 and all(state['files'][k]==v for k,v in expected.items())
closure_sha=compact_sha(expected);assert closure_sha=='6bd4071a2e94eb8ec0ae305cd92861a15a9f53263ba397712b3a2f27b3c9700f'
reads=[];source_rows=[];phases=[];archives=[];reference_rows=[];events=[]
with zipfile.ZipFile(ZIP) as z:
    names=z.namelist();assert len(names)==len(set(names))==1488
    def read(name):
        b=z.read(name);reads.append({'member':name,'bytes':len(b),'sha256':sha(b)});return b
    def get(name):return json.loads(read(name))
    cold_raw=read('hia-cold.json');cold=json.loads(cold_raw)
    qraw=read('hia-cold.cold/qualification.json');q=json.loads(qraw)
    assert sha(qraw)==cold['nested_report_sha256']
    assert cold['schema']=='hepta.hia.selfhost-cold-replay.v1' and cold['status']=='COLD_SELFHOST_REPLAY_PASS'
    assert cold['qualification_wall_limit_seconds']==180 and cold['cleanup_wall_limit_seconds']==3
    assert cold['returncode']==0 and len(cold['checks'])==11 and all(v is True for v in cold['checks'].values())
    assert cold['wall_elapsed_ns']==151755918610 and cold['wall_elapsed_ns']<180000000000
    assert q['schema']=='hepta.hia.selfhost-qualification.v6' and q['status']=='SELF_HOSTED_FIXED_CORE_PASS'
    assert len(q['checks'])==5049 and all(v is True for v in q['checks'].values())
    assert cold['source_manifest']==q['source_manifest']==expected
    assert q['support_contract']['sha256']==sha(contract_raw)
    actual_sources={n[len(SOURCE):] for n in names if n.startswith(SOURCE) and not n.endswith('/')}
    assert actual_sources==set(expected)
    for name in sorted(expected):
        info=z.getinfo(SOURCE+name)
        with z.open(info) as f:h,n=hash_stream(f)
        assert h==expected[name] and n==info.file_size
        source_rows.append({'path':name,'bytes':n,'sha256':h})
    owner=get('hia-cold.cold/process-owner.json')
    assert sha(z.read('hia-cold.cold/process-owner.json'))==cold['process_owner']['receipt_sha256']
    assert owner['qualification_seconds']==180 and owner['cleanup_seconds']==3 and owner['returncode']==0
    assert owner['status']=='OWNED_PROCESS_COMPLETED' and owner['timed_out'] is False
    cleanup=owner['cleanup'];assert cleanup['complete'] and cleanup['observed_echild'] and cleanup['errors']==[] and cleanup['remaining_direct_children']==[]
    assert cleanup['elapsed_ns']==7319815
    index=get(P+'phase-index.json')
    assert index['schema']=='hepta.hia.selfhost-phase-index.v1' and index['completed']==38 and index['exceptions']==0
    expected_pairs=[(f,label) for f in FAMILIES for label in ('original','modified')]
    assert [(r['family'],r['compiler_label']) for r in index['phases']]==expected_pairs
    sched=q['qualification_scheduling']
    assert sched['maximum_host_oracle_workers']==2 and sched['native_child_processes_reused'] is False
    assert sched['fresh_seed_and_generation_chain_sequential'] is True and sched['independent_references_completed_before_B0'] is True
    assert sched['phase_inventory']==[f+'-'+l for f,l in expected_pairs]
    scheduled={(r['family'],r['compiler_label']):r for r in sched['phases']};assert len(scheduled)==38
    for row in index['phases']:
        family,label=row['family'],row['compiler_label'];phase=family+'-'+label;stem=P+'phase-'+phase
        assert row['state']=='completed' and row['report_status']=='PASS'
        process=get(stem+'.process.json');request=get(stem+'.request.json');report_raw=read(stem+'.json');report=json.loads(report_raw)
        assert process==scheduled[(family,label)] and process['schema']=='hepta.hia.selfhost-phase-process.v1'
        assert process['returncode']==0 and sha(report_raw)==process['report_sha256']
        assert report['schema']=='hepta.hia.selfhost-phase.v1' and report['status']=='PASS'
        assert report['family']==family and report['compiler_label']==label and report['worker_pid']==process['worker_pid']
        assert report['source_manifest_sha256']==request['source_manifest_sha256']==closure_sha
        assert report['input_sha256']=={k:v['sha256'] for k,v in request['inputs'].items()}
        assert report['python']=={'isolated':True,'no_site':True,'dont_write_bytecode':True}
        assert report['fresh_host_oracle_process'] is True and report['successor_process_reuse'] is False
        assert report['checks'] and all(v is True for v in report['checks'].values())
        archive_receipt=process['raw_artifacts'];assert archive_receipt['every_original_byte_verified_before_retirement'] is True and archive_receipt['raw_paths_available'] is False
        assert archive_receipt==get(P+'phase-runs/'+phase+'/ARCHIVED.json')
        archive_name=P+'phase-runs/'+phase+'.zip';data=read(archive_name)
        assert len(data)==archive_receipt['packed_bytes'] and sha(data)==archive_receipt['archive_sha256']
        with zipfile.ZipFile(BytesIO(data)) as packed:
            member_names=packed.namelist();assert len(member_names)==len(set(member_names))
            manifest_raw=packed.read('HIA_ARCHIVE_MANIFEST.json');assert sha(manifest_raw)==archive_receipt['manifest_sha256']
            manifest=json.loads(manifest_raw);files=manifest['files']
            assert manifest['schema']=='hepta.hia.lossless-evidence-archive.v1' and manifest['source_directory']==request['directory']
            assert set(member_names)==set(files)|{'HIA_ARCHIVE_MANIFEST.json'}
            assert len(files)==archive_receipt['files'] and len(files)<=100000
            total=0
            for member,record in files.items():
                assert not Path(member).is_absolute() and '..' not in Path(member).parts
                info=packed.getinfo(member)
                assert info.file_size==record['bytes'] and 0<=info.file_size<=16*1024*1024
                assert (info.external_attr>>16)&0o777==record['mode']
                with packed.open(info) as stream:actual,n=hash_stream(stream)
                assert n==record['bytes'] and actual==record['sha256']
                total+=n
            assert total==manifest['unpacked_bytes']==archive_receipt['unpacked_bytes'] and total<=512*1024*1024
        archives.append({'phase':phase,'member':archive_name,'archive_sha256':archive_receipt['archive_sha256'],'manifest_sha256':archive_receipt['manifest_sha256'],'files':len(files),'raw_bytes':total,'packed_bytes':len(data),'all_member_payloads_sizes_modes_and_crc_verified':True})
        events.extend([(process['started_monotonic_ns'],1),(process['completed_monotonic_ns'],-1)])
        phases.append({'phase':phase,'worker_pid':process['worker_pid'],'checks':len(report['checks']),'report_sha256':sha(report_raw),'started_ns':process['started_monotonic_ns'],'completed_ns':process['completed_monotonic_ns']})
        print(json.dumps({'phase_verified':phase,'members':len(files),'raw_bytes':total}),flush=True)
    assert len({p['worker_pid'] for p in phases})==38
    active=maximum=0
    for t,delta in sorted(events):active+=delta;maximum=max(maximum,active);assert 0<=active<=2
    assert active==0 and maximum==2
    for receipt in sched['reference_processes']:
        name=P+'reference-'+receipt['family']+'.worker.json';raw=read(name);r=json.loads(raw)
        assert sha(raw)==receipt['report_sha256'] and r['reference_sha256']==receipt['reference_sha256']==compact_sha(r['reference'])
        assert r['source_manifest_sha256']==closure_sha and r['worker_pid']==receipt['worker_pid'] and r['before_B0'] is True
        assert receipt['returncode']==0 and receipt['completed_monotonic_ns']<sched['seed_started_monotonic_ns']
        reference_rows.append({'family':receipt['family'],'worker_pid':receipt['worker_pid'],'report_sha256':sha(raw),'reference_sha256':r['reference_sha256'],'completed_before_B0':True})
    assert len(reference_rows)==len({r['family'] for r in reference_rows})==len({r['worker_pid'] for r in reference_rows})==17
    seed_raw=read(P+'B0.so');assert sha(seed_raw)==cold['seed_sha256']==q['seed']['artifact_sha256']
    for receipt in [*q['generations'],*q['modified_generations']]:
        name=P+receipt['case']+'.image.bin';image=read(name)
        assert sha(image)==receipt['produced_sha256'] and len(image)==receipt['produced_bytes']
    original=[r['produced_sha256'] for r in q['generations']];modified=[r['produced_sha256'] for r in q['modified_generations']]
    assert original==cold['generation_sha256'] and modified==cold['modified_generation_sha256']
    assert len(original)==len(modified)==3 and len(set(original))==1 and modified[0]!=modified[1]==modified[2] and modified[2]!=original[0]
    language_raw=read('hia-language.json');language=json.loads(language_raw);assertions=get('hia-language.assertions.json')
    assert language['schema']=='hepta.hia.selfhost-language-qualification.v1' and language['status']=='SELFHOST_LANGUAGE_COVERAGE_PASS'
    assert language['source_manifest']==expected and len(language['checks'])==1242 and all(v is True for v in language['checks'].values())
    assert assertions['report_sha256']==sha(language_raw) and assertions['passed'] is True and assertions['tests_run']==10
    assert assertions['errors']==assertions['failures']==assertions['skipped']==[]
    missing_language=[]
    for r in language['fixture_archives']:
        member=r['archive'].removeprefix('/home/runner/work/_temp/')
        if member not in names:missing_language.append({k:r[k] for k in ('archive','archive_sha256','manifest_sha256','files','packed_bytes','unpacked_bytes')})
    assert len(missing_language)==2

test_groups=[]
for job_name,filename in [('source','source-job.log'),('native','native-job.log')]:
    text=(LOGS/filename).read_text();lines=[re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+Z ','',line) for line in text.splitlines()]
    assert PIN in text
    context='';bad=[]
    for i,line in enumerate(lines):
        if line.startswith('##[group]Run '):context=line[len('##[group]'):]
        if re.match(r'^(FAIL:|ERROR:|UNEXPECTED SUCCESS:|FAILED\b|OK\s*\()',line) or re.search(r'\.\.\. (skipped\b|expected failure\b|unexpected success\b)',line):bad.append({'line':i+1,'text':line})
        m=re.fullmatch(r'Ran (\d+) tests? in ([\d.]+)s',line)
        if m:
            following=next((v for v in lines[i+1:] if v.strip()),None)
            assert int(m[1])>0 and following=='OK'
            test_groups.append({'job':job_name,'command_group':context,'tests':int(m[1]),'seconds_text':m[2],'raw_log_line':i+1,'summary':'OK','all_five_anomaly_kinds_absent':True})
    assert not bad,bad
assert [r['tests'] for r in test_groups if r['job']=='source']==[280]
assert [r['tests'] for r in test_groups if r['job']=='native']==[10,242,17,32,10,21,10,12,10,39,11,7,27,25,53]
for name,record in inputs.items():assert file_info(Path(record['path']))==record
result={
 'schema':'hepta.hia.f50-github-independent-final-audit.v1','status':'CI_SOURCE_AND_NATIVE_JOBS_PASS_OBSERVED',
 'commit':PIN,'tree':TREE,'run_id':42966395957,'job_ids':{r['name']:r['id'] for r in jobs},
 'input_files':inputs,'artifact_digest_matches_github_metadata':True,
 'cold':{'schema':cold['schema'],'status':cold['status'],'report_sha256':sha(cold_raw),'checks_passed':11,'checks_total':11,'wall_elapsed_ns':cold['wall_elapsed_ns'],'qualification_seconds':180,'cleanup_seconds':3,'cleanup':cleanup,'source_members':570,'source_manifest_sha256':closure_sha,'all_source_payloads_match_pinned_git':True},
 'nested_qualification':{'schema':q['schema'],'status':q['status'],'report_sha256':sha(qraw),'checks_passed':5049,'checks_total':5049,'phase_count':38,'phase_exceptions':0,'unique_phase_worker_pids':38,'observed_maximum_phase_workers':maximum,'fresh_reference_workers':17,'all_reference_workers_completed_before_B0':True,'generation_sha256':original,'modified_generation_sha256':modified,'claims':q['claims']},
 'phases':phases,'reference_workers':reference_rows,
 'cold_phase_archive_replay':{'archives':38,'member_payloads':sum(r['files'] for r in archives),'raw_bytes':sum(r['raw_bytes'] for r in archives),'packed_bytes':sum(r['packed_bytes'] for r in archives),'every_container_sha_and_manifest_sha_verified':True,'every_member_payload_sha_size_mode_crc_verified':True,'filesystem_extraction_performed':False,'records':archives},
 'language':{'report_sha256':sha(language_raw),'status':language['status'],'checks_passed':1242,'checks_total':1242,'assertion_tests':10,'assertions_errors_failures_skips_empty':True,'source_manifest_matches':True,'raw_fixture_archives_missing_from_upload':missing_language,'raw_fixture_members_replayed':False,'claims':language['claims']},
 'actual_test_groups':test_groups,'test_count_across_ci_groups':sum(r['tests'] for r in test_groups),'all_ci_groups_nonempty_and_zero_anomalies':True,
 'limits':['This CI workflow is not the complete retained repository regression. The separate ROG full job is not reclassified by this audit.','Whole HIA language self-hosting and whole-native delivery are not established by these finite gates.','All 38 cold-stage archives were independently replayed by streaming every raw member. The two language fixture archives are absent from the upload and were not independently replayed.','No native program/test/qualification was rerun, and no production source, budget, concurrency or observation surface was changed.'],
 'recommendation':'Include hia-language.evidence in future upload-artifact paths to retain the two already-sealed language raw ZIPs; keep the current run/report unchanged.',
 'audit_wall_ns':time.monotonic_ns()-started,
}
save('summary.json',result)
for filename,rows in [('source-member-ledger.jsonl.gz',source_rows),('outer-member-read-ledger.jsonl.gz',reads)]:
    with (OUT/filename).open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as f:
            for r in rows:f.write(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n')
files={}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ('custody.json','audit.stdout.log','audit.stderr.log'):
        files[path.name]={'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
save('custody.json',{'schema':'hepta.hia.f50-github-readonly-audit-custody.v1','inputs':inputs,'outputs':files,'all_inputs_unchanged':True,'no_filesystem_extraction':True,'source_modified':False,'qualification_rerun':False,'summary_status':result['status'],'language_raw_archive_retention_gap_preserved':True})
print(json.dumps({'status':result['status'],'cold_checks':11,'nested_checks':5049,'phase_archive_replay':{k:v for k,v in result['cold_phase_archive_replay'].items() if k!='records'},'ci_tests':result['test_count_across_ci_groups'],'language_archives_missing':len(missing_language),'summary_sha256':sha((OUT/'summary.json').read_bytes()),'audit_wall_ns':result['audit_wall_ns']},sort_keys=True),flush=True)
