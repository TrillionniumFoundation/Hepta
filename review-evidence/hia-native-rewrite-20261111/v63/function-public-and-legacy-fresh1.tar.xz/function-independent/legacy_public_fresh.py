"""Actual historical import boundary with retained and complete HIA owners."""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import gzip
import hashlib
import json
import time
import replay_functions_fresh as audit
from hepta.hia_core_upgrade import import_legacy_composite_v2
from hepta.hia_program import HIAProgramRejected
from hepta.hia_program_runtime import execute_program
from hepta.hia_schema import SCHEMA_V2

OUT = audit.BASE / 'legacy-public-fresh1'
OUT.mkdir(exist_ok=False)
cases = json.loads((audit.BASE / 'legacy-cases-fresh.json').read_bytes())
cases = {key: case for key, case in cases.items()
         if case['document']['schema'] == 'hepta.hia.composite.v1'}
types = audit.native_types.installed_composite_types(audit.TYPE_MANIFEST)
helpers = audit.native_helpers.installed_task_helpers(audit.HELPER_MANIFEST)
bundle = audit.native_functions.installed_composite_functions(audit.FUNCTION_MANIFEST)
observer = audit.Observer(OUT / 'native-entries.jsonl.gz')
before = audit.pins()
before[str(Path(__file__))] = dict(bytes=Path(__file__).stat().st_size,
    sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'source-before.json').write_bytes(audit.wire(before))
rows = []
started = time.monotonic()
with ExitStack() as ledger:
    for image, name in [(types, 'types'), (helpers, 'helpers'), *[(v, k) for k, v in bundle.images.items()]]:
        ledger.enter_context(patch.object(image, '_entry', new=observer.wrap(image, name)))
    try:
        for identity, case in cases.items():
            document = deepcopy(case['document'])
            document['schema'] = SCHEMA_V2
            source = audit.wire(document)
            row = dict(identity=identity, source=document, observations={})
            observer.source = identity
            for variant in ('retained', 'native-function'):
                observer.variant = variant
                with ExitStack() as selected:
                    if variant == 'retained':
                        selected.enter_context(patch.object(audit.native_types, 'selected_composite_types', new=lambda *a, **k: None))
                        selected.enter_context(patch.object(audit.native_helpers, 'selected_task_helpers', new=lambda: None))
                        selected.enter_context(patch.object(audit.native_functions, 'selected_composite_functions', new=lambda: None))
                    else:
                        selected.enter_context(patch.object(audit.native_types, 'selected_composite_types',
                            new=lambda definitions, **flags: types.session(definitions, **flags)))
                        selected.enter_context(patch.object(audit.native_helpers, 'selected_task_helpers', new=lambda: helpers))
                        selected.enter_context(patch.object(audit.native_functions, 'selected_task_helpers', new=lambda: helpers))
                        selected.enter_context(patch.object(audit.native_functions, 'selected_composite_functions', new=lambda: bundle))
                        selected.enter_context(patch.object(audit.composite, '_Types', new=audit.forbidden))
                        names = set(audit.NATIVE_DEPENDENCY_HOST_OWNERS + audit.NATIVE_FUNCTION_HOST_OWNERS) - {'function'}
                        for name in names:
                            selected.enter_context(patch.object(audit.composite._Elaborator, name, new=audit.forbidden))
                    try:
                        checked, report = import_legacy_composite_v2(source)
                        value = dict(status='accepted', canonical_hex=checked.canonical_bytes.hex(),
                                     structured_hex=checked.structured_bytes.hex(), report=report)
                        label = case['labels'][0]
                        execution = {
                            'historical-import-stored-loan': ('stored', [True]),
                            'historical-import-enum-owner': ('choose', [False, 7]),
                            'historical-import-task': ('task_case', [2]),
                        }[label]
                        run = execute_program(checked, *execution)
                        value['vm_result'], value['vm_resources'] = run['result'], run['resources']
                    except HIAProgramRejected as error:
                        value = dict(status='rejected', error=audit.rejected(error))
                    row['observations'][variant] = value
                assert audit.wire(document) == source
            row['exact'] = row['observations']['retained'] == row['observations']['native-function']
            rows.append(row)
            with (OUT / 'outcomes.jsonl').open('ab') as target:
                target.write(audit.wire(row) + b'\n')
    finally:
        observer.close()
after = audit.pins()
after[str(Path(__file__))] = dict(bytes=Path(__file__).stat().st_size,
    sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'source-after.json').write_bytes(audit.wire(after))
summary = dict(scope='ACTUAL_PUBLIC_HISTORICAL_IMPORT_AND_VM', cases=len(rows),
    exact=sum(row['exact'] for row in rows),
    accepts=sum(row['observations']['native-function']['status']=='accepted' for row in rows),
    refusals=sum(row['observations']['native-function']['status']=='rejected' for row in rows),
    source_preserved=before==after,
    entries=[dict(variant=k[0], kernel=k[1], count=v) for k,v in sorted(observer.counts.items())],
    elapsed_seconds=time.monotonic()-started, cold_qualified=False,
    runtime_role='independent retained Core VM, not a new native runtime claim')
(OUT / 'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
assert before==after and len(rows)==6 and all(row['exact'] for row in rows)
assert summary['accepts']==3 and summary['refusals']==3
