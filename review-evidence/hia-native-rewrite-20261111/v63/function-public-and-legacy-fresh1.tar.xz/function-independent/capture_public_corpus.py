"""Fresh public corpus capture after temporary audit evidence was reset."""
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
import gzip,hashlib,inspect,json,os,sys,unittest
ROOT=Path('/workspace/scratch/9acdfa9f5639/Hepta')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));os.chdir(ROOT)
for name in tuple(os.environ):
    if name.startswith('HEPTA_HIA_') and (name.endswith('_MANIFEST') or name.endswith('_COLD_REPORT')):
        os.environ.pop(name)
from hepta import hia_program_composite as c
from tools.hia_selfhost_contract import file_digests
def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
def error(exc):return {'class':type(exc).__name__,'code':getattr(exc,'code',None),'text':str(exc)}
records=[];current=[None]
old_init,old_lower,old_function=c._Elaborator.__init__,c._Elaborator.lower,c._Elaborator.function
def init(self,document,*,legacy=False):
    frame=inspect.currentframe().f_back;public=False
    while frame:
        public |= frame.f_code.co_name=='verify_program' and frame.f_code.co_filename.endswith('/hepta/hia_program.py')
        frame=frame.f_back
    row={'index':len(records),'test_id':current[0],'public_verifier_route':public,
         'document':deepcopy(document),'legacy':legacy,'functions':[]}
    records.append(row);self._root_capture=row
    try:old_init(self,document,legacy=legacy)
    except Exception as exc:row['constructor_error']=error(exc);raise
def function(self,fn):
    row={'name':fn['name'],'before':{'serial':self.serial,'value_slots':self.value_slots}}
    self._root_capture['functions'].append(row)
    try:
        value=old_function(self,fn);row['result']=deepcopy(value);return value
    except Exception as exc:row['error']=error(exc);raise
    finally:
        row['after']={'serial':self.serial,'value_slots':self.value_slots,'helpers':deepcopy(self.helpers),
                      'helper_names':[[*key,value] for key,value in self.helper_names.items()],
                      'type_cache_keys':list(self.types.cache),'type_active':sorted(self.types.active),
                      'partial_declaration_steps':self.types.partial_declaration_steps}
def lower(self):
    try:
        value=old_lower(self);self._root_capture['result']=deepcopy(value);return value
    except Exception as exc:self._root_capture['lower_error']=error(exc);raise
class Result(unittest.TextTestResult):
    def startTest(self,test):current[0]=test.id();super().startTest(test)
names=['tests.test_hia_program_composite.CompositeExecutionTests',
       'tests.test_hia_program_composite.CompositeRejectionTests',
       'tests.test_hia_partial_record.PartialRecordExecutionTests',
       'tests.test_hia_partial_record.PartialRecordRejectionTests',
       'tests.test_hia_partial_record.PartialRecordCompatibilityTests',
       'tests.test_hia_composite_returned_loans.CompositeReturnedLoans',
       'tests.test_hia_composite_v6_resources.UnifiedResourceTests']
before=file_digests();(OUT/'source-before.json').write_bytes(raw(before))
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
with patch.object(c._Elaborator,'__init__',new=init),patch.object(c._Elaborator,'function',new=function),patch.object(c._Elaborator,'lower',new=lower):
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
after=file_digests();assert before==after
(OUT/'source-after.json').write_bytes(raw(after))
with gzip.GzipFile(filename=str(OUT/'retained-observations.jsonl.gz'),mode='wb',mtime=0) as stream:
    for row in records:stream.write(raw(row)+b'\n')
unique={}
for row in records:
    if row['public_verifier_route']:
        key=hashlib.sha256(raw({'document':row['document'],'legacy':row['legacy']})).hexdigest()
        unique.setdefault(key,{'document':row['document'],'legacy':row['legacy'],'captured_by':[]})['captured_by'].append(row['index'])
(OUT/'public-cases.json').write_bytes(raw(unique))
counts={'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),
        'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses)}
summary={'scope':'FRESH_PUBLIC_NOMINAL_CORPUS_CAPTURE_AFTER_ENVIRONMENT_RESET','baseline_commit':'f50b37543d1a379353267ce0ab7111242806b8b4',
         'sources_preserved':True,'counts':counts,'observations':len(records),'public_observations':sum(r['public_verifier_route'] for r in records),
         'unique_public_documents':len(unique),'function_calls':sum(len(r['functions']) for r in records),
         'public_cases_sha256':hashlib.sha256(raw(unique)).hexdigest(),'native_qualification':False,'historical_lost_bytes_claimed_restored':False}
(OUT/'capture-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary),flush=True)
raise SystemExit(0 if result.wasSuccessful() and counts['tests']>0 and not any(v for k,v in counts.items() if k!='tests') else 1)
