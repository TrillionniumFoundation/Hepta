"""New deterministic mutation panel from source-admitted public controls.

This reconstructs coverage, not the lost pre-restart panel's original bytes.
Only one change per candidate is applied; duplicate documents retain all labels.
"""
from copy import deepcopy
from pathlib import Path
import collections
import hashlib
import json
import os
import sys

ROOT = Path('/workspace/scratch/9acdfa9f5639/native-function-recovered')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
for key in tuple(os.environ):
    if key.startswith('HEPTA_HIA_') and (key.endswith('_MANIFEST') or key.endswith('_COLD_REPORT')):
        os.environ.pop(key)
from hepta.hia_program import HIAProgramRejected, _decode, verify_program
from tests import test_hia_program_composite as fixtures
from tests import test_hia_composite_v6_resources as resources


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode()


def read_at(document, path):
    for item in path:
        document = document[item]
    return document


def change_at(document, path, value=None, *, delete=False):
    document = deepcopy(document)
    owner = read_at(document, path[:-1])
    if delete:
        del owner[path[-1]]
    else:
        owner[path[-1]] = deepcopy(value)
    return document


cases, excluded = {}, []


def add(document, label, *, parent=None, legacy=False):
    try:
        decoded, raw = _decode(document)
        assert wire(decoded) == raw
    except HIAProgramRejected as error:
        excluded.append(dict(label=label, code=error.code, text=str(error)))
        return
    identity = hashlib.sha256(wire(dict(document=document, legacy=legacy))).hexdigest()
    case = cases.setdefault(identity, dict(document=deepcopy(document), legacy=legacy, labels=[], parents=[]))
    if label not in case['labels']:
        case['labels'].append(label)
    if parent is not None and parent not in case['parents']:
        case['parents'].append(parent)


public = json.loads((OUT / 'public-cases.json').read_bytes())
valid = {}
for identity, case in public.items():
    try:
        verify_program(case['document'])
    except HIAProgramRejected:
        continue
    assert not case['legacy']
    valid[identity] = case
    add(case['document'], 'valid-public-control', parent=identity)

operations, terms = {}, {}
for identity, case in valid.items():
    for fi, fn in enumerate(case['document']['functions']):
        for bi, block in enumerate(fn['blocks']):
            for oi, operation in enumerate(block['ops']):
                operations.setdefault(operation['op'], (identity, ('functions', fi, 'blocks', bi, 'ops', oi)))
            terms.setdefault(block['term']['op'], (identity, ('functions', fi, 'blocks', bi, 'term')))

for opcode, (identity, path) in sorted(operations.items()):
    document = valid[identity]['document']
    original = read_at(document, path)
    prefix = 'operation/' + opcode
    def changed(suffix, value, subpath=()):
        add(change_at(document, path + tuple(subpath), value), prefix + '/' + suffix, parent=identity)
    for name, value in [('null', None), ('list', []), ('empty', {})]:
        changed(name, value)
    for name in ('op', 'args', 'out', 'attrs'):
        add(change_at(document, path + (name,), delete=True), prefix + '/missing-' + name, parent=identity)
    for name, value in [('unknown', 'unknown.operation'), ('null', None), ('number', 0), ('list', [])]:
        changed('opcode-' + name, value, ('op',))
    for name, value in [('null', None), ('empty', []), ('undefined', ['missing']),
                        ('reserved', ['__hia_private']), ('nonstring', [None]), ('object', {})]:
        changed('args-' + name, value, ('args',))
    if original['args']:
        changed('args-duplicated', original['args'] + [original['args'][0]], ('args',))
        changed('args-reversed', list(reversed(original['args'])), ('args',))
    for name, value in [('null', None), ('empty', []), ('empty-item', [{}]),
                        ('unknown-type', [{'name': 'audit_unknown', 'type': 'Unknown'}]),
                        ('reserved', [{'name': '__hia_private', 'type': 'u8'}]),
                        ('null-name', [{'name': None, 'type': 'u8'}]),
                        ('unit', [{'name': 'audit_unit', 'type': 'unit'}]),
                        ('buffer', [{'name': 'audit_buffer', 'type': 'buffer'}])]:
        changed('out-' + name, value, ('out',))
    if original['out']:
        changed('out-duplicated', original['out'] + [original['out'][0]], ('out',))
    for name, value in [('null', None), ('list', []), ('empty', {}),
                        ('extra', {**original['attrs'], 'unexpected': None})]:
        changed('attrs-' + name, value, ('attrs',))
    for name in original['attrs']:
        for suffix, value in [('null', None), ('unknown', 'unknown')]:
            changed('attribute-' + name + '-' + suffix, value, ('attrs', name))
    changed('extra-field', {**original, 'unexpected': None})

for opcode, (identity, path) in sorted(terms.items()):
    document = valid[identity]['document']
    original = read_at(document, path)
    prefix = 'terminator/' + opcode
    def changed(suffix, value, subpath=()):
        add(change_at(document, path + tuple(subpath), value), prefix + '/' + suffix, parent=identity)
    for name, value in [('null', None), ('list', []), ('empty', {}), ('unknown', {'op': 'unknown'})]:
        changed(name, value)
    for name in original:
        changed(name + '-null', None, (name,))
        add(change_at(document, path + (name,), delete=True), prefix + '/missing-' + name, parent=identity)
        if name in ('args', 'values', 'cases'):
            changed(name + '-empty', [], (name,))
            if type(original[name]) is list and original[name]:
                changed(name + '-duplicate', original[name] + [original[name][0]], (name,))
        if name in ('value', 'condition', 'cond', 'target'):
            changed(name + '-unknown', 'missing', (name,))
    changed('extra-field', {**original, 'unexpected': None})
    block_path = path[:-1]
    block = read_at(document, block_path)
    for name, value in [('id-null', None), ('id-reserved', '__hia_private')]:
        add(change_at(document, block_path + ('id',), value), prefix + '/block-' + name, parent=identity)
    for name, value in [('null', None), ('empty', []), ('bad-name', [{'name': '__hia_private', 'type': 'u8'}])]:
        add(change_at(document, block_path + ('params',), value), prefix + '/block-params-' + name, parent=identity)
    for name, value in [('null', None), ('object', {}), ('empty', [])]:
        add(change_at(document, block_path + ('ops',), value), prefix + '/block-ops-' + name, parent=identity)
    for name in ('id', 'params', 'ops', 'term'):
        add(change_at(document, block_path + (name,), delete=True), prefix + '/block-missing-' + name, parent=identity)
    function_path = path[:2]
    function = read_at(document, function_path)
    for name in ('missing', '__hia_private'):
        add(change_at(document, function_path + ('entry',), name), prefix + '/entry-' + name, parent=identity)
    for name, value in [('null', None), ('empty', []), ('object', {}),
                        ('duplicate', function['blocks'] + [function['blocks'][0]])]:
        add(change_at(document, function_path + ('blocks',), value), prefix + '/blocks-' + name, parent=identity)

# Real historical import profiles, including negative new-opcode controls.
legacy = {}
for name, factory in [('stored-loan', fixtures.stored_loan_program),
                      ('enum-owner', fixtures.enum_owner_program), ('task', fixtures.task_program),
                      ('bulk', resources.composite_bulk_program),
                      ('range-task', resources.composite_range_task_program)]:
    document = factory(); document['schema'] = 'hepta.hia.composite.v1'
    identity = hashlib.sha256(wire(dict(document=document, legacy=True))).hexdigest()
    legacy[identity] = dict(document=document, legacy=True, labels=['historical-import-' + name])
document = fixtures.stored_loan_program(); document['schema'] = 'hepta.hia.composite.v1'
operation = document['functions'][0]['blocks'][1]['ops'][5]
assert operation['op'] == 'buffer.store'
operation['op'], operation['args'] = 'buffer.fill', ['parent', 'byte']
identity = hashlib.sha256(wire(dict(document=document, legacy=True))).hexdigest()
legacy[identity] = dict(document=document, legacy=True, labels=['historical-import-primitive-bulk-denied'])
for version in ('hepta.hia.composite.v2', 'hepta.hia.composite.v3', 'hepta.hia.composite.v4'):
    document = fixtures.stored_loan_program(); document['schema'] = version
    identity = hashlib.sha256(wire(dict(document=document, legacy=True))).hexdigest()
    legacy[identity] = dict(document=document, legacy=True, labels=['historical-import-new-schema-denied'])

(OUT / 'mutation-cases-fresh.json').write_bytes(wire(cases))
(OUT / 'legacy-cases-fresh.json').write_bytes(wire(legacy))
summary = dict(scope='NEW_POST_RESTART_MUTATION_PANEL', public_parents=len(public),
    valid_controls=len(valid), opcodes=sorted(operations), terminators=sorted(terms),
    mutation_cases=len(cases), labels=sum(len(v['labels']) for v in cases.values()),
    legacy_cases=len(legacy), source_gate_exclusions=excluded,
    mutation_file_sha256=hashlib.sha256(wire(cases)).hexdigest(),
    legacy_file_sha256=hashlib.sha256(wire(legacy)).hexdigest(),
    old_lost_panel_bytes_claimed_restored=False)
(OUT / 'mutation-build-summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
print(json.dumps(summary, sort_keys=True), flush=True)
assert len(valid) > 0 and len(operations) >= 40 and len(terms) == 5 and not excluded
