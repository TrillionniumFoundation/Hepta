"""Read original failed v64 CI evidence without rerunning qualification.

This records an audit of a failed, incomplete run. It never promotes the
34 completed phase reports into a passing 38-phase qualification.
"""
from collections import Counter
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import gzip, json, re, subprocess, tarfile, time, zipfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
OUT = ROOT / 'v64-github-independent-audit'
ZIP = ROOT / 'HIA-v64-5831f52f-GitHub-20261111.zip'
LOGS = ROOT / 'hia-ci-v64-final'
CONTROL = ROOT / 'hia-v64-publication'
PIN = '5831f52fada45e076f8f68f198a15c0585e6104f'
TREE = '72084752441a61f879dbbcf363a8cade3ef2d6b1'
ZIP_SHA = '128e25c6d8bfd8e58a36114fe5f55b066a14b91f76dc14e40294806ea6e4d71d'
P = 'hia-cold.cold/qualification.evidence/'
SOURCE = 'hia-cold.cold/source/'
FAMILIES = ('capacity','cfg','elf','chain','owned','bulk','loan','resource','tail','select','effects','multi','keyword','signed','scalar-casts','explicit-traps','cli','names','exports')
started = time.monotonic_ns()

def sha(b): return sha256(b).hexdigest()
def compact_sha(v): return sha(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
def hash_stream(s):
    h = sha256(); n = 0
    for b in iter(lambda:s.read(1024*1024),b''): h.update(b); n += len(b)
    return h.hexdigest(), n
def file_info(p):
    st=p.stat()
    with p.open('rb') as f: h,n=hash_stream(f)
    assert n==st.st_size
    return dict(path=str(p),bytes=n,sha256=h,mode=st.st_mode&0o777,device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns,ctime_ns=st.st_ctime_ns)
def save(name,v):
    with (OUT/name).open('x') as f: json.dump(v,f,indent=2,sort_keys=True);f.write('\n')

inputs={k:file_info(p) for k,p in [('artifact',ZIP),('jobs',LOGS/'jobs.json'),('artifact_metadata',LOGS/'artifacts.json'),('source_log',LOGS/'source-job.log'),('native_log',LOGS/'native-job.log'),('library_receipt',LOGS/'library-upload.result.json')]}
assert inputs['artifact']['bytes']==47472576 and inputs['artifact']['sha256']==ZIP_SHA
jobs=json.loads((LOGS/'jobs.json').read_bytes())['jobs']
assert len(jobs)==2 and {j['name'] for j in jobs}=={'source','native'}
for job in jobs:
    assert job['head_sha']==PIN and job['run_id']==42986320732 and job['status']=='completed'
    assert job['conclusion']==('success' if job['name']=='source' else 'failure')
    if job['name']=='source': assert all(s['conclusion']=='success' for s in job['steps'])
    else:
        assert [(s['number'],s['conclusion']) for s in job['steps'] if 6<=s['number']<=21]==[(6,'failure')]+[(n,'skipped') for n in range(7,22)]
artifact=next(a for a in json.loads((LOGS/'artifacts.json').read_bytes()) if a['id']==13839074093)
assert artifact['digest']=='sha256:'+ZIP_SHA and artifact['size_in_bytes']==47472576 and not artifact['expired']
for fn,conclusion in [('hia-run.json','failure'),('codeql-run.json','success')]:
    obj=json.loads((LOGS/fn).read_bytes());assert obj['head_sha']==PIN and obj['status']=='completed' and obj['conclusion']==conclusion
codeql=json.loads((LOGS/'codeql-jobs.json').read_bytes())['jobs']
assert len(codeql)==4 and all(j['conclusion']=='success' for j in codeql)
library=json.loads((LOGS/'library-upload.result.json').read_bytes())['results']
assert len(library)==1 and library[0]['status']=='succeeded' and library[0]['local_metadata_applied'] is True
state_raw=(CONTROL/'full-source-snapshot.json').read_bytes()
assert sha(state_raw)=='1283ed7bffebe06b2955b662ab266ae70730d1f5c37e70e3d4d0b8c765f22c8d'
state=json.loads(state_raw);assert state['head']==PIN and state['tree']==TREE and len(state['files'])==2768
contract_path='docs/HIA_SELFHOST_CORE_SUPPORT.json'
contract_raw=subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT/'Hepta'),'show',PIN+':'+contract_path])
assert sha(contract_raw)=='89e6a187479a277beb6012cfc04054928d8db4f896cbbbcad94f85af8ecfd662'
contract=json.loads(contract_raw);expected={**contract['source_identity']['files'],contract_path:sha(contract_raw)}
assert len(expected)==614 and all(state['files'][k]==v for k,v in expected.items())
assert expected==json.loads((CONTROL/'expected-cold-source-map.json').read_bytes())
closure_sha=compact_sha(expected)
assert closure_sha=='76f070a41f21e0f347f9a1acec053d1fb965bdebda532c2d532704da7ec40eea'
source_rows=[];phases=[];archives=[];references=[];events=[];raw_reports={};partial=[];generations=[]
with zipfile.ZipFile(ZIP) as z:
    names=z.namelist();assert len(names)==len(set(names))==4394
    def read(name,retain=False):
        data=z.read(name)
        if retain: raw_reports[name]=data
        return data
    def get(name,retain=True): return json.loads(read(name,retain))
    cold_raw=read('hia-cold.json',True);cold=json.loads(cold_raw)
    assert cold['schema']=='hepta.hia.selfhost-cold-replay.v1' and cold['status']=='FAIL'
    assert cold['qualification_wall_limit_seconds']==180 and cold['cleanup_wall_limit_seconds']==3
    assert cold['returncode']==-9 and len(cold['checks'])==11 and sum(v is True for v in cold['checks'].values())==6
    assert cold['wall_elapsed_ns']==180141377508 and cold['nested_report_sha256'] is None
    assert 'hia-cold.cold/qualification.json' not in names
    assert cold['source_manifest']==expected
    actual_sources={n[len(SOURCE):] for n in names if n.startswith(SOURCE) and not n.endswith('/')}
    assert actual_sources==set(expected)
    for name in sorted(expected):
        info=z.getinfo(SOURCE+name)
        with z.open(info) as f:h,n=hash_stream(f)
        assert h==expected[name] and n==info.file_size
        source_rows.append({'path':name,'bytes':n,'sha256':h})
    owner=get('hia-cold.cold/process-owner.json')
    assert sha(z.read('hia-cold.cold/process-owner.json'))==cold['process_owner']['receipt_sha256']
    assert owner['qualification_seconds']==180 and owner['cleanup_seconds']==3 and owner['returncode']==-9
    assert owner['status']=='QUALIFICATION_TIMEOUT' and owner['timed_out'] is True
    cleanup=owner['cleanup']
    assert cleanup['complete'] and cleanup['observed_echild'] and cleanup['errors']==[] and cleanup['remaining_direct_children']==[]
    assert cleanup['elapsed_ns']==79801176 and not cleanup['deadline_exceeded']
    index=get(P+'phase-index.json')
    assert index['schema']=='hepta.hia.selfhost-phase-index.v1' and index['completed']==34 and index['exceptions']==0
    expected_pairs=[(f,label) for f in FAMILIES for label in ('original','modified')]
    assert [(r['family'],r['compiler_label']) for r in index['phases']]==expected_pairs
    for row in index['phases'][:34]:
        family,label=row['family'],row['compiler_label'];phase=family+'-'+label;stem=P+'phase-'+phase
        assert row['state']=='completed' and row['report_status']=='PASS'
        process=get(stem+'.process.json');request=get(stem+'.request.json');report_raw=read(stem+'.json',True);report=json.loads(report_raw)
        assert process['schema']=='hepta.hia.selfhost-phase-process.v1' and process['returncode']==0 and sha(report_raw)==process['report_sha256']
        assert report['schema']=='hepta.hia.selfhost-phase.v1' and report['status']=='PASS'
        assert report['family']==family and report['compiler_label']==label and report['worker_pid']==process['worker_pid']
        assert report['source_manifest_sha256']==request['source_manifest_sha256']==closure_sha
        assert report['input_sha256']=={k:v['sha256'] for k,v in request['inputs'].items()}
        assert report['python']=={'isolated':True,'no_site':True,'dont_write_bytecode':True}
        assert report['fresh_host_oracle_process'] is True and report['successor_process_reuse'] is False
        assert report['checks'] and all(v is True for v in report['checks'].values())
        receipt=process['raw_artifacts']
        assert receipt['every_original_byte_verified_before_retirement'] is True and receipt['raw_paths_available'] is False
        assert receipt==get(P+'phase-runs/'+phase+'/ARCHIVED.json')
        archive_name=P+'phase-runs/'+phase+'.zip';data=read(archive_name)
        assert len(data)==receipt['packed_bytes'] and sha(data)==receipt['archive_sha256']
        with zipfile.ZipFile(BytesIO(data)) as packed:
            members=packed.namelist();assert len(members)==len(set(members))
            manifest_raw=packed.read('HIA_ARCHIVE_MANIFEST.json');assert sha(manifest_raw)==receipt['manifest_sha256']
            manifest=json.loads(manifest_raw);files=manifest['files']
            assert manifest['schema']=='hepta.hia.lossless-evidence-archive.v1' and manifest['source_directory']==request['directory']
            assert set(members)==set(files)|{'HIA_ARCHIVE_MANIFEST.json'}
            assert len(files)==receipt['files'] and len(files)<=100000
            total=0
            for member,record in files.items():
                assert not Path(member).is_absolute() and '..' not in Path(member).parts
                info=packed.getinfo(member)
                assert info.file_size==record['bytes'] and 0<=info.file_size<=16*1024*1024
                assert (info.external_attr>>16)&0o777==record['mode']
                with packed.open(info) as stream:actual,n=hash_stream(stream)
                assert n==record['bytes'] and actual==record['sha256'];total+=n
            assert total==manifest['unpacked_bytes']==receipt['unpacked_bytes'] and total<=512*1024*1024
        archives.append({'phase':phase,'member':archive_name,'archive_sha256':receipt['archive_sha256'],'manifest_sha256':receipt['manifest_sha256'],'files':len(files),'raw_bytes':total,'packed_bytes':len(data),'all_member_payloads_sizes_modes_and_crc_verified':True})
        events.extend([(process['started_monotonic_ns'],1),(process['completed_monotonic_ns'],-1)])
        phases.append({'phase':phase,'worker_pid':process['worker_pid'],'checks':len(report['checks']),'report_sha256':sha(report_raw),'started_ns':process['started_monotonic_ns'],'completed_ns':process['completed_monotonic_ns']})
        print(json.dumps({'phase_verified':phase,'members':len(files),'raw_bytes':total}),flush=True)
    assert len({p['worker_pid'] for p in phases})==34 and sum(p['checks'] for p in phases)==3758
    active=maximum=0
    for t,delta in sorted(events):active+=delta;maximum=max(maximum,active);assert 0<=active<=2
    assert active==0 and maximum==2
    for row in index['phases'][34:]:
        phase=row['family']+'-'+row['compiler_label'];stem=P+'phase-'+phase
        assert row['state']=='pending' and stem+'.process.json' not in names and stem+'.json' not in names
        request_present=stem+'.request.json' in names
        assert request_present==(row['family']=='names')
        raw_prefix=P+'phase-runs/'+phase+'/'
        records=[n for n in names if n.startswith(raw_prefix) and n.endswith('.receipt.json')]
        assert bool(records)==request_present
        if request_present:
            request=get(stem+'.request.json');assert request['source_manifest_sha256']==closure_sha
            assert z.read(stem+'.stderr.log')==b''
        partial.append({'phase':phase,'reported_state':row['state'],'request_exists':request_present,'final_report_exists':False,'sealed_archive_exists':False,'available_call_receipts':len(records),'qualification_complete':False})
    for name in sorted(n for n in names if n.startswith(P+'reference-') and n.endswith('.worker.json')):
        raw=read(name,True);r=json.loads(raw)
        assert r['schema']=='hepta.hia.selfhost-independent-reference-process.v1' and r['before_B0'] is True
        assert r['source_manifest_sha256']==closure_sha and r['reference_sha256']==compact_sha(r['reference'])
        references.append({'family':r['family'],'worker_pid':r['worker_pid'],'report_sha256':sha(raw),'reference_sha256':r['reference_sha256'],'before_B0_flag':True})
    assert len(references)==len({r['family'] for r in references})==len({r['worker_pid'] for r in references})==17
    for case in ('B1','B2','B3','M1','M2','M3'):
        receipt=get(P+case+'.receipt.json');request=get(P+case+'.request.json');data=read(P+case+'.image.bin')
        assert receipt['case']==case and receipt['status']=='returned'
        assert len(data)==receipt['produced_bytes'] and sha(data)==receipt['produced_sha256']
        assert sha(read(P+case+'.input.bin'))==receipt['input_sha256']==receipt['source_sha256']==request['source_sha256']
        generations.append({'case':case,'image_sha256':sha(data),'image_bytes':len(data),'receipt_sha256':sha(z.read(P+case+'.receipt.json'))})
    original=[r['image_sha256'] for r in generations[:3]];modified=[r['image_sha256'] for r in generations[3:]]
    assert len(set(original))==1 and modified[0]!=modified[1]==modified[2] and modified[2]!=original[0]
    # Stream every outer member independently; ZipExtFile also verifies CRC.
    outer=[]
    for info in z.infolist():
        assert not Path(info.filename).is_absolute() and '..' not in Path(info.filename).parts
        with z.open(info) as f:h,n=hash_stream(f)
        assert n==info.file_size
        outer.append({'member':info.filename,'bytes':n,'sha256':h,'mode':(info.external_attr>>16)&0o777,'crc32':info.CRC})
    assert sum(r['bytes'] for r in outer)==338592203
    # Original report bytes are kept separately for portable diagnostic review.
    report_archive=OUT/'original-reports.tar.xz'
    with tarfile.open(report_archive,'x:xz') as t:
        for name,data in sorted(raw_reports.items()):
            ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;t.addfile(ti,BytesIO(data))
    with tarfile.open(report_archive,'r:xz') as t:
        assert len(t.getmembers())==len(raw_reports)
        for member in t:
            data=t.extractfile(member).read();assert data==raw_reports[member.name] and member.mode==0o644
    with gzip.open(OUT/'outer-members.json.gz','xt') as f:json.dump(outer,f,sort_keys=True,separators=(',',':'));f.write('\n')
    with gzip.open(OUT/'source-members.json.gz','xt') as f:json.dump(source_rows,f,sort_keys=True,separators=(',',':'));f.write('\n')

source_log=(LOGS/'source-job.log').read_text()
assert re.search(r'Ran 307 tests in 437\.444s',source_log)
assert inputs['artifact']==file_info(ZIP)
summary={'schema':'hepta.hia.v64-failed-ci-independent-audit.v1','status':'CI_HOLD_COLD_TIMEOUT_NATIVE_GROUPS_NOT_EXECUTED','source_head':PIN,'source_tree':TREE,'inputs':inputs,'source_files':len(expected),'source_manifest_sha256':closure_sha,'source_tests':{'tests_run':307,'seconds':437.444,'passed':True},'codeql':{'completed_languages':4,'passed':True},'cold':{'passed':False,'status':cold['status'],'wall_elapsed_ns':cold['wall_elapsed_ns'],'wall_limit_seconds':180,'checks':cold['checks'],'nested_report_exists':False,'timeout_owner_status':owner['status'],'cleanup':cleanup},'completed_phases':phases,'completed_checks':3758,'sealed_phase_archives':archives,'sealed_member_count':sum(a['files'] for a in archives),'sealed_raw_bytes':sum(a['raw_bytes'] for a in archives),'partial_or_unstarted_phases':partial,'maximum_overlapping_completed_phase_processes':maximum,'reference_reports':references,'generation_raw_fixed_points':generations,'generation_raw_fixed_points_are_full_qualification':False,'original_reports_archive':file_info(report_archive),'original_report_members':len(raw_reports),'outer_members':len(outer),'outer_unpacked_bytes':sum(r['bytes'] for r in outer),'historical_zip_in_source_not_counted_as_current_phase':True,'all_available_sealed_phase_and_outer_bytes_read_back':True,'qualification_rerun':False,'main_modified':False,'whole_stack_closed':False,'elapsed_ns':time.monotonic_ns()-started}
save('summary.json',summary)
save('custody.json',{'schema':'hepta.hia.v64-failed-ci-audit-custody.v1','files':[file_info(OUT/p) for p in ('audit.py','summary.json','outer-members.json.gz','source-members.json.gz','original-reports.tar.xz')]})
print(json.dumps({k:summary[k] for k in ('status','source_files','completed_checks','sealed_member_count','sealed_raw_bytes','outer_members','outer_unpacked_bytes','elapsed_ns')}),flush=True)
