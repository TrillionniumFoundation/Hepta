"""Read-only diagnosis of the original v64 failed GitHub cold artifact.

This does not run qualification or change any production file. It reads selected
JSON members and hashes completed stage ZIPs without expanding their payloads.
The separate parent audit owns the complete recursive raw-artifact readback.
"""
from __future__ import annotations

import collections
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
OUT = Path(__file__).resolve().parent
ARTIFACT = ROOT / 'HIA-v64-5831f52f-GitHub-20261111.zip'
OLD = ROOT / 'v63-github-independent-audit/summary.json'
REPO = ROOT / 'Hepta'
OLD_RAW = REPO / 'review-evidence/hia-native-rewrite-20261111/v63/github-final/hia-v63-github-cold-and-failure.tar.xz'
PREFIX = 'hia-cold.cold/qualification.evidence/'
EXPECTED_SHA = '128e25c6d8bfd8e58a36114fe5f55b066a14b91f76dc14e40294806ea6e4d71d'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path):
    s = path.stat()
    with path.open('rb') as f:
        digest = hashlib.file_digest(f, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': s.st_size, 'sha256': digest,
            'mtime_ns': s.st_mtime_ns, 'inode': s.st_ino}


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                       sort_keys=True) + '\n')


before = {'artifact': pin(ARTIFACT), 'v63_independent_summary': pin(OLD),
          'v63_original_reports_archive': pin(OLD_RAW)}
assert before['artifact']['bytes'] == 47472576
assert before['artifact']['sha256'] == EXPECTED_SHA
old = json.loads(OLD.read_bytes())
old_phases = {row['phase']: row for row in old['phases']}
old_refs = {row['family']: row for row in old['reference_workers']}
selected = []
raw_dir = OUT / 'selected-originals'
raw_dir.mkdir(exist_ok=True)
with tarfile.open(OLD_RAW) as t:
    old_cold_raw = t.extractfile('reports/hia-cold.json').read()
old_cold = json.loads(old_cold_raw)
assert sha(old_cold_raw) == old['cold']['report_sha256']
old_start_ns = next(e['monotonic_ns'] for e in old_cold['process_owner']['events']
                    if e['kind'] == 'qualification_started')
(raw_dir / 'v63-original-hia-cold.json').write_bytes(old_cold_raw)

with zipfile.ZipFile(ARTIFACT) as z:
    members = set(z.namelist())

    def read(name, save=False):
        raw = z.read(name)
        selected.append({'member': name, 'bytes': len(raw), 'sha256': sha(raw)})
        if save:
            relative = name.removeprefix(PREFIX).replace('/', '__')
            (raw_dir / relative).write_bytes(raw)
        return json.loads(raw), raw

    cold, cold_raw = read('hia-cold.json', True)
    index, _ = read(PREFIX + 'phase-index.json', True)
    owner = cold['process_owner']
    start = next(e['monotonic_ns'] for e in owner['events']
                 if e['kind'] == 'qualification_started')
    assert owner['status'] == 'QUALIFICATION_TIMEOUT'
    assert owner['cleanup']['complete'] is True
    assert owner['cleanup']['remaining_direct_children'] == []
    phases = []
    for row in index['phases']:
        name = row['family'] + '-' + row['compiler_label']
        record = {'phase': name, 'index_state': row['state'],
                  'request_present': PREFIX + 'phase-' + name + '.request.json' in members,
                  'report_present': PREFIX + 'phase-' + name + '.json' in members,
                  'process_receipt_present': PREFIX + 'phase-' + name + '.process.json' in members}
        if row['state'] == 'completed':
            proc, _ = read(PREFIX + 'phase-' + name + '.process.json', True)
            report, report_raw = read(PREFIX + 'phase-' + name + '.json')
            assert proc['report_sha256'] == sha(report_raw)
            assert row['report_status'] == report['status'] == 'PASS'
            assert proc['returncode'] == 0
            assert all(v is True for v in report['checks'].values())
            archive = proc['raw_artifacts']
            archive_member = 'hia-cold.cold/' + archive['archive'].split('/hia-cold.cold/', 1)[1]
            archive_raw = z.read(archive_member)
            assert sha(archive_raw) == archive['archive_sha256']
            # Central-directory parsing only: recursive contents belong to the
            # parent's independent complete archive readback.
            with zipfile.ZipFile(io.BytesIO(archive_raw)) as inner:
                archive_members = len(inner.infolist())
            a = old_phases[name]
            old_ns = a['completed_ns'] - a['started_ns']
            new_ns = proc['completed_monotonic_ns'] - proc['started_monotonic_ns']
            record.update({
                'status': report['status'], 'checks': len(report['checks']),
                'checks_all_true': True, 'returncode': proc['returncode'],
                'worker_pid': proc['worker_pid'],
                'started_ns': proc['started_monotonic_ns'],
                'completed_ns': proc['completed_monotonic_ns'],
                'start_after_qualification_ns': proc['started_monotonic_ns'] - start,
                'wall_ns': new_ns, 'v63_wall_ns': old_ns,
                'wall_ratio_v64_over_v63': new_ns / old_ns,
                'same_check_count_as_v63': len(report['checks']) == a['checks'],
                'report_sha256': sha(report_raw),
                'fresh_host_oracle_process': report['fresh_host_oracle_process'],
                'successor_process_reuse': report['successor_process_reuse'],
                'input_sha256': report['input_sha256'],
                'source_manifest_sha256': report['source_manifest_sha256'],
                'archive': archive,
                'archive_actual_sha256_matches': True,
                'archive_central_directory_members': archive_members,
            })
        else:
            p = PREFIX + 'phase-runs/' + name + '/'
            files = [n for n in members if n.startswith(p)]
            reqs = {n[:-len('.request.json')]: n for n in files if n.endswith('.request.json')}
            receipts = {n[:-len('.receipt.json')]: n for n in files if n.endswith('.receipt.json')}
            statuses = collections.Counter()
            native_ns = 0
            for n in sorted(receipts.values()):
                receipt, _ = read(n)
                statuses[str(receipt.get('status'))] += 1
                native_ns += receipt.get('native_elapsed_ns', 0)
            unfinished = []
            for k in sorted(reqs.keys() - receipts.keys()):
                request, _ = read(reqs[k], True)
                unfinished.append({'request_member': reqs[k], 'request': request})
            record.update({
                'raw_files': len(files),
                'raw_bytes': sum(z.getinfo(n).file_size for n in files),
                'receipt_files': len(receipts), 'request_files': len(reqs),
                'receipt_statuses': dict(statuses),
                'sum_native_elapsed_ns_from_retained_receipts': native_ns,
                'request_without_receipt': unfinished,
                'nonempty_stderr_members': [n for n in sorted(files)
                                            if n.endswith('.stderr.log') and z.getinfo(n).file_size],
                'receipt_count_is_not_invocation_count': True,
                'receipt_count_caveat': 'Some pre-existing qualifier labels reuse receipt paths; these are retained file counts, not complete native entry counts.',
            })
        phases.append(record)

    references = []
    for family, old_row in old_refs.items():
        worker, raw = read(PREFIX + 'reference-' + family + '.worker.json')
        references.append({
            'family': family, 'worker_pid': worker['worker_pid'],
            'before_B0': worker['before_B0'],
            'wall_ns': worker['wall_elapsed_ns'],
            'reference_sha256': worker['reference_sha256'],
            'same_reference_content_sha256_as_v63': worker['reference_sha256'] == old_row['reference_sha256'],
            'worker_report_sha256': sha(raw),
            'source_manifest_sha256': worker['source_manifest_sha256'],
        })
    compilers = []
    for label in ['B0', 'B1', 'B2', 'B3', 'M1', 'M2', 'M3']:
        r, _ = read(PREFIX + label + '.receipt.json', True)
        image_name = PREFIX + (label + '.so' if label == 'B0' else label + '.image.bin')
        image_raw = z.read(image_name)
        expected = r['artifact_sha256'] if label == 'B0' else r['produced_sha256']
        assert sha(image_raw) == expected
        compilers.append({
            'label': label, 'image_member': image_name,
            'bytes': len(image_raw), 'sha256': sha(image_raw),
            'receipt_produced_image_sha256_matches': True,
            'invoked_compiler_sha256': None if label == 'B0' else r['artifact_sha256'],
            'source_sha256': r.get('source_sha256'),
            'native_elapsed_ns': r.get('native_elapsed_ns'),
            'wall_elapsed_ns': r.get('wall_elapsed_ns'),
        })
    completed = [r for r in phases if r['index_state'] == 'completed']
    new_start = min(r['started_ns'] for r in completed)
    new_end = max(r['completed_ns'] for r in completed)
    old_start = min(old_phases[r['phase']]['started_ns'] for r in completed)
    old_end = max(old_phases[r['phase']]['completed_ns'] for r in completed)
    # Check the implementation bytes from each immutable Git commit, without
    # relying on a potentially concurrently edited worktree file.
    unchanged = []
    for rel in [
        'tools/qualify_hia_selfhost.py', 'tools/replay_hia_selfhost_cold.py',
        'tools/hia_selfhost_names.py', 'tools/hia_selfhost_signed.py',
        'tools/hia_selfhost_scalar_casts.py', 'tools/hia_selfhost_references.py',
        'tools/hia_selfhost_process_owner.py', 'tools/hia_selfhost_limits.py',
        'tools/hia_selfhost_native_observer.py', 'tools/hia_selfhost_child.py',
        'tools/hia_evidence_archive.py', 'hepta/hia_program.py',
        'examples/hia_bootstrap/selfhost.hiaasm',
    ]:
        a = subprocess.check_output(['git', 'show', old['commit'] + ':' + rel], cwd=REPO)
        b = subprocess.check_output(['git', 'show', '5831f52fada45e076f8f68f198a15c0585e6104f:' + rel], cwd=REPO)
        unchanged.append({'path': rel, 'same_bytes': a == b,
                          'v63_sha256': sha(a), 'v64_sha256': sha(b)})

    summary = {
        'schema': 'hepta.hia.v64-cold-independent-diagnosis.v1',
        'scope': 'Original artifact read-only diagnosis; no qualification rerun, no limit/check changes, no production edits.',
        'commit': '5831f52fada45e076f8f68f198a15c0585e6104f',
        'tree': '72084752441a61f879dbbcf363a8cade3ef2d6b1',
        'run_id': 42986320732, 'artifact_id': 13839074093,
        'status': 'QUALIFICATION_TIMEOUT_NO_FINAL_NESTED_REPORT',
        'input_before': before,
        'artifact_members': len(members),
        'outer_member_uncompressed_bytes': sum(i.file_size for i in z.infolist()),
        'qualification_start_monotonic_ns': start,
        'outer_wall_ns': cold['wall_elapsed_ns'],
        'qualification_seconds': cold['qualification_wall_limit_seconds'],
        'cleanup_seconds': cold['cleanup_wall_limit_seconds'],
        'outer_checks': cold['checks'],
        'outer_report_sha256': sha(cold_raw),
        'final_nested_report_present': 'hia-cold.cold/qualification.json' in members,
        'timeout_interpretation': 'The five false outer checks depend on the missing final nested report. They are not independent proof of a source/isolation/manifest violation. Empty outer generation arrays do not mean B/M compiler images were absent.',
        'process_owner': owner,
        'phase_index_completed': index['completed'],
        'phase_index_exceptions': index['exceptions'],
        'completed_phases': len(completed),
        'completed_phase_checks': sum(r['checks'] for r in completed),
        'all_completed_checks_true': all(r['checks_all_true'] for r in completed),
        'all_completed_check_counts_match_v63': all(r['same_check_count_as_v63'] for r in completed),
        'unique_completed_worker_pids': len({r['worker_pid'] for r in completed}),
        'sealed_phase_archives': len(completed),
        'all_completed_archive_sha256_match': True,
        'non_phase_zip': [n for n in sorted(members) if n.endswith('.zip') and '/qualification.evidence/phase-runs/' not in n],
        'phase_records': phases,
        'reference_workers': references,
        'all_17_reference_content_hashes_equal_v63': all(r['same_reference_content_sha256_as_v63'] for r in references),
        'actual_compiler_artifacts': compilers,
        'unchanged_critical_sources': unchanged,
        'comparison_to_v63': {
            'v63_status': old['cold']['status'],
            'v63_cold_wall_ns': old['cold']['wall_elapsed_ns'],
            'v64_pre_first_phase_ns': new_start - start,
            'v63_pre_first_phase_ns': old_start - old_start_ns,
            'additional_pre_first_phase_ns': (new_start - start) - (old_start - old_start_ns),
            'v63_qualification_start_monotonic_ns': old_start_ns,
            'v63_first_to_last_completed_phase_ns': old_end - old_start,
            'v64_first_to_last_completed_phase_ns': new_end - new_start,
            'additional_completed_phase_span_ns': (new_end - new_start) - (old_end - old_start),
            'caution': 'Two different GitHub runs are descriptive timing comparisons, not a controlled causal performance experiment. Several phases are slower while chain and multi are similar/faster. The available artifact does not identify runner contention, CPU model, or a particular production change as the cause.',
        },
        'qualification_conclusion': 'The unchanged 180-second gate failed. 34 passing completed phases and partial names work cannot qualify the whole compiler; both names results, both exports results, final nested report and all later CI groups remain unavailable for this run.',
        'next_action': 'Preserve this original failure. Use the measured pre-phase/phase timing profile to investigate remaining redundant fixture preparation or orchestration costs without removing any native witness, reference, source identity check, process isolation, or 180-second/two-worker gate. A new exact-source complete run is required after a justified fix.',
        'recursive_archive_readback_scope': 'This audit checked stage ZIP bytes against process receipts and parsed their central directories. The parent separately owns complete recursive member/CRC/hash/mode readback.',
    }

after = {'artifact': pin(ARTIFACT), 'v63_independent_summary': pin(OLD),
         'v63_original_reports_archive': pin(OLD_RAW)}
assert before == after
summary['input_after'] = after
summary['input_unchanged'] = True
write('selected-member-ledger.json', selected)
write('report.json', summary)
print(json.dumps({
    'report': str(OUT / 'report.json'),
    'report_sha256': sha((OUT / 'report.json').read_bytes()),
    'phase_checks': summary['completed_phase_checks'],
    'completed_phases': summary['completed_phases'],
    'same_check_counts_v63': summary['all_completed_check_counts_match_v63'],
    'all_17_reference_hashes_same': summary['all_17_reference_content_hashes_equal_v63'],
    'comparison': summary['comparison_to_v63'],
}, indent=2))
