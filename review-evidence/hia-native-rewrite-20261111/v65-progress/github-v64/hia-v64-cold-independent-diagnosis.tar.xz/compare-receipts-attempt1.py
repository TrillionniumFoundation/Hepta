"""Compare matched original v63/v64 receipt clocks; execute no native code."""
from collections import Counter, defaultdict
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import gzip
import json
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/9acdfa9f5639')
OUT = Path(__file__).resolve().parent
BASE = json.loads((OUT / 'report.json').read_bytes())
ZIP = Path(BASE['input_before']['artifact']['path'])
OLD = Path(BASE['input_before']['v63_original_reports_archive']['path'])
P = 'hia-cold.cold/qualification.evidence/'
M = 'HIA_ARCHIVE_MANIFEST.json'
FIELDS = {
    'capacity': ['expanded_capacity_observations'], 'cfg': ['cfg_worklist_observations'],
    'elf': ['elf_object_observations'], 'chain': ['chain_elf_observations', 'chain_allocator_observations'],
    'owned': ['owned_elf_observations'], 'bulk': ['bulk_observations'],
    'loan': ['loan_observations'], 'resource': ['resource_observations'],
    'tail': ['tail_call_observations'], 'select': ['select_observations'],
    'effects': ['effect_observations'], 'multi': ['multi_result_observations'],
    'keyword': ['keyword_observations'], 'signed': ['signed_observations'],
    'scalar-casts': ['scalar_cast_observations'], 'explicit-traps': ['explicit_trap_observations'],
    'cli': ['executable_cli_observations'],
}


def digest(raw): return sha256(raw).hexdigest()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def walk(v):
    if isinstance(v, dict):
        if 'wall_elapsed_ns' in v and 'case' in v and 'input_sha256' in v:
            yield v
        for child in v.values():
            yield from walk(child)
    elif isinstance(v, list):
        for child in v:
            yield from walk(child)


def key(r):
    return tuple(r.get(x) for x in ('case', 'input_sha256', 'image_sha256', 'format', 'transport'))


def clock_key(r):
    return tuple(r.get(x) for x in ('status', 'wall_elapsed_ns', 'native_elapsed_ns',
                                   'result_u64', 'core_u32', 'output_sha256', 'runner_sha256'))


def stats(rows, version='new'):
    r = [x[version] for x in rows]
    timed = [x for x in r if 'native_elapsed_ns' in x]
    wall = sum(x['wall_elapsed_ns'] for x in r)
    native = sum(x['native_elapsed_ns'] for x in timed)
    measured_wall = sum(x['wall_elapsed_ns'] for x in timed)
    return {'retained_receipt_count': len(r), 'native_clock_count': len(timed),
            'no_native_clock_count': len(r) - len(timed), 'wall_ns': wall,
            'native_ns': native, 'wall_minus_native_for_timed_ns': measured_wall - native,
            'wall_without_native_clock_ns': wall - measured_wall,
            'statuses': dict(Counter(x.get('status') for x in r))}


with tarfile.open(OLD) as t:
    raw = t.extractfile('reports/hia-cold.cold/qualification.json').read()
assert digest(raw) == json.loads((ROOT / 'v63-github-independent-audit/summary.json').read_bytes())['nested_qualification']['report_sha256']
old_report = json.loads(raw)
old_index = {}
old_index_stats = {}
for family, fields in FIELDS.items():
    candidates = defaultdict(dict)
    total = 0
    for field in fields:
        for row in walk(old_report[field]):
            total += 1
            candidates[key(row)][clock_key(row)] = row
    old_index[family] = candidates
    old_index_stats[family] = {'nested_references': total, 'distinct_identity_keys': len(candidates),
                               'ambiguous_clock_keys': sum(len(v) > 1 for v in candidates.values())}

ledger, match_ledger, missing, ambiguous, phases, json_ledger = [], [], [], [], [], []
with zipfile.ZipFile(ZIP) as z:
    for phase in BASE['phase_records']:
        if phase['index_state'] != 'completed':
            continue
        name = phase['phase']
        family, label = name.rsplit('-', 1)
        archive = phase['archive']
        archive_name = 'hia-cold.cold/' + archive['archive'].split('/hia-cold.cold/', 1)[1]
        packed_raw = z.read(archive_name)
        assert digest(packed_raw) == archive['archive_sha256']
        selected = set()
        rows, matched, command_rows, owner_rows = [], [], [], []
        frame_count = frame_bytes = repeated_sha_bytes = workspace_slice_bytes = 0
        with zipfile.ZipFile(BytesIO(packed_raw)) as packed:
            manifest_raw = packed.read(M)
            assert digest(manifest_raw) == archive['manifest_sha256']
            manifest = json.loads(manifest_raw)
            files = manifest['files']
            assert set(packed.namelist()) == set(files) | {M}

            def read(member):
                data = packed.read(member)
                assert len(data) == files[member]['bytes']
                assert digest(data) == files[member]['sha256']
                if member not in selected:
                    selected.add(member)
                    json_ledger.append({'archive': archive_name, 'member': member, **files[member]})
                return json.loads(data)

            for member in sorted(files):
                if member.endswith('.receipt.json'):
                    r = read(member)
                    if 'wall_elapsed_ns' not in r or 'case' not in r or 'input_sha256' not in r:
                        continue
                    item = {'phase': name, 'member': member, 'new': r}
                    req_name = member[:-len('.receipt.json')] + '.request.json'
                    if req_name in files:
                        request = read(req_name)
                        item['request'] = request
                        if r.get('transport') == 'HIA-emitted-static-ELF-observer-v2':
                            image = request['image']
                            local_prefix = manifest['source_directory'] + '/'
                            if image.startswith(local_prefix):
                                image_bytes = files[image[len(local_prefix):]]['bytes']
                            else:
                                image_bytes = z.getinfo(image.removeprefix('/home/runner/work/_temp/')).file_size
                            input_bytes = r['input_bytes']
                            frame_count += 1
                            frame_bytes += 56 + image_bytes + input_bytes
                            repeated_sha_bytes += (2 if r.get('status') == 'returned' else 1) * (image_bytes + input_bytes)
                            if r.get('status') == 'returned':
                                workspace_slice_bytes += request['workspace_size']
                    choices = old_index[family].get(key(r), {})
                    if len(choices) == 1:
                        a = next(iter(choices.values()))
                        item['old'] = a
                        checked = ('input_bytes', 'input_sha256', 'image_sha256', 'artifact_sha256',
                                   'status', 'format', 'transport', 'runner_sha256', 'result_u64',
                                   'core_u32', 'output_sha256', 'source_unchanged', 'output_unchanged',
                                   'limits')
                        item['same_payload_outcome_binding'] = all(a.get(k) == r.get(k) for k in checked)
                        item['binding_differences'] = {k: {'v63': a.get(k), 'v64': r.get(k)}
                                                       for k in checked if a.get(k) != r.get(k)}
                        matched.append(item)
                    elif choices:
                        ambiguous.append({'phase': name, 'member': member, 'case': r['case'],
                                          'v63_distinct_clock_variants': len(choices)})
                    else:
                        missing.append({'phase': name, 'member': member, 'case': r['case'], 'identity_key': key(r)})
                    rows.append(item)
                elif member.endswith('.command.json'):
                    r = read(member)
                    if 'wall_elapsed_ns' in r:
                        command_rows.append(r)
                elif member.endswith('/owner.json'):
                    r = read(member)
                    begin = next(e['monotonic_ns'] for e in r['events'] if e['kind'] == 'qualification_started')
                    end = next(e['monotonic_ns'] for e in r['events'] if e['kind'] == 'qualification_exit_observed')
                    owner_rows.append({'member': member, 'observed_interval_ns': end - begin,
                                       'start_to_cleanup_end_ns': r['cleanup']['started_ns'] + r['cleanup']['elapsed_ns'] - begin})
        report = json.loads(z.read(P + 'phase-' + name + '.json'))
        ps = {'phase': name, 'family': family, 'label': label,
              'phase_wall_ns': phase['wall_ns'], 'v63_phase_wall_ns': phase['v63_wall_ns'],
              'phase_body_ns': report['elapsed_ns'],
              'setup_report_exit_envelope_ns': phase['wall_ns'] - report['elapsed_ns'],
              'new_all_retained_native_receipts': stats(rows),
              'matched_receipts': len(matched), 'matched_v63': stats(matched, 'old'),
              'matched_v64': stats(matched),
              'matching_payload_outcome_bindings': all(r['same_payload_outcome_binding'] for r in matched),
              'native_command_count': len(command_rows),
              'native_command_wall_ns': sum(r['wall_elapsed_ns'] for r in command_rows),
              'cli_owner_count': len(owner_rows),
              'cli_owner_window_ns': sum(r['start_to_cleanup_end_ns'] for r in owner_rows),
              'selected_json_members': len(selected),
              'selected_json_bytes': sum(files[n]['bytes'] for n in selected),
              'pure_redundancy': {'discarded_frame_calls': frame_count,
                                  'discarded_frame_payload_bytes': frame_bytes,
                                  'repeated_sha_same_input_bytes': repeated_sha_bytes,
                                  'workspace_header_only_copy_bytes': workspace_slice_bytes}}
        ps['body_outside_selected_clocks_ns'] = (ps['phase_body_ns']
            - ps['new_all_retained_native_receipts']['wall_ns']
            - ps['native_command_wall_ns'] - ps['cli_owner_window_ns'])
        phases.append(ps)
        ledger.extend(rows)
        match_ledger.extend(matched)

    new_seed = json.loads(z.read(P + 'B0.receipt.json'))
    old_seed = old_report['seed']
    seed_bindings = {}
    for field in ('artifact_sha256', 'source_sha256', 'core_sha256', 'object_sha256',
                  'machine_text_sha256', 'toolchain', 'build_host', 'python'):
        seed_bindings[field] = {'v63': old_seed.get(field), 'v64': new_seed.get(field),
                                'equal': old_seed.get(field) == new_seed.get(field)}
    references = []
    for old_row in old_report['qualification_scheduling']['reference_processes']:
        family = old_row['family']
        new_row = json.loads(z.read(P + 'reference-' + family + '.worker.json'))
        references.append({'family': family, 'v63_wall_ns': old_row['wall_elapsed_ns'],
                           'v64_wall_ns': new_row['wall_elapsed_ns'],
                           'same_reference_sha256': old_row['reference_sha256'] == new_row['reference_sha256']})

families = []
for family in FIELDS:
    rows = [r for r in match_ledger if r['phase'].rsplit('-', 1)[0] == family]
    p = [r for r in phases if r['family'] == family]
    families.append({'family': family, 'matched': len(rows),
                     'v63': stats(rows, 'old'), 'v64': stats(rows),
                     'v63_two_worker_phase_sum_ns': sum(r['v63_phase_wall_ns'] for r in p),
                     'v64_two_worker_phase_sum_ns': sum(r['phase_wall_ns'] for r in p),
                     'v64_commands_ns': sum(r['native_command_wall_ns'] for r in p),
                     'v64_cli_owner_window_ns': sum(r['cli_owner_window_ns'] for r in p),
                     'v64_body_outside_selected_clocks_ns': sum(r['body_outside_selected_clocks_ns'] for r in p)})

frontiers = []
for previous, following in zip(list(FIELDS), list(FIELDS)[1:]):
    prior = max(r['completed_ns'] for r in BASE['phase_records'] if r['phase'].rsplit('-', 1)[0] == previous)
    later = min(r['started_ns'] for r in BASE['phase_records'] if r['phase'].rsplit('-', 1)[0] == following)
    frontiers.append({'after': previous, 'before': following, 'v64_envelope_ns': later - prior})

result = {
    'schema': 'hepta.hia.v64-v63-independent-receipt-clock-comparison.v1',
    'scope': 'Read original JSON receipts only; no tests, compiler invocation, or production changes.',
    'v64_artifact_sha256': BASE['input_before']['artifact']['sha256'],
    'v63_nested_report_sha256': digest(raw),
    'v63_original_reports_archive_sha256': digest(OLD.read_bytes()),
    'old_report_index': old_index_stats,
    'v64_total': stats(ledger),
    'matched_total_v63': stats(match_ledger, 'old'),
    'matched_total_v64': stats(match_ledger),
    'missing_v63_match': missing, 'ambiguous_v63_match': ambiguous,
    'all_matched_payload_outcome_bindings_equal': all(r['same_payload_outcome_binding'] for r in match_ledger),
    'binding_differences': [{'phase': r['phase'], 'member': r['member'], 'differences': r['binding_differences']}
                            for r in match_ledger if not r['same_payload_outcome_binding']],
    'families': families, 'phases': phases, 'reference_workers': references,
    'seed_bindings': seed_bindings,
    'phase_frontier_envelopes': frontiers,
    'pure_redundancy_current_source_counts': {k: sum(p['pure_redundancy'][k] for p in phases)
                                              for k in phases[0]['pure_redundancy']},
    'limitations': [
        'Native elapsed values are native-entry wall clocks, not CPU-time samples.',
        'Per-call wall minus native includes execution setup, transport/I/O/capture and scheduling; it is not an independently measured process-startup time.',
        'Per-call wall excludes initial frame construction and some request hashes/writes and final validation/receipt writes.',
        'Worker sums are concurrent totals and cannot be subtracted directly from cold elapsed time.',
        'Inter-phase frontier gaps combine validation, source readback, serialization, archive sealing, and scheduling; archive-only clocks were not recorded.',
        'Old nested observations contain repeated references to cached build receipts; these are indexed by payload identity and deduplicated only when their clock/outcome tuple agrees. Ambiguous old identities are excluded from paired totals.',
        'Current partial names receipts are not included in complete-phase paired timing totals.',
        'Logical bytes attributed to redundant immutable operations are exact countable byte extents, not a measured speedup or memory-bandwidth measurement.',
    ],
}
write('receipt-comparison.json', result)
for name, data in [('matched-native-receipts.jsonl.gz', ledger),
                   ('selected-inner-json-ledger.jsonl.gz', json_ledger)]:
    with (OUT / name).open('wb') as raw_out:
        with gzip.GzipFile(fileobj=raw_out, mode='wb', filename='', mtime=0) as f:
            for r in data:
                f.write(json.dumps(r, sort_keys=True, separators=(',', ':')).encode() + b'\n')
print(json.dumps({k: result[k] for k in ['v64_total', 'matched_total_v63', 'matched_total_v64',
                                        'all_matched_payload_outcome_bindings_equal',
                                        'pure_redundancy_current_source_counts']}, indent=2))
print('unmatched', len(missing), 'ambiguous', len(ambiguous), 'binding_differences', len(result['binding_differences']))
