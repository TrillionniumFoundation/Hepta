# Stage 4: actual native private-lease prefix and corrected test custody

This is development evidence. It is not complete composite normalization, default native selection, current-source cold qualification or removal authority for any retained owner.

## Source and compiled images

The original three production codec files remain at `checkpoints/source-r2/source.json` SHA-256 `f808352953941987fb780b9cfaf85182cdf14066ddf33abfa8b2e52eeefd3de4`. The codec image remains `c76f69b4e13fa2c18ebdbc60c7da01f8ebf68b19bd810fec3b0449bc5db418c6`, from source `86a60e42282449396bd7fffac3db6a493529e798474eb13c34c2224e686ea893`.

The integer decoder remains the original source `151f00a9645fea753aff528cedf79ee1c761afae82c3ed1a13e463cc914053a9` and image `821987a48d99c767d348cb568433a747e3bc0143c24f5f1414e6f47d6cc85565`. A future shared JSON reason ABI or main-source update requires matching recompilation and replay; these images must not be relabelled as that future revision.

The three new private-lease prefix files are frozen in `checkpoints/lease-source-r1/source.json`, SHA-256 `fbf8b3455136152756ea9d5c29aea017e3c3b341904f6e51b289d48ffd83d1cd`. The HIA packer has 4 functions, 30 blocks and 418 instructions. Its 20,383-byte source SHA-256 is `419290091a2809b0bc4de9d79c8986e198b6c4c946b3271edff87c5eb89dd228`; its actual 21,669-byte flat image is `6592bd6fe223843873db38224e6066aa3aba2962c8cec7527baf5b33fcc2cd1b`.

`development/compile-lease-r1/` preserves the real B3 input, request, receipt, stdout/stderr and image. It used the unchanged 10 CPU second, 20 wall second, 256 MiB address, 8 MiB stack and 1 MiB output/workspace compile limits. The compiler remains f50 B3 `0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8`.

## Independent test-loader findings and revisions

Independent review found two concrete faults in the development test loader. Neither is a semantic counterexample for the correctly source-bound codec image.

1. Harness r1 separately checked each row's source against its own manifest and the current codec source against a separate bundle hash. It did not require the codec row to be the current codec or check the per-component schema. An internally consistent decoder row could therefore be mapped in the codec position. Harness r2 validates both current component source byte strings, component schemas and image hashes before either mapping or evidence-directory creation.
2. Harness r2 validated immutable image bytes A, then used a second disk read to label its recorded pin. A replacement B between those reads could make before/after custody describe B while the mapped code was A. Harness r3 records pins from the same immutable bytes that passed validation and will be mapped, rejects inconsistent repeated-path reads, and reads all original pins back before mapping or creating evidence. Later readback confirms or rejects the original identity; it never replaces it.

Exact original harnesses are retained in `checkpoints/harness-r1`, `harness-r2`, and `harness-r3`. Harness r1 is byte-for-byte the test member in the immutable stage3 archive. Their hashes are respectively `58a1863c6be4fade087a9ec1d63f7492e6324ac2d10b25d03b49e9d5faf1aeb3`, `5e7e4b667b8b0066e4d3b54dfee32a8dc5ab5734d8a059d993c1fe8636d0a482`, and `5f0591cb2bf68bc82766bc6bafe092eb52a5d3a48556f2a0f6793786c08d0c4e`.

All three original runs remain: 11 tests in r1, 13 in r2 and 14 in r3. Each ran the same 233 actual decoder and 281 actual codec entries. The added gates are source-admission controls. The r3 run passed all 14 tests in 5.816893 seconds with no failure, error, skip, expected failure or unexpected success and unchanged source/image readback. This timing is an observation, not a performance claim. The independent review's separate raw counterexamples and four small actual-image controls are retained by the independent reviewer; they are not recast as our own tests.

## Actual native executable evidence

`development/lease-run-r1/` contains the six exact selected/executed tests, complete logs, all generated ELF variants, native child ledger and source/image custody. All six tests passed in 3.236258 seconds, maximum parent RSS 63,432 KiB, with no failures, errors or skipped outcomes. The actual HIA packer was called 17 times: three complete executables and fourteen refused malformed length/capacity controls, with input, unused workspace and output canaries checked.

There were 76 actual native child processes: 71 source-bound executable controls and five explicitly private modified-ELF controls. Among the source-bound controls, 53 produced exact packets, 14 refused source or integer-policy input, three refused byte/node/depth overflow and one refused extra command arguments. The 759-byte fixed syscall entry plus exact decoder and codec images were written by HIA; each complete ELF is 225,422 bytes.

The tests compare entire packet bytes, not only hashes. They cover generic integer/string/bool/null/list/map values, ordered Unicode keys, `-0`, large signed/unsigned integers, deterministic nested packets, explicit zero/640/4300 conversion policies, the full 8 MiB wire and 262,144-node and depth-64 public limits and each first value beyond those limits. Later invalid syntax and duplicate keys still refuse in the decoder before an earlier oversized integer can be converted.

Each child runs the static ELF directly with no Python interpreter entrypoint, an empty PATH, an invalid Python module path and invalid optional HIA manifest environment values. There is no runtime arena-input or manifest argument. The entry itself calls the decoder, retains the returned actual arena extent and same wire, and makes both private mappings read-only before the packet codec.

The five private modified-ELF controls have their own files and ledger scope. Direct codec writes to the raw wire and arena each terminate with SIGSEGV; the same instruction class can write the mutable output and returns the expected deliberately invalid extent. A deliberate codec UD2 is reached by valid JSON and is not reached after invalid JSON, proving the actual decoder precedes the actual codec call. These intentionally corrupted machine images are negative controls, not production artifacts or a sandbox claim.

The native child ledger is 122,757 bytes, SHA-256 `169c93170a066e476143954b7a6263e6588da40768270fd9455e870acac6a6d7`. Raw wires and stdout up to 64 KiB are embedded; larger deterministic boundary inputs were compared byte-for-byte in memory and retain their exact hashes and checked source constructors. Full large stdout bytes are not claimed to be archived.

## Remaining work

This prefix preserves the issued arena association and removes Python from this representation path. It does not sort the public canonical snapshot, execute any composite semantic owner, replace the typed-service continuation bridge, spool complete generated Core, run final primitive admission, install a production public driver or change default selection. Those boundaries remain explicitly open. The stage3 private-unissued `[1]` arena with `[2]` wire example still demonstrates the standalone codec's limited authentication scope; the new executable closes that association by actual private issuance and direct calls rather than by changing that codec claim.
