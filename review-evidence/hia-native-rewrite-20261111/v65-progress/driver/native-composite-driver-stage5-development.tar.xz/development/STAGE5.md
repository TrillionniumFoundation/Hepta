# Stage 5: bounded typed-packet JSON and offset index

This is a complete generic representation component for the existing source/typed-service packet ABI. It does not activate default native selection, execute the complete eleven-owner pipeline, grant current cold qualification or remove a retained owner. Complete generated Core remains outside this component's 64 MiB input-packet boundary.

## Source and actual compile

The three production files are frozen in `checkpoints/packet-json-source-r1/source.json`, SHA-256 `7ba7b043c8f73eb24796c996bd2200e451c6b5dd7e9de81e4d0fcca798de738c`: `docs/HIA_COMPOSITE_PACKET_JSON.md`, `tools/generate_hia_composite_packet_json.py`, and `examples/hia_bootstrap/composite_packet_json.hiaasm`.

The 61,863-byte HIA source is `f8eae991a3eace420257baa94d52cfdb1968c944cd3a2c74c6be904494772d47`: 22 functions, 243 blocks, 1,012 instructions, maximum 38 blocks per function and nine block parameters. The 91,907-byte actual image is `3aabcf2df942109755dd6d2750274b702242fb7b2802e413a92e1d7bbab7f7d5`.

`development/compile-packet-json-r1/` preserves actual input/request/receipt/logs/image. The compiler is f50 B3 `0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8`. Compilation passed unchanged 10 CPU/20 wall-second, 256 MiB address, 8 MiB stack and 1 MiB output/workspace limits. No compiler operation, entry profile or language quota changed.

## Complete component and bounds

The HIA image validates one complete existing typed packet: null/bool/canonical arbitrary decimal/strict UTF-8/list/map, every nested extent and child count, string keys and parent-scoped key uniqueness. It indexes every node-header offset, including keys and containers, then emits exact ordered compact integer JSON. Full validation precedes output-capacity refusal. Failed invocations grant neither output nor partial-index authority and cannot revive without fresh control.

The bitmap and packet belong to one immutable private lease. Shape/extent checks do not authenticate substituted bytes. Typed packets and object-token streams remain different ABIs and require distinct owner/channel correlation in the final driver.

The input bound is the existing 64 MiB source/service packet ABI. Workspace derives from `floor(L/32)` keys, `ceil(L/8)` bitmap bytes and `floor(L/24)+1` traversal frames, totalling exactly 164,976,096 bytes at the maximum. There is no new depth limit. This bound is not an aggregate generated-Core gate.

## Actual evidence

The four-entry smoke remains in `development/packet-json-smoke-r1/` and its log. Its exact test source was reconstructed by reversing only the later two large-output assertion-display edits, then checking the recorded SHA `336340343f757c022e73528926c50b22deec1e1ca4d01bd4ae2ac6be69398f5b`; it is retained in `checkpoints/packet-json-smoke-test-r1`. Production sources/images did not change.

The complete `development/packet-json-run-r1/` run selected/executed all seven tests: PASS, zero failures/errors/skips/expected failures/unexpected successes, 17.207643 seconds, maximum RSS 452,392 KiB. This is an observation, not a performance or cold claim. The test harness alone used 1 GiB address/90 CPU-second supervision to exercise the existing ABI; compiler/language quotas stayed unchanged.

There were 229 actual image entries: 171 accepts, three capacity refusals after complete validation, and 55 malformed/control/profile refusals. Source/image pins, input bytes and both output/workspace canaries remained exact.

Tests cover all scalar/container kinds; integer magnitude/sign; controls and Unicode edges; deterministic trees; every bitmap bit against the original detached decoder; hash collisions and repeated keys in different parents; invalid UTF-8/surrogates; noncanonical decimals; malformed counts/extents; duplicate/non-string keys; truncated/multiple roots; real source lengths and output/workspace capacities; bad controls and repeated refusal. A late malformed node takes precedence over a small output buffer.

The full 64 MiB packet was actually accepted and its entire JSON/bitmap compared; the first byte beyond the ABI was refused. A full 64 MiB NUL-string packet was fully validated and charged exactly 402,653,090 JSON bytes before capacity refusal. A private valid 4,096-level packet passed, showing no new transport recursion ceiling; public JSON depth remains 64.

An actual stage4 HIA-packed ELF produced a packet forwarded directly as bytes into this actual image while host JSON decoding, transport and detached materialization were disabled. The forwarder is Python test custody: this is component interoperability, not a claim that the complete driver is already native.

The 329,397-byte entry ledger SHA is `c0742c76257b8f6a76928a3b9c6c3e843283ff3156a09e514b6ff217ecf5ab48`. Raw data/indexes up to 64 KiB are embedded. Larger deterministic data was compared in memory and retains exact hashes plus checked constructors; complete 64 MiB arrays are not claimed to be archived.

## Next boundary

Native object-token continuation must preserve kinds, issued source/session/sequence references, arity/key/UTF-8 refusal, permanent poison and streaming complete Core without a new aggregate quota. Typed requests must route to existing HIA type/helper owners. The public raw path still needs original-source integer conversion before canonical sorting, the complete eleven-owner sequence and all late Core gates.
