"""Explicit development compilation; keeps original B3 subprocess limits."""
from pathlib import Path
import hashlib
import json
import sys
import time
import traceback

ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta')
OVERLAY = Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
COMPILER = Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin')
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_selfhost import compile_stage

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

expected = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
assert sha(COMPILER) == expected
directory = OVERLAY / 'development' / 'compile-r1'
directory.mkdir(parents=True, exist_ok=False)
specs = (
    ('composite-json-packet', OVERLAY / 'checkpoints/source-r1/examples/hia_bootstrap/composite_json_packet.hiaasm',
     'hepta.hia.composite-json-packet-native.v1'),
    ('json-decode', ROOT / 'examples/hia_bootstrap/json_decode.hiaasm', 'hepta.hia.json-decode-native.v1'),
)
results = []
started = time.monotonic()
for label, source, schema in specs:
    before = source.read_bytes()
    source_sha = hashlib.sha256(before).hexdigest()
    print('START', label, len(before), source_sha, flush=True)
    try:
        image, receipt = compile_stage(directory, label, COMPILER, before)
        assert source.read_bytes() == before and sha(COMPILER) == expected
        manifest = {'schema': schema, 'source_sha256': source_sha, 'image_path': image.name,
                    'image_sha256': sha(image), 'compiler_sha256': expected}
        path = directory / (label + '.manifest.json')
        path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
        row = {'label': label, 'status': 'PASS', 'manifest': str(path), 'source': str(source),
               'source_sha256': source_sha, 'image_sha256': sha(image), 'bytes': image.stat().st_size,
               'actual_limits': receipt['limits'], 'receipt': receipt}
    except BaseException as error:
        traceback.print_exc()
        row = {'label': label, 'status': 'FAIL', 'source': str(source), 'source_sha256': source_sha,
               'class': type(error).__name__, 'error': str(error)}
    results.append(row)
    print('RESULT', json.dumps({k: v for k, v in row.items() if k != 'receipt'}), flush=True)
report = {'scope': 'DEVELOPMENT_ONLY_NOT_COLD_QUALIFIED', 'compiler_sha256': expected,
          'base_commit': '31d81594997cfb6cce5ab62ea5aaba3bb7757af1',
          'wall_seconds': time.monotonic() - started, 'results': results}
(directory / 'summary.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
raise SystemExit(0 if all(row['status'] == 'PASS' for row in results) else 1)

