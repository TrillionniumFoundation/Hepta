# Stage 3: actual JSON arena codec differential

This is a completed development codec slice, not the complete composite driver,
a native authoring toolchain, an installed no-Python application, or a cold
qualification.

The frozen source is source-r2: generator SHA-256
7f9ce669cf117b78aca9f8177e1139d289c7082ff7efb0454bb413f2142d447a,
HIA SHA-256 86a60e42282449396bd7fffac3db6a493529e798474eb13c34c2224e686ea893.
Actual B3-produced image: 106098 bytes, SHA-256
c76f69b4e13fa2c18ebdbc60c7da01f8ebf68b19bd810fec3b0449bc5db418c6.
The separate actual integer-JSON decoder image is 118565 bytes, SHA-256
821987a48d99c767d348cb568433a747e3bc0143c24f5f1414e6f47d6cc85565,
from source 151f00a9645fea753aff528cedf79ee1c761afae82c3ed1a13e463cc914053a9.
Both compile receipts retain the original 10-second CPU, 20-second wall,
256-MiB address, 1-MiB output/workspace and 8-MiB stack profile.

## Executed results

The exact initial complete test module ran **11 tests, zero failures, errors,
skips, expected failures or unexpected successes**. All chosen IDs executed
in order. It made **233 actual decoder calls and 281 actual codec calls**.
Of those codec calls, 213 produced packets, eight returned the selected
integer digit-limit refusal, and sixty returned arena/control/extent refusal.
Every observed read-only input and all three canaries remained unchanged.

The 213 successful packets include **one deliberately unissued private pair**:
the arena created from [1] was paired with the same-length wire [2], and the
codec produced [2]. This is retained as an explicit non-authentication witness.
The arena format has no source-content hash; header/extent validation alone
does not prove decoder issuance. It is not a public pipeline acceptance claim.
All other successful test calls use their actual decoder-created arena/wire
pair. The current harness passes that pair mechanically, but a future native
driver still must own a non-substitutable lease end to end.

Exact-byte equality to the existing typed transport covers scalar kinds,
arbitrary integer magnitudes, negative zero, UTF-8 boundaries, control strings,
dictionary order, subtree extents, source-offset maps, 160 deterministic random
trees, eleven real nominal canonical inputs and all four profile envelopes.
The codec does not perform nominal semantic admission; the profile-envelope
cases are representation tests, not four new language-qualification results.

The native path ran with Python JSON value decoding, foreign arena
materialization, old transport and detached-packet reconstruction forbidden.
The original actual integer decoder independently refused floats, malformed
Unicode, duplicate decoded keys and over-depth input before codec entry.
Conversion checks cover disabled digit limits, 640/4300 thresholds, both signs,
16,384-digit values and the first oversized integer in actual traversal order.
The maximum public node count (262144), exact 8-MiB wire, one-above refusals,
and a 64-key deliberate hash probe chain also ran. The larger generic decoder
maximum of 1048576 nodes is statically bounded; it was not a second large test.

Run time was 7.377 seconds and observed peak RSS 158076 KiB on Python 3.12.14.
These are test-run observations, not a performance or cold-pass claim.
All source, manifest and image before/after hashes match.

The compressed ledger is 258112 bytes with SHA-256
b715adcc8b0ed97ec64d3e531aa8ac6411bc042d0283a823060fe6b1bb9ecfd3.
It embeds exact wire/arena/packet bytes up to 64 KiB. Larger deterministic
boundaries retain exact byte hashes, lengths and the checked-in constructors;
their full equality was asserted in memory. No full raw large-case-byte archive
is claimed.

## Preserved failures and corrections

- Initial authoring used unsupported FloorDiv; changing shift//8 to shift>>3
  preserved semantics. Original authoring source and failure remain.
- The first actual compile rejected external readbuf/readbuf/mutbuf f0 with
  native compiler error 5. The later HIA borrow.read/call/loan.end wrapper
  preserves the required external readbuf/mutbuf/mutbuf profile.
- The initial smoke test used a four-byte ASCII backslash-x-a-5 literal instead
  of the intended canary byte. The first null packet and both read-only inputs
  were already equal; the assertion failed only on that test expectation.
  The exact script/log remain. A corrected standalone smoke passed ten
  actual decoder+codec cases without any production source change.
- The first formal test authoring parse rejected a non-ASCII bytes literal.
  Its source and SyntaxError record remain. The test now encodes Unicode text.
  This was not a native semantic failure.

Next work is the native source-lease pipeline and generic token/continuation
representation. The existing eleven semantic kernels, final quota order,
large-Core streaming and public cleanup remain unchanged.

