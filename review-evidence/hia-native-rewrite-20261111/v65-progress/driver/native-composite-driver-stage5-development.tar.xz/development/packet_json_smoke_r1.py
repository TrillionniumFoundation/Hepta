from pathlib import Path
import importlib.util,sys,json,hashlib
b=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
sys.path.insert(0,'/workspace/scratch/9acdfa9f5639/Hepta')
p=b/'tests/test_hia_composite_packet_json.py'
spec=importlib.util.spec_from_file_location('packet_json_smoke',p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
n=m.ActualPacketJson(b/'development/packet-json-smoke-r1')
try:
 for i,value in enumerate((None,{'z':-10,'a':[True,'é😀\u0000',None]},[],{'é':{'é':1}})):
  raw=m.transport(value);out=n.encode('smoke-%d'%i,raw)
  expected=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
  assert out[2]==expected,(i,out[:3])
  print(json.dumps({'case':i,'result':out[0],'header':out[1],'exact':True}),flush=True)
finally:n.close()
