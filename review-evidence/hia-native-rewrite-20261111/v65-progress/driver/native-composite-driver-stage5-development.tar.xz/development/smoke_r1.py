"""Actual-image smoke for the first codec; standalone development evidence."""
from pathlib import Path
import ctypes
import hashlib
import json
import struct
import sys
import traceback
ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta')
BASE = Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
sys.path.insert(0, str(ROOT))
from hepta.hia_json_decode_native import NativeJsonDecoder
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_instruction_policy_native import transport

def image(folder, label, cls):
    manifest=json.loads((folder/(label+'.manifest.json')).read_bytes())
    return cls((folder/manifest['image_path']).read_bytes(),manifest['image_sha256'])
decoder=image(BASE/'development/compile-r1','json-decode',NativeJsonDecoder)
codec=image(BASE/'development/compile-r2','composite-json-packet',NativeHiaJsonImage)
MAGIC=int.from_bytes(b'HIAJPK01','little')
rows=[]
sources=[b'null',b'false',b'true',b'0',b'-0',b'-17',b'[]',b'{}',
         b'{"z":1,"a":[true,null,{"x":"\\uD834\\uDD1E"}],"empty":""}',
         '{"多":"字\\u0000\\n","emoji":"😀","last":-12345}'.encode()]
for wire in sources:
    arena=decoder.arena(wire,max_nodes=262144,max_depth=64)
    n,=struct.unpack_from('<Q',arena,8);slots=2
    while slots<2*n:slots*=2
    size=64+49*n+len(wire)+8*slots
    a=ctypes.create_string_buffer(arena+b'ARENA!!!');s=ctypes.create_string_buffer(wire+b'WIRE!!!!')
    out=ctypes.create_string_buffer(size+16);ctypes.memset(out,0xA5,size+16)
    struct.pack_into('<8Q',out,0,MAGIC,sys.get_int_max_str_digits(),0,0,0,0,0,0)
    result=codec._entry(a,len(arena),s,len(wire),out,size)
    expected=transport(json.loads(wire))
    header=struct.unpack_from('<8Q',out)
    actual=bytes(out[64:result]) if 64<=result<=size else b''
    row={'wire':wire.hex(),'result':result,'header':header,'packet_equal':actual==expected,
         'readonly_arena':ctypes.string_at(a,len(arena))==arena,
         'readonly_wire':ctypes.string_at(s,len(wire))==wire,
         'arena_canary':bytes(a[len(arena):len(arena)+8])==b'ARENA!!!',
         'wire_canary':bytes(s[len(wire):len(wire)+8])==b'WIRE!!!!',
         'output_canary':bytes(out[size:size+16])==b'\\xa5'*16,
         'actual_packet_hex':actual.hex(),'expected_packet_hex':expected.hex()}
    rows.append(row)
    assert all(row[k] for k in ('packet_equal','readonly_arena','readonly_wire','arena_canary','wire_canary','output_canary')),row
(BASE/'development/smoke-r1.json').write_text(json.dumps({'scope':'ACTUAL_CODEC_DEVELOPMENT_ONLY','cases':rows,'status':'PASS'},indent=2)+'\n')
print('PASS',len(rows),'actual decoder+codec cases')

