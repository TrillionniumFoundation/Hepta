"""Compile the private native decoder/codec lease ELF packer; original limits."""
from pathlib import Path
import hashlib
import json
import sys
import traceback
ROOT = Path('/workspace/scratch/9acdfa9f5639/Hepta')
OVERLAY = Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
COMPILER = Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin')
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_selfhost import compile_stage
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
assert sha(COMPILER) == expected
source = OVERLAY / 'checkpoints/lease-source-r1/examples/hia_bootstrap/composite_json_lease_cli_packer.hiaasm'
before = source.read_bytes()
directory = OVERLAY / 'development/compile-lease-r1'
directory.mkdir(parents=True, exist_ok=False)
try:
    image, receipt = compile_stage(directory, 'composite-json-lease-packer', COMPILER, before)
    assert source.read_bytes() == before and sha(COMPILER) == expected
    manifest = {'schema': 'hepta.hia.composite-json-lease-packer-native.v1',
                'source_sha256': hashlib.sha256(before).hexdigest(), 'image_path': image.name,
                'image_sha256': sha(image), 'compiler_sha256': expected}
    (directory / 'composite-json-lease-packer.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
    result = {'scope': 'DEVELOPMENT_ONLY_NOT_COLD_QUALIFIED', 'status':'PASS',
              'source': str(source), 'manifest': manifest, 'receipt': receipt}
except BaseException as error:
    traceback.print_exc()
    result = {'scope': 'DEVELOPMENT_ONLY_NOT_COLD_QUALIFIED', 'status':'FAIL',
              'source': str(source), 'source_sha256': hashlib.sha256(before).hexdigest(),
              'class':type(error).__name__, 'error':str(error)}
(directory / 'summary.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)

