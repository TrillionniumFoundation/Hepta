"""Post-review harness r3: freeze verified bytes and reject source/image readback drift."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import platform
import resource
import sys
import time
import unittest

BASE = Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
REPO = Path('/workspace/scratch/9acdfa9f5639/Hepta')
RUN = BASE / 'development' / 'test-run-r3'
RUN.mkdir(parents=True, exist_ok=False)
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_AS, (768 << 20, 768 << 20))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
sys.path.insert(0, str(REPO))
os.environ['HEPTA_HIA_JSON_PACKET_DEVELOPMENT_BUNDLE'] = str(BASE/'development/bundle-r2.json')
os.environ['HEPTA_HIA_JSON_PACKET_EVIDENCE'] = str(RUN/'actual')
paths = [BASE/'docs/HIA_COMPOSITE_DRIVER_NATIVE_DESIGN.md',
         BASE/'tools/generate_hia_composite_json_packet.py',
         BASE/'examples/hia_bootstrap/composite_json_packet.hiaasm',
         BASE/'tests/test_hia_composite_json_packet.py',
         BASE/'development/bundle-r2.json',
         REPO/'hepta/hia_json_decode_native.py',
         REPO/'hepta/hia_instruction_policy_native.py',
         REPO/'hepta/hia_composite_function_tokens.py']
before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
(RUN/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
spec = importlib.util.spec_from_file_location('test_hia_composite_json_packet', paths[3])
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item
chosen = [test.id() for test in flatten(suite)]
executed = []
class Result(unittest.TextTestResult):
    def startTest(self,test):
        executed.append(test.id())
        super().startTest(test)
started = time.monotonic()
result = unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
after = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
report = {'scope':'ACTUAL_JSON_ARENA_CODEC_DEVELOPMENT_ONLY_NOT_COMPLETE_DRIVER_OR_COLD',
          'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
          'wall_seconds':time.monotonic()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          'chosen_ids':chosen,'executed_ids':executed,'tests_run':result.testsRun,
          'failures':[{'test':t.id(),'trace':s} for t,s in result.failures],
          'errors':[{'test':t.id(),'trace':s} for t,s in result.errors],
          'skipped':[{'test':t.id(),'reason':s} for t,s in result.skipped],
          'expected_failures':[{'test':t.id(),'trace':s} for t,s in result.expectedFailures],
          'unexpected_successes':[t.id() for t in result.unexpectedSuccesses],
          'source_before':before,'source_after':after}
passed = (result.wasSuccessful() and not result.skipped and not result.expectedFailures
          and not result.unexpectedSuccesses and chosen==executed and result.testsRun==len(chosen)
          and before==after)
report['status']='PASS' if passed else 'FAIL_OR_INCOMPLETE'
(RUN/'result.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:report[k] for k in ('status','tests_run','wall_seconds','max_rss_kib')}),flush=True)
raise SystemExit(0 if passed else 1)

