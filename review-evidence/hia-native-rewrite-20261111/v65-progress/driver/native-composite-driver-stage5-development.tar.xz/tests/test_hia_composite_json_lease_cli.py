"""Actual HIA-packed native prefix tests; Python is only build/oracle custody."""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import random
import resource
import signal
import struct
import subprocess
import sys
import unittest

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_decode_native import SOURCE as DECODER_SOURCE
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT = Path(__file__).resolve().parents[1]
GENERATOR = ROOT / 'tools/generate_hia_composite_json_lease_cli.py'
SOURCE = ROOT / 'examples/hia_bootstrap/composite_json_lease_cli_packer.hiaasm'
CODEC_SOURCE = ROOT / 'examples/hia_bootstrap/composite_json_packet.hiaasm'
BAD = 0xffffffff
SPACE = 0xfffffffe
CANARY = bytes([0xa5]) * 32
COMPILER_SHA = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'


def authoring():
    spec = importlib.util.spec_from_file_location('lease_cli_authoring', GENERATOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def child_limits():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_AS, (128 << 20, 128 << 20))
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))


class LeaseHarness:
    def __init__(self, evidence):
        self.module = authoring()
        self.evidence = Path(evidence)
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            digest = sha256(raw).hexdigest()
            key = str(path)
            if key in self.pins and self.pins[key] != digest:
                raise AssertionError('lease build inputs changed during admission')
            self.pins[key] = digest
            return raw
        rows = (
            ('decoder', ROOT / 'development/compile-r1/json-decode.manifest.json',
             DECODER_SOURCE, 'hepta.hia.json-decode-native.v1'),
            ('codec', ROOT / 'development/compile-r2/composite-json-packet.manifest.json',
             CODEC_SOURCE, 'hepta.hia.composite-json-packet-native.v1'),
            ('packer', ROOT / 'development/compile-lease-r1/composite-json-lease-packer.manifest.json',
             SOURCE, 'hepta.hia.composite-json-lease-packer-native.v1'),
        )
        self.images = {}
        for name, manifest_path, source_path, schema in rows:
            manifest = json.loads(read(manifest_path))
            source_bytes = read(source_path)
            if (manifest['schema'] != schema or manifest['compiler_sha256'] != COMPILER_SHA
                    or manifest['source_sha256'] != sha256(source_bytes).hexdigest()):
                raise AssertionError('lease component source identity mismatch: '+name)
            image = read(manifest_path.parent / manifest['image_path'])
            if not 0 < len(image) <= self.module.IMAGE_LIMIT or sha256(image).hexdigest() != manifest['image_sha256']:
                raise AssertionError('lease component image identity mismatch: '+name)
            self.images[name] = image
        read(GENERATOR)
        read(__file__)
        if any(sha256(Path(path).read_bytes()).hexdigest() != digest
               for path, digest in self.pins.items()):
            raise AssertionError('lease build readback mismatch')
        self.evidence.mkdir(parents=True, exist_ok=False)
        self.packer = NativeHiaJsonImage(self.images['packer'], sha256(self.images['packer']).hexdigest())
        self.packer_entries = 0
        self.child_entries = 0
        self.rows = []
        self.log = (self.evidence / 'actual-lease-ledger.jsonl').open('w')
        self.executables = {}

    def pack(self, payload, capacity=None):
        capacity = self.module.BUNDLE_LIMIT if capacity is None else capacity
        source = ctypes.create_string_buffer(payload + CANARY)
        output = ctypes.create_string_buffer(capacity + len(CANARY))
        workspace = ctypes.create_string_buffer(128 + len(CANARY))
        ctypes.memset(output, 0xa5, capacity + len(CANARY))
        ctypes.memset(workspace, 0xa5, 128 + len(CANARY))
        result = self.packer._entry(source, len(payload), output, capacity, workspace, 128)
        self.packer_entries += 1
        if (bytes(source[:len(payload)+len(CANARY)]) != payload+CANARY
                or bytes(output[capacity:capacity+len(CANARY)]) != CANARY
                or bytes(workspace[:128+len(CANARY)]) != bytes([0xa5])*(128+len(CANARY))):
            raise AssertionError('packer source/workspace/canary mutation')
        data = bytes(output[:result]) if result <= capacity else None
        if data is None and bytes(output[:capacity]) != bytes([0xa5])*capacity:
            raise AssertionError('refused packer modified output')
        return result, data

    def executable(self, digits=4300):
        if digits in self.executables:
            return self.executables[digits]
        m = self.module
        payload = struct.pack('<4Q', m.MAGIC, len(self.images['decoder']), len(self.images['codec']), digits)
        payload += self.images['decoder'] + self.images['codec']
        result, actual = self.pack(payload)
        prefix, holes = m.template()
        expected = bytearray(prefix)
        struct.pack_into('<Q', expected, 96, len(prefix)+len(payload)-32)
        struct.pack_into('<Q', expected, 104, len(prefix)+len(payload)-32)
        struct.pack_into('<Q', expected, holes['digits'], digits)
        struct.pack_into('<I', expected, holes['decoder'], len(prefix)-holes['decoder']-4)
        struct.pack_into('<I', expected, holes['codec'], len(prefix)-holes['codec']-4+len(self.images['decoder']))
        expected += payload[32:]
        if result != len(expected) or actual != expected:
            raise AssertionError('actual HIA-packed ELF differs from exact envelope/image bytes')
        path = self.evidence / ('integer-json-packet-%d.elf' % digits)
        path.write_bytes(actual)
        path.chmod(0o700)
        self.pins[str(path)] = sha256(actual).hexdigest()
        self.executables[digits] = path
        return path

    def run(self, label, wire, *, digits=4300, executable=None, args=(), env=None):
        path = self.executable(digits) if executable is None else executable
        environment = {'PATH':'', 'PYTHONPATH':'/missing-python-runtime',
                       'HEPTA_HIA_JSON_DECODE_NATIVE':'/missing-decoder-manifest',
                       'HEPTA_HIA_COMPOSITE_TYPES_NATIVE':'/missing-types-manifest'}
        if env:
            environment.update(env)
        child = subprocess.run([str(path), *args], input=wire, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, cwd=self.evidence, env=environment,
                               timeout=20, preexec_fn=child_limits)
        self.child_entries += 1
        row = {'case':label, 'entry':self.child_entries, 'executable_sha256':sha256(path.read_bytes()).hexdigest(),
               'wire_bytes':len(wire), 'wire_sha256':sha256(wire).hexdigest(),
               'returncode':child.returncode, 'stdout_bytes':len(child.stdout),
               'stdout_sha256':sha256(child.stdout).hexdigest(),
               'stderr_base64':base64.b64encode(child.stderr).decode(),
               'scope':'PRIVATE_MODIFIED_ELF_CONTROL' if executable is not None else 'SOURCE_BOUND_NATIVE_PREFIX'}
        if len(wire) <= 65536:
            row['wire_base64'] = base64.b64encode(wire).decode()
        if len(child.stdout) <= 65536:
            row['stdout_base64'] = base64.b64encode(child.stdout).decode()
        self.rows.append(row)
        self.log.write(json.dumps(row, sort_keys=True)+'\n')
        self.log.flush()
        return child

    def close(self):
        self.log.close()
        after = {path:sha256(Path(path).read_bytes()).hexdigest() for path in self.pins}
        report = {'scope':'NATIVE_JSON_REPRESENTATION_PREFIX_NOT_COMPOSITE_OR_COLD',
                  'packer_entries':self.packer_entries, 'native_processes':self.child_entries,
                  'before':self.pins, 'after':after, 'source_images_unchanged':self.pins==after,
                  'large_case_storage':'Exact outputs compared in memory; raw values <=64KiB embedded, larger deterministic inputs retain checked constructors and byte hashes.'}
        (self.evidence/'custody.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        if self.pins != after:
            raise AssertionError('lease source/image/executable readback mismatch')


class JsonLeaseSourceTests(unittest.TestCase):
    def test_fixed_point_profile_layout_and_elf_permissions(self):
        m = authoring()
        document = m.document()
        self.assertEqual(SOURCE.read_bytes(), render_assembly(document).encode())
        self.assertEqual([p['type'] for p in document['functions'][0]['params']],
                         ['readbuf','mutbuf','mutbuf'])
        self.assertEqual((m.NODES,m.DEPTH,m.WIRE_LIMIT), (262144,64,8<<20))
        self.assertEqual(m.ARENA_BYTES, 23068736)
        self.assertEqual(m.PACKET_BYTES, 25428032)
        self.assertEqual(m.MAPPING_BYTES,61091840)
        self.assertEqual(m.ARENA_OFFSET % 4096,0)
        self.assertEqual(m.WORK_OFFSET % 4096,0)
        self.assertGreaterEqual(m.PACKET_OFFSET,m.WORK_OFFSET+m.WORK_BYTES)
        prefix,holes=m.template()
        self.assertEqual(set(holes),{'decoder','codec','digits'})
        self.assertEqual(struct.unpack_from('<I',prefix,64)[0],1)
        self.assertEqual(struct.unpack_from('<I',prefix,68)[0],5)
        self.assertEqual(struct.unpack_from('<II',prefix,120),(0x6474e551,6))
        self.assertEqual(struct.unpack_from('<H',prefix,56)[0],2)


class JsonLeaseNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=os.environ.get('HEPTA_HIA_JSON_LEASE_EVIDENCE')
        if not path:
            raise AssertionError('fresh explicit native lease evidence directory required; no skip')
        cls.native=LeaseHarness(path)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def exact(self,label,wire,expected=None,*,digits=4300):
        expected=json.loads(wire) if expected is None else expected
        packet=transport(expected)
        child=self.native.run(label,wire,digits=digits)
        self.assertEqual((child.returncode,child.stderr),(0,b''),label)
        self.assertEqual(child.stdout[64:],packet,label)
        magic,error,start,size,nodes,rawlen,reserved,policy=struct.unpack_from('<8Q',child.stdout)
        self.assertEqual((magic,error,start,size,rawlen,reserved,policy),
                         (self.native.module.PACKET_MAGIC,0,64,len(packet),len(wire),0,digits),label)
        self.assertGreaterEqual(nodes,1)
        self.assertEqual(len(child.stdout),64+len(packet))
        return child

    def refusal(self,label,wire,stage,code,*,digits=4300):
        child=self.native.run(label,wire,digits=digits)
        self.assertEqual(child.stdout,b'',label)
        self.assertEqual(child.returncode,3 if code==SPACE else 2,label)
        self.assertEqual(struct.unpack('<3Q',child.stderr),(self.native.module.ERROR_MAGIC,stage,code),label)

    def test_actual_packer_refuses_invalid_extents_before_writing(self):
        m=self.native.module
        good=struct.pack('<4Q',m.MAGIC,len(self.native.images['decoder']),len(self.native.images['codec']),4300)
        good+=self.native.images['decoder']+self.native.images['codec']
        controls=[b'',good[:31],struct.pack('<4Q',0,1,1,4300)+b'00',good[:-1],good+b'0']
        for value in (0,m.IMAGE_LIMIT+1,(1<<64)-1):
            altered=bytearray(good)
            struct.pack_into('<Q',altered,8,value)
            controls.append(bytes(altered))
            altered=bytearray(good)
            struct.pack_into('<Q',altered,16,value)
            controls.append(bytes(altered))
        for raw in controls:
            self.assertEqual(self.native.pack(raw),(BAD,None))
        expected=len(m.template()[0])+len(good)-32
        for size in (0,1,expected-1):
            self.assertEqual(self.native.pack(good,capacity=size),(SPACE,None))

    def test_no_python_runtime_exact_generic_packets(self):
        values=[None,False,True,0,-1,1<<129,'','é😀中\u0000',[],{},
                {'z':-10,'a':[True,None,{'😺':'x'}],'':[]},
                {'schema':'hepta.hia.program.composite.v1','module':'full_input','types':[],'functions':[]}]
        for index,value in enumerate(values):
            wire=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
            self.exact('ordinary-%d'%index,wire,value)
        for index,wire in enumerate((b'-0',b'{"\\u0062":1,"a":2}',b'"\\ud834\\udd1e"')):
            self.exact('lexeme-%d'%index,wire)
        rng=random.Random(0x4c45415345)
        for index in range(32):
            value={'z':[rng.getrandbits(129),bool(index&1),None], 'a':'é😀'*rng.randrange(8)}
            self.exact('seed-%02d'%index,json.dumps(value,ensure_ascii=False).encode(),value)
        child=self.native.run('extra-argument',b'0',args=('arena.bin',))
        self.assertEqual((child.returncode,child.stdout,child.stderr),(64,b'',b''))

    def test_original_integer_admission_precedes_conversion(self):
        for index,wire in enumerate((b'',b'1.0',b'1e2',b'NaN',b'Infinity',b'"\\ud800"',b'"\xff"',b'[1,]')):
            self.refusal('syntax-%d'%index,wire,1,BAD)
        self.refusal('duplicate',b'{"a":1,"\\u0061":2}',1,0xfffffffc)
        oversized=b'7'*641
        self.refusal('integer-limit',b'{"z":'+oversized+b',"a":'+b'8'*642+b'}',2,0xfffffff0,digits=640)
        self.refusal('later-syntax-before-integer',b'['+oversized+b',1.0]',1,BAD,digits=640)
        self.refusal('later-duplicate-before-integer',b'{"z":'+oversized+b',"a":0,"a":1}',1,0xfffffffc,digits=640)
        old=sys.get_int_max_str_digits()
        try:
            sys.set_int_max_str_digits(0)
            for digits in (640,4300):
                self.exact('digits-at-%d'%digits,b'-'+b'7'*digits,digits=digits)
                self.refusal('digits-over-%d'%digits,b'-'+b'7'*(digits+1),2,0xfffffff0,digits=digits)
            self.exact('digits-disabled',b'9'*16384,digits=0)
        finally:
            sys.set_int_max_str_digits(old)

    def test_public_bytes_nodes_depth_boundaries(self):
        m=self.native.module
        self.exact('byte-boundary',b'0'+b' '*(m.WIRE_LIMIT-1),0)
        self.refusal('byte-over',b'0'+b' '*m.WIRE_LIMIT,0,SPACE)
        values=[0]*(m.NODES-1)
        self.exact('node-boundary',b'['+b','.join([b'0']*(m.NODES-1))+b']',values)
        self.refusal('node-over',b'['+b','.join([b'0']*m.NODES)+b']',1,SPACE)
        self.exact('depth-boundary',b'['*64+b'0'+b']'*64)
        self.refusal('depth-over',b'['*65+b'0'+b']'*65,1,SPACE)

    def test_actual_private_leases_are_readonly_and_admission_is_first(self):
        original=self.native.executable().read_bytes()
        prefix,_=self.native.module.template()
        codec_at=len(prefix)+len(self.native.images['decoder'])
        def modified(name,code):
            raw=bytearray(original)
            raw[codec_at:codec_at+len(code)]=code
            path=self.native.evidence/('PRIVATE-'+name+'.elf')
            path.write_bytes(raw);path.chmod(0o700)
            return path
        for name,code in (('raw-write',bytes.fromhex('c6 02 7f 31 c0 c3')),
                          ('arena-write',bytes.fromhex('c6 07 7f 31 c0 c3'))):
            child=self.native.run(name,b'0',executable=modified(name,code))
            self.assertEqual(child.returncode,-signal.SIGSEGV,name)
            self.assertEqual((child.stdout,child.stderr),(b'',b''),name)
        # The same instruction class can write the explicitly mutable output;
        # it returns a deliberately invalid zero extent, which is framed.
        child=self.native.run('output-write',b'0',executable=modified('output-write',bytes.fromhex('41 c6 00 7f 31 c0 c3')))
        self.assertEqual((child.returncode,child.stdout),(2,b''))
        self.assertEqual(struct.unpack('<3Q',child.stderr),(self.native.module.ERROR_MAGIC,2,0))
        trap=modified('codec-entry-trap',bytes.fromhex('0f 0b'))
        child=self.native.run('valid-reaches-codec-trap',b'0',executable=trap)
        self.assertEqual(child.returncode,-signal.SIGILL)
        child=self.native.run('invalid-never-enters-codec',b'1.0',executable=trap)
        self.assertEqual((child.returncode,child.stdout),(2,b''))
        self.assertEqual(struct.unpack('<3Q',child.stderr),(self.native.module.ERROR_MAGIC,1,BAD))


if __name__=='__main__':
    unittest.main()
