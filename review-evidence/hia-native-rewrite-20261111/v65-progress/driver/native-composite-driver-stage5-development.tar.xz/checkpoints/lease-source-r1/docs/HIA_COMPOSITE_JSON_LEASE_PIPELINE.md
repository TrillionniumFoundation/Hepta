# Native JSON decoder lease pipeline

Status: independent development component. The complete composite driver is still in progress. This component has no semantic constructor, function, helper or outer dispatch, and does not replace public normalization or claim current cold qualification.

## Boundary being completed

The first codec accepts an issued integer-JSON arena and its original wire. An arbitrary external arena does not authenticate a same-length wire: the decoder's arena ABI contains no content hash. The new executable removes those independently supplied inputs from its interface. Its only input is raw stdin JSON; its fixed entry calls the exact embedded native decoder, retains the returned private arena and actual extent, and immediately calls the exact embedded packet codec with the same raw bytes.

The operating system makes both the raw wire and the issued arena read-only before they are used by the next stage. The integer decoder receives the wire only as a readbuf. The packet codec receives the arena as a readbuf and the wire only through its original HIA read borrow. Neither input is read back from a filename, external descriptor or replacement manifest between calls. The mapping is private to one process and one input.

This makes source/arena association a property of the actual native call chain. It does not turn the standalone codec into a validator of arbitrary externally supplied arena/wire associations. Its original private-unissued negative-scope witness remains valid and archived.

## HIA packing and runtime ownership

`generate_hia_composite_json_lease_cli.py` is a retained hosted authoring aid. It produces a HIA packer source, which is compiled by the existing B3 compiler under its unchanged limits. The HIA packer writes the ELF headers, fixed syscall entry, two relative call relocations and digit-policy constant, then copies the exact two flat images.

The executable is a static ELF with one read/execute load segment and a non-executable stack. It has no interpreter, imported symbols, loader dependency, Python value materialization, JSON host parser or host session dispatcher. Its fixed entry performs only read/write/mmap/mprotect/exit, owned buffer extent passing, image calls and native status framing. JSON validation and packet conversion remain in the HIA images.

The packed images are trusted build inputs, bound to their source and compile receipts by the development build record. The packer is not a sandbox or a proof of correctness for arbitrary machine images. Qualification of a later current main revision must rebuild from that revision's source; a manifest hash is not a substitute for matching compiler/source evidence.

## Exact representation profile

The original integer decoder runs first, with 8 MiB raw-byte, 262,144 node and depth 64 limits. Its syntax, Unicode, duplicate-key and node/depth refusal ordering is unchanged. The codec's arbitrary integer digit policy is explicit in the packer's 32-byte input header; zero disables it. The conversion policy is applied after the decoder finishes admission, before packet output, preserving source traversal order and `-0` normalization.

The executable emits the codec's entire 64-byte success header followed by its exact typed packet. It does not sort map fields or canonicalize the public constructor snapshot. A subsequent complete pipeline must still preserve original-source integer error ordering, canonical snapshot ordering, all existing constructor/function/helper/outer behavior, and final Core admission. Large generated Core output is unrelated to the bounded input representation and must not receive an earlier aggregate limit.

The HIA packer takes four u64 header words followed by the two flat images:

`[HIAJLP01, decoder_image_bytes, codec_image_bytes, integer_digit_limit]`.

Each image retains the existing 1 MiB maximum. The two-image packaging bound is derived from their sum plus the fixed ELF entry, not a language limit. The packer rejects malformed length headers before producing an executable.

## Buffer derivation

For N = 262,144 and B = 8 MiB, the decoder arena capacity is `64 + 56N + B`. Its separate key-table workspace is `8 * 2N`, which also covers the decoder's depth stack. Packet output and scratch need `64 + 49N + B + 8 * 2N` bytes. The raw wire has one overflow-detection byte and page padding. Arena and packet capacities are rounded up only for the private mmap allocation and read-only protection ranges; each native image receives its exact declared capacity, and the codec's arena view uses the decoder's actual returned extent.

The executable allocates all regions disjointly. No valid source is refused because an unrelated generated-Core arena is small, and no decoder or codec language budget is increased.

## Component diagnostics

On success, stdout contains only the complete codec frame and exit status is zero. On a native refusal, stdout is empty and stderr contains a 24-byte component record:

`[HIAJLE01, stage, exact_native_return]`.

Stage 1 is the decoder and stage 2 is the packet codec. Stage 0 denotes the raw-byte or syscall boundary. These are component transport diagnostics, not a claim to replace the public Python exception text or final CLI error schema. The eventual public driver must retain the existing error categories and ordering when mapping these native results.

The process accepts no arguments; extra arguments return 64. Ordinary source refusal returns 2, the existing byte/node/depth overflow returns 3, and I/O failure returns 4. Partial writes and interrupted reads/writes are retried without re-entering either semantic component.

## Planned actual evidence

The executable must be produced by the actual compiled HIA packer, then run directly with a minimal environment and no Python entrypoint. Required controls include exact packet bytes against the original transport, Unicode and arbitrary integers, first-error ordering, public byte/node/depth boundaries, malformed raw inputs, all packer length/capacity refusals, exact source/image/receipt custody and deliberately modified-image write faults showing that both leases are physically read-only. Deliberate executable corruption is a private test control and never a production or qualification artifact.
