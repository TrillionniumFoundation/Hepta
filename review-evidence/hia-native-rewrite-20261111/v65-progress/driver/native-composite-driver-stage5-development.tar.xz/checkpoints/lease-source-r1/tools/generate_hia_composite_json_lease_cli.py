"""Author the HIA packer for a private decoder-to-packet native pipeline.

The fixed syscall entry reads raw integer-profile JSON, calls the two exact
flat HIA images, and writes the codec's complete frame. It owns both input
leases and makes the raw wire and issued decoder arena physically read-only.
This is a complete representation prefix, not composite normalization.
The authoring aid is still hosted; the generated executable does not use it.
"""
from __future__ import annotations

import ast
from pathlib import Path
import struct

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions


MAGIC = int.from_bytes(b'HIAJLP01', 'little')
PACKET_MAGIC = int.from_bytes(b'HIAJPK01', 'little')
ERROR_MAGIC = int.from_bytes(b'HIAJLE01', 'little')
IMAGE_LIMIT = 1 << 20
BUNDLE_LIMIT = 2 * IMAGE_LIMIT + 4096
WIRE_LIMIT = 8 << 20
NODES = 262144
DEPTH = 64


def page(value):
    return (value + 4095) & ~4095


WIRE_REGION = page(WIRE_LIMIT + 1)
ARENA_BYTES = 64 + 56 * NODES + WIRE_LIMIT
ARENA_REGION = page(ARENA_BYTES)
ARENA_OFFSET = WIRE_REGION
WORK_BYTES = 8 * 2 * NODES
WORK_OFFSET = ARENA_OFFSET + ARENA_REGION
PACKET_BYTES = 64 + 49 * NODES + WIRE_LIMIT + 8 * 2 * NODES
PACKET_OFFSET = WORK_OFFSET + WORK_BYTES
MAPPING_BYTES = PACKET_OFFSET + page(PACKET_BYTES)
SOURCE_PATH = 'examples/hia_bootstrap/composite_json_lease_cli_packer.hiaasm'


def template():
    """Only fixed I/O, exact owned buffer views, calls and native status framing.

    No source-language node, key, number, operation or continuation is
    interpreted in this template. The HIA packer fills only two call holes
    and the explicitly selected conversion-digit policy.
    """
    code, labels, branches, holes = bytearray(), {}, [], {}

    def emit(value):
        code.extend(bytes.fromhex(value))

    def word(value):
        code.extend(struct.pack('<I', value))

    def quad(value):
        code.extend(struct.pack('<Q', value))

    def label(name):
        labels[name] = len(code)

    def branch(op, name):
        emit(op)
        branches.append((len(code), name))
        word(0)

    def pointer(op, offset):
        emit(op)
        word(offset)

    def call(name):
        emit('e8')
        holes[name] = len(code)
        word(0)

    def protect(offset, size):
        pointer('49 8d bc 24', offset)          # rdi = owned page range
        emit('be'); word(size)
        emit('ba 01 00 00 00 b8 0a 00 00 00 0f 05')
        emit('48 85 c0'); branch('0f 85', 'io_error')

    emit('48 83 3c 24 01'); branch('0f 85', 'usage')
    emit('31 ff be'); word(MAPPING_BYTES)
    emit('ba 03 00 00 00 41 ba 22 00 00 00 49 c7 c0 ff ff ff ff'
         ' 45 31 c9 b8 09 00 00 00 0f 05 48 3d 01 f0 ff ff')
    branch('0f 83', 'io_exit')
    emit('49 89 c4 45 31 ed')                   # r12 = private map, r13 = wire extent
    label('read')
    emit('31 c0 31 ff 4b 8d 34 2c ba'); word(WIRE_LIMIT + 1)
    emit('4c 29 ea 0f 05 48 83 f8 fc'); branch('0f 84', 'read')
    emit('48 85 c0'); branch('0f 88', 'io_error'); branch('0f 84', 'decode')
    emit('49 01 c5 49 81 fd'); word(WIRE_LIMIT)
    branch('0f 87', 'wire_limit'); branch('e9', 'read')

    label('decode')
    protect(0, WIRE_REGION)
    emit('4c 89 e7 4c 89 ee')                   # raw wire pointer/actual extent
    pointer('49 8d 94 24', ARENA_OFFSET)
    emit('b9'); word(ARENA_BYTES)
    pointer('4d 8d 84 24', WORK_OFFSET)
    emit('41 b9'); word(WORK_BYTES)
    emit('49 c7 40 30'); word(NODES)
    emit('49 c7 40 38'); word(DEPTH)
    call('decoder')
    emit('41 89 c6 41 bf 01 00 00 00')          # exact native result, diagnostic stage 1
    emit('83 f8 40'); branch('0f 82', 'native_error')
    emit('3d'); word(ARENA_BYTES); branch('0f 87', 'native_error')
    protect(ARENA_OFFSET, ARENA_REGION)

    # Fresh anonymous output already has every reserved field zero. Its
    # explicit control is filled only after the actual decoder succeeds.
    pointer('49 8d 9c 24', PACKET_OFFSET)
    emit('48 b8'); quad(PACKET_MAGIC); emit('48 89 03')
    emit('48 b8'); holes['digits'] = len(code); quad(0)
    emit('48 89 43 08')
    pointer('49 8d bc 24', ARENA_OFFSET)
    emit('4c 89 f6 4c 89 e2 4c 89 e9 49 89 d8')
    emit('41 b9'); word(PACKET_BYTES)
    call('codec')
    emit('41 89 c6 41 bf 02 00 00 00')
    emit('83 f8 40'); branch('0f 82', 'native_error')
    emit('3d'); word(PACKET_BYTES); branch('0f 87', 'native_error')
    emit('41 89 c5')                           # exact complete packet-frame extent
    pointer('4d 8d b4 24', PACKET_OFFSET)
    emit('31 db bd 01 00 00 00')               # exit 0, stdout
    branch('e9', 'write')

    label('wire_limit')
    emit('41 be fe ff ff ff 45 31 ff bb 03 00 00 00')
    branch('e9', 'error_frame')
    label('io_error')
    emit('49 89 c6 45 31 ff bb 04 00 00 00')
    branch('e9', 'error_frame')
    label('native_error')
    emit('bb 02 00 00 00 41 81 fe fe ff ff ff')
    branch('0f 85', 'error_frame')
    emit('bb 03 00 00 00')
    label('error_frame')
    pointer('49 8d 94 24', WORK_OFFSET)
    emit('48 b8'); quad(ERROR_MAGIC)
    emit('48 89 02 4c 89 7a 08 4c 89 72 10')
    emit('49 89 d6 41 bd 18 00 00 00 bd 02 00 00 00')
    label('write')
    emit('4d 85 ed'); branch('0f 84', 'done')
    emit('b8 01 00 00 00 89 ef 4c 89 f6 4c 89 ea 0f 05 48 83 f8 fc')
    branch('0f 84', 'write')
    emit('48 85 c0'); branch('0f 8e', 'io_exit')
    emit('49 01 c6 49 29 c5'); branch('e9', 'write')
    label('done')
    emit('89 df'); branch('e9', 'exit')
    label('usage')
    emit('bf 40 00 00 00'); branch('e9', 'exit')
    label('io_exit')
    emit('bf 04 00 00 00')
    label('exit')
    emit('b8 3c 00 00 00 0f 05 0f 0b')

    for offset, target in branches:
        struct.pack_into('<i', code, offset, labels[target] - offset - 4)
    header = (b'\x7fELF\x02\x01\x01' + bytes(9)
        + struct.pack('<HHIQQQIHHHHHH', 2, 62, 1, 0x4000b0, 64, 0, 0, 64, 56, 2, 0, 0, 0)
        + struct.pack('<IIQQQQQQ', 1, 5, 0, 0x400000, 0x400000, 0, 0, 4096)
        + struct.pack('<IIQQQQQQ', 0x6474e551, 6, 0, 0, 0, 0, 0, 16))
    assert len(header) == 176
    return header + code, {name: 176 + at for name, at in holes.items()}


def source_program():
    prefix, holes = template()
    source = f'''def pack(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(s) < 32 or length(s) > {BUNDLE_LIMIT}:
        return 4294967295
    if read_word(s, 0) != {MAGIC}:
        return 4294967295
    decoder = read_word(s, 8)
    codec = read_word(s, 16)
    digits = read_word(s, 24)
    if decoder == 0 or codec == 0 or decoder > {IMAGE_LIMIT} or codec > {IMAGE_LIMIT}:
        return 4294967295
    if length(s) != 32 + decoder + codec:
        return 4294967295
    size = {len(prefix)} + decoder + codec
    if size > {BUNDLE_LIMIT} or length(o) < size:
        return 4294967294
'''
    for at in range(0, len(prefix), 8):
        part = prefix[at:at+8]
        if len(part) == 8:
            source += f'    put_word(o, {at}, {int.from_bytes(part, "little")})\n'
        else:
            for offset, value in enumerate(part):
                source += f'    store(o, {at + offset}, {value})\n'
    source += f'''    put_word(o, 96, size)
    put_word(o, 104, size)
    put_word(o, {holes['digits']}, digits)
    put_four(o, {holes['decoder']}, {len(prefix) - holes['decoder'] - 4})
    put_four(o, {holes['codec']}, {len(prefix) - holes['codec'] - 4} + decoder)
    i = 32
    while i < length(s):
        store(o, {len(prefix)} + i - 32, byte(s, i))
        i = i + 1
    return size

def read_word(s:readbuf, at:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(s, at + i) << (i * 8))
        i = i + 1
    return value

def put_word(o:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(o, at + i, value & 255)
        value = value >> 8
        i = i + 1
    return 0

def put_four(o:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 4:
        store(o, at + i, value & 255)
        value = value >> 8
        i = i + 1
    return 0
'''
    return source


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i) for i, node in enumerate(nodes)}
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    functions = []
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(value) for value in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8',
                                 'module': 'composite_json_lease_cli_packer', 'functions': functions})


def main():
    path = Path(__file__).resolve().parents[1] / SOURCE_PATH
    path.write_text(render_assembly(document()))
    print(path.name, path.stat().st_size)


if __name__ == '__main__':
    main()
