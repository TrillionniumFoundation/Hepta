# Native typed-packet index and JSON writer

This independent component owns generic transport validation, exact packet-node offsets and ordered integer-JSON spelling. It contains no nominal type, function, helper or outer-lowering rules. It is intended for the existing bounded source and typed-service request packets, whose ABI already has a 64 MiB input limit. It is not an aggregate generated-Core buffer; the complete Core stream must retain its separate, deferred-gate path.

## Complete accepted representation

The input is the exact existing typed transport: a 16-byte little-endian kind/payload-size header, kinds 0 null, 1 Boolean, 2 canonical integer decimal, 4 strict UTF-8 string, 5 list and 6 map. Containers have an eight-byte element/pair count, complete nested extents, and one root. Dictionary keys must be strings with distinct decoded contents and preserve input order. Canonical integer spelling accepts arbitrarily large magnitudes within the existing packet extent, refuses leading signs/zeros other than a nonzero negative sign, and refuses `-0`. The preceding integer JSON decoder/packet codec has already applied its explicitly selected conversion-digit policy.

No floating-kind or arbitrary Python object kind is added. Those kinds are outside the existing public integer JSON path. Surrogate UTF-8 is refused; public source admission already refuses unpaired surrogates before any nominal owner. The component's private malformed-packet diagnostics are transport diagnostics, not a replacement public exception policy.

The native entry first completes the entire structural, arity, extent, UTF-8, integer and duplicate-key validation. Only then does it compare exact JSON output size with the caller's capacity, and only then does it emit JSON. Thus output shortage cannot hide a later malformed input. Failed invocations grant neither a partial output nor a partial source-offset index.

## ABI and lease

The external signature is the unchanged readbuf/mutbuf/mutbuf entry: typed packet, output, workspace. The workspace initially contains 16 u64 words, `[HIAPJS01, 0, ..., 0]`. All other workspace contents are initialized by the owner before use. Reuse without a fresh control is rejected; a refusal stores a nonzero status, so another entry with the same failed state also refuses.

On success the output contains:

`[HIAPJS01, 0, 64, json_bytes, packet_nodes, packet_bytes, index_offset, index_bytes]`

followed by exact `json.dumps(value, ensure_ascii=False, separators=(',', ':'), sort_keys=False)` bytes for the supported integer profile. The return is the whole 64-byte header plus payload extent. Status `0xfffffffd` is malformed packet/control/workspace; `0xfffffffe` is insufficient output capacity after complete validation. Refusal headers expose no output/index extent.

The workspace retains one bit for every byte offset in the source packet, set exactly for every node header, including dictionary keys and container roots. An offset may be used only with a successful invocation and the same immutable packet lease. There is no content digest in this index: its shape/length checks do not authenticate independently substituted source bytes. The eventual native driver owns the packet and index together and makes the packet read-only before publishing references.

## Finite allocation without a new depth limit

Let L be the existing bounded input extent. Each map pair needs at least 32 packet bytes, so the whole invocation has at most `floor(L/32)` keys. Its shared open-address table uses 16 bytes per slot and a power-of-two slot count at least twice that bound, with a minimum of two slots. Entries hold a key offset and its parent-object offset; hash collisions compare complete key bytes.

The exact node-offset bitmap uses `ceil(L/8)` bytes. Every ancestor container occupies at least 24 bytes, so `floor(L/24)+1` traversal frames suffice for every structurally possible packet. Each frame is 32 bytes. No fixed language-depth ceiling is introduced by this component.

The workspace capacity is:

`align8(128 + 16*slots + ceil(L/8)) + 32*(floor(L/24)+1)`.

The authoring subset has no division expression; a bounded 27-bit unsigned long-division helper computes the exact quotient by 24 for admitted `L <= 2^26`. It does not change the compiler or its profile.

Only the key table and bitmap are cleared. Every pushed traversal frame is written before reading, and frames are reused for the emission pass. Valid JSON output needs at most `6L` bytes: ASCII control escaping is the largest byte expansion, and source packet headers already cover JSON punctuation. The caller chooses an output capacity appropriate to its existing service or source boundary; no early complete-Core output limit is inferred from this formula.

## Integration order

Public raw JSON still goes through the original integer decoder and explicit integer conversion policy before canonical sorting. Native typed-service requests are mechanically serialized by this writer and then sent to the already selected HIA type owner. No request is interpreted as a semantic plan by a host adapter. Native object-token continuations, source/session correlation, canonical snapshot composition and final complete-Core handling remain separate integration work.
