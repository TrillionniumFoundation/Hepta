# Native composite driver: staged implementation

Status: independent development overlay, based on main `31d81594997cfb6cce5ab62ea5aaba3bb7757af1` plus the frozen v64 eleven-kernel protocol. No whole-native execution or qualification is claimed.

## Complete target

The final public vertical slice is raw integer-profile JSON through complete composite v1–v4 normalization, with the existing explicit legacy-v1 path. The existing HIA type, helper, constructor, function and outer kernels keep semantic ownership. HIA will also own generic representation and continuation scheduling; the executable boundary will only provide fixed buffer/image/syscall custody.

The pipeline must preserve initial integer JSON admission, canonical snapshot/ordering, constructor prefix state, every function and helper event, all-function-before-final-quota ordering, and final primitive admission. A large generated Core must remain streamable until the existing late gate. Neither a reduced language nor an earlier 8 MiB output gate is acceptable.

## Stage 1: complete JSON arena to typed packet codec

This stage replaces the Python source-value representation conversion. It is not yet the complete driver. The existing typed-packet ABI and the function object-token stream ABI are distinct and remain distinct.

Inputs are (1) a read-only JSON value arena issued by the existing integer JSON decoder, (2) the same immutable raw wire supplied to that decoder, and (3) a mutable result/scratch buffer. The first two arguments are both readbuf; this differs from the usual readbuf/mutbuf/mutbuf convention while retaining the fixed three address/length-pair native calling convention.

**Issuance boundary:** the arena has no source-content digest. The codec checks structural ranges, hierarchy, one-parent coverage, duplicate decoded keys and UTF-8, but cannot prove that an arbitrary externally supplied same-length JSON wire issued that arena. The final public application must itself call the native decoder and retain a private, non-substitutable lease to both read-only inputs. Tests of arbitrary malformed arenas are protocol controls, not a general parser refinement claim.

The result payload is byte-for-byte the existing `hia_instruction_policy_native.transport` representation for the issued value:

- kinds 0/1/2/4/5/6 represent null, bool, arbitrary integer decimal, UTF-8 string, list and map;
- a 16-byte little-endian kind/extent header precedes every value;
- containers begin with an eight-byte child/pair count;
- maps preserve the decoder's ordered fields and emit each key before its value;
- canonical integer decimal retains arbitrarily large valid magnitudes, subject to the explicitly supplied conversion digit policy; JSON -0 becomes typed integer 0;
- scalar string bytes and complete subtree extents determine exact source-reference offsets.

A public input follows its existing canonical snapshot path before becoming constructor input. The codec itself preserves whichever issued arena's order it receives; it must not silently substitute raw-wire order for the public canonical document order.

## Codec control and result ABI

The first 64 bytes of the mutable buffer initially contain eight u64 words:
`[HIAJPK01, integer_digit_limit, 0, 0, 0, 0, 0, 0]`.
The digit limit is the explicit embedding profile. Zero disables that conversion limit; this is not a new language quota. Python differential tests take it from `sys.get_int_max_str_digits()`; the final standalone application's profile source must be explicit and qualified.

A successful return is the byte extent `64 + packet_length`. Its header is:
`[HIAJPK01, 0, 64, packet_length, node_count, wire_length, 0, integer_digit_limit]`.
Only the declared payload is a typed packet. Scratch follows its derived maximum region and is never an output channel.

Refusal returns 0xfffffffd for arena/control/extent protocol failure or 0xfffffff0 for an admitted integer exceeding the selected conversion digit policy. Failure headers carry the node, raw offset, digit count and policy where applicable. They grant no packet authority. Arena structure validation finishes before source-order integer conversion; the first oversized integer is reported in the actual hierarchy traversal order.

## Derived bounds and finite work

Let N be arena nodes and B the input byte count. The existing decoder profile gives 1 ≤ N ≤ 1,048,576 and B ≤ 8 MiB; public Core admission uses N ≤ 262,144, depth ≤ 64 before this codec.

The packet needs at most 40N+B bytes: at most 24 bytes per value/container plus one 16-byte key header per nonroot dictionary value, while all decoded key/string/integer payload bytes are charged to the original wire. The codec checks that aggregate source payload charge.

Scratch consists of a power-of-two open-address key table with at least 2N slots, one byte per node for one-parent coverage, and one u64 packet offset per node. Parent links permit iterative subtree closing without recursion or an added depth quota. Whole-buffer requirement is:
`64 + 49N + B + 8*next_power_of_two(2N)`.

At the public maximum this is 25,428,032 bytes (24.25 MiB + 64 bytes). At the full decoder maximum it is 76,546,112 bytes (73 MiB + 64 bytes). These are representation capacities derived from existing admitted input bounds. Generated Core token streams do not inherit these input-packet bounds.

Every row and linked child is structurally checked once; every valid node is emitted once and closed once. Key hashing retains the existing finite input bounds; it makes no new language admission decision.

## Later complete layers

1. Native generic object-token consumer/custody: complete container arities, exact issued source references, UTF-8, integer/bool/null kind separation, permanent refusal and chunk correlation. Generated output uses bounded streaming/spooling rather than an early aggregate cap.
2. Native typed-service continuations: route constructor/function requests to the already issued type/helper state and build their exact binary responses; preserve request IDs, phases, profile, partial state and borrowed leases.
3. Native function/outer orchestration: retain native metadata and complete Core handles without Python dictionaries, preserve helper insertion/order, late function/block quotas, primitive export sorting and final Core admission.
4. HIA-produced executable packaging and fixed syscall entry; no Python value materialization or session dispatcher at runtime.

## Freeze and tests

The v64 protocol snapshot is `hia-v64-integration-development/frozen-protocol-source.json`, SHA-256 `60f279ba9c95fa580659b07a15dd68fe7e06c36c4e33c0799427b5cc2c1c93ce`. This overlay does not change that tree.

Planned codec evidence: exact old/new packet and offset equality for ordinary and boundary inputs, actual integer JSON decoder plus actual new image, independent native readonly-input canaries, malformed arena/cross-parent/duplicate-key/UTF-8 refusals, int zero/threshold/disabled profiles and first-error ordering, hostile output/control boundaries, and original B3 compile limits. Failed attempts and their source pins remain preserved. No existing admission or execution witness is skipped.

