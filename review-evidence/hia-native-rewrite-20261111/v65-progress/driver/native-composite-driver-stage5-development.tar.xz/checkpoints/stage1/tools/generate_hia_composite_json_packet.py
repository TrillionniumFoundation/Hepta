"""Author a complete issued integer-JSON arena to typed-packet codec in HIA.

Both source buffers are read-only. The embedding driver owns their decoder
lease; structural checks cannot authenticate arbitrary externally supplied
same-length arena/wire pairs. No nominal-language decisions occur here.
"""
from __future__ import annotations

import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

MAGIC = int.from_bytes(b'HIAJPK01', 'little')
SOURCE_PATH = 'examples/hia_bootstrap/composite_json_packet.hiaasm'

SOURCE = r'''
def json_packet(a:readbuf, s:readbuf, o:mutbuf) -> u32:
    if length(o) < 64:
        return 4294967293
    if load(o, 0) != MAGIC_VALUE:
        return fail(o, 4294967293, 0, 0, 0, 0)
    if load(o, 16) != 0 or load(o, 24) != 0 or load(o, 32) != 0 or load(o, 40) != 0 or load(o, 48) != 0 or load(o, 56) != 0:
        return fail(o, 4294967293, 0, 0, 0, 0)
    digits = load(o, 8)
    if arena_header(a, s) == 0:
        return fail(o, 4294967293, 0, 0, 0, digits)
    if initialize(a, s, o, digits) == 0:
        return fail(o, 4294967293, 0, 0, 0, digits)
    if check_tree(a, s, o) == 0:
        return fail(o, 4294967293, 0, 0, 0, digits)
    node = 0
    while node != 18446744073709551615:
        status = emit_node(a, s, o, node)
        if status != 0:
            return status
        node = following(a, o, node)
    extent = load(o, 8)
    put(o, 0, MAGIC_VALUE)
    put(o, 8, 0)
    put(o, 16, 64)
    put(o, 24, extent - 64)
    put(o, 32, read(a, 8))
    put(o, 40, length(s))
    put(o, 48, 0)
    put(o, 56, digits)
    return extent

def read(s:readbuf, at:u64) -> u64:
    result = 0
    shift = 0
    while shift < 64:
        result = result | (widen(byte(s, at + shift // 8)) << shift)
        shift = shift + 8
    return result

def load(o:mutbuf, at:u64) -> u64:
    result = 0
    shift = 0
    while shift < 64:
        result = result | (widen(byte(o, at + shift // 8)) << shift)
        shift = shift + 8
    return result

def put(o:mutbuf, at:u64, value:u64) -> u64:
    shift = 0
    while shift < 64:
        store(o, at + shift // 8, value >> shift)
        shift = shift + 8
    return 0

def widen(value:u64) -> u64:
    return value

def fail(o:mutbuf, code:u64, node:u64, start:u64, count:u64, limit:u64) -> u64:
    put(o, 0, MAGIC_VALUE)
    put(o, 8, code)
    put(o, 16, 0)
    put(o, 24, 0)
    put(o, 32, node)
    put(o, 40, start)
    put(o, 48, count)
    put(o, 56, limit)
    return code

def arena_header(a:readbuf, s:readbuf) -> u64:
    if length(a) < 64 or length(s) > 8388608:
        return 0
    count = read(a, 8)
    if read(a, 0) != 5208772604367785521 or count < 1 or count > 1048576:
        return 0
    base = 64 + count * 56
    if read(a, 16) != base or base > length(a):
        return 0
    if read(a, 24) != length(a) or read(a, 32) != length(a) or read(a, 40) != length(s):
        return 0
    if read(a, 48) != 1 or read(a, 56) != 0:
        return 0
    return 1

def initialize(a:readbuf, s:readbuf, o:mutbuf, digits:u64) -> u64:
    count = read(a, 8)
    slots = 2
    while slots < count * 2:
        slots = slots * 2
    table = 64 + count * 40 + length(s)
    linked = table + slots * 8
    if length(o) < linked + count * 9:
        return 0
    put(o, 8, 64)
    put(o, 16, table)
    put(o, 24, linked)
    put(o, 32, 0)
    put(o, 40, slots - 1)
    put(o, 48, 1)
    put(o, 56, digits)
    at = table
    while at < linked:
        put(o, at, 0)
        at = at + 8
    at = 0
    while at < count:
        store(o, linked + at, 0)
        at = at + 1
    store(o, linked, 1)
    return 1

def check_tree(a:readbuf, s:readbuf, o:mutbuf) -> u64:
    node = 0
    charged = 0
    while node < read(a, 8):
        weight = check_row(a, s, o, node)
        if weight == 18446744073709551615:
            return 0
        if weight > length(s) - charged:
            return 0
        charged = charged + weight
        node = node + 1
    if load(o, 48) != read(a, 8):
        return 0
    return 1

def check_row(a:readbuf, s:readbuf, o:mutbuf, node:u64) -> u64:
    record = 64 + node * 56
    kind = read(a, record)
    parent = read(a, record + 8)
    if kind > 6:
        return 18446744073709551615
    if node == 0:
        if parent != 18446744073709551615 or read(a, record + 16) != 18446744073709551615:
            return 18446744073709551615
    else:
        if parent >= node:
            return 18446744073709551615
        sibling = read(a, record + 16)
        if sibling != 18446744073709551615 and (sibling <= node or sibling >= read(a, 8)):
            return 18446744073709551615
    weight = check_payload(a, s, o, node)
    if weight == 18446744073709551615:
        return weight
    if node != 0 and read(a, 64 + parent * 56) == 6:
        if span(a, read(a, record + 40), read(a, record + 48)) == 0:
            return 18446744073709551615
        if utf8(a, read(a, record + 40), read(a, record + 48)) == 0:
            return 18446744073709551615
        if unique_key(a, o, node) == 0:
            return 18446744073709551615
        weight = weight + read(a, record + 48)
    else:
        if read(a, record + 40) != 0 or read(a, record + 48) != 0:
            return 18446744073709551615
    return weight

def check_payload(a:readbuf, s:readbuf, o:mutbuf, node:u64) -> u64:
    record = 64 + node * 56
    kind = read(a, record)
    start = read(a, record + 24)
    size = read(a, record + 32)
    if kind == 5 or kind == 6:
        if size > read(a, 8):
            return 18446744073709551615
        child = start
        remaining = size
        while remaining > 0:
            if child <= node or child >= read(a, 8):
                return 18446744073709551615
            if byte(o, load(o, 24) + child) != 0 or read(a, 64 + child * 56 + 8) != node:
                return 18446744073709551615
            store(o, load(o, 24) + child, 1)
            put(o, 48, load(o, 48) + 1)
            child = read(a, 64 + child * 56 + 16)
            remaining = remaining - 1
        if child != 18446744073709551615:
            return 18446744073709551615
        return 0
    if kind == 4:
        if span(a, start, size) == 0 or utf8(a, start, size) == 0:
            return 18446744073709551615
        return size
    if kind == 3:
        if start > length(s) or size < 1 or size > length(s) - start:
            return 18446744073709551615
        return size
    if kind == 0:
        return 0
    return 1

def span(a:readbuf, start:u64, size:u64) -> u64:
    if start < read(a, 16) or start > length(a):
        return 0
    if size > length(a) - start:
        return 0
    return 1

def utf8(a:readbuf, start:u64, size:u64) -> u64:
    at = start
    end = start + size
    while at < end:
        first = byte(a, at)
        if first < 128:
            at = at + 1
        else:
            width = 0
            if first >= 194 and first <= 223:
                width = 2
            elif first >= 224 and first <= 239:
                width = 3
            elif first >= 240 and first <= 244:
                width = 4
            if width == 0 or width > end - at:
                return 0
            offset = 1
            while offset < width:
                unit = byte(a, at + offset)
                if unit < 128 or unit > 191:
                    return 0
                if offset == 1:
                    if first == 224 and unit < 160:
                        return 0
                    if first == 237 and unit > 159:
                        return 0
                    if first == 240 and unit < 144:
                        return 0
                    if first == 244 and unit > 143:
                        return 0
                offset = offset + 1
            at = at + width
    return 1

def unique_key(a:readbuf, o:mutbuf, node:u64) -> u64:
    record = 64 + node * 56
    value = 14695981039346656037 ^ read(a, record + 8)
    start = read(a, record + 40)
    size = read(a, record + 48)
    at = 0
    while at < size:
        value = (value ^ widen(byte(a, start + at))) * 1099511628211
        at = at + 1
    slot = value & load(o, 40)
    while True:
        old = load(o, load(o, 16) + slot * 8)
        if old == 0:
            put(o, load(o, 16) + slot * 8, node + 1)
            return 1
        other = 64 + (old - 1) * 56
        if read(a, other + 8) == read(a, record + 8) and read(a, other + 48) == size:
            equal = True
            at = 0
            while at < size and equal:
                if byte(a, read(a, other + 40) + at) != byte(a, start + at):
                    equal = False
                at = at + 1
            if equal:
                return 0
        slot = (slot + 1) & load(o, 40)
    return 0

def header(o:mutbuf, kind:u64, size:u64) -> u64:
    at = load(o, 8)
    if at > load(o, 16) or load(o, 16) - at < 16:
        return 0
    put(o, at, kind)
    put(o, at + 8, size)
    put(o, 8, at + 16)
    return 1

def append(a:readbuf, o:mutbuf, start:u64, size:u64) -> u64:
    at = load(o, 8)
    if at > load(o, 16) or size > load(o, 16) - at:
        return 0
    offset = 0
    while offset < size:
        store(o, at + offset, byte(a, start + offset))
        offset = offset + 1
    put(o, 8, at + size)
    return 1

def scalar_byte(o:mutbuf, value:u64) -> u64:
    at = load(o, 8)
    if at >= load(o, 16):
        return 0
    store(o, at, value)
    put(o, 8, at + 1)
    return 1

def scalar_word(o:mutbuf, value:u64) -> u64:
    at = load(o, 8)
    if at > load(o, 16) or load(o, 16) - at < 8:
        return 0
    put(o, at, value)
    put(o, 8, at + 8)
    return 1

def emit_node(a:readbuf, s:readbuf, o:mutbuf, node:u64) -> u64:
    record = 64 + node * 56
    parent = read(a, record + 8)
    if parent != 18446744073709551615 and read(a, 64 + parent * 56) == 6:
        if header(o, 4, read(a, record + 48)) == 0 or append(a, o, read(a, record + 40), read(a, record + 48)) == 0:
            return fail(o, 4294967293, node, 0, 0, load(o, 56))
    put(o, load(o, 24) + read(a, 8) + node * 8, load(o, 8))
    kind = read(a, record)
    if kind == 0:
        if header(o, 0, 0) == 0:
            return fail(o, 4294967293, node, 0, 0, load(o, 56))
    elif kind == 1 or kind == 2:
        if header(o, 1, 1) == 0 or scalar_byte(o, kind - 1) == 0:
            return fail(o, 4294967293, node, 0, 0, load(o, 56))
    elif kind == 3:
        return emit_integer(a, s, o, node)
    elif kind == 4:
        if header(o, 4, read(a, record + 32)) == 0 or append(a, o, read(a, record + 24), read(a, record + 32)) == 0:
            return fail(o, 4294967293, node, 0, 0, load(o, 56))
    else:
        if header(o, kind, 8) == 0 or scalar_word(o, read(a, record + 32)) == 0:
            return fail(o, 4294967293, node, 0, 0, load(o, 56))
    return 0

def emit_integer(a:readbuf, s:readbuf, o:mutbuf, node:u64) -> u64:
    record = 64 + node * 56
    start = read(a, record + 24)
    size = read(a, record + 32)
    negative = byte(s, start) == 45
    first = start + choose(negative, 1, 0)
    digits = size - choose(negative, 1, 0)
    if digits == 0 or (digits > 1 and byte(s, first) == 48):
        return fail(o, 4294967293, node, start, digits, load(o, 56))
    offset = 0
    while offset < digits:
        unit = byte(s, first + offset)
        if unit < 48 or unit > 57:
            return fail(o, 4294967293, node, start, digits, load(o, 56))
        offset = offset + 1
    if load(o, 56) != 0 and digits > load(o, 56):
        return fail(o, 4294967280, node, start, digits, load(o, 56))
    if negative and digits == 1 and byte(s, first) == 48:
        start = first
        size = 1
    if header(o, 2, size) == 0 or append(s, o, start, size) == 0:
        return fail(o, 4294967293, node, start, digits, load(o, 56))
    return 0

def following(a:readbuf, o:mutbuf, node:u64) -> u64:
    record = 64 + node * 56
    if read(a, record) >= 5 and read(a, record + 32) != 0:
        return read(a, record + 24)
    current = node
    while current != 18446744073709551615:
        record = 64 + current * 56
        if read(a, record) >= 5:
            start = load(o, load(o, 24) + read(a, 8) + current * 8)
            put(o, start + 8, load(o, 8) - start - 16)
        sibling = read(a, record + 16)
        if sibling != 18446744073709551615:
            return sibling
        current = read(a, record + 8)
    return 18446744073709551615
'''


def source_program():
    return SOURCE.replace('MAGIC_VALUE', str(MAGIC))


def document():
    nodes = ast.parse(source_program()).body
    if len({node.name for node in nodes}) != len(nodes):
        raise ValueError('duplicate codec symbol')
    names = {node.name: 'f' + str(index) for index, node in enumerate(nodes)}
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    functions = []
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name],
                          'params': [builder.param(value) for value in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8',
                                  'module': 'composite_json_packet', 'functions': functions})


def main():
    path = Path(__file__).resolve().parents[1] / SOURCE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_assembly(document()))
    print(path.name, path.stat().st_size)


if __name__ == '__main__':
    main()

