"""Independent before/after binding controls. No executable entry is called."""
from pathlib import Path
from hashlib import sha256
import json,sys,types
from unittest.mock import patch
ROOT=Path('/workspace/scratch/9acdfa9f5639')
BASE=ROOT/'native-composite-driver-next'
OUT=ROOT/'hia-json-packet-independent-audit'
sys.path.insert(0,str(ROOT/'Hepta'))
from hepta.hia_json_preflight_native import NativeHiaJsonImage
sources={'r1':(OUT/'frozen-test-r1.py').read_bytes(),'r2':(BASE/'tests/test_hia_composite_json_packet.py').read_bytes()}
expected={'r1':'58a1863c6be4fade087a9ec1d63f7492e6324ac2d10b25d03b49e9d5faf1aeb3','r2':'5e7e4b667b8b0066e4d3b54dfee32a8dc5ab5734d8a059d993c1fe8636d0a482'}
for key,raw in sources.items():assert sha256(raw).hexdigest()==expected[key]
rows=[]
for revision,raw in sources.items():
 module=types.ModuleType('independent_codec_'+revision)
 module.__file__=str(BASE/'tests/test_hia_composite_json_packet.py')
 sys.modules[module.__name__]=module
 exec(compile(raw,module.__file__,'exec'),module.__dict__)
 for label in ('wrong-component','wrong-source-right-schema'):
  bundle=OUT/(label+'-bundle.json')
  inputs=json.loads(bundle.read_bytes())
  evidence=OUT/(revision+'-'+label+'-evidence')
  mappings=[];calls=[]
  initialize=NativeHiaJsonImage.__init__
  def initialize_observed(instance,image,digest):
   mappings.append(digest);initialize(instance,image,digest)
   entry=instance._entry
   def observed(*args):calls.append(True);raise AssertionError('wrong-image entry must never execute')
   instance._entry=observed
  value={'revision':revision,'case':label,'input_bundle_sha256':sha256(bundle.read_bytes()).hexdigest(),'current_codec_source_sha256':inputs['codec_source_sha256']}
  codec=None
  try:
   with patch.object(NativeHiaJsonImage,'__init__',new=initialize_observed):
    codec=module.ActualCodec(bundle,evidence)
   value.update(status='ADMITTED',loaded_codec_sha256=codec.codec.image_sha256)
  except AssertionError as error:
   value.update(status='REFUSED',error=str(error))
  finally:
   if codec is not None:codec.close()
  value.update(image_mappings=mappings,actual_image_entries=len(calls),evidence_directory_created=evidence.exists())
  if revision=='r1':assert value['status']=='ADMITTED' and len(mappings)==2
  else:assert value['status']=='REFUSED' and mappings==[] and not evidence.exists()
  assert not calls
  rows.append(value)
report={'schema':'hepta.hia.json-packet-independent-binding-review.v1','scope':'TEST_HARNESS_ADMISSION_GAP_ONLY; CORRECT_FROZEN_BUNDLE_RESULTS_REMAIN_VALID','production_codec_changed':False,'actual_image_entries':0,'frozen_test_sources':expected,'cases':rows}
p=OUT/'binding-controls.json';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2))
