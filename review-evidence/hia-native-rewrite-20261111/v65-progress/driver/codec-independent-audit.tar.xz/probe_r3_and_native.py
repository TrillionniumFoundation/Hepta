"""Independent custody regression and four small actual-image controls.

Only this audit directory is written. Candidate source/image bytes are read-only.
The structurally forged cases are private ABI controls, not public admission.
"""
from hashlib import sha256
import json
from pathlib import Path
import struct
import sys
import types
from unittest.mock import patch

ROOT = Path('/workspace/scratch/9acdfa9f5639')
BASE = ROOT / 'native-composite-driver-next'
OUT = ROOT / 'hia-json-packet-independent-audit'
sys.path.insert(0, str(ROOT / 'Hepta'))
SOURCE = BASE / 'tests/test_hia_composite_json_packet.py'
raw = SOURCE.read_bytes()
assert sha256(raw).hexdigest() == '5f0591cb2bf68bc82766bc6bafe092eb52a5d3a48556f2a0f6793786c08d0c4e'
(OUT / 'frozen-test-r3.py').write_bytes(raw)
module = types.ModuleType('independent_codec_r3')
module.__file__ = str(SOURCE)
sys.modules[module.__name__] = module
exec(compile(raw, str(SOURCE), 'exec'), module.__dict__)

bundle_path = BASE / 'development/bundle-r2.json'
original = json.loads(bundle_path.read_bytes())
pins = {}
for path in (SOURCE, bundle_path, BASE / 'tools/generate_hia_composite_json_packet.py',
             BASE / 'docs/HIA_COMPOSITE_DRIVER_NATIVE_DESIGN.md', module.SOURCE,
             Path(module.DECODER_SOURCE)):
    pins[str(path)] = sha256(path.read_bytes()).hexdigest()
for name in ('decoder', 'codec'):
    row = original[name]
    mp = Path(row['manifest'])
    manifest = json.loads(mp.read_bytes())
    for path in (mp, Path(row['source']), mp.parent / manifest['image_path']):
        pins[str(path)] = sha256(path.read_bytes()).hexdigest()
(OUT / 'r3-native-source-before.json').write_text(json.dumps(pins, indent=2, sort_keys=True)+'\n')

# Wrong component and same-schema wrong source must refuse before any mapping.
admissions = []
for label in ('wrong-component', 'wrong-source-right-schema'):
    evidence = OUT / ('r3-' + label + '-evidence')
    calls = []
    def forbid(*args, **kwargs):
        calls.append(True)
        raise RuntimeError('unexpected image mapping')
    try:
        with patch.object(module, 'NativeJsonDecoder', new=forbid), \
             patch.object(module, 'NativeHiaJsonImage', new=forbid):
            module.ActualCodec(OUT / (label+'-bundle.json'), evidence)
    except AssertionError as error:
        admissions.append({'case': label, 'refused': True, 'error': str(error),
                           'mappings': len(calls), 'evidence_created': evidence.exists()})
    else:
        raise AssertionError('wrong component admitted')
    assert not calls and not evidence.exists()

# Reproduce exactly the r2 second-read pin replacement, on our own image copy.
row = original['codec']
mp = Path(row['manifest'])
manifest = json.loads(mp.read_bytes())
image_a = (mp.parent / manifest['image_path']).read_bytes()
image_b = image_a + b'\x90'
image = OUT / 'r3-race-codec.image.bin'
image.write_bytes(image_a)
manifest['image_path'] = str(image)
manifest_path = OUT / 'r3-race-codec.manifest.json'
manifest_path.write_text(json.dumps(manifest, sort_keys=True)+'\n')
bundle = json.loads(json.dumps(original))
bundle['codec']['manifest'] = str(manifest_path)
race_bundle = OUT / 'r3-race-bundle.json'
race_bundle.write_text(json.dumps(bundle, sort_keys=True)+'\n')
reader = Path.read_bytes
reads = []
def race_read(path):
    if path == image:
        reads.append(True)
        if len(reads) == 2:
            image.write_bytes(image_b)
    return reader(path)
calls = []
evidence = OUT / 'r3-race-evidence'
try:
    with patch.object(Path, 'read_bytes', new=race_read), \
         patch.object(module, 'NativeJsonDecoder', new=forbid), \
         patch.object(module, 'NativeHiaJsonImage', new=forbid):
        module.ActualCodec(race_bundle, evidence)
except AssertionError as error:
    admissions.append({'case': 'verified-A-second-read-B', 'refused': True,
                       'error': str(error), 'mappings': len(calls),
                       'evidence_created': evidence.exists(), 'image_reads': len(reads)})
else:
    raise AssertionError('changed custody admitted')
assert len(reads) == 2 and not calls and not evidence.exists()
(OUT / 'r3-binding-regressions.json').write_text(json.dumps(admissions, indent=2, sort_keys=True)+'\n')

inputs = OUT / 'small-native-inputs'
inputs.mkdir(exist_ok=False)
native = module.ActualCodec(bundle_path, OUT / 'small-native-actual')
checks = []
def save(label, arena, wire, metadata):
    (inputs / (label+'.arena')).write_bytes(arena)
    (inputs / (label+'.wire')).write_bytes(wire)
    (inputs / (label+'.json')).write_text(json.dumps(metadata, indent=2, sort_keys=True)+'\n')

try:
    wire = '{"é":[-0,true,null,"\\u0000",18446744073709551616]}'.encode()
    arena = native.arena(wire)
    n = struct.unpack_from('<Q', arena, 8)[0]
    size = module.capacity(n, len(wire))
    expected = module.transport({'é': [0, True, None, '\x00', 18446744073709551616]})
    save('issued-roundtrip', arena, wire,
         {'scope': 'ACTUAL_ISSUED_DECODER_PAIR', 'capacity': size,
          'expected_packet_sha256': sha256(expected).hexdigest()})
    result, header, packet = native.encode('issued-roundtrip', arena, wire, output_size=size)
    assert result == 64+len(expected) and packet == expected and header[1] == 0
    checks.append({'case': 'issued-roundtrip', 'exact_packet': True, 'capacity': size})

    save('one-byte-short-derived-capacity', arena, wire,
         {'scope': 'PRIVATE_OUTPUT_CAPACITY_CONTROL', 'capacity': size-1,
          'expected_error': module.BAD})
    result, header, packet = native.encode('one-byte-short-derived-capacity', arena, wire,
                                           output_size=size-1)
    assert result == module.BAD and header[1] == module.BAD and header[2:4] == (0, 0)
    checks.append({'case': 'one-byte-short-derived-capacity', 'refused': True})

    wire = b'[[' + b'7'*641 + b'],' + b'8'*642 + b']'
    original_arena = native.arena(wire)
    assert struct.unpack_from('<Q', original_arena, 8)[0] == 4
    rows = [list(struct.unpack_from('<7Q', original_arena, 64+56*i)) for i in range(4)]
    assert [r[0] for r in rows] == [5, 5, 3, 3]
    mapping = {0: 0, 1: 1, 2: 3, 3: 2}
    changed = bytearray(original_arena)
    for old, row in enumerate(rows):
        row[1] = mapping.get(row[1], row[1])
        row[2] = mapping.get(row[2], row[2])
        if row[0] >= 5:
            row[3] = mapping.get(row[3], row[3])
        struct.pack_into('<7Q', changed, 64+56*mapping[old], *row)
    arena = bytes(changed)
    (inputs / 'physical-order-original.arena').write_bytes(original_arena)
    save('physical-order-not-traversal-order', arena, wire,
         {'scope': 'PRIVATE_STRUCTURALLY_VALID_UNISSUED_ARENA', 'digit_policy': 640,
          'physical_integer_nodes': [2, 3], 'traversal_integer_nodes': [3, 2],
          'expected_first_error_node': 3, 'expected_digit_count': 641})
    result, header, packet = native.encode('physical-order-not-traversal-order', arena, wire, digits=640)
    assert result == module.DIGITS and header[4] == 3 and header[5] == 2 and header[6:] == (641, 640)
    checks.append({'case': 'physical-order-not-traversal-order', 'first_node': header[4],
                   'first_digit_count': header[6], 'refusal_order_correct': True})

    wire = b'[' + b'9'*641 + b',"x"]'
    original_arena = native.arena(wire)
    assert struct.unpack_from('<Q', original_arena, 8)[0] == 3
    row = struct.unpack_from('<7Q', original_arena, 64+2*56)
    assert row[0] == 4 and row[4] == 1
    changed = bytearray(original_arena)
    changed[row[3]] = 0xff
    arena = bytes(changed)
    save('late-invalid-utf8-before-integer-policy', arena, wire,
         {'scope': 'PRIVATE_FORGED_ARENA_STRUCTURE_FIRST_CONTRACT',
          'digit_policy': 640, 'expected_error': module.BAD})
    result, header, packet = native.encode('late-invalid-utf8-before-integer-policy', arena, wire, digits=640)
    assert result == module.BAD and header[1] == module.BAD and header[4:7] == (0, 0, 0)
    checks.append({'case': 'late-invalid-utf8-before-integer-policy', 'structure_refused_first': True})
finally:
    native.close()

after = {path: sha256(Path(path).read_bytes()).hexdigest() for path in pins}
(OUT / 'r3-native-source-after.json').write_text(json.dumps(after, indent=2, sort_keys=True)+'\n')
assert after == pins
assert native.entries == 4 and native.decoder_entries == 3
report = {'schema': 'hepta.hia.json-packet-independent-targeted-controls.v1',
          'scope': 'SOURCE_R2_SMALL_ACTUAL_IMAGE_CONTROLS_NOT_COLD_OR_PUBLIC_DRIVER',
          'harness_sha256': sha256(raw).hexdigest(),
          'actual_decoder_entries': native.decoder_entries,
          'actual_codec_entries': native.entries,
          'all_readonly_inputs_and_canaries_unchanged': all(
              row['readonly_inputs'] and row['canaries_unchanged'] for row in native.rows),
          'before_after_pins_equal': after == pins, 'checks': checks,
          'binding_regressions': admissions}
(OUT / 'r3-small-native-controls.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
print(json.dumps(report, indent=2, sort_keys=True))
