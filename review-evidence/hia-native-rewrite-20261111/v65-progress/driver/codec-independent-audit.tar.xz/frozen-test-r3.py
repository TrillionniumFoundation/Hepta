"""Actual issued integer-JSON arena to complete typed-packet differential tests.

This module has no skip path. A development runner must explicitly provide
HEPTA_HIA_JSON_PACKET_DEVELOPMENT_BUNDLE and a fresh evidence directory. It does
not supply a cold qualification or activate a public composite driver.
"""
from contextlib import contextmanager
import base64
import ctypes
import gzip
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import random
import runpy
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

from hepta.hia_json_decode_native import NativeJsonDecoder, materialize, SOURCE as DECODER_SOURCE
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'examples/hia_bootstrap/composite_json_packet.hiaasm'
MAGIC = int.from_bytes(b'HIAJPK01', 'little')
BAD = 0xfffffffd
DIGITS = 0xfffffff0
NONE = (1 << 64) - 1
CANARY = bytes([0xa5]) * 32


def capacity(count, wire_size):
    slots = 2
    while slots < count * 2:
        slots *= 2
    return 64 + 49 * count + wire_size + slots * 8


@contextmanager
def digit_policy(value):
    before = sys.get_int_max_str_digits()
    try:
        sys.set_int_max_str_digits(value)
        yield
    finally:
        sys.set_int_max_str_digits(before)


class ActualCodec:
    def __init__(self, bundle, evidence):
        self.pins = {}
        def snapshot(path):
            path = Path(path)
            raw = path.read_bytes()
            digest = sha256(raw).hexdigest()
            key = str(path.resolve())
            if key in self.pins and self.pins[key] != digest:
                raise AssertionError('development inputs changed during admission')
            self.pins[key] = digest
            return raw
        self.bundle = json.loads(snapshot(bundle))
        if (self.bundle.get('schema') != 'hepta.hia.composite-json-packet-development.v1'
                or self.bundle.get('scope') != 'DEVELOPMENT_ONLY_NOT_COLD_QUALIFIED'):
            raise AssertionError('requires explicit development image provenance')
        admitted = {}
        codec_bytes = snapshot(SOURCE)
        if sha256(codec_bytes).hexdigest() != self.bundle['codec_source_sha256']:
            raise AssertionError('current source differs from compiled codec')
        expected = {
            'decoder': ('hepta.hia.json-decode-native.v1', snapshot(DECODER_SOURCE)),
            'codec': ('hepta.hia.composite-json-packet-native.v1', codec_bytes),
        }
        # Complete both source/schema/image admissions before mapping either
        # image or creating evidence. A checksum-correct image of another
        # component is not a codec, even when its own manifest is consistent.
        for name in ('decoder', 'codec'):
            row = self.bundle[name]
            manifest_path = Path(row['manifest'])
            manifest = json.loads(snapshot(manifest_path))
            source_path = Path(row['source'])
            source_bytes = snapshot(source_path)
            schema, required_bytes = expected[name]
            if (manifest.get('schema') != schema or source_bytes != required_bytes
                    or sha256(required_bytes).hexdigest() != manifest['source_sha256']):
                raise AssertionError('development source/schema mismatch: ' + name)
            image_path = manifest_path.parent / manifest['image_path']
            image_bytes = snapshot(image_path)
            if sha256(image_bytes).hexdigest() != manifest['image_sha256']:
                raise AssertionError('development image mismatch: ' + name)
            admitted[name] = (image_bytes, manifest['image_sha256'])
        # Pins describe the same frozen bytes that passed validation and will
        # be mapped. A later disk read can only confirm or reject those pins;
        # it must never silently replace the identity of the admitted bytes.
        if any(sha256(Path(path).read_bytes()).hexdigest() != digest
               for path, digest in self.pins.items()):
            raise AssertionError('development inputs changed during admission')
        self.evidence = Path(evidence)
        self.evidence.mkdir(parents=True, exist_ok=False)
        self.entries = 0
        self.decoder_entries = 0
        self.rows = []
        self.log = gzip.open(self.evidence / 'actual-codec-ledger.jsonl.gz', 'wt', encoding='utf-8')
        images = {}
        for name, cls in (('decoder', NativeJsonDecoder), ('codec', NativeHiaJsonImage)):
            images[name] = cls(*admitted[name])
        self.decoder, self.codec = images['decoder'], images['codec']
        original = self.decoder._entry

        def observe(*args):
            result = original(*args)
            self.decoder_entries += 1
            return result
        self.decoder._entry = observe

    def arena(self, wire, *, maximum=262144, depth=64):
        return self.decoder.arena(wire, max_nodes=maximum, max_depth=depth)

    def encode(self, label, arena, wire, *, digits=None, output_size=None, control=None,
               arena_extent=None, wire_extent=None):
        digits = sys.get_int_max_str_digits() if digits is None else digits
        count = struct.unpack_from('<Q', arena, 8)[0] if len(arena) >= 16 else 1
        # Invalid count controls still receive a small bounded protocol buffer.
        size = capacity(count, len(wire)) if 1 <= count <= 1048576 else 1024
        size = size if output_size is None else output_size
        a = ctypes.create_string_buffer(arena + CANARY)
        s = ctypes.create_string_buffer(wire + CANARY)
        output = ctypes.create_string_buffer(size + len(CANARY))
        ctypes.memset(output, 0xa5, size + len(CANARY))
        if size >= 64:
            struct.pack_into('<8Q', output, 0, *(control or (MAGIC, digits, 0, 0, 0, 0, 0, 0)))
        at = len(arena) if arena_extent is None else arena_extent
        st = len(wire) if wire_extent is None else wire_extent
        result = self.codec._entry(a, at, s, st, output, size)
        self.entries += 1
        raw = bytes(output[:size])
        header = struct.unpack_from('<8Q', raw) if size >= 64 else None
        readonly = (ctypes.string_at(a, len(arena)) == arena and
                    ctypes.string_at(s, len(wire)) == wire)
        guards = (bytes(a[len(arena):len(arena)+len(CANARY)]) == CANARY and
                  bytes(s[len(wire):len(wire)+len(CANARY)]) == CANARY and
                  bytes(output[size:size+len(CANARY)]) == CANARY)
        if not readonly or not guards:
            raise AssertionError(('input/canary corruption', label, readonly, guards))
        packet = raw[64:result] if 64 <= result <= size else None
        row = {'case': label, 'entry': self.entries, 'result': result, 'header': header,
               'arena_bytes': len(arena), 'arena_sha256': sha256(arena).hexdigest(),
               'wire_bytes': len(wire), 'wire_sha256': sha256(wire).hexdigest(),
               'output_capacity': size, 'readonly_inputs': readonly, 'canaries_unchanged': guards,
               'packet_bytes': len(packet) if packet is not None else None,
               'packet_sha256': sha256(packet).hexdigest() if packet is not None else None}
        if len(wire) <= 65536:
            row['wire_base64'] = base64.b64encode(wire).decode()
        if len(arena) <= 65536:
            row['arena_base64'] = base64.b64encode(arena).decode()
        if packet is not None and len(packet) <= 65536:
            row['packet_base64'] = base64.b64encode(packet).decode()
        self.rows.append(row)
        self.log.write(json.dumps(row, sort_keys=True) + '\n')
        self.log.flush()
        return result, header, packet

    def close(self):
        self.log.close()
        after = {path: sha256(Path(path).read_bytes()).hexdigest() for path in self.pins}
        report = {'scope': 'ACTUAL_CODEC_DEVELOPMENT_ONLY_NOT_COMPLETE_DRIVER_OR_COLD',
                  'actual_decoder_entries': self.decoder_entries, 'actual_codec_entries': self.entries,
                  'source_image_manifest_before': self.pins, 'source_image_manifest_after': after,
                  'sources_unchanged': after == self.pins,
                  'large_case_ledger': 'Exact comparisons run in memory; wires/arenas/packets <=64KiB embedded; larger deterministic boundaries retain exact hashes and source constructors.'}
        (self.evidence / 'custody.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
        if after != self.pins:
            raise AssertionError('codec/dependency source, manifest or image drift')


class JsonPacketSourceTests(unittest.TestCase):
    def test_changed_image_cannot_relabel_already_validated_bytes(self):
        original = json.loads((ROOT / 'development/bundle-r2.json').read_bytes())
        manifest_path = Path(original['codec']['manifest'])
        manifest = json.loads(manifest_path.read_bytes())
        raw = (manifest_path.parent / manifest['image_path']).read_bytes()
        def forbidden(*args, **kwargs):
            raise AssertionError('image mapping must not precede complete admission')
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            image_path = directory / 'image.bin'
            image_path.write_bytes(raw)
            manifest['image_path'] = 'image.bin'
            replacement = directory / 'manifest.json'
            replacement.write_text(json.dumps(manifest))
            original['codec']['manifest'] = str(replacement)
            bundle = directory / 'bundle.json'
            bundle.write_text(json.dumps(original))
            read_bytes = Path.read_bytes
            changed = []
            def replace_after_read(path):
                result = read_bytes(path)
                if path == image_path and not changed:
                    changed.append(True)
                    image_path.write_bytes(bytes([raw[0] ^ 1]) + raw[1:])
                return result
            output = directory / 'evidence'
            with patch.object(Path, 'read_bytes', new=replace_after_read), \
                    patch(__name__ + '.NativeJsonDecoder', new=forbidden), \
                    patch(__name__ + '.NativeHiaJsonImage', new=forbidden):
                with self.assertRaisesRegex(AssertionError, 'development inputs changed during admission'):
                    ActualCodec(bundle, output)
            self.assertEqual(changed, [True])
            self.assertFalse(output.exists())

    def test_wrong_component_is_rejected_before_mapping_or_evidence(self):
        original = json.loads((ROOT / 'development/bundle-r2.json').read_bytes())
        original['codec'] = dict(original['decoder'])
        def forbidden(*args, **kwargs):
            raise AssertionError('image mapping must not precede complete admission')
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            bundle = directory / 'bundle.json'
            bundle.write_text(json.dumps(original))
            output = directory / 'evidence'
            with patch(__name__ + '.NativeJsonDecoder', new=forbidden), \
                    patch(__name__ + '.NativeHiaJsonImage', new=forbidden):
                with self.assertRaisesRegex(AssertionError, 'development source/schema mismatch: codec'):
                    ActualCodec(bundle, output)
            self.assertFalse(output.exists())

    def test_manifest_schema_and_same_current_source_are_both_required(self):
        original = json.loads((ROOT / 'development/bundle-r2.json').read_bytes())
        def forbidden(*args, **kwargs):
            raise AssertionError('image mapping must not precede complete admission')
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            for name in ('decoder', 'codec'):
                for field in ('schema', 'source_sha256', 'source'):
                    with self.subTest(component=name, field=field):
                        bundle = json.loads(json.dumps(original))
                        manifest = json.loads(Path(bundle[name]['manifest']).read_bytes())
                        if field == 'source':
                            source = directory / 'wrong-source.hiaasm'
                            source.write_bytes(Path(bundle[name]['source']).read_bytes()+b'\n')
                            bundle[name]['source'] = str(source)
                            manifest['source_sha256'] = sha256(source.read_bytes()).hexdigest()
                        else:
                            manifest[field] = 'wrong'
                        manifest_path = directory / 'manifest.json'
                        manifest_path.write_text(json.dumps(manifest))
                        bundle[name]['manifest'] = str(manifest_path)
                        bundle_path = directory / 'bundle.json'
                        bundle_path.write_text(json.dumps(bundle))
                        output = directory / 'evidence'
                        with patch(__name__ + '.NativeJsonDecoder', new=forbidden), \
                                patch(__name__ + '.NativeHiaJsonImage', new=forbidden):
                            with self.assertRaisesRegex(AssertionError, 'development source/schema mismatch: '+name):
                                ActualCodec(bundle_path, output)
                        self.assertFalse(output.exists())

    def test_exact_generator_and_unchanged_external_compiler_profile(self):
        from hepta.hia_agent_assembly import render_assembly
        module = runpy.run_path(str(ROOT / 'tools/generate_hia_composite_json_packet.py'))
        document = module['document']()
        self.assertEqual(SOURCE.read_bytes(), render_assembly(document).encode())
        first = document['functions'][0]
        self.assertEqual([p['type'] for p in first['params']], ['readbuf', 'mutbuf', 'mutbuf'])
        self.assertEqual([op['op'] for op in first['blocks'][0]['ops']],
                         ['borrow.read', 'call', 'loan.end'])
        self.assertLessEqual(len(document['functions']), 128)
        self.assertLessEqual(sum(len(f['blocks']) for f in document['functions']), 1536)
        self.assertLessEqual(max(len(f['blocks']) for f in document['functions']), 256)
        self.assertLessEqual(max(len(b['params']) for f in document['functions'] for b in f['blocks']), 16)

    def test_derived_whole_buffer_capacity(self):
        self.assertEqual(capacity(262144, 8 << 20), 25428032)
        self.assertEqual(capacity(1048576, 8 << 20), 76546112)


class JsonPacketNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        bundle = os.environ.get('HEPTA_HIA_JSON_PACKET_DEVELOPMENT_BUNDLE')
        evidence = os.environ.get('HEPTA_HIA_JSON_PACKET_EVIDENCE')
        if not bundle or not evidence:
            raise AssertionError('explicit source-bound development bundle and fresh evidence directory required; no skip')
        cls.native = ActualCodec(bundle, evidence)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def exact(self, label, wire, expected=None, *, digits=None, maximum=262144, depth=64):
        arena = self.native.arena(wire, maximum=maximum, depth=depth)
        value = json.loads(wire) if expected is None else expected
        packet = transport(value)
        result, header, actual = self.native.encode(label, arena, wire, digits=digits)
        self.assertEqual(actual, packet, label)
        self.assertEqual(result, 64+len(packet), label)
        self.assertEqual(header, (MAGIC, 0, 64, len(packet),
                                 struct.unpack_from('<Q', arena, 8)[0], len(wire), 0,
                                 sys.get_int_max_str_digits() if digits is None else digits))
        decoded, indices = detached_packet_index(actual)
        reference, expected_indices = detached_packet_index(packet)
        self.assertEqual(list(indices), list(expected_indices), label)
        self.assertEqual(list(indices.items()), list(expected_indices.items()), label)
        self.assertEqual(decoded, reference, label)
        return arena, actual

    def test_scalar_container_unicode_and_source_order(self):
        values = [None, False, True, 0, 1, -1, -(1<<63), (1<<64)-1, 1<<129,
                  '', '"\\\n\t\r\b\f\u0000', '\x7f\x80\u07ff\u0800\ud7ff\ue000\uffff',
                  '\U00010000\U0010ffff', 'é', 'e\u0301', '😀中',
                  [], {}, [True, 1, None, [[], {}]],
                  {'z': 1, 'a': [0, {'x': 'y'}], '': {}, '😺': False}]
        for number, value in enumerate(values):
            wire = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
            with self.subTest(case=number):
                self.exact('scalar-%d' % number, wire)
        for number, wire in enumerate((b'-0', b'[-0,0,-10]', b'{"\\u0062":1,"a":2}',
                                       b'"\\uD834\\uDD1E"', b'{"slash":"\\/","control":"\\u0000"}')):
            self.exact('lexeme-%d' % number, wire)

    def test_deterministic_full_generic_tree_packets_and_offsets(self):
        rng = random.Random(0x484941)
        atoms = [None, False, True, '', 'a', '\n', 'é', 'e\u0301', '😀', '\U0010ffff']
        def value(depth):
            kind = rng.randrange(6 if depth else 3)
            if kind == 0:
                return atoms[rng.randrange(len(atoms))]
            if kind == 1:
                return rng.getrandbits(rng.randrange(160)) * (-1 if rng.randrange(2) else 1)
            if kind == 2:
                return ''.join(rng.choice('abé😀\n\\') for _ in range(rng.randrange(25)))
            if kind == 3:
                return [value(depth-1) for _ in range(rng.randrange(7))]
            return {'key%d-%s' % (i, rng.choice(('a','é','😀',''))): value(depth-1)
                    for i in range(rng.randrange(7))}
        for number in range(160):
            expected = value(4)
            wire = json.dumps(expected, ensure_ascii=False, separators=(',', ':')).encode()
            self.exact('seed-484941-%03d' % number, wire, expected)

    def test_public_nominal_canonical_input_packets_v1_through_v4(self):
        from hepta.hia_program import _decode
        from hepta.hia_schema import COMPOSITE_SCHEMAS
        from tests import test_hia_program_composite as nominal
        from tests import test_hia_partial_record as partial
        from tests import test_hia_composite_returned_loans as returned
        fixtures = (nominal.stored_loan_program, nominal.enum_owner_program,
                    nominal.task_program, nominal.scalar_task_program, nominal.owned_result_task_program,
                    partial.roundtrip_program, partial.task_partial_program, partial.chain_partial_program,
                    returned.pair_program, returned.task_program, returned.direct_downgrade_program)
        observed = set()
        for number, factory in enumerate(fixtures):
            document = factory()
            submitted = json.dumps(document, ensure_ascii=False).encode()
            detached, canonical = _decode(submitted)
            observed.add(detached['schema'])
            self.exact('nominal-canonical-%d' % number, canonical, detached)
        # Generic representation also covers every profile envelope; the
        # semantic profile decision remains in the unchanged constructor.
        self.assertEqual(len(COMPOSITE_SCHEMAS), 4)
        for version, schema in enumerate(sorted(COMPOSITE_SCHEMAS), 1):
            document = nominal.stored_loan_program()
            document['schema'] = schema
            detached, canonical = _decode(json.dumps(document).encode())
            self.exact('nominal-profile-envelope-v%d' % version, canonical, detached)
        self.assertTrue(observed)

    def test_no_host_value_producer_is_entered_on_actual_codec_path(self):
        value = {'z': [None, False, True, 12345678901234567890], 'a': '😀\n'}
        wire = json.dumps(value, ensure_ascii=False).encode()
        expected = transport(value)
        def absent(*args, **kwargs):
            raise AssertionError('host value producer entered selected codec path')
        with patch('json.loads', new=absent), \
                patch('hepta.hia_json_decode_native.materialize', new=absent), \
                patch('hepta.hia_instruction_policy_native.transport', new=absent), \
                patch('hepta.hia_composite_function_tokens.detached_packet_index', new=absent):
            arena = self.native.arena(wire)
            result, header, actual = self.native.encode('host-value-producers-forbidden', arena, wire)
        self.assertEqual(actual, expected)
        self.assertEqual(result, len(expected)+64)

    def test_integer_digit_profiles_threshold_disabled_and_first_error(self):
        for limit, length in ((640, 639), (640, 640), (640, 641),
                              (4300, 4300), (4300, 4301), (0, 16384)):
            for negative in (False, True):
                token = ('-' if negative else '') + '7'*length
                wire = ('{"first":['+token+'],"later":'+('8'*(length+1))+'}').encode()
                arena = self.native.arena(wire)
                with digit_policy(limit):
                    seen = []
                    def integer(text):
                        seen.append(text)
                        return int(text)
                    try:
                        value = json.loads(wire, parse_int=integer)
                        expected = transport(value)
                    except ValueError:
                        expected = None
                    result, header, packet = self.native.encode(
                        'digits-%s-%s-%s' % (limit, length, negative), arena, wire, digits=limit)
                    if expected is None:
                        failed = seen[-1]
                        self.assertEqual(result, DIGITS)
                        self.assertEqual(header[1], DIGITS)
                        self.assertEqual(header[5], wire.index(failed.encode()))
                        self.assertEqual(header[6], len(failed.lstrip('-')))
                        self.assertEqual(header[7], limit)
                        self.assertIsNone(packet)
                    else:
                        self.assertEqual(packet, expected)
        for wire in (b'-0', b'0', b'[-0,0]'):
            self.exact('integer-zero-'+wire.hex(), wire)

    def test_original_integer_decoder_admission_precedes_codec(self):
        too_big = b'7' * 4301
        cases = (b'1.0', b'1e2', b'NaN', b'Infinity', b'"\\ud800"',
                 b'{"a":1,"\\u0061":2}', b'"\xff"', b'['*65+b'0'+b']'*65,
                 b'['+too_big+b',1.0]', b'['+too_big+b',"\\ud800"]')
        for number, wire in enumerate(cases):
            before = self.native.entries
            with self.subTest(case=number), self.assertRaises((ValueError, OverflowError)):
                self.native.arena(wire)
            self.assertEqual(self.native.entries, before)

    def test_native_arena_structure_key_utf8_and_extent_refusals(self):
        wire = b'{"a":[0,{"x":"y"}],"b":true,"c":1}'
        arena = self.native.arena(wire)
        count = struct.unpack_from('<Q', arena, 8)[0]
        rows = [struct.unpack_from('<7Q', arena, 64+i*56) for i in range(count)]
        mutations = []
        def word(label, offset, value):
            data = bytearray(arena);struct.pack_into('<Q', data, offset, value)
            mutations.append((label, bytes(data), wire))
        for offset, value in ((0, 0),(8, 0),(8,1048577),(16,0),(24,len(arena)-1),
                              (32,len(arena)-1),(40,len(wire)+1),(48,2),(56,1)):
            word('header-%d-%d' % (offset,value),offset,value)
        word('root-parent',72,0);word('root-sibling',80,1)
        word('root-child-self',88,0);word('root-child-absent',88,NONE)
        word('root-child-count-too-large',96,count+1)
        word('root-child-count-too-small',96,2)
        for node,row in enumerate(rows[1:],1):
            word('unknown-kind-%d'%node,64+node*56,7)
            word('forward-parent-%d'%node,64+node*56+8,node)
            word('self-sibling-%d'%node,64+node*56+16,node)
        integer = next(i for i,row in enumerate(rows) if row[0]==3)
        word('integer-outside-wire',64+integer*56+24,len(wire)+1)
        word('integer-empty',64+integer*56+32,0)
        word('integer-nondecimal',64+integer*56+24,0)
        string = next(i for i,row in enumerate(rows) if row[0]==4)
        word('string-before-payload',64+string*56+24,0)
        word('string-outside-payload',64+string*56+32,len(arena))
        data=bytearray(arena);data[rows[string][3]]=0xff
        mutations.append(('invalid-value-UTF8',bytes(data),wire))
        dictionary_children=[i for i,row in enumerate(rows) if i and rows[row[1]][0]==6 and row[1]==0]
        first,second=dictionary_children[:2]
        data=bytearray(arena);data[rows[second][5]]=data[rows[first][5]]
        mutations.append(('duplicate-decoded-key',bytes(data),wire))
        data=bytearray(arena);data[rows[first][5]]=0xff
        mutations.append(('invalid-key-UTF8',bytes(data),wire))
        data=bytearray(arena);struct.pack_into('<Q',data,64+integer*56+40,rows[first][5])
        mutations.append(('array-value-with-map-key',bytes(data),wire))
        mutations.extend((('short-arena',arena[:20],wire),('truncated-record-area',arena[:70],wire)))
        for label, changed, raw in mutations:
            with self.subTest(label=label):
                result, header, packet = self.native.encode('arena-'+label, changed, raw)
                self.assertEqual(result, BAD, label)
                self.assertIsNone(packet)
        # This explicit private control documents the non-authentication
        # boundary: an arena header does not hash its external wire.
        unbound = self.native.arena(b'[1]')
        result, header, packet = self.native.encode('PRIVATE-UNISSUED-same-length-pair', unbound, b'[2]')
        self.assertEqual(packet, transport([2]))
        self.assertGreater(result, 64)

    def test_output_capacity_reserved_controls_and_input_view_lengths(self):
        wire='{"x":[true,0,"😀"]}'.encode('utf-8')
        arena=self.native.arena(wire)
        count=struct.unpack_from('<Q',arena,8)[0];size=capacity(count,len(wire))
        for amount in (0, 1, 63, 64, size-1):
            result,header,packet=self.native.encode('capacity-%d'%amount,arena,wire,output_size=amount)
            self.assertEqual(result,BAD);self.assertIsNone(packet)
        result,header,packet=self.native.encode('capacity-exact',arena,wire,output_size=size)
        self.assertEqual(packet,transport(json.loads(wire)))
        for offset in (0,2,3,4,5,6,7):
            control=[MAGIC,4300,0,0,0,0,0,0];control[offset]^=1
            result,_,packet=self.native.encode('control-%d'%offset,arena,wire,control=control)
            self.assertEqual(result,BAD);self.assertIsNone(packet)
        for field,value in (('arena_extent',0),('arena_extent',63),
                            ('arena_extent',len(arena)-1),('wire_extent',len(wire)-1)):
            result,_,packet=self.native.encode('view-%s-%s'%(field,value),arena,wire,**{field:value})
            self.assertEqual(result,BAD);self.assertIsNone(packet)

    def test_full_input_boundaries_and_adversarial_key_probe_chains(self):
        # Maximum public node count is exercised without widening the decoder.
        wire=b'['+b','.join([b'null']*262143)+b']'
        self.exact('public-node-limit',wire)
        before=self.native.entries
        with self.assertRaises(OverflowError):
            self.native.arena(b'['+b','.join([b'null']*262144)+b']')
        self.assertEqual(self.native.entries,before)
        # Largest legal wire with only one node, then a one-byte too-large input.
        wire=b'"'+b'x'*((8<<20)-2)+b'"'
        self.exact('public-byte-limit',wire)
        before=self.native.entries
        with self.assertRaises(ValueError):
            self.native.arena(wire+b' ')
        self.assertEqual(self.native.entries,before)
        # Deliberately collide the low bits of the native key table. This is a
        # finite worst-probe test, not a timing or constant-time assertion.
        keys=[];candidate=0
        while len(keys)<64:
            key=('collision-%d'%candidate).encode();candidate+=1
            value=14695981039346656037
            for byte in key:
                value=((value^byte)*1099511628211)&NONE
            if value&255==0:
                keys.append(key.decode())
        value={key: index for index,key in enumerate(keys)}
        self.exact('adversarial-64-key-probe-chain',json.dumps(value,separators=(',',':')).encode(),value)


if __name__ == '__main__':
    unittest.main()

