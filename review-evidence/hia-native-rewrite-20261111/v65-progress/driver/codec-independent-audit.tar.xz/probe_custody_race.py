"""Exact harness-r2 evidence race, using only an independent local image copy."""
from pathlib import Path
from hashlib import sha256
import json,sys,types
from unittest.mock import patch
ROOT=Path('/workspace/scratch/9acdfa9f5639');BASE=ROOT/'native-composite-driver-next';OUT=ROOT/'hia-json-packet-independent-audit'
sys.path.insert(0,str(ROOT/'Hepta'))
from hepta.hia_json_preflight_native import NativeHiaJsonImage
raw=(OUT/'frozen-test-r2.py').read_bytes();assert sha256(raw).hexdigest()=='5e7e4b667b8b0066e4d3b54dfee32a8dc5ab5734d8a059d993c1fe8636d0a482'
module=types.ModuleType('independent_codec_r2_race');module.__file__=str(BASE/'tests/test_hia_composite_json_packet.py');sys.modules[module.__name__]=module
exec(compile(raw,module.__file__,'exec'),module.__dict__)
bundle=json.loads((BASE/'development/bundle-r2.json').read_bytes());original_manifest=Path(bundle['codec']['manifest']);manifest=json.loads(original_manifest.read_bytes());image_a=(original_manifest.parent/manifest['image_path']).read_bytes();image_b=image_a+b'\x90'
image=OUT/'race-codec.image.bin';image.write_bytes(image_a)
manifest['image_path']=image.name
manifest_path=OUT/'race-codec.manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
bundle['codec']=dict(bundle['codec']);bundle['codec']['manifest']=str(manifest_path)
bundle_path=OUT/'race-bundle.json';bundle_path.write_text(json.dumps(bundle,indent=2)+'\n')
read=Path.read_bytes; reads=[];calls=[];mapped=[];initialize=NativeHiaJsonImage.__init__
def changed_read(path):
 if path.resolve()==image.resolve():
  reads.append(True)
  if len(reads)==2:image.write_bytes(image_b)
 return read(path)
def observed_mapping(instance,data,digest):
 mapped.append({'provided_sha256':sha256(data).hexdigest(),'expected_sha256':digest});initialize(instance,data,digest)
 def forbidden(*args):calls.append(True);raise AssertionError('no native entry is part of this custody probe')
 instance._entry=forbidden
with patch.object(Path,'read_bytes',new=changed_read),patch.object(NativeHiaJsonImage,'__init__',new=observed_mapping):
 codec=module.ActualCodec(bundle_path,OUT/'r2-race-evidence')
 loaded=codec.codec.image_sha256;pin=codec.pins[str(image)]
 codec.close()
assert len(reads)==3 and not calls
assert loaded==sha256(image_a).hexdigest() and pin==sha256(image_b).hexdigest() and loaded!=pin
custody=json.loads((OUT/'r2-race-evidence/custody.json').read_bytes());assert custody['sources_unchanged'] is True
value={'schema':'hepta.hia.json-packet-independent-custody-race.v1','scope':'TEST_HARNESS_ONLY_NO_PRODUCTION_INPUT_MODIFIED','frozen_test_sha256':sha256(raw).hexdigest(),'actual_image_entries':0,'image_reads':len(reads),'loaded_codec_sha256':loaded,'reported_before_and_after_image_sha256':pin,'reported_sources_unchanged':custody['sources_unchanged'],'original_verified_code_remained_immutable':True,'negative_input_bundle':str(bundle_path),'mapped_images':mapped}
p=OUT/'custody-race-r2.json';p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');print(json.dumps(value,indent=2))
