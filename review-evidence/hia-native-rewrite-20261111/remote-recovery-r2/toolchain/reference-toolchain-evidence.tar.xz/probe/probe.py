import hashlib,json,os,pathlib,platform,shutil,subprocess,sys,time
BASE=pathlib.Path("/var/tmp/hia9acdfa-native-resume-a3c61136-20261111/toolchains")
BASE.mkdir(mode=0o700,exist_ok=True)
OUT=BASE/"cpython-3.12.14-probe-v1"
OUT.mkdir(mode=0o700,exist_ok=False)
raw=sys.orig_argv[-1].encode()
(OUT/"probe.py").write_bytes(raw)
start=time.time_ns()
def invoke(argv,timeout=10):
    try:
        p=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
        return {"argv":argv,"returncode":p.returncode,"stdout":p.stdout.decode("utf-8","backslashreplace"),"stderr":p.stderr.decode("utf-8","backslashreplace")}
    except BaseException as e:
        return {"argv":argv,"error_type":type(e).__name__,"error":str(e)}
candidates=[]
for p in [shutil.which("python3.12"),"/usr/bin/python3.12","/usr/local/bin/python3.12","/opt/python3.12/bin/python3.12","/opt/python/3.12.14/bin/python3.12","/usr/bin/python3","/usr/local/bin/python3"]:
    if p and p not in candidates:candidates.append(p)
pycode="import json,sys,unicodedata,platform;print(json.dumps({'version':sys.version,'version_info':list(sys.version_info),'unicode':unicodedata.unidata_version,'implementation':platform.python_implementation(),'executable':sys.executable,'prefix':sys.prefix},sort_keys=True))"
probes=[]
for p in candidates:
    item={"path":p,"exists":os.path.lexists(p),"executable":os.access(p,os.X_OK)}
    if item["exists"]:
        item["realpath"]=os.path.realpath(p)
    if item["executable"]:
        item["probe"]=invoke([p,"-I","-c",pycode])
    probes.append(item)
tools={}
for name in ["cc","gcc","make","tar","xz","curl","pkg-config","openssl"]:
    p=shutil.which(name)
    tools[name]={"path":p}
    if p:tools[name]["version"]=invoke([p,"version" if name=="openssl" else "--version"],5)
headers=["stdio.h","openssl/ssl.h","zlib.h","ffi.h","x86_64-linux-gnu/ffi.h","sqlite3.h","bzlib.h","lzma.h","uuid/uuid.h","readline/readline.h","ncurses.h"]
v=os.statvfs(BASE)
report={"schema":"hia.cpython-reference-toolchain.probe.v1","scope":"BOUNDED_STANDARD_PATH_DISCOVERY_ONLY","started_ns":start,"ended_ns":time.time_ns(),"interpreters":probes,"tools":tools,"headers":{p:os.path.isfile("/usr/include/"+p) for p in headers},"statvfs":{"available_bytes":v.f_bavail*v.f_frsize,"available_inodes":v.f_favail},"uname":{"system":platform.system(),"machine":platform.machine()},"affinity":sorted(os.sched_getaffinity(0)),"probe_source_sha256":hashlib.sha256(raw).hexdigest(),"request":{"host":"rog","idempotency_key":"hia-native-resume-a3c61136-cpython31214-probe-20261111-v1","executable":"/usr/bin/python3","cpu_quota_percent":200,"memory_max_bytes":2147483648,"timeout_seconds":120}}
payload=(json.dumps(report,sort_keys=True,indent=2)+"\n").encode()
(OUT/"probe.json").write_bytes(payload)
print(json.dumps({"output":str(OUT),"report_bytes":len(payload),"report_sha256":hashlib.sha256(payload).hexdigest(),"report":report},sort_keys=True),flush=True)
