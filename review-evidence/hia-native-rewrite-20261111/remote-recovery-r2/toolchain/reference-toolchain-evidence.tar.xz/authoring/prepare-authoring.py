import hashlib,importlib.metadata,json,os,pathlib,stat,subprocess,sys,time,tomllib,traceback,urllib.request,zipfile,email.parser
BASE=pathlib.Path("/var/tmp/hia9acdfa-native-resume-a3c61136-20261111/toolchains/hia-authoring-py312-v1")
BASE.mkdir(mode=0o700,exist_ok=False)
(BASE/"prepare-authoring.py").write_bytes(sys.orig_argv[-1].encode())
SOURCE=pathlib.Path("/var/tmp/hia9acdfa-native-resume-a3c61136-20261111/source")
PY=pathlib.Path("/var/tmp/hia9acdfa-native-resume-a3c61136-20261111/toolchains/cpython-3.12.14-build-v1/install/bin/python3.12")
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
report={"schema":"hia.python-authoring-environment.v1","status":"RUNNING","scope":"DEVELOPMENT_AUTHORING_DEPENDENCIES_NOT_QUALIFICATION","started_ns":time.time_ns(),"operations":[],"idempotency_key":"hia-native-resume-a3c61136-authoring-py312-20261111-v1"}
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def save():(BASE/"environment.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
env=dict(os.environ);env.pop("PYTHONHOME",None);env.pop("PYTHONPATH",None)
env["PYTHONDONTWRITEBYTECODE"]="1";env["PIP_DISABLE_PIP_VERSION_CHECK"]="1";env["PIP_NO_INPUT"]="1"
env["TMPDIR"]=str(BASE/"tmp");(BASE/"tmp").mkdir()
def run(label,args,timeout=240):
    report["current_stage"]=label;save()
    t=time.monotonic_ns()
    with (BASE/(label+".stdout")).open("xb") as out,(BASE/(label+".stderr")).open("xb") as err:
        p=subprocess.run(args,cwd=BASE,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=timeout)
    o={"label":label,"argv":args,"returncode":p.returncode,"elapsed_ns":time.monotonic_ns()-t,"stdout":{"bytes":(BASE/(label+".stdout")).stat().st_size,"sha256":sha(BASE/(label+".stdout"))},"stderr":{"bytes":(BASE/(label+".stderr")).stat().st_size,"sha256":sha(BASE/(label+".stderr"))}}
    report["operations"].append(o);save();print(json.dumps({"stage":label,"returncode":p.returncode,"elapsed_ns":o["elapsed_ns"]},sort_keys=True),flush=True)
    if p.returncode:raise RuntimeError(label+" exited "+str(p.returncode))
save()
try:
    if sha(PY)!="5fe3461c5cd09c307e86e8b02b35f4777e057bf6bb59563b7d35fffaea92af89":raise RuntimeError("reference binary drift")
    raw=(SOURCE/"pyproject.toml").read_bytes()
    if hashlib.sha256(raw).hexdigest()!="97b48ef4d10f96bab48f1149d8f4093e4080c4bfb9cb361a9e4951bbbf54eb0e":raise RuntimeError("pyproject changed")
    (BASE/"pyproject.toml").write_bytes(raw)
    cfg=tomllib.loads(raw.decode())
    specs=cfg["project"]["dependencies"]+cfg["project"]["optional-dependencies"]["verification"]
    if specs!=["z3-solver==4.15.4.0"]:raise RuntimeError("unexpected project dependency scope")
    report["dependencies"]=specs;report["pyproject_sha256"]=hashlib.sha256(raw).hexdigest()
    for label,args in [("source-head",["/usr/bin/git","-C",str(SOURCE),"rev-parse","HEAD"]),("source-tree",["/usr/bin/git","-C",str(SOURCE),"rev-parse","HEAD^{tree}"]),("source-pyproject-blob",["/usr/bin/git","-C",str(SOURCE),"rev-parse","HEAD:pyproject.toml"])]:
        run(label,args,30);report[label]=(BASE/(label+".stdout")).read_text().strip()
    expectedblob=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
    if report["source-pyproject-blob"]!=expectedblob:raise RuntimeError("pyproject Git blob differs from exact HEAD")
    report["reference_python_sha256"]=sha(PY)
    run("venv",[str(PY),"-I","-B","-m","venv",str(BASE/"venv")],120)
    python=str(BASE/"venv"/"bin"/"python")
    wheels=BASE/"wheels";wheels.mkdir()
    run("download-wheels",[python,"-I","-B","-m","pip","download","--index-url","https://pypi.org/simple","--only-binary=:all:","--no-cache-dir","--dest",str(wheels)]+specs,300)
    wpins=[]
    for wheel in sorted(wheels.glob("*.whl")):
        with zipfile.ZipFile(wheel) as z:
            metas=[n for n in z.namelist() if n.endswith(".dist-info/METADATA")]
            if len(metas)!=1:raise RuntimeError("invalid wheel metadata")
            metadata=email.parser.BytesParser().parsebytes(z.read(metas[0]))
        name=metadata["Name"];version=metadata["Version"]
        url="https://pypi.org/pypi/"+name+"/"+version+"/json"
        with urllib.request.urlopen(url,timeout=60) as response:pr=response.read()
        pypath=BASE/("pypi-"+name+"-"+version+".json");pypath.write_bytes(pr)
        pj=json.loads(pr);matches=[e for e in pj["urls"] if e["filename"]==wheel.name]
        if len(matches)!=1 or matches[0]["digests"]["sha256"]!=sha(wheel):raise RuntimeError("wheel does not match official PyPI SHA256")
        wpins.append({"path":str(wheel),"name":name,"version":version,"bytes":wheel.stat().st_size,"sha256":sha(wheel),"pypi_metadata_url":url,"pypi_metadata_sha256":hashlib.sha256(pr).hexdigest(),"requires_dist":metadata.get_all("Requires-Dist",[])})
    report["wheels"]=wpins;save()
    run("install-wheels",[python,"-I","-B","-m","pip","install","--no-index","--find-links",str(wheels),"--report",str(BASE/"pip-install-report.json")]+specs,240)
    code="import hashlib,importlib.metadata,importlib.util,json,pathlib,platform,sys,unicodedata;sys.path.insert(0,"+repr(str(SOURCE))+");import z3;import hepta.hia_agent_assembly;import tools.generate_hia_selfhost;assert tuple(sys.version_info[:3])==(3,12,14);assert unicodedata.unidata_version=='15.0.0';assert importlib.metadata.version('z3-solver')=='4.15.4.0';print(json.dumps({'status':'PASS','executable':sys.executable,'base_prefix':sys.base_prefix,'prefix':sys.prefix,'version':sys.version,'unicode':unicodedata.unidata_version,'z3_distribution':importlib.metadata.version('z3-solver'),'z3_library':z3.get_version_string(),'z3_path':z3.__file__,'rpds_spec':str(importlib.util.find_spec('rpds')),'assembly_path':hepta.hia_agent_assembly.__file__,'selfhost_generator_path':tools.generate_hia_selfhost.__file__},sort_keys=True))"
    (BASE/"import-check.py").write_text(code+"\n")
    run("import-check",[python,"-I","-B",str(BASE/"import-check.py")],60)
    report["import_check"]=json.loads((BASE/"import-check.stdout").read_text())
    run("pip-check",[python,"-I","-B","-m","pip","check"],60)
    run("pip-list",[python,"-I","-B","-m","pip","list","--format=json"],60)
    report["installed_packages"]=json.loads((BASE/"pip-list.stdout").read_text())
    if (SOURCE/"pyproject.toml").read_bytes()!=raw or sha(PY)!=report["reference_python_sha256"]:raise RuntimeError("source or reference interpreter changed")
    report["source_after_exact"]=True
    report["venv_python"]=python
    report["venv_pyvenv_cfg"]=(BASE/"venv"/"pyvenv.cfg").read_text()
    if "include-system-site-packages = false" not in report["venv_pyvenv_cfg"]:raise RuntimeError("venv includes system site packages")
    report["status"]="AUTHORING_READY"
except BaseException as e:
    report["status"]="FAILED";report["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
report["ended_ns"]=time.time_ns();save()
print(json.dumps({"report_path":str(BASE/"environment.json"),"report_sha256":sha(BASE/"environment.json"),"status":report["status"],"venv_python":report.get("venv_python"),"error":report.get("error")},sort_keys=True),flush=True)
if report["status"]!="AUTHORING_READY":raise SystemExit(1)
