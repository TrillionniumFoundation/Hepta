import hashlib,io,json,os,pathlib,stat,sys,tarfile,time,traceback
ROOT=pathlib.Path("/var/tmp/hia9acdfa-native-resume-a3c61136-20261111/toolchains")
OUT=ROOT/"reference-toolchain-checkpoint-v1";OUT.mkdir(mode=0o700,exist_ok=False)
(OUT/"seal.py").write_bytes(sys.orig_argv[-1].encode())
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
BUILD=ROOT/"cpython-3.12.14-build-v1";AUTHOR=ROOT/"hia-authoring-py312-v1";PROBE=ROOT/"cpython-3.12.14-probe-v1"
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def identity(p):
    s=p.lstat()
    if not stat.S_ISREG(s.st_mode):raise RuntimeError("not regular "+str(p))
    return {"bytes":s.st_size,"mode":stat.S_IMODE(s.st_mode),"sha256":sha(p),"dev":s.st_dev,"inode":s.st_ino,"mtime_ns":s.st_mtime_ns,"ctime_ns":s.st_ctime_ns}
audit=json.loads((BUILD/"postbuild-audit-v1"/"audit.json").read_text())
author=json.loads((AUTHOR/"environment.json").read_text())
if audit["status"]!="REFERENCE_READY_WITH_GENERATED_BYTECODE_ACCOUNTED" or author["status"]!="AUTHORING_READY":raise RuntimeError("required completed results absent")
if sha(BUILD/"postbuild-audit-v1"/"audit.json")!="e061b3bea1959581b767acb9a99b49c3453bbfd4a0553b3ab6209f6ce330f31f":raise RuntimeError("audit changed")
if sha(AUTHOR/"environment.json")!="e5a10b3e74224685647fc9411b45a5d0eb4d81408afc91a9ab2632a59e2a1b0d":raise RuntimeError("authoring result changed")
external=[]
for name,p,expected in [
 ("official_source_archive",BUILD/"Python-3.12.14.tar.xz","5c8462af5790baf43a321a1559dbe0db06d1be4300fb85fb53c40060668e548a"),
 ("installed_reference_binary",BUILD/"install"/"bin"/"python3.12","5fe3461c5cd09c307e86e8b02b35f4777e057bf6bb59563b7d35fffaea92af89"),
 ("z3_official_wheel",pathlib.Path(author["wheels"][0]["path"]),"7e103a6f203f505b8b8b8e5c931cc407c95b61556512d4921c1ddc0b3f41b08e")]:
    ident=identity(p)
    if ident["sha256"]!=expected:raise RuntimeError("external retained artifact changed "+name)
    external.append({"name":name,"path":str(p),**ident,"included_in_archive":False})
scope={"schema":"hia.cpython-reference-toolchain.checkpoint-scope.v1","kind":"REFERENCE_TOOLCHAIN_DEVELOPMENT_EVIDENCE","not_hia_qualification":True,"reference_python":str(BUILD/"install"/"bin"/"python3.12"),"authoring_python":author["venv_python"],"version":[3,12,14],"unicode":"15.0.0","original_build_exit1_preserved":True,"postbuild_source":{"original_entries_unchanged":4577,"added_cpython312_pyc":148,"changed":0,"removed":0},"stdlib_tests":{"files_passed":3,"tests_run":1995,"upstream_skipped":7,"scope":"CPython stdlib reference tests; does not change HIA zero-anomaly gates"},"authoring":{"source_head":author["source-head"],"source_tree":author["source-tree"],"project_dependency_specs":author["dependencies"],"rpds_installed":False,"imports":["hepta.hia_agent_assembly","tools.generate_hia_selfhost"],"source_after_check_scope":"Only pyproject.toml and reference interpreter bytes were rechecked in this authoring job; whole Git tree verification belongs to the separate checkout job."},"archive_scope":"All top-level probe/build/authoring reports, scripts, raw subprocess logs, original control replies; complete original/after/install manifests; selected generated configure artifacts. Large source archive, installation payload, wheel, and runtime-managed job directories remain on ROG and are not embedded.","external_retained_artifacts":external}
(OUT/"scope.json").write_text(json.dumps(scope,sort_keys=True,indent=2)+"\n")
selected={}
for label,base in [("probe",PROBE),("build",BUILD),("authoring",AUTHOR)]:
    for p in sorted(base.iterdir()):
        if p.is_file() and not p.is_symlink() and p.name!="Python-3.12.14.tar.xz":selected[label+"/"+p.name]=p
for p in sorted((BUILD/"postbuild-audit-v1").iterdir()):
    if p.is_file() and not p.is_symlink():selected["build/postbuild-audit-v1/"+p.name]=p
for rel in ["build/config.log","build/Makefile","build/pyconfig.h"]:
    selected["build/"+rel]=BUILD/rel
selected["authoring/venv/pyvenv.cfg"]=AUTHOR/"venv"/"pyvenv.cfg"
selected["scope.json"]=OUT/"scope.json";selected["seal.py"]=OUT/"seal.py"
members=[{"name":name,"source":str(p),**identity(p)} for name,p in sorted(selected.items())]
custody={"schema":"hia.cpython-reference-toolchain.custody.v1","created_ns":time.time_ns(),"scope":scope,"members":members,"member_count":len(members),"raw_member_bytes":sum(m["bytes"] for m in members)}
craw=(json.dumps(custody,sort_keys=True,indent=2)+"\n").encode();(OUT/"custody.json").write_bytes(craw)
archive=OUT/"reference-toolchain-evidence.tar.xz"
with tarfile.open(archive,"w:xz",preset=6) as tf:
    for m in members:
        p=pathlib.Path(m["source"])
        if identity(p)!={k:v for k,v in m.items() if k not in {"name","source"}}:raise RuntimeError("source identity changed "+m["name"])
        data=p.read_bytes()
        if len(data)!=m["bytes"] or hashlib.sha256(data).hexdigest()!=m["sha256"]:raise RuntimeError("source bytes changed")
        info=tarfile.TarInfo(m["name"]);info.size=len(data);info.mode=m["mode"];info.mtime=0
        tf.addfile(info,io.BytesIO(data))
        if identity(p)!={k:v for k,v in m.items() if k not in {"name","source"}}:raise RuntimeError("source identity changed after read "+m["name"])
    info=tarfile.TarInfo("CUSTODY.json");info.size=len(craw);info.mode=0o600;info.mtime=0;tf.addfile(info,io.BytesIO(craw))
expected={m["name"]:m for m in members}
with tarfile.open(archive,"r:xz") as tf:
    entries=tf.getmembers()
    if len(entries)!=len(members)+1 or len({m.name for m in entries})!=len(entries):raise RuntimeError("archive member count/name mismatch")
    for m in entries:
        if not m.isfile():raise RuntimeError("archive nonregular member")
        data=tf.extractfile(m).read()
        if m.name=="CUSTODY.json":
            if data!=craw or m.mode!=0o600:raise RuntimeError("custody differs")
        else:
            e=expected[m.name]
            if len(data)!=e["bytes"] or hashlib.sha256(data).hexdigest()!=e["sha256"] or m.mode!=e["mode"]:raise RuntimeError("archive replay mismatch "+m.name)
summary={"schema":"hia.cpython-reference-toolchain.checkpoint.v1","status":"SEALED_AND_FULL_MEMBER_REPLAY_PASS","archive_path":str(archive),"archive_bytes":archive.stat().st_size,"archive_sha256":sha(archive),"custody_path":str(OUT/"custody.json"),"custody_bytes":len(craw),"custody_sha256":hashlib.sha256(craw).hexdigest(),"archive_members":len(members)+1,"original_members":len(members),"raw_original_bytes":sum(m["bytes"] for m in members),"scope_path":str(OUT/"scope.json"),"scope_sha256":sha(OUT/"scope.json"),"reference_python":scope["reference_python"],"authoring_python":scope["authoring_python"],"not_hia_qualification":True}
(OUT/"summary.json").write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
print(json.dumps(summary,sort_keys=True),flush=True)
