"""Run original CI source commands against one exact clean v70 candidate.
This new external harness preserves earlier reports; it is not a cold/native qualification.
"""
from hashlib import sha256
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback


def owner_process_identity():
    result = {"pid": os.getpid(), "ppid": os.getppid(), "job_id_hint": None,
              "scope": "own process kernel cgroup only; not terminal-state evidence"}
    try:
        with open("/proc/self/cgroup", "rb") as stream:
            raw = stream.read(65537)
        if len(raw) > 65536:
            raise ValueError("own cgroup diagnostic exceeds the bounded report")
        text = raw.decode("utf-8", "strict")
        result["cgroup_utf8"] = text
        result["cgroup_sha256"] = __import__("hashlib").sha256(raw).hexdigest()
        matches = sorted(set(__import__("re").findall(
            r"(?:^|/)hepta-runtime-job-([0-9a-f]+-[0-9a-f]+-[0-9a-f]+)(?:\.service|\.scope)(?:/|$)",
            text, __import__("re").M)))
        result["matching_job_ids"] = matches
        if len(matches) == 1:
            result["job_id_hint"] = matches[0]
    except (OSError, UnicodeError, ValueError) as exc:
        result["read_error"] = {"type": type(exc).__name__, "message": str(exc)}
    return result

ROOT = Path("/home/qq/hia-native-self-rewrite-20261111-dda7/static-budget-integration-v70-fixture-r2")
HARNESS = ROOT / "review-evidence/hia-native-rewrite-20261111/v69/qualification"
parser = argparse.ArgumentParser()
parser.add_argument("--expected-head", required=True)
parser.add_argument("--expected-tree", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
if not re.fullmatch("[0-9a-f]{40}", args.expected_head) or not re.fullmatch("[0-9a-f]{40}", args.expected_tree):
    raise ValueError("expected Git identities must be exact lowercase SHA1")
OUT = args.output
if not OUT.is_absolute() or OUT.parent.resolve() != ROOT / ".git/hia-static-fixture-v70-r2":
    raise ValueError("output must be a new child of the owned private evidence directory")
OUT.mkdir(mode=0o700, exist_ok=False)
OWNER_PROCESS = owner_process_identity()
_owner_fd = os.open(OUT / "owner-process.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(_owner_fd, "wb") as _owner_stream:
    _owner_stream.write((json.dumps(OWNER_PROCESS, sort_keys=True, indent=2) + "\n").encode("utf-8"))
sys.path.insert(0, str(HARNESS))
import workflow_process
sys.path.insert(0, str(ROOT))
from tools import hia_core_source_identity as identity

def write(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    path = OUT / name
    if path.exists():
        raise FileExistsError(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)

def digest(path):
    raw = Path(path).read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha256(raw).hexdigest()}

def git(*argv):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")
    cp = subprocess.run(["git", "-C", str(ROOT), *argv], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, timeout=60, check=False)
    if cp.returncode:
        raise RuntimeError("Git read failed: " + repr(argv) + " " + cp.stderr.decode("utf-8", "backslashreplace"))
    return cp.stdout

def workflow_script(workflow, name):
    start, = (i for i, line in enumerate(workflow) if line == "      - name: " + name)
    stop = next((i for i in range(start + 1, len(workflow)) if workflow[i].startswith("      - ")), len(workflow))
    lines = workflow[start:stop]
    begin = lines.index("        run: |") + 1
    end = next((i for i in range(begin, len(lines)) if lines[i] and not lines[i].startswith("          ")), len(lines))
    return "\n".join(line[10:] for line in lines[begin:end]) + "\n"

steps = []
before = after = harness_before = harness_after = prerequisite_before = prerequisite_after = None
commands = []
error = None
started = time.monotonic()
paths = {"driver": Path(__file__).resolve(), "workflow_process": Path(workflow_process.__file__).resolve(),
         "workflow": ROOT / ".github/workflows/hia-core.yml",
         "v6_runner": HARNESS / "run_hia_qualification_v6.py"}
try:
    if identity.ROOT.resolve() != ROOT.resolve():
        raise RuntimeError("source-identity helper resolved to another checkout")
    if paths["workflow_process"] != HARNESS / "workflow_process.py":
        raise RuntimeError("workflow owner resolved to another checkout")
    before = identity._source_state()
    write("source-before.json", before)
    actual_tree = git("rev-parse", "HEAD^{tree}").decode().strip()
    if before["status"] or before["head"] != args.expected_head or actual_tree != args.expected_tree:
        raise RuntimeError("source gate requires the expected clean commit and exact source tree")
    if git("write-tree").decode().strip() != args.expected_tree:
        raise RuntimeError("source index differs from expected clean tree")
    harness_before = {name: digest(path) for name, path in paths.items()}
    write("harness-before.json", harness_before)
    environment = dict(os.environ)
    discarded = {}
    for name in sorted(tuple(environment)):
        if name.startswith("HEPTA_HIA_") and (name.endswith(("_MANIFEST", "_COLD_REPORT")) or "_DEVELOPMENT" in name):
            value = environment.pop(name)
            raw = os.fsencode(value)
            discarded[name] = {"value_sha256": sha256(raw).hexdigest(), "bytes": len(raw)}
    environment["PATH"] = str(Path(sys.executable).parent) + os.pathsep + environment.get("PATH", "")
    environment.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUNBUFFERED="1")
    workflow_python = shutil.which("python", path=environment["PATH"])
    if workflow_python is None or not os.path.samefile(workflow_python, sys.executable):
        raise RuntimeError("workflow python does not resolve to the pinned current interpreter")
    prerequisite_before = {"executable": digest(Path(sys.executable).resolve()), "version": sys.version,
        "workflow_python": workflow_python, "discarded_selections": discarded,
        "scope": "ai395 Python 3.14.4 source controls; not GitHub Python 3.14.10 or a cold qualification"}
    write("prerequisites-before.json", prerequisite_before)
    workflow = paths["workflow"].read_text().splitlines()
    regeneration = workflow_script(workflow, "Regenerate actual HIA sources")
    source_tests = workflow_script(workflow, "Core source and independent reference controls")
    write("actual-workflow-scripts.json", {"regeneration": regeneration, "source_tests": source_tests})
    commands = [
        ("ci-regenerate", ["bash", "--noprofile", "--norc", "-c", regeneration]),
        ("core-only", [sys.executable, "-B", "tools/check_hia_core_only.py"]),
        ("support-check", [sys.executable, "-B", "tools/generate_hia_selfhost_contract.py", "--check"]),
        ("ci-language-regenerate", [sys.executable, "-B", "tests/test_hia_selfhost_language_coverage.py", "--generate-inventory"]),
        ("ci-generated-diff", ["git", "diff", "--exit-code"]),
        ("explicit-inventory-validation", [sys.executable, "-B", "-c",
            "from tests.test_hia_selfhost_language_coverage import validate_inventory; import json; "
            "r=validate_inventory(); print(json.dumps({'validated':True,'semantic_support_sha256':r['source']['semantic_support_sha256']}))"]),
        ("ci-source-tests", ["bash", "--noprofile", "--norc", "-c", source_tests]),
        ("original-scalar-proof-identity-tests", [sys.executable, "-B", "-m", "unittest", "-v", "tests.test_hia_scalar_proof_identity"]),
    ]
    for name, command in commands:
        print(json.dumps({"starting": name}), flush=True)
        stdout = OUT / (name + ".stdout.log")
        stderr = OUT / (name + ".stderr.log")
        owner = workflow_process.run_workflow_step(command, cwd=ROOT, env=environment,
            stdout_path=stdout, stderr_path=stderr, receipt_path=OUT / (name + ".owner.json"), seconds=1800)
        passed = (owner.get("returncode") == 0 and owner.get("timed_out") is False
            and owner.get("status") == "WORKFLOW_STEP_COMPLETED" and owner.get("cleanup", {}).get("complete") is True)
        row = {"name": name, "command": command, "owner": owner, "passed": passed,
            "stdout": digest(stdout), "stderr": digest(stderr)}
        if name in ("ci-source-tests", "original-scalar-proof-identity-tests"):
            row["unittest_summaries"] = [{"tests_run": int(n), "reported_seconds": float(s)}
                for n, s in re.findall(r"Ran (\d+) tests in ([0-9.]+)s", stderr.read_text())]
            row["summary_present"] = bool(row["unittest_summaries"])
            if not row["summary_present"]:
                row["passed"] = passed = False
                row["harness_error"] = "completed test command did not emit its original unittest summary"
            if name == "original-scalar-proof-identity-tests" and row["unittest_summaries"] != []:
                if len(row["unittest_summaries"]) != 1 or row["unittest_summaries"][0]["tests_run"] != 3:
                    row["passed"] = passed = False
                    row["harness_error"] = "the original scalar-proof identity module did not execute exactly its three tests"
        steps.append(row)
        write("step-" + str(len(steps)).zfill(2) + ".json", row)
        print(json.dumps({"finished": name, "passed": passed, "returncode": owner.get("returncode")}), flush=True)
        if not passed:
            break
except BaseException as exc:
    error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
finally:
    after_errors = []
    try:
        after = identity._source_state()
        write("source-after.json", after)
    except BaseException as exc:
        after_errors.append({"phase": "source-after", "type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()})
    try:
        harness_after = {name: digest(path) for name, path in paths.items()}
        write("harness-after.json", harness_after)
    except BaseException as exc:
        after_errors.append({"phase": "harness-after", "type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()})
    try:
        prerequisite_after = {"executable": digest(Path(sys.executable).resolve()), "version": sys.version}
        write("prerequisites-after.json", prerequisite_after)
    except BaseException as exc:
        after_errors.append({"phase": "prerequisites-after", "type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()})
    stable_prerequisites = (prerequisite_before is not None and prerequisite_after is not None
        and prerequisite_before["executable"] == prerequisite_after["executable"]
        and prerequisite_before["version"] == prerequisite_after["version"])
    passed = (error is None and not after_errors and len(commands) == 8 and len(steps) == 8
        and all(row["passed"] for row in steps) and before is not None and before == after
        and harness_before is not None and harness_before == harness_after and stable_prerequisites)
    report = {"schema": "hepta.hia.v70-clean-source-gate.v1",
        "scope": "EXACT_CLEAN_INTEGRATION_CI_SOURCE_COMMANDS_PLUS_ORIGINAL_SCALAR_PROOF_IDENTITY_TESTS",
        "expected_head": args.expected_head, "expected_tree": args.expected_tree, "owner_process": OWNER_PROCESS,
        "source_unchanged": before is not None and before == after,
        "harness_unchanged": harness_before is not None and harness_before == harness_after,
        "prerequisites_unchanged": stable_prerequisites, "steps": len(steps), "expected_steps": 8,
        "passed": passed, "error": error, "after_errors": after_errors, "elapsed_seconds": time.monotonic() - started,
        "whole_native": False, "default_native": False, "live_migration": False, "legacy_deletion": False,
        "native_or_cold_qualification_claimed": False}
    write("steps.json", steps)
    write("complete.json", report)
    print(json.dumps(report, sort_keys=True), flush=True)
raise SystemExit(0 if report["passed"] else 1)
