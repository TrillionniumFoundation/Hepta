"""Admit one parent-published exact Git tree into the owned detached checkout."""
import argparse,hashlib,json,os,pathlib,stat,subprocess,time,traceback

def owner_process_identity():
    result = {"pid": os.getpid(), "ppid": os.getppid(), "job_id_hint": None,
              "scope": "own process kernel cgroup only; not terminal-state evidence"}
    try:
        with open("/proc/self/cgroup", "rb") as stream:
            raw = stream.read(65537)
        if len(raw) > 65536:
            raise ValueError("own cgroup diagnostic exceeds the bounded report")
        text = raw.decode("utf-8", "strict")
        result["cgroup_utf8"] = text
        result["cgroup_sha256"] = __import__("hashlib").sha256(raw).hexdigest()
        matches = sorted(set(__import__("re").findall(
            r"(?:^|/)hepta-runtime-job-([0-9a-f]+-[0-9a-f]+-[0-9a-f]+)(?:\.service|\.scope)(?:/|$)",
            text, __import__("re").M)))
        result["matching_job_ids"] = matches
        if len(matches) == 1:
            result["job_id_hint"] = matches[0]
    except (OSError, UnicodeError, ValueError) as exc:
        result["read_error"] = {"type": type(exc).__name__, "message": str(exc)}
    return result

ROOT=pathlib.Path("/home/qq/hia-native-self-rewrite-20261111-dda7/static-budget-integration-v70-fixture-r2")
BASE="8aadee8b8bfc1bda940c9c32b2964429be358e1c"
TREE="4412879c31f0a9fe489a76f123b919936f8bed67"
A=ROOT/".git/hia-static-fixture-v70-r2"
parser=argparse.ArgumentParser()
parser.add_argument("--expected-head",required=True)
args=parser.parse_args()
new=args.expected_head
if len(new)!=40 or any(c not in "0123456789abcdef" for c in new):raise ValueError("expected exact SHA1")
OUT=A/"admit-clean-api-commit-r1"
OUT.mkdir(mode=0o700,exist_ok=False)
OWNER_PROCESS = owner_process_identity()
_owner_fd = os.open(OUT / "owner-process.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(_owner_fd, "wb") as _owner_stream:
    _owner_stream.write((json.dumps(OWNER_PROCESS, sort_keys=True, indent=2) + "\n").encode("utf-8"))
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0",PYTHONDONTWRITEBYTECODE="1")
record={"schema":"hepta.hia.v70-clean-source-admission.v1","base_head":BASE,"expected_head":new,"expected_tree":TREE,
 "commands":[],"source_mutations":[],"qualification":False,"owner_process":OWNER_PROCESS,"started_unix_ns":time.time_ns()}
error=None
def git(*argv,allowed=(0,),timeout=60):
 command=["git","-C",str(ROOT),*argv]
 result=subprocess.run(command,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,check=False)
 record["commands"].append({"argv":command,"returncode":result.returncode,
  "stdout":result.stdout.decode("utf-8","backslashreplace"),"stderr":result.stderr.decode("utf-8","backslashreplace")})
 if result.returncode not in allowed:raise RuntimeError("Git command failed: "+repr(argv))
 return result
def text(*argv):return git(*argv).stdout.decode().strip()
def fingerprint():
 raw=pathlib.Path("/home/qq/hia-native-self-rewrite-20261111-dda7/static-budget-fixture-v70-r2-observation/source-final.json").read_bytes()
 if hashlib.sha256(raw).hexdigest()!="550bddd83e8aeb4ac96dd7c04d8f5daf1dc7ca95f8f1e62c272ebb143f85d412":
  raise RuntimeError("frozen physical source manifest differs")
 expected=json.loads(raw)
 paths={p.decode() for p in git("ls-files","-z").stdout.split(b"\0") if p}
 if paths!=set(expected):raise RuntimeError("tracked source inventory moved")
 for rel,want in expected.items():
  p=ROOT/rel
  before=p.lstat()
  if not stat.S_ISREG(before.st_mode):raise RuntimeError("retained source is not a regular file: "+rel)
  data=p.read_bytes()
  after=p.lstat()
  fields=lambda item:(item.st_dev,item.st_ino,item.st_mode,item.st_size,item.st_mtime_ns)
  if fields(before)!=fields(after):raise RuntimeError("source moved while being fingerprinted: "+rel)
  got={"bytes":len(data),"posix_mode":stat.S_IMODE(before.st_mode),"sha256":hashlib.sha256(data).hexdigest(),
       "git_mode":"100755" if before.st_mode&0o111 else "100644",
       "blob_sha1":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
  if got!=want:raise RuntimeError("frozen source bytes/mode changed: "+rel)
 return {"paths":len(expected),"snapshot_sha256":hashlib.sha256(raw).hexdigest()}
try:
 record["source_before"]=fingerprint()
 if text("rev-parse","HEAD")!=BASE or text("write-tree")!=TREE:
  raise RuntimeError("owned candidate no longer has the frozen base/index")
 if git("symbolic-ref","-q","HEAD",allowed=(0,1)).returncode!=1:
  raise RuntimeError("owned checkout must remain detached")
 if git("diff","--name-only","-z").stdout or git("ls-files","--others","--exclude-standard","-z").stdout:
  raise RuntimeError("unexpected unstaged or untracked source")
 git("fetch","--no-tags","https://github.com/TrillionniumFoundation/Hepta.git",new,timeout=60)
 if text("rev-parse",new+"^{tree}")!=TREE or text("show","-s","--format=%P",new)!=BASE:
  raise RuntimeError("published commit does not have the exact frozen tree and original base parent")
 # HEAD alone advances; the already verified index and working bytes are retained.
 git("reset","--soft",new)
 record["source_mutations"].append({"kind":"detached_HEAD_only","before":BASE,"after":new})
 if text("rev-parse","HEAD")!=new or text("rev-parse","HEAD^{tree}")!=TREE or text("write-tree")!=TREE:
  raise RuntimeError("clean source commit identity differs")
 if git("status","--porcelain=v1","--untracked-files=all").stdout:
  raise RuntimeError("published source is not clean after exact-tree admission")
 record["source_after"]=fingerprint()
 record["source_unchanged"]=record["source_before"]==record["source_after"]
 record["status"]="EXACT_PUBLISHED_SOURCE_CLEAN" if record["source_unchanged"] else "SOURCE_CHANGED"
except BaseException as exc:
 error=exc
 record["status"]="FAILED"
 record["error"]={"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}
finally:
 record["ended_unix_ns"]=time.time_ns()
 raw=(json.dumps(record,indent=2,sort_keys=True)+"\n").encode()
 path=OUT/"report.json"
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,"wb") as f:f.write(raw)
 print(json.dumps({"status":record["status"],"report":str(path),"bytes":len(raw),
  "sha256":hashlib.sha256(raw).hexdigest(),"head":new,"tree":TREE,
  "source_unchanged":record.get("source_unchanged"),"qualification":False,"owner_process":OWNER_PROCESS},sort_keys=True),flush=True)
raise SystemExit(0 if error is None and record["status"]=="EXACT_PUBLISHED_SOURCE_CLEAN" else 1)
