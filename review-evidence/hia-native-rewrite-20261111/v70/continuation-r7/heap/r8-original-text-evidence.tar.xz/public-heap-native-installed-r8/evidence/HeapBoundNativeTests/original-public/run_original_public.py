import contextlib,hashlib,importlib,json,os,pathlib,subprocess,sys,time,traceback,unittest
from unittest.mock import patch
S=pathlib.Path(sys.argv[1]);F=pathlib.Path(sys.argv[2]);mode=sys.argv[3]
for key in list(os.environ):
    if key.startswith('HEPTA_'):os.environ.pop(key)
os.chdir(S);sys.path.insert(0,str(S))
from hepta import hia_heap_bound as heap,hia_heap_bound_native as ad,hia_static_budget as static
from importlib.metadata import version
import z3
assert z3.get_version_string()=='4.15.4'
paths=tuple(pathlib.Path(value) for value in json.loads(sys.argv[4]))
selectors=(ad.SELECTOR,ad.LIVE_SELECTOR,ad.STATIC_SELECTOR,ad.PAYLOAD_SELECTOR)
if mode=='native':os.environ.update({key:str(path) for key,path in zip(selectors,paths)})
else:assert mode=='reference'
expected_blobs={"tests/test_hia_heap_bound.py":"c165ed101c24ccd5d526275a4f4796e494973c21","tests/test_hia_heap_intervals.py":"d6bb59add86ef22007bad54fe7f57d0b1ddcc6f5","tests/test_hia_heap_borrowed.py":"64cf658f4f3ae60f424f39a38a586555f096137c","tests/test_hia_entry_payload_bound.py":"bb02ae772b820cbf3c4d400c71ea597d08247494","tests/test_hia_borrowed_extent_heap.py":"06f5178113b6495265a23f926106916e3f06fa8d","tests/test_hia_finite_v8_heap.py":"c76fcf09a2e5cda1c4e9bb03c31626a10ecb82b1","tests/test_hia_partial_finite_bounds.py":"69c45039d0ae423d9cbdd974d20910e1bb6c1eb1","tests/test_hia_returned_loan_budgets.py":"0189fbb55329ccd613b675cbcece37dec2bae0fd","tests/test_hia_zero_heap_loops.py":"a7b87e39a994d0d651d599424cc492696370f639","tests/test_hia_scoped_alloc_loops.py":"061dc7f263ca918718924902d2fdff5780d95505","tests/test_hia_p0p1_v7_guard.py":"f4d9e183a51eb1a835fe329eb3ded2312b67f41e","tests/test_hia_p1_scoped_try_new_v7_guard.py":"54ab42d1e35a6bbfccb316ee5d157541cf124096","tests/test_hia_returned_loans.py":"2c5a2dd655efdd8bb646992cb0a1eafa87c6d0cf"}
changed={"tests/test_hia_borrowed_extent_heap.py":"29cb3313a02f87656fd582979f6b766dd3776b762f9fc0b8a86c8d6c2d94b5de","tests/test_hia_finite_v8_heap.py":"bdce6033ba3a51315c0118bc3e99d5c63a6cccd96fe242f4e51106dee583c47e","tests/test_hia_partial_finite_bounds.py":"1efe720bea5bc3a5f3ccb44ece16e43aea25e09869cde17a8c3107068db9ada6"}
expected={"tests/test_hia_borrowed_extent_heap.py":"29cb3313a02f87656fd582979f6b766dd3776b762f9fc0b8a86c8d6c2d94b5de","tests/test_hia_entry_payload_bound.py":"43ea10a4dc356f157fe9a95ff23f9ddcdf682d13a6f29f877fd672064340ee52","tests/test_hia_finite_v8_heap.py":"bdce6033ba3a51315c0118bc3e99d5c63a6cccd96fe242f4e51106dee583c47e","tests/test_hia_heap_borrowed.py":"a6c69d306aaf9651dd37a79c01e1fea923374bb711e4c1778a2dea9b18382030","tests/test_hia_heap_bound.py":"df80df2c83e26b82b0b0c5071f51fe8a4a3818b0e3569404e6cca3b895f920b5","tests/test_hia_heap_intervals.py":"61cb7b1ea9bb232990c17e54105756ef096b802fb5d7e47567cec89019098d64","tests/test_hia_p0p1_v7_guard.py":"93f498d5ce03a28219912d248eab72d6bb31ead0f4bfe4fb39952600c37cebc5","tests/test_hia_p1_scoped_try_new_v7_guard.py":"f9be3e032050a57d0c36e119d1b0b40b0c87135057d46ee5550e04328bc46c62","tests/test_hia_partial_finite_bounds.py":"1efe720bea5bc3a5f3ccb44ece16e43aea25e09869cde17a8c3107068db9ada6","tests/test_hia_returned_loan_budgets.py":"73c0cc1af2e02106459cd5c54b0b664f0d29bd3a345536ec97dd1b1b868c4a06","tests/test_hia_returned_loans.py":"f3589f3eb906b5f0d4409d79287578c62972ee1810a89b0ea8f3bcd66f9d18c3","tests/test_hia_scoped_alloc_loops.py":"972c248dd6f1368459f8fe6d6f05dbd8732b8941f37a1142e6196ff355c73e43","tests/test_hia_zero_heap_loops.py":"b38c2ca968a571f1e00a361786ce0ab684af701450e6dfa0810394de4967a33a"}
for path,want in expected.items():
    assert hashlib.sha256((S/path).read_bytes()).hexdigest()==want,(path,'retained public fixture bytes differ')
classes=["tests.test_hia_heap_bound.HIAHeapBoundTests","tests.test_hia_heap_intervals.HIAHeapIntervalTests","tests.test_hia_heap_borrowed.HIAHeapBorrowedExtentTests","tests.test_hia_entry_payload_bound.EntryPayloadBoundTests","tests.test_hia_borrowed_extent_heap.BorrowedExtentHeapTests","tests.test_hia_finite_v8_heap.FiniteV8HeapTests","tests.test_hia_partial_finite_bounds.PartialFiniteBounds","tests.test_hia_returned_loan_budgets.ReturnedLoanBudgetTests","tests.test_hia_zero_heap_loops.ZeroHeapLoopQualification","tests.test_hia_scoped_alloc_loops.ScopedAllocatingLoopTests","tests.test_hia_p0p1_v7_guard.GuardedV7HeapProfileTests","tests.test_hia_p1_scoped_try_new_v7_guard.V7FallibleHeapVersionGuard","tests.test_hia_returned_loans.ReturnedLoans","tests.test_hia_returned_loans.ReturnedLoanSemantics"]
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in classes)
tests=[]
def visit(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):visit(item)
        else:tests.append(item.id())
visit(suite)
assert len(tests)==134,len(tests)
report={'mode':mode,'scope':'PUBLIC_HEAP_ORIGINAL_REFERENCE_AND_EXPLICIT_NATIVE_FIXTURE_BRANCHES','classes':classes,'test_ids':tests,
        'expected_count':len(tests),'source_test_hashes':expected,'original_git_blobs':expected_blobs,'native_fixture_deltas':changed,'python':sys.version,
        'packages':{p:version(p) for p in ('jsonschema','z3-solver')},'native_step_count':0,'old_policy_calls':[],
        'separate_foreign_clang_rust_classes_not_in_scope':True,'started':time.time()}
def forbidden(name):
    def invoke(*args,**kwargs):
        report['old_policy_calls'].append(name)
        raise AssertionError('selected native public heap entered retained policy: '+name)
    return invoke
original_step=ad.NativeHeapController.step
def counted_step(*args,**kwargs):
    report['native_step_count']+=1
    return original_step(*args,**kwargs)
with (F/(mode+'-unittest.log')).open('w') as stream,contextlib.ExitStack() as stack:
    if mode=='native':
        for name in [name for name in vars(heap) if name.startswith('_reference_')]+['_function','_dag','_scoped_allocating_cycle_peak']:
            stack.enter_context(patch.object(heap,name,forbidden('heap.'+name)))
        stack.enter_context(patch.object(heap._FiniteInvocationAnalysis,'__init__',forbidden('heap._FiniteInvocationAnalysis.__init__')))
        for name in [name for name in vars(static) if name.startswith('_reference_')]+['_audit_v7_byte_resource_profile','_audit_v8_resource_profile']:
            stack.enter_context(patch.object(static,name,forbidden('static.'+name)))
        stack.enter_context(patch.object(ad.NativeHeapController,'step',counted_step))
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
report.update(tests_run=result.testsRun,failures=[{'id':t.id(),'traceback':txt} for t,txt in result.failures],
              errors=[{'id':t.id(),'traceback':txt} for t,txt in result.errors],
              skips=[{'id':t.id(),'reason':why} for t,why in result.skipped],
              expected_failures=[{'id':t.id(),'traceback':txt} for t,txt in result.expectedFailures],
              unexpected_successes=[t.id() for t in result.unexpectedSuccesses],finished=time.time())
from tests.hia_heap_native_fixture import OBSERVATIONS
report['native_fixture_observations']=OBSERVATIONS
report['status']='PASS' if result.wasSuccessful() and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses and result.testsRun==len(tests) and (mode!='native' or report['native_step_count']>0) else 'FAIL'
(F/(mode+'-RESULT.json')).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'mode':mode,'status':report['status'],'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'native_step_count':report['native_step_count'],'old_policy_calls':report['old_policy_calls']}),flush=True)
raise SystemExit(0 if report['status']=='PASS' else 1)
