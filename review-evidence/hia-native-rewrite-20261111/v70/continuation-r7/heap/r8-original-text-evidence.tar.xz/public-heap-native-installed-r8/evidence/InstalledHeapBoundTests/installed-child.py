
import sys
sys.path.insert(0,sys.argv[1])
import importlib.abc
from hashlib import sha256
import json
from pathlib import Path
from unittest.mock import patch

class NoAuthoring(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('tools','tests'):
            raise AssertionError('installed heap imported authoring or test code')
sys.meta_path.insert(0,NoAuthoring())

from hepta import hia_heap_bound as heap, hia_heap_bound_native as controller
from hepta import hia_heap_live_native as live, hia_heap_payload_native as payload
from hepta import hia_static_budget as static, hia_static_budget_native as structural
from hepta import hia_native_helpers as helpers
from hepta.hia_native_helpers import native_helpers_scope
from hepta.hia_checker_identity import checker_native_selection

def absent(*args,**kwargs):
    raise AssertionError('installed heap reached a retained heap/static policy')
for name in [name for name in vars(heap) if name.startswith('_reference_')]:
    setattr(heap,name,absent)
for name in ('_function','_dag','_scoped_allocating_cycle_peak','_qualify_finite_entry_live_heap_budget'):
    setattr(heap,name,absent)
heap._FiniteInvocationAnalysis.__init__=absent
for name in [name for name in vars(static) if name.startswith('_reference_')]:
    setattr(static,name,absent)
for name in ('_bound_function','_audit_v7_byte_resource_profile','_audit_v8_resource_profile'):
    setattr(static,name,absent)
modules=(controller,live,structural,payload)
loaders=(controller.installed_heap_controller,live.installed_heap_live,
         structural.installed_static_budget,payload.installed_heap_payload)
installed=Path(sys.argv[1]).resolve()
for path in (heap.__file__,static.__file__,*(module.SOURCE for module in modules)):
    assert Path(path).resolve().is_relative_to(installed),path
bundle,digest,mode=sys.argv[2:5]
entries={module.SELECTOR:0 for module in modules}

if mode=='drift':
    try:
        with native_helpers_scope(bundle,digest):
            raise AssertionError('changed installed heap source was admitted')
    except ValueError as error:
        assert str(error)=='native helper source identity mismatch',str(error)
        print(json.dumps({'refused':str(error),'entries':entries},sort_keys=True))
elif mode=='incomplete':
    with patch.object(helpers.importlib,'import_module',
                      side_effect=AssertionError('mapping/import before complete dependency admission')):
        try:
            with native_helpers_scope(bundle,digest):
                raise AssertionError('incomplete heap group was admitted')
        except ValueError as error:
            assert str(error)=='native heap controller requires its complete pinned dependency set',str(error)
            print(json.dumps({'refused':str(error),'entries':entries},sort_keys=True))
elif mode=='worker':
    import runpy
    sys.argv=['hia-agent-worker','--installation-manifest','--native-helpers-manifest',bundle,
              '--expected-native-helpers-sha256',digest]
    runpy.run_module('hepta.hia_agent_worker',run_name='__main__')
else:
    cases=json.loads(Path(sys.argv[5]).read_bytes())
    with native_helpers_scope(bundle,digest) as binding:
        for module,loader in zip(modules,loaders):
            image=loader(binding.selections[module.SELECTOR])
            assert image in binding.images.values()
            original=image._entry
            def counted(*args,selector=module.SELECTOR,original=original):
                entries[selector]+=1
                return original(*args)
            image._entry=counted
        reports=[]
        for case in cases:
            module=heap if case['owner']=='heap' else static
            try:
                result=getattr(module,case['entry'])(case['program'],*case['arguments'],**case['keywords'])
                reports.append({'returned':result})
            except Exception as error:
                cause=error.__cause__
                reports.append({'type':type(error).__name__,'code':getattr(error,'code',None),
                    'message':str(error),'cause':None if cause is None else
                    {'type':type(cause).__name__,'code':getattr(cause,'code',None),'message':str(cause)}})
        assert all(count>0 for count in entries.values()),entries
        identity=checker_native_selection()
        assert not any(name.split('.')[0] in ('tools','tests') for name in sys.modules)
        binding.check()
        print(json.dumps({'reports':reports,'native_entries':entries,
              'sources':{module.SELECTOR:{'path':str(module.SOURCE),
                       'sha256':sha256(module.SOURCE.read_bytes()).hexdigest()} for module in modules},
              'helpers_sha256':binding.sha256,
              'checker':{key:identity[key] for key in entries}},sort_keys=True))
