"""Replay every completed inner/raw/publication boundary through the fixed ELF.

Expected values are derived outside the child from frozen completed ledgers and,
where newly required, the independent primitive verifier. Child execution has an
empty PATH/HOME, no interpreter, no value bridge and no manifest/source reads.
The local ptrace restriction is recorded; no syscall-observation claim is made.
"""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import resource
import struct
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'Hepta-v66-restored'
sys.path[:0]=[str(ROOT/'development'),str(ROOT),str(BASE)]
from publication_mechanical_executor import PublicBundle
from hepta.hia_program import _decode,verify_program,HIAProgramRejected
from hepta.hia_core_admission_native import NativeCoreAdmission,ERROR_CODES

build_path=ROOT/'development/native-cli-r1/build.json';build_raw=build_path.read_bytes();build=json.loads(build_raw)
assert build['status']=='PASS'
executable_rows={r['profile']:r for r in build['rows']}
bundle=PublicBundle(ROOT/'development/publication-bundle-r2/bundle.json')
pins=dict(bundle.pins);pins[build_path]=build_raw;pins[Path(__file__)]=Path(__file__).read_bytes()
for row in build['rows']:
    path=Path(row['path']);pins[path]=path.read_bytes();assert sha256(pins[path]).hexdigest()==row['sha256']
for p in (ROOT/'tools').glob('*native*'):
    if p.is_file():pins[p]=p.read_bytes()
suites=[('profiles','complete-profile-panel-r2','source-document.json'),
        ('boundaries','complete-boundary-panel-r1','source-document.json'),
        ('raw','raw-pipeline-r1','raw-input.json'),
        ('publication','publication-pipeline-r2','raw-input.json')]
inputs=[]
for suite,folder,input_name in suites:
    directory=ROOT/'development'/folder;summary_path=directory/'summary.json'
    summary_raw=summary_path.read_bytes();summary=json.loads(summary_raw)
    assert summary['status']=='PASS';pins[summary_path]=summary_raw
    for row in summary['results']:
        case=directory/row['case'];wire=(case/input_name).read_bytes()
        inputs.append((suite,case,wire,row))
        for name in (input_name,'result.json'):
            p=case/name;pins[p]=p.read_bytes()
prior_path=ROOT/'development/native-cli-panels-r1/summary.json'
prior_raw=prior_path.read_bytes();prior=json.loads(prior_raw)
assert prior['status']=='FAIL' and prior['error_class']=='TimeoutExpired' and prior['cases_completed']==92
assert [(suite,row['case']) for suite,case,wire,row in inputs[:92]]==[(row['suite'],row['case']) for row in prior['results']]
pins[prior_path]=prior_raw
inputs=inputs[92:]
assert len(inputs)==79
dest=ROOT/'development/native-cli-panels-r2';dest.mkdir(exist_ok=False)
empty=dest/'empty';empty.mkdir()
(dest/'source-before.json').write_text(json.dumps({str(p):{'bytes':len(raw),'sha256':sha256(raw).hexdigest()} for p,raw in pins.items()},indent=2,sort_keys=True)+'\n')
(dest/'test-source.py').write_bytes(Path(__file__).read_bytes())
results=[];start=time.monotonic_ns()
summary={'scope':'COMPLETE_FIXED_NATIVE_ELF_EXISTING_PANEL_REPLAY','status':'INCOMPLETE','whole_stack_closed':False,
    'production_activation':False,'strace_observed':False,'strace_blocked_control':'../native-cli-smoke-r1',
    'retained_child_runtime':False,'expected_cases':len(inputs),'results':results,
    'prior_completed_cases':92,'prior_summary_sha256':sha256(prior_raw).hexdigest(),
    'development_process_wall_seconds':600,'original_cold_and_language_limits_unchanged':True}


def limits():
    resource.setrlimit(resource.RLIMIT_AS,(1536<<20,1536<<20))
    resource.setrlimit(resource.RLIMIT_STACK,(8<<20,8<<20))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))


try:
    for suite,case,wire,old in inputs:
        profile='legacy' if old['legacy'] else 'ordinary';exe=executable_rows[profile]
        expected_output=None;gate_status=None;expected_frame=list(old['frame'])
        if old['accepted']:
            if suite=='publication':
                expected_output=(case/'published-core.json').read_bytes()
            else:
                name='core.json.gz' if suite=='raw' else 'actual-core.json.gz'
                with gzip.open(case/name,'rb') as stream:core=stream.read()
                _,canonical_core=_decode(core)
                gate_status=NativeCoreAdmission.status(bundle.images[27],canonical_core)
                assert gate_status!=0xfffffffd
                try:
                    reference=verify_program(canonical_core)
                    assert gate_status==0 and reference.canonical_bytes==canonical_core,(suite,old['case'])
                except HIAProgramRejected as exc:
                    assert gate_status!=0 and exc.code==ERROR_CODES[gate_status],(suite,old['case'],exc,gate_status)
                if gate_status==0:expected_output=canonical_core
        folder=dest/(suite+'--'+old['case']);folder.mkdir()
        child_before=resource.getrusage(resource.RUSAGE_CHILDREN)
        child_start=time.monotonic_ns()
        process=subprocess.run([exe['path']],input=wire,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            cwd=empty,env={'PATH':str(empty),'HOME':str(empty),'LANG':'C'},preexec_fn=limits,timeout=600)
        child_wall=time.monotonic_ns()-child_start
        child_after=resource.getrusage(resource.RUSAGE_CHILDREN)
        (folder/'stdout.bin').write_bytes(process.stdout);(folder/'stderr.bin').write_bytes(process.stderr)
        record={'suite':suite,'case':old['case'],'profile':profile,'source_case':str(case),
            'raw_bytes':len(wire),'raw_sha256':sha256(wire).hexdigest(),'returncode':process.returncode,
            'stdout_bytes':len(process.stdout),'stdout_sha256':sha256(process.stdout).hexdigest(),
            'stderr_bytes':len(process.stderr),'stderr_sha256':sha256(process.stderr).hexdigest(),
            'executable_sha256':exe['sha256'],'new_primitive_oracle_status':gate_status,
            'child_wall_ns':child_wall,'child_user_seconds':child_after.ru_utime-child_before.ru_utime,
            'child_system_seconds':child_after.ru_stime-child_before.ru_stime}
        (folder/'actual.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
        if expected_output is not None:
            assert process.returncode==0 and process.stderr==b'' and process.stdout==expected_output,(suite,old['case'],record)
        else:
            assert process.returncode==2 and process.stdout==b'' and len(process.stderr)==128,(suite,old['case'],record)
            actual=list(struct.unpack('<16Q',process.stderr));record['frame']=actual
            if gate_status:
                assert actual[4:6]==[8,gate_status] and actual[6:11]==expected_frame[6:11],(suite,old['case'],actual,expected_frame)
            else:
                if suite in ('profiles','boundaries'):expected_frame[2]=72
                assert actual==expected_frame,(suite,old['case'],actual,expected_frame)
        record['status']='PASS';results.append(record)
        (folder/'result.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
        print(json.dumps(record,sort_keys=True),flush=True)
    summary.update(status='PASS',cases=len(results),suites={name:sum(r['suite']==name for r in results) for name,_,_ in suites})
except BaseException as exc:
    summary.update(status='FAIL',cases_completed=len(results),error_class=type(exc).__name__,error=str(exc));raise
finally:
    bundle.close();assert all(p.read_bytes()==raw for p,raw in pins.items())
    summary['all_source_and_executable_pins_unchanged']=True
    summary['wall_elapsed_ns']=time.monotonic_ns()-start
    (dest/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='results'},sort_keys=True),flush=True)
