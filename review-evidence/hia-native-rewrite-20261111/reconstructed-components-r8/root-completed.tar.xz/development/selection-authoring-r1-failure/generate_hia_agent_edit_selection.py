"""Native original selection policy followed by exact integer packet emission.

Core is an actually admitted immutable SourceIndexLease. Selector values retain
their general Graph kinds until fields and identities have been checked in the
original order. Unmatched surrogate/large string names therefore fail lookup,
not an earlier JSON/UTF8 serializer. The resulting typed packet still goes to
the actual native packet issuer before facts/query owners consume its index.
"""
from __future__ import annotations
import ast
from hashlib import sha256
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_query_packet as packet
from tools import generate_hia_agent_edit_apply_graph as graph

CONSTANTS={'COMMAND':int.from_bytes(b'HIAQSC01','little'),'STATE':int.from_bytes(b'HIAQSW01','little'),
           'EVENT':int.from_bytes(b'HIAQSE01','little'),'BAD':0xfffffffd,'MAX':(1<<64)-1,'REF':1<<63,
           'MODE':160,'CURSOR':168,'BASE':176,'ERROR':184}
CORE_LABELS=('functions','name','blocks','id','ops','out','function','block','output','fields','args','attrs','op')
GRAPH_LABELS=('args','attrs','op')
SOURCE=r'''
def selection(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) == 2:
        return refuse(w, 1)
    if length(r) < 256 or word(r, 0) != COMMAND or word(r, 16) == 0 or word(r, 24) == 0:
        return refuse(w, 2)
    if source_lease(s) == 0 or graph_shape(r, 128, length(r) - 128) == 0:
        return refuse(w, 3)
    i = 40
    while i < 72:
        if word(r, i) == 0 or word(r, i) > word(r, 144):
            return refuse(w, 4)
        i = i + 8
    i = 72
    while i < 128:
        if word(r, i) != 0:
            return refuse(w, 5)
        i = i + 8
    if get(w, 8) == 0:
        if word(r, 8) != 1 or word(r, 32) != 0:
            return refuse(w, 6)
        i = 0
        while i < 1024:
            if byte(w, i) != 0:
                return refuse(w, 7)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(r, 16))
        put(w, 24, word(r, 24))
        put(w, 40, length(s))
        put(w, 48, length(r))
        copy_bytes(w, r, 512, 40, 152)
        copy_bytes(w, s, 664, 0, 64)
        error = select(s, r, w)
        if error != 0:
            put(w, ERROR, error)
            put(w, 8, 2)
            return event(w, 2)
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or word(r, 8) != 2:
            return refuse(w, 8)
        if word(r, 16) != get(w, 16) or word(r, 24) != get(w, 24) or word(r, 32) != get(w, 32):
            return refuse(w, 9)
        if length(s) != get(w, 40) or length(r) != get(w, 48):
            return refuse(w, 10)
        i = 0
        while i < 152:
            if byte(r, 40 + i) != byte(w, 512 + i):
                return refuse(w, 11)
            i = i + 1
        i = 0
        while i < 64:
            if byte(s, i) != byte(w, 664 + i):
                return refuse(w, 12)
            i = i + 1
    put(w, MODE, 0)
    put(w, CURSOR, 0)
    put(w, BASE, 1024)
    project(s, r, w)
    if get(w, ERROR) != 0 or get(w, CURSOR) > 67108864:
        return refuse(w, 13)
    put(w, 224, get(w, CURSOR))
    put(w, 56, 1024 + get(w, CURSOR))
    if get(w, 56) > length(w):
        return event(w, 1)
    put(w, MODE, 1)
    put(w, CURSOR, 0)
    project(s, r, w)
    if get(w, ERROR) != 0 or get(w, CURSOR) != get(w, 224):
        return refuse(w, 14)
    put(w, 8, 2)
    return event(w, 0)

def same_name(s:readbuf, r:readbuf, id_:u64, view:u64) -> u64:
    if g_kind(r, id_) != 4 or kind(r, s, view) != 4:
        return 0
    size = word(r, 128 + id_ * 64 + 16)
    if size != text_size(r, s, view):
        return 0
    begin = word(r, 128 + id_ * 64 + 8)
    if begin > length(r) - 128 or size > length(r) - 128 - begin:
        return 0
    i = 0
    while i < size:
        if byte(r, 128 + begin + i) != text_byte(r, s, view, i):
            return 0
        i = i + 1
    return 1

def select(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    fields = word(r, 64)
    if g_kind(r, fields) != 5 and g_kind(r, fields) != 7:
        return 1
    if g_amount(r, fields) == 0 or g_amount(r, fields) > 3:
        return 1
    mask = 0
    i = 0
    while i < g_amount(r, fields):
        value = g_element(r, fields, i)
        bit = 0
        if g_text_is(r, value, G_args) != 0:
            bit = 1
        elif g_text_is(r, value, G_attrs) != 0:
            bit = 2
        elif g_text_is(r, value, G_op) != 0:
            bit = 4
        if bit == 0 or (mask & bit) != 0:
            return 1
        mask = mask | bit
        i = i + 1
    put(w, 104, mask)
    if g_kind(r, word(r, 40)) != 4 or g_kind(r, word(r, 48)) != 4 or g_kind(r, word(r, 56)) != 4:
        return 2
    functions = field(r, s, REF, L_functions)
    fn = child(r, s, functions, 0)
    i = 0
    while i < count(r, s, functions):
        if same_name(s, r, word(r, 40), field(r, s, fn, L_name)) != 0:
            put(w, 64, fn)
            break
        fn = following(r, s, fn)
        i = i + 1
    if get(w, 64) == 0:
        return 3
    blocks = field(r, s, get(w, 64), L_blocks)
    block = child(r, s, blocks, 0)
    i = 0
    while i < count(r, s, blocks):
        if same_name(s, r, word(r, 48), field(r, s, block, L_id)) != 0:
            put(w, 72, block)
            put(w, 88, i)
            break
        block = following(r, s, block)
        i = i + 1
    if get(w, 72) == 0:
        return 4
    ops = field(r, s, get(w, 72), L_ops)
    op = child(r, s, ops, 0)
    i = 0
    while i < count(r, s, ops):
        name = output_name(s, r, op, word(r, 56))
        if name != 0:
            put(w, 80, op)
            put(w, 96, i)
            put(w, 120, name)
            return 0
        op = following(r, s, op)
        i = i + 1
    return 5

def output_name(s:readbuf, r:readbuf, op:u64, id_:u64) -> u64:
    outputs = field(r, s, op, L_out)
    value = child(r, s, outputs, 0)
    i = 0
    while i < count(r, s, outputs):
        name = field(r, s, value, L_name)
        if same_name(s, r, id_, name) != 0:
            return name
        value = following(r, s, value)
        i = i + 1
    return 0

def project(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    root = container(w, 5, 2)
    source_value(s, w, REF)
    selection = container(w, 6, 4)
    literal(w, L_function)
    source_value(s, w, field(r, s, get(w, 64), L_name))
    literal(w, L_block)
    source_value(s, w, field(r, s, get(w, 72), L_id))
    literal(w, L_output)
    source_value(s, w, get(w, 120))
    literal(w, L_fields)
    fields = word(r, 64)
    list_ = container(w, 5, g_amount(r, fields))
    i = 0
    while i < g_amount(r, fields):
        value = g_element(r, fields, i)
        if g_text_is(r, value, G_args) != 0:
            literal(w, L_args)
        elif g_text_is(r, value, G_attrs) != 0:
            literal(w, L_attrs)
        else:
            literal(w, L_op)
        i = i + 1
    finish(w, list_)
    finish(w, selection)
    return finish(w, root)

def event(w:mutbuf, action:u64) -> u32:
    if get(w, 32) == MAX:
        put(w, 8, 3)
        return BAD
    put(w, 32, get(w, 32) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 56))
    put(w, 304, 1024)
    put(w, 312, get(w, 224))
    put(w, 320, get(w, ERROR))
    put(w, 328, get(w, 64))
    put(w, 336, get(w, 72))
    put(w, 344, get(w, 80))
    put(w, 352, get(w, 88))
    put(w, 360, get(w, 96))
    put(w, 368, get(w, 104))
    put(w, 376, 0)
    return 384

def refuse(w:mutbuf, reason:u64) -> u32:
    put(w, 8, 3)
    put(w, ERROR, reason)
    event(w, 3)
    return BAD
'''

def source_program():
    assert sha256(Path(shared.__file__).read_bytes()).hexdigest()=='555472263213f15deb239fcf3bf8e5b273a28caf3a67bb29ffd037f171d7ae5c'
    labels={}
    for prefix,values,parts in (('L_',CORE_LABELS,3),('G_',GRAPH_LABELS,4)):
        for value in values:
            raw=value.encode();labels[prefix+value]=[len(raw),*(int.from_bytes(raw[i*8:i*8+8],'little') for i in range(parts))]
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
        def visit_Call(self,node):
            node=self.generic_visit(node);args=[]
            for arg in node.args:
                if isinstance(arg,ast.Name) and arg.id in labels:args.extend(ast.Constant(v) for v in labels[arg.id])
                else:args.append(arg)
            node.args=args;return node
    own=Expand().visit(ast.parse(SOURCE)).body
    p={n.name:n for n in ast.parse(packet.source_program()).body}
    g={n.name:n for n in ast.parse(graph.source_program()).body}
    rename={'gkind':'g_kind','amount':'g_amount','element':'g_element','text_is':'g_text_is'}
    class GraphOffset(ast.NodeTransformer):
        def visit_FunctionDef(self,node):
            node=self.generic_visit(node);node.name=rename.get(node.name,node.name);return node
        def visit_Call(self,node):
            node=self.generic_visit(node)
            if isinstance(node.func,ast.Name):
                name=node.func.id
                if name in rename:node.func.id=rename[name]
                elif name in ('word','byte') and isinstance(node.args[0],ast.Name) and node.args[0].id=='s':
                    node.args[1]=ast.BinOp(ast.Constant(128),ast.Add(),node.args[1])
                elif name=='length' and isinstance(node.args[0],ast.Name) and node.args[0].id=='s':
                    return ast.BinOp(node,ast.Sub(),ast.Constant(128))
            return node
    gs=[GraphOffset().visit(g[n]) for n in rename]
    helpers=('source_lease','valid_ref','reserve','header','literal','container','finish','source_value','fail',
             'word','get','put','resolved','kind','count','child','following','text_size','text_byte','text_is','field')
    tree=ast.Module(body=own+gs+[g['graph_shape']]+[p[n] for n in helpers],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['selection']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=shared.CopyBuilder(node,names,signatures,total);builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],'returns':[builder.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_selection','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_selection.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
