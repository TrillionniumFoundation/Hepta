# Complete native single edit display — component ABI r1

This HIA owner implements the complete `render_edit_context` checked method,
including its original public error categories and output formatting. Actual
qualification is recorded separately; this contract alone is not a test result.
The source is an immutable private GraphLease using the frozen general wire r3.
A complete mechanical foreign capture remains a development transport, not a
closed public resource boundary. No public selector is activated by this file.

## Three-buffer protocol

The external RWW entry takes the Graph as read buffer, a command or actual wire
workspace as the second buffer (internally borrowed read-only), and the owned
renderer workspace. Fresh workspace is zeroed and at least 32768 bytes. BEGIN is
exactly 64 bytes/eight little-endian u64 words:

`[HIAERC01, graphLease, request, rootID, integerDigitLimit, 0, 0, 0]`

The fixed executor binds the Graph to its actual immutable issuer; identifiers
and header equality do not authenticate supplied foreign memory. Root selection
allows the same Graph to carry a nested query. The complete original top-level
field/schema check runs before the first bounded-wire request.

Ordinary entry returns 128 and publishes sixteen words at workspace offset 0:

`[HIAERE01, action, graphLease, request, wireSequence, phase, neededWorkspace,`
` outputOffset, outputBytes, errorDomain, errorCode, pendingWireRoot,`
` wireCommandOffset, wireCommandBytes, errorCause, abiReason]`

Action 0 is complete UTF-8 display; 1 is GROW; 2 requests the actual pinned wire
service; 3 is a semantic rejection with its entire exact public diagnostic text
in the output view. Domain 1 is E_HIA_QUERY and domain 2 is the original E_HIA_EDIT
bounded-wire rejection. ABI failure returns 0xfffffffd and ends the lease before
any stale event is consumed. Completed/rejected leases cannot be reused. Short
workspaces that cannot retain poison must be discarded by the fixed executor.

Action 2 contains a complete native HIAGWC01 command at offset 128, size 64. The
executor invokes the pinned Graph scan/emit pair on a fresh wire workspace and
forwards the **actual complete final wire workspace** as the next second buffer.
The renderer independently checks its event magic, action, lease, sequence, root,
1 MiB budget, flags 3, numeric runtime profile, phase and output bounds. It copies
any required returned bytes into its own arena. Neither executor nor adapter
constructs wire values, parses display fields, sorts instructions, or chooses
errors.

GROW copies the whole renderer workspace and preserves the Graph. Phase 21 GROW
retains and replays the same actual wire reply lease because its output still
needs copying. Phase 2/30/98 GROW resumes with an empty second buffer; these phases
use owned offsets and the immutable Graph only. The executor does not repeat a
completed wire call. Native code owns all sequence advancement and requests.

## Exact semantics and deferred pure subtree bytes

The first `_wire(query)` remains at the original point, after exact top fields
and schema and before all later shape, name, signature and CFG checks. Once it
succeeds, HIA builds a complete text rope and placeholders for later subtree
canonical byte strings while applying the original validation order. It then
resolves those pure placeholders through the same native wire owner and emits
the whole final UTF-8 text. Output has no new 1 MiB cap: only the original input
wire gate has that limit. Dynamic workspace growth is not an added language
quota or a shortened display.

The reordering of pure byte production is justified only for the same immutable
Graph and identical numeric profile/ASCII/sort settings. If the whole query
passes the complete bounded wire gate, every reachable subtree passes it: DFS
node/queued/depth costs cannot increase on removing surrounding occurrences;
active-cycle rejection already covers every reachable cycle; string, number,
key conversion/collision and key comparability checks already visited the
subtree; its compact canonical bytes are literally a contiguous subexpression
of the complete canonical value and hence at most the same 1 MiB. Therefore
later `_wire` operations cannot introduce a new semantic error after this gate.
No validation is performed in the host, and this argument does not cover mutable
Graph payloads, forged dependency replies, or a changed runtime profile.

The HIA code preserves all declared signature/loan rules, selected identity
checks, all-index capture before type/duplicate rejection, exact integer index
sorting, 256 visible operations, 64 visible blocks, downstream typed parameter
and branch rules, callee order, and complete formatting. It also preserves
existing weaker accepted shapes: tuple iterations, empty iterable output lists,
string/dict argument iteration, truthy non-dict attributes, and unrestricted
JSON metadata that the original input wire permits. Wrong lexical names retain
the original wrapper's generic malformed-presentation text; wrong type/empty or
overlong names retain the explicit invalid-identity text.

The batch renderer, its initial integer-JSON decoding boundary, and bounded
foreign capture are separate owners still to be integrated. This component does
not change that batch boundary or remove the hosted reference implementations.
