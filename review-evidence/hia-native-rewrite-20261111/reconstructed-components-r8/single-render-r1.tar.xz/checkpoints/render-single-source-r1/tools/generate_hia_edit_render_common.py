"""Fixed HIA authoring shared by complete Agent edit display owners."""
from __future__ import annotations
import ast
from tools.generate_hia_graph_wire_common import COMMON as GRAPH_COMMON

FIELDS = ['schema','base_sha256','input_sha256','selector','fields','operation_sha256','context','scope',
          'function','block','output','name','params','returns','effects','return_loans','type','callees',
          'operation','out','args','attrs','op','block_params','operation_index','dependencies','consumers',
          'index','terminator','downstream','id','affected_params','branch_condition_affected','control_reachable',
          'sites','application','site','query']
QUERY_ERRORS = {
 1:'malformed edit presentation',
 2:'expected exact prepared edit query fields',
 3:'malformed edit context/selector',
 4:'invalid rendered selector fields',
 5:'invalid rendered field selection',
 6:'displayed function signature requires exactly its declared fields',
 7:'invalid displayed function signature lists',
 8:'invalid displayed parameter',
 9:'duplicate displayed parameter',
 10:'return_loans must match displayed return arity',
 11:'nonloan return must have a null origin',
 12:'returned loan must name an input loan parameter',
 13:'mutable returned loan needs a mutable input loan',
 14:'invalid displayed callee list',
 15:'rendered function disagrees with selector',
 16:'rendered SSA output disagrees with selector',
 17:'invalid Agent display identity',
 18:'rendered operation index must be a nonnegative integer',
 19:'rendered SSA context lists are malformed',
 20:'rendered SSA operation budget exceeded',
 21:'duplicate or noninteger rendered SSA indexes',
 22:'missing verified CFG downstream presentation',
 23:'rendered CFG context exceeds block budget',
 24:'malformed downstream CFG block presentation',
 25:'duplicate/selected downstream CFG block',
 26:'invalid downstream SSA block parameters',
 27:'invalid downstream typed SSA parameter',
 28:'duplicate downstream block parameter',
 29:'invalid control-reachable CFG flag',
 30:'unbound downstream affected SSA parameter',
 31:'invalid downstream SSA operation collections',
 32:'rendered CFG context exceeds SSA operation budget',
 33:'invalid downstream SSA operation record',
 34:'duplicate or invalid downstream SSA operation index',
 35:'invalid downstream branch-affect flag',
 36:'invalid downstream terminator',
 37:'non-branch CFG flagged as affected condition',
}
WIRE_ERRORS = {
1:'invalid JSON output byte budget',2:'JSON string exceeds byte budget before encoding',
3:'unpaired Unicode surrogate in UTF-8 JSON',4:'JSON input exceeds nesting depth before encoding',
5:'JSON input exceeds node/byte budget',6:'JSON container exceeds queued-node/byte budget',
7:'cyclic JSON container',8:'unsupported JSON object key',9:'JSON key exceeds numeric byte budget',
10:'nonfinite JSON object key',11:'JSON key exceeds byte budget',
12:'JSON object key collision after JSON conversion',13:'JSON integer exceeds byte budget',
14:'non-JSON in-process value',15:'invalid bounded JSON',16:'JSON encoding exceeds byte budget'}
TEXT = [
 'hepta.hia.edit-query.v2','hepta.hia.edit-query.v3','readbuf','mutbuf','branch',
 'function ','fn ','(',') -> ',' effects{','}',':',', ', ',',')','block ','%',' = ','=',
 'EDIT ','\n',' return_loans',' ','downstream block ',') affected{',
 'affected-branch reachable region (all operations shown)',
 'affected branch condition (control dependence unproved)','callee ',
]
LITERALS=list(dict.fromkeys(FIELDS+TEXT+['E_HIA_QUERY: '+v for v in QUERY_ERRORS.values()]
                              +['E_HIA_EDIT: '+v for v in WIRE_ERRORS.values()]))
LIT={text:index for index,text in enumerate(LITERALS)}
CONSTANTS={
 'GRAPH_MAGIC':int.from_bytes(b'HIAGRF01','little'),
 'COMMAND_MAGIC':int.from_bytes(b'HIAERC01','little'),
 'EVENT_MAGIC':int.from_bytes(b'HIAERE01','little'),
 'STATE_MAGIC':int.from_bytes(b'HIAERW01','little'),
 'WIRE_COMMAND':int.from_bytes(b'HIAGWC01','little'),
 'WIRE_EVENT':int.from_bytes(b'HIAGWE01','little'),
 'BAD':0xfffffffd,'MAX':(1<<64)-1,'CHAR':1<<63,
 'MIN_WORK':32768,'OPS':1024,'SEEN':5120,'LITERAL_TABLE':8192,
}
NAMES=('MAGIC BAD PHASE LEASE SEQ ROOT DIGITS SERVICE PENDING NEED ARENA HEAD TAIL '
       'OUTLEN OUTBASE ERROR DOMAIN CAUSE NODES EDGES DATABASE EDGEBASE TOTAL '
       'CONTEXT SELECTOR FUNCTION LOANS OPERATION SELECTED OP_COUNT VISIBLE SEEN_COUNT '
       'CURRENT WAIT_CHUNK PLAN_END').split()
CONSTANTS.update({'S_'+name:256+8*i for i,name in enumerate(NAMES)})
CONSTANTS.update({'F_'+name:LIT[name] for name in FIELDS})
def mask(*fields):return sum(1<<FIELDS.index(name) for name in fields)
CONSTANTS.update({
 'QUERY_FIELDS':mask('schema','base_sha256','input_sha256','selector','fields','operation_sha256','context','scope'),
 'SELECTOR_FIELDS':mask('function','block','output'),
 'SIGNATURE_FIELDS':mask('name','params','returns','effects'),
 'PARAM_FIELDS':mask('name','type'),
 'SUCCESSOR_FIELDS':mask('id','params','affected_params','dependencies','consumers','terminator','branch_condition_affected','control_reachable'),
 'ENTRY_FIELDS':mask('index','operation'),
})

COMMON = r'''
def error(w:mutbuf, code:u64) -> u64:
    if get(w, S_ERROR) == 0:
        put(w, S_ERROR, code)
        put(w, S_DOMAIN, 1)
    return 0

def reserve(w:mutbuf, size:u64) -> u64:
    at = get(w, S_ARENA)
    if at > length(w):
        return abi(w, 29)
    if size > MAX - at:
        return abi(w, 30)
    if size > length(w) - at:
        put(w, S_NEED, at + size)
        return 0
    put(w, S_ARENA, at + size)
    return at

def graph_header(g:readbuf, w:mutbuf) -> u64:
    if length(g) < 64 or read(g, 0) != GRAPH_MAGIC or read(g, 8) == 0 or read(g, 56) != 0:
        return abi(w, 31)
    count = read(g, 16)
    edges = read(g, 32)
    if count == 0 or count > (MAX - 64) >> 6:
        return abi(w, 32)
    edgebase = 64 + count * 64
    if edges > (MAX - edgebase) >> 3:
        return abi(w, 33)
    data = edgebase + edges * 8
    if data > length(g) or read(g, 40) != length(g) - data or read(g, 48) != length(g):
        return abi(w, 34)
    if get(w, S_MAGIC) == 0:
        put(w, S_NODES, count)
        put(w, S_EDGES, edges)
        put(w, S_DATABASE, data)
        put(w, S_EDGEBASE, edgebase)
        put(w, S_TOTAL, length(g))
    elif count != get(w, S_NODES) or edges != get(w, S_EDGES) or data != get(w, S_DATABASE) or length(g) != get(w, S_TOTAL):
        return abi(w, 35)
    return 1

def kind(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    if identifier == 0:
        return MAX
    if identifier >= CHAR:
        return 4
    at = node(g, w, identifier)
    if at == 0:
        return MAX
    return read(g, at)

def text_at(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    if identifier >= CHAR:
        return identifier - CHAR
    at = node(g, w, identifier)
    if at == 0:
        return 0
    return read(g, at + 8)

def text_size(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    if identifier >= CHAR:
        return 1
    at = node(g, w, identifier)
    if at == 0:
        return 0
    return read(g, at + 16)

def text_is(g:readbuf, w:mutbuf, identifier:u64, literal:u64) -> u64:
    if kind(g, w, identifier) != 4:
        return 0
    size = text_size(g, w, identifier)
    if size != get(w, LITERAL_TABLE + literal * 16 + 8):
        return 0
    left = text_at(g, w, identifier)
    right = get(w, LITERAL_TABLE + literal * 16)
    i = 0
    while i < size:
        if byte(g, left + i) != byte(w, right + i):
            return 0
        i = i + 1
    return 1

def same(g:readbuf, w:mutbuf, left:u64, right:u64) -> u64:
    if kind(g, w, left) != 4 or kind(g, w, right) != 4:
        return 0
    size = text_size(g, w, left)
    if size != text_size(g, w, right):
        return 0
    a = text_at(g, w, left)
    b = text_at(g, w, right)
    i = 0
    while i < size:
        if byte(g, a + i) != byte(g, b + i):
            return 0
        i = i + 1
    return 1

def field(g:readbuf, w:mutbuf, identifier:u64, literal:u64) -> u64:
    if kind(g, w, identifier) != 6:
        return 0
    at = node(g, w, identifier)
    i = 0
    while i < read(g, at + 32):
        key = edge(g, w, at, i * 2)
        if text_is(g, w, key, literal) != 0:
            return edge(g, w, at, i * 2 + 1)
        i = i + 1
    return 0

def required(g:readbuf, w:mutbuf, identifier:u64, literal:u64) -> u64:
    value = field(g, w, identifier, literal)
    if value == 0:
        return error(w, 1)
    return value

def keys(g:readbuf, w:mutbuf, identifier:u64, wanted:u64) -> u64:
    if kind(g, w, identifier) != 6:
        return 0
    at = node(g, w, identifier)
    i = 0
    while i < read(g, at + 32):
        key = edge(g, w, at, i * 2)
        bit = field_bit(g, w, key)
        if bit == 0 or (wanted & bit) == 0:
            return 0
        wanted = wanted ^ bit
        i = i + 1
    return choose(wanted == 0, 1, 0)

def iter_count(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    k = kind(g, w, identifier)
    if k == 4:
        if identifier >= CHAR:
            return 1
        return read(g, node(g, w, identifier) + 48)
    if k == 5 or k == 6 or k == 7:
        return read(g, node(g, w, identifier) + 32)
    error(w, 1)
    return 0

def item(g:readbuf, w:mutbuf, identifier:u64, index:u64) -> u64:
    k = kind(g, w, identifier)
    if k == 4:
        if identifier >= CHAR:
            if index != 0:
                return error(w, 1)
            return identifier
        at = node(g, w, identifier)
        if index >= read(g, at + 48):
            return error(w, 1)
        return CHAR + read(g, at + 8) + index
    at = node(g, w, identifier)
    if at == 0:
        return 0
    if k == 6:
        return edge(g, w, at, index * 2)
    if k == 5 or k == 7:
        return edge(g, w, at, index)
    return error(w, 1)

def atom(g:readbuf, w:mutbuf, identifier:u64, dotted:u64) -> u64:
    if kind(g, w, identifier) != 4:
        return error(w, 17)
    count = 1
    if identifier < CHAR:
        count = read(g, node(g, w, identifier) + 48)
    if count == 0 or count > 128:
        return error(w, 17)
    at = text_at(g, w, identifier)
    size = text_size(g, w, identifier)
    start = 0
    i = 0
    while i <= size:
        if i == size or (dotted != 0 and byte(g, at + i) == 46):
            if segment(g, at + start, i - start) == 0:
                return error(w, 1)
            start = i + 1
        i = i + 1
    return identifier

def segment(g:readbuf, at:u64, size:u64) -> u64:
    if size == 0 or size > 128:
        return 0
    first = byte(g, at)
    if first != 95 and (first < 65 or first > 90) and (first < 97 or first > 122):
        return 0
    if size >= 6:
        if byte(g, at) == 95 and byte(g, at + 1) == 95 and byte(g, at + 2) == 104 and byte(g, at + 3) == 105 and byte(g, at + 4) == 97 and byte(g, at + 5) == 95:
            return 0
    i = 1
    while i < size:
        unit = byte(g, at + i)
        if unit != 95 and (unit < 65 or unit > 90) and (unit < 97 or unit > 122) and (unit < 48 or unit > 57):
            return 0
        i = i + 1
    return 1

def nonnegative(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    if kind(g, w, identifier) != 2:
        return 0
    return choose(read(g, node(g, w, identifier) + 48) == 0, 1, 0)

def integer_compare(g:readbuf, w:mutbuf, left:u64, right:u64) -> u64:
    a = node(g, w, left)
    b = node(g, w, right)
    x = read(g, a + 16)
    y = read(g, b + 16)
    if x != y:
        return choose(x < y, 1, 2)
    a = read(g, a + 8)
    b = read(g, b + 8)
    while x != 0:
        x = x - 1
        first = byte(g, a + x)
        second = byte(g, b + x)
        if first != second:
            return choose(first < second, 1, 2)
    return 0

def truth(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    k = kind(g, w, identifier)
    if k == 0:
        return 0
    at = node(g, w, identifier)
    if at == 0:
        return 0
    if k == 1:
        return read(g, at + 48)
    if k == 2 or k == 4 or k == 9:
        return choose(read(g, at + 16) != 0, 1, 0)
    if k == 3:
        return choose((read(g, read(g, at + 8)) & 9223372036854775807) != 0, 1, 0)
    if k == 5 or k == 6 or k == 7:
        return choose(read(g, at + 32) != 0, 1, 0)
    return 1

def table(w:mutbuf, count:u64) -> u64:
    slots = 2
    while slots < count * 2:
        if slots > MAX >> 1:
            return abi(w, 36)
        slots = slots * 2
    if slots > (MAX - 16) >> 4:
        return abi(w, 37)
    at = reserve(w, 16 + slots * 16)
    if at == 0:
        return 0
    put(w, at, slots - 1)
    fill_range(w, at + 8, 8 + slots * 16, 0)
    return at

def slot(g:readbuf, w:mutbuf, base:u64, name:u64) -> u64:
    if kind(g, w, name) != 4:
        return 0
    start = text_at(g, w, name)
    size = text_size(g, w, name)
    hash_ = 14695981039346656037
    i = 0
    while i < size:
        hash_ = (hash_ ^ byte(g, start + i)) * 1099511628211
        i = i + 1
    mask = get(w, base)
    index = hash_ & mask
    tried = 0
    while tried <= mask:
        at = base + 16 + index * 16
        old = get(w, at)
        if old == 0 or same(g, w, old, name) != 0:
            return at
        index = (index + 1) & mask
        tried = tried + 1
    return abi(w, 38)

def chunk(w:mutbuf, kind_:u64, offset:u64, size:u64) -> u64:
    at = reserve(w, 32)
    if at == 0:
        return 0
    if size > MAX - get(w, S_OUTLEN):
        return abi(w, 39)
    put(w, at, 0)
    put(w, at + 8, kind_)
    put(w, at + 16, offset)
    put(w, at + 24, size)
    if get(w, S_TAIL) == 0:
        put(w, S_HEAD, at)
    else:
        put(w, get(w, S_TAIL), at)
    put(w, S_TAIL, at)
    put(w, S_OUTLEN, get(w, S_OUTLEN) + size)
    return 1

def literal(w:mutbuf, identifier:u64) -> u64:
    return chunk(w, 2, get(w, LITERAL_TABLE + identifier * 16), get(w, LITERAL_TABLE + identifier * 16 + 8))

def text(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    if atom(g, w, identifier, 0) == 0:
        return 0
    return chunk(w, 1, text_at(g, w, identifier), text_size(g, w, identifier))

def checked_text(g:readbuf, w:mutbuf, identifier:u64) -> u64:
    return chunk(w, 1, text_at(g, w, identifier), text_size(g, w, identifier))

def wire_text(w:mutbuf, identifier:u64) -> u64:
    return chunk(w, 4, identifier, 0)

def new_line(w:mutbuf) -> u64:
    if get(w, S_HEAD) != 0:
        return lit(w, '\n')
    return 1

def params_text(g:readbuf, w:mutbuf, params:u64, compact:u64) -> u64:
    count = iter_count(g, w, params)
    if get(w, S_ERROR) != 0:
        return 0
    i = 0
    while i < count:
        parameter = item(g, w, params, i)
        name = required(g, w, parameter, F_name)
        if get(w, S_ERROR) != 0 or atom(g, w, name, 0) == 0:
            return 0
        typ = required(g, w, parameter, F_type)
        if get(w, S_ERROR) != 0 or atom(g, w, typ, 0) == 0:
            return 0
        if i != 0:
            if compact != 0:
                if lit(w, ',') == 0:
                    return 0
            elif lit(w, ', ') == 0:
                return 0
        if checked_text(g, w, name) == 0 or lit(w, ':') == 0 or checked_text(g, w, typ) == 0:
            return 0
        i = i + 1
    return 1

def atom_list(g:readbuf, w:mutbuf, values:u64, prefix:u64) -> u64:
    count = iter_count(g, w, values)
    if get(w, S_ERROR) != 0:
        return 0
    i = 0
    while i < count:
        value = item(g, w, values, i)
        if atom(g, w, value, 0) == 0:
            return 0
        if i != 0 and lit(w, ',') == 0:
            return 0
        if prefix != 0 and lit(w, '%') == 0:
            return 0
        if checked_text(g, w, value) == 0:
            return 0
        i = i + 1
    return 1
'''

def borrowed_graph_functions():
    wanted={'read','get','put','abi','node','edge'}
    return [node for node in ast.parse(GRAPH_COMMON).body if node.name in wanted]

def literal_functions():
    lines=['def field_bit(g:readbuf, w:mutbuf, identifier:u64) -> u64:']
    for index,name in enumerate(FIELDS):
        lines += [f'    if text_is(g, w, identifier, {LIT[name]}) != 0:',f'        return {1<<index}']
    lines += ['    return 0','', 'def initialize_literals(w:mutbuf) -> u64:']
    at=CONSTANTS['LITERAL_TABLE']+len(LITERALS)*16
    at=(at+7)&~7
    for index,value in enumerate(LITERALS):
        raw=value.encode('utf-8')
        lines += [f'    put(w, {CONSTANTS["LITERAL_TABLE"]+index*16}, {at})',
                  f'    put(w, {CONSTANTS["LITERAL_TABLE"]+index*16+8}, {len(raw)})']
        for i in range(0,len(raw),8):
            lines += [f'    put(w, {at+i}, {int.from_bytes(raw[i:i+8].ljust(8,bytes([0])),"little")})']
        at+=(len(raw)+7)&~7
    assert at<=32768
    lines += ['    return 1','', 'def error_literal(w:mutbuf) -> u64:']
    for code,value in QUERY_ERRORS.items():
        lines += [f'    if get(w, S_DOMAIN) == 1 and get(w, S_ERROR) == {code}:',
                  f'        return {LIT["E_HIA_QUERY: "+value]}']
    for code,value in WIRE_ERRORS.items():
        lines += [f'    if get(w, S_DOMAIN) == 2 and get(w, S_ERROR) == {code}:',
                  f'        return {LIT["E_HIA_EDIT: "+value]}']
    lines += [f'    return {LIT["E_HIA_QUERY: malformed edit presentation"]}']
    return ast.parse('\n'.join(lines)+'\n').body

