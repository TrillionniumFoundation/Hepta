"""Complete single edit-context rendering semantics in HIA."""
BODY=r'''
def render(g:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < MIN_WORK:
        if length(w) >= 768:
            put(w, S_BAD, 40)
        return BAD
    if get(w, S_BAD) != 0 or get(w, S_PHASE) >= 90:
        return BAD
    if graph_header(g, w) == 0:
        return refuse(w, 41)
    if get(w, S_MAGIC) == 0:
        if length(r) != 64 or read(r, 0) != COMMAND_MAGIC or read(r, 8) != read(g, 8):
            return refuse(w, 42)
        if read(r, 16) == 0 or read(r, 24) == 0 or read(r, 24) > get(w, S_NODES):
            return refuse(w, 43)
        if read(r, 40) != 0 or read(r, 48) != 0 or read(r, 56) != 0:
            return refuse(w, 44)
        put(w, S_MAGIC, STATE_MAGIC)
        put(w, S_LEASE, read(r, 8))
        put(w, S_SEQ, read(r, 16))
        put(w, S_ROOT, read(r, 24))
        put(w, S_DIGITS, read(r, 32))
        put(w, S_ARENA, MIN_WORK)
        initialize_literals(w)
        if keys(g, w, get(w, S_ROOT), QUERY_FIELDS) == 0:
            error(w, 2)
            return error_result(g, w)
        schema = field(g, w, get(w, S_ROOT), F_schema)
        if is_lit(g, w, schema, 'hepta.hia.edit-query.v2') == 0 and is_lit(g, w, schema, 'hepta.hia.edit-query.v3') == 0:
            error(w, 2)
            return error_result(g, w)
        put(w, S_LOANS, is_lit(g, w, schema, 'hepta.hia.edit-query.v3'))
        put(w, S_PHASE, 1)
        return wire_request(w, get(w, S_ROOT))
    if get(w, S_MAGIC) != STATE_MAGIC or read(g, 8) != get(w, S_LEASE):
        return refuse(w, 45)
    phase = get(w, S_PHASE)
    if phase == 1 or phase == 21:
        if wire_reply(g, r, w) == 0:
            return pending(g, w)
    elif phase == 2 or phase == 20 or phase == 30 or phase == 98:
        if length(r) != 0:
            return refuse(w, 46)
    else:
        return refuse(w, 47)
    return drive(g, w)

def event(w:mutbuf, action:u64) -> u32:
    put(w, 0, EVENT_MAGIC)
    put(w, 8, action)
    put(w, 16, get(w, S_LEASE))
    put(w, 24, get(w, S_SEQ))
    put(w, 32, get(w, S_SERVICE))
    put(w, 40, get(w, S_PHASE))
    put(w, 48, get(w, S_NEED))
    put(w, 56, choose(action == 0 or action == 3, get(w, S_OUTBASE), 0))
    put(w, 64, choose(action == 0 or action == 3, get(w, S_OUTLEN), 0))
    put(w, 72, get(w, S_DOMAIN))
    put(w, 80, get(w, S_ERROR))
    put(w, 88, get(w, S_PENDING))
    put(w, 96, choose(action == 2, 128, 0))
    put(w, 104, choose(action == 2, 64, 0))
    put(w, 112, get(w, S_CAUSE))
    put(w, 120, get(w, S_BAD))
    return 128

def refuse(w:mutbuf, reason:u64) -> u32:
    abi(w, reason)
    put(w, S_PHASE, 99)
    event(w, 3)
    return BAD

def pending(g:readbuf, w:mutbuf) -> u32:
    if get(w, S_BAD) != 0:
        return refuse(w, get(w, S_BAD))
    if get(w, S_ERROR) != 0:
        return error_result(g, w)
    if get(w, S_NEED) > length(w):
        return event(w, 1)
    return refuse(w, 48)

def wire_request(w:mutbuf, root:u64) -> u32:
    if get(w, S_SERVICE) == MAX:
        return refuse(w, 49)
    put(w, S_SERVICE, get(w, S_SERVICE) + 1)
    put(w, S_PENDING, root)
    put(w, 128, WIRE_COMMAND)
    put(w, 136, get(w, S_LEASE))
    put(w, 144, get(w, S_SERVICE))
    put(w, 152, root)
    put(w, 160, 1048576)
    put(w, 168, 3)
    put(w, 176, get(w, S_DIGITS))
    put(w, 184, 0)
    return event(w, 2)

def wire_reply(g:readbuf, r:readbuf, w:mutbuf) -> u64:
    if length(r) < 128 or read(r, 0) != WIRE_EVENT:
        return abi(w, 50)
    if read(r, 16) != get(w, S_LEASE) or read(r, 24) != get(w, S_SERVICE) or read(r, 32) != get(w, S_PENDING):
        return abi(w, 51)
    if read(r, 40) != 1048576 or read(r, 48) != 3 or read(r, 56) != get(w, S_DIGITS):
        return abi(w, 52)
    if read(r, 104) != 0 or read(r, 120) != 0:
        return abi(w, 53)
    if read(r, 8) == 3:
        if read(r, 112) != 99 or read(r, 64) < 1 or read(r, 64) > 16 or read(r, 72) > 2:
            return abi(w, 54)
        if read(r, 88) != 0 or read(r, 96) != 0:
            return abi(w, 55)
        put(w, S_DOMAIN, 2)
        put(w, S_ERROR, read(r, 64))
        put(w, S_CAUSE, read(r, 72))
        return 0
    if read(r, 8) != 0 or read(r, 112) != 90 or read(r, 64) != 0 or read(r, 72) != 0:
        return abi(w, 56)
    start = read(r, 88)
    size = read(r, 96)
    if start > length(r) or size == 0 or size > length(r) - start or size > 1048576:
        return abi(w, 57)
    if get(w, S_PHASE) == 1:
        put(w, S_PHASE, 2)
        return 1
    at = reserve(w, size)
    if at == 0:
        return 0
    copy_bytes(w, r, at, start, size)
    chunk_ = get(w, S_WAIT_CHUNK)
    if size > MAX - get(w, S_OUTLEN):
        return abi(w, 58)
    put(w, chunk_ + 8, 2)
    put(w, chunk_ + 16, at)
    put(w, chunk_ + 24, size)
    put(w, S_OUTLEN, get(w, S_OUTLEN) + size)
    put(w, S_CURRENT, get(w, chunk_))
    put(w, S_PHASE, 20)
    return 1

def drive(g:readbuf, w:mutbuf) -> u32:
    put(w, S_NEED, 0)
    if get(w, S_PHASE) == 98:
        return error_result(g, w)
    if get(w, S_PHASE) == 2:
        put(w, S_ARENA, MIN_WORK)
        put(w, S_HEAD, 0)
        put(w, S_TAIL, 0)
        put(w, S_OUTLEN, 0)
        put(w, S_SEEN_COUNT, 0)
        if single_plan(g, w) == 0:
            return pending(g, w)
        put(w, S_CURRENT, get(w, S_HEAD))
        put(w, S_PHASE, 20)
    if get(w, S_PHASE) == 20:
        cursor = get(w, S_CURRENT)
        while cursor != 0:
            if get(w, cursor + 8) == 4:
                put(w, S_WAIT_CHUNK, cursor)
                put(w, S_PHASE, 21)
                return wire_request(w, get(w, cursor + 16))
            cursor = get(w, cursor)
            put(w, S_CURRENT, cursor)
        put(w, S_PHASE, 30)
    if get(w, S_PHASE) == 30:
        if emit_rope(g, w) == 0:
            return pending(g, w)
        put(w, S_PHASE, 90)
        return event(w, 0)
    return refuse(w, 59)

def emit_rope(g:readbuf, w:mutbuf) -> u64:
    base = reserve(w, get(w, S_OUTLEN))
    if base == 0:
        return 0
    put(w, S_OUTBASE, base)
    cursor = get(w, S_HEAD)
    target = base
    while cursor != 0:
        size = get(w, cursor + 24)
        source = get(w, cursor + 16)
        if get(w, cursor + 8) == 1:
            copy_bytes(w, g, target, source, size)
        elif get(w, cursor + 8) == 2:
            i = 0
            while i < size:
                store(w, target + i, byte(w, source + i))
                i = i + 1
        else:
            return abi(w, 60)
        target = target + size
        cursor = get(w, cursor)
    if target != base + get(w, S_OUTLEN):
        return abi(w, 61)
    return 1

def error_result(g:readbuf, w:mutbuf) -> u32:
    if get(w, S_BAD) != 0:
        return refuse(w, get(w, S_BAD))
    put(w, S_PHASE, 98)
    put(w, S_ARENA, MIN_WORK)
    put(w, S_HEAD, 0)
    put(w, S_TAIL, 0)
    put(w, S_OUTLEN, 0)
    if literal(w, error_literal(w)) == 0 or emit_rope(g, w) == 0:
        if get(w, S_BAD) != 0:
            return refuse(w, get(w, S_BAD))
        return event(w, 1)
    put(w, S_PHASE, 99)
    return event(w, 3)

def signature(g:readbuf, w:mutbuf, value:u64) -> u64:
    fields = SIGNATURE_FIELDS
    if get(w, S_LOANS) != 0:
        fields = fields | (1 << F_return_loans)
    if keys(g, w, value, fields) == 0:
        return error(w, 6)
    if atom(g, w, field(g, w, value, F_name), 0) == 0:
        return 0
    params = field(g, w, value, F_params)
    returns = field(g, w, value, F_returns)
    effects = field(g, w, value, F_effects)
    if kind(g, w, params) != 5 or kind(g, w, returns) != 5 or kind(g, w, effects) != 5:
        return error(w, 7)
    names = table(w, iter_count(g, w, params))
    if names == 0:
        return 0
    i = 0
    while i < iter_count(g, w, params):
        parameter = item(g, w, params, i)
        if keys(g, w, parameter, PARAM_FIELDS) == 0:
            return error(w, 8)
        name = atom(g, w, field(g, w, parameter, F_name), 0)
        if name == 0:
            return 0
        typ = atom(g, w, field(g, w, parameter, F_type), 0)
        if typ == 0:
            return 0
        at = slot(g, w, names, name)
        if at == 0:
            return 0
        if get(w, at) != 0:
            return error(w, 9)
        put(w, at, name)
        put(w, at + 8, typ)
        i = i + 1
    i = 0
    while i < iter_count(g, w, returns):
        if atom(g, w, item(g, w, returns, i), 0) == 0:
            return 0
        i = i + 1
    i = 0
    while i < iter_count(g, w, effects):
        if atom(g, w, item(g, w, effects, i), 0) == 0:
            return 0
        i = i + 1
    if get(w, S_LOANS) == 0:
        return 1
    origins = field(g, w, value, F_return_loans)
    if kind(g, w, origins) != 5 or iter_count(g, w, origins) != iter_count(g, w, returns):
        return error(w, 10)
    return signature_origins(g, w, returns, origins, names)

def signature_origins(g:readbuf, w:mutbuf, returns:u64, origins:u64, names:u64) -> u64:
    i = 0
    while i < iter_count(g, w, returns):
        typ = item(g, w, returns, i)
        origin = item(g, w, origins, i)
        if is_lit(g, w, typ, 'readbuf') == 0 and is_lit(g, w, typ, 'mutbuf') == 0:
            if kind(g, w, origin) != 0:
                return error(w, 11)
        else:
            if kind(g, w, origin) != 4:
                return error(w, 12)
            at = slot(g, w, names, origin)
            if at == 0:
                return 0
            input_ = get(w, at + 8)
            if is_lit(g, w, input_, 'readbuf') == 0 and is_lit(g, w, input_, 'mutbuf') == 0:
                return error(w, 12)
            if is_lit(g, w, typ, 'mutbuf') != 0 and is_lit(g, w, input_, 'mutbuf') == 0:
                return error(w, 13)
        i = i + 1
    return 1

def single_plan(g:readbuf, w:mutbuf) -> u64:
    root = get(w, S_ROOT)
    context = field(g, w, root, F_context)
    selector = field(g, w, root, F_selector)
    if kind(g, w, context) != 6 or kind(g, w, selector) != 6:
        return error(w, 3)
    put(w, S_CONTEXT, context)
    put(w, S_SELECTOR, selector)
    if keys(g, w, selector, SELECTOR_FIELDS) == 0:
        return error(w, 4)
    fields = field(g, w, root, F_fields)
    if kind(g, w, fields) != 5 or iter_count(g, w, fields) == 0 or iter_count(g, w, fields) > 3:
        return error(w, 5)
    seen = 0
    i = 0
    while i < iter_count(g, w, fields):
        value = item(g, w, fields, i)
        bit = 0
        if text_is(g, w, value, F_op) != 0:
            bit = 1
        elif text_is(g, w, value, F_args) != 0:
            bit = 2
        elif text_is(g, w, value, F_attrs) != 0:
            bit = 4
        if bit == 0 or (seen & bit) != 0:
            return error(w, 5)
        seen = seen | bit
        i = i + 1
    fn = required(g, w, context, F_function)
    if get(w, S_ERROR) != 0 or signature(g, w, fn) == 0:
        return 0
    put(w, S_FUNCTION, fn)
    callees = required(g, w, context, F_callees)
    if get(w, S_ERROR) != 0:
        return 0
    if kind(g, w, callees) != 5:
        return error(w, 14)
    i = 0
    while i < iter_count(g, w, callees):
        if signature(g, w, item(g, w, callees, i)) == 0:
            return 0
        i = i + 1
    if selected_identity(g, w) == 0 or function_lines(g, w) == 0 or source_operations(g, w) == 0:
        return 0
    if downstream(g, w) == 0:
        return 0
    i = 0
    while i < iter_count(g, w, callees):
        if new_line(w) == 0 or lit(w, 'callee ') == 0 or wire_text(w, item(g, w, callees, i)) == 0:
            return 0
        i = i + 1
    return 1

def selected_identity(g:readbuf, w:mutbuf) -> u64:
    selector = get(w, S_SELECTOR)
    fn = get(w, S_FUNCTION)
    selected_fn = atom(g, w, field(g, w, selector, F_function), 0)
    if selected_fn == 0:
        return 0
    name = atom(g, w, field(g, w, fn, F_name), 0)
    if name == 0:
        return 0
    if same(g, w, selected_fn, name) == 0:
        return error(w, 15)
    selected = atom(g, w, field(g, w, selector, F_output), 0)
    if selected == 0:
        return 0
    operation = required(g, w, get(w, S_CONTEXT), F_operation)
    outputs = required(g, w, operation, F_out)
    if get(w, S_ERROR) != 0:
        return 0
    count = iter_count(g, w, outputs)
    if get(w, S_ERROR) != 0:
        return 0
    found = 0
    i = 0
    while i < count:
        name = required(g, w, item(g, w, outputs, i), F_name)
        if get(w, S_ERROR) != 0 or atom(g, w, name, 0) == 0:
            return 0
        if same(g, w, name, selected) != 0:
            found = 1
        i = i + 1
    if found == 0:
        return error(w, 16)
    put(w, S_OPERATION, operation)
    return 1

def function_lines(g:readbuf, w:mutbuf) -> u64:
    fn = get(w, S_FUNCTION)
    if lit(w, 'function ') == 0 or text(g, w, field(g, w, fn, F_name)) == 0 or lit(w, '(') == 0:
        return 0
    if params_text(g, w, field(g, w, fn, F_params), 0) == 0 or lit(w, ') -> ') == 0:
        return 0
    if atom_list(g, w, field(g, w, fn, F_returns), 0) == 0 or lit(w, ' effects{') == 0:
        return 0
    if atom_list(g, w, field(g, w, fn, F_effects), 0) == 0 or lit(w, '}') == 0:
        return 0
    if get(w, S_LOANS) != 0:
        if lit(w, ' return_loans') == 0 or wire_text(w, field(g, w, fn, F_return_loans)) == 0:
            return 0
    if new_line(w) == 0 or lit(w, 'block ') == 0:
        return 0
    if text(g, w, field(g, w, get(w, S_SELECTOR), F_block)) == 0 or lit(w, '(') == 0:
        return 0
    params = required(g, w, get(w, S_CONTEXT), F_block_params)
    if get(w, S_ERROR) != 0 or params_text(g, w, params, 0) == 0:
        return 0
    return lit(w, ')')

def source_operations(g:readbuf, w:mutbuf) -> u64:
    context = get(w, S_CONTEXT)
    selected = required(g, w, context, F_operation_index)
    if get(w, S_ERROR) != 0:
        return 0
    if nonnegative(g, w, selected) == 0:
        return error(w, 18)
    put(w, S_SELECTED, selected)
    deps = required(g, w, context, F_dependencies)
    consumers = required(g, w, context, F_consumers)
    if get(w, S_ERROR) != 0:
        return 0
    if kind(g, w, deps) != 5 or kind(g, w, consumers) != 5:
        return error(w, 19)
    count = iter_count(g, w, deps) + iter_count(g, w, consumers) + 1
    if count > 256:
        return error(w, 20)
    put(w, S_VISIBLE, count)
    if collect_operations(g, w, deps, consumers, 1, 21) == 0 or display_operations(g, w, 1) == 0:
        return 0
    term = required(g, w, context, F_terminator)
    if get(w, S_ERROR) != 0 or new_line(w) == 0:
        return 0
    return wire_text(w, term)

def collect_operations(g:readbuf, w:mutbuf, deps:u64, consumers:u64, selected:u64, code:u64) -> u64:
    first = iter_count(g, w, deps)
    second = iter_count(g, w, consumers)
    count = first + second + selected
    put(w, S_OP_COUNT, count)
    i = 0
    while i < first + second:
        if i < first:
            record = item(g, w, deps, i)
        else:
            record = item(g, w, consumers, i - first)
        index = required(g, w, record, F_index)
        if get(w, S_ERROR) != 0:
            return 0
        put(w, OPS + i * 16, index)
        put(w, OPS + i * 16 + 8, record)
        i = i + 1
    if selected != 0:
        put(w, OPS + i * 16, get(w, S_SELECTED))
        put(w, OPS + i * 16 + 8, 0)
    i = 0
    while i < count:
        if nonnegative(g, w, get(w, OPS + i * 16)) == 0:
            return error(w, code)
        i = i + 1
    i = 1
    while i < count:
        index = get(w, OPS + i * 16)
        record = get(w, OPS + i * 16 + 8)
        j = i
        while j != 0:
            old = get(w, OPS + (j - 1) * 16)
            relation = integer_compare(g, w, old, index)
            if relation == 0:
                return error(w, code)
            if relation == 1:
                break
            put(w, OPS + j * 16, old)
            put(w, OPS + j * 16 + 8, get(w, OPS + (j - 1) * 16 + 8))
            j = j - 1
        put(w, OPS + j * 16, index)
        put(w, OPS + j * 16 + 8, record)
        i = i + 1
    return 1

def display_operations(g:readbuf, w:mutbuf, selected:u64) -> u64:
    i = 0
    while i < get(w, S_OP_COUNT):
        record = get(w, OPS + i * 16 + 8)
        operation = get(w, S_OPERATION)
        if record != 0:
            operation = required(g, w, record, F_operation)
            if get(w, S_ERROR) != 0:
                return 0
        if new_line(w) == 0:
            return 0
        if selected != 0 and integer_compare(g, w, get(w, OPS + i * 16), get(w, S_SELECTED)) == 0:
            if lit(w, 'EDIT ') == 0:
                return 0
        if operation_line(g, w, operation, 0) == 0:
            return 0
        i = i + 1
    return 1

def validate_operation(g:readbuf, w:mutbuf, operation:u64) -> u64:
    outputs = required(g, w, operation, F_out)
    if get(w, S_ERROR) != 0:
        return 0
    count = iter_count(g, w, outputs)
    if get(w, S_ERROR) != 0:
        return 0
    i = 0
    while i < count:
        value = item(g, w, outputs, i)
        name = required(g, w, value, F_name)
        if get(w, S_ERROR) != 0 or atom(g, w, name, 0) == 0:
            return 0
        typ = required(g, w, value, F_type)
        if get(w, S_ERROR) != 0 or atom(g, w, typ, 0) == 0:
            return 0
        i = i + 1
    args = required(g, w, operation, F_args)
    if get(w, S_ERROR) != 0:
        return 0
    count = iter_count(g, w, args)
    if get(w, S_ERROR) != 0:
        return 0
    i = 0
    while i < count:
        if atom(g, w, item(g, w, args, i), 0) == 0:
            return 0
        i = i + 1
    required(g, w, operation, F_attrs)
    if get(w, S_ERROR) != 0:
        return 0
    name = required(g, w, operation, F_op)
    if get(w, S_ERROR) != 0:
        return 0
    return atom(g, w, name, 1)

def operation_line(g:readbuf, w:mutbuf, operation:u64, compact:u64) -> u64:
    name = validate_operation(g, w, operation)
    if name == 0:
        return 0
    outputs = field(g, w, operation, F_out)
    count = iter_count(g, w, outputs)
    i = 0
    while i < count:
        value = item(g, w, outputs, i)
        if i != 0 and lit(w, ',') == 0:
            return 0
        if lit(w, '%') == 0 or checked_text(g, w, field(g, w, value, F_name)) == 0 or lit(w, ':') == 0 or checked_text(g, w, field(g, w, value, F_type)) == 0:
            return 0
        i = i + 1
    if count != 0:
        if compact != 0:
            if lit(w, '=') == 0:
                return 0
        elif lit(w, ' = ') == 0:
            return 0
    if checked_text(g, w, name) == 0 or lit(w, '(') == 0 or atom_list(g, w, field(g, w, operation, F_args), 1) == 0 or lit(w, ')') == 0:
        return 0
    attrs = field(g, w, operation, F_attrs)
    if truth(g, w, attrs) != 0:
        if lit(w, ' ') == 0 or wire_text(w, attrs) == 0:
            return 0
    return 1

def downstream(g:readbuf, w:mutbuf) -> u64:
    values = field(g, w, get(w, S_CONTEXT), F_downstream)
    if kind(g, w, values) != 5:
        return error(w, 22)
    count = iter_count(g, w, values)
    if count > 63:
        return error(w, 23)
    i = 0
    while i < count:
        if successor(g, w, item(g, w, values, i)) == 0:
            return 0
        i = i + 1
    return 1

def successor(g:readbuf, w:mutbuf, value:u64) -> u64:
    if keys(g, w, value, SUCCESSOR_FIELDS) == 0:
        return error(w, 24)
    ident = atom(g, w, field(g, w, value, F_id), 0)
    if ident == 0:
        return 0
    if same(g, w, ident, field(g, w, get(w, S_SELECTOR), F_block)) != 0:
        return error(w, 25)
    i = 0
    while i < get(w, S_SEEN_COUNT):
        if same(g, w, ident, get(w, SEEN + i * 8)) != 0:
            return error(w, 25)
        i = i + 1
    put(w, SEEN + i * 8, ident)
    put(w, S_SEEN_COUNT, i + 1)
    params = field(g, w, value, F_params)
    affected = field(g, w, value, F_affected_params)
    if kind(g, w, params) != 5 or kind(g, w, affected) != 5:
        return error(w, 26)
    names = successor_params(g, w, params)
    if names == 0:
        return 0
    if successor_affected(g, w, value, params, affected, names) == 0:
        return 0
    if successor_entries(g, w, value) == 0:
        return 0
    branch = field(g, w, value, F_branch_condition_affected)
    if kind(g, w, branch) != 1:
        return error(w, 35)
    term = field(g, w, value, F_terminator)
    if kind(g, w, term) != 6:
        return error(w, 36)
    if new_line(w) == 0 or lit(w, 'downstream block ') == 0 or checked_text(g, w, ident) == 0 or lit(w, '(') == 0:
        return 0
    if params_text(g, w, params, 0) == 0 or lit(w, ') affected{') == 0 or atom_list(g, w, affected, 0) == 0 or lit(w, '}') == 0:
        return 0
    if truth(g, w, field(g, w, value, F_control_reachable)) != 0:
        if new_line(w) == 0 or lit(w, 'affected-branch reachable region (all operations shown)') == 0:
            return 0
    if truth(g, w, branch) != 0:
        if is_lit(g, w, field(g, w, term, F_op), 'branch') == 0:
            return error(w, 37)
        if new_line(w) == 0 or lit(w, 'affected branch condition (control dependence unproved)') == 0:
            return 0
    if display_operations(g, w, 0) == 0 or new_line(w) == 0:
        return 0
    return wire_text(w, term)

def successor_params(g:readbuf, w:mutbuf, params:u64) -> u64:
    count = iter_count(g, w, params)
    i = 0
    while i < count:
        if keys(g, w, item(g, w, params, i), PARAM_FIELDS) == 0:
            return error(w, 27)
        i = i + 1
    i = 0
    while i < count:
        if atom(g, w, field(g, w, item(g, w, params, i), F_name), 0) == 0:
            return 0
        i = i + 1
    names = table(w, count)
    if names == 0:
        return 0
    i = 0
    while i < count:
        name = field(g, w, item(g, w, params, i), F_name)
        at = slot(g, w, names, name)
        if at == 0:
            return 0
        if get(w, at) != 0:
            return error(w, 28)
        put(w, at, name)
        put(w, at + 8, 1)
        i = i + 1
    i = 0
    while i < count:
        if atom(g, w, field(g, w, item(g, w, params, i), F_type), 0) == 0:
            return 0
        i = i + 1
    return names

def successor_affected(g:readbuf, w:mutbuf, value:u64, params:u64, affected:u64, names:u64) -> u64:
    count = iter_count(g, w, affected)
    i = 0
    while i < count:
        if atom(g, w, item(g, w, affected, i), 0) == 0:
            return 0
        i = i + 1
    control = field(g, w, value, F_control_reachable)
    if kind(g, w, control) != 1:
        return error(w, 29)
    if count == 0 and truth(g, w, control) == 0:
        return error(w, 30)
    seen = table(w, count)
    if seen == 0:
        return 0
    i = 0
    while i < count:
        name = item(g, w, affected, i)
        at = slot(g, w, seen, name)
        parent = slot(g, w, names, name)
        if at == 0 or parent == 0:
            return 0
        if get(w, at) != 0 or get(w, parent) == 0:
            return error(w, 30)
        put(w, at, name)
        i = i + 1
    return 1

def successor_entries(g:readbuf, w:mutbuf, value:u64) -> u64:
    deps = field(g, w, value, F_dependencies)
    consumers = field(g, w, value, F_consumers)
    if kind(g, w, deps) != 5 or kind(g, w, consumers) != 5:
        return error(w, 31)
    first = iter_count(g, w, deps)
    second = iter_count(g, w, consumers)
    total = get(w, S_VISIBLE) + first + second
    if total > 256:
        return error(w, 32)
    put(w, S_VISIBLE, total)
    i = 0
    while i < first + second:
        if i < first:
            record = item(g, w, deps, i)
        else:
            record = item(g, w, consumers, i - first)
        if keys(g, w, record, ENTRY_FIELDS) == 0:
            return error(w, 33)
        i = i + 1
    return collect_operations(g, w, deps, consumers, 0, 34)
'''

