"""Author complete native single edit-context display."""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from hepta.hia_program import verify_program
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools.generate_hia_edit_render_common import (COMMON, CONSTANTS, LIT, borrowed_graph_functions,
                                                    literal_functions)
from tools.generate_hia_edit_render_single import BODY

class CopyBuilder(Builder):
    def expr(self, expression):
        if (isinstance(expression,ast.Call) and isinstance(expression.func,ast.Name)
                and expression.func.id=='copy_bytes'):
            values=[self.expr(value) for value in expression.args]
            assert len(values)==5 and values[0][1]=='mutbuf' and values[1][1]=='readbuf'
            return self.op('buffer.copy_range',values[:2]+[self.cast(value,'usize') for value in values[2:]])
        return super().expr(expression)

def authoring():
    nodes=ast.parse(BODY+COMMON).body+borrowed_graph_functions()+literal_functions()
    class Expand(ast.NodeTransformer):
        def visit_Call(self,node):
            if isinstance(node.func,ast.Name) and node.func.id in ('lit','is_lit'):
                name=node.func.id;literal=node.args[-1]
                assert isinstance(literal,ast.Constant) and type(literal.value) is str
                node.func.id='literal' if name=='lit' else 'text_is'
                node.args[-1]=ast.Constant(LIT[literal.value])
            return self.generic_visit(node)
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
    nodes=[Expand().visit(node) for node in nodes]
    definitions={node.name:node for node in nodes}
    assert len(definitions)==len(nodes)
    wanted={'render'};pending=['render']
    while pending:
        name=pending.pop()
        for node in ast.walk(definitions[name]):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
                target=node.func.id
                if target in definitions and target not in wanted:wanted.add(target);pending.append(target)
    return [node for node in nodes if node.name in wanted]

def document():
    nodes=authoring()
    names={node.name:'f'+str(index+1) for index,node in enumerate(nodes)}
    signatures={node.name:([arg.annotation.id for arg in node.args.args],node.returns.id) for node in nodes}
    total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],
                'entry':'b0','blocks':[{'id':'b0','params':params,'ops':[
                    {'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
                    {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],
                     'attrs':{'function':names['render']}},
                    {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],
                    'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=CopyBuilder(node,names,signatures,total)
        builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],
                          'returns':[builder.returns],'effects':['read','write','trap'],
                          'entry':'b0','blocks':builder.blocks})
    result=compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'edit_render_single',
                                 'functions':functions})
    fs=result['functions']
    limits=(len(fs),sum(len(f['blocks']) for f in fs),sum(len(b['ops']) for f in fs for b in f['blocks']),
            max(len(f['blocks']) for f in fs),max(len(b['params']) for f in fs for b in f['blocks']))
    if any(actual>maximum for actual,maximum in zip(limits,(128,1536,8192,256,16))):
        raise ValueError({'original_compiler_limits_exceeded':limits})
    verify_program(result)
    return result

def main():
    doc=document();raw=render_assembly(doc)
    path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/edit_render_single.hiaasm'
    path.write_text(raw)
    fs=doc['functions']
    print(len(raw.encode()),len(fs),sum(len(f['blocks']) for f in fs),
          sum(len(b['ops']) for f in fs for b in f['blocks']),max(len(f['blocks']) for f in fs),
          max(len(b['params']) for f in fs for b in f['blocks']))

if __name__=='__main__':main()

