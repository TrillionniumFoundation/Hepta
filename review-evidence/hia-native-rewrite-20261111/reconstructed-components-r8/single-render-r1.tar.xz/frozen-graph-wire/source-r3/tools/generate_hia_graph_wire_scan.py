"""Complete native bounded-JSON preflight over a private GraphLease."""
BODY = r'''
def scan(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < MIN_WORK:
        if length(w) >= 768:
            return refused(w, 30)
        return BAD
    if graph(s, r, w) == 0:
        return refused(w, 31)
    if get(w, S_PHASE) != 1:
        return refused(w, 32)
    if get(w, S_ERROR) != 0:
        return pending(w)
    while get(w, S_PHASE) == 1:
        stage = get(w, S_STAGE)
        ok = 0
        if stage == 0:
            ok = scan_enter(s, w)
        elif stage == 1:
            ok = scan_keys(s, w)
        elif stage == 2:
            ok = scan_next(s, w)
        else:
            return refused(w, 33)
        if ok == 0:
            return pending(w)
    if get(w, S_PHASE) != 2:
        return refused(w, 34)
    return event(w, 2)

def scan_enter(s:readbuf, w:mutbuf) -> u64:
    if get(w, S_DEPTH) > 128:
        return error(w, 4, 0)
    if get(w, S_QUEUED) == 0:
        return abi(w, 35)
    put(w, S_QUEUED, get(w, S_QUEUED) - 1)
    put(w, S_VISITED, get(w, S_VISITED) + 1)
    if get(w, S_VISITED) > get(w, S_BUDGET):
        return error(w, 5, 0)
    at = node(s, w, get(w, S_CUR))
    if at == 0:
        return 0
    kind = read(s, at)
    if kind == 5 or kind == 6 or kind == 7:
        count = read(s, at + 32)
        if count > get(w, S_BUDGET) - get(w, S_VISITED) - get(w, S_QUEUED):
            return error(w, 6, 0)
        put(w, S_QUEUED, get(w, S_QUEUED) + count)
        i = 0
        while i < get(w, S_LEVEL):
            if get(w, FRAME_BASE + i * 64 + 32) == read(s, at + 40):
                return error(w, 7, 0)
            i = i + 1
        if get(w, S_LEVEL) >= 129:
            return abi(w, 36)
        frame = FRAME_BASE + get(w, S_LEVEL) * 64
        put(w, frame, get(w, S_CUR))
        put(w, frame + 8, kind)
        put(w, frame + 16, count)
        put(w, frame + 24, count)
        put(w, frame + 32, read(s, at + 40))
        put(w, frame + 40, get(w, S_ARENA))
        put(w, frame + 48, 0)
        put(w, frame + 56, 0)
        put(w, S_LEVEL, get(w, S_LEVEL) + 1)
        if kind == 6:
            put(w, S_KEYBASE, 0)
            put(w, S_HASHBASE, 0)
            put(w, S_HASHMASK, 0)
            put(w, S_KEYINDEX, 0)
            put(w, S_KEYMARK, get(w, S_ARENA))
            put(w, S_STAGE, 1)
        else:
            put(w, S_STAGE, 2)
        return 1
    if kind == 4:
        if string_size(s, w, at) == 0:
            return 0
    elif kind == 2:
        if bit_length(s, at) > get(w, S_MAXIMUM) * 4:
            return error(w, 13, 0)
    elif kind != 0 and kind != 1 and kind != 3:
        return error(w, 14, 0)
    put(w, S_STAGE, 2)
    return 1

def scan_next(s:readbuf, w:mutbuf) -> u64:
    while get(w, S_LEVEL) != 0:
        frame = FRAME_BASE + (get(w, S_LEVEL) - 1) * 64
        remaining = get(w, frame + 24)
        if remaining == 0:
            put(w, S_ARENA, get(w, frame + 40))
            put(w, S_LEVEL, get(w, S_LEVEL) - 1)
        else:
            at = node(s, w, get(w, frame))
            if at == 0:
                return 0
            index = remaining - 1
            if get(w, frame + 8) == 6:
                index = index * 2 + 1
            next_node = edge(s, w, at, index)
            if next_node == 0:
                return 0
            put(w, frame + 24, remaining - 1)
            put(w, S_CUR, next_node)
            put(w, S_DEPTH, get(w, S_LEVEL))
            put(w, S_STAGE, 0)
            return 1
    if get(w, S_QUEUED) != 0:
        return abi(w, 37)
    put(w, S_SCANEND, get(w, S_VISITED))
    put(w, S_PHASE, 2)
    put(w, S_STAGE, 0)
    put(w, S_ARENA, MIN_WORK)
    return 1

def scan_keys(s:readbuf, w:mutbuf) -> u64:
    if get(w, S_LEVEL) == 0:
        return abi(w, 38)
    frame = FRAME_BASE + (get(w, S_LEVEL) - 1) * 64
    at = node(s, w, get(w, frame))
    if at == 0:
        return 0
    total = read(s, at + 32)
    if get(w, S_KEYBASE) == 0 and total != 0:
        capacity = 1
        while capacity < total * 2:
            capacity = capacity * 2
        base = reserve(w, capacity * 8 + total * 32)
        if base == 0:
            return 0
        fill_range(w, base, capacity * 8, 0)
        put(w, S_HASHBASE, base)
        put(w, S_HASHMASK, capacity - 1)
        put(w, S_KEYBASE, base + capacity * 8)
    while get(w, S_KEYINDEX) < total:
        index = get(w, S_KEYINDEX)
        key = edge(s, w, at, index * 2)
        if key == 0:
            return 0
        key_node = node(s, w, key)
        if key_node == 0:
            return 0
        mark = get(w, S_ARENA)
        if key_text(s, w, key_node) == 0:
            put(w, S_ARENA, mark)
            return 0
        if retain_key(s, w, key, mark) == 0:
            put(w, S_ARENA, mark)
            return 0
        put(w, S_KEYINDEX, index + 1)
    put(w, S_ARENA, get(w, S_KEYMARK))
    put(w, S_STAGE, 2)
    return 1

def retain_key(s:readbuf, w:mutbuf, key:u64, mark:u64) -> u64:
    # Scalar conversion scratch is temporary. Only the exact converted key
    # string remains for full collision comparisons during this dict scan.
    put(w, S_ARENA, mark)
    if get(w, S_TMPKIND) == 2:
        source = get(w, S_TMPOFF)
        size = get(w, S_TMPSIZE)
        at = reserve(w, size)
        if at == 0:
            return 0
        i = 0
        while i < size:
            store(w, at + i, byte(w, source + i))
            i = i + 1
        put(w, S_TMPOFF, at)
    slot = text_hash(s, w, get(w, S_TMPKIND), get(w, S_TMPOFF), get(w, S_TMPSIZE)) & get(w, S_HASHMASK)
    value = get(w, get(w, S_HASHBASE) + slot * 8)
    while value != 0:
        record = get(w, S_KEYBASE) + (value - 1) * 32
        if text_equal(s, w, record) != 0:
            return error(w, 12, 0)
        slot = (slot + 1) & get(w, S_HASHMASK)
        value = get(w, get(w, S_HASHBASE) + slot * 8)
    index = get(w, S_KEYINDEX)
    record = get(w, S_KEYBASE) + index * 32
    put(w, record, key)
    put(w, record + 8, get(w, S_TMPKIND))
    put(w, record + 16, get(w, S_TMPOFF))
    put(w, record + 24, get(w, S_TMPSIZE))
    put(w, get(w, S_HASHBASE) + slot * 8, index + 1)
    return 1
'''

