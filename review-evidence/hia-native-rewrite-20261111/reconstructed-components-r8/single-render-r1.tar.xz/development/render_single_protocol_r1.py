"""Narrow actual renderer protocol checks; no hosted render computation in forwarding."""
from pathlib import Path
import ctypes,json,struct,sys,time
from render_single_harness_r1 import Actual,COMMAND,EVENT,BAD,CANARY,gw
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'development/render-single-protocol-r1-attempt1'
a=Actual(OUT);start=time.monotonic_ns();cases=[]
q=json.loads((ROOT/'development/renderer-float-boundary-reference.json').read_text())['query']
graph=gw.capture(q);lease=struct.unpack_from('<Q',graph,8)[0];root=struct.unpack_from('<Q',graph,24)[0]
command=struct.pack('<8Q',COMMAND,lease,1,root,4300,0,0,0)
def work(size=32768):
    w=ctypes.create_string_buffer(size+32);ctypes.memset(ctypes.addressof(w)+size,0xd6,32);return w
def mutate(raw,offset,value):
    raw=bytearray(raw);struct.pack_into('<Q',raw,offset,value);return bytes(raw)
def pending_query(name):
    w=work();ret,event=a.call(graph,command,w,32768,name+'-begin')
    assert ret==128 and event[1]==2 and event[5]==1
    packet=ctypes.string_at(ctypes.addressof(w)+event[12],event[13])
    reply=a.wire_reply(graph,packet,name+'-real-wire')
    return w,reply
def rejected(w,size,g,c,follow,name):
    ret,event=a.call(g,c,w,size,name);assert ret==BAD,(name,ret,event)
    ret,event=a.call(g,follow,w,size,name+'-followup');assert ret==BAD
    cases.append({'case':name,'status':'PASS','return':ret})
try:
    for offset,value in [(0,0),(8,lease+1),(16,0),(24,0),(40,1),(48,1),(56,1)]:
        rejected(work(),32768,graph,mutate(command,offset,value),command,'initial-'+str(offset))
    rejected(work(),32768,graph,command[:-1],command,'short-initial')
    for offset,value in [(0,0),(8,2),(16,lease+1),(24,99),(32,root+1),(40,99),
                         (48,0),(56,640),(64,1),(72,1),(88,1<<63),(96,0),
                         (104,1),(112,99),(120,1)]:
        w,reply=pending_query('reply-'+str(offset))
        rejected(w,32768,graph,mutate(reply,offset,value),reply,'reply-'+str(offset))
    w,reply=pending_query('short-reply')
    rejected(w,32768,graph,reply[:127],reply,'short-reply')
    w,reply=pending_query('grow-control')
    ret,event=a.call(graph,reply,w,32768,'grow-control-accept')
    assert ret==128 and event[1]==1 and event[5]==2
    size=max(65536,event[6]);nw=work(size);ctypes.memmove(nw,w,32768)
    rejected(nw,size,graph,command,b'','state-only-grow-input')
    # A too-short workspace with a complete state header retains poison on growth.
    short=work(32767)
    ret,event=a.call(graph,command,short,32767,'short-workspace');assert ret==BAD
    nw=work(65536);ctypes.memmove(nw,short,32767)
    rejected(nw,65536,graph,command,command,'short-workspace-grown-poison')
    # An initial state whose magic is zero cannot silently discard other fields.
    w=work();struct.pack_into('<Q',w,272,1)
    rejected(w,32768,graph,command,command,'nonzero-initial-phase')
    # Real large attrs causes phase21 GROW while holding a real wire reply.
    large=json.loads(json.dumps(q));large['context']['operation']['attrs']={'value':'a'*150000}
    lg=gw.capture(large);lc=struct.pack('<8Q',COMMAND,19,1,1,4300,0,0,0)
    size=32768;w=work(size);control=lc
    while True:
        ret,event=a.call(lg,control,w,size,'live-reply-grow')
        assert ret==128
        if event[1]==2:
            packet=ctypes.string_at(ctypes.addressof(w)+event[12],event[13])
            control=a.wire_reply(lg,packet,'live-reply-grow-wire');continue
        if event[1]==1:
            n=max(size*2,event[6]);nw=work(n);ctypes.memmove(nw,w,size);w=nw;size=n
            if event[5]==21:
                rejected(w,size,lg,mutate(control,24,999),control,'reply-grow-sequence')
                break
            control=b'';continue
        raise AssertionError(('expected real reply GROW',event))
    # Complete one real stream, then any additional command is permanently invalid.
    size=32768;w=work(size);control=command
    while True:
        ret,event=a.call(graph,control,w,size,'complete-session');assert ret==128
        if event[1]==2:
            packet=ctypes.string_at(ctypes.addressof(w)+event[12],event[13])
            control=a.wire_reply(graph,packet,'complete-session-wire');continue
        if event[1]==1:
            n=max(size*2,event[6]);nw=work(n);ctypes.memmove(nw,w,size);w=nw;size=n
            if event[5]!=21:control=b''
            continue
        assert event[1]==0
        rejected(w,size,graph,command,command,'completed-session')
        break
    a.close()
    summary={'status':'PASS','cases':cases,'case_count':len(cases),'entries':a.entries,
             'wire_entries':a.wire.entries,'wall_elapsed_ns':time.monotonic_ns()-start}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'},sort_keys=True))
except BaseException as exc:
    a.close();(OUT/'failure.json').write_text(json.dumps({'class':type(exc).__name__,'error':str(exc),'completed':cases},indent=2,sort_keys=True)+'\n');raise

