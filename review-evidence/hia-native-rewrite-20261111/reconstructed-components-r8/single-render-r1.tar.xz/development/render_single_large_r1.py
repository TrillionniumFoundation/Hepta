"""Actual >1MiB renderer output with physical read-only input/peer leases.

The ordinary raw-heavy differential harness is unchanged. This long continuation
case records every actual event and every byte of the final result, with native
RO pages enforcing input immutability instead of copying all growing workspaces
on every one of 20,000 peer calls.
"""
from pathlib import Path
from hashlib import sha256
import ctypes,json,mmap,resource,struct,sys,time
from unittest.mock import patch
from render_single_harness_r1 import ROOT,BASE,COMMAND,EVENT,WIRE_EVENT,BAD,gw,NativeHiaJsonImage,render_edit_context
from hepta.hia_program_tools import bounded_json_wire
OUT=ROOT/'development/render-single-large-r1-attempt1'
OUT.mkdir(parents=True,exist_ok=False)
resource.setrlimit(resource.RLIMIT_AS,(1024*1024*1024,1024*1024*1024))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
libc=ctypes.CDLL(None,use_errno=True)
libc.mprotect.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int];libc.mprotect.restype=ctypes.c_int
CANARY=b'\xa7'*32
class Block:
    def __init__(self,size,raw=None):
        self.size=size;self.physical=((size+32+4095)//4096)*4096
        self.memory=mmap.mmap(-1,self.physical,prot=mmap.PROT_READ|mmap.PROT_WRITE)
        self.address=ctypes.addressof(ctypes.c_char.from_buffer(self.memory))
        ctypes.memmove(self.address+size,CANARY,32);self.read_only=False
        if raw is not None:
            assert len(raw)==size;ctypes.memmove(self.address,raw,len(raw))
    def ro(self):
        assert libc.mprotect(self.address,self.physical,mmap.PROT_READ)==0,ctypes.get_errno()
        self.read_only=True
    def check(self):assert ctypes.string_at(self.address+self.size,32)==CANARY
    def bytes(self):return ctypes.string_at(self.address,self.size)
    def close(self):self.memory.close()
def grow(old,size):
    new=Block(size);ctypes.memmove(new.address,old.address,old.size);old.close();return new
pins={}
def read(path):
    path=Path(path).resolve();raw=path.read_bytes()
    if path in pins:assert pins[path]==raw
    pins[path]=raw;return raw
def pinfile(name):
    (OUT/name).write_text(json.dumps({str(p):sha256(raw).hexdigest() for p,raw in pins.items()},indent=2,sort_keys=True)+'\n')
images={}
row=json.loads(read(ROOT/'development/render-single-compile-r1/bundle.json'))['component']
assert row['schema']=='hepta.hia.edit-render-single-native.v1'
source=read(row['source_path']);assert source==read(ROOT/'examples/hia_bootstrap/edit_render_single.hiaasm')
assert sha256(source).hexdigest()==row['source_sha256']
raw=read(row['image_path']);assert sha256(raw).hexdigest()==row['image_sha256']
images['renderer']=NativeHiaJsonImage(raw,row['image_sha256'])
for role,row in json.loads(read(ROOT/'development/compile-r3/bundle.json'))['components'].items():
    source=read(row['source_path']);assert source==read(ROOT/('examples/hia_bootstrap/graph_json_wire_'+role+'.hiaasm'))
    raw=read(row['image_path']);assert sha256(source).hexdigest()==row['source_sha256'] and sha256(raw).hexdigest()==row['image_sha256']
    images[role]=NativeHiaJsonImage(raw,row['image_sha256'])
for path,raw in pins.items():assert path.read_bytes()==raw
pinfile('source-before.json')
q=json.loads((ROOT/'development/renderer-float-boundary-reference.json').read_text())['query']
q['context']['callees']=[{'name':'c','params':[],'returns':[],'effects':[]}]*20000
wire=bounded_json_wire(q,1048576);expected=render_edit_context(q).encode('utf-8')
assert len(wire)<=1048576<len(expected)
graph=gw.capture(q);source=Block(len(graph),graph);source.ro()
(OUT/'input.graph').write_bytes(graph);(OUT/'input.wire').write_bytes(wire);(OUT/'expected.txt').write_bytes(expected)
command=struct.pack('<8Q',COMMAND,19,1,1,4300,0,0,0)
control=Block(len(command),command);control.ro();empty=Block(0,b'');empty.ro()
renderer=Block(32768);owned_reply=None;counts={'renderer':0,'scan':0,'emit':0};grows=0;services=0
ledger=(OUT/'entries.jsonl').open('w');start=time.monotonic_ns()
def call(role,first,second,work):
    assert first.read_only and (second is None or second.read_only)
    ret=images[role]._entry(first.address,first.size,second.address if second else 0,second.size if second else 0,work.address,work.size)
    counts[role]+=1;first.check()
    if second:second.check()
    work.check();event=struct.unpack('<16Q',ctypes.string_at(work.address,128))
    ledger.write(json.dumps({'role':role,'ordinal':counts[role],'return':ret,'event':event,
                            'workspace_bytes':work.size,'physical_inputs_readonly':True,
                            'canaries_unchanged':True},sort_keys=True)+'\n')
    if counts[role]%1000==0:ledger.flush()
    return ret,event
def wire_service(command_raw):
    cmd=Block(len(command_raw),command_raw);cmd.ro();workspace=Block(32768);role='scan'
    try:
        while True:
            ret,event=call(role,source,cmd,workspace)
            assert ret==128 and event[0]==WIRE_EVENT
            if event[1]==1:
                assert event[10]>workspace.size
                workspace=grow(workspace,max(workspace.size*2,event[10]));continue
            if event[1]==2:
                assert role=='scan';role='emit';continue
            assert event[1]==0 and event[14]==90
            workspace.ro()
            return workspace
    finally:cmd.close()
def blocked(*args,**kwargs):raise AssertionError('host display/wire semantics disabled in native loop')
patches=[patch('hepta.hia_edit_query.'+name,new=blocked) for name in
         ['render_edit_context','_render_edit_context_checked','_display_atom','_display_signature','_wire']]
patches+=[patch('hepta.hia_program_tools.bounded_json_wire',new=blocked)]
for p in patches:p.start()
try:
    while True:
        ret,event=call('renderer',source,control,renderer)
        assert ret==128 and event[0]==EVENT,(ret,event)
        if event[1]==1:
            assert event[6]>renderer.size
            renderer=grow(renderer,max(renderer.size*2,event[6]));grows+=1
            if event[5]!=21:
                if owned_reply is not None:owned_reply.close();owned_reply=None
                if control is not empty and control is not owned_reply and control.read_only:
                    # The original BEGIN was already closed on the first request.
                    pass
                control=empty
            continue
        if event[1]==2:
            packet=ctypes.string_at(renderer.address+event[12],event[13])
            if owned_reply is not None:owned_reply.close();owned_reply=None
            elif control is not empty:control.close()
            owned_reply=wire_service(packet);control=owned_reply;services+=1;continue
        assert event[1]==0 and event[9:11]==(0,0)
        actual=ctypes.string_at(renderer.address+event[7],event[8])
        assert actual==expected
        source.check();assert source.bytes()==graph
        (OUT/'actual.txt').write_bytes(actual);(OUT/'final-workspace.bin').write_bytes(renderer.bytes())
        summary={'status':'PASS','scope':'ACTUAL_LARGE_DISPLAY_WITH_PHYSICAL_READONLY_LEASES',
                 'callees':20000,'input_wire_bytes':len(wire),'output_bytes':len(actual),
                 'output_sha256':sha256(actual).hexdigest(),'entries':counts,'wire_services':services,
                 'renderer_grows':grows,'all_inputs_physical_readonly':True,'every_entry_canaries_checked':True,
                 'final_output_byte_exact_reference':True,'wall_elapsed_ns':time.monotonic_ns()-start,
                 'cpu_limit_seconds':90,'address_space_limit_bytes':1073741824,
                 'public_foreign_capture_closed':False}
        (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary,sort_keys=True),flush=True)
        break
except BaseException as exc:
    (OUT/'failure.json').write_text(json.dumps({'class':type(exc).__name__,'error':str(exc),'entries':counts},indent=2,sort_keys=True)+'\n')
    raise
finally:
    for p in reversed(patches):p.stop()
    ledger.close()
    for path,raw in pins.items():assert path.read_bytes()==raw
    pinfile('source-after.json')
    if owned_reply is not None:owned_reply.close()
    empty.close();renderer.close();source.close()

