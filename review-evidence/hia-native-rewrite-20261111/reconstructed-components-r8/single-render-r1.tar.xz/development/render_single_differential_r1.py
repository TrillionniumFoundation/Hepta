"""Complete single renderer differential: actual prepared graphs and independent mutations."""
from pathlib import Path
from hashlib import sha256
import copy, json, struct, time, sys
from render_single_harness_r1 import Actual, render_edit_context
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'development/render-single-differential-r1-attempt1'
a=Actual(OUT);start=time.monotonic_ns();cases=[]
BASE=json.loads((ROOT/'development/renderer-float-boundary-reference.json').read_text())['query']
def check(q,name):cases.append(a.check(q,name))
def change(q,path,value):
    q=copy.deepcopy(q);at=q
    for key in path[:-1]:at=at[key]
    at[path[-1]]=value;return q
def paths(value,prefix=()):
    result=[]
    if type(value) is dict:
        for key,child in value.items():
            result.append(prefix+(key,));result.extend(paths(child,prefix+(key,)))
    elif type(value) is list:
        for index,child in enumerate(value):
            result.append(prefix+(index,));result.extend(paths(child,prefix+(index,)))
    return result
CFG=copy.deepcopy(BASE)
CFG['context']['function']['params']=[{'name':'p','type':'u32'}]
CFG['context']['block_params']=[{'name':'p','type':'u32'}]
CFG['context']['operation']['args']=['p']
CFG['context']['operation_index']=3
CFG['context']['dependencies']=[{'index':1,'operation':{'op':'const','out':[{'name':'a','type':'u32'}],'args':[],'attrs':{'value':1}}}]
CFG['context']['consumers']=[{'index':7,'operation':{'op':'int.add.wrap','out':[{'name':'z','type':'u32'}],'args':['x','a'],'attrs':{}}}]
CFG['context']['callees']=[{'name':'callee','params':[{'name':'q','type':'u32'}],'returns':['u32'],'effects':[]}]
CFG['context']['downstream']=[{'id':'after','params':[{'name':'v','type':'u32'}],'affected_params':['v'],
    'dependencies':[{'index':0,'operation':{'op':'const','out':[{'name':'d','type':'u32'}],'args':[],'attrs':{'value':2}}}],
    'consumers':[{'index':1,'operation':{'op':'int.add.wrap','out':[{'name':'e','type':'u32'}],'args':['v','d'],'attrs':{}}}],
    'terminator':{'op':'branch','cond':'e','then':{'target':'a','args':[]},'else':{'target':'b','args':[]}},
    'branch_condition_affected':True,'control_reachable':True}]
LOAN=copy.deepcopy(BASE);LOAN['schema']='hepta.hia.edit-query.v3'
LOAN['context']['function']={'name':'f','params':[{'name':'r','type':'readbuf'},{'name':'m','type':'mutbuf'}],
                            'returns':['readbuf','mutbuf','u32'],'effects':['read','write'],
                            'return_loans':['r','m',None]}
LOAN['context']['callees']=[{'name':'callee','params':[{'name':'r','type':'readbuf'}],
                          'returns':['readbuf'],'effects':['read'],'return_loans':['r']}]
class Substr(str):pass
class Subdict(dict):pass
try:
    corpus=Path('/workspace/scratch/9acdfa9f5639/native-agent-edit-development/packet-graph-wire-r2')
    meta=json.loads((corpus/'summary.json').read_text())
    originals=[]
    for index,row in enumerate(meta['cases'][:99]):
        label=row.get('case',row.get('name',''))
        assert label.startswith('query-'),row
        gp=corpus/(str(index).zfill(4)+'.graph');wp=corpus/(str(index).zfill(4)+'.wire')
        graph=gp.read_bytes();wire=wp.read_bytes()
        assert sha256(wire).hexdigest()==row['wire_sha256'] and len(graph)==row['graph_bytes']
        value=json.loads(wire);expected=render_edit_context(value).encode('utf-8')
        actual=a.render_graph(graph,'actual-prepared-'+label)
        assert actual['status']=='ACCEPT' and actual['bytes']==expected,(label,actual,expected)
        cases.append({'case':'actual-prepared-'+label,'status':'PASS','outcome':'ACCEPT',
                      'calls':actual['calls'],'services':actual['services'],'grows':actual['grows'],
                      'output':a.raw(actual['bytes'],'.output')})
        originals.append({'graph':str(gp),'graph_sha256':sha256(graph).hexdigest(),
                          'wire':str(wp),'wire_sha256':sha256(wire).hexdigest()})
    (OUT/'actual-prepared-custody.json').write_text(json.dumps(originals,indent=2,sort_keys=True)+'\n')
    check(BASE,'independent-base');check(CFG,'complete-cfg');check(LOAN,'complete-loans')
    choices=[None,False,0,-1,1.25,'','bad-name',[],(),{}, {'unexpected':0}]
    for group,value in [('base',BASE),('cfg',CFG),('loan',LOAN)]:
        for index,path in enumerate(paths(value)):
            # Paths common to the base fixture need only one representative pass.
            if group!='base' and path in paths(BASE):continue
            for variant,replacement in enumerate(choices):
                check(change(value,path,replacement),'mutation-'+group+'-'+str(index)+'-'+str(variant))
    # Explicit original short-circuit and all-index-capture priorities.
    value=copy.deepcopy(BASE);value['context']['dependencies']=0;del value['context']['consumers']
    check(value,'deps-wrong-before-missing-consumers')
    value=copy.deepcopy(BASE);value['context']['dependencies']=[{'index':False},{'operation':{}}]
    check(value,'all-index-capture-before-invalid-earlier-index')
    value=copy.deepcopy(BASE);value['context']['dependencies']=[{'index':0},{'index':0}]
    check(value,'duplicate-index-before-missing-operation')
    value=copy.deepcopy(BASE);value['context']['dependencies']=[{'index':1,'operation':{'out':[],'args':[],'op':'bad-name'}}]
    check(value,'missing-attrs-before-invalid-opcode')
    value=copy.deepcopy(CFG);succ=value['context']['downstream'][0]
    succ['params']=[{'name':'v','type':'bad-name'},{'name':'v','type':'u32'},{'name':'bad-name','type':'u32'}]
    check(value,'all-downstream-names-before-duplicate-and-type')
    value=copy.deepcopy(BASE);value['context']['function']['params']=[{'name':'p','type':'u32'},{'name':'p','type':'bad-name'}]
    check(value,'parameter-type-before-duplicate')
    for args in ['abc',(),{'a':0,'b':1},'',{'1':0},'\U0001f600',Substr('x')]:
        value=copy.deepcopy(BASE);value['context']['operation']['args']=args;check(value,'iter-args-'+repr(args))
    for output in [(),'',{},[],[{'name':'x','type':'u32'}]]:
        value=copy.deepcopy(BASE);value['context']['dependencies']=[{'index':9,'operation':{'op':'noop','out':output,'args':[],'attrs':{}}}]
        check(value,'empty-output-iterator-'+repr(output))
    for attrs in [[],(),'',0,0.0,-0.0,None,False,True,'x',1.25,{'value':float('inf')},{'value':float('nan')}]:
        value=copy.deepcopy(BASE);value['context']['operation']['attrs']=attrs;check(value,'attrs-'+repr(attrs))
    for metadata in [{'float':1.125},{1:2},{False:0},{None:1},{1:'x','1':'y'},
                     {'string':'\ud800'},[object()],b'x']:
        value=copy.deepcopy(BASE);value['context']['extra_metadata']=metadata;check(value,'metadata-'+repr(metadata))
    check(Subdict(BASE),'exact-root-dict-subclass')
    value=copy.deepcopy(BASE);value['context']['metadata']=value['context']
    check(value,'cycle-query-gate')
    shared={'value':1.25};value=copy.deepcopy(BASE)
    value['context']['operation']['attrs']=shared;value['context']['metadata']=[shared,shared]
    check(value,'shared-subtree-alias')
    value=copy.deepcopy(BASE);value['context']['operation_index']=1<<200
    value['context']['dependencies']=[{'index':1<<180,'operation':{'op':'const','out':[{'name':'a','type':'u32'}],'args':[],'attrs':{'value':0}}},
                                    {'index':(1<<200)+1,'operation':{'op':'const','out':[{'name':'b','type':'u32'}],'args':[],'attrs':{'value':1}}}]
    check(value,'full-width-integer-sorting')
    for count in [255,256]:
        value=copy.deepcopy(BASE);value['context']['operation_index']=count
        value['context']['dependencies']=[{'index':i,'operation':{'op':'noop','out':[],'args':[],'attrs':{}}} for i in range(count)]
        check(value,'visible-operations-'+str(count+1))
    for count in [63,64]:
        value=copy.deepcopy(BASE);value['context']['downstream']=[
            {'id':'b'+str(i),'params':[],'affected_params':[],'dependencies':[],'consumers':[],
             'terminator':{'op':'ret','values':[]},'branch_condition_affected':False,'control_reachable':True}
            for i in range(count)]
        check(value,'visible-blocks-'+str(count+1))
    value=copy.deepcopy(BASE);value['context']['operation']['attrs']={'value':'a'*1048576}
    value['selector']['block']='bad-name';check(value,'query-wire-before-later-identity')
    value['unknown']=0;check(value,'top-fields-before-query-wire')
    value=copy.deepcopy(BASE);value['context']['callees']=[
        {'name':'c'+str(i),'params':[{'name':'p','type':'u32'}],'returns':['u32'],'effects':[]}
        for i in range(512)]
    check(value,'512-complete-callees')
    a.close()
    for row in originals:
        assert sha256(Path(row['graph']).read_bytes()).hexdigest()==row['graph_sha256']
        assert sha256(Path(row['wire']).read_bytes()).hexdigest()==row['wire_sha256']
    summary={'status':'PASS','scope':'COMPLETE_SINGLE_RENDERER_R1_DEVELOPMENT',
             'cases':cases,'case_count':len(cases),'entries':a.entries,'wire_entries':a.wire.entries,
             'wall_elapsed_ns':time.monotonic_ns()-start,'public_foreign_capture_closed':False,
             'python_cause_objects_reconstructed':False}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({key:value for key,value in summary.items() if key!='cases'},sort_keys=True),flush=True)
except BaseException as exc:
    a.close();failure={'status':'FAIL','class':type(exc).__name__,'error':str(exc),
                      'completed':cases,'entries':a.entries,'wire_entries':a.wire.entries}
    (OUT/'failure.json').write_text(json.dumps(failure,indent=2,sort_keys=True)+'\n')
    raise

