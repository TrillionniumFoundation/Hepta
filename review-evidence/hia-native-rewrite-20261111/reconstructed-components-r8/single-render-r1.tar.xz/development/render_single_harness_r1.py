"""Mechanical complete renderer forwarding, with hosted semantic owners disabled."""
from pathlib import Path
from hashlib import sha256
import ctypes, importlib.util, json, struct, sys
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-agent-edit-native')
sys.path.insert(0,str(BASE))
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_edit_query import render_edit_context
spec=importlib.util.spec_from_file_location('renderer_graph_r3',ROOT/'development/graph_harness_r3.py')
gw=importlib.util.module_from_spec(spec);spec.loader.exec_module(gw)
MAGIC=lambda value:int.from_bytes(value,'little')
COMMAND=MAGIC(b'HIAERC01');EVENT=MAGIC(b'HIAERE01');WIRE_EVENT=MAGIC(b'HIAGWE01')
BAD=0xfffffffd;CANARY=b'\xd6'*32

class Actual:
    def __init__(self,out,bundle=None):
        self.out=Path(out);self.pins={};self.entries=0;self.snapshots={}
        bundle=Path(bundle or ROOT/'development/render-single-compile-r1/bundle.json')
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes()
            if path in self.pins:assert self.pins[path]==raw
            self.pins[path]=raw;return raw
        data=json.loads(read(bundle))
        assert data['status']=='PASS' and data['scope']=='SOURCE_BOUND_SINGLE_RENDERER_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD'
        row=data['component'];assert row['schema']=='hepta.hia.edit-render-single-native.v1'
        source=read(row['source_path']);current=read(ROOT/'examples/hia_bootstrap/edit_render_single.hiaasm')
        image=read(row['image_path'])
        assert source==current and sha256(source).hexdigest()==row['source_sha256']
        assert sha256(image).hexdigest()==row['image_sha256']
        assert row['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
        self.readback();self.out.mkdir(parents=True,exist_ok=False)
        self.image=NativeHiaJsonImage(image,row['image_sha256'])
        self.wire=gw.Actual(self.out/'wire')
        self.rawdir=self.out/'raw';self.rawdir.mkdir()
        self.log=(self.out/'entries.jsonl').open('w')
        self.pinfile('source-before.json')
    def readback(self):
        for path,raw in self.pins.items():assert path.read_bytes()==raw
    def pinfile(self,name):
        (self.out/name).write_text(json.dumps({str(p):sha256(v).hexdigest() for p,v in self.pins.items()},indent=2,sort_keys=True)+'\n')
    def raw(self,value,suffix):
        digest=sha256(value).hexdigest();name=digest+suffix;p=self.rawdir/name
        if not p.exists():p.write_bytes(value)
        else:assert p.read_bytes()==value
        return name
    def call(self,graph,control,workspace,size,case):
        s=ctypes.create_string_buffer(graph+CANARY);r=ctypes.create_string_buffer(control+CANARY)
        before=ctypes.string_at(workspace,size)
        ret=self.image._entry(s,len(graph),r,len(control),workspace,size);self.entries+=1
        event=struct.unpack_from('<16Q',workspace,0)
        assert ctypes.string_at(s,len(graph)+32)==graph+CANARY
        assert ctypes.string_at(r,len(control)+32)==control+CANARY
        assert ctypes.string_at(ctypes.addressof(workspace)+size,32)==CANARY
        row={'case':case,'return':ret,'event':event,'graph':self.raw(graph,'.graph'),
             'control':self.raw(control,'.control'),'workspace_bytes':size,
             'workspace_before':self.raw(before,'.before'),
             'workspace_after':self.raw(ctypes.string_at(workspace,size),'.after'),
             'input_and_canaries_unchanged':True}
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
        return ret,event
    def wire_reply(self,graph,command,case):
        size=32768;work=ctypes.create_string_buffer(size+32)
        ctypes.memset(ctypes.addressof(work)+size,0xb9,32);role='scan'
        while True:
            ret,event=self.wire.call(role,graph,command,work,size,case)
            assert ret==128 and event[0]==WIRE_EVENT,(case,ret,event)
            if event[1]==1:
                n=max(size*2,event[10]);assert n>size
                replacement=ctypes.create_string_buffer(n+32);ctypes.memmove(replacement,work,size)
                ctypes.memset(ctypes.addressof(replacement)+n,0xb9,32);work=replacement;size=n;continue
            if event[1]==2:
                assert role=='scan';role='emit';continue
            assert event[1] in (0,3)
            return ctypes.string_at(work,size)
    def render_graph(self,graph,case='case',digits=None):
        if digits is None:digits=sys.get_int_max_str_digits()
        lease,root=struct.unpack_from('<Q',graph,8)[0],struct.unpack_from('<Q',graph,24)[0]
        control=struct.pack('<8Q',COMMAND,lease,1,root,digits,0,0,0)
        size=32768;work=ctypes.create_string_buffer(size+32)
        ctypes.memset(ctypes.addressof(work)+size,0xd6,32)
        grows=services=calls=0
        def blocked(*args,**kwargs):raise AssertionError('host render/wire semantic owner disabled')
        targets=['render_edit_context','_render_edit_context_checked','_display_atom','_display_signature','_wire']
        patches=[patch('hepta.hia_edit_query.'+name,new=blocked) for name in targets]
        patches+=[patch('hepta.hia_program_tools.bounded_json_wire',new=blocked)]
        for p in patches:p.start()
        try:
            while True:
                calls+=1;assert calls<1000000
                ret,event=self.call(graph,control,work,size,case)
                assert ret==128 and event[0]==EVENT and event[2:4]==(lease,1),(case,ret,event)
                if event[1]==1:
                    needed=event[6];assert needed>size
                    n=max(size*2,needed);nw=ctypes.create_string_buffer(n+32)
                    ctypes.memmove(nw,work,size);ctypes.memset(ctypes.addressof(nw)+n,0xd6,32)
                    work=nw;size=n;grows+=1
                    if event[5]!=21:control=b''
                    continue
                if event[1]==2:
                    assert event[13]==64 and event[12]<=size and 64<=size-event[12]
                    command=ctypes.string_at(ctypes.addressof(work)+event[12],64)
                    control=self.wire_reply(graph,command,case);services+=1;continue
                assert event[1] in (0,3)
                assert event[7]<=size and event[8]<=size-event[7]
                output=ctypes.string_at(ctypes.addressof(work)+event[7],event[8])
                return {'status':'ACCEPT' if event[1]==0 else 'REJECT','bytes':output,'event':event,
                        'grows':grows,'services':services,'calls':calls}
        finally:
            for p in reversed(patches):p.stop()
    def check(self,value,case='case'):
        try:
            text=render_edit_context(value);expected={'status':'ACCEPT','bytes':text.encode('utf-8')}
        except Exception as exc:
            expected={'status':'REJECT','bytes':str(exc).encode('utf-8'),'class':type(exc).__name__,
                      'cause_class':type(exc.__cause__).__name__ if exc.__cause__ else None,
                      'cause_text':str(exc.__cause__) if exc.__cause__ else None}
        graph=gw.capture(value)
        actual=self.render_graph(graph,case)
        assert actual['status']==expected['status'] and actual['bytes']==expected['bytes'],(case,expected,actual)
        return {'case':case,'status':'PASS','outcome':actual['status'],'bytes':len(actual['bytes']),
                'output_sha256':sha256(actual['bytes']).hexdigest(),'output':self.raw(actual['bytes'],'.output'),
                'reference_class':expected.get('class'),'reference_cause_class':expected.get('cause_class'),
                'reference_cause_text':expected.get('cause_text'),
                'grows':actual['grows'],'services':actual['services'],'calls':actual['calls']}
    def close(self):
        self.wire.close();self.log.close();self.readback();self.pinfile('source-after.json')

