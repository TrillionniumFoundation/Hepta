# Graph wire r3 integration notes

This is an additive clarification. The frozen seven-source r3 manifest, images,
full test raw files and original archive are unchanged.

## Empty scalar payload offsets

All scalar kinds with a scalar payload field (integer, binary64, string and exact
bytes) carry an absolute offset within the scalar pool, inclusive of its end.
This applies when the payload is empty. In particular, integer zero has zero
payload bytes and zero sign, but its offset is a valid scalar-pool cursor, **not
zero**. The same rule applies to empty strings and empty exact byte strings.
Null, bool, unsupported and container nodes have no scalar payload fields.

## Actual single versus batch public float boundary

An unchanged reference control uses a valid single query with
`context.operation.attrs.value = 1.25`. `render_edit_context` accepts it and
prints the exact canonical float text. Wrapping that same query in a valid batch
query causes the unchanged `render_batch_context` to reject with
`E_HIA_EDIT: invalid JSON: HIA JSON preflight: expected object separator/end`.

The batch entry serializes then calls `decode_json`, whose default HIA preflight
is integer-only. The single renderer retains its original in-process object
after the complete general bounded-wire gate. The general Graph/wire owner
continues to support finite binary64. Each renderer must retain its own observed
entry behavior and error order; the general codec does not authorize broadening
the batch entry or narrowing the single entry.

The complete inputs, actual output/error, exception cause, and four source SHA256
pins are retained in `development/renderer-float-boundary-reference.json`. This
witness was created after the r3 archive was sealed and is a separate artifact.

## Entry accounting

The three final r3 groups log 1,814 native entries (884 scan, 930 emit). One
additional direct native short-workspace negative control intentionally bypasses
the generic event logger. Thus the observed final r3 total is 1,815 actual
entries. All 732 cases pass; earlier revisions remain separate.
