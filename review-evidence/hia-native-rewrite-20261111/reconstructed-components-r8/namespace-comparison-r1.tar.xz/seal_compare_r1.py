"""Seal exact comparison development originals; never imply store closure."""
from pathlib import Path
from hashlib import sha256
import io
import json
import stat
import tarfile

BASE=Path('/workspace/scratch/hia-audit-runtime-recovery-20261111/namespace-reconstruction')
DEV=BASE/'compare-r1'
SOURCE=BASE.parent/'namespace-authoring-next'
OUT=BASE/'compare-r1-complete-01'
OUT.mkdir(exist_ok=False)

def read(path):
 before=path.lstat();assert stat.S_ISREG(before.st_mode) and before.st_nlink==1
 raw=path.read_bytes();after=path.lstat()
 sig=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
 assert sig(before)==sig(after) and len(raw)==before.st_size
 return raw,before

def load(path):return json.loads(read(path)[0])

first=load(DEV/'vm-r1/result.json')
assert first['status']=='FAIL' and first['tests_run']==6 and len(first['errors'])==6 and first['entries']==0
assert first['source_unchanged'] and not first['failures']
vm=load(DEV/'vm-r2/result.json');compiled=load(DEV/'native-r1/compile/summary.json');native=load(DEV/'native-r1/paired-validation/result.json')
assert vm['status']==compiled['status']==native['status']=='PASS'
assert vm['source_unchanged'] and compiled['source_and_compiler_unchanged'] and native['source_unchanged']
assert native['before']==native['after'] and compiled['before']==compiled['after']
assert vm['tests_run']==vm['tests_loaded']==native['tests_run']==native['tests_loaded']==6
assert native['paired_vm_entries']==native['counters']['actual_native_entries']==native['counters']['full_entry_bytes_equal']==vm['entries']==3628
assert native['oracle_cases']==vm['oracle_cases']==3313 and native['sqlite_version']==vm['oracle_build']['version']=='3.46.1'
assert native['image_sha256']==native['loaded_image_sha256']=='db2b8c170ef033300f604b4d1d2762b0bba3390ffd8261daaaebdc538d961a01'
for value in (vm,native):
 for name in ('errors','failures','skipped','expected_failures','unexpected_successes'):assert value[name]==[]
original=load(DEV/'source-r1/source.json')['files'];fixed=load(DEV/'source-r2/source.json')['files']
assert original[:4]==fixed[:4] and original[-1]['path']==fixed[-1]['path']
for row in fixed:
 raw,info=read(SOURCE/row['path']);assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'] and stat.S_IMODE(info.st_mode)==row['mode']
paths=[]
for p in sorted(DEV.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():
  assert '__pycache__' not in p.parts
  paths.append(('comparison/'+str(p.relative_to(DEV)),p))
for name in ('libsqlite346-reference.so','source.json'):
 paths.append(('sqlite-3.46.1-reference/'+name,BASE/'sqlite-3.46.1-reference-oracle'/name))
paths.append(('sqlite-3.46.1-reference/sqlite-amalgamation-3460100.zip',BASE/'sqlite-amalgamation-3460100.zip'))
for name in ('tools/generate_hia_agent_namespace_store.py','docs/HIA_AGENT_NAMESPACE_STORE_ABI.json'):
 paths.append(('authoring-dependencies/'+name,SOURCE/name))
paths.append(('seal_compare_r1.py',Path(__file__).resolve()))
paths.sort();members=[]
for name,p in paths:
 raw,info=read(p)
 members.append({'name':name,'original':str(p),'bytes':len(raw),'mode':stat.S_IMODE(info.st_mode),'sha256':sha256(raw).hexdigest(),
  'device':info.st_dev,'inode':info.st_ino,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns})
custody={'schema':'hia.namespace.comparison.complete-development.v1',
 'scope':'Comparison owner only. Native scalar affinity/addition, objects/views/log/syscalls/migration/installed ordinary namespace remain incomplete; no cold or full qualification claim.',
 'source_manifest_sha256':sha256(read(DEV/'source-r2/source.json')[0]).hexdigest(),
 'production_source_unchanged_between_fixture_revisions':True,
 'first_harness_failure':{'tests_attempted':6,'harness_errors':6,'hia_entries':0,'all_originals_retained':True},
 'oracle_version':native['sqlite_version'],'oracle_source_id':native['sqlite_source_id'],
 'oracle_test_cases':3313,'core_vm_tests':6,'actual_native_tests':6,'actual_native_entries':3628,
 'all_native_vm_return_output_workspace_input_and_guards_equal':3628,
 'native_workspace_instances':native['counters']['persistent_workspaces'],
 'image_sha256':native['image_sha256'],'compiler_sha256':native['compiler_sha256'],
 'original_files':len(members),'original_bytes':sum(r['bytes'] for r in members),'members':members}
custody_raw=(json.dumps(custody,sort_keys=True,indent=2)+'\n').encode();(OUT/'custody.json').write_bytes(custody_raw)
archive=OUT/'namespace-comparison-r1-development.tar.xz'
with tarfile.open(archive,'w:xz',preset=1) as tar:
 for row in members:
  raw,info=read(Path(row['original']));assert sha256(raw).hexdigest()==row['sha256'] and len(raw)==row['bytes']
  item=tarfile.TarInfo(row['name']);item.size=len(raw);item.mode=row['mode'];item.mtime=0;tar.addfile(item,io.BytesIO(raw))
 item=tarfile.TarInfo('CUSTODY.json');item.size=len(custody_raw);item.mode=0o600;tar.addfile(item,io.BytesIO(custody_raw))
with tarfile.open(archive) as tar:
 assert tar.getnames()==[r['name'] for r in members]+['CUSTODY.json']
 for row in members:
  item=tar.getmember(row['name']);raw=tar.extractfile(item).read();original,info=read(Path(row['original']))
  assert item.isfile() and item.mode==row['mode'] and len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'] and original==raw
  assert info.st_dev==row['device'] and info.st_ino==row['inode'] and info.st_mtime_ns==row['mtime_ns'] and info.st_ctime_ns==row['ctime_ns']
 assert tar.extractfile('CUSTODY.json').read()==custody_raw
raw,_=read(archive)
summary={'status':'ALL_SELECTED_ORIGINAL_MEMBERS_REPLAYED','scope':custody['scope'],'archive':str(archive),
 'archive_bytes':len(raw),'archive_sha256':sha256(raw).hexdigest(),'custody':str(OUT/'custody.json'),
 'custody_bytes':len(custody_raw),'custody_sha256':sha256(custody_raw).hexdigest(),
 'original_members':len(members),'archive_members':len(members)+1,'original_raw_bytes':custody['original_bytes'],
 'original_bytes_modes_inode_mtime_ctime_unchanged':True}
(OUT/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
