from pathlib import Path
from hashlib import sha256
import json
import os
import resource
import sys
import time
import unittest

BASE=Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE=BASE/'namespace-authoring-next'
DEV=BASE/'namespace-reconstruction/compare-r1'
OUT=DEV/'vm-r2'
OUT.mkdir(exist_ok=False)
ORACLE=BASE/'namespace-reconstruction/sqlite-3.46.1-reference-oracle'
os.environ['HIA_NAMESPACE_SQLITE_REFERENCE']=str(ORACLE/'libsqlite346-reference.so')
os.environ['HIA_NAMESPACE_SQLITE_REFERENCE_VERSION']='3.46.1'
os.environ['HIA_NAMESPACE_COMPARE_LEDGER']=str(OUT/'vm-entries')
sys.path.insert(0,str(SOURCE))
resource.setrlimit(resource.RLIMIT_AS,(1024<<20,1024<<20))
resource.setrlimit(resource.RLIMIT_CPU,(300,300))
from tests.test_hia_agent_namespace_compare import NamespaceCompareTests
pins={}
for row in json.loads((DEV/'source-r2/source.json').read_bytes())['files']:
 p=SOURCE/row['path'];raw=p.read_bytes()
 assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'] and p.stat().st_mode&0o777==row['mode']
 pins[str(p)]=sha256(raw).hexdigest()
for p in (ORACLE/'sqlite3.c',ORACLE/'sqlite3.h',ORACLE/'libsqlite346-reference.so',Path(__file__).resolve(),SOURCE/'hepta/hia_program_runtime.py'):
 pins[str(p)]=sha256(p.read_bytes()).hexdigest()
assert pins[str(ORACLE/'sqlite3.c')]=='6c35bc5f7f85eac9c49928bacbb02bb694b547aabf69197e058cca245ad80e83'
assert pins[str(ORACLE/'libsqlite346-reference.so')]=='fa3e9901f4d70fb616d9cb48581f4a8d37892c1752e7ff9058ec7b98189e59b1'
(OUT/'source-before.json').write_text(json.dumps(pins,sort_keys=True,indent=2)+'\n')
start=time.monotonic_ns()
suite=unittest.defaultTestLoader.loadTestsFromTestCase(NamespaceCompareTests)
ids=[t.id() for t in suite]
result=unittest.TextTestRunner(verbosity=2).run(suite)
after={p:sha256(Path(p).read_bytes()).hexdigest() for p in pins}
(OUT/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
value={'scope':'DEVELOPMENT comparison only; actual SQLite3.46.1 oracle; no physical database qualification',
 'test_ids':ids,'tests_loaded':len(ids),'tests_run':result.testsRun,
 'errors':[(t.id(),s) for t,s in result.errors],'failures':[(t.id(),s) for t,s in result.failures],
 'skipped':result.skipped,'expected_failures':[(t.id(),s) for t,s in result.expectedFailures],
 'unexpected_successes':[t.id() for t in result.unexpectedSuccesses],
 'entries':NamespaceCompareTests.entries,'oracle_cases':NamespaceCompareTests.cases,
 'source_unchanged':pins==after,'wall_elapsed_ns':time.monotonic_ns()-start,
 'oracle_build':{'command':['cc','-O0','-fPIC','-shared','-DSQLITE_THREADSAFE=1','sqlite3.c','-Wl,-Bsymbolic','-ldl','-lpthread','-lm','-o','libsqlite346-reference.so'],
 'source_sha256':pins[str(ORACLE/'sqlite3.c')],'image_sha256':pins[str(ORACLE/'libsqlite346-reference.so')],
 'build_exit_code':0,'build_stdout':'','build_stderr':'','version':NamespaceCompareTests.reference.version,
 'source_id':NamespaceCompareTests.reference.source_id}}
value['status']='PASS' if 0<result.testsRun==len(ids)==6 and pins==after and not any(value[k] for k in ('errors','failures','skipped','expected_failures','unexpected_successes')) else 'FAIL'
raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();(OUT/'result.json').write_bytes(raw)
print(json.dumps({'status':value['status'],'tests':result.testsRun,'entries':value['entries'],'oracle_cases':value['oracle_cases'],'result_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
raise SystemExit(0 if value['status']=='PASS' else 1)
