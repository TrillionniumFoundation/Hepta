# Complete namespace engine composition

This development work continues the frozen ten-table, 31-relational-operation,
51-call inventory in `HIA_AGENT_NAMESPACE_STORE_ABI.json`. The operation catalog
is not replaced by a smaller storage API. No new namespace-wide row, byte,
decimal-digit, history or transaction-count limit is introduced. The retained
SQLite owner remains selected until the complete native path, installed callers,
migration and physical crash/race gates pass.

## Remaining execution ownership

| Surface | Native decision owner | Required actual peer and acceptance gate |
| --- | --- | --- |
| Five-class value envelopes | `agent_namespace_values` | Immutable issued cells and vectors, arbitrary TEXT/BLOB extent; full incremental envelope validation |
| All 31 predicates, projections, INSERT/UPDATE/IGNORE, constraints and statement results | `agent_namespace_rows` | Native generic scalar/vector/index/log peers; all ten final tables equal the original whole SQL oracle |
| BEGIN/COMMIT/ROLLBACK/autocommit, known errors, unknown ACK, cleanup and close | `agent_namespace_transactions` | Actual namespace/lock/view/pending/data-sync/root-publication/retirement syscalls and leases |
| Storage class, SQL comparison and index comparison | `agent_namespace_compare` | Actual issued cell bytes, exact mixed INTEGER/REAL order and BINARY collation; no affinity substitution |
| NUMERIC/TEXT affinity and SQL addition | Still to implement | Exact SQLite 3.46.1 decimal conversion, real formatting and overflow behavior; existing JSON float formatting is not a substitute |
| Vector replacement, constants, projection, result builders and independent result lifetime | Still to implement | Native role/generation registry, allocation growth and no reuse of retired handles |
| Committed and pending views, cursor/index order, rowid and high-water | Still to implement | Native selection and ordering; random non-AUTOINCREMENT rowid fallback; real statement rollback |
| Physical commit, read snapshots, recovery and migration | Still to implement | Immutable log and actual filesystem custody, durability ordering and complete old-writer fencing |
| Content identity and ordinary AgentStore callers | Still to compose | Existing HIA journal and hash decisions plus actual namespace issuance, file and directory sync; all retained public callers |

The row owner's 18 generic actions and transaction owner's 13 actions are the
complete current continuation interfaces. A fixed mechanical executor may map
owned buffers/descriptors, copy an exact requested range and report an exact
syscall result. It may not select rows, choose table semantics, normalize values,
decide that a commit happened, fabricate a result handle or substitute a hosted
peer for a missing HIA implementation.

## Leases and durability requirements

Every generic object is bound to its real namespace/session, role, producer,
call/action generation and completed native frame. Numeric handle/header echoes
alone are not authentication for externally supplied buffers. Read-only calls
still get distinct lease generations even when the durable transaction number
does not change. Zero-change COMMIT retires pending/view/value leases and
unlocks. Published results are detached owners that outlive these retirements.

Statement rollback restores the pending overlay and sequence high-water to the
actual statement mark. Whole transaction rollback discards only unpublished
work. Data fsync, publication and root fsync remain separate real boundaries;
an unknown acknowledgement after publication cannot be reported as rollback or
re-executed as a fresh request. A later session must inspect the actual committed
head. Existing HIA request-journal intent, replay and ACK-before-COMMIT rules are
reused unchanged.

Migration must preserve all five stored classes, NULL keys, signed rowids,
sequence high-water, arbitrary decimal TEXT, BLOB bytes, schema behavior and
multiwriter effects. A cooperative new-engine lock or renamed database alone
does not fence an already open old SQLite writer. That boundary remains open
until an actual native migration/locking design and concurrent-writer controls
prove it. The runtime must not activate a partial engine in the meantime.

## Native comparison protocol, revision 1

The RWW entry has input `64 + cells`, output128 and workspace128 minimum bytes.
The workspace starts zero. A successful session can compare repeatedly; each
new call uses the same nonzero session pair and exactly the preceding call plus
one. The u64 call counter cannot wrap; a fresh owner is required after exhaustion.
This is a live protocol counter, not a persistent namespace size/count quota.

The eight-word little-endian header is:

    [HIANCP01, command, sessionLo, sessionHi, call,
     leftLease, rightLease, exactPayloadBytes]

Command1 performs SQL comparison, command2 performs total index comparison,
and command3 reports the effective storage class. Commands1/2 require two
nonzero actual cell leases and exactly two envelopes; command3 requires one
nonzero lease, rightLease0 and exactly one envelope. An envelope is kind:u64,
payloadBytes:u64, then exact raw bytes. NULL0 has zero payload, INTEGER1 and
REAL2 have eight payload bytes, TEXT3 and BLOB4 have any actually present extent.
The integer is signed two's complement and REAL is IEEE binary64 bits. Every
header, length and complete pair is validated before a comparison result is
published. There is no whole-value or store-wide quota in this kernel.

The 16-word output is:

    [magic,status,sessionLo,sessionHi,call,command,leftLease,rightLease,
     leftKind,rightKind,result,reason,schema1,0,0,0]

Status0 is success; BAD0xfffffffd is permanent refusal. For comparison the
result is LT0/EQ1/GT2/UNKNOWN3. For command3 it is the effective storage class.
Malformed frame, invalid cell, stale/skipped call, wrong session, incoherent
workspace or insufficient output permanently poisons a usable workspace.
A workspace shorter than128 cannot record poison and must be discarded by the
executor. Retrying a valid frame after BAD cannot reset the same workspace.

NaN bindings have SQLite's effective NULL class. Infinity remains REAL. SQL
comparison involving NULL is UNKNOWN; index comparison orders NULL first and
considers two NULLs equal. Numeric values precede TEXT, which precedes BLOB.
INTEGER/REAL comparisons use the full signed integer and the binary64 exponent
and significand, without first rounding an INTEGER through binary64. Positive
and negative zero compare equal. TEXT and BLOB use unsigned byte comparison and
then length, including embedded NUL and raw non-UTF-8 bytes. These are the bytes
presented to the retained BINARY collation; this kernel does not convert a
legacy database's text encoding or apply either operand's column affinity.

The existing values owner validates incremental envelopes. The future object
registry supplies the real immutable cell bytes to this comparison owner.
This component's frame validation cannot certify independently supplied cells
as members of a database, establish a filename's authority, or commit a row.

## Reference and evidence discipline

Tests use the exact unmodified SQLite 3.46.1 amalgamation as a separate oracle
when `HIA_NAMESPACE_SQLITE_REFERENCE` names that library; the required version
is checked and an invalid explicit path never falls back. The source archive is
from <https://www.sqlite.org/2024/sqlite-amalgamation-3460100.zip>. The original
`sqlite3MemCompare`, `sqlite3IntFloatCompare` and `binCollFunc` define the retained
behavior. Oracle compiler inputs, output, source id and hashes are recorded.
SQLite is never linked into the generated HIA image or production peer.

Core VM comparisons, real B3 compilation and actual native entry comparisons
are separate evidence. Complete input/output/workspace and guard bytes must
agree for each paired invocation, and before/after source/image pins must match.
Neither this test-only library nor a passing comparison component proves the
remaining object/view/log/syscall/migration or ordinary-caller gates.
