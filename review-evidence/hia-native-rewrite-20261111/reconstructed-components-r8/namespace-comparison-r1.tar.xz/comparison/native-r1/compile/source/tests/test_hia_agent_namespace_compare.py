"""Native five-class comparison decisions against the actual SQLite oracle."""
from __future__ import annotations

import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import random
import struct
import unittest

from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from tests.hia_namespace_sqlite_reference import SQLiteReference, cell, envelope

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANCP01', 'little')
BAD = 0xfffffffd
MASK = (1 << 64) - 1
CANARY = bytes(range(192, 224))


def frame(left, right=None, command=1, call=1, session=(0xabc, 0xdef)):
    payload = envelope(left) + (b'' if command == 3 else envelope(right))
    return struct.pack('<8Q', MAGIC, command, *session, call, 17,
                       0 if command == 3 else 18, len(payload)) + payload


def real_bits(bits):
    return 2, struct.pack('<Q', bits)


class NamespaceCompareTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT/'examples/hia_bootstrap/agent_namespace_compare.hiaasm').read_bytes()
        cls.program = assemble_program(cls.raw)
        cls.entry = cls.program.as_dict()['functions'][0]
        cls.reference = SQLiteReference()
        cls.entries = cls.cases = 0
        cls.evidence = Path(os.environ['HIA_NAMESPACE_COMPARE_LEDGER']) if os.environ.get('HIA_NAMESPACE_COMPARE_LEDGER') else None
        cls.ledger = None
        if cls.evidence:
            cls.evidence.mkdir(parents=True, exist_ok=False)
            cls.ledger = gzip.open(cls.evidence/'invocations.jsonl.gz', 'wt', encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        if cls.ledger:
            cls.ledger.close()
            (cls.evidence/'counts.json').write_text(json.dumps({
                'scope': 'COMPARISON DEVELOPMENT; NO NATIVE DATABASE CLAIM',
                'source_sha256': hashlib.sha256(cls.raw).hexdigest(),
                'entries': cls.entries, 'oracle_cases': cls.cases,
                'sqlite_library': cls.reference.path, 'sqlite_version': cls.reference.version,
                'sqlite_source_id': cls.reference.source_id,
                'sqlite_statements': cls.reference.entries,
            }, sort_keys=True, indent=2) + '\n')
        cls.reference.close()

    def log(self, value):
        if self.ledger:
            self.ledger.write(json.dumps(value, sort_keys=True, separators=(',', ':'))+'\n')
            self.ledger.flush()

    def invoke(self, raw, work, output_size=128):
        original, before = bytes(raw), bytes(work)
        owners = [_Owner(-1, bytearray(original)), _Owner(-2, bytearray(output_size)), _Owner(-3, work)]
        machine = _Machine(self.program, 1000000, 64 << 20, None, 64)
        result = machine.invoke(self.entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
        output = bytes(owners[1].data)
        type(self).entries += 1
        self.assertEqual(bytes(owners[0].data), original)
        self.log({'kind': 'vm_entry', 'entry': type(self).entries, 'test_id': self.id(),
                  'input_hex': original.hex(), 'workspace_before_hex': before.hex(),
                  'workspace_after_hex': bytes(work).hex(), 'output_hex': output.hex(),
                  'return': result, 'output_descriptor_bytes': output_size})
        return result, output

    def compare(self, left, right=None, command=1, work=None):
        if work is None:
            work = bytearray(128)
        call = struct.unpack_from('<Q', work, 32)[0] + 1
        raw = frame(left, right, command, call)
        expected, left_kind, right_kind = self.reference.compare(left, right, command)
        code, payload = self.invoke(raw, work)
        output = struct.unpack('<16Q', payload)
        self.log({'kind': 'oracle_case', 'case': type(self).cases, 'input_hex': raw.hex(),
                  'expected': expected, 'left_kind': left_kind, 'right_kind': right_kind,
                  'output': output, 'sqlite_version': self.reference.version})
        type(self).cases += 1
        self.assertEqual(code, 0)
        self.assertEqual(output, (MAGIC, 0, 0xabc, 0xdef, call, command, 17,
                                 0 if command == 3 else 18, left_kind, right_kind,
                                 expected, 0, 1, 0, 0, 0))
        return expected

    def test_all_storage_classes_sql_and_index_comparison(self):
        values = [None, -(1 << 63), -1, 0, 1, (1 << 63)-1,
                  -math.inf, -1.5, -0.0, 0.0, 0.5, math.inf,
                  '', '0', 'a\x00b', 'é', '中', b'', b'0', b'\x00', b'\xff']
        cells = [cell(v) for v in values] + [real_bits(0x7ff0000000000001), real_bits(0xfff8000000000001), (3, b'\xff\0\xc0')]
        work = bytearray(128)
        for left in cells:
            self.compare(left, command=3, work=work)
            for right in cells:
                self.compare(left, right, 1, work)
                self.compare(left, right, 2, work)

    def test_exact_integer_real_edges_without_binary64_integer_rounding(self):
        work = bytearray(128)
        for power in range(64):
            integer = (1 << power) - 1
            for sign in (-1, 1):
                value = integer * sign
                for real in (float(value), math.nextafter(float(value), -math.inf), math.nextafter(float(value), math.inf)):
                    self.compare(cell(value), cell(real), work=work)
                    self.compare(cell(real), cell(value), work=work)
        for value in (-(1 << 63), -(1 << 53)-1, (1 << 53)+1, (1 << 63)-1):
            for bits in (0, 1, 0x8000000000000000, 0x8000000000000001,
                         0x7ff0000000000000, 0xfff0000000000000,
                         0x43e0000000000000, 0xc3e0000000000000,
                         0x43dfffffffffffff, 0xc3e0000000000001):
                self.compare(cell(value), real_bits(bits), work=work)

    def test_fixed_seed_full_ieee_payloads_and_integer_pairs(self):
        randomizer = random.Random(0x4849414e43503031)
        work = bytearray(128)
        for _ in range(384):
            a, b = randomizer.getrandbits(64), randomizer.getrandbits(64)
            left = real_bits(a) if randomizer.randrange(2) else (1, struct.pack('<Q', a))
            right = real_bits(b) if randomizer.randrange(2) else (1, struct.pack('<Q', b))
            self.compare(left, right, 1, work)
            self.compare(left, right, 2, work)

    def test_binary_collation_includes_raw_bytes_and_embedded_nul(self):
        work = bytearray(128)
        for kind in (3, 4):
            for value in range(256):
                self.compare((kind, b'a\0'+bytes([value])), (kind, b'a\0\x80'), work=work)
            for size in (0, 1, 7, 8, 63, 64, 4095, 4096):
                raw = b'\xc0\0\xff\xed' * (size // 4) + b'a' * (size % 4)
                for other in (raw, raw+b'\0', raw+b'\xff'):
                    self.compare((kind, raw), (kind, other), work=work)

    def test_invalid_frames_cells_and_short_descriptors_permanently_refuse(self):
        valid = frame(cell(1), cell(2))
        invalid = [valid[:n] for n in range(len(valid))]
        invalid += [valid+b'\0', valid+b'\0'*16]
        for word, value in ((0, MAGIC^1), (1, 0), (1, 4), (4, 0), (4, 2),
                            (5, 0), (6, 0), (7, 0), (7, len(valid)-63)):
            changed = bytearray(valid)
            struct.pack_into('<Q', changed, word*8, value)
            invalid.append(bytes(changed))
        zero_session = bytearray(valid)
        zero_session[16:32] = bytes(16)
        invalid.append(bytes(zero_session))
        for kind, size, payload in ((5, 0, b''), (0, 1, b'\0'), (1, 7, bytes(7)),
                                    (2, 9, bytes(9)), (3, MASK, b''), (4, 1, b'')):
            bad_cell = struct.pack('<QQ', kind, size)+payload
            for body in (bad_cell+envelope(cell(2)), envelope(cell(1))+bad_cell):
                invalid.append(valid[:56]+struct.pack('<Q', len(body))+body)
        for raw in invalid:
            work = bytearray(128)
            code, out = self.invoke(raw, work)
            self.assertEqual(code, BAD)
            reason = struct.unpack_from('<Q', work, 88)[0]
            self.assertNotEqual(reason, 0)
            before = bytes(work)
            self.assertEqual(self.invoke(valid, work)[0], BAD)
            self.assertEqual(bytes(work), before)
        for size in (0, 1, 8, 127):
            work = bytearray(128)
            code, out = self.invoke(valid, work, size)
            self.assertEqual((code, out), (BAD, bytes(size)))
            self.assertEqual(self.invoke(valid, work)[0], BAD)
        for size in (0, 1, 8, 127):
            work = bytearray(size)
            code, out = self.invoke(valid, work)
            self.assertEqual((code, out, bytes(work)), (BAD, bytes(128), bytes(size)))

    def test_session_sequence_shape_and_corrupt_private_state(self):
        work = bytearray(128)
        self.compare(cell(1), cell(2), work=work)
        saved = bytes(work)
        bad_frames = [frame(cell(1), cell(2), call=1), frame(cell(1), cell(2), call=3),
                      frame(cell(1), cell(2), call=2, session=(0xabc, 0xdee))]
        for raw in bad_frames:
            current = bytearray(saved)
            self.assertEqual(self.invoke(raw, current)[0], BAD)
            self.assertEqual(self.invoke(frame(cell(1), cell(2), call=2), current)[0], BAD)
        mutations = ((0, 0), (8, 0), (32, 0), (40, 4), (48, 0), (56, 0),
                     (64, 5), (72, 5), (80, 4), (88, 1), (96, 1), (120, 1))
        for offset, value in mutations:
            current = bytearray(saved)
            struct.pack_into('<Q', current, offset, value)
            self.assertEqual(self.invoke(frame(cell(1), cell(2), call=2), current)[0], BAD)
            self.assertEqual(self.invoke(frame(cell(1), cell(2), call=2), current)[0], BAD)
        exhausted = bytearray(saved)
        struct.pack_into('<Q', exhausted, 32, MASK)
        self.assertEqual(self.invoke(frame(cell(1), cell(2), call=0), exhausted)[0], BAD)


if __name__ == '__main__':
    unittest.main(verbosity=2)
