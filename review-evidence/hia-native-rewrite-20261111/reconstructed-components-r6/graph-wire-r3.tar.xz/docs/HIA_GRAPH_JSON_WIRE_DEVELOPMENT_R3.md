# Native GraphLease bounded JSON wire: development r3

## Delivered owner and limits

The scan and emit HIA images implement the complete default bounded-JSON
preflight and canonical wire computation needed by the edit display owners.
They accept the private GraphLease specified in HIA_GRAPH_JSON_WIRE_ABI.md.
They do not implement the single/batch display validators yet and do not close
the public foreign-object capture boundary.

HIA owns reverse-child DFS and queued/node/depth checks, active cycles,
per-string escaped length, Unicode surrogate rejection, scalar/key kinds,
numeric key conversion, key collisions, original-type key sorting, integer
decimal conversion, finite binary64 printing, escaping and complete output
bytes. There is no hosted JSON serializer or float printer in the forwarding
loop. The existing native binary64-format algorithm is included with only its
entry plumbing, function names and scratch offsets relocated.

The original maximum is 8 MiB, with at most 262144 value nodes and depth 128.
The caller's requested maximum may be smaller. Dict keys do not count as value
nodes. Shared containers count per occurrence; only active identities cause
cycle rejection. All original limits and semantic rejection order remain.
Storage GROW is separate from those limits.

The private command records ensure_ascii, sort_keys and the existing foreign
integer-decimal digit profile. A zero digit limit means the foreign runtime has
disabled that compatibility setting. The default Python 3.12 setting in these
tests is 4300. Native renderer callers supply their fixed maximum/options; the
command is not an independent public API for arbitrary Python option objects or
custom user callbacks.

Actual source structure is recorded in generation-r3.log. Both images fit the
unchanged 128-function/1536-block/8192-instruction/256-block-per-function/
16-block-parameter limits. The actual f50 B3 compiler used its original
10 CPU second, 20 wall second and 256 MiB execution limits.

## Exact identity

The current source checkpoint is checkpoints/source-r3/source.json,
SHA-256 eda2a72dd1d8dbd30f49723ddba5158ad6be64e71cb04ded28a0521ea7885117.

The actual development bundle is development/compile-r3/bundle.json,
SHA-256 c69e1391e6e49cfd4bf5813a258a3705e0c23a2ef52d37f785a734e29e92d70d.

| Component | HIA SHA-256 | Actual image SHA-256 |
| --- | --- | --- |
| scan | c1cb49c1df3c4c653dfd37beebba12b3baf57a28a7d77c257157d2cc7e58cde3 | 3545a6c60334b5f7e92eda8df582472a2a493c74b814e5ac9158cdd2e866b026 |
| emit | 9ad72bddb7eaa3d9118155a056e4c5faa7ff3e015e45fbc2d09dae14e2cfb7a2 | 9b69271adb5c3024842fc065e294b9a3550077801b76e43046c4eb09e3925a80 |

Both source/image pairs are development artifacts, not current-source cold
qualification. The compile snapshot label UNEXECUTED records when source was
frozen; the later compile bundle and execution groups prove the subsequent real
execution of those same bytes.

## Actual comparisons

| Group | Cases | Logged scan entries | Logged emit entries |
| --- | ---: | ---: | ---: |
| smoke-r3-attempt1 | 150 | 180 | 259 |
| boundaries-r3-attempt1 | 538 | 618 | 626 |
| protocol-r3-attempt1 | 44 | 86 | 45 |
| Total | 732 | 884 | 930 |

The first two groups are 688 complete comparisons with the independent existing
bounded_json_wire: either every canonical byte or the entire public error text
must match. The protocol group supplies 44 additional private ABI/state
controls. It includes one direct short-workspace call outside the generic
logged-entry wrapper, recorded by its returned value and successful assertion
in the full-state-short-extent case. Therefore there are 1814 logged native
entries plus that one direct entry: 1815 observed r3 entries in total. Compile
calls and older r2 executions are separate.

Coverage includes:

- Every JSON scalar kind, exact tuple/list distinction in capture, general
  attrs/metadata, arbitrary integer values, negative zero and normal/subnormal
  binary64 values.
- 2048 deterministic finite IEEE values, including no host numeric conversion
  in the actual forwarding loop; exact numeric dictionary-key ordering near
  2**53, subnormal zero and the largest finite float.
- 500 deterministic mixed graphs, including malformed values and first-error
  competition. Dict keys are checked before any dict value, while value DFS
  retains reverse insertion order.
- Actual node counts at 262143/262144/262145 including the root, exact depths
  127/128/129, shared aliases counted per occurrence, and active cycles.
- Complete ASCII strings around the 1 MiB and 8 MiB byte limits, escaped and
  unescaped non-BMP strings, the cumulative encoding budget, lone surrogates,
  control characters and DEL.
- Integer decimal lengths 4299/4300/4301, key conversion before invalid value
  failure, and recorded foreign digit profiles 640 and zero.
- Complete command/graph/node malformed boundaries, wrong image order, all
  relevant GROW command correlations, semantic refusal, and both entry points
  permanently refusing after the first protocol failure or completed session.

All ordinary calls check both input buffers and their canaries, and the mutable
workspace's actual capacity canary. Every successful run rereads admitted source,
manifest and image bytes. Full native inputs, commands, canonical outputs,
events, summaries and logs are retained. No expected wire is given to the HIA
images. The test-only complete GraphLease capture is separate from actual
forwarding and does not perform JSON admission.

## Refusal codes

Semantic refusal has event action 3, returns 128, and exposes the exact
E_HIA_EDIT message through these numeric codes:

| Code | Message after E_HIA_EDIT: |
| ---: | --- |
| 1 | invalid JSON output byte budget |
| 2 | JSON string exceeds byte budget before encoding |
| 3 | unpaired Unicode surrogate in UTF-8 JSON |
| 4 | JSON input exceeds nesting depth before encoding |
| 5 | JSON input exceeds node/byte budget |
| 6 | JSON container exceeds queued-node/byte budget |
| 7 | cyclic JSON container |
| 8 | unsupported JSON object key |
| 9 | JSON key exceeds numeric byte budget |
| 10 | nonfinite JSON object key |
| 11 | JSON key exceeds byte budget |
| 12 | JSON object key collision after JSON conversion |
| 13 | JSON integer exceeds byte budget |
| 14 | non-JSON in-process value |
| 15 | invalid bounded JSON |
| 16 | JSON encoding exceeds byte budget |

The generic invalid-bounded code retains a cause kind: 1 for value conversion
failure, 2 for incomparable sorting types. These cause tags are not a claim
that implementation-specific Python traceback objects or all private exception
repr strings have been duplicated.

ABI failure is the distinct 0xfffffffd return; event contents alone never
override it. The fixed driver disposes of every failed lease, including any
buffer too short to physically retain a poison marker.

## Preserved failures and corrections

The initial authoring passed the ordinary Core verifier but the first actual
f50 compilation rejected its RRW entry ABI. Revision r2 adds the fixed RWW entry
wrapper, borrows the second buffer read-only, calls the unchanged internal
owner, and ends that loan. No compiler limit was raised.

A generation-time limit assertion initially examined the un-compacted authoring
CFG. It was corrected to inspect the exact compacted Core that is actually
rendered and compiled. All five original limits remain checked, and the
ordinary verifier plus actual compiler independently enforce the emitted code.

The r2 actual smoke group passed 150 semantic cases. A separate two-call actual
protocol probe then found that a malformed first command returned BAD, but a
corrected command in the same workspace could clear the failure when state
magic was still zero. Its original inputs, events and source pins are retained
in development/poison-r2-counterexample. Revision r3 checks the broken flag and
terminal phase before any initialization. The original probe and the expanded
44 protocol controls now refuse permanently. The earlier r2 pass is not
misrepresented as complete protocol qualification.

## Reuse

For a test-only fixed executor, import development/graph_harness_r3.py and use
Actual(out).serialize_graph(actual_graph_bytes, maximum, flags=3, digits=4300).
That direct method does not call the mechanical object capture. A native
typed-packet-to-GraphLease issuer can therefore supply the graph directly.

Production composition should forward the complete HIAGWC01 command and actual
GraphLease to scan, grow only on action 1, switch to emit only on action 2, and
consume the complete output view only on action 0. The event source/root/sequence/
options remain correlated, and a GROW replay uses the same immutable input.

A complete foreign-object capture before native admission remains a component
transport only. For huge foreign objects it could allocate before the old
fanout-first gate; a native-requested windowed capture or equally proved
resource-preserving boundary is still required. Header or identity equality
does not authenticate an arbitrary graph. The parent coordinator's separate
trusted typed query bridge does not turn this into an untrusted display-input
admission shortcut.

Single and batch render validators, batch textual decoding to a general graph,
public selection, installation/cold/full acceptance, and removal of old hosted
owners remain explicit subsequent work.

