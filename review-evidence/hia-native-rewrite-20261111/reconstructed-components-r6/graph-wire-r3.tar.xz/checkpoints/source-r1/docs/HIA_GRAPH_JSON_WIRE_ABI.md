# GraphLease and native bounded JSON wire — ABI r1

This is a new private component contract for complete general-JSON presentation.
It is not an authenticated external object format and is not public admission.
The fixed issuer retains immutable graph bytes for the entire native operation.
A header, object identity or nonce alone cannot authenticate supplied memory.

## GraphLease

Eight little-endian u64 words form the 64-byte header:

| Word | Field |
| --- | --- |
| 0 | ASCII magic HIAGRF01 |
| 1 | Nonzero lease identity |
| 2 | Node count |
| 3 | Root node ID, one based |
| 4 | Edge count, in u64 elements |
| 5 | Scalar byte count |
| 6 | Complete graph byte count |
| 7 | Zero |

The node table immediately follows the header. Each node is 64 bytes/eight u64
words. The edge table immediately follows all nodes, then the scalar byte pool.
All additions/multiplications must be range checked. The advertised total is
the exact input extent; there is no padding after the scalar pool.

| Node word | Meaning |
| --- | --- |
| 0 | Exact kind |
| 1 | Absolute scalar-pool offset, or zero |
| 2 | Scalar payload bytes, or zero |
| 3 | First edge index, zero based, or zero |
| 4 | Container arity, or zero |
| 5 | Container identity (nonzero), zero for scalar kinds |
| 6 | Kind-specific auxiliary word |
| 7 | Zero |

Kinds are: null=0, bool=1, integer=2, binary64=3, string=4, list=5, dict=6,
tuple=7, unsupported foreign kind=8, exact bytes=9. The last kind is available
for batch textual input; it is not a JSON value and bounded JSON serialization
rejects it. Subclasses are captured as unsupported kinds, not their base types.

Boolean aux is zero or one. Integer payload is the minimal little-endian
unsigned magnitude; aux is sign (zero positive/nonnegative, one negative). Zero
has zero payload bytes and zero sign. HIA computes bit length and decimal text.
Binary64 payload is exactly eight IEEE little-endian bytes, with aux zero.
String payload is canonical UTF-8 with surrogatepass; aux is its Unicode code
point count. This preserves lone surrogates for the original bounded-JSON gate
to reject at its own point. The private issuer establishes the encoding/count
facts; the visitor validates each visited encoded unit. Bytes payload is exact
raw bytes with aux zero. Null/unsupported have no payload and aux zero.

List/tuple edges are child IDs in original order. Dict edges are key,value
pairs, so edge range length is twice arity. Node IDs are valid one-based table
indices. Shared containers reuse a node ID and identity; cycles are represented
by back edges. Dict insertion order is retained. Containers have no scalar
payload and aux zero.

The kernel does not impose a graph-wide node/call/byte quota. Only the requested
root's existing bounded-JSON limits decide semantic rejection. A root may be a
subtree within a larger shared graph.

## Native wire service

Two HIA images, scan and emit, share one workspace. Both have the normal
read/read/write input form: the first read buffer is GraphLease, the second is
the complete command, and the workspace owns its state, temporary tables and
output. All references are offsets. The initial workspace is at least 32768
bytes; storage may grow. Short buffers which cannot hold a poison marker
require unconditional disposal by the driver.

The immutable 64-byte command is:

[HIAGWC01, graphLease, requestSequence, rootID, maximumBytes,
 flags, integerDecimalDigitLimit, 0]

flags bit0 is ensure_ascii and bit1 is sort_keys. Both are true for the existing
edit renderers. Other flag bits are invalid ABI. maximumBytes is in 0..8388608.
The integer digit limit records the existing foreign runtime profile:
sys.get_int_max_str_digits(), with zero meaning disabled. It is not an added
language quota. The fixed native deployment must specify the compatibility
profile explicitly.

Each ordinary result returns 128 and publishes this sixteen-word event:

[HIAGWE01, action, lease, requestSequence, rootID, maximumBytes, flags,
 integerDecimalDigitLimit, errorCode, causeKind, neededWorkspace,
 outputOffset, outputBytes, nextKernel, phase, abiReason]

Action zero is completed canonical bytes; one is GROW; two hands the same
workspace/input to the emit image after complete scan; three is a semantic
refusal. An ABI failure returns 0xfffffffd and poisons the session whenever its
state fits. Callers must inspect the return before trusting event bytes.

GROW copies the existing workspace to at least neededWorkspace and replays
the identical command/GraphLease to the same image. Sequence and semantic
progress do not restart. A completed or refused session cannot be reused.
A new serialization request has a fresh workspace but can borrow the same
immutable GraphLease and select a different root ID.

The scan image owns the original reverse-child DFS, queued/visited budgets,
active-container cycles, all original string/number/key preflight checks, key
conversion/collisions, and their precise ordering. The emit image owns original
sort_keys comparisons, general finite binary64 printing, arbitrary integer
printing within the declared profile, ASCII/non-ASCII string escaping, and
the cumulative canonical byte limit. Its output uses compact comma/colon
separators exactly as bounded_json_wire.

The existing HIA binary64-format algorithm is copied at authoring time with
names and scratch offsets relocated. It remains HIA computation; no host
floating printer or numeric normalizer is used. If module limits require an
additional fixed service image, that will be a separately versioned contract,
not a relaxed compiler limit.

## Scope and open foreign capture boundary

A complete GraphLease capture is a mechanical component-test transport. It
preserves exact kinds, order, object identities and representation bits without
performing admission or canonicalization. Materializing a giant entire foreign
graph before the native gate could allocate more than the original fanout-first
rejection. Therefore this complete-graph capture alone does not close the public
foreign-object resource boundary.

The eventual public foreign capture must provide native-requested node/edge
windows or an equally proved bounded mechanism. A native-issued graph from a
successfully admitted raw JSON/typed value source may be used directly with its
appropriate custody proof. The parent coordinator will implement the complete
typed-packet-to-GraphLease bridge for its canonical query output; that does not
weaken the separate untrusted single/batch renderer domain.

No integer-only codec may silently reject finite floats or erase exact tuple,
dict-key, bool/int/float and unsupported-kind distinctions before the old
renderer decides what to do with them.

