"""Complete GraphLease private protocol controls on the exact r3 images."""
import ctypes,json,struct,time
from pathlib import Path
from graph_harness_r3 import Actual,ROOT,capture,COMMAND,BAD,CANARY

native=Actual(ROOT/'development/protocol-r3-attempt1')
source=capture({'x':[1,2],'y':1.25})
header=list(struct.unpack_from('<8Q',source))
command=list((COMMAND,header[1],1,header[3],1048576,3,4300,0))
good=struct.pack('<8Q',*command)
cases=[];start=time.monotonic_ns();summary=None

def fresh(size=32768):
    w=ctypes.create_string_buffer(size+32);ctypes.memset(ctypes.addressof(w)+size,0xb9,32)
    return w

def poison_case(label,graph,wire,role='scan'):
    work=fresh()
    first=native.call(role,graph,wire,work,32768,label+'-bad')
    assert first[0]==BAD,(label,first)
    for target in ('scan','emit'):
        later=native.call(target,source,good,work,32768,label+'-retry-'+target)
        assert later[0]==BAD,(label,target,later)
    cases.append({'case':label,'status':'PERMANENT_BAD','both_entries_refused_after':True})

try:
    for word,value in [(0,0),(1,0),(1,20),(2,0),(3,0),(3,999),(5,4),(7,1)]:
        broken=command.copy();broken[word]=value
        poison_case(f'command-{word}-{value}',source,struct.pack('<8Q',*broken))
    for word,value in [(0,0),(1,0),(2,0),(2,2**64-1),(3,0),(3,999),(4,2**64-1),(5,0),(6,len(source)-1),(7,1)]:
        broken=header.copy();broken[word]=value
        graph=struct.pack('<8Q',*broken)+source[64:]
        poison_case(f'graph-header-{word}-{value}',graph,good)
    for size in (0,1,63,len(source)-1):
        poison_case(f'truncated-graph-{size}',source[:size],good)
    for size in (0,1,63,65):
        poison_case(f'command-size-{size}',source,good[:size] if size<=64 else good+b'x')
    # Node-shape failures occur after full graph admission, then poison both entries.
    for word,value in [(0,10),(1,1),(2,1),(3,header[4]+1),(4,header[4]+1),(5,0),(6,1),(7,1)]:
        broken=bytearray(source);struct.pack_into('<Q',broken,64+word*8,value)
        poison_case(f'root-node-{word}-{value}',bytes(broken),good)
    poison_case('emit-before-complete-scan',source,good,'emit')
    # Full-state short ABI refusal must remain refused after corrected extent.
    w=fresh()
    ret=native.images['scan']._entry(ctypes.create_string_buffer(source),len(source),
            ctypes.create_string_buffer(good),len(good),w,768)
    assert ret==BAD
    later=native.call('scan',source,good,w,32768,'correct-extent-after-full-state-short')
    assert later[0]==BAD
    cases.append({'case':'full-state-short-extent','status':'PERMANENT_BAD','first_return':ret})
    # Semantic refusal cannot be reused either.
    badmax=command.copy();badmax[4]=8388609
    w=fresh()
    first=native.call('scan',source,struct.pack('<8Q',*badmax),w,32768,'invalid-budget-semantic')
    assert first[0]==128 and first[1][1]==3 and first[1][8]==1
    for role in ('scan','emit'):
        assert native.call(role,source,good,w,32768,'invalid-budget-followup-'+role)[0]==BAD
    cases.append({'case':'semantic-budget-refusal-permanent','status':'PASS'})
    # GROW retry still checks all immutable command/header correlation.
    large=capture({str(i):i for i in range(1100)})
    h=struct.unpack_from('<8Q',large);wire=struct.pack('<8Q',COMMAND,h[1],1,h[3],1048576,3,4300,0)
    for word,value in [(1,21),(2,2),(3,2),(4,1048575),(5,2),(6,0)]:
        w=fresh();first=native.call('scan',large,wire,w,32768,'grow-base-'+str(word))
        assert first[0]==128 and first[1][1]==1,first
        size=first[1][10];grown=fresh(size);ctypes.memmove(grown,w,32768)
        broken=list(struct.unpack('<8Q',wire));broken[word]=value
        after=native.call('scan',large,struct.pack('<8Q',*broken),grown,size,'grow-mismatch-'+str(word))
        assert after[0]==BAD,after
        assert native.call('emit',large,wire,grown,size,'grow-followup-'+str(word))[0]==BAD
        cases.append({'case':'grow-command-mismatch-'+str(word),'status':'PERMANENT_BAD'})
    # Reusing a completed workspace is a protocol failure for both kernels.
    tiny=capture(None);h=struct.unpack_from('<8Q',tiny);wire=struct.pack('<8Q',COMMAND,h[1],1,h[3],4,3,4300,0)
    w=fresh(32772)
    assert native.call('scan',tiny,wire,w,32772,'done-scan')[1][1]==2
    done=native.call('emit',tiny,wire,w,32772,'done-emit')
    assert done[1][1]==0
    for role in ('scan','emit'):assert native.call(role,tiny,wire,w,32772,'done-retry-'+role)[0]==BAD
    cases.append({'case':'done-cannot-restart','status':'PERMANENT_BAD'})
    summary={'status':'PASS','scope':'PRIVATE_GRAPH_PROTOCOL_NO_EXTERNAL_AUTHENTICATION_CLAIM',
             'cases':cases,'native_entries':native.entries.copy(),'wall_elapsed_ns':time.monotonic_ns()-start,
             'r2_bad_initializer_recovery_counterexample_now_refused':True}
except BaseException as exc:
    summary={'status':'FAIL','error_type':type(exc).__name__,'error':str(exc),'completed':len(cases),'native_entries':native.entries.copy()}
    raise
finally:
    native.close();(native.out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)

