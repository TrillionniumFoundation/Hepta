"""Native general JSON differential, first-error and real-boundary controls."""
from pathlib import Path
import json,math,random,resource,struct,sys,time
from graph_harness_r3 import Actual,ROOT
native=Actual(ROOT/'development/boundaries-r3-attempt1')
rng=random.Random(0x47524150484c4541)
cases=[];start=time.monotonic_ns();summary=None
original_digits=sys.get_int_max_str_digits()

def check(value,maximum=1048576,*,case,ascii=True,sort=True):
    row=native.check(value,maximum,ensure_ascii=ascii,sort_keys=sort,case=case)
    row['integer_digit_profile']=sys.get_int_max_str_digits()
    cases.append(row)
    if len(cases)%100==0:print('completed',len(cases),flush=True)

def value(depth):
    if depth==0:kind=rng.randrange(8)
    else:kind=rng.randrange(12)
    if kind==0:return None
    if kind==1:return bool(rng.randrange(2))
    if kind==2:return rng.randrange(-(1<<130),1<<130)
    if kind==3:
        return struct.unpack('<d',rng.getrandbits(64).to_bytes(8,'little'))[0]
    if kind==4:return ''.join(chr(rng.choice([0,9,10,13,34,65,92,127,233,20013,128512,1114111])) for _ in range(rng.randrange(15)))
    if kind==5:return rng.choice([b'',b'x',float('inf'),float('nan')])
    if kind==6:return rng.choice([0,-1,True,1.0,-0.0])
    if kind==7:return object()
    if kind==8:return [value(depth-1) for _ in range(rng.randrange(6))]
    if kind==9:return tuple(value(depth-1) for _ in range(rng.randrange(6)))
    if kind==10:return {str(i):value(depth-1) for i in range(rng.randrange(6))}
    keys=rng.sample([None,False,True,2,-3,1.25,9.5,'null','false','true','2','a'],rng.randrange(6))
    return {key:value(depth-1) for key in keys}

try:
    for index in range(500):
        item=value(4)
        check(item,rng.choice([1,4,16,64,512,1048576]),case=f'random-{index}',
              ascii=bool(rng.randrange(2)),sort=bool(rng.randrange(2)))
    floats=[]
    for _ in range(2048):
        bits=rng.getrandbits(64)
        if ((bits>>52)&2047)==2047:bits^=1<<52
        floats.append(struct.unpack('<d',bits.to_bytes(8,'little'))[0])
    check(floats,case='2048-finite-binary64-values')
    numeric=[False,True,-0.0,0.5,-0.5,-1,2**53-1,2**53,2**53+1,
             float(2**53),math.nextafter(float(2**53),math.inf),-(2**53+1),
             float(-(2**53)),2**1024,-(2**1024),math.nextafter(0.0,1.0),
             -math.nextafter(0.0,1.0),1.7976931348623157e308,-1.7976931348623157e308]
    numeric+=floats[:128]
    rng.shuffle(numeric)
    check({key:index for index,key in enumerate(numeric)},case='exact-mixed-numeric-key-sort')
    check({1.0:'first',True:'replacement'},case='equal-numeric-keys-retain-first-type')
    check({False:'first',-0.0:'replacement'},case='equal-zero-keys-retain-first-type')
    for sort in (False,True):
        check({None:0,1:1,'2':2},case=f'mixed-key-sort-{sort}',sort=sort)
    for count in (127,128,129):
        obj=0
        for _ in range(count):obj=[obj]
        check(obj,case=f'depth-{count}')
    # A list root plus N scalar occurrences, including aliases to the same int.
    for count in (262142,262143,262144):
        check([0]*count,case=f'actual-node-and-queued-bound-{count}')
    shared=[0]*100
    check([shared]*2600,case='repeated-container-alias-counts-per-occurrence')
    cyc=[];cyc.append(cyc)
    check([object(),cyc],case='cycle-before-earlier-sibling-unsupported')
    check([cyc,object()],case='later-sibling-unsupported-before-cycle')
    check({('bad',):object(),'last':'\ud800'},case='all-dict-keys-before-any-values')
    check({'first':object(),'last':'\ud800'},case='dict-values-reverse-DFS')
    check({'first':'\ud800','last':object()},case='dict-values-reverse-DFS-opposite')
    for maximum in (1048576,8388608):
        for delta in (-1,0,1):
            check('x'*(maximum-2+delta),maximum,case=f'actual-string-byte-bound-{maximum}-{delta}')
    for ascii in (False,True):
        maximum=1048576
        width=12 if ascii else 4
        count=(maximum-2)//width
        for delta in (0,1):
            check('😀'*(count+delta),maximum,case=f'actual-unicode-byte-bound-{ascii}-{delta}',ascii=ascii)
    check([1]*5,10,case='cumulative-wire-byte-limit-after-structure')
    for digits in (4299,4300,4301):
        integer=10**(digits-1)
        check(integer,case=f'current-profile-integer-digits-{digits}')
        check({integer:object()},case=f'integer-key-before-invalid-value-{digits}')
    # A recorded foreign compatibility profile, not a new language quota.
    for profile,digits in ((640,640),(640,641),(0,5001)):
        sys.set_int_max_str_digits(profile)
        integer=10**(digits-1)
        check(integer,case=f'actual-foreign-int-profile-{profile}-{digits}')
    sys.set_int_max_str_digits(original_digits)
    # Every control has complete old/native outcome equality; no output truncation.
    summary={'status':'PASS','scope':'PRIVATE_GRAPH_WIRE_BOUNDARIES_DEVELOPMENT',
             'cases':cases,'native_entries':native.entries.copy(),
             'wall_elapsed_ns':time.monotonic_ns()-start,
             'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
             'public_capture_resource_boundary_closed':False,'full_renderer_implemented':False}
except BaseException as exc:
    summary={'status':'FAIL','error_type':type(exc).__name__,'error':str(exc),
             'cases_completed':len(cases),'native_entries':native.entries.copy()}
    raise
finally:
    sys.set_int_max_str_digits(original_digits)
    native.close()
    (native.out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({key:value for key,value in summary.items() if key!='cases'},sort_keys=True),flush=True)

