"""Fresh small complete-output comparison; no public renderer/cold claim."""
from pathlib import Path
import json,time,sys
from graph_harness import Actual,ROOT
out=ROOT/'development/smoke-r2-attempt1'
native=Actual(out)
cases=[]
started=time.monotonic_ns();summary=None
try:
    values=[None,False,True,0,1,-1,256,-256,2**63,2**128,-2**128,
            0.0,-0.0,1.0,1.25,1e100,1e-100,5e-324,1.7976931348623157e308,
            '', 'abc', '\x00\t\n\r\x7f', 'é中😀',
            [],{},(),[1,2,3],{'z':1,'a':2},(1,2),{1:'a',-4:'b',2.5:'c'},
            {None:1},{True:1},{False:1},
            {1:'a','1':'b'},{True:1,'true':2},{None:1,'null':2},
            {1:1,'b':2},float('nan'),float('inf'),{float('inf'):1},
            b'x',object(),'\ud800',{'value':1.25,'metadata':{'nested':[-0.0,1e-7]}}]
    for i,value in enumerate(values):
        for ascii_mode in (True,False):
            cases.append(native.check(value,ensure_ascii=ascii_mode,case=f'case-{i}-{ascii_mode}'))
    alias=[1,'a'];cases.append(native.check([alias,alias],case='alias'))
    cyclic=[];cyclic.append(cyclic);cases.append(native.check(cyclic,case='cycle'))
    for maximum in (0,1,2,3,4,5,6,10,16,32):
        for i,value in enumerate([None,0,'x','😀',[1,2],{'a':[1,2]}]):
            cases.append(native.check(value,maximum,case=f'limit-{maximum}-{i}'))
    summary={'status':'PASS','scope':'PRIVATE_GRAPH_WIRE_COMPLETE_OUTPUT_DIFFERENTIAL_DEVELOPMENT',
             'cases':cases,'native_entries':native.entries.copy(),
             'wall_elapsed_ns':time.monotonic_ns()-started,
             'public_capture_closed':False,'full_renderer_implemented':False}
except BaseException as exc:
    summary={'status':'FAIL','error_type':type(exc).__name__,'error':str(exc),
             'cases_completed':len(cases),'native_entries':native.entries.copy()}
    raise
finally:
    native.close()
    (out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)

