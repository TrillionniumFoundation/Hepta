"""Independent full-workspace bad-initializer recovery probe for frozen r2."""
from pathlib import Path
import ctypes,json,struct
from graph_harness import Actual,ROOT,capture,COMMAND
native=Actual(ROOT/'development/poison-r2-counterexample')
source=capture(None);words=(COMMAND,19,1,1,1048576,3,4300,0)
good=struct.pack('<8Q',*words)
bad=struct.pack('<8Q',*((*words[:7],1)))
work=ctypes.create_string_buffer(32768+32);ctypes.memset(ctypes.addressof(work)+32768,0xb9,32)
summary=None
try:
    first=native.call('scan',source,bad,work,32768,'invalid-first-command')
    second=native.call('scan',source,good,work,32768,'same-workspace-corrected-command')
    summary={'status':'REPRODUCED_PROTOCOL_BUG','first_return':first[0],'second_return':second[0],
             'first_event':first[1],'second_event':second[1],
             'initial_failure_followed_by_successful_phase_handoff':first[0]==0xfffffffd and second[0]==128 and second[1][1]==2}
    assert summary['initial_failure_followed_by_successful_phase_handoff'],summary
finally:
    native.close()
    (native.out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary),flush=True)

