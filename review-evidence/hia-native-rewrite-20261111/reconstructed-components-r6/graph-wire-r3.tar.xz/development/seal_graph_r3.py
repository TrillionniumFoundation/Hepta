"""Archive every retained Graph wire development original and read every member back."""
from pathlib import Path
from hashlib import sha256
import json, stat, tarfile, io
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-agent-edit-render-next')
OUT=ROOT.parent/'hia-graph-json-wire-r3-development.tar.xz'
CUSTODY=OUT.with_name(OUT.name+'.custody.json')
assert not OUT.exists() and not CUSTODY.exists()
paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
assert not any(p.is_symlink() for p in paths)
rows=[]
for p in paths:
    raw=p.read_bytes()
    rows.append({'path':str(p.relative_to(ROOT)),'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)})
with tarfile.open(OUT,'w:xz',preset=3) as archive:
    for row in rows:
        p=ROOT/row['path'];raw=p.read_bytes()
        assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
        member=tarfile.TarInfo(row['path']);member.size=len(raw);member.mode=row['mode'];member.mtime=0
        archive.addfile(member,io.BytesIO(raw))
expected={row['path']:row for row in rows}
seen=set()
with tarfile.open(OUT,'r:xz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in seen and member.name in expected
        row=expected[member.name];raw=archive.extractfile(member).read()
        assert member.mode==row['mode'] and member.size==row['bytes']
        assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
        live=(ROOT/member.name)
        assert live.read_bytes()==raw and stat.S_IMODE(live.stat().st_mode)==row['mode']
        seen.add(member.name)
assert seen==set(expected)
raw=OUT.read_bytes()
report={'schema':'hepta.hia.graph-json-wire-development-custody.v1','status':'PASS',
'archive_path':str(OUT),'archive_bytes':len(raw),'archive_sha256':sha256(raw).hexdigest(),
'member_count':len(rows),'uncompressed_file_bytes':sum(row['bytes'] for row in rows),
'archive_members_equal_original_bytes_sha256_and_mode':True,
'live_sources_equal_after_archive_readback':True,'excluded_only':['__pycache__','*.pyc'],
'scope':'GRAPH_WIRE_R3_DEVELOPMENT_RAW_WITH_ORIGINAL_FAILURES_NOT_COLD_QUALIFIED',
'public_capture_resource_boundary_closed':False,'members':rows}
CUSTODY.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='members'},indent=2),flush=True)
print(json.dumps({'custody_path':str(CUSTODY),'custody_bytes':CUSTODY.stat().st_size,'custody_sha256':sha256(CUSTODY.read_bytes()).hexdigest()}),flush=True)

