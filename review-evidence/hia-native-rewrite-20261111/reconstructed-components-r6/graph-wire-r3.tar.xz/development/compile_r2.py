"""Compile the two fixed GraphLease images using a retained actual HIA B3."""
from pathlib import Path
from hashlib import sha256
import json, shutil, sys, time

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-agent-edit-native')
sys.path.insert(0,str(BASE))
from tools.qualify_hia_selfhost import compile_stage

OUT=ROOT/'development/compile-r2'
SNAP=ROOT/'checkpoints/source-r2'
OUT.mkdir(parents=True,exist_ok=False)
SNAP.mkdir(parents=True,exist_ok=False)
files=['tools/generate_hia_graph_wire.py','tools/generate_hia_graph_wire_common.py',
       'tools/generate_hia_graph_wire_scan.py','tools/generate_hia_graph_wire_emit.py',
       'examples/hia_bootstrap/graph_json_wire_scan.hiaasm',
       'examples/hia_bootstrap/graph_json_wire_emit.hiaasm',
       'docs/HIA_GRAPH_JSON_WIRE_ABI.md']
pins={}
for rel in files:
    path=ROOT/rel;raw=path.read_bytes()
    dest=SNAP/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dest)
    assert dest.read_bytes()==path.read_bytes()==raw
    pins[path]=raw;pins[dest]=raw
compiler=ROOT/'dependencies/f50-B3.image.bin'
compiler.parent.mkdir(parents=True,exist_ok=True)
source_compiler=Path('/workspace/scratch/9acdfa9f5639/native-composite-helper-transport-recovery-next/dependencies/compiler/f50-B3.image.bin')
shutil.copy2(source_compiler,compiler)
assert sha256(compiler.read_bytes()).hexdigest()=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
pins[compiler]=compiler.read_bytes()
dependencies=['tools/generate_hia_agent_binary64_format.py','tools/generate_hia_agent_binary64.py',
              'tools/generate_hia_selfhost.py','tools/qualify_hia_selfhost.py',
              'tools/hia_selfhost_child.py']
for rel in dependencies:
    path=BASE/rel;raw=path.read_bytes()
    dest=ROOT/'dependencies/base'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dest)
    assert dest.read_bytes()==path.read_bytes()==raw
    pins[path]=raw;pins[dest]=raw
manifest={'scope':'UNEXECUTED_GRAPH_WIRE_R2_SOURCE_FREEZE','files':[
    {'path':rel,'bytes':len(pins[ROOT/rel]),'sha256':sha256(pins[ROOT/rel]).hexdigest()} for rel in files],
    'dependencies':{str(path):sha256(raw).hexdigest() for path,raw in pins.items() if path not in [ROOT/f for f in files] and path not in [SNAP/f for f in files]}}
(SNAP/'source.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
pins[SNAP/'source.json']=(SNAP/'source.json').read_bytes()
start=time.monotonic_ns();components={};summary=None
try:
    for name in ('scan','emit'):
        source=SNAP/('examples/hia_bootstrap/graph_json_wire_'+name+'.hiaasm')
        artifact,receipt=compile_stage(OUT,'graph-json-wire-'+name,compiler,pins[source])
        actual=artifact.read_bytes()
        assert receipt['source_sha256']==receipt['input_sha256']==sha256(pins[source]).hexdigest()
        assert receipt['artifact_sha256']==receipt['image_sha256']==sha256(pins[compiler]).hexdigest()
        assert receipt['produced_sha256']==sha256(actual).hexdigest()
        assert receipt['produced_bytes']==len(actual)==receipt['core_u32']
        for path,raw in pins.items():assert path.read_bytes()==raw
        row={'schema':'hepta.hia.graph-json-wire-'+name+'-native.v1',
             'source_path':str(source),'source_sha256':sha256(pins[source]).hexdigest(),
             'image_path':str(artifact),'image_sha256':sha256(actual).hexdigest(),
             'compiler_sha256':sha256(pins[compiler]).hexdigest()}
        (OUT/(name+'.manifest.json')).write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
        components[name]=row
    summary={'status':'PASS','scope':'SOURCE_BOUND_GRAPH_WIRE_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD',
             'components':components,'all_source_before_after_exact':True,
             'source_manifest_sha256':sha256(pins[SNAP/'source.json']).hexdigest(),
             'wall_elapsed_ns':time.monotonic_ns()-start,'public_capture_resource_boundary_closed':False,
             'full_renderer_implemented':False,'whole_stack_closed':False}
    (OUT/'bundle.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
except BaseException as exc:
    summary={'status':'FAIL','error_type':type(exc).__name__,'error':str(exc),'components':components}
    raise
finally:
    for path,raw in pins.items():assert path.read_bytes()==raw
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)

