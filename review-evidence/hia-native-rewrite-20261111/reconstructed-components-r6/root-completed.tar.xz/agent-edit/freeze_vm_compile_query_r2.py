"""Independent complete-query VM control before actual B3 query compilation."""
from hashlib import sha256
import json
from pathlib import Path
import struct
import time
import traceback
from hepta.hia_agent_assembly import assemble_program, render_assembly
from hepta.hia_program import verify_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_agent_slice_native import NativeAgentSlice
from hepta.hia_edit_query import prepare_edit
from tools.generate_hia_agent_edit_query_packet import document
from tools.qualify_hia_selfhost import compile_stage
from tests.test_hia_edit_query import fixture
from facts_harness import vm_call, MAGIC

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
DEST = DEV / 'query-source-and-compile-r2'
DEST.mkdir(exist_ok=False)
COMPILER = DEV / 'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths = [ROOT / 'tools/generate_hia_agent_edit_query_packet.py', ROOT / 'tools/hia_agent_edit_source_views.py',
         ROOT / 'examples/hia_bootstrap/agent_edit_query_packet.hiaasm', COMPILER]
frozen = {p: p.read_bytes() for p in paths}
assert sha256(frozen[COMPILER]).hexdigest() == '35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
rows = []
for p, raw in frozen.items():
    rel = p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin')
    target = DEST / 'source' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append({'path': str(p), 'copy': str(target), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()})
(DEST / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
summary = {'status': 'INCOMPLETE', 'scope': 'DEVELOPMENT_QUERY_PACKET_ONLY_NOT_PUBLIC_PREPARE_OR_COLD'}
started = time.monotonic_ns()
try:
    source = frozen[paths[2]]
    generated = document()
    assert render_assembly(generated).encode() == source
    profile = {'functions': len(generated['functions']), 'blocks': sum(len(fn['blocks']) for fn in generated['functions']),
               'max_blocks': max(len(fn['blocks']) for fn in generated['functions']),
               'ops': sum(len(b['ops']) for fn in generated['functions'] for b in fn['blocks']),
               'max_block_params': max(len(b['params']) for fn in generated['functions'] for b in fn['blocks'])}
    assert profile['functions'] <= 128 and profile['blocks'] <= 1536 and profile['max_blocks'] <= 256
    assert profile['ops'] <= 8192 and profile['max_block_params'] <= 16
    checked = assemble_program(source)
    previous = DEV / 'facts-native-r3'
    ledger = [json.loads(line) for line in (previous / 'facts/entries.jsonl').read_text().splitlines()]
    final = next(row for row in ledger if row['case'] == 'fixture' and row['event'][1] == 0)
    source_lease = (previous / 'facts' / ('source-' + final['source_sha256'] + '.lease')).read_bytes()
    work = (previous / 'facts' / (final['prefix'] + '.after.bin')).read_bytes()
    event = final['event']
    fact = work[event[6]:event[6] + event[7]]
    image = (previous / 'agent-slice.image.bin').read_bytes()
    slicer = NativeAgentSlice(image, sha256(image).hexdigest())
    sliced = slicer.run(fact)
    original = verify_program(fixture())
    expected = prepare_edit(original, function='calculate', block='entry', output='y', fields=['op'])
    expected_packet = transport(expected)
    def cmd(action, sequence):
        return (struct.pack('<16Q', MAGIC(b'HIAQQC01'), action, 1, 1, sequence, len(fact), len(sliced),
                            *event[8:11], event[11], event[12], event[13], 0, 0, 0)
                + bytes.fromhex(expected['base_sha256']) + bytes.fromhex(expected['input_sha256'])
                + bytes.fromhex(expected['operation_sha256']) + bytes(32) + fact + sliced)
    before, control, entries = bytes(1024), cmd(1, 0), 0
    while True:
        code, after = vm_call(checked, control, source_lease, before)
        output = struct.unpack_from('<16Q', after, 256)
        for suffix, raw in (('command', control), ('source', source_lease), ('before', before), ('after', after)):
            (DEST / f'vm-{entries}.{suffix}.bin').write_bytes(raw)
        entries += 1
        assert code == 384, (code, output)
        if output[1] == 0:
            packet = after[output[6]:output[6] + output[7]]
            (DEST / 'vm.actual.packet').write_bytes(packet)
            (DEST / 'vm.expected.packet').write_bytes(expected_packet)
            assert packet == expected_packet, (len(packet), len(expected_packet), output)
            break
        assert output[1] == 1 and output[5] > len(after)
        before = after + bytes(output[5] - len(after))
        control = cmd(2, output[4])
    vm_receipt = {'entries': entries, 'complete_typed_query_matches_retained_oracle': True,
                  'packet_bytes': len(packet), 'packet_sha256': sha256(packet).hexdigest(),
                  'complete_workspace_sha256': sha256(after).hexdigest(),
                  'digests_supplied_by_reference_for_this_VM_control': True,
                  'actual_prior_native_fact_and_slice_inputs': True}
    (DEST / 'independent-vm.json').write_text(json.dumps(vm_receipt, indent=2, sort_keys=True) + '\n')
    compiled, receipt = compile_stage(DEST, 'agent-edit-query-packet', COMPILER, source)
    manifest = {'schema': 'hepta.hia.agent-edit-query-packet-native.v1',
                'source_path': str(DEST / 'source/examples/hia_bootstrap/agent_edit_query_packet.hiaasm'),
                'source_sha256': sha256(source).hexdigest(), 'image_path': str(compiled),
                'image_sha256': sha256(compiled.read_bytes()).hexdigest(), 'compiler_sha256': sha256(frozen[COMPILER]).hexdigest()}
    (DEST / 'agent-edit-query-packet.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    summary.update(status='PASS', profile=profile, independent_vm=vm_receipt, receipt=receipt, manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    summary['source_before_after_equal'] = all(p.read_bytes() == raw for p, raw in frozen.items())
    summary['elapsed_ns'] = time.monotonic_ns() - started
    (DEST / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert summary['source_before_after_equal']
