"""Freeze source, independently execute VM, then invoke qualified actual B3."""
from hashlib import sha256
import json
from pathlib import Path
import struct
import time
import traceback
from hepta.hia_agent_assembly import assemble_program, render_assembly
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index
from tools.generate_hia_packet_graph import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import lease, vm_call
from packet_graph_harness import command, decode_graph_reference

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
OUT = DEV / 'packet-graph-source-and-compile-r2'
OUT.mkdir(exist_ok=False)
COMPILER = DEV / 'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths = [ROOT / 'tools/generate_hia_packet_graph.py', ROOT / 'tools/hia_agent_edit_source_views.py',
         ROOT / 'examples/hia_bootstrap/packet_graph.hiaasm', COMPILER]
frozen = {p: p.read_bytes() for p in paths}
rows = []
for p, raw in frozen.items():
    rel = p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin')
    target = OUT / 'source' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append(dict(path=str(p), copy=str(target), bytes=len(raw), sha256=sha256(raw).hexdigest()))
(OUT / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
summary = dict(status='INCOMPLETE', scope='DEVELOPMENT_INTEGER_TREE_BRIDGE_NOT_PUBLIC_CAPTURE')
started = time.monotonic_ns()
try:
    doc = document()
    source = frozen[paths[2]]
    assert render_assembly(doc).encode() == source
    profile = dict(functions=len(doc['functions']), blocks=sum(len(f['blocks']) for f in doc['functions']),
                   max_blocks=max(len(f['blocks']) for f in doc['functions']),
                   ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),
                   max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions'] <= 128 and profile['blocks'] <= 1536 and profile['max_blocks'] <= 256
    assert profile['ops'] <= 8192 and profile['max_block_params'] <= 16
    checked = assemble_program(source)
    entries = 0
    for case, value in enumerate((None, [True, False, 0, -1, (1 << 129) + 17],
                                 {'': [], '界': ['λ𝄞', {}, -(1 << 127)], 'z': 17})):
        raw = transport(value)
        _, index = detached_packet_index(raw)
        bitmap = bytearray((len(raw) + 7) // 8)
        for offset in index:
            bitmap[offset >> 3] |= 1 << (offset & 7)
        issued = lease(raw, bytes(bitmap))
        (OUT / f'vm-{case}.source.lease').write_bytes(issued)
        control, before = command(request=case + 1), bytes(512)
        while True:
            code, after = vm_call(checked, issued, control, before)
            for suffix, data in (('command', control), ('before', before), ('after', after)):
                (OUT / f'vm-{case}-{entries}.{suffix}.bin').write_bytes(data)
            entries += 1
            event = struct.unpack_from('<16Q', after, 256)
            assert code == 384, (case, code, event)
            if event[1] == 0:
                graph = after[event[6]:event[6] + event[7]]
                assert decode_graph_reference(graph) == value
                (OUT / f'vm-{case}.graph').write_bytes(graph)
                break
            assert event[1] == 1 and event[5] > len(after)
            before = after + bytes(event[5] - len(after))
            control = command(2, request=case + 1, sequence=event[4])
    compiled, receipt = compile_stage(OUT, 'packet-graph', COMPILER, source)
    manifest = dict(schema='hepta.hia.packet-graph-native.v1',
                    source_path=str(OUT / 'source/examples/hia_bootstrap/packet_graph.hiaasm'),
                    source_sha256=sha256(source).hexdigest(), image_path=str(compiled),
                    image_sha256=sha256(compiled.read_bytes()).hexdigest(),
                    compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT / 'packet-graph.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    summary.update(status='PASS', profile=profile, independent_VM_cases=3, independent_VM_entries=entries,
                   VM_capture_reference_supplied=True, receipt=receipt, manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    summary['source_before_after_equal'] = all(p.read_bytes() == raw for p, raw in frozen.items())
    summary['elapsed_ns'] = time.monotonic_ns() - started
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert summary['source_before_after_equal']
