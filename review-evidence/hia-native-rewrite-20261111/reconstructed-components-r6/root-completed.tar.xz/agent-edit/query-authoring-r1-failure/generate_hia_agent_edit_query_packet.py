"""Project a complete edit query from actual native facts and slice results.

This private component consumes issued immutable source/facts/slice leases and
three actual native digests. It constructs the entire query packet; public
canonical budgeting, general object capture and the fixed driver are separate
owners. No synthetic packet or matching header grants admission authority.
"""
from __future__ import annotations
import ast
from hashlib import sha256
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_core_json_frontend import packed
from tools.generate_hia_selfhost import compact_authoring_cfg, total_scalar_functions
from tools import hia_agent_edit_source_views as shared

SHARED_SHA = '555472263213f15deb239fcf3bf8e5b273a28caf3a67bb29ffd037f171d7ae5c'
CONSTANTS = {
    'COMMAND': int.from_bytes(b'HIAQQC01', 'little'),
    'STATE': int.from_bytes(b'HIAQQW01', 'little'),
    'EVENT': int.from_bytes(b'HIAQQE01', 'little'),
    'SOURCE_MAGIC': int.from_bytes(b'HIASIL01', 'little'),
    'FACT_MAGIC': int.from_bytes(b'HIASLC01', 'little'),
    'SLICE_MAGIC': int.from_bytes(b'HIASLR01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1, 'REF': 1 << 63,
    'MODE': 160, 'CURSOR': 168, 'BASE': 176, 'ERROR': 184,
}
LITERALS = (
    'schema', 'base_sha256', 'input_sha256', 'selector', 'fields', 'operation_sha256',
    'context', 'scope', 'function', 'block', 'output', 'name', 'params', 'returns',
    'effects', 'return_loans', 'functions', 'blocks', 'ops', 'op', 'args', 'attrs',
    'call', 'id', 'term', 'index', 'operation', 'block_params', 'dependencies',
    'operation_index', 'consumers', 'downstream', 'terminator', 'callees',
    'affected_params', 'control_reachable', 'hepta.hia.program.v8',
    'hepta.hia.edit-query.v2', 'hepta.hia.edit-query.v3',
)
SCOPE = ('explicit SSA slice with complete displayed terminator inputs and '
         'full reachable regions of value-affected branches; precise '
         'control-dependence, aliases and behavioral equivalence are NOT proved; '
         'whole module is reverified')
SOURCE = r'''
def query_packet(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) == 2:
        return refuse(w, 1)
    if length(s) < 384 or word(s, 0) != COMMAND or source_lease(r) == 0:
        return refuse(w, 2)
    if word(s, 16) == 0 or word(s, 24) == 0:
        return refuse(w, 3)
    if get(w, 8) == 0:
        if word(s, 8) != 1 or word(s, 32) != 0:
            return refuse(w, 4)
        i = 0
        while i < 1024:
            if byte(w, i) != 0:
                return refuse(w, 5)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(s, 16))
        put(w, 24, word(s, 24))
        put(w, 56, length(r))
        put(w, 64, length(s))
        copy_bytes(w, s, 512, 40, 216)
        copy_bytes(w, r, 728, 0, 64)
        if shape(s, r, w) == 0:
            return refuse(w, 6)
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or word(s, 8) != 2:
            return refuse(w, 7)
        if word(s, 16) != get(w, 16) or word(s, 24) != get(w, 24) or word(s, 32) != get(w, 32):
            return refuse(w, 8)
        if length(s) != get(w, 64) or length(r) != get(w, 56):
            return refuse(w, 9)
        i = 0
        while i < 216:
            if byte(s, 40 + i) != byte(w, 512 + i):
                return refuse(w, 10)
            i = i + 1
        i = 0
        while i < 64:
            if byte(r, i) != byte(w, 728 + i):
                return refuse(w, 11)
            i = i + 1
    if length(w) < get(w, BASE):
        put(w, 48, get(w, BASE))
        return event(w, 1)
    if get(w, 40) == 0:
        if plan(s, r, w) == 0:
            return refuse(w, 12)
        put(w, 40, 1)
    put(w, MODE, 0)
    put(w, CURSOR, 0)
    project(s, r, w)
    if get(w, ERROR) != 0 or get(w, CURSOR) > MAX - get(w, BASE):
        return refuse(w, 13)
    put(w, 224, get(w, CURSOR))
    put(w, 48, get(w, BASE) + get(w, 224))
    if length(w) < get(w, 48):
        return event(w, 1)
    put(w, MODE, 1)
    put(w, CURSOR, 0)
    project(s, r, w)
    if get(w, ERROR) != 0 or get(w, CURSOR) != get(w, 224):
        return refuse(w, 14)
    put(w, 8, 2)
    return event(w, 0)

def source_lease(r:readbuf) -> u64:
    if length(r) < 82 or word(r, 0) != SOURCE_MAGIC:
        return 0
    size = word(r, 8)
    if size < 16 or size > 67108864 or word(r, 24) != 64:
        return 0
    at = (64 + size + 7) & 18446744073709551608
    count_ = (size + 7) >> 3
    if word(r, 16) != count_ or word(r, 32) != at or word(r, 40) != length(r):
        return 0
    if at > length(r) or count_ != length(r) - at or word(r, 48) != 0 or word(r, 56) != 0:
        return 0
    if word(r, 72) != size - 16 or (byte(r, at) & 1) == 0:
        return 0
    i = 64 + size
    while i < at:
        if byte(r, i) != 0:
            return 0
        i = i + 1
    if (size & 7) != 0 and (byte(r, length(r) - 1) >> (size & 7)) != 0:
        return 0
    return 1

def valid_ref(r:readbuf, view:u64) -> u64:
    if view < REF:
        return 0
    at = view - REF
    if at > word(r, 8) - 16:
        return 0
    return (byte(r, word(r, 32) + (at >> 3)) >> (at & 7)) & 1

def event(w:mutbuf, action:u64) -> u32:
    if get(w, 32) == MAX:
        put(w, 8, 3)
        return BAD
    put(w, 32, get(w, 32) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 48))
    put(w, 304, get(w, BASE))
    put(w, 312, get(w, 224))
    put(w, 320, get(w, ERROR))
    i = 328
    while i < 384:
        put(w, i, 0)
        i = i + 8
    return 384

def refuse(w:mutbuf, error:u64) -> u32:
    put(w, 8, 3)
    put(w, ERROR, error)
    event(w, 3)
    return BAD

def fail(w:mutbuf, error:u64) -> u64:
    if get(w, ERROR) == 0:
        put(w, ERROR, error)
    return 0

def shape(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    fact = word(s, 40)
    sliced = word(s, 48)
    if fact < 64 or fact > length(s) - 320 or sliced != length(s) - 256 - fact:
        return 0
    if word(s, 256) != FACT_MAGIC or word(s, 104) != 0 or word(s, 112) != 0 or word(s, 120) != 0:
        return 0
    i = 224
    while i < 256:
        if word(s, i) != 0:
            return 0
        i = i + 8
    b = word(s, 264)
    o = word(s, 272)
    v = word(s, 280)
    e = word(s, 288)
    l = word(s, 296)
    if b == 0 or b > fact // 64 or o > fact // 40 or v > fact // 16 or e > fact // 32 or l > fact // 8:
        return 0
    if fact != 64 + b * 64 + o * 40 + v * 16 + e * 32 + l * 8:
        return 0
    if sliced != 64 + 8 * (b + o + v) or word(s, 304) >= b or word(s, 312) >= o:
        return 0
    at = 256 + fact
    if word(s, at) != SLICE_MAGIC or word(s, at + 8) != b or word(s, at + 16) != o or word(s, at + 24) != v:
        return 0
    if word(s, at + 32) != word(s, 304) or word(s, at + 40) != word(s, 312) or word(s, at + 56) != 0:
        return 0
    if word(s, at + 48) == 0 or word(s, at + 48) > 256 or word(s, 96) == 0 or word(s, 96) > 7:
        return 0
    if word(s, 80) != word(s, 304):
        return 0
    put(w, 72, fact)
    put(w, 80, b)
    put(w, 88, o)
    put(w, 96, v)
    put(w, 104, e)
    put(w, 112, l)
    put(w, 120, word(s, 304))
    put(w, 128, word(s, 312))
    put(w, 136, word(s, 56))
    put(w, 144, word(s, 64))
    put(w, 152, word(s, 72))
    put(w, 232, 9216)
    put(w, BASE, 9216 + v * 8)
    if list_shape(s, r, REF, 2) == 0:
        return 0
    if valid_ref(r, get(w, 136)) == 0 or valid_ref(r, get(w, 144)) == 0 or valid_ref(r, get(w, 152)) == 0:
        return 0
    if kind(s, r, get(w, 136)) != 6 or kind(s, r, get(w, 144)) != 6 or kind(s, r, get(w, 152)) != 6:
        return 0
    blocks = field(s, r, get(w, 136), L_blocks)
    if kind(s, r, blocks) != 5 or count(s, r, blocks) != b or child(s, r, blocks, word(s, 80)) != get(w, 144):
        return 0
    ops = field(s, r, get(w, 144), L_ops)
    if kind(s, r, ops) != 5 or word(s, 88) >= count(s, r, ops) or child(s, r, ops, word(s, 88)) != get(w, 152):
        return 0
    at = 320 + word(s, 80) * 64
    if word(s, at + 16) + word(s, 88) != get(w, 128):
        return 0
    functions = field(s, r, child(s, r, REF, 0), L_functions)
    if kind(s, r, functions) != 5:
        return 0
    put(w, 192, functions)
    return 1

def block_flag(s:readbuf, w:mutbuf, bi:u64) -> u64:
    return word(s, 256 + get(w, 72) + 64 + bi * 8)

def value_flag(s:readbuf, w:mutbuf, value:u64) -> u64:
    return word(s, 256 + get(w, 72) + 64 + get(w, 80) * 8 + value * 8)

def op_flag(s:readbuf, w:mutbuf, operation:u64) -> u64:
    return word(s, 256 + get(w, 72) + 64 + (get(w, 80) + get(w, 96)) * 8 + operation * 8)

def name_hash(s:readbuf, r:readbuf, name:u64) -> u64:
    value = 14695981039346656037
    i = 0
    while i < text_size(s, r, name):
        value = (value ^ text_byte(s, r, name, i)) * 1099511628211
        i = i + 1
    return value

def call_slot(s:readbuf, r:readbuf, w:mutbuf, name:u64) -> u64:
    if kind(s, r, name) != 4:
        return 0
    h = name_hash(s, r, name)
    slot = h & 511
    i = 0
    while i < 512:
        at = 1024 + slot * 16
        previous = get(w, at)
        if previous == 0:
            return at
        if get(w, at + 8) == h and text_equal(s, r, previous, name) != 0:
            return at
        slot = (slot + 1) & 511
        i = i + 1
    return 0

def mark_call(s:readbuf, r:readbuf, w:mutbuf, name:u64) -> u64:
    at = call_slot(s, r, w, name)
    if at == 0:
        return 0
    if get(w, at) == 0:
        put(w, at, name)
        put(w, at + 8, name_hash(s, r, name))
        put(w, 200, get(w, 200) + 1)
    return 1

def is_call(s:readbuf, r:readbuf, w:mutbuf, name:u64) -> u64:
    at = call_slot(s, r, w, name)
    if at == 0 or get(w, at) == 0:
        return 0
    return 1

def plan(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    fill_range(w, 1024, 8192, 0)
    i = 0
    visible_blocks = 1
    while i < get(w, 80):
        flag = block_flag(s, w, i)
        if flag != 0 and flag != 1 and flag != 3 and flag != 5 and flag != 7:
            return 0
        if i == get(w, 120) and flag != 0:
            return 0
        if flag != 0:
            visible_blocks = visible_blocks + 1
        i = i + 1
    if visible_blocks > 64:
        return 0
    put(w, 216, visible_blocks - 1)
    i = 0
    while i < get(w, 96):
        if value_flag(s, w, i) > 3:
            return 0
        i = i + 1
    shown = 0
    selected = 0
    i = 0
    while i < get(w, 88):
        flag = op_flag(s, w, i)
        if flag > 3:
            return 0
        if flag != 0:
            shown = shown + 1
        if flag == 3:
            selected = selected + 1
            if i != get(w, 128):
                return 0
        i = i + 1
    if selected != 1 or shown != word(s, 256 + get(w, 72) + 48):
        return 0
    blocks = field(s, r, get(w, 136), L_blocks)
    block = child(s, r, blocks, 0)
    bi = 0
    next_op = 0
    next_value = 0
    while bi < get(w, 80):
        at = 320 + bi * 64
        ops = field(s, r, block, L_ops)
        params = field(s, r, block, L_params)
        if word(s, at) != next_value or word(s, at + 8) != count(s, r, params):
            return 0
        if word(s, at + 16) != next_op or word(s, at + 24) != count(s, r, ops):
            return 0
        next_value = next_value + count(s, r, params)
        op = child(s, r, ops, 0)
        oi = 0
        while oi < count(s, r, ops):
            if next_op >= get(w, 88):
                return 0
            if op_flag(s, w, next_op) != 0 and text_is(s, r, field(s, r, op, L_op), L_call) != 0:
                attrs = field(s, r, op, L_attrs)
                if mark_call(s, r, w, field(s, r, attrs, L_function)) == 0:
                    return 0
            next_value = next_value + count(s, r, field(s, r, op, L_out))
            next_op = next_op + 1
            oi = oi + 1
            op = following(s, r, op)
        bi = bi + 1
        block = following(s, r, block)
    if next_op != get(w, 88) or next_value != get(w, 96):
        return 0
    functions = get(w, 192)
    fn = child(s, r, functions, 0)
    i = 0
    while i < count(s, r, functions):
        if is_call(s, r, w, field(s, r, fn, L_name)) != 0:
            put(w, 208, get(w, 208) + 1)
        fn = following(s, r, fn)
        i = i + 1
    if get(w, 208) != get(w, 200):
        return 0
    return 1

def reserve(w:mutbuf, size:u64) -> u64:
    at = get(w, CURSOR)
    if size > MAX - at:
        fail(w, 20)
        return 0
    if get(w, MODE) == 1:
        base = get(w, BASE)
        if base > length(w) or at > length(w) - base or size > length(w) - base - at:
            fail(w, 21)
            return 0
    put(w, CURSOR, at + size)
    return at

def header(w:mutbuf, k:u64, size:u64) -> u64:
    at = reserve(w, 16)
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        put(w, get(w, BASE) + at, k)
        put(w, get(w, BASE) + at + 8, size)
    return at

def literal(w:mutbuf, size:u64, a:u64, b:u64, c:u64) -> u64:
    header(w, 4, size)
    at = reserve(w, size)
    if get(w, MODE) == 0 or get(w, ERROR) != 0:
        return 0
    i = 0
    while i < size:
        part = a
        if i >= 8:
            part = b
        if i >= 16:
            part = c
        store(w, get(w, BASE) + at + i, (part >> ((i & 7) * 8)) & 255)
        i = i + 1
    return 0

def container(w:mutbuf, k:u64, size:u64) -> u64:
    at = header(w, k, 0)
    payload = reserve(w, 8)
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        put(w, get(w, BASE) + payload, size)
    return at

def finish(w:mutbuf, at:u64) -> u64:
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        put(w, get(w, BASE) + at + 8, get(w, CURSOR) - at - 16)
    return 0

def source_value(r:readbuf, w:mutbuf, view:u64) -> u64:
    if valid_ref(r, view) == 0:
        return fail(w, 22)
    at = 64 + view - REF
    size = 16 + word(r, at + 8)
    out = reserve(w, size)
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        copy_bytes(w, r, get(w, BASE) + out, at, size)
    return 0

def integer(w:mutbuf, value:u64) -> u64:
    digits = 1
    divisor = 1
    while value // divisor >= 10:
        divisor = divisor * 10
        digits = digits + 1
    header(w, 2, digits)
    at = reserve(w, digits)
    if get(w, MODE) == 0 or get(w, ERROR) != 0:
        return 0
    i = 0
    while i < digits:
        digit = value // divisor
        value = value % divisor
        store(w, get(w, BASE) + at + i, 48 + digit)
        if divisor > 1:
            divisor = divisor // 10
        i = i + 1
    return 0

def boolean(w:mutbuf, value:u64) -> u64:
    header(w, 1, 1)
    at = reserve(w, 1)
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        store(w, get(w, BASE) + at, value)
    return 0

def digest_hex(s:readbuf, w:mutbuf, source:u64) -> u64:
    header(w, 4, 64)
    at = reserve(w, 64)
    if get(w, MODE) == 0 or get(w, ERROR) != 0:
        return 0
    i = 0
    while i < 64:
        digit = byte(s, source + (i >> 1))
        if (i & 1) == 0:
            digit = digit >> 4
        digit = digit & 15
        encoded = 48 + digit
        if digit >= 10:
            encoded = 87 + digit
        store(w, get(w, BASE) + at + i, encoded)
        i = i + 1
    return 0

def signature(s:readbuf, r:readbuf, w:mutbuf, fn:u64, loans:u64) -> u64:
    root = container(w, 6, 4 + loans)
    literal(w, L_name)
    source_value(r, w, field(s, r, fn, L_name))
    literal(w, L_params)
    source_value(r, w, field(s, r, fn, L_params))
    literal(w, L_returns)
    source_value(r, w, field(s, r, fn, L_returns))
    literal(w, L_effects)
    source_value(r, w, field(s, r, fn, L_effects))
    if loans != 0:
        literal(w, L_return_loans)
        origins = field(s, r, fn, L_return_loans)
        if origins != 0:
            source_value(r, w, origins)
        else:
            amount = count(s, r, field(s, r, fn, L_returns))
            values = container(w, 5, amount)
            i = 0
            while i < amount:
                header(w, 0, 0)
                i = i + 1
            finish(w, values)
    return finish(w, root)

def entries(s:readbuf, r:readbuf, w:mutbuf, block:u64, bi:u64, wanted:u64) -> u64:
    ops = field(s, r, block, L_ops)
    start = word(s, 320 + bi * 64 + 16)
    n = count(s, r, ops)
    amount = 0
    i = 0
    while i < n:
        if op_flag(s, w, start + i) == wanted:
            amount = amount + 1
        i = i + 1
    root = container(w, 5, amount)
    op = child(s, r, ops, 0)
    i = 0
    while i < n:
        if op_flag(s, w, start + i) == wanted:
            item = container(w, 6, 2)
            literal(w, L_index)
            integer(w, i)
            literal(w, L_operation)
            source_value(r, w, op)
            finish(w, item)
        op = following(s, r, op)
        i = i + 1
    return finish(w, root)

def text_less(s:readbuf, r:readbuf, left:u64, right:u64) -> u64:
    a = text_size(s, r, left)
    b = text_size(s, r, right)
    i = 0
    while i < a and i < b:
        x = text_byte(s, r, left, i)
        y = text_byte(s, r, right, i)
        if x != y:
            return choose(x < y, 1, 0)
        i = i + 1
    return choose(a < b, 1, 0)

def sift(s:readbuf, r:readbuf, w:mutbuf, root:u64, end:u64) -> u64:
    base = get(w, 232)
    while root * 2 + 1 < end:
        child_ = root * 2 + 1
        if child_ + 1 < end and text_less(s, r, get(w, base + child_ * 8), get(w, base + (child_ + 1) * 8)) != 0:
            child_ = child_ + 1
        current = get(w, base + root * 8)
        other = get(w, base + child_ * 8)
        if text_less(s, r, current, other) == 0:
            return 0
        put(w, base + root * 8, other)
        put(w, base + child_ * 8, current)
        root = child_
    return 0

def sort_names(s:readbuf, r:readbuf, w:mutbuf, count_:u64) -> u64:
    start = count_ >> 1
    while start > 0:
        start = start - 1
        sift(s, r, w, start, count_)
    end = count_
    base = get(w, 232)
    while end > 1:
        end = end - 1
        last = get(w, base + end * 8)
        put(w, base + end * 8, get(w, base))
        put(w, base, last)
        sift(s, r, w, 0, end)
    return 0

def affected(s:readbuf, r:readbuf, w:mutbuf, block:u64, bi:u64) -> u64:
    params = field(s, r, block, L_params)
    start = word(s, 320 + bi * 64)
    parameter = child(s, r, params, 0)
    i = 0
    n = 0
    while i < count(s, r, params):
        if (value_flag(s, w, start + i) & 2) != 0:
            if n >= get(w, 96):
                return fail(w, 23)
            put(w, get(w, 232) + n * 8, field(s, r, parameter, L_name))
            n = n + 1
        parameter = following(s, r, parameter)
        i = i + 1
    sort_names(s, r, w, n)
    root = container(w, 5, n)
    i = 0
    while i < n:
        source_value(r, w, get(w, get(w, 232) + i * 8))
        i = i + 1
    return finish(w, root)

def downstream(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    root = container(w, 5, get(w, 216))
    block = child(s, r, field(s, r, get(w, 136), L_blocks), 0)
    bi = 0
    while bi < get(w, 80):
        flag = block_flag(s, w, bi)
        if flag != 0:
            downstream_block(s, r, w, block, bi, flag)
        block = following(s, r, block)
        bi = bi + 1
    return finish(w, root)

def downstream_block(s:readbuf, r:readbuf, w:mutbuf, block:u64, bi:u64, flag:u64) -> u64:
    root = container(w, 6, 8)
    literal(w, L_id)
    source_value(r, w, field(s, r, block, L_id))
    literal(w, L_params)
    source_value(r, w, field(s, r, block, L_params))
    literal(w, L_affected_params)
    affected(s, r, w, block, bi)
    literal(w, L_control_reachable)
    boolean(w, (flag >> 1) & 1)
    literal(w, L_dependencies)
    entries(s, r, w, block, bi, 2)
    literal(w, L_consumers)
    entries(s, r, w, block, bi, 1)
    literal(w, L_terminator)
    source_value(r, w, field(s, r, block, L_term))
    label_branch(w)
    boolean(w, (flag >> 2) & 1)
    return finish(w, root)

def callees(s:readbuf, r:readbuf, w:mutbuf, loans:u64) -> u64:
    root = container(w, 5, get(w, 208))
    functions = get(w, 192)
    fn = child(s, r, functions, 0)
    i = 0
    while i < count(s, r, functions):
        if is_call(s, r, w, field(s, r, fn, L_name)) != 0:
            signature(s, r, w, fn, loans)
        fn = following(s, r, fn)
        i = i + 1
    return finish(w, root)

def fields(s:readbuf, w:mutbuf) -> u64:
    mask = word(s, 96)
    count_ = (mask & 1) + ((mask >> 1) & 1) + ((mask >> 2) & 1)
    root = container(w, 5, count_)
    if (mask & 1) != 0:
        literal(w, L_args)
    if (mask & 2) != 0:
        literal(w, L_attrs)
    if (mask & 4) != 0:
        literal(w, L_op)
    return finish(w, root)

def context(s:readbuf, r:readbuf, w:mutbuf, loans:u64) -> u64:
    root = container(w, 6, 9)
    literal(w, L_function)
    signature(s, r, w, get(w, 136), loans)
    literal(w, L_block_params)
    source_value(r, w, field(s, r, get(w, 144), L_params))
    literal(w, L_dependencies)
    entries(s, r, w, get(w, 144), get(w, 120), 2)
    literal(w, L_operation_index)
    integer(w, word(s, 88))
    literal(w, L_operation)
    source_value(r, w, get(w, 152))
    literal(w, L_consumers)
    entries(s, r, w, get(w, 144), get(w, 120), 1)
    literal(w, L_downstream)
    downstream(s, r, w)
    literal(w, L_terminator)
    source_value(r, w, field(s, r, get(w, 144), L_term))
    literal(w, L_callees)
    callees(s, r, w, loans)
    return finish(w, root)

def project(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    schema = field(s, r, child(s, r, REF, 0), L_schema)
    loans = text_is(s, r, schema, L_hepta_hia_program_v8)
    root = container(w, 6, 8)
    literal(w, L_schema)
    if loans != 0:
        literal(w, L_hepta_hia_edit_query_v3)
    else:
        literal(w, L_hepta_hia_edit_query_v2)
    literal(w, L_base_sha256)
    digest_hex(s, w, 128)
    literal(w, L_input_sha256)
    digest_hex(s, w, 160)
    literal(w, L_selector)
    selector = container(w, 6, 3)
    selection = child(s, r, REF, 1)
    literal(w, L_function)
    source_value(r, w, field(s, r, selection, L_function))
    literal(w, L_block)
    source_value(r, w, field(s, r, selection, L_block))
    literal(w, L_output)
    source_value(r, w, field(s, r, selection, L_output))
    finish(w, selector)
    literal(w, L_fields)
    fields(s, w)
    literal(w, L_operation_sha256)
    digest_hex(s, w, 192)
    literal(w, L_context)
    context(s, r, w, loans)
    literal(w, L_scope)
    scope_text(w)
    return finish(w, root)
'''

COMMON = ('word', 'get', 'put', 'resolved', 'kind', 'count', 'child', 'following',
          'list_shape', 'text_size', 'text_byte', 'text_equal', 'text_is', 'field')


def long_literal(name, text):
    raw = text.encode('ascii')
    lines = [f'def {name}(w:mutbuf) -> u64:', f'    header(w, 4, {len(raw)})',
             f'    at = reserve(w, {len(raw)})',
             '    if get(w, MODE) == 0 or get(w, ERROR) != 0:', '        return 0',
             '    base = get(w, BASE) + at']
    at = 0
    while at + 8 <= len(raw):
        lines.append(f'    put(w, base + {at}, {int.from_bytes(raw[at:at+8], "little")})')
        at += 8
    for i in range(at, len(raw)):
        lines.append(f'    store(w, base + {i}, {raw[i]})')
    lines.append('    return 0')
    return '\n'.join(lines)


def source_program():
    if sha256(Path(shared.__file__).read_bytes()).hexdigest() != SHARED_SHA:
        raise ValueError('immutable source-view authoring changed')
    literals = {'L_' + name.replace('.', '_').replace('-', '_'): packed(name) for name in (*LITERALS, 'out')}
    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node) if node.id in CONSTANTS else node
        def visit_Call(self, node):
            node = self.generic_visit(node)
            args = []
            for arg in node.args:
                if isinstance(arg, ast.Name) and arg.id in literals:
                    args.extend(ast.Constant(value) for value in literals[arg.id])
                else:
                    args.append(arg)
            node.args = args
            return node
    source = SOURCE + '\n' + long_literal('label_branch', 'branch_condition_affected') + '\n' + long_literal('scope_text', SCOPE)
    own = Expand().visit(ast.parse(source)).body
    common = {node.name: node for node in ast.parse(shared.source_program()).body}
    tree = ast.Module(body=own + [common[name] for name in COMMON], type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i + 1) for i, node in enumerate(nodes)}
    signatures = {node.name: ([a.annotation.id for a in node.args.args], node.returns.id) for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'}, {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'],
        'entry': 'b0', 'blocks': [{'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}], 'attrs': {'function': names['query_packet']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}], 'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = shared.CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'agent_edit_query_packet', 'functions': functions})


if __name__ == '__main__':
    doc = document()
    path = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap/agent_edit_query_packet.hiaasm'
    path.write_text(render_assembly(doc))
    print(path.name, path.stat().st_size, len(doc['functions']), sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']), sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
