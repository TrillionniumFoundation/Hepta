"""Actual issuer -> HIA GraphLease bridge -> HIA bounded wire -> HIA SHA."""
from contextlib import ExitStack
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index, ObjectTokenDecoder
from hepta.hia_program_tools import bounded_json_wire
from hepta.hia_sha256_native import NativeSha256
from facts_harness import lease, vm_call
from packet_graph_harness import Actual, command, decode_graph_reference, BAD

DEV = Path(__file__).resolve().parent
OUT = DEV / 'packet-graph-wire-r1'
OUT.mkdir(exist_ok=False)
COMPILE = DEV / 'packet-graph-source-and-compile-r1'
bridge = Actual(COMPILE / 'packet-graph.manifest.json', OUT / 'bridge')
checked = assemble_program((COMPILE / 'source/examples/hia_bootstrap/packet_graph.hiaasm').read_bytes())
pins = {Path(__file__): Path(__file__).read_bytes()}
def load(name, path):
    pins[path] = path.read_bytes()
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
issuer_module = load('packet_graph_actual_issuer_r1', DEV.parent / 'native-composite-core-final-recovery-next/dependencies/packet-issuer/tests/test_hia_composite_packet_json.py')
wire_module = load('packet_graph_actual_wire_r3', DEV.parent / 'native-agent-edit-render-next/development/graph_harness_r3.py')
issuer = issuer_module.ActualPacketJson(OUT / 'issuer')
wire = wire_module.Actual(OUT / 'wire')
hash_image = (DEV / 'query-native-r2/sha256.image.bin').read_bytes()
hasher = NativeSha256(hash_image, sha256(hash_image).hexdigest())
cases, controls = [], []
started = time.monotonic_ns()

def forbidden(*args, **kwargs):
    raise AssertionError('host serializer/capture/decoder entered native bridge pipeline')

def run(label, raw, expected_value, maximum, flags=3, pair_vm=False):
    try:
        expected = {'wire': bounded_json_wire(expected_value, maximum, ensure_ascii=bool(flags & 1), sort_keys=bool(flags & 2))}
    except Exception as exc:
        expected = {'error': str(exc), 'class': type(exc).__name__}
    before_entries = bridge.entries
    with ExitStack() as guards:
        for owner, name in ((ObjectTokenDecoder, 'feed'), (json, 'loads'), (json, 'dumps'),
                            (wire_module, 'capture')):
            # Harness JSON logs use dumps; keep only semantic decoders forbidden.
            if owner is json and name == 'dumps':
                continue
            guards.enter_context(patch.object(owner, name, new=forbidden))
        result, header, encoded, bitmap, issuer_state = issuer.encode(label, raw)
        assert result == 64 + len(encoded) and header[5] == len(raw), (label, result, header)
        source = lease(raw, bitmap)
        graph, completed = bridge.run(label, source, request=len(cases) + 1)
        actual = wire.serialize_graph(graph, maximum, flags=flags, case=label)
        if 'wire' in expected:
            assert actual.get('wire') == expected['wire'], (label, expected, actual)
            digest = hasher.digest(actual['wire'])
            assert digest == sha256(expected['wire']).digest()
        else:
            assert actual.get('error') == expected['error'], (label, expected, actual)
            digest = None
    assert decode_graph_reference(graph) == expected_value
    if pair_vm:
        vm_graph, _ = bridge.run(label + '-VM-paired', source, request=len(cases) + 1000,
                                compare=lambda s, c, w: vm_call(checked, s, c, w))
        assert vm_graph == graph
    (OUT / (str(len(cases)).zfill(4) + '.graph')).write_bytes(graph)
    if 'wire' in actual:
        (OUT / (str(len(cases)).zfill(4) + '.wire')).write_bytes(actual['wire'])
    cases.append(dict(case=label, maximum=maximum, flags=flags, status='PASS',
                      bridge_entries=bridge.entries - before_entries, graph_bytes=len(graph),
                      wire_bytes=len(actual['wire']) if 'wire' in actual else None,
                      wire_sha256=digest.hex() if digest else None, expected_error=expected.get('error'),
                      complete_graph_semantics_equal=True, actual_issuer_and_bounded_wire_and_SHA=True,
                      independent_full_workspace_VM_pair=pair_vm))
    return source, completed

summary = dict(status='INCOMPLETE')
try:
    prior = json.loads((DEV / 'query-native-r2/summary.json').read_text())
    for index, row in enumerate(prior['cases']):
        if row['outcome'] != 'EXACT_COMPLETE_QUERY':
            continue
        raw = (DEV / 'query-native-r2' / f'query-{index}.packet').read_bytes()
        value, _ = detached_packet_index(raw)
        source, completed = run('query-' + row['case'], raw, value, 1 << 20,
                                pair_vm=row['case'] == 'fixture')
    values = [None, True, False, 0, -1, 255, 256, 257, -(1 << 64), (1 << 64) - 1,
              (1 << 129) + 17, -(1 << 257) - 1, 10 ** 999 + 27, '', 'a', '\"\\\n\t',
              '汉字λ𝄞', [], {}, [[], {}, 0, False, None], {'': '', '界': ['λ𝄞', {}, -(1 << 127)]}]
    for index, value in enumerate(values):
        source, completed = run('scalar-tree-' + str(index), transport(value), value, 1 << 20,
                                flags=3 if index & 1 else 0, pair_vm=index in (0, 10, 21))
    value = {'b': '汉\n字', 'a': [0, 1, -2, True, None]}
    raw = transport(value)
    exact_bytes = len(bounded_json_wire(value, 1 << 20))
    for maximum in (0, 1, exact_bytes - 1, exact_bytes, exact_bytes + 1):
        source, completed = run('wire-byte-bound-' + str(maximum), raw, value, maximum)
    nested = 0
    for depth in range(1, 130):
        nested = [nested]
        if depth in (64, 65, 127, 128, 129):
            source, completed = run('depth-' + str(depth), transport(nested), nested, 1 << 20)
    good = command(request=9999)
    for label, control, before in (
        ('empty-command', b'', bytes(512)),
        ('reserved-command', good[:56] + struct.pack('<Q', 1), bytes(512)),
        ('dirty-initial', good, bytes(511) + b'!'),
        ('replay-done', good, completed),
    ):
        code, poisoned = bridge.call(label, source, control, before)
        assert code == BAD
        again, retained = bridge.call(label + '-permanent', source, good, poisoned)
        assert again == BAD and retained == poisoned
        controls.append(dict(case=label, permanent_poison=True))
    code, pending = bridge.call('grow-good', source, good, bytes(512))
    event = struct.unpack_from('<16Q', pending, 256)
    assert code == 384 and event[1] == 1
    continuation = command(2, request=9999, sequence=event[4])
    for label, control, changed_source in (
        ('wrong-lease', command(2, lease=18, request=9999, sequence=event[4]), source),
        ('wrong-request', command(2, request=9998, sequence=event[4]), source),
        ('stale-sequence', command(2, request=9999, sequence=event[4] - 1), source),
        ('changed-source-header', continuation, source[:48] + struct.pack('<Q', 1) + source[56:]),
    ):
        code, poisoned = bridge.call(label, changed_source, control, pending)
        assert code == BAD
        again, retained = bridge.call(label + '-permanent', source, continuation, poisoned)
        assert again == BAD and retained == poisoned
        controls.append(dict(case=label, permanent_poison=True))
    summary = dict(status='PASS', scope='DEVELOPMENT_ACTUAL_NATIVE_QUERY_PACKET_TO_BOUNDED_WIRE_NOT_PUBLIC_CAPTURE_OR_COLD',
                   cases=cases, private_controls=controls, whole_stack_closed=False,
                   full_native_public_prepare_coordinator_still_required=True)
except BaseException as exc:
    summary = dict(status='FAIL', cases=cases, private_controls=controls,
                   error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    bridge.close()
    issuer.close()
    wire.close()
    summary.update(native_bridge_entries=bridge.entries, native_issuer_entries=issuer.entries,
                   native_wire_entries=wire.entries, elapsed_ns=time.monotonic_ns() - started,
                   sources_unchanged=all(p.read_bytes() == raw for p, raw in pins.items()),
                   pins={str(p): sha256(raw).hexdigest() for p, raw in pins.items()})
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('cases', 'private_controls', 'pins')}, sort_keys=True), flush=True)
    assert summary['sources_unchanged']
