"""Bridge an actually issued integer typed tree into the general GraphLease.

This bridge performs no public Agent admission. Its predecessor owns the exact
immutable typed packet/index. It preserves the complete tree and converts all
decimal integer magnitudes natively. General foreign kinds and cyclic captured
graphs enter the separate general GraphLease issuer, not this tree bridge.
"""
from __future__ import annotations
import ast
from hashlib import sha256
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg, total_scalar_functions
from tools import hia_agent_edit_source_views as shared

SHARED_SHA = '555472263213f15deb239fcf3bf8e5b273a28caf3a67bb29ffd037f171d7ae5c'
CONSTANTS = {
    'COMMAND': int.from_bytes(b'HIAPGC01', 'little'),
    'STATE': int.from_bytes(b'HIAPGW01', 'little'),
    'EVENT': int.from_bytes(b'HIAPGE01', 'little'),
    'SOURCE': int.from_bytes(b'HIASIL01', 'little'),
    'GRAPH': int.from_bytes(b'HIAGRF01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1,
}
SOURCE = r'''
def packet_graph(s:readbuf, c:readbuf, w:mutbuf) -> u32:
    if length(w) < 512:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) == 2:
        return refuse(w, 1)
    if length(c) != 64 or word(c, 0) != COMMAND or word(c, 16) == 0 or word(c, 24) == 0:
        return refuse(w, 2)
    if word(c, 40) != 0 or word(c, 48) != 0 or word(c, 56) != 0 or source_lease(s) == 0:
        return refuse(w, 3)
    if get(w, 8) == 0:
        if word(c, 8) != 1 or word(c, 32) != 0:
            return refuse(w, 4)
        i = 0
        while i < 512:
            if byte(w, i) != 0:
                return refuse(w, 5)
            i = i + 1
        put(w, 0, STATE)
        put(w, 8, 1)
        put(w, 16, word(c, 16))
        put(w, 24, word(c, 24))
        put(w, 40, length(s))
        put(w, 48, word(s, 8))
        copy_bytes(w, s, 384, 0, 64)
        if measure(s, w) == 0:
            return refuse(w, 6)
    else:
        if get(w, 0) != STATE or get(w, 8) != 1 or word(c, 8) != 2:
            return refuse(w, 7)
        if word(c, 16) != get(w, 16) or word(c, 24) != get(w, 24) or word(c, 32) != get(w, 32):
            return refuse(w, 8)
        if length(s) != get(w, 40):
            return refuse(w, 9)
        i = 0
        while i < 64:
            if byte(s, i) != byte(w, 384 + i):
                return refuse(w, 10)
            i = i + 1
    if get(w, 88) > length(w):
        return event(w, 1)
    fill_range(w, 512, get(w, 88) - 512, 0)
    if build_nodes(s, w) == 0 or build_edges(s, w) == 0:
        return refuse(w, 11)
    base = get(w, 128)
    put(w, base, GRAPH)
    put(w, base + 8, get(w, 16))
    put(w, base + 16, get(w, 56))
    put(w, base + 24, 1)
    put(w, base + 32, get(w, 64))
    put(w, base + 40, get(w, 144))
    put(w, base + 48, get(w, 136) + get(w, 144))
    put(w, base + 56, 0)
    put(w, 104, get(w, 136) + get(w, 144))
    put(w, 8, 2)
    return event(w, 0)

def source_lease(s:readbuf) -> u64:
    if length(s) < 82 or word(s, 0) != SOURCE:
        return 0
    size = word(s, 8)
    if size < 16 or size > 67108864 or word(s, 24) != 64:
        return 0
    index = (64 + size + 7) & 18446744073709551608
    bits = (size + 7) >> 3
    if word(s, 16) != bits or word(s, 32) != index or word(s, 40) != length(s):
        return 0
    if index > length(s) or bits != length(s) - index or word(s, 48) != 0 or word(s, 56) != 0:
        return 0
    if word(s, 72) != size - 16 or (byte(s, index) & 1) == 0:
        return 0
    at = 64 + size
    while at < index:
        if byte(s, at) != 0:
            return 0
        at = at + 1
    if (size & 7) != 0 and (byte(s, length(s) - 1) >> (size & 7)) != 0:
        return 0
    return 1

def event(w:mutbuf, action:u64) -> u32:
    if get(w, 32) == MAX:
        put(w, 8, 3)
        return BAD
    put(w, 32, get(w, 32) + 1)
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 88))
    put(w, 304, get(w, 128))
    put(w, 312, get(w, 104))
    put(w, 320, get(w, 192))
    put(w, 328, get(w, 56))
    put(w, 336, get(w, 64))
    put(w, 344, get(w, 144))
    i = 352
    while i < 384:
        put(w, i, 0)
        i = i + 8
    return 384

def refuse(w:mutbuf, reason:u64) -> u32:
    put(w, 8, 3)
    put(w, 192, reason)
    event(w, 3)
    return BAD

def node_extent(s:readbuf, at:u64) -> u64:
    if at > word(s, 8) - 16:
        return 0
    if (byte(s, word(s, 32) + (at >> 3)) & (1 << (at & 7))) == 0:
        return 0
    size = word(s, 64 + at + 8)
    if size > word(s, 8) - 16 - at:
        return 0
    return size + 16

def following_node(s:readbuf, at:u64) -> u64:
    kind = word(s, 64 + at)
    if kind == 5 or kind == 6:
        return at + 24
    return at + 16 + word(s, 64 + at + 8)

def measure(s:readbuf, w:mutbuf) -> u64:
    at = 0
    while at < get(w, 48):
        extent = node_extent(s, at)
        if extent == 0:
            return 0
        kind = word(s, 64 + at)
        size = extent - 16
        if kind == 0:
            if size != 0:
                return 0
        elif kind == 1:
            if size != 1 or byte(s, 64 + at + 16) > 1:
                return 0
        elif kind == 2:
            if size == 0:
                return 0
            put(w, 72, get(w, 72) + size)
        elif kind == 4:
            put(w, 72, get(w, 72) + size)
        elif kind == 5 or kind == 6:
            if size < 8:
                return 0
            count_ = word(s, 64 + at + 16)
            if count_ > (size - 8) >> 4:
                return 0
            if kind == 6:
                if count_ > (size - 8) >> 5:
                    return 0
                count_ = count_ * 2
            put(w, 64, get(w, 64) + count_)
        else:
            return 0
        put(w, 56, get(w, 56) + 1)
        at = following_node(s, at)
    if at != get(w, 48) or get(w, 56) == 0 or get(w, 64) + 1 != get(w, 56):
        return 0
    slots = 2
    while slots < get(w, 56) * 2:
        slots = slots * 2
    put(w, 112, slots)
    put(w, 120, 512)
    put(w, 128, 512 + slots * 16)
    put(w, 136, 64 + get(w, 56) * 64 + get(w, 64) * 8)
    put(w, 88, get(w, 128) + get(w, 136) + get(w, 72))
    return 1

def slot(w:mutbuf, offset:u64) -> u64:
    key = offset + 1
    hash_ = key ^ (key >> 17)
    hash_ = hash_ * 11400714819323198485
    mask = get(w, 112) - 1
    index = hash_ & mask
    tried = 0
    while tried < get(w, 112):
        at = get(w, 120) + index * 16
        if get(w, at) == 0 or get(w, at) == key:
            return at
        index = (index + 1) & mask
        tried = tried + 1
    return 0

def integer_payload(s:readbuf, w:mutbuf, source:u64, size:u64, target:u64) -> u64:
    sign = 0
    i = 0
    if byte(s, source) == 45:
        sign = 1
        i = 1
    if i == size:
        return 0
    used = 0
    base = get(w, 128) + get(w, 136) + get(w, 144)
    put(w, target + 8, get(w, 136) + get(w, 144))
    while i < size:
        digit = byte(s, source + i)
        if digit < 48 or digit > 57:
            return 0
        carry = digit - 48
        j = 0
        while j < used:
            value = byte(w, base + j) * 10 + carry
            store(w, base + j, value & 255)
            carry = value >> 8
            j = j + 1
        if carry != 0:
            if used >= size:
                return 0
            store(w, base + used, carry)
            used = used + 1
        i = i + 1
    if used != 0:
        put(w, target + 16, used)
        put(w, target + 48, sign)
        put(w, 144, get(w, 144) + used)
    return 1

def scalar_payload(s:readbuf, w:mutbuf, source:u64, target:u64, kind:u64, size:u64) -> u64:
    if kind == 0:
        return 1
    if kind == 1:
        put(w, target + 48, byte(s, source))
        return 1
    if size > get(w, 72) - get(w, 144):
        return 0
    if kind == 2:
        return integer_payload(s, w, source, size, target)
    if kind != 4:
        return 0
    offset = get(w, 136) + get(w, 144)
    put(w, target + 8, offset)
    put(w, target + 16, size)
    copy_bytes(w, s, get(w, 128) + offset, source, size)
    count_ = 0
    i = 0
    while i < size:
        if (byte(s, source + i) & 192) != 128:
            count_ = count_ + 1
        i = i + 1
    put(w, target + 48, count_)
    put(w, 144, get(w, 144) + size)
    return 1

def build_nodes(s:readbuf, w:mutbuf) -> u64:
    source = 0
    index = 1
    while source < get(w, 48):
        found = slot(w, source)
        if found == 0 or get(w, found) != 0:
            return 0
        put(w, found, source + 1)
        put(w, found + 8, index)
        target = get(w, 128) + 64 + (index - 1) * 64
        kind = word(s, 64 + source)
        put(w, target, kind)
        if kind == 5 or kind == 6:
            put(w, target + 32, word(s, 64 + source + 16))
            put(w, target + 40, index)
        else:
            if scalar_payload(s, w, 64 + source + 16, target, kind, word(s, 64 + source + 8)) == 0:
                return 0
        source = following_node(s, source)
        index = index + 1
    if index != get(w, 56) + 1 or source != get(w, 48):
        return 0
    return 1

def build_edges(s:readbuf, w:mutbuf) -> u64:
    source = 0
    index = 1
    base = get(w, 128) + 64 + get(w, 56) * 64
    cursor = 0
    while source < get(w, 48):
        kind = word(s, 64 + source)
        if kind == 5 or kind == 6:
            target = get(w, 128) + 64 + (index - 1) * 64
            put(w, target + 24, cursor)
            amount = word(s, 64 + source + 16)
            if kind == 6:
                amount = amount * 2
            child_ = source + 24
            i = 0
            while i < amount:
                found = slot(w, child_)
                if found == 0 or get(w, found) != child_ + 1 or cursor >= get(w, 64):
                    return 0
                ident = get(w, found + 8)
                if ident == 0 or ident > get(w, 56):
                    return 0
                put(w, base + cursor * 8, ident)
                cursor = cursor + 1
                child_ = child_ + 16 + word(s, 64 + child_ + 8)
                i = i + 1
            if child_ != source + 16 + word(s, 64 + source + 8):
                return 0
        source = following_node(s, source)
        index = index + 1
    if cursor != get(w, 64):
        return 0
    return 1
'''


def source_program():
    if sha256(Path(shared.__file__).read_bytes()).hexdigest() != SHARED_SHA:
        raise ValueError('immutable byte helpers changed')
    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node) if node.id in CONSTANTS else node
    own = Expand().visit(ast.parse(SOURCE)).body
    old = {node.name: node for node in ast.parse(shared.source_program()).body}
    tree = ast.Module(body=own + [old[n] for n in ('word', 'get', 'put')], type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    names = {n.name: 'f' + str(i + 1) for i, n in enumerate(nodes)}
    signatures = {n.name: ([a.annotation.id for a in n.args.args], n.returns.id) for n in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'}, {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'],
        'entry': 'b0', 'blocks': [{'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}], 'attrs': {'function': names['packet_graph']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}], 'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = shared.CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'packet_graph', 'functions': functions})


if __name__ == '__main__':
    doc = document()
    path = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap/packet_graph.hiaasm'
    path.write_text(render_assembly(doc))
    print(path.name, path.stat().st_size, len(doc['functions']), sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']), sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
