"""Actual issuer/facts/slice/query/canonical/SHA pipeline, development only."""
from contextlib import ExitStack
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch

from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program
from hepta.hia_program_tools import bounded_json_wire
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index, ObjectTokenDecoder
from hepta.hia_agent_slice_native import NativeAgentSlice
from hepta.hia_json_canonical_native import NativeJsonCanonicalizer
from hepta.hia_sha256_native import NativeSha256
from hepta import hia_edit_query as reference
from hepta import hia_agent_slice_native as old_facts
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import ActualFacts, lease, vm_call, MAGIC, BAD

DEV = Path(__file__).resolve().parent
ROOT = DEV.parent / 'Hepta-agent-edit-native'
OUT = DEV / 'query-native-r2'
OUT.mkdir(exist_ok=False)
BEFORE = DEV / 'facts-native-r3'
QUERY = DEV / 'query-source-and-compile-r2'
COMPILER = QUERY / 'source/compiler/B3.image.bin'
test_pins = {}
for p in [Path(__file__), DEV / 'facts_harness.py', ROOT / 'hepta/hia_edit_query.py',
          ROOT / 'hepta/hia_program_tools.py', ROOT / 'hepta/hia_agent_slice_native.py']:
    test_pins[p] = p.read_bytes()
compiled = {}
for name in ('json_canonical', 'sha256'):
    source = ROOT / 'examples/hia_bootstrap' / (name + '.hiaasm')
    test_pins[source] = source.read_bytes()
    path, receipt = compile_stage(OUT, name, COMPILER, test_pins[source])
    compiled[name] = path.read_bytes()
canonical = NativeJsonCanonicalizer(compiled['json_canonical'], sha256(compiled['json_canonical']).hexdigest())
hasher = NativeSha256(compiled['sha256'], sha256(compiled['sha256']).hexdigest())
slice_bytes = (BEFORE / 'agent-slice.image.bin').read_bytes()
slicer = NativeAgentSlice(slice_bytes, sha256(slice_bytes).hexdigest())
facts = ActualFacts(DEV / 'facts-source-and-compile-r1/agent-edit-facts.manifest.json', OUT / 'facts')
query = ActualFacts(QUERY / 'agent-edit-query-packet.manifest.json', OUT / 'query')
checked_query = assemble_program((QUERY / 'source/examples/hia_bootstrap/agent_edit_query_packet.hiaasm').read_bytes())
issuer_path = DEV.parent / 'native-composite-core-final-recovery-next/dependencies/packet-issuer/tests/test_hia_composite_packet_json.py'
test_pins[issuer_path] = issuer_path.read_bytes()
assert sha256(test_pins[issuer_path]).hexdigest() == 'a3b928ae40bd9730b0a32c79336f53c9b769138d30e229b6dd4e5184a4df4746'
spec = importlib.util.spec_from_file_location('query_actual_packet_issuer_r2', issuer_path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
issuer = module.ActualPacketJson(OUT / 'issuer')
prior_cases = json.loads((BEFORE / 'summary.json').read_text())['cases']
prior_ledger = [json.loads(line) for line in (BEFORE / 'facts/entries.jsonl').read_text().splitlines()]
done = {row['case']: row for row in prior_ledger if row['event'] and row['event'][1] == 0}
cases, private = [], []
started = time.monotonic_ns()


def forbidden(*args, **kwargs):
    raise AssertionError('host semantic/query/packet decoder entered actual pipeline')


def encode_packet(label, packet):
    result, header, value, bitmap, state = issuer.encode(label, packet)
    assert result == 64 + len(value) and header[5] == len(packet)
    return value, bitmap


def canonical_bytes(wire):
    return canonical.canonicalize(wire, max_nodes=262144, max_depth=64)


def query_control(fact, sliced, event, digests, *, request, action=1, sequence=0):
    return (struct.pack('<16Q', MAGIC(b'HIAQQC01'), action, 7, request, sequence,
                        len(fact), len(sliced), *event[8:11], event[11], event[12], event[13], 0, 0, 0)
            + b''.join(digests) + bytes(32) + fact + sliced)


def project(label, source, control):
    before, seen = bytes(1024), []
    while True:
        cmd = control if not seen else control[:8] + struct.pack('<Q', 2) + control[16:32] + struct.pack('<Q', seen[-1][2][4]) + control[40:]
        result, after = query.call(label, cmd, source, before)
        event = struct.unpack_from('<16Q', after, 256)
        seen.append((cmd, before, event, result, after))
        assert result == 384, (label, result, event)
        if event[1] == 0:
            return after[event[6]:event[6] + event[7]], seen
        assert event[1] == 1 and event[5] > len(after)
        before = after + bytes(event[5] - len(after))


try:
    for prior in prior_cases:
        if not prior['fact_and_slice_exact']:
            continue  # Those retained facts refusals have no query-input packet.
        label = prior['case']
        row = done[label]
        old_lease = (BEFORE / 'facts' / ('source-' + row['source_sha256'] + '.lease')).read_bytes()
        packet_length = struct.unpack_from('<Q', old_lease, 8)[0]
        input_packet = old_lease[64:64 + packet_length]
        (document, selection), _ = detached_packet_index(input_packet)
        original = verify_program(document)
        expected_error = None
        try:
            expected = reference.prepare_edit(original, **selection)
            expected_packet = transport(expected)
            expected_wire = bounded_json_wire(expected, 1 << 20)
            expected_hash = sha256(expected_wire).digest()
        except Exception as exc:
            expected_error = (type(exc).__name__, str(exc))
        entry_begin = query.entries
        with ExitStack() as guards:
            for owner, name in ((reference, 'prepare_edit'), (reference, '_reference_edit_slice'),
                                (reference, '_cfg_downstream_slice'), (old_facts, 'encode_function'),
                                (old_facts, 'native_edit_slice'), (ObjectTokenDecoder, 'feed'),
                                (json, 'loads')):
                guards.enter_context(patch.object(owner, name, new=forbidden))
            # The original captured typed packet is immutable; the real native
            # issuer validates it again and produces this invocation's bitmap.
            _, bitmap = encode_packet(label + '-source', input_packet)
            source = lease(input_packet, bitmap)
            assert source == old_lease
            status, fact_event, fact_work = facts.run(label, source, request=len(cases) + 1)
            assert status == 384 and fact_event[1] == 0
            fact = fact_work[fact_event[6]:fact_event[6] + fact_event[7]]
            try:
                sliced = slicer.run(fact)
            except Exception as exc:
                assert expected_error == (type(exc).__name__, str(exc)), (label, expected_error, exc)
                cases.append({'case': label, 'outcome': 'EXACT_EXPECTED_NATIVE_SLICE_REFUSAL',
                              'error': expected_error, 'query_entries': 0})
                continue
            assert expected_error is None, (label, expected_error)
            # Packet node byte extents are mechanical ranges from genuine
            # native-produced references. No host chooses a field or operation.
            op_at = fact_event[10] - (1 << 63)
            op_size = 16 + struct.unpack_from('<Q', input_packet, op_at + 8)[0]
            program_at = 24
            program_size = 16 + struct.unpack_from('<Q', input_packet, program_at + 8)[0]
            op_json, _ = encode_packet(label + '-operation', input_packet[op_at:op_at + op_size])
            program_json, _ = encode_packet(label + '-program', input_packet[program_at:program_at + program_size])
            op_wire = canonical_bytes(op_json)
            program_wire = canonical_bytes(program_json)
            base_digest = hasher.digest(program_wire)
            op_digest = hasher.digest(op_wire)
            control = query_control(fact, sliced, fact_event, (base_digest, base_digest, op_digest), request=len(cases) + 1)
            result_packet, observations = project(label, source, control)
            assert result_packet == expected_packet, label
            query_json, _ = encode_packet(label + '-query', result_packet)
            wire = canonical_bytes(query_json)
            digest = hasher.digest(wire)
            assert wire == expected_wire and digest == expected_hash
        if label in ('fixture', 'resources-2-get_pair-entry-left'):
            for cmd, before, event, result, after in observations:
                assert vm_call(checked_query, cmd, source, before) == (result, after)
        (OUT / ('query-' + str(len(cases)) + '.packet')).write_bytes(result_packet)
        (OUT / ('query-' + str(len(cases)) + '.json')).write_bytes(wire)
        (OUT / ('query-' + str(len(cases)) + '.expected.json')).write_bytes(expected_wire)
        cases.append({'case': label, 'outcome': 'EXACT_COMPLETE_QUERY',
                      'query_entries': query.entries - entry_begin, 'query_bytes': len(wire),
                      'query_sha256': digest.hex(), 'complete_packet_bytes': len(result_packet),
                      'all_host_semantics_disabled_during_actual_pipeline': True,
                      'native_canonicalization_and_payload_SHA': True,
                      'canonical_operation_SHA_matches': op_digest.hex() == expected['operation_sha256']})
        last_good = (source, control, observations[-1][-1])
    source, control, completed = last_good
    for label, cmd, initial in (
        ('empty-control', b'', bytes(1024)),
        ('reserved-control', control[:104] + struct.pack('<Q', 1) + control[112:], bytes(1024)),
        ('replay-complete', control, completed),
        ('dirty-initial', control, bytes(1023) + b'!'),
    ):
        code, after = query.call(label, cmd, source, initial)
        assert code == BAD
        again, after2 = query.call(label + '-permanent', control, source, after)
        assert again == BAD and after2 == after
        private.append({'case': label, 'permanent_refusal': True})
    code, pending = query.call('grow-original', control, source, bytes(1024))
    event = struct.unpack_from('<16Q', pending, 256)
    assert code == 384 and event[1] == 1
    continuation = control[:8] + struct.pack('<Q', 2) + control[16:32] + struct.pack('<Q', event[4]) + control[40:]
    for label, cmd in (
        ('changed-immutable-digest', continuation[:128] + bytes([continuation[128] ^ 1]) + continuation[129:]),
        ('wrong-request', continuation[:24] + struct.pack('<Q', 0xffff) + continuation[32:]),
        ('stale-sequence', continuation[:32] + struct.pack('<Q', event[4] - 1) + continuation[40:]),
    ):
        code, after = query.call(label, cmd, source, pending)
        assert code == BAD
        private.append({'case': label, 'rejected': True})
    summary = {'status': 'PASS', 'scope': 'DEVELOPMENT_COMPLETE_TYPED_QUERY_PIPELINE_NOT_PUBLIC_CAPTURE_ADMISSION_OR_COLD',
               'cases': cases, 'private_controls': private, 'native_query_entries': query.entries,
               'native_facts_entries': facts.entries, 'native_issuer_entries': issuer.entries,
               'elapsed_ns': time.monotonic_ns() - started, 'whole_stack_closed': False,
               'query_byte_node_depth_gate_not_yet_owned_by_this_component': True}
except BaseException as exc:
    traceback.print_exc()
    summary = {'status': 'FAIL', 'cases': cases, 'private_controls': private,
               'error_class': type(exc).__name__, 'error': str(exc),
               'native_query_entries': query.entries, 'native_facts_entries': facts.entries,
               'native_issuer_entries': issuer.entries}
    raise
finally:
    facts.close()
    query.close()
    issuer.close()
    summary['test_and_production_source_pins_unchanged'] = all(p.read_bytes() == raw for p, raw in test_pins.items())
    summary['pins'] = {str(p): sha256(raw).hexdigest() for p, raw in test_pins.items()}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('cases', 'private_controls', 'pins')}, sort_keys=True), flush=True)
    assert summary['test_and_production_source_pins_unchanged']
