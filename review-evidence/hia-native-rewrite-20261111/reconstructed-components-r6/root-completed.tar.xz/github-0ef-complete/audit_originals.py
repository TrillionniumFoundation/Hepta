"""Independent read-only replay of original GitHub 0ef artifact evidence."""
from pathlib import Path
from hashlib import sha256
import io, json, struct, time, zipfile

ROOT = Path('/home/runner/work/_temp')
OUT = Path('/workspace/scratch/9acdfa9f5639/hia-v67-0ef-github-qualification')
ARCHIVE_PATH = OUT.parent / 'HIA-v67-0ef9541-github-native-20261111.zip'
assert sha256(ARCHIVE_PATH.read_bytes()).hexdigest() == '4d63d1f748f95c83e24102c3cbe385afedcfcaf3a0eca5b34af5316118389b0f'
ARCHIVE = zipfile.ZipFile(ARCHIVE_PATH)
def read_bytes(path):
    return ARCHIVE.read(Path(path).relative_to(ROOT).as_posix())
EVIDENCE = ROOT / 'hia-cold.cold/qualification.evidence'
FAMILIES = ('capacity', 'cfg', 'elf', 'chain', 'owned', 'bulk', 'loan', 'resource',
            'tail', 'select', 'effects', 'multi', 'keyword', 'signed', 'scalar-casts',
            'explicit-traps', 'cli', 'names', 'exports')

def digest(data):
    return sha256(data).hexdigest()

def compact(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def read_json(path):
    return json.loads(read_bytes(path))

began = time.monotonic_ns()
run = json.loads((OUT / 'run.original.json').read_bytes())
assert run['head_sha'] == '0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5' and run['conclusion'] == 'success'
summary = {'head': run['head_sha']}
jobs = json.loads((OUT / 'jobs.original.json').read_bytes())['jobs']
assert len(jobs) == 2 and all(j['conclusion'] == 'success' for j in jobs)
outer_rows = []
names = ARCHIVE.namelist()
assert len(names) == len(set(names))
for info in ARCHIVE.infolist():
    assert not info.is_dir() and not Path(info.filename).is_absolute() and '..' not in Path(info.filename).parts
    raw = ARCHIVE.read(info.filename)
    assert len(raw) == info.file_size
    outer_rows.append({'path': info.filename, 'bytes': len(raw), 'sha256': digest(raw), 'mode': (info.external_attr >> 16) & 0o777})
(OUT / 'artifact-members.json').write_text(json.dumps(outer_rows, indent=2, sort_keys=True) + '\n')
cold = read_json(ROOT / 'hia-cold.json')
report_path = ROOT / 'hia-cold.cold/qualification.json'
report = read_json(report_path)
assert cold['status'] == 'COLD_SELFHOST_REPLAY_PASS' and cold['qualification_wall_limit_seconds'] == 180
assert len(cold['checks']) == 11 and all(v is True for v in cold['checks'].values())
assert digest(read_bytes(report_path)) == cold['nested_report_sha256']
assert report['status'] == 'SELF_HOSTED_FIXED_CORE_PASS'
assert len(report['checks']) == 5051 and all(v is True for v in report['checks'].values())
assert report['source_manifest'] == cold['source_manifest'] == json.loads((OUT.parent / 'hia-v67-0ef-qualification-local-01/frozen-closure.json').read_bytes())
assert len(report['source_manifest']) == 644
for name, expected in report['source_manifest'].items():
    assert digest(read_bytes(ROOT / 'hia-cold.cold/source' / name)) == expected
manifest_digest = digest(compact(report['source_manifest']))
scheduling = report['qualification_scheduling']
assert scheduling['maximum_host_oracle_workers'] == 2
assert scheduling['native_child_processes_reused'] is False
assert scheduling['independent_references_completed_before_B0'] is True
assert scheduling['phase_completed_only_after_verified_archive'] is True
references = scheduling['reference_processes']
assert len(references) == 17 and len({r['family'] for r in references}) == 17
reference_records = []
for receipt in references:
    assert receipt['returncode'] == 0
    assert receipt['source_manifest_sha256'] == manifest_digest
    assert receipt['completed_monotonic_ns'] <= scheduling['seed_started_monotonic_ns']
    path = EVIDENCE / ('reference-' + receipt['family'] + '.worker.json')
    data = read_bytes(path)
    assert digest(data) == receipt['report_sha256']
    worker = json.loads(data)
    assert worker['before_B0'] is True and worker['family'] == receipt['family']
    assert worker['source_manifest_sha256'] == manifest_digest
    assert digest(compact(worker['reference'])) == receipt['reference_sha256'] == worker['reference_sha256']
    reference_records.append({'family': receipt['family'], 'sha256': digest(data), 'completed_before_B0': True})

expected = [family + '-' + label for family in FAMILIES for label in ('original', 'modified')]
assert scheduling['phase_inventory'] == expected
assert len(scheduling['phases']) == len(set(expected)) == 38
index = read_json(EVIDENCE / 'phase-index.json')
assert index['completed'] == 38 and index['exceptions'] == 0
assert all(row['state'] == 'completed' and row['report_status'] == 'PASS' for row in index['phases'])
phase_records, events, phase_checks = [], [], set()
linked_total = linked_returned = linked_failed = 0
total_members = total_bytes = 0
for receipt, key in zip(scheduling['phases'], expected):
    assert receipt['family'] + '-' + receipt['compiler_label'] == key
    assert receipt['returncode'] == 0
    events.extend([(receipt['started_monotonic_ns'], 1), (receipt['completed_monotonic_ns'], -1)])
    raw_report = read_bytes(EVIDENCE / ('phase-' + key + '.json'))
    assert digest(raw_report) == receipt['report_sha256']
    phase = json.loads(raw_report)
    request = read_json(EVIDENCE / ('phase-' + key + '.request.json'))
    assert phase['status'] == 'PASS' and phase['checks'] and all(v is True for v in phase['checks'].values())
    assert not phase_checks.intersection(phase['checks'])
    phase_checks.update(phase['checks'])
    assert all(report['checks'][name] == value for name, value in phase['checks'].items())
    assert phase['source_manifest_sha256'] == request['source_manifest_sha256'] == manifest_digest
    for name, item in request['inputs'].items():
        path = Path(item['path'])
        path.relative_to(ROOT)
        assert digest(read_bytes(path)) == item['sha256'] == phase['input_sha256'][name]
    archive_receipt = receipt['raw_artifacts']
    archive_path = EVIDENCE / 'phase-runs' / (key + '.zip')
    assert str(archive_path) == archive_receipt['archive']
    assert len(read_bytes(archive_path)) == archive_receipt['packed_bytes']
    assert digest(read_bytes(archive_path)) == archive_receipt['archive_sha256']
    with zipfile.ZipFile(io.BytesIO(read_bytes(archive_path))) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        manifest_bytes = archive.read('HIA_ARCHIVE_MANIFEST.json')
        manifest = json.loads(manifest_bytes)
        assert digest(compact(manifest)) == archive_receipt['manifest_sha256']
        files = manifest['files']
        assert set(names) == set(files) | {'HIA_ARCHIVE_MANIFEST.json'}
        assert len(files) == archive_receipt['files']
        raw_bytes = 0
        for name, row in files.items():
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            info = archive.getinfo(name)
            data = archive.read(name)
            assert len(data) == row['bytes'] == info.file_size
            assert digest(data) == row['sha256'] and (info.external_attr >> 16) & 0o777 == row['mode']
            raw_bytes += len(data)
        assert raw_bytes == manifest['unpacked_bytes'] == archive_receipt['unpacked_bytes']
        source_directory = Path(manifest['source_directory'])
        def original(path):
            path = Path(path)
            if path.is_relative_to(source_directory):
                return archive.read(path.relative_to(source_directory).as_posix())
            path.relative_to(ROOT)
            return read_bytes(path)
        for name in files:
            if not name.endswith('.receipt.json'):
                continue
            observation = json.loads(archive.read(name))
            if observation.get('transport') != 'HIA-emitted-system-dlopen-ELF-observer-v1':
                continue
            linked_total += 1
            stem = name[:-len('.receipt.json')]
            call = json.loads(archive.read(stem + '.request.json'))
            image, source = original(call['image']), original(call['source'])
            assert digest(image) == call['image_sha256'] == observation['artifact_sha256']
            assert digest(source) == call['source_sha256'] == observation['input_sha256']
            assert len(source) == observation['input_bytes']
            assert observation['fresh_native_exec'] is True and observation['successor_process_reuse'] is False
            fd = (1 << 64) - 1 if call['shared_output_fd'] is None else call['shared_output_fd']
            frame = b'HIALDS01' + struct.pack('<6Q', len(image), len(source), call['capacity'],
                                             call['workspace_size'], call['workspace_fill'], fd) + image + source
            assert digest(frame) == call['frame_sha256']
            if observation['status'] == 'returned':
                linked_returned += 1
                output = original(call['output'])
                assert len(output) == call['capacity'] and digest(output) == observation['output_sha256']
                assert observation['source_unchanged'] is True
                assert observation['abi_status'] == observation['result_u64'] >> 32
                assert observation['core_u32'] == observation['result_u64'] & 0xffffffff
                assert observation['limits']['cpu_seconds'] == 10
                assert observation['limits']['address_bytes'] == 256 << 20
                assert not archive.read(stem + '.stderr.log')
            else:
                linked_failed += 1
                assert observation['status'] == 'child_failed' and observation['returncode'] < 0
            if 'shared_output_observation' in observation:
                capture = observation['shared_output_observation']
                output = original(call['output'])
                assert len(output) == capture['observed_bytes'] == call['capacity']
                assert digest(output) == capture['observed_sha256']
        total_members += len(names)
        total_bytes += raw_bytes + len(manifest_bytes)
    phase_records.append({'phase': key, 'checks': len(phase['checks']), 'original_files': len(files),
                          'original_bytes': raw_bytes, 'archive_sha256': archive_receipt['archive_sha256'],
                          'all_bytes_and_modes_replayed': True})
live = maximum = 0
for timestamp, delta in sorted(events):
    live += delta
    maximum = max(maximum, live)
assert live == 0 and maximum <= 2
generations = []
for generation in report['generations'] + report['modified_generations']:
    path = Path(generation['produced_image'])
    path.relative_to(ROOT)
    data = read_bytes(path)
    assert len(data) == generation['produced_bytes'] and digest(data) == generation['produced_sha256']
    assert generation['status'] == 'returned' and generation['source_unchanged'] is True
    assert generation['limits']['cpu_seconds'] == 10 and generation['limits']['address_bytes'] == 256 << 20
    generations.append({'case': generation['case'], 'bytes': len(data), 'sha256': digest(data)})
assert len({r['sha256'] for r in generations[:3]}) == 1
assert generations[4]['sha256'] == generations[5]['sha256'] != generations[3]['sha256']
result = {'schema': 'hia.original-cold-independent-readback.v1', 'source_head': summary['head'],
          'read_only_original_replay_not_new_native_qualification': True,
          'cold_elapsed_ns': cold['wall_elapsed_ns'], 'cold_limit_seconds': 180,
          'published_source_tree_files': 2798, 'closure_files': 644, 'outer_checks': 11,
          'nested_checks': len(report['checks']), 'phase_checks': len(phase_checks),
          'phases': phase_records, 'phase_archive_members_including_manifests': total_members,
          'phase_archive_unpacked_bytes_including_manifests': total_bytes,
          'references_completed_before_B0': reference_records,
          'measured_maximum_overlapping_phase_processes': maximum,
          'linked_receipts': linked_total, 'linked_returned': linked_returned,
          'linked_expected_signal_exits': linked_failed, 'all_saved_linked_inputs_frames_outputs_checked': True,
          'transient_unsaved_response_workspaces_not_reconstructed': True,
          'generations': generations, 'audit_elapsed_ns': time.monotonic_ns() - began,
          'whole_stack_closed': False, 'workflow_run': 43021706295, 'artifact_bytes': ARCHIVE_PATH.stat().st_size, 'artifact_sha256': '4d63d1f748f95c83e24102c3cbe385afedcfcaf3a0eca5b34af5316118389b0f', 'outer_original_files': len(outer_rows), 'outer_original_bytes': sum(x['bytes'] for x in outer_rows), 'current_source_closure_compared_to_published_0ef': True}
(OUT / 'cold-readback.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('phases', 'references_completed_before_B0', 'generations')}, indent=2), flush=True)

