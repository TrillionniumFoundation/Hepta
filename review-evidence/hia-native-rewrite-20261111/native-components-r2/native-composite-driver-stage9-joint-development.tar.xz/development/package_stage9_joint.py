"""Retain exact opaque-byte native joint pipeline and its frozen oracle."""
from pathlib import Path
import hashlib,json,stat,tarfile
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
NATIVE=Path('/dev/shm/hia-type-requests-development')
BASE=ROOT/'checkpoints/stage9-joint'
BASE.mkdir(exist_ok=False)
paths={}
def add(p,name):
    if not p.is_file() or p.is_symlink():raise RuntimeError(str(p))
    if name in paths and paths[name]!=p:raise RuntimeError(name)
    paths[name]=p
for revision in ('r1','r2'):
    for rel in ('development/joint_type_requests_six_ops_'+revision+'.py',
                'development/type-requests-joint-six-ops-'+revision+'.log',
                'development/type-requests-joint-six-ops-'+revision+'-summary.json'):
        add(ROOT/rel,rel)
    directory=NATIVE/('joint-six-ops-'+revision)
    for p in directory.rglob('*'):
        if p.is_file():add(p,'runtime/'+p.relative_to(NATIVE).as_posix())
    # Capture only an original whose current bytes still match this run's pin.
    pins=json.loads((directory/'source-before.json').read_bytes())
    for name,digest in pins.items():
        p=Path(name);raw=p.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=digest:
            raise RuntimeError('original source unavailable after change: '+name)
        arc='source-inputs/'+revision+'/'+p.relative_to(ROOT.parent).as_posix()
        add(p,arc)
add(ROOT/'development/package_stage9_joint.py','development/package_stage9_joint.py')
rows=[]
for name,p in sorted(paths.items()):
    raw=p.read_bytes();rows.append({'path':name,'origin':str(p),'bytes':len(raw),
        'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)})
manifest=BASE/'source.json'
manifest.write_text(json.dumps({'scope':'SIX_ACTUAL_NATIVE_SERVICE_PIPELINE_NOT_COMPLETE_COORDINATOR',
    'members':rows,'member_count':len(rows),'raw_bytes':sum(x['bytes'] for x in rows)},indent=2,sort_keys=True)+'\n')
out=Path('/dev/shm/native-composite-driver-stage9-joint-development.tar.xz')
with tarfile.open(out,'w:xz',preset=6) as tar:
    for row in rows:tar.add(paths[row['path']],arcname=row['path'],recursive=False)
with tarfile.open(out,'r:xz') as tar:
    assert [m.name for m in tar.getmembers()]==[r['path'] for r in rows]
    for row in rows:
        m=tar.getmember(row['path']);raw=tar.extractfile(m).read()
        assert raw==paths[row['path']].read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        assert stat.S_IMODE(m.mode)==row['mode']==stat.S_IMODE(paths[row['path']].stat().st_mode)
raw=out.read_bytes();persistent=BASE/out.name;persistent.write_bytes(raw);assert persistent.read_bytes()==raw
custody={'archive':str(out),'persistent_archive':str(persistent),'bytes':len(raw),
    'sha256':hashlib.sha256(raw).hexdigest(),'member_count':len(rows),'raw_bytes':sum(x['bytes'] for x in rows),
    'source_manifest':str(manifest),'source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'every_member_original_bytes_sha256_mode_equal':True}
p=BASE/'custody.json';p.write_text(json.dumps(custody,indent=2,sort_keys=True)+'\n')
print(json.dumps(custody),flush=True)
print(json.dumps({'custody':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
