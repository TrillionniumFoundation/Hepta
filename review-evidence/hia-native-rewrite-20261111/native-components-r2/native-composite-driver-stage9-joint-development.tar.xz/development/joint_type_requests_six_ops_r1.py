"""Compose request IR/projector/JSON with three exact native type images.

This reuses the peer's fixed original command/frame corpus as a test oracle.
It does not claim actual constructor/function orchestration is complete.
"""
from pathlib import Path
from hashlib import sha256
import ctypes,importlib.util,json,os,resource,struct,sys,time
from unittest.mock import patch
ROOT=Path('/workspace/scratch/9acdfa9f5639/native-composite-driver-next')
MAIN=ROOT.parent/'Hepta'
PEER=ROOT.parent/'native-composite-type-transport-next/development'
sys.path.insert(0,str(MAIN))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
test=module('type_request_actual_pipeline',ROOT/'tests/test_hia_composite_type_requests.py')
transport_module=module('type_transport_actual_pipeline',PEER/'transport_harness.py')
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_composite_types_native import NativeCompositeTypeSession
from hepta.hia_composite_function_tokens import ObjectTokenDecoder
from hepta import hia_program_composite
target=Path('/dev/shm/hia-type-requests-development/joint-six-ops-r1')
target.mkdir(parents=True,exist_ok=False)
pins={}
def read(path):
    path=Path(path).resolve();raw=path.read_bytes()
    if str(path) in pins and pins[str(path)]!=sha256(raw).hexdigest():raise AssertionError('source changed during admission')
    pins[str(path)]=sha256(raw).hexdigest()
    return raw
read(__file__);read(ROOT/'tests/test_hia_composite_type_requests.py');read(PEER/'transport_harness.py')
manifest=json.loads(read(PEER/'compile-types-r1/manifest.json'))
source=read(manifest['source_path']);image=read(manifest['image_path'])
assert manifest['schema']=='hepta.hia.composite-types-native.v1'
assert sha256(source).hexdigest()==manifest['source_sha256']
assert sha256(image).hexdigest()==manifest['image_sha256']
assert manifest['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
bundle=json.loads(read(PEER/'compile-r1/bundle.json'))
for row in bundle['components'].values():
    for kind in ('source','image'):
        assert sha256(read(row[kind+'_path'])).hexdigest()==row[kind+'_sha256']
fixtures=[]
for path in sorted((PEER/'actual-pipeline-r1').glob('*-types-command.json')):
    raw=read(path);native=read(path.with_name(path.name.replace('-types-command.json','-types-response.bin')))
    command=json.loads(raw);op=command['op'];registry=[]
    if op=='init':context,request=1,[1,command['definitions'],command['recursive_chain'],command['partial_records']]
    elif op=='parameters':context,request=1,[2,command['params']]
    elif op=='resolve':context,request=1,[3,command['ref']]
    elif op=='partial':context,request=2,[4,command['base'],command['initialized']]
    elif op=='origins':
        function={}
        if 'return_loans' in command:function['return_loans']=command['return_loans']
        context,request=1,[4,function,command['params'],command['returns']]
    elif op=='task_protocol':
        registry=[[name,[['p'+str(i),identifier] for i,identifier in enumerate(params)],returns]
                  for name,params,returns in command['functions']]
        context,request=2,[5,command['task']]
    else:raise AssertionError('unknown fixed oracle operation')
    fixtures.append((raw,native,context,request,registry))
assert len(fixtures)==13
assert all(sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items())
(target/'source-before.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
requests=test.ActualRequests(target/'requests')
typed=transport_module.NativeTransport(PEER/'compile-r1/bundle.json',lease=444,ledger=target/'type-transport-ledger.jsonl')
types_image=NativeHiaJsonImage(image,manifest['image_sha256'])
types_state=ctypes.create_string_buffer(128<<20)
types_output=ctypes.create_string_buffer((64<<20)+32)
ctypes.memset(ctypes.addressof(types_output)+(64<<20),0xa5,32)
records=[];start=time.monotonic()
def forbidden(*args,**kwargs):raise AssertionError('retained host semantic/transport owner entered')
try:
    for index,(original,old_frame,context,request,registry) in enumerate(fixtures):
        invocation,oracle=requests.invocation('joint-'+str(index),context,request,registry=registry)
        # This oracle construction occurs outside the forbidden forwarding loop.
        assert json.dumps(oracle,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()==original
        with patch.object(ObjectTokenDecoder,'feed',forbidden), \
             patch.object(NativeCompositeTypeSession,'_command',forbidden), \
             patch.object(NativeCompositeTypeSession,'_materialize_value',forbidden), \
             patch.object(hia_program_composite,'_Types',forbidden), \
             patch('hepta.hia_instruction_policy_native.transport',forbidden), \
             patch.object(transport_module,'transport',forbidden):
            result,event,packet=invocation.run()
            assert result==128 and event[1]==0,(index,event)
            _,_,raw,bitmap,state=requests.ir.issuer.encode('joint-types-json-'+str(index),packet)
            assert raw==original,(index,'normalized original JSON bytes differ')
            seq=index+1;operation=event[2];caller=event[4]
            begin=struct.pack('<8Q',transport_module.MAGIC['begin'],typed.lease,seq,
                               operation,caller,len(packet),0,0)+packet
            accepted=typed.call('commands',begin)
            assert accepted[0]==128 and accepted[1][1]==0,(index,'BEGIN',accepted)
            source_buffer=ctypes.create_string_buffer(raw+b'\xb6'*32)
            size=types_image._entry(source_buffer,len(raw),types_output,64<<20,types_state,128<<20)
            assert 64<=size<=64<<20,(index,size)
            assert bytes(source_buffer[:len(raw)+32])==raw+b'\xb6'*32
            assert bytes(types_output[64<<20:(64<<20)+32])==b'\xa5'*32
            actual=bytes(types_output[:size])
            assert actual==old_frame,(index,'original full type frame differs')
            reply=struct.pack('<8Q',transport_module.MAGIC['reply'],typed.lease,seq,
                               operation,caller,len(actual),0,0)+actual
            completed=typed.call('reply',reply)
            assert completed[0]==128 and completed[1][1]==0,(index,'REPLY',completed)
            assert completed[1][2:6]==(typed.lease,seq,caller,operation)
            native_error=struct.unpack_from('<Q',actual,8)[0]
            assert completed[1][6]==native_error
            if native_error:assert completed[2]==b''
        row={'index':index,'operation':operation,'caller_request':caller,
            'json_bytes':len(raw),'json_sha256':sha256(raw).hexdigest(),
            'typed_packet_bytes':len(packet),'typed_packet_sha256':sha256(packet).hexdigest(),
            'native_frame_bytes':len(actual),'native_frame_sha256':sha256(actual).hexdigest(),
            'full_type_frame_equals_frozen_old_adapter_oracle':True,
            'validator_event':completed[1],'validator_payload_bytes':len(completed[2]),
            'validator_payload_sha256':sha256(completed[2]).hexdigest(),
            'host_type_materializer_command_token_feed_and_transport_forbidden':True}
        records.append(row)
        (target/(str(index).zfill(3)+'-normalized.packet')).write_bytes(packet)
        (target/(str(index).zfill(3)+'-types-command.json')).write_bytes(raw)
        (target/(str(index).zfill(3)+'-types-frame.bin')).write_bytes(actual)
        (target/'transactions.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
finally:
    typed.close();requests.close()
    types_state=types_output=None
after={p:sha256(Path(p).read_bytes()).hexdigest() for p in pins}
assert after==pins
summary={'scope':'ACTUAL_NATIVE_SERVICE_TRANSPORT_COMPOSITION_NOT_COMPLETE_CONSTRUCTOR_FUNCTION_COORDINATOR',
    'passed':True,'transactions':len(records),'canonical_operations':sorted({r['operation'] for r in records}),
    'actual_type_owner_entries':len(records),'type_transport_entries':typed.calls,
    'type_transport_grows':typed.grows,'projector_entries':requests.entries,
    'actual_request_ir_entries':requests.ir.entries,'actual_packet_issuer_entries':requests.ir.issuer.entries,
    'elapsed_seconds':time.monotonic()-start,'source_before':pins,'source_after':after,
    'all_source_bytes_unchanged':True,'native_type_source_sha256':manifest['source_sha256'],
    'native_type_image_sha256':manifest['image_sha256'],
    'types_image_revision_note':'fresh peer candidate type source includes newer shared preflight; not an old decoder image or current cold qualification',
    'fixture_source_note':'13 frozen original type commands/frames; metadata token inputs authored by test harness, not yet actual constructor/function invocation',
    'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(target/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(ROOT/'development/type-requests-joint-six-ops-r1-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('source_before','source_after')}),flush=True)
