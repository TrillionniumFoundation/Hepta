"""Actual retained B3 compilation; development only, never a cold qualification."""
from pathlib import Path
from hashlib import sha256
import json
import sys
import traceback

ROOT = Path('/dev/shm/hia-agent-namespace-store-next')
BASE = Path(__file__).resolve().parent
FROZEN = BASE / 'checkpoints/values-source-r2'
OUT = Path('/dev/shm/hia-agent-namespace-store-native-r2/compile')
COMPILER_BASE = BASE.parent / 'hia-f50-compiler-custody'
COMPILER_SHA = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
sys.path.insert(0, str(ROOT))
from tools.qualify_hia_selfhost import compile_stage, CHILD


def digest(data):
    return sha256(data).hexdigest()


manifest = json.loads((FROZEN / 'source.json').read_bytes())
before = {}
for row in manifest['files']:
    path = ROOT / row['path']
    raw = path.read_bytes()
    assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
    assert raw == (FROZEN / row['path']).read_bytes()
    before[str(path)] = digest(raw)
custody = json.loads((COMPILER_BASE / 'custody.json').read_bytes())
for name, row in custody['files'].items():
    raw = (COMPILER_BASE / name).read_bytes()
    assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
    before[str(COMPILER_BASE / name)] = digest(raw)
compiler = COMPILER_BASE / 'B3.image.bin'
assert digest(compiler.read_bytes()) == COMPILER_SHA
before[str(CHILD)] = digest(CHILD.read_bytes())
source_path = ROOT / 'examples/hia_bootstrap/agent_namespace_values.hiaasm'
source = source_path.read_bytes()
OUT.mkdir(parents=True, exist_ok=False)
result = {
    'scope': 'DEVELOPMENT_ONLY_RETAINED_F50_B3; not candidate cold qualification or database qualification',
    'source_checkpoint_sha256': digest((FROZEN / 'source.json').read_bytes()),
    'compiler_custody_sha256': digest((COMPILER_BASE / 'custody.json').read_bytes()),
    'compiler_source_commit': custody['source_commit'],
    'compiler_sha256': COMPILER_SHA,
    'source_sha256': digest(source),
    'before': before,
}
try:
    image, receipt = compile_stage(OUT, 'agent-namespace-values', compiler, source)
    raw = image.read_bytes()
    assert receipt['input_sha256'] == receipt['source_sha256'] == digest(source)
    assert receipt['artifact_sha256'] == COMPILER_SHA
    assert receipt['produced_sha256'] == digest(raw)
    assert receipt['limits']['cpu_seconds'] == 10
    assert receipt['limits']['address_space_bytes'] == 256 << 20
    value = {'schema': 'hepta.hia.agent-namespace-values-native.v1',
             'source_sha256': digest(source), 'image_path': image.name,
             'image_sha256': digest(raw), 'compiler_sha256': COMPILER_SHA}
    (OUT / 'manifest.json').write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    result.update(status='PASS', receipt=receipt, manifest=value)
except BaseException as exc:
    traceback.print_exc()
    result.update(status='FAIL', exception_type=type(exc).__name__, error=str(exc))
finally:
    after = {name: digest(Path(name).read_bytes()) for name in before}
    result['after'] = after
    result['source_and_compiler_unchanged'] = before == after
    if before != after:
        result['status'] = 'FAIL'
    raw = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    (OUT / 'summary.json').write_bytes(raw)
    (BASE / 'compile-values-r2.original.json').write_bytes(raw)
    print(json.dumps({'status': result['status'], 'summary': str(OUT / 'summary.json'),
                      'bytes': len(raw), 'sha256': digest(raw)}, sort_keys=True), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
