"""Read back the existing actual compile; do not execute another compiler."""
from pathlib import Path
from hashlib import sha256
import json

BASE = Path(__file__).resolve().parent
OUT = Path('/dev/shm/hia-agent-namespace-store-native-r2/compile')
INITIAL = json.loads((OUT / 'summary.json').read_bytes())
receipt_raw = (OUT / 'agent-namespace-values.receipt.json').read_bytes()
receipt = json.loads(receipt_raw)
raw = (OUT / 'agent-namespace-values.image.bin').read_bytes()
source = (OUT / 'agent-namespace-values.input.bin').read_bytes()
output = (OUT / 'agent-namespace-values.output.bin').read_bytes()
digest = lambda b: sha256(b).hexdigest()
assert INITIAL['status'] == 'FAIL' and INITIAL['exception_type'] == 'KeyError'
assert INITIAL['error'] == "'address_space_bytes'"
assert receipt['status'] == 'returned' and receipt['abi_status'] == 0
assert receipt['limits']['cpu_seconds'] == 10
assert receipt['limits']['address_bytes'] == 256 << 20
assert receipt['source_unchanged'] and not receipt['forbidden_compiler_modules_loaded']
assert receipt['input_sha256'] == receipt['source_sha256'] == digest(source) == INITIAL['source_sha256']
assert receipt['artifact_sha256'] == receipt['image_sha256'] == INITIAL['compiler_sha256']
assert len(raw) == receipt['core_u32'] == receipt['produced_bytes']
assert receipt['produced_sha256'] == digest(raw)
assert output[:len(raw)] == raw and digest(output) == receipt['output_sha256']
for path, wanted in INITIAL['before'].items():
    assert digest(Path(path).read_bytes()) == wanted
manifest = {'schema': 'hepta.hia.agent-namespace-values-native.v1',
            'source_sha256': digest(source), 'image_path': 'agent-namespace-values.image.bin',
            'image_sha256': digest(raw), 'compiler_sha256': INITIAL['compiler_sha256']}
(OUT / 'manifest.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
value = {
    'scope': 'DEVELOPMENT_ONLY_RETAINED_F50_B3; not candidate cold or database qualification',
    'status': 'ACTUAL_COMPILE_PASS; INITIAL_POSTPROCESSOR_KEY_ERROR_PRESERVED',
    'compiler_reexecuted': False,
    'initial_control_sha256': digest((OUT / 'summary.json').read_bytes()),
    'receipt': receipt, 'receipt_sha256': digest(receipt_raw),
    'manifest': manifest, 'before_after_unchanged': True,
    'note': 'The actual original compiler succeeded. The audit script used address_space_bytes instead of the existing address_bytes field after compilation; this readback validates original limits and all original source/output bytes without replacing the failed initial control.'}
data = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
(OUT / 'readback.json').write_bytes(data)
(BASE / 'compile-values-r2.readback.json').write_bytes(data)
print(json.dumps({'status': value['status'], 'bytes': len(data), 'sha256': digest(data)}, sort_keys=True))
