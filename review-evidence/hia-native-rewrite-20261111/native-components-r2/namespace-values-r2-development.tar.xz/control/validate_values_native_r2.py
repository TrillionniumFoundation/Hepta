"""Paired actual B3-image/CoreVM calls over the seven frozen source tests."""
from pathlib import Path
from hashlib import sha256
import ctypes
import gzip
import json
import os
import struct
import sys
import time
import unittest

ROOT = Path('/dev/shm/hia-agent-namespace-store-next')
BASE = Path(__file__).resolve().parent
COMPILE = Path('/dev/shm/hia-agent-namespace-store-native-r2/compile')
OUT = COMPILE.parent / 'native-validation'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT))
from tests.test_hia_agent_namespace_store_values import NamespaceValueSourceTests, CANARY
from hepta.hia_json_preflight_native import NativeHiaJsonImage

digest = lambda raw: sha256(raw).hexdigest()
source_manifest = json.loads((BASE / 'checkpoints/values-source-r2/source.json').read_bytes())
pins = {}
for row in source_manifest['files']:
    path = ROOT / row['path']
    raw = path.read_bytes()
    assert digest(raw) == row['sha256'] and len(raw) == row['bytes']
    pins[str(path)] = digest(raw)
for path in (COMPILE / 'manifest.json', COMPILE / 'agent-namespace-values.image.bin',
             ROOT / 'hepta/hia_json_preflight_native.py', ROOT / 'hepta/hia_program_runtime.py',
             Path(__file__).resolve()):
    pins[str(path)] = digest(path.read_bytes())
manifest = json.loads((COMPILE / 'manifest.json').read_bytes())
assert manifest['source_sha256'] == pins[str(ROOT / 'examples/hia_bootstrap/agent_namespace_values.hiaasm')]
image_bytes = (COMPILE / manifest['image_path']).read_bytes()
assert manifest['image_sha256'] == digest(image_bytes)
image = NativeHiaJsonImage(image_bytes, manifest['image_sha256'])
assert image.image_sha256 == manifest['image_sha256']
ledger = gzip.open(OUT / 'invocations.jsonl.gz', 'wt', encoding='utf-8')
contexts = {}
counters = {'actual_native_entries': 0, 'persistent_workspace_allocations': 0,
            'explicit_private_workspace_mutations': 0, 'full_entry_bytes_equal': 0}


class PairedNativeTests(NamespaceValueSourceTests):
    def invoke(self, raw, work, *, steps=200000, output_size=128):
        before = bytes(work)
        key = id(work)
        mutation = None
        if key not in contexts:
            buf = ctypes.create_string_buffer(before, max(1, len(before)))
            contexts[key] = (work, buf, len(contexts) + 1)
            counters['persistent_workspace_allocations'] += 1
        else:
            held, buf, _ = contexts[key]
            self.assertIs(held, work)
            old = bytes(buf[:len(work)])
            if old != before:
                mutation = {'before_hex': old.hex(), 'after_hex': before.hex(),
                            'scope': 'explicit private corruption/near-u64 control from frozen test'}
                counters['explicit_private_workspace_mutations'] += 1
                ctypes.memmove(buf, before, len(before))
        _, buf, serial = contexts[key]
        expected_code, expected_header = super().invoke(raw, work, steps=steps, output_size=output_size)
        expected_work = bytes(work)
        extra = CANARY if output_size == 128 else b''
        out_before = bytes(output_size) + extra
        out = ctypes.create_string_buffer(out_before, max(1, len(out_before)))
        original = bytes(raw)
        source = ctypes.create_string_buffer(original + CANARY, len(original) + len(CANARY))
        started = time.monotonic_ns()
        code = image._entry(source, len(original), out, len(out_before), buf, len(before))
        elapsed = time.monotonic_ns() - started
        counters['actual_native_entries'] += 1
        actual_output = bytes(out[:len(out_before)])
        actual_work = bytes(buf[:len(before)])
        expected_output = (struct.pack('<16Q', *expected_header)
                           if output_size == 128 else expected_header) + extra
        row = {'entry': counters['actual_native_entries'], 'test_id': self.id(),
               'workspace_id': serial, 'input_hex': original.hex(),
               'pre_workspace_hex': before.hex(), 'explicit_private_mutation': mutation,
               'expected_return': expected_code, 'actual_return': code,
               'expected_output_hex': expected_output.hex(), 'actual_output_hex': actual_output.hex(),
               'expected_workspace_hex': expected_work.hex(), 'actual_workspace_hex': actual_work.hex(),
               'input_and_canary_unchanged': bytes(source[:len(original)+len(CANARY)]) == original+CANARY,
               'native_elapsed_ns': elapsed}
        ledger.write(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n')
        ledger.flush()
        self.assertEqual(code, expected_code)
        self.assertEqual(actual_output, expected_output)
        self.assertEqual(actual_work, expected_work)
        self.assertTrue(row['input_and_canary_unchanged'])
        counters['full_entry_bytes_equal'] += 1
        return expected_code, expected_header


started = time.monotonic_ns()
suite = unittest.defaultTestLoader.loadTestsFromTestCase(PairedNativeTests)
ids = [test.id() for test in suite]
result = unittest.TextTestRunner(verbosity=2).run(suite)
ledger.close()
after = {path: digest(Path(path).read_bytes()) for path in pins}
value = {
    'scope': 'DEVELOPMENT_ONLY actual retained-B3 image vs CoreVM, not namespace database or cold qualification',
    'image_sha256': manifest['image_sha256'], 'compiler_sha256': manifest['compiler_sha256'],
    'loaded_image_sha256': image.image_sha256, 'pid': os.getpid(),
    'before': pins, 'after': after, 'source_unchanged': pins == after,
    'tests_loaded': len(ids), 'test_ids': ids, 'tests_run': result.testsRun,
    'failures': [(t.id(), s) for t, s in result.failures],
    'errors': [(t.id(), s) for t, s in result.errors],
    'skipped': [(t.id(), s) for t, s in result.skipped],
    'expected_failures': [(t.id(), s) for t, s in result.expectedFailures],
    'unexpected_successes': [t.id() for t in result.unexpectedSuccesses],
    'counters': counters, 'wall_elapsed_ns': time.monotonic_ns() - started,
    'ledger': {'path': str(OUT / 'invocations.jsonl.gz'),
               'bytes': (OUT / 'invocations.jsonl.gz').stat().st_size,
               'sha256': digest((OUT / 'invocations.jsonl.gz').read_bytes())}}
passed = (result.wasSuccessful() and result.testsRun == len(ids) == 7
          and not value['skipped'] and not value['expected_failures'] and not value['unexpected_successes']
          and counters['actual_native_entries'] == counters['full_entry_bytes_equal'] > 0 and pins == after)
value['status'] = 'PASS' if passed else 'FAIL'
raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
(OUT / 'result.json').write_bytes(raw)
(BASE / 'values-native-r2.result.json').write_bytes(raw)
print(json.dumps({'status': value['status'], 'counters': counters,
                  'result_sha256': digest(raw)}, sort_keys=True), flush=True)
raise SystemExit(0 if passed else 1)
