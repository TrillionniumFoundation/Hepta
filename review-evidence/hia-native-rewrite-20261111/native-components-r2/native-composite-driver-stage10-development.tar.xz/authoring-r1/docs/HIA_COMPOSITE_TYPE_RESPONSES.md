# Native completed type-result continuation framing

This development component completes the return direction of all six type
services used by the constructor and function kernels. HIA converts the actual
issued-type transport result into the existing `HIACTP01`, `HIAFRS01`, or
`HIAFLR01` byte frame. It does not materialize Python types, decide type semantics,
inspect the transport's private registry offsets, or dispatch the semantic
owners. The complete native coordinator remains a separate component.

The input is a completed `HIATRE01` event and its same-call, immutable private
result-workspace lease. Both come directly from the fixed coordinator's actual
type-transport **REPLY** call. BEGIN also returns action zero, but that response
only acknowledges an outstanding transaction. In particular, a successful init
REPLY cannot be distinguished from a BEGIN ACK using the result shape alone.
The coordinator's issued call state supplies this provenance; a caller-provided
event or matching numeric lease is not an external authenticator. No subsequent
transport entry or GROW may invalidate the result borrow before framing ends.

## Entry and configuration

The external retained ABI is `readbuf event, mutbuf borrowed-result,
mutbuf output-workspace -> u32`. The wrapper explicitly creates and ends a read
loan on the second buffer. The two internal inputs are read-only. They do not
overlap each other or the writable workspace. This differs from semantic
kernels whose second buffer is an output destination.

The output workspace starts with zero controls and is at least 512 bytes. At
offset 128, sixteen little-endian words contain:

```
[HIASRP01, target, originalKind, callerRequest, typeSessionLease,
 commandSequence, canonicalTypeOperation, 0, 0, 0, 0, 0, 0, 0, 0, 0]
```

Targets are constructor (1), function admission (2), and function lowering (3).
All request, lease, and command identities must equal the completed transport
event. The operation mapping is fixed:

| Target | Original kind | Canonical type operation |
| --- | --- | --- |
| Constructor | 1, 2, 3 | init, parameters, resolve (1, 2, 3) |
| Constructor | 4, 5 | origins, task protocol (5, 6) |
| Function admission | 2 | parameters (2) |
| Function lowering | 2, 3, 4, 5 | parameters, resolve, partial, task protocol (2, 3, 4, 6) |

Function kind 6 is the separate complete task-helper owner. It is deliberately
not accepted as a type-service result.

The 128-byte framer event at offset zero contains:

```
[HIASRE01, action, target, originalKind, callerRequest, typeSessionLease,
 commandSequence, 512, responseBytes, requiredWorkspaceBytes,
 originalSemanticError, canonicalTypeOperation, framingError, 0, 0, 0]
```

Action zero publishes the complete existing owner response at offset 512;
action one requests GROW; action two records a framing refusal. A successful
entry returns 128. A refusal returns `0xfffffffd`, which always tells the driver
to discard this framer lease. A workspace shorter than 512 bytes returns that
value before it can update controls. With a complete workspace, a malformed
input permanently poisons the invocation, and further calls return BAD without
writing it again. Reusing a completed invocation also poisons it.

GROW preserves the complete workspace and repeats the same immutable inputs.
The saved event, source-workspace extent, and configuration are checked again.
The result workspace is never grown by this component. Its private immutable
borrow is the custody boundary; repeating identity words does not authenticate
replacement payload bytes. The whole relevant result shape and integer
representation are checked before a capacity request for response bytes. No
partial response is published. Semantic owners and the type transaction are
not called again during framer GROW.

## Exact existing responses

All words are little endian. The constructor receives:

```
[HIACTP01, request, originalKind, errorBoolean, count, payloadBytes, 0, 0]
+ payload
```

Function admission receives four words:

```
[HIAFRS01, request, errorBoolean, idCount] + ids
```

Function lowering receives:

```
[HIAFLR01, request, originalKind, errorBoolean, idCount, 0, 0, 0] + ids
```

An init success has an empty result. Resolve, partial, and task protocol produce
one issued 32-bit identity, serialized as an eight-byte word. Parameters use the
complete ordered native `[[name, id], ...]` typed packet; HIA verifies the whole
list/row/string/decimal structure and writes each ID in order. Parameter names
are not interpreted or returned by the old continuation ABI. The upstream type
transport already owns their schema and issuance validation.

Origins use the complete native `[null | [name, offset], ...]` packet. A null
becomes three zero words. A nonnull item becomes `[1, utf8NameBytes, offset]`
followed by the original name bytes. The existing offset range is 0 through 511.
There is no JSON re-encoding, dictionary sorting, source expansion, or descriptor
lookup. Existing semantic owners retain their own response and name checks.

A completed native semantic error produces the old `errorBoolean = 1`, zero
count, and no payload. The exact original error number remains in the framer
event for the coordinator's existing delegated-error mapping. Newly issued
descriptors and counters stay committed at the upstream transport's original
boundaries. Init failure additionally requires the fixed coordinator to close
and discard the failed type and transport leases, matching the existing type
session constructor. Later semantic failures do not close an otherwise valid
type session.

## Bounds and scope

This component uses fixed 512-byte controls plus the exact response length. The
two-pass traversal is linear in the issued result bytes and does not allocate a
second descriptor graph. Parameters need `header + 8 * count` bytes; each origin
needs 24 bytes plus its name bytes. Null origins may expand relative to their
16-byte typed nodes, so output capacity is calculated from the validated rows.
All extent checks use remaining lengths before addition. Counts are bounded by
their actual packet bytes, not a new language quota. Arithmetic overflow is a
framing refusal. Full Core output never passes through this component, and it
gains no 8 MiB or 64 MiB restriction here.

This document describes the new development source and its intended private
composition. Actual generated source, compile receipts, images, and tests are
separately source-pinned. A successful component test does not establish a
complete native constructor/function coordinator, current cold qualification,
native compiler authoring, or whole-stack removal of Python.
