"""Author complete type-result continuation framing in HIA.

Inputs are the completed, same-call event and borrowed result workspace from
the native issued-type transport. The fixed coordinator owns those private
leases and invokes this component only after REPLY, never after BEGIN's ACK.
No descriptor semantic decision or type registry access occurs here.
"""
from __future__ import annotations
import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

CONSTANTS = {
    'CONFIG': int.from_bytes(b'HIASRP01', 'little'),
    'EVENT': int.from_bytes(b'HIASRE01', 'little'),
    'TYPE_EVENT': int.from_bytes(b'HIATRE01', 'little'),
    'CTOR_RESPONSE': int.from_bytes(b'HIACTP01', 'little'),
    'ADMIT_RESPONSE': int.from_bytes(b'HIAFRS01', 'little'),
    'LOWER_RESPONSE': int.from_bytes(b'HIAFLR01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1, 'UINT32': (1 << 32) - 1,
    'BASE': 512, 'STATUS': 256, 'ERROR': 264, 'MODE': 272,
    'CURSOR': 280, 'SIZE': 288, 'HEADER': 296, 'SAVED_WORK': 304,
    'SAVED_TARGET': 312, 'SAVED_KIND': 320, 'SAVED_REQUEST': 328,
    'SAVED_LEASE': 336, 'SAVED_SEQ': 344, 'SAVED_OP': 352,
    'SAVED_EVENT': 360,
}

SOURCE = r'''
def type_response(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < BASE:
        return BAD
    if get(w, STATUS) == 3:
        return BAD
    if get(w, STATUS) >= 2:
        return refuse(w, 1)
    if admission(s, r, w) == 0:
        return refuse(w, 2)
    header = 64
    if get(w, SAVED_TARGET) == 2:
        header = 32
    put(w, HEADER, header)
    put(w, MODE, 0)
    put(w, CURSOR, header)
    if payload(s, r, w) == 0:
        return refuse(w, get(w, ERROR))
    size = get(w, CURSOR)
    if size > MAX - BASE:
        return refuse(w, 3)
    put(w, SIZE, size)
    if size > length(w) - BASE:
        put(w, STATUS, 1)
        return event(w, 1, BASE + size)
    put(w, MODE, 1)
    put(w, CURSOR, header)
    if payload(s, r, w) == 0 or get(w, CURSOR) != size:
        return refuse(w, 4)
    response_header(s, w)
    put(w, STATUS, 2)
    return event(w, 0, BASE + size)

def word(s:readbuf, at:u64) -> u64:
    result = 0
    i = 0
    while i < 8:
        result = result | (byte(s, at + i) << (i * 8))
        i = i + 1
    return result

def get(w:mutbuf, at:u64) -> u64:
    result = 0
    i = 0
    while i < 8:
        result = result | (byte(w, at + i) << (i * 8))
        i = i + 1
    return result

def put(w:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(w, at + i, (value >> (i * 8)) & 255)
        i = i + 1
    return 0

def fail(w:mutbuf, error:u64) -> u64:
    if get(w, ERROR) == 0:
        put(w, ERROR, error)
    return 0

def refuse(w:mutbuf, error:u64) -> u32:
    fail(w, error)
    put(w, STATUS, 3)
    event(w, 2, 0)
    return BAD

def event(w:mutbuf, action:u64, required:u64) -> u32:
    put(w, 0, EVENT)
    put(w, 8, action)
    put(w, 16, get(w, SAVED_TARGET))
    put(w, 24, get(w, SAVED_KIND))
    put(w, 32, get(w, SAVED_REQUEST))
    put(w, 40, get(w, SAVED_LEASE))
    put(w, 48, get(w, SAVED_SEQ))
    put(w, 56, BASE)
    put(w, 64, get(w, SIZE))
    put(w, 72, required)
    put(w, 80, get(w, SAVED_EVENT + 48))
    put(w, 88, get(w, SAVED_OP))
    put(w, 96, get(w, ERROR))
    put(w, 104, 0)
    put(w, 112, 0)
    put(w, 120, 0)
    return 128

def operation(target:u64, kind:u64) -> u64:
    if target == 1:
        if kind == 1 or kind == 2 or kind == 3:
            return kind
        if kind == 4:
            return 5
        if kind == 5:
            return 6
    elif target == 2:
        if kind == 2:
            return 2
    elif target == 3:
        if kind == 2 or kind == 3 or kind == 4:
            return kind
        if kind == 5:
            return 6
    return 0

def admission(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    if length(s) != 128 or word(s, 0) != TYPE_EVENT or word(s, 8) != 0:
        return 0
    if word(s, 120) != 0 or word(s, 48) > 50:
        return 0
    if get(w, 128) != CONFIG:
        return 0
    target = get(w, 136)
    kind = get(w, 144)
    op = operation(target, kind)
    if op == 0 or get(w, 176) != op or word(s, 40) != op:
        return 0
    if get(w, 152) == 0 or get(w, 160) == 0 or get(w, 168) == 0:
        return 0
    if word(s, 32) != get(w, 152) or word(s, 16) != get(w, 160) or word(s, 24) != get(w, 168):
        return 0
    i = 184
    while i < 256:
        if get(w, i) != 0:
            return 0
        i = i + 8
    if get(w, STATUS) == 0:
        put(w, SAVED_WORK, length(r))
        put(w, SAVED_TARGET, target)
        put(w, SAVED_KIND, kind)
        put(w, SAVED_REQUEST, get(w, 152))
        put(w, SAVED_LEASE, get(w, 160))
        put(w, SAVED_SEQ, get(w, 168))
        put(w, SAVED_OP, op)
        i = 0
        while i < 128:
            put(w, SAVED_EVENT + i, word(s, i))
            i = i + 8
    else:
        if get(w, SAVED_WORK) != length(r) or get(w, SAVED_TARGET) != target or get(w, SAVED_KIND) != kind:
            return 0
        if get(w, SAVED_REQUEST) != get(w, 152) or get(w, SAVED_LEASE) != get(w, 160):
            return 0
        if get(w, SAVED_SEQ) != get(w, 168) or get(w, SAVED_OP) != op:
            return 0
        i = 0
        while i < 128:
            if get(w, SAVED_EVENT + i) != word(s, i):
                return 0
            i = i + 8
    return 1

def node_end(r:readbuf, at:u64, end:u64) -> u64:
    if at > end or end - at < 16:
        return 0
    size = word(r, at + 8)
    if size > end - at - 16:
        return 0
    return at + 16 + size

def unsigned(r:readbuf, at:u64, end:u64, limit:u64) -> u64:
    if end - at < 17 or word(r, at) != 2 or word(r, at + 8) != end - at - 16:
        return MAX
    start = at + 16
    if end - start > 20:
        return MAX
    if end - start > 1 and byte(r, start) == 48:
        return MAX
    prefix = 429496729
    last = 5
    if limit == 511:
        prefix = 51
        last = 1
    elif limit != UINT32:
        return MAX
    value = 0
    while start < end:
        digit = byte(r, start)
        if digit < 48 or digit > 57:
            return MAX
        digit = digit - 48
        if value > prefix or (value == prefix and digit > last):
            return MAX
        value = value * 10 + digit
        start = start + 1
    return value

def reserve(w:mutbuf, size:u64) -> u64:
    current = get(w, CURSOR)
    if size > MAX - current:
        return fail(w, 20)
    if get(w, MODE) != 0:
        if current > get(w, SIZE) or size > get(w, SIZE) - current:
            return fail(w, 21)
    put(w, CURSOR, current + size)
    return 1

def emit_word(w:mutbuf, value:u64) -> u64:
    at = get(w, CURSOR)
    if reserve(w, 8) == 0:
        return 0
    if get(w, MODE) != 0:
        put(w, BASE + at, value)
    return 1

def emit_bytes(r:readbuf, w:mutbuf, at:u64, size:u64) -> u64:
    target = get(w, CURSOR)
    if reserve(w, size) == 0:
        return 0
    if get(w, MODE) != 0:
        copy_bytes(w, r, BASE + target, at, size)
    return 1

def payload(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    error = word(s, 48)
    op = get(w, SAVED_OP)
    kind = word(s, 88)
    count = word(s, 96)
    at = word(s, 104)
    size = word(s, 112)
    if error != 0 or op == 1:
        if word(s, 56) != 0 or kind != 0 or count != 0 or at != 0 or size != 0:
            return fail(w, 30)
        return 1
    if at > length(r) or size > length(r) - at:
        return fail(w, 31)
    if op == 3 or op == 4 or op == 6:
        if kind != 1 or count != 1 or size != 8:
            return fail(w, 32)
        id = word(r, at)
        if id == 0 or id > UINT32 or word(s, 56) != id:
            return fail(w, 33)
        return emit_word(w, id)
    expected = 2
    if op == 5:
        expected = 3
    if kind != expected or word(s, 56) != count:
        return fail(w, 34)
    end = at + size
    if node_end(r, at, end) != end or size < 24 or word(r, at) != 5 or word(r, at + 16) != count:
        return fail(w, 35)
    at = at + 24
    if count > (end - at) >> 4:
        return fail(w, 36)
    i = 0
    while i < count:
        finish = node_end(r, at, end)
        if finish == 0:
            return fail(w, 37)
        if op == 5 and word(r, at) == 0:
            if finish != at + 16:
                return fail(w, 38)
            if emit_word(w, 0) == 0 or emit_word(w, 0) == 0 or emit_word(w, 0) == 0:
                return 0
        else:
            if pair(r, w, at, finish, op) == 0:
                return 0
        at = finish
        i = i + 1
    if at != end:
        return fail(w, 39)
    return 1

def pair(r:readbuf, w:mutbuf, at:u64, end:u64, op:u64) -> u64:
    if end - at < 24 or word(r, at) != 5 or word(r, at + 16) != 2:
        return fail(w, 40)
    name = at + 24
    next = node_end(r, name, end)
    if next == 0 or word(r, name) != 4:
        return fail(w, 41)
    final = node_end(r, next, end)
    if final == 0 or final != end:
        return fail(w, 42)
    limit = UINT32
    if op == 5:
        limit = 511
    value = unsigned(r, next, final, limit)
    if value == MAX or (op == 2 and value == 0):
        return fail(w, 43)
    if op == 2:
        return emit_word(w, value)
    if emit_word(w, 1) == 0 or emit_word(w, next - name - 16) == 0 or emit_word(w, value) == 0:
        return 0
    return emit_bytes(r, w, name + 16, next - name - 16)

def response_header(s:readbuf, w:mutbuf) -> u64:
    error = 0
    if word(s, 48) != 0:
        error = 1
    count = word(s, 96)
    target = get(w, SAVED_TARGET)
    if target == 1:
        put(w, BASE, CTOR_RESPONSE)
        put(w, BASE + 8, get(w, SAVED_REQUEST))
        put(w, BASE + 16, get(w, SAVED_KIND))
        put(w, BASE + 24, error)
        put(w, BASE + 32, count)
        put(w, BASE + 40, get(w, SIZE) - 64)
        put(w, BASE + 48, 0)
        put(w, BASE + 56, 0)
    elif target == 2:
        put(w, BASE, ADMIT_RESPONSE)
        put(w, BASE + 8, get(w, SAVED_REQUEST))
        put(w, BASE + 16, error)
        put(w, BASE + 24, count)
    else:
        put(w, BASE, LOWER_RESPONSE)
        put(w, BASE + 8, get(w, SAVED_REQUEST))
        put(w, BASE + 16, get(w, SAVED_KIND))
        put(w, BASE + 24, error)
        put(w, BASE + 32, count)
        put(w, BASE + 40, 0)
        put(w, BASE + 48, 0)
        put(w, BASE + 56, 0)
    return 1
'''


class CopyBuilder(Builder):
    def expr(self, expression):
        if (isinstance(expression, ast.Call) and isinstance(expression.func, ast.Name)
                and expression.func.id == 'copy_bytes'):
            values = [self.expr(arg) for arg in expression.args]
            assert len(values) == 5 and values[0][1] == 'mutbuf' and values[1][1] == 'readbuf'
            return self.op('buffer.copy_range', values[:2] + [self.cast(v, 'usize') for v in values[2:]])
        return super().expr(expression)


def source_program():
    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id in CONSTANTS:
                return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node)
            return node
    return ast.unparse(ast.fix_missing_locations(Expand().visit(ast.parse(SOURCE)))) + '\n'


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i + 1) for i, node in enumerate(nodes)}
    signatures = {node.name: ([a.annotation.id for a in node.args.args], node.returns.id) for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'}, {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'], 'entry': 'b0',
        'blocks': [{'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}],
             'attrs': {'function': names['type_response']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}],
            'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
            'returns': [builder.returns], 'effects': ['read', 'write', 'trap'], 'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'composite_type_responses',
                                  'functions': functions})


if __name__ == '__main__':
    target = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap/composite_type_responses.hiaasm'
    doc = document()
    target.write_text(render_assembly(doc))
    print(target.name, target.stat().st_size, len(doc['functions']), sum(len(f['blocks']) for f in doc['functions']))
