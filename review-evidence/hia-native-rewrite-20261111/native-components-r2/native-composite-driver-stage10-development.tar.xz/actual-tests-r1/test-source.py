"""Actual HIA framing controls; synthetic private frames are not issued proofs."""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import random
import struct
import unittest

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'examples/hia_bootstrap/composite_type_responses.hiaasm'
GENERATOR = ROOT / 'tools/generate_hia_composite_type_responses.py'
FROZEN = ROOT / 'checkpoints/type-responses-source-r2/examples/hia_bootstrap/composite_type_responses.hiaasm'
MANIFEST = Path('/dev/shm/hia-type-responses-development/compile-r2/composite-type-responses.manifest.json')
SOURCE_SHA = 'cf89eb9e00b368c6a1326e0daedf003410ca2410a6b2885b24ff6bab32e62d7a'
COMPILER_SHA = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
MAGIC = lambda b: int.from_bytes(b, 'little')
CONFIG, EVENT, TYPE_EVENT = map(MAGIC, (b'HIASRP01', b'HIASRE01', b'HIATRE01'))
BAD, MAX = 0xfffffffd, (1 << 64) - 1
CANARY, READ_CANARY = b'\xa5' * 32, b'\xb7' * 32


def mapping(target, kind):
    if target == 1:
        return {1: 1, 2: 2, 3: 3, 4: 5, 5: 6}[kind]
    if target == 2:
        if kind != 2: raise ValueError('bad admission fixture')
        return 2
    return {2: 2, 3: 3, 4: 4, 5: 6}[kind]


def fixture(op, value=None, *, error=0, offset=64):
    if error or op == 1:
        identifier, kind, count, payload = 0, 0, 0, b''
        offset = 0
    elif op in (3, 4, 6):
        identifier, kind, count, payload = value, 1, 1, struct.pack('<Q', value)
    else:
        identifier, kind, count, payload = len(value), 2 if op == 2 else 3, len(value), transport(value)
    event = [TYPE_EVENT, 0, 801, 23, 17, op, error, identifier, 41, 0, 93,
             kind, count, offset, len(payload), 0]
    return event, b'\x39' * offset + payload


def expected(target, kind, value=None, *, error=0, request=17):
    op = mapping(target, kind)
    if error or op == 1:
        count, payload = 0, b''
    elif op == 2:
        count, payload = len(value), b''.join(struct.pack('<Q', item[1]) for item in value)
    elif op == 5:
        count = len(value)
        payload = b''.join(struct.pack('<3Q', 0, 0, 0) if item is None else
                          struct.pack('<3Q', 1, len(item[0].encode()), item[1]) + item[0].encode()
                          for item in value)
    else:
        count, payload = 1, struct.pack('<Q', value)
    if target == 1:
        header = struct.pack('<8Q', MAGIC(b'HIACTP01'), request, kind, bool(error), count, len(payload), 0, 0)
    elif target == 2:
        header = struct.pack('<4Q', MAGIC(b'HIAFRS01'), request, bool(error), count)
    else:
        header = struct.pack('<8Q', MAGIC(b'HIAFLR01'), request, kind, bool(error), count, 0, 0, 0)
    return header + payload


class ActualResponses:
    def __init__(self, directory):
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            digest = sha256(raw).hexdigest()
            if str(path) in self.pins and self.pins[str(path)] != digest:
                raise AssertionError('admission race')
            self.pins[str(path)] = digest
            return raw
        manifest = json.loads(read(MANIFEST))
        source, frozen = read(SOURCE), read(FROZEN)
        image = read(MANIFEST.parent / manifest['image_path'])
        if (set(manifest) != {'schema', 'source_sha256', 'image_path', 'image_sha256', 'compiler_sha256'}
                or manifest['schema'] != 'hepta.hia.composite-type-responses-native.v1'
                or source != frozen or sha256(source).hexdigest() != SOURCE_SHA
                or manifest['source_sha256'] != SOURCE_SHA
                or manifest['image_sha256'] != sha256(image).hexdigest()
                or manifest['compiler_sha256'] != COMPILER_SHA):
            raise AssertionError('response source/image identity mismatch')
        read(GENERATOR)
        read(__file__)
        if any(sha256(Path(p).read_bytes()).hexdigest() != h for p, h in self.pins.items()):
            raise AssertionError('source changed before mapping')
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=False)
        self.image = NativeHiaJsonImage(image, manifest['image_sha256'])
        self.log = (self.directory / 'actual-response-ledger.jsonl').open('w')
        self.entries = 0

    def invocation(self, label, target, kind, event, workspace, *, extent=None, capacity=512):
        return Invocation(self, label, target, kind, event, workspace, extent=extent, capacity=capacity)

    def close(self):
        self.log.close()
        after = {p: sha256(Path(p).read_bytes()).hexdigest() for p in self.pins}
        report = {'scope': 'NATIVE_CONTINUATION_FRAMER_DEV_NOT_COMPLETE_DRIVER', 'entries': self.entries,
                  'before': self.pins, 'after': after, 'sources_unchanged': after == self.pins}
        (self.directory / 'custody.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
        if after != self.pins: raise AssertionError('source changed during actual run')


class Invocation:
    def __init__(self, native, label, target, kind, event, workspace, *, extent=None, capacity=512):
        self.native, self.label = native, label
        self.event = list(event)
        if type(workspace) is bytes:
            self.read_size = len(workspace)
            self.read = ctypes.create_string_buffer(workspace + READ_CANARY)
        else:
            if extent is None: raise AssertionError('borrowed result extent required')
            self.read_size, self.read = extent, workspace
        self.work = ctypes.create_string_buffer(capacity + len(CANARY))
        self.capacity = capacity
        ctypes.memset(ctypes.addressof(self.work) + capacity, 0xa5, len(CANARY))
        config = [CONFIG, target, kind, event[4], event[2], event[3], mapping(target, kind)] + [0] * 9
        if capacity >= 256: struct.pack_into('<16Q', self.work, 128, *config)
        self.growths = 0

    def call(self, label='entry', *, event_wire=None, read_extent=None, work_extent=None):
        wire = struct.pack('<16Q', *self.event) if event_wire is None else event_wire
        source = ctypes.create_string_buffer(wire + READ_CANARY)
        before = bytes(self.read[:self.read_size])
        result = self.native.image._entry(source, len(wire), self.read,
            self.read_size if read_extent is None else read_extent,
            self.work, self.capacity if work_extent is None else work_extent)
        self.native.entries += 1
        unchanged = bytes(source[:len(wire) + 32]) == wire + READ_CANARY and bytes(self.read[:self.read_size]) == before
        guards = (bytes(self.read[self.read_size:self.read_size + 32]) == READ_CANARY
                  and bytes(self.work[self.capacity:self.capacity + 32]) == CANARY)
        if not unchanged or not guards: raise AssertionError('input or canary mutation')
        header = struct.unpack_from('<16Q', self.work) if self.capacity >= 128 else None
        payload = None
        if result != BAD:
            if result != 128 or header[0] != EVENT or header[13:] != (0, 0, 0):
                raise AssertionError(('invalid response event', result, header))
            if header[1] == 0:
                if header[7] != 512 or header[8] > self.capacity - 512 or header[9] != 512 + header[8]:
                    raise AssertionError('published response extent')
                payload = bytes(self.work[512:512 + header[8]])
        row = {'case': self.label, 'call': label, 'entry': self.native.entries, 'return': result,
               'event': header, 'capacity': self.capacity, 'input_bytes': len(wire),
               'input_sha256': sha256(wire).hexdigest(), 'read_workspace_bytes': self.read_size,
               'read_workspace_sha256': sha256(before).hexdigest(), 'inputs_unchanged': unchanged,
               'canaries_unchanged': guards, 'response_bytes': len(payload) if payload is not None else None,
               'response_sha256': sha256(payload).hexdigest() if payload is not None else None}
        if payload is not None and len(payload) <= 65536:
            row['response_base64'] = base64.b64encode(payload).decode()
        self.native.log.write(json.dumps(row, sort_keys=True) + '\n')
        self.native.log.flush()
        return result, header, payload

    def grow(self, needed):
        if needed <= self.capacity: raise AssertionError('nonincreasing growth')
        new = ctypes.create_string_buffer(needed + 32)
        ctypes.memmove(new, self.work, self.capacity)
        ctypes.memset(ctypes.addressof(new) + needed, 0xa5, 32)
        self.work, self.capacity = new, needed
        self.growths += 1

    def run(self):
        outcome = self.call()
        while outcome[0] != BAD and outcome[1][1] == 1:
            self.grow(outcome[1][9])
            outcome = self.call('after-grow')
        return outcome


class TypeResponseSourceTests(unittest.TestCase):
    def test_fixed_source_and_original_limits(self):
        raw = GENERATOR.read_bytes()
        spec = importlib.util.spec_from_file_location('response_source', GENERATOR)
        module = importlib.util.module_from_spec(spec)
        exec(compile(raw, str(GENERATOR), 'exec'), module.__dict__)
        doc = module.document()
        self.assertEqual(render_assembly(doc).encode(), SOURCE.read_bytes())
        self.assertEqual(SOURCE.read_bytes(), FROZEN.read_bytes())
        self.assertLessEqual(len(doc['functions']), 128)
        self.assertLessEqual(sum(len(f['blocks']) for f in doc['functions']), 1536)
        self.assertLessEqual(max(len(f['blocks']) for f in doc['functions']), 256)
        self.assertLessEqual(max(len(b['params']) for f in doc['functions'] for b in f['blocks']), 16)


class TypeResponseNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        directory = os.environ.get('HEPTA_HIA_TYPE_RESPONSE_EVIDENCE')
        if not directory: raise AssertionError('fresh actual evidence required; no skips')
        cls.native = ActualResponses(directory)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def check(self, label, target, kind, value=None, error=0):
        event, raw = fixture(mapping(target, kind), value, error=error)
        invocation = self.native.invocation(label, target, kind, event, raw)
        outcome = invocation.run()
        self.assertEqual(outcome[0], 128, outcome)
        self.assertEqual(outcome[1][1], 0, outcome)
        self.assertEqual(outcome[2], expected(target, kind, value, error=error))
        self.assertEqual(outcome[1][10], error)
        return invocation, outcome

    def test_every_existing_response_route_and_semantic_error(self):
        routes = [(1, 1, None), (1, 2, [['a', 1], ['z', 0xffffffff]]), (1, 3, 17),
                  (1, 4, [None, ['source', 0], ['tail', 511]]), (1, 5, 35),
                  (2, 2, [['x', 3]]), (3, 2, [['i', 8]]), (3, 3, 49), (3, 4, 51), (3, 5, 29)]
        for target, kind, value in routes:
            self.check('route-' + str((target, kind)), target, kind, value)
            for error in (1, 5, 6, 37, 44, 45, 46, 47, 50):
                self.check('semantic-' + str((target, kind, error)), target, kind, error=error)

    def test_empty_large_counts_random_values_and_exact_copy(self):
        for count in (0, 1, 4096):
            values = [['p' + str(i), 1 + i] for i in range(count)]
            for target in (1, 2, 3): self.check('params-' + str((target, count)), target, 2, values)
            values = [None if i % 2 else ['p' + str(i), i % 512] for i in range(count)]
            self.check('origins-' + str(count), 1, 4, values)
        rng = random.Random(7191)
        for i in range(45):
            value = [['n' + str(j), rng.randint(1, 0xffffffff)] for j in range(rng.randrange(12))]
            self.check('random-params-' + str(i), 1 + i % 3, 2, value)
            origins = [None if rng.randrange(3) == 0 else ['x' * rng.randrange(1, 129), rng.randrange(512)]
                       for _ in range(rng.randrange(12))]
            self.check('random-origins-' + str(i), 1, 4, origins)
        self.check('copy-utf8', 1, 4, [['名字"\\\n😀', 4]])

    def test_invalid_header_correlation_and_result_forms(self):
        base, raw = fixture(3, 17)
        mutations = [(0, 0), (1, 1), (2, 0), (3, 0), (4, 0), (5, 0), (6, 51), (7, 18),
                     (11, 4), (12, 0), (12, 2), (13, MAX), (14, MAX), (14, 7), (15, 1)]
        for at, value in mutations:
            event = list(base); event[at] = value
            inv = self.native.invocation('bad-header-' + str((at, value)), 1, 3, base, raw)
            inv.event = event
            self.assertEqual(inv.call()[0], BAD)
            frozen = bytes(inv.work)
            inv.event = base
            self.assertEqual(inv.call('after-refusal')[0], BAD)
            self.assertEqual(bytes(inv.work), frozen)
        for offset, value in ((128, 0), (136, 0), (136, 4), (144, 6), (152, 18), (160, 9),
                              (168, 24), (176, 6), (184, 1), (248, 1)):
            inv = self.native.invocation('bad-config-' + str(offset), 1, 3, base, raw)
            struct.pack_into('<Q', inv.work, offset, value)
            self.assertEqual(inv.call()[0], BAD)
        for value in (0, 1 << 32, MAX):
            event, raw = fixture(3, value)
            inv = self.native.invocation('bad-id-' + str(value), 1, 3, event, raw)
            self.assertEqual(inv.call()[0], BAD)
        for op, target, kind in ((1, 1, 1), (2, 1, 2), (5, 1, 4)):
            event, raw = fixture(op, error=5)
            event[12] = 1
            self.assertEqual(self.native.invocation('error-with-count-' + str(op), target, kind, event, raw).call()[0], BAD)

    def test_full_packet_validation_precedes_output_capacity(self):
        invalid_params = [None, {}, [None], [['x']], [['x', 1, 2]], [[1, 1]], [['x', 0]],
                          [['x', -1]], [['x', 1 << 32]], [['x', True]], [['x', None]]]
        invalid_origins = [{}, [True], [['x']], [['x', 512]], [['x', -1]], [[1, 0]], [0], [['x', False]]]
        for op, values in ((2, invalid_params), (5, invalid_origins)):
            for i, value in enumerate(values):
                packet = transport(value)
                count = len(value) if type(value) is list else 0
                event = [TYPE_EVENT, 0, 801, 23, 17, op, 0, count, 41, 0, 93,
                         2 if op == 2 else 3, count, 64, len(packet), 0]
                inv = self.native.invocation('bad-payload-' + str((op, i)), 1, 2 if op == 2 else 4,
                                             event, b'\0' * 64 + packet)
                outcome = inv.call()
                self.assertEqual(outcome[0], BAD, outcome)
                self.assertEqual(outcome[1][1], 2)
        for op, value in ((2, [['a', 1]]), (5, [None, ['x', 1]])):
            event, raw = fixture(op, value)
            for offset, word in ((64, 6), (72, MAX), (80, MAX), (80, 0)):
                changed = bytearray(raw); struct.pack_into('<Q', changed, offset, word)
                inv = self.native.invocation('bad-packet-word-' + str((op, offset)), 1, 2 if op == 2 else 4,
                                             event, bytes(changed))
                self.assertEqual(inv.call()[0], BAD)
            tail = raw + b'x'
            event[14] += 1
            self.assertEqual(self.native.invocation('extra-tail-' + str(op), 1, 2 if op == 2 else 4, event, tail).call()[0], BAD)
        for spelling in (b'', b'01', b'+1', b'-0', b'1x', b'4294967296', b'999999999999999999999'):
            packet = (struct.pack('<3Q', 5, 8 + 24 + 17 + 16 + len(spelling), 1)
                      + struct.pack('<3Q', 5, 8 + 17 + 16 + len(spelling), 2)
                      + struct.pack('<2Q', 4, 1) + b'x' + struct.pack('<2Q', 2, len(spelling)) + spelling)
            event = [TYPE_EVENT, 0, 801, 23, 17, 2, 0, 1, 41, 0, 93, 2, 1, 64, len(packet), 0]
            self.assertEqual(self.native.invocation('decimal-' + repr(spelling), 1, 2, event, b'\0' * 64 + packet).call()[0], BAD)

    def test_exact_growth_replay_poison_and_short_workspace_scope(self):
        values = [None, ['abc', 511], None]
        event, raw = fixture(5, values)
        inv = self.native.invocation('exact-growth', 1, 4, event, raw)
        first = inv.call()
        self.assertEqual(first[1][1], 1)
        needed = first[1][9]
        inv.grow(needed - 1)
        self.assertEqual(inv.call('one-short')[1][1], 1)
        inv.grow(needed)
        self.assertEqual(inv.call('exact')[2], expected(1, 4, values))
        self.assertEqual(inv.call('completed-replay')[0], BAD)
        frozen = bytes(inv.work)
        self.assertEqual(inv.call('poisoned-replay')[0], BAD)
        self.assertEqual(bytes(inv.work), frozen)
        for at in (2, 3, 4, 8, 9, 10, 13, 14):
            inv = self.native.invocation('grow-correlation-' + str(at), 1, 4, event, raw)
            first = inv.call(); inv.grow(first[1][9]); inv.event[at] += 1
            self.assertEqual(inv.call()[0], BAD)
        inv = self.native.invocation('short-workspace-is-raw-abi', 1, 4, event, raw)
        frozen = bytes(inv.work)
        self.assertEqual(inv.call(work_extent=511)[0], BAD)
        self.assertEqual(bytes(inv.work), frozen)
        self.assertEqual(inv.run()[2], expected(1, 4, values))
        for length in (0, 1, 63, 127, 129):
            inv = self.native.invocation('bad-event-extent-' + str(length), 1, 4, event, raw)
            self.assertEqual(inv.call(event_wire=b'\0' * length)[0], BAD)

    def test_malformed_private_frames_do_not_establish_issued_authority(self):
        # Header/custody provenance is deliberately outside this component.
        # In particular init BEGIN ACK and successful init REPLY share a shape.
        event, raw = fixture(1)
        inv = self.native.invocation('shape-only-is-not-completed-provenance', 1, 1, event, raw)
        self.assertEqual(inv.run()[2], expected(1, 1))
        # QUERY results have a distinct typeOp and are not service completions.
        event[5], event[11], event[12] = 0, 4, 1
        inv = self.native.invocation('query-is-not-reply', 1, 1, fixture(1)[0], raw)
        inv.event = event
        self.assertEqual(inv.call()[0], BAD)


if __name__ == '__main__':
    unittest.main()
