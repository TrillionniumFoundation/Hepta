# Complete native packet projections between composite owners

This development component moves the remaining owner-initialization packet
construction into HIA. It consumes the immutable SourceIndexLease issued by the
actual typed-packet validator and, where needed, completed metadata IR issued
by the actual ObjectToken consumer. The corresponding fixed coordinator tracks
the semantic producer and completion status. Numeric lease words and bitmaps
do not authenticate an arbitrary external packet or fabricated IR.

Four complete projections execute in one generated HIA image:

| Target | Native input | Complete output |
| --- | --- | --- |
| 0 | Original document packet and explicit legacy flag | `[document, legacy]` constructor packet |
| 1 | Successful constructor metadata | `[document, registry3, origins, 0, 0, legacy, 0]` function packet |
| 2 | The same successful constructor metadata | `[document, registry3, 0, 0, [], []]` outer packet |
| 3 | Original outer function request `[1, functionSourceRef]` | Existing `HIAFNX01` name command |

The constructor metadata is the full six-element value
`[stage, profile, legacy, documentSourceRef, registry4, origins]`. Its document
must be the original constructor packet member. Each registry row is
`[name, [[parameterName, issuedTypeID], ...], [returnIDs, ...], functionSourceRef]`.
The function source reference must be the corresponding original document
function, and its name must match the registry name. The HIA projection keeps
the first three row fields and omits the fourth field when producing the
function/outer transport representation. The original document is copied once;
function source objects are not repeatedly expanded through metadata.

All parameter names, type identities, return identities, origins, order, legacy
state, and source bytes are retained. The component does not resolve types,
count Core blocks, classify exports, plan function lowering, or sort functions.
The existing HIA constructor, function, type and outer owners retain those
decisions. Source dictionaries remain exact copies of the coordinator's
admitted packet; the public JSON canonicalization boundary must precede its
issuance. This component does not replace that boundary.

## ABI

The retained external ABI is `readbuf completedIR, mutbuf SourceIndexLease,
mutbuf workspace -> u32`. The wrapper explicitly borrows the second buffer as
read-only. For target zero, the first input is empty and the source lease holds
the document packet. Other targets use a completed `HIAOIS01` IR and its same
immutable source lease. Constructor metadata requires producer `HIACTK01`,
action zero and zero serial/value-slot counters. NEXT requires producer
`HIAOTK01`, action one and zero counters.

The writable workspace starts with zero controls and at least 512 bytes. Its
configuration at byte 128 is sixteen little-endian words:

```
[HIAOPP01, target, sourceLeaseID, streamID, requestID, legacyFlag, profile,
 0, 0, 0, 0, 0, 0, 0, 0, 0]
```

For target zero, stream, request and profile are zero. For targets one and two,
the profile is one through four, must equal completed constructor metadata, and
the legacy flag must equal both metadata and the original constructor input.
Only a successful constructor completion is eligible; the coordinator must
not turn a partial or refused constructor into function initialization. Target
three uses zero profile/legacy and the actual outer request identity.

The result event is 128 bytes at offset zero:

```
[HIAOPE01, action, target, sourceLeaseID, streamID, requestID, legacy, profile,
 outputOffset, outputBytes, requiredWorkspaceBytes, framingError, 0, 0, 0, 0]
```

Action zero publishes one complete output, action one requests GROW, and action
two records a framing refusal. Completed calls return 128; refusals return
`0xfffffffd`. GROW copies the complete old workspace and repeats the same
immutable IR/source inputs. All offsets remain valid after relocation. Saved
identity, sizes, root, and metadata node count are rechecked; these words are
custody checks within the fixed issuer, not content authentication of externally
substituted leases. Malformed complete-workspace calls permanently poison the
invocation. A too-short workspace cannot update its controls and must be
discarded by the driver on BAD.

## Bounds and ordering

The generic reference-preserving IR writer is shared at authoring time from the
exact pinned type-request projector source. The generated image contains all
required code; Python does not implement a runtime serialization plan. A
32-byte traversal stack entry is reserved per issued metadata node. Referenced
source subtrees are copied as one existing packet span and do not consume
expanded traversal nodes. Only target-zero wrapping, the two initialization
packets, and a small existing NEXT command are handled here; Core output never
passes through this component.

Output measurement traverses the complete relevant shape before the output
capacity check. The same writer then emits exactly the measured bytes. The
existing private owner input limit remains 64 MiB. Actual admitted public source
and constructor metadata have previously derived bounds below that limit; no
new full-Core or JSON input limit is introduced. Original constructor semantic
errors occur before these successful-state projections. The final Core
snapshot/node/depth/byte gates remain after all functions, helpers and outer
inventory completion in the complete driver design.

This is an independently compiled development component. Source regeneration,
actual native evidence, full coordinator execution, current cold qualification,
and eventual removal of retained owners are separate acceptance gates.
