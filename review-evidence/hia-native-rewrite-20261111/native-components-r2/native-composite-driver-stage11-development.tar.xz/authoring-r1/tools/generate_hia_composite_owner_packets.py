"""Author the complete immutable packet projections between composite owners.

Generic source-ref IR copying is shared at authoring time with the complete
type-request projector. All projection, shape, source identity and byte writing
decisions execute in the generated HIA image.
"""
from __future__ import annotations
import ast
from hashlib import sha256
import importlib.util
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_core_json_frontend import packed
from tools.generate_hia_selfhost import compact_authoring_cfg, total_scalar_functions

SHARED_SOURCE_SHA256 = '555472263213f15deb239fcf3bf8e5b273a28caf3a67bb29ffd037f171d7ae5c'


def shared_source():
    path = Path(__file__).with_name('generate_hia_composite_type_requests.py')
    raw = path.read_bytes()
    if sha256(raw).hexdigest() != SHARED_SOURCE_SHA256:
        raise ValueError('shared source-ref IR authoring changed')
    spec = importlib.util.spec_from_file_location('composite_packet_shared_authoring', path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


SOURCE = r'''
def owner_packet(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < STACK:
        return BAD
    if get(w, STATUS) == 3:
        return BAD
    if get(w, STATUS) >= 2:
        return refuse(w, 1)
    if admission(s, r, w) == 0:
        return refuse(w, 2)
    nodes = get(w, SAVED_NODES)
    if nodes > (MAX - STACK) >> 5:
        return refuse(w, 3)
    base = STACK + nodes * 32
    put(w, BASE, base)
    put(w, LIMIT, nodes)
    if base > length(w):
        return event(w, 1, base, 0)
    put(w, MODE, 0)
    put(w, CURSOR, 0)
    project(s, r, w)
    if get(w, ERROR) != 0:
        return refuse(w, get(w, ERROR))
    size = get(w, CURSOR)
    if size > MAX - base:
        return refuse(w, 4)
    if size > PACKET_MAX:
        return refuse(w, 5)
    if size > length(w) - base:
        return event(w, 1, base + size, size)
    put(w, EXPECTED, size)
    put(w, MODE, 1)
    put(w, CURSOR, 0)
    project(s, r, w)
    if get(w, ERROR) != 0 or get(w, CURSOR) != size:
        return refuse(w, 16)
    put(w, STATUS, 2)
    return event(w, 0, base + size, size)

def refuse(w:mutbuf, error:u64) -> u32:
    fail(w, error)
    put(w, STATUS, 3)
    event(w, 2, 0, 0)
    return BAD

def event(w:mutbuf, action:u64, needed:u64, size:u64) -> u32:
    if action == 1:
        put(w, STATUS, 1)
    put(w, 0, EVENT)
    put(w, 8, action)
    put(w, 16, get(w, SAVED_CONTEXT))
    put(w, 24, get(w, SAVED_LEASE))
    put(w, 32, get(w, SAVED_STREAM))
    put(w, 40, get(w, SAVED_REQUEST))
    put(w, 48, get(w, SAVED_LEGACY))
    put(w, 56, get(w, SAVED_PROFILE))
    put(w, 64, get(w, BASE))
    put(w, 72, size)
    put(w, 80, needed)
    put(w, 88, get(w, ERROR))
    put(w, 96, 0)
    put(w, 104, 0)
    put(w, 112, 0)
    put(w, 120, 0)
    return 128

def source_lease(r:readbuf) -> u64:
    if length(r) < 82 or word(r, 0) != SOURCE_MAGIC:
        return 0
    size = word(r, 8)
    if size < 16 or size > PACKET_MAX or word(r, 24) != 64:
        return 0
    index = (64 + size + 7) & (MAX - 7)
    count = (size + 7) >> 3
    if word(r, 16) != count or word(r, 32) != index:
        return 0
    if word(r, 40) != length(r) or index > length(r) or count != length(r) - index:
        return 0
    if word(r, 48) != 0 or word(r, 56) != 0 or word(r, 72) != size - 16:
        return 0
    if (byte(r, index) & 1) == 0:
        return 0
    i = 64 + size
    while i < index:
        if byte(r, i) != 0:
            return 0
        i = i + 1
    if (size & 7) != 0 and (byte(r, length(r) - 1) >> (size & 7)) != 0:
        return 0
    return 1

def admission(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    if source_lease(r) == 0 or get(w, 128) != CONFIG:
        return 0
    target = get(w, 136)
    if target > 3 or get(w, 144) == 0 or get(w, 168) > 1:
        return 0
    i = 184
    while i < 256:
        if get(w, i) != 0:
            return 0
        i = i + 8
    root = 0
    extent = 0
    nodes = 1
    if target == 0:
        if length(s) != 0 or get(w, 152) != 0 or get(w, 160) != 0 or get(w, 176) != 0:
            return 0
    else:
        if length(s) < IR_BASE or word(s, 0) != IR_MAGIC or word(s, 8) != 2:
            return 0
        if word(s, 128) != 0 or word(s, 184) != 0 or word(s, 136) == 0:
            return 0
        root = word(s, 120)
        extent = word(s, 144)
        nodes = word(s, 136)
        if extent < IR_BASE + 80 or extent > length(s) or extent >= REF:
            return 0
        if root < IR_BASE or root > extent - 80 or (root & 7) != 0:
            return 0
        if word(s, 16) != get(w, 144) or word(s, 24) != get(w, 152) or word(s, 48) != get(w, 160):
            return 0
        if word(s, 56) != 0 or word(s, 64) != 0:
            return 0
        if word(s, 88) != word(r, 8) or word(s, 104) != word(r, 16):
            return 0
        if word(s, 96) != word(r, 32) or word(s, 112) != length(r):
            return 0
        if target == 3:
            if word(s, 32) != OUTER_MAGIC or word(s, 40) != 1 or get(w, 176) != 0 or get(w, 168) != 0:
                return 0
        elif word(s, 32) != CTOR_MAGIC or word(s, 40) != 0 or get(w, 176) == 0 or get(w, 176) > 4:
            return 0
    if get(w, STATUS) == 0:
        put(w, ROOT, root)
        put(w, SAVED_CONTEXT, target)
        put(w, SAVED_LEASE, get(w, 144))
        put(w, SAVED_STREAM, get(w, 152))
        put(w, SAVED_REQUEST, get(w, 160))
        put(w, SAVED_LEGACY, get(w, 168))
        put(w, SAVED_PROFILE, get(w, 176))
        put(w, SAVED_IR_SIZE, extent)
        put(w, SAVED_SOURCE_SIZE, length(r))
        put(w, SAVED_NODES, nodes)
    else:
        if get(w, ROOT) != root or get(w, SAVED_CONTEXT) != target:
            return 0
        if get(w, SAVED_LEASE) != get(w, 144) or get(w, SAVED_STREAM) != get(w, 152) or get(w, SAVED_REQUEST) != get(w, 160):
            return 0
        if get(w, SAVED_LEGACY) != get(w, 168) or get(w, SAVED_PROFILE) != get(w, 176):
            return 0
        if get(w, SAVED_IR_SIZE) != extent or get(w, SAVED_SOURCE_SIZE) != length(r) or get(w, SAVED_NODES) != nodes:
            return 0
    return 1

def boolean_value(s:readbuf, r:readbuf, view:u64) -> u64:
    if kind(s, r, view) != 1:
        return MAX
    view = resolved(s, view)
    if view >= REF:
        return byte(r, 64 + view - REF + 16)
    return word(s, view + 8)

def boolean(w:mutbuf, value:u64) -> u64:
    header(w, 1, 1)
    at = reserve(w, 1)
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        store(w, get(w, BASE) + at, value)
    return 0

def duplicate_name(s:readbuf, r:readbuf, rows:u64, row:u64) -> u64:
    before = child(s, r, rows, 0)
    name = child(s, r, row, 0)
    while before != row:
        if text_equal(s, r, child(s, r, before, 0), name) == 1:
            return 1
        before = following(s, r, before)
    return 0

def registry(s:readbuf, r:readbuf, w:mutbuf, doc:u64, rows:u64) -> u64:
    functions = field(s, r, doc, L_functions)
    if kind(s, r, rows) != 5 or functions == 0 or kind(s, r, functions) != 5:
        return fail(w, 30)
    n = count(s, r, rows)
    if n != count(s, r, functions):
        return fail(w, 31)
    start = container(w, 5, n)
    row = child(s, r, rows, 0)
    fn = child(s, r, functions, 0)
    i = 0
    while i < n:
        if list_shape(s, r, row, 4) == 0 or kind(s, r, child(s, r, row, 0)) != 4:
            return fail(w, 32)
        if duplicate_name(s, r, rows, row) != 0:
            return fail(w, 33)
        source = child(s, r, row, 3)
        if resolved(s, source) != resolved(s, fn) or kind(s, r, source) != 6:
            return fail(w, 34)
        name = field(s, r, source, L_name)
        if name == 0 or kind(s, r, name) != 4 or text_equal(s, r, name, child(s, r, row, 0)) == 0:
            return fail(w, 35)
        params = child(s, r, row, 1)
        returns = child(s, r, row, 2)
        if parameter_pairs(s, r, w, params) == 0 or identifiers(s, r, w, returns) == 0:
            return 0
        item = container(w, 5, 3)
        emit_view(s, r, w, child(s, r, row, 0))
        emit_view(s, r, w, params)
        emit_view(s, r, w, returns)
        finish(w, item)
        row = following(s, r, row)
        fn = following(s, r, fn)
        i = i + 1
    finish(w, start)
    return 1

def origin_shape(s:readbuf, r:readbuf, w:mutbuf, rows:u64) -> u64:
    if kind(s, r, rows) != 5:
        return fail(w, 40)
    row = child(s, r, rows, 0)
    i = 0
    while i < count(s, r, rows):
        if list_shape(s, r, row, 2) == 0 or kind(s, r, child(s, r, row, 0)) != 4:
            return fail(w, 41)
        if duplicate_name(s, r, rows, row) != 0:
            return fail(w, 42)
        values = child(s, r, row, 1)
        if kind(s, r, values) != 5:
            return fail(w, 43)
        value = child(s, r, values, 0)
        j = 0
        while j < count(s, r, values):
            if kind(s, r, value) != 0:
                if list_shape(s, r, value, 2) == 0:
                    return fail(w, 44)
                if kind(s, r, child(s, r, value, 0)) != 4 or kind(s, r, child(s, r, value, 1)) != 2:
                    return fail(w, 45)
            value = following(s, r, value)
            j = j + 1
        row = following(s, r, row)
        i = i + 1
    return 1

def next_function(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    root = get(w, ROOT)
    if list_shape(s, r, root, 2) == 0 or unsigned(s, r, child(s, r, root, 0)) != 1:
        return fail(w, 50)
    fn = child(s, r, root, 1)
    if resolved(s, fn) < REF or kind(s, r, fn) != 6:
        return fail(w, 51)
    name = field(s, r, fn, L_name)
    if name == 0 or kind(s, r, name) != 4:
        return fail(w, 52)
    size = text_size(s, r, name)
    at = reserve(w, 16)
    content = reserve(w, size)
    if get(w, MODE) == 1 and get(w, ERROR) == 0:
        base = get(w, BASE)
        put(w, base + at, NEXT_MAGIC)
        put(w, base + at + 8, size)
        i = 0
        while i < size:
            store(w, base + content + i, text_byte(s, r, name, i))
            i = i + 1
    return 1

def project(s:readbuf, r:readbuf, w:mutbuf) -> u64:
    target = get(w, SAVED_CONTEXT)
    if target == 0:
        out = container(w, 5, 2)
        source_value(r, w, REF)
        boolean(w, get(w, SAVED_LEGACY))
        finish(w, out)
        return 1
    if target == 3:
        return next_function(s, r, w)
    root = get(w, ROOT)
    if list_shape(s, r, root, 6) == 0 or unsigned(s, r, child(s, r, root, 0)) != 3:
        return fail(w, 60)
    if unsigned(s, r, child(s, r, root, 1)) != get(w, SAVED_PROFILE):
        return fail(w, 61)
    if boolean_value(s, r, child(s, r, root, 2)) != get(w, SAVED_LEGACY):
        return fail(w, 62)
    if list_shape(s, r, REF, 2) == 0:
        return fail(w, 63)
    if boolean_value(s, r, child(s, r, REF, 1)) != get(w, SAVED_LEGACY):
        return fail(w, 64)
    doc = child(s, r, root, 3)
    if resolved(s, doc) != child(s, r, REF, 0):
        return fail(w, 65)
    rows = child(s, r, root, 4)
    origins = child(s, r, root, 5)
    if origin_shape(s, r, w, origins) == 0:
        return 0
    count = 7
    if target == 2:
        count = 6
    out = container(w, 5, count)
    emit_view(s, r, w, doc)
    if registry(s, r, w, doc, rows) == 0:
        return 0
    if target == 1:
        emit_view(s, r, w, origins)
    integer(w, 0)
    integer(w, 0)
    if target == 1:
        boolean(w, get(w, SAVED_LEGACY))
        integer(w, 0)
    else:
        a = container(w, 5, 0)
        finish(w, a)
        b = container(w, 5, 0)
        finish(w, b)
    finish(w, out)
    return 1
'''


COMMON_NAMES = ('word', 'get', 'put', 'fail', 'resolved', 'kind', 'count', 'child', 'following',
                'list_shape', 'text_size', 'text_byte', 'text_equal', 'text_is', 'field', 'unsigned',
                'reserve', 'header', 'literal', 'container', 'finish', 'integer', 'scalar', 'source_value',
                'push', 'emit_view', 'parameter_pairs', 'identifiers', 'power')


def source_program():
    shared = shared_source()
    constants = {**shared.CONSTANTS, 'CONFIG': int.from_bytes(b'HIAOPP01', 'little'),
                 'EVENT': int.from_bytes(b'HIAOPE01', 'little'),
                 'OUTER_MAGIC': int.from_bytes(b'HIAOTK01', 'little'),
                 'NEXT_MAGIC': int.from_bytes(b'HIAFNX01', 'little'),
                 'SAVED_PROFILE': 408, 'SAVED_LEGACY': 416, 'PACKET_MAX': 64 << 20}
    literals = {'L_' + name: packed(name) for name in ('functions', 'name')}
    class Expand(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Constant(constants[node.id]), node) if node.id in constants else node
        def visit_Call(self, node):
            node = self.generic_visit(node)
            args = []
            for arg in node.args:
                if isinstance(arg, ast.Name) and arg.id in literals:
                    args.extend(ast.Constant(v) for v in literals[arg.id])
                else:
                    args.append(arg)
            node.args = args
            return node
    own = Expand().visit(ast.parse(SOURCE)).body
    common = {node.name: node for node in ast.parse(shared.source_program()).body}
    tree = ast.Module(body=own + [common[name] for name in COMMON_NAMES], type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def document():
    shared = shared_source()
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i + 1) for i, node in enumerate(nodes)}
    signatures = {node.name: ([a.annotation.id for a in node.args.args], node.returns.id) for node in nodes}
    total = total_scalar_functions(nodes)
    params = [{'name': 'v0', 'type': 'readbuf'}, {'name': 'v1', 'type': 'mutbuf'}, {'name': 'v2', 'type': 'mutbuf'}]
    functions = [{'name': 'f0', 'params': params, 'returns': ['u32'], 'effects': ['read', 'write', 'trap'], 'entry': 'b0',
        'blocks': [{'id': 'b0', 'params': params, 'ops': [
            {'op': 'borrow.read', 'args': ['v1'], 'out': [{'name': 'v3', 'type': 'readbuf'}], 'attrs': {}},
            {'op': 'call', 'args': ['v0', 'v3', 'v2'], 'out': [{'name': 'v4', 'type': 'u32'}],
             'attrs': {'function': names['owner_packet']}},
            {'op': 'loan.end', 'args': ['v3'], 'out': [], 'attrs': {}}], 'term': {'op': 'ret', 'values': ['v4']}}]}]
    for node in nodes:
        builder = shared.CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name], 'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8', 'module': 'composite_owner_packets',
                                  'functions': functions})


if __name__ == '__main__':
    target = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap/composite_owner_packets.hiaasm'
    doc = document()
    target.write_text(render_assembly(doc))
    print(target.name, target.stat().st_size, len(doc['functions']), sum(len(f['blocks']) for f in doc['functions']))
