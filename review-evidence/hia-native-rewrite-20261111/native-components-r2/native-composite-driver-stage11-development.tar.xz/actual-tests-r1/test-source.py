"""Actual packet projection from native issued source indices and metadata IR."""
from hashlib import sha256
import base64
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import struct
import unittest

from hepta.hia_agent_assembly import render_assembly
from hepta.hia_instruction_policy_native import transport
from hepta.hia_json_preflight_native import NativeHiaJsonImage

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'examples/hia_bootstrap/composite_owner_packets.hiaasm'
GENERATOR = ROOT / 'tools/generate_hia_composite_owner_packets.py'
FROZEN = ROOT / 'checkpoints/owner-packets-source-r1/examples/hia_bootstrap/composite_owner_packets.hiaasm'
MANIFEST = Path('/dev/shm/hia-owner-packets-development/compile-r1/composite-owner-packets.manifest.json')
SOURCE_SHA = 'bbdb04534cf2b27ab673fa98266fb0c8df4a73ecb683500e773e8dd18d275999'
COMPILER_SHA = '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
MAGIC = lambda b: int.from_bytes(b, 'little')
CONFIG, EVENT = MAGIC(b'HIAOPP01'), MAGIC(b'HIAOPE01')
BAD, MAX, CANARY = 0xfffffffd, (1 << 64) - 1, b'\xa5' * 32


def module(name, path):
    raw = path.read_bytes()
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(path), 'exec'), value.__dict__)
    if path.read_bytes() != raw: raise AssertionError('test import source changed')
    return value


def document(profile=1, count=2, padding=0):
    return {'schema': 'hepta.hia.composite.v' + str(profile), 'module': 'owner_packet_fixture', 'types': [],
            'functions': [{'name': 'f' + str(i), 'params': [], 'returns': [], 'effects': [], 'entry': 'entry',
                           'blocks': [{'padding': 'x' * padding}]} for i in range(count)]}


class ActualOwnerPackets:
    def __init__(self, directory):
        self.pins = {}
        def read(path):
            path = Path(path).resolve(); raw = path.read_bytes(); digest = sha256(raw).hexdigest()
            if str(path) in self.pins and self.pins[str(path)] != digest:
                raise AssertionError('one source changed between roles')
            self.pins[str(path)] = digest
            return raw
        manifest = json.loads(read(MANIFEST))
        source, frozen = read(SOURCE), read(FROZEN)
        image = read(MANIFEST.parent / manifest['image_path'])
        if (manifest['schema'] != 'hepta.hia.composite-owner-packets-native.v1'
                or set(manifest) != {'schema', 'source_sha256', 'image_path', 'image_sha256', 'compiler_sha256'}
                or source != frozen or sha256(source).hexdigest() != SOURCE_SHA
                or manifest['source_sha256'] != SOURCE_SHA or manifest['image_sha256'] != sha256(image).hexdigest()
                or manifest['compiler_sha256'] != COMPILER_SHA):
            raise AssertionError('owner packet source/image mismatch')
        for p in (GENERATOR, ROOT / 'tools/generate_hia_composite_type_requests.py',
                  ROOT / 'tests/test_hia_composite_type_requests.py', ROOT / 'tests/test_hia_composite_object_ir.py', Path(__file__)):
            read(p)
        self.shared = module('owner_packet_test_tokens', ROOT / 'tests/test_hia_composite_type_requests.py')
        self.ir_module = module('owner_packet_test_ir', ROOT / 'tests/test_hia_composite_object_ir.py')
        if any(sha256(Path(p).read_bytes()).hexdigest() != h for p, h in self.pins.items()):
            raise AssertionError('source drift before evidence or mapping')
        self.directory = Path(directory); self.directory.mkdir(parents=True, exist_ok=False)
        self.image = NativeHiaJsonImage(image, manifest['image_sha256'])
        self.ir = self.ir_module.ActualIR(self.directory / 'actual-ir')
        self.log = (self.directory / 'actual-owner-packets-ledger.jsonl').open('w')
        self.entries = 0

    def initial(self, label, value, *, legacy=False, capacity=512):
        packet, source, nodes = self.ir.source(value)
        return Invocation(self, label, 0, None, source, legacy=legacy, profile=0, capacity=capacity)

    def metadata(self, label, value, *, legacy=False, profile=1, rows=None, origins=None, mutation=None):
        s = self.ir.session(label, [value, legacy], action=0, serial=0, slots=0)
        names = {node['name']: offset for offset, node in s.nodes.items() if type(node) is dict and 'name' in node}
        if rows is None:
            rows = [[fn['name'], [['p', 1], ['q', 2]], [3], self.shared.Ref(names[fn['name']])]
                    for fn in value['functions']]
        origins = [] if origins is None else origins
        metadata = [3, profile, legacy, self.shared.Ref(24), rows, origins]
        if mutation: mutation(metadata)
        self.consume(s, MAGIC(b'HIACTK01'), metadata)
        return s, self.shared.dereference(metadata, s.nodes)

    def consume(self, s, producer, value):
        s.init = struct.pack('<8Q', self.ir_module.INIT, s.lease, s.stream, producer, s.action, s.request, 0, 0)
        if s.initialize()[0] == BAD: raise AssertionError('issued source refused')
        chunks = self.ir_module.chunks(self.shared.wire_tokens(self.ir_module, value), 65472)
        for index, payload in enumerate(chunks):
            raw = struct.pack('<8Q', producer, s.action, index, int(index + 1 == len(chunks)), 0, 0, s.request, len(payload)) + payload
            if s.finish(s.call(raw, 'native-metadata-producer'))[0] == BAD:
                raise AssertionError('native metadata IR refused')

    def invocation(self, label, target, session, *, legacy=False, profile=1, capacity=512):
        return Invocation(self, label, target, session, session.source_wire, legacy=legacy,
                          profile=0 if target == 3 else profile, capacity=capacity)

    def close(self):
        self.ir.close(); self.log.close()
        after = {p: sha256(Path(p).read_bytes()).hexdigest() for p in self.pins}
        report = {'scope': 'COMPLETE_NATIVE_OWNER_PACKET_PROJECTIONS_NOT_COMPLETE_COORDINATOR',
                  'entries': self.entries, 'before': self.pins, 'after': after, 'source_unchanged': after == self.pins}
        (self.directory / 'custody.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
        if after != self.pins: raise AssertionError('owner packet source drift')


class Invocation:
    def __init__(self, native, label, target, session, source, *, legacy, profile, capacity):
        self.native, self.label, self.target, self.session = native, label, target, session
        if session is None:
            self.ir = ctypes.create_string_buffer(32); self.ir_size = 0
            self.source = ctypes.create_string_buffer(source + CANARY)
            lease, stream, request = 99, 0, 0
        else:
            self.ir, self.ir_size, self.source = session.work, session.size, session.source
            lease, stream, request = session.lease, session.stream, session.request
        self.source_size = len(source)
        self.capacity = capacity; self.work = ctypes.create_string_buffer(capacity + 32)
        ctypes.memset(ctypes.addressof(self.work) + capacity, 0xa5, 32)
        struct.pack_into('<16Q', self.work, 128, CONFIG, target, lease, stream, request, legacy, profile, *([0] * 9))

    def call(self, label='entry', *, ir_size=None, source_size=None, work_size=None):
        before_ir = bytes(self.ir[:self.ir_size]); before_source = bytes(self.source[:self.source_size])
        result = self.native.image._entry(self.ir, self.ir_size if ir_size is None else ir_size,
            self.source, self.source_size if source_size is None else source_size,
            self.work, self.capacity if work_size is None else work_size)
        self.native.entries += 1
        unchanged = bytes(self.ir[:self.ir_size]) == before_ir and bytes(self.source[:self.source_size]) == before_source
        guards = (bytes(self.source[self.source_size:self.source_size + 32]) == CANARY
                  and bytes(self.work[self.capacity:self.capacity + 32]) == CANARY)
        if self.session is not None: guards &= bytes(self.ir[self.ir_size:self.ir_size + 32]) == CANARY
        if not unchanged or not guards: raise AssertionError('read-only lease/canary changed')
        event = struct.unpack_from('<16Q', self.work)
        payload = None
        if result != BAD:
            if result != 128 or event[0] != EVENT or event[12:] != (0, 0, 0, 0):
                raise AssertionError('invalid owner packet event')
            if event[1] == 0:
                if event[8] > self.capacity or event[9] > self.capacity - event[8] or event[10] != event[8] + event[9]:
                    raise AssertionError('invalid owner packet extent')
                payload = bytes(self.work[event[8]:event[8] + event[9]])
        row = {'case': self.label, 'call': label, 'entry': self.native.entries, 'return': result,
               'event': event, 'capacity': self.capacity, 'ir_bytes': self.ir_size,
               'ir_sha256': sha256(before_ir).hexdigest(), 'source_bytes': self.source_size,
               'source_sha256': sha256(before_source).hexdigest(), 'inputs_unchanged': unchanged,
               'canaries_unchanged': guards, 'output_bytes': len(payload) if payload is not None else None,
               'output_sha256': sha256(payload).hexdigest() if payload is not None else None}
        if payload is not None and len(payload) < 65536: row['output_base64'] = base64.b64encode(payload).decode()
        self.native.log.write(json.dumps(row, sort_keys=True) + '\n'); self.native.log.flush()
        return result, event, payload

    def grow(self, size):
        if size <= self.capacity: raise AssertionError('nonincreasing GROW')
        new = ctypes.create_string_buffer(size + 32); ctypes.memmove(new, self.work, self.capacity)
        ctypes.memset(ctypes.addressof(new) + size, 0xa5, 32)
        self.work, self.capacity = new, size

    def run(self):
        outcome = self.call()
        while outcome[0] != BAD and outcome[1][1] == 1:
            self.grow(outcome[1][10]); outcome = self.call('resumed')
        return outcome


class OwnerPacketSourceTests(unittest.TestCase):
    def test_source_fixed_point_and_original_limits(self):
        doc = module('owner_packet_authoring', GENERATOR).document()
        self.assertEqual(render_assembly(doc).encode(), SOURCE.read_bytes())
        self.assertEqual(SOURCE.read_bytes(), FROZEN.read_bytes())
        self.assertLessEqual(len(doc['functions']), 128)
        self.assertLessEqual(sum(len(f['blocks']) for f in doc['functions']), 1536)
        self.assertLessEqual(max(len(f['blocks']) for f in doc['functions']), 256)
        self.assertLessEqual(max(len(b['params']) for f in doc['functions'] for b in f['blocks']), 16)


class OwnerPacketNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        directory = os.environ.get('HEPTA_HIA_OWNER_PACKET_EVIDENCE')
        if not directory: raise AssertionError('fresh native evidence required')
        cls.native = ActualOwnerPackets(directory)

    @classmethod
    def tearDownClass(cls):
        cls.native.close()

    def success(self, invocation, oracle):
        outcome = invocation.run()
        self.assertEqual(outcome[0], 128, outcome)
        self.assertEqual(outcome[1][1], 0, outcome)
        self.assertEqual(outcome[2], oracle)
        return outcome

    def test_constructor_wrapping_preserves_every_source_kind(self):
        for index, value in enumerate((None, True, False, 0, -1, 123456789012345678901234567890,
                                        '', 'é😀"\\\n', [], {}, [1, {'x': [None, True]}], document())):
            for legacy in (False, True):
                inv = self.native.initial('initial-' + str((index, legacy)), value, legacy=legacy)
                self.success(inv, transport([value, legacy]))

    def test_complete_function_and_outer_packets_all_profiles_legacy(self):
        for profile, legacy in ((1, False), (2, False), (3, False), (4, False), (1, True)):
            value = document(profile, 4)
            origins = [['f0', [None, ['p', 0]]], ['f1', []]] if profile == 4 else []
            s, meta = self.native.metadata('complete-' + str((profile, legacy)), value, legacy=legacy,
                                           profile=profile, origins=origins)
            rows = [row[:3] for row in meta[4]]
            self.success(self.native.invocation('function-' + str(profile), 1, s, legacy=legacy, profile=profile),
                         transport([value, rows, origins, 0, 0, legacy, 0]))
            self.success(self.native.invocation('outer-' + str(profile), 2, s, legacy=legacy, profile=profile),
                         transport([value, rows, 0, 0, [], []]))

    def test_complete_outer_request_native_name_command(self):
        value = document(4, 5)
        source = [value, [], 0, 0, [], []]
        for i in range(5):
            s = self.native.ir.session('outer-request-' + str(i), source, action=1, serial=0, slots=0)
            offset = next(offset for offset, node in s.nodes.items() if type(node) is dict and node.get('name') == 'f' + str(i))
            self.native.consume(s, MAGIC(b'HIAOTK01'), [1, self.native.shared.Ref(offset)])
            expected = struct.pack('<2Q', MAGIC(b'HIAFNX01'), 2) + ('f' + str(i)).encode()
            self.success(self.native.invocation('next-' + str(i), 3, s), expected)

    def test_large_source_refs_are_not_duplicated_as_function_metadata(self):
        value = document(3, 20, 256 << 10)
        s, meta = self.native.metadata('large-source-aliases', value, profile=3)
        self.assertGreater(len(json.dumps(meta, separators=(',', ':'))), 8 << 20)
        self.assertLess(len(json.dumps(value, separators=(',', ':'))), 8 << 20)
        rows = [row[:3] for row in meta[4]]
        actual = self.success(self.native.invocation('large-function', 1, s, profile=3),
                              transport([value, rows, [], 0, 0, False, 0]))
        self.assertLess(len(actual[2]), 6 << 20)
        self.assertLess(s.last[9] - self.native.ir_module.MIN_WORK, 40 << 10)

    def test_invalid_metadata_and_source_aliases_fail_before_output_growth(self):
        mutations = [lambda m: m.__setitem__(0, 2), lambda m: m.__setitem__(1, 4),
                     lambda m: m.__setitem__(2, True), lambda m: m.__setitem__(3, {'functions': []}),
                     lambda m: m[4][0].__setitem__(3, {}), lambda m: m[4][0].__setitem__(0, 'wrong'),
                     lambda m: m[4][0].__setitem__(1, [['x']]), lambda m: m[4][0].__setitem__(2, ['bad']),
                     lambda m: m.__setitem__(5, None), lambda m: m.__setitem__(5, [['x', [True]]]),
                     lambda m: m.__setitem__(5, [['x', []], ['x', []]])]
        for i, change in enumerate(mutations):
            s, _ = self.native.metadata('bad-meta-' + str(i), document(), mutation=change)
            inv = self.native.invocation('reject-meta-' + str(i), 1, s)
            first = inv.call()
            if first[0] != BAD and first[1][1] == 1:
                inv.grow(first[1][10]); first = inv.call('only-stack-growth')
            self.assertEqual(first[0], BAD, first)
            frozen = bytes(inv.work)
            self.assertEqual(inv.call('poisoned-repeat')[0], BAD)
            self.assertEqual(bytes(inv.work), frozen)

    def test_configuration_saved_identity_and_raw_bounds(self):
        s, _ = self.native.metadata('identity-fixture', document())
        for offset, value in ((128, 0), (136, 4), (144, 0), (152, 91), (160, 91), (168, 2), (176, 0), (184, 1)):
            inv = self.native.invocation('bad-config-' + str(offset), 1, s)
            struct.pack_into('<Q', inv.work, offset, value)
            self.assertEqual(inv.call()[0], BAD)
        inv = self.native.invocation('grow-identity', 1, s)
        first = inv.call(); self.assertEqual(first[1][1], 1)
        inv.grow(first[1][10]); struct.pack_into('<Q', inv.work, 176, 2)
        self.assertEqual(inv.call()[0], BAD)
        inv = self.native.initial('source-header', None)
        struct.pack_into('<Q', inv.source, 8, MAX)
        self.assertEqual(inv.call()[0], BAD)
        inv = self.native.initial('short-workspace-scope', None)
        before = bytes(inv.work)
        self.assertEqual(inv.call(work_size=511)[0], BAD)
        self.assertEqual(bytes(inv.work), before)
        self.success(inv, transport([None, False]))
        inv = self.native.initial('complete-is-not-reusable', None)
        self.success(inv, transport([None, False]))
        self.assertEqual(inv.call()[0], BAD)


if __name__ == '__main__':
    unittest.main()
