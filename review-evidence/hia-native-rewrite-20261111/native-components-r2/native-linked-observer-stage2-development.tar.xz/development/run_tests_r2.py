from pathlib import Path
import hashlib
import importlib.util
import json
import os
import resource
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT.parent / 'native-agent-state-integration')]
os.environ['HIA_LINKED_OBSERVER_EVIDENCE_DIR'] = '/dev/shm/hia-linked-observer-development/tests-r2/actual'
os.environ['TMPDIR'] = '/dev/shm'
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
directory = Path('/dev/shm/hia-linked-observer-development/tests-r2')
directory.mkdir(exist_ok=False)
source = ROOT / 'tests/test_hia_selfhost_linked_observer.py'
raw = source.read_bytes()
(directory / 'test-source.py').write_bytes(raw)
spec = importlib.util.spec_from_file_location('hia_linked_observer_actual_tests', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
def ids(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from ids(item)
        else:
            yield item.id()
selected = list(ids(suite))
executed = []
class Result(unittest.TextTestResult):
    def startTest(self, test):
        executed.append(test.id())
        super().startTest(test)
started = time.monotonic_ns()
result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
summary = {'scope': 'DEVELOPMENT_NATIVE_COMPONENT_NOT_FULL_COLD_QUALIFICATION',
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skipped': len(result.skipped), 'expected_failures': len(result.expectedFailures),
    'unexpected_successes': len(result.unexpectedSuccesses), 'selected_ids': selected,
    'executed_ids': executed, 'exact_selected_ids_executed': executed == selected,
    'source_sha256': hashlib.sha256(raw).hexdigest(), 'source_unchanged': source.read_bytes() == raw,
    'elapsed_ns': time.monotonic_ns() - started, 'max_rss_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'parent_limits': {'address_bytes': 1 << 30, 'cpu_seconds': 90},
    'native_child_limits_unchanged': {'address_bytes': 256 << 20, 'cpu_seconds': 10, 'wall_seconds': 20}}
summary['status'] = 'PASS' if (result.wasSuccessful() and not any((result.skipped,
    result.expectedFailures, result.unexpectedSuccesses)) and selected and selected == executed
    and summary['source_unchanged']) else 'FAIL'
for path in (directory / 'summary.json', ROOT / 'development/tests-r2-summary.json'):
    path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
