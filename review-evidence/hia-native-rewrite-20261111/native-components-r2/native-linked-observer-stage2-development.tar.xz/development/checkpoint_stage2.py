from pathlib import Path
from hashlib import sha256
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[1]
checkpoint = ROOT / 'checkpoints/stage2'
checkpoint.mkdir(exist_ok=False)
frozen = ROOT / 'checkpoints/source-r3'
frozen.mkdir(exist_ok=False)
source_rows = []
for relative in ('tools/generate_hia_linked_observer.py', 'tools/hia_selfhost_linked_observer.py',
        'tools/hia_linked_observer_template.S', 'examples/hia_bootstrap/linked_observer_packer.hiaasm',
        'tests/test_hia_selfhost_linked_observer.py', 'docs/HIA_SELFHOST_LINKED_OBSERVER.md'):
    raw = (ROOT / relative).read_bytes()
    target = frozen / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    source_rows.append({'path': relative, 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()})
old = json.loads((ROOT / 'checkpoints/source-r2/source.json').read_bytes())
for row in old['files']:
    assert row in source_rows
source = {'scope': 'COMPACT_LINKED_OBSERVER_DEVELOPMENT_SOURCE_NOT_COLD', 'files': source_rows,
    'production_source_identical_to_compile_r2': True}
(frozen / 'source.json').write_text(json.dumps(source, indent=2, sort_keys=True) + '\n')
items = {}
for name in ('source-r2', 'source-r3'):
    for path in (ROOT / 'checkpoints' / name).rglob('*'):
        if path.is_file():
            items['checkpoints/' + path.relative_to(ROOT / 'checkpoints').as_posix()] = path
for name in ('compile_r2.py', 'run_tests_r2.py', 'checkpoint_stage2.py', 'compile-r2.log',
        'compile-r2-summary.json', 'tests-r2.log', 'tests-r2-summary.json'):
    items['development/' + name] = ROOT / 'development' / name
runtime = Path('/dev/shm/hia-linked-observer-development')
for name in ('reference-r2', 'compile-r2', 'tests-r2'):
    for path in (runtime / name).rglob('*'):
        if path.is_file():
            items['runtime/' + path.relative_to(runtime).as_posix()] = path
rows = []
for name, path in sorted(items.items()):
    raw = path.read_bytes()
    rows.append({'path': name, 'origin': str(path), 'bytes': len(raw),
        'sha256': sha256(raw).hexdigest(), 'mode': path.stat().st_mode & 511})
manifest = {'scope': source['scope'], 'members': rows, 'member_count': len(rows),
    'raw_bytes': sum(row['bytes'] for row in rows)}
manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
(checkpoint / 'source.json').write_bytes(manifest_raw)
archive = checkpoint / 'native-linked-observer-stage2-development.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tf:
    for row in rows:
        raw = items[row['path']].read_bytes()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        member = tarfile.TarInfo(row['path'])
        member.size, member.mode = len(raw), row['mode']
        tf.addfile(member, io.BytesIO(raw))
with tarfile.open(archive, 'r:xz') as tf:
    members = tf.getmembers()
    assert [member.name for member in members] == [row['path'] for row in rows]
    for member, row in zip(members, rows):
        raw = tf.extractfile(member).read()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        assert member.mode == row['mode']
raw = archive.read_bytes()
result = {'archive': str(archive), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
    'member_count': len(rows), 'raw_bytes': manifest['raw_bytes'],
    'source_manifest_sha256': sha256(manifest_raw).hexdigest(),
    'all_members_bytes_sha256_mode_verified': True}
(checkpoint / 'custody.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result), flush=True)
