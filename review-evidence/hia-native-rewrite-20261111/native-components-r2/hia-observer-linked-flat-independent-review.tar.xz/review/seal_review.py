"""Seal every independent-review file and raw invocation without omitting failures."""
from pathlib import Path
import hashlib
import io
import json
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'hia-observer-linked-flat-independent-review.tar.xz'
ROOTS = {
    'review': ROOT,
    'raw/original-linked-build': Path('/dev/shm/hia-linked-observer-independent-probes'),
    'raw/fixed-linked': Path('/dev/shm/hia-linked-observer-independent-recheck-r3'),
    'raw/original-flat': Path('/dev/shm/hia-original-flat-binding-probes'),
    'raw/fixed-flat': Path('/dev/shm/hia-flat-observer-independent-recheck-r3'),
}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

pins = [
    (ROOT / 'fixed-r3/tools/hia_selfhost_linked_observer.py', '6729fe69c56ea02789ed5a53bcf17a701606b3145c60f8cd46a80f467a75a670'),
    (ROOT / 'flat-fixed-r3/tools/hia_selfhost_native_observer.py', 'd9102d22083f88fde3f1d2c09d8602cfc03f4c219382796864b308ff1597c610'),
]
for path, expected in pins:
    assert digest(path.read_bytes()) == expected, path
for name in ('fixed-r3-recheck.json', 'flat-fixed-r3-recheck.json'):
    assert json.loads((ROOT / name).read_bytes())['passed'] is True

entries = []
for prefix, base in ROOTS.items():
    assert base.is_dir(), base
    for path in sorted(base.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        raw = path.read_bytes()
        entries.append((prefix + '/' + path.relative_to(base).as_posix(), path, raw,
                        stat.S_IMODE(path.stat().st_mode)))
manifest = {'scope': 'INDEPENDENT_DEVELOPMENT_CUSTODY_REVIEW_NOT_COLD',
            'all_original_failures_preserved': True,
            'native_compiler_calls': 8, 'native_emitter_calls': 4, 'actual_VM_calls': 56,
            'files': [{'path': name, 'bytes': len(raw), 'sha256': digest(raw), 'mode': mode}
                      for name, _, raw, mode in entries]}
manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
with tarfile.open(OUT, 'w:xz', preset=3) as archive:
    for name, _, raw, mode in entries:
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = mode
        info.mtime = 0
        archive.addfile(info, io.BytesIO(raw))
    info = tarfile.TarInfo('MANIFEST.json')
    info.size = len(manifest_raw)
    info.mode = 0o644
    info.mtime = 0
    archive.addfile(info, io.BytesIO(manifest_raw))
expected = {name: (raw, mode) for name, _, raw, mode in entries}
expected['MANIFEST.json'] = (manifest_raw, 0o644)
with tarfile.open(OUT, 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(expected)
    for member in members:
        raw, mode = expected.pop(member.name)
        assert member.isfile() and member.mode == mode
        assert archive.extractfile(member).read() == raw
assert not expected
for _, path, raw, mode in entries:
    assert path.read_bytes() == raw and stat.S_IMODE(path.stat().st_mode) == mode
result = {'archive': str(OUT), 'archive_bytes': OUT.stat().st_size,
          'archive_sha256': digest(OUT.read_bytes()),
          'members': len(entries) + 1,
          'raw_bytes': sum(len(raw) for _, _, raw, _ in entries) + len(manifest_raw),
          'all_members_bytes_hash_mode_and_live_readback': True,
          'scope': manifest['scope'], 'files': manifest['files']}
custody = OUT.with_name(OUT.stem.replace('.tar', '') + '-custody.json')
custody.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'files'}, sort_keys=True))
print('custody', custody, custody.stat().st_size, digest(custody.read_bytes()))
