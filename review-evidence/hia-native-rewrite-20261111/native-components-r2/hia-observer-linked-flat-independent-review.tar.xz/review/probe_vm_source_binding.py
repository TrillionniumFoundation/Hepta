"""Actual VM windows must belong to one immutable packer source snapshot."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import resource
import sys
from unittest.mock import patch

AUDIT=Path(__file__).resolve().parent
FROZEN=AUDIT/'frozen'
BASE=Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration')
sys.path[:0]=[str(FROZEN),str(BASE)]
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
source=FROZEN/'tools/hia_selfhost_linked_observer.py';code=source.read_bytes()
spec=importlib.util.spec_from_file_location('reviewed_linked_observer_vm',source)
observer=importlib.util.module_from_spec(spec);exec(compile(code,str(source),'exec'),observer.__dict__)
assert sha256(code).hexdigest()=='fbe91da76e46c5ce5c0da41b5f801f1ff552d8f3048ba0836872e0e341dd1de7'
original=(FROZEN/'examples/hia_bootstrap/linked_observer_packer.hiaasm').read_bytes()
old=b'{"value":282584257676671}';new=b'{"value":282584257676672}'
assert original.count(old)==1
changed=original.replace(old,new)
directory=AUDIT/'vm-source-race';directory.mkdir(exist_ok=False)
path=directory/'changing-packer.hiaasm';path.write_bytes(original)
(directory/'original-packer.hiaasm').write_bytes(original)
observer.PACKER=path
import hepta.hia_program as program
real=program.execute_program
calls=[]
def actual_then_change(*args,**kwargs):
    result=real(*args,**kwargs)
    calls.append(result)
    if len(calls)==1:
        path.write_bytes(changed)
    return result
with patch.object(program,'execute_program',actual_then_change):
    reference=observer.independent_reference(before_B0=False)
assert len(calls)==18
assert reference['packer_source_sha256']==sha256(changed).hexdigest()
(directory/'accepted-mixed-source-reference.json').write_text(json.dumps(reference,indent=2,sort_keys=True)+'\n')
rejected=False
try:
    observer.independent_reference(before_B0=False)
except AssertionError as exc:
    rejected=True
    rejection=str(exc)
assert rejected
report=dict(scope='ACTUAL_INDEPENDENT_VM_SOURCE_SNAPSHOT_COUNTEREXAMPLE',
    reviewed_source_sha256=sha256(code).hexdigest(),original_packer_sha256=sha256(original).hexdigest(),
    changed_packer_sha256=sha256(changed).hexdigest(),changed_output_byte_offset=0,
    original_output_byte=127,changed_output_byte=128,actual_VM_calls=19,
    mixed_sources_accepted=True,claimed_current_source_itself_rejected=True,rejection=rejection,
    original_source_files_unchanged=True,cold_qualification=False)
assert source.read_bytes()==code
(AUDIT/'vm-source-binding-counterexample.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,sort_keys=True),flush=True)
