"""Independent assembly, complete original VM windows, and ELF structure audit."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import struct
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'frozen'
sys.path[:0]=[str(FROZEN),'/workspace/scratch/9acdfa9f5639/native-agent-state-integration']
source=FROZEN/'tools/generate_hia_linked_observer.py';raw=source.read_bytes()
spec=importlib.util.spec_from_file_location('reviewed_linked_generator',source)
generator=importlib.util.module_from_spec(spec);exec(compile(raw,str(source),'exec'),generator.__dict__)
assert sha256(raw).hexdigest()=='ef002b124cdb6895b9cdb19734aeba8dee5f1c997c085b80fdda92f2ea23d66a'
directory=ROOT/'machine-reference';directory.mkdir(exist_ok=False)
obj=directory/'adapter.o';elf=directory/'adapter.elf';code=directory/'adapter.text.bin'
commands=[['as','--64','-o',str(obj),str(FROZEN/'tools/hia_linked_observer_template.S')],
    ['ld','-m','elf_x86_64','-nostdlib','-Ttext=0x400200','-e','_start',
     '--defsym=dlopen_slot=0x401800','--defsym=dlsym_slot=0x401808','-o',str(elf),str(obj)],
    ['objcopy','--dump-section','.text='+str(code),str(elf)]]
records=[]
for i,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,timeout=20)
    (directory/(str(i)+'.stdout')).write_bytes(result.stdout)
    (directory/(str(i)+'.stderr')).write_bytes(result.stderr)
    records.append(dict(command=command,returncode=result.returncode))
    result.check_returncode()
assert code.read_bytes()==generator.ADAPTER
image=generator.reference_image()
original=ROOT/'originals/runtime/compile-r2/linked-observer.elf'
assert image==original.read_bytes()
assert len(image)==2256
assert image[512:512+len(generator.ADAPTER)]==generator.ADAPTER
header=struct.unpack_from('<HHIQQQIHHHHHH',image,16)
assert header[:3]==(2,62,1) and header[3]==0x400200 and header[4]==64 and header[9]==7
programs=[struct.unpack_from('<IIQQQQQQ',image,64+i*56) for i in range(7)]
loads=[p for p in programs if p[0]==1]
assert loads==[(1,5,0,0x400000,0x400000,1888,1888,4096),
               (1,6,2048,0x401800,0x401800,208,2048,4096)]
assert all(p[2]%p[7]==p[3]%p[7] for p in loads)
assert not any(p[1]&1 and p[1]&2 for p in loads)
dynamic=[p for p in programs if p[0]==2][0]
records_dynamic=[struct.unpack_from('<QQ',image,dynamic[2]+i*16) for i in range(dynamic[5]//16)]
table=dict(records_dynamic)
assert table[24]==0 and table[30]&8 and table[9]==24 and table[8]==48
relocations=[struct.unpack_from('<QQq',image,table[7]-0x400000+i*24) for i in range(2)]
assert relocations==[(0x401800,(1<<32)|6,0),(0x401808,(2<<32)|6,0)]
relro=[p for p in programs if p[0]==0x6474e552][0]
assert relro[3]==0x401800 and relro[6]==2048
stack=[p for p in programs if p[0]==0x6474e551][0]
assert stack[1]==6
archive=Path('/workspace/scratch/9acdfa9f5639/native-linked-observer-next/checkpoints/stage2/native-linked-observer-stage2-development.tar.xz')
windows=[]
with tarfile.open(archive,'r:xz') as t:
    for member in ('runtime/compile-r2/independent-reference.json',
                   'runtime/tests-r2/actual/independent-reference.json'):
        reference=json.loads(t.extractfile(member).read())
        count=0
        for row in reference['vm_windows']:
            assert row['begin']==count
            result=row['result'];assert result['status']=='returned'
            assert result['values']==[len(image),*image[row['begin']:row['end']]]
            count=row['end']
        assert count==len(image) and len(reference['vm_windows'])==18
        windows.append(dict(member=member,actual_original_windows=18,bytes_compared=count,
                            before_B0=reference['before_B0']))
assert source.read_bytes()==raw
report=dict(scope='INDEPENDENT_ASSEMBLY_AND_ORIGINAL_VM_OBSERVATION_READBACK',
    commands=records,adapter_bytes=len(generator.ADAPTER),adapter_sha256=sha256(generator.ADAPTER).hexdigest(),
    independent_assembler_bytes_equal=True,complete_HIA_emitted_ELF_equal=True,
    executable_bytes=len(image),executable_sha256=sha256(image).hexdigest(),
    program_headers=programs,dynamic_records=records_dynamic,relocations=relocations,
    original_VM_references=windows,new_native_calls=0,new_VM_calls=0,cold_qualification=False)
(ROOT/'machine-reference-review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('commands','program_headers','dynamic_records','relocations')},sort_keys=True),flush=True)
