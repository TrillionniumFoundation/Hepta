"""Repeat independent source/compiler and real VM race controls on fixed r3."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import resource
import sys
import tarfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'flat-frozen-d5'
BASE=Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration')
sys.path[:0]=[str(FROZEN),str(BASE)]
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
source=ROOT/'flat-fixed-r3/tools/hia_selfhost_native_observer.py';code=source.read_bytes()
assert sha256(code).hexdigest()=='d9102d22083f88fde3f1d2c09d8602cfc03f4c219382796864b308ff1597c610'
spec=importlib.util.spec_from_file_location('linked_observer_fixed_r3',source)
observer=importlib.util.module_from_spec(spec);exec(compile(code,str(source),'exec'),observer.__dict__)
packer_bytes=(FROZEN/'examples/hia_bootstrap/native_observer_packer.hiaasm').read_bytes()
compiler_bytes=Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin').read_bytes()
reference=json.loads(Path('/dev/shm/hia-original-flat-binding-probes/accepted-mixed-source-reference.json').read_text())
reference['packer_source_sha256']=sha256(packer_bytes).hexdigest()
from tools import qualify_hia_selfhost as qualify
real_compile,real_invoke=qualify.compile_stage,qualify.invoke
directory=Path('/dev/shm/hia-flat-observer-independent-recheck-r3');directory.mkdir(exist_ok=False)
outcomes=[]
for target in ('packer_source','compiler'):
    case=directory/target;case.mkdir()
    packer=case/'packer.hiaasm';packer.write_bytes(packer_bytes)
    compiler=case/'compiler.image.bin';compiler.write_bytes(compiler_bytes)
    observer.PACKER=packer
    mutation=packer if target=='packer_source' else compiler
    observed=[]
    def native_call(*args,**kwargs):
        result=real_invoke(*args,**kwargs);observed.append(args[1]);return result
    def compile_then_change(*args,**kwargs):
        value=real_compile(*args,**kwargs)
        mutation.write_bytes(mutation.read_bytes()+b'\n')
        return value
    with patch.object(qualify,'compile_stage',compile_then_change),patch.object(qualify,'invoke',native_call):
        try:
            observer.build(case,compiler,reference)
        except AssertionError as exc:
            error=str(exc)
        else:
            raise AssertionError('changed actual build inputs were accepted')
    assert error=='native observer source or compiler changed during build'
    assert observed==['native-observer-packer']
    assert not (case/'native-observer.elf').exists()
    assert not (case/'native-observer-build.json').exists()
    outcomes.append(dict(name=target,refused=True,error=error,actual_native_calls=observed,
                         executable_published=False,success_receipt_published=False))
# No compiler should execute when a previously produced reference names a
# different current source; this is a separate pure admission control.
case=directory/'reference_mismatch';case.mkdir()
packer=case/'packer.hiaasm';packer.write_bytes(packer_bytes+b'\n')
compiler=case/'compiler.image.bin';compiler.write_bytes(compiler_bytes)
observer.PACKER=packer
invocations=[]
def forbidden_compile(*args,**kwargs):
    invocations.append(True);raise AssertionError('compile before reference binding')
with patch.object(qualify,'compile_stage',forbidden_compile):
    try:
        observer.build(case,compiler,reference)
    except AssertionError as exc:
        error=str(exc)
    else:
        raise AssertionError('mismatched source was accepted')
assert not invocations and error=='native observer reference source differs from compilation input'
outcomes.append(dict(name='reference_mismatch',refused=True,error=error,actual_native_calls=[]))
# The exact earlier VM witness changes the ELF's already-observed byte zero.
case=directory/'vm_source';case.mkdir()
packer=case/'packer.hiaasm';packer.write_bytes(packer_bytes)
observer.PACKER=packer
changed=packer_bytes.replace(b'{"value":282584257676671}',b'{"value":282584257676672}')
import hepta.hia_program as program
real_VM=program.execute_program
VM_calls=[]
def actual_VM_then_change(*args,**kwargs):
    result=real_VM(*args,**kwargs);VM_calls.append(result)
    if len(VM_calls)==1:packer.write_bytes(changed)
    return result
with patch.object(program,'execute_program',actual_VM_then_change):
    try:
        observer.independent_reference()
    except AssertionError as exc:
        error=str(exc)
    else:
        raise AssertionError('mixed-source VM reference was accepted')
assert len(VM_calls)==9 and error=='native observer reference source changed during VM observation'
(case/'actual_VM_results.json').write_text(json.dumps(VM_calls,indent=2,sort_keys=True)+'\n')
outcomes.append(dict(name='VM_source_race',refused=True,error=error,actual_VM_calls=9,
                     source_snapshot_used_for_all_windows=True,success_reference_published=False))
assert source.read_bytes()==code
report=dict(scope='INDEPENDENT_FLAT_FIXED_D910_SAME_REAL_COUNTEREXAMPLE_RECHECK',passed=True,
    reviewed_source_sha256=sha256(code).hexdigest(),outcomes=outcomes,
    native_compiler_calls=2,native_emitter_calls=0,actual_VM_calls=9,
    original_stage2_counterexamples_preserved=True,cold_qualification=False)
(ROOT/'flat-fixed-r3-recheck.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,sort_keys=True),flush=True)
