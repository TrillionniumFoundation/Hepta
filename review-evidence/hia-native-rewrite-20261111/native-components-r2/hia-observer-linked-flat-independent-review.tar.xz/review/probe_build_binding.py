"""Independent real-build evidence for source/compiler receipt custody.

Only copies owned by this audit are mutated. The reviewed source and all
original compiler/image files remain unchanged. No cold qualification is run.
"""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import resource
import sys
import tarfile
from unittest.mock import patch

AUDIT=Path(__file__).resolve().parent
FROZEN=AUDIT/'frozen'
BASE=Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration')
sys.path.insert(0,str(BASE))
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
source=FROZEN/'tools/hia_selfhost_linked_observer.py'
raw=source.read_bytes()
spec=importlib.util.spec_from_file_location('reviewed_linked_observer',source)
observer=importlib.util.module_from_spec(spec)
exec(compile(raw,str(source),'exec'),observer.__dict__)
assert sha256(raw).hexdigest()=='fbe91da76e46c5ce5c0da41b5f801f1ff552d8f3048ba0836872e0e341dd1de7'
archive=Path('/workspace/scratch/9acdfa9f5639/native-linked-observer-next/checkpoints/stage2/native-linked-observer-stage2-development.tar.xz')
with tarfile.open(archive,'r:xz') as t:
    reference=json.loads(t.extractfile('runtime/compile-r2/independent-reference.json').read())
from tools import qualify_hia_selfhost as qualify
real_compile=qualify.compile_stage
packer_source=(FROZEN/'examples/hia_bootstrap/linked_observer_packer.hiaasm').read_bytes()
compiler_source=Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin').read_bytes()
assert sha256(compiler_source).hexdigest()=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
destination=Path('/dev/shm/hia-linked-observer-independent-probes')
destination.mkdir(exist_ok=False)
rows=[]
for target in ('packer_source','compiler'):
    directory=destination/target;directory.mkdir()
    packer=directory/'packer.hiaasm';packer.write_bytes(packer_source)
    compiler=directory/'compiler.image.bin';compiler.write_bytes(compiler_source)
    observer.PACKER=packer
    mutation=packer if target=='packer_source' else compiler
    calls=[]
    def after_actual_compile(*args,**kwargs):
        value=real_compile(*args,**kwargs)
        calls.append(value[1])
        mutation.write_bytes(mutation.read_bytes()+b'\n')
        return value
    with patch.object(qualify,'compile_stage',after_actual_compile):
        image,receipt=observer.build(directory,compiler,reference)
    assert len(calls)==1
    assert sha256(image.read_bytes()).hexdigest()==reference['expected_image_sha256']
    observed=receipt['source_sha256'] if target=='packer_source' else receipt['compiler_sha256']
    real=receipt['native_compilation']['input_sha256' if target=='packer_source' else 'image_sha256']
    assert observed!=real
    rows.append(dict(target=target,build_accepted=True,actual_compiled_sha256=real,
        top_receipt_sha256=observed,top_receipt_matches_actual=False,
        emitted_executable_sha256=sha256(image.read_bytes()).hexdigest(),
        raw_directory=str(directory),original_reviewed_source_changed=False))
assert source.read_bytes()==raw
report=dict(scope='DEVELOPMENT_ACTUAL_COMPILE_CUSTODY_COUNTEREXAMPLES',
    reviewed_source_sha256=sha256(raw).hexdigest(),cases=rows,
    native_compiler_calls=2,native_emitter_calls=2,cold_qualification=False)
(AUDIT/'build-binding-counterexamples.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,sort_keys=True),flush=True)
