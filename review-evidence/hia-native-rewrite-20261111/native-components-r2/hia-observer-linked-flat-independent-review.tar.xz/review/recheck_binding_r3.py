"""Repeat independent source/compiler and real VM race controls on fixed r3."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import resource
import sys
import tarfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'frozen'
BASE=Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration')
sys.path[:0]=[str(FROZEN),str(BASE)]
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
source=ROOT/'fixed-r3/tools/hia_selfhost_linked_observer.py';code=source.read_bytes()
assert sha256(code).hexdigest()=='6729fe69c56ea02789ed5a53bcf17a701606b3145c60f8cd46a80f467a75a670'
spec=importlib.util.spec_from_file_location('linked_observer_fixed_r3',source)
observer=importlib.util.module_from_spec(spec);exec(compile(code,str(source),'exec'),observer.__dict__)
packer_bytes=(FROZEN/'examples/hia_bootstrap/linked_observer_packer.hiaasm').read_bytes()
compiler_bytes=Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin').read_bytes()
archive=Path('/workspace/scratch/9acdfa9f5639/native-linked-observer-next/checkpoints/stage2/native-linked-observer-stage2-development.tar.xz')
with tarfile.open(archive,'r:xz') as t:
    reference=json.loads(t.extractfile('runtime/compile-r2/independent-reference.json').read())
from tools import qualify_hia_selfhost as qualify
real_compile,real_invoke=qualify.compile_stage,qualify.invoke
directory=Path('/dev/shm/hia-linked-observer-independent-recheck-r3');directory.mkdir(exist_ok=False)
outcomes=[]
for target in ('packer_source','compiler'):
    case=directory/target;case.mkdir()
    packer=case/'packer.hiaasm';packer.write_bytes(packer_bytes)
    compiler=case/'compiler.image.bin';compiler.write_bytes(compiler_bytes)
    observer.PACKER=packer
    mutation=packer if target=='packer_source' else compiler
    observed=[]
    def native_call(*args,**kwargs):
        result=real_invoke(*args,**kwargs);observed.append(args[1]);return result
    def compile_then_change(*args,**kwargs):
        value=real_compile(*args,**kwargs)
        mutation.write_bytes(mutation.read_bytes()+b'\n')
        return value
    with patch.object(qualify,'compile_stage',compile_then_change),patch.object(qualify,'invoke',native_call):
        try:
            observer.build(case,compiler,reference)
        except AssertionError as exc:
            error=str(exc)
        else:
            raise AssertionError('changed actual build inputs were accepted')
    assert error=='linked observer source or compiler changed during build'
    assert observed==['linked-observer-packer']
    assert not (case/'linked-observer.elf').exists()
    assert not (case/'linked-observer-build.json').exists()
    outcomes.append(dict(name=target,refused=True,error=error,actual_native_calls=observed,
                         executable_published=False,success_receipt_published=False))
# No compiler should execute when a previously produced reference names a
# different current source; this is a separate pure admission control.
case=directory/'reference_mismatch';case.mkdir()
packer=case/'packer.hiaasm';packer.write_bytes(packer_bytes+b'\n')
compiler=case/'compiler.image.bin';compiler.write_bytes(compiler_bytes)
observer.PACKER=packer
invocations=[]
def forbidden_compile(*args,**kwargs):
    invocations.append(True);raise AssertionError('compile before reference binding')
with patch.object(qualify,'compile_stage',forbidden_compile):
    try:
        observer.build(case,compiler,reference)
    except AssertionError as exc:
        error=str(exc)
    else:
        raise AssertionError('mismatched source was accepted')
assert not invocations and error=='linked observer reference source differs from compilation input'
outcomes.append(dict(name='reference_mismatch',refused=True,error=error,actual_native_calls=[]))
# The exact earlier VM witness changes the ELF's already-observed byte zero.
case=directory/'vm_source';case.mkdir()
packer=case/'packer.hiaasm';packer.write_bytes(packer_bytes)
observer.PACKER=packer
changed=packer_bytes.replace(b'{"value":282584257676671}',b'{"value":282584257676672}')
import hepta.hia_program as program
real_VM=program.execute_program
VM_calls=[]
def actual_VM_then_change(*args,**kwargs):
    result=real_VM(*args,**kwargs);VM_calls.append(result)
    if len(VM_calls)==1:packer.write_bytes(changed)
    return result
with patch.object(program,'execute_program',actual_VM_then_change):
    try:
        observer.independent_reference(before_B0=False)
    except AssertionError as exc:
        error=str(exc)
    else:
        raise AssertionError('mixed-source VM reference was accepted')
assert len(VM_calls)==18 and error=='linked observer reference source changed during VM observation'
(case/'actual_VM_results.json').write_text(json.dumps(VM_calls,indent=2,sort_keys=True)+'\n')
outcomes.append(dict(name='VM_source_race',refused=True,error=error,actual_VM_calls=18,
                     source_snapshot_used_for_all_windows=True,success_reference_published=False))
assert source.read_bytes()==code
report=dict(scope='INDEPENDENT_FIXED_R3_SAME_REAL_COUNTEREXAMPLE_RECHECK',passed=True,
    reviewed_source_sha256=sha256(code).hexdigest(),outcomes=outcomes,
    native_compiler_calls=2,native_emitter_calls=0,actual_VM_calls=18,
    original_stage2_counterexamples_preserved=True,cold_qualification=False)
(ROOT/'fixed-r3-recheck.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,sort_keys=True),flush=True)
