# Independent linked and flat observer review

This review is bound to the exact source copies and actual invocations in this directory. It is development evidence. It does not establish cold qualification, whole-language closure, or a guaranteed reduction in the 180-second qualification time.

## Outcome

The original linked observer had two reproducible source-custody defects. The same defects were present in the existing flat observer. Both have been corrected in the reviewed revisions: linked `6729fe69c56ea02789ed5a53bcf17a701606b3145c60f8cd46a80f467a75a670` and flat `d9102d22083f88fde3f1d2c09d8602cfc03f4c219382796864b308ff1597c610`. Repeating the original experiments against each correction now rejects the changed input and publishes no successful proof. No further blocker was identified in the reviewed linked machine code, framing, or fixed closed-object invocation boundary.

The original linked host source is `fbe91da76e46c5ce5c0da41b5f801f1ff552d8f3048ba0836872e0e341dd1de7`. The original flat host source is `629722f68a712889b6b0dde2fdf8fafd739fd63ea5c6537b8b969cae320225e6` from `d5da1eb760454ef3df5153c5e80eb046ddb389d9`. The affected flat functions are also structurally identical to the retained v64 reference, so these findings are not attributable to the later pure byte-copy/hash optimization.

## Actual counterexamples and exact rechecks

The build experiment invokes the real retained B3 compiler. Immediately after the real compilation returns, an audit-owned copy of either the packer source or compiler is changed. The original builder subsequently emits the correct executable but labels its top-level receipt with the changed file's hash. Two real compile and two real emit calls establish this for each original observer. The nested actual compilation receipt and the published top-level receipt disagree. No native output was mocked or replaced.

The VM experiment changes the first emitted ELF byte after the first real VM window. The original reference routine rereads source for every later window. It therefore accepts a reference assembled from two source revisions and labels it with the last revision, although running that final source consistently rejects at window zero. Linked required 18 accepted windows plus one rejecting control; flat required nine plus one. Full accepted references, the two source revisions, rejection output, and probe scripts are retained.

Against each fixed builder, the same two actual compilation races reject before emission. Neither an executable nor a success receipt is published. A source-mismatched reference also rejects before any native call. Against each fixed reference routine, all windows use the original captured source, and the final disk reread detects the mutation and refuses publication. These checks use 18 actual VM windows for linked and nine for flat. Their terminal summaries are `fixed-r3-recheck.json` and `flat-fixed-r3-recheck.json`.

Across these independent experiments there are eight real compiler calls, four real emitter calls, and 56 real VM calls. These counts exclude the original author's test suite and the separate readback of retained VM observations. Original accepted counterexamples are preserved separately from fixed refusals.

## Machine code, ELF, and invocation boundary

The entire original development package was read and checked: 919 archive members, 21,667,030 raw bytes, with byte hashes and modes. The six original source copies and package identities are in `input-custody.json`.

An independent assembler/linker/section extraction of the frozen assembly produced the exact 1,198-byte adapter embedded by the HIA generator, SHA-256 `13539a127998da4cc139a4031feb367f61977ab3a6d992d5c1f0ae91c4884d15`. Reconstructing the complete reference ELF matches the actual HIA-emitted 2,256-byte executable, SHA-256 `95dbe2af13367b9a54655f80e535364c3769d42ba1f1f558d955e2015e37796c`. Both original complete VM references were read window by window, covering all 2,256 bytes each. These readback and assembler checks did not execute an additional native image or VM program.

The reviewed executable has separate RX and RW virtual mappings, immediate dynamic binding, RELRO for the writable import slots, and a non-executable stack. The two GLOB_DAT relocations match the fixed dlopen/dlsym slots. Segment file/virtual offsets satisfy page congruence. The distinct mappings share a file page without sharing a writable executable virtual mapping.

The entry validates the complete request extent and each bounded field before computing offsets. Its bounds prevent arithmetic wrap in the combined input. It seals and verifies the supplied object before `dlopen(RTLD_NOW)`, resolves `f0`, invokes the six-argument native ABI, and uses a fresh process for each observation. The parent retains full returned framing, actual elapsed time, trap output and signal evidence, and final source/image/executable disk rereads. The existing CPU, address-space, stack, file-size, file-descriptor, and wall limits remain in the reviewed code.

## Scope and limits

This is an invocation adapter for the already-inspected linked-selfhost closed-object profile. It is not a universal equivalence claim for arbitrary foreign shared libraries whose constructors inspect process environment, open descriptors, or loader state. The reviewed documentation records that boundary. The additional sealed observer descriptor and different private loader-failure exits are not hidden as arbitrary-library equivalence.

The seed/B0 loader remains independent. The native HIA packer and emitted ELF bytes did not change in the custody repair. Complete cold qualification, all source/native suites, and any timing benefit remain separate integration gates owned by the parent task. No limits, cases, native clocks, fresh-process isolation, or proof checks were removed by this review or its probe scripts.

All writes were restricted to audit-owned copies and evidence. Neither the frozen original candidate nor the parent's integration source was edited by this reviewer.
