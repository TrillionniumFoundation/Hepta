"""Confirm the same pre-existing flat-observer custody defect on exact d5.

The two affected functions are AST-identical to the retained v64 reference.
Only audit-owned input copies are changed. The exact d5 production is read-only.
"""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import resource
import sys
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'flat-frozen-d5'
BASE=Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration')
sys.path[:0]=[str(FROZEN),str(BASE)]
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
source=FROZEN/'tools/hia_selfhost_native_observer.py';code=source.read_bytes()
spec=importlib.util.spec_from_file_location('reviewed_original_flat',source)
observer=importlib.util.module_from_spec(spec);exec(compile(code,str(source),'exec'),observer.__dict__)
assert sha256(code).hexdigest()=='629722f68a712889b6b0dde2fdf8fafd739fd63ea5c6537b8b969cae320225e6'
original=(FROZEN/'examples/hia_bootstrap/native_observer_packer.hiaasm').read_bytes()
assert original.count(b'{"value":282584257676671}')==1
changed=original.replace(b'{"value":282584257676671}',b'{"value":282584257676672}')
directory=Path('/dev/shm/hia-original-flat-binding-probes');directory.mkdir(exist_ok=False)
packer=directory/'changing-packer.hiaasm';packer.write_bytes(original)
observer.PACKER=packer
import hepta.hia_program as program
real_VM=program.execute_program
calls=[]
def VM_then_change(*args,**kwargs):
    result=real_VM(*args,**kwargs);calls.append(result)
    if len(calls)==1:packer.write_bytes(changed)
    return result
with patch.object(program,'execute_program',VM_then_change):
    mixed=observer.independent_reference()
assert len(calls)==9
assert mixed['packer_source_sha256']==sha256(changed).hexdigest()
(directory/'accepted-mixed-source-reference.json').write_text(json.dumps(mixed,indent=2,sort_keys=True)+'\n')
try:
    observer.independent_reference()
except AssertionError as exc:
    failed=str(exc)
else:
    raise AssertionError('modified byte-zero packer did not fail a fixed reference')
assert failed=='independent VM did not reproduce exact observer ELF window'
rows=[dict(name='mixed_VM_sources',accepted=True,actual_VM_calls=10,
    claimed_current_source_itself_rejected=True,changed_byte_offset=0,
    original_packer_sha256=sha256(original).hexdigest(),changed_packer_sha256=sha256(changed).hexdigest())]
from tools import qualify_hia_selfhost as qualify
real_compile=qualify.compile_stage
compiler_bytes=Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin').read_bytes()
reference=dict(mixed,packer_source_sha256=sha256(original).hexdigest())
for target in ('packer_source','compiler'):
    case=directory/target;case.mkdir()
    packer=case/'packer.hiaasm';packer.write_bytes(original)
    compiler=case/'compiler.image.bin';compiler.write_bytes(compiler_bytes)
    observer.PACKER=packer
    mutation=packer if target=='packer_source' else compiler
    def native_compile_then_change(*args,**kwargs):
        value=real_compile(*args,**kwargs);mutation.write_bytes(mutation.read_bytes()+b'\n');return value
    with patch.object(qualify,'compile_stage',native_compile_then_change):
        executable,receipt=observer.build(case,compiler,reference)
    stated=receipt['source_sha256' if target=='packer_source' else 'compiler_sha256']
    actual=receipt['native_compilation']['input_sha256' if target=='packer_source' else 'image_sha256']
    assert stated!=actual
    assert sha256(executable.read_bytes()).hexdigest()==reference['expected_image_sha256']
    rows.append(dict(name=target,accepted=True,top_receipt_sha256=stated,
        actual_compilation_sha256=actual,top_receipt_matches_actual=False,
        actual_emitted_executable_sha256=sha256(executable.read_bytes()).hexdigest()))
assert source.read_bytes()==code
assert (BASE/'tools/hia_selfhost_native_observer.py').read_bytes()==code
report=dict(scope='CONFIRMED_PREEXISTING_FLAT_OBSERVER_BINDING_DEFECT',
    base='d5da1eb760454ef3df5153c5e80eb046ddb389d9',source_sha256=sha256(code).hexdigest(),
    affected_functions_equal_retained_v64_reference=True,outcomes=rows,
    actual_VM_calls=10,native_compiler_calls=2,native_emitter_calls=2,
    original_source_files_unchanged=True,cold_qualification=False)
(ROOT/'original-flat-binding-counterexamples.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,sort_keys=True),flush=True)
