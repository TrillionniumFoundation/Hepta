"""Complete native response, descriptor DAG, and issued-ID commit owner."""
from __future__ import annotations

BODY = r'''
def reply_entry(c:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < CONTROL_BYTES or length(o) < 128:
        return poison(w, 1)
    if get(w, S_BROKEN) != 0:
        return BAD
    if get(w, S_MAGIC) != STATE_MAGIC or length(c) < 128:
        return poison(w, 50)
    if read(c, 0) != REPLY_MAGIC or read(c, 8) != get(w, S_LEASE):
        return poison(w, 51)
    if read(c, 16) != get(w, S_PENDING_SEQ) or read(c, 24) != get(w, S_PENDING_OP):
        return poison(w, 52)
    if read(c, 32) != get(w, S_PENDING_REQUEST) or read(c, 40) != length(c) - 64:
        return poison(w, 53)
    if read(c, 48) != 0 or read(c, 56) != 0 or read(c, 40) > FRAME_LIMIT:
        return poison(w, 54)
    phase = get(w, S_PHASE)
    if phase != 1 and phase != 19 and phase != 20 and phase != 21 and phase != 22:
        return poison(w, 55)
    if resume_memory(w) == 0:
        return BAD
    if phase != 1 and length(c) != get(w, S_INPUT_SIZE):
        return poison(w, 56)
    if reply_header(c, w, choose(phase == 1, 0, 1)) == 0:
        return BAD
    if phase == 1:
        put(w, S_INPUT_SIZE, length(c))
        put(w, S_PHASE, 19)
    if get(w, S_PHASE) == 19:
        if json_prepare(c, w) == 0:
            if get(w, S_BROKEN) != 0:
                return BAD
            return publish(o, w, 1)
        put(w, S_JSON_POS, get(w, S_ENCODING_START))
        put(w, S_JSON_OUT_REL, get(w, S_SCRATCH_USED))
        put(w, S_JSON_AT, get(w, S_SCRATCH_USED))
        put(w, S_JSON_ROOT, get(w, S_SCRATCH_USED))
        put(w, S_JSON_DEPTH, 0)
        put(w, S_JSON_STACK_END, length(w))
        put(w, S_JSON_STRING_NODE, MAX)
        put(w, S_JSON_COMPLETE, 0)
        put(w, S_PHASE, 20)
    if get(w, S_PHASE) == 20:
        if json_scan(c, w) == 0:
            if get(w, S_BROKEN) != 0:
                return BAD
            return publish(o, w, 1)
        put(w, S_PHASE, 21)
    if get(w, S_PHASE) == 21:
        if reply_payload(w) == 0:
            if get(w, S_BROKEN) != 0:
                return BAD
            return publish(o, w, 1)
        if get(w, S_PENDING_OP) == 5 or get(w, S_PENDING_OP) == 6:
            return finish_reply(o, w)
        if prepare_pending(w) == 0:
            if get(w, S_BROKEN) != 0:
                return BAD
            return publish(o, w, 1)
        if descriptor_dag(w) == 0:
            return BAD
        commit_plan(w)
        put(w, S_PHASE, 22)
    if reserve(w, get(w, S_HEAP) + get(w, S_NEW_BYTES) + get(w, S_SCRATCH_USED), 0) == 0:
        if get(w, S_BROKEN) != 0:
            return BAD
        return publish(o, w, 1)
    if commit_descriptors(w) == 0:
        return BAD
    return finish_reply(o, w)

def reply_header(c:readbuf, w:mutbuf, repeated:u64) -> u64:
    operation = get(w, S_PENDING_OP)
    expected = TYPE_MAGIC
    if operation == 2:
        expected = PARAM_MAGIC
    elif operation == 5:
        expected = ORIGIN_MAGIC
    if read(c, 64) != expected or read(c, 120) != 0 or read(c, 88) != length(c) - 128:
        poison(w, 60)
        return 0
    error = read(c, 72)
    id = read(c, 80)
    if error != 0 and (error > 50 or id != 0):
        poison(w, 61)
        return 0
    if operation == 5 or operation == 6:
        if read(c, 96) != get(w, S_CACHED) or read(c, 104) != get(w, S_ACTIVE) or read(c, 112) != get(w, S_STEPS):
            poison(w, 62)
            return 0
    if operation == 5:
        if error != 0 and error != 1 and error != 5 and error != 6 and (error < 37 or error > 44):
            poison(w, 63)
            return 0
        if id != choose(error == 0, get(w, S_ORIGIN_COUNT), 0):
            poison(w, 64)
            return 0
    elif operation == 6:
        if error != 0 and (error < 47 or error > 50):
            poison(w, 65)
            return 0
    elif operation == 2:
        if error != 0 and error != 45 and error != 46 and error > 36:
            poison(w, 66)
            return 0
    if repeated != 0:
        if error != get(w, S_NATIVE_ERROR) or id != get(w, S_NATIVE_ID):
            poison(w, 67)
            return 0
        if read(c, 96) != get(w, S_REPLY_CACHED) or read(c, 104) != get(w, S_REPLY_ACTIVE) or read(c, 112) != get(w, S_REPLY_STEPS):
            poison(w, 68)
            return 0
    else:
        put(w, S_NATIVE_ERROR, error)
        put(w, S_NATIVE_ID, id)
        put(w, S_REPLY_CACHED, read(c, 96))
        put(w, S_REPLY_ACTIVE, read(c, 104))
        put(w, S_REPLY_STEPS, read(c, 112))
    return 1

def pairs_shape(w:mutbuf, node:u64) -> u64:
    if node == MAX or get(w, node) != 5:
        return 0
    count = get(w, node + 16)
    at = node + 24
    i = 0
    while i < count:
        if get(w, at) != 5 or get(w, at + 16) != 2 or get(w, at + 24) != 4:
            return 0
        if identifier(w, end_node(w, at + 24)) == MAX:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1

def reply_payload(w:mutbuf) -> u64:
    root = scratch_node(w, get(w, S_REPLY_REL))
    operation = get(w, S_PENDING_OP)
    if get(w, root) != 6:
        poison(w, 110)
        return 0
    if operation == 5:
        return origins_payload(w, root)
    count = choose(operation == 2, 2, 1)
    types = field(w, root, K_types)
    if get(w, root + 16) != count or types == MAX or get(w, types) != 5:
        poison(w, 111)
        return 0
    put(w, S_TYPES_REL, types - get(w, S_SCRATCH_BASE))
    if operation == 6:
        if get(w, types + 16) != 0:
            poison(w, 112)
            return 0
        return 1
    if operation == 2:
        params = field(w, root, K_params)
        if pairs_shape(w, params) == 0:
            poison(w, 113)
            return 0
        if get(w, params + 16) != get(w, S_NATIVE_ID) or (get(w, S_NATIVE_ERROR) != 0 and get(w, params + 16) != 0):
            poison(w, 114)
            return 0
        put(w, S_PARAMS_REL, params - get(w, S_SCRATCH_BASE))
        put(w, S_VIEW_KIND, 2)
        put(w, S_VIEW_COUNT, get(w, params + 16))
        put(w, S_VIEW_REL, params - get(w, S_SCRATCH_BASE))
        put(w, S_VIEW_BYTES, 16 + get(w, params + 8))
    return 1

def origins_payload(w:mutbuf, root:u64) -> u64:
    node = field(w, root, K_origins)
    count = choose(get(w, S_NATIVE_ERROR) == 0, get(w, S_ORIGIN_COUNT), 0)
    if get(w, root + 16) != 1 or node == MAX or get(w, node) != 5:
        poison(w, 115)
        return 0
    if get(w, node + 16) != count:
        poison(w, 116)
        return 0
    at = node + 24
    i = 0
    while i < count:
        if get(w, at) != 0:
            if get(w, at) != 5 or get(w, at + 16) != 2 or get(w, at + 24) != 4:
                poison(w, 117)
                return 0
            if origin_name(w, at + 24) == 0 or uint_value(w, end_node(w, at + 24), 511) == MAX:
                poison(w, 118)
                return 0
        at = end_node(w, at)
        i = i + 1
    put(w, S_VIEW_KIND, 3)
    put(w, S_VIEW_COUNT, count)
    put(w, S_VIEW_REL, node - get(w, S_SCRATCH_BASE))
    put(w, S_VIEW_BYTES, 16 + get(w, node + 8))
    return 1

def origin_name(w:mutbuf, name:u64) -> u64:
    params = scratch_node(w, get(w, S_ORIGIN_PARAMS))
    count = get(w, params + 16)
    at = params + 24
    i = 0
    while i < count:
        if same_string(w, name, at + 24) == 1:
            return 1
        at = end_node(w, at)
        i = i + 1
    return 0

def descriptor_shape(w:mutbuf, node:u64, id:u64) -> u64:
    kind_node = field(w, node, K_kind)
    kind = 0
    if word(w, kind_node, K_primitive) == 1:
        kind = 1
    elif word(w, kind_node, K_record) == 1:
        kind = 2
    elif word(w, kind_node, K_enum) == 1:
        kind = 3
    elif word(w, kind_node, K_task) == 1:
        kind = 4
    elif word(w, kind_node, K_partial_record) == 1:
        kind = 5
    if kind == 0:
        return 0
    name = field(w, node, K_name)
    if (kind == 5 and get(w, name) != 0) or (kind != 5 and get(w, name) != 4):
        return 0
    if (id <= 16 and kind != 1) or (id > 16 and kind == 1):
        return 0
    if kind == 1 and word(w, name, K_bool + id - 1) == 0:
        return 0
    if identity_vector(w, field(w, node, K_args), 4294967295) == 0:
        return 0
    if identity_vector(w, field(w, node, K_flat), 16) == 0:
        return 0
    if pairs_shape(w, field(w, node, K_fields)) == 0:
        return 0
    if variants_shape(w, field(w, node, K_variants)) == 0:
        return 0
    if optional_id(w, field(w, node, K_state)) == MAX or optional_id(w, field(w, node, K_result)) == MAX or optional_id(w, field(w, node, K_record)) == MAX:
        return 0
    if get(w, field(w, node, K_linear)) != 1:
        return 0
    poll = get(w, field(w, node, K_poll))
    cancel = get(w, field(w, node, K_cancel))
    return choose((poll == 0 or poll == 4) and (cancel == 0 or cancel == 4), 1, 0)

def identity_vector(w:mutbuf, node:u64, limit:u64) -> u64:
    if get(w, node) != 5:
        return 0
    at = node + 24
    count = get(w, node + 16)
    i = 0
    while i < count:
        id = uint_value(w, at, limit)
        if id == 0 or id == MAX:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1

def variants_shape(w:mutbuf, node:u64) -> u64:
    if get(w, node) != 5:
        return 0
    count = get(w, node + 16)
    at = node + 24
    i = 0
    while i < count:
        if get(w, at) != 5 or get(w, at + 16) != 2 or get(w, at + 24) != 4:
            return 0
        if pairs_shape(w, end_node(w, at + 24)) == 0:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1

def prepare_pending(w:mutbuf) -> u64:
    types = scratch_node(w, get(w, S_TYPES_REL))
    count = get(w, types + 16)
    capacity = table_size(count)
    base = align8(get(w, S_SCRATCH_USED))
    required = base + count * 32 + capacity * 16
    if reserve(w, scratch_node(w, required), 0) == 0:
        return 0
    put(w, S_PENDING_LIST, base)
    put(w, S_MATERIAL_ORDER, base + count * 24)
    put(w, S_PENDING_TABLE, base + count * 32)
    put(w, S_PENDING_CAP, capacity)
    put(w, S_PENDING_COUNT, count)
    zero_words(w, scratch_node(w, base), count * 32 + capacity * 16)
    at = types + 24
    i = 0
    while i < count:
        if get(w, at) != 6 or get(w, at + 16) != 13:
            poison(w, 120)
            return 0
        field_index = 0
        while field_index < 13:
            if field(w, at, K_id + field_index) == MAX:
                poison(w, 120)
                return 0
            field_index = field_index + 1
        id = identifier(w, field(w, at, K_id))
        if id == MAX or issued(w, id) != 0:
            poison(w, 121)
            return 0
        if table_insert(w, scratch_node(w, get(w, S_PENDING_TABLE)), capacity, id, i + 1) == 0:
            poison(w, 121)
            return 0
        if descriptor_shape(w, at, id) == 0:
            poison(w, 122)
            return 0
        entry = scratch_node(w, base + i * 24)
        put(w, entry, id)
        put(w, entry + 8, at - get(w, S_SCRATCH_BASE))
        at = end_node(w, at)
        i = i + 1
    put(w, S_SCRATCH_USED, required)
    return 1

def reference_ready(w:mutbuf, id:u64) -> u64:
    if id == 0 or issued(w, id) != 0:
        return 1
    index = table_find(w, scratch_node(w, get(w, S_PENDING_TABLE)), get(w, S_PENDING_CAP), id)
    if index == 0:
        return 0
    return get(w, scratch_node(w, get(w, S_PENDING_LIST) + (index - 1) * 24) + 16)

def vector_ready(w:mutbuf, node:u64) -> u64:
    count = get(w, node + 16)
    at = node + 24
    i = 0
    while i < count:
        if reference_ready(w, identifier(w, at)) == 0:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1

def fields_ready(w:mutbuf, node:u64) -> u64:
    count = get(w, node + 16)
    at = node + 24
    i = 0
    while i < count:
        if reference_ready(w, identifier(w, end_node(w, at + 24))) == 0:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1

def descriptor_ready(w:mutbuf, node:u64) -> u64:
    if vector_ready(w, field(w, node, K_args)) == 0 or fields_ready(w, field(w, node, K_fields)) == 0:
        return 0
    variants = field(w, node, K_variants)
    count = get(w, variants + 16)
    at = variants + 24
    i = 0
    while i < count:
        if fields_ready(w, end_node(w, at + 24)) == 0:
            return 0
        at = end_node(w, at)
        i = i + 1
    if reference_ready(w, optional_id(w, field(w, node, K_state))) == 0:
        return 0
    if reference_ready(w, optional_id(w, field(w, node, K_result))) == 0:
        return 0
    return reference_ready(w, optional_id(w, field(w, node, K_record)))

def descriptor_dag(w:mutbuf) -> u64:
    count = get(w, S_PENDING_COUNT)
    done = 0
    while done < count:
        progressed = 0
        i = 0
        while i < count:
            entry = scratch_node(w, get(w, S_PENDING_LIST) + i * 24)
            if get(w, entry + 16) == 0:
                if descriptor_ready(w, scratch_node(w, get(w, entry + 8))) == 1:
                    put(w, entry + 16, 1)
                    put(w, scratch_node(w, get(w, S_MATERIAL_ORDER) + done * 8), i)
                    done = done + 1
                    progressed = 1
            i = i + 1
        if progressed == 0:
            poison(w, 123)
            return 0
    put(w, S_PENDING_DONE, done)
    return 1

def commit_plan(w:mutbuf) -> u64:
    count = get(w, S_PENDING_COUNT)
    bytes = 0
    i = 0
    while i < count:
        entry = scratch_node(w, get(w, S_PENDING_LIST) + i * 24)
        node = scratch_node(w, get(w, entry + 8))
        bytes = bytes + align8(16 + get(w, node + 8))
        i = i + 1
    capacity = table_size(get(w, S_COUNT) + count)
    table_bytes = choose(capacity > get(w, S_CAPACITY), capacity * 16, 0)
    put(w, S_PLAN_TABLE_CAP, capacity)
    put(w, S_PLAN_TABLE_BYTES, table_bytes)
    put(w, S_NEW_BYTES, bytes + table_bytes)
    return 0

def copy_table(w:mutbuf, table:u64, capacity:u64) -> u64:
    old = get(w, S_TABLE)
    count = get(w, S_CAPACITY)
    i = 0
    while i < count:
        id = get(w, old + i * 16)
        if id != 0:
            if table_insert(w, table, capacity, id, get(w, old + i * 16 + 8)) == 0:
                poison(w, 124)
                return 0
        i = i + 1
    return 1

def commit_descriptors(w:mutbuf) -> u64:
    old = get(w, S_HEAP)
    new = old + get(w, S_NEW_BYTES)
    move_bytes(w, new, get(w, S_SCRATCH_BASE), get(w, S_SCRATCH_USED))
    put(w, S_SCRATCH_BASE, new)
    table = get(w, S_TABLE)
    capacity = get(w, S_CAPACITY)
    if get(w, S_PLAN_TABLE_BYTES) != 0:
        table = new - get(w, S_PLAN_TABLE_BYTES)
        capacity = get(w, S_PLAN_TABLE_CAP)
        zero_words(w, table, get(w, S_PLAN_TABLE_BYTES))
        if copy_table(w, table, capacity) == 0:
            return 0
    count = get(w, S_PENDING_COUNT)
    cursor = old
    i = 0
    while i < count:
        index = get(w, scratch_node(w, get(w, S_MATERIAL_ORDER) + i * 8))
        entry = scratch_node(w, get(w, S_PENDING_LIST) + index * 24)
        node = scratch_node(w, get(w, entry + 8))
        size = 16 + get(w, node + 8)
        move_bytes(w, cursor, node, size)
        if table_insert(w, table, capacity, get(w, entry), cursor) == 0:
            poison(w, 125)
            return 0
        cursor = cursor + align8(size)
        i = i + 1
    put(w, S_HEAP, new)
    put(w, S_TABLE, table)
    put(w, S_CAPACITY, capacity)
    put(w, S_COUNT, get(w, S_COUNT) + count)
    return 1

def parameter_ids_issued(w:mutbuf) -> u64:
    params = scratch_node(w, get(w, S_PARAMS_REL))
    count = get(w, params + 16)
    at = params + 24
    i = 0
    while i < count:
        if issued(w, identifier(w, end_node(w, at + 24))) == 0:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1

def finish_reply(o:mutbuf, w:mutbuf) -> u64:
    operation = get(w, S_PENDING_OP)
    if operation == 2 and parameter_ids_issued(w) == 0:
        return poison(w, 126)
    put(w, S_CACHED, get(w, S_REPLY_CACHED))
    put(w, S_ACTIVE, get(w, S_REPLY_ACTIVE))
    put(w, S_STEPS, get(w, S_REPLY_STEPS))
    put(w, S_OUT_ID, get(w, S_NATIVE_ID))
    put(w, S_OUT_KIND, 0)
    put(w, S_OUT_COUNT, 0)
    put(w, S_OUT_PTR, 0)
    put(w, S_OUT_BYTES, 0)
    if get(w, S_NATIVE_ERROR) == 0:
        if operation == 1:
            if get(w, S_NATIVE_ID) != 0:
                return poison(w, 127)
        elif operation == 2 or operation == 5:
            put(w, S_OUT_KIND, get(w, S_VIEW_KIND))
            put(w, S_OUT_COUNT, get(w, S_VIEW_COUNT))
            put(w, S_OUT_PTR, scratch_node(w, get(w, S_VIEW_REL)))
            put(w, S_OUT_BYTES, get(w, S_VIEW_BYTES))
        else:
            if issued(w, get(w, S_NATIVE_ID)) == 0:
                return poison(w, 128)
            # A private fixed control word is a complete one-ID result view.
            put(w, 2048, get(w, S_NATIVE_ID))
            put(w, S_OUT_KIND, 1)
            put(w, S_OUT_COUNT, 1)
            put(w, S_OUT_PTR, 2048)
            put(w, S_OUT_BYTES, 8)
    put(w, S_COMPLETED_SEQ, get(w, S_PENDING_SEQ))
    put(w, S_PHASE, 2)
    return publish(o, w, 0)
'''
