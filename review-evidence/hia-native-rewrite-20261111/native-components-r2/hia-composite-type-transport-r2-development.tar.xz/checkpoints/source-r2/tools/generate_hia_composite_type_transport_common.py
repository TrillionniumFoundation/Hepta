"""Shared HIA state and packet operations for the complete type transport.

New development authoring. The Python code only constructs HIA source; it does
not validate a live descriptor, choose a type identity, or perform a transaction.
"""
from __future__ import annotations

PRIMITIVES = ('bool', 'unit', 'i8', 'i16', 'i32', 'i64', 'u8', 'u16',
              'u32', 'u64', 'isize', 'usize', 'buffer', 'readbuf', 'mutbuf', 'chain')
WORDS = ('op', 'init', 'parameters', 'resolve', 'partial', 'origins',
         'task_protocol', 'params', 'returns', 'base', 'task', 'functions',
         'types', 'id', 'kind', 'name', 'args', 'flat', 'fields', 'variants',
         'state', 'result', 'poll', 'cancel', 'linear', 'record',
         'primitive', 'enum', 'partial_record') + PRIMITIVES
CONSTANTS = {
    'BEGIN_MAGIC': int.from_bytes(b'HIATRB01', 'little'),
    'REPLY_MAGIC': int.from_bytes(b'HIATRR01', 'little'),
    'QUERY_MAGIC': int.from_bytes(b'HIATRQ01', 'little'),
    'EVENT_MAGIC': int.from_bytes(b'HIATRE01', 'little'),
    'STATE_MAGIC': int.from_bytes(b'HIATRS01', 'little'),
    'TYPE_MAGIC': int.from_bytes(b'HIATYP01', 'little'),
    'ORIGIN_MAGIC': int.from_bytes(b'HIALOR01', 'little'),
    'PARAM_MAGIC': int.from_bytes(b'HIAPRM01', 'little'),
    'BAD': 0xfffffffd, 'MAX': (1 << 64) - 1,
    'PACKET_LIMIT': 64 << 20, 'FRAME_LIMIT': 64 << 20,
    'COMMAND_LIMIT': (8 << 20) + 128, 'CONTROL_BYTES': 4096,
}
FIELDS = (
    'MAGIC', 'BROKEN', 'REASON', 'PHASE', 'LEASE', 'COMPLETED_SEQ',
    'QUERY_SEQ', 'PENDING_SEQ', 'PENDING_OP', 'PENDING_REQUEST',
    'CACHED', 'ACTIVE', 'STEPS', 'HEAP', 'TABLE', 'CAPACITY', 'COUNT',
    'SCRATCH_BASE', 'SCRATCH_USED', 'COMMAND_REL', 'COMMAND_SIZE',
    'INPUT_SIZE', 'INPUT_KIND', 'RETRY', 'MEMORY_BYTES',
    'ORIGIN_COUNT', 'ORIGIN_PARAMS', 'NATIVE_ERROR', 'NATIVE_ID',
    'REPLY_CACHED', 'REPLY_ACTIVE', 'REPLY_STEPS', 'REPLY_REL', 'REPLY_SIZE',
    'OUT_OP', 'OUT_REQUEST', 'OUT_SEQ', 'OUT_ID', 'OUT_KIND', 'OUT_COUNT',
    'OUT_PTR', 'OUT_BYTES', 'GROW', 'PENDING_LIST', 'PENDING_COUNT',
    'PENDING_TABLE', 'PENDING_CAP', 'MATERIAL_ORDER', 'PENDING_DONE',
    'NEW_BYTES', 'JSON_POS', 'JSON_OUT_REL', 'JSON_AT', 'JSON_DEPTH',
    'JSON_STACK_END', 'JSON_STRING_NODE', 'JSON_STRING_KEY', 'JSON_COMPLETE',
    'JSON_ROOT', 'VIEW_KIND', 'VIEW_COUNT', 'VIEW_REL', 'VIEW_BYTES',
    'VALID_BASE', 'VALID_BYTES', 'PLAN_TABLE_CAP', 'PLAN_TABLE_BYTES',
    'TYPES_REL', 'PARAMS_REL', 'JSON_NEGATIVE', 'JSON_NUMBER_KIND',
    'ENCODING_KIND', 'ENCODING_REL', 'ENCODING_BYTES', 'ENCODING_START',
)
CONSTANTS.update({'S_' + name: index * 8 for index, name in enumerate(FIELDS)})
CONSTANTS.update({'K_' + word: index + 1 for index, word in enumerate(WORDS)})

COMMON = r'''
def read(s:readbuf, at:u64) -> u64:
    value = 0
    shift = 0
    while shift < 64:
        value = value | (widen(byte(s, at + (shift >> 3))) << shift)
        shift = shift + 8
    return value

def get(w:mutbuf, at:u64) -> u64:
    value = 0
    shift = 0
    while shift < 64:
        value = value | (widen(byte(w, at + (shift >> 3))) << shift)
        shift = shift + 8
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    shift = 0
    while shift < 64:
        store(w, at + (shift >> 3), value >> shift)
        shift = shift + 8
    return 0

def widen(value:u64) -> u64:
    return value

def poison(w:mutbuf, reason:u64) -> u64:
    if length(w) >= CONTROL_BYTES:
        put(w, S_MAGIC, STATE_MAGIC)
        put(w, S_BROKEN, 1)
        put(w, S_REASON, reason)
    return BAD

def align8(value:u64) -> u64:
    return (value + 7) & 18446744073709551608

def publish(o:mutbuf, w:mutbuf, action:u64) -> u64:
    put(o, 0, EVENT_MAGIC)
    put(o, 8, action)
    put(o, 16, get(w, S_LEASE))
    put(o, 24, get(w, S_OUT_SEQ))
    put(o, 32, get(w, S_OUT_REQUEST))
    put(o, 40, get(w, S_OUT_OP))
    put(o, 48, choose(action == 0, get(w, S_NATIVE_ERROR), 0))
    put(o, 56, choose(action == 0, get(w, S_OUT_ID), 0))
    put(o, 64, get(w, S_CACHED))
    put(o, 72, get(w, S_ACTIVE))
    put(o, 80, get(w, S_STEPS))
    put(o, 88, choose(action == 0, get(w, S_OUT_KIND), 0))
    put(o, 96, choose(action == 0, get(w, S_OUT_COUNT), 0))
    put(o, 104, choose(action == 0, get(w, S_OUT_PTR), 0))
    put(o, 112, choose(action == 0, get(w, S_OUT_BYTES), 0))
    put(o, 120, choose(action == 1, get(w, S_GROW), 0))
    return 128

def clear_result(w:mutbuf) -> u64:
    put(w, S_NATIVE_ERROR, 0)
    put(w, S_OUT_ID, 0)
    put(w, S_OUT_KIND, 0)
    put(w, S_OUT_COUNT, 0)
    put(w, S_OUT_PTR, 0)
    put(w, S_OUT_BYTES, 0)
    put(w, S_GROW, 0)
    return 0

def reserve(w:mutbuf, front:u64, depth:u64) -> u64:
    if depth > (MAX >> 6) - 1 or front > MAX - depth * 64 - 64:
        poison(w, 10)
        return 0
    required = front + depth * 64 + 64
    if required <= length(w):
        return 1
    doubled = length(w)
    if doubled <= (MAX >> 1):
        doubled = doubled * 2
    put(w, S_GROW, choose(doubled > required, doubled, required))
    return 0

def resume_memory(w:mutbuf) -> u64:
    old = get(w, S_MEMORY_BYTES)
    if length(w) < old:
        poison(w, 11)
        return 0
    if old != length(w):
        depth = get(w, S_JSON_DEPTH)
        if depth != 0:
            count = depth * 64
            move_bytes(w, length(w) - count, old - count, count)
        put(w, S_MEMORY_BYTES, length(w))
        put(w, S_JSON_STACK_END, length(w))
    put(w, S_GROW, 0)
    return 1

def scratch_node(w:mutbuf, relative:u64) -> u64:
    return get(w, S_SCRATCH_BASE) + relative

def end_node(w:mutbuf, node:u64) -> u64:
    return node + 16 + get(w, node + 8)

def same_string(w:mutbuf, left:u64, right:u64) -> u64:
    if get(w, left) != 4 or get(w, right) != 4:
        return 0
    size = get(w, left + 8)
    if size != get(w, right + 8):
        return 0
    i = 0
    while i < size:
        if byte(w, left + 16 + i) != byte(w, right + 16 + i):
            return 0
        i = i + 1
    return 1

def field(w:mutbuf, node:u64, key:u64) -> u64:
    if get(w, node) != 6:
        return MAX
    count = get(w, node + 16)
    at = node + 24
    i = 0
    while i < count:
        value = end_node(w, at)
        if word(w, at, key) == 1:
            return value
        at = end_node(w, value)
        i = i + 1
    return MAX

def uint_value(w:mutbuf, node:u64, limit:u64) -> u64:
    if node == MAX or get(w, node) != 2:
        return MAX
    size = get(w, node + 8)
    if size == 0 or size > 10:
        return MAX
    if size > 1 and byte(w, node + 16) == 48:
        return MAX
    value = 0
    i = 0
    while i < size:
        unit = byte(w, node + 16 + i)
        if unit < 48 or unit > 57:
            return MAX
        value = value * 10 + unit - 48
        if value > limit:
            return MAX
        i = i + 1
    return value

def identifier(w:mutbuf, node:u64) -> u64:
    value = uint_value(w, node, 4294967295)
    return choose(value == 0, MAX, value)

def optional_id(w:mutbuf, node:u64) -> u64:
    if node != MAX and get(w, node) == 0:
        return 0
    return identifier(w, node)

def table_find(w:mutbuf, table:u64, capacity:u64, identifier:u64) -> u64:
    if identifier == 0 or identifier > 4294967295 or capacity == 0:
        return 0
    mask = capacity - 1
    slot = (identifier * 11400714819323198485) & mask
    probes = 0
    while probes < capacity:
        at = table + slot * 16
        previous = get(w, at)
        if previous == 0:
            return 0
        if previous == identifier:
            return get(w, at + 8)
        slot = (slot + 1) & mask
        probes = probes + 1
    return 0

def table_insert(w:mutbuf, table:u64, capacity:u64, identifier:u64, value:u64) -> u64:
    mask = capacity - 1
    slot = (identifier * 11400714819323198485) & mask
    probes = 0
    while probes < capacity:
        at = table + slot * 16
        previous = get(w, at)
        if previous == 0:
            put(w, at, identifier)
            put(w, at + 8, value)
            return 1
        if previous == identifier:
            return 0
        slot = (slot + 1) & mask
        probes = probes + 1
    return 0

def issued(w:mutbuf, identifier:u64) -> u64:
    return table_find(w, get(w, S_TABLE), get(w, S_CAPACITY), identifier)

def table_size(count:u64) -> u64:
    capacity = 2
    while capacity < count * 2:
        capacity = capacity * 2
    return capacity

def zero_words(w:mutbuf, at:u64, size:u64) -> u64:
    stop = at + size
    while at < stop:
        put(w, at, 0)
        at = at + 8
    return 0
'''


def literal_source():
    """Fixed ABI words only; no input is read during authoring."""
    result = ['def word(w:mutbuf, node:u64, which:u64) -> u64:',
              '    if node == MAX or get(w, node) != 4:', '        return 0']
    for index, value in enumerate(WORDS, 1):
        encoded = value.encode('ascii')
        result += [f'    if which == {index}:',
                   f'        if get(w, node + 8) != {len(encoded)}:', '            return 0']
        for at in range(0, len(encoded), 8):
            chunk = encoded[at:at + 8]
            mask = (1 << (len(chunk) * 8)) - 1
            result += [f'        if (get(w, node + {16 + at}) & {mask}) != {int.from_bytes(chunk, "little")}:',
                       '            return 0']
        result += ['        return 1']
    result += ['    return 0']
    return '\n'.join(result) + '\n'
