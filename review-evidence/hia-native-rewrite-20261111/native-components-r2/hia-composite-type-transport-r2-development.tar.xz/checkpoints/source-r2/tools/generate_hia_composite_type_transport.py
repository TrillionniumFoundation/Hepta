"""Author the complete two-image HIA type transport owner.

Each runtime decision is in generated HIA. Python only combines fixed source,
expands constants, and uses the retained compiler's existing copy operations.
"""
from __future__ import annotations
import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools.generate_hia_composite_type_transport_common import COMMON, CONSTANTS, literal_source
from tools.generate_hia_composite_type_transport_commands import BODY as COMMANDS, validation_source
from tools.generate_hia_composite_type_transport_reply import BODY as REPLY
from tools.generate_hia_composite_type_transport_json import BODY as JSON
from tools.generate_hia_composite_type_transport_encoding import BODY as ENCODING

SOURCES = {
    'commands': 'examples/hia_bootstrap/composite_type_transport_commands.hiaasm',
    'reply': 'examples/hia_bootstrap/composite_type_transport_reply.hiaasm',
}


def source_program(which):
    if which == 'commands':
        source = COMMANDS + COMMON + literal_source() + validation_source()
    elif which == 'reply':
        source = REPLY + JSON + ENCODING + COMMON + literal_source()
    else:
        raise ValueError('unknown type transport image')
    tree = ast.parse(source)

    class Constants(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id in CONSTANTS:
                return ast.copy_location(ast.Constant(CONSTANTS[node.id]), node)
            return node

    return ast.unparse(ast.fix_missing_locations(Constants().visit(tree))) + '\n'


def document(which):
    nodes = ast.parse(source_program(which)).body
    if len({node.name for node in nodes}) != len(nodes):
        raise ValueError('duplicate type transport function')
    names = {node.name: 'f' + str(i) for i, node in enumerate(nodes)}
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)

    class CopyBuilder(Builder):
        def expr(self, expression):
            if isinstance(expression, ast.Call) and isinstance(expression.func, ast.Name):
                name = expression.func.id
                if name in ('copy_bytes', 'move_bytes'):
                    values = [self.expr(arg) for arg in expression.args]
                    if name == 'copy_bytes':
                        assert len(values) == 5 and values[0][1] == 'mutbuf' and values[1][1] == 'readbuf'
                        return self.op('buffer.copy_range', values[:2] + [self.cast(x, 'usize') for x in values[2:]])
                    assert len(values) == 4 and values[0][1] == 'mutbuf'
                    return self.op('buffer.move_within', values[:1] + [self.cast(x, 'usize') for x in values[1:]])
            return super().expr(expression)

    functions = []
    for node in nodes:
        builder = CopyBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name],
                          'params': [builder.param(x) for x in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    document = compact_authoring_cfg({'schema': 'hepta.hia.program.v8',
                                     'module': 'composite_type_transport_' + which,
                                     'functions': functions})
    limits = {'functions': len(functions),
              'blocks': sum(len(fn['blocks']) for fn in functions),
              'instructions': sum(len(block['ops']) for fn in functions for block in fn['blocks']),
              'maximum_function_blocks': max(len(fn['blocks']) for fn in functions),
              'maximum_block_params': max(len(block['params']) for fn in functions for block in fn['blocks'])}
    if (limits['functions'] > 128 or limits['blocks'] > 1536 or limits['instructions'] > 8192
            or limits['maximum_function_blocks'] > 256 or limits['maximum_block_params'] > 16):
        raise ValueError({'original_compiler_limits_exceeded': limits})
    return document


def main():
    root = Path(__file__).resolve().parents[1]
    for which, path in SOURCES.items():
        target = root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        doc = document(which)
        target.write_text(render_assembly(doc))
        print(which, len(doc['functions']), sum(len(fn['blocks']) for fn in doc['functions']),
              sum(len(block['ops']) for fn in doc['functions'] for block in fn['blocks']),
              target.stat().st_size)


if __name__ == '__main__':
    main()
