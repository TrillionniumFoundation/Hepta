"""Private native JSON byte-encoding compatibility, independent of public JSON.

Matches the byte encodings recognized by json.loads(bytes), including surrogate
pass. The real HIA emitter's normal UTF-8 path remains a direct immutable view.
UTF-16/32 normalization is temporary session scratch and never an issued value.
"""

BODY = r'''
def json_byte(c:readbuf, w:mutbuf, index:u64) -> u64:
    if get(w, S_ENCODING_KIND) == 0:
        return widen(byte(c, index))
    return widen(byte(w, scratch_node(w, get(w, S_ENCODING_REL)) + index - 128))

def json_length(c:readbuf, w:mutbuf) -> u64:
    if get(w, S_ENCODING_KIND) == 0:
        return length(c)
    return 128 + get(w, S_ENCODING_BYTES)

def json_copy(c:readbuf, w:mutbuf, target:u64, index:u64, size:u64) -> u64:
    if get(w, S_ENCODING_KIND) == 0:
        copy_bytes(w, c, target, index, size)
    else:
        move_bytes(w, target, scratch_node(w, get(w, S_ENCODING_REL)) + index - 128, size)
    return 1

def json_code_unit(c:readbuf, index:u64, width:u64, little:u64) -> u64:
    value = 0
    at = 0
    while at < width:
        shift = choose(little != 0, at, width - 1 - at) * 8
        value = value | (widen(byte(c, index + at)) << shift)
        at = at + 1
    return value

def json_prepare(c:readbuf, w:mutbuf) -> u64:
    size = length(c) - 128
    width = 1
    little = 0
    index = 128
    if size >= 4 and json_code_unit(c, 128, 4, 1) == 65279:
        width = 4
        little = 1
        index = 132
    elif size >= 4 and json_code_unit(c, 128, 4, 0) == 65279:
        width = 4
        index = 132
    elif size >= 2 and json_code_unit(c, 128, 2, 1) == 65279:
        width = 2
        little = 1
        index = 130
    elif size >= 2 and json_code_unit(c, 128, 2, 0) == 65279:
        width = 2
        index = 130
    elif size >= 3 and byte(c, 128) == 239 and byte(c, 129) == 187 and byte(c, 130) == 191:
        index = 131
    elif size >= 4:
        if byte(c, 128) == 0:
            width = choose(byte(c, 129) == 0, 4, 2)
        elif byte(c, 129) == 0:
            little = 1
            width = choose(byte(c, 130) == 0 and byte(c, 131) == 0, 4, 2)
    elif size == 2:
        if byte(c, 128) == 0:
            width = 2
        elif byte(c, 129) == 0:
            width = 2
            little = 1
    if width == 1:
        put(w, S_ENCODING_KIND, 0)
        put(w, S_ENCODING_START, index)
        return 1
    if ((length(c) - index) & (width - 1)) != 0:
        poison(w, 130)
        return 0
    relative = get(w, S_SCRATCH_USED)
    # UTF-16 needs at most three bytes per two-byte unit. UTF-32 needs at most
    # four per unit. Twice the original bounded byte extent safely covers both.
    if reserve(w, scratch_node(w, relative) + size * 2, 0) == 0:
        return 0
    put(w, S_JSON_AT, relative)
    put(w, S_JSON_DEPTH, 0)
    while index < length(c):
        cp = json_code_unit(c, index, width, little)
        index = index + width
        if width == 2 and cp >= 55296 and cp <= 56319 and index < length(c):
            low = json_code_unit(c, index, 2, little)
            if low >= 56320 and low <= 57343:
                cp = 65536 + (cp - 55296) * 1024 + low - 56320
                index = index + 2
        if cp > 1114111:
            poison(w, 131)
            return 0
        # Python's bytes decoder uses surrogatepass. Unpaired code units are
        # preserved in the private packet; the public parser is unchanged.
        if json_scalar(w, cp) == 0:
            return 0
    put(w, S_ENCODING_KIND, 1)
    put(w, S_ENCODING_REL, relative)
    put(w, S_ENCODING_BYTES, get(w, S_JSON_AT) - relative)
    put(w, S_ENCODING_START, 128)
    put(w, S_SCRATCH_USED, align8(get(w, S_JSON_AT)))
    return 1

def json_whitespace(c:readbuf, w:mutbuf, index:u64) -> u64:
    going = True
    while going and index < json_length(c, w):
        cp = json_byte(c, w, index)
        if cp != 32 and cp != 9 and cp != 10 and cp != 13:
            going = False
        else:
            index = index + 1
    return index

def json_hex4(c:readbuf, w:mutbuf, index:u64) -> u64:
    if index + 4 > json_length(c, w):
        return MAX
    count = 0
    value = 0
    while count < 4:
        cp = json_byte(c, w, index + count)
        digit = 16
        if cp >= 48 and cp <= 57:
            digit = cp - 48
        elif cp >= 65 and cp <= 70:
            digit = cp - 55
        elif cp >= 97 and cp <= 102:
            digit = cp - 87
        if digit == 16:
            return MAX
        value = value * 16 + digit
        count = count + 1
    return value

def json_decoded(c:readbuf, w:mutbuf, index:u64) -> u64:
    size = json_length(c, w)
    if index >= size:
        return 1114113
    cp = json_byte(c, w, index)
    index = index + 1
    if cp == 34:
        return (index << 32) | 1114112
    if cp < 32:
        return 1114113
    if cp == 92:
        if index >= size:
            return 1114113
        esc = json_byte(c, w, index)
        index = index + 1
        if esc == 34 or esc == 92 or esc == 47:
            return (index << 32) | esc
        if esc == 98:
            return (index << 32) | 8
        if esc == 102:
            return (index << 32) | 12
        if esc == 110:
            return (index << 32) | 10
        if esc == 114:
            return (index << 32) | 13
        if esc == 116:
            return (index << 32) | 9
        if esc != 117:
            return 1114113
        cp = json_hex4(c, w, index)
        if cp == MAX:
            return 1114113
        index = index + 4
        if cp >= 55296 and cp <= 56319 and index + 6 <= size:
            if json_byte(c, w, index) == 92 and json_byte(c, w, index + 1) == 117:
                low = json_hex4(c, w, index + 2)
                if low >= 56320 and low <= 57343:
                    cp = 65536 + (cp - 55296) * 1024 + low - 56320
                    index = index + 6
        return (index << 32) | cp
    if cp < 128:
        return (index << 32) | cp
    needed = 0
    minimum = 0
    if cp >= 194 and cp <= 223:
        needed = 1
        minimum = 128
        cp = cp & 31
    elif cp >= 224 and cp <= 239:
        needed = 2
        minimum = 2048
        cp = cp & 15
    elif cp >= 240 and cp <= 244:
        needed = 3
        minimum = 65536
        cp = cp & 7
    if needed == 0 or index + needed > size:
        return 1114113
    count = 0
    while count < needed:
        unit = json_byte(c, w, index)
        if unit < 128 or unit > 191:
            return 1114113
        cp = cp * 64 + (unit & 63)
        count = count + 1
        index = index + 1
    if cp < minimum or cp > 1114111:
        return 1114113
    return (index << 32) | cp
'''
