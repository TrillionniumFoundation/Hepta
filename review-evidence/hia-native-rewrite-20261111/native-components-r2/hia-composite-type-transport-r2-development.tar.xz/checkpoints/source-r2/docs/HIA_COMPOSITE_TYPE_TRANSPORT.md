# Native composite type transport — development ABI r2

Status: independent source-bound development owner. Revision r1 has actual native compilation, all-six-operation differential, malformed-frame, protocol and large-response evidence. Revision r2 adds private byte-encoding compatibility; its actual compilation and differential results are recorded separately. No installed default, complete driver, whole-stack or cold qualification is claimed.

The owner replaces the complete issued-ID and response materialization behavior of NativeCompositeTypeSession. The existing HIA types image remains the semantic owner of nominal resolution and its budgets.

## Images and private state

Two statically selected HIA images share one exclusively owned workspace:
- type_transport_commands: BEGIN and QUERY.
- type_transport_reply: REPLY.

The caller selects the image solely from the command magic. Both reject wrong command families and share the same permanent refusal flag. All persistent offsets refer to this workspace. A GROW event means preserve all existing bytes, enlarge the same lease, and retry the same image with the same immutable input lease. The coordinator must discard the whole lease on any invalid return, including invalid buffer extents; it must not rely on a refreshed event after failure.

A session lease is a nonzero coordinator-issued identity. It is correlation, not external provenance. The issued-ID table must not be combined with a different types owner or a replacement native types state.

## Command words

All words are little-endian unsigned 64-bit. The fixed header is 64 bytes.

BEGIN magic HIATRB01:
[magic, sessionLease, commandSeq, typeOp, callerRequest, packetBytes, 0, 0]
followed by the complete typed command packet, representing exactly the JSON dictionary sent to the existing types image.

REPLY magic HIATRR01:
[magic, sessionLease, commandSeq, typeOp, callerRequest, nativeFrameBytes, 0, 0]
followed by the original complete native frame, including its original 64-byte header.

QUERY magic HIATRQ01:
[magic, sessionLease, lastCompletedCommandSeq, querySeq, identifier, 0, 0, 0]

typeOp is fixed:
1 init; 2 parameters; 3 resolve; 4 partial; 5 origins; 6 task_protocol.
The command packet's op field must match this header. Constructor op 4 and op 5 are mechanically remapped by the coordinator; function helper services stay outside this owner.

A BEGIN can be accepted only when no native reply is pending. A REPLY consumes exactly one pending BEGIN, with all five correlation fields unchanged. Query is prohibited while a reply is pending and uses its own monotone sequence bound to the last completed command sequence. Replays, unknown IDs, wrong sessions or wrong sequence poison the lease.

## Complete event

The output event is 128 bytes / 16 words:
[HIATRE01, action, sessionLease, commandSeq, callerRequest, typeOp,
 semanticError, nativeIdentifier, cached, active, steps,
 resultKind, resultCount, payloadOffset, payloadBytes, aux]

action 0 means this entry completed normally. BEGIN's normal event is an acknowledgement to invoke the existing types owner; it does not complete the outstanding command. REPLY's normal event completes it. QUERY's normal event publishes a borrowed issued descriptor.

action 1 requests GROW, with aux equal to the required workspace bytes. No command/query sequence is consumed by an incomplete GROW retry.

The ABI-invalid return is 0xfffffffd. No error return authorizes fallback.

resultKind:
0: no value, for successful init and BEGIN acknowledgement.
1: one issued identifier, encoded as an 8-byte little-endian word, for resolve/partial/task.
2: complete typed packet [[name, identifier], ...], for parameters.
3: complete typed packet [null | [name, slotOffset], ...], for origins.
4: one complete 13-field descriptor typed packet, for QUERY.

Payload offsets and extents refer to the current workspace, not the event output buffer. The coordinator consumes/copies the view in HIA before any later call or GROW, and never retains a raw borrowed pointer across a call.

For QUERY, commandSeq is lastCompletedCommandSeq, callerRequest is querySeq, typeOp is zero, nativeIdentifier is the requested issued ID, and resultCount is one.

A completed semantic error has no result payload and retains the original native error number, newly accepted descriptors and original counter updates. It is not an ABI poison. The coordinator maps the exact existing ERRORS table to its caller's response.

## Original bounds and custody

The BEGIN typed packet retains the existing 64 MiB private packet limit. HIA computes its JSON spelling size and enforces the actual existing types command limit of 8 MiB + 128 bytes; these two different representations are not conflated.

The original native frame, including its header, can be up to 64 MiB. The response parser has no public json_decode 8 MiB or 262144-node admission gate.

Persistent descriptors, strings and graph edges are copied into the GROW arena. They never reference the reusable original types output buffer. Command scratch and result views are reclaimed when the next entry begins; repeated responses do not retain whole historical payloads. There is no new session descriptor, byte or call quota.

The input and workspace leases are disjoint and exclusively owned by the fixed native coordinator. GROW retries retain the identical private input lease; numeric IDs alone do not authenticate an independently supplied or modified arena.

## Validation and commit order

The actual native header must pass extent, expected magic, reserved field and error/identifier checks before decoding payload. The original origin/task counter stability and allowed-error subsets remain unchanged.

All descriptors have exactly the original 13 fields: id, kind, name, args, flat, fields, variants, state, result, poll, cancel, linear, record.

IDs are positive uint32 values. IDs 1–16 are primitive iff their kind is primitive and their names match the original primitive table. Descriptor field values are checked only to the original transport types; this owner does not recompute layouts, enforce nominal naming rules, or add kind-specific language restrictions.

Repeated IDs, IDs already issued, unknown references and cyclic pending references are refused. Pending descriptors become issued only after the whole pending DAG is validated. The parameters result references are checked after this descriptor commit, matching the old adapter. Observations are updated after payload validation and before a semantic error or the final ordinary result-ID check.

Origins counts, names and all original type-ID custody checks come from the complete admitted command packet in HIA. The host cannot provide precomputed origin names, counts, layout results or a materialization plan.

## Current unclosed work

The complete fixed native coordinator, ordinary public-entry integration, installed resource/build/qualification gates and whole-driver closure remain separate work. Per-revision test reports record only actual executed groups. A semantic init failure requires the fixed coordinator to close/discard both native leases, as the original constructor does. Ordinary later semantic failures preserve the session. A BAD return always discards the lease even when an illegally short borrowed workspace prevented a persistent poison write.

## Private byte-encoding compatibility

The old private Python json.loads(bytes) recognizes UTF-8 BOM and UTF-16/32, and represents unpaired escaped or surrogate-pass decoded surrogates. Revision r1 recorded 13 actual differences on 18 private response-injection controls; these original inputs/results remain frozen. Revision r2 implements byte-encoding detection and UTF-16/32 normalization in HIA before the unchanged descriptor transaction. Normal UTF-8 retains its immutable read view. Normalized strings are copied into private UTF-8/WTF-8 packet scratch and complete issued descriptors are copied again into persistent session ownership. The public JSON parser and its scalar/encoding rules are unchanged. The native types emitter remains the only issuer on the ordinary pipeline; arbitrary forged-frame injection is labelled private transport coverage. The r2 test report, not this source document, establishes which encoding controls have actually passed.

Malformed-payload diagnostics must also retain the original frame-before-payload-before-native-semantic-error ordering and its descriptor/observation commit points. Reproducing Python JSON parser-specific English syntax-error text is not currently implemented or claimed.

