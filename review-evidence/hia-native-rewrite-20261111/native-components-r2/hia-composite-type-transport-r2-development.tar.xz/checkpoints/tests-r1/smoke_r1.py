"""Actual transport images, synthetic native frames: first protocol smoke."""
from pathlib import Path
import faulthandler
import json
import resource

from transport_harness import NativeTransport, frame, descriptor
from hepta.hia_composite_types_native import PRIMITIVES, NativeCompositeTypeSession

faulthandler.enable()
resource.setrlimit(resource.RLIMIT_CPU, (15, 15))
resource.setrlimit(resource.RLIMIT_AS, (768 << 20, 768 << 20))
root = Path(__file__).resolve().parent
target = root / 'smoke-r1'
target.mkdir(exist_ok=False)
native = NativeTransport(root / 'compile-r1/bundle.json', ledger=target / 'entries.jsonl')
oracle = NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)
oracle._nonce = object()
oracle._types, oracle._ids, oracle._descriptors = {}, {}, {}
types = [descriptor(i, name, kind='primitive', flat=[i]) for i, name in enumerate(PRIMITIVES, 1)]
try:
    result = native.begin({'op': 'init', 'definitions': [], 'recursive_chain': False, 'partial_records': False}, 1)
    assert result[0] == 128 and result[1][1] == 0, result
    result = native.reply(frame({'types': types}))
    assert result[0] == 128 and result[1][6] == 0, result
    oracle._materialize_value({'types': types})
    for identifier in oracle._descriptors:
        assert native.query(identifier) == oracle._descriptors[identifier]
    record = descriptor(17, 'R', fields=[('value', 9)], flat=[9])
    assert native.begin({'op': 'resolve', 'ref': 'R'}, 3)[0] == 128
    result = native.reply(frame({'types': [record]}, identifier=17, counters=(1, 0, 0)))
    assert result[0] == 128 and result[1][11:13] == (1, 1), result
    oracle._materialize_value({'types': [record]})
    assert native.query(17) == record
    summary = {'scope': 'ACTUAL_TWO_IMAGES_SYNTHETIC_FRAME_FIRST_SMOKE',
               'passed': True, 'native_entries': native.calls, 'grows': native.grows,
               'workspace_bytes': native.size, 'queried_descriptors': 17,
               'actual_types_owner_invoked': False, 'cold_qualified': False}
    (target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
finally:
    native.close()
