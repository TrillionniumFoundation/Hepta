"""Reachable large native response, original limits, complete old/new oracle.

This is test construction only. Both the nominal type resolution and response
validation execute their source-bound HIA images. No public JSON quota is used
for the private response, and no language or compiler quota is increased.
"""
from pathlib import Path
from hashlib import sha256
import ctypes
import faulthandler
import json
import resource
import time

from transport_harness import NativeTransport
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_composite_types_native import NativeCompositeTypes, NativeCompositeTypeSession

faulthandler.enable()
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20, 1024 << 20))
root = Path(__file__).resolve().parent
target = Path('/dev/shm/hia-type-transport-large-r2')
target.mkdir(exist_ok=False)
manifest_path = root / 'compile-types-r1/manifest.json'
manifest_raw = manifest_path.read_bytes()
manifest = json.loads(manifest_raw)
image_raw = Path(manifest['image_path']).read_bytes()
source_raw = Path(manifest['source_path']).read_bytes()
assert sha256(image_raw).hexdigest() == manifest['image_sha256']
assert sha256(source_raw).hexdigest() == manifest['source_sha256']
image = NativeCompositeTypes(image_raw, manifest['image_sha256'])
entry = image._entry
transport = NativeTransport(root / 'compile-r1/bundle.json', ledger=target / 'transport-entries.jsonl')
transactions, last = [], {}
started = time.monotonic_ns()


def canonical(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode()


def actual_entry(source, size, output, capacity, workspace, workspace_size):
    raw = ctypes.string_at(source, size)
    before = time.monotonic_ns()
    extent = entry(source, size, output, capacity, workspace, workspace_size)
    native_ns = time.monotonic_ns() - before
    assert 64 <= extent <= capacity, extent
    frame = ctypes.string_at(output, extent)
    index = len(transactions)
    (target / f'{index:02d}-command.json').write_bytes(raw)
    (target / f'{index:02d}-native-frame.bin').write_bytes(frame)
    before = time.monotonic_ns()
    result, event, payload = transport.reply(frame)
    validate_ns = time.monotonic_ns() - before
    assert result == 128 and event[1] == 0 and event[6] == 0, (result, event)
    row = dict(index=index, command_bytes=len(raw), command_sha256=sha256(raw).hexdigest(),
               native_frame_bytes=len(frame), native_frame_sha256=sha256(frame).hexdigest(),
               type_native_ns=native_ns, transport_ns=validate_ns, event=event)
    transactions.append(row)
    last['result'] = payload
    (target / 'transactions.json').write_text(json.dumps(transactions, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    return extent


image._entry = actual_entry
definitions = [dict(name='Zero', kind='record', params=[], fields=[]),
    dict(name='Expanded', kind='enum', params=['A', 'B'], variants=[
        dict(name='variant_' + str(variant), fields=[
            dict(name='field_' + str(field).zfill(2) + '_' + 'x' * 64, type='Zero')
            for field in range(64)]) for variant in range(32)])]
primitive_args = ['bool', 'unit', 'i8', 'i16', 'i32', 'i64', 'u8', 'u16', 'u32',
                  'u64', 'isize', 'usize', 'buffer', 'readbuf', 'mutbuf', 'chain']
params = [dict(name='parameter_' + str(index),
               type={'name': 'Expanded', 'args': [primitive_args[index // 16], primitive_args[index % 16]]})
          for index in range(127)]
init = dict(op='init', definitions=definitions, recursive_chain=True, partial_records=True)
oracle = None
try:
    assert transport.begin(init, 1)[0] == 128
    oracle = NativeCompositeTypeSession(image, definitions, recursive_chain=True, partial_records=True)
    initial_queries = {identifier: canonical(transport.query(identifier)) for identifier in oracle._descriptors}
    grows_before = transport.grows
    assert transport.begin(dict(op='parameters', params=params), 2)[0] == 128
    resolved = oracle.parameters(params)
    received = detached_packet_index(last['result'])[0]
    assert canonical(received) == canonical([[name, oracle._ids[id(value)]] for name, value in resolved])
    assert transactions[1]['native_frame_bytes'] > 8 << 20
    assert oracle.observations == {'cache_count': 128, 'active_count': 0, 'partial_declaration_steps': 0}
    assert transport.grows > grows_before
    # The original output lease is actively overwritten before QUERY. All of
    # the names/fields must already belong to the transport's persistent arena.
    ctypes.memset(oracle._output, 0x5a, ctypes.sizeof(oracle._output))
    for identifier, expected in initial_queries.items():
        assert canonical(transport.query(identifier)) == expected
    count = 0
    registry_digest = sha256()
    for identifier, expected in oracle._descriptors.items():
        raw = canonical(expected)
        assert canonical(transport.query(identifier)) == raw, identifier
        registry_digest.update(raw)
        count += 1
    # A later real owner call reuses both native output and transport scratch.
    command = dict(op='resolve', ref=params[0]['type'])
    assert transport.begin(command, 3)[0] == 128
    later = oracle.resolve(params[0]['type'])
    assert later is resolved[0][1]
    for identifier, expected in oracle._descriptors.items():
        assert canonical(transport.query(identifier)) == canonical(expected), identifier
    # Count the actual response JSON nodes, separately from both native paths.
    response = (target / '01-native-frame.bin').read_bytes()
    value = json.loads(response[64:])
    stack, nodes = [value], 0
    while stack:
        item = stack.pop()
        nodes += 1
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    assert nodes > 262144
    summary = dict(scope='ACTUAL_HIA_TYPES_LARGE_RESPONSE_AND_NATIVE_TRANSPORT', passed=True,
        source_definitions=2, variants_per_instance=32, zero_width_fields_per_variant=64,
        generic_instances=127, cache_count=128, maximum_flat_slots=1,
        command_bytes=[row['command_bytes'] for row in transactions],
        native_frame_bytes=transactions[1]['native_frame_bytes'], native_JSON_value_nodes=nodes,
        actual_type_entries=len(transactions), actual_transport_entries=transport.calls,
        grows=transport.grows, workspace_bytes=transport.size, issued_descriptors=count,
        registry_sha256=registry_digest.hexdigest(),
        all_descriptor_packets_equal_before_and_after_later_reply=True,
        original_native_output_overwritten_before_query=True,
        elapsed_ns=time.monotonic_ns()-started, max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        cold_qualified=False, original_public_and_type_owner_limits_unchanged=True)
    (target / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
finally:
    if oracle is not None:
        oracle.close()
    transport.close()
    assert manifest_path.read_bytes() == manifest_raw
    assert Path(manifest['image_path']).read_bytes() == image_raw
    assert Path(manifest['source_path']).read_bytes() == source_raw
