"""Source-bound development compilation; never a cold-qualification builder."""
from pathlib import Path
from hashlib import sha256
import json

from tools.qualify_hia_selfhost import compile_stage

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / 'checkpoints/source-r1'
DESTINATION = ROOT / 'development/compile-r1'
COMPILER = Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin')


def main():
    manifest_raw = (SNAPSHOT / 'source.json').read_bytes()
    manifest = json.loads(manifest_raw)
    frozen = {}
    for row in manifest['files']:
        raw = (SNAPSHOT / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        frozen[SNAPSHOT / row['path']] = raw
    for row in manifest['dependencies']:
        raw = Path(row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        frozen[Path(row['path'])] = raw
    assert sha256(frozen[COMPILER]).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
    DESTINATION.mkdir(exist_ok=False)
    rows = {}
    try:
        for which in ('commands', 'reply'):
            source = SNAPSHOT / f'examples/hia_bootstrap/composite_type_transport_{which}.hiaasm'
            path, receipt = compile_stage(DESTINATION, 'type-transport-' + which, COMPILER, frozen[source])
            assert receipt['input_sha256'] == sha256(frozen[source]).hexdigest()
            row = {'schema': 'hepta.hia.composite-type-transport-' + which + '-native.v1',
                   'source_path': str(source), 'source_sha256': sha256(frozen[source]).hexdigest(),
                   'image_path': str(path), 'image_sha256': sha256(path.read_bytes()).hexdigest(),
                   'compiler_sha256': sha256(frozen[COMPILER]).hexdigest()}
            (DESTINATION / (which + '.manifest.json')).write_text(json.dumps(row, indent=2, sort_keys=True) + '\n')
            rows[which] = row
        summary = {'scope': 'SOURCE_BOUND_DEVELOPMENT_NOT_COLD_QUALIFIED', 'status': 'PASS',
                   'source_checkpoint_sha256': sha256(manifest_raw).hexdigest(),
                   'components': rows, 'whole_stack_closed': False}
        (DESTINATION / 'bundle.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
        print(json.dumps(summary, sort_keys=True), flush=True)
    finally:
        for path, original in frozen.items():
            assert path.read_bytes() == original, path
        assert (SNAPSHOT / 'source.json').read_bytes() == manifest_raw


if __name__ == '__main__':
    main()
