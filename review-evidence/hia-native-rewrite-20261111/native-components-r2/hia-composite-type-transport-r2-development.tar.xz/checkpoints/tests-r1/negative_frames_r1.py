"""Independent old-adapter outcomes against actual native transport images.

Forged native frames are explicit transport tests, not type-language witnesses.
The compiler and both transport images are real and source-bound.
"""
from pathlib import Path
from hashlib import sha256
from types import SimpleNamespace
from threading import RLock
import copy
import ctypes
import faulthandler
import json
import resource
import struct

from transport_harness import NativeTransport, frame, descriptor, BAD, MAGIC
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_composite_types_native import NativeCompositeTypeSession, ERRORS
from hepta.hia_program import HIAProgramRejected

faulthandler.enable()
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
resource.setrlimit(resource.RLIMIT_AS, (768 << 20, 768 << 20))
root = Path(__file__).resolve().parent
target = root / 'negative-frames-r1'
target.mkdir(exist_ok=False)
initial = (root / 'actual-pipeline-r1/000-types-response.bin').read_bytes()
init_command = dict(op='init', definitions=[], recursive_chain=True, partial_records=True)


def canonical(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode()


def native_snapshot(native):
    data = native.workspace
    word = lambda at: struct.unpack_from('<Q', data, at)[0]
    table, capacity, count = word(112), word(120), word(128)
    items = {}
    for index in range(capacity):
        identifier, pointer = struct.unpack_from('<2Q', data, table + index * 16)
        if not identifier:
            continue
        assert pointer <= native.size - 16
        size = 16 + word(pointer + 8)
        assert size <= native.size - pointer
        value = detached_packet_index(ctypes.string_at(ctypes.addressof(data) + pointer, size))[0]
        items[identifier] = value
    assert len(items) == count
    return {'descriptors': items, 'observations': [word(80), word(88), word(96)], 'broken': bool(word(8))}


def reference_session():
    values = []
    def entry(source, size, output, capacity, state, state_size):
        raw = values.pop(0)
        ctypes.memmove(output, raw, len(raw))
        return len(raw)
    oracle = NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)
    oracle._image = SimpleNamespace(_entry=entry)
    oracle._lock, oracle._nonce = RLock(), object()
    oracle._types, oracle._ids, oracle._descriptors, oracle._observations = {}, {}, {}, {}
    oracle._broken = oracle._closed = False
    oracle._state = ctypes.create_string_buffer(1)
    oracle._output = ctypes.create_string_buffer(1 << 18)
    return oracle, values


def reference_snapshot(oracle):
    return {'descriptors': oracle._descriptors,
            'observations': [oracle._observations.get(key, 0) for key in
                ('cache_count', 'active_count', 'partial_declaration_steps')],
            'broken': oracle._broken}


cases = []
item = descriptor(17, 'Transport may contain arbitrary names', flat=[9], fields=[('a field', 9)])


def add(name, payload=None, *, operation=3, command=None, native=None, identifier=17,
        error=0, counters=(7, 3, 19), magic=b'HIATYP01'):
    if native is None:
        native = frame({'types': [item]} if payload is None else payload,
                       identifier=identifier, error=error, counters=counters, magic=magic)
    if command is None:
        command = {'op': 'resolve', 'ref': 'x'}
    cases.append((name, operation, command, native))


add('valid_nonlanguage_names')
add('valid_uint32_max', {'types': [descriptor(0xffffffff, 'Max', flat=[9])]}, identifier=0xffffffff)
add('valid_flat_513_transport_has_no_layout_quota', {'types': [descriptor(17, 'Wide', flat=[9] * 513)]})
add('valid_partial_fields_only_transport', {'types': [descriptor(17, None, kind='partial_record', record=9)]})
child = descriptor(18, 'Child', flat=[9])
parent = descriptor(17, 'Parent', fields=[('child', 18)], args=[18, 18])
add('valid_forward_DAG', {'types': [parent, child]})
for field in item:
    altered = copy.deepcopy(item)
    del altered[field]
    add('missing_' + field, {'types': [altered]})
altered = dict(item, extra=0)
add('extra_field', {'types': [altered]})
for field, values in {
    'id': [0, -1, True, 1.0, 1 << 32], 'kind': [None, 3, 'foreign'],
    'name': [None, 3], 'args': [None, [0], [True], [1 << 32]],
    'flat': [None, [0], [17], [True], [1.0]],
    'fields': [None, [['x']], [[False, 9]], [['x', False]]],
    'variants': [None, [['x']], [[False, []]], [['x', [['y', 0]]]]],
    'state': [False, 0], 'result': [False, 0], 'record': [False, 0],
    'linear': [0, None], 'poll': [0, []], 'cancel': [False, []],
}.items():
    for index, value in enumerate(values):
        altered = copy.deepcopy(item)
        altered[field] = value
        add('bad_' + field + '_' + str(index), {'types': [altered]})
add('existing_ID', {'types': [descriptor(9, 'u32', kind='primitive', flat=[9])]}, identifier=9)
add('primitive_wrong_name', {'types': [descriptor(17, 'u32', kind='primitive', flat=[9])]})
add('duplicate_new_ID', {'types': [item, item]})
add('self_cycle', {'types': [descriptor(17, 'Cycle', fields=[('next', 17)])]})
add('mutual_cycle', {'types': [descriptor(17, 'A', fields=[('next', 18)]),
                             descriptor(18, 'B', fields=[('next', 17)])]})
add('unknown_reference', {'types': [descriptor(17, 'Unknown', fields=[('x', 99)])]})
add('late_bad_descriptor_cannot_commit_first', {'types': [item, dict(child, linear=0)]})
add('wrong_envelope', {'types': [item], 'extra': []})
base = frame({'types': [item]}, identifier=17)
for word, value in [(0, 0), (1, 51), (7, 1), (3, 0)]:
    altered = bytearray(base)
    struct.pack_into('<Q', altered, word * 8, value)
    add('header_' + str(word), native=bytes(altered))
add('semantic_error_nonzero_identifier', native=frame({'types': []}, identifier=17, error=33))
add('short_native_frame', native=b'HIATYP01')
for name, payload in [('duplicate_keys', b'{"types":[],"types":[]}'),
                      ('trailing_json', b'{"types":[]} null'),
                      ('truncated_json', b'{"types":['),
                      ('invalid_utf8', b'{"types":"\xff"}')]:
    native = struct.pack('<8Q', int.from_bytes(b'HIATYP01', 'little'), 0, 17, len(payload), 7, 3, 19, 0) + payload
    add(name, native=native)
add('late_result_ID_commits_descriptors_and_counters', identifier=99)
add('params_unknown_ID_commits_descriptors_not_counters', {'types': [item], 'params': [['x', 99]]},
    operation=2, command={'op': 'parameters', 'params': []}, identifier=1, magic=b'HIAPRM01')
add('params_bad_pair_no_descriptor_commit', {'types': [item], 'params': [['x', True]]},
    operation=2, command={'op': 'parameters', 'params': []}, identifier=1, magic=b'HIAPRM01')
add('semantic_error_bad_payload_stays_ABI_first', {'types': [dict(item, linear=0)]}, identifier=0, error=1)
for error in range(1, 51):
    add('all_original_semantic_status_' + str(error), {'types': [item]}, identifier=0, error=error)
for operation, command, magic, payload, allowed in [
    (2, {'op': 'parameters', 'params': []}, b'HIAPRM01', {'types': [], 'params': []}, set(range(1, 37)) | {45, 46}),
    (5, {'op': 'origins', 'params': [['p', 14]], 'returns': []}, b'HIALOR01', {'origins': []}, {1, 5, 6} | set(range(37, 45))),
    (6, {'op': 'task_protocol', 'task': 9, 'functions': []}, b'HIATYP01', {'types': []}, set(range(47, 51))),
]:
    for error in range(1, 51):
        add('op_' + str(operation) + '_status_' + str(error), payload, operation=operation,
            command=command, magic=magic, identifier=0, error=error, counters=(0, 0, 0))

ledger = (target / 'outcomes.jsonl').open('w')
total_entries = 0
refused = 0
semantic = 0
accepted = 0
try:
    for index, (name, operation, command, raw) in enumerate(cases):
        native = NativeTransport(root / 'compile-r1/bundle.json', lease=index + 1)
        oracle, pending = reference_session()
        try:
            assert native.begin(init_command, 1)[0] == 128
            assert native.reply(initial)[0] == 128
            pending.append(initial)
            oracle._command(init_command, result=False)
            assert native.begin(command, operation)[0] == 128
            options = {'parameters': True} if operation == 2 else {'origins': True} if operation == 5 else {'stable': True} if operation == 6 else {}
            pending.append(raw)
            error = None
            try:
                value = oracle._command(command, **options)
            except HIAProgramRejected as exc:
                error = (exc.code, str(exc))
            result, event, payload = native.reply(raw)
            if oracle._broken:
                assert result == BAD, (name, error, result, event)
                refused += 1
            elif error:
                assert result == 128 and event[6], (name, error, result, event)
                code, message = ERRORS[event[6]]
                expected = HIAProgramRejected(message, code)
                assert error == (expected.code, str(expected))
                semantic += 1
            else:
                assert result == 128 and event[6] == 0, (name, result, event)
                accepted += 1
            expected, actual = reference_snapshot(oracle), native_snapshot(native)
            assert canonical(actual) == canonical(expected), name
            if result == BAD:
                assert native.query(9) == BAD
                assert native.begin({'op': 'resolve', 'ref': 'u32'}, 3)[0] == BAD
                assert native.reply(base)[0] == BAD
            (target / f'{index:03d}.frame.bin').write_bytes(raw)
            ledger.write(json.dumps({'name': name, 'operation': operation, 'input_sha256': sha256(raw).hexdigest(),
                'reference_error': error, 'native_return': result, 'event': event,
                'complete_state_sha256': sha256(canonical(actual)).hexdigest(),
                'issued': sorted(actual['descriptors']), 'observations': actual['observations'],
                'broken': actual['broken'], 'equal': True}) + '\n')
            ledger.flush()
            total_entries += native.calls
        finally:
            oracle.close()
            native.close()
finally:
    ledger.close()
summary = {'scope': 'FORGED_NATIVE_FRAME_DIFFERENTIAL_REAL_TRANSPORT_IMAGES', 'cases': len(cases),
           'actual_native_entries': total_entries, 'ABI_refusals': refused,
           'semantic_refusals': semantic, 'accepted_controls': accepted,
           'full_descriptor_counter_and_broken_state_equal': True,
           'fail_closed_all_three_followups': True, 'passed': True,
           'encoding_equivalence': 'UNTESTED_AND_UNCLOSED', 'cold_qualified': False}
(target / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary), flush=True)
