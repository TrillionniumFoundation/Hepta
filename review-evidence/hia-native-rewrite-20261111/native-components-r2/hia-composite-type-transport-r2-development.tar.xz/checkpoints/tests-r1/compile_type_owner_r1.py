"""Actual unchanged HIA type-owner dependency, source-bound development only."""
from pathlib import Path
from hashlib import sha256
import json
from tools.qualify_hia_selfhost import compile_stage

root = Path(__file__).resolve().parent
output = root / 'compile-types-r1'
output.mkdir(exist_ok=False)
source = Path('/workspace/scratch/9acdfa9f5639/native-agent-state-integration/examples/hia_bootstrap/composite_types.hiaasm')
compiler = Path('/workspace/scratch/9acdfa9f5639/hia-f50-compiler-custody/B3.image.bin')
source_raw, compiler_raw = source.read_bytes(), compiler.read_bytes()
assert sha256(compiler_raw).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
image, receipt = compile_stage(output, 'composite-types', compiler, source_raw)
assert source.read_bytes() == source_raw and compiler.read_bytes() == compiler_raw
assert receipt['input_sha256'] == sha256(source_raw).hexdigest()
manifest = {'schema': 'hepta.hia.composite-types-native.v1', 'source_path': str(source),
            'source_sha256': sha256(source_raw).hexdigest(), 'image_path': str(image),
            'image_sha256': sha256(image.read_bytes()).hexdigest(),
            'scope': 'DEVELOPMENT_NOT_CURRENT_COLD_QUALIFIED',
            'compiler_sha256': sha256(compiler_raw).hexdigest()}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps(manifest), flush=True)
