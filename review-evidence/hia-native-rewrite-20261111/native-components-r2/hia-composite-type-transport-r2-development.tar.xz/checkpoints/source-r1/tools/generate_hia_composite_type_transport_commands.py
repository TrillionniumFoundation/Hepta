"""BEGIN / QUERY half of the native issued-type transport owner."""
from __future__ import annotations
import ast
import copy

BODY = r'''
def command_entry(c:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < CONTROL_BYTES or length(o) < 128:
        return poison(w, 1)
    if get(w, S_BROKEN) != 0:
        return BAD
    if length(c) < 64:
        return poison(w, 2)
    magic = read(c, 0)
    if magic != BEGIN_MAGIC and magic != QUERY_MAGIC:
        return poison(w, 3)
    if get(w, S_MAGIC) == 0:
        if magic != BEGIN_MAGIC or read(c, 8) == 0 or read(c, 16) != 1 or read(c, 24) != 1:
            return poison(w, 4)
        at = 0
        while at < CONTROL_BYTES:
            if get(w, at) != 0:
                return poison(w, 5)
            at = at + 8
        put(w, S_MAGIC, STATE_MAGIC)
        put(w, S_LEASE, read(c, 8))
        put(w, S_HEAP, CONTROL_BYTES)
        put(w, S_MEMORY_BYTES, length(w))
        put(w, S_JSON_STACK_END, length(w))
    if get(w, S_MAGIC) != STATE_MAGIC or read(c, 8) != get(w, S_LEASE):
        return poison(w, 6)
    if resume_memory(w) == 0:
        return BAD
    if magic == QUERY_MAGIC:
        return query_entry(c, o, w)
    if read(c, 48) != 0 or read(c, 56) != 0 or read(c, 40) != length(c) - 64:
        return poison(w, 20)
    if read(c, 40) < 16 or read(c, 40) > PACKET_LIMIT:
        return poison(w, 21)
    operation = read(c, 24)
    if operation < 1 or operation > 6:
        return poison(w, 22)
    phase = get(w, S_PHASE)
    if phase == 10:
        if read(c, 16) != get(w, S_PENDING_SEQ) or operation != get(w, S_PENDING_OP):
            return poison(w, 23)
        if read(c, 32) != get(w, S_PENDING_REQUEST) or length(c) != get(w, S_INPUT_SIZE):
            return poison(w, 24)
    else:
        if phase != 0 and phase != 2:
            return poison(w, 25)
        if get(w, S_COMPLETED_SEQ) == MAX or read(c, 16) != get(w, S_COMPLETED_SEQ) + 1:
            return poison(w, 26)
        put(w, S_PENDING_SEQ, read(c, 16))
        put(w, S_PENDING_OP, operation)
        put(w, S_PENDING_REQUEST, read(c, 32))
        put(w, S_INPUT_SIZE, length(c))
        put(w, S_PHASE, 10)
        put(w, S_SCRATCH_BASE, get(w, S_HEAP))
        put(w, S_SCRATCH_USED, 0)
        put(w, S_JSON_DEPTH, 0)
    clear_result(w)
    put(w, S_OUT_SEQ, get(w, S_PENDING_SEQ))
    put(w, S_OUT_REQUEST, get(w, S_PENDING_REQUEST))
    put(w, S_OUT_OP, operation)
    put(w, S_VALID_BASE, get(w, S_HEAP))
    required = command_capacity(read(c, 40))
    if reserve(w, get(w, S_VALID_BASE) + required, 0) == 0:
        if get(w, S_BROKEN) != 0:
            return BAD
        return publish(o, w, 1)
    zero_words(w, get(w, S_VALID_BASE), 128)
    if validate_command(c, w) == 0:
        return poison(w, 27)
    if vget(w, 32) > COMMAND_LIMIT:
        return poison(w, 28)
    size = read(c, 40)
    if reserve(w, get(w, S_HEAP) + size, 0) == 0:
        return publish(o, w, 1)
    copy_bytes(w, c, get(w, S_HEAP), 64, size)
    put(w, S_COMMAND_REL, 0)
    put(w, S_COMMAND_SIZE, size)
    put(w, S_SCRATCH_USED, align8(size))
    if command_custody(w, get(w, S_HEAP), operation) == 0:
        return BAD
    put(w, S_PHASE, 1)
    return publish(o, w, 0)

def query_entry(c:readbuf, o:mutbuf, w:mutbuf) -> u64:
    if length(c) != 64 or read(c, 40) != 0 or read(c, 48) != 0 or read(c, 56) != 0:
        return poison(w, 30)
    if get(w, S_PHASE) != 2 or read(c, 16) != get(w, S_COMPLETED_SEQ):
        return poison(w, 31)
    if get(w, S_QUERY_SEQ) == MAX or read(c, 24) != get(w, S_QUERY_SEQ) + 1:
        return poison(w, 32)
    target = issued(w, read(c, 32))
    if target == 0:
        return poison(w, 33)
    clear_result(w)
    put(w, S_SCRATCH_BASE, get(w, S_HEAP))
    put(w, S_SCRATCH_USED, 0)
    put(w, S_QUERY_SEQ, read(c, 24))
    put(w, S_OUT_SEQ, get(w, S_COMPLETED_SEQ))
    put(w, S_OUT_REQUEST, get(w, S_QUERY_SEQ))
    put(w, S_OUT_OP, 0)
    put(w, S_OUT_ID, read(c, 32))
    put(w, S_OUT_KIND, 4)
    put(w, S_OUT_COUNT, 1)
    put(w, S_OUT_PTR, target)
    put(w, S_OUT_BYTES, 16 + get(w, target + 8))
    return publish(o, w, 0)

def command_capacity(size:u64) -> u64:
    slots = 2
    while slots < (size >> 5) * 2:
        slots = slots * 2
    stack = align8(128 + slots * 16 + ((size + 7) >> 3))
    return stack + (pv_divide24(size) + 1) * 32

def vget(w:mutbuf, at:u64) -> u64:
    return get(w, get(w, S_VALID_BASE) + at)

def vput(w:mutbuf, at:u64, value:u64) -> u64:
    return put(w, get(w, S_VALID_BASE) + at, value)

def validate_command(c:readbuf, w:mutbuf) -> u64:
    if pv_initialize(c, w) == 0:
        return 0
    at = 0
    size = length(c) - 64
    while at < size or vget(w, 64) != 0:
        depth = vget(w, 64)
        if depth != 0 and vget(w, vget(w, 56) + (depth - 1) * 32 + 8) == 0:
            frame = vget(w, 56) + (depth - 1) * 32
            if at != vget(w, frame):
                return 0
            vput(w, 64, depth - 1)
        else:
            following = pv_validate_node(c, w, at)
            if following == MAX:
                return 0
            at = following
    return choose(vget(w, 72) == 1 and at == size, 1, 0)

def command_custody(w:mutbuf, root:u64, operation:u64) -> u64:
    key = K_init
    if operation == 2:
        key = K_parameters
    elif operation == 3:
        key = K_resolve
    elif operation == 4:
        key = K_partial
    elif operation == 5:
        key = K_origins
    elif operation == 6:
        key = K_task_protocol
    if get(w, root) != 6 or word(w, field(w, root, K_op), key) == 0:
        poison(w, 40)
        return 0
    if operation == 4:
        if issued(w, identifier(w, field(w, root, K_base))) == 0:
            poison(w, 41)
            return 0
    elif operation == 5:
        params = field(w, root, K_params)
        returns = field(w, root, K_returns)
        if params == MAX or get(w, params) != 5 or id_list(w, returns) == 0:
            poison(w, 42)
            return 0
        count = get(w, params + 16)
        at = params + 24
        i = 0
        while i < count:
            if get(w, at) != 5 or get(w, at + 16) != 2 or get(w, at + 24) != 4:
                poison(w, 43)
                return 0
            if issued(w, identifier(w, end_node(w, at + 24))) == 0:
                poison(w, 44)
                return 0
            at = end_node(w, at)
            i = i + 1
        put(w, S_ORIGIN_COUNT, get(w, returns + 16))
        put(w, S_ORIGIN_PARAMS, params - get(w, S_SCRATCH_BASE))
    elif operation == 6:
        if issued(w, identifier(w, field(w, root, K_task))) == 0:
            poison(w, 45)
            return 0
        functions = field(w, root, K_functions)
        if functions == MAX or get(w, functions) != 5:
            poison(w, 46)
            return 0
        at = functions + 24
        count = get(w, functions + 16)
        i = 0
        while i < count:
            if get(w, at) != 5 or get(w, at + 16) != 3:
                poison(w, 47)
                return 0
            params = end_node(w, at + 24)
            if id_list(w, params) == 0 or id_list(w, end_node(w, params)) == 0:
                poison(w, 48)
                return 0
            at = end_node(w, at)
            i = i + 1
    return 1

def id_list(w:mutbuf, node:u64) -> u64:
    if node == MAX or get(w, node) != 5:
        return 0
    at = node + 24
    count = get(w, node + 16)
    i = 0
    while i < count:
        if issued(w, identifier(w, at)) == 0:
            return 0
        at = end_node(w, at)
        i = i + 1
    return 1
'''


def validation_source():
    # Retain the complete, independently reviewed HIA packet grammar. Only
    # relocate its input past the BEGIN header and its private scratch region.
    from tools.generate_hia_composite_packet_json import source_program
    keep = {'initialize', 'validate_node', 'node_width', 'integer_width',
            'divide24', 'string_width', 'utf8', 'same_key', 'unique_key'}
    nodes = [copy.deepcopy(node) for node in ast.parse(source_program()).body if node.name in keep]

    class Relocate(ast.NodeTransformer):
        def visit_Call(self, node):
            node = self.generic_visit(node)
            if not isinstance(node.func, ast.Name):
                return node
            name = node.func.id
            source = node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == 's'
            workspace = node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == 'w'
            if name in keep:
                node.func.id = 'pv_' + name
            elif name == 'get' and workspace:
                node.func.id = 'vget'
            elif name == 'put' and workspace:
                node.func.id = 'vput'
            elif name in ('read', 'byte') and source:
                node.args[1] = ast.BinOp(ast.Constant(64), ast.Add(), node.args[1])
            elif name in ('byte', 'store') and workspace:
                base = ast.Call(ast.Name('get', ast.Load()), [ast.Name('w', ast.Load()), ast.Name('S_VALID_BASE', ast.Load())], [])
                node.args[1] = ast.BinOp(base, ast.Add(), node.args[1])
            elif name == 'length' and source:
                return ast.BinOp(node, ast.Sub(), ast.Constant(64))
            elif name == 'length' and workspace:
                base = ast.Call(ast.Name('get', ast.Load()), [ast.Name('w', ast.Load()), ast.Name('S_VALID_BASE', ast.Load())], [])
                return ast.BinOp(node, ast.Sub(), base)
            return node

    for node in nodes:
        node.name = 'pv_' + node.name
        Relocate().visit(node)
    return ast.unparse(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))) + '\n'
