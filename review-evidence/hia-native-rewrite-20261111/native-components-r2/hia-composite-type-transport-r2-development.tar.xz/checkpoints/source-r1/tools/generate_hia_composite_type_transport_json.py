"""Private response JSON decoder for the HIA issued-type transport.

The HIA state machine accepts a whole 64 MiB native frame, dynamically grows its
stack and packet arena, and validates all JSON before descriptor validation.
It does not call the public JSON decoder or inherit its node/depth quota.
"""
from __future__ import annotations
import ast
import copy

BODY = r'''
def json_mark_value(w:mutbuf, key:u64) -> u64:
    depth = get(w, S_JSON_DEPTH)
    if depth == 0:
        put(w, S_JSON_COMPLETE, 1)
    else:
        frame = get(w, S_JSON_STACK_END) - depth * 64
        if key != 0:
            put(w, frame + 16, 3)
        else:
            put(w, frame + 16, 2)
            put(w, frame + 24, get(w, frame + 24) + 1)
    return 0

def json_scalar(w:mutbuf, cp:u64) -> u64:
    size = 1
    if cp >= 128:
        size = choose(cp < 2048, 2, choose(cp < 65536, 3, 4))
    at = get(w, S_JSON_AT)
    if reserve(w, scratch_node(w, at) + size, get(w, S_JSON_DEPTH)) == 0:
        return 0
    target = scratch_node(w, at)
    if size == 1:
        store(w, target, cp)
    elif size == 2:
        store(w, target, 192 | (cp >> 6))
        store(w, target + 1, 128 | (cp & 63))
    elif size == 3:
        store(w, target, 224 | (cp >> 12))
        store(w, target + 1, 128 | ((cp >> 6) & 63))
        store(w, target + 2, 128 | (cp & 63))
    else:
        store(w, target, 240 | (cp >> 18))
        store(w, target + 1, 128 | ((cp >> 12) & 63))
        store(w, target + 2, 128 | ((cp >> 6) & 63))
        store(w, target + 3, 128 | (cp & 63))
    put(w, S_JSON_AT, at + size)
    put(w, S_SCRATCH_USED, at + size)
    return 1

def json_string(c:readbuf, w:mutbuf) -> u64:
    while True:
        at = get(w, S_JSON_POS)
        unit = json_decoded(c, at)
        cp = unit & 4294967295
        if cp == 1114113:
            poison(w, 100)
            return 0
        if cp == 1114112:
            node = get(w, S_JSON_STRING_NODE)
            put(w, scratch_node(w, node) + 8, get(w, S_JSON_AT) - node - 16)
            put(w, S_JSON_STRING_NODE, MAX)
            put(w, S_JSON_POS, unit >> 32)
            json_mark_value(w, get(w, S_JSON_STRING_KEY))
            return 1
        if json_scalar(w, cp) == 0:
            return 0
        put(w, S_JSON_POS, unit >> 32)
    return 0

def json_unique_keys(w:mutbuf, node:u64, count:u64) -> u64:
    at = node + 24
    i = 0
    while i < count:
        previous = node + 24
        j = 0
        while j < i:
            if same_string(w, at, previous) == 1:
                poison(w, 101)
                return 0
            previous = end_node(w, end_node(w, previous))
            j = j + 1
        at = end_node(w, end_node(w, at))
        i = i + 1
    return 1

def json_close(w:mutbuf, index:u64) -> u64:
    depth = get(w, S_JSON_DEPTH)
    frame = get(w, S_JSON_STACK_END) - depth * 64
    relative = get(w, frame)
    node = scratch_node(w, relative)
    count = get(w, frame + 24)
    if get(w, frame + 8) == 6 and json_unique_keys(w, node, count) == 0:
        return 0
    put(w, node + 8, get(w, S_JSON_AT) - relative - 16)
    put(w, node + 16, count)
    put(w, S_JSON_DEPTH, depth - 1)
    put(w, S_JSON_POS, index + 1)
    return 1

def json_number(c:readbuf, w:mutbuf, at:u64) -> u64:
    cursor = at
    if byte(c, cursor) == 45:
        cursor = cursor + 1
    if cursor >= length(c):
        return MAX
    ch = byte(c, cursor)
    if ch < 48 or ch > 57:
        return MAX
    cursor = cursor + 1
    if ch != 48:
        going = True
        while going and cursor < length(c):
            ch = byte(c, cursor)
            if ch < 48 or ch > 57:
                going = False
            else:
                cursor = cursor + 1
    kind = 2
    if cursor < length(c) and byte(c, cursor) == 46:
        kind = 3
        cursor = cursor + 1
        begin = cursor
        going = True
        while going and cursor < length(c):
            ch = byte(c, cursor)
            if ch < 48 or ch > 57:
                going = False
            else:
                cursor = cursor + 1
        if cursor == begin:
            return MAX
    if cursor < length(c) and (byte(c, cursor) == 101 or byte(c, cursor) == 69):
        kind = 3
        cursor = cursor + 1
        if cursor < length(c) and (byte(c, cursor) == 43 or byte(c, cursor) == 45):
            cursor = cursor + 1
        begin = cursor
        going = True
        while going and cursor < length(c):
            ch = byte(c, cursor)
            if ch < 48 or ch > 57:
                going = False
            else:
                cursor = cursor + 1
        if cursor == begin:
            return MAX
    put(w, S_JSON_NUMBER_KIND, kind)
    return cursor

def json_atom(c:readbuf, w:mutbuf, index:u64) -> u64:
    ch = byte(c, index)
    kind = 0
    size = 0
    end = index
    boolean = 0
    negative_zero = 0
    if ch == 110 and length(c) - index >= 4:
        if byte(c, index + 1) != 117 or byte(c, index + 2) != 108 or byte(c, index + 3) != 108:
            poison(w, 102)
            return 0
        end = index + 4
    elif ch == 116 and length(c) - index >= 4:
        if byte(c, index + 1) != 114 or byte(c, index + 2) != 117 or byte(c, index + 3) != 101:
            poison(w, 102)
            return 0
        kind = 1
        size = 1
        boolean = 1
        end = index + 4
    elif ch == 102 and length(c) - index >= 5:
        if byte(c, index + 1) != 97 or byte(c, index + 2) != 108 or byte(c, index + 3) != 115 or byte(c, index + 4) != 101:
            poison(w, 102)
            return 0
        kind = 1
        size = 1
        end = index + 5
    else:
        if ch != 45 and (ch < 48 or ch > 57):
            poison(w, 102)
            return 0
        end = json_number(c, w, index)
        if end == MAX:
            poison(w, 103)
            return 0
        kind = get(w, S_JSON_NUMBER_KIND)
        size = end - index
        negative_zero = choose(kind == 2 and size == 2 and byte(c, index) == 45 and byte(c, index + 1) == 48, 1, 0)
        if negative_zero != 0:
            size = 1
    relative = get(w, S_JSON_AT)
    node = scratch_node(w, relative)
    if reserve(w, node + 16 + size, get(w, S_JSON_DEPTH)) == 0:
        return 0
    put(w, node, kind)
    put(w, node + 8, size)
    if kind == 1:
        store(w, node + 16, boolean)
    elif kind == 2 or kind == 3:
        if negative_zero != 0:
            store(w, node + 16, 48)
        else:
            copy_bytes(w, c, node + 16, index, size)
    if get(w, S_JSON_DEPTH) == 0:
        put(w, S_JSON_ROOT, relative)
    put(w, S_JSON_AT, relative + 16 + size)
    put(w, S_SCRATCH_USED, relative + 16 + size)
    put(w, S_JSON_POS, end)
    json_mark_value(w, 0)
    return 1

def json_value(c:readbuf, w:mutbuf, index:u64, key:u64) -> u64:
    ch = byte(c, index)
    depth = get(w, S_JSON_DEPTH)
    relative = get(w, S_JSON_AT)
    node = scratch_node(w, relative)
    if ch == 34:
        if reserve(w, node + 16, depth) == 0:
            return 0
        put(w, node, 4)
        put(w, node + 8, 0)
        if depth == 0:
            put(w, S_JSON_ROOT, relative)
        put(w, S_JSON_AT, relative + 16)
        put(w, S_SCRATCH_USED, relative + 16)
        put(w, S_JSON_STRING_NODE, relative)
        put(w, S_JSON_STRING_KEY, key)
        put(w, S_JSON_POS, index + 1)
        return 1
    if key != 0:
        poison(w, 104)
        return 0
    if ch == 91 or ch == 123:
        if reserve(w, node + 24, depth + 1) == 0:
            return 0
        kind = choose(ch == 91, 5, 6)
        put(w, node, kind)
        put(w, node + 8, 0)
        put(w, node + 16, 0)
        if depth == 0:
            put(w, S_JSON_ROOT, relative)
        json_mark_value(w, 0)
        frame = get(w, S_JSON_STACK_END) - (depth + 1) * 64
        zero_words(w, frame, 64)
        put(w, frame, relative)
        put(w, frame + 8, kind)
        put(w, S_JSON_DEPTH, depth + 1)
        put(w, S_JSON_AT, relative + 24)
        put(w, S_SCRATCH_USED, relative + 24)
        put(w, S_JSON_POS, index + 1)
        return 1
    return json_atom(c, w, index)

def json_scan(c:readbuf, w:mutbuf) -> u64:
    while True:
        if get(w, S_BROKEN) != 0:
            return 0
        if get(w, S_JSON_STRING_NODE) != MAX:
            if json_string(c, w) == 0:
                return 0
        else:
            index = json_whitespace(c, get(w, S_JSON_POS))
            put(w, S_JSON_POS, index)
            depth = get(w, S_JSON_DEPTH)
            if depth == 0 and get(w, S_JSON_COMPLETE) != 0:
                if index != length(c):
                    poison(w, 105)
                    return 0
                put(w, S_REPLY_REL, get(w, S_JSON_ROOT))
                put(w, S_REPLY_SIZE, get(w, S_JSON_AT) - get(w, S_JSON_ROOT))
                return 1
            if index >= length(c):
                poison(w, 106)
                return 0
            ch = byte(c, index)
            key = 0
            dispatch = 1
            if depth != 0:
                frame = get(w, S_JSON_STACK_END) - depth * 64
                kind = get(w, frame + 8)
                state = get(w, frame + 16)
                closing = choose(kind == 5, 93, 125)
                if state == 0 and ch == closing:
                    if json_close(w, index) == 0:
                        return 0
                    dispatch = 0
                elif state == 0 or state == 1:
                    key = choose(kind == 6, 1, 0)
                elif state == 2:
                    if ch == 44:
                        put(w, frame + 16, 1)
                        put(w, S_JSON_POS, index + 1)
                    elif ch == closing:
                        if json_close(w, index) == 0:
                            return 0
                    else:
                        poison(w, 107)
                        return 0
                    dispatch = 0
                elif state == 3:
                    if ch != 58:
                        poison(w, 108)
                        return 0
                    put(w, frame + 16, 4)
                    put(w, S_JSON_POS, index + 1)
                    dispatch = 0
                elif state != 4:
                    poison(w, 109)
                    return 0
            if dispatch != 0:
                if json_value(c, w, index, key) == 0:
                    return 0
    return 0
'''


def lexical_source():
    # No public entry/gate is copied. These leaf functions only decode a JSON
    # code point, a four-hex escape, or whitespace within the supplied extent.
    from tools.generate_hia_json_preflight import SOURCE
    nodes = [copy.deepcopy(node) for node in ast.parse(SOURCE).body
             if node.name in {'decoded', 'hex4', 'whitespace'}]

    class Rename(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id in {'decoded', 'hex4', 'whitespace'}:
                node.id = 'json_' + node.id
            return node

    for node in nodes:
        node.name = 'json_' + node.name
        Rename().visit(node)
    return ast.unparse(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))) + '\n'
