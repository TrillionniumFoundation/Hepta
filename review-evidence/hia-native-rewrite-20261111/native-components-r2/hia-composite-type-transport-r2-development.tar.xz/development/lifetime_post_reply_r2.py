"""Original command byte limits and explicit fixed-driver init cleanup.

The init cleanup exercised here is a mechanical development driver obligation,
not a claim that the not-yet-integrated coordinator or public entry is changed.
"""
from pathlib import Path
from hashlib import sha256
from threading import RLock
from types import SimpleNamespace
import ctypes
import gc
import json
import resource
import struct
import weakref
from unittest.mock import patch

from transport_harness import NativeTransport, BAD, frame
from hepta.hia_composite_types_native import (NativeCompositeTypes, NativeCompositeTypeSession,
                                             ERRORS, SESSION_BYTES, OUTPUT_BYTES, MAX_COMMAND_BYTES)
from hepta.hia_program import HIAProgramRejected
from hepta import hia_program_composite as composite

resource.setrlimit(resource.RLIMIT_CPU,(45,45))
resource.setrlimit(resource.RLIMIT_AS,(1024<<20,1024<<20))
root=Path(__file__).resolve().parent
target=Path('/dev/shm/hia-type-transport-lifetime-post-reply-r2')
target.mkdir(exist_ok=False)
initial=(root/'actual-pipeline-r1/000-types-response.bin').read_bytes()
init=dict(op='init',definitions=[],recursive_chain=True,partial_records=True)
outcomes=[]
total_entries=0


def canonical(command):
    return json.dumps(command,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()


def old_session():
    queue=[initial]
    calls=[]
    def entry(source,size,output,capacity,state,state_size):
        calls.append(size)
        value=queue.pop(0);ctypes.memmove(output,value,len(value));return len(value)
    old=NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)
    old._image=SimpleNamespace(_entry=entry);old._lock=RLock();old._nonce=object()
    old._types={};old._ids={};old._descriptors={};old._observations={}
    old._broken=old._closed=False
    old._state=ctypes.create_string_buffer(1);old._output=ctypes.create_string_buffer(65536)
    old._command(init,result=False)
    return old,queue,calls


manifest_path=root/'compile-types-r1/manifest.json'
manifest_raw=manifest_path.read_bytes();manifest=json.loads(manifest_raw)
image_raw=Path(manifest['image_path']).read_bytes();source_raw=Path(manifest['source_path']).read_bytes()
assert sha256(image_raw).hexdigest()==manifest['image_sha256']
assert sha256(source_raw).hexdigest()==manifest['source_sha256']
image=NativeCompositeTypes(image_raw,manifest['image_sha256'])
real_entry=image._entry
native_type_calls=[]
old_weakrefs={}


def old_entry(source,size,output,capacity,state,state_size):
    old_weakrefs['output']=weakref.ref(output);old_weakrefs['state']=weakref.ref(state)
    result=real_entry(source,size,output,capacity,state,state_size)
    native_type_calls.append('original_init_failure')
    (target/'original-init-failure-frame.bin').write_bytes(ctypes.string_at(output,result))
    return result


image._entry=old_entry
old=NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)
old_held=None
try:
    old.__init__(image,None,recursive_chain=True,partial_records=True)
except HIAProgramRejected as exc:
    old_held=exc
assert old_held is not None and old._closed
gc.collect()
assert all(reference() is None for reference in old_weakrefs.values())
old_code,old_text=old_held.code,str(old_held)


class MechanicalDriver:
    def __init__(self):
        self.state=self.output=self.transport=None
        self.refs={}
        self.closed=False
        self.event=None

    def start(self):
        try:
            self.output=ctypes.create_string_buffer(OUTPUT_BYTES)
            self.state=ctypes.create_string_buffer(SESSION_BYTES)
            self.transport=NativeTransport(root/'compile-r2/bundle.json',ledger=target/'init-failure-transport.jsonl')
            self.refs={'output':weakref.ref(self.output),'state':weakref.ref(self.state)}
            command=dict(op='init',definitions=None,recursive_chain=True,partial_records=True)
            assert self.transport.begin(command,1)[0]==128
            # Observe the actual live workspace after any admission GROW.
            self.refs['transport']=weakref.ref(self.transport.workspace)
            raw=canonical(command);source=ctypes.create_string_buffer(raw)
            extent=real_entry(source,len(raw),self.output,OUTPUT_BYTES,self.state,SESSION_BYTES)
            native_type_calls.append('new_driver_init_failure')
            assert 64<=extent<=OUTPUT_BYTES
            response=ctypes.string_at(self.output,extent)
            (target/'new-init-failure-frame.bin').write_bytes(response)
            assert response==(target/'original-init-failure-frame.bin').read_bytes()
            status,self.event,payload=self.transport.reply(response)
            self.refs['transport_after_reply']=weakref.ref(self.transport.workspace)
            assert status==128 and self.event[6] and not payload
            code,message=ERRORS[self.event[6]]
            raise HIAProgramRejected(message,code)
        except BaseException:
            self.close()
            raise

    def close(self):
        self.closed=True
        self.state=self.output=None
        if self.transport is not None:
            self.transport.close()


def forbidden(*args,**kwargs):
    raise AssertionError('host type owner/materializer called in native path')


driver=MechanicalDriver();held=None
with patch.object(composite,'_Types',forbidden), \
     patch.object(NativeCompositeTypeSession,'_command',forbidden), \
     patch.object(NativeCompositeTypeSession,'_materialize_value',forbidden):
    try:
        driver.start()
    except HIAProgramRejected as exc:
        held=exc
assert held is not None and (held.code,str(held))==(old_code,old_text)
driver.close();driver.close()
gc.collect()
assert driver.closed and all(reference() is None for reference in driver.refs.values())
assert driver.transport.workspace is None
outcomes.append(dict(name='actual_init_failure_held_exception_discard_obligation',passed=True,
    code=held.code,text=str(held),old_session_closed=old._closed,new_driver_closed=driver.closed,
    original_buffers_collected=list(old_weakrefs),new_buffers_collected=list(driver.refs),
    held_exception_still_present=True,close_idempotent=True,
    scope='MECHANICAL_DEV_DRIVER_OBLIGATION_NOT_YET_PUBLIC_COORDINATOR'))
total_entries+=driver.transport.calls
assert manifest_path.read_bytes()==manifest_raw
assert Path(manifest['image_path']).read_bytes()==image_raw
assert Path(manifest['source_path']).read_bytes()==source_raw
summary=dict(scope='ACTUAL_INIT_FAILURE_HELD_EXCEPTION_ALL_LIVE_BUFFERS',passed=True,
             controls=len(outcomes),actual_transport_entries=total_entries,
             actual_type_entries=len(native_type_calls),all_original_bounds_unchanged=True,
             production_coordinator_integrated=False,cold_qualified=False)
(target/'outcomes.json').write_text(json.dumps(outcomes,indent=2,sort_keys=True)+'\n')
(target/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
