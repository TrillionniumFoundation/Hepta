"""Development test custody only: fixed native dispatch, no type semantics."""
from __future__ import annotations
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import struct

from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_json_preflight_native import NativeHiaJsonImage

BAD = 0xfffffffd
MAGIC = {name: int.from_bytes(word, 'little') for name, word in {
    'begin': b'HIATRB01', 'reply': b'HIATRR01', 'query': b'HIATRQ01',
    'event': b'HIATRE01'}.items()}


class NativeTransport:
    def __init__(self, bundle, *, lease=1, workspace=4096, ledger=None):
        self.bundle_path = Path(bundle)
        self.pins = {}
        def pin(path, raw):
            if path in self.pins and self.pins[path] != raw:
                raise ValueError('one path changed between custody roles')
            self.pins[path] = raw
        raw = self.bundle_path.read_bytes()
        pin(self.bundle_path, raw)
        value = json.loads(raw)
        if value['scope'] != 'SOURCE_BOUND_DEVELOPMENT_NOT_COLD_QUALIFIED' or value['status'] != 'PASS':
            raise ValueError('not an exact development bundle')
        snapshots = {}
        for name in ('commands', 'reply'):
            row = value['components'][name]
            if row['schema'] != 'hepta.hia.composite-type-transport-' + name + '-native.v1':
                raise ValueError('wrong image schema')
            current_path = Path(__file__).resolve().parents[1] / 'examples/hia_bootstrap' / (
                'composite_type_transport_' + name + '.hiaasm')
            current_raw = current_path.read_bytes()
            pin(current_path, current_raw)
            if sha256(current_raw).hexdigest() != row['source_sha256']:
                raise ValueError('component source is not the current exact owner')
            for label in ('source', 'image'):
                path = Path(row[label + '_path'])
                source = path.read_bytes()
                if sha256(source).hexdigest() != row[label + '_sha256']:
                    raise ValueError('changed source/image')
                pin(path, source)
                if label == 'source' and source != current_raw:
                    raise ValueError('frozen source differs from current owner')
                if label == 'image':
                    snapshots[name] = (source, row['image_sha256'])
        for path, source in self.pins.items():
            if path.read_bytes() != source:
                raise ValueError('custody changed before mapping')
        self.images = {name: NativeHiaJsonImage(*pair) for name, pair in snapshots.items()}
        self.lease, self.sequence, self.query_sequence = lease, 0, 0
        self.size = workspace
        self.workspace = ctypes.create_string_buffer(workspace + 32)
        ctypes.memset(ctypes.addressof(self.workspace) + workspace, 0xb7, 32)
        self.ledger = Path(ledger).open('w') if ledger else None
        self.calls, self.grows = 0, 0

    def call(self, which, wire, *, auto_grow=True):
        assert type(wire) is bytes
        source = ctypes.create_string_buffer(wire + bytes([0xa7]) * 32)
        while True:
            output = ctypes.create_string_buffer(bytes([0xa5]) * 160)
            result = self.images[which]._entry(source, len(wire), output, 128, self.workspace, self.size)
            self.calls += 1
            assert ctypes.string_at(source, len(wire) + 32) == wire + bytes([0xa7]) * 32
            assert ctypes.string_at(ctypes.addressof(output) + 128, 32) == bytes([0xa5]) * 32
            assert ctypes.string_at(ctypes.addressof(self.workspace) + self.size, 32) == bytes([0xb7]) * 32
            words = struct.unpack('<16Q', ctypes.string_at(output, 128)) if result == 128 else None
            if self.ledger:
                self.ledger.write(json.dumps({'image': which, 'input_bytes': len(wire),
                    'input_sha256': sha256(wire).hexdigest(), 'return': result,
                    'event': words, 'workspace_bytes': self.size,
                    'reason': struct.unpack_from('<Q', self.workspace, 16)[0]}) + '\n')
                self.ledger.flush()
            if result != 128:
                return result, None, None
            assert words[0] == MAGIC['event']
            if words[1] == 1 and auto_grow:
                needed = words[15]
                assert self.size < needed <= 1 << 30
                new = ctypes.create_string_buffer(needed + 32)
                ctypes.memmove(new, self.workspace, self.size)
                ctypes.memset(ctypes.addressof(new) + needed, 0xb7, 32)
                self.workspace, self.size = new, needed
                self.grows += 1
                continue
            if words[14]:
                assert words[13] <= self.size and words[14] <= self.size - words[13]
                payload = ctypes.string_at(ctypes.addressof(self.workspace) + words[13], words[14])
            else:
                payload = b''
            return result, words, payload

    def begin(self, command, operation, *, request=None):
        self.sequence += 1
        self.operation = operation
        self.request = self.sequence if request is None else request
        packet = transport(command)
        wire = struct.pack('<8Q', MAGIC['begin'], self.lease, self.sequence,
                           operation, self.request, len(packet), 0, 0) + packet
        return self.call('commands', wire)

    def reply(self, native):
        wire = struct.pack('<8Q', MAGIC['reply'], self.lease, self.sequence,
                           self.operation, self.request, len(native), 0, 0) + native
        return self.call('reply', wire)

    def query(self, identifier):
        self.query_sequence += 1
        wire = struct.pack('<8Q', MAGIC['query'], self.lease, self.sequence,
                           self.query_sequence, identifier, 0, 0, 0)
        result, event, payload = self.call('commands', wire)
        if result == 128:
            assert event[11:13] == (4, 1)
            return detached_packet_index(payload)[0]
        return result

    def close(self):
        for path, raw in self.pins.items():
            assert path.read_bytes() == raw
        self.workspace = None
        if self.ledger:
            self.ledger.close()
            self.ledger = None


def frame(value, *, identifier=0, error=0, counters=(0, 0, 0), magic=b'HIATYP01'):
    payload = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
    return struct.pack('<8Q', int.from_bytes(magic, 'little'), error,
                       identifier, len(payload), *counters, 0) + payload


def descriptor(identifier, name, *, kind='record', fields=(), args=(), flat=(),
               variants=(), state=None, result=None, poll=None, cancel=None,
               linear=False, record=None):
    return {'id': identifier, 'kind': kind, 'name': name, 'args': list(args),
            'flat': list(flat), 'fields': [list(pair) for pair in fields],
            'variants': [[name, [list(pair) for pair in values]] for name, values in variants],
            'state': state, 'result': result, 'poll': poll, 'cancel': cancel,
            'linear': linear, 'record': record}
