"""Pin original private json.loads(bytes) compatibility, without scope hiding.

Native-image output injection is deliberately private. The public source path
does not choose the bytes emitted by the HIA types owner. These controls still
describe behavior of the existing adapter that a complete replacement must
preserve or explicitly leave unclosed.
"""
from pathlib import Path
from hashlib import sha256
from threading import RLock
from types import SimpleNamespace
import ctypes
import json
import struct

from transport_harness import NativeTransport, descriptor
from hepta.hia_composite_types_native import NativeCompositeTypeSession
from hepta.hia_program import HIAProgramRejected

root=Path(__file__).resolve().parent
target=root/'private-encoding-r1'
target.mkdir(exist_ok=False)
initial=(root/'actual-pipeline-r1/000-types-response.bin').read_bytes()
init=dict(op='init',definitions=[],recursive_chain=True,partial_records=True)
baseline=descriptor(17,'N\u00e9\U0001f600',fields=[('field\n\t\x00',9)])
plain=json.dumps({'types':[baseline]},ensure_ascii=False,separators=(',',':'))
cases=[]
for encoding in ('utf-8','utf-8-sig','utf-16','utf-16-le','utf-16-be','utf-32','utf-32-le','utf-32-be'):
    cases.append((encoding,plain.encode(encoding)))
for label,text,encoding in [
    ('escaped_lone_high','\ud800','ascii'),('escaped_lone_low','\udfff','ascii'),
    ('escaped_pair','\ud800\udc00','ascii'),
    ('raw_wtf8_lone_high','\ud800','utf-8'),('raw_wtf8_lone_low','\udfff','utf-8'),
    ('raw_utf16_lone_high','\ud800','utf-16'),('raw_utf32_lone_low','\udfff','utf-32'),
]:
    value={'types':[dict(baseline,name=text)]}
    encoded=json.dumps(value,ensure_ascii=encoding=='ascii',separators=(',',':')).encode(encoding,errors='surrogatepass')
    cases.append((label,encoded))
cases += [('invalid_utf8',b'{"types":"\xff"}'),
          ('truncated_utf16',plain.encode('utf-16')[:-1]),
          ('invalid_utf32_codepoint',b'\xff\xfe\x00\x00'+b'\xff\xff\xff\xff')]
outcomes=[]
for name,payload in cases:
    raw=struct.pack('<8Q',int.from_bytes(b'HIATYP01','little'),0,17,len(payload),7,3,19,0)+payload
    (target/(name+'.bin')).write_bytes(raw)
    waiting=[initial,raw]
    def entry(source,size,output,capacity,state,state_size):
        value=waiting.pop(0);ctypes.memmove(output,value,len(value));return len(value)
    old=NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)
    old._image=SimpleNamespace(_entry=entry);old._lock=RLock();old._nonce=object()
    old._types={};old._ids={};old._descriptors={};old._observations={}
    old._broken=old._closed=False
    old._state=ctypes.create_string_buffer(1);old._output=ctypes.create_string_buffer(65536)
    old._command(init,result=False)
    native=NativeTransport(root/'compile-r1/bundle.json',ledger=target/(name+'.jsonl'))
    native.begin(init,1);native.reply(initial)
    native.begin(dict(op='resolve',ref='N'),3)
    expected_error=None
    try:
        old._command(dict(op='resolve',ref='N'))
    except HIAProgramRejected as exc:
        expected_error={'code':exc.code,'text':str(exc)}
    actual,event,_=native.reply(raw)
    accepted=actual==128 and event[6]==0
    old_accepted=expected_error is None
    equal=old_accepted==accepted
    if equal and accepted:
        equal=json.dumps(native.query(17),ensure_ascii=True,sort_keys=True)==json.dumps(old._descriptors[17],ensure_ascii=True,sort_keys=True)
    outcomes.append(dict(name=name,old_accepted=old_accepted,new_accepted=accepted,
        equal=equal,old_error=expected_error,source_bytes=len(payload),
        source_sha256=sha256(payload).hexdigest(),actual_transport_entries=native.calls))
    old.close();native.close()
summary=dict(scope='PRIVATE_INJECTED_RESPONSE_ENCODING_COMPATIBILITY_WITNESSES',
    cases=len(outcomes),exact=sum(x['equal'] for x in outcomes),
    differences=[x['name'] for x in outcomes if not x['equal']],
    public_input_counterexample=False,production_source_revision='source-r1',
    compatibility_closed=False,cold_qualified=False)
(target/'outcomes.json').write_text(json.dumps(outcomes,ensure_ascii=True,indent=2,sort_keys=True)+'\n')
(target/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
