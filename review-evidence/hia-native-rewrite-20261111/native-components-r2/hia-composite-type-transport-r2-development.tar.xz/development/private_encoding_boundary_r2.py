"""Pin original private json.loads(bytes) compatibility, without scope hiding.

Native-image output injection is deliberately private. The public source path
does not choose the bytes emitted by the HIA types owner. These controls still
describe behavior of the existing adapter that a complete replacement must
preserve or explicitly leave unclosed.
"""
from pathlib import Path
from hashlib import sha256
from threading import RLock
from types import SimpleNamespace
import ctypes
import json
import struct

from transport_harness import NativeTransport, descriptor, frame
from hepta.hia_composite_types_native import NativeCompositeTypeSession
from hepta.hia_program import HIAProgramRejected

root=Path(__file__).resolve().parent
target=root/'private-encoding-boundary-r2'
target.mkdir(exist_ok=False)
initial=(root/'actual-pipeline-r1/000-types-response.bin').read_bytes()
init=dict(op='init',definitions=[],recursive_chain=True,partial_records=True)
baseline=descriptor(17,'N\u00e9\U0001f600',fields=[('field\n\t\x00',9)])
plain=json.dumps({'types':[baseline]},ensure_ascii=False,separators=(',',':'))
cases=[]
for encoding in ('utf-8','utf-8-sig','utf-16','utf-16-le','utf-16-be','utf-32','utf-32-le','utf-32-be'):
    cases.append((encoding,plain.encode(encoding)))
for label,text,encoding in [
    ('escaped_lone_high','\ud800','ascii'),('escaped_lone_low','\udfff','ascii'),
    ('escaped_pair','\ud800\udc00','ascii'),
    ('raw_wtf8_lone_high','\ud800','utf-8'),('raw_wtf8_lone_low','\udfff','utf-8'),
    ('raw_utf16_lone_high','\ud800','utf-16'),('raw_utf32_lone_low','\udfff','utf-32'),
]:
    value={'types':[dict(baseline,name=text)]}
    encoded=json.dumps(value,ensure_ascii=encoding=='ascii',separators=(',',':')).encode(encoding,errors='surrogatepass')
    cases.append((label,encoded))
cases += [('invalid_utf8',b'{"types":"\xff"}'),
          ('truncated_utf16',plain.encode('utf-16')[:-1]),
          ('invalid_utf32_codepoint',b'\xff\xfe\x00\x00'+b'\xff\xff\xff\xff')]

# Independent byte fixtures for Python's actual surrogatepass decoder and BOM
# inference. These cases do not derive expected acceptance from the new kernel.
for unit in (0xd800,0xdc00,0xdfff):
    value={'types':[dict(baseline,name=chr(unit))]}
    spelling=json.dumps(value,ensure_ascii=False,separators=(',',':'))
    for encoding in ('utf-8','utf-16-le','utf-16-be','utf-32-le','utf-32-be'):
        cases.append(('raw_'+hex(unit)+'_'+encoding,spelling.encode(encoding,errors='surrogatepass')))
for text in ('\\ud800\\u0061','\\ud800\\ud800','\\udc00\\ud800',
             '\\ud800\\udc00','\\ud800\\uZZZZ','\\ud800\\u00','\\ud800\\'):
    base=json.dumps({'types':[dict(baseline,name='ESCAPE_POINT')]},ensure_ascii=True,separators=(',',':'))
    payload=base.replace('ESCAPE_POINT',text)
    cases.append(('escape_boundary_'+str(len(cases)),payload.encode()))
base=json.dumps({'types':[dict(baseline,name='RAW_POINT')]},ensure_ascii=True,separators=(',',':'))
head,tail=base.split('RAW_POINT')
for value in (0x110000,0xffffffff):
    for encoding,endian,bom in [('utf-32-le','little',b'\xff\xfe\x00\x00'),
                                ('utf-32-be','big',b'\x00\x00\xfe\xff')]:
        payload=head.encode(encoding)+value.to_bytes(4,endian)+tail.encode(encoding)
        cases.append(('invalid_'+hex(value)+'_'+encoding,payload))
        cases.append(('invalid_bom_'+hex(value)+'_'+encoding,bom+payload))
for encoding in ('utf-8','utf-16-le','utf-16-be','utf-32-le','utf-32-be'):
    cases.append(('raw_NUL_'+encoding,(head+'\x00'+tail).encode(encoding)))
    # An embedded BOM is a character, not a second encoding declaration.
    cases.append(('inner_string_BOM_'+encoding,(head+'\ufeff'+tail).encode(encoding)))
    cases.append(('leading_space_BOM_'+encoding,(' \ufeff'+plain).encode(encoding)))
for value in (b'',b'\x00',b'\x00\x00',b'\x00\x00\x00',b'\x00\x00\x00\x00',
              b'\xff',b'\xff\xfe',b'\xfe\xff',b'\xff\xfe\x00',b'\xff\xfe\x00\x00',
              b'\x00\x00\xfe\xff',b'\xef\xbb',b'\xef\xbb\xbf',
              b'\x00{',b'{\x00',b'\x00{\x00}',b'{\x00}\x00',b'\x00\x00\x00{',b'{\x00\x00\x00'):
    cases.append(('short_detect_'+value.hex(),value))
for invalid in (b'\xc0\x80',b'\xc1\xbf',b'\xe0\x80\x80',b'\xf0\x80\x80\x80',
                b'\xf4\x90\x80\x80',b'\xf5\x80\x80\x80',b'\x80',b'\xed\xa0',b'\xf0\x9f\x98'):
    cases.append(('invalid_raw_utf8_'+invalid.hex(),head.encode()+invalid+tail.encode()))
# Force normalization and then descriptor persistence to cross multiple GROWs.
long_name='\u00e4'*100000+'\ud800'+'\U0001f600'*100
long_value={'types':[dict(baseline,name=long_name)]}
cases.append(('UTF16_surrogate_GROW',json.dumps(long_value,ensure_ascii=False,separators=(',',':')).encode('utf-16',errors='surrogatepass')))

outcomes=[]
for name,payload in cases:
    raw=struct.pack('<8Q',int.from_bytes(b'HIATYP01','little'),0,17,len(payload),7,3,19,0)+payload
    (target/(name+'.bin')).write_bytes(raw)
    waiting=[initial,raw]
    def entry(source,size,output,capacity,state,state_size):
        value=waiting.pop(0);ctypes.memmove(output,value,len(value));return len(value)
    old=NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)
    old._image=SimpleNamespace(_entry=entry);old._lock=RLock();old._nonce=object()
    old._types={};old._ids={};old._descriptors={};old._observations={}
    old._broken=old._closed=False
    old._state=ctypes.create_string_buffer(1);old._output=ctypes.create_string_buffer(max(65536,len(raw)))
    old._command(init,result=False)
    native=NativeTransport(root/'compile-r2/bundle.json',ledger=target/(name+'.jsonl'))
    native.begin(init,1);native.reply(initial)
    native.begin(dict(op='resolve',ref='N'),3)
    expected_error=None
    try:
        old._command(dict(op='resolve',ref='N'))
    except HIAProgramRejected as exc:
        expected_error={'code':exc.code,'text':str(exc)}
    actual,event,_=native.reply(raw)
    accepted=actual==128 and event[6]==0
    old_accepted=expected_error is None
    equal=old_accepted==accepted
    if equal and accepted:
        equal=json.dumps(native.query(17),ensure_ascii=True,sort_keys=True)==json.dumps(old._descriptors[17],ensure_ascii=True,sort_keys=True)
    if name == 'UTF16_surrogate_GROW' and accepted:
        assert native.grows >= 3
        # A UTF-8 reply reuses the normalization scratch from the UTF-16 reply.
        later=frame({'types':[]},identifier=17,counters=(7,3,19))
        waiting.append(later)
        old._command(dict(op='resolve',ref='N'))
        native.begin(dict(op='resolve',ref='N'),3)
        assert native.reply(later)[0] == 128
        assert json.dumps(native.query(17),ensure_ascii=True,sort_keys=True)==json.dumps(old._descriptors[17],ensure_ascii=True,sort_keys=True)
    outcomes.append(dict(name=name,old_accepted=old_accepted,new_accepted=accepted,
        equal=equal,old_error=expected_error,source_bytes=len(payload),
        source_sha256=sha256(payload).hexdigest(),actual_transport_entries=native.calls))
    old.close();native.close()
assert all(row['equal'] for row in outcomes), [row['name'] for row in outcomes if not row['equal']]
summary=dict(scope='PRIVATE_ENCODING_BOM_SURROGATE_AND_MALFORMED_BOUNDARIES',
    cases=len(outcomes),exact=sum(x['equal'] for x in outcomes),
    differences=[x['name'] for x in outcomes if not x['equal']],
    public_input_counterexample=False,production_source_revision='source-r2',
    compatibility_closed=True,cold_qualified=False)
(target/'outcomes.json').write_text(json.dumps(outcomes,ensure_ascii=True,indent=2,sort_keys=True)+'\n')
(target/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
