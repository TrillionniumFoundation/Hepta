"""Actual-image protocol/custody controls; explicit private ABI boundaries.

No language algorithm is supplied by this harness. Forged frames and private
white-box counters are labelled controls, never public-language witnesses.
"""
from pathlib import Path
from hashlib import sha256
import copy
import ctypes
import gc
import json
import resource
import struct
import weakref
from unittest.mock import patch

import transport_harness as harness
from transport_harness import NativeTransport, BAD, MAGIC, frame, descriptor
from hepta.hia_instruction_policy_native import transport as encode_packet

resource.setrlimit(resource.RLIMIT_CPU, (40, 40))
resource.setrlimit(resource.RLIMIT_AS, (768 << 20, 768 << 20))
root = Path(__file__).resolve().parent
target = root / 'protocol-controls-r1'
target.mkdir(exist_ok=False)
bundle = root / 'compile-r1/bundle.json'
initial = (root / 'actual-pipeline-r1/000-types-response.bin').read_bytes()
init = dict(op='init', definitions=[], recursive_chain=True, partial_records=True)
outcomes, entries = [], 0


def word(owner, offset):
    return struct.unpack_from('<Q', owner.workspace, offset)[0]


def new():
    result = NativeTransport(bundle, ledger=target / ('entries-' + str(len(outcomes)) + '.jsonl'))
    assert result.begin(init, 1)[0] == 128
    assert result.reply(initial)[0] == 128
    return result


def command_wire(owner, command, operation=3, **changes):
    packet = encode_packet(command)
    words = [MAGIC['begin'], owner.lease, owner.sequence + 1, operation,
             owner.sequence + 1, len(packet), 0, 0]
    for key, value in changes.items():
        words[int(key)] = value
    return struct.pack('<8Q', *words) + packet


def reply_wire(owner, native=initial, **changes):
    words = [MAGIC['reply'], owner.lease, owner.sequence, owner.operation,
             owner.request, len(native), 0, 0]
    for key, value in changes.items():
        words[int(key)] = value
    return struct.pack('<8Q', *words) + native


def query_wire(owner, identifier=9, **changes):
    words = [MAGIC['query'], owner.lease, owner.sequence, owner.query_sequence + 1,
             identifier, 0, 0, 0]
    for key, value in changes.items():
        words[int(key)] = value
    return struct.pack('<8Q', *words)


def poisoned(owner):
    assert word(owner, 8) == 1
    assert owner.call('commands', query_wire(owner))[0] == BAD
    assert owner.call('commands', command_wire(owner, dict(op='resolve', ref='u8')))[0] == BAD
    assert owner.call('reply', reply_wire(owner))[0] == BAD


def record(name, owner, **extra):
    global entries
    entries += owner.calls
    outcomes.append(dict(name=name, passed=True, calls=owner.calls, **extra))
    (target / 'outcomes.json').write_text(json.dumps(outcomes, indent=2, sort_keys=True)+'\n')
    owner.close()


for label, factory in [
    ('begin_wrong_lease', lambda o: command_wire(o, dict(op='resolve', ref='u8'), **{'1': 2})),
    ('begin_skipped_sequence', lambda o: command_wire(o, dict(op='resolve', ref='u8'), **{'2': 3})),
    ('begin_wrong_reserved', lambda o: command_wire(o, dict(op='resolve', ref='u8'), **{'6': 1})),
    ('begin_wrong_packet_extent', lambda o: command_wire(o, dict(op='resolve', ref='u8'), **{'5': 0})),
    ('begin_operation_mismatch', lambda o: command_wire(o, dict(op='parameters', params=[]))),
    ('begin_unknown_operation', lambda o: command_wire(o, dict(op='resolve', ref='u8'), operation=7)),
    ('query_wrong_lease', lambda o: query_wire(o, **{'1': 2})),
    ('query_wrong_completed_sequence', lambda o: query_wire(o, **{'2': 0})),
    ('query_skipped_sequence', lambda o: query_wire(o, **{'3': 2})),
    ('query_unissued_ID', lambda o: query_wire(o, 17)),
    ('query_outside_uint32', lambda o: query_wire(o, 1 << 32)),
    ('query_zero_ID', lambda o: query_wire(o, 0)),
    ('query_extra_bytes', lambda o: query_wire(o) + b'x'),
]:
    owner = new()
    wire = factory(owner)
    (target / (label+'.bin')).write_bytes(wire)
    assert owner.call('commands', wire)[0] == BAD, label
    poisoned(owner)
    record(label, owner)

for label, command, operation in [
    ('partial_unissued_base', dict(op='partial', base=17, initialized=[]), 4),
    ('origins_unissued_param', dict(op='origins', params=[['x',17]], returns=[]), 5),
    ('origins_unissued_return', dict(op='origins', params=[], returns=[17]), 5),
    ('task_unissued_task', dict(op='task_protocol', task=17, functions=[]), 6),
    ('task_unissued_param', dict(op='task_protocol', task=9, functions=[['f',[17],[]]]), 6),
    ('task_unissued_return', dict(op='task_protocol', task=9, functions=[['f',[],[17]]]), 6),
    ('partial_boolean_ID', dict(op='partial', base=True, initialized=[]), 4),
]:
    owner = new()
    assert owner.begin(command, operation)[0] == BAD, label
    poisoned(owner)
    record(label, owner)

for label, which in [('query_while_pending', 'query'), ('begin_while_pending', 'begin'),
                     ('replay_completed_reply', 'replay')]:
    owner = new()
    if which == 'replay':
        result = owner.call('reply', reply_wire(owner))[0]
    else:
        assert owner.begin(dict(op='resolve', ref='u8'), 3)[0] == 128
        wire = query_wire(owner) if which == 'query' else command_wire(owner, dict(op='resolve', ref='u8'))
        result = owner.call('commands', wire)[0]
    assert result == BAD, label
    poisoned(owner)
    record(label, owner)

for label, changes in [('reply_wrong_lease', {'1':2}), ('reply_wrong_sequence', {'2':1}),
                       ('reply_wrong_operation', {'3':2}), ('reply_wrong_request', {'4':99}),
                       ('reply_wrong_extent', {'5':1}), ('reply_reserved', {'7':1})]:
    owner = new()
    assert owner.begin(dict(op='resolve', ref='u8'), 3)[0] == 128
    wire = reply_wire(owner, frame({'types':[]}, identifier=7), **changes)
    (target/(label+'.bin')).write_bytes(wire)
    assert owner.call('reply', wire)[0] == BAD
    poisoned(owner)
    record(label, owner)

# A live session with a shortened output view must poison before publishing.
owner = new()
wire = query_wire(owner)
input_buffer = ctypes.create_string_buffer(wire)
output = ctypes.create_string_buffer(128)
assert owner.images['commands']._entry(input_buffer,len(wire),output,127,owner.workspace,owner.size) == BAD
owner.calls += 1
poisoned(owner)
record('short_output_full_workspace_poisons', owner)

# The underlying borrow ABI cannot safely write a tiny workspace. Its BAD
# result requires the fixed driver to discard that lease; do not claim poison.
owner = new()
before = ctypes.string_at(owner.workspace, owner.size)
assert owner.images['commands']._entry(input_buffer,len(wire),output,128,owner.workspace,8) == BAD
owner.calls += 1
assert ctypes.string_at(owner.workspace,owner.size) == before
record('short_workspace_requires_driver_discard', owner, scope='PRIVATE_BORROW_EXTENT_NOT_PUBLIC_INPUT')

# GROW retries keep the exact original bytes. No ID or counters publish early.
owner = NativeTransport(bundle, ledger=target/'grow-entries.jsonl')
packet = encode_packet(init)
wire = struct.pack('<8Q',MAGIC['begin'],1,1,1,1,len(packet),0,0)+packet
result,event,_ = owner.call('commands',wire,auto_grow=False)
assert result == 128 and event[1] == 1
assert word(owner,40)==0 and word(owner,128)==0 and [word(owner,x) for x in (80,88,96)]==[0,0,0]
def enlarge(owner, needed):
    previous=owner.workspace
    memory=ctypes.create_string_buffer(needed+32)
    ctypes.memmove(memory,previous,owner.size)
    ctypes.memset(ctypes.addressof(memory)+needed,0xb7,32)
    owner.workspace,owner.size=memory,needed
    owner.grows+=1
enlarge(owner,event[15])
assert owner.call('commands',wire)[1][1] == 0
owner.sequence,owner.operation,owner.request=1,1,1
reply=reply_wire(owner)
result,event,_=owner.call('reply',reply,auto_grow=False)
assert result==128 and event[1]==1
assert word(owner,40)==0 and word(owner,128)==0
enlarge(owner,event[15])
assert owner.call('reply',reply)[1][1] == 0
assert owner.query(9)['name']=='u32'
record('grow_replay_original_immutable_bytes', owner,
       input_identity_scope='Caller retains exact bytes; header alone does not authenticate body')

# Header u64 fields preserve the full range, including stable origins/task.
owner=new()
maximum=(1<<64)-1
assert owner.begin(dict(op='resolve',ref='u8'),3)[0]==128
result,event,_=owner.reply(frame({'types':[]},identifier=7,counters=(maximum,maximum,maximum)))
assert result==128 and event[8:11]==(maximum,maximum,maximum)
assert owner.begin(dict(op='origins',params=[],returns=[]),5)[0]==128
assert owner.reply(frame({'origins':[]},counters=(maximum,maximum,maximum),magic=b'HIALOR01'))[1][8:11]==(maximum,maximum,maximum)
assert owner.begin(dict(op='task_protocol',task=9,functions=[]),6)[0]==128
result,event,_=owner.reply(frame({'types':[]},error=47,counters=(maximum,maximum,maximum)))
assert result==128 and event[6]==47 and event[8:11]==(maximum,maximum,maximum)
record('all_u64_observation_bits_preserved',owner,scope='FORGED_TRANSPORT_COUNTERS')

# Existing issued IDs and scratch are reused; a call count is not a quota.
owner=new()
heap=word(owner,104)
for iteration in range(2048):
    assert owner.begin(dict(op='resolve',ref='u8'),3)[0]==128
    assert owner.reply(frame({'types':[]},identifier=7))[0]==128
    assert word(owner,104)==heap and word(owner,128)==16
assert owner.query(7)['name']=='u8'
record('2048_calls_no_descriptor_or_scratch_accumulation',owner,iterations=2048,persistent_bytes=heap)

# Test custody failures are checked before any executable mapping. The positive
# runs above use the same tightened fixture; no production image has changed.
original=json.loads(bundle.read_text())
for label, mutate in [
    ('wrong_component_schema', lambda b: b['components']['commands'].__setitem__('schema','wrong')),
    ('wrong_component_source', lambda b: b['components']['reply'].__setitem__('source_sha256','0'*64)),
    ('wrong_component_image', lambda b: b['components']['reply'].__setitem__('image_sha256','0'*64)),
    ('wrong_bundle_scope', lambda b: b.__setitem__('scope','COLD_QUALIFIED')),
]:
    value=copy.deepcopy(original);mutate(value)
    path=target/(label+'.json');path.write_text(json.dumps(value))
    called=[]
    def forbidden_mapping(*args,**kwargs):
        called.append(True)
        raise AssertionError('mapped before all sources validated')
    with patch.object(harness,'NativeHiaJsonImage',forbidden_mapping):
        try:
            NativeTransport(path)
        except ValueError:
            pass
        else:
            raise AssertionError(label)
    assert not called
    outcomes.append(dict(name=label,passed=True,actual_native_entries=0))

summary=dict(scope='ACTUAL_TRANSPORT_PROTOCOL_AND_CUSTODY_CONTROLS',passed=True,
             controls=len(outcomes),actual_transport_entries=entries,
             all_invalid_live_leases_fail_closed=True,
             tiny_borrow_extent_requires_driver_discard=True,
             grow_requires_same_private_immutable_input=True,
             source_images_unchanged=True,cold_qualified=False)
(target/'outcomes.json').write_text(json.dumps(outcomes,indent=2,sort_keys=True)+'\n')
(target/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True),flush=True)
