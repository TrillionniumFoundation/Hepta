"""All six services through the real HIA types image and real transport pair.

The first pass keeps the complete old adapter as an independent oracle. The
second invokes the three native images with hosted type materialization disabled.
These are source-bound development tests, not a cold qualification.
"""
from pathlib import Path
from hashlib import sha256
import ctypes
import faulthandler
import json
import resource
import struct
from unittest.mock import patch

from transport_harness import NativeTransport
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_composite_types_native import (NativeCompositeTypes, NativeCompositeTypeSession,
                                             ERRORS, SESSION_BYTES, OUTPUT_BYTES)
from hepta.hia_program import HIAProgramRejected
from hepta import hia_program_composite as composite

faulthandler.enable()
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20, 1024 << 20))
root = Path(__file__).resolve().parent
target = root / 'actual-pipeline-r2'
target.mkdir(exist_ok=False)
manifest_path = root / 'compile-types-r1/manifest.json'
manifest_raw = manifest_path.read_bytes()
manifest = json.loads(manifest_raw)
image_raw = Path(manifest['image_path']).read_bytes()
source_raw = Path(manifest['source_path']).read_bytes()
assert sha256(image_raw).hexdigest() == manifest['image_sha256']
assert sha256(source_raw).hexdigest() == manifest['source_sha256']
image = NativeCompositeTypes(image_raw, manifest['image_sha256'])
actual_entry = image._entry
transport = NativeTransport(root / 'compile-r2/bundle.json', ledger=target / 'transport-entries.jsonl')
transactions, holder = [], {}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def record(name, fields, params=()):
    return dict(name=name, kind='record', params=list(params),
                fields=[dict(name=name, type=typ) for name, typ in fields])


definitions = [record('State', [('value', 'u8')]), record('Other', [('value', 'u8')]),
    {'name': 'Step', 'kind': 'enum', 'params': [], 'variants': [
        {'name': 'pending', 'fields': [{'name': 's', 'type': 'State'}]},
        {'name': 'ready', 'fields': [{'name': 'v', 'type': 'u8'}]}]},
    {'name': 'Job', 'kind': 'task', 'params': [], 'state': 'State', 'result': 'u8',
     'poll': 'poller', 'cancel': 'cancel'},
    record('Borrowed', [('left', 'readbuf'), ('right', 'mutbuf')]),
    record('Pair', [('scalar', 'u8'), ('owner', 'buffer')]),
    record('Phantom', [], ['T'])]


def observe_entry(source, size, output, capacity, workspace, workspace_size):
    raw = ctypes.string_at(source, size)
    result = actual_entry(source, size, output, capacity, workspace, workspace_size)
    assert 64 <= result <= capacity, result
    response = ctypes.string_at(output, result)
    index = len(transactions)
    (target / f'{index:03d}-types-command.json').write_bytes(raw)
    (target / f'{index:03d}-types-response.bin').write_bytes(response)
    native = transport.reply(response)
    assert native[0] == 128 and native[1][1] == 0, native
    holder['native'] = native
    transactions.append({'command': raw, 'frame': response, 'operation': transport.operation,
                         'event': native[1], 'payload': native[2]})
    return result


image._entry = observe_entry
oracle = NativeCompositeTypeSession.__new__(NativeCompositeTypeSession)


def compare_state():
    result, event, payload = holder['native']
    assert event[8:11] == tuple(oracle.observations[key]
        for key in ('cache_count', 'active_count', 'partial_declaration_steps'))
    for identifier, descriptor in oracle._descriptors.items():
        assert canonical(transport.query(identifier)) == canonical(descriptor), identifier


def execute(command, operation):
    started = transport.begin(command, operation)
    assert started[0] == 128 and started[1][1] == 0, started
    options = ({'parameters': True} if operation == 2 else {'origins': True}
               if operation == 5 else {'stable': True} if operation == 6 else {})
    value, error = None, None
    try:
        value = oracle._command(command, **options)
    except HIAProgramRejected as exc:
        error = (exc.code, str(exc))
    _, event, payload = holder['native']
    if event[6]:
        code, message = ERRORS[event[6]]
        expected = HIAProgramRejected(message, code)
        assert error == (expected.code, str(expected)), (command, error, event)
        assert payload == b''
    else:
        assert error is None, (command, error)
        if operation == 2:
            actual = detached_packet_index(payload)[0]
            expected = [[name, oracle._ids[id(typ)]] for name, typ in value]
            assert canonical(actual) == canonical(expected)
        elif operation == 5:
            actual = detached_packet_index(payload)[0]
            expected = [None if x is None else list(x) for x in value]
            assert canonical(actual) == canonical(expected)
        else:
            assert struct.unpack('<Q', payload)[0] == oracle._ids[id(value)]
    compare_state()
    return value, error


try:
    init = dict(op='init', definitions=definitions, recursive_chain=True, partial_records=True)
    assert transport.begin(init, 1)[0] == 128
    oracle.__init__(image, definitions, recursive_chain=True, partial_records=True)
    assert holder['native'][1][6] == 0
    compare_state()
    params, _ = execute(dict(op='parameters', params=[{'name': name, 'type': typ} for name, typ in
        [('s', 'State'), ('j', 'Job'), ('step', 'Step'), ('pair', 'Pair'), ('loans', 'Borrowed')]]), 2)
    ids = {name: oracle._ids[id(typ)] for name, typ in params}
    execute(dict(op='parameters', params=[{'name': 'x', 'type': {'name': 'Phantom', 'args': ['u8']}},
                                         {'name': 'x', 'type': 'u8'}]), 2)
    execute(dict(op='parameters', params=None), 2)
    one, _ = execute(dict(op='resolve', ref={'name': 'Phantom', 'args': ['u8']}), 3)
    two, _ = execute(dict(op='resolve', ref={'name': 'Phantom', 'args': ['u16']}), 3)
    assert oracle._ids[id(one)] != oracle._ids[id(two)]
    execute(dict(op='partial', base=ids['pair'], initialized=[]), 4)
    execute(dict(op='partial', base=ids['pair'], initialized=['missing']), 4)
    execute(dict(op='origins', params=[['incoming', ids['loans']]], returns=[14, 15],
        return_loans=[{'param': 'incoming', 'fields': ['left']},
                      {'param': 'incoming', 'fields': ['right']}]), 5)
    execute(dict(op='origins', params=[['incoming', ids['loans']]], returns=[14],
        return_loans=[{'param': 'wrong', 'fields': ['left']}]), 5)
    execute(dict(op='task_protocol', task=ids['j'], functions=[
        ['poller', [ids['s']], [ids['step']]], ['cancel', [ids['s']], []]]), 6)
    execute(dict(op='task_protocol', task=ids['j'], functions=[]), 6)
    execute(dict(op='resolve', ref='Unknown'), 3)
    registry = canonical(oracle._descriptors)
    expected_queries = {key: canonical(value) for key, value in oracle._descriptors.items()}
    first_entries, first_grows, first_bytes = transport.calls, transport.grows, transport.size
finally:
    oracle.close()
    transport.close()

native_only = NativeTransport(root / 'compile-r2/bundle.json', lease=2,
                             ledger=target / 'without-host-entries.jsonl')
state = ctypes.create_string_buffer(SESSION_BYTES)
output = ctypes.create_string_buffer(OUTPUT_BYTES)
try:
    def forbidden(*args, **kwargs):
        raise AssertionError('host nominal/type materialization owner called')

    with patch.object(composite, '_Types', forbidden), \
         patch.object(NativeCompositeTypeSession, '_materialize_value', forbidden), \
         patch.object(composite._Elaborator, 'loan_origins', forbidden):
        for transaction in transactions:
            command = json.loads(transaction['command'])  # Test input replayer only.
            result = native_only.begin(command, transaction['operation'])
            assert result[0] == 128 and result[1][1] == 0
            source = ctypes.create_string_buffer(transaction['command'])
            size = actual_entry(source, len(transaction['command']), output, OUTPUT_BYTES, state, SESSION_BYTES)
            actual = ctypes.string_at(output, size)
            assert actual == transaction['frame']
            result, event, payload = native_only.reply(actual)
            assert result == 128 and event[1] == 0
            assert event[5:13] == transaction['event'][5:13]
            assert payload == transaction['payload']
        for identifier, expected in expected_queries.items():
            assert canonical(native_only.query(identifier)) == expected
    summary = {'scope': 'REAL_TYPES_OWNER_AND_TWO_REAL_TRANSPORT_IMAGES_DEVELOPMENT',
               'passed': True, 'operations': sorted(set(row['operation'] for row in transactions)),
               'transactions': len(transactions), 'actual_type_entries': len(transactions) * 2,
               'transport_entries': first_entries + native_only.calls,
               'grows': first_grows + native_only.grows,
               'first_workspace_bytes': first_bytes, 'second_workspace_bytes': native_only.size,
               'issued_descriptors': len(expected_queries), 'hosted_owner_disabled_second_pass': True,
               'registry_sha256': sha256(registry).hexdigest(), 'cold_qualified': False}
    (target / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
finally:
    native_only.close()
    state = output = None
    assert manifest_path.read_bytes() == manifest_raw
    assert Path(manifest['image_path']).read_bytes() == image_raw
    assert Path(manifest['source_path']).read_bytes() == source_raw
