# Complete HIA type transport owner — development r2

The complete six-operation response/issued-ID owner is implemented in two HIA images. Neither image calls Python to interpret descriptors, compute origin names/counts, choose IDs, validate the descriptor graph, or decide a commit. This is a separately tested development component. It has not replaced the ordinary public driver, passed a matching cold qualification, or authorized removal of the original adapter.

## Exact source and images

The base reference is `d5da1eb760454ef3df5153c5e80eb046ddb389d9`. `FINAL_SOURCE_MANIFEST.json` is the final source inventory, SHA-256 `a4bca67f4ab4ac492b66d0477da39db8e4918d0a9928c5f8e967c280de0d41fd`. The immutable compilation snapshot is `checkpoints/source-r2/source.json`, SHA-256 `12e2697e3c8ddb1390f288a8276f9c9844819b8c5b0bdcba2e30fa61a5adde45`. The final authoring regenerated both HIA sources in memory to exactly the tested bytes.

| Image | Source SHA-256 | Image SHA-256 | Functions / blocks / instructions |
|---|---|---|---|
| Commands / query | `f7cf0d36004b69b6d60fe7e4c615b167f587153ab06ed46bbae3fec503d0d3c6` | `b4ad2ffd51ccf2300e06a9c04649c6b48fdc4d59c42d21b12a282fc02955cbdc` | 40 / 612 / 2525 |
| Response / issued registry | `24db3b3f090892b148590ddf5b7989bc0eeb6c733fd4b6f5733f5cd3573a8f9d` | `bdc77f86bd6a11e6ec3c48ad7852fba57883195dfc99b13ec2f7d2df278f68bf` | 60 / 992 / 3959 |

Maximum function blocks are 195 in each image. Maximum block parameters are 9 and 10. All original 128-function / 1536-block / 8192-instruction / 256-block-per-function / 16-block-parameter limits remain unchanged.

The exact manifests are `development/compile-r2/bundle.json`, `commands.manifest.json`, and `reply.manifest.json`. Every component has source/image hashes and retains its actual compile request, execution output and receipt. The compiler was the retained f50 B3 image, SHA-256 `0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8`, under the original bounded compile settings. It is not a current-source cold-qualified compiler claim.

The unchanged semantic types dependency was separately actually compiled from source SHA-256 `33969ee0fdec37c27ebf017c52d01e20748118d643589cf280042a39f68e3d6b`; its image SHA-256 is `dbe484770638ac36b72fc5930eb03862e4ee27f1e532f3a3b7c30acc5cd78612`. Its manifest and raw receipts are in `development/compile-types-r1/`.

## Production authoring boundary

The six authoring files are `tools/generate_hia_composite_type_transport.py`, plus its `_commands`, `_common`, `_reply`, `_json`, and `_encoding` modules. The generated resources are `examples/hia_bootstrap/composite_type_transport_commands.hiaasm` and `composite_type_transport_reply.hiaasm`. The ABI document is `docs/HIA_COMPOSITE_TYPE_TRANSPORT.md`. The source inventory additionally preserves the exact baseline and original adapter reference.

The Python authoring constructs HIA. `development/transport_harness.py` is a test-only custody/dispatch harness. Its object serialization and packet decoding are independent test inputs/oracles, not part of the intended production pipeline. The collaborator's separate HIA request projector already supplies complete native command packets; it does not need the harness's Python `begin()` convenience method.

## ABI and ownership

BEGIN, REPLY and QUERY retain the agreed 64-byte headers. Events are the agreed 128-byte `HIATRE01` frame. Canonical operation numbers are init 1, parameters 2, resolve 3, partial 4, origins 5, and task protocol 6. Successful result kind 1 is one raw eight-byte issued ID, kind 2 is the complete parameter packet, kind 3 is the complete origins packet, and kind 4 is the complete queried thirteen-field descriptor packet. Semantic errors have no result payload.

The command image validates its complete typed packet, computes the original JSON byte size in HIA, enforces the existing 8 MiB + 128-byte command bound, and checks issued IDs in partial/origins/task inputs. The response image validates the complete native frame and JSON, all thirteen descriptor fields, primitive identities, pending references, cycles and result shape. Only a fully valid pending graph is committed. The original late parameter-ID failure commits descriptors before counters; an ordinary invalid result ID commits descriptors and counters before refusal. Origin/task counters and allowed semantic-error sets retain their original behavior.

Persistent descriptor bytes are copied into the growable arena. Whole old replies are not retained after their command scratch is reused. The response parser does not apply the public 8 MiB / 262144-node / 64-depth admission gates. There is no new total descriptor, session-byte or call-count quota.

GROW retries preserve the exact same immutable input bytes and existing workspace contents. Header equality is correlation, not authentication of a replacement body. The fixed driver must discard the whole lease on any BAD return, even if an illegally short workspace prevented the kernel from recording poison. It must also discard both types and transport leases after any init failure, matching the original constructor; later ordinary semantic failures preserve the session.

## Actual r2 validation

`development/R2_RESULT_INDEX.json` indexes eight actual result groups. The original input/output frames and native-entry ledgers are retained. The 18 encoding controls are a subset of the expanded 92 controls and are not counted as independent extra coverage.

| Group | Actual result and scope |
|---|---|
| Six operations | 13 transactions, run with the original adapter oracle and again with hosted type materialization disabled: 26 genuine types-image entries and 376 transport entries. Complete descriptors, results, semantic error code/text and counters agree. |
| Malformed responses and commit order | 280 controls, 2477 real transport entries: 172 ABI refusals, 103 semantic refusals, five accepted transport controls. Full descriptor/counter/broken state matches the old adapter. Every ABI refusal remains refused through BEGIN, REPLY and QUERY. |
| Protocol and custody | 38 controls, 4403 real transport entries, including lease/sequence/replay errors, issued-ID custody, all u64 observation bits, GROW publication, and 2048 commands without accumulating descriptor/scratch storage. |
| Private encodings | 92 complete old/new comparisons, all equal. UTF-8 BOM, UTF-16/32 detection, raw and escaped unpaired surrogates, proper pairs, overlong/malformed UTF-8, invalid UTF-32 values, short zero-byte/BOM detection and embedded NUL are included. A 100000-character UTF-16 string crosses GROW and survives a later UTF-8 reply. |
| Large real response | The genuine types image emits 21,160,521 bytes and 795,037 JSON value nodes. All 144 descriptors match before and after overwriting the original output buffer and completing a later real call. There are three genuine types entries, 334 transport entries and eight GROWs; transport workspace is 134,606,848 bytes. |
| Original command size | ASCII exactly at the original bound is accepted; one byte over is refused before the old native call. Escaped-NUL and UTF-8 spellings exactly at the same bound are accepted. HIA computes these sizes itself. |
| Init lifetime | Genuine init semantic failure retains exactly `E_HIA_LIMIT: invalid nominal type inventory`. With the exception held, original output/state buffers and all new driver's live output/state/transport buffers are collected after mechanical cleanup. Close is idempotent. This proves the development-driver obligation, not unimplemented public coordinator integration. |

The large response uses two legal definitions: a zero-width record and a generic enum with 32 variants of 64 zero-width fields. Its 127 distinct generic instances plus the record use exactly the original 128 cache entries; flat width is one. Inputs are 203,995 bytes for initialization and 9,317 bytes for the parameter command. The same genuine 21,160,521-byte frame is byte-identical between r1 and r2 tests, SHA-256 `05cc4238d84ec93bf747a0c2aea126455920e0753acf5f63855a3e94e06f63c6`.

## Retained failures and compatibility scope

The initial large-response fixture accidentally named nonexistent primitives; the real types image returned status 18, correctly preserved by r1 transport. That original failed run, its source and native frames remain preserved. The corrected fixture changes only the primitive list and runs with unchanged production kernels and limits.

Revision r1 recorded thirteen private encoding differences, rather than silently narrowing the old adapter's accepted encodings. Revision r2 adds HIA normalization/surrogate-pass handling and passes all original and expanded controls. The public parser is unchanged. These are injected private-response compatibility controls, not claims that arbitrary callers can supply a trusted arena or alter genuine types output.

Native semantic error code and English message are checked exactly against the existing table. Python JSON parser-specific English ABI syntax-error messages are not reproduced: the native protocol reports BAD, retaining refusal order, no-fallback behavior and the original descriptor/counter commit boundary. No broader public integration or full qualification claim follows from these component tests.

All prior r1 sources, images, tests, original failures and reports are frozen in `../hia-composite-type-transport-r1-development.tar.xz`, SHA-256 `f47b74da8a98f4b047ce6901228f338ade5db1b188121db8b70f06da07f0b3e4`, 644200 bytes, with 489 fully read-back members. Original test groups intentionally refuse to overwrite an existing evidence destination; independent replay should use a separate evidence destination and preserve that replay's exact test source and result identity.

## Remaining integration

The complete native coordinator must wire the agreed opaque BEGIN/REPLY/QUERY events, enforce immutable private leases and init/BAD cleanup, and consume returned views before another call. Installed resources, builders, shared fixture qualification, source closure, CI/full-run gates and normal public selection are not changed in this overlay. The original Python adapter remains available as the independent reference until those gates close. No production owner is deleted by this handoff.
