"""Freeze the corrected integration without replacing the first failed gate."""
from pathlib import Path
from hashlib import sha256, sha1
import io, json, stat, subprocess, tarfile

ROOT = Path('/dev/shm/hia-native-v66-linked-integration')
OUT = Path('/workspace/scratch/9acdfa9f5639/hia-linked-observer-integration-development')
BASE = 'd5da1eb760454ef3df5153c5e80eb046ddb389d9'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
names = subprocess.check_output(['git', 'diff', '--name-only', BASE], cwd=ROOT, text=True).splitlines()
assert len(names) == len(set(names)) == 15
raws = {name: (ROOT / name).read_bytes() for name in names}
owned = [{'path': name, 'bytes': len(raws[name]), 'sha256': sha256(raws[name]).hexdigest(),
          'git_sha': sha1(b'blob ' + str(len(raws[name])).encode() + b'\0' + raws[name]).hexdigest(),
          'mode': stat.S_IMODE((ROOT / name).stat().st_mode)} for name in sorted(names)]
contract_path = 'docs/HIA_SELFHOST_CORE_SUPPORT.json'
contract_raw = (ROOT / contract_path).read_bytes()
contract = json.loads(contract_raw)
closure = {**contract['source_identity']['files'], contract_path: sha256(contract_raw).hexdigest()}
assert len(closure) == 642
assert all(sha256((ROOT / name).read_bytes()).hexdigest() == digest for name, digest in closure.items())
manifest = {'scope': 'V66_FROZEN_INTEGRATION_R3_BEFORE_SECOND_FULL_SOURCE_AND_COLD_GATES',
            'base_commit': BASE, 'base_tree': '71c9c3effb9ffa45c708e272f374302507d0d65a',
            'root': str(ROOT), 'owned_files': owned, 'source_count': len(closure),
            'source_closure': closure, 'whole_stack_closed': False}
encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
target = OUT / 'draft-v66-r3-source.json'
with target.open('xb') as f: f.write(encoded)
archive = OUT / 'draft-v66-r3-source.tar.xz'
with tarfile.open(archive, 'x:xz') as tf:
    for row in owned:
        info = tarfile.TarInfo('source/' + row['path'])
        info.size, info.mode, info.mtime = row['bytes'], row['mode'], 0
        tf.addfile(info, io.BytesIO(raws[row['path']]))
    info = tarfile.TarInfo('SOURCE_MANIFEST.json')
    info.size, info.mode, info.mtime = len(encoded), 0o644, 0
    tf.addfile(info, io.BytesIO(encoded))
with tarfile.open(archive, 'r:xz') as tf:
    assert len(tf.getmembers()) == 16
    for row in owned:
        member = tf.getmember('source/' + row['path'])
        data = tf.extractfile(member).read()
        assert member.mode == row['mode'] and member.size == row['bytes']
        assert data == raws[row['path']] and sha256(data).hexdigest() == row['sha256']
    assert tf.extractfile('SOURCE_MANIFEST.json').read() == encoded
prior = json.loads((OUT / 'draft-v66-r2-source.json').read_text())
changed = [name for name in sorted(closure) if prior['source_closure'][name] != closure[name]]
assert changed == ['docs/HIA_SELFHOST_CORE_SUPPORT.json', 'tests/test_hia_integrated_workflow.py']
original = (OUT / 'run_source_v66.py').read_text()
replacements = {'source-v66-complete-attempt1': 'source-v66-complete-attempt2',
                '/dev/shm/hia-v66-source': '/dev/shm/hia-v66-source-attempt2'}
new = original
for old, value in replacements.items():
    assert new.count(old) == 1
    new = new.replace(old, value)
controller = OUT / 'run_source_v66_attempt2.py'
with controller.open('x') as f: f.write(new)
result = {'scope': 'FIX_REQUIRED_NATIVE_MODULE_SET_AND_RERUN_COMPLETE_UNCHANGED_329_TEST_SELECTION',
          'prior_gate': 'source-v66-complete-attempt1/summary.json',
          'prior_gate_sha256': sha256((OUT / 'source-v66-complete-attempt1/summary.json').read_bytes()).hexdigest(),
          'prior_status': 'FAILED_ONE_EXACT_MODULE_SET_ASSERTION_329_RUN_ZERO_SKIPS',
          'changed_source_closure_paths': changed, 'controller_replacements': replacements,
          'controller_sha256': sha256(new.encode()).hexdigest(),
          'source_manifest_sha256': sha256(encoded).hexdigest(),
          'archive_bytes': archive.stat().st_size, 'archive_sha256': sha256(archive.read_bytes()).hexdigest(),
          'cold_limits_changed': False, 'test_selection_weakened': False, 'whole_stack_closed': False}
(OUT / 'r3-freeze-receipt.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
