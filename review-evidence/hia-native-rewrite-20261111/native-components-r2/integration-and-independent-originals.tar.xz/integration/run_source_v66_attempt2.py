"""Execute the complete source suite selected by the candidate workflow."""
from pathlib import Path
from hashlib import sha256
import ast, json, os, resource, sys, tempfile, time, unittest

BASE=Path('/workspace/scratch/9acdfa9f5639')
ROOT=Path('/dev/shm/hia-native-v66-linked-integration')
OUT=BASE/'hia-linked-observer-integration-development/source-v66-complete-attempt2'
OUT.mkdir(mode=0o700)
TMP=Path('/dev/shm/hia-v66-source-attempt2');TMP.mkdir(mode=0o700)
os.environ['TMPDIR']=str(TMP);tempfile.tempdir=None
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
contract_path='docs/HIA_SELFHOST_CORE_SUPPORT.json'
contract_raw=(ROOT/contract_path).read_bytes();contract=json.loads(contract_raw)
expected={**contract['source_identity']['files'],contract_path:sha256(contract_raw).hexdigest()}
def snapshot():return {name:sha256((ROOT/name).read_bytes()).hexdigest() for name in expected}
before=snapshot();assert before==expected and len(before)==642;dump('source-before.json',before)
workflow=(ROOT/'.github/workflows/hia-core.yml').read_text()
block=workflow.split('      - name: Core source and independent reference controls\n',1)[1].split('  native:\n',1)[0]
lines=block.split("          python -B - <<'PY'\n",1)[1].split('          PY\n',1)[0].splitlines()
code='\n'.join(line[10:] for line in lines)+'\n'
tree=ast.parse(code);assignment=next(node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in node.targets))
names=ast.literal_eval(assignment.value);assert len(names)==78 and len(set(names))==78
(OUT/'original-workflow-test-block.py').write_text(code)
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
def flatten(value):
    if isinstance(value,unittest.TestSuite):
        for child in value:yield from flatten(child)
    else:yield value
selected=[t.id() for t in flatten(suite)];assert len(selected)==329 and len(set(selected))==329
executed=[]
class Result(unittest.TextTestResult):
    def startTest(self,test):executed.append(test.id());super().startTest(test)
started=time.monotonic_ns()
with (OUT/'suite.log').open('x') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(suite)
after=snapshot();dump('source-after.json',after)
summary={'schema':'hepta.hia.v66-complete-source-suite.v1','scope':'COMPLETE_CURRENT_WORKFLOW_SOURCE_GROUP_NOT_NATIVE_COLD','python':sys.version,'executable':sys.executable,'source_count':len(before),'source_preserved':before==after,'source_manifest_sha256':sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'selected_names':list(names),'selected_test_ids':selected,'executed_test_ids':executed,'tests_run':result.testsRun,'failures':[{'test':str(t),'traceback':s} for t,s in result.failures],'errors':[{'test':str(t),'traceback':s} for t,s in result.errors],'skipped':[{'test':str(t),'reason':s} for t,s in result.skipped],'expected_failures':[{'test':str(t),'traceback':s} for t,s in result.expectedFailures],'unexpected_successes':[str(t) for t in result.unexpectedSuccesses],'seconds':(time.monotonic_ns()-started)/1e9,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'whole_stack_closed':False}
summary['passed']=result.wasSuccessful() and before==after and result.testsRun==len(selected) and executed==selected and not any(summary[k] for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
dump('summary.json',summary);print(json.dumps({k:summary[k] for k in ('passed','tests_run','seconds','source_preserved','max_rss_kib')}),flush=True)
raise SystemExit(0 if summary['passed'] else 1)
