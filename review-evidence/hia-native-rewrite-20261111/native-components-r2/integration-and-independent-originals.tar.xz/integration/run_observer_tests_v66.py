"""Complete old and new observer modules, preserving actual fresh test evidence."""
from pathlib import Path
from hashlib import sha256
import json
import os
import resource
import shutil
import sys
import tempfile
import time
import unittest

ROOT = Path('/dev/shm/hia-native-v66-linked-integration')
OUT = Path(__file__).resolve().parent / 'observer-v66-complete-attempt1'
RAW = Path('/dev/shm/hia-v66-observer-tests')
OUT.mkdir(exist_ok=False)
RAW.mkdir(exist_ok=False)
os.environ['HIA_LINKED_OBSERVER_EVIDENCE_DIR'] = str(RAW / 'linked-actual')
os.environ['TMPDIR'] = str(RAW)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.dont_write_bytecode = True
tempfile.tempdir = None
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
from tests import test_hia_selfhost_native_observer as original
from tests import test_hia_selfhost_linked_observer as linked

paths = ('tools/hia_selfhost_native_observer.py', 'tools/hia_selfhost_linked_observer.py',
    'tools/generate_hia_native_observer.py', 'tools/generate_hia_linked_observer.py',
    'examples/hia_bootstrap/native_observer_packer.hiaasm',
    'examples/hia_bootstrap/linked_observer_packer.hiaasm',
    'tests/test_hia_selfhost_native_observer.py', 'tests/test_hia_selfhost_linked_observer.py')
def snapshot():
    return {path: sha256((ROOT / path).read_bytes()).hexdigest() for path in paths}
before = snapshot()
for path in paths:
    target = OUT / 'source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / path).read_bytes())
original_cleanup = original.NativeObserverTests.tearDownClass.__func__
def retain_then_original_cleanup(cls):
    target = RAW / 'flat-actual'
    shutil.copytree(cls.root, target, copy_function=shutil.copy2, symlinks=True)
    original_cleanup(cls)
original.NativeObserverTests.tearDownClass = classmethod(retain_then_original_cleanup)
suite = unittest.TestSuite((unittest.defaultTestLoader.loadTestsFromModule(original),
    unittest.defaultTestLoader.loadTestsFromModule(linked)))
def flatten(value):
    if isinstance(value, unittest.TestSuite):
        for item in value:
            yield from flatten(item)
    else:
        yield value.id()
selected = list(flatten(suite))
assert len(selected) == len(set(selected)) == 38
executed = []
class Result(unittest.TextTestResult):
    def startTest(self, test):
        executed.append(test.id())
        super().startTest(test)
started = time.monotonic_ns()
with (OUT / 'suite.log').open('x') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=Result).run(suite)
after = snapshot()
summary = {'scope': 'COMPLETE_OBSERVER_COMPONENT_MODULES_NOT_FULL_COLD',
    'selected_test_ids': selected, 'executed_test_ids': executed, 'tests_run': result.testsRun,
    'failures': [{'test': str(t), 'traceback': s} for t, s in result.failures],
    'errors': [{'test': str(t), 'traceback': s} for t, s in result.errors],
    'skipped': list(result.skipped), 'expected_failures': list(result.expectedFailures),
    'unexpected_successes': [str(t) for t in result.unexpectedSuccesses],
    'source_before': before, 'source_after': after, 'source_preserved': before == after,
    'elapsed_ns': time.monotonic_ns() - started,
    'max_rss_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'native_limits_changed': False, 'whole_stack_closed': False}
summary['passed'] = bool(selected and executed == selected and result.wasSuccessful()
    and before == after and not any((result.skipped, result.expectedFailures, result.unexpectedSuccesses)))
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: summary[k] for k in ('passed', 'tests_run', 'elapsed_ns', 'source_preserved')}), flush=True)
raise SystemExit(0 if summary['passed'] else 1)
