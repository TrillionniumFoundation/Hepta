"""Actual report-image private protocol controls, separate from public semantics."""
from hashlib import sha256
import ctypes
import json
from pathlib import Path
import struct
import time
import traceback

from worker_report_harness import ActualReport, inputs, ROOT, CANARY, BAD, M

OUT = ROOT / 'development/report-protocol-r1'
OUT.mkdir(exist_ok=False)
actual = ActualReport(OUT / 'actual')
rows = []
started = time.monotonic_ns()
summary = dict(status='INCOMPLETE')
identities = dict(worker_sha256='a' * 64, backend_sha256='b' * 64, catalog_sha256='c' * 64)
request = dict(tool='hia_describe', request_sha256='d' * 64,
               profile_sha256='e' * 64, catalog_sha256='c' * 64)
error = dict(message='failed 😀', type='ValueError')


def load(row, field):
    entry = row[field]
    raw = Path(entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and sha256(raw).hexdigest() == entry['sha256']
    return raw


def buffer(state):
    value = ctypes.create_string_buffer(len(state) + len(CANARY))
    ctypes.memmove(value, state, len(state))
    ctypes.memmove(ctypes.addressof(value) + len(state), CANARY, len(CANARY))
    return value


def control(label, source, command, state, *, expect=BAD, poison=True,
            follow_source=None, follow_command=None):
    work = buffer(state)
    result, event = actual.call(source, command, work, len(state), label)
    assert result == expect, (label, result, event)
    if poison:
        assert len(state) >= 1024 and struct.unpack_from('<Q', work, 8)[0] == 3, label
        again, _ = actual.call(follow_source or normal_source,
                               follow_command or struct.pack('<24Q', *normal_command),
                               work, len(state), label + ':after-refusal')
        assert again == BAD and struct.unpack_from('<Q', work, 8)[0] == 3, label
    row = dict(case=label, status='PASS', expected_return=expect,
               persistent_refusal_checked=poison, private_protocol=True,
               source=actual.save(source), command=actual.save(command),
               initial_state=actual.save(state), event=event)
    rows.append(row)


def changed(command, index, value):
    words = list(struct.unpack('<24Q', command))
    words[index] = value
    return struct.pack('<24Q', *words)


try:
    normal_source, normal_command = inputs(request, identities,
                                          {'status': 'completed', 'value': -0.0}, None, 0)
    actual.run(normal_source, normal_command, 'reference-normal')
    normal_records = actual.records[:]
    reject_source, reject_command = inputs(request, identities, None, error, 1, request_id=2)
    offset = len(actual.records)
    actual.run(reject_source, reject_command, 'reference-rejection', bytes(range(16)))
    reject_records = actual.records[offset:]
    fresh = normal_records[0]
    grow = next(row for row in normal_records if struct.unpack('<24Q', load(row, 'command'))[1] == 2)
    entropy = next(row for row in reject_records if struct.unpack('<24Q', load(row, 'command'))[1] == 3)
    rejected_grow = next(row for row in reject_records if struct.unpack('<24Q', load(row, 'command'))[1] == 2)
    fresh_command = load(fresh, 'command')
    zero = load(fresh, 'before')

    for length in (0, 1, 8, 64, 128, 191, 193, 200):
        malformed = (fresh_command + b'\0' * 8)[:length]
        control('command-extent-' + str(length), normal_source, malformed, zero)
    for index, value in ((0, 0), (1, 0), (1, 2), (1, 3), (2, 0), (3, 0),
                         (4, 1), (5, 4), (10, 2), (11, 1), (12, 1)):
        control('initial-word-' + str(index) + '-' + str(value), normal_source,
                changed(fresh_command, index, value), zero)
    for index in range(13, 24):
        control('reserved-word-' + str(index), normal_source,
                changed(fresh_command, index, 1), zero)
    for index in (6, 7, 8):
        control('missing-required-root-' + str(index), normal_source,
                changed(fresh_command, index, 0), zero)
    control('normal-error-observation-is-forbidden', normal_source,
            changed(fresh_command, 9, 1), zero)
    for at in (0, 24, 64, 127, 255, 384, 1023):
        state = bytearray(zero); state[at] = 1
        control('dirty-initial-workspace-' + str(at), normal_source, fresh_command, bytes(state))
    for offset in (0, 16, 32, 40, 48, 56):
        source = bytearray(normal_source)
        struct.pack_into('<Q', source, offset, (struct.unpack_from('<Q', source, offset)[0] + 1) & ((1 << 64) - 1))
        control('malformed-source-header-' + str(offset), bytes(source), fresh_command, zero)

    for phase, record in (('growth', grow), ('entropy', entropy), ('post-entropy-growth', rejected_grow)):
        source = load(record, 'source')
        command = load(record, 'command')
        state = load(record, 'before')
        for index in (2, 3, 4, 5, 6, 7, 8, 9):
            old = struct.unpack('<24Q', command)[index]
            control(phase + '-correlation-' + str(index), source,
                    changed(command, index, old + 1), state)
        control(phase + '-wrong-mode', source, changed(command, 1, 1), state)
        changed_source = bytearray(source)
        struct.pack_into('<Q', changed_source, 8, struct.unpack_from('<Q', source, 8)[0] + 1)
        control(phase + '-source-lease-header', bytes(changed_source), command, state)
        control(phase + '-source-extent', source + b'\0', command, state)
        state_changed = bytearray(state); struct.pack_into('<Q', state_changed, 0, 0)
        control(phase + '-state-magic', source, command, bytes(state_changed))
    control('entropy-response-must-have-entropy', load(entropy, 'source'),
            changed(load(entropy, 'command'), 10, 0), load(entropy, 'before'))
    control('after-entropy-random-cannot-change', load(rejected_grow, 'source'),
            changed(load(rejected_grow, 'command'), 11, 0), load(rejected_grow, 'before'))
    control('completion-is-single-use', normal_source, fresh_command,
            load(normal_records[-1], 'after'))
    sequence = bytearray(load(grow, 'before'))
    struct.pack_into('<Q', sequence, 32, (1 << 64) - 1)
    control('event-sequence-overflow', load(grow, 'source'),
            changed(load(grow, 'command'), 4, (1 << 64) - 1), bytes(sequence))

    # A short borrowed extent cannot persist poison. The fixed issuer must
    # discard that lease on BAD; no stronger native claim is made here.
    state = bytearray(load(grow, 'before'))
    full = buffer(bytes(state))
    command = load(grow, 'command')
    source = load(grow, 'source')
    sb = ctypes.create_string_buffer(source + CANARY)
    cb = ctypes.create_string_buffer(command + CANARY)
    before = bytes(full)
    result = actual.image._entry(sb, len(source), cb, len(command), full, 1023)
    actual.calls += 1
    assert result == BAD and bytes(full) == before
    rows.append(dict(case='short-workspace-driver-discard-required', status='PASS',
                     actual_return=result, native_poison_claimed=False,
                     actual_inputs_and_workspace_unchanged=True))

    # Actual source headers are correlation, not authentication. Identical
    # headers do not detect a private payload substitution by a broken issuer.
    alternate = bytearray(load(grow, 'source'))
    position = alternate.index(b'completed')
    alternate[position:position + 9] = b'alterated'
    control('same-shape-private-source-substitution-is-not-authentication', bytes(alternate),
            load(grow, 'command'), load(grow, 'before'), expect=384, poison=False)
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    actual.close()
    summary.update(actual_report_entries=actual.calls, actual_wire_entries=actual.wire.entries,
                   wall_ns=time.monotonic_ns() - started,
                   scope='ACTUAL_PRIVATE_REPORT_PROTOCOL_WITH_ISSUED_GRAPH_REQUIREMENT',
                   complete_worker=False, source_before_after_equal=True)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key not in ('results', 'completed')}, sort_keys=True), flush=True)
