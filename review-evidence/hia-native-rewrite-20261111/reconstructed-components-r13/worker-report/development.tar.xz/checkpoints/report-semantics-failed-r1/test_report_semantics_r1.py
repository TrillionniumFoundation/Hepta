"""Actual HIA report+wire against the original complete worker.main branches.

Service results, failures, installation readings and entropy are controlled
private fixtures. This does not claim execution of any native business service.
"""
from contextlib import ExitStack
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import traceback
import time
from unittest.mock import patch
import uuid

from worker_report_harness import ActualReport, inputs, ROOT, BASE
from hepta import hia_agent_worker as worker
from hepta import hia_agent_service as service
from hepta.hia_agent_store import AgentRejected, wire

OUT = ROOT / 'development/report-semantics-r1'
OUT.mkdir(exist_ok=False)
IDENTITIES = dict(worker_sha256='a' * 64, backend_sha256='b' * 64, catalog_sha256='c' * 64)
SEED = bytes(range(16))
ORIGINAL_MAIN = worker.main
ORIGINAL_DECODE = worker.decode_data
ORIGINAL_KEYS = worker.keys
ERROR_TYPE = AgentRejected
actual = ActualReport(OUT / 'actual')
rows = []
started = time.monotonic_ns()
summary = dict(status='INCOMPLETE')


def request(tool='hia_describe', arguments=None):
    body = dict(schema='hia-agent-worker-request-v1', tool=tool,
                arguments={'section': 'manifest'} if arguments is None else arguments,
                profile_sha256='d' * 64, catalog_sha256=IDENTITIES['catalog_sha256'])
    body['request_sha256'] = sha256(wire(body)).hexdigest()
    return body


def renew(body):
    body['request_sha256'] = sha256(wire({key: value for key, value in body.items()
                                       if key != 'request_sha256'})).hexdigest()
    return body


def observation(exc):
    value = {'message': str(exc), 'type': type(exc).__name__}
    for name in ('code', 'retry_action'):
        if hasattr(exc, name):
            value[name] = getattr(exc, name)
    return value


def oracle(raw, response=None, *, factory_error=None, call_error=None, close_error=None,
           after=None, manifest=False):
    captured = dict(parsed=None, entered=False, identities=IDENTITIES, errors=[], manifest_reads=0)
    stdout, stderr = io.BytesIO(), io.StringIO()

    def identities():
        captured['manifest_reads'] += 1
        result = IDENTITIES if captured['manifest_reads'] == 1 or after is None else after
        captured['identities'] = result
        return result

    def decode(value):
        try:
            result = ORIGINAL_DECODE(value)
        except BaseException as exc:
            captured['errors'].append(exc)
            raise
        captured['parsed'] = result
        return result

    def keys(*args, **kwargs):
        try:
            return ORIGINAL_KEYS(*args, **kwargs)
        except BaseException as exc:
            captured['errors'].append(exc)
            raise

    def rejected(*args, **kwargs):
        error = ERROR_TYPE(*args, **kwargs)
        captured['errors'].append(error)
        return error

    class Service:
        def __init__(self, *args, **kwargs):
            if factory_error is not None:
                captured['errors'].append(factory_error)
                raise factory_error

        def call(self, tool, arguments):
            captured['entered'] = True
            if call_error is not None:
                captured['errors'].append(call_error)
                raise call_error
            return response

        def close(self):
            if close_error is not None:
                captured['errors'].append(close_error)
                raise close_error

    escaped = None
    code = None
    with ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, {}, clear=True))
        stack.enter_context(patch.object(worker, 'installation_manifest', new=identities))
        stack.enter_context(patch.object(worker, 'decode_data', new=decode))
        stack.enter_context(patch.object(worker, 'keys', new=keys))
        stack.enter_context(patch.object(worker, 'AgentRejected', new=rejected))
        stack.enter_context(patch.object(service, 'HIAAgentService', new=Service))
        stack.enter_context(patch.object(worker.uuid, 'uuid4',
                                        new=lambda: uuid.UUID(bytes=SEED, version=4)))
        stack.enter_context(patch.object(sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(raw))))
        stack.enter_context(patch.object(sys, 'stdout', SimpleNamespace(buffer=stdout)))
        stack.enter_context(patch.object(sys, 'stderr', stderr))
        try:
            code = ORIGINAL_MAIN(['--installation-manifest'] if manifest else
                                 ['--state-root', str(OUT / 'never-created-state'), '--request-json-stdin'])
        except BaseException as exc:
            escaped = dict(type=type(exc).__name__, text=str(exc))
    assert not (OUT / 'never-created-state').exists()
    captured.update(stdout=stdout.getvalue(), stderr=stderr.getvalue().encode(), code=code,
                    escaped=escaped)
    return captured


def disabled(*args, **kwargs):
    raise AssertionError('retained worker policy invoked during native forwarding')


def exercise(label, value=None, response=None, **kwargs):
    raw = value if type(value) is bytes else wire(request() if value is None else value)
    expected = oracle(raw, response, **kwargs)
    disposition = 3 if kwargs.get('manifest') else (
        (2 if expected['entered'] else 1) if expected['errors'] else 0)
    error = observation(expected['errors'][0]) if expected['errors'] else None
    if disposition == 2 and error is None:
        raise AssertionError('entered rejection has no original exception')
    source, command = inputs(expected['parsed'], expected['identities'], response, error,
                             disposition, request_id=len(rows) + 1)
    case = OUT / ('case-' + str(len(rows)).zfill(3))
    case.mkdir()
    (case / 'request.json').write_bytes(raw)
    (case / 'oracle-stdout.bin').write_bytes(expected['stdout'])
    (case / 'oracle-stderr.bin').write_bytes(expected['stderr'])
    observation_record = {key: value for key, value in expected.items()
                          if key not in ('stdout', 'stderr', 'errors')}
    observation_record['errors'] = [observation(exc) for exc in expected['errors']]
    (case / 'oracle-observations.json').write_text(json.dumps(observation_record, ensure_ascii=True,
                                                            indent=2, sort_keys=True) + '\n')
    with ExitStack() as stack:
        stack.enter_context(patch.object(worker, 'main', new=disabled))
        stack.enter_context(patch.object(worker, 'wire', new=disabled))
        stack.enter_context(patch.object(worker, 'decode_data', new=disabled))
        stack.enter_context(patch.object(service, 'HIAAgentService', new=disabled))
        stack.enter_context(patch('json.loads', new=disabled))
        result = actual.run(source, command, label, entropy=SEED)
    (case / 'actual-output.bin').write_bytes(result['output'])
    if expected['escaped']:
        assert result['kind'] == 'wire-error' and result['error'] == expected['escaped']['text'], (label, result, expected['escaped'])
    elif expected['code'] == 2:
        assert result['kind'] == 'stderr' and result['exit_code'] == 2
        assert result['output'] == expected['stderr'] and not expected['stdout'], label
        assert result['entropy_requests'] == 0
    else:
        assert result['kind'] == 'stdout' and result['exit_code'] == 0
        assert result['output'] == expected['stdout'] and not expected['stderr'], (label, result['output'], expected['stdout'])
        assert result['entropy_requests'] == int(disposition in (1, 2))
    row = {key: value for key, value in result.items() if key != 'output'}
    row.update(status='PASS', bytes=len(result['output']), sha256=sha256(result['output']).hexdigest(),
               original_worker_main_oracle=True, native_report_and_wire=True,
               controlled_service_identity_entropy=True, native_business_service_claimed=False,
               disposition=disposition)
    rows.append(row)
    (case / 'result.json').write_text(json.dumps(row, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: row[key] for key in ('case', 'status', 'kind', 'bytes', 'entropy_requests')}, sort_keys=True), flush=True)


try:
    tools = ('hia_describe', 'hia_artifact', 'hia_read', 'hia_context', 'hia_inspect',
             'hia_candidate', 'hia_verify', 'hia_emit', 'hia_evaluate', 'hia_adopt', 'hia_rollback')
    for tool in tools:
        response = dict(contract_version='hepta.hia.agent-native.v1', request_id='r-test',
                        status='completed', result=dict(tool=tool, bytes='汉字😀', ratio=1.25, zero=-0.0))
        exercise('forward-complete-' + tool, request(tool), response)
    exercise('forward-alias-unchanged', request('hia_resource_read'), {'status': 'completed', 'result': None})
    exercise('forward-service-rejection', request(), {'status': 'rejected', 'error': {'code': 'E_HIA_TOOL', 'message': 'unknown HIA tool'}})
    exercise('manifest-only', request(), manifest=True)
    for label, raw in (('bad-json', b'{'), ('duplicate-json', b'{"x":1,"x":2}'),
                       ('bad-utf8', b'\xff'), ('nonfinite', b'1e9999'),
                       ('scalar-null', b'null'), ('scalar-list', b'[]')):
        exercise(label, raw)
    cases = []
    value = request(); value['schema'] = 'wrong'; cases.append(('wrong-schema', value))
    value = request(); value['request_sha256'] = '0' * 64; cases.append(('wrong-digest', value))
    value = request(); value['profile_sha256'] = None; cases.append(('null-digest-preserved', value))
    value = request(); value['tool'] = []; renew(value); cases.append(('nonstring-tool-preserved', value))
    value = request(); value['tool'] = '😀' * 129; renew(value); cases.append(('tool-codepoints-not-bytes', value))
    value = request(); value['catalog_sha256'] = 'f' * 64; renew(value); cases.append(('stale-catalog', value))
    value = request(); value.pop('arguments'); cases.append(('correlated-missing-arguments', value))
    value = request(); value.pop('profile_sha256'); cases.append(('uncorrelated-missing-profile', value))
    value = request(); value['extra'] = True; cases.append(('correlated-extra-field', value))
    for label, value in cases:
        exercise(label, value)
    for count in (0, 4095, 4096, 4097):
        exercise('pre-service-Unicode-' + str(count), request(), factory_error=ValueError('😀' * count))
    for error in (OSError('store is unavailable'), TypeError('type problem'), OverflowError('too large'),
                  RecursionError('recursive'), AgentRejected('E_TEST', 'observed', retry_action='stop')):
        exercise('pre-service-' + type(error).__name__, request(), factory_error=error)
    special = ValueError('nullable fields'); special.code = None; special.retry_action = None
    exercise('nullable-exception-attributes', request(), factory_error=special)
    exercise('entered-call-error', request(), call_error=ValueError('private call failure'))
    exercise('entered-close-error', request(), {'status': 'completed'}, close_error=OSError('close failure'))
    exercise('entered-call-and-close-error', request(), call_error=ValueError('original'), close_error=OSError('replacement'))
    for field in IDENTITIES:
        after = {**IDENTITIES, field: 'e' * 64}
        exercise('fresh-manifest-change-' + field, request(), {'status': 'completed'}, after=after)
    exercise('unicode-error-prefix', request(), factory_error=ValueError('a' * 4095 + '😀' + 'trailing'))
    exercise('normal-arbitrary-response-value', request(), [0, -0.0, 1e15, '汉字', None])
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    actual.close()
    summary.update(actual_report_entries=actual.calls, actual_wire_entries=actual.wire.entries,
                   wall_ns=time.monotonic_ns() - started,
                   scope='ACTUAL_NATIVE_WORKER_REPORT_COMPONENT_ORIGINAL_MAIN_ORACLE_WITH_CONTROLLED_SERVICE',
                   complete_worker=False, native_business_service=False,
                   source_before_after_equal=True)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key not in ('results', 'completed')}, sort_keys=True), flush=True)
