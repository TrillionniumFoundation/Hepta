"""Native five-storage-class comparison for the complete namespace engine.

The generated HIA owns SQL NULL comparison, index order, exact INTEGER/REAL
comparison and bytewise BINARY collation. This authoring module never evaluates
stored values. Physical leases and scalar affinity remain separate peers.
"""
from __future__ import annotations

import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_agent_namespace_store import VALUES
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANCP01', 'little')
BAD = 0xfffffffd

COMPARE = r'''
def namespace_compare(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < 128:
        return 4294967293
    if get(w, 8) == 2:
        return emit(o, w, 4294967293)
    if length(o) < 128:
        return poison(w, 1)
    if get(w, 0) == 0:
        at = 0
        while at < 128:
            if byte(w, at) != 0:
                poison(w, 2)
                return emit(o, w, 4294967293)
            at = at + 1
    elif valid_state(w) == 0:
        poison(w, 2)
        return emit(o, w, 4294967293)
    if frame(s, w) == 0:
        poison(w, 3)
        return emit(o, w, 4294967293)
    command = read64(s, 8)
    left = 64
    if cell_valid(s, left) == 0:
        poison(w, 4)
        return emit(o, w, 4294967293)
    right = left + 16 + read64(s, left + 8)
    if command == 3:
        if right != length(s):
            poison(w, 4)
            return emit(o, w, 4294967293)
    else:
        if cell_valid(s, right) == 0:
            poison(w, 4)
            return emit(o, w, 4294967293)
        if read64(s, right + 8) != length(s) - right - 16:
            poison(w, 4)
            return emit(o, w, 4294967293)
    left_kind = effective_kind(s, left)
    right_kind = 0
    result = left_kind
    if command != 3:
        right_kind = effective_kind(s, right)
        result = compare_cells(s, left, right, left_kind, right_kind, command)
    put(w, 0, COMPARE_MAGIC)
    put(w, 8, 1)
    put(w, 16, read64(s, 16))
    put(w, 24, read64(s, 24))
    put(w, 32, read64(s, 32))
    put(w, 40, command)
    put(w, 48, read64(s, 40))
    put(w, 56, read64(s, 48))
    put(w, 64, left_kind)
    put(w, 72, right_kind)
    put(w, 80, result)
    put(w, 88, 0)
    return emit(o, w, 0)

def valid_state(w:mutbuf) -> u64:
    if get(w, 0) != COMPARE_MAGIC or get(w, 8) != 1:
        return 0
    if (get(w, 16) == 0 and get(w, 24) == 0) or get(w, 32) == 0 or get(w, 48) == 0:
        return 0
    command = get(w, 40)
    if command < 1 or command > 3 or get(w, 64) > 4 or get(w, 72) > 4 or get(w, 88) != 0:
        return 0
    if command == 3:
        if get(w, 56) != 0 or get(w, 72) != 0 or get(w, 80) != get(w, 64):
            return 0
    else:
        if get(w, 56) == 0 or get(w, 80) > 3:
            return 0
        if command == 2 and get(w, 80) > 2:
            return 0
        if command == 1:
            if get(w, 64) == 0 or get(w, 72) == 0:
                if get(w, 80) != 3:
                    return 0
            elif get(w, 80) == 3:
                return 0
    at = 96
    while at < 128:
        if get(w, at) != 0:
            return 0
        at = at + 8
    return 1

def frame(s:readbuf, w:mutbuf) -> u64:
    if length(s) < 80 or read64(s, 0) != COMPARE_MAGIC:
        return 0
    command = read64(s, 8)
    if command < 1 or command > 3:
        return 0
    if (read64(s, 16) == 0 and read64(s, 24) == 0) or read64(s, 40) == 0:
        return 0
    if read64(s, 56) != length(s) - 64:
        return 0
    if command == 3:
        if read64(s, 48) != 0:
            return 0
    elif read64(s, 48) == 0:
        return 0
    if get(w, 0) != 0:
        if read64(s, 16) != get(w, 16) or read64(s, 24) != get(w, 24):
            return 0
    if get(w, 32) == 18446744073709551615 or read64(s, 32) != get(w, 32) + 1:
        return 0
    return 1

def cell_valid(s:readbuf, at:u64) -> u64:
    if at > length(s) or length(s) - at < 16:
        return 0
    kind = read64(s, at)
    size = read64(s, at + 8)
    if kind > 4 or size > length(s) - at - 16:
        return 0
    if kind == 0:
        return choose(size == 0, 1, 0)
    if kind == 1 or kind == 2:
        return choose(size == 8, 1, 0)
    return 1

def effective_kind(s:readbuf, at:u64) -> u64:
    kind = read64(s, at)
    if kind == 2:
        bits = read64(s, at + 16)
        if ((bits >> 52) & 2047) == 2047 and (bits & 4503599627370495) != 0:
            return 0
    return kind

def compare_cells(s:readbuf, left:u64, right:u64, lk:u64, rk:u64, command:u64) -> u64:
    if lk == 0 or rk == 0:
        if command == 1:
            return 3
        if lk == rk:
            return 1
        return choose(lk == 0, 0, 2)
    if lk <= 2 and rk <= 2:
        a = read64(s, left + 16)
        b = read64(s, right + 16)
        if lk == 1 and rk == 1:
            return compare_signed(a, b)
        if lk == 2 and rk == 2:
            return compare_real(a, b)
        if lk == 1:
            return compare_integer_real(a, b)
        return reverse(compare_integer_real(b, a))
    if lk != rk:
        return choose(lk < rk, 0, 2)
    return compare_bytes(s, left + 16, read64(s, left + 8), right + 16, read64(s, right + 8))

def compare_unsigned(a:u64, b:u64) -> u64:
    if a < b:
        return 0
    if a > b:
        return 2
    return 1

def compare_signed(a:u64, b:u64) -> u64:
    an = a >> 63
    bn = b >> 63
    if an != bn:
        return choose(an == 1, 0, 2)
    return compare_unsigned(a, b)

def compare_real(a:u64, b:u64) -> u64:
    aa = a & 9223372036854775807
    bb = b & 9223372036854775807
    if aa == 0 and bb == 0:
        return 1
    an = a >> 63
    bn = b >> 63
    if an != bn:
        return choose(an == 1, 0, 2)
    result = compare_unsigned(aa, bb)
    return choose(an == 1, reverse(result), result)

def compare_integer_real(integer:u64, real:u64) -> u64:
    magnitude = integer
    negative = integer >> 63
    if negative == 1:
        magnitude = 0 - integer
    real_magnitude = real & 9223372036854775807
    real_negative = real >> 63
    if real_magnitude == 0:
        return compare_signed(integer, 0)
    if magnitude == 0:
        return choose(real_negative == 1, 2, 0)
    if negative != real_negative:
        return choose(negative == 1, 0, 2)
    result = compare_absolute_integer_real(magnitude, real_magnitude)
    return choose(negative == 1, reverse(result), result)

def compare_absolute_integer_real(integer:u64, real:u64) -> u64:
    exponent = real >> 52
    fraction = real & 4503599627370495
    if exponent == 2047:
        return 0
    if exponent < 1023:
        return 2
    power = exponent - 1023
    if power > 63:
        return 0
    significand = fraction | 4503599627370496
    if power >= 52:
        return compare_unsigned(integer, significand << (power - 52))
    shift = 52 - power
    integral = significand >> shift
    result = compare_unsigned(integer, integral)
    if result == 1 and (significand & ((1 << shift) - 1)) != 0:
        return 0
    return result

def compare_bytes(s:readbuf, a:u64, an:u64, b:u64, bn:u64) -> u64:
    count = choose(an < bn, an, bn)
    at = 0
    while at < count:
        left = byte(s, a + at)
        right = byte(s, b + at)
        if left != right:
            return choose(left < right, 0, 2)
        at = at + 1
    return compare_unsigned(an, bn)

def reverse(value:u64) -> u64:
    return 2 - value

def poison(w:mutbuf, reason:u64) -> u64:
    if get(w, 8) != 2:
        put(w, 88, reason)
    put(w, 0, COMPARE_MAGIC)
    put(w, 8, 2)
    return 4294967293

def emit(o:mutbuf, w:mutbuf, status:u64) -> u64:
    if length(o) < 128:
        return 4294967293
    put(o, 0, COMPARE_MAGIC)
    put(o, 8, status)
    at = 16
    while at < 96:
        put(o, at, get(w, at))
        at = at + 8
    put(o, 96, 1)
    put(o, 104, 0)
    put(o, 112, 0)
    put(o, 120, 0)
    return status
'''


def source_program():
    return COMPARE.replace('COMPARE_MAGIC', str(MAGIC)) + VALUES[VALUES.index('\ndef read64('):]


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i) for i, node in enumerate(nodes)}
    if len(names) != len(nodes):
        raise ValueError('duplicate namespace compare HIA symbol')
    signatures = {node.name: ([a.annotation.id for a in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    functions = []
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name],
                          'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8',
                                  'module': 'agent_namespace_compare', 'functions': functions})


def main():
    path = ROOT / 'examples/hia_bootstrap/agent_namespace_compare.hiaasm'
    path.write_text(render_assembly(document()))
    print(path.name, path.stat().st_size)


if __name__ == '__main__':
    main()
