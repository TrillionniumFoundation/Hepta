"""Test-only SQLite oracle with exact five-class cells, including raw TEXT.

No production namespace module imports this fixture. An explicit library is
loaded exactly and never falls back. The recorded SQLite version/source id is
part of development evidence, not a claim that every installed system agrees.
"""
from __future__ import annotations

import ctypes as C
import ctypes.util
import os
from pathlib import Path
import struct


def cell(value):
    if value is None:
        return (0, b'')
    if type(value) is int:
        return (1, struct.pack('<q', value))
    if type(value) is float:
        return (2, struct.pack('<d', value))
    if type(value) is str:
        return (3, value.encode('utf-8'))
    if type(value) is bytes:
        return (4, value)
    raise TypeError(type(value))


def envelope(value):
    kind, payload = value
    return struct.pack('<QQ', kind, len(payload)) + payload


class SQLiteReference:
    def __init__(self):
        selected = os.environ.get('HIA_NAMESPACE_SQLITE_REFERENCE')
        name = selected or ctypes.util.find_library('sqlite3')
        if not name:
            raise RuntimeError('SQLite reference library is required by development tests')
        if selected:
            name = str(Path(selected).resolve(strict=True))
        self.path = name
        self.lib = C.CDLL(name)
        signatures = {
            'sqlite3_libversion': (C.c_char_p, []),
            'sqlite3_sourceid': (C.c_char_p, []),
            'sqlite3_open': (C.c_int, [C.c_char_p, C.POINTER(C.c_void_p)]),
            'sqlite3_close': (C.c_int, [C.c_void_p]),
            'sqlite3_errmsg': (C.c_char_p, [C.c_void_p]),
            'sqlite3_extended_result_codes': (C.c_int, [C.c_void_p, C.c_int]),
            'sqlite3_extended_errcode': (C.c_int, [C.c_void_p]),
            'sqlite3_get_autocommit': (C.c_int, [C.c_void_p]),
            'sqlite3_changes64': (C.c_int64, [C.c_void_p]),
            'sqlite3_prepare_v2': (C.c_int, [C.c_void_p, C.c_char_p, C.c_int, C.POINTER(C.c_void_p), C.POINTER(C.c_char_p)]),
            'sqlite3_finalize': (C.c_int, [C.c_void_p]),
            'sqlite3_reset': (C.c_int, [C.c_void_p]),
            'sqlite3_clear_bindings': (C.c_int, [C.c_void_p]),
            'sqlite3_bind_parameter_count': (C.c_int, [C.c_void_p]),
            'sqlite3_bind_null': (C.c_int, [C.c_void_p, C.c_int]),
            'sqlite3_bind_int64': (C.c_int, [C.c_void_p, C.c_int, C.c_int64]),
            'sqlite3_bind_double': (C.c_int, [C.c_void_p, C.c_int, C.c_double]),
            'sqlite3_bind_text64': (C.c_int, [C.c_void_p, C.c_int, C.c_void_p, C.c_uint64, C.c_void_p, C.c_ubyte]),
            'sqlite3_bind_blob64': (C.c_int, [C.c_void_p, C.c_int, C.c_void_p, C.c_uint64, C.c_void_p]),
            'sqlite3_step': (C.c_int, [C.c_void_p]),
            'sqlite3_column_count': (C.c_int, [C.c_void_p]),
            'sqlite3_column_type': (C.c_int, [C.c_void_p, C.c_int]),
            'sqlite3_column_int64': (C.c_int64, [C.c_void_p, C.c_int]),
            'sqlite3_column_double': (C.c_double, [C.c_void_p, C.c_int]),
            'sqlite3_column_text': (C.c_void_p, [C.c_void_p, C.c_int]),
            'sqlite3_column_blob': (C.c_void_p, [C.c_void_p, C.c_int]),
            'sqlite3_column_bytes': (C.c_int, [C.c_void_p, C.c_int]),
        }
        for symbol, (result, args) in signatures.items():
            function = getattr(self.lib, symbol)
            function.restype, function.argtypes = result, args
        self.version = self.lib.sqlite3_libversion().decode('ascii')
        self.source_id = self.lib.sqlite3_sourceid().decode('ascii')
        required = os.environ.get('HIA_NAMESPACE_SQLITE_REFERENCE_VERSION')
        if required and self.version != required:
            raise RuntimeError(('unexpected exact SQLite oracle', self.version, required))
        self.db = C.c_void_p()
        self.check(self.lib.sqlite3_open(b':memory:', C.byref(self.db)))
        self.check(self.lib.sqlite3_extended_result_codes(self.db, 1))
        self.statements = {}
        self.entries = 0

    def check(self, code):
        if code != 0:
            raise RuntimeError((code, self.lib.sqlite3_errmsg(self.db).decode('utf-8', 'replace')))

    def execute(self, sql, values=()):
        if sql not in self.statements:
            statement = C.c_void_p()
            tail = C.c_char_p()
            raw = sql.encode('utf-8')
            self.check(self.lib.sqlite3_prepare_v2(self.db, raw, len(raw), C.byref(statement), C.byref(tail)))
            if tail.value:
                self.lib.sqlite3_finalize(statement)
                raise ValueError('reference fixture executes one complete statement')
            self.statements[sql] = statement
        statement = self.statements[sql]
        self.check(self.lib.sqlite3_reset(statement))
        self.check(self.lib.sqlite3_clear_bindings(statement))
        if self.lib.sqlite3_bind_parameter_count(statement) != len(values):
            raise ValueError('reference bind arity')
        for index, (kind, payload) in enumerate(values, 1):
            if kind == 0 and payload == b'':
                code = self.lib.sqlite3_bind_null(statement, index)
            elif kind == 1 and len(payload) == 8:
                code = self.lib.sqlite3_bind_int64(statement, index, struct.unpack('<q', payload)[0])
            elif kind == 2 and len(payload) == 8:
                code = self.lib.sqlite3_bind_double(statement, index, struct.unpack('<d', payload)[0])
            elif kind in (3, 4):
                buffer = C.create_string_buffer(payload, max(1, len(payload)))
                if kind == 3:
                    code = self.lib.sqlite3_bind_text64(statement, index, buffer, len(payload), C.c_void_p(-1), 1)
                else:
                    code = self.lib.sqlite3_bind_blob64(statement, index, buffer, len(payload), C.c_void_p(-1))
            else:
                raise ValueError('reference cell shape')
            self.check(code)
        self.entries += 1
        rows = []
        while True:
            status = self.lib.sqlite3_step(statement)
            if status == 101:
                return {'rows': rows, 'changes': self.lib.sqlite3_changes64(self.db),
                        'autocommit': bool(self.lib.sqlite3_get_autocommit(self.db)), 'error': None}
            if status != 100:
                return {'rows': rows, 'changes': self.lib.sqlite3_changes64(self.db),
                        'autocommit': bool(self.lib.sqlite3_get_autocommit(self.db)),
                        'error': {'code': self.lib.sqlite3_extended_errcode(self.db),
                                  'message': self.lib.sqlite3_errmsg(self.db).decode('utf-8', 'replace')}}
            row = []
            for index in range(self.lib.sqlite3_column_count(statement)):
                kind = self.lib.sqlite3_column_type(statement, index)
                if kind == 5:
                    value = (0, b'')
                elif kind == 1:
                    value = (1, struct.pack('<q', self.lib.sqlite3_column_int64(statement, index)))
                elif kind == 2:
                    value = (2, struct.pack('<d', self.lib.sqlite3_column_double(statement, index)))
                else:
                    pointer = (self.lib.sqlite3_column_text if kind == 3 else self.lib.sqlite3_column_blob)(statement, index)
                    size = self.lib.sqlite3_column_bytes(statement, index)
                    value = (kind, C.string_at(pointer, size) if size else b'')
                row.append(value)
            rows.append(row)

    def compare(self, left, right, command=1):
        if command == 3:
            sql = 'SELECT typeof(?1)'
            row = self.execute(sql, (left,))['rows'][0]
            kind = {b'null': 0, b'integer': 1, b'real': 2, b'text': 3, b'blob': 4}[row[0][1]]
            return kind, kind, 0
        first = ('CASE WHEN ?1 IS NULL OR ?2 IS NULL THEN 3 '
                 if command == 1 else
                 'CASE WHEN ?1 IS NULL THEN CASE WHEN ?2 IS NULL THEN 1 ELSE 0 END WHEN ?2 IS NULL THEN 2 ')
        sql = 'SELECT ' + first + 'WHEN ?1 < ?2 COLLATE BINARY THEN 0 WHEN ?1 = ?2 COLLATE BINARY THEN 1 ELSE 2 END, typeof(?1), typeof(?2)'
        result = self.execute(sql, (left, right))
        if result['error']:
            raise AssertionError(result['error'])
        row = result['rows'][0]
        kinds = {b'null': 0, b'integer': 1, b'real': 2, b'text': 3, b'blob': 4}
        return struct.unpack('<q', row[0][1])[0], kinds[row[1][1]], kinds[row[2][1]]

    def close(self):
        statements, self.statements = self.statements, {}
        for statement in statements.values():
            self.lib.sqlite3_finalize(statement)
        if self.db:
            self.check(self.lib.sqlite3_close(self.db))
            self.db = C.c_void_p()
