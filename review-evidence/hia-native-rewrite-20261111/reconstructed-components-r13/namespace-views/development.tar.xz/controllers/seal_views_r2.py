from pathlib import Path
from hashlib import sha256
import gzip
import io
import json
import os
import stat
import tarfile
import time
import zipfile

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEV = BASE/'namespace-reconstruction/views-r1'
OUT = BASE/'namespace-reconstruction/views-r2-complete-01'
OUT.mkdir(exist_ok=False)
digest = lambda raw: sha256(raw).hexdigest()
result = json.loads((DEV/'native-r2/paired-validation/result.json').read_bytes())
assert result['status'] == 'PASS' and result['source_unchanged']
assert result['tests_loaded'] == result['tests_run'] == 8
assert result['paired_vm_entries'] == result['counters']['actual_native_entries'] == result['counters']['full_entry_bytes_equal'] == 3508
assert result['observations'] == 36
assert not any(result[k] for k in ('errors', 'failures', 'skipped', 'expected_failures', 'unexpected_successes'))
assert result['before'] == result['after']
assert all(digest(Path(p).read_bytes()) == h for p, h in result['before'].items())
r1 = json.loads((DEV/'native-r1/compile/agent-namespace-views.receipt.json').read_bytes())
assert r1['workspace_header']['40'] == 56 and r1['output_unchanged'] and r1['source_unchanged']


def read_dataset(path, native=None):
    with zipfile.ZipFile(path/'workspace-pages.zip') as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        pages = {}
        for name in names:
            raw = archive.read(name)
            assert 0 < len(raw) <= 4096 and digest(raw) == name
            pages[name] = raw
    def restore(record):
        raw = b''.join(pages[h] for h in record['pages'])
        assert len(raw) == record['bytes'] and digest(raw) == record['sha256']
        return raw
    entries = {}
    counts = {'vm_entries': 0, 'actual_preads': 0, 'sqlite_orders': 0, 'native_entries': 0,
              'full_native_vm_return_output_workspace_guard_equal': 0,
              'unique_pages': len(pages), 'decoded_page_bytes': sum(map(len, pages.values()))}
    with gzip.open(path/'invocations.jsonl.gz', 'rt', encoding='utf-8') as stream:
        for line in stream:
            row = json.loads(line)
            if row['kind'] == 'vm_entry':
                before, after = restore(row['workspace_before']), restore(row['workspace_after'])
                assert len(before) == len(after)
                entry = row['entry']
                assert entry == len(entries)+1
                entries[entry] = row
                counts['vm_entries'] += 1
            elif row['kind'] == 'actual_pread':
                assert row['issued_syscall_count'] <= row['requested'] <= 4096
                assert len(bytes.fromhex(row['returned_hex'])) <= row['issued_syscall_count']
                counts['actual_preads'] += 1
            elif row['kind'] == 'sqlite_order':
                assert row['expected_rowids'] == row['actual_rowids']
                counts['sqlite_orders'] += 1
            else:
                raise AssertionError(row['kind'])
    if native:
        with gzip.open(native, 'rt', encoding='utf-8') as stream:
            for line in stream:
                row = json.loads(line)
                vm = entries[row['entry']]
                assert row['entry'] == counts['native_entries']+1
                assert row['input_hex'] == vm['input_hex']
                assert restore(row['pre_workspace']) == restore(vm['workspace_before'])
                assert row['expected_return'] == row['actual_return'] == vm['return']
                expected, actual = restore(row['expected_workspace']), restore(row['actual_workspace'])
                assert expected == actual == restore(vm['workspace_after'])+bytes(range(160, 192))
                assert row['expected_output_hex'] == row['actual_output_hex'] == vm['output_hex']+bytes(range(160, 192)).hex()
                assert row['input_and_canary_unchanged'] is True
                counts['native_entries'] += 1
                counts['full_native_vm_return_output_workspace_guard_equal'] += 1
    recorded = json.loads((path/'counts.json').read_bytes())
    assert counts['vm_entries'] == recorded['entries'] and counts['actual_preads'] == recorded['actual_preads']
    assert counts['unique_pages'] == recorded['unique_workspace_pages']
    return counts


readbacks = {}
for name in ('smoke-r1', 'vm-r1', 'smoke-r2'):
    readbacks[name] = read_dataset(DEV/name/'vm-entries')
readbacks['actual-native-r2'] = read_dataset(DEV/'native-r2/paired-validation/vm-entries', DEV/'native-r2/paired-validation/native-invocations.jsonl.gz')
assert readbacks['actual-native-r2']['full_native_vm_return_output_workspace_guard_equal'] == 3508
(OUT/'paged-ledger-readback.json').write_text(json.dumps(readbacks, sort_keys=True, indent=2)+'\n')

selected = [('views/'+str(p.relative_to(DEV)), p) for p in DEV.rglob('*') if p.is_file()]
selected += [('controllers/run_views_vm.py', BASE/'namespace-reconstruction/run_views_vm.py'),
             ('controllers/seal_views_r2.py', Path(__file__).resolve()),
             ('paged-ledger-readback.json', OUT/'paged-ledger-readback.json')]
for name in ('docs/HIA_AGENT_NAMESPACE_STORE_ABI.json', 'tools/generate_hia_agent_namespace_store.py',
             'tools/generate_hia_agent_namespace_objects.py', 'tools/generate_hia_agent_namespace_compare.py',
             'tools/generate_hia_selfhost.py', 'tests/hia_namespace_sqlite_reference.py',
             'hepta/hia_agent_assembly.py', 'hepta/hia_program_runtime.py', 'hepta/hia_json_preflight_native.py'):
    selected.append(('authoring-dependencies/'+name, SOURCE/name))
selected.append(('next-unexecuted-draft/HIA_AGENT_NAMESPACE_COMMIT.md', SOURCE/'docs/HIA_AGENT_NAMESPACE_COMMIT.md'))
selected.sort()
assert len({name for name, _ in selected}) == len(selected)


def snapshot(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode)
    raw = path.read_bytes()
    after = path.lstat()
    identity = lambda v: (v.st_dev, v.st_ino, v.st_size, v.st_mtime_ns, v.st_ctime_ns, v.st_mode)
    assert identity(s) == identity(after)
    return raw, {'bytes': len(raw), 'sha256': digest(raw), 'mode': s.st_mode & 0o777,
                 'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}


members = []
for name, path in selected:
    _, s = snapshot(path)
    members.append({'name': name, 'original': str(path), **s})
custody = {'schema': 'hia.namespace-views-development-custody.v1',
           'scope': 'Native paged record view only; ten schemas, two existing orders, five classes, actual file range reads. No complete rowid allocator/immutable commit/migration/ordinary store/cold/full qualification claim. Next commit document is explicitly an unexecuted draft.',
           'r1_original_vm': {'tests': 8, 'entries': 3508, 'observations': 36},
           'r1_original_native_compile': {'status': 'REFUSED', 'error': 56, 'meaning': 'mutual tail call outside fixed compiler profile', 'original_full_output_and_receipt_retained': True},
           'r2_source_change': 'Exact AST inline of finish_scan into scan; all remaining ASTs identical; original compiler and every bound unchanged',
           'r2_actual_native_tests': 8, 'actual_native_entries': 3508, 'sqlite_order_and_file_observations': 36,
           'actual_preads': result['actual_preads'], 'actual_pread_bytes': result['actual_pread_bytes'],
           'fixed_workspace_bytes': 12288, 'max_requested_read_bytes': 4096,
           'image_sha256': result['image_sha256'], 'compiler_sha256': result['compiler_sha256'],
           'paged_ledgers_read_back': readbacks, 'members': members,
           'original_files': len(members), 'original_bytes': sum(row['bytes'] for row in members)}
custody_raw = (json.dumps(custody, sort_keys=True, indent=2)+'\n').encode()
(OUT/'custody.json').write_bytes(custody_raw)
archive = OUT/'namespace-views-r2-development.tar.xz'
partial = OUT/'namespace-views-r2-development.tar.xz.partial'
with partial.open('xb') as stream:
    if hasattr(os, 'posix_fallocate'):
        os.posix_fallocate(stream.fileno(), 0, custody['original_bytes']+len(custody_raw)+(1 << 20))
    with tarfile.open(fileobj=stream, mode='w:xz', preset=6) as tf:
        for row, (_, path) in zip(members, selected):
            raw, fresh = snapshot(path)
            assert all(fresh[k] == row[k] for k in fresh)
            info = tarfile.TarInfo(row['name']); info.size = len(raw); info.mode = row['mode']; info.mtime = 0
            tf.addfile(info, io.BytesIO(raw))
        info = tarfile.TarInfo('CUSTODY.json'); info.size = len(custody_raw); info.mode = 0o644; info.mtime = 0
        tf.addfile(info, io.BytesIO(custody_raw))
    stream.truncate(stream.tell())
    stream.flush(); os.fsync(stream.fileno())
partial.replace(archive)
with tarfile.open(archive, 'r:xz') as tf:
    actual = tf.getmembers()
    assert len(actual) == len(members)+1 and len({m.name for m in actual}) == len(actual)
    expected = {row['name']: row for row in members}
    for m in actual:
        assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
        raw = tf.extractfile(m).read()
        if m.name == 'CUSTODY.json':
            assert raw == custody_raw and m.mode == 0o644
        else:
            row = expected[m.name]
            assert m.mode == row['mode'] and len(raw) == row['bytes'] and digest(raw) == row['sha256']
            live, fresh = snapshot(Path(row['original']))
            assert raw == live and all(fresh[k] == row[k] for k in fresh)
raw = archive.read_bytes()
summary = {'status': 'ALL_ORIGINAL_MEMBERS_AND_COMPLETE_PAGED_LEDGERS_REPLAYED', 'scope': custody['scope'],
           'archive': str(archive), 'archive_bytes': len(raw), 'archive_sha256': digest(raw),
           'archive_members': len(members)+1, 'original_members': len(members), 'original_raw_bytes': custody['original_bytes'],
           'custody': str(OUT/'custody.json'), 'custody_bytes': len(custody_raw), 'custody_sha256': digest(custody_raw),
           'all_original_bytes_modes_inode_mtime_ctime_unchanged': True}
(OUT/'summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2)+'\n')
print(json.dumps(summary, sort_keys=True), flush=True)
