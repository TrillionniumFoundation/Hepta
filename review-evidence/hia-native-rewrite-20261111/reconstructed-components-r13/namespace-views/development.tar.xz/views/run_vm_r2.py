from pathlib import Path
from hashlib import sha256
import json
import os
import resource
import sys
import time
import unittest

BASE = Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE = BASE/'namespace-authoring-next'
DEV = BASE/'namespace-reconstruction/views-r1'
OUT = DEV/sys.argv[1]
OUT.mkdir(parents=True, exist_ok=False)
os.environ['HIA_NAMESPACE_VIEWS_LEDGER'] = str(OUT/'vm-entries')
os.environ['HIA_NAMESPACE_SQLITE_REFERENCE'] = str(BASE/'namespace-reconstruction/sqlite-3.46.1-reference-oracle/libsqlite346-reference.so')
os.environ['HIA_NAMESPACE_SQLITE_REFERENCE_VERSION'] = '3.46.1'
sys.path.insert(0, str(SOURCE))
resource.setrlimit(resource.RLIMIT_AS, (1024 << 20, 1024 << 20))
resource.setrlimit(resource.RLIMIT_CPU, (300, 300))
from tests.test_hia_agent_namespace_views import NamespaceViewsTests

pins = {}
for row in json.loads((DEV/'authoring-r2/source.json').read_bytes())['files']:
    p = SOURCE/row['path']; raw = p.read_bytes()
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256'] and p.stat().st_mode & 0o777 == row['mode']
    pins[str(p)] = sha256(raw).hexdigest()
for p in (Path(__file__).resolve(), SOURCE/'hepta/hia_program_runtime.py', SOURCE/'hepta/hia_agent_assembly.py',
          SOURCE/'tools/generate_hia_selfhost.py', SOURCE/'tools/generate_hia_agent_namespace_store.py',
          SOURCE/'tools/generate_hia_agent_namespace_objects.py', SOURCE/'tools/generate_hia_agent_namespace_compare.py',
          SOURCE/'docs/HIA_AGENT_NAMESPACE_STORE_ABI.json', SOURCE/'tests/hia_namespace_sqlite_reference.py',
          Path(os.environ['HIA_NAMESPACE_SQLITE_REFERENCE'])):
    pins[str(p)] = sha256(p.read_bytes()).hexdigest()
(OUT/'source-before.json').write_text(json.dumps(pins, sort_keys=True, indent=2)+'\n')
start = time.monotonic_ns()
names = sys.argv[2:]
suite = (unittest.TestSuite(NamespaceViewsTests(name) for name in names) if names else
         unittest.defaultTestLoader.loadTestsFromTestCase(NamespaceViewsTests))
ids = [test.id() for test in suite]
result = unittest.TextTestRunner(verbosity=2).run(suite)
after = {p: sha256(Path(p).read_bytes()).hexdigest() for p in pins}
(OUT/'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2)+'\n')
value = {'scope': 'DEVELOPMENT Core VM actual-file views only; no complete physical store/commit/migration qualification',
         'test_ids': ids, 'tests_loaded': len(ids), 'tests_run': result.testsRun,
         'errors': [(t.id(), s) for t, s in result.errors], 'failures': [(t.id(), s) for t, s in result.failures],
         'skipped': result.skipped, 'expected_failures': [(t.id(), s) for t, s in result.expectedFailures],
         'unexpected_successes': [t.id() for t in result.unexpectedSuccesses],
         'entries': getattr(NamespaceViewsTests, 'entries', 0), 'observations': getattr(NamespaceViewsTests, 'observations', 0),
         'actual_preads': getattr(NamespaceViewsTests, 'reads', 0), 'actual_pread_bytes': getattr(NamespaceViewsTests, 'bytes_read', 0),
         'source_unchanged': pins == after, 'wall_elapsed_ns': time.monotonic_ns()-start}
passed = (0 < result.testsRun == len(ids) and pins == after and (bool(names) or len(ids) == 8)
          and not any(value[k] for k in ('errors', 'failures', 'skipped', 'expected_failures', 'unexpected_successes')))
value['status'] = 'PASS' if passed else 'FAIL'
raw = (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()
(OUT/'result.json').write_bytes(raw)
print(json.dumps({'status': value['status'], 'tests': result.testsRun, 'entries': value['entries'],
                  'observations': value['observations'], 'result_sha256': sha256(raw).hexdigest()}, sort_keys=True), flush=True)
raise SystemExit(0 if passed else 1)
