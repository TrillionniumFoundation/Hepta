# Native ordinary Agent worker — implementation boundary

This is a new independent development overlay. The exact retained sources are copied and hashed in `checkpoints/baseline-r1/source.json`. No ordinary selector, installed entry, five-command stdio source, journal source, namespace source, or edit controller is modified here.

## Existing public boundary

`hepta.hia_agent_worker.main` is a one-request process protocol used by the existing runtime process owner. It is not MCP. Runtime authorization, durable job identity, cancellation, terminal report verification, and unknown-operation observation remain the existing external runtime's authority.

The worker reads administrator options and actual installation identities before reading at most 8 MiB plus one input byte. Expected worker/backend/catalog pins are checked before stdin admission and before creating a service/store. A decoded request is retained even if a later envelope check fails. A malformed request may produce a correlated rejected report only when its original object has all four correlation fields `tool`, `request_sha256`, `profile_sha256`, and `catalog_sha256`; their mere presence does not make their values admitted or authorize effects.

The request envelope owns exact required fields, schema, three canonical digest checks, canonical request digest, catalog equality, then the tool string type/code-point length. The existing complete `worker_request.hiaasm` already owns these semantic decisions and ordinary finite-binary64 canonicalization. It is not a replacement for service construction, service calls, state, report output, or the outer public diagnostic sequence.

Once service construction succeeds, the worker records service entry before calling it and always closes it. A caught exception after that point becomes the original `E_HIA_REQUEST_UNKNOWN` / `observe_original` report. Successful service return is followed by a fresh installation-manifest check; a changed manifest is retained as the report identity before the same unknown-result rejection. Protocol failure must not be disguised as confirmed successful service completion or retried as a new request.

The report has the original nine fields and complete response. The normal response is forwarded without a host schema planner. Rejection responses use the original fixed admission phase, `worker-` UUID, error code/default, first 4,096 Unicode code points of the message (or exception class when empty), retry action/default, and null details artifact. Report serialization is the original ordinary JSON wire profile: compact, sorted keys, UTF-8, finite numbers, 8 MiB, then a newline. This late wire failure is not silently converted into a successful report.

## Five commands and eleven tools are separate contracts

The existing native stdio command set is `capabilities`, `verify`, `compile`, `render-assembly`, and `assemble`. Its capabilities explicitly say edit and persistence are unimplemented. It does not call the ordinary worker.

The ordinary catalog has eleven tools: `hia_describe`, `hia_artifact`, `hia_read`, `hia_context`, `hia_inspect`, `hia_candidate`, `hia_verify`, `hia_emit`, `hia_evaluate`, `hia_adopt`, and `hia_rollback`. The journal also handles the existing `hia_resource_read` alias before validation. No tool is removed or invented here.

The complete native edit chain can implement the `hia_inspect` dependencies preparation operation. `hia_candidate` patching has a different existing contract: it receives a retained patch artifact and declared patch schema. That path must reuse the complete Core/patch/admission owners directly; replacing it with a query/response contract would change the public API. Other inspection views, assembly imports, proof/evaluation, and adoption still need their actual existing semantic owners.

## Implementation sequence

1. A complete HIA worker report and correlation owner takes actual issued request/result/identity Graphs and mechanical exception observations, and produces the exact full rejected response or worker report. It does not treat an arbitrary Graph header or hash as authority. Complete immutable source leases are retained across GROW.
2. A HIA worker controller owns pin-before-read, actual native request admission, service-open/call/close ordering, the single pending continuation, fresh installation recheck, report publication and permanent protocol refusal. Existing native JSON, request, Graph wire, and SHA images are reused. Private mechanical acknowledgement tests will be distinguished from a complete public worker run.
3. Native journal and namespace continuations are connected at their exact original commit points. The namespace ABI has ten tables and 31 fixed relational operations; no arbitrary SQL or reduced key/value substitute is added. A business callback remains an open semantic dependency until its actual HIA owner is connected. Python service calls must never be counted as native worker completion.
4. The fixed native executable and installable entry are composed only after the required actual services are connected. The clean-build owner may package the new source-bound worker as another entry; it continues to own the original five-command artifact independently.

## Ownership coordination

- `/root/audit_selfhost`: this overlay, complete worker outer request/control/report and the eventual fixed worker composition.
- `/root/native_checker`: `native-clean-build-next`, clean source-bound release/build gate, fixed build executor, and original five-command installed entry.
- `/root/audit_runtime`: namespace values, objects, transaction/log/physical state ownership and its ordinary integration.
- `/root`: shared native edit/public JSON route, cross-component integration, main, release identities and final qualification.

All work here is development. An envelope validator, journal decision image, private protocol test, or callback seam is not a full native Agent service or a completed eleven-tool worker.
