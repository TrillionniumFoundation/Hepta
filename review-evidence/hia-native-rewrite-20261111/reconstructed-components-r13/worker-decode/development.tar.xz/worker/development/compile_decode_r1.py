"""Source-bound development compile; no changed compiler or runtime budgets."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
sys.path[:0] = [str(ROOT / 'tools'), str(BASE / 'Hepta-agent-edit-native')]
from generate_hia_worker_decode import document
from hepta.hia_agent_assembly import assemble_program, render_assembly
from tools.qualify_hia_selfhost import compile_stage

OUT = ROOT / 'development/decode-compile-r1'
OUT.mkdir(exist_ok=False)
COMPILER = BASE / 'native-composite-core-final-recovery-next/dependencies/f50-B3.image.bin'
paths = sorted(p for folder in ('tools', 'docs', 'examples') for p in (ROOT / folder).rglob('*')
               if p.is_file() and '__pycache__' not in p.parts)
paths += [Path(__file__), COMPILER, ROOT / 'checkpoints/baseline-r1/source.json']
paths += [Path(row['path']) for row in json.loads((ROOT / 'checkpoints/baseline-r1/source.json').read_bytes())]
paths += [BASE / 'Hepta-agent-edit-native/tools/generate_hia_selfhost.py']
paths += [BASE / 'native-agent-edit-render-next/tools/generate_hia_edit_decode.py', BASE / 'native-agent-edit-render-next/tools/generate_hia_arena_graph.py', BASE / 'Hepta-agent-edit-native/tools/generate_hia_json_preflight.py', BASE / 'Hepta-agent-edit-native/tools/generate_hia_agent_binary64.py']
frozen = {p: p.read_bytes() for p in paths}
assert sha256(frozen[COMPILER]).hexdigest() == '0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
rows = []
for i, (path, raw) in enumerate(frozen.items()):
    target = OUT / 'source' / str(i) / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    rows.append(dict(path=str(path), copy=str(target), bytes=len(raw), sha256=sha256(raw).hexdigest()))
(OUT / 'source.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n')
summary = dict(status='INCOMPLETE', scope='WORKER_DECODE_DEVELOPMENT_NOT_COMPLETE_WORKER_OR_COLD',
               compile_cpu_seconds=10, compile_wall_seconds=20,
               compile_address_space_bytes=256 << 20)
started = time.monotonic_ns()
try:
    value = document()
    raw = render_assembly(value).encode()
    source = ROOT / 'examples/hia_bootstrap/agent_worker_decode.hiaasm'
    assert raw == frozen[source]
    assemble_program(raw)
    counts = dict(functions=len(value['functions']), blocks=sum(len(f['blocks']) for f in value['functions']),
                  max_blocks=max(len(f['blocks']) for f in value['functions']),
                  instructions=sum(len(b['ops']) for f in value['functions'] for b in f['blocks']),
                  max_block_params=max(len(b['params']) for f in value['functions'] for b in f['blocks']))
    assert counts['functions'] <= 128 and counts['blocks'] <= 1536 and counts['max_blocks'] <= 256
    assert counts['instructions'] <= 8192 and counts['max_block_params'] <= 16
    image, receipt = compile_stage(OUT, 'agent-worker-decode', COMPILER, raw)
    source_copy = OUT / 'source.hiaasm'
    source_copy.write_bytes(raw)
    manifest = dict(schema='hepta.hia.worker-decode-development.v1', scope='DEVELOPMENT_NOT_COLD',
                    source_path=str(source_copy), expected_source_path=str(source),
                    source_bytes=len(raw), source_sha256=sha256(raw).hexdigest(),
                    image_path=str(image), image_bytes=image.stat().st_size,
                    image_sha256=sha256(image.read_bytes()).hexdigest(),
                    compiler_sha256=sha256(frozen[COMPILER]).hexdigest(),
                    receipt_path=str(OUT / 'agent-worker-decode.receipt.json'))
    (OUT / 'agent-worker-decode.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    summary.update(status='PASS', counts=counts, manifest=manifest, receipt=receipt)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc))
    traceback.print_exc()
    raise
finally:
    summary['source_before_after_equal'] = all(p.read_bytes() == raw for p, raw in frozen.items())
    summary['wall_ns'] = time.monotonic_ns() - started
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True), flush=True)
    assert summary['source_before_after_equal']
