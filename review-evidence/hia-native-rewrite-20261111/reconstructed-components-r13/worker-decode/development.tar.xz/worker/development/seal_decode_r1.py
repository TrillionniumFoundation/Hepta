"""Seal exact completed bytes-decoder evidence, without copying an entire checkout."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
BOUNDARY = Path('/dev/shm/hia-worker-decode-boundaries-r1')
ARCHIVE = BASE / 'hia-native-agent-worker-decode-r1-development.tar.xz'
assert not ARCHIVE.exists()
files = {}


def add(path):
    path = Path(path).resolve()
    assert path.is_file() and not path.is_symlink()
    if '__pycache__' in path.parts:
        return
    if path.is_relative_to(ROOT):
        name = 'worker/' + path.relative_to(ROOT).as_posix()
    elif path.is_relative_to(BOUNDARY):
        name = 'large-boundaries/' + path.relative_to(BOUNDARY).as_posix()
    else:
        assert path.is_relative_to(BASE)
        name = 'dependencies/' + path.relative_to(BASE).as_posix()
    if name in files:
        assert files[name] == path
    files[name] = path


for rel in ('checkpoints/baseline-r1', 'checkpoints/decode-source-r1',
            'checkpoints/worker-decode-authoring-failed-r1', 'checkpoints/worker-decode-authoring-failed-r2',
            'development/decode-compile-r1', 'development/decode-semantics-r1',
            'development/decode-protocol-r1'):
    for path in (ROOT / rel).rglob('*'):
        if path.is_file():
            add(path)
for path in BOUNDARY.rglob('*'):
    if path.is_file():
        add(path)
for rel in ('tools/generate_hia_worker_decode.py', 'examples/hia_bootstrap/agent_worker_decode.hiaasm',
            'docs/HIA_AGENT_WORKER_DECODE_ABI.md', 'development/worker_decode_harness.py',
            'development/compile_decode_r1.py', 'development/test_decode_semantics_r1.py',
            'development/test_decode_protocol_r1.py', 'development/test_decode_boundaries_r1.py',
            'development/decode-boundaries-r1-summary.json', 'development/seal_decode_r1.py'):
    add(ROOT / rel)
for pattern in ('worker-decode-*.log', 'decode-*.log'):
    for path in (ROOT / 'development').glob(pattern):
        add(path)
for run in (ROOT / 'development/decode-semantics-r1', ROOT / 'development/decode-protocol-r1', BOUNDARY):
    summary = json.loads((run / 'summary.json').read_bytes())
    assert summary['status'] == 'PASS' and summary['source_before_after_equal']
    before = json.loads((run / 'actual/source-before.json').read_bytes())
    after = json.loads((run / 'actual/source-after.json').read_bytes())
    assert before == after
    for path, expected in before.items():
        assert sha256(Path(path).read_bytes()).hexdigest() == expected
        add(path)
for row in json.loads((ROOT / 'development/decode-compile-r1/source.json').read_bytes()):
    path = Path(row['path'])
    assert path.read_bytes() == Path(row['copy']).read_bytes()
    assert len(path.read_bytes()) == row['bytes'] and sha256(path.read_bytes()).hexdigest() == row['sha256']
    add(path)

# Check the complete lossless CAS against every original-byte identity in the
# actual large-run ledger before packaging the compressed members.
raw_members = {}
def find_raw(value):
    if isinstance(value, dict):
        if value.get('storage') == 'lossless-gzip':
            raw_members[value['path']] = value
        for child in value.values():
            find_raw(child)
    elif isinstance(value, list):
        for child in value:
            find_raw(child)
for line in (BOUNDARY / 'actual/entries.jsonl').read_text().splitlines():
    find_raw(json.loads(line))
find_raw(json.loads((BOUNDARY / 'summary.json').read_bytes()))
for name, row in raw_members.items():
    raw = gzip.decompress((BOUNDARY / 'actual/raw' / name).read_bytes())
    assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']

members = []
with tarfile.open(ARCHIVE, 'w:xz', preset=6) as writer:
    for name, path in sorted(files.items()):
        raw = path.read_bytes()
        row = dict(name=name, original=str(path), bytes=len(raw), sha256=sha256(raw).hexdigest(),
                   mode=stat.S_IMODE(path.stat().st_mode))
        members.append(row)
        writer.add(path, arcname=name, recursive=False)
with tarfile.open(ARCHIVE, 'r:xz') as reader:
    actual = reader.getmembers()
    assert len(actual) == len(members)
    for entry, row in zip(actual, members):
        raw = reader.extractfile(entry).read()
        assert entry.name == row['name'] and entry.size == row['bytes'] and entry.mode == row['mode']
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        assert Path(row['original']).read_bytes() == raw
manifest = ARCHIVE.with_suffix('.members.json')
manifest.write_text(json.dumps(members, indent=2, sort_keys=True) + '\n')
custody = dict(archive=str(ARCHIVE), bytes=ARCHIVE.stat().st_size,
               sha256=sha256(ARCHIVE.read_bytes()).hexdigest(), members=str(manifest),
               member_manifest_sha256=sha256(manifest.read_bytes()).hexdigest(),
               member_count=len(members), member_bytes=sum(row['bytes'] for row in members),
               all_members_original_bytes_size_mode_sha_readback=True,
               compressed_original_cas_count=len(raw_members), compressed_original_cas_sha_readback=True,
               semantic_cases=319, protocol_cases=135, original_boundary_cases=6,
               original_authoring_import_failures_retained=2,
               scope='DEVELOPMENT_COMPLETE_WORKER_BYTES_DECODE_COMPONENT_NOT_WHOLE_WORKER')
ARCHIVE.with_suffix('.custody.json').write_text(json.dumps(custody, indent=2, sort_keys=True) + '\n')
print(json.dumps(custody, sort_keys=True), flush=True)
