"""Actual ordinary worker bytes decoder against the unselected decode_data."""
from pathlib import Path
import json
import math
import random
import struct
import time
import traceback

from worker_decode_harness import Actual, ROOT

OUT = ROOT / 'development/decode-semantics-r1'
OUT.mkdir(exist_ok=False)
actual = Actual(OUT / 'actual')
rows = []
summary = dict(status='INCOMPLETE')
started = time.monotonic_ns()


def check(label, raw, digits=4300):
    row = actual.check(raw, label, digits)
    rows.append(row)
    print(json.dumps({key: row[key] for key in ('case', 'status', 'outcome')}, sort_keys=True), flush=True)


try:
    valid = [b'null', b'true', b'false', b'0', b'-0', b'123456789012345678901234567890',
             b'0.0', b'-0.0', b'1.25', b'1e2', b'1E+2', b'-123.5e-3',
             b'1e-324', b'2.4703282292062327e-324', b'2.4703282292062328e-324',
             b'1.7976931348623157e308', b'1.7976931348623158e308', b'1e999999999999999999999',
             b'-1e99999', b'1e-999999999999999999',
             b'{"a": [1.25, -0.0, 0, 1e12], "b":true}',
             ' {"字": ["😀", "e2 .5 1.0"], "a":2} '.encode(),
             b'{"a":"\\ud83d\\ude00","n":0.125}', b'{"n":{"request_sha256":1.2}}',
             b'"\\\\\\\"0.0"']
    for i, raw in enumerate(valid):
        check('ordinary-value-' + str(i), raw)
    invalid = [b'', b' ', b'{', b'[', b'!', b'1.', b'1e', b'1e+', b'1e-', b'01.2',
               b'-01e2', b'-.1', b'.1', b'1.e2', b'1e2e3', b'[1.,2]', b'[1e+]',
               b'[1.0,]', b'{"x":1.0,}', b'{"x":1.0 "y":2}', b'{"x":1.0,"x":2}',
               b'{"x":1.0,"\\u0078":2}', b'NaN', b'Infinity', b'-Infinity',
               b'"\\ud800"', b'"\\udc00"', b'"\\ud800\\u0000"', b'"\\q"',
               b'"\\u0gg0"', b'"\\u00"', b'"\\', b'"unterminated', b'"\x00"',
               b'true false', b'null!', b'\xef\xbb\xbfnull', b'{}x', b'{1:2}', b'{"x" 1.0}']
    for i, raw in enumerate(invalid):
        check('grammar-first-' + str(i), raw)
    for raw in (b'\x80', b'\xbf', b'\xc0', b'\xc1', b'\xc2', b'\xc2!', b'\xdf',
                b'\xe0\x80\x80', b'\xed\xa0\x80', b'\xe2\x82', b'\xe2\x82!',
                b'\xf0\x80\x80\x80', b'\xf4\x90\x80\x80', b'\xf0\x90\x80',
                b'\xf0\x90\x80!', b'\xf5\x80\x80\x80', b'\xff'):
        check('utf8-start-' + raw.hex(), raw)
        check('utf8-after-earlier-grammar-' + raw.hex(), b'! [ 00 "' + raw)
    for first in range(128, 256):
        check('every-high-leading-byte-' + str(first), bytes([first]) + b'"')
    for depth in (127, 128, 129):
        check('depth-' + str(depth), b'[' * depth + b'1.25' + b']' * depth)
    for count in (639, 640, 641, 4300, 4301):
        for digits in (640, 4300, 0):
            check('digits-' + str(count) + '-' + str(digits), b'7' * count, digits)
    check('complete-preflight-before-oversized-integer', b'[' + b'7' * 4301 + b',]', 4300)
    check('complete-preflight-before-nonfinite', b'[1e9999,]', 4300)
    check('integer-first-before-nonfinite', b'[' + b'7' * 4301 + b',1e9999]', 4300)
    check('nonfinite-first-before-integer', b'[1e9999,' + b'7' * 4301 + b']', 4300)
    randomizer = random.Random(0x51f7)
    for i in range(64):
        bits = randomizer.getrandbits(64)
        value = struct.unpack('<d', struct.pack('<Q', bits))[0]
        if math.isfinite(value):
            check('binary64-roundtrip-' + str(i), repr(value).encode())
    for i, token in enumerate((b'1e+', b'0.1e-', b'9E', b'1.e2', b'-0.0.0', b'01e2')):
        check('regex-prefix-object-' + str(i), b'{"x":' + token + b',"y":2}')
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    actual.close()
    summary.update(entries=actual.entries, wall_ns=time.monotonic_ns() - started,
                   source_before_after_equal=True,
                   scope='ACTUAL_THREE_IMAGE_WORKER_BYTES_DECODE_COMPONENT',
                   complete_worker=False, native_business_service=False)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key not in ('results', 'completed')}, sort_keys=True), flush=True)
