# Ordinary worker bytes decoder — development r1

This component implements the complete original `decode_data` behavior for the exact byte input read by the ordinary worker. It is separate from the integer-only program and edit JSON input contracts. It emits the complete normalized value as an issued Graph, including finite IEEE-754 binary64 values, or the original exception text and an unambiguous exception category. It does not execute any of the eleven business tools, scan the installed package, or activate an ordinary worker entry.

## Original decision order

1. The complete input undergoes strict UTF-8 decoding. The HIA code preserves the original first invalid sequence, its byte range, single-byte versus multi-byte message form, and invalid-start, invalid-continuation or incomplete-sequence reason. This happens before the byte ceiling; a bad byte in an oversized input retains priority.
2. Valid UTF-8 input above 8 MiB is refused with the original Agent JSON error.
3. Only outside strings, the same ASCII regular-expression number prefixes as the original implementation are recognized. Complete fractional or exponent tokens are replaced by one zero in a temporary preflight source. Invalid suffixes remain in place. Incomplete fractional/exponent suffixes retain the same longest valid prefix behavior. Strings, escapes, keys and original wire bytes are not changed.
4. The complete original integer preflight operates over that temporary source, with 262,144 value nodes and depth 128. It preserves all twenty diagnostic reasons, decoded duplicate-key checks, and budget order. This whole preflight completes before any numeric conversion error.
5. The unchanged actual general JSON decoder emits an arena from the original wire. The unchanged actual arena-to-Graph owner then converts integers and binary64 values in original source order. Its finite-number flag is one. The complete original integer digit-limit and nonfinite-number texts are rendered by HIA.
6. The resulting full Graph is copied into the controller's private workspace before publication. This may be larger than 8 MiB: the 8 MiB input budget is not reused as an internal Graph limit.

The worker calls this bytes contract. Private Python `str` input, arbitrary subclasses, exception traceback objects and selected-image custody failures are not silently included in this byte-entry claim.

## Private protocol

The retained RWW ABI is immutable raw bytes, a second buffer borrowed read-only, and mutable private workspace. A fresh invocation starts with zero workspace of at least 512 bytes. The exact initial eight-word command is:

`[HIAWDC01, lease, request, 9, integerDigitLimit, 0, 0, 0]`

Lease and request are nonzero; kind 9 explicitly identifies the worker's exact byte contract. Zero disables the interpreter's integer conversion limit. The actual worker captures that profile once; this interface does not invent a new digit limit.

Ordinary events return 128 and occupy the first 128 bytes of workspace:

`[HIAWDE01, action, lease, request, phase, neededWorkspace, peer, readOffset, readBytes, commandOffset, commandBytes, peerOutputBytes, peerWorkspaceBytes, errorCode, outputOffset, outputBytes]`

Actions are 0 complete Graph, 1 GROW, 2 fixed native peer call, and 3 complete user refusal. The final view is given by the last two fields. Phase 90 is successful; phase 99 is terminal. BAD `0xfffffffd` is a private protocol failure and takes precedence over any old event. With a complete workspace it permanently closes the invocation. A workspace shorter than 512 bytes cannot record poison; every BAD therefore requires the fixed executor to discard the lease.

Peer 1 is the actual general JSON arena decoder. HIA supplies its exact `[262144,128]` configuration and bounded allocation sizes. Its immutable reply is:

`[HIAWDR01, lease, request, 1, actualReturn, actualAllocatedOutputBytes, 0, 0] + completeActualOutput`

Peer 2 is the actual arena-to-Graph owner. HIA generates its complete `HIAGAC01` command plus the identical original wire, using the actual peer-1 arena extent. The mechanical executor serves peer-2 growth without repeating peer 1. Its reply is:

`[HIAWDR01, lease, request, 2, 128, actualWorkspaceBytes, 0, 0] + completeActualWorkspace`

The controller validates both complete reply envelopes, actual events, counts, profiles, error metadata, Graph headers and view arithmetic. Controller GROW replays the same immutable initial command or the same actual peer reply; it never calls the producer again merely because the controller needs space. Phase 11 pins the full decoder and arena header; phase 21 pins the complete Graph event and Graph header. These checks are correlation, not authentication of substituted same-shape buffers. The fixed issuer must retain the actual immutable source and actual native reply leases.

## Refusal categories

The complete output text is authoritative. Error code 3 denotes the original `UnicodeDecodeError`; code 4 denotes the original `OverflowError` for preflight node/depth refusal. Codes 2 and 9 denote `AgentRejected` with code `E_HIA_JSON`, respectively the byte ceiling and nonfinite numeric conversion. Code 6 and codes 101–120 denote the original `ValueError` for integer conversion and the twenty preflight reasons; code 5 denotes the decoded duplicate-key `ValueError`. A caller may materialize this category mechanically, but must not redo parsing or replace the complete text with a generic error.

## Actual development evidence

The HIA source is 202,074 bytes, SHA-256 `8199058980e8192485477b7b06a1ac4383a19f069431c3844c27eaf00a4f5414`; the actual image is 279,454 bytes, SHA-256 `cabd40762fb15e065c403ecfb19828e481889759813c7650560d7783af42cab0`. It contains 25 functions, 666 blocks and 3,385 instructions, with maximum function size 221 blocks and 14 block parameters. The exact historical f50 B3 compiled it under the unchanged 10 CPU seconds, 20 wall seconds and 256 MiB limits. Two earlier development import failures are retained with their exact source and logs.

Three separate actual groups passed:

| Group | Cases | Actual controller / decoder / Graph entries |
| --- | ---: | ---: |
| Original `decode_data` semantic comparison | 319 | 1,011 / 108 / 216 |
| Private protocol and exact-growth controls | 135 | 276 / 1 / 2 |
| Full original byte/node boundaries | 6 | 20 / 2 / 4 |

The six boundary cases include acceptance of an exact 8 MiB value and exact 262,144-node array, their plus-one refusals, invalid UTF-8 before the oversized-byte refusal, and oversized bytes before grammar. This group completed in 14.601 seconds with unchanged 90 CPU seconds and 1 GiB development process limits. Its complete raw states are stored losslessly compressed. This is an execution observation, not a performance or cold-qualification claim.

The tests compare complete values, binary64 bits, insertion order, exception classes, codes and full text. Retained ordinary decoding, preflight, value materialization, worker execution and `json.loads` are disabled during actual forwarding. Immutable input bytes, canaries and all selected source/image pins are checked. The complete worker, native business services, installed package scan, ordinary selector, and whole-project qualification remain open.
