"""Unchanged ordinary worker byte/node limits through all three actual images."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import resource
import time
import traceback

from worker_decode_harness import Actual, ROOT

OUT = Path('/dev/shm/hia-worker-decode-boundaries-r1')
OUT.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))


class Compressed(Actual):
    def raw(self, value):
        key = sha256(value).hexdigest()
        path = self.rawdir / (key + '.bin.gz')
        if path.exists():
            assert gzip.decompress(path.read_bytes()) == value
        else:
            raw = gzip.compress(value, compresslevel=1, mtime=0)
            path.write_bytes(raw)
            assert gzip.decompress(path.read_bytes()) == value
        return dict(bytes=len(value), sha256=key, path=path.name, storage='lossless-gzip')


actual = Compressed(OUT / 'actual')
rows = []
summary = dict(status='INCOMPLETE')
started = time.monotonic_ns()
try:
    maximum = 8 << 20
    cases = (
        ('bytes-exact-8MiB', b'"' + b'a' * (maximum - 2) + b'"'),
        ('bytes-8MiB-plus-one', b'"' + b'a' * (maximum - 2) + b'" '),
        ('invalid-UTF8-before-byte-limit', b' ' * maximum + b'\xff'),
        ('byte-limit-before-grammar', b'!' + b' ' * maximum),
        ('nodes-exact-262144', b'[' + b','.join([b'0'] * 262143) + b']'),
        ('nodes-262145-refused', b'[' + b','.join([b'0'] * 262144) + b']'),
    )
    for label, raw in cases:
        row = actual.check(raw, label)
        rows.append(row)
        print(json.dumps({key: row[key] for key in ('case', 'status', 'outcome')}, sort_keys=True), flush=True)
    summary.update(status='PASS', cases=len(rows), results=rows)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    actual.close()
    summary.update(entries=actual.entries, wall_ns=time.monotonic_ns() - started,
                   source_before_after_equal=True, runtime_cpu_seconds=90, runtime_address_bytes=1 << 30,
                   scope='ACTUAL_WORKER_BYTES_DECODE_8MiB_AND_262144_BOUNDARIES', complete_worker=False)
    text = json.dumps(summary, indent=2, sort_keys=True) + '\n'
    (OUT / 'summary.json').write_text(text)
    (ROOT / 'development/decode-boundaries-r1-summary.json').write_text(text)
    print(json.dumps({key: value for key, value in summary.items() if key not in ('results', 'completed')}, sort_keys=True), flush=True)
