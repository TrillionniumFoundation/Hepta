"""Actual controller framing, original peer continuations, and growth custody."""
from hashlib import sha256
import ctypes
import json
from pathlib import Path
import struct
import time
import traceback

from worker_decode_harness import Actual, ROOT, mechanics

OUT = ROOT / 'development/decode-protocol-r1'
OUT.mkdir(exist_ok=False)
actual = Actual(OUT / 'actual')
rows = []
started = time.monotonic_ns()
summary = dict(status='INCOMPLETE')
BAD = 0xfffffffd
raw = b'null'


def load(row, name):
    record = row[name]
    data = (actual.rawdir / record['path']).read_bytes()
    assert len(data) == record['bytes'] and sha256(data).hexdigest() == record['sha256']
    return data


def buffer(data):
    target = mechanics.workspace(len(data))
    ctypes.memmove(target, data, len(data))
    return target


def changed(data, offset, value):
    result = bytearray(data)
    struct.pack_into('<Q', result, offset, value)
    return bytes(result)


def reject(label, source, second, state):
    work = buffer(state)
    returned, event = actual.invoke(source, second, work, len(state), label)
    assert returned == BAD, (label, returned, event)
    returned, event = actual.invoke(raw, initial, work, len(state), label + ':permanent')
    assert returned == BAD, (label, returned, event)
    rows.append(dict(case=label, status='PASS', original_state=actual.raw(state),
                     source=actual.raw(source), second=actual.raw(second),
                     permanent_refusal=True, private_protocol=True))


try:
    initial = struct.pack('<8Q', mechanics.COMMAND, mechanics.LEASE, mechanics.REQUEST, 9, 4300, 0, 0, 0)
    command = initial
    size = 512
    work = mechanics.workspace(size)
    for iteration in range(20):
        returned, event = actual.invoke(raw, command, work, size, 'actual-exact-growth-predecessor')
        assert returned == 128
        if event[1] == 1:
            assert event[5] > size
            replacement = mechanics.workspace(event[5])
            ctypes.memmove(replacement, work, size)
            work, size = replacement, event[5]
        elif event[1] == 2:
            start, count = event[7:9]
            offset, extent = event[9:11]
            control = ctypes.string_at(ctypes.addressof(work) + offset, extent)
            if event[6] == 1:
                command = actual.decoder(raw[start:start + count], control, event[11], event[12], 'actual-decoder')
            else:
                assert event[6] == 2
                command = actual.graph(command[start:start + count], control, event[12], 'actual-graph')
        else:
            assert event[1] == 0
            break
    else:
        raise AssertionError('actual exact-growth predecessor did not complete')
    actual.log.flush()
    records = [json.loads(line) for line in (actual.out / 'entries.jsonl').read_text().splitlines()]
    controller = [row for row in records if row['role'] == 'controller']
    phase_records = {}
    for record in controller:
        state = load(record, 'before')
        phase = struct.unpack_from('<Q', state, 272)[0]
        phase_records.setdefault(phase, record)
    assert set(phase_records) >= {0, 1, 10, 11, 20, 21}, phase_records.keys()
    zero = load(phase_records[0], 'before')
    for length in (0, 1, 63, 65, 128):
        reject('initial-command-extent-' + str(length), raw, (initial + bytes(128))[:length], zero)
    for offset, value in ((0, 0), (8, 0), (16, 0), (24, 4), (24, 10), (40, 1), (48, 1), (56, 1)):
        reject('initial-command-word-' + str(offset) + '-' + str(value), raw, changed(initial, offset, value), zero)
    for at in (256, 264, 280, 432, 511):
        state = bytearray(zero); state[at] = 1
        reject('dirty-initial-state-' + str(at), raw, initial, bytes(state))
    for phase in (1, 10, 11, 20, 21):
        record = phase_records[phase]
        state, second = load(record, 'before'), load(record, 'second')
        reject('phase-' + str(phase) + '-source-extent', raw + b' ', second, state)
        reject('phase-' + str(phase) + '-state-magic', raw, second, changed(state, 256, 0x77))
        if phase == 1:
            for offset in (8, 16, 24, 32, 40):
                value = struct.unpack_from('<Q', second, offset)[0]
                reject('growth-command-' + str(offset), raw, changed(second, offset, value + 1), state)
            continue
        for offset in (0, 8, 16, 24, 40, 48, 56):
            value = struct.unpack_from('<Q', second, offset)[0]
            reject('phase-' + str(phase) + '-reply-header-' + str(offset), raw,
                   changed(second, offset, value + 1), state)
        reject('phase-' + str(phase) + '-truncated-frame', raw, second[:-1], state)
    for phase in (10, 11):
        record = phase_records[phase]
        state, second = load(record, 'before'), load(record, 'second')
        for offset in (32, 64, 72, 80, 88, 96, 104, 112, 120):
            value = struct.unpack_from('<Q', second, offset)[0]
            reject('decoder-phase-' + str(phase) + '-field-' + str(offset), raw,
                   changed(second, offset, value + 1), state)
    for phase in (20, 21):
        record = phase_records[phase]
        state, second = load(record, 'before'), load(record, 'second')
        for offset, value in ((32, 129), (64, 0), (72, 2), (80, 99), (88, 99),
                              (96, (1 << 64) - 1), (104, 0), (112, 0), (120, 0),
                              (128, 1), (136, 1), (144, 1), (152, 640), (160, 0),
                              (168, 1), (176, 99), (184, 1)):
            reject('graph-phase-' + str(phase) + '-field-' + str(offset), raw,
                   changed(second, offset, value), state)
        base = 64 + struct.unpack_from('<Q', second, 104)[0]
        for offset in (0, 8, 16, 24, 32, 40, 48, 56):
            value = struct.unpack_from('<Q', second, base + offset)[0]
            reject('graph-phase-' + str(phase) + '-Graph-header-' + str(offset), raw,
                   changed(second, base + offset, value + 1), state)
    reject('completed-session-cannot-restart', raw, initial, load(controller[-1], 'after'))
    short = mechanics.workspace(511)
    before = bytes(short)
    source = mechanics.buffer(raw); command_buffer = mechanics.buffer(initial)
    result = actual.images['controller']._entry(source, len(raw), command_buffer, len(initial), short, 511)
    actual.entries['controller'] += 1
    assert result == BAD and bytes(short) == before
    rows.append(dict(case='short-workspace-requires-executor-lease-discard', status='PASS',
                     native_poison_claimed=False, actual_return=result))
    summary.update(status='PASS', cases=len(rows), results=rows,
                   all_predecessor_frames_from_actual_same_image_peers=True)
except BaseException as exc:
    summary.update(status='FAIL', error_class=type(exc).__name__, error=str(exc), completed=rows)
    traceback.print_exc()
    raise
finally:
    actual.close()
    summary.update(entries=actual.entries, wall_ns=time.monotonic_ns() - started,
                   source_before_after_equal=True, scope='ACTUAL_WORKER_DECODE_PRIVATE_PROTOCOL',
                   complete_worker=False)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key not in ('results', 'completed')}, sort_keys=True), flush=True)
