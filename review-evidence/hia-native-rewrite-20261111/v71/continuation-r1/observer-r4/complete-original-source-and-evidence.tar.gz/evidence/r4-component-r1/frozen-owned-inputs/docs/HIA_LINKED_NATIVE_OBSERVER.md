# HIA linked ELF observation transport

## Boundary and current status

This component moves the disposable **linked-selfhost observation child** into
a native executable emitted by HIA. It preserves the actual system loader for
the complete target shared object. It does not implement a general ELF linker,
compile submitted HIA on the host, or replace the compiler's language policy.

The component is being developed independently of the frozen
67382498b9d60bfecf3696d8c2cb632d8f20281b source. The first actual development run
passed: ordinary Core VM execution compared all 2,376 object bytes in 19 windows
before new native compilation; the native HIA packer emitted the same object;
the real linker constructed a 13,888-byte executable; six complete bytesum
observations matched the retained Python loader; actual bad-ELF and missing-f0
objects were refused by both loaders. That run used compiler
81b6fad94493546b5bf3f858248f25b19aded88bf8f3aaad18140aa317dac109 as a retained
development tool. It is not a current-source cold qualification of this new
component. A later local CPython 3.12.14 mechanism run retained 21 original-r3
observations: 12 accepted-boundary-whitespace differences and three ordinary
output losses after finalizer failure were reproduced; six existing controls
agreed. The original ai395 18-test run has an unknown terminal state and is not
reclassified by the local observations. This revision addresses those actual
differences. Its new complete component controls and the later exact integrated
cold chain remain separate gates.

All whole-language, whole-stack, default activation, live migration and legacy
deletion claims remain false. The old loader stays available as an independent
oracle and for the existing seed/shared direct-reference and generation paths.

## Source and executable custody

The maintained HIA program is
[linked_native_observer_packer.hiaasm](../examples/hia_bootstrap/linked_native_observer_packer.hiaasm).
Its authoring generator emits a fixed platform adapter, including every byte of
an ELF64 ET_REL object. It does not inspect target programs, dispatch on source
hashes, or translate target instructions.

The generated object has a text section, a relocation section, symbol and
string tables, section names, and a non-executable stack note. Its fixed foreign
symbols are __libc_start_main, dlopen, dlsym, dlerror and exit. Relocations are
the actual x86-64 PLT32 call relocations with addend -4. A real GNU linker
resolves them and emits the observer's dynamic executable. The interpreter path
comes from the running admitted Python executable's actual PT_INTERP, and its
bytes are bound in the build receipt. No target text extraction or replacement
of ELF relocation/loading occurs.

The independent GNU assembly source is a test oracle. It is not read by the
HIA packer or used to produce its executable. Tests compare its entire text and
normalized foreign relocation inventory against the HIA-produced object.
Separately, ordinary Core VM execution checks every object byte before any new
native packer compilation. These are different controls.

Each invocation copies the exact observer image into a memfd, installs all four
seals, and execs a new process. The target .so is copied in full into another
memfd, completely sealed and verified before dlopen. The loader uses
RTLD_LOCAL | RTLD_NOW, finds f0 through dlsym, then closes the file descriptor.
It keeps the loaded object for normal process lifetime. There is no early
dlclose, child reuse, in-process Python evaluation, or fallback from the selected
native linked path to the Python loader.

The raw F_GET_SEALS result is checked for a negative errno before testing seal
bits. This guard was added during source review, before any r1/r2 adapter was
machine-executed. It must not be described as a previously observed native
failure. The actual controlled EPERM test is a separate later observation.

## Actual ABI, limits and observations

The request frame retains the established byte ABI limits:

| Field | Bound |
| --- | ---: |
| Complete target image | 1 through 4 MiB |
| Source bytes | 0 through 1 MiB |
| Output capacity | 0 through 1 MiB |
| Workspace bytes | 0 through 1 MiB |
| Workspace fill | 0 through 255 |
| Native child wall limit | 20 seconds |
| Kernel CPU limit | 10 seconds |
| Kernel address-space limit | 256 MiB |
| Kernel stack limit | 8 MiB |
| Kernel file-size limit | 16 MiB |
| Kernel open-file limit | 32 |
| Core dumps | Disabled, including PR_SET_DUMPABLE |

These are the old qualification byte ABI limits. They are not new Core-language
parameter, return, recursion, object, or public-runtime limits.

The actual call remains the six-word foreign byte ABI. The complete u64 return
is retained: its upper half is the ABI status and its lower half the Core u32
value. The observer copies the actual source, output and workspace into the
response. Source immutability is checked against actual returned bytes. Selected
workspace fields, full output hashes, and resource metadata retain their old
meaning. Actual kernel queries in the test image check the limits rather than
trusting receipt constants.

CLOCK_MONOTONIC measures only the f0 call, as in the old child. Constructor and
finalizer time is still included in the parent's wall time. Deliberate UD2 stays
a real SIGILL termination; it is not caught and converted into a successful
native return.

The parent Python bridge still owns fixed framing, process supervision, byte
materialization and report files. The system linker, kernel, libc and dynamic
loader remain explicit foreign dependencies. This component makes no claim
that those interfaces, the qualification controller, the source parser or the
whole toolchain have all been rewritten by this change.

## Loader lifetime and output ordering

The executable enters through __libc_start_main and exits through libc exit.
The runtime loader's finalizer callback is retained. A bare exit syscall would
omit normal finalization and is not an equivalent implementation.

Return values and ordinary output are captured before normal process
finalizers. When the caller requests shared/trap-output observation, the parent
reads the actual shared mapping after process termination. A finalizer can
therefore change the final shared output while the returned report still
contains the pre-finalizer output hash. This ordering is preserved deliberately.
An explicit output preimage alone does not turn ordinary output into a
post-finalizer observation.

The r4 observer writes ordinary output to a separate parent-owned, size-sealed
snapshot memfd immediately after the f0 call and its ending clock observation.
Only after all output bytes are written does it publish the completion word
capacity+1. A zero word means f0 has not committed a return; capacity zero still
has the distinct completion word 1. This private snapshot is separate from the
live output mapping, so finalizers can change the shared postimage without
changing the captured ordinary bytes.

The request keeps its 56-byte size and existing source/image extents. Its new
HIAOBS03 header carries two 32-bit descriptors in the old descriptor word:
optional live output and mandatory return snapshot. Both are allocated by the
parent, validated before target loading and passed explicitly to the child.
The response uses HIAOBR03. Current and old private frames are not interchangeable.

If a finalizer exits nonzero, signals, or prevents normal process completion,
the parent retains the committed ordinary snapshot. It does not infer a
completed f0 from stdout: a constructor can emit a plausible response and exit
without ever calling f0, and a finalizer can append non-JSON noise after a real
return. A returned success requires agreement between the exact response
output and its committed snapshot. Shared/trap observations still use the live
mapping after termination, including real writes made before a trap.

The lifetime control uses a DSO-owned duplicate of a genuine shared mapping,
created by mremap with old_size=0. That duplicate survives release of the
original Python mapping. The finalizer writes through and unmaps its own
mapping. The test never dereferences a borrowed ctypes buffer after Python main
has released it. Clone success is required only in the actual shared-output
mode; a private or unaligned ctypes buffer can legitimately give EINVAL.

Constructor/call/finalizer events are recorded separately. Normal completion
must produce C/F/D, while a real trap after the call-side write produces C/F.
The ordinary and shared output modes are compared against the retained loader
on the same complete .so bytes.

## Response framing

The old linked child reports JSON on the same stdout used by a target's foreign
output. Its caller parses the complete stdout as text. Non-JSON noise is a
refusal; it is not skipped by searching for a later report.

The native response has a fixed header and length derived from the admitted
request. Its parser never searches for a later magic sequence. The original
JSON parser also accepts four ASCII boundary whitespace bytes: space, tab,
carriage return and line feed. The new parser must preserve that accepted
boundary explicitly: consume only this prefix, require magic at the first
non-whitespace byte, take the exact complete frame length, and verify that any
remaining bytes are only those four whitespace bytes. It must never strip the
frame payload, because legal source/output/workspace can end with the same
bytes.

The whitespace difference was first identified in source review and then
reproduced for all four accepted bytes at constructor, f0 and finalizer positions
in a separate local run. Those original negative controls remain distinct from
revised-parser controls. Unrelated private
protocol error text and Python traceback formatting are not claimed as a
general arbitrary-.so refinement theorem.

Stderr from constructors/finalizers is retained on successful calls, just as
with the old JSON child. Tests also cover non-whitespace stdout from the
constructor, f0 and finalizer. Their bytes must cause a framing refusal, not be
silently removed.

## Qualification integration

The integration proposal makes the qualifier's linked observer an explicit,
content-bound phase input. Until that separate change is applied and qualified,
the new component does not alter the existing qualifier dispatch.
Every phase request must include both native observers and their exact image
hashes. The same original complete input inventory checks and before/after
readback apply to the additional artifact. The selected linked branch has no
hosted semantic fallback.

The original B0 and B1/B2/B3, M1/M2/M3 generation order stays sequential. The
ordinary linked-packer VM reference runs before B0. Its actual native build is
performed after the existing generation chains. The phase family inventory,
all old semantic checks, worker count, original 20-second calls and original
180-second cold qualification plus 3-second cleanup are preserved.

New checks bind the before-B0 ordinary reference, exact HIA object emission and
actual system linker result. Existing seed/shared independent references and
generation controls continue to use their retained loader. All former phase
checks remain required.

## Component tests and scope labels

The source tests verify exact generated HIA, original compiler limits,
independent assembler bytes/relocations, and rejection of simultaneous cold and
development selections before reads or directory creation. Native tests cover
complete return words and output bytes, source-mutation observations, retained
workspace fields, the actual kernel limits,
complete HIA compiler success and refusal, allocator imports, normal and
abnormal finalization, shared postimages, actual seal errno failure, malformed
private frames and descriptor cleanup on storage or partial-allocation failure.
The real whitespace controls keep source/output/workspace payloads ending in
ASCII whitespace; finalizer controls include exit 23, stdout noise followed by
exit 23 and SIGILL, plus a constructor's fake response before f0 and a committed
zero-capacity return.

The explicit fixture inputs are:

- HEPTA_HIA_LINKED_OBSERVER_COLD_REPORT: a completed matching current-source cold
  report; all owned source files must be in its source closure.
- HEPTA_HIA_LINKED_OBSERVER_DEVELOPMENT_COMPILER: a retained compiler used only
  for an explicitly labelled development component run.
- HEPTA_HIA_LINKED_OBSERVER_EVIDENCE: the output root. After admission, its parent
  is created if needed; the candidate directory remains exclusively created.

Cold and development selectors are mutually exclusive. Without either, the
native test performs its own isolated source bootstrap, with its ordinary
reference before that bootstrap. Such a test is not relabelled as a cold
qualification report.

No small loader timing comparison establishes a whole cold-suite improvement.
Concurrent post-cold development work, source identities, tools, compiler
images, actual process terminal results, and all first failures are retained
with each run. A current integrated source can be called qualified only after
its own original source, cold and complete retained gates have actually run.
