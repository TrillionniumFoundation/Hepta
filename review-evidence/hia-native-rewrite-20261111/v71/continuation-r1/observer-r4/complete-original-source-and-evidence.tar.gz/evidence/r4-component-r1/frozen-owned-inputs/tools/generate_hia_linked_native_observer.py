"""Emit the fixed linked-ELF observation adapter as a HIA-produced ET_REL.

The emitted object is a platform transport, never a compiler for submitted HIA.
The real system linker constructs its dynamic executable; libc's startup and
exit path retain runtime-loader initialization/finalization. Each observation
still dlopens the complete sealed target object and looks up f0. No target text
is extracted, and no process is reused.

The old flat observer bytes are reused only for its audited fixed framing,
resource limits, buffers and measurement. A separately committed output snapshot
retains ordinary return bytes when a later target finalizer exits abnormally.
This authoring module is
not imported by an observer child. The HIA packer emits every object byte.
"""
from __future__ import annotations

import ast
from hashlib import sha256
from pathlib import Path
import struct

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_native_observer import ADAPTER
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

ROOT = Path(__file__).resolve().parents[1]
PACKER = ROOT / "examples/hia_bootstrap/linked_native_observer_packer.hiaasm"
FLAT_ADAPTER_SHA256 = "72574a19ff4e76326e6d90b5cde8b7c273ef8948808620f64387d40cf025d987"
IMPORTS = ("__libc_start_main", "dlopen", "dlsym", "dlerror", "exit")
IMAGE_SPAN = bytes.fromhex(
    "488b742410e8910100004989c54889c7498d742438488b4c2410fcf3a4"
    "4c89ef488b742410ba05000000b80a0000000f054885c00f85bb010000"
)


class _Code:
    """Small authoring relocation writer; it does not execute or parse inputs."""

    def __init__(self):
        self.data = bytearray()
        self.labels = {}
        self.local = []
        self.external = []

    def emit(self, hexadecimal):
        self.data.extend(bytes.fromhex(hexadecimal))

    def mark(self, name):
        if name in self.labels:
            raise AssertionError(("duplicate adapter label", name))
        self.labels[name] = len(self.data)

    def relative(self, opcode, name, width=4):
        self.emit(opcode)
        offset = len(self.data)
        self.data.extend(bytes(width))
        self.local.append((offset, name, width))

    def call(self, name):
        if name not in IMPORTS:
            raise AssertionError(("unknown fixed foreign symbol", name))
        self.emit("e8")
        self.external.append((len(self.data), name))
        self.data.extend(bytes(4))

    def text(self):
        for offset, name, width in self.local:
            value = self.labels[name] - (offset + width)
            self.data[offset:offset + width] = value.to_bytes(width, "little", signed=True)
        return bytes(self.data)


def adapter():
    if len(ADAPTER) != 931 or sha256(ADAPTER).hexdigest() != FLAT_ADAPTER_SHA256:
        raise AssertionError("the reviewed flat transport changed")
    c = _Code()
    c.mark("_start")
    # Standard SysV/glibc entry: preserve rtld_fini and register it through
    # __libc_start_main. Returning through a bare syscall would omit finalizers.
    c.emit("31ed4989d15e4889e24883e4f050544531c031c9")
    c.relative("488d3d", "main")
    c.call("__libc_start_main")
    c.emit("0f0b")
    start_size = len(c.data)
    c.mark("main")
    main = bytearray(ADAPTER)
    if main[:5] != bytes.fromhex("48833c2401"):
        raise AssertionError("original argc check changed")
    # main receives argc in edi. Keep the original five-byte instruction slot.
    main[:5] = bytes.fromhex("83ff019090")
    allocation = bytes.fromhex("4881ec00010000")
    if main.count(allocation) != 1:
        raise AssertionError("original stack reservation changed")
    at = main.index(allocation)
    # A main call has its return address on the stack. Keep every helper call
    # 16-byte aligned with an eight-byte-larger private frame.
    main[at:at + len(allocation)] = bytes.fromhex("4881ec08010000")
    if main.count(IMAGE_SPAN) != 1:
        raise AssertionError("original flat image mapping changed")
    if main.count(b"HIAOBS02") != 1:
        raise AssertionError("original fixed input magic changed")
    main = main.replace(b"HIAOBS02", b"HIAOBS03")
    fd_span = bytes.fromhex(
        "498b4424304883f8ff74164883f8030f82f3010000483dffffff7f0f87e7010000")
    if main.count(fd_span) != 1:
        raise AssertionError("original output descriptor validation changed")
    fd_at = main.index(fd_span)
    main[fd_at:fd_at + len(fd_span)] = b"\xe8" + bytes(4) + b"\x90" * (len(fd_span) - 5)
    c.local.append((len(c.data) + fd_at + 1, "validate_descriptors", 4))
    output_fd = bytes.fromhex("4d8b4424304983f8ff")
    if main.count(output_fd) != 1:
        raise AssertionError("original shared output descriptor load changed")
    main[main.index(output_fd):main.index(output_fd) + len(output_fd)] = bytes.fromhex("458b4424304183f8ff")
    captured = bytes.fromhex("488944247048b84849414f425230324889442460")
    if main.count(captured) != 1:
        raise AssertionError("original return capture changed")
    captured_at = main.index(captured)
    main[captured_at:captured_at + len(captured)] = b"\xe8" + bytes(4) + b"\x90" * (len(captured) - 5)
    c.local.append((len(c.data) + captured_at + 1, "snapshot_and_header", 4))
    image_at = main.index(IMAGE_SPAN)
    main[image_at:image_at + len(IMAGE_SPAN)] = (
        b"\xe8" + bytes(4) + bytes.fromhex("4989c5fc") + b"\x90" * (len(IMAGE_SPAN) - 9))
    c.local.append((len(c.data) + image_at + 1, "load_linked", 4))
    exit_at = len(main) - 9
    if main[exit_at:] != bytes.fromhex("b83c0000000f050f0b"):
        raise AssertionError("original terminal syscall changed")
    main[exit_at:] = b"\xe9" + bytes(4) + bytes.fromhex("0f0b9090")
    c.local.append((len(c.data) + exit_at + 1, "native_exit", 4))
    io_error = bytes.fromhex("bf04000000eb05bf40000000")
    if main.count(io_error) != 1:
        raise AssertionError("original error labels changed")
    c.labels["io_error"] = len(c.data) + main.index(io_error)
    invalid = bytes.fromhex("bf02000000")
    if main.count(invalid) != 1:
        raise AssertionError("original invalid-frame target changed")
    c.labels["invalid_frame"] = len(c.data) + main.index(invalid)
    c.data.extend(main)

    c.mark("validate_descriptors")
    # The unchanged 56-byte header holds two private 32-bit descriptors:
    # low = optional live output, high = mandatory pre-finalizer snapshot.
    # A source/target never chooses either descriptor.
    c.emit("418b44243483f803")
    c.relative("0f82", "invalid_frame")
    c.emit("3dffffff7f")
    c.relative("0f87", "invalid_frame")
    c.emit("418b54243083faff")
    c.relative("0f84", "descriptors_valid")
    c.emit("83fa03")
    c.relative("0f82", "invalid_frame")
    c.emit("81faffffff7f")
    c.relative("0f87", "invalid_frame")
    c.emit("39d0")
    c.relative("0f84", "invalid_frame")
    c.mark("descriptors_valid")
    c.emit("c3")

    c.mark("snapshot_and_header")
    # This call follows f0 and the second clock read. Save the original return
    # observation before libc exit can run target finalizers. The snapshot
    # commit is independent of stdout, so a constructor's fake frame cannot
    # invent a completed f0. r14 and r15 retain the live ABI buffers.
    c.emit("488944247848b8")
    c.data.extend(b"HIAOBR03")
    c.emit("4889442468418b7c24344c89f6488b5424284989d141ba080000004885d2")
    c.relative("0f84", "snapshot_commit")
    c.mark("snapshot_write")
    c.emit("b8120000000f054883f8fc")
    c.relative("0f84", "snapshot_write")
    c.emit("4885c0")
    c.relative("0f8e", "io_error")
    c.emit("4801c64901c24829c2")
    c.relative("0f85", "snapshot_write")
    c.mark("snapshot_commit")
    # Marker capacity+1 distinguishes a completed empty output from no call.
    # The payload is already complete before any marker byte is published.
    c.emit("498d4101504889e6ba080000004531d2")
    c.mark("snapshot_commit_write")
    c.emit("b8120000000f054883f8fc")
    c.relative("0f84", "snapshot_commit_write")
    c.emit("4883f808")
    c.relative("0f85", "io_error")
    c.emit("58c3")

    c.mark("load_linked")
    # On call entry rsp%16 == 8. Locals: fd[0], entry[8], path[16..96].
    c.emit("4883ec68")
    c.relative("488d3d", "target_name")
    c.emit("be02000000b83f0100000f054885c0")
    c.relative("0f88", "io_error")
    c.emit("48890424498d742438498b542408")
    c.mark("image_write")
    c.emit("488b3c24b8010000000f054883f8fc")
    c.relative("0f84", "image_write")
    c.emit("4885c0")
    c.relative("0f8e", "io_error")
    c.emit("4801c64829c2")
    c.relative("0f85", "image_write")
    # All four memfd seals, verified before the system loader sees the image.
    c.emit("488b3c24be09040000ba0f000000b8480000000f054885c0")
    c.relative("0f85", "io_error")
    c.emit("488b3c24be0a040000b8480000000f054885c0")
    c.relative("0f88", "io_error")
    c.emit("83e00f83f80f")
    c.relative("0f85", "io_error")
    # Format the actual owned descriptor, with no path supplied by the caller.
    c.emit("488d5c2460c60300488b0424b90a000000")
    c.mark("descriptor_digit")
    c.emit("31d248f7f180c23048ffcb88134885c0")
    c.relative("0f85", "descriptor_digit")
    c.emit("4883eb0e48b8")
    c.data.extend(b"/proc/se")
    c.emit("488903c74308")
    c.data.extend(b"lf/f")
    c.emit("66c7430c")
    c.data.extend(b"d/")
    c.emit("4889dfbe02000000")
    c.call("dlopen")  # RTLD_LOCAL | RTLD_NOW is exactly 0 | 2.
    c.emit("4885c0")
    c.relative("0f84", "loader_failure")
    c.emit("4889c7")
    c.relative("488d35", "entry_name")
    c.call("dlsym")
    c.emit("4885c0")
    c.relative("0f84", "loader_failure")
    c.emit("4889442408488b3c24b8030000000f054885c0")
    c.relative("0f85", "io_error")
    c.emit("488b4424084883c468c3")

    c.mark("loader_failure")
    # Preserve the actual foreign loader diagnostic. No signal is intercepted,
    # and no dlclose is added: target lifetime lasts until normal process exit.
    c.call("dlerror")
    c.emit("4885c0")
    c.relative("0f84", "loader_failure_close")
    c.emit("4889c631d2")
    c.mark("loader_error_length")
    c.emit("803c1600")
    c.relative("0f84", "loader_error_write")
    c.emit("48ffc2")
    c.relative("e9", "loader_error_length")
    c.mark("loader_error_write")
    c.relative("e8", "stderr_all")
    c.relative("488d35", "newline")
    c.emit("ba01000000")
    c.relative("e8", "stderr_all")
    c.mark("loader_failure_close")
    c.emit("488b3c24b8030000000f05bf01000000")
    c.relative("e9", "native_exit")

    c.mark("stderr_all")
    c.emit("4885d2")
    c.relative("0f84", "stderr_done")
    c.mark("stderr_write")
    c.emit("b801000000bf020000000f054883f8fc")
    c.relative("0f84", "stderr_write")
    c.emit("4885c0")
    c.relative("0f8e", "io_error")
    c.emit("4801c64829c2")
    c.relative("0f85", "stderr_write")
    c.mark("stderr_done")
    c.emit("c3")

    c.mark("native_exit")
    # Errors may arrive from an internal helper. Realign without depending on
    # that helper's private frame, then retain libc/rtld finalization.
    c.emit("4883e4f0")
    c.call("exit")
    c.emit("0f0b")
    c.mark("target_name")
    c.data.extend(b"hia-linked-target\0")
    c.mark("entry_name")
    c.data.extend(b"f0\0")
    c.mark("newline")
    c.data.extend(b"\n")
    text = c.text()
    return text, tuple(c.external), start_size


def reference_object():
    """Canonical complete ET_REL bytes, including fixed foreign relocations."""
    text, relocations, start_size = adapter()
    symbol_names = ["", "_start", *IMPORTS]
    strings = bytearray(b"\0")
    string_at = {"": 0}
    for name in symbol_names[1:]:
        string_at[name] = len(strings)
        strings.extend(name.encode("ascii") + b"\0")
    symbols = [bytes(24), struct.pack("<IBBHQQ", 0, 3, 0, 1, 0, 0),
               struct.pack("<IBBHQQ", string_at["_start"], 18, 0, 1, 0, start_size)]
    symbol_at = {"_start": 2}
    for name in IMPORTS:
        symbol_at[name] = len(symbols)
        symbols.append(struct.pack("<IBBHQQ", string_at[name], 18, 0, 0, 0, 0))
    relas = b"".join(struct.pack("<QQq", offset, (symbol_at[name] << 32) | 4, -4)
                     for offset, name in relocations)
    shstrings = b"\0.text\0.rela.text\0.symtab\0.strtab\0.shstrtab\0.note.GNU-stack\0"
    shname = {name: shstrings.index(name.encode() + b"\0")
              for name in (".text", ".rela.text", ".symtab", ".strtab", ".shstrtab", ".note.GNU-stack")}
    data = bytearray(64)
    def append(value, alignment):
        data.extend(bytes((-len(data)) % alignment))
        offset = len(data)
        data.extend(value)
        return offset
    text_at = append(text, 16)
    rela_at = append(relas, 8)
    symbol_bytes = b"".join(symbols)
    symbols_at = append(symbol_bytes, 8)
    strings_at = append(strings, 1)
    shstrings_at = append(shstrings, 1)
    stack_at = len(data)
    sections_at = append(b"", 8)
    sections = [
        bytes(64),
        struct.pack("<IIQQQQIIQQ", shname[".text"], 1, 6, 0, text_at, len(text), 0, 0, 16, 0),
        struct.pack("<IIQQQQIIQQ", shname[".rela.text"], 4, 64, 0, rela_at, len(relas), 3, 1, 8, 24),
        struct.pack("<IIQQQQIIQQ", shname[".symtab"], 2, 0, 0, symbols_at, len(symbol_bytes), 4, 2, 8, 24),
        struct.pack("<IIQQQQIIQQ", shname[".strtab"], 3, 0, 0, strings_at, len(strings), 0, 0, 1, 0),
        struct.pack("<IIQQQQIIQQ", shname[".shstrtab"], 3, 0, 0, shstrings_at, len(shstrings), 0, 0, 1, 0),
        struct.pack("<IIQQQQIIQQ", shname[".note.GNU-stack"], 1, 0, 0, stack_at, 0, 0, 0, 1, 0),
    ]
    data.extend(b"".join(sections))
    data[:64] = struct.pack("<16sHHIQQQIHHHHHH", b"\x7fELF\x02\x01\x01" + bytes(9),
                           1, 62, 1, 0, 0, sections_at, 0, 64, 0, 0, 64, 7, 5)
    return bytes(data)


def source_program():
    raw = reference_object()
    lines = [
        "def entry(s:readbuf, o:mutbuf, w:mutbuf) -> u32:",
        "    if length(s) != 0:",
        "        return 4294967295",
        "    if length(o) < " + str(len(raw)) + ":",
        "        return 4294967294",
    ]
    chunks = list(range(0, len(raw), 48 * 8))
    for index, _ in enumerate(chunks):
        lines.append("    emit_" + str(index) + "(o)")
    lines += ["    return " + str(len(raw)), ""]
    for index, begin in enumerate(chunks):
        lines.append("def emit_" + str(index) + "(o:mutbuf) -> u64:")
        for offset in range(begin, min(begin + 48 * 8, len(raw)), 8):
            value = raw[offset:offset + 8]
            lines.append("    word(o, " + str(offset) + ", " + str(int.from_bytes(value, "little")) + ", " + str(len(value)) + ")")
        lines += ["    return 0", ""]
    lines += [
        "def word(o:mutbuf, at:u64, value:u64, count:u64) -> u64:",
        "    i = 0",
        "    while i < count:",
        "        store(o, at + i, value & 255)",
        "        value = value >> 8",
        "        i = i + 1",
        "    return 0",
    ]
    return "\n".join(lines) + "\n"


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: "f" + str(index) for index, node in enumerate(nodes)}
    signatures = {node.name: ([arg.annotation.id for arg in node.args.args], node.returns.id) for node in nodes}
    total = total_scalar_functions(nodes)
    functions = []
    for node in nodes:
        builder = Builder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({"name": names[node.name], "params": [builder.param(value) for value in builder.params],
                          "returns": [builder.returns], "effects": ["read", "write", "trap"],
                          "entry": "b0", "blocks": builder.blocks})
    return compact_authoring_cfg({"schema": "hepta.hia.program.v8", "module": "linked_native_observer_packer",
                                  "functions": functions})


def main():
    PACKER.write_text(render_assembly(document()))
    print(PACKER.name, PACKER.stat().st_size)


if __name__ == "__main__":
    main()
