"""Real linked-ELF observation, independent assembler/VM, and loader lifetime controls."""
from __future__ import annotations

from contextlib import contextmanager
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import shutil
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from tools import generate_hia_linked_native_observer as generator
from tools import hia_selfhost_linked_native_observer as native
from tools import qualify_hia_selfhost as original

ROOT=Path(__file__).resolve().parents[1]
REFERENCE=ROOT/"tools/hia_linked_native_observer_reference.S"
COLD_REPORT="HEPTA_HIA_LINKED_OBSERVER_COLD_REPORT"
DEVELOPMENT_COMPILER="HEPTA_HIA_LINKED_OBSERVER_DEVELOPMENT_COMPILER"
EVIDENCE="HEPTA_HIA_LINKED_OBSERVER_EVIDENCE"
OWNED=(
    "tools/generate_hia_linked_native_observer.py",
    "tools/hia_selfhost_linked_native_observer.py",
    "tools/hia_linked_native_observer_reference.S",
    "examples/hia_bootstrap/linked_native_observer_packer.hiaasm",
    "tests/test_hia_selfhost_linked_native_observer.py",
    "tools/generate_hia_native_observer.py",
    "tools/hia_native_observer_template.S",
    "tools/hia_selfhost_native_observer.py",
    "tools/hia_selfhost_child.py",
    "tools/qualify_hia_selfhost.py",
)
FIELDS=("status","result_u64","abi_status","core_u32","return_encoding",
        "source_unchanged","output_unchanged","workspace_header",
        "source_sha256","image_sha256","output_sha256","limits",
        "forbidden_compiler_modules_loaded")


def digest(data):
    return sha256(data).hexdigest()


def elf_contents(data):
    header=struct.unpack_from("<16sHHIQQQIHHHHHH",data)
    if header[0][:7]!=b"\x7fELF\x02\x01\x01" or header[2]!=62:
        raise AssertionError("expected the actual ELF64 x86-64 artifact")
    rows=[struct.unpack_from("<IIQQQQIIQQ",data,header[6]+index*header[11])
          for index in range(header[12])]
    name_row=rows[header[13]]
    names=data[name_row[4]:name_row[4]+name_row[5]]
    def string(raw,at):
        end=raw.index(0,at)
        return raw[at:end].decode("ascii")
    named={string(names,row[0]):row for row in rows}
    text=named[".text"]
    sym=named[".symtab"]; strings=rows[sym[6]]
    strings=data[strings[4]:strings[4]+strings[5]]
    symbols=[struct.unpack_from("<IBBHQQ",data,sym[4]+at)
             for at in range(0,sym[5],sym[9])]
    symbols=[{"name":string(strings,row[0]),"binding":row[1]>>4,"kind":row[1]&15,
              "section":row[3],"value":row[4],"size":row[5]} for row in symbols]
    relas=[]
    for row in rows:
        if row[1]==4 and rows[row[7]]==text:
            for at in range(0,row[5],row[9]):
                offset,info,addend=struct.unpack_from("<QQq",data,row[4]+at)
                relas.append((offset,info&0xffffffff,symbols[info>>32]["name"],addend))
    return {"text":data[text[4]:text[4]+text[5]],"relocations":relas,
            "symbols":symbols,"sections":named}


def assemble(directory,label,source,*,shared=False):
    assembly=directory/(label+".S");assembly.write_text(source)
    obj=directory/(label+".o")
    original.observe_native_tool(directory,label+"-as","as",["--64",assembly,"-o",obj])
    if not shared:return obj
    linked=directory/(label+".so")
    original.observe_native_tool(directory,label+"-ld","ld",[
        "-m","elf_x86_64","-shared","-z","defs","-z","noexecstack",
        "-z","relro","-z","now","--build-id=none",obj,"-lc","-o",linked])
    return linked


@contextmanager
def independent_loader():
    # Keep the retained Python loader as the independent oracle after the new
    # linked-observer dispatch is integrated into the qualifier.
    with patch.object(original,"NATIVE_OBSERVER",None), \
         patch.object(original,"LINKED_NATIVE_OBSERVER",None,create=True):
        yield


def legacy_invoke(*args,**kwargs):
    with independent_loader():
        return original.invoke(*args,image_format="linked-selfhost",**kwargs)


def foreign_bytes(directory,label,code):
    return assemble(directory,label,
        ".intel_syntax noprefix\n.text\n.global f0\n.type f0,@function\nf0:\n"
        +" .byte "+",".join(str(byte) for byte in code)+"\n.size f0,.-f0\n"
        +'.section .note.GNU-stack,"",@progbits\n',shared=True)


def lifetime_source(*,trap=False,noise=0,stderr=False):
    """A foreign ABI fixture, not HIA code or a production serializer.

    mremap(old_size=0) duplicates only a genuine shared mapping. The DSO owns
    that duplicate until fini, so no borrowed Python buffer is used after main
    has released it. The ordinary ctypes path may validly return EINVAL.
    """
    page=os.sysconf("SC_PAGE_SIZE")
    return r'''
.intel_syntax noprefix
.set PAGE, @PAGE@
.set TRAP, @TRAP@
.set NOISE, @NOISE@
.set STDERR, @STDERR@
.section .data
.align 8
mapping_record:
 .quad -1, PAGE, 0
.section .rodata
events_name: .asciz "events.bin"
mapping_name: .asciz "mapping.bin"
stdout_byte: .ascii "!"
stderr_byte: .ascii "?"
.text
.global f0
.type f0,@function
f0:
 push rbx
 mov rbx,rdx
 test rcx,rcx
 jz fixture_failure
 mov byte ptr [rbx],65
 mov edi,70
 call append_event
 .if NOISE==2
 call stdout_noise
 .endif
 mov rdi,rbx
 xor esi,esi
 mov edx,PAGE
 mov r10d,1
 mov eax,25
 syscall
 mov [rip+mapping_record],rax
 mov eax,39
 syscall
 mov [rip+mapping_record+16],rax
 call save_mapping
 .if TRAP
 ud2
 .endif
 mov eax,37
 pop rbx
 ret
.size f0,.-f0
construct:
 sub rsp,8
 mov edi,67
 call append_event
 .if NOISE==1
 call stdout_noise
 .endif
 .if STDERR
 call stderr_noise
 .endif
 add rsp,8
 ret
destruct:
 push rbx
 mov rbx,[rip+mapping_record]
 cmp rbx,-4095
 jae no_mapping
 mov byte ptr [rbx],66
 mov rdi,rbx
 mov esi,PAGE
 mov eax,11
 syscall
 test rax,rax
 jne fixture_failure
no_mapping:
 mov edi,68
 call append_event
 .if NOISE==3
 call stdout_noise
 .endif
 .if STDERR
 call stderr_noise
 .endif
 pop rbx
 ret
append_event:
 sub rsp,16
 mov [rsp],dil
 mov edi,-100
 lea rsi,[rip+events_name]
 mov edx,1089
 mov r10d,384
 mov eax,257
 syscall
 test rax,rax
 js fixture_failure
 mov r8,rax
 mov edi,eax
 lea rsi,[rsp]
 mov edx,1
 mov eax,1
 syscall
 cmp rax,1
 jne fixture_failure
 mov rdi,r8
 mov eax,3
 syscall
 test rax,rax
 jne fixture_failure
 add rsp,16
 ret
save_mapping:
 mov edi,-100
 lea rsi,[rip+mapping_name]
 mov edx,577
 mov r10d,384
 mov eax,257
 syscall
 test rax,rax
 js fixture_failure
 mov r8,rax
 mov edi,eax
 lea rsi,[rip+mapping_record]
 mov edx,24
 mov eax,1
 syscall
 cmp rax,24
 jne fixture_failure
 mov rdi,r8
 mov eax,3
 syscall
 test rax,rax
 jne fixture_failure
 ret
stdout_noise:
 mov edi,1
 lea rsi,[rip+stdout_byte]
 jmp noise
stderr_noise:
 mov edi,2
 lea rsi,[rip+stderr_byte]
noise:
 mov edx,1
 mov eax,1
 syscall
 cmp rax,1
 jne fixture_failure
 ret
fixture_failure:
 ud2
.section .init_array,"aw"
 .quad construct
.section .fini_array,"aw"
 .quad destruct
.section .note.GNU-stack,"",@progbits
'''.replace("@PAGE@",str(page)).replace("@TRAP@",str(int(trap))).replace("@NOISE@",str(noise)).replace("@STDERR@",str(int(stderr)))


class LinkedObserverSourceTests(unittest.TestCase):
    def test_HIA_source_is_generated_exactly_within_original_profile(self):
        from hepta.hia_agent_assembly import assemble_program,render_assembly
        self.assertEqual(generator.PACKER.read_text(),render_assembly(generator.document()))
        checked=assemble_program(generator.PACKER.read_bytes()).as_dict()
        self.assertLessEqual(len(checked["functions"]),128)
        self.assertLessEqual(sum(len(f["blocks"]) for f in checked["functions"]),1536)
        self.assertLessEqual(sum(len(b["ops"]) for f in checked["functions"] for b in f["blocks"]),8192)
        self.assertLessEqual(max(len(f["blocks"]) for f in checked["functions"]),256)
        self.assertLessEqual(max(len(b["params"]) for f in checked["functions"] for b in f["blocks"]),16)

    @unittest.skipUnless(shutil.which("as"),"independent GNU assembler required")
    def test_independent_assembler_matches_all_text_and_foreign_relocations(self):
        with tempfile.TemporaryDirectory(prefix="hia-linked-observer-reference-") as temporary:
            obj=assemble(Path(temporary),"independent-adapter",REFERENCE.read_text())
            actual=elf_contents(obj.read_bytes())
        expected=elf_contents(generator.reference_object())
        self.assertEqual(actual["text"],expected["text"])
        self.assertEqual(actual["relocations"],expected["relocations"])
        self.assertEqual([row for row in actual["symbols"] if row["name"]=="_start"],
                         [row for row in expected["symbols"] if row["name"]=="_start"])
        self.assertEqual(actual["sections"][".note.GNU-stack"][2]&4,0)
        self.assertEqual({name for _,_,name,_ in actual["relocations"]},set(generator.IMPORTS))

    def test_boundary_whitespace_parser_preserves_every_binary_payload_byte(self):
        frame=b"HIAOBR03"+struct.pack("<2Q",37,0)+b"A \t\r\n"
        for prefix in (b"",b" ",b"\t",b"\r",b"\n",b" \t\r\n"):
            for suffix in (b"",b" ",b"\t",b"\r",b"\n",b" \t\r\n"):
                self.assertEqual(native._response_frame(prefix+frame+suffix,len(frame)),frame)
        for raw in (b"!"+frame,b"x "+frame,b"\0"+frame,b"\xc2\xa0"+frame,
                    b"\xef\xbb\xbf"+frame,frame+b"!",frame+b"\0",frame+frame,frame[:-1]):
            self.assertIsNone(native._response_frame(raw,len(frame)))

    def test_dual_selection_refuses_before_read_or_directory_creation(self):
        with patch.dict(os.environ,{COLD_REPORT:"unread-cold",DEVELOPMENT_COMPILER:"unread-development"}), \
             patch.object(Path,"read_bytes",side_effect=AssertionError("must not read")) as read, \
             patch.object(Path,"mkdir",side_effect=AssertionError("must not create")) as mkdir:
            with self.assertRaisesRegex(ValueError,"mutually exclusive"):
                LinkedObserverNativeTests.setUpClass()
        read.assert_not_called();mkdir.assert_not_called()


@unittest.skipUnless(platform.system()=="Linux" and platform.machine().lower() in ("x86_64","amd64")
    and shutil.which("ld") and shutil.which("as"),"Linux x86-64 and ordinary linker/assembler required")
class LinkedObserverNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cold=os.environ.get(COLD_REPORT); development=os.environ.get(DEVELOPMENT_COMPILER)
        if cold and development:raise ValueError("cold and development inputs are mutually exclusive")
        cls.cold_bytes=cls.cold_sources=None
        if cold:
            from tools.build_hia_json_preflight import admit_cold_build
            cls.cold_bytes=Path(cold).read_bytes()
            outer=json.loads(cls.cold_bytes);nested=json.loads(Path(outer["nested_report"]).read_bytes())
            compiler=Path(nested["generations"][-1]["produced_image"])
            cls.compiler_bytes=compiler.read_bytes()
            cls.cold_sources=admit_cold_build(cls.compiler_bytes,cls.cold_bytes)
            if any(name not in cls.cold_sources for name in OWNED):
                raise ValueError("cold qualification does not bind every linked observer input")
            cls.scope="CURRENT_SOURCE_COLD_BUILT_COMPONENT"
        elif development:
            compiler=Path(development);cls.compiler_bytes=compiler.read_bytes()
            cls.scope="RETAINED_COMPILER_DEVELOPMENT_COMPONENT"
        else:
            compiler=None;cls.scope="ISOLATED_CURRENT_SOURCE_BOOTSTRAP_COMPONENT"
        cls.temp=None
        if os.environ.get(EVIDENCE):
            parent=Path(os.environ[EVIDENCE])
            parent.mkdir(mode=0o700,parents=True,exist_ok=True)
            cls.root=parent/"candidate";cls.root.mkdir(mode=0o700)
        else:
            cls.temp=tempfile.TemporaryDirectory(prefix="hia-linked-observer-")
            cls.root=Path(cls.temp.name)
        names=set(OWNED)
        for folder in ("hepta","tools"):
            names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/folder).rglob("*.py"))
        cls.inputs={name:(ROOT/name).read_bytes() for name in sorted(names)}
        (cls.root/"source-before.json").write_text(json.dumps({k:digest(v) for k,v in cls.inputs.items()},indent=2,sort_keys=True)+"\n")
        # This invocation always precedes NEW native compilation. Only the
        # default seed mode is literally before B0 in this test fixture.
        cls.reference=native.independent_reference(before_B0=not(cold or development))
        (cls.root/"ordinary-vm-reference.json").write_text(json.dumps(cls.reference,indent=2,sort_keys=True)+"\n")
        if compiler is None:
            seed,_=original.build_seed(cls.root)
            compiler,_=original.compile_stage(cls.root,"B1",seed,original.SOURCE.read_bytes(),image_format="seed-shared")
            cls.compiler_bytes=compiler.read_bytes()
        cls.compiler=compiler
        cls.build_dir=cls.root/"build";cls.build_dir.mkdir(mode=0o700)
        cls.executable,cls.build=native.build(cls.build_dir,compiler,cls.reference)
        cls.executable_bytes=cls.executable.read_bytes()
        cls.new_entries=cls.old_entries=cls.differentials=0
        cls.pids=[]

    @classmethod
    def tearDownClass(cls):
        unchanged=all((ROOT/name).read_bytes()==raw for name,raw in cls.inputs.items())
        held=cls.compiler.read_bytes()==cls.compiler_bytes and cls.executable.read_bytes()==cls.executable_bytes
        if cls.cold_bytes is not None:
            from tools.build_hia_json_preflight import current_sources
            held=held and Path(os.environ[COLD_REPORT]).read_bytes()==cls.cold_bytes and current_sources()==cls.cold_sources
        row={"schema":"hepta.hia.linked-observer-component-observations.v1","scope":cls.scope,
             "source_unchanged":unchanged,"held_inputs_unchanged":held,
             "new_native_entries":cls.new_entries,"retained_loader_entries":cls.old_entries,
             "differentials":cls.differentials,"ordinary_vm_windows":len(cls.reference["vm_windows"]),
             "whole_stack_rewritten_in_hia":False,"production_activated":False,"observed_fixture_pids":cls.pids}
        (cls.root/"observations.json").write_text(json.dumps(row,indent=2,sort_keys=True)+"\n")
        if cls.temp is not None:cls.temp.cleanup()
        if not unchanged or not held:raise AssertionError("linked observer frozen source/input changed")

    def folder(self,label):
        path=self.root/label;path.mkdir(mode=0o700);return path

    def pair(self,folder,image,source=b"",*,capacity=32,workspace_size=128,workspace_fill=90,
             output_initial=None,observe_trap_writes=False):
        old_dir=folder/"old";new_dir=folder/"new"
        old_dir.mkdir(mode=0o700);new_dir.mkdir(mode=0o700)
        kwargs={"capacity":capacity,"workspace_size":workspace_size,"workspace_fill":workspace_fill,
                "output_initial":output_initial,"observe_trap_writes":observe_trap_writes}
        type(self).old_entries+=1
        old,old_out=legacy_invoke(old_dir,"call",image,source,**kwargs)
        type(self).new_entries+=1
        new,new_out=native.invoke(new_dir,"call",self.executable,image,source,**kwargs)
        type(self).differentials+=1
        self.assertEqual(old["status"],new["status"])
        self.assertEqual(old_out,new_out)
        if old["status"]=="returned":
            for key in FIELDS:self.assertEqual(old[key],new[key],(folder.name,key))
        else:self.assertEqual(old.get("returncode"),new.get("returncode"))
        if observe_trap_writes:
            for key in ("available","initial_sha256","observed_sha256","observed_bytes","unchanged"):
                self.assertEqual(old["shared_output_observation"][key],new["shared_output_observation"][key])
        (folder/"comparison.json").write_text(json.dumps({"original":old,"native":new,
            "output_equal":old_out==new_out,"compared_fields":FIELDS},indent=2,sort_keys=True)+"\n")
        self.assertTrue(new["fresh_native_exec"]);self.assertFalse(new["successor_process_reuse"])
        return old,new,new_out

    def test_actual_HIA_object_emission_matches_every_independent_VM_byte(self):
        self.assertTrue(self.reference["before_native_compilation"])
        self.assertTrue(self.reference["every_output_byte_compared"])
        self.assertEqual((self.build_dir/"linked-native-observer.o").read_bytes(),generator.reference_object())
        self.assertEqual(self.build["runtime_loader"],native._runtime_interpreter()[1])
        self.assertFalse(self.build["production_activated"])

    def test_full_word_return_source_output_workspace_and_resource_receipts(self):
        folder=self.folder("full-word")
        image=foreign_bytes(folder,"return64",bytes.fromhex("48 b8 2a 00 00 00 ef be ad de c3"))
        for index,source in enumerate((b"",b"A\0\xff"*137)):
            for capacity in (0,1,257):
                for fill in (0,90,255):
                    pair=folder/(str(index)+"-"+str(capacity)+"-"+str(fill));pair.mkdir()
                    _,new,_=self.pair(pair,image,source,capacity=capacity,workspace_size=1032,workspace_fill=fill)
                    self.assertEqual(new["result_u64"],0xdeadbeef0000002a)

    def test_actual_readonly_source_violation_is_observed(self):
        folder=self.folder("source-violation")
        image=foreign_bytes(folder,"mutator",bytes.fromhex("c6 07 61 31 c0 c3"))
        _,new,out=self.pair(folder,image,b"XYZ")
        self.assertFalse(new["source_unchanged"]);self.assertEqual(out,b"\xa5"*32)

    def test_real_kernel_limits_and_dumpability(self):
        folder=self.folder("kernel-limits")
        # Save all six actual limits to the caller output, then PR_GET_DUMPABLE.
        assembly=[".intel_syntax noprefix",".text",".global f0",".type f0,@function","f0:",
                  " push rbx"," mov rbx,rdx"]
        for index,resource in enumerate((0,9,3,1,7,4)):
            assembly += [" xor edi,edi"," mov esi,"+str(resource)," xor edx,edx",
                         " lea r10,[rbx+"+str(index*16)+"]"," mov eax,302"," syscall",
                         " test rax,rax"," jne failed"]
        assembly += [" mov edi,3"," xor esi,esi"," xor edx,edx"," xor r10d,r10d",
                     " xor r8d,r8d"," mov eax,157"," syscall"," pop rbx"," ret",
                     "failed:"," ud2",'.section .note.GNU-stack,"",@progbits']
        image=assemble(folder,"limits","\n".join(assembly)+"\n",shared=True)
        _,new,out=self.pair(folder,image,capacity=96,workspace_size=0)
        self.assertEqual(new["result_u64"],0)
        self.assertEqual(struct.unpack("<12Q",out),(10,10,256<<20,256<<20,8<<20,8<<20,16<<20,16<<20,32,32,0,0))

    def test_complete_HIA_ELF_has_same_text_as_flat_and_same_observations(self):
        folder=self.folder("hia-bytesum")
        sample=original.SAMPLE.read_bytes()
        flat,_=original.compile_stage(folder,"flat",self.compiler,sample)
        obj,_=original.compile_stage(folder,"object",self.compiler,sample.replace(b"hepta.hia.program.v8 selfhost\n",b"hepta.hia.program.v8 selfhost_elf\n",1),output_extension=".o")
        inventory=original.inspect_selfhost_object(obj.read_bytes())
        self.assertEqual(inventory["text_sha256"],digest(flat.read_bytes()))
        linked=folder/"target.so"
        original.observe_native_tool(folder,"link","ld",["-m","elf_x86_64","-shared","-z","defs","-z","noexecstack","-z","relro","-z","now","--build-id=none",obj,"-o",linked])
        for index,source in enumerate((b"",b"abc",bytes(range(256))*4)):
            pair=folder/str(index);pair.mkdir()
            self.pair(pair,linked,source,capacity=64,workspace_size=2048,workspace_fill=165)

    def test_full_linked_HIA_compiler_success_and_refusal_bytes_are_identical(self):
        folder=self.folder("linked-compiler")
        source=original.SOURCE.read_bytes().replace(b"hepta.hia.program.v8 selfhost\n",b"hepta.hia.program.v8 selfhost_elf\n",1)
        obj,_=original.compile_stage(folder,"compiler",self.compiler,source,output_extension=".o")
        original.inspect_selfhost_object(obj.read_bytes())
        linked=folder/"compiler.so"
        original.observe_native_tool(folder,"link","ld",["-m","elf_x86_64","-shared","-z","defs","-z","noexecstack","-z","relro","-z","now","--build-id=none",obj,"-o",linked])
        for index,source in enumerate((original.SAMPLE.read_bytes(),b"invalid")):
            pair=folder/str(index);pair.mkdir()
            self.pair(pair,linked,source,capacity=1<<20,workspace_size=1<<20,workspace_fill=90)

    def test_owned_libc_imports_and_actual_trap_capture(self):
        from tools.hia_selfhost_owned_elf_cases import cases,reference
        from tools.hia_selfhost_owned_flow_cases import cases as flow_cases
        from tools.qualify_hia_selfhost_owned_elf import inspect_owned_object
        folder=self.folder("owned-libc")
        available=[*cases(),*flow_cases()]
        by_name={case["id"]:case for case in available}
        chosen=[by_name[name] for name in ("new-8","move-nested-loan-and-drop",
                 "flow-forward-owner-through-two-calls","new-allocation-trap-1")]
        for index,case in enumerate(chosen):
            pair=folder/str(index);pair.mkdir()
            expected=reference(case)
            (pair/"ordinary-reference.json").write_text(json.dumps(expected,indent=2,sort_keys=True)+"\n")
            obj,_=original.compile_stage(pair,"owned",self.compiler,case["source"].encode(),output_extension=".o")
            inventory=inspect_owned_object(obj.read_bytes())
            self.assertEqual(inventory["undefined_symbols"],["calloc","free"])
            linked=pair/"owned.so"
            original.observe_native_tool(pair,"link","ld",["-m","elf_x86_64","-shared","-z","defs","-z","noexecstack","-z","relro","-z","now","--build-id=none",obj,"-lc","-o",linked])
            _,new,out=self.pair(pair,linked,capacity=8,workspace_size=0,workspace_fill=0,
                               output_initial=b"\xa5"*8,observe_trap_writes=True)
            if "expected_trap" in case:self.assertEqual(new["returncode"],-4)
            else:self.assertEqual(new["core_u32"],case["expected_result"])
            self.assertEqual(out.hex(),case["expected_output_hex"])

    def test_real_normal_finalization_preserves_preimage_and_shared_postimage_modes(self):
        folder=self.folder("lifetime")
        image=assemble(folder,"lifetime",lifetime_source(),shared=True)
        page=os.sysconf("SC_PAGE_SIZE")
        for index,(initial,shared) in enumerate(((None,False),(b"Z"*page,False),(None,True),(b"Z"*page,True))):
            pair=folder/str(index);pair.mkdir()
            old,new,out=self.pair(pair,image,capacity=page,workspace_size=0,workspace_fill=0,
                                  output_initial=initial,observe_trap_writes=shared)
            before=b"A"+(initial or b"\xa5"*page)[1:]
            after=(b"B"+before[1:]) if shared else before
            self.assertEqual(out,after)
            self.assertEqual(old["output_sha256"],digest(before))
            self.assertEqual(new["output_sha256"],digest(before))
            for kind in ("old","new"):
                self.assertEqual((pair/kind/"events.bin").read_bytes(),b"CFD")
                address,extent,pid=struct.unpack("<3Q",(pair/kind/"mapping.bin").read_bytes())
                type(self).pids.append({"mode":index,"kind":kind,"pid":pid,"address":address,"extent":extent})
                self.assertEqual(extent,page)
                if shared:
                    self.assertLess(address,(1<<64)-4095);self.assertEqual(address%page,0)
        self.assertEqual(len({row["pid"] for row in self.pids}),len(self.pids))

    def test_real_SIGILL_has_no_finalizer_and_retains_actual_shared_writes(self):
        folder=self.folder("trap-lifetime")
        image=assemble(folder,"trap",lifetime_source(trap=True),shared=True)
        page=os.sysconf("SC_PAGE_SIZE")
        _,new,out=self.pair(folder,image,capacity=page,workspace_size=0,workspace_fill=0,
                           observe_trap_writes=True)
        self.assertEqual(new["returncode"],-4)
        self.assertEqual(out,b"A"+b"\xa5"*(page-1))
        for kind in ("old","new"):
            self.assertEqual((folder/kind/"events.bin").read_bytes(),b"CF")
            address,extent,_=struct.unpack("<3Q",(folder/kind/"mapping.bin").read_bytes())
            self.assertLess(address,(1<<64)-4095);self.assertEqual(extent,page)

    def test_constructor_call_and_finalizer_stdout_noise_is_never_searched_past(self):
        folder=self.folder("stdout-noise")
        page=os.sysconf("SC_PAGE_SIZE")
        for where in (1,2,3):
            image=assemble(folder,"noise-"+str(where),lifetime_source(noise=where),shared=True)
            pair=folder/str(where);pair.mkdir()
            old_dir=pair/"old";new_dir=pair/"new";old_dir.mkdir();new_dir.mkdir()
            type(self).old_entries+=1
            with self.assertRaises(json.JSONDecodeError):
                legacy_invoke(old_dir,"call",image,b"",capacity=page,workspace_size=0,workspace_fill=0)
            type(self).new_entries+=1
            new,out=native.invoke(new_dir,"call",self.executable,image,b"",capacity=page,workspace_size=0,workspace_fill=0)
            self.assertEqual(new["status"],"protocol_failed");self.assertEqual(out,b"")
            raw=(new_dir/"call.failure-stdout.raw").read_bytes()
            self.assertEqual(len(raw),24+page+1)
            self.assertEqual(raw.startswith(b"!HIAOBR03"),where in (1,2))
            if where==3:self.assertEqual(raw[-1:],b"!")
            for kind in ("old","new"):self.assertEqual((pair/kind/"events.bin").read_bytes(),b"CFD")

    def test_stderr_from_constructors_and_finalizers_is_preserved_on_success(self):
        folder=self.folder("stderr-lifecycle")
        image=assemble(folder,"stderr",lifetime_source(stderr=True),shared=True)
        self.pair(folder,image,capacity=os.sysconf("SC_PAGE_SIZE"),workspace_size=0)
        for kind in ("old","new"):self.assertEqual((folder/kind/"call.stderr.log").read_bytes(),b"??")

    def test_real_dlopen_and_missing_symbol_refusals(self):
        folder=self.folder("loader-refusals")
        bad=folder/"invalid.so";bad.write_bytes(b"not an ELF object\n")
        missing=assemble(folder,"missing",'.text\n.global unrelated\nunrelated:\n ret\n.section .note.GNU-stack,"",@progbits\n',shared=True)
        for label,image in (("bad",bad),("missing",missing)):
            pair=folder/label;pair.mkdir()
            _,new,out=self.pair(pair,image,capacity=8,workspace_size=0,workspace_fill=0)
            self.assertEqual((new["status"],new["returncode"],out),("child_failed",1,b""))
            self.assertTrue((pair/"new/call.stderr.log").read_bytes())

    def test_private_malformed_frames_and_extra_arguments_refuse_before_target_load(self):
        folder=self.folder("malformed-frames")
        image=foreign_bytes(folder,"unused",b"\xc3").read_bytes()
        with native.output_snapshot(0) as snapshot:
            good=native._linked_frame(image,b"",0,0,0,None,snapshot)
            bad=[b"",good[:47],b"badMAGIC"+good[8:],good+b"\0",good[:-1]]
            for index in range(5):
                altered=bytearray(good);struct.pack_into("<Q",altered,8+index*8,(1<<64)-1);bad.append(bytes(altered))
            for at,values in ((48,(0,1,2,2147483648,0xfffffffe,snapshot)),
                              (52,(0,1,2,2147483648,0xffffffff))):
                for value in values:
                    altered=bytearray(good);struct.pack_into("<I",altered,at,value);bad.append(bytes(altered))
            for index,data in enumerate(bad):
                process=native.execute(self.executable_bytes,data,cwd=folder,snapshot_fd=snapshot)
                self.assertEqual((process.returncode,process.stdout,process.stderr),(2,b"",b""),index)
            process=native.execute(self.executable_bytes,good,cwd=folder,arguments=("unexpected",),snapshot_fd=snapshot)
            self.assertEqual((process.returncode,process.stdout),(64,b""))

    def test_F_GET_SEALS_error_is_rejected_before_real_loader(self):
        folder=self.folder("seals-error")
        image=assemble(folder,"not-entered",lifetime_source(),shared=True)
        executable=shutil.which("strace")
        if executable is None:raise RuntimeError("strace is required for the actual seal errno control")
        trace=folder/"syscalls.log"
        with native.output_snapshot(os.sysconf("SC_PAGE_SIZE")) as snapshot:
            payload=native._linked_frame(image.read_bytes(),b"",os.sysconf("SC_PAGE_SIZE"),0,0,None,snapshot)
            process=subprocess.run([executable,"-f","-o",str(trace),"-e","trace=fcntl",
                "-e","inject=fcntl:error=EPERM:when=2",str(self.executable)],
                input=payload,cwd=folder,capture_output=True,timeout=20,pass_fds=(snapshot,))
        (folder/"stdout.raw").write_bytes(process.stdout);(folder/"stderr.raw").write_bytes(process.stderr)
        self.assertEqual((process.returncode,process.stdout),(4,b""))
        self.assertIn("F_GET_SEALS",trace.read_text());self.assertIn("EPERM",trace.read_text())
        self.assertFalse((folder/"events.bin").exists())

    def test_prelaunch_storage_failure_releases_parent_shared_descriptor(self):
        import errno
        folder=self.folder("prelaunch-storage")
        image=foreign_bytes(folder,"unused",b"\xc3")
        before=len(list(Path("/proc/self/fd").iterdir()))
        with patch.object(Path,"write_text",side_effect=OSError(errno.ENOSPC,"controlled evidence failure")):
            with self.assertRaises(OSError):
                native.invoke(folder,"call",self.executable,image,b"",capacity=1,workspace_size=0,
                              workspace_fill=0,output_initial=b"X",observe_trap_writes=True)
        self.assertEqual(len(list(Path("/proc/self/fd").iterdir())),before)

    def test_actual_ASCII_stdout_whitespace_matches_original_without_trimming_payload(self):
        folder=self.folder("stdout-whitespace")
        page=os.sysconf("SC_PAGE_SIZE")
        for byte in (32,9,13,10):
            for where in (1,2,3):
                pair=folder/(str(byte)+"-"+str(where));pair.mkdir()
                source=lifetime_source(noise=where).replace('stdout_byte: .ascii "!"',
                                                            "stdout_byte: .byte "+str(byte))
                image=assemble(pair,"whitespace",source,shared=True)
                _,new,out=self.pair(pair,image,b"\0 \t\r\n",capacity=page,
                                   workspace_size=128,workspace_fill=32,output_initial=b" "*page)
                self.assertEqual(new["status"],"returned")
                self.assertEqual(out,b"A"+b" "*(page-1))
                self.assertTrue(new["prefinalizer_output_snapshot"]["available"])
                for kind in ("old","new"):
                    self.assertEqual((pair/kind/"events.bin").read_bytes(),b"CFD")

    def test_finalizer_nonzero_noise_or_signal_retains_preimage_and_shared_postimage(self):
        folder=self.folder("finalizer-failure")
        page=os.sysconf("SC_PAGE_SIZE")
        anchor=" pop rbx\n ret\nappend_event:"
        for kind,noise,code in (("exit",0,23),("exit-noise",3,23),("signal",0,-4)):
            source=lifetime_source(noise=noise)
            self.assertEqual(source.count(anchor),1)
            tail=" pop rbx\n"+(" ud2\n" if kind=="signal" else
                  " mov edi,23\n mov eax,231\n syscall\n ud2\n")+"append_event:"
            source=source.replace(anchor,tail)
            image=assemble(folder,kind,source,shared=True)
            for shared in (False,True):
                pair=folder/(kind+"-"+str(int(shared)));pair.mkdir()
                _,new,out=self.pair(pair,image,capacity=page,workspace_size=0,workspace_fill=0,
                                   output_initial=b" "*page,observe_trap_writes=shared)
                self.assertEqual((new["status"],new["returncode"]),("child_failed",code))
                self.assertEqual(out,(b"B" if shared else b"A")+b" "*(page-1))
                self.assertEqual(new["prefinalizer_output_snapshot"]["sha256"],
                                 digest(b"A"+b" "*(page-1)))
                for which in ("old","new"):
                    self.assertEqual((pair/which/"events.bin").read_bytes(),b"CFD")

    def test_constructor_fake_response_cannot_invent_a_completed_f0_snapshot(self):
        folder=self.folder("constructor-fake")
        raw=b"HIAOBR03"+struct.pack("<2Q",37,0)+b"Q"*8
        source=(".intel_syntax noprefix\n.text\n.global f0\nf0:\n mov eax,37\n ret\n"
                "construct:\n mov edi,1\n lea rsi,[rip+fake]\n mov edx,"+str(len(raw))+
                "\n mov eax,1\n syscall\n mov edi,23\n mov eax,231\n syscall\n ud2\n"
                "fake:\n .byte "+",".join(map(str,raw))+
                '\n.section .init_array,"aw"\n .quad construct\n'
                '.section .note.GNU-stack,"",@progbits\n')
        image=assemble(folder,"fake",source,shared=True)
        _,new,out=self.pair(folder,image,capacity=8,workspace_size=0,workspace_fill=0)
        self.assertEqual((new["status"],new["returncode"],out),("child_failed",23,b""))
        self.assertFalse(new["prefinalizer_output_snapshot"]["available"])

    def test_zero_capacity_return_is_committed_before_finalizer_failure(self):
        folder=self.folder("empty-finalizer-failure")
        source=('.intel_syntax noprefix\n.text\n.global f0\nf0:\n mov eax,37\n ret\n'
                'destruct:\n mov edi,23\n mov eax,231\n syscall\n ud2\n'
                '.section .fini_array,"aw"\n .quad destruct\n'
                '.section .note.GNU-stack,"",@progbits\n')
        image=assemble(folder,"empty",source,shared=True)
        _,new,out=self.pair(folder,image,capacity=0,workspace_size=0,workspace_fill=0)
        self.assertEqual((new["status"],new["returncode"],out),("child_failed",23,b""))
        self.assertTrue(new["prefinalizer_output_snapshot"]["available"])
        self.assertEqual(new["prefinalizer_output_snapshot"]["sha256"],digest(b""))
        self.assertTrue((folder/"new/call.output.bin").exists())

    def test_snapshot_allocation_failure_releases_existing_parent_capture(self):
        import errno
        folder=self.folder("snapshot-allocation-failure")
        image=foreign_bytes(folder,"unused",b"\xc3")
        before=len(list(Path("/proc/self/fd").iterdir()))
        allocator=os.memfd_create;calls=[]
        failure=OSError(errno.ENOSPC,"controlled snapshot allocation failure")
        def allocate(name,flags):
            calls.append(name)
            if len(calls)==2:raise failure
            return allocator(name,flags)
        with patch.object(os,"memfd_create",side_effect=allocate), \
             patch.object(native,"execute",side_effect=AssertionError("no child before full custody")) as enter:
            with self.assertRaises(OSError) as observed:
                native.invoke(folder,"call",self.executable,image,b"",capacity=1,workspace_size=0,
                              workspace_fill=0,output_initial=b"X",observe_trap_writes=True)
        self.assertIs(observed.exception,failure)
        self.assertEqual(calls,["hia-native-output","hia-linked-return-snapshot"])
        enter.assert_not_called()
        self.assertEqual(len(list(Path("/proc/self/fd").iterdir())),before)


if __name__=="__main__":
    unittest.main()
