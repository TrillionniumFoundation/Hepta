from pathlib import Path
from hashlib import sha256
import contextlib,importlib.util,json,os,platform,shutil,subprocess,sys,time,traceback,unittest
BASE=Path('/tmp/hia-linked-observer-local-v71-20261112-r1')
ROOT=BASE/'source-r4'; OUT=BASE/'evidence/r4-component-r1'
OUT.mkdir(mode=0o700,exist_ok=False);os.umask(0o077)
COMPILER=BASE/'retained-8aade-CI-development-compiler.bin'
EXPECTED={
 'tools/generate_hia_linked_native_observer.py':'954bf186009b6775e0358c12df6f57df5cfd758eb241a3d6962d38321d6f180b',
 'tools/hia_selfhost_linked_native_observer.py':'bb430496609dbb588b1aa01a93f7d8e98c6c89e5dc677c9fbba42f21d3fb4987',
 'tools/hia_linked_native_observer_reference.S':'7780e438b647c7b8314aea2cb12cebbac05282e5d3bc6964f4d971953afc6fe2',
 'examples/hia_bootstrap/linked_native_observer_packer.hiaasm':'816164fdb6364a41b479b1b1ee4578592d1d0ccfa3f0fa77c7e27f809d954fdd',
 'tests/test_hia_selfhost_linked_native_observer.py':'a149f93f9bbecc59f79bf824c8af6321e87d93b36752d4691c1aa2014491d861',
 'docs/HIA_LINKED_NATIVE_OBSERVER.md':'4b72806d96c651c8b44fcd01b7d0fe2be48f644ba8342fb90eff16c7db2a6196'}
def digest(data):return sha256(data).hexdigest()
def record(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':digest(b),'mode':path.stat().st_mode&0o777}
def write(name,value):
 b=value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
 with (OUT/name).open('xb') as f:f.write(b)
def state():
 return {p.relative_to(ROOT).as_posix():record(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
started=time.monotonic_ns();before=state();write('source-before.json',before)
compiler_before=record(COMPILER)
python_path=Path(sys.executable).resolve(strict=True);python_before=record(python_path)
report={'schema':'hia.linked-observer.r4-complete-development-gate.v1','status':'HOLD',
 'scope':'DISTINCT_ENVIRONMENT_RETAINED_COMPILER_DEVELOPMENT',
 'source_scope':'explicit restored pin673 import closure and owned revised source; not a complete Git checkout',
 'original_remote18_status':'UNKNOWN','original_remote18_replayed':False,
 'python':sys.version,'platform':platform.platform(),'compiler_provenance':'8aade GitHub CI43098596489 artifact13891487322 B3; no matching-source cold qualification',
 'compiler_before':compiler_before,'python_before':python_before,
 'current_source_cold_qualification':False,'whole_native_delivery':False,'default_activation':False,
 'live_migration':False,'legacy_deletion':False,'limits':{'child_wall_seconds':20,'CPU_seconds':10,'AS_bytes':256<<20,'stack_bytes':8<<20,'file_bytes':16<<20,'open_files':32,'component_outer_seconds':600},
 'declared_tests':24,'tests_run':0,'failures':[],'errors':[],'skipped':[],'expected_failures':[],'unexpected_successes':[]}
try:
 for name,wanted in EXPECTED.items():assert before[name]['sha256']==wanted,('frozen product differs',name)
 assert compiler_before['bytes']==669494 and compiler_before['sha256']=='81b6fad94493546b5bf3f858248f25b19aded88bf8f3aaad18140aa317dac109'
 tools={}
 for name in ('as','ld','strace'):
  path=Path(shutil.which(name)).resolve(strict=True)
  actual=subprocess.run([str(path),'--version'],capture_output=True,timeout=30)
  write(name+'.version.stdout',actual.stdout);write(name+'.version.stderr',actual.stderr)
  assert actual.returncode==0
  tools[name]=record(path)
 report['tools_before']=tools
 report['removed_selector_names']=sorted(key for key in os.environ if key.startswith('HEPTA_HIA_'))
 for key in report['removed_selector_names']:os.environ.pop(key)
 os.environ['HEPTA_HIA_LINKED_OBSERVER_DEVELOPMENT_COMPILER']=str(COMPILER)
 os.environ['HEPTA_HIA_LINKED_OBSERVER_EVIDENCE']=str(OUT/'actual')
 os.environ['PYTHONDONTWRITEBYTECODE']='1'
 sys.path.insert(0,str(ROOT))
 with (OUT/'tests.log').open('x') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  spec=importlib.util.spec_from_file_location('linked_observer_r4_frozen_tests',ROOT/'tests/test_hia_selfhost_linked_native_observer.py')
  module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
  suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(module.LinkedObserverSourceTests),
                           unittest.defaultTestLoader.loadTestsFromTestCase(module.LinkedObserverNativeTests)])
  assert suite.countTestCases()==24
  result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 report.update(tests_run=result.testsRun,failures=[{'test':str(t),'traceback':error} for t,error in result.failures],
  errors=[{'test':str(t),'traceback':error} for t,error in result.errors],
  skipped=[{'test':str(t),'reason':reason} for t,reason in result.skipped],
  expected_failures=[str(t) for t,_ in result.expectedFailures],
  unexpected_successes=[str(t) for t in result.unexpectedSuccesses])
 if result.wasSuccessful() and result.testsRun==24 and not any((result.skipped,result.expectedFailures,result.unexpectedSuccesses)):
  report['status']='PASS_DEVELOPMENT_COMPONENT'
except BaseException as error:
 report['harness_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 after=state();write('source-after.json',after);report['source_unchanged']=after==before
 report['compiler_after']=record(COMPILER);report['python_after']=record(python_path)
 report['held_inputs_unchanged']=report['compiler_after']==compiler_before and report['python_after']==python_before
 if 'tools_before' in report:
  report['tools_after']={name:record(Path(row['path'])) for name,row in report['tools_before'].items()}
  report['held_inputs_unchanged']&=report['tools_before']==report['tools_after']
 if not report['source_unchanged'] or not report['held_inputs_unchanged']:report['status']='HOLD'
 observations=OUT/'actual/candidate/observations.json'
 if observations.exists():report['component_observations']=json.loads(observations.read_bytes())
 report['elapsed_ns']=time.monotonic_ns()-started
 report['source_before']=record(OUT/'source-before.json');report['source_after']=record(OUT/'source-after.json')
 if (OUT/'tests.log').exists():report['test_log']=record(OUT/'tests.log')
 write('report.json',report)
print(json.dumps({k:report[k] for k in ('status','tests_run','declared_tests','source_unchanged','held_inputs_unchanged','elapsed_ns','failures','errors','skipped')},sort_keys=True),flush=True)
raise SystemExit(0 if report['status']=='PASS_DEVELOPMENT_COMPONENT' else 1)
