from pathlib import Path
from hashlib import sha256
import ast,json,os,platform,subprocess,sys,time,traceback
from unittest.mock import patch
BASE=Path('/tmp/hia-linked-observer-local-v71-20261112-r1')
ROOT=BASE/'source-r4'; OUT=BASE/'evidence/r4-reference-r2'
OUT.mkdir(mode=0o700,exist_ok=False)
os.umask(0o077)
def digest(data):return sha256(data).hexdigest()
def write(name,data):
 raw=data if isinstance(data,bytes) else (json.dumps(data,indent=2,sort_keys=True)+'\n').encode()
 with (OUT/name).open('xb') as f:f.write(raw)
def source_state():return {p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p.read_bytes()),'mode':p.stat().st_mode&0o777} for p in sorted(ROOT.rglob('*')) if p.is_file()}
before=source_state(); write('source-before.json',before)
report={'schema':'hia.linked-observer.r4-source-reference.v1','status':'HOLD','python':sys.version,'platform':platform.platform(),'original_ai39518':'UNKNOWN','new_HIA_native_compilation':False,'current_source_cold_qualification':False,'source_scope':'explicit known673 import closure plus revised linked observer; not complete checkout'}
began=time.monotonic_ns()
try:
 sys.path.insert(0,str(ROOT))
 from tools import generate_hia_linked_native_observer as gen
 from tools import hia_selfhost_linked_native_observer as bridge
 from hepta.hia_agent_assembly import assemble_program,render_assembly
 from hepta.hia_program import verify_program
 disabled={k:'' for k in os.environ if k.startswith('HEPTA_HIA_')}
 report['cleared_selector_names']=sorted(disabled)
 with patch.dict(os.environ,disabled):
  checked=assemble_program(gen.PACKER.read_bytes())
  assert render_assembly(gen.document()).encode()==gen.PACKER.read_bytes()
  document=checked.as_dict()
  report['profile']={'functions':len(document['functions']),'blocks':sum(len(f['blocks']) for f in document['functions']),'operations':sum(len(b['ops']) for f in document['functions'] for b in f['blocks']),'max_parameters':max([len(f['params']) for f in document['functions']]+[len(b['params']) for f in document['functions'] for b in f['blocks']]),'max_function_blocks':max(len(f['blocks']) for f in document['functions'])}
  assert report['profile']['functions']<=128 and report['profile']['blocks']<=1536 and report['profile']['operations']<=8192 and report['profile']['max_parameters']<=16 and report['profile']['max_function_blocks']<=256
  raw=gen.reference_object();write('reference-object.o',raw)
  source=(ROOT/'tests/test_hia_selfhost_linked_native_observer.py').read_text()
  tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='elf_contents')
  import struct
  namespace={'struct':struct};exec(compile(ast.Module([node],type_ignores=[]),'retained-elf-contents','exec'),namespace)
  command=['as','--64',str(ROOT/'tools/hia_linked_native_observer_reference.S'),'-o',str(OUT/'independent-reference.o')]
  process=subprocess.run(command,capture_output=True,timeout=30)
  write('assembler.stdout',process.stdout);write('assembler.stderr',process.stderr)
  report['assembler']={'command':command,'returncode':process.returncode}
  assert process.returncode==0
  actual=namespace['elf_contents']((OUT/'independent-reference.o').read_bytes());expected=namespace['elf_contents'](raw)
  comparison={'text_bytes':len(expected['text']),'expected_text_sha256':digest(expected['text']),'actual_text_sha256':digest(actual['text']),'text_equal':actual['text']==expected['text'],'relocations_equal':actual['relocations']==expected['relocations'],'actual_relocations':actual['relocations'],'expected_relocations':expected['relocations']}
  write('assembler-comparison.json',comparison);report['assembler_comparison']=comparison
  assert comparison['text_equal'] and comparison['relocations_equal']
  vm=bridge.independent_reference(before_B0=False);write('ordinary-Core-VM.json',vm)
  report['ordinary_Core_VM']={'windows':len(vm['vm_windows']),'every_byte_equal':vm['every_output_byte_compared'],'reference_object_bytes':len(raw),'reference_object_sha256':digest(raw),'packer_source_bytes':gen.PACKER.stat().st_size,'packer_source_sha256':digest(gen.PACKER.read_bytes())}
  assert vm['expected_object_sha256']==digest(raw) and vm['before_native_compilation'] is True
 report['status']='SOURCE_REFERENCE_PASS'
except BaseException as error:report['error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 after=source_state();write('source-after.json',after);report['source_unchanged']=after==before;report['elapsed_ns']=time.monotonic_ns()-began
 if after!=before:report['status']='HOLD'
 write('report.json',report)
print(json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(0 if report['status']=='SOURCE_REFERENCE_PASS' else 1)
