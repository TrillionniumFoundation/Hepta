"""Independent hosted oracle and post-run comparison for the native controller.

Value construction/interpretation is confined to test setup, the retained
reference path, and completed-run comparisons. The forward loop is poisoned
against every retained owner and value decoder used by the older adapters.
"""
from contextlib import ExitStack
from copy import deepcopy
import gzip
from hashlib import sha256
import json
from pathlib import Path
import struct
from unittest.mock import patch

from mechanical_executor import Bundle, Executor, actual_source_lease, C
from hepta import hia_program_composite as composite
from hepta import hia_composite_types_native as native_types
from hepta import hia_composite_functions_native as native_functions
from hepta import hia_task_helpers_native as native_helpers
from hepta.hia_composite_constructor_errors import ERRORS as CTOR_ERRORS
from hepta.hia_composite_function_tokens import ObjectTokenDecoder
from hepta.hia_instruction_policy_native import transport
from hepta.hia_program import HIAProgramRejected, _bounded_detached_snapshot, _structure


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()


def forbidden(*args, **kwargs):
    raise AssertionError('host semantic/value transport used in native forwarding')


class CompressedExecutor(Executor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ledger.close()
        (self.directory/'entries.jsonl').unlink()
        self.ledger=gzip.open(self.directory/'entries.jsonl.gz', 'wt', encoding='utf-8', compresslevel=1)


def oracle(bundle, document, legacy):
    owner=composite._Elaborator.__new__(composite._Elaborator)
    result={}; core=None
    with ExitStack() as stack:
        stack.enter_context(patch.object(native_types, 'selected_composite_types', new=lambda definitions, **kw:
            native_types.NativeCompositeTypeSession(bundle.images[8], definitions, **kw)))
        stack.enter_context(patch.object(native_functions, 'selected_composite_functions', new=lambda:None))
        stack.enter_context(patch.object(native_helpers, 'selected_task_helpers', new=lambda:None))
        try:
            owner._reference_initialize(document, legacy=legacy)
            core=owner._reference_lower()
            _structure(_bounded_detached_snapshot(core))
            result.update(accepted=True)
        except HIAProgramRejected as exc:
            result.update(accepted=False, code=exc.code, error=str(exc))
        finally:
            result['serial']=getattr(owner, 'serial', 0)
            result['slots']=getattr(owner, 'value_slots', 0)
            result['attributes']=sorted(vars(owner))
            result['helpers']=deepcopy(getattr(owner, 'helpers', []))
            typ=getattr(owner, 'native_types', None)
            result['type_observations']=None if typ is None else typ.observations
            result['helper_cache']=[]
            if typ is not None:
                ids={value.key:identifier for identifier, value in typ._types.items()}
                for (key, operation), name in getattr(owner, 'helper_names', {}).items():
                    result['helper_cache'].append([ids[key], native_functions.OPERATIONS.index(operation),
                                                  int(name.removeprefix('h2internal_'))])
                typ.close()
    return result, None if core is None else compact(core)


def _native_diagnostic(frame):
    group, error=frame[4:6]
    if group==1: return CTOR_ERRORS[error]
    if group==2: return native_types.ERRORS[error]
    if group==3: return native_functions.ERRORS[error]
    if group==4: return native_helpers.ERRORS[error]
    if group==5:
        assert error==1
        return 'E_HIA_LIMIT', 'elaborated program exceeds core inventory budget'
    if group==6:
        return 'E_HIA_LIMIT', {1:'caller-owned tree exceeds snapshot budget',
            2:'caller-owned tree exceeds queued-node budget',
            3:'program exceeds byte budget before encoding'}[error]
    raise AssertionError(('unrecognized complete semantic result', frame))


def native_error(frame):
    code, message=_native_diagnostic(frame)
    return code, str(HIAProgramRejected(message, code))


def guarded_forward(executor):
    with ExitStack() as guard:
        for method in ('_reference_initialize', '_reference_function', '_reference_helper', '_reference_lower',
                       '_reference_parameters', '_reference_check_task', 'loan_origins', 'fresh',
                       'reserve_values', 'flat_parameters', 'constant', 'zeros', 'drop_padding', 'helper'):
            guard.enter_context(patch.object(composite._Elaborator, method, new=forbidden))
        guard.enter_context(patch.object(composite, '_Types', new=forbidden))
        for method in ('_command', '_materialize_value'):
            guard.enter_context(patch.object(native_types.NativeCompositeTypeSession, method, new=forbidden))
        guard.enter_context(patch.object(ObjectTokenDecoder, 'feed', new=forbidden))
        guard.enter_context(patch.object(json, 'loads', new=forbidden))
        import hepta.hia_instruction_policy_native as packet_owner
        guard.enter_context(patch.object(packet_owner, 'transport', new=forbidden))
        return executor.run()


def run_case(bundle, destination, label, submitted, legacy=False):
    # The public decode supplies a detached canonical-key document. Exercise
    # exactly that semantic input here, while retaining the explicit fact that
    # this development panel constructs its typed packet in Python.
    document=json.loads(json.dumps(submitted, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
    _structure(_bounded_detached_snapshot(document))
    expected, expected_core=oracle(bundle, document, legacy)
    packet=transport(document); lease, issuer=actual_source_lease(bundle, packet)
    executor=CompressedExecutor(bundle, lease, destination/label, legacy=legacy)
    folder=executor.directory
    (folder/'source-document.json').write_bytes(compact(document))
    (folder/'source.packet').write_bytes(packet)
    expected_summary={k:v for k,v in expected.items() if k!='helpers'}
    expected_summary['helper_sha256']=[sha256(compact(h)).hexdigest() for h in expected['helpers']]
    expected_summary['core_bytes']=None if expected_core is None else len(expected_core)
    expected_summary['core_sha256']=None if expected_core is None else sha256(expected_core).hexdigest()
    (folder/'oracle.json').write_text(json.dumps(expected_summary, indent=2, sort_keys=True)+'\n')
    try:
        frame=guarded_forward(executor)
        actual_core=executor.result_bytes()
        accepted=frame[4:6]==(0,0)
        assert accepted==expected['accepted'], (label, frame, expected_summary)
        if not accepted:
            assert native_error(frame)==(expected['code'], expected['error']), (label, native_error(frame), expected_summary)
        assert frame[7:9]==(expected['serial'], expected['slots']), (label, frame, expected_summary)
        if actual_core is not None:
            assert actual_core==expected_core, label
            assert frame[11]==len(actual_core), label
            assert b''.join(x.to_bytes(8,'little') for x in frame[12:])==sha256(actual_core).digest(), label
            with gzip.open(folder/'actual-core.json.gz', 'wb', compresslevel=1) as out: out.write(actual_core)
        elif accepted:
            raise AssertionError(('accepted without complete Core', label))
        count=executor.read_state('L_COMMITTED_CACHE_COUNT')
        cache=[list(struct.unpack('<3Q',executor.buffers[2].read(C['CACHE_COMMITTED']+i*24,24))) for i in range(count)]
        assert cache==expected['helper_cache'], (label, cache, expected_summary)
        if expected['type_observations'] is not None:
            event=struct.unpack('<16Q',executor.buffers[15].read(0,128))
            actual_observations=dict(zip(('cache_count','active_count','partial_declaration_steps'),event[8:11]))
            assert actual_observations==expected['type_observations'], (label, actual_observations, expected_summary)
        else:
            actual_observations=None
        row={'case':label, 'status':'PASS', 'legacy':legacy, 'frame':frame,
             'accepted':accepted, 'error':None if accepted else native_error(frame),
             'core_bytes':None if actual_core is None else len(actual_core),
             'core_sha256':None if actual_core is None else sha256(actual_core).hexdigest(),
             'native_calls':dict(executor.calls), 'executor_events':dict(executor.events),
             'max_live_buffer_bytes':executor.max_live_bytes, 'source_issuer':issuer,
             'helper_cache':cache, 'type_observations':actual_observations,
             'ctor_handoff':executor.ctor_handoff}
        (folder/'result.json').write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
        return row
    finally:
        executor.close()
