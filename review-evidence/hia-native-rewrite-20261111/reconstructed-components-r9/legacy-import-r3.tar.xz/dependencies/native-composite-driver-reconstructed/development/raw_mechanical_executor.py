"""Development-only mechanical executor, extended with the native raw prefix."""
from collections import Counter
from hashlib import sha256
import gzip
import json
from pathlib import Path
import struct

import mechanical_executor as old
from mechanical_executor import Buffer,Executor,C,EXPECTED_SOURCES,NativeHiaJsonImage

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'Hepta-v66-restored'
RAW_CONFIG=int.from_bytes(b'HIARNC01','little')
CTOR_INIT=int.from_bytes(b'HIACDI01','little')


class RawBundle(old.Bundle):
    EXTRA_EXPECTED={}
    def __init__(self,path):
        expected=dict(EXPECTED_SOURCES)
        expected.update({24:BASE/'examples/hia_bootstrap/json_decode.hiaasm',
            25:ROOT/'immutable-recovery/raw-prefix/stage5/examples/hia_bootstrap/composite_json_packet.hiaasm',
            26:BASE/'examples/hia_bootstrap/json_canonical.hiaasm',
            44:ROOT/'examples/hia_bootstrap/composite_raw_driver.hiaasm'})
        expected.update(self.EXTRA_EXPECTED)
        self.pins,self.images,self.components={},{},{}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes()
            if path in self.pins:assert self.pins[path]==raw
            self.pins[path]=raw;return raw
        value=json.loads(read(path))
        assert value['status']=='PASS' and value['all_source_and_compiler_bytes_unchanged'] is True
        assert set(map(int,value['components']))==set(expected)
        for key,row in value['components'].items():
            role=int(key);assert row['role']==role
            assert Path(row['expected_source_path']).resolve()==expected[role].resolve()
            assert row['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
            source=read(row['source_path']);current=read(expected[role]);image=read(row['image_path'])
            receipt=json.loads(read(row['receipt_path']))
            assert source==current and len(source)==row['source_bytes']
            assert sha256(source).hexdigest()==row['source_sha256']
            assert len(image)==row['image_bytes'] and sha256(image).hexdigest()==row['image_sha256']
            assert receipt['input_sha256']==row['source_sha256']
            assert receipt['produced_sha256']==row['image_sha256']
            assert receipt['artifact_sha256']==row['compiler_sha256']
            self.components[role]=row
        self.readback()
        for role,row in self.components.items():
            self.images[role]=NativeHiaJsonImage(self.pins[Path(row['image_path']).resolve()],row['image_sha256'])


class RawExecutor(Executor):
    def __init__(self,bundle,wire,directory,*,legacy=False,digits=4300):
        self.bundle=bundle;self.directory=Path(directory);self.directory.mkdir(exist_ok=False)
        assert type(wire) is bytes and len(wire)<= (8<<20)+1
        self.buffers={0:Buffer(1,readonly=True),2:Buffer(C['MIN_WORK']),44:Buffer(len(wire),wire,True)}
        self.files={};self.sealed=set();self.positions={};self.calls=Counter();self.events=Counter()
        self.ledger=gzip.open(self.directory/'entries.jsonl.gz','wt',encoding='utf-8',compresslevel=1)
        self.sequence=0;self.controller=44;self.closed=False
        self.prefix_handoff=None;self.ctor_handoff=None;self.final=None;self.max_live_bytes=0
        self.identifier=71;self.command=wire
        for slot,buf in self.buffers.items():
            self.buffers[2].write(C['CAPS']+slot*8,struct.pack('<Q',buf.size))
        self.buffers[2].write(12288,struct.pack('<8Q',RAW_CONFIG,int(legacy),digits,71,0,0,0,0))
        (self.directory/'raw-input.json').write_bytes(wire)
        old.TWO_READ.add(25)

    def operate(self,frame):
        if frame[1]!=1 or frame[4]<24:return super().operate(frame)
        image,first,at,size,second,secondsize,work,worksize,observe,offset,count,zero=frame[4:]
        assert image in (24,25,26) and zero==0 and count<=256
        self.events[1]+=1
        result=self.native(image,first,at,size,second,secondsize,work,worksize)
        observed=self.buffers[observe].read(offset,count)
        self.max_live_bytes=max(self.max_live_bytes,sum(buf.size for buf in self.buffers.values()))
        return struct.pack('<8Q',C['ACK_MAGIC'],frame[2],frame[3],1,0,result,len(observed),0)+observed

    def run(self):
        while self.controller==44:
            initial=self.calls[44]==0
            command=self.buffers[44] if initial else Buffer(len(self.command),self.command,True)
            output=Buffer(128)
            try:
                result=int(self.bundle.images[44]._entry(command.address,command.size,output.address,128,
                    self.buffers[2].address,C['MIN_WORK']))
                self.calls[44]+=1;command.check();output.check();self.buffers[2].check()
                assert command.read(0,command.size)==self.command
                raw=output.read(0,128)
            finally:
                if not initial:command.close()
                output.close()
            self.log({'kind':'controller','role':44,'return':result,'phase':self.read_state('C_PHASE'),
                'reason':self.read_state('C_REASON'),'input_bytes':len(self.command),
                'input_sha256':sha256(self.command).hexdigest(),
                'input_hex':self.command.hex() if len(self.command)<=320 else None,'frame':raw.hex()})
            assert result==128, ('raw controller refused',result,self.read_state('C_REASON'))
            frame=struct.unpack('<16Q',raw)
            assert frame[0]==C['EVENT_MAGIC'] and frame[2]==self.identifier
            if frame[1]==7:
                assert frame[3]==self.sequence
                self.prefix_handoff=frame
                (self.directory/'prefix-handoff.bin').write_bytes(raw)
                if frame[4]==7:
                    self.final=frame;return frame
                assert frame[4]==CTOR_INIT and frame[5]==self.identifier+1 and frame[6]<=1 and frame[8]==48 and not any(frame[9:])
                assert set(self.buffers)=={0,2,48} and self.buffers[48].readonly and self.buffers[48].size==frame[7]
                self.buffers[1]=self.buffers.pop(48)
                (self.directory/'native-source.lease').write_bytes(self.buffers[1].read(0,self.buffers[1].size))
                self.controller=43;self.sequence=0;self.identifier=frame[5]
                self.command=struct.pack('<8Q',CTOR_INIT,frame[5],frame[6],frame[7],0,0,0,0)
                break
            assert frame[3]==self.sequence+1
            self.sequence=frame[3];self.command=self.operate(frame)
        return super().run()
