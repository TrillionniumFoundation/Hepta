"""Development executor for native driver events, never a value interpreter.

This Python executor is a test instrument, not the final native ELF executor.
It only applies fixed operations on privately owned buffers and files. Every
semantic/continuation decision and every value projection is a real HIA call.
"""
from collections import Counter
import ctypes
import fcntl
from hashlib import sha256
import json
import mmap
import os
from pathlib import Path
import struct

from hepta.hia_json_preflight_native import NativeHiaJsonImage
from tools.hia_composite_lowering_driver_common import CONSTANTS as C

CANARY = b'\xa7' * 32
PAGE = mmap.PAGESIZE
LIBC = ctypes.CDLL(None, use_errno=True)
LIBC.mprotect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
LIBC.mprotect.restype = ctypes.c_int
TWO_READ = {1, 5, 6, 10, 18, 19, 21, 23}
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent/'Hepta-v66-restored'
REC = ROOT/'immutable-recovery'
HELP = ROOT.parent/'native-composite-helper-transport-recovery-next'
CORE = ROOT.parent/'native-composite-core-final-recovery-next'
EXPECTED_SOURCES = {
    1:REC/'stage11/source/examples/hia_bootstrap/composite_owner_packets.hiaasm',
    2:REC/'stage8/dependencies/packet-issuer/examples/hia_bootstrap/composite_packet_json.hiaasm',
    5:REC/'stage8/examples/hia_bootstrap/composite_object_ir.hiaasm',
    6:REC/'stage9/examples/hia_bootstrap/composite_type_requests.hiaasm',
    7:REC/'types-r2/examples/hia_bootstrap/composite_type_transport_commands.hiaasm',
    9:REC/'types-r2/examples/hia_bootstrap/composite_type_transport_reply.hiaasm',
    10:REC/'stage10/source/examples/hia_bootstrap/composite_type_responses.hiaasm',
    18:HELP/'checkpoints/source-reconstructed-r3/examples/hia_bootstrap/composite_helper_transport_request.hiaasm',
    19:HELP/'checkpoints/source-reconstructed-r3/examples/hia_bootstrap/composite_helper_transport_reply.hiaasm',
    21:REC/'stage7/examples/hia_bootstrap/composite_object_json.hiaasm',
    23:CORE/'examples/hia_bootstrap/composite_core_final.hiaasm',
}
for _role,_name in ((3,'composite_constructor_owner'),(4,'composite_constructor_render'),
        (8,'composite_types'),(11,'composite_function_admit'),(12,'composite_function_records'),
        (13,'composite_function_advanced'),(14,'composite_function_terms'),(15,'composite_function_render'),
        (16,'composite_outer_owner'),(17,'composite_outer_render'),(20,'task_helpers'),(22,'sha256_stream')):
    EXPECTED_SOURCES[_role]=BASE/('examples/hia_bootstrap/'+_name+'.hiaasm')
for _role,_name in ((40,'main'),(41,'services'),(42,'stream'),(43,'ctor')):
    EXPECTED_SOURCES[_role]=ROOT/('examples/hia_bootstrap/composite_lowering_driver_'+_name+'.hiaasm')


class Buffer:
    def __init__(self, size, raw=b'', readonly=False):
        assert size >= 0 and len(raw) <= size
        self.size = size
        self.extent = ((size + 32 + PAGE - 1) // PAGE) * PAGE
        self.mapping = mmap.mmap(-1, self.extent, prot=mmap.PROT_READ | mmap.PROT_WRITE)
        self.address = ctypes.addressof(ctypes.c_char.from_buffer(self.mapping))
        self.readonly = False
        if raw:
            ctypes.memmove(self.address, raw, len(raw))
        ctypes.memmove(self.address + size, CANARY, 32)
        self.protect(readonly)

    def read(self, offset, size):
        assert 0 <= offset <= self.size and 0 <= size <= self.size-offset
        return ctypes.string_at(self.address + offset, size)

    def write(self, offset, raw):
        assert not self.readonly and 0 <= offset <= self.size and len(raw) <= self.size-offset
        if raw:
            ctypes.memmove(self.address+offset, raw, len(raw))

    def check(self):
        assert ctypes.string_at(self.address+self.size, 32) == CANARY

    def protect(self, readonly):
        readonly = bool(readonly)
        if self.readonly == readonly:
            return
        rights = mmap.PROT_READ | (0 if readonly else mmap.PROT_WRITE)
        if LIBC.mprotect(self.address, self.extent, rights):
            raise OSError(ctypes.get_errno(), 'private buffer protection')
        self.readonly = readonly

    def close(self):
        if self.mapping is not None:
            self.check()
            self.mapping.close()
            self.mapping = None


class Bundle:
    def __init__(self, path):
        self.pins, self.images, self.components = {}, {}, {}
        def read(path):
            path=Path(path).resolve(); raw=path.read_bytes()
            if path in self.pins:
                assert self.pins[path] == raw
            self.pins[path]=raw
            return raw
        raw=read(path); value=json.loads(raw)
        assert value['status']=='PASS' and value['all_source_and_compiler_bytes_unchanged'] is True
        assert set(map(int, value['components'])) == set(range(1,24)) | {40,41,42,43}
        for key,row in value['components'].items():
            role=int(key)
            assert row['role']==role
            assert Path(row['expected_source_path']).resolve()==EXPECTED_SOURCES[role].resolve()
            assert row['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
            source=read(row['source_path']); expected=read(EXPECTED_SOURCES[role])
            image=read(row['image_path']); receipt=json.loads(read(row['receipt_path']))
            assert source == expected and sha256(source).hexdigest() == row['source_sha256']
            assert len(source)==row['source_bytes'] and len(image)==row['image_bytes']
            assert sha256(image).hexdigest()==row['image_sha256']
            assert receipt['input_sha256']==row['source_sha256']
            assert receipt['produced_sha256']==row['image_sha256']
            assert receipt['artifact_sha256']==row['compiler_sha256']
            self.components[role]=row
        self.readback()
        for role,row in self.components.items():
            self.images[role]=NativeHiaJsonImage(self.pins[Path(row['image_path']).resolve()], row['image_sha256'])

    def readback(self):
        assert all(path.read_bytes()==raw for path,raw in self.pins.items())

    def close(self):
        for image in self.images.values():
            image._mapping.close()
        self.images.clear()
        self.readback()


def actual_source_lease(bundle, packet):
    """Issue the bitmap with the actual native packet image, before forwarding."""
    size=len(packet); assert 16 <= size <= 64<<20
    slots=2
    while slots < (size >> 5)*2:
        slots *= 2
    index=128+slots*16; bitmap=(size+7)//8
    stack=(index+bitmap+7)&~7
    worksize=stack+(size//24+1)*32
    source=Buffer(size, packet, True)
    output=Buffer(64+size*6)
    work=Buffer(worksize)
    try:
        work.write(0, struct.pack('<Q', C['PACKET_JSON_MAGIC']) + bytes(120))
        result=int(bundle.images[2]._entry(source.address,size,output.address,output.size,work.address,work.size))
        source.check(); output.check(); work.check()
        header=struct.unpack('<8Q',output.read(0,64))
        assert result==64+header[3] and header[:3]==(C['PACKET_JSON_MAGIC'],0,64)
        assert header[5:]==(size,index,bitmap)
        assert source.read(0,size)==packet
        bitmap_raw=work.read(index,bitmap)
        aligned=(64+size+7)&~7
        lease=struct.pack('<8Q',C['SOURCE_MAGIC'],size,bitmap,64,aligned,aligned+bitmap,0,0)+packet+bytes(aligned-64-size)+bitmap_raw
        return lease, {'native_issuer_return':result, 'header':header, 'packet_sha256':sha256(packet).hexdigest(),
                       'source_lease_sha256':sha256(lease).hexdigest(), 'source_bytes_unchanged':True}
    finally:
        source.close(); output.close(); work.close()


class Executor:
    def __init__(self, bundle, lease, directory, *, legacy=False, identifier=71):
        self.bundle=bundle; self.directory=Path(directory); self.directory.mkdir(exist_ok=False)
        self.buffers={0:Buffer(1,readonly=True),1:Buffer(len(lease),lease,True),2:Buffer(C['MIN_WORK'])}
        self.files={}; self.sealed=set(); self.positions={}; self.calls=Counter(); self.events=Counter()
        self.ledger=(self.directory/'entries.jsonl').open('w')
        self.sequence=0; self.controller=43; self.closed=False
        self.ctor_handoff=None; self.final=None; self.max_live_bytes=0
        for slot,buf in self.buffers.items():
            self.buffers[2].write(C['CAPS']+slot*8,struct.pack('<Q',buf.size))
        self.command=struct.pack('<8Q', int.from_bytes(b'HIACDI01','little'), identifier, int(legacy), len(lease),0,0,0,0)
        self.identifier=identifier
        (self.directory/'source.lease').write_bytes(lease)

    def read_state(self, name):
        return struct.unpack('<Q',self.buffers[2].read(C[name],8))[0]

    def log(self, row):
        self.ledger.write(json.dumps(row,sort_keys=True)+'\n'); self.ledger.flush()

    def native(self, role, first, at, extent, second, second_extent, workspace, work_extent):
        a,b,c=self.buffers[first],self.buffers[second],self.buffers[workspace]
        assert len({id(a),id(b),id(c)})==3
        assert 0<=at<=a.size and 0<=extent<=a.size-at and 0<=second_extent<=b.size and 0<=work_extent<=c.size
        assert not c.readonly
        rights=[(a,a.readonly)]
        if role in TWO_READ:
            rights.append((b,b.readonly))
        else:
            assert not b.readonly
        before=sha256(a.read(at,extent)).hexdigest() if extent < 8<<20 else None
        try:
            for buf,_ in rights:buf.protect(True)
            result=int(self.bundle.images[role]._entry(a.address+at,extent,b.address,second_extent,c.address,work_extent))
        finally:
            for buf,old in reversed(rights):buf.protect(old)
        for buf in (a,b,c):buf.check()
        if before is not None:assert sha256(a.read(at,extent)).hexdigest()==before
        self.calls[role]+=1
        self.log({'kind':'image','role':role,'return':result,'first_bytes':extent,'first_sha256':before,
                  'second_bytes':second_extent,'work_bytes':work_extent,
                  'image_sha256':self.bundle.components[role]['image_sha256']})
        return result

    def operate(self, frame):
        opcode=frame[1]; a=frame[4:]
        self.events[opcode]+=1
        result=0; observed=b''
        if opcode==1:
            image,first,at,size,second,secondsize,work,worksize,observe,offset,count,zero=a
            assert zero==0 and image in range(1,24) and count<=256
            result=self.native(image,first,at,size,second,secondsize,work,worksize)
            observed=self.buffers[observe].read(offset,count)
        elif opcode==2:
            slot,size=a[:2]; assert not any(a[2:]) and 4<=slot<64 and size>0
            previous=self.buffers.get(slot)
            assert previous is None or (not previous.readonly and size>previous.size)
            new=Buffer(size)
            if previous is not None:
                ctypes.memmove(new.address,previous.address,previous.size); previous.close()
            self.buffers[slot]=new
        elif opcode==3:
            slot,offset,size=a[:3]; assert not any(a[3:])
            buf=self.buffers[slot]
            assert not buf.readonly and 0<=offset<=buf.size and 0<=size<=buf.size-offset
            ctypes.memset(buf.address+offset,0,size)
        elif opcode==4:
            source,at,target,to,size=a[:5]; assert not any(a[5:]) and source!=target
            src,dst=self.buffers[source],self.buffers[target]
            assert not dst.readonly and 0<=at<=src.size and size<=src.size-at and 0<=to<=dst.size and size<=dst.size-to
            ctypes.memmove(dst.address+to,src.address+at,size)
        elif opcode==5:
            slot=a[0]; assert not any(a[1:]) and slot>=4
            self.buffers.pop(slot).close()
        elif opcode==6:
            slot,readonly=a[:2]; assert not any(a[2:]) and readonly in (0,1)
            self.buffers[slot].protect(readonly)
        elif opcode==8:
            target=a[0]; assert not any(a[1:]) and target in (40,41,42) and target!=self.controller
            self.controller=target
        elif opcode==10:
            file=a[0]; assert file in (0,1) and file not in self.files and not any(a[1:])
            self.files[file]=os.memfd_create('hia-development-private-spool',os.MFD_ALLOW_SEALING|os.MFD_CLOEXEC)
            self.positions[file]=0
        elif opcode==11:
            file,at,slot,offset,size=a[:5]
            assert not any(a[5:]) and file in self.files and file not in self.sealed and at==self.positions[file]
            raw=self.buffers[slot].read(offset,size); pos=0
            while pos<len(raw):
                try:n=os.pwrite(self.files[file],raw[pos:],at+pos)
                except InterruptedError:continue
                assert n>0; pos+=n
            self.positions[file]+=size
        elif opcode==12:
            file,at,slot,offset,size=a[:5]
            assert not any(a[5:]) and file in self.sealed and at<=self.positions[file] and size<=self.positions[file]-at
            result_bytes=bytearray()
            while len(result_bytes)<size:
                try:part=os.pread(self.files[file],size-len(result_bytes),at+len(result_bytes))
                except InterruptedError:continue
                assert part; result_bytes.extend(part)
            self.buffers[slot].write(offset,bytes(result_bytes))
        elif opcode==13:
            file=a[0]; assert not any(a[1:]) and file in self.files and file not in self.sealed
            fcntl.fcntl(self.files[file],fcntl.F_ADD_SEALS,fcntl.F_SEAL_GROW|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_WRITE|fcntl.F_SEAL_SEAL)
            self.sealed.add(file)
        elif opcode==14:
            slot,offset,size=a[:3]; assert not any(a[3:]) and size<=256
            observed=self.buffers[slot].read(offset,size)
        else:
            raise AssertionError('unknown fixed executor opcode '+str(opcode))
        for buf in self.buffers.values():buf.check()
        self.max_live_bytes=max(self.max_live_bytes,sum(buf.size for buf in self.buffers.values()))
        return struct.pack('<8Q',C['ACK_MAGIC'],frame[2],frame[3],opcode,0,result,len(observed),0)+observed

    def run(self):
        while True:
            command=Buffer(len(self.command),self.command,True); output=Buffer(128)
            try:
                result=int(self.bundle.images[self.controller]._entry(command.address,command.size,
                          output.address,128,self.buffers[2].address,C['MIN_WORK']))
                self.calls[self.controller]+=1
                command.check(); output.check(); self.buffers[2].check()
                assert command.read(0,command.size)==self.command
                raw=output.read(0,128)
            finally:
                command.close(); output.close()
            row={'kind':'controller','role':self.controller,'return':result,'phase':self.read_state('C_PHASE'),
                 'reason':self.read_state('C_REASON'),'input_bytes':len(self.command),
                 'input_sha256':sha256(self.command).hexdigest(),'input_hex':self.command.hex(),'frame':raw.hex()}
            self.log(row)
            if result != 128:
                raise AssertionError('native controller refused: '+json.dumps(row,sort_keys=True))
            frame=struct.unpack('<16Q',raw)
            assert frame[0]==C['EVENT_MAGIC'] and frame[2]==self.identifier
            if frame[1]==7:
                assert frame[3]==self.sequence
                if self.controller==43:
                    assert self.ctor_handoff is None
                    self.ctor_handoff=frame
                    (self.directory/'constructor-handoff.bin').write_bytes(raw)
                    self.controller=40; self.command=raw
                    continue
                assert self.controller==40
                self.final=frame
                (self.directory/'final-handoff.bin').write_bytes(raw)
                return frame
            assert frame[3]==self.sequence+1
            self.sequence=frame[3]
            self.command=self.operate(frame)

    def result_bytes(self):
        if 1 not in self.files:return None
        assert 1 in self.sealed
        return os.pread(self.files[1],self.positions[1],0)

    def close(self):
        if self.closed:return
        for fd in self.files.values():os.close(fd)
        self.files.clear()
        for buf in self.buffers.values():buf.close()
        self.buffers.clear()
        self.ledger.close(); self.bundle.readback(); self.closed=True

