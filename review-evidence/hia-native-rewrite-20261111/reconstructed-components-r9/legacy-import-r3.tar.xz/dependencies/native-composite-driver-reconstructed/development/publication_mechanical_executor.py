"""New development revision, including actual complete primitive admission."""
from pathlib import Path
from hashlib import sha256
import struct
from raw_mechanical_executor import RawBundle,RawExecutor,Buffer,C,ROOT,BASE


class PublicBundle(RawBundle):
    EXTRA_EXPECTED={27:BASE/'examples/hia_bootstrap/core_admission.hiaasm',
                    45:ROOT/'examples/hia_bootstrap/composite_publication_driver.hiaasm'}


class PublicExecutor(RawExecutor):
    def operate(self,frame):
        if frame[1]!=1 or frame[4]!=27:return super().operate(frame)
        image,first,at,size,second,secondsize,work,worksize,observe,offset,count,zero=frame[4:]
        assert zero==0 and count<=256
        self.events[1]+=1
        result=self.native(image,first,at,size,second,secondsize,work,worksize)
        observed=self.buffers[observe].read(offset,count)
        return struct.pack('<8Q',C['ACK_MAGIC'],frame[2],frame[3],1,0,result,len(observed),0)+observed

    def run(self):
        frame=super().run()
        self.lowering_frame=frame;self.publication_frame=None
        if frame[4:6]!=(0,0):return frame
        self.controller=45;self.command=struct.pack('<16Q',*frame)
        while True:
            command=Buffer(len(self.command),self.command,True);output=Buffer(128)
            try:
                result=int(self.bundle.images[45]._entry(command.address,command.size,output.address,128,
                    self.buffers[2].address,C['MIN_WORK']))
                self.calls[45]+=1;command.check();output.check();self.buffers[2].check()
                assert command.read(0,command.size)==self.command
                raw=output.read(0,128)
            finally:command.close();output.close()
            self.log({'kind':'controller','role':45,'return':result,'phase':self.read_state('C_PHASE'),
                'reason':self.read_state('C_REASON'),'input_hex':self.command.hex(),'frame':raw.hex()})
            assert result==128,('publication refused',result,self.read_state('C_REASON'))
            frame=struct.unpack('<16Q',raw)
            assert frame[0]==C['EVENT_MAGIC'] and frame[2]==self.identifier
            if frame[1]==7:
                assert frame[3]==self.sequence
                self.publication_frame=frame;self.final=frame
                (self.directory/'publication-frame.bin').write_bytes(raw)
                return frame
            assert frame[3]==self.sequence+1
            self.sequence=frame[3];self.command=self.operate(frame)

    def published_bytes(self):
        if self.publication_frame is None or self.publication_frame[4:6]!=(0,0):return None
        result=self.buffers[45].read(0,self.publication_frame[11])
        assert self.buffers[45].readonly
        assert sha256(result).digest()==b''.join(n.to_bytes(8,'little') for n in self.publication_frame[12:])
        return result
