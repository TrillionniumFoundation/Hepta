# Complete explicit legacy composite importer: native development r3

## Delivered behavior

The standalone x86-64 ELF reads raw JSON bytes from stdin and executes the complete historical `import_legacy_composite_v2` semantic path. All language decisions run in 37 embedded HIA images. A separately compiled HIA packer emitted the actual ELF from the fixed mechanical syscall template and those exact images. The executable runs with empty PATH and HOME; it does not load Python or an external compiler, interpret a host semantic plan, or launch child processes.

The native sequence preserves the original public raw-byte contract: integer JSON admission; exact four-field legacy envelope; explicit historical schema; schema rename; complete legacy lowering; complete primitive-v1 admission; the renamed-input byte gate; a fresh independent ordinary composite-v1 lowering and primitive-v6 admission; complete canonical payload comparison excluding only the schema digit; then the original report and full structured source. Legacy import remains an explicit operation. It is not selected by ordinary structured input.

Successful stdout is the complete canonical object `{"core":...,"report":...,"structured":...}`. All report hashes and claims match the retained importer. Semantic refusal writes its native 128-byte diagnostic frame and exits 2 without stdout; ABI and I/O failures have separate native exits. Native generic diagnostic codes and order are compared; this does not claim all hosted English context text or private Python object semantics are identical.

## Exact current result

Current production identity is `checkpoints/importer-source-r3/source.json` and the 16 files it lists. `development/build-r3/bundle.json` binds all 37 HIA sources, actual images, receipts, historical B3 compiler and actual packer output. The executable is `development/build-r3/hia-import-legacy-composite`, 7,299,291 bytes, SHA-256 `6ea85c3d4fc14409c40f713836551bc2618b6bda811ca14a0282469a94df9a82`.

All final r3 source and image pins remained unchanged across these completed gates:

| Gate | Result | Recorded elapsed time |
| --- | --- | --- |
| Complete public profile/raw-input panel | 117 / 117 PASS | 30.386812598 s |
| Exact 8 MiB and late-error boundaries | 5 / 5 PASS | 325.586331276 s |
| Actual component protocol controls | 33 / 33 PASS | 0.194115330 s |

The 122 public cases compare the complete returned Core, structured source and report bytes on acceptance, and the first rejection category on refusal. They include 82 previously frozen nominal fixtures explicitly relabelled as the historical schema, supported/unsupported resource profiles, schema/key precedence, malformed JSON/UTF-8/surrogates, depth and byte limits. Newer structured features are not silently granted to the old profile.

The five decisive byte cases use valid declarations within all original language limits. Original canonical input of 8,388,606 bytes becomes exactly 8,388,608 after the rename and succeeds, returning 8,389,875 complete bytes. Inputs of 8,388,607 and 8,388,608 bytes reach the renamed-input error only after the full legacy Core gate. An old lowering error and an old primitive type error each precede that late byte error, as in the retained implementation. The successful response is hashed in complete <=8 MiB SHA updates; no output bytes are omitted or truncated.

Protocol evidence covers actual issued-source projection, complete Core comparison, malformed initialization and ACK correlation, replay and permanent refusal. Short advertised workspaces cannot persist poison and are explicitly a fixed-executor lease-discard responsibility. Private same-pipeline source leases are not external authentication. Fixed-executor syscall failure injection has not been observed.

## Preserved original failures and revisions

`development/build-r1` contains the original actual B3 rejection of a direct two-readbuf entry. The correction uses the established RWW entry with explicit borrow/read and loan.end, without changing the compiler limits. `development/build-r2` and the complete r2 smoke/public results remain intact.

`development/byte-boundaries-r1` preserves the first actual large-input failure: both semantic paths completed, but the r2 importer sent the entire >8 MiB response as one update to the existing bounded SHA kernel. This produced ABI exit 3, not a language refusal or timeout. R3 changes only the importer continuation to hash all bytes in bounded updates; the original SHA kernel, language and compiler limits are unchanged. The full five-case boundary gate and complete 117-case panel were then rerun under new identities on the actual r3 ELF.

`development/protocol-r1` preserves the development harness bytearray/ctypes TypeError after ten passing controls. R2 converted only that test input to immutable bytes; r3 reran all 33 controls against current production. No failed original is overwritten or relabelled as passed.

## Ownership and current limits

The additional RUN_CHILD operation is a fixed same-process context switch selected by HIA. Each child has independent controller, type state, temporary buffers, spool and counters; only the selected immutable source lease is borrowed. On completion, only the successful actual readonly Core mapping is transferred back. Other child mappings and descriptors are released. No fork, exec, schema selection or language lowering occurs in the template. Independent review of this new nested executor and external syscall tracing remain outstanding; prior ordinary-executor review does not automatically cover this extension.

This is an independent development candidate. It is not installed as the default route, is not matching-current cold/full qualification, and does not close whole-stack or source-authoring self-hosting. Python generators, assembly authoring, hosted oracles and existing semantic owners remain available. The historical B3 compiler is byte-bound development provenance, not a new qualification claim. The unchanged B3 compile limits are 10 CPU seconds, 20 wall seconds, 256 MiB address space, 8 MiB stack and the original 1 MiB compiler capacities. Native public case timeout is 180 seconds in these importer panels; no retained, cold or language deadline changed.

## Recovery

The archive preserves this entire overlay, including all source revisions, actual compiler/packer inputs and receipts, emitted executables, original failures, complete raw cases and final success logs. Current immutable external sources, images, compiler, receipts, hosted oracle sources and the frozen 82-document corpus are mapped by `DEPENDENCY_CUSTODY.json` under `dependencies/`. The exact restored baseline commit is `e2f392e5658d3cb2d6867a14b88c6335b5975f96`; the prior full ordinary-driver archive is already held by recovery commit `9be384e9a01096081730c3012ecad773326a323d`.

Every archive member is read back and compared to its original bytes, SHA-256 and mode. No old archive, live peer source or shared branch is modified by sealing.
