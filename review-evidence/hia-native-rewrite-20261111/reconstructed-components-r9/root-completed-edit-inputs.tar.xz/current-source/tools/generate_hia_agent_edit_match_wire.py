"""Exact native snapshot-byte equality after both original canonical gates."""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_apply_graph as graph
CONSTANTS={'COMMAND':int.from_bytes(b'HIAQMC01','little'),'EVENT':int.from_bytes(b'HIAQME01','little'),'BAD':0xfffffffd}
MESSAGES={1:'E_HIA_QUERY: stale or modified edit query',2:'E_HIA_EDIT_BATCH: stale or altered batch query'}
BODY=r'''
def match(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 512:
        return BAD
    if get(w, 32) == 3:
        return BAD
    if get(w, 32) != 0:
        return invalid(w, 1)
    if get(w, 0) != COMMAND or get(w, 8) < 1 or get(w, 8) > 2 or get(w, 16) == 0 or get(w, 24) == 0:
        return invalid(w, 2)
    if length(s) == 0 or length(r) == 0 or length(s) > 1048576 or length(r) > 1048576:
        return invalid(w, 3)
    at = 32
    while at < 512:
        if byte(w, at) != 0:
            return invalid(w, 4)
        at = at + 1
    put(w, 48, length(s))
    put(w, 56, length(r))
    equal = 1
    if length(s) != length(r):
        equal = 0
    at = 0
    while at < length(s) and equal != 0:
        if byte(s, at) != byte(r, at):
            equal = 0
        at = at + 1
    put(w, 32, 2)
    if equal != 0:
        return event(w, 0, 0)
    size = diagnostic(w)
    return event(w, 2, size)

def event(w:mutbuf, action:u64, text:u64) -> u32:
    put(w, 128, EVENT)
    put(w, 136, action)
    put(w, 144, get(w, 16))
    put(w, 152, get(w, 24))
    put(w, 160, get(w, 8))
    put(w, 168, get(w, 48))
    put(w, 176, get(w, 56))
    put(w, 184, get(w, 64))
    put(w, 192, choose(text == 0, 0, 256))
    put(w, 200, text)
    at = 208
    while at < 256:
        put(w, at, 0)
        at = at + 8
    return 256

def invalid(w:mutbuf, reason:u64) -> u32:
    put(w, 32, 3)
    put(w, 64, reason)
    event(w, 3, 0)
    return BAD
'''

def source_program():
    lines=['def diagnostic(w:mutbuf) -> u64:']
    for mode,text in MESSAGES.items():
        lines.append(f'    if get(w, 8) == {mode}:')
        raw=text.encode()
        for index in range(0,len(raw),8):
            chunk=raw[index:index+8]
            if len(chunk)==8:lines.append(f'        put(w, {256+index}, {int.from_bytes(chunk,"little")})')
            else:
                for j,v in enumerate(chunk):lines.append(f'        store(w, {256+index+j}, {v})')
        lines.append(f'        return {len(raw)}')
    lines.append('    return 0')
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
    own=Expand().visit(ast.parse(BODY+'\n'+'\n'.join(lines)+'\n')).body
    helpers={node.name:node for node in ast.parse(graph.source_program()).body}
    tree=ast.Module(body=own+[helpers[n] for n in ('get','put')],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['match']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=shared.CopyBuilder(node,names,signatures,total);builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],'returns':[builder.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_match_wire','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_match_wire.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
