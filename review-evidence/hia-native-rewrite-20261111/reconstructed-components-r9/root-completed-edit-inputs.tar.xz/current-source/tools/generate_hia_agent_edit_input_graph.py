"""Original edit prefix shape/order over immutable issued general Graphs.

Batch application validates every nested selector shape before reconstruction.
Batch preparation checks one selection at a time, so a previous native overlap
refusal precedes a malformed later item. Missing fields stay virtual None (0)
until the common native selection owner performs its original first check.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import hia_agent_edit_source_views as shared
from tools import generate_hia_agent_edit_apply_graph as graph

CONSTANTS={'COMMAND':int.from_bytes(b'HIAQIC01','little'),'STATE':int.from_bytes(b'HIAQIW01','little'),
           'EVENT':int.from_bytes(b'HIAQIE01','little'),'BAD':0xfffffffd,'MAX':(1<<64)-1}
LABELS=('function','block','output','fields','selector','schema','sites','site','query',
        'hepta.hia.edit-batch-query.v2','hepta.hia.edit-batch-query.v3')
SOURCE=r'''
def prefix(s:readbuf, r:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, 8) == 3:
        return BAD
    if get(w, 8) != 0:
        return refuse(w, 1)
    if length(r) != 128 or word(r, 0) != COMMAND or word(r, 16) == 0 or word(r, 24) == 0:
        return refuse(w, 2)
    if word(r, 8) < 1 or word(r, 8) > 3 or graph_shape(s, 0, length(s)) == 0:
        return refuse(w, 3)
    if word(r, 32) == 0 or word(r, 32) > word(s, 16):
        return refuse(w, 4)
    at = 48
    while at < 128:
        if word(r, at) != 0:
            return refuse(w, 5)
        at = at + 8
    if word(r, 8) != 2 and word(r, 40) != 0:
        return refuse(w, 6)
    at = 0
    while at < 1024:
        if byte(w, at) != 0:
            return refuse(w, 7)
        at = at + 1
    put(w, 0, STATE)
    put(w, 8, 1)
    put(w, 16, word(r, 16))
    put(w, 24, word(r, 24))
    put(w, 32, word(r, 8))
    put(w, 40, word(r, 40))
    error = 0
    if word(r, 8) == 1:
        error = single_apply(s, w, word(r, 32))
    elif word(r, 8) == 2:
        error = batch_prepare(s, w, word(r, 32), word(r, 40))
    else:
        error = batch_apply(s, w, word(r, 32))
    if error == MAX:
        return refuse(w, 8)
    put(w, 8, 2)
    put(w, 64, error)
    if error != 0:
        return event(w, 2)
    return event(w, 0)

def selector_shape(s:readbuf, id_:u64) -> u64:
    if gkind(s, id_) != 6 or amount(s, id_) != 3:
        return 0
    if field(s, id_, L_function) == 0 or field(s, id_, L_block) == 0 or field(s, id_, L_output) == 0:
        return 0
    return 1

def emit_selection(s:readbuf, w:mutbuf, id_:u64, fields:u64, index:u64) -> u64:
    put(w, 512 + index * 32, field(s, id_, L_function))
    put(w, 520 + index * 32, field(s, id_, L_block))
    put(w, 528 + index * 32, field(s, id_, L_output))
    put(w, 536 + index * 32, fields)
    return 0

def single_apply(s:readbuf, w:mutbuf, query:u64) -> u64:
    if gkind(s, query) != 6:
        return 1
    selected = field(s, query, L_selector)
    if selector_shape(s, selected) == 0:
        return 2
    emit_selection(s, w, selected, field(s, query, L_fields), 0)
    put(w, 48, 1)
    put(w, 56, 1)
    return 0

def batch_prepare(s:readbuf, w:mutbuf, selections:u64, index:u64) -> u64:
    if gkind(s, selections) != 5 or amount(s, selections) < 1 or amount(s, selections) > 16:
        return 10
    put(w, 48, amount(s, selections))
    if index >= amount(s, selections):
        return MAX
    selected = element(s, selections, index)
    if gkind(s, selected) != 6 or amount(s, selected) != 4:
        return 11
    if field(s, selected, L_function) == 0 or field(s, selected, L_block) == 0 or field(s, selected, L_output) == 0 or field(s, selected, L_fields) == 0:
        return 11
    emit_selection(s, w, selected, field(s, selected, L_fields), 0)
    put(w, 56, 1)
    return 0

def batch_apply(s:readbuf, w:mutbuf, query:u64) -> u64:
    if gkind(s, query) != 6:
        return 20
    schema = field(s, query, L_schema)
    if text_is(s, schema, L_hepta_hia_edit_batch_query_v2) == 0 and text_is(s, schema, L_hepta_hia_edit_batch_query_v3) == 0:
        return 20
    sites = field(s, query, L_sites)
    if gkind(s, sites) != 5 or amount(s, sites) < 1 or amount(s, sites) > 16:
        return 21
    put(w, 48, amount(s, sites))
    index = 0
    while index < amount(s, sites):
        item = element(s, sites, index)
        if gkind(s, item) != 6 or amount(s, item) != 2:
            return 22
        number = field(s, item, L_site)
        nested = field(s, item, L_query)
        if number == 0 or nested == 0 or small_integer(s, number) != index or gkind(s, nested) != 6:
            return 22
        selected = field(s, nested, L_selector)
        if selector_shape(s, selected) == 0:
            return 23
        emit_selection(s, w, selected, field(s, nested, L_fields), index)
        index = index + 1
    put(w, 56, amount(s, sites))
    return 0

def event(w:mutbuf, action:u64) -> u32:
    put(w, 256, EVENT)
    put(w, 264, action)
    put(w, 272, get(w, 16))
    put(w, 280, get(w, 24))
    put(w, 288, get(w, 32))
    put(w, 296, get(w, 48))
    put(w, 304, get(w, 40))
    put(w, 312, 512)
    put(w, 320, get(w, 56) * 32)
    put(w, 328, get(w, 64))
    put(w, 336, get(w, 56))
    put(w, 344, 0)
    put(w, 352, 0)
    put(w, 360, 0)
    put(w, 368, 0)
    put(w, 376, 0)
    return 384

def refuse(w:mutbuf, reason:u64) -> u32:
    put(w, 8, 3)
    put(w, 64, reason)
    event(w, 3)
    return BAD
'''

def source_program():
    labels={}
    for value in LABELS:
        key='L_'+value.replace('.','_').replace('-','_');raw=value.encode()
        assert len(raw)<=32
        labels[key]=[len(raw),*(int.from_bytes(raw[i*8:i*8+8],'little') for i in range(4))]
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
        def visit_Call(self,node):
            node=self.generic_visit(node);args=[]
            for arg in node.args:
                if isinstance(arg,ast.Name) and arg.id in labels:args.extend(ast.Constant(value) for value in labels[arg.id])
                else:args.append(arg)
            node.args=args;return node
    own=Expand().visit(ast.parse(SOURCE)).body
    helpers={node.name:node for node in ast.parse(graph.source_program()).body}
    names=('gkind','amount','element','text_is','field','small_integer','graph_shape','word','get','put')
    tree=ast.Module(body=own+[helpers[name] for name in names],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['prefix']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=shared.CopyBuilder(node,names,signatures,total);builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],'returns':[builder.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_input_graph','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_input_graph.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
