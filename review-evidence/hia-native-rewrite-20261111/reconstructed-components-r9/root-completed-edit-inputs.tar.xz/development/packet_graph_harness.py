"""Actual private typed-tree to GraphLease bridge; no host field decisions."""
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import struct
from hepta.hia_json_preflight_native import NativeHiaJsonImage

MAGIC = lambda value: int.from_bytes(value, 'little')
BAD = 0xfffffffd
CANARY = b'\xe3' * 32

def command(action=1, *, lease=17, request=1, sequence=0):
    return struct.pack('<8Q', MAGIC(b'HIAPGC01'), action, lease, request, sequence, 0, 0, 0)

class Actual:
    def __init__(self, manifest, out):
        self.pins = {}
        def read(path):
            path = Path(path).resolve()
            raw = path.read_bytes()
            if path in self.pins:
                assert raw == self.pins[path]
            self.pins[path] = raw
            return raw
        row = json.loads(read(manifest))
        source, image = read(row['source_path']), read(row['image_path'])
        assert sha256(source).hexdigest() == row['source_sha256']
        assert sha256(image).hexdigest() == row['image_sha256']
        assert row['compiler_sha256'] == '35ee92b7258134b0bdf517448b51cfdef4c191a510af26ae581b81ad2924ee5b'
        self.native = NativeHiaJsonImage(image, row['image_sha256'])
        self.out = Path(out)
        self.out.mkdir(parents=True, exist_ok=False)
        self.log = (self.out / 'entries.jsonl').open('w')
        self.entries = 0
        self.sources = set()

    def call(self, label, source, control, before):
        s = ctypes.create_string_buffer(source + CANARY)
        c = ctypes.create_string_buffer(control + CANARY)
        w = ctypes.create_string_buffer(before + CANARY)
        code = self.native._entry(s, len(source), c, len(control), w, len(before))
        after = ctypes.string_at(w, len(before))
        assert ctypes.string_at(s, len(source) + 32) == source + CANARY
        assert ctypes.string_at(c, len(control) + 32) == control + CANARY
        assert ctypes.string_at(ctypes.addressof(w) + len(before), 32) == CANARY
        self.entries += 1
        prefix = str(self.entries).zfill(6)
        digest = sha256(source).hexdigest()
        if digest not in self.sources:
            (self.out / ('source-' + digest + '.lease')).write_bytes(source)
            self.sources.add(digest)
        for suffix, raw in (('command', control), ('before', before), ('after', after)):
            (self.out / (prefix + '.' + suffix + '.bin')).write_bytes(raw)
        event = struct.unpack_from('<16Q', after, 256) if len(after) >= 384 else None
        row = dict(case=label, entry=self.entries, prefix=prefix, return_code=code,
                   source_sha256=digest, source_bytes=len(source), workspace_bytes=len(before),
                   before_sha256=sha256(before).hexdigest(), after_sha256=sha256(after).hexdigest(),
                   command_sha256=sha256(control).hexdigest(), event=event,
                   full_buffers_saved=True, inputs_and_canaries_unchanged=True)
        self.log.write(json.dumps(row, sort_keys=True) + '\n')
        self.log.flush()
        return code, after

    def run(self, label, source, *, compare=None, request=1):
        control, before = command(request=request), bytes(512)
        while True:
            code, after = self.call(label, source, control, before)
            if compare is not None:
                assert compare(source, control, before) == (code, after)
            assert code == 384, (label, code, struct.unpack_from('<16Q', after, 256))
            event = struct.unpack_from('<16Q', after, 256)
            if event[1] == 0:
                graph = after[event[6]:event[6] + event[7]]
                return graph, after
            assert event[1] == 1 and event[5] > len(after)
            before = after + bytes(event[5] - len(after))
            control = command(2, request=request, sequence=event[4])

    def close(self):
        self.log.close()
        assert all(path.read_bytes() == raw for path, raw in self.pins.items())
        (self.out / 'custody.json').write_text(json.dumps({
            'entries': self.entries, 'source_and_image_unchanged': True,
            'pins': {str(path): sha256(raw).hexdigest() for path, raw in self.pins.items()},
        }, indent=2, sort_keys=True) + '\n')

def decode_graph_reference(graph):
    """Independent inspection only, never used by an actual forwarding path."""
    h = struct.unpack_from('<8Q', graph)
    magic, identity, nodes, root, edges, scalar, total, reserved = h
    assert magic == MAGIC(b'HIAGRF01') and identity and total == len(graph) and not reserved
    assert total == 64 + 64 * nodes + 8 * edges + scalar
    scalar_base = total - scalar
    def value(ident):
        assert 1 <= ident <= nodes
        kind, offset, size, first, arity, obj, aux, zero = struct.unpack_from('<8Q', graph, 64 * ident)
        assert zero == 0
        if kind in (5, 6):
            assert obj == ident and offset == size == aux == 0
            count = arity * (2 if kind == 6 else 1)
            assert first <= edges and count <= edges - first
            children = [value(struct.unpack_from('<Q', graph, 64 + 64 * nodes + 8 * (first + i))[0]) for i in range(count)]
            return children if kind == 5 else dict(zip(children[0::2], children[1::2]))
        assert first == arity == obj == 0
        if kind == 0:
            assert offset == size == aux == 0
            return None
        if kind == 1:
            assert offset == size == 0 and aux in (0, 1)
            return bool(aux)
        if kind == 2 and size == 0:
            assert scalar_base <= offset <= total and aux == 0
            return 0
        assert scalar_base <= offset <= total and size <= total - offset
        raw = graph[offset:offset + size]
        if kind == 2:
            assert aux in (0, 1) and raw[-1] != 0
            return int.from_bytes(raw, 'little') * (-1 if aux else 1)
        assert kind == 4
        text = raw.decode('utf-8')
        assert len(text) == aux
        return text
    return value(root)
