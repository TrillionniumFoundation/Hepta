"""Actual prefix owners against retained entry points stopped at reconstruction.

The oracle invokes the unchanged old entry, replacing only its later prepared-
query call with a sentinel. Native forwarding forbids all those old entries.
Whole prepare-batch controls additionally run actual selection/facts/query/wire
and overlap owners, preserving when each later selection may be inspected.
"""
from contextlib import ExitStack
import copy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program
from hepta.hia_program_tools import bounded_json_wire,decode_json
from hepta import hia_edit_query,hia_edit_batch,hia_program,hia_program_tools,hia_instruction_policy_native,hia_json_decode_native
from hepta import hia_composite_function_tokens
from hepta.hia_core_admission_native import NativeCoreAdmission
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans,selected
from tests.test_hia_program import b,c,f,i,ret
from packet_graph_harness import Actual,BAD
from facts_harness import vm_call
from input_graph_harness import command,run,ERRORS
from selection_harness import command as select_command,run as select_run,ERRORS as SELECT_ERRORS
from batch_graph_harness import command as batch_command,run as batch_run
from graph_merge_harness import merge
from native_query_pipeline import NativeQueryPipeline
from core_packet_transport import CorePacketTransport

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'input-graph-native-r2';OUT.mkdir(exist_ok=False)
native=Actual(DEV/'input-graph-source-and-compile-r1/agent-edit-input-graph.manifest.json',OUT/'prefix')
selector=Actual(DEV/'selection-source-and-compile-r3/agent-edit-selection.manifest.json',OUT/'selector')
batch=Actual(DEV/'batch-graph-source-and-compile-r1/agent-edit-batch-graph.manifest.json',OUT/'batch')
merger=Actual(DEV/'graph-merge-source-and-compile-r1/graph-merge.manifest.json',OUT/'merge')
codec=CorePacketTransport(OUT/'core-codec');pipeline=NativeQueryPipeline(OUT/'queries')
image=(DEV/'apply-graph-native-r1/core_admission.image.bin').read_bytes();admission=NativeCoreAdmission(image,sha256(image).hexdigest())
(OUT/'core_admission.image.bin').write_bytes(image)
checked=assemble_program((DEV/'input-graph-source-and-compile-r1/source/examples/hia_bootstrap/agent_edit_input_graph.hiaasm').read_bytes())
spec=importlib.util.spec_from_file_location('input_prefix_native_capture',DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py')
gm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gm;spec.loader.exec_module(gm)
pins={p:p.read_bytes() for p in (Path(__file__),DEV/'input_graph_harness.py',DEV/'selection_harness.py',DEV/'core_packet_transport.py',
      DEV/'native_query_pipeline.py',ROOT/'hepta/hia_edit_query.py',ROOT/'hepta/hia_edit_batch.py')}
cases,whole_cases,controls=[],[],[];cached={};started=time.monotonic_ns();summary=dict(status='INCOMPLETE')
original=verify_program(fixture())

class ReachedReconstruction(Exception):pass
def oracle(mode,value,index):
    reached=[];error=None;prior=[0]
    real_prepare=hia_edit_query.prepare_edit
    def single(document,**selection):
        if mode==2 and prior[0]<index:
            prior[0]+=1;return real_prepare(document,**selection)
        reached.append(selection);raise ReachedReconstruction()
    def all_sites(document,selections):
        reached.extend(selections);raise ReachedReconstruction()
    try:
        if mode==1:
            with patch.object(hia_edit_query,'prepare_edit',new=single):hia_edit_query.apply_edit(original,value,{})
        elif mode==2:
            with patch.object(hia_edit_batch,'prepare_edit',new=single):hia_edit_batch.prepare_batch(original,value)
        else:
            with patch.object(hia_edit_batch,'prepare_batch',new=all_sites):hia_edit_batch.apply_batch(original,bounded_json_wire(value,1<<20),{})
    except ReachedReconstruction:pass
    except Exception as exc:error=(type(exc).__name__,str(exc))
    assert bool(reached)!=(error is not None)
    return reached,error

def graph_value(graph,ident,memo=None):
    """Independent observation only, never called by native forwarding."""
    if ident==0:return None
    if memo is None:memo={}
    if ident in memo:return memo[ident]
    kind,offset,size,first,count,obj,aux,zero=struct.unpack_from('<8Q',graph,ident*64)
    if kind==0:return None
    if kind==1:return bool(aux)
    if kind==2:return int.from_bytes(graph[offset:offset+size],'little')*(-1 if aux else 1)
    if kind==3:return struct.unpack('<d',graph[offset:offset+size])[0]
    if kind==4:return graph[offset:offset+size].decode('utf8','surrogatepass')
    if kind==9:return graph[offset:offset+size]
    assert kind in (5,6,7),kind
    nodes=struct.unpack_from('<Q',graph,16)[0];child_count=count*(2 if kind==6 else 1)
    children=struct.unpack_from('<'+'Q'*child_count,graph,64+nodes*64+first*8)
    if kind==6:
        result={};memo[ident]=result
        for at in range(0,len(children),2):result[graph_value(graph,children[at],memo)]=graph_value(graph,children[at+1],memo)
    else:
        result=[];memo[ident]=result;result.extend(graph_value(graph,item,memo) for item in children)
        if kind==7:result=tuple(result);memo[ident]=result
    return result

def forbidden(*args,**kwargs):raise AssertionError('host edit policy/decoder entered actual prefix/query path')
def guards():
    stack=ExitStack()
    for owner,name in ((hia_program,'verify_program'),(hia_edit_query,'prepare_edit'),(hia_edit_query,'apply_edit'),
                       (hia_edit_batch,'prepare_batch'),(hia_edit_batch,'apply_batch'),
                       (hia_edit_query,'_reference_edit_slice'),(hia_edit_query,'_cfg_downstream_slice'),
                       (hia_program_tools,'bounded_json_wire'),(hia_instruction_policy_native,'transport'),
                       (hia_composite_function_tokens,'detached_packet_index'),(hia_composite_function_tokens.ObjectTokenDecoder,'feed'),
                       (hia_json_decode_native,'materialize'),(json,'loads')):
        stack.enter_context(patch.object(owner,name,new=forbidden))
    return stack

def prefix_case(label,mode,value,index=0,vm=False):
    # Mode 3's prerequisite is the already bounded, integer-decoded value.
    # Its raw gate is a separate owner and is not claimed by this component.
    if mode==3:value=decode_json(bounded_json_wire(value,1<<20))
    expected,error=oracle(mode,value,index);graph=gm.capture(value);ctl=command(graph,mode,index,len(cases)+1)
    with guards():event,roots,after=run(native.call,label,graph,ctl)
    if error:
        assert event[1]==2 and error==('HIAEditRejected',ERRORS[event[9]]),(label,event,error)
    else:
        assert event[1]==0 and len(roots)==len(expected),(label,event,expected)
        observed=[dict(zip(('function','block','output','fields'),[graph_value(graph,r) for r in row])) for row in roots]
        assert observed==expected,(label,observed,expected)
    if vm:assert vm_call(checked,graph,ctl,bytes(1024))==(384,after)
    cases.append(dict(case=label,mode=mode,index=index,event=event,expected_error=error,
                      expected_reconstruction_calls=len(expected),full_workspace_VM_pair=vm,host_owners_disabled=True))
    return graph,ctl,after

def whole_batch(label,document,value,*,from_query=False):
    admitted=verify_program(document);wire=admitted.canonical_bytes;expected=None;error=None
    if from_query:
        value=decode_json(bounded_json_wire(value,1<<20))
        # Capture the complete retained reconstruction frontier, then let the
        # unchanged old prepare_batch decide all later selection/overlap order.
        expected_selections,prefix_error=oracle(3,value,0)
        if prefix_error:error=prefix_error
        else:
            try:expected=hia_edit_batch.prepare_batch(admitted,expected_selections)
            except Exception as exc:error=(type(exc).__name__,str(exc))
    else:
        try:expected=hia_edit_batch.prepare_batch(admitted,value)
        except Exception as exc:error=(type(exc).__name__,str(exc))
    expected_wire=bounded_json_wire(expected,1<<20) if expected is not None else None
    graph=gm.capture(value);case_dir=OUT/('whole-'+str(len(whole_cases)));case_dir.mkdir();(case_dir/'base.json').write_bytes(wire)
    count_queries=pipeline.requests;prefix_calls=0;overlap_checks=0;actual_error=None;last_graph=None;query_roots=[]
    with guards():
        key=sha256(wire).hexdigest()
        if key not in cached:
            assert admission.status(wire)==0
            raw,source=codec.decode(label,wire);cached[key]=(source,pipeline.hasher.digest(wire))
        source,digest=cached[key]
        e,selectors,unused=run(native.call,label+'-input-prefix',graph,command(graph,3 if from_query else 2,request=len(whole_cases)+1000));prefix_calls+=1
        if e[1]==2:actual_error=('HIAEditRejected',ERRORS[e[9]])
        else:
            count=e[5]
            for at in range(count):
                if from_query:roots=selectors[at]
                else:
                    if at:
                        e,selectors,unused=run(native.call,label+'-selection-'+str(at),graph,command(graph,2,at,request=len(whole_cases)+1000+at));prefix_calls+=1
                        if e[1]==2:actual_error=('HIAEditRejected',ERRORS[e[9]]);break
                    roots=selectors[0]
                se,sw=select_run(selector.call,label+'-resolve-'+str(at),source,select_command(graph,roots,request=pipeline.requests+1))
                if se[1]==2:actual_error=('HIAEditRejected',SELECT_ERRORS[se[8]]);break
                packet=sw[se[6]:se[6]+se[7]]
                try:qgraph,qwire=pipeline.prepare(label+'-query-'+str(at),packet,digest,digest)
                except Exception as exc:actual_error=(type(exc).__name__,str(exc));break
                if last_graph is None:last_graph=qgraph;query_roots=[struct.unpack_from('<Q',qgraph,24)[0]]
                else:
                    before_nodes=struct.unpack_from('<Q',last_graph,16)[0]
                    last_graph,unused=merge(merger.call,label+'-merge-'+str(at),last_graph,qgraph,request=pipeline.requests)
                    query_roots=[v+1 for v in query_roots]+[struct.unpack_from('<Q',qgraph,24)[0]+before_nodes+1]
                be,bw=batch_run(batch.call,label+'-overlap-'+str(at),last_graph,batch_command(query_roots,0,request=pipeline.requests));overlap_checks+=1
                if be[1]==2:
                    assert be[8]==1;actual_error=('HIAEditRejected','E_HIA_EDIT_BATCH: selections overlap one instruction');break
            if actual_error is None:
                be,bw=batch_run(batch.call,label+'-final',last_graph,batch_command(query_roots,1,request=pipeline.requests+5000))
                assert be[1]==0
                result=bw[be[6]:be[6]+be[7]]
                final=pipeline.wire.serialize_graph(result,1<<20,case=label+'-complete-batch')['wire']
                assert expected_wire==final and error is None
                (case_dir/'actual-batch.json').write_bytes(final);(case_dir/'expected-batch.json').write_bytes(expected_wire)
        assert actual_error==error,(label,actual_error,error)
    whole_cases.append(dict(case=label,actual_prefix_calls=prefix_calls,actual_single_queries=pipeline.requests-count_queries,
                           actual_overlap_checks=overlap_checks,exact_original_error=error,complete_batch_wire_equal=error is None,
                           all_host_owners_disabled=True))

try:
    single=hia_edit_query.prepare_edit(original,function='calculate',block='entry',output='y',fields=['op'])
    selected0=dict(function='calculate',block='entry',output='one',fields=['attrs'])
    selected1=dict(function='calculate',block='entry',output='y',fields=['op'])
    for n,v in enumerate((None,False,0,'query',b'query',[],(),{})):
        prefix_case('single-root-'+str(n),1,v)
    for name in ('selector','fields','context','schema'):
        value=copy.deepcopy(single);del value[name];prefix_case('single-missing-'+name,1,value)
    for n,value in enumerate((None,False,0,'x',[],{},dict(single['selector'],extra=0))):
        prefix_case('single-selector-shape-'+str(n),1,dict(single,selector=value))
    for name in ('function','block','output'):
        value=copy.deepcopy(single);del value['selector'][name];prefix_case('single-selector-missing-'+name,1,value)
    for n,value in enumerate((None,0,[],['op'],('attrs','args'),'op')):
        prefix_case('single-fields-retained-'+str(n),1,dict(single,fields=value),vm=n in (0,4))
    for n,value in enumerate((None,False,0,'selections',{},(),[],[selected0]*17)):
        prefix_case('batch-selection-root-'+str(n),2,value)
    for n,value in enumerate((None,False,0,[],{},dict(selected0,extra=0))):prefix_case('selection-shape-'+str(n),2,[value])
    for key in selected0:
        value=dict(selected0);del value[key];prefix_case('selection-missing-'+key,2,[value])
    prefix_case('valid-prefix-before-malformed-next',2,[selected0,{}],vm=True)
    prefix_case('malformed-next-after-valid-prefix',2,[selected0,{}],index=1)
    prefix_case('second-valid-after-valid-prefix',2,[selected0,selected1],index=1)
    base_batch=hia_edit_batch.prepare_batch(original,[selected0,selected1])
    for n,value in enumerate((None,False,0,'query',[],{},dict(base_batch,schema='bad'),dict(base_batch,schema=None))):
        prefix_case('apply-batch-root-schema-'+str(n),3,value)
    for n,value in enumerate((None,False,0,'sites',{},[],[base_batch['sites'][0]]*17)):
        prefix_case('apply-batch-sites-'+str(n),3,dict(base_batch,sites=value))
    for n,item in enumerate((None,False,0,[],{},dict(base_batch['sites'][0],extra=0),{'site':0},{'query':single},
                             {'site':True,'query':single},{'site':-1,'query':single},{'site':1,'query':single},
                             {'site':1<<200,'query':single},{'site':'0','query':single},{'site':0,'query':None})):
        prefix_case('apply-batch-site-item-'+str(n),3,dict(base_batch,sites=[item]))
    for n,nested in enumerate(({},dict(single,selector=None),dict(single,selector={}),dict(single,selector=dict(single['selector'],extra=0)))):
        prefix_case('apply-batch-nested-selector-'+str(n),3,dict(base_batch,sites=[{'site':0,'query':nested}]))
    value=copy.deepcopy(base_batch);del value['sites'][0]['query']['fields'];prefix_case('apply-batch-fields-absent',3,value,vm=True)
    value=copy.deepcopy(base_batch);value['sites'][0]['query']['fields']=[];value['sites'][1]['query']['selector']={}
    prefix_case('late-nested-shape-before-early-field-policy',3,value,vm=True)
    # All sixteen output records occupy exactly the available 512-byte area.
    value=copy.deepcopy(base_batch);value['sites']=[{'site':n,'query':copy.deepcopy(single)} for n in range(16)]
    graph,ctl,completed=prefix_case('all-16-extracted-before-reconstruction',3,value,vm=True)
    whole_batch('ordered-two',fixture(),[selected0,selected1])
    whole_batch('reversed-two',fixture(),[selected1,selected0])
    whole_batch('overlap-before-late-invalid-shape',fixture(),[selected0,selected0,{}])
    whole_batch('overlap-before-late-invalid-fields',fixture(),[selected0,selected0,dict(selected1,fields=[])])
    whole_batch('earlier-fields-before-later-shape',fixture(),[dict(selected0,fields=[]),{}])
    whole_batch('later-shape-after-complete-first-query',fixture(),[selected0,{}])
    source=loans();whole_batch('loans-two',source,[selected('reader'),selected('writer')])
    source=loans();source['functions'][0]['blocks'][0]['ops'][1]=i('buffer.try_new',['size'],[('a','buffer'),('ok','bool')])
    whole_batch('multioutput-overlap-before-bad-next',source,[selected('a'),selected('ok'),{}])
    source={'schema':'hepta.hia.program.v8','module':'prefix16','functions':[
        f('work',[],['u32'],[],[b('entry',[],[c('k'+str(n),'u32',n) for n in range(16)],ret('k15'))])]}
    selections=[dict(function='work',block='entry',output='k'+str(n),fields=['attrs']) for n in range(16)]
    whole_batch('all-16-native-prepared',source,selections)
    whole_batch('all-extracted-valid-reconstruction',fixture(),base_batch,from_query=True)
    value=copy.deepcopy(base_batch);value['sites'][0]['query']['fields']=[];value['sites'][1]['query']['selector']={}
    whole_batch('all-shapes-before-any-prepare',fixture(),value,from_query=True)
    value=copy.deepcopy(base_batch);del value['sites'][0]['query']['fields']
    whole_batch('missing-fields-deferred-to-common-selection',fixture(),value,from_query=True)
    for label,a,cnt,before in (
        ('empty-command',graph,b'',bytes(1024)),('dirty-initial',graph,ctl,bytes(1023)+b'!'),
        ('replay-complete',graph,ctl,completed),('reserved-command',graph,ctl[:48]+struct.pack('<Q',1)+ctl[56:],bytes(1024)),
        ('invalid-mode',graph,ctl[:8]+bytes(8)+ctl[16:],bytes(1024)),('zero-root',graph,ctl[:32]+bytes(8)+ctl[40:],bytes(1024)),
        ('invalid-graph-header',b'\0'+graph[1:],ctl,bytes(1024)),('short-workspace',graph,ctl,bytes(1023))):
        code,poisoned=native.call(label,a,cnt,before);assert code==BAD
        if len(before)>=1024:
            again,retained=native.call(label+'-permanent',graph,ctl,poisoned);assert again==BAD and retained==poisoned
        controls.append(dict(case=label,refused=True,permanent_poison=len(before)>=1024))
    summary.update(status='PASS')
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    native.close();selector.close();batch.close();merger.close();codec.close();pipeline.close()
    summary.update(scope='DEVELOPMENT_PREFIX_AND_COMPLETE_BATCH_PREPARE_NOT_PUBLIC_DECODE_OR_FIXED_DRIVER',
                   cases=cases,whole_cases=whole_cases,private_controls=controls,actual_prefix_entries=native.entries,
                   actual_selector_entries=selector.entries,actual_batch_entries=batch.entries,actual_merge_entries=merger.entries,
                   actual_codec_entries=codec.entries,actual_native_queries=pipeline.requests,
                   actual_facts_entries=pipeline.facts.entries,actual_query_entries=pipeline.query.entries,
                   actual_packet_graph_entries=pipeline.bridge.entries,actual_issuer_entries=pipeline.issuer.entries,
                   actual_wire_entries=pipeline.wire.entries,elapsed_ns=time.monotonic_ns()-started,
                   all_pins_unchanged=all(p.read_bytes()==raw for p,raw in pins.items()),
                   pins={str(p):sha256(raw).hexdigest() for p,raw in pins.items()},whole_stack_closed=False)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','whole_cases','private_controls','pins')},sort_keys=True),flush=True)
    assert summary['all_pins_unchanged']
