"""Execute caller input-order VM controls with actual native peers, then B3."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import traceback
from hepta.hia_agent_assembly import assemble_program,render_assembly
from hepta.hia_program_tools import bounded_json_wire,decode_json
from tools.generate_hia_agent_edit_bounded_input import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from bounded_input_harness import Evidence,Peers,command,run

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'bounded-input-source-and-compile-r3';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_bounded_input.py',ROOT/'tools/generate_hia_agent_edit_query_packet.py',
       ROOT/'tools/generate_hia_agent_edit_apply_graph.py',ROOT/'tools/generate_hia_graph_merge.py',
       ROOT/'tools/hia_agent_edit_source_views.py',ROOT/'examples/hia_bootstrap/agent_edit_bounded_input.hiaasm',
       COMPILER,Path(__file__),DEV/'bounded_input_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
summary=dict(status='INCOMPLETE',scope='DEVELOPMENT_PRIVATE_CALLER_GATE_NOT_PUBLIC_CAPTURE_OR_FIXED_EXECUTOR')
started=time.monotonic_ns();peers=Peers(OUT/'peers');evidence=Evidence(OUT/'vm');observations=[]
try:
    doc=document();source=frozen[paths[5]];assert render_assembly(doc).encode()==source
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    checked=assemble_program(source)
    def call(label,a,b,before):
        code,after=vm_call(checked,a,b,before);evidence.record(label,a,b,before,after,code)
        return code,after
    cases=[
        ('raw-single',1,b'{"op":"int.add.wrap"}'),
        ('object-single',1,{'op':'int.add.wrap'}),
        ('batch-query-null',2,'null'),
        ('object-batch-response',3,{'edits':[]}),
        ('single-surrogate-character',1,'水\ud800ok'),
        ('single-surrogate-range',1,'😀\ud800\udfff'),
        ('batch-surrogate',2,'水\ud800'),
        ('float-query-comparison-wire',4,{'a':1.25}),
        ('prepared-surrogate',5,{'a':'\ud800'}),
    ]
    for n,(label,policy,value) in enumerate(cases):
        graph=peers.wm.capture(value);expected=None;raw=None;error=None;domain=1
        try:
            if policy>=4:raw=bounded_json_wire(value,1<<20)
            else:
                maximum={1:16384,2:1<<20,3:65536}[policy]
                if type(value) is str:raw=value.encode()
                elif type(value) is bytes:raw=value
                else:raw=bounded_json_wire(value,maximum)
                expected=decode_json(raw)
        except Exception as exc:
            error=str(exc)
            if policy in (2,3):error='E_HIA_EDIT_BATCH: invalid '+('query' if policy==2 else 'response')
            elif policy==4:error='E_HIA_QUERY: query is not canonical JSON'
            elif type(exc).__name__=='UnicodeEncodeError':domain=2
        result=run(call,peers,label,graph,command(graph,policy,request=n+1))
        assert result['error']==error,(label,result['error'],error,result['event'],result['result'])
        if error is None:
            assert result['raw']==raw
            if policy<4:
                expected_graph=peers.wm.capture(expected,lease=101)
                assert peers.dm.ag.shape(result['graph'])==peers.dm.ag.shape(expected_graph)
            else:assert result['graph']==b''
        else:assert result['result'][2]==domain
        observations.append(dict(case=label,event=result['event'],result=result['result'],error=error,actual_peer_kinds=result['peers'],entries=result['entries']))
    compiled,receipt=compile_stage(OUT,'agent-edit-bounded-input',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-bounded-input-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_bounded_input.hiaasm'),source_sha256=sha256(source).hexdigest(),image_path=str(compiled),image_sha256=sha256(compiled.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-bounded-input.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=observations,independent_VM_entries=evidence.entries,
                   actual_wire_entries=peers.wire.entries,actual_decode_entries=peers.decode.entries,receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc),independent_VM_cases=observations);traceback.print_exc();raise
finally:
    peers.close();evidence.close()
    summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
