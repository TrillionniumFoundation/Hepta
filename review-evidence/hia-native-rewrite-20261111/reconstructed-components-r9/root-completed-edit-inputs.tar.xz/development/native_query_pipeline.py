"""Development-only mechanical wiring of actual native complete query owners.

Input capture, full native base admission and input/base digest provenance are
the caller's prerequisite. This class is not the production public coordinator.
"""
from hashlib import sha256
import importlib.util
from pathlib import Path
import struct
import sys
from hepta.hia_agent_slice_native import NativeAgentSlice
from hepta.hia_json_canonical_native import NativeJsonCanonicalizer
from hepta.hia_sha256_native import NativeSha256
from facts_harness import ActualFacts, lease, MAGIC
from packet_graph_harness import Actual as ActualBridge

DEV=Path(__file__).resolve().parent

class NativeQueryPipeline:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False)
        self.facts=ActualFacts(DEV/'facts-source-and-compile-r1/agent-edit-facts.manifest.json',self.out/'facts')
        self.query=ActualFacts(DEV/'query-source-and-compile-r2/agent-edit-query-packet.manifest.json',self.out/'query')
        self.bridge=ActualBridge(DEV/'packet-graph-source-and-compile-r2/packet-graph.manifest.json',self.out/'bridge')
        def module(name,path):
            spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
            sys.modules[name]=m;spec.loader.exec_module(m);return m
        im=module('batch_native_query_packet_issuer',DEV.parent/'native-composite-core-final-recovery-next/dependencies/packet-issuer/tests/test_hia_composite_packet_json.py')
        gm=module('batch_native_query_graph_wire',DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py')
        self.issuer=im.ActualPacketJson(self.out/'issuer');self.wire=gm.Actual(self.out/'wire')
        for filename,attribute,typ in (
            (DEV/'facts-native-r3/agent-slice.image.bin','slice',NativeAgentSlice),
            (DEV/'query-native-r2/json_canonical.image.bin','canonical',NativeJsonCanonicalizer),
            (DEV/'query-native-r2/sha256.image.bin','hasher',NativeSha256)):
            raw=filename.read_bytes();setattr(self,attribute,typ(raw,sha256(raw).hexdigest()))
        self.requests=0

    def encode(self,label,raw):
        code,header,wire,index,state=self.issuer.encode(label,raw)
        assert code==64+len(wire) and header[5]==len(raw)
        return wire,index

    def prepare(self,label,source_packet,base_digest,input_digest):
        self.requests+=1
        unused,index=self.encode(label+'-source',source_packet)
        source=lease(source_packet,index)
        code,event,state=self.facts.run(label,source,request=self.requests)
        assert code==384 and event[1]==0,(label,code,event)
        fact=state[event[6]:event[6]+event[7]]
        sliced=self.slice.run(fact)
        at=event[10]-(1<<63);size=16+struct.unpack_from('<Q',source_packet,at+8)[0]
        opwire,unused=self.encode(label+'-operation',source_packet[at:at+size])
        opwire=self.canonical.canonicalize(opwire,max_nodes=262144,max_depth=64)
        digest=self.hasher.digest(opwire)
        control=(struct.pack('<16Q',MAGIC(b'HIAQQC01'),1,73,self.requests,0,len(fact),len(sliced),
                    *event[8:11],event[11],event[12],event[13],0,0,0)
                 +base_digest+input_digest+digest+bytes(32)+fact+sliced)
        before=bytes(1024)
        while True:
            code,after=self.query.call(label,control,source,before)
            qevent=struct.unpack_from('<16Q',after,256)
            assert code==384,(label,code,qevent)
            if qevent[1]==0:break
            assert qevent[1]==1 and qevent[5]>len(after)
            before=after+bytes(qevent[5]-len(after))
            control=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',qevent[4])+control[40:]
        packet=after[qevent[6]:qevent[6]+qevent[7]]
        unused,index=self.encode(label+'-query',packet)
        graph,unused=self.bridge.run(label,lease(packet,index),request=self.requests)
        wire=self.wire.serialize_graph(graph,1<<20,case=label)['wire']
        return graph,wire

    def close(self):
        self.facts.close();self.query.close();self.bridge.close();self.issuer.close();self.wire.close()
