"""Mechanical actual native decoder/codec/index transport for admitted Core.

The caller owns actual complete Core admission and canonical byte provenance.
No Python JSON decoder, integer materializer, or typed-value encoder is used.
Dynamic capacities below are exact storage bounds from actual immutable headers;
they add no semantic quota. This is a development executor, not a public driver.
"""
import ctypes
from hashlib import sha256
import json
from pathlib import Path
import struct
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_json_decode_native import arena_sizes
from facts_harness import lease

DEV=Path(__file__).resolve().parent
MAGIC=lambda value:int.from_bytes(value,'little')
CANARY=b'\xcd'*32

class CorePacketTransport:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False)
        self.pins={};self.entries={24:0,25:0,2:0};self.objects={};self.serial=0
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes()
            if path in self.pins:assert self.pins[path]==raw
            self.pins[path]=raw;return raw
        bundle=DEV.parent/'native-composite-driver-reconstructed/development/publication-bundle-r2/bundle.json'
        manifest=json.loads(read(bundle));self.images={};rows={}
        assert manifest['status']=='PASS'
        for role in (24,25,2):
            row=manifest['components'][str(role)]
            source=read(row['source_path']);expected=read(row['expected_source_path']);image=read(row['image_path'])
            receipt=json.loads(read(row['receipt_path']))
            assert source==expected and sha256(source).hexdigest()==row['source_sha256']
            assert sha256(image).hexdigest()==row['image_sha256']
            assert row['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
            assert receipt['input_sha256']==row['source_sha256'] and receipt['produced_sha256']==row['image_sha256']
            assert receipt['artifact_sha256']==row['compiler_sha256']
            self.images[role]=NativeHiaJsonImage(image,row['image_sha256']);rows[str(role)]=row
            (self.out/(str(role)+'.source.hiaasm')).write_bytes(source);(self.out/(str(role)+'.image.bin')).write_bytes(image)
        (self.out/'selected-components.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
        (self.out/'objects').mkdir();self.log=(self.out/'entries.jsonl').open('w')

    def save(self,raw):
        digest=sha256(raw).hexdigest()
        if digest not in self.objects:
            (self.out/'objects'/digest).write_bytes(raw);self.objects[digest]=len(raw)
        return digest

    def call(self,label,role,first,second,before):
        a=ctypes.create_string_buffer(first+CANARY);b=ctypes.create_string_buffer(second+CANARY);w=ctypes.create_string_buffer(before+CANARY)
        result=int(self.images[role]._entry(a,len(first),b,len(second),w,len(before)))
        b_after=ctypes.string_at(b,len(second));w_after=ctypes.string_at(w,len(before))
        assert ctypes.string_at(a,len(first)+32)==first+CANARY
        assert ctypes.string_at(ctypes.addressof(b)+len(second),32)==CANARY
        assert ctypes.string_at(ctypes.addressof(w)+len(before),32)==CANARY
        if role==25:assert b_after==second
        self.entries[role]+=1;self.serial+=1
        row=dict(entry=self.serial,case=label,role=role,result=result,first=self.save(first),
                 second_before=self.save(second),second_after=self.save(b_after),
                 workspace_before=self.save(before),workspace_after=self.save(w_after),
                 full_buffers_saved=True,readonly_inputs_and_canaries_unchanged=True)
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
        return result,b_after,w_after

    def decode(self,label,wire,digits=4300):
        assert len(wire)<=8<<20
        out_size,work_size=arena_sizes(len(wire),262144,64)
        work=bytearray(work_size);struct.pack_into('<2Q',work,48,262144,64)
        code,out,unused=self.call(label+'-decoder',24,wire,bytes(out_size),bytes(work))
        assert 64<=code<=out_size,(label,code)
        arena=out[:code];count=struct.unpack_from('<Q',arena,8)[0]
        slots=2
        while slots<count*2:slots*=2
        capacity=64+49*count+len(wire)+slots*8
        work=struct.pack('<8Q',MAGIC(b'HIAJPK01'),digits,0,0,0,0,0,0)+bytes(capacity-64)
        code,unchanged,result=self.call(label+'-codec',25,arena,wire,work)
        header=struct.unpack_from('<8Q',result)
        assert 80<=code<=capacity and header==(MAGIC(b'HIAJPK01'),0,64,code-64,count,len(wire),0,digits),(label,code,header)
        packet=result[64:code]
        encoded,index=self.issue(label+'-issuer',packet)
        assert encoded==wire,(label,'canonical admitted Core must retain the exact canonical wire')
        return packet,lease(packet,index)

    def issue(self,label,packet):
        n=len(packet);assert 16<=n<=64<<20
        slots=2
        while slots<(n>>5)*2:slots*=2
        bitmap_at=128+slots*16;bitmap_bytes=(n+7)//8
        stack=(bitmap_at+bitmap_bytes+7)&~7;capacity=stack+(n//24+1)*32
        work=struct.pack('<16Q',MAGIC(b'HIAPJS01'),*([0]*15))+bytes(capacity-128)
        code,out,after=self.call(label,2,packet,bytes(64+6*n),work)
        header=struct.unpack_from('<8Q',out)
        assert 64<=code<=len(out) and header[:4]==(MAGIC(b'HIAPJS01'),0,64,code-64),(label,code,header)
        assert header[4]>0 and header[5:]==(n,bitmap_at,bitmap_bytes)
        return out[64:code],after[bitmap_at:bitmap_at+bitmap_bytes]

    def close(self):
        self.log.close();assert all(p.read_bytes()==raw for p,raw in self.pins.items())
        (self.out/'custody.json').write_text(json.dumps(dict(entries=self.entries,pins={str(p):sha256(raw).hexdigest() for p,raw in self.pins.items()},
            source_before_after_equal=True,all_actual_entry_buffers_saved=True,objects=self.objects,
            scope='DEVELOPMENT_NATIVE_INTEGER_CODEC_OF_ALREADY_ADMITTED_CORE_NOT_PUBLIC_ADMISSION'),indent=2,sort_keys=True)+'\n')

