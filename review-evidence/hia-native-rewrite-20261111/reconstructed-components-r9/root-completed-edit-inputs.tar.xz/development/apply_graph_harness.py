"""Mechanical calls for private native apply planning; no public admission."""
import struct
import ctypes
from packet_graph_harness import Actual, MAGIC

ERRORS = {
    1: 'E_HIA_QUERY: response may replace only the selected instruction fields',
    2: 'E_HIA_EDIT_BATCH: response requires exactly edits',
    3: 'E_HIA_EDIT_BATCH: every selected site must occur exactly once',
    4: 'E_HIA_EDIT_BATCH: an edit requires exactly site and changes',
    5: 'E_HIA_EDIT_BATCH: duplicate or invalid site',
    6: 'E_HIA_EDIT_BATCH: changes exceed selected fields',
}

def command(mode, roots, response_bytes, query_hash, response_hash, *, action=1, request=1, sequence=0):
    assert len(query_hash) == len(response_hash) == 32
    return (struct.pack('<16Q', MAGIC(b'HIAQAC01'), action, 43, request, sequence, mode,
                        *roots, response_bytes, *([0] * 6)) + query_hash + response_hash)

def run(call, label, source, control, compare=None):
    before = bytes(1024)
    while True:
        code, after = call(label, source, control, before)
        if compare is not None:
            assert compare(source, control, before) == (code, after)
        event = struct.unpack_from('<16Q', after, 256)
        assert code == 384, (label, code, event)
        assert event[0] == MAGIC(b'HIAQAE01')
        if event[1] != 1:
            return event, after
        assert event[5] > len(after)
        before = after + bytes(event[5] - len(after))
        control = control[:8] + struct.pack('<Q', 2) + control[16:32] + struct.pack('<Q', event[4]) + control[40:]

def triple_roots_reference(graph):
    """Oracle fixture root decomposition, not used by the production driver."""
    nodes, root = struct.unpack_from('<2Q', graph, 16)
    at = root * 64
    assert struct.unpack_from('<Q', graph, at)[0] == 5
    first, count = struct.unpack_from('<2Q', graph, at + 24)
    assert count == 3
    return struct.unpack_from('<3Q', graph, 64 + nodes * 64 + first * 8)

def serialize_root(wire, source, root, maximum, label):
    """Replay native service events, choosing a native-issued root ID only."""
    lease = struct.unpack_from('<Q', source, 8)[0]
    control = struct.pack('<8Q', MAGIC(b'HIAGWC01'), lease, 1, root, maximum, 3, 4300, 0)
    size = 32768
    work = ctypes.create_string_buffer(size + 32)
    ctypes.memset(ctypes.addressof(work) + size, 0xb9, 32)
    role = 'scan'
    while True:
        code, event = wire.call(role, source, control, work, size, label)
        assert code == 128
        if event[1] == 1:
            needed = max(size * 2, event[10]); assert needed > size
            replacement = ctypes.create_string_buffer(needed + 32)
            ctypes.memmove(replacement, work, size)
            ctypes.memset(ctypes.addressof(replacement) + needed, 0xb9, 32)
            work, size = replacement, needed
            continue
        if event[1] == 2:
            assert role == 'scan'; role = 'emit'; continue
        assert event[1] == 0 and role == 'emit', event
        return ctypes.string_at(ctypes.addressof(work) + event[11], event[12])
