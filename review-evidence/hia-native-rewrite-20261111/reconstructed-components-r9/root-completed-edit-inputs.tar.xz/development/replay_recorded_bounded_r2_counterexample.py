"""Later-written replay of saved original r2 buffers, not the lost shell source.

The original actual image entry and observation were already recorded. This
script uses those immutable raw objects rather than rebuilding a public input
or claiming the original counterexample has become a pass.
"""
import json
from pathlib import Path
from hashlib import sha256
import sys
from bounded_input_harness import Actual

DEV=Path(__file__).resolve().parent
ORIGINAL=DEV/'bounded-input-r2-pending-counterexample'
rows=[json.loads(line) for line in (ORIGINAL/'actual/entries.jsonl').read_text().splitlines()]
assert len(rows)==1
def read(row):
    raw=(ORIGINAL/'actual/raw'/row['sha256']).read_bytes()
    assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
    return raw
if __name__=='__main__':
    out=Path(sys.argv[1]);assert not out.exists()
    native=Actual(DEV/'bounded-input-source-and-compile-r2/agent-edit-bounded-input.manifest.json',out)
    try:
        row=rows[0]
        code,after=native.call('REPLAY_OF_ORIGINAL_PRIVATE_R2_FAILURE',read(row['source']),read(row['second']),read(row['before']))
        assert code==row['return_code']==128 and after==read(row['after'])
        print(json.dumps(dict(original_defect_reproduced=True,original_status='FAIL',actual=code,expected=0xfffffffd)))
    finally:native.close()
