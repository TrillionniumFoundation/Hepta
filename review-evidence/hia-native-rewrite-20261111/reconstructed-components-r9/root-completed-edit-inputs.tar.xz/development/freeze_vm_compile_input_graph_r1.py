"""Independent input-prefix VM outcomes before actual qualified B3 compile."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from hepta.hia_agent_assembly import assemble_program,render_assembly
from tools.generate_hia_agent_edit_input_graph import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from input_graph_harness import command,run

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'input-graph-source-and-compile-r1';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_input_graph.py',ROOT/'tools/generate_hia_agent_edit_apply_graph.py',
       ROOT/'tools/generate_hia_graph_merge.py',ROOT/'tools/hia_agent_edit_source_views.py',
       ROOT/'examples/hia_bootstrap/agent_edit_input_graph.hiaasm',COMPILER,Path(__file__),DEV/'input_graph_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
spec=importlib.util.spec_from_file_location('input_graph_vm_capture',DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py')
wire=importlib.util.module_from_spec(spec);sys.modules[spec.name]=wire;spec.loader.exec_module(wire)
summary=dict(status='INCOMPLETE',scope='DEVELOPMENT_PRIVATE_INPUT_PREFIX_NOT_PUBLIC_CAPTURE_OR_COORDINATOR');started=time.monotonic_ns()
try:
    doc=document();source=frozen[paths[4]];assert render_assembly(doc).encode()==source
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    checked=assemble_program(source);entries=[0];observations=[]
    def call(label,a,b,before):
        code,after=vm_call(checked,a,b,before);entries[0]+=1
        for suffix,raw in (('graph',a),('command',b),('before',before),('after',after)):(OUT/f'vm-{entries[0]}.{suffix}.bin').write_bytes(raw)
        return code,after
    select=dict(function='work',block='entry',output='value')
    nested=dict(selector=select,fields=['op'])
    batch=dict(schema='hepta.hia.edit-batch-query.v3',sites=[dict(site=0,query=nested),dict(site=1,query=dict(selector=select))])
    cases=[('single',1,nested,0,0,1),('single-missing-fields',1,dict(selector=select),0,0,1),
           ('single-invalid-selector',1,dict(selector=dict(select,extra=1)),0,2,0),
           ('batch-current-only',2,[dict(select,fields=['op']),{}],0,0,1),
           ('batch-next-invalid',2,[dict(select,fields=['op']),{}],1,11,0),
           ('batch-all-sites',3,batch,0,0,2),
           ('batch-site-before-nested',3,dict(schema=batch['schema'],sites=[dict(site=True,query={})]),0,22,0),
           ('batch-late-selector-before-early-fields',3,dict(schema=batch['schema'],sites=[dict(site=0,query=dict(selector=select,fields=[])),dict(site=1,query={})]),0,23,0)]
    for number,(label,mode,value,index,error,count) in enumerate(cases):
        graph=wire.capture(value);event,roots,after=run(call,label,graph,command(graph,mode,index,number+1))
        assert event[9]==error and (event[1]==0)==(error==0),(label,event)
        if not error:
            assert len(roots)==count
            if label=='single-missing-fields':assert roots[0][3]==0
            if label=='batch-all-sites':assert roots[1][3]==0
        observations.append(dict(case=label,event=event,selector_node_ids=roots))
    compiled,receipt=compile_stage(OUT,'agent-edit-input-graph',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-input-graph-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_input_graph.hiaasm'),source_sha256=sha256(source).hexdigest(),image_path=str(compiled),image_sha256=sha256(compiled.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-input-graph.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=observations,independent_VM_entries=entries[0],receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
