"""Actual complete caller budgets, wire, normalization and native diagnostics."""
from contextlib import ExitStack
import copy
from hashlib import sha256
import json
import math
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program
from hepta import hia_edit_query,hia_edit_batch,hia_program_tools
from hepta.hia_program_tools import bounded_json_wire,decode_json
from tests.test_hia_edit_query import fixture
from facts_harness import vm_call
from bounded_input_harness import Actual,Peers,command,run,BAD

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'bounded-input-native-r3';OUT.mkdir(exist_ok=False)
native=Actual(DEV/'bounded-input-source-and-compile-r3/agent-edit-bounded-input.manifest.json',OUT/'controller')
peers=Peers(OUT/'peers')
checked=assemble_program((DEV/'bounded-input-source-and-compile-r3/source/examples/hia_bootstrap/agent_edit_bounded_input.hiaasm').read_bytes())
original=verify_program(fixture());prepared=hia_edit_query.prepare_edit(original,function='calculate',block='entry',output='y',fields=['op'])
pins={p:p.read_bytes() for p in (Path(__file__),DEV/'bounded_input_harness.py',ROOT/'hepta/hia_edit_query.py',ROOT/'hepta/hia_edit_batch.py',ROOT/'hepta/hia_program_tools.py')}
cases,controls=[],[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')

class Frontier(Exception):pass
def oracle(value,policy,digits):
    old=sys.get_int_max_str_digits();sys.set_int_max_str_digits(digits)
    raw=None;decoded=None;error=None;cls=None;cause=None
    try:
        if policy==1:
            captured=[]
            def decode_frontier(payload):captured.append(payload);raise Frontier()
            try:
                with patch.object(hia_edit_query,'decode_json',new=decode_frontier):
                    hia_edit_query.apply_edit(original,prepared,value)
            except Frontier:pass
            assert len(captured)==1
            raw=captured[0];decoded=decode_json(raw)
        elif policy in (2,3):
            decoded,raw=hia_edit_batch._bounded(value,1<<20 if policy==2 else 65536,'query' if policy==2 else 'response')
        elif policy==4:
            captured=[];real_wire=hia_edit_query._wire
            def wire_frontier(query):captured.append(real_wire(query));raise Frontier()
            try:
                with patch.object(hia_edit_query,'prepare_edit',return_value=prepared),patch.object(hia_edit_query,'_wire',new=wire_frontier):
                    hia_edit_query.apply_edit(original,value,{})
            except Frontier:pass
            assert len(captured)==1
            raw=captured[0]
        else:raw=bounded_json_wire(value,1<<20)
    except Exception as exc:
        error=str(exc);cls=type(exc).__name__;cause=type(exc.__cause__).__name__ if exc.__cause__ is not None else None
    finally:sys.set_int_max_str_digits(old)
    return dict(raw=raw,decoded=decoded,error=error,error_class=cls,cause=cause)

def forbidden(*args,**kwargs):raise AssertionError('host parsing/wire/edit policy entered actual bounded-input chain')
def exercise(label,policy,value,*,digits=4300,vm=False):
    expected=oracle(value,policy,digits);graph=peers.wm.capture(value);ctl=command(graph,policy,digits=digits,request=len(cases)+1);observations=[]
    with ExitStack() as stack:
        for target in ('hepta.hia_edit_query.apply_edit','hepta.hia_edit_query.prepare_edit','hepta.hia_edit_batch.apply_batch',
                       'hepta.hia_edit_batch._bounded','hepta.hia_program_tools.decode_json','hepta.hia_program_tools.bounded_json_wire',
                       'hepta.hia_json_preflight._preflight_hia_json_reference','hepta.hia_agent_data_json_native.materialize_data',
                       'hepta.hia_json_decode_native.materialize','json.loads'):
            stack.enter_context(patch(target,new=forbidden))
        result=run(native.call,peers,label,graph,ctl,observe=observations)
    assert result['error']==expected['error'],(label,result['error'],expected,result['event'],result['result'])
    if expected['error'] is None:
        assert result['raw']==expected['raw'],label
        if policy<4:
            expected_graph=peers.wm.capture(expected['decoded'],lease=101)
            assert peers.dm.ag.shape(result['graph'])==peers.dm.ag.shape(expected_graph),label
        else:assert result['graph']==b''
    else:
        assert expected['error_class']==('UnicodeEncodeError' if result['result'][2]==2 else 'HIAEditRejected'),(label,expected,result['result'])
    if vm:
        for source,control,before,code,after in observations:assert vm_call(checked,source,control,before)==(code,after)
    cases.append(dict(case=label,policy=policy,digits=digits,error=expected['error'],expected_class=expected['error_class'],
                      expected_cause=expected['cause'],event=result['event'],result=result['result'],actual_peer_kinds=result['peers'],
                      entries=result['entries'],raw_bytes=len(result['raw']),normalized_graph_bytes=len(result['graph']),
                      complete_original_raw_and_normalization_equal=expected['error'] is None,full_workspace_VM_pair=vm,
                      old_owners_disabled_during_actual_chain=True))
    return graph,ctl,result,observations

def mutate(raw,at,value):
    return raw[:at]+struct.pack('<Q',value)+raw[at+8:]

try:
    values=[None,False,True,0,1,-1,1.25,-0.0,float('nan'),float('inf'),'', 'null','true','0','-0',
            '{"op":"int.add.wrap"}','{"x":1,"x":2}','{"x":1.0}','! \ud800','水\ud800',
            '😀\ud800\udfff','😀\ud800x\udfff',b'',b'null',b'! \xff',b'\xef\xbb\xbfnull',
            b'{"x":1,"x":2}',[],(),{},['x',1,False,None],('x',1),{'z':1,'a':'é'},
            {1:'integer'}, {None:'none',False:'bool'}, {1:'a','1':'collision'}, {1:'a','x':'sort'},
            [b'not-json'],{'k':'\ud800'},set(),object()]
    for policy in (1,2,3):
        for n,value in enumerate(values):exercise('common-'+str(policy)+'-'+str(n),policy,value,vm=policy==1 and n in (5,19,20))
    cycle=[];cycle.append(cycle)
    shared=[1,{'x':'é'}]
    for policy in (1,2,3):
        exercise('cycle-'+str(policy),policy,cycle)
        exercise('alias-'+str(policy),policy,[shared,shared])
        limit={1:16384,2:1<<20,3:65536}[policy]
        exact=b'null'+b' '*(limit-4)
        exercise('raw-bytes-exact-'+str(policy),policy,exact)
        exercise('raw-text-exact-'+str(policy),policy,exact.decode())
        exercise('raw-bytes-over-before-invalid-utf8-'+str(policy),policy,b'!'+b' '*(limit-1)+b'\xff')
        exercise('raw-bytes-within-invalid-utf8-'+str(policy),policy,b'!'+b' '*(limit-2)+b'\xff')
        exercise('raw-text-over-before-grammar-'+str(policy),policy,'!'+' '*(limit))
        exercise('raw-text-surrogate-before-budget-'+str(policy),policy,' '*(limit)+'\ud800\udfff')
        # Multibyte strings charge UTF-8 bytes, not Python codepoint length.
        text='"'+'é'*((limit-2)//2)+'"'
        exercise('raw-multibyte-exact-'+str(policy),policy,text)
        exercise('raw-multibyte-over-'+str(policy),policy,text+' ')
        # Complete output is retained on the exact boundary; no truncation.
        exercise('object-wire-exact-'+str(policy),policy,{'x':'a'*(limit-8)})
        exercise('object-wire-over-'+str(policy),policy,{'x':'a'*(limit-7)})
    old=sys.get_int_max_str_digits();sys.set_int_max_str_digits(0)
    integer=int('7'*650)
    sys.set_int_max_str_digits(old)
    for digits in (0,640,4300):
        for policy in (1,2,3):
            exercise('integer-object-'+str(policy)+'-'+str(digits),policy,integer,digits=digits)
            exercise('integer-raw-'+str(policy)+'-'+str(digits),policy,b'7'*650,digits=digits)
    depth=[0]
    for _ in range(128):depth=[depth]
    for policy in (1,2,3):exercise('depth-refusal-'+str(policy),policy,depth)
    for n,altered in enumerate((prepared,dict(prepared,extra=1.25),dict(prepared,extra=True),
                                dict(prepared,extra='\ud800'),dict(prepared,extra=object()),
                                dict(prepared,extra=cycle),dict(prepared,extra='x'*(1<<20)))):
        exercise('single-query-canonical-wrapper-'+str(n),4,altered,vm=n==0)
    for n,value in enumerate((None,1.25,{'x':-0.0},{'x':'\ud800'},cycle,{'x':'a'*((1<<20)-8)})):
        exercise('prepared-wire-'+str(n),5,value)
    graph,ctl,complete,observations=exercise('protocol-template',1,{'op':'int.add.wrap'})
    # Controller growth and immutable reply continuations, all actual frames.
    begin=observations[0]
    for label,source,control,before in (
        ('short-workspace',graph,ctl,bytes(1023)),
        ('empty-command',graph,b'',bytes(1024)),
        ('reserved-command',graph,mutate(ctl,48,1),bytes(1024)),
        ('invalid-policy',graph,mutate(ctl,32,6),bytes(1024)),
        ('zero-root',graph,mutate(ctl,24,0),bytes(1024)),
        ('dirty-initial',graph,ctl,bytes(1023)+b'!'),
        ('bad-graph-header',b'\0'+graph[1:],ctl,bytes(1024)),
        ('terminal-replay',graph,ctl,complete['workspace'])):
        code,after=native.call(label,source,control,before);assert code==BAD,label
        if len(before)>=1024:
            again,retained=native.call(label+'-permanent',graph,ctl,after);assert again==BAD and retained==after
        controls.append(dict(case=label,refused=True,permanent=len(before)>=1024))
    code,pending=native.call('grow-initial-original',graph,ctl,bytes(1024));assert code==128
    for label,source,control in (
        ('changed-initial-digit-profile',graph,mutate(ctl,40,640)),
        ('changed-initial-request',graph,mutate(ctl,16,999)),
        ('changed-graph-identity',mutate(graph,8,999),ctl),
        ('changed-graph-extent',graph+b'!',ctl)):
        code,after=native.call(label,source,control,pending);assert code==BAD,label
        again,retained=native.call(label+'-permanent',graph,ctl,after);assert again==BAD and retained==after
        controls.append(dict(case=label,permanent=True))
    # Every field of both final native reply headers/events is independently
    # checked where the ABI promises an exact binding or bounded extent.
    peer_observations=[row for row in observations if len(row[1])>=192 and struct.unpack_from('<Q',row[1])[0]!=struct.unpack_from('<Q',ctl)[0]]
    for peer in (1,2):
        row=next(row for row in peer_observations if struct.unpack_from('<Q',row[1],24)[0]==peer)
        source,reply,before,unused_code,unused_after=row
        mutations=[(0,0),(8,999),(16,999),(24,3),(32,127),(40,len(reply)),(48,1),(56,1),(64,0),(80,999),(88,999)]
        if peer==1:mutations.extend(((96,999),(104,0),(112,0),(120,640),(128,1),(136,1),(144,1),(168,1),(176,99),(184,1),(152,len(reply)),(160,1<<63)))
        else:mutations.extend(((96,99),(104,len(reply)),(112,1),(120,1),(128,1),(136,1),(144,1),(152,1),(160,1),(168,3),(176,len(reply)),(184,1<<63)))
        for at,value in mutations:
            label='peer-'+str(peer)+'-field-'+str(at);control=mutate(reply,at,value)
            code,after=native.call(label,source,control,before);assert code==BAD,(label,code,struct.unpack_from('<16Q',after))
            again,retained=native.call(label+'-permanent',source,reply,after);assert again==BAD and retained==after
            controls.append(dict(case=label,permanent=True))
    for row in observations:
        source,reply,before,code,after=row;e=struct.unpack_from('<16Q',after)
        if e[1]!=1 or e[4] not in (11,21):continue
        pending=after+bytes(e[5]-len(after))
        changed=mutate(reply,16,999)
        code,poisoned=native.call('growth-reply-header-'+str(e[4]),source,changed,pending);assert code==BAD
        again,retained=native.call('growth-reply-header-permanent-'+str(e[4]),source,reply,poisoned);assert again==BAD and retained==poisoned
        controls.append(dict(case='growth-reply-header-'+str(e[4]),permanent=True))
    # The actual r2 counterexample replaced a pinned success with a different
    # terminal kind after GROW. Even an otherwise valid error must fail binding.
    row=next(row for row in observations if len(row[1])>=192 and struct.unpack_from('<Q',row[2],272)[0]==11)
    source,reply,before,unused,after=row
    changed=reply
    for at,value in ((72,3),(128,15),(136,1),(152,0),(160,0),(176,99)):
        changed=mutate(changed,at,value)
    code,poisoned=native.call('pending-success-replaced-by-error',source,changed,before);assert code==BAD
    again,retained=native.call('pending-success-replaced-by-error-permanent',source,reply,poisoned)
    assert again==BAD and retained==poisoned
    controls.append(dict(case='pending-success-replaced-by-error',permanent=True,original_r2_counterexample=True))
    # Refusal replies are also actual peer outputs, never a synthetic success.
    for label,policy,value in (('wire-error-template',2,cycle),('decode-error-template',1,b'{"x":1.5}')):
        graph,ctl,result,obs=exercise(label,policy,value)
        source,reply,before,unused,after=next(row for row in obs if len(row[1])>=192 and struct.unpack_from('<Q',row[1])[0]!=struct.unpack_from('<Q',ctl)[0])
        at=128 if label.startswith('wire') else 168
        code,poisoned=native.call(label+'-zero-error-code',source,mutate(reply,at,0),before);assert code==BAD
        controls.append(dict(case=label+'-zero-error-code',refused=True))
    summary.update(status='PASS')
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    native.close();peers.close()
    summary.update(scope='DEVELOPMENT_COMPLETE_CALLER_GATES_WIRE_DECODE_NOT_PUBLIC_FOREIGN_CAPTURE_OR_FIXED_EXECUTOR',
                   cases=cases,private_controls=controls,actual_controller_entries=native.entries,
                   actual_wire_entries=peers.wire.entries,actual_decode_entries=peers.decode.entries,
                   elapsed_ns=time.monotonic_ns()-started,all_pins_unchanged=all(p.read_bytes()==v for p,v in pins.items()),
                   pins={str(p):sha256(v).hexdigest() for p,v in pins.items()},whole_stack_closed=False)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','private_controls','pins')},sort_keys=True),flush=True)
    assert summary['all_pins_unchanged']
