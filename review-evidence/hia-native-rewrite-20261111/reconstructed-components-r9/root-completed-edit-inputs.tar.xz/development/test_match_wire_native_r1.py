"""Actual byte equality, original limits, whole-workspace pairs, poison checks."""
from hashlib import sha256
import json
from pathlib import Path
import struct
import time
import traceback
from hepta.hia_agent_assembly import assemble_program
from facts_harness import vm_call
from bounded_input_harness import Actual,BAD
from match_wire_harness import command,run,ERRORS

DEV=Path(__file__).resolve().parent;OUT=DEV/'match-wire-native-r1';OUT.mkdir(exist_ok=False)
native=Actual(DEV/'match-wire-source-and-compile-r1/agent-edit-match-wire.manifest.json',OUT/'native')
source=DEV/'match-wire-source-and-compile-r1/source/examples/hia_bootstrap/agent_edit_match_wire.hiaasm'
checked=assemble_program(source.read_bytes());pins={p:p.read_bytes() for p in (Path(__file__),DEV/'match_wire_harness.py',DEV/'bounded_input_harness.py',source)}
cases=[];controls=[];started=time.monotonic_ns();summary=dict(status='INCOMPLETE')
def exercise(label,a,b,mode,vm=False):
    request=len(cases)+1;event,after,error=run(native.call,label,a,b,mode=mode,request=request)
    assert (event[1]==0)==(a==b) and error==(None if a==b else ERRORS[mode])
    if vm:assert vm_call(checked,a,b,command(mode,request))==(256,after)
    cases.append(dict(case=label,mode=mode,equal=a==b,event=event,complete_workspace_VM_pair=vm))
    return after
def refuse(label,a,b,before,vm=False):
    code,after=native.call(label,a,b,before);assert code==BAD
    if vm:assert vm_call(checked,a,b,before)==(code,after)
    if len(after)>=512:
        assert struct.unpack_from('<Q',after,32)[0]==3
        again,unchanged=native.call(label+'-permanent',a,b,after);assert again==BAD and unchanged==after
    else:assert after==before
    controls.append(dict(case=label,complete_workspace_VM_pair=vm,permanent_poison_or_short_discard=True))
try:
    for mode in (1,2):
        for i,(a,b) in enumerate([(b'null',b'null'),(b'[]',b'[]'),(b'{}',b'{}'),(b'1',b'1'),
            (b'{"a":true}',b'{"a":1}'),(b'1.0',b'1'),(b'-0.0',b'0'),(b'[1,2]',b'[1,3]'),
            (b'"abc"',b'"xbc"'),(b'"abc"',b'"abx"'),(b'{"a":1}',b'{"a":11}')]):
            exercise('shape-'+str(mode)+'-'+str(i),a,b,mode,vm=i in (0,4,7))
        for size in (512,4096,65536,1048576):
            a=b'"'+b'a'*(size-2)+b'"'
            exercise('boundary-same-'+str(mode)+'-'+str(size),a,a,mode)
            for at in (1,size//2,size-2):
                b=a[:at]+b'b'+a[at+1:]
                exercise('boundary-different-'+str(mode)+'-'+str(size)+'-'+str(at),a,b,mode)
    good=command()
    for offset,value in ((0,0),(8,0),(8,3),(16,0),(24,0),(32,1),(40,1),(64,1),(504,1)):
        bad=bytearray(good);struct.pack_into('<Q',bad,offset,value)
        refuse('bad-control-'+str(offset)+'-'+str(value),b'{}',b'{}',bytes(bad),vm=offset in (0,40))
    for label,a,b in [('empty-left',b'',b'{}'),('empty-right',b'{}',b''),
        ('over-left',b'a'*1048577,b'{}'),('over-right',b'{}',b'a'*1048577)]:refuse(label,a,b,good,vm=label=='empty-left')
    for n in (0,1,63,128,256,511):refuse('short-'+str(n),b'{}',b'{}',bytes(n),vm=n in (0,511))
    for label,a,b in [('match-replay',b'{}',b'{}'),('mismatch-replay',b'{}',b'[]')]:
        completed=exercise(label,a,b,1);refuse(label+'-refused',a,b,completed,vm=True)
    summary.update(status='PASS',cases=cases,private_controls=controls,actual_entries=native.entries,
        all_inputs_and_canaries_unchanged=True,original_limits_unchanged=True,whole_stack_closed=False)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc),completed_cases=cases,completed_controls=controls);traceback.print_exc();raise
finally:
    native.close();summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in pins.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
