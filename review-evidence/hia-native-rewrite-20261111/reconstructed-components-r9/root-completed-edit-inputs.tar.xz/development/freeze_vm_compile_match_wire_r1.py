"""Freeze and independently execute the exact snapshot-byte owner before B3."""
from hashlib import sha256
import json
from pathlib import Path
import time
import traceback
from hepta.hia_agent_assembly import assemble_program,render_assembly
from tools.generate_hia_agent_edit_match_wire import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call
from match_wire_harness import command,run,ERRORS

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'match-wire-source-and-compile-r1';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_match_wire.py',ROOT/'tools/generate_hia_agent_edit_apply_graph.py',
       ROOT/'tools/generate_hia_graph_merge.py',ROOT/'tools/hia_agent_edit_source_views.py',
       ROOT/'examples/hia_bootstrap/agent_edit_match_wire.hiaasm',COMPILER,Path(__file__),DEV/'match_wire_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
summary=dict(status='INCOMPLETE',scope='DEVELOPMENT_NATIVE_EXACT_CANONICAL_SNAPSHOT_BYTES_NOT_PUBLIC_COORDINATOR');started=time.monotonic_ns()
try:
    doc=document();source=frozen[paths[4]];assert render_assembly(doc).encode()==source
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),
        max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),
        max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    checked=assemble_program(source);entries=[0];observations=[]
    def call(label,a,b,before):
        code,after=vm_call(checked,a,b,before);entries[0]+=1
        for suffix,raw in (('source',a),('second',b),('before',before),('after',after)):(OUT/f'vm-{entries[0]}.{suffix}.bin').write_bytes(raw)
        return code,after
    for n,(label,a,b,mode) in enumerate([
        ('same-object',b'{"a":1}',b'{"a":1}',1),('same-batch',b'[{"a":1}]',b'[{"a":1}]',2),
        ('bool-int',b'{"a":true}',b'{"a":1}',1),('float-int',b'{"a":1.0}',b'{"a":1}',2),
        ('same-length-final-byte',b'[11]',b'[12]',1),('same-length-prefix',b'1',b'2',2),
        ('longer-left',b'"aa"',b'"a"',1),('shorter-left',b'"a"',b'"aa"',2)]):
        event,after,error=run(call,label,a,b,mode=mode,request=n+1)
        assert (event[1]==0)==(a==b) and error==(None if a==b else ERRORS[mode])
        observations.append(dict(case=label,event=event,error=error,exact_bytes=True))
    compiled,receipt=compile_stage(OUT,'agent-edit-match-wire',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-match-wire-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_match_wire.hiaasm'),
        source_sha256=sha256(source).hexdigest(),image_path=str(compiled),image_sha256=sha256(compiled.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-match-wire.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=observations,independent_VM_entries=entries[0],receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
