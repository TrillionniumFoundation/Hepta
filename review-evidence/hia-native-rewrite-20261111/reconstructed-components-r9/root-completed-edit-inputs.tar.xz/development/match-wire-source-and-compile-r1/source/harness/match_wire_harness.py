"""Mechanical forwarding for the immutable canonical-byte equality owner."""
import struct
from packet_graph_harness import MAGIC

ERRORS={1:'E_HIA_QUERY: stale or modified edit query',2:'E_HIA_EDIT_BATCH: stale or altered batch query'}

def command(mode=1,request=1,lease=103):
    return struct.pack('<8Q',MAGIC(b'HIAQMC01'),mode,lease,request,0,0,0,0)+bytes(448)

def run(call,label,actual,expected,*,mode=1,request=1):
    code,after=call(label,actual,expected,command(mode,request))
    event=struct.unpack_from('<16Q',after,128)
    assert code==256 and event[0]==MAGIC(b'HIAQME01') and event[1] in (0,2),(label,code,event)
    assert event[2:7]==(103,request,mode,len(actual),len(expected))
    error=after[event[8]:event[8]+event[9]].decode('utf8') if event[1]==2 else None
    if error is not None:assert error==ERRORS[mode]
    return event,after,error
