"""Freeze original selector semantics and independently execute before B3."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from hepta.hia_agent_assembly import assemble_program,render_assembly
from hepta.hia_program import verify_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_composite_function_tokens import detached_packet_index
from hepta.hia_edit_query import prepare_edit
from tests.test_hia_edit_query import fixture
from tools.generate_hia_agent_edit_selection import document
from tools.qualify_hia_selfhost import compile_stage
from facts_harness import vm_call,lease
from selection_harness import command,run,ERRORS

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'selection-source-and-compile-r3';OUT.mkdir(exist_ok=False)
COMPILER=DEV/'facts-source-and-compile-r1/source/compiler/B3.image.bin'
paths=[ROOT/'tools/generate_hia_agent_edit_selection.py',ROOT/'tools/generate_hia_agent_edit_query_packet.py',
       ROOT/'tools/generate_hia_agent_edit_apply_graph.py',ROOT/'tools/generate_hia_graph_merge.py',
       ROOT/'tools/hia_agent_edit_source_views.py',ROOT/'examples/hia_bootstrap/agent_edit_selection.hiaasm',
       COMPILER,Path(__file__),DEV/'selection_harness.py']
frozen={p:p.read_bytes() for p in paths};rows=[]
for p,raw in frozen.items():
    rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('compiler/B3.image.bin') if p==COMPILER else Path('harness')/p.name
    target=OUT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(path=str(p),copy=str(target),bytes=len(raw),sha256=sha256(raw).hexdigest()))
(OUT/'source.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
spec=importlib.util.spec_from_file_location('selection_vm_graph',DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py')
wire=importlib.util.module_from_spec(spec);sys.modules[spec.name]=wire;spec.loader.exec_module(wire)
summary=dict(status='INCOMPLETE',scope='DEVELOPMENT_PRIVATE_SELECTION_PREFIX_NOT_PUBLIC_CAPTURE_OR_COORDINATOR');started=time.monotonic_ns()
try:
    doc=document();source=frozen[paths[5]];assert render_assembly(doc).encode()==source
    profile=dict(functions=len(doc['functions']),blocks=sum(len(f['blocks']) for f in doc['functions']),max_blocks=max(len(f['blocks']) for f in doc['functions']),ops=sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']),max_block_params=max(len(b['params']) for f in doc['functions'] for b in f['blocks']))
    assert profile['functions']<=128 and profile['blocks']<=1536 and profile['max_blocks']<=256 and profile['ops']<=8192 and profile['max_block_params']<=16
    checked=assemble_program(source);entries=[0];observations=[]
    def call(label,a,b,before):
        code,after=vm_call(checked,a,b,before);entries[0]+=1
        for suffix,raw in (('source',a),('command',b),('before',before),('after',after)):(OUT/f'vm-{entries[0]}.{suffix}.bin').write_bytes(raw)
        return code,after
    original=verify_program(fixture());packet=transport(original.as_dict())
    unused,indices=detached_packet_index(packet);bitmap=bytearray((len(packet)+7)//8)
    for at in indices:bitmap[at>>3]|=1<<(at&7)
    source_lease=lease(packet,bytes(bitmap))
    selections=[
        ('all-fields-tuple',dict(function='calculate',block='entry',output='y',fields=('op','attrs','args'))),
        ('last-function',dict(function='caller',block='entry',output='answer',fields=['args'])),
        ('fields-before-nonstring',dict(function=123,block=None,output=False,fields=[])),
        ('identity-before-lookup',dict(function='absent',block=123,output='missing',fields=['op'])),
        ('surrogate-function',dict(function='\ud800',block='entry',output='y',fields=['op'])),
        ('surrogate-block',dict(function='calculate',block='\ud800',output='y',fields=['op'])),
        ('surrogate-output',dict(function='calculate',block='entry',output='\ud800',fields=['op'])),
        ('absent-fields',dict(function='calculate',block='entry',output='y',fields=None)),
    ]
    for n,(label,selection) in enumerate(selections):
        graph=wire.capture([selection[k] for k in ('function','block','output','fields')]);nodes=struct.unpack_from('<Q',graph,16)[0]
        roots=struct.unpack_from('<4Q',graph,64+nodes*64)
        if label=='absent-fields':roots=(*roots[:3],0)
        expected_error=None
        try:prepare_edit(original,**selection)
        except Exception as exc:expected_error=str(exc)
        event,after=run(call,label,source_lease,command(graph,roots,request=n+1))
        if expected_error is not None:
            assert event[1]==2 and ERRORS[event[8]]==expected_error,(label,event,expected_error)
        else:
            assert event[1]==0,(label,event)
            actual=after[event[6]:event[6]+event[7]]
            expected=transport([original.as_dict(),dict(selection,fields=list(selection['fields']))])
            assert actual==expected,(label,len(actual),len(expected),event)
            (OUT/(label+'.actual.packet')).write_bytes(actual);(OUT/(label+'.expected.packet')).write_bytes(expected)
        observations.append(dict(case=label,exact_packet_or_diagnostic=True,error=expected_error,event=event))
    compiled,receipt=compile_stage(OUT,'agent-edit-selection',COMPILER,source)
    manifest=dict(schema='hepta.hia.agent-edit-selection-native.v1',source_path=str(OUT/'source/examples/hia_bootstrap/agent_edit_selection.hiaasm'),source_sha256=sha256(source).hexdigest(),image_path=str(compiled),image_sha256=sha256(compiled.read_bytes()).hexdigest(),compiler_sha256=sha256(frozen[COMPILER]).hexdigest())
    (OUT/'agent-edit-selection.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    summary.update(status='PASS',profile=profile,independent_VM_cases=observations,independent_VM_entries=entries[0],receipt=receipt,manifest=manifest)
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    summary['source_before_after_equal']=all(p.read_bytes()==v for p,v in frozen.items());summary['elapsed_ns']=time.monotonic_ns()-started
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)
    assert summary['source_before_after_equal']
