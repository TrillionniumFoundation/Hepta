"""Mechanical native selector command/continuation transport, with no policy."""
import struct
from packet_graph_harness import MAGIC

ERRORS={
    1:'E_HIA_QUERY: fields must be a unique nonempty subset of op, args, attrs',
    2:'E_HIA_QUERY: function, block and output identities must be strings',
    3:'E_HIA_QUERY: function not found',
    4:'E_HIA_QUERY: block not found',
    5:'E_HIA_QUERY: SSA output does not identify one instruction',
}

def command(graph,roots,*,action=1,request=1,sequence=0):
    assert len(roots)==4
    return (struct.pack('<16Q',MAGIC(b'HIAQSC01'),action,89,request,sequence,*roots,*([0]*7))+graph)

def run(call,label,source,control,compare=None):
    before=bytes(1024)
    while True:
        code,after=call(label,source,control,before)
        if compare is not None:assert compare(source,control,before)==(code,after)
        event=struct.unpack_from('<16Q',after,256)
        assert code==384,(label,code,event)
        assert event[0]==MAGIC(b'HIAQSE01')
        if event[1]!=1:return event,after
        assert event[5]>len(after)
        before=after+bytes(event[5]-len(after))
        control=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',event[4])+control[40:]

