"""Mechanical merge calls plus an independent, non-forwarding byte oracle."""
import struct
from packet_graph_harness import Actual, MAGIC

def frame(a, b, *, action=1, lease=41, request=1, sequence=0, left=None, right=None):
    if left is None:
        left = struct.unpack_from('<Q', a, 24)[0]
    if right is None:
        right = struct.unpack_from('<Q', b, 24)[0]
    return struct.pack('<16Q', MAGIC(b'HIAGMC01'), action, lease, request, sequence, left, right,
                       *([0] * 9)) + a

def merge(call, label, a, b, *, request=1, left=None, right=None, compare=None):
    before = bytes(512)
    control = frame(a, b, request=request, left=left, right=right)
    while True:
        code, after = call(label, control, b, before)
        if compare is not None:
            assert compare(control, b, before) == (code, after)
        event = struct.unpack_from('<16Q', after, 256)
        assert code == 384, (label, code, event)
        assert event[0] == MAGIC(b'HIAGME01')
        if event[1] == 0:
            return after[event[6]:event[6] + event[7]], after
        assert event[1] == 1 and event[5] > len(after)
        before = after + bytes(event[5] - len(after))
        control = frame(a, b, request=request, action=2, sequence=event[4], left=left, right=right)

def reference(a, b, *, lease=41, left=None, right=None):
    headers = [struct.unpack_from('<8Q', graph) for graph in (a, b)]
    if left is None: left = headers[0][3]
    if right is None: right = headers[1][3]
    nodes = 1 + sum(h[2] for h in headers)
    edges = 2 + sum(h[4] for h in headers)
    scalars = sum(h[5] for h in headers)
    base = 64 + nodes * 64 + edges * 8
    out = bytearray(base + scalars)
    struct.pack_into('<8Q', out, 0, MAGIC(b'HIAGRF01'), lease, nodes, 1, edges, scalars, len(out), 0)
    struct.pack_into('<8Q', out, 64, 5, 0, 0, 0, 2, 1, 0, 0)
    struct.pack_into('<2Q', out, 64 + nodes * 64, left + 1, right + headers[0][2] + 1)
    nd, ed, sd = 1, 2, 0
    for graph, h in zip((a, b), headers):
        old_scalar = 64 + h[2] * 64 + h[4] * 8
        for i in range(h[2]):
            row = list(struct.unpack_from('<8Q', graph, 64 + i * 64))
            if row[0] in (5, 6, 7):
                row[3] += ed
                row[5] = i + nd + 1
            elif row[0] in (2, 3, 4, 9):
                row[1] += base + sd - old_scalar
            struct.pack_into('<8Q', out, 64 + (i + nd) * 64, *row)
        for i in range(h[4]):
            child = struct.unpack_from('<Q', graph, 64 + h[2] * 64 + i * 8)[0]
            struct.pack_into('<Q', out, 64 + nodes * 64 + (i + ed) * 8, child + nd)
        out[base + sd:base + sd + h[5]] = graph[old_scalar:]
        nd += h[2]; ed += h[4]; sd += h[5]
    return bytes(out)
