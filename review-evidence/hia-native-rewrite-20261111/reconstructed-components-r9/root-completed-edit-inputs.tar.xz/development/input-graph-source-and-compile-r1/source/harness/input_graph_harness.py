"""Mechanical input-prefix forwarding, no field/key or error-order decisions."""
import struct
from packet_graph_harness import MAGIC

ERRORS={
    1:'E_HIA_QUERY: query must be an exact prepare_edit result',
    2:'E_HIA_QUERY: invalid query selector',
    10:'E_HIA_EDIT_BATCH: a batch requires 1..16 selections',
    11:'E_HIA_EDIT_BATCH: a selection requires exactly function, block, output, fields',
    20:'E_HIA_EDIT_BATCH: expected an exact prepared batch query',
    21:'E_HIA_EDIT_BATCH: invalid query sites',
    22:'E_HIA_EDIT_BATCH: query sites must retain their exact ordered identities',
    23:'E_HIA_EDIT_BATCH: invalid nested selection',
}

def command(graph,mode,index=0,request=1):
    root=struct.unpack_from('<Q',graph,24)[0]
    return struct.pack('<16Q',MAGIC(b'HIAQIC01'),mode,97,request,root,index,*([0]*10))

def run(call,label,graph,control):
    code,after=call(label,graph,control,bytes(1024))
    event=struct.unpack_from('<16Q',after,256)
    assert code==384 and event[0]==MAGIC(b'HIAQIE01'),(label,code,event)
    roots=[]
    if event[1]==0:
        assert event[8]==event[10]*32 and 1<=event[10]<=16
        roots=[struct.unpack_from('<4Q',after,event[7]+index*32) for index in range(event[10])]
    else:assert event[1]==2 and event[9] in ERRORS,(label,event)
    return event,roots,after

