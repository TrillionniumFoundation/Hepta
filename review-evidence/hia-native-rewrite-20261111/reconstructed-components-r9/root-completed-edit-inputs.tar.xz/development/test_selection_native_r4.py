"""Actual admitted Core bytes -> native selection -> complete native queries."""
from contextlib import ExitStack
import copy
from hashlib import sha256
import importlib.util
import itertools
import json
from pathlib import Path
import struct
import sys
import time
import traceback
from unittest.mock import patch
from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program import verify_program
from hepta.hia_instruction_policy_native import transport
from hepta.hia_program_tools import bounded_json_wire
from hepta import hia_edit_query,hia_program,hia_program_tools,hia_instruction_policy_native,hia_json_decode_native
from hepta import hia_composite_function_tokens
from hepta.hia_core_admission_native import NativeCoreAdmission
from tests.test_hia_edit_query import fixture
from tests.test_hia_edit_batch import loans,selected
from tests.test_hia_program import b,c,f,i,ret,jump
from packet_graph_harness import Actual,BAD
from facts_harness import vm_call
from selection_harness import command,run,ERRORS
from native_query_pipeline import NativeQueryPipeline
from core_packet_transport import CorePacketTransport

DEV=Path(__file__).resolve().parent;ROOT=DEV.parent/'Hepta-agent-edit-native'
OUT=DEV/'selection-native-r4';OUT.mkdir(exist_ok=False)
selector=Actual(DEV/'selection-source-and-compile-r3/agent-edit-selection.manifest.json',OUT/'selector')
codec=CorePacketTransport(OUT/'core-codec');pipeline=NativeQueryPipeline(OUT/'queries')
image=(DEV/'apply-graph-native-r1/core_admission.image.bin').read_bytes();admission=NativeCoreAdmission(image,sha256(image).hexdigest())
(OUT/'core_admission.image.bin').write_bytes(image)
checked=assemble_program((DEV/'selection-source-and-compile-r3/source/examples/hia_bootstrap/agent_edit_selection.hiaasm').read_bytes())
spec=importlib.util.spec_from_file_location('selection_native_capture',DEV.parent/'native-agent-edit-render-next/development/graph_harness_r3.py')
gm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=gm;spec.loader.exec_module(gm)
pins={p:p.read_bytes() for p in (Path(__file__),DEV/'selection_harness.py',DEV/'core_packet_transport.py',DEV/'native_query_pipeline.py',
      ROOT/'hepta/hia_edit_query.py',ROOT/'hepta/hia_program_tools.py')}
cases,controls=[],[];cached={};started=time.monotonic_ns();summary=dict(status='INCOMPLETE')

def forbidden(*args,**kwargs):raise AssertionError('host semantic or value decoder/encoder entered actual selector/query chain')

def exercise(label,document,selection,*,pair_vm=False,whole=True,absent_fields=False):
    original=verify_program(document);base_wire=original.canonical_bytes;canonical_value=json.loads(base_wire)
    expected_error=None;expected_query=None;expected_wire=None
    try:
        expected_query=hia_edit_query.prepare_edit(original,**selection)
        expected_wire=bounded_json_wire(expected_query,1<<20)
    except Exception as exc:expected_error=(type(exc).__name__,str(exc))
    values=[selection[k] for k in ('function','block','output','fields')]
    graph=gm.capture(values);nodes=struct.unpack_from('<Q',graph,16)[0];roots=struct.unpack_from('<4Q',graph,64+nodes*64)
    if absent_fields:roots=(*roots[:3],0)
    control=command(graph,roots,request=len(cases)+1)
    expected_packet=None
    if expected_error is None:expected_packet=transport([canonical_value,dict(selection,fields=list(selection['fields']))])
    case_dir=OUT/('case-'+str(len(cases)));case_dir.mkdir();(case_dir/'base.json').write_bytes(base_wire)
    if expected_wire is not None:(case_dir/'expected-query.json').write_bytes(expected_wire)
    key=sha256(base_wire).hexdigest();query_before=pipeline.requests
    observations=[]
    def observed(label,a,b,before):
        result=selector.call(label,a,b,before)
        if pair_vm:observations.append((a,b,before,result))
        return result
    with ExitStack() as guards:
        for owner,name in ((hia_program,'verify_program'),(hia_edit_query,'prepare_edit'),(hia_edit_query,'_reference_edit_slice'),
                           (hia_edit_query,'_cfg_downstream_slice'),(hia_program_tools,'bounded_json_wire'),
                           (hia_instruction_policy_native,'transport'),(hia_composite_function_tokens,'detached_packet_index'),
                           (hia_composite_function_tokens.ObjectTokenDecoder,'feed'),(hia_json_decode_native,'materialize'),(json,'loads')):
            guards.enter_context(patch.object(owner,name,new=forbidden))
        if key not in cached:
            assert admission.status(base_wire)==0
            packet,source=codec.decode(label,base_wire)
            cached[key]=(packet,source,pipeline.hasher.digest(base_wire))
        base_packet,source,digest=cached[key]
        event,after=run(observed,label,source,control)
        if event[1]==2:
            assert expected_error==('HIAEditRejected',ERRORS[event[8]]),(label,event,expected_error)
            assert pipeline.requests==query_before
            outcome='EXACT_ORIGINAL_SELECTION_FIRST_ERROR'
        else:
            assert event[1]==0,(label,event)
            packet=after[event[6]:event[6]+event[7]]
            if expected_packet is not None:assert packet==expected_packet,label
            (case_dir/'selection.packet').write_bytes(packet)
            if whole:
                try:query_graph,wire=pipeline.prepare(label,packet,digest,digest)
                except Exception as exc:
                    assert expected_error==(type(exc).__name__,str(exc)),(label,expected_error,type(exc).__name__,str(exc))
                    outcome='EXACT_ORIGINAL_LATER_SLICE_REFUSAL'
                else:
                    assert expected_error is None and wire==expected_wire,(label,expected_error)
                    (case_dir/'actual-query.json').write_bytes(wire)
                    outcome='EXACT_NATIVE_COMPLETE_QUERY_FROM_ADMITTED_CORE_BYTES_AND_SELECTOR_GRAPH'
            else:
                assert expected_error is None and packet==expected_packet
                outcome='EXACT_NATIVE_SELECTION_PACKET'
    for a,b,before,result in observations:
        assert vm_call(checked,a,b,before)==result
    cases.append(dict(case=label,outcome=outcome,event=event,expected_error=expected_error,
                      actual_query_count=pipeline.requests-query_before,full_workspace_VM_pair=pair_vm,
                      host_semantic_owners_disabled=True,core_admission_and_codec_lease=key))
    return source,control,after

try:
    base=fixture();good=dict(function='calculate',block='entry',output='y',fields=['op'])
    for size in (1,2,3):
        for fields in itertools.permutations(('op','args','attrs'),size):
            for typ in (list,tuple):
                s,ctl,last=exercise('fields-'+','.join(fields)+'-'+typ.__name__,base,dict(good,fields=typ(fields)),pair_vm=size==3 and fields==('op','args','attrs') and typ is tuple)
    exercise('absent-fields-before-bad-name',base,dict(good,function=False,fields=None),absent_fields=True)
    class ListSubclass(list):pass
    class StrSubclass(str):pass
    bad_fields=[None,False,1,1.0,'op',b'op',{},set(),frozenset(),[],(),['op','args','attrs','op'],
                ['op','op'],('args','attrs','args'),[None],[True],[1],[1.0],[b'op'],[[]],[{}],['unknown'],[''],['\ud800'],
                ['op','attrs','\ud800'],ListSubclass(['op']),[StrSubclass('op')]]
    cyclic=[];cyclic.append(cyclic);bad_fields.append(cyclic)
    for n,value in enumerate(bad_fields):
        exercise('invalid-fields-'+str(n),base,dict(function=123,block=None,output=False,fields=value))
    wrong_names=[None,True,0,1.0,b'calculate',[],{},(),object(),StrSubclass('calculate')]
    for position in ('function','block','output'):
        for n,value in enumerate(wrong_names):exercise('name-kind-'+position+'-'+str(n),base,dict(good,**{position:value}))
    for position in ('function','block','output'):
        for n,value in enumerate(('', '\ud800','\udfff','é','calculate\x00','x'*129,'x'*(1<<20))):
            exercise('unmatched-'+position+'-'+str(n),base,dict(good,**{position:value}))
    for n,selection in enumerate((dict(function='missing',block=123,output='missing',fields=['op']),
                                  dict(function='missing',block='missing',output='missing',fields=['op']),
                                  dict(function='calculate',block='missing',output='missing',fields=['op']),
                                  dict(function='calculate',block='entry',output='missing',fields=['op']))):
        exercise('ordered-errors-'+str(n),base,selection)
    exercise('last-function-call',base,dict(function='caller',block='entry',output='answer',fields=['args']))
    source=loans();exercise('v8-read-loan',source,selected('reader'));exercise('v8-mut-loan',source,selected('writer'))
    source=loans();source['functions'][0]['blocks'][0]['ops'][1]=i('buffer.try_new',['size'],[('a','buffer'),('ok','bool')])
    exercise('multioutput-buffer',source,selected('a'));exercise('multioutput-bool',source,selected('ok'))
    many={'schema':'hepta.hia.program.v8','module':'selector_functions','functions':[
        f('f'+str(n),[],['u32'],[],[b('entry',[],[c('value','u32',n)],ret('value'))]) for n in range(1024)]}
    exercise('last-of-1024-functions',many,dict(function='f1023',block='entry',output='value',fields=['attrs']))
    blocks=[b('b'+str(n),[],[c('v'+str(n),'u32',n)],jump('b'+str(n+1))) for n in range(4095)]
    blocks.append(b('b4095',[],[c('v4095','u32',4095)],ret('v4095')))
    many={'schema':'hepta.hia.program.v8','module':'selector_blocks','functions':[f('work',[],['u32'],[],blocks)]}
    exercise('last-of-4096-blocks',many,dict(function='work',block='b4095',output='v4095',fields=['attrs']))
    source=fixture();ops=source['functions'][0]['blocks'][0]['ops']
    ops[:]=[c('v'+str(n),'u32',n) for n in range(255)]+[c('y','u32',255)]
    s,ctl,last=exercise('last-of-256-operations',source,good)
    for label,a,cnt,before in (
        ('empty-control',s,b'',bytes(1024)),('dirty-initial',s,ctl,bytes(1023)+b'!'),
        ('replay-complete',s,ctl,last),('reserved-control',s,ctl[:72]+struct.pack('<Q',1)+ctl[80:],bytes(1024)),
        ('invalid-source-header',b'\0'+s[1:],ctl,bytes(1024)),('zero-selector-node',s,ctl[:40]+bytes(8)+ctl[48:],bytes(1024)),
        ('short-descriptor',s,ctl,bytes(1023))):
        code,poisoned=selector.call(label,a,cnt,before);assert code==BAD
        if len(before)>=1024:
            again,retained=selector.call(label+'-permanent',s,ctl,poisoned);assert again==BAD and retained==poisoned
        controls.append(dict(case=label,refused=True,permanent_poison=len(before)>=1024))
    code,pending=selector.call('grow-original',s,ctl,bytes(1024));e=struct.unpack_from('<16Q',pending,256);assert code==384 and e[1]==1
    cont=ctl[:8]+struct.pack('<Q',2)+ctl[16:32]+struct.pack('<Q',e[4])+ctl[40:]
    for label,a,cnt in (('stale-sequence',s,cont[:32]+bytes(8)+cont[40:]),
                        ('changed-root',s,cont[:40]+struct.pack('<Q',1)+cont[48:]),
                        ('changed-graph-lease',s,cont[:136]+struct.pack('<Q',999)+cont[144:]),
                        ('changed-source-header',s[:48]+struct.pack('<Q',1)+s[56:],cont)):
        code,poisoned=selector.call(label,a,cnt,pending);assert code==BAD
        again,retained=selector.call(label+'-permanent',s,cont,poisoned);assert again==BAD and retained==poisoned
        controls.append(dict(case=label,permanent_poison=True))
    summary.update(status='PASS')
except BaseException as exc:
    summary.update(status='FAIL',error_class=type(exc).__name__,error=str(exc));traceback.print_exc();raise
finally:
    selector.close();codec.close();pipeline.close()
    summary.update(scope='DEVELOPMENT_COMPLETE_SELECTION_QUERY_CHAIN_NOT_PUBLIC_FOREIGN_CAPTURE_OR_FIXED_DRIVER',
                   cases=cases,private_controls=controls,actual_selector_entries=selector.entries,
                   actual_codec_entries=codec.entries,actual_native_queries=pipeline.requests,
                   actual_facts_entries=pipeline.facts.entries,actual_query_entries=pipeline.query.entries,
                   actual_packet_graph_entries=pipeline.bridge.entries,actual_issuer_entries=pipeline.issuer.entries,
                   actual_wire_entries=pipeline.wire.entries,elapsed_ns=time.monotonic_ns()-started,
                   all_pins_unchanged=all(p.read_bytes()==raw for p,raw in pins.items()),
                   pins={str(p):sha256(raw).hexdigest() for p,raw in pins.items()},whole_stack_closed=False)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','private_controls','pins')},sort_keys=True),flush=True)
    assert summary['all_pins_unchanged']
