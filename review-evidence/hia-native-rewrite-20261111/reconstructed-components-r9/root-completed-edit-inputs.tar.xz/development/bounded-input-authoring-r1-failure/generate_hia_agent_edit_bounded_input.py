"""Native caller budgets, exact wire/error wrapping and decode coordination.

Five policies retain separate original entry behavior: single response, batch
query, batch response, single-query comparison wire and prepared-query wire.
Peer results are private actual immutable native completions, never arbitrary
external buffers authenticated only by a header.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_selfhost import compact_authoring_cfg,total_scalar_functions
from tools import generate_hia_agent_edit_apply_graph as graph
from tools import generate_hia_agent_edit_query_packet as packet

CONSTANTS={
 'COMMAND':int.from_bytes(b'HIAQWC01','little'),'STATE':int.from_bytes(b'HIAQWW01','little'),
 'EVENT':int.from_bytes(b'HIAQWE01','little'),'RESULT':int.from_bytes(b'HIAQWO01','little'),
 'REPLY':int.from_bytes(b'HIAQWR01','little'),'WIRE_COMMAND':int.from_bytes(b'HIAGWC01','little'),
 'WIRE_EVENT':int.from_bytes(b'HIAGWE01','little'),'DECODE_COMMAND':int.from_bytes(b'HIADJC01','little'),
 'DECODE_EVENT':int.from_bytes(b'HIAJDE01','little'),'GRAPH_MAGIC':int.from_bytes(b'HIAGRF01','little'),
 'BAD':0xfffffffd,'MAX':(1<<64)-1,'RAW_BASE':8192,
}
NAMES=('MAGIC BAD PHASE LEASE REQUEST ROOT POLICY DIGITS SIZE GLEASE RAWLEN INOFF PEER NEED '
       'ERROR DOMAIN CAUSE DIAG DIAGLEN GRAPH GRAPH_LEN SUR_START SUR_END SUR_CP DETAIL').split()
CONSTANTS.update({'S_'+name:256+i*8 for i,name in enumerate(NAMES)})
WIRE_ERRORS=(
 'invalid JSON output byte budget','JSON string exceeds byte budget before encoding',
 'unpaired Unicode surrogate in UTF-8 JSON','JSON input exceeds nesting depth before encoding',
 'JSON input exceeds node/byte budget','JSON container exceeds queued-node/byte budget',
 'cyclic JSON container','unsupported JSON object key','JSON key exceeds numeric byte budget',
 'nonfinite JSON object key','JSON key exceeds byte budget','JSON object key collision after JSON conversion',
 'JSON integer exceeds byte budget','non-JSON in-process value','invalid bounded JSON','JSON encoding exceeds byte budget')
MESSAGES={
 1:'E_HIA_QUERY: response exceeds edit budget',
 2:'E_HIA_EDIT_BATCH: query exceeds byte budget',
 3:'E_HIA_EDIT_BATCH: response exceeds byte budget',
 4:'E_HIA_EDIT_BATCH: invalid query',
 5:'E_HIA_EDIT_BATCH: invalid response',
 6:'E_HIA_QUERY: query is not canonical JSON',
 30:"'utf-8' codec can't encode character '\\u",
 31:"' in position ",32:': surrogates not allowed',
 33:"'utf-8' codec can't encode characters in position ",34:'-',
}
MESSAGES.update({11+i:'E_HIA_EDIT: '+value for i,value in enumerate(WIRE_ERRORS)})
BODY=r'''
def bounded(s:readbuf, c:readbuf, w:mutbuf) -> u32:
    if length(w) < 1024:
        return BAD
    if get(w, S_BAD) != 0:
        return BAD
    if get(w, S_PHASE) >= 90:
        return invalid(w, 1)
    if get(w, S_MAGIC) == 0:
        if length(c) != 64 or word(c, 0) != COMMAND or word(c, 8) == 0 or word(c, 16) == 0:
            return invalid(w, 2)
        if word(c, 32) < 1 or word(c, 32) > 5 or word(c, 48) != 0 or word(c, 56) != 0:
            return invalid(w, 3)
        if graph_shape(s, 0, length(s)) == 0 or word(c, 24) == 0 or word(c, 24) > word(s, 16):
            return invalid(w, 4)
        at = 0
        while at < 1024:
            if byte(w, at) != 0:
                return invalid(w, 5)
            at = at + 1
        put(w, S_MAGIC, STATE)
        put(w, S_PHASE, 1)
        put(w, S_LEASE, word(c, 8))
        put(w, S_REQUEST, word(c, 16))
        put(w, S_ROOT, word(c, 24))
        put(w, S_POLICY, word(c, 32))
        put(w, S_DIGITS, word(c, 40))
        put(w, S_SIZE, length(s))
        put(w, S_GLEASE, word(s, 8))
        copy_bytes(w, s, 640, 0, 64)
        copy_bytes(w, c, 704, 0, 64)
    elif get(w, S_MAGIC) != STATE:
        return invalid(w, 6)
    if length(s) != get(w, S_SIZE):
        return invalid(w, 7)
    at = 0
    while at < 64:
        if byte(s, at) != byte(w, 640 + at):
            return invalid(w, 8)
        at = at + 1
    phase = get(w, S_PHASE)
    if phase == 1 or phase == 2:
        if length(c) != 64:
            return invalid(w, 9)
        at = 0
        while at < 64:
            if byte(c, at) != byte(w, 704 + at):
                return invalid(w, 10)
            at = at + 1
        return begin_input(s, w)
    if phase == 10 or phase == 11:
        return wire_reply(c, w)
    if phase == 20 or phase == 21:
        return decode_reply(c, w)
    return invalid(w, 11)

def maximum(w:mutbuf) -> u64:
    if get(w, S_POLICY) == 1:
        return 16384
    if get(w, S_POLICY) == 3:
        return 65536
    return 1048576

def begin_input(s:readbuf, w:mutbuf) -> u32:
    if length(w) < RAW_BASE:
        return grow(w, RAW_BASE)
    if get(w, S_PHASE) == 1:
        initialize_text(w)
        root = get(w, S_ROOT)
        kind = gkind(s, root)
        if get(w, S_POLICY) >= 4 or (kind != 4 and kind != 9):
            put(w, 512, WIRE_COMMAND)
            put(w, 520, get(w, S_GLEASE))
            put(w, 528, get(w, S_REQUEST))
            put(w, 536, root)
            put(w, 544, maximum(w))
            put(w, 552, 3)
            put(w, 560, get(w, S_DIGITS))
            put(w, 568, 0)
            put(w, S_PHASE, 10)
            put(w, S_PEER, 1)
            put(w, S_NEED, 0)
            return publish(w, 2)
        offset = word(s, root * 64 + 8)
        size = word(s, root * 64 + 16)
        if offset < length(s) - word(s, 40) or offset > length(s) or size > length(s) - offset:
            return invalid(w, 12)
        if kind == 4:
            status = unicode_scan(s, w, offset, size, word(s, root * 64 + 48))
            if status == 0:
                return invalid(w, 13)
            if status == 2:
                if get(w, S_POLICY) == 1:
                    return unicode_error(w)
                return own_error(w, choose(get(w, S_POLICY) == 2, 30, 31), 2, 0)
        if size > maximum(w):
            return own_error(w, get(w, S_POLICY), 0, 0)
        put(w, S_INOFF, offset)
        put(w, S_RAWLEN, size)
        put(w, S_PHASE, 2)
    if get(w, S_RAWLEN) > MAX - RAW_BASE:
        return invalid(w, 14)
    if length(w) < RAW_BASE + get(w, S_RAWLEN):
        return grow(w, RAW_BASE + get(w, S_RAWLEN))
    copy_bytes(w, s, RAW_BASE, get(w, S_INOFF), get(w, S_RAWLEN))
    return request_decode(w)

def utf_unit(s:readbuf, at:u64, end:u64) -> u64:
    first = byte(s, at)
    if first < 128:
        return 4294967296 | first
    width = 0
    value = 0
    minimum = 0
    if first >= 194 and first <= 223:
        width = 2
        value = first & 31
        minimum = 128
    elif first >= 224 and first <= 239:
        width = 3
        value = first & 15
        minimum = 2048
    elif first >= 240 and first <= 244:
        width = 4
        value = first & 7
        minimum = 65536
    else:
        return 0
    if width > end - at:
        return 0
    i = 1
    while i < width:
        unit = byte(s, at + i)
        if unit < 128 or unit > 191:
            return 0
        value = (value << 6) | (unit & 63)
        i = i + 1
    if value < minimum or value > 1114111:
        return 0
    return (width << 32) | value

def unicode_scan(s:readbuf, w:mutbuf, begin:u64, size:u64, expected:u64) -> u64:
    at = begin
    end = begin + size
    count = 0
    bad = 0
    while at < end:
        unit = utf_unit(s, at, end)
        if unit == 0:
            return 0
        value = unit & 4294967295
        if value >= 55296 and value <= 57343:
            if bad == 0:
                put(w, S_SUR_START, count)
                put(w, S_SUR_CP, value)
            bad = 1
            put(w, S_SUR_END, count + 1)
        elif bad != 0:
            return 2
        count = count + 1
        at = at + (unit >> 32)
    if count != expected:
        return 0
    if bad != 0:
        return 2
    return 1

def reply(c:readbuf, w:mutbuf, peer:u64) -> u64:
    if length(c) < 192 or word(c, 0) != REPLY or word(c, 8) != get(w, S_LEASE) or word(c, 16) != get(w, S_REQUEST):
        return 0
    if word(c, 24) != peer or word(c, 32) != 128 or word(c, 40) != length(c) - 64 or word(c, 48) != 0 or word(c, 56) != 0:
        return 0
    if get(w, S_PEER) != peer:
        return 0
    return 1

def pin_reply(c:readbuf, w:mutbuf, first:u64) -> u64:
    if first != 0:
        copy_bytes(w, c, 768, 0, 192)
    else:
        at = 0
        while at < 192:
            if byte(c, at) != byte(w, 768 + at):
                return 0
            at = at + 1
    return 1

def wire_reply(c:readbuf, w:mutbuf) -> u32:
    if reply(c, w, 1) == 0 or word(c, 40) < 32768:
        return invalid(w, 15)
    if word(c, 64) != WIRE_EVENT or word(c, 80) != get(w, S_GLEASE) or word(c, 88) != get(w, S_REQUEST):
        return invalid(w, 16)
    if word(c, 96) != get(w, S_ROOT) or word(c, 104) != maximum(w) or word(c, 112) != 3 or word(c, 120) != get(w, S_DIGITS):
        return invalid(w, 17)
    if word(c, 144) > word(c, 40) or word(c, 168) != 0 or word(c, 184) != 0:
        return invalid(w, 18)
    if word(c, 72) == 3:
        code = word(c, 128)
        cause = word(c, 136)
        if word(c, 176) != 99 or code < 1 or code > 16 or cause > 2 or word(c, 152) != 0 or word(c, 160) != 0:
            return invalid(w, 19)
        policy = get(w, S_POLICY)
        if policy == 2 or policy == 3:
            return own_error(w, choose(policy == 2, 30, 31), 1, cause)
        if policy == 4:
            return own_error(w, 32, 1, cause)
        return own_error(w, 100 + code, choose(cause == 0, 0, 2 + cause), 0)
    if word(c, 72) != 0 or word(c, 128) != 0 or word(c, 136) != 0 or word(c, 144) != 0 or word(c, 176) != 90:
        return invalid(w, 20)
    offset = word(c, 152)
    size = word(c, 160)
    if size > maximum(w) or offset < 32768 or offset > word(c, 40) or size > word(c, 40) - offset:
        return invalid(w, 21)
    if pin_reply(c, w, get(w, S_PHASE) == 10) == 0:
        return invalid(w, 22)
    put(w, S_PHASE, 11)
    put(w, S_RAWLEN, size)
    if length(w) < RAW_BASE + size:
        return grow(w, RAW_BASE + size)
    copy_bytes(w, c, RAW_BASE, 64 + offset, size)
    if get(w, S_POLICY) >= 4:
        return finish(w, 0)
    return request_decode(w)

def request_decode(w:mutbuf) -> u32:
    put(w, 512, DECODE_COMMAND)
    put(w, 520, get(w, S_LEASE))
    put(w, 528, get(w, S_REQUEST))
    put(w, 536, 9)
    put(w, 544, get(w, S_DIGITS))
    put(w, 552, 0)
    put(w, 560, 0)
    put(w, 568, 0)
    put(w, S_PHASE, 20)
    put(w, S_PEER, 2)
    put(w, S_NEED, 0)
    return publish(w, 2)

def decode_reply(c:readbuf, w:mutbuf) -> u32:
    if reply(c, w, 2) == 0 or word(c, 40) < 512:
        return invalid(w, 23)
    if word(c, 64) != DECODE_EVENT or word(c, 80) != get(w, S_LEASE) or word(c, 88) != get(w, S_REQUEST):
        return invalid(w, 24)
    if word(c, 104) > word(c, 40):
        return invalid(w, 25)
    at = 112
    while at <= 160:
        if word(c, at) != 0:
            return invalid(w, 26)
        at = at + 8
    action = word(c, 72)
    code = word(c, 168)
    if action == 3:
        if word(c, 96) != 99 or (code < 3 or (code > 6 and code < 101) or code > 120):
            return invalid(w, 27)
    elif action != 0 or word(c, 96) != 90 or code != 0:
        return invalid(w, 28)
    offset = word(c, 176)
    size = word(c, 184)
    if offset < 512 or offset > word(c, 40) or size == 0 or size > word(c, 40) - offset:
        return invalid(w, 29)
    if action == 0:
        if graph_shape(c, 64 + offset, size) == 0:
            return invalid(w, 30)
        if word(c, 64 + offset + 8) != get(w, S_LEASE) or word(c, 64 + offset + 24) != 1:
            return invalid(w, 31)
        if word(c, 64 + offset + 16) > 524287:
            return invalid(w, 32)
    if pin_reply(c, w, get(w, S_PHASE) == 20) == 0:
        return invalid(w, 33)
    if action == 0:
        if get(w, S_PHASE) == 20:
            copy_bytes(w, c, 960, 64 + offset, 64)
        else:
            at = 0
            while at < 64:
                if byte(c, 64 + offset + at) != byte(w, 960 + at):
                    return invalid(w, 34)
                at = at + 1
    put(w, S_PHASE, 21)
    base = (RAW_BASE + get(w, S_RAWLEN) + 7) & (MAX - 7)
    if size > MAX - base:
        return invalid(w, 35)
    if length(w) < base + size:
        return grow(w, base + size)
    copy_bytes(w, c, base, 64 + offset, size)
    if action == 0:
        put(w, S_GRAPH, base)
        put(w, S_GRAPH_LEN, size)
        return finish(w, 0)
    put(w, S_ERROR, 1000 + code)
    put(w, S_DOMAIN, 1)
    put(w, S_CAUSE, 3)
    put(w, S_DIAG, base)
    put(w, S_DIAGLEN, size)
    return finish(w, 3)

def own_error(w:mutbuf, code:u64, cause:u64, detail:u64) -> u32:
    index = code
    if code >= 101:
        index = code - 90
    elif code >= 30:
        index = code - 26
    at = message(w, index, 6144)
    put(w, S_ERROR, code)
    put(w, S_DOMAIN, 1)
    put(w, S_CAUSE, cause)
    put(w, S_DETAIL, detail)
    put(w, S_DIAG, 6144)
    put(w, S_DIAGLEN, at - 6144)
    return finish(w, 3)

def unicode_error(w:mutbuf) -> u32:
    at = 6144
    if get(w, S_SUR_END) == get(w, S_SUR_START) + 1:
        at = message(w, 30, at)
        index = 0
        while index < 4:
            digit = (get(w, S_SUR_CP) >> ((3 - index) * 4)) & 15
            store(w, at, choose(digit < 10, 48 + digit, 87 + digit))
            at = at + 1
            index = index + 1
        at = message(w, 31, at)
        at = decimal(w, get(w, S_SUR_START), at)
    else:
        at = message(w, 33, at)
        at = decimal(w, get(w, S_SUR_START), at)
        at = message(w, 34, at)
        at = decimal(w, get(w, S_SUR_END) - 1, at)
    at = message(w, 32, at)
    put(w, S_ERROR, 4)
    put(w, S_DOMAIN, 2)
    put(w, S_DIAG, 6144)
    put(w, S_DIAGLEN, at - 6144)
    return finish(w, 3)

def message(w:mutbuf, index:u64, at:u64) -> u64:
    start = get(w, 1280 + index * 16)
    size = get(w, 1288 + index * 16)
    i = 0
    while i < size:
        store(w, at + i, byte(w, start + i))
        i = i + 1
    return at + size

def decimal(w:mutbuf, value:u64, at:u64) -> u64:
    if value == 0:
        store(w, at, 48)
        return at + 1
    count = 0
    while value > 0:
        store(w, 1120 + count, 48 + value % 10)
        value = value // 10
        count = count + 1
    while count > 0:
        count = count - 1
        store(w, at, byte(w, 1120 + count))
        at = at + 1
    return at

def finish(w:mutbuf, action:u64) -> u32:
    put(w, S_PHASE, choose(action == 0, 90, 99))
    put(w, S_PEER, 0)
    put(w, S_NEED, 0)
    put(w, 1024, RESULT)
    put(w, 1032, get(w, S_POLICY))
    put(w, 1040, get(w, S_DOMAIN))
    put(w, 1048, get(w, S_ERROR))
    put(w, 1056, get(w, S_CAUSE))
    put(w, 1064, RAW_BASE)
    put(w, 1072, get(w, S_RAWLEN))
    put(w, 1080, get(w, S_GRAPH))
    put(w, 1088, get(w, S_GRAPH_LEN))
    put(w, 1096, get(w, S_DIAG))
    put(w, 1104, get(w, S_DIAGLEN))
    put(w, 1112, get(w, S_DETAIL))
    return publish(w, action)

def grow(w:mutbuf, needed:u64) -> u32:
    put(w, S_NEED, needed)
    return publish(w, 1)

def publish(w:mutbuf, action:u64) -> u32:
    peer = get(w, S_PEER)
    put(w, 0, EVENT)
    put(w, 8, action)
    put(w, 16, get(w, S_LEASE))
    put(w, 24, get(w, S_REQUEST))
    put(w, 32, get(w, S_PHASE))
    put(w, 40, get(w, S_NEED))
    put(w, 48, choose(action == 2, peer, 0))
    put(w, 56, choose(peer == 2 and action == 2, 1, 0))
    put(w, 64, choose(peer == 2 and action == 2, RAW_BASE, 0))
    put(w, 72, choose(action == 2, choose(peer == 1, get(w, S_SIZE), get(w, S_RAWLEN)), 0))
    put(w, 80, choose(action == 2, 512, 0))
    put(w, 88, choose(action == 2, 64, 0))
    put(w, 96, choose(action == 2, choose(peer == 1, 32768, 512), 0))
    put(w, 104, get(w, S_ERROR))
    put(w, 112, choose(action == 0 or action == 3, 1024, 0))
    put(w, 120, choose(action == 0 or action == 3, 96, 0))
    return 128

def invalid(w:mutbuf, reason:u64) -> u32:
    if get(w, S_BAD) == 0:
        put(w, S_BAD, reason)
    put(w, S_PHASE, 99)
    put(w, S_ERROR, BAD)
    publish(w, 3)
    return BAD
'''

def source_program():
    lines=['def initialize_text(w:mutbuf) -> u64:'];at=2048
    for code,text in sorted(MESSAGES.items()):
        raw=text.encode();lines.extend((f'    put(w, {1280+16*code}, {at})',f'    put(w, {1288+16*code}, {len(raw)})'))
        for index in range(0,len(raw),8):
            chunk=raw[index:index+8]
            if len(chunk)==8:lines.append(f'    put(w, {at+index}, {int.from_bytes(chunk,"little")})')
            else:
                for j,v in enumerate(chunk):lines.append(f'    store(w, {at+index+j}, {v})')
        at+=len(raw)
    assert at<6144
    lines.append('    return 0')
    tree=ast.parse(BODY+'\n'+'\n'.join(lines)+'\n')
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
    own=Expand().visit(tree).body
    helpers={node.name:node for node in ast.parse(graph.source_program()).body}
    tree=ast.Module(body=own+[helpers[name] for name in ('graph_shape','gkind','word','get','put')],type_ignores=[])
    return ast.unparse(ast.fix_missing_locations(tree))+'\n'

def document():
    nodes=ast.parse(source_program()).body;names={n.name:'f'+str(i+1) for i,n in enumerate(nodes)}
    signatures={n.name:([a.annotation.id for a in n.args.args],n.returns.id) for n in nodes};total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],'entry':'b0','blocks':[
        {'id':'b0','params':params,'ops':[{'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
        {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['bounded']}},
        {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=packet.QueryBuilder(node,names,signatures,total);builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],'returns':[builder.returns],
                          'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    return compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'agent_edit_bounded_input','functions':functions})

if __name__=='__main__':
    doc=document();path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/agent_edit_bounded_input.hiaasm';path.write_text(render_assembly(doc))
    print(path.name,path.stat().st_size,len(doc['functions']),sum(len(f['blocks']) for f in doc['functions']),
          max(len(f['blocks']) for f in doc['functions']),sum(len(b['ops']) for f in doc['functions'] for b in f['blocks']))
