"""Mechanical prefix/final command forwarding only."""
import struct
from packet_graph_harness import MAGIC

def command(roots,final,*,request=1,action=1,sequence=0):
    return (struct.pack('<16Q',MAGIC(b'HIAQBC01'),action,71,request,sequence,final,len(roots),*([0]*9))
            +struct.pack('<'+'Q'*len(roots),*roots))

def run(call,label,graph,control,compare=None):
    before=bytes(1024)
    while True:
        code,after=call(label,graph,control,before)
        if compare is not None:assert compare(graph,control,before)==(code,after)
        event=struct.unpack_from('<16Q',after,256)
        assert code==384,(label,code,event)
        assert event[0]==MAGIC(b'HIAQBE01')
        if event[1]!=1:return event,after
        assert event[5]>len(after)
        before=after+bytes(event[5]-len(after))
        control=control[:8]+struct.pack('<Q',2)+control[16:32]+struct.pack('<Q',event[4])+control[40:]
