"""Complete public Agent decode_json diagnostics and native Graph normalization.

Only development-time AST composition occurs in Python. The emitted HIA owns
input-kind/UTF-8/budget/syntax ordering, complete diagnostic text, continuation
validation, and the persistent normalized Graph copy.
"""
from __future__ import annotations
import ast
from pathlib import Path
from hepta.hia_agent_assembly import render_assembly
from hepta.hia_program import verify_program
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions
from tools.generate_hia_json_preflight import SOURCE as PREFLIGHT
from tools.generate_hia_arena_graph import BODY as ARENA_BODY

CONSTANTS={
 'COMMAND':int.from_bytes(b'HIADJC01','little'),'EVENT':int.from_bytes(b'HIAJDE01','little'),
 'STATE':int.from_bytes(b'HIAJDW01','little'),'REPLY':int.from_bytes(b'HIAJDR01','little'),
 'ARENA':int.from_bytes(b'HIADATA1','little'),'GRAPH':int.from_bytes(b'HIAGRF01','little'),
 'GRAPH_COMMAND':int.from_bytes(b'HIAGAC01','little'),
 'GRAPH_EVENT':int.from_bytes(b'HIAGAE01','little'),
 'BAD':0xfffffffd,'MAX':(1<<64)-1,'MIN_WORK':32768,'PF_BASE':8192,'KEY_BASE':32768,
}
_NAMES=('MAGIC BAD PHASE LEASE SEQ KIND DIGITS RAW NEED PEER READ READSIZE COMMAND COMMANDSIZE '
        'OUTSIZE WORKSIZE ERROR OUT OUTLEN ARENASIZE KEYS COUNT').split()
CONSTANTS.update({'S_'+name:256+i*8 for i,name in enumerate(_NAMES)})
REASONS={
 1:'expected JSON string',2:'unescaped control or isolated Unicode surrogate',
 3:'unterminated JSON escape',4:'invalid JSON escape',5:'invalid Unicode escape',
 6:'unpaired high Unicode surrogate',7:'unpaired low Unicode surrogate',
 8:'unterminated JSON string',9:'missing JSON value',10:'expected JSON integer or literal',
 11:'unexpected value completion',12:'extra JSON data',13:'incomplete JSON value',
 14:'expected array separator/end',15:'invalid array preflight state',
 16:'expected object field name',17:'expected object colon',
 18:'expected object separator/end',19:'invalid object preflight state',
 20:'invalid JSON syntax or Unicode'}
MESSAGES={
 1:'E_HIA_EDIT: JSON input must be text or bytes',
 2:'E_HIA_EDIT: JSON input exceeds byte limit',
 3:'E_HIA_EDIT: invalid JSON',
 4:'E_HIA_EDIT: JSON node/depth budget exceeded before decoding',
 5:'E_HIA_EDIT: invalid JSON: HIA JSON preflight: duplicate decoded object key',
 6:'E_HIA_EDIT: invalid JSON: Exceeds the limit (',
 7:' digits) for integer string conversion: value has ',
 8:' digits; use sys.set_int_max_str_digits() to increase the limit',
}
MESSAGES.update({100+k:'E_HIA_EDIT: invalid JSON: HIA JSON preflight: '+v for k,v in REASONS.items()})
TEXT_INDEX={code:i for i,code in enumerate(MESSAGES)}

BODY=r'''
def decode(s:readbuf, c:readbuf, w:mutbuf) -> u32:
    if length(w) < 512:
        return BAD
    if get(w, S_BAD) != 0 or get(w, S_PHASE) >= 90:
        return BAD
    if get(w, S_MAGIC) == 0:
        if length(c) != 64 or word(c, 0) != COMMAND or word(c, 8) == 0 or word(c, 16) == 0:
            return invalid(w, 1)
        if word(c, 24) > 9 or word(c, 40) != 0 or word(c, 48) != 0 or word(c, 56) != 0:
            return invalid(w, 2)
        at = 256
        while at < 512:
            if byte(w, at) != 0:
                return invalid(w, 3)
            at = at + 1
        put(w, S_MAGIC, STATE)
        put(w, S_PHASE, 1)
        put(w, S_LEASE, word(c, 8))
        put(w, S_SEQ, word(c, 16))
        put(w, S_KIND, word(c, 24))
        put(w, S_DIGITS, word(c, 32))
        put(w, S_RAW, length(s))
        copy_bytes(w, c, 128, 0, 64)
    elif get(w, S_MAGIC) != STATE:
        return invalid(w, 4)
    if length(s) != get(w, S_RAW):
        return invalid(w, 5)
    phase = get(w, S_PHASE)
    if phase == 1:
        if length(c) != 64:
            return invalid(w, 6)
        at = 0
        while at < 64:
            if byte(c, at) != byte(w, 128 + at):
                return invalid(w, 7)
            at = at + 1
        if length(w) < MIN_WORK:
            put(w, S_NEED, MIN_WORK)
            return publish(w, 1)
        initialize_text(w)
        kind = get(w, S_KIND)
        if kind != 4 and kind != 9:
            return semantic(w, 1, 0)
        if kind == 4 and utf_count(s, 0, length(s)) == MAX:
            return semantic(w, 3, 0)
        if length(s) > 8388608:
            return semantic(w, 2, 0)
        if kind == 9 and utf_count(s, 0, length(s)) == MAX:
            return semantic(w, 3, 0)
        bound = (length(s) >> 2) + 1
        if bound > 262144:
            bound = 262144
        slots = 2
        while slots < bound * 2:
            slots = slots * 2
        put(w, S_KEYS, slots * 8)
        need = KEY_BASE + slots * 8
        if length(w) < need:
            put(w, S_NEED, need)
            return publish(w, 1)
        put(w, PF_BASE + 48, 262144)
        put(w, PF_BASE + 56, 128)
        status = pf_preflight(s, w)
        reason = get(w, PF_BASE + 32)
        if status == 1:
            if reason < 1 or reason > 20:
                return invalid(w, 8)
            return semantic(w, 100 + reason, 0)
        if reason != 0:
            return invalid(w, 9)
        if status == 2:
            return semantic(w, 4, 0)
        if status == 4:
            return semantic(w, 5, 0)
        if status != 0:
            return invalid(w, 10)
        bound = ((length(s) + 1) >> 1) + 1
        if bound > 262144:
            bound = 262144
        output = 64 + bound * 56 + length(s)
        if output < 4256:
            output = 4256
        workspace = get(w, S_KEYS)
        if workspace < 6320:
            workspace = 6320
        put(w, 192, 262144)
        put(w, 200, 128)
        put(w, S_PHASE, 10)
        put(w, S_PEER, 1)
        put(w, S_READ, 0)
        put(w, S_READSIZE, length(s))
        put(w, S_COMMAND, 192)
        put(w, S_COMMANDSIZE, 16)
        put(w, S_OUTSIZE, output)
        put(w, S_WORKSIZE, workspace)
        put(w, S_NEED, 0)
        return publish(w, 2)
    if phase == 10 or phase == 11:
        if get(w, S_PEER) != 1 or validate_reply(c, w, 1) == 0:
            return invalid(w, 11)
        extent = word(c, 32)
        if word(c, 40) != get(w, S_OUTSIZE) or extent < 64 or extent > word(c, 40):
            return invalid(w, 12)
        if word(c, 64) != ARENA or word(c, 64 + 40) != length(s):
            return invalid(w, 13)
        count = word(c, 64 + 8)
        if count == 0 or count > 262144 or word(c, 64 + 16) != 64 + count * 56:
            return invalid(w, 14)
        if word(c, 64 + 16) > extent or word(c, 64 + 24) != extent or word(c, 64 + 32) != extent:
            return invalid(w, 15)
        if word(c, 64 + 48) != 1 or word(c, 64 + 56) != 0:
            return invalid(w, 16)
        if phase == 10:
            copy_bytes(w, c, 512, 0, 128)
        else:
            at = 0
            while at < 128:
                if byte(c, at) != byte(w, 512 + at):
                    return invalid(w, 32)
                at = at + 1
        put(w, S_PHASE, 11)
        put(w, S_COUNT, count)
        put(w, S_ARENASIZE, extent)
        need = KEY_BASE + 64 + length(s)
        if length(w) < need:
            put(w, S_NEED, need)
            return publish(w, 1)
        put(w, KEY_BASE, GRAPH_COMMAND)
        put(w, KEY_BASE + 8, get(w, S_LEASE))
        put(w, KEY_BASE + 16, get(w, S_SEQ))
        put(w, KEY_BASE + 24, length(s))
        put(w, KEY_BASE + 32, extent)
        put(w, KEY_BASE + 40, get(w, S_DIGITS))
        put(w, KEY_BASE + 48, 1)
        put(w, KEY_BASE + 56, 0)
        copy_bytes(w, s, KEY_BASE + 64, 0, length(s))
        put(w, S_PHASE, 20)
        put(w, S_PEER, 2)
        put(w, S_READ, 64)
        put(w, S_READSIZE, extent)
        put(w, S_COMMAND, KEY_BASE)
        put(w, S_COMMANDSIZE, 64 + length(s))
        put(w, S_OUTSIZE, 0)
        put(w, S_WORKSIZE, 512)
        put(w, S_NEED, 0)
        return publish(w, 2)
    if phase == 20 or phase == 21:
        if get(w, S_PEER) != 2 or validate_reply(c, w, 2) == 0 or word(c, 32) != 128 or word(c, 40) < 512:
            return invalid(w, 17)
        if word(c, 64) != GRAPH_EVENT or word(c, 80) != get(w, S_LEASE) or word(c, 88) != get(w, S_SEQ):
            return invalid(w, 18)
        if word(c, 152) != get(w, S_DIGITS) or word(c, 160) != 1 or word(c, 168) != 0 or word(c, 184) != 0:
            return invalid(w, 19)
        if word(c, 96) < 512 or word(c, 96) > word(c, 40):
            return invalid(w, 33)
        if word(c, 120) < get(w, S_COUNT) or word(c, 120) > get(w, S_COUNT) * 2 - 1:
            return invalid(w, 34)
        if word(c, 104) < 512 or word(c, 104) > word(c, 40):
            return invalid(w, 35)
        action = word(c, 72)
        if action == 3:
            if word(c, 128) != 1 or word(c, 176) != 99 or word(c, 112) != 0:
                return invalid(w, 20)
            if word(c, 136) >= get(w, S_COUNT) or word(c, 144) > length(s):
                return invalid(w, 36)
            if get(w, S_DIGITS) == 0 or word(c, 144) <= get(w, S_DIGITS):
                return invalid(w, 21)
            return semantic(w, 6, word(c, 144))
        if action != 0 or word(c, 128) != 0 or word(c, 136) != 0 or word(c, 144) != 0 or word(c, 176) != 90:
            return invalid(w, 22)
        if word(c, 96) > word(c, 40):
            return invalid(w, 23)
        offset = word(c, 104)
        size = word(c, 112)
        if offset < 512 or offset > word(c, 40) or size < 64 or size > word(c, 40) - offset:
            return invalid(w, 24)
        base = 64 + offset
        if word(c, base) != GRAPH or word(c, base + 8) != get(w, S_LEASE):
            return invalid(w, 25)
        count = word(c, base + 16)
        if count == 0 or count > 524287 or count != word(c, 120) or word(c, base + 24) != 1:
            return invalid(w, 26)
        if word(c, base + 48) != size or word(c, base + 56) != 0:
            return invalid(w, 27)
        edges = word(c, base + 32)
        if count * 64 > size - 64 or edges > (size - 64 - count * 64) >> 3:
            return invalid(w, 28)
        if word(c, base + 40) != size - 64 - count * 64 - edges * 8:
            return invalid(w, 29)
        if phase == 20:
            copy_bytes(w, c, 512, 0, 192)
            copy_bytes(w, c, 704, base, 64)
        else:
            at = 0
            while at < 192:
                if byte(c, at) != byte(w, 512 + at):
                    return invalid(w, 37)
                at = at + 1
            at = 0
            while at < 64:
                if byte(c, base + at) != byte(w, 704 + at):
                    return invalid(w, 38)
                at = at + 1
        put(w, S_PHASE, 21)
        if size > MAX - KEY_BASE:
            return invalid(w, 30)
        put(w, S_NEED, KEY_BASE + size)
        if length(w) < get(w, S_NEED):
            return publish(w, 1)
        copy_bytes(w, c, KEY_BASE, base, size)
        put(w, S_PHASE, 90)
        put(w, S_OUT, KEY_BASE)
        put(w, S_OUTLEN, size)
        put(w, S_PEER, 0)
        put(w, S_READ, 0)
        put(w, S_READSIZE, 0)
        put(w, S_COMMAND, 0)
        put(w, S_COMMANDSIZE, 0)
        put(w, S_OUTSIZE, 0)
        put(w, S_WORKSIZE, 0)
        return publish(w, 0)
    return invalid(w, 31)

def validate_reply(c:readbuf, w:mutbuf, peer:u64) -> u64:
    if length(c) < 64 or word(c, 0) != REPLY or word(c, 8) != get(w, S_LEASE) or word(c, 16) != get(w, S_SEQ):
        return 0
    if word(c, 24) != peer or word(c, 40) != length(c) - 64 or word(c, 48) != 0 or word(c, 56) != 0:
        return 0
    return 1

def publish(w:mutbuf, action:u64) -> u32:
    put(w, 0, EVENT)
    put(w, 8, action)
    put(w, 16, get(w, S_LEASE))
    put(w, 24, get(w, S_SEQ))
    put(w, 32, get(w, S_PHASE))
    put(w, 40, get(w, S_NEED))
    put(w, 48, get(w, S_PEER))
    put(w, 56, get(w, S_READ))
    put(w, 64, get(w, S_READSIZE))
    put(w, 72, get(w, S_COMMAND))
    put(w, 80, get(w, S_COMMANDSIZE))
    put(w, 88, get(w, S_OUTSIZE))
    put(w, 96, get(w, S_WORKSIZE))
    put(w, 104, get(w, S_ERROR))
    put(w, 112, get(w, S_OUT))
    put(w, 120, get(w, S_OUTLEN))
    return 128

def invalid(w:mutbuf, reason:u64) -> u32:
    put(w, S_BAD, reason)
    put(w, S_PHASE, 99)
    put(w, S_ERROR, BAD)
    publish(w, 3)
    return BAD

def semantic(w:mutbuf, code:u64, detail:u64) -> u32:
    at = copy_message(w, code, 1024)
    if code == 6:
        at = decimal(w, get(w, S_DIGITS), at)
        at = copy_message(w, 7, at)
        at = decimal(w, detail, at)
        at = copy_message(w, 8, at)
    put(w, S_ERROR, code)
    put(w, S_OUT, 1024)
    put(w, S_OUTLEN, at - 1024)
    put(w, S_PHASE, 99)
    put(w, S_NEED, 0)
    put(w, S_PEER, 0)
    put(w, S_READ, 0)
    put(w, S_READSIZE, 0)
    put(w, S_COMMAND, 0)
    put(w, S_COMMANDSIZE, 0)
    put(w, S_OUTSIZE, 0)
    put(w, S_WORKSIZE, 0)
    return publish(w, 3)

def copy_message(w:mutbuf, code:u64, at:u64) -> u64:
    index = message_index(code)
    source = get(w, 2048 + index * 16)
    size = get(w, 2056 + index * 16)
    i = 0
    while i < size:
        store(w, at + i, byte(w, source + i))
        i = i + 1
    return at + size

def decimal(w:mutbuf, value:u64, at:u64) -> u64:
    index = 19
    while index > 0 and value < get(w, 768 + index * 8):
        index = index - 1
    going = True
    while going:
        power = get(w, 768 + index * 8)
        digit = 0
        while value >= power:
            value = value - power
            digit = digit + 1
        store(w, at, 48 + digit)
        at = at + 1
        if index == 0:
            going = False
        else:
            index = index - 1
    return at

def word(s:readbuf, at:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(s, at + i) << (i * 8))
        i = i + 1
    return value

def get(w:mutbuf, at:u64) -> u64:
    value = 0
    i = 0
    while i < 8:
        value = value | (byte(w, at + i) << (i * 8))
        i = i + 1
    return value

def put(w:mutbuf, at:u64, value:u64) -> u64:
    i = 0
    while i < 8:
        store(w, at + i, value & 255)
        value = value >> 8
        i = i + 1
    return 0
'''

def preflight_functions():
    nodes=ast.parse(PREFLIGHT).body
    names={node.name for node in nodes}
    class Relocate(ast.NodeTransformer):
        def visit_FunctionDef(self,node):
            old=node.name
            if old in ('preflight','insert_key'):
                node.args.args=[arg for arg in node.args.args if arg.arg!='o']
            if old=='preflight':
                node.returns=ast.Name(id='u64',ctx=ast.Load())
            node=self.generic_visit(node)
            node.name='pf_'+old
            return node
        def visit_Call(self,node):
            name=node.func.id if isinstance(node.func,ast.Name) else None
            if name in ('get','put'):
                owner=node.args[0].id
                base='KEY_BASE' if owner=='o' else 'PF_BASE'
                assert owner in ('w','o')
                node.args[0]=ast.Name(id='w',ctx=ast.Load())
                node.args[1]=ast.BinOp(left=ast.Name(id=base,ctx=ast.Load()),op=ast.Add(),right=node.args[1])
                return self.generic_visit(node)
            if name=='length' and isinstance(node.args[0],ast.Name) and node.args[0].id in ('w','o'):
                owner=node.args[0].id
                return ast.BinOp(left=ast.Call(func=ast.Name(id='length',ctx=ast.Load()),
                      args=[ast.Name(id='w',ctx=ast.Load())],keywords=[]),
                      op=ast.Sub(),right=ast.Name(id='KEY_BASE' if owner=='o' else 'PF_BASE',ctx=ast.Load()))
            if name in ('preflight','insert_key'):
                node.args.pop(1)
            node=self.generic_visit(node)
            if name in names and name not in ('get','put'):node.func.id='pf_'+name
            return node
    return [Relocate().visit(node) for node in nodes if node.name not in ('get','put')]

def text_functions():
    lines=['def initialize_text(w:mutbuf) -> u64:']
    for i in range(20):lines.append(f'    put(w, {768+8*i}, {10**i})')
    offset=4096
    for code,text in MESSAGES.items():
        raw=text.encode('ascii');i=TEXT_INDEX[code]
        lines.extend([f'    put(w, {2048+16*i}, {offset})',f'    put(w, {2056+16*i}, {len(raw)})'])
        for begin in range(0,len(raw),8):
            part=raw[begin:begin+8].ljust(8,b'\0')
            lines.append(f'    put(w, {offset+begin}, {int.from_bytes(part,"little")})')
        offset+=(len(raw)+7)//8*8
    assert offset<8192
    lines.append('    return 0')
    lines.append('def message_index(code:u64) -> u64:')
    for code,i in TEXT_INDEX.items():lines.extend([f'    if code == {code}:',f'        return {i}'])
    lines.append('    return 0')
    return ast.parse('\n'.join(lines)).body

class CopyBuilder(Builder):
    def expr(self,expression):
        if (isinstance(expression,ast.Call) and isinstance(expression.func,ast.Name)
                and expression.func.id=='copy_bytes'):
            values=[self.expr(value) for value in expression.args]
            assert len(values)==5 and values[0][1]=='mutbuf' and values[1][1]=='readbuf'
            return self.op('buffer.copy_range',values[:2]+[self.cast(value,'usize') for value in values[2:]])
        return super().expr(expression)

def document():
    utf=next(node for node in ast.parse(ARENA_BODY).body if node.name=='utf_count')
    nodes=ast.parse(BODY).body+preflight_functions()+[utf]+text_functions()
    class Expand(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node) if node.id in CONSTANTS else node
    nodes=[Expand().visit(node) for node in nodes]
    names={node.name:'f'+str(i+1) for i,node in enumerate(nodes)}
    assert len(names)==len(nodes)
    signatures={node.name:([arg.annotation.id for arg in node.args.args],node.returns.id) for node in nodes}
    total=total_scalar_functions(nodes)
    params=[{'name':'v0','type':'readbuf'},{'name':'v1','type':'mutbuf'},{'name':'v2','type':'mutbuf'}]
    functions=[{'name':'f0','params':params,'returns':['u32'],'effects':['read','write','trap'],
      'entry':'b0','blocks':[{'id':'b0','params':params,'ops':[
       {'op':'borrow.read','args':['v1'],'out':[{'name':'v3','type':'readbuf'}],'attrs':{}},
       {'op':'call','args':['v0','v3','v2'],'out':[{'name':'v4','type':'u32'}],'attrs':{'function':names['decode']}},
       {'op':'loan.end','args':['v3'],'out':[],'attrs':{}}],'term':{'op':'ret','values':['v4']}}]}]
    for node in nodes:
        builder=CopyBuilder(node,names,signatures,total);builder.statements(node.body)
        functions.append({'name':names[node.name],'params':[builder.param(v) for v in builder.params],
          'returns':[builder.returns],'effects':['read','write','trap'],'entry':'b0','blocks':builder.blocks})
    result=compact_authoring_cfg({'schema':'hepta.hia.program.v8','module':'edit_decode','functions':functions})
    fs=result['functions']
    limits=(len(fs),sum(len(f['blocks']) for f in fs),sum(len(b['ops']) for f in fs for b in f['blocks']),
            max(len(f['blocks']) for f in fs),max(len(b['params']) for f in fs for b in f['blocks']))
    if any(a>b for a,b in zip(limits,(128,1536,8192,256,16))):
        raise ValueError({'original_compiler_limits_exceeded':limits})
    verify_program(result)
    return result

def main():
    doc=document();raw=render_assembly(doc)
    path=Path(__file__).resolve().parents[1]/'examples/hia_bootstrap/edit_decode.hiaasm'
    path.write_text(raw);fs=doc['functions']
    print(len(raw.encode()),len(fs),sum(len(f['blocks']) for f in fs),sum(len(b['ops']) for f in fs for b in f['blocks']),
          max(len(f['blocks']) for f in fs),max(len(b['params']) for f in fs for b in f['blocks']))
if __name__=='__main__':main()

