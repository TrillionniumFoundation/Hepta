# Native public Agent JSON decoding and normalization

## Scope

This independent HIA component implements the original `hepta.hia_program_tools.decode_json` input and diagnostic sequence, then produces a persistent normalized GraphLease through the actual general JSON arena decoder and the frozen arena-to-Graph owner. It is a development component. No public selector or ordinary application path has been changed.

The lower decoder ceiling is 8 MiB, 262,144 value nodes and depth 128. Calling entry points retain their own earlier budgets: single responses, batch responses and renderer queries must perform their original 16 KiB, 64 KiB or 1 MiB gates before this service where the original API did so. This component does not collapse these different layers.

Exact `str` input is mechanically represented by UTF-8 with surrogatepass; exact bytes retain all original bytes. Other exact source kinds are tagged as their GraphLease kind. This transport performs no admission. The HIA entry performs the original type refusal itself. Foreign Python subclass equality/conversion behavior and bounded arbitrary-object capture remain separate open work; no arbitrary Python object compatibility is claimed by this raw-input service.

## Original order retained

1. Exact input kind must be text or bytes.
2. Text undergoes complete strict UTF-8 validation before checking its encoded byte size. Thus an isolated surrogate has the original generic invalid-JSON result even if its hypothetical encoded bytes exceed the byte ceiling.
3. Bytes undergo the byte-size check before complete strict UTF-8 validation.
4. Only after the complete input passes UTF-8 does the original integer-only HIA preflight run. This is deliberately a complete earlier UTF-8 scan: a bad byte near the end retains priority over a grammar error at the beginning.
5. The embedded, unchanged preflight state machine chooses the original first grammar, duplicate-key or node/depth result. Its 20 diagnostic reasons are rendered as complete text by HIA.
6. The actual native general JSON decoder builds the value arena. Preflight acceptance restricts this call to the original integer JSON grammar.
7. The actual arena-to-Graph owner converts integer magnitudes and preserves value/string/map order. Integer digit-limit errors are rendered with the original complete public diagnostic. The resulting complete Graph is copied into the controller's owned workspace before publication.

The original preflight functions are relocated at authoring time; Python does not parse the request or compute its diagnostic. No hosted JSON decoder, integer parser or arena materializer is used in the execution loop.

## Entry and private custody

The actual image uses RWW ABI: immutable original input bytes, a second buffer borrowed read-only, and its private mutable workspace. The second buffer is either the initial 64-byte command or a complete actual peer reply. The workspace starts at zero and may grow. Fewer than 512 bytes return BAD because the state cannot safely be written; the fixed executor must then discard the session. At least 512 bytes persist the first ABI failure.

All sources, replies, generated images and workspaces belong to a fixed private issuer. Lease/request/header equality is correlation, not authentication of arbitrary externally supplied memory. GROW must replay the identical immutable original input and complete command/reply, copying all old workspace bytes. Raw pointers are not retained.

Initial command, eight little-endian u64 words:

`[HIADJC01, lease, request, inputKind, integerDigitLimit, 0, 0, 0]`

Lease and request are nonzero. Kind 4 is exact text; kind 9 is exact bytes; kinds 0 through 8 other than 4 produce the original public input-type error. Values outside the GraphLease kind set are a private ABI failure. The digit-limit value is the captured interpreter profile; zero disables the conversion limit.

## Events

An ordinary return is 128, with sixteen u64 words at workspace offset zero:

`[HIAJDE01, action, lease, request, phase, neededWorkspace, peerKind, readOffset, readBytes, commandOffset, commandBytes, peerOutputBytes, peerWorkspaceBytes, errorCode, outputOffset, outputBytes]`

Actions are 0 (complete Graph), 1 (GROW), 2 (call fixed peer), and 3 (complete user refusal). BAD is 0xfffffffd; on BAD the executor must discard the lease immediately and must not trust an old event header.

The final Graph or diagnostic is the bounded view specified by the last two words. Final phase 90 is successful; phase 99 is a user or private refusal. Any later call permanently refuses.

### Peer 1: general JSON arena decoder

The source view is in the first input buffer. HIA supplies the complete 16-byte `[262144,128]` configuration in its command view. The executor allocates the requested output/workspace, copies these two words to the existing decoder workspace offset 48, and invokes the source-bound decoder exactly once. The requested sizes use the existing `arena_sizes` formula; they do not add a language limit.

The reply is a 64-byte header followed by the entire actual allocated decoder output:

`[HIAJDR01, lease, request, 1, actualReturn, allocatedOutputBytes, 0, 0] + output`

The controller checks the complete frame, return/extent and actual arena header before exposing the arena view to peer 2. An unexpected decoder failure after the independent preflight has passed is a private dependency failure, not a replacement user diagnostic.

### Peer 2: arena-to-Graph

The source view is in the retained peer-1 reply. The command view is a complete native `HIAGAC01` header plus the identical original raw input, generated by HIA. The executor invokes the actual frozen arena-to-Graph image, mechanically serving that image's own GROW events, and retains all actual buffers.

The reply is:

`[HIAJDR01, lease, request, 2, 128, actualWorkspaceBytes, 0, 0] + actualWorkspace`

The controller validates the complete final `HIAGAE01` event, its lease/request/profile/phase, graph extent/header and all bounded view arithmetic. It copies the complete Graph before returning it. No later use depends on the peer's reusable output storage.

### Growth

Phase 1 GROW repeats the initial 64-byte command. Phase 11 GROW repeats the complete peer-1 reply. Phase 21 GROW repeats the complete peer-2 reply. Sequence and ownership do not advance during these retries, and no peer call is repeated solely to satisfy controller workspace growth.

## Errors

Complete public text is produced in HIA. Error codes 1 through 6 identify input type, byte size, generic invalid UTF-8/text, node/depth, duplicate key and integer-digit conversion failures. Codes 101 through 120 identify the original twenty preflight reasons. Codes are private metadata; callers must not replace the already-produced text with a less precise message.

This component does not manufacture Python traceback or exception-cause objects. Public wrapper integration must preserve the original externally visible exception class and applicable cause category without redoing JSON parsing. That wrapper is not activated by this development artifact.


## Development r2 frame tightening

The first actual r1 public differential passed 676 cases. Separate actual peer-frame mutation controls then showed that success error-index metadata and a refused integer's out-of-range arena index were not checked. Their accepted r1 frames and exact inputs are preserved as private ABI counterexamples; they are not public JSON counterexamples. Revision r2 checks all completion/error metadata and recorded arena/node/count bounds, and pins complete headers across controller GROW retries. This does not authenticate a mutated payload with an identical header: the immutable fixed-issuer lease remains required. The original r1 image and tests are retained separately.
