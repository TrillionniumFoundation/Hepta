# Issued general JSON arena to GraphLease — ABI r1

This private HIA component replaces the value conversion work needed to turn an
actually issued general JSON arena into the existing general GraphLease. It does
not authenticate externally supplied arenas or claim public foreign graph capture
is bounded. The fixed predecessor retains the arena and its original raw JSON as
immutable, inseparable leases throughout all calls, including GROW. Header equality
alone does not prove that the two buffers have common provenance.

## Inputs and event

The external ABI is the original read/write/write form. Input one is the exact
HIADATA1 arena returned by the pinned agent_data_json image, including its exact
used length. Input two is borrowed read-only internally and contains this 64-byte
header followed immediately by the complete original JSON wire:

`[HIAGAC01, lease, request, rawBytes, arenaBytes, integerDigitLimit, finiteOnly, 0]`

All fields are little-endian u64. Lease and request are nonzero. finiteOnly is
zero or one. integerDigitLimit records the existing runtime compatibility profile
(usually 4300; zero means disabled); it is not a new language quota. A valid
integer with more digits produces a conversion refusal before allocating its
magnitude. finiteOnly=1 matches the existing NativeAgentDataJson default, which
rejects an overflowing decimal number. finiteOnly=0 preserves the resulting
positive/negative infinity IEEE bits for a caller whose existing semantic gate
occurs later. Neither mode changes JSON syntax.

A fresh workspace is zero initialized and at least 512 bytes. The image returns
128 for each event and writes sixteen little-endian words at workspace offset 0:

`[HIAGAE01, action, lease, request, neededWorkspace, graphOffset, graphBytes,`
` graphNodes, conversionError, arenaIndex, errorValue, integerDigitLimit,`
` finiteOnly, abiReason, phase, 0]`

Action 0 is complete GraphLease, action 1 requests GROW, action 3 is a semantic
conversion refusal. Conversion error 1 is the runtime integer digit limit, with
errorValue equal to the encountered digit count and arenaIndex locating the
number. Error 2 is nonfinite decimal conversion under finiteOnly=1. No partial
Graph is published on failure. Every semantic refusal or ABI failure permanently
ends the workspace session. ABI failure returns 0xfffffffd; the driver checks
that return before reading any previous event. Buffers shorter than the state
header cannot be poisoned safely and require unconditional driver disposal.

GROW copies the complete old workspace into at least neededWorkspace bytes and
replays the same immutable arena and complete command/raw input. This component
does not advance a command sequence or restart a partially published result.
Source headers and command fields are rechecked, but private immutable custody is
required for the payloads. The published Graph is a view owned by the workspace;
a later allocator must retain or copy it before releasing the workspace.

## Native computation and original boundaries

The HIA implementation checks the full arena header, exact total extent, original
one-parent ownership and sibling chains, valid UTF-8/string extents, object key
ranges and uniqueness. It preserves each container's child order. The original
arena producer's maximum one-million-node representation is retained; its public
callers choose their own original smaller budgets. This bridge adds no call or
session-wide quota.

Every JSON value gets a Graph node and every object key a separate string node.
Container IDs are one based; object keys and values are paired edges. All string
bytes and number magnitudes are copied into the owned Graph pool. Zero integers
and empty strings still receive a valid pool cursor for their empty payload.

Integers are converted in HIA directly from decimal lexemes to minimal
little-endian magnitudes, without a foreign int conversion. Fraction/exponent
lexemes use the existing exact HIA binary64 rounding algorithm with relocated
scratch, without a foreign float conversion. Strings get native UTF-8 code-point
counts. Source/arena validation and whole-tree ownership complete before output
conversion or publication. The original agent_data_json parser remains the owner
of actual syntax, Unicode escape and duplicate-key admission. A forged matching
arena/wire pair is not an authenticated public input merely because this bridge
can interpret it.

This development component is not yet selected by ordinary renderer entry points.
It is separate from the already frozen Graph bounded-wire r3 and the root's
trusted integer typed-packet bridge. Full renderer validation and error order,
raw-text batch preflight, and bounded foreign object capture remain separate work.
