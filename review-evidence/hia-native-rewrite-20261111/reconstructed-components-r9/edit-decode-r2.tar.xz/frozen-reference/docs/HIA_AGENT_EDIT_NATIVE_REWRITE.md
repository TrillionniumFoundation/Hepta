# Native edit query and simultaneous batch: implementation contract

This is a new development worktree based on the exact published commit
`0ef9541b2fc12f4b01ab5078b05d0b304cfa90f5`. It is not installed or selected and
does not retire any existing implementation. The full remaining owners are
`hepta/hia_edit_query.py` and `hepta/hia_edit_batch.py`, together with their
name/fact transport and complete query/response/rendering orchestration.

The existing HIA slice algorithm already owns same-block dependency closure,
FIFO inter-block propagation, affected branch regions and original view limits.
This work will keep that algorithm and move the remaining decisions into HIA.
The independently retained Python implementations supply differential oracles.

## Complete retained behavior

Query preparation verifies and freezes the original program before checking
field selection. Fields must be a unique nonempty subset of `op`, `args`, and
`attrs`; the complete query sorts them. It checks selector kinds, then resolves
function, block and the unique SSA-producing instruction in that order. Every
name comparison uses full bytes, and two outputs of one instruction select the
same instruction. The native slice result determines the exact dependencies,
consumers and downstream regions. Visible calls select callee signatures in
program declaration order. Query v3 preserves return-loan origins; earlier
program schemas retain query v2.

Preparation retains the original input digest separately from the normalized
program digest. It hashes the exact canonical operation wire and checks the
complete 1 MiB query budget after construction. No truncated context is accepted.
The existing 256-operation and 64-block visible-context limits remain unchanged.

Applying an edit first admits and captures the original program, validates the
query selector, reconstructs the complete original query, and compares canonical
bytes. Boolean, integer and floating-point values cannot compare equal merely
because a host language equates them. The response is at most 16 KiB; only
selected fields may change. The unchanged complete patch and Core-admission
owners verify the resulting whole program. The receipt retains exact query and
response digests, raw response byte length and the original selectors.

Batch preparation accepts 1 through 16 ordered selections. Overlap is checked
by function, block and instruction index, including distinct outputs of one
instruction. All sites refer to the same immutable program snapshot. The batch
query has the original 1 MiB limit. Application reconstructs that exact ordered
query, admits at most 64 KiB of response, checks every site occurs once, and
applies all replacements simultaneously through one whole-program patch. No
intermediate candidate is admitted. Response order remains the patch edit order.

Single and batch presentation must preserve the complete existing validators,
identifier checks, operation ordering, signature/CFG metadata consistency,
cross-site deduplication, selected-site annotations and exact text. Presentation
is an untrusted display input; it cannot reuse the weaker assumption that every
query came from preparation. Valid display attributes can contain general JSON
values, including finite binary64 values. The integer-only composite packet
codec is not sufficient for that complete presentation domain.

## Native composition and custody

Public program and control JSON retain their original independent byte and
depth limits. Wrapping a legal 8 MiB program in a transport envelope must not
add a new public node/depth/byte admission point. Complete primitive Core
admission covers v1 through v8; composite normalization depends on the complete
native composite coordinator under separate development.

The fact projector consumes an immutable, genuinely issued SourceIndexLease.
The source contains the captured verified program and one selection. The fixed
coordinator must retain the actual source packet, native validator/index result
and successful program-admission result for that exact program. A matching
header, digest or node bit does not authenticate an arbitrary external buffer.
All BAD returns discard the private workspace immediately, including buffers
too short to hold a poison marker.

The generic source-view helpers are an exact authoring-time copy of the
durable stage-9 source (`555472263213f15deb239fcf3bf8e5b273a28caf3a67bb29ffd037f171d7ae5c`).
They read typed source nodes or the completed 80-byte object-token IR. The fact
projector needs source nodes only. This IR is different from the earlier
32-byte segmented function renderer IR; their offsets and operations must never
be mixed.

The first new kernel owns field/selector admission, name resolution and the
complete normalized function fact packet. It must match every byte emitted by
`encode_function`, including declaration-order value numbering and the duplicate
terminator/edge argument ranges. A native open-addressed name table uses full
byte comparisons after hashing; hashes never decide identity. It emits the
existing `HIASLC01` packet for the actual HIA slice kernel. It does not choose a
slice, publish a query or claim the full coordinator is complete.

Storage grows from actual counts through an explicit continuation; storage
capacity is not a new semantic quota. The existing 8 MiB fact packet limit is
retained separately from public Core limits. A conservative charge of at most
16 fact bytes per independently bounded Core value node, plus the 64-byte
header, keeps admitted functions below that fact limit: block metadata charges
its dictionary/parameter-list/operation-list/terminator nodes; operation metadata
charges its dictionary/argument-list/output-list nodes; value entries charge
their typed declaration nodes; edges charge their target/argument-list nodes;
argument links, including the duplicated edge ranges, charge at most 16 bytes
per argument node. These charges use disjoint node classes. This reasoning is
to be checked against actual maximum-size witnesses and the original Core node
counter before it is used as a composition premise.

## Required completion gates

Every new kernel must pass the ordinary Core verifier, compile through the
unchanged actual HIA compiler, and execute complete independent differential
controls. Tests must include all existing single/batch query and presentation
cases, all retained program versions, returned loans, original error ordering,
real size boundaries, branch reconvergence/cycles, no-result effects, multi-result
overlap, forged presentation, duplicate JSON fields and scalar-kind distinctions.

The complete fixed driver must use actual native decoding, admission, slicing,
hashing, query construction, response construction, patching and final
materialization. Test-only codecs, synthetic handoffs and private kernel calls
are component evidence. They do not qualify a public native path. Current-source
cold and complete retained application/installation acceptance remain necessary
before changing the product default or retiring hosted owners.

