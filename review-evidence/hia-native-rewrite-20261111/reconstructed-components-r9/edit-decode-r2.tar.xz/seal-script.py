"""Seal both development revisions, actual raw frames and exact dependencies."""
from pathlib import Path
from hashlib import sha256
import json,tarfile,stat
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
ARCHIVE=BASE/'hia-edit-decode-r2-development.tar.xz'
selected={}
def add(path,name=None):
    path=Path(path)
    if path.is_dir():
        for child in sorted(path.rglob('*')):
            if child.is_file() and '__pycache__' not in child.parts and child.suffix!='.pyc':
                add(child,(Path(name)/child.relative_to(path)).as_posix() if name else None)
    else:
        key=name or path.relative_to(ROOT).as_posix()
        assert key not in selected or selected[key]==path
        selected[key]=path
for name in ['tools/generate_hia_edit_decode.py','examples/hia_bootstrap/edit_decode.hiaasm',
             'docs/HIA_EDIT_DECODE_ABI.md','docs/HIA_EDIT_DECODE_DEVELOPMENT_R2.md','dependencies/f50-B3.image.bin']:
    add(ROOT/name)
for path in sorted((ROOT/'development').iterdir()):
    if path.name.startswith(('edit-decode-','edit_decode_','compile_edit_decode_')):add(path)
for path in sorted((ROOT/'checkpoints').iterdir()):
    if path.name.startswith('edit-decode-'):add(path)
add(ROOT/'checkpoints/arena-graph-source-r2','frozen-arena-graph/source-r2')
add(ROOT/'development/arena-graph-compile-r2','frozen-arena-graph/compile-r2')
for name in ['arena_graph_harness_r2.py','graph_harness_r3.py']:
    add(ROOT/'development'/name,'frozen-reference-harnesses/'+name)
add(ROOT/'reference','frozen-reference')
add(Path(__file__),'seal-script.py')
manifest=[]
for name,path in sorted(selected.items()):
    raw=path.read_bytes()
    manifest.append({'path':name,'source_path':str(path),'bytes':len(raw),
                     'mode':stat.S_IMODE(path.stat().st_mode),'sha256':sha256(raw).hexdigest()})
print(json.dumps({'phase':'inventory','members':len(manifest),'raw_bytes':sum(r['bytes'] for r in manifest)}),flush=True)
with tarfile.open(ARCHIVE,'w:xz',preset=3) as tar:
    for row in manifest:tar.add(row['source_path'],arcname=row['path'],recursive=False)
print(json.dumps({'phase':'archive_written','bytes':ARCHIVE.stat().st_size}),flush=True)
with tarfile.open(ARCHIVE,'r:xz') as tar:
    members=tar.getmembers();assert len(members)==len(manifest)
    expected={row['path']:row for row in manifest}
    for member in members:
        row=expected.pop(member.name);raw=tar.extractfile(member).read();path=Path(row['source_path'])
        assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'] and member.mode==row['mode']
        assert raw==path.read_bytes() and stat.S_IMODE(path.stat().st_mode)==row['mode']
    assert not expected
raw=ARCHIVE.read_bytes()
custody={'schema':'hepta.hia.edit-decode-development-custody.v1','status':'PASS',
 'archive_path':str(ARCHIVE),'archive_bytes':len(raw),'archive_sha256':sha256(raw).hexdigest(),
 'member_count':len(manifest),'uncompressed_file_bytes':sum(r['bytes'] for r in manifest),
 'archive_members_equal_live_bytes_sha256_and_mode':True,
 'scope':'PUBLIC_DECODE_HIA_SEMANTICS_DEVELOPMENT_NOT_PUBLIC_WRAPPER_OR_COLD',
 'r2_final_cases':763,'r2_final_entries':{'controller':2890,'decoder':367,'graph':734},
 'r1_public_cases_retained':691,'r1_private_counterexamples_retained':2,
 'public_foreign_capture_closed':False,'batch_renderer_implemented':False,
 'members':manifest}
p=Path(str(ARCHIVE)+'.custody.json');p.write_text(json.dumps(custody,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in custody.items() if k!='members'},indent=2,sort_keys=True),flush=True)
print(json.dumps({'custody_path':str(p),'custody_bytes':p.stat().st_size,'custody_sha256':sha256(p.read_bytes()).hexdigest()}),flush=True)

