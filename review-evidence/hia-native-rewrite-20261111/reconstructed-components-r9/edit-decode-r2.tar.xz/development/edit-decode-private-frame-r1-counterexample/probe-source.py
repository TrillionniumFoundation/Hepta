"""Preserve a real r1 completion-frame validation counterexample."""
from pathlib import Path
import ctypes,hashlib,json,shutil,struct
from edit_decode_harness_r1 import Actual,ROOT,workspace
source=ROOT/'development/edit-decode-smoke-r1-attempt1'
rows=[json.loads(line) for line in (source/'entries.jsonl').read_text().splitlines()]
actual=Actual(ROOT/'development/edit-decode-private-frame-r1-counterexample')
results=[]
try:
    for name,at,value in [('null',136,1),('bigint',136,999999)]:
        row=next(r for r in rows if r['case']==name and r['role']=='controller' and r['event'][4] in (90,99) and r['event'][13] in (0,6))
        def raw(key):return(source/'raw'/row[key]['path']).read_bytes()
        before=raw('before');control=bytearray(raw('second'));original=bytes(control)
        struct.pack_into('<Q',control,at,value)
        w=workspace(len(before));ctypes.memmove(w,before,len(before))
        ret,event=actual.invoke(raw('source'),bytes(control),w,len(before),name+'-mutated-error-index')
        results.append({'case':name,'mutated_byte_offset':at,'value':value,'return':ret,'event':event,
                        'accepted_private_malformed_frame':ret==128,
                        'original_control':actual.raw(original)})
finally:
    actual.close()
    shutil.copy2(__file__,actual.out/'probe-source.py')
    report={'scope':'PRIVATE_ACTUAL_PEER_FRAME_COMPLETENESS_NOT_PUBLIC_JSON_COUNTEREXAMPLE',
            'status':'CONFIRMED_R1_MISSING_ERROR_INDEX_VALIDATION','cases':results,'entries':actual.entries}
    (actual.out/'summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,sort_keys=True),flush=True)

