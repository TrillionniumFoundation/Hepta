"""Independent ordered public decode differential, including real public ceilings."""
from pathlib import Path
import hashlib,json,random,resource,shutil,sys,time
from edit_decode_harness_r1 import Actual,ROOT

def cases():
    small=[
      ('bool-true',True),('int',1),('float',1.5),('list',[]),('dict',{}),('tuple',()),
      ('bytearray',bytearray(b'null')),('memoryview',memoryview(b'null')),
    ]
    class SubStr(str):pass
    class SubBytes(bytes):pass
    small.extend([('str-subclass',SubStr('null')),('bytes-subclass',SubBytes(b'null'))])
    syntax=['',' ','\n\t','[','{','"','"\\','"\\x"','"\\u0"','"\\u000g"','"\\u😺000"',
            '"\\uD800"','"\\uDC00"','"\\uD800\\uD800"','"\\uD800x\\uDC00"',
            '"\\uD800\\u0041"','"\\uD800\\uDC00"','"\\udbff\\udfff"',
            '"\x00"','"\x1f"','"\ud800"','"\udfff"','[1','[1 2]','[1,]',
            '{"x"}','{"x":}','{"x":','{"x":1','{"x":1 "y":2}','{1:2}','{,}','[,]',
            'nul','truefalse','00','-00','-','+1','NaN','Infinity','-Infinity',
            '1.25','[1.25]','{"x":1.25}','1e3','[1e3]','{"x":1e3}',
            '١','[١]','null\x00','\x00null','null null','{}[]',
            '{"":1,"":2}','{"a":1,"\\u0061":2}','{"é":1,"\\u00e9":2}',
            '{"😀":1,"\\ud83d\\ude00":2}','{"a":{"x":1},"b":{"x":2}}',
            '{"a":1,"b":{"a":2}}','{"a":1,"a": [','{"a":1,"a"}',
            '"\\/\\b\\f\\n\\r\\t\\\\\\\""','"𐀀é水\u007f"',
            '-0','0','-9223372036854775809','18446744073709551616']
    small += [('grammar-'+str(i),s) for i,s in enumerate(syntax)]
    for n,p in small:yield n,p,4300
    invalid=[b'\x80',b'\xbf',b'\xc0\x80',b'\xc1\xbf',b'\xc2',b'\xe0\x80\x80',
             b'\xed\xa0\x80',b'\xed\xbf\xbf',b'\xf0\x80\x80\x80',
             b'\xf4\x90\x80\x80',b'\xf5\x80\x80\x80',b'\xff',b'\xe2\x28\xa1']
    for i,p in enumerate(invalid):
        yield 'bad-utf8-root-'+str(i),p,4300
        yield 'bad-utf8-after-syntax-'+str(i),b'! '+p,4300
        yield 'bad-utf8-after-valid-'+str(i),b'{"a":1} '+p,4300
    for encoding in ['utf-16-le','utf-16-be','utf-32-le','utf-32-be']:
        for bom in [False,True]:
            p='{"a":1}'.encode(encoding)
            if bom:p={'utf-16-le':b'\xff\xfe','utf-16-be':b'\xfe\xff',
                      'utf-32-le':b'\xff\xfe\0\0','utf-32-be':b'\0\0\xfe\xff'}[encoding]+p
            yield 'foreign-'+encoding+'-'+str(bom),p,4300
    for p in [b'\xef\xbb\xbfnull',b'\0',b'\0\0',b'\0n',b'n\0',b'null\0',b'\0null']:
        yield 'nul-bom-'+p.hex(),p,4300
    for limit in [0,640,4300]:
        for count in [639,640,641,4299,4300,4301,5000]:
            for sign in ['', '-']:
                yield 'digits-'+str(limit)+'-'+str(count)+'-'+str(bool(sign)),sign+'7'*count,limit
    for suffix in [',"x":0,"x":1}',',"x":}',',"x":1.25}',',"x":1}']:
        yield 'integer-late-'+suffix,'{"large":'+'7'*4301+suffix,4300
    for n in [127,128,129,130]:
        yield 'depth-value-'+str(n),'['*n+'0'+']'*n,4300
        yield 'depth-empty-'+str(n),'['*n+']'*n,4300
    rng=random.Random(981207)
    def value(depth=0):
        if depth<4 and rng.randrange(4)==0:
            if rng.randrange(2):return [value(depth+1) for _ in range(rng.randrange(5))]
            return {str(i)+rng.choice(['','é','水']):value(depth+1) for i in range(rng.randrange(5))}
        return rng.choice([None,True,False,rng.randrange(-10**35,10**35),
                          ''.join(rng.choice(['a','é','水','😀','\n','"','\\','\0']) for _ in range(rng.randrange(15)))])
    alphabet=' []{}:,"\\u0123456789-.+eabcdefnrtXYZ\n\t'
    for i in range(240):
        text=json.dumps(value(),ensure_ascii=bool(i&1),separators=(',',':'))
        yield 'random-valid-'+str(i),text,4300
        j=rng.randrange(len(text)+1)
        if i%3==0:mut=text[:j]+rng.choice(alphabet)+text[j:]
        elif i%3==1:mut=text[:j]+text[j+1:]
        else:mut=text[:j]+rng.choice(alphabet)+text[j+1:]
        yield 'random-mutant-'+str(i),mut,4300
    # Full, unchanged public ceilings: keys are not nodes, root is depth zero.
    yield 'many-object-keys','{'+','.join(json.dumps(str(i))+':0' for i in range(8192))+'}',4300
    for total in [262143,262144,262145]:
        yield 'actual-node-ceiling-'+str(total),'['+','.join('0' for _ in range(total-1))+']',4300
    yield 'node-over-before-late-syntax','['+','.join('0' for _ in range(262144))+',?]',4300
    yield 'exact-8MiB-string','"'+'a'*(8388608-2)+'"',4300
    yield 'over-8MiB-bytes',b' '*8388608+b'\xff',4300
    yield 'exact-8MiB-invalid-utf8-after-syntax',b'!'+b' '*(8388608-2)+b'\xff',4300
    yield 'over-8MiB-str-surrogate',' '*8388608+'\ud800',4300
    yield 'over-8MiB-str-ascii',' '*8388609,4300

def main():
    resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(90,90))
    actual=Actual(ROOT/'development/edit-decode-differential-r1-attempt1');rows=[]
    own=Path(__file__).read_bytes();harness=Path(__file__).with_name('edit_decode_harness_r1.py').read_bytes()
    (actual.out/'test-source.py').write_bytes(own);(actual.out/'harness-source.py').write_bytes(harness)
    start=time.monotonic_ns();status='FAIL'
    try:
        for name,payload,digits in cases():
            rows.append(actual.check(payload,name,digits))
        status='PASS'
    finally:
        actual.close()
        assert Path(__file__).read_bytes()==own
        assert Path(__file__).with_name('edit_decode_harness_r1.py').read_bytes()==harness
        summary={'status':status,'case_count':len(rows),'cases':rows,'entries':actual.entries,
          'wall_elapsed_ns':time.monotonic_ns()-start,'source_before_after_exact':True,
          'test_sha256':hashlib.sha256(own).hexdigest(),'harness_sha256':hashlib.sha256(harness).hexdigest(),
          'scope':'ACTUAL_HIA_PUBLIC_DECODE_WITH_ORIGINAL_BYTE_NODE_DEPTH_LIMITS_DEVELOPMENT'}
        (actual.out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
        print(json.dumps({k:v for k,v in summary.items() if k!='cases'},sort_keys=True),flush=True)
if __name__=='__main__':main()

