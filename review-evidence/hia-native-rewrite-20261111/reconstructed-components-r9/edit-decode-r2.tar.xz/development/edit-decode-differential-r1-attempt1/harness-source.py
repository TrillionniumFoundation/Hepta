"""Actual public-decode HIA controller plus its two fixed native peers."""
from pathlib import Path
from hashlib import sha256
import ctypes, importlib.util, json, os, struct, sys, time
from contextlib import ExitStack
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/workspace/scratch/9acdfa9f5639/Hepta-agent-edit-native')
sys.path.insert(0,str(BASE))
from hepta.hia_json_preflight_native import NativeHiaJsonImage
from hepta.hia_program_tools import decode_json as reference_decode
spec=importlib.util.spec_from_file_location('decode_arena_reference_r2',ROOT/'development/arena_graph_harness_r2.py')
ag=importlib.util.module_from_spec(spec);spec.loader.exec_module(ag)
MAGIC=lambda text:int.from_bytes(text,'little')
COMMAND=MAGIC(b'HIADJC01');EVENT=MAGIC(b'HIAJDE01');REPLY=MAGIC(b'HIAJDR01')
GRAPH_EVENT=MAGIC(b'HIAGAE01');BAD=0xfffffffd;CANARY=b'\xa7'*32
LEASE=41;REQUEST=1

def input_wire(value):
    typ=type(value)
    if typ is str:return value.encode('utf-8','surrogatepass'),4
    if typ is bytes:return value,9
    kinds={type(None):0,bool:1,int:2,float:3,list:5,dict:6,tuple:7}
    return b'',kinds.get(typ,8)

def buffer(raw):
    return ctypes.create_string_buffer(raw+CANARY)

def workspace(size):
    value=ctypes.create_string_buffer(size+32)
    ctypes.memset(ctypes.addressof(value)+size,0xa7,32)
    return value

class Actual:
    def __init__(self,out,bundle=None):
        self.out=Path(out);self.pins={};self.entries={'controller':0,'decoder':0,'graph':0}
        def read(path):
            path=Path(path).resolve();raw=path.read_bytes()
            if path in self.pins:assert self.pins[path]==raw
            self.pins[path]=raw;return raw
        bundle=Path(bundle or ROOT/'development/edit-decode-compile-r1/bundle.json')
        report=json.loads(read(bundle))
        assert report['status']=='PASS' and report['scope']=='SOURCE_BOUND_EDIT_DECODE_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD'
        row=report['component']
        assert row['schema']=='hepta.hia.edit-decode-native.v1'
        graph_bundle=read(report['arena_graph_bundle_path'])
        assert sha256(graph_bundle).hexdigest()==report['arena_graph_bundle_sha256']
        peers=json.loads(graph_bundle)
        assert peers['status']=='PASS' and peers['scope']=='SOURCE_BOUND_ARENA_GRAPH_DEVELOPMENT_NOT_PUBLIC_ADMISSION_OR_COLD'
        components={'controller':row,'decoder':peers['components']['decoder'],'graph':peers['components']['bridge']}
        current={'controller':ROOT/'examples/hia_bootstrap/edit_decode.hiaasm',
                 'decoder':BASE/'examples/hia_bootstrap/agent_data_json.hiaasm',
                 'graph':ROOT/'examples/hia_bootstrap/arena_graph.hiaasm'}
        images={}
        for role,item in components.items():
            source=read(item['source_path']);image=read(item['image_path'])
            assert read(current[role])==source and sha256(source).hexdigest()==item['source_sha256']
            assert sha256(image).hexdigest()==item['image_sha256']
            assert item['compiler_sha256']=='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'
            images[role]=(image,item['image_sha256'])
        self.readback();self.out.mkdir(parents=True,exist_ok=False)
        self.images={role:NativeHiaJsonImage(*item) for role,item in images.items()}
        self.rawdir=self.out/'raw';self.rawdir.mkdir();self.log=(self.out/'entries.jsonl').open('w')
        self.pinfile('source-before.json')
    def readback(self):
        for path,raw in self.pins.items():assert path.read_bytes()==raw
    def pinfile(self,name):
        (self.out/name).write_text(json.dumps({str(p):sha256(v).hexdigest() for p,v in self.pins.items()},indent=2,sort_keys=True)+'\n')
    def raw(self,value):
        key=sha256(value).hexdigest();path=self.rawdir/(key+'.bin')
        if not path.exists():path.write_bytes(value)
        else:assert path.read_bytes()==value
        return {'bytes':len(value),'sha256':key,'path':path.name}
    def record(self,row):
        self.log.write(json.dumps(row,sort_keys=True)+'\n');self.log.flush()
    def invoke(self,raw,control,work,size,case):
        source=buffer(raw);second=buffer(control)
        before=ctypes.string_at(work,size)
        result=self.images['controller']._entry(source,len(raw),second,len(control),work,size)
        self.entries['controller']+=1
        assert ctypes.string_at(source,len(raw)+32)==raw+CANARY
        assert ctypes.string_at(second,len(control)+32)==control+CANARY
        assert ctypes.string_at(ctypes.addressof(work)+size,32)==CANARY
        after=ctypes.string_at(work,size)
        event=struct.unpack_from('<16Q',after) if size>=128 else None
        self.record({'case':case,'role':'controller','return':result,'event':event,
                     'source':self.raw(raw),'second':self.raw(control),
                     'before':self.raw(before),'after':self.raw(after),'input_and_canaries_unchanged':True})
        return result,event
    def decoder(self,raw,config,osize,wsize,case):
        s=buffer(raw);o=workspace(osize);w=workspace(wsize)
        ctypes.memmove(ctypes.addressof(w)+48,config,len(config))
        before=ctypes.string_at(w,wsize)
        ret=self.images['decoder']._entry(s,len(raw),o,osize,w,wsize)
        self.entries['decoder']+=1
        assert ctypes.string_at(s,len(raw)+32)==raw+CANARY
        for obj,n in [(o,osize),(w,wsize)]:assert ctypes.string_at(ctypes.addressof(obj)+n,32)==CANARY
        output=ctypes.string_at(o,osize)
        self.record({'case':case,'role':'decoder','return':ret,'source':self.raw(raw),'config':self.raw(config),
                     'output':self.raw(output),'before':self.raw(before),'after':self.raw(ctypes.string_at(w,wsize)),
                     'input_and_canaries_unchanged':True})
        return struct.pack('<8Q',REPLY,LEASE,REQUEST,1,ret,osize,0,0)+output
    def graph(self,arena,command,initial,case):
        size=initial;w=workspace(size)
        while True:
            a=buffer(arena);c=buffer(command);before=ctypes.string_at(w,size)
            ret=self.images['graph']._entry(a,len(arena),c,len(command),w,size)
            self.entries['graph']+=1
            assert ctypes.string_at(a,len(arena)+32)==arena+CANARY
            assert ctypes.string_at(c,len(command)+32)==command+CANARY
            assert ctypes.string_at(ctypes.addressof(w)+size,32)==CANARY
            after=ctypes.string_at(w,size);event=struct.unpack_from('<16Q',after)
            self.record({'case':case,'role':'graph','return':ret,'event':event,
                         'arena':self.raw(arena),'command':self.raw(command),'before':self.raw(before),
                         'after':self.raw(after),'input_and_canaries_unchanged':True})
            assert ret==128 and event[0]==GRAPH_EVENT,(case,ret,event)
            if event[1]!=1:return struct.pack('<8Q',REPLY,LEASE,REQUEST,2,ret,size,0,0)+after
            assert event[4]>size
            new_size=max(size*2,event[4]);new=workspace(new_size);ctypes.memmove(new,w,size)
            w=new;size=new_size
    def run(self,raw,kind,*,digits=4300,case='case',initial=512):
        control=struct.pack('<8Q',COMMAND,LEASE,REQUEST,kind,digits,0,0,0)
        size=initial;work=workspace(size);grows=0;services=0
        with ExitStack() as stack:
            for target in ['hepta.hia_program_tools.decode_json',
                           'hepta.hia_json_preflight._preflight_hia_json_reference',
                           'hepta.hia_agent_data_json_native.materialize_data',
                           'hepta.hia_json_decode_native.materialize','json.loads']:
                stack.enter_context(patch(target,side_effect=AssertionError('host semantic owner disabled: '+target)))
            while True:
                ret,event=self.invoke(raw,control,work,size,case)
                assert ret==128 and event[0]==EVENT and event[2:4]==(LEASE,REQUEST),(case,ret,event)
                action=event[1]
                if action==1:
                    assert event[5]>size
                    new_size=max(size*2,event[5]);new=workspace(new_size);ctypes.memmove(new,work,size)
                    size=new_size;work=new;grows+=1;continue
                if action==2:
                    peer=event[6];start,length=event[7:9];offset,extent=event[9:11]
                    assert offset<=size and extent<=size-offset
                    command=ctypes.string_at(ctypes.addressof(work)+offset,extent)
                    services+=1
                    if peer==1:
                        assert start<=len(raw) and length<=len(raw)-start and extent==16
                        control=self.decoder(raw[start:start+length],command,event[11],event[12],case)
                    else:
                        assert peer==2 and start<=len(control) and length<=len(control)-start
                        control=self.graph(control[start:start+length],command,event[12],case)
                    continue
                assert action in (0,3) and event[14]<=size and event[15]<=size-event[14]
                result=ctypes.string_at(ctypes.addressof(work)+event[14],event[15])
                self.raw(result)
                return {'graph':result} | {'grows':grows,'services':services,'event':event} if action==0 else {
                    'error':result.decode('utf-8'),'grows':grows,'services':services,'event':event}
    def check(self,payload,case='case',digits=4300):
        old=sys.get_int_max_str_digits();expected=None;error=None;error_class=None;cause=None;cause_text=None
        try:
            sys.set_int_max_str_digits(digits)
            with patch.dict(os.environ,{'HEPTA_HIA_JSON_DECODE_MANIFEST':'','HEPTA_HIA_JSON_PREFLIGHT_MANIFEST':''}):
                try:expected=reference_decode(payload)
                except BaseException as exc:
                    error=str(exc);error_class=type(exc).__name__
                    if exc.__cause__ is not None:cause=type(exc.__cause__).__name__;cause_text=str(exc.__cause__)
        finally:sys.set_int_max_str_digits(old)
        raw,kind=input_wire(payload)
        actual=self.run(raw,kind,digits=digits,case=case)
        if error is not None:assert actual.get('error')==error,(case,actual,error,error_class)
        else:
            assert 'graph' in actual,(case,actual)
            expected_graph=ag.gw.capture(expected,lease=LEASE)
            assert ag.shape(actual['graph'])==ag.shape(expected_graph),(case,ag.shape(actual['graph']),ag.shape(expected_graph))
            self.raw(expected_graph)
        return {'case':case,'status':'PASS','outcome':'REJECT' if error is not None else 'ACCEPT',
                'error':error,'reference_class':error_class,'reference_cause_class':cause,'reference_cause_text':cause_text,
                'grows':actual['grows'],'services':actual['services']}
    def close(self):
        self.log.close();self.readback();self.pinfile('source-after.json')

def main():
    import resource
    resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
    resource.setrlimit(resource.RLIMIT_CPU,(90,90))
    actual=Actual(ROOT/'development/edit-decode-smoke-r1-attempt1');cases=[]
    start=time.monotonic_ns()
    try:
        for name,payload in [('null','null'),('int','-12345678901234567890'),('dict','{"a":[1,true,null],"é":"水"}'),
          ('bytes',b'{"b":1}'),('none',None),('float',1.25),('empty',''),('fraction','{"a":1.25}'),
          ('duplicate','{"a":1,"a":2}'),('surrogate','"\\ud800"'),('raw-surrogate','"\ud800"'),
          ('invalid-tail',b'! \xff'),('utf8-bom',b'\xef\xbb\xbfnull'),('zero','-0'),
          ('bigint','1'*4301)]:
            cases.append(actual.check(payload,name))
    finally:
        actual.close()
        report={'status':'PASS' if len(cases)==15 else 'FAIL','case_count':len(cases),'cases':cases,
                'entries':actual.entries,'wall_elapsed_ns':time.monotonic_ns()-start,
                'scope':'ACTUAL_HIA_PUBLIC_DECODE_DEVELOPMENT_NOT_PUBLIC_WRAPPER_OR_COLD'}
        (actual.out/'summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        print(json.dumps({k:v for k,v in report.items() if k!='cases'},sort_keys=True),flush=True)
if __name__=='__main__':main()

