"""Actual fixed-peer frame, refusal, retry and owned-result controls."""
from pathlib import Path
import ctypes,hashlib,json,resource,shutil,struct,time
from edit_decode_harness_r2 import Actual,ROOT,COMMAND,EVENT,BAD,LEASE,REQUEST,workspace

def rows(folder):
    return [json.loads(line) for line in (folder/'entries.jsonl').read_text().splitlines()]

def load(folder,row,key):
    value=row[key];raw=(folder/'raw'/value['path']).read_bytes()
    assert len(raw)==value['bytes'] and hashlib.sha256(raw).hexdigest()==value['sha256']
    return raw

def main():
    resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_CPU,(90,90))
    actual=Actual(ROOT/'development/edit-decode-protocol-r2-attempt1')
    smoke=ROOT/'development/edit-decode-smoke-r2-attempt1'
    full=ROOT/'development/edit-decode-differential-r2-attempt1'
    sm=rows(smoke);fl=rows(full);cases=[];start=time.monotonic_ns();status='FAIL'
    own=Path(__file__).read_bytes();(actual.out/'test-source.py').write_bytes(own)
    def reject(label,source,control,before,correct=None):
        w=workspace(len(before));ctypes.memmove(w,before,len(before))
        ret,event=actual.invoke(source,control,w,len(before),label)
        assert ret==BAD,(label,ret,event)
        ret2,event2=actual.invoke(source,correct if correct is not None else control,w,len(before),label+'-followup')
        assert ret2==BAD,(label,'revived',ret2,event2)
        cases.append({'case':label,'status':'PASS','return':ret,'followup_return':ret2})
    def mutation(label,folder,row,at,value):
        source=load(folder,row,'source');before=load(folder,row,'before')
        good=load(folder,row,'second');bad=bytearray(good);struct.pack_into('<Q',bad,at,value)
        reject(label,source,bytes(bad),before,good)
    try:
        good=struct.pack('<8Q',COMMAND,LEASE,REQUEST,9,4300,0,0,0)
        for at,value in [(0,0),(8,0),(16,0),(24,10),(40,1),(48,1),(56,1)]:
            bad=bytearray(good);struct.pack_into('<Q',bad,at,value)
            reject('initial-'+str(at),b'null',bytes(bad),bytes(512),good)
        reject('initial-short',b'null',good[:-1],bytes(512),good)
        dirty=bytearray(512);struct.pack_into('<Q',dirty,424,1)
        reject('initial-nonzero-state',b'null',good,bytes(dirty),good)
        w=workspace(511);ret,_=actual.invoke(b'null',good,w,511,'short-unpersistable-workspace')
        assert ret==BAD
        cases.append({'case':'short-unpersistable-workspace','status':'PASS','return':ret,
                      'disposition':'DISCARD_LEASE_NO_IN_PLACE_POISON_CLAIM'})
        first=next(r for r in sm if r['role']=='controller' and r['case']=='null' and r['event'][4]==10)
        # The first peer reply is consumed by the following controller entry.
        one=next(r for r in sm if r['role']=='controller' and r['case']=='null' and r['event'][4]==20)
        good1=load(smoke,one,'second');extent=struct.unpack_from('<Q',good1,32)[0]
        for at,value in [(0,0),(8,LEASE+1),(16,REQUEST+1),(24,2),(32,63),(40,0),(48,1),(56,1),
                         (64,0),(72,0),(80,0),(88,extent+1),(96,extent+1),(104,999),(112,0),(120,1)]:
            mutation('decoder-reply-'+str(at),smoke,one,at,value)
        source=load(smoke,one,'source');before=load(smoke,one,'before')
        reject('decoder-reply-truncated',source,good1[:-1],before,good1)
        two=next(r for r in sm if r['role']=='controller' and r['case']=='null' and r['event'][4]==90)
        good2=load(smoke,two,'second');buflen=len(good2)-64;goff=struct.unpack_from('<Q',good2,104)[0]
        mutations=[(0,0),(8,LEASE+1),(16,REQUEST+1),(24,1),(32,127),(40,0),(48,1),(56,1),
                   (64,0),(72,1),(80,LEASE+1),(88,REQUEST+1),(96,buflen+1),(104,0),(112,0),(120,0),
                   (128,1),(136,1),(144,1),(152,0),(160,0),(168,1),(176,0),(184,1)]
        for at,value in mutations:mutation('graph-reply-'+str(at),smoke,two,at,value)
        for at,value in [(0,0),(8,LEASE+1),(16,0),(24,0),(32,1),(40,1),(48,0),(56,1)]:
            mutation('graph-header-'+str(at),smoke,two,64+goff+at,value)
        failed=next(r for r in sm if r['role']=='controller' and r['case']=='bigint' and r['event'][4]==99)
        for at,value in [(128,0),(128,2),(136,999999),(144,4300),(144,100000),(176,90),(112,1)]:
            mutation('graph-error-'+str(at)+'-'+str(value),smoke,failed,at,value)
        # Terminal phases refuse both the original and fresh initial command.
        for label,row in [('success',two),('semantic-error',failed)]:
            before=load(smoke,row,'after');raw=load(smoke,row,'source')
            reject('terminal-'+label,raw,good,before,load(smoke,row,'second'))
        # Header snapshots are checked during actual controller GROW retries.
        for phase,name in [(11,'exact-8MiB-string'),(21,'actual-node-ceiling-262144')]:
            row=next(r for r in fl if r['role']=='controller' and r['case']==name
                     and r['event'][1]==1 and r['event'][4]==phase)
            before=load(full,row,'after');need=row['event'][5]
            before=before+b'\0'*(need-len(before))
            source=load(full,row,'source');control=load(full,row,'second')
            changed=bytearray(control)
            if phase==11:
                extent=struct.unpack_from('<Q',changed,32)[0]
                for at in [32,88,96]:struct.pack_into('<Q',changed,at,extent+1)
            else:
                changed+=b'\0'*8
                struct.pack_into('<Q',changed,40,len(changed)-64)
            reject('grow-'+str(phase)+'-changed-header',source,bytes(changed),before,control)
        # GROW-correlated initial source length cannot drift.
        row=next(r for r in sm if r['role']=='controller' and r['case']=='null' and r['event'][1]==1)
        before=load(smoke,row,'after')+b'\0'*(row['event'][5]-len(load(smoke,row,'after')))
        reject('grow-1-source-extent',b'null ',load(smoke,row,'second'),before,load(smoke,row,'second'))
        # A published Graph remains entirely owned after the peer reply is changed.
        row=two;before=load(smoke,row,'before');source=load(smoke,row,'source')
        control=bytearray(load(smoke,row,'second'));w=workspace(len(before));ctypes.memmove(w,before,len(before))
        ret,event=actual.invoke(source,bytes(control),w,len(before),'graph-copy-ownership')
        assert ret==128 and event[1]==0
        owned=ctypes.string_at(ctypes.addressof(w)+event[14],event[15]);actual.raw(owned)
        control[:]=b'\xcc'*len(control)
        assert ctypes.string_at(ctypes.addressof(w)+event[14],event[15])==owned
        cases.append({'case':'graph-copy-ownership','status':'PASS','bytes':len(owned)})
        status='PASS'
    finally:
        actual.close();assert Path(__file__).read_bytes()==own
        summary={'status':status,'case_count':len(cases),'cases':cases,'entries':actual.entries,
                 'wall_elapsed_ns':time.monotonic_ns()-start,'source_before_after_exact':True,
                 'test_sha256':hashlib.sha256(own).hexdigest(),
                 'scope':'ACTUAL_PRIVATE_PROTOCOL_REFUSAL_NOT_EXTERNAL_BUFFER_AUTHENTICATION'}
        (actual.out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
        print(json.dumps({k:v for k,v in summary.items() if k!='cases'},sort_keys=True),flush=True)
if __name__=='__main__':main()

