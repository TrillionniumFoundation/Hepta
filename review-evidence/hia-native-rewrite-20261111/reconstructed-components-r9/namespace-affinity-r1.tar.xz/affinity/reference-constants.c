#include <float.h>
#include <fenv.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void) {
 long double v[] = {1e100L,1e10L,1e1L,1e-100L,1e-10L,1e-1L,1e19L,1e119L,1e29L,1e-97L,1e7L,1e17L};
 printf("%d %d %d %d %d %zu %zu\n", FLT_RADIX,LDBL_MANT_DIG,LDBL_MAX_EXP,DBL_MANT_DIG,fegetround(),sizeof(long double),sizeof(double));
 for(unsigned i=0;i<sizeof(v)/sizeof(v[0]);i++){ uint64_t m=0;uint16_t e=0;memcpy(&m,&v[i],8);memcpy(&e,((char*)&v[i])+8,2);printf("%llu %u\n",(unsigned long long)m,(unsigned)e);}
 return 0;
}
