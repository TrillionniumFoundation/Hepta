# Namespace scalar affinity and increment owner

This component is a development implementation of the complete scalar peer
needed by the existing ten-table namespace catalog: NUMERIC affinity, TEXT
affinity, and the SQL expression `value + 1`. It does not provide a database,
an object registry, migration, transaction durability, or an ordinary AgentStore
route. Those owners remain open. The completed comparison and transaction
components retain their own source and evidence identities.

## Compatibility profile

Profile 1 denotes the observed SQLite 3.46.1 UTF-8 behavior with the x86 extended
precision conversion path enabled (`SQLITE_TESTCTRL_USELONGDOUBLE = 1`, binary80
precision 64, binary64 precision 53, nearest-even binary operations). The
official source id is
`2024-08-13 09:16:08 c9c2ab54ba1f5f46360f1b4f35d849cd3f080e6fc2b6c60e91b16c63f69a1e33`.
The implementation uses HIA integers and buffers exclusively. It does not call
SQLite, a host float parser, a formatting library, or the host math runtime.

The profile is explicit. This stage does not claim the separate SQLite
double-double fallback, other SQLite revisions, a different floating-point
rounding mode, or conversion of old UTF-16 database pages. A namespace migration
owner must bind the actual source database encoding and compatibility profile;
an arbitrary external caller cannot choose a profile to authenticate a value.

The integer-only binary80 representation uses an unsigned 64-bit normalized
significand and an exponent biased by 20000. Multiplication computes all 128
product bits and rounds each original multiplication to nearest-even. Decimal
constants are generated from exact integer ratios, then rounded to the same
64-bit significand. AtoF follows the original significand collection, exponent
parse and power-of-ten multiplication order. It preserves prefix conversion
for arithmetic separately from full-string acceptance for NUMERIC affinity.
Its explicit largest-binary64 comparison precedes the final binary64 cast.

TEXT conversion follows `sqlite3FpDecode` and `%!.15g`: scaling is performed
with that binary80 path, decimal rounding is HALF-UP to 15 significant digits,
and the original fixed/scientific threshold and mandatory decimal point are
retained. In particular, integer formatting differs from REAL formatting,
negative REAL zero renders as `0.0`, and infinities render as `Inf` / `-Inf`.
The existing JSON shortest formatter is not used as this SQLite formatter.

The arithmetic peer preserves INTEGER addition until signed overflow and then
uses the exact binary64 `+1` result. A non-numeric text/blob prefix can become
INTEGER zero for arithmetic while the same TEXT remains TEXT under NUMERIC
affinity. REAL results of addition remain REAL before a later row-affinity
operation. NaN values have the effective NULL representation used by SQLite.

## RWW protocol

Entry receives immutable input, mutable output, and a private mutable workspace.
The minimum output is 192 bytes; workspace is 512 bytes. Neither size limits an
input TEXT/BLOB value. All integers in the ABI are little-endian u64.

Input begins with eight words:

| Word | Meaning |
|---:|---|
| 0 | `HIANAF01` |
| 1 | 1 NUMERIC, 2 TEXT, 3 ADD_ONE |
| 2–3 | nonzero 128-bit session |
| 4 | exact next nonzero call sequence |
| 5 | nonzero source value lease |
| 6 | exact bytes following this 64-byte header |
| 7 | compatibility profile, exactly 1 |

The remaining input is exactly one cell: storage class, payload byte count,
payload. Classes are NULL=0 (zero bytes), INTEGER=1 and REAL=2 (eight bytes),
TEXT=3 and BLOB=4 (arbitrary bytes). INTEGER is two's-complement i64; REAL is an
IEEE binary64 bit pattern. Every extent and class is checked before publishing
a result. NUL and non-UTF-8 bytes are retained as raw value bytes. This does not
turn a raw buffer into an authenticated database value.

The output has sixteen header words:

| Word | Meaning |
|---:|---|
| 0–6 | magic, status, session low/high, call, operation, source lease |
| 7 | original input storage class |
| 8 | resulting storage class |
| 9 | 0 inline result, 1 unchanged source borrow |
| 10 | result payload bytes |
| 11 | rejection reason, zero on success |
| 12 | profile 1 |
| 13 | borrowed input offset 80, otherwise zero |
| 14 | original source payload bytes |
| 15 | zero |

At output offset 128 the resulting cell class/count are repeated. Inline payload
starts at 144 and is at most 32 bytes: NULL, INTEGER, REAL, or the derived numeric
TEXT. Unchanged TEXT/BLOB uses the original input lease and offset 80 instead of
copying an unbounded value into a fixed buffer. The future object owner must
keep that exact immutable input alive or detach it before releasing its lease.
Framing is not external storage authorization and does not establish issuer
provenance by itself.

A fresh workspace must be all zero. Successful calls retain session identity,
strictly increasing call identity, and the complete previous result shape.
Call exhaustion, malformed headers/cells, invalid prior state, and insufficient
output capacity permanently poison the workspace. All later calls refuse. A
workspace shorter than 512 bytes cannot carry the poison record and must be
discarded. Output writes are confined to the first 192 bytes and private work
writes to the first 512 bytes. No test may count a short-workspace reuse as an
authenticated session.

## No new value or history limit

There is no decimal digit quota, input TEXT/BLOB quota, database record limit,
transaction history limit, or aggregate store size limit. Numeric conversion
scans the complete original value to preserve acceptance and prefix semantics.
Exponent scaling may terminate once further monotone scaling provably cannot
change the final binary64 zero/infinity result; it does not reject the input.
The physical object/view/log owners and their growth/reclamation proofs remain
separate work.

## Evidence requirements

The oracle is the actual pinned official SQLite 3.46.1 test library, using typed
bindings, real NUMERIC/TEXT column affinity, and the actual `? + 1` expression.
`CAST(... AS NUMERIC)` is not an affinity oracle. Record source/library/image
pins, original bytes, every SQL case and VM/native entry, complete work/output
equality, input immutability, guards, and failure-first protocol cases. Until
those runs complete this document is an implementation contract, not a native
PASS or qualification assertion.
