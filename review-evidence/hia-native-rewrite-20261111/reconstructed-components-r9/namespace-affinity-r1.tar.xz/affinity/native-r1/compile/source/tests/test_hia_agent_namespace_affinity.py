"""Complete scalar peer against actual SQLite 3.46.1 column/expression semantics."""
from __future__ import annotations

import ctypes
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import random
import struct
import unittest

from hepta.hia_agent_assembly import assemble_program
from hepta.hia_program_runtime import _Machine, _Owner, _View
from tests.hia_namespace_sqlite_reference import SQLiteReference, cell, envelope

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANAF01', 'little')
BAD = 0xfffffffd
MASK = (1 << 64) - 1
CANARY = bytes(range(192, 224))


def frame(value, operation=1, call=1, session=(0xabc, 0xdef)):
    payload = envelope(value)
    return struct.pack('<8Q', MAGIC, operation, *session, call, 17, len(payload), 1) + payload


def real_bits(bits):
    return 2, struct.pack('<Q', bits)


class ScalarReference(SQLiteReference):
    def __init__(self):
        super().__init__()
        if self.version != '3.46.1':
            raise RuntimeError('exact SQLite 3.46.1 scalar reference required')
        control = self.lib.sqlite3_test_control
        control.restype = ctypes.c_int
        self.longdouble_profile = control(34, -1)
        if self.longdouble_profile != 1:
            raise RuntimeError('scalar profile requires the observed long-double path')
        self.execute('CREATE TABLE numeric_values(v NUMERIC)')
        self.execute('CREATE TABLE text_values(v TEXT)')

    def scalar(self, value, operation):
        if operation == 3:
            result = self.execute('SELECT ?1 + 1', (value,))
        else:
            table = 'numeric_values' if operation == 1 else 'text_values'
            self.execute('DELETE FROM '+table)
            result = self.execute('INSERT INTO '+table+'(v) VALUES(?1) RETURNING v', (value,))
        if result['error']:
            raise AssertionError(result['error'])
        if len(result['rows']) != 1 or len(result['rows'][0]) != 1:
            raise AssertionError('scalar oracle must return exactly one typed cell')
        return result['rows'][0][0]


class NamespaceAffinityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT/'examples/hia_bootstrap/agent_namespace_affinity.hiaasm').read_bytes()
        cls.program = assemble_program(cls.raw)
        cls.entry = cls.program.as_dict()['functions'][0]
        cls.reference = ScalarReference()
        cls.entries = cls.cases = 0
        cls.evidence = Path(os.environ['HIA_NAMESPACE_AFFINITY_LEDGER']) if os.environ.get('HIA_NAMESPACE_AFFINITY_LEDGER') else None
        cls.ledger = None
        if cls.evidence:
            cls.evidence.mkdir(parents=True, exist_ok=False)
            cls.ledger = gzip.open(cls.evidence/'invocations.jsonl.gz', 'wt', encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        if cls.ledger:
            cls.ledger.close()
            (cls.evidence/'counts.json').write_text(json.dumps({
                'scope': 'SCALAR DEVELOPMENT; NO NATIVE DATABASE CLAIM',
                'source_sha256': hashlib.sha256(cls.raw).hexdigest(),
                'entries': cls.entries, 'oracle_cases': cls.cases,
                'sqlite_library': cls.reference.path, 'sqlite_version': cls.reference.version,
                'sqlite_source_id': cls.reference.source_id,
                'sqlite_longdouble_profile': cls.reference.longdouble_profile,
                'sqlite_statements': cls.reference.entries,
            }, sort_keys=True, indent=2) + '\n')
        cls.reference.close()

    def log(self, value):
        if self.ledger:
            self.ledger.write(json.dumps(value, sort_keys=True, separators=(',', ':'))+'\n')
            self.ledger.flush()

    def invoke(self, raw, work, output_size=192):
        original, before = bytes(raw), bytes(work)
        owners = [_Owner(-1, bytearray(original)), _Owner(-2, bytearray(output_size)), _Owner(-3, work)]
        machine = _Machine(self.program, 4000000, 64 << 20, None, 64)
        result = machine.invoke(self.entry, [_View(owners[0], False), _View(owners[1], True), _View(owners[2], True)])[0]
        output = bytes(owners[1].data)
        type(self).entries += 1
        self.assertEqual(bytes(owners[0].data), original)
        self.log({'kind': 'vm_entry', 'entry': type(self).entries, 'test_id': self.id(),
                  'input_hex': original.hex(), 'workspace_before_hex': before.hex(),
                  'workspace_after_hex': bytes(work).hex(), 'output_hex': output.hex(),
                  'return': result, 'output_descriptor_bytes': output_size})
        return result, output

    def scalar(self, value, operation, work=None):
        if work is None:
            work = bytearray(512)
        call = struct.unpack_from('<Q', work, 32)[0] + 1
        raw = frame(value, operation, call)
        expected = self.reference.scalar(value, operation)
        code, payload = self.invoke(raw, work)
        header = struct.unpack_from('<16Q', payload)
        kind, size = struct.unpack_from('<2Q', payload, 128)
        mode = header[9]
        actual = kind, (raw[header[13]:header[13]+size] if mode == 1 else payload[144:144+size])
        self.log({'kind': 'oracle_case', 'case': type(self).cases, 'input_hex': raw.hex(),
                  'expected_kind': expected[0], 'expected_payload_hex': expected[1].hex(),
                  'actual_kind': actual[0], 'actual_payload_hex': actual[1].hex(),
                  'output_header': header, 'sqlite_version': self.reference.version})
        type(self).cases += 1
        self.assertEqual(code, 0)
        self.assertIn(mode, (0, 1))
        self.assertEqual(actual, expected, (operation, value, header))
        self.assertEqual(header, (MAGIC, 0, 0xabc, 0xdef, call, operation, 17, value[0],
                                 expected[0], mode, len(expected[1]), 0, 1,
                                 80 if mode else 0, len(value[1]), 0))
        if mode:
            self.assertIn(operation, (1, 2))
            self.assertIn(expected[0], (3, 4))
            self.assertEqual(expected, value)
            self.assertEqual(payload[144:], bytes(48))
        else:
            self.assertLessEqual(size, 32)
            self.assertEqual(payload[144+size:], bytes(48-size))
        return actual

    def test_all_five_storage_classes_and_distinct_scalar_operations(self):
        values = [None, -(1 << 63), -1, 0, 1, (1 << 63)-1,
                  -math.inf, -1.5, -0.0, 0.0, 0.5, 1.0, math.inf,
                  '', '0', '1.5', '1foo', 'a\0b', 'é', b'', b'1.5', b'\0', b'\xff']
        cells = [cell(v) for v in values] + [real_bits(0x7ff0000000000001), real_bits(0xfff8000000000001), (3, b'\xff\0\xc0')]
        work = bytearray(512)
        for value in cells:
            for operation in (1, 2, 3):
                self.scalar(value, operation, work)

    def test_decimal_parse_full_acceptance_prefixes_whitespace_and_i64_edges(self):
        raw = ['', ' ', '\t\n\v\f\r', '+', '-', '.', '+.', '-.', '0', '-0', '+0',
               '0.0', '-0.0', '.0', '1.', '.1', '1e', '1e+', '1e-', '1.e', '1.e+',
               '.1e', '.1e+', '1.25x', '1e2x', '1.2e3x', '1foo', 'foo', '0x10',
               '0Xf', 'NaN', 'Inf', '-Inf', 'Infinity', '1_0', '1\0', '1 \0',
               '1e99999', '-1e99999', '1e-99999', '-1e-99999',
               '1e999999', '1e-999999', '3.0e5', '12.000', '000123', '-000123',
               '9223372036854775807', '9223372036854775808', '9223372036854775809',
               '-9223372036854775807', '-9223372036854775808', '-9223372036854775809',
               '-9223372036854775808.0', '9223372036854775807.0',
               '9007199254740991', '9007199254740992', '9007199254740993',
               '1844674407370955160', '1844674407370955161', '18446744073709551609',
               '1844674407370955160999', '18446744073709551610.125',
               '1.7976931348623157e308', '1.7976931348623158e308',
               '2.2250738585072014e-308', '4.9406564584124654e-324',
               '2.4703282292062327e-324', '2.4703282292062328e-324']
        work = bytearray(512)
        for text in raw:
            for kind in (3, 4):
                for operation in (1, 3):
                    self.scalar((kind, text.encode()), operation, work)
        for space in range(256):
            value = (3, bytes([space])+b'12'+bytes([space]))
            self.scalar(value, 1, work)
            self.scalar(value, 3, work)

    def test_binary64_increment_and_text_rounding_boundaries(self):
        work = bytearray(512)
        bits = {0, 1, 2, 0x000fffffffffffff, 0x0010000000000000,
                0x0010000000000001, 0x7fefffffffffffff, 0x7ff0000000000000}
        for exponent in (-55, -54, -53, -52, -5, -4, -1, 0, 1, 14, 15, 16, 17, 18,
                         19, 28, 29, 51, 52, 53, 54, 62, 63, 100, 119, 1023):
            value = math.ldexp(1.0, exponent)
            center = struct.unpack('<Q', struct.pack('<d', value))[0]
            bits.update((center-1, center, center+1))
        for raw in sorted(bits):
            for sign in (0, 1 << 63):
                for operation in (1, 2, 3):
                    self.scalar(real_bits(raw | sign), operation, work)
        for power in range(64):
            for sign in (-1, 1):
                integer = sign * ((1 << power)-1)
                for operation in (1, 2, 3):
                    self.scalar(cell(integer), operation, work)

    def test_fixed_seed_ieee_and_decimal_strings(self):
        randomizer = random.Random(0x4849414e41463031)
        work = bytearray(512)
        for _ in range(256):
            bits = randomizer.getrandbits(64)
            for operation in (1, 2, 3):
                self.scalar(real_bits(bits), operation, work)
            count = randomizer.randrange(1, 71)
            digits = ''.join(str(randomizer.randrange(10)) for _ in range(count))
            point = randomizer.randrange(count+1)
            value = digits[:point]+'.'+digits[point:]
            value = ('-' if randomizer.randrange(2) else '')+value+'e'+str(randomizer.randrange(-400, 401))
            for operation in (1, 3):
                self.scalar(cell(value), operation, work)

    def test_unbounded_cell_borrow_and_long_numeric_prefixes(self):
        work = bytearray(512)
        for size in (0, 1, 7, 8, 63, 64, 255, 256, 4095, 4096):
            raw = b'\xff\0\xc0\xed' * (size//4) + b'z' * (size%4)
            for kind in (3, 4):
                for operation in (1, 2):
                    self.scalar((kind, raw), operation, work)
        for text in ('0'*1024+'1', '1'+'0'*1024, '0.'+'0'*1024+'1',
                     '1.'+'0'*1024, '1e'+'9'*1024, '1e-'+'9'*1024,
                     ' '*1024+'12'+' '*1024, '9'*1024+'garbage'):
            for operation in (1, 2, 3):
                self.scalar(cell(text), operation, work)

    def test_protocol_invalid_inputs_and_persistent_refusal(self):
        valid = frame(cell(1))
        invalid = [valid[:n] for n in range(len(valid))] + [valid+b'\0']
        for word, value in ((0, MAGIC^1), (1, 0), (1, 4), (4, 0), (4, 2),
                            (5, 0), (6, 0), (6, len(valid)-63), (7, 0), (7, 2)):
            changed = bytearray(valid)
            struct.pack_into('<Q', changed, word*8, value)
            invalid.append(bytes(changed))
        changed = bytearray(valid);changed[16:32] = bytes(16);invalid.append(bytes(changed))
        for kind, size, payload in ((5, 0, b''), (0, 1, b'\0'), (1, 7, bytes(7)),
                                    (2, 9, bytes(9)), (3, MASK, b''), (4, 1, b'')):
            body = struct.pack('<QQ', kind, size)+payload
            invalid.append(valid[:48]+struct.pack('<QQ', len(body), 1)+body)
        for raw in invalid:
            work = bytearray(512)
            self.assertEqual(self.invoke(raw, work)[0], BAD)
            before = bytes(work)
            self.assertNotEqual(struct.unpack_from('<Q', work, 88)[0], 0)
            self.assertEqual(self.invoke(valid, work)[0], BAD)
            self.assertEqual(bytes(work), before)
        for size in (0, 1, 128, 191):
            work = bytearray(512)
            self.assertEqual(self.invoke(valid, work, size), (BAD, bytes(size)))
            self.assertEqual(self.invoke(valid, work)[0], BAD)
        for size in (0, 1, 128, 511):
            work = bytearray(size)
            self.assertEqual(self.invoke(valid, work), (BAD, bytes(192)))
            self.assertEqual(bytes(work), bytes(size))

    def test_session_generation_private_shape_and_exhaustion(self):
        work = bytearray(512)
        self.scalar(cell(1), 1, work)
        saved = bytes(work)
        for raw in (frame(cell(1), call=1), frame(cell(1), call=3),
                    frame(cell(1), call=2, session=(0xabc, 0xdee))):
            current = bytearray(saved)
            self.assertEqual(self.invoke(raw, current)[0], BAD)
            self.assertEqual(self.invoke(frame(cell(1), call=2), current)[0], BAD)
        for offset, value in ((0, 0), (8, 0), (32, 0), (40, 4), (48, 0),
                              (56, 5), (64, 5), (72, 2), (80, 7), (88, 1),
                              (96, 0), (104, 80), (112, 9), (120, 1)):
            current = bytearray(saved)
            struct.pack_into('<Q', current, offset, value)
            self.assertEqual(self.invoke(frame(cell(1), call=2), current)[0], BAD)
            before = bytes(current)
            self.assertEqual(self.invoke(frame(cell(1), call=2), current)[0], BAD)
            self.assertEqual(bytes(current), before)
        current = bytearray(saved)
        struct.pack_into('<Q', current, 32, MASK)
        self.assertEqual(self.invoke(frame(cell(1), call=0), current)[0], BAD)


if __name__ == '__main__':
    unittest.main(verbosity=2)
