"""HIA integer-only SQLite-profile scalar semantics for the namespace engine.

Authoring computes only exact power-of-ten constants. Runtime NUMERIC/TEXT
affinity and ADD_ONE execute in generated HIA with no host numeric callbacks.
See the ABI document for the explicit SQLite 3.46.1 binary80 profile and the
remaining object/view/log/migration owners.
"""
from __future__ import annotations

import ast
from pathlib import Path

from hepta.hia_agent_assembly import render_assembly
from tools.generate_hia_agent_namespace_store import VALUES
from tools.generate_hia_selfhost import Builder, compact_authoring_cfg, total_scalar_functions

ROOT = Path(__file__).resolve().parents[1]
MAGIC = int.from_bytes(b'HIANAF01', 'little')
BAD = 0xfffffffd

AFFINITY = r'''
def namespace_affinity(s:readbuf, o:mutbuf, w:mutbuf) -> u32:
    if length(w) < 512:
        return 4294967293
    if get(w, 8) == 2:
        return emit(o, w, 4294967293)
    if length(o) < 192:
        return poison(w, 1)
    if get(w, 0) == 0:
        at = 0
        while at < 512:
            if byte(w, at) != 0:
                poison(w, 2)
                return emit(o, w, 4294967293)
            at = at + 1
    elif valid_state(w) == 0:
        poison(w, 2)
        return emit(o, w, 4294967293)
    if frame(s, w) == 0:
        poison(w, 3)
        return emit(o, w, 4294967293)
    if cell_valid(s) == 0:
        poison(w, 4)
        return emit(o, w, 4294967293)
    fill_range(w, 128, 384, 0)
    operation = read64(s, 8)
    kind = read64(s, 64)
    if kind == 2 and real_nan(read64(s, 80)) == 1:
        kind = 0
    put(w, 64, kind)
    put(w, 72, 0)
    put(w, 80, 0)
    put(w, 104, 0)
    if kind == 0:
        result_number(w, 0, 0)
    elif operation == 1:
        numeric_affinity(s, w, kind)
    elif operation == 2:
        text_affinity(s, w, kind)
    else:
        add_one_value(s, w, kind)
    put(w, 0, AFFINITY_MAGIC)
    put(w, 8, 1)
    put(w, 16, read64(s, 16))
    put(w, 24, read64(s, 24))
    put(w, 32, read64(s, 32))
    put(w, 40, operation)
    put(w, 48, read64(s, 40))
    put(w, 56, read64(s, 64))
    put(w, 88, 0)
    put(w, 96, 1)
    put(w, 112, read64(s, 72))
    put(w, 120, 0)
    return emit(o, w, 0)

def valid_state(w:mutbuf) -> u64:
    if get(w, 0) != AFFINITY_MAGIC or get(w, 8) != 1:
        return 0
    if (get(w, 16) == 0 and get(w, 24) == 0) or get(w, 32) == 0 or get(w, 48) == 0:
        return 0
    op = get(w, 40)
    source_kind = get(w, 56)
    kind = get(w, 64)
    mode = get(w, 72)
    size = get(w, 80)
    if op < 1 or op > 3 or source_kind > 4 or kind > 4 or mode > 1:
        return 0
    if get(w, 88) != 0 or get(w, 96) != 1 or get(w, 120) != 0:
        return 0
    if source_kind == 0 and get(w, 112) != 0:
        return 0
    if source_kind == 1 or source_kind == 2:
        if get(w, 112) != 8:
            return 0
    if mode == 1:
        if kind < 3 or kind != source_kind or op == 3 or get(w, 104) != 80 or size != get(w, 112):
            return 0
    else:
        if get(w, 104) != 0 or kind == 4:
            return 0
        if kind == 0:
            if size != 0:
                return 0
        elif kind == 1 or kind == 2:
            if size != 8 or op == 2:
                return 0
        elif op != 2 or size == 0 or size > 32:
            return 0
    return 1

def frame(s:readbuf, w:mutbuf) -> u64:
    if length(s) < 80 or read64(s, 0) != AFFINITY_MAGIC:
        return 0
    if read64(s, 8) < 1 or read64(s, 8) > 3 or read64(s, 56) != 1:
        return 0
    if (read64(s, 16) == 0 and read64(s, 24) == 0) or read64(s, 40) == 0:
        return 0
    if read64(s, 48) != length(s) - 64:
        return 0
    if get(w, 0) != 0:
        if read64(s, 16) != get(w, 16) or read64(s, 24) != get(w, 24):
            return 0
    if get(w, 32) == 18446744073709551615 or read64(s, 32) != get(w, 32) + 1:
        return 0
    return 1

def cell_valid(s:readbuf) -> u64:
    kind = read64(s, 64)
    size = read64(s, 72)
    if kind > 4 or size != length(s) - 80:
        return 0
    if kind == 0:
        return choose(size == 0, 1, 0)
    if kind == 1 or kind == 2:
        return choose(size == 8, 1, 0)
    return 1

def real_nan(bits:u64) -> u64:
    return choose(((bits >> 52) & 2047) == 2047 and (bits & 4503599627370495) != 0, 1, 0)

def result_number(w:mutbuf, kind:u64, bits:u64) -> u64:
    put(w, 64, kind)
    put(w, 72, 0)
    put(w, 80, choose(kind == 0, 0, 8))
    put(w, 104, 0)
    if kind != 0:
        put(w, 256, bits)
    return 0

def result_borrow(s:readbuf, w:mutbuf, kind:u64) -> u64:
    put(w, 64, kind)
    put(w, 72, 1)
    put(w, 80, read64(s, 72))
    put(w, 104, 80)
    return 0

def numeric_affinity(s:readbuf, w:mutbuf, kind:u64) -> u64:
    if kind == 1:
        return result_number(w, 1, read64(s, 80))
    if kind == 2:
        return integer_affinity(w, read64(s, 80))
    if kind == 4:
        return result_borrow(s, w, kind)
    parse_real(s, w)
    rc = get(w, 152)
    if rc == 0 or rc == 4:
        return result_borrow(s, w, 3)
    if rc == 1:
        parse_integer(s, w)
        if get(w, 168) == 0:
            return result_number(w, 1, get(w, 160))
    return integer_affinity(w, get(w, 144))

def integer_affinity(w:mutbuf, bits:u64) -> u64:
    magnitude = bits & 9223372036854775807
    if magnitude == 0:
        return result_number(w, 1, 0)
    exponent = magnitude >> 52
    if exponent < 1023 or exponent >= 1086:
        return result_number(w, 2, bits)
    power = exponent - 1023
    mantissa = (magnitude & 4503599627370495) | 4503599627370496
    integral = 0
    if power >= 52:
        integral = mantissa << (power - 52)
    else:
        shift = 52 - power
        if (mantissa & ((1 << shift) - 1)) != 0:
            return result_number(w, 2, bits)
        integral = mantissa >> shift
    if (bits >> 63) != 0:
        integral = 0 - integral
    return result_number(w, 1, integral)

def text_affinity(s:readbuf, w:mutbuf, kind:u64) -> u64:
    if kind >= 3:
        return result_borrow(s, w, kind)
    if kind == 1:
        return render_integer(w, read64(s, 80))
    return render_real(w, read64(s, 80))

def add_one_value(s:readbuf, w:mutbuf, kind:u64) -> u64:
    bits = 0
    selected = kind
    if kind <= 2:
        bits = read64(s, 80)
    else:
        parse_real(s, w)
        parse_integer(s, w)
        rc = get(w, 152)
        irc = get(w, 168)
        selected = 2
        bits = get(w, 144)
        if rc == 0:
            if irc == 0 or irc == 1 or irc == 4:
                selected = 1
                bits = get(w, 160)
        elif rc == 1 and irc == 0:
            selected = 1
            bits = get(w, 160)
    if selected == 1:
        if bits != 9223372036854775807:
            return result_number(w, 1, bits + 1)
        return result_number(w, 2, 4890909195324358656)
    return result_number(w, 2, real_plus_one(bits))

def is_space(value:u64) -> u64:
    return choose(value == 32 or (value >= 9 and value <= 13), 1, 0)

def is_digit(value:u64) -> u64:
    return choose(value >= 48 and value <= 57, 1, 0)

def parse_integer(s:readbuf, w:mutbuf) -> u64:
    at = 80
    end = length(s)
    while at < end and is_space(byte(s, at)) == 1:
        at = at + 1
    negative = 0
    if at < end:
        if byte(s, at) == 45:
            negative = 1
            at = at + 1
        elif byte(s, at) == 43:
            at = at + 1
    first = at
    while at < end and byte(s, at) == 48:
        at = at + 1
    significant = at
    value = 0
    while at < end and is_digit(byte(s, at)) == 1:
        if at - significant < 19:
            value = value * 10 + byte(s, at) - 48
        at = at + 1
    digits = at - significant
    rc = 0
    if at == first:
        rc = 4
    else:
        tail = at
        while tail < end and is_space(byte(s, tail)) == 1:
            tail = tail + 1
        if tail != end:
            rc = 1
    if digits > 19 or value > 9223372036854775808:
        rc = 2
        value = choose(negative == 1, 9223372036854775808, 9223372036854775807)
    elif value == 9223372036854775808:
        if negative == 0:
            rc = 3
            value = 9223372036854775807
    elif negative == 1:
        value = 0 - value
    put(w, 160, value)
    put(w, 168, rc)
    return 0

def parse_real(s:readbuf, w:mutbuf) -> u64:
    at = 80
    end = length(s)
    while at < end and is_space(byte(s, at)) == 1:
        at = at + 1
    negative = 0
    if at < end:
        if byte(s, at) == 45:
            negative = 1
            at = at + 1
        elif byte(s, at) == 43:
            at = at + 1
    value = 0
    digits = 0
    plus = 0
    minus = 0
    while at < end and is_digit(byte(s, at)) == 1:
        value = value * 10 + byte(s, at) - 48
        digits = digits + 1
        at = at + 1
        if value >= 1844674407370955160:
            while at < end and is_digit(byte(s, at)) == 1:
                at = at + 1
                plus = plus + 1
    form = 1
    if at < end and byte(s, at) == 46:
        at = at + 1
        form = form + 1
        while at < end and is_digit(byte(s, at)) == 1:
            if value < 1844674407370955160:
                value = value * 10 + byte(s, at) - 48
                minus = minus + 1
                digits = digits + 1
            at = at + 1
    exponent = 0
    exponent_negative = 0
    exponent_valid = 1
    if at < end and (byte(s, at) == 101 or byte(s, at) == 69):
        at = at + 1
        form = form + 1
        exponent_valid = 0
        if at < end:
            if byte(s, at) == 45:
                exponent_negative = 1
                at = at + 1
            elif byte(s, at) == 43:
                at = at + 1
        while at < end and is_digit(byte(s, at)) == 1:
            exponent = choose(exponent < 10000, exponent * 10 + byte(s, at) - 48, 10000)
            exponent_valid = 1
            at = at + 1
    while at < end and is_space(byte(s, at)) == 1:
        at = at + 1
    rc = 0
    if at == end and digits > 0 and exponent_valid == 1:
        rc = form
    elif form >= 2 and (form == 3 or exponent_valid == 1) and digits > 0:
        rc = 4
    put(w, 152, rc)
    if value == 0:
        put(w, 144, negative << 63)
        return 0
    if exponent_negative == 1:
        if minus > 18446744073709551615 - exponent:
            put(w, 144, negative << 63)
            return 0
        minus = minus + exponent
    else:
        if plus > 18446744073709551615 - exponent:
            put(w, 144, (negative << 63) | 9218868437227405312)
            return 0
        plus = plus + exponent
    direction = choose(plus >= minus, 0, 1)
    amount = choose(plus >= minus, plus - minus, minus - plus)
    if direction == 0:
        while amount > 0 and value < 1844674407370955161:
            value = value * 10
            amount = amount - 1
    else:
        while amount > 0 and (value % 10) == 0:
            value = value // 10
            amount = amount - 1
    x80_integer(w, value)
    if direction == 0:
        scale_positive(w, amount)
    else:
        scale_negative(w, amount)
    put(w, 144, x80_binary64(w) | (negative << 63))
    return 0

def highest_bit(value:u64) -> u64:
    result = 0
    if (value >> 32) != 0:
        value = value >> 32
        result = result + 32
    if (value >> 16) != 0:
        value = value >> 16
        result = result + 16
    if (value >> 8) != 0:
        value = value >> 8
        result = result + 8
    if (value >> 4) != 0:
        value = value >> 4
        result = result + 4
    if (value >> 2) != 0:
        value = value >> 2
        result = result + 2
    if (value >> 1) != 0:
        result = result + 1
    return result

def x80_integer(w:mutbuf, value:u64) -> u64:
    power = highest_bit(value)
    put(w, 128, value << (63 - power))
    put(w, 136, 20000 + power)
    return 0

def x80_real(w:mutbuf, magnitude:u64) -> u64:
    exponent = magnitude >> 52
    fraction = magnitude & 4503599627370495
    if exponent == 0:
        power = highest_bit(fraction)
        put(w, 128, fraction << (63 - power))
        put(w, 136, 18926 + power)
    else:
        put(w, 128, (fraction | 4503599627370496) << 11)
        put(w, 136, 18977 + exponent)
    return 0

def x80_multiply(w:mutbuf, b:u64, be:u64) -> u64:
    a = get(w, 128)
    al = a & 4294967295
    ah = a >> 32
    bl = b & 4294967295
    bh = b >> 32
    p00 = al * bl
    p01 = al * bh
    p10 = ah * bl
    p11 = ah * bh
    low = p00 + (p01 << 32)
    carry = choose(low < p00, 1, 0)
    old = low
    low = low + (p10 << 32)
    carry = carry + choose(low < old, 1, 0)
    high = p11 + (p01 >> 32) + (p10 >> 32) + carry
    exponent = get(w, 136) + be - 20000
    mantissa = 0
    rest = 0
    half = 0
    if (high >> 63) == 1:
        mantissa = high
        rest = low
        half = 9223372036854775808
        exponent = exponent + 1
    else:
        mantissa = (high << 1) | (low >> 63)
        rest = low & 9223372036854775807
        half = 4611686018427387904
    if rest > half or (rest == half and (mantissa & 1) == 1):
        mantissa = mantissa + 1
        if mantissa == 0:
            mantissa = 9223372036854775808
            exponent = exponent + 1
    put(w, 128, mantissa)
    put(w, 136, exponent)
    return 0

def scale_positive(w:mutbuf, amount:u64) -> u64:
    while amount >= 100:
        x80_multiply(w, P100_M, P100_E)
        amount = amount - 100
        if get(w, 136) > 21024:
            return 0
    while amount >= 10:
        x80_multiply(w, P10_M, P10_E)
        amount = amount - 10
    while amount > 0:
        x80_multiply(w, P1_M, P1_E)
        amount = amount - 1
    return 0

def scale_negative(w:mutbuf, amount:u64) -> u64:
    while amount >= 100:
        x80_multiply(w, N100_M, N100_E)
        amount = amount - 100
        if get(w, 136) < 18924:
            return 0
    while amount >= 10:
        x80_multiply(w, N10_M, N10_E)
        amount = amount - 10
    while amount > 0:
        x80_multiply(w, N1_M, N1_E)
        amount = amount - 1
    return 0

def x80_binary64(w:mutbuf) -> u64:
    mantissa = get(w, 128)
    exponent = get(w, 136)
    if mantissa == 0:
        return 0
    if exponent > 21023 or (exponent == 21023 and mantissa > 18446744073709549568):
        return 9218868437227405312
    if exponent >= 18978:
        value = mantissa >> 11
        rest = mantissa & 2047
        if rest > 1024 or (rest == 1024 and (value & 1) == 1):
            value = value + 1
            if value == 9007199254740992:
                value = value >> 1
                exponent = exponent + 1
        return ((exponent - 18977) << 52) | (value & 4503599627370495)
    shift = 18989 - exponent
    if shift > 64:
        return 0
    if shift == 64:
        return choose(mantissa > 9223372036854775808, 1, 0)
    value = mantissa >> shift
    rest = mantissa & ((1 << shift) - 1)
    half = 1 << (shift - 1)
    if rest > half or (rest == half and (value & 1) == 1):
        value = value + 1
    return value

def x80_less(w:mutbuf, mantissa:u64, exponent:u64) -> u64:
    actual = get(w, 136)
    return choose(actual < exponent or (actual == exponent and get(w, 128) < mantissa), 1, 0)

def real_plus_one(bits:u64) -> u64:
    magnitude = bits & 9223372036854775807
    exponent = magnitude >> 52
    if exponent == 2047 or exponent >= 1077:
        return bits
    if exponent < 968:
        return 4607182418800017408
    mantissa = (magnitude & 4503599627370495) | 4503599627370496
    low_value = mantissa << 3
    shift_one = 1078 - exponent
    high = 0
    low = 0
    if shift_one >= 64:
        high = 1 << (shift_one - 64)
    else:
        low = 1 << shift_one
    negative = 0
    if (bits >> 63) == 0:
        old = low
        low = low + low_value
        high = high + choose(low < old, 1, 0)
    elif high == 0 and low < low_value:
        negative = 1
        low = low_value - low
    else:
        borrow = choose(low < low_value, 1, 0)
        low = low - low_value
        high = high - borrow
    if high == 0 and low == 0:
        return 0
    power = choose(high == 0, highest_bit(low), 64 + highest_bit(high))
    result_exponent = exponent - 55 + power
    value = 0
    if power <= 52:
        value = low << (52 - power)
    else:
        shift = power - 52
        value = (low >> shift) | (high << (64 - shift))
        rest = low & ((1 << shift) - 1)
        half = 1 << (shift - 1)
        if rest > half or (rest == half and (value & 1) == 1):
            value = value + 1
            if value == 9007199254740992:
                value = value >> 1
                result_exponent = result_exponent + 1
    return (negative << 63) | (result_exponent << 52) | (value & 4503599627370495)

def digits_backward(w:mutbuf, value:u64) -> u64:
    at = 352
    while value >= 10:
        at = at - 1
        store(w, at, 48 + value % 10)
        value = value // 10
    at = at - 1
    store(w, at, 48 + value)
    return at

def finish_text(w:mutbuf, end:u64) -> u64:
    put(w, 64, 3)
    put(w, 72, 0)
    put(w, 80, end - 256)
    put(w, 104, 0)
    return 0

def render_integer(w:mutbuf, bits:u64) -> u64:
    value = bits
    at = 256
    if (bits >> 63) == 1:
        store(w, at, 45)
        at = at + 1
        value = 0 - bits
    source = digits_backward(w, value)
    while source < 352:
        store(w, at, byte(w, source))
        at = at + 1
        source = source + 1
    return finish_text(w, at)

def render_real(w:mutbuf, bits:u64) -> u64:
    magnitude = bits & 9223372036854775807
    if magnitude == 0:
        store(w, 256, 48)
        store(w, 257, 46)
        store(w, 258, 48)
        return finish_text(w, 259)
    at = 256
    if (bits >> 63) == 1:
        store(w, at, 45)
        at = at + 1
    if (magnitude >> 52) == 2047:
        store(w, at, 73)
        store(w, at + 1, 110)
        store(w, at + 2, 102)
        return finish_text(w, at + 3)
    x80_real(w, magnitude)
    decimal_exponent = render_scale(w)
    value = get(w, 128) >> (20063 - get(w, 136))
    source = digits_backward(w, value)
    count = 352 - source
    decimal_point = decimal_exponent + count
    if count > 15:
        divisor = 1
        left = count - 15
        while left > 0:
            divisor = divisor * 10
            left = left - 1
        rest = value % divisor
        value = value // divisor
        if rest >= divisor // 2:
            value = value + 1
        if value == 1000000000000000:
            value = 1
            decimal_point = decimal_point + 1
    while (value % 10) == 0:
        value = value // 10
    source = digits_backward(w, value)
    if decimal_point < 19997 or decimal_point > 20015:
        return render_scientific(w, at, source, decimal_point)
    return render_fixed(w, at, source, decimal_point)

def render_scale(w:mutbuf) -> u64:
    exponent = 20000
    if x80_less(w, P19_M, P19_E) == 0:
        while x80_less(w, P119_M, P119_E) == 0:
            exponent = exponent + 100
            x80_multiply(w, N100_M, N100_E)
        while x80_less(w, P29_M, P29_E) == 0:
            exponent = exponent + 10
            x80_multiply(w, N10_M, N10_E)
        while x80_less(w, P19_M, P19_E) == 0:
            exponent = exponent + 1
            x80_multiply(w, N1_M, N1_E)
    else:
        while x80_less(w, N97_M, N97_E) == 1:
            exponent = exponent - 100
            x80_multiply(w, P100_M, P100_E)
        while x80_less(w, P7_M, P7_E) == 1:
            exponent = exponent - 10
            x80_multiply(w, P10_M, P10_E)
        while x80_less(w, P17_M, P17_E) == 1:
            exponent = exponent - 1
            x80_multiply(w, P1_M, P1_E)
    return exponent

def render_scientific(w:mutbuf, at:u64, source:u64, decimal_point:u64) -> u64:
    store(w, at, byte(w, source))
    at = at + 1
    source = source + 1
    store(w, at, 46)
    at = at + 1
    if source == 352:
        store(w, at, 48)
        at = at + 1
    while source < 352:
        store(w, at, byte(w, source))
        at = at + 1
        source = source + 1
    store(w, at, 101)
    at = at + 1
    exponent = 0
    if decimal_point < 20001:
        store(w, at, 45)
        exponent = 20001 - decimal_point
    else:
        store(w, at, 43)
        exponent = decimal_point - 20001
    at = at + 1
    if exponent >= 100:
        store(w, at, 48 + exponent // 100)
        at = at + 1
        exponent = exponent % 100
    store(w, at, 48 + exponent // 10)
    store(w, at + 1, 48 + exponent % 10)
    return finish_text(w, at + 2)

def render_fixed(w:mutbuf, at:u64, source:u64, decimal_point:u64) -> u64:
    if decimal_point > 20000:
        count = decimal_point - 20000
        while count > 0:
            value = 48
            if source < 352:
                value = byte(w, source)
                source = source + 1
            store(w, at, value)
            at = at + 1
            count = count - 1
        store(w, at, 46)
        at = at + 1
        if source == 352:
            store(w, at, 48)
            at = at + 1
    else:
        store(w, at, 48)
        store(w, at + 1, 46)
        at = at + 2
        count = 20000 - decimal_point
        while count > 0:
            store(w, at, 48)
            at = at + 1
            count = count - 1
    while source < 352:
        store(w, at, byte(w, source))
        at = at + 1
        source = source + 1
    return finish_text(w, at)

def poison(w:mutbuf, reason:u64) -> u64:
    if get(w, 8) != 2:
        put(w, 88, reason)
    put(w, 0, AFFINITY_MAGIC)
    put(w, 8, 2)
    return 4294967293

def emit(o:mutbuf, w:mutbuf, status:u64) -> u64:
    if length(o) < 192:
        return 4294967293
    fill_range(o, 0, 192, 0)
    put(o, 0, AFFINITY_MAGIC)
    put(o, 8, status)
    at = 16
    while at < 128:
        put(o, at, get(w, at))
        at = at + 8
    if status == 0:
        put(o, 128, get(w, 64))
        put(o, 136, get(w, 80))
        if get(w, 72) == 0:
            at = 0
            while at < get(w, 80):
                store(o, 144 + at, byte(w, 256 + at))
                at = at + 1
    return status
'''


def rounded_binary80(numerator: int, denominator: int = 1) -> tuple[int, int]:
    """Exact rational -> binary80 normalized positive significand/exponent."""
    assert numerator > 0 and denominator > 0
    exponent = numerator.bit_length() - denominator.bit_length()
    if exponent >= 0:
        if numerator < denominator << exponent:
            exponent -= 1
    elif numerator << -exponent < denominator:
        exponent -= 1
    shift = 63 - exponent
    n, d = (numerator << shift, denominator) if shift >= 0 else (numerator, denominator << -shift)
    significand, remainder = divmod(n, d)
    if 2 * remainder > d or (2 * remainder == d and significand & 1):
        significand += 1
    if significand == 1 << 64:
        significand >>= 1
        exponent += 1
    assert 1 << 63 <= significand < 1 << 64
    return significand, exponent + 20000


def source_program():
    result = AFFINITY.replace('AFFINITY_MAGIC', str(MAGIC))
    constants = {'P100': 100, 'P10': 10, 'P1': 1, 'N100': -100, 'N10': -10,
                 'N1': -1, 'P19': 19, 'P119': 119, 'P29': 29, 'N97': -97,
                 'P7': 7, 'P17': 17}
    for name, exponent in constants.items():
        n, d = (10 ** exponent, 1) if exponent >= 0 else (1, 10 ** -exponent)
        mantissa, power = rounded_binary80(n, d)
        result = result.replace(name + '_M', str(mantissa)).replace(name + '_E', str(power))
    return result + VALUES[VALUES.index('\ndef read64('):]


class ScalarBuilder(Builder):
    """Emit Core's existing checked unsigned division/remainder operations."""
    def expr(self, node):
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.FloorDiv, ast.Mod)):
            left, right = self.expr(node.left), self.expr(node.right)
            assert left[1] == right[1] == 'u64'
            operation = 'int.div.checked' if isinstance(node.op, ast.FloorDiv) else 'int.rem.checked'
            return self.op(operation, [left, right], 'u64')
        return super().expr(node)


def document():
    nodes = ast.parse(source_program()).body
    names = {node.name: 'f' + str(i) for i, node in enumerate(nodes)}
    if len(names) != len(nodes):
        raise ValueError('duplicate namespace affinity HIA symbol')
    signatures = {node.name: ([a.annotation.id for a in node.args.args], node.returns.id)
                  for node in nodes}
    total = total_scalar_functions(nodes)
    functions = []
    for node in nodes:
        builder = ScalarBuilder(node, names, signatures, total)
        builder.statements(node.body)
        functions.append({'name': names[node.name],
                          'params': [builder.param(v) for v in builder.params],
                          'returns': [builder.returns], 'effects': ['read', 'write', 'trap'],
                          'entry': 'b0', 'blocks': builder.blocks})
    return compact_authoring_cfg({'schema': 'hepta.hia.program.v8',
                                  'module': 'agent_namespace_affinity', 'functions': functions})


def main():
    path = ROOT / 'examples/hia_bootstrap/agent_namespace_affinity.hiaasm'
    path.write_text(render_assembly(document()))
    print(path.name, path.stat().st_size)


if __name__ == '__main__':
    main()
