from pathlib import Path
from hashlib import sha256
import ctypes
import gzip
import json
import os
import resource
import sys
import time
import unittest

BASE=Path('/workspace/scratch/hia-audit-runtime-recovery-20261111')
SOURCE=BASE/'namespace-authoring-next'
DEV=BASE/'namespace-reconstruction/affinity-r1'
COMPILE=DEV/'native-r2/compile'
OUT=DEV/'native-r2/paired-validation'
OUT.mkdir(exist_ok=False)
os.environ['HIA_NAMESPACE_SQLITE_REFERENCE']=str(BASE/'namespace-reconstruction/sqlite-3.46.1-reference-oracle/libsqlite346-reference.so')
os.environ['HIA_NAMESPACE_SQLITE_REFERENCE_VERSION']='3.46.1'
os.environ['HIA_NAMESPACE_AFFINITY_LEDGER']=str(OUT/'vm-entries')
sys.path.insert(0,str(SOURCE))
from tests.test_hia_agent_namespace_affinity import NamespaceAffinityTests,CANARY
from hepta.hia_json_preflight_native import NativeHiaJsonImage

digest=lambda b:sha256(b).hexdigest()
summary=json.loads((COMPILE/'summary.json').read_bytes())
assert summary['status']=='PASS' and summary['source_and_compiler_unchanged']
pins=summary['before']
assert all(digest(Path(p).read_bytes())==h for p,h in pins.items())
manifest=json.loads((COMPILE/'manifest.json').read_bytes())
image_path=COMPILE/manifest['image_path'];image_raw=image_path.read_bytes()
assert digest(image_raw)==manifest['image_sha256']
assert manifest['source_sha256']==pins[str(SOURCE/'examples/hia_bootstrap/agent_namespace_affinity.hiaasm')]
for p in (image_path,COMPILE/'manifest.json',COMPILE/'summary.json',SOURCE/'hepta/hia_json_preflight_native.py',Path(__file__).resolve()):
 pins[str(p)]=digest(p.read_bytes())
image=NativeHiaJsonImage(image_raw,manifest['image_sha256'])
assert image.image_sha256==manifest['image_sha256']
resource.setrlimit(resource.RLIMIT_AS,(1024<<20,1024<<20))
resource.setrlimit(resource.RLIMIT_CPU,(300,300))
ledger=gzip.open(OUT/'native-invocations.jsonl.gz','wt',encoding='utf-8')
contexts={}
counters={'actual_native_entries':0,'full_entry_bytes_equal':0,'persistent_workspaces':0,'explicit_private_workspace_mutations':0}


class PairedNativeTests(NamespaceAffinityTests):
 def invoke(self,raw,work,output_size=192):
  before=bytes(work);key=id(work);mutation=None
  if key not in contexts:
   buf=ctypes.create_string_buffer(before+CANARY,len(before)+len(CANARY))
   contexts[key]=(work,buf,len(contexts)+1);counters['persistent_workspaces']+=1
  else:
   held,buf,_=contexts[key];self.assertIs(held,work)
   prior=bytes(buf[:len(before)])
   if prior!=before:
    mutation={'before_hex':prior.hex(),'after_hex':before.hex(),'scope':'explicit private state mutation'}
    counters['explicit_private_workspace_mutations']+=1
    ctypes.memmove(buf,before,len(before))
  _,buf,serial=contexts[key]
  expected_code,expected_payload=super().invoke(raw,work,output_size)
  original=bytes(raw);source=ctypes.create_string_buffer(original+CANARY,len(original)+len(CANARY))
  output=ctypes.create_string_buffer(bytes(output_size)+CANARY,output_size+len(CANARY))
  start=time.monotonic_ns();code=image._entry(source,len(original),output,output_size,buf,len(before));elapsed=time.monotonic_ns()-start
  counters['actual_native_entries']+=1
  actual_output=bytes(output[:output_size+len(CANARY)]);actual_work=bytes(buf[:len(before)+len(CANARY)])
  expected_output=expected_payload+CANARY;expected_work=bytes(work)+CANARY
  row={'entry':counters['actual_native_entries'],'test_id':self.id(),'workspace_id':serial,
   'input_hex':original.hex(),'pre_workspace_hex':before.hex(),'private_mutation':mutation,
   'expected_return':expected_code,'actual_return':code,'expected_output_hex':expected_output.hex(),'actual_output_hex':actual_output.hex(),
   'expected_workspace_hex':expected_work.hex(),'actual_workspace_hex':actual_work.hex(),
   'input_descriptor_bytes':len(original),'output_descriptor_bytes':output_size,'workspace_descriptor_bytes':len(before),
   'input_and_canary_unchanged':bytes(source[:len(original)+len(CANARY)])==original+CANARY,'native_elapsed_ns':elapsed}
  ledger.write(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n');ledger.flush()
  self.assertEqual(code,expected_code);self.assertEqual(actual_output,expected_output);self.assertEqual(actual_work,expected_work)
  self.assertTrue(row['input_and_canary_unchanged']);counters['full_entry_bytes_equal']+=1
  return expected_code,expected_payload


start=time.monotonic_ns()
suite=unittest.defaultTestLoader.loadTestsFromTestCase(PairedNativeTests);ids=[t.id() for t in suite]
result=unittest.TextTestRunner(verbosity=2).run(suite);ledger.close()
after={p:digest(Path(p).read_bytes()) for p in pins}
value={'scope':'DEVELOPMENT actual scalar affinity/TEXT/add-one image vs CoreVM and official SQLite3.46.1; no physical database/migration/installed-store claim',
 'image_sha256':manifest['image_sha256'],'loaded_image_sha256':image.image_sha256,'compiler_sha256':manifest['compiler_sha256'],
 'before':pins,'after':after,'source_unchanged':pins==after,'tests_loaded':len(ids),'test_ids':ids,'tests_run':result.testsRun,
 'errors':[(t.id(),s) for t,s in result.errors],'failures':[(t.id(),s) for t,s in result.failures],
 'skipped':result.skipped,'expected_failures':[(t.id(),s) for t,s in result.expectedFailures],'unexpected_successes':[t.id() for t in result.unexpectedSuccesses],
 'paired_vm_entries':PairedNativeTests.entries,'oracle_cases':PairedNativeTests.cases,'sqlite_version':PairedNativeTests.reference.version,
 'sqlite_source_id':PairedNativeTests.reference.source_id,'counters':counters,'wall_elapsed_ns':time.monotonic_ns()-start,
 'ledger':{'bytes':(OUT/'native-invocations.jsonl.gz').stat().st_size,'sha256':digest((OUT/'native-invocations.jsonl.gz').read_bytes())}}
passed=(0<result.testsRun==len(ids)==7 and pins==after and not any(value[k] for k in ('errors','failures','skipped','expected_failures','unexpected_successes'))
 and PairedNativeTests.entries==counters['actual_native_entries']==counters['full_entry_bytes_equal']==3370 and PairedNativeTests.cases==3111 and PairedNativeTests.reference.version=='3.46.1')
value['status']='PASS' if passed else 'FAIL'
raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();(OUT/'result.json').write_bytes(raw)
print(json.dumps({'status':value['status'],'counters':counters,'result_sha256':digest(raw)},sort_keys=True),flush=True)
raise SystemExit(0 if passed else 1)
