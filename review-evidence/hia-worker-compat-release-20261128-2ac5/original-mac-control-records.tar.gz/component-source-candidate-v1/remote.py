from pathlib import Path
import json,hashlib,base64,stat
R=Path("/home/qq/hia-worker-compat-release-20261128-2ac5")
names=[
"native-stage20-v1/result.json","native-stage20-v1-driver/intent.json","native-stage20-v1-driver/terminal.json","native-stage20-v1-driver/harness.py",
"native-stage20-v1/independent-01/report.json","native-stage20-v1/independent-02/report.json",
"author-v1/terminal.json","author-v1/stderr","author-v2/terminal.json","author-v2/stdout",
"native-refusals-v1/unknown-owner-alias/result.json","native-refusals-v1/terminal.json",
"native-refusals-v1/variants.json","native-refusals-v1/harness.py",
"native-refusals-v2/terminal.json","native-refusals-v2/author-stability.json",
"native-refusals-v2/unknown-owner-alias/result.json","native-refusals-v2/complete-member-footer/result.json","native-refusals-v2/native-entry-bind-magic/result.json",
"source/tools/generate_hia_worker_compat_release.py","source/tools/qualify_hia_worker_compat_release.py","source/examples/hia_bootstrap/release_stage_worker_compat.hiastd"]
files=[];missing=[]
for name in names:
 p=R/name
 if not p.exists():missing.append(name);continue
 assert p.is_file() and not p.is_symlink()
 a=p.stat();b=p.read_bytes();z=p.stat();assert (a.st_size,a.st_mtime_ns,a.st_ino)==(z.st_size,z.st_mtime_ns,z.st_ino)
 assert len(b)<262144
 files.append({"path":name,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"mode":stat.S_IMODE(a.st_mode),"content_base64":base64.b64encode(b).decode()})
print(json.dumps({"root":str(R),"files":files,"missing_optional_files":missing}))
