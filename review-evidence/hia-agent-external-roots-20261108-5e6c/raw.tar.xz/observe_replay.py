"""Observe actual runner IO while the unmodified runner checks its result.

This test observer calls the original subprocess communicate exactly once and
returns its unchanged result. It adds no process, cleanup or admission result.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import runpy
import subprocess
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument("--source-root", required=True)
parser.add_argument("--subjects", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
original = subprocess.Popen.communicate
records = []


def observe(process, *call_args, **call_kwargs):
    result = original(process, *call_args, **call_kwargs)
    supplied = call_args[0] if call_args else call_kwargs.get("input")
    if type(supplied) is not bytes:
        return result
    try:
        request = json.loads(supplied)
    except (ValueError, UnicodeError):
        return result
    if (type(request) is not dict or request.get("mode") not in {"reference", "native"}
            or set(request) != {"artifact", "artifact_sha256", "signatures", "cases", "warmup",
                                "repetitions", "mode", "foreign_buffer_exports", "snapshot_files"}):
        return result
    folder = args.output / "process-bytes"
    folder.mkdir(exist_ok=True)
    prefix = f"process-{len(records) + 1:02}"
    data = {"stdin": supplied, "stdout": result[0], "stderr": result[1],
            "artifact": Path(request["artifact"]).read_bytes()}
    for case, snapshots in enumerate(request["snapshot_files"]):
        for snapshot in snapshots:
            data[f"buffer-{case}-{snapshot['argument']}"] = Path(snapshot["path"]).read_bytes()
    row = {"mode": request["mode"], "argv": process.args, "pid": process.pid,
           "returncode": process.returncode, "files": {}}
    for name, raw in data.items():
        path = folder / f"{prefix}.{name}.bin"
        path.write_bytes(raw)
        row["files"][name] = {"path": str(path.relative_to(args.output)), "bytes": len(raw),
                              "sha256": sha256(raw).hexdigest()}
    records.append(row)
    (folder / "index.json").write_text(json.dumps(records, sort_keys=True, indent=2) + "\n")
    return result


with patch.object(subprocess.Popen, "communicate", observe):
    runpy.run_path(str(Path(__file__).with_name("replay.py")), run_name="__main__")
