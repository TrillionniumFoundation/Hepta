"""Retain one real borrowed-root regression replay; never deploy or adopt."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import traceback


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--subjects", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(root))
    from hepta.hia_agent_buffers import reference_observation
    from hepta.hia_agent_contract import installation_manifest
    from hepta.hia_agent_service import HIAAgentService
    from hepta.hia_program import verify_program
    from tools.hia_agent_native_qualification import Session, ToolClient

    call = {"function": "entry", "arguments": [{"bytes_hex": "0000"}]}
    exports = (("entry", 64),)
    expected = {
        "trap": "a753045d796c1f28f2e858773b4fcf704e37be507c0ed360e023e7a415dcdb4c",
        "budget": "a6f1f2ca8c7eb918006c377104448beed839882488de600e2993ba4a932d4d4e",
    }
    source_manifest = {str(path.relative_to(root)): sha256(path.read_bytes()).hexdigest()
                       for area in ("hepta", "docs", "tools") for path in sorted((root / area).rglob("*"))
                       if path.is_file() and "__pycache__" not in path.parts}
    assert not list(root.rglob("__pycache__")), "source-only import tree required"
    write(output / "source-manifest.json", source_manifest)
    write(output / "installation-manifest.json", installation_manifest())
    observations = []
    for name, limit in (("trap", 100), ("budget", 5)):
        source = (args.subjects / (name + ".core.json")).read_bytes()
        program = verify_program(json.loads(source))
        assert program.sha256 == expected[name] == sha256(source).hexdigest()
        (output / (name + ".core.json")).write_bytes(source)
        row = {"case": name, "core_sha256": program.sha256, "call": call,
               "steps_limit": limit, "heap_limit": 0, "exports": exports}
        try:
            row["observation"] = reference_observation(program, call, exports, steps=limit, heap=0)
        except Exception as error:
            row["error"] = {"type": type(error).__name__, "code": getattr(error, "code", None),
                            "message": str(error), "traceback": traceback.format_exc()}
        observations.append(row)
        write(output / "reference-observations.json", observations)

    artifacts = output / "files"
    artifacts.mkdir()
    service = HIAAgentService(output / "state", artifact_roots=(artifacts,))
    client = ToolClient(service.call)
    session = Session(client, prefix="external-root-replay")
    try:
        workload = {"schema": "hepta.hia.agent.workload.v2", "foreign_buffer_exports": [
            {"function": "entry", "max_buffer_bytes": 64}],
            "cases": [{**call, "expected": {"status": "trapped"}}],
            "warmup_iterations": 0, "repetitions": 1}
        session.freeze(workload)
        subject = session.import_program(json.loads((args.subjects / "trap.core.json").read_bytes()))
        admitted = session.verify(subject)
        built = session.emit(subject, receipts=[admitted["verification_receipt"]])
        encoded = session.encoding(subject, built)
        receipts = [admitted["verification_receipt"], encoded["verification_receipt"]]
        evaluation = session.evaluate(built, built, receipts=receipts)
        measurements = session.read_json(evaluation["measurements"])
        write(output / "admission.json", admitted)
        write(output / "build.json", built)
        write(output / "encoding.json", encoded)
        write(output / "evaluation.json", evaluation)
        write(output / "measurements.json", measurements)
        counts = {name: service.store.db.execute("SELECT COUNT(*) FROM " + name).fetchone()[0]
                  for name in ("slots", "leases")}
        summary = {"schema": "hepta.hia.external-root-regression-replay.v1",
                   "source_root": str(root), "same_core_self_evaluation": True,
                   "core_sha256": expected["trap"], "reference": observations,
                   "evaluation_outcome": evaluation["outcome"],
                   "planned_workload_complete": evaluation["planned_workload_complete"],
                   "termination_confirmed": evaluation["termination_confirmed"],
                   "retained_slots_leases": counts, "tool_calls": len(client.records),
                   "new_formal_proofs": False, "compiler_refinement_proved": False,
                   "native_heap_accounting_extended": False,
                   "scope": "Exact two stopped Core invocations and one same-Core Agent evaluation; no adoption."}
        write(output / "summary.json", summary)
    finally:
        write(output / "tool-records.json", client.records)
        service.close()
    print(json.dumps({"output": str(output), "evaluation_outcome": evaluation["outcome"],
                      "reference_outcomes": [row.get("observation", {}).get("status", row.get("error", {}).get("code"))
                                             for row in observations], "slots_leases": counts}, sort_keys=True))


if __name__ == "__main__":
    main()
