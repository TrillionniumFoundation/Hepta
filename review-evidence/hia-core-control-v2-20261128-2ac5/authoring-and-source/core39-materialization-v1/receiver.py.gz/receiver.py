import pathlib,subprocess,json,hashlib,os,sys,tarfile,io
os.umask(0o022)
base=pathlib.Path('/home/qian-qi/hia-core39-native-development-20261128-2ac5')
q=base/'materialization-v1';q.mkdir(mode=0o700,exist_ok=False)
raw=sys.stdin.buffer.read();(q/'transport.tar.gz').write_bytes(raw)
expected=sys.argv[1];assert hashlib.sha256(raw).hexdigest()==expected
tar=tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')
for member in tar.getmembers():
 p=pathlib.PurePosixPath(member.name)
 assert member.isfile() and not p.is_absolute() and '..' not in p.parts
 data=tar.extractfile(member).read();dst=q/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
r=base/'source';assert not r.exists();r.mkdir(mode=0o700)
def run(args,**kw):
 t=subprocess.run(args,cwd=r,capture_output=True,**kw)
 with (q/'git.log').open('ab') as f:f.write(repr(args).encode()+b'\n'+t.stdout+t.stderr)
 assert t.returncode==0,(args,t.returncode,t.stderr.decode())
 return t.stdout
run(['git','init'])
alternates=[];seen=set()
def add(path):
 path=pathlib.Path(path).resolve()
 if str(path) in seen:return
 seen.add(str(path));assert len(seen)<=256
 if not path.is_dir():return
 alternates.append(str(path))
 alternate=path/'info/alternates'
 if alternate.exists():
  for value in alternate.read_text().splitlines():
   other=pathlib.Path(value);add(other if other.is_absolute() else path/other)
add('/home/qian-qi/hia-core-three-ad419-development-20261127-2ac5/source/.git/objects')
(r/'.git/objects/info/alternates').write_text('\n'.join(alternates)+'\n')
run(['git','index-pack','--stdin'],input=(q/'objects.pack').read_bytes())
head='a706c6e1b6aa5e5ba0e0fcec2c1c5a9db36ea21f';(r/'.git/shallow').write_text(head+'\n')
objects=json.loads((q/'base-objects.json').read_bytes())
check=run(['git','cat-file','--batch-check'],input=('\n'.join(objects)+'\n').encode()).decode().splitlines()
assert len(check)==len(objects) and all('missing' not in line for line in check)
run(['git','checkout','--detach',head])
assert not run(['git','status','--porcelain'])
overlay=json.loads((q/'overlay.json').read_bytes())
for name,item in overlay.items():
 p=r/name;data=(q/'overlay'/name).read_bytes()
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 if item['base_blob'] is None:assert not p.exists(),name
 else:
  old=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(old)).encode()+b'\0'+old).hexdigest()==item['base_blob'],name
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(item['mode'])
pins=json.loads((q/'source-pins.json').read_bytes())
assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==v for n,v in pins.items())
intent={'scope':'DEVELOPMENT_ONLY','base':head,'transport_sha256':expected,'object_count':len(objects),'overlay_count':len(overlay),'captured_paths':len(pins),'source_unchanged':True,'native_started':False}
(q/'terminal.json').write_text(json.dumps(intent,sort_keys=True,indent=2)+'\n')
print(json.dumps(intent),flush=True)
