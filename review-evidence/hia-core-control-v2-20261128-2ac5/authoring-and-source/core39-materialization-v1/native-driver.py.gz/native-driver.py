import pathlib,subprocess,json,hashlib,os,sys,time,traceback,struct,importlib,unittest
os.umask(0o022)
base=pathlib.Path('/home/qian-qi/hia-core39-native-development-20261128-2ac5')
root=base/'source';q=base/'native-build-v1';q.mkdir(mode=0o700)
tmp=q/'tmp';tmp.mkdir(mode=0o700);os.environ['TMPDIR']=str(tmp);os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.chdir(root);sys.path.insert(0,str(root))
sha=lambda b:hashlib.sha256(b).hexdigest()
compiler=pathlib.Path('/home/qian-qi/hia-native-current-future-20261127-2ac5/chain-v2/cold/qualification/base/B3.flat')
compiler_raw=compiler.read_bytes()
assert len(compiler_raw)==641344 and sha(compiler_raw)=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
source_map=json.loads((base/'materialization-v1/source-pins.json').read_bytes())
def current_pins():return {name:sha((root/name).read_bytes()) for name in source_map}
assert current_pins()==source_map
result={'schema':'hepta.hia.core-control-v2-development.v1','scope':'DEVELOPMENT_ONLY','source_base':'a706c6e1b6aa5e5ba0e0fcec2c1c5a9db36ea21f','passed':False,'matching_cold_qualified':False,'production_activated':False,'compiler_sha256':sha(compiler_raw),'compile_receipts':[],'source_before':source_map}
(q/'intent.json').write_text(json.dumps({'pid':os.getpid(),'started_ns':time.time_ns(),'scope':result['scope'],'compiler_sha256':result['compiler_sha256'],'original_compile_wall_seconds':20,'capacity':1048576},sort_keys=True,indent=2)+'\n')
start=time.monotonic()
try:
 from tools.qualify_hia_selfhost import compile_stage
 from tools.build_hia_source_build import _check_pack_output
 from hepta import hia_core_lowering_selection as selected
 from hepta.hia_native_continuation_selection import resource_names,_RUNTIME,INPROCESS_SCHEMA_V2
 from tools.build_hia_native_continuation import pack_input,_link_guarded_packer,_pack_aggregate,_checked_pack_result
 from tools.generate_hia_native_filter import read_adapter_binding
 def compile_at(folder,label,raw):
  folder.mkdir(mode=0o700)
  p,receipt=compile_stage(folder,label,compiler,raw)
  whole=(folder/(label+'.output.bin')).read_bytes()
  image=_check_pack_output(receipt,whole,artifact=compiler_raw,source=raw)
  assert p.read_bytes()==image
  result['compile_receipts'].append({'label':label,'source_sha256':sha(raw),'image_sha256':sha(image),'receipt':receipt})
  print(json.dumps({'compiled':label,'bytes':len(image),'elapsed_seconds':receipt.get('wall_elapsed_ns',0)/1e9}),flush=True)
  return p,image
 aggregate=q/'aggregate';aggregate.mkdir(mode=0o700)
 policy=aggregate/'policy';policy.mkdir(mode=0o700)
 abi_raw=(root/selected.ABI_SOURCE_V2).read_bytes();abi=selected.checked_abi_v2(abi_raw)
 names=tuple(pathlib.Path(n).stem for n in selected.source_names(abi))
 manifests={};images=[]
 for name in names:
  raw=(root/'examples/hia_bootstrap'/ (name+'.hepta')).read_bytes()
  folder=policy/name;p,image=compile_at(folder,name,raw);images.append(image)
  value={'schema':selected.UNIT_SCHEMA_V2,'source_sha256':sha(raw),'image_path':p.name,'image_sha256':sha(image),'compiler_sha256':sha(compiler_raw)}
  (folder/'manifest.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
  manifests[name]=name+'/manifest.json'
 policy_manifest=policy/'manifest.json'
 policy_manifest.write_text(json.dumps({'schema':selected.SCHEMA_V2,'abi_sha256':sha(abi_raw),'compiler_sha256':sha(compiler_raw),'unit_manifests':manifests},sort_keys=True,indent=2)+'\n')
 generated={}
 for name,actual in [('continuation_policy','continuation_policy_v2'),('continuation_inprocess_packer','continuation_inprocess_packer_v2'),('continuation_guard_check','continuation_guard_check'),('continuation_guarded_packer','continuation_guarded_packer')]:
  generated[name]=compile_at(aggregate/name,name,(root/'examples/hia_bootstrap'/(actual+'.hepta')).read_bytes())
 binding=read_adapter_binding((root/'examples/hia_bootstrap/continuation_guarded_packer.hepta').read_bytes(),(root/'tools/hia_continuation_guard_syscalls.S').read_bytes(),calls=2)
 wire=pack_input(generated['continuation_policy'][1],images[0],images[1:],abi)
 (aggregate/'pack.input').write_bytes(wire)
 runner,linkreceipt=_link_guarded_packer(aggregate,'inprocess',generated,binding,None,'continuation_inprocess_packer')
 receipt,padded=_pack_aggregate(aggregate,'inprocess',runner,generated['continuation_inprocess_packer'][1],wire,64<<20)
 image=_checked_pack_result(receipt,padded,image=generated['continuation_inprocess_packer'][1],source=wire,capacity=64<<20,transport='inprocess')
 (aggregate/'inprocess.pack.output').write_bytes(padded)
 (aggregate/'inprocess.pack.receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
 target=aggregate/'continuation.image.bin';target.write_bytes(image);target.chmod(0o400)
 value={'schema':INPROCESS_SCHEMA_V2,'kind':'core-lowering','policy_bundle':'policy/manifest.json','policy_bundle_sha256':sha(policy_manifest.read_bytes()),'compiler_sha256':sha(compiler_raw),'image_path':target.name,'image_sha256':sha(image),'resource_sha256':{n:sha((root/n).read_bytes()) for n in resource_names('core-lowering',core_v2=True)},'runtime_sha256':{'hepta/'+n:sha((root/'hepta'/n).read_bytes()) for n in _RUNTIME}}
 outer=aggregate/'inprocess-manifest.json';outer.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
 result['aggregate']={'manifest':str(outer),'manifest_sha256':sha(outer.read_bytes()),'image_sha256':sha(image),'image_bytes':len(image),'link_receipt':linkreceipt,'pack_receipt':receipt}
 for family in ('compare','integer','unpack'):
  module=importlib.import_module('hepta.hia_core_'+family+'_selection')
  inputs=module.current_inputs();folder=q/('companion-'+family)
  _p,image=compile_at(folder,'core-'+family,inputs[module.HIA_SOURCE])
  target=folder/('core-'+family+'.image.bin')
  if _p!=target:target.write_bytes(image)
  value={'schema':module.SCHEMA,'source_sha256':sha(inputs[module.HIA_SOURCE]),'abi_sha256':sha(inputs[module.ABI_SOURCE]),'bridge_sha256':sha(inputs[module.BRIDGE_SOURCE]),'selection_sha256':sha(inputs[module.SELECTION_SOURCE]),'image_path':target.name,'image_sha256':sha(image),'compiler_sha256':sha(compiler_raw)}
  manifest=folder/'manifest.json';manifest.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
  os.environ[module.SELECTOR]=str(manifest)
 os.environ['HEPTA_HIA_CORE_LOWERING_DEVELOPMENT_MANIFEST']=str(policy_manifest)
 os.environ['HEPTA_HIA_CORE_CONTROL_V2_DEVELOPMENT_MANIFEST']=str(outer)
 os.environ['HEPTA_HIA_CORE_UNPACK_FIXTURE_EVIDENCE']=str(q/'original-unpack-evidence')
 selectors=['tests.test_hia_core_unpack_native.UnpackCompositionNativeTests','tests.test_hia_core_control_v2.CoreControlV2NativeTests']
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in selectors)
 assert suite.countTestCases()==9,suite.countTestCases()
 with (q/'tests.stderr').open('w') as stream:
  test=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 result['tests']={'selectors':selectors,'planned':9,'tests_run':test.testsRun,'errors':test.errors,'failures':test.failures,'skipped':test.skipped,'unexpected_successes':test.unexpectedSuccesses,'passed':test.wasSuccessful() and test.testsRun==9 and not test.skipped}
 result['passed']=result['tests']['passed']
except BaseException as error:
 result['error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
 traceback.print_exc()
finally:
 result['elapsed_seconds']=time.monotonic()-start
 result['source_after']=current_pins();result['source_unchanged']=result['source_after']==source_map and compiler.read_bytes()==compiler_raw
 result['passed']=result['passed'] and result['source_unchanged']
 def encode(obj):return str(obj)
 (q/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2,default=encode)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('source_before','source_after','compile_receipts','aggregate')},default=encode),flush=True)
raise SystemExit(0 if result['passed'] else 1)
