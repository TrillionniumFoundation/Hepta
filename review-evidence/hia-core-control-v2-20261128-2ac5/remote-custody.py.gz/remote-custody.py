import pathlib,json,hashlib,tarfile,gzip,io,os,time
base=pathlib.Path('/home/qian-qi/hia-core39-native-development-20261128-2ac5')
q=base/'evidence-v1';q.mkdir(mode=0o700)
source=base/'native-build-v1'
terminal=json.loads((source/'terminal.json').read_bytes())
assert terminal['passed'] is True and terminal['source_unchanged'] is True and terminal['tests']['tests_run']==10 and not terminal['tests']['skipped']
assert terminal['matching_cold_qualified'] is False
files=sorted([p for p in source.rglob('*') if p.is_file()])
files += [base/'materialization-v1'/name for name in ('native-driver.py','source-pins.json')]
rows=[]
archive=q/'native-complete.tar.gz'
with archive.open('xb') as output,gzip.GzipFile(fileobj=output,mode='wb',mtime=0,compresslevel=9) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
 for p in files:
  assert not p.is_symlink(),str(p)
  raw=p.read_bytes();name=p.relative_to(base).as_posix();mode=p.stat().st_mode&0o777
  rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':mode})
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=mode;info.mtime=0
  tar.addfile(info,io.BytesIO(raw))
manifest={'schema':'hepta.hia.complete-file-custody.v1','scope':'DEVELOPMENT_ONLY','matching_cold_qualified':False,'files':rows,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()}}
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):
  raw=tar.extractfile(m).read()
  assert m.name==row['path'] and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and m.mode==row['mode']
for p,row in zip(files,rows):
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
(q/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps({'files':len(rows),'raw_bytes':sum(r['bytes'] for r in rows),'archive':manifest['archive'],'remote_readback':True}),flush=True)
