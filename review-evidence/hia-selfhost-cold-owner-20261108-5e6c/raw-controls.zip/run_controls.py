from pathlib import Path
import contextlib,hashlib,importlib.util,io,json,sys,time,unittest
root=Path('/workspace/scratch/5e6c25ac6d7b/hepta-ci14b-cold-owner')
evidence=Path(sys.argv[1]);evidence.mkdir(parents=True)
source=evidence/'source';files={}
for name in ('tools/hia_selfhost_process_owner.py','tools/replay_hia_selfhost_cold.py','tests/test_hia_selfhost_process_owner.py'):
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);raw=(root/name).read_bytes();p.write_bytes(raw);files[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
sys.path.insert(0,str(source))
spec=importlib.util.spec_from_file_location('test_hia_selfhost_process_owner',source/'tests/test_hia_selfhost_process_owner.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
stdout,stderr=io.StringIO(),io.StringIO();started=time.monotonic_ns()
with contextlib.redirect_stdout(stdout):
 result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
(evidence/'stdout.log').write_text(stdout.getvalue());(evidence/'stderr.log').write_text(stderr.getvalue())
observations=[]
for i,row in enumerate(module.ColdProcessOwnerTests.observations):
 dest=evidence/('case-%02d'%i);dest.mkdir();hashes={}
 for name,encoded in row['files_hex'].items():
  raw=bytes.fromhex(encoded);(dest/name).write_bytes(raw);hashes[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 observations.append({'test':row['test'],'result':row['result'],'files':hashes})
report={'schema':'hepta.hia.cold-owner-control-run.v1','source':files,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'elapsed_ns':time.monotonic_ns()-started,'native_qualifications':0,'observations':observations}
(evidence/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='observations'}))
print(stderr.getvalue()[-8000:])
sys.exit(0 if result.wasSuccessful() else 1)
