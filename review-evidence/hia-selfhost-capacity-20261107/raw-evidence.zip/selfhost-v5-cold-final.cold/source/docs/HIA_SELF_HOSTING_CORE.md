# HIA fixed-Core native self-hosting

This is a real, deliberately bounded self-hosting compiler for a fixed subset of
`hia-asm.v1` / `hepta.hia.program.v8`. The complete compiler is
`examples/hia_bootstrap/selfhost.hiaasm`. Its scanner, parser, semantic verifier,
control-flow checker, x86-64 encoder and relocation writer are HIA functions.
It accepts that entire source file as ordinary input bytes and produces the next
compiler as executable machine bytes. The old `compile_constant` component and
its explicitly open qualification remain separate.

Run the source-bound qualification on Linux x86-64:

```sh
python tools/qualify_hia_selfhost.py --output /tmp/hia-selfhost.json
python tools/replay_hia_selfhost_cold.py --output /tmp/hia-selfhost-cold.json
python -m unittest tests.test_hia_selfhost tests.test_hia_selfhost_contract
```

The qualification creates an evidence directory next to the JSON report. It
retains source inputs, the B0 build receipt, each generated image, every native
invocation receipt, raw child stdout/stderr, and checksums. A passing exit
requires every check to pass.

## Fixed version and support identity

The machine-readable [support contract](HIA_SELFHOST_CORE_SUPPORT.json) names
`selfhost-core-linux-x86_64-v5`, the sole target, the seed and successor ABIs,
resource limits, supported and excluded features, and SHA-256 identities for
the compiler assembly, authoring aid, loader, qualification, test fixtures and
complete Python seed package. It is checked before B0. A stale source file,
changed loader, or broadened support declaration fails that check. To review
and regenerate the contract after an intentional source change, run:

```sh
python tools/generate_hia_selfhost_contract.py
python tools/generate_hia_selfhost_contract.py --check
```

The static contract is a support and identity declaration, not a successful
execution receipt. The runtime qualification additionally records the exact
B0 shared-library digest, actual loaded seed modules, CPython executable and
version, GNU linker identity, source closure, and original and modified native
generations. Git commit/tree metadata is supplementary; actual file hashes
remain authoritative, including when a worktree is dirty. No commit identifier
is embedded in its own source lock.

The cold runner copies only these pinned source files into a newly created
directory. It starts isolated CPython with site packages disabled, a fresh
home and temporary directory, no inherited Python path, and no seed, successor
or bytecode caches. It rebuilds B0 and executes the entire qualification there,
then verifies the exported and original bytes again. The original source tree
is not on the child's import path. This establishes source/process/cache cold
replay on the measured host; it is not a new VM or an independent toolchain.

## Fixed seed and actual generation chain

| Generation | Executed compiler | Input | Output construction |
|---|---|---|---|
| B0 | Existing Python HIA assembler, Core verifier, direct x86 backend; GNU ld | Complete checked-in HIA compiler source | Seed shared library with explicit borrowed-byte export `f0` |
| B1 | That seed's **native HIA compiler** | Complete compiler source | HIA emits a flat x86-64 image |
| B2 | The B1 image | Complete compiler source | HIA parses, verifies and emits the B2 image |
| B3 | The B2 image | Complete compiler source | HIA parses, verifies and emits the B3 image |

B1, B2 and B3 must be byte-identical. They are actual executable compiler
artifacts. Their input is the full source, including all compiler functions;
lexing the source or compiling a separate small example does not close the gate.

`tools/generate_hia_selfhost.py` is a reproducible **authoring aid** that lowers a
restricted development notation into checked-in HIA assembly. It is used to edit
the source before B0. It is neither shipped inside the compiler nor imported by
the successor loader. The qualification itself reads the checked-in assembly;
it does not run this authoring aid. There are no source-hash dispatch tables,
precompiled successor blobs, Python callbacks, runtime token streams, or host
parse/code-generation calls in successor compilation.

`tools/hia_selfhost_child.py` uses only the Python standard library. It hashes
and copies input bytes, loads the sealed B0 shared library or maps a successor
image read/write then changes it to read/execute, and calls the fixed ABI. It
asserts that no `hepta.*` or compiler authoring modules are loaded. The loader
never rewrites instruction bytes, builds an object, resolves relocations,
interprets Core or links a successor. The HIA compiler handles every relative
call and branch relocation in its output.

The report's claims are specific to this fixed subset. It does not claim that
all HIA opcodes, modules or target architectures are self-hosted, nor that the
compiler has a formal refinement proof. Finite test evidence and a bootstrap
fixed point do not constitute such a proof.

## The chosen Core subset

The flat-image input is ordinary HIA assembly with the fixed header
`hia-asm.v1 hepta.hia.program.v8 selfhost`. Explicit `selfhost_elf` selects the
bounded ELF object profile described below. Names are numeric: contiguous `f0`,
`f1`, ... functions; contiguous `b0`, `b1`, ... blocks within each function;
and `vN` SSA values. Function signature variables are `v0`, `v1`, ... and the
entry block must exactly reproduce their names and types. SSA numbers elsewhere
need not be contiguous, but each definition must be unique in its function.
Only ASCII spaces and LF separate tokens. Decimal unsigned literals forbid
leading zeroes and are checked for `u64` overflow. The grammar recognizes the
explicit JSON attribute forms that these operations require.
The existing assembly grammar's adjacency rules are retained: a declaration or
edge name, opcode, `ret`, `effects`, or `entry` directly precedes its opening
parenthesis; `entry(bN)` and `->` remain contiguous. Required separators before
effect/entry clauses, between branch targets and before instruction attributes
cannot be removed. Optional spaces inside parameter/argument lists remain valid.

| Area | Accepted constructs |
|---|---|
| Values | `u64`, `usize` (64 bits), `u32`, `u8`, `bool`, borrowed `readbuf` and `mutbuf` parameters |
| Constants | Typed integer literals and `true` / `false` boolean literals |
| Integer operations | `int.add.wrap`, `int.sub.wrap`, `int.mul.wrap`, `bit.and`, `bit.or`, `bit.xor`, checked left/right shifts |
| Conditions | Unsigned `compare.eq`, `ne`, `lt`, `le`, `gt`, `ge`; `bool.and`, `bool.or`, `bool.not` |
| Casts | `int.cast` with `{"mode":"wrap"}` between integer types |
| Bytes | `buffer.len`, `buffer.load`, `buffer.store`, `buffer.swap` |
| Calls | Scalar-return direct `call` to any numbered function in an acyclic call graph, with exact parameter/return types |
| Control flow | `ret`, `jump`, `branch` with explicit, typed block arguments |
| Effects | Every function explicitly declares `effects(read,write,trap)` |

The compiler returns the generated image size on success, `0xffffffff` for
invalid/unsupported input, and `0xfffffffe` for insufficient output or workspace
capacity. B0 uses the existing packed ABI-status plus Core-result wrapper. Flat
successors return a zero-extended Core `u32`; their wrapper relies on the
qualification caller to provide live, disjoint allocations and does not add a
public arbitrary-pointer validation interface. The Core compiler itself checks
its source/output extents and required workspace before parsing.

Each function returns exactly one scalar; returned loans and owners are excluded.
There are no allocations, deallocations, foreign calls, callbacks, arbitrary
pointers, recursion, exceptions, indirect branches or host library imports in
the subset. The fixed exported function `f0` accepts exactly three buffers
`(readbuf, mutbuf, mutbuf)` and returns `u32`. Private helper functions can have
scalar and borrowed-buffer parameters.

The native verifier checks grammar, literal widths, unique SSA definitions,
block-local scope, operation arity/types, buffer permissions, call signatures,
edge signatures, existing targets and graph reachability. Inbound edges to
`b0` are forbidden. The native HIA checker records the complete directed call
graph, rejects missing targets, and marks functions whose callees are already
acyclic. After at most one pass per function, every function must be marked.
Backward calls are therefore admitted when they do not create a cycle. Direct
and indirect recursion are rejected, including cycles in unused helper
functions. Repeated mutable buffer arguments in one call or edge
are rejected. Every edge also rejects repeated `readbuf` SSA arguments, matching
Core's linear capability transfer rule, even on a statically untaken branch.
Calls may pass the same read-only loan more than once. Buffers can only originate in parameters and flow through checked
edges/calls; the subset cannot create aliases by producing new buffer values.
The host supplies disjoint live allocations at the external entrypoint.

The bounds are part of the compiler profile:

| Resource | Maximum |
|---|---:|
| Source bytes / output capacity | 1,048,576 each |
| Workspace required | 1,048,576 bytes |
| Functions | 128 |
| Blocks per function / all functions | 256 / 1,536 |
| Function or block parameters / call or edge arguments | 16 |
| SSA variable index per function | 2,047 |
| Instructions across the module | 8,192 |
| Core JSON structural nodes | 262,144 |
| Relative relocations | 12,000 |

These bounds also bound stack frames and the accepted Core structure. The
checked acyclic graph bounds native call depth by the 128-function limit.
The call graph and its marks occupy bytes 858,368 through 875,775 of the
existing 1 MiB workspace, after the complete relative-relocation table; they
do not overlap live parser, SSA or relocation state. Every compilation clears
this state, including when the caller supplies nonzero scratch contents.
Each native parse pass counts the exact corresponding Core JSON nodes, including
containers, declarations, parameters, instruction results, attributes and both
branch arms. Header word 248 records the count; the count starts at four for
the root object, schema, module and function-list nodes. More than 262,144 nodes
is rejected before any output write. The maximum instruction count does not
bypass the general Core's structural budget.

The unchanged grammar also bounds canonical Core JSON bytes. Conservative
budgets of 1,024 bytes for the root and each function's own fields, 2,048 bytes
per block excluding its operations, and 512 bytes per operation give at most
7,472,128 bytes, below the general Core's 8 MiB limit. These bounds use the
fixed identifier lengths, 16-argument/parameter limit, single scalar output,
single optional attribute and unsigned 64-bit literal limit.
The text frontend's separate general-purpose presentation limits are not
reimplemented as a dependency of the native compiler.

### v5 capacity qualification

The previous v4 profile allowed 3,072 instructions; v5 raises this to 8,192
without increasing source, output or workspace bytes, stack/CPU/address-space
limits, or child deadlines. The current compiler contains 3,044 instructions,
leaving 5,148 instruction slots in the v5 profile. Owned resources, returned
loans, recursion, arbitrary identifiers and general external linking remain
outside this profile.

The relocation table remains 12,000 records in the same workspace layout.
An instruction contributes at most one call relocation, a block at most two
edge relocations, and the wrapper one call: `1 + 8192 + 2*1536 = 11265`.
Relocations are counted during preflight as well as emission. Every displacement
lies within the checked 1 MiB output, well inside signed x86-64 `rel32` range;
the ELF writer still emits its existing ELF64 fields and resolved `.text`.

Qualification executes 3,072-, 3,073- and 8,192-instruction programs using both
the original and modified compilers. An independent Core VM checks the same
operations and calls, with only the unused borrowed entry parameters removed
to expose a scalar entry. The 8,192-operation result is 8,176. Its ELF `.text`
must equal the flat image; one-byte-short output is transactionally refused.
8,193 operations are valid general Core but refused by this fixed native profile.

Separate 910,057-byte fixtures have exactly 262,144 and 262,145 structural nodes.
The general Core accepts the first and rejects the second. Native parsing must
make the same structural decision: the first reaches output-capacity preflight,
while the second returns invalid-source with error 58 before output changes.
All source bytes, raw invocation logs, output hashes, counters and independent
reference outcomes are retained, including the refusal cases. These checks run
inside the source-only cold replay and do not weaken its acceptance conditions.

An additional upgrade replay consumes the retained v4 B3 image and source from
the exact `894d2dfce54ff25271b8de2c18c902394484d5cc` source release. Their expected
SHA-256 digests are pinned in the replay tool, and its original receipt must
agree. It first demonstrates the old 3,073-operation refusal, then has that
same native v4 compiler compile the 3,044-operation v5 source. U1 compiles U2,
U2 compiles U3, all three must match, and U3 must compile and execute the
8,192-operation case. This upgrade uses no Python parser/code generator or
external assembler/linker. It does reuse, rather than freshly rebuild, the
historical v4 B3; the independent v5 cold replay still starts from B0.

```sh
python tools/replay_hia_selfhost_upgrade.py \
  --previous-evidence <retained-v4-qualification.evidence> \
  --output <new-upgrade-report.json>
```

## Parse, validate and generate

Compilation runs three passes over private source bytes:

1. Parse all functions/blocks, check local types and SSA scope, and collect
   signatures, block-edge metadata and the direct-call graph. Check target
   validity, block reachability and absence of call cycles.
2. Parse again, validate all calls and edge signatures against the complete
   metadata, and count the exact encoded output size without writing output.
3. After the full validation and capacity checks succeed, parse again and emit
   actual machine bytes, then apply HIA-written relative relocations.

For rejected source or insufficient output capacity, output bytes remain
unchanged. Workspace is scratch state and may change on failure. Determinism of
these passes depends on the caller supplying private, nonconcurrently modified
source and disjoint output/workspace; the qualification loader makes those
copies. Workspace need not initially contain zeroes; B3 deliberately runs with
nonzero scratch contents.

Integer widths are normalized after wrapping operations and casts. Generated
buffer accesses check the index against the carried loan length. Checked shifts
check their type's bit width. Failed runtime bounds/shift checks execute `ud2`;
this is a trap, with no promise of transactional rollback for an arbitrary
compiled program. The compiler's transactional output property applies to its
validation/capacity rejection path.

Generated functions use only caller-saved registers and `rbp`. SSA values live
in frame slots; edge arguments use temporary slots so parallel transfers remain
correct even on loops. Calls pass an argument array and a result slot. The
emitter touches each stack page while reserving a frame. The flat image's first
instruction is its SysV entry wrapper; all calls and branches are relative and
there are no external symbol relocations.

## Borrowed-resource batch: byte swap

Version 4 adds `buffer.swap(mutbuf, usize, usize)`, with no result binding.
It preserves the existing borrowed-buffer lifetime model and original size
limits. Both indices are compared with the carried buffer length before either
pointer is formed or either byte is read or written. Equal valid indices are a
no-op; equal invalid indices still trap. The instruction exchanges exactly two
bytes without allocating storage or creating a new loan. Read-only buffers,
incorrect index types, result bindings and incorrect arities are rejected.

The qualification records a separate resource batch for the original and the
modified fixed-point compiler. Its independent general Core reference runs
before B0 and uses owned allocation, borrowing, initialization, swapping,
loads, loan ending and owner cleanup to expose the resulting bytes. The native
program uses the supported borrowed parameters. Nine cases cover both swap
directions, interior bytes, equal indices, either invalid operand, the maximum
`usize` value and an empty extent. Five malformed programs are independently
rejected by both checkers. A native ELF swap object must contain the same text
bytes as the flat image from the same compiler.

For each runtime trap, the loader's optional qualification-only shared output
mapping retains the actual bytes after the child terminates with `SIGILL`.
Each failing swap must leave its input bytes unchanged. A positive control
performs a store before a failing swap: the retained output must contain that
store, confirming that the observer sees actual writes and that an arbitrary
program has no rollback guarantee. The loader does not catch signals or change
native control flow. The report preserves preimage/output hashes, independent
results, child exit status, raw logs and wall time, including failed executions.

This batch does not add allocation, owner movement, new loans, returned loans
or recursion to Selfhost-Core. Those constructs remain outside the fixed
profile; the general Core reference's broader ownership support is not evidence
that the native self-hosting checker implements it. These finite cases are
regression evidence rather than a general checker or refinement proof.

## Modification experiment

The qualification makes one explicit, guarded source edit in the HIA wrapper
emitter (`f13`, bound by the support contract): replace its stack-reservation
constant `64` with `80`. Both values keep
16-byte stack alignment, but generated machine code must change.

B3 compiles the modified source into M1. M1's outer wrapper was emitted by B3,
so it still reserves 64 bytes. Its HIA emitter now generates 80-byte wrappers.
M1 then compiles the same modified source into M2, whose outer wrapper must
actually contain `sub rsp, 80`. M2 compiles the modified source into M3; M2 and
M3 must be identical. M1 and M2 must differ, and the final modified fixed point
must differ from the original fixed point. This is a code-generation change
propagating across compiler generations, not just a source-comment change.

Both original and modified compilers also compile and execute
`examples/hia_bootstrap/bytesum.hiaasm`. That separate program exercises a loop,
branch arguments, a forward function call, byte loads and stores, casts,
wrapping `u32` multiplication and XOR. Its results are checked against an
independent host integer oracle, including empty input and repeated byte ranges.
The acceptance report additionally requires rejection of malformed tokens,
integer overflows, duplicate/out-of-scope SSA, missing/unreachable blocks, wrong
edge/call types, invalid recursive-call signatures, mutable aliases and read-only writes.
It separately checks read-only edge duplication versus legal read-only call
aliases, and rejects syntax that violates the shared assembly adjacency rules.

## General Core expansion batch: arbitrary acyclic call order

Version 2 removes the earlier requirement that every callee have a larger
function number. The compiler assembly itself is now emitted in source order
and contains real backward calls, so B1 through B3 must use the new native
graph checker to rebuild the full compiler. The authoring aid does not sort
the functions into a topological order to avoid that requirement.

The additional independent checks retain both original and modified compiler
outputs for a bytesum program containing a backward call, a complete 128-function
chain with backward edges, wrong backward-call signatures, missing and
out-of-range callees, direct recursion, mutual recursion and an unused cyclic
helper component. Failed compilation must leave source and output unchanged.
Scalar helper results are compared with the independent general Core interpreter
before B0, and complete borrowed-byte programs run against an independent host
integer oracle after self-compilation. Their source bytes, admission differences
and native outputs are retained in the same evidence directory.

Typed recursion is valid in the general Core but intentionally outside this
finite self-hosting profile. Its refusal records say so rather than labeling
it malformed Core. Owned allocations/transfers, returned loans and a general
resource/effect checker remain unimplemented in this compiler and are explicitly
marked in the support matrix.

## Object expansion batch: HIA-written ELF64 ET_REL

The opt-in module spelling `selfhost_elf` selects
`hepta.hia.selfhost.elf64-relocatable.v1`. It changes only the output container;
the accepted operations, resources, signatures and call-graph restrictions are
the same as the flat profile. In HIA functions `f38`, `f39` and `f41`, the
compiler emits the ELF64 little-endian x86-64 relocatable header, `.text`, a
three-entry symbol table with only `f0` exported, both string tables and a
nonexecuting `.note.GNU-stack`. Internal relative calls/branches remain resolved
by HIA. There are no undefined symbols, external relocations or host imports.

All object bytes come directly from native HIA compilation. Python transports
and independently inspects the resulting bytes without constructing or repairing
the ELF object. `readelf` checks headers, sections, symbols and relocations;
`objdump` disassembles the actual `f0` wrapper. GNU ld then links the emitted
object into a shared library under `-z defs -z noexecstack -z relro -z now`.
The linked compiler rebuilds its complete original/modified source, and linked
bytesum objects execute against the host integer oracle. The extracted `.text`
must be byte-identical to the corresponding flat image in both compiler versions.

The flat B0→B3 and M1→M3 chains still use no linker after B0. The additional
object qualification deliberately invokes GNU ld after those chains; its
separate command identities, logs, object/shared hashes and execution receipts
are retained. Insufficient object capacity and rejected source leave output
unchanged, including the ELF header. Object overhead consumes the same 1 MiB
output limit; no compiler or runtime resource limit is increased.

The object route does not implement external symbol relocations, arbitrary
public exports, a linker written in HIA, executable ELF images or other ELF
targets. The seed's existing Python ELF writer remains a distinct dependency.

## Trust and operational boundaries

B0 retains the existing Python Core verifier/direct backend/ELF writer and GNU
linker as seed dependencies. Its exact implementation and source hashes are in
the evidence. After B0, the loader, operating system and hardware remain trusted;
Python no longer performs parsing, verification or code generation. Successor
images need no assembler, linker or libc calls themselves.

Each native invocation runs in a fresh process with 10 CPU seconds, 20 seconds
of parent wall time, 256 MiB address space, 8 MiB stack and bounded file output.
These are resource guards, **not an OS security sandbox**. This helper is for
qualification of source-bound trusted compiler artifacts; it is not an exposed
connector that executes arbitrary uploaded native files. Integration with
worker/catalog identity and deployment gates remains the candidate's separate
responsibility.
