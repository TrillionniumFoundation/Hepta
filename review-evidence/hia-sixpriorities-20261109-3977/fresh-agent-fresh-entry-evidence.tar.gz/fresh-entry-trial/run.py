#!/usr/bin/env python3
"""Run one trial command and retain its exact stdout/stderr and metadata."""
import datetime
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
label, cwd, *argv = sys.argv[1:]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(argv, cwd=cwd, capture_output=True)
(root / (label + '.stdout')).write_bytes(result.stdout)
(root / (label + '.stderr')).write_bytes(result.stderr)
record = {'label': label, 'cwd': cwd, 'argv': argv, 'started': started,
          'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit_code': result.returncode,
          'stdout': label + '.stdout', 'stderr': label + '.stderr'}
with (root / 'commands.jsonl').open('a') as stream:
    stream.write(json.dumps(record) + '\n')
print(json.dumps(record))
sys.stdout.flush()
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
