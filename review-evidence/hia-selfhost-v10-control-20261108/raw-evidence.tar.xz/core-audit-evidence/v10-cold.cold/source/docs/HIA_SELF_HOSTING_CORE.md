# HIA fixed-Core native self-hosting

This is a real, deliberately bounded self-hosting compiler for a fixed subset of
`hia-asm.v1` / `hepta.hia.program.v8`. The complete compiler is
`examples/hia_bootstrap/selfhost.hiaasm`. Its scanner, parser, semantic verifier,
control-flow checker, x86-64 encoder and relocation writer are HIA functions.
It accepts that entire source file as ordinary input bytes and produces the next
compiler as executable machine bytes. The old `compile_constant` component and
its explicitly open qualification remain separate.

Run the source-bound qualification on Linux x86-64:

```sh
python tools/qualify_hia_selfhost.py --output /tmp/hia-selfhost.json
python tools/replay_hia_selfhost_cold.py --output /tmp/hia-selfhost-cold.json
python -m unittest tests.test_hia_selfhost tests.test_hia_selfhost_contract
```

The qualification creates an evidence directory next to the JSON report. It
retains source inputs, the B0 build receipt, each generated image, every native
invocation receipt, raw child stdout/stderr, and checksums. A passing exit
requires every check to pass.

## Fixed version and support identity

The machine-readable [support contract](HIA_SELFHOST_CORE_SUPPORT.json) names
`selfhost-core-linux-x86_64-v10`, the sole target, the seed and successor ABIs,
resource limits, supported and excluded features, and SHA-256 identities for
the compiler assembly, authoring aid, loader, qualification, test fixtures and
complete Python seed package. It is checked before B0. A stale source file,
changed loader, or broadened support declaration fails that check. To review
and regenerate the contract after an intentional source change, run:

```sh
python tools/generate_hia_selfhost_contract.py
python tools/generate_hia_selfhost_contract.py --check
```

The static contract is a support and identity declaration, not a successful
execution receipt. The runtime qualification additionally records the exact
B0 shared-library digest, actual loaded seed modules, CPython executable and
version, GNU linker identity, source closure, and original and modified native
generations. Git commit/tree metadata is supplementary; actual file hashes
remain authoritative, including when a worktree is dirty. No commit identifier
is embedded in its own source lock.

The cold runner copies only these pinned source files into a newly created
directory. It starts isolated CPython with site packages disabled, a fresh
home and temporary directory, no inherited Python path, and no seed, successor
or bytecode caches. It rebuilds B0 and executes the entire qualification there,
then verifies the exported and original bytes again. The original source tree
is not on the child's import path. This establishes source/process/cache cold
replay on the measured host; it is not a new VM or an independent toolchain.

## Fixed seed and actual generation chain

| Generation | Executed compiler | Input | Output construction |
|---|---|---|---|
| B0 | Existing Python HIA assembler, Core verifier, direct x86 backend; GNU ld | Complete checked-in HIA compiler source | Seed shared library with explicit borrowed-byte export `f0` |
| B1 | That seed's **native HIA compiler** | Complete compiler source | HIA emits a flat x86-64 image |
| B2 | The B1 image | Complete compiler source | HIA parses, verifies and emits the B2 image |
| B3 | The B2 image | Complete compiler source | HIA parses, verifies and emits the B3 image |

B1, B2 and B3 must be byte-identical. They are actual executable compiler
artifacts. Their input is the full source, including all compiler functions;
lexing the source or compiling a separate small example does not close the gate.

`tools/generate_hia_selfhost.py` is a reproducible **authoring aid** that lowers a
restricted development notation into checked-in HIA assembly. It is used to edit
the source before B0. It is neither shipped inside the compiler nor imported by
the successor loader. The qualification itself reads the checked-in assembly;
it does not run this authoring aid. There are no source-hash dispatch tables,
precompiled successor blobs, Python callbacks, runtime token streams, or host
parse/code-generation calls in successor compilation.

`tools/hia_selfhost_child.py` uses only the Python standard library. It hashes
and copies input bytes, loads the sealed B0 shared library or maps a successor
image read/write then changes it to read/execute, and calls the fixed ABI. It
asserts that no `hepta.*` or compiler authoring modules are loaded. The loader
never rewrites instruction bytes, builds an object, resolves relocations,
interprets Core or links a successor. The HIA compiler handles every relative
call and branch relocation in its output.

The report's claims are specific to this fixed subset. It does not claim that
all HIA opcodes, modules or target architectures are self-hosted, nor that the
compiler has a formal refinement proof. Finite test evidence and a bootstrap
fixed point do not constitute such a proof.

## The chosen Core subset

The flat-image input is ordinary HIA assembly with the fixed header
`hia-asm.v1 hepta.hia.program.v8 selfhost`. Explicit `selfhost_elf` selects the
bounded ELF object profile described below. Names are numeric: contiguous `f0`,
`f1`, ... functions; contiguous `b0`, `b1`, ... blocks within each function;
and `vN` SSA values. Function signature variables are `v0`, `v1`, ... and the
entry block must exactly reproduce their names and types. SSA numbers elsewhere
need not be contiguous, but each definition must be unique in its function.
Only ASCII spaces and LF separate tokens. Decimal unsigned literals forbid
leading zeroes and are checked for `u64` overflow. The grammar recognizes the
explicit JSON attribute forms that these operations require.
The existing assembly grammar's adjacency rules are retained: a declaration or
edge name, opcode, `ret`, `effects`, or `entry` directly precedes its opening
parenthesis; `entry(bN)` and `->` remain contiguous. Required separators before
effect/entry clauses, between branch targets and before instruction attributes
cannot be removed. Optional spaces inside parameter/argument lists remain valid.

| Area | Accepted constructs |
|---|---|
| Values | `u64`, `usize` (64 bits), `u32`, `u8`, `bool`, borrowed `readbuf` and `mutbuf` parameters |
| Constants | Typed integer literals and `true` / `false` boolean literals |
| Integer operations | `int.add.wrap`, `int.sub.wrap`, `int.mul.wrap`, `int.add.checked`, `int.sub.checked`, `bit.not`, `bit.and`, `bit.or`, `bit.xor`, checked left/right shifts |
| Conditions | Unsigned `compare.eq`, `ne`, `lt`, `le`, `gt`, `ge`; `bool.and`, `bool.or`, `bool.not` |
| Selection | `select(bool, T, T) -> T` for `u8`, `u32`, `u64`, `usize`, and `bool`; true chooses the second operand, false the third; resources are excluded |
| Casts | `int.cast` with `{"mode":"wrap"}` between integer types |
| Bytes | `buffer.len`, `buffer.load`, `buffer.store`, `buffer.swap` |
| Calls | Scalar-return direct `call`, exact signatures, acyclic non-self call graph; direct self calls in the checked tail form below |
| Control flow | `ret`, `jump`, `branch` with explicit, typed block arguments; explicit `trap` with a catalog code |
| Effects | Every function explicitly declares `effects(read,write,trap)` |

All integer operations use `u8`, `u32`, `u64` or `usize`; booleans remain
separate. `bit.not` complements exactly the declared width. Checked addition
traps when the mathematical sum exceeds that width's unsigned maximum, and
checked subtraction traps when the left operand is smaller than the right.
An arithmetic trap uses `UD2`, as do bounds and shift traps. A trap occurs
before later effects; stores completed before it remain observable. Arbitrary
program execution has no rollback guarantee.

The compiler returns the generated image size on success, `0xffffffff` for
invalid/unsupported input, and `0xfffffffe` for insufficient output or workspace
capacity. B0 uses the existing packed ABI-status plus Core-result wrapper. Flat
successors return a zero-extended Core `u32`; their wrapper relies on the
qualification caller to provide live, disjoint allocations and does not add a
public arbitrary-pointer validation interface. The Core compiler itself checks
its source/output extents and required workspace before parsing.

Each function returns exactly one scalar; returned loans and owners are excluded.
There are no allocations, deallocations, foreign calls, callbacks, arbitrary
pointers, non-tail or mutual recursion, exceptions, indirect branches or host library imports in
the subset. The fixed exported function `f0` accepts exactly three buffers
`(readbuf, mutbuf, mutbuf)` and returns `u32`. Private helper functions can have
scalar and borrowed-buffer parameters.

The native verifier checks grammar, literal widths, unique SSA definitions,
block-local scope, operation arity/types, buffer permissions, call signatures,
edge signatures, existing targets and graph reachability. Inbound edges to
`b0` are forbidden. The native HIA checker records the complete directed call
graph, rejects missing targets, and marks functions whose non-self callees are
already acyclic. After at most one pass per function, every function must be
marked. Backward calls are admitted when they do not create a cycle. A direct
self call is excluded from that graph only after the parser enforces the exact
tail shape. Non-tail self calls and all mutual cycles are rejected, including
cycles in unused helper functions. Repeated mutable buffer arguments in one call or edge
are rejected. Every edge also rejects repeated `readbuf` SSA arguments, matching
Core's linear capability transfer rule, even on a statically untaken branch.
Calls may pass the same read-only loan more than once. Buffers can only originate in parameters and flow through checked
edges/calls; the subset cannot create aliases by producing new buffer values.
The host supplies disjoint live allocations at the external entrypoint.

The bounds are part of the compiler profile:

| Resource | Maximum |
|---|---:|
| Source bytes / output capacity | 1,048,576 each |
| Source lines / bytes per line excluding LF | 16,384 / 16,384 |
| Workspace required | 1,048,576 bytes |
| Functions | 128 |
| Blocks per function / all functions | 256 / 1,536 |
| Function or block parameters / call or edge arguments | 16 |
| SSA variable index per function | 2,047 |
| Instructions across the module | 8,192 |
| Core JSON structural nodes | 262,144 |
| Relative relocations | 12,000 |

These bounds also bound stack frames and the accepted Core structure. The
checked non-self graph bounds live native frames by the 128-function limit;
each admitted tail self call adds zero frames.
The call graph and its marks occupy bytes 858,368 through 875,775 of the
existing 1 MiB workspace, after the complete relative-relocation table; they
do not overlap live parser, SSA or relocation state. Every compilation clears
this state, including when the caller supplies nonzero scratch contents.
Each native parse pass counts the exact corresponding Core JSON nodes, including
containers, declarations, parameters, instruction results, attributes and both
branch arms. Header word 248 records the count; the count starts at four for
the root object, schema, module and function-list nodes. More than 262,144 nodes
is rejected before any output write. The maximum instruction count does not
bypass the general Core's structural budget.

The unchanged grammar also bounds canonical Core JSON bytes. Conservative
budgets of 1,024 bytes for the root and each function's own fields, 2,048 bytes
per block excluding its operations, and 512 bytes per operation give at most
7,472,128 bytes, below the general Core's 8 MiB limit. These bounds use the
fixed identifier lengths, 16-argument/parameter limit, single scalar output,
single optional attribute and unsigned 64-bit literal limit.
The native HIA source preflight enforces the independent assembly frontend's
16,384-line and 16,384-byte-per-line limits before parsing or writing output.
The final empty line after a trailing LF counts as a line, and trailing spaces
count as bytes. The HIA implementation reads the actual source bytes; it does
not call the Python text frontend. Previous profiles deliberately omitted these
presentation limits, so overlong whitespace-padded lines had different admission
results across the two frontends. v10 closes that admission difference.

### v5 capacity qualification

The previous v4 profile allowed 3,072 instructions; v5 raised this to 8,192
without increasing source, output or workspace bytes, stack/CPU/address-space
limits, or child deadlines. The v5 compiler contained 3,044 instructions.
v6 retained these limits and all exact capacity fixtures while adding the tail
self-call checker and lowering. v8 retains the same limits while adding three
unsigned integer operations and scalar selection. The current instruction count is recorded by
the authoring aid and each B0/generation receipt. Owned resources, returned
loans, non-tail/mutual recursion, arbitrary identifiers and general external
linking remain outside this profile.

The relocation table remains 12,000 records in the same workspace layout.
An instruction contributes at most one call relocation, a block at most two
edge relocations, and the wrapper one call: `1 + 8192 + 2*1536 = 11265`.
Relocations are counted during preflight as well as emission. Every displacement
lies within the checked 1 MiB output, well inside signed x86-64 `rel32` range;
the ELF writer still emits its existing ELF64 fields and resolved `.text`.

Qualification executes 3,072-, 3,073- and 8,192-instruction programs using both
the original and modified compilers. An independent Core VM checks the same
operations and calls, with only the unused borrowed entry parameters removed
to expose a scalar entry. The 8,192-operation result is 8,176. Its ELF `.text`
must equal the flat image; one-byte-short output is transactionally refused.
8,193 operations are valid general Core but refused by this fixed native profile.

Separate 910,057-byte fixtures have exactly 262,144 and 262,145 structural nodes.
The general Core accepts the first and rejects the second. Native parsing must
make the same structural decision: the first reaches output-capacity preflight,
while the second returns invalid-source with error 58 before output changes.
All source bytes, raw invocation logs, output hashes, counters and independent
reference outcomes are retained, including the refusal cases. These checks run
inside the source-only cold replay and do not weaken its acceptance conditions.

The historical v5 upgrade replay consumes the retained v4 B3 image and source from
the exact `894d2dfce54ff25271b8de2c18c902394484d5cc` source release. Their expected
SHA-256 digests are pinned in the replay tool, and its original receipt must
agree. It first demonstrates the old 3,073-operation refusal, then has that
same native v4 compiler compile the 3,044-operation v5 source. U1 compiles U2,
U2 compiles U3, all three must match, and U3 must compile and execute the
8,192-operation case. This upgrade uses no Python parser/code generator or
external assembler/linker. It does reuse, rather than freshly rebuild, the
historical v4 B3; the independent v5 cold replay still starts from B0.

Run that historical replay from the pinned v5 source release. Its script refuses
to apply the v4-to-v5 label to a v6 or later checkout: v4/v5 did not admit self calls, and
this round does not claim a native-only historical upgrade into the new source.

```sh
python tools/replay_hia_selfhost_upgrade.py \
  --previous-evidence <retained-v4-qualification.evidence> \
  --output <new-upgrade-report.json>
```

### v6 direct tail self calls

A direct call to the current function is admitted only when it is the last
instruction of its block and the immediately following terminator is
`ret(vN)` for exactly that call's result. A following arithmetic instruction,
edge, branch, or return of a different value is refused with error 59. The call
still passes the ordinary arity, exact type, scalar return, SSA and mutable
alias checks. Both parse passes before output writing check the tail shape;
invalid tail syntax therefore leaves the output allocation unchanged.

Lowering first copies every actual argument into the existing call scratch
slots. It then copies all staged words into `b0` parameter slots and emits one
relative jump to `b0`, after the function prologue and its stack probes. This
parallel copy preserves exchanged scalar arguments and both words of borrowed
buffers. It does not overwrite the original result pointer at `rbp-8`, push a
return address, allocate another frame, or execute a second prologue. A later
ordinary return stores through that original pointer and returns to the
original caller. Self-call relocations use the existing block relocation kind;
the v5 relocation upper bound is unchanged. Header word 256 stores the pending
result plus one and is reset at every block; word 248 remains the exact Core
node counter.

This is a bound on stack growth, not a termination proof. Just as accepted
ordinary loops can run forever, a tail self call need not decrease an argument.
The unchanged child limits enforce 10 CPU seconds, a 20-second parent deadline,
256 MiB address space and an 8 MiB stack. General recursion and mutual tail
cycles remain excluded.

The compiler itself uses a recursive `emit_bytes` helper: `emit4` and `emit8`
call it with 4 and 8 remaining bytes. Thus every B0/B1/B2 compiler actually
executes the new form while compiling its complete successor; B1=B2=B3 and the
modified M2=M3 chain must still hold. B0 retains its ordinary native call
implementation and executes only the bounded 4/8-byte recursion. Successors
perform the checked same-frame lowering.

Qualification retains independent recursive Core VM observations for scalar
argument exchange at depths 0, 1, 62, 63 and 127 and for recursive byte copies.
The buffer VM wrapper allocates, initializes and inspects owners; its recursive
helper is unchanged from the native fixture. Native output and scalar results
must agree in both the original and modified compilers. A separate 1,000,001
iteration fixture uses SSA index 2047, a 33,328-byte frame and a closed integer
recurrence oracle (each step exchanges arguments and adds the remaining count)
under the same 8 MiB stack cap. Its recursive VM call-budget refusal is
explicitly retained and is not reported as a VM deep-recursion success.
Tail-related type/arity/alias refusals, valid-general-Core non-tail refusals,
one-byte-short output and matching flat/ELF `.text` are part of the cold replay.

## Parse, validate and generate

Compilation runs three passes over private source bytes:

1. Parse all functions/blocks, check local types and SSA scope, and collect
   signatures, block-edge metadata and the direct-call graph. Check target
   validity, block reachability and absence of call cycles.
2. Parse again, validate all calls and edge signatures against the complete
   metadata, and count the exact encoded output size without writing output.
3. After the full validation and capacity checks succeed, parse again and emit
   actual machine bytes, then apply HIA-written relative relocations.

For rejected source or insufficient output capacity, output bytes remain
unchanged. Workspace is scratch state and may change on failure. Determinism of
these passes depends on the caller supplying private, nonconcurrently modified
source and disjoint output/workspace; the qualification loader makes those
copies. Workspace need not initially contain zeroes; B3 deliberately runs with
nonzero scratch contents.

Integer widths are normalized after wrapping operations and casts. Generated
buffer accesses check the index against the carried loan length. Checked shifts
check their type's bit width. Failed runtime bounds/shift checks execute `ud2`;
this is a trap, with no promise of transactional rollback for an arbitrary
compiled program. The compiler's transactional output property applies to its
validation/capacity rejection path.

Generated functions use only caller-saved registers and `rbp`. SSA values live
in frame slots; edge arguments use temporary slots so parallel transfers remain
correct even on loops. Calls pass an argument array and a result slot. The
emitter touches each stack page while reserving a frame. The flat image's first
instruction is its SysV entry wrapper; all calls and branches are relative and
there are no external symbol relocations.

## Borrowed-resource batch: byte swap

Version 4 adds `buffer.swap(mutbuf, usize, usize)`, with no result binding.
It preserves the existing borrowed-buffer lifetime model and original size
limits. Both indices are compared with the carried buffer length before either
pointer is formed or either byte is read or written. Equal valid indices are a
no-op; equal invalid indices still trap. The instruction exchanges exactly two
bytes without allocating storage or creating a new loan. Read-only buffers,
incorrect index types, result bindings and incorrect arities are rejected.

The qualification records a separate resource batch for the original and the
modified fixed-point compiler. Its independent general Core reference runs
before B0 and uses owned allocation, borrowing, initialization, swapping,
loads, loan ending and owner cleanup to expose the resulting bytes. The native
program uses the supported borrowed parameters. Nine cases cover both swap
directions, interior bytes, equal indices, either invalid operand, the maximum
`usize` value and an empty extent. Five malformed programs are independently
rejected by both checkers. A native ELF swap object must contain the same text
bytes as the flat image from the same compiler.

For each runtime trap, the loader's optional qualification-only shared output
mapping retains the actual bytes after the child terminates with `SIGILL`.
Each failing swap must leave its input bytes unchanged. A positive control
performs a store before a failing swap: the retained output must contain that
store, confirming that the observer sees actual writes and that an arbitrary
program has no rollback guarantee. The loader does not catch signals or change
native control flow. The report preserves preimage/output hashes, independent
results, child exit status, raw logs and wall time, including failed executions.

This batch does not add allocation, owner movement, new loans, returned loans
or recursion to Selfhost-Core. Those constructs remain outside the fixed
profile; the general Core reference's broader ownership support is not evidence
that the native self-hosting checker implements it. These finite cases are
regression evidence rather than a general checker or refinement proof.

### v8 unsigned integer and scalar selection extension

The v8 HIA scanner, type/arity checker and machine emitter added
`bit.not`, `int.add.checked`, `int.sub.checked` and scalar `select`. This brings
the then-declared input operation set to 28 of the 50 general Core operations. It did not
expand the ABI, owned resources, external linking, resource limits or the
separate Safe Core machine-validation profile.

The emitter checks the machine carry/borrow flag immediately after 64-bit
addition/subtraction. Narrow addition also compares its full sum with its
normalized `u8` or `u32` result, so overflow cannot be hidden by truncation.
The verifier requires one matching integer operand for `bit.not` and two
matching integer operands for checked addition/subtraction, with one matching
result and no attributes.

The integer emitter is HIA helper `f44`; scalar selection is helper `f45`.
Both are appended after the original `f0` through `f43`, preserving their
identities and keeping every compiler function
within the unchanged SSA-index and per-function block limits. Qualification
checks those limits on the compiler's own complete input source as well as on
boundary fixtures.

The v8 language inventory included 700 independent scalar value
oracles. Every new operation also runs with operands decoded from runtime
input bytes in each of the four widths. The general Core VM executes those
input-dependent bodies through an owned-buffer reference wrapper before B0.
B3 and mutated M3 compile and execute all native fixtures. Separate refusal
cases cover arity, result/operand types, boolean and buffer misuse, unexpected
attributes and out-of-range literals. Forty arithmetic-trap cases per compiler
cover unsigned overflow and underflow, including 64-bit carry and narrow
overflow without a 64-bit carry. Shared output retains a prior store and
excludes a later store after a trap; no-prior-store controls retain the whole
preimage. The arithmetic VM reference verifies each trapping operand pair;
the shared native output supplies the memory-order observations.

Selection requires a boolean condition and two matching scalar values of
`u8`, `u32`, `u64`, `usize` or `bool`, with the same result type. True selects
the second operand; false selects the third. The machine emitter uses full-word
moves and a conditional move on the condition. Forty scalar selection witnesses
cover both conditions for each type and the complete boolean truth table.
Twenty-eight additional observations vary input bytes while keeping each type's
program unchanged; every integer result is observed as all eight output bytes.
Thirteen selection refusal cases cover arity, condition, value/result type,
resource misuse, omitted results and an undefined third operand.

The cold qualification also executes a separate 64-case selection batch from
`tools.hia_selfhost_select`: independent Core references run before B0, and
both B3 and mutated M3 compile five native fixtures that read the condition
and both values from input bytes. Each returns the selected low 32 bits and
writes all eight result bytes, including for boolean results. Both conditions,
the complete boolean truth table, zero, maximum values and the high-bit
boundaries of all four unsigned types are observed. Each compiler also
rejects 13 invalid programs, preserves output on insufficient compilation
capacity, and produces matching flat and ELF text. These supplementary
observations are reported separately from the 700 scalar witnesses and the
28 input-dependent selection observations in the language inventory.

```sh
python -B tests/test_hia_selfhost_language_coverage.py --generate-inventory
python -B tools/generate_hia_selfhost_contract.py
python -B tests/test_hia_selfhost_language_coverage.py --output <new-report.json>
```

Regeneration produces declarations and input identities. Only the subsequent
qualification report records execution, including failed runs and all raw
child logs. The finite cases and fixed points are not an all-input compiler
correctness proof.

## Modification experiment

The qualification makes one explicit, guarded source edit in the HIA wrapper
emitter (`f13`, bound by the support contract): replace its stack-reservation
constant `64` with `80`. Both values keep
16-byte stack alignment, but generated machine code must change.

B3 compiles the modified source into M1. M1's outer wrapper was emitted by B3,
so it still reserves 64 bytes. Its HIA emitter now generates 80-byte wrappers.
M1 then compiles the same modified source into M2, whose outer wrapper must
actually contain `sub rsp, 80`. M2 compiles the modified source into M3; M2 and
M3 must be identical. M1 and M2 must differ, and the final modified fixed point
must differ from the original fixed point. This is a code-generation change
propagating across compiler generations, not just a source-comment change.

Both original and modified compilers also compile and execute
`examples/hia_bootstrap/bytesum.hiaasm`. That separate program exercises a loop,
branch arguments, a forward function call, byte loads and stores, casts,
wrapping `u32` multiplication and XOR. Its results are checked against an
independent host integer oracle, including empty input and repeated byte ranges.
The acceptance report additionally requires rejection of malformed tokens,
integer overflows, duplicate/out-of-scope SSA, missing/unreachable blocks, wrong
edge/call types, invalid recursive-call signatures, mutable aliases and read-only writes.
It separately checks read-only edge duplication versus legal read-only call
aliases, and rejects syntax that violates the shared assembly adjacency rules.

## General Core expansion batch: arbitrary acyclic call order

Version 2 removes the earlier requirement that every callee have a larger
function number. The compiler assembly itself is now emitted in source order
and contains real backward calls, so B1 through B3 must use the new native
graph checker to rebuild the full compiler. The authoring aid does not sort
the functions into a topological order to avoid that requirement.

The additional independent checks retain both original and modified compiler
outputs for a bytesum program containing a backward call, a complete 128-function
chain with backward edges, wrong backward-call signatures, missing and
out-of-range callees, direct recursion, mutual recursion and an unused cyclic
helper component. Failed compilation must leave source and output unchanged.
Scalar helper results are compared with the independent general Core interpreter
before B0, and complete borrowed-byte programs run against an independent host
integer oracle after self-compilation. Their source bytes, admission differences
and native outputs are retained in the same evidence directory.

Non-tail and mutual recursion are valid in the general Core but remain outside
this finite self-hosting profile. Direct self-tail calls are admitted by the v6
rules above, including bounded same-frame argument staging and cycle checks;
those cases must not be reported as unsupported by the current compiler. Owned
allocations/transfers, returned loans and a general resource/effect checker
remain unimplemented and are explicitly marked in the support matrix.

## Object expansion batch: HIA-written ELF64 ET_REL

The opt-in module spelling `selfhost_elf` selects
`hepta.hia.selfhost.elf64-relocatable.v1`. It changes only the output container;
the accepted operations, resources, signatures and call-graph restrictions are
the same as the flat profile. In HIA functions `f38`, `f39` and `f41`, the
compiler emits the ELF64 little-endian x86-64 relocatable header, `.text`, a
three-entry symbol table with only `f0` exported, both string tables and a
nonexecuting `.note.GNU-stack`. Internal relative calls/branches remain resolved
by HIA. There are no undefined symbols, external relocations or host imports.

All object bytes come directly from native HIA compilation. Python transports
and independently inspects the resulting bytes without constructing or repairing
the ELF object. `readelf` checks headers, sections, symbols and relocations;
`objdump` disassembles the actual `f0` wrapper. GNU ld then links the emitted
object into a shared library under `-z defs -z noexecstack -z relro -z now`.
The linked compiler rebuilds its complete original/modified source, and linked
bytesum objects execute against the host integer oracle. The extracted `.text`
must be byte-identical to the corresponding flat image in both compiler versions.

The flat B0→B3 and M1→M3 chains still use no linker after B0. The additional
object qualification deliberately invokes GNU ld after those chains; its
separate command identities, logs, object/shared hashes and execution receipts
are retained. Insufficient object capacity and rejected source leave output
unchanged, including the ELF header. Object overhead consumes the same 1 MiB
output limit; no compiler or runtime resource limit is increased.

The object route does not implement external symbol relocations, arbitrary
public exports, a linker written in HIA, executable ELF images or other ELF
targets. The seed's existing Python ELF writer remains a distinct dependency.

## Trust and operational boundaries

B0 retains the existing Python Core verifier/direct backend/ELF writer and GNU
linker as seed dependencies. Its exact implementation and source hashes are in
the evidence. After B0, the loader, operating system and hardware remain trusted;
Python no longer performs parsing, verification or code generation. Successor
images need no assembler, linker or libc calls themselves.

Each native invocation runs in a fresh process with 10 CPU seconds, 20 seconds
of parent wall time, 256 MiB address space, 8 MiB stack and bounded file output.
These are resource guards, **not an OS security sandbox**. This helper is for
qualification of source-bound trusted compiler artifacts; it is not an exposed
connector that executes arbitrary uploaded native files. Integration with
worker/catalog identity and deployment gates remains the candidate's separate
responsibility.

## v9 unsigned checked arithmetic

The native compiler now accepts unsigned `int.mul.checked`, `int.div.checked`,
`int.rem.checked` and `int.neg.checked` for u8/u32/u64/usize. Unsigned MUL checks
its high half and then the declared narrow width. Division and remainder check
zero before DIV and clear the high dividend word. Unsigned negation returns zero
only for zero input. Invalid arithmetic executes UD2 before subsequent writes;
earlier writes remain observable. The current inventory has 824 scalar witnesses, 120 arithmetic trap cases per
compiler and 171 refusal cases per compiler. Input-dependent reference
observations are split into batches of at most 16 scalar results, preserving the
shared 128-result byte-observation limit. The input operation inventory is 32/50.
Signed types, owned resources and the remaining general Core obligations remain
outside this profile. Native finite witnesses and fixed points remain separate
from an all-input compiler correctness proof.

## v10 explicit trap terminator and shared source-line budgets

The native parser and emitter accept all four Core terminator kinds: `ret`,
`jump`, `branch`, and `trap`. The explicit trap spelling accepts exactly `user`,
`overflow`, `division_by_zero`, `bounds`, or `allocation`. A trap accounts for
three Core structural nodes and emits UD2 at the original program position.
The flat ABI does not return a structured trap code; code identity is validated
at admission and recorded by the independent Core VM. Native qualification
observes process termination and retained output bytes, without claiming a
machine-level distinction among the five trap reasons.

`tools/hia_selfhost_control.py` constructs 30 independent Core VM cases covering
all five reasons, direct and called traps, stores before the trap, and both
branches of one input-dependent helper. For each B3 and M3 compiler, 20 cases
must execute UD2 and 10 must return 7, execute the caller's later store, and
produce the exact expected bytes. The shared-output observer must retain stores
before a trap and show no later caller store. Ten malformed/out-of-profile
forms are checked separately, including a self call followed by a trap: the
existing immediate-self-tail-return rule is preserved.

Four exact 16,384-byte line cases place padding on the header, an instruction,
the end marker, and the trailing line at EOF. They must compile and run. Each
16,385-byte counterpart and a 16,385-line source must be refused before any
output write, with nonzero caller-provided workspace. The complete source-byte,
instruction, structural-node, output, workspace, and child resource limits
remain unchanged. These witnesses run as part of the full qualification and
its source-only cold replay.

Terminator coverage increases from three to four kinds. The ordinary operation
inventory remains 32 of 50; owned resources, general Core inputs, broader ABI
and compiler correctness obligations remain open.
