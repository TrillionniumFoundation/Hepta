#!/usr/bin/env python3
"""Observe the six source and four native helper caller controls once."""
import argparse
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import traceback

CONTROLLER_SHA = 'b86ed6752303a76dd4cd21a7e7a4abb3a90507dc1f183011f44d4669a6761edb'
HELPER_SHA = 'a7b35008ad1f6e07a9137cd128af42d38b1bb4eb229e0578e178366beac3f793'
CLASSES = ('tests.test_hia_worker_native_helpers.WorkerHelperSourceTests',
           'tests.test_hia_worker_native_helpers.NativeWorkerCallerViewTests')
METHODS = (
    ('test_allowlist_has_real_single_image_contracts_and_packaged_sources',
     'test_any_ambient_selector_and_incomplete_pair_refuse_and_restore',
     'test_fork_cannot_reuse_parent_scope_or_release_its_owner',
     'test_patch_factory_view_identity_refuses_before_any_mapping',
     'test_unselected_scope_refuses_new_image_and_restores_complete_environment',
     'test_unselected_scope_rejects_nested_and_foreign_thread_requests'),
    ('test_original_buffer_callers_execute_native_boundaries_and_refusals',
     'test_original_service_refusal_is_durable_without_candidate_or_host_fallback',
     'test_two_exact_patch_views_execute_cli_and_original_service_payloads',
     'test_unknown_factories_and_wrong_adjacent_admission_never_use_general_loader'),
)
EXPECTED_IDS = tuple(name + '.' + method for name, methods in zip(CLASSES, METHODS) for method in methods)


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def record(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}


def imported(path, name, expected):
    if record(path)['sha256'] != expected:
        raise ValueError('external evidence helper differs from its frozen version')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def clean_environment(original, cold, clang):
    forbidden = sorted(key for key, value in original.items() if value and
        (key.startswith(('HEPTA_', 'HIA_')) and 'DEVELOPMENT' in key
         or key.startswith('HEPTA_HIA_') and key.endswith('_MANIFEST')))
    if forbidden:
        raise ValueError('development or ambient native manifests are forbidden: ' + repr(forbidden))
    environment = {key: value for key, value in original.items()
                   if not key.startswith('HEPTA_HIA_') and not key.endswith('_COLD_REPORT')}
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1',
                       HEPTA_HIA_WORKER_HELPERS_COLD_REPORT=str(cold),
                       CLANG=str(clang), HEPTA_CLANG=str(clang), HEPTA_TEST_CLANG=str(clang))
    return environment


CHILD = r'''
from hashlib import sha256
import importlib.util,json,os,sys,unittest
from pathlib import Path
sys.path.insert(0, ROOT)
assert sha256(Path(HELPER).read_bytes()).hexdigest() == HELPER_SHA
spec=importlib.util.spec_from_file_location('original_state_owner_evidence',HELPER)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
loader=unittest.TestLoader()
suite=loader.loadTestsFromNames(CLASSES)
loaded=[item.id() for item in helper.flatten(suite)]
assert not loader.errors and loaded == EXPECTED_IDS and len(loaded) == len(set(loaded)) == 10
module=__import__('tests.test_hia_worker_native_helpers',fromlist=['NativeWorkerCallerViewTests'])
assert Path(module.__file__).resolve() == Path(ROOT,'tests/test_hia_worker_native_helpers.py').resolve()
assert os.environ.get('HEPTA_HIA_WORKER_HELPERS_COLD_REPORT') == COLD
assert not any(value and key.startswith(('HEPTA_','HIA_')) and 'DEVELOPMENT' in key
               for key,value in os.environ.items())
Path(OUT,'loaded-tests.json').write_text(json.dumps(loaded,indent=2)+'\n')
with Path(OUT,'test-events.jsonl').open('x') as events:
    events.write(json.dumps({'event':'observer_child_started','pid':os.getpid(),
        'cold_report':COLD,'source':ROOT})+'\n');events.flush()
    result=unittest.TextTestRunner(verbosity=2,failfast=False,
        resultclass=lambda *a,**k:helper.EvidenceResult(*a,events=events,**k)).run(suite)
value=helper.result_observation(result,loaded)
value['status']='HELPER_CALLER_CONTROLS_PASS' if value['passed'] else 'HELPER_CALLER_CONTROLS_HOLD'
value['actual_child_pid']=os.getpid()
value['selected_cold_report']=COLD
value['development_selection']=False
assets=getattr(module.NativeWorkerCallerViewTests,'assets',None)
value['retained_actual_assets']={}
value['asset_observation_error']=None
try:
    if type(assets) is not dict or set(assets)!={'snapshot','patch','admission'}:
        raise ValueError('actual test class did not retain its three source-bound native assets')
    directory=Path(OUT,'actual-native-assets');directory.mkdir()
    for name,(manifest,image) in sorted(assets.items()):
        if type(image) is not bytes or sha256(image).hexdigest()!=manifest['image_sha256']:
            raise ValueError('actual image differs from its actual parsed manifest')
        if manifest['compiler_sha256']!=COMPILER_SHA:
            raise ValueError('actual image compiler differs from the selected cold final generation')
        target=directory/(name+'.image.bin')
        target.write_bytes(image)
        parsed=directory/(name+'.parsed-manifest.json')
        parsed.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        value['retained_actual_assets'][name]={
            'image':{'path':str(target),'bytes':len(image),'sha256':sha256(image).hexdigest()},
            'parsed_manifest_copy':{'path':str(parsed),'sha256':sha256(parsed.read_bytes()).hexdigest(),
                'is_original_manifest_bytes':False,
                'description':'Serialization of the actual parsed record retained by the test class; not the original manifest byte stream'},
            'schema':manifest['schema'],'source_sha256':manifest['source_sha256'],
            'compiler_sha256':manifest['compiler_sha256']}
except (OSError,ValueError,TypeError,KeyError) as error:
    value['asset_observation_error']=type(error).__name__+': '+str(error)
    value['status']='HELPER_CALLER_CONTROLS_HOLD'
Path(OUT,'run.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
raise SystemExit(0 if value['status']=='HELPER_CALLER_CONTROLS_PASS' else 1)
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'cold', 'output', 'clang', 'retained-controller', 'evidence-helper'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    root = args.source.resolve(strict=True)
    out = args.output.resolve()
    if out.is_relative_to(root) or root.is_relative_to(out):
        parser.error('evidence output must be separate from frozen source')
    out.mkdir(mode=0o700, parents=True, exist_ok=False)
    started = time.monotonic()
    report = {'schema':'hepta.matching-cold-helper-caller-controls.v1',
        'status':'HELPER_CALLER_CONTROLS_HOLD','expected_head':args.head,'expected_ids':list(EXPECTED_IDS),
        'expected_counts':dict(zip(CLASSES,(6,4))),'workflow_seconds':1800,
        'development_selection':False,'whole_native_delivery_qualified':False,
        'observer':record(Path(__file__).resolve()),'python':sys.version,'python_executable':sys.executable}
    before = pins = records = sources = identity = support = admit_cold_build = None
    external_before = None
    try:
        if sys.version_info[:2] != (3,12) or not sys.flags.isolated or not sys.dont_write_bytecode:
            raise ValueError('invoke the observer with the selected Python 3.12 using -I -B')
        if not re.fullmatch('[0-9a-f]{40}',args.head):
            raise ValueError('the complete frozen head is required')
        clang = args.clang.resolve(strict=True)
        cold = args.cold.resolve(strict=True)
        environment = clean_environment(os.environ,cold,clang)
        version = subprocess.run([str(clang),'--version'],capture_output=True,text=True,check=True,timeout=15)
        if not re.search(r'\bclang version 20\.1\.8(?:\s|$)',version.stdout):
            raise ValueError('the actual selected Clang is not 20.1.8')
        report['clang'] = {**record(clang),'version':version.stdout,'stderr':version.stderr}
        report['selected_environment']={name:environment.get(name) for name in
            ('CLANG','HEPTA_CLANG','HEPTA_TEST_CLANG','HEPTA_HIA_WORKER_HELPERS_COLD_REPORT')}
        report['platform'] = platform.platform()
        controller = args.retained_controller.resolve(strict=True)
        helper = args.evidence_helper.resolve(strict=True)
        support = imported(controller,'frozen_retained_cold_custody',CONTROLLER_SHA)
        if record(helper)['sha256'] != HELPER_SHA:
            raise ValueError('the original EvidenceResult helper changed')
        os.chdir(root)
        sys.path[:0]=[str(root),str(root/'review-evidence/hia-native-rewrite-20261111')]
        from tools import hia_core_source_identity as source_identity
        identity = source_identity
        from tools.build_hia_json_preflight import admit_cold_build as admit, current_sources
        admit_cold_build = admit
        from workflow_process import run_workflow_step
        import workflow_process
        if identity.ROOT.resolve()!=root or Path(workflow_process.__file__).resolve()!=root/'review-evidence/hia-native-rewrite-20261111/workflow_process.py':
            raise ValueError('source identity or process owner belongs to a different checkout')
        before=identity._source_state()
        save(out/'source-before.json',before)
        if before['head']!=args.head or before['status']:
            raise ValueError('source is not the exact clean frozen commit')
        sources=current_sources()
        pins,records=support.capture_cold_evidence(cold,sources,admit_cold_build)
        save(out/'cold-before.json',records)
        paths=[Path(__file__).resolve(),controller,helper,Path(workflow_process.__file__).resolve()]
        external_before={str(path):record(path) for path in paths}
        prefix={'ROOT':str(root),'OUT':str(out),'HELPER':str(helper),'HELPER_SHA':HELPER_SHA,
                'CLASSES':list(CLASSES),'EXPECTED_IDS':list(EXPECTED_IDS),'COLD':str(cold),
                'COMPILER_SHA':records['compiler']['sha256']}
        child=out/'controls-child.py'
        child.write_text(''.join(name+'='+repr(value)+'\n' for name,value in prefix.items())+CHILD)
        external_before[str(child)]=record(child)
        save(out/'harness-before.json',external_before)
        save(out/'RUNNING.json',{'head':before['head'],'tree':before['tree'],'selected_environment':report['selected_environment'],
            'cold':records,'expected_ids':list(EXPECTED_IDS),'child':record(child),'workflow_seconds':1800})
        report['owner']=run_workflow_step([sys.executable,'-I','-B',str(child)],cwd=root,env=environment,
            stdout_path=out/'stdout.log',stderr_path=out/'stderr.log',receipt_path=out/'owner.json',seconds=1800)
        run_path=out/'run.json'
        run=json.loads(run_path.read_bytes()) if run_path.is_file() else {}
        report.update(tests_run=run.get('tests_run'),run_result=record(run_path) if run_path.is_file() else None,
            exact_execution=run.get('exact_execution'),test_anomalies=run.get('anomalies'),
            actual_asset_count=len(run.get('retained_actual_assets',{})))
        report['test_run_passed']=(report['owner'].get('status')=='WORKFLOW_STEP_COMPLETED'
            and report['owner'].get('returncode')==0 and run.get('status')=='HELPER_CALLER_CONTROLS_PASS'
            and run.get('tests_run')==10 and run.get('loaded_ids')==list(EXPECTED_IDS)
            and run.get('exact_execution') is True and run.get('passed') is True)
    except BaseException as error:
        report['error']=type(error).__name__+': '+str(error)
        report['traceback']=traceback.format_exc()
    finally:
        if before is not None:
            try:
                after=identity._source_state();save(out/'source-after.json',after)
                report.update(head=before['head'],tree=before['tree'],source_preserved=before==after)
            except BaseException as error:
                report['source_recheck_error']=type(error).__name__+': '+str(error)
        if pins is not None:
            try:
                after=support.recheck_cold_evidence(pins,records,sources,admit_cold_build)
                save(out/'cold-after.json',after)
                report.update(cold_preserved=after==records,cold_sha256=records['wrapper']['sha256'])
            except BaseException as error:
                report['cold_recheck_error']=type(error).__name__+': '+str(error)
        if external_before is not None:
            try:
                after={name:record(Path(name)) for name in external_before}
                save(out/'harness-after.json',after)
                report['harness_preserved']=after==external_before
            except BaseException as error:
                report['harness_recheck_error']=type(error).__name__+': '+str(error)
        report['seconds']=time.monotonic()-started
        if (report.get('test_run_passed') is True and report.get('source_preserved') is True
                and report.get('cold_preserved') is True and report.get('harness_preserved') is True
                and not any(key.endswith('error') for key in report)):
            report['status']='HELPER_CALLER_CONTROLS_PASS'
        save(out/'summary.json',report)
    print(json.dumps({key:report.get(key) for key in ('status','head','tests_run','exact_execution',
        'source_preserved','cold_preserved','harness_preserved','seconds','error')},sort_keys=True),flush=True)
    return 0 if report['status']=='HELPER_CALLER_CONTROLS_PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
