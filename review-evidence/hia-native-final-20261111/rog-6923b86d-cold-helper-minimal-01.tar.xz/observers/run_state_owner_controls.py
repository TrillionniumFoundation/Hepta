#!/usr/bin/env python3
"""Run the 82 retained state-owner controls against one frozen source and cold.

This external test supervisor does not install dependencies, change budgets,
select development images, or make a whole-product native-completion claim.
Every invocation requires a new output directory; failures are never replaced.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import traceback
import unittest


CLASSES = (
    ('tests.test_hia_execution_budget_native.ExecutionBudgetNativeTests', 22),
    ('tests.test_hia_retirement_state_native.RetirementStateNativeTests', 22),
    ('tests.test_hia_candidate_budget_native.CandidateBudgetNativeTests', 16),
    ('tests.test_hia_worker_native_helpers.NativeWorkerHelperTests', 12),
    ('tests.test_hia_worker_native_helpers.NativeWorkerRequestBundleTests', 3),
    ('tests.test_hia_worker_native_helpers.NativeWorkerJournalBundleTests', 2),
    ('tests.test_hia_worker_native_helpers.NativeWorkerBudgetBundleTests', 5),
)
PINS = {'setuptools': '78.1.1', 'wheel': '0.46.3',
        'z3-solver': '4.15.4.0', 'jsonschema': '4.26.0'}
COLD_COMPONENTS = ('EXECUTION_BUDGET', 'RETIREMENT_STATE', 'CANDIDATE_BUDGET',
                   'WORKER_HELPERS', 'WORKER_REQUEST', 'AGENT_JOURNAL')


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_name(path.name + '.pending')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def git(root, *arguments):
    child = subprocess.run(['git', '-C', str(root), *arguments], capture_output=True,
                           text=True, check=True, timeout=30)
    return child.stdout.strip()


def source_identity(root, head, tree):
    actual = {'root': git(root, 'rev-parse', '--show-toplevel'),
              'head': git(root, 'rev-parse', 'HEAD'),
              'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
              'status_porcelain': git(root, 'status', '--porcelain=v1', '--untracked-files=all')}
    if Path(actual['root']).resolve() != root or actual['head'] != head or actual['tree'] != tree:
        raise ValueError('source checkout does not match the explicit root, head and tree')
    if actual['status_porcelain']:
        raise ValueError('source checkout is not clean: ' + actual['status_porcelain'])
    return actual


def executable_version(path):
    path = path.resolve(strict=True)
    if not path.is_file() or not os.access(path, os.X_OK):
        raise ValueError('explicit tool is not an executable file: ' + str(path))
    child = subprocess.run([str(path), '--version'], capture_output=True, text=True,
                           check=True, timeout=15)
    return {'path': str(path), 'version': child.stdout.strip(), 'stderr': child.stderr.strip()}


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def load_declared_tests(root):
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromNames([name for name, _count in CLASSES])
    tests = list(flatten(suite))
    identifiers = [test.id() for test in tests]
    counts = Counter(identifier.rsplit('.', 1)[0] for identifier in identifiers)
    if loader.errors or counts != Counter(dict(CLASSES)):
        raise ValueError('loaded test classes/counts differ: ' + repr((dict(counts), loader.errors)))
    if len(identifiers) != 82 or len(set(identifiers)) != 82:
        raise ValueError('loaded test identities are empty, duplicated, missing or unexpected')
    for name, _count in CLASSES:
        module = importlib.import_module(name.rsplit('.', 1)[0])
        actual = Path(module.__file__).resolve()
        expected = root.joinpath(*name.rsplit('.', 1)[0].split('.')).with_suffix('.py')
        if actual != expected:
            raise ValueError('test import escaped frozen checkout: ' + str(actual))
    return suite, identifiers


class EvidenceResult(unittest.TextTestResult):
    """Record outer identities even when class setup fails or a process stops."""

    def __init__(self, *arguments, events, **keywords):
        super().__init__(*arguments, **keywords)
        self.events = events
        self.started_ids = []
        self.finished_ids = []
        self.successful_ids = []
        self.run_starts = 0
        self.run_stops = 0

    def record(self, event, test=None, **fields):
        value = {'event': event, 'utc': utc_now(), 'monotonic_ns': time.monotonic_ns(), **fields}
        if test is not None:
            value['test_id'] = test.id()
        self.events.write(json.dumps(value, sort_keys=True) + '\n')
        self.events.flush()
        os.fsync(self.events.fileno())

    def startTestRun(self):
        self.run_starts += 1
        self.record('run_started')
        super().startTestRun()

    def stopTestRun(self):
        self.run_stops += 1
        self.record('run_finished')
        super().stopTestRun()

    def startTest(self, test):
        self.started_ids.append(test.id())
        self.record('started', test)
        super().startTest(test)

    def stopTest(self, test):
        self.finished_ids.append(test.id())
        self.record('finished', test)
        super().stopTest(test)

    def addSuccess(self, test):
        self.successful_ids.append(test.id())
        self.record('success', test)
        super().addSuccess(test)

    def addError(self, test, error):
        self.record('error', test, traceback=''.join(traceback.format_exception(*error)))
        super().addError(test, error)

    def addFailure(self, test, error):
        self.record('failure', test, traceback=''.join(traceback.format_exception(*error)))
        super().addFailure(test, error)

    def addSkip(self, test, reason):
        self.record('skip', test, reason=reason)
        super().addSkip(test, reason)

    def addExpectedFailure(self, test, error):
        self.record('expected_failure', test, traceback=''.join(traceback.format_exception(*error)))
        super().addExpectedFailure(test, error)

    def addUnexpectedSuccess(self, test):
        self.record('unexpected_success', test)
        super().addUnexpectedSuccess(test)

    def addSubTest(self, test, subtest, error):
        if error is not None:
            self.record('subtest_anomaly', test, subtest=subtest.id(),
                        traceback=''.join(traceback.format_exception(*error)))
        super().addSubTest(test, subtest, error)


def result_observation(result, expected_ids):
    anomalies = {
        'errors': [{'id': item.id(), 'traceback': text} for item, text in result.errors],
        'failures': [{'id': item.id(), 'traceback': text} for item, text in result.failures],
        'skipped': [{'id': item.id(), 'reason': text} for item, text in result.skipped],
        'expected_failures': [{'id': item.id(), 'traceback': text} for item, text in result.expectedFailures],
        'unexpected_successes': [item.id() for item in result.unexpectedSuccesses],
    }
    exact = (bool(expected_ids) and result.testsRun == len(expected_ids)
             and result.started_ids == expected_ids and result.finished_ids == expected_ids
             and result.successful_ids == expected_ids
             and result.run_starts == result.run_stops == 1)
    return {'expected_count': len(expected_ids), 'tests_run': result.testsRun,
            'loaded_ids': expected_ids, 'started_ids': result.started_ids,
            'finished_ids': result.finished_ids, 'successful_ids': result.successful_ids,
            'run_starts': result.run_starts, 'run_stops': result.run_stops,
            'exact_execution': exact, 'anomalies': anomalies,
            'passed': exact and result.wasSuccessful() and not any(anomalies.values())}


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', required=True, type=Path)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--cold-report', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--clang', required=True, type=Path)
    parser.add_argument('--rustc', required=True, type=Path)
    parser.add_argument('--expected-python-version', required=True)
    args = parser.parse_args()
    for name in ('expected_head', 'expected_tree'):
        if re.fullmatch('[0-9a-f]{40}', getattr(args, name)) is None:
            parser.error('--' + name.replace('_', '-') + ' must be the exact 40-character identity')
    return args


def main():
    args = arguments()
    root = args.source_root.resolve(strict=True)
    output = args.output.resolve()
    if output == root or root in output.parents:
        raise ValueError('evidence output must be outside the frozen source checkout')
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    report_path = output / 'run.json'
    record = {'schema': 'hepta.state-owner-controls.v1', 'status': 'PREPARING',
              'started_utc': utc_now(), 'source_root': str(root),
              'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
              'declared_classes': dict(CLASSES), 'expected_outer_controls': 82,
              'tests_started': False, 'cold_admission_passed': False,
              'whole_stack_rewritten_in_hia': False,
              'runner_sha256': sha256(Path(__file__).read_bytes()).hexdigest()}
    write_json(report_path, record)
    started = time.monotonic()
    result = None
    expected_ids = []
    try:
        record['phase'] = 'source_identity'
        record['source_before'] = source_identity(root, args.expected_head, args.expected_tree)
        record['phase'] = 'dependencies'
        record['python'] = {'executable': sys.executable, 'version': platform.python_version()}
        if platform.python_version() != args.expected_python_version:
            raise ValueError('Python version differs from the explicit selected environment')
        if not sys.flags.isolated:
            raise ValueError('invoke the supervisor with Python -I to exclude ambient Python paths')
        if platform.system() != 'Linux' or platform.machine() not in ('x86_64', 'amd64'):
            raise ValueError('the retained controls require actual Linux x86_64')
        record['dependencies'] = {name: importlib.metadata.version(name) for name in PINS}
        if record['dependencies'] != PINS:
            raise ValueError('installed dependency versions differ from the explicit CI pins')
        importlib.import_module('pip')
        record['clang'] = executable_version(args.clang)
        record['rustc'] = executable_version(args.rustc)
        if re.search(r'clang version 20\.', record['clang']['version']) is None:
            raise ValueError('the declared Clang executable is not Clang 20')
        if not record['rustc']['version'].startswith('rustc 1.95.0 '):
            raise ValueError('the declared Rust executable is not Rust 1.95.0')
        os.chdir(root)
        sys.path.insert(0, str(root))
        sys.dont_write_bytecode = True
        os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
        record['discarded_selection_names'] = []
        for name in tuple(os.environ):
            if name.startswith('HEPTA_HIA_') and (name.endswith('_MANIFEST') or 'DEVELOPMENT' in name):
                record['discarded_selection_names'].append(name)
                del os.environ[name]
        for name in ('CLANG', 'HEPTA_CLANG', 'HEPTA_TEST_CLANG'):
            os.environ[name] = record['clang']['path']
        os.environ['RUSTC'] = record['rustc']['path']
        os.environ['PATH'] = os.pathsep.join(dict.fromkeys((
            str(Path(sys.executable).parent), str(Path(record['clang']['path']).parent),
            str(Path(record['rustc']['path']).parent), *os.environ.get('PATH', '').split(os.pathsep))))
        os.environ['HEPTA_HIA_TEST_PACKAGING_PYTHON'] = sys.executable
        cold_path = args.cold_report.resolve(strict=True)
        for component in COLD_COMPONENTS:
            os.environ['HEPTA_HIA_' + component + '_COLD_REPORT'] = str(cold_path)
        for component, name in (('EXECUTION_BUDGET', 'execution-budget'),
                                ('RETIREMENT_STATE', 'retirement-state'),
                                ('CANDIDATE_BUDGET', 'candidate-budget')):
            os.environ['HEPTA_HIA_' + component + '_EVIDENCE'] = str(output / name)
        record['phase'] = 'cold_admission'
        from tools.build_hia_json_preflight import admit_cold_build, current_sources
        from tools.hia_selfhost_contract import PROFILE
        cold_bytes = cold_path.read_bytes()
        cold = json.loads(cold_bytes)
        nested_path = Path(cold['nested_report']).resolve(strict=True)
        nested_bytes = nested_path.read_bytes()
        compiler_path = Path(json.loads(nested_bytes)['generations'][-1]['produced_image']).resolve(strict=True)
        compiler_bytes = compiler_path.read_bytes()
        sources = admit_cold_build(compiler_bytes, cold_bytes)
        if current_sources() != sources:
            raise ValueError('current source map differs after cold admission')
        record['cold_admission_passed'] = True
        record['cold'] = {'path': str(cold_path), 'sha256': sha256(cold_bytes).hexdigest(),
                          'nested_path': str(nested_path), 'nested_sha256': sha256(nested_bytes).hexdigest(),
                          'compiler_path': str(compiler_path),
                          'compiler_sha256': sha256(compiler_bytes).hexdigest(), 'profile': PROFILE,
                          'source_manifest_entries': len(sources)}
        write_json(output / 'source-manifest.json', sources)
        record['phase'] = 'load_declared_controls'
        suite, expected_ids = load_declared_tests(root)
        record['loaded_ids'] = expected_ids
        record['status'] = 'RUNNING'
        record['phase'] = 'native_controls'
        record['tests_started'] = True
        write_json(report_path, record)
        with (output / 'tests.log').open('x', encoding='utf-8') as log, \
                (output / 'test-events.jsonl').open('x', encoding='utf-8') as events:
            def factory(*arguments, **keywords):
                return EvidenceResult(*arguments, events=events, **keywords)
            result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=factory).run(suite)
        record['execution'] = result_observation(result, expected_ids)
        record['phase'] = 'final_source_and_cold_readback'
        record['source_after'] = source_identity(root, args.expected_head, args.expected_tree)
        if (cold_path.read_bytes() != cold_bytes or nested_path.read_bytes() != nested_bytes
                or compiler_path.read_bytes() != compiler_bytes or current_sources() != sources
                or admit_cold_build(compiler_bytes, cold_bytes) != sources):
            raise ValueError('source, compiler or cold evidence changed during the controls')
        record['source_and_cold_preserved'] = True
        record['status'] = 'PASS' if record['execution']['passed'] else 'FAIL_OR_INCOMPLETE'
        record['phase'] = 'complete'
    except BaseException as error:
        record['status'] = 'FAIL_OR_INCOMPLETE'
        record['exception'] = {'type': type(error).__name__, 'message': str(error),
                               'traceback': traceback.format_exc()}
        if result is not None:
            record['execution'] = result_observation(result, expected_ids)
    finally:
        record['finished_utc'] = utc_now()
        record['elapsed_seconds'] = time.monotonic() - started
        write_json(report_path, record)
    print(json.dumps({'status': record['status'], 'phase': record['phase'],
                      'report': str(report_path), 'elapsed_seconds': record['elapsed_seconds']}, sort_keys=True))
    return 0 if record['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
