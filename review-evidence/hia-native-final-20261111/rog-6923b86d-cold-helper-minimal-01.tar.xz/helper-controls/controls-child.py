ROOT='/tmp/hia-a4f12-delivery-20261111/final-6923b86d9a00/source'
OUT='/tmp/hia-a4f12-delivery-20261111/helper-callers-6923b86d'
HELPER='/tmp/hia-a4f12-delivery-20261111/controllers/final-20261111/run_state_owner_controls.py'
HELPER_SHA='a7b35008ad1f6e07a9137cd128af42d38b1bb4eb229e0578e178366beac3f793'
CLASSES=['tests.test_hia_worker_native_helpers.WorkerHelperSourceTests', 'tests.test_hia_worker_native_helpers.NativeWorkerCallerViewTests']
EXPECTED_IDS=['tests.test_hia_worker_native_helpers.WorkerHelperSourceTests.test_allowlist_has_real_single_image_contracts_and_packaged_sources', 'tests.test_hia_worker_native_helpers.WorkerHelperSourceTests.test_any_ambient_selector_and_incomplete_pair_refuse_and_restore', 'tests.test_hia_worker_native_helpers.WorkerHelperSourceTests.test_fork_cannot_reuse_parent_scope_or_release_its_owner', 'tests.test_hia_worker_native_helpers.WorkerHelperSourceTests.test_patch_factory_view_identity_refuses_before_any_mapping', 'tests.test_hia_worker_native_helpers.WorkerHelperSourceTests.test_unselected_scope_refuses_new_image_and_restores_complete_environment', 'tests.test_hia_worker_native_helpers.WorkerHelperSourceTests.test_unselected_scope_rejects_nested_and_foreign_thread_requests', 'tests.test_hia_worker_native_helpers.NativeWorkerCallerViewTests.test_original_buffer_callers_execute_native_boundaries_and_refusals', 'tests.test_hia_worker_native_helpers.NativeWorkerCallerViewTests.test_original_service_refusal_is_durable_without_candidate_or_host_fallback', 'tests.test_hia_worker_native_helpers.NativeWorkerCallerViewTests.test_two_exact_patch_views_execute_cli_and_original_service_payloads', 'tests.test_hia_worker_native_helpers.NativeWorkerCallerViewTests.test_unknown_factories_and_wrong_adjacent_admission_never_use_general_loader']
COLD='/tmp/hia-a4f12-delivery-20261111/final-6923b86d9a00/evidence/cold.json'
COMPILER_SHA='0e09ccca227d8f8ed7e7fa37111d2c44e1329517b19763bd9f280d00135591c8'

from hashlib import sha256
import importlib.util,json,os,sys,unittest
from pathlib import Path
sys.path.insert(0, ROOT)
assert sha256(Path(HELPER).read_bytes()).hexdigest() == HELPER_SHA
spec=importlib.util.spec_from_file_location('original_state_owner_evidence',HELPER)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
loader=unittest.TestLoader()
suite=loader.loadTestsFromNames(CLASSES)
loaded=[item.id() for item in helper.flatten(suite)]
assert not loader.errors and loaded == EXPECTED_IDS and len(loaded) == len(set(loaded)) == 10
module=__import__('tests.test_hia_worker_native_helpers',fromlist=['NativeWorkerCallerViewTests'])
assert Path(module.__file__).resolve() == Path(ROOT,'tests/test_hia_worker_native_helpers.py').resolve()
assert os.environ.get('HEPTA_HIA_WORKER_HELPERS_COLD_REPORT') == COLD
assert not any(value and key.startswith(('HEPTA_','HIA_')) and 'DEVELOPMENT' in key
               for key,value in os.environ.items())
Path(OUT,'loaded-tests.json').write_text(json.dumps(loaded,indent=2)+'\n')
with Path(OUT,'test-events.jsonl').open('x') as events:
    events.write(json.dumps({'event':'observer_child_started','pid':os.getpid(),
        'cold_report':COLD,'source':ROOT})+'\n');events.flush()
    result=unittest.TextTestRunner(verbosity=2,failfast=False,
        resultclass=lambda *a,**k:helper.EvidenceResult(*a,events=events,**k)).run(suite)
value=helper.result_observation(result,loaded)
value['status']='HELPER_CALLER_CONTROLS_PASS' if value['passed'] else 'HELPER_CALLER_CONTROLS_HOLD'
value['actual_child_pid']=os.getpid()
value['selected_cold_report']=COLD
value['development_selection']=False
assets=getattr(module.NativeWorkerCallerViewTests,'assets',None)
value['retained_actual_assets']={}
value['asset_observation_error']=None
try:
    if type(assets) is not dict or set(assets)!={'snapshot','patch','admission'}:
        raise ValueError('actual test class did not retain its three source-bound native assets')
    directory=Path(OUT,'actual-native-assets');directory.mkdir()
    for name,(manifest,image) in sorted(assets.items()):
        if type(image) is not bytes or sha256(image).hexdigest()!=manifest['image_sha256']:
            raise ValueError('actual image differs from its actual parsed manifest')
        if manifest['compiler_sha256']!=COMPILER_SHA:
            raise ValueError('actual image compiler differs from the selected cold final generation')
        target=directory/(name+'.image.bin')
        target.write_bytes(image)
        parsed=directory/(name+'.parsed-manifest.json')
        parsed.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        value['retained_actual_assets'][name]={
            'image':{'path':str(target),'bytes':len(image),'sha256':sha256(image).hexdigest()},
            'parsed_manifest_copy':{'path':str(parsed),'sha256':sha256(parsed.read_bytes()).hexdigest(),
                'is_original_manifest_bytes':False,
                'description':'Serialization of the actual parsed record retained by the test class; not the original manifest byte stream'},
            'schema':manifest['schema'],'source_sha256':manifest['source_sha256'],
            'compiler_sha256':manifest['compiler_sha256']}
except (OSError,ValueError,TypeError,KeyError) as error:
    value['asset_observation_error']=type(error).__name__+': '+str(error)
    value['status']='HELPER_CALLER_CONTROLS_HOLD'
Path(OUT,'run.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
raise SystemExit(0 if value['status']=='HELPER_CALLER_CONTROLS_PASS' else 1)
