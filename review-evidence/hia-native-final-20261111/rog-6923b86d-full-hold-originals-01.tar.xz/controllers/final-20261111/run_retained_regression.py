"""Observe one complete retained regression against an exact frozen source.

This external observer neither invokes the previous v4 component groups nor
claims their FULL_RETAINED_PASS. Its budget/environment come from frozen v4.
"""
import argparse
import ast
from hashlib import sha256
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import traceback


def file_record(path):
    path = Path(path)
    return {'path': str(path), 'sha256': sha256(path.read_bytes()).hexdigest()}


def capture_cold_evidence(cold_path, expected_sources, admit_cold_build):
    """Bind the wrapper, its exact nested report and its exact final compiler."""
    cold_raw = cold_path.read_bytes()
    cold = json.loads(cold_raw)
    nested_path = Path(cold['nested_report']).absolute()
    nested_raw = nested_path.read_bytes()
    if cold.get('nested_report_sha256') != sha256(nested_raw).hexdigest():
        raise ValueError('cold nested report bytes differ from the wrapper digest')
    nested = json.loads(nested_raw)
    generations = nested.get('generations')
    if (nested.get('status') != 'SELF_HOSTED_FIXED_CORE_PASS'
            or nested.get('source_manifest') != expected_sources
            or not isinstance(nested.get('checks'), dict) or not nested['checks']
            or not all(value is True for value in nested['checks'].values())
            or type(generations) is not list or len(generations) != 3):
        raise ValueError('nested cold qualification is incomplete or belongs to another source')
    compiler_path = Path(generations[-1]['produced_image']).absolute()
    compiler_raw = compiler_path.read_bytes()
    if generations[-1].get('produced_sha256') != sha256(compiler_raw).hexdigest():
        raise ValueError('last cold generation bytes differ from the nested report digest')
    admitted = admit_cold_build(compiler_raw, cold_raw)
    if admitted != expected_sources:
        raise ValueError('cold builder admission differs from the exact frozen source map')
    pins = {'wrapper': (cold_path, cold_raw), 'nested_report': (nested_path, nested_raw),
            'compiler': (compiler_path, compiler_raw)}
    if any(path.read_bytes() != raw for path, raw in pins.values()):
        raise ValueError('cold evidence changed during capture and admission')
    records = {name: {'path': str(path), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}
               for name, (path, raw) in pins.items()}
    records['admitted_source_manifest'] = admitted
    return pins, records


def recheck_cold_evidence(before_pins, before_records, expected_sources, admit_cold_build):
    # Read the original three paths first. A changed wrapper must not redirect
    # the final observation to a different report or a replacement compiler.
    if any(path.read_bytes() != raw for path, raw in before_pins.values()):
        raise ValueError('original cold wrapper, nested report or compiler changed during tests')
    after_pins, after_records = capture_cold_evidence(before_pins['wrapper'][0],
                                                   expected_sources, admit_cold_build)
    if (after_records != before_records
            or any(after_pins[name] != before_pins[name] for name in before_pins)):
        raise ValueError('cold evidence custody or admitted source map changed during tests')
    return after_records


def frozen_configuration(raw, out, cold, base_environment=None):
    tree = ast.parse(raw)
    values = {}
    cold_names = None
    evidence = {}
    seconds = None
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ('development_selectors', 'production_selectors'):
                    values[target.id] = ast.literal_eval(node.value)
        if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == 'name':
            if "'_COLD_REPORT'" in ast.unparse(node):
                cold_names = ast.literal_eval(node.iter)
        if isinstance(node, ast.FunctionDef) and node.name == 'run':
            for item in node.body:
                if not isinstance(item, ast.Assign) or len(item.targets) != 1:
                    continue
                target = item.targets[0]
                if (isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name)
                        and target.value.id == 'step_environment'):
                    name = ast.literal_eval(target.slice)
                    expression = ast.Expression(item.value)
                    evidence[name] = eval(compile(expression, '<frozen-v4-environment>', 'eval'),
                                          {'__builtins__': {}, 'str': str},
                                          {'out': out, 'name': 'full-retained-regression'})
        if isinstance(node, ast.FunctionDef) and node.name == 'suite':
            for item in ast.walk(node):
                if isinstance(item, ast.Call) and isinstance(item.func, ast.Name) and item.func.id == 'run':
                    for keyword in item.keywords:
                        if keyword.arg == 'timeout':
                            value = keyword.value
                            if (not isinstance(value, ast.IfExp) or not isinstance(value.test, ast.Name)
                                    or value.test.id != 'discover'):
                                raise ValueError('unexpected frozen discovery timeout expression')
                            seconds = ast.literal_eval(value.body)
    if (set(values) != {'development_selectors', 'production_selectors'} or not cold_names
            or not evidence or seconds != 5400):
        raise ValueError('frozen v4 environment/discovery budget is missing or changed')
    environment = dict(os.environ if base_environment is None else base_environment)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    environment['PYTHONUNBUFFERED'] = '1'
    discarded = {}
    for kind, names in values.items():
        discarded[kind] = [name for name in names if name in environment]
        for name in names:
            environment.pop(name, None)
    for name in cold_names:
        environment['HEPTA_HIA_' + name + '_COLD_REPORT'] = str(cold)
    environment.update(evidence)
    recorded = {key: value for key, value in environment.items()
                if key in {'PATH', 'LD_LIBRARY_PATH', 'CLANG', 'HEPTA_CLANG', 'HEPTA_TEST_CLANG',
                           'RUSTC', 'HEPTA_RUSTC', 'CARGO', 'CARGO_HOME', 'CARGO_TARGET_DIR',
                           'PYTHONDONTWRITEBYTECODE', 'PYTHONUNBUFFERED'}
                or key.startswith('HEPTA_HIA_') and key.endswith(('_COLD_REPORT', '_EVIDENCE', '_OBSERVATIONS'))}
    return environment, {'discarded': discarded, 'environment': recorded,
                         'cold_report_names': list(cold_names), 'workflow_seconds': seconds}, seconds


def tool_environment(args, root, out):
    """Bind explicit installed executables; no cloud or ROG paths are embedded."""
    binaries = {}
    for name in ('python', 'clang', 'rustc', 'cargo'):
        path = Path(getattr(args, name)).absolute()
        if not path.is_file() or not os.access(path, os.X_OK):
            raise ValueError('selected ' + name + ' is not an executable file: ' + str(path))
        binaries[name] = path
    # Keep the caller's venv path when invoking Python: resolving its executable
    # symlink would bypass that venv and its exact installed package versions.
    if Path(os.path.abspath(sys.executable)) != binaries['python']:
        raise ValueError('launch this controller with the selected --python interpreter')
    if sys.version_info[:2] != (3, 12):
        raise ValueError('the retained observation requires Python 3.12; observed ' + platform.python_version())
    environment = dict(os.environ)
    environment.update(CLANG=str(binaries['clang']), HEPTA_CLANG=str(binaries['clang']),
                       HEPTA_TEST_CLANG=str(binaries['clang']), RUSTC=str(binaries['rustc']),
                       HEPTA_RUSTC=str(binaries['rustc']), CARGO=str(binaries['cargo']))
    path_entries = []
    for path in [binaries[name].parent for name in ('python', 'rustc', 'cargo', 'clang')] + args.path_entry:
        path = Path(path).absolute()
        if not path.is_dir():
            raise ValueError('tool PATH entry is not a directory: ' + str(path))
        if str(path) not in path_entries:
            path_entries.append(str(path))
    environment['PATH'] = os.pathsep.join(path_entries + [environment.get('PATH', os.defpath)])
    library_entries = []
    for path in args.library_path:
        path = path.absolute()
        if not path.is_dir():
            raise ValueError('library path is not a directory: ' + str(path))
        library_entries.append(str(path))
    if library_entries:
        inherited = environment.get('LD_LIBRARY_PATH')
        environment['LD_LIBRARY_PATH'] = os.pathsep.join(library_entries + ([inherited] if inherited else []))
    cargo_home = args.cargo_home
    if cargo_home is None:
        cargo_home = Path(environment['CARGO_HOME']) if environment.get('CARGO_HOME') else out / 'cargo-home'
    cargo_target = args.cargo_target_dir or out / 'cargo-target'
    for name, path in [('CARGO_HOME', cargo_home), ('CARGO_TARGET_DIR', cargo_target)]:
        path = path.resolve(strict=False)
        if path == root or path.is_relative_to(root):
            raise ValueError(name + ' must be outside the frozen source')
        environment[name] = str(path)
    return environment, binaries


def tool_versions(environment, binaries):
    versions = {'python': sys.version, 'python_version': platform.python_version(),
                'python_minor_required': '3.12', 'executable': sys.executable,
                'selected_python': str(binaries['python']), 'prefix': sys.prefix,
                'base_prefix': sys.base_prefix, 'platform': platform.platform(),
                'cloud_reference_python_patch': '3.12.14',
                'python_patch_differs_from_cloud_reference': platform.python_version() != '3.12.14'}
    versions['python_patch_note'] = ('This run uses Python ' + platform.python_version()
        + '; prior cloud observations used Python 3.12.14. The accepted minor is 3.12; '
          'cross-environment results remain separately recorded.')
    versions['installed_dependencies'] = {}
    for name in ('setuptools', 'wheel', 'jsonschema', 'z3-solver'):
        try:
            versions['installed_dependencies'][name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions['installed_dependencies'][name] = None
    for name in ('clang', 'rustc', 'cargo'):
        process = subprocess.run([str(binaries[name]), '--version'], env=environment,
                                 capture_output=True, text=True, check=True, timeout=20)
        versions[name] = {'path': str(binaries[name]), 'stdout': process.stdout,
                          'stderr': process.stderr}
    expected = {'clang': r'\bclang version 20\.1\.8(?:\s|$)',
                'rustc': r'^rustc 1\.95\.0(?:\s|$)',
                'cargo': r'^cargo 1\.95\.0(?:\s|$)'}
    for name, pattern in expected.items():
        if not re.search(pattern, versions[name]['stdout']):
            raise ValueError('actual ' + name + ' version differs from the agreed launch environment')
    rust_environment_names = ('RUSTC', 'HEPTA_RUSTC', 'HIA_TEST_SOURCE_RUSTC', 'RUSTDOC',
        'CARGO', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_TARGET', 'CARGO_BUILD_RUSTC',
        'CARGO_BUILD_RUSTC_WRAPPER', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER',
        'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
        'RUSTDOCFLAGS', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_NET_OFFLINE',
        'CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER', 'CC', 'CXX', 'LD', 'AR',
        'PATH', 'LD_LIBRARY_PATH')
    # Explicit allowlist: registry tokens and other credential-bearing variables
    # are never copied into the public environment receipt.
    versions['rust_cargo_environment'] = {name: environment.get(name) for name in rust_environment_names}
    rust_commands = {'rustc_verbose': [str(binaries['rustc']), '--version', '--verbose'],
                     'rustc_sysroot': [str(binaries['rustc']), '--print', 'sysroot'],
                     'rustc_target_libdir': [str(binaries['rustc']), '--print', 'target-libdir'],
                     'cargo_verbose': [str(binaries['cargo']), '--version', '--verbose']}
    versions['rust_cargo_actual_probes'] = {}
    for name, command in rust_commands.items():
        process = subprocess.run(command, env=environment, capture_output=True,
                                 text=True, check=True, timeout=20)
        versions['rust_cargo_actual_probes'][name] = {'command': command,
            'returncode': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr}
    cargo_home = Path(environment['CARGO_HOME'])
    versions['cargo_home_exists'] = cargo_home.is_dir()
    versions['cargo_home_config_files'] = [file_record(cargo_home / name)
        for name in ('config', 'config.toml') if (cargo_home / name).is_file()]
    versions['rust_cargo_executable_files'] = {name: {**file_record(binaries[name]),
        'resolved_path': str(binaries[name].resolve(strict=True))} for name in ('rustc', 'cargo')}
    return versions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', '--source', dest='repo', required=True, type=Path)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--python', required=True, type=Path, help='the Python 3.12 venv executable running this controller')
    parser.add_argument('--clang', required=True, type=Path, help='actual Clang 20.1.8 executable')
    parser.add_argument('--rustc', '--rust', dest='rustc', required=True, type=Path, help='actual rustc 1.95.0 executable')
    parser.add_argument('--cargo', required=True, type=Path, help='actual cargo 1.95.0 executable')
    parser.add_argument('--cargo-home', type=Path, help='prepared private Cargo dependency cache outside the source')
    parser.add_argument('--cargo-target-dir', type=Path, help='build outputs outside the source; defaults below --output')
    parser.add_argument('--path-entry', action='append', type=Path, default=[], help='additional installed tool binary directory')
    parser.add_argument('--library-path', action='append', type=Path, default=[], help='additional installed shared-library directory')
    parser.add_argument('--cold-report', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = args.repo.resolve(strict=True)
    cold_path = args.cold_report.resolve(strict=True)
    out = args.output.resolve(strict=False)
    if not re.fullmatch('[0-9a-f]{40}', args.expected_head):
        parser.error('expected-head must be the complete frozen commit SHA')
    if out == root or out.is_relative_to(root) or root.is_relative_to(out):
        parser.error('output must be separate from the frozen source')
    base_environment, binaries = tool_environment(args, root, out)
    out.mkdir(parents=True, exist_ok=False)
    os.chdir(root)
    sys.path.insert(0, str(root))
    harness = root / 'review-evidence/hia-native-rewrite-20261111'
    sys.path.insert(0, str(harness))
    from tools import hia_core_source_identity as identity
    from tools.hia_selfhost_contract import validate_contract, CONTRACT_PATH
    from tools.build_hia_json_preflight import admit_cold_build
    import workflow_process
    if identity.ROOT.resolve() != root or Path(workflow_process.__file__).resolve() != harness / 'workflow_process.py':
        raise ValueError('source identity or workflow supervisor belongs to another checkout')
    before = identity._source_state()
    if before['head'] != args.expected_head or before['status']:
        raise ValueError('source is not the exact clean frozen commit')
    (out / 'source-before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    runner = harness / 'run_hia_qualification_v4.py'
    runner_raw = runner.read_bytes()
    for path in (runner, Path(workflow_process.__file__).resolve()):
        if before['files'].get(path.relative_to(root).as_posix()) != file_record(path)['sha256']:
            raise ValueError('frozen v4 runner/supervisor differs from source snapshot')
    contract = validate_contract()
    cold_sources = {**contract['source_identity']['files'],
                    CONTRACT_PATH: sha256((root / CONTRACT_PATH).read_bytes()).hexdigest()}
    if any(before['files'].get(name) != value for name, value in cold_sources.items()):
        raise ValueError('cold closure differs from complete pinned source')
    cold_pins, cold_evidence_before = capture_cold_evidence(cold_path, cold_sources, admit_cold_build)
    cold_before = cold_evidence_before['wrapper']
    snapshots = out / 'cold-originals'
    snapshots.mkdir()
    cold_snapshots = {}
    for name, (_path, raw) in cold_pins.items():
        snapshot = snapshots / (name + ('.bin' if name == 'compiler' else '.json'))
        with snapshot.open('xb') as stream:
            stream.write(raw)
        if snapshot.read_bytes() != raw:
            raise ValueError('cold evidence snapshot writeback differs')
        snapshot.chmod(0o400)
        cold_snapshots[name] = file_record(snapshot)
    (out / 'cold-evidence-before.json').write_text(json.dumps(cold_evidence_before, indent=2, sort_keys=True) + '\n')
    environment, environment_record, seconds = frozen_configuration(runner_raw, out, cold_path, base_environment)
    environment_record['versions'] = tool_versions(environment, binaries)
    (out / 'environment.json').write_text(json.dumps(environment_record, indent=2, sort_keys=True) + '\n')
    child_path = Path(__file__).resolve().with_name('retained_child.py')
    harness_paths = {'external_controller': Path(__file__).resolve(), 'external_child': child_path,
                     'frozen_v4_runner': runner, 'frozen_workflow_process': Path(workflow_process.__file__).resolve()}
    harness_before = {name: file_record(path) for name, path in harness_paths.items()}
    (out / 'harness-before.json').write_text(json.dumps(harness_before, indent=2, sort_keys=True) + '\n')
    prefix = ('ROOT=' + repr(str(root)) + '\nRESULT=' + repr(str(out / 'tests.json'))
              + '\nEVENTS=' + repr(str(out / 'test-events.jsonl'))
              + '\nLOADED=' + repr(str(out / 'loaded-tests.json')) + '\n')
    command = [str(binaries['python']), '-B', '-c', prefix + child_path.read_text()]
    (out / 'RUNNING.json').write_text(json.dumps({'scope': 'INDEPENDENT_FULL_RETAINED_OBSERVATION',
        'expected_head': args.expected_head, 'cold': cold_before, 'workflow_seconds': seconds,
        'previous_v4_component_groups_replayed': False, 'started_utc_seconds': time.time()}, indent=2) + '\n')
    print(json.dumps({'starting': 'independent-full-retained-regression', 'source_head': args.expected_head,
                      'workflow_seconds': seconds, 'output': str(out)}), flush=True)
    owner = workflow_process.run_workflow_step(command, cwd=root, env=environment,
        stdout_path=out / 'stdout.log', stderr_path=out / 'stderr.log',
        receipt_path=out / 'owner.json', seconds=seconds)
    source_error = None
    try:
        after = identity._source_state()
        preserved = after == before
    except BaseException as error:
        after = {'error': repr(error)}
        source_error = traceback.format_exc()
        preserved = False
    (out / 'source-after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    harness_after = {name: file_record(path) for name, path in harness_paths.items()}
    cold_error = None
    try:
        cold_evidence_after = recheck_cold_evidence(cold_pins, cold_evidence_before,
                                                  cold_sources, admit_cold_build)
        cold_preserved = True
        cold_after = cold_evidence_after['wrapper']
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        cold_error = repr(error)
        cold_evidence_after = {'error': cold_error}
        cold_after = None
        cold_preserved = False
    (out / 'cold-evidence-after.json').write_text(json.dumps(cold_evidence_after, indent=2, sort_keys=True) + '\n')
    suite_error = None
    suite = None
    try:
        suite = json.loads((out / 'tests.json').read_text())
        suite_passed = (type(suite.get('expected_tests')) is int and type(suite.get('tests_run')) is int
            and suite['tests_run'] == suite['expected_tests'] > 0
            and suite.get('successful') is True and suite.get('strict_pass') is True
            and suite.get('loaded_test_ids') == suite.get('executed_test_ids')
            and len(suite.get('loaded_test_ids', [])) == suite['expected_tests']
            and suite.get('excluded_test_ids') == []
            and all(suite.get(key) == [] for key in ('errors', 'failures', 'skipped',
                                                    'expected_failures', 'unexpected_successes')))
    except (OSError, ValueError, TypeError, AttributeError) as error:
        suite_error = repr(error)
        suite_passed = False
    completed = (owner.get('status') == 'WORKFLOW_STEP_COMPLETED' and owner.get('returncode') == 0
                 and owner.get('timed_out') is False and owner.get('cleanup', {}).get('complete') is True)
    passed = completed and suite_passed and preserved and harness_after == harness_before and cold_preserved
    report = {'schema': 'hia.independent-full-retained-observation.v1',
        'status': 'RETAINED_REGRESSION_PASS' if passed else 'HOLD',
        'source_head': before['head'], 'source_tree': before['tree'],
        'source_before': file_record(out / 'source-before.json'),
        'source_after': file_record(out / 'source-after.json'),
        'source_preserved': preserved, 'source_error': source_error,
        'raw_git_tree_blobs_and_modes_checked': True,
        'cold_before': cold_before, 'cold_after': cold_after,
        'cold_report_preserved': cold_preserved,
        'cold_evidence_before': file_record(out / 'cold-evidence-before.json'),
        'cold_evidence_after': file_record(out / 'cold-evidence-after.json'),
        'cold_wrapper_nested_and_compiler_preserved': cold_preserved,
        'cold_admission_error': cold_error, 'cold_original_snapshots': cold_snapshots,
        'cold_snapshots_used_as_qualification_inputs': False,
        'harness_before': harness_before, 'harness_after': harness_after,
        'harness_preserved': harness_before == harness_after,
        'environment': file_record(out / 'environment.json'), 'owner': owner,
        'loaded_tests': file_record(out / 'loaded-tests.json') if (out / 'loaded-tests.json').exists() else None,
        'test_events': file_record(out / 'test-events.jsonl') if (out / 'test-events.jsonl').exists() else None,
        'suite_result': file_record(out / 'tests.json') if (out / 'tests.json').exists() else None,
        'suite_error': suite_error, 'expected_tests': suite.get('expected_tests') if suite else None,
        'tests_run': suite.get('tests_run') if suite else None,
        'suite_passed': suite_passed, 'strict_workflow_completed': completed,
        'old_ec484_discovery_count_for_comparison_only': 4250,
        'full_v4_workflow_qualified': False, 'whole_native_delivery_qualified': False,
        'previous_v4_component_groups_replayed': False,
        'selfhost_qualification_gate_modified': False}
    (out / 'RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'source_head', 'expected_tests',
        'tests_run', 'source_preserved', 'suite_passed')}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
