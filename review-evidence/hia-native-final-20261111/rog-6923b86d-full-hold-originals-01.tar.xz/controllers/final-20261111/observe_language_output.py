#!/usr/bin/env python3
"""Retain the existing full run's language evidence; never execute a test."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import sys
import time

KEY = 'HIA_SELFHOST_LANGUAGE_EVIDENCE'
PREFIX = 'tests.test_hia_selfhost_language_coverage.SelfhostLanguageNativeTests.'
METHODS = {
    'test_all_generations_and_raw_evidence_are_retained',
    'test_boolean_equality_reads_all_truth_table_inputs',
    'test_checked_arithmetic_traps_before_later_writes_and_preserves_prior_writes',
    'test_checked_casts_read_runtime_values_and_preserve_trap_write_order',
    'test_every_positive_program_runs_under_both_hia_compilers',
    'test_invalid_checked_shifts_trap_with_native_output_preserved',
    'test_negative_inputs_are_transactionally_rejected_by_both_compilers',
    'test_new_integer_operations_use_runtime_input_under_both_compilers',
    'test_original_and_modified_compilers_are_real_fixed_points',
    'test_select_uses_changing_inputs_and_full_width_output_under_both_compilers',
}
IDS = {PREFIX + name for name in METHODS}


def record(path):
    path = Path(path).absolute()
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('observed output must not use symlinks: ' + str(path))
    before = path.stat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('not a regular evidence file: ' + str(path))
    with path.open('rb') as stream:
        digest = __import__('hashlib').file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError('evidence changed while being read: ' + str(path))
    return {'path': str(path), 'bytes': after.st_size, 'sha256': digest,
            'mode': stat.S_IMODE(after.st_mode)}


def read_json(path):
    before = record(path)
    raw = Path(path).read_bytes()
    if sha256(raw).hexdigest() != before['sha256'] or record(path) != before:
        raise ValueError('parsed JSON differs from its captured bytes')
    return json.loads(raw), before


def started(args, result):
    full = args.full_output.resolve(strict=True)
    report = args.report.absolute()
    if report.parent.resolve() != full or report.exists() or report.with_suffix('.evidence').exists():
        raise ValueError('the language output must be a fresh path directly under this full output')
    if any(p.is_symlink() for p in (report, *report.parents)):
        raise ValueError('the language output path must not contain symlinks')
    running, running_record = read_json(full / 'RUNNING.json')
    source, source_record = read_json(full / 'source-before.json')
    if running.get('expected_head') != args.expected_head or source.get('head') != args.expected_head:
        raise ValueError('the original full source differs from the requested frozen head')
    with (full / 'test-events.jsonl').open() as stream:
        event = json.loads(stream.readline())
    if event.get('event') != 'discovery_started' or type(event.get('pid')) is not int:
        raise ValueError('the original discovery event/PID is unavailable')
    proc = Path('/proc') / str(event['pid'])
    before = (proc / 'stat').read_text().rsplit(')', 1)[1].split()[19]
    if str((proc / 'cwd').resolve()) != event.get('source'):
        raise ValueError('the actual full child cwd differs from its original event')
    environment = dict(entry.split(b'=', 1) for entry in (proc / 'environ').read_bytes().split(b'\0') if entry)
    observed = environment.get(KEY.encode())
    if observed is None or observed.decode() != str(report):
        raise ValueError('the actual full child did not receive the declared output selector')
    after = (proc / 'stat').read_text().rsplit(')', 1)[1].split()[19]
    if before != after:
        raise ValueError('the actual full child identity changed during observation')
    result.update(status='OUTPUT_SELECTOR_OBSERVED', source_head=args.expected_head,
        full_output=str(full), language_report=str(report), output_absent_at_start_observation=True,
        original_running_record=running_record, original_source_before=source_record,
        actual_child={'pid': event['pid'], 'start_time_ticks': before,
                      'executable': str((proc / 'exe').resolve()), 'event': event},
        observed_output_environment={KEY: observed.decode()}, unrelated_environment_recorded=False)


def finished(args, result):
    start, start_record = read_json(args.started_record)
    if start.get('phase') != 'started' or start.get('status') != 'OUTPUT_SELECTOR_OBSERVED':
        raise ValueError('the original output-selector observation is absent or failed')
    if start.get('observer', {}).get('sha256') != result['observer']['sha256']:
        raise ValueError('the output observer changed between start and finish')
    full = Path(start['full_output'])
    report_path = Path(start['language_report'])
    result.update(source_head=start['source_head'], full_output=str(full), started_record=start_record,
                  language_report_path=str(report_path), missing_or_invalid=[], evidence_files={})
    captured = {}
    def capture(label, path):
        try:
            value, identity = read_json(path)
            result[label + '_file'] = identity
            captured[label] = value
        except (OSError, ValueError, TypeError) as error:
            result['missing_or_invalid'].append({'file': str(path), 'error': str(error)})
    capture('full_result', full / 'RESULT.json')
    capture('suite', full / 'tests.json')
    capture('language', report_path)
    try:
        if record(full / 'RUNNING.json') != start['original_running_record']:
            raise ValueError('the original full start record changed')
        if record(full / 'source-before.json') != start['original_source_before']:
            raise ValueError('the original full source snapshot changed')
    except (OSError, ValueError) as error:
        result['missing_or_invalid'].append({'error': str(error)})
    evidence = report_path.with_suffix('.evidence')
    try:
        if not evidence.is_dir() or evidence.is_symlink():
            raise ValueError('the actual language evidence directory is absent')
        paths = sorted(p for p in evidence.rglob('*') if not p.is_dir() or p.is_symlink())
        if not paths:
            raise ValueError('the actual language evidence directory is empty')
        inventory = {p.relative_to(evidence).as_posix(): record(p) for p in paths}
        required = {'B0.receipt.json', 'independent-reference.json'} | {
            generation + suffix for generation in ('B1', 'B2', 'B3', 'M1', 'M2', 'M3')
            for suffix in ('.image.bin', '.stdout.log', '.stderr.log')}
        if not required <= set(inventory):
            raise ValueError('required original generation evidence is missing: ' + repr(sorted(required-set(inventory))))
        if paths != sorted(p for p in evidence.rglob('*') if not p.is_dir() or p.is_symlink()):
            raise ValueError('language evidence inventory changed during observation')
        if any(record(evidence/name) != original for name, original in inventory.items()):
            raise ValueError('language evidence bytes changed during observation')
        result['evidence_files'] = inventory
    except (OSError, ValueError) as error:
        result['missing_or_invalid'].append({'file': str(evidence), 'error': str(error)})
    suite, full_result, language = (captured.get(name, {}) for name in ('suite', 'full_result', 'language'))
    loaded = [i for i in suite.get('loaded_test_ids', []) if i.startswith(PREFIX)]
    executed = [i for i in suite.get('executed_test_ids', []) if i.startswith(PREFIX)]
    executions = [row for row in suite.get('test_executions', []) if row.get('test_id', '').startswith(PREFIX)]
    assertions_ok = (len(loaded) == len(executed) == len(executions) == 10
        and set(loaded) == IDS and executed == loaded
        and [row.get('test_id') for row in executions] == loaded
        and all(type(row.get('completed_ns')) is int
            and sum(outcome.get('status') == 'passed' for outcome in row.get('outcomes', [])) == 1
            and all(outcome.get('status') in ('passed', 'subtest_passed') for outcome in row.get('outcomes', []))
            for row in executions))
    bound = (full_result.get('source_head') == start['source_head']
             and (full_result.get('suite_result') or {}).get('sha256') == result.get('suite_file', {}).get('sha256'))
    language_ok = (language.get('status') == 'SELFHOST_LANGUAGE_COVERAGE_PASS'
                  and bool(language.get('checks')) and all(value is True for value in language['checks'].values()))
    full_ok = full_result.get('status') == 'RETAINED_REGRESSION_PASS' and full_result.get('source_preserved') is True
    result.update(full_status=full_result.get('status'), language_status=language.get('status'),
        original_language_test_ids=loaded, original_language_test_executions=executions,
        ten_original_assertions_passed=assertions_ok, full_suite_file_binding_matches=bound,
        language_checks_all_true=language_ok, full_regression_pass=full_ok,
        status='ORIGINAL_LANGUAGE_OUTPUT_RETAINED' if assertions_ok and bound and language_ok and full_ok
            and not result['missing_or_invalid'] else 'HOLD')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='phase', required=True)
    start = sub.add_parser('started')
    for key in ('full-output', 'report'):
        start.add_argument('--' + key, type=Path, required=True)
    start.add_argument('--expected-head', required=True)
    end = sub.add_parser('finished')
    end.add_argument('--started-record', type=Path, required=True)
    for item in (start, end):
        item.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = {'schema': 'hia.original-full-language-output-observation.v1', 'phase': args.phase,
        'status': 'HOLD', 'observer': record(__file__), 'observed_at_unix_seconds': time.time(),
        'project_tests_executed_by_observer': 0, 'language_qualification_repeated': False,
        'standalone_assertions_file_fabricated': False, 'whole_native_delivery_qualified': False}
    try:
        (started if args.phase == 'started' else finished)(args, result)
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'output': str(args.output),
                      'language_status': result.get('language_status'), 'full_status': result.get('full_status')}))
    return 1 if result['status'] == 'HOLD' else 0


if __name__ == '__main__':
    raise SystemExit(main())
