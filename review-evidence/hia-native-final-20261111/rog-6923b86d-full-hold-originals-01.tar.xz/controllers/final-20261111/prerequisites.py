#!/usr/bin/env python3
"""Observe the full retained test prerequisites without running a test.

This external observer does not alter the frozen controller, source, test set,
or budgets. A ready result is preparation evidence, never a regression pass.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys
import time
import unittest

sys.dont_write_bytecode = True
CONTROLLER_SHA256 = "b86ed6752303a76dd4cd21a7e7a4abb3a90507dc1f183011f44d4669a6761edb"
REQUIRED_EXTRAS = {
    "LEAN", "HEPTA_RUN_ARTIFACT_SESSION", "HIA_TEST_CLANG20", "HEPTA_LLD",
    "HEPTA_QEMU_AARCH64", "HEPTA_QEMU_X86_64", "HEPTA_NDU_BRIDGE",
    "HEPTA_NDU_BUILD", "HEPTA_NDU_UPSTREAM", "HEPTA_RECURSIVE_NDU_BRIDGE",
    "HEPTA_RECURSIVE_NDU_IDENTITY", "HEPTA_FINITE_NDU_BRIDGE",
    "HEPTA_FINITE_NDU_IDENTITY", "HEPTA_NDU_STREAM_IDENTITY",
    "HEPTA_RAW_MODEL_BRIDGE", "HEPTA_RAW_MODEL_BUILD",
    "HEPTA_DYNAMIC_POLICY_BINARY", "HEPTA_DYNAMIC_POLICY_MANIFEST",
}
OPTIONAL_OUTPUTS = {"HEPTA_RAW_MODEL_TRANSCRIPT"}
TOOL_EXTRAS = {"LEAN", "HIA_TEST_CLANG20", "HEPTA_LLD", "HEPTA_QEMU_AARCH64", "HEPTA_QEMU_X86_64"}
INPUT_DIRECTORIES = {"HEPTA_NDU_BUILD", "HEPTA_NDU_UPSTREAM"}
BARE_TOOLS = ("clang", "clang-20", "cc", "gcc", "ld", "as", "objcopy", "objdump",
              "readelf", "git", "bash", "strace", "cargo", "rustc")


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()


def record(path):
    path = Path(path).absolute()
    before = path.stat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError("not a regular input file: " + str(path))
    with path.open("rb") as stream:
        digest = __import__("hashlib").file_digest(stream, "sha256").hexdigest()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError("input changed while being read: " + str(path))
    return {"path": str(path), "resolved_path": str(path.resolve(strict=True)),
            "bytes": after.st_size, "mode": stat.S_IMODE(after.st_mode), "sha256": digest}


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def discovery_observation(suite, loader_errors):
    tests = list(flatten(suite))
    ids = [test.id() for test in tests]
    skipped, expected_failures = [], []
    for test in tests:
        cls = type(test)
        method = getattr(test, test._testMethodName)
        if getattr(cls, "__unittest_skip__", False) or getattr(method, "__unittest_skip__", False):
            skipped.append({"test_id": test.id(), "class_reason": getattr(cls, "__unittest_skip_why__", None),
                            "method_reason": getattr(method, "__unittest_skip_why__", None)})
        if getattr(method, "__unittest_expecting_failure__", False):
            expected_failures.append(test.id())
    return {"loaded_ids": ids, "count": len(ids), "count_test_cases": suite.countTestCases(),
            "ordered_ids_sha256": sha256(canonical(ids)).hexdigest(),
            "duplicate_ids": len(ids) != len(set(ids)), "loader_errors": list(loader_errors),
            "decorated_skips": skipped, "decorated_expected_failures": expected_failures,
            "tests_executed": 0, "runtime_setUp_or_test_outcomes_not_observed": True}


def tool_metadata(path, environment, arguments=("--version",)):
    path = Path(path).absolute()
    before = record(path)
    with path.open("rb") as stream:
        if stream.read(4) != b"\x7fELF":
            raise ValueError("selected native tool is not an actual ELF executable: " + str(path))
    process = subprocess.run([str(path), *arguments], env=environment, capture_output=True,
                             text=True, timeout=20)
    if process.returncode or record(path) != before:
        raise ValueError("tool identity/version observation failed: " + str(path))
    return {**before, "version_argv": [str(path), *arguments], "returncode": process.returncode,
            "stdout": process.stdout, "stderr": process.stderr}


def git_observation(directory):
    directory = Path(directory).resolve(strict=True)
    def git(*arguments):
        return subprocess.run(["git", "--no-replace-objects", "-C", str(directory), *arguments],
                              check=True, capture_output=True, text=True, timeout=20).stdout
    return {"path": str(directory), "head": git("rev-parse", "HEAD").strip(),
            "tree": git("rev-parse", "HEAD^{tree}").strip(),
            "status": git("status", "--porcelain=v1", "--untracked-files=all")}


def capture(args):
    root, out = args.repo.resolve(strict=True), args.output.resolve(strict=False)
    full_out = args.full_output.resolve(strict=False)
    args.binding_files = args.binding_files.resolve(strict=True)
    cold_path = args.cold_report.resolve(strict=True)
    if out == root or out.is_relative_to(root) or root.is_relative_to(out):
        raise ValueError("preflight output must be separate from source")
    if full_out == root or full_out.is_relative_to(root) or root.is_relative_to(full_out):
        raise ValueError("full output must be separate from source")
    if full_out == out or full_out.is_relative_to(out) or out.is_relative_to(full_out):
        raise ValueError("full output and preflight output must be separate directories")
    controller = Path(__file__).with_name("run_retained_regression.py").resolve(strict=True)
    if record(controller)["sha256"] != CONTROLLER_SHA256:
        raise ValueError("full controller differs from the reviewed b86ed version")
    spec = importlib.util.spec_from_file_location("retained_preflight_controller", controller)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    extras_path = args.extra_environment.resolve(strict=True)
    extras_raw = extras_path.read_bytes()
    extras = json.loads(extras_raw)
    if (type(extras) is not dict or not REQUIRED_EXTRAS <= set(extras)
            or not set(extras) <= REQUIRED_EXTRAS | OPTIONAL_OUTPUTS
            or any(type(v) is not str or not v for v in extras.values())):
        raise ValueError("extra environment must provide the complete reviewed test-input selectors")
    if any(os.environ.get(key) != value for key, value in extras.items()):
        raise ValueError("launch preflight with the same explicit extra environment as the future full run")
    if extras["HEPTA_RUN_ARTIFACT_SESSION"] != "1":
        raise ValueError("the existing artifact-session opt-in must be explicitly enabled")
    if Path(extras["HIA_TEST_CLANG20"]).resolve(strict=True) != args.clang.resolve(strict=True):
        raise ValueError("the dedicated byte-sum compiler must be the same selected Clang 20")
    environment, binaries = module.tool_environment(args, root, full_out)
    runner = root / "review-evidence/hia-native-rewrite-20261111/run_hia_qualification_v4.py"
    environment, configuration, seconds = module.frozen_configuration(
        runner.read_bytes(), full_out, cold_path, environment)
    os.environ.clear()
    os.environ.update(environment)
    os.chdir(root)
    sys.path.insert(0, str(root))
    from tools import hia_core_source_identity as identity
    from tools.hia_selfhost_contract import validate_contract, CONTRACT_PATH
    from tools.build_hia_json_preflight import admit_cold_build
    before = identity._source_state()
    if before["head"] != args.expected_head or before["status"]:
        raise ValueError("source is not the exact clean frozen commit")
    contract = validate_contract()
    cold_sources = {**contract["source_identity"]["files"],
                    CONTRACT_PATH: sha256((root / CONTRACT_PATH).read_bytes()).hexdigest()}
    cold_pins, cold_record = module.capture_cold_evidence(cold_path, cold_sources, admit_cold_build)
    versions = module.tool_versions(environment, binaries)
    bindings = {}
    def bind(path, expected=None):
        observed = record(path)
        if expected is not None and observed["sha256"] != expected:
            raise ValueError("bound dependency differs from its original receipt: " + observed["path"])
        old = bindings.setdefault(observed["path"], observed)
        if old != observed:
            raise ValueError("one dependency changed across observations")
        return observed
    for path in (Path(__file__), controller, extras_path, args.binding_files, runner):
        bind(path)
    for path in binaries.values():
        bind(path)
    binding_raw = args.binding_files.read_bytes()
    if (sha256(extras_raw).hexdigest() != bindings[str(extras_path)]["sha256"]
            or sha256(binding_raw).hexdigest() != bindings[str(args.binding_files)]["sha256"]):
        raise ValueError("parsed prerequisite input bytes differ from the bound original")
    requested = json.loads(binding_raw)
    if type(requested) is dict:
        requested = [{"path": path, "sha256": digest} for path, digest in requested.items()]
    if type(requested) is not list or not requested:
        raise ValueError("explicit NDU receipt dependency bindings must be a nonempty mapping or list")
    for item in requested:
        if isinstance(item, str):
            bind(item)
        elif type(item) is dict and set(item) <= {"path", "sha256"} and "path" in item:
            bind(item["path"], item.get("sha256"))
        else:
            raise ValueError("invalid explicit dependency binding")
    directories = {}
    for key, value in extras.items():
        if key == "HEPTA_RUN_ARTIFACT_SESSION" or key in OPTIONAL_OUTPUTS:
            continue
        if key in INPUT_DIRECTORIES:
            path = Path(value).resolve(strict=True)
            if not path.is_dir():
                raise ValueError("test input directory is unavailable: " + key)
            directories[key] = {"path": value, "resolved_path": str(path)}
            if key == "HEPTA_NDU_UPSTREAM":
                directories[key]["git"] = git_observation(path)
            else:
                bind(path / "build-receipt.json")
        else:
            bind(value)
    tools = {}
    for key in sorted(TOOL_EXTRAS):
        tools[key] = tool_metadata(extras[key], environment, ("-flavor", "gnu", "--version") if key == "HEPTA_LLD" else ("--version",))
        bind(extras[key])
    lean_lock = json.loads((root / "formal/toolchain-lock.json").read_bytes())
    qemu_lock = json.loads((root / "formal/qemu-toolchain-lock.json").read_bytes())
    if tools["LEAN"]["sha256"] != lean_lock["lean_binary_sha256"] or "4.19.0" not in tools["LEAN"]["stdout"]:
        raise ValueError("Lean is not the exact locked 4.19.0 checker")
    if tools["HEPTA_QEMU_AARCH64"]["sha256"] != qemu_lock["binary_sha256"]:
        raise ValueError("AArch64 QEMU is not the exact locked reviewed binary")
    lean_root = Path(extras["LEAN"]).resolve().parent.parent
    lean_files = ["lib/lean/libInit_shared.so", "lib/lean/libleanshared.so", "lib/lean/libleanshared_1.so"]
    lean_files.extend("lib/lean/" + line for line in (root / "formal/proof-dependencies.txt").read_text().splitlines()
                      if line and not line.startswith("#"))
    for name in lean_files:
        bind(lean_root / name)
    for name in BARE_TOOLS:
        path = shutil.which(name, path=environment["PATH"])
        if path is None:
            raise ValueError("actual required PATH tool is absent: " + name)
        tools["PATH:" + name] = tool_metadata(path, environment)
        bind(path)
    for path in ("/usr/bin/strace", "/usr/bin/objdump"):
        bind(path)
    loader = unittest.TestLoader()
    suite = loader.discover("tests", top_level_dir=".")
    discovery = discovery_observation(suite, loader.errors)
    exact = (discovery["ordered_ids_sha256"] == args.expected_discovery_sha256
             and discovery["count"] == discovery["count_test_cases"] > 0
             and not discovery["duplicate_ids"] and not discovery["loader_errors"]
             and not discovery["decorated_skips"] and not discovery["decorated_expected_failures"])
    after = identity._source_state()
    module.recheck_cold_evidence(cold_pins, cold_record, cold_sources, admit_cold_build)
    preserved = before == after and all(record(name) == value for name, value in bindings.items())
    out.mkdir(parents=True, exist_ok=False)
    write_new(out / "source-before.json", before)
    write_new(out / "source-after.json", after)
    write_new(out / "discovery.json", discovery)
    report = {"schema": "hepta.external-retained-prerequisites.v1", "scope": "PREPARATION_ONLY_NO_TESTS_EXECUTED",
        "status": "READY_FOR_FULL_NOT_TEST_PASS" if exact and preserved else "HOLD",
        "source": str(root),
        "source_head": before["head"], "source_tree": before["tree"], "source_preserved": preserved,
        "source_before": record(out / "source-before.json"), "source_after": record(out / "source-after.json"),
        "full_output": str(full_out), "full_controller_sha256": CONTROLLER_SHA256,
        "observed_at_utc_seconds": time.time(), "python": platform.python_version(),
        "extra_environment": extras, "full_configuration": configuration, "workflow_seconds": seconds,
        "versions": versions, "tools": tools, "bound_files": bindings, "input_directories": directories,
        "cold_evidence": cold_record, "discovery": record(out / "discovery.json"),
        "loaded_tests": discovery["count"], "ordered_ids_sha256": discovery["ordered_ids_sha256"],
        "zero_decorated_skips": not discovery["decorated_skips"],
        "zero_decorated_expected_failures": not discovery["decorated_expected_failures"],
        "runtime_setUp_or_test_outcomes_not_observed": True, "actual_regression_pass_claimed": False}
    write_new(out / "prerequisites.json", report)
    print(json.dumps({"status": report["status"], "loaded_tests": discovery["count"],
                      "decorated_skips": len(discovery["decorated_skips"]), "report": str(out / "prerequisites.json")}))
    return 0 if exact and preserved else 1


def verify(args):
    manifest_record = record(args.manifest)
    manifest = json.loads(args.manifest.read_bytes())
    if manifest.get("status") != "READY_FOR_FULL_NOT_TEST_PASS":
        raise ValueError("preparation never reached ready status")
    changed = []
    for path, original in manifest["bound_files"].items():
        try:
            if record(path) != original:
                changed.append(path)
        except Exception as error:
            changed.append(path + ": " + str(error))
    environment_changed = [key for key, value in manifest["extra_environment"].items()
                           if os.environ.get(key) != value]
    directory_changes = []
    for key, original in manifest["input_directories"].items():
        path = Path(original["path"])
        if not path.is_dir() or str(path.resolve()) != original["resolved_path"]:
            directory_changes.append(key)
        elif "git" in original and git_observation(path) != original["git"]:
            directory_changes.append(key)
    full_record = record(args.full_record)
    if Path(full_record["path"]).parent.resolve() != Path(manifest["full_output"]).resolve():
        raise ValueError("the observed full record belongs to another output directory")
    expected_name = "RUNNING.json" if args.phase == "started" else "RESULT.json"
    if args.full_record.name != expected_name:
        raise ValueError("the phase must bind the corresponding original full controller record")
    full = json.loads(args.full_record.read_bytes())
    head = full.get("expected_head") if args.phase == "started" else full.get("source_head")
    if head != manifest["source_head"]:
        raise ValueError("full record source differs from prerequisite source")
    full_environment_path = Path(manifest["full_output"]) / "environment.json"
    full_environment = json.loads(full_environment_path.read_bytes())
    if any(full_environment.get(key) != value for key, value in manifest["full_configuration"].items()):
        raise ValueError("actual full controller environment differs from the prepared configuration")
    actual_child = None
    started_record = None
    if args.phase == "started":
        events_path = Path(manifest["full_output"]) / "test-events.jsonl"
        with events_path.open() as stream:
            first_event = json.loads(stream.readline())
        if first_event.get("event") != "discovery_started" or first_event.get("source") != manifest["source"]:
            raise ValueError("original full child discovery event is unavailable or differs")
        pid = first_event.get("pid")
        if type(pid) is not int or pid <= 1:
            raise ValueError("invalid original full child PID")
        proc = Path("/proc") / str(pid)
        process_stat_before = (proc / "stat").read_text()
        if str((proc / "cwd").resolve()) != manifest["source"]:
            raise ValueError("original full child cwd differs")
        raw_environment = (proc / "environ").read_bytes()
        actual_environment = dict(entry.decode().split("=", 1) for entry in raw_environment.split(b"\0") if entry)
        actual_extras = {key: actual_environment.get(key) for key in manifest["extra_environment"]}
        if actual_extras != manifest["extra_environment"]:
            raise ValueError("the actual running full child did not receive all reviewed extra selectors")
        # The start-time field is stable; CPU/accounting fields can advance.
        start_time_before = process_stat_before.rsplit(")", 1)[1].split()[19]
        start_time_after = (proc / "stat").read_text().rsplit(")", 1)[1].split()[19]
        if start_time_before != start_time_after:
            raise ValueError("observed full child identity changed")
        actual_child = {"pid": pid, "proc_start_time_ticks": start_time_before,
                        "executable": str((proc / "exe").resolve()),
                        "extra_environment": actual_extras, "first_event": first_event,
                        "no_unrelated_environment_values_recorded": True}
    else:
        if args.started_record is None:
            raise ValueError("finished verification must bind the original started recheck")
        started_record = record(args.started_record)
        started = json.loads(args.started_record.read_bytes())
        if (started.get("phase") != "started" or started.get("status") != "PRESERVED"
                or started.get("manifest") != manifest_record or not started.get("actual_running_child")):
            raise ValueError("original started recheck is absent or did not preserve prerequisites")
    if record(args.manifest) != manifest_record:
        raise ValueError("prerequisite manifest changed during recheck")
    ok = not changed and not environment_changed and not directory_changes
    result = {"schema": "hepta.external-retained-prerequisites-recheck.v1", "phase": args.phase,
              "status": "PRESERVED" if ok else "HOLD", "manifest": manifest_record,
              "full_record": full_record, "observed_at_utc_seconds": time.time(),
              "full_environment": record(full_environment_path), "actual_running_child": actual_child,
              "started_record": started_record,
              "changed_files": changed, "changed_environment_keys": environment_changed,
              "changed_input_directories": directory_changes, "actual_regression_pass_claimed": False}
    write_new(args.output, result)
    print(json.dumps(result))
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    capture_parser = commands.add_parser("capture")
    for name in ("repo", "python", "clang", "rustc", "cargo", "cargo-home", "cold-report",
                 "full-output", "output", "extra-environment", "binding-files"):
        capture_parser.add_argument("--" + name, type=Path, required=True)
    capture_parser.add_argument("--expected-head", required=True)
    capture_parser.add_argument("--expected-discovery-sha256", required=True)
    capture_parser.add_argument("--cargo-target-dir", type=Path)
    capture_parser.add_argument("--path-entry", type=Path, action="append", default=[])
    capture_parser.add_argument("--library-path", type=Path, action="append", default=[])
    verify_parser = commands.add_parser("verify")
    verify_parser.add_argument("--manifest", type=Path, required=True)
    verify_parser.add_argument("--full-record", type=Path, required=True)
    verify_parser.add_argument("--output", type=Path, required=True)
    verify_parser.add_argument("--phase", choices=("started", "finished"), required=True)
    verify_parser.add_argument("--started-record", type=Path)
    args = parser.parse_args()
    return capture(args) if args.command == "capture" else verify(args)


if __name__ == "__main__":
    raise SystemExit(main())
