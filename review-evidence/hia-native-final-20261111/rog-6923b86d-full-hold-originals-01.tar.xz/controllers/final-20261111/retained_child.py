"""Record the unchanged complete unittest discovery; no test-selection controls.

Executed with -c after the controller supplies ROOT, RESULT, EVENTS and LOADED.
The strict v4 result checks are preserved and complete ordered IDs are added.
"""
import json
import os
from pathlib import Path
import sys
import time
import traceback
import unittest


def run_complete_discovery(root, result_path, events_path, loaded_path):
    root = Path(root).resolve(strict=True)
    if Path.cwd().resolve() != root:
        raise RuntimeError('test cwd differs from the pinned source')
    sys.path.insert(0, str(root))
    dumps = json.dumps
    monotonic_ns = time.monotonic_ns
    event_sequence = 0
    with Path(events_path).open('x', encoding='utf-8', buffering=1) as events:
        write_event_line = events.write
        flush_events = events.flush

        def event(kind, **fields):
            nonlocal event_sequence
            event_sequence += 1
            write_event_line(dumps({'sequence': event_sequence,
                                   'monotonic_ns': monotonic_ns(),
                                   'event': kind, **fields}, ensure_ascii=True) + '\n')
            flush_events()

        def flatten(suite):
            for test in suite:
                if isinstance(test, unittest.TestSuite):
                    yield from flatten(test)
                else:
                    yield test

        event('discovery_started', source=str(root), pid=os.getpid())
        loader = unittest.defaultTestLoader
        suite = loader.discover('tests', top_level_dir='.')
        loaded_ids = [test.id() for test in flatten(suite)]
        expected = suite.countTestCases()
        if expected != len(loaded_ids):
            raise RuntimeError('loaded ID inventory differs from unittest count')
        loaded = {'source': str(root), 'discovery': {'start_dir': 'tests',
                  'top_level_dir': '.', 'pattern': 'test*.py'},
                  'expected_tests': expected, 'loaded_test_ids': loaded_ids,
                  'loader_errors': list(loader.errors), 'excluded_test_ids': []}
        Path(loaded_path).write_text(dumps(loaded, indent=2) + '\n')
        event('discovery_completed', expected_tests=expected,
              loader_error_count=len(loader.errors))

        class RecordingResult(unittest.TextTestResult):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.executed_ids = []
                self.executions = []
                self.active = None

            def startTest(self, test):
                super().startTest(test)
                self.executed_ids.append(test.id())
                self.active = {'ordinal': len(self.executed_ids), 'test_id': test.id(),
                               'started_ns': monotonic_ns(), 'outcomes': []}
                self.executions.append(self.active)
                event('test_started', **self.active)

            def outcome(self, test, status, **fields):
                row = {'status': status, 'test_id': test.id(), **fields}
                if self.active is not None:
                    self.active['outcomes'].append(row)
                event('test_outcome', **row)

            def stopTest(self, test):
                if self.active is not None:
                    self.active['completed_ns'] = monotonic_ns()
                    self.active['wall_ns'] = (self.active['completed_ns']
                                              - self.active['started_ns'])
                    event('test_completed', **self.active)
                self.active = None
                super().stopTest(test)

            def addSuccess(self, test):
                super().addSuccess(test)
                self.outcome(test, 'passed')

            def addError(self, test, err):
                super().addError(test, err)
                self.outcome(test, 'error', traceback=self.errors[-1][1])

            def addFailure(self, test, err):
                super().addFailure(test, err)
                self.outcome(test, 'failed', traceback=self.failures[-1][1])

            def addSkip(self, test, reason):
                super().addSkip(test, reason)
                self.outcome(test, 'skipped', reason=reason)

            def addExpectedFailure(self, test, err):
                super().addExpectedFailure(test, err)
                self.outcome(test, 'expected_failure', traceback=self.expectedFailures[-1][1])

            def addUnexpectedSuccess(self, test):
                super().addUnexpectedSuccess(test)
                self.outcome(test, 'unexpected_success')

            def addSubTest(self, test, subtest, err):
                super().addSubTest(test, subtest, err)
                if err is None:
                    status, details = 'subtest_passed', {}
                else:
                    status = ('subtest_failed' if issubclass(err[0], test.failureException)
                              else 'subtest_error')
                    details = {'traceback': self._exc_info_to_string(err, test)}
                self.outcome(subtest, status, parent_test_id=test.id(), **details)

        started = monotonic_ns()
        try:
            result = unittest.TextTestRunner(verbosity=2, failfast=False,
                                             resultclass=RecordingResult).run(suite)
        except BaseException as error:
            event('runner_exception', exception_type=type(error).__name__,
                  traceback=traceback.format_exc())
            raise
        anomalies = {
            'errors': [{'test': test.id(), 'traceback': text} for test, text in result.errors],
            'failures': [{'test': test.id(), 'traceback': text} for test, text in result.failures],
            'skipped': [{'test': test.id(), 'reason': reason} for test, reason in result.skipped],
            'expected_failures': [{'test': test.id(), 'traceback': text}
                                  for test, text in result.expectedFailures],
            'unexpected_successes': [test.id() for test in result.unexpectedSuccesses],
        }
        passed = (result.testsRun == expected and expected > 0
                  and result.executed_ids == loaded_ids and result.wasSuccessful()
                  and not any(anomalies.values()))
        value = {'schema': 'hia.independent-complete-retained-tests.v1',
                 'status': 'PASS' if passed else 'HOLD',
                 'expected_tests': expected, 'tests_run': result.testsRun,
                 'successful': result.wasSuccessful(), 'strict_pass': passed,
                 'loaded_test_ids': loaded_ids, 'executed_test_ids': result.executed_ids,
                 'ordered_loaded_and_executed_ids_equal': result.executed_ids == loaded_ids,
                 'test_executions': result.executions, 'loader_errors': list(loader.errors),
                 'excluded_test_ids': [], 'wall_seconds': (monotonic_ns() - started) / 1e9,
                 **anomalies}
        Path(result_path).write_text(dumps(value, indent=2) + '\n')
        event('suite_completed', status=value['status'], tests_run=result.testsRun,
              expected_tests=expected, anomalies={key: len(value) for key, value in anomalies.items()})
        return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(run_complete_discovery(ROOT, RESULT, EVENTS, LOADED))
