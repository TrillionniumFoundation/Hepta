import hashlib,io,json,lzma,os,pathlib,stat,sys,tarfile,time,traceback
T=pathlib.Path("/tmp/hia-a4f12-delivery-20261111")
F=T/"retained-full-6923b86d"
P=T/"retained-prerequisites-6923b86d"
PL=T/"retained-prerequisites-launch-6923b86d"
L=T/"retained-full-launch-6923b86d"
OUT=T/"pack-full6923-hold-01"
ARCHIVE=T/"rog-6923b86d-full-hold-originals-01.tar.xz"
MANIFEST=T/"rog-6923b86d-full-hold-originals-01-MANIFEST.json"
OUT.mkdir(mode=0o700,exist_ok=False)
(OUT/"controller.py").write_text(sys.argv[1])
started=time.monotonic()
result={"status":"HOLD","source_head":"6923b86d9a007aa15b9a5803b35c0f288590dfd2",
        "original_full_status":"HOLD","project_tests_executed":0,"native_executions":0,
        "original_records_modified":False,"errors":[]}

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write("\n")

def read(path):return json.loads(path.read_bytes())

def record(path):
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode):raise ValueError("not a regular original file: "+str(path))
    digest=hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b""):digest.update(chunk)
    after=path.lstat()
    if (before.st_dev,before.st_ino,before.st_size,before.st_mode,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mode,after.st_mtime_ns,after.st_ctime_ns):
        raise ValueError("original changed during packaging read: "+str(path))
    return {"path":str(path),"bytes":before.st_size,"sha256":digest.hexdigest(),"mode":stat.S_IMODE(before.st_mode)}

try:
    assert not ARCHIVE.exists() and not MANIFEST.exists()
    original=record(F/"RESULT.json")
    assert original["sha256"]=="98566791c364a663fceaa4abefa63150a09ad45cfc4d31ed2dae8ed6fa6a9750"
    full=read(F/"RESULT.json")
    assert full["status"]=="HOLD" and full["source_head"]==result["source_head"] and full["source_tree"]=="1e77b5916c6ea45ccc32a7364de0a3d683a7c2eb"
    assert full["expected_tests"]==full["tests_run"]==4388 and full["source_preserved"] is True
    assert full["cold_wrapper_nested_and_compiler_preserved"] is True and full["harness_preserved"] is True
    owner=read(F/"owner.json")
    assert owner==full["owner"] and owner["status"]=="WORKFLOW_STEP_HOLD" and owner["returncode"]==1 and owner["timed_out"] is False
    assert owner["cleanup"]["complete"] is True and owner["cleanup"]["errors"]==[]
    language=read(P/"language-finished.json")
    assert record(P/"language-finished.json")["sha256"]=="97c44ee11ec2cfe0a481521eb056079d65dc6319ecb3b9cae9cb5ea2c24fb457"
    assert language["status"]=="HOLD" and language["full_regression_pass"] is False
    assert language["ten_original_assertions_passed"] is True and len(language["evidence_files"])==51 and language["missing_or_invalid"]==[]
    prerequisite=read(P/"finished.json")
    assert record(P/"finished.json")["sha256"]=="3136cc7677ae0e85e94e6e03e05d9caf75ce89cff9956f8c6b62106395ff3c4f"
    assert prerequisite["status"]=="PRESERVED"
    review=T/"independent-progress-6923b86d/final-review.json"
    assert record(review)["sha256"]=="45fb0c67d9fcecdd66b04af011a2c18f638c6b3d390e7236bd932ce663f76ffe"
    assert read(review)["status"]=="ORIGINAL_FULL_HOLD_VERIFIED"
    files={}
    expected={}
    def select(path,arcname=None,pin=None):
        path=path.absolute()
        if not path.is_relative_to(T):raise ValueError("original outside the task namespace")
        name=arcname or path.relative_to(T).as_posix()
        if name in files and files[name]!=path:raise ValueError("archive member collision")
        files[name]=path
        if pin is not None:expected[name]=pin
    for path in sorted(F.iterdir()):
        if path.is_file() and path.suffix in (".json",".jsonl",".log"):
            select(path)
    for name,pin in full["cold_original_snapshots"].items():select(pathlib.Path(pin["path"]),pin=pin)
    for key in ("source_before","source_after","cold_evidence_before","cold_evidence_after","environment","loaded_tests","test_events","suite_result"):
        pin=full[key];select(pathlib.Path(pin["path"]),pin=pin)
    for key in ("external_controller","external_child","frozen_v4_runner","frozen_workflow_process"):
        pin=full["harness_before"][key];select(pathlib.Path(pin["path"]),pin=pin)
    for name in ("prerequisites.json","started.json","finished.json","language-started.json","language-finished.json"):
        select(P/name)
    for name in ("RESULT.json","merged-bind-files.json","ndu-reuse-admission.json"):
        select(PL/name)
    for path in sorted(L.iterdir()):
        if path.is_file() and path.suffix in (".json",".log"):select(path)
    for name in ("prerequisites.py","observe_language_output.py"):
        select(T/"controllers/final-20261111"/name)
    select(pathlib.Path(language["language_file"]["path"]),pin=language["language_file"])
    for pin in language["evidence_files"].values():
        path=pathlib.Path(pin["path"])
        if not path.is_relative_to(F/"language-coverage.evidence"):raise ValueError("unexpected original language evidence path")
        select(path,pin=pin)
    select(review)
    quota=T/"full6923-own-quota-syscall-readonly-01/RESULT.json"
    select(quota,pin={"sha256":"afe81fd178e3710b1f8c91d54cd690fd36f88124be657d4232c509477e40eb67","bytes":1733})
    select(OUT/"controller.py","packaging/controller.py")
    rows=[]
    for name,path in sorted(files.items()):
        actual=record(path)
        pin=expected.get(name,{})
        if any(actual[key]!=value for key,value in pin.items() if key in ("sha256","bytes","mode")):
            raise ValueError("original no longer matches its original immutable receipt: "+str(path))
        rows.append({"member":name,"original_path":str(path),**{key:actual[key] for key in ("bytes","sha256","mode")}})
    supplied=read(PL/"merged-bind-files.json")
    assert type(supplied) is dict and len(supplied)==797
    manifest={"schema":"hepta.original-full-hold-byte-archive.v1",
        "source_head":full["source_head"],"source_tree":full["source_tree"],
        "original_full_status":"HOLD","expected_tests":4388,"tests_run":4388,
        "original_full_result_sha256":original["sha256"],
        "original_owner_status":"WORKFLOW_STEP_HOLD","original_workflow_seconds":5400,
        "original_owner_seconds":owner["seconds"],"original_owner_timed_out":False,
        "source_cold_harness_preserved":True,"requested_input_map_entries":797,
        "language_observer_status":"HOLD","ten_original_language_assertions_passed":True,
        "language_evidence_files":51,"project_tests_executed_by_packager":0,"native_executions_by_packager":0,
        "whole_native_delivery_qualified":False,
        "scope":"Selected original full HOLD records, complete tests/events and original language evidence; no test or qualification rerun.",
        "not_included":"Unrelated historical corpora, registry cache, private upstream source trees and native build targets remain at their original task paths.",
        "members":rows,"member_count":len(rows),"original_bytes":sum(row["bytes"] for row in rows)}
    save(MANIFEST,manifest)
    with ARCHIVE.open("xb") as storage,lzma.LZMAFile(storage,"w",preset=6) as encoded,tarfile.open(fileobj=encoded,mode="w|") as package:
        raw=MANIFEST.read_bytes()
        info=tarfile.TarInfo("MANIFEST.json");info.size=len(raw);info.mode=0o644;info.mtime=0
        package.addfile(info,io.BytesIO(raw))
        for row in rows:
            info=tarfile.TarInfo(row["member"]);info.size=row["bytes"];info.mode=row["mode"];info.mtime=0
            with pathlib.Path(row["original_path"]).open("rb") as stream:package.addfile(info,stream)
    indexed={row["member"]:row for row in rows}
    verified=[]
    with tarfile.open(ARCHIVE,"r|xz") as package:
        for member in package:
            if not member.isfile():raise ValueError("archive has a nonregular member")
            stream=package.extractfile(member)
            if member.name=="MANIFEST.json":
                if stream.read()!=MANIFEST.read_bytes():raise ValueError("archive manifest differs")
                continue
            if member.name not in indexed or member.name in verified:raise ValueError("unexpected or duplicate archive member")
            wanted=indexed[member.name];digest=hashlib.sha256()
            for chunk in iter(lambda:stream.read(1024*1024),b""):digest.update(chunk)
            if digest.hexdigest()!=wanted["sha256"] or member.size!=wanted["bytes"] or member.mode!=wanted["mode"]:
                raise ValueError("archive member byte or mode readback differs")
            verified.append(member.name)
    assert set(verified)==set(indexed) and len(verified)==len(rows)
    for row in rows:
        final=record(pathlib.Path(row["original_path"]))
        if any(final[key]!=row[key] for key in ("bytes","sha256","mode")):raise ValueError("original changed during packaging")
    result.update(status="ORIGINAL_FULL_HOLD_FILES_ARCHIVED_AND_VERIFIED",
        archive=record(ARCHIVE),manifest=record(MANIFEST),member_count=len(rows),
        original_bytes=manifest["original_bytes"],all_member_hashes_and_modes_verified=True,
        all_selected_original_files_preserved=True)
except BaseException as error:
    result["errors"].append({"error":repr(error),"traceback":traceback.format_exc()})
result["seconds"]=time.monotonic()-started
save(OUT/"RESULT.json",result)
print(json.dumps(result,sort_keys=True),flush=True)
raise SystemExit(0 if not result["errors"] else 1)
