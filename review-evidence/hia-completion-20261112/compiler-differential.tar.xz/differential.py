from pathlib import Path
import json,sys,time,hashlib
sys.path.insert(0,'/workspace/scratch/a1e68adcd0c9/Hepta')
from tools.qualify_hia_selfhost import compile_stage,invoke
from tools.hia_selfhost_names import cases,value_cases,block_cases,entry_order_cases,refusals,value_refusals,block_refusals,entry_order_refusals
from tools.hia_selfhost_exports_cases import document,allocated_document,dense_document,assembly,refusals as export_refusals
root=Path('/workspace/scratch/a1e68adcd0c9/compiler-audit/final')
old=Path('/workspace/scratch/ccbcd4e7f1a5/validation/v71-fixed-cold.cold/qualification.evidence/B3.image.bin')
source=Path('/workspace/scratch/a1e68adcd0c9/Hepta/examples/hia_bootstrap/selfhost.hepta').read_bytes()
new,r1=compile_stage(root,'optimized-compiler',old,source)
new2,r2=compile_stage(root,'optimized-fixedpoint',new,source)
assert new.read_bytes()==new2.read_bytes()
print(json.dumps({'phase':'fixedpoint','old_compiler_ns':r1['native_elapsed_ns'],'new_compiler_ns':r2['native_elapsed_ns'],'bytes':len(new.read_bytes())}),flush=True)
corpus=[]
seen=set()
for row in [*cases(),*value_cases(),*block_cases(),*entry_order_cases(),*refusals(),*value_refusals(),*block_refusals(),*entry_order_refusals()]:
    s=row['source'].encode() if isinstance(row['source'],str) else row['source']
    if s not in seen:
        seen.add(s);corpus.append((row['id'],s))
from tools.hia_selfhost_owned_elf_cases import cases as owned_cases, refusals as owned_refusals
from tools.hia_selfhost_owned_flow_cases import cases as owned_flow_cases, refusals as owned_flow_refusals
from tools.hia_selfhost_chain_flow_cases import cases as chain_flow_cases, refusals as chain_flow_refusals
from tools.hia_selfhost_chain_cases import cases as chain_cases
from tools.hia_selfhost_loans import loan_cases
for row in [*owned_cases(),*owned_flow_cases(),*chain_flow_cases(),*chain_cases(),*loan_cases()]:
    s=row['source'].encode() if isinstance(row['source'],str) else row['source']
    if s not in seen:
        seen.add(s);corpus.append((row['id'],s))
for provider in (owned_refusals,owned_flow_refusals,chain_flow_refusals):
    values=provider()
    if isinstance(values,dict):values=[{'id':k,'source':v} for k,v in values.items()]
    for row in values:
        s=row['source'].encode() if isinstance(row['source'],str) else row['source']
        if s not in seen:
            seen.add(s);corpus.append((row['id'],s))
for name,value in [('exports',document()),('allocated-exports',allocated_document()),('dense-exports',dense_document())]:
    corpus.append((name,assembly(value)))
for name,s in export_refusals().items():corpus.append(('export-refusal-'+name,s))
rows=[]
for index,(name,s) in enumerate(corpus):
    for fill in (0,165):
        a,ao=invoke(root,f'before-{index}-{fill}',old,s,workspace_fill=fill)
        b,bo=invoke(root,f'after-{index}-{fill}',new,s,workspace_fill=fill)
        comparable=('status','core_u32','abi_status','workspace_header','source_unchanged')
        assert {k:a.get(k) for k in comparable}=={k:b.get(k) for k in comparable},(name,fill,a,b)
        assert ao==bo,(name,fill,'different full output')
        rows.append({'case':name,'source_sha256':hashlib.sha256(s).hexdigest(),'workspace_fill':fill,
                     'result':a.get('core_u32'),'workspace_header':b.get('workspace_header'),
                     'full_output_sha256':hashlib.sha256(bo).hexdigest(),
                     'before_native_ns':a.get('native_elapsed_ns'),'after_native_ns':b.get('native_elapsed_ns')})
    if index%15==0:print(json.dumps({'phase':'differential','done':index+1,'total':len(corpus)}),flush=True)
report={'schema':'hepta.hia.compiler-table-reset-audit.v1','old_compiler_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),
        'new_compiler_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'new_source_sha256':hashlib.sha256(source).hexdigest(),
        'source_before_sha256':hashlib.sha256((root/'selfhost-before.hepta').read_bytes()).hexdigest(),
        'fixed_point_equal':True,'fixedpoint_compile_receipts':[r1,r2],
        'differential_cases':len(rows),'unique_programs':len(corpus),'native_before_ns':sum(x['before_native_ns'] for x in rows),
        'native_after_ns':sum(x['after_native_ns'] for x in rows),'rows':rows,
        'all_input_equivalence_proved':False,'cold_qualification_performed':False,'whole_native_delivery_qualified':False}
(root/'table-reset-differential.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('rows','fixedpoint_compile_receipts')}),flush=True)
