"""Run only the approved Python/PTY/clock and relocation controls."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys
import time
import unittest

ROOT = Path('/workspace/scratch/e5ee74d2b78c/ci-integration-evidence')
MODULES = [
    'tests.test_core_seven_part04_capture',
    'tests.test_core_seven_part04_runner',
    'tests.test_core_seven_relocation_runner',
    'tests.test_core_seven_part04_deadlines',
    'tests.test_core_seven_relocation_timeout',
]
SOURCE_PATHS = ['.github/workflows/hia-initialization-frontier-research.yml',
                'tools/core_seven_part04_capture.py',
                'tools/diagnose_core_seven_part04.py',
                'tools/diagnose_core_seven_relocation.py'] + [
                    name.replace('.', '/') + '.py' for name in MODULES]

def source_hashes():
    return {name: hashlib.sha256(Path(name).read_bytes()).hexdigest()
            for name in SOURCE_PATHS}

def flatten(node):
    for item in node:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item

loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(MODULES)
ids = sorted(case.id() for case in flatten(suite))
old = json.loads(subprocess.check_output([
    'git', 'show', '164e462e6098f3a31790b8987705e7fe6592b230:'
    'review-evidence/hia-part04-deadline-20261108-e5ee/validation.json']))
added = {
    'tests.test_core_seven_relocation_runner.Part04RunnerTests.test_timeout_replay_waits_for_delayed_child_markers',
    'tests.test_core_seven_relocation_runner.Part04ReplayGrammarTests.test_fixture_timeout_clock_requires_all_persisted_markers',
    'tests.test_core_seven_relocation_runner.Part04ReplayGrammarTests.test_fixture_missing_marker_has_finite_readiness_deadline',
}
assert not loader.errors, loader.errors
assert not sys.flags.optimize
assert len(ids) == len(set(ids)) == 108
assert set(old['tests']['ids']).issubset(ids)
assert set(ids) - set(old['tests']['ids']) == added
before = source_hashes()
tree = subprocess.check_output(['git', 'write-tree']).decode().strip()
print(json.dumps({'modules': MODULES, 'ids': ids, 'source_sha256': before,
                  'fixture_tree': tree}), flush=True)
started = time.monotonic()
result = unittest.TextTestRunner(verbosity=2).run(suite)
elapsed = time.monotonic() - started
after = source_hashes()
summary = {
    'schema': 'hepta.part04-fixture-integration-tests.v1',
    'source_fixture_tree': tree,
    'parents': ['164e462e6098f3a31790b8987705e7fe6592b230',
                '39ae467a5806a9c969133e6e8801f83c96f246aa'],
    'python': sys.version,
    'platform': platform.platform(),
    'modules': MODULES,
    'expected_methods': 108,
    'tests_run': result.testsRun,
    'elapsed_seconds': round(elapsed, 6),
    'failures': [(test.id(), detail) for test, detail in result.failures],
    'errors': [(test.id(), detail) for test, detail in result.errors],
    'skipped': [(test.id(), reason) for test, reason in result.skipped],
    'expected_failures': [(test.id(), detail) for test, detail in result.expectedFailures],
    'unexpected_successes': [test.id() for test in result.unexpectedSuccesses],
    'ids': ids,
    'inventory_sha256': hashlib.sha256('\n'.join(ids).encode()).hexdigest(),
    'source_sha256_before': before,
    'source_sha256_after': after,
    'preserved_817_ids': 105,
    'additional_816_ids': sorted(added),
    'test_scope': 'Python subprocess, PTY, clocks, receipt replay and source grammar only; no Lean or native loader/compiler tests executed',
}
passed = (result.testsRun == 108 and result.wasSuccessful() and
          not result.skipped and not result.expectedFailures and
          not result.unexpectedSuccesses and before == after)
summary['status'] = 'PASS' if passed else 'FAIL'
(ROOT/'affected-tests.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'tests_run': result.testsRun,
                  'elapsed_seconds': summary['elapsed_seconds']}), flush=True)
raise SystemExit(0 if passed else 1)
