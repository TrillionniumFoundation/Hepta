"""Load and compare CI inventories without running any test methods."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import unittest
import yaml

ROOT = Path('/workspace/scratch/e5ee74d2b78c/ci-integration-evidence')
WORKFLOW = '.github/workflows/hia-initialization-frontier-research.yml'
BASE = 'ffa64c93dd4c51190fda8c0f647481a31ffbcf07'
ADDED = {
    'tests.test_core_seven_relocation_runner.Part04RunnerTests.test_timeout_replay_waits_for_delayed_child_markers',
    'tests.test_core_seven_relocation_runner.Part04ReplayGrammarTests.test_fixture_timeout_clock_requires_all_persisted_markers',
    'tests.test_core_seven_relocation_runner.Part04ReplayGrammarTests.test_fixture_missing_marker_has_finite_readiness_deadline',
}

def source(commit):
    return subprocess.check_output(['git', 'show', commit + ':' + WORKFLOW]).decode()

def block(text, job, marker):
    steps = yaml.safe_load(text)['jobs'][job]['steps']
    values = [step['run'] for step in steps if marker in step.get('run', '')]
    assert len(values) == 1
    code = values[0].split("<<'" + marker + "'\n", 1)[1].split('\n' + marker, 1)[0]
    return code

def flatten(node):
    for case in node:
        if isinstance(case, unittest.TestSuite):
            yield from flatten(case)
        else:
            yield case

def without_added(suite):
    return unittest.TestSuite(case for case in flatten(suite) if case.id() not in ADDED)

class HistoricalLoaderView(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Attribute) and node.func.attr in (
                'loadTestsFromNames', 'loadTestsFromName'):
            return ast.copy_location(ast.Call(func=ast.Name(id='without_added', ctx=ast.Load()),
                                              args=[node], keywords=[]), node)
        return node

def inventory(text, historical=False):
    code = block(text, 'declaration-diagnostic-controls', 'PYDIAG')
    code = code.split("group = os.environ['CONTROL_GROUP']", 1)[0]
    tree = ast.parse(code)
    assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                   and node.func.attr == 'run' for node in ast.walk(tree))
    if historical:
        tree = ast.fix_missing_locations(HistoricalLoaderView().visit(tree))
    scope = {'without_added': without_added}
    exec(compile(tree, '<CI inventory only>', 'exec'), scope)
    return scope

current_text = Path(WORKFLOW).read_text()
current = inventory(current_text)
old = inventory(source(BASE), historical=True)
assert len(old['all_ids']) == 709
assert len(current['all_ids']) == 712
assert set(old['all_ids']).issubset(current['all_ids'])
assert set(current['all_ids']) - set(old['all_ids']) == ADDED

# Only the relocation runner changed among historical test source modules.
# Every original method body there is unchanged; the historical view above
# removes exactly the three new IDs before running the old splitting logic.
names = sorted({name for group_names, _ in old['groups'].values() for name in group_names})
modules = sorted({'.'.join(name.split('.')[:2]) for name in names})
for module in modules:
    path = module.replace('.', '/') + '.py'
    if path == 'tests/test_core_seven_relocation_runner.py':
        prior = ast.parse(subprocess.check_output(['git', 'show', BASE + ':' + path]).decode())
        current_ast = ast.parse(Path(path).read_text())
        def methods(tree):
            return {cls.name + '.' + method.name: ast.dump(method, include_attributes=False)
                    for cls in tree.body if isinstance(cls, ast.ClassDef)
                    for method in cls.body if isinstance(method, ast.FunctionDef)
                    and method.name.startswith('test_')}
        before, after = methods(prior), methods(current_ast)
        assert all(after[name] == body for name, body in before.items())
    else:
        assert Path(path).read_bytes() == subprocess.check_output(['git', 'show', BASE + ':' + path]), path

new_code = block(current_text, 'part04-deadline-controls', 'PY')
new_code = new_code.split('result = unittest.TextTestRunner', 1)[0]
new_scope = {}
exec(compile(new_code, '<new CI inventory only>', 'exec'), new_scope)
assert set(new_scope['actual']) == set(current['deadline_ids'])
assert len(new_scope['actual']) == 11
combined = sorted(current['all_ids'] + current['deadline_ids'])
assert len(combined) == len(set(combined)) == 723

# Other old CI jobs, guards, path triggers and timeouts survive byte-for-byte
# as parsed YAML; only the two integration-owned jobs are allowed to differ.
prior_workflow = yaml.safe_load(source('164e462e6098f3a31790b8987705e7fe6592b230'))
new_workflow = yaml.safe_load(current_text)
allowed = {'declaration-diagnostic-controls', 'part04-deadline-controls'}
assert set(prior_workflow['jobs']) == set(new_workflow['jobs'])
for name, job in prior_workflow['jobs'].items():
    if name not in allowed:
        assert job == new_workflow['jobs'][name], name
for name in set(new_workflow) - {'jobs'}:
    assert new_workflow[name] == prior_workflow[name], name

summary = {
    'schema': 'hepta.part04-fixture-integration-inventory.v1',
    'status': 'PASS',
    'test_methods_executed': 0,
    'historical_count': 709,
    'historical_original_method_bodies_preserved': True,
    'historical_shard_ids': old['inventories'],
    'integrated_shard_count': 712,
    'integrated_shard_ids': current['inventories'],
    'independent_deadline_count': 11,
    'independent_deadline_ids': sorted(current['deadline_ids']),
    'combined_count': 723,
    'combined_inventory_sha256': hashlib.sha256('\n'.join(combined).encode()).hexdigest(),
    'added_816_ids': sorted(ADDED),
    'capture_methods': 41,
    'part04_runner_methods': 17,
    'relocation_runner_methods': 23,
    'other_817_jobs_and_workflow_guards_unchanged': True,
}
(ROOT/'inventory.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items()
                  if not key.endswith('_ids')}, indent=2))
