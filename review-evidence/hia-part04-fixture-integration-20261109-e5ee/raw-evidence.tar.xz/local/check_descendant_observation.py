"""Four explicit observations of one harmless, owned Python child fixture."""
from contextlib import ExitStack
from pathlib import Path
import hashlib
import json
import subprocess
import time
import unittest
from unittest.mock import patch

from tests import test_core_seven_part04_capture as harness

ROOT = Path(__file__).resolve().parent
METHOD = 'test_held_descendant_descriptors_are_killed_after_leader_exits'
SCENARIOS = ['natural', 'transient_running_observation',
             'persistent_running_observation', 'late_terminal_observation']
source_path = Path('tests/test_core_seven_part04_capture.py')
before = hashlib.sha256(source_path.read_bytes()).hexdigest()
records = []

for scenario in SCENARIOS:
    target = ROOT/('descendant-' + scenario)
    target.mkdir(exist_ok=False)
    case = harness.Part04CaptureTests(METHOD)
    real_run_child = case.run_child
    real_read_text = Path.read_text
    started = time.monotonic()
    samples = []
    call_count = [0]
    print(json.dumps({'scenario': scenario,
                      'injected_observations': scenario != 'natural'}), flush=True)
    with ExitStack() as stack:
        def run_child(*args, **kwargs):
            result, files, launches = real_run_child(*args, **kwargs)
            (target/'capture-result.json').write_text(json.dumps(result, indent=2) + '\n')
            for name, data in files.items():
                (target/name).write_bytes(data)
            child = int(files[harness.capture.DIAGNOSTIC_FILES[0]].strip())
            state_path = Path('/proc')/str(child)/'stat'

            def read_actual(path, args, kwargs):
                try:
                    return real_read_text(path, *args, **kwargs)
                except FileNotFoundError:
                    return None

            def read_text(path, *read_args, **read_kwargs):
                if path != state_path:
                    return real_read_text(path, *read_args, **read_kwargs)
                call_count[0] += 1
                raw = read_actual(path, read_args, read_kwargs)
                first_raw = raw
                delayed = scenario == 'late_terminal_observation' and call_count[0] == 1
                if delayed:
                    time.sleep(1.51)
                    raw = read_actual(path, read_args, read_kwargs)
                    assert raw is None or raw.split()[2] == 'Z', 'late control did not observe real termination'
                inject_running = (scenario == 'persistent_running_observation' or
                                  (scenario == 'transient_running_observation' and call_count[0] <= 2))
                delivered = raw
                if inject_running:
                    # Deliberately inject only a live observation. Passing still
                    # requires a later unmodified real Z or real disappearance.
                    fields = (raw or '%d (fixture) R 0 %d\n' % (child, result['pid'])).split()
                    fields[2] = 'R'
                    delivered = ' '.join(fields) + '\n'
                samples.append({'call': call_count[0], 'elapsed': time.monotonic()-started,
                                'child_pid': child, 'process_group': result['pid'],
                                'actual_raw_before_delay': first_raw,
                                'actual_raw_return_observation': raw,
                                'delivered_state': None if delivered is None else delivered.split()[2],
                                'injected_running': inject_running,
                                'injected_delay_seconds': 1.51 if delayed else 0})
                if delivered is None:
                    raise FileNotFoundError(str(path))
                return delivered

            stack.enter_context(patch.object(Path, 'read_text', read_text))
            return result, files, launches

        case.run_child = run_child
        result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
    expected_rejection = scenario in ('persistent_running_observation', 'late_terminal_observation')
    expected_reason = 'descendant exit observation exceeded the original total deadline'
    correctly_rejected = (len(result.failures) == 1 and not result.errors and
                          expected_reason in result.failures[0][1])
    passed = (correctly_rejected if expected_rejection else result.wasSuccessful())
    passed = bool(passed and result.testsRun == 1 and not result.skipped and
                  not result.expectedFailures and not result.unexpectedSuccesses)
    row = {'scenario': scenario, 'injected': scenario != 'natural',
           'expected_rejection': expected_rejection,
           'method_tests_run': result.testsRun,
           'method_failures': [(test.id(), detail) for test, detail in result.failures],
           'method_errors': [(test.id(), detail) for test, detail in result.errors],
           'method_skips': [(test.id(), reason) for test, reason in result.skipped],
           'elapsed_seconds': time.monotonic()-started,
           'observations': samples, 'control_status': 'PASS' if passed else 'FAIL'}
    (target/'observation.json').write_text(json.dumps(row, indent=2) + '\n')
    records.append(row)
    print(json.dumps({'scenario': scenario, 'expected_rejection': expected_rejection,
                      'control_status': row['control_status'], 'reads': len(samples),
                      'elapsed_seconds': row['elapsed_seconds']}), flush=True)

after = hashlib.sha256(source_path.read_bytes()).hexdigest()
production = {}
for path in ('tools/core_seven_part04_capture.py', 'tools/diagnose_core_seven_part04.py',
             'tools/diagnose_core_seven_relocation.py'):
    data = Path(path).read_bytes()
    assert data == subprocess.check_output(['git', 'show', '164e462e6098f3a31790b8987705e7fe6592b230:' + path])
    production[path] = hashlib.sha256(data).hexdigest()
summary = {'schema': 'hepta.descendant-observation-controls.v1',
           'method': 'tests.test_core_seven_part04_capture.Part04CaptureTests.' + METHOD,
           'scenarios': records,
           'same_method_invocations': 4,
           'positive_scenarios': 2,
           'expected_negative_scenarios': 2,
           'source_sha256_before': before, 'source_sha256_after': after,
           'production_817_unchanged_sha256': production,
           'original_total_test_deadline_seconds': 1.5,
           'original_108_run_replaced_or_retried': False,
           'status': 'PASS' if before == after and all(r['control_status'] == 'PASS' for r in records) else 'FAIL'}
(ROOT/'descendant-controls.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'scenarios'}), flush=True)
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
