from pathlib import Path
import subprocess,json,os,time
R=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
P=Path('/Users/qianqi/work/hia-root-unified-cold-20261127-2ac5/kernel-generic-integration-v1/source')
S=R/'builder-generation-source';Q=R/'builder-generation-integration-v1';Q.mkdir(mode=0o700)
assert not S.exists()
env=os.environ.copy();env['GIT_NO_LAZY_FETCH']='1';rows=[]
def run(label,args):
 t=time.monotonic();p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (Q/(label+'.stdout')).write_bytes(p.stdout);(Q/(label+'.stderr')).write_bytes(p.stderr)
 row={'label':label,'returncode':p.returncode,'elapsed':time.monotonic()-t,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}
 rows.append(row);print(json.dumps(row),flush=True)
 assert p.returncode==0,label
 return p.stdout.decode().strip()
head='d5f853cabeb7bed4102e2033415e699e8c100d4f'
assert run('roothead',['git','-C',str(P),'rev-parse','HEAD'])==head
run('clone',['git','clone','--shared','--no-checkout',str(P),str(S)])
objects=Path(run('objects',['git','-C',str(S),'rev-parse','--path-format=absolute','--git-path','objects']))
peer=Path(run('peerobjects',['git','-C',str(R/'dispatch-source'),'rev-parse','--path-format=absolute','--git-path','objects']))
a=objects/'info/alternates';current=a.read_text().splitlines()
if str(peer) not in current:current.append(str(peer))
a.write_text('\n'.join(current)+'\n')
run('checkout',['git','-C',str(S),'checkout','-b','codex/hia-source8-builder-generation-20261128-2ac5',head])
run('merge',['git','-C',str(S),'merge','--no-ff','2d7b63e1d30a8a42bdde49857043b3d2edbfe745','-m','Merge complete Source8 failure custody into current source-generation integration'])
assert not run('status',['git','-C',str(S),'status','--porcelain'])
result={'source':str(S),'head':run('head',['git','-C',str(S),'rev-parse','HEAD']),'tree':run('tree',['git','-C',str(S),'rev-parse','HEAD^{tree}']),'parents':run('parents',['git','-C',str(S),'show','-s','--format=%P','HEAD']).split(),'explicit_readonly_objects':a.read_text().splitlines(),'normal_merge':True}
(Q/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
