from pathlib import Path
import subprocess, os, json, hashlib, time, ast
B=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
S=B/'builder-generation-source'; Q=B/'builder-generation-integration-v1'/'baseline'; Q.mkdir(exist_ok=False)
env=dict(os.environ); env['PYTHONDONTWRITEBYTECODE']='1'
cmd=['/opt/homebrew/bin/python3.14','-B','-m','unittest','-v','tests.test_hia_current_source_generation']
t=time.monotonic()
with (Q/'tests.log').open('wb') as log:
 p=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
names=['tools/build_hia_service_bootstrap.py','tools/hia_current_source_generation.py','tests/test_hia_current_source_generation.py','hepta/hia_program_runtime_dispatch.py','tests/test_hia_program_runtime_dispatch.py','tests/hia_runtime_dispatch_source_history.py','tests/fixtures/hia_runtime_dispatch_observer_successor_v1.json','tests/fixtures/hia_current_source_generation_v1.json']
pins={n:{'bytes':len(x:=(S/n).read_bytes()),'sha256':hashlib.sha256(x).hexdigest(),'mode':oct((S/n).stat().st_mode&0o7777)} for n in names}
out={'cmd':cmd,'cwd':str(S),'returncode':p.returncode,'elapsed':time.monotonic()-t,'pins':pins}
(Q/'result.json').write_text(json.dumps(out,indent=2)+'\n')
for n in names[:3]:
 (Q/(Path(n).name+'.original')).write_bytes((S/n).read_bytes())
print(json.dumps(out,sort_keys=True))
print((Q/'tests.log').read_text())
raw=(S/names[0]).read_text()
print('BUILDER_INPUTS_START')
node=next(n for n in ast.parse(raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='INPUTS' for t in n.targets))
print(''.join(raw.splitlines(keepends=True)[node.lineno-1:node.end_lineno]))
print('BUILDER_INPUTS_END')
