from pathlib import Path
import subprocess,json,hashlib,os
B=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
S=B/'builder-generation-source'; Q=B/'builder-generation-integration-v1'/'git-provenance-v2';Q.mkdir(exist_ok=False)
name='tools/build_hia_service_bootstrap.py'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*args):return subprocess.check_output(['git',*args],cwd=S,env=env)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
log=git('log','-n','24','--format=%H','175ac187d63bc67f77c4e40a366e6dd5d2416e49','--',name).decode().splitlines()
rows=[];prior=None
for commit in log:
 raw=git('show',commit+':'+name)
 row={'commit':commit,'blob':git('rev-parse',commit+':'+name).decode().strip(),**pin(raw)}
 rows.append(row)
 if row['sha256']=='d0e5f770166ed9bfb7834ccc1834404d50b1f2b7ff4e1b6172ca113813ce03f8':
  prior=row;(Q/'prior.py.txt').write_bytes(raw);break
(Q/'examined.json').write_text(json.dumps(rows,indent=2)+'\n')
assert prior is not None,rows
assert (Q/'prior.py.txt').read_bytes()==(B/'builder-generation-integration-v1/candidate-v2/builder-prior.py.txt').read_bytes()
currentraw=git('show','175ac187d63bc67f77c4e40a366e6dd5d2416e49:'+name)
assert pin(currentraw)==pin((S/name).read_bytes())
(Q/'current.py.txt').write_bytes(currentraw)
out={'prior':prior,'current':rows[0],'complete_old_and_new_git_bytes_confirmed':True,
 'original_test_file_sha256':hashlib.sha256((S/'tests/test_hia_current_source_generation.py').read_bytes()).hexdigest(),
 'status':git('status','--short').decode()}
(Q/'result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,sort_keys=True))
