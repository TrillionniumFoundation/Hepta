from pathlib import Path
import subprocess,json,hashlib,ast
B=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
S=B/'builder-generation-source'; Q=B/'builder-generation-integration-v1'/'git-provenance';Q.mkdir(exist_ok=False)
name='tools/build_hia_service_bootstrap.py'
def git(*args):return subprocess.check_output(['git',*args],cwd=S)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
rows={}
for label,rev in [('prior','175ac187d63bc67f77c4e40a366e6dd5d2416e49^'),('current','175ac187d63bc67f77c4e40a366e6dd5d2416e49'),('root_current','d5f853cabeb7bed4102e2033415e699e8c100d4f')]:
 commit=git('rev-parse',rev).decode().strip()
 blob=git('rev-parse',commit+':'+name).decode().strip()
 raw=git('show',commit+':'+name)
 rows[label]={'commit':commit,'blob':blob,**pin(raw)}
 (Q/(label+'.py.txt')).write_bytes(raw)
assert rows['prior']['sha256']=='d0e5f770166ed9bfb7834ccc1834404d50b1f2b7ff4e1b6172ca113813ce03f8'
assert rows['current']['sha256']==rows['root_current']['sha256']=='f2ebc4b904ad8b34ff4dac8cb9268edfcb7cf71279ce217d536fbd894648dbc6'
assert (Q/'prior.py.txt').read_bytes()==(B/'builder-generation-integration-v1/candidate-v2/builder-prior.py.txt').read_bytes()
names=['tools/hia_current_source_generation.py','tools/hia_source8_builder_history.py','tests/fixtures/hia_source8_builder_successor_v1.json','tests/test_hia_source8_builder_history.py']
rows['candidate_files']={n:pin((S/n).read_bytes()) for n in names}
rows['status']=git('status','--short').decode()
(Q/'result.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,sort_keys=True))
