from pathlib import Path
from hashlib import sha256
import ast, json, difflib, subprocess
B=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
S=B/'builder-generation-source'; Q=B/'builder-generation-integration-v1'/'candidate-v2'; Q.mkdir(exist_ok=False)
builder='tools/build_hia_service_bootstrap.py'
names={
'hepta/hia_program_runtime_dispatch.py':'73c06c1a92e2028df69fe111b01b52263741ecb0bb2b4e20611292ab41cc39f4',
'tests/test_hia_program_runtime_dispatch.py':'870af530d2188d10ed6887a8ccf428b5dd0d3961986caeeeb7bdad5aa2358db3',
'tests/hia_runtime_dispatch_source_history.py':'6dbb1a3eb0f6790193335164a5992a35901d3a256be979644cd57f21fad2fa13',
'tests/fixtures/hia_runtime_dispatch_observer_successor_v1.json':'58ec792c5147a85082000a8c5f7337210a3d2fa2926d3d697acf06f74b9f7883'}
def pin(raw):return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
raw=(S/builder).read_bytes()
assert pin(raw)=={'bytes':31169,'sha256':'f2ebc4b904ad8b34ff4dac8cb9268edfcb7cf71279ce217d536fbd894648dbc6'}
prior=raw
inputs={}
for name, expected in names.items():
 item=(S/name).read_bytes(); assert sha256(item).hexdigest()==expected
 inputs[name]=pin(item)
 candidates=[("    "+quote+name+quote+",\n").encode() for quote in ("'",'"')]
 assert sum(prior.count(x) for x in candidates)==1,name
 line=next(x for x in candidates if prior.count(x)==1)
 prior=prior.replace(line,b'',1)
assert pin(prior)=={'bytes':30952,'sha256':'d0e5f770166ed9bfb7834ccc1834404d50b1f2b7ff4e1b6172ca113813ce03f8'}
assert len(raw)-len(prior)==217
hunks=[]
matcher=difflib.SequenceMatcher(None,prior,raw,autojunk=False)
for tag,a,b,c,d in matcher.get_opcodes():
 if tag!='equal':
  hunks.append({'old_offset':a,'new_offset':c,'old_hex':prior[a:b].hex(),'new_hex':raw[c:d].hex()})
relation={'schema':'hepta.hia.source8-builder-successor.v1','scope':'EXPLICIT_SOURCE8_BUILDER_SOURCE_HISTORY',
 'source_commit':'175ac187d63bc67f77c4e40a366e6dd5d2416e49',
 'files':{builder:{'old_sha256':sha256(prior).hexdigest(),'new_sha256':sha256(raw).hexdigest(),
 'old_bytes':len(prior),'new_bytes':len(raw),'hunks':hunks}},
 'introduced_inputs':inputs,'original_authorities_changed':False,'original_test_methods_changed':False,
 'current_product_execution_qualified':False}
fixture_raw=(json.dumps(relation,indent=2,sort_keys=True)+'\n').encode()
fixture=S/'tests/fixtures/hia_source8_builder_successor_v1.json'
assert not fixture.exists(); fixture.write_bytes(fixture_raw)
helper="\"\"\"A complete Source8 builder relation with physical dependency custody.\n\nThis is data-only source history. It neither executes the predecessor nor\nqualifies the current Bootstrap implementation or its performance gate.\n\"\"\"\nfrom __future__ import annotations\nfrom hashlib import sha256\nimport json\nfrom pathlib import Path\nimport stat\n\nSELF = 'tools/hia_source8_builder_history.py'\nFIXTURE = 'tests/fixtures/hia_source8_builder_successor_v1.json'\nFIXTURE_SHA256 = '@FIXTURE_SHA256@'\nENGINE = 'tools/hia_frozen_component_sources.py'\nENGINE_SHA256 = '60a30ab07d6c58ef0523531636a3250cc9e75402bffe75a07115012efa5d0774'\nBUILDER = 'tools/build_hia_service_bootstrap.py'\nCURRENT = {'bytes': 31169, 'sha256': 'f2ebc4b904ad8b34ff4dac8cb9268edfcb7cf71279ce217d536fbd894648dbc6'}\nPRIOR = {'bytes': 30952, 'sha256': 'd0e5f770166ed9bfb7834ccc1834404d50b1f2b7ff4e1b6172ca113813ce03f8'}\nINTRODUCED_INPUTS = @INTRODUCED_INPUTS@\n_SCHEMA = 'hepta.hia.source8-builder-successor.v1'\n_SCOPE = 'EXPLICIT_SOURCE8_BUILDER_SOURCE_HISTORY'\n_EXECUTED_PATH = Path(__file__).resolve(strict=True)\n_EXECUTED_SOURCE = _EXECUTED_PATH.read_bytes()\n\n\ndef pin(raw):\n    if type(raw) is not bytes:\n        raise ValueError('Source8 builder history needs complete immutable bytes')\n    return {'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}\n\n\ndef _pairs(rows):\n    answer = {}\n    for key, value in rows:\n        if key in answer:\n            raise ValueError('duplicate Source8 builder history field')\n        answer[key] = value\n    return answer\n\n\ndef _name(root, path):\n    path = Path(path)\n    if not path.is_absolute():\n        path = root / path\n    try:\n        name = path.relative_to(root).as_posix()\n    except ValueError:\n        raise ValueError('Source8 builder history path escapes its root') from None\n    if (name in ('', '.') or any(p in ('', '.', '..', '.git') for p in name.split('/'))\n            or root / name != path):\n        raise ValueError('Source8 builder history path is not canonical')\n    return path, name\n\n\ndef _stamp(value):\n    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink,\n            value.st_size, value.st_mtime_ns, value.st_ctime_ns)\n\n\nclass BuilderHistory:\n    def __init__(self, root, take):\n        self.root = Path(root).resolve(strict=True)\n        self.take = take\n        self.captures = {}\n        self._initial = {}\n        self.prior_sources = {}\n        self._prior = {}\n        self._inventory = ()\n\n    def capture(self, path):\n        path, name = _name(self.root, path)\n        cursor = path\n        while cursor != self.root:\n            if stat.S_ISLNK(cursor.lstat().st_mode):\n                raise ValueError('Source8 builder history input uses a symlink: ' + name)\n            cursor = cursor.parent\n        before = path.lstat()\n        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:\n            raise ValueError('Source8 builder history needs an owned regular file: ' + name)\n        raw = self.take(path)\n        pin(raw)\n        if path.read_bytes() != raw or _stamp(before) != _stamp(path.lstat()):\n            raise ValueError('Source8 builder capture differs from actual bytes: ' + name)\n        value = (raw, stat.S_IMODE(before.st_mode))\n        if name in self._initial and self._initial[name] != value:\n            raise ValueError('Source8 builder physical input changed: ' + name)\n        if name in self.captures and self.captures[name] != raw:\n            raise ValueError('Source8 builder physical capture was rewritten: ' + name)\n        self._initial[name] = value\n        self.captures[name] = raw\n        return raw\n\n    def prior_take(self, path):\n        path, name = _name(self.root, path)\n        verify_unchanged(self)\n        actual = self.capture(path)\n        return self._prior.get(name, actual)\n\n    def review(self):\n        verify_unchanged(self)\n        return {\n            'schema': 'hepta.hia.source8-builder-review.v1',\n            'scope': _SCOPE,\n            'physical_root': str(self.root),\n            'actual_builder': pin(self.captures[BUILDER]),\n            'explicit_prior_builder': pin(self._prior[BUILDER]),\n            'introduced_inputs': {n: pin(self.captures[n]) for n in INTRODUCED_INPUTS},\n            'complete_physical_sources': {\n                n: {**pin(raw), 'mode': mode}\n                for n, (raw, mode) in sorted(self._initial.items())},\n            'full_inverse_and_forward_replay': True,\n            'physical_capture_rewritten': False,\n            'prior_projection_is_physical_source': False,\n            'current_product_execution_qualified': False,\n        }\n\n\ndef prepare(root, supplied, *, take=Path.read_bytes):\n    if type(supplied) is not dict or set(supplied) != {BUILDER}:\n        raise ValueError('Source8 builder history accepts only its complete builder')\n    if pin(supplied[BUILDER]) != CURRENT:\n        raise ValueError('unreviewed Source8 builder history argument')\n    h = BuilderHistory(root, take)\n    if (h.capture(h.root / SELF) != _EXECUTED_SOURCE\n            or _EXECUTED_PATH.read_bytes() != _EXECUTED_SOURCE):\n        raise ValueError('Source8 builder executing reader differs')\n    frozen = h.capture(h.root / FIXTURE)\n    if sha256(frozen).hexdigest() != FIXTURE_SHA256:\n        raise ValueError('Source8 builder immutable relation differs')\n    relation = json.loads(frozen, object_pairs_hook=_pairs)\n    if (type(relation) is not dict or set(relation) != {\n            'schema', 'scope', 'source_commit', 'files', 'introduced_inputs',\n            'original_authorities_changed', 'original_test_methods_changed',\n            'current_product_execution_qualified'}\n            or relation['schema'] != _SCHEMA or relation['scope'] != _SCOPE\n            or relation['source_commit'] != '175ac187d63bc67f77c4e40a366e6dd5d2416e49'\n            or set(relation['files']) != {BUILDER}\n            or relation['introduced_inputs'] != INTRODUCED_INPUTS\n            or relation['original_authorities_changed'] is not False\n            or relation['original_test_methods_changed'] is not False\n            or relation['current_product_execution_qualified'] is not False):\n        raise ValueError('Source8 builder immutable relation domain differs')\n    engine_raw = h.capture(h.root / ENGINE)\n    if sha256(engine_raw).hexdigest() != ENGINE_SHA256:\n        raise ValueError('Source8 builder frozen inverse engine differs')\n    from tools import hia_frozen_component_sources as engine\n    if Path(engine.__file__).read_bytes() != engine_raw:\n        raise ValueError('Source8 builder imported another inverse engine')\n    actual = h.capture(h.root / BUILDER)\n    if actual != supplied[BUILDER] or pin(actual) != CURRENT:\n        raise ValueError('Source8 builder argument is not its physical capture')\n    for name, expected in INTRODUCED_INPUTS.items():\n        if pin(h.capture(h.root / name)) != expected:\n            raise ValueError('Source8 builder dependency differs: ' + name)\n    h.prior_sources[BUILDER] = engine.history_inverse(\n        actual, relation['files'][BUILDER], PRIOR)\n    h._prior = dict(h.prior_sources)\n    h._inventory = tuple(sorted(h._initial))\n    verify_unchanged(h)\n    return dict(h.prior_sources), h\n\n\ndef verify_unchanged(history):\n    if (type(history) is not BuilderHistory\n            or history.prior_sources != history._prior\n            or set(history._prior) != {BUILDER}\n            or pin(history._prior[BUILDER]) != PRIOR\n            or tuple(sorted(history._initial)) != history._inventory\n            or history.captures != {n: row[0] for n, row in history._initial.items()}\n            or _EXECUTED_PATH.read_bytes() != _EXECUTED_SOURCE):\n        raise ValueError('Source8 builder actual or prior custody changed')\n    for name in history._inventory:\n        history.capture(history.root / name)\n    if (pin(history.captures[BUILDER]) != CURRENT\n            or history.captures[SELF] != _EXECUTED_SOURCE\n            or sha256(history.captures[FIXTURE]).hexdigest() != FIXTURE_SHA256\n            or sha256(history.captures[ENGINE]).hexdigest() != ENGINE_SHA256\n            or any(pin(history.captures[n]) != expected\n                   for n, expected in INTRODUCED_INPUTS.items())):\n        raise ValueError('Source8 builder terminal identities differ')\n"
helper=helper.replace('@FIXTURE_SHA256@',sha256(fixture_raw).hexdigest()).replace('@INTRODUCED_INPUTS@',repr(inputs))
assert '@FIXTURE' not in helper and '@INTRODUCED' not in helper
helper_path=S/'tools/hia_source8_builder_history.py'; assert not helper_path.exists()
helper_path.write_text(helper)
name='tools/hia_current_source_generation.py'; before=(S/name).read_text(); current=before
def replace(old,new):
 global current
 assert current.count(old)==1,(old[:100],current.count(old))
 current=current.replace(old,new,1)
replace("CHANGED_INPUTS = (SERVICE, REGISTRY, BUILDER, VERIFICATION_TEST)\n",
"CHANGED_INPUTS = (SERVICE, REGISTRY, BUILDER, VERIFICATION_TEST)\n"
"SOURCE8_BUILDER = {'bytes': 31169, 'sha256': 'f2ebc4b904ad8b34ff4dac8cb9268edfcb7cf71279ce217d536fbd894648dbc6'}\n"
"SOURCE8_BUILDER_READER = 'tools/hia_source8_builder_history.py'\n"
"SOURCE8_BUILDER_READER_SHA256 = '"+sha256(helper.encode()).hexdigest()+"'\n")
replace("        self.project_reader = False\n","        self.project_reader = False\n        self.source8_builder_history = None\n")
replace("            'reader_projected_for_original_source_controls': self.project_reader,\n",
"            'reader_projected_for_original_source_controls': self.project_reader,\n"
"            'source8_builder_history': (self.source8_builder_history.review()\n"
"                if self.source8_builder_history is not None else None),\n")
replace("    for name in CHANGED_INPUTS:\n        raw = h.capture(h.root / name)\n        if pin(raw) != CURRENT[name]:\n",
"    for name in CHANGED_INPUTS:\n"
"        raw = h.capture(h.root / name)\n"
"        if name == BUILDER and pin(raw) == SOURCE8_BUILDER:\n"
"            reader_raw = h.capture(h.root / SOURCE8_BUILDER_READER)\n"
"            if sha256(reader_raw).hexdigest() != SOURCE8_BUILDER_READER_SHA256:\n"
"                raise ValueError('source generation Source8 builder reader differs')\n"
"            from tools import hia_source8_builder_history as source8\n"
"            if Path(source8.__file__).read_bytes() != reader_raw:\n"
"                raise ValueError('source generation imported another Source8 builder reader')\n"
"            projected, h.source8_builder_history = source8.prepare(\n"
"                h.root, {BUILDER: raw}, take=h.capture)\n"
"            raw = projected[BUILDER]\n"
"        if pin(raw) != CURRENT[name]:\n")
replace("    for name, expected in PRIOR.items():\n        raw = h.capture(h.root / name)\n",
"    for name, expected in PRIOR.items():\n"
"        raw = (h.source8_builder_history.prior_take(h.root / name)\n"
"               if name == BUILDER and h.source8_builder_history is not None\n"
"               else h.capture(h.root / name))\n")
replace("    if history.bootstrap_saved is not None:\n",
"    if history.source8_builder_history is not None:\n"
"        from tools import hia_source8_builder_history as source8\n"
"        source8.verify_unchanged(history.source8_builder_history)\n"
"    elif pin(history.captures[BUILDER]) == SOURCE8_BUILDER:\n"
"        raise ValueError('source generation lost its explicit Source8 builder history')\n"
"    if history.bootstrap_saved is not None:\n")
replace("    direct = any(name in CURRENT and pin(raw) == CURRENT[name]\n                 for name, raw in supplied.items())\n",
"    direct = any((name in CURRENT and pin(raw) == CURRENT[name])\n"
"                 or (name == BUILDER and pin(raw) == SOURCE8_BUILDER)\n"
"                 for name, raw in supplied.items())\n")
def definitions(raw):
 return {t.id:ast.dump(n.value,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name)}
a,b=definitions(before),definitions(current)
for key in ('CURRENT','PRIOR','FIXTURE','FIXTURE_SHA256','ENGINE','ENGINE_SHA256','CHANGED_INPUTS'):
 assert a[key]==b[key],key
(S/name).write_text(current)
assert (S/'tests/test_hia_current_source_generation.py').read_bytes()==(B/'builder-generation-integration-v1/baseline/test_hia_current_source_generation.py.original').read_bytes()
assert sha256((S/'tests/fixtures/hia_current_source_generation_v1.json').read_bytes()).hexdigest()=='0f425262209c2408a387c00bae2d6698cbfaa614e90c9ad4401e5857cf743467'
(Q/'builder-prior.py.txt').write_bytes(prior)
(Q/'builder-current.py.txt').write_bytes(raw)
(Q/'generation.before.py.txt').write_text(before)
(Q/'generation.after.py.txt').write_text(current)
(Q/'diff.patch').write_bytes(subprocess.check_output(['git','diff','--','tools/hia_current_source_generation.py'],cwd=S))
report={'new_inputs':inputs,'fixture':pin(fixture_raw),'helper':pin(helper.encode()),'generation_before':pin(before.encode()),
 'generation_after':pin(current.encode()),'builder_before':pin(prior),'builder_after':pin(raw),'hunks':len(hunks),
 'original_constants_ast_unchanged':True,'original_current10_file_unchanged':True,'original_fixture_unchanged':True}
(Q/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,sort_keys=True))
