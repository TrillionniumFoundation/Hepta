(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (ite (bvule abi_word_1 abi_word_0)
                (ite (= abi_word_0 abi_word_1) abi_word_1 abi_word_0)
                (bvadd #x0000000000000001
                       (ite (= abi_word_0 abi_word_1) abi_word_1 abi_word_0))))
      (a!2 (ite (not (bvule abi_word_1 abi_word_0))
                (bvadd #x0000000000000001
                       (ite (= abi_word_0 abi_word_1) abi_word_1 abi_word_0))
                #x0000000000000000))
      (a!4 (ite (bvule abi_word_1 abi_word_0)
                initial_caller_bytes
                (ite (not (bvule abi_word_1 abi_word_0))
                     initial_caller_bytes
                     initial_caller_bytes))))
(let ((a!3 (distinct (ite true a!1 #x0000000000000000)
                     (ite (bvule abi_word_1 abi_word_0)
                          (ite (= abi_word_0 abi_word_1) abi_word_1 abi_word_0)
                          a!2))))
  (or (distinct (or false) (or false))
      (and (not (or false)) a!3)
      (distinct (ite true initial_caller_bytes initial_caller_bytes) a!4)))))

(check-sat)
