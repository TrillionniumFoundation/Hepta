import json
import os
from pathlib import Path
report = json.loads((Path(os.environ['RUNNER_TEMP']) / 'hia-sixgap/original-select-strict/qualification.json').read_text())
assert report['status'] == 'HOLD_REAL_DELTA_STRICT_GATE'
assert report['worker_calls'] == 20
assert report['evaluation_response']['error']['code'] == 'E_HIA_CLAIM_REQUIRED'
assert not report['adoption_attempted'] and not report['adoption_authorized']
assert report['empty_slot_count'] == report['empty_lease_count'] == 0
assert report['same_core_substitution'] is False and report['strict_claims_weakened'] is False
assert report['canonical_subjects']['original']['sha256'] != report['canonical_subjects']['candidate']['sha256']
print('Strict refusal reproduced; original-delta proof/evaluation/adoption acceptance remains HOLD.')
