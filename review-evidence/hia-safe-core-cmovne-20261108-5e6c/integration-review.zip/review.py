"""Read-only integration review; no compiler, linker, or native subject execution."""
from pathlib import Path
from hashlib import sha256
import ast
import json
import os
import re
import subprocess
import sys
import zipfile

import yaml

BASE = Path('/workspace/scratch/5e6c25ac6d7b')
ROOT = BASE / 'hepta-core'
OUT = Path(__file__).resolve().parent
PYTHON = BASE / 'cmovne-venv/bin/python'
WORKFLOW = '.github/workflows/hia-sixgap-source.yml'
NAMES = [WORKFLOW, 'tools/hia_release.py', 'tests/test_hia_release.py',
    'docs/HIA_SELFHOST_CORE_SUPPORT.json', 'hepta/hia_safe_core_x64.py',
    'tools/qualify_hia_safe_core_cmovne.py', 'tools/hia_safe_core_cmovne_child.py',
    'tests/test_hia_safe_core_cmovne.py', 'docs/HIA_SAFE_CORE_CMOVNE_20261108.md']
before = {p: sha256((ROOT / p).read_bytes()).hexdigest() for p in NAMES}
workflow = yaml.load((ROOT / WORKFLOW).read_text(), Loader=yaml.BaseLoader)
job = workflow['jobs']['source-closure']
assert job['env']['HEPTA_SOURCE_SHA'] == '${{ github.sha }}'
assert job['steps'][0]['with']['ref'] == '${{ env.HEPTA_SOURCE_SHA }}'
steps = {step['name']: step for step in job['steps'] if 'name' in step}
cmov = steps['Validate exact CMOVNE leaf subjects and retain all counterexamples']['run']
strict = steps['Recheck the real original select delta and preserve strict rejection']['run']
methods = re.findall(r'tests\.test_hia_safe_core_cmovne\.CmovneLeafTests\.([A-Za-z_]+)', cmov)
assert methods == ['test_all_register_fields_include_rex_extensions_and_aliases',
    'test_unreviewed_forms_fail_even_when_unreachable', 'test_branch_cannot_enter_a_cmov_operand']
assert cmov.count('python -B tools/qualify_hia_safe_core_cmovne.py') == 1
assert '--output "$RUNNER_TEMP/hia-sixgap/cmovne-leaf"' in cmov
assert '--output "$RUNNER_TEMP/hia-sixgap/original-select-strict"' in strict
assert 'set -euo pipefail' in cmov and 'set -euo pipefail' in strict
test_tree = ast.parse((ROOT / 'tests/test_hia_safe_core_cmovne.py').read_bytes())
class_node = next(n for n in test_tree.body if isinstance(n, ast.ClassDef) and n.name == 'CmovneLeafTests')
assert set(methods) <= {n.name for n in class_node.body if isinstance(n, ast.FunctionDef)}

def python_blocks(run):
    lines = run.splitlines()
    result = []
    for at, line in enumerate(lines):
        if "python -B - <<'PY'" in line:
            end = lines.index('PY', at + 1)
            body = '\n'.join(lines[at + 1:end]) + '\n'
            compile(body, '<workflow-python>', 'exec')
            result.append(body)
    return result

shell_runs = python_count = 0
syntax_log = []
for step in job['steps']:
    if 'run' not in step:
        continue
    shell_runs += 1
    checked = subprocess.run(['bash', '-n'], input=step['run'], text=True, capture_output=True)
    assert checked.returncode == 0, (step.get('name'), checked.stderr)
    python_count += len(python_blocks(step['run']))
    syntax_log.append({'step': step.get('name'), 'bash_syntax_returncode': checked.returncode})

release_ast = ast.parse((ROOT / 'tools/hia_release.py').read_bytes())
candidate = next(ast.literal_eval(n.value) for n in release_ast.body if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == 'CANDIDATE_FILES' for t in n.targets))
directories = next(ast.literal_eval(n.value) for n in release_ast.body if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == 'SOURCE_DIRECTORIES' for t in n.targets))
new_paths = ['tools/qualify_hia_safe_core_cmovne.py', 'tools/hia_safe_core_cmovne_child.py',
             'tests/test_hia_safe_core_cmovne.py', 'docs/HIA_SAFE_CORE_CMOVNE_20261108.md']
release_test_ast = ast.parse((ROOT / 'tests/test_hia_release.py').read_bytes())
inventory_test = next(n for n in ast.walk(release_test_ast) if isinstance(n, ast.FunctionDef)
    and n.name == 'test_repository_trial_inputs_and_proof_scope_cannot_disappear_from_inventory')
test_literals = {n.value for n in ast.walk(inventory_test) if isinstance(n, ast.Constant) and isinstance(n.value, str)}
assert set(new_paths) <= set(candidate) and set(new_paths) <= test_literals
assert all(any(p.startswith(d + '/') for d in directories) for p in new_paths)
contract = json.loads((ROOT / 'docs/HIA_SELFHOST_CORE_SUPPORT.json').read_text())
source = contract['source_identity']['files']
assert source['hepta/hia_safe_core_x64.py'] == before['hepta/hia_safe_core_x64.py']
assert all(sha256((ROOT / p).read_bytes()).hexdigest() == digest for p, digest in source.items())

extract = python_blocks(strict)[0]
fixtures_node = next(n for n in ast.parse(extract).body if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == 'fixtures' for t in n.targets))
fixtures = ast.literal_eval(fixtures_node.value)
archive = ROOT / 'review-evidence/hia-agent-original-select-delta-20261108-5e6c/raw-evidence.zip'
assert sha256(archive.read_bytes()).hexdigest() == '0b18f5665657601141ada5fe67990ee192d91665eb5463f806b495d6240a2d3a'
with zipfile.ZipFile(archive) as z:
    for name, digest in fixtures.items():
        assert sha256(z.read('installed-source/frozen-inputs/' + name)).hexdigest() == digest

runtime = OUT / 'assert-runtime'
group = runtime / 'hia-sixgap'
group.mkdir(parents=True)
report_dirs = {
    'cmovne-leaf': BASE / 'root-cmovne-integrated-v13-02',
    'original-select-strict': BASE / 'root-original-select-strict-v13-03',
}
assertions = {'cmovne-leaf': python_blocks(cmov)[0], 'original-select-strict': python_blocks(strict)[1]}
records = {}
for name, directory in report_dirs.items():
    (group / name).symlink_to(directory, target_is_directory=True)
    script = OUT / (name + '-workflow-assertions.py')
    script.write_text(assertions[name])
    process = subprocess.run([str(PYTHON), '-B', str(script)], cwd=ROOT, text=True,
        capture_output=True, env={**os.environ, 'RUNNER_TEMP': str(runtime)})
    (OUT / (name + '-assertions.stdout.log')).write_text(process.stdout)
    (OUT / (name + '-assertions.stderr.log')).write_text(process.stderr)
    assert process.returncode == 0, (name, process.stdout, process.stderr)
    raw = (directory / 'qualification.json').read_bytes()
    records[name] = {'report_path': str(directory / 'qualification.json'),
        'report_sha256': sha256(raw).hexdigest(), 'assertions_sha256': sha256(script.read_bytes()).hexdigest(),
        'assertions_returncode': process.returncode, 'report_status': json.loads(raw)['status']}

upload = next(step for step in job['steps'] if step.get('uses', '').startswith('actions/upload-artifact@'))
assert upload['if'] == 'always()' and '${{ runner.temp }}/hia-sixgap/' in upload['with']['path']
assert 'cmovne' not in '\n'.join(s for s in upload['with']['path'].splitlines() if s.startswith('!'))
log = (OUT / 'release-lock-boundaries.log').read_text()
assert re.search(r'Ran 14 tests in .*\n\nOK\n', log) and log.count(' ... ok\n') == 14
after = {p: sha256((ROOT / p).read_bytes()).hexdigest() for p in NAMES}
assert before == after
summary = {'schema': 'hepta.hia.cmovne-integration-readonly-review.v1', 'status': 'PASS',
    'root': str(ROOT), 'source_identity': before, 'reviewed_sources_unchanged': True,
    'release_lock_boundaries': {'passed': 14, 'total': 14, 'python': str(PYTHON),
        'command': [str(PYTHON), '-B', '-m', 'unittest', 'tests.test_hia_release.ReleaseLockBoundaries', '-v'],
        'log_sha256': sha256((OUT / 'release-lock-boundaries.log').read_bytes()).hexdigest()},
    'workflow_yaml_parsed': True, 'shell_runs_syntax_checked': shell_runs,
    'embedded_python_blocks_compiled': python_count, 'shell_syntax': syntax_log,
    'cmovne_decoder_test_methods': methods, 'retained_cmovne_cli_invocations': 1,
    'candidate_inventory_and_existing_refusal_test_paths': new_paths,
    'support_contract_files_checked': len(source), 'retained_report_assertion_replays': records,
    'actual_original_select_fixture_sha256': fixtures, 'artifact_always_retains_cmovne_reports': True,
    'new_native_or_compiler_executions': 0, 'new_cold_or_language_qualifications': 0,
    'changes_to_root_source': False, 'whole_compiler_or_original_agent_delta_proved': False,
    'original_agent_four_claim_gate': 'HOLD'}
(OUT / 'review.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: summary[k] for k in ['status', 'release_lock_boundaries',
    'shell_runs_syntax_checked', 'embedded_python_blocks_compiled',
    'support_contract_files_checked', 'new_native_or_compiler_executions']}, sort_keys=True))
