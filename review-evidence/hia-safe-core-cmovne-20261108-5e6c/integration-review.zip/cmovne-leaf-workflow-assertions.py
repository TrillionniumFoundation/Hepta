import json
import os
from pathlib import Path
root = Path(os.environ['RUNNER_TEMP']) / 'hia-sixgap/cmovne-leaf'
report = json.loads((root / 'qualification.json').read_text())
assert report['status'] == 'PASS'
assert report['counts'] == {'smt_validated': 13, 'refuted': 6, 'unsupported': 3,
    'native_calls': 492, 'decoded_register_combinations': 256, 'decoder_refusals': 17}
assert report['original_agent_four_claim_gate'] == 'HOLD'
assert report['whole_compiler_or_original_agent_delta_proved'] is False
assert report['hardware_isa_refinement_proved'] is False
for case in report['cases']:
    proof = json.loads((root / case['id'] / 'validation.json').read_text())
    if case['expected'] == 'smt_validated':
        assert [ob['result'] for ob in proof['obligations']] == ['sat', 'unsat', 'unsat', 'unsat', 'unsat']
        assert all(key in proof for key in ('subject', 'property', 'profile', 'assumptions', 'checker', 'unproved_obligations'))
    else:
        assert case['native_calls'] == 0
        if case['expected'] == 'refuted':
            assert proof['validation']['ok'] is False
            assert proof['validation']['obligations'][-1]['result'] == 'sat'
        else:
            assert proof['proof_issued'] is False
print('Exact CMOVNE leaf model qualified; whole-compiler and original-task proof gates remain HOLD.')
