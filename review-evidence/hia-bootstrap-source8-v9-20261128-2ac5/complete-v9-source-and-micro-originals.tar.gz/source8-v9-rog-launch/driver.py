from pathlib import Path
import subprocess,os,time,json,hashlib,platform,stat,sys
R=Path("/home/qian-qi/hia-bootstrap-vm-dispatch-v9-20261128-2ac5")
S=R/"source";Q=R/"source8-v9-v1";Q.mkdir(mode=0o700)
tmp=R/"source8-tmp-v9-v1";tmp.mkdir(mode=0o700)
python="/usr/bin/python3";head="175ac187d63bc67f77c4e40a366e6dd5d2416e49"
env={k:v for k,v in os.environ.items() if not k.startswith(("HEPTA_HIA_","PYTHON"))};env["TMPDIR"]=str(tmp)
def git(*args):return subprocess.run(["git","-C",str(S),*args],capture_output=True,check=True).stdout
manifest_raw=(R/"incoming/source-manifest.json").read_bytes()
assert hashlib.sha256(manifest_raw).hexdigest()=="0a3a5caa99e9a5be2f0114820cb15b4179a0ee087647b6fdcc6c3301cb2dc288"
manifest=json.loads(manifest_raw);assert manifest["head"]==head
def capture():
 assert git("rev-parse","HEAD").decode().strip()==head and not git("status","--porcelain").strip()
 assert not (S/".git/objects/info/alternates").exists()
 tracked={row.split(b"\t",1)[1].decode() for row in git("ls-tree","-rz","--full-tree",head).split(b"\0") if row}
 assert tracked=={row["path"] for row in manifest["files"]}
 for row in manifest["files"]:
  p=S/row["path"];a=p.lstat();raw=p.read_bytes();z=p.lstat()
  assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and stat.S_IMODE(a.st_mode)==row["mode"],row["path"]
  assert all(getattr(a,k)==getattr(z,k) for k in ("st_dev","st_ino","st_size","st_mode","st_mtime_ns","st_ctime_ns")),row["path"]
  assert len(raw)==row["bytes"] and hashlib.sha256(raw).hexdigest()==row["sha256"],row["path"]
  assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==row["git_blob"],row["path"]
 return {"head":head,"tree":manifest["tree"],"files":len(manifest["files"]),"bytes":sum(r["bytes"] for r in manifest["files"]),"manifest_sha256":hashlib.sha256(manifest_raw).hexdigest()}
before=capture();(Q/"source-before.json").write_text(json.dumps(before,sort_keys=True,indent=2)+"\n")
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>6<<30
check=subprocess.run([python,"-I","-B","-c","import sys,json,platform,gc,os;print(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'gc_enabled':gc.isenabled(),'gc_threshold':gc.get_threshold(),'load':os.getloadavg()}))"],capture_output=True,check=True,env=env)
(Q/"interpreter.json").write_bytes(check.stdout)
cmd=[python,"-I","-B",str(S/"tools/qualify_hia_service_bootstrap.py"),"--suite","source","--output",str(Q/"source8")]
beg=time.monotonic()
with (Q/"source8.stdout").open("xb") as out,(Q/"source8.stderr").open("xb") as err:
 p=subprocess.Popen(cmd,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
 intent={"source":head,"tree":manifest["tree"],"pid":p.pid,"pgid":os.getpgid(p.pid),"command":cmd,
 "original_outer_seconds":1800,"cleanup_seconds":3,"TMPDIR":str(tmp),"all_original_source_methods":8,
 "observer_protocol":"CASE_LOCAL_COLLECTION_THEN_NATURAL_PROCESS_EXIT","input_storage":"IMMUTABLE_FULL_CANONICAL_CASE_BYTES",
 "vm_dispatch":"EXPLICIT_SOURCE_VERIFIED_STATIC_OPCODE_METADATA_WITH_DYNAMIC_FALLBACK",
 "original_runtime_sha256":"76f184195ffc37dab2e327a2170e0999aa51349b9e1f62475084719d675686f4",
 "original_test_bodies_unchanged":True,"original_input_records":232,"complete_qualification_cases":15830,
 "native_execution":False,"actual_host":"rog","source_manifest_sha256":hashlib.sha256(manifest_raw).hexdigest(),
 "child_cleanup":"INVOCATION_NONCE_PIDFD_AND_TEMPORARY_SUBREAPER","launch_time_ns":time.time_ns()}
 (Q/"source8.start.json").write_text(json.dumps(intent,sort_keys=True,indent=2)+"\n")
 print(json.dumps(intent,sort_keys=True),flush=True)
 rc=p.wait()
terminal={**intent,"returncode":rc,"elapsed_seconds":time.monotonic()-beg,"terminal_time_ns":time.time_ns()}
for name in ("stdout","stderr"):
 raw=(Q/("source8."+name)).read_bytes();terminal[name]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
after=capture();(Q/"source-after.json").write_text(json.dumps(after,sort_keys=True,indent=2)+"\n")
terminal["source_before"]=before;terminal["source_after"]=after;terminal["source_unchanged"]=before==after
tree_receipt=Q/"source8/suite.tree-terminal.json"
if tree_receipt.is_file():
 raw=tree_receipt.read_bytes();terminal["owned_tree_terminal"]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"record":json.loads(raw)}
report=Q/"source8/suite/report.json"
if report.exists():
 value=json.loads(report.read_bytes());terminal["suite"]={k:value.get(k) for k in ("status","run","failures","errors","skips","method_statuses","component_evidence")}
(Q/"source8.terminal.json").write_text(json.dumps(terminal,sort_keys=True,indent=2)+"\n");print(json.dumps(terminal,sort_keys=True),flush=True)
raise SystemExit(rc or not terminal["source_unchanged"])
