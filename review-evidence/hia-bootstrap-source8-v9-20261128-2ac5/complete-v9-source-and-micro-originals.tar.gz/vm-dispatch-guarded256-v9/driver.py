from pathlib import Path
import sys,os,json,hashlib,time,gc,resource,importlib.util
q=Path(sys.argv[1]);lane=sys.argv[2];selection=sys.argv[3];count=int(sys.argv[4])
root=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5/dispatch-source')
out=q/(lane+'-'+selection+'-'+str(count));out.mkdir(exist_ok=False)
for k in list(os.environ):
 if k.startswith('HEPTA_HIA_'):del os.environ[k]
sys.path.insert(0,str(root))
from tests import hia_service_bootstrap_observer as obs
from hepta import hia_program_runtime as runtime
from hepta import hia_program_runtime_prepared as prepared
import ctypes
raw=(q/'complete-inputs.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='0e94dda78d7e70caf0b30a06fb685485d5a0c2b17f8e641a24ebfed9bb0dcd70'
values=json.loads(raw)['cases'];assert len(values)==15830
indices=list(range(count)) if selection=='prefix' else [i*(len(values)-1)//(count-1) for i in range(count)]
assert len(set(indices))==count
cases=obs.CaseBytes([values[i] for i in indices]);del values
runtime_path=root/'hepta/hia_program_runtime.py';before=runtime_path.read_bytes()
assert hashlib.sha256(before).hexdigest()=='76f184195ffc37dab2e327a2170e0999aa51349b9e1f62475084719d675686f4'
stats=(out/'machine-counters.jsonl').open('wb')
candidate=None
if lane=='decoded':
 from hepta import hia_program_runtime_dispatch as candidate
class Entry:
 def __init__(self,program):
  self.program,self.calls=program,0
  self.plan=None if candidate is None else candidate.prepare_runtime_dispatch(program)
 def __call__(self,source,size,output,capacity,state,extent):
  raw=ctypes.string_at(source,size)
  owners=[runtime._Owner(i+1,bytearray(data)) for i,data in enumerate((raw,ctypes.string_at(output,capacity),ctypes.string_at(state,extent)))]
  machine=(runtime._Machine(self.program,4_000_000,16<<20,None,128) if candidate is None else
           candidate.fresh_machine(self.program,(4_000_000,16<<20,None,128),self.plan))
  code=machine.invoke(machine.functions['f0'],[runtime._View(owner,i!=0) for i,owner in enumerate(owners)])[0]
  assert bytes(owners[0].data)==raw
  ctypes.memmove(output,bytes(owners[1].data),capacity);ctypes.memmove(state,bytes(owners[2].data),extent)
  summary={k:v for k,v in vars(machine).items() if type(v) in (int,bool,str,float,type(None))}
  stats.write(obs.oracle.canonical(summary)+b'\n')
  self.calls+=1
  return code
obs.VMEntry=Entry
if lane=='unselected':
 backend=obs.UnselectedBackend(compatibility=True)
elif lane=='original':
 backend=None
else:
 backend=obs.Backend('vm',None,compatibility=True)
 if candidate is not None:
  (out/'ast-relations.json').write_text(json.dumps({'relations':[dict(x) for x in backend.image._entry.plan.relations],'instruction_count':backend.image._entry.plan.instruction_count,'handlers':len(backend.image._entry.plan.relations),'generic_program_metadata':True},indent=2)+'\n')
intent={'source':str(root),'source_sha256':hashlib.sha256(before).hexdigest(),'input_sha256':hashlib.sha256(raw).hexdigest(),'indices':indices,'lane':lane,'gc_enabled':gc.isenabled(),'gc_thresholds':gc.get_threshold(),'python':sys.version,'pid':os.getpid(),'load':os.getloadavg(),'diagnostic_only':True,'full_source8_qualified':False,'unprofiled':True}
(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
start=time.monotonic();cpu=time.process_time()
with (out/'observations.jsonl').open('wb') as observations,(out/'late.jsonl').open('wb') as late,(out/'tracebacks.jsonl').open('wb') as traces,(out/'case-terminals.jsonl').open('wb') as terminals:
 for case in cases:
  boundary=obs.CaseTerminal(case)
  if backend is None:
   actual,trace=obs.oracle.observe(case,retain_world=boundary.retain)
  else:
   functions,namespace,captured_builtins=backend.select(case)
   actual,trace=obs.oracle.observe(case,functions=functions,namespace=namespace,captured_builtins=captured_builtins,retain_world=boundary.retain)
  encoded,frozen=obs.seal_record(actual,lambda row:late.write(obs.oracle.canonical(row)+b'\n'))
  observations.write(encoded+b'\n');traces.write(obs.oracle.canonical(trace)+b'\n')
  terminal=boundary.finish();terminals.write(obs.oracle.canonical(terminal)+b'\n')
  del actual,trace,frozen
elapsed=time.monotonic()-start;used=time.process_time()-cpu;stats.close()
assert runtime_path.read_bytes()==before
entries=0 if backend is None else backend.image._entry.calls
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.iterdir() if p.is_file()}
result={'status':'COMPLETE_DIAGNOSTIC','elapsed_seconds':elapsed,'process_cpu_seconds':used,'cases':count,'entries':entries,'full_collections':count,'source_unchanged':True,'gc_enabled':gc.isenabled(),'gc_thresholds':gc.get_threshold(),'files':files,'unprofiled':True,'diagnostic_only':True}
(out/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
