from pathlib import Path
import hashlib,json,ast,subprocess,os,time
B=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
S=B/'builder-generation-source';Q=B/'builder-generation-integration-terminal-v2'/'candidate-controls-v2';Q.mkdir(exist_ok=False)
helper_path=S/'tools/hia_source8_builder_history.py'
before=helper_path.read_text();assert hashlib.sha256(before.encode()).hexdigest()=='b9bdc78df34ef8c1c48d3d5a2f112d05b659bb23bbbce4fa87f9afdf3a054650'
needle="        raise ValueError('Source8 builder terminal identities differ')\n"
assert before.count(needle)==1
helper=before.replace(needle,needle+"    verify_physical_unchanged(history)\n")+"\n\ndef verify_physical_unchanged(history):\n    \"\"\"End with physical reads after the last caller-supplied take callback.\"\"\"\n    if (type(history) is not BuilderHistory\n            or history.prior_sources != history._prior\n            or set(history._prior) != {BUILDER}\n            or pin(history._prior[BUILDER]) != PRIOR\n            or tuple(sorted(history._initial)) != history._inventory\n            or history.captures != {n: row[0] for n, row in history._initial.items()}):\n        raise ValueError('Source8 builder terminal custody changed')\n    for name in history._inventory:\n        path, _ = _name(history.root, history.root / name)\n        cursor = path\n        while cursor != history.root:\n            if stat.S_ISLNK(cursor.lstat().st_mode):\n                raise ValueError('Source8 builder terminal path uses a symlink: ' + name)\n            cursor = cursor.parent\n        before = path.lstat()\n        expected, mode = history._initial[name]\n        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1\n                or stat.S_IMODE(before.st_mode) != mode\n                or path.read_bytes() != expected\n                or _stamp(before) != _stamp(path.lstat())):\n            raise ValueError('Source8 builder actual input changed after take: ' + name)\n    if _EXECUTED_PATH.read_bytes() != _EXECUTED_SOURCE:\n        raise ValueError('Source8 builder executed reader changed after take')\n"
helper_path.write_text(helper)
genpath=S/'tools/hia_current_source_generation.py';genbefore=genpath.read_text()
gen=genbefore.replace("SOURCE8_BUILDER_READER_SHA256 = 'b9bdc78df34ef8c1c48d3d5a2f112d05b659bb23bbbce4fa87f9afdf3a054650'",
 "SOURCE8_BUILDER_READER_SHA256 = '"+hashlib.sha256(helper.encode()).hexdigest()+"'")
needle="        raise ValueError('source generation physical inventory changed at terminal')\n"
assert gen.count(needle)==1
gen=gen.replace(needle,needle+"    if history.source8_builder_history is not None:\n        _source8_terminal_physical(history)\n")
marker="\n\ndef maybe_prepare(root, supplied, *, take=Path.read_bytes):"
assert gen.count(marker)==1
gen=gen.replace(marker,"\n\ndef _source8_terminal_physical(history):\n    \"\"\"Keep the physical inventory current after all nested take callbacks.\"\"\"\n    from tools import hia_source8_builder_history as source8\n    source8.verify_physical_unchanged(history.source8_builder_history)\n    if (history.prior_sources != history._prior\n            or history.captures != {n: row[0] for n, row in history._initial.items()}):\n        raise ValueError('source generation terminal actual or prior custody changed')\n    for name, (expected, mode) in history._initial.items():\n        path, _ = _name(history.root, history.root / name)\n        cursor = path\n        while cursor != history.root:\n            if stat.S_ISLNK(cursor.lstat().st_mode):\n                raise ValueError('source generation terminal path uses a symlink: ' + name)\n            cursor = cursor.parent\n        before = path.lstat()\n        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1\n                or stat.S_IMODE(before.st_mode) != mode\n                or path.read_bytes() != expected\n                or _stamp(before) != _stamp(path.lstat())):\n            raise ValueError('source generation input changed after final take: ' + name)\n    if _EXECUTED_PATH.read_bytes() != _EXECUTED_SOURCE:\n        raise ValueError('source generation executed reader changed after final take')\n"+marker)
genpath.write_text(gen)
testpath=S/'tests/test_hia_source8_builder_history.py';testbefore=testpath.read_text()
marker="\n\nif __name__ == '__main__':"
assert testbefore.count(marker)==1
test=testbefore.replace(marker,"\n"+"\n    def _last_take_change(self, domain, target_kind):\n        if domain == 'generation':\n            self.install(self.complete_sources)\n        module = history\n        if target_kind == 'executed-module':\n            path = self.root / 'executed_reader.py'\n            path.write_bytes(self.sources[history.SELF])\n            spec = importlib.util.spec_from_file_location('_hia_source8_terminal_reader', path)\n            module = importlib.util.module_from_spec(spec)\n            spec.loader.exec_module(module)\n            target = path\n        elif target_kind == 'selected-reader':\n            target = self.root / generation.SELF\n        else:\n            target = self.root / history.BUILDER\n        original = target.read_bytes()\n        calls = []\n        armed = False\n        count = 0\n        last = 0\n        def take(path):\n            nonlocal count\n            raw = path.read_bytes()\n            calls.append(path)\n            if armed:\n                count += 1\n                if count == last:\n                    self.assertNotEqual(path, target)\n                    target.write_bytes(original + b'\\n')\n            return raw\n        if domain == 'generation':\n            _, saved = generation.prepare(self.root, take=take)\n            verify = generation.verify_unchanged\n        else:\n            _, saved = module.prepare(self.root,\n                {history.BUILDER: self.sources[history.BUILDER]}, take=take)\n            verify = module.verify_unchanged\n        calls.clear()\n        verify(saved)\n        last = len(calls)\n        self.assertGreater(last, 0)\n        self.assertNotEqual(calls[-1], target)\n        armed = True\n        try:\n            with self.assertRaises(ValueError):\n                verify(saved)\n            self.assertEqual(target.read_bytes(), original + b'\\n')\n        finally:\n            armed = False\n            target.write_bytes(original)\n        verify(saved)\n\n    def test_last_leaf_take_cannot_change_previously_checked_builder(self):\n        self._last_take_change('leaf', 'builder')\n\n    def test_last_leaf_take_cannot_change_the_executed_module(self):\n        self._last_take_change('leaf', 'executed-module')\n\n    def test_last_generation_take_cannot_change_previously_checked_builder(self):\n        self._last_take_change('generation', 'builder')\n\n    def test_last_generation_take_cannot_change_selected_reader(self):\n        self._last_take_change('generation', 'selected-reader')\n\n"+marker);testpath.write_text(test)
for label,a,z in [('helper',before,helper),('generation',genbefore,gen),('tests',testbefore,test)]:
 (Q/(label+'.before.py.txt')).write_text(a);(Q/(label+'.after.py.txt')).write_text(z)
old=json.loads((B/'builder-generation-integration-v1/controls-v1/result.json').read_bytes())
for n in ('tests/test_hia_current_source_generation.py','tests/fixtures/hia_current_source_generation_v1.json','tools/hia_frozen_component_sources.py'):
 assert hashlib.sha256((S/n).read_bytes()).hexdigest()==old['before'][n]['sha256']
names=['tools/hia_current_source_generation.py','tools/hia_source8_builder_history.py',
 'tests/fixtures/hia_source8_builder_successor_v1.json','tests/test_hia_source8_builder_history.py',
 'tests/test_hia_current_source_generation.py','tests/fixtures/hia_current_source_generation_v1.json',
 'tools/hia_frozen_component_sources.py']
def capture():return {n:{'bytes':len(x:=(S/n).read_bytes()),'sha256':hashlib.sha256(x).hexdigest(),'mode':(S/n).stat().st_mode&0o7777} for n in names}
initial=capture()
cmd=['/opt/homebrew/bin/python3.14','-B','-m','unittest','-v',
 'tests.test_hia_current_source_generation','tests.test_hia_source8_builder_history']
t=time.monotonic()
with (Q/'tests.log').open('wb') as f:
 p=subprocess.run(cmd,cwd=S,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT,timeout=180)
final=capture()
report={'command':cmd,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-t,
 'before':initial,'after':final,'source_unchanged':initial==final,'scope':'SOURCE_HISTORY_ONLY',
 'original_ten_complete_file_unchanged':True,'old_fixed_fixture_and_engine_unchanged':True}
(Q/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,sort_keys=True));print((Q/'tests.log').read_text())
raise SystemExit(p.returncode or (0 if initial==final else 2))
