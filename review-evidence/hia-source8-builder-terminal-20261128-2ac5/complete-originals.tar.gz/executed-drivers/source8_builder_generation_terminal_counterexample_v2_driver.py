from pathlib import Path
import sys, tempfile, importlib.util, json, hashlib, traceback
B=Path('/Users/qianqi/work/hia-bootstrap-source8-late-channels-20261128-2ac5')
S=B/'builder-generation-source';Q=B/'builder-generation-integration-terminal-v2'/'counterexamples-v2';Q.mkdir(exist_ok=False)
sys.path.insert(0,str(S))
from tools import hia_current_source_generation as generation
from tools import hia_source8_builder_history as reader
_,actual=generation.prepare(S); sources=dict(actual.captures)
results=[]
for domain,target_kind in [('leaf','builder'),('leaf','executed-module'),('generation','builder'),('generation','selected-reader')]:
 with tempfile.TemporaryDirectory(prefix='hia-source8-terminal-counterexample-') as d:
  root=Path(d).resolve(strict=True)/'source';root.mkdir()
  selected=sources if domain=='generation' else {n:sources[n] for n in (reader.SELF,reader.FIXTURE,reader.ENGINE,reader.BUILDER,*reader.INTRODUCED_INPUTS)}
  for name,raw in selected.items():
   p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o644)
  module=reader
  if target_kind=='executed-module':
   module_path=Path(d).resolve(strict=True)/'executed_reader.py';module_path.write_bytes(sources[reader.SELF])
   spec=importlib.util.spec_from_file_location('_hia_terminal_snapshot_counterexample',module_path)
   module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
   target=module_path
  elif target_kind=='selected-reader':target=root/generation.SELF
  else:target=root/reader.BUILDER
  original=target.read_bytes();calls=[];armed=False;count=0;last=0
  def take(path):
   global count
   raw=path.read_bytes()
   calls.append(str(path.relative_to(root)))
   if armed:
    count+=1
    if count==last:
     assert path!=target
     target.write_bytes(original+b'\n')
   return raw
  if domain=='leaf':
   _,saved=module.prepare(root,{reader.BUILDER:sources[reader.BUILDER]},take=take);verify=module.verify_unchanged
  else:
   _,saved=generation.prepare(root,take=take);verify=generation.verify_unchanged
  calls.clear();verify(saved);last=len(calls);last_path=calls[-1]
  assert root/last_path != target
  armed=True;count=0;raised=None
  try:verify(saved)
  except BaseException as exc:raised=type(exc).__name__+': '+str(exc)
  changed=target.read_bytes()!=original
  armed=False;target.write_bytes(original);verify(saved)
  row={'domain':domain,'target_kind':target_kind,'take_calls':last,'last_take_path':last_path,
       'target_changed':changed,'raised':raised,'false_accept':changed and raised is None}
  results.append(row);print(json.dumps(row),flush=True)
assert len(results)==4 and all(r['false_accept'] for r in results)
(Q/'old-reader-counterexamples.json').write_text(json.dumps({
 'source_commit':'6f6cfc1f250bfedb83cf04c7cf23015f3c886301',
 'scope':'actual late physical source changes in private copies; no product execution',
 'counterexamples':results,'restored_private_inputs':True},indent=2)+'\n')
