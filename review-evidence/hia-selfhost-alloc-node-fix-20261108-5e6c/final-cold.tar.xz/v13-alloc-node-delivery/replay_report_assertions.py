"""Run three existing report assertions without repeating compilation."""
from hashlib import sha256
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent.parent
SOURCE = BASE / "hepta-v13-alloc-node-fix"
sys.path.insert(0, str(SOURCE))
from tests.test_hia_selfhost import SelfhostNativeTests

report_path = BASE / "v13-alloc-node-native-final-02.json"
raw = report_path.read_bytes()
report = json.loads(raw)
test_source = SOURCE / "tests/test_hia_selfhost.py"
source_digest = sha256(test_source.read_bytes()).hexdigest()
assert report["source_manifest"]["tests/test_hia_selfhost.py"] == source_digest
methods = (
    "test_native_capacity_boundary_and_original_modified_node_accounting",
    "test_loans_keep_live_graphs_through_native_original_and_mutated_compilers",
    "test_hia_writes_elf_objects_that_link_and_rebuild_the_compiler",
)
for method in methods:
    case = SelfhostNativeTests(method)
    case.report = report
    getattr(case, method)()
result = {
    "schema": "hepta.hia.retained-native-report-assertions.v1", "status": "PASS",
    "report_sha256": sha256(raw).hexdigest(), "test_source_sha256": source_digest,
    "methods_passed": list(methods), "additional_native_compilation_or_execution": False,
    "scope": "existing test-method assertions over the retained final 1131-check report",
}
(Path(__file__).parent / "retained-report-assertions.json").write_text(
    json.dumps(result, sort_keys=True, indent=2) + "\n")
print(json.dumps(result, sort_keys=True))
