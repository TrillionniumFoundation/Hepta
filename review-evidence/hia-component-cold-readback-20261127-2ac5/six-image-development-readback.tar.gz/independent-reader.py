import importlib.abc,json,pathlib,sys
sys.path.insert(0,sys.argv[1])
class NoProduct(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=="hepta" or fullname.startswith(("hepta.","tools.build_","tools.generate_")) or "oracle" in fullname:
   raise AssertionError("independent reader imported product: "+fullname)
sys.meta_path.insert(0,NoProduct())
from tools import read_hia_service_bootstrap as r
root=pathlib.Path(sys.argv[2]);source=json.loads((root/"source-before.json").read_bytes());captured=[]
report,declarations,images=r.construction(root,None,captured,source,require_cold=False)
r.unchanged(captured)
result={"status":"PASS","scope":"EXPLICIT_DEVELOPMENT_SIX_IMAGE_INDEPENDENT_READBACK","images":images,"captured_files":len(captured),"product_generator_builder_oracle_imported":False,"matching_native_cold_qualified":False,"whole_native_delivery_qualified":False}
(root/"independent-readback.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
print(json.dumps({k:result[k] for k in ("status","scope","captured_files")}))
