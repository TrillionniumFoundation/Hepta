import time
time.sleep(0.20)
import os,time;os.write(1,b'"HIA_DIAG_v1_LIN_000" : String\n');time.sleep(10)