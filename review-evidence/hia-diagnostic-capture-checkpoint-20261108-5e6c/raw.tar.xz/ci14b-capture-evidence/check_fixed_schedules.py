"""Targeted replay of child/start-fsync latency and absent-marker failure."""
from hashlib import sha256
import io
import json
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/5e6c25ac6d7b/hepta-ci14b-capture-fix')
EVIDENCE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tests.test_core_syntax_diagnostic_capture import DiagnosticCaptureTests, capture

original = DiagnosticCaptureTests.run_child
summary = []
for name in ('child_delay_200ms', 'start_fsync_delay_200ms', 'missing_marker'):
    directory = EVIDENCE / name
    directory.mkdir(exist_ok=False)
    observed = {}

    def instrumented(self, script, **kwargs):
        actual = ('import time\ntime.sleep(0.20)\n' + script if name == 'child_delay_200ms' else
                  'import time;time.sleep(10)' if name == 'missing_marker' else script)
        (directory / 'child.py').write_text(actual)
        if name == 'child_delay_200ms':
            assert actual.encode() == (EVIDENCE / 'repro-child-delayed.py').read_bytes()
        setup = kwargs.get('setup')
        if name == 'start_fsync_delay_200ms':
            def delayed_setup(safe, stack):
                original_fsync = capture.os.fsync
                calls = 0
                def delayed_fsync(fd):
                    nonlocal calls
                    if calls == 0:
                        time.sleep(0.20)
                    calls += 1
                    return original_fsync(fd)
                stack.enter_context(patch.object(capture.os, 'fsync', delayed_fsync))
                setup(safe, stack)
            kwargs['setup'] = delayed_setup
        result, files, launches = original(self, actual, **kwargs)
        observed.update(result=result, files={})
        for file_name, data in files.items():
            (directory / file_name).write_bytes(data)
            observed['files'][file_name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
        return result, files, launches

    case = DiagnosticCaptureTests('test_complete_marker_checkpoints_are_durable_and_raw_not_copied')
    output = io.StringIO()
    started = time.monotonic()
    with patch.object(DiagnosticCaptureTests, 'run_child', instrumented):
        result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.TestSuite([case]))
    elapsed = time.monotonic() - started
    expected_failure = name == 'missing_marker'
    observed.update(case=name, tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                    expected_failure=expected_failure, real_elapsed_seconds=elapsed)
    (directory / 'unittest.log').write_text(output.getvalue())
    (directory / 'receipt.json').write_text(json.dumps(observed, indent=2) + '\n')
    assert result.testsRun == 1 and len(result.failures) == int(expected_failure) and not result.errors, output.getvalue()
    assert observed['result']['status'] == 'diagnostic_timeout'
    assert observed['result']['timeout_seconds'] == 0.15
    assert observed['result']['marker_count'] == int(not expected_failure)
    assert observed['result']['leader_reaped'] and observed['result']['group_kill_sent']
    assert not observed['result']['cleanup_deadline_exceeded']
    if expected_failure:
        assert 1 <= elapsed < 1.5, elapsed
    summary.append({key: observed[key] for key in ('case', 'tests_run', 'failures', 'errors', 'expected_failure', 'real_elapsed_seconds')})

(EVIDENCE / 'fixed-schedule-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
