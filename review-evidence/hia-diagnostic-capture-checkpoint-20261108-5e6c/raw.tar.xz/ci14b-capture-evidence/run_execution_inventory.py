"""Run the unchanged 42-case execution inventory from the retained CI log."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import unittest
import z3

ROOT = Path('/workspace/scratch/5e6c25ac6d7b/hepta-ci14b-capture-fix')
EVIDENCE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
assert z3.get_version_string() == '4.15.4'

def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item

names = ['tests.test_core_syntax_declaration_diagnostic_runner', 'tests.test_core_syntax_diagnostic_capture']
cases = sorted(flatten(unittest.defaultTestLoader.loadTestsFromNames(names)), key=lambda case: case.id())
assert not unittest.defaultTestLoader.errors
inventory = [case.id() for case in cases]
original_line = next(line for line in (EVIDENCE / 'original-ci-failure.log').read_text().splitlines()
                     if '{"group": "execution", "count": 42, "tests": [' in line)
original_inventory = json.loads(original_line[original_line.index('{'):])
assert inventory == original_inventory['tests'] and len(inventory) == 42
started = time.monotonic()
with (EVIDENCE / 'fixed-execution-42-qualified.log').open('w') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.TestSuite(cases))
report = dict(base_commit='14b2c03c35f0d8d4f3b77133cf3deecde92a2f40', python=sys.version,
              executable=sys.executable, z3_version=z3.get_version_string(), tests=inventory,
              inventory_matches_original_ci=True, original_inventory_sha256=original_inventory['inventory_sha256'],
              tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
              elapsed_seconds=time.monotonic() - started, successful=result.wasSuccessful(),
              source_sha256={name: sha256((ROOT / name).read_bytes()).hexdigest() for name in
                             ('tests/test_core_syntax_diagnostic_capture.py', 'tools/core_syntax_diagnostic_capture.py')})
(EVIDENCE / 'fixed-execution-42-qualified.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('tests_run', 'failures', 'errors', 'skipped', 'elapsed_seconds', 'successful')}))
assert result.testsRun == 42 and result.wasSuccessful() and not result.skipped
