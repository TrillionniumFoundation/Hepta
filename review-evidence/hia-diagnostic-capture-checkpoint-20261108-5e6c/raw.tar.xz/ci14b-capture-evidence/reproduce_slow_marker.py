"""Controlled child scheduling delay against the unchanged exact-14b test."""
from hashlib import sha256
import io
import json
from pathlib import Path
import shutil
import sys
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/5e6c25ac6d7b/hepta-ci14b-capture-fix')
EVIDENCE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tests.test_core_syntax_diagnostic_capture import DiagnosticCaptureTests

original = DiagnosticCaptureTests.run_child
observed = {}

def delayed(self, script, **kwargs):
    actual = 'import time\ntime.sleep(0.20)\n' + script
    (EVIDENCE / 'repro-child-original.py').write_text(script)
    (EVIDENCE / 'repro-child-delayed.py').write_text(actual)
    result, files, launches = original(self, actual, **kwargs)
    observed.update(result=result, files={})
    for name, data in files.items():
        (EVIDENCE / ('repro-' + name)).write_bytes(data)
        observed['files'][name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
    return result, files, launches

case = DiagnosticCaptureTests('test_complete_marker_checkpoints_are_durable_and_raw_not_copied')
output = io.StringIO()
with patch.object(DiagnosticCaptureTests, 'run_child', delayed):
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.TestSuite([case]))
(EVIDENCE / 'original-controlled-delay-test.log').write_text(output.getvalue())
observed.update(schema='hia.capture.schedule_reproduction.v1',
    base_commit='14b2c03c35f0d8d4f3b77133cf3deecde92a2f40',
    scheduling_injection='prepend a 0.20-second sleep before the original child code; test body and capture source unchanged',
    original_ci_cause='unknown from CI log; this reproduces a scheduling assumption, not the exact unobserved CI schedule',
    tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
    original_test_sha256=sha256((ROOT / 'tests/test_core_syntax_diagnostic_capture.py').read_bytes()).hexdigest(),
    capture_sha256=sha256((ROOT / 'tools/core_syntax_diagnostic_capture.py').read_bytes()).hexdigest())
(EVIDENCE / 'original-controlled-delay.json').write_text(json.dumps(observed, indent=2) + '\n')
print(output.getvalue(), end='')
print(json.dumps({key: observed[key] for key in ('tests_run', 'failures', 'errors', 'original_test_sha256', 'capture_sha256')}))
assert result.testsRun == 1 and len(result.failures) == 1 and not result.errors
assert observed['result']['status'] == 'diagnostic_timeout'
assert observed['result']['marker_count'] == 0
assert observed['result']['leader_reaped']
shutil.copyfile('/workspace/scratch/5e6c25ac6d7b/ci14b-initialization-failure.log', EVIDENCE / 'original-ci-failure.log')
