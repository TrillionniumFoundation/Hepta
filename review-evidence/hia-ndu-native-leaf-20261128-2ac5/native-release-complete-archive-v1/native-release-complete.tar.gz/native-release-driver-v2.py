from pathlib import Path
import ast,hashlib,json,os,sys,time,traceback,struct,subprocess,shutil
from unittest.mock import patch
R=Path(__file__).resolve().parent;S=R/'release-source-v2';Q=R/'qualification/native-release-component-v2';Q.mkdir(parents=True)
sys.path.insert(0,str(S));os.umask(0o022)
manifest=json.loads((R/'release-source-v2.manifest.json').read_bytes())
def stable():
 for name,row in manifest.items():
  p=S/name;data=p.read_bytes()
  if len(data)!=row['bytes']or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('changed source '+name)
stable();result={'started':time.time(),'passed':False,'scope':'DEVELOPMENT_COMPONENT_NATIVE_CONSTRUCTION','matching_cold':False}
try:
 from tools.build_hia_ndu_evaluator import build,_run
 from tools.build_hia_source_build import _named_source_request,_compiled_sources,_run_captured
 from tools.build_hia_source_capture import capture_root_sources,capture_named_sources
 from tools.build_hia_native_store_release import NativeReleaseSources
 from tools.hia_ndu_evaluator_release import stage_ndu_evaluator,CONTRACT,CONTRACT_SHA256,PRODUCT,CONTRACT_PRODUCT,frame
 from tools.generate_hia_ndu_evaluator_recipe import recipe,SOURCE_PATH
 compiler=R/'prerequisites/hia-source-build';b3=(R/'prerequisites/B3.flat').read_bytes()
 seed=compiler.read_bytes();capture=(R/'prerequisites/hia-source-capture').read_bytes()
 assert hashlib.sha256(seed).hexdigest()=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 assert hashlib.sha256(b3).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
 strict=build(Q/'sealed-original-constructor',compiler,R/'prerequisites/hia-seed-filter-pack',root=S)
 contract=json.loads((S/CONTRACT).read_bytes());pins={name:row['sha256']for name,row in manifest.items()}
 captures=[];real_capture_run=_run_captured
 def observe_capture(executable,operation,wire,work,**kwargs):
  observed=real_capture_run(executable,operation,wire,work,**kwargs)
  d=Q/'captures'/str(len(captures));d.mkdir(parents=True)
  (d/'stdin').write_bytes(wire);(d/'stdout').write_bytes(observed.stdout);(d/'stderr').write_bytes(observed.stderr)
  row={'id':len(captures),'returncode':observed.returncode,'stdin_sha256':hashlib.sha256(wire).hexdigest(),'stdout_sha256':hashlib.sha256(observed.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(observed.stderr).hexdigest()}
  (d/'terminal.json').write_text(json.dumps(row,indent=2)+'\n');captures.append(row);return observed
 counter=0;kit_images={};kit_paths={}
 def call(program,operation,wire):
  global counter
  digest=hashlib.sha256(program).hexdigest();path=Q/'executables'/digest;path.parent.mkdir(exist_ok=True)
  if not path.exists():path.write_bytes(program);path.chmod(0o500)
  d=Q/'calls'/str(counter);counter+=1;d.mkdir(parents=True)
  raw,_=_run(d,'native',[path,operation],wire,executable=program)
  if wire[:8]==b'HIANDP01':kit_images[digest]=program;kit_paths[digest]=path
  return raw
 def capture_sources(named):
  normalized={alias:path if path.startswith(('examples/','docs/','hepta/','tools/'))else'examples/hia_bootstrap/'+path for alias,path in named.items()}
  return capture_root_sources(capture,S,normalized,pins,Q)
 def compile_sources(named):
  captured=capture_sources(named)
  raw=call(seed,'sources',_named_source_request(captured))
  return raw,_compiled_sources(raw,captured),captured
 published=[]
 with patch('tools.build_hia_source_capture._run_captured',side_effect=observe_capture):
  for n in(1,2):
   work=Q/('construction-'+str(n));work.mkdir()
   products={}
   def publish(path,*,expected=None):
    data=path.read_bytes();assert expected and hashlib.sha256(data).hexdigest()==expected
    assert path.name not in products;products[path.name]=data
   builds=NativeReleaseSources(seed,compile_sources,capture_sources,call)
   stage_ndu_evaluator(work,seed,builds,call,b3,publish)
   assert set(products)=={PRODUCT,CONTRACT_PRODUCT}
   assert products[PRODUCT]==strict.read_bytes()
   assert products[CONTRACT_PRODUCT]==(S/CONTRACT).read_bytes()
   published.append(products)
  # Actual native root-relative captures: all three ABI JSON files and the
  # typed custody archive, never the six original Python paths.
  from tools.hia_core_host_custody import ARCHIVE_PATH
  core={family+'.json':'hepta/hia_core_'+family+'_abi.json'for family in('compare','integer','unpack')}
  core['custody.hiadat']=ARCHIVE_PATH
  actual=capture_root_sources(capture,S,core,pins,Q)
  assert actual=={alias:(S/name).read_bytes()for alias,name in core.items()}
  # Original named source capture still executes its original HIANAM01 route.
  original=capture_named_sources(capture,S,{'selfhost.hepta':'selfhost.hepta'},pins,Q)
  assert original['selfhost.hepta']==(S/'examples/hia_bootstrap/selfhost.hepta').read_bytes()
  control=Q/'capture-controls';control.mkdir()
  bads=[]
  def reject(label,path,pin):
   before=len(captures)
   try:capture_root_sources(capture,control,{'data':path},{path:pin},Q)
   except(ValueError,OSError)as error:bads.append({'label':label,'refused':True,'native_calls':len(captures)-before,'error':str(error)})
   else:raise AssertionError('raw capture admitted '+label)
  good=control/'good.txt';good.write_bytes(b'actual native data')
  goodpin=hashlib.sha256(good.read_bytes()).hexdigest()
  assert capture_root_sources(capture,control,{'data':'good.txt'},{'good.txt':goodpin},Q)=={'data':b'actual native data'}
  (control/'host.py').write_bytes(b'print(1)');reject('host-language-path','host.py',hashlib.sha256((control/'host.py').read_bytes()).hexdigest())
  reject('wrong-digest','good.txt','0'*64)
  reject('absent','missing.txt',goodpin)
  (control/'link.txt').symlink_to('good.txt');reject('symlink','link.txt',goodpin)
  os.link(good,control/'hard.txt');reject('hardlink','hard.txt',goodpin)
  (control/'hard.txt').unlink()
  (control/'empty.txt').touch();reject('empty','empty.txt',hashlib.sha256(b'').hexdigest())
  (control/'directory.txt').mkdir();reject('directory','directory.txt',goodpin)
  os.mkfifo(control/'fifo.txt');reject('fifo','fifo.txt',goodpin)
  (control/'large.txt').write_bytes(b'x'*(1048576+1));reject('original-1MiB-limit','large.txt',hashlib.sha256((control/'large.txt').read_bytes()).hexdigest())
  # Preserve the FIFO/symlink/directory identities as metadata; tar will not
  # follow or read them as regular evidence payloads.
  (Q/'capture-controls.json').write_text(json.dumps(bads,indent=2)+'\n')
 assert published[0]==published[1]
 assert len(kit_images)==1
 kit=next(iter(kit_images.values()));kit_path=next(iter(kit_paths.values()))
 rows={row['role']:row for row in contract['build_inputs']['modules']}
 images={role:(Q/'sealed-original-constructor/construction-1'/(role+'.stdout')).read_bytes()for role in('transport','evaluator','number','debug')}
 wire=frame(images,contract);bad_inputs=[('empty',b''),('short-header',wire[:47]),('truncated',wire[:-1]),('trailing',wire+b'x')]
 for off in(0,8,16,24,32,40):
  data=bytearray(wire);struct.pack_into('<Q',data,off,struct.unpack_from('<Q',data,off)[0]^1);bad_inputs.append(('word-'+str(off),bytes(data)))
 refusals=[]
 for label,data in bad_inputs:
  d=Q/'policy-refusals'/label;d.mkdir(parents=True)
  try:_run(d,'native',[kit_path,'build'],data,executable=kit)
  except ValueError:pass
  else:raise AssertionError('new fixed leaf policy accepted '+label)
  terminal=json.loads((d/'native.terminal.json').read_bytes())
  assert terminal['status']=='exited'and terminal['returncode']==16
  assert not(d/'native.stdout').read_bytes()
  refusals.append({'case':label,**terminal})
 (Q/'policy-refusals.json').write_text(json.dumps(refusals,indent=2)+'\n')
 import importlib.util
 spec=importlib.util.spec_from_file_location('ndu_installed_negative_controls',S/'tests/hia_ndu_native_controls.py')
 controls_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(controls_module)
 control_report=controls_module.run_controls(R/'qualification/native-leaf-v2/default-package',Q/'strict-default-controls')
 result['default_resource_refusals']=control_report['controls']
 # Data-only recipe declaration is independently re-read; execution of the
 # whole final release owner awaits the central source freeze.
 dag=(S/SOURCE_PATH).read_bytes();assert dag==recipe().binary()
 result.update(passed=True,ordinary_constructions=2,actual_native_calls=counter,native_captures=len(captures),core_raw_paths=core,core_raw_capture_passed=True,raw_negative_controls=len(bads),policy_native_refusals=len(refusals),published={name:hashlib.sha256(raw).hexdigest()for name,raw in published[0].items()},dag_sha256=hashlib.sha256(dag).hexdigest(),installed_whole_rebuild_qualified_here=False)
except BaseException:result['exception']=traceback.format_exc();print(result['exception'],flush=True)
finally:
 try:stable();result['source_unchanged']=True
 except BaseException:result['source_unchanged']=False;result['source_error']=traceback.format_exc()
 result['passed']=result['passed']and result['source_unchanged'];result['finished']=time.time()
 (Q/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if not result['passed']:raise SystemExit(1)
