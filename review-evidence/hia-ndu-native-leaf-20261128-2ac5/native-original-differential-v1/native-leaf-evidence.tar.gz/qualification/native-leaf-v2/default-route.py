import sys,json
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from hepta.hia_ndu_optimizer import _bridge_identity,_native_rank
from hepta.hia_ndu_prepared_ranker import PreparedNduRanker
from hepta.hia_ndu_persistent_ranker import PersistentNduRanker
request=json.loads(Path(sys.argv[2]).read_bytes())
image,identity=_bridge_identity(None)
assert identity['implementation']=='HIA'
first,first_identity=_native_rank(None,request,timeout_s=10)
assert first['advisory_recommendation']=='candidate'
prepared=PreparedNduRanker(max_requests=2)
try:
 a,ai=prepared.rank(request);b,bi=prepared.rank(request);assert a==b==first
finally:prepared.close()
persistent=PersistentNduRanker(max_requests=2,lifetime_s=60,startup_timeout_s=1)
try:
 a,ai=persistent.rank(request);b,bi=persistent.rank(request);assert a==b==first
finally:persistent.close()
print(json.dumps({'passed':True,'one_shot':1,'prepared':2,'persistent':2,'identity':identity}))
