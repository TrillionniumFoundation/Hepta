from pathlib import Path
import hashlib,json,os,sys,subprocess,time,traceback,struct,unittest,types,shutil,ast
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/native-leaf-v1';Q.mkdir(parents=True)
os.umask(0o022);sys.path.insert(0,str(S));os.environ['PYTHONDONTWRITEBYTECODE']='1'
manifest=json.loads((R/'source-manifest.json').read_bytes())
def source_check():
 for name,row in manifest.items():
  p=S/name
  if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256'] or len(p.read_bytes())!=row['bytes']:raise ValueError('source changed '+name)
source_check(); result={'started':time.time(),'passed':False,'source_files':len(manifest),'scope':'DEVELOPMENT_COMPONENT','matching_cold':False}
try:
 compiler=R/'prerequisites/hia-source-build';compiler.chmod(0o500)
 b3=R/'prerequisites/B3.flat'
 assert hashlib.sha256(compiler.read_bytes()).hexdigest()=='494833999e25ac74ea6ad1de41235c01bfa036951f212604026cb8be686c78af'
 assert hashlib.sha256(b3.read_bytes()).hexdigest()=='acb6478d1a466d17210611c5fcbbd5aeec3109b0813e917f0bb5c8419f3c33a9'
 prep=Q/'filter-prerequisite';prep.mkdir()
 from tools.build_hia_ndu_evaluator import _run,build
 raw,record=_run(prep,'compile-filter',[compiler,'compile'],(S/'examples/hia_bootstrap/native_filter_packer.hepta').read_bytes())
 flat=prep/'native_filter_packer.flat';flat.write_bytes(raw)
 from tools.qualify_hia_selfhost import compile_stage
 root,receipt=compile_stage(prep,'wrap-filter',flat,b'HIAFLT01'+struct.pack('<Q',len(raw))+raw,output_extension='.elf')
 actual=hashlib.sha256(root.read_bytes()).hexdigest()
 if actual!='bd9f7c5d09a044737c549f860a581bb44e9d5e007fd9dd1ce15524cafff918f0':raise ValueError('fixed filter root differs '+actual)
 root.chmod(0o500)
 binary=build(Q/'native-build',compiler,root,root=S)
 result['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
 # Three explicit native identity changes; every original behavioral method is byte-identical.
 original=(S/'tests/test_hia_ndu_bridge.py').read_text()
 assert hashlib.sha256(original.encode()).hexdigest()=='ce16245ab77aa86e324f8d590f04a5a62887e4670f1a3076c179566f0d27b6cd'
 splices=[
 ('self.assertEqual(result["schema"], "hepta.hia.ndu-response.v1")','self.assertEqual(result["schema"], "hepta.hia.ndu-native-response.v1")'),
 ('self.assertEqual(result["entry_point"], PIN["entry_point"])','self.assertEqual(result["entry_point"], "hepta.hia.ndu_evaluator.v1")\n        self.assertEqual(result["reference_entry_point"], PIN["entry_point"])')]
 projected=original
 for old,new in splices:
  assert projected.count(old)==1;projected=projected.replace(old,new,1)
 restored=projected
 for old,new in reversed(splices):assert restored.count(new)==1;restored=restored.replace(new,old,1)
 assert restored==original
 before_methods={n.name:ast.get_source_segment(original,n)for n in ast.walk(ast.parse(original))if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')}
 after_methods={n.name:ast.get_source_segment(projected,n)for n in ast.walk(ast.parse(projected))if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')}
 assert before_methods==after_methods and len(before_methods)==19
 (Q/'original-test.py').write_text(original);(Q/'native-identity-test.py').write_text(projected)
 (Q/'test-source-relation.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'actual_projected_sha256':hashlib.sha256(projected.encode()).hexdigest(),'splices':[{'old':a,'new':b}for a,b in splices],'all_19_original_method_bodies_unchanged':True,'all_native_14_executed':True,'rust_provenance_5_separate':True},indent=2)+'\n')
 os.environ['HEPTA_NDU_BRIDGE']=str(binary)
 namespace={'__name__':'ndu_native_behavior','__file__':str(S/'tests/test_hia_ndu_bridge.py')}
 exec(compile(projected,namespace['__file__'],'exec'),namespace)
 klass=namespace['NativeNDUBridgeTests'];old_invoke=klass.invoke;observations=[]
 def invoke(self,value,*,raw=False):
  encoded=value if raw else json.dumps(value,separators=(',',':'),allow_nan=False).encode()
  p=old_invoke(self,value,raw=raw);number=len(observations);d=Q/'observations'/str(number);d.mkdir(parents=True)
  for label,data in [('stdin',encoded),('stdout',p.stdout),('stderr',p.stderr)]:(d/label).write_bytes(data)
  observations.append({'method':self.id().rsplit('.',1)[1],'returncode':p.returncode,'stdin_sha256':hashlib.sha256(encoded).hexdigest(),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'directory':str(d.relative_to(Q))})
  return p
 klass.invoke=invoke;suite=unittest.defaultTestLoader.loadTestsFromTestCase(klass);assert suite.countTestCases()==14
 with(Q/'tests.stderr').open('w')as stream:outcome=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 (Q/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
 result.update(tests=outcome.testsRun,failures=len(outcome.failures),errors=len(outcome.errors),skipped=len(outcome.skipped),actual_requests=len(observations))
 # A distinct package-owned default route; the source checkout stays untouched.
 package=Q/'default-package';shutil.copytree(S/'hepta',package/'hepta',ignore=shutil.ignore_patterns('__pycache__','.hepta-lock-*'))
 template=json.loads((S/'docs/HIA_NATIVE_NDU_EVALUATOR_BUILD.json').read_bytes())
 for name in [*template['source_files'],'docs/HIA_NATIVE_NDU_EVALUATOR_BUILD.json']:
  dst=package/'hepta/_data'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(S/name,dst)
 shutil.copyfile(binary,package/'hepta/_hia_ndu_evaluator.elf');(package/'hepta/_hia_ndu_evaluator.elf').chmod(0o500)
 shutil.copyfile(Q/'native-build/build-receipt.json',package/'hepta/_hia_ndu_evaluator_build.json')
 request=namespace['request'](namespace['candidate']('candidate',1));(Q/'request.json').write_text(json.dumps(request))
 code=r'''import sys,json
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from hepta.hia_ndu_optimizer import _bridge_identity,_native_rank
from hepta.hia_ndu_prepared_ranker import PreparedNduRanker
from hepta.hia_ndu_persistent_ranker import PersistentNduRanker
request=json.loads(Path(sys.argv[2]).read_bytes())
image,identity=_bridge_identity(None)
assert identity['implementation']=='HIA'
first,first_identity=_native_rank(None,request,timeout_s=10)
assert first['advisory_recommendation']=='candidate'
prepared=PreparedNduRanker(max_requests=2)
try:
 a,ai=prepared.rank(request);b,bi=prepared.rank(request);assert a==b==first
finally:prepared.close()
persistent=PersistentNduRanker(max_requests=2,lifetime_s=60,startup_timeout_s=1)
try:
 a,ai=persistent.rank(request);b,bi=persistent.rank(request);assert a==b==first
finally:persistent.close()
print(json.dumps({'passed':True,'one_shot':1,'prepared':2,'persistent':2,'identity':identity}))
'''
 child=Q/'default-route.py';child.write_text(code)
 start=time.monotonic();p=subprocess.run([sys.executable,'-I','-B',str(child),str(package),str(Q/'request.json')],capture_output=True,timeout=180)
 (Q/'default-route.stdout').write_bytes(p.stdout);(Q/'default-route.stderr').write_bytes(p.stderr)
 result['default_route']={'returncode':p.returncode,'wall_seconds':time.monotonic()-start}
 result['passed']=outcome.wasSuccessful()and not outcome.skipped and outcome.testsRun==14 and p.returncode==0
except BaseException:
 result['exception']=traceback.format_exc();print(result['exception'],flush=True)
finally:
 try:source_check();result['source_unchanged']=True
 except BaseException:result['source_unchanged']=False;result['source_error']=traceback.format_exc()
 result.update(finished=time.time());result['passed']=result['passed']and result['source_unchanged']
 (Q/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if not result['passed']:raise SystemExit(1)
