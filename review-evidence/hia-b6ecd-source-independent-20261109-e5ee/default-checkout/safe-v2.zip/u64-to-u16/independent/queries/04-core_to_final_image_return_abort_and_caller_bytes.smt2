(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_0 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (or (not (= ((_ extract 63 16) abi_word_0) #x000000000000)) false))
      (a!2 (or (not (= ((_ extract 63 16) abi_word_0) #x000000000000))
               (= ((_ extract 15 0) abi_word_0) #xffff)))
      (a!4 (ite (not (= ((_ extract 63 16) abi_word_0) #x000000000000))
                #x0000000000000000
                #x0000000000000000))
      (a!8 (ite (not (= ((_ extract 63 16) abi_word_0) #x000000000000))
                initial_caller_bytes
                initial_caller_bytes)))
(let ((a!3 (or (and a!2 (not (= abi_word_0 #x000000000000ffff))) false))
      (a!5 (not (and a!2 (not (= abi_word_0 #x000000000000ffff))))))
(let ((a!6 (ite (and a!2 (not (= abi_word_0 #x000000000000ffff)))
                #x0000000000000000
                (ite a!5
                     (concat #x000000000000 ((_ extract 15 0) abi_word_0))
                     #x0000000000000000)))
      (a!9 (ite (and a!2 (not (= abi_word_0 #x000000000000ffff)))
                initial_caller_bytes
                (ite a!5 initial_caller_bytes initial_caller_bytes))))
(let ((a!7 (distinct (ite (= ((_ extract 63 16) abi_word_0) #x000000000000)
                          (concat #x000000000000 ((_ extract 15 0) abi_word_0))
                          a!4)
                     a!6))
      (a!10 (distinct (ite (= ((_ extract 63 16) abi_word_0) #x000000000000)
                           initial_caller_bytes
                           a!8)
                      a!9)))
  (or (distinct a!1 a!3) (and (not a!1) a!7) a!10))))))

(check-sat)
