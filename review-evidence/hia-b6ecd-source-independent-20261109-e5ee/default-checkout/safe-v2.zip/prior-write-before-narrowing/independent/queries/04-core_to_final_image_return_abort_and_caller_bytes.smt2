(declare-fun initial_rsp () (_ BitVec 64))
(declare-fun abi_word_0 () (_ BitVec 64))
(declare-fun abi_word_1 () (_ BitVec 64))
(declare-fun initial_caller_bytes () (Array (_ BitVec 64) (_ BitVec 8)))
(declare-fun abi_word_2 () (_ BitVec 64))
(assert (bvuge initial_rsp #x0000000000004000))
(assert (bvule initial_rsp #xfffffffffffffff0))
(assert (= (bvand initial_rsp #x000000000000000f) #x0000000000000008))
(assert (let ((a!1 (or (= abi_word_1 #x0000000000000000)
               (and (distinct abi_word_0 #x0000000000000000)
                    (bvuge (bvadd abi_word_0 abi_word_1) abi_word_0)))))
  (=> (and (bvule abi_word_1 #x0000000000000010) a!1)
      (or (= abi_word_1 #x0000000000000000)
          (bvule (bvadd abi_word_0 abi_word_1)
                 (bvsub initial_rsp #x0000000000004000))
          (bvuge abi_word_0 (bvadd initial_rsp #x0000000000000008))))))
(assert (let ((a!1 (not (and (not (= abi_word_1 #x0000000000000000))
                     (= abi_word_0 #x0000000000000000))))
      (a!2 (and (not (= abi_word_1 #x0000000000000000))
                (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!5 (or (not (= ((_ extract 63 5) abi_word_1)
                       #b00000000000000000000000000000000000000000000000000000000000))
               (bvule #b10000 ((_ extract 4 0) abi_word_1))))
      (a!7 (or (not (= ((_ extract 63 16) abi_word_2) #x000000000000))
               (= ((_ extract 15 0) abi_word_2) #xffff)))
      (a!12 (and (= ((_ extract 63 5) abi_word_1)
                    #b00000000000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 4 0) abi_word_1) #b10000)
                 (not (= abi_word_1 #x0000000000000000))
                 (= abi_word_0 #x0000000000000000)))
      (a!13 (not (and (= ((_ extract 63 5) abi_word_1)
                         #b00000000000000000000000000000000000000000000000000000000000)
                      (bvule ((_ extract 4 0) abi_word_1) #b10000)))))
(let ((a!3 (and (= ((_ extract 63 5) abi_word_1)
                   #b00000000000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 4 0) abi_word_1) #b10000)
                a!1
                (not a!2)
                (= abi_word_1 #x0000000000000000)))
      (a!4 (and (= ((_ extract 63 5) abi_word_1)
                   #b00000000000000000000000000000000000000000000000000000000000)
                (bvule ((_ extract 4 0) abi_word_1) #b10000)
                a!1
                (not a!2)
                (not (= abi_word_1 #x0000000000000000))
                (not (= ((_ extract 63 16) abi_word_2) #x000000000000))))
      (a!6 (not (and a!5 (not (= abi_word_1 #x0000000000000010)))))
      (a!10 (and (= ((_ extract 63 5) abi_word_1)
                    #b00000000000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 4 0) abi_word_1) #b10000)
                 a!1
                 (not a!2)
                 (not (= abi_word_1 #x0000000000000000))
                 (= ((_ extract 63 16) abi_word_2) #x000000000000)))
      (a!11 (and (= ((_ extract 63 5) abi_word_1)
                    #b00000000000000000000000000000000000000000000000000000000000)
                 (bvule ((_ extract 4 0) abi_word_1) #b10000)
                 a!1
                 (not (= abi_word_1 #x0000000000000000))
                 (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!16 (not (and a!7 (not (= abi_word_2 #x000000000000ffff))))))
(let ((a!8 (and a!6
                (not (= abi_word_1 #x0000000000000000))
                (not (= abi_word_0 #x0000000000000000))
                (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                (not (bvule (bvadd abi_word_0 abi_word_1) abi_word_0))
                a!7
                (not (= abi_word_2 #x000000000000ffff))))
      (a!14 (ite a!3
                 #x0000000000000000
                 (ite a!11
                      #x0000000300000000
                      (ite a!12
                           #x0000000200000000
                           (ite a!13 #x0000000100000000 #x0000000000000000)))))
      (a!15 (and a!6
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (not (bvule abi_word_0 (bvadd abi_word_0 abi_word_1)))))
      (a!17 (and a!6
                 (not (= abi_word_1 #x0000000000000000))
                 (not (= abi_word_0 #x0000000000000000))
                 (bvule abi_word_0 (bvadd abi_word_0 abi_word_1))
                 (not (bvule (bvadd abi_word_0 abi_word_1) abi_word_0))
                 a!16))
      (a!22 (ite a!3
                 initial_caller_bytes
                 (ite a!11
                      initial_caller_bytes
                      (ite a!12
                           initial_caller_bytes
                           (ite a!13 initial_caller_bytes initial_caller_bytes))))))
(let ((a!9 (distinct (or a!3 a!4 false)
                     (or a!8 (and a!6 (= abi_word_1 #x0000000000000000)) false)))
      (a!18 (ite a!8
                 #x0000000000000000
                 (ite a!17
                      (concat #x000000000000 ((_ extract 15 0) abi_word_2))
                      #x0000000000000000)))
      (a!23 (ite a!10
                 (store initial_caller_bytes
                        (bvadd abi_word_0 #x0000000000000000)
                        ((_ extract 7 0) #x000000000000005d))
                 (ite a!4
                      (store initial_caller_bytes
                             (bvadd abi_word_0 #x0000000000000000)
                             ((_ extract 7 0) #x000000000000005d))
                      a!22)))
      (a!24 (ite a!8
                 (store initial_caller_bytes
                        abi_word_0
                        ((_ extract 7 0) #x000000000000005d))
                 (ite a!17
                      (store initial_caller_bytes
                             abi_word_0
                             ((_ extract 7 0) #x000000000000005d))
                      initial_caller_bytes))))
(let ((a!19 (ite (and a!6
                      (not (= abi_word_1 #x0000000000000000))
                      (= abi_word_0 #x0000000000000000))
                 #x0000000200000000
                 (ite a!15 #x0000000300000000 a!18)))
      (a!25 (ite (and a!6
                      (not (= abi_word_1 #x0000000000000000))
                      (= abi_word_0 #x0000000000000000))
                 initial_caller_bytes
                 (ite a!15 initial_caller_bytes a!24))))
(let ((a!20 (ite (and a!5 (not (= abi_word_1 #x0000000000000010)))
                 #x0000000100000000
                 (ite (and a!6 (= abi_word_1 #x0000000000000000))
                      #x0000000000000000
                      a!19)))
      (a!26 (ite (and a!5 (not (= abi_word_1 #x0000000000000010)))
                 initial_caller_bytes
                 (ite (and a!6 (= abi_word_1 #x0000000000000000))
                      initial_caller_bytes
                      a!25))))
(let ((a!21 (distinct (ite a!10
                           (concat #x000000000000 ((_ extract 15 0) abi_word_2))
                           (ite a!4 #x0000000000000000 a!14))
                      a!20)))
  (or a!9 (and (not (or a!3 a!4 false)) a!21) (distinct a!23 a!26))))))))))

(check-sat)
