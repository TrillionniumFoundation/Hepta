"""Retain real capture/replay under a controlled scheduler delay after SIGKILL."""
from pathlib import Path
import json
import shutil
import sys
import time
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from tests.test_core_seven_relocation_runner import Part04RunnerTests, collector

destination = Path(sys.argv[1])
destination.mkdir(parents=True, exist_ok=False)
Part04RunnerTests.setUpClass()
case = Part04RunnerTests("test_complete_failure_replay_and_spawn_semantics")
real_killpg = collector.os.killpg
signals = []

def delayed_killpg(pid, sig):
    real_killpg(pid, sig)
    signals.append([pid, int(sig)])
    time.sleep(0.04)

def inspect(path, report, identity, support):
    shutil.copytree(path, destination / "capture")
    verified = case.replay(path, identity, support)
    observation = {
        "validated_markers": verified["validated_markers"],
        "validated_parent_count": verified["validated_parent_count"],
        "status": report["status"],
        "process": report["stages"][-1]["process"],
        "controlled_post_sigkill_delay_seconds": 0.04,
        "actual_signals": signals,
    }
    (destination / "observation.json").write_text(json.dumps(observation, indent=2) + "\n")
    print(json.dumps(observation, indent=2), flush=True)
    case.assertTrue(verified["validated_markers"])

started = time.monotonic()
with patch.object(collector.os, "killpg", side_effect=delayed_killpg):
    case.exercise("target_timeout", inspect)
print(json.dumps({"elapsed_seconds": time.monotonic() - started}), flush=True)
