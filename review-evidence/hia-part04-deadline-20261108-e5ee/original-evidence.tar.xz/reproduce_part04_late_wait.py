"""Preserve actual Part04 child output, but observe wait completion too late."""
from pathlib import Path
import json
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from tests.test_core_seven_part04_capture import Part04CaptureTests, capture, lines

destination = Path(sys.argv[1])
destination.mkdir(parents=True, exist_ok=False)
state = {"offset": 0, "late_wait": False}
def setup(safe, stack):
    popen, monotonic = capture.subprocess.Popen, time.monotonic
    def launch(*args, **kwargs):
        child = popen(*args, **kwargs)
        wait = child.wait
        def observe(*args, **kwargs):
            outcome = wait(*args, **kwargs)
            state.update(offset=2, late_wait=True)
            return outcome
        child.wait = observe
        return child
    stack.enter_context(patch.object(capture.subprocess, 'Popen', side_effect=launch))
    stack.enter_context(patch.object(capture, 'time', SimpleNamespace(monotonic=lambda:monotonic()+state['offset'])))

case = Part04CaptureTests()
result, files, launches = case.run_child('import os;os.write(1,%r)' % lines(), setup=setup)
for name, raw in files.items():
    (destination/name).write_bytes(raw)
(destination/'observation.json').write_text(json.dumps({'result':result,'state':state},indent=2)+'\n')
print(json.dumps({'result':result,'state':state},indent=2),flush=True)
case.assertTrue(state['late_wait'])
case.assertNotEqual(result['status'],'diagnostic_completed')
