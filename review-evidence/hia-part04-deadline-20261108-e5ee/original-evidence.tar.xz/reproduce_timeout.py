"""Controlled target-start delay; execute the real retained capture and replay."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from tests.test_core_seven_relocation_runner import Part04RunnerTests, collector

destination = Path(sys.argv[1])
destination.mkdir(parents=True, exist_ok=False)
Part04RunnerTests.setUpClass()
case = Part04RunnerTests("test_complete_failure_replay_and_spawn_semantics")
real_popen = subprocess.Popen

def delayed(argv, **kwargs):
    assert argv[:2] == [sys.executable, "-c"]
    return real_popen(argv[:2] + ["import time\ntime.sleep(0.7)\n" + argv[2]], **kwargs)

def inspect(path, report, identity, support):
    shutil.copytree(path, destination / "capture")
    verified = case.replay(path, identity, support)
    process = report["stages"][-1]["process"]
    observation = {
        "validated_markers": verified["validated_markers"],
        "validated_parent_count": verified["validated_parent_count"],
        "status": report["status"],
        "process": process,
        "controlled_start_delay_seconds": 0.7,
    }
    (destination / "observation.json").write_text(json.dumps(observation, indent=2) + "\n")
    print(json.dumps(observation, indent=2), flush=True)
    case.assertTrue(verified["validated_markers"])

started = time.monotonic()
with patch.object(collector.subprocess, "Popen", side_effect=delayed):
    case.exercise("target_timeout", inspect)
print(json.dumps({"elapsed_seconds": time.monotonic() - started}), flush=True)
