import HiaSyntaxResearch.CertPart02
namespace HiaCoreSyntaxSlice
def linearRaw : Raw := linear_r0
def linearBytes : List Nat := linear_b0
theorem linear_bounds : withinBounds linearRaw = true := by decide +kernel
theorem linear_serialized : serializeRaw transportFuel transportDepth linearRaw = some linearBytes := by exact linear_s0
theorem linear_parsed : parseRaw transportFuel transportDepth linearBytes = some (linearRaw, []) := by
  simpa only [List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_p0 [])
theorem linear_bf0000 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g0 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0001 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g1 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0002 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g2 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0003 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g4 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0004 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g5 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0005 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g6 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0006 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g7 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0007 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g8 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0008 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g9 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0009 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g10 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0010 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g11 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0011 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g13 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0012 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g14 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0013 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g16 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0014 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g17 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0015 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g19 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0016 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g20 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0017 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g21 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0018 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g23 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0019 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g24 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0020 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g25 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0021 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g27 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0022 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g28 178 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0023 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g30 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0024 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g31 195 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0025 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g33 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0026 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g34 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0027 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g35 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0028 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g37 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0029 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g38 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0030 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g39 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0031 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g41 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0032 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g42 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0033 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g43 58 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0034 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g45 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0035 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g47 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0036 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g49 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0037 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g50 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0038 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g52 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0039 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g53 200 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0040 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g55 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0041 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g56 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0042 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g57 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0043 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g59 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0044 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g60 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0045 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g61 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0046 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g63 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0047 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g64 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0048 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g66 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0049 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g67 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0050 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g69 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0051 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g70 233 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0052 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g71 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0053 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g73 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0054 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g74 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0055 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g75 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0056 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g77 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0057 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g78 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0058 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g80 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0059 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g81 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0060 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g83 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0061 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g84 115 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0062 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g85 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0063 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g87 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0064 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g88 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0065 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g89 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0066 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g91 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0067 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g92 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0068 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g94 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0069 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g95 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0070 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g97 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0071 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g98 253 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0072 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g99 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0073 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g101 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0074 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g102 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0075 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g103 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0076 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g105 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0077 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g106 153 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0078 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g108 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0079 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g109 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0080 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g111 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0081 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g112 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0082 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g113 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0083 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g115 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0084 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g116 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0085 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g117 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0086 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g119 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0087 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g120 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0088 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g122 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0089 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g123 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0090 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g125 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0091 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g126 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0092 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g127 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0093 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g129 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0094 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g130 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0095 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g131 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0096 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g133 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0097 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g134 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0098 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g135 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0099 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g137 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0100 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g139 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0101 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g141 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0102 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g143 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0103 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g145 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0104 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g147 92 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0105 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g149 80 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0106 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g151 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0107 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g153 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0108 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g155 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0109 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g156 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0110 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g158 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0111 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g159 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0112 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g161 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0113 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g162 93 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0114 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g163 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0115 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g165 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0116 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g166 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0117 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g167 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0118 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g169 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0119 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g170 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0120 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g172 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0121 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g173 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0122 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g175 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0123 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g176 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0124 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g177 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0125 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g179 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0126 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g180 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0127 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g181 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0128 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g183 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0129 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g184 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0130 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g186 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0131 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g187 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0132 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g189 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0133 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g190 230 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0134 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g191 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0135 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g193 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0136 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g194 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0137 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g195 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0138 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g197 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0139 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g198 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0140 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g199 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0141 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g201 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0142 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g203 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0143 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g205 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0144 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g207 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0145 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g209 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0146 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g211 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0147 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g212 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0148 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g214 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0149 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g215 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0150 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g217 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0151 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g218 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0152 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g219 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0153 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g221 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0154 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g222 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0155 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g223 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0156 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g225 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0157 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g226 155 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0158 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g228 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0159 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g229 205 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0160 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g231 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0161 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g232 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0162 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g233 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0163 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g235 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0164 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g236 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0165 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g237 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0166 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g239 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0167 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g240 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0168 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g242 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0169 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g243 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0170 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g245 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0171 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g246 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0172 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g247 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0173 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g249 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0174 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g250 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0175 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g251 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0176 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g253 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0177 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g254 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0178 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g255 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0179 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g257 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0180 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g259 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0181 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g261 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0182 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g263 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0183 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g265 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0184 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g267 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0185 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g269 83 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0186 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g271 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0187 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g273 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0188 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g275 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0189 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g276 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0190 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g278 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0191 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g279 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0192 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g281 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0193 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g282 98 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0194 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g283 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0195 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g285 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0196 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g286 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0197 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g287 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0198 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g289 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0199 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g290 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0200 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g292 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0201 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g293 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0202 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g295 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0203 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g296 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0204 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g297 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0205 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g299 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0206 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g300 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0207 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g301 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0208 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g303 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0209 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g304 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0210 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g306 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0211 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g307 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0212 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g309 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0213 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g310 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0214 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g311 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0215 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g313 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0216 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g314 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0217 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g315 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0218 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g317 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0219 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g318 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0220 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g319 96 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0221 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g321 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0222 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g323 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0223 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g325 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0224 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g327 107 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0225 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g329 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0226 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g331 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0227 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g332 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0228 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g334 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0229 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g335 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0230 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g337 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0231 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g338 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0232 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g339 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0233 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g341 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0234 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g342 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0235 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g343 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0236 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g345 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0237 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g346 156 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0238 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g348 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0239 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g349 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0240 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g351 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0241 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g352 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0242 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g353 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0243 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g355 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0244 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g356 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0245 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g357 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0246 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g359 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0247 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g360 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0248 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g362 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0249 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g363 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0250 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g365 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0251 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g366 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0252 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g367 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0253 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g369 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0254 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g370 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0255 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g371 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0256 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g373 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0257 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g374 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0258 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g376 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0259 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g377 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0260 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g379 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0261 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g380 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0262 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g381 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0263 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g382 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0264 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g384 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0265 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g385 31 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0266 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g387 8 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0267 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g388 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0268 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g390 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0269 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g391 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0270 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g393 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0271 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g394 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0272 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g396 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0273 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g397 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0274 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g398 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0275 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g399 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0276 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g401 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0277 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g402 18 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0278 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g404 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0279 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g405 22 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0280 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g406 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0281 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b1 13 := by
  simpa only [linear_b1] using linear_bf0002
theorem linear_bf0282 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b6 13 := by
  simpa only [linear_b6] using linear_bf0010
theorem linear_bf0283 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b7 209 := by
  simpa only [linear_b7] using linear_bf0012
theorem linear_bf0284 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b8 61 := by
  simpa only [linear_b8] using linear_bf0014
theorem linear_bf0285 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b9 209 := by
  simpa only [linear_b9] using linear_bf0016
theorem linear_bf0286 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_3 216 := by
  simpa only [linear_v5_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g19 linear_b9 7 209 linear_bf0015 linear_bf0285)
theorem linear_bf0287 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_2 287 := by
  simpa only [linear_v5_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g16 ++ linear_b8) (44 :: linear_v5_3) 70 217 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g16 linear_b8 9 61 linear_bf0013 linear_bf0284) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_3 216 (by decide +kernel) linear_bf0286))
theorem linear_bf0288 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_1 503 := by
  simpa only [linear_v5_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g13 ++ linear_b7) (44 :: linear_v5_2) 215 288 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g13 linear_b7 6 209 linear_bf0011 linear_bf0283) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_2 287 (by decide +kernel) linear_bf0287))
theorem linear_bf0289 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_0 522 := by
  simpa only [linear_v5_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g10 ++ linear_b6) (44 :: linear_v5_1) 18 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g10 linear_b6 5 13 linear_bf0009 linear_bf0282) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_1 503 (by decide +kernel) linear_bf0288))
theorem linear_bf0290 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b5 524 := by
  simpa only [linear_b5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g9 (linear_v5_0 ++ linear_g21) 1 523 linear_bf0008 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v5_0 linear_g21 522 1 linear_bf0289 linear_bf0017))
theorem linear_bf0291 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b11 13 := by
  simpa only [linear_b11] using linear_bf0020
theorem linear_bf0292 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b12 178 := by
  simpa only [linear_b12] using linear_bf0022
theorem linear_bf0293 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b13 195 := by
  simpa only [linear_b13] using linear_bf0024
theorem linear_bf0294 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b14 100 := by
  simpa only [linear_b14] using linear_bf0026
theorem linear_bf0295 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_3 107 := by
  simpa only [linear_v10_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g33 linear_b14 7 100 linear_bf0025 linear_bf0294)
theorem linear_bf0296 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_2 312 := by
  simpa only [linear_v10_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g30 ++ linear_b13) (44 :: linear_v10_3) 204 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g30 linear_b13 9 195 linear_bf0023 linear_bf0293) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_3 107 (by decide +kernel) linear_bf0295))
theorem linear_bf0297 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_1 497 := by
  simpa only [linear_v10_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g27 ++ linear_b12) (44 :: linear_v10_2) 184 313 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g27 linear_b12 6 178 linear_bf0021 linear_bf0292) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_2 312 (by decide +kernel) linear_bf0296))
theorem linear_bf0298 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_0 516 := by
  simpa only [linear_v10_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g24 ++ linear_b11) (44 :: linear_v10_1) 18 498 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g24 linear_b11 5 13 linear_bf0019 linear_bf0291) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_1 497 (by decide +kernel) linear_bf0297))
theorem linear_bf0299 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b10 518 := by
  simpa only [linear_b10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g23 (linear_v10_0 ++ linear_g35) 1 517 linear_bf0018 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v10_0 linear_g35 516 1 linear_bf0298 linear_bf0027))
theorem linear_bf0300 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b16 13 := by
  simpa only [linear_b16] using linear_bf0030
theorem linear_bf0301 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b18 58 := by
  simpa only [linear_b18] using linear_bf0033
theorem linear_bf0302 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b19 87 := by
  simpa only [linear_b19] using linear_bf0034
theorem linear_bf0303 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b20 100 := by
  simpa only [linear_b20] using linear_bf0035
theorem linear_bf0304 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b21 104 := by
  simpa only [linear_b21] using linear_bf0036
theorem linear_bf0305 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_3 104 := by
  simpa only [linear_v17_3] using linear_bf0304
theorem linear_bf0306 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_2 205 := by
  simpa only [linear_v17_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b20 (44 :: linear_v17_3) 100 105 linear_bf0303 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_3 104 (by decide +kernel) linear_bf0305))
theorem linear_bf0307 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_1 293 := by
  simpa only [linear_v17_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b19 (44 :: linear_v17_2) 87 206 linear_bf0302 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_2 205 (by decide +kernel) linear_bf0306))
theorem linear_bf0308 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_0 352 := by
  simpa only [linear_v17_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b18 (44 :: linear_v17_1) 58 294 linear_bf0301 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_1 293 (by decide +kernel) linear_bf0307))
theorem linear_bf0309 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b17 354 := by
  simpa only [linear_b17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g42 (linear_v17_0 ++ linear_g50) 1 353 linear_bf0032 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v17_0 linear_g50 352 1 linear_bf0308 linear_bf0037))
theorem linear_bf0310 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b22 200 := by
  simpa only [linear_b22] using linear_bf0039
theorem linear_bf0311 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b23 33 := by
  simpa only [linear_b23] using linear_bf0041
theorem linear_bf0312 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_3 40 := by
  simpa only [linear_v15_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g55 linear_b23 7 33 linear_bf0040 linear_bf0311)
theorem linear_bf0313 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_2 250 := by
  simpa only [linear_v15_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g52 ++ linear_b22) (44 :: linear_v15_3) 209 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g52 linear_b22 9 200 linear_bf0038 linear_bf0310) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_3 40 (by decide +kernel) linear_bf0312))
theorem linear_bf0314 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_1 611 := by
  simpa only [linear_v15_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g41 ++ linear_b17) (44 :: linear_v15_2) 360 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g41 linear_b17 6 354 linear_bf0031 linear_bf0309) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_2 250 (by decide +kernel) linear_bf0313))
theorem linear_bf0315 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_0 630 := by
  simpa only [linear_v15_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g38 ++ linear_b16) (44 :: linear_v15_1) 18 612 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g38 linear_b16 5 13 linear_bf0029 linear_bf0300) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_1 611 (by decide +kernel) linear_bf0314))
theorem linear_bf0316 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b15 632 := by
  simpa only [linear_b15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g37 (linear_v15_0 ++ linear_g57) 1 631 linear_bf0028 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v15_0 linear_g57 630 1 linear_bf0315 linear_bf0042))
theorem linear_bf0317 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b25 13 := by
  simpa only [linear_b25] using linear_bf0045
theorem linear_bf0318 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b26 102 := by
  simpa only [linear_b26] using linear_bf0047
theorem linear_bf0319 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b27 204 := by
  simpa only [linear_b27] using linear_bf0049
theorem linear_bf0320 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b28 233 := by
  simpa only [linear_b28] using linear_bf0051
theorem linear_bf0321 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_3 240 := by
  simpa only [linear_v24_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g69 linear_b28 7 233 linear_bf0050 linear_bf0320)
theorem linear_bf0322 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_2 454 := by
  simpa only [linear_v24_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g66 ++ linear_b27) (44 :: linear_v24_3) 213 241 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g66 linear_b27 9 204 linear_bf0048 linear_bf0319) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_3 240 (by decide +kernel) linear_bf0321))
theorem linear_bf0323 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_1 563 := by
  simpa only [linear_v24_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g63 ++ linear_b26) (44 :: linear_v24_2) 108 455 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g63 linear_b26 6 102 linear_bf0046 linear_bf0318) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_2 454 (by decide +kernel) linear_bf0322))
theorem linear_bf0324 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_0 582 := by
  simpa only [linear_v24_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g60 ++ linear_b25) (44 :: linear_v24_1) 18 564 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g60 linear_b25 5 13 linear_bf0044 linear_bf0317) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_1 563 (by decide +kernel) linear_bf0323))
theorem linear_bf0325 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b24 584 := by
  simpa only [linear_b24] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g59 (linear_v24_0 ++ linear_g71) 1 583 linear_bf0043 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v24_0 linear_g71 582 1 linear_bf0324 linear_bf0052))
theorem linear_bf0326 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b30 13 := by
  simpa only [linear_b30] using linear_bf0055
theorem linear_bf0327 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b31 173 := by
  simpa only [linear_b31] using linear_bf0057
theorem linear_bf0328 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b32 204 := by
  simpa only [linear_b32] using linear_bf0059
theorem linear_bf0329 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b33 115 := by
  simpa only [linear_b33] using linear_bf0061
theorem linear_bf0330 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_3 122 := by
  simpa only [linear_v29_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g83 linear_b33 7 115 linear_bf0060 linear_bf0329)
theorem linear_bf0331 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_2 336 := by
  simpa only [linear_v29_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g80 ++ linear_b32) (44 :: linear_v29_3) 213 123 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g80 linear_b32 9 204 linear_bf0058 linear_bf0328) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_3 122 (by decide +kernel) linear_bf0330))
theorem linear_bf0332 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_1 516 := by
  simpa only [linear_v29_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g77 ++ linear_b31) (44 :: linear_v29_2) 179 337 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g77 linear_b31 6 173 linear_bf0056 linear_bf0327) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_2 336 (by decide +kernel) linear_bf0331))
theorem linear_bf0333 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_0 535 := by
  simpa only [linear_v29_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g74 ++ linear_b30) (44 :: linear_v29_1) 18 517 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g74 linear_b30 5 13 linear_bf0054 linear_bf0326) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_1 516 (by decide +kernel) linear_bf0332))
theorem linear_bf0334 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b29 537 := by
  simpa only [linear_b29] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g73 (linear_v29_0 ++ linear_g85) 1 536 linear_bf0053 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v29_0 linear_g85 535 1 linear_bf0333 linear_bf0062))
theorem linear_bf0335 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b35 13 := by
  simpa only [linear_b35] using linear_bf0065
theorem linear_bf0336 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b36 102 := by
  simpa only [linear_b36] using linear_bf0067
theorem linear_bf0337 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b37 236 := by
  simpa only [linear_b37] using linear_bf0069
theorem linear_bf0338 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b38 253 := by
  simpa only [linear_b38] using linear_bf0071
theorem linear_bf0339 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_3 260 := by
  simpa only [linear_v34_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g97 linear_b38 7 253 linear_bf0070 linear_bf0338)
theorem linear_bf0340 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_2 506 := by
  simpa only [linear_v34_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g94 ++ linear_b37) (44 :: linear_v34_3) 245 261 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g94 linear_b37 9 236 linear_bf0068 linear_bf0337) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_3 260 (by decide +kernel) linear_bf0339))
theorem linear_bf0341 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_1 615 := by
  simpa only [linear_v34_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g91 ++ linear_b36) (44 :: linear_v34_2) 108 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g91 linear_b36 6 102 linear_bf0066 linear_bf0336) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_2 506 (by decide +kernel) linear_bf0340))
theorem linear_bf0342 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_0 634 := by
  simpa only [linear_v34_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g88 ++ linear_b35) (44 :: linear_v34_1) 18 616 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g88 linear_b35 5 13 linear_bf0064 linear_bf0335) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_1 615 (by decide +kernel) linear_bf0341))
theorem linear_bf0343 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b34 636 := by
  simpa only [linear_b34] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g87 (linear_v34_0 ++ linear_g99) 1 635 linear_bf0063 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v34_0 linear_g99 634 1 linear_bf0342 linear_bf0072))
theorem linear_bf0344 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b40 13 := by
  simpa only [linear_b40] using linear_bf0075
theorem linear_bf0345 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b41 153 := by
  simpa only [linear_b41] using linear_bf0077
theorem linear_bf0346 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b42 236 := by
  simpa only [linear_b42] using linear_bf0079
theorem linear_bf0347 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b43 33 := by
  simpa only [linear_b43] using linear_bf0081
theorem linear_bf0348 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_3 40 := by
  simpa only [linear_v39_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g111 linear_b43 7 33 linear_bf0080 linear_bf0347)
theorem linear_bf0349 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_2 286 := by
  simpa only [linear_v39_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g108 ++ linear_b42) (44 :: linear_v39_3) 245 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g108 linear_b42 9 236 linear_bf0078 linear_bf0346) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_3 40 (by decide +kernel) linear_bf0348))
theorem linear_bf0350 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_1 446 := by
  simpa only [linear_v39_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g105 ++ linear_b41) (44 :: linear_v39_2) 159 287 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g105 linear_b41 6 153 linear_bf0076 linear_bf0345) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_2 286 (by decide +kernel) linear_bf0349))
theorem linear_bf0351 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_0 465 := by
  simpa only [linear_v39_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g102 ++ linear_b40) (44 :: linear_v39_1) 18 447 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g102 linear_b40 5 13 linear_bf0074 linear_bf0344) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_1 446 (by decide +kernel) linear_bf0350))
theorem linear_bf0352 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b39 467 := by
  simpa only [linear_b39] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g101 (linear_v39_0 ++ linear_g113) 1 466 linear_bf0073 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v39_0 linear_g113 465 1 linear_bf0351 linear_bf0082))
theorem linear_bf0353 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b45 11 := by
  simpa only [linear_b45] using linear_bf0085
theorem linear_bf0354 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b46 102 := by
  simpa only [linear_b46] using linear_bf0087
theorem linear_bf0355 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b47 170 := by
  simpa only [linear_b47] using linear_bf0089
theorem linear_bf0356 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b48 210 := by
  simpa only [linear_b48] using linear_bf0091
theorem linear_bf0357 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_3 217 := by
  simpa only [linear_v44_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g125 linear_b48 7 210 linear_bf0090 linear_bf0356)
theorem linear_bf0358 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_2 397 := by
  simpa only [linear_v44_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g122 ++ linear_b47) (44 :: linear_v44_3) 179 218 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g122 linear_b47 9 170 linear_bf0088 linear_bf0355) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_3 217 (by decide +kernel) linear_bf0357))
theorem linear_bf0359 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_1 506 := by
  simpa only [linear_v44_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g119 ++ linear_b46) (44 :: linear_v44_2) 108 398 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g119 linear_b46 6 102 linear_bf0086 linear_bf0354) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_2 397 (by decide +kernel) linear_bf0358))
theorem linear_bf0360 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_0 523 := by
  simpa only [linear_v44_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g116 ++ linear_b45) (44 :: linear_v44_1) 16 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g116 linear_b45 5 11 linear_bf0084 linear_bf0353) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_1 506 (by decide +kernel) linear_bf0359))
theorem linear_bf0361 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b44 525 := by
  simpa only [linear_b44] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g115 (linear_v44_0 ++ linear_g127) 1 524 linear_bf0083 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v44_0 linear_g127 523 1 linear_bf0360 linear_bf0092))
theorem linear_bf0362 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b50 11 := by
  simpa only [linear_b50] using linear_bf0095
theorem linear_bf0363 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b52 100 := by
  simpa only [linear_b52] using linear_bf0098
theorem linear_bf0364 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b53 101 := by
  simpa only [linear_b53] using linear_bf0099
theorem linear_bf0365 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b54 99 := by
  simpa only [linear_b54] using linear_bf0100
theorem linear_bf0366 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b55 99 := by
  simpa only [linear_b55] using linear_bf0101
theorem linear_bf0367 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b56 100 := by
  simpa only [linear_b56] using linear_bf0102
theorem linear_bf0368 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b57 99 := by
  simpa only [linear_b57] using linear_bf0103
theorem linear_bf0369 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b58 92 := by
  simpa only [linear_b58] using linear_bf0104
theorem linear_bf0370 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b59 80 := by
  simpa only [linear_b59] using linear_bf0105
theorem linear_bf0371 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b60 56 := by
  simpa only [linear_b60] using linear_bf0106
theorem linear_bf0372 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b61 86 := by
  simpa only [linear_b61] using linear_bf0107
theorem linear_bf0373 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b62 103 := by
  simpa only [linear_b62] using linear_bf0108
theorem linear_bf0374 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_10 103 := by
  simpa only [linear_v51_10] using linear_bf0373
theorem linear_bf0375 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_9 190 := by
  simpa only [linear_v51_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b61 (44 :: linear_v51_10) 86 104 linear_bf0372 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_10 103 (by decide +kernel) linear_bf0374))
theorem linear_bf0376 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_8 247 := by
  simpa only [linear_v51_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b60 (44 :: linear_v51_9) 56 191 linear_bf0371 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_9 190 (by decide +kernel) linear_bf0375))
theorem linear_bf0377 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_7 328 := by
  simpa only [linear_v51_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b59 (44 :: linear_v51_8) 80 248 linear_bf0370 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_8 247 (by decide +kernel) linear_bf0376))
theorem linear_bf0378 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_6 421 := by
  simpa only [linear_v51_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b58 (44 :: linear_v51_7) 92 329 linear_bf0369 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_7 328 (by decide +kernel) linear_bf0377))
theorem linear_bf0379 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_5 521 := by
  simpa only [linear_v51_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b57 (44 :: linear_v51_6) 99 422 linear_bf0368 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_6 421 (by decide +kernel) linear_bf0378))
theorem linear_bf0380 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_4 622 := by
  simpa only [linear_v51_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b56 (44 :: linear_v51_5) 100 522 linear_bf0367 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_5 521 (by decide +kernel) linear_bf0379))
theorem linear_bf0381 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_3 722 := by
  simpa only [linear_v51_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b55 (44 :: linear_v51_4) 99 623 linear_bf0366 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_4 622 (by decide +kernel) linear_bf0380))
theorem linear_bf0382 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_2 822 := by
  simpa only [linear_v51_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b54 (44 :: linear_v51_3) 99 723 linear_bf0365 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_3 722 (by decide +kernel) linear_bf0381))
theorem linear_bf0383 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_1 924 := by
  simpa only [linear_v51_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b53 (44 :: linear_v51_2) 101 823 linear_bf0364 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_2 822 (by decide +kernel) linear_bf0382))
theorem linear_bf0384 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_0 1025 := by
  simpa only [linear_v51_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b52 (44 :: linear_v51_1) 100 925 linear_bf0363 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_1 924 (by decide +kernel) linear_bf0383))
theorem linear_bf0385 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b51 1027 := by
  simpa only [linear_b51] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g134 (linear_v51_0 ++ linear_g156) 1 1026 linear_bf0097 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v51_0 linear_g156 1025 1 linear_bf0384 linear_bf0109))
theorem linear_bf0386 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b63 170 := by
  simpa only [linear_b63] using linear_bf0111
theorem linear_bf0387 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b64 93 := by
  simpa only [linear_b64] using linear_bf0113
theorem linear_bf0388 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_3 100 := by
  simpa only [linear_v49_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g161 linear_b64 7 93 linear_bf0112 linear_bf0387)
theorem linear_bf0389 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_2 280 := by
  simpa only [linear_v49_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g158 ++ linear_b63) (44 :: linear_v49_3) 179 101 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g158 linear_b63 9 170 linear_bf0110 linear_bf0386) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_3 100 (by decide +kernel) linear_bf0388))
theorem linear_bf0390 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_1 1314 := by
  simpa only [linear_v49_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g133 ++ linear_b51) (44 :: linear_v49_2) 1033 281 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g133 linear_b51 6 1027 linear_bf0096 linear_bf0385) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_2 280 (by decide +kernel) linear_bf0389))
theorem linear_bf0391 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_0 1331 := by
  simpa only [linear_v49_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g130 ++ linear_b50) (44 :: linear_v49_1) 16 1315 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g130 linear_b50 5 11 linear_bf0094 linear_bf0362) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_1 1314 (by decide +kernel) linear_bf0390))
theorem linear_bf0392 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b49 1333 := by
  simpa only [linear_b49] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g129 (linear_v49_0 ++ linear_g163) 1 1332 linear_bf0093 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v49_0 linear_g163 1331 1 linear_bf0391 linear_bf0114))
theorem linear_bf0393 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b66 11 := by
  simpa only [linear_b66] using linear_bf0117
theorem linear_bf0394 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b67 173 := by
  simpa only [linear_b67] using linear_bf0119
theorem linear_bf0395 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b68 170 := by
  simpa only [linear_b68] using linear_bf0121
theorem linear_bf0396 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b69 103 := by
  simpa only [linear_b69] using linear_bf0123
theorem linear_bf0397 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_3 110 := by
  simpa only [linear_v65_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g175 linear_b69 7 103 linear_bf0122 linear_bf0396)
theorem linear_bf0398 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_2 290 := by
  simpa only [linear_v65_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g172 ++ linear_b68) (44 :: linear_v65_3) 179 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g172 linear_b68 9 170 linear_bf0120 linear_bf0395) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_3 110 (by decide +kernel) linear_bf0397))
theorem linear_bf0399 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_1 470 := by
  simpa only [linear_v65_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g169 ++ linear_b67) (44 :: linear_v65_2) 179 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g169 linear_b67 6 173 linear_bf0118 linear_bf0394) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_2 290 (by decide +kernel) linear_bf0398))
theorem linear_bf0400 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_0 487 := by
  simpa only [linear_v65_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g166 ++ linear_b66) (44 :: linear_v65_1) 16 471 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g166 linear_b66 5 11 linear_bf0116 linear_bf0393) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_1 470 (by decide +kernel) linear_bf0399))
theorem linear_bf0401 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b65 489 := by
  simpa only [linear_b65] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g165 (linear_v65_0 ++ linear_g177) 1 488 linear_bf0115 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v65_0 linear_g177 487 1 linear_bf0400 linear_bf0124))
theorem linear_bf0402 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b71 11 := by
  simpa only [linear_b71] using linear_bf0127
theorem linear_bf0403 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b72 102 := by
  simpa only [linear_b72] using linear_bf0129
theorem linear_bf0404 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b73 202 := by
  simpa only [linear_b73] using linear_bf0131
theorem linear_bf0405 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b74 230 := by
  simpa only [linear_b74] using linear_bf0133
theorem linear_bf0406 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_3 237 := by
  simpa only [linear_v70_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g189 linear_b74 7 230 linear_bf0132 linear_bf0405)
theorem linear_bf0407 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_2 449 := by
  simpa only [linear_v70_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g186 ++ linear_b73) (44 :: linear_v70_3) 211 238 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g186 linear_b73 9 202 linear_bf0130 linear_bf0404) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_3 237 (by decide +kernel) linear_bf0406))
theorem linear_bf0408 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_1 558 := by
  simpa only [linear_v70_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g183 ++ linear_b72) (44 :: linear_v70_2) 108 450 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g183 linear_b72 6 102 linear_bf0128 linear_bf0403) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_2 449 (by decide +kernel) linear_bf0407))
theorem linear_bf0409 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_0 575 := by
  simpa only [linear_v70_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g180 ++ linear_b71) (44 :: linear_v70_1) 16 559 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g180 linear_b71 5 11 linear_bf0126 linear_bf0402) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_1 558 (by decide +kernel) linear_bf0408))
theorem linear_bf0410 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b70 577 := by
  simpa only [linear_b70] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g179 (linear_v70_0 ++ linear_g191) 1 576 linear_bf0125 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v70_0 linear_g191 575 1 linear_bf0409 linear_bf0134))
theorem linear_bf0411 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b76 11 := by
  simpa only [linear_b76] using linear_bf0137
theorem linear_bf0412 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b78 94 := by
  simpa only [linear_b78] using linear_bf0140
theorem linear_bf0413 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b79 99 := by
  simpa only [linear_b79] using linear_bf0141
theorem linear_bf0414 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b80 56 := by
  simpa only [linear_b80] using linear_bf0142
theorem linear_bf0415 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b81 100 := by
  simpa only [linear_b81] using linear_bf0143
theorem linear_bf0416 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b82 101 := by
  simpa only [linear_b82] using linear_bf0144
theorem linear_bf0417 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b83 86 := by
  simpa only [linear_b83] using linear_bf0145
theorem linear_bf0418 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b84 103 := by
  simpa only [linear_b84] using linear_bf0146
theorem linear_bf0419 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_6 103 := by
  simpa only [linear_v77_6] using linear_bf0418
theorem linear_bf0420 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_5 190 := by
  simpa only [linear_v77_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b83 (44 :: linear_v77_6) 86 104 linear_bf0417 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_6 103 (by decide +kernel) linear_bf0419))
theorem linear_bf0421 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_4 292 := by
  simpa only [linear_v77_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b82 (44 :: linear_v77_5) 101 191 linear_bf0416 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_5 190 (by decide +kernel) linear_bf0420))
theorem linear_bf0422 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_3 393 := by
  simpa only [linear_v77_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b81 (44 :: linear_v77_4) 100 293 linear_bf0415 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_4 292 (by decide +kernel) linear_bf0421))
theorem linear_bf0423 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_2 450 := by
  simpa only [linear_v77_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b80 (44 :: linear_v77_3) 56 394 linear_bf0414 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_3 393 (by decide +kernel) linear_bf0422))
theorem linear_bf0424 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_1 550 := by
  simpa only [linear_v77_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b79 (44 :: linear_v77_2) 99 451 linear_bf0413 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_2 450 (by decide +kernel) linear_bf0423))
theorem linear_bf0425 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_0 645 := by
  simpa only [linear_v77_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b78 (44 :: linear_v77_1) 94 551 linear_bf0412 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_1 550 (by decide +kernel) linear_bf0424))
theorem linear_bf0426 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b77 647 := by
  simpa only [linear_b77] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g198 (linear_v77_0 ++ linear_g212) 1 646 linear_bf0139 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v77_0 linear_g212 645 1 linear_bf0425 linear_bf0147))
theorem linear_bf0427 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b85 202 := by
  simpa only [linear_b85] using linear_bf0149
theorem linear_bf0428 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b86 103 := by
  simpa only [linear_b86] using linear_bf0151
theorem linear_bf0429 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_3 110 := by
  simpa only [linear_v75_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g217 linear_b86 7 103 linear_bf0150 linear_bf0428)
theorem linear_bf0430 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_2 322 := by
  simpa only [linear_v75_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g214 ++ linear_b85) (44 :: linear_v75_3) 211 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g214 linear_b85 9 202 linear_bf0148 linear_bf0427) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_3 110 (by decide +kernel) linear_bf0429))
theorem linear_bf0431 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_1 976 := by
  simpa only [linear_v75_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g197 ++ linear_b77) (44 :: linear_v75_2) 653 323 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g197 linear_b77 6 647 linear_bf0138 linear_bf0426) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_2 322 (by decide +kernel) linear_bf0430))
theorem linear_bf0432 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_0 993 := by
  simpa only [linear_v75_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g194 ++ linear_b76) (44 :: linear_v75_1) 16 977 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g194 linear_b76 5 11 linear_bf0136 linear_bf0411) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_1 976 (by decide +kernel) linear_bf0431))
theorem linear_bf0433 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b75 995 := by
  simpa only [linear_b75] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g193 (linear_v75_0 ++ linear_g219) 1 994 linear_bf0135 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v75_0 linear_g219 993 1 linear_bf0432 linear_bf0152))
theorem linear_bf0434 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b88 11 := by
  simpa only [linear_b88] using linear_bf0155
theorem linear_bf0435 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b89 155 := by
  simpa only [linear_b89] using linear_bf0157
theorem linear_bf0436 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b90 205 := by
  simpa only [linear_b90] using linear_bf0159
theorem linear_bf0437 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b91 34 := by
  simpa only [linear_b91] using linear_bf0161
theorem linear_bf0438 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_3 41 := by
  simpa only [linear_v87_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g231 linear_b91 7 34 linear_bf0160 linear_bf0437)
theorem linear_bf0439 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_2 256 := by
  simpa only [linear_v87_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g228 ++ linear_b90) (44 :: linear_v87_3) 214 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g228 linear_b90 9 205 linear_bf0158 linear_bf0436) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_3 41 (by decide +kernel) linear_bf0438))
theorem linear_bf0440 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_1 418 := by
  simpa only [linear_v87_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g225 ++ linear_b89) (44 :: linear_v87_2) 161 257 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g225 linear_b89 6 155 linear_bf0156 linear_bf0435) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_2 256 (by decide +kernel) linear_bf0439))
theorem linear_bf0441 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_0 435 := by
  simpa only [linear_v87_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g222 ++ linear_b88) (44 :: linear_v87_1) 16 419 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g222 linear_b88 5 11 linear_bf0154 linear_bf0434) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_1 418 (by decide +kernel) linear_bf0440))
theorem linear_bf0442 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b87 437 := by
  simpa only [linear_b87] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g221 (linear_v87_0 ++ linear_g233) 1 436 linear_bf0153 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v87_0 linear_g233 435 1 linear_bf0441 linear_bf0162))
theorem linear_bf0443 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b93 11 := by
  simpa only [linear_b93] using linear_bf0165
theorem linear_bf0444 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b94 105 := by
  simpa only [linear_b94] using linear_bf0167
theorem linear_bf0445 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b95 175 := by
  simpa only [linear_b95] using linear_bf0169
theorem linear_bf0446 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b96 221 := by
  simpa only [linear_b96] using linear_bf0171
theorem linear_bf0447 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_3 228 := by
  simpa only [linear_v92_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g245 linear_b96 7 221 linear_bf0170 linear_bf0446)
theorem linear_bf0448 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_2 413 := by
  simpa only [linear_v92_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g242 ++ linear_b95) (44 :: linear_v92_3) 184 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g242 linear_b95 9 175 linear_bf0168 linear_bf0445) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_3 228 (by decide +kernel) linear_bf0447))
theorem linear_bf0449 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_1 525 := by
  simpa only [linear_v92_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g239 ++ linear_b94) (44 :: linear_v92_2) 111 414 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g239 linear_b94 6 105 linear_bf0166 linear_bf0444) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_2 413 (by decide +kernel) linear_bf0448))
theorem linear_bf0450 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_0 542 := by
  simpa only [linear_v92_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g236 ++ linear_b93) (44 :: linear_v92_1) 16 526 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g236 linear_b93 5 11 linear_bf0164 linear_bf0443) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_1 525 (by decide +kernel) linear_bf0449))
theorem linear_bf0451 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b92 544 := by
  simpa only [linear_b92] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g235 (linear_v92_0 ++ linear_g247) 1 543 linear_bf0163 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v92_0 linear_g247 542 1 linear_bf0450 linear_bf0172))
theorem linear_bf0452 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b98 11 := by
  simpa only [linear_b98] using linear_bf0175
theorem linear_bf0453 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b100 102 := by
  simpa only [linear_b100] using linear_bf0178
theorem linear_bf0454 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b101 104 := by
  simpa only [linear_b101] using linear_bf0179
theorem linear_bf0455 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b102 101 := by
  simpa only [linear_b102] using linear_bf0180
theorem linear_bf0456 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b103 101 := by
  simpa only [linear_b103] using linear_bf0181
theorem linear_bf0457 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b104 103 := by
  simpa only [linear_b104] using linear_bf0182
theorem linear_bf0458 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b105 101 := by
  simpa only [linear_b105] using linear_bf0183
theorem linear_bf0459 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b106 94 := by
  simpa only [linear_b106] using linear_bf0184
theorem linear_bf0460 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b107 83 := by
  simpa only [linear_b107] using linear_bf0185
theorem linear_bf0461 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b108 57 := by
  simpa only [linear_b108] using linear_bf0186
theorem linear_bf0462 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b109 87 := by
  simpa only [linear_b109] using linear_bf0187
theorem linear_bf0463 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b110 109 := by
  simpa only [linear_b110] using linear_bf0188
theorem linear_bf0464 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_10 109 := by
  simpa only [linear_v99_10] using linear_bf0463
theorem linear_bf0465 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_9 197 := by
  simpa only [linear_v99_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b109 (44 :: linear_v99_10) 87 110 linear_bf0462 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_10 109 (by decide +kernel) linear_bf0464))
theorem linear_bf0466 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_8 255 := by
  simpa only [linear_v99_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b108 (44 :: linear_v99_9) 57 198 linear_bf0461 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_9 197 (by decide +kernel) linear_bf0465))
theorem linear_bf0467 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_7 339 := by
  simpa only [linear_v99_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b107 (44 :: linear_v99_8) 83 256 linear_bf0460 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_8 255 (by decide +kernel) linear_bf0466))
theorem linear_bf0468 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_6 434 := by
  simpa only [linear_v99_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b106 (44 :: linear_v99_7) 94 340 linear_bf0459 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_7 339 (by decide +kernel) linear_bf0467))
theorem linear_bf0469 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_5 536 := by
  simpa only [linear_v99_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b105 (44 :: linear_v99_6) 101 435 linear_bf0458 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_6 434 (by decide +kernel) linear_bf0468))
theorem linear_bf0470 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_4 640 := by
  simpa only [linear_v99_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b104 (44 :: linear_v99_5) 103 537 linear_bf0457 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_5 536 (by decide +kernel) linear_bf0469))
theorem linear_bf0471 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_3 742 := by
  simpa only [linear_v99_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b103 (44 :: linear_v99_4) 101 641 linear_bf0456 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_4 640 (by decide +kernel) linear_bf0470))
theorem linear_bf0472 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_2 844 := by
  simpa only [linear_v99_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b102 (44 :: linear_v99_3) 101 743 linear_bf0455 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_3 742 (by decide +kernel) linear_bf0471))
theorem linear_bf0473 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_1 949 := by
  simpa only [linear_v99_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b101 (44 :: linear_v99_2) 104 845 linear_bf0454 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_2 844 (by decide +kernel) linear_bf0472))
theorem linear_bf0474 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_0 1052 := by
  simpa only [linear_v99_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b100 (44 :: linear_v99_1) 102 950 linear_bf0453 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_1 949 (by decide +kernel) linear_bf0473))
theorem linear_bf0475 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b99 1054 := by
  simpa only [linear_b99] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g254 (linear_v99_0 ++ linear_g276) 1 1053 linear_bf0177 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v99_0 linear_g276 1052 1 linear_bf0474 linear_bf0189))
theorem linear_bf0476 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b111 175 := by
  simpa only [linear_b111] using linear_bf0191
theorem linear_bf0477 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b112 98 := by
  simpa only [linear_b112] using linear_bf0193
theorem linear_bf0478 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_3 105 := by
  simpa only [linear_v97_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g281 linear_b112 7 98 linear_bf0192 linear_bf0477)
theorem linear_bf0479 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_2 290 := by
  simpa only [linear_v97_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g278 ++ linear_b111) (44 :: linear_v97_3) 184 106 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g278 linear_b111 9 175 linear_bf0190 linear_bf0476) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_3 105 (by decide +kernel) linear_bf0478))
theorem linear_bf0480 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_1 1351 := by
  simpa only [linear_v97_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g253 ++ linear_b99) (44 :: linear_v97_2) 1060 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g253 linear_b99 6 1054 linear_bf0176 linear_bf0475) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_2 290 (by decide +kernel) linear_bf0479))
theorem linear_bf0481 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_0 1368 := by
  simpa only [linear_v97_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g250 ++ linear_b98) (44 :: linear_v97_1) 16 1352 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g250 linear_b98 5 11 linear_bf0174 linear_bf0452) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_1 1351 (by decide +kernel) linear_bf0480))
theorem linear_bf0482 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b97 1370 := by
  simpa only [linear_b97] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g249 (linear_v97_0 ++ linear_g283) 1 1369 linear_bf0173 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v97_0 linear_g283 1368 1 linear_bf0481 linear_bf0194))
theorem linear_bf0483 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b114 11 := by
  simpa only [linear_b114] using linear_bf0197
theorem linear_bf0484 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b115 175 := by
  simpa only [linear_b115] using linear_bf0199
theorem linear_bf0485 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b116 175 := by
  simpa only [linear_b116] using linear_bf0201
theorem linear_bf0486 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b117 109 := by
  simpa only [linear_b117] using linear_bf0203
theorem linear_bf0487 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_3 116 := by
  simpa only [linear_v113_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g295 linear_b117 7 109 linear_bf0202 linear_bf0486)
theorem linear_bf0488 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_2 301 := by
  simpa only [linear_v113_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g292 ++ linear_b116) (44 :: linear_v113_3) 184 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g292 linear_b116 9 175 linear_bf0200 linear_bf0485) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_3 116 (by decide +kernel) linear_bf0487))
theorem linear_bf0489 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_1 483 := by
  simpa only [linear_v113_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g289 ++ linear_b115) (44 :: linear_v113_2) 181 302 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g289 linear_b115 6 175 linear_bf0198 linear_bf0484) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_2 301 (by decide +kernel) linear_bf0488))
theorem linear_bf0490 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_0 500 := by
  simpa only [linear_v113_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g286 ++ linear_b114) (44 :: linear_v113_1) 16 484 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g286 linear_b114 5 11 linear_bf0196 linear_bf0483) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_1 483 (by decide +kernel) linear_bf0489))
theorem linear_bf0491 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b113 502 := by
  simpa only [linear_b113] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g285 (linear_v113_0 ++ linear_g297) 1 501 linear_bf0195 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v113_0 linear_g297 500 1 linear_bf0490 linear_bf0204))
theorem linear_bf0492 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b119 11 := by
  simpa only [linear_b119] using linear_bf0207
theorem linear_bf0493 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b120 105 := by
  simpa only [linear_b120] using linear_bf0209
theorem linear_bf0494 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b121 208 := by
  simpa only [linear_b121] using linear_bf0211
theorem linear_bf0495 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b122 243 := by
  simpa only [linear_b122] using linear_bf0213
theorem linear_bf0496 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_3 250 := by
  simpa only [linear_v118_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g309 linear_b122 7 243 linear_bf0212 linear_bf0495)
theorem linear_bf0497 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_2 468 := by
  simpa only [linear_v118_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g306 ++ linear_b121) (44 :: linear_v118_3) 217 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g306 linear_b121 9 208 linear_bf0210 linear_bf0494) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_3 250 (by decide +kernel) linear_bf0496))
theorem linear_bf0498 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_1 580 := by
  simpa only [linear_v118_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g303 ++ linear_b120) (44 :: linear_v118_2) 111 469 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g303 linear_b120 6 105 linear_bf0208 linear_bf0493) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_2 468 (by decide +kernel) linear_bf0497))
theorem linear_bf0499 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_0 597 := by
  simpa only [linear_v118_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g300 ++ linear_b119) (44 :: linear_v118_1) 16 581 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g300 linear_b119 5 11 linear_bf0206 linear_bf0492) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_1 580 (by decide +kernel) linear_bf0498))
theorem linear_bf0500 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b118 599 := by
  simpa only [linear_b118] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g299 (linear_v118_0 ++ linear_g311) 1 598 linear_bf0205 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v118_0 linear_g311 597 1 linear_bf0499 linear_bf0214))
theorem linear_bf0501 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b124 11 := by
  simpa only [linear_b124] using linear_bf0217
theorem linear_bf0502 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b126 96 := by
  simpa only [linear_b126] using linear_bf0220
theorem linear_bf0503 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b127 102 := by
  simpa only [linear_b127] using linear_bf0221
theorem linear_bf0504 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b128 57 := by
  simpa only [linear_b128] using linear_bf0222
theorem linear_bf0505 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b129 102 := by
  simpa only [linear_b129] using linear_bf0223
theorem linear_bf0506 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b130 107 := by
  simpa only [linear_b130] using linear_bf0224
theorem linear_bf0507 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b131 87 := by
  simpa only [linear_b131] using linear_bf0225
theorem linear_bf0508 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b132 109 := by
  simpa only [linear_b132] using linear_bf0226
theorem linear_bf0509 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_6 109 := by
  simpa only [linear_v125_6] using linear_bf0508
theorem linear_bf0510 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_5 197 := by
  simpa only [linear_v125_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b131 (44 :: linear_v125_6) 87 110 linear_bf0507 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_6 109 (by decide +kernel) linear_bf0509))
theorem linear_bf0511 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_4 305 := by
  simpa only [linear_v125_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b130 (44 :: linear_v125_5) 107 198 linear_bf0506 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_5 197 (by decide +kernel) linear_bf0510))
theorem linear_bf0512 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_3 408 := by
  simpa only [linear_v125_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b129 (44 :: linear_v125_4) 102 306 linear_bf0505 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_4 305 (by decide +kernel) linear_bf0511))
theorem linear_bf0513 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_2 466 := by
  simpa only [linear_v125_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b128 (44 :: linear_v125_3) 57 409 linear_bf0504 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_3 408 (by decide +kernel) linear_bf0512))
theorem linear_bf0514 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_1 569 := by
  simpa only [linear_v125_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b127 (44 :: linear_v125_2) 102 467 linear_bf0503 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_2 466 (by decide +kernel) linear_bf0513))
theorem linear_bf0515 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_0 666 := by
  simpa only [linear_v125_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b126 (44 :: linear_v125_1) 96 570 linear_bf0502 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_1 569 (by decide +kernel) linear_bf0514))
theorem linear_bf0516 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b125 668 := by
  simpa only [linear_b125] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g318 (linear_v125_0 ++ linear_g332) 1 667 linear_bf0219 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v125_0 linear_g332 666 1 linear_bf0515 linear_bf0227))
theorem linear_bf0517 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b133 208 := by
  simpa only [linear_b133] using linear_bf0229
theorem linear_bf0518 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b134 109 := by
  simpa only [linear_b134] using linear_bf0231
theorem linear_bf0519 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_3 116 := by
  simpa only [linear_v123_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g337 linear_b134 7 109 linear_bf0230 linear_bf0518)
theorem linear_bf0520 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_2 334 := by
  simpa only [linear_v123_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g334 ++ linear_b133) (44 :: linear_v123_3) 217 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g334 linear_b133 9 208 linear_bf0228 linear_bf0517) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_3 116 (by decide +kernel) linear_bf0519))
theorem linear_bf0521 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_1 1009 := by
  simpa only [linear_v123_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g317 ++ linear_b125) (44 :: linear_v123_2) 674 335 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g317 linear_b125 6 668 linear_bf0218 linear_bf0516) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_2 334 (by decide +kernel) linear_bf0520))
theorem linear_bf0522 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_0 1026 := by
  simpa only [linear_v123_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g314 ++ linear_b124) (44 :: linear_v123_1) 16 1010 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g314 linear_b124 5 11 linear_bf0216 linear_bf0501) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_1 1009 (by decide +kernel) linear_bf0521))
theorem linear_bf0523 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b123 1028 := by
  simpa only [linear_b123] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g313 (linear_v123_0 ++ linear_g339) 1 1027 linear_bf0215 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v123_0 linear_g339 1026 1 linear_bf0522 linear_bf0232))
theorem linear_bf0524 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b136 11 := by
  simpa only [linear_b136] using linear_bf0235
theorem linear_bf0525 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b137 156 := by
  simpa only [linear_b137] using linear_bf0237
theorem linear_bf0526 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b138 208 := by
  simpa only [linear_b138] using linear_bf0239
theorem linear_bf0527 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b139 34 := by
  simpa only [linear_b139] using linear_bf0241
theorem linear_bf0528 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_3 41 := by
  simpa only [linear_v135_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g351 linear_b139 7 34 linear_bf0240 linear_bf0527)
theorem linear_bf0529 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_2 259 := by
  simpa only [linear_v135_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g348 ++ linear_b138) (44 :: linear_v135_3) 217 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g348 linear_b138 9 208 linear_bf0238 linear_bf0526) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_3 41 (by decide +kernel) linear_bf0528))
theorem linear_bf0530 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_1 422 := by
  simpa only [linear_v135_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g345 ++ linear_b137) (44 :: linear_v135_2) 162 260 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g345 linear_b137 6 156 linear_bf0236 linear_bf0525) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_2 259 (by decide +kernel) linear_bf0529))
theorem linear_bf0531 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_0 439 := by
  simpa only [linear_v135_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g342 ++ linear_b136) (44 :: linear_v135_1) 16 423 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g342 linear_b136 5 11 linear_bf0234 linear_bf0524) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_1 422 (by decide +kernel) linear_bf0530))
theorem linear_bf0532 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b135 441 := by
  simpa only [linear_b135] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g341 (linear_v135_0 ++ linear_g353) 1 440 linear_bf0233 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v135_0 linear_g353 439 1 linear_bf0531 linear_bf0242))
theorem linear_bf0533 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b141 12 := by
  simpa only [linear_b141] using linear_bf0245
theorem linear_bf0534 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b142 209 := by
  simpa only [linear_b142] using linear_bf0247
theorem linear_bf0535 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b143 210 := by
  simpa only [linear_b143] using linear_bf0249
theorem linear_bf0536 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b144 221 := by
  simpa only [linear_b144] using linear_bf0251
theorem linear_bf0537 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_3 228 := by
  simpa only [linear_v140_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g365 linear_b144 7 221 linear_bf0250 linear_bf0536)
theorem linear_bf0538 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_2 448 := by
  simpa only [linear_v140_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g362 ++ linear_b143) (44 :: linear_v140_3) 219 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g362 linear_b143 9 210 linear_bf0248 linear_bf0535) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_3 228 (by decide +kernel) linear_bf0537))
theorem linear_bf0539 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_1 664 := by
  simpa only [linear_v140_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g359 ++ linear_b142) (44 :: linear_v140_2) 215 449 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g359 linear_b142 6 209 linear_bf0246 linear_bf0534) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_2 448 (by decide +kernel) linear_bf0538))
theorem linear_bf0540 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_0 682 := by
  simpa only [linear_v140_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g356 ++ linear_b141) (44 :: linear_v140_1) 17 665 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g356 linear_b141 5 12 linear_bf0244 linear_bf0533) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_1 664 (by decide +kernel) linear_bf0539))
theorem linear_bf0541 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b140 684 := by
  simpa only [linear_b140] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g355 (linear_v140_0 ++ linear_g367) 1 683 linear_bf0243 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v140_0 linear_g367 682 1 linear_bf0540 linear_bf0252))
theorem linear_bf0542 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b146 12 := by
  simpa only [linear_b146] using linear_bf0255
theorem linear_bf0543 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b147 209 := by
  simpa only [linear_b147] using linear_bf0257
theorem linear_bf0544 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b148 243 := by
  simpa only [linear_b148] using linear_bf0259
theorem linear_bf0545 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b149 243 := by
  simpa only [linear_b149] using linear_bf0261
theorem linear_bf0546 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_3 250 := by
  simpa only [linear_v145_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g379 linear_b149 7 243 linear_bf0260 linear_bf0545)
theorem linear_bf0547 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_2 503 := by
  simpa only [linear_v145_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g376 ++ linear_b148) (44 :: linear_v145_3) 252 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g376 linear_b148 9 243 linear_bf0258 linear_bf0544) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_3 250 (by decide +kernel) linear_bf0546))
theorem linear_bf0548 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_1 719 := by
  simpa only [linear_v145_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g373 ++ linear_b147) (44 :: linear_v145_2) 215 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g373 linear_b147 6 209 linear_bf0256 linear_bf0543) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_2 503 (by decide +kernel) linear_bf0547))
theorem linear_bf0549 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_0 737 := by
  simpa only [linear_v145_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g370 ++ linear_b146) (44 :: linear_v145_1) 17 720 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g370 linear_b146 5 12 linear_bf0254 linear_bf0542) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_1 719 (by decide +kernel) linear_bf0548))
theorem linear_bf0550 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b145 739 := by
  simpa only [linear_b145] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g369 (linear_v145_0 ++ linear_g381) 1 738 linear_bf0253 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v145_0 linear_g381 737 1 linear_bf0549 linear_bf0262))
theorem linear_bf0551 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_20 739 := by
  simpa only [linear_v4_20] using linear_bf0550
theorem linear_bf0552 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_19 1424 := by
  simpa only [linear_v4_19] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b140 (44 :: linear_v4_20) 684 740 linear_bf0541 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_20 739 (by decide +kernel) linear_bf0551))
theorem linear_bf0553 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_18 1866 := by
  simpa only [linear_v4_18] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b135 (44 :: linear_v4_19) 441 1425 linear_bf0532 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_19 1424 (by decide +kernel) linear_bf0552))
theorem linear_bf0554 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_17 2895 := by
  simpa only [linear_v4_17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b123 (44 :: linear_v4_18) 1028 1867 linear_bf0523 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_18 1866 (by decide +kernel) linear_bf0553))
theorem linear_bf0555 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_16 3495 := by
  simpa only [linear_v4_16] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b118 (44 :: linear_v4_17) 599 2896 linear_bf0500 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_17 2895 (by decide +kernel) linear_bf0554))
theorem linear_bf0556 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_15 3998 := by
  simpa only [linear_v4_15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b113 (44 :: linear_v4_16) 502 3496 linear_bf0491 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_16 3495 (by decide +kernel) linear_bf0555))
theorem linear_bf0557 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_14 5369 := by
  simpa only [linear_v4_14] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b97 (44 :: linear_v4_15) 1370 3999 linear_bf0482 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_15 3998 (by decide +kernel) linear_bf0556))
theorem linear_bf0558 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_13 5914 := by
  simpa only [linear_v4_13] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b92 (44 :: linear_v4_14) 544 5370 linear_bf0451 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_14 5369 (by decide +kernel) linear_bf0557))
theorem linear_bf0559 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_12 6352 := by
  simpa only [linear_v4_12] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b87 (44 :: linear_v4_13) 437 5915 linear_bf0442 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_13 5914 (by decide +kernel) linear_bf0558))
theorem linear_bf0560 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_11 7348 := by
  simpa only [linear_v4_11] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b75 (44 :: linear_v4_12) 995 6353 linear_bf0433 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_12 6352 (by decide +kernel) linear_bf0559))
theorem linear_bf0561 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_10 7926 := by
  simpa only [linear_v4_10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b70 (44 :: linear_v4_11) 577 7349 linear_bf0410 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_11 7348 (by decide +kernel) linear_bf0560))
theorem linear_bf0562 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_9 8416 := by
  simpa only [linear_v4_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b65 (44 :: linear_v4_10) 489 7927 linear_bf0401 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_10 7926 (by decide +kernel) linear_bf0561))
theorem linear_bf0563 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_8 9750 := by
  simpa only [linear_v4_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b49 (44 :: linear_v4_9) 1333 8417 linear_bf0392 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_9 8416 (by decide +kernel) linear_bf0562))
theorem linear_bf0564 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_7 10276 := by
  simpa only [linear_v4_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b44 (44 :: linear_v4_8) 525 9751 linear_bf0361 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_8 9750 (by decide +kernel) linear_bf0563))
theorem linear_bf0565 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_6 10744 := by
  simpa only [linear_v4_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b39 (44 :: linear_v4_7) 467 10277 linear_bf0352 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_7 10276 (by decide +kernel) linear_bf0564))
theorem linear_bf0566 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_5 11381 := by
  simpa only [linear_v4_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b34 (44 :: linear_v4_6) 636 10745 linear_bf0343 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_6 10744 (by decide +kernel) linear_bf0565))
theorem linear_bf0567 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_4 11919 := by
  simpa only [linear_v4_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b29 (44 :: linear_v4_5) 537 11382 linear_bf0334 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_5 11381 (by decide +kernel) linear_bf0566))
theorem linear_bf0568 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_3 12504 := by
  simpa only [linear_v4_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b24 (44 :: linear_v4_4) 584 11920 linear_bf0325 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_4 11919 (by decide +kernel) linear_bf0567))
theorem linear_bf0569 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_2 13137 := by
  simpa only [linear_v4_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b15 (44 :: linear_v4_3) 632 12505 linear_bf0316 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_3 12504 (by decide +kernel) linear_bf0568))
theorem linear_bf0570 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_1 13656 := by
  simpa only [linear_v4_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b10 (44 :: linear_v4_2) 518 13138 linear_bf0299 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_2 13137 (by decide +kernel) linear_bf0569))
theorem linear_bf0571 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_0 14181 := by
  simpa only [linear_v4_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b5 (44 :: linear_v4_1) 524 13657 linear_bf0290 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_1 13656 (by decide +kernel) linear_bf0570))
theorem linear_bf0572 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b4 14183 := by
  simpa only [linear_b4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g8 (linear_v4_0 ++ linear_g382) 1 14182 linear_bf0007 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v4_0 linear_g382 14181 1 linear_bf0571 linear_bf0263))
theorem linear_bf0573 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b150 31 := by
  simpa only [linear_b150] using linear_bf0265
theorem linear_bf0574 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b151 13 := by
  simpa only [linear_b151] using linear_bf0267
theorem linear_bf0575 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b152 11 := by
  simpa only [linear_b152] using linear_bf0269
theorem linear_bf0576 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b153 61 := by
  simpa only [linear_b153] using linear_bf0271
theorem linear_bf0577 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b154 7 := by
  simpa only [linear_b154] using linear_bf0273
theorem linear_bf0578 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_5 17 := by
  simpa only [linear_v3_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g396 linear_b154 10 7 linear_bf0272 linear_bf0577)
theorem linear_bf0579 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_4 88 := by
  simpa only [linear_v3_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g393 ++ linear_b153) (44 :: linear_v3_5) 70 18 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g393 linear_b153 9 61 linear_bf0270 linear_bf0576) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_5 17 (by decide +kernel) linear_bf0578))
theorem linear_bf0580 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_3 107 := by
  simpa only [linear_v3_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g390 ++ linear_b152) (44 :: linear_v3_4) 18 89 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g390 linear_b152 7 11 linear_bf0268 linear_bf0575) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_4 88 (by decide +kernel) linear_bf0579))
theorem linear_bf0581 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_2 129 := by
  simpa only [linear_v3_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g387 ++ linear_b151) (44 :: linear_v3_3) 21 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g387 linear_b151 8 13 linear_bf0266 linear_bf0574) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_3 107 (by decide +kernel) linear_bf0580))
theorem linear_bf0582 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_1 171 := by
  simpa only [linear_v3_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g384 ++ linear_b150) (44 :: linear_v3_2) 41 130 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g384 linear_b150 10 31 linear_bf0264 linear_bf0573) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_2 129 (by decide +kernel) linear_bf0581))
theorem linear_bf0583 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_0 14364 := by
  simpa only [linear_v3_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g7 ++ linear_b4) (44 :: linear_v3_1) 14192 172 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g7 linear_b4 9 14183 linear_bf0006 linear_bf0572) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_1 171 (by decide +kernel) linear_bf0582))
theorem linear_bf0584 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b3 14366 := by
  simpa only [linear_b3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g6 (linear_v3_0 ++ linear_g398) 1 14365 linear_bf0005 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v3_0 linear_g398 14364 1 linear_bf0583 linear_bf0274))
theorem linear_bf0585 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v2_0 14366 := by
  simpa only [linear_v2_0] using linear_bf0584
theorem linear_bf0586 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b2 14368 := by
  simpa only [linear_b2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g5 (linear_v2_0 ++ linear_g399) 1 14367 linear_bf0004 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v2_0 linear_g399 14366 1 linear_bf0585 linear_bf0275))
theorem linear_bf0587 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b155 18 := by
  simpa only [linear_b155] using linear_bf0277
theorem linear_bf0588 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b156 22 := by
  simpa only [linear_b156] using linear_bf0279
theorem linear_bf0589 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_3 31 := by
  simpa only [linear_v0_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g404 linear_b156 9 22 linear_bf0278 linear_bf0588)
theorem linear_bf0590 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_2 59 := by
  simpa only [linear_v0_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g401 ++ linear_b155) (44 :: linear_v0_3) 27 32 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g401 linear_b155 9 18 linear_bf0276 linear_bf0587) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_3 31 (by decide +kernel) linear_bf0589))
theorem linear_bf0591 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_1 14440 := by
  simpa only [linear_v0_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g4 ++ linear_b2) (44 :: linear_v0_2) 14380 60 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g4 linear_b2 12 14368 linear_bf0003 linear_bf0586) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_2 59 (by decide +kernel) linear_bf0590))
theorem linear_bf0592 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_0 14464 := by
  simpa only [linear_v0_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g1 ++ linear_b1) (44 :: linear_v0_1) 23 14441 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g1 linear_b1 10 13 linear_bf0001 linear_bf0281) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_1 14440 (by decide +kernel) linear_bf0591))
theorem linear_bf0593 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b0 14466 := by
  simpa only [linear_b0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g0 (linear_v0_0 ++ linear_g406) 1 14465 linear_bf0000 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v0_0 linear_g406 14464 1 linear_bf0592 linear_bf0280))
theorem linear_bf0594 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linearBytes 14466 := by
  simpa only [linearBytes] using linear_bf0593
theorem linear_length : linearBytes.length ≤ transportByteLimit := by
  rw [(linear_bf0594).1]
  decide +kernel
theorem linear_byte_range : linearBytes.all (fun byte => decide (byte ≤ 255)) = true := by exact (linear_bf0594).2
theorem linear_transport : checkedEncode linearRaw = some linearBytes := checkedEncode_of_parts linearRaw linearBytes linear_bounds linear_serialized linear_parsed linear_length linear_byte_range
def parallel_g0 : List Nat := [123]
def parallel_g1 : List Nat := [34,101,120,112,111,114,116,115,34,58]
def parallel_g2 : List Nat := [91,34,99,97,108,99,117,108,97,116,101,34,93]
def parallel_g3 : List Nat := [44]
def parallel_g4 : List Nat := [34,102,117,110,99,116,105,111,110,115,34,58]
def parallel_g5 : List Nat := [91]
def parallel_g6 : List Nat := [123]
def parallel_g7 : List Nat := [34,98,108,111,99,107,115,34,58]
def parallel_g8 : List Nat := [91]
def parallel_g9 : List Nat := [123]
def parallel_g10 : List Nat := [34,105,100,34,58]
def parallel_g11 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def parallel_g12 : List Nat := [44]
def parallel_g13 : List Nat := [34,111,112,115,34,58]
def parallel_g14 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,116,114,121,95,110,101,119,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,93]
def parallel_g15 : List Nat := [44]
def parallel_g16 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g17 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def parallel_g18 : List Nat := [44]
def parallel_g19 : List Nat := [34,116,101,114,109,34,58]
def parallel_g20 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,125,125]
def parallel_g21 : List Nat := [125]
def parallel_g22 : List Nat := [44]
def parallel_g23 : List Nat := [123]
def parallel_g24 : List Nat := [34,105,100,34,58]
def parallel_g25 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,49,34]
def parallel_g26 : List Nat := [44]
def parallel_g27 : List Nat := [34,111,112,115,34,58]
def parallel_g28 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def parallel_g29 : List Nat := [44]
def parallel_g30 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g31 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g32 : List Nat := [44]
def parallel_g33 : List Nat := [34,116,101,114,109,34,58]
def parallel_g34 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,52,34,44,34,100,103,95,118,95,56,34,44,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,57,34,44,34,100,103,95,118,95,49,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,125]
def parallel_g35 : List Nat := [125]
def parallel_g36 : List Nat := [44]
def parallel_g37 : List Nat := [123]
def parallel_g38 : List Nat := [34,105,100,34,58]
def parallel_g39 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,50,34]
def parallel_g40 : List Nat := [44]
def parallel_g41 : List Nat := [34,111,112,115,34,58]
def parallel_g42 : List Nat := [91]
def parallel_g43 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g44 : List Nat := [44]
def parallel_g45 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,48,48,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g46 : List Nat := [44]
def parallel_g47 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g48 : List Nat := [44]
def parallel_g49 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,34,44,34,100,103,95,118,95,49,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g50 : List Nat := [93]
def parallel_g51 : List Nat := [44]
def parallel_g52 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g53 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g54 : List Nat := [44]
def parallel_g55 : List Nat := [34,116,101,114,109,34,58]
def parallel_g56 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,56,34,93,125]
def parallel_g57 : List Nat := [125]
def parallel_g58 : List Nat := [44]
def parallel_g59 : List Nat := [123]
def parallel_g60 : List Nat := [34,105,100,34,58]
def parallel_g61 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,51,34]
def parallel_g62 : List Nat := [44]
def parallel_g63 : List Nat := [34,111,112,115,34,58]
def parallel_g64 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g65 : List Nat := [44]
def parallel_g66 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g67 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g68 : List Nat := [44]
def parallel_g69 : List Nat := [34,116,101,114,109,34,58]
def parallel_g70 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,50,53,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,48,34,125,125]
def parallel_g71 : List Nat := [125]
def parallel_g72 : List Nat := [44]
def parallel_g73 : List Nat := [123]
def parallel_g74 : List Nat := [34,105,100,34,58]
def parallel_g75 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,52,34]
def parallel_g76 : List Nat := [44]
def parallel_g77 : List Nat := [34,111,112,115,34,58]
def parallel_g78 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,50,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def parallel_g79 : List Nat := [44]
def parallel_g80 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g81 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g82 : List Nat := [44]
def parallel_g83 : List Nat := [34,116,101,114,109,34,58]
def parallel_g84 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,50,56,34,44,34,100,103,95,118,95,50,57,34,44,34,100,103,95,118,95,51,50,34,44,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,51,51,34,44,34,100,103,95,118,95,51,52,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,125]
def parallel_g85 : List Nat := [125]
def parallel_g86 : List Nat := [44]
def parallel_g87 : List Nat := [123]
def parallel_g88 : List Nat := [34,105,100,34,58]
def parallel_g89 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,53,34]
def parallel_g90 : List Nat := [44]
def parallel_g91 : List Nat := [34,111,112,115,34,58]
def parallel_g92 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,51,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g93 : List Nat := [44]
def parallel_g94 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g95 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g96 : List Nat := [44]
def parallel_g97 : List Nat := [34,116,101,114,109,34,58]
def parallel_g98 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,52,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,49,34,125,125]
def parallel_g99 : List Nat := [125]
def parallel_g100 : List Nat := [44]
def parallel_g101 : List Nat := [123]
def parallel_g102 : List Nat := [34,105,100,34,58]
def parallel_g103 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,54,34]
def parallel_g104 : List Nat := [44]
def parallel_g105 : List Nat := [34,111,112,115,34,58]
def parallel_g106 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def parallel_g107 : List Nat := [44]
def parallel_g108 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g109 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,53,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g110 : List Nat := [44]
def parallel_g111 : List Nat := [34,116,101,114,109,34,58]
def parallel_g112 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,52,54,34,93,125]
def parallel_g113 : List Nat := [125]
def parallel_g114 : List Nat := [44]
def parallel_g115 : List Nat := [123]
def parallel_g116 : List Nat := [34,105,100,34,58]
def parallel_g117 : List Nat := [34,100,103,95,102,97,115,116,95,48,34]
def parallel_g118 : List Nat := [44]
def parallel_g119 : List Nat := [34,111,112,115,34,58]
def parallel_g120 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,54,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g121 : List Nat := [44]
def parallel_g122 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g123 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g124 : List Nat := [44]
def parallel_g125 : List Nat := [34,116,101,114,109,34,58]
def parallel_g126 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,53,54,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def parallel_g127 : List Nat := [125]
def parallel_g128 : List Nat := [44]
def parallel_g129 : List Nat := [123]
def parallel_g130 : List Nat := [34,105,100,34,58]
def parallel_g131 : List Nat := [34,100,103,95,102,97,115,116,95,49,34]
def parallel_g132 : List Nat := [44]
def parallel_g133 : List Nat := [34,111,112,115,34,58]
def parallel_g134 : List Nat := [91]
def parallel_g135 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def parallel_g136 : List Nat := [44]
def parallel_g137 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,50,34,44,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,51,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def parallel_g138 : List Nat := [44]
def parallel_g139 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,52,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g140 : List Nat := [44]
def parallel_g141 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g142 : List Nat := [44]
def parallel_g143 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,52,34,44,34,100,103,95,118,95,54,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,54,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g144 : List Nat := [44]
def parallel_g145 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,54,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g146 : List Nat := [44]
def parallel_g147 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,56,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def parallel_g148 : List Nat := [44]
def parallel_g149 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,44,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g150 : List Nat := [44]
def parallel_g151 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g152 : List Nat := [44]
def parallel_g153 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g154 : List Nat := [44]
def parallel_g155 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g156 : List Nat := [93]
def parallel_g157 : List Nat := [44]
def parallel_g158 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g159 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g160 : List Nat := [44]
def parallel_g161 : List Nat := [34,116,101,114,109,34,58]
def parallel_g162 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,55,34,44,34,100,103,95,118,95,53,56,34,44,34,100,103,95,118,95,53,57,34,44,34,100,103,95,118,95,54,48,34,44,34,100,103,95,118,95,55,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,48,34,125]
def parallel_g163 : List Nat := [125]
def parallel_g164 : List Nat := [44]
def parallel_g165 : List Nat := [123]
def parallel_g166 : List Nat := [34,105,100,34,58]
def parallel_g167 : List Nat := [34,100,103,95,102,97,115,116,95,50,34]
def parallel_g168 : List Nat := [44]
def parallel_g169 : List Nat := [34,111,112,115,34,58]
def parallel_g170 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def parallel_g171 : List Nat := [44]
def parallel_g172 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g173 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g174 : List Nat := [44]
def parallel_g175 : List Nat := [34,116,101,114,109,34,58]
def parallel_g176 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,50,34,44,34,100,103,95,118,95,55,51,34,44,34,100,103,95,118,95,55,54,34,44,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,55,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def parallel_g177 : List Nat := [125]
def parallel_g178 : List Nat := [44]
def parallel_g179 : List Nat := [123]
def parallel_g180 : List Nat := [34,105,100,34,58]
def parallel_g181 : List Nat := [34,100,103,95,102,97,115,116,95,51,34]
def parallel_g182 : List Nat := [44]
def parallel_g183 : List Nat := [34,111,112,115,34,58]
def parallel_g184 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,51,34,44,34,100,103,95,118,95,56,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g185 : List Nat := [44]
def parallel_g186 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g187 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g188 : List Nat := [44]
def parallel_g189 : List Nat := [34,116,101,114,109,34,58]
def parallel_g190 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,56,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def parallel_g191 : List Nat := [125]
def parallel_g192 : List Nat := [44]
def parallel_g193 : List Nat := [123]
def parallel_g194 : List Nat := [34,105,100,34,58]
def parallel_g195 : List Nat := [34,100,103,95,102,97,115,116,95,52,34]
def parallel_g196 : List Nat := [44]
def parallel_g197 : List Nat := [34,111,112,115,34,58]
def parallel_g198 : List Nat := [91]
def parallel_g199 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,49,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def parallel_g200 : List Nat := [44]
def parallel_g201 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,44,34,100,103,95,118,95,57,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g202 : List Nat := [44]
def parallel_g203 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g204 : List Nat := [44]
def parallel_g205 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,50,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g206 : List Nat := [44]
def parallel_g207 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,56,34,44,34,100,103,95,118,95,57,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g208 : List Nat := [44]
def parallel_g209 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g210 : List Nat := [44]
def parallel_g211 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,48,34,44,34,100,103,95,118,95,57,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g212 : List Nat := [93]
def parallel_g213 : List Nat := [44]
def parallel_g214 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g215 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g216 : List Nat := [44]
def parallel_g217 : List Nat := [34,116,101,114,109,34,58]
def parallel_g218 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,53,34,44,34,100,103,95,118,95,56,54,34,44,34,100,103,95,118,95,56,55,34,44,34,100,103,95,118,95,57,52,34,44,34,100,103,95,118,95,56,57,34,44,34,100,103,95,118,95,57,54,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def parallel_g219 : List Nat := [125]
def parallel_g220 : List Nat := [44]
def parallel_g221 : List Nat := [123]
def parallel_g222 : List Nat := [34,105,100,34,58]
def parallel_g223 : List Nat := [34,100,103,95,102,97,115,116,95,53,34]
def parallel_g224 : List Nat := [44]
def parallel_g225 : List Nat := [34,111,112,115,34,58]
def parallel_g226 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def parallel_g227 : List Nat := [44]
def parallel_g228 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g229 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,48,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g230 : List Nat := [44]
def parallel_g231 : List Nat := [34,116,101,114,109,34,58]
def parallel_g232 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,48,48,34,93,125]
def parallel_g233 : List Nat := [125]
def parallel_g234 : List Nat := [44]
def parallel_g235 : List Nat := [123]
def parallel_g236 : List Nat := [34,105,100,34,58]
def parallel_g237 : List Nat := [34,100,103,95,115,108,111,119,95,48,34]
def parallel_g238 : List Nat := [44]
def parallel_g239 : List Nat := [34,111,112,115,34,58]
def parallel_g240 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,56,34,44,34,100,103,95,118,95,49,48,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,57,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g241 : List Nat := [44]
def parallel_g242 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g243 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g244 : List Nat := [44]
def parallel_g245 : List Nat := [34,116,101,114,109,34,58]
def parallel_g246 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,48,57,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,125]
def parallel_g247 : List Nat := [125]
def parallel_g248 : List Nat := [44]
def parallel_g249 : List Nat := [123]
def parallel_g250 : List Nat := [34,105,100,34,58]
def parallel_g251 : List Nat := [34,100,103,95,115,108,111,119,95,49,34]
def parallel_g252 : List Nat := [44]
def parallel_g253 : List Nat := [34,111,112,115,34,58]
def parallel_g254 : List Nat := [91]
def parallel_g255 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def parallel_g256 : List Nat := [44]
def parallel_g257 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,53,34,44,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def parallel_g258 : List Nat := [44]
def parallel_g259 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g260 : List Nat := [44]
def parallel_g261 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,56,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g262 : List Nat := [44]
def parallel_g263 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,55,34,44,34,100,103,95,118,95,49,49,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,57,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g264 : List Nat := [44]
def parallel_g265 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,57,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,48,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g266 : List Nat := [44]
def parallel_g267 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,49,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def parallel_g268 : List Nat := [44]
def parallel_g269 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,44,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g270 : List Nat := [44]
def parallel_g271 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g272 : List Nat := [44]
def parallel_g273 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g274 : List Nat := [44]
def parallel_g275 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g276 : List Nat := [93]
def parallel_g277 : List Nat := [44]
def parallel_g278 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g279 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g280 : List Nat := [44]
def parallel_g281 : List Nat := [34,116,101,114,109,34,58]
def parallel_g282 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,48,34,44,34,100,103,95,118,95,49,49,49,34,44,34,100,103,95,118,95,49,49,50,34,44,34,100,103,95,118,95,49,49,51,34,44,34,100,103,95,118,95,49,50,51,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,48,34,125]
def parallel_g283 : List Nat := [125]
def parallel_g284 : List Nat := [44]
def parallel_g285 : List Nat := [123]
def parallel_g286 : List Nat := [34,105,100,34,58]
def parallel_g287 : List Nat := [34,100,103,95,115,108,111,119,95,50,34]
def parallel_g288 : List Nat := [44]
def parallel_g289 : List Nat := [34,111,112,115,34,58]
def parallel_g290 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,57,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def parallel_g291 : List Nat := [44]
def parallel_g292 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g293 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g294 : List Nat := [44]
def parallel_g295 : List Nat := [34,116,101,114,109,34,58]
def parallel_g296 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,50,53,34,44,34,100,103,95,118,95,49,50,54,34,44,34,100,103,95,118,95,49,50,57,34,44,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,51,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def parallel_g297 : List Nat := [125]
def parallel_g298 : List Nat := [44]
def parallel_g299 : List Nat := [123]
def parallel_g300 : List Nat := [34,105,100,34,58]
def parallel_g301 : List Nat := [34,100,103,95,115,108,111,119,95,51,34]
def parallel_g302 : List Nat := [44]
def parallel_g303 : List Nat := [34,111,112,115,34,58]
def parallel_g304 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,54,34,44,34,100,103,95,118,95,49,51,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,55,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g305 : List Nat := [44]
def parallel_g306 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g307 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g308 : List Nat := [44]
def parallel_g309 : List Nat := [34,116,101,114,109,34,58]
def parallel_g310 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,51,55,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,125]
def parallel_g311 : List Nat := [125]
def parallel_g312 : List Nat := [44]
def parallel_g313 : List Nat := [123]
def parallel_g314 : List Nat := [34,105,100,34,58]
def parallel_g315 : List Nat := [34,100,103,95,115,108,111,119,95,52,34]
def parallel_g316 : List Nat := [44]
def parallel_g317 : List Nat := [34,111,112,115,34,58]
def parallel_g318 : List Nat := [91]
def parallel_g319 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,52,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def parallel_g320 : List Nat := [44]
def parallel_g321 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,44,34,100,103,95,118,95,49,52,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def parallel_g322 : List Nat := [44]
def parallel_g323 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def parallel_g324 : List Nat := [44]
def parallel_g325 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g326 : List Nat := [44]
def parallel_g327 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,49,34,44,34,100,103,95,118,95,49,52,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def parallel_g328 : List Nat := [44]
def parallel_g329 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g330 : List Nat := [44]
def parallel_g331 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,51,34,44,34,100,103,95,118,95,49,52,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def parallel_g332 : List Nat := [93]
def parallel_g333 : List Nat := [44]
def parallel_g334 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g335 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g336 : List Nat := [44]
def parallel_g337 : List Nat := [34,116,101,114,109,34,58]
def parallel_g338 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,56,34,44,34,100,103,95,118,95,49,51,57,34,44,34,100,103,95,118,95,49,52,48,34,44,34,100,103,95,118,95,49,52,55,34,44,34,100,103,95,118,95,49,52,50,34,44,34,100,103,95,118,95,49,52,57,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def parallel_g339 : List Nat := [125]
def parallel_g340 : List Nat := [44]
def parallel_g341 : List Nat := [123]
def parallel_g342 : List Nat := [34,105,100,34,58]
def parallel_g343 : List Nat := [34,100,103,95,115,108,111,119,95,53,34]
def parallel_g344 : List Nat := [44]
def parallel_g345 : List Nat := [34,111,112,115,34,58]
def parallel_g346 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def parallel_g347 : List Nat := [44]
def parallel_g348 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g349 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g350 : List Nat := [44]
def parallel_g351 : List Nat := [34,116,101,114,109,34,58]
def parallel_g352 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,53,51,34,93,125]
def parallel_g353 : List Nat := [125]
def parallel_g354 : List Nat := [44]
def parallel_g355 : List Nat := [123]
def parallel_g356 : List Nat := [34,105,100,34,58]
def parallel_g357 : List Nat := [34,100,103,95,103,117,97,114,100,95,48,34]
def parallel_g358 : List Nat := [44]
def parallel_g359 : List Nat := [34,111,112,115,34,58]
def parallel_g360 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,50,34,44,34,100,103,95,118,95,49,54,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g361 : List Nat := [44]
def parallel_g362 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g363 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g364 : List Nat := [44]
def parallel_g365 : List Nat := [34,116,101,114,109,34,58]
def parallel_g366 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,54,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def parallel_g367 : List Nat := [125]
def parallel_g368 : List Nat := [44]
def parallel_g369 : List Nat := [123]
def parallel_g370 : List Nat := [34,105,100,34,58]
def parallel_g371 : List Nat := [34,100,103,95,103,117,97,114,100,95,49,34]
def parallel_g372 : List Nat := [44]
def parallel_g373 : List Nat := [34,111,112,115,34,58]
def parallel_g374 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,55,49,34,44,34,100,103,95,118,95,49,55,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def parallel_g375 : List Nat := [44]
def parallel_g376 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g377 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def parallel_g378 : List Nat := [44]
def parallel_g379 : List Nat := [34,116,101,114,109,34,58]
def parallel_g380 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,55,51,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def parallel_g381 : List Nat := [125]
def parallel_g382 : List Nat := [93]
def parallel_g383 : List Nat := [44]
def parallel_g384 : List Nat := [34,101,102,102,101,99,116,115,34,58]
def parallel_g385 : List Nat := [91,34,97,108,108,111,99,34,44,34,114,101,97,100,34,44,34,116,114,97,112,34,44,34,119,114,105,116,101,34,93]
def parallel_g386 : List Nat := [44]
def parallel_g387 : List Nat := [34,101,110,116,114,121,34,58]
def parallel_g388 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def parallel_g389 : List Nat := [44]
def parallel_g390 : List Nat := [34,110,97,109,101,34,58]
def parallel_g391 : List Nat := [34,99,97,108,99,117,108,97,116,101,34]
def parallel_g392 : List Nat := [44]
def parallel_g393 : List Nat := [34,112,97,114,97,109,115,34,58]
def parallel_g394 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def parallel_g395 : List Nat := [44]
def parallel_g396 : List Nat := [34,114,101,116,117,114,110,115,34,58]
def parallel_g397 : List Nat := [91,34,117,54,52,34,93]
def parallel_g398 : List Nat := [125]
def parallel_g399 : List Nat := [93]
def parallel_g400 : List Nat := [44]
def parallel_g401 : List Nat := [34,109,111,100,117,108,101,34,58]
def parallel_g402 : List Nat := [34,114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114,34]
def parallel_g403 : List Nat := [44]
def parallel_g404 : List Nat := [34,115,99,104,101,109,97,34,58]
def parallel_g405 : List Nat := [34,104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49,34]
def parallel_g406 : List Nat := [125]
def parallel_t407 : List Nat := []
def parallel_t406 : List Nat := parallel_g406 ++ parallel_t407
def parallel_t405 : List Nat := parallel_g405 ++ parallel_t406
def parallel_t404 : List Nat := parallel_g404 ++ parallel_t405
def parallel_t403 : List Nat := parallel_g403 ++ parallel_t404
def parallel_t402 : List Nat := parallel_g402 ++ parallel_t403
def parallel_t401 : List Nat := parallel_g401 ++ parallel_t402
def parallel_t400 : List Nat := parallel_g400 ++ parallel_t401
def parallel_t399 : List Nat := parallel_g399 ++ parallel_t400
def parallel_t398 : List Nat := parallel_g398 ++ parallel_t399
def parallel_t397 : List Nat := parallel_g397 ++ parallel_t398
def parallel_t396 : List Nat := parallel_g396 ++ parallel_t397
def parallel_t395 : List Nat := parallel_g395 ++ parallel_t396
def parallel_t394 : List Nat := parallel_g394 ++ parallel_t395
def parallel_t393 : List Nat := parallel_g393 ++ parallel_t394
def parallel_t392 : List Nat := parallel_g392 ++ parallel_t393
def parallel_t391 : List Nat := parallel_g391 ++ parallel_t392
def parallel_t390 : List Nat := parallel_g390 ++ parallel_t391
def parallel_t389 : List Nat := parallel_g389 ++ parallel_t390
def parallel_t388 : List Nat := parallel_g388 ++ parallel_t389
def parallel_t387 : List Nat := parallel_g387 ++ parallel_t388
def parallel_t386 : List Nat := parallel_g386 ++ parallel_t387
def parallel_t385 : List Nat := parallel_g385 ++ parallel_t386
def parallel_t384 : List Nat := parallel_g384 ++ parallel_t385
def parallel_t383 : List Nat := parallel_g383 ++ parallel_t384
def parallel_t382 : List Nat := parallel_g382 ++ parallel_t383
def parallel_t381 : List Nat := parallel_g381 ++ parallel_t382
def parallel_t380 : List Nat := parallel_g380 ++ parallel_t381
def parallel_t379 : List Nat := parallel_g379 ++ parallel_t380
def parallel_t378 : List Nat := parallel_g378 ++ parallel_t379
def parallel_t377 : List Nat := parallel_g377 ++ parallel_t378
def parallel_t376 : List Nat := parallel_g376 ++ parallel_t377
def parallel_t375 : List Nat := parallel_g375 ++ parallel_t376
def parallel_t374 : List Nat := parallel_g374 ++ parallel_t375
def parallel_t373 : List Nat := parallel_g373 ++ parallel_t374
def parallel_t372 : List Nat := parallel_g372 ++ parallel_t373
def parallel_t371 : List Nat := parallel_g371 ++ parallel_t372
def parallel_t370 : List Nat := parallel_g370 ++ parallel_t371
def parallel_t369 : List Nat := parallel_g369 ++ parallel_t370
def parallel_t368 : List Nat := parallel_g368 ++ parallel_t369
def parallel_t367 : List Nat := parallel_g367 ++ parallel_t368
def parallel_t366 : List Nat := parallel_g366 ++ parallel_t367
def parallel_t365 : List Nat := parallel_g365 ++ parallel_t366
def parallel_t364 : List Nat := parallel_g364 ++ parallel_t365
def parallel_t363 : List Nat := parallel_g363 ++ parallel_t364
def parallel_t362 : List Nat := parallel_g362 ++ parallel_t363
def parallel_t361 : List Nat := parallel_g361 ++ parallel_t362
def parallel_t360 : List Nat := parallel_g360 ++ parallel_t361
def parallel_t359 : List Nat := parallel_g359 ++ parallel_t360
def parallel_t358 : List Nat := parallel_g358 ++ parallel_t359
def parallel_t357 : List Nat := parallel_g357 ++ parallel_t358
def parallel_t356 : List Nat := parallel_g356 ++ parallel_t357
def parallel_t355 : List Nat := parallel_g355 ++ parallel_t356
def parallel_t354 : List Nat := parallel_g354 ++ parallel_t355
def parallel_t353 : List Nat := parallel_g353 ++ parallel_t354
def parallel_t352 : List Nat := parallel_g352 ++ parallel_t353
def parallel_t351 : List Nat := parallel_g351 ++ parallel_t352
def parallel_t350 : List Nat := parallel_g350 ++ parallel_t351
def parallel_t349 : List Nat := parallel_g349 ++ parallel_t350
def parallel_t348 : List Nat := parallel_g348 ++ parallel_t349
def parallel_t347 : List Nat := parallel_g347 ++ parallel_t348
def parallel_t346 : List Nat := parallel_g346 ++ parallel_t347
def parallel_t345 : List Nat := parallel_g345 ++ parallel_t346
def parallel_t344 : List Nat := parallel_g344 ++ parallel_t345
def parallel_t343 : List Nat := parallel_g343 ++ parallel_t344
def parallel_t342 : List Nat := parallel_g342 ++ parallel_t343
def parallel_t341 : List Nat := parallel_g341 ++ parallel_t342
def parallel_t340 : List Nat := parallel_g340 ++ parallel_t341
def parallel_t339 : List Nat := parallel_g339 ++ parallel_t340
def parallel_t338 : List Nat := parallel_g338 ++ parallel_t339
def parallel_t337 : List Nat := parallel_g337 ++ parallel_t338
def parallel_t336 : List Nat := parallel_g336 ++ parallel_t337
def parallel_t335 : List Nat := parallel_g335 ++ parallel_t336
def parallel_t334 : List Nat := parallel_g334 ++ parallel_t335
def parallel_t333 : List Nat := parallel_g333 ++ parallel_t334
def parallel_t332 : List Nat := parallel_g332 ++ parallel_t333
def parallel_t331 : List Nat := parallel_g331 ++ parallel_t332
def parallel_t330 : List Nat := parallel_g330 ++ parallel_t331
def parallel_t329 : List Nat := parallel_g329 ++ parallel_t330
def parallel_t328 : List Nat := parallel_g328 ++ parallel_t329
def parallel_t327 : List Nat := parallel_g327 ++ parallel_t328
def parallel_t326 : List Nat := parallel_g326 ++ parallel_t327
def parallel_t325 : List Nat := parallel_g325 ++ parallel_t326
def parallel_t324 : List Nat := parallel_g324 ++ parallel_t325
def parallel_t323 : List Nat := parallel_g323 ++ parallel_t324
def parallel_t322 : List Nat := parallel_g322 ++ parallel_t323
def parallel_t321 : List Nat := parallel_g321 ++ parallel_t322
def parallel_t320 : List Nat := parallel_g320 ++ parallel_t321
def parallel_t319 : List Nat := parallel_g319 ++ parallel_t320
def parallel_t318 : List Nat := parallel_g318 ++ parallel_t319
def parallel_t317 : List Nat := parallel_g317 ++ parallel_t318
def parallel_t316 : List Nat := parallel_g316 ++ parallel_t317
def parallel_t315 : List Nat := parallel_g315 ++ parallel_t316
def parallel_t314 : List Nat := parallel_g314 ++ parallel_t315
def parallel_t313 : List Nat := parallel_g313 ++ parallel_t314
def parallel_t312 : List Nat := parallel_g312 ++ parallel_t313
def parallel_t311 : List Nat := parallel_g311 ++ parallel_t312
def parallel_t310 : List Nat := parallel_g310 ++ parallel_t311
def parallel_t309 : List Nat := parallel_g309 ++ parallel_t310
def parallel_t308 : List Nat := parallel_g308 ++ parallel_t309
def parallel_t307 : List Nat := parallel_g307 ++ parallel_t308
def parallel_t306 : List Nat := parallel_g306 ++ parallel_t307
def parallel_t305 : List Nat := parallel_g305 ++ parallel_t306
def parallel_t304 : List Nat := parallel_g304 ++ parallel_t305
def parallel_t303 : List Nat := parallel_g303 ++ parallel_t304
def parallel_t302 : List Nat := parallel_g302 ++ parallel_t303
def parallel_t301 : List Nat := parallel_g301 ++ parallel_t302
def parallel_t300 : List Nat := parallel_g300 ++ parallel_t301
def parallel_t299 : List Nat := parallel_g299 ++ parallel_t300
def parallel_t298 : List Nat := parallel_g298 ++ parallel_t299
def parallel_t297 : List Nat := parallel_g297 ++ parallel_t298
def parallel_t296 : List Nat := parallel_g296 ++ parallel_t297
def parallel_t295 : List Nat := parallel_g295 ++ parallel_t296
def parallel_t294 : List Nat := parallel_g294 ++ parallel_t295
def parallel_t293 : List Nat := parallel_g293 ++ parallel_t294
def parallel_t292 : List Nat := parallel_g292 ++ parallel_t293
def parallel_t291 : List Nat := parallel_g291 ++ parallel_t292
def parallel_t290 : List Nat := parallel_g290 ++ parallel_t291
def parallel_t289 : List Nat := parallel_g289 ++ parallel_t290
def parallel_t288 : List Nat := parallel_g288 ++ parallel_t289
def parallel_t287 : List Nat := parallel_g287 ++ parallel_t288
def parallel_t286 : List Nat := parallel_g286 ++ parallel_t287
def parallel_t285 : List Nat := parallel_g285 ++ parallel_t286
def parallel_t284 : List Nat := parallel_g284 ++ parallel_t285
def parallel_t283 : List Nat := parallel_g283 ++ parallel_t284
def parallel_t282 : List Nat := parallel_g282 ++ parallel_t283
def parallel_t281 : List Nat := parallel_g281 ++ parallel_t282
def parallel_t280 : List Nat := parallel_g280 ++ parallel_t281
def parallel_t279 : List Nat := parallel_g279 ++ parallel_t280
def parallel_t278 : List Nat := parallel_g278 ++ parallel_t279
def parallel_t277 : List Nat := parallel_g277 ++ parallel_t278
def parallel_t276 : List Nat := parallel_g276 ++ parallel_t277
def parallel_t275 : List Nat := parallel_g275 ++ parallel_t276
def parallel_t274 : List Nat := parallel_g274 ++ parallel_t275
def parallel_t273 : List Nat := parallel_g273 ++ parallel_t274
def parallel_t272 : List Nat := parallel_g272 ++ parallel_t273
def parallel_t271 : List Nat := parallel_g271 ++ parallel_t272
def parallel_t270 : List Nat := parallel_g270 ++ parallel_t271
def parallel_t269 : List Nat := parallel_g269 ++ parallel_t270
def parallel_t268 : List Nat := parallel_g268 ++ parallel_t269
def parallel_t267 : List Nat := parallel_g267 ++ parallel_t268
def parallel_t266 : List Nat := parallel_g266 ++ parallel_t267
def parallel_t265 : List Nat := parallel_g265 ++ parallel_t266
def parallel_t264 : List Nat := parallel_g264 ++ parallel_t265
def parallel_t263 : List Nat := parallel_g263 ++ parallel_t264
def parallel_t262 : List Nat := parallel_g262 ++ parallel_t263
def parallel_t261 : List Nat := parallel_g261 ++ parallel_t262
def parallel_t260 : List Nat := parallel_g260 ++ parallel_t261
def parallel_t259 : List Nat := parallel_g259 ++ parallel_t260
def parallel_t258 : List Nat := parallel_g258 ++ parallel_t259
def parallel_t257 : List Nat := parallel_g257 ++ parallel_t258
def parallel_t256 : List Nat := parallel_g256 ++ parallel_t257
def parallel_t255 : List Nat := parallel_g255 ++ parallel_t256
def parallel_t254 : List Nat := parallel_g254 ++ parallel_t255
def parallel_t253 : List Nat := parallel_g253 ++ parallel_t254
def parallel_t252 : List Nat := parallel_g252 ++ parallel_t253
def parallel_t251 : List Nat := parallel_g251 ++ parallel_t252
def parallel_t250 : List Nat := parallel_g250 ++ parallel_t251
def parallel_t249 : List Nat := parallel_g249 ++ parallel_t250
def parallel_t248 : List Nat := parallel_g248 ++ parallel_t249
def parallel_t247 : List Nat := parallel_g247 ++ parallel_t248
def parallel_t246 : List Nat := parallel_g246 ++ parallel_t247
def parallel_t245 : List Nat := parallel_g245 ++ parallel_t246
def parallel_t244 : List Nat := parallel_g244 ++ parallel_t245
def parallel_t243 : List Nat := parallel_g243 ++ parallel_t244
def parallel_t242 : List Nat := parallel_g242 ++ parallel_t243
def parallel_t241 : List Nat := parallel_g241 ++ parallel_t242
def parallel_t240 : List Nat := parallel_g240 ++ parallel_t241
def parallel_t239 : List Nat := parallel_g239 ++ parallel_t240
def parallel_t238 : List Nat := parallel_g238 ++ parallel_t239
def parallel_t237 : List Nat := parallel_g237 ++ parallel_t238
def parallel_t236 : List Nat := parallel_g236 ++ parallel_t237
def parallel_t235 : List Nat := parallel_g235 ++ parallel_t236
def parallel_t234 : List Nat := parallel_g234 ++ parallel_t235
def parallel_t233 : List Nat := parallel_g233 ++ parallel_t234
def parallel_t232 : List Nat := parallel_g232 ++ parallel_t233
def parallel_t231 : List Nat := parallel_g231 ++ parallel_t232
def parallel_t230 : List Nat := parallel_g230 ++ parallel_t231
def parallel_t229 : List Nat := parallel_g229 ++ parallel_t230
def parallel_t228 : List Nat := parallel_g228 ++ parallel_t229
def parallel_t227 : List Nat := parallel_g227 ++ parallel_t228
def parallel_t226 : List Nat := parallel_g226 ++ parallel_t227
def parallel_t225 : List Nat := parallel_g225 ++ parallel_t226
def parallel_t224 : List Nat := parallel_g224 ++ parallel_t225
def parallel_t223 : List Nat := parallel_g223 ++ parallel_t224
def parallel_t222 : List Nat := parallel_g222 ++ parallel_t223
def parallel_t221 : List Nat := parallel_g221 ++ parallel_t222
def parallel_t220 : List Nat := parallel_g220 ++ parallel_t221
def parallel_t219 : List Nat := parallel_g219 ++ parallel_t220
def parallel_t218 : List Nat := parallel_g218 ++ parallel_t219
def parallel_t217 : List Nat := parallel_g217 ++ parallel_t218
def parallel_t216 : List Nat := parallel_g216 ++ parallel_t217
def parallel_t215 : List Nat := parallel_g215 ++ parallel_t216
def parallel_t214 : List Nat := parallel_g214 ++ parallel_t215
def parallel_t213 : List Nat := parallel_g213 ++ parallel_t214
def parallel_t212 : List Nat := parallel_g212 ++ parallel_t213
def parallel_t211 : List Nat := parallel_g211 ++ parallel_t212
def parallel_t210 : List Nat := parallel_g210 ++ parallel_t211
def parallel_t209 : List Nat := parallel_g209 ++ parallel_t210
def parallel_t208 : List Nat := parallel_g208 ++ parallel_t209
def parallel_t207 : List Nat := parallel_g207 ++ parallel_t208
def parallel_t206 : List Nat := parallel_g206 ++ parallel_t207
def parallel_t205 : List Nat := parallel_g205 ++ parallel_t206
def parallel_t204 : List Nat := parallel_g204 ++ parallel_t205
def parallel_t203 : List Nat := parallel_g203 ++ parallel_t204
def parallel_t202 : List Nat := parallel_g202 ++ parallel_t203
def parallel_t201 : List Nat := parallel_g201 ++ parallel_t202
def parallel_t200 : List Nat := parallel_g200 ++ parallel_t201
def parallel_t199 : List Nat := parallel_g199 ++ parallel_t200
def parallel_t198 : List Nat := parallel_g198 ++ parallel_t199
def parallel_t197 : List Nat := parallel_g197 ++ parallel_t198
def parallel_t196 : List Nat := parallel_g196 ++ parallel_t197
def parallel_t195 : List Nat := parallel_g195 ++ parallel_t196
def parallel_t194 : List Nat := parallel_g194 ++ parallel_t195
def parallel_t193 : List Nat := parallel_g193 ++ parallel_t194
def parallel_t192 : List Nat := parallel_g192 ++ parallel_t193
def parallel_t191 : List Nat := parallel_g191 ++ parallel_t192
def parallel_t190 : List Nat := parallel_g190 ++ parallel_t191
def parallel_t189 : List Nat := parallel_g189 ++ parallel_t190
def parallel_t188 : List Nat := parallel_g188 ++ parallel_t189
def parallel_t187 : List Nat := parallel_g187 ++ parallel_t188
def parallel_t186 : List Nat := parallel_g186 ++ parallel_t187
def parallel_t185 : List Nat := parallel_g185 ++ parallel_t186
def parallel_t184 : List Nat := parallel_g184 ++ parallel_t185
def parallel_t183 : List Nat := parallel_g183 ++ parallel_t184
def parallel_t182 : List Nat := parallel_g182 ++ parallel_t183
def parallel_t181 : List Nat := parallel_g181 ++ parallel_t182
def parallel_t180 : List Nat := parallel_g180 ++ parallel_t181
def parallel_t179 : List Nat := parallel_g179 ++ parallel_t180
def parallel_t178 : List Nat := parallel_g178 ++ parallel_t179
def parallel_t177 : List Nat := parallel_g177 ++ parallel_t178
def parallel_t176 : List Nat := parallel_g176 ++ parallel_t177
def parallel_t175 : List Nat := parallel_g175 ++ parallel_t176
def parallel_t174 : List Nat := parallel_g174 ++ parallel_t175
def parallel_t173 : List Nat := parallel_g173 ++ parallel_t174
def parallel_t172 : List Nat := parallel_g172 ++ parallel_t173
def parallel_t171 : List Nat := parallel_g171 ++ parallel_t172
def parallel_t170 : List Nat := parallel_g170 ++ parallel_t171
def parallel_t169 : List Nat := parallel_g169 ++ parallel_t170
def parallel_t168 : List Nat := parallel_g168 ++ parallel_t169
def parallel_t167 : List Nat := parallel_g167 ++ parallel_t168
def parallel_t166 : List Nat := parallel_g166 ++ parallel_t167
def parallel_t165 : List Nat := parallel_g165 ++ parallel_t166
def parallel_t164 : List Nat := parallel_g164 ++ parallel_t165
def parallel_t163 : List Nat := parallel_g163 ++ parallel_t164
def parallel_t162 : List Nat := parallel_g162 ++ parallel_t163
def parallel_t161 : List Nat := parallel_g161 ++ parallel_t162
def parallel_t160 : List Nat := parallel_g160 ++ parallel_t161
def parallel_t159 : List Nat := parallel_g159 ++ parallel_t160
def parallel_t158 : List Nat := parallel_g158 ++ parallel_t159
def parallel_t157 : List Nat := parallel_g157 ++ parallel_t158
def parallel_t156 : List Nat := parallel_g156 ++ parallel_t157
def parallel_t155 : List Nat := parallel_g155 ++ parallel_t156
def parallel_t154 : List Nat := parallel_g154 ++ parallel_t155
def parallel_t153 : List Nat := parallel_g153 ++ parallel_t154
def parallel_t152 : List Nat := parallel_g152 ++ parallel_t153
def parallel_t151 : List Nat := parallel_g151 ++ parallel_t152
def parallel_t150 : List Nat := parallel_g150 ++ parallel_t151
def parallel_t149 : List Nat := parallel_g149 ++ parallel_t150
def parallel_t148 : List Nat := parallel_g148 ++ parallel_t149
def parallel_t147 : List Nat := parallel_g147 ++ parallel_t148
def parallel_t146 : List Nat := parallel_g146 ++ parallel_t147
def parallel_t145 : List Nat := parallel_g145 ++ parallel_t146
def parallel_t144 : List Nat := parallel_g144 ++ parallel_t145
def parallel_t143 : List Nat := parallel_g143 ++ parallel_t144
def parallel_t142 : List Nat := parallel_g142 ++ parallel_t143
def parallel_t141 : List Nat := parallel_g141 ++ parallel_t142
def parallel_t140 : List Nat := parallel_g140 ++ parallel_t141
def parallel_t139 : List Nat := parallel_g139 ++ parallel_t140
def parallel_t138 : List Nat := parallel_g138 ++ parallel_t139
def parallel_t137 : List Nat := parallel_g137 ++ parallel_t138
def parallel_t136 : List Nat := parallel_g136 ++ parallel_t137
def parallel_t135 : List Nat := parallel_g135 ++ parallel_t136
def parallel_t134 : List Nat := parallel_g134 ++ parallel_t135
def parallel_t133 : List Nat := parallel_g133 ++ parallel_t134
def parallel_t132 : List Nat := parallel_g132 ++ parallel_t133
def parallel_t131 : List Nat := parallel_g131 ++ parallel_t132
def parallel_t130 : List Nat := parallel_g130 ++ parallel_t131
def parallel_t129 : List Nat := parallel_g129 ++ parallel_t130
def parallel_t128 : List Nat := parallel_g128 ++ parallel_t129
def parallel_t127 : List Nat := parallel_g127 ++ parallel_t128
def parallel_t126 : List Nat := parallel_g126 ++ parallel_t127
def parallel_t125 : List Nat := parallel_g125 ++ parallel_t126
def parallel_t124 : List Nat := parallel_g124 ++ parallel_t125
def parallel_t123 : List Nat := parallel_g123 ++ parallel_t124
def parallel_t122 : List Nat := parallel_g122 ++ parallel_t123
def parallel_t121 : List Nat := parallel_g121 ++ parallel_t122
def parallel_t120 : List Nat := parallel_g120 ++ parallel_t121
def parallel_t119 : List Nat := parallel_g119 ++ parallel_t120
def parallel_t118 : List Nat := parallel_g118 ++ parallel_t119
def parallel_t117 : List Nat := parallel_g117 ++ parallel_t118
def parallel_t116 : List Nat := parallel_g116 ++ parallel_t117
def parallel_t115 : List Nat := parallel_g115 ++ parallel_t116
def parallel_t114 : List Nat := parallel_g114 ++ parallel_t115
def parallel_t113 : List Nat := parallel_g113 ++ parallel_t114
def parallel_t112 : List Nat := parallel_g112 ++ parallel_t113
def parallel_t111 : List Nat := parallel_g111 ++ parallel_t112
def parallel_t110 : List Nat := parallel_g110 ++ parallel_t111
def parallel_t109 : List Nat := parallel_g109 ++ parallel_t110
def parallel_t108 : List Nat := parallel_g108 ++ parallel_t109
def parallel_t107 : List Nat := parallel_g107 ++ parallel_t108
def parallel_t106 : List Nat := parallel_g106 ++ parallel_t107
def parallel_t105 : List Nat := parallel_g105 ++ parallel_t106
def parallel_t104 : List Nat := parallel_g104 ++ parallel_t105
def parallel_t103 : List Nat := parallel_g103 ++ parallel_t104
def parallel_t102 : List Nat := parallel_g102 ++ parallel_t103
def parallel_t101 : List Nat := parallel_g101 ++ parallel_t102
def parallel_t100 : List Nat := parallel_g100 ++ parallel_t101
def parallel_t99 : List Nat := parallel_g99 ++ parallel_t100
def parallel_t98 : List Nat := parallel_g98 ++ parallel_t99
def parallel_t97 : List Nat := parallel_g97 ++ parallel_t98
def parallel_t96 : List Nat := parallel_g96 ++ parallel_t97
def parallel_t95 : List Nat := parallel_g95 ++ parallel_t96
def parallel_t94 : List Nat := parallel_g94 ++ parallel_t95
def parallel_t93 : List Nat := parallel_g93 ++ parallel_t94
def parallel_t92 : List Nat := parallel_g92 ++ parallel_t93
def parallel_t91 : List Nat := parallel_g91 ++ parallel_t92
def parallel_t90 : List Nat := parallel_g90 ++ parallel_t91
def parallel_t89 : List Nat := parallel_g89 ++ parallel_t90
def parallel_t88 : List Nat := parallel_g88 ++ parallel_t89
def parallel_t87 : List Nat := parallel_g87 ++ parallel_t88
def parallel_t86 : List Nat := parallel_g86 ++ parallel_t87
def parallel_t85 : List Nat := parallel_g85 ++ parallel_t86
def parallel_t84 : List Nat := parallel_g84 ++ parallel_t85
def parallel_t83 : List Nat := parallel_g83 ++ parallel_t84
def parallel_t82 : List Nat := parallel_g82 ++ parallel_t83
def parallel_t81 : List Nat := parallel_g81 ++ parallel_t82
def parallel_t80 : List Nat := parallel_g80 ++ parallel_t81
def parallel_t79 : List Nat := parallel_g79 ++ parallel_t80
def parallel_t78 : List Nat := parallel_g78 ++ parallel_t79
def parallel_t77 : List Nat := parallel_g77 ++ parallel_t78
def parallel_t76 : List Nat := parallel_g76 ++ parallel_t77
def parallel_t75 : List Nat := parallel_g75 ++ parallel_t76
def parallel_t74 : List Nat := parallel_g74 ++ parallel_t75
def parallel_t73 : List Nat := parallel_g73 ++ parallel_t74
def parallel_t72 : List Nat := parallel_g72 ++ parallel_t73
def parallel_t71 : List Nat := parallel_g71 ++ parallel_t72
def parallel_t70 : List Nat := parallel_g70 ++ parallel_t71
def parallel_t69 : List Nat := parallel_g69 ++ parallel_t70
def parallel_t68 : List Nat := parallel_g68 ++ parallel_t69
def parallel_t67 : List Nat := parallel_g67 ++ parallel_t68
def parallel_t66 : List Nat := parallel_g66 ++ parallel_t67
def parallel_t65 : List Nat := parallel_g65 ++ parallel_t66
def parallel_t64 : List Nat := parallel_g64 ++ parallel_t65
def parallel_t63 : List Nat := parallel_g63 ++ parallel_t64
def parallel_t62 : List Nat := parallel_g62 ++ parallel_t63
def parallel_t61 : List Nat := parallel_g61 ++ parallel_t62
def parallel_t60 : List Nat := parallel_g60 ++ parallel_t61
def parallel_t59 : List Nat := parallel_g59 ++ parallel_t60
def parallel_t58 : List Nat := parallel_g58 ++ parallel_t59
def parallel_t57 : List Nat := parallel_g57 ++ parallel_t58
def parallel_t56 : List Nat := parallel_g56 ++ parallel_t57
def parallel_t55 : List Nat := parallel_g55 ++ parallel_t56
def parallel_t54 : List Nat := parallel_g54 ++ parallel_t55
def parallel_t53 : List Nat := parallel_g53 ++ parallel_t54
def parallel_t52 : List Nat := parallel_g52 ++ parallel_t53
def parallel_t51 : List Nat := parallel_g51 ++ parallel_t52
def parallel_t50 : List Nat := parallel_g50 ++ parallel_t51
def parallel_t49 : List Nat := parallel_g49 ++ parallel_t50
def parallel_t48 : List Nat := parallel_g48 ++ parallel_t49
def parallel_t47 : List Nat := parallel_g47 ++ parallel_t48
def parallel_t46 : List Nat := parallel_g46 ++ parallel_t47
def parallel_t45 : List Nat := parallel_g45 ++ parallel_t46
def parallel_t44 : List Nat := parallel_g44 ++ parallel_t45
def parallel_t43 : List Nat := parallel_g43 ++ parallel_t44
def parallel_t42 : List Nat := parallel_g42 ++ parallel_t43
def parallel_t41 : List Nat := parallel_g41 ++ parallel_t42
def parallel_t40 : List Nat := parallel_g40 ++ parallel_t41
def parallel_t39 : List Nat := parallel_g39 ++ parallel_t40
def parallel_t38 : List Nat := parallel_g38 ++ parallel_t39
def parallel_t37 : List Nat := parallel_g37 ++ parallel_t38
def parallel_t36 : List Nat := parallel_g36 ++ parallel_t37
def parallel_t35 : List Nat := parallel_g35 ++ parallel_t36
def parallel_t34 : List Nat := parallel_g34 ++ parallel_t35
def parallel_t33 : List Nat := parallel_g33 ++ parallel_t34
def parallel_t32 : List Nat := parallel_g32 ++ parallel_t33
def parallel_t31 : List Nat := parallel_g31 ++ parallel_t32
def parallel_t30 : List Nat := parallel_g30 ++ parallel_t31
def parallel_t29 : List Nat := parallel_g29 ++ parallel_t30
def parallel_t28 : List Nat := parallel_g28 ++ parallel_t29
def parallel_t27 : List Nat := parallel_g27 ++ parallel_t28
def parallel_t26 : List Nat := parallel_g26 ++ parallel_t27
def parallel_t25 : List Nat := parallel_g25 ++ parallel_t26
def parallel_t24 : List Nat := parallel_g24 ++ parallel_t25
def parallel_t23 : List Nat := parallel_g23 ++ parallel_t24
def parallel_t22 : List Nat := parallel_g22 ++ parallel_t23
def parallel_t21 : List Nat := parallel_g21 ++ parallel_t22
def parallel_t20 : List Nat := parallel_g20 ++ parallel_t21
def parallel_t19 : List Nat := parallel_g19 ++ parallel_t20
def parallel_t18 : List Nat := parallel_g18 ++ parallel_t19
def parallel_t17 : List Nat := parallel_g17 ++ parallel_t18
def parallel_t16 : List Nat := parallel_g16 ++ parallel_t17
def parallel_t15 : List Nat := parallel_g15 ++ parallel_t16
def parallel_t14 : List Nat := parallel_g14 ++ parallel_t15
def parallel_t13 : List Nat := parallel_g13 ++ parallel_t14
def parallel_t12 : List Nat := parallel_g12 ++ parallel_t13
def parallel_t11 : List Nat := parallel_g11 ++ parallel_t12
def parallel_t10 : List Nat := parallel_g10 ++ parallel_t11
def parallel_t9 : List Nat := parallel_g9 ++ parallel_t10
def parallel_t8 : List Nat := parallel_g8 ++ parallel_t9
def parallel_t7 : List Nat := parallel_g7 ++ parallel_t8
def parallel_t6 : List Nat := parallel_g6 ++ parallel_t7
def parallel_t5 : List Nat := parallel_g5 ++ parallel_t6
def parallel_t4 : List Nat := parallel_g4 ++ parallel_t5
def parallel_t3 : List Nat := parallel_g3 ++ parallel_t4
def parallel_t2 : List Nat := parallel_g2 ++ parallel_t3
def parallel_t1 : List Nat := parallel_g1 ++ parallel_t2
def parallel_t0 : List Nat := parallel_g0 ++ parallel_t1
def parallel_r1 : Raw := (.arr [(.str [99,97,108,99,117,108,97,116,101])])
def parallel_b1 : List Nat := parallel_g2
theorem parallel_s1 : serializeRaw 4094 31 parallel_r1 = some parallel_b1 := by decide +kernel
theorem parallel_p1 (tail : List Nat) : parseRaw 4094 31 (parallel_b1 ++ tail) = some (parallel_r1, tail) := by rfl
def parallel_r6 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def parallel_b6 : List Nat := parallel_g11
theorem parallel_s6 : serializeRaw 4085 27 parallel_r6 = some parallel_b6 := by decide +kernel
theorem parallel_p6 (tail : List Nat) : parseRaw 4085 27 (parallel_b6 ++ tail) = some (parallel_r6, tail) := by rfl
def parallel_r7 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,116,114,121,95,110,101,119])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49])),([116,121,112,101],(.str [98,111,111,108]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50])),([116,121,112,101],(.str [117,56]))])]))])])
def parallel_b7 : List Nat := parallel_g14
theorem parallel_s7 : serializeRaw 4084 27 parallel_r7 = some parallel_b7 := by decide +kernel
theorem parallel_p7 (tail : List Nat) : parseRaw 4084 27 (parallel_b7 ++ tail) = some (parallel_r7, tail) := by rfl
def parallel_r8 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def parallel_b8 : List Nat := parallel_g17
theorem parallel_s8 : serializeRaw 4083 27 parallel_r8 = some parallel_b8 := by decide +kernel
theorem parallel_p8 (tail : List Nat) : parseRaw 4083 27 (parallel_b8 ++ tail) = some (parallel_r8, tail) := by rfl
def parallel_r9 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,49]))]))])
def parallel_b9 : List Nat := parallel_g20
theorem parallel_s9 : serializeRaw 4082 27 parallel_r9 = some parallel_b9 := by decide +kernel
theorem parallel_p9 (tail : List Nat) : parseRaw 4082 27 (parallel_b9 ++ tail) = some (parallel_r9, tail) := by rfl
def parallel_k5_0 : List Nat := [105,100]
theorem parallel_kd5_0 : stringBytes parallel_k5_0 = true := by decide +kernel
theorem parallel_kp5_0 (tail : List Nat) : parseStringTail (parallel_k5_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k5_0, 58 :: tail) := by rfl
def parallel_k5_1 : List Nat := [111,112,115]
theorem parallel_kd5_1 : stringBytes parallel_k5_1 = true := by decide +kernel
theorem parallel_kp5_1 (tail : List Nat) : parseStringTail (parallel_k5_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k5_1, 58 :: tail) := by rfl
def parallel_k5_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd5_2 : stringBytes parallel_k5_2 = true := by decide +kernel
theorem parallel_kp5_2 (tail : List Nat) : parseStringTail (parallel_k5_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k5_2, 58 :: tail) := by rfl
def parallel_k5_3 : List Nat := [116,101,114,109]
theorem parallel_kd5_3 : stringBytes parallel_k5_3 = true := by decide +kernel
theorem parallel_kp5_3 (tail : List Nat) : parseStringTail (parallel_k5_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k5_3, 58 :: tail) := by rfl
def parallel_l5_3 : List (List Nat × Raw) := [(parallel_k5_3, parallel_r9)]
def parallel_v5_3 : List Nat := parallel_g19 ++ parallel_b9
theorem parallel_sl5_3 : serializeFields 4083 27 parallel_l5_3 = some parallel_v5_3 := by
  simpa only [parallel_l5_3, parallel_v5_3, parallel_k5_3, parallel_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4082 27 parallel_k5_3 parallel_r9 parallel_b9 parallel_kd5_3 parallel_s9)
theorem parallel_pl5_3 (tail : List Nat) : parseFields 4083 27 (parallel_v5_3 ++ (125 :: tail)) = some (parallel_l5_3, tail) := by
  simpa only [parallel_l5_3, parallel_v5_3, parallel_k5_3, parallel_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4082 27 (parallel_k5_3 ++ (34 :: 58 :: (parallel_b9 ++ (125 :: tail)))) parallel_k5_3 (parallel_b9 ++ (125 :: tail)) tail parallel_r9 (parallel_kp5_3 (parallel_b9 ++ (125 :: tail))) (parallel_p9 (125 :: tail)))
def parallel_l5_2 : List (List Nat × Raw) := (parallel_k5_2, parallel_r8) :: parallel_l5_3
def parallel_v5_2 : List Nat := (parallel_g16 ++ parallel_b8) ++ (44 :: parallel_v5_3)
theorem parallel_sl5_2 : serializeFields 4084 27 parallel_l5_2 = some parallel_v5_2 := by
  simpa only [parallel_l5_2, parallel_v5_2, parallel_k5_2, parallel_g16, parallel_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 parallel_k5_2 parallel_r8 (parallel_k5_3, parallel_r9) [] parallel_b8 parallel_v5_3 parallel_kd5_2 parallel_s8 parallel_sl5_3)
theorem parallel_pl5_2 (tail : List Nat) : parseFields 4084 27 (parallel_v5_2 ++ (125 :: tail)) = some (parallel_l5_2, tail) := by
  simpa only [parallel_l5_2, parallel_v5_2, parallel_k5_2, parallel_g16, parallel_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (parallel_k5_2 ++ (34 :: 58 :: (parallel_b8 ++ (44 :: (parallel_v5_3 ++ (125 :: tail)))))) parallel_k5_2 (parallel_b8 ++ (44 :: (parallel_v5_3 ++ (125 :: tail)))) (parallel_v5_3 ++ (125 :: tail)) tail parallel_r8 parallel_l5_3 (parallel_kp5_2 (parallel_b8 ++ (44 :: (parallel_v5_3 ++ (125 :: tail))))) (parallel_p8 (44 :: (parallel_v5_3 ++ (125 :: tail)))) (parallel_pl5_3 tail))
def parallel_l5_1 : List (List Nat × Raw) := (parallel_k5_1, parallel_r7) :: parallel_l5_2
def parallel_v5_1 : List Nat := (parallel_g13 ++ parallel_b7) ++ (44 :: parallel_v5_2)
theorem parallel_sl5_1 : serializeFields 4085 27 parallel_l5_1 = some parallel_v5_1 := by
  simpa only [parallel_l5_1, parallel_v5_1, parallel_k5_1, parallel_g13, parallel_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 parallel_k5_1 parallel_r7 (parallel_k5_2, parallel_r8) parallel_l5_3 parallel_b7 parallel_v5_2 parallel_kd5_1 parallel_s7 parallel_sl5_2)
theorem parallel_pl5_1 (tail : List Nat) : parseFields 4085 27 (parallel_v5_1 ++ (125 :: tail)) = some (parallel_l5_1, tail) := by
  simpa only [parallel_l5_1, parallel_v5_1, parallel_k5_1, parallel_g13, parallel_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (parallel_k5_1 ++ (34 :: 58 :: (parallel_b7 ++ (44 :: (parallel_v5_2 ++ (125 :: tail)))))) parallel_k5_1 (parallel_b7 ++ (44 :: (parallel_v5_2 ++ (125 :: tail)))) (parallel_v5_2 ++ (125 :: tail)) tail parallel_r7 parallel_l5_2 (parallel_kp5_1 (parallel_b7 ++ (44 :: (parallel_v5_2 ++ (125 :: tail))))) (parallel_p7 (44 :: (parallel_v5_2 ++ (125 :: tail)))) (parallel_pl5_2 tail))
def parallel_l5_0 : List (List Nat × Raw) := (parallel_k5_0, parallel_r6) :: parallel_l5_1
def parallel_v5_0 : List Nat := (parallel_g10 ++ parallel_b6) ++ (44 :: parallel_v5_1)
theorem parallel_sl5_0 : serializeFields 4086 27 parallel_l5_0 = some parallel_v5_0 := by
  simpa only [parallel_l5_0, parallel_v5_0, parallel_k5_0, parallel_g10, parallel_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 27 parallel_k5_0 parallel_r6 (parallel_k5_1, parallel_r7) parallel_l5_2 parallel_b6 parallel_v5_1 parallel_kd5_0 parallel_s6 parallel_sl5_1)
theorem parallel_pl5_0 (tail : List Nat) : parseFields 4086 27 (parallel_v5_0 ++ (125 :: tail)) = some (parallel_l5_0, tail) := by
  simpa only [parallel_l5_0, parallel_v5_0, parallel_k5_0, parallel_g10, parallel_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 27 (parallel_k5_0 ++ (34 :: 58 :: (parallel_b6 ++ (44 :: (parallel_v5_1 ++ (125 :: tail)))))) parallel_k5_0 (parallel_b6 ++ (44 :: (parallel_v5_1 ++ (125 :: tail)))) (parallel_v5_1 ++ (125 :: tail)) tail parallel_r6 parallel_l5_1 (parallel_kp5_0 (parallel_b6 ++ (44 :: (parallel_v5_1 ++ (125 :: tail))))) (parallel_p6 (44 :: (parallel_v5_1 ++ (125 :: tail)))) (parallel_pl5_1 tail))
def parallel_r5 : Raw := (.obj parallel_l5_0)
def parallel_b5 : List Nat := parallel_g9 ++ (parallel_v5_0 ++ parallel_g21)
theorem parallel_o5 : orderedFields parallel_l5_0 = true := by decide +kernel
theorem parallel_s5 : serializeRaw 4087 28 parallel_r5 = some parallel_b5 := by
  simpa only [parallel_r5, parallel_b5, parallel_g9, parallel_g21, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4086 27 parallel_l5_0 parallel_v5_0 parallel_o5 parallel_sl5_0)
theorem parallel_p5 (tail : List Nat) : parseRaw 4087 28 (parallel_b5 ++ tail) = some (parallel_r5, tail) := by
  simpa only [parallel_r5, parallel_b5, parallel_g9, parallel_g21, parallel_v5_0, parallel_k5_0, parallel_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4086 27 (parallel_k5_0 ++ (34 :: 58 :: (parallel_b6 ++ (44 :: (parallel_v5_1 ++ (125 :: tail)))))) tail parallel_l5_0 parallel_o5 (by simpa only [parallel_v5_0, parallel_k5_0, parallel_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl5_0 tail)))
def parallel_r11 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,49])
def parallel_b11 : List Nat := parallel_g25
theorem parallel_s11 : serializeRaw 4084 27 parallel_r11 = some parallel_b11 := by decide +kernel
theorem parallel_p11 (tail : List Nat) : parseRaw 4084 27 (parallel_b11 ++ tail) = some (parallel_r11, tail) := by rfl
def parallel_r12 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def parallel_b12 : List Nat := parallel_g28
theorem parallel_s12 : serializeRaw 4083 27 parallel_r12 = some parallel_b12 := by decide +kernel
theorem parallel_p12 (tail : List Nat) : parseRaw 4083 27 (parallel_b12 ++ tail) = some (parallel_r12, tail) := by rfl
def parallel_r13 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b13 : List Nat := parallel_g31
theorem parallel_s13 : serializeRaw 4082 27 parallel_r13 = some parallel_b13 := by decide +kernel
theorem parallel_p13 (tail : List Nat) : parseRaw 4082 27 (parallel_b13 ++ tail) = some (parallel_r13, tail) := by rfl
def parallel_r14 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,52]),(.str [100,103,95,118,95,56]),(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,57]),(.str [100,103,95,118,95,49,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,51]))])
def parallel_b14 : List Nat := parallel_g34
theorem parallel_s14 : serializeRaw 4081 27 parallel_r14 = some parallel_b14 := by decide +kernel
theorem parallel_p14 (tail : List Nat) : parseRaw 4081 27 (parallel_b14 ++ tail) = some (parallel_r14, tail) := by rfl
def parallel_k10_0 : List Nat := [105,100]
theorem parallel_kd10_0 : stringBytes parallel_k10_0 = true := by decide +kernel
theorem parallel_kp10_0 (tail : List Nat) : parseStringTail (parallel_k10_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k10_0, 58 :: tail) := by rfl
def parallel_k10_1 : List Nat := [111,112,115]
theorem parallel_kd10_1 : stringBytes parallel_k10_1 = true := by decide +kernel
theorem parallel_kp10_1 (tail : List Nat) : parseStringTail (parallel_k10_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k10_1, 58 :: tail) := by rfl
def parallel_k10_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd10_2 : stringBytes parallel_k10_2 = true := by decide +kernel
theorem parallel_kp10_2 (tail : List Nat) : parseStringTail (parallel_k10_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k10_2, 58 :: tail) := by rfl
def parallel_k10_3 : List Nat := [116,101,114,109]
theorem parallel_kd10_3 : stringBytes parallel_k10_3 = true := by decide +kernel
theorem parallel_kp10_3 (tail : List Nat) : parseStringTail (parallel_k10_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k10_3, 58 :: tail) := by rfl
def parallel_l10_3 : List (List Nat × Raw) := [(parallel_k10_3, parallel_r14)]
def parallel_v10_3 : List Nat := parallel_g33 ++ parallel_b14
theorem parallel_sl10_3 : serializeFields 4082 27 parallel_l10_3 = some parallel_v10_3 := by
  simpa only [parallel_l10_3, parallel_v10_3, parallel_k10_3, parallel_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4081 27 parallel_k10_3 parallel_r14 parallel_b14 parallel_kd10_3 parallel_s14)
theorem parallel_pl10_3 (tail : List Nat) : parseFields 4082 27 (parallel_v10_3 ++ (125 :: tail)) = some (parallel_l10_3, tail) := by
  simpa only [parallel_l10_3, parallel_v10_3, parallel_k10_3, parallel_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4081 27 (parallel_k10_3 ++ (34 :: 58 :: (parallel_b14 ++ (125 :: tail)))) parallel_k10_3 (parallel_b14 ++ (125 :: tail)) tail parallel_r14 (parallel_kp10_3 (parallel_b14 ++ (125 :: tail))) (parallel_p14 (125 :: tail)))
def parallel_l10_2 : List (List Nat × Raw) := (parallel_k10_2, parallel_r13) :: parallel_l10_3
def parallel_v10_2 : List Nat := (parallel_g30 ++ parallel_b13) ++ (44 :: parallel_v10_3)
theorem parallel_sl10_2 : serializeFields 4083 27 parallel_l10_2 = some parallel_v10_2 := by
  simpa only [parallel_l10_2, parallel_v10_2, parallel_k10_2, parallel_g30, parallel_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 parallel_k10_2 parallel_r13 (parallel_k10_3, parallel_r14) [] parallel_b13 parallel_v10_3 parallel_kd10_2 parallel_s13 parallel_sl10_3)
theorem parallel_pl10_2 (tail : List Nat) : parseFields 4083 27 (parallel_v10_2 ++ (125 :: tail)) = some (parallel_l10_2, tail) := by
  simpa only [parallel_l10_2, parallel_v10_2, parallel_k10_2, parallel_g30, parallel_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (parallel_k10_2 ++ (34 :: 58 :: (parallel_b13 ++ (44 :: (parallel_v10_3 ++ (125 :: tail)))))) parallel_k10_2 (parallel_b13 ++ (44 :: (parallel_v10_3 ++ (125 :: tail)))) (parallel_v10_3 ++ (125 :: tail)) tail parallel_r13 parallel_l10_3 (parallel_kp10_2 (parallel_b13 ++ (44 :: (parallel_v10_3 ++ (125 :: tail))))) (parallel_p13 (44 :: (parallel_v10_3 ++ (125 :: tail)))) (parallel_pl10_3 tail))
def parallel_l10_1 : List (List Nat × Raw) := (parallel_k10_1, parallel_r12) :: parallel_l10_2
def parallel_v10_1 : List Nat := (parallel_g27 ++ parallel_b12) ++ (44 :: parallel_v10_2)
theorem parallel_sl10_1 : serializeFields 4084 27 parallel_l10_1 = some parallel_v10_1 := by
  simpa only [parallel_l10_1, parallel_v10_1, parallel_k10_1, parallel_g27, parallel_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 parallel_k10_1 parallel_r12 (parallel_k10_2, parallel_r13) parallel_l10_3 parallel_b12 parallel_v10_2 parallel_kd10_1 parallel_s12 parallel_sl10_2)
theorem parallel_pl10_1 (tail : List Nat) : parseFields 4084 27 (parallel_v10_1 ++ (125 :: tail)) = some (parallel_l10_1, tail) := by
  simpa only [parallel_l10_1, parallel_v10_1, parallel_k10_1, parallel_g27, parallel_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (parallel_k10_1 ++ (34 :: 58 :: (parallel_b12 ++ (44 :: (parallel_v10_2 ++ (125 :: tail)))))) parallel_k10_1 (parallel_b12 ++ (44 :: (parallel_v10_2 ++ (125 :: tail)))) (parallel_v10_2 ++ (125 :: tail)) tail parallel_r12 parallel_l10_2 (parallel_kp10_1 (parallel_b12 ++ (44 :: (parallel_v10_2 ++ (125 :: tail))))) (parallel_p12 (44 :: (parallel_v10_2 ++ (125 :: tail)))) (parallel_pl10_2 tail))
def parallel_l10_0 : List (List Nat × Raw) := (parallel_k10_0, parallel_r11) :: parallel_l10_1
def parallel_v10_0 : List Nat := (parallel_g24 ++ parallel_b11) ++ (44 :: parallel_v10_1)
theorem parallel_sl10_0 : serializeFields 4085 27 parallel_l10_0 = some parallel_v10_0 := by
  simpa only [parallel_l10_0, parallel_v10_0, parallel_k10_0, parallel_g24, parallel_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 parallel_k10_0 parallel_r11 (parallel_k10_1, parallel_r12) parallel_l10_2 parallel_b11 parallel_v10_1 parallel_kd10_0 parallel_s11 parallel_sl10_1)
theorem parallel_pl10_0 (tail : List Nat) : parseFields 4085 27 (parallel_v10_0 ++ (125 :: tail)) = some (parallel_l10_0, tail) := by
  simpa only [parallel_l10_0, parallel_v10_0, parallel_k10_0, parallel_g24, parallel_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (parallel_k10_0 ++ (34 :: 58 :: (parallel_b11 ++ (44 :: (parallel_v10_1 ++ (125 :: tail)))))) parallel_k10_0 (parallel_b11 ++ (44 :: (parallel_v10_1 ++ (125 :: tail)))) (parallel_v10_1 ++ (125 :: tail)) tail parallel_r11 parallel_l10_1 (parallel_kp10_0 (parallel_b11 ++ (44 :: (parallel_v10_1 ++ (125 :: tail))))) (parallel_p11 (44 :: (parallel_v10_1 ++ (125 :: tail)))) (parallel_pl10_1 tail))
def parallel_r10 : Raw := (.obj parallel_l10_0)
def parallel_b10 : List Nat := parallel_g23 ++ (parallel_v10_0 ++ parallel_g35)
theorem parallel_o10 : orderedFields parallel_l10_0 = true := by decide +kernel
theorem parallel_s10 : serializeRaw 4086 28 parallel_r10 = some parallel_b10 := by
  simpa only [parallel_r10, parallel_b10, parallel_g23, parallel_g35, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4085 27 parallel_l10_0 parallel_v10_0 parallel_o10 parallel_sl10_0)
theorem parallel_p10 (tail : List Nat) : parseRaw 4086 28 (parallel_b10 ++ tail) = some (parallel_r10, tail) := by
  simpa only [parallel_r10, parallel_b10, parallel_g23, parallel_g35, parallel_v10_0, parallel_k10_0, parallel_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4085 27 (parallel_k10_0 ++ (34 :: 58 :: (parallel_b11 ++ (44 :: (parallel_v10_1 ++ (125 :: tail)))))) tail parallel_l10_0 parallel_o10 (by simpa only [parallel_v10_0, parallel_k10_0, parallel_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl10_0 tail)))
def parallel_r16 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,50])
def parallel_b16 : List Nat := parallel_g39
theorem parallel_s16 : serializeRaw 4083 27 parallel_r16 = some parallel_b16 := by decide +kernel
theorem parallel_p16 (tail : List Nat) : parseRaw 4083 27 (parallel_b16 ++ tail) = some (parallel_r16, tail) := by rfl
def parallel_r18 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])
def parallel_b18 : List Nat := parallel_g43
theorem parallel_s18 : serializeRaw 4080 26 parallel_r18 = some parallel_b18 := by decide +kernel
theorem parallel_p18 (tail : List Nat) : parseRaw 4080 26 (parallel_b18 ++ tail) = some (parallel_r18, tail) := by rfl
def parallel_r19 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1000))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b19 : List Nat := parallel_g45
theorem parallel_s19 : serializeRaw 4079 26 parallel_r19 = some parallel_b19 := by decide +kernel
theorem parallel_p19 (tail : List Nat) : parseRaw 4079 26 (parallel_b19 ++ tail) = some (parallel_r19, tail) := by rfl
def parallel_r20 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b20 : List Nat := parallel_g47
theorem parallel_s20 : serializeRaw 4078 26 parallel_r20 = some parallel_b20 := by decide +kernel
theorem parallel_p20 (tail : List Nat) : parseRaw 4078 26 (parallel_b20 ++ tail) = some (parallel_r20, tail) := by rfl
def parallel_r21 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54]),(.str [100,103,95,118,95,49,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,56])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b21 : List Nat := parallel_g49
theorem parallel_s21 : serializeRaw 4077 26 parallel_r21 = some parallel_b21 := by decide +kernel
theorem parallel_p21 (tail : List Nat) : parseRaw 4077 26 (parallel_b21 ++ tail) = some (parallel_r21, tail) := by rfl
def parallel_l17_3 : List Raw := [parallel_r21]
def parallel_v17_3 : List Nat := parallel_b21
theorem parallel_sl17_3 : serializeItems 4078 26 parallel_l17_3 = some parallel_v17_3 := by
  simpa only [parallel_l17_3, parallel_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4077 26 parallel_r21 parallel_b21 parallel_s21)
theorem parallel_pl17_3 (tail : List Nat) : parseItems 4078 26 (parallel_v17_3 ++ (93 :: tail)) = some (parallel_l17_3, tail) := by
  simpa only [parallel_l17_3, parallel_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4077 26 (parallel_b21 ++ (93 :: tail)) tail parallel_r21 (parallel_p21 (93 :: tail)))
def parallel_l17_2 : List Raw := parallel_r20 :: parallel_l17_3
def parallel_v17_2 : List Nat := (parallel_b20) ++ (44 :: parallel_v17_3)
theorem parallel_sl17_2 : serializeItems 4079 26 parallel_l17_2 = some parallel_v17_2 := by
  simpa only [parallel_l17_2, parallel_v17_2, parallel_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 26 parallel_r20 parallel_r21 [] parallel_b20 parallel_v17_3 parallel_s20 parallel_sl17_3)
theorem parallel_pl17_2 (tail : List Nat) : parseItems 4079 26 (parallel_v17_2 ++ (93 :: tail)) = some (parallel_l17_2, tail) := by
  simpa only [parallel_l17_2, parallel_v17_2, parallel_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 26 (parallel_b20 ++ (44 :: (parallel_v17_3 ++ (93 :: tail)))) (parallel_v17_3 ++ (93 :: tail)) tail parallel_r20 parallel_l17_3 (parallel_p20 (44 :: (parallel_v17_3 ++ (93 :: tail)))) (parallel_pl17_3 tail))
def parallel_l17_1 : List Raw := parallel_r19 :: parallel_l17_2
def parallel_v17_1 : List Nat := (parallel_b19) ++ (44 :: parallel_v17_2)
theorem parallel_sl17_1 : serializeItems 4080 26 parallel_l17_1 = some parallel_v17_1 := by
  simpa only [parallel_l17_1, parallel_v17_1, parallel_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 26 parallel_r19 parallel_r20 parallel_l17_3 parallel_b19 parallel_v17_2 parallel_s19 parallel_sl17_2)
theorem parallel_pl17_1 (tail : List Nat) : parseItems 4080 26 (parallel_v17_1 ++ (93 :: tail)) = some (parallel_l17_1, tail) := by
  simpa only [parallel_l17_1, parallel_v17_1, parallel_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 26 (parallel_b19 ++ (44 :: (parallel_v17_2 ++ (93 :: tail)))) (parallel_v17_2 ++ (93 :: tail)) tail parallel_r19 parallel_l17_2 (parallel_p19 (44 :: (parallel_v17_2 ++ (93 :: tail)))) (parallel_pl17_2 tail))
def parallel_l17_0 : List Raw := parallel_r18 :: parallel_l17_1
def parallel_v17_0 : List Nat := (parallel_b18) ++ (44 :: parallel_v17_1)
theorem parallel_sl17_0 : serializeItems 4081 26 parallel_l17_0 = some parallel_v17_0 := by
  simpa only [parallel_l17_0, parallel_v17_0, parallel_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 26 parallel_r18 parallel_r19 parallel_l17_2 parallel_b18 parallel_v17_1 parallel_s18 parallel_sl17_1)
theorem parallel_pl17_0 (tail : List Nat) : parseItems 4081 26 (parallel_v17_0 ++ (93 :: tail)) = some (parallel_l17_0, tail) := by
  simpa only [parallel_l17_0, parallel_v17_0, parallel_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 26 (parallel_b18 ++ (44 :: (parallel_v17_1 ++ (93 :: tail)))) (parallel_v17_1 ++ (93 :: tail)) tail parallel_r18 parallel_l17_1 (parallel_p18 (44 :: (parallel_v17_1 ++ (93 :: tail)))) (parallel_pl17_1 tail))
def parallel_r17 : Raw := (.arr parallel_l17_0)
def parallel_b17 : List Nat := parallel_g42 ++ (parallel_v17_0 ++ parallel_g50)
theorem parallel_s17 : serializeRaw 4082 27 parallel_r17 = some parallel_b17 := by
  simpa only [parallel_r17, parallel_b17, parallel_g42, parallel_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4081 26 parallel_l17_0 parallel_v17_0 parallel_sl17_0)
theorem parallel_p17 (tail : List Nat) : parseRaw 4082 27 (parallel_b17 ++ tail) = some (parallel_r17, tail) := by
  simpa only [parallel_r17, parallel_b17, parallel_g42, parallel_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4081 26 (parallel_v17_0 ++ (93 :: tail)) tail parallel_l17_0 (by intro h; cases h) (parallel_pl17_0 tail))
def parallel_r22 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,57])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b22 : List Nat := parallel_g53
theorem parallel_s22 : serializeRaw 4081 27 parallel_r22 = some parallel_b22 := by decide +kernel
theorem parallel_p22 (tail : List Nat) : parseRaw 4081 27 (parallel_b22 ++ tail) = some (parallel_r22, tail) := by rfl
def parallel_r23 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,56])]))])
def parallel_b23 : List Nat := parallel_g56
theorem parallel_s23 : serializeRaw 4080 27 parallel_r23 = some parallel_b23 := by decide +kernel
theorem parallel_p23 (tail : List Nat) : parseRaw 4080 27 (parallel_b23 ++ tail) = some (parallel_r23, tail) := by rfl
def parallel_k15_0 : List Nat := [105,100]
theorem parallel_kd15_0 : stringBytes parallel_k15_0 = true := by decide +kernel
theorem parallel_kp15_0 (tail : List Nat) : parseStringTail (parallel_k15_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k15_0, 58 :: tail) := by rfl
def parallel_k15_1 : List Nat := [111,112,115]
theorem parallel_kd15_1 : stringBytes parallel_k15_1 = true := by decide +kernel
theorem parallel_kp15_1 (tail : List Nat) : parseStringTail (parallel_k15_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k15_1, 58 :: tail) := by rfl
def parallel_k15_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd15_2 : stringBytes parallel_k15_2 = true := by decide +kernel
theorem parallel_kp15_2 (tail : List Nat) : parseStringTail (parallel_k15_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k15_2, 58 :: tail) := by rfl
def parallel_k15_3 : List Nat := [116,101,114,109]
theorem parallel_kd15_3 : stringBytes parallel_k15_3 = true := by decide +kernel
theorem parallel_kp15_3 (tail : List Nat) : parseStringTail (parallel_k15_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k15_3, 58 :: tail) := by rfl
def parallel_l15_3 : List (List Nat × Raw) := [(parallel_k15_3, parallel_r23)]
def parallel_v15_3 : List Nat := parallel_g55 ++ parallel_b23
theorem parallel_sl15_3 : serializeFields 4081 27 parallel_l15_3 = some parallel_v15_3 := by
  simpa only [parallel_l15_3, parallel_v15_3, parallel_k15_3, parallel_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4080 27 parallel_k15_3 parallel_r23 parallel_b23 parallel_kd15_3 parallel_s23)
theorem parallel_pl15_3 (tail : List Nat) : parseFields 4081 27 (parallel_v15_3 ++ (125 :: tail)) = some (parallel_l15_3, tail) := by
  simpa only [parallel_l15_3, parallel_v15_3, parallel_k15_3, parallel_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4080 27 (parallel_k15_3 ++ (34 :: 58 :: (parallel_b23 ++ (125 :: tail)))) parallel_k15_3 (parallel_b23 ++ (125 :: tail)) tail parallel_r23 (parallel_kp15_3 (parallel_b23 ++ (125 :: tail))) (parallel_p23 (125 :: tail)))
def parallel_l15_2 : List (List Nat × Raw) := (parallel_k15_2, parallel_r22) :: parallel_l15_3
def parallel_v15_2 : List Nat := (parallel_g52 ++ parallel_b22) ++ (44 :: parallel_v15_3)
theorem parallel_sl15_2 : serializeFields 4082 27 parallel_l15_2 = some parallel_v15_2 := by
  simpa only [parallel_l15_2, parallel_v15_2, parallel_k15_2, parallel_g52, parallel_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 parallel_k15_2 parallel_r22 (parallel_k15_3, parallel_r23) [] parallel_b22 parallel_v15_3 parallel_kd15_2 parallel_s22 parallel_sl15_3)
theorem parallel_pl15_2 (tail : List Nat) : parseFields 4082 27 (parallel_v15_2 ++ (125 :: tail)) = some (parallel_l15_2, tail) := by
  simpa only [parallel_l15_2, parallel_v15_2, parallel_k15_2, parallel_g52, parallel_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (parallel_k15_2 ++ (34 :: 58 :: (parallel_b22 ++ (44 :: (parallel_v15_3 ++ (125 :: tail)))))) parallel_k15_2 (parallel_b22 ++ (44 :: (parallel_v15_3 ++ (125 :: tail)))) (parallel_v15_3 ++ (125 :: tail)) tail parallel_r22 parallel_l15_3 (parallel_kp15_2 (parallel_b22 ++ (44 :: (parallel_v15_3 ++ (125 :: tail))))) (parallel_p22 (44 :: (parallel_v15_3 ++ (125 :: tail)))) (parallel_pl15_3 tail))
def parallel_l15_1 : List (List Nat × Raw) := (parallel_k15_1, parallel_r17) :: parallel_l15_2
def parallel_v15_1 : List Nat := (parallel_g41 ++ parallel_b17) ++ (44 :: parallel_v15_2)
theorem parallel_sl15_1 : serializeFields 4083 27 parallel_l15_1 = some parallel_v15_1 := by
  simpa only [parallel_l15_1, parallel_v15_1, parallel_k15_1, parallel_g41, parallel_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 parallel_k15_1 parallel_r17 (parallel_k15_2, parallel_r22) parallel_l15_3 parallel_b17 parallel_v15_2 parallel_kd15_1 parallel_s17 parallel_sl15_2)
theorem parallel_pl15_1 (tail : List Nat) : parseFields 4083 27 (parallel_v15_1 ++ (125 :: tail)) = some (parallel_l15_1, tail) := by
  simpa only [parallel_l15_1, parallel_v15_1, parallel_k15_1, parallel_g41, parallel_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (parallel_k15_1 ++ (34 :: 58 :: (parallel_b17 ++ (44 :: (parallel_v15_2 ++ (125 :: tail)))))) parallel_k15_1 (parallel_b17 ++ (44 :: (parallel_v15_2 ++ (125 :: tail)))) (parallel_v15_2 ++ (125 :: tail)) tail parallel_r17 parallel_l15_2 (parallel_kp15_1 (parallel_b17 ++ (44 :: (parallel_v15_2 ++ (125 :: tail))))) (parallel_p17 (44 :: (parallel_v15_2 ++ (125 :: tail)))) (parallel_pl15_2 tail))
def parallel_l15_0 : List (List Nat × Raw) := (parallel_k15_0, parallel_r16) :: parallel_l15_1
def parallel_v15_0 : List Nat := (parallel_g38 ++ parallel_b16) ++ (44 :: parallel_v15_1)
theorem parallel_sl15_0 : serializeFields 4084 27 parallel_l15_0 = some parallel_v15_0 := by
  simpa only [parallel_l15_0, parallel_v15_0, parallel_k15_0, parallel_g38, parallel_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 parallel_k15_0 parallel_r16 (parallel_k15_1, parallel_r17) parallel_l15_2 parallel_b16 parallel_v15_1 parallel_kd15_0 parallel_s16 parallel_sl15_1)
theorem parallel_pl15_0 (tail : List Nat) : parseFields 4084 27 (parallel_v15_0 ++ (125 :: tail)) = some (parallel_l15_0, tail) := by
  simpa only [parallel_l15_0, parallel_v15_0, parallel_k15_0, parallel_g38, parallel_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (parallel_k15_0 ++ (34 :: 58 :: (parallel_b16 ++ (44 :: (parallel_v15_1 ++ (125 :: tail)))))) parallel_k15_0 (parallel_b16 ++ (44 :: (parallel_v15_1 ++ (125 :: tail)))) (parallel_v15_1 ++ (125 :: tail)) tail parallel_r16 parallel_l15_1 (parallel_kp15_0 (parallel_b16 ++ (44 :: (parallel_v15_1 ++ (125 :: tail))))) (parallel_p16 (44 :: (parallel_v15_1 ++ (125 :: tail)))) (parallel_pl15_1 tail))
def parallel_r15 : Raw := (.obj parallel_l15_0)
def parallel_b15 : List Nat := parallel_g37 ++ (parallel_v15_0 ++ parallel_g57)
theorem parallel_o15 : orderedFields parallel_l15_0 = true := by decide +kernel
theorem parallel_s15 : serializeRaw 4085 28 parallel_r15 = some parallel_b15 := by
  simpa only [parallel_r15, parallel_b15, parallel_g37, parallel_g57, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4084 27 parallel_l15_0 parallel_v15_0 parallel_o15 parallel_sl15_0)
theorem parallel_p15 (tail : List Nat) : parseRaw 4085 28 (parallel_b15 ++ tail) = some (parallel_r15, tail) := by
  simpa only [parallel_r15, parallel_b15, parallel_g37, parallel_g57, parallel_v15_0, parallel_k15_0, parallel_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4084 27 (parallel_k15_0 ++ (34 :: 58 :: (parallel_b16 ++ (44 :: (parallel_v15_1 ++ (125 :: tail)))))) tail parallel_l15_0 parallel_o15 (by simpa only [parallel_v15_0, parallel_k15_0, parallel_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl15_0 tail)))
def parallel_r25 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,51])
def parallel_b25 : List Nat := parallel_g61
theorem parallel_s25 : serializeRaw 4082 27 parallel_r25 = some parallel_b25 := by decide +kernel
theorem parallel_p25 (tail : List Nat) : parseRaw 4082 27 (parallel_b25 ++ tail) = some (parallel_r25, tail) := by rfl
def parallel_r26 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,53])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b26 : List Nat := parallel_g64
theorem parallel_s26 : serializeRaw 4081 27 parallel_r26 = some parallel_b26 := by decide +kernel
theorem parallel_p26 (tail : List Nat) : parseRaw 4081 27 (parallel_b26 ++ tail) = some (parallel_r26, tail) := by rfl
def parallel_r27 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b27 : List Nat := parallel_g67
theorem parallel_s27 : serializeRaw 4080 27 parallel_r27 = some parallel_b27 := by decide +kernel
theorem parallel_p27 (tail : List Nat) : parseRaw 4080 27 (parallel_b27 ++ tail) = some (parallel_r27, tail) := by rfl
def parallel_r28 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,50,53])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,48]))]))])
def parallel_b28 : List Nat := parallel_g70
theorem parallel_s28 : serializeRaw 4079 27 parallel_r28 = some parallel_b28 := by decide +kernel
theorem parallel_p28 (tail : List Nat) : parseRaw 4079 27 (parallel_b28 ++ tail) = some (parallel_r28, tail) := by rfl
def parallel_k24_0 : List Nat := [105,100]
theorem parallel_kd24_0 : stringBytes parallel_k24_0 = true := by decide +kernel
theorem parallel_kp24_0 (tail : List Nat) : parseStringTail (parallel_k24_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k24_0, 58 :: tail) := by rfl
def parallel_k24_1 : List Nat := [111,112,115]
theorem parallel_kd24_1 : stringBytes parallel_k24_1 = true := by decide +kernel
theorem parallel_kp24_1 (tail : List Nat) : parseStringTail (parallel_k24_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k24_1, 58 :: tail) := by rfl
def parallel_k24_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd24_2 : stringBytes parallel_k24_2 = true := by decide +kernel
theorem parallel_kp24_2 (tail : List Nat) : parseStringTail (parallel_k24_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k24_2, 58 :: tail) := by rfl
def parallel_k24_3 : List Nat := [116,101,114,109]
theorem parallel_kd24_3 : stringBytes parallel_k24_3 = true := by decide +kernel
theorem parallel_kp24_3 (tail : List Nat) : parseStringTail (parallel_k24_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k24_3, 58 :: tail) := by rfl
def parallel_l24_3 : List (List Nat × Raw) := [(parallel_k24_3, parallel_r28)]
def parallel_v24_3 : List Nat := parallel_g69 ++ parallel_b28
theorem parallel_sl24_3 : serializeFields 4080 27 parallel_l24_3 = some parallel_v24_3 := by
  simpa only [parallel_l24_3, parallel_v24_3, parallel_k24_3, parallel_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4079 27 parallel_k24_3 parallel_r28 parallel_b28 parallel_kd24_3 parallel_s28)
theorem parallel_pl24_3 (tail : List Nat) : parseFields 4080 27 (parallel_v24_3 ++ (125 :: tail)) = some (parallel_l24_3, tail) := by
  simpa only [parallel_l24_3, parallel_v24_3, parallel_k24_3, parallel_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4079 27 (parallel_k24_3 ++ (34 :: 58 :: (parallel_b28 ++ (125 :: tail)))) parallel_k24_3 (parallel_b28 ++ (125 :: tail)) tail parallel_r28 (parallel_kp24_3 (parallel_b28 ++ (125 :: tail))) (parallel_p28 (125 :: tail)))
def parallel_l24_2 : List (List Nat × Raw) := (parallel_k24_2, parallel_r27) :: parallel_l24_3
def parallel_v24_2 : List Nat := (parallel_g66 ++ parallel_b27) ++ (44 :: parallel_v24_3)
theorem parallel_sl24_2 : serializeFields 4081 27 parallel_l24_2 = some parallel_v24_2 := by
  simpa only [parallel_l24_2, parallel_v24_2, parallel_k24_2, parallel_g66, parallel_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 parallel_k24_2 parallel_r27 (parallel_k24_3, parallel_r28) [] parallel_b27 parallel_v24_3 parallel_kd24_2 parallel_s27 parallel_sl24_3)
theorem parallel_pl24_2 (tail : List Nat) : parseFields 4081 27 (parallel_v24_2 ++ (125 :: tail)) = some (parallel_l24_2, tail) := by
  simpa only [parallel_l24_2, parallel_v24_2, parallel_k24_2, parallel_g66, parallel_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (parallel_k24_2 ++ (34 :: 58 :: (parallel_b27 ++ (44 :: (parallel_v24_3 ++ (125 :: tail)))))) parallel_k24_2 (parallel_b27 ++ (44 :: (parallel_v24_3 ++ (125 :: tail)))) (parallel_v24_3 ++ (125 :: tail)) tail parallel_r27 parallel_l24_3 (parallel_kp24_2 (parallel_b27 ++ (44 :: (parallel_v24_3 ++ (125 :: tail))))) (parallel_p27 (44 :: (parallel_v24_3 ++ (125 :: tail)))) (parallel_pl24_3 tail))
def parallel_l24_1 : List (List Nat × Raw) := (parallel_k24_1, parallel_r26) :: parallel_l24_2
def parallel_v24_1 : List Nat := (parallel_g63 ++ parallel_b26) ++ (44 :: parallel_v24_2)
theorem parallel_sl24_1 : serializeFields 4082 27 parallel_l24_1 = some parallel_v24_1 := by
  simpa only [parallel_l24_1, parallel_v24_1, parallel_k24_1, parallel_g63, parallel_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 parallel_k24_1 parallel_r26 (parallel_k24_2, parallel_r27) parallel_l24_3 parallel_b26 parallel_v24_2 parallel_kd24_1 parallel_s26 parallel_sl24_2)
theorem parallel_pl24_1 (tail : List Nat) : parseFields 4082 27 (parallel_v24_1 ++ (125 :: tail)) = some (parallel_l24_1, tail) := by
  simpa only [parallel_l24_1, parallel_v24_1, parallel_k24_1, parallel_g63, parallel_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (parallel_k24_1 ++ (34 :: 58 :: (parallel_b26 ++ (44 :: (parallel_v24_2 ++ (125 :: tail)))))) parallel_k24_1 (parallel_b26 ++ (44 :: (parallel_v24_2 ++ (125 :: tail)))) (parallel_v24_2 ++ (125 :: tail)) tail parallel_r26 parallel_l24_2 (parallel_kp24_1 (parallel_b26 ++ (44 :: (parallel_v24_2 ++ (125 :: tail))))) (parallel_p26 (44 :: (parallel_v24_2 ++ (125 :: tail)))) (parallel_pl24_2 tail))
def parallel_l24_0 : List (List Nat × Raw) := (parallel_k24_0, parallel_r25) :: parallel_l24_1
def parallel_v24_0 : List Nat := (parallel_g60 ++ parallel_b25) ++ (44 :: parallel_v24_1)
theorem parallel_sl24_0 : serializeFields 4083 27 parallel_l24_0 = some parallel_v24_0 := by
  simpa only [parallel_l24_0, parallel_v24_0, parallel_k24_0, parallel_g60, parallel_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 parallel_k24_0 parallel_r25 (parallel_k24_1, parallel_r26) parallel_l24_2 parallel_b25 parallel_v24_1 parallel_kd24_0 parallel_s25 parallel_sl24_1)
theorem parallel_pl24_0 (tail : List Nat) : parseFields 4083 27 (parallel_v24_0 ++ (125 :: tail)) = some (parallel_l24_0, tail) := by
  simpa only [parallel_l24_0, parallel_v24_0, parallel_k24_0, parallel_g60, parallel_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (parallel_k24_0 ++ (34 :: 58 :: (parallel_b25 ++ (44 :: (parallel_v24_1 ++ (125 :: tail)))))) parallel_k24_0 (parallel_b25 ++ (44 :: (parallel_v24_1 ++ (125 :: tail)))) (parallel_v24_1 ++ (125 :: tail)) tail parallel_r25 parallel_l24_1 (parallel_kp24_0 (parallel_b25 ++ (44 :: (parallel_v24_1 ++ (125 :: tail))))) (parallel_p25 (44 :: (parallel_v24_1 ++ (125 :: tail)))) (parallel_pl24_1 tail))
def parallel_r24 : Raw := (.obj parallel_l24_0)
def parallel_b24 : List Nat := parallel_g59 ++ (parallel_v24_0 ++ parallel_g71)
theorem parallel_o24 : orderedFields parallel_l24_0 = true := by decide +kernel
theorem parallel_s24 : serializeRaw 4084 28 parallel_r24 = some parallel_b24 := by
  simpa only [parallel_r24, parallel_b24, parallel_g59, parallel_g71, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4083 27 parallel_l24_0 parallel_v24_0 parallel_o24 parallel_sl24_0)
theorem parallel_p24 (tail : List Nat) : parseRaw 4084 28 (parallel_b24 ++ tail) = some (parallel_r24, tail) := by
  simpa only [parallel_r24, parallel_b24, parallel_g59, parallel_g71, parallel_v24_0, parallel_k24_0, parallel_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4083 27 (parallel_k24_0 ++ (34 :: 58 :: (parallel_b25 ++ (44 :: (parallel_v24_1 ++ (125 :: tail)))))) tail parallel_l24_0 parallel_o24 (by simpa only [parallel_v24_0, parallel_k24_0, parallel_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl24_0 tail)))
def parallel_r30 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,52])
def parallel_b30 : List Nat := parallel_g75
theorem parallel_s30 : serializeRaw 4081 27 parallel_r30 = some parallel_b30 := by decide +kernel
theorem parallel_p30 (tail : List Nat) : parseRaw 4081 27 (parallel_b30 ++ tail) = some (parallel_r30, tail) := by rfl
def parallel_r31 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,50])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def parallel_b31 : List Nat := parallel_g78
theorem parallel_s31 : serializeRaw 4080 27 parallel_r31 = some parallel_b31 := by decide +kernel
theorem parallel_p31 (tail : List Nat) : parseRaw 4080 27 (parallel_b31 ++ tail) = some (parallel_r31, tail) := by rfl
def parallel_r32 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b32 : List Nat := parallel_g81
theorem parallel_s32 : serializeRaw 4079 27 parallel_r32 = some parallel_b32 := by decide +kernel
theorem parallel_p32 (tail : List Nat) : parseRaw 4079 27 (parallel_b32 ++ tail) = some (parallel_r32, tail) := by rfl
def parallel_r33 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,50,56]),(.str [100,103,95,118,95,50,57]),(.str [100,103,95,118,95,51,50]),(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,51,51]),(.str [100,103,95,118,95,51,52])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,53]))])
def parallel_b33 : List Nat := parallel_g84
theorem parallel_s33 : serializeRaw 4078 27 parallel_r33 = some parallel_b33 := by decide +kernel
theorem parallel_p33 (tail : List Nat) : parseRaw 4078 27 (parallel_b33 ++ tail) = some (parallel_r33, tail) := by rfl
def parallel_k29_0 : List Nat := [105,100]
theorem parallel_kd29_0 : stringBytes parallel_k29_0 = true := by decide +kernel
theorem parallel_kp29_0 (tail : List Nat) : parseStringTail (parallel_k29_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k29_0, 58 :: tail) := by rfl
def parallel_k29_1 : List Nat := [111,112,115]
theorem parallel_kd29_1 : stringBytes parallel_k29_1 = true := by decide +kernel
theorem parallel_kp29_1 (tail : List Nat) : parseStringTail (parallel_k29_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k29_1, 58 :: tail) := by rfl
def parallel_k29_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd29_2 : stringBytes parallel_k29_2 = true := by decide +kernel
theorem parallel_kp29_2 (tail : List Nat) : parseStringTail (parallel_k29_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k29_2, 58 :: tail) := by rfl
def parallel_k29_3 : List Nat := [116,101,114,109]
theorem parallel_kd29_3 : stringBytes parallel_k29_3 = true := by decide +kernel
theorem parallel_kp29_3 (tail : List Nat) : parseStringTail (parallel_k29_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k29_3, 58 :: tail) := by rfl
def parallel_l29_3 : List (List Nat × Raw) := [(parallel_k29_3, parallel_r33)]
def parallel_v29_3 : List Nat := parallel_g83 ++ parallel_b33
theorem parallel_sl29_3 : serializeFields 4079 27 parallel_l29_3 = some parallel_v29_3 := by
  simpa only [parallel_l29_3, parallel_v29_3, parallel_k29_3, parallel_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4078 27 parallel_k29_3 parallel_r33 parallel_b33 parallel_kd29_3 parallel_s33)
theorem parallel_pl29_3 (tail : List Nat) : parseFields 4079 27 (parallel_v29_3 ++ (125 :: tail)) = some (parallel_l29_3, tail) := by
  simpa only [parallel_l29_3, parallel_v29_3, parallel_k29_3, parallel_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4078 27 (parallel_k29_3 ++ (34 :: 58 :: (parallel_b33 ++ (125 :: tail)))) parallel_k29_3 (parallel_b33 ++ (125 :: tail)) tail parallel_r33 (parallel_kp29_3 (parallel_b33 ++ (125 :: tail))) (parallel_p33 (125 :: tail)))
def parallel_l29_2 : List (List Nat × Raw) := (parallel_k29_2, parallel_r32) :: parallel_l29_3
def parallel_v29_2 : List Nat := (parallel_g80 ++ parallel_b32) ++ (44 :: parallel_v29_3)
theorem parallel_sl29_2 : serializeFields 4080 27 parallel_l29_2 = some parallel_v29_2 := by
  simpa only [parallel_l29_2, parallel_v29_2, parallel_k29_2, parallel_g80, parallel_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 parallel_k29_2 parallel_r32 (parallel_k29_3, parallel_r33) [] parallel_b32 parallel_v29_3 parallel_kd29_2 parallel_s32 parallel_sl29_3)
theorem parallel_pl29_2 (tail : List Nat) : parseFields 4080 27 (parallel_v29_2 ++ (125 :: tail)) = some (parallel_l29_2, tail) := by
  simpa only [parallel_l29_2, parallel_v29_2, parallel_k29_2, parallel_g80, parallel_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (parallel_k29_2 ++ (34 :: 58 :: (parallel_b32 ++ (44 :: (parallel_v29_3 ++ (125 :: tail)))))) parallel_k29_2 (parallel_b32 ++ (44 :: (parallel_v29_3 ++ (125 :: tail)))) (parallel_v29_3 ++ (125 :: tail)) tail parallel_r32 parallel_l29_3 (parallel_kp29_2 (parallel_b32 ++ (44 :: (parallel_v29_3 ++ (125 :: tail))))) (parallel_p32 (44 :: (parallel_v29_3 ++ (125 :: tail)))) (parallel_pl29_3 tail))
def parallel_l29_1 : List (List Nat × Raw) := (parallel_k29_1, parallel_r31) :: parallel_l29_2
def parallel_v29_1 : List Nat := (parallel_g77 ++ parallel_b31) ++ (44 :: parallel_v29_2)
theorem parallel_sl29_1 : serializeFields 4081 27 parallel_l29_1 = some parallel_v29_1 := by
  simpa only [parallel_l29_1, parallel_v29_1, parallel_k29_1, parallel_g77, parallel_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 parallel_k29_1 parallel_r31 (parallel_k29_2, parallel_r32) parallel_l29_3 parallel_b31 parallel_v29_2 parallel_kd29_1 parallel_s31 parallel_sl29_2)
theorem parallel_pl29_1 (tail : List Nat) : parseFields 4081 27 (parallel_v29_1 ++ (125 :: tail)) = some (parallel_l29_1, tail) := by
  simpa only [parallel_l29_1, parallel_v29_1, parallel_k29_1, parallel_g77, parallel_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (parallel_k29_1 ++ (34 :: 58 :: (parallel_b31 ++ (44 :: (parallel_v29_2 ++ (125 :: tail)))))) parallel_k29_1 (parallel_b31 ++ (44 :: (parallel_v29_2 ++ (125 :: tail)))) (parallel_v29_2 ++ (125 :: tail)) tail parallel_r31 parallel_l29_2 (parallel_kp29_1 (parallel_b31 ++ (44 :: (parallel_v29_2 ++ (125 :: tail))))) (parallel_p31 (44 :: (parallel_v29_2 ++ (125 :: tail)))) (parallel_pl29_2 tail))
def parallel_l29_0 : List (List Nat × Raw) := (parallel_k29_0, parallel_r30) :: parallel_l29_1
def parallel_v29_0 : List Nat := (parallel_g74 ++ parallel_b30) ++ (44 :: parallel_v29_1)
theorem parallel_sl29_0 : serializeFields 4082 27 parallel_l29_0 = some parallel_v29_0 := by
  simpa only [parallel_l29_0, parallel_v29_0, parallel_k29_0, parallel_g74, parallel_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 parallel_k29_0 parallel_r30 (parallel_k29_1, parallel_r31) parallel_l29_2 parallel_b30 parallel_v29_1 parallel_kd29_0 parallel_s30 parallel_sl29_1)
theorem parallel_pl29_0 (tail : List Nat) : parseFields 4082 27 (parallel_v29_0 ++ (125 :: tail)) = some (parallel_l29_0, tail) := by
  simpa only [parallel_l29_0, parallel_v29_0, parallel_k29_0, parallel_g74, parallel_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (parallel_k29_0 ++ (34 :: 58 :: (parallel_b30 ++ (44 :: (parallel_v29_1 ++ (125 :: tail)))))) parallel_k29_0 (parallel_b30 ++ (44 :: (parallel_v29_1 ++ (125 :: tail)))) (parallel_v29_1 ++ (125 :: tail)) tail parallel_r30 parallel_l29_1 (parallel_kp29_0 (parallel_b30 ++ (44 :: (parallel_v29_1 ++ (125 :: tail))))) (parallel_p30 (44 :: (parallel_v29_1 ++ (125 :: tail)))) (parallel_pl29_1 tail))
def parallel_r29 : Raw := (.obj parallel_l29_0)
def parallel_b29 : List Nat := parallel_g73 ++ (parallel_v29_0 ++ parallel_g85)
theorem parallel_o29 : orderedFields parallel_l29_0 = true := by decide +kernel
theorem parallel_s29 : serializeRaw 4083 28 parallel_r29 = some parallel_b29 := by
  simpa only [parallel_r29, parallel_b29, parallel_g73, parallel_g85, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4082 27 parallel_l29_0 parallel_v29_0 parallel_o29 parallel_sl29_0)
theorem parallel_p29 (tail : List Nat) : parseRaw 4083 28 (parallel_b29 ++ tail) = some (parallel_r29, tail) := by
  simpa only [parallel_r29, parallel_b29, parallel_g73, parallel_g85, parallel_v29_0, parallel_k29_0, parallel_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4082 27 (parallel_k29_0 ++ (34 :: 58 :: (parallel_b30 ++ (44 :: (parallel_v29_1 ++ (125 :: tail)))))) tail parallel_l29_0 parallel_o29 (by simpa only [parallel_v29_0, parallel_k29_0, parallel_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl29_0 tail)))
def parallel_r35 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,53])
def parallel_b35 : List Nat := parallel_g89
theorem parallel_s35 : serializeRaw 4080 27 parallel_r35 = some parallel_b35 := by decide +kernel
theorem parallel_p35 (tail : List Nat) : parseRaw 4080 27 (parallel_b35 ++ tail) = some (parallel_r35, tail) := by rfl
def parallel_r36 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,51,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,49])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b36 : List Nat := parallel_g92
theorem parallel_s36 : serializeRaw 4079 27 parallel_r36 = some parallel_b36 := by decide +kernel
theorem parallel_p36 (tail : List Nat) : parseRaw 4079 27 (parallel_b36 ++ tail) = some (parallel_r36, tail) := by rfl
def parallel_r37 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b37 : List Nat := parallel_g95
theorem parallel_s37 : serializeRaw 4078 27 parallel_r37 = some parallel_b37 := by decide +kernel
theorem parallel_p37 (tail : List Nat) : parseRaw 4078 27 (parallel_b37 ++ tail) = some (parallel_r37, tail) := by rfl
def parallel_r38 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,52,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,54]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,49]))]))])
def parallel_b38 : List Nat := parallel_g98
theorem parallel_s38 : serializeRaw 4077 27 parallel_r38 = some parallel_b38 := by decide +kernel
theorem parallel_p38 (tail : List Nat) : parseRaw 4077 27 (parallel_b38 ++ tail) = some (parallel_r38, tail) := by rfl
def parallel_k34_0 : List Nat := [105,100]
theorem parallel_kd34_0 : stringBytes parallel_k34_0 = true := by decide +kernel
theorem parallel_kp34_0 (tail : List Nat) : parseStringTail (parallel_k34_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k34_0, 58 :: tail) := by rfl
def parallel_k34_1 : List Nat := [111,112,115]
theorem parallel_kd34_1 : stringBytes parallel_k34_1 = true := by decide +kernel
theorem parallel_kp34_1 (tail : List Nat) : parseStringTail (parallel_k34_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k34_1, 58 :: tail) := by rfl
def parallel_k34_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd34_2 : stringBytes parallel_k34_2 = true := by decide +kernel
theorem parallel_kp34_2 (tail : List Nat) : parseStringTail (parallel_k34_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k34_2, 58 :: tail) := by rfl
def parallel_k34_3 : List Nat := [116,101,114,109]
theorem parallel_kd34_3 : stringBytes parallel_k34_3 = true := by decide +kernel
theorem parallel_kp34_3 (tail : List Nat) : parseStringTail (parallel_k34_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k34_3, 58 :: tail) := by rfl
def parallel_l34_3 : List (List Nat × Raw) := [(parallel_k34_3, parallel_r38)]
def parallel_v34_3 : List Nat := parallel_g97 ++ parallel_b38
theorem parallel_sl34_3 : serializeFields 4078 27 parallel_l34_3 = some parallel_v34_3 := by
  simpa only [parallel_l34_3, parallel_v34_3, parallel_k34_3, parallel_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4077 27 parallel_k34_3 parallel_r38 parallel_b38 parallel_kd34_3 parallel_s38)
theorem parallel_pl34_3 (tail : List Nat) : parseFields 4078 27 (parallel_v34_3 ++ (125 :: tail)) = some (parallel_l34_3, tail) := by
  simpa only [parallel_l34_3, parallel_v34_3, parallel_k34_3, parallel_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4077 27 (parallel_k34_3 ++ (34 :: 58 :: (parallel_b38 ++ (125 :: tail)))) parallel_k34_3 (parallel_b38 ++ (125 :: tail)) tail parallel_r38 (parallel_kp34_3 (parallel_b38 ++ (125 :: tail))) (parallel_p38 (125 :: tail)))
def parallel_l34_2 : List (List Nat × Raw) := (parallel_k34_2, parallel_r37) :: parallel_l34_3
def parallel_v34_2 : List Nat := (parallel_g94 ++ parallel_b37) ++ (44 :: parallel_v34_3)
theorem parallel_sl34_2 : serializeFields 4079 27 parallel_l34_2 = some parallel_v34_2 := by
  simpa only [parallel_l34_2, parallel_v34_2, parallel_k34_2, parallel_g94, parallel_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 parallel_k34_2 parallel_r37 (parallel_k34_3, parallel_r38) [] parallel_b37 parallel_v34_3 parallel_kd34_2 parallel_s37 parallel_sl34_3)
theorem parallel_pl34_2 (tail : List Nat) : parseFields 4079 27 (parallel_v34_2 ++ (125 :: tail)) = some (parallel_l34_2, tail) := by
  simpa only [parallel_l34_2, parallel_v34_2, parallel_k34_2, parallel_g94, parallel_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (parallel_k34_2 ++ (34 :: 58 :: (parallel_b37 ++ (44 :: (parallel_v34_3 ++ (125 :: tail)))))) parallel_k34_2 (parallel_b37 ++ (44 :: (parallel_v34_3 ++ (125 :: tail)))) (parallel_v34_3 ++ (125 :: tail)) tail parallel_r37 parallel_l34_3 (parallel_kp34_2 (parallel_b37 ++ (44 :: (parallel_v34_3 ++ (125 :: tail))))) (parallel_p37 (44 :: (parallel_v34_3 ++ (125 :: tail)))) (parallel_pl34_3 tail))
def parallel_l34_1 : List (List Nat × Raw) := (parallel_k34_1, parallel_r36) :: parallel_l34_2
def parallel_v34_1 : List Nat := (parallel_g91 ++ parallel_b36) ++ (44 :: parallel_v34_2)
theorem parallel_sl34_1 : serializeFields 4080 27 parallel_l34_1 = some parallel_v34_1 := by
  simpa only [parallel_l34_1, parallel_v34_1, parallel_k34_1, parallel_g91, parallel_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 parallel_k34_1 parallel_r36 (parallel_k34_2, parallel_r37) parallel_l34_3 parallel_b36 parallel_v34_2 parallel_kd34_1 parallel_s36 parallel_sl34_2)
theorem parallel_pl34_1 (tail : List Nat) : parseFields 4080 27 (parallel_v34_1 ++ (125 :: tail)) = some (parallel_l34_1, tail) := by
  simpa only [parallel_l34_1, parallel_v34_1, parallel_k34_1, parallel_g91, parallel_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (parallel_k34_1 ++ (34 :: 58 :: (parallel_b36 ++ (44 :: (parallel_v34_2 ++ (125 :: tail)))))) parallel_k34_1 (parallel_b36 ++ (44 :: (parallel_v34_2 ++ (125 :: tail)))) (parallel_v34_2 ++ (125 :: tail)) tail parallel_r36 parallel_l34_2 (parallel_kp34_1 (parallel_b36 ++ (44 :: (parallel_v34_2 ++ (125 :: tail))))) (parallel_p36 (44 :: (parallel_v34_2 ++ (125 :: tail)))) (parallel_pl34_2 tail))
def parallel_l34_0 : List (List Nat × Raw) := (parallel_k34_0, parallel_r35) :: parallel_l34_1
def parallel_v34_0 : List Nat := (parallel_g88 ++ parallel_b35) ++ (44 :: parallel_v34_1)
theorem parallel_sl34_0 : serializeFields 4081 27 parallel_l34_0 = some parallel_v34_0 := by
  simpa only [parallel_l34_0, parallel_v34_0, parallel_k34_0, parallel_g88, parallel_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 parallel_k34_0 parallel_r35 (parallel_k34_1, parallel_r36) parallel_l34_2 parallel_b35 parallel_v34_1 parallel_kd34_0 parallel_s35 parallel_sl34_1)
theorem parallel_pl34_0 (tail : List Nat) : parseFields 4081 27 (parallel_v34_0 ++ (125 :: tail)) = some (parallel_l34_0, tail) := by
  simpa only [parallel_l34_0, parallel_v34_0, parallel_k34_0, parallel_g88, parallel_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (parallel_k34_0 ++ (34 :: 58 :: (parallel_b35 ++ (44 :: (parallel_v34_1 ++ (125 :: tail)))))) parallel_k34_0 (parallel_b35 ++ (44 :: (parallel_v34_1 ++ (125 :: tail)))) (parallel_v34_1 ++ (125 :: tail)) tail parallel_r35 parallel_l34_1 (parallel_kp34_0 (parallel_b35 ++ (44 :: (parallel_v34_1 ++ (125 :: tail))))) (parallel_p35 (44 :: (parallel_v34_1 ++ (125 :: tail)))) (parallel_pl34_1 tail))
def parallel_r34 : Raw := (.obj parallel_l34_0)
def parallel_b34 : List Nat := parallel_g87 ++ (parallel_v34_0 ++ parallel_g99)
theorem parallel_o34 : orderedFields parallel_l34_0 = true := by decide +kernel
theorem parallel_s34 : serializeRaw 4082 28 parallel_r34 = some parallel_b34 := by
  simpa only [parallel_r34, parallel_b34, parallel_g87, parallel_g99, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4081 27 parallel_l34_0 parallel_v34_0 parallel_o34 parallel_sl34_0)
theorem parallel_p34 (tail : List Nat) : parseRaw 4082 28 (parallel_b34 ++ tail) = some (parallel_r34, tail) := by
  simpa only [parallel_r34, parallel_b34, parallel_g87, parallel_g99, parallel_v34_0, parallel_k34_0, parallel_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4081 27 (parallel_k34_0 ++ (34 :: 58 :: (parallel_b35 ++ (44 :: (parallel_v34_1 ++ (125 :: tail)))))) tail parallel_l34_0 parallel_o34 (by simpa only [parallel_v34_0, parallel_k34_0, parallel_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl34_0 tail)))
def parallel_r40 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,54])
def parallel_b40 : List Nat := parallel_g103
theorem parallel_s40 : serializeRaw 4079 27 parallel_r40 = some parallel_b40 := by decide +kernel
theorem parallel_p40 (tail : List Nat) : parseRaw 4079 27 (parallel_b40 ++ tail) = some (parallel_r40, tail) := by rfl
def parallel_r41 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def parallel_b41 : List Nat := parallel_g106
theorem parallel_s41 : serializeRaw 4078 27 parallel_r41 = some parallel_b41 := by decide +kernel
theorem parallel_p41 (tail : List Nat) : parseRaw 4078 27 (parallel_b41 ++ tail) = some (parallel_r41, tail) := by rfl
def parallel_r42 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,53])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,54])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b42 : List Nat := parallel_g109
theorem parallel_s42 : serializeRaw 4077 27 parallel_r42 = some parallel_b42 := by decide +kernel
theorem parallel_p42 (tail : List Nat) : parseRaw 4077 27 (parallel_b42 ++ tail) = some (parallel_r42, tail) := by rfl
def parallel_r43 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,52,54])]))])
def parallel_b43 : List Nat := parallel_g112
theorem parallel_s43 : serializeRaw 4076 27 parallel_r43 = some parallel_b43 := by decide +kernel
theorem parallel_p43 (tail : List Nat) : parseRaw 4076 27 (parallel_b43 ++ tail) = some (parallel_r43, tail) := by rfl
def parallel_k39_0 : List Nat := [105,100]
theorem parallel_kd39_0 : stringBytes parallel_k39_0 = true := by decide +kernel
theorem parallel_kp39_0 (tail : List Nat) : parseStringTail (parallel_k39_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k39_0, 58 :: tail) := by rfl
def parallel_k39_1 : List Nat := [111,112,115]
theorem parallel_kd39_1 : stringBytes parallel_k39_1 = true := by decide +kernel
theorem parallel_kp39_1 (tail : List Nat) : parseStringTail (parallel_k39_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k39_1, 58 :: tail) := by rfl
def parallel_k39_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd39_2 : stringBytes parallel_k39_2 = true := by decide +kernel
theorem parallel_kp39_2 (tail : List Nat) : parseStringTail (parallel_k39_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k39_2, 58 :: tail) := by rfl
def parallel_k39_3 : List Nat := [116,101,114,109]
theorem parallel_kd39_3 : stringBytes parallel_k39_3 = true := by decide +kernel
theorem parallel_kp39_3 (tail : List Nat) : parseStringTail (parallel_k39_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k39_3, 58 :: tail) := by rfl
def parallel_l39_3 : List (List Nat × Raw) := [(parallel_k39_3, parallel_r43)]
def parallel_v39_3 : List Nat := parallel_g111 ++ parallel_b43
theorem parallel_sl39_3 : serializeFields 4077 27 parallel_l39_3 = some parallel_v39_3 := by
  simpa only [parallel_l39_3, parallel_v39_3, parallel_k39_3, parallel_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4076 27 parallel_k39_3 parallel_r43 parallel_b43 parallel_kd39_3 parallel_s43)
theorem parallel_pl39_3 (tail : List Nat) : parseFields 4077 27 (parallel_v39_3 ++ (125 :: tail)) = some (parallel_l39_3, tail) := by
  simpa only [parallel_l39_3, parallel_v39_3, parallel_k39_3, parallel_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4076 27 (parallel_k39_3 ++ (34 :: 58 :: (parallel_b43 ++ (125 :: tail)))) parallel_k39_3 (parallel_b43 ++ (125 :: tail)) tail parallel_r43 (parallel_kp39_3 (parallel_b43 ++ (125 :: tail))) (parallel_p43 (125 :: tail)))
def parallel_l39_2 : List (List Nat × Raw) := (parallel_k39_2, parallel_r42) :: parallel_l39_3
def parallel_v39_2 : List Nat := (parallel_g108 ++ parallel_b42) ++ (44 :: parallel_v39_3)
theorem parallel_sl39_2 : serializeFields 4078 27 parallel_l39_2 = some parallel_v39_2 := by
  simpa only [parallel_l39_2, parallel_v39_2, parallel_k39_2, parallel_g108, parallel_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 parallel_k39_2 parallel_r42 (parallel_k39_3, parallel_r43) [] parallel_b42 parallel_v39_3 parallel_kd39_2 parallel_s42 parallel_sl39_3)
theorem parallel_pl39_2 (tail : List Nat) : parseFields 4078 27 (parallel_v39_2 ++ (125 :: tail)) = some (parallel_l39_2, tail) := by
  simpa only [parallel_l39_2, parallel_v39_2, parallel_k39_2, parallel_g108, parallel_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (parallel_k39_2 ++ (34 :: 58 :: (parallel_b42 ++ (44 :: (parallel_v39_3 ++ (125 :: tail)))))) parallel_k39_2 (parallel_b42 ++ (44 :: (parallel_v39_3 ++ (125 :: tail)))) (parallel_v39_3 ++ (125 :: tail)) tail parallel_r42 parallel_l39_3 (parallel_kp39_2 (parallel_b42 ++ (44 :: (parallel_v39_3 ++ (125 :: tail))))) (parallel_p42 (44 :: (parallel_v39_3 ++ (125 :: tail)))) (parallel_pl39_3 tail))
def parallel_l39_1 : List (List Nat × Raw) := (parallel_k39_1, parallel_r41) :: parallel_l39_2
def parallel_v39_1 : List Nat := (parallel_g105 ++ parallel_b41) ++ (44 :: parallel_v39_2)
theorem parallel_sl39_1 : serializeFields 4079 27 parallel_l39_1 = some parallel_v39_1 := by
  simpa only [parallel_l39_1, parallel_v39_1, parallel_k39_1, parallel_g105, parallel_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 parallel_k39_1 parallel_r41 (parallel_k39_2, parallel_r42) parallel_l39_3 parallel_b41 parallel_v39_2 parallel_kd39_1 parallel_s41 parallel_sl39_2)
theorem parallel_pl39_1 (tail : List Nat) : parseFields 4079 27 (parallel_v39_1 ++ (125 :: tail)) = some (parallel_l39_1, tail) := by
  simpa only [parallel_l39_1, parallel_v39_1, parallel_k39_1, parallel_g105, parallel_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (parallel_k39_1 ++ (34 :: 58 :: (parallel_b41 ++ (44 :: (parallel_v39_2 ++ (125 :: tail)))))) parallel_k39_1 (parallel_b41 ++ (44 :: (parallel_v39_2 ++ (125 :: tail)))) (parallel_v39_2 ++ (125 :: tail)) tail parallel_r41 parallel_l39_2 (parallel_kp39_1 (parallel_b41 ++ (44 :: (parallel_v39_2 ++ (125 :: tail))))) (parallel_p41 (44 :: (parallel_v39_2 ++ (125 :: tail)))) (parallel_pl39_2 tail))
def parallel_l39_0 : List (List Nat × Raw) := (parallel_k39_0, parallel_r40) :: parallel_l39_1
def parallel_v39_0 : List Nat := (parallel_g102 ++ parallel_b40) ++ (44 :: parallel_v39_1)
theorem parallel_sl39_0 : serializeFields 4080 27 parallel_l39_0 = some parallel_v39_0 := by
  simpa only [parallel_l39_0, parallel_v39_0, parallel_k39_0, parallel_g102, parallel_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 parallel_k39_0 parallel_r40 (parallel_k39_1, parallel_r41) parallel_l39_2 parallel_b40 parallel_v39_1 parallel_kd39_0 parallel_s40 parallel_sl39_1)
theorem parallel_pl39_0 (tail : List Nat) : parseFields 4080 27 (parallel_v39_0 ++ (125 :: tail)) = some (parallel_l39_0, tail) := by
  simpa only [parallel_l39_0, parallel_v39_0, parallel_k39_0, parallel_g102, parallel_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (parallel_k39_0 ++ (34 :: 58 :: (parallel_b40 ++ (44 :: (parallel_v39_1 ++ (125 :: tail)))))) parallel_k39_0 (parallel_b40 ++ (44 :: (parallel_v39_1 ++ (125 :: tail)))) (parallel_v39_1 ++ (125 :: tail)) tail parallel_r40 parallel_l39_1 (parallel_kp39_0 (parallel_b40 ++ (44 :: (parallel_v39_1 ++ (125 :: tail))))) (parallel_p40 (44 :: (parallel_v39_1 ++ (125 :: tail)))) (parallel_pl39_1 tail))
def parallel_r39 : Raw := (.obj parallel_l39_0)
def parallel_b39 : List Nat := parallel_g101 ++ (parallel_v39_0 ++ parallel_g113)
theorem parallel_o39 : orderedFields parallel_l39_0 = true := by decide +kernel
theorem parallel_s39 : serializeRaw 4081 28 parallel_r39 = some parallel_b39 := by
  simpa only [parallel_r39, parallel_b39, parallel_g101, parallel_g113, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4080 27 parallel_l39_0 parallel_v39_0 parallel_o39 parallel_sl39_0)
theorem parallel_p39 (tail : List Nat) : parseRaw 4081 28 (parallel_b39 ++ tail) = some (parallel_r39, tail) := by
  simpa only [parallel_r39, parallel_b39, parallel_g101, parallel_g113, parallel_v39_0, parallel_k39_0, parallel_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4080 27 (parallel_k39_0 ++ (34 :: 58 :: (parallel_b40 ++ (44 :: (parallel_v39_1 ++ (125 :: tail)))))) tail parallel_l39_0 parallel_o39 (by simpa only [parallel_v39_0, parallel_k39_0, parallel_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl39_0 tail)))
def parallel_r45 : Raw := (.str [100,103,95,102,97,115,116,95,48])
def parallel_b45 : List Nat := parallel_g117
theorem parallel_s45 : serializeRaw 4078 27 parallel_r45 = some parallel_b45 := by decide +kernel
theorem parallel_p45 (tail : List Nat) : parseRaw 4078 27 (parallel_b45 ++ tail) = some (parallel_r45, tail) := by rfl
def parallel_r46 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,53]),(.str [100,103,95,118,95,53,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,54])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b46 : List Nat := parallel_g120
theorem parallel_s46 : serializeRaw 4077 27 parallel_r46 = some parallel_b46 := by decide +kernel
theorem parallel_p46 (tail : List Nat) : parseRaw 4077 27 (parallel_b46 ++ tail) = some (parallel_r46, tail) := by rfl
def parallel_r47 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b47 : List Nat := parallel_g123
theorem parallel_s47 : serializeRaw 4076 27 parallel_r47 = some parallel_b47 := by decide +kernel
theorem parallel_p47 (tail : List Nat) : parseRaw 4076 27 (parallel_b47 ++ tail) = some (parallel_r47, tail) := by rfl
def parallel_r48 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,53,54])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,53]),(.str [100,103,95,118,95,53,52])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def parallel_b48 : List Nat := parallel_g126
theorem parallel_s48 : serializeRaw 4075 27 parallel_r48 = some parallel_b48 := by decide +kernel
theorem parallel_p48 (tail : List Nat) : parseRaw 4075 27 (parallel_b48 ++ tail) = some (parallel_r48, tail) := by rfl
def parallel_k44_0 : List Nat := [105,100]
theorem parallel_kd44_0 : stringBytes parallel_k44_0 = true := by decide +kernel
theorem parallel_kp44_0 (tail : List Nat) : parseStringTail (parallel_k44_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k44_0, 58 :: tail) := by rfl
def parallel_k44_1 : List Nat := [111,112,115]
theorem parallel_kd44_1 : stringBytes parallel_k44_1 = true := by decide +kernel
theorem parallel_kp44_1 (tail : List Nat) : parseStringTail (parallel_k44_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k44_1, 58 :: tail) := by rfl
def parallel_k44_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd44_2 : stringBytes parallel_k44_2 = true := by decide +kernel
theorem parallel_kp44_2 (tail : List Nat) : parseStringTail (parallel_k44_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k44_2, 58 :: tail) := by rfl
def parallel_k44_3 : List Nat := [116,101,114,109]
theorem parallel_kd44_3 : stringBytes parallel_k44_3 = true := by decide +kernel
theorem parallel_kp44_3 (tail : List Nat) : parseStringTail (parallel_k44_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k44_3, 58 :: tail) := by rfl
def parallel_l44_3 : List (List Nat × Raw) := [(parallel_k44_3, parallel_r48)]
def parallel_v44_3 : List Nat := parallel_g125 ++ parallel_b48
theorem parallel_sl44_3 : serializeFields 4076 27 parallel_l44_3 = some parallel_v44_3 := by
  simpa only [parallel_l44_3, parallel_v44_3, parallel_k44_3, parallel_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4075 27 parallel_k44_3 parallel_r48 parallel_b48 parallel_kd44_3 parallel_s48)
theorem parallel_pl44_3 (tail : List Nat) : parseFields 4076 27 (parallel_v44_3 ++ (125 :: tail)) = some (parallel_l44_3, tail) := by
  simpa only [parallel_l44_3, parallel_v44_3, parallel_k44_3, parallel_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4075 27 (parallel_k44_3 ++ (34 :: 58 :: (parallel_b48 ++ (125 :: tail)))) parallel_k44_3 (parallel_b48 ++ (125 :: tail)) tail parallel_r48 (parallel_kp44_3 (parallel_b48 ++ (125 :: tail))) (parallel_p48 (125 :: tail)))
def parallel_l44_2 : List (List Nat × Raw) := (parallel_k44_2, parallel_r47) :: parallel_l44_3
def parallel_v44_2 : List Nat := (parallel_g122 ++ parallel_b47) ++ (44 :: parallel_v44_3)
theorem parallel_sl44_2 : serializeFields 4077 27 parallel_l44_2 = some parallel_v44_2 := by
  simpa only [parallel_l44_2, parallel_v44_2, parallel_k44_2, parallel_g122, parallel_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 parallel_k44_2 parallel_r47 (parallel_k44_3, parallel_r48) [] parallel_b47 parallel_v44_3 parallel_kd44_2 parallel_s47 parallel_sl44_3)
theorem parallel_pl44_2 (tail : List Nat) : parseFields 4077 27 (parallel_v44_2 ++ (125 :: tail)) = some (parallel_l44_2, tail) := by
  simpa only [parallel_l44_2, parallel_v44_2, parallel_k44_2, parallel_g122, parallel_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (parallel_k44_2 ++ (34 :: 58 :: (parallel_b47 ++ (44 :: (parallel_v44_3 ++ (125 :: tail)))))) parallel_k44_2 (parallel_b47 ++ (44 :: (parallel_v44_3 ++ (125 :: tail)))) (parallel_v44_3 ++ (125 :: tail)) tail parallel_r47 parallel_l44_3 (parallel_kp44_2 (parallel_b47 ++ (44 :: (parallel_v44_3 ++ (125 :: tail))))) (parallel_p47 (44 :: (parallel_v44_3 ++ (125 :: tail)))) (parallel_pl44_3 tail))
def parallel_l44_1 : List (List Nat × Raw) := (parallel_k44_1, parallel_r46) :: parallel_l44_2
def parallel_v44_1 : List Nat := (parallel_g119 ++ parallel_b46) ++ (44 :: parallel_v44_2)
theorem parallel_sl44_1 : serializeFields 4078 27 parallel_l44_1 = some parallel_v44_1 := by
  simpa only [parallel_l44_1, parallel_v44_1, parallel_k44_1, parallel_g119, parallel_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 parallel_k44_1 parallel_r46 (parallel_k44_2, parallel_r47) parallel_l44_3 parallel_b46 parallel_v44_2 parallel_kd44_1 parallel_s46 parallel_sl44_2)
theorem parallel_pl44_1 (tail : List Nat) : parseFields 4078 27 (parallel_v44_1 ++ (125 :: tail)) = some (parallel_l44_1, tail) := by
  simpa only [parallel_l44_1, parallel_v44_1, parallel_k44_1, parallel_g119, parallel_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (parallel_k44_1 ++ (34 :: 58 :: (parallel_b46 ++ (44 :: (parallel_v44_2 ++ (125 :: tail)))))) parallel_k44_1 (parallel_b46 ++ (44 :: (parallel_v44_2 ++ (125 :: tail)))) (parallel_v44_2 ++ (125 :: tail)) tail parallel_r46 parallel_l44_2 (parallel_kp44_1 (parallel_b46 ++ (44 :: (parallel_v44_2 ++ (125 :: tail))))) (parallel_p46 (44 :: (parallel_v44_2 ++ (125 :: tail)))) (parallel_pl44_2 tail))
def parallel_l44_0 : List (List Nat × Raw) := (parallel_k44_0, parallel_r45) :: parallel_l44_1
def parallel_v44_0 : List Nat := (parallel_g116 ++ parallel_b45) ++ (44 :: parallel_v44_1)
theorem parallel_sl44_0 : serializeFields 4079 27 parallel_l44_0 = some parallel_v44_0 := by
  simpa only [parallel_l44_0, parallel_v44_0, parallel_k44_0, parallel_g116, parallel_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 parallel_k44_0 parallel_r45 (parallel_k44_1, parallel_r46) parallel_l44_2 parallel_b45 parallel_v44_1 parallel_kd44_0 parallel_s45 parallel_sl44_1)
theorem parallel_pl44_0 (tail : List Nat) : parseFields 4079 27 (parallel_v44_0 ++ (125 :: tail)) = some (parallel_l44_0, tail) := by
  simpa only [parallel_l44_0, parallel_v44_0, parallel_k44_0, parallel_g116, parallel_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (parallel_k44_0 ++ (34 :: 58 :: (parallel_b45 ++ (44 :: (parallel_v44_1 ++ (125 :: tail)))))) parallel_k44_0 (parallel_b45 ++ (44 :: (parallel_v44_1 ++ (125 :: tail)))) (parallel_v44_1 ++ (125 :: tail)) tail parallel_r45 parallel_l44_1 (parallel_kp44_0 (parallel_b45 ++ (44 :: (parallel_v44_1 ++ (125 :: tail))))) (parallel_p45 (44 :: (parallel_v44_1 ++ (125 :: tail)))) (parallel_pl44_1 tail))
def parallel_r44 : Raw := (.obj parallel_l44_0)
def parallel_b44 : List Nat := parallel_g115 ++ (parallel_v44_0 ++ parallel_g127)
theorem parallel_o44 : orderedFields parallel_l44_0 = true := by decide +kernel
theorem parallel_s44 : serializeRaw 4080 28 parallel_r44 = some parallel_b44 := by
  simpa only [parallel_r44, parallel_b44, parallel_g115, parallel_g127, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4079 27 parallel_l44_0 parallel_v44_0 parallel_o44 parallel_sl44_0)
theorem parallel_p44 (tail : List Nat) : parseRaw 4080 28 (parallel_b44 ++ tail) = some (parallel_r44, tail) := by
  simpa only [parallel_r44, parallel_b44, parallel_g115, parallel_g127, parallel_v44_0, parallel_k44_0, parallel_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4079 27 (parallel_k44_0 ++ (34 :: 58 :: (parallel_b45 ++ (44 :: (parallel_v44_1 ++ (125 :: tail)))))) tail parallel_l44_0 parallel_o44 (by simpa only [parallel_v44_0, parallel_k44_0, parallel_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl44_0 tail)))
def parallel_r50 : Raw := (.str [100,103,95,102,97,115,116,95,49])
def parallel_b50 : List Nat := parallel_g131
theorem parallel_s50 : serializeRaw 4077 27 parallel_r50 = some parallel_b50 := by decide +kernel
theorem parallel_p50 (tail : List Nat) : parseRaw 4077 27 (parallel_b50 ++ tail) = some (parallel_r50, tail) := by rfl
def parallel_r52 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,50])),([116,121,112,101],(.str [117,51,50]))])]))])
def parallel_b52 : List Nat := parallel_g135
theorem parallel_s52 : serializeRaw 4074 26 parallel_r52 = some parallel_b52 := by decide +kernel
theorem parallel_p52 (tail : List Nat) : parseRaw 4074 26 (parallel_b52 ++ tail) = some (parallel_r52, tail) := by rfl
def parallel_r53 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,50]),(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,51])),([116,121,112,101],(.str [117,51,50]))])]))])
def parallel_b53 : List Nat := parallel_g137
theorem parallel_s53 : serializeRaw 4073 26 parallel_r53 = some parallel_b53 := by decide +kernel
theorem parallel_p53 (tail : List Nat) : parseRaw 4073 26 (parallel_b53 ++ tail) = some (parallel_r53, tail) := by rfl
def parallel_r54 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,52])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b54 : List Nat := parallel_g139
theorem parallel_s54 : serializeRaw 4072 26 parallel_r54 = some parallel_b54 := by decide +kernel
theorem parallel_p54 (tail : List Nat) : parseRaw 4072 26 (parallel_b54 ++ tail) = some (parallel_r54, tail) := by rfl
def parallel_r55 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,53])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b55 : List Nat := parallel_g141
theorem parallel_s55 : serializeRaw 4071 26 parallel_r55 = some parallel_b55 := by decide +kernel
theorem parallel_p55 (tail : List Nat) : parseRaw 4071 26 (parallel_b55 ++ tail) = some (parallel_r55, tail) := by rfl
def parallel_r56 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,52]),(.str [100,103,95,118,95,54,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,54])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b56 : List Nat := parallel_g143
theorem parallel_s56 : serializeRaw 4070 26 parallel_r56 = some parallel_b56 := by decide +kernel
theorem parallel_p56 (tail : List Nat) : parseRaw 4070 26 (parallel_b56 ++ tail) = some (parallel_r56, tail) := by rfl
def parallel_r57 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,54])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,55])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b57 : List Nat := parallel_g145
theorem parallel_s57 : serializeRaw 4069 26 parallel_r57 = some parallel_b57 := by decide +kernel
theorem parallel_p57 (tail : List Nat) : parseRaw 4069 26 (parallel_b57 ++ tail) = some (parallel_r57, tail) := by rfl
def parallel_r58 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,56])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def parallel_b58 : List Nat := parallel_g147
theorem parallel_s58 : serializeRaw 4068 26 parallel_r58 = some parallel_b58 := by decide +kernel
theorem parallel_p58 (tail : List Nat) : parseRaw 4068 26 (parallel_b58 ++ tail) = some (parallel_r58, tail) := by rfl
def parallel_r59 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56]),(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def parallel_b59 : List Nat := parallel_g149
theorem parallel_s59 : serializeRaw 4067 26 parallel_r59 = some parallel_b59 := by decide +kernel
theorem parallel_p59 (tail : List Nat) : parseRaw 4067 26 (parallel_b59 ++ tail) = some (parallel_r59, tail) := by rfl
def parallel_r60 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def parallel_b60 : List Nat := parallel_g151
theorem parallel_s60 : serializeRaw 4066 26 parallel_r60 = some parallel_b60 := by decide +kernel
theorem parallel_p60 (tail : List Nat) : parseRaw 4066 26 (parallel_b60 ++ tail) = some (parallel_r60, tail) := by rfl
def parallel_r61 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b61 : List Nat := parallel_g153
theorem parallel_s61 : serializeRaw 4065 26 parallel_r61 = some parallel_b61 := by decide +kernel
theorem parallel_p61 (tail : List Nat) : parseRaw 4065 26 (parallel_b61 ++ tail) = some (parallel_r61, tail) := by rfl
def parallel_r62 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b62 : List Nat := parallel_g155
theorem parallel_s62 : serializeRaw 4064 26 parallel_r62 = some parallel_b62 := by decide +kernel
theorem parallel_p62 (tail : List Nat) : parseRaw 4064 26 (parallel_b62 ++ tail) = some (parallel_r62, tail) := by rfl
def parallel_l51_10 : List Raw := [parallel_r62]
def parallel_v51_10 : List Nat := parallel_b62
theorem parallel_sl51_10 : serializeItems 4065 26 parallel_l51_10 = some parallel_v51_10 := by
  simpa only [parallel_l51_10, parallel_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4064 26 parallel_r62 parallel_b62 parallel_s62)
theorem parallel_pl51_10 (tail : List Nat) : parseItems 4065 26 (parallel_v51_10 ++ (93 :: tail)) = some (parallel_l51_10, tail) := by
  simpa only [parallel_l51_10, parallel_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4064 26 (parallel_b62 ++ (93 :: tail)) tail parallel_r62 (parallel_p62 (93 :: tail)))
def parallel_l51_9 : List Raw := parallel_r61 :: parallel_l51_10
def parallel_v51_9 : List Nat := (parallel_b61) ++ (44 :: parallel_v51_10)
theorem parallel_sl51_9 : serializeItems 4066 26 parallel_l51_9 = some parallel_v51_9 := by
  simpa only [parallel_l51_9, parallel_v51_9, parallel_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 parallel_r61 parallel_r62 [] parallel_b61 parallel_v51_10 parallel_s61 parallel_sl51_10)
theorem parallel_pl51_9 (tail : List Nat) : parseItems 4066 26 (parallel_v51_9 ++ (93 :: tail)) = some (parallel_l51_9, tail) := by
  simpa only [parallel_l51_9, parallel_v51_9, parallel_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (parallel_b61 ++ (44 :: (parallel_v51_10 ++ (93 :: tail)))) (parallel_v51_10 ++ (93 :: tail)) tail parallel_r61 parallel_l51_10 (parallel_p61 (44 :: (parallel_v51_10 ++ (93 :: tail)))) (parallel_pl51_10 tail))
def parallel_l51_8 : List Raw := parallel_r60 :: parallel_l51_9
def parallel_v51_8 : List Nat := (parallel_b60) ++ (44 :: parallel_v51_9)
theorem parallel_sl51_8 : serializeItems 4067 26 parallel_l51_8 = some parallel_v51_8 := by
  simpa only [parallel_l51_8, parallel_v51_8, parallel_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 parallel_r60 parallel_r61 parallel_l51_10 parallel_b60 parallel_v51_9 parallel_s60 parallel_sl51_9)
theorem parallel_pl51_8 (tail : List Nat) : parseItems 4067 26 (parallel_v51_8 ++ (93 :: tail)) = some (parallel_l51_8, tail) := by
  simpa only [parallel_l51_8, parallel_v51_8, parallel_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (parallel_b60 ++ (44 :: (parallel_v51_9 ++ (93 :: tail)))) (parallel_v51_9 ++ (93 :: tail)) tail parallel_r60 parallel_l51_9 (parallel_p60 (44 :: (parallel_v51_9 ++ (93 :: tail)))) (parallel_pl51_9 tail))
def parallel_l51_7 : List Raw := parallel_r59 :: parallel_l51_8
def parallel_v51_7 : List Nat := (parallel_b59) ++ (44 :: parallel_v51_8)
theorem parallel_sl51_7 : serializeItems 4068 26 parallel_l51_7 = some parallel_v51_7 := by
  simpa only [parallel_l51_7, parallel_v51_7, parallel_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 parallel_r59 parallel_r60 parallel_l51_9 parallel_b59 parallel_v51_8 parallel_s59 parallel_sl51_8)
theorem parallel_pl51_7 (tail : List Nat) : parseItems 4068 26 (parallel_v51_7 ++ (93 :: tail)) = some (parallel_l51_7, tail) := by
  simpa only [parallel_l51_7, parallel_v51_7, parallel_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (parallel_b59 ++ (44 :: (parallel_v51_8 ++ (93 :: tail)))) (parallel_v51_8 ++ (93 :: tail)) tail parallel_r59 parallel_l51_8 (parallel_p59 (44 :: (parallel_v51_8 ++ (93 :: tail)))) (parallel_pl51_8 tail))
def parallel_l51_6 : List Raw := parallel_r58 :: parallel_l51_7
def parallel_v51_6 : List Nat := (parallel_b58) ++ (44 :: parallel_v51_7)
theorem parallel_sl51_6 : serializeItems 4069 26 parallel_l51_6 = some parallel_v51_6 := by
  simpa only [parallel_l51_6, parallel_v51_6, parallel_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 parallel_r58 parallel_r59 parallel_l51_8 parallel_b58 parallel_v51_7 parallel_s58 parallel_sl51_7)
theorem parallel_pl51_6 (tail : List Nat) : parseItems 4069 26 (parallel_v51_6 ++ (93 :: tail)) = some (parallel_l51_6, tail) := by
  simpa only [parallel_l51_6, parallel_v51_6, parallel_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (parallel_b58 ++ (44 :: (parallel_v51_7 ++ (93 :: tail)))) (parallel_v51_7 ++ (93 :: tail)) tail parallel_r58 parallel_l51_7 (parallel_p58 (44 :: (parallel_v51_7 ++ (93 :: tail)))) (parallel_pl51_7 tail))
def parallel_l51_5 : List Raw := parallel_r57 :: parallel_l51_6
def parallel_v51_5 : List Nat := (parallel_b57) ++ (44 :: parallel_v51_6)
theorem parallel_sl51_5 : serializeItems 4070 26 parallel_l51_5 = some parallel_v51_5 := by
  simpa only [parallel_l51_5, parallel_v51_5, parallel_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 parallel_r57 parallel_r58 parallel_l51_7 parallel_b57 parallel_v51_6 parallel_s57 parallel_sl51_6)
theorem parallel_pl51_5 (tail : List Nat) : parseItems 4070 26 (parallel_v51_5 ++ (93 :: tail)) = some (parallel_l51_5, tail) := by
  simpa only [parallel_l51_5, parallel_v51_5, parallel_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (parallel_b57 ++ (44 :: (parallel_v51_6 ++ (93 :: tail)))) (parallel_v51_6 ++ (93 :: tail)) tail parallel_r57 parallel_l51_6 (parallel_p57 (44 :: (parallel_v51_6 ++ (93 :: tail)))) (parallel_pl51_6 tail))
def parallel_l51_4 : List Raw := parallel_r56 :: parallel_l51_5
def parallel_v51_4 : List Nat := (parallel_b56) ++ (44 :: parallel_v51_5)
theorem parallel_sl51_4 : serializeItems 4071 26 parallel_l51_4 = some parallel_v51_4 := by
  simpa only [parallel_l51_4, parallel_v51_4, parallel_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 parallel_r56 parallel_r57 parallel_l51_6 parallel_b56 parallel_v51_5 parallel_s56 parallel_sl51_5)
theorem parallel_pl51_4 (tail : List Nat) : parseItems 4071 26 (parallel_v51_4 ++ (93 :: tail)) = some (parallel_l51_4, tail) := by
  simpa only [parallel_l51_4, parallel_v51_4, parallel_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (parallel_b56 ++ (44 :: (parallel_v51_5 ++ (93 :: tail)))) (parallel_v51_5 ++ (93 :: tail)) tail parallel_r56 parallel_l51_5 (parallel_p56 (44 :: (parallel_v51_5 ++ (93 :: tail)))) (parallel_pl51_5 tail))
def parallel_l51_3 : List Raw := parallel_r55 :: parallel_l51_4
def parallel_v51_3 : List Nat := (parallel_b55) ++ (44 :: parallel_v51_4)
theorem parallel_sl51_3 : serializeItems 4072 26 parallel_l51_3 = some parallel_v51_3 := by
  simpa only [parallel_l51_3, parallel_v51_3, parallel_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 parallel_r55 parallel_r56 parallel_l51_5 parallel_b55 parallel_v51_4 parallel_s55 parallel_sl51_4)
theorem parallel_pl51_3 (tail : List Nat) : parseItems 4072 26 (parallel_v51_3 ++ (93 :: tail)) = some (parallel_l51_3, tail) := by
  simpa only [parallel_l51_3, parallel_v51_3, parallel_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (parallel_b55 ++ (44 :: (parallel_v51_4 ++ (93 :: tail)))) (parallel_v51_4 ++ (93 :: tail)) tail parallel_r55 parallel_l51_4 (parallel_p55 (44 :: (parallel_v51_4 ++ (93 :: tail)))) (parallel_pl51_4 tail))
def parallel_l51_2 : List Raw := parallel_r54 :: parallel_l51_3
def parallel_v51_2 : List Nat := (parallel_b54) ++ (44 :: parallel_v51_3)
theorem parallel_sl51_2 : serializeItems 4073 26 parallel_l51_2 = some parallel_v51_2 := by
  simpa only [parallel_l51_2, parallel_v51_2, parallel_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 26 parallel_r54 parallel_r55 parallel_l51_4 parallel_b54 parallel_v51_3 parallel_s54 parallel_sl51_3)
theorem parallel_pl51_2 (tail : List Nat) : parseItems 4073 26 (parallel_v51_2 ++ (93 :: tail)) = some (parallel_l51_2, tail) := by
  simpa only [parallel_l51_2, parallel_v51_2, parallel_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 26 (parallel_b54 ++ (44 :: (parallel_v51_3 ++ (93 :: tail)))) (parallel_v51_3 ++ (93 :: tail)) tail parallel_r54 parallel_l51_3 (parallel_p54 (44 :: (parallel_v51_3 ++ (93 :: tail)))) (parallel_pl51_3 tail))
def parallel_l51_1 : List Raw := parallel_r53 :: parallel_l51_2
def parallel_v51_1 : List Nat := (parallel_b53) ++ (44 :: parallel_v51_2)
theorem parallel_sl51_1 : serializeItems 4074 26 parallel_l51_1 = some parallel_v51_1 := by
  simpa only [parallel_l51_1, parallel_v51_1, parallel_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 26 parallel_r53 parallel_r54 parallel_l51_3 parallel_b53 parallel_v51_2 parallel_s53 parallel_sl51_2)
theorem parallel_pl51_1 (tail : List Nat) : parseItems 4074 26 (parallel_v51_1 ++ (93 :: tail)) = some (parallel_l51_1, tail) := by
  simpa only [parallel_l51_1, parallel_v51_1, parallel_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 26 (parallel_b53 ++ (44 :: (parallel_v51_2 ++ (93 :: tail)))) (parallel_v51_2 ++ (93 :: tail)) tail parallel_r53 parallel_l51_2 (parallel_p53 (44 :: (parallel_v51_2 ++ (93 :: tail)))) (parallel_pl51_2 tail))
def parallel_l51_0 : List Raw := parallel_r52 :: parallel_l51_1
def parallel_v51_0 : List Nat := (parallel_b52) ++ (44 :: parallel_v51_1)
theorem parallel_sl51_0 : serializeItems 4075 26 parallel_l51_0 = some parallel_v51_0 := by
  simpa only [parallel_l51_0, parallel_v51_0, parallel_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 26 parallel_r52 parallel_r53 parallel_l51_2 parallel_b52 parallel_v51_1 parallel_s52 parallel_sl51_1)
theorem parallel_pl51_0 (tail : List Nat) : parseItems 4075 26 (parallel_v51_0 ++ (93 :: tail)) = some (parallel_l51_0, tail) := by
  simpa only [parallel_l51_0, parallel_v51_0, parallel_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 26 (parallel_b52 ++ (44 :: (parallel_v51_1 ++ (93 :: tail)))) (parallel_v51_1 ++ (93 :: tail)) tail parallel_r52 parallel_l51_1 (parallel_p52 (44 :: (parallel_v51_1 ++ (93 :: tail)))) (parallel_pl51_1 tail))
def parallel_r51 : Raw := (.arr parallel_l51_0)
def parallel_b51 : List Nat := parallel_g134 ++ (parallel_v51_0 ++ parallel_g156)
theorem parallel_s51 : serializeRaw 4076 27 parallel_r51 = some parallel_b51 := by
  simpa only [parallel_r51, parallel_b51, parallel_g134, parallel_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4075 26 parallel_l51_0 parallel_v51_0 parallel_sl51_0)
theorem parallel_p51 (tail : List Nat) : parseRaw 4076 27 (parallel_b51 ++ tail) = some (parallel_r51, tail) := by
  simpa only [parallel_r51, parallel_b51, parallel_g134, parallel_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4075 26 (parallel_v51_0 ++ (93 :: tail)) tail parallel_l51_0 (by intro h; cases h) (parallel_pl51_0 tail))
def parallel_r63 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b63 : List Nat := parallel_g159
theorem parallel_s63 : serializeRaw 4075 27 parallel_r63 = some parallel_b63 := by decide +kernel
theorem parallel_p63 (tail : List Nat) : parseRaw 4075 27 (parallel_b63 ++ tail) = some (parallel_r63, tail) := by rfl
def parallel_r64 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,55]),(.str [100,103,95,118,95,53,56]),(.str [100,103,95,118,95,53,57]),(.str [100,103,95,118,95,54,48]),(.str [100,103,95,118,95,55,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,48]))])
def parallel_b64 : List Nat := parallel_g162
theorem parallel_s64 : serializeRaw 4074 27 parallel_r64 = some parallel_b64 := by decide +kernel
theorem parallel_p64 (tail : List Nat) : parseRaw 4074 27 (parallel_b64 ++ tail) = some (parallel_r64, tail) := by rfl
def parallel_k49_0 : List Nat := [105,100]
theorem parallel_kd49_0 : stringBytes parallel_k49_0 = true := by decide +kernel
theorem parallel_kp49_0 (tail : List Nat) : parseStringTail (parallel_k49_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k49_0, 58 :: tail) := by rfl
def parallel_k49_1 : List Nat := [111,112,115]
theorem parallel_kd49_1 : stringBytes parallel_k49_1 = true := by decide +kernel
theorem parallel_kp49_1 (tail : List Nat) : parseStringTail (parallel_k49_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k49_1, 58 :: tail) := by rfl
def parallel_k49_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd49_2 : stringBytes parallel_k49_2 = true := by decide +kernel
theorem parallel_kp49_2 (tail : List Nat) : parseStringTail (parallel_k49_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k49_2, 58 :: tail) := by rfl
def parallel_k49_3 : List Nat := [116,101,114,109]
theorem parallel_kd49_3 : stringBytes parallel_k49_3 = true := by decide +kernel
theorem parallel_kp49_3 (tail : List Nat) : parseStringTail (parallel_k49_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k49_3, 58 :: tail) := by rfl
def parallel_l49_3 : List (List Nat × Raw) := [(parallel_k49_3, parallel_r64)]
def parallel_v49_3 : List Nat := parallel_g161 ++ parallel_b64
theorem parallel_sl49_3 : serializeFields 4075 27 parallel_l49_3 = some parallel_v49_3 := by
  simpa only [parallel_l49_3, parallel_v49_3, parallel_k49_3, parallel_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4074 27 parallel_k49_3 parallel_r64 parallel_b64 parallel_kd49_3 parallel_s64)
theorem parallel_pl49_3 (tail : List Nat) : parseFields 4075 27 (parallel_v49_3 ++ (125 :: tail)) = some (parallel_l49_3, tail) := by
  simpa only [parallel_l49_3, parallel_v49_3, parallel_k49_3, parallel_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4074 27 (parallel_k49_3 ++ (34 :: 58 :: (parallel_b64 ++ (125 :: tail)))) parallel_k49_3 (parallel_b64 ++ (125 :: tail)) tail parallel_r64 (parallel_kp49_3 (parallel_b64 ++ (125 :: tail))) (parallel_p64 (125 :: tail)))
def parallel_l49_2 : List (List Nat × Raw) := (parallel_k49_2, parallel_r63) :: parallel_l49_3
def parallel_v49_2 : List Nat := (parallel_g158 ++ parallel_b63) ++ (44 :: parallel_v49_3)
theorem parallel_sl49_2 : serializeFields 4076 27 parallel_l49_2 = some parallel_v49_2 := by
  simpa only [parallel_l49_2, parallel_v49_2, parallel_k49_2, parallel_g158, parallel_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 parallel_k49_2 parallel_r63 (parallel_k49_3, parallel_r64) [] parallel_b63 parallel_v49_3 parallel_kd49_2 parallel_s63 parallel_sl49_3)
theorem parallel_pl49_2 (tail : List Nat) : parseFields 4076 27 (parallel_v49_2 ++ (125 :: tail)) = some (parallel_l49_2, tail) := by
  simpa only [parallel_l49_2, parallel_v49_2, parallel_k49_2, parallel_g158, parallel_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (parallel_k49_2 ++ (34 :: 58 :: (parallel_b63 ++ (44 :: (parallel_v49_3 ++ (125 :: tail)))))) parallel_k49_2 (parallel_b63 ++ (44 :: (parallel_v49_3 ++ (125 :: tail)))) (parallel_v49_3 ++ (125 :: tail)) tail parallel_r63 parallel_l49_3 (parallel_kp49_2 (parallel_b63 ++ (44 :: (parallel_v49_3 ++ (125 :: tail))))) (parallel_p63 (44 :: (parallel_v49_3 ++ (125 :: tail)))) (parallel_pl49_3 tail))
def parallel_l49_1 : List (List Nat × Raw) := (parallel_k49_1, parallel_r51) :: parallel_l49_2
def parallel_v49_1 : List Nat := (parallel_g133 ++ parallel_b51) ++ (44 :: parallel_v49_2)
theorem parallel_sl49_1 : serializeFields 4077 27 parallel_l49_1 = some parallel_v49_1 := by
  simpa only [parallel_l49_1, parallel_v49_1, parallel_k49_1, parallel_g133, parallel_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 parallel_k49_1 parallel_r51 (parallel_k49_2, parallel_r63) parallel_l49_3 parallel_b51 parallel_v49_2 parallel_kd49_1 parallel_s51 parallel_sl49_2)
theorem parallel_pl49_1 (tail : List Nat) : parseFields 4077 27 (parallel_v49_1 ++ (125 :: tail)) = some (parallel_l49_1, tail) := by
  simpa only [parallel_l49_1, parallel_v49_1, parallel_k49_1, parallel_g133, parallel_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (parallel_k49_1 ++ (34 :: 58 :: (parallel_b51 ++ (44 :: (parallel_v49_2 ++ (125 :: tail)))))) parallel_k49_1 (parallel_b51 ++ (44 :: (parallel_v49_2 ++ (125 :: tail)))) (parallel_v49_2 ++ (125 :: tail)) tail parallel_r51 parallel_l49_2 (parallel_kp49_1 (parallel_b51 ++ (44 :: (parallel_v49_2 ++ (125 :: tail))))) (parallel_p51 (44 :: (parallel_v49_2 ++ (125 :: tail)))) (parallel_pl49_2 tail))
def parallel_l49_0 : List (List Nat × Raw) := (parallel_k49_0, parallel_r50) :: parallel_l49_1
def parallel_v49_0 : List Nat := (parallel_g130 ++ parallel_b50) ++ (44 :: parallel_v49_1)
theorem parallel_sl49_0 : serializeFields 4078 27 parallel_l49_0 = some parallel_v49_0 := by
  simpa only [parallel_l49_0, parallel_v49_0, parallel_k49_0, parallel_g130, parallel_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 parallel_k49_0 parallel_r50 (parallel_k49_1, parallel_r51) parallel_l49_2 parallel_b50 parallel_v49_1 parallel_kd49_0 parallel_s50 parallel_sl49_1)
theorem parallel_pl49_0 (tail : List Nat) : parseFields 4078 27 (parallel_v49_0 ++ (125 :: tail)) = some (parallel_l49_0, tail) := by
  simpa only [parallel_l49_0, parallel_v49_0, parallel_k49_0, parallel_g130, parallel_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (parallel_k49_0 ++ (34 :: 58 :: (parallel_b50 ++ (44 :: (parallel_v49_1 ++ (125 :: tail)))))) parallel_k49_0 (parallel_b50 ++ (44 :: (parallel_v49_1 ++ (125 :: tail)))) (parallel_v49_1 ++ (125 :: tail)) tail parallel_r50 parallel_l49_1 (parallel_kp49_0 (parallel_b50 ++ (44 :: (parallel_v49_1 ++ (125 :: tail))))) (parallel_p50 (44 :: (parallel_v49_1 ++ (125 :: tail)))) (parallel_pl49_1 tail))
def parallel_r49 : Raw := (.obj parallel_l49_0)
def parallel_b49 : List Nat := parallel_g129 ++ (parallel_v49_0 ++ parallel_g163)
theorem parallel_o49 : orderedFields parallel_l49_0 = true := by decide +kernel
theorem parallel_s49 : serializeRaw 4079 28 parallel_r49 = some parallel_b49 := by
  simpa only [parallel_r49, parallel_b49, parallel_g129, parallel_g163, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4078 27 parallel_l49_0 parallel_v49_0 parallel_o49 parallel_sl49_0)
theorem parallel_p49 (tail : List Nat) : parseRaw 4079 28 (parallel_b49 ++ tail) = some (parallel_r49, tail) := by
  simpa only [parallel_r49, parallel_b49, parallel_g129, parallel_g163, parallel_v49_0, parallel_k49_0, parallel_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4078 27 (parallel_k49_0 ++ (34 :: 58 :: (parallel_b50 ++ (44 :: (parallel_v49_1 ++ (125 :: tail)))))) tail parallel_l49_0 parallel_o49 (by simpa only [parallel_v49_0, parallel_k49_0, parallel_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl49_0 tail)))
def parallel_r66 : Raw := (.str [100,103,95,102,97,115,116,95,50])
def parallel_b66 : List Nat := parallel_g167
theorem parallel_s66 : serializeRaw 4076 27 parallel_r66 = some parallel_b66 := by decide +kernel
theorem parallel_p66 (tail : List Nat) : parseRaw 4076 27 (parallel_b66 ++ tail) = some (parallel_r66, tail) := by rfl
def parallel_r67 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,54])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,55])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def parallel_b67 : List Nat := parallel_g170
theorem parallel_s67 : serializeRaw 4075 27 parallel_r67 = some parallel_b67 := by decide +kernel
theorem parallel_p67 (tail : List Nat) : parseRaw 4075 27 (parallel_b67 ++ tail) = some (parallel_r67, tail) := by rfl
def parallel_r68 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b68 : List Nat := parallel_g173
theorem parallel_s68 : serializeRaw 4074 27 parallel_r68 = some parallel_b68 := by decide +kernel
theorem parallel_p68 (tail : List Nat) : parseRaw 4074 27 (parallel_b68 ++ tail) = some (parallel_r68, tail) := by rfl
def parallel_r69 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,50]),(.str [100,103,95,118,95,55,51]),(.str [100,103,95,118,95,55,54]),(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,55])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def parallel_b69 : List Nat := parallel_g176
theorem parallel_s69 : serializeRaw 4073 27 parallel_r69 = some parallel_b69 := by decide +kernel
theorem parallel_p69 (tail : List Nat) : parseRaw 4073 27 (parallel_b69 ++ tail) = some (parallel_r69, tail) := by rfl
def parallel_k65_0 : List Nat := [105,100]
theorem parallel_kd65_0 : stringBytes parallel_k65_0 = true := by decide +kernel
theorem parallel_kp65_0 (tail : List Nat) : parseStringTail (parallel_k65_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k65_0, 58 :: tail) := by rfl
def parallel_k65_1 : List Nat := [111,112,115]
theorem parallel_kd65_1 : stringBytes parallel_k65_1 = true := by decide +kernel
theorem parallel_kp65_1 (tail : List Nat) : parseStringTail (parallel_k65_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k65_1, 58 :: tail) := by rfl
def parallel_k65_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd65_2 : stringBytes parallel_k65_2 = true := by decide +kernel
theorem parallel_kp65_2 (tail : List Nat) : parseStringTail (parallel_k65_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k65_2, 58 :: tail) := by rfl
def parallel_k65_3 : List Nat := [116,101,114,109]
theorem parallel_kd65_3 : stringBytes parallel_k65_3 = true := by decide +kernel
theorem parallel_kp65_3 (tail : List Nat) : parseStringTail (parallel_k65_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k65_3, 58 :: tail) := by rfl
def parallel_l65_3 : List (List Nat × Raw) := [(parallel_k65_3, parallel_r69)]
def parallel_v65_3 : List Nat := parallel_g175 ++ parallel_b69
theorem parallel_sl65_3 : serializeFields 4074 27 parallel_l65_3 = some parallel_v65_3 := by
  simpa only [parallel_l65_3, parallel_v65_3, parallel_k65_3, parallel_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4073 27 parallel_k65_3 parallel_r69 parallel_b69 parallel_kd65_3 parallel_s69)
theorem parallel_pl65_3 (tail : List Nat) : parseFields 4074 27 (parallel_v65_3 ++ (125 :: tail)) = some (parallel_l65_3, tail) := by
  simpa only [parallel_l65_3, parallel_v65_3, parallel_k65_3, parallel_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4073 27 (parallel_k65_3 ++ (34 :: 58 :: (parallel_b69 ++ (125 :: tail)))) parallel_k65_3 (parallel_b69 ++ (125 :: tail)) tail parallel_r69 (parallel_kp65_3 (parallel_b69 ++ (125 :: tail))) (parallel_p69 (125 :: tail)))
def parallel_l65_2 : List (List Nat × Raw) := (parallel_k65_2, parallel_r68) :: parallel_l65_3
def parallel_v65_2 : List Nat := (parallel_g172 ++ parallel_b68) ++ (44 :: parallel_v65_3)
theorem parallel_sl65_2 : serializeFields 4075 27 parallel_l65_2 = some parallel_v65_2 := by
  simpa only [parallel_l65_2, parallel_v65_2, parallel_k65_2, parallel_g172, parallel_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 parallel_k65_2 parallel_r68 (parallel_k65_3, parallel_r69) [] parallel_b68 parallel_v65_3 parallel_kd65_2 parallel_s68 parallel_sl65_3)
theorem parallel_pl65_2 (tail : List Nat) : parseFields 4075 27 (parallel_v65_2 ++ (125 :: tail)) = some (parallel_l65_2, tail) := by
  simpa only [parallel_l65_2, parallel_v65_2, parallel_k65_2, parallel_g172, parallel_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (parallel_k65_2 ++ (34 :: 58 :: (parallel_b68 ++ (44 :: (parallel_v65_3 ++ (125 :: tail)))))) parallel_k65_2 (parallel_b68 ++ (44 :: (parallel_v65_3 ++ (125 :: tail)))) (parallel_v65_3 ++ (125 :: tail)) tail parallel_r68 parallel_l65_3 (parallel_kp65_2 (parallel_b68 ++ (44 :: (parallel_v65_3 ++ (125 :: tail))))) (parallel_p68 (44 :: (parallel_v65_3 ++ (125 :: tail)))) (parallel_pl65_3 tail))
def parallel_l65_1 : List (List Nat × Raw) := (parallel_k65_1, parallel_r67) :: parallel_l65_2
def parallel_v65_1 : List Nat := (parallel_g169 ++ parallel_b67) ++ (44 :: parallel_v65_2)
theorem parallel_sl65_1 : serializeFields 4076 27 parallel_l65_1 = some parallel_v65_1 := by
  simpa only [parallel_l65_1, parallel_v65_1, parallel_k65_1, parallel_g169, parallel_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 parallel_k65_1 parallel_r67 (parallel_k65_2, parallel_r68) parallel_l65_3 parallel_b67 parallel_v65_2 parallel_kd65_1 parallel_s67 parallel_sl65_2)
theorem parallel_pl65_1 (tail : List Nat) : parseFields 4076 27 (parallel_v65_1 ++ (125 :: tail)) = some (parallel_l65_1, tail) := by
  simpa only [parallel_l65_1, parallel_v65_1, parallel_k65_1, parallel_g169, parallel_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (parallel_k65_1 ++ (34 :: 58 :: (parallel_b67 ++ (44 :: (parallel_v65_2 ++ (125 :: tail)))))) parallel_k65_1 (parallel_b67 ++ (44 :: (parallel_v65_2 ++ (125 :: tail)))) (parallel_v65_2 ++ (125 :: tail)) tail parallel_r67 parallel_l65_2 (parallel_kp65_1 (parallel_b67 ++ (44 :: (parallel_v65_2 ++ (125 :: tail))))) (parallel_p67 (44 :: (parallel_v65_2 ++ (125 :: tail)))) (parallel_pl65_2 tail))
def parallel_l65_0 : List (List Nat × Raw) := (parallel_k65_0, parallel_r66) :: parallel_l65_1
def parallel_v65_0 : List Nat := (parallel_g166 ++ parallel_b66) ++ (44 :: parallel_v65_1)
theorem parallel_sl65_0 : serializeFields 4077 27 parallel_l65_0 = some parallel_v65_0 := by
  simpa only [parallel_l65_0, parallel_v65_0, parallel_k65_0, parallel_g166, parallel_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 parallel_k65_0 parallel_r66 (parallel_k65_1, parallel_r67) parallel_l65_2 parallel_b66 parallel_v65_1 parallel_kd65_0 parallel_s66 parallel_sl65_1)
theorem parallel_pl65_0 (tail : List Nat) : parseFields 4077 27 (parallel_v65_0 ++ (125 :: tail)) = some (parallel_l65_0, tail) := by
  simpa only [parallel_l65_0, parallel_v65_0, parallel_k65_0, parallel_g166, parallel_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (parallel_k65_0 ++ (34 :: 58 :: (parallel_b66 ++ (44 :: (parallel_v65_1 ++ (125 :: tail)))))) parallel_k65_0 (parallel_b66 ++ (44 :: (parallel_v65_1 ++ (125 :: tail)))) (parallel_v65_1 ++ (125 :: tail)) tail parallel_r66 parallel_l65_1 (parallel_kp65_0 (parallel_b66 ++ (44 :: (parallel_v65_1 ++ (125 :: tail))))) (parallel_p66 (44 :: (parallel_v65_1 ++ (125 :: tail)))) (parallel_pl65_1 tail))
def parallel_r65 : Raw := (.obj parallel_l65_0)
def parallel_b65 : List Nat := parallel_g165 ++ (parallel_v65_0 ++ parallel_g177)
theorem parallel_o65 : orderedFields parallel_l65_0 = true := by decide +kernel
theorem parallel_s65 : serializeRaw 4078 28 parallel_r65 = some parallel_b65 := by
  simpa only [parallel_r65, parallel_b65, parallel_g165, parallel_g177, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4077 27 parallel_l65_0 parallel_v65_0 parallel_o65 parallel_sl65_0)
theorem parallel_p65 (tail : List Nat) : parseRaw 4078 28 (parallel_b65 ++ tail) = some (parallel_r65, tail) := by
  simpa only [parallel_r65, parallel_b65, parallel_g165, parallel_g177, parallel_v65_0, parallel_k65_0, parallel_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4077 27 (parallel_k65_0 ++ (34 :: 58 :: (parallel_b66 ++ (44 :: (parallel_v65_1 ++ (125 :: tail)))))) tail parallel_l65_0 parallel_o65 (by simpa only [parallel_v65_0, parallel_k65_0, parallel_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl65_0 tail)))
def parallel_r71 : Raw := (.str [100,103,95,102,97,115,116,95,51])
def parallel_b71 : List Nat := parallel_g181
theorem parallel_s71 : serializeRaw 4075 27 parallel_r71 = some parallel_b71 := by decide +kernel
theorem parallel_p71 (tail : List Nat) : parseRaw 4075 27 (parallel_b71 ++ tail) = some (parallel_r71, tail) := by rfl
def parallel_r72 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,51]),(.str [100,103,95,118,95,56,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b72 : List Nat := parallel_g184
theorem parallel_s72 : serializeRaw 4074 27 parallel_r72 = some parallel_b72 := by decide +kernel
theorem parallel_p72 (tail : List Nat) : parseRaw 4074 27 (parallel_b72 ++ tail) = some (parallel_r72, tail) := by rfl
def parallel_r73 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b73 : List Nat := parallel_g187
theorem parallel_s73 : serializeRaw 4073 27 parallel_r73 = some parallel_b73 := by decide +kernel
theorem parallel_p73 (tail : List Nat) : parseRaw 4073 27 (parallel_b73 ++ tail) = some (parallel_r73, tail) := by rfl
def parallel_r74 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,56,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def parallel_b74 : List Nat := parallel_g190
theorem parallel_s74 : serializeRaw 4072 27 parallel_r74 = some parallel_b74 := by decide +kernel
theorem parallel_p74 (tail : List Nat) : parseRaw 4072 27 (parallel_b74 ++ tail) = some (parallel_r74, tail) := by rfl
def parallel_k70_0 : List Nat := [105,100]
theorem parallel_kd70_0 : stringBytes parallel_k70_0 = true := by decide +kernel
theorem parallel_kp70_0 (tail : List Nat) : parseStringTail (parallel_k70_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k70_0, 58 :: tail) := by rfl
def parallel_k70_1 : List Nat := [111,112,115]
theorem parallel_kd70_1 : stringBytes parallel_k70_1 = true := by decide +kernel
theorem parallel_kp70_1 (tail : List Nat) : parseStringTail (parallel_k70_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k70_1, 58 :: tail) := by rfl
def parallel_k70_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd70_2 : stringBytes parallel_k70_2 = true := by decide +kernel
theorem parallel_kp70_2 (tail : List Nat) : parseStringTail (parallel_k70_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k70_2, 58 :: tail) := by rfl
def parallel_k70_3 : List Nat := [116,101,114,109]
theorem parallel_kd70_3 : stringBytes parallel_k70_3 = true := by decide +kernel
theorem parallel_kp70_3 (tail : List Nat) : parseStringTail (parallel_k70_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k70_3, 58 :: tail) := by rfl
def parallel_l70_3 : List (List Nat × Raw) := [(parallel_k70_3, parallel_r74)]
def parallel_v70_3 : List Nat := parallel_g189 ++ parallel_b74
theorem parallel_sl70_3 : serializeFields 4073 27 parallel_l70_3 = some parallel_v70_3 := by
  simpa only [parallel_l70_3, parallel_v70_3, parallel_k70_3, parallel_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4072 27 parallel_k70_3 parallel_r74 parallel_b74 parallel_kd70_3 parallel_s74)
theorem parallel_pl70_3 (tail : List Nat) : parseFields 4073 27 (parallel_v70_3 ++ (125 :: tail)) = some (parallel_l70_3, tail) := by
  simpa only [parallel_l70_3, parallel_v70_3, parallel_k70_3, parallel_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4072 27 (parallel_k70_3 ++ (34 :: 58 :: (parallel_b74 ++ (125 :: tail)))) parallel_k70_3 (parallel_b74 ++ (125 :: tail)) tail parallel_r74 (parallel_kp70_3 (parallel_b74 ++ (125 :: tail))) (parallel_p74 (125 :: tail)))
def parallel_l70_2 : List (List Nat × Raw) := (parallel_k70_2, parallel_r73) :: parallel_l70_3
def parallel_v70_2 : List Nat := (parallel_g186 ++ parallel_b73) ++ (44 :: parallel_v70_3)
theorem parallel_sl70_2 : serializeFields 4074 27 parallel_l70_2 = some parallel_v70_2 := by
  simpa only [parallel_l70_2, parallel_v70_2, parallel_k70_2, parallel_g186, parallel_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 parallel_k70_2 parallel_r73 (parallel_k70_3, parallel_r74) [] parallel_b73 parallel_v70_3 parallel_kd70_2 parallel_s73 parallel_sl70_3)
theorem parallel_pl70_2 (tail : List Nat) : parseFields 4074 27 (parallel_v70_2 ++ (125 :: tail)) = some (parallel_l70_2, tail) := by
  simpa only [parallel_l70_2, parallel_v70_2, parallel_k70_2, parallel_g186, parallel_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (parallel_k70_2 ++ (34 :: 58 :: (parallel_b73 ++ (44 :: (parallel_v70_3 ++ (125 :: tail)))))) parallel_k70_2 (parallel_b73 ++ (44 :: (parallel_v70_3 ++ (125 :: tail)))) (parallel_v70_3 ++ (125 :: tail)) tail parallel_r73 parallel_l70_3 (parallel_kp70_2 (parallel_b73 ++ (44 :: (parallel_v70_3 ++ (125 :: tail))))) (parallel_p73 (44 :: (parallel_v70_3 ++ (125 :: tail)))) (parallel_pl70_3 tail))
def parallel_l70_1 : List (List Nat × Raw) := (parallel_k70_1, parallel_r72) :: parallel_l70_2
def parallel_v70_1 : List Nat := (parallel_g183 ++ parallel_b72) ++ (44 :: parallel_v70_2)
theorem parallel_sl70_1 : serializeFields 4075 27 parallel_l70_1 = some parallel_v70_1 := by
  simpa only [parallel_l70_1, parallel_v70_1, parallel_k70_1, parallel_g183, parallel_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 parallel_k70_1 parallel_r72 (parallel_k70_2, parallel_r73) parallel_l70_3 parallel_b72 parallel_v70_2 parallel_kd70_1 parallel_s72 parallel_sl70_2)
theorem parallel_pl70_1 (tail : List Nat) : parseFields 4075 27 (parallel_v70_1 ++ (125 :: tail)) = some (parallel_l70_1, tail) := by
  simpa only [parallel_l70_1, parallel_v70_1, parallel_k70_1, parallel_g183, parallel_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (parallel_k70_1 ++ (34 :: 58 :: (parallel_b72 ++ (44 :: (parallel_v70_2 ++ (125 :: tail)))))) parallel_k70_1 (parallel_b72 ++ (44 :: (parallel_v70_2 ++ (125 :: tail)))) (parallel_v70_2 ++ (125 :: tail)) tail parallel_r72 parallel_l70_2 (parallel_kp70_1 (parallel_b72 ++ (44 :: (parallel_v70_2 ++ (125 :: tail))))) (parallel_p72 (44 :: (parallel_v70_2 ++ (125 :: tail)))) (parallel_pl70_2 tail))
def parallel_l70_0 : List (List Nat × Raw) := (parallel_k70_0, parallel_r71) :: parallel_l70_1
def parallel_v70_0 : List Nat := (parallel_g180 ++ parallel_b71) ++ (44 :: parallel_v70_1)
theorem parallel_sl70_0 : serializeFields 4076 27 parallel_l70_0 = some parallel_v70_0 := by
  simpa only [parallel_l70_0, parallel_v70_0, parallel_k70_0, parallel_g180, parallel_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 parallel_k70_0 parallel_r71 (parallel_k70_1, parallel_r72) parallel_l70_2 parallel_b71 parallel_v70_1 parallel_kd70_0 parallel_s71 parallel_sl70_1)
theorem parallel_pl70_0 (tail : List Nat) : parseFields 4076 27 (parallel_v70_0 ++ (125 :: tail)) = some (parallel_l70_0, tail) := by
  simpa only [parallel_l70_0, parallel_v70_0, parallel_k70_0, parallel_g180, parallel_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (parallel_k70_0 ++ (34 :: 58 :: (parallel_b71 ++ (44 :: (parallel_v70_1 ++ (125 :: tail)))))) parallel_k70_0 (parallel_b71 ++ (44 :: (parallel_v70_1 ++ (125 :: tail)))) (parallel_v70_1 ++ (125 :: tail)) tail parallel_r71 parallel_l70_1 (parallel_kp70_0 (parallel_b71 ++ (44 :: (parallel_v70_1 ++ (125 :: tail))))) (parallel_p71 (44 :: (parallel_v70_1 ++ (125 :: tail)))) (parallel_pl70_1 tail))
def parallel_r70 : Raw := (.obj parallel_l70_0)
def parallel_b70 : List Nat := parallel_g179 ++ (parallel_v70_0 ++ parallel_g191)
theorem parallel_o70 : orderedFields parallel_l70_0 = true := by decide +kernel
theorem parallel_s70 : serializeRaw 4077 28 parallel_r70 = some parallel_b70 := by
  simpa only [parallel_r70, parallel_b70, parallel_g179, parallel_g191, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4076 27 parallel_l70_0 parallel_v70_0 parallel_o70 parallel_sl70_0)
theorem parallel_p70 (tail : List Nat) : parseRaw 4077 28 (parallel_b70 ++ tail) = some (parallel_r70, tail) := by
  simpa only [parallel_r70, parallel_b70, parallel_g179, parallel_g191, parallel_v70_0, parallel_k70_0, parallel_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4076 27 (parallel_k70_0 ++ (34 :: 58 :: (parallel_b71 ++ (44 :: (parallel_v70_1 ++ (125 :: tail)))))) tail parallel_l70_0 parallel_o70 (by simpa only [parallel_v70_0, parallel_k70_0, parallel_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl70_0 tail)))
def parallel_r76 : Raw := (.str [100,103,95,102,97,115,116,95,52])
def parallel_b76 : List Nat := parallel_g195
theorem parallel_s76 : serializeRaw 4074 27 parallel_r76 = some parallel_b76 := by decide +kernel
theorem parallel_p76 (tail : List Nat) : parseRaw 4074 27 (parallel_b76 ++ tail) = some (parallel_r76, tail) := by rfl
def parallel_r78 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,49])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def parallel_b78 : List Nat := parallel_g199
theorem parallel_s78 : serializeRaw 4071 26 parallel_r78 = some parallel_b78 := by decide +kernel
theorem parallel_p78 (tail : List Nat) : parseRaw 4071 26 (parallel_b78 ++ tail) = some (parallel_r78, tail) := by rfl
def parallel_r79 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49]),(.str [100,103,95,118,95,57,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,50])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b79 : List Nat := parallel_g201
theorem parallel_s79 : serializeRaw 4070 26 parallel_r79 = some parallel_b79 := by decide +kernel
theorem parallel_p79 (tail : List Nat) : parseRaw 4070 26 (parallel_b79 ++ tail) = some (parallel_r79, tail) := by rfl
def parallel_r80 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def parallel_b80 : List Nat := parallel_g203
theorem parallel_s80 : serializeRaw 4069 26 parallel_r80 = some parallel_b80 := by decide +kernel
theorem parallel_p80 (tail : List Nat) : parseRaw 4069 26 (parallel_b80 ++ tail) = some (parallel_r80, tail) := by rfl
def parallel_r81 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,50])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,51])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b81 : List Nat := parallel_g205
theorem parallel_s81 : serializeRaw 4068 26 parallel_r81 = some parallel_b81 := by decide +kernel
theorem parallel_p81 (tail : List Nat) : parseRaw 4068 26 (parallel_b81 ++ tail) = some (parallel_r81, tail) := by rfl
def parallel_r82 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,56]),(.str [100,103,95,118,95,57,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,52])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b82 : List Nat := parallel_g207
theorem parallel_s82 : serializeRaw 4067 26 parallel_r82 = some parallel_b82 := by decide +kernel
theorem parallel_p82 (tail : List Nat) : parseRaw 4067 26 (parallel_b82 ++ tail) = some (parallel_r82, tail) := by rfl
def parallel_r83 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,53])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b83 : List Nat := parallel_g209
theorem parallel_s83 : serializeRaw 4066 26 parallel_r83 = some parallel_b83 := by decide +kernel
theorem parallel_p83 (tail : List Nat) : parseRaw 4066 26 (parallel_b83 ++ tail) = some (parallel_r83, tail) := by rfl
def parallel_r84 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,48]),(.str [100,103,95,118,95,57,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,54])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b84 : List Nat := parallel_g211
theorem parallel_s84 : serializeRaw 4065 26 parallel_r84 = some parallel_b84 := by decide +kernel
theorem parallel_p84 (tail : List Nat) : parseRaw 4065 26 (parallel_b84 ++ tail) = some (parallel_r84, tail) := by rfl
def parallel_l77_6 : List Raw := [parallel_r84]
def parallel_v77_6 : List Nat := parallel_b84
theorem parallel_sl77_6 : serializeItems 4066 26 parallel_l77_6 = some parallel_v77_6 := by
  simpa only [parallel_l77_6, parallel_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4065 26 parallel_r84 parallel_b84 parallel_s84)
theorem parallel_pl77_6 (tail : List Nat) : parseItems 4066 26 (parallel_v77_6 ++ (93 :: tail)) = some (parallel_l77_6, tail) := by
  simpa only [parallel_l77_6, parallel_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4065 26 (parallel_b84 ++ (93 :: tail)) tail parallel_r84 (parallel_p84 (93 :: tail)))
def parallel_l77_5 : List Raw := parallel_r83 :: parallel_l77_6
def parallel_v77_5 : List Nat := (parallel_b83) ++ (44 :: parallel_v77_6)
theorem parallel_sl77_5 : serializeItems 4067 26 parallel_l77_5 = some parallel_v77_5 := by
  simpa only [parallel_l77_5, parallel_v77_5, parallel_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 parallel_r83 parallel_r84 [] parallel_b83 parallel_v77_6 parallel_s83 parallel_sl77_6)
theorem parallel_pl77_5 (tail : List Nat) : parseItems 4067 26 (parallel_v77_5 ++ (93 :: tail)) = some (parallel_l77_5, tail) := by
  simpa only [parallel_l77_5, parallel_v77_5, parallel_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (parallel_b83 ++ (44 :: (parallel_v77_6 ++ (93 :: tail)))) (parallel_v77_6 ++ (93 :: tail)) tail parallel_r83 parallel_l77_6 (parallel_p83 (44 :: (parallel_v77_6 ++ (93 :: tail)))) (parallel_pl77_6 tail))
def parallel_l77_4 : List Raw := parallel_r82 :: parallel_l77_5
def parallel_v77_4 : List Nat := (parallel_b82) ++ (44 :: parallel_v77_5)
theorem parallel_sl77_4 : serializeItems 4068 26 parallel_l77_4 = some parallel_v77_4 := by
  simpa only [parallel_l77_4, parallel_v77_4, parallel_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 parallel_r82 parallel_r83 parallel_l77_6 parallel_b82 parallel_v77_5 parallel_s82 parallel_sl77_5)
theorem parallel_pl77_4 (tail : List Nat) : parseItems 4068 26 (parallel_v77_4 ++ (93 :: tail)) = some (parallel_l77_4, tail) := by
  simpa only [parallel_l77_4, parallel_v77_4, parallel_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (parallel_b82 ++ (44 :: (parallel_v77_5 ++ (93 :: tail)))) (parallel_v77_5 ++ (93 :: tail)) tail parallel_r82 parallel_l77_5 (parallel_p82 (44 :: (parallel_v77_5 ++ (93 :: tail)))) (parallel_pl77_5 tail))
def parallel_l77_3 : List Raw := parallel_r81 :: parallel_l77_4
def parallel_v77_3 : List Nat := (parallel_b81) ++ (44 :: parallel_v77_4)
theorem parallel_sl77_3 : serializeItems 4069 26 parallel_l77_3 = some parallel_v77_3 := by
  simpa only [parallel_l77_3, parallel_v77_3, parallel_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 parallel_r81 parallel_r82 parallel_l77_5 parallel_b81 parallel_v77_4 parallel_s81 parallel_sl77_4)
theorem parallel_pl77_3 (tail : List Nat) : parseItems 4069 26 (parallel_v77_3 ++ (93 :: tail)) = some (parallel_l77_3, tail) := by
  simpa only [parallel_l77_3, parallel_v77_3, parallel_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (parallel_b81 ++ (44 :: (parallel_v77_4 ++ (93 :: tail)))) (parallel_v77_4 ++ (93 :: tail)) tail parallel_r81 parallel_l77_4 (parallel_p81 (44 :: (parallel_v77_4 ++ (93 :: tail)))) (parallel_pl77_4 tail))
def parallel_l77_2 : List Raw := parallel_r80 :: parallel_l77_3
def parallel_v77_2 : List Nat := (parallel_b80) ++ (44 :: parallel_v77_3)
theorem parallel_sl77_2 : serializeItems 4070 26 parallel_l77_2 = some parallel_v77_2 := by
  simpa only [parallel_l77_2, parallel_v77_2, parallel_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 parallel_r80 parallel_r81 parallel_l77_4 parallel_b80 parallel_v77_3 parallel_s80 parallel_sl77_3)
theorem parallel_pl77_2 (tail : List Nat) : parseItems 4070 26 (parallel_v77_2 ++ (93 :: tail)) = some (parallel_l77_2, tail) := by
  simpa only [parallel_l77_2, parallel_v77_2, parallel_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (parallel_b80 ++ (44 :: (parallel_v77_3 ++ (93 :: tail)))) (parallel_v77_3 ++ (93 :: tail)) tail parallel_r80 parallel_l77_3 (parallel_p80 (44 :: (parallel_v77_3 ++ (93 :: tail)))) (parallel_pl77_3 tail))
def parallel_l77_1 : List Raw := parallel_r79 :: parallel_l77_2
def parallel_v77_1 : List Nat := (parallel_b79) ++ (44 :: parallel_v77_2)
theorem parallel_sl77_1 : serializeItems 4071 26 parallel_l77_1 = some parallel_v77_1 := by
  simpa only [parallel_l77_1, parallel_v77_1, parallel_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 parallel_r79 parallel_r80 parallel_l77_3 parallel_b79 parallel_v77_2 parallel_s79 parallel_sl77_2)
theorem parallel_pl77_1 (tail : List Nat) : parseItems 4071 26 (parallel_v77_1 ++ (93 :: tail)) = some (parallel_l77_1, tail) := by
  simpa only [parallel_l77_1, parallel_v77_1, parallel_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (parallel_b79 ++ (44 :: (parallel_v77_2 ++ (93 :: tail)))) (parallel_v77_2 ++ (93 :: tail)) tail parallel_r79 parallel_l77_2 (parallel_p79 (44 :: (parallel_v77_2 ++ (93 :: tail)))) (parallel_pl77_2 tail))
def parallel_l77_0 : List Raw := parallel_r78 :: parallel_l77_1
def parallel_v77_0 : List Nat := (parallel_b78) ++ (44 :: parallel_v77_1)
theorem parallel_sl77_0 : serializeItems 4072 26 parallel_l77_0 = some parallel_v77_0 := by
  simpa only [parallel_l77_0, parallel_v77_0, parallel_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 parallel_r78 parallel_r79 parallel_l77_2 parallel_b78 parallel_v77_1 parallel_s78 parallel_sl77_1)
theorem parallel_pl77_0 (tail : List Nat) : parseItems 4072 26 (parallel_v77_0 ++ (93 :: tail)) = some (parallel_l77_0, tail) := by
  simpa only [parallel_l77_0, parallel_v77_0, parallel_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (parallel_b78 ++ (44 :: (parallel_v77_1 ++ (93 :: tail)))) (parallel_v77_1 ++ (93 :: tail)) tail parallel_r78 parallel_l77_1 (parallel_p78 (44 :: (parallel_v77_1 ++ (93 :: tail)))) (parallel_pl77_1 tail))
def parallel_r77 : Raw := (.arr parallel_l77_0)
def parallel_b77 : List Nat := parallel_g198 ++ (parallel_v77_0 ++ parallel_g212)
theorem parallel_s77 : serializeRaw 4073 27 parallel_r77 = some parallel_b77 := by
  simpa only [parallel_r77, parallel_b77, parallel_g198, parallel_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4072 26 parallel_l77_0 parallel_v77_0 parallel_sl77_0)
theorem parallel_p77 (tail : List Nat) : parseRaw 4073 27 (parallel_b77 ++ tail) = some (parallel_r77, tail) := by
  simpa only [parallel_r77, parallel_b77, parallel_g198, parallel_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4072 26 (parallel_v77_0 ++ (93 :: tail)) tail parallel_l77_0 (by intro h; cases h) (parallel_pl77_0 tail))
def parallel_r85 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b85 : List Nat := parallel_g215
theorem parallel_s85 : serializeRaw 4072 27 parallel_r85 = some parallel_b85 := by decide +kernel
theorem parallel_p85 (tail : List Nat) : parseRaw 4072 27 (parallel_b85 ++ tail) = some (parallel_r85, tail) := by rfl
def parallel_r86 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,53]),(.str [100,103,95,118,95,56,54]),(.str [100,103,95,118,95,56,55]),(.str [100,103,95,118,95,57,52]),(.str [100,103,95,118,95,56,57]),(.str [100,103,95,118,95,57,54])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def parallel_b86 : List Nat := parallel_g218
theorem parallel_s86 : serializeRaw 4071 27 parallel_r86 = some parallel_b86 := by decide +kernel
theorem parallel_p86 (tail : List Nat) : parseRaw 4071 27 (parallel_b86 ++ tail) = some (parallel_r86, tail) := by rfl
def parallel_k75_0 : List Nat := [105,100]
theorem parallel_kd75_0 : stringBytes parallel_k75_0 = true := by decide +kernel
theorem parallel_kp75_0 (tail : List Nat) : parseStringTail (parallel_k75_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k75_0, 58 :: tail) := by rfl
def parallel_k75_1 : List Nat := [111,112,115]
theorem parallel_kd75_1 : stringBytes parallel_k75_1 = true := by decide +kernel
theorem parallel_kp75_1 (tail : List Nat) : parseStringTail (parallel_k75_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k75_1, 58 :: tail) := by rfl
def parallel_k75_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd75_2 : stringBytes parallel_k75_2 = true := by decide +kernel
theorem parallel_kp75_2 (tail : List Nat) : parseStringTail (parallel_k75_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k75_2, 58 :: tail) := by rfl
def parallel_k75_3 : List Nat := [116,101,114,109]
theorem parallel_kd75_3 : stringBytes parallel_k75_3 = true := by decide +kernel
theorem parallel_kp75_3 (tail : List Nat) : parseStringTail (parallel_k75_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k75_3, 58 :: tail) := by rfl
def parallel_l75_3 : List (List Nat × Raw) := [(parallel_k75_3, parallel_r86)]
def parallel_v75_3 : List Nat := parallel_g217 ++ parallel_b86
theorem parallel_sl75_3 : serializeFields 4072 27 parallel_l75_3 = some parallel_v75_3 := by
  simpa only [parallel_l75_3, parallel_v75_3, parallel_k75_3, parallel_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4071 27 parallel_k75_3 parallel_r86 parallel_b86 parallel_kd75_3 parallel_s86)
theorem parallel_pl75_3 (tail : List Nat) : parseFields 4072 27 (parallel_v75_3 ++ (125 :: tail)) = some (parallel_l75_3, tail) := by
  simpa only [parallel_l75_3, parallel_v75_3, parallel_k75_3, parallel_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4071 27 (parallel_k75_3 ++ (34 :: 58 :: (parallel_b86 ++ (125 :: tail)))) parallel_k75_3 (parallel_b86 ++ (125 :: tail)) tail parallel_r86 (parallel_kp75_3 (parallel_b86 ++ (125 :: tail))) (parallel_p86 (125 :: tail)))
def parallel_l75_2 : List (List Nat × Raw) := (parallel_k75_2, parallel_r85) :: parallel_l75_3
def parallel_v75_2 : List Nat := (parallel_g214 ++ parallel_b85) ++ (44 :: parallel_v75_3)
theorem parallel_sl75_2 : serializeFields 4073 27 parallel_l75_2 = some parallel_v75_2 := by
  simpa only [parallel_l75_2, parallel_v75_2, parallel_k75_2, parallel_g214, parallel_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 parallel_k75_2 parallel_r85 (parallel_k75_3, parallel_r86) [] parallel_b85 parallel_v75_3 parallel_kd75_2 parallel_s85 parallel_sl75_3)
theorem parallel_pl75_2 (tail : List Nat) : parseFields 4073 27 (parallel_v75_2 ++ (125 :: tail)) = some (parallel_l75_2, tail) := by
  simpa only [parallel_l75_2, parallel_v75_2, parallel_k75_2, parallel_g214, parallel_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (parallel_k75_2 ++ (34 :: 58 :: (parallel_b85 ++ (44 :: (parallel_v75_3 ++ (125 :: tail)))))) parallel_k75_2 (parallel_b85 ++ (44 :: (parallel_v75_3 ++ (125 :: tail)))) (parallel_v75_3 ++ (125 :: tail)) tail parallel_r85 parallel_l75_3 (parallel_kp75_2 (parallel_b85 ++ (44 :: (parallel_v75_3 ++ (125 :: tail))))) (parallel_p85 (44 :: (parallel_v75_3 ++ (125 :: tail)))) (parallel_pl75_3 tail))
def parallel_l75_1 : List (List Nat × Raw) := (parallel_k75_1, parallel_r77) :: parallel_l75_2
def parallel_v75_1 : List Nat := (parallel_g197 ++ parallel_b77) ++ (44 :: parallel_v75_2)
theorem parallel_sl75_1 : serializeFields 4074 27 parallel_l75_1 = some parallel_v75_1 := by
  simpa only [parallel_l75_1, parallel_v75_1, parallel_k75_1, parallel_g197, parallel_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 parallel_k75_1 parallel_r77 (parallel_k75_2, parallel_r85) parallel_l75_3 parallel_b77 parallel_v75_2 parallel_kd75_1 parallel_s77 parallel_sl75_2)
theorem parallel_pl75_1 (tail : List Nat) : parseFields 4074 27 (parallel_v75_1 ++ (125 :: tail)) = some (parallel_l75_1, tail) := by
  simpa only [parallel_l75_1, parallel_v75_1, parallel_k75_1, parallel_g197, parallel_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (parallel_k75_1 ++ (34 :: 58 :: (parallel_b77 ++ (44 :: (parallel_v75_2 ++ (125 :: tail)))))) parallel_k75_1 (parallel_b77 ++ (44 :: (parallel_v75_2 ++ (125 :: tail)))) (parallel_v75_2 ++ (125 :: tail)) tail parallel_r77 parallel_l75_2 (parallel_kp75_1 (parallel_b77 ++ (44 :: (parallel_v75_2 ++ (125 :: tail))))) (parallel_p77 (44 :: (parallel_v75_2 ++ (125 :: tail)))) (parallel_pl75_2 tail))
def parallel_l75_0 : List (List Nat × Raw) := (parallel_k75_0, parallel_r76) :: parallel_l75_1
def parallel_v75_0 : List Nat := (parallel_g194 ++ parallel_b76) ++ (44 :: parallel_v75_1)
theorem parallel_sl75_0 : serializeFields 4075 27 parallel_l75_0 = some parallel_v75_0 := by
  simpa only [parallel_l75_0, parallel_v75_0, parallel_k75_0, parallel_g194, parallel_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 parallel_k75_0 parallel_r76 (parallel_k75_1, parallel_r77) parallel_l75_2 parallel_b76 parallel_v75_1 parallel_kd75_0 parallel_s76 parallel_sl75_1)
theorem parallel_pl75_0 (tail : List Nat) : parseFields 4075 27 (parallel_v75_0 ++ (125 :: tail)) = some (parallel_l75_0, tail) := by
  simpa only [parallel_l75_0, parallel_v75_0, parallel_k75_0, parallel_g194, parallel_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (parallel_k75_0 ++ (34 :: 58 :: (parallel_b76 ++ (44 :: (parallel_v75_1 ++ (125 :: tail)))))) parallel_k75_0 (parallel_b76 ++ (44 :: (parallel_v75_1 ++ (125 :: tail)))) (parallel_v75_1 ++ (125 :: tail)) tail parallel_r76 parallel_l75_1 (parallel_kp75_0 (parallel_b76 ++ (44 :: (parallel_v75_1 ++ (125 :: tail))))) (parallel_p76 (44 :: (parallel_v75_1 ++ (125 :: tail)))) (parallel_pl75_1 tail))
def parallel_r75 : Raw := (.obj parallel_l75_0)
def parallel_b75 : List Nat := parallel_g193 ++ (parallel_v75_0 ++ parallel_g219)
theorem parallel_o75 : orderedFields parallel_l75_0 = true := by decide +kernel
theorem parallel_s75 : serializeRaw 4076 28 parallel_r75 = some parallel_b75 := by
  simpa only [parallel_r75, parallel_b75, parallel_g193, parallel_g219, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4075 27 parallel_l75_0 parallel_v75_0 parallel_o75 parallel_sl75_0)
theorem parallel_p75 (tail : List Nat) : parseRaw 4076 28 (parallel_b75 ++ tail) = some (parallel_r75, tail) := by
  simpa only [parallel_r75, parallel_b75, parallel_g193, parallel_g219, parallel_v75_0, parallel_k75_0, parallel_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4075 27 (parallel_k75_0 ++ (34 :: 58 :: (parallel_b76 ++ (44 :: (parallel_v75_1 ++ (125 :: tail)))))) tail parallel_l75_0 parallel_o75 (by simpa only [parallel_v75_0, parallel_k75_0, parallel_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl75_0 tail)))
def parallel_r88 : Raw := (.str [100,103,95,102,97,115,116,95,53])
def parallel_b88 : List Nat := parallel_g223
theorem parallel_s88 : serializeRaw 4073 27 parallel_r88 = some parallel_b88 := by decide +kernel
theorem parallel_p88 (tail : List Nat) : parseRaw 4073 27 (parallel_b88 ++ tail) = some (parallel_r88, tail) := by rfl
def parallel_r89 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def parallel_b89 : List Nat := parallel_g226
theorem parallel_s89 : serializeRaw 4072 27 parallel_r89 = some parallel_b89 := by decide +kernel
theorem parallel_p89 (tail : List Nat) : parseRaw 4072 27 (parallel_b89 ++ tail) = some (parallel_r89, tail) := by rfl
def parallel_r90 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,48])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b90 : List Nat := parallel_g229
theorem parallel_s90 : serializeRaw 4071 27 parallel_r90 = some parallel_b90 := by decide +kernel
theorem parallel_p90 (tail : List Nat) : parseRaw 4071 27 (parallel_b90 ++ tail) = some (parallel_r90, tail) := by rfl
def parallel_r91 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,48,48])]))])
def parallel_b91 : List Nat := parallel_g232
theorem parallel_s91 : serializeRaw 4070 27 parallel_r91 = some parallel_b91 := by decide +kernel
theorem parallel_p91 (tail : List Nat) : parseRaw 4070 27 (parallel_b91 ++ tail) = some (parallel_r91, tail) := by rfl
def parallel_k87_0 : List Nat := [105,100]
theorem parallel_kd87_0 : stringBytes parallel_k87_0 = true := by decide +kernel
theorem parallel_kp87_0 (tail : List Nat) : parseStringTail (parallel_k87_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k87_0, 58 :: tail) := by rfl
def parallel_k87_1 : List Nat := [111,112,115]
theorem parallel_kd87_1 : stringBytes parallel_k87_1 = true := by decide +kernel
theorem parallel_kp87_1 (tail : List Nat) : parseStringTail (parallel_k87_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k87_1, 58 :: tail) := by rfl
def parallel_k87_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd87_2 : stringBytes parallel_k87_2 = true := by decide +kernel
theorem parallel_kp87_2 (tail : List Nat) : parseStringTail (parallel_k87_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k87_2, 58 :: tail) := by rfl
def parallel_k87_3 : List Nat := [116,101,114,109]
theorem parallel_kd87_3 : stringBytes parallel_k87_3 = true := by decide +kernel
theorem parallel_kp87_3 (tail : List Nat) : parseStringTail (parallel_k87_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k87_3, 58 :: tail) := by rfl
def parallel_l87_3 : List (List Nat × Raw) := [(parallel_k87_3, parallel_r91)]
def parallel_v87_3 : List Nat := parallel_g231 ++ parallel_b91
theorem parallel_sl87_3 : serializeFields 4071 27 parallel_l87_3 = some parallel_v87_3 := by
  simpa only [parallel_l87_3, parallel_v87_3, parallel_k87_3, parallel_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4070 27 parallel_k87_3 parallel_r91 parallel_b91 parallel_kd87_3 parallel_s91)
theorem parallel_pl87_3 (tail : List Nat) : parseFields 4071 27 (parallel_v87_3 ++ (125 :: tail)) = some (parallel_l87_3, tail) := by
  simpa only [parallel_l87_3, parallel_v87_3, parallel_k87_3, parallel_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4070 27 (parallel_k87_3 ++ (34 :: 58 :: (parallel_b91 ++ (125 :: tail)))) parallel_k87_3 (parallel_b91 ++ (125 :: tail)) tail parallel_r91 (parallel_kp87_3 (parallel_b91 ++ (125 :: tail))) (parallel_p91 (125 :: tail)))
def parallel_l87_2 : List (List Nat × Raw) := (parallel_k87_2, parallel_r90) :: parallel_l87_3
def parallel_v87_2 : List Nat := (parallel_g228 ++ parallel_b90) ++ (44 :: parallel_v87_3)
theorem parallel_sl87_2 : serializeFields 4072 27 parallel_l87_2 = some parallel_v87_2 := by
  simpa only [parallel_l87_2, parallel_v87_2, parallel_k87_2, parallel_g228, parallel_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 parallel_k87_2 parallel_r90 (parallel_k87_3, parallel_r91) [] parallel_b90 parallel_v87_3 parallel_kd87_2 parallel_s90 parallel_sl87_3)
theorem parallel_pl87_2 (tail : List Nat) : parseFields 4072 27 (parallel_v87_2 ++ (125 :: tail)) = some (parallel_l87_2, tail) := by
  simpa only [parallel_l87_2, parallel_v87_2, parallel_k87_2, parallel_g228, parallel_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (parallel_k87_2 ++ (34 :: 58 :: (parallel_b90 ++ (44 :: (parallel_v87_3 ++ (125 :: tail)))))) parallel_k87_2 (parallel_b90 ++ (44 :: (parallel_v87_3 ++ (125 :: tail)))) (parallel_v87_3 ++ (125 :: tail)) tail parallel_r90 parallel_l87_3 (parallel_kp87_2 (parallel_b90 ++ (44 :: (parallel_v87_3 ++ (125 :: tail))))) (parallel_p90 (44 :: (parallel_v87_3 ++ (125 :: tail)))) (parallel_pl87_3 tail))
def parallel_l87_1 : List (List Nat × Raw) := (parallel_k87_1, parallel_r89) :: parallel_l87_2
def parallel_v87_1 : List Nat := (parallel_g225 ++ parallel_b89) ++ (44 :: parallel_v87_2)
theorem parallel_sl87_1 : serializeFields 4073 27 parallel_l87_1 = some parallel_v87_1 := by
  simpa only [parallel_l87_1, parallel_v87_1, parallel_k87_1, parallel_g225, parallel_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 parallel_k87_1 parallel_r89 (parallel_k87_2, parallel_r90) parallel_l87_3 parallel_b89 parallel_v87_2 parallel_kd87_1 parallel_s89 parallel_sl87_2)
theorem parallel_pl87_1 (tail : List Nat) : parseFields 4073 27 (parallel_v87_1 ++ (125 :: tail)) = some (parallel_l87_1, tail) := by
  simpa only [parallel_l87_1, parallel_v87_1, parallel_k87_1, parallel_g225, parallel_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (parallel_k87_1 ++ (34 :: 58 :: (parallel_b89 ++ (44 :: (parallel_v87_2 ++ (125 :: tail)))))) parallel_k87_1 (parallel_b89 ++ (44 :: (parallel_v87_2 ++ (125 :: tail)))) (parallel_v87_2 ++ (125 :: tail)) tail parallel_r89 parallel_l87_2 (parallel_kp87_1 (parallel_b89 ++ (44 :: (parallel_v87_2 ++ (125 :: tail))))) (parallel_p89 (44 :: (parallel_v87_2 ++ (125 :: tail)))) (parallel_pl87_2 tail))
def parallel_l87_0 : List (List Nat × Raw) := (parallel_k87_0, parallel_r88) :: parallel_l87_1
def parallel_v87_0 : List Nat := (parallel_g222 ++ parallel_b88) ++ (44 :: parallel_v87_1)
theorem parallel_sl87_0 : serializeFields 4074 27 parallel_l87_0 = some parallel_v87_0 := by
  simpa only [parallel_l87_0, parallel_v87_0, parallel_k87_0, parallel_g222, parallel_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 parallel_k87_0 parallel_r88 (parallel_k87_1, parallel_r89) parallel_l87_2 parallel_b88 parallel_v87_1 parallel_kd87_0 parallel_s88 parallel_sl87_1)
theorem parallel_pl87_0 (tail : List Nat) : parseFields 4074 27 (parallel_v87_0 ++ (125 :: tail)) = some (parallel_l87_0, tail) := by
  simpa only [parallel_l87_0, parallel_v87_0, parallel_k87_0, parallel_g222, parallel_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (parallel_k87_0 ++ (34 :: 58 :: (parallel_b88 ++ (44 :: (parallel_v87_1 ++ (125 :: tail)))))) parallel_k87_0 (parallel_b88 ++ (44 :: (parallel_v87_1 ++ (125 :: tail)))) (parallel_v87_1 ++ (125 :: tail)) tail parallel_r88 parallel_l87_1 (parallel_kp87_0 (parallel_b88 ++ (44 :: (parallel_v87_1 ++ (125 :: tail))))) (parallel_p88 (44 :: (parallel_v87_1 ++ (125 :: tail)))) (parallel_pl87_1 tail))
def parallel_r87 : Raw := (.obj parallel_l87_0)
def parallel_b87 : List Nat := parallel_g221 ++ (parallel_v87_0 ++ parallel_g233)
theorem parallel_o87 : orderedFields parallel_l87_0 = true := by decide +kernel
theorem parallel_s87 : serializeRaw 4075 28 parallel_r87 = some parallel_b87 := by
  simpa only [parallel_r87, parallel_b87, parallel_g221, parallel_g233, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4074 27 parallel_l87_0 parallel_v87_0 parallel_o87 parallel_sl87_0)
theorem parallel_p87 (tail : List Nat) : parseRaw 4075 28 (parallel_b87 ++ tail) = some (parallel_r87, tail) := by
  simpa only [parallel_r87, parallel_b87, parallel_g221, parallel_g233, parallel_v87_0, parallel_k87_0, parallel_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4074 27 (parallel_k87_0 ++ (34 :: 58 :: (parallel_b88 ++ (44 :: (parallel_v87_1 ++ (125 :: tail)))))) tail parallel_l87_0 parallel_o87 (by simpa only [parallel_v87_0, parallel_k87_0, parallel_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl87_0 tail)))
def parallel_r93 : Raw := (.str [100,103,95,115,108,111,119,95,48])
def parallel_b93 : List Nat := parallel_g237
theorem parallel_s93 : serializeRaw 4072 27 parallel_r93 = some parallel_b93 := by decide +kernel
theorem parallel_p93 (tail : List Nat) : parseRaw 4072 27 (parallel_b93 ++ tail) = some (parallel_r93, tail) := by rfl
def parallel_r94 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,56]),(.str [100,103,95,118,95,49,48,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,57])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b94 : List Nat := parallel_g240
theorem parallel_s94 : serializeRaw 4071 27 parallel_r94 = some parallel_b94 := by decide +kernel
theorem parallel_p94 (tail : List Nat) : parseRaw 4071 27 (parallel_b94 ++ tail) = some (parallel_r94, tail) := by rfl
def parallel_r95 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b95 : List Nat := parallel_g243
theorem parallel_s95 : serializeRaw 4070 27 parallel_r95 = some parallel_b95 := by decide +kernel
theorem parallel_p95 (tail : List Nat) : parseRaw 4070 27 (parallel_b95 ++ tail) = some (parallel_r95, tail) := by rfl
def parallel_r96 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,48,57])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))]))])
def parallel_b96 : List Nat := parallel_g246
theorem parallel_s96 : serializeRaw 4069 27 parallel_r96 = some parallel_b96 := by decide +kernel
theorem parallel_p96 (tail : List Nat) : parseRaw 4069 27 (parallel_b96 ++ tail) = some (parallel_r96, tail) := by rfl
def parallel_k92_0 : List Nat := [105,100]
theorem parallel_kd92_0 : stringBytes parallel_k92_0 = true := by decide +kernel
theorem parallel_kp92_0 (tail : List Nat) : parseStringTail (parallel_k92_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k92_0, 58 :: tail) := by rfl
def parallel_k92_1 : List Nat := [111,112,115]
theorem parallel_kd92_1 : stringBytes parallel_k92_1 = true := by decide +kernel
theorem parallel_kp92_1 (tail : List Nat) : parseStringTail (parallel_k92_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k92_1, 58 :: tail) := by rfl
def parallel_k92_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd92_2 : stringBytes parallel_k92_2 = true := by decide +kernel
theorem parallel_kp92_2 (tail : List Nat) : parseStringTail (parallel_k92_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k92_2, 58 :: tail) := by rfl
def parallel_k92_3 : List Nat := [116,101,114,109]
theorem parallel_kd92_3 : stringBytes parallel_k92_3 = true := by decide +kernel
theorem parallel_kp92_3 (tail : List Nat) : parseStringTail (parallel_k92_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k92_3, 58 :: tail) := by rfl
def parallel_l92_3 : List (List Nat × Raw) := [(parallel_k92_3, parallel_r96)]
def parallel_v92_3 : List Nat := parallel_g245 ++ parallel_b96
theorem parallel_sl92_3 : serializeFields 4070 27 parallel_l92_3 = some parallel_v92_3 := by
  simpa only [parallel_l92_3, parallel_v92_3, parallel_k92_3, parallel_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4069 27 parallel_k92_3 parallel_r96 parallel_b96 parallel_kd92_3 parallel_s96)
theorem parallel_pl92_3 (tail : List Nat) : parseFields 4070 27 (parallel_v92_3 ++ (125 :: tail)) = some (parallel_l92_3, tail) := by
  simpa only [parallel_l92_3, parallel_v92_3, parallel_k92_3, parallel_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4069 27 (parallel_k92_3 ++ (34 :: 58 :: (parallel_b96 ++ (125 :: tail)))) parallel_k92_3 (parallel_b96 ++ (125 :: tail)) tail parallel_r96 (parallel_kp92_3 (parallel_b96 ++ (125 :: tail))) (parallel_p96 (125 :: tail)))
def parallel_l92_2 : List (List Nat × Raw) := (parallel_k92_2, parallel_r95) :: parallel_l92_3
def parallel_v92_2 : List Nat := (parallel_g242 ++ parallel_b95) ++ (44 :: parallel_v92_3)
theorem parallel_sl92_2 : serializeFields 4071 27 parallel_l92_2 = some parallel_v92_2 := by
  simpa only [parallel_l92_2, parallel_v92_2, parallel_k92_2, parallel_g242, parallel_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 parallel_k92_2 parallel_r95 (parallel_k92_3, parallel_r96) [] parallel_b95 parallel_v92_3 parallel_kd92_2 parallel_s95 parallel_sl92_3)
theorem parallel_pl92_2 (tail : List Nat) : parseFields 4071 27 (parallel_v92_2 ++ (125 :: tail)) = some (parallel_l92_2, tail) := by
  simpa only [parallel_l92_2, parallel_v92_2, parallel_k92_2, parallel_g242, parallel_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (parallel_k92_2 ++ (34 :: 58 :: (parallel_b95 ++ (44 :: (parallel_v92_3 ++ (125 :: tail)))))) parallel_k92_2 (parallel_b95 ++ (44 :: (parallel_v92_3 ++ (125 :: tail)))) (parallel_v92_3 ++ (125 :: tail)) tail parallel_r95 parallel_l92_3 (parallel_kp92_2 (parallel_b95 ++ (44 :: (parallel_v92_3 ++ (125 :: tail))))) (parallel_p95 (44 :: (parallel_v92_3 ++ (125 :: tail)))) (parallel_pl92_3 tail))
def parallel_l92_1 : List (List Nat × Raw) := (parallel_k92_1, parallel_r94) :: parallel_l92_2
def parallel_v92_1 : List Nat := (parallel_g239 ++ parallel_b94) ++ (44 :: parallel_v92_2)
theorem parallel_sl92_1 : serializeFields 4072 27 parallel_l92_1 = some parallel_v92_1 := by
  simpa only [parallel_l92_1, parallel_v92_1, parallel_k92_1, parallel_g239, parallel_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 parallel_k92_1 parallel_r94 (parallel_k92_2, parallel_r95) parallel_l92_3 parallel_b94 parallel_v92_2 parallel_kd92_1 parallel_s94 parallel_sl92_2)
theorem parallel_pl92_1 (tail : List Nat) : parseFields 4072 27 (parallel_v92_1 ++ (125 :: tail)) = some (parallel_l92_1, tail) := by
  simpa only [parallel_l92_1, parallel_v92_1, parallel_k92_1, parallel_g239, parallel_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (parallel_k92_1 ++ (34 :: 58 :: (parallel_b94 ++ (44 :: (parallel_v92_2 ++ (125 :: tail)))))) parallel_k92_1 (parallel_b94 ++ (44 :: (parallel_v92_2 ++ (125 :: tail)))) (parallel_v92_2 ++ (125 :: tail)) tail parallel_r94 parallel_l92_2 (parallel_kp92_1 (parallel_b94 ++ (44 :: (parallel_v92_2 ++ (125 :: tail))))) (parallel_p94 (44 :: (parallel_v92_2 ++ (125 :: tail)))) (parallel_pl92_2 tail))
def parallel_l92_0 : List (List Nat × Raw) := (parallel_k92_0, parallel_r93) :: parallel_l92_1
def parallel_v92_0 : List Nat := (parallel_g236 ++ parallel_b93) ++ (44 :: parallel_v92_1)
theorem parallel_sl92_0 : serializeFields 4073 27 parallel_l92_0 = some parallel_v92_0 := by
  simpa only [parallel_l92_0, parallel_v92_0, parallel_k92_0, parallel_g236, parallel_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 parallel_k92_0 parallel_r93 (parallel_k92_1, parallel_r94) parallel_l92_2 parallel_b93 parallel_v92_1 parallel_kd92_0 parallel_s93 parallel_sl92_1)
theorem parallel_pl92_0 (tail : List Nat) : parseFields 4073 27 (parallel_v92_0 ++ (125 :: tail)) = some (parallel_l92_0, tail) := by
  simpa only [parallel_l92_0, parallel_v92_0, parallel_k92_0, parallel_g236, parallel_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (parallel_k92_0 ++ (34 :: 58 :: (parallel_b93 ++ (44 :: (parallel_v92_1 ++ (125 :: tail)))))) parallel_k92_0 (parallel_b93 ++ (44 :: (parallel_v92_1 ++ (125 :: tail)))) (parallel_v92_1 ++ (125 :: tail)) tail parallel_r93 parallel_l92_1 (parallel_kp92_0 (parallel_b93 ++ (44 :: (parallel_v92_1 ++ (125 :: tail))))) (parallel_p93 (44 :: (parallel_v92_1 ++ (125 :: tail)))) (parallel_pl92_1 tail))
def parallel_r92 : Raw := (.obj parallel_l92_0)
def parallel_b92 : List Nat := parallel_g235 ++ (parallel_v92_0 ++ parallel_g247)
theorem parallel_o92 : orderedFields parallel_l92_0 = true := by decide +kernel
theorem parallel_s92 : serializeRaw 4074 28 parallel_r92 = some parallel_b92 := by
  simpa only [parallel_r92, parallel_b92, parallel_g235, parallel_g247, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4073 27 parallel_l92_0 parallel_v92_0 parallel_o92 parallel_sl92_0)
theorem parallel_p92 (tail : List Nat) : parseRaw 4074 28 (parallel_b92 ++ tail) = some (parallel_r92, tail) := by
  simpa only [parallel_r92, parallel_b92, parallel_g235, parallel_g247, parallel_v92_0, parallel_k92_0, parallel_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4073 27 (parallel_k92_0 ++ (34 :: 58 :: (parallel_b93 ++ (44 :: (parallel_v92_1 ++ (125 :: tail)))))) tail parallel_l92_0 parallel_o92 (by simpa only [parallel_v92_0, parallel_k92_0, parallel_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl92_0 tail)))
def parallel_r98 : Raw := (.str [100,103,95,115,108,111,119,95,49])
def parallel_b98 : List Nat := parallel_g251
theorem parallel_s98 : serializeRaw 4071 27 parallel_r98 = some parallel_b98 := by decide +kernel
theorem parallel_p98 (tail : List Nat) : parseRaw 4071 27 (parallel_b98 ++ tail) = some (parallel_r98, tail) := by rfl
def parallel_r100 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,53])),([116,121,112,101],(.str [117,51,50]))])]))])
def parallel_b100 : List Nat := parallel_g255
theorem parallel_s100 : serializeRaw 4068 26 parallel_r100 = some parallel_b100 := by decide +kernel
theorem parallel_p100 (tail : List Nat) : parseRaw 4068 26 (parallel_b100 ++ tail) = some (parallel_r100, tail) := by rfl
def parallel_r101 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,53]),(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,54])),([116,121,112,101],(.str [117,51,50]))])]))])
def parallel_b101 : List Nat := parallel_g257
theorem parallel_s101 : serializeRaw 4067 26 parallel_r101 = some parallel_b101 := by decide +kernel
theorem parallel_p101 (tail : List Nat) : parseRaw 4067 26 (parallel_b101 ++ tail) = some (parallel_r101, tail) := by rfl
def parallel_r102 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,55])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b102 : List Nat := parallel_g259
theorem parallel_s102 : serializeRaw 4066 26 parallel_r102 = some parallel_b102 := by decide +kernel
theorem parallel_p102 (tail : List Nat) : parseRaw 4066 26 (parallel_b102 ++ tail) = some (parallel_r102, tail) := by rfl
def parallel_r103 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,56])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b103 : List Nat := parallel_g261
theorem parallel_s103 : serializeRaw 4065 26 parallel_r103 = some parallel_b103 := by decide +kernel
theorem parallel_p103 (tail : List Nat) : parseRaw 4065 26 (parallel_b103 ++ tail) = some (parallel_r103, tail) := by rfl
def parallel_r104 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,55]),(.str [100,103,95,118,95,49,49,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,57])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b104 : List Nat := parallel_g263
theorem parallel_s104 : serializeRaw 4064 26 parallel_r104 = some parallel_b104 := by decide +kernel
theorem parallel_p104 (tail : List Nat) : parseRaw 4064 26 (parallel_b104 ++ tail) = some (parallel_r104, tail) := by rfl
def parallel_r105 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,57])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,48])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b105 : List Nat := parallel_g265
theorem parallel_s105 : serializeRaw 4063 26 parallel_r105 = some parallel_b105 := by decide +kernel
theorem parallel_p105 (tail : List Nat) : parseRaw 4063 26 (parallel_b105 ++ tail) = some (parallel_r105, tail) := by rfl
def parallel_r106 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,49])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def parallel_b106 : List Nat := parallel_g267
theorem parallel_s106 : serializeRaw 4062 26 parallel_r106 = some parallel_b106 := by decide +kernel
theorem parallel_p106 (tail : List Nat) : parseRaw 4062 26 (parallel_b106 ++ tail) = some (parallel_r106, tail) := by rfl
def parallel_r107 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49]),(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def parallel_b107 : List Nat := parallel_g269
theorem parallel_s107 : serializeRaw 4061 26 parallel_r107 = some parallel_b107 := by decide +kernel
theorem parallel_p107 (tail : List Nat) : parseRaw 4061 26 (parallel_b107 ++ tail) = some (parallel_r107, tail) := by rfl
def parallel_r108 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def parallel_b108 : List Nat := parallel_g271
theorem parallel_s108 : serializeRaw 4060 26 parallel_r108 = some parallel_b108 := by decide +kernel
theorem parallel_p108 (tail : List Nat) : parseRaw 4060 26 (parallel_b108 ++ tail) = some (parallel_r108, tail) := by rfl
def parallel_r109 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b109 : List Nat := parallel_g273
theorem parallel_s109 : serializeRaw 4059 26 parallel_r109 = some parallel_b109 := by decide +kernel
theorem parallel_p109 (tail : List Nat) : parseRaw 4059 26 (parallel_b109 ++ tail) = some (parallel_r109, tail) := by rfl
def parallel_r110 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b110 : List Nat := parallel_g275
theorem parallel_s110 : serializeRaw 4058 26 parallel_r110 = some parallel_b110 := by decide +kernel
theorem parallel_p110 (tail : List Nat) : parseRaw 4058 26 (parallel_b110 ++ tail) = some (parallel_r110, tail) := by rfl
def parallel_l99_10 : List Raw := [parallel_r110]
def parallel_v99_10 : List Nat := parallel_b110
theorem parallel_sl99_10 : serializeItems 4059 26 parallel_l99_10 = some parallel_v99_10 := by
  simpa only [parallel_l99_10, parallel_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4058 26 parallel_r110 parallel_b110 parallel_s110)
theorem parallel_pl99_10 (tail : List Nat) : parseItems 4059 26 (parallel_v99_10 ++ (93 :: tail)) = some (parallel_l99_10, tail) := by
  simpa only [parallel_l99_10, parallel_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4058 26 (parallel_b110 ++ (93 :: tail)) tail parallel_r110 (parallel_p110 (93 :: tail)))
def parallel_l99_9 : List Raw := parallel_r109 :: parallel_l99_10
def parallel_v99_9 : List Nat := (parallel_b109) ++ (44 :: parallel_v99_10)
theorem parallel_sl99_9 : serializeItems 4060 26 parallel_l99_9 = some parallel_v99_9 := by
  simpa only [parallel_l99_9, parallel_v99_9, parallel_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4059 26 parallel_r109 parallel_r110 [] parallel_b109 parallel_v99_10 parallel_s109 parallel_sl99_10)
theorem parallel_pl99_9 (tail : List Nat) : parseItems 4060 26 (parallel_v99_9 ++ (93 :: tail)) = some (parallel_l99_9, tail) := by
  simpa only [parallel_l99_9, parallel_v99_9, parallel_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4059 26 (parallel_b109 ++ (44 :: (parallel_v99_10 ++ (93 :: tail)))) (parallel_v99_10 ++ (93 :: tail)) tail parallel_r109 parallel_l99_10 (parallel_p109 (44 :: (parallel_v99_10 ++ (93 :: tail)))) (parallel_pl99_10 tail))
def parallel_l99_8 : List Raw := parallel_r108 :: parallel_l99_9
def parallel_v99_8 : List Nat := (parallel_b108) ++ (44 :: parallel_v99_9)
theorem parallel_sl99_8 : serializeItems 4061 26 parallel_l99_8 = some parallel_v99_8 := by
  simpa only [parallel_l99_8, parallel_v99_8, parallel_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 parallel_r108 parallel_r109 parallel_l99_10 parallel_b108 parallel_v99_9 parallel_s108 parallel_sl99_9)
theorem parallel_pl99_8 (tail : List Nat) : parseItems 4061 26 (parallel_v99_8 ++ (93 :: tail)) = some (parallel_l99_8, tail) := by
  simpa only [parallel_l99_8, parallel_v99_8, parallel_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (parallel_b108 ++ (44 :: (parallel_v99_9 ++ (93 :: tail)))) (parallel_v99_9 ++ (93 :: tail)) tail parallel_r108 parallel_l99_9 (parallel_p108 (44 :: (parallel_v99_9 ++ (93 :: tail)))) (parallel_pl99_9 tail))
def parallel_l99_7 : List Raw := parallel_r107 :: parallel_l99_8
def parallel_v99_7 : List Nat := (parallel_b107) ++ (44 :: parallel_v99_8)
theorem parallel_sl99_7 : serializeItems 4062 26 parallel_l99_7 = some parallel_v99_7 := by
  simpa only [parallel_l99_7, parallel_v99_7, parallel_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 parallel_r107 parallel_r108 parallel_l99_9 parallel_b107 parallel_v99_8 parallel_s107 parallel_sl99_8)
theorem parallel_pl99_7 (tail : List Nat) : parseItems 4062 26 (parallel_v99_7 ++ (93 :: tail)) = some (parallel_l99_7, tail) := by
  simpa only [parallel_l99_7, parallel_v99_7, parallel_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (parallel_b107 ++ (44 :: (parallel_v99_8 ++ (93 :: tail)))) (parallel_v99_8 ++ (93 :: tail)) tail parallel_r107 parallel_l99_8 (parallel_p107 (44 :: (parallel_v99_8 ++ (93 :: tail)))) (parallel_pl99_8 tail))
def parallel_l99_6 : List Raw := parallel_r106 :: parallel_l99_7
def parallel_v99_6 : List Nat := (parallel_b106) ++ (44 :: parallel_v99_7)
theorem parallel_sl99_6 : serializeItems 4063 26 parallel_l99_6 = some parallel_v99_6 := by
  simpa only [parallel_l99_6, parallel_v99_6, parallel_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 parallel_r106 parallel_r107 parallel_l99_8 parallel_b106 parallel_v99_7 parallel_s106 parallel_sl99_7)
theorem parallel_pl99_6 (tail : List Nat) : parseItems 4063 26 (parallel_v99_6 ++ (93 :: tail)) = some (parallel_l99_6, tail) := by
  simpa only [parallel_l99_6, parallel_v99_6, parallel_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (parallel_b106 ++ (44 :: (parallel_v99_7 ++ (93 :: tail)))) (parallel_v99_7 ++ (93 :: tail)) tail parallel_r106 parallel_l99_7 (parallel_p106 (44 :: (parallel_v99_7 ++ (93 :: tail)))) (parallel_pl99_7 tail))
def parallel_l99_5 : List Raw := parallel_r105 :: parallel_l99_6
def parallel_v99_5 : List Nat := (parallel_b105) ++ (44 :: parallel_v99_6)
theorem parallel_sl99_5 : serializeItems 4064 26 parallel_l99_5 = some parallel_v99_5 := by
  simpa only [parallel_l99_5, parallel_v99_5, parallel_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 parallel_r105 parallel_r106 parallel_l99_7 parallel_b105 parallel_v99_6 parallel_s105 parallel_sl99_6)
theorem parallel_pl99_5 (tail : List Nat) : parseItems 4064 26 (parallel_v99_5 ++ (93 :: tail)) = some (parallel_l99_5, tail) := by
  simpa only [parallel_l99_5, parallel_v99_5, parallel_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (parallel_b105 ++ (44 :: (parallel_v99_6 ++ (93 :: tail)))) (parallel_v99_6 ++ (93 :: tail)) tail parallel_r105 parallel_l99_6 (parallel_p105 (44 :: (parallel_v99_6 ++ (93 :: tail)))) (parallel_pl99_6 tail))
def parallel_l99_4 : List Raw := parallel_r104 :: parallel_l99_5
def parallel_v99_4 : List Nat := (parallel_b104) ++ (44 :: parallel_v99_5)
theorem parallel_sl99_4 : serializeItems 4065 26 parallel_l99_4 = some parallel_v99_4 := by
  simpa only [parallel_l99_4, parallel_v99_4, parallel_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 parallel_r104 parallel_r105 parallel_l99_6 parallel_b104 parallel_v99_5 parallel_s104 parallel_sl99_5)
theorem parallel_pl99_4 (tail : List Nat) : parseItems 4065 26 (parallel_v99_4 ++ (93 :: tail)) = some (parallel_l99_4, tail) := by
  simpa only [parallel_l99_4, parallel_v99_4, parallel_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (parallel_b104 ++ (44 :: (parallel_v99_5 ++ (93 :: tail)))) (parallel_v99_5 ++ (93 :: tail)) tail parallel_r104 parallel_l99_5 (parallel_p104 (44 :: (parallel_v99_5 ++ (93 :: tail)))) (parallel_pl99_5 tail))
def parallel_l99_3 : List Raw := parallel_r103 :: parallel_l99_4
def parallel_v99_3 : List Nat := (parallel_b103) ++ (44 :: parallel_v99_4)
theorem parallel_sl99_3 : serializeItems 4066 26 parallel_l99_3 = some parallel_v99_3 := by
  simpa only [parallel_l99_3, parallel_v99_3, parallel_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 parallel_r103 parallel_r104 parallel_l99_5 parallel_b103 parallel_v99_4 parallel_s103 parallel_sl99_4)
theorem parallel_pl99_3 (tail : List Nat) : parseItems 4066 26 (parallel_v99_3 ++ (93 :: tail)) = some (parallel_l99_3, tail) := by
  simpa only [parallel_l99_3, parallel_v99_3, parallel_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (parallel_b103 ++ (44 :: (parallel_v99_4 ++ (93 :: tail)))) (parallel_v99_4 ++ (93 :: tail)) tail parallel_r103 parallel_l99_4 (parallel_p103 (44 :: (parallel_v99_4 ++ (93 :: tail)))) (parallel_pl99_4 tail))
def parallel_l99_2 : List Raw := parallel_r102 :: parallel_l99_3
def parallel_v99_2 : List Nat := (parallel_b102) ++ (44 :: parallel_v99_3)
theorem parallel_sl99_2 : serializeItems 4067 26 parallel_l99_2 = some parallel_v99_2 := by
  simpa only [parallel_l99_2, parallel_v99_2, parallel_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 parallel_r102 parallel_r103 parallel_l99_4 parallel_b102 parallel_v99_3 parallel_s102 parallel_sl99_3)
theorem parallel_pl99_2 (tail : List Nat) : parseItems 4067 26 (parallel_v99_2 ++ (93 :: tail)) = some (parallel_l99_2, tail) := by
  simpa only [parallel_l99_2, parallel_v99_2, parallel_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (parallel_b102 ++ (44 :: (parallel_v99_3 ++ (93 :: tail)))) (parallel_v99_3 ++ (93 :: tail)) tail parallel_r102 parallel_l99_3 (parallel_p102 (44 :: (parallel_v99_3 ++ (93 :: tail)))) (parallel_pl99_3 tail))
def parallel_l99_1 : List Raw := parallel_r101 :: parallel_l99_2
def parallel_v99_1 : List Nat := (parallel_b101) ++ (44 :: parallel_v99_2)
theorem parallel_sl99_1 : serializeItems 4068 26 parallel_l99_1 = some parallel_v99_1 := by
  simpa only [parallel_l99_1, parallel_v99_1, parallel_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 parallel_r101 parallel_r102 parallel_l99_3 parallel_b101 parallel_v99_2 parallel_s101 parallel_sl99_2)
theorem parallel_pl99_1 (tail : List Nat) : parseItems 4068 26 (parallel_v99_1 ++ (93 :: tail)) = some (parallel_l99_1, tail) := by
  simpa only [parallel_l99_1, parallel_v99_1, parallel_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (parallel_b101 ++ (44 :: (parallel_v99_2 ++ (93 :: tail)))) (parallel_v99_2 ++ (93 :: tail)) tail parallel_r101 parallel_l99_2 (parallel_p101 (44 :: (parallel_v99_2 ++ (93 :: tail)))) (parallel_pl99_2 tail))
def parallel_l99_0 : List Raw := parallel_r100 :: parallel_l99_1
def parallel_v99_0 : List Nat := (parallel_b100) ++ (44 :: parallel_v99_1)
theorem parallel_sl99_0 : serializeItems 4069 26 parallel_l99_0 = some parallel_v99_0 := by
  simpa only [parallel_l99_0, parallel_v99_0, parallel_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 parallel_r100 parallel_r101 parallel_l99_2 parallel_b100 parallel_v99_1 parallel_s100 parallel_sl99_1)
theorem parallel_pl99_0 (tail : List Nat) : parseItems 4069 26 (parallel_v99_0 ++ (93 :: tail)) = some (parallel_l99_0, tail) := by
  simpa only [parallel_l99_0, parallel_v99_0, parallel_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (parallel_b100 ++ (44 :: (parallel_v99_1 ++ (93 :: tail)))) (parallel_v99_1 ++ (93 :: tail)) tail parallel_r100 parallel_l99_1 (parallel_p100 (44 :: (parallel_v99_1 ++ (93 :: tail)))) (parallel_pl99_1 tail))
def parallel_r99 : Raw := (.arr parallel_l99_0)
def parallel_b99 : List Nat := parallel_g254 ++ (parallel_v99_0 ++ parallel_g276)
theorem parallel_s99 : serializeRaw 4070 27 parallel_r99 = some parallel_b99 := by
  simpa only [parallel_r99, parallel_b99, parallel_g254, parallel_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4069 26 parallel_l99_0 parallel_v99_0 parallel_sl99_0)
theorem parallel_p99 (tail : List Nat) : parseRaw 4070 27 (parallel_b99 ++ tail) = some (parallel_r99, tail) := by
  simpa only [parallel_r99, parallel_b99, parallel_g254, parallel_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4069 26 (parallel_v99_0 ++ (93 :: tail)) tail parallel_l99_0 (by intro h; cases h) (parallel_pl99_0 tail))
def parallel_r111 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b111 : List Nat := parallel_g279
theorem parallel_s111 : serializeRaw 4069 27 parallel_r111 = some parallel_b111 := by decide +kernel
theorem parallel_p111 (tail : List Nat) : parseRaw 4069 27 (parallel_b111 ++ tail) = some (parallel_r111, tail) := by rfl
def parallel_r112 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,48]),(.str [100,103,95,118,95,49,49,49]),(.str [100,103,95,118,95,49,49,50]),(.str [100,103,95,118,95,49,49,51]),(.str [100,103,95,118,95,49,50,51])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,48]))])
def parallel_b112 : List Nat := parallel_g282
theorem parallel_s112 : serializeRaw 4068 27 parallel_r112 = some parallel_b112 := by decide +kernel
theorem parallel_p112 (tail : List Nat) : parseRaw 4068 27 (parallel_b112 ++ tail) = some (parallel_r112, tail) := by rfl
def parallel_k97_0 : List Nat := [105,100]
theorem parallel_kd97_0 : stringBytes parallel_k97_0 = true := by decide +kernel
theorem parallel_kp97_0 (tail : List Nat) : parseStringTail (parallel_k97_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k97_0, 58 :: tail) := by rfl
def parallel_k97_1 : List Nat := [111,112,115]
theorem parallel_kd97_1 : stringBytes parallel_k97_1 = true := by decide +kernel
theorem parallel_kp97_1 (tail : List Nat) : parseStringTail (parallel_k97_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k97_1, 58 :: tail) := by rfl
def parallel_k97_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd97_2 : stringBytes parallel_k97_2 = true := by decide +kernel
theorem parallel_kp97_2 (tail : List Nat) : parseStringTail (parallel_k97_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k97_2, 58 :: tail) := by rfl
def parallel_k97_3 : List Nat := [116,101,114,109]
theorem parallel_kd97_3 : stringBytes parallel_k97_3 = true := by decide +kernel
theorem parallel_kp97_3 (tail : List Nat) : parseStringTail (parallel_k97_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k97_3, 58 :: tail) := by rfl
def parallel_l97_3 : List (List Nat × Raw) := [(parallel_k97_3, parallel_r112)]
def parallel_v97_3 : List Nat := parallel_g281 ++ parallel_b112
theorem parallel_sl97_3 : serializeFields 4069 27 parallel_l97_3 = some parallel_v97_3 := by
  simpa only [parallel_l97_3, parallel_v97_3, parallel_k97_3, parallel_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4068 27 parallel_k97_3 parallel_r112 parallel_b112 parallel_kd97_3 parallel_s112)
theorem parallel_pl97_3 (tail : List Nat) : parseFields 4069 27 (parallel_v97_3 ++ (125 :: tail)) = some (parallel_l97_3, tail) := by
  simpa only [parallel_l97_3, parallel_v97_3, parallel_k97_3, parallel_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4068 27 (parallel_k97_3 ++ (34 :: 58 :: (parallel_b112 ++ (125 :: tail)))) parallel_k97_3 (parallel_b112 ++ (125 :: tail)) tail parallel_r112 (parallel_kp97_3 (parallel_b112 ++ (125 :: tail))) (parallel_p112 (125 :: tail)))
def parallel_l97_2 : List (List Nat × Raw) := (parallel_k97_2, parallel_r111) :: parallel_l97_3
def parallel_v97_2 : List Nat := (parallel_g278 ++ parallel_b111) ++ (44 :: parallel_v97_3)
theorem parallel_sl97_2 : serializeFields 4070 27 parallel_l97_2 = some parallel_v97_2 := by
  simpa only [parallel_l97_2, parallel_v97_2, parallel_k97_2, parallel_g278, parallel_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 parallel_k97_2 parallel_r111 (parallel_k97_3, parallel_r112) [] parallel_b111 parallel_v97_3 parallel_kd97_2 parallel_s111 parallel_sl97_3)
theorem parallel_pl97_2 (tail : List Nat) : parseFields 4070 27 (parallel_v97_2 ++ (125 :: tail)) = some (parallel_l97_2, tail) := by
  simpa only [parallel_l97_2, parallel_v97_2, parallel_k97_2, parallel_g278, parallel_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (parallel_k97_2 ++ (34 :: 58 :: (parallel_b111 ++ (44 :: (parallel_v97_3 ++ (125 :: tail)))))) parallel_k97_2 (parallel_b111 ++ (44 :: (parallel_v97_3 ++ (125 :: tail)))) (parallel_v97_3 ++ (125 :: tail)) tail parallel_r111 parallel_l97_3 (parallel_kp97_2 (parallel_b111 ++ (44 :: (parallel_v97_3 ++ (125 :: tail))))) (parallel_p111 (44 :: (parallel_v97_3 ++ (125 :: tail)))) (parallel_pl97_3 tail))
def parallel_l97_1 : List (List Nat × Raw) := (parallel_k97_1, parallel_r99) :: parallel_l97_2
def parallel_v97_1 : List Nat := (parallel_g253 ++ parallel_b99) ++ (44 :: parallel_v97_2)
theorem parallel_sl97_1 : serializeFields 4071 27 parallel_l97_1 = some parallel_v97_1 := by
  simpa only [parallel_l97_1, parallel_v97_1, parallel_k97_1, parallel_g253, parallel_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 parallel_k97_1 parallel_r99 (parallel_k97_2, parallel_r111) parallel_l97_3 parallel_b99 parallel_v97_2 parallel_kd97_1 parallel_s99 parallel_sl97_2)
theorem parallel_pl97_1 (tail : List Nat) : parseFields 4071 27 (parallel_v97_1 ++ (125 :: tail)) = some (parallel_l97_1, tail) := by
  simpa only [parallel_l97_1, parallel_v97_1, parallel_k97_1, parallel_g253, parallel_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (parallel_k97_1 ++ (34 :: 58 :: (parallel_b99 ++ (44 :: (parallel_v97_2 ++ (125 :: tail)))))) parallel_k97_1 (parallel_b99 ++ (44 :: (parallel_v97_2 ++ (125 :: tail)))) (parallel_v97_2 ++ (125 :: tail)) tail parallel_r99 parallel_l97_2 (parallel_kp97_1 (parallel_b99 ++ (44 :: (parallel_v97_2 ++ (125 :: tail))))) (parallel_p99 (44 :: (parallel_v97_2 ++ (125 :: tail)))) (parallel_pl97_2 tail))
def parallel_l97_0 : List (List Nat × Raw) := (parallel_k97_0, parallel_r98) :: parallel_l97_1
def parallel_v97_0 : List Nat := (parallel_g250 ++ parallel_b98) ++ (44 :: parallel_v97_1)
theorem parallel_sl97_0 : serializeFields 4072 27 parallel_l97_0 = some parallel_v97_0 := by
  simpa only [parallel_l97_0, parallel_v97_0, parallel_k97_0, parallel_g250, parallel_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 parallel_k97_0 parallel_r98 (parallel_k97_1, parallel_r99) parallel_l97_2 parallel_b98 parallel_v97_1 parallel_kd97_0 parallel_s98 parallel_sl97_1)
theorem parallel_pl97_0 (tail : List Nat) : parseFields 4072 27 (parallel_v97_0 ++ (125 :: tail)) = some (parallel_l97_0, tail) := by
  simpa only [parallel_l97_0, parallel_v97_0, parallel_k97_0, parallel_g250, parallel_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (parallel_k97_0 ++ (34 :: 58 :: (parallel_b98 ++ (44 :: (parallel_v97_1 ++ (125 :: tail)))))) parallel_k97_0 (parallel_b98 ++ (44 :: (parallel_v97_1 ++ (125 :: tail)))) (parallel_v97_1 ++ (125 :: tail)) tail parallel_r98 parallel_l97_1 (parallel_kp97_0 (parallel_b98 ++ (44 :: (parallel_v97_1 ++ (125 :: tail))))) (parallel_p98 (44 :: (parallel_v97_1 ++ (125 :: tail)))) (parallel_pl97_1 tail))
def parallel_r97 : Raw := (.obj parallel_l97_0)
def parallel_b97 : List Nat := parallel_g249 ++ (parallel_v97_0 ++ parallel_g283)
theorem parallel_o97 : orderedFields parallel_l97_0 = true := by decide +kernel
theorem parallel_s97 : serializeRaw 4073 28 parallel_r97 = some parallel_b97 := by
  simpa only [parallel_r97, parallel_b97, parallel_g249, parallel_g283, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4072 27 parallel_l97_0 parallel_v97_0 parallel_o97 parallel_sl97_0)
theorem parallel_p97 (tail : List Nat) : parseRaw 4073 28 (parallel_b97 ++ tail) = some (parallel_r97, tail) := by
  simpa only [parallel_r97, parallel_b97, parallel_g249, parallel_g283, parallel_v97_0, parallel_k97_0, parallel_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4072 27 (parallel_k97_0 ++ (34 :: 58 :: (parallel_b98 ++ (44 :: (parallel_v97_1 ++ (125 :: tail)))))) tail parallel_l97_0 parallel_o97 (by simpa only [parallel_v97_0, parallel_k97_0, parallel_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl97_0 tail)))
def parallel_r114 : Raw := (.str [100,103,95,115,108,111,119,95,50])
def parallel_b114 : List Nat := parallel_g287
theorem parallel_s114 : serializeRaw 4070 27 parallel_r114 = some parallel_b114 := by decide +kernel
theorem parallel_p114 (tail : List Nat) : parseRaw 4070 27 (parallel_b114 ++ tail) = some (parallel_r114, tail) := by rfl
def parallel_r115 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,57])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def parallel_b115 : List Nat := parallel_g290
theorem parallel_s115 : serializeRaw 4069 27 parallel_r115 = some parallel_b115 := by decide +kernel
theorem parallel_p115 (tail : List Nat) : parseRaw 4069 27 (parallel_b115 ++ tail) = some (parallel_r115, tail) := by rfl
def parallel_r116 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b116 : List Nat := parallel_g293
theorem parallel_s116 : serializeRaw 4068 27 parallel_r116 = some parallel_b116 := by decide +kernel
theorem parallel_p116 (tail : List Nat) : parseRaw 4068 27 (parallel_b116 ++ tail) = some (parallel_r116, tail) := by rfl
def parallel_r117 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,50,53]),(.str [100,103,95,118,95,49,50,54]),(.str [100,103,95,118,95,49,50,57]),(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,51,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def parallel_b117 : List Nat := parallel_g296
theorem parallel_s117 : serializeRaw 4067 27 parallel_r117 = some parallel_b117 := by decide +kernel
theorem parallel_p117 (tail : List Nat) : parseRaw 4067 27 (parallel_b117 ++ tail) = some (parallel_r117, tail) := by rfl
def parallel_k113_0 : List Nat := [105,100]
theorem parallel_kd113_0 : stringBytes parallel_k113_0 = true := by decide +kernel
theorem parallel_kp113_0 (tail : List Nat) : parseStringTail (parallel_k113_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k113_0, 58 :: tail) := by rfl
def parallel_k113_1 : List Nat := [111,112,115]
theorem parallel_kd113_1 : stringBytes parallel_k113_1 = true := by decide +kernel
theorem parallel_kp113_1 (tail : List Nat) : parseStringTail (parallel_k113_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k113_1, 58 :: tail) := by rfl
def parallel_k113_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd113_2 : stringBytes parallel_k113_2 = true := by decide +kernel
theorem parallel_kp113_2 (tail : List Nat) : parseStringTail (parallel_k113_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k113_2, 58 :: tail) := by rfl
def parallel_k113_3 : List Nat := [116,101,114,109]
theorem parallel_kd113_3 : stringBytes parallel_k113_3 = true := by decide +kernel
theorem parallel_kp113_3 (tail : List Nat) : parseStringTail (parallel_k113_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k113_3, 58 :: tail) := by rfl
def parallel_l113_3 : List (List Nat × Raw) := [(parallel_k113_3, parallel_r117)]
def parallel_v113_3 : List Nat := parallel_g295 ++ parallel_b117
theorem parallel_sl113_3 : serializeFields 4068 27 parallel_l113_3 = some parallel_v113_3 := by
  simpa only [parallel_l113_3, parallel_v113_3, parallel_k113_3, parallel_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4067 27 parallel_k113_3 parallel_r117 parallel_b117 parallel_kd113_3 parallel_s117)
theorem parallel_pl113_3 (tail : List Nat) : parseFields 4068 27 (parallel_v113_3 ++ (125 :: tail)) = some (parallel_l113_3, tail) := by
  simpa only [parallel_l113_3, parallel_v113_3, parallel_k113_3, parallel_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4067 27 (parallel_k113_3 ++ (34 :: 58 :: (parallel_b117 ++ (125 :: tail)))) parallel_k113_3 (parallel_b117 ++ (125 :: tail)) tail parallel_r117 (parallel_kp113_3 (parallel_b117 ++ (125 :: tail))) (parallel_p117 (125 :: tail)))
def parallel_l113_2 : List (List Nat × Raw) := (parallel_k113_2, parallel_r116) :: parallel_l113_3
def parallel_v113_2 : List Nat := (parallel_g292 ++ parallel_b116) ++ (44 :: parallel_v113_3)
theorem parallel_sl113_2 : serializeFields 4069 27 parallel_l113_2 = some parallel_v113_2 := by
  simpa only [parallel_l113_2, parallel_v113_2, parallel_k113_2, parallel_g292, parallel_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 parallel_k113_2 parallel_r116 (parallel_k113_3, parallel_r117) [] parallel_b116 parallel_v113_3 parallel_kd113_2 parallel_s116 parallel_sl113_3)
theorem parallel_pl113_2 (tail : List Nat) : parseFields 4069 27 (parallel_v113_2 ++ (125 :: tail)) = some (parallel_l113_2, tail) := by
  simpa only [parallel_l113_2, parallel_v113_2, parallel_k113_2, parallel_g292, parallel_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (parallel_k113_2 ++ (34 :: 58 :: (parallel_b116 ++ (44 :: (parallel_v113_3 ++ (125 :: tail)))))) parallel_k113_2 (parallel_b116 ++ (44 :: (parallel_v113_3 ++ (125 :: tail)))) (parallel_v113_3 ++ (125 :: tail)) tail parallel_r116 parallel_l113_3 (parallel_kp113_2 (parallel_b116 ++ (44 :: (parallel_v113_3 ++ (125 :: tail))))) (parallel_p116 (44 :: (parallel_v113_3 ++ (125 :: tail)))) (parallel_pl113_3 tail))
def parallel_l113_1 : List (List Nat × Raw) := (parallel_k113_1, parallel_r115) :: parallel_l113_2
def parallel_v113_1 : List Nat := (parallel_g289 ++ parallel_b115) ++ (44 :: parallel_v113_2)
theorem parallel_sl113_1 : serializeFields 4070 27 parallel_l113_1 = some parallel_v113_1 := by
  simpa only [parallel_l113_1, parallel_v113_1, parallel_k113_1, parallel_g289, parallel_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 parallel_k113_1 parallel_r115 (parallel_k113_2, parallel_r116) parallel_l113_3 parallel_b115 parallel_v113_2 parallel_kd113_1 parallel_s115 parallel_sl113_2)
theorem parallel_pl113_1 (tail : List Nat) : parseFields 4070 27 (parallel_v113_1 ++ (125 :: tail)) = some (parallel_l113_1, tail) := by
  simpa only [parallel_l113_1, parallel_v113_1, parallel_k113_1, parallel_g289, parallel_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (parallel_k113_1 ++ (34 :: 58 :: (parallel_b115 ++ (44 :: (parallel_v113_2 ++ (125 :: tail)))))) parallel_k113_1 (parallel_b115 ++ (44 :: (parallel_v113_2 ++ (125 :: tail)))) (parallel_v113_2 ++ (125 :: tail)) tail parallel_r115 parallel_l113_2 (parallel_kp113_1 (parallel_b115 ++ (44 :: (parallel_v113_2 ++ (125 :: tail))))) (parallel_p115 (44 :: (parallel_v113_2 ++ (125 :: tail)))) (parallel_pl113_2 tail))
def parallel_l113_0 : List (List Nat × Raw) := (parallel_k113_0, parallel_r114) :: parallel_l113_1
def parallel_v113_0 : List Nat := (parallel_g286 ++ parallel_b114) ++ (44 :: parallel_v113_1)
theorem parallel_sl113_0 : serializeFields 4071 27 parallel_l113_0 = some parallel_v113_0 := by
  simpa only [parallel_l113_0, parallel_v113_0, parallel_k113_0, parallel_g286, parallel_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 parallel_k113_0 parallel_r114 (parallel_k113_1, parallel_r115) parallel_l113_2 parallel_b114 parallel_v113_1 parallel_kd113_0 parallel_s114 parallel_sl113_1)
theorem parallel_pl113_0 (tail : List Nat) : parseFields 4071 27 (parallel_v113_0 ++ (125 :: tail)) = some (parallel_l113_0, tail) := by
  simpa only [parallel_l113_0, parallel_v113_0, parallel_k113_0, parallel_g286, parallel_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (parallel_k113_0 ++ (34 :: 58 :: (parallel_b114 ++ (44 :: (parallel_v113_1 ++ (125 :: tail)))))) parallel_k113_0 (parallel_b114 ++ (44 :: (parallel_v113_1 ++ (125 :: tail)))) (parallel_v113_1 ++ (125 :: tail)) tail parallel_r114 parallel_l113_1 (parallel_kp113_0 (parallel_b114 ++ (44 :: (parallel_v113_1 ++ (125 :: tail))))) (parallel_p114 (44 :: (parallel_v113_1 ++ (125 :: tail)))) (parallel_pl113_1 tail))
theorem parallel_bf0000 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g0 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0001 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g1 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0002 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g2 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0003 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g4 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0004 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g5 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0005 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g6 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0006 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g7 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0007 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g8 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0008 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g9 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0009 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g10 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0010 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g11 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0011 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g13 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0012 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g14 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0013 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g16 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0014 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g17 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0015 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g19 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0016 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g20 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0017 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g21 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0018 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g23 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0019 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g24 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0020 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g25 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0021 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g27 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0022 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g28 178 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0023 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g30 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0024 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g31 195 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0025 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g33 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0026 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g34 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0027 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g35 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0028 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g37 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0029 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g38 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0030 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g39 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0031 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g41 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0032 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g42 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0033 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g43 58 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0034 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g45 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0035 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g47 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0036 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g49 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0037 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g50 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0038 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g52 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0039 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g53 200 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0040 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g55 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0041 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g56 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0042 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g57 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0043 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g59 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0044 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g60 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0045 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g61 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0046 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g63 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0047 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g64 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0048 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g66 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0049 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g67 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0050 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g69 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0051 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g70 233 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0052 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g71 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0053 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g73 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0054 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g74 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0055 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g75 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0056 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g77 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0057 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g78 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0058 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g80 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0059 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g81 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0060 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g83 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0061 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g84 115 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0062 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g85 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0063 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g87 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0064 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g88 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0065 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g89 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0066 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g91 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0067 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g92 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0068 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g94 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0069 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g95 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0070 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g97 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0071 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g98 253 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0072 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g99 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0073 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g101 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0074 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g102 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0075 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g103 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0076 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g105 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0077 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g106 153 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0078 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g108 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0079 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g109 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0080 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g111 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0081 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g112 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0082 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g113 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0083 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g115 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0084 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g116 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0085 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g117 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0086 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g119 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0087 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g120 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0088 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g122 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0089 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g123 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0090 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g125 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0091 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g126 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0092 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g127 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0093 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g129 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0094 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g130 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0095 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g131 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0096 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g133 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0097 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g134 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0098 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g135 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0099 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g137 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0100 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g139 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0101 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g141 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0102 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g143 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0103 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g145 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0104 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g147 92 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0105 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g149 80 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0106 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g151 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0107 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g153 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0108 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g155 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0109 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g156 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0110 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g158 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0111 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g159 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0112 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g161 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0113 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g162 93 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0114 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g163 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0115 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g165 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0116 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g166 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0117 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g167 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0118 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g169 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0119 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g170 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0120 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g172 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0121 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g173 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0122 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g175 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0123 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g176 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0124 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g177 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0125 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g179 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0126 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g180 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0127 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g181 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0128 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g183 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0129 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g184 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0130 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g186 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0131 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g187 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0132 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g189 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0133 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g190 230 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0134 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g191 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0135 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g193 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0136 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g194 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0137 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g195 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0138 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g197 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0139 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g198 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0140 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g199 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0141 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g201 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0142 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g203 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0143 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g205 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0144 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g207 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0145 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g209 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0146 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g211 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0147 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g212 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0148 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g214 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0149 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g215 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0150 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g217 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0151 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g218 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0152 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g219 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0153 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g221 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0154 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g222 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0155 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g223 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0156 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g225 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0157 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g226 155 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0158 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g228 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0159 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g229 205 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0160 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g231 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0161 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g232 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0162 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g233 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0163 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g235 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0164 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g236 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0165 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g237 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0166 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g239 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0167 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g240 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0168 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g242 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0169 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g243 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0170 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g245 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0171 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g246 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0172 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g247 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0173 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g249 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0174 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g250 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0175 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g251 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0176 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g253 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0177 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g254 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0178 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g255 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0179 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g257 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0180 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g259 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0181 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g261 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0182 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g263 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0183 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g265 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0184 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g267 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0185 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g269 83 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0186 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g271 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0187 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g273 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0188 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g275 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0189 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g276 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0190 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g278 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0191 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g279 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0192 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g281 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0193 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g282 98 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0194 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g283 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0195 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g285 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0196 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g286 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0197 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g287 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0198 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g289 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0199 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g290 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0200 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g292 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0201 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g293 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0202 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g295 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0203 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g296 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0204 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g297 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0205 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g299 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0206 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g300 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0207 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g301 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0208 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g303 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0209 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g304 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0210 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g306 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0211 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g307 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0212 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g309 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0213 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g310 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0214 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g311 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0215 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g313 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0216 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g314 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0217 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g315 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0218 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g317 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0219 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g318 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0220 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g319 96 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0221 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g321 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0222 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g323 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0223 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g325 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0224 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g327 107 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0225 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g329 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0226 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g331 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0227 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g332 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0228 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g334 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0229 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g335 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0230 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g337 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0231 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g338 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0232 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g339 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0233 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g341 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0234 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g342 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0235 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g343 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0236 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g345 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0237 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g346 156 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0238 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g348 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0239 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g349 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0240 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g351 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0241 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g352 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0242 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g353 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0243 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g355 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0244 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g356 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0245 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g357 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0246 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g359 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0247 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g360 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0248 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g362 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0249 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g363 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0250 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g365 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0251 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g366 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0252 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g367 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0253 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g369 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0254 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g370 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0255 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g371 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0256 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g373 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0257 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g374 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0258 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g376 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0259 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g377 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0260 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g379 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0261 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g380 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0262 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g381 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0263 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g382 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0264 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g384 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0265 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g385 31 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0266 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g387 8 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0267 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g388 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0268 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g390 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0269 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g391 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0270 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g393 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0271 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g394 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0272 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g396 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0273 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g397 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0274 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g398 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0275 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g399 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0276 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g401 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0277 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g402 18 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0278 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g404 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0279 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g405 22 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0280 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_g406 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem parallel_bf0281 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b1 13 := by
  simpa only [parallel_b1] using parallel_bf0002
theorem parallel_bf0282 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b6 13 := by
  simpa only [parallel_b6] using parallel_bf0010
theorem parallel_bf0283 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b7 209 := by
  simpa only [parallel_b7] using parallel_bf0012
theorem parallel_bf0284 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b8 61 := by
  simpa only [parallel_b8] using parallel_bf0014
theorem parallel_bf0285 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b9 209 := by
  simpa only [parallel_b9] using parallel_bf0016
theorem parallel_bf0286 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v5_3 216 := by
  simpa only [parallel_v5_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g19 parallel_b9 7 209 parallel_bf0015 parallel_bf0285)
theorem parallel_bf0287 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v5_2 287 := by
  simpa only [parallel_v5_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g16 ++ parallel_b8) (44 :: parallel_v5_3) 70 217 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g16 parallel_b8 9 61 parallel_bf0013 parallel_bf0284) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v5_3 216 (by decide +kernel) parallel_bf0286))
theorem parallel_bf0288 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v5_1 503 := by
  simpa only [parallel_v5_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g13 ++ parallel_b7) (44 :: parallel_v5_2) 215 288 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g13 parallel_b7 6 209 parallel_bf0011 parallel_bf0283) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v5_2 287 (by decide +kernel) parallel_bf0287))
theorem parallel_bf0289 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v5_0 522 := by
  simpa only [parallel_v5_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g10 ++ parallel_b6) (44 :: parallel_v5_1) 18 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g10 parallel_b6 5 13 parallel_bf0009 parallel_bf0282) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v5_1 503 (by decide +kernel) parallel_bf0288))
theorem parallel_bf0290 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b5 524 := by
  simpa only [parallel_b5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g9 (parallel_v5_0 ++ parallel_g21) 1 523 parallel_bf0008 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v5_0 parallel_g21 522 1 parallel_bf0289 parallel_bf0017))
theorem parallel_bf0291 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b11 13 := by
  simpa only [parallel_b11] using parallel_bf0020
theorem parallel_bf0292 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b12 178 := by
  simpa only [parallel_b12] using parallel_bf0022
theorem parallel_bf0293 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b13 195 := by
  simpa only [parallel_b13] using parallel_bf0024
theorem parallel_bf0294 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b14 100 := by
  simpa only [parallel_b14] using parallel_bf0026
theorem parallel_bf0295 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v10_3 107 := by
  simpa only [parallel_v10_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g33 parallel_b14 7 100 parallel_bf0025 parallel_bf0294)
theorem parallel_bf0296 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v10_2 312 := by
  simpa only [parallel_v10_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g30 ++ parallel_b13) (44 :: parallel_v10_3) 204 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g30 parallel_b13 9 195 parallel_bf0023 parallel_bf0293) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v10_3 107 (by decide +kernel) parallel_bf0295))
theorem parallel_bf0297 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v10_1 497 := by
  simpa only [parallel_v10_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g27 ++ parallel_b12) (44 :: parallel_v10_2) 184 313 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g27 parallel_b12 6 178 parallel_bf0021 parallel_bf0292) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v10_2 312 (by decide +kernel) parallel_bf0296))
theorem parallel_bf0298 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v10_0 516 := by
  simpa only [parallel_v10_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g24 ++ parallel_b11) (44 :: parallel_v10_1) 18 498 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g24 parallel_b11 5 13 parallel_bf0019 parallel_bf0291) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v10_1 497 (by decide +kernel) parallel_bf0297))
theorem parallel_bf0299 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b10 518 := by
  simpa only [parallel_b10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g23 (parallel_v10_0 ++ parallel_g35) 1 517 parallel_bf0018 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v10_0 parallel_g35 516 1 parallel_bf0298 parallel_bf0027))
theorem parallel_bf0300 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b16 13 := by
  simpa only [parallel_b16] using parallel_bf0030
theorem parallel_bf0301 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b18 58 := by
  simpa only [parallel_b18] using parallel_bf0033
theorem parallel_bf0302 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b19 87 := by
  simpa only [parallel_b19] using parallel_bf0034
theorem parallel_bf0303 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b20 100 := by
  simpa only [parallel_b20] using parallel_bf0035
theorem parallel_bf0304 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b21 104 := by
  simpa only [parallel_b21] using parallel_bf0036
theorem parallel_bf0305 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v17_3 104 := by
  simpa only [parallel_v17_3] using parallel_bf0304
theorem parallel_bf0306 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v17_2 205 := by
  simpa only [parallel_v17_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b20 (44 :: parallel_v17_3) 100 105 parallel_bf0303 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v17_3 104 (by decide +kernel) parallel_bf0305))
theorem parallel_bf0307 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v17_1 293 := by
  simpa only [parallel_v17_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b19 (44 :: parallel_v17_2) 87 206 parallel_bf0302 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v17_2 205 (by decide +kernel) parallel_bf0306))
theorem parallel_bf0308 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v17_0 352 := by
  simpa only [parallel_v17_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b18 (44 :: parallel_v17_1) 58 294 parallel_bf0301 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v17_1 293 (by decide +kernel) parallel_bf0307))
theorem parallel_bf0309 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b17 354 := by
  simpa only [parallel_b17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g42 (parallel_v17_0 ++ parallel_g50) 1 353 parallel_bf0032 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v17_0 parallel_g50 352 1 parallel_bf0308 parallel_bf0037))
theorem parallel_bf0310 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b22 200 := by
  simpa only [parallel_b22] using parallel_bf0039
theorem parallel_bf0311 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b23 33 := by
  simpa only [parallel_b23] using parallel_bf0041
theorem parallel_bf0312 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v15_3 40 := by
  simpa only [parallel_v15_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g55 parallel_b23 7 33 parallel_bf0040 parallel_bf0311)
theorem parallel_bf0313 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v15_2 250 := by
  simpa only [parallel_v15_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g52 ++ parallel_b22) (44 :: parallel_v15_3) 209 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g52 parallel_b22 9 200 parallel_bf0038 parallel_bf0310) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v15_3 40 (by decide +kernel) parallel_bf0312))
theorem parallel_bf0314 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v15_1 611 := by
  simpa only [parallel_v15_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g41 ++ parallel_b17) (44 :: parallel_v15_2) 360 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g41 parallel_b17 6 354 parallel_bf0031 parallel_bf0309) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v15_2 250 (by decide +kernel) parallel_bf0313))
theorem parallel_bf0315 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v15_0 630 := by
  simpa only [parallel_v15_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g38 ++ parallel_b16) (44 :: parallel_v15_1) 18 612 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g38 parallel_b16 5 13 parallel_bf0029 parallel_bf0300) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v15_1 611 (by decide +kernel) parallel_bf0314))
theorem parallel_bf0316 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b15 632 := by
  simpa only [parallel_b15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g37 (parallel_v15_0 ++ parallel_g57) 1 631 parallel_bf0028 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v15_0 parallel_g57 630 1 parallel_bf0315 parallel_bf0042))
theorem parallel_bf0317 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b25 13 := by
  simpa only [parallel_b25] using parallel_bf0045
theorem parallel_bf0318 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b26 102 := by
  simpa only [parallel_b26] using parallel_bf0047
theorem parallel_bf0319 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b27 204 := by
  simpa only [parallel_b27] using parallel_bf0049
theorem parallel_bf0320 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b28 233 := by
  simpa only [parallel_b28] using parallel_bf0051
theorem parallel_bf0321 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v24_3 240 := by
  simpa only [parallel_v24_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g69 parallel_b28 7 233 parallel_bf0050 parallel_bf0320)
theorem parallel_bf0322 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v24_2 454 := by
  simpa only [parallel_v24_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g66 ++ parallel_b27) (44 :: parallel_v24_3) 213 241 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g66 parallel_b27 9 204 parallel_bf0048 parallel_bf0319) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v24_3 240 (by decide +kernel) parallel_bf0321))
theorem parallel_bf0323 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v24_1 563 := by
  simpa only [parallel_v24_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g63 ++ parallel_b26) (44 :: parallel_v24_2) 108 455 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g63 parallel_b26 6 102 parallel_bf0046 parallel_bf0318) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v24_2 454 (by decide +kernel) parallel_bf0322))
theorem parallel_bf0324 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v24_0 582 := by
  simpa only [parallel_v24_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g60 ++ parallel_b25) (44 :: parallel_v24_1) 18 564 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g60 parallel_b25 5 13 parallel_bf0044 parallel_bf0317) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v24_1 563 (by decide +kernel) parallel_bf0323))
theorem parallel_bf0325 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b24 584 := by
  simpa only [parallel_b24] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g59 (parallel_v24_0 ++ parallel_g71) 1 583 parallel_bf0043 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v24_0 parallel_g71 582 1 parallel_bf0324 parallel_bf0052))
theorem parallel_bf0326 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b30 13 := by
  simpa only [parallel_b30] using parallel_bf0055
theorem parallel_bf0327 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b31 173 := by
  simpa only [parallel_b31] using parallel_bf0057
theorem parallel_bf0328 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b32 204 := by
  simpa only [parallel_b32] using parallel_bf0059
theorem parallel_bf0329 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b33 115 := by
  simpa only [parallel_b33] using parallel_bf0061
theorem parallel_bf0330 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v29_3 122 := by
  simpa only [parallel_v29_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g83 parallel_b33 7 115 parallel_bf0060 parallel_bf0329)
theorem parallel_bf0331 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v29_2 336 := by
  simpa only [parallel_v29_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g80 ++ parallel_b32) (44 :: parallel_v29_3) 213 123 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g80 parallel_b32 9 204 parallel_bf0058 parallel_bf0328) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v29_3 122 (by decide +kernel) parallel_bf0330))
theorem parallel_bf0332 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v29_1 516 := by
  simpa only [parallel_v29_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g77 ++ parallel_b31) (44 :: parallel_v29_2) 179 337 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g77 parallel_b31 6 173 parallel_bf0056 parallel_bf0327) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v29_2 336 (by decide +kernel) parallel_bf0331))
theorem parallel_bf0333 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v29_0 535 := by
  simpa only [parallel_v29_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g74 ++ parallel_b30) (44 :: parallel_v29_1) 18 517 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g74 parallel_b30 5 13 parallel_bf0054 parallel_bf0326) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v29_1 516 (by decide +kernel) parallel_bf0332))
theorem parallel_bf0334 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b29 537 := by
  simpa only [parallel_b29] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g73 (parallel_v29_0 ++ parallel_g85) 1 536 parallel_bf0053 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v29_0 parallel_g85 535 1 parallel_bf0333 parallel_bf0062))
theorem parallel_bf0335 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b35 13 := by
  simpa only [parallel_b35] using parallel_bf0065
theorem parallel_bf0336 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b36 102 := by
  simpa only [parallel_b36] using parallel_bf0067
theorem parallel_bf0337 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b37 236 := by
  simpa only [parallel_b37] using parallel_bf0069
theorem parallel_bf0338 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b38 253 := by
  simpa only [parallel_b38] using parallel_bf0071
theorem parallel_bf0339 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v34_3 260 := by
  simpa only [parallel_v34_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g97 parallel_b38 7 253 parallel_bf0070 parallel_bf0338)
theorem parallel_bf0340 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v34_2 506 := by
  simpa only [parallel_v34_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g94 ++ parallel_b37) (44 :: parallel_v34_3) 245 261 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g94 parallel_b37 9 236 parallel_bf0068 parallel_bf0337) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v34_3 260 (by decide +kernel) parallel_bf0339))
theorem parallel_bf0341 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v34_1 615 := by
  simpa only [parallel_v34_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g91 ++ parallel_b36) (44 :: parallel_v34_2) 108 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g91 parallel_b36 6 102 parallel_bf0066 parallel_bf0336) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v34_2 506 (by decide +kernel) parallel_bf0340))
theorem parallel_bf0342 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v34_0 634 := by
  simpa only [parallel_v34_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g88 ++ parallel_b35) (44 :: parallel_v34_1) 18 616 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g88 parallel_b35 5 13 parallel_bf0064 parallel_bf0335) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v34_1 615 (by decide +kernel) parallel_bf0341))
theorem parallel_bf0343 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b34 636 := by
  simpa only [parallel_b34] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g87 (parallel_v34_0 ++ parallel_g99) 1 635 parallel_bf0063 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v34_0 parallel_g99 634 1 parallel_bf0342 parallel_bf0072))
theorem parallel_bf0344 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b40 13 := by
  simpa only [parallel_b40] using parallel_bf0075
theorem parallel_bf0345 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b41 153 := by
  simpa only [parallel_b41] using parallel_bf0077
theorem parallel_bf0346 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b42 236 := by
  simpa only [parallel_b42] using parallel_bf0079
theorem parallel_bf0347 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b43 33 := by
  simpa only [parallel_b43] using parallel_bf0081
theorem parallel_bf0348 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v39_3 40 := by
  simpa only [parallel_v39_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g111 parallel_b43 7 33 parallel_bf0080 parallel_bf0347)
theorem parallel_bf0349 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v39_2 286 := by
  simpa only [parallel_v39_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g108 ++ parallel_b42) (44 :: parallel_v39_3) 245 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g108 parallel_b42 9 236 parallel_bf0078 parallel_bf0346) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v39_3 40 (by decide +kernel) parallel_bf0348))
theorem parallel_bf0350 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v39_1 446 := by
  simpa only [parallel_v39_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g105 ++ parallel_b41) (44 :: parallel_v39_2) 159 287 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g105 parallel_b41 6 153 parallel_bf0076 parallel_bf0345) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v39_2 286 (by decide +kernel) parallel_bf0349))
theorem parallel_bf0351 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v39_0 465 := by
  simpa only [parallel_v39_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g102 ++ parallel_b40) (44 :: parallel_v39_1) 18 447 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g102 parallel_b40 5 13 parallel_bf0074 parallel_bf0344) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v39_1 446 (by decide +kernel) parallel_bf0350))
theorem parallel_bf0352 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b39 467 := by
  simpa only [parallel_b39] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g101 (parallel_v39_0 ++ parallel_g113) 1 466 parallel_bf0073 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v39_0 parallel_g113 465 1 parallel_bf0351 parallel_bf0082))
theorem parallel_bf0353 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b45 11 := by
  simpa only [parallel_b45] using parallel_bf0085
theorem parallel_bf0354 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b46 102 := by
  simpa only [parallel_b46] using parallel_bf0087
theorem parallel_bf0355 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b47 170 := by
  simpa only [parallel_b47] using parallel_bf0089
theorem parallel_bf0356 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b48 210 := by
  simpa only [parallel_b48] using parallel_bf0091
theorem parallel_bf0357 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v44_3 217 := by
  simpa only [parallel_v44_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g125 parallel_b48 7 210 parallel_bf0090 parallel_bf0356)
theorem parallel_bf0358 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v44_2 397 := by
  simpa only [parallel_v44_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g122 ++ parallel_b47) (44 :: parallel_v44_3) 179 218 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g122 parallel_b47 9 170 parallel_bf0088 parallel_bf0355) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v44_3 217 (by decide +kernel) parallel_bf0357))
theorem parallel_bf0359 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v44_1 506 := by
  simpa only [parallel_v44_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g119 ++ parallel_b46) (44 :: parallel_v44_2) 108 398 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g119 parallel_b46 6 102 parallel_bf0086 parallel_bf0354) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v44_2 397 (by decide +kernel) parallel_bf0358))
theorem parallel_bf0360 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v44_0 523 := by
  simpa only [parallel_v44_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g116 ++ parallel_b45) (44 :: parallel_v44_1) 16 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g116 parallel_b45 5 11 parallel_bf0084 parallel_bf0353) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v44_1 506 (by decide +kernel) parallel_bf0359))
theorem parallel_bf0361 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b44 525 := by
  simpa only [parallel_b44] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g115 (parallel_v44_0 ++ parallel_g127) 1 524 parallel_bf0083 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v44_0 parallel_g127 523 1 parallel_bf0360 parallel_bf0092))
theorem parallel_bf0362 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b50 11 := by
  simpa only [parallel_b50] using parallel_bf0095
theorem parallel_bf0363 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b52 100 := by
  simpa only [parallel_b52] using parallel_bf0098
theorem parallel_bf0364 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b53 101 := by
  simpa only [parallel_b53] using parallel_bf0099
theorem parallel_bf0365 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b54 99 := by
  simpa only [parallel_b54] using parallel_bf0100
theorem parallel_bf0366 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b55 99 := by
  simpa only [parallel_b55] using parallel_bf0101
theorem parallel_bf0367 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b56 100 := by
  simpa only [parallel_b56] using parallel_bf0102
theorem parallel_bf0368 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b57 99 := by
  simpa only [parallel_b57] using parallel_bf0103
theorem parallel_bf0369 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b58 92 := by
  simpa only [parallel_b58] using parallel_bf0104
theorem parallel_bf0370 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b59 80 := by
  simpa only [parallel_b59] using parallel_bf0105
theorem parallel_bf0371 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b60 56 := by
  simpa only [parallel_b60] using parallel_bf0106
theorem parallel_bf0372 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b61 86 := by
  simpa only [parallel_b61] using parallel_bf0107
theorem parallel_bf0373 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b62 103 := by
  simpa only [parallel_b62] using parallel_bf0108
theorem parallel_bf0374 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_10 103 := by
  simpa only [parallel_v51_10] using parallel_bf0373
theorem parallel_bf0375 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_9 190 := by
  simpa only [parallel_v51_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b61 (44 :: parallel_v51_10) 86 104 parallel_bf0372 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_10 103 (by decide +kernel) parallel_bf0374))
theorem parallel_bf0376 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_8 247 := by
  simpa only [parallel_v51_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b60 (44 :: parallel_v51_9) 56 191 parallel_bf0371 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_9 190 (by decide +kernel) parallel_bf0375))
theorem parallel_bf0377 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_7 328 := by
  simpa only [parallel_v51_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b59 (44 :: parallel_v51_8) 80 248 parallel_bf0370 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_8 247 (by decide +kernel) parallel_bf0376))
theorem parallel_bf0378 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_6 421 := by
  simpa only [parallel_v51_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b58 (44 :: parallel_v51_7) 92 329 parallel_bf0369 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_7 328 (by decide +kernel) parallel_bf0377))
theorem parallel_bf0379 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_5 521 := by
  simpa only [parallel_v51_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b57 (44 :: parallel_v51_6) 99 422 parallel_bf0368 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_6 421 (by decide +kernel) parallel_bf0378))
theorem parallel_bf0380 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_4 622 := by
  simpa only [parallel_v51_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b56 (44 :: parallel_v51_5) 100 522 parallel_bf0367 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_5 521 (by decide +kernel) parallel_bf0379))
theorem parallel_bf0381 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_3 722 := by
  simpa only [parallel_v51_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b55 (44 :: parallel_v51_4) 99 623 parallel_bf0366 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_4 622 (by decide +kernel) parallel_bf0380))
theorem parallel_bf0382 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_2 822 := by
  simpa only [parallel_v51_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b54 (44 :: parallel_v51_3) 99 723 parallel_bf0365 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_3 722 (by decide +kernel) parallel_bf0381))
theorem parallel_bf0383 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_1 924 := by
  simpa only [parallel_v51_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b53 (44 :: parallel_v51_2) 101 823 parallel_bf0364 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_2 822 (by decide +kernel) parallel_bf0382))
theorem parallel_bf0384 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v51_0 1025 := by
  simpa only [parallel_v51_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b52 (44 :: parallel_v51_1) 100 925 parallel_bf0363 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v51_1 924 (by decide +kernel) parallel_bf0383))
theorem parallel_bf0385 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b51 1027 := by
  simpa only [parallel_b51] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g134 (parallel_v51_0 ++ parallel_g156) 1 1026 parallel_bf0097 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v51_0 parallel_g156 1025 1 parallel_bf0384 parallel_bf0109))
theorem parallel_bf0386 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b63 170 := by
  simpa only [parallel_b63] using parallel_bf0111
theorem parallel_bf0387 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b64 93 := by
  simpa only [parallel_b64] using parallel_bf0113
theorem parallel_bf0388 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v49_3 100 := by
  simpa only [parallel_v49_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g161 parallel_b64 7 93 parallel_bf0112 parallel_bf0387)
theorem parallel_bf0389 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v49_2 280 := by
  simpa only [parallel_v49_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g158 ++ parallel_b63) (44 :: parallel_v49_3) 179 101 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g158 parallel_b63 9 170 parallel_bf0110 parallel_bf0386) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v49_3 100 (by decide +kernel) parallel_bf0388))
theorem parallel_bf0390 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v49_1 1314 := by
  simpa only [parallel_v49_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g133 ++ parallel_b51) (44 :: parallel_v49_2) 1033 281 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g133 parallel_b51 6 1027 parallel_bf0096 parallel_bf0385) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v49_2 280 (by decide +kernel) parallel_bf0389))
theorem parallel_bf0391 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v49_0 1331 := by
  simpa only [parallel_v49_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g130 ++ parallel_b50) (44 :: parallel_v49_1) 16 1315 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g130 parallel_b50 5 11 parallel_bf0094 parallel_bf0362) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v49_1 1314 (by decide +kernel) parallel_bf0390))
theorem parallel_bf0392 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b49 1333 := by
  simpa only [parallel_b49] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g129 (parallel_v49_0 ++ parallel_g163) 1 1332 parallel_bf0093 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v49_0 parallel_g163 1331 1 parallel_bf0391 parallel_bf0114))
theorem parallel_bf0393 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b66 11 := by
  simpa only [parallel_b66] using parallel_bf0117
theorem parallel_bf0394 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b67 173 := by
  simpa only [parallel_b67] using parallel_bf0119
theorem parallel_bf0395 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b68 170 := by
  simpa only [parallel_b68] using parallel_bf0121
theorem parallel_bf0396 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b69 103 := by
  simpa only [parallel_b69] using parallel_bf0123
theorem parallel_bf0397 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v65_3 110 := by
  simpa only [parallel_v65_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g175 parallel_b69 7 103 parallel_bf0122 parallel_bf0396)
theorem parallel_bf0398 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v65_2 290 := by
  simpa only [parallel_v65_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g172 ++ parallel_b68) (44 :: parallel_v65_3) 179 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g172 parallel_b68 9 170 parallel_bf0120 parallel_bf0395) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v65_3 110 (by decide +kernel) parallel_bf0397))
theorem parallel_bf0399 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v65_1 470 := by
  simpa only [parallel_v65_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g169 ++ parallel_b67) (44 :: parallel_v65_2) 179 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g169 parallel_b67 6 173 parallel_bf0118 parallel_bf0394) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v65_2 290 (by decide +kernel) parallel_bf0398))
theorem parallel_bf0400 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v65_0 487 := by
  simpa only [parallel_v65_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g166 ++ parallel_b66) (44 :: parallel_v65_1) 16 471 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g166 parallel_b66 5 11 parallel_bf0116 parallel_bf0393) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v65_1 470 (by decide +kernel) parallel_bf0399))
theorem parallel_bf0401 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b65 489 := by
  simpa only [parallel_b65] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g165 (parallel_v65_0 ++ parallel_g177) 1 488 parallel_bf0115 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v65_0 parallel_g177 487 1 parallel_bf0400 parallel_bf0124))
theorem parallel_bf0402 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b71 11 := by
  simpa only [parallel_b71] using parallel_bf0127
theorem parallel_bf0403 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b72 102 := by
  simpa only [parallel_b72] using parallel_bf0129
theorem parallel_bf0404 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b73 202 := by
  simpa only [parallel_b73] using parallel_bf0131
theorem parallel_bf0405 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b74 230 := by
  simpa only [parallel_b74] using parallel_bf0133
theorem parallel_bf0406 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v70_3 237 := by
  simpa only [parallel_v70_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g189 parallel_b74 7 230 parallel_bf0132 parallel_bf0405)
theorem parallel_bf0407 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v70_2 449 := by
  simpa only [parallel_v70_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g186 ++ parallel_b73) (44 :: parallel_v70_3) 211 238 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g186 parallel_b73 9 202 parallel_bf0130 parallel_bf0404) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v70_3 237 (by decide +kernel) parallel_bf0406))
theorem parallel_bf0408 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v70_1 558 := by
  simpa only [parallel_v70_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g183 ++ parallel_b72) (44 :: parallel_v70_2) 108 450 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g183 parallel_b72 6 102 parallel_bf0128 parallel_bf0403) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v70_2 449 (by decide +kernel) parallel_bf0407))
theorem parallel_bf0409 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v70_0 575 := by
  simpa only [parallel_v70_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g180 ++ parallel_b71) (44 :: parallel_v70_1) 16 559 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g180 parallel_b71 5 11 parallel_bf0126 parallel_bf0402) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v70_1 558 (by decide +kernel) parallel_bf0408))
theorem parallel_bf0410 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b70 577 := by
  simpa only [parallel_b70] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g179 (parallel_v70_0 ++ parallel_g191) 1 576 parallel_bf0125 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v70_0 parallel_g191 575 1 parallel_bf0409 parallel_bf0134))
theorem parallel_bf0411 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b76 11 := by
  simpa only [parallel_b76] using parallel_bf0137
theorem parallel_bf0412 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b78 94 := by
  simpa only [parallel_b78] using parallel_bf0140
theorem parallel_bf0413 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b79 99 := by
  simpa only [parallel_b79] using parallel_bf0141
theorem parallel_bf0414 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b80 56 := by
  simpa only [parallel_b80] using parallel_bf0142
theorem parallel_bf0415 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b81 100 := by
  simpa only [parallel_b81] using parallel_bf0143
theorem parallel_bf0416 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b82 101 := by
  simpa only [parallel_b82] using parallel_bf0144
theorem parallel_bf0417 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b83 86 := by
  simpa only [parallel_b83] using parallel_bf0145
theorem parallel_bf0418 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b84 103 := by
  simpa only [parallel_b84] using parallel_bf0146
theorem parallel_bf0419 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_6 103 := by
  simpa only [parallel_v77_6] using parallel_bf0418
theorem parallel_bf0420 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_5 190 := by
  simpa only [parallel_v77_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b83 (44 :: parallel_v77_6) 86 104 parallel_bf0417 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v77_6 103 (by decide +kernel) parallel_bf0419))
theorem parallel_bf0421 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_4 292 := by
  simpa only [parallel_v77_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b82 (44 :: parallel_v77_5) 101 191 parallel_bf0416 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v77_5 190 (by decide +kernel) parallel_bf0420))
theorem parallel_bf0422 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_3 393 := by
  simpa only [parallel_v77_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b81 (44 :: parallel_v77_4) 100 293 parallel_bf0415 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v77_4 292 (by decide +kernel) parallel_bf0421))
theorem parallel_bf0423 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_2 450 := by
  simpa only [parallel_v77_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b80 (44 :: parallel_v77_3) 56 394 parallel_bf0414 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v77_3 393 (by decide +kernel) parallel_bf0422))
theorem parallel_bf0424 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_1 550 := by
  simpa only [parallel_v77_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b79 (44 :: parallel_v77_2) 99 451 parallel_bf0413 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v77_2 450 (by decide +kernel) parallel_bf0423))
theorem parallel_bf0425 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v77_0 645 := by
  simpa only [parallel_v77_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b78 (44 :: parallel_v77_1) 94 551 parallel_bf0412 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v77_1 550 (by decide +kernel) parallel_bf0424))
theorem parallel_bf0426 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b77 647 := by
  simpa only [parallel_b77] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g198 (parallel_v77_0 ++ parallel_g212) 1 646 parallel_bf0139 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v77_0 parallel_g212 645 1 parallel_bf0425 parallel_bf0147))
theorem parallel_bf0427 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b85 202 := by
  simpa only [parallel_b85] using parallel_bf0149
theorem parallel_bf0428 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b86 103 := by
  simpa only [parallel_b86] using parallel_bf0151
theorem parallel_bf0429 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v75_3 110 := by
  simpa only [parallel_v75_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g217 parallel_b86 7 103 parallel_bf0150 parallel_bf0428)
theorem parallel_bf0430 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v75_2 322 := by
  simpa only [parallel_v75_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g214 ++ parallel_b85) (44 :: parallel_v75_3) 211 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g214 parallel_b85 9 202 parallel_bf0148 parallel_bf0427) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v75_3 110 (by decide +kernel) parallel_bf0429))
theorem parallel_bf0431 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v75_1 976 := by
  simpa only [parallel_v75_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g197 ++ parallel_b77) (44 :: parallel_v75_2) 653 323 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g197 parallel_b77 6 647 parallel_bf0138 parallel_bf0426) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v75_2 322 (by decide +kernel) parallel_bf0430))
theorem parallel_bf0432 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v75_0 993 := by
  simpa only [parallel_v75_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g194 ++ parallel_b76) (44 :: parallel_v75_1) 16 977 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g194 parallel_b76 5 11 parallel_bf0136 parallel_bf0411) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v75_1 976 (by decide +kernel) parallel_bf0431))
theorem parallel_bf0433 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b75 995 := by
  simpa only [parallel_b75] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g193 (parallel_v75_0 ++ parallel_g219) 1 994 parallel_bf0135 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v75_0 parallel_g219 993 1 parallel_bf0432 parallel_bf0152))
theorem parallel_bf0434 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b88 11 := by
  simpa only [parallel_b88] using parallel_bf0155
theorem parallel_bf0435 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b89 155 := by
  simpa only [parallel_b89] using parallel_bf0157
theorem parallel_bf0436 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b90 205 := by
  simpa only [parallel_b90] using parallel_bf0159
theorem parallel_bf0437 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b91 34 := by
  simpa only [parallel_b91] using parallel_bf0161
theorem parallel_bf0438 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v87_3 41 := by
  simpa only [parallel_v87_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g231 parallel_b91 7 34 parallel_bf0160 parallel_bf0437)
theorem parallel_bf0439 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v87_2 256 := by
  simpa only [parallel_v87_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g228 ++ parallel_b90) (44 :: parallel_v87_3) 214 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g228 parallel_b90 9 205 parallel_bf0158 parallel_bf0436) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v87_3 41 (by decide +kernel) parallel_bf0438))
theorem parallel_bf0440 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v87_1 418 := by
  simpa only [parallel_v87_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g225 ++ parallel_b89) (44 :: parallel_v87_2) 161 257 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g225 parallel_b89 6 155 parallel_bf0156 parallel_bf0435) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v87_2 256 (by decide +kernel) parallel_bf0439))
theorem parallel_bf0441 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v87_0 435 := by
  simpa only [parallel_v87_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g222 ++ parallel_b88) (44 :: parallel_v87_1) 16 419 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g222 parallel_b88 5 11 parallel_bf0154 parallel_bf0434) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v87_1 418 (by decide +kernel) parallel_bf0440))
theorem parallel_bf0442 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b87 437 := by
  simpa only [parallel_b87] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g221 (parallel_v87_0 ++ parallel_g233) 1 436 parallel_bf0153 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v87_0 parallel_g233 435 1 parallel_bf0441 parallel_bf0162))
theorem parallel_bf0443 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b93 11 := by
  simpa only [parallel_b93] using parallel_bf0165
theorem parallel_bf0444 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b94 105 := by
  simpa only [parallel_b94] using parallel_bf0167
theorem parallel_bf0445 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b95 175 := by
  simpa only [parallel_b95] using parallel_bf0169
theorem parallel_bf0446 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b96 221 := by
  simpa only [parallel_b96] using parallel_bf0171
theorem parallel_bf0447 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v92_3 228 := by
  simpa only [parallel_v92_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g245 parallel_b96 7 221 parallel_bf0170 parallel_bf0446)
theorem parallel_bf0448 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v92_2 413 := by
  simpa only [parallel_v92_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g242 ++ parallel_b95) (44 :: parallel_v92_3) 184 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g242 parallel_b95 9 175 parallel_bf0168 parallel_bf0445) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v92_3 228 (by decide +kernel) parallel_bf0447))
theorem parallel_bf0449 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v92_1 525 := by
  simpa only [parallel_v92_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g239 ++ parallel_b94) (44 :: parallel_v92_2) 111 414 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g239 parallel_b94 6 105 parallel_bf0166 parallel_bf0444) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v92_2 413 (by decide +kernel) parallel_bf0448))
theorem parallel_bf0450 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v92_0 542 := by
  simpa only [parallel_v92_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g236 ++ parallel_b93) (44 :: parallel_v92_1) 16 526 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g236 parallel_b93 5 11 parallel_bf0164 parallel_bf0443) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v92_1 525 (by decide +kernel) parallel_bf0449))
theorem parallel_bf0451 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b92 544 := by
  simpa only [parallel_b92] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g235 (parallel_v92_0 ++ parallel_g247) 1 543 parallel_bf0163 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v92_0 parallel_g247 542 1 parallel_bf0450 parallel_bf0172))
theorem parallel_bf0452 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b98 11 := by
  simpa only [parallel_b98] using parallel_bf0175
theorem parallel_bf0453 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b100 102 := by
  simpa only [parallel_b100] using parallel_bf0178
theorem parallel_bf0454 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b101 104 := by
  simpa only [parallel_b101] using parallel_bf0179
theorem parallel_bf0455 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b102 101 := by
  simpa only [parallel_b102] using parallel_bf0180
theorem parallel_bf0456 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b103 101 := by
  simpa only [parallel_b103] using parallel_bf0181
theorem parallel_bf0457 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b104 103 := by
  simpa only [parallel_b104] using parallel_bf0182
theorem parallel_bf0458 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b105 101 := by
  simpa only [parallel_b105] using parallel_bf0183
theorem parallel_bf0459 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b106 94 := by
  simpa only [parallel_b106] using parallel_bf0184
theorem parallel_bf0460 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b107 83 := by
  simpa only [parallel_b107] using parallel_bf0185
theorem parallel_bf0461 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b108 57 := by
  simpa only [parallel_b108] using parallel_bf0186
theorem parallel_bf0462 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b109 87 := by
  simpa only [parallel_b109] using parallel_bf0187
theorem parallel_bf0463 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b110 109 := by
  simpa only [parallel_b110] using parallel_bf0188
theorem parallel_bf0464 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_10 109 := by
  simpa only [parallel_v99_10] using parallel_bf0463
theorem parallel_bf0465 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_9 197 := by
  simpa only [parallel_v99_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b109 (44 :: parallel_v99_10) 87 110 parallel_bf0462 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_10 109 (by decide +kernel) parallel_bf0464))
theorem parallel_bf0466 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_8 255 := by
  simpa only [parallel_v99_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b108 (44 :: parallel_v99_9) 57 198 parallel_bf0461 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_9 197 (by decide +kernel) parallel_bf0465))
theorem parallel_bf0467 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_7 339 := by
  simpa only [parallel_v99_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b107 (44 :: parallel_v99_8) 83 256 parallel_bf0460 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_8 255 (by decide +kernel) parallel_bf0466))
theorem parallel_bf0468 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_6 434 := by
  simpa only [parallel_v99_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b106 (44 :: parallel_v99_7) 94 340 parallel_bf0459 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_7 339 (by decide +kernel) parallel_bf0467))
theorem parallel_bf0469 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_5 536 := by
  simpa only [parallel_v99_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b105 (44 :: parallel_v99_6) 101 435 parallel_bf0458 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_6 434 (by decide +kernel) parallel_bf0468))
theorem parallel_bf0470 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_4 640 := by
  simpa only [parallel_v99_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b104 (44 :: parallel_v99_5) 103 537 parallel_bf0457 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_5 536 (by decide +kernel) parallel_bf0469))
theorem parallel_bf0471 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_3 742 := by
  simpa only [parallel_v99_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b103 (44 :: parallel_v99_4) 101 641 parallel_bf0456 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_4 640 (by decide +kernel) parallel_bf0470))
theorem parallel_bf0472 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_2 844 := by
  simpa only [parallel_v99_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b102 (44 :: parallel_v99_3) 101 743 parallel_bf0455 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_3 742 (by decide +kernel) parallel_bf0471))
theorem parallel_bf0473 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_1 949 := by
  simpa only [parallel_v99_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b101 (44 :: parallel_v99_2) 104 845 parallel_bf0454 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_2 844 (by decide +kernel) parallel_bf0472))
theorem parallel_bf0474 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v99_0 1052 := by
  simpa only [parallel_v99_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b100 (44 :: parallel_v99_1) 102 950 parallel_bf0453 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v99_1 949 (by decide +kernel) parallel_bf0473))
theorem parallel_bf0475 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b99 1054 := by
  simpa only [parallel_b99] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g254 (parallel_v99_0 ++ parallel_g276) 1 1053 parallel_bf0177 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v99_0 parallel_g276 1052 1 parallel_bf0474 parallel_bf0189))
theorem parallel_bf0476 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b111 175 := by
  simpa only [parallel_b111] using parallel_bf0191
theorem parallel_bf0477 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b112 98 := by
  simpa only [parallel_b112] using parallel_bf0193
theorem parallel_bf0478 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v97_3 105 := by
  simpa only [parallel_v97_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g281 parallel_b112 7 98 parallel_bf0192 parallel_bf0477)
theorem parallel_bf0479 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v97_2 290 := by
  simpa only [parallel_v97_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g278 ++ parallel_b111) (44 :: parallel_v97_3) 184 106 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g278 parallel_b111 9 175 parallel_bf0190 parallel_bf0476) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v97_3 105 (by decide +kernel) parallel_bf0478))
theorem parallel_bf0480 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v97_1 1351 := by
  simpa only [parallel_v97_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g253 ++ parallel_b99) (44 :: parallel_v97_2) 1060 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g253 parallel_b99 6 1054 parallel_bf0176 parallel_bf0475) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v97_2 290 (by decide +kernel) parallel_bf0479))
theorem parallel_bf0481 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v97_0 1368 := by
  simpa only [parallel_v97_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g250 ++ parallel_b98) (44 :: parallel_v97_1) 16 1352 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g250 parallel_b98 5 11 parallel_bf0174 parallel_bf0452) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v97_1 1351 (by decide +kernel) parallel_bf0480))
theorem parallel_bf0482 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b97 1370 := by
  simpa only [parallel_b97] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g249 (parallel_v97_0 ++ parallel_g283) 1 1369 parallel_bf0173 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v97_0 parallel_g283 1368 1 parallel_bf0481 parallel_bf0194))
theorem parallel_bf0483 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b114 11 := by
  simpa only [parallel_b114] using parallel_bf0197
theorem parallel_bf0484 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b115 175 := by
  simpa only [parallel_b115] using parallel_bf0199
theorem parallel_bf0485 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b116 175 := by
  simpa only [parallel_b116] using parallel_bf0201
theorem parallel_bf0486 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b117 109 := by
  simpa only [parallel_b117] using parallel_bf0203
theorem parallel_bf0487 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v113_3 116 := by
  simpa only [parallel_v113_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g295 parallel_b117 7 109 parallel_bf0202 parallel_bf0486)
theorem parallel_bf0488 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v113_2 301 := by
  simpa only [parallel_v113_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g292 ++ parallel_b116) (44 :: parallel_v113_3) 184 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g292 parallel_b116 9 175 parallel_bf0200 parallel_bf0485) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v113_3 116 (by decide +kernel) parallel_bf0487))
theorem parallel_bf0489 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v113_1 483 := by
  simpa only [parallel_v113_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g289 ++ parallel_b115) (44 :: parallel_v113_2) 181 302 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g289 parallel_b115 6 175 parallel_bf0198 parallel_bf0484) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v113_2 301 (by decide +kernel) parallel_bf0488))
theorem parallel_bf0490 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v113_0 500 := by
  simpa only [parallel_v113_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g286 ++ parallel_b114) (44 :: parallel_v113_1) 16 484 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g286 parallel_b114 5 11 parallel_bf0196 parallel_bf0483) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v113_1 483 (by decide +kernel) parallel_bf0489))
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.linear_bf0000
#print axioms HiaCoreSyntaxSlice.linear_bf0001
#print axioms HiaCoreSyntaxSlice.linear_bf0002
#print axioms HiaCoreSyntaxSlice.linear_bf0003
#print axioms HiaCoreSyntaxSlice.linear_bf0004
#print axioms HiaCoreSyntaxSlice.linear_bf0005
#print axioms HiaCoreSyntaxSlice.linear_bf0006
#print axioms HiaCoreSyntaxSlice.linear_bf0007
#print axioms HiaCoreSyntaxSlice.linear_bf0008
#print axioms HiaCoreSyntaxSlice.linear_bf0009
#print axioms HiaCoreSyntaxSlice.linear_bf0010
#print axioms HiaCoreSyntaxSlice.linear_bf0011
#print axioms HiaCoreSyntaxSlice.linear_bf0012
#print axioms HiaCoreSyntaxSlice.linear_bf0013
#print axioms HiaCoreSyntaxSlice.linear_bf0014
#print axioms HiaCoreSyntaxSlice.linear_bf0015
#print axioms HiaCoreSyntaxSlice.linear_bf0016
#print axioms HiaCoreSyntaxSlice.linear_bf0017
#print axioms HiaCoreSyntaxSlice.linear_bf0018
#print axioms HiaCoreSyntaxSlice.linear_bf0019
#print axioms HiaCoreSyntaxSlice.linear_bf0020
#print axioms HiaCoreSyntaxSlice.linear_bf0021
#print axioms HiaCoreSyntaxSlice.linear_bf0022
#print axioms HiaCoreSyntaxSlice.linear_bf0023
#print axioms HiaCoreSyntaxSlice.linear_bf0024
#print axioms HiaCoreSyntaxSlice.linear_bf0025
#print axioms HiaCoreSyntaxSlice.linear_bf0026
#print axioms HiaCoreSyntaxSlice.linear_bf0027
#print axioms HiaCoreSyntaxSlice.linear_bf0028
#print axioms HiaCoreSyntaxSlice.linear_bf0029
#print axioms HiaCoreSyntaxSlice.linear_bf0030
#print axioms HiaCoreSyntaxSlice.linear_bf0031
#print axioms HiaCoreSyntaxSlice.linear_bf0032
#print axioms HiaCoreSyntaxSlice.linear_bf0033
#print axioms HiaCoreSyntaxSlice.linear_bf0034
#print axioms HiaCoreSyntaxSlice.linear_bf0035
#print axioms HiaCoreSyntaxSlice.linear_bf0036
#print axioms HiaCoreSyntaxSlice.linear_bf0037
#print axioms HiaCoreSyntaxSlice.linear_bf0038
#print axioms HiaCoreSyntaxSlice.linear_bf0039
#print axioms HiaCoreSyntaxSlice.linear_bf0040
#print axioms HiaCoreSyntaxSlice.linear_bf0041
#print axioms HiaCoreSyntaxSlice.linear_bf0042
#print axioms HiaCoreSyntaxSlice.linear_bf0043
#print axioms HiaCoreSyntaxSlice.linear_bf0044
#print axioms HiaCoreSyntaxSlice.linear_bf0045
#print axioms HiaCoreSyntaxSlice.linear_bf0046
#print axioms HiaCoreSyntaxSlice.linear_bf0047
#print axioms HiaCoreSyntaxSlice.linear_bf0048
#print axioms HiaCoreSyntaxSlice.linear_bf0049
#print axioms HiaCoreSyntaxSlice.linear_bf0050
#print axioms HiaCoreSyntaxSlice.linear_bf0051
#print axioms HiaCoreSyntaxSlice.linear_bf0052
#print axioms HiaCoreSyntaxSlice.linear_bf0053
#print axioms HiaCoreSyntaxSlice.linear_bf0054
#print axioms HiaCoreSyntaxSlice.linear_bf0055
#print axioms HiaCoreSyntaxSlice.linear_bf0056
#print axioms HiaCoreSyntaxSlice.linear_bf0057
#print axioms HiaCoreSyntaxSlice.linear_bf0058
#print axioms HiaCoreSyntaxSlice.linear_bf0059
#print axioms HiaCoreSyntaxSlice.linear_bf0060
#print axioms HiaCoreSyntaxSlice.linear_bf0061
#print axioms HiaCoreSyntaxSlice.linear_bf0062
#print axioms HiaCoreSyntaxSlice.linear_bf0063
#print axioms HiaCoreSyntaxSlice.linear_bf0064
#print axioms HiaCoreSyntaxSlice.linear_bf0065
#print axioms HiaCoreSyntaxSlice.linear_bf0066
#print axioms HiaCoreSyntaxSlice.linear_bf0067
#print axioms HiaCoreSyntaxSlice.linear_bf0068
#print axioms HiaCoreSyntaxSlice.linear_bf0069
#print axioms HiaCoreSyntaxSlice.linear_bf0070
#print axioms HiaCoreSyntaxSlice.linear_bf0071
#print axioms HiaCoreSyntaxSlice.linear_bf0072
#print axioms HiaCoreSyntaxSlice.linear_bf0073
#print axioms HiaCoreSyntaxSlice.linear_bf0074
#print axioms HiaCoreSyntaxSlice.linear_bf0075
#print axioms HiaCoreSyntaxSlice.linear_bf0076
#print axioms HiaCoreSyntaxSlice.linear_bf0077
#print axioms HiaCoreSyntaxSlice.linear_bf0078
#print axioms HiaCoreSyntaxSlice.linear_bf0079
#print axioms HiaCoreSyntaxSlice.linear_bf0080
#print axioms HiaCoreSyntaxSlice.linear_bf0081
#print axioms HiaCoreSyntaxSlice.linear_bf0082
#print axioms HiaCoreSyntaxSlice.linear_bf0083
#print axioms HiaCoreSyntaxSlice.linear_bf0084
#print axioms HiaCoreSyntaxSlice.linear_bf0085
#print axioms HiaCoreSyntaxSlice.linear_bf0086
#print axioms HiaCoreSyntaxSlice.linear_bf0087
#print axioms HiaCoreSyntaxSlice.linear_bf0088
#print axioms HiaCoreSyntaxSlice.linear_bf0089
#print axioms HiaCoreSyntaxSlice.linear_bf0090
#print axioms HiaCoreSyntaxSlice.linear_bf0091
#print axioms HiaCoreSyntaxSlice.linear_bf0092
#print axioms HiaCoreSyntaxSlice.linear_bf0093
#print axioms HiaCoreSyntaxSlice.linear_bf0094
#print axioms HiaCoreSyntaxSlice.linear_bf0095
#print axioms HiaCoreSyntaxSlice.linear_bf0096
#print axioms HiaCoreSyntaxSlice.linear_bf0097
#print axioms HiaCoreSyntaxSlice.linear_bf0098
#print axioms HiaCoreSyntaxSlice.linear_bf0099
#print axioms HiaCoreSyntaxSlice.linear_bf0100
#print axioms HiaCoreSyntaxSlice.linear_bf0101
#print axioms HiaCoreSyntaxSlice.linear_bf0102
#print axioms HiaCoreSyntaxSlice.linear_bf0103
#print axioms HiaCoreSyntaxSlice.linear_bf0104
#print axioms HiaCoreSyntaxSlice.linear_bf0105
#print axioms HiaCoreSyntaxSlice.linear_bf0106
#print axioms HiaCoreSyntaxSlice.linear_bf0107
#print axioms HiaCoreSyntaxSlice.linear_bf0108
#print axioms HiaCoreSyntaxSlice.linear_bf0109
#print axioms HiaCoreSyntaxSlice.linear_bf0110
#print axioms HiaCoreSyntaxSlice.linear_bf0111
#print axioms HiaCoreSyntaxSlice.linear_bf0112
#print axioms HiaCoreSyntaxSlice.linear_bf0113
#print axioms HiaCoreSyntaxSlice.linear_bf0114
#print axioms HiaCoreSyntaxSlice.linear_bf0115
#print axioms HiaCoreSyntaxSlice.linear_bf0116
#print axioms HiaCoreSyntaxSlice.linear_bf0117
#print axioms HiaCoreSyntaxSlice.linear_bf0118
#print axioms HiaCoreSyntaxSlice.linear_bf0119
#print axioms HiaCoreSyntaxSlice.linear_bf0120
#print axioms HiaCoreSyntaxSlice.linear_bf0121
#print axioms HiaCoreSyntaxSlice.linear_bf0122
#print axioms HiaCoreSyntaxSlice.linear_bf0123
#print axioms HiaCoreSyntaxSlice.linear_bf0124
#print axioms HiaCoreSyntaxSlice.linear_bf0125
#print axioms HiaCoreSyntaxSlice.linear_bf0126
#print axioms HiaCoreSyntaxSlice.linear_bf0127
#print axioms HiaCoreSyntaxSlice.linear_bf0128
#print axioms HiaCoreSyntaxSlice.linear_bf0129
#print axioms HiaCoreSyntaxSlice.linear_bf0130
#print axioms HiaCoreSyntaxSlice.linear_bf0131
#print axioms HiaCoreSyntaxSlice.linear_bf0132
#print axioms HiaCoreSyntaxSlice.linear_bf0133
#print axioms HiaCoreSyntaxSlice.linear_bf0134
#print axioms HiaCoreSyntaxSlice.linear_bf0135
#print axioms HiaCoreSyntaxSlice.linear_bf0136
#print axioms HiaCoreSyntaxSlice.linear_bf0137
#print axioms HiaCoreSyntaxSlice.linear_bf0138
#print axioms HiaCoreSyntaxSlice.linear_bf0139
#print axioms HiaCoreSyntaxSlice.linear_bf0140
#print axioms HiaCoreSyntaxSlice.linear_bf0141
#print axioms HiaCoreSyntaxSlice.linear_bf0142
#print axioms HiaCoreSyntaxSlice.linear_bf0143
#print axioms HiaCoreSyntaxSlice.linear_bf0144
#print axioms HiaCoreSyntaxSlice.linear_bf0145
#print axioms HiaCoreSyntaxSlice.linear_bf0146
#print axioms HiaCoreSyntaxSlice.linear_bf0147
#print axioms HiaCoreSyntaxSlice.linear_bf0148
#print axioms HiaCoreSyntaxSlice.linear_bf0149
#print axioms HiaCoreSyntaxSlice.linear_bf0150
#print axioms HiaCoreSyntaxSlice.linear_bf0151
#print axioms HiaCoreSyntaxSlice.linear_bf0152
#print axioms HiaCoreSyntaxSlice.linear_bf0153
#print axioms HiaCoreSyntaxSlice.linear_bf0154
#print axioms HiaCoreSyntaxSlice.linear_bf0155
#print axioms HiaCoreSyntaxSlice.linear_bf0156
#print axioms HiaCoreSyntaxSlice.linear_bf0157
#print axioms HiaCoreSyntaxSlice.linear_bf0158
#print axioms HiaCoreSyntaxSlice.linear_bf0159
#print axioms HiaCoreSyntaxSlice.linear_bf0160
#print axioms HiaCoreSyntaxSlice.linear_bf0161
#print axioms HiaCoreSyntaxSlice.linear_bf0162
#print axioms HiaCoreSyntaxSlice.linear_bf0163
#print axioms HiaCoreSyntaxSlice.linear_bf0164
#print axioms HiaCoreSyntaxSlice.linear_bf0165
#print axioms HiaCoreSyntaxSlice.linear_bf0166
#print axioms HiaCoreSyntaxSlice.linear_bf0167
#print axioms HiaCoreSyntaxSlice.linear_bf0168
#print axioms HiaCoreSyntaxSlice.linear_bf0169
#print axioms HiaCoreSyntaxSlice.linear_bf0170
#print axioms HiaCoreSyntaxSlice.linear_bf0171
#print axioms HiaCoreSyntaxSlice.linear_bf0172
#print axioms HiaCoreSyntaxSlice.linear_bf0173
#print axioms HiaCoreSyntaxSlice.linear_bf0174
#print axioms HiaCoreSyntaxSlice.linear_bf0175
#print axioms HiaCoreSyntaxSlice.linear_bf0176
#print axioms HiaCoreSyntaxSlice.linear_bf0177
#print axioms HiaCoreSyntaxSlice.linear_bf0178
#print axioms HiaCoreSyntaxSlice.linear_bf0179
#print axioms HiaCoreSyntaxSlice.linear_bf0180
#print axioms HiaCoreSyntaxSlice.linear_bf0181
#print axioms HiaCoreSyntaxSlice.linear_bf0182
#print axioms HiaCoreSyntaxSlice.linear_bf0183
#print axioms HiaCoreSyntaxSlice.linear_bf0184
#print axioms HiaCoreSyntaxSlice.linear_bf0185
#print axioms HiaCoreSyntaxSlice.linear_bf0186
#print axioms HiaCoreSyntaxSlice.linear_bf0187
#print axioms HiaCoreSyntaxSlice.linear_bf0188
#print axioms HiaCoreSyntaxSlice.linear_bf0189
#print axioms HiaCoreSyntaxSlice.linear_bf0190
#print axioms HiaCoreSyntaxSlice.linear_bf0191
#print axioms HiaCoreSyntaxSlice.linear_bf0192
#print axioms HiaCoreSyntaxSlice.linear_bf0193
#print axioms HiaCoreSyntaxSlice.linear_bf0194
#print axioms HiaCoreSyntaxSlice.linear_bf0195
#print axioms HiaCoreSyntaxSlice.linear_bf0196
#print axioms HiaCoreSyntaxSlice.linear_bf0197
#print axioms HiaCoreSyntaxSlice.linear_bf0198
#print axioms HiaCoreSyntaxSlice.linear_bf0199
#print axioms HiaCoreSyntaxSlice.linear_bf0200
#print axioms HiaCoreSyntaxSlice.linear_bf0201
#print axioms HiaCoreSyntaxSlice.linear_bf0202
#print axioms HiaCoreSyntaxSlice.linear_bf0203
#print axioms HiaCoreSyntaxSlice.linear_bf0204
#print axioms HiaCoreSyntaxSlice.linear_bf0205
#print axioms HiaCoreSyntaxSlice.linear_bf0206
#print axioms HiaCoreSyntaxSlice.linear_bf0207
#print axioms HiaCoreSyntaxSlice.linear_bf0208
#print axioms HiaCoreSyntaxSlice.linear_bf0209
#print axioms HiaCoreSyntaxSlice.linear_bf0210
#print axioms HiaCoreSyntaxSlice.linear_bf0211
#print axioms HiaCoreSyntaxSlice.linear_bf0212
#print axioms HiaCoreSyntaxSlice.linear_bf0213
#print axioms HiaCoreSyntaxSlice.linear_bf0214
#print axioms HiaCoreSyntaxSlice.linear_bf0215
#print axioms HiaCoreSyntaxSlice.linear_bf0216
#print axioms HiaCoreSyntaxSlice.linear_bf0217
#print axioms HiaCoreSyntaxSlice.linear_bf0218
#print axioms HiaCoreSyntaxSlice.linear_bf0219
#print axioms HiaCoreSyntaxSlice.linear_bf0220
#print axioms HiaCoreSyntaxSlice.linear_bf0221
#print axioms HiaCoreSyntaxSlice.linear_bf0222
#print axioms HiaCoreSyntaxSlice.linear_bf0223
#print axioms HiaCoreSyntaxSlice.linear_bf0224
#print axioms HiaCoreSyntaxSlice.linear_bf0225
#print axioms HiaCoreSyntaxSlice.linear_bf0226
#print axioms HiaCoreSyntaxSlice.linear_bf0227
#print axioms HiaCoreSyntaxSlice.linear_bf0228
#print axioms HiaCoreSyntaxSlice.linear_bf0229
#print axioms HiaCoreSyntaxSlice.linear_bf0230
#print axioms HiaCoreSyntaxSlice.linear_bf0231
#print axioms HiaCoreSyntaxSlice.linear_bf0232
#print axioms HiaCoreSyntaxSlice.linear_bf0233
#print axioms HiaCoreSyntaxSlice.linear_bf0234
#print axioms HiaCoreSyntaxSlice.linear_bf0235
#print axioms HiaCoreSyntaxSlice.linear_bf0236
#print axioms HiaCoreSyntaxSlice.linear_bf0237
#print axioms HiaCoreSyntaxSlice.linear_bf0238
#print axioms HiaCoreSyntaxSlice.linear_bf0239
#print axioms HiaCoreSyntaxSlice.linear_bf0240
#print axioms HiaCoreSyntaxSlice.linear_bf0241
#print axioms HiaCoreSyntaxSlice.linear_bf0242
#print axioms HiaCoreSyntaxSlice.linear_bf0243
#print axioms HiaCoreSyntaxSlice.linear_bf0244
#print axioms HiaCoreSyntaxSlice.linear_bf0245
#print axioms HiaCoreSyntaxSlice.linear_bf0246
#print axioms HiaCoreSyntaxSlice.linear_bf0247
#print axioms HiaCoreSyntaxSlice.linear_bf0248
#print axioms HiaCoreSyntaxSlice.linear_bf0249
#print axioms HiaCoreSyntaxSlice.linear_bf0250
#print axioms HiaCoreSyntaxSlice.linear_bf0251
#print axioms HiaCoreSyntaxSlice.linear_bf0252
#print axioms HiaCoreSyntaxSlice.linear_bf0253
#print axioms HiaCoreSyntaxSlice.linear_bf0254
#print axioms HiaCoreSyntaxSlice.linear_bf0255
#print axioms HiaCoreSyntaxSlice.linear_bf0256
#print axioms HiaCoreSyntaxSlice.linear_bf0257
#print axioms HiaCoreSyntaxSlice.linear_bf0258
#print axioms HiaCoreSyntaxSlice.linear_bf0259
#print axioms HiaCoreSyntaxSlice.linear_bf0260
#print axioms HiaCoreSyntaxSlice.linear_bf0261
#print axioms HiaCoreSyntaxSlice.linear_bf0262
#print axioms HiaCoreSyntaxSlice.linear_bf0263
#print axioms HiaCoreSyntaxSlice.linear_bf0264
#print axioms HiaCoreSyntaxSlice.linear_bf0265
#print axioms HiaCoreSyntaxSlice.linear_bf0266
#print axioms HiaCoreSyntaxSlice.linear_bf0267
#print axioms HiaCoreSyntaxSlice.linear_bf0268
#print axioms HiaCoreSyntaxSlice.linear_bf0269
#print axioms HiaCoreSyntaxSlice.linear_bf0270
#print axioms HiaCoreSyntaxSlice.linear_bf0271
#print axioms HiaCoreSyntaxSlice.linear_bf0272
#print axioms HiaCoreSyntaxSlice.linear_bf0273
#print axioms HiaCoreSyntaxSlice.linear_bf0274
#print axioms HiaCoreSyntaxSlice.linear_bf0275
#print axioms HiaCoreSyntaxSlice.linear_bf0276
#print axioms HiaCoreSyntaxSlice.linear_bf0277
#print axioms HiaCoreSyntaxSlice.linear_bf0278
#print axioms HiaCoreSyntaxSlice.linear_bf0279
#print axioms HiaCoreSyntaxSlice.linear_bf0280
#print axioms HiaCoreSyntaxSlice.linear_bf0281
#print axioms HiaCoreSyntaxSlice.linear_bf0282
#print axioms HiaCoreSyntaxSlice.linear_bf0283
#print axioms HiaCoreSyntaxSlice.linear_bf0284
#print axioms HiaCoreSyntaxSlice.linear_bf0285
#print axioms HiaCoreSyntaxSlice.linear_bf0286
#print axioms HiaCoreSyntaxSlice.linear_bf0287
#print axioms HiaCoreSyntaxSlice.linear_bf0288
#print axioms HiaCoreSyntaxSlice.linear_bf0289
#print axioms HiaCoreSyntaxSlice.linear_bf0290
#print axioms HiaCoreSyntaxSlice.linear_bf0291
#print axioms HiaCoreSyntaxSlice.linear_bf0292
#print axioms HiaCoreSyntaxSlice.linear_bf0293
#print axioms HiaCoreSyntaxSlice.linear_bf0294
#print axioms HiaCoreSyntaxSlice.linear_bf0295
#print axioms HiaCoreSyntaxSlice.linear_bf0296
#print axioms HiaCoreSyntaxSlice.linear_bf0297
#print axioms HiaCoreSyntaxSlice.linear_bf0298
#print axioms HiaCoreSyntaxSlice.linear_bf0299
#print axioms HiaCoreSyntaxSlice.linear_bf0300
#print axioms HiaCoreSyntaxSlice.linear_bf0301
#print axioms HiaCoreSyntaxSlice.linear_bf0302
#print axioms HiaCoreSyntaxSlice.linear_bf0303
#print axioms HiaCoreSyntaxSlice.linear_bf0304
#print axioms HiaCoreSyntaxSlice.linear_bf0305
#print axioms HiaCoreSyntaxSlice.linear_bf0306
#print axioms HiaCoreSyntaxSlice.linear_bf0307
#print axioms HiaCoreSyntaxSlice.linear_bf0308
#print axioms HiaCoreSyntaxSlice.linear_bf0309
#print axioms HiaCoreSyntaxSlice.linear_bf0310
#print axioms HiaCoreSyntaxSlice.linear_bf0311
#print axioms HiaCoreSyntaxSlice.linear_bf0312
#print axioms HiaCoreSyntaxSlice.linear_bf0313
#print axioms HiaCoreSyntaxSlice.linear_bf0314
#print axioms HiaCoreSyntaxSlice.linear_bf0315
#print axioms HiaCoreSyntaxSlice.linear_bf0316
#print axioms HiaCoreSyntaxSlice.linear_bf0317
#print axioms HiaCoreSyntaxSlice.linear_bf0318
#print axioms HiaCoreSyntaxSlice.linear_bf0319
#print axioms HiaCoreSyntaxSlice.linear_bf0320
#print axioms HiaCoreSyntaxSlice.linear_bf0321
#print axioms HiaCoreSyntaxSlice.linear_bf0322
#print axioms HiaCoreSyntaxSlice.linear_bf0323
#print axioms HiaCoreSyntaxSlice.linear_bf0324
#print axioms HiaCoreSyntaxSlice.linear_bf0325
#print axioms HiaCoreSyntaxSlice.linear_bf0326
#print axioms HiaCoreSyntaxSlice.linear_bf0327
#print axioms HiaCoreSyntaxSlice.linear_bf0328
#print axioms HiaCoreSyntaxSlice.linear_bf0329
#print axioms HiaCoreSyntaxSlice.linear_bf0330
#print axioms HiaCoreSyntaxSlice.linear_bf0331
#print axioms HiaCoreSyntaxSlice.linear_bf0332
#print axioms HiaCoreSyntaxSlice.linear_bf0333
#print axioms HiaCoreSyntaxSlice.linear_bf0334
#print axioms HiaCoreSyntaxSlice.linear_bf0335
#print axioms HiaCoreSyntaxSlice.linear_bf0336
#print axioms HiaCoreSyntaxSlice.linear_bf0337
#print axioms HiaCoreSyntaxSlice.linear_bf0338
#print axioms HiaCoreSyntaxSlice.linear_bf0339
#print axioms HiaCoreSyntaxSlice.linear_bf0340
#print axioms HiaCoreSyntaxSlice.linear_bf0341
#print axioms HiaCoreSyntaxSlice.linear_bf0342
#print axioms HiaCoreSyntaxSlice.linear_bf0343
#print axioms HiaCoreSyntaxSlice.linear_bf0344
#print axioms HiaCoreSyntaxSlice.linear_bf0345
#print axioms HiaCoreSyntaxSlice.linear_bf0346
#print axioms HiaCoreSyntaxSlice.linear_bf0347
#print axioms HiaCoreSyntaxSlice.linear_bf0348
#print axioms HiaCoreSyntaxSlice.linear_bf0349
#print axioms HiaCoreSyntaxSlice.linear_bf0350
#print axioms HiaCoreSyntaxSlice.linear_bf0351
#print axioms HiaCoreSyntaxSlice.linear_bf0352
#print axioms HiaCoreSyntaxSlice.linear_bf0353
#print axioms HiaCoreSyntaxSlice.linear_bf0354
#print axioms HiaCoreSyntaxSlice.linear_bf0355
#print axioms HiaCoreSyntaxSlice.linear_bf0356
#print axioms HiaCoreSyntaxSlice.linear_bf0357
#print axioms HiaCoreSyntaxSlice.linear_bf0358
#print axioms HiaCoreSyntaxSlice.linear_bf0359
#print axioms HiaCoreSyntaxSlice.linear_bf0360
#print axioms HiaCoreSyntaxSlice.linear_bf0361
#print axioms HiaCoreSyntaxSlice.linear_bf0362
#print axioms HiaCoreSyntaxSlice.linear_bf0363
#print axioms HiaCoreSyntaxSlice.linear_bf0364
#print axioms HiaCoreSyntaxSlice.linear_bf0365
#print axioms HiaCoreSyntaxSlice.linear_bf0366
#print axioms HiaCoreSyntaxSlice.linear_bf0367
#print axioms HiaCoreSyntaxSlice.linear_bf0368
#print axioms HiaCoreSyntaxSlice.linear_bf0369
#print axioms HiaCoreSyntaxSlice.linear_bf0370
#print axioms HiaCoreSyntaxSlice.linear_bf0371
#print axioms HiaCoreSyntaxSlice.linear_bf0372
#print axioms HiaCoreSyntaxSlice.linear_bf0373
#print axioms HiaCoreSyntaxSlice.linear_bf0374
#print axioms HiaCoreSyntaxSlice.linear_bf0375
#print axioms HiaCoreSyntaxSlice.linear_bf0376
#print axioms HiaCoreSyntaxSlice.linear_bf0377
#print axioms HiaCoreSyntaxSlice.linear_bf0378
#print axioms HiaCoreSyntaxSlice.linear_bf0379
#print axioms HiaCoreSyntaxSlice.linear_bf0380
#print axioms HiaCoreSyntaxSlice.linear_bf0381
#print axioms HiaCoreSyntaxSlice.linear_bf0382
#print axioms HiaCoreSyntaxSlice.linear_bf0383
#print axioms HiaCoreSyntaxSlice.linear_bf0384
#print axioms HiaCoreSyntaxSlice.linear_bf0385
#print axioms HiaCoreSyntaxSlice.linear_bf0386
#print axioms HiaCoreSyntaxSlice.linear_bf0387
#print axioms HiaCoreSyntaxSlice.linear_bf0388
#print axioms HiaCoreSyntaxSlice.linear_bf0389
#print axioms HiaCoreSyntaxSlice.linear_bf0390
#print axioms HiaCoreSyntaxSlice.linear_bf0391
#print axioms HiaCoreSyntaxSlice.linear_bf0392
#print axioms HiaCoreSyntaxSlice.linear_bf0393
#print axioms HiaCoreSyntaxSlice.linear_bf0394
#print axioms HiaCoreSyntaxSlice.linear_bf0395
#print axioms HiaCoreSyntaxSlice.linear_bf0396
#print axioms HiaCoreSyntaxSlice.linear_bf0397
#print axioms HiaCoreSyntaxSlice.linear_bf0398
#print axioms HiaCoreSyntaxSlice.linear_bf0399
#print axioms HiaCoreSyntaxSlice.linear_bf0400
#print axioms HiaCoreSyntaxSlice.linear_bf0401
#print axioms HiaCoreSyntaxSlice.linear_bf0402
#print axioms HiaCoreSyntaxSlice.linear_bf0403
#print axioms HiaCoreSyntaxSlice.linear_bf0404
#print axioms HiaCoreSyntaxSlice.linear_bf0405
#print axioms HiaCoreSyntaxSlice.linear_bf0406
#print axioms HiaCoreSyntaxSlice.linear_bf0407
#print axioms HiaCoreSyntaxSlice.linear_bf0408
#print axioms HiaCoreSyntaxSlice.linear_bf0409
#print axioms HiaCoreSyntaxSlice.linear_bf0410
#print axioms HiaCoreSyntaxSlice.linear_bf0411
#print axioms HiaCoreSyntaxSlice.linear_bf0412
#print axioms HiaCoreSyntaxSlice.linear_bf0413
#print axioms HiaCoreSyntaxSlice.linear_bf0414
#print axioms HiaCoreSyntaxSlice.linear_bf0415
#print axioms HiaCoreSyntaxSlice.linear_bf0416
#print axioms HiaCoreSyntaxSlice.linear_bf0417
#print axioms HiaCoreSyntaxSlice.linear_bf0418
#print axioms HiaCoreSyntaxSlice.linear_bf0419
#print axioms HiaCoreSyntaxSlice.linear_bf0420
#print axioms HiaCoreSyntaxSlice.linear_bf0421
#print axioms HiaCoreSyntaxSlice.linear_bf0422
#print axioms HiaCoreSyntaxSlice.linear_bf0423
#print axioms HiaCoreSyntaxSlice.linear_bf0424
#print axioms HiaCoreSyntaxSlice.linear_bf0425
#print axioms HiaCoreSyntaxSlice.linear_bf0426
#print axioms HiaCoreSyntaxSlice.linear_bf0427
#print axioms HiaCoreSyntaxSlice.linear_bf0428
#print axioms HiaCoreSyntaxSlice.linear_bf0429
#print axioms HiaCoreSyntaxSlice.linear_bf0430
#print axioms HiaCoreSyntaxSlice.linear_bf0431
#print axioms HiaCoreSyntaxSlice.linear_bf0432
#print axioms HiaCoreSyntaxSlice.linear_bf0433
#print axioms HiaCoreSyntaxSlice.linear_bf0434
#print axioms HiaCoreSyntaxSlice.linear_bf0435
#print axioms HiaCoreSyntaxSlice.linear_bf0436
#print axioms HiaCoreSyntaxSlice.linear_bf0437
#print axioms HiaCoreSyntaxSlice.linear_bf0438
#print axioms HiaCoreSyntaxSlice.linear_bf0439
#print axioms HiaCoreSyntaxSlice.linear_bf0440
#print axioms HiaCoreSyntaxSlice.linear_bf0441
#print axioms HiaCoreSyntaxSlice.linear_bf0442
#print axioms HiaCoreSyntaxSlice.linear_bf0443
#print axioms HiaCoreSyntaxSlice.linear_bf0444
#print axioms HiaCoreSyntaxSlice.linear_bf0445
#print axioms HiaCoreSyntaxSlice.linear_bf0446
#print axioms HiaCoreSyntaxSlice.linear_bf0447
#print axioms HiaCoreSyntaxSlice.linear_bf0448
#print axioms HiaCoreSyntaxSlice.linear_bf0449
#print axioms HiaCoreSyntaxSlice.linear_bf0450
#print axioms HiaCoreSyntaxSlice.linear_bf0451
#print axioms HiaCoreSyntaxSlice.linear_bf0452
#print axioms HiaCoreSyntaxSlice.linear_bf0453
#print axioms HiaCoreSyntaxSlice.linear_bf0454
#print axioms HiaCoreSyntaxSlice.linear_bf0455
#print axioms HiaCoreSyntaxSlice.linear_bf0456
#print axioms HiaCoreSyntaxSlice.linear_bf0457
#print axioms HiaCoreSyntaxSlice.linear_bf0458
#print axioms HiaCoreSyntaxSlice.linear_bf0459
#print axioms HiaCoreSyntaxSlice.linear_bf0460
#print axioms HiaCoreSyntaxSlice.linear_bf0461
#print axioms HiaCoreSyntaxSlice.linear_bf0462
#print axioms HiaCoreSyntaxSlice.linear_bf0463
#print axioms HiaCoreSyntaxSlice.linear_bf0464
#print axioms HiaCoreSyntaxSlice.linear_bf0465
#print axioms HiaCoreSyntaxSlice.linear_bf0466
#print axioms HiaCoreSyntaxSlice.linear_bf0467
#print axioms HiaCoreSyntaxSlice.linear_bf0468
#print axioms HiaCoreSyntaxSlice.linear_bf0469
#print axioms HiaCoreSyntaxSlice.linear_bf0470
#print axioms HiaCoreSyntaxSlice.linear_bf0471
#print axioms HiaCoreSyntaxSlice.linear_bf0472
#print axioms HiaCoreSyntaxSlice.linear_bf0473
#print axioms HiaCoreSyntaxSlice.linear_bf0474
#print axioms HiaCoreSyntaxSlice.linear_bf0475
#print axioms HiaCoreSyntaxSlice.linear_bf0476
#print axioms HiaCoreSyntaxSlice.linear_bf0477
#print axioms HiaCoreSyntaxSlice.linear_bf0478
#print axioms HiaCoreSyntaxSlice.linear_bf0479
#print axioms HiaCoreSyntaxSlice.linear_bf0480
#print axioms HiaCoreSyntaxSlice.linear_bf0481
#print axioms HiaCoreSyntaxSlice.linear_bf0482
#print axioms HiaCoreSyntaxSlice.linear_bf0483
#print axioms HiaCoreSyntaxSlice.linear_bf0484
#print axioms HiaCoreSyntaxSlice.linear_bf0485
#print axioms HiaCoreSyntaxSlice.linear_bf0486
#print axioms HiaCoreSyntaxSlice.linear_bf0487
#print axioms HiaCoreSyntaxSlice.linear_bf0488
#print axioms HiaCoreSyntaxSlice.linear_bf0489
#print axioms HiaCoreSyntaxSlice.linear_bf0490
#print axioms HiaCoreSyntaxSlice.linear_bf0491
#print axioms HiaCoreSyntaxSlice.linear_bf0492
#print axioms HiaCoreSyntaxSlice.linear_bf0493
#print axioms HiaCoreSyntaxSlice.linear_bf0494
#print axioms HiaCoreSyntaxSlice.linear_bf0495
#print axioms HiaCoreSyntaxSlice.linear_bf0496
#print axioms HiaCoreSyntaxSlice.linear_bf0497
#print axioms HiaCoreSyntaxSlice.linear_bf0498
#print axioms HiaCoreSyntaxSlice.linear_bf0499
#print axioms HiaCoreSyntaxSlice.linear_bf0500
#print axioms HiaCoreSyntaxSlice.linear_bf0501
#print axioms HiaCoreSyntaxSlice.linear_bf0502
#print axioms HiaCoreSyntaxSlice.linear_bf0503
#print axioms HiaCoreSyntaxSlice.linear_bf0504
#print axioms HiaCoreSyntaxSlice.linear_bf0505
#print axioms HiaCoreSyntaxSlice.linear_bf0506
#print axioms HiaCoreSyntaxSlice.linear_bf0507
#print axioms HiaCoreSyntaxSlice.linear_bf0508
#print axioms HiaCoreSyntaxSlice.linear_bf0509
#print axioms HiaCoreSyntaxSlice.linear_bf0510
#print axioms HiaCoreSyntaxSlice.linear_bf0511
#print axioms HiaCoreSyntaxSlice.linear_bf0512
#print axioms HiaCoreSyntaxSlice.linear_bf0513
#print axioms HiaCoreSyntaxSlice.linear_bf0514
#print axioms HiaCoreSyntaxSlice.linear_bf0515
#print axioms HiaCoreSyntaxSlice.linear_bf0516
#print axioms HiaCoreSyntaxSlice.linear_bf0517
#print axioms HiaCoreSyntaxSlice.linear_bf0518
#print axioms HiaCoreSyntaxSlice.linear_bf0519
#print axioms HiaCoreSyntaxSlice.linear_bf0520
#print axioms HiaCoreSyntaxSlice.linear_bf0521
#print axioms HiaCoreSyntaxSlice.linear_bf0522
#print axioms HiaCoreSyntaxSlice.linear_bf0523
#print axioms HiaCoreSyntaxSlice.linear_bf0524
#print axioms HiaCoreSyntaxSlice.linear_bf0525
#print axioms HiaCoreSyntaxSlice.linear_bf0526
#print axioms HiaCoreSyntaxSlice.linear_bf0527
#print axioms HiaCoreSyntaxSlice.linear_bf0528
#print axioms HiaCoreSyntaxSlice.linear_bf0529
#print axioms HiaCoreSyntaxSlice.linear_bf0530
#print axioms HiaCoreSyntaxSlice.linear_bf0531
#print axioms HiaCoreSyntaxSlice.linear_bf0532
#print axioms HiaCoreSyntaxSlice.linear_bf0533
#print axioms HiaCoreSyntaxSlice.linear_bf0534
#print axioms HiaCoreSyntaxSlice.linear_bf0535
#print axioms HiaCoreSyntaxSlice.linear_bf0536
#print axioms HiaCoreSyntaxSlice.linear_bf0537
#print axioms HiaCoreSyntaxSlice.linear_bf0538
#print axioms HiaCoreSyntaxSlice.linear_bf0539
#print axioms HiaCoreSyntaxSlice.linear_bf0540
#print axioms HiaCoreSyntaxSlice.linear_bf0541
#print axioms HiaCoreSyntaxSlice.linear_bf0542
#print axioms HiaCoreSyntaxSlice.linear_bf0543
#print axioms HiaCoreSyntaxSlice.linear_bf0544
#print axioms HiaCoreSyntaxSlice.linear_bf0545
#print axioms HiaCoreSyntaxSlice.linear_bf0546
#print axioms HiaCoreSyntaxSlice.linear_bf0547
#print axioms HiaCoreSyntaxSlice.linear_bf0548
#print axioms HiaCoreSyntaxSlice.linear_bf0549
#print axioms HiaCoreSyntaxSlice.linear_bf0550
#print axioms HiaCoreSyntaxSlice.linear_bf0551
#print axioms HiaCoreSyntaxSlice.linear_bf0552
#print axioms HiaCoreSyntaxSlice.linear_bf0553
#print axioms HiaCoreSyntaxSlice.linear_bf0554
#print axioms HiaCoreSyntaxSlice.linear_bf0555
#print axioms HiaCoreSyntaxSlice.linear_bf0556
#print axioms HiaCoreSyntaxSlice.linear_bf0557
#print axioms HiaCoreSyntaxSlice.linear_bf0558
#print axioms HiaCoreSyntaxSlice.linear_bf0559
#print axioms HiaCoreSyntaxSlice.linear_bf0560
#print axioms HiaCoreSyntaxSlice.linear_bf0561
#print axioms HiaCoreSyntaxSlice.linear_bf0562
#print axioms HiaCoreSyntaxSlice.linear_bf0563
#print axioms HiaCoreSyntaxSlice.linear_bf0564
#print axioms HiaCoreSyntaxSlice.linear_bf0565
#print axioms HiaCoreSyntaxSlice.linear_bf0566
#print axioms HiaCoreSyntaxSlice.linear_bf0567
#print axioms HiaCoreSyntaxSlice.linear_bf0568
#print axioms HiaCoreSyntaxSlice.linear_bf0569
#print axioms HiaCoreSyntaxSlice.linear_bf0570
#print axioms HiaCoreSyntaxSlice.linear_bf0571
#print axioms HiaCoreSyntaxSlice.linear_bf0572
#print axioms HiaCoreSyntaxSlice.linear_bf0573
#print axioms HiaCoreSyntaxSlice.linear_bf0574
#print axioms HiaCoreSyntaxSlice.linear_bf0575
#print axioms HiaCoreSyntaxSlice.linear_bf0576
#print axioms HiaCoreSyntaxSlice.linear_bf0577
#print axioms HiaCoreSyntaxSlice.linear_bf0578
#print axioms HiaCoreSyntaxSlice.linear_bf0579
#print axioms HiaCoreSyntaxSlice.linear_bf0580
#print axioms HiaCoreSyntaxSlice.linear_bf0581
#print axioms HiaCoreSyntaxSlice.linear_bf0582
#print axioms HiaCoreSyntaxSlice.linear_bf0583
#print axioms HiaCoreSyntaxSlice.linear_bf0584
#print axioms HiaCoreSyntaxSlice.linear_bf0585
#print axioms HiaCoreSyntaxSlice.linear_bf0586
#print axioms HiaCoreSyntaxSlice.linear_bf0587
#print axioms HiaCoreSyntaxSlice.linear_bf0588
#print axioms HiaCoreSyntaxSlice.linear_bf0589
#print axioms HiaCoreSyntaxSlice.linear_bf0590
#print axioms HiaCoreSyntaxSlice.linear_bf0591
#print axioms HiaCoreSyntaxSlice.linear_bf0592
#print axioms HiaCoreSyntaxSlice.linear_bf0593
#print axioms HiaCoreSyntaxSlice.linear_bf0594
#print axioms HiaCoreSyntaxSlice.linear_bounds
#print axioms HiaCoreSyntaxSlice.linear_byte_range
#print axioms HiaCoreSyntaxSlice.linear_length
#print axioms HiaCoreSyntaxSlice.linear_parsed
#print axioms HiaCoreSyntaxSlice.linear_serialized
#print axioms HiaCoreSyntaxSlice.linear_transport
#print axioms HiaCoreSyntaxSlice.parallel_bf0000
#print axioms HiaCoreSyntaxSlice.parallel_bf0001
#print axioms HiaCoreSyntaxSlice.parallel_bf0002
#print axioms HiaCoreSyntaxSlice.parallel_bf0003
#print axioms HiaCoreSyntaxSlice.parallel_bf0004
#print axioms HiaCoreSyntaxSlice.parallel_bf0005
#print axioms HiaCoreSyntaxSlice.parallel_bf0006
#print axioms HiaCoreSyntaxSlice.parallel_bf0007
#print axioms HiaCoreSyntaxSlice.parallel_bf0008
#print axioms HiaCoreSyntaxSlice.parallel_bf0009
#print axioms HiaCoreSyntaxSlice.parallel_bf0010
#print axioms HiaCoreSyntaxSlice.parallel_bf0011
#print axioms HiaCoreSyntaxSlice.parallel_bf0012
#print axioms HiaCoreSyntaxSlice.parallel_bf0013
#print axioms HiaCoreSyntaxSlice.parallel_bf0014
#print axioms HiaCoreSyntaxSlice.parallel_bf0015
#print axioms HiaCoreSyntaxSlice.parallel_bf0016
#print axioms HiaCoreSyntaxSlice.parallel_bf0017
#print axioms HiaCoreSyntaxSlice.parallel_bf0018
#print axioms HiaCoreSyntaxSlice.parallel_bf0019
#print axioms HiaCoreSyntaxSlice.parallel_bf0020
#print axioms HiaCoreSyntaxSlice.parallel_bf0021
#print axioms HiaCoreSyntaxSlice.parallel_bf0022
#print axioms HiaCoreSyntaxSlice.parallel_bf0023
#print axioms HiaCoreSyntaxSlice.parallel_bf0024
#print axioms HiaCoreSyntaxSlice.parallel_bf0025
#print axioms HiaCoreSyntaxSlice.parallel_bf0026
#print axioms HiaCoreSyntaxSlice.parallel_bf0027
#print axioms HiaCoreSyntaxSlice.parallel_bf0028
#print axioms HiaCoreSyntaxSlice.parallel_bf0029
#print axioms HiaCoreSyntaxSlice.parallel_bf0030
#print axioms HiaCoreSyntaxSlice.parallel_bf0031
#print axioms HiaCoreSyntaxSlice.parallel_bf0032
#print axioms HiaCoreSyntaxSlice.parallel_bf0033
#print axioms HiaCoreSyntaxSlice.parallel_bf0034
#print axioms HiaCoreSyntaxSlice.parallel_bf0035
#print axioms HiaCoreSyntaxSlice.parallel_bf0036
#print axioms HiaCoreSyntaxSlice.parallel_bf0037
#print axioms HiaCoreSyntaxSlice.parallel_bf0038
#print axioms HiaCoreSyntaxSlice.parallel_bf0039
#print axioms HiaCoreSyntaxSlice.parallel_bf0040
#print axioms HiaCoreSyntaxSlice.parallel_bf0041
#print axioms HiaCoreSyntaxSlice.parallel_bf0042
#print axioms HiaCoreSyntaxSlice.parallel_bf0043
#print axioms HiaCoreSyntaxSlice.parallel_bf0044
#print axioms HiaCoreSyntaxSlice.parallel_bf0045
#print axioms HiaCoreSyntaxSlice.parallel_bf0046
#print axioms HiaCoreSyntaxSlice.parallel_bf0047
#print axioms HiaCoreSyntaxSlice.parallel_bf0048
#print axioms HiaCoreSyntaxSlice.parallel_bf0049
#print axioms HiaCoreSyntaxSlice.parallel_bf0050
#print axioms HiaCoreSyntaxSlice.parallel_bf0051
#print axioms HiaCoreSyntaxSlice.parallel_bf0052
#print axioms HiaCoreSyntaxSlice.parallel_bf0053
#print axioms HiaCoreSyntaxSlice.parallel_bf0054
#print axioms HiaCoreSyntaxSlice.parallel_bf0055
#print axioms HiaCoreSyntaxSlice.parallel_bf0056
#print axioms HiaCoreSyntaxSlice.parallel_bf0057
#print axioms HiaCoreSyntaxSlice.parallel_bf0058
#print axioms HiaCoreSyntaxSlice.parallel_bf0059
#print axioms HiaCoreSyntaxSlice.parallel_bf0060
#print axioms HiaCoreSyntaxSlice.parallel_bf0061
#print axioms HiaCoreSyntaxSlice.parallel_bf0062
#print axioms HiaCoreSyntaxSlice.parallel_bf0063
#print axioms HiaCoreSyntaxSlice.parallel_bf0064
#print axioms HiaCoreSyntaxSlice.parallel_bf0065
#print axioms HiaCoreSyntaxSlice.parallel_bf0066
#print axioms HiaCoreSyntaxSlice.parallel_bf0067
#print axioms HiaCoreSyntaxSlice.parallel_bf0068
#print axioms HiaCoreSyntaxSlice.parallel_bf0069
#print axioms HiaCoreSyntaxSlice.parallel_bf0070
#print axioms HiaCoreSyntaxSlice.parallel_bf0071
#print axioms HiaCoreSyntaxSlice.parallel_bf0072
#print axioms HiaCoreSyntaxSlice.parallel_bf0073
#print axioms HiaCoreSyntaxSlice.parallel_bf0074
#print axioms HiaCoreSyntaxSlice.parallel_bf0075
#print axioms HiaCoreSyntaxSlice.parallel_bf0076
#print axioms HiaCoreSyntaxSlice.parallel_bf0077
#print axioms HiaCoreSyntaxSlice.parallel_bf0078
#print axioms HiaCoreSyntaxSlice.parallel_bf0079
#print axioms HiaCoreSyntaxSlice.parallel_bf0080
#print axioms HiaCoreSyntaxSlice.parallel_bf0081
#print axioms HiaCoreSyntaxSlice.parallel_bf0082
#print axioms HiaCoreSyntaxSlice.parallel_bf0083
#print axioms HiaCoreSyntaxSlice.parallel_bf0084
#print axioms HiaCoreSyntaxSlice.parallel_bf0085
#print axioms HiaCoreSyntaxSlice.parallel_bf0086
#print axioms HiaCoreSyntaxSlice.parallel_bf0087
#print axioms HiaCoreSyntaxSlice.parallel_bf0088
#print axioms HiaCoreSyntaxSlice.parallel_bf0089
#print axioms HiaCoreSyntaxSlice.parallel_bf0090
#print axioms HiaCoreSyntaxSlice.parallel_bf0091
#print axioms HiaCoreSyntaxSlice.parallel_bf0092
#print axioms HiaCoreSyntaxSlice.parallel_bf0093
#print axioms HiaCoreSyntaxSlice.parallel_bf0094
#print axioms HiaCoreSyntaxSlice.parallel_bf0095
#print axioms HiaCoreSyntaxSlice.parallel_bf0096
#print axioms HiaCoreSyntaxSlice.parallel_bf0097
#print axioms HiaCoreSyntaxSlice.parallel_bf0098
#print axioms HiaCoreSyntaxSlice.parallel_bf0099
#print axioms HiaCoreSyntaxSlice.parallel_bf0100
#print axioms HiaCoreSyntaxSlice.parallel_bf0101
#print axioms HiaCoreSyntaxSlice.parallel_bf0102
#print axioms HiaCoreSyntaxSlice.parallel_bf0103
#print axioms HiaCoreSyntaxSlice.parallel_bf0104
#print axioms HiaCoreSyntaxSlice.parallel_bf0105
#print axioms HiaCoreSyntaxSlice.parallel_bf0106
#print axioms HiaCoreSyntaxSlice.parallel_bf0107
#print axioms HiaCoreSyntaxSlice.parallel_bf0108
#print axioms HiaCoreSyntaxSlice.parallel_bf0109
#print axioms HiaCoreSyntaxSlice.parallel_bf0110
#print axioms HiaCoreSyntaxSlice.parallel_bf0111
#print axioms HiaCoreSyntaxSlice.parallel_bf0112
#print axioms HiaCoreSyntaxSlice.parallel_bf0113
#print axioms HiaCoreSyntaxSlice.parallel_bf0114
#print axioms HiaCoreSyntaxSlice.parallel_bf0115
#print axioms HiaCoreSyntaxSlice.parallel_bf0116
#print axioms HiaCoreSyntaxSlice.parallel_bf0117
#print axioms HiaCoreSyntaxSlice.parallel_bf0118
#print axioms HiaCoreSyntaxSlice.parallel_bf0119
#print axioms HiaCoreSyntaxSlice.parallel_bf0120
#print axioms HiaCoreSyntaxSlice.parallel_bf0121
#print axioms HiaCoreSyntaxSlice.parallel_bf0122
#print axioms HiaCoreSyntaxSlice.parallel_bf0123
#print axioms HiaCoreSyntaxSlice.parallel_bf0124
#print axioms HiaCoreSyntaxSlice.parallel_bf0125
#print axioms HiaCoreSyntaxSlice.parallel_bf0126
#print axioms HiaCoreSyntaxSlice.parallel_bf0127
#print axioms HiaCoreSyntaxSlice.parallel_bf0128
#print axioms HiaCoreSyntaxSlice.parallel_bf0129
#print axioms HiaCoreSyntaxSlice.parallel_bf0130
#print axioms HiaCoreSyntaxSlice.parallel_bf0131
#print axioms HiaCoreSyntaxSlice.parallel_bf0132
#print axioms HiaCoreSyntaxSlice.parallel_bf0133
#print axioms HiaCoreSyntaxSlice.parallel_bf0134
#print axioms HiaCoreSyntaxSlice.parallel_bf0135
#print axioms HiaCoreSyntaxSlice.parallel_bf0136
#print axioms HiaCoreSyntaxSlice.parallel_bf0137
#print axioms HiaCoreSyntaxSlice.parallel_bf0138
#print axioms HiaCoreSyntaxSlice.parallel_bf0139
#print axioms HiaCoreSyntaxSlice.parallel_bf0140
#print axioms HiaCoreSyntaxSlice.parallel_bf0141
#print axioms HiaCoreSyntaxSlice.parallel_bf0142
#print axioms HiaCoreSyntaxSlice.parallel_bf0143
#print axioms HiaCoreSyntaxSlice.parallel_bf0144
#print axioms HiaCoreSyntaxSlice.parallel_bf0145
#print axioms HiaCoreSyntaxSlice.parallel_bf0146
#print axioms HiaCoreSyntaxSlice.parallel_bf0147
#print axioms HiaCoreSyntaxSlice.parallel_bf0148
#print axioms HiaCoreSyntaxSlice.parallel_bf0149
#print axioms HiaCoreSyntaxSlice.parallel_bf0150
#print axioms HiaCoreSyntaxSlice.parallel_bf0151
#print axioms HiaCoreSyntaxSlice.parallel_bf0152
#print axioms HiaCoreSyntaxSlice.parallel_bf0153
#print axioms HiaCoreSyntaxSlice.parallel_bf0154
#print axioms HiaCoreSyntaxSlice.parallel_bf0155
#print axioms HiaCoreSyntaxSlice.parallel_bf0156
#print axioms HiaCoreSyntaxSlice.parallel_bf0157
#print axioms HiaCoreSyntaxSlice.parallel_bf0158
#print axioms HiaCoreSyntaxSlice.parallel_bf0159
#print axioms HiaCoreSyntaxSlice.parallel_bf0160
#print axioms HiaCoreSyntaxSlice.parallel_bf0161
#print axioms HiaCoreSyntaxSlice.parallel_bf0162
#print axioms HiaCoreSyntaxSlice.parallel_bf0163
#print axioms HiaCoreSyntaxSlice.parallel_bf0164
#print axioms HiaCoreSyntaxSlice.parallel_bf0165
#print axioms HiaCoreSyntaxSlice.parallel_bf0166
#print axioms HiaCoreSyntaxSlice.parallel_bf0167
#print axioms HiaCoreSyntaxSlice.parallel_bf0168
#print axioms HiaCoreSyntaxSlice.parallel_bf0169
#print axioms HiaCoreSyntaxSlice.parallel_bf0170
#print axioms HiaCoreSyntaxSlice.parallel_bf0171
#print axioms HiaCoreSyntaxSlice.parallel_bf0172
#print axioms HiaCoreSyntaxSlice.parallel_bf0173
#print axioms HiaCoreSyntaxSlice.parallel_bf0174
#print axioms HiaCoreSyntaxSlice.parallel_bf0175
#print axioms HiaCoreSyntaxSlice.parallel_bf0176
#print axioms HiaCoreSyntaxSlice.parallel_bf0177
#print axioms HiaCoreSyntaxSlice.parallel_bf0178
#print axioms HiaCoreSyntaxSlice.parallel_bf0179
#print axioms HiaCoreSyntaxSlice.parallel_bf0180
#print axioms HiaCoreSyntaxSlice.parallel_bf0181
#print axioms HiaCoreSyntaxSlice.parallel_bf0182
#print axioms HiaCoreSyntaxSlice.parallel_bf0183
#print axioms HiaCoreSyntaxSlice.parallel_bf0184
#print axioms HiaCoreSyntaxSlice.parallel_bf0185
#print axioms HiaCoreSyntaxSlice.parallel_bf0186
#print axioms HiaCoreSyntaxSlice.parallel_bf0187
#print axioms HiaCoreSyntaxSlice.parallel_bf0188
#print axioms HiaCoreSyntaxSlice.parallel_bf0189
#print axioms HiaCoreSyntaxSlice.parallel_bf0190
#print axioms HiaCoreSyntaxSlice.parallel_bf0191
#print axioms HiaCoreSyntaxSlice.parallel_bf0192
#print axioms HiaCoreSyntaxSlice.parallel_bf0193
#print axioms HiaCoreSyntaxSlice.parallel_bf0194
#print axioms HiaCoreSyntaxSlice.parallel_bf0195
#print axioms HiaCoreSyntaxSlice.parallel_bf0196
#print axioms HiaCoreSyntaxSlice.parallel_bf0197
#print axioms HiaCoreSyntaxSlice.parallel_bf0198
#print axioms HiaCoreSyntaxSlice.parallel_bf0199
#print axioms HiaCoreSyntaxSlice.parallel_bf0200
#print axioms HiaCoreSyntaxSlice.parallel_bf0201
#print axioms HiaCoreSyntaxSlice.parallel_bf0202
#print axioms HiaCoreSyntaxSlice.parallel_bf0203
#print axioms HiaCoreSyntaxSlice.parallel_bf0204
#print axioms HiaCoreSyntaxSlice.parallel_bf0205
#print axioms HiaCoreSyntaxSlice.parallel_bf0206
#print axioms HiaCoreSyntaxSlice.parallel_bf0207
#print axioms HiaCoreSyntaxSlice.parallel_bf0208
#print axioms HiaCoreSyntaxSlice.parallel_bf0209
#print axioms HiaCoreSyntaxSlice.parallel_bf0210
#print axioms HiaCoreSyntaxSlice.parallel_bf0211
#print axioms HiaCoreSyntaxSlice.parallel_bf0212
#print axioms HiaCoreSyntaxSlice.parallel_bf0213
#print axioms HiaCoreSyntaxSlice.parallel_bf0214
#print axioms HiaCoreSyntaxSlice.parallel_bf0215
#print axioms HiaCoreSyntaxSlice.parallel_bf0216
#print axioms HiaCoreSyntaxSlice.parallel_bf0217
#print axioms HiaCoreSyntaxSlice.parallel_bf0218
#print axioms HiaCoreSyntaxSlice.parallel_bf0219
#print axioms HiaCoreSyntaxSlice.parallel_bf0220
#print axioms HiaCoreSyntaxSlice.parallel_bf0221
#print axioms HiaCoreSyntaxSlice.parallel_bf0222
#print axioms HiaCoreSyntaxSlice.parallel_bf0223
#print axioms HiaCoreSyntaxSlice.parallel_bf0224
#print axioms HiaCoreSyntaxSlice.parallel_bf0225
#print axioms HiaCoreSyntaxSlice.parallel_bf0226
#print axioms HiaCoreSyntaxSlice.parallel_bf0227
#print axioms HiaCoreSyntaxSlice.parallel_bf0228
#print axioms HiaCoreSyntaxSlice.parallel_bf0229
#print axioms HiaCoreSyntaxSlice.parallel_bf0230
#print axioms HiaCoreSyntaxSlice.parallel_bf0231
#print axioms HiaCoreSyntaxSlice.parallel_bf0232
#print axioms HiaCoreSyntaxSlice.parallel_bf0233
#print axioms HiaCoreSyntaxSlice.parallel_bf0234
#print axioms HiaCoreSyntaxSlice.parallel_bf0235
#print axioms HiaCoreSyntaxSlice.parallel_bf0236
#print axioms HiaCoreSyntaxSlice.parallel_bf0237
#print axioms HiaCoreSyntaxSlice.parallel_bf0238
#print axioms HiaCoreSyntaxSlice.parallel_bf0239
#print axioms HiaCoreSyntaxSlice.parallel_bf0240
#print axioms HiaCoreSyntaxSlice.parallel_bf0241
#print axioms HiaCoreSyntaxSlice.parallel_bf0242
#print axioms HiaCoreSyntaxSlice.parallel_bf0243
#print axioms HiaCoreSyntaxSlice.parallel_bf0244
#print axioms HiaCoreSyntaxSlice.parallel_bf0245
#print axioms HiaCoreSyntaxSlice.parallel_bf0246
#print axioms HiaCoreSyntaxSlice.parallel_bf0247
#print axioms HiaCoreSyntaxSlice.parallel_bf0248
#print axioms HiaCoreSyntaxSlice.parallel_bf0249
#print axioms HiaCoreSyntaxSlice.parallel_bf0250
#print axioms HiaCoreSyntaxSlice.parallel_bf0251
#print axioms HiaCoreSyntaxSlice.parallel_bf0252
#print axioms HiaCoreSyntaxSlice.parallel_bf0253
#print axioms HiaCoreSyntaxSlice.parallel_bf0254
#print axioms HiaCoreSyntaxSlice.parallel_bf0255
#print axioms HiaCoreSyntaxSlice.parallel_bf0256
#print axioms HiaCoreSyntaxSlice.parallel_bf0257
#print axioms HiaCoreSyntaxSlice.parallel_bf0258
#print axioms HiaCoreSyntaxSlice.parallel_bf0259
#print axioms HiaCoreSyntaxSlice.parallel_bf0260
#print axioms HiaCoreSyntaxSlice.parallel_bf0261
#print axioms HiaCoreSyntaxSlice.parallel_bf0262
#print axioms HiaCoreSyntaxSlice.parallel_bf0263
#print axioms HiaCoreSyntaxSlice.parallel_bf0264
#print axioms HiaCoreSyntaxSlice.parallel_bf0265
#print axioms HiaCoreSyntaxSlice.parallel_bf0266
#print axioms HiaCoreSyntaxSlice.parallel_bf0267
#print axioms HiaCoreSyntaxSlice.parallel_bf0268
#print axioms HiaCoreSyntaxSlice.parallel_bf0269
#print axioms HiaCoreSyntaxSlice.parallel_bf0270
#print axioms HiaCoreSyntaxSlice.parallel_bf0271
#print axioms HiaCoreSyntaxSlice.parallel_bf0272
#print axioms HiaCoreSyntaxSlice.parallel_bf0273
#print axioms HiaCoreSyntaxSlice.parallel_bf0274
#print axioms HiaCoreSyntaxSlice.parallel_bf0275
#print axioms HiaCoreSyntaxSlice.parallel_bf0276
#print axioms HiaCoreSyntaxSlice.parallel_bf0277
#print axioms HiaCoreSyntaxSlice.parallel_bf0278
#print axioms HiaCoreSyntaxSlice.parallel_bf0279
#print axioms HiaCoreSyntaxSlice.parallel_bf0280
#print axioms HiaCoreSyntaxSlice.parallel_bf0281
#print axioms HiaCoreSyntaxSlice.parallel_bf0282
#print axioms HiaCoreSyntaxSlice.parallel_bf0283
#print axioms HiaCoreSyntaxSlice.parallel_bf0284
#print axioms HiaCoreSyntaxSlice.parallel_bf0285
#print axioms HiaCoreSyntaxSlice.parallel_bf0286
#print axioms HiaCoreSyntaxSlice.parallel_bf0287
#print axioms HiaCoreSyntaxSlice.parallel_bf0288
#print axioms HiaCoreSyntaxSlice.parallel_bf0289
#print axioms HiaCoreSyntaxSlice.parallel_bf0290
#print axioms HiaCoreSyntaxSlice.parallel_bf0291
#print axioms HiaCoreSyntaxSlice.parallel_bf0292
#print axioms HiaCoreSyntaxSlice.parallel_bf0293
#print axioms HiaCoreSyntaxSlice.parallel_bf0294
#print axioms HiaCoreSyntaxSlice.parallel_bf0295
#print axioms HiaCoreSyntaxSlice.parallel_bf0296
#print axioms HiaCoreSyntaxSlice.parallel_bf0297
#print axioms HiaCoreSyntaxSlice.parallel_bf0298
#print axioms HiaCoreSyntaxSlice.parallel_bf0299
#print axioms HiaCoreSyntaxSlice.parallel_bf0300
#print axioms HiaCoreSyntaxSlice.parallel_bf0301
#print axioms HiaCoreSyntaxSlice.parallel_bf0302
#print axioms HiaCoreSyntaxSlice.parallel_bf0303
#print axioms HiaCoreSyntaxSlice.parallel_bf0304
#print axioms HiaCoreSyntaxSlice.parallel_bf0305
#print axioms HiaCoreSyntaxSlice.parallel_bf0306
#print axioms HiaCoreSyntaxSlice.parallel_bf0307
#print axioms HiaCoreSyntaxSlice.parallel_bf0308
#print axioms HiaCoreSyntaxSlice.parallel_bf0309
#print axioms HiaCoreSyntaxSlice.parallel_bf0310
#print axioms HiaCoreSyntaxSlice.parallel_bf0311
#print axioms HiaCoreSyntaxSlice.parallel_bf0312
#print axioms HiaCoreSyntaxSlice.parallel_bf0313
#print axioms HiaCoreSyntaxSlice.parallel_bf0314
#print axioms HiaCoreSyntaxSlice.parallel_bf0315
#print axioms HiaCoreSyntaxSlice.parallel_bf0316
#print axioms HiaCoreSyntaxSlice.parallel_bf0317
#print axioms HiaCoreSyntaxSlice.parallel_bf0318
#print axioms HiaCoreSyntaxSlice.parallel_bf0319
#print axioms HiaCoreSyntaxSlice.parallel_bf0320
#print axioms HiaCoreSyntaxSlice.parallel_bf0321
#print axioms HiaCoreSyntaxSlice.parallel_bf0322
#print axioms HiaCoreSyntaxSlice.parallel_bf0323
#print axioms HiaCoreSyntaxSlice.parallel_bf0324
#print axioms HiaCoreSyntaxSlice.parallel_bf0325
#print axioms HiaCoreSyntaxSlice.parallel_bf0326
#print axioms HiaCoreSyntaxSlice.parallel_bf0327
#print axioms HiaCoreSyntaxSlice.parallel_bf0328
#print axioms HiaCoreSyntaxSlice.parallel_bf0329
#print axioms HiaCoreSyntaxSlice.parallel_bf0330
#print axioms HiaCoreSyntaxSlice.parallel_bf0331
#print axioms HiaCoreSyntaxSlice.parallel_bf0332
#print axioms HiaCoreSyntaxSlice.parallel_bf0333
#print axioms HiaCoreSyntaxSlice.parallel_bf0334
#print axioms HiaCoreSyntaxSlice.parallel_bf0335
#print axioms HiaCoreSyntaxSlice.parallel_bf0336
#print axioms HiaCoreSyntaxSlice.parallel_bf0337
#print axioms HiaCoreSyntaxSlice.parallel_bf0338
#print axioms HiaCoreSyntaxSlice.parallel_bf0339
#print axioms HiaCoreSyntaxSlice.parallel_bf0340
#print axioms HiaCoreSyntaxSlice.parallel_bf0341
#print axioms HiaCoreSyntaxSlice.parallel_bf0342
#print axioms HiaCoreSyntaxSlice.parallel_bf0343
#print axioms HiaCoreSyntaxSlice.parallel_bf0344
#print axioms HiaCoreSyntaxSlice.parallel_bf0345
#print axioms HiaCoreSyntaxSlice.parallel_bf0346
#print axioms HiaCoreSyntaxSlice.parallel_bf0347
#print axioms HiaCoreSyntaxSlice.parallel_bf0348
#print axioms HiaCoreSyntaxSlice.parallel_bf0349
#print axioms HiaCoreSyntaxSlice.parallel_bf0350
#print axioms HiaCoreSyntaxSlice.parallel_bf0351
#print axioms HiaCoreSyntaxSlice.parallel_bf0352
#print axioms HiaCoreSyntaxSlice.parallel_bf0353
#print axioms HiaCoreSyntaxSlice.parallel_bf0354
#print axioms HiaCoreSyntaxSlice.parallel_bf0355
#print axioms HiaCoreSyntaxSlice.parallel_bf0356
#print axioms HiaCoreSyntaxSlice.parallel_bf0357
#print axioms HiaCoreSyntaxSlice.parallel_bf0358
#print axioms HiaCoreSyntaxSlice.parallel_bf0359
#print axioms HiaCoreSyntaxSlice.parallel_bf0360
#print axioms HiaCoreSyntaxSlice.parallel_bf0361
#print axioms HiaCoreSyntaxSlice.parallel_bf0362
#print axioms HiaCoreSyntaxSlice.parallel_bf0363
#print axioms HiaCoreSyntaxSlice.parallel_bf0364
#print axioms HiaCoreSyntaxSlice.parallel_bf0365
#print axioms HiaCoreSyntaxSlice.parallel_bf0366
#print axioms HiaCoreSyntaxSlice.parallel_bf0367
#print axioms HiaCoreSyntaxSlice.parallel_bf0368
#print axioms HiaCoreSyntaxSlice.parallel_bf0369
#print axioms HiaCoreSyntaxSlice.parallel_bf0370
#print axioms HiaCoreSyntaxSlice.parallel_bf0371
#print axioms HiaCoreSyntaxSlice.parallel_bf0372
#print axioms HiaCoreSyntaxSlice.parallel_bf0373
#print axioms HiaCoreSyntaxSlice.parallel_bf0374
#print axioms HiaCoreSyntaxSlice.parallel_bf0375
#print axioms HiaCoreSyntaxSlice.parallel_bf0376
#print axioms HiaCoreSyntaxSlice.parallel_bf0377
#print axioms HiaCoreSyntaxSlice.parallel_bf0378
#print axioms HiaCoreSyntaxSlice.parallel_bf0379
#print axioms HiaCoreSyntaxSlice.parallel_bf0380
#print axioms HiaCoreSyntaxSlice.parallel_bf0381
#print axioms HiaCoreSyntaxSlice.parallel_bf0382
#print axioms HiaCoreSyntaxSlice.parallel_bf0383
#print axioms HiaCoreSyntaxSlice.parallel_bf0384
#print axioms HiaCoreSyntaxSlice.parallel_bf0385
#print axioms HiaCoreSyntaxSlice.parallel_bf0386
#print axioms HiaCoreSyntaxSlice.parallel_bf0387
#print axioms HiaCoreSyntaxSlice.parallel_bf0388
#print axioms HiaCoreSyntaxSlice.parallel_bf0389
#print axioms HiaCoreSyntaxSlice.parallel_bf0390
#print axioms HiaCoreSyntaxSlice.parallel_bf0391
#print axioms HiaCoreSyntaxSlice.parallel_bf0392
#print axioms HiaCoreSyntaxSlice.parallel_bf0393
#print axioms HiaCoreSyntaxSlice.parallel_bf0394
#print axioms HiaCoreSyntaxSlice.parallel_bf0395
#print axioms HiaCoreSyntaxSlice.parallel_bf0396
#print axioms HiaCoreSyntaxSlice.parallel_bf0397
#print axioms HiaCoreSyntaxSlice.parallel_bf0398
#print axioms HiaCoreSyntaxSlice.parallel_bf0399
#print axioms HiaCoreSyntaxSlice.parallel_bf0400
#print axioms HiaCoreSyntaxSlice.parallel_bf0401
#print axioms HiaCoreSyntaxSlice.parallel_bf0402
#print axioms HiaCoreSyntaxSlice.parallel_bf0403
#print axioms HiaCoreSyntaxSlice.parallel_bf0404
#print axioms HiaCoreSyntaxSlice.parallel_bf0405
#print axioms HiaCoreSyntaxSlice.parallel_bf0406
#print axioms HiaCoreSyntaxSlice.parallel_bf0407
#print axioms HiaCoreSyntaxSlice.parallel_bf0408
#print axioms HiaCoreSyntaxSlice.parallel_bf0409
#print axioms HiaCoreSyntaxSlice.parallel_bf0410
#print axioms HiaCoreSyntaxSlice.parallel_bf0411
#print axioms HiaCoreSyntaxSlice.parallel_bf0412
#print axioms HiaCoreSyntaxSlice.parallel_bf0413
#print axioms HiaCoreSyntaxSlice.parallel_bf0414
#print axioms HiaCoreSyntaxSlice.parallel_bf0415
#print axioms HiaCoreSyntaxSlice.parallel_bf0416
#print axioms HiaCoreSyntaxSlice.parallel_bf0417
#print axioms HiaCoreSyntaxSlice.parallel_bf0418
#print axioms HiaCoreSyntaxSlice.parallel_bf0419
#print axioms HiaCoreSyntaxSlice.parallel_bf0420
#print axioms HiaCoreSyntaxSlice.parallel_bf0421
#print axioms HiaCoreSyntaxSlice.parallel_bf0422
#print axioms HiaCoreSyntaxSlice.parallel_bf0423
#print axioms HiaCoreSyntaxSlice.parallel_bf0424
#print axioms HiaCoreSyntaxSlice.parallel_bf0425
#print axioms HiaCoreSyntaxSlice.parallel_bf0426
#print axioms HiaCoreSyntaxSlice.parallel_bf0427
#print axioms HiaCoreSyntaxSlice.parallel_bf0428
#print axioms HiaCoreSyntaxSlice.parallel_bf0429
#print axioms HiaCoreSyntaxSlice.parallel_bf0430
#print axioms HiaCoreSyntaxSlice.parallel_bf0431
#print axioms HiaCoreSyntaxSlice.parallel_bf0432
#print axioms HiaCoreSyntaxSlice.parallel_bf0433
#print axioms HiaCoreSyntaxSlice.parallel_bf0434
#print axioms HiaCoreSyntaxSlice.parallel_bf0435
#print axioms HiaCoreSyntaxSlice.parallel_bf0436
#print axioms HiaCoreSyntaxSlice.parallel_bf0437
#print axioms HiaCoreSyntaxSlice.parallel_bf0438
#print axioms HiaCoreSyntaxSlice.parallel_bf0439
#print axioms HiaCoreSyntaxSlice.parallel_bf0440
#print axioms HiaCoreSyntaxSlice.parallel_bf0441
#print axioms HiaCoreSyntaxSlice.parallel_bf0442
#print axioms HiaCoreSyntaxSlice.parallel_bf0443
#print axioms HiaCoreSyntaxSlice.parallel_bf0444
#print axioms HiaCoreSyntaxSlice.parallel_bf0445
#print axioms HiaCoreSyntaxSlice.parallel_bf0446
#print axioms HiaCoreSyntaxSlice.parallel_bf0447
#print axioms HiaCoreSyntaxSlice.parallel_bf0448
#print axioms HiaCoreSyntaxSlice.parallel_bf0449
#print axioms HiaCoreSyntaxSlice.parallel_bf0450
#print axioms HiaCoreSyntaxSlice.parallel_bf0451
#print axioms HiaCoreSyntaxSlice.parallel_bf0452
#print axioms HiaCoreSyntaxSlice.parallel_bf0453
#print axioms HiaCoreSyntaxSlice.parallel_bf0454
#print axioms HiaCoreSyntaxSlice.parallel_bf0455
#print axioms HiaCoreSyntaxSlice.parallel_bf0456
#print axioms HiaCoreSyntaxSlice.parallel_bf0457
#print axioms HiaCoreSyntaxSlice.parallel_bf0458
#print axioms HiaCoreSyntaxSlice.parallel_bf0459
#print axioms HiaCoreSyntaxSlice.parallel_bf0460
#print axioms HiaCoreSyntaxSlice.parallel_bf0461
#print axioms HiaCoreSyntaxSlice.parallel_bf0462
#print axioms HiaCoreSyntaxSlice.parallel_bf0463
#print axioms HiaCoreSyntaxSlice.parallel_bf0464
#print axioms HiaCoreSyntaxSlice.parallel_bf0465
#print axioms HiaCoreSyntaxSlice.parallel_bf0466
#print axioms HiaCoreSyntaxSlice.parallel_bf0467
#print axioms HiaCoreSyntaxSlice.parallel_bf0468
#print axioms HiaCoreSyntaxSlice.parallel_bf0469
#print axioms HiaCoreSyntaxSlice.parallel_bf0470
#print axioms HiaCoreSyntaxSlice.parallel_bf0471
#print axioms HiaCoreSyntaxSlice.parallel_bf0472
#print axioms HiaCoreSyntaxSlice.parallel_bf0473
#print axioms HiaCoreSyntaxSlice.parallel_bf0474
#print axioms HiaCoreSyntaxSlice.parallel_bf0475
#print axioms HiaCoreSyntaxSlice.parallel_bf0476
#print axioms HiaCoreSyntaxSlice.parallel_bf0477
#print axioms HiaCoreSyntaxSlice.parallel_bf0478
#print axioms HiaCoreSyntaxSlice.parallel_bf0479
#print axioms HiaCoreSyntaxSlice.parallel_bf0480
#print axioms HiaCoreSyntaxSlice.parallel_bf0481
#print axioms HiaCoreSyntaxSlice.parallel_bf0482
#print axioms HiaCoreSyntaxSlice.parallel_bf0483
#print axioms HiaCoreSyntaxSlice.parallel_bf0484
#print axioms HiaCoreSyntaxSlice.parallel_bf0485
#print axioms HiaCoreSyntaxSlice.parallel_bf0486
#print axioms HiaCoreSyntaxSlice.parallel_bf0487
#print axioms HiaCoreSyntaxSlice.parallel_bf0488
#print axioms HiaCoreSyntaxSlice.parallel_bf0489
#print axioms HiaCoreSyntaxSlice.parallel_bf0490
#print axioms HiaCoreSyntaxSlice.parallel_kd10_0
#print axioms HiaCoreSyntaxSlice.parallel_kd10_1
#print axioms HiaCoreSyntaxSlice.parallel_kd10_2
#print axioms HiaCoreSyntaxSlice.parallel_kd10_3
#print axioms HiaCoreSyntaxSlice.parallel_kd113_0
#print axioms HiaCoreSyntaxSlice.parallel_kd113_1
#print axioms HiaCoreSyntaxSlice.parallel_kd113_2
#print axioms HiaCoreSyntaxSlice.parallel_kd113_3
#print axioms HiaCoreSyntaxSlice.parallel_kd15_0
#print axioms HiaCoreSyntaxSlice.parallel_kd15_1
#print axioms HiaCoreSyntaxSlice.parallel_kd15_2
#print axioms HiaCoreSyntaxSlice.parallel_kd15_3
#print axioms HiaCoreSyntaxSlice.parallel_kd24_0
#print axioms HiaCoreSyntaxSlice.parallel_kd24_1
#print axioms HiaCoreSyntaxSlice.parallel_kd24_2
#print axioms HiaCoreSyntaxSlice.parallel_kd24_3
#print axioms HiaCoreSyntaxSlice.parallel_kd29_0
#print axioms HiaCoreSyntaxSlice.parallel_kd29_1
#print axioms HiaCoreSyntaxSlice.parallel_kd29_2
#print axioms HiaCoreSyntaxSlice.parallel_kd29_3
#print axioms HiaCoreSyntaxSlice.parallel_kd34_0
#print axioms HiaCoreSyntaxSlice.parallel_kd34_1
#print axioms HiaCoreSyntaxSlice.parallel_kd34_2
#print axioms HiaCoreSyntaxSlice.parallel_kd34_3
#print axioms HiaCoreSyntaxSlice.parallel_kd39_0
#print axioms HiaCoreSyntaxSlice.parallel_kd39_1
#print axioms HiaCoreSyntaxSlice.parallel_kd39_2
#print axioms HiaCoreSyntaxSlice.parallel_kd39_3
#print axioms HiaCoreSyntaxSlice.parallel_kd44_0
#print axioms HiaCoreSyntaxSlice.parallel_kd44_1
#print axioms HiaCoreSyntaxSlice.parallel_kd44_2
#print axioms HiaCoreSyntaxSlice.parallel_kd44_3
#print axioms HiaCoreSyntaxSlice.parallel_kd49_0
#print axioms HiaCoreSyntaxSlice.parallel_kd49_1
#print axioms HiaCoreSyntaxSlice.parallel_kd49_2
#print axioms HiaCoreSyntaxSlice.parallel_kd49_3
#print axioms HiaCoreSyntaxSlice.parallel_kd5_0
#print axioms HiaCoreSyntaxSlice.parallel_kd5_1
#print axioms HiaCoreSyntaxSlice.parallel_kd5_2
#print axioms HiaCoreSyntaxSlice.parallel_kd5_3
#print axioms HiaCoreSyntaxSlice.parallel_kd65_0
#print axioms HiaCoreSyntaxSlice.parallel_kd65_1
#print axioms HiaCoreSyntaxSlice.parallel_kd65_2
#print axioms HiaCoreSyntaxSlice.parallel_kd65_3
#print axioms HiaCoreSyntaxSlice.parallel_kd70_0
#print axioms HiaCoreSyntaxSlice.parallel_kd70_1
#print axioms HiaCoreSyntaxSlice.parallel_kd70_2
#print axioms HiaCoreSyntaxSlice.parallel_kd70_3
#print axioms HiaCoreSyntaxSlice.parallel_kd75_0
#print axioms HiaCoreSyntaxSlice.parallel_kd75_1
#print axioms HiaCoreSyntaxSlice.parallel_kd75_2
#print axioms HiaCoreSyntaxSlice.parallel_kd75_3
#print axioms HiaCoreSyntaxSlice.parallel_kd87_0
#print axioms HiaCoreSyntaxSlice.parallel_kd87_1
#print axioms HiaCoreSyntaxSlice.parallel_kd87_2
#print axioms HiaCoreSyntaxSlice.parallel_kd87_3
#print axioms HiaCoreSyntaxSlice.parallel_kd92_0
#print axioms HiaCoreSyntaxSlice.parallel_kd92_1
#print axioms HiaCoreSyntaxSlice.parallel_kd92_2
#print axioms HiaCoreSyntaxSlice.parallel_kd92_3
#print axioms HiaCoreSyntaxSlice.parallel_kd97_0
#print axioms HiaCoreSyntaxSlice.parallel_kd97_1
#print axioms HiaCoreSyntaxSlice.parallel_kd97_2
#print axioms HiaCoreSyntaxSlice.parallel_kd97_3
#print axioms HiaCoreSyntaxSlice.parallel_kp10_0
#print axioms HiaCoreSyntaxSlice.parallel_kp10_1
#print axioms HiaCoreSyntaxSlice.parallel_kp10_2
#print axioms HiaCoreSyntaxSlice.parallel_kp10_3
#print axioms HiaCoreSyntaxSlice.parallel_kp113_0
#print axioms HiaCoreSyntaxSlice.parallel_kp113_1
#print axioms HiaCoreSyntaxSlice.parallel_kp113_2
#print axioms HiaCoreSyntaxSlice.parallel_kp113_3
#print axioms HiaCoreSyntaxSlice.parallel_kp15_0
#print axioms HiaCoreSyntaxSlice.parallel_kp15_1
#print axioms HiaCoreSyntaxSlice.parallel_kp15_2
#print axioms HiaCoreSyntaxSlice.parallel_kp15_3
#print axioms HiaCoreSyntaxSlice.parallel_kp24_0
#print axioms HiaCoreSyntaxSlice.parallel_kp24_1
#print axioms HiaCoreSyntaxSlice.parallel_kp24_2
#print axioms HiaCoreSyntaxSlice.parallel_kp24_3
#print axioms HiaCoreSyntaxSlice.parallel_kp29_0
#print axioms HiaCoreSyntaxSlice.parallel_kp29_1
#print axioms HiaCoreSyntaxSlice.parallel_kp29_2
#print axioms HiaCoreSyntaxSlice.parallel_kp29_3
#print axioms HiaCoreSyntaxSlice.parallel_kp34_0
#print axioms HiaCoreSyntaxSlice.parallel_kp34_1
#print axioms HiaCoreSyntaxSlice.parallel_kp34_2
#print axioms HiaCoreSyntaxSlice.parallel_kp34_3
#print axioms HiaCoreSyntaxSlice.parallel_kp39_0
#print axioms HiaCoreSyntaxSlice.parallel_kp39_1
#print axioms HiaCoreSyntaxSlice.parallel_kp39_2
#print axioms HiaCoreSyntaxSlice.parallel_kp39_3
#print axioms HiaCoreSyntaxSlice.parallel_kp44_0
#print axioms HiaCoreSyntaxSlice.parallel_kp44_1
#print axioms HiaCoreSyntaxSlice.parallel_kp44_2
#print axioms HiaCoreSyntaxSlice.parallel_kp44_3
#print axioms HiaCoreSyntaxSlice.parallel_kp49_0
#print axioms HiaCoreSyntaxSlice.parallel_kp49_1
#print axioms HiaCoreSyntaxSlice.parallel_kp49_2
#print axioms HiaCoreSyntaxSlice.parallel_kp49_3
#print axioms HiaCoreSyntaxSlice.parallel_kp5_0
#print axioms HiaCoreSyntaxSlice.parallel_kp5_1
#print axioms HiaCoreSyntaxSlice.parallel_kp5_2
#print axioms HiaCoreSyntaxSlice.parallel_kp5_3
#print axioms HiaCoreSyntaxSlice.parallel_kp65_0
#print axioms HiaCoreSyntaxSlice.parallel_kp65_1
#print axioms HiaCoreSyntaxSlice.parallel_kp65_2
#print axioms HiaCoreSyntaxSlice.parallel_kp65_3
#print axioms HiaCoreSyntaxSlice.parallel_kp70_0
#print axioms HiaCoreSyntaxSlice.parallel_kp70_1
#print axioms HiaCoreSyntaxSlice.parallel_kp70_2
#print axioms HiaCoreSyntaxSlice.parallel_kp70_3
#print axioms HiaCoreSyntaxSlice.parallel_kp75_0
#print axioms HiaCoreSyntaxSlice.parallel_kp75_1
#print axioms HiaCoreSyntaxSlice.parallel_kp75_2
#print axioms HiaCoreSyntaxSlice.parallel_kp75_3
#print axioms HiaCoreSyntaxSlice.parallel_kp87_0
#print axioms HiaCoreSyntaxSlice.parallel_kp87_1
#print axioms HiaCoreSyntaxSlice.parallel_kp87_2
#print axioms HiaCoreSyntaxSlice.parallel_kp87_3
#print axioms HiaCoreSyntaxSlice.parallel_kp92_0
#print axioms HiaCoreSyntaxSlice.parallel_kp92_1
#print axioms HiaCoreSyntaxSlice.parallel_kp92_2
#print axioms HiaCoreSyntaxSlice.parallel_kp92_3
#print axioms HiaCoreSyntaxSlice.parallel_kp97_0
#print axioms HiaCoreSyntaxSlice.parallel_kp97_1
#print axioms HiaCoreSyntaxSlice.parallel_kp97_2
#print axioms HiaCoreSyntaxSlice.parallel_kp97_3
#print axioms HiaCoreSyntaxSlice.parallel_o10
#print axioms HiaCoreSyntaxSlice.parallel_o15
#print axioms HiaCoreSyntaxSlice.parallel_o24
#print axioms HiaCoreSyntaxSlice.parallel_o29
#print axioms HiaCoreSyntaxSlice.parallel_o34
#print axioms HiaCoreSyntaxSlice.parallel_o39
#print axioms HiaCoreSyntaxSlice.parallel_o44
#print axioms HiaCoreSyntaxSlice.parallel_o49
#print axioms HiaCoreSyntaxSlice.parallel_o5
#print axioms HiaCoreSyntaxSlice.parallel_o65
#print axioms HiaCoreSyntaxSlice.parallel_o70
#print axioms HiaCoreSyntaxSlice.parallel_o75
#print axioms HiaCoreSyntaxSlice.parallel_o87
#print axioms HiaCoreSyntaxSlice.parallel_o92
#print axioms HiaCoreSyntaxSlice.parallel_o97
#print axioms HiaCoreSyntaxSlice.parallel_p1
#print axioms HiaCoreSyntaxSlice.parallel_p10
#print axioms HiaCoreSyntaxSlice.parallel_p100
#print axioms HiaCoreSyntaxSlice.parallel_p101
#print axioms HiaCoreSyntaxSlice.parallel_p102
#print axioms HiaCoreSyntaxSlice.parallel_p103
#print axioms HiaCoreSyntaxSlice.parallel_p104
#print axioms HiaCoreSyntaxSlice.parallel_p105
#print axioms HiaCoreSyntaxSlice.parallel_p106
#print axioms HiaCoreSyntaxSlice.parallel_p107
#print axioms HiaCoreSyntaxSlice.parallel_p108
#print axioms HiaCoreSyntaxSlice.parallel_p109
#print axioms HiaCoreSyntaxSlice.parallel_p11
#print axioms HiaCoreSyntaxSlice.parallel_p110
#print axioms HiaCoreSyntaxSlice.parallel_p111
#print axioms HiaCoreSyntaxSlice.parallel_p112
#print axioms HiaCoreSyntaxSlice.parallel_p114
#print axioms HiaCoreSyntaxSlice.parallel_p115
#print axioms HiaCoreSyntaxSlice.parallel_p116
#print axioms HiaCoreSyntaxSlice.parallel_p117
#print axioms HiaCoreSyntaxSlice.parallel_p12
#print axioms HiaCoreSyntaxSlice.parallel_p13
#print axioms HiaCoreSyntaxSlice.parallel_p14
#print axioms HiaCoreSyntaxSlice.parallel_p15
#print axioms HiaCoreSyntaxSlice.parallel_p16
#print axioms HiaCoreSyntaxSlice.parallel_p17
#print axioms HiaCoreSyntaxSlice.parallel_p18
#print axioms HiaCoreSyntaxSlice.parallel_p19
#print axioms HiaCoreSyntaxSlice.parallel_p20
#print axioms HiaCoreSyntaxSlice.parallel_p21
#print axioms HiaCoreSyntaxSlice.parallel_p22
#print axioms HiaCoreSyntaxSlice.parallel_p23
#print axioms HiaCoreSyntaxSlice.parallel_p24
#print axioms HiaCoreSyntaxSlice.parallel_p25
#print axioms HiaCoreSyntaxSlice.parallel_p26
#print axioms HiaCoreSyntaxSlice.parallel_p27
#print axioms HiaCoreSyntaxSlice.parallel_p28
#print axioms HiaCoreSyntaxSlice.parallel_p29
#print axioms HiaCoreSyntaxSlice.parallel_p30
#print axioms HiaCoreSyntaxSlice.parallel_p31
#print axioms HiaCoreSyntaxSlice.parallel_p32
#print axioms HiaCoreSyntaxSlice.parallel_p33
#print axioms HiaCoreSyntaxSlice.parallel_p34
#print axioms HiaCoreSyntaxSlice.parallel_p35
#print axioms HiaCoreSyntaxSlice.parallel_p36
#print axioms HiaCoreSyntaxSlice.parallel_p37
#print axioms HiaCoreSyntaxSlice.parallel_p38
#print axioms HiaCoreSyntaxSlice.parallel_p39
#print axioms HiaCoreSyntaxSlice.parallel_p40
#print axioms HiaCoreSyntaxSlice.parallel_p41
#print axioms HiaCoreSyntaxSlice.parallel_p42
#print axioms HiaCoreSyntaxSlice.parallel_p43
#print axioms HiaCoreSyntaxSlice.parallel_p44
#print axioms HiaCoreSyntaxSlice.parallel_p45
#print axioms HiaCoreSyntaxSlice.parallel_p46
#print axioms HiaCoreSyntaxSlice.parallel_p47
#print axioms HiaCoreSyntaxSlice.parallel_p48
#print axioms HiaCoreSyntaxSlice.parallel_p49
#print axioms HiaCoreSyntaxSlice.parallel_p5
#print axioms HiaCoreSyntaxSlice.parallel_p50
#print axioms HiaCoreSyntaxSlice.parallel_p51
#print axioms HiaCoreSyntaxSlice.parallel_p52
#print axioms HiaCoreSyntaxSlice.parallel_p53
#print axioms HiaCoreSyntaxSlice.parallel_p54
#print axioms HiaCoreSyntaxSlice.parallel_p55
#print axioms HiaCoreSyntaxSlice.parallel_p56
#print axioms HiaCoreSyntaxSlice.parallel_p57
#print axioms HiaCoreSyntaxSlice.parallel_p58
#print axioms HiaCoreSyntaxSlice.parallel_p59
#print axioms HiaCoreSyntaxSlice.parallel_p6
#print axioms HiaCoreSyntaxSlice.parallel_p60
#print axioms HiaCoreSyntaxSlice.parallel_p61
#print axioms HiaCoreSyntaxSlice.parallel_p62
#print axioms HiaCoreSyntaxSlice.parallel_p63
#print axioms HiaCoreSyntaxSlice.parallel_p64
#print axioms HiaCoreSyntaxSlice.parallel_p65
#print axioms HiaCoreSyntaxSlice.parallel_p66
#print axioms HiaCoreSyntaxSlice.parallel_p67
#print axioms HiaCoreSyntaxSlice.parallel_p68
#print axioms HiaCoreSyntaxSlice.parallel_p69
#print axioms HiaCoreSyntaxSlice.parallel_p7
#print axioms HiaCoreSyntaxSlice.parallel_p70
#print axioms HiaCoreSyntaxSlice.parallel_p71
#print axioms HiaCoreSyntaxSlice.parallel_p72
#print axioms HiaCoreSyntaxSlice.parallel_p73
#print axioms HiaCoreSyntaxSlice.parallel_p74
#print axioms HiaCoreSyntaxSlice.parallel_p75
#print axioms HiaCoreSyntaxSlice.parallel_p76
#print axioms HiaCoreSyntaxSlice.parallel_p77
#print axioms HiaCoreSyntaxSlice.parallel_p78
#print axioms HiaCoreSyntaxSlice.parallel_p79
#print axioms HiaCoreSyntaxSlice.parallel_p8
#print axioms HiaCoreSyntaxSlice.parallel_p80
#print axioms HiaCoreSyntaxSlice.parallel_p81
#print axioms HiaCoreSyntaxSlice.parallel_p82
#print axioms HiaCoreSyntaxSlice.parallel_p83
#print axioms HiaCoreSyntaxSlice.parallel_p84
#print axioms HiaCoreSyntaxSlice.parallel_p85
#print axioms HiaCoreSyntaxSlice.parallel_p86
#print axioms HiaCoreSyntaxSlice.parallel_p87
#print axioms HiaCoreSyntaxSlice.parallel_p88
#print axioms HiaCoreSyntaxSlice.parallel_p89
#print axioms HiaCoreSyntaxSlice.parallel_p9
#print axioms HiaCoreSyntaxSlice.parallel_p90
#print axioms HiaCoreSyntaxSlice.parallel_p91
#print axioms HiaCoreSyntaxSlice.parallel_p92
#print axioms HiaCoreSyntaxSlice.parallel_p93
#print axioms HiaCoreSyntaxSlice.parallel_p94
#print axioms HiaCoreSyntaxSlice.parallel_p95
#print axioms HiaCoreSyntaxSlice.parallel_p96
#print axioms HiaCoreSyntaxSlice.parallel_p97
#print axioms HiaCoreSyntaxSlice.parallel_p98
#print axioms HiaCoreSyntaxSlice.parallel_p99
#print axioms HiaCoreSyntaxSlice.parallel_pl10_0
#print axioms HiaCoreSyntaxSlice.parallel_pl10_1
#print axioms HiaCoreSyntaxSlice.parallel_pl10_2
#print axioms HiaCoreSyntaxSlice.parallel_pl10_3
#print axioms HiaCoreSyntaxSlice.parallel_pl113_0
#print axioms HiaCoreSyntaxSlice.parallel_pl113_1
#print axioms HiaCoreSyntaxSlice.parallel_pl113_2
#print axioms HiaCoreSyntaxSlice.parallel_pl113_3
#print axioms HiaCoreSyntaxSlice.parallel_pl15_0
#print axioms HiaCoreSyntaxSlice.parallel_pl15_1
#print axioms HiaCoreSyntaxSlice.parallel_pl15_2
#print axioms HiaCoreSyntaxSlice.parallel_pl15_3
#print axioms HiaCoreSyntaxSlice.parallel_pl17_0
#print axioms HiaCoreSyntaxSlice.parallel_pl17_1
#print axioms HiaCoreSyntaxSlice.parallel_pl17_2
#print axioms HiaCoreSyntaxSlice.parallel_pl17_3
#print axioms HiaCoreSyntaxSlice.parallel_pl24_0
#print axioms HiaCoreSyntaxSlice.parallel_pl24_1
#print axioms HiaCoreSyntaxSlice.parallel_pl24_2
#print axioms HiaCoreSyntaxSlice.parallel_pl24_3
#print axioms HiaCoreSyntaxSlice.parallel_pl29_0
#print axioms HiaCoreSyntaxSlice.parallel_pl29_1
#print axioms HiaCoreSyntaxSlice.parallel_pl29_2
#print axioms HiaCoreSyntaxSlice.parallel_pl29_3
#print axioms HiaCoreSyntaxSlice.parallel_pl34_0
#print axioms HiaCoreSyntaxSlice.parallel_pl34_1
#print axioms HiaCoreSyntaxSlice.parallel_pl34_2
#print axioms HiaCoreSyntaxSlice.parallel_pl34_3
#print axioms HiaCoreSyntaxSlice.parallel_pl39_0
#print axioms HiaCoreSyntaxSlice.parallel_pl39_1
#print axioms HiaCoreSyntaxSlice.parallel_pl39_2
#print axioms HiaCoreSyntaxSlice.parallel_pl39_3
#print axioms HiaCoreSyntaxSlice.parallel_pl44_0
#print axioms HiaCoreSyntaxSlice.parallel_pl44_1
#print axioms HiaCoreSyntaxSlice.parallel_pl44_2
#print axioms HiaCoreSyntaxSlice.parallel_pl44_3
#print axioms HiaCoreSyntaxSlice.parallel_pl49_0
#print axioms HiaCoreSyntaxSlice.parallel_pl49_1
#print axioms HiaCoreSyntaxSlice.parallel_pl49_2
#print axioms HiaCoreSyntaxSlice.parallel_pl49_3
#print axioms HiaCoreSyntaxSlice.parallel_pl51_0
#print axioms HiaCoreSyntaxSlice.parallel_pl51_1
#print axioms HiaCoreSyntaxSlice.parallel_pl51_10
#print axioms HiaCoreSyntaxSlice.parallel_pl51_2
#print axioms HiaCoreSyntaxSlice.parallel_pl51_3
#print axioms HiaCoreSyntaxSlice.parallel_pl51_4
#print axioms HiaCoreSyntaxSlice.parallel_pl51_5
#print axioms HiaCoreSyntaxSlice.parallel_pl51_6
#print axioms HiaCoreSyntaxSlice.parallel_pl51_7
#print axioms HiaCoreSyntaxSlice.parallel_pl51_8
#print axioms HiaCoreSyntaxSlice.parallel_pl51_9
#print axioms HiaCoreSyntaxSlice.parallel_pl5_0
#print axioms HiaCoreSyntaxSlice.parallel_pl5_1
#print axioms HiaCoreSyntaxSlice.parallel_pl5_2
#print axioms HiaCoreSyntaxSlice.parallel_pl5_3
#print axioms HiaCoreSyntaxSlice.parallel_pl65_0
#print axioms HiaCoreSyntaxSlice.parallel_pl65_1
#print axioms HiaCoreSyntaxSlice.parallel_pl65_2
#print axioms HiaCoreSyntaxSlice.parallel_pl65_3
#print axioms HiaCoreSyntaxSlice.parallel_pl70_0
#print axioms HiaCoreSyntaxSlice.parallel_pl70_1
#print axioms HiaCoreSyntaxSlice.parallel_pl70_2
#print axioms HiaCoreSyntaxSlice.parallel_pl70_3
#print axioms HiaCoreSyntaxSlice.parallel_pl75_0
#print axioms HiaCoreSyntaxSlice.parallel_pl75_1
#print axioms HiaCoreSyntaxSlice.parallel_pl75_2
#print axioms HiaCoreSyntaxSlice.parallel_pl75_3
#print axioms HiaCoreSyntaxSlice.parallel_pl77_0
#print axioms HiaCoreSyntaxSlice.parallel_pl77_1
#print axioms HiaCoreSyntaxSlice.parallel_pl77_2
#print axioms HiaCoreSyntaxSlice.parallel_pl77_3
#print axioms HiaCoreSyntaxSlice.parallel_pl77_4
#print axioms HiaCoreSyntaxSlice.parallel_pl77_5
#print axioms HiaCoreSyntaxSlice.parallel_pl77_6
#print axioms HiaCoreSyntaxSlice.parallel_pl87_0
#print axioms HiaCoreSyntaxSlice.parallel_pl87_1
#print axioms HiaCoreSyntaxSlice.parallel_pl87_2
#print axioms HiaCoreSyntaxSlice.parallel_pl87_3
#print axioms HiaCoreSyntaxSlice.parallel_pl92_0
#print axioms HiaCoreSyntaxSlice.parallel_pl92_1
#print axioms HiaCoreSyntaxSlice.parallel_pl92_2
#print axioms HiaCoreSyntaxSlice.parallel_pl92_3
#print axioms HiaCoreSyntaxSlice.parallel_pl97_0
#print axioms HiaCoreSyntaxSlice.parallel_pl97_1
#print axioms HiaCoreSyntaxSlice.parallel_pl97_2
#print axioms HiaCoreSyntaxSlice.parallel_pl97_3
#print axioms HiaCoreSyntaxSlice.parallel_pl99_0
#print axioms HiaCoreSyntaxSlice.parallel_pl99_1
#print axioms HiaCoreSyntaxSlice.parallel_pl99_10
#print axioms HiaCoreSyntaxSlice.parallel_pl99_2
#print axioms HiaCoreSyntaxSlice.parallel_pl99_3
#print axioms HiaCoreSyntaxSlice.parallel_pl99_4
#print axioms HiaCoreSyntaxSlice.parallel_pl99_5
#print axioms HiaCoreSyntaxSlice.parallel_pl99_6
#print axioms HiaCoreSyntaxSlice.parallel_pl99_7
#print axioms HiaCoreSyntaxSlice.parallel_pl99_8
#print axioms HiaCoreSyntaxSlice.parallel_pl99_9
#print axioms HiaCoreSyntaxSlice.parallel_s1
#print axioms HiaCoreSyntaxSlice.parallel_s10
#print axioms HiaCoreSyntaxSlice.parallel_s100
#print axioms HiaCoreSyntaxSlice.parallel_s101
#print axioms HiaCoreSyntaxSlice.parallel_s102
#print axioms HiaCoreSyntaxSlice.parallel_s103
#print axioms HiaCoreSyntaxSlice.parallel_s104
#print axioms HiaCoreSyntaxSlice.parallel_s105
#print axioms HiaCoreSyntaxSlice.parallel_s106
#print axioms HiaCoreSyntaxSlice.parallel_s107
#print axioms HiaCoreSyntaxSlice.parallel_s108
#print axioms HiaCoreSyntaxSlice.parallel_s109
#print axioms HiaCoreSyntaxSlice.parallel_s11
#print axioms HiaCoreSyntaxSlice.parallel_s110
#print axioms HiaCoreSyntaxSlice.parallel_s111
#print axioms HiaCoreSyntaxSlice.parallel_s112
#print axioms HiaCoreSyntaxSlice.parallel_s114
#print axioms HiaCoreSyntaxSlice.parallel_s115
#print axioms HiaCoreSyntaxSlice.parallel_s116
#print axioms HiaCoreSyntaxSlice.parallel_s117
#print axioms HiaCoreSyntaxSlice.parallel_s12
#print axioms HiaCoreSyntaxSlice.parallel_s13
#print axioms HiaCoreSyntaxSlice.parallel_s14
#print axioms HiaCoreSyntaxSlice.parallel_s15
#print axioms HiaCoreSyntaxSlice.parallel_s16
#print axioms HiaCoreSyntaxSlice.parallel_s17
#print axioms HiaCoreSyntaxSlice.parallel_s18
#print axioms HiaCoreSyntaxSlice.parallel_s19
#print axioms HiaCoreSyntaxSlice.parallel_s20
#print axioms HiaCoreSyntaxSlice.parallel_s21
#print axioms HiaCoreSyntaxSlice.parallel_s22
#print axioms HiaCoreSyntaxSlice.parallel_s23
#print axioms HiaCoreSyntaxSlice.parallel_s24
#print axioms HiaCoreSyntaxSlice.parallel_s25
#print axioms HiaCoreSyntaxSlice.parallel_s26
#print axioms HiaCoreSyntaxSlice.parallel_s27
#print axioms HiaCoreSyntaxSlice.parallel_s28
#print axioms HiaCoreSyntaxSlice.parallel_s29
#print axioms HiaCoreSyntaxSlice.parallel_s30
#print axioms HiaCoreSyntaxSlice.parallel_s31
#print axioms HiaCoreSyntaxSlice.parallel_s32
#print axioms HiaCoreSyntaxSlice.parallel_s33
#print axioms HiaCoreSyntaxSlice.parallel_s34
#print axioms HiaCoreSyntaxSlice.parallel_s35
#print axioms HiaCoreSyntaxSlice.parallel_s36
#print axioms HiaCoreSyntaxSlice.parallel_s37
#print axioms HiaCoreSyntaxSlice.parallel_s38
#print axioms HiaCoreSyntaxSlice.parallel_s39
#print axioms HiaCoreSyntaxSlice.parallel_s40
#print axioms HiaCoreSyntaxSlice.parallel_s41
#print axioms HiaCoreSyntaxSlice.parallel_s42
#print axioms HiaCoreSyntaxSlice.parallel_s43
#print axioms HiaCoreSyntaxSlice.parallel_s44
#print axioms HiaCoreSyntaxSlice.parallel_s45
#print axioms HiaCoreSyntaxSlice.parallel_s46
#print axioms HiaCoreSyntaxSlice.parallel_s47
#print axioms HiaCoreSyntaxSlice.parallel_s48
#print axioms HiaCoreSyntaxSlice.parallel_s49
#print axioms HiaCoreSyntaxSlice.parallel_s5
#print axioms HiaCoreSyntaxSlice.parallel_s50
#print axioms HiaCoreSyntaxSlice.parallel_s51
#print axioms HiaCoreSyntaxSlice.parallel_s52
#print axioms HiaCoreSyntaxSlice.parallel_s53
#print axioms HiaCoreSyntaxSlice.parallel_s54
#print axioms HiaCoreSyntaxSlice.parallel_s55
#print axioms HiaCoreSyntaxSlice.parallel_s56
#print axioms HiaCoreSyntaxSlice.parallel_s57
#print axioms HiaCoreSyntaxSlice.parallel_s58
#print axioms HiaCoreSyntaxSlice.parallel_s59
#print axioms HiaCoreSyntaxSlice.parallel_s6
#print axioms HiaCoreSyntaxSlice.parallel_s60
#print axioms HiaCoreSyntaxSlice.parallel_s61
#print axioms HiaCoreSyntaxSlice.parallel_s62
#print axioms HiaCoreSyntaxSlice.parallel_s63
#print axioms HiaCoreSyntaxSlice.parallel_s64
#print axioms HiaCoreSyntaxSlice.parallel_s65
#print axioms HiaCoreSyntaxSlice.parallel_s66
#print axioms HiaCoreSyntaxSlice.parallel_s67
#print axioms HiaCoreSyntaxSlice.parallel_s68
#print axioms HiaCoreSyntaxSlice.parallel_s69
#print axioms HiaCoreSyntaxSlice.parallel_s7
#print axioms HiaCoreSyntaxSlice.parallel_s70
#print axioms HiaCoreSyntaxSlice.parallel_s71
#print axioms HiaCoreSyntaxSlice.parallel_s72
#print axioms HiaCoreSyntaxSlice.parallel_s73
#print axioms HiaCoreSyntaxSlice.parallel_s74
#print axioms HiaCoreSyntaxSlice.parallel_s75
#print axioms HiaCoreSyntaxSlice.parallel_s76
#print axioms HiaCoreSyntaxSlice.parallel_s77
#print axioms HiaCoreSyntaxSlice.parallel_s78
#print axioms HiaCoreSyntaxSlice.parallel_s79
#print axioms HiaCoreSyntaxSlice.parallel_s8
#print axioms HiaCoreSyntaxSlice.parallel_s80
#print axioms HiaCoreSyntaxSlice.parallel_s81
#print axioms HiaCoreSyntaxSlice.parallel_s82
#print axioms HiaCoreSyntaxSlice.parallel_s83
#print axioms HiaCoreSyntaxSlice.parallel_s84
#print axioms HiaCoreSyntaxSlice.parallel_s85
#print axioms HiaCoreSyntaxSlice.parallel_s86
#print axioms HiaCoreSyntaxSlice.parallel_s87
#print axioms HiaCoreSyntaxSlice.parallel_s88
#print axioms HiaCoreSyntaxSlice.parallel_s89
#print axioms HiaCoreSyntaxSlice.parallel_s9
#print axioms HiaCoreSyntaxSlice.parallel_s90
#print axioms HiaCoreSyntaxSlice.parallel_s91
#print axioms HiaCoreSyntaxSlice.parallel_s92
#print axioms HiaCoreSyntaxSlice.parallel_s93
#print axioms HiaCoreSyntaxSlice.parallel_s94
#print axioms HiaCoreSyntaxSlice.parallel_s95
#print axioms HiaCoreSyntaxSlice.parallel_s96
#print axioms HiaCoreSyntaxSlice.parallel_s97
#print axioms HiaCoreSyntaxSlice.parallel_s98
#print axioms HiaCoreSyntaxSlice.parallel_s99
#print axioms HiaCoreSyntaxSlice.parallel_sl10_0
#print axioms HiaCoreSyntaxSlice.parallel_sl10_1
#print axioms HiaCoreSyntaxSlice.parallel_sl10_2
#print axioms HiaCoreSyntaxSlice.parallel_sl10_3
#print axioms HiaCoreSyntaxSlice.parallel_sl113_0
#print axioms HiaCoreSyntaxSlice.parallel_sl113_1
#print axioms HiaCoreSyntaxSlice.parallel_sl113_2
#print axioms HiaCoreSyntaxSlice.parallel_sl113_3
#print axioms HiaCoreSyntaxSlice.parallel_sl15_0
#print axioms HiaCoreSyntaxSlice.parallel_sl15_1
#print axioms HiaCoreSyntaxSlice.parallel_sl15_2
#print axioms HiaCoreSyntaxSlice.parallel_sl15_3
#print axioms HiaCoreSyntaxSlice.parallel_sl17_0
#print axioms HiaCoreSyntaxSlice.parallel_sl17_1
#print axioms HiaCoreSyntaxSlice.parallel_sl17_2
#print axioms HiaCoreSyntaxSlice.parallel_sl17_3
#print axioms HiaCoreSyntaxSlice.parallel_sl24_0
#print axioms HiaCoreSyntaxSlice.parallel_sl24_1
#print axioms HiaCoreSyntaxSlice.parallel_sl24_2
#print axioms HiaCoreSyntaxSlice.parallel_sl24_3
#print axioms HiaCoreSyntaxSlice.parallel_sl29_0
#print axioms HiaCoreSyntaxSlice.parallel_sl29_1
#print axioms HiaCoreSyntaxSlice.parallel_sl29_2
#print axioms HiaCoreSyntaxSlice.parallel_sl29_3
#print axioms HiaCoreSyntaxSlice.parallel_sl34_0
#print axioms HiaCoreSyntaxSlice.parallel_sl34_1
#print axioms HiaCoreSyntaxSlice.parallel_sl34_2
#print axioms HiaCoreSyntaxSlice.parallel_sl34_3
#print axioms HiaCoreSyntaxSlice.parallel_sl39_0
#print axioms HiaCoreSyntaxSlice.parallel_sl39_1
#print axioms HiaCoreSyntaxSlice.parallel_sl39_2
#print axioms HiaCoreSyntaxSlice.parallel_sl39_3
#print axioms HiaCoreSyntaxSlice.parallel_sl44_0
#print axioms HiaCoreSyntaxSlice.parallel_sl44_1
#print axioms HiaCoreSyntaxSlice.parallel_sl44_2
#print axioms HiaCoreSyntaxSlice.parallel_sl44_3
#print axioms HiaCoreSyntaxSlice.parallel_sl49_0
#print axioms HiaCoreSyntaxSlice.parallel_sl49_1
#print axioms HiaCoreSyntaxSlice.parallel_sl49_2
#print axioms HiaCoreSyntaxSlice.parallel_sl49_3
#print axioms HiaCoreSyntaxSlice.parallel_sl51_0
#print axioms HiaCoreSyntaxSlice.parallel_sl51_1
#print axioms HiaCoreSyntaxSlice.parallel_sl51_10
#print axioms HiaCoreSyntaxSlice.parallel_sl51_2
#print axioms HiaCoreSyntaxSlice.parallel_sl51_3
#print axioms HiaCoreSyntaxSlice.parallel_sl51_4
#print axioms HiaCoreSyntaxSlice.parallel_sl51_5
#print axioms HiaCoreSyntaxSlice.parallel_sl51_6
#print axioms HiaCoreSyntaxSlice.parallel_sl51_7
#print axioms HiaCoreSyntaxSlice.parallel_sl51_8
#print axioms HiaCoreSyntaxSlice.parallel_sl51_9
#print axioms HiaCoreSyntaxSlice.parallel_sl5_0
#print axioms HiaCoreSyntaxSlice.parallel_sl5_1
#print axioms HiaCoreSyntaxSlice.parallel_sl5_2
#print axioms HiaCoreSyntaxSlice.parallel_sl5_3
#print axioms HiaCoreSyntaxSlice.parallel_sl65_0
#print axioms HiaCoreSyntaxSlice.parallel_sl65_1
#print axioms HiaCoreSyntaxSlice.parallel_sl65_2
#print axioms HiaCoreSyntaxSlice.parallel_sl65_3
#print axioms HiaCoreSyntaxSlice.parallel_sl70_0
#print axioms HiaCoreSyntaxSlice.parallel_sl70_1
#print axioms HiaCoreSyntaxSlice.parallel_sl70_2
#print axioms HiaCoreSyntaxSlice.parallel_sl70_3
#print axioms HiaCoreSyntaxSlice.parallel_sl75_0
#print axioms HiaCoreSyntaxSlice.parallel_sl75_1
#print axioms HiaCoreSyntaxSlice.parallel_sl75_2
#print axioms HiaCoreSyntaxSlice.parallel_sl75_3
#print axioms HiaCoreSyntaxSlice.parallel_sl77_0
#print axioms HiaCoreSyntaxSlice.parallel_sl77_1
#print axioms HiaCoreSyntaxSlice.parallel_sl77_2
#print axioms HiaCoreSyntaxSlice.parallel_sl77_3
#print axioms HiaCoreSyntaxSlice.parallel_sl77_4
#print axioms HiaCoreSyntaxSlice.parallel_sl77_5
#print axioms HiaCoreSyntaxSlice.parallel_sl77_6
#print axioms HiaCoreSyntaxSlice.parallel_sl87_0
#print axioms HiaCoreSyntaxSlice.parallel_sl87_1
#print axioms HiaCoreSyntaxSlice.parallel_sl87_2
#print axioms HiaCoreSyntaxSlice.parallel_sl87_3
#print axioms HiaCoreSyntaxSlice.parallel_sl92_0
#print axioms HiaCoreSyntaxSlice.parallel_sl92_1
#print axioms HiaCoreSyntaxSlice.parallel_sl92_2
#print axioms HiaCoreSyntaxSlice.parallel_sl92_3
#print axioms HiaCoreSyntaxSlice.parallel_sl97_0
#print axioms HiaCoreSyntaxSlice.parallel_sl97_1
#print axioms HiaCoreSyntaxSlice.parallel_sl97_2
#print axioms HiaCoreSyntaxSlice.parallel_sl97_3
#print axioms HiaCoreSyntaxSlice.parallel_sl99_0
#print axioms HiaCoreSyntaxSlice.parallel_sl99_1
#print axioms HiaCoreSyntaxSlice.parallel_sl99_10
#print axioms HiaCoreSyntaxSlice.parallel_sl99_2
#print axioms HiaCoreSyntaxSlice.parallel_sl99_3
#print axioms HiaCoreSyntaxSlice.parallel_sl99_4
#print axioms HiaCoreSyntaxSlice.parallel_sl99_5
#print axioms HiaCoreSyntaxSlice.parallel_sl99_6
#print axioms HiaCoreSyntaxSlice.parallel_sl99_7
#print axioms HiaCoreSyntaxSlice.parallel_sl99_8
#print axioms HiaCoreSyntaxSlice.parallel_sl99_9
