import HiaSyntaxResearch.CertPart01
namespace HiaCoreSyntaxSlice
def linear_k3_0 : List Nat := [98,108,111,99,107,115]
theorem linear_kd3_0 : stringBytes linear_k3_0 = true := by decide +kernel
theorem linear_kp3_0 (tail : List Nat) : parseStringTail (linear_k3_0 ++ (34 :: 58 :: tail)) [] = some (linear_k3_0, 58 :: tail) := by rfl
def linear_k3_1 : List Nat := [101,102,102,101,99,116,115]
theorem linear_kd3_1 : stringBytes linear_k3_1 = true := by decide +kernel
theorem linear_kp3_1 (tail : List Nat) : parseStringTail (linear_k3_1 ++ (34 :: 58 :: tail)) [] = some (linear_k3_1, 58 :: tail) := by rfl
def linear_k3_2 : List Nat := [101,110,116,114,121]
theorem linear_kd3_2 : stringBytes linear_k3_2 = true := by decide +kernel
theorem linear_kp3_2 (tail : List Nat) : parseStringTail (linear_k3_2 ++ (34 :: 58 :: tail)) [] = some (linear_k3_2, 58 :: tail) := by rfl
def linear_k3_3 : List Nat := [110,97,109,101]
theorem linear_kd3_3 : stringBytes linear_k3_3 = true := by decide +kernel
theorem linear_kp3_3 (tail : List Nat) : parseStringTail (linear_k3_3 ++ (34 :: 58 :: tail)) [] = some (linear_k3_3, 58 :: tail) := by rfl
def linear_k3_4 : List Nat := [112,97,114,97,109,115]
theorem linear_kd3_4 : stringBytes linear_k3_4 = true := by decide +kernel
theorem linear_kp3_4 (tail : List Nat) : parseStringTail (linear_k3_4 ++ (34 :: 58 :: tail)) [] = some (linear_k3_4, 58 :: tail) := by rfl
def linear_k3_5 : List Nat := [114,101,116,117,114,110,115]
theorem linear_kd3_5 : stringBytes linear_k3_5 = true := by decide +kernel
theorem linear_kp3_5 (tail : List Nat) : parseStringTail (linear_k3_5 ++ (34 :: 58 :: tail)) [] = some (linear_k3_5, 58 :: tail) := by rfl
def linear_l3_5 : List (List Nat × Raw) := [(linear_k3_5, linear_r154)]
def linear_v3_5 : List Nat := linear_g396 ++ linear_b154
theorem linear_sl3_5 : serializeFields 4085 29 linear_l3_5 = some linear_v3_5 := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4084 29 linear_k3_5 linear_r154 linear_b154 linear_kd3_5 linear_s154)
theorem linear_pl3_5 (tail : List Nat) : parseFields 4085 29 (linear_v3_5 ++ (125 :: tail)) = some (linear_l3_5, tail) := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4084 29 (linear_k3_5 ++ (34 :: 58 :: (linear_b154 ++ (125 :: tail)))) linear_k3_5 (linear_b154 ++ (125 :: tail)) tail linear_r154 (linear_kp3_5 (linear_b154 ++ (125 :: tail))) (linear_p154 (125 :: tail)))
def linear_l3_4 : List (List Nat × Raw) := (linear_k3_4, linear_r153) :: linear_l3_5
def linear_v3_4 : List Nat := (linear_g393 ++ linear_b153) ++ (44 :: linear_v3_5)
theorem linear_sl3_4 : serializeFields 4086 29 linear_l3_4 = some linear_v3_4 := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 29 linear_k3_4 linear_r153 (linear_k3_5, linear_r154) [] linear_b153 linear_v3_5 linear_kd3_4 linear_s153 linear_sl3_5)
theorem linear_pl3_4 (tail : List Nat) : parseFields 4086 29 (linear_v3_4 ++ (125 :: tail)) = some (linear_l3_4, tail) := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 29 (linear_k3_4 ++ (34 :: 58 :: (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))))) linear_k3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))) (linear_v3_5 ++ (125 :: tail)) tail linear_r153 linear_l3_5 (linear_kp3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail))))) (linear_p153 (44 :: (linear_v3_5 ++ (125 :: tail)))) (linear_pl3_5 tail))
def linear_l3_3 : List (List Nat × Raw) := (linear_k3_3, linear_r152) :: linear_l3_4
def linear_v3_3 : List Nat := (linear_g390 ++ linear_b152) ++ (44 :: linear_v3_4)
theorem linear_sl3_3 : serializeFields 4087 29 linear_l3_3 = some linear_v3_3 := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4086 29 linear_k3_3 linear_r152 (linear_k3_4, linear_r153) linear_l3_5 linear_b152 linear_v3_4 linear_kd3_3 linear_s152 linear_sl3_4)
theorem linear_pl3_3 (tail : List Nat) : parseFields 4087 29 (linear_v3_3 ++ (125 :: tail)) = some (linear_l3_3, tail) := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4086 29 (linear_k3_3 ++ (34 :: 58 :: (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))))) linear_k3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))) (linear_v3_4 ++ (125 :: tail)) tail linear_r152 linear_l3_4 (linear_kp3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail))))) (linear_p152 (44 :: (linear_v3_4 ++ (125 :: tail)))) (linear_pl3_4 tail))
def linear_l3_2 : List (List Nat × Raw) := (linear_k3_2, linear_r151) :: linear_l3_3
def linear_v3_2 : List Nat := (linear_g387 ++ linear_b151) ++ (44 :: linear_v3_3)
theorem linear_sl3_2 : serializeFields 4088 29 linear_l3_2 = some linear_v3_2 := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4087 29 linear_k3_2 linear_r151 (linear_k3_3, linear_r152) linear_l3_4 linear_b151 linear_v3_3 linear_kd3_2 linear_s151 linear_sl3_3)
theorem linear_pl3_2 (tail : List Nat) : parseFields 4088 29 (linear_v3_2 ++ (125 :: tail)) = some (linear_l3_2, tail) := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4087 29 (linear_k3_2 ++ (34 :: 58 :: (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))))) linear_k3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))) (linear_v3_3 ++ (125 :: tail)) tail linear_r151 linear_l3_3 (linear_kp3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail))))) (linear_p151 (44 :: (linear_v3_3 ++ (125 :: tail)))) (linear_pl3_3 tail))
def linear_l3_1 : List (List Nat × Raw) := (linear_k3_1, linear_r150) :: linear_l3_2
def linear_v3_1 : List Nat := (linear_g384 ++ linear_b150) ++ (44 :: linear_v3_2)
theorem linear_sl3_1 : serializeFields 4089 29 linear_l3_1 = some linear_v3_1 := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4088 29 linear_k3_1 linear_r150 (linear_k3_2, linear_r151) linear_l3_3 linear_b150 linear_v3_2 linear_kd3_1 linear_s150 linear_sl3_2)
theorem linear_pl3_1 (tail : List Nat) : parseFields 4089 29 (linear_v3_1 ++ (125 :: tail)) = some (linear_l3_1, tail) := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4088 29 (linear_k3_1 ++ (34 :: 58 :: (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))))) linear_k3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))) (linear_v3_2 ++ (125 :: tail)) tail linear_r150 linear_l3_2 (linear_kp3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail))))) (linear_p150 (44 :: (linear_v3_2 ++ (125 :: tail)))) (linear_pl3_2 tail))
def linear_l3_0 : List (List Nat × Raw) := (linear_k3_0, linear_r4) :: linear_l3_1
def linear_v3_0 : List Nat := (linear_g7 ++ linear_b4) ++ (44 :: linear_v3_1)
theorem linear_sl3_0 : serializeFields 4090 29 linear_l3_0 = some linear_v3_0 := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4089 29 linear_k3_0 linear_r4 (linear_k3_1, linear_r150) linear_l3_2 linear_b4 linear_v3_1 linear_kd3_0 linear_s4 linear_sl3_1)
theorem linear_pl3_0 (tail : List Nat) : parseFields 4090 29 (linear_v3_0 ++ (125 :: tail)) = some (linear_l3_0, tail) := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4089 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) linear_k3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))) (linear_v3_1 ++ (125 :: tail)) tail linear_r4 linear_l3_1 (linear_kp3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail))))) (linear_p4 (44 :: (linear_v3_1 ++ (125 :: tail)))) (linear_pl3_1 tail))
def linear_r3 : Raw := (.obj linear_l3_0)
def linear_b3 : List Nat := linear_g6 ++ (linear_v3_0 ++ linear_g398)
theorem linear_o3 : orderedFields linear_l3_0 = true := by decide +kernel
theorem linear_s3 : serializeRaw 4091 30 linear_r3 = some linear_b3 := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4090 29 linear_l3_0 linear_v3_0 linear_o3 linear_sl3_0)
theorem linear_p3 (tail : List Nat) : parseRaw 4091 30 (linear_b3 ++ tail) = some (linear_r3, tail) := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4090 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) tail linear_l3_0 linear_o3 (by simpa only [linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl3_0 tail)))
def linear_l2_0 : List Raw := [linear_r3]
def linear_v2_0 : List Nat := linear_b3
theorem linear_sl2_0 : serializeItems 4092 30 linear_l2_0 = some linear_v2_0 := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4091 30 linear_r3 linear_b3 linear_s3)
theorem linear_pl2_0 (tail : List Nat) : parseItems 4092 30 (linear_v2_0 ++ (93 :: tail)) = some (linear_l2_0, tail) := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4091 30 (linear_b3 ++ (93 :: tail)) tail linear_r3 (linear_p3 (93 :: tail)))
def linear_r2 : Raw := (.arr linear_l2_0)
def linear_b2 : List Nat := linear_g5 ++ (linear_v2_0 ++ linear_g399)
theorem linear_s2 : serializeRaw 4093 31 linear_r2 = some linear_b2 := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4092 30 linear_l2_0 linear_v2_0 linear_sl2_0)
theorem linear_p2 (tail : List Nat) : parseRaw 4093 31 (linear_b2 ++ tail) = some (linear_r2, tail) := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4092 30 (linear_v2_0 ++ (93 :: tail)) tail linear_l2_0 (by intro h; cases h) (linear_pl2_0 tail))
def linear_r155 : Raw := (.str [114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114])
def linear_b155 : List Nat := linear_g402
theorem linear_s155 : serializeRaw 4092 31 linear_r155 = some linear_b155 := by decide +kernel
theorem linear_p155 (tail : List Nat) : parseRaw 4092 31 (linear_b155 ++ tail) = some (linear_r155, tail) := by rfl
def linear_r156 : Raw := (.str [104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49])
def linear_b156 : List Nat := linear_g405
theorem linear_s156 : serializeRaw 4091 31 linear_r156 = some linear_b156 := by decide +kernel
theorem linear_p156 (tail : List Nat) : parseRaw 4091 31 (linear_b156 ++ tail) = some (linear_r156, tail) := by rfl
def linear_k0_0 : List Nat := [101,120,112,111,114,116,115]
theorem linear_kd0_0 : stringBytes linear_k0_0 = true := by decide +kernel
theorem linear_kp0_0 (tail : List Nat) : parseStringTail (linear_k0_0 ++ (34 :: 58 :: tail)) [] = some (linear_k0_0, 58 :: tail) := by rfl
def linear_k0_1 : List Nat := [102,117,110,99,116,105,111,110,115]
theorem linear_kd0_1 : stringBytes linear_k0_1 = true := by decide +kernel
theorem linear_kp0_1 (tail : List Nat) : parseStringTail (linear_k0_1 ++ (34 :: 58 :: tail)) [] = some (linear_k0_1, 58 :: tail) := by rfl
def linear_k0_2 : List Nat := [109,111,100,117,108,101]
theorem linear_kd0_2 : stringBytes linear_k0_2 = true := by decide +kernel
theorem linear_kp0_2 (tail : List Nat) : parseStringTail (linear_k0_2 ++ (34 :: 58 :: tail)) [] = some (linear_k0_2, 58 :: tail) := by rfl
def linear_k0_3 : List Nat := [115,99,104,101,109,97]
theorem linear_kd0_3 : stringBytes linear_k0_3 = true := by decide +kernel
theorem linear_kp0_3 (tail : List Nat) : parseStringTail (linear_k0_3 ++ (34 :: 58 :: tail)) [] = some (linear_k0_3, 58 :: tail) := by rfl
def linear_l0_3 : List (List Nat × Raw) := [(linear_k0_3, linear_r156)]
def linear_v0_3 : List Nat := linear_g404 ++ linear_b156
theorem linear_sl0_3 : serializeFields 4092 31 linear_l0_3 = some linear_v0_3 := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4091 31 linear_k0_3 linear_r156 linear_b156 linear_kd0_3 linear_s156)
theorem linear_pl0_3 (tail : List Nat) : parseFields 4092 31 (linear_v0_3 ++ (125 :: tail)) = some (linear_l0_3, tail) := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4091 31 (linear_k0_3 ++ (34 :: 58 :: (linear_b156 ++ (125 :: tail)))) linear_k0_3 (linear_b156 ++ (125 :: tail)) tail linear_r156 (linear_kp0_3 (linear_b156 ++ (125 :: tail))) (linear_p156 (125 :: tail)))
def linear_l0_2 : List (List Nat × Raw) := (linear_k0_2, linear_r155) :: linear_l0_3
def linear_v0_2 : List Nat := (linear_g401 ++ linear_b155) ++ (44 :: linear_v0_3)
theorem linear_sl0_2 : serializeFields 4093 31 linear_l0_2 = some linear_v0_2 := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4092 31 linear_k0_2 linear_r155 (linear_k0_3, linear_r156) [] linear_b155 linear_v0_3 linear_kd0_2 linear_s155 linear_sl0_3)
theorem linear_pl0_2 (tail : List Nat) : parseFields 4093 31 (linear_v0_2 ++ (125 :: tail)) = some (linear_l0_2, tail) := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4092 31 (linear_k0_2 ++ (34 :: 58 :: (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))))) linear_k0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))) (linear_v0_3 ++ (125 :: tail)) tail linear_r155 linear_l0_3 (linear_kp0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail))))) (linear_p155 (44 :: (linear_v0_3 ++ (125 :: tail)))) (linear_pl0_3 tail))
def linear_l0_1 : List (List Nat × Raw) := (linear_k0_1, linear_r2) :: linear_l0_2
def linear_v0_1 : List Nat := (linear_g4 ++ linear_b2) ++ (44 :: linear_v0_2)
theorem linear_sl0_1 : serializeFields 4094 31 linear_l0_1 = some linear_v0_1 := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4093 31 linear_k0_1 linear_r2 (linear_k0_2, linear_r155) linear_l0_3 linear_b2 linear_v0_2 linear_kd0_1 linear_s2 linear_sl0_2)
theorem linear_pl0_1 (tail : List Nat) : parseFields 4094 31 (linear_v0_1 ++ (125 :: tail)) = some (linear_l0_1, tail) := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4093 31 (linear_k0_1 ++ (34 :: 58 :: (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))))) linear_k0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))) (linear_v0_2 ++ (125 :: tail)) tail linear_r2 linear_l0_2 (linear_kp0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail))))) (linear_p2 (44 :: (linear_v0_2 ++ (125 :: tail)))) (linear_pl0_2 tail))
def linear_l0_0 : List (List Nat × Raw) := (linear_k0_0, linear_r1) :: linear_l0_1
def linear_v0_0 : List Nat := (linear_g1 ++ linear_b1) ++ (44 :: linear_v0_1)
theorem linear_sl0_0 : serializeFields 4095 31 linear_l0_0 = some linear_v0_0 := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4094 31 linear_k0_0 linear_r1 (linear_k0_1, linear_r2) linear_l0_2 linear_b1 linear_v0_1 linear_kd0_0 linear_s1 linear_sl0_1)
theorem linear_pl0_0 (tail : List Nat) : parseFields 4095 31 (linear_v0_0 ++ (125 :: tail)) = some (linear_l0_0, tail) := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4094 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) linear_k0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))) (linear_v0_1 ++ (125 :: tail)) tail linear_r1 linear_l0_1 (linear_kp0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail))))) (linear_p1 (44 :: (linear_v0_1 ++ (125 :: tail)))) (linear_pl0_1 tail))
def linear_r0 : Raw := (.obj linear_l0_0)
def linear_b0 : List Nat := linear_g0 ++ (linear_v0_0 ++ linear_g406)
theorem linear_o0 : orderedFields linear_l0_0 = true := by decide +kernel
theorem linear_s0 : serializeRaw 4096 32 linear_r0 = some linear_b0 := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4095 31 linear_l0_0 linear_v0_0 linear_o0 linear_sl0_0)
theorem linear_p0 (tail : List Nat) : parseRaw 4096 32 (linear_b0 ++ tail) = some (linear_r0, tail) := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4095 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) tail linear_l0_0 linear_o0 (by simpa only [linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl0_0 tail)))
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.linear_kd0_0
#print axioms HiaCoreSyntaxSlice.linear_kd0_1
#print axioms HiaCoreSyntaxSlice.linear_kd0_2
#print axioms HiaCoreSyntaxSlice.linear_kd0_3
#print axioms HiaCoreSyntaxSlice.linear_kd3_0
#print axioms HiaCoreSyntaxSlice.linear_kd3_1
#print axioms HiaCoreSyntaxSlice.linear_kd3_2
#print axioms HiaCoreSyntaxSlice.linear_kd3_3
#print axioms HiaCoreSyntaxSlice.linear_kd3_4
#print axioms HiaCoreSyntaxSlice.linear_kd3_5
#print axioms HiaCoreSyntaxSlice.linear_kp0_0
#print axioms HiaCoreSyntaxSlice.linear_kp0_1
#print axioms HiaCoreSyntaxSlice.linear_kp0_2
#print axioms HiaCoreSyntaxSlice.linear_kp0_3
#print axioms HiaCoreSyntaxSlice.linear_kp3_0
#print axioms HiaCoreSyntaxSlice.linear_kp3_1
#print axioms HiaCoreSyntaxSlice.linear_kp3_2
#print axioms HiaCoreSyntaxSlice.linear_kp3_3
#print axioms HiaCoreSyntaxSlice.linear_kp3_4
#print axioms HiaCoreSyntaxSlice.linear_kp3_5
#print axioms HiaCoreSyntaxSlice.linear_o0
#print axioms HiaCoreSyntaxSlice.linear_o3
#print axioms HiaCoreSyntaxSlice.linear_p0
#print axioms HiaCoreSyntaxSlice.linear_p155
#print axioms HiaCoreSyntaxSlice.linear_p156
#print axioms HiaCoreSyntaxSlice.linear_p2
#print axioms HiaCoreSyntaxSlice.linear_p3
#print axioms HiaCoreSyntaxSlice.linear_pl0_0
#print axioms HiaCoreSyntaxSlice.linear_pl0_1
#print axioms HiaCoreSyntaxSlice.linear_pl0_2
#print axioms HiaCoreSyntaxSlice.linear_pl0_3
#print axioms HiaCoreSyntaxSlice.linear_pl2_0
#print axioms HiaCoreSyntaxSlice.linear_pl3_0
#print axioms HiaCoreSyntaxSlice.linear_pl3_1
#print axioms HiaCoreSyntaxSlice.linear_pl3_2
#print axioms HiaCoreSyntaxSlice.linear_pl3_3
#print axioms HiaCoreSyntaxSlice.linear_pl3_4
#print axioms HiaCoreSyntaxSlice.linear_pl3_5
#print axioms HiaCoreSyntaxSlice.linear_s0
#print axioms HiaCoreSyntaxSlice.linear_s155
#print axioms HiaCoreSyntaxSlice.linear_s156
#print axioms HiaCoreSyntaxSlice.linear_s2
#print axioms HiaCoreSyntaxSlice.linear_s3
#print axioms HiaCoreSyntaxSlice.linear_sl0_0
#print axioms HiaCoreSyntaxSlice.linear_sl0_1
#print axioms HiaCoreSyntaxSlice.linear_sl0_2
#print axioms HiaCoreSyntaxSlice.linear_sl0_3
#print axioms HiaCoreSyntaxSlice.linear_sl2_0
#print axioms HiaCoreSyntaxSlice.linear_sl3_0
#print axioms HiaCoreSyntaxSlice.linear_sl3_1
#print axioms HiaCoreSyntaxSlice.linear_sl3_2
#print axioms HiaCoreSyntaxSlice.linear_sl3_3
#print axioms HiaCoreSyntaxSlice.linear_sl3_4
#print axioms HiaCoreSyntaxSlice.linear_sl3_5
