import HiaSyntaxResearch.Baseline
/-!
UNCHECKED Lean 4.19 proof text. Append after the existing
Lean.Elab.Tactic.Omega import; no additional import is required.

Restricted, compact canonical JSON transport for an inert whole-document tree.
The decoder is independent of the serializer. checkedEncode accepts only after
an actual decode equality check, so determinacy below is a checked round-trip
result, not an assumed serializer-injectivity theorem. No claim of completeness
for all JSON, all Core, or every input within the resource limits is made.
File-to-byte provenance is outside this kernel statement.
-/

namespace HiaCoreSyntaxSlice

inductive Raw where
  | str (bytes : List Nat)
  | num (value : Nat)
  | arr (items : List Raw)
  | obj (fields : List (List Nat × Raw))
  deriving Repr

/- Lean 4.19 does not derive DecidableEq for this nested datatype. These
    explicit mutual decisions produce equality proofs by constructor congruence
    and reject unequal constructor arguments by constructor injectivity. -/
mutual
  def rawDecEq : (a b : Raw) → Decidable (a = b)
    | .str left, .str right =>
      if same : left = right then isTrue (congrArg Raw.str same)
      else isFalse (fun equal => same (Raw.str.inj equal))
    | .num left, .num right =>
      if same : left = right then isTrue (congrArg Raw.num same)
      else isFalse (fun equal => same (Raw.num.inj equal))
    | .arr left, .arr right =>
      match rawListDecEq left right with
      | isTrue same => isTrue (congrArg Raw.arr same)
      | isFalse different => isFalse (fun equal => different (Raw.arr.inj equal))
    | .obj left, .obj right =>
      match rawFieldsDecEq left right with
      | isTrue same => isTrue (congrArg Raw.obj same)
      | isFalse different => isFalse (fun equal => different (Raw.obj.inj equal))
    | .str _, .num _ => isFalse (by intro equal; cases equal)
    | .str _, .arr _ => isFalse (by intro equal; cases equal)
    | .str _, .obj _ => isFalse (by intro equal; cases equal)
    | .num _, .str _ => isFalse (by intro equal; cases equal)
    | .num _, .arr _ => isFalse (by intro equal; cases equal)
    | .num _, .obj _ => isFalse (by intro equal; cases equal)
    | .arr _, .str _ => isFalse (by intro equal; cases equal)
    | .arr _, .num _ => isFalse (by intro equal; cases equal)
    | .arr _, .obj _ => isFalse (by intro equal; cases equal)
    | .obj _, .str _ => isFalse (by intro equal; cases equal)
    | .obj _, .num _ => isFalse (by intro equal; cases equal)
    | .obj _, .arr _ => isFalse (by intro equal; cases equal)

  def rawListDecEq : (a b : List Raw) → Decidable (a = b)
    | [], [] => isTrue rfl
    | [], _ :: _ => isFalse (by intro equal; cases equal)
    | _ :: _, [] => isFalse (by intro equal; cases equal)
    | left :: leftRest, right :: rightRest =>
      match rawDecEq left right with
      | isFalse different =>
        isFalse (fun equal => different (List.cons.inj equal).1)
      | isTrue same =>
        match rawListDecEq leftRest rightRest with
        | isFalse different =>
          isFalse (fun equal => different (List.cons.inj equal).2)
        | isTrue sameRest => isTrue (by cases same; cases sameRest; rfl)

  def rawFieldDecEq : (a b : List Nat × Raw) → Decidable (a = b)
    | (leftKey, left), (rightKey, right) =>
      if sameKey : leftKey = rightKey then
        match rawDecEq left right with
        | isTrue same => isTrue (by cases sameKey; cases same; rfl)
        | isFalse different =>
          isFalse (fun equal => different (congrArg Prod.snd equal))
      else isFalse (fun equal => sameKey (congrArg Prod.fst equal))

  def rawFieldsDecEq : (a b : List (List Nat × Raw)) → Decidable (a = b)
    | [], [] => isTrue rfl
    | [], _ :: _ => isFalse (by intro equal; cases equal)
    | _ :: _, [] => isFalse (by intro equal; cases equal)
    | left :: leftRest, right :: rightRest =>
      match rawFieldDecEq left right with
      | isFalse different =>
        isFalse (fun equal => different (List.cons.inj equal).1)
      | isTrue same =>
        match rawFieldsDecEq leftRest rightRest with
        | isFalse different =>
          isFalse (fun equal => different (List.cons.inj equal).2)
        | isTrue sameRest => isTrue (by cases same; cases sameRest; rfl)
end

instance : DecidableEq Raw := rawDecEq

def transportFuel : Nat := 4096
def transportDepth : Nat := 32
def transportByteLimit : Nat := 32768

/-- Printable ASCII without JSON's quote or escape character. -/
def stringByte (byte : Nat) : Bool :=
  decide (32 ≤ byte ∧ byte ≤ 126 ∧ byte ≠ 34 ∧ byte ≠ 92)

def stringBytes : List Nat → Bool
  | [] => true
  | byte :: rest => stringByte byte && stringBytes rest

/-- Strict lexicographic comparison of byte lists, including prefix ordering. -/
def keyLess : List Nat → List Nat → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: left, b :: right =>
    if a < b then true else if a = b then keyLess left right else false

/-- Strict order rejects both duplicates and noncanonical field order. -/
def orderedFields : List (List Nat × Raw) → Bool
  | [] => true
  | (key, _) :: rest =>
    match rest with
    | [] => true
    | (nextKey, _) :: _ => keyLess key nextKey && orderedFields rest

/-- Count all value nodes, including unselected subtrees, without recursion on
    the nested datatype. This is separate from parser/serializer call fuel. -/
def nodeBudget : Nat → List Raw → Bool
  | _, [] => true
  | 0, _ :: _ => false
  | fuel + 1, .str _ :: rest => nodeBudget fuel rest
  | fuel + 1, .num _ :: rest => nodeBudget fuel rest
  | fuel + 1, .arr items :: rest => nodeBudget fuel (items ++ rest)
  | fuel + 1, .obj fields :: rest =>
    nodeBudget fuel (fields.map (fun entry => entry.2) ++ rest)

/-- A separate cheap whole-tree budget check for syntax extraction. Each
    pending item carries the number of value levels still allowed at that item. -/
def depthNodeBudget : Nat → List (Nat × Raw) → Bool
  | _, [] => true
  | 0, _ :: _ => false
  | _ + 1, (0, _) :: _ => false
  | fuel + 1, (_ + 1, .str _) :: rest => depthNodeBudget fuel rest
  | fuel + 1, (_ + 1, .num _) :: rest => depthNodeBudget fuel rest
  | fuel + 1, (depth + 1, .arr items) :: rest =>
    depthNodeBudget fuel (items.map (fun item => (depth, item)) ++ rest)
  | fuel + 1, (depth + 1, .obj fields) :: rest =>
    depthNodeBudget fuel (fields.map (fun entry => (depth, entry.2)) ++ rest)

def withinBounds (raw : Raw) : Bool :=
  depthNodeBudget transportFuel [(transportDepth, raw)]

/-- Explicit base-ten conversion. Zero emits exactly one digit. The only
    leading digit emitted is 1..9 unless the entire numeral is zero. -/
def decimalAux : Nat → Nat → List Nat → Option (List Nat)
  | 0, _, _ => none
  | fuel + 1, value, suffix =>
    if value < 10 then some ((48 + value) :: suffix)
    else decimalAux fuel (value / 10) ((48 + value % 10) :: suffix)

def decimal (value : Nat) : Option (List Nat) :=
  decimalAux transportByteLimit value []

mutual
  /-- A compact serializer with no escape or raw-fragment constructor. -/
  def serializeRaw : Nat → Nat → Raw → Option (List Nat)
    | 0, _, _ => none
    | _ + 1, 0, _ => none
    | _ + 1, _ + 1, .str bytes =>
      if stringBytes bytes then some (34 :: (bytes ++ [34])) else none
    | _ + 1, _ + 1, .num value => decimal value
    | fuel + 1, depth + 1, .arr items => do
      let bytes ← serializeItems fuel depth items
      pure (91 :: (bytes ++ [93]))
    | fuel + 1, depth + 1, .obj fields =>
      if orderedFields fields then do
        let bytes ← serializeFields fuel depth fields
        pure (123 :: (bytes ++ [125]))
      else none

  def serializeItems : Nat → Nat → List Raw → Option (List Nat)
    | _, _, [] => some []
    | 0, _, _ :: _ => none
    | fuel + 1, depth, value :: rest => do
      let bytes ← serializeRaw fuel depth value
      match rest with
      | [] => pure bytes
      | _ :: _ =>
        let suffix ← serializeItems fuel depth rest
        pure (bytes ++ (44 :: suffix))

  def serializeFields : Nat → Nat → List (List Nat × Raw) → Option (List Nat)
    | _, _, [] => some []
    | 0, _, _ :: _ => none
    | fuel + 1, depth, (key, value) :: rest =>
      if stringBytes key then do
        let bytes ← serializeRaw fuel depth value
        let field := 34 :: (key ++ (34 :: 58 :: bytes))
        match rest with
        | [] => pure field
        | _ :: _ =>
          let suffix ← serializeFields fuel depth rest
          pure (field ++ (44 :: suffix))
      else none
end

/-- The byte and node checks are part of the accepted transport domain. -/
def serializeChecked (raw : Raw) : Option (List Nat) :=
  if withinBounds raw then
    match serializeRaw transportFuel transportDepth raw with
    | none => none
    | some bytes => if bytes.length ≤ transportByteLimit then some bytes else none
  else none

def digitByte (byte : Nat) : Bool := decide (48 ≤ byte ∧ byte ≤ 57)

/-- Called after an opening quote. It consumes its closing quote, never escapes. -/
def parseStringTail : List Nat → List Nat → Option (List Nat × List Nat)
  | [], _ => none
  | byte :: rest, reversed =>
    if byte = 34 then some (reversed.reverse, rest)
    else if stringByte byte then parseStringTail rest (byte :: reversed)
    else none

def parseDigits : List Nat → Nat → Nat × List Nat
  | [], value => (value, [])
  | byte :: rest, value =>
    if digitByte byte then parseDigits rest (value * 10 + (byte - 48))
    else (value, byte :: rest)

/-- A zero cannot be followed by another decimal digit. A separator is checked
    by the enclosing parser or by decode's full-consumption check. -/
def parseNumber : List Nat → Option (Nat × List Nat)
  | [] => none
  | byte :: rest =>
    if byte = 48 then
      match rest with
      | next :: _ => if digitByte next then none else some (0, rest)
      | [] => some (0, [])
    else if decide (49 ≤ byte ∧ byte ≤ 57) then
      some (parseDigits rest (byte - 48))
    else none

mutual
  /-- Independent, fuelled parser. Whitespace, escape sequences, signs,
      decimals, bool and null have no admitting parser case. -/
  def parseRaw : Nat → Nat → List Nat → Option (Raw × List Nat)
    | 0, _, _ => none
    | _ + 1, 0, _ => none
    | _ + 1, _ + 1, 34 :: rest => do
      let (bytes, suffix) ← parseStringTail rest []
      pure (.str bytes, suffix)
    | _ + 1, _ + 1, 91 :: 93 :: rest => some (.arr [], rest)
    | fuel + 1, depth + 1, 91 :: rest => do
      let (items, suffix) ← parseItems fuel depth rest
      pure (.arr items, suffix)
    | _ + 1, _ + 1, 123 :: 125 :: rest => some (.obj [], rest)
    | fuel + 1, depth + 1, 123 :: rest => do
      let (fields, suffix) ← parseFields fuel depth rest
      if orderedFields fields then pure (.obj fields, suffix) else none
    | _ + 1, _ + 1, bytes => do
      let (value, suffix) ← parseNumber bytes
      pure (.num value, suffix)

  /-- Nonempty array contents only. A trailing comma therefore cannot pass. -/
  def parseItems : Nat → Nat → List Nat → Option (List Raw × List Nat)
    | 0, _, _ => none
    | fuel + 1, depth, bytes => do
      let (value, suffix) ← parseRaw fuel depth bytes
      match suffix with
      | 93 :: rest => pure ([value], rest)
      | 44 :: rest =>
        let (values, suffix) ← parseItems fuel depth rest
        pure (value :: values, suffix)
      | _ => none

  /-- Nonempty object contents only. Keys must be unescaped strings. -/
  def parseFields : Nat → Nat → List Nat → Option (List (List Nat × Raw) × List Nat)
    | 0, _, _ => none
    | fuel + 1, depth, 34 :: rest => do
      let (key, suffix) ← parseStringTail rest []
      match suffix with
      | 58 :: rest =>
        let (value, suffix) ← parseRaw fuel depth rest
        match suffix with
        | 125 :: rest => pure ([(key, value)], rest)
        | 44 :: rest =>
          let (fields, suffix) ← parseFields fuel depth rest
          pure ((key, value) :: fields, suffix)
        | _ => none
      | _ => none
    | _ + 1, _, _ => none
end

/-- Full consumption, exact byte limit, and whole-tree node limit are mandatory.
    Parser recursion is bounded independently of the value-node counter. -/
def decode (bytes : List Nat) : Option Raw :=
  if bytes.length ≤ transportByteLimit ∧
      bytes.all (fun byte => decide (byte ≤ 255)) = true then
    match parseRaw transportFuel transportDepth bytes with
    | some (raw, []) => if withinBounds raw then some raw else none
    | _ => none
  else none

/-- Successful encoding includes a decoder equality check, not an assumption
    that structurally different inputs cannot happen to emit equal bytes. -/
def checkedEncode (raw : Raw) : Option (List Nat) :=
  match serializeChecked raw with
  | none => none
  | some bytes => if decode bytes = some raw then some bytes else none

/-- Compose separately kernel-checked computational certificates without
    weakening the full byte equality or any transport bound. The premises
    concern the same raw tree and the same independently supplied byte list. -/
theorem checkedEncode_of_parts (raw : Raw) (bytes : List Nat)
    (bounds : withinBounds raw = true)
    (serialized : serializeRaw transportFuel transportDepth raw = some bytes)
    (parsed : parseRaw transportFuel transportDepth bytes = some (raw, []))
    (boundedLength : bytes.length ≤ transportByteLimit)
    (byteRange : bytes.all (fun byte => decide (byte ≤ 255)) = true) :
    checkedEncode raw = some bytes := by
  have encoded : serializeChecked raw = some bytes := by
    simp [serializeChecked, bounds, serialized, boundedLength]
  have decoded : decode bytes = some raw := by
    simp [decode, boundedLength, byteRange, parsed, bounds]
  simp [checkedEncode, encoded, decoded]

/-- Generic checked round trip. This says nothing about unaccepted inputs. -/
theorem checkedEncode_roundtrip (raw : Raw) (bytes : List Nat)
    (accepted : checkedEncode raw = some bytes) : decode bytes = some raw := by
  unfold checkedEncode at accepted
  cases encoded : serializeChecked raw with
  | none => simp [encoded] at accepted
  | some candidate =>
    by_cases parsed : decode candidate = some raw
    · have same : candidate = bytes := by simpa [encoded, parsed] using accepted
      simpa [same] using parsed
    · simp [encoded, parsed] at accepted

/-- Equal accepted bytes identify one inert whole-document Raw tree. The proof
    uses decoder equality and does not postulate serializer injectivity. -/
theorem checkedEncode_determinate (a b : Raw) (bytes : List Nat)
    (left : checkedEncode a = some bytes)
    (right : checkedEncode b = some bytes) : a = b := by
  have decodedLeft := checkedEncode_roundtrip a bytes left
  have decodedRight := checkedEncode_roundtrip b bytes right
  exact Option.some.inj (decodedLeft.symm.trans decodedRight)


end HiaCoreSyntaxSlice

#print axioms HiaCoreSyntaxSlice.checkedEncode_determinate
#print axioms HiaCoreSyntaxSlice.checkedEncode_of_parts
#print axioms HiaCoreSyntaxSlice.checkedEncode_roundtrip
/-!
UNCHECKED helper proof text until the pinned Lean 4.19 kernel accepts it.
Append after the exact transport portion of CoreSyntaxSlice.lean. No imports.

These are one-step equalities for the existing functions, not replacement
semantics. The f/d parameters are the precise child call arguments. No rule
resets fuel, drops a suffix, admits a numeric boundary, or supplies a fact from
Python. Concrete leaf certificates and all byte/source bindings remain required.
-/

namespace HiaCoreSyntaxSlice.Structured

/-- The child list call uses exactly f and d. -/
theorem serialize_array (f d : Nat) (items : List Raw) (output : List Nat)
    (children : serializeItems f d items = some output) :
    serializeRaw (f + 1) (d + 1) (.arr items) =
      some (91 :: (output ++ [93])) := by
  simp [serializeRaw, children]

theorem serialize_object (f d : Nat) (fields : List (List Nat × Raw))
    (output : List Nat) (ordered : orderedFields fields = true)
    (children : serializeFields f d fields = some output) :
    serializeRaw (f + 1) (d + 1) (.obj fields) =
      some (123 :: (output ++ [125])) := by
  simp [serializeRaw, ordered, children]

theorem serialize_items_nil (f d : Nat) :
    serializeItems f d [] = some [] := by
  cases f <;> rfl

theorem serialize_items_single (f d : Nat) (value : Raw) (output : List Nat)
    (child : serializeRaw f d value = some output) :
    serializeItems (f + 1) d [value] = some output := by
  simp [serializeItems, child]

theorem serialize_items_cons (f d : Nat) (value next : Raw) (rest : List Raw)
    (output suffix : List Nat)
    (child : serializeRaw f d value = some output)
    (children : serializeItems f d (next :: rest) = some suffix) :
    serializeItems (f + 1) d (value :: next :: rest) =
      some (output ++ (44 :: suffix)) := by
  simp [serializeItems, child, children]

theorem serialize_fields_nil (f d : Nat) :
    serializeFields f d [] = some [] := by
  cases f <;> rfl

theorem serialize_fields_single (f d : Nat) (key : List Nat) (value : Raw)
    (output : List Nat) (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output) :
    serializeFields (f + 1) d [(key, value)] =
      some (34 :: (key ++ (34 :: 58 :: output))) := by
  simp [serializeFields, keyDomain, child]

theorem serialize_fields_cons (f d : Nat) (key : List Nat) (value : Raw)
    (next : List Nat × Raw) (rest : List (List Nat × Raw))
    (output suffix : List Nat) (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output)
    (children : serializeFields f d (next :: rest) = some suffix) :
    serializeFields (f + 1) d ((key, value) :: next :: rest) =
      some ((34 :: (key ++ (34 :: 58 :: output))) ++ (44 :: suffix)) := by
  simp [serializeFields, keyDomain, child, children]

theorem serialize_string (f d : Nat) (value : List Nat)
    (domain : stringBytes value = true) :
    serializeRaw (f + 1) (d + 1) (.str value) =
      some (34 :: (value ++ [34])) := by
  simp [serializeRaw, domain]

theorem serialize_number (f d value : Nat) (output : List Nat)
    (digits : decimal value = some output) :
    serializeRaw (f + 1) (d + 1) (.num value) = some output := by
  simp [serializeRaw, digits]

/-- Exclude the earlier empty-array pattern before applying the list rule. -/
theorem parse_array (f d : Nat) (input tail : List Nat) (items : List Raw)
    (notEmptyClose : input.head? ≠ some 93)
    (children : parseItems f d input = some (items, tail)) :
    parseRaw (f + 1) (d + 1) (91 :: input) = some (.arr items, tail) := by
  unfold parseRaw
  split
  case h_1 => omega
  case h_2 => omega
  case h_3 =>
    rename_i hinput
    have bad : (91 : Nat) = 34 := (List.cons.inj hinput).1
    omega
  case h_4 =>
    rename_i hinput
    exact False.elim
      (notEmptyClose (congrArg List.head? (List.cons.inj hinput).2))
  case h_5 =>
    rename_i childFuel childDepth rest excluded hf hd hinput
    have fuelEq : f = childFuel := Nat.succ.inj hf
    have depthEq : d = childDepth := Nat.succ.inj hd
    have inputEq : input = rest := (List.cons.inj hinput).2
    rw [← fuelEq, ← depthEq, ← inputEq, children] <;> rfl
  case h_6 =>
    rename_i hinput
    have bad : (91 : Nat) = 123 := (List.cons.inj hinput).1
    omega
  case h_7 =>
    rename_i hinput
    have bad : (91 : Nat) = 123 := (List.cons.inj hinput).1
    omega
  case h_8 =>
    rename_i noString noEmptyArray noArray noEmptyObject noObject
    exact False.elim (noArray input rfl)

/-- The explicit opening quote excludes the earlier empty-object pattern. -/
theorem parse_object (f d : Nat) (input tail : List Nat)
    (fields : List (List Nat × Raw))
    (ordered : orderedFields fields = true)
    (children : parseFields f d (34 :: input) = some (fields, tail)) :
    parseRaw (f + 1) (d + 1) (123 :: 34 :: input) =
      some (.obj fields, tail) := by
  simp [parseRaw, children, ordered]

theorem parse_items_last (f d : Nat) (input tail : List Nat) (value : Raw)
    (child : parseRaw f d input = some (value, 93 :: tail)) :
    parseItems (f + 1) d input = some ([value], tail) := by
  simp [parseItems, child]

theorem parse_items_cons (f d : Nat) (input middle tail : List Nat)
    (value : Raw) (rest : List Raw)
    (child : parseRaw f d input = some (value, 44 :: middle))
    (children : parseItems f d middle = some (rest, tail)) :
    parseItems (f + 1) d input = some (value :: rest, tail) := by
  simp [parseItems, child, children]

theorem parse_fields_last (f d : Nat) (keyInput key valueInput tail : List Nat)
    (value : Raw)
    (keyRead : parseStringTail keyInput [] = some (key, 58 :: valueInput))
    (child : parseRaw f d valueInput = some (value, 125 :: tail)) :
    parseFields (f + 1) d (34 :: keyInput) = some ([(key, value)], tail) := by
  simp [parseFields, keyRead, child]

theorem parse_fields_cons (f d : Nat)
    (keyInput key valueInput middle tail : List Nat)
    (value : Raw) (rest : List (List Nat × Raw))
    (keyRead : parseStringTail keyInput [] = some (key, 58 :: valueInput))
    (child : parseRaw f d valueInput = some (value, 44 :: middle))
    (children : parseFields f d middle = some (rest, tail)) :
    parseFields (f + 1) d (34 :: keyInput) = some ((key, value) :: rest, tail) := by
  simp [parseFields, keyRead, child, children]

theorem parse_empty_array (f d : Nat) (tail : List Nat) :
    parseRaw (f + 1) (d + 1) (91 :: 93 :: tail) = some (.arr [], tail) := by
  rfl

theorem parse_empty_object (f d : Nat) (tail : List Nat) :
    parseRaw (f + 1) (d + 1) (123 :: 125 :: tail) = some (.obj [], tail) := by
  rfl

theorem parse_string (f d : Nat) (input value tail : List Nat)
    (characters : parseStringTail input [] = some (value, tail)) :
    parseRaw (f + 1) (d + 1) (34 :: input) = some (.str value, tail) := by
  simp [parseRaw, characters]

/-- Reading a valid quoted prefix does not inspect the suffix after its quote.
    The accumulator form supports induction without assumptions about that suffix. -/
theorem parse_string_tail_prefix (segment suffix acc : List Nat) :
    stringBytes segment = true →
    parseStringTail (segment ++ (34 :: suffix)) acc =
      some (acc.reverse ++ segment, suffix) := by
  induction segment generalizing acc with
  | nil =>
    intro _domain
    simp [parseStringTail]
  | cons first rest previous =>
    intro domain
    have parts : stringByte first = true ∧ stringBytes rest = true := by
      simpa only [stringBytes, Bool.and_eq_true] using domain
    have allowed : 32 ≤ first ∧ first ≤ 126 ∧ first ≠ 34 ∧ first ≠ 92 := by
      simpa [stringByte] using parts.1
    have notQuote : first ≠ 34 := allowed.2.2.1
    have remaining := previous (first :: acc) parts.2
    simpa [parseStringTail, notQuote, parts.1, List.reverse_cons, List.append_assoc]
      using remaining

/-- A key packet supplies its checked domain and this symbolic-tail equation. -/
theorem parse_key_prefix (key tail : List Nat) (domain : stringBytes key = true) :
    parseStringTail (key ++ (34 :: 58 :: tail)) [] = some (key, 58 :: tail) := by
  simpa using parse_string_tail_prefix key (58 :: tail) [] domain

/-
Leaf-generation contract (not an extra theorem or assumed fact):

For nonnumeric complete leaf bytes b and Raw r at exact F,D, prove
  ∀ tail, parseRaw F D (b ++ tail) = some (r, tail).
For a numeric leaf use its actual structural delimiter c ∈ {44,93,125}:
  ∀ tail, parseRaw F D (b ++ (c :: tail)) = some (r, c :: tail).
For a key k, prove stringBytes k = true and
  ∀ tail, parseStringTail (k ++ (34 :: 58 :: tail)) [] = some (k, 58 :: tail).

These are closed small-prefix proofs after introducing the symbolic tail.
Unfold only the local leaf/key definitions. Never replace the numeric form with
an arbitrary-suffix extension rule: decimal bytes [49] followed by [50] parse
as 12. Root composition must still return the exact empty suffix.
-/

/-- Decimal digits cannot be split by an arbitrary suffix-extension rule. -/
theorem reject_numeric_split :
    ¬ (parseRaw 2 2 [49, 50] = some (.num 1, [50])) := by
  intro claim
  change some (Raw.num 12, ([] : List Nat)) = some (Raw.num 1, [50]) at claim
  have tails : ([] : List Nat) = [50] := congrArg Prod.snd (Option.some.inj claim)
  cases tails

/-- A colon cannot replace the comma between two array items. -/
theorem reject_wrong_separator :
    ¬ (parseRaw 8 4 [91, 49, 58, 50, 93] =
      some (.arr [.num 1, .num 2], [])) := by
  decide +kernel

/-- An object close cannot terminate an array. -/
theorem reject_wrong_closing :
    ¬ (parseRaw 8 4 [91, 49, 125] = some (.arr [.num 1], [])) := by
  decide +kernel

/-- A successful prefix parse does not authorize dropping remaining bytes. -/
theorem reject_trailing_bytes :
    ¬ (parseRaw 2 2 [91, 93, 48] = some (.arr [], [])) ∧
    ¬ (decode [91, 93, 48] = some (.arr [])) := by
  constructor
  · intro claim
    change some (Raw.arr [], [48]) = some (Raw.arr [], ([] : List Nat)) at claim
    have tails : [48] = ([] : List Nat) := congrArg Prod.snd (Option.some.inj claim)
    cases tails
  · intro claim
    change none = some (Raw.arr []) at claim
    cases claim

theorem reject_insufficient_fuel :
    ¬ (parseRaw 0 2 [48] = some (.num 0, [])) := by
  decide +kernel

theorem reject_insufficient_depth :
    ¬ (parseRaw 2 0 [48] = some (.num 0, [])) := by
  decide +kernel

/-- Fixed Raw cannot justify a different literal byte inside its encoding. -/
theorem reject_changed_leaf_byte :
    ¬ (serializeRaw 2 2 (.str [97]) = some [34, 98, 34]) := by
  decide +kernel

/-- Both distinct sufficient fuel values succeed. Fuel inequality alone is
    not a sound negative-control criterion. -/
theorem reject_distinct_sufficient_fuel_failure :
    ¬ (parseRaw 1 1 [48] ≠ some (.num 0, []) ∨
       parseRaw 2 1 [48] ≠ some (.num 0, [])) := by
  intro failure
  cases failure with
  | inl rejected => exact rejected rfl
  | inr rejected => exact rejected rfl

end HiaCoreSyntaxSlice.Structured
#print axioms HiaCoreSyntaxSlice.Structured.parse_array
#print axioms HiaCoreSyntaxSlice.Structured.parse_empty_array
#print axioms HiaCoreSyntaxSlice.Structured.parse_empty_object
#print axioms HiaCoreSyntaxSlice.Structured.parse_fields_cons
#print axioms HiaCoreSyntaxSlice.Structured.parse_fields_last
#print axioms HiaCoreSyntaxSlice.Structured.parse_items_cons
#print axioms HiaCoreSyntaxSlice.Structured.parse_items_last
#print axioms HiaCoreSyntaxSlice.Structured.parse_key_prefix
#print axioms HiaCoreSyntaxSlice.Structured.parse_object
#print axioms HiaCoreSyntaxSlice.Structured.parse_string
#print axioms HiaCoreSyntaxSlice.Structured.parse_string_tail_prefix
#print axioms HiaCoreSyntaxSlice.Structured.reject_changed_leaf_byte
#print axioms HiaCoreSyntaxSlice.Structured.reject_distinct_sufficient_fuel_failure
#print axioms HiaCoreSyntaxSlice.Structured.reject_insufficient_depth
#print axioms HiaCoreSyntaxSlice.Structured.reject_insufficient_fuel
#print axioms HiaCoreSyntaxSlice.Structured.reject_numeric_split
#print axioms HiaCoreSyntaxSlice.Structured.reject_trailing_bytes
#print axioms HiaCoreSyntaxSlice.Structured.reject_wrong_closing
#print axioms HiaCoreSyntaxSlice.Structured.reject_wrong_separator
#print axioms HiaCoreSyntaxSlice.Structured.serialize_array
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_cons
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_nil
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_single
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_cons
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_nil
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_single
#print axioms HiaCoreSyntaxSlice.Structured.serialize_number
#print axioms HiaCoreSyntaxSlice.Structured.serialize_object
#print axioms HiaCoreSyntaxSlice.Structured.serialize_string
/-!
UNCHECKED Lean 4.19 proof text for the source-only byte-facts experiment.
Insert this fragment in SyntaxData; no additional import is required.
Pinned library declarations were source-checked at leanprover/lean4 v4.19.0:
Init/Data/List/Basic.lean: length_cons, all_cons, length_append.
Init/Data/List/Lemmas.lean: all_append.
Init/Prelude.lean: decide_eq_true.
This fragment has not been elaborated or kernel-checked.
-/

namespace HiaCoreSyntaxSlice.ByteFactsResearch

def facts (xs : List Nat) (n : Nat) : Prop :=
  xs.length = n ∧ xs.all (fun b => decide (b ≤ 255)) = true

theorem nil : facts ([] : List Nat) (0 : Nat) := by
  exact ⟨rfl, rfl⟩

theorem cons (b : Nat) (xs : List Nat) (n : Nat)
    (byteBound : b ≤ 255) (child : facts xs n) : facts (b :: xs) (n + 1) := by
  constructor
  · rw [List.length_cons, child.1]
  · rw [List.all_cons, decide_eq_true byteBound, child.2]
    rfl

theorem append (xs ys : List Nat) (n m : Nat)
    (left : facts xs n) (right : facts ys m) : facts (xs ++ ys) (n + m) := by
  constructor
  · rw [List.length_append, left.1, right.1]
  · rw [List.all_append, left.2, right.2]
    rfl

end HiaCoreSyntaxSlice.ByteFactsResearch
#print axioms HiaCoreSyntaxSlice.ByteFactsResearch.append
#print axioms HiaCoreSyntaxSlice.ByteFactsResearch.cons
#print axioms HiaCoreSyntaxSlice.ByteFactsResearch.nil
-- SEVEN_CERTIFICATE_PREFIX_V1
namespace HiaCoreSyntaxSlice
def linear_g0 : List Nat := [123]
def linear_g1 : List Nat := [34,101,120,112,111,114,116,115,34,58]
def linear_g2 : List Nat := [91,34,99,97,108,99,117,108,97,116,101,34,93]
def linear_g3 : List Nat := [44]
def linear_g4 : List Nat := [34,102,117,110,99,116,105,111,110,115,34,58]
def linear_g5 : List Nat := [91]
def linear_g6 : List Nat := [123]
def linear_g7 : List Nat := [34,98,108,111,99,107,115,34,58]
def linear_g8 : List Nat := [91]
def linear_g9 : List Nat := [123]
def linear_g10 : List Nat := [34,105,100,34,58]
def linear_g11 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g12 : List Nat := [44]
def linear_g13 : List Nat := [34,111,112,115,34,58]
def linear_g14 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,116,114,121,95,110,101,119,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,93]
def linear_g15 : List Nat := [44]
def linear_g16 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g17 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g18 : List Nat := [44]
def linear_g19 : List Nat := [34,116,101,114,109,34,58]
def linear_g20 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,125,125]
def linear_g21 : List Nat := [125]
def linear_g22 : List Nat := [44]
def linear_g23 : List Nat := [123]
def linear_g24 : List Nat := [34,105,100,34,58]
def linear_g25 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,49,34]
def linear_g26 : List Nat := [44]
def linear_g27 : List Nat := [34,111,112,115,34,58]
def linear_g28 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g29 : List Nat := [44]
def linear_g30 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g31 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g32 : List Nat := [44]
def linear_g33 : List Nat := [34,116,101,114,109,34,58]
def linear_g34 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,52,34,44,34,100,103,95,118,95,56,34,44,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,57,34,44,34,100,103,95,118,95,49,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,125]
def linear_g35 : List Nat := [125]
def linear_g36 : List Nat := [44]
def linear_g37 : List Nat := [123]
def linear_g38 : List Nat := [34,105,100,34,58]
def linear_g39 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,50,34]
def linear_g40 : List Nat := [44]
def linear_g41 : List Nat := [34,111,112,115,34,58]
def linear_g42 : List Nat := [91]
def linear_g43 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125]
def linear_g44 : List Nat := [44]
def linear_g45 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,48,48,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g46 : List Nat := [44]
def linear_g47 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g48 : List Nat := [44]
def linear_g49 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,34,44,34,100,103,95,118,95,49,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g50 : List Nat := [93]
def linear_g51 : List Nat := [44]
def linear_g52 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g53 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g54 : List Nat := [44]
def linear_g55 : List Nat := [34,116,101,114,109,34,58]
def linear_g56 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,56,34,93,125]
def linear_g57 : List Nat := [125]
def linear_g58 : List Nat := [44]
def linear_g59 : List Nat := [123]
def linear_g60 : List Nat := [34,105,100,34,58]
def linear_g61 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,51,34]
def linear_g62 : List Nat := [44]
def linear_g63 : List Nat := [34,111,112,115,34,58]
def linear_g64 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g65 : List Nat := [44]
def linear_g66 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g67 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g68 : List Nat := [44]
def linear_g69 : List Nat := [34,116,101,114,109,34,58]
def linear_g70 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,50,53,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,48,34,125,125]
def linear_g71 : List Nat := [125]
def linear_g72 : List Nat := [44]
def linear_g73 : List Nat := [123]
def linear_g74 : List Nat := [34,105,100,34,58]
def linear_g75 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,52,34]
def linear_g76 : List Nat := [44]
def linear_g77 : List Nat := [34,111,112,115,34,58]
def linear_g78 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,50,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g79 : List Nat := [44]
def linear_g80 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g81 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g82 : List Nat := [44]
def linear_g83 : List Nat := [34,116,101,114,109,34,58]
def linear_g84 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,50,56,34,44,34,100,103,95,118,95,50,57,34,44,34,100,103,95,118,95,51,50,34,44,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,51,51,34,44,34,100,103,95,118,95,51,52,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,125]
def linear_g85 : List Nat := [125]
def linear_g86 : List Nat := [44]
def linear_g87 : List Nat := [123]
def linear_g88 : List Nat := [34,105,100,34,58]
def linear_g89 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,53,34]
def linear_g90 : List Nat := [44]
def linear_g91 : List Nat := [34,111,112,115,34,58]
def linear_g92 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,51,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g93 : List Nat := [44]
def linear_g94 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g95 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g96 : List Nat := [44]
def linear_g97 : List Nat := [34,116,101,114,109,34,58]
def linear_g98 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,52,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,49,34,125,125]
def linear_g99 : List Nat := [125]
def linear_g100 : List Nat := [44]
def linear_g101 : List Nat := [123]
def linear_g102 : List Nat := [34,105,100,34,58]
def linear_g103 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,54,34]
def linear_g104 : List Nat := [44]
def linear_g105 : List Nat := [34,111,112,115,34,58]
def linear_g106 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g107 : List Nat := [44]
def linear_g108 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g109 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,53,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g110 : List Nat := [44]
def linear_g111 : List Nat := [34,116,101,114,109,34,58]
def linear_g112 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,52,54,34,93,125]
def linear_g113 : List Nat := [125]
def linear_g114 : List Nat := [44]
def linear_g115 : List Nat := [123]
def linear_g116 : List Nat := [34,105,100,34,58]
def linear_g117 : List Nat := [34,100,103,95,102,97,115,116,95,48,34]
def linear_g118 : List Nat := [44]
def linear_g119 : List Nat := [34,111,112,115,34,58]
def linear_g120 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,54,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g121 : List Nat := [44]
def linear_g122 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g123 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g124 : List Nat := [44]
def linear_g125 : List Nat := [34,116,101,114,109,34,58]
def linear_g126 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,53,54,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g127 : List Nat := [125]
def linear_g128 : List Nat := [44]
def linear_g129 : List Nat := [123]
def linear_g130 : List Nat := [34,105,100,34,58]
def linear_g131 : List Nat := [34,100,103,95,102,97,115,116,95,49,34]
def linear_g132 : List Nat := [44]
def linear_g133 : List Nat := [34,111,112,115,34,58]
def linear_g134 : List Nat := [91]
def linear_g135 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g136 : List Nat := [44]
def linear_g137 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,50,34,44,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,51,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g138 : List Nat := [44]
def linear_g139 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,52,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g140 : List Nat := [44]
def linear_g141 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g142 : List Nat := [44]
def linear_g143 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,52,34,44,34,100,103,95,118,95,54,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,54,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g144 : List Nat := [44]
def linear_g145 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,54,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g146 : List Nat := [44]
def linear_g147 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,56,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g148 : List Nat := [44]
def linear_g149 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,44,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g150 : List Nat := [44]
def linear_g151 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g152 : List Nat := [44]
def linear_g153 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g154 : List Nat := [44]
def linear_g155 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g156 : List Nat := [93]
def linear_g157 : List Nat := [44]
def linear_g158 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g159 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g160 : List Nat := [44]
def linear_g161 : List Nat := [34,116,101,114,109,34,58]
def linear_g162 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,55,34,44,34,100,103,95,118,95,53,56,34,44,34,100,103,95,118,95,53,57,34,44,34,100,103,95,118,95,54,48,34,44,34,100,103,95,118,95,55,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,48,34,125]
def linear_g163 : List Nat := [125]
def linear_g164 : List Nat := [44]
def linear_g165 : List Nat := [123]
def linear_g166 : List Nat := [34,105,100,34,58]
def linear_g167 : List Nat := [34,100,103,95,102,97,115,116,95,50,34]
def linear_g168 : List Nat := [44]
def linear_g169 : List Nat := [34,111,112,115,34,58]
def linear_g170 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g171 : List Nat := [44]
def linear_g172 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g173 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g174 : List Nat := [44]
def linear_g175 : List Nat := [34,116,101,114,109,34,58]
def linear_g176 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,50,34,44,34,100,103,95,118,95,55,51,34,44,34,100,103,95,118,95,55,54,34,44,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,55,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g177 : List Nat := [125]
def linear_g178 : List Nat := [44]
def linear_g179 : List Nat := [123]
def linear_g180 : List Nat := [34,105,100,34,58]
def linear_g181 : List Nat := [34,100,103,95,102,97,115,116,95,51,34]
def linear_g182 : List Nat := [44]
def linear_g183 : List Nat := [34,111,112,115,34,58]
def linear_g184 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,51,34,44,34,100,103,95,118,95,56,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g185 : List Nat := [44]
def linear_g186 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g187 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g188 : List Nat := [44]
def linear_g189 : List Nat := [34,116,101,114,109,34,58]
def linear_g190 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,56,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g191 : List Nat := [125]
def linear_g192 : List Nat := [44]
def linear_g193 : List Nat := [123]
def linear_g194 : List Nat := [34,105,100,34,58]
def linear_g195 : List Nat := [34,100,103,95,102,97,115,116,95,52,34]
def linear_g196 : List Nat := [44]
def linear_g197 : List Nat := [34,111,112,115,34,58]
def linear_g198 : List Nat := [91]
def linear_g199 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,49,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g200 : List Nat := [44]
def linear_g201 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,44,34,100,103,95,118,95,57,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g202 : List Nat := [44]
def linear_g203 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g204 : List Nat := [44]
def linear_g205 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,50,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g206 : List Nat := [44]
def linear_g207 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,56,34,44,34,100,103,95,118,95,57,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g208 : List Nat := [44]
def linear_g209 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g210 : List Nat := [44]
def linear_g211 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,48,34,44,34,100,103,95,118,95,57,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g212 : List Nat := [93]
def linear_g213 : List Nat := [44]
def linear_g214 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g215 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g216 : List Nat := [44]
def linear_g217 : List Nat := [34,116,101,114,109,34,58]
def linear_g218 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,53,34,44,34,100,103,95,118,95,56,54,34,44,34,100,103,95,118,95,56,55,34,44,34,100,103,95,118,95,57,52,34,44,34,100,103,95,118,95,56,57,34,44,34,100,103,95,118,95,57,54,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g219 : List Nat := [125]
def linear_g220 : List Nat := [44]
def linear_g221 : List Nat := [123]
def linear_g222 : List Nat := [34,105,100,34,58]
def linear_g223 : List Nat := [34,100,103,95,102,97,115,116,95,53,34]
def linear_g224 : List Nat := [44]
def linear_g225 : List Nat := [34,111,112,115,34,58]
def linear_g226 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g227 : List Nat := [44]
def linear_g228 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g229 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,48,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g230 : List Nat := [44]
def linear_g231 : List Nat := [34,116,101,114,109,34,58]
def linear_g232 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,48,48,34,93,125]
def linear_g233 : List Nat := [125]
def linear_g234 : List Nat := [44]
def linear_g235 : List Nat := [123]
def linear_g236 : List Nat := [34,105,100,34,58]
def linear_g237 : List Nat := [34,100,103,95,115,108,111,119,95,48,34]
def linear_g238 : List Nat := [44]
def linear_g239 : List Nat := [34,111,112,115,34,58]
def linear_g240 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,56,34,44,34,100,103,95,118,95,49,48,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,57,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g241 : List Nat := [44]
def linear_g242 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g243 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g244 : List Nat := [44]
def linear_g245 : List Nat := [34,116,101,114,109,34,58]
def linear_g246 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,48,57,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,125]
def linear_g247 : List Nat := [125]
def linear_g248 : List Nat := [44]
def linear_g249 : List Nat := [123]
def linear_g250 : List Nat := [34,105,100,34,58]
def linear_g251 : List Nat := [34,100,103,95,115,108,111,119,95,49,34]
def linear_g252 : List Nat := [44]
def linear_g253 : List Nat := [34,111,112,115,34,58]
def linear_g254 : List Nat := [91]
def linear_g255 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g256 : List Nat := [44]
def linear_g257 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,53,34,44,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g258 : List Nat := [44]
def linear_g259 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g260 : List Nat := [44]
def linear_g261 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,56,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g262 : List Nat := [44]
def linear_g263 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,55,34,44,34,100,103,95,118,95,49,49,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,57,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g264 : List Nat := [44]
def linear_g265 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,57,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,48,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g266 : List Nat := [44]
def linear_g267 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,49,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g268 : List Nat := [44]
def linear_g269 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,44,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g270 : List Nat := [44]
def linear_g271 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g272 : List Nat := [44]
def linear_g273 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g274 : List Nat := [44]
def linear_g275 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g276 : List Nat := [93]
def linear_g277 : List Nat := [44]
def linear_g278 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g279 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g280 : List Nat := [44]
def linear_g281 : List Nat := [34,116,101,114,109,34,58]
def linear_g282 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,48,34,44,34,100,103,95,118,95,49,49,49,34,44,34,100,103,95,118,95,49,49,50,34,44,34,100,103,95,118,95,49,49,51,34,44,34,100,103,95,118,95,49,50,51,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,48,34,125]
def linear_g283 : List Nat := [125]
def linear_g284 : List Nat := [44]
def linear_g285 : List Nat := [123]
def linear_g286 : List Nat := [34,105,100,34,58]
def linear_g287 : List Nat := [34,100,103,95,115,108,111,119,95,50,34]
def linear_g288 : List Nat := [44]
def linear_g289 : List Nat := [34,111,112,115,34,58]
def linear_g290 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,57,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g291 : List Nat := [44]
def linear_g292 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g293 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g294 : List Nat := [44]
def linear_g295 : List Nat := [34,116,101,114,109,34,58]
def linear_g296 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,50,53,34,44,34,100,103,95,118,95,49,50,54,34,44,34,100,103,95,118,95,49,50,57,34,44,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,51,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g297 : List Nat := [125]
def linear_g298 : List Nat := [44]
def linear_g299 : List Nat := [123]
def linear_g300 : List Nat := [34,105,100,34,58]
def linear_g301 : List Nat := [34,100,103,95,115,108,111,119,95,51,34]
def linear_g302 : List Nat := [44]
def linear_g303 : List Nat := [34,111,112,115,34,58]
def linear_g304 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,54,34,44,34,100,103,95,118,95,49,51,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,55,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g305 : List Nat := [44]
def linear_g306 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g307 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g308 : List Nat := [44]
def linear_g309 : List Nat := [34,116,101,114,109,34,58]
def linear_g310 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,51,55,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,125]
def linear_g311 : List Nat := [125]
def linear_g312 : List Nat := [44]
def linear_g313 : List Nat := [123]
def linear_g314 : List Nat := [34,105,100,34,58]
def linear_g315 : List Nat := [34,100,103,95,115,108,111,119,95,52,34]
def linear_g316 : List Nat := [44]
def linear_g317 : List Nat := [34,111,112,115,34,58]
def linear_g318 : List Nat := [91]
def linear_g319 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,52,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g320 : List Nat := [44]
def linear_g321 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,44,34,100,103,95,118,95,49,52,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g322 : List Nat := [44]
def linear_g323 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g324 : List Nat := [44]
def linear_g325 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g326 : List Nat := [44]
def linear_g327 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,49,34,44,34,100,103,95,118,95,49,52,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g328 : List Nat := [44]
def linear_g329 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g330 : List Nat := [44]
def linear_g331 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,51,34,44,34,100,103,95,118,95,49,52,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g332 : List Nat := [93]
def linear_g333 : List Nat := [44]
def linear_g334 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g335 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g336 : List Nat := [44]
def linear_g337 : List Nat := [34,116,101,114,109,34,58]
def linear_g338 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,56,34,44,34,100,103,95,118,95,49,51,57,34,44,34,100,103,95,118,95,49,52,48,34,44,34,100,103,95,118,95,49,52,55,34,44,34,100,103,95,118,95,49,52,50,34,44,34,100,103,95,118,95,49,52,57,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g339 : List Nat := [125]
def linear_g340 : List Nat := [44]
def linear_g341 : List Nat := [123]
def linear_g342 : List Nat := [34,105,100,34,58]
def linear_g343 : List Nat := [34,100,103,95,115,108,111,119,95,53,34]
def linear_g344 : List Nat := [44]
def linear_g345 : List Nat := [34,111,112,115,34,58]
def linear_g346 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g347 : List Nat := [44]
def linear_g348 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g349 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g350 : List Nat := [44]
def linear_g351 : List Nat := [34,116,101,114,109,34,58]
def linear_g352 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,53,51,34,93,125]
def linear_g353 : List Nat := [125]
def linear_g354 : List Nat := [44]
def linear_g355 : List Nat := [123]
def linear_g356 : List Nat := [34,105,100,34,58]
def linear_g357 : List Nat := [34,100,103,95,103,117,97,114,100,95,48,34]
def linear_g358 : List Nat := [44]
def linear_g359 : List Nat := [34,111,112,115,34,58]
def linear_g360 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,50,34,44,34,100,103,95,118,95,49,54,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g361 : List Nat := [44]
def linear_g362 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g363 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g364 : List Nat := [44]
def linear_g365 : List Nat := [34,116,101,114,109,34,58]
def linear_g366 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,54,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g367 : List Nat := [125]
def linear_g368 : List Nat := [44]
def linear_g369 : List Nat := [123]
def linear_g370 : List Nat := [34,105,100,34,58]
def linear_g371 : List Nat := [34,100,103,95,103,117,97,114,100,95,49,34]
def linear_g372 : List Nat := [44]
def linear_g373 : List Nat := [34,111,112,115,34,58]
def linear_g374 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,55,49,34,44,34,100,103,95,118,95,49,55,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g375 : List Nat := [44]
def linear_g376 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g377 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g378 : List Nat := [44]
def linear_g379 : List Nat := [34,116,101,114,109,34,58]
def linear_g380 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,55,51,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g381 : List Nat := [125]
def linear_g382 : List Nat := [93]
def linear_g383 : List Nat := [44]
def linear_g384 : List Nat := [34,101,102,102,101,99,116,115,34,58]
def linear_g385 : List Nat := [91,34,97,108,108,111,99,34,44,34,114,101,97,100,34,44,34,116,114,97,112,34,44,34,119,114,105,116,101,34,93]
def linear_g386 : List Nat := [44]
def linear_g387 : List Nat := [34,101,110,116,114,121,34,58]
def linear_g388 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g389 : List Nat := [44]
def linear_g390 : List Nat := [34,110,97,109,101,34,58]
def linear_g391 : List Nat := [34,99,97,108,99,117,108,97,116,101,34]
def linear_g392 : List Nat := [44]
def linear_g393 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g394 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g395 : List Nat := [44]
def linear_g396 : List Nat := [34,114,101,116,117,114,110,115,34,58]
def linear_g397 : List Nat := [91,34,117,54,52,34,93]
def linear_g398 : List Nat := [125]
def linear_g399 : List Nat := [93]
def linear_g400 : List Nat := [44]
def linear_g401 : List Nat := [34,109,111,100,117,108,101,34,58]
def linear_g402 : List Nat := [34,114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114,34]
def linear_g403 : List Nat := [44]
def linear_g404 : List Nat := [34,115,99,104,101,109,97,34,58]
def linear_g405 : List Nat := [34,104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49,34]
def linear_g406 : List Nat := [125]
def linear_t407 : List Nat := []
def linear_t406 : List Nat := linear_g406 ++ linear_t407
def linear_t405 : List Nat := linear_g405 ++ linear_t406
def linear_t404 : List Nat := linear_g404 ++ linear_t405
def linear_t403 : List Nat := linear_g403 ++ linear_t404
def linear_t402 : List Nat := linear_g402 ++ linear_t403
def linear_t401 : List Nat := linear_g401 ++ linear_t402
def linear_t400 : List Nat := linear_g400 ++ linear_t401
def linear_t399 : List Nat := linear_g399 ++ linear_t400
def linear_t398 : List Nat := linear_g398 ++ linear_t399
def linear_t397 : List Nat := linear_g397 ++ linear_t398
def linear_t396 : List Nat := linear_g396 ++ linear_t397
def linear_t395 : List Nat := linear_g395 ++ linear_t396
def linear_t394 : List Nat := linear_g394 ++ linear_t395
def linear_t393 : List Nat := linear_g393 ++ linear_t394
def linear_t392 : List Nat := linear_g392 ++ linear_t393
def linear_t391 : List Nat := linear_g391 ++ linear_t392
def linear_t390 : List Nat := linear_g390 ++ linear_t391
def linear_t389 : List Nat := linear_g389 ++ linear_t390
def linear_t388 : List Nat := linear_g388 ++ linear_t389
def linear_t387 : List Nat := linear_g387 ++ linear_t388
def linear_t386 : List Nat := linear_g386 ++ linear_t387
def linear_t385 : List Nat := linear_g385 ++ linear_t386
def linear_t384 : List Nat := linear_g384 ++ linear_t385
def linear_t383 : List Nat := linear_g383 ++ linear_t384
def linear_t382 : List Nat := linear_g382 ++ linear_t383
def linear_t381 : List Nat := linear_g381 ++ linear_t382
def linear_t380 : List Nat := linear_g380 ++ linear_t381
def linear_t379 : List Nat := linear_g379 ++ linear_t380
def linear_t378 : List Nat := linear_g378 ++ linear_t379
def linear_t377 : List Nat := linear_g377 ++ linear_t378
def linear_t376 : List Nat := linear_g376 ++ linear_t377
def linear_t375 : List Nat := linear_g375 ++ linear_t376
def linear_t374 : List Nat := linear_g374 ++ linear_t375
def linear_t373 : List Nat := linear_g373 ++ linear_t374
def linear_t372 : List Nat := linear_g372 ++ linear_t373
def linear_t371 : List Nat := linear_g371 ++ linear_t372
def linear_t370 : List Nat := linear_g370 ++ linear_t371
def linear_t369 : List Nat := linear_g369 ++ linear_t370
def linear_t368 : List Nat := linear_g368 ++ linear_t369
def linear_t367 : List Nat := linear_g367 ++ linear_t368
def linear_t366 : List Nat := linear_g366 ++ linear_t367
def linear_t365 : List Nat := linear_g365 ++ linear_t366
def linear_t364 : List Nat := linear_g364 ++ linear_t365
def linear_t363 : List Nat := linear_g363 ++ linear_t364
def linear_t362 : List Nat := linear_g362 ++ linear_t363
def linear_t361 : List Nat := linear_g361 ++ linear_t362
def linear_t360 : List Nat := linear_g360 ++ linear_t361
def linear_t359 : List Nat := linear_g359 ++ linear_t360
def linear_t358 : List Nat := linear_g358 ++ linear_t359
def linear_t357 : List Nat := linear_g357 ++ linear_t358
def linear_t356 : List Nat := linear_g356 ++ linear_t357
def linear_t355 : List Nat := linear_g355 ++ linear_t356
def linear_t354 : List Nat := linear_g354 ++ linear_t355
def linear_t353 : List Nat := linear_g353 ++ linear_t354
def linear_t352 : List Nat := linear_g352 ++ linear_t353
def linear_t351 : List Nat := linear_g351 ++ linear_t352
def linear_t350 : List Nat := linear_g350 ++ linear_t351
def linear_t349 : List Nat := linear_g349 ++ linear_t350
def linear_t348 : List Nat := linear_g348 ++ linear_t349
def linear_t347 : List Nat := linear_g347 ++ linear_t348
def linear_t346 : List Nat := linear_g346 ++ linear_t347
def linear_t345 : List Nat := linear_g345 ++ linear_t346
def linear_t344 : List Nat := linear_g344 ++ linear_t345
def linear_t343 : List Nat := linear_g343 ++ linear_t344
def linear_t342 : List Nat := linear_g342 ++ linear_t343
def linear_t341 : List Nat := linear_g341 ++ linear_t342
def linear_t340 : List Nat := linear_g340 ++ linear_t341
def linear_t339 : List Nat := linear_g339 ++ linear_t340
def linear_t338 : List Nat := linear_g338 ++ linear_t339
def linear_t337 : List Nat := linear_g337 ++ linear_t338
def linear_t336 : List Nat := linear_g336 ++ linear_t337
def linear_t335 : List Nat := linear_g335 ++ linear_t336
def linear_t334 : List Nat := linear_g334 ++ linear_t335
def linear_t333 : List Nat := linear_g333 ++ linear_t334
def linear_t332 : List Nat := linear_g332 ++ linear_t333
def linear_t331 : List Nat := linear_g331 ++ linear_t332
def linear_t330 : List Nat := linear_g330 ++ linear_t331
def linear_t329 : List Nat := linear_g329 ++ linear_t330
def linear_t328 : List Nat := linear_g328 ++ linear_t329
def linear_t327 : List Nat := linear_g327 ++ linear_t328
def linear_t326 : List Nat := linear_g326 ++ linear_t327
def linear_t325 : List Nat := linear_g325 ++ linear_t326
def linear_t324 : List Nat := linear_g324 ++ linear_t325
def linear_t323 : List Nat := linear_g323 ++ linear_t324
def linear_t322 : List Nat := linear_g322 ++ linear_t323
def linear_t321 : List Nat := linear_g321 ++ linear_t322
def linear_t320 : List Nat := linear_g320 ++ linear_t321
def linear_t319 : List Nat := linear_g319 ++ linear_t320
def linear_t318 : List Nat := linear_g318 ++ linear_t319
def linear_t317 : List Nat := linear_g317 ++ linear_t318
def linear_t316 : List Nat := linear_g316 ++ linear_t317
def linear_t315 : List Nat := linear_g315 ++ linear_t316
def linear_t314 : List Nat := linear_g314 ++ linear_t315
def linear_t313 : List Nat := linear_g313 ++ linear_t314
def linear_t312 : List Nat := linear_g312 ++ linear_t313
def linear_t311 : List Nat := linear_g311 ++ linear_t312
def linear_t310 : List Nat := linear_g310 ++ linear_t311
def linear_t309 : List Nat := linear_g309 ++ linear_t310
def linear_t308 : List Nat := linear_g308 ++ linear_t309
def linear_t307 : List Nat := linear_g307 ++ linear_t308
def linear_t306 : List Nat := linear_g306 ++ linear_t307
def linear_t305 : List Nat := linear_g305 ++ linear_t306
def linear_t304 : List Nat := linear_g304 ++ linear_t305
def linear_t303 : List Nat := linear_g303 ++ linear_t304
def linear_t302 : List Nat := linear_g302 ++ linear_t303
def linear_t301 : List Nat := linear_g301 ++ linear_t302
def linear_t300 : List Nat := linear_g300 ++ linear_t301
def linear_t299 : List Nat := linear_g299 ++ linear_t300
def linear_t298 : List Nat := linear_g298 ++ linear_t299
def linear_t297 : List Nat := linear_g297 ++ linear_t298
def linear_t296 : List Nat := linear_g296 ++ linear_t297
def linear_t295 : List Nat := linear_g295 ++ linear_t296
def linear_t294 : List Nat := linear_g294 ++ linear_t295
def linear_t293 : List Nat := linear_g293 ++ linear_t294
def linear_t292 : List Nat := linear_g292 ++ linear_t293
def linear_t291 : List Nat := linear_g291 ++ linear_t292
def linear_t290 : List Nat := linear_g290 ++ linear_t291
def linear_t289 : List Nat := linear_g289 ++ linear_t290
def linear_t288 : List Nat := linear_g288 ++ linear_t289
def linear_t287 : List Nat := linear_g287 ++ linear_t288
def linear_t286 : List Nat := linear_g286 ++ linear_t287
def linear_t285 : List Nat := linear_g285 ++ linear_t286
def linear_t284 : List Nat := linear_g284 ++ linear_t285
def linear_t283 : List Nat := linear_g283 ++ linear_t284
def linear_t282 : List Nat := linear_g282 ++ linear_t283
def linear_t281 : List Nat := linear_g281 ++ linear_t282
def linear_t280 : List Nat := linear_g280 ++ linear_t281
def linear_t279 : List Nat := linear_g279 ++ linear_t280
def linear_t278 : List Nat := linear_g278 ++ linear_t279
def linear_t277 : List Nat := linear_g277 ++ linear_t278
def linear_t276 : List Nat := linear_g276 ++ linear_t277
def linear_t275 : List Nat := linear_g275 ++ linear_t276
def linear_t274 : List Nat := linear_g274 ++ linear_t275
def linear_t273 : List Nat := linear_g273 ++ linear_t274
def linear_t272 : List Nat := linear_g272 ++ linear_t273
def linear_t271 : List Nat := linear_g271 ++ linear_t272
def linear_t270 : List Nat := linear_g270 ++ linear_t271
def linear_t269 : List Nat := linear_g269 ++ linear_t270
def linear_t268 : List Nat := linear_g268 ++ linear_t269
def linear_t267 : List Nat := linear_g267 ++ linear_t268
def linear_t266 : List Nat := linear_g266 ++ linear_t267
def linear_t265 : List Nat := linear_g265 ++ linear_t266
def linear_t264 : List Nat := linear_g264 ++ linear_t265
def linear_t263 : List Nat := linear_g263 ++ linear_t264
def linear_t262 : List Nat := linear_g262 ++ linear_t263
def linear_t261 : List Nat := linear_g261 ++ linear_t262
def linear_t260 : List Nat := linear_g260 ++ linear_t261
def linear_t259 : List Nat := linear_g259 ++ linear_t260
def linear_t258 : List Nat := linear_g258 ++ linear_t259
def linear_t257 : List Nat := linear_g257 ++ linear_t258
def linear_t256 : List Nat := linear_g256 ++ linear_t257
def linear_t255 : List Nat := linear_g255 ++ linear_t256
def linear_t254 : List Nat := linear_g254 ++ linear_t255
def linear_t253 : List Nat := linear_g253 ++ linear_t254
def linear_t252 : List Nat := linear_g252 ++ linear_t253
def linear_t251 : List Nat := linear_g251 ++ linear_t252
def linear_t250 : List Nat := linear_g250 ++ linear_t251
def linear_t249 : List Nat := linear_g249 ++ linear_t250
def linear_t248 : List Nat := linear_g248 ++ linear_t249
def linear_t247 : List Nat := linear_g247 ++ linear_t248
def linear_t246 : List Nat := linear_g246 ++ linear_t247
def linear_t245 : List Nat := linear_g245 ++ linear_t246
def linear_t244 : List Nat := linear_g244 ++ linear_t245
def linear_t243 : List Nat := linear_g243 ++ linear_t244
def linear_t242 : List Nat := linear_g242 ++ linear_t243
def linear_t241 : List Nat := linear_g241 ++ linear_t242
def linear_t240 : List Nat := linear_g240 ++ linear_t241
def linear_t239 : List Nat := linear_g239 ++ linear_t240
def linear_t238 : List Nat := linear_g238 ++ linear_t239
def linear_t237 : List Nat := linear_g237 ++ linear_t238
def linear_t236 : List Nat := linear_g236 ++ linear_t237
def linear_t235 : List Nat := linear_g235 ++ linear_t236
def linear_t234 : List Nat := linear_g234 ++ linear_t235
def linear_t233 : List Nat := linear_g233 ++ linear_t234
def linear_t232 : List Nat := linear_g232 ++ linear_t233
def linear_t231 : List Nat := linear_g231 ++ linear_t232
def linear_t230 : List Nat := linear_g230 ++ linear_t231
def linear_t229 : List Nat := linear_g229 ++ linear_t230
def linear_t228 : List Nat := linear_g228 ++ linear_t229
def linear_t227 : List Nat := linear_g227 ++ linear_t228
def linear_t226 : List Nat := linear_g226 ++ linear_t227
def linear_t225 : List Nat := linear_g225 ++ linear_t226
def linear_t224 : List Nat := linear_g224 ++ linear_t225
def linear_t223 : List Nat := linear_g223 ++ linear_t224
def linear_t222 : List Nat := linear_g222 ++ linear_t223
def linear_t221 : List Nat := linear_g221 ++ linear_t222
def linear_t220 : List Nat := linear_g220 ++ linear_t221
def linear_t219 : List Nat := linear_g219 ++ linear_t220
def linear_t218 : List Nat := linear_g218 ++ linear_t219
def linear_t217 : List Nat := linear_g217 ++ linear_t218
def linear_t216 : List Nat := linear_g216 ++ linear_t217
def linear_t215 : List Nat := linear_g215 ++ linear_t216
def linear_t214 : List Nat := linear_g214 ++ linear_t215
def linear_t213 : List Nat := linear_g213 ++ linear_t214
def linear_t212 : List Nat := linear_g212 ++ linear_t213
def linear_t211 : List Nat := linear_g211 ++ linear_t212
def linear_t210 : List Nat := linear_g210 ++ linear_t211
def linear_t209 : List Nat := linear_g209 ++ linear_t210
def linear_t208 : List Nat := linear_g208 ++ linear_t209
def linear_t207 : List Nat := linear_g207 ++ linear_t208
def linear_t206 : List Nat := linear_g206 ++ linear_t207
def linear_t205 : List Nat := linear_g205 ++ linear_t206
def linear_t204 : List Nat := linear_g204 ++ linear_t205
def linear_t203 : List Nat := linear_g203 ++ linear_t204
def linear_t202 : List Nat := linear_g202 ++ linear_t203
def linear_t201 : List Nat := linear_g201 ++ linear_t202
def linear_t200 : List Nat := linear_g200 ++ linear_t201
def linear_t199 : List Nat := linear_g199 ++ linear_t200
def linear_t198 : List Nat := linear_g198 ++ linear_t199
def linear_t197 : List Nat := linear_g197 ++ linear_t198
def linear_t196 : List Nat := linear_g196 ++ linear_t197
def linear_t195 : List Nat := linear_g195 ++ linear_t196
def linear_t194 : List Nat := linear_g194 ++ linear_t195
def linear_t193 : List Nat := linear_g193 ++ linear_t194
def linear_t192 : List Nat := linear_g192 ++ linear_t193
def linear_t191 : List Nat := linear_g191 ++ linear_t192
def linear_t190 : List Nat := linear_g190 ++ linear_t191
def linear_t189 : List Nat := linear_g189 ++ linear_t190
def linear_t188 : List Nat := linear_g188 ++ linear_t189
def linear_t187 : List Nat := linear_g187 ++ linear_t188
def linear_t186 : List Nat := linear_g186 ++ linear_t187
def linear_t185 : List Nat := linear_g185 ++ linear_t186
def linear_t184 : List Nat := linear_g184 ++ linear_t185
def linear_t183 : List Nat := linear_g183 ++ linear_t184
def linear_t182 : List Nat := linear_g182 ++ linear_t183
def linear_t181 : List Nat := linear_g181 ++ linear_t182
def linear_t180 : List Nat := linear_g180 ++ linear_t181
def linear_t179 : List Nat := linear_g179 ++ linear_t180
def linear_t178 : List Nat := linear_g178 ++ linear_t179
def linear_t177 : List Nat := linear_g177 ++ linear_t178
def linear_t176 : List Nat := linear_g176 ++ linear_t177
def linear_t175 : List Nat := linear_g175 ++ linear_t176
def linear_t174 : List Nat := linear_g174 ++ linear_t175
def linear_t173 : List Nat := linear_g173 ++ linear_t174
def linear_t172 : List Nat := linear_g172 ++ linear_t173
def linear_t171 : List Nat := linear_g171 ++ linear_t172
def linear_t170 : List Nat := linear_g170 ++ linear_t171
def linear_t169 : List Nat := linear_g169 ++ linear_t170
def linear_t168 : List Nat := linear_g168 ++ linear_t169
def linear_t167 : List Nat := linear_g167 ++ linear_t168
def linear_t166 : List Nat := linear_g166 ++ linear_t167
def linear_t165 : List Nat := linear_g165 ++ linear_t166
def linear_t164 : List Nat := linear_g164 ++ linear_t165
def linear_t163 : List Nat := linear_g163 ++ linear_t164
def linear_t162 : List Nat := linear_g162 ++ linear_t163
def linear_t161 : List Nat := linear_g161 ++ linear_t162
def linear_t160 : List Nat := linear_g160 ++ linear_t161
def linear_t159 : List Nat := linear_g159 ++ linear_t160
def linear_t158 : List Nat := linear_g158 ++ linear_t159
def linear_t157 : List Nat := linear_g157 ++ linear_t158
def linear_t156 : List Nat := linear_g156 ++ linear_t157
def linear_t155 : List Nat := linear_g155 ++ linear_t156
def linear_t154 : List Nat := linear_g154 ++ linear_t155
def linear_t153 : List Nat := linear_g153 ++ linear_t154
def linear_t152 : List Nat := linear_g152 ++ linear_t153
def linear_t151 : List Nat := linear_g151 ++ linear_t152
def linear_t150 : List Nat := linear_g150 ++ linear_t151
def linear_t149 : List Nat := linear_g149 ++ linear_t150
def linear_t148 : List Nat := linear_g148 ++ linear_t149
def linear_t147 : List Nat := linear_g147 ++ linear_t148
def linear_t146 : List Nat := linear_g146 ++ linear_t147
def linear_t145 : List Nat := linear_g145 ++ linear_t146
def linear_t144 : List Nat := linear_g144 ++ linear_t145
def linear_t143 : List Nat := linear_g143 ++ linear_t144
def linear_t142 : List Nat := linear_g142 ++ linear_t143
def linear_t141 : List Nat := linear_g141 ++ linear_t142
def linear_t140 : List Nat := linear_g140 ++ linear_t141
def linear_t139 : List Nat := linear_g139 ++ linear_t140
def linear_t138 : List Nat := linear_g138 ++ linear_t139
def linear_t137 : List Nat := linear_g137 ++ linear_t138
def linear_t136 : List Nat := linear_g136 ++ linear_t137
def linear_t135 : List Nat := linear_g135 ++ linear_t136
def linear_t134 : List Nat := linear_g134 ++ linear_t135
def linear_t133 : List Nat := linear_g133 ++ linear_t134
def linear_t132 : List Nat := linear_g132 ++ linear_t133
def linear_t131 : List Nat := linear_g131 ++ linear_t132
def linear_t130 : List Nat := linear_g130 ++ linear_t131
def linear_t129 : List Nat := linear_g129 ++ linear_t130
def linear_t128 : List Nat := linear_g128 ++ linear_t129
def linear_t127 : List Nat := linear_g127 ++ linear_t128
def linear_t126 : List Nat := linear_g126 ++ linear_t127
def linear_t125 : List Nat := linear_g125 ++ linear_t126
def linear_t124 : List Nat := linear_g124 ++ linear_t125
def linear_t123 : List Nat := linear_g123 ++ linear_t124
def linear_t122 : List Nat := linear_g122 ++ linear_t123
def linear_t121 : List Nat := linear_g121 ++ linear_t122
def linear_t120 : List Nat := linear_g120 ++ linear_t121
def linear_t119 : List Nat := linear_g119 ++ linear_t120
def linear_t118 : List Nat := linear_g118 ++ linear_t119
def linear_t117 : List Nat := linear_g117 ++ linear_t118
def linear_t116 : List Nat := linear_g116 ++ linear_t117
def linear_t115 : List Nat := linear_g115 ++ linear_t116
def linear_t114 : List Nat := linear_g114 ++ linear_t115
def linear_t113 : List Nat := linear_g113 ++ linear_t114
def linear_t112 : List Nat := linear_g112 ++ linear_t113
def linear_t111 : List Nat := linear_g111 ++ linear_t112
def linear_t110 : List Nat := linear_g110 ++ linear_t111
def linear_t109 : List Nat := linear_g109 ++ linear_t110
def linear_t108 : List Nat := linear_g108 ++ linear_t109
def linear_t107 : List Nat := linear_g107 ++ linear_t108
def linear_t106 : List Nat := linear_g106 ++ linear_t107
def linear_t105 : List Nat := linear_g105 ++ linear_t106
def linear_t104 : List Nat := linear_g104 ++ linear_t105
def linear_t103 : List Nat := linear_g103 ++ linear_t104
def linear_t102 : List Nat := linear_g102 ++ linear_t103
def linear_t101 : List Nat := linear_g101 ++ linear_t102
def linear_t100 : List Nat := linear_g100 ++ linear_t101
def linear_t99 : List Nat := linear_g99 ++ linear_t100
def linear_t98 : List Nat := linear_g98 ++ linear_t99
def linear_t97 : List Nat := linear_g97 ++ linear_t98
def linear_t96 : List Nat := linear_g96 ++ linear_t97
def linear_t95 : List Nat := linear_g95 ++ linear_t96
def linear_t94 : List Nat := linear_g94 ++ linear_t95
def linear_t93 : List Nat := linear_g93 ++ linear_t94
def linear_t92 : List Nat := linear_g92 ++ linear_t93
def linear_t91 : List Nat := linear_g91 ++ linear_t92
def linear_t90 : List Nat := linear_g90 ++ linear_t91
def linear_t89 : List Nat := linear_g89 ++ linear_t90
def linear_t88 : List Nat := linear_g88 ++ linear_t89
def linear_t87 : List Nat := linear_g87 ++ linear_t88
def linear_t86 : List Nat := linear_g86 ++ linear_t87
def linear_t85 : List Nat := linear_g85 ++ linear_t86
def linear_t84 : List Nat := linear_g84 ++ linear_t85
def linear_t83 : List Nat := linear_g83 ++ linear_t84
def linear_t82 : List Nat := linear_g82 ++ linear_t83
def linear_t81 : List Nat := linear_g81 ++ linear_t82
def linear_t80 : List Nat := linear_g80 ++ linear_t81
def linear_t79 : List Nat := linear_g79 ++ linear_t80
def linear_t78 : List Nat := linear_g78 ++ linear_t79
def linear_t77 : List Nat := linear_g77 ++ linear_t78
def linear_t76 : List Nat := linear_g76 ++ linear_t77
def linear_t75 : List Nat := linear_g75 ++ linear_t76
def linear_t74 : List Nat := linear_g74 ++ linear_t75
def linear_t73 : List Nat := linear_g73 ++ linear_t74
def linear_t72 : List Nat := linear_g72 ++ linear_t73
def linear_t71 : List Nat := linear_g71 ++ linear_t72
def linear_t70 : List Nat := linear_g70 ++ linear_t71
def linear_t69 : List Nat := linear_g69 ++ linear_t70
def linear_t68 : List Nat := linear_g68 ++ linear_t69
def linear_t67 : List Nat := linear_g67 ++ linear_t68
def linear_t66 : List Nat := linear_g66 ++ linear_t67
def linear_t65 : List Nat := linear_g65 ++ linear_t66
def linear_t64 : List Nat := linear_g64 ++ linear_t65
def linear_t63 : List Nat := linear_g63 ++ linear_t64
def linear_t62 : List Nat := linear_g62 ++ linear_t63
def linear_t61 : List Nat := linear_g61 ++ linear_t62
def linear_t60 : List Nat := linear_g60 ++ linear_t61
def linear_t59 : List Nat := linear_g59 ++ linear_t60
def linear_t58 : List Nat := linear_g58 ++ linear_t59
def linear_t57 : List Nat := linear_g57 ++ linear_t58
def linear_t56 : List Nat := linear_g56 ++ linear_t57
def linear_t55 : List Nat := linear_g55 ++ linear_t56
def linear_t54 : List Nat := linear_g54 ++ linear_t55
def linear_t53 : List Nat := linear_g53 ++ linear_t54
def linear_t52 : List Nat := linear_g52 ++ linear_t53
def linear_t51 : List Nat := linear_g51 ++ linear_t52
def linear_t50 : List Nat := linear_g50 ++ linear_t51
def linear_t49 : List Nat := linear_g49 ++ linear_t50
def linear_t48 : List Nat := linear_g48 ++ linear_t49
def linear_t47 : List Nat := linear_g47 ++ linear_t48
def linear_t46 : List Nat := linear_g46 ++ linear_t47
def linear_t45 : List Nat := linear_g45 ++ linear_t46
def linear_t44 : List Nat := linear_g44 ++ linear_t45
def linear_t43 : List Nat := linear_g43 ++ linear_t44
def linear_t42 : List Nat := linear_g42 ++ linear_t43
def linear_t41 : List Nat := linear_g41 ++ linear_t42
def linear_t40 : List Nat := linear_g40 ++ linear_t41
def linear_t39 : List Nat := linear_g39 ++ linear_t40
def linear_t38 : List Nat := linear_g38 ++ linear_t39
def linear_t37 : List Nat := linear_g37 ++ linear_t38
def linear_t36 : List Nat := linear_g36 ++ linear_t37
def linear_t35 : List Nat := linear_g35 ++ linear_t36
def linear_t34 : List Nat := linear_g34 ++ linear_t35
def linear_t33 : List Nat := linear_g33 ++ linear_t34
def linear_t32 : List Nat := linear_g32 ++ linear_t33
def linear_t31 : List Nat := linear_g31 ++ linear_t32
def linear_t30 : List Nat := linear_g30 ++ linear_t31
def linear_t29 : List Nat := linear_g29 ++ linear_t30
def linear_t28 : List Nat := linear_g28 ++ linear_t29
def linear_t27 : List Nat := linear_g27 ++ linear_t28
def linear_t26 : List Nat := linear_g26 ++ linear_t27
def linear_t25 : List Nat := linear_g25 ++ linear_t26
def linear_t24 : List Nat := linear_g24 ++ linear_t25
def linear_t23 : List Nat := linear_g23 ++ linear_t24
def linear_t22 : List Nat := linear_g22 ++ linear_t23
def linear_t21 : List Nat := linear_g21 ++ linear_t22
def linear_t20 : List Nat := linear_g20 ++ linear_t21
def linear_t19 : List Nat := linear_g19 ++ linear_t20
def linear_t18 : List Nat := linear_g18 ++ linear_t19
def linear_t17 : List Nat := linear_g17 ++ linear_t18
def linear_t16 : List Nat := linear_g16 ++ linear_t17
def linear_t15 : List Nat := linear_g15 ++ linear_t16
def linear_t14 : List Nat := linear_g14 ++ linear_t15
def linear_t13 : List Nat := linear_g13 ++ linear_t14
def linear_t12 : List Nat := linear_g12 ++ linear_t13
def linear_t11 : List Nat := linear_g11 ++ linear_t12
def linear_t10 : List Nat := linear_g10 ++ linear_t11
def linear_t9 : List Nat := linear_g9 ++ linear_t10
def linear_t8 : List Nat := linear_g8 ++ linear_t9
def linear_t7 : List Nat := linear_g7 ++ linear_t8
def linear_t6 : List Nat := linear_g6 ++ linear_t7
def linear_t5 : List Nat := linear_g5 ++ linear_t6
def linear_t4 : List Nat := linear_g4 ++ linear_t5
def linear_t3 : List Nat := linear_g3 ++ linear_t4
def linear_t2 : List Nat := linear_g2 ++ linear_t3
def linear_t1 : List Nat := linear_g1 ++ linear_t2
def linear_t0 : List Nat := linear_g0 ++ linear_t1
def linear_r1 : Raw := (.arr [(.str [99,97,108,99,117,108,97,116,101])])
def linear_b1 : List Nat := linear_g2
theorem linear_s1 : serializeRaw 4094 31 linear_r1 = some linear_b1 := by decide +kernel
theorem linear_p1 (tail : List Nat) : parseRaw 4094 31 (linear_b1 ++ tail) = some (linear_r1, tail) := by rfl
def linear_r6 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b6 : List Nat := linear_g11
theorem linear_s6 : serializeRaw 4085 27 linear_r6 = some linear_b6 := by decide +kernel
theorem linear_p6 (tail : List Nat) : parseRaw 4085 27 (linear_b6 ++ tail) = some (linear_r6, tail) := by rfl
def linear_r7 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,116,114,121,95,110,101,119])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49])),([116,121,112,101],(.str [98,111,111,108]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50])),([116,121,112,101],(.str [117,56]))])]))])])
def linear_b7 : List Nat := linear_g14
theorem linear_s7 : serializeRaw 4084 27 linear_r7 = some linear_b7 := by decide +kernel
theorem linear_p7 (tail : List Nat) : parseRaw 4084 27 (linear_b7 ++ tail) = some (linear_r7, tail) := by rfl
def linear_r8 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b8 : List Nat := linear_g17
theorem linear_s8 : serializeRaw 4083 27 linear_r8 = some linear_b8 := by decide +kernel
theorem linear_p8 (tail : List Nat) : parseRaw 4083 27 (linear_b8 ++ tail) = some (linear_r8, tail) := by rfl
def linear_r9 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,49]))]))])
def linear_b9 : List Nat := linear_g20
theorem linear_s9 : serializeRaw 4082 27 linear_r9 = some linear_b9 := by decide +kernel
theorem linear_p9 (tail : List Nat) : parseRaw 4082 27 (linear_b9 ++ tail) = some (linear_r9, tail) := by rfl
def linear_k5_0 : List Nat := [105,100]
theorem linear_kd5_0 : stringBytes linear_k5_0 = true := by decide +kernel
theorem linear_kp5_0 (tail : List Nat) : parseStringTail (linear_k5_0 ++ (34 :: 58 :: tail)) [] = some (linear_k5_0, 58 :: tail) := by rfl
def linear_k5_1 : List Nat := [111,112,115]
theorem linear_kd5_1 : stringBytes linear_k5_1 = true := by decide +kernel
theorem linear_kp5_1 (tail : List Nat) : parseStringTail (linear_k5_1 ++ (34 :: 58 :: tail)) [] = some (linear_k5_1, 58 :: tail) := by rfl
def linear_k5_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd5_2 : stringBytes linear_k5_2 = true := by decide +kernel
theorem linear_kp5_2 (tail : List Nat) : parseStringTail (linear_k5_2 ++ (34 :: 58 :: tail)) [] = some (linear_k5_2, 58 :: tail) := by rfl
def linear_k5_3 : List Nat := [116,101,114,109]
theorem linear_kd5_3 : stringBytes linear_k5_3 = true := by decide +kernel
theorem linear_kp5_3 (tail : List Nat) : parseStringTail (linear_k5_3 ++ (34 :: 58 :: tail)) [] = some (linear_k5_3, 58 :: tail) := by rfl
def linear_l5_3 : List (List Nat × Raw) := [(linear_k5_3, linear_r9)]
def linear_v5_3 : List Nat := linear_g19 ++ linear_b9
theorem linear_sl5_3 : serializeFields 4083 27 linear_l5_3 = some linear_v5_3 := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4082 27 linear_k5_3 linear_r9 linear_b9 linear_kd5_3 linear_s9)
theorem linear_pl5_3 (tail : List Nat) : parseFields 4083 27 (linear_v5_3 ++ (125 :: tail)) = some (linear_l5_3, tail) := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4082 27 (linear_k5_3 ++ (34 :: 58 :: (linear_b9 ++ (125 :: tail)))) linear_k5_3 (linear_b9 ++ (125 :: tail)) tail linear_r9 (linear_kp5_3 (linear_b9 ++ (125 :: tail))) (linear_p9 (125 :: tail)))
def linear_l5_2 : List (List Nat × Raw) := (linear_k5_2, linear_r8) :: linear_l5_3
def linear_v5_2 : List Nat := (linear_g16 ++ linear_b8) ++ (44 :: linear_v5_3)
theorem linear_sl5_2 : serializeFields 4084 27 linear_l5_2 = some linear_v5_2 := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k5_2 linear_r8 (linear_k5_3, linear_r9) [] linear_b8 linear_v5_3 linear_kd5_2 linear_s8 linear_sl5_3)
theorem linear_pl5_2 (tail : List Nat) : parseFields 4084 27 (linear_v5_2 ++ (125 :: tail)) = some (linear_l5_2, tail) := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k5_2 ++ (34 :: 58 :: (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))))) linear_k5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))) (linear_v5_3 ++ (125 :: tail)) tail linear_r8 linear_l5_3 (linear_kp5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail))))) (linear_p8 (44 :: (linear_v5_3 ++ (125 :: tail)))) (linear_pl5_3 tail))
def linear_l5_1 : List (List Nat × Raw) := (linear_k5_1, linear_r7) :: linear_l5_2
def linear_v5_1 : List Nat := (linear_g13 ++ linear_b7) ++ (44 :: linear_v5_2)
theorem linear_sl5_1 : serializeFields 4085 27 linear_l5_1 = some linear_v5_1 := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k5_1 linear_r7 (linear_k5_2, linear_r8) linear_l5_3 linear_b7 linear_v5_2 linear_kd5_1 linear_s7 linear_sl5_2)
theorem linear_pl5_1 (tail : List Nat) : parseFields 4085 27 (linear_v5_1 ++ (125 :: tail)) = some (linear_l5_1, tail) := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k5_1 ++ (34 :: 58 :: (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))))) linear_k5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))) (linear_v5_2 ++ (125 :: tail)) tail linear_r7 linear_l5_2 (linear_kp5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail))))) (linear_p7 (44 :: (linear_v5_2 ++ (125 :: tail)))) (linear_pl5_2 tail))
def linear_l5_0 : List (List Nat × Raw) := (linear_k5_0, linear_r6) :: linear_l5_1
def linear_v5_0 : List Nat := (linear_g10 ++ linear_b6) ++ (44 :: linear_v5_1)
theorem linear_sl5_0 : serializeFields 4086 27 linear_l5_0 = some linear_v5_0 := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 27 linear_k5_0 linear_r6 (linear_k5_1, linear_r7) linear_l5_2 linear_b6 linear_v5_1 linear_kd5_0 linear_s6 linear_sl5_1)
theorem linear_pl5_0 (tail : List Nat) : parseFields 4086 27 (linear_v5_0 ++ (125 :: tail)) = some (linear_l5_0, tail) := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) linear_k5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))) (linear_v5_1 ++ (125 :: tail)) tail linear_r6 linear_l5_1 (linear_kp5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail))))) (linear_p6 (44 :: (linear_v5_1 ++ (125 :: tail)))) (linear_pl5_1 tail))
def linear_r5 : Raw := (.obj linear_l5_0)
def linear_b5 : List Nat := linear_g9 ++ (linear_v5_0 ++ linear_g21)
theorem linear_o5 : orderedFields linear_l5_0 = true := by decide +kernel
theorem linear_s5 : serializeRaw 4087 28 linear_r5 = some linear_b5 := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4086 27 linear_l5_0 linear_v5_0 linear_o5 linear_sl5_0)
theorem linear_p5 (tail : List Nat) : parseRaw 4087 28 (linear_b5 ++ tail) = some (linear_r5, tail) := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4086 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) tail linear_l5_0 linear_o5 (by simpa only [linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl5_0 tail)))
def linear_r11 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,49])
def linear_b11 : List Nat := linear_g25
theorem linear_s11 : serializeRaw 4084 27 linear_r11 = some linear_b11 := by decide +kernel
theorem linear_p11 (tail : List Nat) : parseRaw 4084 27 (linear_b11 ++ tail) = some (linear_r11, tail) := by rfl
def linear_r12 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b12 : List Nat := linear_g28
theorem linear_s12 : serializeRaw 4083 27 linear_r12 = some linear_b12 := by decide +kernel
theorem linear_p12 (tail : List Nat) : parseRaw 4083 27 (linear_b12 ++ tail) = some (linear_r12, tail) := by rfl
def linear_r13 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b13 : List Nat := linear_g31
theorem linear_s13 : serializeRaw 4082 27 linear_r13 = some linear_b13 := by decide +kernel
theorem linear_p13 (tail : List Nat) : parseRaw 4082 27 (linear_b13 ++ tail) = some (linear_r13, tail) := by rfl
def linear_r14 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,52]),(.str [100,103,95,118,95,56]),(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,57]),(.str [100,103,95,118,95,49,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,51]))])
def linear_b14 : List Nat := linear_g34
theorem linear_s14 : serializeRaw 4081 27 linear_r14 = some linear_b14 := by decide +kernel
theorem linear_p14 (tail : List Nat) : parseRaw 4081 27 (linear_b14 ++ tail) = some (linear_r14, tail) := by rfl
def linear_k10_0 : List Nat := [105,100]
theorem linear_kd10_0 : stringBytes linear_k10_0 = true := by decide +kernel
theorem linear_kp10_0 (tail : List Nat) : parseStringTail (linear_k10_0 ++ (34 :: 58 :: tail)) [] = some (linear_k10_0, 58 :: tail) := by rfl
def linear_k10_1 : List Nat := [111,112,115]
theorem linear_kd10_1 : stringBytes linear_k10_1 = true := by decide +kernel
theorem linear_kp10_1 (tail : List Nat) : parseStringTail (linear_k10_1 ++ (34 :: 58 :: tail)) [] = some (linear_k10_1, 58 :: tail) := by rfl
def linear_k10_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd10_2 : stringBytes linear_k10_2 = true := by decide +kernel
theorem linear_kp10_2 (tail : List Nat) : parseStringTail (linear_k10_2 ++ (34 :: 58 :: tail)) [] = some (linear_k10_2, 58 :: tail) := by rfl
def linear_k10_3 : List Nat := [116,101,114,109]
theorem linear_kd10_3 : stringBytes linear_k10_3 = true := by decide +kernel
theorem linear_kp10_3 (tail : List Nat) : parseStringTail (linear_k10_3 ++ (34 :: 58 :: tail)) [] = some (linear_k10_3, 58 :: tail) := by rfl
def linear_l10_3 : List (List Nat × Raw) := [(linear_k10_3, linear_r14)]
def linear_v10_3 : List Nat := linear_g33 ++ linear_b14
theorem linear_sl10_3 : serializeFields 4082 27 linear_l10_3 = some linear_v10_3 := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4081 27 linear_k10_3 linear_r14 linear_b14 linear_kd10_3 linear_s14)
theorem linear_pl10_3 (tail : List Nat) : parseFields 4082 27 (linear_v10_3 ++ (125 :: tail)) = some (linear_l10_3, tail) := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4081 27 (linear_k10_3 ++ (34 :: 58 :: (linear_b14 ++ (125 :: tail)))) linear_k10_3 (linear_b14 ++ (125 :: tail)) tail linear_r14 (linear_kp10_3 (linear_b14 ++ (125 :: tail))) (linear_p14 (125 :: tail)))
def linear_l10_2 : List (List Nat × Raw) := (linear_k10_2, linear_r13) :: linear_l10_3
def linear_v10_2 : List Nat := (linear_g30 ++ linear_b13) ++ (44 :: linear_v10_3)
theorem linear_sl10_2 : serializeFields 4083 27 linear_l10_2 = some linear_v10_2 := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k10_2 linear_r13 (linear_k10_3, linear_r14) [] linear_b13 linear_v10_3 linear_kd10_2 linear_s13 linear_sl10_3)
theorem linear_pl10_2 (tail : List Nat) : parseFields 4083 27 (linear_v10_2 ++ (125 :: tail)) = some (linear_l10_2, tail) := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k10_2 ++ (34 :: 58 :: (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))))) linear_k10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))) (linear_v10_3 ++ (125 :: tail)) tail linear_r13 linear_l10_3 (linear_kp10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail))))) (linear_p13 (44 :: (linear_v10_3 ++ (125 :: tail)))) (linear_pl10_3 tail))
def linear_l10_1 : List (List Nat × Raw) := (linear_k10_1, linear_r12) :: linear_l10_2
def linear_v10_1 : List Nat := (linear_g27 ++ linear_b12) ++ (44 :: linear_v10_2)
theorem linear_sl10_1 : serializeFields 4084 27 linear_l10_1 = some linear_v10_1 := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k10_1 linear_r12 (linear_k10_2, linear_r13) linear_l10_3 linear_b12 linear_v10_2 linear_kd10_1 linear_s12 linear_sl10_2)
theorem linear_pl10_1 (tail : List Nat) : parseFields 4084 27 (linear_v10_1 ++ (125 :: tail)) = some (linear_l10_1, tail) := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k10_1 ++ (34 :: 58 :: (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))))) linear_k10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))) (linear_v10_2 ++ (125 :: tail)) tail linear_r12 linear_l10_2 (linear_kp10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail))))) (linear_p12 (44 :: (linear_v10_2 ++ (125 :: tail)))) (linear_pl10_2 tail))
def linear_l10_0 : List (List Nat × Raw) := (linear_k10_0, linear_r11) :: linear_l10_1
def linear_v10_0 : List Nat := (linear_g24 ++ linear_b11) ++ (44 :: linear_v10_1)
theorem linear_sl10_0 : serializeFields 4085 27 linear_l10_0 = some linear_v10_0 := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k10_0 linear_r11 (linear_k10_1, linear_r12) linear_l10_2 linear_b11 linear_v10_1 linear_kd10_0 linear_s11 linear_sl10_1)
theorem linear_pl10_0 (tail : List Nat) : parseFields 4085 27 (linear_v10_0 ++ (125 :: tail)) = some (linear_l10_0, tail) := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) linear_k10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))) (linear_v10_1 ++ (125 :: tail)) tail linear_r11 linear_l10_1 (linear_kp10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail))))) (linear_p11 (44 :: (linear_v10_1 ++ (125 :: tail)))) (linear_pl10_1 tail))
def linear_r10 : Raw := (.obj linear_l10_0)
def linear_b10 : List Nat := linear_g23 ++ (linear_v10_0 ++ linear_g35)
theorem linear_o10 : orderedFields linear_l10_0 = true := by decide +kernel
theorem linear_s10 : serializeRaw 4086 28 linear_r10 = some linear_b10 := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4085 27 linear_l10_0 linear_v10_0 linear_o10 linear_sl10_0)
theorem linear_p10 (tail : List Nat) : parseRaw 4086 28 (linear_b10 ++ tail) = some (linear_r10, tail) := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4085 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) tail linear_l10_0 linear_o10 (by simpa only [linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl10_0 tail)))
def linear_r16 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,50])
def linear_b16 : List Nat := linear_g39
theorem linear_s16 : serializeRaw 4083 27 linear_r16 = some linear_b16 := by decide +kernel
theorem linear_p16 (tail : List Nat) : parseRaw 4083 27 (linear_b16 ++ tail) = some (linear_r16, tail) := by rfl
def linear_r18 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])
def linear_b18 : List Nat := linear_g43
theorem linear_s18 : serializeRaw 4080 26 linear_r18 = some linear_b18 := by decide +kernel
theorem linear_p18 (tail : List Nat) : parseRaw 4080 26 (linear_b18 ++ tail) = some (linear_r18, tail) := by rfl
def linear_r19 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1000))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b19 : List Nat := linear_g45
theorem linear_s19 : serializeRaw 4079 26 linear_r19 = some linear_b19 := by decide +kernel
theorem linear_p19 (tail : List Nat) : parseRaw 4079 26 (linear_b19 ++ tail) = some (linear_r19, tail) := by rfl
def linear_r20 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b20 : List Nat := linear_g47
theorem linear_s20 : serializeRaw 4078 26 linear_r20 = some linear_b20 := by decide +kernel
theorem linear_p20 (tail : List Nat) : parseRaw 4078 26 (linear_b20 ++ tail) = some (linear_r20, tail) := by rfl
def linear_r21 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54]),(.str [100,103,95,118,95,49,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,56])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b21 : List Nat := linear_g49
theorem linear_s21 : serializeRaw 4077 26 linear_r21 = some linear_b21 := by decide +kernel
theorem linear_p21 (tail : List Nat) : parseRaw 4077 26 (linear_b21 ++ tail) = some (linear_r21, tail) := by rfl
def linear_l17_3 : List Raw := [linear_r21]
def linear_v17_3 : List Nat := linear_b21
theorem linear_sl17_3 : serializeItems 4078 26 linear_l17_3 = some linear_v17_3 := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4077 26 linear_r21 linear_b21 linear_s21)
theorem linear_pl17_3 (tail : List Nat) : parseItems 4078 26 (linear_v17_3 ++ (93 :: tail)) = some (linear_l17_3, tail) := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4077 26 (linear_b21 ++ (93 :: tail)) tail linear_r21 (linear_p21 (93 :: tail)))
def linear_l17_2 : List Raw := linear_r20 :: linear_l17_3
def linear_v17_2 : List Nat := (linear_b20) ++ (44 :: linear_v17_3)
theorem linear_sl17_2 : serializeItems 4079 26 linear_l17_2 = some linear_v17_2 := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 26 linear_r20 linear_r21 [] linear_b20 linear_v17_3 linear_s20 linear_sl17_3)
theorem linear_pl17_2 (tail : List Nat) : parseItems 4079 26 (linear_v17_2 ++ (93 :: tail)) = some (linear_l17_2, tail) := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 26 (linear_b20 ++ (44 :: (linear_v17_3 ++ (93 :: tail)))) (linear_v17_3 ++ (93 :: tail)) tail linear_r20 linear_l17_3 (linear_p20 (44 :: (linear_v17_3 ++ (93 :: tail)))) (linear_pl17_3 tail))
def linear_l17_1 : List Raw := linear_r19 :: linear_l17_2
def linear_v17_1 : List Nat := (linear_b19) ++ (44 :: linear_v17_2)
theorem linear_sl17_1 : serializeItems 4080 26 linear_l17_1 = some linear_v17_1 := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 26 linear_r19 linear_r20 linear_l17_3 linear_b19 linear_v17_2 linear_s19 linear_sl17_2)
theorem linear_pl17_1 (tail : List Nat) : parseItems 4080 26 (linear_v17_1 ++ (93 :: tail)) = some (linear_l17_1, tail) := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 26 (linear_b19 ++ (44 :: (linear_v17_2 ++ (93 :: tail)))) (linear_v17_2 ++ (93 :: tail)) tail linear_r19 linear_l17_2 (linear_p19 (44 :: (linear_v17_2 ++ (93 :: tail)))) (linear_pl17_2 tail))
def linear_l17_0 : List Raw := linear_r18 :: linear_l17_1
def linear_v17_0 : List Nat := (linear_b18) ++ (44 :: linear_v17_1)
theorem linear_sl17_0 : serializeItems 4081 26 linear_l17_0 = some linear_v17_0 := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 26 linear_r18 linear_r19 linear_l17_2 linear_b18 linear_v17_1 linear_s18 linear_sl17_1)
theorem linear_pl17_0 (tail : List Nat) : parseItems 4081 26 (linear_v17_0 ++ (93 :: tail)) = some (linear_l17_0, tail) := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 26 (linear_b18 ++ (44 :: (linear_v17_1 ++ (93 :: tail)))) (linear_v17_1 ++ (93 :: tail)) tail linear_r18 linear_l17_1 (linear_p18 (44 :: (linear_v17_1 ++ (93 :: tail)))) (linear_pl17_1 tail))
def linear_r17 : Raw := (.arr linear_l17_0)
def linear_b17 : List Nat := linear_g42 ++ (linear_v17_0 ++ linear_g50)
theorem linear_s17 : serializeRaw 4082 27 linear_r17 = some linear_b17 := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4081 26 linear_l17_0 linear_v17_0 linear_sl17_0)
theorem linear_p17 (tail : List Nat) : parseRaw 4082 27 (linear_b17 ++ tail) = some (linear_r17, tail) := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4081 26 (linear_v17_0 ++ (93 :: tail)) tail linear_l17_0 (by intro h; cases h) (linear_pl17_0 tail))
def linear_r22 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,57])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b22 : List Nat := linear_g53
theorem linear_s22 : serializeRaw 4081 27 linear_r22 = some linear_b22 := by decide +kernel
theorem linear_p22 (tail : List Nat) : parseRaw 4081 27 (linear_b22 ++ tail) = some (linear_r22, tail) := by rfl
def linear_r23 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,56])]))])
def linear_b23 : List Nat := linear_g56
theorem linear_s23 : serializeRaw 4080 27 linear_r23 = some linear_b23 := by decide +kernel
theorem linear_p23 (tail : List Nat) : parseRaw 4080 27 (linear_b23 ++ tail) = some (linear_r23, tail) := by rfl
def linear_k15_0 : List Nat := [105,100]
theorem linear_kd15_0 : stringBytes linear_k15_0 = true := by decide +kernel
theorem linear_kp15_0 (tail : List Nat) : parseStringTail (linear_k15_0 ++ (34 :: 58 :: tail)) [] = some (linear_k15_0, 58 :: tail) := by rfl
def linear_k15_1 : List Nat := [111,112,115]
theorem linear_kd15_1 : stringBytes linear_k15_1 = true := by decide +kernel
theorem linear_kp15_1 (tail : List Nat) : parseStringTail (linear_k15_1 ++ (34 :: 58 :: tail)) [] = some (linear_k15_1, 58 :: tail) := by rfl
def linear_k15_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd15_2 : stringBytes linear_k15_2 = true := by decide +kernel
theorem linear_kp15_2 (tail : List Nat) : parseStringTail (linear_k15_2 ++ (34 :: 58 :: tail)) [] = some (linear_k15_2, 58 :: tail) := by rfl
def linear_k15_3 : List Nat := [116,101,114,109]
theorem linear_kd15_3 : stringBytes linear_k15_3 = true := by decide +kernel
theorem linear_kp15_3 (tail : List Nat) : parseStringTail (linear_k15_3 ++ (34 :: 58 :: tail)) [] = some (linear_k15_3, 58 :: tail) := by rfl
def linear_l15_3 : List (List Nat × Raw) := [(linear_k15_3, linear_r23)]
def linear_v15_3 : List Nat := linear_g55 ++ linear_b23
theorem linear_sl15_3 : serializeFields 4081 27 linear_l15_3 = some linear_v15_3 := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4080 27 linear_k15_3 linear_r23 linear_b23 linear_kd15_3 linear_s23)
theorem linear_pl15_3 (tail : List Nat) : parseFields 4081 27 (linear_v15_3 ++ (125 :: tail)) = some (linear_l15_3, tail) := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4080 27 (linear_k15_3 ++ (34 :: 58 :: (linear_b23 ++ (125 :: tail)))) linear_k15_3 (linear_b23 ++ (125 :: tail)) tail linear_r23 (linear_kp15_3 (linear_b23 ++ (125 :: tail))) (linear_p23 (125 :: tail)))
def linear_l15_2 : List (List Nat × Raw) := (linear_k15_2, linear_r22) :: linear_l15_3
def linear_v15_2 : List Nat := (linear_g52 ++ linear_b22) ++ (44 :: linear_v15_3)
theorem linear_sl15_2 : serializeFields 4082 27 linear_l15_2 = some linear_v15_2 := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k15_2 linear_r22 (linear_k15_3, linear_r23) [] linear_b22 linear_v15_3 linear_kd15_2 linear_s22 linear_sl15_3)
theorem linear_pl15_2 (tail : List Nat) : parseFields 4082 27 (linear_v15_2 ++ (125 :: tail)) = some (linear_l15_2, tail) := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k15_2 ++ (34 :: 58 :: (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))))) linear_k15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))) (linear_v15_3 ++ (125 :: tail)) tail linear_r22 linear_l15_3 (linear_kp15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail))))) (linear_p22 (44 :: (linear_v15_3 ++ (125 :: tail)))) (linear_pl15_3 tail))
def linear_l15_1 : List (List Nat × Raw) := (linear_k15_1, linear_r17) :: linear_l15_2
def linear_v15_1 : List Nat := (linear_g41 ++ linear_b17) ++ (44 :: linear_v15_2)
theorem linear_sl15_1 : serializeFields 4083 27 linear_l15_1 = some linear_v15_1 := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k15_1 linear_r17 (linear_k15_2, linear_r22) linear_l15_3 linear_b17 linear_v15_2 linear_kd15_1 linear_s17 linear_sl15_2)
theorem linear_pl15_1 (tail : List Nat) : parseFields 4083 27 (linear_v15_1 ++ (125 :: tail)) = some (linear_l15_1, tail) := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k15_1 ++ (34 :: 58 :: (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))))) linear_k15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))) (linear_v15_2 ++ (125 :: tail)) tail linear_r17 linear_l15_2 (linear_kp15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail))))) (linear_p17 (44 :: (linear_v15_2 ++ (125 :: tail)))) (linear_pl15_2 tail))
def linear_l15_0 : List (List Nat × Raw) := (linear_k15_0, linear_r16) :: linear_l15_1
def linear_v15_0 : List Nat := (linear_g38 ++ linear_b16) ++ (44 :: linear_v15_1)
theorem linear_sl15_0 : serializeFields 4084 27 linear_l15_0 = some linear_v15_0 := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k15_0 linear_r16 (linear_k15_1, linear_r17) linear_l15_2 linear_b16 linear_v15_1 linear_kd15_0 linear_s16 linear_sl15_1)
theorem linear_pl15_0 (tail : List Nat) : parseFields 4084 27 (linear_v15_0 ++ (125 :: tail)) = some (linear_l15_0, tail) := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) linear_k15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))) (linear_v15_1 ++ (125 :: tail)) tail linear_r16 linear_l15_1 (linear_kp15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail))))) (linear_p16 (44 :: (linear_v15_1 ++ (125 :: tail)))) (linear_pl15_1 tail))
def linear_r15 : Raw := (.obj linear_l15_0)
def linear_b15 : List Nat := linear_g37 ++ (linear_v15_0 ++ linear_g57)
theorem linear_o15 : orderedFields linear_l15_0 = true := by decide +kernel
theorem linear_s15 : serializeRaw 4085 28 linear_r15 = some linear_b15 := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4084 27 linear_l15_0 linear_v15_0 linear_o15 linear_sl15_0)
theorem linear_p15 (tail : List Nat) : parseRaw 4085 28 (linear_b15 ++ tail) = some (linear_r15, tail) := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4084 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) tail linear_l15_0 linear_o15 (by simpa only [linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl15_0 tail)))
def linear_r25 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,51])
def linear_b25 : List Nat := linear_g61
theorem linear_s25 : serializeRaw 4082 27 linear_r25 = some linear_b25 := by decide +kernel
theorem linear_p25 (tail : List Nat) : parseRaw 4082 27 (linear_b25 ++ tail) = some (linear_r25, tail) := by rfl
def linear_r26 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,53])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b26 : List Nat := linear_g64
theorem linear_s26 : serializeRaw 4081 27 linear_r26 = some linear_b26 := by decide +kernel
theorem linear_p26 (tail : List Nat) : parseRaw 4081 27 (linear_b26 ++ tail) = some (linear_r26, tail) := by rfl
def linear_r27 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b27 : List Nat := linear_g67
theorem linear_s27 : serializeRaw 4080 27 linear_r27 = some linear_b27 := by decide +kernel
theorem linear_p27 (tail : List Nat) : parseRaw 4080 27 (linear_b27 ++ tail) = some (linear_r27, tail) := by rfl
def linear_r28 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,50,53])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,48]))]))])
def linear_b28 : List Nat := linear_g70
theorem linear_s28 : serializeRaw 4079 27 linear_r28 = some linear_b28 := by decide +kernel
theorem linear_p28 (tail : List Nat) : parseRaw 4079 27 (linear_b28 ++ tail) = some (linear_r28, tail) := by rfl
def linear_k24_0 : List Nat := [105,100]
theorem linear_kd24_0 : stringBytes linear_k24_0 = true := by decide +kernel
theorem linear_kp24_0 (tail : List Nat) : parseStringTail (linear_k24_0 ++ (34 :: 58 :: tail)) [] = some (linear_k24_0, 58 :: tail) := by rfl
def linear_k24_1 : List Nat := [111,112,115]
theorem linear_kd24_1 : stringBytes linear_k24_1 = true := by decide +kernel
theorem linear_kp24_1 (tail : List Nat) : parseStringTail (linear_k24_1 ++ (34 :: 58 :: tail)) [] = some (linear_k24_1, 58 :: tail) := by rfl
def linear_k24_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd24_2 : stringBytes linear_k24_2 = true := by decide +kernel
theorem linear_kp24_2 (tail : List Nat) : parseStringTail (linear_k24_2 ++ (34 :: 58 :: tail)) [] = some (linear_k24_2, 58 :: tail) := by rfl
def linear_k24_3 : List Nat := [116,101,114,109]
theorem linear_kd24_3 : stringBytes linear_k24_3 = true := by decide +kernel
theorem linear_kp24_3 (tail : List Nat) : parseStringTail (linear_k24_3 ++ (34 :: 58 :: tail)) [] = some (linear_k24_3, 58 :: tail) := by rfl
def linear_l24_3 : List (List Nat × Raw) := [(linear_k24_3, linear_r28)]
def linear_v24_3 : List Nat := linear_g69 ++ linear_b28
theorem linear_sl24_3 : serializeFields 4080 27 linear_l24_3 = some linear_v24_3 := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4079 27 linear_k24_3 linear_r28 linear_b28 linear_kd24_3 linear_s28)
theorem linear_pl24_3 (tail : List Nat) : parseFields 4080 27 (linear_v24_3 ++ (125 :: tail)) = some (linear_l24_3, tail) := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4079 27 (linear_k24_3 ++ (34 :: 58 :: (linear_b28 ++ (125 :: tail)))) linear_k24_3 (linear_b28 ++ (125 :: tail)) tail linear_r28 (linear_kp24_3 (linear_b28 ++ (125 :: tail))) (linear_p28 (125 :: tail)))
def linear_l24_2 : List (List Nat × Raw) := (linear_k24_2, linear_r27) :: linear_l24_3
def linear_v24_2 : List Nat := (linear_g66 ++ linear_b27) ++ (44 :: linear_v24_3)
theorem linear_sl24_2 : serializeFields 4081 27 linear_l24_2 = some linear_v24_2 := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k24_2 linear_r27 (linear_k24_3, linear_r28) [] linear_b27 linear_v24_3 linear_kd24_2 linear_s27 linear_sl24_3)
theorem linear_pl24_2 (tail : List Nat) : parseFields 4081 27 (linear_v24_2 ++ (125 :: tail)) = some (linear_l24_2, tail) := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k24_2 ++ (34 :: 58 :: (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))))) linear_k24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))) (linear_v24_3 ++ (125 :: tail)) tail linear_r27 linear_l24_3 (linear_kp24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail))))) (linear_p27 (44 :: (linear_v24_3 ++ (125 :: tail)))) (linear_pl24_3 tail))
def linear_l24_1 : List (List Nat × Raw) := (linear_k24_1, linear_r26) :: linear_l24_2
def linear_v24_1 : List Nat := (linear_g63 ++ linear_b26) ++ (44 :: linear_v24_2)
theorem linear_sl24_1 : serializeFields 4082 27 linear_l24_1 = some linear_v24_1 := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k24_1 linear_r26 (linear_k24_2, linear_r27) linear_l24_3 linear_b26 linear_v24_2 linear_kd24_1 linear_s26 linear_sl24_2)
theorem linear_pl24_1 (tail : List Nat) : parseFields 4082 27 (linear_v24_1 ++ (125 :: tail)) = some (linear_l24_1, tail) := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k24_1 ++ (34 :: 58 :: (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))))) linear_k24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))) (linear_v24_2 ++ (125 :: tail)) tail linear_r26 linear_l24_2 (linear_kp24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail))))) (linear_p26 (44 :: (linear_v24_2 ++ (125 :: tail)))) (linear_pl24_2 tail))
def linear_l24_0 : List (List Nat × Raw) := (linear_k24_0, linear_r25) :: linear_l24_1
def linear_v24_0 : List Nat := (linear_g60 ++ linear_b25) ++ (44 :: linear_v24_1)
theorem linear_sl24_0 : serializeFields 4083 27 linear_l24_0 = some linear_v24_0 := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k24_0 linear_r25 (linear_k24_1, linear_r26) linear_l24_2 linear_b25 linear_v24_1 linear_kd24_0 linear_s25 linear_sl24_1)
theorem linear_pl24_0 (tail : List Nat) : parseFields 4083 27 (linear_v24_0 ++ (125 :: tail)) = some (linear_l24_0, tail) := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) linear_k24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))) (linear_v24_1 ++ (125 :: tail)) tail linear_r25 linear_l24_1 (linear_kp24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail))))) (linear_p25 (44 :: (linear_v24_1 ++ (125 :: tail)))) (linear_pl24_1 tail))
def linear_r24 : Raw := (.obj linear_l24_0)
def linear_b24 : List Nat := linear_g59 ++ (linear_v24_0 ++ linear_g71)
theorem linear_o24 : orderedFields linear_l24_0 = true := by decide +kernel
theorem linear_s24 : serializeRaw 4084 28 linear_r24 = some linear_b24 := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4083 27 linear_l24_0 linear_v24_0 linear_o24 linear_sl24_0)
theorem linear_p24 (tail : List Nat) : parseRaw 4084 28 (linear_b24 ++ tail) = some (linear_r24, tail) := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4083 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) tail linear_l24_0 linear_o24 (by simpa only [linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl24_0 tail)))
def linear_r30 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,52])
def linear_b30 : List Nat := linear_g75
theorem linear_s30 : serializeRaw 4081 27 linear_r30 = some linear_b30 := by decide +kernel
theorem linear_p30 (tail : List Nat) : parseRaw 4081 27 (linear_b30 ++ tail) = some (linear_r30, tail) := by rfl
def linear_r31 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,50])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b31 : List Nat := linear_g78
theorem linear_s31 : serializeRaw 4080 27 linear_r31 = some linear_b31 := by decide +kernel
theorem linear_p31 (tail : List Nat) : parseRaw 4080 27 (linear_b31 ++ tail) = some (linear_r31, tail) := by rfl
def linear_r32 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b32 : List Nat := linear_g81
theorem linear_s32 : serializeRaw 4079 27 linear_r32 = some linear_b32 := by decide +kernel
theorem linear_p32 (tail : List Nat) : parseRaw 4079 27 (linear_b32 ++ tail) = some (linear_r32, tail) := by rfl
def linear_r33 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,50,56]),(.str [100,103,95,118,95,50,57]),(.str [100,103,95,118,95,51,50]),(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,51,51]),(.str [100,103,95,118,95,51,52])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,53]))])
def linear_b33 : List Nat := linear_g84
theorem linear_s33 : serializeRaw 4078 27 linear_r33 = some linear_b33 := by decide +kernel
theorem linear_p33 (tail : List Nat) : parseRaw 4078 27 (linear_b33 ++ tail) = some (linear_r33, tail) := by rfl
def linear_k29_0 : List Nat := [105,100]
theorem linear_kd29_0 : stringBytes linear_k29_0 = true := by decide +kernel
theorem linear_kp29_0 (tail : List Nat) : parseStringTail (linear_k29_0 ++ (34 :: 58 :: tail)) [] = some (linear_k29_0, 58 :: tail) := by rfl
def linear_k29_1 : List Nat := [111,112,115]
theorem linear_kd29_1 : stringBytes linear_k29_1 = true := by decide +kernel
theorem linear_kp29_1 (tail : List Nat) : parseStringTail (linear_k29_1 ++ (34 :: 58 :: tail)) [] = some (linear_k29_1, 58 :: tail) := by rfl
def linear_k29_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd29_2 : stringBytes linear_k29_2 = true := by decide +kernel
theorem linear_kp29_2 (tail : List Nat) : parseStringTail (linear_k29_2 ++ (34 :: 58 :: tail)) [] = some (linear_k29_2, 58 :: tail) := by rfl
def linear_k29_3 : List Nat := [116,101,114,109]
theorem linear_kd29_3 : stringBytes linear_k29_3 = true := by decide +kernel
theorem linear_kp29_3 (tail : List Nat) : parseStringTail (linear_k29_3 ++ (34 :: 58 :: tail)) [] = some (linear_k29_3, 58 :: tail) := by rfl
def linear_l29_3 : List (List Nat × Raw) := [(linear_k29_3, linear_r33)]
def linear_v29_3 : List Nat := linear_g83 ++ linear_b33
theorem linear_sl29_3 : serializeFields 4079 27 linear_l29_3 = some linear_v29_3 := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4078 27 linear_k29_3 linear_r33 linear_b33 linear_kd29_3 linear_s33)
theorem linear_pl29_3 (tail : List Nat) : parseFields 4079 27 (linear_v29_3 ++ (125 :: tail)) = some (linear_l29_3, tail) := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4078 27 (linear_k29_3 ++ (34 :: 58 :: (linear_b33 ++ (125 :: tail)))) linear_k29_3 (linear_b33 ++ (125 :: tail)) tail linear_r33 (linear_kp29_3 (linear_b33 ++ (125 :: tail))) (linear_p33 (125 :: tail)))
def linear_l29_2 : List (List Nat × Raw) := (linear_k29_2, linear_r32) :: linear_l29_3
def linear_v29_2 : List Nat := (linear_g80 ++ linear_b32) ++ (44 :: linear_v29_3)
theorem linear_sl29_2 : serializeFields 4080 27 linear_l29_2 = some linear_v29_2 := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k29_2 linear_r32 (linear_k29_3, linear_r33) [] linear_b32 linear_v29_3 linear_kd29_2 linear_s32 linear_sl29_3)
theorem linear_pl29_2 (tail : List Nat) : parseFields 4080 27 (linear_v29_2 ++ (125 :: tail)) = some (linear_l29_2, tail) := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k29_2 ++ (34 :: 58 :: (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))))) linear_k29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))) (linear_v29_3 ++ (125 :: tail)) tail linear_r32 linear_l29_3 (linear_kp29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail))))) (linear_p32 (44 :: (linear_v29_3 ++ (125 :: tail)))) (linear_pl29_3 tail))
def linear_l29_1 : List (List Nat × Raw) := (linear_k29_1, linear_r31) :: linear_l29_2
def linear_v29_1 : List Nat := (linear_g77 ++ linear_b31) ++ (44 :: linear_v29_2)
theorem linear_sl29_1 : serializeFields 4081 27 linear_l29_1 = some linear_v29_1 := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k29_1 linear_r31 (linear_k29_2, linear_r32) linear_l29_3 linear_b31 linear_v29_2 linear_kd29_1 linear_s31 linear_sl29_2)
theorem linear_pl29_1 (tail : List Nat) : parseFields 4081 27 (linear_v29_1 ++ (125 :: tail)) = some (linear_l29_1, tail) := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k29_1 ++ (34 :: 58 :: (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))))) linear_k29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))) (linear_v29_2 ++ (125 :: tail)) tail linear_r31 linear_l29_2 (linear_kp29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail))))) (linear_p31 (44 :: (linear_v29_2 ++ (125 :: tail)))) (linear_pl29_2 tail))
def linear_l29_0 : List (List Nat × Raw) := (linear_k29_0, linear_r30) :: linear_l29_1
def linear_v29_0 : List Nat := (linear_g74 ++ linear_b30) ++ (44 :: linear_v29_1)
theorem linear_sl29_0 : serializeFields 4082 27 linear_l29_0 = some linear_v29_0 := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k29_0 linear_r30 (linear_k29_1, linear_r31) linear_l29_2 linear_b30 linear_v29_1 linear_kd29_0 linear_s30 linear_sl29_1)
theorem linear_pl29_0 (tail : List Nat) : parseFields 4082 27 (linear_v29_0 ++ (125 :: tail)) = some (linear_l29_0, tail) := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) linear_k29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))) (linear_v29_1 ++ (125 :: tail)) tail linear_r30 linear_l29_1 (linear_kp29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail))))) (linear_p30 (44 :: (linear_v29_1 ++ (125 :: tail)))) (linear_pl29_1 tail))
def linear_r29 : Raw := (.obj linear_l29_0)
def linear_b29 : List Nat := linear_g73 ++ (linear_v29_0 ++ linear_g85)
theorem linear_o29 : orderedFields linear_l29_0 = true := by decide +kernel
theorem linear_s29 : serializeRaw 4083 28 linear_r29 = some linear_b29 := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4082 27 linear_l29_0 linear_v29_0 linear_o29 linear_sl29_0)
theorem linear_p29 (tail : List Nat) : parseRaw 4083 28 (linear_b29 ++ tail) = some (linear_r29, tail) := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4082 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) tail linear_l29_0 linear_o29 (by simpa only [linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl29_0 tail)))
def linear_r35 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,53])
def linear_b35 : List Nat := linear_g89
theorem linear_s35 : serializeRaw 4080 27 linear_r35 = some linear_b35 := by decide +kernel
theorem linear_p35 (tail : List Nat) : parseRaw 4080 27 (linear_b35 ++ tail) = some (linear_r35, tail) := by rfl
def linear_r36 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,51,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,49])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b36 : List Nat := linear_g92
theorem linear_s36 : serializeRaw 4079 27 linear_r36 = some linear_b36 := by decide +kernel
theorem linear_p36 (tail : List Nat) : parseRaw 4079 27 (linear_b36 ++ tail) = some (linear_r36, tail) := by rfl
def linear_r37 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b37 : List Nat := linear_g95
theorem linear_s37 : serializeRaw 4078 27 linear_r37 = some linear_b37 := by decide +kernel
theorem linear_p37 (tail : List Nat) : parseRaw 4078 27 (linear_b37 ++ tail) = some (linear_r37, tail) := by rfl
def linear_r38 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,52,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,54]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,49]))]))])
def linear_b38 : List Nat := linear_g98
theorem linear_s38 : serializeRaw 4077 27 linear_r38 = some linear_b38 := by decide +kernel
theorem linear_p38 (tail : List Nat) : parseRaw 4077 27 (linear_b38 ++ tail) = some (linear_r38, tail) := by rfl
def linear_k34_0 : List Nat := [105,100]
theorem linear_kd34_0 : stringBytes linear_k34_0 = true := by decide +kernel
theorem linear_kp34_0 (tail : List Nat) : parseStringTail (linear_k34_0 ++ (34 :: 58 :: tail)) [] = some (linear_k34_0, 58 :: tail) := by rfl
def linear_k34_1 : List Nat := [111,112,115]
theorem linear_kd34_1 : stringBytes linear_k34_1 = true := by decide +kernel
theorem linear_kp34_1 (tail : List Nat) : parseStringTail (linear_k34_1 ++ (34 :: 58 :: tail)) [] = some (linear_k34_1, 58 :: tail) := by rfl
def linear_k34_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd34_2 : stringBytes linear_k34_2 = true := by decide +kernel
theorem linear_kp34_2 (tail : List Nat) : parseStringTail (linear_k34_2 ++ (34 :: 58 :: tail)) [] = some (linear_k34_2, 58 :: tail) := by rfl
def linear_k34_3 : List Nat := [116,101,114,109]
theorem linear_kd34_3 : stringBytes linear_k34_3 = true := by decide +kernel
theorem linear_kp34_3 (tail : List Nat) : parseStringTail (linear_k34_3 ++ (34 :: 58 :: tail)) [] = some (linear_k34_3, 58 :: tail) := by rfl
def linear_l34_3 : List (List Nat × Raw) := [(linear_k34_3, linear_r38)]
def linear_v34_3 : List Nat := linear_g97 ++ linear_b38
theorem linear_sl34_3 : serializeFields 4078 27 linear_l34_3 = some linear_v34_3 := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4077 27 linear_k34_3 linear_r38 linear_b38 linear_kd34_3 linear_s38)
theorem linear_pl34_3 (tail : List Nat) : parseFields 4078 27 (linear_v34_3 ++ (125 :: tail)) = some (linear_l34_3, tail) := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4077 27 (linear_k34_3 ++ (34 :: 58 :: (linear_b38 ++ (125 :: tail)))) linear_k34_3 (linear_b38 ++ (125 :: tail)) tail linear_r38 (linear_kp34_3 (linear_b38 ++ (125 :: tail))) (linear_p38 (125 :: tail)))
def linear_l34_2 : List (List Nat × Raw) := (linear_k34_2, linear_r37) :: linear_l34_3
def linear_v34_2 : List Nat := (linear_g94 ++ linear_b37) ++ (44 :: linear_v34_3)
theorem linear_sl34_2 : serializeFields 4079 27 linear_l34_2 = some linear_v34_2 := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k34_2 linear_r37 (linear_k34_3, linear_r38) [] linear_b37 linear_v34_3 linear_kd34_2 linear_s37 linear_sl34_3)
theorem linear_pl34_2 (tail : List Nat) : parseFields 4079 27 (linear_v34_2 ++ (125 :: tail)) = some (linear_l34_2, tail) := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k34_2 ++ (34 :: 58 :: (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))))) linear_k34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))) (linear_v34_3 ++ (125 :: tail)) tail linear_r37 linear_l34_3 (linear_kp34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail))))) (linear_p37 (44 :: (linear_v34_3 ++ (125 :: tail)))) (linear_pl34_3 tail))
def linear_l34_1 : List (List Nat × Raw) := (linear_k34_1, linear_r36) :: linear_l34_2
def linear_v34_1 : List Nat := (linear_g91 ++ linear_b36) ++ (44 :: linear_v34_2)
theorem linear_sl34_1 : serializeFields 4080 27 linear_l34_1 = some linear_v34_1 := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k34_1 linear_r36 (linear_k34_2, linear_r37) linear_l34_3 linear_b36 linear_v34_2 linear_kd34_1 linear_s36 linear_sl34_2)
theorem linear_pl34_1 (tail : List Nat) : parseFields 4080 27 (linear_v34_1 ++ (125 :: tail)) = some (linear_l34_1, tail) := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k34_1 ++ (34 :: 58 :: (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))))) linear_k34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))) (linear_v34_2 ++ (125 :: tail)) tail linear_r36 linear_l34_2 (linear_kp34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail))))) (linear_p36 (44 :: (linear_v34_2 ++ (125 :: tail)))) (linear_pl34_2 tail))
def linear_l34_0 : List (List Nat × Raw) := (linear_k34_0, linear_r35) :: linear_l34_1
def linear_v34_0 : List Nat := (linear_g88 ++ linear_b35) ++ (44 :: linear_v34_1)
theorem linear_sl34_0 : serializeFields 4081 27 linear_l34_0 = some linear_v34_0 := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k34_0 linear_r35 (linear_k34_1, linear_r36) linear_l34_2 linear_b35 linear_v34_1 linear_kd34_0 linear_s35 linear_sl34_1)
theorem linear_pl34_0 (tail : List Nat) : parseFields 4081 27 (linear_v34_0 ++ (125 :: tail)) = some (linear_l34_0, tail) := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) linear_k34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))) (linear_v34_1 ++ (125 :: tail)) tail linear_r35 linear_l34_1 (linear_kp34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail))))) (linear_p35 (44 :: (linear_v34_1 ++ (125 :: tail)))) (linear_pl34_1 tail))
def linear_r34 : Raw := (.obj linear_l34_0)
def linear_b34 : List Nat := linear_g87 ++ (linear_v34_0 ++ linear_g99)
theorem linear_o34 : orderedFields linear_l34_0 = true := by decide +kernel
theorem linear_s34 : serializeRaw 4082 28 linear_r34 = some linear_b34 := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4081 27 linear_l34_0 linear_v34_0 linear_o34 linear_sl34_0)
theorem linear_p34 (tail : List Nat) : parseRaw 4082 28 (linear_b34 ++ tail) = some (linear_r34, tail) := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4081 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) tail linear_l34_0 linear_o34 (by simpa only [linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl34_0 tail)))
def linear_r40 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,54])
def linear_b40 : List Nat := linear_g103
theorem linear_s40 : serializeRaw 4079 27 linear_r40 = some linear_b40 := by decide +kernel
theorem linear_p40 (tail : List Nat) : parseRaw 4079 27 (linear_b40 ++ tail) = some (linear_r40, tail) := by rfl
def linear_r41 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b41 : List Nat := linear_g106
theorem linear_s41 : serializeRaw 4078 27 linear_r41 = some linear_b41 := by decide +kernel
theorem linear_p41 (tail : List Nat) : parseRaw 4078 27 (linear_b41 ++ tail) = some (linear_r41, tail) := by rfl
def linear_r42 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,53])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,54])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b42 : List Nat := linear_g109
theorem linear_s42 : serializeRaw 4077 27 linear_r42 = some linear_b42 := by decide +kernel
theorem linear_p42 (tail : List Nat) : parseRaw 4077 27 (linear_b42 ++ tail) = some (linear_r42, tail) := by rfl
def linear_r43 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,52,54])]))])
def linear_b43 : List Nat := linear_g112
theorem linear_s43 : serializeRaw 4076 27 linear_r43 = some linear_b43 := by decide +kernel
theorem linear_p43 (tail : List Nat) : parseRaw 4076 27 (linear_b43 ++ tail) = some (linear_r43, tail) := by rfl
def linear_k39_0 : List Nat := [105,100]
theorem linear_kd39_0 : stringBytes linear_k39_0 = true := by decide +kernel
theorem linear_kp39_0 (tail : List Nat) : parseStringTail (linear_k39_0 ++ (34 :: 58 :: tail)) [] = some (linear_k39_0, 58 :: tail) := by rfl
def linear_k39_1 : List Nat := [111,112,115]
theorem linear_kd39_1 : stringBytes linear_k39_1 = true := by decide +kernel
theorem linear_kp39_1 (tail : List Nat) : parseStringTail (linear_k39_1 ++ (34 :: 58 :: tail)) [] = some (linear_k39_1, 58 :: tail) := by rfl
def linear_k39_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd39_2 : stringBytes linear_k39_2 = true := by decide +kernel
theorem linear_kp39_2 (tail : List Nat) : parseStringTail (linear_k39_2 ++ (34 :: 58 :: tail)) [] = some (linear_k39_2, 58 :: tail) := by rfl
def linear_k39_3 : List Nat := [116,101,114,109]
theorem linear_kd39_3 : stringBytes linear_k39_3 = true := by decide +kernel
theorem linear_kp39_3 (tail : List Nat) : parseStringTail (linear_k39_3 ++ (34 :: 58 :: tail)) [] = some (linear_k39_3, 58 :: tail) := by rfl
def linear_l39_3 : List (List Nat × Raw) := [(linear_k39_3, linear_r43)]
def linear_v39_3 : List Nat := linear_g111 ++ linear_b43
theorem linear_sl39_3 : serializeFields 4077 27 linear_l39_3 = some linear_v39_3 := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4076 27 linear_k39_3 linear_r43 linear_b43 linear_kd39_3 linear_s43)
theorem linear_pl39_3 (tail : List Nat) : parseFields 4077 27 (linear_v39_3 ++ (125 :: tail)) = some (linear_l39_3, tail) := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4076 27 (linear_k39_3 ++ (34 :: 58 :: (linear_b43 ++ (125 :: tail)))) linear_k39_3 (linear_b43 ++ (125 :: tail)) tail linear_r43 (linear_kp39_3 (linear_b43 ++ (125 :: tail))) (linear_p43 (125 :: tail)))
def linear_l39_2 : List (List Nat × Raw) := (linear_k39_2, linear_r42) :: linear_l39_3
def linear_v39_2 : List Nat := (linear_g108 ++ linear_b42) ++ (44 :: linear_v39_3)
theorem linear_sl39_2 : serializeFields 4078 27 linear_l39_2 = some linear_v39_2 := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k39_2 linear_r42 (linear_k39_3, linear_r43) [] linear_b42 linear_v39_3 linear_kd39_2 linear_s42 linear_sl39_3)
theorem linear_pl39_2 (tail : List Nat) : parseFields 4078 27 (linear_v39_2 ++ (125 :: tail)) = some (linear_l39_2, tail) := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k39_2 ++ (34 :: 58 :: (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))))) linear_k39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))) (linear_v39_3 ++ (125 :: tail)) tail linear_r42 linear_l39_3 (linear_kp39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail))))) (linear_p42 (44 :: (linear_v39_3 ++ (125 :: tail)))) (linear_pl39_3 tail))
def linear_l39_1 : List (List Nat × Raw) := (linear_k39_1, linear_r41) :: linear_l39_2
def linear_v39_1 : List Nat := (linear_g105 ++ linear_b41) ++ (44 :: linear_v39_2)
theorem linear_sl39_1 : serializeFields 4079 27 linear_l39_1 = some linear_v39_1 := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k39_1 linear_r41 (linear_k39_2, linear_r42) linear_l39_3 linear_b41 linear_v39_2 linear_kd39_1 linear_s41 linear_sl39_2)
theorem linear_pl39_1 (tail : List Nat) : parseFields 4079 27 (linear_v39_1 ++ (125 :: tail)) = some (linear_l39_1, tail) := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k39_1 ++ (34 :: 58 :: (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))))) linear_k39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))) (linear_v39_2 ++ (125 :: tail)) tail linear_r41 linear_l39_2 (linear_kp39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail))))) (linear_p41 (44 :: (linear_v39_2 ++ (125 :: tail)))) (linear_pl39_2 tail))
def linear_l39_0 : List (List Nat × Raw) := (linear_k39_0, linear_r40) :: linear_l39_1
def linear_v39_0 : List Nat := (linear_g102 ++ linear_b40) ++ (44 :: linear_v39_1)
theorem linear_sl39_0 : serializeFields 4080 27 linear_l39_0 = some linear_v39_0 := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k39_0 linear_r40 (linear_k39_1, linear_r41) linear_l39_2 linear_b40 linear_v39_1 linear_kd39_0 linear_s40 linear_sl39_1)
theorem linear_pl39_0 (tail : List Nat) : parseFields 4080 27 (linear_v39_0 ++ (125 :: tail)) = some (linear_l39_0, tail) := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) linear_k39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))) (linear_v39_1 ++ (125 :: tail)) tail linear_r40 linear_l39_1 (linear_kp39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail))))) (linear_p40 (44 :: (linear_v39_1 ++ (125 :: tail)))) (linear_pl39_1 tail))
def linear_r39 : Raw := (.obj linear_l39_0)
def linear_b39 : List Nat := linear_g101 ++ (linear_v39_0 ++ linear_g113)
theorem linear_o39 : orderedFields linear_l39_0 = true := by decide +kernel
theorem linear_s39 : serializeRaw 4081 28 linear_r39 = some linear_b39 := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4080 27 linear_l39_0 linear_v39_0 linear_o39 linear_sl39_0)
theorem linear_p39 (tail : List Nat) : parseRaw 4081 28 (linear_b39 ++ tail) = some (linear_r39, tail) := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4080 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) tail linear_l39_0 linear_o39 (by simpa only [linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl39_0 tail)))
def linear_r45 : Raw := (.str [100,103,95,102,97,115,116,95,48])
def linear_b45 : List Nat := linear_g117
theorem linear_s45 : serializeRaw 4078 27 linear_r45 = some linear_b45 := by decide +kernel
theorem linear_p45 (tail : List Nat) : parseRaw 4078 27 (linear_b45 ++ tail) = some (linear_r45, tail) := by rfl
def linear_r46 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,53]),(.str [100,103,95,118,95,53,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,54])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b46 : List Nat := linear_g120
theorem linear_s46 : serializeRaw 4077 27 linear_r46 = some linear_b46 := by decide +kernel
theorem linear_p46 (tail : List Nat) : parseRaw 4077 27 (linear_b46 ++ tail) = some (linear_r46, tail) := by rfl
def linear_r47 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b47 : List Nat := linear_g123
theorem linear_s47 : serializeRaw 4076 27 linear_r47 = some linear_b47 := by decide +kernel
theorem linear_p47 (tail : List Nat) : parseRaw 4076 27 (linear_b47 ++ tail) = some (linear_r47, tail) := by rfl
def linear_r48 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,53,54])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b48 : List Nat := linear_g126
theorem linear_s48 : serializeRaw 4075 27 linear_r48 = some linear_b48 := by decide +kernel
theorem linear_p48 (tail : List Nat) : parseRaw 4075 27 (linear_b48 ++ tail) = some (linear_r48, tail) := by rfl
def linear_k44_0 : List Nat := [105,100]
theorem linear_kd44_0 : stringBytes linear_k44_0 = true := by decide +kernel
theorem linear_kp44_0 (tail : List Nat) : parseStringTail (linear_k44_0 ++ (34 :: 58 :: tail)) [] = some (linear_k44_0, 58 :: tail) := by rfl
def linear_k44_1 : List Nat := [111,112,115]
theorem linear_kd44_1 : stringBytes linear_k44_1 = true := by decide +kernel
theorem linear_kp44_1 (tail : List Nat) : parseStringTail (linear_k44_1 ++ (34 :: 58 :: tail)) [] = some (linear_k44_1, 58 :: tail) := by rfl
def linear_k44_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd44_2 : stringBytes linear_k44_2 = true := by decide +kernel
theorem linear_kp44_2 (tail : List Nat) : parseStringTail (linear_k44_2 ++ (34 :: 58 :: tail)) [] = some (linear_k44_2, 58 :: tail) := by rfl
def linear_k44_3 : List Nat := [116,101,114,109]
theorem linear_kd44_3 : stringBytes linear_k44_3 = true := by decide +kernel
theorem linear_kp44_3 (tail : List Nat) : parseStringTail (linear_k44_3 ++ (34 :: 58 :: tail)) [] = some (linear_k44_3, 58 :: tail) := by rfl
def linear_l44_3 : List (List Nat × Raw) := [(linear_k44_3, linear_r48)]
def linear_v44_3 : List Nat := linear_g125 ++ linear_b48
theorem linear_sl44_3 : serializeFields 4076 27 linear_l44_3 = some linear_v44_3 := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4075 27 linear_k44_3 linear_r48 linear_b48 linear_kd44_3 linear_s48)
theorem linear_pl44_3 (tail : List Nat) : parseFields 4076 27 (linear_v44_3 ++ (125 :: tail)) = some (linear_l44_3, tail) := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4075 27 (linear_k44_3 ++ (34 :: 58 :: (linear_b48 ++ (125 :: tail)))) linear_k44_3 (linear_b48 ++ (125 :: tail)) tail linear_r48 (linear_kp44_3 (linear_b48 ++ (125 :: tail))) (linear_p48 (125 :: tail)))
def linear_l44_2 : List (List Nat × Raw) := (linear_k44_2, linear_r47) :: linear_l44_3
def linear_v44_2 : List Nat := (linear_g122 ++ linear_b47) ++ (44 :: linear_v44_3)
theorem linear_sl44_2 : serializeFields 4077 27 linear_l44_2 = some linear_v44_2 := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k44_2 linear_r47 (linear_k44_3, linear_r48) [] linear_b47 linear_v44_3 linear_kd44_2 linear_s47 linear_sl44_3)
theorem linear_pl44_2 (tail : List Nat) : parseFields 4077 27 (linear_v44_2 ++ (125 :: tail)) = some (linear_l44_2, tail) := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k44_2 ++ (34 :: 58 :: (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))))) linear_k44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))) (linear_v44_3 ++ (125 :: tail)) tail linear_r47 linear_l44_3 (linear_kp44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail))))) (linear_p47 (44 :: (linear_v44_3 ++ (125 :: tail)))) (linear_pl44_3 tail))
def linear_l44_1 : List (List Nat × Raw) := (linear_k44_1, linear_r46) :: linear_l44_2
def linear_v44_1 : List Nat := (linear_g119 ++ linear_b46) ++ (44 :: linear_v44_2)
theorem linear_sl44_1 : serializeFields 4078 27 linear_l44_1 = some linear_v44_1 := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k44_1 linear_r46 (linear_k44_2, linear_r47) linear_l44_3 linear_b46 linear_v44_2 linear_kd44_1 linear_s46 linear_sl44_2)
theorem linear_pl44_1 (tail : List Nat) : parseFields 4078 27 (linear_v44_1 ++ (125 :: tail)) = some (linear_l44_1, tail) := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k44_1 ++ (34 :: 58 :: (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))))) linear_k44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))) (linear_v44_2 ++ (125 :: tail)) tail linear_r46 linear_l44_2 (linear_kp44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail))))) (linear_p46 (44 :: (linear_v44_2 ++ (125 :: tail)))) (linear_pl44_2 tail))
def linear_l44_0 : List (List Nat × Raw) := (linear_k44_0, linear_r45) :: linear_l44_1
def linear_v44_0 : List Nat := (linear_g116 ++ linear_b45) ++ (44 :: linear_v44_1)
theorem linear_sl44_0 : serializeFields 4079 27 linear_l44_0 = some linear_v44_0 := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k44_0 linear_r45 (linear_k44_1, linear_r46) linear_l44_2 linear_b45 linear_v44_1 linear_kd44_0 linear_s45 linear_sl44_1)
theorem linear_pl44_0 (tail : List Nat) : parseFields 4079 27 (linear_v44_0 ++ (125 :: tail)) = some (linear_l44_0, tail) := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) linear_k44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))) (linear_v44_1 ++ (125 :: tail)) tail linear_r45 linear_l44_1 (linear_kp44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail))))) (linear_p45 (44 :: (linear_v44_1 ++ (125 :: tail)))) (linear_pl44_1 tail))
def linear_r44 : Raw := (.obj linear_l44_0)
def linear_b44 : List Nat := linear_g115 ++ (linear_v44_0 ++ linear_g127)
theorem linear_o44 : orderedFields linear_l44_0 = true := by decide +kernel
theorem linear_s44 : serializeRaw 4080 28 linear_r44 = some linear_b44 := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4079 27 linear_l44_0 linear_v44_0 linear_o44 linear_sl44_0)
theorem linear_p44 (tail : List Nat) : parseRaw 4080 28 (linear_b44 ++ tail) = some (linear_r44, tail) := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4079 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) tail linear_l44_0 linear_o44 (by simpa only [linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl44_0 tail)))
def linear_r50 : Raw := (.str [100,103,95,102,97,115,116,95,49])
def linear_b50 : List Nat := linear_g131
theorem linear_s50 : serializeRaw 4077 27 linear_r50 = some linear_b50 := by decide +kernel
theorem linear_p50 (tail : List Nat) : parseRaw 4077 27 (linear_b50 ++ tail) = some (linear_r50, tail) := by rfl
def linear_r52 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,50])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b52 : List Nat := linear_g135
theorem linear_s52 : serializeRaw 4074 26 linear_r52 = some linear_b52 := by decide +kernel
theorem linear_p52 (tail : List Nat) : parseRaw 4074 26 (linear_b52 ++ tail) = some (linear_r52, tail) := by rfl
def linear_r53 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,50]),(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,51])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b53 : List Nat := linear_g137
theorem linear_s53 : serializeRaw 4073 26 linear_r53 = some linear_b53 := by decide +kernel
theorem linear_p53 (tail : List Nat) : parseRaw 4073 26 (linear_b53 ++ tail) = some (linear_r53, tail) := by rfl
def linear_r54 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,52])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b54 : List Nat := linear_g139
theorem linear_s54 : serializeRaw 4072 26 linear_r54 = some linear_b54 := by decide +kernel
theorem linear_p54 (tail : List Nat) : parseRaw 4072 26 (linear_b54 ++ tail) = some (linear_r54, tail) := by rfl
def linear_r55 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b55 : List Nat := linear_g141
theorem linear_s55 : serializeRaw 4071 26 linear_r55 = some linear_b55 := by decide +kernel
theorem linear_p55 (tail : List Nat) : parseRaw 4071 26 (linear_b55 ++ tail) = some (linear_r55, tail) := by rfl
def linear_r56 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,52]),(.str [100,103,95,118,95,54,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,54])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b56 : List Nat := linear_g143
theorem linear_s56 : serializeRaw 4070 26 linear_r56 = some linear_b56 := by decide +kernel
theorem linear_p56 (tail : List Nat) : parseRaw 4070 26 (linear_b56 ++ tail) = some (linear_r56, tail) := by rfl
def linear_r57 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,54])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b57 : List Nat := linear_g145
theorem linear_s57 : serializeRaw 4069 26 linear_r57 = some linear_b57 := by decide +kernel
theorem linear_p57 (tail : List Nat) : parseRaw 4069 26 (linear_b57 ++ tail) = some (linear_r57, tail) := by rfl
def linear_r58 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,56])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b58 : List Nat := linear_g147
theorem linear_s58 : serializeRaw 4068 26 linear_r58 = some linear_b58 := by decide +kernel
theorem linear_p58 (tail : List Nat) : parseRaw 4068 26 (linear_b58 ++ tail) = some (linear_r58, tail) := by rfl
def linear_r59 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56]),(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b59 : List Nat := linear_g149
theorem linear_s59 : serializeRaw 4067 26 linear_r59 = some linear_b59 := by decide +kernel
theorem linear_p59 (tail : List Nat) : parseRaw 4067 26 (linear_b59 ++ tail) = some (linear_r59, tail) := by rfl
def linear_r60 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b60 : List Nat := linear_g151
theorem linear_s60 : serializeRaw 4066 26 linear_r60 = some linear_b60 := by decide +kernel
theorem linear_p60 (tail : List Nat) : parseRaw 4066 26 (linear_b60 ++ tail) = some (linear_r60, tail) := by rfl
def linear_r61 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b61 : List Nat := linear_g153
theorem linear_s61 : serializeRaw 4065 26 linear_r61 = some linear_b61 := by decide +kernel
theorem linear_p61 (tail : List Nat) : parseRaw 4065 26 (linear_b61 ++ tail) = some (linear_r61, tail) := by rfl
def linear_r62 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b62 : List Nat := linear_g155
theorem linear_s62 : serializeRaw 4064 26 linear_r62 = some linear_b62 := by decide +kernel
theorem linear_p62 (tail : List Nat) : parseRaw 4064 26 (linear_b62 ++ tail) = some (linear_r62, tail) := by rfl
def linear_l51_10 : List Raw := [linear_r62]
def linear_v51_10 : List Nat := linear_b62
theorem linear_sl51_10 : serializeItems 4065 26 linear_l51_10 = some linear_v51_10 := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4064 26 linear_r62 linear_b62 linear_s62)
theorem linear_pl51_10 (tail : List Nat) : parseItems 4065 26 (linear_v51_10 ++ (93 :: tail)) = some (linear_l51_10, tail) := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4064 26 (linear_b62 ++ (93 :: tail)) tail linear_r62 (linear_p62 (93 :: tail)))
def linear_l51_9 : List Raw := linear_r61 :: linear_l51_10
def linear_v51_9 : List Nat := (linear_b61) ++ (44 :: linear_v51_10)
theorem linear_sl51_9 : serializeItems 4066 26 linear_l51_9 = some linear_v51_9 := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r61 linear_r62 [] linear_b61 linear_v51_10 linear_s61 linear_sl51_10)
theorem linear_pl51_9 (tail : List Nat) : parseItems 4066 26 (linear_v51_9 ++ (93 :: tail)) = some (linear_l51_9, tail) := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b61 ++ (44 :: (linear_v51_10 ++ (93 :: tail)))) (linear_v51_10 ++ (93 :: tail)) tail linear_r61 linear_l51_10 (linear_p61 (44 :: (linear_v51_10 ++ (93 :: tail)))) (linear_pl51_10 tail))
def linear_l51_8 : List Raw := linear_r60 :: linear_l51_9
def linear_v51_8 : List Nat := (linear_b60) ++ (44 :: linear_v51_9)
theorem linear_sl51_8 : serializeItems 4067 26 linear_l51_8 = some linear_v51_8 := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r60 linear_r61 linear_l51_10 linear_b60 linear_v51_9 linear_s60 linear_sl51_9)
theorem linear_pl51_8 (tail : List Nat) : parseItems 4067 26 (linear_v51_8 ++ (93 :: tail)) = some (linear_l51_8, tail) := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b60 ++ (44 :: (linear_v51_9 ++ (93 :: tail)))) (linear_v51_9 ++ (93 :: tail)) tail linear_r60 linear_l51_9 (linear_p60 (44 :: (linear_v51_9 ++ (93 :: tail)))) (linear_pl51_9 tail))
def linear_l51_7 : List Raw := linear_r59 :: linear_l51_8
def linear_v51_7 : List Nat := (linear_b59) ++ (44 :: linear_v51_8)
theorem linear_sl51_7 : serializeItems 4068 26 linear_l51_7 = some linear_v51_7 := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r59 linear_r60 linear_l51_9 linear_b59 linear_v51_8 linear_s59 linear_sl51_8)
theorem linear_pl51_7 (tail : List Nat) : parseItems 4068 26 (linear_v51_7 ++ (93 :: tail)) = some (linear_l51_7, tail) := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b59 ++ (44 :: (linear_v51_8 ++ (93 :: tail)))) (linear_v51_8 ++ (93 :: tail)) tail linear_r59 linear_l51_8 (linear_p59 (44 :: (linear_v51_8 ++ (93 :: tail)))) (linear_pl51_8 tail))
def linear_l51_6 : List Raw := linear_r58 :: linear_l51_7
def linear_v51_6 : List Nat := (linear_b58) ++ (44 :: linear_v51_7)
theorem linear_sl51_6 : serializeItems 4069 26 linear_l51_6 = some linear_v51_6 := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r58 linear_r59 linear_l51_8 linear_b58 linear_v51_7 linear_s58 linear_sl51_7)
theorem linear_pl51_6 (tail : List Nat) : parseItems 4069 26 (linear_v51_6 ++ (93 :: tail)) = some (linear_l51_6, tail) := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b58 ++ (44 :: (linear_v51_7 ++ (93 :: tail)))) (linear_v51_7 ++ (93 :: tail)) tail linear_r58 linear_l51_7 (linear_p58 (44 :: (linear_v51_7 ++ (93 :: tail)))) (linear_pl51_7 tail))
def linear_l51_5 : List Raw := linear_r57 :: linear_l51_6
def linear_v51_5 : List Nat := (linear_b57) ++ (44 :: linear_v51_6)
theorem linear_sl51_5 : serializeItems 4070 26 linear_l51_5 = some linear_v51_5 := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r57 linear_r58 linear_l51_7 linear_b57 linear_v51_6 linear_s57 linear_sl51_6)
theorem linear_pl51_5 (tail : List Nat) : parseItems 4070 26 (linear_v51_5 ++ (93 :: tail)) = some (linear_l51_5, tail) := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b57 ++ (44 :: (linear_v51_6 ++ (93 :: tail)))) (linear_v51_6 ++ (93 :: tail)) tail linear_r57 linear_l51_6 (linear_p57 (44 :: (linear_v51_6 ++ (93 :: tail)))) (linear_pl51_6 tail))
def linear_l51_4 : List Raw := linear_r56 :: linear_l51_5
def linear_v51_4 : List Nat := (linear_b56) ++ (44 :: linear_v51_5)
theorem linear_sl51_4 : serializeItems 4071 26 linear_l51_4 = some linear_v51_4 := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r56 linear_r57 linear_l51_6 linear_b56 linear_v51_5 linear_s56 linear_sl51_5)
theorem linear_pl51_4 (tail : List Nat) : parseItems 4071 26 (linear_v51_4 ++ (93 :: tail)) = some (linear_l51_4, tail) := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b56 ++ (44 :: (linear_v51_5 ++ (93 :: tail)))) (linear_v51_5 ++ (93 :: tail)) tail linear_r56 linear_l51_5 (linear_p56 (44 :: (linear_v51_5 ++ (93 :: tail)))) (linear_pl51_5 tail))
def linear_l51_3 : List Raw := linear_r55 :: linear_l51_4
def linear_v51_3 : List Nat := (linear_b55) ++ (44 :: linear_v51_4)
theorem linear_sl51_3 : serializeItems 4072 26 linear_l51_3 = some linear_v51_3 := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r55 linear_r56 linear_l51_5 linear_b55 linear_v51_4 linear_s55 linear_sl51_4)
theorem linear_pl51_3 (tail : List Nat) : parseItems 4072 26 (linear_v51_3 ++ (93 :: tail)) = some (linear_l51_3, tail) := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b55 ++ (44 :: (linear_v51_4 ++ (93 :: tail)))) (linear_v51_4 ++ (93 :: tail)) tail linear_r55 linear_l51_4 (linear_p55 (44 :: (linear_v51_4 ++ (93 :: tail)))) (linear_pl51_4 tail))
def linear_l51_2 : List Raw := linear_r54 :: linear_l51_3
def linear_v51_2 : List Nat := (linear_b54) ++ (44 :: linear_v51_3)
theorem linear_sl51_2 : serializeItems 4073 26 linear_l51_2 = some linear_v51_2 := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 26 linear_r54 linear_r55 linear_l51_4 linear_b54 linear_v51_3 linear_s54 linear_sl51_3)
theorem linear_pl51_2 (tail : List Nat) : parseItems 4073 26 (linear_v51_2 ++ (93 :: tail)) = some (linear_l51_2, tail) := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 26 (linear_b54 ++ (44 :: (linear_v51_3 ++ (93 :: tail)))) (linear_v51_3 ++ (93 :: tail)) tail linear_r54 linear_l51_3 (linear_p54 (44 :: (linear_v51_3 ++ (93 :: tail)))) (linear_pl51_3 tail))
def linear_l51_1 : List Raw := linear_r53 :: linear_l51_2
def linear_v51_1 : List Nat := (linear_b53) ++ (44 :: linear_v51_2)
theorem linear_sl51_1 : serializeItems 4074 26 linear_l51_1 = some linear_v51_1 := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 26 linear_r53 linear_r54 linear_l51_3 linear_b53 linear_v51_2 linear_s53 linear_sl51_2)
theorem linear_pl51_1 (tail : List Nat) : parseItems 4074 26 (linear_v51_1 ++ (93 :: tail)) = some (linear_l51_1, tail) := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 26 (linear_b53 ++ (44 :: (linear_v51_2 ++ (93 :: tail)))) (linear_v51_2 ++ (93 :: tail)) tail linear_r53 linear_l51_2 (linear_p53 (44 :: (linear_v51_2 ++ (93 :: tail)))) (linear_pl51_2 tail))
def linear_l51_0 : List Raw := linear_r52 :: linear_l51_1
def linear_v51_0 : List Nat := (linear_b52) ++ (44 :: linear_v51_1)
theorem linear_sl51_0 : serializeItems 4075 26 linear_l51_0 = some linear_v51_0 := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 26 linear_r52 linear_r53 linear_l51_2 linear_b52 linear_v51_1 linear_s52 linear_sl51_1)
theorem linear_pl51_0 (tail : List Nat) : parseItems 4075 26 (linear_v51_0 ++ (93 :: tail)) = some (linear_l51_0, tail) := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 26 (linear_b52 ++ (44 :: (linear_v51_1 ++ (93 :: tail)))) (linear_v51_1 ++ (93 :: tail)) tail linear_r52 linear_l51_1 (linear_p52 (44 :: (linear_v51_1 ++ (93 :: tail)))) (linear_pl51_1 tail))
def linear_r51 : Raw := (.arr linear_l51_0)
def linear_b51 : List Nat := linear_g134 ++ (linear_v51_0 ++ linear_g156)
theorem linear_s51 : serializeRaw 4076 27 linear_r51 = some linear_b51 := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4075 26 linear_l51_0 linear_v51_0 linear_sl51_0)
theorem linear_p51 (tail : List Nat) : parseRaw 4076 27 (linear_b51 ++ tail) = some (linear_r51, tail) := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4075 26 (linear_v51_0 ++ (93 :: tail)) tail linear_l51_0 (by intro h; cases h) (linear_pl51_0 tail))
def linear_r63 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b63 : List Nat := linear_g159
theorem linear_s63 : serializeRaw 4075 27 linear_r63 = some linear_b63 := by decide +kernel
theorem linear_p63 (tail : List Nat) : parseRaw 4075 27 (linear_b63 ++ tail) = some (linear_r63, tail) := by rfl
def linear_r64 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,55]),(.str [100,103,95,118,95,53,56]),(.str [100,103,95,118,95,53,57]),(.str [100,103,95,118,95,54,48]),(.str [100,103,95,118,95,55,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,48]))])
def linear_b64 : List Nat := linear_g162
theorem linear_s64 : serializeRaw 4074 27 linear_r64 = some linear_b64 := by decide +kernel
theorem linear_p64 (tail : List Nat) : parseRaw 4074 27 (linear_b64 ++ tail) = some (linear_r64, tail) := by rfl
def linear_k49_0 : List Nat := [105,100]
theorem linear_kd49_0 : stringBytes linear_k49_0 = true := by decide +kernel
theorem linear_kp49_0 (tail : List Nat) : parseStringTail (linear_k49_0 ++ (34 :: 58 :: tail)) [] = some (linear_k49_0, 58 :: tail) := by rfl
def linear_k49_1 : List Nat := [111,112,115]
theorem linear_kd49_1 : stringBytes linear_k49_1 = true := by decide +kernel
theorem linear_kp49_1 (tail : List Nat) : parseStringTail (linear_k49_1 ++ (34 :: 58 :: tail)) [] = some (linear_k49_1, 58 :: tail) := by rfl
def linear_k49_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd49_2 : stringBytes linear_k49_2 = true := by decide +kernel
theorem linear_kp49_2 (tail : List Nat) : parseStringTail (linear_k49_2 ++ (34 :: 58 :: tail)) [] = some (linear_k49_2, 58 :: tail) := by rfl
def linear_k49_3 : List Nat := [116,101,114,109]
theorem linear_kd49_3 : stringBytes linear_k49_3 = true := by decide +kernel
theorem linear_kp49_3 (tail : List Nat) : parseStringTail (linear_k49_3 ++ (34 :: 58 :: tail)) [] = some (linear_k49_3, 58 :: tail) := by rfl
def linear_l49_3 : List (List Nat × Raw) := [(linear_k49_3, linear_r64)]
def linear_v49_3 : List Nat := linear_g161 ++ linear_b64
theorem linear_sl49_3 : serializeFields 4075 27 linear_l49_3 = some linear_v49_3 := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4074 27 linear_k49_3 linear_r64 linear_b64 linear_kd49_3 linear_s64)
theorem linear_pl49_3 (tail : List Nat) : parseFields 4075 27 (linear_v49_3 ++ (125 :: tail)) = some (linear_l49_3, tail) := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4074 27 (linear_k49_3 ++ (34 :: 58 :: (linear_b64 ++ (125 :: tail)))) linear_k49_3 (linear_b64 ++ (125 :: tail)) tail linear_r64 (linear_kp49_3 (linear_b64 ++ (125 :: tail))) (linear_p64 (125 :: tail)))
def linear_l49_2 : List (List Nat × Raw) := (linear_k49_2, linear_r63) :: linear_l49_3
def linear_v49_2 : List Nat := (linear_g158 ++ linear_b63) ++ (44 :: linear_v49_3)
theorem linear_sl49_2 : serializeFields 4076 27 linear_l49_2 = some linear_v49_2 := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k49_2 linear_r63 (linear_k49_3, linear_r64) [] linear_b63 linear_v49_3 linear_kd49_2 linear_s63 linear_sl49_3)
theorem linear_pl49_2 (tail : List Nat) : parseFields 4076 27 (linear_v49_2 ++ (125 :: tail)) = some (linear_l49_2, tail) := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k49_2 ++ (34 :: 58 :: (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))))) linear_k49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))) (linear_v49_3 ++ (125 :: tail)) tail linear_r63 linear_l49_3 (linear_kp49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail))))) (linear_p63 (44 :: (linear_v49_3 ++ (125 :: tail)))) (linear_pl49_3 tail))
def linear_l49_1 : List (List Nat × Raw) := (linear_k49_1, linear_r51) :: linear_l49_2
def linear_v49_1 : List Nat := (linear_g133 ++ linear_b51) ++ (44 :: linear_v49_2)
theorem linear_sl49_1 : serializeFields 4077 27 linear_l49_1 = some linear_v49_1 := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k49_1 linear_r51 (linear_k49_2, linear_r63) linear_l49_3 linear_b51 linear_v49_2 linear_kd49_1 linear_s51 linear_sl49_2)
theorem linear_pl49_1 (tail : List Nat) : parseFields 4077 27 (linear_v49_1 ++ (125 :: tail)) = some (linear_l49_1, tail) := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k49_1 ++ (34 :: 58 :: (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))))) linear_k49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))) (linear_v49_2 ++ (125 :: tail)) tail linear_r51 linear_l49_2 (linear_kp49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail))))) (linear_p51 (44 :: (linear_v49_2 ++ (125 :: tail)))) (linear_pl49_2 tail))
def linear_l49_0 : List (List Nat × Raw) := (linear_k49_0, linear_r50) :: linear_l49_1
def linear_v49_0 : List Nat := (linear_g130 ++ linear_b50) ++ (44 :: linear_v49_1)
theorem linear_sl49_0 : serializeFields 4078 27 linear_l49_0 = some linear_v49_0 := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k49_0 linear_r50 (linear_k49_1, linear_r51) linear_l49_2 linear_b50 linear_v49_1 linear_kd49_0 linear_s50 linear_sl49_1)
theorem linear_pl49_0 (tail : List Nat) : parseFields 4078 27 (linear_v49_0 ++ (125 :: tail)) = some (linear_l49_0, tail) := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) linear_k49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))) (linear_v49_1 ++ (125 :: tail)) tail linear_r50 linear_l49_1 (linear_kp49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail))))) (linear_p50 (44 :: (linear_v49_1 ++ (125 :: tail)))) (linear_pl49_1 tail))
def linear_r49 : Raw := (.obj linear_l49_0)
def linear_b49 : List Nat := linear_g129 ++ (linear_v49_0 ++ linear_g163)
theorem linear_o49 : orderedFields linear_l49_0 = true := by decide +kernel
theorem linear_s49 : serializeRaw 4079 28 linear_r49 = some linear_b49 := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4078 27 linear_l49_0 linear_v49_0 linear_o49 linear_sl49_0)
theorem linear_p49 (tail : List Nat) : parseRaw 4079 28 (linear_b49 ++ tail) = some (linear_r49, tail) := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4078 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) tail linear_l49_0 linear_o49 (by simpa only [linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl49_0 tail)))
def linear_r66 : Raw := (.str [100,103,95,102,97,115,116,95,50])
def linear_b66 : List Nat := linear_g167
theorem linear_s66 : serializeRaw 4076 27 linear_r66 = some linear_b66 := by decide +kernel
theorem linear_p66 (tail : List Nat) : parseRaw 4076 27 (linear_b66 ++ tail) = some (linear_r66, tail) := by rfl
def linear_r67 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,54])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,55])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b67 : List Nat := linear_g170
theorem linear_s67 : serializeRaw 4075 27 linear_r67 = some linear_b67 := by decide +kernel
theorem linear_p67 (tail : List Nat) : parseRaw 4075 27 (linear_b67 ++ tail) = some (linear_r67, tail) := by rfl
def linear_r68 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b68 : List Nat := linear_g173
theorem linear_s68 : serializeRaw 4074 27 linear_r68 = some linear_b68 := by decide +kernel
theorem linear_p68 (tail : List Nat) : parseRaw 4074 27 (linear_b68 ++ tail) = some (linear_r68, tail) := by rfl
def linear_r69 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,50]),(.str [100,103,95,118,95,55,51]),(.str [100,103,95,118,95,55,54]),(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,55])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b69 : List Nat := linear_g176
theorem linear_s69 : serializeRaw 4073 27 linear_r69 = some linear_b69 := by decide +kernel
theorem linear_p69 (tail : List Nat) : parseRaw 4073 27 (linear_b69 ++ tail) = some (linear_r69, tail) := by rfl
def linear_k65_0 : List Nat := [105,100]
theorem linear_kd65_0 : stringBytes linear_k65_0 = true := by decide +kernel
theorem linear_kp65_0 (tail : List Nat) : parseStringTail (linear_k65_0 ++ (34 :: 58 :: tail)) [] = some (linear_k65_0, 58 :: tail) := by rfl
def linear_k65_1 : List Nat := [111,112,115]
theorem linear_kd65_1 : stringBytes linear_k65_1 = true := by decide +kernel
theorem linear_kp65_1 (tail : List Nat) : parseStringTail (linear_k65_1 ++ (34 :: 58 :: tail)) [] = some (linear_k65_1, 58 :: tail) := by rfl
def linear_k65_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd65_2 : stringBytes linear_k65_2 = true := by decide +kernel
theorem linear_kp65_2 (tail : List Nat) : parseStringTail (linear_k65_2 ++ (34 :: 58 :: tail)) [] = some (linear_k65_2, 58 :: tail) := by rfl
def linear_k65_3 : List Nat := [116,101,114,109]
theorem linear_kd65_3 : stringBytes linear_k65_3 = true := by decide +kernel
theorem linear_kp65_3 (tail : List Nat) : parseStringTail (linear_k65_3 ++ (34 :: 58 :: tail)) [] = some (linear_k65_3, 58 :: tail) := by rfl
def linear_l65_3 : List (List Nat × Raw) := [(linear_k65_3, linear_r69)]
def linear_v65_3 : List Nat := linear_g175 ++ linear_b69
theorem linear_sl65_3 : serializeFields 4074 27 linear_l65_3 = some linear_v65_3 := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4073 27 linear_k65_3 linear_r69 linear_b69 linear_kd65_3 linear_s69)
theorem linear_pl65_3 (tail : List Nat) : parseFields 4074 27 (linear_v65_3 ++ (125 :: tail)) = some (linear_l65_3, tail) := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4073 27 (linear_k65_3 ++ (34 :: 58 :: (linear_b69 ++ (125 :: tail)))) linear_k65_3 (linear_b69 ++ (125 :: tail)) tail linear_r69 (linear_kp65_3 (linear_b69 ++ (125 :: tail))) (linear_p69 (125 :: tail)))
def linear_l65_2 : List (List Nat × Raw) := (linear_k65_2, linear_r68) :: linear_l65_3
def linear_v65_2 : List Nat := (linear_g172 ++ linear_b68) ++ (44 :: linear_v65_3)
theorem linear_sl65_2 : serializeFields 4075 27 linear_l65_2 = some linear_v65_2 := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k65_2 linear_r68 (linear_k65_3, linear_r69) [] linear_b68 linear_v65_3 linear_kd65_2 linear_s68 linear_sl65_3)
theorem linear_pl65_2 (tail : List Nat) : parseFields 4075 27 (linear_v65_2 ++ (125 :: tail)) = some (linear_l65_2, tail) := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k65_2 ++ (34 :: 58 :: (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))))) linear_k65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))) (linear_v65_3 ++ (125 :: tail)) tail linear_r68 linear_l65_3 (linear_kp65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail))))) (linear_p68 (44 :: (linear_v65_3 ++ (125 :: tail)))) (linear_pl65_3 tail))
def linear_l65_1 : List (List Nat × Raw) := (linear_k65_1, linear_r67) :: linear_l65_2
def linear_v65_1 : List Nat := (linear_g169 ++ linear_b67) ++ (44 :: linear_v65_2)
theorem linear_sl65_1 : serializeFields 4076 27 linear_l65_1 = some linear_v65_1 := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k65_1 linear_r67 (linear_k65_2, linear_r68) linear_l65_3 linear_b67 linear_v65_2 linear_kd65_1 linear_s67 linear_sl65_2)
theorem linear_pl65_1 (tail : List Nat) : parseFields 4076 27 (linear_v65_1 ++ (125 :: tail)) = some (linear_l65_1, tail) := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k65_1 ++ (34 :: 58 :: (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))))) linear_k65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))) (linear_v65_2 ++ (125 :: tail)) tail linear_r67 linear_l65_2 (linear_kp65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail))))) (linear_p67 (44 :: (linear_v65_2 ++ (125 :: tail)))) (linear_pl65_2 tail))
def linear_l65_0 : List (List Nat × Raw) := (linear_k65_0, linear_r66) :: linear_l65_1
def linear_v65_0 : List Nat := (linear_g166 ++ linear_b66) ++ (44 :: linear_v65_1)
theorem linear_sl65_0 : serializeFields 4077 27 linear_l65_0 = some linear_v65_0 := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k65_0 linear_r66 (linear_k65_1, linear_r67) linear_l65_2 linear_b66 linear_v65_1 linear_kd65_0 linear_s66 linear_sl65_1)
theorem linear_pl65_0 (tail : List Nat) : parseFields 4077 27 (linear_v65_0 ++ (125 :: tail)) = some (linear_l65_0, tail) := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) linear_k65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))) (linear_v65_1 ++ (125 :: tail)) tail linear_r66 linear_l65_1 (linear_kp65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail))))) (linear_p66 (44 :: (linear_v65_1 ++ (125 :: tail)))) (linear_pl65_1 tail))
def linear_r65 : Raw := (.obj linear_l65_0)
def linear_b65 : List Nat := linear_g165 ++ (linear_v65_0 ++ linear_g177)
theorem linear_o65 : orderedFields linear_l65_0 = true := by decide +kernel
theorem linear_s65 : serializeRaw 4078 28 linear_r65 = some linear_b65 := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4077 27 linear_l65_0 linear_v65_0 linear_o65 linear_sl65_0)
theorem linear_p65 (tail : List Nat) : parseRaw 4078 28 (linear_b65 ++ tail) = some (linear_r65, tail) := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4077 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) tail linear_l65_0 linear_o65 (by simpa only [linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl65_0 tail)))
def linear_r71 : Raw := (.str [100,103,95,102,97,115,116,95,51])
def linear_b71 : List Nat := linear_g181
theorem linear_s71 : serializeRaw 4075 27 linear_r71 = some linear_b71 := by decide +kernel
theorem linear_p71 (tail : List Nat) : parseRaw 4075 27 (linear_b71 ++ tail) = some (linear_r71, tail) := by rfl
def linear_r72 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,51]),(.str [100,103,95,118,95,56,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b72 : List Nat := linear_g184
theorem linear_s72 : serializeRaw 4074 27 linear_r72 = some linear_b72 := by decide +kernel
theorem linear_p72 (tail : List Nat) : parseRaw 4074 27 (linear_b72 ++ tail) = some (linear_r72, tail) := by rfl
def linear_r73 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b73 : List Nat := linear_g187
theorem linear_s73 : serializeRaw 4073 27 linear_r73 = some linear_b73 := by decide +kernel
theorem linear_p73 (tail : List Nat) : parseRaw 4073 27 (linear_b73 ++ tail) = some (linear_r73, tail) := by rfl
def linear_r74 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,56,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b74 : List Nat := linear_g190
theorem linear_s74 : serializeRaw 4072 27 linear_r74 = some linear_b74 := by decide +kernel
theorem linear_p74 (tail : List Nat) : parseRaw 4072 27 (linear_b74 ++ tail) = some (linear_r74, tail) := by rfl
def linear_k70_0 : List Nat := [105,100]
theorem linear_kd70_0 : stringBytes linear_k70_0 = true := by decide +kernel
theorem linear_kp70_0 (tail : List Nat) : parseStringTail (linear_k70_0 ++ (34 :: 58 :: tail)) [] = some (linear_k70_0, 58 :: tail) := by rfl
def linear_k70_1 : List Nat := [111,112,115]
theorem linear_kd70_1 : stringBytes linear_k70_1 = true := by decide +kernel
theorem linear_kp70_1 (tail : List Nat) : parseStringTail (linear_k70_1 ++ (34 :: 58 :: tail)) [] = some (linear_k70_1, 58 :: tail) := by rfl
def linear_k70_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd70_2 : stringBytes linear_k70_2 = true := by decide +kernel
theorem linear_kp70_2 (tail : List Nat) : parseStringTail (linear_k70_2 ++ (34 :: 58 :: tail)) [] = some (linear_k70_2, 58 :: tail) := by rfl
def linear_k70_3 : List Nat := [116,101,114,109]
theorem linear_kd70_3 : stringBytes linear_k70_3 = true := by decide +kernel
theorem linear_kp70_3 (tail : List Nat) : parseStringTail (linear_k70_3 ++ (34 :: 58 :: tail)) [] = some (linear_k70_3, 58 :: tail) := by rfl
def linear_l70_3 : List (List Nat × Raw) := [(linear_k70_3, linear_r74)]
def linear_v70_3 : List Nat := linear_g189 ++ linear_b74
theorem linear_sl70_3 : serializeFields 4073 27 linear_l70_3 = some linear_v70_3 := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4072 27 linear_k70_3 linear_r74 linear_b74 linear_kd70_3 linear_s74)
theorem linear_pl70_3 (tail : List Nat) : parseFields 4073 27 (linear_v70_3 ++ (125 :: tail)) = some (linear_l70_3, tail) := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4072 27 (linear_k70_3 ++ (34 :: 58 :: (linear_b74 ++ (125 :: tail)))) linear_k70_3 (linear_b74 ++ (125 :: tail)) tail linear_r74 (linear_kp70_3 (linear_b74 ++ (125 :: tail))) (linear_p74 (125 :: tail)))
def linear_l70_2 : List (List Nat × Raw) := (linear_k70_2, linear_r73) :: linear_l70_3
def linear_v70_2 : List Nat := (linear_g186 ++ linear_b73) ++ (44 :: linear_v70_3)
theorem linear_sl70_2 : serializeFields 4074 27 linear_l70_2 = some linear_v70_2 := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k70_2 linear_r73 (linear_k70_3, linear_r74) [] linear_b73 linear_v70_3 linear_kd70_2 linear_s73 linear_sl70_3)
theorem linear_pl70_2 (tail : List Nat) : parseFields 4074 27 (linear_v70_2 ++ (125 :: tail)) = some (linear_l70_2, tail) := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k70_2 ++ (34 :: 58 :: (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))))) linear_k70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))) (linear_v70_3 ++ (125 :: tail)) tail linear_r73 linear_l70_3 (linear_kp70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail))))) (linear_p73 (44 :: (linear_v70_3 ++ (125 :: tail)))) (linear_pl70_3 tail))
def linear_l70_1 : List (List Nat × Raw) := (linear_k70_1, linear_r72) :: linear_l70_2
def linear_v70_1 : List Nat := (linear_g183 ++ linear_b72) ++ (44 :: linear_v70_2)
theorem linear_sl70_1 : serializeFields 4075 27 linear_l70_1 = some linear_v70_1 := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k70_1 linear_r72 (linear_k70_2, linear_r73) linear_l70_3 linear_b72 linear_v70_2 linear_kd70_1 linear_s72 linear_sl70_2)
theorem linear_pl70_1 (tail : List Nat) : parseFields 4075 27 (linear_v70_1 ++ (125 :: tail)) = some (linear_l70_1, tail) := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k70_1 ++ (34 :: 58 :: (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))))) linear_k70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))) (linear_v70_2 ++ (125 :: tail)) tail linear_r72 linear_l70_2 (linear_kp70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail))))) (linear_p72 (44 :: (linear_v70_2 ++ (125 :: tail)))) (linear_pl70_2 tail))
def linear_l70_0 : List (List Nat × Raw) := (linear_k70_0, linear_r71) :: linear_l70_1
def linear_v70_0 : List Nat := (linear_g180 ++ linear_b71) ++ (44 :: linear_v70_1)
theorem linear_sl70_0 : serializeFields 4076 27 linear_l70_0 = some linear_v70_0 := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k70_0 linear_r71 (linear_k70_1, linear_r72) linear_l70_2 linear_b71 linear_v70_1 linear_kd70_0 linear_s71 linear_sl70_1)
theorem linear_pl70_0 (tail : List Nat) : parseFields 4076 27 (linear_v70_0 ++ (125 :: tail)) = some (linear_l70_0, tail) := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) linear_k70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))) (linear_v70_1 ++ (125 :: tail)) tail linear_r71 linear_l70_1 (linear_kp70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail))))) (linear_p71 (44 :: (linear_v70_1 ++ (125 :: tail)))) (linear_pl70_1 tail))
def linear_r70 : Raw := (.obj linear_l70_0)
def linear_b70 : List Nat := linear_g179 ++ (linear_v70_0 ++ linear_g191)
theorem linear_o70 : orderedFields linear_l70_0 = true := by decide +kernel
theorem linear_s70 : serializeRaw 4077 28 linear_r70 = some linear_b70 := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4076 27 linear_l70_0 linear_v70_0 linear_o70 linear_sl70_0)
theorem linear_p70 (tail : List Nat) : parseRaw 4077 28 (linear_b70 ++ tail) = some (linear_r70, tail) := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4076 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) tail linear_l70_0 linear_o70 (by simpa only [linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl70_0 tail)))
def linear_r76 : Raw := (.str [100,103,95,102,97,115,116,95,52])
def linear_b76 : List Nat := linear_g195
theorem linear_s76 : serializeRaw 4074 27 linear_r76 = some linear_b76 := by decide +kernel
theorem linear_p76 (tail : List Nat) : parseRaw 4074 27 (linear_b76 ++ tail) = some (linear_r76, tail) := by rfl
def linear_r78 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,49])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b78 : List Nat := linear_g199
theorem linear_s78 : serializeRaw 4071 26 linear_r78 = some linear_b78 := by decide +kernel
theorem linear_p78 (tail : List Nat) : parseRaw 4071 26 (linear_b78 ++ tail) = some (linear_r78, tail) := by rfl
def linear_r79 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49]),(.str [100,103,95,118,95,57,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,50])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b79 : List Nat := linear_g201
theorem linear_s79 : serializeRaw 4070 26 linear_r79 = some linear_b79 := by decide +kernel
theorem linear_p79 (tail : List Nat) : parseRaw 4070 26 (linear_b79 ++ tail) = some (linear_r79, tail) := by rfl
def linear_r80 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b80 : List Nat := linear_g203
theorem linear_s80 : serializeRaw 4069 26 linear_r80 = some linear_b80 := by decide +kernel
theorem linear_p80 (tail : List Nat) : parseRaw 4069 26 (linear_b80 ++ tail) = some (linear_r80, tail) := by rfl
def linear_r81 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,50])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,51])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b81 : List Nat := linear_g205
theorem linear_s81 : serializeRaw 4068 26 linear_r81 = some linear_b81 := by decide +kernel
theorem linear_p81 (tail : List Nat) : parseRaw 4068 26 (linear_b81 ++ tail) = some (linear_r81, tail) := by rfl
def linear_r82 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,56]),(.str [100,103,95,118,95,57,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,52])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b82 : List Nat := linear_g207
theorem linear_s82 : serializeRaw 4067 26 linear_r82 = some linear_b82 := by decide +kernel
theorem linear_p82 (tail : List Nat) : parseRaw 4067 26 (linear_b82 ++ tail) = some (linear_r82, tail) := by rfl
def linear_r83 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,53])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b83 : List Nat := linear_g209
theorem linear_s83 : serializeRaw 4066 26 linear_r83 = some linear_b83 := by decide +kernel
theorem linear_p83 (tail : List Nat) : parseRaw 4066 26 (linear_b83 ++ tail) = some (linear_r83, tail) := by rfl
def linear_r84 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,48]),(.str [100,103,95,118,95,57,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,54])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b84 : List Nat := linear_g211
theorem linear_s84 : serializeRaw 4065 26 linear_r84 = some linear_b84 := by decide +kernel
theorem linear_p84 (tail : List Nat) : parseRaw 4065 26 (linear_b84 ++ tail) = some (linear_r84, tail) := by rfl
def linear_l77_6 : List Raw := [linear_r84]
def linear_v77_6 : List Nat := linear_b84
theorem linear_sl77_6 : serializeItems 4066 26 linear_l77_6 = some linear_v77_6 := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4065 26 linear_r84 linear_b84 linear_s84)
theorem linear_pl77_6 (tail : List Nat) : parseItems 4066 26 (linear_v77_6 ++ (93 :: tail)) = some (linear_l77_6, tail) := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4065 26 (linear_b84 ++ (93 :: tail)) tail linear_r84 (linear_p84 (93 :: tail)))
def linear_l77_5 : List Raw := linear_r83 :: linear_l77_6
def linear_v77_5 : List Nat := (linear_b83) ++ (44 :: linear_v77_6)
theorem linear_sl77_5 : serializeItems 4067 26 linear_l77_5 = some linear_v77_5 := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r83 linear_r84 [] linear_b83 linear_v77_6 linear_s83 linear_sl77_6)
theorem linear_pl77_5 (tail : List Nat) : parseItems 4067 26 (linear_v77_5 ++ (93 :: tail)) = some (linear_l77_5, tail) := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b83 ++ (44 :: (linear_v77_6 ++ (93 :: tail)))) (linear_v77_6 ++ (93 :: tail)) tail linear_r83 linear_l77_6 (linear_p83 (44 :: (linear_v77_6 ++ (93 :: tail)))) (linear_pl77_6 tail))
def linear_l77_4 : List Raw := linear_r82 :: linear_l77_5
def linear_v77_4 : List Nat := (linear_b82) ++ (44 :: linear_v77_5)
theorem linear_sl77_4 : serializeItems 4068 26 linear_l77_4 = some linear_v77_4 := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r82 linear_r83 linear_l77_6 linear_b82 linear_v77_5 linear_s82 linear_sl77_5)
theorem linear_pl77_4 (tail : List Nat) : parseItems 4068 26 (linear_v77_4 ++ (93 :: tail)) = some (linear_l77_4, tail) := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b82 ++ (44 :: (linear_v77_5 ++ (93 :: tail)))) (linear_v77_5 ++ (93 :: tail)) tail linear_r82 linear_l77_5 (linear_p82 (44 :: (linear_v77_5 ++ (93 :: tail)))) (linear_pl77_5 tail))
def linear_l77_3 : List Raw := linear_r81 :: linear_l77_4
def linear_v77_3 : List Nat := (linear_b81) ++ (44 :: linear_v77_4)
theorem linear_sl77_3 : serializeItems 4069 26 linear_l77_3 = some linear_v77_3 := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r81 linear_r82 linear_l77_5 linear_b81 linear_v77_4 linear_s81 linear_sl77_4)
theorem linear_pl77_3 (tail : List Nat) : parseItems 4069 26 (linear_v77_3 ++ (93 :: tail)) = some (linear_l77_3, tail) := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b81 ++ (44 :: (linear_v77_4 ++ (93 :: tail)))) (linear_v77_4 ++ (93 :: tail)) tail linear_r81 linear_l77_4 (linear_p81 (44 :: (linear_v77_4 ++ (93 :: tail)))) (linear_pl77_4 tail))
def linear_l77_2 : List Raw := linear_r80 :: linear_l77_3
def linear_v77_2 : List Nat := (linear_b80) ++ (44 :: linear_v77_3)
theorem linear_sl77_2 : serializeItems 4070 26 linear_l77_2 = some linear_v77_2 := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r80 linear_r81 linear_l77_4 linear_b80 linear_v77_3 linear_s80 linear_sl77_3)
theorem linear_pl77_2 (tail : List Nat) : parseItems 4070 26 (linear_v77_2 ++ (93 :: tail)) = some (linear_l77_2, tail) := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b80 ++ (44 :: (linear_v77_3 ++ (93 :: tail)))) (linear_v77_3 ++ (93 :: tail)) tail linear_r80 linear_l77_3 (linear_p80 (44 :: (linear_v77_3 ++ (93 :: tail)))) (linear_pl77_3 tail))
def linear_l77_1 : List Raw := linear_r79 :: linear_l77_2
def linear_v77_1 : List Nat := (linear_b79) ++ (44 :: linear_v77_2)
theorem linear_sl77_1 : serializeItems 4071 26 linear_l77_1 = some linear_v77_1 := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r79 linear_r80 linear_l77_3 linear_b79 linear_v77_2 linear_s79 linear_sl77_2)
theorem linear_pl77_1 (tail : List Nat) : parseItems 4071 26 (linear_v77_1 ++ (93 :: tail)) = some (linear_l77_1, tail) := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b79 ++ (44 :: (linear_v77_2 ++ (93 :: tail)))) (linear_v77_2 ++ (93 :: tail)) tail linear_r79 linear_l77_2 (linear_p79 (44 :: (linear_v77_2 ++ (93 :: tail)))) (linear_pl77_2 tail))
def linear_l77_0 : List Raw := linear_r78 :: linear_l77_1
def linear_v77_0 : List Nat := (linear_b78) ++ (44 :: linear_v77_1)
theorem linear_sl77_0 : serializeItems 4072 26 linear_l77_0 = some linear_v77_0 := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r78 linear_r79 linear_l77_2 linear_b78 linear_v77_1 linear_s78 linear_sl77_1)
theorem linear_pl77_0 (tail : List Nat) : parseItems 4072 26 (linear_v77_0 ++ (93 :: tail)) = some (linear_l77_0, tail) := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b78 ++ (44 :: (linear_v77_1 ++ (93 :: tail)))) (linear_v77_1 ++ (93 :: tail)) tail linear_r78 linear_l77_1 (linear_p78 (44 :: (linear_v77_1 ++ (93 :: tail)))) (linear_pl77_1 tail))
def linear_r77 : Raw := (.arr linear_l77_0)
def linear_b77 : List Nat := linear_g198 ++ (linear_v77_0 ++ linear_g212)
theorem linear_s77 : serializeRaw 4073 27 linear_r77 = some linear_b77 := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4072 26 linear_l77_0 linear_v77_0 linear_sl77_0)
theorem linear_p77 (tail : List Nat) : parseRaw 4073 27 (linear_b77 ++ tail) = some (linear_r77, tail) := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4072 26 (linear_v77_0 ++ (93 :: tail)) tail linear_l77_0 (by intro h; cases h) (linear_pl77_0 tail))
def linear_r85 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b85 : List Nat := linear_g215
theorem linear_s85 : serializeRaw 4072 27 linear_r85 = some linear_b85 := by decide +kernel
theorem linear_p85 (tail : List Nat) : parseRaw 4072 27 (linear_b85 ++ tail) = some (linear_r85, tail) := by rfl
def linear_r86 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,53]),(.str [100,103,95,118,95,56,54]),(.str [100,103,95,118,95,56,55]),(.str [100,103,95,118,95,57,52]),(.str [100,103,95,118,95,56,57]),(.str [100,103,95,118,95,57,54])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b86 : List Nat := linear_g218
theorem linear_s86 : serializeRaw 4071 27 linear_r86 = some linear_b86 := by decide +kernel
theorem linear_p86 (tail : List Nat) : parseRaw 4071 27 (linear_b86 ++ tail) = some (linear_r86, tail) := by rfl
def linear_k75_0 : List Nat := [105,100]
theorem linear_kd75_0 : stringBytes linear_k75_0 = true := by decide +kernel
theorem linear_kp75_0 (tail : List Nat) : parseStringTail (linear_k75_0 ++ (34 :: 58 :: tail)) [] = some (linear_k75_0, 58 :: tail) := by rfl
def linear_k75_1 : List Nat := [111,112,115]
theorem linear_kd75_1 : stringBytes linear_k75_1 = true := by decide +kernel
theorem linear_kp75_1 (tail : List Nat) : parseStringTail (linear_k75_1 ++ (34 :: 58 :: tail)) [] = some (linear_k75_1, 58 :: tail) := by rfl
def linear_k75_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd75_2 : stringBytes linear_k75_2 = true := by decide +kernel
theorem linear_kp75_2 (tail : List Nat) : parseStringTail (linear_k75_2 ++ (34 :: 58 :: tail)) [] = some (linear_k75_2, 58 :: tail) := by rfl
def linear_k75_3 : List Nat := [116,101,114,109]
theorem linear_kd75_3 : stringBytes linear_k75_3 = true := by decide +kernel
theorem linear_kp75_3 (tail : List Nat) : parseStringTail (linear_k75_3 ++ (34 :: 58 :: tail)) [] = some (linear_k75_3, 58 :: tail) := by rfl
def linear_l75_3 : List (List Nat × Raw) := [(linear_k75_3, linear_r86)]
def linear_v75_3 : List Nat := linear_g217 ++ linear_b86
theorem linear_sl75_3 : serializeFields 4072 27 linear_l75_3 = some linear_v75_3 := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4071 27 linear_k75_3 linear_r86 linear_b86 linear_kd75_3 linear_s86)
theorem linear_pl75_3 (tail : List Nat) : parseFields 4072 27 (linear_v75_3 ++ (125 :: tail)) = some (linear_l75_3, tail) := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4071 27 (linear_k75_3 ++ (34 :: 58 :: (linear_b86 ++ (125 :: tail)))) linear_k75_3 (linear_b86 ++ (125 :: tail)) tail linear_r86 (linear_kp75_3 (linear_b86 ++ (125 :: tail))) (linear_p86 (125 :: tail)))
def linear_l75_2 : List (List Nat × Raw) := (linear_k75_2, linear_r85) :: linear_l75_3
def linear_v75_2 : List Nat := (linear_g214 ++ linear_b85) ++ (44 :: linear_v75_3)
theorem linear_sl75_2 : serializeFields 4073 27 linear_l75_2 = some linear_v75_2 := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k75_2 linear_r85 (linear_k75_3, linear_r86) [] linear_b85 linear_v75_3 linear_kd75_2 linear_s85 linear_sl75_3)
theorem linear_pl75_2 (tail : List Nat) : parseFields 4073 27 (linear_v75_2 ++ (125 :: tail)) = some (linear_l75_2, tail) := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k75_2 ++ (34 :: 58 :: (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))))) linear_k75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))) (linear_v75_3 ++ (125 :: tail)) tail linear_r85 linear_l75_3 (linear_kp75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail))))) (linear_p85 (44 :: (linear_v75_3 ++ (125 :: tail)))) (linear_pl75_3 tail))
def linear_l75_1 : List (List Nat × Raw) := (linear_k75_1, linear_r77) :: linear_l75_2
def linear_v75_1 : List Nat := (linear_g197 ++ linear_b77) ++ (44 :: linear_v75_2)
theorem linear_sl75_1 : serializeFields 4074 27 linear_l75_1 = some linear_v75_1 := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k75_1 linear_r77 (linear_k75_2, linear_r85) linear_l75_3 linear_b77 linear_v75_2 linear_kd75_1 linear_s77 linear_sl75_2)
theorem linear_pl75_1 (tail : List Nat) : parseFields 4074 27 (linear_v75_1 ++ (125 :: tail)) = some (linear_l75_1, tail) := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k75_1 ++ (34 :: 58 :: (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))))) linear_k75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))) (linear_v75_2 ++ (125 :: tail)) tail linear_r77 linear_l75_2 (linear_kp75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail))))) (linear_p77 (44 :: (linear_v75_2 ++ (125 :: tail)))) (linear_pl75_2 tail))
def linear_l75_0 : List (List Nat × Raw) := (linear_k75_0, linear_r76) :: linear_l75_1
def linear_v75_0 : List Nat := (linear_g194 ++ linear_b76) ++ (44 :: linear_v75_1)
theorem linear_sl75_0 : serializeFields 4075 27 linear_l75_0 = some linear_v75_0 := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k75_0 linear_r76 (linear_k75_1, linear_r77) linear_l75_2 linear_b76 linear_v75_1 linear_kd75_0 linear_s76 linear_sl75_1)
theorem linear_pl75_0 (tail : List Nat) : parseFields 4075 27 (linear_v75_0 ++ (125 :: tail)) = some (linear_l75_0, tail) := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) linear_k75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))) (linear_v75_1 ++ (125 :: tail)) tail linear_r76 linear_l75_1 (linear_kp75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail))))) (linear_p76 (44 :: (linear_v75_1 ++ (125 :: tail)))) (linear_pl75_1 tail))
def linear_r75 : Raw := (.obj linear_l75_0)
def linear_b75 : List Nat := linear_g193 ++ (linear_v75_0 ++ linear_g219)
theorem linear_o75 : orderedFields linear_l75_0 = true := by decide +kernel
theorem linear_s75 : serializeRaw 4076 28 linear_r75 = some linear_b75 := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4075 27 linear_l75_0 linear_v75_0 linear_o75 linear_sl75_0)
theorem linear_p75 (tail : List Nat) : parseRaw 4076 28 (linear_b75 ++ tail) = some (linear_r75, tail) := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4075 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) tail linear_l75_0 linear_o75 (by simpa only [linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl75_0 tail)))
def linear_r88 : Raw := (.str [100,103,95,102,97,115,116,95,53])
def linear_b88 : List Nat := linear_g223
theorem linear_s88 : serializeRaw 4073 27 linear_r88 = some linear_b88 := by decide +kernel
theorem linear_p88 (tail : List Nat) : parseRaw 4073 27 (linear_b88 ++ tail) = some (linear_r88, tail) := by rfl
def linear_r89 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b89 : List Nat := linear_g226
theorem linear_s89 : serializeRaw 4072 27 linear_r89 = some linear_b89 := by decide +kernel
theorem linear_p89 (tail : List Nat) : parseRaw 4072 27 (linear_b89 ++ tail) = some (linear_r89, tail) := by rfl
def linear_r90 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,48])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b90 : List Nat := linear_g229
theorem linear_s90 : serializeRaw 4071 27 linear_r90 = some linear_b90 := by decide +kernel
theorem linear_p90 (tail : List Nat) : parseRaw 4071 27 (linear_b90 ++ tail) = some (linear_r90, tail) := by rfl
def linear_r91 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,48,48])]))])
def linear_b91 : List Nat := linear_g232
theorem linear_s91 : serializeRaw 4070 27 linear_r91 = some linear_b91 := by decide +kernel
theorem linear_p91 (tail : List Nat) : parseRaw 4070 27 (linear_b91 ++ tail) = some (linear_r91, tail) := by rfl
def linear_k87_0 : List Nat := [105,100]
theorem linear_kd87_0 : stringBytes linear_k87_0 = true := by decide +kernel
theorem linear_kp87_0 (tail : List Nat) : parseStringTail (linear_k87_0 ++ (34 :: 58 :: tail)) [] = some (linear_k87_0, 58 :: tail) := by rfl
def linear_k87_1 : List Nat := [111,112,115]
theorem linear_kd87_1 : stringBytes linear_k87_1 = true := by decide +kernel
theorem linear_kp87_1 (tail : List Nat) : parseStringTail (linear_k87_1 ++ (34 :: 58 :: tail)) [] = some (linear_k87_1, 58 :: tail) := by rfl
def linear_k87_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd87_2 : stringBytes linear_k87_2 = true := by decide +kernel
theorem linear_kp87_2 (tail : List Nat) : parseStringTail (linear_k87_2 ++ (34 :: 58 :: tail)) [] = some (linear_k87_2, 58 :: tail) := by rfl
def linear_k87_3 : List Nat := [116,101,114,109]
theorem linear_kd87_3 : stringBytes linear_k87_3 = true := by decide +kernel
theorem linear_kp87_3 (tail : List Nat) : parseStringTail (linear_k87_3 ++ (34 :: 58 :: tail)) [] = some (linear_k87_3, 58 :: tail) := by rfl
def linear_l87_3 : List (List Nat × Raw) := [(linear_k87_3, linear_r91)]
def linear_v87_3 : List Nat := linear_g231 ++ linear_b91
theorem linear_sl87_3 : serializeFields 4071 27 linear_l87_3 = some linear_v87_3 := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4070 27 linear_k87_3 linear_r91 linear_b91 linear_kd87_3 linear_s91)
theorem linear_pl87_3 (tail : List Nat) : parseFields 4071 27 (linear_v87_3 ++ (125 :: tail)) = some (linear_l87_3, tail) := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4070 27 (linear_k87_3 ++ (34 :: 58 :: (linear_b91 ++ (125 :: tail)))) linear_k87_3 (linear_b91 ++ (125 :: tail)) tail linear_r91 (linear_kp87_3 (linear_b91 ++ (125 :: tail))) (linear_p91 (125 :: tail)))
def linear_l87_2 : List (List Nat × Raw) := (linear_k87_2, linear_r90) :: linear_l87_3
def linear_v87_2 : List Nat := (linear_g228 ++ linear_b90) ++ (44 :: linear_v87_3)
theorem linear_sl87_2 : serializeFields 4072 27 linear_l87_2 = some linear_v87_2 := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k87_2 linear_r90 (linear_k87_3, linear_r91) [] linear_b90 linear_v87_3 linear_kd87_2 linear_s90 linear_sl87_3)
theorem linear_pl87_2 (tail : List Nat) : parseFields 4072 27 (linear_v87_2 ++ (125 :: tail)) = some (linear_l87_2, tail) := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k87_2 ++ (34 :: 58 :: (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))))) linear_k87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))) (linear_v87_3 ++ (125 :: tail)) tail linear_r90 linear_l87_3 (linear_kp87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail))))) (linear_p90 (44 :: (linear_v87_3 ++ (125 :: tail)))) (linear_pl87_3 tail))
def linear_l87_1 : List (List Nat × Raw) := (linear_k87_1, linear_r89) :: linear_l87_2
def linear_v87_1 : List Nat := (linear_g225 ++ linear_b89) ++ (44 :: linear_v87_2)
theorem linear_sl87_1 : serializeFields 4073 27 linear_l87_1 = some linear_v87_1 := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k87_1 linear_r89 (linear_k87_2, linear_r90) linear_l87_3 linear_b89 linear_v87_2 linear_kd87_1 linear_s89 linear_sl87_2)
theorem linear_pl87_1 (tail : List Nat) : parseFields 4073 27 (linear_v87_1 ++ (125 :: tail)) = some (linear_l87_1, tail) := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k87_1 ++ (34 :: 58 :: (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))))) linear_k87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))) (linear_v87_2 ++ (125 :: tail)) tail linear_r89 linear_l87_2 (linear_kp87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail))))) (linear_p89 (44 :: (linear_v87_2 ++ (125 :: tail)))) (linear_pl87_2 tail))
def linear_l87_0 : List (List Nat × Raw) := (linear_k87_0, linear_r88) :: linear_l87_1
def linear_v87_0 : List Nat := (linear_g222 ++ linear_b88) ++ (44 :: linear_v87_1)
theorem linear_sl87_0 : serializeFields 4074 27 linear_l87_0 = some linear_v87_0 := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k87_0 linear_r88 (linear_k87_1, linear_r89) linear_l87_2 linear_b88 linear_v87_1 linear_kd87_0 linear_s88 linear_sl87_1)
theorem linear_pl87_0 (tail : List Nat) : parseFields 4074 27 (linear_v87_0 ++ (125 :: tail)) = some (linear_l87_0, tail) := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) linear_k87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))) (linear_v87_1 ++ (125 :: tail)) tail linear_r88 linear_l87_1 (linear_kp87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail))))) (linear_p88 (44 :: (linear_v87_1 ++ (125 :: tail)))) (linear_pl87_1 tail))
def linear_r87 : Raw := (.obj linear_l87_0)
def linear_b87 : List Nat := linear_g221 ++ (linear_v87_0 ++ linear_g233)
theorem linear_o87 : orderedFields linear_l87_0 = true := by decide +kernel
theorem linear_s87 : serializeRaw 4075 28 linear_r87 = some linear_b87 := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4074 27 linear_l87_0 linear_v87_0 linear_o87 linear_sl87_0)
theorem linear_p87 (tail : List Nat) : parseRaw 4075 28 (linear_b87 ++ tail) = some (linear_r87, tail) := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4074 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) tail linear_l87_0 linear_o87 (by simpa only [linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl87_0 tail)))
def linear_r93 : Raw := (.str [100,103,95,115,108,111,119,95,48])
def linear_b93 : List Nat := linear_g237
theorem linear_s93 : serializeRaw 4072 27 linear_r93 = some linear_b93 := by decide +kernel
theorem linear_p93 (tail : List Nat) : parseRaw 4072 27 (linear_b93 ++ tail) = some (linear_r93, tail) := by rfl
def linear_r94 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,56]),(.str [100,103,95,118,95,49,48,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,57])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b94 : List Nat := linear_g240
theorem linear_s94 : serializeRaw 4071 27 linear_r94 = some linear_b94 := by decide +kernel
theorem linear_p94 (tail : List Nat) : parseRaw 4071 27 (linear_b94 ++ tail) = some (linear_r94, tail) := by rfl
def linear_r95 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b95 : List Nat := linear_g243
theorem linear_s95 : serializeRaw 4070 27 linear_r95 = some linear_b95 := by decide +kernel
theorem linear_p95 (tail : List Nat) : parseRaw 4070 27 (linear_b95 ++ tail) = some (linear_r95, tail) := by rfl
def linear_r96 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,48,57])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))]))])
def linear_b96 : List Nat := linear_g246
theorem linear_s96 : serializeRaw 4069 27 linear_r96 = some linear_b96 := by decide +kernel
theorem linear_p96 (tail : List Nat) : parseRaw 4069 27 (linear_b96 ++ tail) = some (linear_r96, tail) := by rfl
def linear_k92_0 : List Nat := [105,100]
theorem linear_kd92_0 : stringBytes linear_k92_0 = true := by decide +kernel
theorem linear_kp92_0 (tail : List Nat) : parseStringTail (linear_k92_0 ++ (34 :: 58 :: tail)) [] = some (linear_k92_0, 58 :: tail) := by rfl
def linear_k92_1 : List Nat := [111,112,115]
theorem linear_kd92_1 : stringBytes linear_k92_1 = true := by decide +kernel
theorem linear_kp92_1 (tail : List Nat) : parseStringTail (linear_k92_1 ++ (34 :: 58 :: tail)) [] = some (linear_k92_1, 58 :: tail) := by rfl
def linear_k92_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd92_2 : stringBytes linear_k92_2 = true := by decide +kernel
theorem linear_kp92_2 (tail : List Nat) : parseStringTail (linear_k92_2 ++ (34 :: 58 :: tail)) [] = some (linear_k92_2, 58 :: tail) := by rfl
def linear_k92_3 : List Nat := [116,101,114,109]
theorem linear_kd92_3 : stringBytes linear_k92_3 = true := by decide +kernel
theorem linear_kp92_3 (tail : List Nat) : parseStringTail (linear_k92_3 ++ (34 :: 58 :: tail)) [] = some (linear_k92_3, 58 :: tail) := by rfl
def linear_l92_3 : List (List Nat × Raw) := [(linear_k92_3, linear_r96)]
def linear_v92_3 : List Nat := linear_g245 ++ linear_b96
theorem linear_sl92_3 : serializeFields 4070 27 linear_l92_3 = some linear_v92_3 := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4069 27 linear_k92_3 linear_r96 linear_b96 linear_kd92_3 linear_s96)
theorem linear_pl92_3 (tail : List Nat) : parseFields 4070 27 (linear_v92_3 ++ (125 :: tail)) = some (linear_l92_3, tail) := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4069 27 (linear_k92_3 ++ (34 :: 58 :: (linear_b96 ++ (125 :: tail)))) linear_k92_3 (linear_b96 ++ (125 :: tail)) tail linear_r96 (linear_kp92_3 (linear_b96 ++ (125 :: tail))) (linear_p96 (125 :: tail)))
def linear_l92_2 : List (List Nat × Raw) := (linear_k92_2, linear_r95) :: linear_l92_3
def linear_v92_2 : List Nat := (linear_g242 ++ linear_b95) ++ (44 :: linear_v92_3)
theorem linear_sl92_2 : serializeFields 4071 27 linear_l92_2 = some linear_v92_2 := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k92_2 linear_r95 (linear_k92_3, linear_r96) [] linear_b95 linear_v92_3 linear_kd92_2 linear_s95 linear_sl92_3)
theorem linear_pl92_2 (tail : List Nat) : parseFields 4071 27 (linear_v92_2 ++ (125 :: tail)) = some (linear_l92_2, tail) := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k92_2 ++ (34 :: 58 :: (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))))) linear_k92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))) (linear_v92_3 ++ (125 :: tail)) tail linear_r95 linear_l92_3 (linear_kp92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail))))) (linear_p95 (44 :: (linear_v92_3 ++ (125 :: tail)))) (linear_pl92_3 tail))
def linear_l92_1 : List (List Nat × Raw) := (linear_k92_1, linear_r94) :: linear_l92_2
def linear_v92_1 : List Nat := (linear_g239 ++ linear_b94) ++ (44 :: linear_v92_2)
theorem linear_sl92_1 : serializeFields 4072 27 linear_l92_1 = some linear_v92_1 := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k92_1 linear_r94 (linear_k92_2, linear_r95) linear_l92_3 linear_b94 linear_v92_2 linear_kd92_1 linear_s94 linear_sl92_2)
theorem linear_pl92_1 (tail : List Nat) : parseFields 4072 27 (linear_v92_1 ++ (125 :: tail)) = some (linear_l92_1, tail) := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k92_1 ++ (34 :: 58 :: (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))))) linear_k92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))) (linear_v92_2 ++ (125 :: tail)) tail linear_r94 linear_l92_2 (linear_kp92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail))))) (linear_p94 (44 :: (linear_v92_2 ++ (125 :: tail)))) (linear_pl92_2 tail))
def linear_l92_0 : List (List Nat × Raw) := (linear_k92_0, linear_r93) :: linear_l92_1
def linear_v92_0 : List Nat := (linear_g236 ++ linear_b93) ++ (44 :: linear_v92_1)
theorem linear_sl92_0 : serializeFields 4073 27 linear_l92_0 = some linear_v92_0 := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k92_0 linear_r93 (linear_k92_1, linear_r94) linear_l92_2 linear_b93 linear_v92_1 linear_kd92_0 linear_s93 linear_sl92_1)
theorem linear_pl92_0 (tail : List Nat) : parseFields 4073 27 (linear_v92_0 ++ (125 :: tail)) = some (linear_l92_0, tail) := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) linear_k92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))) (linear_v92_1 ++ (125 :: tail)) tail linear_r93 linear_l92_1 (linear_kp92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail))))) (linear_p93 (44 :: (linear_v92_1 ++ (125 :: tail)))) (linear_pl92_1 tail))
def linear_r92 : Raw := (.obj linear_l92_0)
def linear_b92 : List Nat := linear_g235 ++ (linear_v92_0 ++ linear_g247)
theorem linear_o92 : orderedFields linear_l92_0 = true := by decide +kernel
theorem linear_s92 : serializeRaw 4074 28 linear_r92 = some linear_b92 := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4073 27 linear_l92_0 linear_v92_0 linear_o92 linear_sl92_0)
theorem linear_p92 (tail : List Nat) : parseRaw 4074 28 (linear_b92 ++ tail) = some (linear_r92, tail) := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4073 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) tail linear_l92_0 linear_o92 (by simpa only [linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl92_0 tail)))
def linear_r98 : Raw := (.str [100,103,95,115,108,111,119,95,49])
def linear_b98 : List Nat := linear_g251
theorem linear_s98 : serializeRaw 4071 27 linear_r98 = some linear_b98 := by decide +kernel
theorem linear_p98 (tail : List Nat) : parseRaw 4071 27 (linear_b98 ++ tail) = some (linear_r98, tail) := by rfl
def linear_r100 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,53])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b100 : List Nat := linear_g255
theorem linear_s100 : serializeRaw 4068 26 linear_r100 = some linear_b100 := by decide +kernel
theorem linear_p100 (tail : List Nat) : parseRaw 4068 26 (linear_b100 ++ tail) = some (linear_r100, tail) := by rfl
def linear_r101 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,53]),(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,54])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b101 : List Nat := linear_g257
theorem linear_s101 : serializeRaw 4067 26 linear_r101 = some linear_b101 := by decide +kernel
theorem linear_p101 (tail : List Nat) : parseRaw 4067 26 (linear_b101 ++ tail) = some (linear_r101, tail) := by rfl
def linear_r102 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b102 : List Nat := linear_g259
theorem linear_s102 : serializeRaw 4066 26 linear_r102 = some linear_b102 := by decide +kernel
theorem linear_p102 (tail : List Nat) : parseRaw 4066 26 (linear_b102 ++ tail) = some (linear_r102, tail) := by rfl
def linear_r103 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,56])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b103 : List Nat := linear_g261
theorem linear_s103 : serializeRaw 4065 26 linear_r103 = some linear_b103 := by decide +kernel
theorem linear_p103 (tail : List Nat) : parseRaw 4065 26 (linear_b103 ++ tail) = some (linear_r103, tail) := by rfl
def linear_r104 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,55]),(.str [100,103,95,118,95,49,49,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,57])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b104 : List Nat := linear_g263
theorem linear_s104 : serializeRaw 4064 26 linear_r104 = some linear_b104 := by decide +kernel
theorem linear_p104 (tail : List Nat) : parseRaw 4064 26 (linear_b104 ++ tail) = some (linear_r104, tail) := by rfl
def linear_r105 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,57])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,48])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b105 : List Nat := linear_g265
theorem linear_s105 : serializeRaw 4063 26 linear_r105 = some linear_b105 := by decide +kernel
theorem linear_p105 (tail : List Nat) : parseRaw 4063 26 (linear_b105 ++ tail) = some (linear_r105, tail) := by rfl
def linear_r106 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,49])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b106 : List Nat := linear_g267
theorem linear_s106 : serializeRaw 4062 26 linear_r106 = some linear_b106 := by decide +kernel
theorem linear_p106 (tail : List Nat) : parseRaw 4062 26 (linear_b106 ++ tail) = some (linear_r106, tail) := by rfl
def linear_r107 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49]),(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b107 : List Nat := linear_g269
theorem linear_s107 : serializeRaw 4061 26 linear_r107 = some linear_b107 := by decide +kernel
theorem linear_p107 (tail : List Nat) : parseRaw 4061 26 (linear_b107 ++ tail) = some (linear_r107, tail) := by rfl
def linear_r108 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b108 : List Nat := linear_g271
theorem linear_s108 : serializeRaw 4060 26 linear_r108 = some linear_b108 := by decide +kernel
theorem linear_p108 (tail : List Nat) : parseRaw 4060 26 (linear_b108 ++ tail) = some (linear_r108, tail) := by rfl
def linear_r109 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b109 : List Nat := linear_g273
theorem linear_s109 : serializeRaw 4059 26 linear_r109 = some linear_b109 := by decide +kernel
theorem linear_p109 (tail : List Nat) : parseRaw 4059 26 (linear_b109 ++ tail) = some (linear_r109, tail) := by rfl
def linear_r110 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b110 : List Nat := linear_g275
theorem linear_s110 : serializeRaw 4058 26 linear_r110 = some linear_b110 := by decide +kernel
theorem linear_p110 (tail : List Nat) : parseRaw 4058 26 (linear_b110 ++ tail) = some (linear_r110, tail) := by rfl
def linear_l99_10 : List Raw := [linear_r110]
def linear_v99_10 : List Nat := linear_b110
theorem linear_sl99_10 : serializeItems 4059 26 linear_l99_10 = some linear_v99_10 := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4058 26 linear_r110 linear_b110 linear_s110)
theorem linear_pl99_10 (tail : List Nat) : parseItems 4059 26 (linear_v99_10 ++ (93 :: tail)) = some (linear_l99_10, tail) := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4058 26 (linear_b110 ++ (93 :: tail)) tail linear_r110 (linear_p110 (93 :: tail)))
def linear_l99_9 : List Raw := linear_r109 :: linear_l99_10
def linear_v99_9 : List Nat := (linear_b109) ++ (44 :: linear_v99_10)
theorem linear_sl99_9 : serializeItems 4060 26 linear_l99_9 = some linear_v99_9 := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4059 26 linear_r109 linear_r110 [] linear_b109 linear_v99_10 linear_s109 linear_sl99_10)
theorem linear_pl99_9 (tail : List Nat) : parseItems 4060 26 (linear_v99_9 ++ (93 :: tail)) = some (linear_l99_9, tail) := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4059 26 (linear_b109 ++ (44 :: (linear_v99_10 ++ (93 :: tail)))) (linear_v99_10 ++ (93 :: tail)) tail linear_r109 linear_l99_10 (linear_p109 (44 :: (linear_v99_10 ++ (93 :: tail)))) (linear_pl99_10 tail))
def linear_l99_8 : List Raw := linear_r108 :: linear_l99_9
def linear_v99_8 : List Nat := (linear_b108) ++ (44 :: linear_v99_9)
theorem linear_sl99_8 : serializeItems 4061 26 linear_l99_8 = some linear_v99_8 := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r108 linear_r109 linear_l99_10 linear_b108 linear_v99_9 linear_s108 linear_sl99_9)
theorem linear_pl99_8 (tail : List Nat) : parseItems 4061 26 (linear_v99_8 ++ (93 :: tail)) = some (linear_l99_8, tail) := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b108 ++ (44 :: (linear_v99_9 ++ (93 :: tail)))) (linear_v99_9 ++ (93 :: tail)) tail linear_r108 linear_l99_9 (linear_p108 (44 :: (linear_v99_9 ++ (93 :: tail)))) (linear_pl99_9 tail))
def linear_l99_7 : List Raw := linear_r107 :: linear_l99_8
def linear_v99_7 : List Nat := (linear_b107) ++ (44 :: linear_v99_8)
theorem linear_sl99_7 : serializeItems 4062 26 linear_l99_7 = some linear_v99_7 := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r107 linear_r108 linear_l99_9 linear_b107 linear_v99_8 linear_s107 linear_sl99_8)
theorem linear_pl99_7 (tail : List Nat) : parseItems 4062 26 (linear_v99_7 ++ (93 :: tail)) = some (linear_l99_7, tail) := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b107 ++ (44 :: (linear_v99_8 ++ (93 :: tail)))) (linear_v99_8 ++ (93 :: tail)) tail linear_r107 linear_l99_8 (linear_p107 (44 :: (linear_v99_8 ++ (93 :: tail)))) (linear_pl99_8 tail))
def linear_l99_6 : List Raw := linear_r106 :: linear_l99_7
def linear_v99_6 : List Nat := (linear_b106) ++ (44 :: linear_v99_7)
theorem linear_sl99_6 : serializeItems 4063 26 linear_l99_6 = some linear_v99_6 := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r106 linear_r107 linear_l99_8 linear_b106 linear_v99_7 linear_s106 linear_sl99_7)
theorem linear_pl99_6 (tail : List Nat) : parseItems 4063 26 (linear_v99_6 ++ (93 :: tail)) = some (linear_l99_6, tail) := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b106 ++ (44 :: (linear_v99_7 ++ (93 :: tail)))) (linear_v99_7 ++ (93 :: tail)) tail linear_r106 linear_l99_7 (linear_p106 (44 :: (linear_v99_7 ++ (93 :: tail)))) (linear_pl99_7 tail))
def linear_l99_5 : List Raw := linear_r105 :: linear_l99_6
def linear_v99_5 : List Nat := (linear_b105) ++ (44 :: linear_v99_6)
theorem linear_sl99_5 : serializeItems 4064 26 linear_l99_5 = some linear_v99_5 := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r105 linear_r106 linear_l99_7 linear_b105 linear_v99_6 linear_s105 linear_sl99_6)
theorem linear_pl99_5 (tail : List Nat) : parseItems 4064 26 (linear_v99_5 ++ (93 :: tail)) = some (linear_l99_5, tail) := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b105 ++ (44 :: (linear_v99_6 ++ (93 :: tail)))) (linear_v99_6 ++ (93 :: tail)) tail linear_r105 linear_l99_6 (linear_p105 (44 :: (linear_v99_6 ++ (93 :: tail)))) (linear_pl99_6 tail))
def linear_l99_4 : List Raw := linear_r104 :: linear_l99_5
def linear_v99_4 : List Nat := (linear_b104) ++ (44 :: linear_v99_5)
theorem linear_sl99_4 : serializeItems 4065 26 linear_l99_4 = some linear_v99_4 := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r104 linear_r105 linear_l99_6 linear_b104 linear_v99_5 linear_s104 linear_sl99_5)
theorem linear_pl99_4 (tail : List Nat) : parseItems 4065 26 (linear_v99_4 ++ (93 :: tail)) = some (linear_l99_4, tail) := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b104 ++ (44 :: (linear_v99_5 ++ (93 :: tail)))) (linear_v99_5 ++ (93 :: tail)) tail linear_r104 linear_l99_5 (linear_p104 (44 :: (linear_v99_5 ++ (93 :: tail)))) (linear_pl99_5 tail))
def linear_l99_3 : List Raw := linear_r103 :: linear_l99_4
def linear_v99_3 : List Nat := (linear_b103) ++ (44 :: linear_v99_4)
theorem linear_sl99_3 : serializeItems 4066 26 linear_l99_3 = some linear_v99_3 := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r103 linear_r104 linear_l99_5 linear_b103 linear_v99_4 linear_s103 linear_sl99_4)
theorem linear_pl99_3 (tail : List Nat) : parseItems 4066 26 (linear_v99_3 ++ (93 :: tail)) = some (linear_l99_3, tail) := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b103 ++ (44 :: (linear_v99_4 ++ (93 :: tail)))) (linear_v99_4 ++ (93 :: tail)) tail linear_r103 linear_l99_4 (linear_p103 (44 :: (linear_v99_4 ++ (93 :: tail)))) (linear_pl99_4 tail))
def linear_l99_2 : List Raw := linear_r102 :: linear_l99_3
def linear_v99_2 : List Nat := (linear_b102) ++ (44 :: linear_v99_3)
theorem linear_sl99_2 : serializeItems 4067 26 linear_l99_2 = some linear_v99_2 := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r102 linear_r103 linear_l99_4 linear_b102 linear_v99_3 linear_s102 linear_sl99_3)
theorem linear_pl99_2 (tail : List Nat) : parseItems 4067 26 (linear_v99_2 ++ (93 :: tail)) = some (linear_l99_2, tail) := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b102 ++ (44 :: (linear_v99_3 ++ (93 :: tail)))) (linear_v99_3 ++ (93 :: tail)) tail linear_r102 linear_l99_3 (linear_p102 (44 :: (linear_v99_3 ++ (93 :: tail)))) (linear_pl99_3 tail))
def linear_l99_1 : List Raw := linear_r101 :: linear_l99_2
def linear_v99_1 : List Nat := (linear_b101) ++ (44 :: linear_v99_2)
theorem linear_sl99_1 : serializeItems 4068 26 linear_l99_1 = some linear_v99_1 := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r101 linear_r102 linear_l99_3 linear_b101 linear_v99_2 linear_s101 linear_sl99_2)
theorem linear_pl99_1 (tail : List Nat) : parseItems 4068 26 (linear_v99_1 ++ (93 :: tail)) = some (linear_l99_1, tail) := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b101 ++ (44 :: (linear_v99_2 ++ (93 :: tail)))) (linear_v99_2 ++ (93 :: tail)) tail linear_r101 linear_l99_2 (linear_p101 (44 :: (linear_v99_2 ++ (93 :: tail)))) (linear_pl99_2 tail))
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.linear_kd10_0
#print axioms HiaCoreSyntaxSlice.linear_kd10_1
#print axioms HiaCoreSyntaxSlice.linear_kd10_2
#print axioms HiaCoreSyntaxSlice.linear_kd10_3
#print axioms HiaCoreSyntaxSlice.linear_kd15_0
#print axioms HiaCoreSyntaxSlice.linear_kd15_1
#print axioms HiaCoreSyntaxSlice.linear_kd15_2
#print axioms HiaCoreSyntaxSlice.linear_kd15_3
#print axioms HiaCoreSyntaxSlice.linear_kd24_0
#print axioms HiaCoreSyntaxSlice.linear_kd24_1
#print axioms HiaCoreSyntaxSlice.linear_kd24_2
#print axioms HiaCoreSyntaxSlice.linear_kd24_3
#print axioms HiaCoreSyntaxSlice.linear_kd29_0
#print axioms HiaCoreSyntaxSlice.linear_kd29_1
#print axioms HiaCoreSyntaxSlice.linear_kd29_2
#print axioms HiaCoreSyntaxSlice.linear_kd29_3
#print axioms HiaCoreSyntaxSlice.linear_kd34_0
#print axioms HiaCoreSyntaxSlice.linear_kd34_1
#print axioms HiaCoreSyntaxSlice.linear_kd34_2
#print axioms HiaCoreSyntaxSlice.linear_kd34_3
#print axioms HiaCoreSyntaxSlice.linear_kd39_0
#print axioms HiaCoreSyntaxSlice.linear_kd39_1
#print axioms HiaCoreSyntaxSlice.linear_kd39_2
#print axioms HiaCoreSyntaxSlice.linear_kd39_3
#print axioms HiaCoreSyntaxSlice.linear_kd44_0
#print axioms HiaCoreSyntaxSlice.linear_kd44_1
#print axioms HiaCoreSyntaxSlice.linear_kd44_2
#print axioms HiaCoreSyntaxSlice.linear_kd44_3
#print axioms HiaCoreSyntaxSlice.linear_kd49_0
#print axioms HiaCoreSyntaxSlice.linear_kd49_1
#print axioms HiaCoreSyntaxSlice.linear_kd49_2
#print axioms HiaCoreSyntaxSlice.linear_kd49_3
#print axioms HiaCoreSyntaxSlice.linear_kd5_0
#print axioms HiaCoreSyntaxSlice.linear_kd5_1
#print axioms HiaCoreSyntaxSlice.linear_kd5_2
#print axioms HiaCoreSyntaxSlice.linear_kd5_3
#print axioms HiaCoreSyntaxSlice.linear_kd65_0
#print axioms HiaCoreSyntaxSlice.linear_kd65_1
#print axioms HiaCoreSyntaxSlice.linear_kd65_2
#print axioms HiaCoreSyntaxSlice.linear_kd65_3
#print axioms HiaCoreSyntaxSlice.linear_kd70_0
#print axioms HiaCoreSyntaxSlice.linear_kd70_1
#print axioms HiaCoreSyntaxSlice.linear_kd70_2
#print axioms HiaCoreSyntaxSlice.linear_kd70_3
#print axioms HiaCoreSyntaxSlice.linear_kd75_0
#print axioms HiaCoreSyntaxSlice.linear_kd75_1
#print axioms HiaCoreSyntaxSlice.linear_kd75_2
#print axioms HiaCoreSyntaxSlice.linear_kd75_3
#print axioms HiaCoreSyntaxSlice.linear_kd87_0
#print axioms HiaCoreSyntaxSlice.linear_kd87_1
#print axioms HiaCoreSyntaxSlice.linear_kd87_2
#print axioms HiaCoreSyntaxSlice.linear_kd87_3
#print axioms HiaCoreSyntaxSlice.linear_kd92_0
#print axioms HiaCoreSyntaxSlice.linear_kd92_1
#print axioms HiaCoreSyntaxSlice.linear_kd92_2
#print axioms HiaCoreSyntaxSlice.linear_kd92_3
#print axioms HiaCoreSyntaxSlice.linear_kp10_0
#print axioms HiaCoreSyntaxSlice.linear_kp10_1
#print axioms HiaCoreSyntaxSlice.linear_kp10_2
#print axioms HiaCoreSyntaxSlice.linear_kp10_3
#print axioms HiaCoreSyntaxSlice.linear_kp15_0
#print axioms HiaCoreSyntaxSlice.linear_kp15_1
#print axioms HiaCoreSyntaxSlice.linear_kp15_2
#print axioms HiaCoreSyntaxSlice.linear_kp15_3
#print axioms HiaCoreSyntaxSlice.linear_kp24_0
#print axioms HiaCoreSyntaxSlice.linear_kp24_1
#print axioms HiaCoreSyntaxSlice.linear_kp24_2
#print axioms HiaCoreSyntaxSlice.linear_kp24_3
#print axioms HiaCoreSyntaxSlice.linear_kp29_0
#print axioms HiaCoreSyntaxSlice.linear_kp29_1
#print axioms HiaCoreSyntaxSlice.linear_kp29_2
#print axioms HiaCoreSyntaxSlice.linear_kp29_3
#print axioms HiaCoreSyntaxSlice.linear_kp34_0
#print axioms HiaCoreSyntaxSlice.linear_kp34_1
#print axioms HiaCoreSyntaxSlice.linear_kp34_2
#print axioms HiaCoreSyntaxSlice.linear_kp34_3
#print axioms HiaCoreSyntaxSlice.linear_kp39_0
#print axioms HiaCoreSyntaxSlice.linear_kp39_1
#print axioms HiaCoreSyntaxSlice.linear_kp39_2
#print axioms HiaCoreSyntaxSlice.linear_kp39_3
#print axioms HiaCoreSyntaxSlice.linear_kp44_0
#print axioms HiaCoreSyntaxSlice.linear_kp44_1
#print axioms HiaCoreSyntaxSlice.linear_kp44_2
#print axioms HiaCoreSyntaxSlice.linear_kp44_3
#print axioms HiaCoreSyntaxSlice.linear_kp49_0
#print axioms HiaCoreSyntaxSlice.linear_kp49_1
#print axioms HiaCoreSyntaxSlice.linear_kp49_2
#print axioms HiaCoreSyntaxSlice.linear_kp49_3
#print axioms HiaCoreSyntaxSlice.linear_kp5_0
#print axioms HiaCoreSyntaxSlice.linear_kp5_1
#print axioms HiaCoreSyntaxSlice.linear_kp5_2
#print axioms HiaCoreSyntaxSlice.linear_kp5_3
#print axioms HiaCoreSyntaxSlice.linear_kp65_0
#print axioms HiaCoreSyntaxSlice.linear_kp65_1
#print axioms HiaCoreSyntaxSlice.linear_kp65_2
#print axioms HiaCoreSyntaxSlice.linear_kp65_3
#print axioms HiaCoreSyntaxSlice.linear_kp70_0
#print axioms HiaCoreSyntaxSlice.linear_kp70_1
#print axioms HiaCoreSyntaxSlice.linear_kp70_2
#print axioms HiaCoreSyntaxSlice.linear_kp70_3
#print axioms HiaCoreSyntaxSlice.linear_kp75_0
#print axioms HiaCoreSyntaxSlice.linear_kp75_1
#print axioms HiaCoreSyntaxSlice.linear_kp75_2
#print axioms HiaCoreSyntaxSlice.linear_kp75_3
#print axioms HiaCoreSyntaxSlice.linear_kp87_0
#print axioms HiaCoreSyntaxSlice.linear_kp87_1
#print axioms HiaCoreSyntaxSlice.linear_kp87_2
#print axioms HiaCoreSyntaxSlice.linear_kp87_3
#print axioms HiaCoreSyntaxSlice.linear_kp92_0
#print axioms HiaCoreSyntaxSlice.linear_kp92_1
#print axioms HiaCoreSyntaxSlice.linear_kp92_2
#print axioms HiaCoreSyntaxSlice.linear_kp92_3
#print axioms HiaCoreSyntaxSlice.linear_o10
#print axioms HiaCoreSyntaxSlice.linear_o15
#print axioms HiaCoreSyntaxSlice.linear_o24
#print axioms HiaCoreSyntaxSlice.linear_o29
#print axioms HiaCoreSyntaxSlice.linear_o34
#print axioms HiaCoreSyntaxSlice.linear_o39
#print axioms HiaCoreSyntaxSlice.linear_o44
#print axioms HiaCoreSyntaxSlice.linear_o49
#print axioms HiaCoreSyntaxSlice.linear_o5
#print axioms HiaCoreSyntaxSlice.linear_o65
#print axioms HiaCoreSyntaxSlice.linear_o70
#print axioms HiaCoreSyntaxSlice.linear_o75
#print axioms HiaCoreSyntaxSlice.linear_o87
#print axioms HiaCoreSyntaxSlice.linear_o92
#print axioms HiaCoreSyntaxSlice.linear_p1
#print axioms HiaCoreSyntaxSlice.linear_p10
#print axioms HiaCoreSyntaxSlice.linear_p100
#print axioms HiaCoreSyntaxSlice.linear_p101
#print axioms HiaCoreSyntaxSlice.linear_p102
#print axioms HiaCoreSyntaxSlice.linear_p103
#print axioms HiaCoreSyntaxSlice.linear_p104
#print axioms HiaCoreSyntaxSlice.linear_p105
#print axioms HiaCoreSyntaxSlice.linear_p106
#print axioms HiaCoreSyntaxSlice.linear_p107
#print axioms HiaCoreSyntaxSlice.linear_p108
#print axioms HiaCoreSyntaxSlice.linear_p109
#print axioms HiaCoreSyntaxSlice.linear_p11
#print axioms HiaCoreSyntaxSlice.linear_p110
#print axioms HiaCoreSyntaxSlice.linear_p12
#print axioms HiaCoreSyntaxSlice.linear_p13
#print axioms HiaCoreSyntaxSlice.linear_p14
#print axioms HiaCoreSyntaxSlice.linear_p15
#print axioms HiaCoreSyntaxSlice.linear_p16
#print axioms HiaCoreSyntaxSlice.linear_p17
#print axioms HiaCoreSyntaxSlice.linear_p18
#print axioms HiaCoreSyntaxSlice.linear_p19
#print axioms HiaCoreSyntaxSlice.linear_p20
#print axioms HiaCoreSyntaxSlice.linear_p21
#print axioms HiaCoreSyntaxSlice.linear_p22
#print axioms HiaCoreSyntaxSlice.linear_p23
#print axioms HiaCoreSyntaxSlice.linear_p24
#print axioms HiaCoreSyntaxSlice.linear_p25
#print axioms HiaCoreSyntaxSlice.linear_p26
#print axioms HiaCoreSyntaxSlice.linear_p27
#print axioms HiaCoreSyntaxSlice.linear_p28
#print axioms HiaCoreSyntaxSlice.linear_p29
#print axioms HiaCoreSyntaxSlice.linear_p30
#print axioms HiaCoreSyntaxSlice.linear_p31
#print axioms HiaCoreSyntaxSlice.linear_p32
#print axioms HiaCoreSyntaxSlice.linear_p33
#print axioms HiaCoreSyntaxSlice.linear_p34
#print axioms HiaCoreSyntaxSlice.linear_p35
#print axioms HiaCoreSyntaxSlice.linear_p36
#print axioms HiaCoreSyntaxSlice.linear_p37
#print axioms HiaCoreSyntaxSlice.linear_p38
#print axioms HiaCoreSyntaxSlice.linear_p39
#print axioms HiaCoreSyntaxSlice.linear_p40
#print axioms HiaCoreSyntaxSlice.linear_p41
#print axioms HiaCoreSyntaxSlice.linear_p42
#print axioms HiaCoreSyntaxSlice.linear_p43
#print axioms HiaCoreSyntaxSlice.linear_p44
#print axioms HiaCoreSyntaxSlice.linear_p45
#print axioms HiaCoreSyntaxSlice.linear_p46
#print axioms HiaCoreSyntaxSlice.linear_p47
#print axioms HiaCoreSyntaxSlice.linear_p48
#print axioms HiaCoreSyntaxSlice.linear_p49
#print axioms HiaCoreSyntaxSlice.linear_p5
#print axioms HiaCoreSyntaxSlice.linear_p50
#print axioms HiaCoreSyntaxSlice.linear_p51
#print axioms HiaCoreSyntaxSlice.linear_p52
#print axioms HiaCoreSyntaxSlice.linear_p53
#print axioms HiaCoreSyntaxSlice.linear_p54
#print axioms HiaCoreSyntaxSlice.linear_p55
#print axioms HiaCoreSyntaxSlice.linear_p56
#print axioms HiaCoreSyntaxSlice.linear_p57
#print axioms HiaCoreSyntaxSlice.linear_p58
#print axioms HiaCoreSyntaxSlice.linear_p59
#print axioms HiaCoreSyntaxSlice.linear_p6
#print axioms HiaCoreSyntaxSlice.linear_p60
#print axioms HiaCoreSyntaxSlice.linear_p61
#print axioms HiaCoreSyntaxSlice.linear_p62
#print axioms HiaCoreSyntaxSlice.linear_p63
#print axioms HiaCoreSyntaxSlice.linear_p64
#print axioms HiaCoreSyntaxSlice.linear_p65
#print axioms HiaCoreSyntaxSlice.linear_p66
#print axioms HiaCoreSyntaxSlice.linear_p67
#print axioms HiaCoreSyntaxSlice.linear_p68
#print axioms HiaCoreSyntaxSlice.linear_p69
#print axioms HiaCoreSyntaxSlice.linear_p7
#print axioms HiaCoreSyntaxSlice.linear_p70
#print axioms HiaCoreSyntaxSlice.linear_p71
#print axioms HiaCoreSyntaxSlice.linear_p72
#print axioms HiaCoreSyntaxSlice.linear_p73
#print axioms HiaCoreSyntaxSlice.linear_p74
#print axioms HiaCoreSyntaxSlice.linear_p75
#print axioms HiaCoreSyntaxSlice.linear_p76
#print axioms HiaCoreSyntaxSlice.linear_p77
#print axioms HiaCoreSyntaxSlice.linear_p78
#print axioms HiaCoreSyntaxSlice.linear_p79
#print axioms HiaCoreSyntaxSlice.linear_p8
#print axioms HiaCoreSyntaxSlice.linear_p80
#print axioms HiaCoreSyntaxSlice.linear_p81
#print axioms HiaCoreSyntaxSlice.linear_p82
#print axioms HiaCoreSyntaxSlice.linear_p83
#print axioms HiaCoreSyntaxSlice.linear_p84
#print axioms HiaCoreSyntaxSlice.linear_p85
#print axioms HiaCoreSyntaxSlice.linear_p86
#print axioms HiaCoreSyntaxSlice.linear_p87
#print axioms HiaCoreSyntaxSlice.linear_p88
#print axioms HiaCoreSyntaxSlice.linear_p89
#print axioms HiaCoreSyntaxSlice.linear_p9
#print axioms HiaCoreSyntaxSlice.linear_p90
#print axioms HiaCoreSyntaxSlice.linear_p91
#print axioms HiaCoreSyntaxSlice.linear_p92
#print axioms HiaCoreSyntaxSlice.linear_p93
#print axioms HiaCoreSyntaxSlice.linear_p94
#print axioms HiaCoreSyntaxSlice.linear_p95
#print axioms HiaCoreSyntaxSlice.linear_p96
#print axioms HiaCoreSyntaxSlice.linear_p98
#print axioms HiaCoreSyntaxSlice.linear_pl10_0
#print axioms HiaCoreSyntaxSlice.linear_pl10_1
#print axioms HiaCoreSyntaxSlice.linear_pl10_2
#print axioms HiaCoreSyntaxSlice.linear_pl10_3
#print axioms HiaCoreSyntaxSlice.linear_pl15_0
#print axioms HiaCoreSyntaxSlice.linear_pl15_1
#print axioms HiaCoreSyntaxSlice.linear_pl15_2
#print axioms HiaCoreSyntaxSlice.linear_pl15_3
#print axioms HiaCoreSyntaxSlice.linear_pl17_0
#print axioms HiaCoreSyntaxSlice.linear_pl17_1
#print axioms HiaCoreSyntaxSlice.linear_pl17_2
#print axioms HiaCoreSyntaxSlice.linear_pl17_3
#print axioms HiaCoreSyntaxSlice.linear_pl24_0
#print axioms HiaCoreSyntaxSlice.linear_pl24_1
#print axioms HiaCoreSyntaxSlice.linear_pl24_2
#print axioms HiaCoreSyntaxSlice.linear_pl24_3
#print axioms HiaCoreSyntaxSlice.linear_pl29_0
#print axioms HiaCoreSyntaxSlice.linear_pl29_1
#print axioms HiaCoreSyntaxSlice.linear_pl29_2
#print axioms HiaCoreSyntaxSlice.linear_pl29_3
#print axioms HiaCoreSyntaxSlice.linear_pl34_0
#print axioms HiaCoreSyntaxSlice.linear_pl34_1
#print axioms HiaCoreSyntaxSlice.linear_pl34_2
#print axioms HiaCoreSyntaxSlice.linear_pl34_3
#print axioms HiaCoreSyntaxSlice.linear_pl39_0
#print axioms HiaCoreSyntaxSlice.linear_pl39_1
#print axioms HiaCoreSyntaxSlice.linear_pl39_2
#print axioms HiaCoreSyntaxSlice.linear_pl39_3
#print axioms HiaCoreSyntaxSlice.linear_pl44_0
#print axioms HiaCoreSyntaxSlice.linear_pl44_1
#print axioms HiaCoreSyntaxSlice.linear_pl44_2
#print axioms HiaCoreSyntaxSlice.linear_pl44_3
#print axioms HiaCoreSyntaxSlice.linear_pl49_0
#print axioms HiaCoreSyntaxSlice.linear_pl49_1
#print axioms HiaCoreSyntaxSlice.linear_pl49_2
#print axioms HiaCoreSyntaxSlice.linear_pl49_3
#print axioms HiaCoreSyntaxSlice.linear_pl51_0
#print axioms HiaCoreSyntaxSlice.linear_pl51_1
#print axioms HiaCoreSyntaxSlice.linear_pl51_10
#print axioms HiaCoreSyntaxSlice.linear_pl51_2
#print axioms HiaCoreSyntaxSlice.linear_pl51_3
#print axioms HiaCoreSyntaxSlice.linear_pl51_4
#print axioms HiaCoreSyntaxSlice.linear_pl51_5
#print axioms HiaCoreSyntaxSlice.linear_pl51_6
#print axioms HiaCoreSyntaxSlice.linear_pl51_7
#print axioms HiaCoreSyntaxSlice.linear_pl51_8
#print axioms HiaCoreSyntaxSlice.linear_pl51_9
#print axioms HiaCoreSyntaxSlice.linear_pl5_0
#print axioms HiaCoreSyntaxSlice.linear_pl5_1
#print axioms HiaCoreSyntaxSlice.linear_pl5_2
#print axioms HiaCoreSyntaxSlice.linear_pl5_3
#print axioms HiaCoreSyntaxSlice.linear_pl65_0
#print axioms HiaCoreSyntaxSlice.linear_pl65_1
#print axioms HiaCoreSyntaxSlice.linear_pl65_2
#print axioms HiaCoreSyntaxSlice.linear_pl65_3
#print axioms HiaCoreSyntaxSlice.linear_pl70_0
#print axioms HiaCoreSyntaxSlice.linear_pl70_1
#print axioms HiaCoreSyntaxSlice.linear_pl70_2
#print axioms HiaCoreSyntaxSlice.linear_pl70_3
#print axioms HiaCoreSyntaxSlice.linear_pl75_0
#print axioms HiaCoreSyntaxSlice.linear_pl75_1
#print axioms HiaCoreSyntaxSlice.linear_pl75_2
#print axioms HiaCoreSyntaxSlice.linear_pl75_3
#print axioms HiaCoreSyntaxSlice.linear_pl77_0
#print axioms HiaCoreSyntaxSlice.linear_pl77_1
#print axioms HiaCoreSyntaxSlice.linear_pl77_2
#print axioms HiaCoreSyntaxSlice.linear_pl77_3
#print axioms HiaCoreSyntaxSlice.linear_pl77_4
#print axioms HiaCoreSyntaxSlice.linear_pl77_5
#print axioms HiaCoreSyntaxSlice.linear_pl77_6
#print axioms HiaCoreSyntaxSlice.linear_pl87_0
#print axioms HiaCoreSyntaxSlice.linear_pl87_1
#print axioms HiaCoreSyntaxSlice.linear_pl87_2
#print axioms HiaCoreSyntaxSlice.linear_pl87_3
#print axioms HiaCoreSyntaxSlice.linear_pl92_0
#print axioms HiaCoreSyntaxSlice.linear_pl92_1
#print axioms HiaCoreSyntaxSlice.linear_pl92_2
#print axioms HiaCoreSyntaxSlice.linear_pl92_3
#print axioms HiaCoreSyntaxSlice.linear_pl99_1
#print axioms HiaCoreSyntaxSlice.linear_pl99_10
#print axioms HiaCoreSyntaxSlice.linear_pl99_2
#print axioms HiaCoreSyntaxSlice.linear_pl99_3
#print axioms HiaCoreSyntaxSlice.linear_pl99_4
#print axioms HiaCoreSyntaxSlice.linear_pl99_5
#print axioms HiaCoreSyntaxSlice.linear_pl99_6
#print axioms HiaCoreSyntaxSlice.linear_pl99_7
#print axioms HiaCoreSyntaxSlice.linear_pl99_8
#print axioms HiaCoreSyntaxSlice.linear_pl99_9
#print axioms HiaCoreSyntaxSlice.linear_s1
#print axioms HiaCoreSyntaxSlice.linear_s10
#print axioms HiaCoreSyntaxSlice.linear_s100
#print axioms HiaCoreSyntaxSlice.linear_s101
#print axioms HiaCoreSyntaxSlice.linear_s102
#print axioms HiaCoreSyntaxSlice.linear_s103
#print axioms HiaCoreSyntaxSlice.linear_s104
#print axioms HiaCoreSyntaxSlice.linear_s105
#print axioms HiaCoreSyntaxSlice.linear_s106
#print axioms HiaCoreSyntaxSlice.linear_s107
#print axioms HiaCoreSyntaxSlice.linear_s108
#print axioms HiaCoreSyntaxSlice.linear_s109
#print axioms HiaCoreSyntaxSlice.linear_s11
#print axioms HiaCoreSyntaxSlice.linear_s110
#print axioms HiaCoreSyntaxSlice.linear_s12
#print axioms HiaCoreSyntaxSlice.linear_s13
#print axioms HiaCoreSyntaxSlice.linear_s14
#print axioms HiaCoreSyntaxSlice.linear_s15
#print axioms HiaCoreSyntaxSlice.linear_s16
#print axioms HiaCoreSyntaxSlice.linear_s17
#print axioms HiaCoreSyntaxSlice.linear_s18
#print axioms HiaCoreSyntaxSlice.linear_s19
#print axioms HiaCoreSyntaxSlice.linear_s20
#print axioms HiaCoreSyntaxSlice.linear_s21
#print axioms HiaCoreSyntaxSlice.linear_s22
#print axioms HiaCoreSyntaxSlice.linear_s23
#print axioms HiaCoreSyntaxSlice.linear_s24
#print axioms HiaCoreSyntaxSlice.linear_s25
#print axioms HiaCoreSyntaxSlice.linear_s26
#print axioms HiaCoreSyntaxSlice.linear_s27
#print axioms HiaCoreSyntaxSlice.linear_s28
#print axioms HiaCoreSyntaxSlice.linear_s29
#print axioms HiaCoreSyntaxSlice.linear_s30
#print axioms HiaCoreSyntaxSlice.linear_s31
#print axioms HiaCoreSyntaxSlice.linear_s32
#print axioms HiaCoreSyntaxSlice.linear_s33
#print axioms HiaCoreSyntaxSlice.linear_s34
#print axioms HiaCoreSyntaxSlice.linear_s35
#print axioms HiaCoreSyntaxSlice.linear_s36
#print axioms HiaCoreSyntaxSlice.linear_s37
#print axioms HiaCoreSyntaxSlice.linear_s38
#print axioms HiaCoreSyntaxSlice.linear_s39
#print axioms HiaCoreSyntaxSlice.linear_s40
#print axioms HiaCoreSyntaxSlice.linear_s41
#print axioms HiaCoreSyntaxSlice.linear_s42
#print axioms HiaCoreSyntaxSlice.linear_s43
#print axioms HiaCoreSyntaxSlice.linear_s44
#print axioms HiaCoreSyntaxSlice.linear_s45
#print axioms HiaCoreSyntaxSlice.linear_s46
#print axioms HiaCoreSyntaxSlice.linear_s47
#print axioms HiaCoreSyntaxSlice.linear_s48
#print axioms HiaCoreSyntaxSlice.linear_s49
#print axioms HiaCoreSyntaxSlice.linear_s5
#print axioms HiaCoreSyntaxSlice.linear_s50
#print axioms HiaCoreSyntaxSlice.linear_s51
#print axioms HiaCoreSyntaxSlice.linear_s52
#print axioms HiaCoreSyntaxSlice.linear_s53
#print axioms HiaCoreSyntaxSlice.linear_s54
#print axioms HiaCoreSyntaxSlice.linear_s55
#print axioms HiaCoreSyntaxSlice.linear_s56
#print axioms HiaCoreSyntaxSlice.linear_s57
#print axioms HiaCoreSyntaxSlice.linear_s58
#print axioms HiaCoreSyntaxSlice.linear_s59
#print axioms HiaCoreSyntaxSlice.linear_s6
#print axioms HiaCoreSyntaxSlice.linear_s60
#print axioms HiaCoreSyntaxSlice.linear_s61
#print axioms HiaCoreSyntaxSlice.linear_s62
#print axioms HiaCoreSyntaxSlice.linear_s63
#print axioms HiaCoreSyntaxSlice.linear_s64
#print axioms HiaCoreSyntaxSlice.linear_s65
#print axioms HiaCoreSyntaxSlice.linear_s66
#print axioms HiaCoreSyntaxSlice.linear_s67
#print axioms HiaCoreSyntaxSlice.linear_s68
#print axioms HiaCoreSyntaxSlice.linear_s69
#print axioms HiaCoreSyntaxSlice.linear_s7
#print axioms HiaCoreSyntaxSlice.linear_s70
#print axioms HiaCoreSyntaxSlice.linear_s71
#print axioms HiaCoreSyntaxSlice.linear_s72
#print axioms HiaCoreSyntaxSlice.linear_s73
#print axioms HiaCoreSyntaxSlice.linear_s74
#print axioms HiaCoreSyntaxSlice.linear_s75
#print axioms HiaCoreSyntaxSlice.linear_s76
#print axioms HiaCoreSyntaxSlice.linear_s77
#print axioms HiaCoreSyntaxSlice.linear_s78
#print axioms HiaCoreSyntaxSlice.linear_s79
#print axioms HiaCoreSyntaxSlice.linear_s8
#print axioms HiaCoreSyntaxSlice.linear_s80
#print axioms HiaCoreSyntaxSlice.linear_s81
#print axioms HiaCoreSyntaxSlice.linear_s82
#print axioms HiaCoreSyntaxSlice.linear_s83
#print axioms HiaCoreSyntaxSlice.linear_s84
#print axioms HiaCoreSyntaxSlice.linear_s85
#print axioms HiaCoreSyntaxSlice.linear_s86
#print axioms HiaCoreSyntaxSlice.linear_s87
#print axioms HiaCoreSyntaxSlice.linear_s88
#print axioms HiaCoreSyntaxSlice.linear_s89
#print axioms HiaCoreSyntaxSlice.linear_s9
#print axioms HiaCoreSyntaxSlice.linear_s90
#print axioms HiaCoreSyntaxSlice.linear_s91
#print axioms HiaCoreSyntaxSlice.linear_s92
#print axioms HiaCoreSyntaxSlice.linear_s93
#print axioms HiaCoreSyntaxSlice.linear_s94
#print axioms HiaCoreSyntaxSlice.linear_s95
#print axioms HiaCoreSyntaxSlice.linear_s96
#print axioms HiaCoreSyntaxSlice.linear_s98
#print axioms HiaCoreSyntaxSlice.linear_sl10_0
#print axioms HiaCoreSyntaxSlice.linear_sl10_1
#print axioms HiaCoreSyntaxSlice.linear_sl10_2
#print axioms HiaCoreSyntaxSlice.linear_sl10_3
#print axioms HiaCoreSyntaxSlice.linear_sl15_0
#print axioms HiaCoreSyntaxSlice.linear_sl15_1
#print axioms HiaCoreSyntaxSlice.linear_sl15_2
#print axioms HiaCoreSyntaxSlice.linear_sl15_3
#print axioms HiaCoreSyntaxSlice.linear_sl17_0
#print axioms HiaCoreSyntaxSlice.linear_sl17_1
#print axioms HiaCoreSyntaxSlice.linear_sl17_2
#print axioms HiaCoreSyntaxSlice.linear_sl17_3
#print axioms HiaCoreSyntaxSlice.linear_sl24_0
#print axioms HiaCoreSyntaxSlice.linear_sl24_1
#print axioms HiaCoreSyntaxSlice.linear_sl24_2
#print axioms HiaCoreSyntaxSlice.linear_sl24_3
#print axioms HiaCoreSyntaxSlice.linear_sl29_0
#print axioms HiaCoreSyntaxSlice.linear_sl29_1
#print axioms HiaCoreSyntaxSlice.linear_sl29_2
#print axioms HiaCoreSyntaxSlice.linear_sl29_3
#print axioms HiaCoreSyntaxSlice.linear_sl34_0
#print axioms HiaCoreSyntaxSlice.linear_sl34_1
#print axioms HiaCoreSyntaxSlice.linear_sl34_2
#print axioms HiaCoreSyntaxSlice.linear_sl34_3
#print axioms HiaCoreSyntaxSlice.linear_sl39_0
#print axioms HiaCoreSyntaxSlice.linear_sl39_1
#print axioms HiaCoreSyntaxSlice.linear_sl39_2
#print axioms HiaCoreSyntaxSlice.linear_sl39_3
#print axioms HiaCoreSyntaxSlice.linear_sl44_0
#print axioms HiaCoreSyntaxSlice.linear_sl44_1
#print axioms HiaCoreSyntaxSlice.linear_sl44_2
#print axioms HiaCoreSyntaxSlice.linear_sl44_3
#print axioms HiaCoreSyntaxSlice.linear_sl49_0
#print axioms HiaCoreSyntaxSlice.linear_sl49_1
#print axioms HiaCoreSyntaxSlice.linear_sl49_2
#print axioms HiaCoreSyntaxSlice.linear_sl49_3
#print axioms HiaCoreSyntaxSlice.linear_sl51_0
#print axioms HiaCoreSyntaxSlice.linear_sl51_1
#print axioms HiaCoreSyntaxSlice.linear_sl51_10
#print axioms HiaCoreSyntaxSlice.linear_sl51_2
#print axioms HiaCoreSyntaxSlice.linear_sl51_3
#print axioms HiaCoreSyntaxSlice.linear_sl51_4
#print axioms HiaCoreSyntaxSlice.linear_sl51_5
#print axioms HiaCoreSyntaxSlice.linear_sl51_6
#print axioms HiaCoreSyntaxSlice.linear_sl51_7
#print axioms HiaCoreSyntaxSlice.linear_sl51_8
#print axioms HiaCoreSyntaxSlice.linear_sl51_9
#print axioms HiaCoreSyntaxSlice.linear_sl5_0
#print axioms HiaCoreSyntaxSlice.linear_sl5_1
#print axioms HiaCoreSyntaxSlice.linear_sl5_2
#print axioms HiaCoreSyntaxSlice.linear_sl5_3
#print axioms HiaCoreSyntaxSlice.linear_sl65_0
#print axioms HiaCoreSyntaxSlice.linear_sl65_1
#print axioms HiaCoreSyntaxSlice.linear_sl65_2
#print axioms HiaCoreSyntaxSlice.linear_sl65_3
#print axioms HiaCoreSyntaxSlice.linear_sl70_0
#print axioms HiaCoreSyntaxSlice.linear_sl70_1
#print axioms HiaCoreSyntaxSlice.linear_sl70_2
#print axioms HiaCoreSyntaxSlice.linear_sl70_3
#print axioms HiaCoreSyntaxSlice.linear_sl75_0
#print axioms HiaCoreSyntaxSlice.linear_sl75_1
#print axioms HiaCoreSyntaxSlice.linear_sl75_2
#print axioms HiaCoreSyntaxSlice.linear_sl75_3
#print axioms HiaCoreSyntaxSlice.linear_sl77_0
#print axioms HiaCoreSyntaxSlice.linear_sl77_1
#print axioms HiaCoreSyntaxSlice.linear_sl77_2
#print axioms HiaCoreSyntaxSlice.linear_sl77_3
#print axioms HiaCoreSyntaxSlice.linear_sl77_4
#print axioms HiaCoreSyntaxSlice.linear_sl77_5
#print axioms HiaCoreSyntaxSlice.linear_sl77_6
#print axioms HiaCoreSyntaxSlice.linear_sl87_0
#print axioms HiaCoreSyntaxSlice.linear_sl87_1
#print axioms HiaCoreSyntaxSlice.linear_sl87_2
#print axioms HiaCoreSyntaxSlice.linear_sl87_3
#print axioms HiaCoreSyntaxSlice.linear_sl92_0
#print axioms HiaCoreSyntaxSlice.linear_sl92_1
#print axioms HiaCoreSyntaxSlice.linear_sl92_2
#print axioms HiaCoreSyntaxSlice.linear_sl92_3
#print axioms HiaCoreSyntaxSlice.linear_sl99_1
#print axioms HiaCoreSyntaxSlice.linear_sl99_10
#print axioms HiaCoreSyntaxSlice.linear_sl99_2
#print axioms HiaCoreSyntaxSlice.linear_sl99_3
#print axioms HiaCoreSyntaxSlice.linear_sl99_4
#print axioms HiaCoreSyntaxSlice.linear_sl99_5
#print axioms HiaCoreSyntaxSlice.linear_sl99_6
#print axioms HiaCoreSyntaxSlice.linear_sl99_7
#print axioms HiaCoreSyntaxSlice.linear_sl99_8
#print axioms HiaCoreSyntaxSlice.linear_sl99_9
