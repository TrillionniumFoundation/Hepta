import HiaSyntaxResearch.SyntaxData
namespace HiaCoreSyntaxSlice
def linear_l99_0 : List Raw := linear_r100 :: linear_l99_1
def linear_v99_0 : List Nat := (linear_b100) ++ (44 :: linear_v99_1)
theorem linear_sl99_0 : serializeItems 4069 26 linear_l99_0 = some linear_v99_0 := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r100 linear_r101 linear_l99_2 linear_b100 linear_v99_1 linear_s100 linear_sl99_1)
theorem linear_pl99_0 (tail : List Nat) : parseItems 4069 26 (linear_v99_0 ++ (93 :: tail)) = some (linear_l99_0, tail) := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b100 ++ (44 :: (linear_v99_1 ++ (93 :: tail)))) (linear_v99_1 ++ (93 :: tail)) tail linear_r100 linear_l99_1 (linear_p100 (44 :: (linear_v99_1 ++ (93 :: tail)))) (linear_pl99_1 tail))
def linear_r99 : Raw := (.arr linear_l99_0)
def linear_b99 : List Nat := linear_g254 ++ (linear_v99_0 ++ linear_g276)
theorem linear_s99 : serializeRaw 4070 27 linear_r99 = some linear_b99 := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4069 26 linear_l99_0 linear_v99_0 linear_sl99_0)
theorem linear_p99 (tail : List Nat) : parseRaw 4070 27 (linear_b99 ++ tail) = some (linear_r99, tail) := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4069 26 (linear_v99_0 ++ (93 :: tail)) tail linear_l99_0 (by intro h; cases h) (linear_pl99_0 tail))
def linear_r111 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b111 : List Nat := linear_g279
theorem linear_s111 : serializeRaw 4069 27 linear_r111 = some linear_b111 := by decide +kernel
theorem linear_p111 (tail : List Nat) : parseRaw 4069 27 (linear_b111 ++ tail) = some (linear_r111, tail) := by rfl
def linear_r112 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,48]),(.str [100,103,95,118,95,49,49,49]),(.str [100,103,95,118,95,49,49,50]),(.str [100,103,95,118,95,49,49,51]),(.str [100,103,95,118,95,49,50,51])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,48]))])
def linear_b112 : List Nat := linear_g282
theorem linear_s112 : serializeRaw 4068 27 linear_r112 = some linear_b112 := by decide +kernel
theorem linear_p112 (tail : List Nat) : parseRaw 4068 27 (linear_b112 ++ tail) = some (linear_r112, tail) := by rfl
def linear_k97_0 : List Nat := [105,100]
theorem linear_kd97_0 : stringBytes linear_k97_0 = true := by decide +kernel
theorem linear_kp97_0 (tail : List Nat) : parseStringTail (linear_k97_0 ++ (34 :: 58 :: tail)) [] = some (linear_k97_0, 58 :: tail) := by rfl
def linear_k97_1 : List Nat := [111,112,115]
theorem linear_kd97_1 : stringBytes linear_k97_1 = true := by decide +kernel
theorem linear_kp97_1 (tail : List Nat) : parseStringTail (linear_k97_1 ++ (34 :: 58 :: tail)) [] = some (linear_k97_1, 58 :: tail) := by rfl
def linear_k97_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd97_2 : stringBytes linear_k97_2 = true := by decide +kernel
theorem linear_kp97_2 (tail : List Nat) : parseStringTail (linear_k97_2 ++ (34 :: 58 :: tail)) [] = some (linear_k97_2, 58 :: tail) := by rfl
def linear_k97_3 : List Nat := [116,101,114,109]
theorem linear_kd97_3 : stringBytes linear_k97_3 = true := by decide +kernel
theorem linear_kp97_3 (tail : List Nat) : parseStringTail (linear_k97_3 ++ (34 :: 58 :: tail)) [] = some (linear_k97_3, 58 :: tail) := by rfl
def linear_l97_3 : List (List Nat × Raw) := [(linear_k97_3, linear_r112)]
def linear_v97_3 : List Nat := linear_g281 ++ linear_b112
theorem linear_sl97_3 : serializeFields 4069 27 linear_l97_3 = some linear_v97_3 := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4068 27 linear_k97_3 linear_r112 linear_b112 linear_kd97_3 linear_s112)
theorem linear_pl97_3 (tail : List Nat) : parseFields 4069 27 (linear_v97_3 ++ (125 :: tail)) = some (linear_l97_3, tail) := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4068 27 (linear_k97_3 ++ (34 :: 58 :: (linear_b112 ++ (125 :: tail)))) linear_k97_3 (linear_b112 ++ (125 :: tail)) tail linear_r112 (linear_kp97_3 (linear_b112 ++ (125 :: tail))) (linear_p112 (125 :: tail)))
def linear_l97_2 : List (List Nat × Raw) := (linear_k97_2, linear_r111) :: linear_l97_3
def linear_v97_2 : List Nat := (linear_g278 ++ linear_b111) ++ (44 :: linear_v97_3)
theorem linear_sl97_2 : serializeFields 4070 27 linear_l97_2 = some linear_v97_2 := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k97_2 linear_r111 (linear_k97_3, linear_r112) [] linear_b111 linear_v97_3 linear_kd97_2 linear_s111 linear_sl97_3)
theorem linear_pl97_2 (tail : List Nat) : parseFields 4070 27 (linear_v97_2 ++ (125 :: tail)) = some (linear_l97_2, tail) := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k97_2 ++ (34 :: 58 :: (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))))) linear_k97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))) (linear_v97_3 ++ (125 :: tail)) tail linear_r111 linear_l97_3 (linear_kp97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail))))) (linear_p111 (44 :: (linear_v97_3 ++ (125 :: tail)))) (linear_pl97_3 tail))
def linear_l97_1 : List (List Nat × Raw) := (linear_k97_1, linear_r99) :: linear_l97_2
def linear_v97_1 : List Nat := (linear_g253 ++ linear_b99) ++ (44 :: linear_v97_2)
theorem linear_sl97_1 : serializeFields 4071 27 linear_l97_1 = some linear_v97_1 := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k97_1 linear_r99 (linear_k97_2, linear_r111) linear_l97_3 linear_b99 linear_v97_2 linear_kd97_1 linear_s99 linear_sl97_2)
theorem linear_pl97_1 (tail : List Nat) : parseFields 4071 27 (linear_v97_1 ++ (125 :: tail)) = some (linear_l97_1, tail) := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k97_1 ++ (34 :: 58 :: (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))))) linear_k97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))) (linear_v97_2 ++ (125 :: tail)) tail linear_r99 linear_l97_2 (linear_kp97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail))))) (linear_p99 (44 :: (linear_v97_2 ++ (125 :: tail)))) (linear_pl97_2 tail))
def linear_l97_0 : List (List Nat × Raw) := (linear_k97_0, linear_r98) :: linear_l97_1
def linear_v97_0 : List Nat := (linear_g250 ++ linear_b98) ++ (44 :: linear_v97_1)
theorem linear_sl97_0 : serializeFields 4072 27 linear_l97_0 = some linear_v97_0 := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k97_0 linear_r98 (linear_k97_1, linear_r99) linear_l97_2 linear_b98 linear_v97_1 linear_kd97_0 linear_s98 linear_sl97_1)
theorem linear_pl97_0 (tail : List Nat) : parseFields 4072 27 (linear_v97_0 ++ (125 :: tail)) = some (linear_l97_0, tail) := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) linear_k97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))) (linear_v97_1 ++ (125 :: tail)) tail linear_r98 linear_l97_1 (linear_kp97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail))))) (linear_p98 (44 :: (linear_v97_1 ++ (125 :: tail)))) (linear_pl97_1 tail))
def linear_r97 : Raw := (.obj linear_l97_0)
def linear_b97 : List Nat := linear_g249 ++ (linear_v97_0 ++ linear_g283)
theorem linear_o97 : orderedFields linear_l97_0 = true := by decide +kernel
theorem linear_s97 : serializeRaw 4073 28 linear_r97 = some linear_b97 := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4072 27 linear_l97_0 linear_v97_0 linear_o97 linear_sl97_0)
theorem linear_p97 (tail : List Nat) : parseRaw 4073 28 (linear_b97 ++ tail) = some (linear_r97, tail) := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4072 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) tail linear_l97_0 linear_o97 (by simpa only [linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl97_0 tail)))
def linear_r114 : Raw := (.str [100,103,95,115,108,111,119,95,50])
def linear_b114 : List Nat := linear_g287
theorem linear_s114 : serializeRaw 4070 27 linear_r114 = some linear_b114 := by decide +kernel
theorem linear_p114 (tail : List Nat) : parseRaw 4070 27 (linear_b114 ++ tail) = some (linear_r114, tail) := by rfl
def linear_r115 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,57])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b115 : List Nat := linear_g290
theorem linear_s115 : serializeRaw 4069 27 linear_r115 = some linear_b115 := by decide +kernel
theorem linear_p115 (tail : List Nat) : parseRaw 4069 27 (linear_b115 ++ tail) = some (linear_r115, tail) := by rfl
def linear_r116 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b116 : List Nat := linear_g293
theorem linear_s116 : serializeRaw 4068 27 linear_r116 = some linear_b116 := by decide +kernel
theorem linear_p116 (tail : List Nat) : parseRaw 4068 27 (linear_b116 ++ tail) = some (linear_r116, tail) := by rfl
def linear_r117 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,50,53]),(.str [100,103,95,118,95,49,50,54]),(.str [100,103,95,118,95,49,50,57]),(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,51,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b117 : List Nat := linear_g296
theorem linear_s117 : serializeRaw 4067 27 linear_r117 = some linear_b117 := by decide +kernel
theorem linear_p117 (tail : List Nat) : parseRaw 4067 27 (linear_b117 ++ tail) = some (linear_r117, tail) := by rfl
def linear_k113_0 : List Nat := [105,100]
theorem linear_kd113_0 : stringBytes linear_k113_0 = true := by decide +kernel
theorem linear_kp113_0 (tail : List Nat) : parseStringTail (linear_k113_0 ++ (34 :: 58 :: tail)) [] = some (linear_k113_0, 58 :: tail) := by rfl
def linear_k113_1 : List Nat := [111,112,115]
theorem linear_kd113_1 : stringBytes linear_k113_1 = true := by decide +kernel
theorem linear_kp113_1 (tail : List Nat) : parseStringTail (linear_k113_1 ++ (34 :: 58 :: tail)) [] = some (linear_k113_1, 58 :: tail) := by rfl
def linear_k113_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd113_2 : stringBytes linear_k113_2 = true := by decide +kernel
theorem linear_kp113_2 (tail : List Nat) : parseStringTail (linear_k113_2 ++ (34 :: 58 :: tail)) [] = some (linear_k113_2, 58 :: tail) := by rfl
def linear_k113_3 : List Nat := [116,101,114,109]
theorem linear_kd113_3 : stringBytes linear_k113_3 = true := by decide +kernel
theorem linear_kp113_3 (tail : List Nat) : parseStringTail (linear_k113_3 ++ (34 :: 58 :: tail)) [] = some (linear_k113_3, 58 :: tail) := by rfl
def linear_l113_3 : List (List Nat × Raw) := [(linear_k113_3, linear_r117)]
def linear_v113_3 : List Nat := linear_g295 ++ linear_b117
theorem linear_sl113_3 : serializeFields 4068 27 linear_l113_3 = some linear_v113_3 := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4067 27 linear_k113_3 linear_r117 linear_b117 linear_kd113_3 linear_s117)
theorem linear_pl113_3 (tail : List Nat) : parseFields 4068 27 (linear_v113_3 ++ (125 :: tail)) = some (linear_l113_3, tail) := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4067 27 (linear_k113_3 ++ (34 :: 58 :: (linear_b117 ++ (125 :: tail)))) linear_k113_3 (linear_b117 ++ (125 :: tail)) tail linear_r117 (linear_kp113_3 (linear_b117 ++ (125 :: tail))) (linear_p117 (125 :: tail)))
def linear_l113_2 : List (List Nat × Raw) := (linear_k113_2, linear_r116) :: linear_l113_3
def linear_v113_2 : List Nat := (linear_g292 ++ linear_b116) ++ (44 :: linear_v113_3)
theorem linear_sl113_2 : serializeFields 4069 27 linear_l113_2 = some linear_v113_2 := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k113_2 linear_r116 (linear_k113_3, linear_r117) [] linear_b116 linear_v113_3 linear_kd113_2 linear_s116 linear_sl113_3)
theorem linear_pl113_2 (tail : List Nat) : parseFields 4069 27 (linear_v113_2 ++ (125 :: tail)) = some (linear_l113_2, tail) := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k113_2 ++ (34 :: 58 :: (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))))) linear_k113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))) (linear_v113_3 ++ (125 :: tail)) tail linear_r116 linear_l113_3 (linear_kp113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail))))) (linear_p116 (44 :: (linear_v113_3 ++ (125 :: tail)))) (linear_pl113_3 tail))
def linear_l113_1 : List (List Nat × Raw) := (linear_k113_1, linear_r115) :: linear_l113_2
def linear_v113_1 : List Nat := (linear_g289 ++ linear_b115) ++ (44 :: linear_v113_2)
theorem linear_sl113_1 : serializeFields 4070 27 linear_l113_1 = some linear_v113_1 := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k113_1 linear_r115 (linear_k113_2, linear_r116) linear_l113_3 linear_b115 linear_v113_2 linear_kd113_1 linear_s115 linear_sl113_2)
theorem linear_pl113_1 (tail : List Nat) : parseFields 4070 27 (linear_v113_1 ++ (125 :: tail)) = some (linear_l113_1, tail) := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k113_1 ++ (34 :: 58 :: (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))))) linear_k113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))) (linear_v113_2 ++ (125 :: tail)) tail linear_r115 linear_l113_2 (linear_kp113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail))))) (linear_p115 (44 :: (linear_v113_2 ++ (125 :: tail)))) (linear_pl113_2 tail))
def linear_l113_0 : List (List Nat × Raw) := (linear_k113_0, linear_r114) :: linear_l113_1
def linear_v113_0 : List Nat := (linear_g286 ++ linear_b114) ++ (44 :: linear_v113_1)
theorem linear_sl113_0 : serializeFields 4071 27 linear_l113_0 = some linear_v113_0 := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k113_0 linear_r114 (linear_k113_1, linear_r115) linear_l113_2 linear_b114 linear_v113_1 linear_kd113_0 linear_s114 linear_sl113_1)
theorem linear_pl113_0 (tail : List Nat) : parseFields 4071 27 (linear_v113_0 ++ (125 :: tail)) = some (linear_l113_0, tail) := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) linear_k113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))) (linear_v113_1 ++ (125 :: tail)) tail linear_r114 linear_l113_1 (linear_kp113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail))))) (linear_p114 (44 :: (linear_v113_1 ++ (125 :: tail)))) (linear_pl113_1 tail))
def linear_r113 : Raw := (.obj linear_l113_0)
def linear_b113 : List Nat := linear_g285 ++ (linear_v113_0 ++ linear_g297)
theorem linear_o113 : orderedFields linear_l113_0 = true := by decide +kernel
theorem linear_s113 : serializeRaw 4072 28 linear_r113 = some linear_b113 := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4071 27 linear_l113_0 linear_v113_0 linear_o113 linear_sl113_0)
theorem linear_p113 (tail : List Nat) : parseRaw 4072 28 (linear_b113 ++ tail) = some (linear_r113, tail) := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4071 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) tail linear_l113_0 linear_o113 (by simpa only [linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl113_0 tail)))
def linear_r119 : Raw := (.str [100,103,95,115,108,111,119,95,51])
def linear_b119 : List Nat := linear_g301
theorem linear_s119 : serializeRaw 4069 27 linear_r119 = some linear_b119 := by decide +kernel
theorem linear_p119 (tail : List Nat) : parseRaw 4069 27 (linear_b119 ++ tail) = some (linear_r119, tail) := by rfl
def linear_r120 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,54]),(.str [100,103,95,118,95,49,51,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,55])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b120 : List Nat := linear_g304
theorem linear_s120 : serializeRaw 4068 27 linear_r120 = some linear_b120 := by decide +kernel
theorem linear_p120 (tail : List Nat) : parseRaw 4068 27 (linear_b120 ++ tail) = some (linear_r120, tail) := by rfl
def linear_r121 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,52])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b121 : List Nat := linear_g307
theorem linear_s121 : serializeRaw 4067 27 linear_r121 = some linear_b121 := by decide +kernel
theorem linear_p121 (tail : List Nat) : parseRaw 4067 27 (linear_b121 ++ tail) = some (linear_r121, tail) := by rfl
def linear_r122 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,51,55])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))]))])
def linear_b122 : List Nat := linear_g310
theorem linear_s122 : serializeRaw 4066 27 linear_r122 = some linear_b122 := by decide +kernel
theorem linear_p122 (tail : List Nat) : parseRaw 4066 27 (linear_b122 ++ tail) = some (linear_r122, tail) := by rfl
def linear_k118_0 : List Nat := [105,100]
theorem linear_kd118_0 : stringBytes linear_k118_0 = true := by decide +kernel
theorem linear_kp118_0 (tail : List Nat) : parseStringTail (linear_k118_0 ++ (34 :: 58 :: tail)) [] = some (linear_k118_0, 58 :: tail) := by rfl
def linear_k118_1 : List Nat := [111,112,115]
theorem linear_kd118_1 : stringBytes linear_k118_1 = true := by decide +kernel
theorem linear_kp118_1 (tail : List Nat) : parseStringTail (linear_k118_1 ++ (34 :: 58 :: tail)) [] = some (linear_k118_1, 58 :: tail) := by rfl
def linear_k118_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd118_2 : stringBytes linear_k118_2 = true := by decide +kernel
theorem linear_kp118_2 (tail : List Nat) : parseStringTail (linear_k118_2 ++ (34 :: 58 :: tail)) [] = some (linear_k118_2, 58 :: tail) := by rfl
def linear_k118_3 : List Nat := [116,101,114,109]
theorem linear_kd118_3 : stringBytes linear_k118_3 = true := by decide +kernel
theorem linear_kp118_3 (tail : List Nat) : parseStringTail (linear_k118_3 ++ (34 :: 58 :: tail)) [] = some (linear_k118_3, 58 :: tail) := by rfl
def linear_l118_3 : List (List Nat × Raw) := [(linear_k118_3, linear_r122)]
def linear_v118_3 : List Nat := linear_g309 ++ linear_b122
theorem linear_sl118_3 : serializeFields 4067 27 linear_l118_3 = some linear_v118_3 := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4066 27 linear_k118_3 linear_r122 linear_b122 linear_kd118_3 linear_s122)
theorem linear_pl118_3 (tail : List Nat) : parseFields 4067 27 (linear_v118_3 ++ (125 :: tail)) = some (linear_l118_3, tail) := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4066 27 (linear_k118_3 ++ (34 :: 58 :: (linear_b122 ++ (125 :: tail)))) linear_k118_3 (linear_b122 ++ (125 :: tail)) tail linear_r122 (linear_kp118_3 (linear_b122 ++ (125 :: tail))) (linear_p122 (125 :: tail)))
def linear_l118_2 : List (List Nat × Raw) := (linear_k118_2, linear_r121) :: linear_l118_3
def linear_v118_2 : List Nat := (linear_g306 ++ linear_b121) ++ (44 :: linear_v118_3)
theorem linear_sl118_2 : serializeFields 4068 27 linear_l118_2 = some linear_v118_2 := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k118_2 linear_r121 (linear_k118_3, linear_r122) [] linear_b121 linear_v118_3 linear_kd118_2 linear_s121 linear_sl118_3)
theorem linear_pl118_2 (tail : List Nat) : parseFields 4068 27 (linear_v118_2 ++ (125 :: tail)) = some (linear_l118_2, tail) := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k118_2 ++ (34 :: 58 :: (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))))) linear_k118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))) (linear_v118_3 ++ (125 :: tail)) tail linear_r121 linear_l118_3 (linear_kp118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail))))) (linear_p121 (44 :: (linear_v118_3 ++ (125 :: tail)))) (linear_pl118_3 tail))
def linear_l118_1 : List (List Nat × Raw) := (linear_k118_1, linear_r120) :: linear_l118_2
def linear_v118_1 : List Nat := (linear_g303 ++ linear_b120) ++ (44 :: linear_v118_2)
theorem linear_sl118_1 : serializeFields 4069 27 linear_l118_1 = some linear_v118_1 := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k118_1 linear_r120 (linear_k118_2, linear_r121) linear_l118_3 linear_b120 linear_v118_2 linear_kd118_1 linear_s120 linear_sl118_2)
theorem linear_pl118_1 (tail : List Nat) : parseFields 4069 27 (linear_v118_1 ++ (125 :: tail)) = some (linear_l118_1, tail) := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k118_1 ++ (34 :: 58 :: (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))))) linear_k118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))) (linear_v118_2 ++ (125 :: tail)) tail linear_r120 linear_l118_2 (linear_kp118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail))))) (linear_p120 (44 :: (linear_v118_2 ++ (125 :: tail)))) (linear_pl118_2 tail))
def linear_l118_0 : List (List Nat × Raw) := (linear_k118_0, linear_r119) :: linear_l118_1
def linear_v118_0 : List Nat := (linear_g300 ++ linear_b119) ++ (44 :: linear_v118_1)
theorem linear_sl118_0 : serializeFields 4070 27 linear_l118_0 = some linear_v118_0 := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k118_0 linear_r119 (linear_k118_1, linear_r120) linear_l118_2 linear_b119 linear_v118_1 linear_kd118_0 linear_s119 linear_sl118_1)
theorem linear_pl118_0 (tail : List Nat) : parseFields 4070 27 (linear_v118_0 ++ (125 :: tail)) = some (linear_l118_0, tail) := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) linear_k118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))) (linear_v118_1 ++ (125 :: tail)) tail linear_r119 linear_l118_1 (linear_kp118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail))))) (linear_p119 (44 :: (linear_v118_1 ++ (125 :: tail)))) (linear_pl118_1 tail))
def linear_r118 : Raw := (.obj linear_l118_0)
def linear_b118 : List Nat := linear_g299 ++ (linear_v118_0 ++ linear_g311)
theorem linear_o118 : orderedFields linear_l118_0 = true := by decide +kernel
theorem linear_s118 : serializeRaw 4071 28 linear_r118 = some linear_b118 := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4070 27 linear_l118_0 linear_v118_0 linear_o118 linear_sl118_0)
theorem linear_p118 (tail : List Nat) : parseRaw 4071 28 (linear_b118 ++ tail) = some (linear_r118, tail) := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4070 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) tail linear_l118_0 linear_o118 (by simpa only [linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl118_0 tail)))
def linear_r124 : Raw := (.str [100,103,95,115,108,111,119,95,52])
def linear_b124 : List Nat := linear_g315
theorem linear_s124 : serializeRaw 4068 27 linear_r124 = some linear_b124 := by decide +kernel
theorem linear_p124 (tail : List Nat) : parseRaw 4068 27 (linear_b124 ++ tail) = some (linear_r124, tail) := by rfl
def linear_r126 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,52])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b126 : List Nat := linear_g319
theorem linear_s126 : serializeRaw 4065 26 linear_r126 = some linear_b126 := by decide +kernel
theorem linear_p126 (tail : List Nat) : parseRaw 4065 26 (linear_b126 ++ tail) = some (linear_r126, tail) := by rfl
def linear_r127 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52]),(.str [100,103,95,118,95,49,52,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b127 : List Nat := linear_g321
theorem linear_s127 : serializeRaw 4064 26 linear_r127 = some linear_b127 := by decide +kernel
theorem linear_p127 (tail : List Nat) : parseRaw 4064 26 (linear_b127 ++ tail) = some (linear_r127, tail) := by rfl
def linear_r128 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b128 : List Nat := linear_g323
theorem linear_s128 : serializeRaw 4063 26 linear_r128 = some linear_b128 := by decide +kernel
theorem linear_p128 (tail : List Nat) : parseRaw 4063 26 (linear_b128 ++ tail) = some (linear_r128, tail) := by rfl
def linear_r129 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b129 : List Nat := linear_g325
theorem linear_s129 : serializeRaw 4062 26 linear_r129 = some linear_b129 := by decide +kernel
theorem linear_p129 (tail : List Nat) : parseRaw 4062 26 (linear_b129 ++ tail) = some (linear_r129, tail) := by rfl
def linear_r130 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,49]),(.str [100,103,95,118,95,49,52,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b130 : List Nat := linear_g327
theorem linear_s130 : serializeRaw 4061 26 linear_r130 = some linear_b130 := by decide +kernel
theorem linear_p130 (tail : List Nat) : parseRaw 4061 26 (linear_b130 ++ tail) = some (linear_r130, tail) := by rfl
def linear_r131 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b131 : List Nat := linear_g329
theorem linear_s131 : serializeRaw 4060 26 linear_r131 = some linear_b131 := by decide +kernel
theorem linear_p131 (tail : List Nat) : parseRaw 4060 26 (linear_b131 ++ tail) = some (linear_r131, tail) := by rfl
def linear_r132 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,51]),(.str [100,103,95,118,95,49,52,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b132 : List Nat := linear_g331
theorem linear_s132 : serializeRaw 4059 26 linear_r132 = some linear_b132 := by decide +kernel
theorem linear_p132 (tail : List Nat) : parseRaw 4059 26 (linear_b132 ++ tail) = some (linear_r132, tail) := by rfl
def linear_l125_6 : List Raw := [linear_r132]
def linear_v125_6 : List Nat := linear_b132
theorem linear_sl125_6 : serializeItems 4060 26 linear_l125_6 = some linear_v125_6 := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4059 26 linear_r132 linear_b132 linear_s132)
theorem linear_pl125_6 (tail : List Nat) : parseItems 4060 26 (linear_v125_6 ++ (93 :: tail)) = some (linear_l125_6, tail) := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4059 26 (linear_b132 ++ (93 :: tail)) tail linear_r132 (linear_p132 (93 :: tail)))
def linear_l125_5 : List Raw := linear_r131 :: linear_l125_6
def linear_v125_5 : List Nat := (linear_b131) ++ (44 :: linear_v125_6)
theorem linear_sl125_5 : serializeItems 4061 26 linear_l125_5 = some linear_v125_5 := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r131 linear_r132 [] linear_b131 linear_v125_6 linear_s131 linear_sl125_6)
theorem linear_pl125_5 (tail : List Nat) : parseItems 4061 26 (linear_v125_5 ++ (93 :: tail)) = some (linear_l125_5, tail) := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b131 ++ (44 :: (linear_v125_6 ++ (93 :: tail)))) (linear_v125_6 ++ (93 :: tail)) tail linear_r131 linear_l125_6 (linear_p131 (44 :: (linear_v125_6 ++ (93 :: tail)))) (linear_pl125_6 tail))
def linear_l125_4 : List Raw := linear_r130 :: linear_l125_5
def linear_v125_4 : List Nat := (linear_b130) ++ (44 :: linear_v125_5)
theorem linear_sl125_4 : serializeItems 4062 26 linear_l125_4 = some linear_v125_4 := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r130 linear_r131 linear_l125_6 linear_b130 linear_v125_5 linear_s130 linear_sl125_5)
theorem linear_pl125_4 (tail : List Nat) : parseItems 4062 26 (linear_v125_4 ++ (93 :: tail)) = some (linear_l125_4, tail) := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b130 ++ (44 :: (linear_v125_5 ++ (93 :: tail)))) (linear_v125_5 ++ (93 :: tail)) tail linear_r130 linear_l125_5 (linear_p130 (44 :: (linear_v125_5 ++ (93 :: tail)))) (linear_pl125_5 tail))
def linear_l125_3 : List Raw := linear_r129 :: linear_l125_4
def linear_v125_3 : List Nat := (linear_b129) ++ (44 :: linear_v125_4)
theorem linear_sl125_3 : serializeItems 4063 26 linear_l125_3 = some linear_v125_3 := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r129 linear_r130 linear_l125_5 linear_b129 linear_v125_4 linear_s129 linear_sl125_4)
theorem linear_pl125_3 (tail : List Nat) : parseItems 4063 26 (linear_v125_3 ++ (93 :: tail)) = some (linear_l125_3, tail) := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b129 ++ (44 :: (linear_v125_4 ++ (93 :: tail)))) (linear_v125_4 ++ (93 :: tail)) tail linear_r129 linear_l125_4 (linear_p129 (44 :: (linear_v125_4 ++ (93 :: tail)))) (linear_pl125_4 tail))
def linear_l125_2 : List Raw := linear_r128 :: linear_l125_3
def linear_v125_2 : List Nat := (linear_b128) ++ (44 :: linear_v125_3)
theorem linear_sl125_2 : serializeItems 4064 26 linear_l125_2 = some linear_v125_2 := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r128 linear_r129 linear_l125_4 linear_b128 linear_v125_3 linear_s128 linear_sl125_3)
theorem linear_pl125_2 (tail : List Nat) : parseItems 4064 26 (linear_v125_2 ++ (93 :: tail)) = some (linear_l125_2, tail) := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b128 ++ (44 :: (linear_v125_3 ++ (93 :: tail)))) (linear_v125_3 ++ (93 :: tail)) tail linear_r128 linear_l125_3 (linear_p128 (44 :: (linear_v125_3 ++ (93 :: tail)))) (linear_pl125_3 tail))
def linear_l125_1 : List Raw := linear_r127 :: linear_l125_2
def linear_v125_1 : List Nat := (linear_b127) ++ (44 :: linear_v125_2)
theorem linear_sl125_1 : serializeItems 4065 26 linear_l125_1 = some linear_v125_1 := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r127 linear_r128 linear_l125_3 linear_b127 linear_v125_2 linear_s127 linear_sl125_2)
theorem linear_pl125_1 (tail : List Nat) : parseItems 4065 26 (linear_v125_1 ++ (93 :: tail)) = some (linear_l125_1, tail) := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b127 ++ (44 :: (linear_v125_2 ++ (93 :: tail)))) (linear_v125_2 ++ (93 :: tail)) tail linear_r127 linear_l125_2 (linear_p127 (44 :: (linear_v125_2 ++ (93 :: tail)))) (linear_pl125_2 tail))
def linear_l125_0 : List Raw := linear_r126 :: linear_l125_1
def linear_v125_0 : List Nat := (linear_b126) ++ (44 :: linear_v125_1)
theorem linear_sl125_0 : serializeItems 4066 26 linear_l125_0 = some linear_v125_0 := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r126 linear_r127 linear_l125_2 linear_b126 linear_v125_1 linear_s126 linear_sl125_1)
theorem linear_pl125_0 (tail : List Nat) : parseItems 4066 26 (linear_v125_0 ++ (93 :: tail)) = some (linear_l125_0, tail) := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b126 ++ (44 :: (linear_v125_1 ++ (93 :: tail)))) (linear_v125_1 ++ (93 :: tail)) tail linear_r126 linear_l125_1 (linear_p126 (44 :: (linear_v125_1 ++ (93 :: tail)))) (linear_pl125_1 tail))
def linear_r125 : Raw := (.arr linear_l125_0)
def linear_b125 : List Nat := linear_g318 ++ (linear_v125_0 ++ linear_g332)
theorem linear_s125 : serializeRaw 4067 27 linear_r125 = some linear_b125 := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4066 26 linear_l125_0 linear_v125_0 linear_sl125_0)
theorem linear_p125 (tail : List Nat) : parseRaw 4067 27 (linear_b125 ++ tail) = some (linear_r125, tail) := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4066 26 (linear_v125_0 ++ (93 :: tail)) tail linear_l125_0 (by intro h; cases h) (linear_pl125_0 tail))
def linear_r133 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b133 : List Nat := linear_g335
theorem linear_s133 : serializeRaw 4066 27 linear_r133 = some linear_b133 := by decide +kernel
theorem linear_p133 (tail : List Nat) : parseRaw 4066 27 (linear_b133 ++ tail) = some (linear_r133, tail) := by rfl
def linear_r134 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,56]),(.str [100,103,95,118,95,49,51,57]),(.str [100,103,95,118,95,49,52,48]),(.str [100,103,95,118,95,49,52,55]),(.str [100,103,95,118,95,49,52,50]),(.str [100,103,95,118,95,49,52,57])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b134 : List Nat := linear_g338
theorem linear_s134 : serializeRaw 4065 27 linear_r134 = some linear_b134 := by decide +kernel
theorem linear_p134 (tail : List Nat) : parseRaw 4065 27 (linear_b134 ++ tail) = some (linear_r134, tail) := by rfl
def linear_k123_0 : List Nat := [105,100]
theorem linear_kd123_0 : stringBytes linear_k123_0 = true := by decide +kernel
theorem linear_kp123_0 (tail : List Nat) : parseStringTail (linear_k123_0 ++ (34 :: 58 :: tail)) [] = some (linear_k123_0, 58 :: tail) := by rfl
def linear_k123_1 : List Nat := [111,112,115]
theorem linear_kd123_1 : stringBytes linear_k123_1 = true := by decide +kernel
theorem linear_kp123_1 (tail : List Nat) : parseStringTail (linear_k123_1 ++ (34 :: 58 :: tail)) [] = some (linear_k123_1, 58 :: tail) := by rfl
def linear_k123_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd123_2 : stringBytes linear_k123_2 = true := by decide +kernel
theorem linear_kp123_2 (tail : List Nat) : parseStringTail (linear_k123_2 ++ (34 :: 58 :: tail)) [] = some (linear_k123_2, 58 :: tail) := by rfl
def linear_k123_3 : List Nat := [116,101,114,109]
theorem linear_kd123_3 : stringBytes linear_k123_3 = true := by decide +kernel
theorem linear_kp123_3 (tail : List Nat) : parseStringTail (linear_k123_3 ++ (34 :: 58 :: tail)) [] = some (linear_k123_3, 58 :: tail) := by rfl
def linear_l123_3 : List (List Nat × Raw) := [(linear_k123_3, linear_r134)]
def linear_v123_3 : List Nat := linear_g337 ++ linear_b134
theorem linear_sl123_3 : serializeFields 4066 27 linear_l123_3 = some linear_v123_3 := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4065 27 linear_k123_3 linear_r134 linear_b134 linear_kd123_3 linear_s134)
theorem linear_pl123_3 (tail : List Nat) : parseFields 4066 27 (linear_v123_3 ++ (125 :: tail)) = some (linear_l123_3, tail) := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4065 27 (linear_k123_3 ++ (34 :: 58 :: (linear_b134 ++ (125 :: tail)))) linear_k123_3 (linear_b134 ++ (125 :: tail)) tail linear_r134 (linear_kp123_3 (linear_b134 ++ (125 :: tail))) (linear_p134 (125 :: tail)))
def linear_l123_2 : List (List Nat × Raw) := (linear_k123_2, linear_r133) :: linear_l123_3
def linear_v123_2 : List Nat := (linear_g334 ++ linear_b133) ++ (44 :: linear_v123_3)
theorem linear_sl123_2 : serializeFields 4067 27 linear_l123_2 = some linear_v123_2 := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k123_2 linear_r133 (linear_k123_3, linear_r134) [] linear_b133 linear_v123_3 linear_kd123_2 linear_s133 linear_sl123_3)
theorem linear_pl123_2 (tail : List Nat) : parseFields 4067 27 (linear_v123_2 ++ (125 :: tail)) = some (linear_l123_2, tail) := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k123_2 ++ (34 :: 58 :: (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))))) linear_k123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))) (linear_v123_3 ++ (125 :: tail)) tail linear_r133 linear_l123_3 (linear_kp123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail))))) (linear_p133 (44 :: (linear_v123_3 ++ (125 :: tail)))) (linear_pl123_3 tail))
def linear_l123_1 : List (List Nat × Raw) := (linear_k123_1, linear_r125) :: linear_l123_2
def linear_v123_1 : List Nat := (linear_g317 ++ linear_b125) ++ (44 :: linear_v123_2)
theorem linear_sl123_1 : serializeFields 4068 27 linear_l123_1 = some linear_v123_1 := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k123_1 linear_r125 (linear_k123_2, linear_r133) linear_l123_3 linear_b125 linear_v123_2 linear_kd123_1 linear_s125 linear_sl123_2)
theorem linear_pl123_1 (tail : List Nat) : parseFields 4068 27 (linear_v123_1 ++ (125 :: tail)) = some (linear_l123_1, tail) := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k123_1 ++ (34 :: 58 :: (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))))) linear_k123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))) (linear_v123_2 ++ (125 :: tail)) tail linear_r125 linear_l123_2 (linear_kp123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail))))) (linear_p125 (44 :: (linear_v123_2 ++ (125 :: tail)))) (linear_pl123_2 tail))
def linear_l123_0 : List (List Nat × Raw) := (linear_k123_0, linear_r124) :: linear_l123_1
def linear_v123_0 : List Nat := (linear_g314 ++ linear_b124) ++ (44 :: linear_v123_1)
theorem linear_sl123_0 : serializeFields 4069 27 linear_l123_0 = some linear_v123_0 := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k123_0 linear_r124 (linear_k123_1, linear_r125) linear_l123_2 linear_b124 linear_v123_1 linear_kd123_0 linear_s124 linear_sl123_1)
theorem linear_pl123_0 (tail : List Nat) : parseFields 4069 27 (linear_v123_0 ++ (125 :: tail)) = some (linear_l123_0, tail) := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) linear_k123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))) (linear_v123_1 ++ (125 :: tail)) tail linear_r124 linear_l123_1 (linear_kp123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail))))) (linear_p124 (44 :: (linear_v123_1 ++ (125 :: tail)))) (linear_pl123_1 tail))
def linear_r123 : Raw := (.obj linear_l123_0)
def linear_b123 : List Nat := linear_g313 ++ (linear_v123_0 ++ linear_g339)
theorem linear_o123 : orderedFields linear_l123_0 = true := by decide +kernel
theorem linear_s123 : serializeRaw 4070 28 linear_r123 = some linear_b123 := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4069 27 linear_l123_0 linear_v123_0 linear_o123 linear_sl123_0)
theorem linear_p123 (tail : List Nat) : parseRaw 4070 28 (linear_b123 ++ tail) = some (linear_r123, tail) := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4069 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) tail linear_l123_0 linear_o123 (by simpa only [linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl123_0 tail)))
def linear_r136 : Raw := (.str [100,103,95,115,108,111,119,95,53])
def linear_b136 : List Nat := linear_g343
theorem linear_s136 : serializeRaw 4067 27 linear_r136 = some linear_b136 := by decide +kernel
theorem linear_p136 (tail : List Nat) : parseRaw 4067 27 (linear_b136 ++ tail) = some (linear_r136, tail) := by rfl
def linear_r137 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b137 : List Nat := linear_g346
theorem linear_s137 : serializeRaw 4066 27 linear_r137 = some linear_b137 := by decide +kernel
theorem linear_p137 (tail : List Nat) : parseRaw 4066 27 (linear_b137 ++ tail) = some (linear_r137, tail) := by rfl
def linear_r138 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,51])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b138 : List Nat := linear_g349
theorem linear_s138 : serializeRaw 4065 27 linear_r138 = some linear_b138 := by decide +kernel
theorem linear_p138 (tail : List Nat) : parseRaw 4065 27 (linear_b138 ++ tail) = some (linear_r138, tail) := by rfl
def linear_r139 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,53,51])]))])
def linear_b139 : List Nat := linear_g352
theorem linear_s139 : serializeRaw 4064 27 linear_r139 = some linear_b139 := by decide +kernel
theorem linear_p139 (tail : List Nat) : parseRaw 4064 27 (linear_b139 ++ tail) = some (linear_r139, tail) := by rfl
def linear_k135_0 : List Nat := [105,100]
theorem linear_kd135_0 : stringBytes linear_k135_0 = true := by decide +kernel
theorem linear_kp135_0 (tail : List Nat) : parseStringTail (linear_k135_0 ++ (34 :: 58 :: tail)) [] = some (linear_k135_0, 58 :: tail) := by rfl
def linear_k135_1 : List Nat := [111,112,115]
theorem linear_kd135_1 : stringBytes linear_k135_1 = true := by decide +kernel
theorem linear_kp135_1 (tail : List Nat) : parseStringTail (linear_k135_1 ++ (34 :: 58 :: tail)) [] = some (linear_k135_1, 58 :: tail) := by rfl
def linear_k135_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd135_2 : stringBytes linear_k135_2 = true := by decide +kernel
theorem linear_kp135_2 (tail : List Nat) : parseStringTail (linear_k135_2 ++ (34 :: 58 :: tail)) [] = some (linear_k135_2, 58 :: tail) := by rfl
def linear_k135_3 : List Nat := [116,101,114,109]
theorem linear_kd135_3 : stringBytes linear_k135_3 = true := by decide +kernel
theorem linear_kp135_3 (tail : List Nat) : parseStringTail (linear_k135_3 ++ (34 :: 58 :: tail)) [] = some (linear_k135_3, 58 :: tail) := by rfl
def linear_l135_3 : List (List Nat × Raw) := [(linear_k135_3, linear_r139)]
def linear_v135_3 : List Nat := linear_g351 ++ linear_b139
theorem linear_sl135_3 : serializeFields 4065 27 linear_l135_3 = some linear_v135_3 := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4064 27 linear_k135_3 linear_r139 linear_b139 linear_kd135_3 linear_s139)
theorem linear_pl135_3 (tail : List Nat) : parseFields 4065 27 (linear_v135_3 ++ (125 :: tail)) = some (linear_l135_3, tail) := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4064 27 (linear_k135_3 ++ (34 :: 58 :: (linear_b139 ++ (125 :: tail)))) linear_k135_3 (linear_b139 ++ (125 :: tail)) tail linear_r139 (linear_kp135_3 (linear_b139 ++ (125 :: tail))) (linear_p139 (125 :: tail)))
def linear_l135_2 : List (List Nat × Raw) := (linear_k135_2, linear_r138) :: linear_l135_3
def linear_v135_2 : List Nat := (linear_g348 ++ linear_b138) ++ (44 :: linear_v135_3)
theorem linear_sl135_2 : serializeFields 4066 27 linear_l135_2 = some linear_v135_2 := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k135_2 linear_r138 (linear_k135_3, linear_r139) [] linear_b138 linear_v135_3 linear_kd135_2 linear_s138 linear_sl135_3)
theorem linear_pl135_2 (tail : List Nat) : parseFields 4066 27 (linear_v135_2 ++ (125 :: tail)) = some (linear_l135_2, tail) := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k135_2 ++ (34 :: 58 :: (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))))) linear_k135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))) (linear_v135_3 ++ (125 :: tail)) tail linear_r138 linear_l135_3 (linear_kp135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail))))) (linear_p138 (44 :: (linear_v135_3 ++ (125 :: tail)))) (linear_pl135_3 tail))
def linear_l135_1 : List (List Nat × Raw) := (linear_k135_1, linear_r137) :: linear_l135_2
def linear_v135_1 : List Nat := (linear_g345 ++ linear_b137) ++ (44 :: linear_v135_2)
theorem linear_sl135_1 : serializeFields 4067 27 linear_l135_1 = some linear_v135_1 := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k135_1 linear_r137 (linear_k135_2, linear_r138) linear_l135_3 linear_b137 linear_v135_2 linear_kd135_1 linear_s137 linear_sl135_2)
theorem linear_pl135_1 (tail : List Nat) : parseFields 4067 27 (linear_v135_1 ++ (125 :: tail)) = some (linear_l135_1, tail) := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k135_1 ++ (34 :: 58 :: (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))))) linear_k135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))) (linear_v135_2 ++ (125 :: tail)) tail linear_r137 linear_l135_2 (linear_kp135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail))))) (linear_p137 (44 :: (linear_v135_2 ++ (125 :: tail)))) (linear_pl135_2 tail))
def linear_l135_0 : List (List Nat × Raw) := (linear_k135_0, linear_r136) :: linear_l135_1
def linear_v135_0 : List Nat := (linear_g342 ++ linear_b136) ++ (44 :: linear_v135_1)
theorem linear_sl135_0 : serializeFields 4068 27 linear_l135_0 = some linear_v135_0 := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k135_0 linear_r136 (linear_k135_1, linear_r137) linear_l135_2 linear_b136 linear_v135_1 linear_kd135_0 linear_s136 linear_sl135_1)
theorem linear_pl135_0 (tail : List Nat) : parseFields 4068 27 (linear_v135_0 ++ (125 :: tail)) = some (linear_l135_0, tail) := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) linear_k135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))) (linear_v135_1 ++ (125 :: tail)) tail linear_r136 linear_l135_1 (linear_kp135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail))))) (linear_p136 (44 :: (linear_v135_1 ++ (125 :: tail)))) (linear_pl135_1 tail))
def linear_r135 : Raw := (.obj linear_l135_0)
def linear_b135 : List Nat := linear_g341 ++ (linear_v135_0 ++ linear_g353)
theorem linear_o135 : orderedFields linear_l135_0 = true := by decide +kernel
theorem linear_s135 : serializeRaw 4069 28 linear_r135 = some linear_b135 := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4068 27 linear_l135_0 linear_v135_0 linear_o135 linear_sl135_0)
theorem linear_p135 (tail : List Nat) : parseRaw 4069 28 (linear_b135 ++ tail) = some (linear_r135, tail) := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4068 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) tail linear_l135_0 linear_o135 (by simpa only [linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl135_0 tail)))
def linear_r141 : Raw := (.str [100,103,95,103,117,97,114,100,95,48])
def linear_b141 : List Nat := linear_g357
theorem linear_s141 : serializeRaw 4066 27 linear_r141 = some linear_b141 := by decide +kernel
theorem linear_p141 (tail : List Nat) : parseRaw 4066 27 (linear_b141 ++ tail) = some (linear_r141, tail) := by rfl
def linear_r142 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,50]),(.str [100,103,95,118,95,49,54,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b142 : List Nat := linear_g360
theorem linear_s142 : serializeRaw 4065 27 linear_r142 = some linear_b142 := by decide +kernel
theorem linear_p142 (tail : List Nat) : parseRaw 4065 27 (linear_b142 ++ tail) = some (linear_r142, tail) := by rfl
def linear_r143 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b143 : List Nat := linear_g363
theorem linear_s143 : serializeRaw 4064 27 linear_r143 = some linear_b143 := by decide +kernel
theorem linear_p143 (tail : List Nat) : parseRaw 4064 27 (linear_b143 ++ tail) = some (linear_r143, tail) := by rfl
def linear_r144 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,54,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b144 : List Nat := linear_g366
theorem linear_s144 : serializeRaw 4063 27 linear_r144 = some linear_b144 := by decide +kernel
theorem linear_p144 (tail : List Nat) : parseRaw 4063 27 (linear_b144 ++ tail) = some (linear_r144, tail) := by rfl
def linear_k140_0 : List Nat := [105,100]
theorem linear_kd140_0 : stringBytes linear_k140_0 = true := by decide +kernel
theorem linear_kp140_0 (tail : List Nat) : parseStringTail (linear_k140_0 ++ (34 :: 58 :: tail)) [] = some (linear_k140_0, 58 :: tail) := by rfl
def linear_k140_1 : List Nat := [111,112,115]
theorem linear_kd140_1 : stringBytes linear_k140_1 = true := by decide +kernel
theorem linear_kp140_1 (tail : List Nat) : parseStringTail (linear_k140_1 ++ (34 :: 58 :: tail)) [] = some (linear_k140_1, 58 :: tail) := by rfl
def linear_k140_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd140_2 : stringBytes linear_k140_2 = true := by decide +kernel
theorem linear_kp140_2 (tail : List Nat) : parseStringTail (linear_k140_2 ++ (34 :: 58 :: tail)) [] = some (linear_k140_2, 58 :: tail) := by rfl
def linear_k140_3 : List Nat := [116,101,114,109]
theorem linear_kd140_3 : stringBytes linear_k140_3 = true := by decide +kernel
theorem linear_kp140_3 (tail : List Nat) : parseStringTail (linear_k140_3 ++ (34 :: 58 :: tail)) [] = some (linear_k140_3, 58 :: tail) := by rfl
def linear_l140_3 : List (List Nat × Raw) := [(linear_k140_3, linear_r144)]
def linear_v140_3 : List Nat := linear_g365 ++ linear_b144
theorem linear_sl140_3 : serializeFields 4064 27 linear_l140_3 = some linear_v140_3 := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4063 27 linear_k140_3 linear_r144 linear_b144 linear_kd140_3 linear_s144)
theorem linear_pl140_3 (tail : List Nat) : parseFields 4064 27 (linear_v140_3 ++ (125 :: tail)) = some (linear_l140_3, tail) := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4063 27 (linear_k140_3 ++ (34 :: 58 :: (linear_b144 ++ (125 :: tail)))) linear_k140_3 (linear_b144 ++ (125 :: tail)) tail linear_r144 (linear_kp140_3 (linear_b144 ++ (125 :: tail))) (linear_p144 (125 :: tail)))
def linear_l140_2 : List (List Nat × Raw) := (linear_k140_2, linear_r143) :: linear_l140_3
def linear_v140_2 : List Nat := (linear_g362 ++ linear_b143) ++ (44 :: linear_v140_3)
theorem linear_sl140_2 : serializeFields 4065 27 linear_l140_2 = some linear_v140_2 := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k140_2 linear_r143 (linear_k140_3, linear_r144) [] linear_b143 linear_v140_3 linear_kd140_2 linear_s143 linear_sl140_3)
theorem linear_pl140_2 (tail : List Nat) : parseFields 4065 27 (linear_v140_2 ++ (125 :: tail)) = some (linear_l140_2, tail) := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k140_2 ++ (34 :: 58 :: (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))))) linear_k140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))) (linear_v140_3 ++ (125 :: tail)) tail linear_r143 linear_l140_3 (linear_kp140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail))))) (linear_p143 (44 :: (linear_v140_3 ++ (125 :: tail)))) (linear_pl140_3 tail))
def linear_l140_1 : List (List Nat × Raw) := (linear_k140_1, linear_r142) :: linear_l140_2
def linear_v140_1 : List Nat := (linear_g359 ++ linear_b142) ++ (44 :: linear_v140_2)
theorem linear_sl140_1 : serializeFields 4066 27 linear_l140_1 = some linear_v140_1 := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k140_1 linear_r142 (linear_k140_2, linear_r143) linear_l140_3 linear_b142 linear_v140_2 linear_kd140_1 linear_s142 linear_sl140_2)
theorem linear_pl140_1 (tail : List Nat) : parseFields 4066 27 (linear_v140_1 ++ (125 :: tail)) = some (linear_l140_1, tail) := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k140_1 ++ (34 :: 58 :: (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))))) linear_k140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))) (linear_v140_2 ++ (125 :: tail)) tail linear_r142 linear_l140_2 (linear_kp140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail))))) (linear_p142 (44 :: (linear_v140_2 ++ (125 :: tail)))) (linear_pl140_2 tail))
def linear_l140_0 : List (List Nat × Raw) := (linear_k140_0, linear_r141) :: linear_l140_1
def linear_v140_0 : List Nat := (linear_g356 ++ linear_b141) ++ (44 :: linear_v140_1)
theorem linear_sl140_0 : serializeFields 4067 27 linear_l140_0 = some linear_v140_0 := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k140_0 linear_r141 (linear_k140_1, linear_r142) linear_l140_2 linear_b141 linear_v140_1 linear_kd140_0 linear_s141 linear_sl140_1)
theorem linear_pl140_0 (tail : List Nat) : parseFields 4067 27 (linear_v140_0 ++ (125 :: tail)) = some (linear_l140_0, tail) := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) linear_k140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))) (linear_v140_1 ++ (125 :: tail)) tail linear_r141 linear_l140_1 (linear_kp140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail))))) (linear_p141 (44 :: (linear_v140_1 ++ (125 :: tail)))) (linear_pl140_1 tail))
def linear_r140 : Raw := (.obj linear_l140_0)
def linear_b140 : List Nat := linear_g355 ++ (linear_v140_0 ++ linear_g367)
theorem linear_o140 : orderedFields linear_l140_0 = true := by decide +kernel
theorem linear_s140 : serializeRaw 4068 28 linear_r140 = some linear_b140 := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4067 27 linear_l140_0 linear_v140_0 linear_o140 linear_sl140_0)
theorem linear_p140 (tail : List Nat) : parseRaw 4068 28 (linear_b140 ++ tail) = some (linear_r140, tail) := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4067 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) tail linear_l140_0 linear_o140 (by simpa only [linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl140_0 tail)))
def linear_r146 : Raw := (.str [100,103,95,103,117,97,114,100,95,49])
def linear_b146 : List Nat := linear_g371
theorem linear_s146 : serializeRaw 4065 27 linear_r146 = some linear_b146 := by decide +kernel
theorem linear_p146 (tail : List Nat) : parseRaw 4065 27 (linear_b146 ++ tail) = some (linear_r146, tail) := by rfl
def linear_r147 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,55,49]),(.str [100,103,95,118,95,49,55,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,51])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b147 : List Nat := linear_g374
theorem linear_s147 : serializeRaw 4064 27 linear_r147 = some linear_b147 := by decide +kernel
theorem linear_p147 (tail : List Nat) : parseRaw 4064 27 (linear_b147 ++ tail) = some (linear_r147, tail) := by rfl
def linear_r148 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b148 : List Nat := linear_g377
theorem linear_s148 : serializeRaw 4063 27 linear_r148 = some linear_b148 := by decide +kernel
theorem linear_p148 (tail : List Nat) : parseRaw 4063 27 (linear_b148 ++ tail) = some (linear_r148, tail) := by rfl
def linear_r149 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,55,51])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b149 : List Nat := linear_g380
theorem linear_s149 : serializeRaw 4062 27 linear_r149 = some linear_b149 := by decide +kernel
theorem linear_p149 (tail : List Nat) : parseRaw 4062 27 (linear_b149 ++ tail) = some (linear_r149, tail) := by rfl
def linear_k145_0 : List Nat := [105,100]
theorem linear_kd145_0 : stringBytes linear_k145_0 = true := by decide +kernel
theorem linear_kp145_0 (tail : List Nat) : parseStringTail (linear_k145_0 ++ (34 :: 58 :: tail)) [] = some (linear_k145_0, 58 :: tail) := by rfl
def linear_k145_1 : List Nat := [111,112,115]
theorem linear_kd145_1 : stringBytes linear_k145_1 = true := by decide +kernel
theorem linear_kp145_1 (tail : List Nat) : parseStringTail (linear_k145_1 ++ (34 :: 58 :: tail)) [] = some (linear_k145_1, 58 :: tail) := by rfl
def linear_k145_2 : List Nat := [112,97,114,97,109,115]
theorem linear_kd145_2 : stringBytes linear_k145_2 = true := by decide +kernel
theorem linear_kp145_2 (tail : List Nat) : parseStringTail (linear_k145_2 ++ (34 :: 58 :: tail)) [] = some (linear_k145_2, 58 :: tail) := by rfl
def linear_k145_3 : List Nat := [116,101,114,109]
theorem linear_kd145_3 : stringBytes linear_k145_3 = true := by decide +kernel
theorem linear_kp145_3 (tail : List Nat) : parseStringTail (linear_k145_3 ++ (34 :: 58 :: tail)) [] = some (linear_k145_3, 58 :: tail) := by rfl
def linear_l145_3 : List (List Nat × Raw) := [(linear_k145_3, linear_r149)]
def linear_v145_3 : List Nat := linear_g379 ++ linear_b149
theorem linear_sl145_3 : serializeFields 4063 27 linear_l145_3 = some linear_v145_3 := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4062 27 linear_k145_3 linear_r149 linear_b149 linear_kd145_3 linear_s149)
theorem linear_pl145_3 (tail : List Nat) : parseFields 4063 27 (linear_v145_3 ++ (125 :: tail)) = some (linear_l145_3, tail) := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4062 27 (linear_k145_3 ++ (34 :: 58 :: (linear_b149 ++ (125 :: tail)))) linear_k145_3 (linear_b149 ++ (125 :: tail)) tail linear_r149 (linear_kp145_3 (linear_b149 ++ (125 :: tail))) (linear_p149 (125 :: tail)))
def linear_l145_2 : List (List Nat × Raw) := (linear_k145_2, linear_r148) :: linear_l145_3
def linear_v145_2 : List Nat := (linear_g376 ++ linear_b148) ++ (44 :: linear_v145_3)
theorem linear_sl145_2 : serializeFields 4064 27 linear_l145_2 = some linear_v145_2 := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4063 27 linear_k145_2 linear_r148 (linear_k145_3, linear_r149) [] linear_b148 linear_v145_3 linear_kd145_2 linear_s148 linear_sl145_3)
theorem linear_pl145_2 (tail : List Nat) : parseFields 4064 27 (linear_v145_2 ++ (125 :: tail)) = some (linear_l145_2, tail) := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4063 27 (linear_k145_2 ++ (34 :: 58 :: (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))))) linear_k145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))) (linear_v145_3 ++ (125 :: tail)) tail linear_r148 linear_l145_3 (linear_kp145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail))))) (linear_p148 (44 :: (linear_v145_3 ++ (125 :: tail)))) (linear_pl145_3 tail))
def linear_l145_1 : List (List Nat × Raw) := (linear_k145_1, linear_r147) :: linear_l145_2
def linear_v145_1 : List Nat := (linear_g373 ++ linear_b147) ++ (44 :: linear_v145_2)
theorem linear_sl145_1 : serializeFields 4065 27 linear_l145_1 = some linear_v145_1 := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k145_1 linear_r147 (linear_k145_2, linear_r148) linear_l145_3 linear_b147 linear_v145_2 linear_kd145_1 linear_s147 linear_sl145_2)
theorem linear_pl145_1 (tail : List Nat) : parseFields 4065 27 (linear_v145_1 ++ (125 :: tail)) = some (linear_l145_1, tail) := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k145_1 ++ (34 :: 58 :: (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))))) linear_k145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))) (linear_v145_2 ++ (125 :: tail)) tail linear_r147 linear_l145_2 (linear_kp145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail))))) (linear_p147 (44 :: (linear_v145_2 ++ (125 :: tail)))) (linear_pl145_2 tail))
def linear_l145_0 : List (List Nat × Raw) := (linear_k145_0, linear_r146) :: linear_l145_1
def linear_v145_0 : List Nat := (linear_g370 ++ linear_b146) ++ (44 :: linear_v145_1)
theorem linear_sl145_0 : serializeFields 4066 27 linear_l145_0 = some linear_v145_0 := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k145_0 linear_r146 (linear_k145_1, linear_r147) linear_l145_2 linear_b146 linear_v145_1 linear_kd145_0 linear_s146 linear_sl145_1)
theorem linear_pl145_0 (tail : List Nat) : parseFields 4066 27 (linear_v145_0 ++ (125 :: tail)) = some (linear_l145_0, tail) := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) linear_k145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))) (linear_v145_1 ++ (125 :: tail)) tail linear_r146 linear_l145_1 (linear_kp145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail))))) (linear_p146 (44 :: (linear_v145_1 ++ (125 :: tail)))) (linear_pl145_1 tail))
def linear_r145 : Raw := (.obj linear_l145_0)
def linear_b145 : List Nat := linear_g369 ++ (linear_v145_0 ++ linear_g381)
theorem linear_o145 : orderedFields linear_l145_0 = true := by decide +kernel
theorem linear_s145 : serializeRaw 4067 28 linear_r145 = some linear_b145 := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4066 27 linear_l145_0 linear_v145_0 linear_o145 linear_sl145_0)
theorem linear_p145 (tail : List Nat) : parseRaw 4067 28 (linear_b145 ++ tail) = some (linear_r145, tail) := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4066 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) tail linear_l145_0 linear_o145 (by simpa only [linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (linear_pl145_0 tail)))
def linear_l4_20 : List Raw := [linear_r145]
def linear_v4_20 : List Nat := linear_b145
theorem linear_sl4_20 : serializeItems 4068 28 linear_l4_20 = some linear_v4_20 := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4067 28 linear_r145 linear_b145 linear_s145)
theorem linear_pl4_20 (tail : List Nat) : parseItems 4068 28 (linear_v4_20 ++ (93 :: tail)) = some (linear_l4_20, tail) := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4067 28 (linear_b145 ++ (93 :: tail)) tail linear_r145 (linear_p145 (93 :: tail)))
def linear_l4_19 : List Raw := linear_r140 :: linear_l4_20
def linear_v4_19 : List Nat := (linear_b140) ++ (44 :: linear_v4_20)
theorem linear_sl4_19 : serializeItems 4069 28 linear_l4_19 = some linear_v4_19 := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 28 linear_r140 linear_r145 [] linear_b140 linear_v4_20 linear_s140 linear_sl4_20)
theorem linear_pl4_19 (tail : List Nat) : parseItems 4069 28 (linear_v4_19 ++ (93 :: tail)) = some (linear_l4_19, tail) := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 28 (linear_b140 ++ (44 :: (linear_v4_20 ++ (93 :: tail)))) (linear_v4_20 ++ (93 :: tail)) tail linear_r140 linear_l4_20 (linear_p140 (44 :: (linear_v4_20 ++ (93 :: tail)))) (linear_pl4_20 tail))
def linear_l4_18 : List Raw := linear_r135 :: linear_l4_19
def linear_v4_18 : List Nat := (linear_b135) ++ (44 :: linear_v4_19)
theorem linear_sl4_18 : serializeItems 4070 28 linear_l4_18 = some linear_v4_18 := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 28 linear_r135 linear_r140 linear_l4_20 linear_b135 linear_v4_19 linear_s135 linear_sl4_19)
theorem linear_pl4_18 (tail : List Nat) : parseItems 4070 28 (linear_v4_18 ++ (93 :: tail)) = some (linear_l4_18, tail) := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 28 (linear_b135 ++ (44 :: (linear_v4_19 ++ (93 :: tail)))) (linear_v4_19 ++ (93 :: tail)) tail linear_r135 linear_l4_19 (linear_p135 (44 :: (linear_v4_19 ++ (93 :: tail)))) (linear_pl4_19 tail))
def linear_l4_17 : List Raw := linear_r123 :: linear_l4_18
def linear_v4_17 : List Nat := (linear_b123) ++ (44 :: linear_v4_18)
theorem linear_sl4_17 : serializeItems 4071 28 linear_l4_17 = some linear_v4_17 := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 28 linear_r123 linear_r135 linear_l4_19 linear_b123 linear_v4_18 linear_s123 linear_sl4_18)
theorem linear_pl4_17 (tail : List Nat) : parseItems 4071 28 (linear_v4_17 ++ (93 :: tail)) = some (linear_l4_17, tail) := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 28 (linear_b123 ++ (44 :: (linear_v4_18 ++ (93 :: tail)))) (linear_v4_18 ++ (93 :: tail)) tail linear_r123 linear_l4_18 (linear_p123 (44 :: (linear_v4_18 ++ (93 :: tail)))) (linear_pl4_18 tail))
def linear_l4_16 : List Raw := linear_r118 :: linear_l4_17
def linear_v4_16 : List Nat := (linear_b118) ++ (44 :: linear_v4_17)
theorem linear_sl4_16 : serializeItems 4072 28 linear_l4_16 = some linear_v4_16 := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 28 linear_r118 linear_r123 linear_l4_18 linear_b118 linear_v4_17 linear_s118 linear_sl4_17)
theorem linear_pl4_16 (tail : List Nat) : parseItems 4072 28 (linear_v4_16 ++ (93 :: tail)) = some (linear_l4_16, tail) := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 28 (linear_b118 ++ (44 :: (linear_v4_17 ++ (93 :: tail)))) (linear_v4_17 ++ (93 :: tail)) tail linear_r118 linear_l4_17 (linear_p118 (44 :: (linear_v4_17 ++ (93 :: tail)))) (linear_pl4_17 tail))
def linear_l4_15 : List Raw := linear_r113 :: linear_l4_16
def linear_v4_15 : List Nat := (linear_b113) ++ (44 :: linear_v4_16)
theorem linear_sl4_15 : serializeItems 4073 28 linear_l4_15 = some linear_v4_15 := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 28 linear_r113 linear_r118 linear_l4_17 linear_b113 linear_v4_16 linear_s113 linear_sl4_16)
theorem linear_pl4_15 (tail : List Nat) : parseItems 4073 28 (linear_v4_15 ++ (93 :: tail)) = some (linear_l4_15, tail) := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 28 (linear_b113 ++ (44 :: (linear_v4_16 ++ (93 :: tail)))) (linear_v4_16 ++ (93 :: tail)) tail linear_r113 linear_l4_16 (linear_p113 (44 :: (linear_v4_16 ++ (93 :: tail)))) (linear_pl4_16 tail))
def linear_l4_14 : List Raw := linear_r97 :: linear_l4_15
def linear_v4_14 : List Nat := (linear_b97) ++ (44 :: linear_v4_15)
theorem linear_sl4_14 : serializeItems 4074 28 linear_l4_14 = some linear_v4_14 := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 28 linear_r97 linear_r113 linear_l4_16 linear_b97 linear_v4_15 linear_s97 linear_sl4_15)
theorem linear_pl4_14 (tail : List Nat) : parseItems 4074 28 (linear_v4_14 ++ (93 :: tail)) = some (linear_l4_14, tail) := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 28 (linear_b97 ++ (44 :: (linear_v4_15 ++ (93 :: tail)))) (linear_v4_15 ++ (93 :: tail)) tail linear_r97 linear_l4_15 (linear_p97 (44 :: (linear_v4_15 ++ (93 :: tail)))) (linear_pl4_15 tail))
def linear_l4_13 : List Raw := linear_r92 :: linear_l4_14
def linear_v4_13 : List Nat := (linear_b92) ++ (44 :: linear_v4_14)
theorem linear_sl4_13 : serializeItems 4075 28 linear_l4_13 = some linear_v4_13 := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 28 linear_r92 linear_r97 linear_l4_15 linear_b92 linear_v4_14 linear_s92 linear_sl4_14)
theorem linear_pl4_13 (tail : List Nat) : parseItems 4075 28 (linear_v4_13 ++ (93 :: tail)) = some (linear_l4_13, tail) := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 28 (linear_b92 ++ (44 :: (linear_v4_14 ++ (93 :: tail)))) (linear_v4_14 ++ (93 :: tail)) tail linear_r92 linear_l4_14 (linear_p92 (44 :: (linear_v4_14 ++ (93 :: tail)))) (linear_pl4_14 tail))
def linear_l4_12 : List Raw := linear_r87 :: linear_l4_13
def linear_v4_12 : List Nat := (linear_b87) ++ (44 :: linear_v4_13)
theorem linear_sl4_12 : serializeItems 4076 28 linear_l4_12 = some linear_v4_12 := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4075 28 linear_r87 linear_r92 linear_l4_14 linear_b87 linear_v4_13 linear_s87 linear_sl4_13)
theorem linear_pl4_12 (tail : List Nat) : parseItems 4076 28 (linear_v4_12 ++ (93 :: tail)) = some (linear_l4_12, tail) := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4075 28 (linear_b87 ++ (44 :: (linear_v4_13 ++ (93 :: tail)))) (linear_v4_13 ++ (93 :: tail)) tail linear_r87 linear_l4_13 (linear_p87 (44 :: (linear_v4_13 ++ (93 :: tail)))) (linear_pl4_13 tail))
def linear_l4_11 : List Raw := linear_r75 :: linear_l4_12
def linear_v4_11 : List Nat := (linear_b75) ++ (44 :: linear_v4_12)
theorem linear_sl4_11 : serializeItems 4077 28 linear_l4_11 = some linear_v4_11 := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4076 28 linear_r75 linear_r87 linear_l4_13 linear_b75 linear_v4_12 linear_s75 linear_sl4_12)
theorem linear_pl4_11 (tail : List Nat) : parseItems 4077 28 (linear_v4_11 ++ (93 :: tail)) = some (linear_l4_11, tail) := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4076 28 (linear_b75 ++ (44 :: (linear_v4_12 ++ (93 :: tail)))) (linear_v4_12 ++ (93 :: tail)) tail linear_r75 linear_l4_12 (linear_p75 (44 :: (linear_v4_12 ++ (93 :: tail)))) (linear_pl4_12 tail))
def linear_l4_10 : List Raw := linear_r70 :: linear_l4_11
def linear_v4_10 : List Nat := (linear_b70) ++ (44 :: linear_v4_11)
theorem linear_sl4_10 : serializeItems 4078 28 linear_l4_10 = some linear_v4_10 := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4077 28 linear_r70 linear_r75 linear_l4_12 linear_b70 linear_v4_11 linear_s70 linear_sl4_11)
theorem linear_pl4_10 (tail : List Nat) : parseItems 4078 28 (linear_v4_10 ++ (93 :: tail)) = some (linear_l4_10, tail) := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4077 28 (linear_b70 ++ (44 :: (linear_v4_11 ++ (93 :: tail)))) (linear_v4_11 ++ (93 :: tail)) tail linear_r70 linear_l4_11 (linear_p70 (44 :: (linear_v4_11 ++ (93 :: tail)))) (linear_pl4_11 tail))
def linear_l4_9 : List Raw := linear_r65 :: linear_l4_10
def linear_v4_9 : List Nat := (linear_b65) ++ (44 :: linear_v4_10)
theorem linear_sl4_9 : serializeItems 4079 28 linear_l4_9 = some linear_v4_9 := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 28 linear_r65 linear_r70 linear_l4_11 linear_b65 linear_v4_10 linear_s65 linear_sl4_10)
theorem linear_pl4_9 (tail : List Nat) : parseItems 4079 28 (linear_v4_9 ++ (93 :: tail)) = some (linear_l4_9, tail) := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 28 (linear_b65 ++ (44 :: (linear_v4_10 ++ (93 :: tail)))) (linear_v4_10 ++ (93 :: tail)) tail linear_r65 linear_l4_10 (linear_p65 (44 :: (linear_v4_10 ++ (93 :: tail)))) (linear_pl4_10 tail))
def linear_l4_8 : List Raw := linear_r49 :: linear_l4_9
def linear_v4_8 : List Nat := (linear_b49) ++ (44 :: linear_v4_9)
theorem linear_sl4_8 : serializeItems 4080 28 linear_l4_8 = some linear_v4_8 := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 28 linear_r49 linear_r65 linear_l4_10 linear_b49 linear_v4_9 linear_s49 linear_sl4_9)
theorem linear_pl4_8 (tail : List Nat) : parseItems 4080 28 (linear_v4_8 ++ (93 :: tail)) = some (linear_l4_8, tail) := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 28 (linear_b49 ++ (44 :: (linear_v4_9 ++ (93 :: tail)))) (linear_v4_9 ++ (93 :: tail)) tail linear_r49 linear_l4_9 (linear_p49 (44 :: (linear_v4_9 ++ (93 :: tail)))) (linear_pl4_9 tail))
def linear_l4_7 : List Raw := linear_r44 :: linear_l4_8
def linear_v4_7 : List Nat := (linear_b44) ++ (44 :: linear_v4_8)
theorem linear_sl4_7 : serializeItems 4081 28 linear_l4_7 = some linear_v4_7 := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 28 linear_r44 linear_r49 linear_l4_9 linear_b44 linear_v4_8 linear_s44 linear_sl4_8)
theorem linear_pl4_7 (tail : List Nat) : parseItems 4081 28 (linear_v4_7 ++ (93 :: tail)) = some (linear_l4_7, tail) := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 28 (linear_b44 ++ (44 :: (linear_v4_8 ++ (93 :: tail)))) (linear_v4_8 ++ (93 :: tail)) tail linear_r44 linear_l4_8 (linear_p44 (44 :: (linear_v4_8 ++ (93 :: tail)))) (linear_pl4_8 tail))
def linear_l4_6 : List Raw := linear_r39 :: linear_l4_7
def linear_v4_6 : List Nat := (linear_b39) ++ (44 :: linear_v4_7)
theorem linear_sl4_6 : serializeItems 4082 28 linear_l4_6 = some linear_v4_6 := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4081 28 linear_r39 linear_r44 linear_l4_8 linear_b39 linear_v4_7 linear_s39 linear_sl4_7)
theorem linear_pl4_6 (tail : List Nat) : parseItems 4082 28 (linear_v4_6 ++ (93 :: tail)) = some (linear_l4_6, tail) := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4081 28 (linear_b39 ++ (44 :: (linear_v4_7 ++ (93 :: tail)))) (linear_v4_7 ++ (93 :: tail)) tail linear_r39 linear_l4_7 (linear_p39 (44 :: (linear_v4_7 ++ (93 :: tail)))) (linear_pl4_7 tail))
def linear_l4_5 : List Raw := linear_r34 :: linear_l4_6
def linear_v4_5 : List Nat := (linear_b34) ++ (44 :: linear_v4_6)
theorem linear_sl4_5 : serializeItems 4083 28 linear_l4_5 = some linear_v4_5 := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4082 28 linear_r34 linear_r39 linear_l4_7 linear_b34 linear_v4_6 linear_s34 linear_sl4_6)
theorem linear_pl4_5 (tail : List Nat) : parseItems 4083 28 (linear_v4_5 ++ (93 :: tail)) = some (linear_l4_5, tail) := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4082 28 (linear_b34 ++ (44 :: (linear_v4_6 ++ (93 :: tail)))) (linear_v4_6 ++ (93 :: tail)) tail linear_r34 linear_l4_6 (linear_p34 (44 :: (linear_v4_6 ++ (93 :: tail)))) (linear_pl4_6 tail))
def linear_l4_4 : List Raw := linear_r29 :: linear_l4_5
def linear_v4_4 : List Nat := (linear_b29) ++ (44 :: linear_v4_5)
theorem linear_sl4_4 : serializeItems 4084 28 linear_l4_4 = some linear_v4_4 := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4083 28 linear_r29 linear_r34 linear_l4_6 linear_b29 linear_v4_5 linear_s29 linear_sl4_5)
theorem linear_pl4_4 (tail : List Nat) : parseItems 4084 28 (linear_v4_4 ++ (93 :: tail)) = some (linear_l4_4, tail) := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4083 28 (linear_b29 ++ (44 :: (linear_v4_5 ++ (93 :: tail)))) (linear_v4_5 ++ (93 :: tail)) tail linear_r29 linear_l4_5 (linear_p29 (44 :: (linear_v4_5 ++ (93 :: tail)))) (linear_pl4_5 tail))
def linear_l4_3 : List Raw := linear_r24 :: linear_l4_4
def linear_v4_3 : List Nat := (linear_b24) ++ (44 :: linear_v4_4)
theorem linear_sl4_3 : serializeItems 4085 28 linear_l4_3 = some linear_v4_3 := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4084 28 linear_r24 linear_r29 linear_l4_5 linear_b24 linear_v4_4 linear_s24 linear_sl4_4)
theorem linear_pl4_3 (tail : List Nat) : parseItems 4085 28 (linear_v4_3 ++ (93 :: tail)) = some (linear_l4_3, tail) := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4084 28 (linear_b24 ++ (44 :: (linear_v4_4 ++ (93 :: tail)))) (linear_v4_4 ++ (93 :: tail)) tail linear_r24 linear_l4_4 (linear_p24 (44 :: (linear_v4_4 ++ (93 :: tail)))) (linear_pl4_4 tail))
def linear_l4_2 : List Raw := linear_r15 :: linear_l4_3
def linear_v4_2 : List Nat := (linear_b15) ++ (44 :: linear_v4_3)
theorem linear_sl4_2 : serializeItems 4086 28 linear_l4_2 = some linear_v4_2 := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4085 28 linear_r15 linear_r24 linear_l4_4 linear_b15 linear_v4_3 linear_s15 linear_sl4_3)
theorem linear_pl4_2 (tail : List Nat) : parseItems 4086 28 (linear_v4_2 ++ (93 :: tail)) = some (linear_l4_2, tail) := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4085 28 (linear_b15 ++ (44 :: (linear_v4_3 ++ (93 :: tail)))) (linear_v4_3 ++ (93 :: tail)) tail linear_r15 linear_l4_3 (linear_p15 (44 :: (linear_v4_3 ++ (93 :: tail)))) (linear_pl4_3 tail))
def linear_l4_1 : List Raw := linear_r10 :: linear_l4_2
def linear_v4_1 : List Nat := (linear_b10) ++ (44 :: linear_v4_2)
theorem linear_sl4_1 : serializeItems 4087 28 linear_l4_1 = some linear_v4_1 := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4086 28 linear_r10 linear_r15 linear_l4_3 linear_b10 linear_v4_2 linear_s10 linear_sl4_2)
theorem linear_pl4_1 (tail : List Nat) : parseItems 4087 28 (linear_v4_1 ++ (93 :: tail)) = some (linear_l4_1, tail) := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4086 28 (linear_b10 ++ (44 :: (linear_v4_2 ++ (93 :: tail)))) (linear_v4_2 ++ (93 :: tail)) tail linear_r10 linear_l4_2 (linear_p10 (44 :: (linear_v4_2 ++ (93 :: tail)))) (linear_pl4_2 tail))
def linear_l4_0 : List Raw := linear_r5 :: linear_l4_1
def linear_v4_0 : List Nat := (linear_b5) ++ (44 :: linear_v4_1)
theorem linear_sl4_0 : serializeItems 4088 28 linear_l4_0 = some linear_v4_0 := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4087 28 linear_r5 linear_r10 linear_l4_2 linear_b5 linear_v4_1 linear_s5 linear_sl4_1)
theorem linear_pl4_0 (tail : List Nat) : parseItems 4088 28 (linear_v4_0 ++ (93 :: tail)) = some (linear_l4_0, tail) := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4087 28 (linear_b5 ++ (44 :: (linear_v4_1 ++ (93 :: tail)))) (linear_v4_1 ++ (93 :: tail)) tail linear_r5 linear_l4_1 (linear_p5 (44 :: (linear_v4_1 ++ (93 :: tail)))) (linear_pl4_1 tail))
def linear_r4 : Raw := (.arr linear_l4_0)
def linear_b4 : List Nat := linear_g8 ++ (linear_v4_0 ++ linear_g382)
theorem linear_s4 : serializeRaw 4089 29 linear_r4 = some linear_b4 := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4088 28 linear_l4_0 linear_v4_0 linear_sl4_0)
theorem linear_p4 (tail : List Nat) : parseRaw 4089 29 (linear_b4 ++ tail) = some (linear_r4, tail) := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4088 28 (linear_v4_0 ++ (93 :: tail)) tail linear_l4_0 (by intro h; cases h) (linear_pl4_0 tail))
def linear_r150 : Raw := (.arr [(.str [97,108,108,111,99]),(.str [114,101,97,100]),(.str [116,114,97,112]),(.str [119,114,105,116,101])])
def linear_b150 : List Nat := linear_g385
theorem linear_s150 : serializeRaw 4088 29 linear_r150 = some linear_b150 := by decide +kernel
theorem linear_p150 (tail : List Nat) : parseRaw 4088 29 (linear_b150 ++ tail) = some (linear_r150, tail) := by rfl
def linear_r151 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b151 : List Nat := linear_g388
theorem linear_s151 : serializeRaw 4087 29 linear_r151 = some linear_b151 := by decide +kernel
theorem linear_p151 (tail : List Nat) : parseRaw 4087 29 (linear_b151 ++ tail) = some (linear_r151, tail) := by rfl
def linear_r152 : Raw := (.str [99,97,108,99,117,108,97,116,101])
def linear_b152 : List Nat := linear_g391
theorem linear_s152 : serializeRaw 4086 29 linear_r152 = some linear_b152 := by decide +kernel
theorem linear_p152 (tail : List Nat) : parseRaw 4086 29 (linear_b152 ++ tail) = some (linear_r152, tail) := by rfl
def linear_r153 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b153 : List Nat := linear_g394
theorem linear_s153 : serializeRaw 4085 29 linear_r153 = some linear_b153 := by decide +kernel
theorem linear_p153 (tail : List Nat) : parseRaw 4085 29 (linear_b153 ++ tail) = some (linear_r153, tail) := by rfl
def linear_r154 : Raw := (.arr [(.str [117,54,52])])
def linear_b154 : List Nat := linear_g397
theorem linear_s154 : serializeRaw 4084 29 linear_r154 = some linear_b154 := by decide +kernel
theorem linear_p154 (tail : List Nat) : parseRaw 4084 29 (linear_b154 ++ tail) = some (linear_r154, tail) := by rfl
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.linear_kd113_0
#print axioms HiaCoreSyntaxSlice.linear_kd113_1
#print axioms HiaCoreSyntaxSlice.linear_kd113_2
#print axioms HiaCoreSyntaxSlice.linear_kd113_3
#print axioms HiaCoreSyntaxSlice.linear_kd118_0
#print axioms HiaCoreSyntaxSlice.linear_kd118_1
#print axioms HiaCoreSyntaxSlice.linear_kd118_2
#print axioms HiaCoreSyntaxSlice.linear_kd118_3
#print axioms HiaCoreSyntaxSlice.linear_kd123_0
#print axioms HiaCoreSyntaxSlice.linear_kd123_1
#print axioms HiaCoreSyntaxSlice.linear_kd123_2
#print axioms HiaCoreSyntaxSlice.linear_kd123_3
#print axioms HiaCoreSyntaxSlice.linear_kd135_0
#print axioms HiaCoreSyntaxSlice.linear_kd135_1
#print axioms HiaCoreSyntaxSlice.linear_kd135_2
#print axioms HiaCoreSyntaxSlice.linear_kd135_3
#print axioms HiaCoreSyntaxSlice.linear_kd140_0
#print axioms HiaCoreSyntaxSlice.linear_kd140_1
#print axioms HiaCoreSyntaxSlice.linear_kd140_2
#print axioms HiaCoreSyntaxSlice.linear_kd140_3
#print axioms HiaCoreSyntaxSlice.linear_kd145_0
#print axioms HiaCoreSyntaxSlice.linear_kd145_1
#print axioms HiaCoreSyntaxSlice.linear_kd145_2
#print axioms HiaCoreSyntaxSlice.linear_kd145_3
#print axioms HiaCoreSyntaxSlice.linear_kd97_0
#print axioms HiaCoreSyntaxSlice.linear_kd97_1
#print axioms HiaCoreSyntaxSlice.linear_kd97_2
#print axioms HiaCoreSyntaxSlice.linear_kd97_3
#print axioms HiaCoreSyntaxSlice.linear_kp113_0
#print axioms HiaCoreSyntaxSlice.linear_kp113_1
#print axioms HiaCoreSyntaxSlice.linear_kp113_2
#print axioms HiaCoreSyntaxSlice.linear_kp113_3
#print axioms HiaCoreSyntaxSlice.linear_kp118_0
#print axioms HiaCoreSyntaxSlice.linear_kp118_1
#print axioms HiaCoreSyntaxSlice.linear_kp118_2
#print axioms HiaCoreSyntaxSlice.linear_kp118_3
#print axioms HiaCoreSyntaxSlice.linear_kp123_0
#print axioms HiaCoreSyntaxSlice.linear_kp123_1
#print axioms HiaCoreSyntaxSlice.linear_kp123_2
#print axioms HiaCoreSyntaxSlice.linear_kp123_3
#print axioms HiaCoreSyntaxSlice.linear_kp135_0
#print axioms HiaCoreSyntaxSlice.linear_kp135_1
#print axioms HiaCoreSyntaxSlice.linear_kp135_2
#print axioms HiaCoreSyntaxSlice.linear_kp135_3
#print axioms HiaCoreSyntaxSlice.linear_kp140_0
#print axioms HiaCoreSyntaxSlice.linear_kp140_1
#print axioms HiaCoreSyntaxSlice.linear_kp140_2
#print axioms HiaCoreSyntaxSlice.linear_kp140_3
#print axioms HiaCoreSyntaxSlice.linear_kp145_0
#print axioms HiaCoreSyntaxSlice.linear_kp145_1
#print axioms HiaCoreSyntaxSlice.linear_kp145_2
#print axioms HiaCoreSyntaxSlice.linear_kp145_3
#print axioms HiaCoreSyntaxSlice.linear_kp97_0
#print axioms HiaCoreSyntaxSlice.linear_kp97_1
#print axioms HiaCoreSyntaxSlice.linear_kp97_2
#print axioms HiaCoreSyntaxSlice.linear_kp97_3
#print axioms HiaCoreSyntaxSlice.linear_o113
#print axioms HiaCoreSyntaxSlice.linear_o118
#print axioms HiaCoreSyntaxSlice.linear_o123
#print axioms HiaCoreSyntaxSlice.linear_o135
#print axioms HiaCoreSyntaxSlice.linear_o140
#print axioms HiaCoreSyntaxSlice.linear_o145
#print axioms HiaCoreSyntaxSlice.linear_o97
#print axioms HiaCoreSyntaxSlice.linear_p111
#print axioms HiaCoreSyntaxSlice.linear_p112
#print axioms HiaCoreSyntaxSlice.linear_p113
#print axioms HiaCoreSyntaxSlice.linear_p114
#print axioms HiaCoreSyntaxSlice.linear_p115
#print axioms HiaCoreSyntaxSlice.linear_p116
#print axioms HiaCoreSyntaxSlice.linear_p117
#print axioms HiaCoreSyntaxSlice.linear_p118
#print axioms HiaCoreSyntaxSlice.linear_p119
#print axioms HiaCoreSyntaxSlice.linear_p120
#print axioms HiaCoreSyntaxSlice.linear_p121
#print axioms HiaCoreSyntaxSlice.linear_p122
#print axioms HiaCoreSyntaxSlice.linear_p123
#print axioms HiaCoreSyntaxSlice.linear_p124
#print axioms HiaCoreSyntaxSlice.linear_p125
#print axioms HiaCoreSyntaxSlice.linear_p126
#print axioms HiaCoreSyntaxSlice.linear_p127
#print axioms HiaCoreSyntaxSlice.linear_p128
#print axioms HiaCoreSyntaxSlice.linear_p129
#print axioms HiaCoreSyntaxSlice.linear_p130
#print axioms HiaCoreSyntaxSlice.linear_p131
#print axioms HiaCoreSyntaxSlice.linear_p132
#print axioms HiaCoreSyntaxSlice.linear_p133
#print axioms HiaCoreSyntaxSlice.linear_p134
#print axioms HiaCoreSyntaxSlice.linear_p135
#print axioms HiaCoreSyntaxSlice.linear_p136
#print axioms HiaCoreSyntaxSlice.linear_p137
#print axioms HiaCoreSyntaxSlice.linear_p138
#print axioms HiaCoreSyntaxSlice.linear_p139
#print axioms HiaCoreSyntaxSlice.linear_p140
#print axioms HiaCoreSyntaxSlice.linear_p141
#print axioms HiaCoreSyntaxSlice.linear_p142
#print axioms HiaCoreSyntaxSlice.linear_p143
#print axioms HiaCoreSyntaxSlice.linear_p144
#print axioms HiaCoreSyntaxSlice.linear_p145
#print axioms HiaCoreSyntaxSlice.linear_p146
#print axioms HiaCoreSyntaxSlice.linear_p147
#print axioms HiaCoreSyntaxSlice.linear_p148
#print axioms HiaCoreSyntaxSlice.linear_p149
#print axioms HiaCoreSyntaxSlice.linear_p150
#print axioms HiaCoreSyntaxSlice.linear_p151
#print axioms HiaCoreSyntaxSlice.linear_p152
#print axioms HiaCoreSyntaxSlice.linear_p153
#print axioms HiaCoreSyntaxSlice.linear_p154
#print axioms HiaCoreSyntaxSlice.linear_p4
#print axioms HiaCoreSyntaxSlice.linear_p97
#print axioms HiaCoreSyntaxSlice.linear_p99
#print axioms HiaCoreSyntaxSlice.linear_pl113_0
#print axioms HiaCoreSyntaxSlice.linear_pl113_1
#print axioms HiaCoreSyntaxSlice.linear_pl113_2
#print axioms HiaCoreSyntaxSlice.linear_pl113_3
#print axioms HiaCoreSyntaxSlice.linear_pl118_0
#print axioms HiaCoreSyntaxSlice.linear_pl118_1
#print axioms HiaCoreSyntaxSlice.linear_pl118_2
#print axioms HiaCoreSyntaxSlice.linear_pl118_3
#print axioms HiaCoreSyntaxSlice.linear_pl123_0
#print axioms HiaCoreSyntaxSlice.linear_pl123_1
#print axioms HiaCoreSyntaxSlice.linear_pl123_2
#print axioms HiaCoreSyntaxSlice.linear_pl123_3
#print axioms HiaCoreSyntaxSlice.linear_pl125_0
#print axioms HiaCoreSyntaxSlice.linear_pl125_1
#print axioms HiaCoreSyntaxSlice.linear_pl125_2
#print axioms HiaCoreSyntaxSlice.linear_pl125_3
#print axioms HiaCoreSyntaxSlice.linear_pl125_4
#print axioms HiaCoreSyntaxSlice.linear_pl125_5
#print axioms HiaCoreSyntaxSlice.linear_pl125_6
#print axioms HiaCoreSyntaxSlice.linear_pl135_0
#print axioms HiaCoreSyntaxSlice.linear_pl135_1
#print axioms HiaCoreSyntaxSlice.linear_pl135_2
#print axioms HiaCoreSyntaxSlice.linear_pl135_3
#print axioms HiaCoreSyntaxSlice.linear_pl140_0
#print axioms HiaCoreSyntaxSlice.linear_pl140_1
#print axioms HiaCoreSyntaxSlice.linear_pl140_2
#print axioms HiaCoreSyntaxSlice.linear_pl140_3
#print axioms HiaCoreSyntaxSlice.linear_pl145_0
#print axioms HiaCoreSyntaxSlice.linear_pl145_1
#print axioms HiaCoreSyntaxSlice.linear_pl145_2
#print axioms HiaCoreSyntaxSlice.linear_pl145_3
#print axioms HiaCoreSyntaxSlice.linear_pl4_0
#print axioms HiaCoreSyntaxSlice.linear_pl4_1
#print axioms HiaCoreSyntaxSlice.linear_pl4_10
#print axioms HiaCoreSyntaxSlice.linear_pl4_11
#print axioms HiaCoreSyntaxSlice.linear_pl4_12
#print axioms HiaCoreSyntaxSlice.linear_pl4_13
#print axioms HiaCoreSyntaxSlice.linear_pl4_14
#print axioms HiaCoreSyntaxSlice.linear_pl4_15
#print axioms HiaCoreSyntaxSlice.linear_pl4_16
#print axioms HiaCoreSyntaxSlice.linear_pl4_17
#print axioms HiaCoreSyntaxSlice.linear_pl4_18
#print axioms HiaCoreSyntaxSlice.linear_pl4_19
#print axioms HiaCoreSyntaxSlice.linear_pl4_2
#print axioms HiaCoreSyntaxSlice.linear_pl4_20
#print axioms HiaCoreSyntaxSlice.linear_pl4_3
#print axioms HiaCoreSyntaxSlice.linear_pl4_4
#print axioms HiaCoreSyntaxSlice.linear_pl4_5
#print axioms HiaCoreSyntaxSlice.linear_pl4_6
#print axioms HiaCoreSyntaxSlice.linear_pl4_7
#print axioms HiaCoreSyntaxSlice.linear_pl4_8
#print axioms HiaCoreSyntaxSlice.linear_pl4_9
#print axioms HiaCoreSyntaxSlice.linear_pl97_0
#print axioms HiaCoreSyntaxSlice.linear_pl97_1
#print axioms HiaCoreSyntaxSlice.linear_pl97_2
#print axioms HiaCoreSyntaxSlice.linear_pl97_3
#print axioms HiaCoreSyntaxSlice.linear_pl99_0
#print axioms HiaCoreSyntaxSlice.linear_s111
#print axioms HiaCoreSyntaxSlice.linear_s112
#print axioms HiaCoreSyntaxSlice.linear_s113
#print axioms HiaCoreSyntaxSlice.linear_s114
#print axioms HiaCoreSyntaxSlice.linear_s115
#print axioms HiaCoreSyntaxSlice.linear_s116
#print axioms HiaCoreSyntaxSlice.linear_s117
#print axioms HiaCoreSyntaxSlice.linear_s118
#print axioms HiaCoreSyntaxSlice.linear_s119
#print axioms HiaCoreSyntaxSlice.linear_s120
#print axioms HiaCoreSyntaxSlice.linear_s121
#print axioms HiaCoreSyntaxSlice.linear_s122
#print axioms HiaCoreSyntaxSlice.linear_s123
#print axioms HiaCoreSyntaxSlice.linear_s124
#print axioms HiaCoreSyntaxSlice.linear_s125
#print axioms HiaCoreSyntaxSlice.linear_s126
#print axioms HiaCoreSyntaxSlice.linear_s127
#print axioms HiaCoreSyntaxSlice.linear_s128
#print axioms HiaCoreSyntaxSlice.linear_s129
#print axioms HiaCoreSyntaxSlice.linear_s130
#print axioms HiaCoreSyntaxSlice.linear_s131
#print axioms HiaCoreSyntaxSlice.linear_s132
#print axioms HiaCoreSyntaxSlice.linear_s133
#print axioms HiaCoreSyntaxSlice.linear_s134
#print axioms HiaCoreSyntaxSlice.linear_s135
#print axioms HiaCoreSyntaxSlice.linear_s136
#print axioms HiaCoreSyntaxSlice.linear_s137
#print axioms HiaCoreSyntaxSlice.linear_s138
#print axioms HiaCoreSyntaxSlice.linear_s139
#print axioms HiaCoreSyntaxSlice.linear_s140
#print axioms HiaCoreSyntaxSlice.linear_s141
#print axioms HiaCoreSyntaxSlice.linear_s142
#print axioms HiaCoreSyntaxSlice.linear_s143
#print axioms HiaCoreSyntaxSlice.linear_s144
#print axioms HiaCoreSyntaxSlice.linear_s145
#print axioms HiaCoreSyntaxSlice.linear_s146
#print axioms HiaCoreSyntaxSlice.linear_s147
#print axioms HiaCoreSyntaxSlice.linear_s148
#print axioms HiaCoreSyntaxSlice.linear_s149
#print axioms HiaCoreSyntaxSlice.linear_s150
#print axioms HiaCoreSyntaxSlice.linear_s151
#print axioms HiaCoreSyntaxSlice.linear_s152
#print axioms HiaCoreSyntaxSlice.linear_s153
#print axioms HiaCoreSyntaxSlice.linear_s154
#print axioms HiaCoreSyntaxSlice.linear_s4
#print axioms HiaCoreSyntaxSlice.linear_s97
#print axioms HiaCoreSyntaxSlice.linear_s99
#print axioms HiaCoreSyntaxSlice.linear_sl113_0
#print axioms HiaCoreSyntaxSlice.linear_sl113_1
#print axioms HiaCoreSyntaxSlice.linear_sl113_2
#print axioms HiaCoreSyntaxSlice.linear_sl113_3
#print axioms HiaCoreSyntaxSlice.linear_sl118_0
#print axioms HiaCoreSyntaxSlice.linear_sl118_1
#print axioms HiaCoreSyntaxSlice.linear_sl118_2
#print axioms HiaCoreSyntaxSlice.linear_sl118_3
#print axioms HiaCoreSyntaxSlice.linear_sl123_0
#print axioms HiaCoreSyntaxSlice.linear_sl123_1
#print axioms HiaCoreSyntaxSlice.linear_sl123_2
#print axioms HiaCoreSyntaxSlice.linear_sl123_3
#print axioms HiaCoreSyntaxSlice.linear_sl125_0
#print axioms HiaCoreSyntaxSlice.linear_sl125_1
#print axioms HiaCoreSyntaxSlice.linear_sl125_2
#print axioms HiaCoreSyntaxSlice.linear_sl125_3
#print axioms HiaCoreSyntaxSlice.linear_sl125_4
#print axioms HiaCoreSyntaxSlice.linear_sl125_5
#print axioms HiaCoreSyntaxSlice.linear_sl125_6
#print axioms HiaCoreSyntaxSlice.linear_sl135_0
#print axioms HiaCoreSyntaxSlice.linear_sl135_1
#print axioms HiaCoreSyntaxSlice.linear_sl135_2
#print axioms HiaCoreSyntaxSlice.linear_sl135_3
#print axioms HiaCoreSyntaxSlice.linear_sl140_0
#print axioms HiaCoreSyntaxSlice.linear_sl140_1
#print axioms HiaCoreSyntaxSlice.linear_sl140_2
#print axioms HiaCoreSyntaxSlice.linear_sl140_3
#print axioms HiaCoreSyntaxSlice.linear_sl145_0
#print axioms HiaCoreSyntaxSlice.linear_sl145_1
#print axioms HiaCoreSyntaxSlice.linear_sl145_2
#print axioms HiaCoreSyntaxSlice.linear_sl145_3
#print axioms HiaCoreSyntaxSlice.linear_sl4_0
#print axioms HiaCoreSyntaxSlice.linear_sl4_1
#print axioms HiaCoreSyntaxSlice.linear_sl4_10
#print axioms HiaCoreSyntaxSlice.linear_sl4_11
#print axioms HiaCoreSyntaxSlice.linear_sl4_12
#print axioms HiaCoreSyntaxSlice.linear_sl4_13
#print axioms HiaCoreSyntaxSlice.linear_sl4_14
#print axioms HiaCoreSyntaxSlice.linear_sl4_15
#print axioms HiaCoreSyntaxSlice.linear_sl4_16
#print axioms HiaCoreSyntaxSlice.linear_sl4_17
#print axioms HiaCoreSyntaxSlice.linear_sl4_18
#print axioms HiaCoreSyntaxSlice.linear_sl4_19
#print axioms HiaCoreSyntaxSlice.linear_sl4_2
#print axioms HiaCoreSyntaxSlice.linear_sl4_20
#print axioms HiaCoreSyntaxSlice.linear_sl4_3
#print axioms HiaCoreSyntaxSlice.linear_sl4_4
#print axioms HiaCoreSyntaxSlice.linear_sl4_5
#print axioms HiaCoreSyntaxSlice.linear_sl4_6
#print axioms HiaCoreSyntaxSlice.linear_sl4_7
#print axioms HiaCoreSyntaxSlice.linear_sl4_8
#print axioms HiaCoreSyntaxSlice.linear_sl4_9
#print axioms HiaCoreSyntaxSlice.linear_sl97_0
#print axioms HiaCoreSyntaxSlice.linear_sl97_1
#print axioms HiaCoreSyntaxSlice.linear_sl97_2
#print axioms HiaCoreSyntaxSlice.linear_sl97_3
#print axioms HiaCoreSyntaxSlice.linear_sl99_0
