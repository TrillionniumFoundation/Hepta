import Lean.Elab.Tactic.Omega

/-!
A mathematical byte-memory model for the full-write-before-read optimization.
`none` is an uninitialized byte.  The fill schedule is exactly 0, 1, ..., n-1;
values are an arbitrary function independent of the initial byte contents.

This file does not import a HIA CFG, model an allocator or prove Python/LLVM
refinement.  The separate conservative CFG checker must establish this exact
schedule, common allocation identity, absence of early reads/escapes and that
the completed-fill exit dominates every subsequent byte read.  Native bounds,
allocation success/failure, zero-length and release remain separate obligations.
-/

namespace HiaInitializationPrefix

abbrev Byte := BitVec 8
abbrev Memory := Nat → Option Byte

def empty : Memory := fun _ => none
def zeroed : Memory := fun _ => some (BitVec.ofNat 8 0)

def write (memory : Memory) (index : Nat) (value : Byte) : Memory :=
  fun address => if address = index then some value else memory address

def fillPrefix (initial : Memory) (values : Nat → Byte) : Nat → Memory
  | 0 => initial
  | count + 1 => write (fillPrefix initial values count) count (values count)

def PrefixValues (memory : Memory) (values : Nat → Byte) (count : Nat) : Prop :=
  ∀ address, address < count → memory address = some (values address)

def FullyInitialized (memory : Memory) (length : Nat) : Prop :=
  ∀ address, address < length → ∃ value, memory address = some value

theorem write_at_index (memory : Memory) (index : Nat) (value : Byte) :
    write memory index value index = some value := by
  simp [write]

theorem write_at_other (memory : Memory) (index address : Nat) (value : Byte)
    (different : address ≠ index) :
    write memory index value address = memory address := by
  simp [write, different]

theorem zero_prefix (initial : Memory) (values : Nat → Byte) :
    fillPrefix initial values 0 = initial := rfl

theorem write_extends_prefix (memory : Memory) (values : Nat → Byte) (index : Nat)
    (before : PrefixValues memory values index) :
    PrefixValues (write memory index (values index)) values (index + 1) := by
  intro address below
  by_cases equal : address = index
  · subst address
    exact write_at_index memory index (values index)
  · have earlier : address < index := by omega
    simpa [write, equal] using before address earlier

theorem prefix_value (initial : Memory) (values : Nat → Byte) (count address : Nat)
    (below : address < count) :
    fillPrefix initial values count address = some (values address) := by
  induction count generalizing address with
  | zero => omega
  | succ count previous =>
      by_cases equal : address = count
      · subst address
        simp [fillPrefix, write]
      · have earlier : address < count := by omega
        simpa [fillPrefix, write, equal] using previous address earlier

theorem prefix_outside (initial : Memory) (values : Nat → Byte) (count address : Nat)
    (outside : count ≤ address) :
    fillPrefix initial values count address = initial address := by
  induction count with
  | zero => rfl
  | succ count previous =>
      have different : address ≠ count := by omega
      have before : count ≤ address := by omega
      simpa [fillPrefix, write, different] using previous before

theorem prefix_invariant (initial : Memory) (values : Nat → Byte) (count : Nat) :
    PrefixValues (fillPrefix initial values count) values count := by
  intro address below
  exact prefix_value initial values count address below

theorem completed_fill_initialized (initial : Memory) (values : Nat → Byte) (length : Nat) :
    FullyInitialized (fillPrefix initial values length) length := by
  intro address below
  exact ⟨values address, prefix_value initial values length address below⟩

theorem completed_fill_independent_of_initial (left right : Memory) (values : Nat → Byte)
    (length address : Nat) (below : address < length) :
    fillPrefix left values length address = fillPrefix right values length address := by
  rw [prefix_value left values length address below,
      prefix_value right values length address below]

theorem completed_fill_matches_zeroed (initial : Memory) (values : Nat → Byte)
    (length address : Nat) (below : address < length) :
    fillPrefix initial values length address = fillPrefix zeroed values length address :=
  completed_fill_independent_of_initial initial zeroed values length address below

theorem increment_within_limit (index length maximum : Nat)
    (continues : index < length) (bounded : length ≤ maximum) :
    index + 1 ≤ maximum := by omega

theorem completed_exit_is_exact_bound (index length : Nat)
    (invariant : index ≤ length) (exit : ¬ index < length) :
    index = length := by omega

theorem completed_exit_establishes_initialized (memory : Memory) (values : Nat → Byte)
    (index length : Nat) (initializedPrefix : PrefixValues memory values index)
    (invariant : index ≤ length) (exit : ¬ index < length) :
    FullyInitialized memory length := by
  have finished : index = length := completed_exit_is_exact_bound index length invariant exit
  intro address below
  exact ⟨values address, initializedPrefix address (by omega)⟩

theorem incomplete_prefix_is_not_full (values : Nat → Byte) (written length : Nat)
    (incomplete : written < length) :
    ¬ FullyInitialized (fillPrefix empty values written) length := by
  intro complete
  obtain ⟨value, found⟩ := complete written incomplete
  have absent : fillPrefix empty values written written = none := by
    simpa [empty] using prefix_outside empty values written written (Nat.le_refl written)
  rw [absent] at found
  contradiction

def fillFromOne (values : Nat → Byte) : Nat → Memory
  | 0 => empty
  | count + 1 => write (fillFromOne values count) (count + 1) (values (count + 1))

theorem skipped_zero_stays_uninitialized (values : Nat → Byte) (count : Nat) :
    fillFromOne values count 0 = none := by
  induction count with
  | zero => rfl
  | succ count previous => simpa [fillFromOne, write] using previous

def fillStrideTwo (values : Nat → Byte) : Nat → Memory
  | 0 => empty
  | count + 1 => write (fillStrideTwo values count) (count * 2) (values (count * 2))

theorem stride_two_leaves_a_hole (values : Nat → Byte) (count : Nat) :
    fillStrideTwo values count 1 = none := by
  induction count with
  | zero => rfl
  | succ count previous =>
      have different : 1 ≠ count * 2 := by omega
      simpa [fillStrideTwo, write, different] using previous

#print axioms write_at_index
#print axioms write_at_other
#print axioms zero_prefix
#print axioms write_extends_prefix
#print axioms prefix_value
#print axioms prefix_outside
#print axioms prefix_invariant
#print axioms completed_fill_initialized
#print axioms completed_fill_independent_of_initial
#print axioms completed_fill_matches_zeroed
#print axioms increment_within_limit
#print axioms completed_exit_is_exact_bound
#print axioms completed_exit_establishes_initialized
#print axioms incomplete_prefix_is_not_full
#print axioms skipped_zero_stays_uninitialized
#print axioms stride_two_leaves_a_hole

end HiaInitializationPrefix

/-!
UNCHECKED proof text until acceptance by the repository-pinned Lean CI lane.
Append after the exact HiaInitializationPrefix.lean input (no extra imports).

This is a partial scalar projection of a selected true edge and a local add,
not a Core interpreter or memory model. It does not establish arrival at the
add, body framing, definition of every edge operand, allocation identity,
exporter/parser refinement, or a whole-loop/backend/resource theorem.
-/

namespace HiaGuardedUsizeSlice

inductive TypeTag where
  | usize
  | other
  deriving DecidableEq, Repr

inductive CompareOp where
  | lt
  | le
  | other
  deriving DecidableEq, Repr

inductive Arm where
  | thenArm
  | elseArm
  deriving DecidableEq, Repr

inductive AddOp where
  | checked
  | wrapping
  | other
  deriving DecidableEq, Repr

inductive Value where
  | usize (value : Nat)
  | opaque
  deriving DecidableEq, Repr

abbrev Env := Nat → Option Value

structure Descriptor where
  sourceIndex : Nat
  sourceExtent : Nat
  compareOutput : Nat
  branchCondition : Nat
  indexType : TypeTag
  extentType : TypeTag
  compareOp : CompareOp
  selectedArm : Arm
  incoming : List Nat
  indexSlot : Nat
  extentSlot : Nat
  addIndexSlot : Nat
  addOp : AddOp
  addType : TypeTag
  literalType : TypeTag
  literalValue : Nat
  literalOrdinal : Nat
  addOrdinal : Nat
  deriving DecidableEq, Repr

/-- All validation facts are computed from the descriptor, not proof fields. -/
def Valid (d : Descriptor) : Prop :=
  d.indexType = .usize ∧
  d.extentType = .usize ∧
  d.compareOp = .lt ∧
  d.branchCondition = d.compareOutput ∧
  d.selectedArm = .thenArm ∧
  d.incoming[d.indexSlot]? = some d.sourceIndex ∧
  d.incoming[d.extentSlot]? = some d.sourceExtent ∧
  d.addIndexSlot = d.indexSlot ∧
  d.addOp ≠ .other ∧
  d.addType = .usize ∧
  d.literalType = .usize ∧
  d.literalValue = 1 ∧
  d.literalOrdinal < d.addOrdinal

instance (d : Descriptor) : Decidable (Valid d) := by
  unfold Valid
  infer_instance

/-- Opaque, absent, or out-of-range values cannot be used as usize. -/
def readUsize (maximum : Nat) (env : Env) (slot : Nat) : Option Nat :=
  match env slot with
  | some (.usize n) => if n ≤ maximum then some n else none
  | _ => none

/-- Every lookup reads the same immutable incoming environment. -/
def phiEnv (d : Descriptor) (env : Env) : Env := fun slot =>
  match d.incoming[slot]? with -- MUTATION_SITE_PHI_LOOKUP
  | some source => env source
  | none => none

def evalGuard (maximum : Nat) (d : Descriptor) (env : Env) : Option Bool :=
  match readUsize maximum env d.sourceIndex,
      readUsize maximum env d.sourceExtent with
  | some index, some extent =>
    match d.compareOp with
    | .lt => some (decide (index < extent))
    | .le => some (decide (index ≤ extent))
    | .other => none
  | _, _ => none

/-- The literal is a direct operand. It is never installed into phiEnv. -/
def evalAdd (mode : AddOp) (maximum index literal : Nat) : Option Nat :=
  let sum := index + literal -- MUTATION_SITE_ADD_LITERAL
  match mode with
  | .checked => if sum ≤ maximum then some sum else none
  | .wrapping => some (sum % (maximum + 1))
  | .other => none

def evalStep (mode : AddOp) (maximum : Nat) (d : Descriptor) (env : Env) : Option Nat :=
  if Valid d then
    if evalGuard maximum d env = some true then -- MUTATION_SITE_STEP_GUARD
      match readUsize maximum (phiEnv d env) d.addIndexSlot,
          readUsize maximum (phiEnv d env) d.extentSlot with
      | some index, some _extent => evalAdd mode maximum index d.literalValue
      | _, _ => none
    else none
  else none

def evalSelectedStep (maximum : Nat) (d : Descriptor) (env : Env) : Option Nat :=
  evalStep d.addOp maximum d env

theorem readUsize_bounded (maximum : Nat) (env : Env) (slot n : Nat)
    (read : readUsize maximum env slot = some n) : n ≤ maximum := by
  unfold readUsize at read
  cases hvalue : env slot with
  | none => simp [hvalue] at read
  | some value =>
    cases value with
    | «opaque» => simp [hvalue] at read
    | usize value =>
      by_cases bounded : value ≤ maximum
      · have same : value = n := by simpa [hvalue, bounded] using read
        omega
      · simp [hvalue, bounded] at read

theorem readUsize_phi (maximum : Nat) (d : Descriptor) (env : Env)
    (slot source : Nat) (position : d.incoming[slot]? = some source) :
    readUsize maximum (phiEnv d env) slot = readUsize maximum env source := by
  simp [readUsize, phiEnv, position]

/-- Strictness and source values are derived from the actual guard evaluation. -/
theorem guard_values (maximum : Nat) (d : Descriptor) (env : Env)
    (strict : d.compareOp = .lt)
    (guard : evalGuard maximum d env = some true) :
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧ index < extent := by
  unfold evalGuard at guard
  cases hi : readUsize maximum env d.sourceIndex with
  | none => simp [hi] at guard
  | some index =>
    cases hn : readUsize maximum env d.sourceExtent with
    | none => simp [hi, hn] at guard
    | some extent =>
      have below : index < extent := by simpa [hi, hn, strict] using guard
      exact ⟨index, extent, rfl, rfl, below⟩

theorem checked_add_in_range (maximum index : Nat) (bounded : index + 1 ≤ maximum) :
    evalAdd .checked maximum index 1 = some (index + 1) := by
  simp [evalAdd, bounded]

theorem wrapping_add_in_range (maximum index : Nat) (bounded : index + 1 ≤ maximum) :
    evalAdd .wrapping maximum index 1 = some (index + 1) := by
  have below : index + 1 < maximum + 1 := by omega
  simp [evalAdd, Nat.mod_eq_of_lt below]

/-- Existence of BOTH successful additions, for arbitrary environments and valid
    descriptors. No caller-supplied i<N or phi-value premise is used. -/
theorem guarded_successors (maximum : Nat) (d : Descriptor) (env : Env)
    (valid : Valid d) (guard : evalGuard maximum d env = some true) :
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧
      index < extent ∧
      evalStep .checked maximum d env = some (index + 1) ∧
      evalStep .wrapping maximum d env = some (index + 1) ∧
      index + 1 ≤ extent ∧ extent ≤ maximum ∧ index + 1 ≤ maximum := by
  have validCopy := valid
  obtain ⟨_indexType, _extentType, strict, _condition, _arm,
    indexPosition, extentPosition, addPosition, _mode, _addType,
    _literalType, one, _order⟩ := validCopy
  obtain ⟨index, extent, hi, hn, below⟩ := guard_values maximum d env strict guard
  have extentBound := readUsize_bounded maximum env d.sourceExtent extent hn
  have successorBound : index + 1 ≤ maximum :=
    HiaInitializationPrefix.increment_within_limit index extent maximum below extentBound
  have indexRead : readUsize maximum (phiEnv d env) d.addIndexSlot = some index := by
    rw [addPosition, readUsize_phi maximum d env d.indexSlot d.sourceIndex indexPosition]
    exact hi
  have extentRead : readUsize maximum (phiEnv d env) d.extentSlot = some extent := by
    rw [readUsize_phi maximum d env d.extentSlot d.sourceExtent extentPosition]
    exact hn
  have checked : evalStep .checked maximum d env = some (index + 1) := by
    simpa [evalStep, valid, guard, indexRead, extentRead, one] using
      checked_add_in_range maximum index successorBound
  have wrapping : evalStep .wrapping maximum d env = some (index + 1) := by
    simpa [evalStep, valid, guard, indexRead, extentRead, one] using
      wrapping_add_in_range maximum index successorBound
  exact ⟨index, extent, hi, hn, below, checked, wrapping, by omega,
    extentBound, successorBound⟩

/-- In particular the descriptor's actual selected opcode has a successor. -/
theorem selected_successor (maximum : Nat) (d : Descriptor) (env : Env)
    (valid : Valid d) (guard : evalGuard maximum d env = some true) :
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧
      evalSelectedStep maximum d env = some (index + 1) ∧
      index + 1 ≤ extent ∧ extent ≤ maximum ∧ index + 1 ≤ maximum := by
  obtain ⟨index, extent, hi, hn, _below, checked, wrapping, within, extentBound,
    successorBound⟩ := guarded_successors maximum d env valid guard
  have supported : d.addOp ≠ .other := valid.2.2.2.2.2.2.2.2.1
  have selected : evalSelectedStep maximum d env = some (index + 1) := by
    unfold evalSelectedStep
    cases mode : d.addOp with
    | checked => exact checked
    | wrapping => exact wrapping
    | other => exact False.elim (supported mode)
  exact ⟨index, extent, hi, hn, selected, within, extentBound, successorBound⟩

/-- Negative semantic obligation: bypassing the guard must not validate. -/
theorem false_guard_no_step (mode : AddOp) (maximum : Nat) (d : Descriptor) (env : Env)
    (guard : evalGuard maximum d env ≠ some true) :
    evalStep mode maximum d env = none := by
  simp [evalStep, guard]

theorem invalid_no_step (mode : AddOp) (maximum : Nat) (d : Descriptor) (env : Env)
    (invalid : ¬ Valid d) : evalStep mode maximum d env = none := by
  simp [evalStep, invalid]

#print axioms readUsize_bounded
#print axioms readUsize_phi
#print axioms guard_values
#print axioms checked_add_in_range
#print axioms wrapping_add_in_range
#print axioms guarded_successors
#print axioms selected_successor
#print axioms false_guard_no_step
#print axioms invalid_no_step

end HiaGuardedUsizeSlice


namespace HiaGuardedUsizeSlice
def linear_0 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 9,
  addOrdinal := 10
}
theorem linear_0_valid : Valid linear_0 := by decide
def linear_0_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem linear_0_small : evalGuard 18446744073709551615 linear_0 linear_0_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_0 linear_0_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_0 linear_0_small_env = some 1 := by decide
def linear_0_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem linear_0_upper : evalGuard 18446744073709551615 linear_0 linear_0_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_0 linear_0_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_0 linear_0_upper_env = some 18446744073709551615 := by decide
#print axioms linear_0_valid
#print axioms linear_0_small
#print axioms linear_0_upper

def linear_1 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem linear_1_valid : Valid linear_1 := by decide
def linear_1_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem linear_1_small : evalGuard 18446744073709551615 linear_1 linear_1_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_1 linear_1_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_1 linear_1_small_env = some 1 := by decide
def linear_1_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem linear_1_upper : evalGuard 18446744073709551615 linear_1 linear_1_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_1 linear_1_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_1 linear_1_upper_env = some 18446744073709551615 := by decide
#print axioms linear_1_valid
#print axioms linear_1_small
#print axioms linear_1_upper

def linear_2 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 9,
  addOrdinal := 10
}
theorem linear_2_valid : Valid linear_2 := by decide
def linear_2_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem linear_2_small : evalGuard 18446744073709551615 linear_2 linear_2_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_2 linear_2_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_2 linear_2_small_env = some 1 := by decide
def linear_2_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem linear_2_upper : evalGuard 18446744073709551615 linear_2 linear_2_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_2 linear_2_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_2 linear_2_upper_env = some 18446744073709551615 := by decide
#print axioms linear_2_valid
#print axioms linear_2_small
#print axioms linear_2_upper

def linear_3 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem linear_3_valid : Valid linear_3 := by decide
def linear_3_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem linear_3_small : evalGuard 18446744073709551615 linear_3 linear_3_small_env = some true ∧
    evalStep .checked 18446744073709551615 linear_3 linear_3_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 linear_3 linear_3_small_env = some 1 := by decide
def linear_3_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem linear_3_upper : evalGuard 18446744073709551615 linear_3 linear_3_upper_env = some true ∧
    evalStep .checked 18446744073709551615 linear_3 linear_3_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 linear_3 linear_3_upper_env = some 18446744073709551615 := by decide
#print axioms linear_3_valid
#print axioms linear_3_small
#print axioms linear_3_upper

def affine_0 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 13,
  addOrdinal := 14
}
theorem affine_0_valid : Valid affine_0 := by decide
def affine_0_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem affine_0_small : evalGuard 18446744073709551615 affine_0 affine_0_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_0 affine_0_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_0 affine_0_small_env = some 1 := by decide
def affine_0_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem affine_0_upper : evalGuard 18446744073709551615 affine_0 affine_0_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_0 affine_0_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_0 affine_0_upper_env = some 18446744073709551615 := by decide
#print axioms affine_0_valid
#print axioms affine_0_small
#print axioms affine_0_upper

def affine_1 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem affine_1_valid : Valid affine_1 := by decide
def affine_1_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem affine_1_small : evalGuard 18446744073709551615 affine_1 affine_1_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_1 affine_1_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_1 affine_1_small_env = some 1 := by decide
def affine_1_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem affine_1_upper : evalGuard 18446744073709551615 affine_1 affine_1_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_1 affine_1_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_1 affine_1_upper_env = some 18446744073709551615 := by decide
#print axioms affine_1_valid
#print axioms affine_1_small
#print axioms affine_1_upper

def affine_2 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4],
  indexSlot := 4,
  extentSlot := 3,
  addIndexSlot := 4,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 13,
  addOrdinal := 14
}
theorem affine_2_valid : Valid affine_2 := by decide
def affine_2_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem affine_2_small : evalGuard 18446744073709551615 affine_2 affine_2_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_2 affine_2_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_2 affine_2_small_env = some 1 := by decide
def affine_2_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem affine_2_upper : evalGuard 18446744073709551615 affine_2 affine_2_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_2 affine_2_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_2 affine_2_upper_env = some 18446744073709551615 := by decide
#print axioms affine_2_valid
#print axioms affine_2_small
#print axioms affine_2_upper

def affine_3 : Descriptor := {
  sourceIndex := 5,
  sourceExtent := 4,
  compareOutput := 6,
  branchCondition := 6,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 3, 4, 5],
  indexSlot := 5,
  extentSlot := 4,
  addIndexSlot := 5,
  addOp := .checked,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 5,
  addOrdinal := 6
}
theorem affine_3_valid : Valid affine_3 := by decide
def affine_3_small_env : Env := fun slot =>
  if slot = 5 then some (.usize 0)
  else if slot = 4 then some (.usize 1) else none
theorem affine_3_small : evalGuard 18446744073709551615 affine_3 affine_3_small_env = some true ∧
    evalStep .checked 18446744073709551615 affine_3 affine_3_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 affine_3 affine_3_small_env = some 1 := by decide
def affine_3_upper_env : Env := fun slot =>
  if slot = 5 then some (.usize 18446744073709551614)
  else if slot = 4 then some (.usize 18446744073709551615) else none
theorem affine_3_upper : evalGuard 18446744073709551615 affine_3 affine_3_upper_env = some true ∧
    evalStep .checked 18446744073709551615 affine_3 affine_3_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 affine_3 affine_3_upper_env = some 18446744073709551615 := by decide
#print axioms affine_3_valid
#print axioms affine_3_small
#print axioms affine_3_upper

def crossed_0 : Descriptor := {
  sourceIndex := 4,
  sourceExtent := 3,
  compareOutput := 5,
  branchCondition := 5,
  indexType := .usize,
  extentType := .usize,
  compareOp := .lt,
  selectedArm := .thenArm,
  incoming := [0, 1, 2, 4, 3],
  indexSlot := 3,
  extentSlot := 4,
  addIndexSlot := 3,
  addOp := .wrapping,
  addType := .usize,
  literalType := .usize,
  literalValue := 1,
  literalOrdinal := 9,
  addOrdinal := 10
}
theorem crossed_0_valid : Valid crossed_0 := by decide
def crossed_0_small_env : Env := fun slot =>
  if slot = 4 then some (.usize 0)
  else if slot = 3 then some (.usize 1) else none
theorem crossed_0_small : evalGuard 18446744073709551615 crossed_0 crossed_0_small_env = some true ∧
    evalStep .checked 18446744073709551615 crossed_0 crossed_0_small_env = some 1 ∧
    evalStep .wrapping 18446744073709551615 crossed_0 crossed_0_small_env = some 1 := by decide
def crossed_0_upper_env : Env := fun slot =>
  if slot = 4 then some (.usize 18446744073709551614)
  else if slot = 3 then some (.usize 18446744073709551615) else none
theorem crossed_0_upper : evalGuard 18446744073709551615 crossed_0 crossed_0_upper_env = some true ∧
    evalStep .checked 18446744073709551615 crossed_0 crossed_0_upper_env = some 18446744073709551615 ∧
    evalStep .wrapping 18446744073709551615 crossed_0 crossed_0_upper_env = some 18446744073709551615 := by decide
#print axioms crossed_0_valid
#print axioms crossed_0_small
#print axioms crossed_0_upper

theorem no_step_missing : evalSelectedStep 18446744073709551615 linear_0 (fun _ => none) = none := by decide
#print axioms no_step_missing

theorem no_step_opaque : evalSelectedStep 18446744073709551615 linear_0 (fun _ => some .opaque) = none := by decide
#print axioms no_step_opaque

theorem no_step_oversized : evalSelectedStep 18446744073709551615 linear_0 (fun _ => some (.usize 18446744073709551616)) = none := by decide
#print axioms no_step_oversized

theorem no_step_false_guard : evalSelectedStep 18446744073709551615 linear_0 (fun _ => some (.usize 0)) = none := by decide
#print axioms no_step_false_guard

end HiaGuardedUsizeSlice
