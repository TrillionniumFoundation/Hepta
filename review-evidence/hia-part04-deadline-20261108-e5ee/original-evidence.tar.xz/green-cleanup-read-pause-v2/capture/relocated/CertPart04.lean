import HiaSyntaxResearch.CertPart03
namespace HiaCoreSyntaxSlice
def parallel_r113 : Raw := (.obj parallel_l113_0)
def parallel_b113 : List Nat := parallel_g285 ++ (parallel_v113_0 ++ parallel_g297)
theorem parallel_o113 : orderedFields parallel_l113_0 = true := by decide +kernel
theorem parallel_s113 : serializeRaw 4072 28 parallel_r113 = some parallel_b113 := by
  simpa only [parallel_r113, parallel_b113, parallel_g285, parallel_g297, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4071 27 parallel_l113_0 parallel_v113_0 parallel_o113 parallel_sl113_0)
theorem parallel_p113 (tail : List Nat) : parseRaw 4072 28 (parallel_b113 ++ tail) = some (parallel_r113, tail) := by
  simpa only [parallel_r113, parallel_b113, parallel_g285, parallel_g297, parallel_v113_0, parallel_k113_0, parallel_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4071 27 (parallel_k113_0 ++ (34 :: 58 :: (parallel_b114 ++ (44 :: (parallel_v113_1 ++ (125 :: tail)))))) tail parallel_l113_0 parallel_o113 (by simpa only [parallel_v113_0, parallel_k113_0, parallel_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl113_0 tail)))
def parallel_r119 : Raw := (.str [100,103,95,115,108,111,119,95,51])
def parallel_b119 : List Nat := parallel_g301
theorem parallel_s119 : serializeRaw 4069 27 parallel_r119 = some parallel_b119 := by decide +kernel
theorem parallel_p119 (tail : List Nat) : parseRaw 4069 27 (parallel_b119 ++ tail) = some (parallel_r119, tail) := by rfl
def parallel_r120 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,54]),(.str [100,103,95,118,95,49,51,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,55])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b120 : List Nat := parallel_g304
theorem parallel_s120 : serializeRaw 4068 27 parallel_r120 = some parallel_b120 := by decide +kernel
theorem parallel_p120 (tail : List Nat) : parseRaw 4068 27 (parallel_b120 ++ tail) = some (parallel_r120, tail) := by rfl
def parallel_r121 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,52])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b121 : List Nat := parallel_g307
theorem parallel_s121 : serializeRaw 4067 27 parallel_r121 = some parallel_b121 := by decide +kernel
theorem parallel_p121 (tail : List Nat) : parseRaw 4067 27 (parallel_b121 ++ tail) = some (parallel_r121, tail) := by rfl
def parallel_r122 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,51,55])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))]))])
def parallel_b122 : List Nat := parallel_g310
theorem parallel_s122 : serializeRaw 4066 27 parallel_r122 = some parallel_b122 := by decide +kernel
theorem parallel_p122 (tail : List Nat) : parseRaw 4066 27 (parallel_b122 ++ tail) = some (parallel_r122, tail) := by rfl
def parallel_k118_0 : List Nat := [105,100]
theorem parallel_kd118_0 : stringBytes parallel_k118_0 = true := by decide +kernel
theorem parallel_kp118_0 (tail : List Nat) : parseStringTail (parallel_k118_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k118_0, 58 :: tail) := by rfl
def parallel_k118_1 : List Nat := [111,112,115]
theorem parallel_kd118_1 : stringBytes parallel_k118_1 = true := by decide +kernel
theorem parallel_kp118_1 (tail : List Nat) : parseStringTail (parallel_k118_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k118_1, 58 :: tail) := by rfl
def parallel_k118_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd118_2 : stringBytes parallel_k118_2 = true := by decide +kernel
theorem parallel_kp118_2 (tail : List Nat) : parseStringTail (parallel_k118_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k118_2, 58 :: tail) := by rfl
def parallel_k118_3 : List Nat := [116,101,114,109]
theorem parallel_kd118_3 : stringBytes parallel_k118_3 = true := by decide +kernel
theorem parallel_kp118_3 (tail : List Nat) : parseStringTail (parallel_k118_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k118_3, 58 :: tail) := by rfl
def parallel_l118_3 : List (List Nat × Raw) := [(parallel_k118_3, parallel_r122)]
def parallel_v118_3 : List Nat := parallel_g309 ++ parallel_b122
theorem parallel_sl118_3 : serializeFields 4067 27 parallel_l118_3 = some parallel_v118_3 := by
  simpa only [parallel_l118_3, parallel_v118_3, parallel_k118_3, parallel_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4066 27 parallel_k118_3 parallel_r122 parallel_b122 parallel_kd118_3 parallel_s122)
theorem parallel_pl118_3 (tail : List Nat) : parseFields 4067 27 (parallel_v118_3 ++ (125 :: tail)) = some (parallel_l118_3, tail) := by
  simpa only [parallel_l118_3, parallel_v118_3, parallel_k118_3, parallel_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4066 27 (parallel_k118_3 ++ (34 :: 58 :: (parallel_b122 ++ (125 :: tail)))) parallel_k118_3 (parallel_b122 ++ (125 :: tail)) tail parallel_r122 (parallel_kp118_3 (parallel_b122 ++ (125 :: tail))) (parallel_p122 (125 :: tail)))
def parallel_l118_2 : List (List Nat × Raw) := (parallel_k118_2, parallel_r121) :: parallel_l118_3
def parallel_v118_2 : List Nat := (parallel_g306 ++ parallel_b121) ++ (44 :: parallel_v118_3)
theorem parallel_sl118_2 : serializeFields 4068 27 parallel_l118_2 = some parallel_v118_2 := by
  simpa only [parallel_l118_2, parallel_v118_2, parallel_k118_2, parallel_g306, parallel_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 parallel_k118_2 parallel_r121 (parallel_k118_3, parallel_r122) [] parallel_b121 parallel_v118_3 parallel_kd118_2 parallel_s121 parallel_sl118_3)
theorem parallel_pl118_2 (tail : List Nat) : parseFields 4068 27 (parallel_v118_2 ++ (125 :: tail)) = some (parallel_l118_2, tail) := by
  simpa only [parallel_l118_2, parallel_v118_2, parallel_k118_2, parallel_g306, parallel_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (parallel_k118_2 ++ (34 :: 58 :: (parallel_b121 ++ (44 :: (parallel_v118_3 ++ (125 :: tail)))))) parallel_k118_2 (parallel_b121 ++ (44 :: (parallel_v118_3 ++ (125 :: tail)))) (parallel_v118_3 ++ (125 :: tail)) tail parallel_r121 parallel_l118_3 (parallel_kp118_2 (parallel_b121 ++ (44 :: (parallel_v118_3 ++ (125 :: tail))))) (parallel_p121 (44 :: (parallel_v118_3 ++ (125 :: tail)))) (parallel_pl118_3 tail))
def parallel_l118_1 : List (List Nat × Raw) := (parallel_k118_1, parallel_r120) :: parallel_l118_2
def parallel_v118_1 : List Nat := (parallel_g303 ++ parallel_b120) ++ (44 :: parallel_v118_2)
theorem parallel_sl118_1 : serializeFields 4069 27 parallel_l118_1 = some parallel_v118_1 := by
  simpa only [parallel_l118_1, parallel_v118_1, parallel_k118_1, parallel_g303, parallel_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 parallel_k118_1 parallel_r120 (parallel_k118_2, parallel_r121) parallel_l118_3 parallel_b120 parallel_v118_2 parallel_kd118_1 parallel_s120 parallel_sl118_2)
theorem parallel_pl118_1 (tail : List Nat) : parseFields 4069 27 (parallel_v118_1 ++ (125 :: tail)) = some (parallel_l118_1, tail) := by
  simpa only [parallel_l118_1, parallel_v118_1, parallel_k118_1, parallel_g303, parallel_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (parallel_k118_1 ++ (34 :: 58 :: (parallel_b120 ++ (44 :: (parallel_v118_2 ++ (125 :: tail)))))) parallel_k118_1 (parallel_b120 ++ (44 :: (parallel_v118_2 ++ (125 :: tail)))) (parallel_v118_2 ++ (125 :: tail)) tail parallel_r120 parallel_l118_2 (parallel_kp118_1 (parallel_b120 ++ (44 :: (parallel_v118_2 ++ (125 :: tail))))) (parallel_p120 (44 :: (parallel_v118_2 ++ (125 :: tail)))) (parallel_pl118_2 tail))
def parallel_l118_0 : List (List Nat × Raw) := (parallel_k118_0, parallel_r119) :: parallel_l118_1
def parallel_v118_0 : List Nat := (parallel_g300 ++ parallel_b119) ++ (44 :: parallel_v118_1)
theorem parallel_sl118_0 : serializeFields 4070 27 parallel_l118_0 = some parallel_v118_0 := by
  simpa only [parallel_l118_0, parallel_v118_0, parallel_k118_0, parallel_g300, parallel_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 parallel_k118_0 parallel_r119 (parallel_k118_1, parallel_r120) parallel_l118_2 parallel_b119 parallel_v118_1 parallel_kd118_0 parallel_s119 parallel_sl118_1)
theorem parallel_pl118_0 (tail : List Nat) : parseFields 4070 27 (parallel_v118_0 ++ (125 :: tail)) = some (parallel_l118_0, tail) := by
  simpa only [parallel_l118_0, parallel_v118_0, parallel_k118_0, parallel_g300, parallel_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (parallel_k118_0 ++ (34 :: 58 :: (parallel_b119 ++ (44 :: (parallel_v118_1 ++ (125 :: tail)))))) parallel_k118_0 (parallel_b119 ++ (44 :: (parallel_v118_1 ++ (125 :: tail)))) (parallel_v118_1 ++ (125 :: tail)) tail parallel_r119 parallel_l118_1 (parallel_kp118_0 (parallel_b119 ++ (44 :: (parallel_v118_1 ++ (125 :: tail))))) (parallel_p119 (44 :: (parallel_v118_1 ++ (125 :: tail)))) (parallel_pl118_1 tail))
def parallel_r118 : Raw := (.obj parallel_l118_0)
def parallel_b118 : List Nat := parallel_g299 ++ (parallel_v118_0 ++ parallel_g311)
theorem parallel_o118 : orderedFields parallel_l118_0 = true := by decide +kernel
theorem parallel_s118 : serializeRaw 4071 28 parallel_r118 = some parallel_b118 := by
  simpa only [parallel_r118, parallel_b118, parallel_g299, parallel_g311, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4070 27 parallel_l118_0 parallel_v118_0 parallel_o118 parallel_sl118_0)
theorem parallel_p118 (tail : List Nat) : parseRaw 4071 28 (parallel_b118 ++ tail) = some (parallel_r118, tail) := by
  simpa only [parallel_r118, parallel_b118, parallel_g299, parallel_g311, parallel_v118_0, parallel_k118_0, parallel_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4070 27 (parallel_k118_0 ++ (34 :: 58 :: (parallel_b119 ++ (44 :: (parallel_v118_1 ++ (125 :: tail)))))) tail parallel_l118_0 parallel_o118 (by simpa only [parallel_v118_0, parallel_k118_0, parallel_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl118_0 tail)))
def parallel_r124 : Raw := (.str [100,103,95,115,108,111,119,95,52])
def parallel_b124 : List Nat := parallel_g315
theorem parallel_s124 : serializeRaw 4068 27 parallel_r124 = some parallel_b124 := by decide +kernel
theorem parallel_p124 (tail : List Nat) : parseRaw 4068 27 (parallel_b124 ++ tail) = some (parallel_r124, tail) := by rfl
def parallel_r126 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,52])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def parallel_b126 : List Nat := parallel_g319
theorem parallel_s126 : serializeRaw 4065 26 parallel_r126 = some parallel_b126 := by decide +kernel
theorem parallel_p126 (tail : List Nat) : parseRaw 4065 26 (parallel_b126 ++ tail) = some (parallel_r126, tail) := by rfl
def parallel_r127 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52]),(.str [100,103,95,118,95,49,52,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,53])),([116,121,112,101],(.str [117,56]))])]))])
def parallel_b127 : List Nat := parallel_g321
theorem parallel_s127 : serializeRaw 4064 26 parallel_r127 = some parallel_b127 := by decide +kernel
theorem parallel_p127 (tail : List Nat) : parseRaw 4064 26 (parallel_b127 ++ tail) = some (parallel_r127, tail) := by rfl
def parallel_r128 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def parallel_b128 : List Nat := parallel_g323
theorem parallel_s128 : serializeRaw 4063 26 parallel_r128 = some parallel_b128 := by decide +kernel
theorem parallel_p128 (tail : List Nat) : parseRaw 4063 26 (parallel_b128 ++ tail) = some (parallel_r128, tail) := by rfl
def parallel_r129 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b129 : List Nat := parallel_g325
theorem parallel_s129 : serializeRaw 4062 26 parallel_r129 = some parallel_b129 := by decide +kernel
theorem parallel_p129 (tail : List Nat) : parseRaw 4062 26 (parallel_b129 ++ tail) = some (parallel_r129, tail) := by rfl
def parallel_r130 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,49]),(.str [100,103,95,118,95,49,52,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def parallel_b130 : List Nat := parallel_g327
theorem parallel_s130 : serializeRaw 4061 26 parallel_r130 = some parallel_b130 := by decide +kernel
theorem parallel_p130 (tail : List Nat) : parseRaw 4061 26 (parallel_b130 ++ tail) = some (parallel_r130, tail) := by rfl
def parallel_r131 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b131 : List Nat := parallel_g329
theorem parallel_s131 : serializeRaw 4060 26 parallel_r131 = some parallel_b131 := by decide +kernel
theorem parallel_p131 (tail : List Nat) : parseRaw 4060 26 (parallel_b131 ++ tail) = some (parallel_r131, tail) := by rfl
def parallel_r132 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,51]),(.str [100,103,95,118,95,49,52,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def parallel_b132 : List Nat := parallel_g331
theorem parallel_s132 : serializeRaw 4059 26 parallel_r132 = some parallel_b132 := by decide +kernel
theorem parallel_p132 (tail : List Nat) : parseRaw 4059 26 (parallel_b132 ++ tail) = some (parallel_r132, tail) := by rfl
def parallel_l125_6 : List Raw := [parallel_r132]
def parallel_v125_6 : List Nat := parallel_b132
theorem parallel_sl125_6 : serializeItems 4060 26 parallel_l125_6 = some parallel_v125_6 := by
  simpa only [parallel_l125_6, parallel_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4059 26 parallel_r132 parallel_b132 parallel_s132)
theorem parallel_pl125_6 (tail : List Nat) : parseItems 4060 26 (parallel_v125_6 ++ (93 :: tail)) = some (parallel_l125_6, tail) := by
  simpa only [parallel_l125_6, parallel_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4059 26 (parallel_b132 ++ (93 :: tail)) tail parallel_r132 (parallel_p132 (93 :: tail)))
def parallel_l125_5 : List Raw := parallel_r131 :: parallel_l125_6
def parallel_v125_5 : List Nat := (parallel_b131) ++ (44 :: parallel_v125_6)
theorem parallel_sl125_5 : serializeItems 4061 26 parallel_l125_5 = some parallel_v125_5 := by
  simpa only [parallel_l125_5, parallel_v125_5, parallel_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 parallel_r131 parallel_r132 [] parallel_b131 parallel_v125_6 parallel_s131 parallel_sl125_6)
theorem parallel_pl125_5 (tail : List Nat) : parseItems 4061 26 (parallel_v125_5 ++ (93 :: tail)) = some (parallel_l125_5, tail) := by
  simpa only [parallel_l125_5, parallel_v125_5, parallel_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (parallel_b131 ++ (44 :: (parallel_v125_6 ++ (93 :: tail)))) (parallel_v125_6 ++ (93 :: tail)) tail parallel_r131 parallel_l125_6 (parallel_p131 (44 :: (parallel_v125_6 ++ (93 :: tail)))) (parallel_pl125_6 tail))
def parallel_l125_4 : List Raw := parallel_r130 :: parallel_l125_5
def parallel_v125_4 : List Nat := (parallel_b130) ++ (44 :: parallel_v125_5)
theorem parallel_sl125_4 : serializeItems 4062 26 parallel_l125_4 = some parallel_v125_4 := by
  simpa only [parallel_l125_4, parallel_v125_4, parallel_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 parallel_r130 parallel_r131 parallel_l125_6 parallel_b130 parallel_v125_5 parallel_s130 parallel_sl125_5)
theorem parallel_pl125_4 (tail : List Nat) : parseItems 4062 26 (parallel_v125_4 ++ (93 :: tail)) = some (parallel_l125_4, tail) := by
  simpa only [parallel_l125_4, parallel_v125_4, parallel_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (parallel_b130 ++ (44 :: (parallel_v125_5 ++ (93 :: tail)))) (parallel_v125_5 ++ (93 :: tail)) tail parallel_r130 parallel_l125_5 (parallel_p130 (44 :: (parallel_v125_5 ++ (93 :: tail)))) (parallel_pl125_5 tail))
def parallel_l125_3 : List Raw := parallel_r129 :: parallel_l125_4
def parallel_v125_3 : List Nat := (parallel_b129) ++ (44 :: parallel_v125_4)
theorem parallel_sl125_3 : serializeItems 4063 26 parallel_l125_3 = some parallel_v125_3 := by
  simpa only [parallel_l125_3, parallel_v125_3, parallel_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 parallel_r129 parallel_r130 parallel_l125_5 parallel_b129 parallel_v125_4 parallel_s129 parallel_sl125_4)
theorem parallel_pl125_3 (tail : List Nat) : parseItems 4063 26 (parallel_v125_3 ++ (93 :: tail)) = some (parallel_l125_3, tail) := by
  simpa only [parallel_l125_3, parallel_v125_3, parallel_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (parallel_b129 ++ (44 :: (parallel_v125_4 ++ (93 :: tail)))) (parallel_v125_4 ++ (93 :: tail)) tail parallel_r129 parallel_l125_4 (parallel_p129 (44 :: (parallel_v125_4 ++ (93 :: tail)))) (parallel_pl125_4 tail))
def parallel_l125_2 : List Raw := parallel_r128 :: parallel_l125_3
def parallel_v125_2 : List Nat := (parallel_b128) ++ (44 :: parallel_v125_3)
theorem parallel_sl125_2 : serializeItems 4064 26 parallel_l125_2 = some parallel_v125_2 := by
  simpa only [parallel_l125_2, parallel_v125_2, parallel_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 parallel_r128 parallel_r129 parallel_l125_4 parallel_b128 parallel_v125_3 parallel_s128 parallel_sl125_3)
theorem parallel_pl125_2 (tail : List Nat) : parseItems 4064 26 (parallel_v125_2 ++ (93 :: tail)) = some (parallel_l125_2, tail) := by
  simpa only [parallel_l125_2, parallel_v125_2, parallel_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (parallel_b128 ++ (44 :: (parallel_v125_3 ++ (93 :: tail)))) (parallel_v125_3 ++ (93 :: tail)) tail parallel_r128 parallel_l125_3 (parallel_p128 (44 :: (parallel_v125_3 ++ (93 :: tail)))) (parallel_pl125_3 tail))
def parallel_l125_1 : List Raw := parallel_r127 :: parallel_l125_2
def parallel_v125_1 : List Nat := (parallel_b127) ++ (44 :: parallel_v125_2)
theorem parallel_sl125_1 : serializeItems 4065 26 parallel_l125_1 = some parallel_v125_1 := by
  simpa only [parallel_l125_1, parallel_v125_1, parallel_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 parallel_r127 parallel_r128 parallel_l125_3 parallel_b127 parallel_v125_2 parallel_s127 parallel_sl125_2)
theorem parallel_pl125_1 (tail : List Nat) : parseItems 4065 26 (parallel_v125_1 ++ (93 :: tail)) = some (parallel_l125_1, tail) := by
  simpa only [parallel_l125_1, parallel_v125_1, parallel_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (parallel_b127 ++ (44 :: (parallel_v125_2 ++ (93 :: tail)))) (parallel_v125_2 ++ (93 :: tail)) tail parallel_r127 parallel_l125_2 (parallel_p127 (44 :: (parallel_v125_2 ++ (93 :: tail)))) (parallel_pl125_2 tail))
def parallel_l125_0 : List Raw := parallel_r126 :: parallel_l125_1
def parallel_v125_0 : List Nat := (parallel_b126) ++ (44 :: parallel_v125_1)
theorem parallel_sl125_0 : serializeItems 4066 26 parallel_l125_0 = some parallel_v125_0 := by
  simpa only [parallel_l125_0, parallel_v125_0, parallel_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 parallel_r126 parallel_r127 parallel_l125_2 parallel_b126 parallel_v125_1 parallel_s126 parallel_sl125_1)
theorem parallel_pl125_0 (tail : List Nat) : parseItems 4066 26 (parallel_v125_0 ++ (93 :: tail)) = some (parallel_l125_0, tail) := by
  simpa only [parallel_l125_0, parallel_v125_0, parallel_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (parallel_b126 ++ (44 :: (parallel_v125_1 ++ (93 :: tail)))) (parallel_v125_1 ++ (93 :: tail)) tail parallel_r126 parallel_l125_1 (parallel_p126 (44 :: (parallel_v125_1 ++ (93 :: tail)))) (parallel_pl125_1 tail))
def parallel_r125 : Raw := (.arr parallel_l125_0)
def parallel_b125 : List Nat := parallel_g318 ++ (parallel_v125_0 ++ parallel_g332)
theorem parallel_s125 : serializeRaw 4067 27 parallel_r125 = some parallel_b125 := by
  simpa only [parallel_r125, parallel_b125, parallel_g318, parallel_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4066 26 parallel_l125_0 parallel_v125_0 parallel_sl125_0)
theorem parallel_p125 (tail : List Nat) : parseRaw 4067 27 (parallel_b125 ++ tail) = some (parallel_r125, tail) := by
  simpa only [parallel_r125, parallel_b125, parallel_g318, parallel_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4066 26 (parallel_v125_0 ++ (93 :: tail)) tail parallel_l125_0 (by intro h; cases h) (parallel_pl125_0 tail))
def parallel_r133 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b133 : List Nat := parallel_g335
theorem parallel_s133 : serializeRaw 4066 27 parallel_r133 = some parallel_b133 := by decide +kernel
theorem parallel_p133 (tail : List Nat) : parseRaw 4066 27 (parallel_b133 ++ tail) = some (parallel_r133, tail) := by rfl
def parallel_r134 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,56]),(.str [100,103,95,118,95,49,51,57]),(.str [100,103,95,118,95,49,52,48]),(.str [100,103,95,118,95,49,52,55]),(.str [100,103,95,118,95,49,52,50]),(.str [100,103,95,118,95,49,52,57])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def parallel_b134 : List Nat := parallel_g338
theorem parallel_s134 : serializeRaw 4065 27 parallel_r134 = some parallel_b134 := by decide +kernel
theorem parallel_p134 (tail : List Nat) : parseRaw 4065 27 (parallel_b134 ++ tail) = some (parallel_r134, tail) := by rfl
def parallel_k123_0 : List Nat := [105,100]
theorem parallel_kd123_0 : stringBytes parallel_k123_0 = true := by decide +kernel
theorem parallel_kp123_0 (tail : List Nat) : parseStringTail (parallel_k123_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k123_0, 58 :: tail) := by rfl
def parallel_k123_1 : List Nat := [111,112,115]
theorem parallel_kd123_1 : stringBytes parallel_k123_1 = true := by decide +kernel
theorem parallel_kp123_1 (tail : List Nat) : parseStringTail (parallel_k123_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k123_1, 58 :: tail) := by rfl
def parallel_k123_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd123_2 : stringBytes parallel_k123_2 = true := by decide +kernel
theorem parallel_kp123_2 (tail : List Nat) : parseStringTail (parallel_k123_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k123_2, 58 :: tail) := by rfl
def parallel_k123_3 : List Nat := [116,101,114,109]
theorem parallel_kd123_3 : stringBytes parallel_k123_3 = true := by decide +kernel
theorem parallel_kp123_3 (tail : List Nat) : parseStringTail (parallel_k123_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k123_3, 58 :: tail) := by rfl
def parallel_l123_3 : List (List Nat × Raw) := [(parallel_k123_3, parallel_r134)]
def parallel_v123_3 : List Nat := parallel_g337 ++ parallel_b134
theorem parallel_sl123_3 : serializeFields 4066 27 parallel_l123_3 = some parallel_v123_3 := by
  simpa only [parallel_l123_3, parallel_v123_3, parallel_k123_3, parallel_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4065 27 parallel_k123_3 parallel_r134 parallel_b134 parallel_kd123_3 parallel_s134)
theorem parallel_pl123_3 (tail : List Nat) : parseFields 4066 27 (parallel_v123_3 ++ (125 :: tail)) = some (parallel_l123_3, tail) := by
  simpa only [parallel_l123_3, parallel_v123_3, parallel_k123_3, parallel_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4065 27 (parallel_k123_3 ++ (34 :: 58 :: (parallel_b134 ++ (125 :: tail)))) parallel_k123_3 (parallel_b134 ++ (125 :: tail)) tail parallel_r134 (parallel_kp123_3 (parallel_b134 ++ (125 :: tail))) (parallel_p134 (125 :: tail)))
def parallel_l123_2 : List (List Nat × Raw) := (parallel_k123_2, parallel_r133) :: parallel_l123_3
def parallel_v123_2 : List Nat := (parallel_g334 ++ parallel_b133) ++ (44 :: parallel_v123_3)
theorem parallel_sl123_2 : serializeFields 4067 27 parallel_l123_2 = some parallel_v123_2 := by
  simpa only [parallel_l123_2, parallel_v123_2, parallel_k123_2, parallel_g334, parallel_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 parallel_k123_2 parallel_r133 (parallel_k123_3, parallel_r134) [] parallel_b133 parallel_v123_3 parallel_kd123_2 parallel_s133 parallel_sl123_3)
theorem parallel_pl123_2 (tail : List Nat) : parseFields 4067 27 (parallel_v123_2 ++ (125 :: tail)) = some (parallel_l123_2, tail) := by
  simpa only [parallel_l123_2, parallel_v123_2, parallel_k123_2, parallel_g334, parallel_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (parallel_k123_2 ++ (34 :: 58 :: (parallel_b133 ++ (44 :: (parallel_v123_3 ++ (125 :: tail)))))) parallel_k123_2 (parallel_b133 ++ (44 :: (parallel_v123_3 ++ (125 :: tail)))) (parallel_v123_3 ++ (125 :: tail)) tail parallel_r133 parallel_l123_3 (parallel_kp123_2 (parallel_b133 ++ (44 :: (parallel_v123_3 ++ (125 :: tail))))) (parallel_p133 (44 :: (parallel_v123_3 ++ (125 :: tail)))) (parallel_pl123_3 tail))
def parallel_l123_1 : List (List Nat × Raw) := (parallel_k123_1, parallel_r125) :: parallel_l123_2
def parallel_v123_1 : List Nat := (parallel_g317 ++ parallel_b125) ++ (44 :: parallel_v123_2)
theorem parallel_sl123_1 : serializeFields 4068 27 parallel_l123_1 = some parallel_v123_1 := by
  simpa only [parallel_l123_1, parallel_v123_1, parallel_k123_1, parallel_g317, parallel_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 parallel_k123_1 parallel_r125 (parallel_k123_2, parallel_r133) parallel_l123_3 parallel_b125 parallel_v123_2 parallel_kd123_1 parallel_s125 parallel_sl123_2)
theorem parallel_pl123_1 (tail : List Nat) : parseFields 4068 27 (parallel_v123_1 ++ (125 :: tail)) = some (parallel_l123_1, tail) := by
  simpa only [parallel_l123_1, parallel_v123_1, parallel_k123_1, parallel_g317, parallel_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (parallel_k123_1 ++ (34 :: 58 :: (parallel_b125 ++ (44 :: (parallel_v123_2 ++ (125 :: tail)))))) parallel_k123_1 (parallel_b125 ++ (44 :: (parallel_v123_2 ++ (125 :: tail)))) (parallel_v123_2 ++ (125 :: tail)) tail parallel_r125 parallel_l123_2 (parallel_kp123_1 (parallel_b125 ++ (44 :: (parallel_v123_2 ++ (125 :: tail))))) (parallel_p125 (44 :: (parallel_v123_2 ++ (125 :: tail)))) (parallel_pl123_2 tail))
def parallel_l123_0 : List (List Nat × Raw) := (parallel_k123_0, parallel_r124) :: parallel_l123_1
def parallel_v123_0 : List Nat := (parallel_g314 ++ parallel_b124) ++ (44 :: parallel_v123_1)
theorem parallel_sl123_0 : serializeFields 4069 27 parallel_l123_0 = some parallel_v123_0 := by
  simpa only [parallel_l123_0, parallel_v123_0, parallel_k123_0, parallel_g314, parallel_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 parallel_k123_0 parallel_r124 (parallel_k123_1, parallel_r125) parallel_l123_2 parallel_b124 parallel_v123_1 parallel_kd123_0 parallel_s124 parallel_sl123_1)
theorem parallel_pl123_0 (tail : List Nat) : parseFields 4069 27 (parallel_v123_0 ++ (125 :: tail)) = some (parallel_l123_0, tail) := by
  simpa only [parallel_l123_0, parallel_v123_0, parallel_k123_0, parallel_g314, parallel_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (parallel_k123_0 ++ (34 :: 58 :: (parallel_b124 ++ (44 :: (parallel_v123_1 ++ (125 :: tail)))))) parallel_k123_0 (parallel_b124 ++ (44 :: (parallel_v123_1 ++ (125 :: tail)))) (parallel_v123_1 ++ (125 :: tail)) tail parallel_r124 parallel_l123_1 (parallel_kp123_0 (parallel_b124 ++ (44 :: (parallel_v123_1 ++ (125 :: tail))))) (parallel_p124 (44 :: (parallel_v123_1 ++ (125 :: tail)))) (parallel_pl123_1 tail))
def parallel_r123 : Raw := (.obj parallel_l123_0)
def parallel_b123 : List Nat := parallel_g313 ++ (parallel_v123_0 ++ parallel_g339)
theorem parallel_o123 : orderedFields parallel_l123_0 = true := by decide +kernel
theorem parallel_s123 : serializeRaw 4070 28 parallel_r123 = some parallel_b123 := by
  simpa only [parallel_r123, parallel_b123, parallel_g313, parallel_g339, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4069 27 parallel_l123_0 parallel_v123_0 parallel_o123 parallel_sl123_0)
theorem parallel_p123 (tail : List Nat) : parseRaw 4070 28 (parallel_b123 ++ tail) = some (parallel_r123, tail) := by
  simpa only [parallel_r123, parallel_b123, parallel_g313, parallel_g339, parallel_v123_0, parallel_k123_0, parallel_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4069 27 (parallel_k123_0 ++ (34 :: 58 :: (parallel_b124 ++ (44 :: (parallel_v123_1 ++ (125 :: tail)))))) tail parallel_l123_0 parallel_o123 (by simpa only [parallel_v123_0, parallel_k123_0, parallel_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl123_0 tail)))
def parallel_r136 : Raw := (.str [100,103,95,115,108,111,119,95,53])
def parallel_b136 : List Nat := parallel_g343
theorem parallel_s136 : serializeRaw 4067 27 parallel_r136 = some parallel_b136 := by decide +kernel
theorem parallel_p136 (tail : List Nat) : parseRaw 4067 27 (parallel_b136 ++ tail) = some (parallel_r136, tail) := by rfl
def parallel_r137 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def parallel_b137 : List Nat := parallel_g346
theorem parallel_s137 : serializeRaw 4066 27 parallel_r137 = some parallel_b137 := by decide +kernel
theorem parallel_p137 (tail : List Nat) : parseRaw 4066 27 (parallel_b137 ++ tail) = some (parallel_r137, tail) := by rfl
def parallel_r138 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,51])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b138 : List Nat := parallel_g349
theorem parallel_s138 : serializeRaw 4065 27 parallel_r138 = some parallel_b138 := by decide +kernel
theorem parallel_p138 (tail : List Nat) : parseRaw 4065 27 (parallel_b138 ++ tail) = some (parallel_r138, tail) := by rfl
def parallel_r139 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,53,51])]))])
def parallel_b139 : List Nat := parallel_g352
theorem parallel_s139 : serializeRaw 4064 27 parallel_r139 = some parallel_b139 := by decide +kernel
theorem parallel_p139 (tail : List Nat) : parseRaw 4064 27 (parallel_b139 ++ tail) = some (parallel_r139, tail) := by rfl
def parallel_k135_0 : List Nat := [105,100]
theorem parallel_kd135_0 : stringBytes parallel_k135_0 = true := by decide +kernel
theorem parallel_kp135_0 (tail : List Nat) : parseStringTail (parallel_k135_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k135_0, 58 :: tail) := by rfl
def parallel_k135_1 : List Nat := [111,112,115]
theorem parallel_kd135_1 : stringBytes parallel_k135_1 = true := by decide +kernel
theorem parallel_kp135_1 (tail : List Nat) : parseStringTail (parallel_k135_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k135_1, 58 :: tail) := by rfl
def parallel_k135_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd135_2 : stringBytes parallel_k135_2 = true := by decide +kernel
theorem parallel_kp135_2 (tail : List Nat) : parseStringTail (parallel_k135_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k135_2, 58 :: tail) := by rfl
def parallel_k135_3 : List Nat := [116,101,114,109]
theorem parallel_kd135_3 : stringBytes parallel_k135_3 = true := by decide +kernel
theorem parallel_kp135_3 (tail : List Nat) : parseStringTail (parallel_k135_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k135_3, 58 :: tail) := by rfl
def parallel_l135_3 : List (List Nat × Raw) := [(parallel_k135_3, parallel_r139)]
def parallel_v135_3 : List Nat := parallel_g351 ++ parallel_b139
theorem parallel_sl135_3 : serializeFields 4065 27 parallel_l135_3 = some parallel_v135_3 := by
  simpa only [parallel_l135_3, parallel_v135_3, parallel_k135_3, parallel_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4064 27 parallel_k135_3 parallel_r139 parallel_b139 parallel_kd135_3 parallel_s139)
theorem parallel_pl135_3 (tail : List Nat) : parseFields 4065 27 (parallel_v135_3 ++ (125 :: tail)) = some (parallel_l135_3, tail) := by
  simpa only [parallel_l135_3, parallel_v135_3, parallel_k135_3, parallel_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4064 27 (parallel_k135_3 ++ (34 :: 58 :: (parallel_b139 ++ (125 :: tail)))) parallel_k135_3 (parallel_b139 ++ (125 :: tail)) tail parallel_r139 (parallel_kp135_3 (parallel_b139 ++ (125 :: tail))) (parallel_p139 (125 :: tail)))
def parallel_l135_2 : List (List Nat × Raw) := (parallel_k135_2, parallel_r138) :: parallel_l135_3
def parallel_v135_2 : List Nat := (parallel_g348 ++ parallel_b138) ++ (44 :: parallel_v135_3)
theorem parallel_sl135_2 : serializeFields 4066 27 parallel_l135_2 = some parallel_v135_2 := by
  simpa only [parallel_l135_2, parallel_v135_2, parallel_k135_2, parallel_g348, parallel_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 parallel_k135_2 parallel_r138 (parallel_k135_3, parallel_r139) [] parallel_b138 parallel_v135_3 parallel_kd135_2 parallel_s138 parallel_sl135_3)
theorem parallel_pl135_2 (tail : List Nat) : parseFields 4066 27 (parallel_v135_2 ++ (125 :: tail)) = some (parallel_l135_2, tail) := by
  simpa only [parallel_l135_2, parallel_v135_2, parallel_k135_2, parallel_g348, parallel_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (parallel_k135_2 ++ (34 :: 58 :: (parallel_b138 ++ (44 :: (parallel_v135_3 ++ (125 :: tail)))))) parallel_k135_2 (parallel_b138 ++ (44 :: (parallel_v135_3 ++ (125 :: tail)))) (parallel_v135_3 ++ (125 :: tail)) tail parallel_r138 parallel_l135_3 (parallel_kp135_2 (parallel_b138 ++ (44 :: (parallel_v135_3 ++ (125 :: tail))))) (parallel_p138 (44 :: (parallel_v135_3 ++ (125 :: tail)))) (parallel_pl135_3 tail))
def parallel_l135_1 : List (List Nat × Raw) := (parallel_k135_1, parallel_r137) :: parallel_l135_2
def parallel_v135_1 : List Nat := (parallel_g345 ++ parallel_b137) ++ (44 :: parallel_v135_2)
theorem parallel_sl135_1 : serializeFields 4067 27 parallel_l135_1 = some parallel_v135_1 := by
  simpa only [parallel_l135_1, parallel_v135_1, parallel_k135_1, parallel_g345, parallel_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 parallel_k135_1 parallel_r137 (parallel_k135_2, parallel_r138) parallel_l135_3 parallel_b137 parallel_v135_2 parallel_kd135_1 parallel_s137 parallel_sl135_2)
theorem parallel_pl135_1 (tail : List Nat) : parseFields 4067 27 (parallel_v135_1 ++ (125 :: tail)) = some (parallel_l135_1, tail) := by
  simpa only [parallel_l135_1, parallel_v135_1, parallel_k135_1, parallel_g345, parallel_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (parallel_k135_1 ++ (34 :: 58 :: (parallel_b137 ++ (44 :: (parallel_v135_2 ++ (125 :: tail)))))) parallel_k135_1 (parallel_b137 ++ (44 :: (parallel_v135_2 ++ (125 :: tail)))) (parallel_v135_2 ++ (125 :: tail)) tail parallel_r137 parallel_l135_2 (parallel_kp135_1 (parallel_b137 ++ (44 :: (parallel_v135_2 ++ (125 :: tail))))) (parallel_p137 (44 :: (parallel_v135_2 ++ (125 :: tail)))) (parallel_pl135_2 tail))
def parallel_l135_0 : List (List Nat × Raw) := (parallel_k135_0, parallel_r136) :: parallel_l135_1
def parallel_v135_0 : List Nat := (parallel_g342 ++ parallel_b136) ++ (44 :: parallel_v135_1)
theorem parallel_sl135_0 : serializeFields 4068 27 parallel_l135_0 = some parallel_v135_0 := by
  simpa only [parallel_l135_0, parallel_v135_0, parallel_k135_0, parallel_g342, parallel_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 parallel_k135_0 parallel_r136 (parallel_k135_1, parallel_r137) parallel_l135_2 parallel_b136 parallel_v135_1 parallel_kd135_0 parallel_s136 parallel_sl135_1)
theorem parallel_pl135_0 (tail : List Nat) : parseFields 4068 27 (parallel_v135_0 ++ (125 :: tail)) = some (parallel_l135_0, tail) := by
  simpa only [parallel_l135_0, parallel_v135_0, parallel_k135_0, parallel_g342, parallel_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (parallel_k135_0 ++ (34 :: 58 :: (parallel_b136 ++ (44 :: (parallel_v135_1 ++ (125 :: tail)))))) parallel_k135_0 (parallel_b136 ++ (44 :: (parallel_v135_1 ++ (125 :: tail)))) (parallel_v135_1 ++ (125 :: tail)) tail parallel_r136 parallel_l135_1 (parallel_kp135_0 (parallel_b136 ++ (44 :: (parallel_v135_1 ++ (125 :: tail))))) (parallel_p136 (44 :: (parallel_v135_1 ++ (125 :: tail)))) (parallel_pl135_1 tail))
def parallel_r135 : Raw := (.obj parallel_l135_0)
def parallel_b135 : List Nat := parallel_g341 ++ (parallel_v135_0 ++ parallel_g353)
theorem parallel_o135 : orderedFields parallel_l135_0 = true := by decide +kernel
theorem parallel_s135 : serializeRaw 4069 28 parallel_r135 = some parallel_b135 := by
  simpa only [parallel_r135, parallel_b135, parallel_g341, parallel_g353, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4068 27 parallel_l135_0 parallel_v135_0 parallel_o135 parallel_sl135_0)
theorem parallel_p135 (tail : List Nat) : parseRaw 4069 28 (parallel_b135 ++ tail) = some (parallel_r135, tail) := by
  simpa only [parallel_r135, parallel_b135, parallel_g341, parallel_g353, parallel_v135_0, parallel_k135_0, parallel_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4068 27 (parallel_k135_0 ++ (34 :: 58 :: (parallel_b136 ++ (44 :: (parallel_v135_1 ++ (125 :: tail)))))) tail parallel_l135_0 parallel_o135 (by simpa only [parallel_v135_0, parallel_k135_0, parallel_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl135_0 tail)))
def parallel_r141 : Raw := (.str [100,103,95,103,117,97,114,100,95,48])
def parallel_b141 : List Nat := parallel_g357
theorem parallel_s141 : serializeRaw 4066 27 parallel_r141 = some parallel_b141 := by decide +kernel
theorem parallel_p141 (tail : List Nat) : parseRaw 4066 27 (parallel_b141 ++ tail) = some (parallel_r141, tail) := by rfl
def parallel_r142 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,50]),(.str [100,103,95,118,95,49,54,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b142 : List Nat := parallel_g360
theorem parallel_s142 : serializeRaw 4065 27 parallel_r142 = some parallel_b142 := by decide +kernel
theorem parallel_p142 (tail : List Nat) : parseRaw 4065 27 (parallel_b142 ++ tail) = some (parallel_r142, tail) := by rfl
def parallel_r143 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b143 : List Nat := parallel_g363
theorem parallel_s143 : serializeRaw 4064 27 parallel_r143 = some parallel_b143 := by decide +kernel
theorem parallel_p143 (tail : List Nat) : parseRaw 4064 27 (parallel_b143 ++ tail) = some (parallel_r143, tail) := by rfl
def parallel_r144 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,54,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def parallel_b144 : List Nat := parallel_g366
theorem parallel_s144 : serializeRaw 4063 27 parallel_r144 = some parallel_b144 := by decide +kernel
theorem parallel_p144 (tail : List Nat) : parseRaw 4063 27 (parallel_b144 ++ tail) = some (parallel_r144, tail) := by rfl
def parallel_k140_0 : List Nat := [105,100]
theorem parallel_kd140_0 : stringBytes parallel_k140_0 = true := by decide +kernel
theorem parallel_kp140_0 (tail : List Nat) : parseStringTail (parallel_k140_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k140_0, 58 :: tail) := by rfl
def parallel_k140_1 : List Nat := [111,112,115]
theorem parallel_kd140_1 : stringBytes parallel_k140_1 = true := by decide +kernel
theorem parallel_kp140_1 (tail : List Nat) : parseStringTail (parallel_k140_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k140_1, 58 :: tail) := by rfl
def parallel_k140_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd140_2 : stringBytes parallel_k140_2 = true := by decide +kernel
theorem parallel_kp140_2 (tail : List Nat) : parseStringTail (parallel_k140_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k140_2, 58 :: tail) := by rfl
def parallel_k140_3 : List Nat := [116,101,114,109]
theorem parallel_kd140_3 : stringBytes parallel_k140_3 = true := by decide +kernel
theorem parallel_kp140_3 (tail : List Nat) : parseStringTail (parallel_k140_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k140_3, 58 :: tail) := by rfl
def parallel_l140_3 : List (List Nat × Raw) := [(parallel_k140_3, parallel_r144)]
def parallel_v140_3 : List Nat := parallel_g365 ++ parallel_b144
theorem parallel_sl140_3 : serializeFields 4064 27 parallel_l140_3 = some parallel_v140_3 := by
  simpa only [parallel_l140_3, parallel_v140_3, parallel_k140_3, parallel_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4063 27 parallel_k140_3 parallel_r144 parallel_b144 parallel_kd140_3 parallel_s144)
theorem parallel_pl140_3 (tail : List Nat) : parseFields 4064 27 (parallel_v140_3 ++ (125 :: tail)) = some (parallel_l140_3, tail) := by
  simpa only [parallel_l140_3, parallel_v140_3, parallel_k140_3, parallel_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4063 27 (parallel_k140_3 ++ (34 :: 58 :: (parallel_b144 ++ (125 :: tail)))) parallel_k140_3 (parallel_b144 ++ (125 :: tail)) tail parallel_r144 (parallel_kp140_3 (parallel_b144 ++ (125 :: tail))) (parallel_p144 (125 :: tail)))
def parallel_l140_2 : List (List Nat × Raw) := (parallel_k140_2, parallel_r143) :: parallel_l140_3
def parallel_v140_2 : List Nat := (parallel_g362 ++ parallel_b143) ++ (44 :: parallel_v140_3)
theorem parallel_sl140_2 : serializeFields 4065 27 parallel_l140_2 = some parallel_v140_2 := by
  simpa only [parallel_l140_2, parallel_v140_2, parallel_k140_2, parallel_g362, parallel_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 parallel_k140_2 parallel_r143 (parallel_k140_3, parallel_r144) [] parallel_b143 parallel_v140_3 parallel_kd140_2 parallel_s143 parallel_sl140_3)
theorem parallel_pl140_2 (tail : List Nat) : parseFields 4065 27 (parallel_v140_2 ++ (125 :: tail)) = some (parallel_l140_2, tail) := by
  simpa only [parallel_l140_2, parallel_v140_2, parallel_k140_2, parallel_g362, parallel_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (parallel_k140_2 ++ (34 :: 58 :: (parallel_b143 ++ (44 :: (parallel_v140_3 ++ (125 :: tail)))))) parallel_k140_2 (parallel_b143 ++ (44 :: (parallel_v140_3 ++ (125 :: tail)))) (parallel_v140_3 ++ (125 :: tail)) tail parallel_r143 parallel_l140_3 (parallel_kp140_2 (parallel_b143 ++ (44 :: (parallel_v140_3 ++ (125 :: tail))))) (parallel_p143 (44 :: (parallel_v140_3 ++ (125 :: tail)))) (parallel_pl140_3 tail))
def parallel_l140_1 : List (List Nat × Raw) := (parallel_k140_1, parallel_r142) :: parallel_l140_2
def parallel_v140_1 : List Nat := (parallel_g359 ++ parallel_b142) ++ (44 :: parallel_v140_2)
theorem parallel_sl140_1 : serializeFields 4066 27 parallel_l140_1 = some parallel_v140_1 := by
  simpa only [parallel_l140_1, parallel_v140_1, parallel_k140_1, parallel_g359, parallel_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 parallel_k140_1 parallel_r142 (parallel_k140_2, parallel_r143) parallel_l140_3 parallel_b142 parallel_v140_2 parallel_kd140_1 parallel_s142 parallel_sl140_2)
theorem parallel_pl140_1 (tail : List Nat) : parseFields 4066 27 (parallel_v140_1 ++ (125 :: tail)) = some (parallel_l140_1, tail) := by
  simpa only [parallel_l140_1, parallel_v140_1, parallel_k140_1, parallel_g359, parallel_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (parallel_k140_1 ++ (34 :: 58 :: (parallel_b142 ++ (44 :: (parallel_v140_2 ++ (125 :: tail)))))) parallel_k140_1 (parallel_b142 ++ (44 :: (parallel_v140_2 ++ (125 :: tail)))) (parallel_v140_2 ++ (125 :: tail)) tail parallel_r142 parallel_l140_2 (parallel_kp140_1 (parallel_b142 ++ (44 :: (parallel_v140_2 ++ (125 :: tail))))) (parallel_p142 (44 :: (parallel_v140_2 ++ (125 :: tail)))) (parallel_pl140_2 tail))
def parallel_l140_0 : List (List Nat × Raw) := (parallel_k140_0, parallel_r141) :: parallel_l140_1
def parallel_v140_0 : List Nat := (parallel_g356 ++ parallel_b141) ++ (44 :: parallel_v140_1)
theorem parallel_sl140_0 : serializeFields 4067 27 parallel_l140_0 = some parallel_v140_0 := by
  simpa only [parallel_l140_0, parallel_v140_0, parallel_k140_0, parallel_g356, parallel_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 parallel_k140_0 parallel_r141 (parallel_k140_1, parallel_r142) parallel_l140_2 parallel_b141 parallel_v140_1 parallel_kd140_0 parallel_s141 parallel_sl140_1)
theorem parallel_pl140_0 (tail : List Nat) : parseFields 4067 27 (parallel_v140_0 ++ (125 :: tail)) = some (parallel_l140_0, tail) := by
  simpa only [parallel_l140_0, parallel_v140_0, parallel_k140_0, parallel_g356, parallel_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (parallel_k140_0 ++ (34 :: 58 :: (parallel_b141 ++ (44 :: (parallel_v140_1 ++ (125 :: tail)))))) parallel_k140_0 (parallel_b141 ++ (44 :: (parallel_v140_1 ++ (125 :: tail)))) (parallel_v140_1 ++ (125 :: tail)) tail parallel_r141 parallel_l140_1 (parallel_kp140_0 (parallel_b141 ++ (44 :: (parallel_v140_1 ++ (125 :: tail))))) (parallel_p141 (44 :: (parallel_v140_1 ++ (125 :: tail)))) (parallel_pl140_1 tail))
def parallel_r140 : Raw := (.obj parallel_l140_0)
def parallel_b140 : List Nat := parallel_g355 ++ (parallel_v140_0 ++ parallel_g367)
theorem parallel_o140 : orderedFields parallel_l140_0 = true := by decide +kernel
theorem parallel_s140 : serializeRaw 4068 28 parallel_r140 = some parallel_b140 := by
  simpa only [parallel_r140, parallel_b140, parallel_g355, parallel_g367, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4067 27 parallel_l140_0 parallel_v140_0 parallel_o140 parallel_sl140_0)
theorem parallel_p140 (tail : List Nat) : parseRaw 4068 28 (parallel_b140 ++ tail) = some (parallel_r140, tail) := by
  simpa only [parallel_r140, parallel_b140, parallel_g355, parallel_g367, parallel_v140_0, parallel_k140_0, parallel_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4067 27 (parallel_k140_0 ++ (34 :: 58 :: (parallel_b141 ++ (44 :: (parallel_v140_1 ++ (125 :: tail)))))) tail parallel_l140_0 parallel_o140 (by simpa only [parallel_v140_0, parallel_k140_0, parallel_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl140_0 tail)))
def parallel_r146 : Raw := (.str [100,103,95,103,117,97,114,100,95,49])
def parallel_b146 : List Nat := parallel_g371
theorem parallel_s146 : serializeRaw 4065 27 parallel_r146 = some parallel_b146 := by decide +kernel
theorem parallel_p146 (tail : List Nat) : parseRaw 4065 27 (parallel_b146 ++ tail) = some (parallel_r146, tail) := by rfl
def parallel_r147 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,55,49]),(.str [100,103,95,118,95,49,55,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,51])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def parallel_b147 : List Nat := parallel_g374
theorem parallel_s147 : serializeRaw 4064 27 parallel_r147 = some parallel_b147 := by decide +kernel
theorem parallel_p147 (tail : List Nat) : parseRaw 4064 27 (parallel_b147 ++ tail) = some (parallel_r147, tail) := by rfl
def parallel_r148 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def parallel_b148 : List Nat := parallel_g377
theorem parallel_s148 : serializeRaw 4063 27 parallel_r148 = some parallel_b148 := by decide +kernel
theorem parallel_p148 (tail : List Nat) : parseRaw 4063 27 (parallel_b148 ++ tail) = some (parallel_r148, tail) := by rfl
def parallel_r149 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,55,51])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def parallel_b149 : List Nat := parallel_g380
theorem parallel_s149 : serializeRaw 4062 27 parallel_r149 = some parallel_b149 := by decide +kernel
theorem parallel_p149 (tail : List Nat) : parseRaw 4062 27 (parallel_b149 ++ tail) = some (parallel_r149, tail) := by rfl
def parallel_k145_0 : List Nat := [105,100]
theorem parallel_kd145_0 : stringBytes parallel_k145_0 = true := by decide +kernel
theorem parallel_kp145_0 (tail : List Nat) : parseStringTail (parallel_k145_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k145_0, 58 :: tail) := by rfl
def parallel_k145_1 : List Nat := [111,112,115]
theorem parallel_kd145_1 : stringBytes parallel_k145_1 = true := by decide +kernel
theorem parallel_kp145_1 (tail : List Nat) : parseStringTail (parallel_k145_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k145_1, 58 :: tail) := by rfl
def parallel_k145_2 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd145_2 : stringBytes parallel_k145_2 = true := by decide +kernel
theorem parallel_kp145_2 (tail : List Nat) : parseStringTail (parallel_k145_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k145_2, 58 :: tail) := by rfl
def parallel_k145_3 : List Nat := [116,101,114,109]
theorem parallel_kd145_3 : stringBytes parallel_k145_3 = true := by decide +kernel
theorem parallel_kp145_3 (tail : List Nat) : parseStringTail (parallel_k145_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k145_3, 58 :: tail) := by rfl
def parallel_l145_3 : List (List Nat × Raw) := [(parallel_k145_3, parallel_r149)]
def parallel_v145_3 : List Nat := parallel_g379 ++ parallel_b149
theorem parallel_sl145_3 : serializeFields 4063 27 parallel_l145_3 = some parallel_v145_3 := by
  simpa only [parallel_l145_3, parallel_v145_3, parallel_k145_3, parallel_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4062 27 parallel_k145_3 parallel_r149 parallel_b149 parallel_kd145_3 parallel_s149)
theorem parallel_pl145_3 (tail : List Nat) : parseFields 4063 27 (parallel_v145_3 ++ (125 :: tail)) = some (parallel_l145_3, tail) := by
  simpa only [parallel_l145_3, parallel_v145_3, parallel_k145_3, parallel_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4062 27 (parallel_k145_3 ++ (34 :: 58 :: (parallel_b149 ++ (125 :: tail)))) parallel_k145_3 (parallel_b149 ++ (125 :: tail)) tail parallel_r149 (parallel_kp145_3 (parallel_b149 ++ (125 :: tail))) (parallel_p149 (125 :: tail)))
def parallel_l145_2 : List (List Nat × Raw) := (parallel_k145_2, parallel_r148) :: parallel_l145_3
def parallel_v145_2 : List Nat := (parallel_g376 ++ parallel_b148) ++ (44 :: parallel_v145_3)
theorem parallel_sl145_2 : serializeFields 4064 27 parallel_l145_2 = some parallel_v145_2 := by
  simpa only [parallel_l145_2, parallel_v145_2, parallel_k145_2, parallel_g376, parallel_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4063 27 parallel_k145_2 parallel_r148 (parallel_k145_3, parallel_r149) [] parallel_b148 parallel_v145_3 parallel_kd145_2 parallel_s148 parallel_sl145_3)
theorem parallel_pl145_2 (tail : List Nat) : parseFields 4064 27 (parallel_v145_2 ++ (125 :: tail)) = some (parallel_l145_2, tail) := by
  simpa only [parallel_l145_2, parallel_v145_2, parallel_k145_2, parallel_g376, parallel_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4063 27 (parallel_k145_2 ++ (34 :: 58 :: (parallel_b148 ++ (44 :: (parallel_v145_3 ++ (125 :: tail)))))) parallel_k145_2 (parallel_b148 ++ (44 :: (parallel_v145_3 ++ (125 :: tail)))) (parallel_v145_3 ++ (125 :: tail)) tail parallel_r148 parallel_l145_3 (parallel_kp145_2 (parallel_b148 ++ (44 :: (parallel_v145_3 ++ (125 :: tail))))) (parallel_p148 (44 :: (parallel_v145_3 ++ (125 :: tail)))) (parallel_pl145_3 tail))
def parallel_l145_1 : List (List Nat × Raw) := (parallel_k145_1, parallel_r147) :: parallel_l145_2
def parallel_v145_1 : List Nat := (parallel_g373 ++ parallel_b147) ++ (44 :: parallel_v145_2)
theorem parallel_sl145_1 : serializeFields 4065 27 parallel_l145_1 = some parallel_v145_1 := by
  simpa only [parallel_l145_1, parallel_v145_1, parallel_k145_1, parallel_g373, parallel_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 parallel_k145_1 parallel_r147 (parallel_k145_2, parallel_r148) parallel_l145_3 parallel_b147 parallel_v145_2 parallel_kd145_1 parallel_s147 parallel_sl145_2)
theorem parallel_pl145_1 (tail : List Nat) : parseFields 4065 27 (parallel_v145_1 ++ (125 :: tail)) = some (parallel_l145_1, tail) := by
  simpa only [parallel_l145_1, parallel_v145_1, parallel_k145_1, parallel_g373, parallel_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (parallel_k145_1 ++ (34 :: 58 :: (parallel_b147 ++ (44 :: (parallel_v145_2 ++ (125 :: tail)))))) parallel_k145_1 (parallel_b147 ++ (44 :: (parallel_v145_2 ++ (125 :: tail)))) (parallel_v145_2 ++ (125 :: tail)) tail parallel_r147 parallel_l145_2 (parallel_kp145_1 (parallel_b147 ++ (44 :: (parallel_v145_2 ++ (125 :: tail))))) (parallel_p147 (44 :: (parallel_v145_2 ++ (125 :: tail)))) (parallel_pl145_2 tail))
def parallel_l145_0 : List (List Nat × Raw) := (parallel_k145_0, parallel_r146) :: parallel_l145_1
def parallel_v145_0 : List Nat := (parallel_g370 ++ parallel_b146) ++ (44 :: parallel_v145_1)
theorem parallel_sl145_0 : serializeFields 4066 27 parallel_l145_0 = some parallel_v145_0 := by
  simpa only [parallel_l145_0, parallel_v145_0, parallel_k145_0, parallel_g370, parallel_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 parallel_k145_0 parallel_r146 (parallel_k145_1, parallel_r147) parallel_l145_2 parallel_b146 parallel_v145_1 parallel_kd145_0 parallel_s146 parallel_sl145_1)
theorem parallel_pl145_0 (tail : List Nat) : parseFields 4066 27 (parallel_v145_0 ++ (125 :: tail)) = some (parallel_l145_0, tail) := by
  simpa only [parallel_l145_0, parallel_v145_0, parallel_k145_0, parallel_g370, parallel_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (parallel_k145_0 ++ (34 :: 58 :: (parallel_b146 ++ (44 :: (parallel_v145_1 ++ (125 :: tail)))))) parallel_k145_0 (parallel_b146 ++ (44 :: (parallel_v145_1 ++ (125 :: tail)))) (parallel_v145_1 ++ (125 :: tail)) tail parallel_r146 parallel_l145_1 (parallel_kp145_0 (parallel_b146 ++ (44 :: (parallel_v145_1 ++ (125 :: tail))))) (parallel_p146 (44 :: (parallel_v145_1 ++ (125 :: tail)))) (parallel_pl145_1 tail))
def parallel_r145 : Raw := (.obj parallel_l145_0)
def parallel_b145 : List Nat := parallel_g369 ++ (parallel_v145_0 ++ parallel_g381)
theorem parallel_o145 : orderedFields parallel_l145_0 = true := by decide +kernel
theorem parallel_s145 : serializeRaw 4067 28 parallel_r145 = some parallel_b145 := by
  simpa only [parallel_r145, parallel_b145, parallel_g369, parallel_g381, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4066 27 parallel_l145_0 parallel_v145_0 parallel_o145 parallel_sl145_0)
theorem parallel_p145 (tail : List Nat) : parseRaw 4067 28 (parallel_b145 ++ tail) = some (parallel_r145, tail) := by
  simpa only [parallel_r145, parallel_b145, parallel_g369, parallel_g381, parallel_v145_0, parallel_k145_0, parallel_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4066 27 (parallel_k145_0 ++ (34 :: 58 :: (parallel_b146 ++ (44 :: (parallel_v145_1 ++ (125 :: tail)))))) tail parallel_l145_0 parallel_o145 (by simpa only [parallel_v145_0, parallel_k145_0, parallel_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl145_0 tail)))
def parallel_l4_20 : List Raw := [parallel_r145]
def parallel_v4_20 : List Nat := parallel_b145
theorem parallel_sl4_20 : serializeItems 4068 28 parallel_l4_20 = some parallel_v4_20 := by
  simpa only [parallel_l4_20, parallel_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4067 28 parallel_r145 parallel_b145 parallel_s145)
theorem parallel_pl4_20 (tail : List Nat) : parseItems 4068 28 (parallel_v4_20 ++ (93 :: tail)) = some (parallel_l4_20, tail) := by
  simpa only [parallel_l4_20, parallel_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4067 28 (parallel_b145 ++ (93 :: tail)) tail parallel_r145 (parallel_p145 (93 :: tail)))
def parallel_l4_19 : List Raw := parallel_r140 :: parallel_l4_20
def parallel_v4_19 : List Nat := (parallel_b140) ++ (44 :: parallel_v4_20)
theorem parallel_sl4_19 : serializeItems 4069 28 parallel_l4_19 = some parallel_v4_19 := by
  simpa only [parallel_l4_19, parallel_v4_19, parallel_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 28 parallel_r140 parallel_r145 [] parallel_b140 parallel_v4_20 parallel_s140 parallel_sl4_20)
theorem parallel_pl4_19 (tail : List Nat) : parseItems 4069 28 (parallel_v4_19 ++ (93 :: tail)) = some (parallel_l4_19, tail) := by
  simpa only [parallel_l4_19, parallel_v4_19, parallel_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 28 (parallel_b140 ++ (44 :: (parallel_v4_20 ++ (93 :: tail)))) (parallel_v4_20 ++ (93 :: tail)) tail parallel_r140 parallel_l4_20 (parallel_p140 (44 :: (parallel_v4_20 ++ (93 :: tail)))) (parallel_pl4_20 tail))
def parallel_l4_18 : List Raw := parallel_r135 :: parallel_l4_19
def parallel_v4_18 : List Nat := (parallel_b135) ++ (44 :: parallel_v4_19)
theorem parallel_sl4_18 : serializeItems 4070 28 parallel_l4_18 = some parallel_v4_18 := by
  simpa only [parallel_l4_18, parallel_v4_18, parallel_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 28 parallel_r135 parallel_r140 parallel_l4_20 parallel_b135 parallel_v4_19 parallel_s135 parallel_sl4_19)
theorem parallel_pl4_18 (tail : List Nat) : parseItems 4070 28 (parallel_v4_18 ++ (93 :: tail)) = some (parallel_l4_18, tail) := by
  simpa only [parallel_l4_18, parallel_v4_18, parallel_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 28 (parallel_b135 ++ (44 :: (parallel_v4_19 ++ (93 :: tail)))) (parallel_v4_19 ++ (93 :: tail)) tail parallel_r135 parallel_l4_19 (parallel_p135 (44 :: (parallel_v4_19 ++ (93 :: tail)))) (parallel_pl4_19 tail))
def parallel_l4_17 : List Raw := parallel_r123 :: parallel_l4_18
def parallel_v4_17 : List Nat := (parallel_b123) ++ (44 :: parallel_v4_18)
theorem parallel_sl4_17 : serializeItems 4071 28 parallel_l4_17 = some parallel_v4_17 := by
  simpa only [parallel_l4_17, parallel_v4_17, parallel_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 28 parallel_r123 parallel_r135 parallel_l4_19 parallel_b123 parallel_v4_18 parallel_s123 parallel_sl4_18)
theorem parallel_pl4_17 (tail : List Nat) : parseItems 4071 28 (parallel_v4_17 ++ (93 :: tail)) = some (parallel_l4_17, tail) := by
  simpa only [parallel_l4_17, parallel_v4_17, parallel_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 28 (parallel_b123 ++ (44 :: (parallel_v4_18 ++ (93 :: tail)))) (parallel_v4_18 ++ (93 :: tail)) tail parallel_r123 parallel_l4_18 (parallel_p123 (44 :: (parallel_v4_18 ++ (93 :: tail)))) (parallel_pl4_18 tail))
def parallel_l4_16 : List Raw := parallel_r118 :: parallel_l4_17
def parallel_v4_16 : List Nat := (parallel_b118) ++ (44 :: parallel_v4_17)
theorem parallel_sl4_16 : serializeItems 4072 28 parallel_l4_16 = some parallel_v4_16 := by
  simpa only [parallel_l4_16, parallel_v4_16, parallel_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 28 parallel_r118 parallel_r123 parallel_l4_18 parallel_b118 parallel_v4_17 parallel_s118 parallel_sl4_17)
theorem parallel_pl4_16 (tail : List Nat) : parseItems 4072 28 (parallel_v4_16 ++ (93 :: tail)) = some (parallel_l4_16, tail) := by
  simpa only [parallel_l4_16, parallel_v4_16, parallel_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 28 (parallel_b118 ++ (44 :: (parallel_v4_17 ++ (93 :: tail)))) (parallel_v4_17 ++ (93 :: tail)) tail parallel_r118 parallel_l4_17 (parallel_p118 (44 :: (parallel_v4_17 ++ (93 :: tail)))) (parallel_pl4_17 tail))
def parallel_l4_15 : List Raw := parallel_r113 :: parallel_l4_16
def parallel_v4_15 : List Nat := (parallel_b113) ++ (44 :: parallel_v4_16)
theorem parallel_sl4_15 : serializeItems 4073 28 parallel_l4_15 = some parallel_v4_15 := by
  simpa only [parallel_l4_15, parallel_v4_15, parallel_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 28 parallel_r113 parallel_r118 parallel_l4_17 parallel_b113 parallel_v4_16 parallel_s113 parallel_sl4_16)
theorem parallel_pl4_15 (tail : List Nat) : parseItems 4073 28 (parallel_v4_15 ++ (93 :: tail)) = some (parallel_l4_15, tail) := by
  simpa only [parallel_l4_15, parallel_v4_15, parallel_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 28 (parallel_b113 ++ (44 :: (parallel_v4_16 ++ (93 :: tail)))) (parallel_v4_16 ++ (93 :: tail)) tail parallel_r113 parallel_l4_16 (parallel_p113 (44 :: (parallel_v4_16 ++ (93 :: tail)))) (parallel_pl4_16 tail))
def parallel_l4_14 : List Raw := parallel_r97 :: parallel_l4_15
def parallel_v4_14 : List Nat := (parallel_b97) ++ (44 :: parallel_v4_15)
theorem parallel_sl4_14 : serializeItems 4074 28 parallel_l4_14 = some parallel_v4_14 := by
  simpa only [parallel_l4_14, parallel_v4_14, parallel_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 28 parallel_r97 parallel_r113 parallel_l4_16 parallel_b97 parallel_v4_15 parallel_s97 parallel_sl4_15)
theorem parallel_pl4_14 (tail : List Nat) : parseItems 4074 28 (parallel_v4_14 ++ (93 :: tail)) = some (parallel_l4_14, tail) := by
  simpa only [parallel_l4_14, parallel_v4_14, parallel_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 28 (parallel_b97 ++ (44 :: (parallel_v4_15 ++ (93 :: tail)))) (parallel_v4_15 ++ (93 :: tail)) tail parallel_r97 parallel_l4_15 (parallel_p97 (44 :: (parallel_v4_15 ++ (93 :: tail)))) (parallel_pl4_15 tail))
def parallel_l4_13 : List Raw := parallel_r92 :: parallel_l4_14
def parallel_v4_13 : List Nat := (parallel_b92) ++ (44 :: parallel_v4_14)
theorem parallel_sl4_13 : serializeItems 4075 28 parallel_l4_13 = some parallel_v4_13 := by
  simpa only [parallel_l4_13, parallel_v4_13, parallel_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 28 parallel_r92 parallel_r97 parallel_l4_15 parallel_b92 parallel_v4_14 parallel_s92 parallel_sl4_14)
theorem parallel_pl4_13 (tail : List Nat) : parseItems 4075 28 (parallel_v4_13 ++ (93 :: tail)) = some (parallel_l4_13, tail) := by
  simpa only [parallel_l4_13, parallel_v4_13, parallel_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 28 (parallel_b92 ++ (44 :: (parallel_v4_14 ++ (93 :: tail)))) (parallel_v4_14 ++ (93 :: tail)) tail parallel_r92 parallel_l4_14 (parallel_p92 (44 :: (parallel_v4_14 ++ (93 :: tail)))) (parallel_pl4_14 tail))
def parallel_l4_12 : List Raw := parallel_r87 :: parallel_l4_13
def parallel_v4_12 : List Nat := (parallel_b87) ++ (44 :: parallel_v4_13)
theorem parallel_sl4_12 : serializeItems 4076 28 parallel_l4_12 = some parallel_v4_12 := by
  simpa only [parallel_l4_12, parallel_v4_12, parallel_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4075 28 parallel_r87 parallel_r92 parallel_l4_14 parallel_b87 parallel_v4_13 parallel_s87 parallel_sl4_13)
theorem parallel_pl4_12 (tail : List Nat) : parseItems 4076 28 (parallel_v4_12 ++ (93 :: tail)) = some (parallel_l4_12, tail) := by
  simpa only [parallel_l4_12, parallel_v4_12, parallel_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4075 28 (parallel_b87 ++ (44 :: (parallel_v4_13 ++ (93 :: tail)))) (parallel_v4_13 ++ (93 :: tail)) tail parallel_r87 parallel_l4_13 (parallel_p87 (44 :: (parallel_v4_13 ++ (93 :: tail)))) (parallel_pl4_13 tail))
def parallel_l4_11 : List Raw := parallel_r75 :: parallel_l4_12
def parallel_v4_11 : List Nat := (parallel_b75) ++ (44 :: parallel_v4_12)
theorem parallel_sl4_11 : serializeItems 4077 28 parallel_l4_11 = some parallel_v4_11 := by
  simpa only [parallel_l4_11, parallel_v4_11, parallel_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4076 28 parallel_r75 parallel_r87 parallel_l4_13 parallel_b75 parallel_v4_12 parallel_s75 parallel_sl4_12)
theorem parallel_pl4_11 (tail : List Nat) : parseItems 4077 28 (parallel_v4_11 ++ (93 :: tail)) = some (parallel_l4_11, tail) := by
  simpa only [parallel_l4_11, parallel_v4_11, parallel_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4076 28 (parallel_b75 ++ (44 :: (parallel_v4_12 ++ (93 :: tail)))) (parallel_v4_12 ++ (93 :: tail)) tail parallel_r75 parallel_l4_12 (parallel_p75 (44 :: (parallel_v4_12 ++ (93 :: tail)))) (parallel_pl4_12 tail))
def parallel_l4_10 : List Raw := parallel_r70 :: parallel_l4_11
def parallel_v4_10 : List Nat := (parallel_b70) ++ (44 :: parallel_v4_11)
theorem parallel_sl4_10 : serializeItems 4078 28 parallel_l4_10 = some parallel_v4_10 := by
  simpa only [parallel_l4_10, parallel_v4_10, parallel_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4077 28 parallel_r70 parallel_r75 parallel_l4_12 parallel_b70 parallel_v4_11 parallel_s70 parallel_sl4_11)
theorem parallel_pl4_10 (tail : List Nat) : parseItems 4078 28 (parallel_v4_10 ++ (93 :: tail)) = some (parallel_l4_10, tail) := by
  simpa only [parallel_l4_10, parallel_v4_10, parallel_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4077 28 (parallel_b70 ++ (44 :: (parallel_v4_11 ++ (93 :: tail)))) (parallel_v4_11 ++ (93 :: tail)) tail parallel_r70 parallel_l4_11 (parallel_p70 (44 :: (parallel_v4_11 ++ (93 :: tail)))) (parallel_pl4_11 tail))
def parallel_l4_9 : List Raw := parallel_r65 :: parallel_l4_10
def parallel_v4_9 : List Nat := (parallel_b65) ++ (44 :: parallel_v4_10)
theorem parallel_sl4_9 : serializeItems 4079 28 parallel_l4_9 = some parallel_v4_9 := by
  simpa only [parallel_l4_9, parallel_v4_9, parallel_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 28 parallel_r65 parallel_r70 parallel_l4_11 parallel_b65 parallel_v4_10 parallel_s65 parallel_sl4_10)
theorem parallel_pl4_9 (tail : List Nat) : parseItems 4079 28 (parallel_v4_9 ++ (93 :: tail)) = some (parallel_l4_9, tail) := by
  simpa only [parallel_l4_9, parallel_v4_9, parallel_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 28 (parallel_b65 ++ (44 :: (parallel_v4_10 ++ (93 :: tail)))) (parallel_v4_10 ++ (93 :: tail)) tail parallel_r65 parallel_l4_10 (parallel_p65 (44 :: (parallel_v4_10 ++ (93 :: tail)))) (parallel_pl4_10 tail))
def parallel_l4_8 : List Raw := parallel_r49 :: parallel_l4_9
def parallel_v4_8 : List Nat := (parallel_b49) ++ (44 :: parallel_v4_9)
theorem parallel_sl4_8 : serializeItems 4080 28 parallel_l4_8 = some parallel_v4_8 := by
  simpa only [parallel_l4_8, parallel_v4_8, parallel_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 28 parallel_r49 parallel_r65 parallel_l4_10 parallel_b49 parallel_v4_9 parallel_s49 parallel_sl4_9)
theorem parallel_pl4_8 (tail : List Nat) : parseItems 4080 28 (parallel_v4_8 ++ (93 :: tail)) = some (parallel_l4_8, tail) := by
  simpa only [parallel_l4_8, parallel_v4_8, parallel_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 28 (parallel_b49 ++ (44 :: (parallel_v4_9 ++ (93 :: tail)))) (parallel_v4_9 ++ (93 :: tail)) tail parallel_r49 parallel_l4_9 (parallel_p49 (44 :: (parallel_v4_9 ++ (93 :: tail)))) (parallel_pl4_9 tail))
def parallel_l4_7 : List Raw := parallel_r44 :: parallel_l4_8
def parallel_v4_7 : List Nat := (parallel_b44) ++ (44 :: parallel_v4_8)
theorem parallel_sl4_7 : serializeItems 4081 28 parallel_l4_7 = some parallel_v4_7 := by
  simpa only [parallel_l4_7, parallel_v4_7, parallel_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 28 parallel_r44 parallel_r49 parallel_l4_9 parallel_b44 parallel_v4_8 parallel_s44 parallel_sl4_8)
theorem parallel_pl4_7 (tail : List Nat) : parseItems 4081 28 (parallel_v4_7 ++ (93 :: tail)) = some (parallel_l4_7, tail) := by
  simpa only [parallel_l4_7, parallel_v4_7, parallel_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 28 (parallel_b44 ++ (44 :: (parallel_v4_8 ++ (93 :: tail)))) (parallel_v4_8 ++ (93 :: tail)) tail parallel_r44 parallel_l4_8 (parallel_p44 (44 :: (parallel_v4_8 ++ (93 :: tail)))) (parallel_pl4_8 tail))
def parallel_l4_6 : List Raw := parallel_r39 :: parallel_l4_7
def parallel_v4_6 : List Nat := (parallel_b39) ++ (44 :: parallel_v4_7)
theorem parallel_sl4_6 : serializeItems 4082 28 parallel_l4_6 = some parallel_v4_6 := by
  simpa only [parallel_l4_6, parallel_v4_6, parallel_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4081 28 parallel_r39 parallel_r44 parallel_l4_8 parallel_b39 parallel_v4_7 parallel_s39 parallel_sl4_7)
theorem parallel_pl4_6 (tail : List Nat) : parseItems 4082 28 (parallel_v4_6 ++ (93 :: tail)) = some (parallel_l4_6, tail) := by
  simpa only [parallel_l4_6, parallel_v4_6, parallel_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4081 28 (parallel_b39 ++ (44 :: (parallel_v4_7 ++ (93 :: tail)))) (parallel_v4_7 ++ (93 :: tail)) tail parallel_r39 parallel_l4_7 (parallel_p39 (44 :: (parallel_v4_7 ++ (93 :: tail)))) (parallel_pl4_7 tail))
def parallel_l4_5 : List Raw := parallel_r34 :: parallel_l4_6
def parallel_v4_5 : List Nat := (parallel_b34) ++ (44 :: parallel_v4_6)
theorem parallel_sl4_5 : serializeItems 4083 28 parallel_l4_5 = some parallel_v4_5 := by
  simpa only [parallel_l4_5, parallel_v4_5, parallel_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4082 28 parallel_r34 parallel_r39 parallel_l4_7 parallel_b34 parallel_v4_6 parallel_s34 parallel_sl4_6)
theorem parallel_pl4_5 (tail : List Nat) : parseItems 4083 28 (parallel_v4_5 ++ (93 :: tail)) = some (parallel_l4_5, tail) := by
  simpa only [parallel_l4_5, parallel_v4_5, parallel_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4082 28 (parallel_b34 ++ (44 :: (parallel_v4_6 ++ (93 :: tail)))) (parallel_v4_6 ++ (93 :: tail)) tail parallel_r34 parallel_l4_6 (parallel_p34 (44 :: (parallel_v4_6 ++ (93 :: tail)))) (parallel_pl4_6 tail))
def parallel_l4_4 : List Raw := parallel_r29 :: parallel_l4_5
def parallel_v4_4 : List Nat := (parallel_b29) ++ (44 :: parallel_v4_5)
theorem parallel_sl4_4 : serializeItems 4084 28 parallel_l4_4 = some parallel_v4_4 := by
  simpa only [parallel_l4_4, parallel_v4_4, parallel_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4083 28 parallel_r29 parallel_r34 parallel_l4_6 parallel_b29 parallel_v4_5 parallel_s29 parallel_sl4_5)
theorem parallel_pl4_4 (tail : List Nat) : parseItems 4084 28 (parallel_v4_4 ++ (93 :: tail)) = some (parallel_l4_4, tail) := by
  simpa only [parallel_l4_4, parallel_v4_4, parallel_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4083 28 (parallel_b29 ++ (44 :: (parallel_v4_5 ++ (93 :: tail)))) (parallel_v4_5 ++ (93 :: tail)) tail parallel_r29 parallel_l4_5 (parallel_p29 (44 :: (parallel_v4_5 ++ (93 :: tail)))) (parallel_pl4_5 tail))
def parallel_l4_3 : List Raw := parallel_r24 :: parallel_l4_4
def parallel_v4_3 : List Nat := (parallel_b24) ++ (44 :: parallel_v4_4)
theorem parallel_sl4_3 : serializeItems 4085 28 parallel_l4_3 = some parallel_v4_3 := by
  simpa only [parallel_l4_3, parallel_v4_3, parallel_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4084 28 parallel_r24 parallel_r29 parallel_l4_5 parallel_b24 parallel_v4_4 parallel_s24 parallel_sl4_4)
theorem parallel_pl4_3 (tail : List Nat) : parseItems 4085 28 (parallel_v4_3 ++ (93 :: tail)) = some (parallel_l4_3, tail) := by
  simpa only [parallel_l4_3, parallel_v4_3, parallel_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4084 28 (parallel_b24 ++ (44 :: (parallel_v4_4 ++ (93 :: tail)))) (parallel_v4_4 ++ (93 :: tail)) tail parallel_r24 parallel_l4_4 (parallel_p24 (44 :: (parallel_v4_4 ++ (93 :: tail)))) (parallel_pl4_4 tail))
def parallel_l4_2 : List Raw := parallel_r15 :: parallel_l4_3
def parallel_v4_2 : List Nat := (parallel_b15) ++ (44 :: parallel_v4_3)
theorem parallel_sl4_2 : serializeItems 4086 28 parallel_l4_2 = some parallel_v4_2 := by
  simpa only [parallel_l4_2, parallel_v4_2, parallel_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4085 28 parallel_r15 parallel_r24 parallel_l4_4 parallel_b15 parallel_v4_3 parallel_s15 parallel_sl4_3)
theorem parallel_pl4_2 (tail : List Nat) : parseItems 4086 28 (parallel_v4_2 ++ (93 :: tail)) = some (parallel_l4_2, tail) := by
  simpa only [parallel_l4_2, parallel_v4_2, parallel_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4085 28 (parallel_b15 ++ (44 :: (parallel_v4_3 ++ (93 :: tail)))) (parallel_v4_3 ++ (93 :: tail)) tail parallel_r15 parallel_l4_3 (parallel_p15 (44 :: (parallel_v4_3 ++ (93 :: tail)))) (parallel_pl4_3 tail))
def parallel_l4_1 : List Raw := parallel_r10 :: parallel_l4_2
def parallel_v4_1 : List Nat := (parallel_b10) ++ (44 :: parallel_v4_2)
theorem parallel_sl4_1 : serializeItems 4087 28 parallel_l4_1 = some parallel_v4_1 := by
  simpa only [parallel_l4_1, parallel_v4_1, parallel_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4086 28 parallel_r10 parallel_r15 parallel_l4_3 parallel_b10 parallel_v4_2 parallel_s10 parallel_sl4_2)
theorem parallel_pl4_1 (tail : List Nat) : parseItems 4087 28 (parallel_v4_1 ++ (93 :: tail)) = some (parallel_l4_1, tail) := by
  simpa only [parallel_l4_1, parallel_v4_1, parallel_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4086 28 (parallel_b10 ++ (44 :: (parallel_v4_2 ++ (93 :: tail)))) (parallel_v4_2 ++ (93 :: tail)) tail parallel_r10 parallel_l4_2 (parallel_p10 (44 :: (parallel_v4_2 ++ (93 :: tail)))) (parallel_pl4_2 tail))
def parallel_l4_0 : List Raw := parallel_r5 :: parallel_l4_1
def parallel_v4_0 : List Nat := (parallel_b5) ++ (44 :: parallel_v4_1)
theorem parallel_sl4_0 : serializeItems 4088 28 parallel_l4_0 = some parallel_v4_0 := by
  simpa only [parallel_l4_0, parallel_v4_0, parallel_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4087 28 parallel_r5 parallel_r10 parallel_l4_2 parallel_b5 parallel_v4_1 parallel_s5 parallel_sl4_1)
theorem parallel_pl4_0 (tail : List Nat) : parseItems 4088 28 (parallel_v4_0 ++ (93 :: tail)) = some (parallel_l4_0, tail) := by
  simpa only [parallel_l4_0, parallel_v4_0, parallel_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4087 28 (parallel_b5 ++ (44 :: (parallel_v4_1 ++ (93 :: tail)))) (parallel_v4_1 ++ (93 :: tail)) tail parallel_r5 parallel_l4_1 (parallel_p5 (44 :: (parallel_v4_1 ++ (93 :: tail)))) (parallel_pl4_1 tail))
def parallel_r4 : Raw := (.arr parallel_l4_0)
def parallel_b4 : List Nat := parallel_g8 ++ (parallel_v4_0 ++ parallel_g382)
theorem parallel_s4 : serializeRaw 4089 29 parallel_r4 = some parallel_b4 := by
  simpa only [parallel_r4, parallel_b4, parallel_g8, parallel_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4088 28 parallel_l4_0 parallel_v4_0 parallel_sl4_0)
theorem parallel_p4 (tail : List Nat) : parseRaw 4089 29 (parallel_b4 ++ tail) = some (parallel_r4, tail) := by
  simpa only [parallel_r4, parallel_b4, parallel_g8, parallel_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4088 28 (parallel_v4_0 ++ (93 :: tail)) tail parallel_l4_0 (by intro h; cases h) (parallel_pl4_0 tail))
def parallel_r150 : Raw := (.arr [(.str [97,108,108,111,99]),(.str [114,101,97,100]),(.str [116,114,97,112]),(.str [119,114,105,116,101])])
def parallel_b150 : List Nat := parallel_g385
theorem parallel_s150 : serializeRaw 4088 29 parallel_r150 = some parallel_b150 := by decide +kernel
theorem parallel_p150 (tail : List Nat) : parseRaw 4088 29 (parallel_b150 ++ tail) = some (parallel_r150, tail) := by rfl
def parallel_r151 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def parallel_b151 : List Nat := parallel_g388
theorem parallel_s151 : serializeRaw 4087 29 parallel_r151 = some parallel_b151 := by decide +kernel
theorem parallel_p151 (tail : List Nat) : parseRaw 4087 29 (parallel_b151 ++ tail) = some (parallel_r151, tail) := by rfl
def parallel_r152 : Raw := (.str [99,97,108,99,117,108,97,116,101])
def parallel_b152 : List Nat := parallel_g391
theorem parallel_s152 : serializeRaw 4086 29 parallel_r152 = some parallel_b152 := by decide +kernel
theorem parallel_p152 (tail : List Nat) : parseRaw 4086 29 (parallel_b152 ++ tail) = some (parallel_r152, tail) := by rfl
def parallel_r153 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def parallel_b153 : List Nat := parallel_g394
theorem parallel_s153 : serializeRaw 4085 29 parallel_r153 = some parallel_b153 := by decide +kernel
theorem parallel_p153 (tail : List Nat) : parseRaw 4085 29 (parallel_b153 ++ tail) = some (parallel_r153, tail) := by rfl
def parallel_r154 : Raw := (.arr [(.str [117,54,52])])
def parallel_b154 : List Nat := parallel_g397
theorem parallel_s154 : serializeRaw 4084 29 parallel_r154 = some parallel_b154 := by decide +kernel
theorem parallel_p154 (tail : List Nat) : parseRaw 4084 29 (parallel_b154 ++ tail) = some (parallel_r154, tail) := by rfl
def parallel_k3_0 : List Nat := [98,108,111,99,107,115]
theorem parallel_kd3_0 : stringBytes parallel_k3_0 = true := by decide +kernel
theorem parallel_kp3_0 (tail : List Nat) : parseStringTail (parallel_k3_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k3_0, 58 :: tail) := by rfl
def parallel_k3_1 : List Nat := [101,102,102,101,99,116,115]
theorem parallel_kd3_1 : stringBytes parallel_k3_1 = true := by decide +kernel
theorem parallel_kp3_1 (tail : List Nat) : parseStringTail (parallel_k3_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k3_1, 58 :: tail) := by rfl
def parallel_k3_2 : List Nat := [101,110,116,114,121]
theorem parallel_kd3_2 : stringBytes parallel_k3_2 = true := by decide +kernel
theorem parallel_kp3_2 (tail : List Nat) : parseStringTail (parallel_k3_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k3_2, 58 :: tail) := by rfl
def parallel_k3_3 : List Nat := [110,97,109,101]
theorem parallel_kd3_3 : stringBytes parallel_k3_3 = true := by decide +kernel
theorem parallel_kp3_3 (tail : List Nat) : parseStringTail (parallel_k3_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k3_3, 58 :: tail) := by rfl
def parallel_k3_4 : List Nat := [112,97,114,97,109,115]
theorem parallel_kd3_4 : stringBytes parallel_k3_4 = true := by decide +kernel
theorem parallel_kp3_4 (tail : List Nat) : parseStringTail (parallel_k3_4 ++ (34 :: 58 :: tail)) [] = some (parallel_k3_4, 58 :: tail) := by rfl
def parallel_k3_5 : List Nat := [114,101,116,117,114,110,115]
theorem parallel_kd3_5 : stringBytes parallel_k3_5 = true := by decide +kernel
theorem parallel_kp3_5 (tail : List Nat) : parseStringTail (parallel_k3_5 ++ (34 :: 58 :: tail)) [] = some (parallel_k3_5, 58 :: tail) := by rfl
def parallel_l3_5 : List (List Nat × Raw) := [(parallel_k3_5, parallel_r154)]
def parallel_v3_5 : List Nat := parallel_g396 ++ parallel_b154
theorem parallel_sl3_5 : serializeFields 4085 29 parallel_l3_5 = some parallel_v3_5 := by
  simpa only [parallel_l3_5, parallel_v3_5, parallel_k3_5, parallel_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4084 29 parallel_k3_5 parallel_r154 parallel_b154 parallel_kd3_5 parallel_s154)
theorem parallel_pl3_5 (tail : List Nat) : parseFields 4085 29 (parallel_v3_5 ++ (125 :: tail)) = some (parallel_l3_5, tail) := by
  simpa only [parallel_l3_5, parallel_v3_5, parallel_k3_5, parallel_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4084 29 (parallel_k3_5 ++ (34 :: 58 :: (parallel_b154 ++ (125 :: tail)))) parallel_k3_5 (parallel_b154 ++ (125 :: tail)) tail parallel_r154 (parallel_kp3_5 (parallel_b154 ++ (125 :: tail))) (parallel_p154 (125 :: tail)))
def parallel_l3_4 : List (List Nat × Raw) := (parallel_k3_4, parallel_r153) :: parallel_l3_5
def parallel_v3_4 : List Nat := (parallel_g393 ++ parallel_b153) ++ (44 :: parallel_v3_5)
theorem parallel_sl3_4 : serializeFields 4086 29 parallel_l3_4 = some parallel_v3_4 := by
  simpa only [parallel_l3_4, parallel_v3_4, parallel_k3_4, parallel_g393, parallel_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 29 parallel_k3_4 parallel_r153 (parallel_k3_5, parallel_r154) [] parallel_b153 parallel_v3_5 parallel_kd3_4 parallel_s153 parallel_sl3_5)
theorem parallel_pl3_4 (tail : List Nat) : parseFields 4086 29 (parallel_v3_4 ++ (125 :: tail)) = some (parallel_l3_4, tail) := by
  simpa only [parallel_l3_4, parallel_v3_4, parallel_k3_4, parallel_g393, parallel_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 29 (parallel_k3_4 ++ (34 :: 58 :: (parallel_b153 ++ (44 :: (parallel_v3_5 ++ (125 :: tail)))))) parallel_k3_4 (parallel_b153 ++ (44 :: (parallel_v3_5 ++ (125 :: tail)))) (parallel_v3_5 ++ (125 :: tail)) tail parallel_r153 parallel_l3_5 (parallel_kp3_4 (parallel_b153 ++ (44 :: (parallel_v3_5 ++ (125 :: tail))))) (parallel_p153 (44 :: (parallel_v3_5 ++ (125 :: tail)))) (parallel_pl3_5 tail))
def parallel_l3_3 : List (List Nat × Raw) := (parallel_k3_3, parallel_r152) :: parallel_l3_4
def parallel_v3_3 : List Nat := (parallel_g390 ++ parallel_b152) ++ (44 :: parallel_v3_4)
theorem parallel_sl3_3 : serializeFields 4087 29 parallel_l3_3 = some parallel_v3_3 := by
  simpa only [parallel_l3_3, parallel_v3_3, parallel_k3_3, parallel_g390, parallel_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4086 29 parallel_k3_3 parallel_r152 (parallel_k3_4, parallel_r153) parallel_l3_5 parallel_b152 parallel_v3_4 parallel_kd3_3 parallel_s152 parallel_sl3_4)
theorem parallel_pl3_3 (tail : List Nat) : parseFields 4087 29 (parallel_v3_3 ++ (125 :: tail)) = some (parallel_l3_3, tail) := by
  simpa only [parallel_l3_3, parallel_v3_3, parallel_k3_3, parallel_g390, parallel_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4086 29 (parallel_k3_3 ++ (34 :: 58 :: (parallel_b152 ++ (44 :: (parallel_v3_4 ++ (125 :: tail)))))) parallel_k3_3 (parallel_b152 ++ (44 :: (parallel_v3_4 ++ (125 :: tail)))) (parallel_v3_4 ++ (125 :: tail)) tail parallel_r152 parallel_l3_4 (parallel_kp3_3 (parallel_b152 ++ (44 :: (parallel_v3_4 ++ (125 :: tail))))) (parallel_p152 (44 :: (parallel_v3_4 ++ (125 :: tail)))) (parallel_pl3_4 tail))
def parallel_l3_2 : List (List Nat × Raw) := (parallel_k3_2, parallel_r151) :: parallel_l3_3
def parallel_v3_2 : List Nat := (parallel_g387 ++ parallel_b151) ++ (44 :: parallel_v3_3)
theorem parallel_sl3_2 : serializeFields 4088 29 parallel_l3_2 = some parallel_v3_2 := by
  simpa only [parallel_l3_2, parallel_v3_2, parallel_k3_2, parallel_g387, parallel_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4087 29 parallel_k3_2 parallel_r151 (parallel_k3_3, parallel_r152) parallel_l3_4 parallel_b151 parallel_v3_3 parallel_kd3_2 parallel_s151 parallel_sl3_3)
theorem parallel_pl3_2 (tail : List Nat) : parseFields 4088 29 (parallel_v3_2 ++ (125 :: tail)) = some (parallel_l3_2, tail) := by
  simpa only [parallel_l3_2, parallel_v3_2, parallel_k3_2, parallel_g387, parallel_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4087 29 (parallel_k3_2 ++ (34 :: 58 :: (parallel_b151 ++ (44 :: (parallel_v3_3 ++ (125 :: tail)))))) parallel_k3_2 (parallel_b151 ++ (44 :: (parallel_v3_3 ++ (125 :: tail)))) (parallel_v3_3 ++ (125 :: tail)) tail parallel_r151 parallel_l3_3 (parallel_kp3_2 (parallel_b151 ++ (44 :: (parallel_v3_3 ++ (125 :: tail))))) (parallel_p151 (44 :: (parallel_v3_3 ++ (125 :: tail)))) (parallel_pl3_3 tail))
def parallel_l3_1 : List (List Nat × Raw) := (parallel_k3_1, parallel_r150) :: parallel_l3_2
def parallel_v3_1 : List Nat := (parallel_g384 ++ parallel_b150) ++ (44 :: parallel_v3_2)
theorem parallel_sl3_1 : serializeFields 4089 29 parallel_l3_1 = some parallel_v3_1 := by
  simpa only [parallel_l3_1, parallel_v3_1, parallel_k3_1, parallel_g384, parallel_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4088 29 parallel_k3_1 parallel_r150 (parallel_k3_2, parallel_r151) parallel_l3_3 parallel_b150 parallel_v3_2 parallel_kd3_1 parallel_s150 parallel_sl3_2)
theorem parallel_pl3_1 (tail : List Nat) : parseFields 4089 29 (parallel_v3_1 ++ (125 :: tail)) = some (parallel_l3_1, tail) := by
  simpa only [parallel_l3_1, parallel_v3_1, parallel_k3_1, parallel_g384, parallel_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4088 29 (parallel_k3_1 ++ (34 :: 58 :: (parallel_b150 ++ (44 :: (parallel_v3_2 ++ (125 :: tail)))))) parallel_k3_1 (parallel_b150 ++ (44 :: (parallel_v3_2 ++ (125 :: tail)))) (parallel_v3_2 ++ (125 :: tail)) tail parallel_r150 parallel_l3_2 (parallel_kp3_1 (parallel_b150 ++ (44 :: (parallel_v3_2 ++ (125 :: tail))))) (parallel_p150 (44 :: (parallel_v3_2 ++ (125 :: tail)))) (parallel_pl3_2 tail))
def parallel_l3_0 : List (List Nat × Raw) := (parallel_k3_0, parallel_r4) :: parallel_l3_1
def parallel_v3_0 : List Nat := (parallel_g7 ++ parallel_b4) ++ (44 :: parallel_v3_1)
theorem parallel_sl3_0 : serializeFields 4090 29 parallel_l3_0 = some parallel_v3_0 := by
  simpa only [parallel_l3_0, parallel_v3_0, parallel_k3_0, parallel_g7, parallel_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4089 29 parallel_k3_0 parallel_r4 (parallel_k3_1, parallel_r150) parallel_l3_2 parallel_b4 parallel_v3_1 parallel_kd3_0 parallel_s4 parallel_sl3_1)
theorem parallel_pl3_0 (tail : List Nat) : parseFields 4090 29 (parallel_v3_0 ++ (125 :: tail)) = some (parallel_l3_0, tail) := by
  simpa only [parallel_l3_0, parallel_v3_0, parallel_k3_0, parallel_g7, parallel_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4089 29 (parallel_k3_0 ++ (34 :: 58 :: (parallel_b4 ++ (44 :: (parallel_v3_1 ++ (125 :: tail)))))) parallel_k3_0 (parallel_b4 ++ (44 :: (parallel_v3_1 ++ (125 :: tail)))) (parallel_v3_1 ++ (125 :: tail)) tail parallel_r4 parallel_l3_1 (parallel_kp3_0 (parallel_b4 ++ (44 :: (parallel_v3_1 ++ (125 :: tail))))) (parallel_p4 (44 :: (parallel_v3_1 ++ (125 :: tail)))) (parallel_pl3_1 tail))
def parallel_r3 : Raw := (.obj parallel_l3_0)
def parallel_b3 : List Nat := parallel_g6 ++ (parallel_v3_0 ++ parallel_g398)
theorem parallel_o3 : orderedFields parallel_l3_0 = true := by decide +kernel
theorem parallel_s3 : serializeRaw 4091 30 parallel_r3 = some parallel_b3 := by
  simpa only [parallel_r3, parallel_b3, parallel_g6, parallel_g398, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4090 29 parallel_l3_0 parallel_v3_0 parallel_o3 parallel_sl3_0)
theorem parallel_p3 (tail : List Nat) : parseRaw 4091 30 (parallel_b3 ++ tail) = some (parallel_r3, tail) := by
  simpa only [parallel_r3, parallel_b3, parallel_g6, parallel_g398, parallel_v3_0, parallel_k3_0, parallel_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4090 29 (parallel_k3_0 ++ (34 :: 58 :: (parallel_b4 ++ (44 :: (parallel_v3_1 ++ (125 :: tail)))))) tail parallel_l3_0 parallel_o3 (by simpa only [parallel_v3_0, parallel_k3_0, parallel_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl3_0 tail)))
def parallel_l2_0 : List Raw := [parallel_r3]
def parallel_v2_0 : List Nat := parallel_b3
theorem parallel_sl2_0 : serializeItems 4092 30 parallel_l2_0 = some parallel_v2_0 := by
  simpa only [parallel_l2_0, parallel_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4091 30 parallel_r3 parallel_b3 parallel_s3)
theorem parallel_pl2_0 (tail : List Nat) : parseItems 4092 30 (parallel_v2_0 ++ (93 :: tail)) = some (parallel_l2_0, tail) := by
  simpa only [parallel_l2_0, parallel_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4091 30 (parallel_b3 ++ (93 :: tail)) tail parallel_r3 (parallel_p3 (93 :: tail)))
def parallel_r2 : Raw := (.arr parallel_l2_0)
def parallel_b2 : List Nat := parallel_g5 ++ (parallel_v2_0 ++ parallel_g399)
theorem parallel_s2 : serializeRaw 4093 31 parallel_r2 = some parallel_b2 := by
  simpa only [parallel_r2, parallel_b2, parallel_g5, parallel_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4092 30 parallel_l2_0 parallel_v2_0 parallel_sl2_0)
theorem parallel_p2 (tail : List Nat) : parseRaw 4093 31 (parallel_b2 ++ tail) = some (parallel_r2, tail) := by
  simpa only [parallel_r2, parallel_b2, parallel_g5, parallel_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4092 30 (parallel_v2_0 ++ (93 :: tail)) tail parallel_l2_0 (by intro h; cases h) (parallel_pl2_0 tail))
def parallel_r155 : Raw := (.str [114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114])
def parallel_b155 : List Nat := parallel_g402
theorem parallel_s155 : serializeRaw 4092 31 parallel_r155 = some parallel_b155 := by decide +kernel
theorem parallel_p155 (tail : List Nat) : parseRaw 4092 31 (parallel_b155 ++ tail) = some (parallel_r155, tail) := by rfl
def parallel_r156 : Raw := (.str [104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49])
def parallel_b156 : List Nat := parallel_g405
theorem parallel_s156 : serializeRaw 4091 31 parallel_r156 = some parallel_b156 := by decide +kernel
theorem parallel_p156 (tail : List Nat) : parseRaw 4091 31 (parallel_b156 ++ tail) = some (parallel_r156, tail) := by rfl
def parallel_k0_0 : List Nat := [101,120,112,111,114,116,115]
theorem parallel_kd0_0 : stringBytes parallel_k0_0 = true := by decide +kernel
theorem parallel_kp0_0 (tail : List Nat) : parseStringTail (parallel_k0_0 ++ (34 :: 58 :: tail)) [] = some (parallel_k0_0, 58 :: tail) := by rfl
def parallel_k0_1 : List Nat := [102,117,110,99,116,105,111,110,115]
theorem parallel_kd0_1 : stringBytes parallel_k0_1 = true := by decide +kernel
theorem parallel_kp0_1 (tail : List Nat) : parseStringTail (parallel_k0_1 ++ (34 :: 58 :: tail)) [] = some (parallel_k0_1, 58 :: tail) := by rfl
def parallel_k0_2 : List Nat := [109,111,100,117,108,101]
theorem parallel_kd0_2 : stringBytes parallel_k0_2 = true := by decide +kernel
theorem parallel_kp0_2 (tail : List Nat) : parseStringTail (parallel_k0_2 ++ (34 :: 58 :: tail)) [] = some (parallel_k0_2, 58 :: tail) := by rfl
def parallel_k0_3 : List Nat := [115,99,104,101,109,97]
theorem parallel_kd0_3 : stringBytes parallel_k0_3 = true := by decide +kernel
theorem parallel_kp0_3 (tail : List Nat) : parseStringTail (parallel_k0_3 ++ (34 :: 58 :: tail)) [] = some (parallel_k0_3, 58 :: tail) := by rfl
def parallel_l0_3 : List (List Nat × Raw) := [(parallel_k0_3, parallel_r156)]
def parallel_v0_3 : List Nat := parallel_g404 ++ parallel_b156
theorem parallel_sl0_3 : serializeFields 4092 31 parallel_l0_3 = some parallel_v0_3 := by
  simpa only [parallel_l0_3, parallel_v0_3, parallel_k0_3, parallel_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4091 31 parallel_k0_3 parallel_r156 parallel_b156 parallel_kd0_3 parallel_s156)
theorem parallel_pl0_3 (tail : List Nat) : parseFields 4092 31 (parallel_v0_3 ++ (125 :: tail)) = some (parallel_l0_3, tail) := by
  simpa only [parallel_l0_3, parallel_v0_3, parallel_k0_3, parallel_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4091 31 (parallel_k0_3 ++ (34 :: 58 :: (parallel_b156 ++ (125 :: tail)))) parallel_k0_3 (parallel_b156 ++ (125 :: tail)) tail parallel_r156 (parallel_kp0_3 (parallel_b156 ++ (125 :: tail))) (parallel_p156 (125 :: tail)))
def parallel_l0_2 : List (List Nat × Raw) := (parallel_k0_2, parallel_r155) :: parallel_l0_3
def parallel_v0_2 : List Nat := (parallel_g401 ++ parallel_b155) ++ (44 :: parallel_v0_3)
theorem parallel_sl0_2 : serializeFields 4093 31 parallel_l0_2 = some parallel_v0_2 := by
  simpa only [parallel_l0_2, parallel_v0_2, parallel_k0_2, parallel_g401, parallel_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4092 31 parallel_k0_2 parallel_r155 (parallel_k0_3, parallel_r156) [] parallel_b155 parallel_v0_3 parallel_kd0_2 parallel_s155 parallel_sl0_3)
theorem parallel_pl0_2 (tail : List Nat) : parseFields 4093 31 (parallel_v0_2 ++ (125 :: tail)) = some (parallel_l0_2, tail) := by
  simpa only [parallel_l0_2, parallel_v0_2, parallel_k0_2, parallel_g401, parallel_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4092 31 (parallel_k0_2 ++ (34 :: 58 :: (parallel_b155 ++ (44 :: (parallel_v0_3 ++ (125 :: tail)))))) parallel_k0_2 (parallel_b155 ++ (44 :: (parallel_v0_3 ++ (125 :: tail)))) (parallel_v0_3 ++ (125 :: tail)) tail parallel_r155 parallel_l0_3 (parallel_kp0_2 (parallel_b155 ++ (44 :: (parallel_v0_3 ++ (125 :: tail))))) (parallel_p155 (44 :: (parallel_v0_3 ++ (125 :: tail)))) (parallel_pl0_3 tail))
def parallel_l0_1 : List (List Nat × Raw) := (parallel_k0_1, parallel_r2) :: parallel_l0_2
def parallel_v0_1 : List Nat := (parallel_g4 ++ parallel_b2) ++ (44 :: parallel_v0_2)
theorem parallel_sl0_1 : serializeFields 4094 31 parallel_l0_1 = some parallel_v0_1 := by
  simpa only [parallel_l0_1, parallel_v0_1, parallel_k0_1, parallel_g4, parallel_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4093 31 parallel_k0_1 parallel_r2 (parallel_k0_2, parallel_r155) parallel_l0_3 parallel_b2 parallel_v0_2 parallel_kd0_1 parallel_s2 parallel_sl0_2)
theorem parallel_pl0_1 (tail : List Nat) : parseFields 4094 31 (parallel_v0_1 ++ (125 :: tail)) = some (parallel_l0_1, tail) := by
  simpa only [parallel_l0_1, parallel_v0_1, parallel_k0_1, parallel_g4, parallel_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4093 31 (parallel_k0_1 ++ (34 :: 58 :: (parallel_b2 ++ (44 :: (parallel_v0_2 ++ (125 :: tail)))))) parallel_k0_1 (parallel_b2 ++ (44 :: (parallel_v0_2 ++ (125 :: tail)))) (parallel_v0_2 ++ (125 :: tail)) tail parallel_r2 parallel_l0_2 (parallel_kp0_1 (parallel_b2 ++ (44 :: (parallel_v0_2 ++ (125 :: tail))))) (parallel_p2 (44 :: (parallel_v0_2 ++ (125 :: tail)))) (parallel_pl0_2 tail))
def parallel_l0_0 : List (List Nat × Raw) := (parallel_k0_0, parallel_r1) :: parallel_l0_1
def parallel_v0_0 : List Nat := (parallel_g1 ++ parallel_b1) ++ (44 :: parallel_v0_1)
theorem parallel_sl0_0 : serializeFields 4095 31 parallel_l0_0 = some parallel_v0_0 := by
  simpa only [parallel_l0_0, parallel_v0_0, parallel_k0_0, parallel_g1, parallel_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4094 31 parallel_k0_0 parallel_r1 (parallel_k0_1, parallel_r2) parallel_l0_2 parallel_b1 parallel_v0_1 parallel_kd0_0 parallel_s1 parallel_sl0_1)
theorem parallel_pl0_0 (tail : List Nat) : parseFields 4095 31 (parallel_v0_0 ++ (125 :: tail)) = some (parallel_l0_0, tail) := by
  simpa only [parallel_l0_0, parallel_v0_0, parallel_k0_0, parallel_g1, parallel_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4094 31 (parallel_k0_0 ++ (34 :: 58 :: (parallel_b1 ++ (44 :: (parallel_v0_1 ++ (125 :: tail)))))) parallel_k0_0 (parallel_b1 ++ (44 :: (parallel_v0_1 ++ (125 :: tail)))) (parallel_v0_1 ++ (125 :: tail)) tail parallel_r1 parallel_l0_1 (parallel_kp0_0 (parallel_b1 ++ (44 :: (parallel_v0_1 ++ (125 :: tail))))) (parallel_p1 (44 :: (parallel_v0_1 ++ (125 :: tail)))) (parallel_pl0_1 tail))
def parallel_r0 : Raw := (.obj parallel_l0_0)
def parallel_b0 : List Nat := parallel_g0 ++ (parallel_v0_0 ++ parallel_g406)
theorem parallel_o0 : orderedFields parallel_l0_0 = true := by decide +kernel
theorem parallel_s0 : serializeRaw 4096 32 parallel_r0 = some parallel_b0 := by
  simpa only [parallel_r0, parallel_b0, parallel_g0, parallel_g406, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4095 31 parallel_l0_0 parallel_v0_0 parallel_o0 parallel_sl0_0)
theorem parallel_p0 (tail : List Nat) : parseRaw 4096 32 (parallel_b0 ++ tail) = some (parallel_r0, tail) := by
  simpa only [parallel_r0, parallel_b0, parallel_g0, parallel_g406, parallel_v0_0, parallel_k0_0, parallel_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4095 31 (parallel_k0_0 ++ (34 :: 58 :: (parallel_b1 ++ (44 :: (parallel_v0_1 ++ (125 :: tail)))))) tail parallel_l0_0 parallel_o0 (by simpa only [parallel_v0_0, parallel_k0_0, parallel_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_pl0_0 tail)))
def parallelRaw : Raw := parallel_r0
def parallelBytes : List Nat := parallel_b0
theorem parallel_bounds : withinBounds parallelRaw = true := by decide +kernel
theorem parallel_serialized : serializeRaw transportFuel transportDepth parallelRaw = some parallelBytes := by exact parallel_s0
theorem parallel_parsed : parseRaw transportFuel transportDepth parallelBytes = some (parallelRaw, []) := by
  simpa only [List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (parallel_p0 [])
theorem parallel_bf0491 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b113 502 := by
  simpa only [parallel_b113] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g285 (parallel_v113_0 ++ parallel_g297) 1 501 parallel_bf0195 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v113_0 parallel_g297 500 1 parallel_bf0490 parallel_bf0204))
theorem parallel_bf0492 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b119 11 := by
  simpa only [parallel_b119] using parallel_bf0207
theorem parallel_bf0493 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b120 105 := by
  simpa only [parallel_b120] using parallel_bf0209
theorem parallel_bf0494 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b121 208 := by
  simpa only [parallel_b121] using parallel_bf0211
theorem parallel_bf0495 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b122 243 := by
  simpa only [parallel_b122] using parallel_bf0213
theorem parallel_bf0496 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v118_3 250 := by
  simpa only [parallel_v118_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g309 parallel_b122 7 243 parallel_bf0212 parallel_bf0495)
theorem parallel_bf0497 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v118_2 468 := by
  simpa only [parallel_v118_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g306 ++ parallel_b121) (44 :: parallel_v118_3) 217 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g306 parallel_b121 9 208 parallel_bf0210 parallel_bf0494) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v118_3 250 (by decide +kernel) parallel_bf0496))
theorem parallel_bf0498 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v118_1 580 := by
  simpa only [parallel_v118_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g303 ++ parallel_b120) (44 :: parallel_v118_2) 111 469 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g303 parallel_b120 6 105 parallel_bf0208 parallel_bf0493) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v118_2 468 (by decide +kernel) parallel_bf0497))
theorem parallel_bf0499 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v118_0 597 := by
  simpa only [parallel_v118_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g300 ++ parallel_b119) (44 :: parallel_v118_1) 16 581 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g300 parallel_b119 5 11 parallel_bf0206 parallel_bf0492) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v118_1 580 (by decide +kernel) parallel_bf0498))
theorem parallel_bf0500 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b118 599 := by
  simpa only [parallel_b118] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g299 (parallel_v118_0 ++ parallel_g311) 1 598 parallel_bf0205 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v118_0 parallel_g311 597 1 parallel_bf0499 parallel_bf0214))
theorem parallel_bf0501 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b124 11 := by
  simpa only [parallel_b124] using parallel_bf0217
theorem parallel_bf0502 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b126 96 := by
  simpa only [parallel_b126] using parallel_bf0220
theorem parallel_bf0503 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b127 102 := by
  simpa only [parallel_b127] using parallel_bf0221
theorem parallel_bf0504 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b128 57 := by
  simpa only [parallel_b128] using parallel_bf0222
theorem parallel_bf0505 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b129 102 := by
  simpa only [parallel_b129] using parallel_bf0223
theorem parallel_bf0506 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b130 107 := by
  simpa only [parallel_b130] using parallel_bf0224
theorem parallel_bf0507 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b131 87 := by
  simpa only [parallel_b131] using parallel_bf0225
theorem parallel_bf0508 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b132 109 := by
  simpa only [parallel_b132] using parallel_bf0226
theorem parallel_bf0509 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_6 109 := by
  simpa only [parallel_v125_6] using parallel_bf0508
theorem parallel_bf0510 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_5 197 := by
  simpa only [parallel_v125_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b131 (44 :: parallel_v125_6) 87 110 parallel_bf0507 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v125_6 109 (by decide +kernel) parallel_bf0509))
theorem parallel_bf0511 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_4 305 := by
  simpa only [parallel_v125_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b130 (44 :: parallel_v125_5) 107 198 parallel_bf0506 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v125_5 197 (by decide +kernel) parallel_bf0510))
theorem parallel_bf0512 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_3 408 := by
  simpa only [parallel_v125_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b129 (44 :: parallel_v125_4) 102 306 parallel_bf0505 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v125_4 305 (by decide +kernel) parallel_bf0511))
theorem parallel_bf0513 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_2 466 := by
  simpa only [parallel_v125_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b128 (44 :: parallel_v125_3) 57 409 parallel_bf0504 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v125_3 408 (by decide +kernel) parallel_bf0512))
theorem parallel_bf0514 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_1 569 := by
  simpa only [parallel_v125_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b127 (44 :: parallel_v125_2) 102 467 parallel_bf0503 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v125_2 466 (by decide +kernel) parallel_bf0513))
theorem parallel_bf0515 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v125_0 666 := by
  simpa only [parallel_v125_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b126 (44 :: parallel_v125_1) 96 570 parallel_bf0502 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v125_1 569 (by decide +kernel) parallel_bf0514))
theorem parallel_bf0516 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b125 668 := by
  simpa only [parallel_b125] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g318 (parallel_v125_0 ++ parallel_g332) 1 667 parallel_bf0219 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v125_0 parallel_g332 666 1 parallel_bf0515 parallel_bf0227))
theorem parallel_bf0517 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b133 208 := by
  simpa only [parallel_b133] using parallel_bf0229
theorem parallel_bf0518 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b134 109 := by
  simpa only [parallel_b134] using parallel_bf0231
theorem parallel_bf0519 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v123_3 116 := by
  simpa only [parallel_v123_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g337 parallel_b134 7 109 parallel_bf0230 parallel_bf0518)
theorem parallel_bf0520 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v123_2 334 := by
  simpa only [parallel_v123_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g334 ++ parallel_b133) (44 :: parallel_v123_3) 217 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g334 parallel_b133 9 208 parallel_bf0228 parallel_bf0517) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v123_3 116 (by decide +kernel) parallel_bf0519))
theorem parallel_bf0521 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v123_1 1009 := by
  simpa only [parallel_v123_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g317 ++ parallel_b125) (44 :: parallel_v123_2) 674 335 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g317 parallel_b125 6 668 parallel_bf0218 parallel_bf0516) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v123_2 334 (by decide +kernel) parallel_bf0520))
theorem parallel_bf0522 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v123_0 1026 := by
  simpa only [parallel_v123_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g314 ++ parallel_b124) (44 :: parallel_v123_1) 16 1010 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g314 parallel_b124 5 11 parallel_bf0216 parallel_bf0501) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v123_1 1009 (by decide +kernel) parallel_bf0521))
theorem parallel_bf0523 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b123 1028 := by
  simpa only [parallel_b123] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g313 (parallel_v123_0 ++ parallel_g339) 1 1027 parallel_bf0215 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v123_0 parallel_g339 1026 1 parallel_bf0522 parallel_bf0232))
theorem parallel_bf0524 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b136 11 := by
  simpa only [parallel_b136] using parallel_bf0235
theorem parallel_bf0525 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b137 156 := by
  simpa only [parallel_b137] using parallel_bf0237
theorem parallel_bf0526 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b138 208 := by
  simpa only [parallel_b138] using parallel_bf0239
theorem parallel_bf0527 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b139 34 := by
  simpa only [parallel_b139] using parallel_bf0241
theorem parallel_bf0528 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v135_3 41 := by
  simpa only [parallel_v135_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g351 parallel_b139 7 34 parallel_bf0240 parallel_bf0527)
theorem parallel_bf0529 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v135_2 259 := by
  simpa only [parallel_v135_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g348 ++ parallel_b138) (44 :: parallel_v135_3) 217 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g348 parallel_b138 9 208 parallel_bf0238 parallel_bf0526) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v135_3 41 (by decide +kernel) parallel_bf0528))
theorem parallel_bf0530 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v135_1 422 := by
  simpa only [parallel_v135_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g345 ++ parallel_b137) (44 :: parallel_v135_2) 162 260 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g345 parallel_b137 6 156 parallel_bf0236 parallel_bf0525) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v135_2 259 (by decide +kernel) parallel_bf0529))
theorem parallel_bf0531 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v135_0 439 := by
  simpa only [parallel_v135_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g342 ++ parallel_b136) (44 :: parallel_v135_1) 16 423 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g342 parallel_b136 5 11 parallel_bf0234 parallel_bf0524) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v135_1 422 (by decide +kernel) parallel_bf0530))
theorem parallel_bf0532 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b135 441 := by
  simpa only [parallel_b135] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g341 (parallel_v135_0 ++ parallel_g353) 1 440 parallel_bf0233 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v135_0 parallel_g353 439 1 parallel_bf0531 parallel_bf0242))
theorem parallel_bf0533 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b141 12 := by
  simpa only [parallel_b141] using parallel_bf0245
theorem parallel_bf0534 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b142 209 := by
  simpa only [parallel_b142] using parallel_bf0247
theorem parallel_bf0535 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b143 210 := by
  simpa only [parallel_b143] using parallel_bf0249
theorem parallel_bf0536 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b144 221 := by
  simpa only [parallel_b144] using parallel_bf0251
theorem parallel_bf0537 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v140_3 228 := by
  simpa only [parallel_v140_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g365 parallel_b144 7 221 parallel_bf0250 parallel_bf0536)
theorem parallel_bf0538 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v140_2 448 := by
  simpa only [parallel_v140_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g362 ++ parallel_b143) (44 :: parallel_v140_3) 219 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g362 parallel_b143 9 210 parallel_bf0248 parallel_bf0535) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v140_3 228 (by decide +kernel) parallel_bf0537))
theorem parallel_bf0539 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v140_1 664 := by
  simpa only [parallel_v140_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g359 ++ parallel_b142) (44 :: parallel_v140_2) 215 449 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g359 parallel_b142 6 209 parallel_bf0246 parallel_bf0534) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v140_2 448 (by decide +kernel) parallel_bf0538))
theorem parallel_bf0540 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v140_0 682 := by
  simpa only [parallel_v140_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g356 ++ parallel_b141) (44 :: parallel_v140_1) 17 665 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g356 parallel_b141 5 12 parallel_bf0244 parallel_bf0533) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v140_1 664 (by decide +kernel) parallel_bf0539))
theorem parallel_bf0541 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b140 684 := by
  simpa only [parallel_b140] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g355 (parallel_v140_0 ++ parallel_g367) 1 683 parallel_bf0243 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v140_0 parallel_g367 682 1 parallel_bf0540 parallel_bf0252))
theorem parallel_bf0542 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b146 12 := by
  simpa only [parallel_b146] using parallel_bf0255
theorem parallel_bf0543 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b147 209 := by
  simpa only [parallel_b147] using parallel_bf0257
theorem parallel_bf0544 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b148 243 := by
  simpa only [parallel_b148] using parallel_bf0259
theorem parallel_bf0545 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b149 243 := by
  simpa only [parallel_b149] using parallel_bf0261
theorem parallel_bf0546 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v145_3 250 := by
  simpa only [parallel_v145_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g379 parallel_b149 7 243 parallel_bf0260 parallel_bf0545)
theorem parallel_bf0547 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v145_2 503 := by
  simpa only [parallel_v145_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g376 ++ parallel_b148) (44 :: parallel_v145_3) 252 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g376 parallel_b148 9 243 parallel_bf0258 parallel_bf0544) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v145_3 250 (by decide +kernel) parallel_bf0546))
theorem parallel_bf0548 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v145_1 719 := by
  simpa only [parallel_v145_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g373 ++ parallel_b147) (44 :: parallel_v145_2) 215 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g373 parallel_b147 6 209 parallel_bf0256 parallel_bf0543) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v145_2 503 (by decide +kernel) parallel_bf0547))
theorem parallel_bf0549 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v145_0 737 := by
  simpa only [parallel_v145_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g370 ++ parallel_b146) (44 :: parallel_v145_1) 17 720 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g370 parallel_b146 5 12 parallel_bf0254 parallel_bf0542) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v145_1 719 (by decide +kernel) parallel_bf0548))
theorem parallel_bf0550 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b145 739 := by
  simpa only [parallel_b145] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g369 (parallel_v145_0 ++ parallel_g381) 1 738 parallel_bf0253 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v145_0 parallel_g381 737 1 parallel_bf0549 parallel_bf0262))
theorem parallel_bf0551 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_20 739 := by
  simpa only [parallel_v4_20] using parallel_bf0550
theorem parallel_bf0552 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_19 1424 := by
  simpa only [parallel_v4_19] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b140 (44 :: parallel_v4_20) 684 740 parallel_bf0541 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_20 739 (by decide +kernel) parallel_bf0551))
theorem parallel_bf0553 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_18 1866 := by
  simpa only [parallel_v4_18] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b135 (44 :: parallel_v4_19) 441 1425 parallel_bf0532 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_19 1424 (by decide +kernel) parallel_bf0552))
theorem parallel_bf0554 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_17 2895 := by
  simpa only [parallel_v4_17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b123 (44 :: parallel_v4_18) 1028 1867 parallel_bf0523 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_18 1866 (by decide +kernel) parallel_bf0553))
theorem parallel_bf0555 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_16 3495 := by
  simpa only [parallel_v4_16] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b118 (44 :: parallel_v4_17) 599 2896 parallel_bf0500 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_17 2895 (by decide +kernel) parallel_bf0554))
theorem parallel_bf0556 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_15 3998 := by
  simpa only [parallel_v4_15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b113 (44 :: parallel_v4_16) 502 3496 parallel_bf0491 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_16 3495 (by decide +kernel) parallel_bf0555))
theorem parallel_bf0557 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_14 5369 := by
  simpa only [parallel_v4_14] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b97 (44 :: parallel_v4_15) 1370 3999 parallel_bf0482 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_15 3998 (by decide +kernel) parallel_bf0556))
theorem parallel_bf0558 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_13 5914 := by
  simpa only [parallel_v4_13] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b92 (44 :: parallel_v4_14) 544 5370 parallel_bf0451 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_14 5369 (by decide +kernel) parallel_bf0557))
theorem parallel_bf0559 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_12 6352 := by
  simpa only [parallel_v4_12] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b87 (44 :: parallel_v4_13) 437 5915 parallel_bf0442 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_13 5914 (by decide +kernel) parallel_bf0558))
theorem parallel_bf0560 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_11 7348 := by
  simpa only [parallel_v4_11] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b75 (44 :: parallel_v4_12) 995 6353 parallel_bf0433 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_12 6352 (by decide +kernel) parallel_bf0559))
theorem parallel_bf0561 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_10 7926 := by
  simpa only [parallel_v4_10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b70 (44 :: parallel_v4_11) 577 7349 parallel_bf0410 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_11 7348 (by decide +kernel) parallel_bf0560))
theorem parallel_bf0562 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_9 8416 := by
  simpa only [parallel_v4_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b65 (44 :: parallel_v4_10) 489 7927 parallel_bf0401 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_10 7926 (by decide +kernel) parallel_bf0561))
theorem parallel_bf0563 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_8 9750 := by
  simpa only [parallel_v4_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b49 (44 :: parallel_v4_9) 1333 8417 parallel_bf0392 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_9 8416 (by decide +kernel) parallel_bf0562))
theorem parallel_bf0564 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_7 10276 := by
  simpa only [parallel_v4_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b44 (44 :: parallel_v4_8) 525 9751 parallel_bf0361 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_8 9750 (by decide +kernel) parallel_bf0563))
theorem parallel_bf0565 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_6 10744 := by
  simpa only [parallel_v4_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b39 (44 :: parallel_v4_7) 467 10277 parallel_bf0352 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_7 10276 (by decide +kernel) parallel_bf0564))
theorem parallel_bf0566 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_5 11381 := by
  simpa only [parallel_v4_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b34 (44 :: parallel_v4_6) 636 10745 parallel_bf0343 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_6 10744 (by decide +kernel) parallel_bf0565))
theorem parallel_bf0567 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_4 11919 := by
  simpa only [parallel_v4_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b29 (44 :: parallel_v4_5) 537 11382 parallel_bf0334 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_5 11381 (by decide +kernel) parallel_bf0566))
theorem parallel_bf0568 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_3 12504 := by
  simpa only [parallel_v4_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b24 (44 :: parallel_v4_4) 584 11920 parallel_bf0325 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_4 11919 (by decide +kernel) parallel_bf0567))
theorem parallel_bf0569 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_2 13137 := by
  simpa only [parallel_v4_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b15 (44 :: parallel_v4_3) 632 12505 parallel_bf0316 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_3 12504 (by decide +kernel) parallel_bf0568))
theorem parallel_bf0570 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_1 13656 := by
  simpa only [parallel_v4_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b10 (44 :: parallel_v4_2) 518 13138 parallel_bf0299 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_2 13137 (by decide +kernel) parallel_bf0569))
theorem parallel_bf0571 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v4_0 14181 := by
  simpa only [parallel_v4_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_b5 (44 :: parallel_v4_1) 524 13657 parallel_bf0290 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v4_1 13656 (by decide +kernel) parallel_bf0570))
theorem parallel_bf0572 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b4 14183 := by
  simpa only [parallel_b4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g8 (parallel_v4_0 ++ parallel_g382) 1 14182 parallel_bf0007 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v4_0 parallel_g382 14181 1 parallel_bf0571 parallel_bf0263))
theorem parallel_bf0573 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b150 31 := by
  simpa only [parallel_b150] using parallel_bf0265
theorem parallel_bf0574 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b151 13 := by
  simpa only [parallel_b151] using parallel_bf0267
theorem parallel_bf0575 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b152 11 := by
  simpa only [parallel_b152] using parallel_bf0269
theorem parallel_bf0576 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b153 61 := by
  simpa only [parallel_b153] using parallel_bf0271
theorem parallel_bf0577 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b154 7 := by
  simpa only [parallel_b154] using parallel_bf0273
theorem parallel_bf0578 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v3_5 17 := by
  simpa only [parallel_v3_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g396 parallel_b154 10 7 parallel_bf0272 parallel_bf0577)
theorem parallel_bf0579 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v3_4 88 := by
  simpa only [parallel_v3_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g393 ++ parallel_b153) (44 :: parallel_v3_5) 70 18 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g393 parallel_b153 9 61 parallel_bf0270 parallel_bf0576) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v3_5 17 (by decide +kernel) parallel_bf0578))
theorem parallel_bf0580 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v3_3 107 := by
  simpa only [parallel_v3_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g390 ++ parallel_b152) (44 :: parallel_v3_4) 18 89 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g390 parallel_b152 7 11 parallel_bf0268 parallel_bf0575) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v3_4 88 (by decide +kernel) parallel_bf0579))
theorem parallel_bf0581 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v3_2 129 := by
  simpa only [parallel_v3_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g387 ++ parallel_b151) (44 :: parallel_v3_3) 21 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g387 parallel_b151 8 13 parallel_bf0266 parallel_bf0574) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v3_3 107 (by decide +kernel) parallel_bf0580))
theorem parallel_bf0582 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v3_1 171 := by
  simpa only [parallel_v3_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g384 ++ parallel_b150) (44 :: parallel_v3_2) 41 130 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g384 parallel_b150 10 31 parallel_bf0264 parallel_bf0573) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v3_2 129 (by decide +kernel) parallel_bf0581))
theorem parallel_bf0583 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v3_0 14364 := by
  simpa only [parallel_v3_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g7 ++ parallel_b4) (44 :: parallel_v3_1) 14192 172 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g7 parallel_b4 9 14183 parallel_bf0006 parallel_bf0572) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v3_1 171 (by decide +kernel) parallel_bf0582))
theorem parallel_bf0584 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b3 14366 := by
  simpa only [parallel_b3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g6 (parallel_v3_0 ++ parallel_g398) 1 14365 parallel_bf0005 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v3_0 parallel_g398 14364 1 parallel_bf0583 parallel_bf0274))
theorem parallel_bf0585 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v2_0 14366 := by
  simpa only [parallel_v2_0] using parallel_bf0584
theorem parallel_bf0586 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b2 14368 := by
  simpa only [parallel_b2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g5 (parallel_v2_0 ++ parallel_g399) 1 14367 parallel_bf0004 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v2_0 parallel_g399 14366 1 parallel_bf0585 parallel_bf0275))
theorem parallel_bf0587 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b155 18 := by
  simpa only [parallel_b155] using parallel_bf0277
theorem parallel_bf0588 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b156 22 := by
  simpa only [parallel_b156] using parallel_bf0279
theorem parallel_bf0589 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v0_3 31 := by
  simpa only [parallel_v0_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g404 parallel_b156 9 22 parallel_bf0278 parallel_bf0588)
theorem parallel_bf0590 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v0_2 59 := by
  simpa only [parallel_v0_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g401 ++ parallel_b155) (44 :: parallel_v0_3) 27 32 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g401 parallel_b155 9 18 parallel_bf0276 parallel_bf0587) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v0_3 31 (by decide +kernel) parallel_bf0589))
theorem parallel_bf0591 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v0_1 14440 := by
  simpa only [parallel_v0_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g4 ++ parallel_b2) (44 :: parallel_v0_2) 14380 60 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g4 parallel_b2 12 14368 parallel_bf0003 parallel_bf0586) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v0_2 59 (by decide +kernel) parallel_bf0590))
theorem parallel_bf0592 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_v0_0 14464 := by
  simpa only [parallel_v0_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (parallel_g1 ++ parallel_b1) (44 :: parallel_v0_1) 23 14441 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g1 parallel_b1 10 13 parallel_bf0001 parallel_bf0281) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 parallel_v0_1 14440 (by decide +kernel) parallel_bf0591))
theorem parallel_bf0593 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallel_b0 14466 := by
  simpa only [parallel_b0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_g0 (parallel_v0_0 ++ parallel_g406) 1 14465 parallel_bf0000 (HiaCoreSyntaxSlice.ByteFactsResearch.append parallel_v0_0 parallel_g406 14464 1 parallel_bf0592 parallel_bf0280))
theorem parallel_bf0594 : HiaCoreSyntaxSlice.ByteFactsResearch.facts parallelBytes 14466 := by
  simpa only [parallelBytes] using parallel_bf0593
theorem parallel_length : parallelBytes.length ≤ transportByteLimit := by
  rw [(parallel_bf0594).1]
  decide +kernel
theorem parallel_byte_range : parallelBytes.all (fun byte => decide (byte ≤ 255)) = true := by exact (parallel_bf0594).2
theorem parallel_transport : checkedEncode parallelRaw = some parallelBytes := checkedEncode_of_parts parallelRaw parallelBytes parallel_bounds parallel_serialized parallel_parsed parallel_length parallel_byte_range
end HiaCoreSyntaxSlice
namespace HiaCoreSyntaxSlice.WrongPhi
def linear_g0 : List Nat := [123]
def linear_g1 : List Nat := [34,101,120,112,111,114,116,115,34,58]
def linear_g2 : List Nat := [91,34,99,97,108,99,117,108,97,116,101,34,93]
def linear_g3 : List Nat := [44]
def linear_g4 : List Nat := [34,102,117,110,99,116,105,111,110,115,34,58]
def linear_g5 : List Nat := [91]
def linear_g6 : List Nat := [123]
def linear_g7 : List Nat := [34,98,108,111,99,107,115,34,58]
def linear_g8 : List Nat := [91]
def linear_g9 : List Nat := [123]
def linear_g10 : List Nat := [34,105,100,34,58]
def linear_g11 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g12 : List Nat := [44]
def linear_g13 : List Nat := [34,111,112,115,34,58]
def linear_g14 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,116,114,121,95,110,101,119,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,93]
def linear_g15 : List Nat := [44]
def linear_g16 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g17 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g18 : List Nat := [44]
def linear_g19 : List Nat := [34,116,101,114,109,34,58]
def linear_g20 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,125,125]
def linear_g21 : List Nat := [125]
def linear_g22 : List Nat := [44]
def linear_g23 : List Nat := [123]
def linear_g24 : List Nat := [34,105,100,34,58]
def linear_g25 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,49,34]
def linear_g26 : List Nat := [44]
def linear_g27 : List Nat := [34,111,112,115,34,58]
def linear_g28 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g29 : List Nat := [44]
def linear_g30 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g31 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g32 : List Nat := [44]
def linear_g33 : List Nat := [34,116,101,114,109,34,58]
def linear_g34 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,52,34,44,34,100,103,95,118,95,56,34,44,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,57,34,44,34,100,103,95,118,95,49,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,125]
def linear_g35 : List Nat := [125]
def linear_g36 : List Nat := [44]
def linear_g37 : List Nat := [123]
def linear_g38 : List Nat := [34,105,100,34,58]
def linear_g39 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,50,34]
def linear_g40 : List Nat := [44]
def linear_g41 : List Nat := [34,111,112,115,34,58]
def linear_g42 : List Nat := [91]
def linear_g43 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125]
def linear_g44 : List Nat := [44]
def linear_g45 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,48,48,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g46 : List Nat := [44]
def linear_g47 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g48 : List Nat := [44]
def linear_g49 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,34,44,34,100,103,95,118,95,49,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g50 : List Nat := [93]
def linear_g51 : List Nat := [44]
def linear_g52 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g53 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g54 : List Nat := [44]
def linear_g55 : List Nat := [34,116,101,114,109,34,58]
def linear_g56 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,56,34,93,125]
def linear_g57 : List Nat := [125]
def linear_g58 : List Nat := [44]
def linear_g59 : List Nat := [123]
def linear_g60 : List Nat := [34,105,100,34,58]
def linear_g61 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,51,34]
def linear_g62 : List Nat := [44]
def linear_g63 : List Nat := [34,111,112,115,34,58]
def linear_g64 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g65 : List Nat := [44]
def linear_g66 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g67 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g68 : List Nat := [44]
def linear_g69 : List Nat := [34,116,101,114,109,34,58]
def linear_g70 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,50,53,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,48,34,125,125]
def linear_g71 : List Nat := [125]
def linear_g72 : List Nat := [44]
def linear_g73 : List Nat := [123]
def linear_g74 : List Nat := [34,105,100,34,58]
def linear_g75 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,52,34]
def linear_g76 : List Nat := [44]
def linear_g77 : List Nat := [34,111,112,115,34,58]
def linear_g78 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,50,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g79 : List Nat := [44]
def linear_g80 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g81 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g82 : List Nat := [44]
def linear_g83 : List Nat := [34,116,101,114,109,34,58]
def linear_g84 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,50,56,34,44,34,100,103,95,118,95,50,57,34,44,34,100,103,95,118,95,51,50,34,44,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,51,51,34,44,34,100,103,95,118,95,51,52,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,125]
def linear_g85 : List Nat := [125]
def linear_g86 : List Nat := [44]
def linear_g87 : List Nat := [123]
def linear_g88 : List Nat := [34,105,100,34,58]
def linear_g89 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,53,34]
def linear_g90 : List Nat := [44]
def linear_g91 : List Nat := [34,111,112,115,34,58]
def linear_g92 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,51,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g93 : List Nat := [44]
def linear_g94 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g95 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g96 : List Nat := [44]
def linear_g97 : List Nat := [34,116,101,114,109,34,58]
def linear_g98 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,52,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,49,34,125,125]
def linear_g99 : List Nat := [125]
def linear_g100 : List Nat := [44]
def linear_g101 : List Nat := [123]
def linear_g102 : List Nat := [34,105,100,34,58]
def linear_g103 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,54,34]
def linear_g104 : List Nat := [44]
def linear_g105 : List Nat := [34,111,112,115,34,58]
def linear_g106 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g107 : List Nat := [44]
def linear_g108 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g109 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,53,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g110 : List Nat := [44]
def linear_g111 : List Nat := [34,116,101,114,109,34,58]
def linear_g112 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,52,54,34,93,125]
def linear_g113 : List Nat := [125]
def linear_g114 : List Nat := [44]
def linear_g115 : List Nat := [123]
def linear_g116 : List Nat := [34,105,100,34,58]
def linear_g117 : List Nat := [34,100,103,95,102,97,115,116,95,48,34]
def linear_g118 : List Nat := [44]
def linear_g119 : List Nat := [34,111,112,115,34,58]
def linear_g120 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,54,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g121 : List Nat := [44]
def linear_g122 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g123 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g124 : List Nat := [44]
def linear_g125 : List Nat := [34,116,101,114,109,34,58]
def linear_g126 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,53,54,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,52,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g127 : List Nat := [125]
def linear_g128 : List Nat := [44]
def linear_g129 : List Nat := [123]
def linear_g130 : List Nat := [34,105,100,34,58]
def linear_g131 : List Nat := [34,100,103,95,102,97,115,116,95,49,34]
def linear_g132 : List Nat := [44]
def linear_g133 : List Nat := [34,111,112,115,34,58]
def linear_g134 : List Nat := [91]
def linear_g135 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g136 : List Nat := [44]
def linear_g137 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,50,34,44,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,51,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g138 : List Nat := [44]
def linear_g139 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,52,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g140 : List Nat := [44]
def linear_g141 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g142 : List Nat := [44]
def linear_g143 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,52,34,44,34,100,103,95,118,95,54,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,54,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g144 : List Nat := [44]
def linear_g145 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,54,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g146 : List Nat := [44]
def linear_g147 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,56,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g148 : List Nat := [44]
def linear_g149 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,44,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g150 : List Nat := [44]
def linear_g151 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g152 : List Nat := [44]
def linear_g153 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g154 : List Nat := [44]
def linear_g155 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g156 : List Nat := [93]
def linear_g157 : List Nat := [44]
def linear_g158 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g159 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g160 : List Nat := [44]
def linear_g161 : List Nat := [34,116,101,114,109,34,58]
def linear_g162 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,55,34,44,34,100,103,95,118,95,53,56,34,44,34,100,103,95,118,95,53,57,34,44,34,100,103,95,118,95,54,48,34,44,34,100,103,95,118,95,55,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,48,34,125]
def linear_g163 : List Nat := [125]
def linear_g164 : List Nat := [44]
def linear_g165 : List Nat := [123]
def linear_g166 : List Nat := [34,105,100,34,58]
def linear_g167 : List Nat := [34,100,103,95,102,97,115,116,95,50,34]
def linear_g168 : List Nat := [44]
def linear_g169 : List Nat := [34,111,112,115,34,58]
def linear_g170 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g171 : List Nat := [44]
def linear_g172 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g173 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g174 : List Nat := [44]
def linear_g175 : List Nat := [34,116,101,114,109,34,58]
def linear_g176 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,50,34,44,34,100,103,95,118,95,55,51,34,44,34,100,103,95,118,95,55,54,34,44,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,55,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g177 : List Nat := [125]
def linear_g178 : List Nat := [44]
def linear_g179 : List Nat := [123]
def linear_g180 : List Nat := [34,105,100,34,58]
def linear_g181 : List Nat := [34,100,103,95,102,97,115,116,95,51,34]
def linear_g182 : List Nat := [44]
def linear_g183 : List Nat := [34,111,112,115,34,58]
def linear_g184 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,51,34,44,34,100,103,95,118,95,56,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g185 : List Nat := [44]
def linear_g186 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g187 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g188 : List Nat := [44]
def linear_g189 : List Nat := [34,116,101,114,109,34,58]
def linear_g190 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,56,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g191 : List Nat := [125]
def linear_g192 : List Nat := [44]
def linear_g193 : List Nat := [123]
def linear_g194 : List Nat := [34,105,100,34,58]
def linear_g195 : List Nat := [34,100,103,95,102,97,115,116,95,52,34]
def linear_g196 : List Nat := [44]
def linear_g197 : List Nat := [34,111,112,115,34,58]
def linear_g198 : List Nat := [91]
def linear_g199 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,49,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g200 : List Nat := [44]
def linear_g201 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,44,34,100,103,95,118,95,57,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g202 : List Nat := [44]
def linear_g203 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g204 : List Nat := [44]
def linear_g205 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,50,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g206 : List Nat := [44]
def linear_g207 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,56,34,44,34,100,103,95,118,95,57,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g208 : List Nat := [44]
def linear_g209 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g210 : List Nat := [44]
def linear_g211 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,48,34,44,34,100,103,95,118,95,57,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g212 : List Nat := [93]
def linear_g213 : List Nat := [44]
def linear_g214 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g215 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g216 : List Nat := [44]
def linear_g217 : List Nat := [34,116,101,114,109,34,58]
def linear_g218 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,53,34,44,34,100,103,95,118,95,56,54,34,44,34,100,103,95,118,95,56,55,34,44,34,100,103,95,118,95,57,52,34,44,34,100,103,95,118,95,56,57,34,44,34,100,103,95,118,95,57,54,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g219 : List Nat := [125]
def linear_g220 : List Nat := [44]
def linear_g221 : List Nat := [123]
def linear_g222 : List Nat := [34,105,100,34,58]
def linear_g223 : List Nat := [34,100,103,95,102,97,115,116,95,53,34]
def linear_g224 : List Nat := [44]
def linear_g225 : List Nat := [34,111,112,115,34,58]
def linear_g226 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g227 : List Nat := [44]
def linear_g228 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g229 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,48,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g230 : List Nat := [44]
def linear_g231 : List Nat := [34,116,101,114,109,34,58]
def linear_g232 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,48,48,34,93,125]
def linear_g233 : List Nat := [125]
def linear_g234 : List Nat := [44]
def linear_g235 : List Nat := [123]
def linear_g236 : List Nat := [34,105,100,34,58]
def linear_g237 : List Nat := [34,100,103,95,115,108,111,119,95,48,34]
def linear_g238 : List Nat := [44]
def linear_g239 : List Nat := [34,111,112,115,34,58]
def linear_g240 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,56,34,44,34,100,103,95,118,95,49,48,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,57,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g241 : List Nat := [44]
def linear_g242 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g243 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g244 : List Nat := [44]
def linear_g245 : List Nat := [34,116,101,114,109,34,58]
def linear_g246 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,48,57,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,125]
def linear_g247 : List Nat := [125]
def linear_g248 : List Nat := [44]
def linear_g249 : List Nat := [123]
def linear_g250 : List Nat := [34,105,100,34,58]
def linear_g251 : List Nat := [34,100,103,95,115,108,111,119,95,49,34]
def linear_g252 : List Nat := [44]
def linear_g253 : List Nat := [34,111,112,115,34,58]
def linear_g254 : List Nat := [91]
def linear_g255 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g256 : List Nat := [44]
def linear_g257 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,53,34,44,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g258 : List Nat := [44]
def linear_g259 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g260 : List Nat := [44]
def linear_g261 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,56,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g262 : List Nat := [44]
def linear_g263 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,55,34,44,34,100,103,95,118,95,49,49,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,57,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g264 : List Nat := [44]
def linear_g265 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,57,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,48,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g266 : List Nat := [44]
def linear_g267 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,49,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g268 : List Nat := [44]
def linear_g269 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,44,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g270 : List Nat := [44]
def linear_g271 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g272 : List Nat := [44]
def linear_g273 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g274 : List Nat := [44]
def linear_g275 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g276 : List Nat := [93]
def linear_g277 : List Nat := [44]
def linear_g278 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g279 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g280 : List Nat := [44]
def linear_g281 : List Nat := [34,116,101,114,109,34,58]
def linear_g282 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,48,34,44,34,100,103,95,118,95,49,49,49,34,44,34,100,103,95,118,95,49,49,50,34,44,34,100,103,95,118,95,49,49,51,34,44,34,100,103,95,118,95,49,50,51,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,48,34,125]
def linear_g283 : List Nat := [125]
def linear_g284 : List Nat := [44]
def linear_g285 : List Nat := [123]
def linear_g286 : List Nat := [34,105,100,34,58]
def linear_g287 : List Nat := [34,100,103,95,115,108,111,119,95,50,34]
def linear_g288 : List Nat := [44]
def linear_g289 : List Nat := [34,111,112,115,34,58]
def linear_g290 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,57,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g291 : List Nat := [44]
def linear_g292 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g293 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g294 : List Nat := [44]
def linear_g295 : List Nat := [34,116,101,114,109,34,58]
def linear_g296 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,50,53,34,44,34,100,103,95,118,95,49,50,54,34,44,34,100,103,95,118,95,49,50,57,34,44,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,51,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g297 : List Nat := [125]
def linear_g298 : List Nat := [44]
def linear_g299 : List Nat := [123]
def linear_g300 : List Nat := [34,105,100,34,58]
def linear_g301 : List Nat := [34,100,103,95,115,108,111,119,95,51,34]
def linear_g302 : List Nat := [44]
def linear_g303 : List Nat := [34,111,112,115,34,58]
def linear_g304 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,54,34,44,34,100,103,95,118,95,49,51,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,55,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g305 : List Nat := [44]
def linear_g306 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g307 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g308 : List Nat := [44]
def linear_g309 : List Nat := [34,116,101,114,109,34,58]
def linear_g310 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,51,55,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,125]
def linear_g311 : List Nat := [125]
def linear_g312 : List Nat := [44]
def linear_g313 : List Nat := [123]
def linear_g314 : List Nat := [34,105,100,34,58]
def linear_g315 : List Nat := [34,100,103,95,115,108,111,119,95,52,34]
def linear_g316 : List Nat := [44]
def linear_g317 : List Nat := [34,111,112,115,34,58]
def linear_g318 : List Nat := [91]
def linear_g319 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,52,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g320 : List Nat := [44]
def linear_g321 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,44,34,100,103,95,118,95,49,52,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g322 : List Nat := [44]
def linear_g323 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g324 : List Nat := [44]
def linear_g325 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g326 : List Nat := [44]
def linear_g327 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,49,34,44,34,100,103,95,118,95,49,52,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g328 : List Nat := [44]
def linear_g329 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g330 : List Nat := [44]
def linear_g331 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,51,34,44,34,100,103,95,118,95,49,52,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g332 : List Nat := [93]
def linear_g333 : List Nat := [44]
def linear_g334 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g335 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g336 : List Nat := [44]
def linear_g337 : List Nat := [34,116,101,114,109,34,58]
def linear_g338 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,56,34,44,34,100,103,95,118,95,49,51,57,34,44,34,100,103,95,118,95,49,52,48,34,44,34,100,103,95,118,95,49,52,55,34,44,34,100,103,95,118,95,49,52,50,34,44,34,100,103,95,118,95,49,52,57,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g339 : List Nat := [125]
def linear_g340 : List Nat := [44]
def linear_g341 : List Nat := [123]
def linear_g342 : List Nat := [34,105,100,34,58]
def linear_g343 : List Nat := [34,100,103,95,115,108,111,119,95,53,34]
def linear_g344 : List Nat := [44]
def linear_g345 : List Nat := [34,111,112,115,34,58]
def linear_g346 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g347 : List Nat := [44]
def linear_g348 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g349 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g350 : List Nat := [44]
def linear_g351 : List Nat := [34,116,101,114,109,34,58]
def linear_g352 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,53,51,34,93,125]
def linear_g353 : List Nat := [125]
def linear_g354 : List Nat := [44]
def linear_g355 : List Nat := [123]
def linear_g356 : List Nat := [34,105,100,34,58]
def linear_g357 : List Nat := [34,100,103,95,103,117,97,114,100,95,48,34]
def linear_g358 : List Nat := [44]
def linear_g359 : List Nat := [34,111,112,115,34,58]
def linear_g360 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,50,34,44,34,100,103,95,118,95,49,54,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g361 : List Nat := [44]
def linear_g362 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g363 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g364 : List Nat := [44]
def linear_g365 : List Nat := [34,116,101,114,109,34,58]
def linear_g366 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,54,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g367 : List Nat := [125]
def linear_g368 : List Nat := [44]
def linear_g369 : List Nat := [123]
def linear_g370 : List Nat := [34,105,100,34,58]
def linear_g371 : List Nat := [34,100,103,95,103,117,97,114,100,95,49,34]
def linear_g372 : List Nat := [44]
def linear_g373 : List Nat := [34,111,112,115,34,58]
def linear_g374 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,55,49,34,44,34,100,103,95,118,95,49,55,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g375 : List Nat := [44]
def linear_g376 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g377 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g378 : List Nat := [44]
def linear_g379 : List Nat := [34,116,101,114,109,34,58]
def linear_g380 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,55,51,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g381 : List Nat := [125]
def linear_g382 : List Nat := [93]
def linear_g383 : List Nat := [44]
def linear_g384 : List Nat := [34,101,102,102,101,99,116,115,34,58]
def linear_g385 : List Nat := [91,34,97,108,108,111,99,34,44,34,114,101,97,100,34,44,34,116,114,97,112,34,44,34,119,114,105,116,101,34,93]
def linear_g386 : List Nat := [44]
def linear_g387 : List Nat := [34,101,110,116,114,121,34,58]
def linear_g388 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g389 : List Nat := [44]
def linear_g390 : List Nat := [34,110,97,109,101,34,58]
def linear_g391 : List Nat := [34,99,97,108,99,117,108,97,116,101,34]
def linear_g392 : List Nat := [44]
def linear_g393 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g394 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g395 : List Nat := [44]
def linear_g396 : List Nat := [34,114,101,116,117,114,110,115,34,58]
def linear_g397 : List Nat := [91,34,117,54,52,34,93]
def linear_g398 : List Nat := [125]
def linear_g399 : List Nat := [93]
def linear_g400 : List Nat := [44]
def linear_g401 : List Nat := [34,109,111,100,117,108,101,34,58]
def linear_g402 : List Nat := [34,114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114,34]
def linear_g403 : List Nat := [44]
def linear_g404 : List Nat := [34,115,99,104,101,109,97,34,58]
def linear_g405 : List Nat := [34,104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49,34]
def linear_g406 : List Nat := [125]
def linear_t407 : List Nat := []
def linear_t406 : List Nat := linear_g406 ++ linear_t407
def linear_t405 : List Nat := linear_g405 ++ linear_t406
def linear_t404 : List Nat := linear_g404 ++ linear_t405
def linear_t403 : List Nat := linear_g403 ++ linear_t404
def linear_t402 : List Nat := linear_g402 ++ linear_t403
def linear_t401 : List Nat := linear_g401 ++ linear_t402
def linear_t400 : List Nat := linear_g400 ++ linear_t401
def linear_t399 : List Nat := linear_g399 ++ linear_t400
def linear_t398 : List Nat := linear_g398 ++ linear_t399
def linear_t397 : List Nat := linear_g397 ++ linear_t398
def linear_t396 : List Nat := linear_g396 ++ linear_t397
def linear_t395 : List Nat := linear_g395 ++ linear_t396
def linear_t394 : List Nat := linear_g394 ++ linear_t395
def linear_t393 : List Nat := linear_g393 ++ linear_t394
def linear_t392 : List Nat := linear_g392 ++ linear_t393
def linear_t391 : List Nat := linear_g391 ++ linear_t392
def linear_t390 : List Nat := linear_g390 ++ linear_t391
def linear_t389 : List Nat := linear_g389 ++ linear_t390
def linear_t388 : List Nat := linear_g388 ++ linear_t389
def linear_t387 : List Nat := linear_g387 ++ linear_t388
def linear_t386 : List Nat := linear_g386 ++ linear_t387
def linear_t385 : List Nat := linear_g385 ++ linear_t386
def linear_t384 : List Nat := linear_g384 ++ linear_t385
def linear_t383 : List Nat := linear_g383 ++ linear_t384
def linear_t382 : List Nat := linear_g382 ++ linear_t383
def linear_t381 : List Nat := linear_g381 ++ linear_t382
def linear_t380 : List Nat := linear_g380 ++ linear_t381
def linear_t379 : List Nat := linear_g379 ++ linear_t380
def linear_t378 : List Nat := linear_g378 ++ linear_t379
def linear_t377 : List Nat := linear_g377 ++ linear_t378
def linear_t376 : List Nat := linear_g376 ++ linear_t377
def linear_t375 : List Nat := linear_g375 ++ linear_t376
def linear_t374 : List Nat := linear_g374 ++ linear_t375
def linear_t373 : List Nat := linear_g373 ++ linear_t374
def linear_t372 : List Nat := linear_g372 ++ linear_t373
def linear_t371 : List Nat := linear_g371 ++ linear_t372
def linear_t370 : List Nat := linear_g370 ++ linear_t371
def linear_t369 : List Nat := linear_g369 ++ linear_t370
def linear_t368 : List Nat := linear_g368 ++ linear_t369
def linear_t367 : List Nat := linear_g367 ++ linear_t368
def linear_t366 : List Nat := linear_g366 ++ linear_t367
def linear_t365 : List Nat := linear_g365 ++ linear_t366
def linear_t364 : List Nat := linear_g364 ++ linear_t365
def linear_t363 : List Nat := linear_g363 ++ linear_t364
def linear_t362 : List Nat := linear_g362 ++ linear_t363
def linear_t361 : List Nat := linear_g361 ++ linear_t362
def linear_t360 : List Nat := linear_g360 ++ linear_t361
def linear_t359 : List Nat := linear_g359 ++ linear_t360
def linear_t358 : List Nat := linear_g358 ++ linear_t359
def linear_t357 : List Nat := linear_g357 ++ linear_t358
def linear_t356 : List Nat := linear_g356 ++ linear_t357
def linear_t355 : List Nat := linear_g355 ++ linear_t356
def linear_t354 : List Nat := linear_g354 ++ linear_t355
def linear_t353 : List Nat := linear_g353 ++ linear_t354
def linear_t352 : List Nat := linear_g352 ++ linear_t353
def linear_t351 : List Nat := linear_g351 ++ linear_t352
def linear_t350 : List Nat := linear_g350 ++ linear_t351
def linear_t349 : List Nat := linear_g349 ++ linear_t350
def linear_t348 : List Nat := linear_g348 ++ linear_t349
def linear_t347 : List Nat := linear_g347 ++ linear_t348
def linear_t346 : List Nat := linear_g346 ++ linear_t347
def linear_t345 : List Nat := linear_g345 ++ linear_t346
def linear_t344 : List Nat := linear_g344 ++ linear_t345
def linear_t343 : List Nat := linear_g343 ++ linear_t344
def linear_t342 : List Nat := linear_g342 ++ linear_t343
def linear_t341 : List Nat := linear_g341 ++ linear_t342
def linear_t340 : List Nat := linear_g340 ++ linear_t341
def linear_t339 : List Nat := linear_g339 ++ linear_t340
def linear_t338 : List Nat := linear_g338 ++ linear_t339
def linear_t337 : List Nat := linear_g337 ++ linear_t338
def linear_t336 : List Nat := linear_g336 ++ linear_t337
def linear_t335 : List Nat := linear_g335 ++ linear_t336
def linear_t334 : List Nat := linear_g334 ++ linear_t335
def linear_t333 : List Nat := linear_g333 ++ linear_t334
def linear_t332 : List Nat := linear_g332 ++ linear_t333
def linear_t331 : List Nat := linear_g331 ++ linear_t332
def linear_t330 : List Nat := linear_g330 ++ linear_t331
def linear_t329 : List Nat := linear_g329 ++ linear_t330
def linear_t328 : List Nat := linear_g328 ++ linear_t329
def linear_t327 : List Nat := linear_g327 ++ linear_t328
def linear_t326 : List Nat := linear_g326 ++ linear_t327
def linear_t325 : List Nat := linear_g325 ++ linear_t326
def linear_t324 : List Nat := linear_g324 ++ linear_t325
def linear_t323 : List Nat := linear_g323 ++ linear_t324
def linear_t322 : List Nat := linear_g322 ++ linear_t323
def linear_t321 : List Nat := linear_g321 ++ linear_t322
def linear_t320 : List Nat := linear_g320 ++ linear_t321
def linear_t319 : List Nat := linear_g319 ++ linear_t320
def linear_t318 : List Nat := linear_g318 ++ linear_t319
def linear_t317 : List Nat := linear_g317 ++ linear_t318
def linear_t316 : List Nat := linear_g316 ++ linear_t317
def linear_t315 : List Nat := linear_g315 ++ linear_t316
def linear_t314 : List Nat := linear_g314 ++ linear_t315
def linear_t313 : List Nat := linear_g313 ++ linear_t314
def linear_t312 : List Nat := linear_g312 ++ linear_t313
def linear_t311 : List Nat := linear_g311 ++ linear_t312
def linear_t310 : List Nat := linear_g310 ++ linear_t311
def linear_t309 : List Nat := linear_g309 ++ linear_t310
def linear_t308 : List Nat := linear_g308 ++ linear_t309
def linear_t307 : List Nat := linear_g307 ++ linear_t308
def linear_t306 : List Nat := linear_g306 ++ linear_t307
def linear_t305 : List Nat := linear_g305 ++ linear_t306
def linear_t304 : List Nat := linear_g304 ++ linear_t305
def linear_t303 : List Nat := linear_g303 ++ linear_t304
def linear_t302 : List Nat := linear_g302 ++ linear_t303
def linear_t301 : List Nat := linear_g301 ++ linear_t302
def linear_t300 : List Nat := linear_g300 ++ linear_t301
def linear_t299 : List Nat := linear_g299 ++ linear_t300
def linear_t298 : List Nat := linear_g298 ++ linear_t299
def linear_t297 : List Nat := linear_g297 ++ linear_t298
def linear_t296 : List Nat := linear_g296 ++ linear_t297
def linear_t295 : List Nat := linear_g295 ++ linear_t296
def linear_t294 : List Nat := linear_g294 ++ linear_t295
def linear_t293 : List Nat := linear_g293 ++ linear_t294
def linear_t292 : List Nat := linear_g292 ++ linear_t293
def linear_t291 : List Nat := linear_g291 ++ linear_t292
def linear_t290 : List Nat := linear_g290 ++ linear_t291
def linear_t289 : List Nat := linear_g289 ++ linear_t290
def linear_t288 : List Nat := linear_g288 ++ linear_t289
def linear_t287 : List Nat := linear_g287 ++ linear_t288
def linear_t286 : List Nat := linear_g286 ++ linear_t287
def linear_t285 : List Nat := linear_g285 ++ linear_t286
def linear_t284 : List Nat := linear_g284 ++ linear_t285
def linear_t283 : List Nat := linear_g283 ++ linear_t284
def linear_t282 : List Nat := linear_g282 ++ linear_t283
def linear_t281 : List Nat := linear_g281 ++ linear_t282
def linear_t280 : List Nat := linear_g280 ++ linear_t281
def linear_t279 : List Nat := linear_g279 ++ linear_t280
def linear_t278 : List Nat := linear_g278 ++ linear_t279
def linear_t277 : List Nat := linear_g277 ++ linear_t278
def linear_t276 : List Nat := linear_g276 ++ linear_t277
def linear_t275 : List Nat := linear_g275 ++ linear_t276
def linear_t274 : List Nat := linear_g274 ++ linear_t275
def linear_t273 : List Nat := linear_g273 ++ linear_t274
def linear_t272 : List Nat := linear_g272 ++ linear_t273
def linear_t271 : List Nat := linear_g271 ++ linear_t272
def linear_t270 : List Nat := linear_g270 ++ linear_t271
def linear_t269 : List Nat := linear_g269 ++ linear_t270
def linear_t268 : List Nat := linear_g268 ++ linear_t269
def linear_t267 : List Nat := linear_g267 ++ linear_t268
def linear_t266 : List Nat := linear_g266 ++ linear_t267
def linear_t265 : List Nat := linear_g265 ++ linear_t266
def linear_t264 : List Nat := linear_g264 ++ linear_t265
def linear_t263 : List Nat := linear_g263 ++ linear_t264
def linear_t262 : List Nat := linear_g262 ++ linear_t263
def linear_t261 : List Nat := linear_g261 ++ linear_t262
def linear_t260 : List Nat := linear_g260 ++ linear_t261
def linear_t259 : List Nat := linear_g259 ++ linear_t260
def linear_t258 : List Nat := linear_g258 ++ linear_t259
def linear_t257 : List Nat := linear_g257 ++ linear_t258
def linear_t256 : List Nat := linear_g256 ++ linear_t257
def linear_t255 : List Nat := linear_g255 ++ linear_t256
def linear_t254 : List Nat := linear_g254 ++ linear_t255
def linear_t253 : List Nat := linear_g253 ++ linear_t254
def linear_t252 : List Nat := linear_g252 ++ linear_t253
def linear_t251 : List Nat := linear_g251 ++ linear_t252
def linear_t250 : List Nat := linear_g250 ++ linear_t251
def linear_t249 : List Nat := linear_g249 ++ linear_t250
def linear_t248 : List Nat := linear_g248 ++ linear_t249
def linear_t247 : List Nat := linear_g247 ++ linear_t248
def linear_t246 : List Nat := linear_g246 ++ linear_t247
def linear_t245 : List Nat := linear_g245 ++ linear_t246
def linear_t244 : List Nat := linear_g244 ++ linear_t245
def linear_t243 : List Nat := linear_g243 ++ linear_t244
def linear_t242 : List Nat := linear_g242 ++ linear_t243
def linear_t241 : List Nat := linear_g241 ++ linear_t242
def linear_t240 : List Nat := linear_g240 ++ linear_t241
def linear_t239 : List Nat := linear_g239 ++ linear_t240
def linear_t238 : List Nat := linear_g238 ++ linear_t239
def linear_t237 : List Nat := linear_g237 ++ linear_t238
def linear_t236 : List Nat := linear_g236 ++ linear_t237
def linear_t235 : List Nat := linear_g235 ++ linear_t236
def linear_t234 : List Nat := linear_g234 ++ linear_t235
def linear_t233 : List Nat := linear_g233 ++ linear_t234
def linear_t232 : List Nat := linear_g232 ++ linear_t233
def linear_t231 : List Nat := linear_g231 ++ linear_t232
def linear_t230 : List Nat := linear_g230 ++ linear_t231
def linear_t229 : List Nat := linear_g229 ++ linear_t230
def linear_t228 : List Nat := linear_g228 ++ linear_t229
def linear_t227 : List Nat := linear_g227 ++ linear_t228
def linear_t226 : List Nat := linear_g226 ++ linear_t227
def linear_t225 : List Nat := linear_g225 ++ linear_t226
def linear_t224 : List Nat := linear_g224 ++ linear_t225
def linear_t223 : List Nat := linear_g223 ++ linear_t224
def linear_t222 : List Nat := linear_g222 ++ linear_t223
def linear_t221 : List Nat := linear_g221 ++ linear_t222
def linear_t220 : List Nat := linear_g220 ++ linear_t221
def linear_t219 : List Nat := linear_g219 ++ linear_t220
def linear_t218 : List Nat := linear_g218 ++ linear_t219
def linear_t217 : List Nat := linear_g217 ++ linear_t218
def linear_t216 : List Nat := linear_g216 ++ linear_t217
def linear_t215 : List Nat := linear_g215 ++ linear_t216
def linear_t214 : List Nat := linear_g214 ++ linear_t215
def linear_t213 : List Nat := linear_g213 ++ linear_t214
def linear_t212 : List Nat := linear_g212 ++ linear_t213
def linear_t211 : List Nat := linear_g211 ++ linear_t212
def linear_t210 : List Nat := linear_g210 ++ linear_t211
def linear_t209 : List Nat := linear_g209 ++ linear_t210
def linear_t208 : List Nat := linear_g208 ++ linear_t209
def linear_t207 : List Nat := linear_g207 ++ linear_t208
def linear_t206 : List Nat := linear_g206 ++ linear_t207
def linear_t205 : List Nat := linear_g205 ++ linear_t206
def linear_t204 : List Nat := linear_g204 ++ linear_t205
def linear_t203 : List Nat := linear_g203 ++ linear_t204
def linear_t202 : List Nat := linear_g202 ++ linear_t203
def linear_t201 : List Nat := linear_g201 ++ linear_t202
def linear_t200 : List Nat := linear_g200 ++ linear_t201
def linear_t199 : List Nat := linear_g199 ++ linear_t200
def linear_t198 : List Nat := linear_g198 ++ linear_t199
def linear_t197 : List Nat := linear_g197 ++ linear_t198
def linear_t196 : List Nat := linear_g196 ++ linear_t197
def linear_t195 : List Nat := linear_g195 ++ linear_t196
def linear_t194 : List Nat := linear_g194 ++ linear_t195
def linear_t193 : List Nat := linear_g193 ++ linear_t194
def linear_t192 : List Nat := linear_g192 ++ linear_t193
def linear_t191 : List Nat := linear_g191 ++ linear_t192
def linear_t190 : List Nat := linear_g190 ++ linear_t191
def linear_t189 : List Nat := linear_g189 ++ linear_t190
def linear_t188 : List Nat := linear_g188 ++ linear_t189
def linear_t187 : List Nat := linear_g187 ++ linear_t188
def linear_t186 : List Nat := linear_g186 ++ linear_t187
def linear_t185 : List Nat := linear_g185 ++ linear_t186
def linear_t184 : List Nat := linear_g184 ++ linear_t185
def linear_t183 : List Nat := linear_g183 ++ linear_t184
def linear_t182 : List Nat := linear_g182 ++ linear_t183
def linear_t181 : List Nat := linear_g181 ++ linear_t182
def linear_t180 : List Nat := linear_g180 ++ linear_t181
def linear_t179 : List Nat := linear_g179 ++ linear_t180
def linear_t178 : List Nat := linear_g178 ++ linear_t179
def linear_t177 : List Nat := linear_g177 ++ linear_t178
def linear_t176 : List Nat := linear_g176 ++ linear_t177
def linear_t175 : List Nat := linear_g175 ++ linear_t176
def linear_t174 : List Nat := linear_g174 ++ linear_t175
def linear_t173 : List Nat := linear_g173 ++ linear_t174
def linear_t172 : List Nat := linear_g172 ++ linear_t173
def linear_t171 : List Nat := linear_g171 ++ linear_t172
def linear_t170 : List Nat := linear_g170 ++ linear_t171
def linear_t169 : List Nat := linear_g169 ++ linear_t170
def linear_t168 : List Nat := linear_g168 ++ linear_t169
def linear_t167 : List Nat := linear_g167 ++ linear_t168
def linear_t166 : List Nat := linear_g166 ++ linear_t167
def linear_t165 : List Nat := linear_g165 ++ linear_t166
def linear_t164 : List Nat := linear_g164 ++ linear_t165
def linear_t163 : List Nat := linear_g163 ++ linear_t164
def linear_t162 : List Nat := linear_g162 ++ linear_t163
def linear_t161 : List Nat := linear_g161 ++ linear_t162
def linear_t160 : List Nat := linear_g160 ++ linear_t161
def linear_t159 : List Nat := linear_g159 ++ linear_t160
def linear_t158 : List Nat := linear_g158 ++ linear_t159
def linear_t157 : List Nat := linear_g157 ++ linear_t158
def linear_t156 : List Nat := linear_g156 ++ linear_t157
def linear_t155 : List Nat := linear_g155 ++ linear_t156
def linear_t154 : List Nat := linear_g154 ++ linear_t155
def linear_t153 : List Nat := linear_g153 ++ linear_t154
def linear_t152 : List Nat := linear_g152 ++ linear_t153
def linear_t151 : List Nat := linear_g151 ++ linear_t152
def linear_t150 : List Nat := linear_g150 ++ linear_t151
def linear_t149 : List Nat := linear_g149 ++ linear_t150
def linear_t148 : List Nat := linear_g148 ++ linear_t149
def linear_t147 : List Nat := linear_g147 ++ linear_t148
def linear_t146 : List Nat := linear_g146 ++ linear_t147
def linear_t145 : List Nat := linear_g145 ++ linear_t146
def linear_t144 : List Nat := linear_g144 ++ linear_t145
def linear_t143 : List Nat := linear_g143 ++ linear_t144
def linear_t142 : List Nat := linear_g142 ++ linear_t143
def linear_t141 : List Nat := linear_g141 ++ linear_t142
def linear_t140 : List Nat := linear_g140 ++ linear_t141
def linear_t139 : List Nat := linear_g139 ++ linear_t140
def linear_t138 : List Nat := linear_g138 ++ linear_t139
def linear_t137 : List Nat := linear_g137 ++ linear_t138
def linear_t136 : List Nat := linear_g136 ++ linear_t137
def linear_t135 : List Nat := linear_g135 ++ linear_t136
def linear_t134 : List Nat := linear_g134 ++ linear_t135
def linear_t133 : List Nat := linear_g133 ++ linear_t134
def linear_t132 : List Nat := linear_g132 ++ linear_t133
def linear_t131 : List Nat := linear_g131 ++ linear_t132
def linear_t130 : List Nat := linear_g130 ++ linear_t131
def linear_t129 : List Nat := linear_g129 ++ linear_t130
def linear_t128 : List Nat := linear_g128 ++ linear_t129
def linear_t127 : List Nat := linear_g127 ++ linear_t128
def linear_t126 : List Nat := linear_g126 ++ linear_t127
def linear_t125 : List Nat := linear_g125 ++ linear_t126
def linear_t124 : List Nat := linear_g124 ++ linear_t125
def linear_t123 : List Nat := linear_g123 ++ linear_t124
def linear_t122 : List Nat := linear_g122 ++ linear_t123
def linear_t121 : List Nat := linear_g121 ++ linear_t122
def linear_t120 : List Nat := linear_g120 ++ linear_t121
def linear_t119 : List Nat := linear_g119 ++ linear_t120
def linear_t118 : List Nat := linear_g118 ++ linear_t119
def linear_t117 : List Nat := linear_g117 ++ linear_t118
def linear_t116 : List Nat := linear_g116 ++ linear_t117
def linear_t115 : List Nat := linear_g115 ++ linear_t116
def linear_t114 : List Nat := linear_g114 ++ linear_t115
def linear_t113 : List Nat := linear_g113 ++ linear_t114
def linear_t112 : List Nat := linear_g112 ++ linear_t113
def linear_t111 : List Nat := linear_g111 ++ linear_t112
def linear_t110 : List Nat := linear_g110 ++ linear_t111
def linear_t109 : List Nat := linear_g109 ++ linear_t110
def linear_t108 : List Nat := linear_g108 ++ linear_t109
def linear_t107 : List Nat := linear_g107 ++ linear_t108
def linear_t106 : List Nat := linear_g106 ++ linear_t107
def linear_t105 : List Nat := linear_g105 ++ linear_t106
def linear_t104 : List Nat := linear_g104 ++ linear_t105
def linear_t103 : List Nat := linear_g103 ++ linear_t104
def linear_t102 : List Nat := linear_g102 ++ linear_t103
def linear_t101 : List Nat := linear_g101 ++ linear_t102
def linear_t100 : List Nat := linear_g100 ++ linear_t101
def linear_t99 : List Nat := linear_g99 ++ linear_t100
def linear_t98 : List Nat := linear_g98 ++ linear_t99
def linear_t97 : List Nat := linear_g97 ++ linear_t98
def linear_t96 : List Nat := linear_g96 ++ linear_t97
def linear_t95 : List Nat := linear_g95 ++ linear_t96
def linear_t94 : List Nat := linear_g94 ++ linear_t95
def linear_t93 : List Nat := linear_g93 ++ linear_t94
def linear_t92 : List Nat := linear_g92 ++ linear_t93
def linear_t91 : List Nat := linear_g91 ++ linear_t92
def linear_t90 : List Nat := linear_g90 ++ linear_t91
def linear_t89 : List Nat := linear_g89 ++ linear_t90
def linear_t88 : List Nat := linear_g88 ++ linear_t89
def linear_t87 : List Nat := linear_g87 ++ linear_t88
def linear_t86 : List Nat := linear_g86 ++ linear_t87
def linear_t85 : List Nat := linear_g85 ++ linear_t86
def linear_t84 : List Nat := linear_g84 ++ linear_t85
def linear_t83 : List Nat := linear_g83 ++ linear_t84
def linear_t82 : List Nat := linear_g82 ++ linear_t83
def linear_t81 : List Nat := linear_g81 ++ linear_t82
def linear_t80 : List Nat := linear_g80 ++ linear_t81
def linear_t79 : List Nat := linear_g79 ++ linear_t80
def linear_t78 : List Nat := linear_g78 ++ linear_t79
def linear_t77 : List Nat := linear_g77 ++ linear_t78
def linear_t76 : List Nat := linear_g76 ++ linear_t77
def linear_t75 : List Nat := linear_g75 ++ linear_t76
def linear_t74 : List Nat := linear_g74 ++ linear_t75
def linear_t73 : List Nat := linear_g73 ++ linear_t74
def linear_t72 : List Nat := linear_g72 ++ linear_t73
def linear_t71 : List Nat := linear_g71 ++ linear_t72
def linear_t70 : List Nat := linear_g70 ++ linear_t71
def linear_t69 : List Nat := linear_g69 ++ linear_t70
def linear_t68 : List Nat := linear_g68 ++ linear_t69
def linear_t67 : List Nat := linear_g67 ++ linear_t68
def linear_t66 : List Nat := linear_g66 ++ linear_t67
def linear_t65 : List Nat := linear_g65 ++ linear_t66
def linear_t64 : List Nat := linear_g64 ++ linear_t65
def linear_t63 : List Nat := linear_g63 ++ linear_t64
def linear_t62 : List Nat := linear_g62 ++ linear_t63
def linear_t61 : List Nat := linear_g61 ++ linear_t62
def linear_t60 : List Nat := linear_g60 ++ linear_t61
def linear_t59 : List Nat := linear_g59 ++ linear_t60
def linear_t58 : List Nat := linear_g58 ++ linear_t59
def linear_t57 : List Nat := linear_g57 ++ linear_t58
def linear_t56 : List Nat := linear_g56 ++ linear_t57
def linear_t55 : List Nat := linear_g55 ++ linear_t56
def linear_t54 : List Nat := linear_g54 ++ linear_t55
def linear_t53 : List Nat := linear_g53 ++ linear_t54
def linear_t52 : List Nat := linear_g52 ++ linear_t53
def linear_t51 : List Nat := linear_g51 ++ linear_t52
def linear_t50 : List Nat := linear_g50 ++ linear_t51
def linear_t49 : List Nat := linear_g49 ++ linear_t50
def linear_t48 : List Nat := linear_g48 ++ linear_t49
def linear_t47 : List Nat := linear_g47 ++ linear_t48
def linear_t46 : List Nat := linear_g46 ++ linear_t47
def linear_t45 : List Nat := linear_g45 ++ linear_t46
def linear_t44 : List Nat := linear_g44 ++ linear_t45
def linear_t43 : List Nat := linear_g43 ++ linear_t44
def linear_t42 : List Nat := linear_g42 ++ linear_t43
def linear_t41 : List Nat := linear_g41 ++ linear_t42
def linear_t40 : List Nat := linear_g40 ++ linear_t41
def linear_t39 : List Nat := linear_g39 ++ linear_t40
def linear_t38 : List Nat := linear_g38 ++ linear_t39
def linear_t37 : List Nat := linear_g37 ++ linear_t38
def linear_t36 : List Nat := linear_g36 ++ linear_t37
def linear_t35 : List Nat := linear_g35 ++ linear_t36
def linear_t34 : List Nat := linear_g34 ++ linear_t35
def linear_t33 : List Nat := linear_g33 ++ linear_t34
def linear_t32 : List Nat := linear_g32 ++ linear_t33
def linear_t31 : List Nat := linear_g31 ++ linear_t32
def linear_t30 : List Nat := linear_g30 ++ linear_t31
def linear_t29 : List Nat := linear_g29 ++ linear_t30
def linear_t28 : List Nat := linear_g28 ++ linear_t29
def linear_t27 : List Nat := linear_g27 ++ linear_t28
def linear_t26 : List Nat := linear_g26 ++ linear_t27
def linear_t25 : List Nat := linear_g25 ++ linear_t26
def linear_t24 : List Nat := linear_g24 ++ linear_t25
def linear_t23 : List Nat := linear_g23 ++ linear_t24
def linear_t22 : List Nat := linear_g22 ++ linear_t23
def linear_t21 : List Nat := linear_g21 ++ linear_t22
def linear_t20 : List Nat := linear_g20 ++ linear_t21
def linear_t19 : List Nat := linear_g19 ++ linear_t20
def linear_t18 : List Nat := linear_g18 ++ linear_t19
def linear_t17 : List Nat := linear_g17 ++ linear_t18
def linear_t16 : List Nat := linear_g16 ++ linear_t17
def linear_t15 : List Nat := linear_g15 ++ linear_t16
def linear_t14 : List Nat := linear_g14 ++ linear_t15
def linear_t13 : List Nat := linear_g13 ++ linear_t14
def linear_t12 : List Nat := linear_g12 ++ linear_t13
def linear_t11 : List Nat := linear_g11 ++ linear_t12
def linear_t10 : List Nat := linear_g10 ++ linear_t11
def linear_t9 : List Nat := linear_g9 ++ linear_t10
def linear_t8 : List Nat := linear_g8 ++ linear_t9
def linear_t7 : List Nat := linear_g7 ++ linear_t8
def linear_t6 : List Nat := linear_g6 ++ linear_t7
def linear_t5 : List Nat := linear_g5 ++ linear_t6
def linear_t4 : List Nat := linear_g4 ++ linear_t5
def linear_t3 : List Nat := linear_g3 ++ linear_t4
def linear_t2 : List Nat := linear_g2 ++ linear_t3
def linear_t1 : List Nat := linear_g1 ++ linear_t2
def linear_t0 : List Nat := linear_g0 ++ linear_t1
def linear_r1 : Raw := (.arr [(.str [99,97,108,99,117,108,97,116,101])])
def linear_b1 : List Nat := linear_g2
theorem mutated_s1 : serializeRaw 4094 31 linear_r1 = some linear_b1 := by decide +kernel
theorem mutated_p1 (tail : List Nat) : parseRaw 4094 31 (linear_b1 ++ tail) = some (linear_r1, tail) := by rfl
def linear_r6 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b6 : List Nat := linear_g11
theorem mutated_s6 : serializeRaw 4085 27 linear_r6 = some linear_b6 := by decide +kernel
theorem mutated_p6 (tail : List Nat) : parseRaw 4085 27 (linear_b6 ++ tail) = some (linear_r6, tail) := by rfl
def linear_r7 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,116,114,121,95,110,101,119])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49])),([116,121,112,101],(.str [98,111,111,108]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50])),([116,121,112,101],(.str [117,56]))])]))])])
def linear_b7 : List Nat := linear_g14
theorem mutated_s7 : serializeRaw 4084 27 linear_r7 = some linear_b7 := by decide +kernel
theorem mutated_p7 (tail : List Nat) : parseRaw 4084 27 (linear_b7 ++ tail) = some (linear_r7, tail) := by rfl
def linear_r8 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b8 : List Nat := linear_g17
theorem mutated_s8 : serializeRaw 4083 27 linear_r8 = some linear_b8 := by decide +kernel
theorem mutated_p8 (tail : List Nat) : parseRaw 4083 27 (linear_b8 ++ tail) = some (linear_r8, tail) := by rfl
def linear_r9 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,49]))]))])
def linear_b9 : List Nat := linear_g20
theorem mutated_s9 : serializeRaw 4082 27 linear_r9 = some linear_b9 := by decide +kernel
theorem mutated_p9 (tail : List Nat) : parseRaw 4082 27 (linear_b9 ++ tail) = some (linear_r9, tail) := by rfl
def linear_k5_0 : List Nat := [105,100]
theorem mutated_kd5_0 : stringBytes linear_k5_0 = true := by decide +kernel
theorem mutated_kp5_0 (tail : List Nat) : parseStringTail (linear_k5_0 ++ (34 :: 58 :: tail)) [] = some (linear_k5_0, 58 :: tail) := by rfl
def linear_k5_1 : List Nat := [111,112,115]
theorem mutated_kd5_1 : stringBytes linear_k5_1 = true := by decide +kernel
theorem mutated_kp5_1 (tail : List Nat) : parseStringTail (linear_k5_1 ++ (34 :: 58 :: tail)) [] = some (linear_k5_1, 58 :: tail) := by rfl
def linear_k5_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd5_2 : stringBytes linear_k5_2 = true := by decide +kernel
theorem mutated_kp5_2 (tail : List Nat) : parseStringTail (linear_k5_2 ++ (34 :: 58 :: tail)) [] = some (linear_k5_2, 58 :: tail) := by rfl
def linear_k5_3 : List Nat := [116,101,114,109]
theorem mutated_kd5_3 : stringBytes linear_k5_3 = true := by decide +kernel
theorem mutated_kp5_3 (tail : List Nat) : parseStringTail (linear_k5_3 ++ (34 :: 58 :: tail)) [] = some (linear_k5_3, 58 :: tail) := by rfl
def linear_l5_3 : List (List Nat × Raw) := [(linear_k5_3, linear_r9)]
def linear_v5_3 : List Nat := linear_g19 ++ linear_b9
theorem mutated_sl5_3 : serializeFields 4083 27 linear_l5_3 = some linear_v5_3 := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4082 27 linear_k5_3 linear_r9 linear_b9 mutated_kd5_3 mutated_s9)
theorem mutated_pl5_3 (tail : List Nat) : parseFields 4083 27 (linear_v5_3 ++ (125 :: tail)) = some (linear_l5_3, tail) := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4082 27 (linear_k5_3 ++ (34 :: 58 :: (linear_b9 ++ (125 :: tail)))) linear_k5_3 (linear_b9 ++ (125 :: tail)) tail linear_r9 (mutated_kp5_3 (linear_b9 ++ (125 :: tail))) (mutated_p9 (125 :: tail)))
def linear_l5_2 : List (List Nat × Raw) := (linear_k5_2, linear_r8) :: linear_l5_3
def linear_v5_2 : List Nat := (linear_g16 ++ linear_b8) ++ (44 :: linear_v5_3)
theorem mutated_sl5_2 : serializeFields 4084 27 linear_l5_2 = some linear_v5_2 := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k5_2 linear_r8 (linear_k5_3, linear_r9) [] linear_b8 linear_v5_3 mutated_kd5_2 mutated_s8 mutated_sl5_3)
theorem mutated_pl5_2 (tail : List Nat) : parseFields 4084 27 (linear_v5_2 ++ (125 :: tail)) = some (linear_l5_2, tail) := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k5_2 ++ (34 :: 58 :: (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))))) linear_k5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))) (linear_v5_3 ++ (125 :: tail)) tail linear_r8 linear_l5_3 (mutated_kp5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail))))) (mutated_p8 (44 :: (linear_v5_3 ++ (125 :: tail)))) (mutated_pl5_3 tail))
def linear_l5_1 : List (List Nat × Raw) := (linear_k5_1, linear_r7) :: linear_l5_2
def linear_v5_1 : List Nat := (linear_g13 ++ linear_b7) ++ (44 :: linear_v5_2)
theorem mutated_sl5_1 : serializeFields 4085 27 linear_l5_1 = some linear_v5_1 := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k5_1 linear_r7 (linear_k5_2, linear_r8) linear_l5_3 linear_b7 linear_v5_2 mutated_kd5_1 mutated_s7 mutated_sl5_2)
theorem mutated_pl5_1 (tail : List Nat) : parseFields 4085 27 (linear_v5_1 ++ (125 :: tail)) = some (linear_l5_1, tail) := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k5_1 ++ (34 :: 58 :: (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))))) linear_k5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))) (linear_v5_2 ++ (125 :: tail)) tail linear_r7 linear_l5_2 (mutated_kp5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail))))) (mutated_p7 (44 :: (linear_v5_2 ++ (125 :: tail)))) (mutated_pl5_2 tail))
def linear_l5_0 : List (List Nat × Raw) := (linear_k5_0, linear_r6) :: linear_l5_1
def linear_v5_0 : List Nat := (linear_g10 ++ linear_b6) ++ (44 :: linear_v5_1)
theorem mutated_sl5_0 : serializeFields 4086 27 linear_l5_0 = some linear_v5_0 := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 27 linear_k5_0 linear_r6 (linear_k5_1, linear_r7) linear_l5_2 linear_b6 linear_v5_1 mutated_kd5_0 mutated_s6 mutated_sl5_1)
theorem mutated_pl5_0 (tail : List Nat) : parseFields 4086 27 (linear_v5_0 ++ (125 :: tail)) = some (linear_l5_0, tail) := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) linear_k5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))) (linear_v5_1 ++ (125 :: tail)) tail linear_r6 linear_l5_1 (mutated_kp5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail))))) (mutated_p6 (44 :: (linear_v5_1 ++ (125 :: tail)))) (mutated_pl5_1 tail))
def linear_r5 : Raw := (.obj linear_l5_0)
def linear_b5 : List Nat := linear_g9 ++ (linear_v5_0 ++ linear_g21)
theorem mutated_o5 : orderedFields linear_l5_0 = true := by decide +kernel
theorem mutated_s5 : serializeRaw 4087 28 linear_r5 = some linear_b5 := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4086 27 linear_l5_0 linear_v5_0 mutated_o5 mutated_sl5_0)
theorem mutated_p5 (tail : List Nat) : parseRaw 4087 28 (linear_b5 ++ tail) = some (linear_r5, tail) := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4086 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) tail linear_l5_0 mutated_o5 (by simpa only [linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl5_0 tail)))
def linear_r11 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,49])
def linear_b11 : List Nat := linear_g25
theorem mutated_s11 : serializeRaw 4084 27 linear_r11 = some linear_b11 := by decide +kernel
theorem mutated_p11 (tail : List Nat) : parseRaw 4084 27 (linear_b11 ++ tail) = some (linear_r11, tail) := by rfl
def linear_r12 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b12 : List Nat := linear_g28
theorem mutated_s12 : serializeRaw 4083 27 linear_r12 = some linear_b12 := by decide +kernel
theorem mutated_p12 (tail : List Nat) : parseRaw 4083 27 (linear_b12 ++ tail) = some (linear_r12, tail) := by rfl
def linear_r13 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b13 : List Nat := linear_g31
theorem mutated_s13 : serializeRaw 4082 27 linear_r13 = some linear_b13 := by decide +kernel
theorem mutated_p13 (tail : List Nat) : parseRaw 4082 27 (linear_b13 ++ tail) = some (linear_r13, tail) := by rfl
def linear_r14 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,52]),(.str [100,103,95,118,95,56]),(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,57]),(.str [100,103,95,118,95,49,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,51]))])
def linear_b14 : List Nat := linear_g34
theorem mutated_s14 : serializeRaw 4081 27 linear_r14 = some linear_b14 := by decide +kernel
theorem mutated_p14 (tail : List Nat) : parseRaw 4081 27 (linear_b14 ++ tail) = some (linear_r14, tail) := by rfl
def linear_k10_0 : List Nat := [105,100]
theorem mutated_kd10_0 : stringBytes linear_k10_0 = true := by decide +kernel
theorem mutated_kp10_0 (tail : List Nat) : parseStringTail (linear_k10_0 ++ (34 :: 58 :: tail)) [] = some (linear_k10_0, 58 :: tail) := by rfl
def linear_k10_1 : List Nat := [111,112,115]
theorem mutated_kd10_1 : stringBytes linear_k10_1 = true := by decide +kernel
theorem mutated_kp10_1 (tail : List Nat) : parseStringTail (linear_k10_1 ++ (34 :: 58 :: tail)) [] = some (linear_k10_1, 58 :: tail) := by rfl
def linear_k10_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd10_2 : stringBytes linear_k10_2 = true := by decide +kernel
theorem mutated_kp10_2 (tail : List Nat) : parseStringTail (linear_k10_2 ++ (34 :: 58 :: tail)) [] = some (linear_k10_2, 58 :: tail) := by rfl
def linear_k10_3 : List Nat := [116,101,114,109]
theorem mutated_kd10_3 : stringBytes linear_k10_3 = true := by decide +kernel
theorem mutated_kp10_3 (tail : List Nat) : parseStringTail (linear_k10_3 ++ (34 :: 58 :: tail)) [] = some (linear_k10_3, 58 :: tail) := by rfl
def linear_l10_3 : List (List Nat × Raw) := [(linear_k10_3, linear_r14)]
def linear_v10_3 : List Nat := linear_g33 ++ linear_b14
theorem mutated_sl10_3 : serializeFields 4082 27 linear_l10_3 = some linear_v10_3 := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4081 27 linear_k10_3 linear_r14 linear_b14 mutated_kd10_3 mutated_s14)
theorem mutated_pl10_3 (tail : List Nat) : parseFields 4082 27 (linear_v10_3 ++ (125 :: tail)) = some (linear_l10_3, tail) := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4081 27 (linear_k10_3 ++ (34 :: 58 :: (linear_b14 ++ (125 :: tail)))) linear_k10_3 (linear_b14 ++ (125 :: tail)) tail linear_r14 (mutated_kp10_3 (linear_b14 ++ (125 :: tail))) (mutated_p14 (125 :: tail)))
def linear_l10_2 : List (List Nat × Raw) := (linear_k10_2, linear_r13) :: linear_l10_3
def linear_v10_2 : List Nat := (linear_g30 ++ linear_b13) ++ (44 :: linear_v10_3)
theorem mutated_sl10_2 : serializeFields 4083 27 linear_l10_2 = some linear_v10_2 := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k10_2 linear_r13 (linear_k10_3, linear_r14) [] linear_b13 linear_v10_3 mutated_kd10_2 mutated_s13 mutated_sl10_3)
theorem mutated_pl10_2 (tail : List Nat) : parseFields 4083 27 (linear_v10_2 ++ (125 :: tail)) = some (linear_l10_2, tail) := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k10_2 ++ (34 :: 58 :: (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))))) linear_k10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))) (linear_v10_3 ++ (125 :: tail)) tail linear_r13 linear_l10_3 (mutated_kp10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail))))) (mutated_p13 (44 :: (linear_v10_3 ++ (125 :: tail)))) (mutated_pl10_3 tail))
def linear_l10_1 : List (List Nat × Raw) := (linear_k10_1, linear_r12) :: linear_l10_2
def linear_v10_1 : List Nat := (linear_g27 ++ linear_b12) ++ (44 :: linear_v10_2)
theorem mutated_sl10_1 : serializeFields 4084 27 linear_l10_1 = some linear_v10_1 := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k10_1 linear_r12 (linear_k10_2, linear_r13) linear_l10_3 linear_b12 linear_v10_2 mutated_kd10_1 mutated_s12 mutated_sl10_2)
theorem mutated_pl10_1 (tail : List Nat) : parseFields 4084 27 (linear_v10_1 ++ (125 :: tail)) = some (linear_l10_1, tail) := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k10_1 ++ (34 :: 58 :: (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))))) linear_k10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))) (linear_v10_2 ++ (125 :: tail)) tail linear_r12 linear_l10_2 (mutated_kp10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail))))) (mutated_p12 (44 :: (linear_v10_2 ++ (125 :: tail)))) (mutated_pl10_2 tail))
def linear_l10_0 : List (List Nat × Raw) := (linear_k10_0, linear_r11) :: linear_l10_1
def linear_v10_0 : List Nat := (linear_g24 ++ linear_b11) ++ (44 :: linear_v10_1)
theorem mutated_sl10_0 : serializeFields 4085 27 linear_l10_0 = some linear_v10_0 := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k10_0 linear_r11 (linear_k10_1, linear_r12) linear_l10_2 linear_b11 linear_v10_1 mutated_kd10_0 mutated_s11 mutated_sl10_1)
theorem mutated_pl10_0 (tail : List Nat) : parseFields 4085 27 (linear_v10_0 ++ (125 :: tail)) = some (linear_l10_0, tail) := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) linear_k10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))) (linear_v10_1 ++ (125 :: tail)) tail linear_r11 linear_l10_1 (mutated_kp10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail))))) (mutated_p11 (44 :: (linear_v10_1 ++ (125 :: tail)))) (mutated_pl10_1 tail))
def linear_r10 : Raw := (.obj linear_l10_0)
def linear_b10 : List Nat := linear_g23 ++ (linear_v10_0 ++ linear_g35)
theorem mutated_o10 : orderedFields linear_l10_0 = true := by decide +kernel
theorem mutated_s10 : serializeRaw 4086 28 linear_r10 = some linear_b10 := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4085 27 linear_l10_0 linear_v10_0 mutated_o10 mutated_sl10_0)
theorem mutated_p10 (tail : List Nat) : parseRaw 4086 28 (linear_b10 ++ tail) = some (linear_r10, tail) := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4085 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) tail linear_l10_0 mutated_o10 (by simpa only [linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl10_0 tail)))
def linear_r16 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,50])
def linear_b16 : List Nat := linear_g39
theorem mutated_s16 : serializeRaw 4083 27 linear_r16 = some linear_b16 := by decide +kernel
theorem mutated_p16 (tail : List Nat) : parseRaw 4083 27 (linear_b16 ++ tail) = some (linear_r16, tail) := by rfl
def linear_r18 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])
def linear_b18 : List Nat := linear_g43
theorem mutated_s18 : serializeRaw 4080 26 linear_r18 = some linear_b18 := by decide +kernel
theorem mutated_p18 (tail : List Nat) : parseRaw 4080 26 (linear_b18 ++ tail) = some (linear_r18, tail) := by rfl
def linear_r19 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1000))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b19 : List Nat := linear_g45
theorem mutated_s19 : serializeRaw 4079 26 linear_r19 = some linear_b19 := by decide +kernel
theorem mutated_p19 (tail : List Nat) : parseRaw 4079 26 (linear_b19 ++ tail) = some (linear_r19, tail) := by rfl
def linear_r20 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b20 : List Nat := linear_g47
theorem mutated_s20 : serializeRaw 4078 26 linear_r20 = some linear_b20 := by decide +kernel
theorem mutated_p20 (tail : List Nat) : parseRaw 4078 26 (linear_b20 ++ tail) = some (linear_r20, tail) := by rfl
def linear_r21 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54]),(.str [100,103,95,118,95,49,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,56])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b21 : List Nat := linear_g49
theorem mutated_s21 : serializeRaw 4077 26 linear_r21 = some linear_b21 := by decide +kernel
theorem mutated_p21 (tail : List Nat) : parseRaw 4077 26 (linear_b21 ++ tail) = some (linear_r21, tail) := by rfl
def linear_l17_3 : List Raw := [linear_r21]
def linear_v17_3 : List Nat := linear_b21
theorem mutated_sl17_3 : serializeItems 4078 26 linear_l17_3 = some linear_v17_3 := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4077 26 linear_r21 linear_b21 mutated_s21)
theorem mutated_pl17_3 (tail : List Nat) : parseItems 4078 26 (linear_v17_3 ++ (93 :: tail)) = some (linear_l17_3, tail) := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4077 26 (linear_b21 ++ (93 :: tail)) tail linear_r21 (mutated_p21 (93 :: tail)))
def linear_l17_2 : List Raw := linear_r20 :: linear_l17_3
def linear_v17_2 : List Nat := (linear_b20) ++ (44 :: linear_v17_3)
theorem mutated_sl17_2 : serializeItems 4079 26 linear_l17_2 = some linear_v17_2 := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 26 linear_r20 linear_r21 [] linear_b20 linear_v17_3 mutated_s20 mutated_sl17_3)
theorem mutated_pl17_2 (tail : List Nat) : parseItems 4079 26 (linear_v17_2 ++ (93 :: tail)) = some (linear_l17_2, tail) := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 26 (linear_b20 ++ (44 :: (linear_v17_3 ++ (93 :: tail)))) (linear_v17_3 ++ (93 :: tail)) tail linear_r20 linear_l17_3 (mutated_p20 (44 :: (linear_v17_3 ++ (93 :: tail)))) (mutated_pl17_3 tail))
def linear_l17_1 : List Raw := linear_r19 :: linear_l17_2
def linear_v17_1 : List Nat := (linear_b19) ++ (44 :: linear_v17_2)
theorem mutated_sl17_1 : serializeItems 4080 26 linear_l17_1 = some linear_v17_1 := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 26 linear_r19 linear_r20 linear_l17_3 linear_b19 linear_v17_2 mutated_s19 mutated_sl17_2)
theorem mutated_pl17_1 (tail : List Nat) : parseItems 4080 26 (linear_v17_1 ++ (93 :: tail)) = some (linear_l17_1, tail) := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 26 (linear_b19 ++ (44 :: (linear_v17_2 ++ (93 :: tail)))) (linear_v17_2 ++ (93 :: tail)) tail linear_r19 linear_l17_2 (mutated_p19 (44 :: (linear_v17_2 ++ (93 :: tail)))) (mutated_pl17_2 tail))
def linear_l17_0 : List Raw := linear_r18 :: linear_l17_1
def linear_v17_0 : List Nat := (linear_b18) ++ (44 :: linear_v17_1)
theorem mutated_sl17_0 : serializeItems 4081 26 linear_l17_0 = some linear_v17_0 := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 26 linear_r18 linear_r19 linear_l17_2 linear_b18 linear_v17_1 mutated_s18 mutated_sl17_1)
theorem mutated_pl17_0 (tail : List Nat) : parseItems 4081 26 (linear_v17_0 ++ (93 :: tail)) = some (linear_l17_0, tail) := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 26 (linear_b18 ++ (44 :: (linear_v17_1 ++ (93 :: tail)))) (linear_v17_1 ++ (93 :: tail)) tail linear_r18 linear_l17_1 (mutated_p18 (44 :: (linear_v17_1 ++ (93 :: tail)))) (mutated_pl17_1 tail))
def linear_r17 : Raw := (.arr linear_l17_0)
def linear_b17 : List Nat := linear_g42 ++ (linear_v17_0 ++ linear_g50)
theorem mutated_s17 : serializeRaw 4082 27 linear_r17 = some linear_b17 := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4081 26 linear_l17_0 linear_v17_0 mutated_sl17_0)
theorem mutated_p17 (tail : List Nat) : parseRaw 4082 27 (linear_b17 ++ tail) = some (linear_r17, tail) := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4081 26 (linear_v17_0 ++ (93 :: tail)) tail linear_l17_0 (by intro h; cases h) (mutated_pl17_0 tail))
def linear_r22 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,57])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b22 : List Nat := linear_g53
theorem mutated_s22 : serializeRaw 4081 27 linear_r22 = some linear_b22 := by decide +kernel
theorem mutated_p22 (tail : List Nat) : parseRaw 4081 27 (linear_b22 ++ tail) = some (linear_r22, tail) := by rfl
def linear_r23 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,56])]))])
def linear_b23 : List Nat := linear_g56
theorem mutated_s23 : serializeRaw 4080 27 linear_r23 = some linear_b23 := by decide +kernel
theorem mutated_p23 (tail : List Nat) : parseRaw 4080 27 (linear_b23 ++ tail) = some (linear_r23, tail) := by rfl
def linear_k15_0 : List Nat := [105,100]
theorem mutated_kd15_0 : stringBytes linear_k15_0 = true := by decide +kernel
theorem mutated_kp15_0 (tail : List Nat) : parseStringTail (linear_k15_0 ++ (34 :: 58 :: tail)) [] = some (linear_k15_0, 58 :: tail) := by rfl
def linear_k15_1 : List Nat := [111,112,115]
theorem mutated_kd15_1 : stringBytes linear_k15_1 = true := by decide +kernel
theorem mutated_kp15_1 (tail : List Nat) : parseStringTail (linear_k15_1 ++ (34 :: 58 :: tail)) [] = some (linear_k15_1, 58 :: tail) := by rfl
def linear_k15_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd15_2 : stringBytes linear_k15_2 = true := by decide +kernel
theorem mutated_kp15_2 (tail : List Nat) : parseStringTail (linear_k15_2 ++ (34 :: 58 :: tail)) [] = some (linear_k15_2, 58 :: tail) := by rfl
def linear_k15_3 : List Nat := [116,101,114,109]
theorem mutated_kd15_3 : stringBytes linear_k15_3 = true := by decide +kernel
theorem mutated_kp15_3 (tail : List Nat) : parseStringTail (linear_k15_3 ++ (34 :: 58 :: tail)) [] = some (linear_k15_3, 58 :: tail) := by rfl
def linear_l15_3 : List (List Nat × Raw) := [(linear_k15_3, linear_r23)]
def linear_v15_3 : List Nat := linear_g55 ++ linear_b23
theorem mutated_sl15_3 : serializeFields 4081 27 linear_l15_3 = some linear_v15_3 := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4080 27 linear_k15_3 linear_r23 linear_b23 mutated_kd15_3 mutated_s23)
theorem mutated_pl15_3 (tail : List Nat) : parseFields 4081 27 (linear_v15_3 ++ (125 :: tail)) = some (linear_l15_3, tail) := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4080 27 (linear_k15_3 ++ (34 :: 58 :: (linear_b23 ++ (125 :: tail)))) linear_k15_3 (linear_b23 ++ (125 :: tail)) tail linear_r23 (mutated_kp15_3 (linear_b23 ++ (125 :: tail))) (mutated_p23 (125 :: tail)))
def linear_l15_2 : List (List Nat × Raw) := (linear_k15_2, linear_r22) :: linear_l15_3
def linear_v15_2 : List Nat := (linear_g52 ++ linear_b22) ++ (44 :: linear_v15_3)
theorem mutated_sl15_2 : serializeFields 4082 27 linear_l15_2 = some linear_v15_2 := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k15_2 linear_r22 (linear_k15_3, linear_r23) [] linear_b22 linear_v15_3 mutated_kd15_2 mutated_s22 mutated_sl15_3)
theorem mutated_pl15_2 (tail : List Nat) : parseFields 4082 27 (linear_v15_2 ++ (125 :: tail)) = some (linear_l15_2, tail) := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k15_2 ++ (34 :: 58 :: (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))))) linear_k15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))) (linear_v15_3 ++ (125 :: tail)) tail linear_r22 linear_l15_3 (mutated_kp15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail))))) (mutated_p22 (44 :: (linear_v15_3 ++ (125 :: tail)))) (mutated_pl15_3 tail))
def linear_l15_1 : List (List Nat × Raw) := (linear_k15_1, linear_r17) :: linear_l15_2
def linear_v15_1 : List Nat := (linear_g41 ++ linear_b17) ++ (44 :: linear_v15_2)
theorem mutated_sl15_1 : serializeFields 4083 27 linear_l15_1 = some linear_v15_1 := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k15_1 linear_r17 (linear_k15_2, linear_r22) linear_l15_3 linear_b17 linear_v15_2 mutated_kd15_1 mutated_s17 mutated_sl15_2)
theorem mutated_pl15_1 (tail : List Nat) : parseFields 4083 27 (linear_v15_1 ++ (125 :: tail)) = some (linear_l15_1, tail) := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k15_1 ++ (34 :: 58 :: (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))))) linear_k15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))) (linear_v15_2 ++ (125 :: tail)) tail linear_r17 linear_l15_2 (mutated_kp15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail))))) (mutated_p17 (44 :: (linear_v15_2 ++ (125 :: tail)))) (mutated_pl15_2 tail))
def linear_l15_0 : List (List Nat × Raw) := (linear_k15_0, linear_r16) :: linear_l15_1
def linear_v15_0 : List Nat := (linear_g38 ++ linear_b16) ++ (44 :: linear_v15_1)
theorem mutated_sl15_0 : serializeFields 4084 27 linear_l15_0 = some linear_v15_0 := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k15_0 linear_r16 (linear_k15_1, linear_r17) linear_l15_2 linear_b16 linear_v15_1 mutated_kd15_0 mutated_s16 mutated_sl15_1)
theorem mutated_pl15_0 (tail : List Nat) : parseFields 4084 27 (linear_v15_0 ++ (125 :: tail)) = some (linear_l15_0, tail) := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) linear_k15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))) (linear_v15_1 ++ (125 :: tail)) tail linear_r16 linear_l15_1 (mutated_kp15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail))))) (mutated_p16 (44 :: (linear_v15_1 ++ (125 :: tail)))) (mutated_pl15_1 tail))
def linear_r15 : Raw := (.obj linear_l15_0)
def linear_b15 : List Nat := linear_g37 ++ (linear_v15_0 ++ linear_g57)
theorem mutated_o15 : orderedFields linear_l15_0 = true := by decide +kernel
theorem mutated_s15 : serializeRaw 4085 28 linear_r15 = some linear_b15 := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4084 27 linear_l15_0 linear_v15_0 mutated_o15 mutated_sl15_0)
theorem mutated_p15 (tail : List Nat) : parseRaw 4085 28 (linear_b15 ++ tail) = some (linear_r15, tail) := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4084 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) tail linear_l15_0 mutated_o15 (by simpa only [linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl15_0 tail)))
def linear_r25 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,51])
def linear_b25 : List Nat := linear_g61
theorem mutated_s25 : serializeRaw 4082 27 linear_r25 = some linear_b25 := by decide +kernel
theorem mutated_p25 (tail : List Nat) : parseRaw 4082 27 (linear_b25 ++ tail) = some (linear_r25, tail) := by rfl
def linear_r26 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,53])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b26 : List Nat := linear_g64
theorem mutated_s26 : serializeRaw 4081 27 linear_r26 = some linear_b26 := by decide +kernel
theorem mutated_p26 (tail : List Nat) : parseRaw 4081 27 (linear_b26 ++ tail) = some (linear_r26, tail) := by rfl
def linear_r27 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b27 : List Nat := linear_g67
theorem mutated_s27 : serializeRaw 4080 27 linear_r27 = some linear_b27 := by decide +kernel
theorem mutated_p27 (tail : List Nat) : parseRaw 4080 27 (linear_b27 ++ tail) = some (linear_r27, tail) := by rfl
def linear_r28 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,50,53])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,48]))]))])
def linear_b28 : List Nat := linear_g70
theorem mutated_s28 : serializeRaw 4079 27 linear_r28 = some linear_b28 := by decide +kernel
theorem mutated_p28 (tail : List Nat) : parseRaw 4079 27 (linear_b28 ++ tail) = some (linear_r28, tail) := by rfl
def linear_k24_0 : List Nat := [105,100]
theorem mutated_kd24_0 : stringBytes linear_k24_0 = true := by decide +kernel
theorem mutated_kp24_0 (tail : List Nat) : parseStringTail (linear_k24_0 ++ (34 :: 58 :: tail)) [] = some (linear_k24_0, 58 :: tail) := by rfl
def linear_k24_1 : List Nat := [111,112,115]
theorem mutated_kd24_1 : stringBytes linear_k24_1 = true := by decide +kernel
theorem mutated_kp24_1 (tail : List Nat) : parseStringTail (linear_k24_1 ++ (34 :: 58 :: tail)) [] = some (linear_k24_1, 58 :: tail) := by rfl
def linear_k24_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd24_2 : stringBytes linear_k24_2 = true := by decide +kernel
theorem mutated_kp24_2 (tail : List Nat) : parseStringTail (linear_k24_2 ++ (34 :: 58 :: tail)) [] = some (linear_k24_2, 58 :: tail) := by rfl
def linear_k24_3 : List Nat := [116,101,114,109]
theorem mutated_kd24_3 : stringBytes linear_k24_3 = true := by decide +kernel
theorem mutated_kp24_3 (tail : List Nat) : parseStringTail (linear_k24_3 ++ (34 :: 58 :: tail)) [] = some (linear_k24_3, 58 :: tail) := by rfl
def linear_l24_3 : List (List Nat × Raw) := [(linear_k24_3, linear_r28)]
def linear_v24_3 : List Nat := linear_g69 ++ linear_b28
theorem mutated_sl24_3 : serializeFields 4080 27 linear_l24_3 = some linear_v24_3 := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4079 27 linear_k24_3 linear_r28 linear_b28 mutated_kd24_3 mutated_s28)
theorem mutated_pl24_3 (tail : List Nat) : parseFields 4080 27 (linear_v24_3 ++ (125 :: tail)) = some (linear_l24_3, tail) := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4079 27 (linear_k24_3 ++ (34 :: 58 :: (linear_b28 ++ (125 :: tail)))) linear_k24_3 (linear_b28 ++ (125 :: tail)) tail linear_r28 (mutated_kp24_3 (linear_b28 ++ (125 :: tail))) (mutated_p28 (125 :: tail)))
def linear_l24_2 : List (List Nat × Raw) := (linear_k24_2, linear_r27) :: linear_l24_3
def linear_v24_2 : List Nat := (linear_g66 ++ linear_b27) ++ (44 :: linear_v24_3)
theorem mutated_sl24_2 : serializeFields 4081 27 linear_l24_2 = some linear_v24_2 := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k24_2 linear_r27 (linear_k24_3, linear_r28) [] linear_b27 linear_v24_3 mutated_kd24_2 mutated_s27 mutated_sl24_3)
theorem mutated_pl24_2 (tail : List Nat) : parseFields 4081 27 (linear_v24_2 ++ (125 :: tail)) = some (linear_l24_2, tail) := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k24_2 ++ (34 :: 58 :: (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))))) linear_k24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))) (linear_v24_3 ++ (125 :: tail)) tail linear_r27 linear_l24_3 (mutated_kp24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail))))) (mutated_p27 (44 :: (linear_v24_3 ++ (125 :: tail)))) (mutated_pl24_3 tail))
def linear_l24_1 : List (List Nat × Raw) := (linear_k24_1, linear_r26) :: linear_l24_2
def linear_v24_1 : List Nat := (linear_g63 ++ linear_b26) ++ (44 :: linear_v24_2)
theorem mutated_sl24_1 : serializeFields 4082 27 linear_l24_1 = some linear_v24_1 := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k24_1 linear_r26 (linear_k24_2, linear_r27) linear_l24_3 linear_b26 linear_v24_2 mutated_kd24_1 mutated_s26 mutated_sl24_2)
theorem mutated_pl24_1 (tail : List Nat) : parseFields 4082 27 (linear_v24_1 ++ (125 :: tail)) = some (linear_l24_1, tail) := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k24_1 ++ (34 :: 58 :: (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))))) linear_k24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))) (linear_v24_2 ++ (125 :: tail)) tail linear_r26 linear_l24_2 (mutated_kp24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail))))) (mutated_p26 (44 :: (linear_v24_2 ++ (125 :: tail)))) (mutated_pl24_2 tail))
def linear_l24_0 : List (List Nat × Raw) := (linear_k24_0, linear_r25) :: linear_l24_1
def linear_v24_0 : List Nat := (linear_g60 ++ linear_b25) ++ (44 :: linear_v24_1)
theorem mutated_sl24_0 : serializeFields 4083 27 linear_l24_0 = some linear_v24_0 := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k24_0 linear_r25 (linear_k24_1, linear_r26) linear_l24_2 linear_b25 linear_v24_1 mutated_kd24_0 mutated_s25 mutated_sl24_1)
theorem mutated_pl24_0 (tail : List Nat) : parseFields 4083 27 (linear_v24_0 ++ (125 :: tail)) = some (linear_l24_0, tail) := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) linear_k24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))) (linear_v24_1 ++ (125 :: tail)) tail linear_r25 linear_l24_1 (mutated_kp24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail))))) (mutated_p25 (44 :: (linear_v24_1 ++ (125 :: tail)))) (mutated_pl24_1 tail))
def linear_r24 : Raw := (.obj linear_l24_0)
def linear_b24 : List Nat := linear_g59 ++ (linear_v24_0 ++ linear_g71)
theorem mutated_o24 : orderedFields linear_l24_0 = true := by decide +kernel
theorem mutated_s24 : serializeRaw 4084 28 linear_r24 = some linear_b24 := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4083 27 linear_l24_0 linear_v24_0 mutated_o24 mutated_sl24_0)
theorem mutated_p24 (tail : List Nat) : parseRaw 4084 28 (linear_b24 ++ tail) = some (linear_r24, tail) := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4083 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) tail linear_l24_0 mutated_o24 (by simpa only [linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl24_0 tail)))
def linear_r30 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,52])
def linear_b30 : List Nat := linear_g75
theorem mutated_s30 : serializeRaw 4081 27 linear_r30 = some linear_b30 := by decide +kernel
theorem mutated_p30 (tail : List Nat) : parseRaw 4081 27 (linear_b30 ++ tail) = some (linear_r30, tail) := by rfl
def linear_r31 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,50])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b31 : List Nat := linear_g78
theorem mutated_s31 : serializeRaw 4080 27 linear_r31 = some linear_b31 := by decide +kernel
theorem mutated_p31 (tail : List Nat) : parseRaw 4080 27 (linear_b31 ++ tail) = some (linear_r31, tail) := by rfl
def linear_r32 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b32 : List Nat := linear_g81
theorem mutated_s32 : serializeRaw 4079 27 linear_r32 = some linear_b32 := by decide +kernel
theorem mutated_p32 (tail : List Nat) : parseRaw 4079 27 (linear_b32 ++ tail) = some (linear_r32, tail) := by rfl
def linear_r33 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,50,56]),(.str [100,103,95,118,95,50,57]),(.str [100,103,95,118,95,51,50]),(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,51,51]),(.str [100,103,95,118,95,51,52])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,53]))])
def linear_b33 : List Nat := linear_g84
theorem mutated_s33 : serializeRaw 4078 27 linear_r33 = some linear_b33 := by decide +kernel
theorem mutated_p33 (tail : List Nat) : parseRaw 4078 27 (linear_b33 ++ tail) = some (linear_r33, tail) := by rfl
def linear_k29_0 : List Nat := [105,100]
theorem mutated_kd29_0 : stringBytes linear_k29_0 = true := by decide +kernel
theorem mutated_kp29_0 (tail : List Nat) : parseStringTail (linear_k29_0 ++ (34 :: 58 :: tail)) [] = some (linear_k29_0, 58 :: tail) := by rfl
def linear_k29_1 : List Nat := [111,112,115]
theorem mutated_kd29_1 : stringBytes linear_k29_1 = true := by decide +kernel
theorem mutated_kp29_1 (tail : List Nat) : parseStringTail (linear_k29_1 ++ (34 :: 58 :: tail)) [] = some (linear_k29_1, 58 :: tail) := by rfl
def linear_k29_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd29_2 : stringBytes linear_k29_2 = true := by decide +kernel
theorem mutated_kp29_2 (tail : List Nat) : parseStringTail (linear_k29_2 ++ (34 :: 58 :: tail)) [] = some (linear_k29_2, 58 :: tail) := by rfl
def linear_k29_3 : List Nat := [116,101,114,109]
theorem mutated_kd29_3 : stringBytes linear_k29_3 = true := by decide +kernel
theorem mutated_kp29_3 (tail : List Nat) : parseStringTail (linear_k29_3 ++ (34 :: 58 :: tail)) [] = some (linear_k29_3, 58 :: tail) := by rfl
def linear_l29_3 : List (List Nat × Raw) := [(linear_k29_3, linear_r33)]
def linear_v29_3 : List Nat := linear_g83 ++ linear_b33
theorem mutated_sl29_3 : serializeFields 4079 27 linear_l29_3 = some linear_v29_3 := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4078 27 linear_k29_3 linear_r33 linear_b33 mutated_kd29_3 mutated_s33)
theorem mutated_pl29_3 (tail : List Nat) : parseFields 4079 27 (linear_v29_3 ++ (125 :: tail)) = some (linear_l29_3, tail) := by
  simpa only [linear_l29_3, linear_v29_3, linear_k29_3, linear_g83, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4078 27 (linear_k29_3 ++ (34 :: 58 :: (linear_b33 ++ (125 :: tail)))) linear_k29_3 (linear_b33 ++ (125 :: tail)) tail linear_r33 (mutated_kp29_3 (linear_b33 ++ (125 :: tail))) (mutated_p33 (125 :: tail)))
def linear_l29_2 : List (List Nat × Raw) := (linear_k29_2, linear_r32) :: linear_l29_3
def linear_v29_2 : List Nat := (linear_g80 ++ linear_b32) ++ (44 :: linear_v29_3)
theorem mutated_sl29_2 : serializeFields 4080 27 linear_l29_2 = some linear_v29_2 := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k29_2 linear_r32 (linear_k29_3, linear_r33) [] linear_b32 linear_v29_3 mutated_kd29_2 mutated_s32 mutated_sl29_3)
theorem mutated_pl29_2 (tail : List Nat) : parseFields 4080 27 (linear_v29_2 ++ (125 :: tail)) = some (linear_l29_2, tail) := by
  simpa only [linear_l29_2, linear_v29_2, linear_k29_2, linear_g80, linear_l29_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k29_2 ++ (34 :: 58 :: (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))))) linear_k29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail)))) (linear_v29_3 ++ (125 :: tail)) tail linear_r32 linear_l29_3 (mutated_kp29_2 (linear_b32 ++ (44 :: (linear_v29_3 ++ (125 :: tail))))) (mutated_p32 (44 :: (linear_v29_3 ++ (125 :: tail)))) (mutated_pl29_3 tail))
def linear_l29_1 : List (List Nat × Raw) := (linear_k29_1, linear_r31) :: linear_l29_2
def linear_v29_1 : List Nat := (linear_g77 ++ linear_b31) ++ (44 :: linear_v29_2)
theorem mutated_sl29_1 : serializeFields 4081 27 linear_l29_1 = some linear_v29_1 := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k29_1 linear_r31 (linear_k29_2, linear_r32) linear_l29_3 linear_b31 linear_v29_2 mutated_kd29_1 mutated_s31 mutated_sl29_2)
theorem mutated_pl29_1 (tail : List Nat) : parseFields 4081 27 (linear_v29_1 ++ (125 :: tail)) = some (linear_l29_1, tail) := by
  simpa only [linear_l29_1, linear_v29_1, linear_k29_1, linear_g77, linear_l29_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k29_1 ++ (34 :: 58 :: (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))))) linear_k29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail)))) (linear_v29_2 ++ (125 :: tail)) tail linear_r31 linear_l29_2 (mutated_kp29_1 (linear_b31 ++ (44 :: (linear_v29_2 ++ (125 :: tail))))) (mutated_p31 (44 :: (linear_v29_2 ++ (125 :: tail)))) (mutated_pl29_2 tail))
def linear_l29_0 : List (List Nat × Raw) := (linear_k29_0, linear_r30) :: linear_l29_1
def linear_v29_0 : List Nat := (linear_g74 ++ linear_b30) ++ (44 :: linear_v29_1)
theorem mutated_sl29_0 : serializeFields 4082 27 linear_l29_0 = some linear_v29_0 := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k29_0 linear_r30 (linear_k29_1, linear_r31) linear_l29_2 linear_b30 linear_v29_1 mutated_kd29_0 mutated_s30 mutated_sl29_1)
theorem mutated_pl29_0 (tail : List Nat) : parseFields 4082 27 (linear_v29_0 ++ (125 :: tail)) = some (linear_l29_0, tail) := by
  simpa only [linear_l29_0, linear_v29_0, linear_k29_0, linear_g74, linear_l29_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) linear_k29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))) (linear_v29_1 ++ (125 :: tail)) tail linear_r30 linear_l29_1 (mutated_kp29_0 (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail))))) (mutated_p30 (44 :: (linear_v29_1 ++ (125 :: tail)))) (mutated_pl29_1 tail))
def linear_r29 : Raw := (.obj linear_l29_0)
def linear_b29 : List Nat := linear_g73 ++ (linear_v29_0 ++ linear_g85)
theorem mutated_o29 : orderedFields linear_l29_0 = true := by decide +kernel
theorem mutated_s29 : serializeRaw 4083 28 linear_r29 = some linear_b29 := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4082 27 linear_l29_0 linear_v29_0 mutated_o29 mutated_sl29_0)
theorem mutated_p29 (tail : List Nat) : parseRaw 4083 28 (linear_b29 ++ tail) = some (linear_r29, tail) := by
  simpa only [linear_r29, linear_b29, linear_g73, linear_g85, linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4082 27 (linear_k29_0 ++ (34 :: 58 :: (linear_b30 ++ (44 :: (linear_v29_1 ++ (125 :: tail)))))) tail linear_l29_0 mutated_o29 (by simpa only [linear_v29_0, linear_k29_0, linear_g74, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl29_0 tail)))
def linear_r35 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,53])
def linear_b35 : List Nat := linear_g89
theorem mutated_s35 : serializeRaw 4080 27 linear_r35 = some linear_b35 := by decide +kernel
theorem mutated_p35 (tail : List Nat) : parseRaw 4080 27 (linear_b35 ++ tail) = some (linear_r35, tail) := by rfl
def linear_r36 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,51,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,49])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b36 : List Nat := linear_g92
theorem mutated_s36 : serializeRaw 4079 27 linear_r36 = some linear_b36 := by decide +kernel
theorem mutated_p36 (tail : List Nat) : parseRaw 4079 27 (linear_b36 ++ tail) = some (linear_r36, tail) := by rfl
def linear_r37 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b37 : List Nat := linear_g95
theorem mutated_s37 : serializeRaw 4078 27 linear_r37 = some linear_b37 := by decide +kernel
theorem mutated_p37 (tail : List Nat) : parseRaw 4078 27 (linear_b37 ++ tail) = some (linear_r37, tail) := by rfl
def linear_r38 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,52,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,54]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51,53]),(.str [100,103,95,118,95,51,54]),(.str [100,103,95,118,95,51,55]),(.str [100,103,95,118,95,51,56]),(.str [100,103,95,118,95,51,57]),(.str [100,103,95,118,95,52,48]),(.str [100,103,95,118,95,52,50])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,49]))]))])
def linear_b38 : List Nat := linear_g98
theorem mutated_s38 : serializeRaw 4077 27 linear_r38 = some linear_b38 := by decide +kernel
theorem mutated_p38 (tail : List Nat) : parseRaw 4077 27 (linear_b38 ++ tail) = some (linear_r38, tail) := by rfl
def linear_k34_0 : List Nat := [105,100]
theorem mutated_kd34_0 : stringBytes linear_k34_0 = true := by decide +kernel
theorem mutated_kp34_0 (tail : List Nat) : parseStringTail (linear_k34_0 ++ (34 :: 58 :: tail)) [] = some (linear_k34_0, 58 :: tail) := by rfl
def linear_k34_1 : List Nat := [111,112,115]
theorem mutated_kd34_1 : stringBytes linear_k34_1 = true := by decide +kernel
theorem mutated_kp34_1 (tail : List Nat) : parseStringTail (linear_k34_1 ++ (34 :: 58 :: tail)) [] = some (linear_k34_1, 58 :: tail) := by rfl
def linear_k34_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd34_2 : stringBytes linear_k34_2 = true := by decide +kernel
theorem mutated_kp34_2 (tail : List Nat) : parseStringTail (linear_k34_2 ++ (34 :: 58 :: tail)) [] = some (linear_k34_2, 58 :: tail) := by rfl
def linear_k34_3 : List Nat := [116,101,114,109]
theorem mutated_kd34_3 : stringBytes linear_k34_3 = true := by decide +kernel
theorem mutated_kp34_3 (tail : List Nat) : parseStringTail (linear_k34_3 ++ (34 :: 58 :: tail)) [] = some (linear_k34_3, 58 :: tail) := by rfl
def linear_l34_3 : List (List Nat × Raw) := [(linear_k34_3, linear_r38)]
def linear_v34_3 : List Nat := linear_g97 ++ linear_b38
theorem mutated_sl34_3 : serializeFields 4078 27 linear_l34_3 = some linear_v34_3 := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4077 27 linear_k34_3 linear_r38 linear_b38 mutated_kd34_3 mutated_s38)
theorem mutated_pl34_3 (tail : List Nat) : parseFields 4078 27 (linear_v34_3 ++ (125 :: tail)) = some (linear_l34_3, tail) := by
  simpa only [linear_l34_3, linear_v34_3, linear_k34_3, linear_g97, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4077 27 (linear_k34_3 ++ (34 :: 58 :: (linear_b38 ++ (125 :: tail)))) linear_k34_3 (linear_b38 ++ (125 :: tail)) tail linear_r38 (mutated_kp34_3 (linear_b38 ++ (125 :: tail))) (mutated_p38 (125 :: tail)))
def linear_l34_2 : List (List Nat × Raw) := (linear_k34_2, linear_r37) :: linear_l34_3
def linear_v34_2 : List Nat := (linear_g94 ++ linear_b37) ++ (44 :: linear_v34_3)
theorem mutated_sl34_2 : serializeFields 4079 27 linear_l34_2 = some linear_v34_2 := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k34_2 linear_r37 (linear_k34_3, linear_r38) [] linear_b37 linear_v34_3 mutated_kd34_2 mutated_s37 mutated_sl34_3)
theorem mutated_pl34_2 (tail : List Nat) : parseFields 4079 27 (linear_v34_2 ++ (125 :: tail)) = some (linear_l34_2, tail) := by
  simpa only [linear_l34_2, linear_v34_2, linear_k34_2, linear_g94, linear_l34_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k34_2 ++ (34 :: 58 :: (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))))) linear_k34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail)))) (linear_v34_3 ++ (125 :: tail)) tail linear_r37 linear_l34_3 (mutated_kp34_2 (linear_b37 ++ (44 :: (linear_v34_3 ++ (125 :: tail))))) (mutated_p37 (44 :: (linear_v34_3 ++ (125 :: tail)))) (mutated_pl34_3 tail))
def linear_l34_1 : List (List Nat × Raw) := (linear_k34_1, linear_r36) :: linear_l34_2
def linear_v34_1 : List Nat := (linear_g91 ++ linear_b36) ++ (44 :: linear_v34_2)
theorem mutated_sl34_1 : serializeFields 4080 27 linear_l34_1 = some linear_v34_1 := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k34_1 linear_r36 (linear_k34_2, linear_r37) linear_l34_3 linear_b36 linear_v34_2 mutated_kd34_1 mutated_s36 mutated_sl34_2)
theorem mutated_pl34_1 (tail : List Nat) : parseFields 4080 27 (linear_v34_1 ++ (125 :: tail)) = some (linear_l34_1, tail) := by
  simpa only [linear_l34_1, linear_v34_1, linear_k34_1, linear_g91, linear_l34_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k34_1 ++ (34 :: 58 :: (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))))) linear_k34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail)))) (linear_v34_2 ++ (125 :: tail)) tail linear_r36 linear_l34_2 (mutated_kp34_1 (linear_b36 ++ (44 :: (linear_v34_2 ++ (125 :: tail))))) (mutated_p36 (44 :: (linear_v34_2 ++ (125 :: tail)))) (mutated_pl34_2 tail))
def linear_l34_0 : List (List Nat × Raw) := (linear_k34_0, linear_r35) :: linear_l34_1
def linear_v34_0 : List Nat := (linear_g88 ++ linear_b35) ++ (44 :: linear_v34_1)
theorem mutated_sl34_0 : serializeFields 4081 27 linear_l34_0 = some linear_v34_0 := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k34_0 linear_r35 (linear_k34_1, linear_r36) linear_l34_2 linear_b35 linear_v34_1 mutated_kd34_0 mutated_s35 mutated_sl34_1)
theorem mutated_pl34_0 (tail : List Nat) : parseFields 4081 27 (linear_v34_0 ++ (125 :: tail)) = some (linear_l34_0, tail) := by
  simpa only [linear_l34_0, linear_v34_0, linear_k34_0, linear_g88, linear_l34_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) linear_k34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))) (linear_v34_1 ++ (125 :: tail)) tail linear_r35 linear_l34_1 (mutated_kp34_0 (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail))))) (mutated_p35 (44 :: (linear_v34_1 ++ (125 :: tail)))) (mutated_pl34_1 tail))
def linear_r34 : Raw := (.obj linear_l34_0)
def linear_b34 : List Nat := linear_g87 ++ (linear_v34_0 ++ linear_g99)
theorem mutated_o34 : orderedFields linear_l34_0 = true := by decide +kernel
theorem mutated_s34 : serializeRaw 4082 28 linear_r34 = some linear_b34 := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4081 27 linear_l34_0 linear_v34_0 mutated_o34 mutated_sl34_0)
theorem mutated_p34 (tail : List Nat) : parseRaw 4082 28 (linear_b34 ++ tail) = some (linear_r34, tail) := by
  simpa only [linear_r34, linear_b34, linear_g87, linear_g99, linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4081 27 (linear_k34_0 ++ (34 :: 58 :: (linear_b35 ++ (44 :: (linear_v34_1 ++ (125 :: tail)))))) tail linear_l34_0 mutated_o34 (by simpa only [linear_v34_0, linear_k34_0, linear_g88, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl34_0 tail)))
def linear_r40 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,54])
def linear_b40 : List Nat := linear_g103
theorem mutated_s40 : serializeRaw 4079 27 linear_r40 = some linear_b40 := by decide +kernel
theorem mutated_p40 (tail : List Nat) : parseRaw 4079 27 (linear_b40 ++ tail) = some (linear_r40, tail) := by rfl
def linear_r41 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,52,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b41 : List Nat := linear_g106
theorem mutated_s41 : serializeRaw 4078 27 linear_r41 = some linear_b41 := by decide +kernel
theorem mutated_p41 (tail : List Nat) : parseRaw 4078 27 (linear_b41 ++ tail) = some (linear_r41, tail) := by rfl
def linear_r42 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,53])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,54])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b42 : List Nat := linear_g109
theorem mutated_s42 : serializeRaw 4077 27 linear_r42 = some linear_b42 := by decide +kernel
theorem mutated_p42 (tail : List Nat) : parseRaw 4077 27 (linear_b42 ++ tail) = some (linear_r42, tail) := by rfl
def linear_r43 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,52,54])]))])
def linear_b43 : List Nat := linear_g112
theorem mutated_s43 : serializeRaw 4076 27 linear_r43 = some linear_b43 := by decide +kernel
theorem mutated_p43 (tail : List Nat) : parseRaw 4076 27 (linear_b43 ++ tail) = some (linear_r43, tail) := by rfl
def linear_k39_0 : List Nat := [105,100]
theorem mutated_kd39_0 : stringBytes linear_k39_0 = true := by decide +kernel
theorem mutated_kp39_0 (tail : List Nat) : parseStringTail (linear_k39_0 ++ (34 :: 58 :: tail)) [] = some (linear_k39_0, 58 :: tail) := by rfl
def linear_k39_1 : List Nat := [111,112,115]
theorem mutated_kd39_1 : stringBytes linear_k39_1 = true := by decide +kernel
theorem mutated_kp39_1 (tail : List Nat) : parseStringTail (linear_k39_1 ++ (34 :: 58 :: tail)) [] = some (linear_k39_1, 58 :: tail) := by rfl
def linear_k39_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd39_2 : stringBytes linear_k39_2 = true := by decide +kernel
theorem mutated_kp39_2 (tail : List Nat) : parseStringTail (linear_k39_2 ++ (34 :: 58 :: tail)) [] = some (linear_k39_2, 58 :: tail) := by rfl
def linear_k39_3 : List Nat := [116,101,114,109]
theorem mutated_kd39_3 : stringBytes linear_k39_3 = true := by decide +kernel
theorem mutated_kp39_3 (tail : List Nat) : parseStringTail (linear_k39_3 ++ (34 :: 58 :: tail)) [] = some (linear_k39_3, 58 :: tail) := by rfl
def linear_l39_3 : List (List Nat × Raw) := [(linear_k39_3, linear_r43)]
def linear_v39_3 : List Nat := linear_g111 ++ linear_b43
theorem mutated_sl39_3 : serializeFields 4077 27 linear_l39_3 = some linear_v39_3 := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4076 27 linear_k39_3 linear_r43 linear_b43 mutated_kd39_3 mutated_s43)
theorem mutated_pl39_3 (tail : List Nat) : parseFields 4077 27 (linear_v39_3 ++ (125 :: tail)) = some (linear_l39_3, tail) := by
  simpa only [linear_l39_3, linear_v39_3, linear_k39_3, linear_g111, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4076 27 (linear_k39_3 ++ (34 :: 58 :: (linear_b43 ++ (125 :: tail)))) linear_k39_3 (linear_b43 ++ (125 :: tail)) tail linear_r43 (mutated_kp39_3 (linear_b43 ++ (125 :: tail))) (mutated_p43 (125 :: tail)))
def linear_l39_2 : List (List Nat × Raw) := (linear_k39_2, linear_r42) :: linear_l39_3
def linear_v39_2 : List Nat := (linear_g108 ++ linear_b42) ++ (44 :: linear_v39_3)
theorem mutated_sl39_2 : serializeFields 4078 27 linear_l39_2 = some linear_v39_2 := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k39_2 linear_r42 (linear_k39_3, linear_r43) [] linear_b42 linear_v39_3 mutated_kd39_2 mutated_s42 mutated_sl39_3)
theorem mutated_pl39_2 (tail : List Nat) : parseFields 4078 27 (linear_v39_2 ++ (125 :: tail)) = some (linear_l39_2, tail) := by
  simpa only [linear_l39_2, linear_v39_2, linear_k39_2, linear_g108, linear_l39_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k39_2 ++ (34 :: 58 :: (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))))) linear_k39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail)))) (linear_v39_3 ++ (125 :: tail)) tail linear_r42 linear_l39_3 (mutated_kp39_2 (linear_b42 ++ (44 :: (linear_v39_3 ++ (125 :: tail))))) (mutated_p42 (44 :: (linear_v39_3 ++ (125 :: tail)))) (mutated_pl39_3 tail))
def linear_l39_1 : List (List Nat × Raw) := (linear_k39_1, linear_r41) :: linear_l39_2
def linear_v39_1 : List Nat := (linear_g105 ++ linear_b41) ++ (44 :: linear_v39_2)
theorem mutated_sl39_1 : serializeFields 4079 27 linear_l39_1 = some linear_v39_1 := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k39_1 linear_r41 (linear_k39_2, linear_r42) linear_l39_3 linear_b41 linear_v39_2 mutated_kd39_1 mutated_s41 mutated_sl39_2)
theorem mutated_pl39_1 (tail : List Nat) : parseFields 4079 27 (linear_v39_1 ++ (125 :: tail)) = some (linear_l39_1, tail) := by
  simpa only [linear_l39_1, linear_v39_1, linear_k39_1, linear_g105, linear_l39_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k39_1 ++ (34 :: 58 :: (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))))) linear_k39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail)))) (linear_v39_2 ++ (125 :: tail)) tail linear_r41 linear_l39_2 (mutated_kp39_1 (linear_b41 ++ (44 :: (linear_v39_2 ++ (125 :: tail))))) (mutated_p41 (44 :: (linear_v39_2 ++ (125 :: tail)))) (mutated_pl39_2 tail))
def linear_l39_0 : List (List Nat × Raw) := (linear_k39_0, linear_r40) :: linear_l39_1
def linear_v39_0 : List Nat := (linear_g102 ++ linear_b40) ++ (44 :: linear_v39_1)
theorem mutated_sl39_0 : serializeFields 4080 27 linear_l39_0 = some linear_v39_0 := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4079 27 linear_k39_0 linear_r40 (linear_k39_1, linear_r41) linear_l39_2 linear_b40 linear_v39_1 mutated_kd39_0 mutated_s40 mutated_sl39_1)
theorem mutated_pl39_0 (tail : List Nat) : parseFields 4080 27 (linear_v39_0 ++ (125 :: tail)) = some (linear_l39_0, tail) := by
  simpa only [linear_l39_0, linear_v39_0, linear_k39_0, linear_g102, linear_l39_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4079 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) linear_k39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))) (linear_v39_1 ++ (125 :: tail)) tail linear_r40 linear_l39_1 (mutated_kp39_0 (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail))))) (mutated_p40 (44 :: (linear_v39_1 ++ (125 :: tail)))) (mutated_pl39_1 tail))
def linear_r39 : Raw := (.obj linear_l39_0)
def linear_b39 : List Nat := linear_g101 ++ (linear_v39_0 ++ linear_g113)
theorem mutated_o39 : orderedFields linear_l39_0 = true := by decide +kernel
theorem mutated_s39 : serializeRaw 4081 28 linear_r39 = some linear_b39 := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4080 27 linear_l39_0 linear_v39_0 mutated_o39 mutated_sl39_0)
theorem mutated_p39 (tail : List Nat) : parseRaw 4081 28 (linear_b39 ++ tail) = some (linear_r39, tail) := by
  simpa only [linear_r39, linear_b39, linear_g101, linear_g113, linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4080 27 (linear_k39_0 ++ (34 :: 58 :: (linear_b40 ++ (44 :: (linear_v39_1 ++ (125 :: tail)))))) tail linear_l39_0 mutated_o39 (by simpa only [linear_v39_0, linear_k39_0, linear_g102, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl39_0 tail)))
def linear_r45 : Raw := (.str [100,103,95,102,97,115,116,95,48])
def linear_b45 : List Nat := linear_g117
theorem mutated_s45 : serializeRaw 4078 27 linear_r45 = some linear_b45 := by decide +kernel
theorem mutated_p45 (tail : List Nat) : parseRaw 4078 27 (linear_b45 ++ tail) = some (linear_r45, tail) := by rfl
def linear_r46 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,53]),(.str [100,103,95,118,95,53,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,54])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b46 : List Nat := linear_g120
theorem mutated_s46 : serializeRaw 4077 27 linear_r46 = some linear_b46 := by decide +kernel
theorem mutated_p46 (tail : List Nat) : parseRaw 4077 27 (linear_b46 ++ tail) = some (linear_r46, tail) := by rfl
def linear_r47 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b47 : List Nat := linear_g123
theorem mutated_s47 : serializeRaw 4076 27 linear_r47 = some linear_b47 := by decide +kernel
theorem mutated_p47 (tail : List Nat) : parseRaw 4076 27 (linear_b47 ++ tail) = some (linear_r47, tail) := by rfl
def linear_r48 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,53,54])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,53])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,49]),(.str [100,103,95,118,95,53,50]),(.str [100,103,95,118,95,53,51]),(.str [100,103,95,118,95,53,52]),(.str [100,103,95,118,95,53,52])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b48 : List Nat := linear_g126
theorem mutated_s48 : serializeRaw 4075 27 linear_r48 = some linear_b48 := by decide +kernel
theorem mutated_p48 (tail : List Nat) : parseRaw 4075 27 (linear_b48 ++ tail) = some (linear_r48, tail) := by rfl
def linear_k44_0 : List Nat := [105,100]
theorem mutated_kd44_0 : stringBytes linear_k44_0 = true := by decide +kernel
theorem mutated_kp44_0 (tail : List Nat) : parseStringTail (linear_k44_0 ++ (34 :: 58 :: tail)) [] = some (linear_k44_0, 58 :: tail) := by rfl
def linear_k44_1 : List Nat := [111,112,115]
theorem mutated_kd44_1 : stringBytes linear_k44_1 = true := by decide +kernel
theorem mutated_kp44_1 (tail : List Nat) : parseStringTail (linear_k44_1 ++ (34 :: 58 :: tail)) [] = some (linear_k44_1, 58 :: tail) := by rfl
def linear_k44_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd44_2 : stringBytes linear_k44_2 = true := by decide +kernel
theorem mutated_kp44_2 (tail : List Nat) : parseStringTail (linear_k44_2 ++ (34 :: 58 :: tail)) [] = some (linear_k44_2, 58 :: tail) := by rfl
def linear_k44_3 : List Nat := [116,101,114,109]
theorem mutated_kd44_3 : stringBytes linear_k44_3 = true := by decide +kernel
theorem mutated_kp44_3 (tail : List Nat) : parseStringTail (linear_k44_3 ++ (34 :: 58 :: tail)) [] = some (linear_k44_3, 58 :: tail) := by rfl
def linear_l44_3 : List (List Nat × Raw) := [(linear_k44_3, linear_r48)]
def linear_v44_3 : List Nat := linear_g125 ++ linear_b48
theorem mutated_sl44_3 : serializeFields 4076 27 linear_l44_3 = some linear_v44_3 := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4075 27 linear_k44_3 linear_r48 linear_b48 mutated_kd44_3 mutated_s48)
theorem mutated_pl44_3 (tail : List Nat) : parseFields 4076 27 (linear_v44_3 ++ (125 :: tail)) = some (linear_l44_3, tail) := by
  simpa only [linear_l44_3, linear_v44_3, linear_k44_3, linear_g125, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4075 27 (linear_k44_3 ++ (34 :: 58 :: (linear_b48 ++ (125 :: tail)))) linear_k44_3 (linear_b48 ++ (125 :: tail)) tail linear_r48 (mutated_kp44_3 (linear_b48 ++ (125 :: tail))) (mutated_p48 (125 :: tail)))
def linear_l44_2 : List (List Nat × Raw) := (linear_k44_2, linear_r47) :: linear_l44_3
def linear_v44_2 : List Nat := (linear_g122 ++ linear_b47) ++ (44 :: linear_v44_3)
theorem mutated_sl44_2 : serializeFields 4077 27 linear_l44_2 = some linear_v44_2 := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k44_2 linear_r47 (linear_k44_3, linear_r48) [] linear_b47 linear_v44_3 mutated_kd44_2 mutated_s47 mutated_sl44_3)
theorem mutated_pl44_2 (tail : List Nat) : parseFields 4077 27 (linear_v44_2 ++ (125 :: tail)) = some (linear_l44_2, tail) := by
  simpa only [linear_l44_2, linear_v44_2, linear_k44_2, linear_g122, linear_l44_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k44_2 ++ (34 :: 58 :: (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))))) linear_k44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail)))) (linear_v44_3 ++ (125 :: tail)) tail linear_r47 linear_l44_3 (mutated_kp44_2 (linear_b47 ++ (44 :: (linear_v44_3 ++ (125 :: tail))))) (mutated_p47 (44 :: (linear_v44_3 ++ (125 :: tail)))) (mutated_pl44_3 tail))
def linear_l44_1 : List (List Nat × Raw) := (linear_k44_1, linear_r46) :: linear_l44_2
def linear_v44_1 : List Nat := (linear_g119 ++ linear_b46) ++ (44 :: linear_v44_2)
theorem mutated_sl44_1 : serializeFields 4078 27 linear_l44_1 = some linear_v44_1 := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k44_1 linear_r46 (linear_k44_2, linear_r47) linear_l44_3 linear_b46 linear_v44_2 mutated_kd44_1 mutated_s46 mutated_sl44_2)
theorem mutated_pl44_1 (tail : List Nat) : parseFields 4078 27 (linear_v44_1 ++ (125 :: tail)) = some (linear_l44_1, tail) := by
  simpa only [linear_l44_1, linear_v44_1, linear_k44_1, linear_g119, linear_l44_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k44_1 ++ (34 :: 58 :: (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))))) linear_k44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail)))) (linear_v44_2 ++ (125 :: tail)) tail linear_r46 linear_l44_2 (mutated_kp44_1 (linear_b46 ++ (44 :: (linear_v44_2 ++ (125 :: tail))))) (mutated_p46 (44 :: (linear_v44_2 ++ (125 :: tail)))) (mutated_pl44_2 tail))
def linear_l44_0 : List (List Nat × Raw) := (linear_k44_0, linear_r45) :: linear_l44_1
def linear_v44_0 : List Nat := (linear_g116 ++ linear_b45) ++ (44 :: linear_v44_1)
theorem mutated_sl44_0 : serializeFields 4079 27 linear_l44_0 = some linear_v44_0 := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4078 27 linear_k44_0 linear_r45 (linear_k44_1, linear_r46) linear_l44_2 linear_b45 linear_v44_1 mutated_kd44_0 mutated_s45 mutated_sl44_1)
theorem mutated_pl44_0 (tail : List Nat) : parseFields 4079 27 (linear_v44_0 ++ (125 :: tail)) = some (linear_l44_0, tail) := by
  simpa only [linear_l44_0, linear_v44_0, linear_k44_0, linear_g116, linear_l44_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4078 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) linear_k44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))) (linear_v44_1 ++ (125 :: tail)) tail linear_r45 linear_l44_1 (mutated_kp44_0 (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail))))) (mutated_p45 (44 :: (linear_v44_1 ++ (125 :: tail)))) (mutated_pl44_1 tail))
def linear_r44 : Raw := (.obj linear_l44_0)
def linear_b44 : List Nat := linear_g115 ++ (linear_v44_0 ++ linear_g127)
theorem mutated_o44 : orderedFields linear_l44_0 = true := by decide +kernel
theorem mutated_s44 : serializeRaw 4080 28 linear_r44 = some linear_b44 := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4079 27 linear_l44_0 linear_v44_0 mutated_o44 mutated_sl44_0)
theorem mutated_p44 (tail : List Nat) : parseRaw 4080 28 (linear_b44 ++ tail) = some (linear_r44, tail) := by
  simpa only [linear_r44, linear_b44, linear_g115, linear_g127, linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4079 27 (linear_k44_0 ++ (34 :: 58 :: (linear_b45 ++ (44 :: (linear_v44_1 ++ (125 :: tail)))))) tail linear_l44_0 mutated_o44 (by simpa only [linear_v44_0, linear_k44_0, linear_g116, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl44_0 tail)))
def linear_r50 : Raw := (.str [100,103,95,102,97,115,116,95,49])
def linear_b50 : List Nat := linear_g131
theorem mutated_s50 : serializeRaw 4077 27 linear_r50 = some linear_b50 := by decide +kernel
theorem mutated_p50 (tail : List Nat) : parseRaw 4077 27 (linear_b50 ++ tail) = some (linear_r50, tail) := by rfl
def linear_r52 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,50])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b52 : List Nat := linear_g135
theorem mutated_s52 : serializeRaw 4074 26 linear_r52 = some linear_b52 := by decide +kernel
theorem mutated_p52 (tail : List Nat) : parseRaw 4074 26 (linear_b52 ++ tail) = some (linear_r52, tail) := by rfl
def linear_r53 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,50]),(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,51])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b53 : List Nat := linear_g137
theorem mutated_s53 : serializeRaw 4073 26 linear_r53 = some linear_b53 := by decide +kernel
theorem mutated_p53 (tail : List Nat) : parseRaw 4073 26 (linear_b53 ++ tail) = some (linear_r53, tail) := by rfl
def linear_r54 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,52])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b54 : List Nat := linear_g139
theorem mutated_s54 : serializeRaw 4072 26 linear_r54 = some linear_b54 := by decide +kernel
theorem mutated_p54 (tail : List Nat) : parseRaw 4072 26 (linear_b54 ++ tail) = some (linear_r54, tail) := by rfl
def linear_r55 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,56])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b55 : List Nat := linear_g141
theorem mutated_s55 : serializeRaw 4071 26 linear_r55 = some linear_b55 := by decide +kernel
theorem mutated_p55 (tail : List Nat) : parseRaw 4071 26 (linear_b55 ++ tail) = some (linear_r55, tail) := by rfl
def linear_r56 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,52]),(.str [100,103,95,118,95,54,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,54])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b56 : List Nat := linear_g143
theorem mutated_s56 : serializeRaw 4070 26 linear_r56 = some linear_b56 := by decide +kernel
theorem mutated_p56 (tail : List Nat) : parseRaw 4070 26 (linear_b56 ++ tail) = some (linear_r56, tail) := by rfl
def linear_r57 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,54])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b57 : List Nat := linear_g145
theorem mutated_s57 : serializeRaw 4069 26 linear_r57 = some linear_b57 := by decide +kernel
theorem mutated_p57 (tail : List Nat) : parseRaw 4069 26 (linear_b57 ++ tail) = some (linear_r57, tail) := by rfl
def linear_r58 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,56])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b58 : List Nat := linear_g147
theorem mutated_s58 : serializeRaw 4068 26 linear_r58 = some linear_b58 := by decide +kernel
theorem mutated_p58 (tail : List Nat) : parseRaw 4068 26 (linear_b58 ++ tail) = some (linear_r58, tail) := by rfl
def linear_r59 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56]),(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b59 : List Nat := linear_g149
theorem mutated_s59 : serializeRaw 4067 26 linear_r59 = some linear_b59 := by decide +kernel
theorem mutated_p59 (tail : List Nat) : parseRaw 4067 26 (linear_b59 ++ tail) = some (linear_r59, tail) := by rfl
def linear_r60 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b60 : List Nat := linear_g151
theorem mutated_s60 : serializeRaw 4066 26 linear_r60 = some linear_b60 := by decide +kernel
theorem mutated_p60 (tail : List Nat) : parseRaw 4066 26 (linear_b60 ++ tail) = some (linear_r60, tail) := by rfl
def linear_r61 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b61 : List Nat := linear_g153
theorem mutated_s61 : serializeRaw 4065 26 linear_r61 = some linear_b61 := by decide +kernel
theorem mutated_p61 (tail : List Nat) : parseRaw 4065 26 (linear_b61 ++ tail) = some (linear_r61, tail) := by rfl
def linear_r62 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54,49]),(.str [100,103,95,118,95,54,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b62 : List Nat := linear_g155
theorem mutated_s62 : serializeRaw 4064 26 linear_r62 = some linear_b62 := by decide +kernel
theorem mutated_p62 (tail : List Nat) : parseRaw 4064 26 (linear_b62 ++ tail) = some (linear_r62, tail) := by rfl
def linear_l51_10 : List Raw := [linear_r62]
def linear_v51_10 : List Nat := linear_b62
theorem mutated_sl51_10 : serializeItems 4065 26 linear_l51_10 = some linear_v51_10 := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4064 26 linear_r62 linear_b62 mutated_s62)
theorem mutated_pl51_10 (tail : List Nat) : parseItems 4065 26 (linear_v51_10 ++ (93 :: tail)) = some (linear_l51_10, tail) := by
  simpa only [linear_l51_10, linear_v51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4064 26 (linear_b62 ++ (93 :: tail)) tail linear_r62 (mutated_p62 (93 :: tail)))
def linear_l51_9 : List Raw := linear_r61 :: linear_l51_10
def linear_v51_9 : List Nat := (linear_b61) ++ (44 :: linear_v51_10)
theorem mutated_sl51_9 : serializeItems 4066 26 linear_l51_9 = some linear_v51_9 := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r61 linear_r62 [] linear_b61 linear_v51_10 mutated_s61 mutated_sl51_10)
theorem mutated_pl51_9 (tail : List Nat) : parseItems 4066 26 (linear_v51_9 ++ (93 :: tail)) = some (linear_l51_9, tail) := by
  simpa only [linear_l51_9, linear_v51_9, linear_l51_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b61 ++ (44 :: (linear_v51_10 ++ (93 :: tail)))) (linear_v51_10 ++ (93 :: tail)) tail linear_r61 linear_l51_10 (mutated_p61 (44 :: (linear_v51_10 ++ (93 :: tail)))) (mutated_pl51_10 tail))
def linear_l51_8 : List Raw := linear_r60 :: linear_l51_9
def linear_v51_8 : List Nat := (linear_b60) ++ (44 :: linear_v51_9)
theorem mutated_sl51_8 : serializeItems 4067 26 linear_l51_8 = some linear_v51_8 := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r60 linear_r61 linear_l51_10 linear_b60 linear_v51_9 mutated_s60 mutated_sl51_9)
theorem mutated_pl51_8 (tail : List Nat) : parseItems 4067 26 (linear_v51_8 ++ (93 :: tail)) = some (linear_l51_8, tail) := by
  simpa only [linear_l51_8, linear_v51_8, linear_l51_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b60 ++ (44 :: (linear_v51_9 ++ (93 :: tail)))) (linear_v51_9 ++ (93 :: tail)) tail linear_r60 linear_l51_9 (mutated_p60 (44 :: (linear_v51_9 ++ (93 :: tail)))) (mutated_pl51_9 tail))
def linear_l51_7 : List Raw := linear_r59 :: linear_l51_8
def linear_v51_7 : List Nat := (linear_b59) ++ (44 :: linear_v51_8)
theorem mutated_sl51_7 : serializeItems 4068 26 linear_l51_7 = some linear_v51_7 := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r59 linear_r60 linear_l51_9 linear_b59 linear_v51_8 mutated_s59 mutated_sl51_8)
theorem mutated_pl51_7 (tail : List Nat) : parseItems 4068 26 (linear_v51_7 ++ (93 :: tail)) = some (linear_l51_7, tail) := by
  simpa only [linear_l51_7, linear_v51_7, linear_l51_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b59 ++ (44 :: (linear_v51_8 ++ (93 :: tail)))) (linear_v51_8 ++ (93 :: tail)) tail linear_r59 linear_l51_8 (mutated_p59 (44 :: (linear_v51_8 ++ (93 :: tail)))) (mutated_pl51_8 tail))
def linear_l51_6 : List Raw := linear_r58 :: linear_l51_7
def linear_v51_6 : List Nat := (linear_b58) ++ (44 :: linear_v51_7)
theorem mutated_sl51_6 : serializeItems 4069 26 linear_l51_6 = some linear_v51_6 := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r58 linear_r59 linear_l51_8 linear_b58 linear_v51_7 mutated_s58 mutated_sl51_7)
theorem mutated_pl51_6 (tail : List Nat) : parseItems 4069 26 (linear_v51_6 ++ (93 :: tail)) = some (linear_l51_6, tail) := by
  simpa only [linear_l51_6, linear_v51_6, linear_l51_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b58 ++ (44 :: (linear_v51_7 ++ (93 :: tail)))) (linear_v51_7 ++ (93 :: tail)) tail linear_r58 linear_l51_7 (mutated_p58 (44 :: (linear_v51_7 ++ (93 :: tail)))) (mutated_pl51_7 tail))
def linear_l51_5 : List Raw := linear_r57 :: linear_l51_6
def linear_v51_5 : List Nat := (linear_b57) ++ (44 :: linear_v51_6)
theorem mutated_sl51_5 : serializeItems 4070 26 linear_l51_5 = some linear_v51_5 := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r57 linear_r58 linear_l51_7 linear_b57 linear_v51_6 mutated_s57 mutated_sl51_6)
theorem mutated_pl51_5 (tail : List Nat) : parseItems 4070 26 (linear_v51_5 ++ (93 :: tail)) = some (linear_l51_5, tail) := by
  simpa only [linear_l51_5, linear_v51_5, linear_l51_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b57 ++ (44 :: (linear_v51_6 ++ (93 :: tail)))) (linear_v51_6 ++ (93 :: tail)) tail linear_r57 linear_l51_6 (mutated_p57 (44 :: (linear_v51_6 ++ (93 :: tail)))) (mutated_pl51_6 tail))
def linear_l51_4 : List Raw := linear_r56 :: linear_l51_5
def linear_v51_4 : List Nat := (linear_b56) ++ (44 :: linear_v51_5)
theorem mutated_sl51_4 : serializeItems 4071 26 linear_l51_4 = some linear_v51_4 := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r56 linear_r57 linear_l51_6 linear_b56 linear_v51_5 mutated_s56 mutated_sl51_5)
theorem mutated_pl51_4 (tail : List Nat) : parseItems 4071 26 (linear_v51_4 ++ (93 :: tail)) = some (linear_l51_4, tail) := by
  simpa only [linear_l51_4, linear_v51_4, linear_l51_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b56 ++ (44 :: (linear_v51_5 ++ (93 :: tail)))) (linear_v51_5 ++ (93 :: tail)) tail linear_r56 linear_l51_5 (mutated_p56 (44 :: (linear_v51_5 ++ (93 :: tail)))) (mutated_pl51_5 tail))
def linear_l51_3 : List Raw := linear_r55 :: linear_l51_4
def linear_v51_3 : List Nat := (linear_b55) ++ (44 :: linear_v51_4)
theorem mutated_sl51_3 : serializeItems 4072 26 linear_l51_3 = some linear_v51_3 := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r55 linear_r56 linear_l51_5 linear_b55 linear_v51_4 mutated_s55 mutated_sl51_4)
theorem mutated_pl51_3 (tail : List Nat) : parseItems 4072 26 (linear_v51_3 ++ (93 :: tail)) = some (linear_l51_3, tail) := by
  simpa only [linear_l51_3, linear_v51_3, linear_l51_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b55 ++ (44 :: (linear_v51_4 ++ (93 :: tail)))) (linear_v51_4 ++ (93 :: tail)) tail linear_r55 linear_l51_4 (mutated_p55 (44 :: (linear_v51_4 ++ (93 :: tail)))) (mutated_pl51_4 tail))
def linear_l51_2 : List Raw := linear_r54 :: linear_l51_3
def linear_v51_2 : List Nat := (linear_b54) ++ (44 :: linear_v51_3)
theorem mutated_sl51_2 : serializeItems 4073 26 linear_l51_2 = some linear_v51_2 := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 26 linear_r54 linear_r55 linear_l51_4 linear_b54 linear_v51_3 mutated_s54 mutated_sl51_3)
theorem mutated_pl51_2 (tail : List Nat) : parseItems 4073 26 (linear_v51_2 ++ (93 :: tail)) = some (linear_l51_2, tail) := by
  simpa only [linear_l51_2, linear_v51_2, linear_l51_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 26 (linear_b54 ++ (44 :: (linear_v51_3 ++ (93 :: tail)))) (linear_v51_3 ++ (93 :: tail)) tail linear_r54 linear_l51_3 (mutated_p54 (44 :: (linear_v51_3 ++ (93 :: tail)))) (mutated_pl51_3 tail))
def linear_l51_1 : List Raw := linear_r53 :: linear_l51_2
def linear_v51_1 : List Nat := (linear_b53) ++ (44 :: linear_v51_2)
theorem mutated_sl51_1 : serializeItems 4074 26 linear_l51_1 = some linear_v51_1 := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 26 linear_r53 linear_r54 linear_l51_3 linear_b53 linear_v51_2 mutated_s53 mutated_sl51_2)
theorem mutated_pl51_1 (tail : List Nat) : parseItems 4074 26 (linear_v51_1 ++ (93 :: tail)) = some (linear_l51_1, tail) := by
  simpa only [linear_l51_1, linear_v51_1, linear_l51_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 26 (linear_b53 ++ (44 :: (linear_v51_2 ++ (93 :: tail)))) (linear_v51_2 ++ (93 :: tail)) tail linear_r53 linear_l51_2 (mutated_p53 (44 :: (linear_v51_2 ++ (93 :: tail)))) (mutated_pl51_2 tail))
def linear_l51_0 : List Raw := linear_r52 :: linear_l51_1
def linear_v51_0 : List Nat := (linear_b52) ++ (44 :: linear_v51_1)
theorem mutated_sl51_0 : serializeItems 4075 26 linear_l51_0 = some linear_v51_0 := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 26 linear_r52 linear_r53 linear_l51_2 linear_b52 linear_v51_1 mutated_s52 mutated_sl51_1)
theorem mutated_pl51_0 (tail : List Nat) : parseItems 4075 26 (linear_v51_0 ++ (93 :: tail)) = some (linear_l51_0, tail) := by
  simpa only [linear_l51_0, linear_v51_0, linear_l51_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 26 (linear_b52 ++ (44 :: (linear_v51_1 ++ (93 :: tail)))) (linear_v51_1 ++ (93 :: tail)) tail linear_r52 linear_l51_1 (mutated_p52 (44 :: (linear_v51_1 ++ (93 :: tail)))) (mutated_pl51_1 tail))
def linear_r51 : Raw := (.arr linear_l51_0)
def linear_b51 : List Nat := linear_g134 ++ (linear_v51_0 ++ linear_g156)
theorem mutated_s51 : serializeRaw 4076 27 linear_r51 = some linear_b51 := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4075 26 linear_l51_0 linear_v51_0 mutated_sl51_0)
theorem mutated_p51 (tail : List Nat) : parseRaw 4076 27 (linear_b51 ++ tail) = some (linear_r51, tail) := by
  simpa only [linear_r51, linear_b51, linear_g134, linear_g156, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4075 26 (linear_v51_0 ++ (93 :: tail)) tail linear_l51_0 (by intro h; cases h) (mutated_pl51_0 tail))
def linear_r63 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b63 : List Nat := linear_g159
theorem mutated_s63 : serializeRaw 4075 27 linear_r63 = some linear_b63 := by decide +kernel
theorem mutated_p63 (tail : List Nat) : parseRaw 4075 27 (linear_b63 ++ tail) = some (linear_r63, tail) := by rfl
def linear_r64 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,55]),(.str [100,103,95,118,95,53,56]),(.str [100,103,95,118,95,53,57]),(.str [100,103,95,118,95,54,48]),(.str [100,103,95,118,95,55,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,48]))])
def linear_b64 : List Nat := linear_g162
theorem mutated_s64 : serializeRaw 4074 27 linear_r64 = some linear_b64 := by decide +kernel
theorem mutated_p64 (tail : List Nat) : parseRaw 4074 27 (linear_b64 ++ tail) = some (linear_r64, tail) := by rfl
def linear_k49_0 : List Nat := [105,100]
theorem mutated_kd49_0 : stringBytes linear_k49_0 = true := by decide +kernel
theorem mutated_kp49_0 (tail : List Nat) : parseStringTail (linear_k49_0 ++ (34 :: 58 :: tail)) [] = some (linear_k49_0, 58 :: tail) := by rfl
def linear_k49_1 : List Nat := [111,112,115]
theorem mutated_kd49_1 : stringBytes linear_k49_1 = true := by decide +kernel
theorem mutated_kp49_1 (tail : List Nat) : parseStringTail (linear_k49_1 ++ (34 :: 58 :: tail)) [] = some (linear_k49_1, 58 :: tail) := by rfl
def linear_k49_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd49_2 : stringBytes linear_k49_2 = true := by decide +kernel
theorem mutated_kp49_2 (tail : List Nat) : parseStringTail (linear_k49_2 ++ (34 :: 58 :: tail)) [] = some (linear_k49_2, 58 :: tail) := by rfl
def linear_k49_3 : List Nat := [116,101,114,109]
theorem mutated_kd49_3 : stringBytes linear_k49_3 = true := by decide +kernel
theorem mutated_kp49_3 (tail : List Nat) : parseStringTail (linear_k49_3 ++ (34 :: 58 :: tail)) [] = some (linear_k49_3, 58 :: tail) := by rfl
def linear_l49_3 : List (List Nat × Raw) := [(linear_k49_3, linear_r64)]
def linear_v49_3 : List Nat := linear_g161 ++ linear_b64
theorem mutated_sl49_3 : serializeFields 4075 27 linear_l49_3 = some linear_v49_3 := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4074 27 linear_k49_3 linear_r64 linear_b64 mutated_kd49_3 mutated_s64)
theorem mutated_pl49_3 (tail : List Nat) : parseFields 4075 27 (linear_v49_3 ++ (125 :: tail)) = some (linear_l49_3, tail) := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4074 27 (linear_k49_3 ++ (34 :: 58 :: (linear_b64 ++ (125 :: tail)))) linear_k49_3 (linear_b64 ++ (125 :: tail)) tail linear_r64 (mutated_kp49_3 (linear_b64 ++ (125 :: tail))) (mutated_p64 (125 :: tail)))
def linear_l49_2 : List (List Nat × Raw) := (linear_k49_2, linear_r63) :: linear_l49_3
def linear_v49_2 : List Nat := (linear_g158 ++ linear_b63) ++ (44 :: linear_v49_3)
theorem mutated_sl49_2 : serializeFields 4076 27 linear_l49_2 = some linear_v49_2 := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k49_2 linear_r63 (linear_k49_3, linear_r64) [] linear_b63 linear_v49_3 mutated_kd49_2 mutated_s63 mutated_sl49_3)
theorem mutated_pl49_2 (tail : List Nat) : parseFields 4076 27 (linear_v49_2 ++ (125 :: tail)) = some (linear_l49_2, tail) := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k49_2 ++ (34 :: 58 :: (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))))) linear_k49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))) (linear_v49_3 ++ (125 :: tail)) tail linear_r63 linear_l49_3 (mutated_kp49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail))))) (mutated_p63 (44 :: (linear_v49_3 ++ (125 :: tail)))) (mutated_pl49_3 tail))
def linear_l49_1 : List (List Nat × Raw) := (linear_k49_1, linear_r51) :: linear_l49_2
def linear_v49_1 : List Nat := (linear_g133 ++ linear_b51) ++ (44 :: linear_v49_2)
theorem mutated_sl49_1 : serializeFields 4077 27 linear_l49_1 = some linear_v49_1 := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k49_1 linear_r51 (linear_k49_2, linear_r63) linear_l49_3 linear_b51 linear_v49_2 mutated_kd49_1 mutated_s51 mutated_sl49_2)
theorem mutated_pl49_1 (tail : List Nat) : parseFields 4077 27 (linear_v49_1 ++ (125 :: tail)) = some (linear_l49_1, tail) := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k49_1 ++ (34 :: 58 :: (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))))) linear_k49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))) (linear_v49_2 ++ (125 :: tail)) tail linear_r51 linear_l49_2 (mutated_kp49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail))))) (mutated_p51 (44 :: (linear_v49_2 ++ (125 :: tail)))) (mutated_pl49_2 tail))
def linear_l49_0 : List (List Nat × Raw) := (linear_k49_0, linear_r50) :: linear_l49_1
def linear_v49_0 : List Nat := (linear_g130 ++ linear_b50) ++ (44 :: linear_v49_1)
theorem mutated_sl49_0 : serializeFields 4078 27 linear_l49_0 = some linear_v49_0 := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k49_0 linear_r50 (linear_k49_1, linear_r51) linear_l49_2 linear_b50 linear_v49_1 mutated_kd49_0 mutated_s50 mutated_sl49_1)
theorem mutated_pl49_0 (tail : List Nat) : parseFields 4078 27 (linear_v49_0 ++ (125 :: tail)) = some (linear_l49_0, tail) := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) linear_k49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))) (linear_v49_1 ++ (125 :: tail)) tail linear_r50 linear_l49_1 (mutated_kp49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail))))) (mutated_p50 (44 :: (linear_v49_1 ++ (125 :: tail)))) (mutated_pl49_1 tail))
def linear_r49 : Raw := (.obj linear_l49_0)
def linear_b49 : List Nat := linear_g129 ++ (linear_v49_0 ++ linear_g163)
theorem mutated_o49 : orderedFields linear_l49_0 = true := by decide +kernel
theorem mutated_s49 : serializeRaw 4079 28 linear_r49 = some linear_b49 := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4078 27 linear_l49_0 linear_v49_0 mutated_o49 mutated_sl49_0)
theorem mutated_p49 (tail : List Nat) : parseRaw 4079 28 (linear_b49 ++ tail) = some (linear_r49, tail) := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4078 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) tail linear_l49_0 mutated_o49 (by simpa only [linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl49_0 tail)))
def linear_r66 : Raw := (.str [100,103,95,102,97,115,116,95,50])
def linear_b66 : List Nat := linear_g167
theorem mutated_s66 : serializeRaw 4076 27 linear_r66 = some linear_b66 := by decide +kernel
theorem mutated_p66 (tail : List Nat) : parseRaw 4076 27 (linear_b66 ++ tail) = some (linear_r66, tail) := by rfl
def linear_r67 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,54])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,55])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b67 : List Nat := linear_g170
theorem mutated_s67 : serializeRaw 4075 27 linear_r67 = some linear_b67 := by decide +kernel
theorem mutated_p67 (tail : List Nat) : parseRaw 4075 27 (linear_b67 ++ tail) = some (linear_r67, tail) := by rfl
def linear_r68 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b68 : List Nat := linear_g173
theorem mutated_s68 : serializeRaw 4074 27 linear_r68 = some linear_b68 := by decide +kernel
theorem mutated_p68 (tail : List Nat) : parseRaw 4074 27 (linear_b68 ++ tail) = some (linear_r68, tail) := by rfl
def linear_r69 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,50]),(.str [100,103,95,118,95,55,51]),(.str [100,103,95,118,95,55,54]),(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,55])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b69 : List Nat := linear_g176
theorem mutated_s69 : serializeRaw 4073 27 linear_r69 = some linear_b69 := by decide +kernel
theorem mutated_p69 (tail : List Nat) : parseRaw 4073 27 (linear_b69 ++ tail) = some (linear_r69, tail) := by rfl
def linear_k65_0 : List Nat := [105,100]
theorem mutated_kd65_0 : stringBytes linear_k65_0 = true := by decide +kernel
theorem mutated_kp65_0 (tail : List Nat) : parseStringTail (linear_k65_0 ++ (34 :: 58 :: tail)) [] = some (linear_k65_0, 58 :: tail) := by rfl
def linear_k65_1 : List Nat := [111,112,115]
theorem mutated_kd65_1 : stringBytes linear_k65_1 = true := by decide +kernel
theorem mutated_kp65_1 (tail : List Nat) : parseStringTail (linear_k65_1 ++ (34 :: 58 :: tail)) [] = some (linear_k65_1, 58 :: tail) := by rfl
def linear_k65_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd65_2 : stringBytes linear_k65_2 = true := by decide +kernel
theorem mutated_kp65_2 (tail : List Nat) : parseStringTail (linear_k65_2 ++ (34 :: 58 :: tail)) [] = some (linear_k65_2, 58 :: tail) := by rfl
def linear_k65_3 : List Nat := [116,101,114,109]
theorem mutated_kd65_3 : stringBytes linear_k65_3 = true := by decide +kernel
theorem mutated_kp65_3 (tail : List Nat) : parseStringTail (linear_k65_3 ++ (34 :: 58 :: tail)) [] = some (linear_k65_3, 58 :: tail) := by rfl
def linear_l65_3 : List (List Nat × Raw) := [(linear_k65_3, linear_r69)]
def linear_v65_3 : List Nat := linear_g175 ++ linear_b69
theorem mutated_sl65_3 : serializeFields 4074 27 linear_l65_3 = some linear_v65_3 := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4073 27 linear_k65_3 linear_r69 linear_b69 mutated_kd65_3 mutated_s69)
theorem mutated_pl65_3 (tail : List Nat) : parseFields 4074 27 (linear_v65_3 ++ (125 :: tail)) = some (linear_l65_3, tail) := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4073 27 (linear_k65_3 ++ (34 :: 58 :: (linear_b69 ++ (125 :: tail)))) linear_k65_3 (linear_b69 ++ (125 :: tail)) tail linear_r69 (mutated_kp65_3 (linear_b69 ++ (125 :: tail))) (mutated_p69 (125 :: tail)))
def linear_l65_2 : List (List Nat × Raw) := (linear_k65_2, linear_r68) :: linear_l65_3
def linear_v65_2 : List Nat := (linear_g172 ++ linear_b68) ++ (44 :: linear_v65_3)
theorem mutated_sl65_2 : serializeFields 4075 27 linear_l65_2 = some linear_v65_2 := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k65_2 linear_r68 (linear_k65_3, linear_r69) [] linear_b68 linear_v65_3 mutated_kd65_2 mutated_s68 mutated_sl65_3)
theorem mutated_pl65_2 (tail : List Nat) : parseFields 4075 27 (linear_v65_2 ++ (125 :: tail)) = some (linear_l65_2, tail) := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k65_2 ++ (34 :: 58 :: (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))))) linear_k65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))) (linear_v65_3 ++ (125 :: tail)) tail linear_r68 linear_l65_3 (mutated_kp65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail))))) (mutated_p68 (44 :: (linear_v65_3 ++ (125 :: tail)))) (mutated_pl65_3 tail))
def linear_l65_1 : List (List Nat × Raw) := (linear_k65_1, linear_r67) :: linear_l65_2
def linear_v65_1 : List Nat := (linear_g169 ++ linear_b67) ++ (44 :: linear_v65_2)
theorem mutated_sl65_1 : serializeFields 4076 27 linear_l65_1 = some linear_v65_1 := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k65_1 linear_r67 (linear_k65_2, linear_r68) linear_l65_3 linear_b67 linear_v65_2 mutated_kd65_1 mutated_s67 mutated_sl65_2)
theorem mutated_pl65_1 (tail : List Nat) : parseFields 4076 27 (linear_v65_1 ++ (125 :: tail)) = some (linear_l65_1, tail) := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k65_1 ++ (34 :: 58 :: (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))))) linear_k65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))) (linear_v65_2 ++ (125 :: tail)) tail linear_r67 linear_l65_2 (mutated_kp65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail))))) (mutated_p67 (44 :: (linear_v65_2 ++ (125 :: tail)))) (mutated_pl65_2 tail))
def linear_l65_0 : List (List Nat × Raw) := (linear_k65_0, linear_r66) :: linear_l65_1
def linear_v65_0 : List Nat := (linear_g166 ++ linear_b66) ++ (44 :: linear_v65_1)
theorem mutated_sl65_0 : serializeFields 4077 27 linear_l65_0 = some linear_v65_0 := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k65_0 linear_r66 (linear_k65_1, linear_r67) linear_l65_2 linear_b66 linear_v65_1 mutated_kd65_0 mutated_s66 mutated_sl65_1)
theorem mutated_pl65_0 (tail : List Nat) : parseFields 4077 27 (linear_v65_0 ++ (125 :: tail)) = some (linear_l65_0, tail) := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) linear_k65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))) (linear_v65_1 ++ (125 :: tail)) tail linear_r66 linear_l65_1 (mutated_kp65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail))))) (mutated_p66 (44 :: (linear_v65_1 ++ (125 :: tail)))) (mutated_pl65_1 tail))
def linear_r65 : Raw := (.obj linear_l65_0)
def linear_b65 : List Nat := linear_g165 ++ (linear_v65_0 ++ linear_g177)
theorem mutated_o65 : orderedFields linear_l65_0 = true := by decide +kernel
theorem mutated_s65 : serializeRaw 4078 28 linear_r65 = some linear_b65 := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4077 27 linear_l65_0 linear_v65_0 mutated_o65 mutated_sl65_0)
theorem mutated_p65 (tail : List Nat) : parseRaw 4078 28 (linear_b65 ++ tail) = some (linear_r65, tail) := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4077 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) tail linear_l65_0 mutated_o65 (by simpa only [linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl65_0 tail)))
def linear_r71 : Raw := (.str [100,103,95,102,97,115,116,95,51])
def linear_b71 : List Nat := linear_g181
theorem mutated_s71 : serializeRaw 4075 27 linear_r71 = some linear_b71 := by decide +kernel
theorem mutated_p71 (tail : List Nat) : parseRaw 4075 27 (linear_b71 ++ tail) = some (linear_r71, tail) := by rfl
def linear_r72 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,51]),(.str [100,103,95,118,95,56,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b72 : List Nat := linear_g184
theorem mutated_s72 : serializeRaw 4074 27 linear_r72 = some linear_b72 := by decide +kernel
theorem mutated_p72 (tail : List Nat) : parseRaw 4074 27 (linear_b72 ++ tail) = some (linear_r72, tail) := by rfl
def linear_r73 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b73 : List Nat := linear_g187
theorem mutated_s73 : serializeRaw 4073 27 linear_r73 = some linear_b73 := by decide +kernel
theorem mutated_p73 (tail : List Nat) : parseRaw 4073 27 (linear_b73 ++ tail) = some (linear_r73, tail) := by rfl
def linear_r74 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,56,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b74 : List Nat := linear_g190
theorem mutated_s74 : serializeRaw 4072 27 linear_r74 = some linear_b74 := by decide +kernel
theorem mutated_p74 (tail : List Nat) : parseRaw 4072 27 (linear_b74 ++ tail) = some (linear_r74, tail) := by rfl
def linear_k70_0 : List Nat := [105,100]
theorem mutated_kd70_0 : stringBytes linear_k70_0 = true := by decide +kernel
theorem mutated_kp70_0 (tail : List Nat) : parseStringTail (linear_k70_0 ++ (34 :: 58 :: tail)) [] = some (linear_k70_0, 58 :: tail) := by rfl
def linear_k70_1 : List Nat := [111,112,115]
theorem mutated_kd70_1 : stringBytes linear_k70_1 = true := by decide +kernel
theorem mutated_kp70_1 (tail : List Nat) : parseStringTail (linear_k70_1 ++ (34 :: 58 :: tail)) [] = some (linear_k70_1, 58 :: tail) := by rfl
def linear_k70_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd70_2 : stringBytes linear_k70_2 = true := by decide +kernel
theorem mutated_kp70_2 (tail : List Nat) : parseStringTail (linear_k70_2 ++ (34 :: 58 :: tail)) [] = some (linear_k70_2, 58 :: tail) := by rfl
def linear_k70_3 : List Nat := [116,101,114,109]
theorem mutated_kd70_3 : stringBytes linear_k70_3 = true := by decide +kernel
theorem mutated_kp70_3 (tail : List Nat) : parseStringTail (linear_k70_3 ++ (34 :: 58 :: tail)) [] = some (linear_k70_3, 58 :: tail) := by rfl
def linear_l70_3 : List (List Nat × Raw) := [(linear_k70_3, linear_r74)]
def linear_v70_3 : List Nat := linear_g189 ++ linear_b74
theorem mutated_sl70_3 : serializeFields 4073 27 linear_l70_3 = some linear_v70_3 := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4072 27 linear_k70_3 linear_r74 linear_b74 mutated_kd70_3 mutated_s74)
theorem mutated_pl70_3 (tail : List Nat) : parseFields 4073 27 (linear_v70_3 ++ (125 :: tail)) = some (linear_l70_3, tail) := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4072 27 (linear_k70_3 ++ (34 :: 58 :: (linear_b74 ++ (125 :: tail)))) linear_k70_3 (linear_b74 ++ (125 :: tail)) tail linear_r74 (mutated_kp70_3 (linear_b74 ++ (125 :: tail))) (mutated_p74 (125 :: tail)))
def linear_l70_2 : List (List Nat × Raw) := (linear_k70_2, linear_r73) :: linear_l70_3
def linear_v70_2 : List Nat := (linear_g186 ++ linear_b73) ++ (44 :: linear_v70_3)
theorem mutated_sl70_2 : serializeFields 4074 27 linear_l70_2 = some linear_v70_2 := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k70_2 linear_r73 (linear_k70_3, linear_r74) [] linear_b73 linear_v70_3 mutated_kd70_2 mutated_s73 mutated_sl70_3)
theorem mutated_pl70_2 (tail : List Nat) : parseFields 4074 27 (linear_v70_2 ++ (125 :: tail)) = some (linear_l70_2, tail) := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k70_2 ++ (34 :: 58 :: (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))))) linear_k70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))) (linear_v70_3 ++ (125 :: tail)) tail linear_r73 linear_l70_3 (mutated_kp70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail))))) (mutated_p73 (44 :: (linear_v70_3 ++ (125 :: tail)))) (mutated_pl70_3 tail))
def linear_l70_1 : List (List Nat × Raw) := (linear_k70_1, linear_r72) :: linear_l70_2
def linear_v70_1 : List Nat := (linear_g183 ++ linear_b72) ++ (44 :: linear_v70_2)
theorem mutated_sl70_1 : serializeFields 4075 27 linear_l70_1 = some linear_v70_1 := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k70_1 linear_r72 (linear_k70_2, linear_r73) linear_l70_3 linear_b72 linear_v70_2 mutated_kd70_1 mutated_s72 mutated_sl70_2)
theorem mutated_pl70_1 (tail : List Nat) : parseFields 4075 27 (linear_v70_1 ++ (125 :: tail)) = some (linear_l70_1, tail) := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k70_1 ++ (34 :: 58 :: (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))))) linear_k70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))) (linear_v70_2 ++ (125 :: tail)) tail linear_r72 linear_l70_2 (mutated_kp70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail))))) (mutated_p72 (44 :: (linear_v70_2 ++ (125 :: tail)))) (mutated_pl70_2 tail))
def linear_l70_0 : List (List Nat × Raw) := (linear_k70_0, linear_r71) :: linear_l70_1
def linear_v70_0 : List Nat := (linear_g180 ++ linear_b71) ++ (44 :: linear_v70_1)
theorem mutated_sl70_0 : serializeFields 4076 27 linear_l70_0 = some linear_v70_0 := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k70_0 linear_r71 (linear_k70_1, linear_r72) linear_l70_2 linear_b71 linear_v70_1 mutated_kd70_0 mutated_s71 mutated_sl70_1)
theorem mutated_pl70_0 (tail : List Nat) : parseFields 4076 27 (linear_v70_0 ++ (125 :: tail)) = some (linear_l70_0, tail) := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) linear_k70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))) (linear_v70_1 ++ (125 :: tail)) tail linear_r71 linear_l70_1 (mutated_kp70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail))))) (mutated_p71 (44 :: (linear_v70_1 ++ (125 :: tail)))) (mutated_pl70_1 tail))
def linear_r70 : Raw := (.obj linear_l70_0)
def linear_b70 : List Nat := linear_g179 ++ (linear_v70_0 ++ linear_g191)
theorem mutated_o70 : orderedFields linear_l70_0 = true := by decide +kernel
theorem mutated_s70 : serializeRaw 4077 28 linear_r70 = some linear_b70 := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4076 27 linear_l70_0 linear_v70_0 mutated_o70 mutated_sl70_0)
theorem mutated_p70 (tail : List Nat) : parseRaw 4077 28 (linear_b70 ++ tail) = some (linear_r70, tail) := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4076 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) tail linear_l70_0 mutated_o70 (by simpa only [linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl70_0 tail)))
def linear_r76 : Raw := (.str [100,103,95,102,97,115,116,95,52])
def linear_b76 : List Nat := linear_g195
theorem mutated_s76 : serializeRaw 4074 27 linear_r76 = some linear_b76 := by decide +kernel
theorem mutated_p76 (tail : List Nat) : parseRaw 4074 27 (linear_b76 ++ tail) = some (linear_r76, tail) := by rfl
def linear_r78 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,49])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b78 : List Nat := linear_g199
theorem mutated_s78 : serializeRaw 4071 26 linear_r78 = some linear_b78 := by decide +kernel
theorem mutated_p78 (tail : List Nat) : parseRaw 4071 26 (linear_b78 ++ tail) = some (linear_r78, tail) := by rfl
def linear_r79 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49]),(.str [100,103,95,118,95,57,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,50])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b79 : List Nat := linear_g201
theorem mutated_s79 : serializeRaw 4070 26 linear_r79 = some linear_b79 := by decide +kernel
theorem mutated_p79 (tail : List Nat) : parseRaw 4070 26 (linear_b79 ++ tail) = some (linear_r79, tail) := by rfl
def linear_r80 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b80 : List Nat := linear_g203
theorem mutated_s80 : serializeRaw 4069 26 linear_r80 = some linear_b80 := by decide +kernel
theorem mutated_p80 (tail : List Nat) : parseRaw 4069 26 (linear_b80 ++ tail) = some (linear_r80, tail) := by rfl
def linear_r81 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,50])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,51])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b81 : List Nat := linear_g205
theorem mutated_s81 : serializeRaw 4068 26 linear_r81 = some linear_b81 := by decide +kernel
theorem mutated_p81 (tail : List Nat) : parseRaw 4068 26 (linear_b81 ++ tail) = some (linear_r81, tail) := by rfl
def linear_r82 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,56]),(.str [100,103,95,118,95,57,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,52])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b82 : List Nat := linear_g207
theorem mutated_s82 : serializeRaw 4067 26 linear_r82 = some linear_b82 := by decide +kernel
theorem mutated_p82 (tail : List Nat) : parseRaw 4067 26 (linear_b82 ++ tail) = some (linear_r82, tail) := by rfl
def linear_r83 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,53])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b83 : List Nat := linear_g209
theorem mutated_s83 : serializeRaw 4066 26 linear_r83 = some linear_b83 := by decide +kernel
theorem mutated_p83 (tail : List Nat) : parseRaw 4066 26 (linear_b83 ++ tail) = some (linear_r83, tail) := by rfl
def linear_r84 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,48]),(.str [100,103,95,118,95,57,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,54])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b84 : List Nat := linear_g211
theorem mutated_s84 : serializeRaw 4065 26 linear_r84 = some linear_b84 := by decide +kernel
theorem mutated_p84 (tail : List Nat) : parseRaw 4065 26 (linear_b84 ++ tail) = some (linear_r84, tail) := by rfl
def linear_l77_6 : List Raw := [linear_r84]
def linear_v77_6 : List Nat := linear_b84
theorem mutated_sl77_6 : serializeItems 4066 26 linear_l77_6 = some linear_v77_6 := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4065 26 linear_r84 linear_b84 mutated_s84)
theorem mutated_pl77_6 (tail : List Nat) : parseItems 4066 26 (linear_v77_6 ++ (93 :: tail)) = some (linear_l77_6, tail) := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4065 26 (linear_b84 ++ (93 :: tail)) tail linear_r84 (mutated_p84 (93 :: tail)))
def linear_l77_5 : List Raw := linear_r83 :: linear_l77_6
def linear_v77_5 : List Nat := (linear_b83) ++ (44 :: linear_v77_6)
theorem mutated_sl77_5 : serializeItems 4067 26 linear_l77_5 = some linear_v77_5 := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r83 linear_r84 [] linear_b83 linear_v77_6 mutated_s83 mutated_sl77_6)
theorem mutated_pl77_5 (tail : List Nat) : parseItems 4067 26 (linear_v77_5 ++ (93 :: tail)) = some (linear_l77_5, tail) := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b83 ++ (44 :: (linear_v77_6 ++ (93 :: tail)))) (linear_v77_6 ++ (93 :: tail)) tail linear_r83 linear_l77_6 (mutated_p83 (44 :: (linear_v77_6 ++ (93 :: tail)))) (mutated_pl77_6 tail))
def linear_l77_4 : List Raw := linear_r82 :: linear_l77_5
def linear_v77_4 : List Nat := (linear_b82) ++ (44 :: linear_v77_5)
theorem mutated_sl77_4 : serializeItems 4068 26 linear_l77_4 = some linear_v77_4 := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r82 linear_r83 linear_l77_6 linear_b82 linear_v77_5 mutated_s82 mutated_sl77_5)
theorem mutated_pl77_4 (tail : List Nat) : parseItems 4068 26 (linear_v77_4 ++ (93 :: tail)) = some (linear_l77_4, tail) := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b82 ++ (44 :: (linear_v77_5 ++ (93 :: tail)))) (linear_v77_5 ++ (93 :: tail)) tail linear_r82 linear_l77_5 (mutated_p82 (44 :: (linear_v77_5 ++ (93 :: tail)))) (mutated_pl77_5 tail))
def linear_l77_3 : List Raw := linear_r81 :: linear_l77_4
def linear_v77_3 : List Nat := (linear_b81) ++ (44 :: linear_v77_4)
theorem mutated_sl77_3 : serializeItems 4069 26 linear_l77_3 = some linear_v77_3 := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r81 linear_r82 linear_l77_5 linear_b81 linear_v77_4 mutated_s81 mutated_sl77_4)
theorem mutated_pl77_3 (tail : List Nat) : parseItems 4069 26 (linear_v77_3 ++ (93 :: tail)) = some (linear_l77_3, tail) := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b81 ++ (44 :: (linear_v77_4 ++ (93 :: tail)))) (linear_v77_4 ++ (93 :: tail)) tail linear_r81 linear_l77_4 (mutated_p81 (44 :: (linear_v77_4 ++ (93 :: tail)))) (mutated_pl77_4 tail))
def linear_l77_2 : List Raw := linear_r80 :: linear_l77_3
def linear_v77_2 : List Nat := (linear_b80) ++ (44 :: linear_v77_3)
theorem mutated_sl77_2 : serializeItems 4070 26 linear_l77_2 = some linear_v77_2 := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r80 linear_r81 linear_l77_4 linear_b80 linear_v77_3 mutated_s80 mutated_sl77_3)
theorem mutated_pl77_2 (tail : List Nat) : parseItems 4070 26 (linear_v77_2 ++ (93 :: tail)) = some (linear_l77_2, tail) := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b80 ++ (44 :: (linear_v77_3 ++ (93 :: tail)))) (linear_v77_3 ++ (93 :: tail)) tail linear_r80 linear_l77_3 (mutated_p80 (44 :: (linear_v77_3 ++ (93 :: tail)))) (mutated_pl77_3 tail))
def linear_l77_1 : List Raw := linear_r79 :: linear_l77_2
def linear_v77_1 : List Nat := (linear_b79) ++ (44 :: linear_v77_2)
theorem mutated_sl77_1 : serializeItems 4071 26 linear_l77_1 = some linear_v77_1 := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r79 linear_r80 linear_l77_3 linear_b79 linear_v77_2 mutated_s79 mutated_sl77_2)
theorem mutated_pl77_1 (tail : List Nat) : parseItems 4071 26 (linear_v77_1 ++ (93 :: tail)) = some (linear_l77_1, tail) := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b79 ++ (44 :: (linear_v77_2 ++ (93 :: tail)))) (linear_v77_2 ++ (93 :: tail)) tail linear_r79 linear_l77_2 (mutated_p79 (44 :: (linear_v77_2 ++ (93 :: tail)))) (mutated_pl77_2 tail))
def linear_l77_0 : List Raw := linear_r78 :: linear_l77_1
def linear_v77_0 : List Nat := (linear_b78) ++ (44 :: linear_v77_1)
theorem mutated_sl77_0 : serializeItems 4072 26 linear_l77_0 = some linear_v77_0 := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r78 linear_r79 linear_l77_2 linear_b78 linear_v77_1 mutated_s78 mutated_sl77_1)
theorem mutated_pl77_0 (tail : List Nat) : parseItems 4072 26 (linear_v77_0 ++ (93 :: tail)) = some (linear_l77_0, tail) := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b78 ++ (44 :: (linear_v77_1 ++ (93 :: tail)))) (linear_v77_1 ++ (93 :: tail)) tail linear_r78 linear_l77_1 (mutated_p78 (44 :: (linear_v77_1 ++ (93 :: tail)))) (mutated_pl77_1 tail))
def linear_r77 : Raw := (.arr linear_l77_0)
def linear_b77 : List Nat := linear_g198 ++ (linear_v77_0 ++ linear_g212)
theorem mutated_s77 : serializeRaw 4073 27 linear_r77 = some linear_b77 := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4072 26 linear_l77_0 linear_v77_0 mutated_sl77_0)
theorem mutated_p77 (tail : List Nat) : parseRaw 4073 27 (linear_b77 ++ tail) = some (linear_r77, tail) := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4072 26 (linear_v77_0 ++ (93 :: tail)) tail linear_l77_0 (by intro h; cases h) (mutated_pl77_0 tail))
def linear_r85 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b85 : List Nat := linear_g215
theorem mutated_s85 : serializeRaw 4072 27 linear_r85 = some linear_b85 := by decide +kernel
theorem mutated_p85 (tail : List Nat) : parseRaw 4072 27 (linear_b85 ++ tail) = some (linear_r85, tail) := by rfl
def linear_r86 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,53]),(.str [100,103,95,118,95,56,54]),(.str [100,103,95,118,95,56,55]),(.str [100,103,95,118,95,57,52]),(.str [100,103,95,118,95,56,57]),(.str [100,103,95,118,95,57,54])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b86 : List Nat := linear_g218
theorem mutated_s86 : serializeRaw 4071 27 linear_r86 = some linear_b86 := by decide +kernel
theorem mutated_p86 (tail : List Nat) : parseRaw 4071 27 (linear_b86 ++ tail) = some (linear_r86, tail) := by rfl
def linear_k75_0 : List Nat := [105,100]
theorem mutated_kd75_0 : stringBytes linear_k75_0 = true := by decide +kernel
theorem mutated_kp75_0 (tail : List Nat) : parseStringTail (linear_k75_0 ++ (34 :: 58 :: tail)) [] = some (linear_k75_0, 58 :: tail) := by rfl
def linear_k75_1 : List Nat := [111,112,115]
theorem mutated_kd75_1 : stringBytes linear_k75_1 = true := by decide +kernel
theorem mutated_kp75_1 (tail : List Nat) : parseStringTail (linear_k75_1 ++ (34 :: 58 :: tail)) [] = some (linear_k75_1, 58 :: tail) := by rfl
def linear_k75_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd75_2 : stringBytes linear_k75_2 = true := by decide +kernel
theorem mutated_kp75_2 (tail : List Nat) : parseStringTail (linear_k75_2 ++ (34 :: 58 :: tail)) [] = some (linear_k75_2, 58 :: tail) := by rfl
def linear_k75_3 : List Nat := [116,101,114,109]
theorem mutated_kd75_3 : stringBytes linear_k75_3 = true := by decide +kernel
theorem mutated_kp75_3 (tail : List Nat) : parseStringTail (linear_k75_3 ++ (34 :: 58 :: tail)) [] = some (linear_k75_3, 58 :: tail) := by rfl
def linear_l75_3 : List (List Nat × Raw) := [(linear_k75_3, linear_r86)]
def linear_v75_3 : List Nat := linear_g217 ++ linear_b86
theorem mutated_sl75_3 : serializeFields 4072 27 linear_l75_3 = some linear_v75_3 := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4071 27 linear_k75_3 linear_r86 linear_b86 mutated_kd75_3 mutated_s86)
theorem mutated_pl75_3 (tail : List Nat) : parseFields 4072 27 (linear_v75_3 ++ (125 :: tail)) = some (linear_l75_3, tail) := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4071 27 (linear_k75_3 ++ (34 :: 58 :: (linear_b86 ++ (125 :: tail)))) linear_k75_3 (linear_b86 ++ (125 :: tail)) tail linear_r86 (mutated_kp75_3 (linear_b86 ++ (125 :: tail))) (mutated_p86 (125 :: tail)))
def linear_l75_2 : List (List Nat × Raw) := (linear_k75_2, linear_r85) :: linear_l75_3
def linear_v75_2 : List Nat := (linear_g214 ++ linear_b85) ++ (44 :: linear_v75_3)
theorem mutated_sl75_2 : serializeFields 4073 27 linear_l75_2 = some linear_v75_2 := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k75_2 linear_r85 (linear_k75_3, linear_r86) [] linear_b85 linear_v75_3 mutated_kd75_2 mutated_s85 mutated_sl75_3)
theorem mutated_pl75_2 (tail : List Nat) : parseFields 4073 27 (linear_v75_2 ++ (125 :: tail)) = some (linear_l75_2, tail) := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k75_2 ++ (34 :: 58 :: (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))))) linear_k75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))) (linear_v75_3 ++ (125 :: tail)) tail linear_r85 linear_l75_3 (mutated_kp75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail))))) (mutated_p85 (44 :: (linear_v75_3 ++ (125 :: tail)))) (mutated_pl75_3 tail))
def linear_l75_1 : List (List Nat × Raw) := (linear_k75_1, linear_r77) :: linear_l75_2
def linear_v75_1 : List Nat := (linear_g197 ++ linear_b77) ++ (44 :: linear_v75_2)
theorem mutated_sl75_1 : serializeFields 4074 27 linear_l75_1 = some linear_v75_1 := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k75_1 linear_r77 (linear_k75_2, linear_r85) linear_l75_3 linear_b77 linear_v75_2 mutated_kd75_1 mutated_s77 mutated_sl75_2)
theorem mutated_pl75_1 (tail : List Nat) : parseFields 4074 27 (linear_v75_1 ++ (125 :: tail)) = some (linear_l75_1, tail) := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k75_1 ++ (34 :: 58 :: (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))))) linear_k75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))) (linear_v75_2 ++ (125 :: tail)) tail linear_r77 linear_l75_2 (mutated_kp75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail))))) (mutated_p77 (44 :: (linear_v75_2 ++ (125 :: tail)))) (mutated_pl75_2 tail))
def linear_l75_0 : List (List Nat × Raw) := (linear_k75_0, linear_r76) :: linear_l75_1
def linear_v75_0 : List Nat := (linear_g194 ++ linear_b76) ++ (44 :: linear_v75_1)
theorem mutated_sl75_0 : serializeFields 4075 27 linear_l75_0 = some linear_v75_0 := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k75_0 linear_r76 (linear_k75_1, linear_r77) linear_l75_2 linear_b76 linear_v75_1 mutated_kd75_0 mutated_s76 mutated_sl75_1)
theorem mutated_pl75_0 (tail : List Nat) : parseFields 4075 27 (linear_v75_0 ++ (125 :: tail)) = some (linear_l75_0, tail) := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) linear_k75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))) (linear_v75_1 ++ (125 :: tail)) tail linear_r76 linear_l75_1 (mutated_kp75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail))))) (mutated_p76 (44 :: (linear_v75_1 ++ (125 :: tail)))) (mutated_pl75_1 tail))
def linear_r75 : Raw := (.obj linear_l75_0)
def linear_b75 : List Nat := linear_g193 ++ (linear_v75_0 ++ linear_g219)
theorem mutated_o75 : orderedFields linear_l75_0 = true := by decide +kernel
theorem mutated_s75 : serializeRaw 4076 28 linear_r75 = some linear_b75 := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4075 27 linear_l75_0 linear_v75_0 mutated_o75 mutated_sl75_0)
theorem mutated_p75 (tail : List Nat) : parseRaw 4076 28 (linear_b75 ++ tail) = some (linear_r75, tail) := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4075 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) tail linear_l75_0 mutated_o75 (by simpa only [linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl75_0 tail)))
def linear_r88 : Raw := (.str [100,103,95,102,97,115,116,95,53])
def linear_b88 : List Nat := linear_g223
theorem mutated_s88 : serializeRaw 4073 27 linear_r88 = some linear_b88 := by decide +kernel
theorem mutated_p88 (tail : List Nat) : parseRaw 4073 27 (linear_b88 ++ tail) = some (linear_r88, tail) := by rfl
def linear_r89 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b89 : List Nat := linear_g226
theorem mutated_s89 : serializeRaw 4072 27 linear_r89 = some linear_b89 := by decide +kernel
theorem mutated_p89 (tail : List Nat) : parseRaw 4072 27 (linear_b89 ++ tail) = some (linear_r89, tail) := by rfl
def linear_r90 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,48])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b90 : List Nat := linear_g229
theorem mutated_s90 : serializeRaw 4071 27 linear_r90 = some linear_b90 := by decide +kernel
theorem mutated_p90 (tail : List Nat) : parseRaw 4071 27 (linear_b90 ++ tail) = some (linear_r90, tail) := by rfl
def linear_r91 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,48,48])]))])
def linear_b91 : List Nat := linear_g232
theorem mutated_s91 : serializeRaw 4070 27 linear_r91 = some linear_b91 := by decide +kernel
theorem mutated_p91 (tail : List Nat) : parseRaw 4070 27 (linear_b91 ++ tail) = some (linear_r91, tail) := by rfl
def linear_k87_0 : List Nat := [105,100]
theorem mutated_kd87_0 : stringBytes linear_k87_0 = true := by decide +kernel
end HiaCoreSyntaxSlice.WrongPhi
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd10_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd10_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd10_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd10_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd15_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd15_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd15_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd15_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd24_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd24_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd24_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd24_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd29_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd29_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd29_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd29_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd34_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd34_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd34_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd34_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd39_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd39_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd39_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd39_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd44_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd44_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd44_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd44_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd49_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd49_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd49_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd49_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd5_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd5_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd5_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd5_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd65_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd65_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd65_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd65_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd70_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd70_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd70_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd70_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd75_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd75_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd75_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd75_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kd87_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp10_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp10_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp10_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp10_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp15_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp15_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp15_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp15_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp24_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp24_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp24_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp24_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp29_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp29_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp29_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp29_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp34_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp34_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp34_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp34_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp39_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp39_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp39_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp39_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp44_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp44_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp44_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp44_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp49_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp49_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp49_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp49_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp5_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp5_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp5_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp5_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp65_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp65_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp65_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp65_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp70_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp70_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp70_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp70_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp75_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp75_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp75_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_kp75_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o15
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o24
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o29
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o34
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o39
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o44
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o49
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o65
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o70
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_o75
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p11
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p12
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p13
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p14
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p15
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p16
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p17
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p18
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p19
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p20
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p21
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p22
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p23
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p24
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p25
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p26
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p27
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p28
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p29
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p30
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p31
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p32
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p33
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p34
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p35
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p36
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p37
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p38
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p39
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p40
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p41
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p42
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p43
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p44
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p45
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p46
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p47
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p48
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p49
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p50
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p51
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p52
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p53
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p54
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p55
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p56
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p57
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p58
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p59
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p60
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p61
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p62
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p63
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p64
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p65
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p66
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p67
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p68
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p69
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p70
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p71
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p72
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p73
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p74
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p75
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p76
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p77
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p78
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p79
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p80
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p81
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p82
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p83
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p84
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p85
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p86
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p88
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p89
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p90
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_p91
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl10_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl10_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl10_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl10_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl15_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl15_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl15_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl15_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl17_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl17_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl17_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl17_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl24_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl24_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl24_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl24_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl29_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl29_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl29_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl29_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl34_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl34_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl34_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl34_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl39_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl39_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl39_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl39_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl44_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl44_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl44_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl44_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl49_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl49_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl49_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl49_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl51_9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl5_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl5_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl5_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl5_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl65_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl65_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl65_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl65_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl70_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl70_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl70_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl70_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl75_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl75_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl75_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl75_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_pl77_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s11
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s12
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s13
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s14
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s15
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s16
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s17
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s18
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s19
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s20
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s21
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s22
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s23
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s24
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s25
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s26
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s27
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s28
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s29
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s30
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s31
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s32
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s33
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s34
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s35
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s36
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s37
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s38
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s39
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s40
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s41
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s42
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s43
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s44
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s45
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s46
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s47
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s48
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s49
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s50
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s51
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s52
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s53
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s54
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s55
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s56
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s57
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s58
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s59
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s60
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s61
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s62
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s63
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s64
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s65
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s66
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s67
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s68
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s69
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s70
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s71
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s72
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s73
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s74
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s75
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s76
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s77
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s78
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s79
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s80
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s81
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s82
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s83
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s84
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s85
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s86
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s88
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s89
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s90
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_s91
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl10_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl10_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl10_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl10_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl15_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl15_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl15_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl15_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl17_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl17_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl17_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl17_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl24_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl24_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl24_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl24_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl29_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl29_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl29_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl29_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl34_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl34_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl34_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl34_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl39_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl39_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl39_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl39_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl44_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl44_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl44_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl44_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl49_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl49_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl49_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl49_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_10
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_6
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_7
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_8
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl51_9
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl5_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl5_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl5_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl5_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl65_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl65_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl65_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl65_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl70_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl70_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl70_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl70_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl75_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl75_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl75_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl75_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_0
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_1
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_2
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_3
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_4
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_5
#print axioms HiaCoreSyntaxSlice.WrongPhi.mutated_sl77_6
#print axioms HiaCoreSyntaxSlice.parallel_bf0491
#print axioms HiaCoreSyntaxSlice.parallel_bf0492
#print axioms HiaCoreSyntaxSlice.parallel_bf0493
#print axioms HiaCoreSyntaxSlice.parallel_bf0494
#print axioms HiaCoreSyntaxSlice.parallel_bf0495
#print axioms HiaCoreSyntaxSlice.parallel_bf0496
#print axioms HiaCoreSyntaxSlice.parallel_bf0497
#print axioms HiaCoreSyntaxSlice.parallel_bf0498
#print axioms HiaCoreSyntaxSlice.parallel_bf0499
#print axioms HiaCoreSyntaxSlice.parallel_bf0500
#print axioms HiaCoreSyntaxSlice.parallel_bf0501
#print axioms HiaCoreSyntaxSlice.parallel_bf0502
#print axioms HiaCoreSyntaxSlice.parallel_bf0503
#print axioms HiaCoreSyntaxSlice.parallel_bf0504
#print axioms HiaCoreSyntaxSlice.parallel_bf0505
#print axioms HiaCoreSyntaxSlice.parallel_bf0506
#print axioms HiaCoreSyntaxSlice.parallel_bf0507
#print axioms HiaCoreSyntaxSlice.parallel_bf0508
#print axioms HiaCoreSyntaxSlice.parallel_bf0509
#print axioms HiaCoreSyntaxSlice.parallel_bf0510
#print axioms HiaCoreSyntaxSlice.parallel_bf0511
#print axioms HiaCoreSyntaxSlice.parallel_bf0512
#print axioms HiaCoreSyntaxSlice.parallel_bf0513
#print axioms HiaCoreSyntaxSlice.parallel_bf0514
#print axioms HiaCoreSyntaxSlice.parallel_bf0515
#print axioms HiaCoreSyntaxSlice.parallel_bf0516
#print axioms HiaCoreSyntaxSlice.parallel_bf0517
#print axioms HiaCoreSyntaxSlice.parallel_bf0518
#print axioms HiaCoreSyntaxSlice.parallel_bf0519
#print axioms HiaCoreSyntaxSlice.parallel_bf0520
#print axioms HiaCoreSyntaxSlice.parallel_bf0521
#print axioms HiaCoreSyntaxSlice.parallel_bf0522
#print axioms HiaCoreSyntaxSlice.parallel_bf0523
#print axioms HiaCoreSyntaxSlice.parallel_bf0524
#print axioms HiaCoreSyntaxSlice.parallel_bf0525
#print axioms HiaCoreSyntaxSlice.parallel_bf0526
#print axioms HiaCoreSyntaxSlice.parallel_bf0527
#print axioms HiaCoreSyntaxSlice.parallel_bf0528
#print axioms HiaCoreSyntaxSlice.parallel_bf0529
#print axioms HiaCoreSyntaxSlice.parallel_bf0530
#print axioms HiaCoreSyntaxSlice.parallel_bf0531
#print axioms HiaCoreSyntaxSlice.parallel_bf0532
#print axioms HiaCoreSyntaxSlice.parallel_bf0533
#print axioms HiaCoreSyntaxSlice.parallel_bf0534
#print axioms HiaCoreSyntaxSlice.parallel_bf0535
#print axioms HiaCoreSyntaxSlice.parallel_bf0536
#print axioms HiaCoreSyntaxSlice.parallel_bf0537
#print axioms HiaCoreSyntaxSlice.parallel_bf0538
#print axioms HiaCoreSyntaxSlice.parallel_bf0539
#print axioms HiaCoreSyntaxSlice.parallel_bf0540
#print axioms HiaCoreSyntaxSlice.parallel_bf0541
#print axioms HiaCoreSyntaxSlice.parallel_bf0542
#print axioms HiaCoreSyntaxSlice.parallel_bf0543
#print axioms HiaCoreSyntaxSlice.parallel_bf0544
#print axioms HiaCoreSyntaxSlice.parallel_bf0545
#print axioms HiaCoreSyntaxSlice.parallel_bf0546
#print axioms HiaCoreSyntaxSlice.parallel_bf0547
#print axioms HiaCoreSyntaxSlice.parallel_bf0548
#print axioms HiaCoreSyntaxSlice.parallel_bf0549
#print axioms HiaCoreSyntaxSlice.parallel_bf0550
#print axioms HiaCoreSyntaxSlice.parallel_bf0551
#print axioms HiaCoreSyntaxSlice.parallel_bf0552
#print axioms HiaCoreSyntaxSlice.parallel_bf0553
#print axioms HiaCoreSyntaxSlice.parallel_bf0554
#print axioms HiaCoreSyntaxSlice.parallel_bf0555
#print axioms HiaCoreSyntaxSlice.parallel_bf0556
#print axioms HiaCoreSyntaxSlice.parallel_bf0557
#print axioms HiaCoreSyntaxSlice.parallel_bf0558
#print axioms HiaCoreSyntaxSlice.parallel_bf0559
#print axioms HiaCoreSyntaxSlice.parallel_bf0560
#print axioms HiaCoreSyntaxSlice.parallel_bf0561
#print axioms HiaCoreSyntaxSlice.parallel_bf0562
#print axioms HiaCoreSyntaxSlice.parallel_bf0563
#print axioms HiaCoreSyntaxSlice.parallel_bf0564
#print axioms HiaCoreSyntaxSlice.parallel_bf0565
#print axioms HiaCoreSyntaxSlice.parallel_bf0566
#print axioms HiaCoreSyntaxSlice.parallel_bf0567
#print axioms HiaCoreSyntaxSlice.parallel_bf0568
#print axioms HiaCoreSyntaxSlice.parallel_bf0569
#print axioms HiaCoreSyntaxSlice.parallel_bf0570
#print axioms HiaCoreSyntaxSlice.parallel_bf0571
#print axioms HiaCoreSyntaxSlice.parallel_bf0572
#print axioms HiaCoreSyntaxSlice.parallel_bf0573
#print axioms HiaCoreSyntaxSlice.parallel_bf0574
#print axioms HiaCoreSyntaxSlice.parallel_bf0575
#print axioms HiaCoreSyntaxSlice.parallel_bf0576
#print axioms HiaCoreSyntaxSlice.parallel_bf0577
#print axioms HiaCoreSyntaxSlice.parallel_bf0578
#print axioms HiaCoreSyntaxSlice.parallel_bf0579
#print axioms HiaCoreSyntaxSlice.parallel_bf0580
#print axioms HiaCoreSyntaxSlice.parallel_bf0581
#print axioms HiaCoreSyntaxSlice.parallel_bf0582
#print axioms HiaCoreSyntaxSlice.parallel_bf0583
#print axioms HiaCoreSyntaxSlice.parallel_bf0584
#print axioms HiaCoreSyntaxSlice.parallel_bf0585
#print axioms HiaCoreSyntaxSlice.parallel_bf0586
#print axioms HiaCoreSyntaxSlice.parallel_bf0587
#print axioms HiaCoreSyntaxSlice.parallel_bf0588
#print axioms HiaCoreSyntaxSlice.parallel_bf0589
#print axioms HiaCoreSyntaxSlice.parallel_bf0590
#print axioms HiaCoreSyntaxSlice.parallel_bf0591
#print axioms HiaCoreSyntaxSlice.parallel_bf0592
#print axioms HiaCoreSyntaxSlice.parallel_bf0593
#print axioms HiaCoreSyntaxSlice.parallel_bf0594
#print axioms HiaCoreSyntaxSlice.parallel_bounds
#print axioms HiaCoreSyntaxSlice.parallel_byte_range
#print axioms HiaCoreSyntaxSlice.parallel_kd0_0
#print axioms HiaCoreSyntaxSlice.parallel_kd0_1
#print axioms HiaCoreSyntaxSlice.parallel_kd0_2
#print axioms HiaCoreSyntaxSlice.parallel_kd0_3
#print axioms HiaCoreSyntaxSlice.parallel_kd118_0
#print axioms HiaCoreSyntaxSlice.parallel_kd118_1
#print axioms HiaCoreSyntaxSlice.parallel_kd118_2
#print axioms HiaCoreSyntaxSlice.parallel_kd118_3
#print axioms HiaCoreSyntaxSlice.parallel_kd123_0
#print axioms HiaCoreSyntaxSlice.parallel_kd123_1
#print axioms HiaCoreSyntaxSlice.parallel_kd123_2
#print axioms HiaCoreSyntaxSlice.parallel_kd123_3
#print axioms HiaCoreSyntaxSlice.parallel_kd135_0
#print axioms HiaCoreSyntaxSlice.parallel_kd135_1
#print axioms HiaCoreSyntaxSlice.parallel_kd135_2
#print axioms HiaCoreSyntaxSlice.parallel_kd135_3
#print axioms HiaCoreSyntaxSlice.parallel_kd140_0
#print axioms HiaCoreSyntaxSlice.parallel_kd140_1
#print axioms HiaCoreSyntaxSlice.parallel_kd140_2
#print axioms HiaCoreSyntaxSlice.parallel_kd140_3
#print axioms HiaCoreSyntaxSlice.parallel_kd145_0
#print axioms HiaCoreSyntaxSlice.parallel_kd145_1
#print axioms HiaCoreSyntaxSlice.parallel_kd145_2
#print axioms HiaCoreSyntaxSlice.parallel_kd145_3
#print axioms HiaCoreSyntaxSlice.parallel_kd3_0
#print axioms HiaCoreSyntaxSlice.parallel_kd3_1
#print axioms HiaCoreSyntaxSlice.parallel_kd3_2
#print axioms HiaCoreSyntaxSlice.parallel_kd3_3
#print axioms HiaCoreSyntaxSlice.parallel_kd3_4
#print axioms HiaCoreSyntaxSlice.parallel_kd3_5
#print axioms HiaCoreSyntaxSlice.parallel_kp0_0
#print axioms HiaCoreSyntaxSlice.parallel_kp0_1
#print axioms HiaCoreSyntaxSlice.parallel_kp0_2
#print axioms HiaCoreSyntaxSlice.parallel_kp0_3
#print axioms HiaCoreSyntaxSlice.parallel_kp118_0
#print axioms HiaCoreSyntaxSlice.parallel_kp118_1
#print axioms HiaCoreSyntaxSlice.parallel_kp118_2
#print axioms HiaCoreSyntaxSlice.parallel_kp118_3
#print axioms HiaCoreSyntaxSlice.parallel_kp123_0
#print axioms HiaCoreSyntaxSlice.parallel_kp123_1
#print axioms HiaCoreSyntaxSlice.parallel_kp123_2
#print axioms HiaCoreSyntaxSlice.parallel_kp123_3
#print axioms HiaCoreSyntaxSlice.parallel_kp135_0
#print axioms HiaCoreSyntaxSlice.parallel_kp135_1
#print axioms HiaCoreSyntaxSlice.parallel_kp135_2
#print axioms HiaCoreSyntaxSlice.parallel_kp135_3
#print axioms HiaCoreSyntaxSlice.parallel_kp140_0
#print axioms HiaCoreSyntaxSlice.parallel_kp140_1
#print axioms HiaCoreSyntaxSlice.parallel_kp140_2
#print axioms HiaCoreSyntaxSlice.parallel_kp140_3
#print axioms HiaCoreSyntaxSlice.parallel_kp145_0
#print axioms HiaCoreSyntaxSlice.parallel_kp145_1
#print axioms HiaCoreSyntaxSlice.parallel_kp145_2
#print axioms HiaCoreSyntaxSlice.parallel_kp145_3
#print axioms HiaCoreSyntaxSlice.parallel_kp3_0
#print axioms HiaCoreSyntaxSlice.parallel_kp3_1
#print axioms HiaCoreSyntaxSlice.parallel_kp3_2
#print axioms HiaCoreSyntaxSlice.parallel_kp3_3
#print axioms HiaCoreSyntaxSlice.parallel_kp3_4
#print axioms HiaCoreSyntaxSlice.parallel_kp3_5
#print axioms HiaCoreSyntaxSlice.parallel_length
#print axioms HiaCoreSyntaxSlice.parallel_o0
#print axioms HiaCoreSyntaxSlice.parallel_o113
#print axioms HiaCoreSyntaxSlice.parallel_o118
#print axioms HiaCoreSyntaxSlice.parallel_o123
#print axioms HiaCoreSyntaxSlice.parallel_o135
#print axioms HiaCoreSyntaxSlice.parallel_o140
#print axioms HiaCoreSyntaxSlice.parallel_o145
#print axioms HiaCoreSyntaxSlice.parallel_o3
#print axioms HiaCoreSyntaxSlice.parallel_p0
#print axioms HiaCoreSyntaxSlice.parallel_p113
#print axioms HiaCoreSyntaxSlice.parallel_p118
#print axioms HiaCoreSyntaxSlice.parallel_p119
#print axioms HiaCoreSyntaxSlice.parallel_p120
#print axioms HiaCoreSyntaxSlice.parallel_p121
#print axioms HiaCoreSyntaxSlice.parallel_p122
#print axioms HiaCoreSyntaxSlice.parallel_p123
#print axioms HiaCoreSyntaxSlice.parallel_p124
#print axioms HiaCoreSyntaxSlice.parallel_p125
#print axioms HiaCoreSyntaxSlice.parallel_p126
#print axioms HiaCoreSyntaxSlice.parallel_p127
#print axioms HiaCoreSyntaxSlice.parallel_p128
#print axioms HiaCoreSyntaxSlice.parallel_p129
#print axioms HiaCoreSyntaxSlice.parallel_p130
#print axioms HiaCoreSyntaxSlice.parallel_p131
#print axioms HiaCoreSyntaxSlice.parallel_p132
#print axioms HiaCoreSyntaxSlice.parallel_p133
#print axioms HiaCoreSyntaxSlice.parallel_p134
#print axioms HiaCoreSyntaxSlice.parallel_p135
#print axioms HiaCoreSyntaxSlice.parallel_p136
#print axioms HiaCoreSyntaxSlice.parallel_p137
#print axioms HiaCoreSyntaxSlice.parallel_p138
#print axioms HiaCoreSyntaxSlice.parallel_p139
#print axioms HiaCoreSyntaxSlice.parallel_p140
#print axioms HiaCoreSyntaxSlice.parallel_p141
#print axioms HiaCoreSyntaxSlice.parallel_p142
#print axioms HiaCoreSyntaxSlice.parallel_p143
#print axioms HiaCoreSyntaxSlice.parallel_p144
#print axioms HiaCoreSyntaxSlice.parallel_p145
#print axioms HiaCoreSyntaxSlice.parallel_p146
#print axioms HiaCoreSyntaxSlice.parallel_p147
#print axioms HiaCoreSyntaxSlice.parallel_p148
#print axioms HiaCoreSyntaxSlice.parallel_p149
#print axioms HiaCoreSyntaxSlice.parallel_p150
#print axioms HiaCoreSyntaxSlice.parallel_p151
#print axioms HiaCoreSyntaxSlice.parallel_p152
#print axioms HiaCoreSyntaxSlice.parallel_p153
#print axioms HiaCoreSyntaxSlice.parallel_p154
#print axioms HiaCoreSyntaxSlice.parallel_p155
#print axioms HiaCoreSyntaxSlice.parallel_p156
#print axioms HiaCoreSyntaxSlice.parallel_p2
#print axioms HiaCoreSyntaxSlice.parallel_p3
#print axioms HiaCoreSyntaxSlice.parallel_p4
#print axioms HiaCoreSyntaxSlice.parallel_parsed
#print axioms HiaCoreSyntaxSlice.parallel_pl0_0
#print axioms HiaCoreSyntaxSlice.parallel_pl0_1
#print axioms HiaCoreSyntaxSlice.parallel_pl0_2
#print axioms HiaCoreSyntaxSlice.parallel_pl0_3
#print axioms HiaCoreSyntaxSlice.parallel_pl118_0
#print axioms HiaCoreSyntaxSlice.parallel_pl118_1
#print axioms HiaCoreSyntaxSlice.parallel_pl118_2
#print axioms HiaCoreSyntaxSlice.parallel_pl118_3
#print axioms HiaCoreSyntaxSlice.parallel_pl123_0
#print axioms HiaCoreSyntaxSlice.parallel_pl123_1
#print axioms HiaCoreSyntaxSlice.parallel_pl123_2
#print axioms HiaCoreSyntaxSlice.parallel_pl123_3
#print axioms HiaCoreSyntaxSlice.parallel_pl125_0
#print axioms HiaCoreSyntaxSlice.parallel_pl125_1
#print axioms HiaCoreSyntaxSlice.parallel_pl125_2
#print axioms HiaCoreSyntaxSlice.parallel_pl125_3
#print axioms HiaCoreSyntaxSlice.parallel_pl125_4
#print axioms HiaCoreSyntaxSlice.parallel_pl125_5
#print axioms HiaCoreSyntaxSlice.parallel_pl125_6
#print axioms HiaCoreSyntaxSlice.parallel_pl135_0
#print axioms HiaCoreSyntaxSlice.parallel_pl135_1
#print axioms HiaCoreSyntaxSlice.parallel_pl135_2
#print axioms HiaCoreSyntaxSlice.parallel_pl135_3
#print axioms HiaCoreSyntaxSlice.parallel_pl140_0
#print axioms HiaCoreSyntaxSlice.parallel_pl140_1
#print axioms HiaCoreSyntaxSlice.parallel_pl140_2
#print axioms HiaCoreSyntaxSlice.parallel_pl140_3
#print axioms HiaCoreSyntaxSlice.parallel_pl145_0
#print axioms HiaCoreSyntaxSlice.parallel_pl145_1
#print axioms HiaCoreSyntaxSlice.parallel_pl145_2
#print axioms HiaCoreSyntaxSlice.parallel_pl145_3
#print axioms HiaCoreSyntaxSlice.parallel_pl2_0
#print axioms HiaCoreSyntaxSlice.parallel_pl3_0
#print axioms HiaCoreSyntaxSlice.parallel_pl3_1
#print axioms HiaCoreSyntaxSlice.parallel_pl3_2
#print axioms HiaCoreSyntaxSlice.parallel_pl3_3
#print axioms HiaCoreSyntaxSlice.parallel_pl3_4
#print axioms HiaCoreSyntaxSlice.parallel_pl3_5
#print axioms HiaCoreSyntaxSlice.parallel_pl4_0
#print axioms HiaCoreSyntaxSlice.parallel_pl4_1
#print axioms HiaCoreSyntaxSlice.parallel_pl4_10
#print axioms HiaCoreSyntaxSlice.parallel_pl4_11
#print axioms HiaCoreSyntaxSlice.parallel_pl4_12
#print axioms HiaCoreSyntaxSlice.parallel_pl4_13
#print axioms HiaCoreSyntaxSlice.parallel_pl4_14
#print axioms HiaCoreSyntaxSlice.parallel_pl4_15
#print axioms HiaCoreSyntaxSlice.parallel_pl4_16
#print axioms HiaCoreSyntaxSlice.parallel_pl4_17
#print axioms HiaCoreSyntaxSlice.parallel_pl4_18
#print axioms HiaCoreSyntaxSlice.parallel_pl4_19
#print axioms HiaCoreSyntaxSlice.parallel_pl4_2
#print axioms HiaCoreSyntaxSlice.parallel_pl4_20
#print axioms HiaCoreSyntaxSlice.parallel_pl4_3
#print axioms HiaCoreSyntaxSlice.parallel_pl4_4
#print axioms HiaCoreSyntaxSlice.parallel_pl4_5
#print axioms HiaCoreSyntaxSlice.parallel_pl4_6
#print axioms HiaCoreSyntaxSlice.parallel_pl4_7
#print axioms HiaCoreSyntaxSlice.parallel_pl4_8
#print axioms HiaCoreSyntaxSlice.parallel_pl4_9
#print axioms HiaCoreSyntaxSlice.parallel_s0
#print axioms HiaCoreSyntaxSlice.parallel_s113
#print axioms HiaCoreSyntaxSlice.parallel_s118
#print axioms HiaCoreSyntaxSlice.parallel_s119
#print axioms HiaCoreSyntaxSlice.parallel_s120
#print axioms HiaCoreSyntaxSlice.parallel_s121
#print axioms HiaCoreSyntaxSlice.parallel_s122
#print axioms HiaCoreSyntaxSlice.parallel_s123
#print axioms HiaCoreSyntaxSlice.parallel_s124
#print axioms HiaCoreSyntaxSlice.parallel_s125
#print axioms HiaCoreSyntaxSlice.parallel_s126
#print axioms HiaCoreSyntaxSlice.parallel_s127
#print axioms HiaCoreSyntaxSlice.parallel_s128
#print axioms HiaCoreSyntaxSlice.parallel_s129
#print axioms HiaCoreSyntaxSlice.parallel_s130
#print axioms HiaCoreSyntaxSlice.parallel_s131
#print axioms HiaCoreSyntaxSlice.parallel_s132
#print axioms HiaCoreSyntaxSlice.parallel_s133
#print axioms HiaCoreSyntaxSlice.parallel_s134
#print axioms HiaCoreSyntaxSlice.parallel_s135
#print axioms HiaCoreSyntaxSlice.parallel_s136
#print axioms HiaCoreSyntaxSlice.parallel_s137
#print axioms HiaCoreSyntaxSlice.parallel_s138
#print axioms HiaCoreSyntaxSlice.parallel_s139
#print axioms HiaCoreSyntaxSlice.parallel_s140
#print axioms HiaCoreSyntaxSlice.parallel_s141
#print axioms HiaCoreSyntaxSlice.parallel_s142
#print axioms HiaCoreSyntaxSlice.parallel_s143
#print axioms HiaCoreSyntaxSlice.parallel_s144
#print axioms HiaCoreSyntaxSlice.parallel_s145
#print axioms HiaCoreSyntaxSlice.parallel_s146
#print axioms HiaCoreSyntaxSlice.parallel_s147
#print axioms HiaCoreSyntaxSlice.parallel_s148
#print axioms HiaCoreSyntaxSlice.parallel_s149
#print axioms HiaCoreSyntaxSlice.parallel_s150
#print axioms HiaCoreSyntaxSlice.parallel_s151
#print axioms HiaCoreSyntaxSlice.parallel_s152
#print axioms HiaCoreSyntaxSlice.parallel_s153
#print axioms HiaCoreSyntaxSlice.parallel_s154
#print axioms HiaCoreSyntaxSlice.parallel_s155
#print axioms HiaCoreSyntaxSlice.parallel_s156
#print axioms HiaCoreSyntaxSlice.parallel_s2
#print axioms HiaCoreSyntaxSlice.parallel_s3
#print axioms HiaCoreSyntaxSlice.parallel_s4
#print axioms HiaCoreSyntaxSlice.parallel_serialized
#print axioms HiaCoreSyntaxSlice.parallel_sl0_0
#print axioms HiaCoreSyntaxSlice.parallel_sl0_1
#print axioms HiaCoreSyntaxSlice.parallel_sl0_2
#print axioms HiaCoreSyntaxSlice.parallel_sl0_3
#print axioms HiaCoreSyntaxSlice.parallel_sl118_0
#print axioms HiaCoreSyntaxSlice.parallel_sl118_1
#print axioms HiaCoreSyntaxSlice.parallel_sl118_2
#print axioms HiaCoreSyntaxSlice.parallel_sl118_3
#print axioms HiaCoreSyntaxSlice.parallel_sl123_0
#print axioms HiaCoreSyntaxSlice.parallel_sl123_1
#print axioms HiaCoreSyntaxSlice.parallel_sl123_2
#print axioms HiaCoreSyntaxSlice.parallel_sl123_3
#print axioms HiaCoreSyntaxSlice.parallel_sl125_0
#print axioms HiaCoreSyntaxSlice.parallel_sl125_1
#print axioms HiaCoreSyntaxSlice.parallel_sl125_2
#print axioms HiaCoreSyntaxSlice.parallel_sl125_3
#print axioms HiaCoreSyntaxSlice.parallel_sl125_4
#print axioms HiaCoreSyntaxSlice.parallel_sl125_5
#print axioms HiaCoreSyntaxSlice.parallel_sl125_6
#print axioms HiaCoreSyntaxSlice.parallel_sl135_0
#print axioms HiaCoreSyntaxSlice.parallel_sl135_1
#print axioms HiaCoreSyntaxSlice.parallel_sl135_2
#print axioms HiaCoreSyntaxSlice.parallel_sl135_3
#print axioms HiaCoreSyntaxSlice.parallel_sl140_0
#print axioms HiaCoreSyntaxSlice.parallel_sl140_1
#print axioms HiaCoreSyntaxSlice.parallel_sl140_2
#print axioms HiaCoreSyntaxSlice.parallel_sl140_3
#print axioms HiaCoreSyntaxSlice.parallel_sl145_0
#print axioms HiaCoreSyntaxSlice.parallel_sl145_1
#print axioms HiaCoreSyntaxSlice.parallel_sl145_2
#print axioms HiaCoreSyntaxSlice.parallel_sl145_3
#print axioms HiaCoreSyntaxSlice.parallel_sl2_0
#print axioms HiaCoreSyntaxSlice.parallel_sl3_0
#print axioms HiaCoreSyntaxSlice.parallel_sl3_1
#print axioms HiaCoreSyntaxSlice.parallel_sl3_2
#print axioms HiaCoreSyntaxSlice.parallel_sl3_3
#print axioms HiaCoreSyntaxSlice.parallel_sl3_4
#print axioms HiaCoreSyntaxSlice.parallel_sl3_5
#print axioms HiaCoreSyntaxSlice.parallel_sl4_0
#print axioms HiaCoreSyntaxSlice.parallel_sl4_1
#print axioms HiaCoreSyntaxSlice.parallel_sl4_10
#print axioms HiaCoreSyntaxSlice.parallel_sl4_11
#print axioms HiaCoreSyntaxSlice.parallel_sl4_12
#print axioms HiaCoreSyntaxSlice.parallel_sl4_13
#print axioms HiaCoreSyntaxSlice.parallel_sl4_14
#print axioms HiaCoreSyntaxSlice.parallel_sl4_15
#print axioms HiaCoreSyntaxSlice.parallel_sl4_16
#print axioms HiaCoreSyntaxSlice.parallel_sl4_17
#print axioms HiaCoreSyntaxSlice.parallel_sl4_18
#print axioms HiaCoreSyntaxSlice.parallel_sl4_19
#print axioms HiaCoreSyntaxSlice.parallel_sl4_2
#print axioms HiaCoreSyntaxSlice.parallel_sl4_20
#print axioms HiaCoreSyntaxSlice.parallel_sl4_3
#print axioms HiaCoreSyntaxSlice.parallel_sl4_4
#print axioms HiaCoreSyntaxSlice.parallel_sl4_5
#print axioms HiaCoreSyntaxSlice.parallel_sl4_6
#print axioms HiaCoreSyntaxSlice.parallel_sl4_7
#print axioms HiaCoreSyntaxSlice.parallel_sl4_8
#print axioms HiaCoreSyntaxSlice.parallel_sl4_9
#print axioms HiaCoreSyntaxSlice.parallel_transport
