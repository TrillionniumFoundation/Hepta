import HiaSyntaxResearch.CertPart07
-- SEVEN_CERTIFICATE_CONNECTIONS_V1

namespace HiaCoreSyntaxSlice

open HiaGuardedUsizeSlice

/-- Names are exact ASCII byte sequences, never hashes or normalized names. -/
def ascii (s : String) : List Nat := s.toList.map Char.toNat

def field (raw : Raw) (key : String) : Raw :=
  match raw with
  | .obj fields => ((fields.find? (fun pair => pair.1 == ascii key)).map Prod.snd).getD (.obj [])
  | _ => .obj []

def array (raw : Raw) : List Raw :=
  match raw with
  | .arr items => items
  | _ => []

def bytes (raw : Raw) : List Nat :=
  match raw with
  | .str value => value
  | _ => []

def number (raw : Raw) : Nat :=
  match raw with
  | .num value => value
  | _ => 0

def isString : Raw → Bool
  | .str _ => true
  | _ => false

def isObject : Raw → Bool
  | .obj _ => true
  | _ => false

def isArray : Raw → Bool
  | .arr _ => true
  | _ => false

def keysAre (raw : Raw) (keys : List String) : Bool :=
  match raw with
  | .obj fields => decide (fields.map Prod.fst = keys.map ascii)
  | _ => false

def rawAt (items : List Raw) (index : Nat) : Raw := items[index]?.getD (.obj [])

def position (name : List Nat) : List (List Nat) → Nat
  | [] => 0
  | first :: rest => if name = first then 0 else position name rest + 1

def names (items : List Raw) : List (List Nat) :=
  items.map (fun item => bytes (field item "name"))

def goodParam (raw : Raw) : Bool :=
  keysAre raw ["name", "type"] && isString (field raw "name") &&
    isString (field raw "type")

def goodParams (raw : Raw) : Bool :=
  isArray raw && (array raw).all goodParam

def goodStrings (raw : Raw) : Bool :=
  isArray raw && (array raw).all isString

def goodOp (raw : Raw) : Bool :=
  keysAre raw ["args", "attrs", "op", "out"] &&
    goodStrings (field raw "args") && isObject (field raw "attrs") &&
    isString (field raw "op") && goodParams (field raw "out")

def blockBinders (raw : Raw) : List Raw :=
  array (field raw "params") ++
    (array (field raw "ops")).flatMap (fun op => array (field op "out"))

/-- Unknown operations remain inert syntax. Their envelope and binders, not
    their execution behavior, are checked. -/
def goodBlock (raw : Raw) : Bool :=
  keysAre raw ["id", "ops", "params", "term"] &&
    isString (field raw "id") && goodParams (field raw "params") &&
    isArray (field raw "ops") && (array (field raw "ops")).all goodOp &&
    isObject (field raw "term") &&
    decide ((names (blockBinders raw)).Nodup) -- MUTATION_SITE_BINDER_UNIQUENESS

def goodFunction (raw : Raw) : Bool :=
  keysAre raw ["blocks", "effects", "entry", "name", "params", "returns"] &&
    isString (field raw "name") && isString (field raw "entry") &&
    goodStrings (field raw "effects") && goodParams (field raw "params") &&
    decide ((names (array (field raw "params"))).Nodup) &&
    goodStrings (field raw "returns") && isArray (field raw "blocks") &&
    decide ((array (field raw "blocks")).length ≤ 128) &&
    (array (field raw "blocks")).all goodBlock &&
    decide (((array (field raw "blocks")).map (fun b => bytes (field b "id"))).Nodup)

def goodProgram (raw : Raw) : Bool :=
  keysAre raw ["exports", "functions", "module", "schema"] &&
    goodStrings (field raw "exports") && isString (field raw "module") &&
    decide (field raw "schema" = .str (ascii "hepta.hia.program.v1")) &&
    isArray (field raw "functions") &&
    (array (field raw "functions")).all goodFunction &&
    decide ((names (array (field raw "functions"))).Nodup)

structure Hint where
  functionIndex : Nat
  headerIndex : Nat
  targetIndex : Nat
  addOrdinal : Nat
  bodyIndex : List Nat
  bodyExtent : List Nat
  deriving DecidableEq, Repr

abbrev Locator := Hint

def selectedFunction (raw : Raw) (hint : Hint) : Raw :=
  rawAt (array (field raw "functions")) hint.functionIndex

def selectedHeader (raw : Raw) (hint : Hint) : Raw :=
  rawAt (array (field (selectedFunction raw hint) "blocks")) hint.headerIndex

def selectedTarget (raw : Raw) (hint : Hint) : Raw :=
  rawAt (array (field (selectedFunction raw hint) "blocks")) hint.targetIndex

def definitionOrdinal (name : List Nat) : List Raw → Nat
  | [] => 0
  | op :: rest =>
    if name ∈ names (array (field op "out")) then 0
    else definitionOrdinal name rest + 1

def addTag (raw : Raw) : AddOp :=
  if raw = .str (ascii "int.add.checked") then .checked
  else if raw = .str (ascii "int.add.wrap") then .wrapping else .other

/-- This proposal function reads syntax, not an expected descriptor. Its defaults
    are rejected by the independent relation's shape, bounds and scope checks. -/
def reconstruct (raw : Raw) (hint : Hint) : Descriptor :=
  let header := selectedHeader raw hint
  let target := selectedTarget raw hint
  let compare := rawAt (array (field header "ops")) 0
  let sourceNames := names (blockBinders header)
  let compareArgs := (array (field compare "args")).map bytes
  let edge := field (field header "term") "then" -- MUTATION_SITE_SELECT_THEN
  let targetParams := array (field target "params")
  let targetNames := names targetParams
  let ops := array (field target "ops")
  let add := rawAt ops hint.addOrdinal
  let args := (array (field add "args")).map bytes
  let literalOrdinal := definitionOrdinal (args[1]?.getD []) ops
  let literal := rawAt ops literalOrdinal
  { sourceIndex := position (compareArgs[0]?.getD []) sourceNames -- MUTATION_SITE_SOURCE_POSITION
    sourceExtent := position (compareArgs[1]?.getD []) sourceNames
    compareOutput := position (bytes (field (rawAt (array (field compare "out")) 0) "name")) sourceNames
    branchCondition := position (bytes (field (field header "term") "cond")) sourceNames
    indexType := if field (rawAt (blockBinders header) (position (compareArgs[0]?.getD []) sourceNames)) "type" = .str (ascii "usize") then .usize else .other
    extentType := if field (rawAt (blockBinders header) (position (compareArgs[1]?.getD []) sourceNames)) "type" = .str (ascii "usize") then .usize else .other
    compareOp := if field compare "op" = .str (ascii "compare.lt") then .lt else .other
    selectedArm := .thenArm
    incoming := (array (field edge "args")).map (fun arg => position (bytes arg) sourceNames)
    indexSlot := position hint.bodyIndex targetNames
    extentSlot := position hint.bodyExtent targetNames
    addIndexSlot := position (args[0]?.getD []) targetNames
    addOp := addTag (field add "op")
    addType := if field (rawAt (array (field add "out")) 0) "type" = .str (ascii "usize") then .usize else .other
    literalType := if field (rawAt (array (field literal "out")) 0) "type" = .str (ascii "usize") then .usize else .other
    literalValue := number (field (field literal "attrs") "value")
    literalOrdinal := literalOrdinal
    addOrdinal := hint.addOrdinal }

/-- Declarative raw syntax contract, independent of `extract` and `reconstruct`.
    Every ordered edge argument is retained, including opaque/resource values.
    No condition below claims normal arrival through the target body. -/
def SliceSyntaxRelation (raw : Raw) (hint : Hint) (d : Descriptor) : Prop :=
  let functions := array (field raw "functions")
  let fn := rawAt functions hint.functionIndex
  let blocks := array (field fn "blocks")
  let header := rawAt blocks hint.headerIndex
  let target := rawAt blocks hint.targetIndex
  let headerParams := array (field header "params")
  let compare := rawAt (array (field header "ops")) 0
  let sourceBinders := blockBinders header
  let sourceNames := names sourceBinders
  let targetParams := array (field target "params")
  let targetNames := names targetParams
  let term := field header "term"
  let thenEdge := field term "then"
  let elseEdge := field term "else"
  let edgeArgs := array (field thenEdge "args")
  let ops := array (field target "ops")
  let add := rawAt ops d.addOrdinal
  let literal := rawAt ops d.literalOrdinal
  withinBounds raw = true ∧
  goodProgram raw = true ∧
  hint.functionIndex < functions.length ∧
  hint.headerIndex < blocks.length ∧ hint.targetIndex < blocks.length ∧
  array (field header "ops") = [compare] ∧
  field compare "op" = .str (ascii "compare.lt") ∧
  field compare "attrs" = .obj [] ∧
  field compare "args" = .arr [.str (sourceNames[d.sourceIndex]?.getD []),
    .str (sourceNames[d.sourceExtent]?.getD [])] ∧
  d.sourceIndex < headerParams.length ∧ d.sourceExtent < headerParams.length ∧
  field (rawAt sourceBinders d.sourceIndex) "type" = .str (ascii "usize") ∧
  field (rawAt sourceBinders d.sourceExtent) "type" = .str (ascii "usize") ∧
  d.compareOutput = headerParams.length ∧
  field compare "out" = .arr [.obj [(ascii "name", .str (sourceNames[d.compareOutput]?.getD [])),
    (ascii "type", .str (ascii "bool"))]] ∧
  keysAre term ["cond", "else", "op", "then"] = true ∧
  field term "op" = .str (ascii "branch") ∧
  field term "cond" = .str (sourceNames[d.compareOutput]?.getD []) ∧
  keysAre thenEdge ["args", "target"] = true ∧
  keysAre elseEdge ["args", "target"] = true ∧
  goodStrings (field elseEdge "args") = true ∧ isString (field elseEdge "target") = true ∧
  field thenEdge "target" = field target "id" ∧
  goodStrings (field thenEdge "args") = true ∧
  edgeArgs.length = targetParams.length ∧
  d.incoming.length = edgeArgs.length ∧
  d.incoming.all (fun i => decide (i < sourceNames.length)) = true ∧
  edgeArgs = d.incoming.map (fun i => Raw.str (sourceNames[i]?.getD [])) ∧
  hint.bodyIndex ∈ targetNames ∧ hint.bodyExtent ∈ targetNames ∧
  targetNames[d.indexSlot]? = some hint.bodyIndex ∧
  targetNames[d.extentSlot]? = some hint.bodyExtent ∧
  field (rawAt targetParams d.indexSlot) "type" = .str (ascii "usize") ∧
  field (rawAt targetParams d.extentSlot) "type" = .str (ascii "usize") ∧
  d.incoming[d.indexSlot]? = some d.sourceIndex ∧
  d.incoming[d.extentSlot]? = some d.sourceExtent ∧
  d.addOrdinal = hint.addOrdinal ∧ d.addOrdinal < ops.length ∧
  d.literalOrdinal < d.addOrdinal ∧
  field add "args" = .arr [.str hint.bodyIndex,
    .str (bytes (field (rawAt (array (field literal "out")) 0) "name"))] ∧
  field add "attrs" = .obj [] ∧
  (field add "op" = .str (ascii "int.add.checked") ∧ d.addOp = .checked ∨
   field add "op" = .str (ascii "int.add.wrap") ∧ d.addOp = .wrapping) ∧
  (array (field add "out")).length = 1 ∧
  field (rawAt (array (field add "out")) 0) "type" = .str (ascii "usize") ∧
  field literal "op" = .str (ascii "const") ∧
  field literal "args" = .arr [] ∧
  field literal "attrs" = .obj [(ascii "value", .num 1)] ∧
  (array (field literal "out")).length = 1 ∧
  field (rawAt (array (field literal "out")) 0) "type" = .str (ascii "usize") ∧
  d.branchCondition = d.compareOutput ∧ d.indexType = .usize ∧ d.extentType = .usize ∧
  d.compareOp = .lt ∧ d.selectedArm = .thenArm ∧ d.addIndexSlot = d.indexSlot ∧
  d.addType = .usize ∧ d.literalType = .usize ∧ d.literalValue = 1

/-- Assemble small decisions without asking typeclass search to synthesize
    the entire structural contract in one recursive search. -/
def andDecision {p q : Prop} (left : Decidable p) (right : Decidable q) :
    Decidable (p ∧ q) :=
  match left, right with
  | isTrue hp, isTrue hq => isTrue ⟨hp, hq⟩
  | isFalse hp, _ => isFalse (fun both => hp both.1)
  | _, isFalse hq => isFalse (fun both => hq both.2)

instance (raw : Raw) (hint : Hint) (d : Descriptor) : Decidable (SliceSyntaxRelation raw hint d) := by
  dsimp only [SliceSyntaxRelation]
  exact
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    andDecision (by infer_instance) (
    (by infer_instance))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

/-- Successful reconstruction requires the independently specified contract. -/
def extract (raw : Raw) (hint : Hint) : Option Descriptor :=
  let proposed := reconstruct raw hint
  if SliceSyntaxRelation raw hint proposed then some proposed else none

theorem extract_sound (raw : Raw) (hint : Hint) (d : Descriptor)
    (extracted : extract raw hint = some d) : SliceSyntaxRelation raw hint d := by
  by_cases accepted : SliceSyntaxRelation raw hint (reconstruct raw hint)
  · have same : reconstruct raw hint = d := by
      simpa [extract, accepted] using extracted
    rw [← same]
    exact accepted
  · simp [extract, accepted] at extracted

/-- Composition with the existing projection theorem. Exact byte binding and
    transport determinacy are separate certificate obligations. -/
theorem extracted_successor (raw : Raw) (hint : Hint) (d : Descriptor)
    (maximum : Nat) (env : Env)
    (extracted : extract raw hint = some d)
    (valid : Valid d) (guard : evalGuard maximum d env = some true) :
    SliceSyntaxRelation raw hint d ∧
    ∃ index extent,
      readUsize maximum env d.sourceIndex = some index ∧
      readUsize maximum env d.sourceExtent = some extent ∧
      evalSelectedStep maximum d env = some (index + 1) ∧
      index + 1 ≤ extent ∧ extent ≤ maximum ∧ index + 1 ≤ maximum := by
  exact ⟨extract_sound raw hint d extracted,
    selected_successor maximum d env valid guard⟩


end HiaCoreSyntaxSlice

namespace HiaCoreSyntaxSlice
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice

namespace HiaCoreSyntaxSlice
def parallelHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice

namespace HiaCoreSyntaxSlice.WrongPhi
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice.WrongPhi

namespace HiaCoreSyntaxSlice.LiteralTwo
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice.LiteralTwo

namespace HiaCoreSyntaxSlice.WrongCondition
def linearHint : Hint := { functionIndex := 0, headerIndex := 7, targetIndex := 8, addOrdinal := 10, bodyIndex := [100,103,95,118,95,54,49], bodyExtent := [100,103,95,118,95,54,48] }
end HiaCoreSyntaxSlice.WrongCondition

namespace HiaCoreSyntaxSlice
theorem linear_extraction : extract linearRaw linearHint = some HiaGuardedUsizeSlice.linear_0 := by decide +kernel
theorem linear_relation : SliceSyntaxRelation linearRaw linearHint HiaGuardedUsizeSlice.linear_0 :=
  extract_sound linearRaw linearHint HiaGuardedUsizeSlice.linear_0 linear_extraction
theorem parallel_extraction : extract parallelRaw parallelHint = some HiaGuardedUsizeSlice.linear_0 := by decide +kernel
theorem reject_stale_descriptor : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.linearRaw HiaCoreSyntaxSlice.linearHint = some { HiaGuardedUsizeSlice.linear_0 with literalValue := 2 }) := by decide +kernel
theorem reject_wrong_phi : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.WrongPhi.linearRaw HiaCoreSyntaxSlice.WrongPhi.linearHint = some HiaGuardedUsizeSlice.linear_0) := by decide +kernel
theorem reject_literal_two : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.LiteralTwo.linearRaw HiaCoreSyntaxSlice.LiteralTwo.linearHint = some HiaGuardedUsizeSlice.linear_0) := by decide +kernel
theorem reject_wrong_condition : ¬ (HiaCoreSyntaxSlice.extract HiaCoreSyntaxSlice.WrongCondition.linearRaw HiaCoreSyntaxSlice.WrongCondition.linearHint = some HiaGuardedUsizeSlice.linear_0) := by decide +kernel
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.checkedEncode_determinate
#print axioms HiaCoreSyntaxSlice.checkedEncode_of_parts
#print axioms HiaCoreSyntaxSlice.checkedEncode_roundtrip
#print axioms HiaCoreSyntaxSlice.extract_sound
#print axioms HiaCoreSyntaxSlice.extracted_successor
#print axioms HiaCoreSyntaxSlice.linear_extraction
#print axioms HiaCoreSyntaxSlice.linear_relation
#print axioms HiaCoreSyntaxSlice.linear_transport
#print axioms HiaCoreSyntaxSlice.parallel_extraction
#print axioms HiaCoreSyntaxSlice.parallel_transport
#print axioms HiaCoreSyntaxSlice.reject_literal_two
#print axioms HiaCoreSyntaxSlice.reject_stale_descriptor
#print axioms HiaCoreSyntaxSlice.reject_wrong_condition
#print axioms HiaCoreSyntaxSlice.reject_wrong_phi
#print axioms HiaGuardedUsizeSlice.affine_0_small
#print axioms HiaGuardedUsizeSlice.affine_0_upper
#print axioms HiaGuardedUsizeSlice.affine_0_valid
#print axioms HiaGuardedUsizeSlice.affine_1_small
#print axioms HiaGuardedUsizeSlice.affine_1_upper
#print axioms HiaGuardedUsizeSlice.affine_1_valid
#print axioms HiaGuardedUsizeSlice.affine_2_small
#print axioms HiaGuardedUsizeSlice.affine_2_upper
#print axioms HiaGuardedUsizeSlice.affine_2_valid
#print axioms HiaGuardedUsizeSlice.affine_3_small
#print axioms HiaGuardedUsizeSlice.affine_3_upper
#print axioms HiaGuardedUsizeSlice.affine_3_valid
#print axioms HiaGuardedUsizeSlice.checked_add_in_range
#print axioms HiaGuardedUsizeSlice.crossed_0_small
#print axioms HiaGuardedUsizeSlice.crossed_0_upper
#print axioms HiaGuardedUsizeSlice.crossed_0_valid
#print axioms HiaGuardedUsizeSlice.false_guard_no_step
#print axioms HiaGuardedUsizeSlice.guard_values
#print axioms HiaGuardedUsizeSlice.guarded_successors
#print axioms HiaGuardedUsizeSlice.invalid_no_step
#print axioms HiaGuardedUsizeSlice.linear_0_small
#print axioms HiaGuardedUsizeSlice.linear_0_upper
#print axioms HiaGuardedUsizeSlice.linear_0_valid
#print axioms HiaGuardedUsizeSlice.linear_1_small
#print axioms HiaGuardedUsizeSlice.linear_1_upper
#print axioms HiaGuardedUsizeSlice.linear_1_valid
#print axioms HiaGuardedUsizeSlice.linear_2_small
#print axioms HiaGuardedUsizeSlice.linear_2_upper
#print axioms HiaGuardedUsizeSlice.linear_2_valid
#print axioms HiaGuardedUsizeSlice.linear_3_small
#print axioms HiaGuardedUsizeSlice.linear_3_upper
#print axioms HiaGuardedUsizeSlice.linear_3_valid
#print axioms HiaGuardedUsizeSlice.no_step_false_guard
#print axioms HiaGuardedUsizeSlice.no_step_missing
#print axioms HiaGuardedUsizeSlice.no_step_opaque
#print axioms HiaGuardedUsizeSlice.no_step_oversized
#print axioms HiaGuardedUsizeSlice.readUsize_bounded
#print axioms HiaGuardedUsizeSlice.readUsize_phi
#print axioms HiaGuardedUsizeSlice.selected_successor
#print axioms HiaGuardedUsizeSlice.wrapping_add_in_range
#print axioms HiaInitializationPrefix.completed_exit_establishes_initialized
#print axioms HiaInitializationPrefix.completed_exit_is_exact_bound
#print axioms HiaInitializationPrefix.completed_fill_independent_of_initial
#print axioms HiaInitializationPrefix.completed_fill_initialized
#print axioms HiaInitializationPrefix.completed_fill_matches_zeroed
#print axioms HiaInitializationPrefix.incomplete_prefix_is_not_full
#print axioms HiaInitializationPrefix.increment_within_limit
#print axioms HiaInitializationPrefix.prefix_invariant
#print axioms HiaInitializationPrefix.prefix_outside
#print axioms HiaInitializationPrefix.prefix_value
#print axioms HiaInitializationPrefix.skipped_zero_stays_uninitialized
#print axioms HiaInitializationPrefix.stride_two_leaves_a_hole
#print axioms HiaInitializationPrefix.write_at_index
#print axioms HiaInitializationPrefix.write_at_other
#print axioms HiaInitializationPrefix.write_extends_prefix
#print axioms HiaInitializationPrefix.zero_prefix
-- SEVEN_CERTIFICATE_REJECTIONS_V1

namespace HiaCoreSyntaxSlice.ChangedByte
def linearBytes : List Nat := [123,34,101,120,112,111,114,116,115,34,58,91,34,99,97,108,99,117,108,97,116,101,34,93,44,34,102,117,110,99,116,105,111,110,115,34,58,91,123,34,98,108,111,99,107,115,34,58,91,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,48,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,116,114,121,95,110,101,119,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,52,34,44,34,100,103,95,118,95,56,34,44,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,57,34,44,34,100,103,95,118,95,49,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,125,125,44,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,48,48,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,34,44,34,100,103,95,118,95,49,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,56,34,93,125,125,44,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,50,53,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,48,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,50,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,50,56,34,44,34,100,103,95,118,95,50,57,34,44,34,100,103,95,118,95,51,50,34,44,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,51,51,34,44,34,100,103,95,118,95,51,52,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,125,125,44,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,51,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,52,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,49,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,53,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,52,54,34,93,125,125,44,123,34,105,100,34,58,34,100,103,95,102,97,115,116,95,48,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,54,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,53,54,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,102,97,115,116,95,49,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,50,34,44,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,51,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,52,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,52,34,44,34,100,103,95,118,95,54,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,54,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,54,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,56,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,44,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,55,34,44,34,100,103,95,118,95,53,56,34,44,34,100,103,95,118,95,53,57,34,44,34,100,103,95,118,95,54,48,34,44,34,100,103,95,118,95,55,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,48,34,125,125,44,123,34,105,100,34,58,34,100,103,95,102,97,115,116,95,50,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,50,34,44,34,100,103,95,118,95,55,51,34,44,34,100,103,95,118,95,55,54,34,44,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,55,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125,125,44,123,34,105,100,34,58,34,100,103,95,102,97,115,116,95,51,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,51,34,44,34,100,103,95,118,95,56,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,56,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,102,97,115,116,95,52,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,49,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,44,34,100,103,95,118,95,57,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,50,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,56,34,44,34,100,103,95,118,95,57,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,48,34,44,34,100,103,95,118,95,57,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,53,34,44,34,100,103,95,118,95,56,54,34,44,34,100,103,95,118,95,56,55,34,44,34,100,103,95,118,95,57,52,34,44,34,100,103,95,118,95,56,57,34,44,34,100,103,95,118,95,57,54,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125,125,44,123,34,105,100,34,58,34,100,103,95,102,97,115,116,95,53,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,48,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,48,48,34,93,125,125,44,123,34,105,100,34,58,34,100,103,95,115,108,111,119,95,48,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,56,34,44,34,100,103,95,118,95,49,48,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,57,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,48,57,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,115,108,111,119,95,49,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,53,34,44,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,56,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,55,34,44,34,100,103,95,118,95,49,49,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,57,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,57,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,48,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,49,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,44,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,48,34,44,34,100,103,95,118,95,49,49,49,34,44,34,100,103,95,118,95,49,49,50,34,44,34,100,103,95,118,95,49,49,51,34,44,34,100,103,95,118,95,49,50,51,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,48,34,125,125,44,123,34,105,100,34,58,34,100,103,95,115,108,111,119,95,50,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,57,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,50,53,34,44,34,100,103,95,118,95,49,50,54,34,44,34,100,103,95,118,95,49,50,57,34,44,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,51,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125,125,44,123,34,105,100,34,58,34,100,103,95,115,108,111,119,95,51,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,54,34,44,34,100,103,95,118,95,49,51,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,55,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,51,55,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,115,108,111,119,95,52,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,52,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,44,34,100,103,95,118,95,49,52,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,49,34,44,34,100,103,95,118,95,49,52,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,51,34,44,34,100,103,95,118,95,49,52,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,56,34,44,34,100,103,95,118,95,49,51,57,34,44,34,100,103,95,118,95,49,52,48,34,44,34,100,103,95,118,95,49,52,55,34,44,34,100,103,95,118,95,49,52,50,34,44,34,100,103,95,118,95,49,52,57,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125,125,44,123,34,105,100,34,58,34,100,103,95,115,108,111,119,95,53,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,53,51,34,93,125,125,44,123,34,105,100,34,58,34,100,103,95,103,117,97,114,100,95,48,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,50,34,44,34,100,103,95,118,95,49,54,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,54,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125,125,44,123,34,105,100,34,58,34,100,103,95,103,117,97,114,100,95,49,34,44,34,111,112,115,34,58,91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,55,49,34,44,34,100,103,95,118,95,49,55,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,44,34,116,101,114,109,34,58,123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,55,51,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125,125,93,44,34,101,102,102,101,99,116,115,34,58,91,34,97,108,108,111,99,34,44,34,114,101,97,100,34,44,34,116,114,97,112,34,44,34,119,114,105,116,101,34,93,44,34,101,110,116,114,121,34,58,34,100,103,95,115,104,97,114,101,100,95,48,34,44,34,110,97,109,101,34,58,34,99,97,108,99,117,108,97,116,101,34,44,34,112,97,114,97,109,115,34,58,91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,44,34,114,101,116,117,114,110,115,34,58,91,34,117,54,52,34,93,125,93,44,34,109,111,100,117,108,101,34,58,34,114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114,34,44,34,115,99,104,101,109,97,34,58,34,104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49,34,93]
end HiaCoreSyntaxSlice.ChangedByte

namespace HiaCoreSyntaxSlice
theorem reject_changed_exact_byte : ¬ (HiaCoreSyntaxSlice.checkedEncode HiaCoreSyntaxSlice.linearRaw = some HiaCoreSyntaxSlice.ChangedByte.linearBytes) := by
  rw [HiaCoreSyntaxSlice.linear_transport]
  decide +kernel
theorem reject_duplicate_keys : ¬ (HiaCoreSyntaxSlice.checkedEncode (.obj [([97],.num 0),([97],.num 1)]) = some [123,34,97,34,58,48,44,34,97,34,58,49,125]) := by decide +kernel
theorem reject_unordered_keys : ¬ (HiaCoreSyntaxSlice.checkedEncode (.obj [([98],.num 0),([97],.num 1)]) = some [123,34,98,34,58,48,44,34,97,34,58,49,125]) := by decide +kernel
theorem reject_byte_modulo_alias : ¬ (HiaCoreSyntaxSlice.checkedEncode (.str [256]) = some [34,0,34]) := by decide +kernel
theorem reject_leading_zero : ¬ (HiaCoreSyntaxSlice.decode [48,49] = some (.num 1)) := by decide +kernel
end HiaCoreSyntaxSlice
#print axioms HiaCoreSyntaxSlice.reject_byte_modulo_alias
#print axioms HiaCoreSyntaxSlice.reject_changed_exact_byte
#print axioms HiaCoreSyntaxSlice.reject_duplicate_keys
#print axioms HiaCoreSyntaxSlice.reject_leading_zero
#print axioms HiaCoreSyntaxSlice.reject_unordered_keys
