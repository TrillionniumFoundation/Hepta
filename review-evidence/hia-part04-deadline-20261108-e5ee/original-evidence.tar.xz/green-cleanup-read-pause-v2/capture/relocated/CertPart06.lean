import HiaSyntaxResearch.CertPart05
namespace HiaCoreSyntaxSlice.LiteralTwo
def linear_r63 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b63 : List Nat := linear_g159
theorem mutated_s63 : serializeRaw 4075 27 linear_r63 = some linear_b63 := by decide +kernel
theorem mutated_p63 (tail : List Nat) : parseRaw 4075 27 (linear_b63 ++ tail) = some (linear_r63, tail) := by rfl
def linear_r64 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,53,55]),(.str [100,103,95,118,95,53,56]),(.str [100,103,95,118,95,53,57]),(.str [100,103,95,118,95,54,48]),(.str [100,103,95,118,95,55,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,48]))])
def linear_b64 : List Nat := linear_g162
theorem mutated_s64 : serializeRaw 4074 27 linear_r64 = some linear_b64 := by decide +kernel
theorem mutated_p64 (tail : List Nat) : parseRaw 4074 27 (linear_b64 ++ tail) = some (linear_r64, tail) := by rfl
def linear_k49_0 : List Nat := [105,100]
theorem mutated_kd49_0 : stringBytes linear_k49_0 = true := by decide +kernel
theorem mutated_kp49_0 (tail : List Nat) : parseStringTail (linear_k49_0 ++ (34 :: 58 :: tail)) [] = some (linear_k49_0, 58 :: tail) := by rfl
def linear_k49_1 : List Nat := [111,112,115]
theorem mutated_kd49_1 : stringBytes linear_k49_1 = true := by decide +kernel
theorem mutated_kp49_1 (tail : List Nat) : parseStringTail (linear_k49_1 ++ (34 :: 58 :: tail)) [] = some (linear_k49_1, 58 :: tail) := by rfl
def linear_k49_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd49_2 : stringBytes linear_k49_2 = true := by decide +kernel
theorem mutated_kp49_2 (tail : List Nat) : parseStringTail (linear_k49_2 ++ (34 :: 58 :: tail)) [] = some (linear_k49_2, 58 :: tail) := by rfl
def linear_k49_3 : List Nat := [116,101,114,109]
theorem mutated_kd49_3 : stringBytes linear_k49_3 = true := by decide +kernel
theorem mutated_kp49_3 (tail : List Nat) : parseStringTail (linear_k49_3 ++ (34 :: 58 :: tail)) [] = some (linear_k49_3, 58 :: tail) := by rfl
def linear_l49_3 : List (List Nat × Raw) := [(linear_k49_3, linear_r64)]
def linear_v49_3 : List Nat := linear_g161 ++ linear_b64
theorem mutated_sl49_3 : serializeFields 4075 27 linear_l49_3 = some linear_v49_3 := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4074 27 linear_k49_3 linear_r64 linear_b64 mutated_kd49_3 mutated_s64)
theorem mutated_pl49_3 (tail : List Nat) : parseFields 4075 27 (linear_v49_3 ++ (125 :: tail)) = some (linear_l49_3, tail) := by
  simpa only [linear_l49_3, linear_v49_3, linear_k49_3, linear_g161, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4074 27 (linear_k49_3 ++ (34 :: 58 :: (linear_b64 ++ (125 :: tail)))) linear_k49_3 (linear_b64 ++ (125 :: tail)) tail linear_r64 (mutated_kp49_3 (linear_b64 ++ (125 :: tail))) (mutated_p64 (125 :: tail)))
def linear_l49_2 : List (List Nat × Raw) := (linear_k49_2, linear_r63) :: linear_l49_3
def linear_v49_2 : List Nat := (linear_g158 ++ linear_b63) ++ (44 :: linear_v49_3)
theorem mutated_sl49_2 : serializeFields 4076 27 linear_l49_2 = some linear_v49_2 := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k49_2 linear_r63 (linear_k49_3, linear_r64) [] linear_b63 linear_v49_3 mutated_kd49_2 mutated_s63 mutated_sl49_3)
theorem mutated_pl49_2 (tail : List Nat) : parseFields 4076 27 (linear_v49_2 ++ (125 :: tail)) = some (linear_l49_2, tail) := by
  simpa only [linear_l49_2, linear_v49_2, linear_k49_2, linear_g158, linear_l49_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k49_2 ++ (34 :: 58 :: (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))))) linear_k49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail)))) (linear_v49_3 ++ (125 :: tail)) tail linear_r63 linear_l49_3 (mutated_kp49_2 (linear_b63 ++ (44 :: (linear_v49_3 ++ (125 :: tail))))) (mutated_p63 (44 :: (linear_v49_3 ++ (125 :: tail)))) (mutated_pl49_3 tail))
def linear_l49_1 : List (List Nat × Raw) := (linear_k49_1, linear_r51) :: linear_l49_2
def linear_v49_1 : List Nat := (linear_g133 ++ linear_b51) ++ (44 :: linear_v49_2)
theorem mutated_sl49_1 : serializeFields 4077 27 linear_l49_1 = some linear_v49_1 := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k49_1 linear_r51 (linear_k49_2, linear_r63) linear_l49_3 linear_b51 linear_v49_2 mutated_kd49_1 mutated_s51 mutated_sl49_2)
theorem mutated_pl49_1 (tail : List Nat) : parseFields 4077 27 (linear_v49_1 ++ (125 :: tail)) = some (linear_l49_1, tail) := by
  simpa only [linear_l49_1, linear_v49_1, linear_k49_1, linear_g133, linear_l49_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k49_1 ++ (34 :: 58 :: (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))))) linear_k49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail)))) (linear_v49_2 ++ (125 :: tail)) tail linear_r51 linear_l49_2 (mutated_kp49_1 (linear_b51 ++ (44 :: (linear_v49_2 ++ (125 :: tail))))) (mutated_p51 (44 :: (linear_v49_2 ++ (125 :: tail)))) (mutated_pl49_2 tail))
def linear_l49_0 : List (List Nat × Raw) := (linear_k49_0, linear_r50) :: linear_l49_1
def linear_v49_0 : List Nat := (linear_g130 ++ linear_b50) ++ (44 :: linear_v49_1)
theorem mutated_sl49_0 : serializeFields 4078 27 linear_l49_0 = some linear_v49_0 := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4077 27 linear_k49_0 linear_r50 (linear_k49_1, linear_r51) linear_l49_2 linear_b50 linear_v49_1 mutated_kd49_0 mutated_s50 mutated_sl49_1)
theorem mutated_pl49_0 (tail : List Nat) : parseFields 4078 27 (linear_v49_0 ++ (125 :: tail)) = some (linear_l49_0, tail) := by
  simpa only [linear_l49_0, linear_v49_0, linear_k49_0, linear_g130, linear_l49_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4077 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) linear_k49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))) (linear_v49_1 ++ (125 :: tail)) tail linear_r50 linear_l49_1 (mutated_kp49_0 (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail))))) (mutated_p50 (44 :: (linear_v49_1 ++ (125 :: tail)))) (mutated_pl49_1 tail))
def linear_r49 : Raw := (.obj linear_l49_0)
def linear_b49 : List Nat := linear_g129 ++ (linear_v49_0 ++ linear_g163)
theorem mutated_o49 : orderedFields linear_l49_0 = true := by decide +kernel
theorem mutated_s49 : serializeRaw 4079 28 linear_r49 = some linear_b49 := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4078 27 linear_l49_0 linear_v49_0 mutated_o49 mutated_sl49_0)
theorem mutated_p49 (tail : List Nat) : parseRaw 4079 28 (linear_b49 ++ tail) = some (linear_r49, tail) := by
  simpa only [linear_r49, linear_b49, linear_g129, linear_g163, linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4078 27 (linear_k49_0 ++ (34 :: 58 :: (linear_b50 ++ (44 :: (linear_v49_1 ++ (125 :: tail)))))) tail linear_l49_0 mutated_o49 (by simpa only [linear_v49_0, linear_k49_0, linear_g130, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl49_0 tail)))
def linear_r66 : Raw := (.str [100,103,95,102,97,115,116,95,50])
def linear_b66 : List Nat := linear_g167
theorem mutated_s66 : serializeRaw 4076 27 linear_r66 = some linear_b66 := by decide +kernel
theorem mutated_p66 (tail : List Nat) : parseRaw 4076 27 (linear_b66 ++ tail) = some (linear_r66, tail) := by rfl
def linear_r67 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,54])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,55])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b67 : List Nat := linear_g170
theorem mutated_s67 : serializeRaw 4075 27 linear_r67 = some linear_b67 := by decide +kernel
theorem mutated_p67 (tail : List Nat) : parseRaw 4075 27 (linear_b67 ++ tail) = some (linear_r67, tail) := by rfl
def linear_r68 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b68 : List Nat := linear_g173
theorem mutated_s68 : serializeRaw 4074 27 linear_r68 = some linear_b68 := by decide +kernel
theorem mutated_p68 (tail : List Nat) : parseRaw 4074 27 (linear_b68 ++ tail) = some (linear_r68, tail) := by rfl
def linear_r69 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,50]),(.str [100,103,95,118,95,55,51]),(.str [100,103,95,118,95,55,54]),(.str [100,103,95,118,95,55,49]),(.str [100,103,95,118,95,55,55])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b69 : List Nat := linear_g176
theorem mutated_s69 : serializeRaw 4073 27 linear_r69 = some linear_b69 := by decide +kernel
theorem mutated_p69 (tail : List Nat) : parseRaw 4073 27 (linear_b69 ++ tail) = some (linear_r69, tail) := by rfl
def linear_k65_0 : List Nat := [105,100]
theorem mutated_kd65_0 : stringBytes linear_k65_0 = true := by decide +kernel
theorem mutated_kp65_0 (tail : List Nat) : parseStringTail (linear_k65_0 ++ (34 :: 58 :: tail)) [] = some (linear_k65_0, 58 :: tail) := by rfl
def linear_k65_1 : List Nat := [111,112,115]
theorem mutated_kd65_1 : stringBytes linear_k65_1 = true := by decide +kernel
theorem mutated_kp65_1 (tail : List Nat) : parseStringTail (linear_k65_1 ++ (34 :: 58 :: tail)) [] = some (linear_k65_1, 58 :: tail) := by rfl
def linear_k65_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd65_2 : stringBytes linear_k65_2 = true := by decide +kernel
theorem mutated_kp65_2 (tail : List Nat) : parseStringTail (linear_k65_2 ++ (34 :: 58 :: tail)) [] = some (linear_k65_2, 58 :: tail) := by rfl
def linear_k65_3 : List Nat := [116,101,114,109]
theorem mutated_kd65_3 : stringBytes linear_k65_3 = true := by decide +kernel
theorem mutated_kp65_3 (tail : List Nat) : parseStringTail (linear_k65_3 ++ (34 :: 58 :: tail)) [] = some (linear_k65_3, 58 :: tail) := by rfl
def linear_l65_3 : List (List Nat × Raw) := [(linear_k65_3, linear_r69)]
def linear_v65_3 : List Nat := linear_g175 ++ linear_b69
theorem mutated_sl65_3 : serializeFields 4074 27 linear_l65_3 = some linear_v65_3 := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4073 27 linear_k65_3 linear_r69 linear_b69 mutated_kd65_3 mutated_s69)
theorem mutated_pl65_3 (tail : List Nat) : parseFields 4074 27 (linear_v65_3 ++ (125 :: tail)) = some (linear_l65_3, tail) := by
  simpa only [linear_l65_3, linear_v65_3, linear_k65_3, linear_g175, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4073 27 (linear_k65_3 ++ (34 :: 58 :: (linear_b69 ++ (125 :: tail)))) linear_k65_3 (linear_b69 ++ (125 :: tail)) tail linear_r69 (mutated_kp65_3 (linear_b69 ++ (125 :: tail))) (mutated_p69 (125 :: tail)))
def linear_l65_2 : List (List Nat × Raw) := (linear_k65_2, linear_r68) :: linear_l65_3
def linear_v65_2 : List Nat := (linear_g172 ++ linear_b68) ++ (44 :: linear_v65_3)
theorem mutated_sl65_2 : serializeFields 4075 27 linear_l65_2 = some linear_v65_2 := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k65_2 linear_r68 (linear_k65_3, linear_r69) [] linear_b68 linear_v65_3 mutated_kd65_2 mutated_s68 mutated_sl65_3)
theorem mutated_pl65_2 (tail : List Nat) : parseFields 4075 27 (linear_v65_2 ++ (125 :: tail)) = some (linear_l65_2, tail) := by
  simpa only [linear_l65_2, linear_v65_2, linear_k65_2, linear_g172, linear_l65_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k65_2 ++ (34 :: 58 :: (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))))) linear_k65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail)))) (linear_v65_3 ++ (125 :: tail)) tail linear_r68 linear_l65_3 (mutated_kp65_2 (linear_b68 ++ (44 :: (linear_v65_3 ++ (125 :: tail))))) (mutated_p68 (44 :: (linear_v65_3 ++ (125 :: tail)))) (mutated_pl65_3 tail))
def linear_l65_1 : List (List Nat × Raw) := (linear_k65_1, linear_r67) :: linear_l65_2
def linear_v65_1 : List Nat := (linear_g169 ++ linear_b67) ++ (44 :: linear_v65_2)
theorem mutated_sl65_1 : serializeFields 4076 27 linear_l65_1 = some linear_v65_1 := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k65_1 linear_r67 (linear_k65_2, linear_r68) linear_l65_3 linear_b67 linear_v65_2 mutated_kd65_1 mutated_s67 mutated_sl65_2)
theorem mutated_pl65_1 (tail : List Nat) : parseFields 4076 27 (linear_v65_1 ++ (125 :: tail)) = some (linear_l65_1, tail) := by
  simpa only [linear_l65_1, linear_v65_1, linear_k65_1, linear_g169, linear_l65_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k65_1 ++ (34 :: 58 :: (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))))) linear_k65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail)))) (linear_v65_2 ++ (125 :: tail)) tail linear_r67 linear_l65_2 (mutated_kp65_1 (linear_b67 ++ (44 :: (linear_v65_2 ++ (125 :: tail))))) (mutated_p67 (44 :: (linear_v65_2 ++ (125 :: tail)))) (mutated_pl65_2 tail))
def linear_l65_0 : List (List Nat × Raw) := (linear_k65_0, linear_r66) :: linear_l65_1
def linear_v65_0 : List Nat := (linear_g166 ++ linear_b66) ++ (44 :: linear_v65_1)
theorem mutated_sl65_0 : serializeFields 4077 27 linear_l65_0 = some linear_v65_0 := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4076 27 linear_k65_0 linear_r66 (linear_k65_1, linear_r67) linear_l65_2 linear_b66 linear_v65_1 mutated_kd65_0 mutated_s66 mutated_sl65_1)
theorem mutated_pl65_0 (tail : List Nat) : parseFields 4077 27 (linear_v65_0 ++ (125 :: tail)) = some (linear_l65_0, tail) := by
  simpa only [linear_l65_0, linear_v65_0, linear_k65_0, linear_g166, linear_l65_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4076 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) linear_k65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))) (linear_v65_1 ++ (125 :: tail)) tail linear_r66 linear_l65_1 (mutated_kp65_0 (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail))))) (mutated_p66 (44 :: (linear_v65_1 ++ (125 :: tail)))) (mutated_pl65_1 tail))
def linear_r65 : Raw := (.obj linear_l65_0)
def linear_b65 : List Nat := linear_g165 ++ (linear_v65_0 ++ linear_g177)
theorem mutated_o65 : orderedFields linear_l65_0 = true := by decide +kernel
theorem mutated_s65 : serializeRaw 4078 28 linear_r65 = some linear_b65 := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4077 27 linear_l65_0 linear_v65_0 mutated_o65 mutated_sl65_0)
theorem mutated_p65 (tail : List Nat) : parseRaw 4078 28 (linear_b65 ++ tail) = some (linear_r65, tail) := by
  simpa only [linear_r65, linear_b65, linear_g165, linear_g177, linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4077 27 (linear_k65_0 ++ (34 :: 58 :: (linear_b66 ++ (44 :: (linear_v65_1 ++ (125 :: tail)))))) tail linear_l65_0 mutated_o65 (by simpa only [linear_v65_0, linear_k65_0, linear_g166, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl65_0 tail)))
def linear_r71 : Raw := (.str [100,103,95,102,97,115,116,95,51])
def linear_b71 : List Nat := linear_g181
theorem mutated_s71 : serializeRaw 4075 27 linear_r71 = some linear_b71 := by decide +kernel
theorem mutated_p71 (tail : List Nat) : parseRaw 4075 27 (linear_b71 ++ tail) = some (linear_r71, tail) := by rfl
def linear_r72 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,51]),(.str [100,103,95,118,95,56,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b72 : List Nat := linear_g184
theorem mutated_s72 : serializeRaw 4074 27 linear_r72 = some linear_b72 := by decide +kernel
theorem mutated_p72 (tail : List Nat) : parseRaw 4074 27 (linear_b72 ++ tail) = some (linear_r72, tail) := by rfl
def linear_r73 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b73 : List Nat := linear_g187
theorem mutated_s73 : serializeRaw 4073 27 linear_r73 = some linear_b73 := by decide +kernel
theorem mutated_p73 (tail : List Nat) : parseRaw 4073 27 (linear_b73 ++ tail) = some (linear_r73, tail) := by rfl
def linear_r74 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,56,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,55,56]),(.str [100,103,95,118,95,55,57]),(.str [100,103,95,118,95,56,48]),(.str [100,103,95,118,95,56,49]),(.str [100,103,95,118,95,56,50]),(.str [100,103,95,118,95,56,51])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b74 : List Nat := linear_g190
theorem mutated_s74 : serializeRaw 4072 27 linear_r74 = some linear_b74 := by decide +kernel
theorem mutated_p74 (tail : List Nat) : parseRaw 4072 27 (linear_b74 ++ tail) = some (linear_r74, tail) := by rfl
def linear_k70_0 : List Nat := [105,100]
theorem mutated_kd70_0 : stringBytes linear_k70_0 = true := by decide +kernel
theorem mutated_kp70_0 (tail : List Nat) : parseStringTail (linear_k70_0 ++ (34 :: 58 :: tail)) [] = some (linear_k70_0, 58 :: tail) := by rfl
def linear_k70_1 : List Nat := [111,112,115]
theorem mutated_kd70_1 : stringBytes linear_k70_1 = true := by decide +kernel
theorem mutated_kp70_1 (tail : List Nat) : parseStringTail (linear_k70_1 ++ (34 :: 58 :: tail)) [] = some (linear_k70_1, 58 :: tail) := by rfl
def linear_k70_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd70_2 : stringBytes linear_k70_2 = true := by decide +kernel
theorem mutated_kp70_2 (tail : List Nat) : parseStringTail (linear_k70_2 ++ (34 :: 58 :: tail)) [] = some (linear_k70_2, 58 :: tail) := by rfl
def linear_k70_3 : List Nat := [116,101,114,109]
theorem mutated_kd70_3 : stringBytes linear_k70_3 = true := by decide +kernel
theorem mutated_kp70_3 (tail : List Nat) : parseStringTail (linear_k70_3 ++ (34 :: 58 :: tail)) [] = some (linear_k70_3, 58 :: tail) := by rfl
def linear_l70_3 : List (List Nat × Raw) := [(linear_k70_3, linear_r74)]
def linear_v70_3 : List Nat := linear_g189 ++ linear_b74
theorem mutated_sl70_3 : serializeFields 4073 27 linear_l70_3 = some linear_v70_3 := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4072 27 linear_k70_3 linear_r74 linear_b74 mutated_kd70_3 mutated_s74)
theorem mutated_pl70_3 (tail : List Nat) : parseFields 4073 27 (linear_v70_3 ++ (125 :: tail)) = some (linear_l70_3, tail) := by
  simpa only [linear_l70_3, linear_v70_3, linear_k70_3, linear_g189, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4072 27 (linear_k70_3 ++ (34 :: 58 :: (linear_b74 ++ (125 :: tail)))) linear_k70_3 (linear_b74 ++ (125 :: tail)) tail linear_r74 (mutated_kp70_3 (linear_b74 ++ (125 :: tail))) (mutated_p74 (125 :: tail)))
def linear_l70_2 : List (List Nat × Raw) := (linear_k70_2, linear_r73) :: linear_l70_3
def linear_v70_2 : List Nat := (linear_g186 ++ linear_b73) ++ (44 :: linear_v70_3)
theorem mutated_sl70_2 : serializeFields 4074 27 linear_l70_2 = some linear_v70_2 := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k70_2 linear_r73 (linear_k70_3, linear_r74) [] linear_b73 linear_v70_3 mutated_kd70_2 mutated_s73 mutated_sl70_3)
theorem mutated_pl70_2 (tail : List Nat) : parseFields 4074 27 (linear_v70_2 ++ (125 :: tail)) = some (linear_l70_2, tail) := by
  simpa only [linear_l70_2, linear_v70_2, linear_k70_2, linear_g186, linear_l70_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k70_2 ++ (34 :: 58 :: (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))))) linear_k70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail)))) (linear_v70_3 ++ (125 :: tail)) tail linear_r73 linear_l70_3 (mutated_kp70_2 (linear_b73 ++ (44 :: (linear_v70_3 ++ (125 :: tail))))) (mutated_p73 (44 :: (linear_v70_3 ++ (125 :: tail)))) (mutated_pl70_3 tail))
def linear_l70_1 : List (List Nat × Raw) := (linear_k70_1, linear_r72) :: linear_l70_2
def linear_v70_1 : List Nat := (linear_g183 ++ linear_b72) ++ (44 :: linear_v70_2)
theorem mutated_sl70_1 : serializeFields 4075 27 linear_l70_1 = some linear_v70_1 := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k70_1 linear_r72 (linear_k70_2, linear_r73) linear_l70_3 linear_b72 linear_v70_2 mutated_kd70_1 mutated_s72 mutated_sl70_2)
theorem mutated_pl70_1 (tail : List Nat) : parseFields 4075 27 (linear_v70_1 ++ (125 :: tail)) = some (linear_l70_1, tail) := by
  simpa only [linear_l70_1, linear_v70_1, linear_k70_1, linear_g183, linear_l70_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k70_1 ++ (34 :: 58 :: (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))))) linear_k70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail)))) (linear_v70_2 ++ (125 :: tail)) tail linear_r72 linear_l70_2 (mutated_kp70_1 (linear_b72 ++ (44 :: (linear_v70_2 ++ (125 :: tail))))) (mutated_p72 (44 :: (linear_v70_2 ++ (125 :: tail)))) (mutated_pl70_2 tail))
def linear_l70_0 : List (List Nat × Raw) := (linear_k70_0, linear_r71) :: linear_l70_1
def linear_v70_0 : List Nat := (linear_g180 ++ linear_b71) ++ (44 :: linear_v70_1)
theorem mutated_sl70_0 : serializeFields 4076 27 linear_l70_0 = some linear_v70_0 := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4075 27 linear_k70_0 linear_r71 (linear_k70_1, linear_r72) linear_l70_2 linear_b71 linear_v70_1 mutated_kd70_0 mutated_s71 mutated_sl70_1)
theorem mutated_pl70_0 (tail : List Nat) : parseFields 4076 27 (linear_v70_0 ++ (125 :: tail)) = some (linear_l70_0, tail) := by
  simpa only [linear_l70_0, linear_v70_0, linear_k70_0, linear_g180, linear_l70_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4075 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) linear_k70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))) (linear_v70_1 ++ (125 :: tail)) tail linear_r71 linear_l70_1 (mutated_kp70_0 (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail))))) (mutated_p71 (44 :: (linear_v70_1 ++ (125 :: tail)))) (mutated_pl70_1 tail))
def linear_r70 : Raw := (.obj linear_l70_0)
def linear_b70 : List Nat := linear_g179 ++ (linear_v70_0 ++ linear_g191)
theorem mutated_o70 : orderedFields linear_l70_0 = true := by decide +kernel
theorem mutated_s70 : serializeRaw 4077 28 linear_r70 = some linear_b70 := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4076 27 linear_l70_0 linear_v70_0 mutated_o70 mutated_sl70_0)
theorem mutated_p70 (tail : List Nat) : parseRaw 4077 28 (linear_b70 ++ tail) = some (linear_r70, tail) := by
  simpa only [linear_r70, linear_b70, linear_g179, linear_g191, linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4076 27 (linear_k70_0 ++ (34 :: 58 :: (linear_b71 ++ (44 :: (linear_v70_1 ++ (125 :: tail)))))) tail linear_l70_0 mutated_o70 (by simpa only [linear_v70_0, linear_k70_0, linear_g180, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl70_0 tail)))
def linear_r76 : Raw := (.str [100,103,95,102,97,115,116,95,52])
def linear_b76 : List Nat := linear_g195
theorem mutated_s76 : serializeRaw 4074 27 linear_r76 = some linear_b76 := by decide +kernel
theorem mutated_p76 (tail : List Nat) : parseRaw 4074 27 (linear_b76 ++ tail) = some (linear_r76, tail) := by rfl
def linear_r78 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,49])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b78 : List Nat := linear_g199
theorem mutated_s78 : serializeRaw 4071 26 linear_r78 = some linear_b78 := by decide +kernel
theorem mutated_p78 (tail : List Nat) : parseRaw 4071 26 (linear_b78 ++ tail) = some (linear_r78, tail) := by rfl
def linear_r79 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49]),(.str [100,103,95,118,95,57,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,50])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b79 : List Nat := linear_g201
theorem mutated_s79 : serializeRaw 4070 26 linear_r79 = some linear_b79 := by decide +kernel
theorem mutated_p79 (tail : List Nat) : parseRaw 4070 26 (linear_b79 ++ tail) = some (linear_r79, tail) := by rfl
def linear_r80 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b80 : List Nat := linear_g203
theorem mutated_s80 : serializeRaw 4069 26 linear_r80 = some linear_b80 := by decide +kernel
theorem mutated_p80 (tail : List Nat) : parseRaw 4069 26 (linear_b80 ++ tail) = some (linear_r80, tail) := by rfl
def linear_r81 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,50])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,51])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b81 : List Nat := linear_g205
theorem mutated_s81 : serializeRaw 4068 26 linear_r81 = some linear_b81 := by decide +kernel
theorem mutated_p81 (tail : List Nat) : parseRaw 4068 26 (linear_b81 ++ tail) = some (linear_r81, tail) := by rfl
def linear_r82 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,56]),(.str [100,103,95,118,95,57,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,52])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b82 : List Nat := linear_g207
theorem mutated_s82 : serializeRaw 4067 26 linear_r82 = some linear_b82 := by decide +kernel
theorem mutated_p82 (tail : List Nat) : parseRaw 4067 26 (linear_b82 ++ tail) = some (linear_r82, tail) := by rfl
def linear_r83 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,53])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b83 : List Nat := linear_g209
theorem mutated_s83 : serializeRaw 4066 26 linear_r83 = some linear_b83 := by decide +kernel
theorem mutated_p83 (tail : List Nat) : parseRaw 4066 26 (linear_b83 ++ tail) = some (linear_r83, tail) := by rfl
def linear_r84 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,48]),(.str [100,103,95,118,95,57,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,54])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b84 : List Nat := linear_g211
theorem mutated_s84 : serializeRaw 4065 26 linear_r84 = some linear_b84 := by decide +kernel
theorem mutated_p84 (tail : List Nat) : parseRaw 4065 26 (linear_b84 ++ tail) = some (linear_r84, tail) := by rfl
def linear_l77_6 : List Raw := [linear_r84]
def linear_v77_6 : List Nat := linear_b84
theorem mutated_sl77_6 : serializeItems 4066 26 linear_l77_6 = some linear_v77_6 := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4065 26 linear_r84 linear_b84 mutated_s84)
theorem mutated_pl77_6 (tail : List Nat) : parseItems 4066 26 (linear_v77_6 ++ (93 :: tail)) = some (linear_l77_6, tail) := by
  simpa only [linear_l77_6, linear_v77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4065 26 (linear_b84 ++ (93 :: tail)) tail linear_r84 (mutated_p84 (93 :: tail)))
def linear_l77_5 : List Raw := linear_r83 :: linear_l77_6
def linear_v77_5 : List Nat := (linear_b83) ++ (44 :: linear_v77_6)
theorem mutated_sl77_5 : serializeItems 4067 26 linear_l77_5 = some linear_v77_5 := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r83 linear_r84 [] linear_b83 linear_v77_6 mutated_s83 mutated_sl77_6)
theorem mutated_pl77_5 (tail : List Nat) : parseItems 4067 26 (linear_v77_5 ++ (93 :: tail)) = some (linear_l77_5, tail) := by
  simpa only [linear_l77_5, linear_v77_5, linear_l77_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b83 ++ (44 :: (linear_v77_6 ++ (93 :: tail)))) (linear_v77_6 ++ (93 :: tail)) tail linear_r83 linear_l77_6 (mutated_p83 (44 :: (linear_v77_6 ++ (93 :: tail)))) (mutated_pl77_6 tail))
def linear_l77_4 : List Raw := linear_r82 :: linear_l77_5
def linear_v77_4 : List Nat := (linear_b82) ++ (44 :: linear_v77_5)
theorem mutated_sl77_4 : serializeItems 4068 26 linear_l77_4 = some linear_v77_4 := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r82 linear_r83 linear_l77_6 linear_b82 linear_v77_5 mutated_s82 mutated_sl77_5)
theorem mutated_pl77_4 (tail : List Nat) : parseItems 4068 26 (linear_v77_4 ++ (93 :: tail)) = some (linear_l77_4, tail) := by
  simpa only [linear_l77_4, linear_v77_4, linear_l77_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b82 ++ (44 :: (linear_v77_5 ++ (93 :: tail)))) (linear_v77_5 ++ (93 :: tail)) tail linear_r82 linear_l77_5 (mutated_p82 (44 :: (linear_v77_5 ++ (93 :: tail)))) (mutated_pl77_5 tail))
def linear_l77_3 : List Raw := linear_r81 :: linear_l77_4
def linear_v77_3 : List Nat := (linear_b81) ++ (44 :: linear_v77_4)
theorem mutated_sl77_3 : serializeItems 4069 26 linear_l77_3 = some linear_v77_3 := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r81 linear_r82 linear_l77_5 linear_b81 linear_v77_4 mutated_s81 mutated_sl77_4)
theorem mutated_pl77_3 (tail : List Nat) : parseItems 4069 26 (linear_v77_3 ++ (93 :: tail)) = some (linear_l77_3, tail) := by
  simpa only [linear_l77_3, linear_v77_3, linear_l77_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b81 ++ (44 :: (linear_v77_4 ++ (93 :: tail)))) (linear_v77_4 ++ (93 :: tail)) tail linear_r81 linear_l77_4 (mutated_p81 (44 :: (linear_v77_4 ++ (93 :: tail)))) (mutated_pl77_4 tail))
def linear_l77_2 : List Raw := linear_r80 :: linear_l77_3
def linear_v77_2 : List Nat := (linear_b80) ++ (44 :: linear_v77_3)
theorem mutated_sl77_2 : serializeItems 4070 26 linear_l77_2 = some linear_v77_2 := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 26 linear_r80 linear_r81 linear_l77_4 linear_b80 linear_v77_3 mutated_s80 mutated_sl77_3)
theorem mutated_pl77_2 (tail : List Nat) : parseItems 4070 26 (linear_v77_2 ++ (93 :: tail)) = some (linear_l77_2, tail) := by
  simpa only [linear_l77_2, linear_v77_2, linear_l77_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 26 (linear_b80 ++ (44 :: (linear_v77_3 ++ (93 :: tail)))) (linear_v77_3 ++ (93 :: tail)) tail linear_r80 linear_l77_3 (mutated_p80 (44 :: (linear_v77_3 ++ (93 :: tail)))) (mutated_pl77_3 tail))
def linear_l77_1 : List Raw := linear_r79 :: linear_l77_2
def linear_v77_1 : List Nat := (linear_b79) ++ (44 :: linear_v77_2)
theorem mutated_sl77_1 : serializeItems 4071 26 linear_l77_1 = some linear_v77_1 := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 26 linear_r79 linear_r80 linear_l77_3 linear_b79 linear_v77_2 mutated_s79 mutated_sl77_2)
theorem mutated_pl77_1 (tail : List Nat) : parseItems 4071 26 (linear_v77_1 ++ (93 :: tail)) = some (linear_l77_1, tail) := by
  simpa only [linear_l77_1, linear_v77_1, linear_l77_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 26 (linear_b79 ++ (44 :: (linear_v77_2 ++ (93 :: tail)))) (linear_v77_2 ++ (93 :: tail)) tail linear_r79 linear_l77_2 (mutated_p79 (44 :: (linear_v77_2 ++ (93 :: tail)))) (mutated_pl77_2 tail))
def linear_l77_0 : List Raw := linear_r78 :: linear_l77_1
def linear_v77_0 : List Nat := (linear_b78) ++ (44 :: linear_v77_1)
theorem mutated_sl77_0 : serializeItems 4072 26 linear_l77_0 = some linear_v77_0 := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 26 linear_r78 linear_r79 linear_l77_2 linear_b78 linear_v77_1 mutated_s78 mutated_sl77_1)
theorem mutated_pl77_0 (tail : List Nat) : parseItems 4072 26 (linear_v77_0 ++ (93 :: tail)) = some (linear_l77_0, tail) := by
  simpa only [linear_l77_0, linear_v77_0, linear_l77_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 26 (linear_b78 ++ (44 :: (linear_v77_1 ++ (93 :: tail)))) (linear_v77_1 ++ (93 :: tail)) tail linear_r78 linear_l77_1 (mutated_p78 (44 :: (linear_v77_1 ++ (93 :: tail)))) (mutated_pl77_1 tail))
def linear_r77 : Raw := (.arr linear_l77_0)
def linear_b77 : List Nat := linear_g198 ++ (linear_v77_0 ++ linear_g212)
theorem mutated_s77 : serializeRaw 4073 27 linear_r77 = some linear_b77 := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4072 26 linear_l77_0 linear_v77_0 mutated_sl77_0)
theorem mutated_p77 (tail : List Nat) : parseRaw 4073 27 (linear_b77 ++ tail) = some (linear_r77, tail) := by
  simpa only [linear_r77, linear_b77, linear_g198, linear_g212, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4072 26 (linear_v77_0 ++ (93 :: tail)) tail linear_l77_0 (by intro h; cases h) (mutated_pl77_0 tail))
def linear_r85 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,56,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b85 : List Nat := linear_g215
theorem mutated_s85 : serializeRaw 4072 27 linear_r85 = some linear_b85 := by decide +kernel
theorem mutated_p85 (tail : List Nat) : parseRaw 4072 27 (linear_b85 ++ tail) = some (linear_r85, tail) := by rfl
def linear_r86 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,56,53]),(.str [100,103,95,118,95,56,54]),(.str [100,103,95,118,95,56,55]),(.str [100,103,95,118,95,57,52]),(.str [100,103,95,118,95,56,57]),(.str [100,103,95,118,95,57,54])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,51]))])
def linear_b86 : List Nat := linear_g218
theorem mutated_s86 : serializeRaw 4071 27 linear_r86 = some linear_b86 := by decide +kernel
theorem mutated_p86 (tail : List Nat) : parseRaw 4071 27 (linear_b86 ++ tail) = some (linear_r86, tail) := by rfl
def linear_k75_0 : List Nat := [105,100]
theorem mutated_kd75_0 : stringBytes linear_k75_0 = true := by decide +kernel
theorem mutated_kp75_0 (tail : List Nat) : parseStringTail (linear_k75_0 ++ (34 :: 58 :: tail)) [] = some (linear_k75_0, 58 :: tail) := by rfl
def linear_k75_1 : List Nat := [111,112,115]
theorem mutated_kd75_1 : stringBytes linear_k75_1 = true := by decide +kernel
theorem mutated_kp75_1 (tail : List Nat) : parseStringTail (linear_k75_1 ++ (34 :: 58 :: tail)) [] = some (linear_k75_1, 58 :: tail) := by rfl
def linear_k75_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd75_2 : stringBytes linear_k75_2 = true := by decide +kernel
theorem mutated_kp75_2 (tail : List Nat) : parseStringTail (linear_k75_2 ++ (34 :: 58 :: tail)) [] = some (linear_k75_2, 58 :: tail) := by rfl
def linear_k75_3 : List Nat := [116,101,114,109]
theorem mutated_kd75_3 : stringBytes linear_k75_3 = true := by decide +kernel
theorem mutated_kp75_3 (tail : List Nat) : parseStringTail (linear_k75_3 ++ (34 :: 58 :: tail)) [] = some (linear_k75_3, 58 :: tail) := by rfl
def linear_l75_3 : List (List Nat × Raw) := [(linear_k75_3, linear_r86)]
def linear_v75_3 : List Nat := linear_g217 ++ linear_b86
theorem mutated_sl75_3 : serializeFields 4072 27 linear_l75_3 = some linear_v75_3 := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4071 27 linear_k75_3 linear_r86 linear_b86 mutated_kd75_3 mutated_s86)
theorem mutated_pl75_3 (tail : List Nat) : parseFields 4072 27 (linear_v75_3 ++ (125 :: tail)) = some (linear_l75_3, tail) := by
  simpa only [linear_l75_3, linear_v75_3, linear_k75_3, linear_g217, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4071 27 (linear_k75_3 ++ (34 :: 58 :: (linear_b86 ++ (125 :: tail)))) linear_k75_3 (linear_b86 ++ (125 :: tail)) tail linear_r86 (mutated_kp75_3 (linear_b86 ++ (125 :: tail))) (mutated_p86 (125 :: tail)))
def linear_l75_2 : List (List Nat × Raw) := (linear_k75_2, linear_r85) :: linear_l75_3
def linear_v75_2 : List Nat := (linear_g214 ++ linear_b85) ++ (44 :: linear_v75_3)
theorem mutated_sl75_2 : serializeFields 4073 27 linear_l75_2 = some linear_v75_2 := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k75_2 linear_r85 (linear_k75_3, linear_r86) [] linear_b85 linear_v75_3 mutated_kd75_2 mutated_s85 mutated_sl75_3)
theorem mutated_pl75_2 (tail : List Nat) : parseFields 4073 27 (linear_v75_2 ++ (125 :: tail)) = some (linear_l75_2, tail) := by
  simpa only [linear_l75_2, linear_v75_2, linear_k75_2, linear_g214, linear_l75_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k75_2 ++ (34 :: 58 :: (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))))) linear_k75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail)))) (linear_v75_3 ++ (125 :: tail)) tail linear_r85 linear_l75_3 (mutated_kp75_2 (linear_b85 ++ (44 :: (linear_v75_3 ++ (125 :: tail))))) (mutated_p85 (44 :: (linear_v75_3 ++ (125 :: tail)))) (mutated_pl75_3 tail))
def linear_l75_1 : List (List Nat × Raw) := (linear_k75_1, linear_r77) :: linear_l75_2
def linear_v75_1 : List Nat := (linear_g197 ++ linear_b77) ++ (44 :: linear_v75_2)
theorem mutated_sl75_1 : serializeFields 4074 27 linear_l75_1 = some linear_v75_1 := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k75_1 linear_r77 (linear_k75_2, linear_r85) linear_l75_3 linear_b77 linear_v75_2 mutated_kd75_1 mutated_s77 mutated_sl75_2)
theorem mutated_pl75_1 (tail : List Nat) : parseFields 4074 27 (linear_v75_1 ++ (125 :: tail)) = some (linear_l75_1, tail) := by
  simpa only [linear_l75_1, linear_v75_1, linear_k75_1, linear_g197, linear_l75_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k75_1 ++ (34 :: 58 :: (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))))) linear_k75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail)))) (linear_v75_2 ++ (125 :: tail)) tail linear_r77 linear_l75_2 (mutated_kp75_1 (linear_b77 ++ (44 :: (linear_v75_2 ++ (125 :: tail))))) (mutated_p77 (44 :: (linear_v75_2 ++ (125 :: tail)))) (mutated_pl75_2 tail))
def linear_l75_0 : List (List Nat × Raw) := (linear_k75_0, linear_r76) :: linear_l75_1
def linear_v75_0 : List Nat := (linear_g194 ++ linear_b76) ++ (44 :: linear_v75_1)
theorem mutated_sl75_0 : serializeFields 4075 27 linear_l75_0 = some linear_v75_0 := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4074 27 linear_k75_0 linear_r76 (linear_k75_1, linear_r77) linear_l75_2 linear_b76 linear_v75_1 mutated_kd75_0 mutated_s76 mutated_sl75_1)
theorem mutated_pl75_0 (tail : List Nat) : parseFields 4075 27 (linear_v75_0 ++ (125 :: tail)) = some (linear_l75_0, tail) := by
  simpa only [linear_l75_0, linear_v75_0, linear_k75_0, linear_g194, linear_l75_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4074 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) linear_k75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))) (linear_v75_1 ++ (125 :: tail)) tail linear_r76 linear_l75_1 (mutated_kp75_0 (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail))))) (mutated_p76 (44 :: (linear_v75_1 ++ (125 :: tail)))) (mutated_pl75_1 tail))
def linear_r75 : Raw := (.obj linear_l75_0)
def linear_b75 : List Nat := linear_g193 ++ (linear_v75_0 ++ linear_g219)
theorem mutated_o75 : orderedFields linear_l75_0 = true := by decide +kernel
theorem mutated_s75 : serializeRaw 4076 28 linear_r75 = some linear_b75 := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4075 27 linear_l75_0 linear_v75_0 mutated_o75 mutated_sl75_0)
theorem mutated_p75 (tail : List Nat) : parseRaw 4076 28 (linear_b75 ++ tail) = some (linear_r75, tail) := by
  simpa only [linear_r75, linear_b75, linear_g193, linear_g219, linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4075 27 (linear_k75_0 ++ (34 :: 58 :: (linear_b76 ++ (44 :: (linear_v75_1 ++ (125 :: tail)))))) tail linear_l75_0 mutated_o75 (by simpa only [linear_v75_0, linear_k75_0, linear_g194, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl75_0 tail)))
def linear_r88 : Raw := (.str [100,103,95,102,97,115,116,95,53])
def linear_b88 : List Nat := linear_g223
theorem mutated_s88 : serializeRaw 4073 27 linear_r88 = some linear_b88 := by decide +kernel
theorem mutated_p88 (tail : List Nat) : parseRaw 4073 27 (linear_b88 ++ tail) = some (linear_r88, tail) := by rfl
def linear_r89 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,57,57])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b89 : List Nat := linear_g226
theorem mutated_s89 : serializeRaw 4072 27 linear_r89 = some linear_b89 := by decide +kernel
theorem mutated_p89 (tail : List Nat) : parseRaw 4072 27 (linear_b89 ++ tail) = some (linear_r89, tail) := by rfl
def linear_r90 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,57,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,48])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b90 : List Nat := linear_g229
theorem mutated_s90 : serializeRaw 4071 27 linear_r90 = some linear_b90 := by decide +kernel
theorem mutated_p90 (tail : List Nat) : parseRaw 4071 27 (linear_b90 ++ tail) = some (linear_r90, tail) := by rfl
def linear_r91 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,48,48])]))])
def linear_b91 : List Nat := linear_g232
theorem mutated_s91 : serializeRaw 4070 27 linear_r91 = some linear_b91 := by decide +kernel
theorem mutated_p91 (tail : List Nat) : parseRaw 4070 27 (linear_b91 ++ tail) = some (linear_r91, tail) := by rfl
def linear_k87_0 : List Nat := [105,100]
theorem mutated_kd87_0 : stringBytes linear_k87_0 = true := by decide +kernel
theorem mutated_kp87_0 (tail : List Nat) : parseStringTail (linear_k87_0 ++ (34 :: 58 :: tail)) [] = some (linear_k87_0, 58 :: tail) := by rfl
def linear_k87_1 : List Nat := [111,112,115]
theorem mutated_kd87_1 : stringBytes linear_k87_1 = true := by decide +kernel
theorem mutated_kp87_1 (tail : List Nat) : parseStringTail (linear_k87_1 ++ (34 :: 58 :: tail)) [] = some (linear_k87_1, 58 :: tail) := by rfl
def linear_k87_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd87_2 : stringBytes linear_k87_2 = true := by decide +kernel
theorem mutated_kp87_2 (tail : List Nat) : parseStringTail (linear_k87_2 ++ (34 :: 58 :: tail)) [] = some (linear_k87_2, 58 :: tail) := by rfl
def linear_k87_3 : List Nat := [116,101,114,109]
theorem mutated_kd87_3 : stringBytes linear_k87_3 = true := by decide +kernel
theorem mutated_kp87_3 (tail : List Nat) : parseStringTail (linear_k87_3 ++ (34 :: 58 :: tail)) [] = some (linear_k87_3, 58 :: tail) := by rfl
def linear_l87_3 : List (List Nat × Raw) := [(linear_k87_3, linear_r91)]
def linear_v87_3 : List Nat := linear_g231 ++ linear_b91
theorem mutated_sl87_3 : serializeFields 4071 27 linear_l87_3 = some linear_v87_3 := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4070 27 linear_k87_3 linear_r91 linear_b91 mutated_kd87_3 mutated_s91)
theorem mutated_pl87_3 (tail : List Nat) : parseFields 4071 27 (linear_v87_3 ++ (125 :: tail)) = some (linear_l87_3, tail) := by
  simpa only [linear_l87_3, linear_v87_3, linear_k87_3, linear_g231, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4070 27 (linear_k87_3 ++ (34 :: 58 :: (linear_b91 ++ (125 :: tail)))) linear_k87_3 (linear_b91 ++ (125 :: tail)) tail linear_r91 (mutated_kp87_3 (linear_b91 ++ (125 :: tail))) (mutated_p91 (125 :: tail)))
def linear_l87_2 : List (List Nat × Raw) := (linear_k87_2, linear_r90) :: linear_l87_3
def linear_v87_2 : List Nat := (linear_g228 ++ linear_b90) ++ (44 :: linear_v87_3)
theorem mutated_sl87_2 : serializeFields 4072 27 linear_l87_2 = some linear_v87_2 := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k87_2 linear_r90 (linear_k87_3, linear_r91) [] linear_b90 linear_v87_3 mutated_kd87_2 mutated_s90 mutated_sl87_3)
theorem mutated_pl87_2 (tail : List Nat) : parseFields 4072 27 (linear_v87_2 ++ (125 :: tail)) = some (linear_l87_2, tail) := by
  simpa only [linear_l87_2, linear_v87_2, linear_k87_2, linear_g228, linear_l87_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k87_2 ++ (34 :: 58 :: (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))))) linear_k87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail)))) (linear_v87_3 ++ (125 :: tail)) tail linear_r90 linear_l87_3 (mutated_kp87_2 (linear_b90 ++ (44 :: (linear_v87_3 ++ (125 :: tail))))) (mutated_p90 (44 :: (linear_v87_3 ++ (125 :: tail)))) (mutated_pl87_3 tail))
def linear_l87_1 : List (List Nat × Raw) := (linear_k87_1, linear_r89) :: linear_l87_2
def linear_v87_1 : List Nat := (linear_g225 ++ linear_b89) ++ (44 :: linear_v87_2)
theorem mutated_sl87_1 : serializeFields 4073 27 linear_l87_1 = some linear_v87_1 := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k87_1 linear_r89 (linear_k87_2, linear_r90) linear_l87_3 linear_b89 linear_v87_2 mutated_kd87_1 mutated_s89 mutated_sl87_2)
theorem mutated_pl87_1 (tail : List Nat) : parseFields 4073 27 (linear_v87_1 ++ (125 :: tail)) = some (linear_l87_1, tail) := by
  simpa only [linear_l87_1, linear_v87_1, linear_k87_1, linear_g225, linear_l87_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k87_1 ++ (34 :: 58 :: (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))))) linear_k87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail)))) (linear_v87_2 ++ (125 :: tail)) tail linear_r89 linear_l87_2 (mutated_kp87_1 (linear_b89 ++ (44 :: (linear_v87_2 ++ (125 :: tail))))) (mutated_p89 (44 :: (linear_v87_2 ++ (125 :: tail)))) (mutated_pl87_2 tail))
def linear_l87_0 : List (List Nat × Raw) := (linear_k87_0, linear_r88) :: linear_l87_1
def linear_v87_0 : List Nat := (linear_g222 ++ linear_b88) ++ (44 :: linear_v87_1)
theorem mutated_sl87_0 : serializeFields 4074 27 linear_l87_0 = some linear_v87_0 := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4073 27 linear_k87_0 linear_r88 (linear_k87_1, linear_r89) linear_l87_2 linear_b88 linear_v87_1 mutated_kd87_0 mutated_s88 mutated_sl87_1)
theorem mutated_pl87_0 (tail : List Nat) : parseFields 4074 27 (linear_v87_0 ++ (125 :: tail)) = some (linear_l87_0, tail) := by
  simpa only [linear_l87_0, linear_v87_0, linear_k87_0, linear_g222, linear_l87_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4073 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) linear_k87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))) (linear_v87_1 ++ (125 :: tail)) tail linear_r88 linear_l87_1 (mutated_kp87_0 (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail))))) (mutated_p88 (44 :: (linear_v87_1 ++ (125 :: tail)))) (mutated_pl87_1 tail))
def linear_r87 : Raw := (.obj linear_l87_0)
def linear_b87 : List Nat := linear_g221 ++ (linear_v87_0 ++ linear_g233)
theorem mutated_o87 : orderedFields linear_l87_0 = true := by decide +kernel
theorem mutated_s87 : serializeRaw 4075 28 linear_r87 = some linear_b87 := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4074 27 linear_l87_0 linear_v87_0 mutated_o87 mutated_sl87_0)
theorem mutated_p87 (tail : List Nat) : parseRaw 4075 28 (linear_b87 ++ tail) = some (linear_r87, tail) := by
  simpa only [linear_r87, linear_b87, linear_g221, linear_g233, linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4074 27 (linear_k87_0 ++ (34 :: 58 :: (linear_b88 ++ (44 :: (linear_v87_1 ++ (125 :: tail)))))) tail linear_l87_0 mutated_o87 (by simpa only [linear_v87_0, linear_k87_0, linear_g222, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl87_0 tail)))
def linear_r93 : Raw := (.str [100,103,95,115,108,111,119,95,48])
def linear_b93 : List Nat := linear_g237
theorem mutated_s93 : serializeRaw 4072 27 linear_r93 = some linear_b93 := by decide +kernel
theorem mutated_p93 (tail : List Nat) : parseRaw 4072 27 (linear_b93 ++ tail) = some (linear_r93, tail) := by rfl
def linear_r94 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,56]),(.str [100,103,95,118,95,49,48,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,57])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b94 : List Nat := linear_g240
theorem mutated_s94 : serializeRaw 4071 27 linear_r94 = some linear_b94 := by decide +kernel
theorem mutated_p94 (tail : List Nat) : parseRaw 4071 27 (linear_b94 ++ tail) = some (linear_r94, tail) := by rfl
def linear_r95 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b95 : List Nat := linear_g243
theorem mutated_s95 : serializeRaw 4070 27 linear_r95 = some linear_b95 := by decide +kernel
theorem mutated_p95 (tail : List Nat) : parseRaw 4070 27 (linear_b95 ++ tail) = some (linear_r95, tail) := by rfl
def linear_r96 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,48,57])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,48,52]),(.str [100,103,95,118,95,49,48,53]),(.str [100,103,95,118,95,49,48,54]),(.str [100,103,95,118,95,49,48,55]),(.str [100,103,95,118,95,49,48,56])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))]))])
def linear_b96 : List Nat := linear_g246
theorem mutated_s96 : serializeRaw 4069 27 linear_r96 = some linear_b96 := by decide +kernel
theorem mutated_p96 (tail : List Nat) : parseRaw 4069 27 (linear_b96 ++ tail) = some (linear_r96, tail) := by rfl
def linear_k92_0 : List Nat := [105,100]
theorem mutated_kd92_0 : stringBytes linear_k92_0 = true := by decide +kernel
theorem mutated_kp92_0 (tail : List Nat) : parseStringTail (linear_k92_0 ++ (34 :: 58 :: tail)) [] = some (linear_k92_0, 58 :: tail) := by rfl
def linear_k92_1 : List Nat := [111,112,115]
theorem mutated_kd92_1 : stringBytes linear_k92_1 = true := by decide +kernel
theorem mutated_kp92_1 (tail : List Nat) : parseStringTail (linear_k92_1 ++ (34 :: 58 :: tail)) [] = some (linear_k92_1, 58 :: tail) := by rfl
def linear_k92_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd92_2 : stringBytes linear_k92_2 = true := by decide +kernel
theorem mutated_kp92_2 (tail : List Nat) : parseStringTail (linear_k92_2 ++ (34 :: 58 :: tail)) [] = some (linear_k92_2, 58 :: tail) := by rfl
def linear_k92_3 : List Nat := [116,101,114,109]
theorem mutated_kd92_3 : stringBytes linear_k92_3 = true := by decide +kernel
theorem mutated_kp92_3 (tail : List Nat) : parseStringTail (linear_k92_3 ++ (34 :: 58 :: tail)) [] = some (linear_k92_3, 58 :: tail) := by rfl
def linear_l92_3 : List (List Nat × Raw) := [(linear_k92_3, linear_r96)]
def linear_v92_3 : List Nat := linear_g245 ++ linear_b96
theorem mutated_sl92_3 : serializeFields 4070 27 linear_l92_3 = some linear_v92_3 := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4069 27 linear_k92_3 linear_r96 linear_b96 mutated_kd92_3 mutated_s96)
theorem mutated_pl92_3 (tail : List Nat) : parseFields 4070 27 (linear_v92_3 ++ (125 :: tail)) = some (linear_l92_3, tail) := by
  simpa only [linear_l92_3, linear_v92_3, linear_k92_3, linear_g245, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4069 27 (linear_k92_3 ++ (34 :: 58 :: (linear_b96 ++ (125 :: tail)))) linear_k92_3 (linear_b96 ++ (125 :: tail)) tail linear_r96 (mutated_kp92_3 (linear_b96 ++ (125 :: tail))) (mutated_p96 (125 :: tail)))
def linear_l92_2 : List (List Nat × Raw) := (linear_k92_2, linear_r95) :: linear_l92_3
def linear_v92_2 : List Nat := (linear_g242 ++ linear_b95) ++ (44 :: linear_v92_3)
theorem mutated_sl92_2 : serializeFields 4071 27 linear_l92_2 = some linear_v92_2 := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k92_2 linear_r95 (linear_k92_3, linear_r96) [] linear_b95 linear_v92_3 mutated_kd92_2 mutated_s95 mutated_sl92_3)
theorem mutated_pl92_2 (tail : List Nat) : parseFields 4071 27 (linear_v92_2 ++ (125 :: tail)) = some (linear_l92_2, tail) := by
  simpa only [linear_l92_2, linear_v92_2, linear_k92_2, linear_g242, linear_l92_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k92_2 ++ (34 :: 58 :: (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))))) linear_k92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail)))) (linear_v92_3 ++ (125 :: tail)) tail linear_r95 linear_l92_3 (mutated_kp92_2 (linear_b95 ++ (44 :: (linear_v92_3 ++ (125 :: tail))))) (mutated_p95 (44 :: (linear_v92_3 ++ (125 :: tail)))) (mutated_pl92_3 tail))
def linear_l92_1 : List (List Nat × Raw) := (linear_k92_1, linear_r94) :: linear_l92_2
def linear_v92_1 : List Nat := (linear_g239 ++ linear_b94) ++ (44 :: linear_v92_2)
theorem mutated_sl92_1 : serializeFields 4072 27 linear_l92_1 = some linear_v92_1 := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k92_1 linear_r94 (linear_k92_2, linear_r95) linear_l92_3 linear_b94 linear_v92_2 mutated_kd92_1 mutated_s94 mutated_sl92_2)
theorem mutated_pl92_1 (tail : List Nat) : parseFields 4072 27 (linear_v92_1 ++ (125 :: tail)) = some (linear_l92_1, tail) := by
  simpa only [linear_l92_1, linear_v92_1, linear_k92_1, linear_g239, linear_l92_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k92_1 ++ (34 :: 58 :: (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))))) linear_k92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail)))) (linear_v92_2 ++ (125 :: tail)) tail linear_r94 linear_l92_2 (mutated_kp92_1 (linear_b94 ++ (44 :: (linear_v92_2 ++ (125 :: tail))))) (mutated_p94 (44 :: (linear_v92_2 ++ (125 :: tail)))) (mutated_pl92_2 tail))
def linear_l92_0 : List (List Nat × Raw) := (linear_k92_0, linear_r93) :: linear_l92_1
def linear_v92_0 : List Nat := (linear_g236 ++ linear_b93) ++ (44 :: linear_v92_1)
theorem mutated_sl92_0 : serializeFields 4073 27 linear_l92_0 = some linear_v92_0 := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4072 27 linear_k92_0 linear_r93 (linear_k92_1, linear_r94) linear_l92_2 linear_b93 linear_v92_1 mutated_kd92_0 mutated_s93 mutated_sl92_1)
theorem mutated_pl92_0 (tail : List Nat) : parseFields 4073 27 (linear_v92_0 ++ (125 :: tail)) = some (linear_l92_0, tail) := by
  simpa only [linear_l92_0, linear_v92_0, linear_k92_0, linear_g236, linear_l92_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4072 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) linear_k92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))) (linear_v92_1 ++ (125 :: tail)) tail linear_r93 linear_l92_1 (mutated_kp92_0 (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail))))) (mutated_p93 (44 :: (linear_v92_1 ++ (125 :: tail)))) (mutated_pl92_1 tail))
def linear_r92 : Raw := (.obj linear_l92_0)
def linear_b92 : List Nat := linear_g235 ++ (linear_v92_0 ++ linear_g247)
theorem mutated_o92 : orderedFields linear_l92_0 = true := by decide +kernel
theorem mutated_s92 : serializeRaw 4074 28 linear_r92 = some linear_b92 := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4073 27 linear_l92_0 linear_v92_0 mutated_o92 mutated_sl92_0)
theorem mutated_p92 (tail : List Nat) : parseRaw 4074 28 (linear_b92 ++ tail) = some (linear_r92, tail) := by
  simpa only [linear_r92, linear_b92, linear_g235, linear_g247, linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4073 27 (linear_k92_0 ++ (34 :: 58 :: (linear_b93 ++ (44 :: (linear_v92_1 ++ (125 :: tail)))))) tail linear_l92_0 mutated_o92 (by simpa only [linear_v92_0, linear_k92_0, linear_g236, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl92_0 tail)))
def linear_r98 : Raw := (.str [100,103,95,115,108,111,119,95,49])
def linear_b98 : List Nat := linear_g251
theorem mutated_s98 : serializeRaw 4071 27 linear_r98 = some linear_b98 := by decide +kernel
theorem mutated_p98 (tail : List Nat) : parseRaw 4071 27 (linear_b98 ++ tail) = some (linear_r98, tail) := by rfl
def linear_r100 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,53])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b100 : List Nat := linear_g255
theorem mutated_s100 : serializeRaw 4068 26 linear_r100 = some linear_b100 := by decide +kernel
theorem mutated_p100 (tail : List Nat) : parseRaw 4068 26 (linear_b100 ++ tail) = some (linear_r100, tail) := by rfl
def linear_r101 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,53]),(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,54])),([116,121,112,101],(.str [117,51,50]))])]))])
def linear_b101 : List Nat := linear_g257
theorem mutated_s101 : serializeRaw 4067 26 linear_r101 = some linear_b101 := by decide +kernel
theorem mutated_p101 (tail : List Nat) : parseRaw 4067 26 (linear_b101 ++ tail) = some (linear_r101, tail) := by rfl
def linear_r102 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,55])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b102 : List Nat := linear_g259
theorem mutated_s102 : serializeRaw 4066 26 linear_r102 = some linear_b102 := by decide +kernel
theorem mutated_p102 (tail : List Nat) : parseRaw 4066 26 (linear_b102 ++ tail) = some (linear_r102, tail) := by rfl
def linear_r103 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,49])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,56])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b103 : List Nat := linear_g261
theorem mutated_s103 : serializeRaw 4065 26 linear_r103 = some linear_b103 := by decide +kernel
theorem mutated_p103 (tail : List Nat) : parseRaw 4065 26 (linear_b103 ++ tail) = some (linear_r103, tail) := by rfl
def linear_r104 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,55]),(.str [100,103,95,118,95,49,49,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,119,114,97,112])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,57])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b104 : List Nat := linear_g263
theorem mutated_s104 : serializeRaw 4064 26 linear_r104 = some linear_b104 := by decide +kernel
theorem mutated_p104 (tail : List Nat) : parseRaw 4064 26 (linear_b104 ++ tail) = some (linear_r104, tail) := by rfl
def linear_r105 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,57])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,48])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b105 : List Nat := linear_g265
theorem mutated_s105 : serializeRaw 4063 26 linear_r105 = some linear_b105 := by decide +kernel
theorem mutated_p105 (tail : List Nat) : parseRaw 4063 26 (linear_b105 ++ tail) = some (linear_r105, tail) := by rfl
def linear_r106 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,109,117,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,49])),([116,121,112,101],(.str [109,117,116,98,117,102]))])]))])
def linear_b106 : List Nat := linear_g267
theorem mutated_s106 : serializeRaw 4062 26 linear_r106 = some linear_b106 := by decide +kernel
theorem mutated_p106 (tail : List Nat) : parseRaw 4062 26 (linear_b106 ++ tail) = some (linear_r106, tail) := by rfl
def linear_r107 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49]),(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,115,116,111,114,101])),([111,117,116],(.arr []))])
def linear_b107 : List Nat := linear_g269
theorem mutated_s107 : serializeRaw 4061 26 linear_r107 = some linear_b107 := by decide +kernel
theorem mutated_p107 (tail : List Nat) : parseRaw 4061 26 (linear_b107 ++ tail) = some (linear_r107, tail) := by rfl
def linear_r108 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b108 : List Nat := linear_g271
theorem mutated_s108 : serializeRaw 4060 26 linear_r108 = some linear_b108 := by decide +kernel
theorem mutated_p108 (tail : List Nat) : parseRaw 4060 26 (linear_b108 ++ tail) = some (linear_r108, tail) := by rfl
def linear_r109 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b109 : List Nat := linear_g273
theorem mutated_s109 : serializeRaw 4059 26 linear_r109 = some linear_b109 := by decide +kernel
theorem mutated_p109 (tail : List Nat) : parseRaw 4059 26 (linear_b109 ++ tail) = some (linear_r109, tail) := by rfl
def linear_r110 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,52]),(.str [100,103,95,118,95,49,50,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b110 : List Nat := linear_g275
theorem mutated_s110 : serializeRaw 4058 26 linear_r110 = some linear_b110 := by decide +kernel
theorem mutated_p110 (tail : List Nat) : parseRaw 4058 26 (linear_b110 ++ tail) = some (linear_r110, tail) := by rfl
def linear_l99_10 : List Raw := [linear_r110]
def linear_v99_10 : List Nat := linear_b110
theorem mutated_sl99_10 : serializeItems 4059 26 linear_l99_10 = some linear_v99_10 := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4058 26 linear_r110 linear_b110 mutated_s110)
theorem mutated_pl99_10 (tail : List Nat) : parseItems 4059 26 (linear_v99_10 ++ (93 :: tail)) = some (linear_l99_10, tail) := by
  simpa only [linear_l99_10, linear_v99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4058 26 (linear_b110 ++ (93 :: tail)) tail linear_r110 (mutated_p110 (93 :: tail)))
def linear_l99_9 : List Raw := linear_r109 :: linear_l99_10
def linear_v99_9 : List Nat := (linear_b109) ++ (44 :: linear_v99_10)
theorem mutated_sl99_9 : serializeItems 4060 26 linear_l99_9 = some linear_v99_9 := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4059 26 linear_r109 linear_r110 [] linear_b109 linear_v99_10 mutated_s109 mutated_sl99_10)
theorem mutated_pl99_9 (tail : List Nat) : parseItems 4060 26 (linear_v99_9 ++ (93 :: tail)) = some (linear_l99_9, tail) := by
  simpa only [linear_l99_9, linear_v99_9, linear_l99_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4059 26 (linear_b109 ++ (44 :: (linear_v99_10 ++ (93 :: tail)))) (linear_v99_10 ++ (93 :: tail)) tail linear_r109 linear_l99_10 (mutated_p109 (44 :: (linear_v99_10 ++ (93 :: tail)))) (mutated_pl99_10 tail))
def linear_l99_8 : List Raw := linear_r108 :: linear_l99_9
def linear_v99_8 : List Nat := (linear_b108) ++ (44 :: linear_v99_9)
theorem mutated_sl99_8 : serializeItems 4061 26 linear_l99_8 = some linear_v99_8 := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r108 linear_r109 linear_l99_10 linear_b108 linear_v99_9 mutated_s108 mutated_sl99_9)
theorem mutated_pl99_8 (tail : List Nat) : parseItems 4061 26 (linear_v99_8 ++ (93 :: tail)) = some (linear_l99_8, tail) := by
  simpa only [linear_l99_8, linear_v99_8, linear_l99_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b108 ++ (44 :: (linear_v99_9 ++ (93 :: tail)))) (linear_v99_9 ++ (93 :: tail)) tail linear_r108 linear_l99_9 (mutated_p108 (44 :: (linear_v99_9 ++ (93 :: tail)))) (mutated_pl99_9 tail))
def linear_l99_7 : List Raw := linear_r107 :: linear_l99_8
def linear_v99_7 : List Nat := (linear_b107) ++ (44 :: linear_v99_8)
theorem mutated_sl99_7 : serializeItems 4062 26 linear_l99_7 = some linear_v99_7 := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r107 linear_r108 linear_l99_9 linear_b107 linear_v99_8 mutated_s107 mutated_sl99_8)
theorem mutated_pl99_7 (tail : List Nat) : parseItems 4062 26 (linear_v99_7 ++ (93 :: tail)) = some (linear_l99_7, tail) := by
  simpa only [linear_l99_7, linear_v99_7, linear_l99_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b107 ++ (44 :: (linear_v99_8 ++ (93 :: tail)))) (linear_v99_8 ++ (93 :: tail)) tail linear_r107 linear_l99_8 (mutated_p107 (44 :: (linear_v99_8 ++ (93 :: tail)))) (mutated_pl99_8 tail))
def linear_l99_6 : List Raw := linear_r106 :: linear_l99_7
def linear_v99_6 : List Nat := (linear_b106) ++ (44 :: linear_v99_7)
theorem mutated_sl99_6 : serializeItems 4063 26 linear_l99_6 = some linear_v99_6 := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r106 linear_r107 linear_l99_8 linear_b106 linear_v99_7 mutated_s106 mutated_sl99_7)
theorem mutated_pl99_6 (tail : List Nat) : parseItems 4063 26 (linear_v99_6 ++ (93 :: tail)) = some (linear_l99_6, tail) := by
  simpa only [linear_l99_6, linear_v99_6, linear_l99_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b106 ++ (44 :: (linear_v99_7 ++ (93 :: tail)))) (linear_v99_7 ++ (93 :: tail)) tail linear_r106 linear_l99_7 (mutated_p106 (44 :: (linear_v99_7 ++ (93 :: tail)))) (mutated_pl99_7 tail))
def linear_l99_5 : List Raw := linear_r105 :: linear_l99_6
def linear_v99_5 : List Nat := (linear_b105) ++ (44 :: linear_v99_6)
theorem mutated_sl99_5 : serializeItems 4064 26 linear_l99_5 = some linear_v99_5 := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r105 linear_r106 linear_l99_7 linear_b105 linear_v99_6 mutated_s105 mutated_sl99_6)
theorem mutated_pl99_5 (tail : List Nat) : parseItems 4064 26 (linear_v99_5 ++ (93 :: tail)) = some (linear_l99_5, tail) := by
  simpa only [linear_l99_5, linear_v99_5, linear_l99_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b105 ++ (44 :: (linear_v99_6 ++ (93 :: tail)))) (linear_v99_6 ++ (93 :: tail)) tail linear_r105 linear_l99_6 (mutated_p105 (44 :: (linear_v99_6 ++ (93 :: tail)))) (mutated_pl99_6 tail))
def linear_l99_4 : List Raw := linear_r104 :: linear_l99_5
def linear_v99_4 : List Nat := (linear_b104) ++ (44 :: linear_v99_5)
theorem mutated_sl99_4 : serializeItems 4065 26 linear_l99_4 = some linear_v99_4 := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r104 linear_r105 linear_l99_6 linear_b104 linear_v99_5 mutated_s104 mutated_sl99_5)
theorem mutated_pl99_4 (tail : List Nat) : parseItems 4065 26 (linear_v99_4 ++ (93 :: tail)) = some (linear_l99_4, tail) := by
  simpa only [linear_l99_4, linear_v99_4, linear_l99_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b104 ++ (44 :: (linear_v99_5 ++ (93 :: tail)))) (linear_v99_5 ++ (93 :: tail)) tail linear_r104 linear_l99_5 (mutated_p104 (44 :: (linear_v99_5 ++ (93 :: tail)))) (mutated_pl99_5 tail))
def linear_l99_3 : List Raw := linear_r103 :: linear_l99_4
def linear_v99_3 : List Nat := (linear_b103) ++ (44 :: linear_v99_4)
theorem mutated_sl99_3 : serializeItems 4066 26 linear_l99_3 = some linear_v99_3 := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r103 linear_r104 linear_l99_5 linear_b103 linear_v99_4 mutated_s103 mutated_sl99_4)
theorem mutated_pl99_3 (tail : List Nat) : parseItems 4066 26 (linear_v99_3 ++ (93 :: tail)) = some (linear_l99_3, tail) := by
  simpa only [linear_l99_3, linear_v99_3, linear_l99_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b103 ++ (44 :: (linear_v99_4 ++ (93 :: tail)))) (linear_v99_4 ++ (93 :: tail)) tail linear_r103 linear_l99_4 (mutated_p103 (44 :: (linear_v99_4 ++ (93 :: tail)))) (mutated_pl99_4 tail))
def linear_l99_2 : List Raw := linear_r102 :: linear_l99_3
def linear_v99_2 : List Nat := (linear_b102) ++ (44 :: linear_v99_3)
theorem mutated_sl99_2 : serializeItems 4067 26 linear_l99_2 = some linear_v99_2 := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4066 26 linear_r102 linear_r103 linear_l99_4 linear_b102 linear_v99_3 mutated_s102 mutated_sl99_3)
theorem mutated_pl99_2 (tail : List Nat) : parseItems 4067 26 (linear_v99_2 ++ (93 :: tail)) = some (linear_l99_2, tail) := by
  simpa only [linear_l99_2, linear_v99_2, linear_l99_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4066 26 (linear_b102 ++ (44 :: (linear_v99_3 ++ (93 :: tail)))) (linear_v99_3 ++ (93 :: tail)) tail linear_r102 linear_l99_3 (mutated_p102 (44 :: (linear_v99_3 ++ (93 :: tail)))) (mutated_pl99_3 tail))
def linear_l99_1 : List Raw := linear_r101 :: linear_l99_2
def linear_v99_1 : List Nat := (linear_b101) ++ (44 :: linear_v99_2)
theorem mutated_sl99_1 : serializeItems 4068 26 linear_l99_1 = some linear_v99_1 := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4067 26 linear_r101 linear_r102 linear_l99_3 linear_b101 linear_v99_2 mutated_s101 mutated_sl99_2)
theorem mutated_pl99_1 (tail : List Nat) : parseItems 4068 26 (linear_v99_1 ++ (93 :: tail)) = some (linear_l99_1, tail) := by
  simpa only [linear_l99_1, linear_v99_1, linear_l99_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4067 26 (linear_b101 ++ (44 :: (linear_v99_2 ++ (93 :: tail)))) (linear_v99_2 ++ (93 :: tail)) tail linear_r101 linear_l99_2 (mutated_p101 (44 :: (linear_v99_2 ++ (93 :: tail)))) (mutated_pl99_2 tail))
def linear_l99_0 : List Raw := linear_r100 :: linear_l99_1
def linear_v99_0 : List Nat := (linear_b100) ++ (44 :: linear_v99_1)
theorem mutated_sl99_0 : serializeItems 4069 26 linear_l99_0 = some linear_v99_0 := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 26 linear_r100 linear_r101 linear_l99_2 linear_b100 linear_v99_1 mutated_s100 mutated_sl99_1)
theorem mutated_pl99_0 (tail : List Nat) : parseItems 4069 26 (linear_v99_0 ++ (93 :: tail)) = some (linear_l99_0, tail) := by
  simpa only [linear_l99_0, linear_v99_0, linear_l99_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 26 (linear_b100 ++ (44 :: (linear_v99_1 ++ (93 :: tail)))) (linear_v99_1 ++ (93 :: tail)) tail linear_r100 linear_l99_1 (mutated_p100 (44 :: (linear_v99_1 ++ (93 :: tail)))) (mutated_pl99_1 tail))
def linear_r99 : Raw := (.arr linear_l99_0)
def linear_b99 : List Nat := linear_g254 ++ (linear_v99_0 ++ linear_g276)
theorem mutated_s99 : serializeRaw 4070 27 linear_r99 = some linear_b99 := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4069 26 linear_l99_0 linear_v99_0 mutated_sl99_0)
theorem mutated_p99 (tail : List Nat) : parseRaw 4070 27 (linear_b99 ++ tail) = some (linear_r99, tail) := by
  simpa only [linear_r99, linear_b99, linear_g254, linear_g276, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4069 26 (linear_v99_0 ++ (93 :: tail)) tail linear_l99_0 (by intro h; cases h) (mutated_pl99_0 tail))
def linear_r111 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b111 : List Nat := linear_g279
theorem mutated_s111 : serializeRaw 4069 27 linear_r111 = some linear_b111 := by decide +kernel
theorem mutated_p111 (tail : List Nat) : parseRaw 4069 27 (linear_b111 ++ tail) = some (linear_r111, tail) := by rfl
def linear_r112 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,49,48]),(.str [100,103,95,118,95,49,49,49]),(.str [100,103,95,118,95,49,49,50]),(.str [100,103,95,118,95,49,49,51]),(.str [100,103,95,118,95,49,50,51])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,48]))])
def linear_b112 : List Nat := linear_g282
theorem mutated_s112 : serializeRaw 4068 27 linear_r112 = some linear_b112 := by decide +kernel
theorem mutated_p112 (tail : List Nat) : parseRaw 4068 27 (linear_b112 ++ tail) = some (linear_r112, tail) := by rfl
def linear_k97_0 : List Nat := [105,100]
theorem mutated_kd97_0 : stringBytes linear_k97_0 = true := by decide +kernel
theorem mutated_kp97_0 (tail : List Nat) : parseStringTail (linear_k97_0 ++ (34 :: 58 :: tail)) [] = some (linear_k97_0, 58 :: tail) := by rfl
def linear_k97_1 : List Nat := [111,112,115]
theorem mutated_kd97_1 : stringBytes linear_k97_1 = true := by decide +kernel
theorem mutated_kp97_1 (tail : List Nat) : parseStringTail (linear_k97_1 ++ (34 :: 58 :: tail)) [] = some (linear_k97_1, 58 :: tail) := by rfl
def linear_k97_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd97_2 : stringBytes linear_k97_2 = true := by decide +kernel
theorem mutated_kp97_2 (tail : List Nat) : parseStringTail (linear_k97_2 ++ (34 :: 58 :: tail)) [] = some (linear_k97_2, 58 :: tail) := by rfl
def linear_k97_3 : List Nat := [116,101,114,109]
theorem mutated_kd97_3 : stringBytes linear_k97_3 = true := by decide +kernel
theorem mutated_kp97_3 (tail : List Nat) : parseStringTail (linear_k97_3 ++ (34 :: 58 :: tail)) [] = some (linear_k97_3, 58 :: tail) := by rfl
def linear_l97_3 : List (List Nat × Raw) := [(linear_k97_3, linear_r112)]
def linear_v97_3 : List Nat := linear_g281 ++ linear_b112
theorem mutated_sl97_3 : serializeFields 4069 27 linear_l97_3 = some linear_v97_3 := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4068 27 linear_k97_3 linear_r112 linear_b112 mutated_kd97_3 mutated_s112)
theorem mutated_pl97_3 (tail : List Nat) : parseFields 4069 27 (linear_v97_3 ++ (125 :: tail)) = some (linear_l97_3, tail) := by
  simpa only [linear_l97_3, linear_v97_3, linear_k97_3, linear_g281, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4068 27 (linear_k97_3 ++ (34 :: 58 :: (linear_b112 ++ (125 :: tail)))) linear_k97_3 (linear_b112 ++ (125 :: tail)) tail linear_r112 (mutated_kp97_3 (linear_b112 ++ (125 :: tail))) (mutated_p112 (125 :: tail)))
def linear_l97_2 : List (List Nat × Raw) := (linear_k97_2, linear_r111) :: linear_l97_3
def linear_v97_2 : List Nat := (linear_g278 ++ linear_b111) ++ (44 :: linear_v97_3)
theorem mutated_sl97_2 : serializeFields 4070 27 linear_l97_2 = some linear_v97_2 := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k97_2 linear_r111 (linear_k97_3, linear_r112) [] linear_b111 linear_v97_3 mutated_kd97_2 mutated_s111 mutated_sl97_3)
theorem mutated_pl97_2 (tail : List Nat) : parseFields 4070 27 (linear_v97_2 ++ (125 :: tail)) = some (linear_l97_2, tail) := by
  simpa only [linear_l97_2, linear_v97_2, linear_k97_2, linear_g278, linear_l97_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k97_2 ++ (34 :: 58 :: (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))))) linear_k97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail)))) (linear_v97_3 ++ (125 :: tail)) tail linear_r111 linear_l97_3 (mutated_kp97_2 (linear_b111 ++ (44 :: (linear_v97_3 ++ (125 :: tail))))) (mutated_p111 (44 :: (linear_v97_3 ++ (125 :: tail)))) (mutated_pl97_3 tail))
def linear_l97_1 : List (List Nat × Raw) := (linear_k97_1, linear_r99) :: linear_l97_2
def linear_v97_1 : List Nat := (linear_g253 ++ linear_b99) ++ (44 :: linear_v97_2)
theorem mutated_sl97_1 : serializeFields 4071 27 linear_l97_1 = some linear_v97_1 := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k97_1 linear_r99 (linear_k97_2, linear_r111) linear_l97_3 linear_b99 linear_v97_2 mutated_kd97_1 mutated_s99 mutated_sl97_2)
theorem mutated_pl97_1 (tail : List Nat) : parseFields 4071 27 (linear_v97_1 ++ (125 :: tail)) = some (linear_l97_1, tail) := by
  simpa only [linear_l97_1, linear_v97_1, linear_k97_1, linear_g253, linear_l97_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k97_1 ++ (34 :: 58 :: (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))))) linear_k97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail)))) (linear_v97_2 ++ (125 :: tail)) tail linear_r99 linear_l97_2 (mutated_kp97_1 (linear_b99 ++ (44 :: (linear_v97_2 ++ (125 :: tail))))) (mutated_p99 (44 :: (linear_v97_2 ++ (125 :: tail)))) (mutated_pl97_2 tail))
def linear_l97_0 : List (List Nat × Raw) := (linear_k97_0, linear_r98) :: linear_l97_1
def linear_v97_0 : List Nat := (linear_g250 ++ linear_b98) ++ (44 :: linear_v97_1)
theorem mutated_sl97_0 : serializeFields 4072 27 linear_l97_0 = some linear_v97_0 := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4071 27 linear_k97_0 linear_r98 (linear_k97_1, linear_r99) linear_l97_2 linear_b98 linear_v97_1 mutated_kd97_0 mutated_s98 mutated_sl97_1)
theorem mutated_pl97_0 (tail : List Nat) : parseFields 4072 27 (linear_v97_0 ++ (125 :: tail)) = some (linear_l97_0, tail) := by
  simpa only [linear_l97_0, linear_v97_0, linear_k97_0, linear_g250, linear_l97_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4071 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) linear_k97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))) (linear_v97_1 ++ (125 :: tail)) tail linear_r98 linear_l97_1 (mutated_kp97_0 (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail))))) (mutated_p98 (44 :: (linear_v97_1 ++ (125 :: tail)))) (mutated_pl97_1 tail))
def linear_r97 : Raw := (.obj linear_l97_0)
def linear_b97 : List Nat := linear_g249 ++ (linear_v97_0 ++ linear_g283)
theorem mutated_o97 : orderedFields linear_l97_0 = true := by decide +kernel
theorem mutated_s97 : serializeRaw 4073 28 linear_r97 = some linear_b97 := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4072 27 linear_l97_0 linear_v97_0 mutated_o97 mutated_sl97_0)
theorem mutated_p97 (tail : List Nat) : parseRaw 4073 28 (linear_b97 ++ tail) = some (linear_r97, tail) := by
  simpa only [linear_r97, linear_b97, linear_g249, linear_g283, linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4072 27 (linear_k97_0 ++ (34 :: 58 :: (linear_b98 ++ (44 :: (linear_v97_1 ++ (125 :: tail)))))) tail linear_l97_0 mutated_o97 (by simpa only [linear_v97_0, linear_k97_0, linear_g250, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl97_0 tail)))
def linear_r114 : Raw := (.str [100,103,95,115,108,111,119,95,50])
def linear_b114 : List Nat := linear_g287
theorem mutated_s114 : serializeRaw 4070 27 linear_r114 = some linear_b114 := by decide +kernel
theorem mutated_p114 (tail : List Nat) : parseRaw 4070 27 (linear_b114 ++ tail) = some (linear_r114, tail) := by rfl
def linear_r115 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,57])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b115 : List Nat := linear_g290
theorem mutated_s115 : serializeRaw 4069 27 linear_r115 = some linear_b115 := by decide +kernel
theorem mutated_p115 (tail : List Nat) : parseRaw 4069 27 (linear_b115 ++ tail) = some (linear_r115, tail) := by rfl
def linear_r116 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,53])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50,56])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b116 : List Nat := linear_g293
theorem mutated_s116 : serializeRaw 4068 27 linear_r116 = some linear_b116 := by decide +kernel
theorem mutated_p116 (tail : List Nat) : parseRaw 4068 27 (linear_b116 ++ tail) = some (linear_r116, tail) := by rfl
def linear_r117 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,50,53]),(.str [100,103,95,118,95,49,50,54]),(.str [100,103,95,118,95,49,50,57]),(.str [100,103,95,118,95,49,50,52]),(.str [100,103,95,118,95,49,51,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b117 : List Nat := linear_g296
theorem mutated_s117 : serializeRaw 4067 27 linear_r117 = some linear_b117 := by decide +kernel
theorem mutated_p117 (tail : List Nat) : parseRaw 4067 27 (linear_b117 ++ tail) = some (linear_r117, tail) := by rfl
def linear_k113_0 : List Nat := [105,100]
theorem mutated_kd113_0 : stringBytes linear_k113_0 = true := by decide +kernel
theorem mutated_kp113_0 (tail : List Nat) : parseStringTail (linear_k113_0 ++ (34 :: 58 :: tail)) [] = some (linear_k113_0, 58 :: tail) := by rfl
def linear_k113_1 : List Nat := [111,112,115]
theorem mutated_kd113_1 : stringBytes linear_k113_1 = true := by decide +kernel
theorem mutated_kp113_1 (tail : List Nat) : parseStringTail (linear_k113_1 ++ (34 :: 58 :: tail)) [] = some (linear_k113_1, 58 :: tail) := by rfl
def linear_k113_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd113_2 : stringBytes linear_k113_2 = true := by decide +kernel
theorem mutated_kp113_2 (tail : List Nat) : parseStringTail (linear_k113_2 ++ (34 :: 58 :: tail)) [] = some (linear_k113_2, 58 :: tail) := by rfl
def linear_k113_3 : List Nat := [116,101,114,109]
theorem mutated_kd113_3 : stringBytes linear_k113_3 = true := by decide +kernel
theorem mutated_kp113_3 (tail : List Nat) : parseStringTail (linear_k113_3 ++ (34 :: 58 :: tail)) [] = some (linear_k113_3, 58 :: tail) := by rfl
def linear_l113_3 : List (List Nat × Raw) := [(linear_k113_3, linear_r117)]
def linear_v113_3 : List Nat := linear_g295 ++ linear_b117
theorem mutated_sl113_3 : serializeFields 4068 27 linear_l113_3 = some linear_v113_3 := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4067 27 linear_k113_3 linear_r117 linear_b117 mutated_kd113_3 mutated_s117)
theorem mutated_pl113_3 (tail : List Nat) : parseFields 4068 27 (linear_v113_3 ++ (125 :: tail)) = some (linear_l113_3, tail) := by
  simpa only [linear_l113_3, linear_v113_3, linear_k113_3, linear_g295, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4067 27 (linear_k113_3 ++ (34 :: 58 :: (linear_b117 ++ (125 :: tail)))) linear_k113_3 (linear_b117 ++ (125 :: tail)) tail linear_r117 (mutated_kp113_3 (linear_b117 ++ (125 :: tail))) (mutated_p117 (125 :: tail)))
def linear_l113_2 : List (List Nat × Raw) := (linear_k113_2, linear_r116) :: linear_l113_3
def linear_v113_2 : List Nat := (linear_g292 ++ linear_b116) ++ (44 :: linear_v113_3)
theorem mutated_sl113_2 : serializeFields 4069 27 linear_l113_2 = some linear_v113_2 := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k113_2 linear_r116 (linear_k113_3, linear_r117) [] linear_b116 linear_v113_3 mutated_kd113_2 mutated_s116 mutated_sl113_3)
theorem mutated_pl113_2 (tail : List Nat) : parseFields 4069 27 (linear_v113_2 ++ (125 :: tail)) = some (linear_l113_2, tail) := by
  simpa only [linear_l113_2, linear_v113_2, linear_k113_2, linear_g292, linear_l113_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k113_2 ++ (34 :: 58 :: (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))))) linear_k113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail)))) (linear_v113_3 ++ (125 :: tail)) tail linear_r116 linear_l113_3 (mutated_kp113_2 (linear_b116 ++ (44 :: (linear_v113_3 ++ (125 :: tail))))) (mutated_p116 (44 :: (linear_v113_3 ++ (125 :: tail)))) (mutated_pl113_3 tail))
def linear_l113_1 : List (List Nat × Raw) := (linear_k113_1, linear_r115) :: linear_l113_2
def linear_v113_1 : List Nat := (linear_g289 ++ linear_b115) ++ (44 :: linear_v113_2)
theorem mutated_sl113_1 : serializeFields 4070 27 linear_l113_1 = some linear_v113_1 := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k113_1 linear_r115 (linear_k113_2, linear_r116) linear_l113_3 linear_b115 linear_v113_2 mutated_kd113_1 mutated_s115 mutated_sl113_2)
theorem mutated_pl113_1 (tail : List Nat) : parseFields 4070 27 (linear_v113_1 ++ (125 :: tail)) = some (linear_l113_1, tail) := by
  simpa only [linear_l113_1, linear_v113_1, linear_k113_1, linear_g289, linear_l113_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k113_1 ++ (34 :: 58 :: (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))))) linear_k113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail)))) (linear_v113_2 ++ (125 :: tail)) tail linear_r115 linear_l113_2 (mutated_kp113_1 (linear_b115 ++ (44 :: (linear_v113_2 ++ (125 :: tail))))) (mutated_p115 (44 :: (linear_v113_2 ++ (125 :: tail)))) (mutated_pl113_2 tail))
def linear_l113_0 : List (List Nat × Raw) := (linear_k113_0, linear_r114) :: linear_l113_1
def linear_v113_0 : List Nat := (linear_g286 ++ linear_b114) ++ (44 :: linear_v113_1)
theorem mutated_sl113_0 : serializeFields 4071 27 linear_l113_0 = some linear_v113_0 := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4070 27 linear_k113_0 linear_r114 (linear_k113_1, linear_r115) linear_l113_2 linear_b114 linear_v113_1 mutated_kd113_0 mutated_s114 mutated_sl113_1)
theorem mutated_pl113_0 (tail : List Nat) : parseFields 4071 27 (linear_v113_0 ++ (125 :: tail)) = some (linear_l113_0, tail) := by
  simpa only [linear_l113_0, linear_v113_0, linear_k113_0, linear_g286, linear_l113_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4070 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) linear_k113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))) (linear_v113_1 ++ (125 :: tail)) tail linear_r114 linear_l113_1 (mutated_kp113_0 (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail))))) (mutated_p114 (44 :: (linear_v113_1 ++ (125 :: tail)))) (mutated_pl113_1 tail))
def linear_r113 : Raw := (.obj linear_l113_0)
def linear_b113 : List Nat := linear_g285 ++ (linear_v113_0 ++ linear_g297)
theorem mutated_o113 : orderedFields linear_l113_0 = true := by decide +kernel
theorem mutated_s113 : serializeRaw 4072 28 linear_r113 = some linear_b113 := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4071 27 linear_l113_0 linear_v113_0 mutated_o113 mutated_sl113_0)
theorem mutated_p113 (tail : List Nat) : parseRaw 4072 28 (linear_b113 ++ tail) = some (linear_r113, tail) := by
  simpa only [linear_r113, linear_b113, linear_g285, linear_g297, linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4071 27 (linear_k113_0 ++ (34 :: 58 :: (linear_b114 ++ (44 :: (linear_v113_1 ++ (125 :: tail)))))) tail linear_l113_0 mutated_o113 (by simpa only [linear_v113_0, linear_k113_0, linear_g286, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl113_0 tail)))
def linear_r119 : Raw := (.str [100,103,95,115,108,111,119,95,51])
def linear_b119 : List Nat := linear_g301
theorem mutated_s119 : serializeRaw 4069 27 linear_r119 = some linear_b119 := by decide +kernel
theorem mutated_p119 (tail : List Nat) : parseRaw 4069 27 (linear_b119 ++ tail) = some (linear_r119, tail) := by rfl
def linear_r120 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,54]),(.str [100,103,95,118,95,49,51,53])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,55])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b120 : List Nat := linear_g304
theorem mutated_s120 : serializeRaw 4068 27 linear_r120 = some linear_b120 := by decide +kernel
theorem mutated_p120 (tail : List Nat) : parseRaw 4068 27 (linear_b120 ++ tail) = some (linear_r120, tail) := by rfl
def linear_r121 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,51])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,52])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b121 : List Nat := linear_g307
theorem mutated_s121 : serializeRaw 4067 27 linear_r121 = some linear_b121 := by decide +kernel
theorem mutated_p121 (tail : List Nat) : parseRaw 4067 27 (linear_b121 ++ tail) = some (linear_r121, tail) := by rfl
def linear_r122 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,51,55])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,53]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,49]),(.str [100,103,95,118,95,49,51,50]),(.str [100,103,95,118,95,49,51,51]),(.str [100,103,95,118,95,49,51,52]),(.str [100,103,95,118,95,49,51,53]),(.str [100,103,95,118,95,49,51,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))]))])
def linear_b122 : List Nat := linear_g310
theorem mutated_s122 : serializeRaw 4066 27 linear_r122 = some linear_b122 := by decide +kernel
theorem mutated_p122 (tail : List Nat) : parseRaw 4066 27 (linear_b122 ++ tail) = some (linear_r122, tail) := by rfl
def linear_k118_0 : List Nat := [105,100]
theorem mutated_kd118_0 : stringBytes linear_k118_0 = true := by decide +kernel
theorem mutated_kp118_0 (tail : List Nat) : parseStringTail (linear_k118_0 ++ (34 :: 58 :: tail)) [] = some (linear_k118_0, 58 :: tail) := by rfl
def linear_k118_1 : List Nat := [111,112,115]
theorem mutated_kd118_1 : stringBytes linear_k118_1 = true := by decide +kernel
theorem mutated_kp118_1 (tail : List Nat) : parseStringTail (linear_k118_1 ++ (34 :: 58 :: tail)) [] = some (linear_k118_1, 58 :: tail) := by rfl
def linear_k118_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd118_2 : stringBytes linear_k118_2 = true := by decide +kernel
theorem mutated_kp118_2 (tail : List Nat) : parseStringTail (linear_k118_2 ++ (34 :: 58 :: tail)) [] = some (linear_k118_2, 58 :: tail) := by rfl
def linear_k118_3 : List Nat := [116,101,114,109]
theorem mutated_kd118_3 : stringBytes linear_k118_3 = true := by decide +kernel
theorem mutated_kp118_3 (tail : List Nat) : parseStringTail (linear_k118_3 ++ (34 :: 58 :: tail)) [] = some (linear_k118_3, 58 :: tail) := by rfl
def linear_l118_3 : List (List Nat × Raw) := [(linear_k118_3, linear_r122)]
def linear_v118_3 : List Nat := linear_g309 ++ linear_b122
theorem mutated_sl118_3 : serializeFields 4067 27 linear_l118_3 = some linear_v118_3 := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4066 27 linear_k118_3 linear_r122 linear_b122 mutated_kd118_3 mutated_s122)
theorem mutated_pl118_3 (tail : List Nat) : parseFields 4067 27 (linear_v118_3 ++ (125 :: tail)) = some (linear_l118_3, tail) := by
  simpa only [linear_l118_3, linear_v118_3, linear_k118_3, linear_g309, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4066 27 (linear_k118_3 ++ (34 :: 58 :: (linear_b122 ++ (125 :: tail)))) linear_k118_3 (linear_b122 ++ (125 :: tail)) tail linear_r122 (mutated_kp118_3 (linear_b122 ++ (125 :: tail))) (mutated_p122 (125 :: tail)))
def linear_l118_2 : List (List Nat × Raw) := (linear_k118_2, linear_r121) :: linear_l118_3
def linear_v118_2 : List Nat := (linear_g306 ++ linear_b121) ++ (44 :: linear_v118_3)
theorem mutated_sl118_2 : serializeFields 4068 27 linear_l118_2 = some linear_v118_2 := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k118_2 linear_r121 (linear_k118_3, linear_r122) [] linear_b121 linear_v118_3 mutated_kd118_2 mutated_s121 mutated_sl118_3)
theorem mutated_pl118_2 (tail : List Nat) : parseFields 4068 27 (linear_v118_2 ++ (125 :: tail)) = some (linear_l118_2, tail) := by
  simpa only [linear_l118_2, linear_v118_2, linear_k118_2, linear_g306, linear_l118_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k118_2 ++ (34 :: 58 :: (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))))) linear_k118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail)))) (linear_v118_3 ++ (125 :: tail)) tail linear_r121 linear_l118_3 (mutated_kp118_2 (linear_b121 ++ (44 :: (linear_v118_3 ++ (125 :: tail))))) (mutated_p121 (44 :: (linear_v118_3 ++ (125 :: tail)))) (mutated_pl118_3 tail))
def linear_l118_1 : List (List Nat × Raw) := (linear_k118_1, linear_r120) :: linear_l118_2
def linear_v118_1 : List Nat := (linear_g303 ++ linear_b120) ++ (44 :: linear_v118_2)
theorem mutated_sl118_1 : serializeFields 4069 27 linear_l118_1 = some linear_v118_1 := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k118_1 linear_r120 (linear_k118_2, linear_r121) linear_l118_3 linear_b120 linear_v118_2 mutated_kd118_1 mutated_s120 mutated_sl118_2)
theorem mutated_pl118_1 (tail : List Nat) : parseFields 4069 27 (linear_v118_1 ++ (125 :: tail)) = some (linear_l118_1, tail) := by
  simpa only [linear_l118_1, linear_v118_1, linear_k118_1, linear_g303, linear_l118_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k118_1 ++ (34 :: 58 :: (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))))) linear_k118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail)))) (linear_v118_2 ++ (125 :: tail)) tail linear_r120 linear_l118_2 (mutated_kp118_1 (linear_b120 ++ (44 :: (linear_v118_2 ++ (125 :: tail))))) (mutated_p120 (44 :: (linear_v118_2 ++ (125 :: tail)))) (mutated_pl118_2 tail))
def linear_l118_0 : List (List Nat × Raw) := (linear_k118_0, linear_r119) :: linear_l118_1
def linear_v118_0 : List Nat := (linear_g300 ++ linear_b119) ++ (44 :: linear_v118_1)
theorem mutated_sl118_0 : serializeFields 4070 27 linear_l118_0 = some linear_v118_0 := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4069 27 linear_k118_0 linear_r119 (linear_k118_1, linear_r120) linear_l118_2 linear_b119 linear_v118_1 mutated_kd118_0 mutated_s119 mutated_sl118_1)
theorem mutated_pl118_0 (tail : List Nat) : parseFields 4070 27 (linear_v118_0 ++ (125 :: tail)) = some (linear_l118_0, tail) := by
  simpa only [linear_l118_0, linear_v118_0, linear_k118_0, linear_g300, linear_l118_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4069 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) linear_k118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))) (linear_v118_1 ++ (125 :: tail)) tail linear_r119 linear_l118_1 (mutated_kp118_0 (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail))))) (mutated_p119 (44 :: (linear_v118_1 ++ (125 :: tail)))) (mutated_pl118_1 tail))
def linear_r118 : Raw := (.obj linear_l118_0)
def linear_b118 : List Nat := linear_g299 ++ (linear_v118_0 ++ linear_g311)
theorem mutated_o118 : orderedFields linear_l118_0 = true := by decide +kernel
theorem mutated_s118 : serializeRaw 4071 28 linear_r118 = some linear_b118 := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4070 27 linear_l118_0 linear_v118_0 mutated_o118 mutated_sl118_0)
theorem mutated_p118 (tail : List Nat) : parseRaw 4071 28 (linear_b118 ++ tail) = some (linear_r118, tail) := by
  simpa only [linear_r118, linear_b118, linear_g299, linear_g311, linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4070 27 (linear_k118_0 ++ (34 :: 58 :: (linear_b119 ++ (44 :: (linear_v118_1 ++ (125 :: tail)))))) tail linear_l118_0 mutated_o118 (by simpa only [linear_v118_0, linear_k118_0, linear_g300, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl118_0 tail)))
def linear_r124 : Raw := (.str [100,103,95,115,108,111,119,95,52])
def linear_b124 : List Nat := linear_g315
theorem mutated_s124 : serializeRaw 4068 27 linear_r124 = some linear_b124 := by decide +kernel
theorem mutated_p124 (tail : List Nat) : parseRaw 4068 27 (linear_b124 ++ tail) = some (linear_r124, tail) := by rfl
def linear_r126 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,48])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,111,114,114,111,119,46,114,101,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,52])),([116,121,112,101],(.str [114,101,97,100,98,117,102]))])]))])
def linear_b126 : List Nat := linear_g319
theorem mutated_s126 : serializeRaw 4065 26 linear_r126 = some linear_b126 := by decide +kernel
theorem mutated_p126 (tail : List Nat) : parseRaw 4065 26 (linear_b126 ++ tail) = some (linear_r126, tail) := by rfl
def linear_r127 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52]),(.str [100,103,95,118,95,49,52,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,108,111,97,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,53])),([116,121,112,101],(.str [117,56]))])]))])
def linear_b127 : List Nat := linear_g321
theorem mutated_s127 : serializeRaw 4064 26 linear_r127 = some linear_b127 := by decide +kernel
theorem mutated_p127 (tail : List Nat) : parseRaw 4064 26 (linear_b127 ++ tail) = some (linear_r127, tail) := by rfl
def linear_r128 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [108,111,97,110,46,101,110,100])),([111,117,116],(.arr []))])
def linear_b128 : List Nat := linear_g323
theorem mutated_s128 : serializeRaw 4063 26 linear_r128 = some linear_b128 := by decide +kernel
theorem mutated_p128 (tail : List Nat) : parseRaw 4063 26 (linear_b128 ++ tail) = some (linear_r128, tail) := by rfl
def linear_r129 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b129 : List Nat := linear_g325
theorem mutated_s129 : serializeRaw 4062 26 linear_r129 = some linear_b129 := by decide +kernel
theorem mutated_p129 (tail : List Nat) : parseRaw 4062 26 (linear_b129 ++ tail) = some (linear_r129, tail) := by rfl
def linear_r130 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,49]),(.str [100,103,95,118,95,49,52,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b130 : List Nat := linear_g327
theorem mutated_s130 : serializeRaw 4061 26 linear_r130 = some linear_b130 := by decide +kernel
theorem mutated_p130 (tail : List Nat) : parseRaw 4061 26 (linear_b130 ++ tail) = some (linear_r130, tail) := by rfl
def linear_r131 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,56])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b131 : List Nat := linear_g329
theorem mutated_s131 : serializeRaw 4060 26 linear_r131 = some linear_b131 := by decide +kernel
theorem mutated_p131 (tail : List Nat) : parseRaw 4060 26 (linear_b131 ++ tail) = some (linear_r131, tail) := by rfl
def linear_r132 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52,51]),(.str [100,103,95,118,95,49,52,56])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])
def linear_b132 : List Nat := linear_g331
theorem mutated_s132 : serializeRaw 4059 26 linear_r132 = some linear_b132 := by decide +kernel
theorem mutated_p132 (tail : List Nat) : parseRaw 4059 26 (linear_b132 ++ tail) = some (linear_r132, tail) := by rfl
def linear_l125_6 : List Raw := [linear_r132]
def linear_v125_6 : List Nat := linear_b132
theorem mutated_sl125_6 : serializeItems 4060 26 linear_l125_6 = some linear_v125_6 := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4059 26 linear_r132 linear_b132 mutated_s132)
theorem mutated_pl125_6 (tail : List Nat) : parseItems 4060 26 (linear_v125_6 ++ (93 :: tail)) = some (linear_l125_6, tail) := by
  simpa only [linear_l125_6, linear_v125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4059 26 (linear_b132 ++ (93 :: tail)) tail linear_r132 (mutated_p132 (93 :: tail)))
def linear_l125_5 : List Raw := linear_r131 :: linear_l125_6
def linear_v125_5 : List Nat := (linear_b131) ++ (44 :: linear_v125_6)
theorem mutated_sl125_5 : serializeItems 4061 26 linear_l125_5 = some linear_v125_5 := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4060 26 linear_r131 linear_r132 [] linear_b131 linear_v125_6 mutated_s131 mutated_sl125_6)
theorem mutated_pl125_5 (tail : List Nat) : parseItems 4061 26 (linear_v125_5 ++ (93 :: tail)) = some (linear_l125_5, tail) := by
  simpa only [linear_l125_5, linear_v125_5, linear_l125_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4060 26 (linear_b131 ++ (44 :: (linear_v125_6 ++ (93 :: tail)))) (linear_v125_6 ++ (93 :: tail)) tail linear_r131 linear_l125_6 (mutated_p131 (44 :: (linear_v125_6 ++ (93 :: tail)))) (mutated_pl125_6 tail))
def linear_l125_4 : List Raw := linear_r130 :: linear_l125_5
def linear_v125_4 : List Nat := (linear_b130) ++ (44 :: linear_v125_5)
theorem mutated_sl125_4 : serializeItems 4062 26 linear_l125_4 = some linear_v125_4 := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4061 26 linear_r130 linear_r131 linear_l125_6 linear_b130 linear_v125_5 mutated_s130 mutated_sl125_5)
theorem mutated_pl125_4 (tail : List Nat) : parseItems 4062 26 (linear_v125_4 ++ (93 :: tail)) = some (linear_l125_4, tail) := by
  simpa only [linear_l125_4, linear_v125_4, linear_l125_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4061 26 (linear_b130 ++ (44 :: (linear_v125_5 ++ (93 :: tail)))) (linear_v125_5 ++ (93 :: tail)) tail linear_r130 linear_l125_5 (mutated_p130 (44 :: (linear_v125_5 ++ (93 :: tail)))) (mutated_pl125_5 tail))
def linear_l125_3 : List Raw := linear_r129 :: linear_l125_4
def linear_v125_3 : List Nat := (linear_b129) ++ (44 :: linear_v125_4)
theorem mutated_sl125_3 : serializeItems 4063 26 linear_l125_3 = some linear_v125_3 := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4062 26 linear_r129 linear_r130 linear_l125_5 linear_b129 linear_v125_4 mutated_s129 mutated_sl125_4)
theorem mutated_pl125_3 (tail : List Nat) : parseItems 4063 26 (linear_v125_3 ++ (93 :: tail)) = some (linear_l125_3, tail) := by
  simpa only [linear_l125_3, linear_v125_3, linear_l125_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4062 26 (linear_b129 ++ (44 :: (linear_v125_4 ++ (93 :: tail)))) (linear_v125_4 ++ (93 :: tail)) tail linear_r129 linear_l125_4 (mutated_p129 (44 :: (linear_v125_4 ++ (93 :: tail)))) (mutated_pl125_4 tail))
def linear_l125_2 : List Raw := linear_r128 :: linear_l125_3
def linear_v125_2 : List Nat := (linear_b128) ++ (44 :: linear_v125_3)
theorem mutated_sl125_2 : serializeItems 4064 26 linear_l125_2 = some linear_v125_2 := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4063 26 linear_r128 linear_r129 linear_l125_4 linear_b128 linear_v125_3 mutated_s128 mutated_sl125_3)
theorem mutated_pl125_2 (tail : List Nat) : parseItems 4064 26 (linear_v125_2 ++ (93 :: tail)) = some (linear_l125_2, tail) := by
  simpa only [linear_l125_2, linear_v125_2, linear_l125_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4063 26 (linear_b128 ++ (44 :: (linear_v125_3 ++ (93 :: tail)))) (linear_v125_3 ++ (93 :: tail)) tail linear_r128 linear_l125_3 (mutated_p128 (44 :: (linear_v125_3 ++ (93 :: tail)))) (mutated_pl125_3 tail))
def linear_l125_1 : List Raw := linear_r127 :: linear_l125_2
def linear_v125_1 : List Nat := (linear_b127) ++ (44 :: linear_v125_2)
theorem mutated_sl125_1 : serializeItems 4065 26 linear_l125_1 = some linear_v125_1 := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4064 26 linear_r127 linear_r128 linear_l125_3 linear_b127 linear_v125_2 mutated_s127 mutated_sl125_2)
theorem mutated_pl125_1 (tail : List Nat) : parseItems 4065 26 (linear_v125_1 ++ (93 :: tail)) = some (linear_l125_1, tail) := by
  simpa only [linear_l125_1, linear_v125_1, linear_l125_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4064 26 (linear_b127 ++ (44 :: (linear_v125_2 ++ (93 :: tail)))) (linear_v125_2 ++ (93 :: tail)) tail linear_r127 linear_l125_2 (mutated_p127 (44 :: (linear_v125_2 ++ (93 :: tail)))) (mutated_pl125_2 tail))
def linear_l125_0 : List Raw := linear_r126 :: linear_l125_1
def linear_v125_0 : List Nat := (linear_b126) ++ (44 :: linear_v125_1)
theorem mutated_sl125_0 : serializeItems 4066 26 linear_l125_0 = some linear_v125_0 := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4065 26 linear_r126 linear_r127 linear_l125_2 linear_b126 linear_v125_1 mutated_s126 mutated_sl125_1)
theorem mutated_pl125_0 (tail : List Nat) : parseItems 4066 26 (linear_v125_0 ++ (93 :: tail)) = some (linear_l125_0, tail) := by
  simpa only [linear_l125_0, linear_v125_0, linear_l125_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4065 26 (linear_b126 ++ (44 :: (linear_v125_1 ++ (93 :: tail)))) (linear_v125_1 ++ (93 :: tail)) tail linear_r126 linear_l125_1 (mutated_p126 (44 :: (linear_v125_1 ++ (93 :: tail)))) (mutated_pl125_1 tail))
def linear_r125 : Raw := (.arr linear_l125_0)
def linear_b125 : List Nat := linear_g318 ++ (linear_v125_0 ++ linear_g332)
theorem mutated_s125 : serializeRaw 4067 27 linear_r125 = some linear_b125 := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4066 26 linear_l125_0 linear_v125_0 mutated_sl125_0)
theorem mutated_p125 (tail : List Nat) : parseRaw 4067 27 (linear_b125 ++ tail) = some (linear_r125, tail) := by
  simpa only [linear_r125, linear_b125, linear_g318, linear_g332, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4066 26 (linear_v125_0 ++ (93 :: tail)) tail linear_l125_0 (by intro h; cases h) (mutated_pl125_0 tail))
def linear_r133 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,56])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51,57])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,49])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,50])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52,51])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b133 : List Nat := linear_g335
theorem mutated_s133 : serializeRaw 4066 27 linear_r133 = some linear_b133 := by decide +kernel
theorem mutated_p133 (tail : List Nat) : parseRaw 4066 27 (linear_b133 ++ tail) = some (linear_r133, tail) := by rfl
def linear_r134 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,51,56]),(.str [100,103,95,118,95,49,51,57]),(.str [100,103,95,118,95,49,52,48]),(.str [100,103,95,118,95,49,52,55]),(.str [100,103,95,118,95,49,52,50]),(.str [100,103,95,118,95,49,52,57])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,51]))])
def linear_b134 : List Nat := linear_g338
theorem mutated_s134 : serializeRaw 4065 27 linear_r134 = some linear_b134 := by decide +kernel
theorem mutated_p134 (tail : List Nat) : parseRaw 4065 27 (linear_b134 ++ tail) = some (linear_r134, tail) := by rfl
def linear_k123_0 : List Nat := [105,100]
theorem mutated_kd123_0 : stringBytes linear_k123_0 = true := by decide +kernel
theorem mutated_kp123_0 (tail : List Nat) : parseStringTail (linear_k123_0 ++ (34 :: 58 :: tail)) [] = some (linear_k123_0, 58 :: tail) := by rfl
def linear_k123_1 : List Nat := [111,112,115]
theorem mutated_kd123_1 : stringBytes linear_k123_1 = true := by decide +kernel
theorem mutated_kp123_1 (tail : List Nat) : parseStringTail (linear_k123_1 ++ (34 :: 58 :: tail)) [] = some (linear_k123_1, 58 :: tail) := by rfl
def linear_k123_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd123_2 : stringBytes linear_k123_2 = true := by decide +kernel
theorem mutated_kp123_2 (tail : List Nat) : parseStringTail (linear_k123_2 ++ (34 :: 58 :: tail)) [] = some (linear_k123_2, 58 :: tail) := by rfl
def linear_k123_3 : List Nat := [116,101,114,109]
theorem mutated_kd123_3 : stringBytes linear_k123_3 = true := by decide +kernel
theorem mutated_kp123_3 (tail : List Nat) : parseStringTail (linear_k123_3 ++ (34 :: 58 :: tail)) [] = some (linear_k123_3, 58 :: tail) := by rfl
def linear_l123_3 : List (List Nat × Raw) := [(linear_k123_3, linear_r134)]
def linear_v123_3 : List Nat := linear_g337 ++ linear_b134
theorem mutated_sl123_3 : serializeFields 4066 27 linear_l123_3 = some linear_v123_3 := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4065 27 linear_k123_3 linear_r134 linear_b134 mutated_kd123_3 mutated_s134)
theorem mutated_pl123_3 (tail : List Nat) : parseFields 4066 27 (linear_v123_3 ++ (125 :: tail)) = some (linear_l123_3, tail) := by
  simpa only [linear_l123_3, linear_v123_3, linear_k123_3, linear_g337, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4065 27 (linear_k123_3 ++ (34 :: 58 :: (linear_b134 ++ (125 :: tail)))) linear_k123_3 (linear_b134 ++ (125 :: tail)) tail linear_r134 (mutated_kp123_3 (linear_b134 ++ (125 :: tail))) (mutated_p134 (125 :: tail)))
def linear_l123_2 : List (List Nat × Raw) := (linear_k123_2, linear_r133) :: linear_l123_3
def linear_v123_2 : List Nat := (linear_g334 ++ linear_b133) ++ (44 :: linear_v123_3)
theorem mutated_sl123_2 : serializeFields 4067 27 linear_l123_2 = some linear_v123_2 := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k123_2 linear_r133 (linear_k123_3, linear_r134) [] linear_b133 linear_v123_3 mutated_kd123_2 mutated_s133 mutated_sl123_3)
theorem mutated_pl123_2 (tail : List Nat) : parseFields 4067 27 (linear_v123_2 ++ (125 :: tail)) = some (linear_l123_2, tail) := by
  simpa only [linear_l123_2, linear_v123_2, linear_k123_2, linear_g334, linear_l123_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k123_2 ++ (34 :: 58 :: (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))))) linear_k123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail)))) (linear_v123_3 ++ (125 :: tail)) tail linear_r133 linear_l123_3 (mutated_kp123_2 (linear_b133 ++ (44 :: (linear_v123_3 ++ (125 :: tail))))) (mutated_p133 (44 :: (linear_v123_3 ++ (125 :: tail)))) (mutated_pl123_3 tail))
def linear_l123_1 : List (List Nat × Raw) := (linear_k123_1, linear_r125) :: linear_l123_2
def linear_v123_1 : List Nat := (linear_g317 ++ linear_b125) ++ (44 :: linear_v123_2)
theorem mutated_sl123_1 : serializeFields 4068 27 linear_l123_1 = some linear_v123_1 := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k123_1 linear_r125 (linear_k123_2, linear_r133) linear_l123_3 linear_b125 linear_v123_2 mutated_kd123_1 mutated_s125 mutated_sl123_2)
theorem mutated_pl123_1 (tail : List Nat) : parseFields 4068 27 (linear_v123_1 ++ (125 :: tail)) = some (linear_l123_1, tail) := by
  simpa only [linear_l123_1, linear_v123_1, linear_k123_1, linear_g317, linear_l123_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k123_1 ++ (34 :: 58 :: (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))))) linear_k123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail)))) (linear_v123_2 ++ (125 :: tail)) tail linear_r125 linear_l123_2 (mutated_kp123_1 (linear_b125 ++ (44 :: (linear_v123_2 ++ (125 :: tail))))) (mutated_p125 (44 :: (linear_v123_2 ++ (125 :: tail)))) (mutated_pl123_2 tail))
def linear_l123_0 : List (List Nat × Raw) := (linear_k123_0, linear_r124) :: linear_l123_1
def linear_v123_0 : List Nat := (linear_g314 ++ linear_b124) ++ (44 :: linear_v123_1)
theorem mutated_sl123_0 : serializeFields 4069 27 linear_l123_0 = some linear_v123_0 := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4068 27 linear_k123_0 linear_r124 (linear_k123_1, linear_r125) linear_l123_2 linear_b124 linear_v123_1 mutated_kd123_0 mutated_s124 mutated_sl123_1)
theorem mutated_pl123_0 (tail : List Nat) : parseFields 4069 27 (linear_v123_0 ++ (125 :: tail)) = some (linear_l123_0, tail) := by
  simpa only [linear_l123_0, linear_v123_0, linear_k123_0, linear_g314, linear_l123_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4068 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) linear_k123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))) (linear_v123_1 ++ (125 :: tail)) tail linear_r124 linear_l123_1 (mutated_kp123_0 (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail))))) (mutated_p124 (44 :: (linear_v123_1 ++ (125 :: tail)))) (mutated_pl123_1 tail))
def linear_r123 : Raw := (.obj linear_l123_0)
def linear_b123 : List Nat := linear_g313 ++ (linear_v123_0 ++ linear_g339)
theorem mutated_o123 : orderedFields linear_l123_0 = true := by decide +kernel
theorem mutated_s123 : serializeRaw 4070 28 linear_r123 = some linear_b123 := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4069 27 linear_l123_0 linear_v123_0 mutated_o123 mutated_sl123_0)
theorem mutated_p123 (tail : List Nat) : parseRaw 4070 28 (linear_b123 ++ tail) = some (linear_r123, tail) := by
  simpa only [linear_r123, linear_b123, linear_g313, linear_g339, linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4069 27 (linear_k123_0 ++ (34 :: 58 :: (linear_b124 ++ (44 :: (linear_v123_1 ++ (125 :: tail)))))) tail linear_l123_0 mutated_o123 (by simpa only [linear_v123_0, linear_k123_0, linear_g314, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl123_0 tail)))
def linear_r136 : Raw := (.str [100,103,95,115,108,111,119,95,53])
def linear_b136 : List Nat := linear_g343
theorem mutated_s136 : serializeRaw 4067 27 linear_r136 = some linear_b136 := by decide +kernel
theorem mutated_p136 (tail : List Nat) : parseRaw 4067 27 (linear_b136 ++ tail) = some (linear_r136, tail) := by rfl
def linear_r137 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])])
def linear_b137 : List Nat := linear_g346
theorem mutated_s137 : serializeRaw 4066 27 linear_r137 = some linear_b137 := by decide +kernel
theorem mutated_p137 (tail : List Nat) : parseRaw 4066 27 (linear_b137 ++ tail) = some (linear_r137, tail) := by rfl
def linear_r138 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,51])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,53])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b138 : List Nat := linear_g349
theorem mutated_s138 : serializeRaw 4065 27 linear_r138 = some linear_b138 := by decide +kernel
theorem mutated_p138 (tail : List Nat) : parseRaw 4065 27 (linear_b138 ++ tail) = some (linear_r138, tail) := by rfl
def linear_r139 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,53,51])]))])
def linear_b139 : List Nat := linear_g352
theorem mutated_s139 : serializeRaw 4064 27 linear_r139 = some linear_b139 := by decide +kernel
theorem mutated_p139 (tail : List Nat) : parseRaw 4064 27 (linear_b139 ++ tail) = some (linear_r139, tail) := by rfl
def linear_k135_0 : List Nat := [105,100]
theorem mutated_kd135_0 : stringBytes linear_k135_0 = true := by decide +kernel
theorem mutated_kp135_0 (tail : List Nat) : parseStringTail (linear_k135_0 ++ (34 :: 58 :: tail)) [] = some (linear_k135_0, 58 :: tail) := by rfl
def linear_k135_1 : List Nat := [111,112,115]
theorem mutated_kd135_1 : stringBytes linear_k135_1 = true := by decide +kernel
theorem mutated_kp135_1 (tail : List Nat) : parseStringTail (linear_k135_1 ++ (34 :: 58 :: tail)) [] = some (linear_k135_1, 58 :: tail) := by rfl
def linear_k135_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd135_2 : stringBytes linear_k135_2 = true := by decide +kernel
theorem mutated_kp135_2 (tail : List Nat) : parseStringTail (linear_k135_2 ++ (34 :: 58 :: tail)) [] = some (linear_k135_2, 58 :: tail) := by rfl
def linear_k135_3 : List Nat := [116,101,114,109]
theorem mutated_kd135_3 : stringBytes linear_k135_3 = true := by decide +kernel
theorem mutated_kp135_3 (tail : List Nat) : parseStringTail (linear_k135_3 ++ (34 :: 58 :: tail)) [] = some (linear_k135_3, 58 :: tail) := by rfl
def linear_l135_3 : List (List Nat × Raw) := [(linear_k135_3, linear_r139)]
def linear_v135_3 : List Nat := linear_g351 ++ linear_b139
theorem mutated_sl135_3 : serializeFields 4065 27 linear_l135_3 = some linear_v135_3 := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4064 27 linear_k135_3 linear_r139 linear_b139 mutated_kd135_3 mutated_s139)
theorem mutated_pl135_3 (tail : List Nat) : parseFields 4065 27 (linear_v135_3 ++ (125 :: tail)) = some (linear_l135_3, tail) := by
  simpa only [linear_l135_3, linear_v135_3, linear_k135_3, linear_g351, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4064 27 (linear_k135_3 ++ (34 :: 58 :: (linear_b139 ++ (125 :: tail)))) linear_k135_3 (linear_b139 ++ (125 :: tail)) tail linear_r139 (mutated_kp135_3 (linear_b139 ++ (125 :: tail))) (mutated_p139 (125 :: tail)))
def linear_l135_2 : List (List Nat × Raw) := (linear_k135_2, linear_r138) :: linear_l135_3
def linear_v135_2 : List Nat := (linear_g348 ++ linear_b138) ++ (44 :: linear_v135_3)
theorem mutated_sl135_2 : serializeFields 4066 27 linear_l135_2 = some linear_v135_2 := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k135_2 linear_r138 (linear_k135_3, linear_r139) [] linear_b138 linear_v135_3 mutated_kd135_2 mutated_s138 mutated_sl135_3)
theorem mutated_pl135_2 (tail : List Nat) : parseFields 4066 27 (linear_v135_2 ++ (125 :: tail)) = some (linear_l135_2, tail) := by
  simpa only [linear_l135_2, linear_v135_2, linear_k135_2, linear_g348, linear_l135_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k135_2 ++ (34 :: 58 :: (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))))) linear_k135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail)))) (linear_v135_3 ++ (125 :: tail)) tail linear_r138 linear_l135_3 (mutated_kp135_2 (linear_b138 ++ (44 :: (linear_v135_3 ++ (125 :: tail))))) (mutated_p138 (44 :: (linear_v135_3 ++ (125 :: tail)))) (mutated_pl135_3 tail))
def linear_l135_1 : List (List Nat × Raw) := (linear_k135_1, linear_r137) :: linear_l135_2
def linear_v135_1 : List Nat := (linear_g345 ++ linear_b137) ++ (44 :: linear_v135_2)
theorem mutated_sl135_1 : serializeFields 4067 27 linear_l135_1 = some linear_v135_1 := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k135_1 linear_r137 (linear_k135_2, linear_r138) linear_l135_3 linear_b137 linear_v135_2 mutated_kd135_1 mutated_s137 mutated_sl135_2)
theorem mutated_pl135_1 (tail : List Nat) : parseFields 4067 27 (linear_v135_1 ++ (125 :: tail)) = some (linear_l135_1, tail) := by
  simpa only [linear_l135_1, linear_v135_1, linear_k135_1, linear_g345, linear_l135_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k135_1 ++ (34 :: 58 :: (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))))) linear_k135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail)))) (linear_v135_2 ++ (125 :: tail)) tail linear_r137 linear_l135_2 (mutated_kp135_1 (linear_b137 ++ (44 :: (linear_v135_2 ++ (125 :: tail))))) (mutated_p137 (44 :: (linear_v135_2 ++ (125 :: tail)))) (mutated_pl135_2 tail))
def linear_l135_0 : List (List Nat × Raw) := (linear_k135_0, linear_r136) :: linear_l135_1
def linear_v135_0 : List Nat := (linear_g342 ++ linear_b136) ++ (44 :: linear_v135_1)
theorem mutated_sl135_0 : serializeFields 4068 27 linear_l135_0 = some linear_v135_0 := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4067 27 linear_k135_0 linear_r136 (linear_k135_1, linear_r137) linear_l135_2 linear_b136 linear_v135_1 mutated_kd135_0 mutated_s136 mutated_sl135_1)
theorem mutated_pl135_0 (tail : List Nat) : parseFields 4068 27 (linear_v135_0 ++ (125 :: tail)) = some (linear_l135_0, tail) := by
  simpa only [linear_l135_0, linear_v135_0, linear_k135_0, linear_g342, linear_l135_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4067 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) linear_k135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))) (linear_v135_1 ++ (125 :: tail)) tail linear_r136 linear_l135_1 (mutated_kp135_0 (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail))))) (mutated_p136 (44 :: (linear_v135_1 ++ (125 :: tail)))) (mutated_pl135_1 tail))
def linear_r135 : Raw := (.obj linear_l135_0)
def linear_b135 : List Nat := linear_g341 ++ (linear_v135_0 ++ linear_g353)
theorem mutated_o135 : orderedFields linear_l135_0 = true := by decide +kernel
theorem mutated_s135 : serializeRaw 4069 28 linear_r135 = some linear_b135 := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4068 27 linear_l135_0 linear_v135_0 mutated_o135 mutated_sl135_0)
theorem mutated_p135 (tail : List Nat) : parseRaw 4069 28 (linear_b135 ++ tail) = some (linear_r135, tail) := by
  simpa only [linear_r135, linear_b135, linear_g341, linear_g353, linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4068 27 (linear_k135_0 ++ (34 :: 58 :: (linear_b136 ++ (44 :: (linear_v135_1 ++ (125 :: tail)))))) tail linear_l135_0 mutated_o135 (by simpa only [linear_v135_0, linear_k135_0, linear_g342, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl135_0 tail)))
def linear_r141 : Raw := (.str [100,103,95,103,117,97,114,100,95,48])
def linear_b141 : List Nat := linear_g357
theorem mutated_s141 : serializeRaw 4066 27 linear_r141 = some linear_b141 := by decide +kernel
theorem mutated_p141 (tail : List Nat) : parseRaw 4066 27 (linear_b141 ++ tail) = some (linear_r141, tail) := by rfl
def linear_r142 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,50]),(.str [100,103,95,118,95,49,54,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,52])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b142 : List Nat := linear_g360
theorem mutated_s142 : serializeRaw 4065 27 linear_r142 = some linear_b142 := by decide +kernel
theorem mutated_p142 (tail : List Nat) : parseRaw 4065 27 (linear_b142 ++ tail) = some (linear_r142, tail) := by rfl
def linear_r143 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,50])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b143 : List Nat := linear_g363
theorem mutated_s143 : serializeRaw 4064 27 linear_r143 = some linear_b143 := by decide +kernel
theorem mutated_p143 (tail : List Nat) : parseRaw 4064 27 (linear_b143 ++ tail) = some (linear_r143, tail) := by rfl
def linear_r144 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,54,52])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,49]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53,55]),(.str [100,103,95,118,95,49,53,56]),(.str [100,103,95,118,95,49,53,57]),(.str [100,103,95,118,95,49,54,48]),(.str [100,103,95,118,95,49,54,49])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,49]))]))])
def linear_b144 : List Nat := linear_g366
theorem mutated_s144 : serializeRaw 4063 27 linear_r144 = some linear_b144 := by decide +kernel
theorem mutated_p144 (tail : List Nat) : parseRaw 4063 27 (linear_b144 ++ tail) = some (linear_r144, tail) := by rfl
def linear_k140_0 : List Nat := [105,100]
theorem mutated_kd140_0 : stringBytes linear_k140_0 = true := by decide +kernel
theorem mutated_kp140_0 (tail : List Nat) : parseStringTail (linear_k140_0 ++ (34 :: 58 :: tail)) [] = some (linear_k140_0, 58 :: tail) := by rfl
def linear_k140_1 : List Nat := [111,112,115]
theorem mutated_kd140_1 : stringBytes linear_k140_1 = true := by decide +kernel
theorem mutated_kp140_1 (tail : List Nat) : parseStringTail (linear_k140_1 ++ (34 :: 58 :: tail)) [] = some (linear_k140_1, 58 :: tail) := by rfl
def linear_k140_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd140_2 : stringBytes linear_k140_2 = true := by decide +kernel
theorem mutated_kp140_2 (tail : List Nat) : parseStringTail (linear_k140_2 ++ (34 :: 58 :: tail)) [] = some (linear_k140_2, 58 :: tail) := by rfl
def linear_k140_3 : List Nat := [116,101,114,109]
theorem mutated_kd140_3 : stringBytes linear_k140_3 = true := by decide +kernel
theorem mutated_kp140_3 (tail : List Nat) : parseStringTail (linear_k140_3 ++ (34 :: 58 :: tail)) [] = some (linear_k140_3, 58 :: tail) := by rfl
def linear_l140_3 : List (List Nat × Raw) := [(linear_k140_3, linear_r144)]
def linear_v140_3 : List Nat := linear_g365 ++ linear_b144
theorem mutated_sl140_3 : serializeFields 4064 27 linear_l140_3 = some linear_v140_3 := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4063 27 linear_k140_3 linear_r144 linear_b144 mutated_kd140_3 mutated_s144)
theorem mutated_pl140_3 (tail : List Nat) : parseFields 4064 27 (linear_v140_3 ++ (125 :: tail)) = some (linear_l140_3, tail) := by
  simpa only [linear_l140_3, linear_v140_3, linear_k140_3, linear_g365, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4063 27 (linear_k140_3 ++ (34 :: 58 :: (linear_b144 ++ (125 :: tail)))) linear_k140_3 (linear_b144 ++ (125 :: tail)) tail linear_r144 (mutated_kp140_3 (linear_b144 ++ (125 :: tail))) (mutated_p144 (125 :: tail)))
def linear_l140_2 : List (List Nat × Raw) := (linear_k140_2, linear_r143) :: linear_l140_3
def linear_v140_2 : List Nat := (linear_g362 ++ linear_b143) ++ (44 :: linear_v140_3)
theorem mutated_sl140_2 : serializeFields 4065 27 linear_l140_2 = some linear_v140_2 := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k140_2 linear_r143 (linear_k140_3, linear_r144) [] linear_b143 linear_v140_3 mutated_kd140_2 mutated_s143 mutated_sl140_3)
theorem mutated_pl140_2 (tail : List Nat) : parseFields 4065 27 (linear_v140_2 ++ (125 :: tail)) = some (linear_l140_2, tail) := by
  simpa only [linear_l140_2, linear_v140_2, linear_k140_2, linear_g362, linear_l140_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k140_2 ++ (34 :: 58 :: (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))))) linear_k140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail)))) (linear_v140_3 ++ (125 :: tail)) tail linear_r143 linear_l140_3 (mutated_kp140_2 (linear_b143 ++ (44 :: (linear_v140_3 ++ (125 :: tail))))) (mutated_p143 (44 :: (linear_v140_3 ++ (125 :: tail)))) (mutated_pl140_3 tail))
def linear_l140_1 : List (List Nat × Raw) := (linear_k140_1, linear_r142) :: linear_l140_2
def linear_v140_1 : List Nat := (linear_g359 ++ linear_b142) ++ (44 :: linear_v140_2)
theorem mutated_sl140_1 : serializeFields 4066 27 linear_l140_1 = some linear_v140_1 := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k140_1 linear_r142 (linear_k140_2, linear_r143) linear_l140_3 linear_b142 linear_v140_2 mutated_kd140_1 mutated_s142 mutated_sl140_2)
theorem mutated_pl140_1 (tail : List Nat) : parseFields 4066 27 (linear_v140_1 ++ (125 :: tail)) = some (linear_l140_1, tail) := by
  simpa only [linear_l140_1, linear_v140_1, linear_k140_1, linear_g359, linear_l140_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k140_1 ++ (34 :: 58 :: (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))))) linear_k140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail)))) (linear_v140_2 ++ (125 :: tail)) tail linear_r142 linear_l140_2 (mutated_kp140_1 (linear_b142 ++ (44 :: (linear_v140_2 ++ (125 :: tail))))) (mutated_p142 (44 :: (linear_v140_2 ++ (125 :: tail)))) (mutated_pl140_2 tail))
def linear_l140_0 : List (List Nat × Raw) := (linear_k140_0, linear_r141) :: linear_l140_1
def linear_v140_0 : List Nat := (linear_g356 ++ linear_b141) ++ (44 :: linear_v140_1)
theorem mutated_sl140_0 : serializeFields 4067 27 linear_l140_0 = some linear_v140_0 := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4066 27 linear_k140_0 linear_r141 (linear_k140_1, linear_r142) linear_l140_2 linear_b141 linear_v140_1 mutated_kd140_0 mutated_s141 mutated_sl140_1)
theorem mutated_pl140_0 (tail : List Nat) : parseFields 4067 27 (linear_v140_0 ++ (125 :: tail)) = some (linear_l140_0, tail) := by
  simpa only [linear_l140_0, linear_v140_0, linear_k140_0, linear_g356, linear_l140_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4066 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) linear_k140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))) (linear_v140_1 ++ (125 :: tail)) tail linear_r141 linear_l140_1 (mutated_kp140_0 (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail))))) (mutated_p141 (44 :: (linear_v140_1 ++ (125 :: tail)))) (mutated_pl140_1 tail))
def linear_r140 : Raw := (.obj linear_l140_0)
def linear_b140 : List Nat := linear_g355 ++ (linear_v140_0 ++ linear_g367)
theorem mutated_o140 : orderedFields linear_l140_0 = true := by decide +kernel
theorem mutated_s140 : serializeRaw 4068 28 linear_r140 = some linear_b140 := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4067 27 linear_l140_0 linear_v140_0 mutated_o140 mutated_sl140_0)
theorem mutated_p140 (tail : List Nat) : parseRaw 4068 28 (linear_b140 ++ tail) = some (linear_r140, tail) := by
  simpa only [linear_r140, linear_b140, linear_g355, linear_g367, linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4067 27 (linear_k140_0 ++ (34 :: 58 :: (linear_b141 ++ (44 :: (linear_v140_1 ++ (125 :: tail)))))) tail linear_l140_0 mutated_o140 (by simpa only [linear_v140_0, linear_k140_0, linear_g356, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl140_0 tail)))
def linear_r146 : Raw := (.str [100,103,95,103,117,97,114,100,95,49])
def linear_b146 : List Nat := linear_g371
theorem mutated_s146 : serializeRaw 4065 27 linear_r146 = some linear_b146 := by decide +kernel
theorem mutated_p146 (tail : List Nat) : parseRaw 4065 27 (linear_b146 ++ tail) = some (linear_r146, tail) := by rfl
def linear_r147 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 72340172838076673))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,50])),([116,121,112,101],(.str [117,115,105,122,101]))])]))]),(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,55,49]),(.str [100,103,95,118,95,49,55,50])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,51])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b147 : List Nat := linear_g374
theorem mutated_s147 : serializeRaw 4064 27 linear_r147 = some linear_b147 := by decide +kernel
theorem mutated_p147 (tail : List Nat) : parseRaw 4064 27 (linear_b147 ++ tail) = some (linear_r147, tail) := by rfl
def linear_r148 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,53])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,54])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,55])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,56])),([116,121,112,101],(.str [117,54,52]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54,57])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55,49])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b148 : List Nat := linear_g377
theorem mutated_s148 : serializeRaw 4063 27 linear_r148 = some linear_b148 := by decide +kernel
theorem mutated_p148 (tail : List Nat) : parseRaw 4063 27 (linear_b148 ++ tail) = some (linear_r148, tail) := by rfl
def linear_r149 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49,55,51])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,115,108,111,119,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54,53]),(.str [100,103,95,118,95,49,54,54]),(.str [100,103,95,118,95,49,54,55]),(.str [100,103,95,118,95,49,54,56]),(.str [100,103,95,118,95,49,54,57]),(.str [100,103,95,118,95,49,55,48])])),([116,97,114,103,101,116],(.str [100,103,95,102,97,115,116,95,52]))]))])
def linear_b149 : List Nat := linear_g380
theorem mutated_s149 : serializeRaw 4062 27 linear_r149 = some linear_b149 := by decide +kernel
theorem mutated_p149 (tail : List Nat) : parseRaw 4062 27 (linear_b149 ++ tail) = some (linear_r149, tail) := by rfl
def linear_k145_0 : List Nat := [105,100]
theorem mutated_kd145_0 : stringBytes linear_k145_0 = true := by decide +kernel
theorem mutated_kp145_0 (tail : List Nat) : parseStringTail (linear_k145_0 ++ (34 :: 58 :: tail)) [] = some (linear_k145_0, 58 :: tail) := by rfl
def linear_k145_1 : List Nat := [111,112,115]
theorem mutated_kd145_1 : stringBytes linear_k145_1 = true := by decide +kernel
theorem mutated_kp145_1 (tail : List Nat) : parseStringTail (linear_k145_1 ++ (34 :: 58 :: tail)) [] = some (linear_k145_1, 58 :: tail) := by rfl
def linear_k145_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd145_2 : stringBytes linear_k145_2 = true := by decide +kernel
theorem mutated_kp145_2 (tail : List Nat) : parseStringTail (linear_k145_2 ++ (34 :: 58 :: tail)) [] = some (linear_k145_2, 58 :: tail) := by rfl
def linear_k145_3 : List Nat := [116,101,114,109]
theorem mutated_kd145_3 : stringBytes linear_k145_3 = true := by decide +kernel
theorem mutated_kp145_3 (tail : List Nat) : parseStringTail (linear_k145_3 ++ (34 :: 58 :: tail)) [] = some (linear_k145_3, 58 :: tail) := by rfl
def linear_l145_3 : List (List Nat × Raw) := [(linear_k145_3, linear_r149)]
def linear_v145_3 : List Nat := linear_g379 ++ linear_b149
theorem mutated_sl145_3 : serializeFields 4063 27 linear_l145_3 = some linear_v145_3 := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4062 27 linear_k145_3 linear_r149 linear_b149 mutated_kd145_3 mutated_s149)
theorem mutated_pl145_3 (tail : List Nat) : parseFields 4063 27 (linear_v145_3 ++ (125 :: tail)) = some (linear_l145_3, tail) := by
  simpa only [linear_l145_3, linear_v145_3, linear_k145_3, linear_g379, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4062 27 (linear_k145_3 ++ (34 :: 58 :: (linear_b149 ++ (125 :: tail)))) linear_k145_3 (linear_b149 ++ (125 :: tail)) tail linear_r149 (mutated_kp145_3 (linear_b149 ++ (125 :: tail))) (mutated_p149 (125 :: tail)))
def linear_l145_2 : List (List Nat × Raw) := (linear_k145_2, linear_r148) :: linear_l145_3
def linear_v145_2 : List Nat := (linear_g376 ++ linear_b148) ++ (44 :: linear_v145_3)
theorem mutated_sl145_2 : serializeFields 4064 27 linear_l145_2 = some linear_v145_2 := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4063 27 linear_k145_2 linear_r148 (linear_k145_3, linear_r149) [] linear_b148 linear_v145_3 mutated_kd145_2 mutated_s148 mutated_sl145_3)
theorem mutated_pl145_2 (tail : List Nat) : parseFields 4064 27 (linear_v145_2 ++ (125 :: tail)) = some (linear_l145_2, tail) := by
  simpa only [linear_l145_2, linear_v145_2, linear_k145_2, linear_g376, linear_l145_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4063 27 (linear_k145_2 ++ (34 :: 58 :: (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))))) linear_k145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail)))) (linear_v145_3 ++ (125 :: tail)) tail linear_r148 linear_l145_3 (mutated_kp145_2 (linear_b148 ++ (44 :: (linear_v145_3 ++ (125 :: tail))))) (mutated_p148 (44 :: (linear_v145_3 ++ (125 :: tail)))) (mutated_pl145_3 tail))
def linear_l145_1 : List (List Nat × Raw) := (linear_k145_1, linear_r147) :: linear_l145_2
def linear_v145_1 : List Nat := (linear_g373 ++ linear_b147) ++ (44 :: linear_v145_2)
theorem mutated_sl145_1 : serializeFields 4065 27 linear_l145_1 = some linear_v145_1 := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4064 27 linear_k145_1 linear_r147 (linear_k145_2, linear_r148) linear_l145_3 linear_b147 linear_v145_2 mutated_kd145_1 mutated_s147 mutated_sl145_2)
theorem mutated_pl145_1 (tail : List Nat) : parseFields 4065 27 (linear_v145_1 ++ (125 :: tail)) = some (linear_l145_1, tail) := by
  simpa only [linear_l145_1, linear_v145_1, linear_k145_1, linear_g373, linear_l145_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4064 27 (linear_k145_1 ++ (34 :: 58 :: (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))))) linear_k145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail)))) (linear_v145_2 ++ (125 :: tail)) tail linear_r147 linear_l145_2 (mutated_kp145_1 (linear_b147 ++ (44 :: (linear_v145_2 ++ (125 :: tail))))) (mutated_p147 (44 :: (linear_v145_2 ++ (125 :: tail)))) (mutated_pl145_2 tail))
def linear_l145_0 : List (List Nat × Raw) := (linear_k145_0, linear_r146) :: linear_l145_1
def linear_v145_0 : List Nat := (linear_g370 ++ linear_b146) ++ (44 :: linear_v145_1)
theorem mutated_sl145_0 : serializeFields 4066 27 linear_l145_0 = some linear_v145_0 := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4065 27 linear_k145_0 linear_r146 (linear_k145_1, linear_r147) linear_l145_2 linear_b146 linear_v145_1 mutated_kd145_0 mutated_s146 mutated_sl145_1)
theorem mutated_pl145_0 (tail : List Nat) : parseFields 4066 27 (linear_v145_0 ++ (125 :: tail)) = some (linear_l145_0, tail) := by
  simpa only [linear_l145_0, linear_v145_0, linear_k145_0, linear_g370, linear_l145_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4065 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) linear_k145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))) (linear_v145_1 ++ (125 :: tail)) tail linear_r146 linear_l145_1 (mutated_kp145_0 (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail))))) (mutated_p146 (44 :: (linear_v145_1 ++ (125 :: tail)))) (mutated_pl145_1 tail))
def linear_r145 : Raw := (.obj linear_l145_0)
def linear_b145 : List Nat := linear_g369 ++ (linear_v145_0 ++ linear_g381)
theorem mutated_o145 : orderedFields linear_l145_0 = true := by decide +kernel
theorem mutated_s145 : serializeRaw 4067 28 linear_r145 = some linear_b145 := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4066 27 linear_l145_0 linear_v145_0 mutated_o145 mutated_sl145_0)
theorem mutated_p145 (tail : List Nat) : parseRaw 4067 28 (linear_b145 ++ tail) = some (linear_r145, tail) := by
  simpa only [linear_r145, linear_b145, linear_g369, linear_g381, linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4066 27 (linear_k145_0 ++ (34 :: 58 :: (linear_b146 ++ (44 :: (linear_v145_1 ++ (125 :: tail)))))) tail linear_l145_0 mutated_o145 (by simpa only [linear_v145_0, linear_k145_0, linear_g370, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl145_0 tail)))
def linear_l4_20 : List Raw := [linear_r145]
def linear_v4_20 : List Nat := linear_b145
theorem mutated_sl4_20 : serializeItems 4068 28 linear_l4_20 = some linear_v4_20 := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4067 28 linear_r145 linear_b145 mutated_s145)
theorem mutated_pl4_20 (tail : List Nat) : parseItems 4068 28 (linear_v4_20 ++ (93 :: tail)) = some (linear_l4_20, tail) := by
  simpa only [linear_l4_20, linear_v4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4067 28 (linear_b145 ++ (93 :: tail)) tail linear_r145 (mutated_p145 (93 :: tail)))
def linear_l4_19 : List Raw := linear_r140 :: linear_l4_20
def linear_v4_19 : List Nat := (linear_b140) ++ (44 :: linear_v4_20)
theorem mutated_sl4_19 : serializeItems 4069 28 linear_l4_19 = some linear_v4_19 := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4068 28 linear_r140 linear_r145 [] linear_b140 linear_v4_20 mutated_s140 mutated_sl4_20)
theorem mutated_pl4_19 (tail : List Nat) : parseItems 4069 28 (linear_v4_19 ++ (93 :: tail)) = some (linear_l4_19, tail) := by
  simpa only [linear_l4_19, linear_v4_19, linear_l4_20, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4068 28 (linear_b140 ++ (44 :: (linear_v4_20 ++ (93 :: tail)))) (linear_v4_20 ++ (93 :: tail)) tail linear_r140 linear_l4_20 (mutated_p140 (44 :: (linear_v4_20 ++ (93 :: tail)))) (mutated_pl4_20 tail))
def linear_l4_18 : List Raw := linear_r135 :: linear_l4_19
def linear_v4_18 : List Nat := (linear_b135) ++ (44 :: linear_v4_19)
theorem mutated_sl4_18 : serializeItems 4070 28 linear_l4_18 = some linear_v4_18 := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4069 28 linear_r135 linear_r140 linear_l4_20 linear_b135 linear_v4_19 mutated_s135 mutated_sl4_19)
theorem mutated_pl4_18 (tail : List Nat) : parseItems 4070 28 (linear_v4_18 ++ (93 :: tail)) = some (linear_l4_18, tail) := by
  simpa only [linear_l4_18, linear_v4_18, linear_l4_19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4069 28 (linear_b135 ++ (44 :: (linear_v4_19 ++ (93 :: tail)))) (linear_v4_19 ++ (93 :: tail)) tail linear_r135 linear_l4_19 (mutated_p135 (44 :: (linear_v4_19 ++ (93 :: tail)))) (mutated_pl4_19 tail))
def linear_l4_17 : List Raw := linear_r123 :: linear_l4_18
def linear_v4_17 : List Nat := (linear_b123) ++ (44 :: linear_v4_18)
theorem mutated_sl4_17 : serializeItems 4071 28 linear_l4_17 = some linear_v4_17 := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4070 28 linear_r123 linear_r135 linear_l4_19 linear_b123 linear_v4_18 mutated_s123 mutated_sl4_18)
theorem mutated_pl4_17 (tail : List Nat) : parseItems 4071 28 (linear_v4_17 ++ (93 :: tail)) = some (linear_l4_17, tail) := by
  simpa only [linear_l4_17, linear_v4_17, linear_l4_18, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4070 28 (linear_b123 ++ (44 :: (linear_v4_18 ++ (93 :: tail)))) (linear_v4_18 ++ (93 :: tail)) tail linear_r123 linear_l4_18 (mutated_p123 (44 :: (linear_v4_18 ++ (93 :: tail)))) (mutated_pl4_18 tail))
def linear_l4_16 : List Raw := linear_r118 :: linear_l4_17
def linear_v4_16 : List Nat := (linear_b118) ++ (44 :: linear_v4_17)
theorem mutated_sl4_16 : serializeItems 4072 28 linear_l4_16 = some linear_v4_16 := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4071 28 linear_r118 linear_r123 linear_l4_18 linear_b118 linear_v4_17 mutated_s118 mutated_sl4_17)
theorem mutated_pl4_16 (tail : List Nat) : parseItems 4072 28 (linear_v4_16 ++ (93 :: tail)) = some (linear_l4_16, tail) := by
  simpa only [linear_l4_16, linear_v4_16, linear_l4_17, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4071 28 (linear_b118 ++ (44 :: (linear_v4_17 ++ (93 :: tail)))) (linear_v4_17 ++ (93 :: tail)) tail linear_r118 linear_l4_17 (mutated_p118 (44 :: (linear_v4_17 ++ (93 :: tail)))) (mutated_pl4_17 tail))
def linear_l4_15 : List Raw := linear_r113 :: linear_l4_16
def linear_v4_15 : List Nat := (linear_b113) ++ (44 :: linear_v4_16)
theorem mutated_sl4_15 : serializeItems 4073 28 linear_l4_15 = some linear_v4_15 := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4072 28 linear_r113 linear_r118 linear_l4_17 linear_b113 linear_v4_16 mutated_s113 mutated_sl4_16)
theorem mutated_pl4_15 (tail : List Nat) : parseItems 4073 28 (linear_v4_15 ++ (93 :: tail)) = some (linear_l4_15, tail) := by
  simpa only [linear_l4_15, linear_v4_15, linear_l4_16, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4072 28 (linear_b113 ++ (44 :: (linear_v4_16 ++ (93 :: tail)))) (linear_v4_16 ++ (93 :: tail)) tail linear_r113 linear_l4_16 (mutated_p113 (44 :: (linear_v4_16 ++ (93 :: tail)))) (mutated_pl4_16 tail))
def linear_l4_14 : List Raw := linear_r97 :: linear_l4_15
def linear_v4_14 : List Nat := (linear_b97) ++ (44 :: linear_v4_15)
theorem mutated_sl4_14 : serializeItems 4074 28 linear_l4_14 = some linear_v4_14 := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4073 28 linear_r97 linear_r113 linear_l4_16 linear_b97 linear_v4_15 mutated_s97 mutated_sl4_15)
theorem mutated_pl4_14 (tail : List Nat) : parseItems 4074 28 (linear_v4_14 ++ (93 :: tail)) = some (linear_l4_14, tail) := by
  simpa only [linear_l4_14, linear_v4_14, linear_l4_15, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4073 28 (linear_b97 ++ (44 :: (linear_v4_15 ++ (93 :: tail)))) (linear_v4_15 ++ (93 :: tail)) tail linear_r97 linear_l4_15 (mutated_p97 (44 :: (linear_v4_15 ++ (93 :: tail)))) (mutated_pl4_15 tail))
def linear_l4_13 : List Raw := linear_r92 :: linear_l4_14
def linear_v4_13 : List Nat := (linear_b92) ++ (44 :: linear_v4_14)
theorem mutated_sl4_13 : serializeItems 4075 28 linear_l4_13 = some linear_v4_13 := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4074 28 linear_r92 linear_r97 linear_l4_15 linear_b92 linear_v4_14 mutated_s92 mutated_sl4_14)
theorem mutated_pl4_13 (tail : List Nat) : parseItems 4075 28 (linear_v4_13 ++ (93 :: tail)) = some (linear_l4_13, tail) := by
  simpa only [linear_l4_13, linear_v4_13, linear_l4_14, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4074 28 (linear_b92 ++ (44 :: (linear_v4_14 ++ (93 :: tail)))) (linear_v4_14 ++ (93 :: tail)) tail linear_r92 linear_l4_14 (mutated_p92 (44 :: (linear_v4_14 ++ (93 :: tail)))) (mutated_pl4_14 tail))
def linear_l4_12 : List Raw := linear_r87 :: linear_l4_13
def linear_v4_12 : List Nat := (linear_b87) ++ (44 :: linear_v4_13)
theorem mutated_sl4_12 : serializeItems 4076 28 linear_l4_12 = some linear_v4_12 := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4075 28 linear_r87 linear_r92 linear_l4_14 linear_b87 linear_v4_13 mutated_s87 mutated_sl4_13)
theorem mutated_pl4_12 (tail : List Nat) : parseItems 4076 28 (linear_v4_12 ++ (93 :: tail)) = some (linear_l4_12, tail) := by
  simpa only [linear_l4_12, linear_v4_12, linear_l4_13, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4075 28 (linear_b87 ++ (44 :: (linear_v4_13 ++ (93 :: tail)))) (linear_v4_13 ++ (93 :: tail)) tail linear_r87 linear_l4_13 (mutated_p87 (44 :: (linear_v4_13 ++ (93 :: tail)))) (mutated_pl4_13 tail))
def linear_l4_11 : List Raw := linear_r75 :: linear_l4_12
def linear_v4_11 : List Nat := (linear_b75) ++ (44 :: linear_v4_12)
theorem mutated_sl4_11 : serializeItems 4077 28 linear_l4_11 = some linear_v4_11 := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4076 28 linear_r75 linear_r87 linear_l4_13 linear_b75 linear_v4_12 mutated_s75 mutated_sl4_12)
theorem mutated_pl4_11 (tail : List Nat) : parseItems 4077 28 (linear_v4_11 ++ (93 :: tail)) = some (linear_l4_11, tail) := by
  simpa only [linear_l4_11, linear_v4_11, linear_l4_12, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4076 28 (linear_b75 ++ (44 :: (linear_v4_12 ++ (93 :: tail)))) (linear_v4_12 ++ (93 :: tail)) tail linear_r75 linear_l4_12 (mutated_p75 (44 :: (linear_v4_12 ++ (93 :: tail)))) (mutated_pl4_12 tail))
def linear_l4_10 : List Raw := linear_r70 :: linear_l4_11
def linear_v4_10 : List Nat := (linear_b70) ++ (44 :: linear_v4_11)
theorem mutated_sl4_10 : serializeItems 4078 28 linear_l4_10 = some linear_v4_10 := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4077 28 linear_r70 linear_r75 linear_l4_12 linear_b70 linear_v4_11 mutated_s70 mutated_sl4_11)
theorem mutated_pl4_10 (tail : List Nat) : parseItems 4078 28 (linear_v4_10 ++ (93 :: tail)) = some (linear_l4_10, tail) := by
  simpa only [linear_l4_10, linear_v4_10, linear_l4_11, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4077 28 (linear_b70 ++ (44 :: (linear_v4_11 ++ (93 :: tail)))) (linear_v4_11 ++ (93 :: tail)) tail linear_r70 linear_l4_11 (mutated_p70 (44 :: (linear_v4_11 ++ (93 :: tail)))) (mutated_pl4_11 tail))
def linear_l4_9 : List Raw := linear_r65 :: linear_l4_10
def linear_v4_9 : List Nat := (linear_b65) ++ (44 :: linear_v4_10)
theorem mutated_sl4_9 : serializeItems 4079 28 linear_l4_9 = some linear_v4_9 := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 28 linear_r65 linear_r70 linear_l4_11 linear_b65 linear_v4_10 mutated_s65 mutated_sl4_10)
theorem mutated_pl4_9 (tail : List Nat) : parseItems 4079 28 (linear_v4_9 ++ (93 :: tail)) = some (linear_l4_9, tail) := by
  simpa only [linear_l4_9, linear_v4_9, linear_l4_10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 28 (linear_b65 ++ (44 :: (linear_v4_10 ++ (93 :: tail)))) (linear_v4_10 ++ (93 :: tail)) tail linear_r65 linear_l4_10 (mutated_p65 (44 :: (linear_v4_10 ++ (93 :: tail)))) (mutated_pl4_10 tail))
def linear_l4_8 : List Raw := linear_r49 :: linear_l4_9
def linear_v4_8 : List Nat := (linear_b49) ++ (44 :: linear_v4_9)
theorem mutated_sl4_8 : serializeItems 4080 28 linear_l4_8 = some linear_v4_8 := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 28 linear_r49 linear_r65 linear_l4_10 linear_b49 linear_v4_9 mutated_s49 mutated_sl4_9)
theorem mutated_pl4_8 (tail : List Nat) : parseItems 4080 28 (linear_v4_8 ++ (93 :: tail)) = some (linear_l4_8, tail) := by
  simpa only [linear_l4_8, linear_v4_8, linear_l4_9, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 28 (linear_b49 ++ (44 :: (linear_v4_9 ++ (93 :: tail)))) (linear_v4_9 ++ (93 :: tail)) tail linear_r49 linear_l4_9 (mutated_p49 (44 :: (linear_v4_9 ++ (93 :: tail)))) (mutated_pl4_9 tail))
def linear_l4_7 : List Raw := linear_r44 :: linear_l4_8
def linear_v4_7 : List Nat := (linear_b44) ++ (44 :: linear_v4_8)
theorem mutated_sl4_7 : serializeItems 4081 28 linear_l4_7 = some linear_v4_7 := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 28 linear_r44 linear_r49 linear_l4_9 linear_b44 linear_v4_8 mutated_s44 mutated_sl4_8)
theorem mutated_pl4_7 (tail : List Nat) : parseItems 4081 28 (linear_v4_7 ++ (93 :: tail)) = some (linear_l4_7, tail) := by
  simpa only [linear_l4_7, linear_v4_7, linear_l4_8, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 28 (linear_b44 ++ (44 :: (linear_v4_8 ++ (93 :: tail)))) (linear_v4_8 ++ (93 :: tail)) tail linear_r44 linear_l4_8 (mutated_p44 (44 :: (linear_v4_8 ++ (93 :: tail)))) (mutated_pl4_8 tail))
def linear_l4_6 : List Raw := linear_r39 :: linear_l4_7
def linear_v4_6 : List Nat := (linear_b39) ++ (44 :: linear_v4_7)
theorem mutated_sl4_6 : serializeItems 4082 28 linear_l4_6 = some linear_v4_6 := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4081 28 linear_r39 linear_r44 linear_l4_8 linear_b39 linear_v4_7 mutated_s39 mutated_sl4_7)
theorem mutated_pl4_6 (tail : List Nat) : parseItems 4082 28 (linear_v4_6 ++ (93 :: tail)) = some (linear_l4_6, tail) := by
  simpa only [linear_l4_6, linear_v4_6, linear_l4_7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4081 28 (linear_b39 ++ (44 :: (linear_v4_7 ++ (93 :: tail)))) (linear_v4_7 ++ (93 :: tail)) tail linear_r39 linear_l4_7 (mutated_p39 (44 :: (linear_v4_7 ++ (93 :: tail)))) (mutated_pl4_7 tail))
def linear_l4_5 : List Raw := linear_r34 :: linear_l4_6
def linear_v4_5 : List Nat := (linear_b34) ++ (44 :: linear_v4_6)
theorem mutated_sl4_5 : serializeItems 4083 28 linear_l4_5 = some linear_v4_5 := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4082 28 linear_r34 linear_r39 linear_l4_7 linear_b34 linear_v4_6 mutated_s34 mutated_sl4_6)
theorem mutated_pl4_5 (tail : List Nat) : parseItems 4083 28 (linear_v4_5 ++ (93 :: tail)) = some (linear_l4_5, tail) := by
  simpa only [linear_l4_5, linear_v4_5, linear_l4_6, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4082 28 (linear_b34 ++ (44 :: (linear_v4_6 ++ (93 :: tail)))) (linear_v4_6 ++ (93 :: tail)) tail linear_r34 linear_l4_6 (mutated_p34 (44 :: (linear_v4_6 ++ (93 :: tail)))) (mutated_pl4_6 tail))
def linear_l4_4 : List Raw := linear_r29 :: linear_l4_5
def linear_v4_4 : List Nat := (linear_b29) ++ (44 :: linear_v4_5)
theorem mutated_sl4_4 : serializeItems 4084 28 linear_l4_4 = some linear_v4_4 := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4083 28 linear_r29 linear_r34 linear_l4_6 linear_b29 linear_v4_5 mutated_s29 mutated_sl4_5)
theorem mutated_pl4_4 (tail : List Nat) : parseItems 4084 28 (linear_v4_4 ++ (93 :: tail)) = some (linear_l4_4, tail) := by
  simpa only [linear_l4_4, linear_v4_4, linear_l4_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4083 28 (linear_b29 ++ (44 :: (linear_v4_5 ++ (93 :: tail)))) (linear_v4_5 ++ (93 :: tail)) tail linear_r29 linear_l4_5 (mutated_p29 (44 :: (linear_v4_5 ++ (93 :: tail)))) (mutated_pl4_5 tail))
def linear_l4_3 : List Raw := linear_r24 :: linear_l4_4
def linear_v4_3 : List Nat := (linear_b24) ++ (44 :: linear_v4_4)
theorem mutated_sl4_3 : serializeItems 4085 28 linear_l4_3 = some linear_v4_3 := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4084 28 linear_r24 linear_r29 linear_l4_5 linear_b24 linear_v4_4 mutated_s24 mutated_sl4_4)
theorem mutated_pl4_3 (tail : List Nat) : parseItems 4085 28 (linear_v4_3 ++ (93 :: tail)) = some (linear_l4_3, tail) := by
  simpa only [linear_l4_3, linear_v4_3, linear_l4_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4084 28 (linear_b24 ++ (44 :: (linear_v4_4 ++ (93 :: tail)))) (linear_v4_4 ++ (93 :: tail)) tail linear_r24 linear_l4_4 (mutated_p24 (44 :: (linear_v4_4 ++ (93 :: tail)))) (mutated_pl4_4 tail))
def linear_l4_2 : List Raw := linear_r15 :: linear_l4_3
def linear_v4_2 : List Nat := (linear_b15) ++ (44 :: linear_v4_3)
theorem mutated_sl4_2 : serializeItems 4086 28 linear_l4_2 = some linear_v4_2 := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4085 28 linear_r15 linear_r24 linear_l4_4 linear_b15 linear_v4_3 mutated_s15 mutated_sl4_3)
theorem mutated_pl4_2 (tail : List Nat) : parseItems 4086 28 (linear_v4_2 ++ (93 :: tail)) = some (linear_l4_2, tail) := by
  simpa only [linear_l4_2, linear_v4_2, linear_l4_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4085 28 (linear_b15 ++ (44 :: (linear_v4_3 ++ (93 :: tail)))) (linear_v4_3 ++ (93 :: tail)) tail linear_r15 linear_l4_3 (mutated_p15 (44 :: (linear_v4_3 ++ (93 :: tail)))) (mutated_pl4_3 tail))
def linear_l4_1 : List Raw := linear_r10 :: linear_l4_2
def linear_v4_1 : List Nat := (linear_b10) ++ (44 :: linear_v4_2)
theorem mutated_sl4_1 : serializeItems 4087 28 linear_l4_1 = some linear_v4_1 := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4086 28 linear_r10 linear_r15 linear_l4_3 linear_b10 linear_v4_2 mutated_s10 mutated_sl4_2)
theorem mutated_pl4_1 (tail : List Nat) : parseItems 4087 28 (linear_v4_1 ++ (93 :: tail)) = some (linear_l4_1, tail) := by
  simpa only [linear_l4_1, linear_v4_1, linear_l4_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4086 28 (linear_b10 ++ (44 :: (linear_v4_2 ++ (93 :: tail)))) (linear_v4_2 ++ (93 :: tail)) tail linear_r10 linear_l4_2 (mutated_p10 (44 :: (linear_v4_2 ++ (93 :: tail)))) (mutated_pl4_2 tail))
def linear_l4_0 : List Raw := linear_r5 :: linear_l4_1
def linear_v4_0 : List Nat := (linear_b5) ++ (44 :: linear_v4_1)
theorem mutated_sl4_0 : serializeItems 4088 28 linear_l4_0 = some linear_v4_0 := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4087 28 linear_r5 linear_r10 linear_l4_2 linear_b5 linear_v4_1 mutated_s5 mutated_sl4_1)
theorem mutated_pl4_0 (tail : List Nat) : parseItems 4088 28 (linear_v4_0 ++ (93 :: tail)) = some (linear_l4_0, tail) := by
  simpa only [linear_l4_0, linear_v4_0, linear_l4_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4087 28 (linear_b5 ++ (44 :: (linear_v4_1 ++ (93 :: tail)))) (linear_v4_1 ++ (93 :: tail)) tail linear_r5 linear_l4_1 (mutated_p5 (44 :: (linear_v4_1 ++ (93 :: tail)))) (mutated_pl4_1 tail))
def linear_r4 : Raw := (.arr linear_l4_0)
def linear_b4 : List Nat := linear_g8 ++ (linear_v4_0 ++ linear_g382)
theorem mutated_s4 : serializeRaw 4089 29 linear_r4 = some linear_b4 := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4088 28 linear_l4_0 linear_v4_0 mutated_sl4_0)
theorem mutated_p4 (tail : List Nat) : parseRaw 4089 29 (linear_b4 ++ tail) = some (linear_r4, tail) := by
  simpa only [linear_r4, linear_b4, linear_g8, linear_g382, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4088 28 (linear_v4_0 ++ (93 :: tail)) tail linear_l4_0 (by intro h; cases h) (mutated_pl4_0 tail))
def linear_r150 : Raw := (.arr [(.str [97,108,108,111,99]),(.str [114,101,97,100]),(.str [116,114,97,112]),(.str [119,114,105,116,101])])
def linear_b150 : List Nat := linear_g385
theorem mutated_s150 : serializeRaw 4088 29 linear_r150 = some linear_b150 := by decide +kernel
theorem mutated_p150 (tail : List Nat) : parseRaw 4088 29 (linear_b150 ++ tail) = some (linear_r150, tail) := by rfl
def linear_r151 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b151 : List Nat := linear_g388
theorem mutated_s151 : serializeRaw 4087 29 linear_r151 = some linear_b151 := by decide +kernel
theorem mutated_p151 (tail : List Nat) : parseRaw 4087 29 (linear_b151 ++ tail) = some (linear_r151, tail) := by rfl
def linear_r152 : Raw := (.str [99,97,108,99,117,108,97,116,101])
def linear_b152 : List Nat := linear_g391
theorem mutated_s152 : serializeRaw 4086 29 linear_r152 = some linear_b152 := by decide +kernel
theorem mutated_p152 (tail : List Nat) : parseRaw 4086 29 (linear_b152 ++ tail) = some (linear_r152, tail) := by rfl
def linear_r153 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b153 : List Nat := linear_g394
theorem mutated_s153 : serializeRaw 4085 29 linear_r153 = some linear_b153 := by decide +kernel
theorem mutated_p153 (tail : List Nat) : parseRaw 4085 29 (linear_b153 ++ tail) = some (linear_r153, tail) := by rfl
def linear_r154 : Raw := (.arr [(.str [117,54,52])])
def linear_b154 : List Nat := linear_g397
theorem mutated_s154 : serializeRaw 4084 29 linear_r154 = some linear_b154 := by decide +kernel
theorem mutated_p154 (tail : List Nat) : parseRaw 4084 29 (linear_b154 ++ tail) = some (linear_r154, tail) := by rfl
def linear_k3_0 : List Nat := [98,108,111,99,107,115]
theorem mutated_kd3_0 : stringBytes linear_k3_0 = true := by decide +kernel
theorem mutated_kp3_0 (tail : List Nat) : parseStringTail (linear_k3_0 ++ (34 :: 58 :: tail)) [] = some (linear_k3_0, 58 :: tail) := by rfl
def linear_k3_1 : List Nat := [101,102,102,101,99,116,115]
theorem mutated_kd3_1 : stringBytes linear_k3_1 = true := by decide +kernel
theorem mutated_kp3_1 (tail : List Nat) : parseStringTail (linear_k3_1 ++ (34 :: 58 :: tail)) [] = some (linear_k3_1, 58 :: tail) := by rfl
def linear_k3_2 : List Nat := [101,110,116,114,121]
theorem mutated_kd3_2 : stringBytes linear_k3_2 = true := by decide +kernel
theorem mutated_kp3_2 (tail : List Nat) : parseStringTail (linear_k3_2 ++ (34 :: 58 :: tail)) [] = some (linear_k3_2, 58 :: tail) := by rfl
def linear_k3_3 : List Nat := [110,97,109,101]
theorem mutated_kd3_3 : stringBytes linear_k3_3 = true := by decide +kernel
theorem mutated_kp3_3 (tail : List Nat) : parseStringTail (linear_k3_3 ++ (34 :: 58 :: tail)) [] = some (linear_k3_3, 58 :: tail) := by rfl
def linear_k3_4 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd3_4 : stringBytes linear_k3_4 = true := by decide +kernel
theorem mutated_kp3_4 (tail : List Nat) : parseStringTail (linear_k3_4 ++ (34 :: 58 :: tail)) [] = some (linear_k3_4, 58 :: tail) := by rfl
def linear_k3_5 : List Nat := [114,101,116,117,114,110,115]
theorem mutated_kd3_5 : stringBytes linear_k3_5 = true := by decide +kernel
theorem mutated_kp3_5 (tail : List Nat) : parseStringTail (linear_k3_5 ++ (34 :: 58 :: tail)) [] = some (linear_k3_5, 58 :: tail) := by rfl
def linear_l3_5 : List (List Nat × Raw) := [(linear_k3_5, linear_r154)]
def linear_v3_5 : List Nat := linear_g396 ++ linear_b154
theorem mutated_sl3_5 : serializeFields 4085 29 linear_l3_5 = some linear_v3_5 := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4084 29 linear_k3_5 linear_r154 linear_b154 mutated_kd3_5 mutated_s154)
theorem mutated_pl3_5 (tail : List Nat) : parseFields 4085 29 (linear_v3_5 ++ (125 :: tail)) = some (linear_l3_5, tail) := by
  simpa only [linear_l3_5, linear_v3_5, linear_k3_5, linear_g396, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4084 29 (linear_k3_5 ++ (34 :: 58 :: (linear_b154 ++ (125 :: tail)))) linear_k3_5 (linear_b154 ++ (125 :: tail)) tail linear_r154 (mutated_kp3_5 (linear_b154 ++ (125 :: tail))) (mutated_p154 (125 :: tail)))
def linear_l3_4 : List (List Nat × Raw) := (linear_k3_4, linear_r153) :: linear_l3_5
def linear_v3_4 : List Nat := (linear_g393 ++ linear_b153) ++ (44 :: linear_v3_5)
theorem mutated_sl3_4 : serializeFields 4086 29 linear_l3_4 = some linear_v3_4 := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 29 linear_k3_4 linear_r153 (linear_k3_5, linear_r154) [] linear_b153 linear_v3_5 mutated_kd3_4 mutated_s153 mutated_sl3_5)
theorem mutated_pl3_4 (tail : List Nat) : parseFields 4086 29 (linear_v3_4 ++ (125 :: tail)) = some (linear_l3_4, tail) := by
  simpa only [linear_l3_4, linear_v3_4, linear_k3_4, linear_g393, linear_l3_5, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 29 (linear_k3_4 ++ (34 :: 58 :: (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))))) linear_k3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail)))) (linear_v3_5 ++ (125 :: tail)) tail linear_r153 linear_l3_5 (mutated_kp3_4 (linear_b153 ++ (44 :: (linear_v3_5 ++ (125 :: tail))))) (mutated_p153 (44 :: (linear_v3_5 ++ (125 :: tail)))) (mutated_pl3_5 tail))
def linear_l3_3 : List (List Nat × Raw) := (linear_k3_3, linear_r152) :: linear_l3_4
def linear_v3_3 : List Nat := (linear_g390 ++ linear_b152) ++ (44 :: linear_v3_4)
theorem mutated_sl3_3 : serializeFields 4087 29 linear_l3_3 = some linear_v3_3 := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4086 29 linear_k3_3 linear_r152 (linear_k3_4, linear_r153) linear_l3_5 linear_b152 linear_v3_4 mutated_kd3_3 mutated_s152 mutated_sl3_4)
theorem mutated_pl3_3 (tail : List Nat) : parseFields 4087 29 (linear_v3_3 ++ (125 :: tail)) = some (linear_l3_3, tail) := by
  simpa only [linear_l3_3, linear_v3_3, linear_k3_3, linear_g390, linear_l3_4, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4086 29 (linear_k3_3 ++ (34 :: 58 :: (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))))) linear_k3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail)))) (linear_v3_4 ++ (125 :: tail)) tail linear_r152 linear_l3_4 (mutated_kp3_3 (linear_b152 ++ (44 :: (linear_v3_4 ++ (125 :: tail))))) (mutated_p152 (44 :: (linear_v3_4 ++ (125 :: tail)))) (mutated_pl3_4 tail))
def linear_l3_2 : List (List Nat × Raw) := (linear_k3_2, linear_r151) :: linear_l3_3
def linear_v3_2 : List Nat := (linear_g387 ++ linear_b151) ++ (44 :: linear_v3_3)
theorem mutated_sl3_2 : serializeFields 4088 29 linear_l3_2 = some linear_v3_2 := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4087 29 linear_k3_2 linear_r151 (linear_k3_3, linear_r152) linear_l3_4 linear_b151 linear_v3_3 mutated_kd3_2 mutated_s151 mutated_sl3_3)
theorem mutated_pl3_2 (tail : List Nat) : parseFields 4088 29 (linear_v3_2 ++ (125 :: tail)) = some (linear_l3_2, tail) := by
  simpa only [linear_l3_2, linear_v3_2, linear_k3_2, linear_g387, linear_l3_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4087 29 (linear_k3_2 ++ (34 :: 58 :: (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))))) linear_k3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail)))) (linear_v3_3 ++ (125 :: tail)) tail linear_r151 linear_l3_3 (mutated_kp3_2 (linear_b151 ++ (44 :: (linear_v3_3 ++ (125 :: tail))))) (mutated_p151 (44 :: (linear_v3_3 ++ (125 :: tail)))) (mutated_pl3_3 tail))
def linear_l3_1 : List (List Nat × Raw) := (linear_k3_1, linear_r150) :: linear_l3_2
def linear_v3_1 : List Nat := (linear_g384 ++ linear_b150) ++ (44 :: linear_v3_2)
theorem mutated_sl3_1 : serializeFields 4089 29 linear_l3_1 = some linear_v3_1 := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4088 29 linear_k3_1 linear_r150 (linear_k3_2, linear_r151) linear_l3_3 linear_b150 linear_v3_2 mutated_kd3_1 mutated_s150 mutated_sl3_2)
theorem mutated_pl3_1 (tail : List Nat) : parseFields 4089 29 (linear_v3_1 ++ (125 :: tail)) = some (linear_l3_1, tail) := by
  simpa only [linear_l3_1, linear_v3_1, linear_k3_1, linear_g384, linear_l3_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4088 29 (linear_k3_1 ++ (34 :: 58 :: (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))))) linear_k3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail)))) (linear_v3_2 ++ (125 :: tail)) tail linear_r150 linear_l3_2 (mutated_kp3_1 (linear_b150 ++ (44 :: (linear_v3_2 ++ (125 :: tail))))) (mutated_p150 (44 :: (linear_v3_2 ++ (125 :: tail)))) (mutated_pl3_2 tail))
def linear_l3_0 : List (List Nat × Raw) := (linear_k3_0, linear_r4) :: linear_l3_1
def linear_v3_0 : List Nat := (linear_g7 ++ linear_b4) ++ (44 :: linear_v3_1)
theorem mutated_sl3_0 : serializeFields 4090 29 linear_l3_0 = some linear_v3_0 := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4089 29 linear_k3_0 linear_r4 (linear_k3_1, linear_r150) linear_l3_2 linear_b4 linear_v3_1 mutated_kd3_0 mutated_s4 mutated_sl3_1)
theorem mutated_pl3_0 (tail : List Nat) : parseFields 4090 29 (linear_v3_0 ++ (125 :: tail)) = some (linear_l3_0, tail) := by
  simpa only [linear_l3_0, linear_v3_0, linear_k3_0, linear_g7, linear_l3_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4089 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) linear_k3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))) (linear_v3_1 ++ (125 :: tail)) tail linear_r4 linear_l3_1 (mutated_kp3_0 (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail))))) (mutated_p4 (44 :: (linear_v3_1 ++ (125 :: tail)))) (mutated_pl3_1 tail))
def linear_r3 : Raw := (.obj linear_l3_0)
def linear_b3 : List Nat := linear_g6 ++ (linear_v3_0 ++ linear_g398)
theorem mutated_o3 : orderedFields linear_l3_0 = true := by decide +kernel
theorem mutated_s3 : serializeRaw 4091 30 linear_r3 = some linear_b3 := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4090 29 linear_l3_0 linear_v3_0 mutated_o3 mutated_sl3_0)
theorem mutated_p3 (tail : List Nat) : parseRaw 4091 30 (linear_b3 ++ tail) = some (linear_r3, tail) := by
  simpa only [linear_r3, linear_b3, linear_g6, linear_g398, linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4090 29 (linear_k3_0 ++ (34 :: 58 :: (linear_b4 ++ (44 :: (linear_v3_1 ++ (125 :: tail)))))) tail linear_l3_0 mutated_o3 (by simpa only [linear_v3_0, linear_k3_0, linear_g7, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl3_0 tail)))
def linear_l2_0 : List Raw := [linear_r3]
def linear_v2_0 : List Nat := linear_b3
theorem mutated_sl2_0 : serializeItems 4092 30 linear_l2_0 = some linear_v2_0 := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4091 30 linear_r3 linear_b3 mutated_s3)
theorem mutated_pl2_0 (tail : List Nat) : parseItems 4092 30 (linear_v2_0 ++ (93 :: tail)) = some (linear_l2_0, tail) := by
  simpa only [linear_l2_0, linear_v2_0, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4091 30 (linear_b3 ++ (93 :: tail)) tail linear_r3 (mutated_p3 (93 :: tail)))
def linear_r2 : Raw := (.arr linear_l2_0)
def linear_b2 : List Nat := linear_g5 ++ (linear_v2_0 ++ linear_g399)
theorem mutated_s2 : serializeRaw 4093 31 linear_r2 = some linear_b2 := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4092 30 linear_l2_0 linear_v2_0 mutated_sl2_0)
theorem mutated_p2 (tail : List Nat) : parseRaw 4093 31 (linear_b2 ++ tail) = some (linear_r2, tail) := by
  simpa only [linear_r2, linear_b2, linear_g5, linear_g399, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4092 30 (linear_v2_0 ++ (93 :: tail)) tail linear_l2_0 (by intro h; cases h) (mutated_pl2_0 tail))
def linear_r155 : Raw := (.str [114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114])
def linear_b155 : List Nat := linear_g402
theorem mutated_s155 : serializeRaw 4092 31 linear_r155 = some linear_b155 := by decide +kernel
theorem mutated_p155 (tail : List Nat) : parseRaw 4092 31 (linear_b155 ++ tail) = some (linear_r155, tail) := by rfl
def linear_r156 : Raw := (.str [104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49])
def linear_b156 : List Nat := linear_g405
theorem mutated_s156 : serializeRaw 4091 31 linear_r156 = some linear_b156 := by decide +kernel
theorem mutated_p156 (tail : List Nat) : parseRaw 4091 31 (linear_b156 ++ tail) = some (linear_r156, tail) := by rfl
def linear_k0_0 : List Nat := [101,120,112,111,114,116,115]
theorem mutated_kd0_0 : stringBytes linear_k0_0 = true := by decide +kernel
theorem mutated_kp0_0 (tail : List Nat) : parseStringTail (linear_k0_0 ++ (34 :: 58 :: tail)) [] = some (linear_k0_0, 58 :: tail) := by rfl
def linear_k0_1 : List Nat := [102,117,110,99,116,105,111,110,115]
theorem mutated_kd0_1 : stringBytes linear_k0_1 = true := by decide +kernel
theorem mutated_kp0_1 (tail : List Nat) : parseStringTail (linear_k0_1 ++ (34 :: 58 :: tail)) [] = some (linear_k0_1, 58 :: tail) := by rfl
def linear_k0_2 : List Nat := [109,111,100,117,108,101]
theorem mutated_kd0_2 : stringBytes linear_k0_2 = true := by decide +kernel
theorem mutated_kp0_2 (tail : List Nat) : parseStringTail (linear_k0_2 ++ (34 :: 58 :: tail)) [] = some (linear_k0_2, 58 :: tail) := by rfl
def linear_k0_3 : List Nat := [115,99,104,101,109,97]
theorem mutated_kd0_3 : stringBytes linear_k0_3 = true := by decide +kernel
theorem mutated_kp0_3 (tail : List Nat) : parseStringTail (linear_k0_3 ++ (34 :: 58 :: tail)) [] = some (linear_k0_3, 58 :: tail) := by rfl
def linear_l0_3 : List (List Nat × Raw) := [(linear_k0_3, linear_r156)]
def linear_v0_3 : List Nat := linear_g404 ++ linear_b156
theorem mutated_sl0_3 : serializeFields 4092 31 linear_l0_3 = some linear_v0_3 := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4091 31 linear_k0_3 linear_r156 linear_b156 mutated_kd0_3 mutated_s156)
theorem mutated_pl0_3 (tail : List Nat) : parseFields 4092 31 (linear_v0_3 ++ (125 :: tail)) = some (linear_l0_3, tail) := by
  simpa only [linear_l0_3, linear_v0_3, linear_k0_3, linear_g404, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4091 31 (linear_k0_3 ++ (34 :: 58 :: (linear_b156 ++ (125 :: tail)))) linear_k0_3 (linear_b156 ++ (125 :: tail)) tail linear_r156 (mutated_kp0_3 (linear_b156 ++ (125 :: tail))) (mutated_p156 (125 :: tail)))
def linear_l0_2 : List (List Nat × Raw) := (linear_k0_2, linear_r155) :: linear_l0_3
def linear_v0_2 : List Nat := (linear_g401 ++ linear_b155) ++ (44 :: linear_v0_3)
theorem mutated_sl0_2 : serializeFields 4093 31 linear_l0_2 = some linear_v0_2 := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4092 31 linear_k0_2 linear_r155 (linear_k0_3, linear_r156) [] linear_b155 linear_v0_3 mutated_kd0_2 mutated_s155 mutated_sl0_3)
theorem mutated_pl0_2 (tail : List Nat) : parseFields 4093 31 (linear_v0_2 ++ (125 :: tail)) = some (linear_l0_2, tail) := by
  simpa only [linear_l0_2, linear_v0_2, linear_k0_2, linear_g401, linear_l0_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4092 31 (linear_k0_2 ++ (34 :: 58 :: (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))))) linear_k0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail)))) (linear_v0_3 ++ (125 :: tail)) tail linear_r155 linear_l0_3 (mutated_kp0_2 (linear_b155 ++ (44 :: (linear_v0_3 ++ (125 :: tail))))) (mutated_p155 (44 :: (linear_v0_3 ++ (125 :: tail)))) (mutated_pl0_3 tail))
def linear_l0_1 : List (List Nat × Raw) := (linear_k0_1, linear_r2) :: linear_l0_2
def linear_v0_1 : List Nat := (linear_g4 ++ linear_b2) ++ (44 :: linear_v0_2)
theorem mutated_sl0_1 : serializeFields 4094 31 linear_l0_1 = some linear_v0_1 := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4093 31 linear_k0_1 linear_r2 (linear_k0_2, linear_r155) linear_l0_3 linear_b2 linear_v0_2 mutated_kd0_1 mutated_s2 mutated_sl0_2)
theorem mutated_pl0_1 (tail : List Nat) : parseFields 4094 31 (linear_v0_1 ++ (125 :: tail)) = some (linear_l0_1, tail) := by
  simpa only [linear_l0_1, linear_v0_1, linear_k0_1, linear_g4, linear_l0_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4093 31 (linear_k0_1 ++ (34 :: 58 :: (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))))) linear_k0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail)))) (linear_v0_2 ++ (125 :: tail)) tail linear_r2 linear_l0_2 (mutated_kp0_1 (linear_b2 ++ (44 :: (linear_v0_2 ++ (125 :: tail))))) (mutated_p2 (44 :: (linear_v0_2 ++ (125 :: tail)))) (mutated_pl0_2 tail))
def linear_l0_0 : List (List Nat × Raw) := (linear_k0_0, linear_r1) :: linear_l0_1
def linear_v0_0 : List Nat := (linear_g1 ++ linear_b1) ++ (44 :: linear_v0_1)
theorem mutated_sl0_0 : serializeFields 4095 31 linear_l0_0 = some linear_v0_0 := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4094 31 linear_k0_0 linear_r1 (linear_k0_1, linear_r2) linear_l0_2 linear_b1 linear_v0_1 mutated_kd0_0 mutated_s1 mutated_sl0_1)
theorem mutated_pl0_0 (tail : List Nat) : parseFields 4095 31 (linear_v0_0 ++ (125 :: tail)) = some (linear_l0_0, tail) := by
  simpa only [linear_l0_0, linear_v0_0, linear_k0_0, linear_g1, linear_l0_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4094 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) linear_k0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))) (linear_v0_1 ++ (125 :: tail)) tail linear_r1 linear_l0_1 (mutated_kp0_0 (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail))))) (mutated_p1 (44 :: (linear_v0_1 ++ (125 :: tail)))) (mutated_pl0_1 tail))
def linear_r0 : Raw := (.obj linear_l0_0)
def linear_b0 : List Nat := linear_g0 ++ (linear_v0_0 ++ linear_g406)
theorem mutated_o0 : orderedFields linear_l0_0 = true := by decide +kernel
theorem mutated_s0 : serializeRaw 4096 32 linear_r0 = some linear_b0 := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4095 31 linear_l0_0 linear_v0_0 mutated_o0 mutated_sl0_0)
theorem mutated_p0 (tail : List Nat) : parseRaw 4096 32 (linear_b0 ++ tail) = some (linear_r0, tail) := by
  simpa only [linear_r0, linear_b0, linear_g0, linear_g406, linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4095 31 (linear_k0_0 ++ (34 :: 58 :: (linear_b1 ++ (44 :: (linear_v0_1 ++ (125 :: tail)))))) tail linear_l0_0 mutated_o0 (by simpa only [linear_v0_0, linear_k0_0, linear_g1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl0_0 tail)))
def linearRaw : Raw := linear_r0
def linearBytes : List Nat := linear_b0
theorem mutated_bounds : withinBounds linearRaw = true := by decide +kernel
theorem mutated_serialized : serializeRaw transportFuel transportDepth linearRaw = some linearBytes := by exact mutated_s0
theorem mutated_parsed : parseRaw transportFuel transportDepth linearBytes = some (linearRaw, []) := by
  simpa only [List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_p0 [])
theorem linear_bf0000 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g0 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0001 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g1 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0002 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g2 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0003 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g4 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0004 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g5 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0005 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g6 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0006 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g7 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0007 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g8 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0008 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g9 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0009 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g10 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0010 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g11 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0011 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g13 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0012 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g14 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0013 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g16 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0014 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g17 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0015 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g19 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0016 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g20 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0017 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g21 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0018 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g23 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0019 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g24 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0020 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g25 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0021 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g27 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0022 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g28 178 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0023 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g30 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0024 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g31 195 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0025 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g33 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0026 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g34 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0027 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g35 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0028 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g37 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0029 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g38 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0030 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g39 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0031 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g41 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0032 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g42 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0033 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g43 58 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0034 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g45 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0035 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g47 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0036 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g49 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0037 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g50 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0038 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g52 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0039 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g53 200 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0040 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g55 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0041 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g56 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0042 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g57 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0043 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g59 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0044 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g60 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0045 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g61 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0046 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g63 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0047 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g64 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0048 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g66 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0049 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g67 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0050 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g69 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0051 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g70 233 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0052 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g71 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0053 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g73 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0054 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g74 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0055 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g75 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0056 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g77 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0057 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g78 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0058 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g80 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0059 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g81 204 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0060 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g83 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0061 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g84 115 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0062 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g85 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0063 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g87 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0064 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g88 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0065 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g89 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0066 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g91 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0067 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g92 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0068 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g94 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0069 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g95 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0070 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g97 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0071 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g98 253 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0072 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g99 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0073 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g101 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0074 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g102 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0075 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g103 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0076 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g105 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0077 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g106 153 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0078 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g108 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0079 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g109 236 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0080 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g111 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0081 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g112 33 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0082 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g113 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0083 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g115 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0084 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g116 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0085 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g117 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0086 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g119 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0087 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g120 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0088 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g122 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0089 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g123 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0090 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g125 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0091 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g126 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0092 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g127 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0093 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g129 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0094 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g130 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0095 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g131 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0096 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g133 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0097 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g134 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0098 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g135 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0099 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g137 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0100 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g139 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0101 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g141 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0102 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g143 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0103 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g145 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0104 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g147 92 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0105 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g149 80 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0106 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g151 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0107 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g153 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0108 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g155 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0109 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g156 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0110 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g158 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0111 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g159 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0112 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g161 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0113 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g162 93 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0114 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g163 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0115 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g165 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0116 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g166 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0117 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g167 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0118 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g169 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0119 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g170 173 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0120 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g172 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0121 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g173 170 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0122 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g175 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0123 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g176 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0124 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g177 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0125 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g179 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0126 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g180 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0127 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g181 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0128 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g183 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0129 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g184 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0130 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g186 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0131 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g187 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0132 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g189 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0133 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g190 230 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0134 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g191 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0135 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g193 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0136 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g194 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0137 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g195 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0138 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g197 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0139 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g198 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0140 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g199 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0141 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g201 99 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0142 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g203 56 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0143 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g205 100 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0144 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g207 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0145 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g209 86 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0146 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g211 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0147 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g212 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0148 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g214 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0149 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g215 202 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0150 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g217 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0151 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g218 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0152 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g219 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0153 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g221 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0154 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g222 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0155 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g223 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0156 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g225 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0157 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g226 155 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0158 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g228 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0159 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g229 205 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0160 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g231 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0161 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g232 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0162 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g233 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0163 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g235 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0164 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g236 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0165 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g237 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0166 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g239 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0167 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g240 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0168 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g242 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0169 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g243 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0170 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g245 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0171 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g246 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0172 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g247 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0173 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g249 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0174 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g250 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0175 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g251 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0176 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g253 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0177 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g254 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0178 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g255 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0179 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g257 104 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0180 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g259 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0181 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g261 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0182 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g263 103 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0183 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g265 101 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0184 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g267 94 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0185 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g269 83 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0186 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g271 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0187 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g273 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0188 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g275 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0189 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g276 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0190 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g278 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0191 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g279 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0192 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g281 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0193 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g282 98 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0194 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g283 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0195 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g285 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0196 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g286 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0197 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g287 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0198 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g289 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0199 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g290 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0200 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g292 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0201 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g293 175 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0202 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g295 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0203 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g296 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0204 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g297 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0205 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g299 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0206 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g300 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0207 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g301 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0208 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g303 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0209 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g304 105 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0210 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g306 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0211 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g307 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0212 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g309 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0213 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g310 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0214 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g311 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0215 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g313 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0216 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g314 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0217 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g315 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0218 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g317 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0219 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g318 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0220 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g319 96 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0221 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g321 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0222 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g323 57 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0223 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g325 102 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0224 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g327 107 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0225 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g329 87 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0226 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g331 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0227 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g332 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0228 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g334 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0229 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g335 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0230 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g337 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0231 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g338 109 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0232 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g339 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0233 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g341 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0234 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g342 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0235 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g343 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0236 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g345 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0237 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g346 156 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0238 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g348 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0239 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g349 208 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0240 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g351 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0241 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g352 34 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0242 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g353 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0243 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g355 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0244 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g356 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0245 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g357 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0246 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g359 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0247 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g360 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0248 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g362 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0249 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g363 210 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0250 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g365 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0251 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g366 221 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0252 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g367 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0253 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g369 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0254 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g370 5 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0255 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g371 12 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0256 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g373 6 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0257 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g374 209 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0258 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g376 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0259 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g377 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0260 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g379 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0261 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g380 243 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0262 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g381 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0263 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g382 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0264 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g384 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0265 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g385 31 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0266 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g387 8 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0267 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g388 13 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0268 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g390 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0269 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g391 11 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0270 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g393 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0271 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g394 61 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0272 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g396 10 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0273 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g397 7 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0274 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g398 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0275 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g399 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0276 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g401 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0277 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g402 18 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0278 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g404 9 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0279 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g405 22 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0280 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_g406 1 := by unfold HiaCoreSyntaxSlice.ByteFactsResearch.facts; decide +kernel
theorem linear_bf0281 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b1 13 := by
  simpa only [linear_b1] using linear_bf0002
theorem linear_bf0282 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b6 13 := by
  simpa only [linear_b6] using linear_bf0010
theorem linear_bf0283 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b7 209 := by
  simpa only [linear_b7] using linear_bf0012
theorem linear_bf0284 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b8 61 := by
  simpa only [linear_b8] using linear_bf0014
theorem linear_bf0285 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b9 209 := by
  simpa only [linear_b9] using linear_bf0016
theorem linear_bf0286 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_3 216 := by
  simpa only [linear_v5_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g19 linear_b9 7 209 linear_bf0015 linear_bf0285)
theorem linear_bf0287 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_2 287 := by
  simpa only [linear_v5_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g16 ++ linear_b8) (44 :: linear_v5_3) 70 217 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g16 linear_b8 9 61 linear_bf0013 linear_bf0284) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_3 216 (by decide +kernel) linear_bf0286))
theorem linear_bf0288 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_1 503 := by
  simpa only [linear_v5_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g13 ++ linear_b7) (44 :: linear_v5_2) 215 288 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g13 linear_b7 6 209 linear_bf0011 linear_bf0283) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_2 287 (by decide +kernel) linear_bf0287))
theorem linear_bf0289 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v5_0 522 := by
  simpa only [linear_v5_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g10 ++ linear_b6) (44 :: linear_v5_1) 18 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g10 linear_b6 5 13 linear_bf0009 linear_bf0282) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v5_1 503 (by decide +kernel) linear_bf0288))
theorem linear_bf0290 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b5 524 := by
  simpa only [linear_b5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g9 (linear_v5_0 ++ linear_g21) 1 523 linear_bf0008 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v5_0 linear_g21 522 1 linear_bf0289 linear_bf0017))
theorem linear_bf0291 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b11 13 := by
  simpa only [linear_b11] using linear_bf0020
theorem linear_bf0292 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b12 178 := by
  simpa only [linear_b12] using linear_bf0022
theorem linear_bf0293 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b13 195 := by
  simpa only [linear_b13] using linear_bf0024
theorem linear_bf0294 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b14 100 := by
  simpa only [linear_b14] using linear_bf0026
theorem linear_bf0295 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_3 107 := by
  simpa only [linear_v10_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g33 linear_b14 7 100 linear_bf0025 linear_bf0294)
theorem linear_bf0296 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_2 312 := by
  simpa only [linear_v10_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g30 ++ linear_b13) (44 :: linear_v10_3) 204 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g30 linear_b13 9 195 linear_bf0023 linear_bf0293) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_3 107 (by decide +kernel) linear_bf0295))
theorem linear_bf0297 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_1 497 := by
  simpa only [linear_v10_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g27 ++ linear_b12) (44 :: linear_v10_2) 184 313 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g27 linear_b12 6 178 linear_bf0021 linear_bf0292) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_2 312 (by decide +kernel) linear_bf0296))
theorem linear_bf0298 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v10_0 516 := by
  simpa only [linear_v10_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g24 ++ linear_b11) (44 :: linear_v10_1) 18 498 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g24 linear_b11 5 13 linear_bf0019 linear_bf0291) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v10_1 497 (by decide +kernel) linear_bf0297))
theorem linear_bf0299 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b10 518 := by
  simpa only [linear_b10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g23 (linear_v10_0 ++ linear_g35) 1 517 linear_bf0018 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v10_0 linear_g35 516 1 linear_bf0298 linear_bf0027))
theorem linear_bf0300 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b16 13 := by
  simpa only [linear_b16] using linear_bf0030
theorem linear_bf0301 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b18 58 := by
  simpa only [linear_b18] using linear_bf0033
theorem linear_bf0302 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b19 87 := by
  simpa only [linear_b19] using linear_bf0034
theorem linear_bf0303 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b20 100 := by
  simpa only [linear_b20] using linear_bf0035
theorem linear_bf0304 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b21 104 := by
  simpa only [linear_b21] using linear_bf0036
theorem linear_bf0305 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_3 104 := by
  simpa only [linear_v17_3] using linear_bf0304
theorem linear_bf0306 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_2 205 := by
  simpa only [linear_v17_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b20 (44 :: linear_v17_3) 100 105 linear_bf0303 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_3 104 (by decide +kernel) linear_bf0305))
theorem linear_bf0307 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_1 293 := by
  simpa only [linear_v17_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b19 (44 :: linear_v17_2) 87 206 linear_bf0302 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_2 205 (by decide +kernel) linear_bf0306))
theorem linear_bf0308 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v17_0 352 := by
  simpa only [linear_v17_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b18 (44 :: linear_v17_1) 58 294 linear_bf0301 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v17_1 293 (by decide +kernel) linear_bf0307))
theorem linear_bf0309 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b17 354 := by
  simpa only [linear_b17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g42 (linear_v17_0 ++ linear_g50) 1 353 linear_bf0032 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v17_0 linear_g50 352 1 linear_bf0308 linear_bf0037))
theorem linear_bf0310 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b22 200 := by
  simpa only [linear_b22] using linear_bf0039
theorem linear_bf0311 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b23 33 := by
  simpa only [linear_b23] using linear_bf0041
theorem linear_bf0312 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_3 40 := by
  simpa only [linear_v15_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g55 linear_b23 7 33 linear_bf0040 linear_bf0311)
theorem linear_bf0313 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_2 250 := by
  simpa only [linear_v15_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g52 ++ linear_b22) (44 :: linear_v15_3) 209 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g52 linear_b22 9 200 linear_bf0038 linear_bf0310) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_3 40 (by decide +kernel) linear_bf0312))
theorem linear_bf0314 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_1 611 := by
  simpa only [linear_v15_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g41 ++ linear_b17) (44 :: linear_v15_2) 360 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g41 linear_b17 6 354 linear_bf0031 linear_bf0309) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_2 250 (by decide +kernel) linear_bf0313))
theorem linear_bf0315 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v15_0 630 := by
  simpa only [linear_v15_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g38 ++ linear_b16) (44 :: linear_v15_1) 18 612 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g38 linear_b16 5 13 linear_bf0029 linear_bf0300) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v15_1 611 (by decide +kernel) linear_bf0314))
theorem linear_bf0316 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b15 632 := by
  simpa only [linear_b15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g37 (linear_v15_0 ++ linear_g57) 1 631 linear_bf0028 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v15_0 linear_g57 630 1 linear_bf0315 linear_bf0042))
theorem linear_bf0317 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b25 13 := by
  simpa only [linear_b25] using linear_bf0045
theorem linear_bf0318 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b26 102 := by
  simpa only [linear_b26] using linear_bf0047
theorem linear_bf0319 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b27 204 := by
  simpa only [linear_b27] using linear_bf0049
theorem linear_bf0320 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b28 233 := by
  simpa only [linear_b28] using linear_bf0051
theorem linear_bf0321 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_3 240 := by
  simpa only [linear_v24_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g69 linear_b28 7 233 linear_bf0050 linear_bf0320)
theorem linear_bf0322 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_2 454 := by
  simpa only [linear_v24_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g66 ++ linear_b27) (44 :: linear_v24_3) 213 241 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g66 linear_b27 9 204 linear_bf0048 linear_bf0319) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_3 240 (by decide +kernel) linear_bf0321))
theorem linear_bf0323 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_1 563 := by
  simpa only [linear_v24_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g63 ++ linear_b26) (44 :: linear_v24_2) 108 455 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g63 linear_b26 6 102 linear_bf0046 linear_bf0318) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_2 454 (by decide +kernel) linear_bf0322))
theorem linear_bf0324 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v24_0 582 := by
  simpa only [linear_v24_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g60 ++ linear_b25) (44 :: linear_v24_1) 18 564 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g60 linear_b25 5 13 linear_bf0044 linear_bf0317) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v24_1 563 (by decide +kernel) linear_bf0323))
theorem linear_bf0325 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b24 584 := by
  simpa only [linear_b24] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g59 (linear_v24_0 ++ linear_g71) 1 583 linear_bf0043 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v24_0 linear_g71 582 1 linear_bf0324 linear_bf0052))
theorem linear_bf0326 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b30 13 := by
  simpa only [linear_b30] using linear_bf0055
theorem linear_bf0327 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b31 173 := by
  simpa only [linear_b31] using linear_bf0057
theorem linear_bf0328 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b32 204 := by
  simpa only [linear_b32] using linear_bf0059
theorem linear_bf0329 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b33 115 := by
  simpa only [linear_b33] using linear_bf0061
theorem linear_bf0330 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_3 122 := by
  simpa only [linear_v29_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g83 linear_b33 7 115 linear_bf0060 linear_bf0329)
theorem linear_bf0331 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_2 336 := by
  simpa only [linear_v29_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g80 ++ linear_b32) (44 :: linear_v29_3) 213 123 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g80 linear_b32 9 204 linear_bf0058 linear_bf0328) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_3 122 (by decide +kernel) linear_bf0330))
theorem linear_bf0332 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_1 516 := by
  simpa only [linear_v29_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g77 ++ linear_b31) (44 :: linear_v29_2) 179 337 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g77 linear_b31 6 173 linear_bf0056 linear_bf0327) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_2 336 (by decide +kernel) linear_bf0331))
theorem linear_bf0333 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v29_0 535 := by
  simpa only [linear_v29_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g74 ++ linear_b30) (44 :: linear_v29_1) 18 517 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g74 linear_b30 5 13 linear_bf0054 linear_bf0326) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v29_1 516 (by decide +kernel) linear_bf0332))
theorem linear_bf0334 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b29 537 := by
  simpa only [linear_b29] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g73 (linear_v29_0 ++ linear_g85) 1 536 linear_bf0053 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v29_0 linear_g85 535 1 linear_bf0333 linear_bf0062))
theorem linear_bf0335 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b35 13 := by
  simpa only [linear_b35] using linear_bf0065
theorem linear_bf0336 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b36 102 := by
  simpa only [linear_b36] using linear_bf0067
theorem linear_bf0337 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b37 236 := by
  simpa only [linear_b37] using linear_bf0069
theorem linear_bf0338 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b38 253 := by
  simpa only [linear_b38] using linear_bf0071
theorem linear_bf0339 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_3 260 := by
  simpa only [linear_v34_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g97 linear_b38 7 253 linear_bf0070 linear_bf0338)
theorem linear_bf0340 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_2 506 := by
  simpa only [linear_v34_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g94 ++ linear_b37) (44 :: linear_v34_3) 245 261 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g94 linear_b37 9 236 linear_bf0068 linear_bf0337) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_3 260 (by decide +kernel) linear_bf0339))
theorem linear_bf0341 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_1 615 := by
  simpa only [linear_v34_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g91 ++ linear_b36) (44 :: linear_v34_2) 108 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g91 linear_b36 6 102 linear_bf0066 linear_bf0336) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_2 506 (by decide +kernel) linear_bf0340))
theorem linear_bf0342 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v34_0 634 := by
  simpa only [linear_v34_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g88 ++ linear_b35) (44 :: linear_v34_1) 18 616 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g88 linear_b35 5 13 linear_bf0064 linear_bf0335) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v34_1 615 (by decide +kernel) linear_bf0341))
theorem linear_bf0343 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b34 636 := by
  simpa only [linear_b34] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g87 (linear_v34_0 ++ linear_g99) 1 635 linear_bf0063 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v34_0 linear_g99 634 1 linear_bf0342 linear_bf0072))
theorem linear_bf0344 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b40 13 := by
  simpa only [linear_b40] using linear_bf0075
theorem linear_bf0345 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b41 153 := by
  simpa only [linear_b41] using linear_bf0077
theorem linear_bf0346 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b42 236 := by
  simpa only [linear_b42] using linear_bf0079
theorem linear_bf0347 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b43 33 := by
  simpa only [linear_b43] using linear_bf0081
theorem linear_bf0348 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_3 40 := by
  simpa only [linear_v39_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g111 linear_b43 7 33 linear_bf0080 linear_bf0347)
theorem linear_bf0349 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_2 286 := by
  simpa only [linear_v39_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g108 ++ linear_b42) (44 :: linear_v39_3) 245 41 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g108 linear_b42 9 236 linear_bf0078 linear_bf0346) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_3 40 (by decide +kernel) linear_bf0348))
theorem linear_bf0350 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_1 446 := by
  simpa only [linear_v39_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g105 ++ linear_b41) (44 :: linear_v39_2) 159 287 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g105 linear_b41 6 153 linear_bf0076 linear_bf0345) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_2 286 (by decide +kernel) linear_bf0349))
theorem linear_bf0351 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v39_0 465 := by
  simpa only [linear_v39_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g102 ++ linear_b40) (44 :: linear_v39_1) 18 447 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g102 linear_b40 5 13 linear_bf0074 linear_bf0344) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v39_1 446 (by decide +kernel) linear_bf0350))
theorem linear_bf0352 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b39 467 := by
  simpa only [linear_b39] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g101 (linear_v39_0 ++ linear_g113) 1 466 linear_bf0073 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v39_0 linear_g113 465 1 linear_bf0351 linear_bf0082))
theorem linear_bf0353 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b45 11 := by
  simpa only [linear_b45] using linear_bf0085
theorem linear_bf0354 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b46 102 := by
  simpa only [linear_b46] using linear_bf0087
theorem linear_bf0355 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b47 170 := by
  simpa only [linear_b47] using linear_bf0089
theorem linear_bf0356 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b48 210 := by
  simpa only [linear_b48] using linear_bf0091
theorem linear_bf0357 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_3 217 := by
  simpa only [linear_v44_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g125 linear_b48 7 210 linear_bf0090 linear_bf0356)
theorem linear_bf0358 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_2 397 := by
  simpa only [linear_v44_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g122 ++ linear_b47) (44 :: linear_v44_3) 179 218 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g122 linear_b47 9 170 linear_bf0088 linear_bf0355) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_3 217 (by decide +kernel) linear_bf0357))
theorem linear_bf0359 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_1 506 := by
  simpa only [linear_v44_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g119 ++ linear_b46) (44 :: linear_v44_2) 108 398 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g119 linear_b46 6 102 linear_bf0086 linear_bf0354) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_2 397 (by decide +kernel) linear_bf0358))
theorem linear_bf0360 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v44_0 523 := by
  simpa only [linear_v44_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g116 ++ linear_b45) (44 :: linear_v44_1) 16 507 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g116 linear_b45 5 11 linear_bf0084 linear_bf0353) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v44_1 506 (by decide +kernel) linear_bf0359))
theorem linear_bf0361 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b44 525 := by
  simpa only [linear_b44] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g115 (linear_v44_0 ++ linear_g127) 1 524 linear_bf0083 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v44_0 linear_g127 523 1 linear_bf0360 linear_bf0092))
theorem linear_bf0362 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b50 11 := by
  simpa only [linear_b50] using linear_bf0095
theorem linear_bf0363 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b52 100 := by
  simpa only [linear_b52] using linear_bf0098
theorem linear_bf0364 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b53 101 := by
  simpa only [linear_b53] using linear_bf0099
theorem linear_bf0365 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b54 99 := by
  simpa only [linear_b54] using linear_bf0100
theorem linear_bf0366 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b55 99 := by
  simpa only [linear_b55] using linear_bf0101
theorem linear_bf0367 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b56 100 := by
  simpa only [linear_b56] using linear_bf0102
theorem linear_bf0368 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b57 99 := by
  simpa only [linear_b57] using linear_bf0103
theorem linear_bf0369 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b58 92 := by
  simpa only [linear_b58] using linear_bf0104
theorem linear_bf0370 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b59 80 := by
  simpa only [linear_b59] using linear_bf0105
theorem linear_bf0371 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b60 56 := by
  simpa only [linear_b60] using linear_bf0106
theorem linear_bf0372 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b61 86 := by
  simpa only [linear_b61] using linear_bf0107
theorem linear_bf0373 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b62 103 := by
  simpa only [linear_b62] using linear_bf0108
theorem linear_bf0374 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_10 103 := by
  simpa only [linear_v51_10] using linear_bf0373
theorem linear_bf0375 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_9 190 := by
  simpa only [linear_v51_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b61 (44 :: linear_v51_10) 86 104 linear_bf0372 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_10 103 (by decide +kernel) linear_bf0374))
theorem linear_bf0376 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_8 247 := by
  simpa only [linear_v51_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b60 (44 :: linear_v51_9) 56 191 linear_bf0371 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_9 190 (by decide +kernel) linear_bf0375))
theorem linear_bf0377 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_7 328 := by
  simpa only [linear_v51_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b59 (44 :: linear_v51_8) 80 248 linear_bf0370 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_8 247 (by decide +kernel) linear_bf0376))
theorem linear_bf0378 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_6 421 := by
  simpa only [linear_v51_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b58 (44 :: linear_v51_7) 92 329 linear_bf0369 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_7 328 (by decide +kernel) linear_bf0377))
theorem linear_bf0379 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_5 521 := by
  simpa only [linear_v51_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b57 (44 :: linear_v51_6) 99 422 linear_bf0368 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_6 421 (by decide +kernel) linear_bf0378))
theorem linear_bf0380 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_4 622 := by
  simpa only [linear_v51_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b56 (44 :: linear_v51_5) 100 522 linear_bf0367 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_5 521 (by decide +kernel) linear_bf0379))
theorem linear_bf0381 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_3 722 := by
  simpa only [linear_v51_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b55 (44 :: linear_v51_4) 99 623 linear_bf0366 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_4 622 (by decide +kernel) linear_bf0380))
theorem linear_bf0382 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_2 822 := by
  simpa only [linear_v51_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b54 (44 :: linear_v51_3) 99 723 linear_bf0365 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_3 722 (by decide +kernel) linear_bf0381))
theorem linear_bf0383 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_1 924 := by
  simpa only [linear_v51_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b53 (44 :: linear_v51_2) 101 823 linear_bf0364 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_2 822 (by decide +kernel) linear_bf0382))
theorem linear_bf0384 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v51_0 1025 := by
  simpa only [linear_v51_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b52 (44 :: linear_v51_1) 100 925 linear_bf0363 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v51_1 924 (by decide +kernel) linear_bf0383))
theorem linear_bf0385 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b51 1027 := by
  simpa only [linear_b51] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g134 (linear_v51_0 ++ linear_g156) 1 1026 linear_bf0097 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v51_0 linear_g156 1025 1 linear_bf0384 linear_bf0109))
theorem linear_bf0386 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b63 170 := by
  simpa only [linear_b63] using linear_bf0111
theorem linear_bf0387 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b64 93 := by
  simpa only [linear_b64] using linear_bf0113
theorem linear_bf0388 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_3 100 := by
  simpa only [linear_v49_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g161 linear_b64 7 93 linear_bf0112 linear_bf0387)
theorem linear_bf0389 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_2 280 := by
  simpa only [linear_v49_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g158 ++ linear_b63) (44 :: linear_v49_3) 179 101 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g158 linear_b63 9 170 linear_bf0110 linear_bf0386) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_3 100 (by decide +kernel) linear_bf0388))
theorem linear_bf0390 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_1 1314 := by
  simpa only [linear_v49_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g133 ++ linear_b51) (44 :: linear_v49_2) 1033 281 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g133 linear_b51 6 1027 linear_bf0096 linear_bf0385) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_2 280 (by decide +kernel) linear_bf0389))
theorem linear_bf0391 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v49_0 1331 := by
  simpa only [linear_v49_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g130 ++ linear_b50) (44 :: linear_v49_1) 16 1315 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g130 linear_b50 5 11 linear_bf0094 linear_bf0362) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v49_1 1314 (by decide +kernel) linear_bf0390))
theorem linear_bf0392 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b49 1333 := by
  simpa only [linear_b49] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g129 (linear_v49_0 ++ linear_g163) 1 1332 linear_bf0093 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v49_0 linear_g163 1331 1 linear_bf0391 linear_bf0114))
theorem linear_bf0393 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b66 11 := by
  simpa only [linear_b66] using linear_bf0117
theorem linear_bf0394 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b67 173 := by
  simpa only [linear_b67] using linear_bf0119
theorem linear_bf0395 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b68 170 := by
  simpa only [linear_b68] using linear_bf0121
theorem linear_bf0396 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b69 103 := by
  simpa only [linear_b69] using linear_bf0123
theorem linear_bf0397 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_3 110 := by
  simpa only [linear_v65_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g175 linear_b69 7 103 linear_bf0122 linear_bf0396)
theorem linear_bf0398 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_2 290 := by
  simpa only [linear_v65_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g172 ++ linear_b68) (44 :: linear_v65_3) 179 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g172 linear_b68 9 170 linear_bf0120 linear_bf0395) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_3 110 (by decide +kernel) linear_bf0397))
theorem linear_bf0399 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_1 470 := by
  simpa only [linear_v65_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g169 ++ linear_b67) (44 :: linear_v65_2) 179 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g169 linear_b67 6 173 linear_bf0118 linear_bf0394) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_2 290 (by decide +kernel) linear_bf0398))
theorem linear_bf0400 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v65_0 487 := by
  simpa only [linear_v65_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g166 ++ linear_b66) (44 :: linear_v65_1) 16 471 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g166 linear_b66 5 11 linear_bf0116 linear_bf0393) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v65_1 470 (by decide +kernel) linear_bf0399))
theorem linear_bf0401 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b65 489 := by
  simpa only [linear_b65] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g165 (linear_v65_0 ++ linear_g177) 1 488 linear_bf0115 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v65_0 linear_g177 487 1 linear_bf0400 linear_bf0124))
theorem linear_bf0402 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b71 11 := by
  simpa only [linear_b71] using linear_bf0127
theorem linear_bf0403 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b72 102 := by
  simpa only [linear_b72] using linear_bf0129
theorem linear_bf0404 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b73 202 := by
  simpa only [linear_b73] using linear_bf0131
theorem linear_bf0405 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b74 230 := by
  simpa only [linear_b74] using linear_bf0133
theorem linear_bf0406 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_3 237 := by
  simpa only [linear_v70_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g189 linear_b74 7 230 linear_bf0132 linear_bf0405)
theorem linear_bf0407 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_2 449 := by
  simpa only [linear_v70_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g186 ++ linear_b73) (44 :: linear_v70_3) 211 238 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g186 linear_b73 9 202 linear_bf0130 linear_bf0404) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_3 237 (by decide +kernel) linear_bf0406))
theorem linear_bf0408 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_1 558 := by
  simpa only [linear_v70_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g183 ++ linear_b72) (44 :: linear_v70_2) 108 450 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g183 linear_b72 6 102 linear_bf0128 linear_bf0403) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_2 449 (by decide +kernel) linear_bf0407))
theorem linear_bf0409 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v70_0 575 := by
  simpa only [linear_v70_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g180 ++ linear_b71) (44 :: linear_v70_1) 16 559 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g180 linear_b71 5 11 linear_bf0126 linear_bf0402) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v70_1 558 (by decide +kernel) linear_bf0408))
theorem linear_bf0410 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b70 577 := by
  simpa only [linear_b70] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g179 (linear_v70_0 ++ linear_g191) 1 576 linear_bf0125 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v70_0 linear_g191 575 1 linear_bf0409 linear_bf0134))
theorem linear_bf0411 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b76 11 := by
  simpa only [linear_b76] using linear_bf0137
theorem linear_bf0412 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b78 94 := by
  simpa only [linear_b78] using linear_bf0140
theorem linear_bf0413 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b79 99 := by
  simpa only [linear_b79] using linear_bf0141
theorem linear_bf0414 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b80 56 := by
  simpa only [linear_b80] using linear_bf0142
theorem linear_bf0415 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b81 100 := by
  simpa only [linear_b81] using linear_bf0143
theorem linear_bf0416 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b82 101 := by
  simpa only [linear_b82] using linear_bf0144
theorem linear_bf0417 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b83 86 := by
  simpa only [linear_b83] using linear_bf0145
theorem linear_bf0418 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b84 103 := by
  simpa only [linear_b84] using linear_bf0146
theorem linear_bf0419 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_6 103 := by
  simpa only [linear_v77_6] using linear_bf0418
theorem linear_bf0420 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_5 190 := by
  simpa only [linear_v77_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b83 (44 :: linear_v77_6) 86 104 linear_bf0417 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_6 103 (by decide +kernel) linear_bf0419))
theorem linear_bf0421 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_4 292 := by
  simpa only [linear_v77_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b82 (44 :: linear_v77_5) 101 191 linear_bf0416 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_5 190 (by decide +kernel) linear_bf0420))
theorem linear_bf0422 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_3 393 := by
  simpa only [linear_v77_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b81 (44 :: linear_v77_4) 100 293 linear_bf0415 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_4 292 (by decide +kernel) linear_bf0421))
theorem linear_bf0423 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_2 450 := by
  simpa only [linear_v77_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b80 (44 :: linear_v77_3) 56 394 linear_bf0414 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_3 393 (by decide +kernel) linear_bf0422))
theorem linear_bf0424 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_1 550 := by
  simpa only [linear_v77_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b79 (44 :: linear_v77_2) 99 451 linear_bf0413 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_2 450 (by decide +kernel) linear_bf0423))
theorem linear_bf0425 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v77_0 645 := by
  simpa only [linear_v77_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b78 (44 :: linear_v77_1) 94 551 linear_bf0412 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v77_1 550 (by decide +kernel) linear_bf0424))
theorem linear_bf0426 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b77 647 := by
  simpa only [linear_b77] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g198 (linear_v77_0 ++ linear_g212) 1 646 linear_bf0139 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v77_0 linear_g212 645 1 linear_bf0425 linear_bf0147))
theorem linear_bf0427 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b85 202 := by
  simpa only [linear_b85] using linear_bf0149
theorem linear_bf0428 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b86 103 := by
  simpa only [linear_b86] using linear_bf0151
theorem linear_bf0429 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_3 110 := by
  simpa only [linear_v75_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g217 linear_b86 7 103 linear_bf0150 linear_bf0428)
theorem linear_bf0430 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_2 322 := by
  simpa only [linear_v75_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g214 ++ linear_b85) (44 :: linear_v75_3) 211 111 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g214 linear_b85 9 202 linear_bf0148 linear_bf0427) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_3 110 (by decide +kernel) linear_bf0429))
theorem linear_bf0431 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_1 976 := by
  simpa only [linear_v75_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g197 ++ linear_b77) (44 :: linear_v75_2) 653 323 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g197 linear_b77 6 647 linear_bf0138 linear_bf0426) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_2 322 (by decide +kernel) linear_bf0430))
theorem linear_bf0432 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v75_0 993 := by
  simpa only [linear_v75_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g194 ++ linear_b76) (44 :: linear_v75_1) 16 977 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g194 linear_b76 5 11 linear_bf0136 linear_bf0411) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v75_1 976 (by decide +kernel) linear_bf0431))
theorem linear_bf0433 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b75 995 := by
  simpa only [linear_b75] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g193 (linear_v75_0 ++ linear_g219) 1 994 linear_bf0135 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v75_0 linear_g219 993 1 linear_bf0432 linear_bf0152))
theorem linear_bf0434 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b88 11 := by
  simpa only [linear_b88] using linear_bf0155
theorem linear_bf0435 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b89 155 := by
  simpa only [linear_b89] using linear_bf0157
theorem linear_bf0436 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b90 205 := by
  simpa only [linear_b90] using linear_bf0159
theorem linear_bf0437 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b91 34 := by
  simpa only [linear_b91] using linear_bf0161
theorem linear_bf0438 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_3 41 := by
  simpa only [linear_v87_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g231 linear_b91 7 34 linear_bf0160 linear_bf0437)
theorem linear_bf0439 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_2 256 := by
  simpa only [linear_v87_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g228 ++ linear_b90) (44 :: linear_v87_3) 214 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g228 linear_b90 9 205 linear_bf0158 linear_bf0436) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_3 41 (by decide +kernel) linear_bf0438))
theorem linear_bf0440 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_1 418 := by
  simpa only [linear_v87_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g225 ++ linear_b89) (44 :: linear_v87_2) 161 257 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g225 linear_b89 6 155 linear_bf0156 linear_bf0435) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_2 256 (by decide +kernel) linear_bf0439))
theorem linear_bf0441 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v87_0 435 := by
  simpa only [linear_v87_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g222 ++ linear_b88) (44 :: linear_v87_1) 16 419 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g222 linear_b88 5 11 linear_bf0154 linear_bf0434) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v87_1 418 (by decide +kernel) linear_bf0440))
theorem linear_bf0442 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b87 437 := by
  simpa only [linear_b87] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g221 (linear_v87_0 ++ linear_g233) 1 436 linear_bf0153 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v87_0 linear_g233 435 1 linear_bf0441 linear_bf0162))
theorem linear_bf0443 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b93 11 := by
  simpa only [linear_b93] using linear_bf0165
theorem linear_bf0444 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b94 105 := by
  simpa only [linear_b94] using linear_bf0167
theorem linear_bf0445 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b95 175 := by
  simpa only [linear_b95] using linear_bf0169
theorem linear_bf0446 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b96 221 := by
  simpa only [linear_b96] using linear_bf0171
theorem linear_bf0447 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_3 228 := by
  simpa only [linear_v92_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g245 linear_b96 7 221 linear_bf0170 linear_bf0446)
theorem linear_bf0448 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_2 413 := by
  simpa only [linear_v92_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g242 ++ linear_b95) (44 :: linear_v92_3) 184 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g242 linear_b95 9 175 linear_bf0168 linear_bf0445) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_3 228 (by decide +kernel) linear_bf0447))
theorem linear_bf0449 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_1 525 := by
  simpa only [linear_v92_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g239 ++ linear_b94) (44 :: linear_v92_2) 111 414 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g239 linear_b94 6 105 linear_bf0166 linear_bf0444) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_2 413 (by decide +kernel) linear_bf0448))
theorem linear_bf0450 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v92_0 542 := by
  simpa only [linear_v92_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g236 ++ linear_b93) (44 :: linear_v92_1) 16 526 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g236 linear_b93 5 11 linear_bf0164 linear_bf0443) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v92_1 525 (by decide +kernel) linear_bf0449))
theorem linear_bf0451 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b92 544 := by
  simpa only [linear_b92] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g235 (linear_v92_0 ++ linear_g247) 1 543 linear_bf0163 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v92_0 linear_g247 542 1 linear_bf0450 linear_bf0172))
theorem linear_bf0452 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b98 11 := by
  simpa only [linear_b98] using linear_bf0175
theorem linear_bf0453 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b100 102 := by
  simpa only [linear_b100] using linear_bf0178
theorem linear_bf0454 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b101 104 := by
  simpa only [linear_b101] using linear_bf0179
theorem linear_bf0455 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b102 101 := by
  simpa only [linear_b102] using linear_bf0180
theorem linear_bf0456 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b103 101 := by
  simpa only [linear_b103] using linear_bf0181
theorem linear_bf0457 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b104 103 := by
  simpa only [linear_b104] using linear_bf0182
theorem linear_bf0458 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b105 101 := by
  simpa only [linear_b105] using linear_bf0183
theorem linear_bf0459 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b106 94 := by
  simpa only [linear_b106] using linear_bf0184
theorem linear_bf0460 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b107 83 := by
  simpa only [linear_b107] using linear_bf0185
theorem linear_bf0461 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b108 57 := by
  simpa only [linear_b108] using linear_bf0186
theorem linear_bf0462 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b109 87 := by
  simpa only [linear_b109] using linear_bf0187
theorem linear_bf0463 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b110 109 := by
  simpa only [linear_b110] using linear_bf0188
theorem linear_bf0464 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_10 109 := by
  simpa only [linear_v99_10] using linear_bf0463
theorem linear_bf0465 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_9 197 := by
  simpa only [linear_v99_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b109 (44 :: linear_v99_10) 87 110 linear_bf0462 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_10 109 (by decide +kernel) linear_bf0464))
theorem linear_bf0466 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_8 255 := by
  simpa only [linear_v99_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b108 (44 :: linear_v99_9) 57 198 linear_bf0461 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_9 197 (by decide +kernel) linear_bf0465))
theorem linear_bf0467 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_7 339 := by
  simpa only [linear_v99_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b107 (44 :: linear_v99_8) 83 256 linear_bf0460 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_8 255 (by decide +kernel) linear_bf0466))
theorem linear_bf0468 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_6 434 := by
  simpa only [linear_v99_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b106 (44 :: linear_v99_7) 94 340 linear_bf0459 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_7 339 (by decide +kernel) linear_bf0467))
theorem linear_bf0469 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_5 536 := by
  simpa only [linear_v99_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b105 (44 :: linear_v99_6) 101 435 linear_bf0458 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_6 434 (by decide +kernel) linear_bf0468))
theorem linear_bf0470 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_4 640 := by
  simpa only [linear_v99_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b104 (44 :: linear_v99_5) 103 537 linear_bf0457 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_5 536 (by decide +kernel) linear_bf0469))
theorem linear_bf0471 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_3 742 := by
  simpa only [linear_v99_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b103 (44 :: linear_v99_4) 101 641 linear_bf0456 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_4 640 (by decide +kernel) linear_bf0470))
theorem linear_bf0472 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_2 844 := by
  simpa only [linear_v99_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b102 (44 :: linear_v99_3) 101 743 linear_bf0455 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_3 742 (by decide +kernel) linear_bf0471))
theorem linear_bf0473 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_1 949 := by
  simpa only [linear_v99_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b101 (44 :: linear_v99_2) 104 845 linear_bf0454 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_2 844 (by decide +kernel) linear_bf0472))
theorem linear_bf0474 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v99_0 1052 := by
  simpa only [linear_v99_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b100 (44 :: linear_v99_1) 102 950 linear_bf0453 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v99_1 949 (by decide +kernel) linear_bf0473))
theorem linear_bf0475 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b99 1054 := by
  simpa only [linear_b99] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g254 (linear_v99_0 ++ linear_g276) 1 1053 linear_bf0177 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v99_0 linear_g276 1052 1 linear_bf0474 linear_bf0189))
theorem linear_bf0476 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b111 175 := by
  simpa only [linear_b111] using linear_bf0191
theorem linear_bf0477 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b112 98 := by
  simpa only [linear_b112] using linear_bf0193
theorem linear_bf0478 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_3 105 := by
  simpa only [linear_v97_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g281 linear_b112 7 98 linear_bf0192 linear_bf0477)
theorem linear_bf0479 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_2 290 := by
  simpa only [linear_v97_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g278 ++ linear_b111) (44 :: linear_v97_3) 184 106 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g278 linear_b111 9 175 linear_bf0190 linear_bf0476) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_3 105 (by decide +kernel) linear_bf0478))
theorem linear_bf0480 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_1 1351 := by
  simpa only [linear_v97_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g253 ++ linear_b99) (44 :: linear_v97_2) 1060 291 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g253 linear_b99 6 1054 linear_bf0176 linear_bf0475) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_2 290 (by decide +kernel) linear_bf0479))
theorem linear_bf0481 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v97_0 1368 := by
  simpa only [linear_v97_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g250 ++ linear_b98) (44 :: linear_v97_1) 16 1352 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g250 linear_b98 5 11 linear_bf0174 linear_bf0452) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v97_1 1351 (by decide +kernel) linear_bf0480))
theorem linear_bf0482 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b97 1370 := by
  simpa only [linear_b97] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g249 (linear_v97_0 ++ linear_g283) 1 1369 linear_bf0173 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v97_0 linear_g283 1368 1 linear_bf0481 linear_bf0194))
theorem linear_bf0483 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b114 11 := by
  simpa only [linear_b114] using linear_bf0197
theorem linear_bf0484 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b115 175 := by
  simpa only [linear_b115] using linear_bf0199
theorem linear_bf0485 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b116 175 := by
  simpa only [linear_b116] using linear_bf0201
theorem linear_bf0486 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b117 109 := by
  simpa only [linear_b117] using linear_bf0203
theorem linear_bf0487 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_3 116 := by
  simpa only [linear_v113_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g295 linear_b117 7 109 linear_bf0202 linear_bf0486)
theorem linear_bf0488 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_2 301 := by
  simpa only [linear_v113_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g292 ++ linear_b116) (44 :: linear_v113_3) 184 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g292 linear_b116 9 175 linear_bf0200 linear_bf0485) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_3 116 (by decide +kernel) linear_bf0487))
theorem linear_bf0489 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_1 483 := by
  simpa only [linear_v113_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g289 ++ linear_b115) (44 :: linear_v113_2) 181 302 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g289 linear_b115 6 175 linear_bf0198 linear_bf0484) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_2 301 (by decide +kernel) linear_bf0488))
theorem linear_bf0490 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v113_0 500 := by
  simpa only [linear_v113_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g286 ++ linear_b114) (44 :: linear_v113_1) 16 484 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g286 linear_b114 5 11 linear_bf0196 linear_bf0483) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v113_1 483 (by decide +kernel) linear_bf0489))
theorem linear_bf0491 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b113 502 := by
  simpa only [linear_b113] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g285 (linear_v113_0 ++ linear_g297) 1 501 linear_bf0195 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v113_0 linear_g297 500 1 linear_bf0490 linear_bf0204))
theorem linear_bf0492 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b119 11 := by
  simpa only [linear_b119] using linear_bf0207
theorem linear_bf0493 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b120 105 := by
  simpa only [linear_b120] using linear_bf0209
theorem linear_bf0494 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b121 208 := by
  simpa only [linear_b121] using linear_bf0211
theorem linear_bf0495 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b122 243 := by
  simpa only [linear_b122] using linear_bf0213
theorem linear_bf0496 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_3 250 := by
  simpa only [linear_v118_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g309 linear_b122 7 243 linear_bf0212 linear_bf0495)
theorem linear_bf0497 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_2 468 := by
  simpa only [linear_v118_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g306 ++ linear_b121) (44 :: linear_v118_3) 217 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g306 linear_b121 9 208 linear_bf0210 linear_bf0494) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_3 250 (by decide +kernel) linear_bf0496))
theorem linear_bf0498 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_1 580 := by
  simpa only [linear_v118_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g303 ++ linear_b120) (44 :: linear_v118_2) 111 469 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g303 linear_b120 6 105 linear_bf0208 linear_bf0493) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_2 468 (by decide +kernel) linear_bf0497))
theorem linear_bf0499 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v118_0 597 := by
  simpa only [linear_v118_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g300 ++ linear_b119) (44 :: linear_v118_1) 16 581 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g300 linear_b119 5 11 linear_bf0206 linear_bf0492) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v118_1 580 (by decide +kernel) linear_bf0498))
theorem linear_bf0500 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b118 599 := by
  simpa only [linear_b118] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g299 (linear_v118_0 ++ linear_g311) 1 598 linear_bf0205 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v118_0 linear_g311 597 1 linear_bf0499 linear_bf0214))
theorem linear_bf0501 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b124 11 := by
  simpa only [linear_b124] using linear_bf0217
theorem linear_bf0502 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b126 96 := by
  simpa only [linear_b126] using linear_bf0220
theorem linear_bf0503 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b127 102 := by
  simpa only [linear_b127] using linear_bf0221
theorem linear_bf0504 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b128 57 := by
  simpa only [linear_b128] using linear_bf0222
theorem linear_bf0505 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b129 102 := by
  simpa only [linear_b129] using linear_bf0223
theorem linear_bf0506 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b130 107 := by
  simpa only [linear_b130] using linear_bf0224
theorem linear_bf0507 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b131 87 := by
  simpa only [linear_b131] using linear_bf0225
theorem linear_bf0508 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b132 109 := by
  simpa only [linear_b132] using linear_bf0226
theorem linear_bf0509 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_6 109 := by
  simpa only [linear_v125_6] using linear_bf0508
theorem linear_bf0510 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_5 197 := by
  simpa only [linear_v125_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b131 (44 :: linear_v125_6) 87 110 linear_bf0507 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_6 109 (by decide +kernel) linear_bf0509))
theorem linear_bf0511 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_4 305 := by
  simpa only [linear_v125_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b130 (44 :: linear_v125_5) 107 198 linear_bf0506 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_5 197 (by decide +kernel) linear_bf0510))
theorem linear_bf0512 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_3 408 := by
  simpa only [linear_v125_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b129 (44 :: linear_v125_4) 102 306 linear_bf0505 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_4 305 (by decide +kernel) linear_bf0511))
theorem linear_bf0513 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_2 466 := by
  simpa only [linear_v125_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b128 (44 :: linear_v125_3) 57 409 linear_bf0504 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_3 408 (by decide +kernel) linear_bf0512))
theorem linear_bf0514 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_1 569 := by
  simpa only [linear_v125_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b127 (44 :: linear_v125_2) 102 467 linear_bf0503 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_2 466 (by decide +kernel) linear_bf0513))
theorem linear_bf0515 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v125_0 666 := by
  simpa only [linear_v125_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b126 (44 :: linear_v125_1) 96 570 linear_bf0502 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v125_1 569 (by decide +kernel) linear_bf0514))
theorem linear_bf0516 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b125 668 := by
  simpa only [linear_b125] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g318 (linear_v125_0 ++ linear_g332) 1 667 linear_bf0219 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v125_0 linear_g332 666 1 linear_bf0515 linear_bf0227))
theorem linear_bf0517 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b133 208 := by
  simpa only [linear_b133] using linear_bf0229
theorem linear_bf0518 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b134 109 := by
  simpa only [linear_b134] using linear_bf0231
theorem linear_bf0519 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_3 116 := by
  simpa only [linear_v123_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g337 linear_b134 7 109 linear_bf0230 linear_bf0518)
theorem linear_bf0520 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_2 334 := by
  simpa only [linear_v123_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g334 ++ linear_b133) (44 :: linear_v123_3) 217 117 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g334 linear_b133 9 208 linear_bf0228 linear_bf0517) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_3 116 (by decide +kernel) linear_bf0519))
theorem linear_bf0521 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_1 1009 := by
  simpa only [linear_v123_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g317 ++ linear_b125) (44 :: linear_v123_2) 674 335 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g317 linear_b125 6 668 linear_bf0218 linear_bf0516) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_2 334 (by decide +kernel) linear_bf0520))
theorem linear_bf0522 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v123_0 1026 := by
  simpa only [linear_v123_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g314 ++ linear_b124) (44 :: linear_v123_1) 16 1010 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g314 linear_b124 5 11 linear_bf0216 linear_bf0501) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v123_1 1009 (by decide +kernel) linear_bf0521))
theorem linear_bf0523 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b123 1028 := by
  simpa only [linear_b123] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g313 (linear_v123_0 ++ linear_g339) 1 1027 linear_bf0215 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v123_0 linear_g339 1026 1 linear_bf0522 linear_bf0232))
theorem linear_bf0524 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b136 11 := by
  simpa only [linear_b136] using linear_bf0235
theorem linear_bf0525 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b137 156 := by
  simpa only [linear_b137] using linear_bf0237
theorem linear_bf0526 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b138 208 := by
  simpa only [linear_b138] using linear_bf0239
theorem linear_bf0527 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b139 34 := by
  simpa only [linear_b139] using linear_bf0241
theorem linear_bf0528 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_3 41 := by
  simpa only [linear_v135_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g351 linear_b139 7 34 linear_bf0240 linear_bf0527)
theorem linear_bf0529 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_2 259 := by
  simpa only [linear_v135_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g348 ++ linear_b138) (44 :: linear_v135_3) 217 42 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g348 linear_b138 9 208 linear_bf0238 linear_bf0526) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_3 41 (by decide +kernel) linear_bf0528))
theorem linear_bf0530 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_1 422 := by
  simpa only [linear_v135_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g345 ++ linear_b137) (44 :: linear_v135_2) 162 260 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g345 linear_b137 6 156 linear_bf0236 linear_bf0525) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_2 259 (by decide +kernel) linear_bf0529))
theorem linear_bf0531 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v135_0 439 := by
  simpa only [linear_v135_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g342 ++ linear_b136) (44 :: linear_v135_1) 16 423 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g342 linear_b136 5 11 linear_bf0234 linear_bf0524) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v135_1 422 (by decide +kernel) linear_bf0530))
theorem linear_bf0532 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b135 441 := by
  simpa only [linear_b135] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g341 (linear_v135_0 ++ linear_g353) 1 440 linear_bf0233 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v135_0 linear_g353 439 1 linear_bf0531 linear_bf0242))
theorem linear_bf0533 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b141 12 := by
  simpa only [linear_b141] using linear_bf0245
theorem linear_bf0534 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b142 209 := by
  simpa only [linear_b142] using linear_bf0247
theorem linear_bf0535 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b143 210 := by
  simpa only [linear_b143] using linear_bf0249
theorem linear_bf0536 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b144 221 := by
  simpa only [linear_b144] using linear_bf0251
theorem linear_bf0537 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_3 228 := by
  simpa only [linear_v140_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g365 linear_b144 7 221 linear_bf0250 linear_bf0536)
theorem linear_bf0538 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_2 448 := by
  simpa only [linear_v140_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g362 ++ linear_b143) (44 :: linear_v140_3) 219 229 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g362 linear_b143 9 210 linear_bf0248 linear_bf0535) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_3 228 (by decide +kernel) linear_bf0537))
theorem linear_bf0539 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_1 664 := by
  simpa only [linear_v140_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g359 ++ linear_b142) (44 :: linear_v140_2) 215 449 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g359 linear_b142 6 209 linear_bf0246 linear_bf0534) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_2 448 (by decide +kernel) linear_bf0538))
theorem linear_bf0540 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v140_0 682 := by
  simpa only [linear_v140_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g356 ++ linear_b141) (44 :: linear_v140_1) 17 665 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g356 linear_b141 5 12 linear_bf0244 linear_bf0533) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v140_1 664 (by decide +kernel) linear_bf0539))
theorem linear_bf0541 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b140 684 := by
  simpa only [linear_b140] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g355 (linear_v140_0 ++ linear_g367) 1 683 linear_bf0243 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v140_0 linear_g367 682 1 linear_bf0540 linear_bf0252))
theorem linear_bf0542 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b146 12 := by
  simpa only [linear_b146] using linear_bf0255
theorem linear_bf0543 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b147 209 := by
  simpa only [linear_b147] using linear_bf0257
theorem linear_bf0544 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b148 243 := by
  simpa only [linear_b148] using linear_bf0259
theorem linear_bf0545 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b149 243 := by
  simpa only [linear_b149] using linear_bf0261
theorem linear_bf0546 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_3 250 := by
  simpa only [linear_v145_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g379 linear_b149 7 243 linear_bf0260 linear_bf0545)
theorem linear_bf0547 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_2 503 := by
  simpa only [linear_v145_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g376 ++ linear_b148) (44 :: linear_v145_3) 252 251 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g376 linear_b148 9 243 linear_bf0258 linear_bf0544) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_3 250 (by decide +kernel) linear_bf0546))
theorem linear_bf0548 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_1 719 := by
  simpa only [linear_v145_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g373 ++ linear_b147) (44 :: linear_v145_2) 215 504 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g373 linear_b147 6 209 linear_bf0256 linear_bf0543) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_2 503 (by decide +kernel) linear_bf0547))
theorem linear_bf0549 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v145_0 737 := by
  simpa only [linear_v145_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g370 ++ linear_b146) (44 :: linear_v145_1) 17 720 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g370 linear_b146 5 12 linear_bf0254 linear_bf0542) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v145_1 719 (by decide +kernel) linear_bf0548))
theorem linear_bf0550 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b145 739 := by
  simpa only [linear_b145] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g369 (linear_v145_0 ++ linear_g381) 1 738 linear_bf0253 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v145_0 linear_g381 737 1 linear_bf0549 linear_bf0262))
theorem linear_bf0551 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_20 739 := by
  simpa only [linear_v4_20] using linear_bf0550
theorem linear_bf0552 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_19 1424 := by
  simpa only [linear_v4_19] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b140 (44 :: linear_v4_20) 684 740 linear_bf0541 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_20 739 (by decide +kernel) linear_bf0551))
theorem linear_bf0553 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_18 1866 := by
  simpa only [linear_v4_18] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b135 (44 :: linear_v4_19) 441 1425 linear_bf0532 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_19 1424 (by decide +kernel) linear_bf0552))
theorem linear_bf0554 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_17 2895 := by
  simpa only [linear_v4_17] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b123 (44 :: linear_v4_18) 1028 1867 linear_bf0523 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_18 1866 (by decide +kernel) linear_bf0553))
theorem linear_bf0555 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_16 3495 := by
  simpa only [linear_v4_16] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b118 (44 :: linear_v4_17) 599 2896 linear_bf0500 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_17 2895 (by decide +kernel) linear_bf0554))
theorem linear_bf0556 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_15 3998 := by
  simpa only [linear_v4_15] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b113 (44 :: linear_v4_16) 502 3496 linear_bf0491 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_16 3495 (by decide +kernel) linear_bf0555))
theorem linear_bf0557 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_14 5369 := by
  simpa only [linear_v4_14] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b97 (44 :: linear_v4_15) 1370 3999 linear_bf0482 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_15 3998 (by decide +kernel) linear_bf0556))
theorem linear_bf0558 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_13 5914 := by
  simpa only [linear_v4_13] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b92 (44 :: linear_v4_14) 544 5370 linear_bf0451 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_14 5369 (by decide +kernel) linear_bf0557))
theorem linear_bf0559 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_12 6352 := by
  simpa only [linear_v4_12] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b87 (44 :: linear_v4_13) 437 5915 linear_bf0442 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_13 5914 (by decide +kernel) linear_bf0558))
theorem linear_bf0560 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_11 7348 := by
  simpa only [linear_v4_11] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b75 (44 :: linear_v4_12) 995 6353 linear_bf0433 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_12 6352 (by decide +kernel) linear_bf0559))
theorem linear_bf0561 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_10 7926 := by
  simpa only [linear_v4_10] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b70 (44 :: linear_v4_11) 577 7349 linear_bf0410 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_11 7348 (by decide +kernel) linear_bf0560))
theorem linear_bf0562 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_9 8416 := by
  simpa only [linear_v4_9] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b65 (44 :: linear_v4_10) 489 7927 linear_bf0401 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_10 7926 (by decide +kernel) linear_bf0561))
theorem linear_bf0563 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_8 9750 := by
  simpa only [linear_v4_8] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b49 (44 :: linear_v4_9) 1333 8417 linear_bf0392 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_9 8416 (by decide +kernel) linear_bf0562))
theorem linear_bf0564 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_7 10276 := by
  simpa only [linear_v4_7] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b44 (44 :: linear_v4_8) 525 9751 linear_bf0361 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_8 9750 (by decide +kernel) linear_bf0563))
theorem linear_bf0565 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_6 10744 := by
  simpa only [linear_v4_6] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b39 (44 :: linear_v4_7) 467 10277 linear_bf0352 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_7 10276 (by decide +kernel) linear_bf0564))
theorem linear_bf0566 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_5 11381 := by
  simpa only [linear_v4_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b34 (44 :: linear_v4_6) 636 10745 linear_bf0343 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_6 10744 (by decide +kernel) linear_bf0565))
theorem linear_bf0567 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_4 11919 := by
  simpa only [linear_v4_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b29 (44 :: linear_v4_5) 537 11382 linear_bf0334 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_5 11381 (by decide +kernel) linear_bf0566))
theorem linear_bf0568 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_3 12504 := by
  simpa only [linear_v4_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b24 (44 :: linear_v4_4) 584 11920 linear_bf0325 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_4 11919 (by decide +kernel) linear_bf0567))
theorem linear_bf0569 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_2 13137 := by
  simpa only [linear_v4_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b15 (44 :: linear_v4_3) 632 12505 linear_bf0316 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_3 12504 (by decide +kernel) linear_bf0568))
theorem linear_bf0570 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_1 13656 := by
  simpa only [linear_v4_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b10 (44 :: linear_v4_2) 518 13138 linear_bf0299 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_2 13137 (by decide +kernel) linear_bf0569))
theorem linear_bf0571 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v4_0 14181 := by
  simpa only [linear_v4_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_b5 (44 :: linear_v4_1) 524 13657 linear_bf0290 (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v4_1 13656 (by decide +kernel) linear_bf0570))
theorem linear_bf0572 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b4 14183 := by
  simpa only [linear_b4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g8 (linear_v4_0 ++ linear_g382) 1 14182 linear_bf0007 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v4_0 linear_g382 14181 1 linear_bf0571 linear_bf0263))
theorem linear_bf0573 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b150 31 := by
  simpa only [linear_b150] using linear_bf0265
theorem linear_bf0574 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b151 13 := by
  simpa only [linear_b151] using linear_bf0267
theorem linear_bf0575 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b152 11 := by
  simpa only [linear_b152] using linear_bf0269
theorem linear_bf0576 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b153 61 := by
  simpa only [linear_b153] using linear_bf0271
theorem linear_bf0577 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b154 7 := by
  simpa only [linear_b154] using linear_bf0273
theorem linear_bf0578 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_5 17 := by
  simpa only [linear_v3_5] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g396 linear_b154 10 7 linear_bf0272 linear_bf0577)
theorem linear_bf0579 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_4 88 := by
  simpa only [linear_v3_4] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g393 ++ linear_b153) (44 :: linear_v3_5) 70 18 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g393 linear_b153 9 61 linear_bf0270 linear_bf0576) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_5 17 (by decide +kernel) linear_bf0578))
theorem linear_bf0580 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_3 107 := by
  simpa only [linear_v3_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g390 ++ linear_b152) (44 :: linear_v3_4) 18 89 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g390 linear_b152 7 11 linear_bf0268 linear_bf0575) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_4 88 (by decide +kernel) linear_bf0579))
theorem linear_bf0581 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_2 129 := by
  simpa only [linear_v3_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g387 ++ linear_b151) (44 :: linear_v3_3) 21 108 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g387 linear_b151 8 13 linear_bf0266 linear_bf0574) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_3 107 (by decide +kernel) linear_bf0580))
theorem linear_bf0582 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_1 171 := by
  simpa only [linear_v3_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g384 ++ linear_b150) (44 :: linear_v3_2) 41 130 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g384 linear_b150 10 31 linear_bf0264 linear_bf0573) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_2 129 (by decide +kernel) linear_bf0581))
theorem linear_bf0583 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v3_0 14364 := by
  simpa only [linear_v3_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g7 ++ linear_b4) (44 :: linear_v3_1) 14192 172 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g7 linear_b4 9 14183 linear_bf0006 linear_bf0572) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v3_1 171 (by decide +kernel) linear_bf0582))
theorem linear_bf0584 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b3 14366 := by
  simpa only [linear_b3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g6 (linear_v3_0 ++ linear_g398) 1 14365 linear_bf0005 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v3_0 linear_g398 14364 1 linear_bf0583 linear_bf0274))
theorem linear_bf0585 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v2_0 14366 := by
  simpa only [linear_v2_0] using linear_bf0584
theorem linear_bf0586 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b2 14368 := by
  simpa only [linear_b2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g5 (linear_v2_0 ++ linear_g399) 1 14367 linear_bf0004 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v2_0 linear_g399 14366 1 linear_bf0585 linear_bf0275))
theorem linear_bf0587 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b155 18 := by
  simpa only [linear_b155] using linear_bf0277
theorem linear_bf0588 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b156 22 := by
  simpa only [linear_b156] using linear_bf0279
theorem linear_bf0589 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_3 31 := by
  simpa only [linear_v0_3] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g404 linear_b156 9 22 linear_bf0278 linear_bf0588)
theorem linear_bf0590 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_2 59 := by
  simpa only [linear_v0_2] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g401 ++ linear_b155) (44 :: linear_v0_3) 27 32 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g401 linear_b155 9 18 linear_bf0276 linear_bf0587) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_3 31 (by decide +kernel) linear_bf0589))
theorem linear_bf0591 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_1 14440 := by
  simpa only [linear_v0_1] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g4 ++ linear_b2) (44 :: linear_v0_2) 14380 60 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g4 linear_b2 12 14368 linear_bf0003 linear_bf0586) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_2 59 (by decide +kernel) linear_bf0590))
theorem linear_bf0592 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_v0_0 14464 := by
  simpa only [linear_v0_0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append (linear_g1 ++ linear_b1) (44 :: linear_v0_1) 23 14441 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g1 linear_b1 10 13 linear_bf0001 linear_bf0281) (HiaCoreSyntaxSlice.ByteFactsResearch.cons 44 linear_v0_1 14440 (by decide +kernel) linear_bf0591))
theorem linear_bf0593 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linear_b0 14466 := by
  simpa only [linear_b0] using (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_g0 (linear_v0_0 ++ linear_g406) 1 14465 linear_bf0000 (HiaCoreSyntaxSlice.ByteFactsResearch.append linear_v0_0 linear_g406 14464 1 linear_bf0592 linear_bf0280))
theorem linear_bf0594 : HiaCoreSyntaxSlice.ByteFactsResearch.facts linearBytes 14466 := by
  simpa only [linearBytes] using linear_bf0593
theorem mutated_length : linearBytes.length ≤ transportByteLimit := by
  rw [(linear_bf0594).1]
  decide +kernel
theorem mutated_byte_range : linearBytes.all (fun byte => decide (byte ≤ 255)) = true := by exact (linear_bf0594).2
theorem mutated_transport : checkedEncode linearRaw = some linearBytes := checkedEncode_of_parts linearRaw linearBytes mutated_bounds mutated_serialized mutated_parsed mutated_length mutated_byte_range
end HiaCoreSyntaxSlice.LiteralTwo
namespace HiaCoreSyntaxSlice.WrongCondition
def linear_g0 : List Nat := [123]
def linear_g1 : List Nat := [34,101,120,112,111,114,116,115,34,58]
def linear_g2 : List Nat := [91,34,99,97,108,99,117,108,97,116,101,34,93]
def linear_g3 : List Nat := [44]
def linear_g4 : List Nat := [34,102,117,110,99,116,105,111,110,115,34,58]
def linear_g5 : List Nat := [91]
def linear_g6 : List Nat := [123]
def linear_g7 : List Nat := [34,98,108,111,99,107,115,34,58]
def linear_g8 : List Nat := [91]
def linear_g9 : List Nat := [123]
def linear_g10 : List Nat := [34,105,100,34,58]
def linear_g11 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g12 : List Nat := [44]
def linear_g13 : List Nat := [34,111,112,115,34,58]
def linear_g14 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,116,114,121,95,110,101,119,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125,93]
def linear_g15 : List Nat := [44]
def linear_g16 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g17 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g18 : List Nat := [44]
def linear_g19 : List Nat := [34,116,101,114,109,34,58]
def linear_g20 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,97,114,103,49,34,44,34,97,114,103,50,34,44,34,100,103,95,118,95,49,34,44,34,100,103,95,118,95,48,34,44,34,100,103,95,118,95,50,34,44,34,97,114,103,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,49,34,125,125]
def linear_g21 : List Nat := [125]
def linear_g22 : List Nat := [44]
def linear_g23 : List Nat := [123]
def linear_g24 : List Nat := [34,105,100,34,58]
def linear_g25 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,49,34]
def linear_g26 : List Nat := [44]
def linear_g27 : List Nat := [34,111,112,115,34,58]
def linear_g28 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g29 : List Nat := [44]
def linear_g30 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g31 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g32 : List Nat := [44]
def linear_g33 : List Nat := [34,116,101,114,109,34,58]
def linear_g34 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,52,34,44,34,100,103,95,118,95,56,34,44,34,100,103,95,118,95,51,34,44,34,100,103,95,118,95,57,34,44,34,100,103,95,118,95,49,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,51,34,125]
def linear_g35 : List Nat := [125]
def linear_g36 : List Nat := [44]
def linear_g37 : List Nat := [123]
def linear_g38 : List Nat := [34,105,100,34,58]
def linear_g39 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,50,34]
def linear_g40 : List Nat := [44]
def linear_g41 : List Nat := [34,111,112,115,34,58]
def linear_g42 : List Nat := [91]
def linear_g43 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125]
def linear_g44 : List Nat := [44]
def linear_g45 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,48,48,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g46 : List Nat := [44]
def linear_g47 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g48 : List Nat := [44]
def linear_g49 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,34,44,34,100,103,95,118,95,49,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g50 : List Nat := [93]
def linear_g51 : List Nat := [44]
def linear_g52 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g53 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g54 : List Nat := [44]
def linear_g55 : List Nat := [34,116,101,114,109,34,58]
def linear_g56 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,56,34,93,125]
def linear_g57 : List Nat := [125]
def linear_g58 : List Nat := [44]
def linear_g59 : List Nat := [123]
def linear_g60 : List Nat := [34,105,100,34,58]
def linear_g61 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,51,34]
def linear_g62 : List Nat := [44]
def linear_g63 : List Nat := [34,111,112,115,34,58]
def linear_g64 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,53,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g65 : List Nat := [44]
def linear_g66 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g67 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g68 : List Nat := [44]
def linear_g69 : List Nat := [34,116,101,114,109,34,58]
def linear_g70 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,50,53,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,48,34,44,34,100,103,95,118,95,50,49,34,44,34,100,103,95,118,95,50,50,34,44,34,100,103,95,118,95,50,51,34,44,34,100,103,95,118,95,50,52,34,44,34,100,103,95,118,95,50,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,48,34,125,125]
def linear_g71 : List Nat := [125]
def linear_g72 : List Nat := [44]
def linear_g73 : List Nat := [123]
def linear_g74 : List Nat := [34,105,100,34,58]
def linear_g75 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,52,34]
def linear_g76 : List Nat := [44]
def linear_g77 : List Nat := [34,111,112,115,34,58]
def linear_g78 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,50,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g79 : List Nat := [44]
def linear_g80 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g81 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,50,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g82 : List Nat := [44]
def linear_g83 : List Nat := [34,116,101,114,109,34,58]
def linear_g84 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,50,56,34,44,34,100,103,95,118,95,50,57,34,44,34,100,103,95,118,95,51,50,34,44,34,100,103,95,118,95,50,55,34,44,34,100,103,95,118,95,51,51,34,44,34,100,103,95,118,95,51,52,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,53,34,125]
def linear_g85 : List Nat := [125]
def linear_g86 : List Nat := [44]
def linear_g87 : List Nat := [123]
def linear_g88 : List Nat := [34,105,100,34,58]
def linear_g89 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,53,34]
def linear_g90 : List Nat := [44]
def linear_g91 : List Nat := [34,111,112,115,34,58]
def linear_g92 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,51,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,49,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g93 : List Nat := [44]
def linear_g94 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g95 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,51,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g96 : List Nat := [44]
def linear_g97 : List Nat := [34,116,101,114,109,34,58]
def linear_g98 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,52,49,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,104,97,114,101,100,95,54,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,51,53,34,44,34,100,103,95,118,95,51,54,34,44,34,100,103,95,118,95,51,55,34,44,34,100,103,95,118,95,51,56,34,44,34,100,103,95,118,95,51,57,34,44,34,100,103,95,118,95,52,48,34,44,34,100,103,95,118,95,52,50,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,103,117,97,114,100,95,49,34,125,125]
def linear_g99 : List Nat := [125]
def linear_g100 : List Nat := [44]
def linear_g101 : List Nat := [123]
def linear_g102 : List Nat := [34,105,100,34,58]
def linear_g103 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,54,34]
def linear_g104 : List Nat := [44]
def linear_g105 : List Nat := [34,111,112,115,34,58]
def linear_g106 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,52,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g107 : List Nat := [44]
def linear_g108 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g109 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,52,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,53,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g110 : List Nat := [44]
def linear_g111 : List Nat := [34,116,101,114,109,34,58]
def linear_g112 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,52,54,34,93,125]
def linear_g113 : List Nat := [125]
def linear_g114 : List Nat := [44]
def linear_g115 : List Nat := [123]
def linear_g116 : List Nat := [34,105,100,34,58]
def linear_g117 : List Nat := [34,100,103,95,102,97,115,116,95,48,34]
def linear_g118 : List Nat := [44]
def linear_g119 : List Nat := [34,111,112,115,34,58]
def linear_g120 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,53,34,44,34,100,103,95,118,95,53,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,54,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,111,108,46,110,111,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,115,121,110,116,97,120,95,119,114,111,110,103,95,99,111,110,100,105,116,105,111,110,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g121 : List Nat := [44]
def linear_g122 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g123 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g124 : List Nat := [44]
def linear_g125 : List Nat := [34,116,101,114,109,34,58]
def linear_g126 : List Nat := [123,34,99,111,110,100,34,58,34,115,121,110,116,97,120,95,119,114,111,110,103,95,99,111,110,100,105,116,105,111,110,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,49,34,44,34,100,103,95,118,95,53,50,34,44,34,100,103,95,118,95,53,51,34,44,34,100,103,95,118,95,53,52,34,44,34,100,103,95,118,95,53,53,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g127 : List Nat := [125]
def linear_g128 : List Nat := [44]
def linear_g129 : List Nat := [123]
def linear_g130 : List Nat := [34,105,100,34,58]
def linear_g131 : List Nat := [34,100,103,95,102,97,115,116,95,49,34]
def linear_g132 : List Nat := [44]
def linear_g133 : List Nat := [34,111,112,115,34,58]
def linear_g134 : List Nat := [91]
def linear_g135 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g136 : List Nat := [44]
def linear_g137 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,50,34,44,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,51,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g138 : List Nat := [44]
def linear_g139 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,52,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g140 : List Nat := [44]
def linear_g141 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,56,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g142 : List Nat := [44]
def linear_g143 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,52,34,44,34,100,103,95,118,95,54,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,54,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g144 : List Nat := [44]
def linear_g145 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,54,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g146 : List Nat := [44]
def linear_g147 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,56,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g148 : List Nat := [44]
def linear_g149 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,44,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g150 : List Nat := [44]
def linear_g151 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g152 : List Nat := [44]
def linear_g153 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g154 : List Nat := [44]
def linear_g155 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,54,49,34,44,34,100,103,95,118,95,54,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g156 : List Nat := [93]
def linear_g157 : List Nat := [44]
def linear_g158 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g159 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g160 : List Nat := [44]
def linear_g161 : List Nat := [34,116,101,114,109,34,58]
def linear_g162 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,53,55,34,44,34,100,103,95,118,95,53,56,34,44,34,100,103,95,118,95,53,57,34,44,34,100,103,95,118,95,54,48,34,44,34,100,103,95,118,95,55,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,48,34,125]
def linear_g163 : List Nat := [125]
def linear_g164 : List Nat := [44]
def linear_g165 : List Nat := [123]
def linear_g166 : List Nat := [34,105,100,34,58]
def linear_g167 : List Nat := [34,100,103,95,102,97,115,116,95,50,34]
def linear_g168 : List Nat := [44]
def linear_g169 : List Nat := [34,111,112,115,34,58]
def linear_g170 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g171 : List Nat := [44]
def linear_g172 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g173 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g174 : List Nat := [44]
def linear_g175 : List Nat := [34,116,101,114,109,34,58]
def linear_g176 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,50,34,44,34,100,103,95,118,95,55,51,34,44,34,100,103,95,118,95,55,54,34,44,34,100,103,95,118,95,55,49,34,44,34,100,103,95,118,95,55,55,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g177 : List Nat := [125]
def linear_g178 : List Nat := [44]
def linear_g179 : List Nat := [123]
def linear_g180 : List Nat := [34,105,100,34,58]
def linear_g181 : List Nat := [34,100,103,95,102,97,115,116,95,51,34]
def linear_g182 : List Nat := [44]
def linear_g183 : List Nat := [34,111,112,115,34,58]
def linear_g184 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,51,34,44,34,100,103,95,118,95,56,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g185 : List Nat := [44]
def linear_g186 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g187 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,55,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g188 : List Nat := [44]
def linear_g189 : List Nat := [34,116,101,114,109,34,58]
def linear_g190 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,56,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,55,56,34,44,34,100,103,95,118,95,55,57,34,44,34,100,103,95,118,95,56,48,34,44,34,100,103,95,118,95,56,49,34,44,34,100,103,95,118,95,56,50,34,44,34,100,103,95,118,95,56,51,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g191 : List Nat := [125]
def linear_g192 : List Nat := [44]
def linear_g193 : List Nat := [123]
def linear_g194 : List Nat := [34,105,100,34,58]
def linear_g195 : List Nat := [34,100,103,95,102,97,115,116,95,52,34]
def linear_g196 : List Nat := [44]
def linear_g197 : List Nat := [34,111,112,115,34,58]
def linear_g198 : List Nat := [91]
def linear_g199 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,49,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g200 : List Nat := [44]
def linear_g201 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,44,34,100,103,95,118,95,57,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,50,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g202 : List Nat := [44]
def linear_g203 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g204 : List Nat := [44]
def linear_g205 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,50,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g206 : List Nat := [44]
def linear_g207 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,56,34,44,34,100,103,95,118,95,57,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g208 : List Nat := [44]
def linear_g209 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g210 : List Nat := [44]
def linear_g211 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,48,34,44,34,100,103,95,118,95,57,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g212 : List Nat := [93]
def linear_g213 : List Nat := [44]
def linear_g214 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g215 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,56,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g216 : List Nat := [44]
def linear_g217 : List Nat := [34,116,101,114,109,34,58]
def linear_g218 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,56,53,34,44,34,100,103,95,118,95,56,54,34,44,34,100,103,95,118,95,56,55,34,44,34,100,103,95,118,95,57,52,34,44,34,100,103,95,118,95,56,57,34,44,34,100,103,95,118,95,57,54,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,51,34,125]
def linear_g219 : List Nat := [125]
def linear_g220 : List Nat := [44]
def linear_g221 : List Nat := [123]
def linear_g222 : List Nat := [34,105,100,34,58]
def linear_g223 : List Nat := [34,100,103,95,102,97,115,116,95,53,34]
def linear_g224 : List Nat := [44]
def linear_g225 : List Nat := [34,111,112,115,34,58]
def linear_g226 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,57,57,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g227 : List Nat := [44]
def linear_g228 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g229 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,57,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,48,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g230 : List Nat := [44]
def linear_g231 : List Nat := [34,116,101,114,109,34,58]
def linear_g232 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,48,48,34,93,125]
def linear_g233 : List Nat := [125]
def linear_g234 : List Nat := [44]
def linear_g235 : List Nat := [123]
def linear_g236 : List Nat := [34,105,100,34,58]
def linear_g237 : List Nat := [34,100,103,95,115,108,111,119,95,48,34]
def linear_g238 : List Nat := [44]
def linear_g239 : List Nat := [34,111,112,115,34,58]
def linear_g240 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,56,34,44,34,100,103,95,118,95,49,48,55,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,57,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g241 : List Nat := [44]
def linear_g242 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g243 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,48,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g244 : List Nat := [44]
def linear_g245 : List Nat := [34,116,101,114,109,34,58]
def linear_g246 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,48,57,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,50,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,48,52,34,44,34,100,103,95,118,95,49,48,53,34,44,34,100,103,95,118,95,49,48,54,34,44,34,100,103,95,118,95,49,48,55,34,44,34,100,103,95,118,95,49,48,56,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,125]
def linear_g247 : List Nat := [125]
def linear_g248 : List Nat := [44]
def linear_g249 : List Nat := [123]
def linear_g250 : List Nat := [34,105,100,34,58]
def linear_g251 : List Nat := [34,100,103,95,115,108,111,119,95,49,34]
def linear_g252 : List Nat := [44]
def linear_g253 : List Nat := [34,111,112,115,34,58]
def linear_g254 : List Nat := [91]
def linear_g255 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g256 : List Nat := [44]
def linear_g257 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,53,34,44,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93,125]
def linear_g258 : List Nat := [44]
def linear_g259 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,55,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g260 : List Nat := [44]
def linear_g261 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,49,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,56,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g262 : List Nat := [44]
def linear_g263 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,55,34,44,34,100,103,95,118,95,49,49,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,119,114,97,112,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,57,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g264 : List Nat := [44]
def linear_g265 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,57,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,48,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g266 : List Nat := [44]
def linear_g267 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,109,117,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,49,34,44,34,116,121,112,101,34,58,34,109,117,116,98,117,102,34,125,93,125]
def linear_g268 : List Nat := [44]
def linear_g269 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,44,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,115,116,111,114,101,34,44,34,111,117,116,34,58,91,93,125]
def linear_g270 : List Nat := [44]
def linear_g271 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,49,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g272 : List Nat := [44]
def linear_g273 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g274 : List Nat := [44]
def linear_g275 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,52,34,44,34,100,103,95,118,95,49,50,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g276 : List Nat := [93]
def linear_g277 : List Nat := [44]
def linear_g278 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g279 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,49,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g280 : List Nat := [44]
def linear_g281 : List Nat := [34,116,101,114,109,34,58]
def linear_g282 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,49,48,34,44,34,100,103,95,118,95,49,49,49,34,44,34,100,103,95,118,95,49,49,50,34,44,34,100,103,95,118,95,49,49,51,34,44,34,100,103,95,118,95,49,50,51,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,48,34,125]
def linear_g283 : List Nat := [125]
def linear_g284 : List Nat := [44]
def linear_g285 : List Nat := [123]
def linear_g286 : List Nat := [34,105,100,34,58]
def linear_g287 : List Nat := [34,100,103,95,115,108,111,119,95,50,34]
def linear_g288 : List Nat := [44]
def linear_g289 : List Nat := [34,111,112,115,34,58]
def linear_g290 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,57,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125,44,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,48,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,93]
def linear_g291 : List Nat := [44]
def linear_g292 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g293 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,53,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,50,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g294 : List Nat := [44]
def linear_g295 : List Nat := [34,116,101,114,109,34,58]
def linear_g296 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,50,53,34,44,34,100,103,95,118,95,49,50,54,34,44,34,100,103,95,118,95,49,50,57,34,44,34,100,103,95,118,95,49,50,52,34,44,34,100,103,95,118,95,49,51,48,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g297 : List Nat := [125]
def linear_g298 : List Nat := [44]
def linear_g299 : List Nat := [123]
def linear_g300 : List Nat := [34,105,100,34,58]
def linear_g301 : List Nat := [34,100,103,95,115,108,111,119,95,51,34]
def linear_g302 : List Nat := [44]
def linear_g303 : List Nat := [34,111,112,115,34,58]
def linear_g304 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,54,34,44,34,100,103,95,118,95,49,51,53,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,55,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g305 : List Nat := [44]
def linear_g306 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g307 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,51,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,52,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,54,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g308 : List Nat := [44]
def linear_g309 : List Nat := [34,116,101,114,109,34,58]
def linear_g310 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,51,55,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,53,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,49,34,44,34,100,103,95,118,95,49,51,50,34,44,34,100,103,95,118,95,49,51,51,34,44,34,100,103,95,118,95,49,51,52,34,44,34,100,103,95,118,95,49,51,53,34,44,34,100,103,95,118,95,49,51,54,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,125]
def linear_g311 : List Nat := [125]
def linear_g312 : List Nat := [44]
def linear_g313 : List Nat := [123]
def linear_g314 : List Nat := [34,105,100,34,58]
def linear_g315 : List Nat := [34,100,103,95,115,108,111,119,95,52,34]
def linear_g316 : List Nat := [44]
def linear_g317 : List Nat := [34,111,112,115,34,58]
def linear_g318 : List Nat := [91]
def linear_g319 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,48,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,111,114,114,111,119,46,114,101,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,52,34,44,34,116,121,112,101,34,58,34,114,101,97,100,98,117,102,34,125,93,125]
def linear_g320 : List Nat := [44]
def linear_g321 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,44,34,100,103,95,118,95,49,52,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,98,117,102,102,101,114,46,108,111,97,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,53,34,44,34,116,121,112,101,34,58,34,117,56,34,125,93,125]
def linear_g322 : List Nat := [44]
def linear_g323 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,52,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,108,111,97,110,46,101,110,100,34,44,34,111,117,116,34,58,91,93,125]
def linear_g324 : List Nat := [44]
def linear_g325 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,53,34,93,44,34,97,116,116,114,115,34,58,123,34,109,111,100,101,34,58,34,119,114,97,112,34,125,44,34,111,112,34,58,34,105,110,116,46,99,97,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,54,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g326 : List Nat := [44]
def linear_g327 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,49,34,44,34,100,103,95,118,95,49,52,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,55,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,93,125]
def linear_g328 : List Nat := [44]
def linear_g329 : List Nat := [123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,49,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g330 : List Nat := [44]
def linear_g331 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,52,51,34,44,34,100,103,95,118,95,49,52,56,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,105,110,116,46,97,100,100,46,99,104,101,99,107,101,100,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125]
def linear_g332 : List Nat := [93]
def linear_g333 : List Nat := [44]
def linear_g334 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g335 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,56,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,51,57,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,48,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,49,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,52,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g336 : List Nat := [44]
def linear_g337 : List Nat := [34,116,101,114,109,34,58]
def linear_g338 : List Nat := [123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,51,56,34,44,34,100,103,95,118,95,49,51,57,34,44,34,100,103,95,118,95,49,52,48,34,44,34,100,103,95,118,95,49,52,55,34,44,34,100,103,95,118,95,49,52,50,34,44,34,100,103,95,118,95,49,52,57,34,93,44,34,111,112,34,58,34,106,117,109,112,34,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,51,34,125]
def linear_g339 : List Nat := [125]
def linear_g340 : List Nat := [44]
def linear_g341 : List Nat := [123]
def linear_g342 : List Nat := [34,105,100,34,58]
def linear_g343 : List Nat := [34,100,103,95,115,108,111,119,95,53,34]
def linear_g344 : List Nat := [44]
def linear_g345 : List Nat := [34,111,112,115,34,58]
def linear_g346 : List Nat := [91,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,109,111,118,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,54,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,54,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,111,119,110,101,114,46,100,114,111,112,34,44,34,111,117,116,34,58,91,93,125,93]
def linear_g347 : List Nat := [44]
def linear_g348 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g349 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,49,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,50,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,51,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,52,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g350 : List Nat := [44]
def linear_g351 : List Nat := [34,116,101,114,109,34,58]
def linear_g352 : List Nat := [123,34,111,112,34,58,34,114,101,116,34,44,34,118,97,108,117,101,115,34,58,91,34,100,103,95,118,95,49,53,51,34,93,125]
def linear_g353 : List Nat := [125]
def linear_g354 : List Nat := [44]
def linear_g355 : List Nat := [123]
def linear_g356 : List Nat := [34,105,100,34,58]
def linear_g357 : List Nat := [34,100,103,95,103,117,97,114,100,95,48,34]
def linear_g358 : List Nat := [44]
def linear_g359 : List Nat := [34,111,112,115,34,58]
def linear_g360 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,51,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,50,34,44,34,100,103,95,118,95,49,54,51,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,52,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g361 : List Nat := [44]
def linear_g362 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g363 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,55,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,56,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,53,57,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g364 : List Nat := [44]
def linear_g365 : List Nat := [34,116,101,114,109,34,58]
def linear_g366 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,54,52,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,49,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,53,55,34,44,34,100,103,95,118,95,49,53,56,34,44,34,100,103,95,118,95,49,53,57,34,44,34,100,103,95,118,95,49,54,48,34,44,34,100,103,95,118,95,49,54,49,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,49,34,125,125]
def linear_g367 : List Nat := [125]
def linear_g368 : List Nat := [44]
def linear_g369 : List Nat := [123]
def linear_g370 : List Nat := [34,105,100,34,58]
def linear_g371 : List Nat := [34,100,103,95,103,117,97,114,100,95,49,34]
def linear_g372 : List Nat := [44]
def linear_g373 : List Nat := [34,111,112,115,34,58]
def linear_g374 : List Nat := [91,123,34,97,114,103,115,34,58,91,93,44,34,97,116,116,114,115,34,58,123,34,118,97,108,117,101,34,58,55,50,51,52,48,49,55,50,56,51,56,48,55,54,54,55,51,125,44,34,111,112,34,58,34,99,111,110,115,116,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,50,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93,125,44,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,55,49,34,44,34,100,103,95,118,95,49,55,50,34,93,44,34,97,116,116,114,115,34,58,123,125,44,34,111,112,34,58,34,99,111,109,112,97,114,101,46,108,101,34,44,34,111,117,116,34,58,91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,51,34,44,34,116,121,112,101,34,58,34,98,111,111,108,34,125,93,125,93]
def linear_g375 : List Nat := [44]
def linear_g376 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g377 : List Nat := [91,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,53,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,54,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,55,34,44,34,116,121,112,101,34,58,34,98,117,102,102,101,114,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,56,34,44,34,116,121,112,101,34,58,34,117,54,52,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,54,57,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,48,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,100,103,95,118,95,49,55,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,93]
def linear_g378 : List Nat := [44]
def linear_g379 : List Nat := [34,116,101,114,109,34,58]
def linear_g380 : List Nat := [123,34,99,111,110,100,34,58,34,100,103,95,118,95,49,55,51,34,44,34,101,108,115,101,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,115,108,111,119,95,52,34,125,44,34,111,112,34,58,34,98,114,97,110,99,104,34,44,34,116,104,101,110,34,58,123,34,97,114,103,115,34,58,91,34,100,103,95,118,95,49,54,53,34,44,34,100,103,95,118,95,49,54,54,34,44,34,100,103,95,118,95,49,54,55,34,44,34,100,103,95,118,95,49,54,56,34,44,34,100,103,95,118,95,49,54,57,34,44,34,100,103,95,118,95,49,55,48,34,93,44,34,116,97,114,103,101,116,34,58,34,100,103,95,102,97,115,116,95,52,34,125,125]
def linear_g381 : List Nat := [125]
def linear_g382 : List Nat := [93]
def linear_g383 : List Nat := [44]
def linear_g384 : List Nat := [34,101,102,102,101,99,116,115,34,58]
def linear_g385 : List Nat := [91,34,97,108,108,111,99,34,44,34,114,101,97,100,34,44,34,116,114,97,112,34,44,34,119,114,105,116,101,34,93]
def linear_g386 : List Nat := [44]
def linear_g387 : List Nat := [34,101,110,116,114,121,34,58]
def linear_g388 : List Nat := [34,100,103,95,115,104,97,114,101,100,95,48,34]
def linear_g389 : List Nat := [44]
def linear_g390 : List Nat := [34,110,97,109,101,34,58]
def linear_g391 : List Nat := [34,99,97,108,99,117,108,97,116,101,34]
def linear_g392 : List Nat := [44]
def linear_g393 : List Nat := [34,112,97,114,97,109,115,34,58]
def linear_g394 : List Nat := [91,123,34,110,97,109,101,34,58,34,97,114,103,49,34,44,34,116,121,112,101,34,58,34,117,115,105,122,101,34,125,44,123,34,110,97,109,101,34,58,34,97,114,103,50,34,44,34,116,121,112,101,34,58,34,117,51,50,34,125,93]
def linear_g395 : List Nat := [44]
def linear_g396 : List Nat := [34,114,101,116,117,114,110,115,34,58]
def linear_g397 : List Nat := [91,34,117,54,52,34,93]
def linear_g398 : List Nat := [125]
def linear_g399 : List Nat := [93]
def linear_g400 : List Nat := [44]
def linear_g401 : List Nat := [34,109,111,100,117,108,101,34,58]
def linear_g402 : List Nat := [34,114,101,100,117,99,116,105,111,110,95,108,105,110,101,97,114,34]
def linear_g403 : List Nat := [44]
def linear_g404 : List Nat := [34,115,99,104,101,109,97,34,58]
def linear_g405 : List Nat := [34,104,101,112,116,97,46,104,105,97,46,112,114,111,103,114,97,109,46,118,49,34]
def linear_g406 : List Nat := [125]
def linear_t407 : List Nat := []
def linear_t406 : List Nat := linear_g406 ++ linear_t407
def linear_t405 : List Nat := linear_g405 ++ linear_t406
def linear_t404 : List Nat := linear_g404 ++ linear_t405
def linear_t403 : List Nat := linear_g403 ++ linear_t404
def linear_t402 : List Nat := linear_g402 ++ linear_t403
def linear_t401 : List Nat := linear_g401 ++ linear_t402
def linear_t400 : List Nat := linear_g400 ++ linear_t401
def linear_t399 : List Nat := linear_g399 ++ linear_t400
def linear_t398 : List Nat := linear_g398 ++ linear_t399
def linear_t397 : List Nat := linear_g397 ++ linear_t398
def linear_t396 : List Nat := linear_g396 ++ linear_t397
def linear_t395 : List Nat := linear_g395 ++ linear_t396
def linear_t394 : List Nat := linear_g394 ++ linear_t395
def linear_t393 : List Nat := linear_g393 ++ linear_t394
def linear_t392 : List Nat := linear_g392 ++ linear_t393
def linear_t391 : List Nat := linear_g391 ++ linear_t392
def linear_t390 : List Nat := linear_g390 ++ linear_t391
def linear_t389 : List Nat := linear_g389 ++ linear_t390
def linear_t388 : List Nat := linear_g388 ++ linear_t389
def linear_t387 : List Nat := linear_g387 ++ linear_t388
def linear_t386 : List Nat := linear_g386 ++ linear_t387
def linear_t385 : List Nat := linear_g385 ++ linear_t386
def linear_t384 : List Nat := linear_g384 ++ linear_t385
def linear_t383 : List Nat := linear_g383 ++ linear_t384
def linear_t382 : List Nat := linear_g382 ++ linear_t383
def linear_t381 : List Nat := linear_g381 ++ linear_t382
def linear_t380 : List Nat := linear_g380 ++ linear_t381
def linear_t379 : List Nat := linear_g379 ++ linear_t380
def linear_t378 : List Nat := linear_g378 ++ linear_t379
def linear_t377 : List Nat := linear_g377 ++ linear_t378
def linear_t376 : List Nat := linear_g376 ++ linear_t377
def linear_t375 : List Nat := linear_g375 ++ linear_t376
def linear_t374 : List Nat := linear_g374 ++ linear_t375
def linear_t373 : List Nat := linear_g373 ++ linear_t374
def linear_t372 : List Nat := linear_g372 ++ linear_t373
def linear_t371 : List Nat := linear_g371 ++ linear_t372
def linear_t370 : List Nat := linear_g370 ++ linear_t371
def linear_t369 : List Nat := linear_g369 ++ linear_t370
def linear_t368 : List Nat := linear_g368 ++ linear_t369
def linear_t367 : List Nat := linear_g367 ++ linear_t368
def linear_t366 : List Nat := linear_g366 ++ linear_t367
def linear_t365 : List Nat := linear_g365 ++ linear_t366
def linear_t364 : List Nat := linear_g364 ++ linear_t365
def linear_t363 : List Nat := linear_g363 ++ linear_t364
def linear_t362 : List Nat := linear_g362 ++ linear_t363
def linear_t361 : List Nat := linear_g361 ++ linear_t362
def linear_t360 : List Nat := linear_g360 ++ linear_t361
def linear_t359 : List Nat := linear_g359 ++ linear_t360
def linear_t358 : List Nat := linear_g358 ++ linear_t359
def linear_t357 : List Nat := linear_g357 ++ linear_t358
def linear_t356 : List Nat := linear_g356 ++ linear_t357
def linear_t355 : List Nat := linear_g355 ++ linear_t356
def linear_t354 : List Nat := linear_g354 ++ linear_t355
def linear_t353 : List Nat := linear_g353 ++ linear_t354
def linear_t352 : List Nat := linear_g352 ++ linear_t353
def linear_t351 : List Nat := linear_g351 ++ linear_t352
def linear_t350 : List Nat := linear_g350 ++ linear_t351
def linear_t349 : List Nat := linear_g349 ++ linear_t350
def linear_t348 : List Nat := linear_g348 ++ linear_t349
def linear_t347 : List Nat := linear_g347 ++ linear_t348
def linear_t346 : List Nat := linear_g346 ++ linear_t347
def linear_t345 : List Nat := linear_g345 ++ linear_t346
def linear_t344 : List Nat := linear_g344 ++ linear_t345
def linear_t343 : List Nat := linear_g343 ++ linear_t344
def linear_t342 : List Nat := linear_g342 ++ linear_t343
def linear_t341 : List Nat := linear_g341 ++ linear_t342
def linear_t340 : List Nat := linear_g340 ++ linear_t341
def linear_t339 : List Nat := linear_g339 ++ linear_t340
def linear_t338 : List Nat := linear_g338 ++ linear_t339
def linear_t337 : List Nat := linear_g337 ++ linear_t338
def linear_t336 : List Nat := linear_g336 ++ linear_t337
def linear_t335 : List Nat := linear_g335 ++ linear_t336
def linear_t334 : List Nat := linear_g334 ++ linear_t335
def linear_t333 : List Nat := linear_g333 ++ linear_t334
def linear_t332 : List Nat := linear_g332 ++ linear_t333
def linear_t331 : List Nat := linear_g331 ++ linear_t332
def linear_t330 : List Nat := linear_g330 ++ linear_t331
def linear_t329 : List Nat := linear_g329 ++ linear_t330
def linear_t328 : List Nat := linear_g328 ++ linear_t329
def linear_t327 : List Nat := linear_g327 ++ linear_t328
def linear_t326 : List Nat := linear_g326 ++ linear_t327
def linear_t325 : List Nat := linear_g325 ++ linear_t326
def linear_t324 : List Nat := linear_g324 ++ linear_t325
def linear_t323 : List Nat := linear_g323 ++ linear_t324
def linear_t322 : List Nat := linear_g322 ++ linear_t323
def linear_t321 : List Nat := linear_g321 ++ linear_t322
def linear_t320 : List Nat := linear_g320 ++ linear_t321
def linear_t319 : List Nat := linear_g319 ++ linear_t320
def linear_t318 : List Nat := linear_g318 ++ linear_t319
def linear_t317 : List Nat := linear_g317 ++ linear_t318
def linear_t316 : List Nat := linear_g316 ++ linear_t317
def linear_t315 : List Nat := linear_g315 ++ linear_t316
def linear_t314 : List Nat := linear_g314 ++ linear_t315
def linear_t313 : List Nat := linear_g313 ++ linear_t314
def linear_t312 : List Nat := linear_g312 ++ linear_t313
def linear_t311 : List Nat := linear_g311 ++ linear_t312
def linear_t310 : List Nat := linear_g310 ++ linear_t311
def linear_t309 : List Nat := linear_g309 ++ linear_t310
def linear_t308 : List Nat := linear_g308 ++ linear_t309
def linear_t307 : List Nat := linear_g307 ++ linear_t308
def linear_t306 : List Nat := linear_g306 ++ linear_t307
def linear_t305 : List Nat := linear_g305 ++ linear_t306
def linear_t304 : List Nat := linear_g304 ++ linear_t305
def linear_t303 : List Nat := linear_g303 ++ linear_t304
def linear_t302 : List Nat := linear_g302 ++ linear_t303
def linear_t301 : List Nat := linear_g301 ++ linear_t302
def linear_t300 : List Nat := linear_g300 ++ linear_t301
def linear_t299 : List Nat := linear_g299 ++ linear_t300
def linear_t298 : List Nat := linear_g298 ++ linear_t299
def linear_t297 : List Nat := linear_g297 ++ linear_t298
def linear_t296 : List Nat := linear_g296 ++ linear_t297
def linear_t295 : List Nat := linear_g295 ++ linear_t296
def linear_t294 : List Nat := linear_g294 ++ linear_t295
def linear_t293 : List Nat := linear_g293 ++ linear_t294
def linear_t292 : List Nat := linear_g292 ++ linear_t293
def linear_t291 : List Nat := linear_g291 ++ linear_t292
def linear_t290 : List Nat := linear_g290 ++ linear_t291
def linear_t289 : List Nat := linear_g289 ++ linear_t290
def linear_t288 : List Nat := linear_g288 ++ linear_t289
def linear_t287 : List Nat := linear_g287 ++ linear_t288
def linear_t286 : List Nat := linear_g286 ++ linear_t287
def linear_t285 : List Nat := linear_g285 ++ linear_t286
def linear_t284 : List Nat := linear_g284 ++ linear_t285
def linear_t283 : List Nat := linear_g283 ++ linear_t284
def linear_t282 : List Nat := linear_g282 ++ linear_t283
def linear_t281 : List Nat := linear_g281 ++ linear_t282
def linear_t280 : List Nat := linear_g280 ++ linear_t281
def linear_t279 : List Nat := linear_g279 ++ linear_t280
def linear_t278 : List Nat := linear_g278 ++ linear_t279
def linear_t277 : List Nat := linear_g277 ++ linear_t278
def linear_t276 : List Nat := linear_g276 ++ linear_t277
def linear_t275 : List Nat := linear_g275 ++ linear_t276
def linear_t274 : List Nat := linear_g274 ++ linear_t275
def linear_t273 : List Nat := linear_g273 ++ linear_t274
def linear_t272 : List Nat := linear_g272 ++ linear_t273
def linear_t271 : List Nat := linear_g271 ++ linear_t272
def linear_t270 : List Nat := linear_g270 ++ linear_t271
def linear_t269 : List Nat := linear_g269 ++ linear_t270
def linear_t268 : List Nat := linear_g268 ++ linear_t269
def linear_t267 : List Nat := linear_g267 ++ linear_t268
def linear_t266 : List Nat := linear_g266 ++ linear_t267
def linear_t265 : List Nat := linear_g265 ++ linear_t266
def linear_t264 : List Nat := linear_g264 ++ linear_t265
def linear_t263 : List Nat := linear_g263 ++ linear_t264
def linear_t262 : List Nat := linear_g262 ++ linear_t263
def linear_t261 : List Nat := linear_g261 ++ linear_t262
def linear_t260 : List Nat := linear_g260 ++ linear_t261
def linear_t259 : List Nat := linear_g259 ++ linear_t260
def linear_t258 : List Nat := linear_g258 ++ linear_t259
def linear_t257 : List Nat := linear_g257 ++ linear_t258
def linear_t256 : List Nat := linear_g256 ++ linear_t257
def linear_t255 : List Nat := linear_g255 ++ linear_t256
def linear_t254 : List Nat := linear_g254 ++ linear_t255
def linear_t253 : List Nat := linear_g253 ++ linear_t254
def linear_t252 : List Nat := linear_g252 ++ linear_t253
def linear_t251 : List Nat := linear_g251 ++ linear_t252
def linear_t250 : List Nat := linear_g250 ++ linear_t251
def linear_t249 : List Nat := linear_g249 ++ linear_t250
def linear_t248 : List Nat := linear_g248 ++ linear_t249
def linear_t247 : List Nat := linear_g247 ++ linear_t248
def linear_t246 : List Nat := linear_g246 ++ linear_t247
def linear_t245 : List Nat := linear_g245 ++ linear_t246
def linear_t244 : List Nat := linear_g244 ++ linear_t245
def linear_t243 : List Nat := linear_g243 ++ linear_t244
def linear_t242 : List Nat := linear_g242 ++ linear_t243
def linear_t241 : List Nat := linear_g241 ++ linear_t242
def linear_t240 : List Nat := linear_g240 ++ linear_t241
def linear_t239 : List Nat := linear_g239 ++ linear_t240
def linear_t238 : List Nat := linear_g238 ++ linear_t239
def linear_t237 : List Nat := linear_g237 ++ linear_t238
def linear_t236 : List Nat := linear_g236 ++ linear_t237
def linear_t235 : List Nat := linear_g235 ++ linear_t236
def linear_t234 : List Nat := linear_g234 ++ linear_t235
def linear_t233 : List Nat := linear_g233 ++ linear_t234
def linear_t232 : List Nat := linear_g232 ++ linear_t233
def linear_t231 : List Nat := linear_g231 ++ linear_t232
def linear_t230 : List Nat := linear_g230 ++ linear_t231
def linear_t229 : List Nat := linear_g229 ++ linear_t230
def linear_t228 : List Nat := linear_g228 ++ linear_t229
def linear_t227 : List Nat := linear_g227 ++ linear_t228
def linear_t226 : List Nat := linear_g226 ++ linear_t227
def linear_t225 : List Nat := linear_g225 ++ linear_t226
def linear_t224 : List Nat := linear_g224 ++ linear_t225
def linear_t223 : List Nat := linear_g223 ++ linear_t224
def linear_t222 : List Nat := linear_g222 ++ linear_t223
def linear_t221 : List Nat := linear_g221 ++ linear_t222
def linear_t220 : List Nat := linear_g220 ++ linear_t221
def linear_t219 : List Nat := linear_g219 ++ linear_t220
def linear_t218 : List Nat := linear_g218 ++ linear_t219
def linear_t217 : List Nat := linear_g217 ++ linear_t218
def linear_t216 : List Nat := linear_g216 ++ linear_t217
def linear_t215 : List Nat := linear_g215 ++ linear_t216
def linear_t214 : List Nat := linear_g214 ++ linear_t215
def linear_t213 : List Nat := linear_g213 ++ linear_t214
def linear_t212 : List Nat := linear_g212 ++ linear_t213
def linear_t211 : List Nat := linear_g211 ++ linear_t212
def linear_t210 : List Nat := linear_g210 ++ linear_t211
def linear_t209 : List Nat := linear_g209 ++ linear_t210
def linear_t208 : List Nat := linear_g208 ++ linear_t209
def linear_t207 : List Nat := linear_g207 ++ linear_t208
def linear_t206 : List Nat := linear_g206 ++ linear_t207
def linear_t205 : List Nat := linear_g205 ++ linear_t206
def linear_t204 : List Nat := linear_g204 ++ linear_t205
def linear_t203 : List Nat := linear_g203 ++ linear_t204
def linear_t202 : List Nat := linear_g202 ++ linear_t203
def linear_t201 : List Nat := linear_g201 ++ linear_t202
def linear_t200 : List Nat := linear_g200 ++ linear_t201
def linear_t199 : List Nat := linear_g199 ++ linear_t200
def linear_t198 : List Nat := linear_g198 ++ linear_t199
def linear_t197 : List Nat := linear_g197 ++ linear_t198
def linear_t196 : List Nat := linear_g196 ++ linear_t197
def linear_t195 : List Nat := linear_g195 ++ linear_t196
def linear_t194 : List Nat := linear_g194 ++ linear_t195
def linear_t193 : List Nat := linear_g193 ++ linear_t194
def linear_t192 : List Nat := linear_g192 ++ linear_t193
def linear_t191 : List Nat := linear_g191 ++ linear_t192
def linear_t190 : List Nat := linear_g190 ++ linear_t191
def linear_t189 : List Nat := linear_g189 ++ linear_t190
def linear_t188 : List Nat := linear_g188 ++ linear_t189
def linear_t187 : List Nat := linear_g187 ++ linear_t188
def linear_t186 : List Nat := linear_g186 ++ linear_t187
def linear_t185 : List Nat := linear_g185 ++ linear_t186
def linear_t184 : List Nat := linear_g184 ++ linear_t185
def linear_t183 : List Nat := linear_g183 ++ linear_t184
def linear_t182 : List Nat := linear_g182 ++ linear_t183
def linear_t181 : List Nat := linear_g181 ++ linear_t182
def linear_t180 : List Nat := linear_g180 ++ linear_t181
def linear_t179 : List Nat := linear_g179 ++ linear_t180
def linear_t178 : List Nat := linear_g178 ++ linear_t179
def linear_t177 : List Nat := linear_g177 ++ linear_t178
def linear_t176 : List Nat := linear_g176 ++ linear_t177
def linear_t175 : List Nat := linear_g175 ++ linear_t176
def linear_t174 : List Nat := linear_g174 ++ linear_t175
def linear_t173 : List Nat := linear_g173 ++ linear_t174
def linear_t172 : List Nat := linear_g172 ++ linear_t173
def linear_t171 : List Nat := linear_g171 ++ linear_t172
def linear_t170 : List Nat := linear_g170 ++ linear_t171
def linear_t169 : List Nat := linear_g169 ++ linear_t170
def linear_t168 : List Nat := linear_g168 ++ linear_t169
def linear_t167 : List Nat := linear_g167 ++ linear_t168
def linear_t166 : List Nat := linear_g166 ++ linear_t167
def linear_t165 : List Nat := linear_g165 ++ linear_t166
def linear_t164 : List Nat := linear_g164 ++ linear_t165
def linear_t163 : List Nat := linear_g163 ++ linear_t164
def linear_t162 : List Nat := linear_g162 ++ linear_t163
def linear_t161 : List Nat := linear_g161 ++ linear_t162
def linear_t160 : List Nat := linear_g160 ++ linear_t161
def linear_t159 : List Nat := linear_g159 ++ linear_t160
def linear_t158 : List Nat := linear_g158 ++ linear_t159
def linear_t157 : List Nat := linear_g157 ++ linear_t158
def linear_t156 : List Nat := linear_g156 ++ linear_t157
def linear_t155 : List Nat := linear_g155 ++ linear_t156
def linear_t154 : List Nat := linear_g154 ++ linear_t155
def linear_t153 : List Nat := linear_g153 ++ linear_t154
def linear_t152 : List Nat := linear_g152 ++ linear_t153
def linear_t151 : List Nat := linear_g151 ++ linear_t152
def linear_t150 : List Nat := linear_g150 ++ linear_t151
def linear_t149 : List Nat := linear_g149 ++ linear_t150
def linear_t148 : List Nat := linear_g148 ++ linear_t149
def linear_t147 : List Nat := linear_g147 ++ linear_t148
def linear_t146 : List Nat := linear_g146 ++ linear_t147
def linear_t145 : List Nat := linear_g145 ++ linear_t146
def linear_t144 : List Nat := linear_g144 ++ linear_t145
def linear_t143 : List Nat := linear_g143 ++ linear_t144
def linear_t142 : List Nat := linear_g142 ++ linear_t143
def linear_t141 : List Nat := linear_g141 ++ linear_t142
def linear_t140 : List Nat := linear_g140 ++ linear_t141
def linear_t139 : List Nat := linear_g139 ++ linear_t140
def linear_t138 : List Nat := linear_g138 ++ linear_t139
def linear_t137 : List Nat := linear_g137 ++ linear_t138
def linear_t136 : List Nat := linear_g136 ++ linear_t137
def linear_t135 : List Nat := linear_g135 ++ linear_t136
def linear_t134 : List Nat := linear_g134 ++ linear_t135
def linear_t133 : List Nat := linear_g133 ++ linear_t134
def linear_t132 : List Nat := linear_g132 ++ linear_t133
def linear_t131 : List Nat := linear_g131 ++ linear_t132
def linear_t130 : List Nat := linear_g130 ++ linear_t131
def linear_t129 : List Nat := linear_g129 ++ linear_t130
def linear_t128 : List Nat := linear_g128 ++ linear_t129
def linear_t127 : List Nat := linear_g127 ++ linear_t128
def linear_t126 : List Nat := linear_g126 ++ linear_t127
def linear_t125 : List Nat := linear_g125 ++ linear_t126
def linear_t124 : List Nat := linear_g124 ++ linear_t125
def linear_t123 : List Nat := linear_g123 ++ linear_t124
def linear_t122 : List Nat := linear_g122 ++ linear_t123
def linear_t121 : List Nat := linear_g121 ++ linear_t122
def linear_t120 : List Nat := linear_g120 ++ linear_t121
def linear_t119 : List Nat := linear_g119 ++ linear_t120
def linear_t118 : List Nat := linear_g118 ++ linear_t119
def linear_t117 : List Nat := linear_g117 ++ linear_t118
def linear_t116 : List Nat := linear_g116 ++ linear_t117
def linear_t115 : List Nat := linear_g115 ++ linear_t116
def linear_t114 : List Nat := linear_g114 ++ linear_t115
def linear_t113 : List Nat := linear_g113 ++ linear_t114
def linear_t112 : List Nat := linear_g112 ++ linear_t113
def linear_t111 : List Nat := linear_g111 ++ linear_t112
def linear_t110 : List Nat := linear_g110 ++ linear_t111
def linear_t109 : List Nat := linear_g109 ++ linear_t110
def linear_t108 : List Nat := linear_g108 ++ linear_t109
def linear_t107 : List Nat := linear_g107 ++ linear_t108
def linear_t106 : List Nat := linear_g106 ++ linear_t107
def linear_t105 : List Nat := linear_g105 ++ linear_t106
def linear_t104 : List Nat := linear_g104 ++ linear_t105
def linear_t103 : List Nat := linear_g103 ++ linear_t104
def linear_t102 : List Nat := linear_g102 ++ linear_t103
def linear_t101 : List Nat := linear_g101 ++ linear_t102
def linear_t100 : List Nat := linear_g100 ++ linear_t101
def linear_t99 : List Nat := linear_g99 ++ linear_t100
def linear_t98 : List Nat := linear_g98 ++ linear_t99
def linear_t97 : List Nat := linear_g97 ++ linear_t98
def linear_t96 : List Nat := linear_g96 ++ linear_t97
def linear_t95 : List Nat := linear_g95 ++ linear_t96
def linear_t94 : List Nat := linear_g94 ++ linear_t95
def linear_t93 : List Nat := linear_g93 ++ linear_t94
def linear_t92 : List Nat := linear_g92 ++ linear_t93
def linear_t91 : List Nat := linear_g91 ++ linear_t92
def linear_t90 : List Nat := linear_g90 ++ linear_t91
def linear_t89 : List Nat := linear_g89 ++ linear_t90
def linear_t88 : List Nat := linear_g88 ++ linear_t89
def linear_t87 : List Nat := linear_g87 ++ linear_t88
def linear_t86 : List Nat := linear_g86 ++ linear_t87
def linear_t85 : List Nat := linear_g85 ++ linear_t86
def linear_t84 : List Nat := linear_g84 ++ linear_t85
def linear_t83 : List Nat := linear_g83 ++ linear_t84
def linear_t82 : List Nat := linear_g82 ++ linear_t83
def linear_t81 : List Nat := linear_g81 ++ linear_t82
def linear_t80 : List Nat := linear_g80 ++ linear_t81
def linear_t79 : List Nat := linear_g79 ++ linear_t80
def linear_t78 : List Nat := linear_g78 ++ linear_t79
def linear_t77 : List Nat := linear_g77 ++ linear_t78
def linear_t76 : List Nat := linear_g76 ++ linear_t77
def linear_t75 : List Nat := linear_g75 ++ linear_t76
def linear_t74 : List Nat := linear_g74 ++ linear_t75
def linear_t73 : List Nat := linear_g73 ++ linear_t74
def linear_t72 : List Nat := linear_g72 ++ linear_t73
def linear_t71 : List Nat := linear_g71 ++ linear_t72
def linear_t70 : List Nat := linear_g70 ++ linear_t71
def linear_t69 : List Nat := linear_g69 ++ linear_t70
def linear_t68 : List Nat := linear_g68 ++ linear_t69
def linear_t67 : List Nat := linear_g67 ++ linear_t68
def linear_t66 : List Nat := linear_g66 ++ linear_t67
def linear_t65 : List Nat := linear_g65 ++ linear_t66
def linear_t64 : List Nat := linear_g64 ++ linear_t65
def linear_t63 : List Nat := linear_g63 ++ linear_t64
def linear_t62 : List Nat := linear_g62 ++ linear_t63
def linear_t61 : List Nat := linear_g61 ++ linear_t62
def linear_t60 : List Nat := linear_g60 ++ linear_t61
def linear_t59 : List Nat := linear_g59 ++ linear_t60
def linear_t58 : List Nat := linear_g58 ++ linear_t59
def linear_t57 : List Nat := linear_g57 ++ linear_t58
def linear_t56 : List Nat := linear_g56 ++ linear_t57
def linear_t55 : List Nat := linear_g55 ++ linear_t56
def linear_t54 : List Nat := linear_g54 ++ linear_t55
def linear_t53 : List Nat := linear_g53 ++ linear_t54
def linear_t52 : List Nat := linear_g52 ++ linear_t53
def linear_t51 : List Nat := linear_g51 ++ linear_t52
def linear_t50 : List Nat := linear_g50 ++ linear_t51
def linear_t49 : List Nat := linear_g49 ++ linear_t50
def linear_t48 : List Nat := linear_g48 ++ linear_t49
def linear_t47 : List Nat := linear_g47 ++ linear_t48
def linear_t46 : List Nat := linear_g46 ++ linear_t47
def linear_t45 : List Nat := linear_g45 ++ linear_t46
def linear_t44 : List Nat := linear_g44 ++ linear_t45
def linear_t43 : List Nat := linear_g43 ++ linear_t44
def linear_t42 : List Nat := linear_g42 ++ linear_t43
def linear_t41 : List Nat := linear_g41 ++ linear_t42
def linear_t40 : List Nat := linear_g40 ++ linear_t41
def linear_t39 : List Nat := linear_g39 ++ linear_t40
def linear_t38 : List Nat := linear_g38 ++ linear_t39
def linear_t37 : List Nat := linear_g37 ++ linear_t38
def linear_t36 : List Nat := linear_g36 ++ linear_t37
def linear_t35 : List Nat := linear_g35 ++ linear_t36
def linear_t34 : List Nat := linear_g34 ++ linear_t35
def linear_t33 : List Nat := linear_g33 ++ linear_t34
def linear_t32 : List Nat := linear_g32 ++ linear_t33
def linear_t31 : List Nat := linear_g31 ++ linear_t32
def linear_t30 : List Nat := linear_g30 ++ linear_t31
def linear_t29 : List Nat := linear_g29 ++ linear_t30
def linear_t28 : List Nat := linear_g28 ++ linear_t29
def linear_t27 : List Nat := linear_g27 ++ linear_t28
def linear_t26 : List Nat := linear_g26 ++ linear_t27
def linear_t25 : List Nat := linear_g25 ++ linear_t26
def linear_t24 : List Nat := linear_g24 ++ linear_t25
def linear_t23 : List Nat := linear_g23 ++ linear_t24
def linear_t22 : List Nat := linear_g22 ++ linear_t23
def linear_t21 : List Nat := linear_g21 ++ linear_t22
def linear_t20 : List Nat := linear_g20 ++ linear_t21
def linear_t19 : List Nat := linear_g19 ++ linear_t20
def linear_t18 : List Nat := linear_g18 ++ linear_t19
def linear_t17 : List Nat := linear_g17 ++ linear_t18
def linear_t16 : List Nat := linear_g16 ++ linear_t17
def linear_t15 : List Nat := linear_g15 ++ linear_t16
def linear_t14 : List Nat := linear_g14 ++ linear_t15
def linear_t13 : List Nat := linear_g13 ++ linear_t14
def linear_t12 : List Nat := linear_g12 ++ linear_t13
def linear_t11 : List Nat := linear_g11 ++ linear_t12
def linear_t10 : List Nat := linear_g10 ++ linear_t11
def linear_t9 : List Nat := linear_g9 ++ linear_t10
def linear_t8 : List Nat := linear_g8 ++ linear_t9
def linear_t7 : List Nat := linear_g7 ++ linear_t8
def linear_t6 : List Nat := linear_g6 ++ linear_t7
def linear_t5 : List Nat := linear_g5 ++ linear_t6
def linear_t4 : List Nat := linear_g4 ++ linear_t5
def linear_t3 : List Nat := linear_g3 ++ linear_t4
def linear_t2 : List Nat := linear_g2 ++ linear_t3
def linear_t1 : List Nat := linear_g1 ++ linear_t2
def linear_t0 : List Nat := linear_g0 ++ linear_t1
def linear_r1 : Raw := (.arr [(.str [99,97,108,99,117,108,97,116,101])])
def linear_b1 : List Nat := linear_g2
theorem mutated_s1 : serializeRaw 4094 31 linear_r1 = some linear_b1 := by decide +kernel
theorem mutated_p1 (tail : List Nat) : parseRaw 4094 31 (linear_b1 ++ tail) = some (linear_r1, tail) := by rfl
def linear_r6 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,48])
def linear_b6 : List Nat := linear_g11
theorem mutated_s6 : serializeRaw 4085 27 linear_r6 = some linear_b6 := by decide +kernel
theorem mutated_p6 (tail : List Nat) : parseRaw 4085 27 (linear_b6 ++ tail) = some (linear_r6, tail) := by rfl
def linear_r7 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [98,117,102,102,101,114,46,116,114,121,95,110,101,119])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,48])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49])),([116,121,112,101],(.str [98,111,111,108]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50])),([116,121,112,101],(.str [117,56]))])]))])])
def linear_b7 : List Nat := linear_g14
theorem mutated_s7 : serializeRaw 4084 27 linear_r7 = some linear_b7 := by decide +kernel
theorem mutated_p7 (tail : List Nat) : parseRaw 4084 27 (linear_b7 ++ tail) = some (linear_r7, tail) := by rfl
def linear_r8 : Raw := (.arr [(.obj [([110,97,109,101],(.str [97,114,103,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [97,114,103,50])),([116,121,112,101],(.str [117,51,50]))])])
def linear_b8 : List Nat := linear_g17
theorem mutated_s8 : serializeRaw 4083 27 linear_r8 = some linear_b8 := by decide +kernel
theorem mutated_p8 (tail : List Nat) : parseRaw 4083 27 (linear_b8 ++ tail) = some (linear_r8, tail) := by rfl
def linear_r9 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,49])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,50]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [97,114,103,49]),(.str [97,114,103,50]),(.str [100,103,95,118,95,49]),(.str [100,103,95,118,95,48]),(.str [100,103,95,118,95,50]),(.str [97,114,103,49])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,49]))]))])
def linear_b9 : List Nat := linear_g20
theorem mutated_s9 : serializeRaw 4082 27 linear_r9 = some linear_b9 := by decide +kernel
theorem mutated_p9 (tail : List Nat) : parseRaw 4082 27 (linear_b9 ++ tail) = some (linear_r9, tail) := by rfl
def linear_k5_0 : List Nat := [105,100]
theorem mutated_kd5_0 : stringBytes linear_k5_0 = true := by decide +kernel
theorem mutated_kp5_0 (tail : List Nat) : parseStringTail (linear_k5_0 ++ (34 :: 58 :: tail)) [] = some (linear_k5_0, 58 :: tail) := by rfl
def linear_k5_1 : List Nat := [111,112,115]
theorem mutated_kd5_1 : stringBytes linear_k5_1 = true := by decide +kernel
theorem mutated_kp5_1 (tail : List Nat) : parseStringTail (linear_k5_1 ++ (34 :: 58 :: tail)) [] = some (linear_k5_1, 58 :: tail) := by rfl
def linear_k5_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd5_2 : stringBytes linear_k5_2 = true := by decide +kernel
theorem mutated_kp5_2 (tail : List Nat) : parseStringTail (linear_k5_2 ++ (34 :: 58 :: tail)) [] = some (linear_k5_2, 58 :: tail) := by rfl
def linear_k5_3 : List Nat := [116,101,114,109]
theorem mutated_kd5_3 : stringBytes linear_k5_3 = true := by decide +kernel
theorem mutated_kp5_3 (tail : List Nat) : parseStringTail (linear_k5_3 ++ (34 :: 58 :: tail)) [] = some (linear_k5_3, 58 :: tail) := by rfl
def linear_l5_3 : List (List Nat × Raw) := [(linear_k5_3, linear_r9)]
def linear_v5_3 : List Nat := linear_g19 ++ linear_b9
theorem mutated_sl5_3 : serializeFields 4083 27 linear_l5_3 = some linear_v5_3 := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4082 27 linear_k5_3 linear_r9 linear_b9 mutated_kd5_3 mutated_s9)
theorem mutated_pl5_3 (tail : List Nat) : parseFields 4083 27 (linear_v5_3 ++ (125 :: tail)) = some (linear_l5_3, tail) := by
  simpa only [linear_l5_3, linear_v5_3, linear_k5_3, linear_g19, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4082 27 (linear_k5_3 ++ (34 :: 58 :: (linear_b9 ++ (125 :: tail)))) linear_k5_3 (linear_b9 ++ (125 :: tail)) tail linear_r9 (mutated_kp5_3 (linear_b9 ++ (125 :: tail))) (mutated_p9 (125 :: tail)))
def linear_l5_2 : List (List Nat × Raw) := (linear_k5_2, linear_r8) :: linear_l5_3
def linear_v5_2 : List Nat := (linear_g16 ++ linear_b8) ++ (44 :: linear_v5_3)
theorem mutated_sl5_2 : serializeFields 4084 27 linear_l5_2 = some linear_v5_2 := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k5_2 linear_r8 (linear_k5_3, linear_r9) [] linear_b8 linear_v5_3 mutated_kd5_2 mutated_s8 mutated_sl5_3)
theorem mutated_pl5_2 (tail : List Nat) : parseFields 4084 27 (linear_v5_2 ++ (125 :: tail)) = some (linear_l5_2, tail) := by
  simpa only [linear_l5_2, linear_v5_2, linear_k5_2, linear_g16, linear_l5_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k5_2 ++ (34 :: 58 :: (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))))) linear_k5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail)))) (linear_v5_3 ++ (125 :: tail)) tail linear_r8 linear_l5_3 (mutated_kp5_2 (linear_b8 ++ (44 :: (linear_v5_3 ++ (125 :: tail))))) (mutated_p8 (44 :: (linear_v5_3 ++ (125 :: tail)))) (mutated_pl5_3 tail))
def linear_l5_1 : List (List Nat × Raw) := (linear_k5_1, linear_r7) :: linear_l5_2
def linear_v5_1 : List Nat := (linear_g13 ++ linear_b7) ++ (44 :: linear_v5_2)
theorem mutated_sl5_1 : serializeFields 4085 27 linear_l5_1 = some linear_v5_1 := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k5_1 linear_r7 (linear_k5_2, linear_r8) linear_l5_3 linear_b7 linear_v5_2 mutated_kd5_1 mutated_s7 mutated_sl5_2)
theorem mutated_pl5_1 (tail : List Nat) : parseFields 4085 27 (linear_v5_1 ++ (125 :: tail)) = some (linear_l5_1, tail) := by
  simpa only [linear_l5_1, linear_v5_1, linear_k5_1, linear_g13, linear_l5_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k5_1 ++ (34 :: 58 :: (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))))) linear_k5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail)))) (linear_v5_2 ++ (125 :: tail)) tail linear_r7 linear_l5_2 (mutated_kp5_1 (linear_b7 ++ (44 :: (linear_v5_2 ++ (125 :: tail))))) (mutated_p7 (44 :: (linear_v5_2 ++ (125 :: tail)))) (mutated_pl5_2 tail))
def linear_l5_0 : List (List Nat × Raw) := (linear_k5_0, linear_r6) :: linear_l5_1
def linear_v5_0 : List Nat := (linear_g10 ++ linear_b6) ++ (44 :: linear_v5_1)
theorem mutated_sl5_0 : serializeFields 4086 27 linear_l5_0 = some linear_v5_0 := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4085 27 linear_k5_0 linear_r6 (linear_k5_1, linear_r7) linear_l5_2 linear_b6 linear_v5_1 mutated_kd5_0 mutated_s6 mutated_sl5_1)
theorem mutated_pl5_0 (tail : List Nat) : parseFields 4086 27 (linear_v5_0 ++ (125 :: tail)) = some (linear_l5_0, tail) := by
  simpa only [linear_l5_0, linear_v5_0, linear_k5_0, linear_g10, linear_l5_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4085 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) linear_k5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))) (linear_v5_1 ++ (125 :: tail)) tail linear_r6 linear_l5_1 (mutated_kp5_0 (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail))))) (mutated_p6 (44 :: (linear_v5_1 ++ (125 :: tail)))) (mutated_pl5_1 tail))
def linear_r5 : Raw := (.obj linear_l5_0)
def linear_b5 : List Nat := linear_g9 ++ (linear_v5_0 ++ linear_g21)
theorem mutated_o5 : orderedFields linear_l5_0 = true := by decide +kernel
theorem mutated_s5 : serializeRaw 4087 28 linear_r5 = some linear_b5 := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4086 27 linear_l5_0 linear_v5_0 mutated_o5 mutated_sl5_0)
theorem mutated_p5 (tail : List Nat) : parseRaw 4087 28 (linear_b5 ++ tail) = some (linear_r5, tail) := by
  simpa only [linear_r5, linear_b5, linear_g9, linear_g21, linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4086 27 (linear_k5_0 ++ (34 :: 58 :: (linear_b6 ++ (44 :: (linear_v5_1 ++ (125 :: tail)))))) tail linear_l5_0 mutated_o5 (by simpa only [linear_v5_0, linear_k5_0, linear_g10, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl5_0 tail)))
def linear_r11 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,49])
def linear_b11 : List Nat := linear_g25
theorem mutated_s11 : serializeRaw 4084 27 linear_r11 = some linear_b11 := by decide +kernel
theorem mutated_p11 (tail : List Nat) : parseRaw 4084 27 (linear_b11 ++ tail) = some (linear_r11, tail) := by rfl
def linear_r12 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,54])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,109,111,118,101])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,56])),([116,121,112,101],(.str [98,117,102,102,101,114]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,57])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b12 : List Nat := linear_g28
theorem mutated_s12 : serializeRaw 4083 27 linear_r12 = some linear_b12 := by decide +kernel
theorem mutated_p12 (tail : List Nat) : parseRaw 4083 27 (linear_b12 ++ tail) = some (linear_r12, tail) := by rfl
def linear_r13 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,52])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,53])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,54])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,55])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,48])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b13 : List Nat := linear_g31
theorem mutated_s13 : serializeRaw 4082 27 linear_r13 = some linear_b13 := by decide +kernel
theorem mutated_p13 (tail : List Nat) : parseRaw 4082 27 (linear_b13 ++ tail) = some (linear_r13, tail) := by rfl
def linear_r14 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,52]),(.str [100,103,95,118,95,56]),(.str [100,103,95,118,95,51]),(.str [100,103,95,118,95,57]),(.str [100,103,95,118,95,49,48])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,51]))])
def linear_b14 : List Nat := linear_g34
theorem mutated_s14 : serializeRaw 4081 27 linear_r14 = some linear_b14 := by decide +kernel
theorem mutated_p14 (tail : List Nat) : parseRaw 4081 27 (linear_b14 ++ tail) = some (linear_r14, tail) := by rfl
def linear_k10_0 : List Nat := [105,100]
theorem mutated_kd10_0 : stringBytes linear_k10_0 = true := by decide +kernel
theorem mutated_kp10_0 (tail : List Nat) : parseStringTail (linear_k10_0 ++ (34 :: 58 :: tail)) [] = some (linear_k10_0, 58 :: tail) := by rfl
def linear_k10_1 : List Nat := [111,112,115]
theorem mutated_kd10_1 : stringBytes linear_k10_1 = true := by decide +kernel
theorem mutated_kp10_1 (tail : List Nat) : parseStringTail (linear_k10_1 ++ (34 :: 58 :: tail)) [] = some (linear_k10_1, 58 :: tail) := by rfl
def linear_k10_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd10_2 : stringBytes linear_k10_2 = true := by decide +kernel
theorem mutated_kp10_2 (tail : List Nat) : parseStringTail (linear_k10_2 ++ (34 :: 58 :: tail)) [] = some (linear_k10_2, 58 :: tail) := by rfl
def linear_k10_3 : List Nat := [116,101,114,109]
theorem mutated_kd10_3 : stringBytes linear_k10_3 = true := by decide +kernel
theorem mutated_kp10_3 (tail : List Nat) : parseStringTail (linear_k10_3 ++ (34 :: 58 :: tail)) [] = some (linear_k10_3, 58 :: tail) := by rfl
def linear_l10_3 : List (List Nat × Raw) := [(linear_k10_3, linear_r14)]
def linear_v10_3 : List Nat := linear_g33 ++ linear_b14
theorem mutated_sl10_3 : serializeFields 4082 27 linear_l10_3 = some linear_v10_3 := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4081 27 linear_k10_3 linear_r14 linear_b14 mutated_kd10_3 mutated_s14)
theorem mutated_pl10_3 (tail : List Nat) : parseFields 4082 27 (linear_v10_3 ++ (125 :: tail)) = some (linear_l10_3, tail) := by
  simpa only [linear_l10_3, linear_v10_3, linear_k10_3, linear_g33, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4081 27 (linear_k10_3 ++ (34 :: 58 :: (linear_b14 ++ (125 :: tail)))) linear_k10_3 (linear_b14 ++ (125 :: tail)) tail linear_r14 (mutated_kp10_3 (linear_b14 ++ (125 :: tail))) (mutated_p14 (125 :: tail)))
def linear_l10_2 : List (List Nat × Raw) := (linear_k10_2, linear_r13) :: linear_l10_3
def linear_v10_2 : List Nat := (linear_g30 ++ linear_b13) ++ (44 :: linear_v10_3)
theorem mutated_sl10_2 : serializeFields 4083 27 linear_l10_2 = some linear_v10_2 := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k10_2 linear_r13 (linear_k10_3, linear_r14) [] linear_b13 linear_v10_3 mutated_kd10_2 mutated_s13 mutated_sl10_3)
theorem mutated_pl10_2 (tail : List Nat) : parseFields 4083 27 (linear_v10_2 ++ (125 :: tail)) = some (linear_l10_2, tail) := by
  simpa only [linear_l10_2, linear_v10_2, linear_k10_2, linear_g30, linear_l10_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k10_2 ++ (34 :: 58 :: (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))))) linear_k10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail)))) (linear_v10_3 ++ (125 :: tail)) tail linear_r13 linear_l10_3 (mutated_kp10_2 (linear_b13 ++ (44 :: (linear_v10_3 ++ (125 :: tail))))) (mutated_p13 (44 :: (linear_v10_3 ++ (125 :: tail)))) (mutated_pl10_3 tail))
def linear_l10_1 : List (List Nat × Raw) := (linear_k10_1, linear_r12) :: linear_l10_2
def linear_v10_1 : List Nat := (linear_g27 ++ linear_b12) ++ (44 :: linear_v10_2)
theorem mutated_sl10_1 : serializeFields 4084 27 linear_l10_1 = some linear_v10_1 := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k10_1 linear_r12 (linear_k10_2, linear_r13) linear_l10_3 linear_b12 linear_v10_2 mutated_kd10_1 mutated_s12 mutated_sl10_2)
theorem mutated_pl10_1 (tail : List Nat) : parseFields 4084 27 (linear_v10_1 ++ (125 :: tail)) = some (linear_l10_1, tail) := by
  simpa only [linear_l10_1, linear_v10_1, linear_k10_1, linear_g27, linear_l10_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k10_1 ++ (34 :: 58 :: (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))))) linear_k10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail)))) (linear_v10_2 ++ (125 :: tail)) tail linear_r12 linear_l10_2 (mutated_kp10_1 (linear_b12 ++ (44 :: (linear_v10_2 ++ (125 :: tail))))) (mutated_p12 (44 :: (linear_v10_2 ++ (125 :: tail)))) (mutated_pl10_2 tail))
def linear_l10_0 : List (List Nat × Raw) := (linear_k10_0, linear_r11) :: linear_l10_1
def linear_v10_0 : List Nat := (linear_g24 ++ linear_b11) ++ (44 :: linear_v10_1)
theorem mutated_sl10_0 : serializeFields 4085 27 linear_l10_0 = some linear_v10_0 := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4084 27 linear_k10_0 linear_r11 (linear_k10_1, linear_r12) linear_l10_2 linear_b11 linear_v10_1 mutated_kd10_0 mutated_s11 mutated_sl10_1)
theorem mutated_pl10_0 (tail : List Nat) : parseFields 4085 27 (linear_v10_0 ++ (125 :: tail)) = some (linear_l10_0, tail) := by
  simpa only [linear_l10_0, linear_v10_0, linear_k10_0, linear_g24, linear_l10_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4084 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) linear_k10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))) (linear_v10_1 ++ (125 :: tail)) tail linear_r11 linear_l10_1 (mutated_kp10_0 (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail))))) (mutated_p11 (44 :: (linear_v10_1 ++ (125 :: tail)))) (mutated_pl10_1 tail))
def linear_r10 : Raw := (.obj linear_l10_0)
def linear_b10 : List Nat := linear_g23 ++ (linear_v10_0 ++ linear_g35)
theorem mutated_o10 : orderedFields linear_l10_0 = true := by decide +kernel
theorem mutated_s10 : serializeRaw 4086 28 linear_r10 = some linear_b10 := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4085 27 linear_l10_0 linear_v10_0 mutated_o10 mutated_sl10_0)
theorem mutated_p10 (tail : List Nat) : parseRaw 4086 28 (linear_b10 ++ tail) = some (linear_r10, tail) := by
  simpa only [linear_r10, linear_b10, linear_g23, linear_g35, linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4085 27 (linear_k10_0 ++ (34 :: 58 :: (linear_b11 ++ (44 :: (linear_v10_1 ++ (125 :: tail)))))) tail linear_l10_0 mutated_o10 (by simpa only [linear_v10_0, linear_k10_0, linear_g24, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl10_0 tail)))
def linear_r16 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,50])
def linear_b16 : List Nat := linear_g39
theorem mutated_s16 : serializeRaw 4083 27 linear_r16 = some linear_b16 := by decide +kernel
theorem mutated_p16 (tail : List Nat) : parseRaw 4083 27 (linear_b16 ++ tail) = some (linear_r16, tail) := by rfl
def linear_r18 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,52])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [111,119,110,101,114,46,100,114,111,112])),([111,117,116],(.arr []))])
def linear_b18 : List Nat := linear_g43
theorem mutated_s18 : serializeRaw 4080 26 linear_r18 = some linear_b18 := by decide +kernel
theorem mutated_p18 (tail : List Nat) : parseRaw 4080 26 (linear_b18 ++ tail) = some (linear_r18, tail) := by rfl
def linear_r19 : Raw := (.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 1000))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,54])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b19 : List Nat := linear_g45
theorem mutated_s19 : serializeRaw 4079 26 linear_r19 = some linear_b19 := by decide +kernel
theorem mutated_p19 (tail : List Nat) : parseRaw 4079 26 (linear_b19 ++ tail) = some (linear_r19, tail) := by rfl
def linear_r20 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,53])])),([97,116,116,114,115],(.obj [([109,111,100,101],(.str [119,114,97,112]))])),([111,112],(.str [105,110,116,46,99,97,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,55])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b20 : List Nat := linear_g47
theorem mutated_s20 : serializeRaw 4078 26 linear_r20 = some linear_b20 := by decide +kernel
theorem mutated_p20 (tail : List Nat) : parseRaw 4078 26 (linear_b20 ++ tail) = some (linear_r20, tail) := by rfl
def linear_r21 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,49,54]),(.str [100,103,95,118,95,49,55])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [105,110,116,46,97,100,100,46,99,104,101,99,107,101,100])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,56])),([116,121,112,101],(.str [117,54,52]))])]))])
def linear_b21 : List Nat := linear_g49
theorem mutated_s21 : serializeRaw 4077 26 linear_r21 = some linear_b21 := by decide +kernel
theorem mutated_p21 (tail : List Nat) : parseRaw 4077 26 (linear_b21 ++ tail) = some (linear_r21, tail) := by rfl
def linear_l17_3 : List Raw := [linear_r21]
def linear_v17_3 : List Nat := linear_b21
theorem mutated_sl17_3 : serializeItems 4078 26 linear_l17_3 = some linear_v17_3 := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_single 4077 26 linear_r21 linear_b21 mutated_s21)
theorem mutated_pl17_3 (tail : List Nat) : parseItems 4078 26 (linear_v17_3 ++ (93 :: tail)) = some (linear_l17_3, tail) := by
  simpa only [linear_l17_3, linear_v17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_last 4077 26 (linear_b21 ++ (93 :: tail)) tail linear_r21 (mutated_p21 (93 :: tail)))
def linear_l17_2 : List Raw := linear_r20 :: linear_l17_3
def linear_v17_2 : List Nat := (linear_b20) ++ (44 :: linear_v17_3)
theorem mutated_sl17_2 : serializeItems 4079 26 linear_l17_2 = some linear_v17_2 := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4078 26 linear_r20 linear_r21 [] linear_b20 linear_v17_3 mutated_s20 mutated_sl17_3)
theorem mutated_pl17_2 (tail : List Nat) : parseItems 4079 26 (linear_v17_2 ++ (93 :: tail)) = some (linear_l17_2, tail) := by
  simpa only [linear_l17_2, linear_v17_2, linear_l17_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4078 26 (linear_b20 ++ (44 :: (linear_v17_3 ++ (93 :: tail)))) (linear_v17_3 ++ (93 :: tail)) tail linear_r20 linear_l17_3 (mutated_p20 (44 :: (linear_v17_3 ++ (93 :: tail)))) (mutated_pl17_3 tail))
def linear_l17_1 : List Raw := linear_r19 :: linear_l17_2
def linear_v17_1 : List Nat := (linear_b19) ++ (44 :: linear_v17_2)
theorem mutated_sl17_1 : serializeItems 4080 26 linear_l17_1 = some linear_v17_1 := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4079 26 linear_r19 linear_r20 linear_l17_3 linear_b19 linear_v17_2 mutated_s19 mutated_sl17_2)
theorem mutated_pl17_1 (tail : List Nat) : parseItems 4080 26 (linear_v17_1 ++ (93 :: tail)) = some (linear_l17_1, tail) := by
  simpa only [linear_l17_1, linear_v17_1, linear_l17_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4079 26 (linear_b19 ++ (44 :: (linear_v17_2 ++ (93 :: tail)))) (linear_v17_2 ++ (93 :: tail)) tail linear_r19 linear_l17_2 (mutated_p19 (44 :: (linear_v17_2 ++ (93 :: tail)))) (mutated_pl17_2 tail))
def linear_l17_0 : List Raw := linear_r18 :: linear_l17_1
def linear_v17_0 : List Nat := (linear_b18) ++ (44 :: linear_v17_1)
theorem mutated_sl17_0 : serializeItems 4081 26 linear_l17_0 = some linear_v17_0 := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_items_cons 4080 26 linear_r18 linear_r19 linear_l17_2 linear_b18 linear_v17_1 mutated_s18 mutated_sl17_1)
theorem mutated_pl17_0 (tail : List Nat) : parseItems 4081 26 (linear_v17_0 ++ (93 :: tail)) = some (linear_l17_0, tail) := by
  simpa only [linear_l17_0, linear_v17_0, linear_l17_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_items_cons 4080 26 (linear_b18 ++ (44 :: (linear_v17_1 ++ (93 :: tail)))) (linear_v17_1 ++ (93 :: tail)) tail linear_r18 linear_l17_1 (mutated_p18 (44 :: (linear_v17_1 ++ (93 :: tail)))) (mutated_pl17_1 tail))
def linear_r17 : Raw := (.arr linear_l17_0)
def linear_b17 : List Nat := linear_g42 ++ (linear_v17_0 ++ linear_g50)
theorem mutated_s17 : serializeRaw 4082 27 linear_r17 = some linear_b17 := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_array 4081 26 linear_l17_0 linear_v17_0 mutated_sl17_0)
theorem mutated_p17 (tail : List Nat) : parseRaw 4082 27 (linear_b17 ++ tail) = some (linear_r17, tail) := by
  simpa only [linear_r17, linear_b17, linear_g42, linear_g50, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_array 4081 26 (linear_v17_0 ++ (93 :: tail)) tail linear_l17_0 (by intro h; cases h) (mutated_pl17_0 tail))
def linear_r22 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,50])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,51])),([116,121,112,101],(.str [98,111,111,108]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,52])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,53])),([116,121,112,101],(.str [117,56]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,49,57])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b22 : List Nat := linear_g53
theorem mutated_s22 : serializeRaw 4081 27 linear_r22 = some linear_b22 := by decide +kernel
theorem mutated_p22 (tail : List Nat) : parseRaw 4081 27 (linear_b22 ++ tail) = some (linear_r22, tail) := by rfl
def linear_r23 : Raw := (.obj [([111,112],(.str [114,101,116])),([118,97,108,117,101,115],(.arr [(.str [100,103,95,118,95,49,56])]))])
def linear_b23 : List Nat := linear_g56
theorem mutated_s23 : serializeRaw 4080 27 linear_r23 = some linear_b23 := by decide +kernel
theorem mutated_p23 (tail : List Nat) : parseRaw 4080 27 (linear_b23 ++ tail) = some (linear_r23, tail) := by rfl
def linear_k15_0 : List Nat := [105,100]
theorem mutated_kd15_0 : stringBytes linear_k15_0 = true := by decide +kernel
theorem mutated_kp15_0 (tail : List Nat) : parseStringTail (linear_k15_0 ++ (34 :: 58 :: tail)) [] = some (linear_k15_0, 58 :: tail) := by rfl
def linear_k15_1 : List Nat := [111,112,115]
theorem mutated_kd15_1 : stringBytes linear_k15_1 = true := by decide +kernel
theorem mutated_kp15_1 (tail : List Nat) : parseStringTail (linear_k15_1 ++ (34 :: 58 :: tail)) [] = some (linear_k15_1, 58 :: tail) := by rfl
def linear_k15_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd15_2 : stringBytes linear_k15_2 = true := by decide +kernel
theorem mutated_kp15_2 (tail : List Nat) : parseStringTail (linear_k15_2 ++ (34 :: 58 :: tail)) [] = some (linear_k15_2, 58 :: tail) := by rfl
def linear_k15_3 : List Nat := [116,101,114,109]
theorem mutated_kd15_3 : stringBytes linear_k15_3 = true := by decide +kernel
theorem mutated_kp15_3 (tail : List Nat) : parseStringTail (linear_k15_3 ++ (34 :: 58 :: tail)) [] = some (linear_k15_3, 58 :: tail) := by rfl
def linear_l15_3 : List (List Nat × Raw) := [(linear_k15_3, linear_r23)]
def linear_v15_3 : List Nat := linear_g55 ++ linear_b23
theorem mutated_sl15_3 : serializeFields 4081 27 linear_l15_3 = some linear_v15_3 := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4080 27 linear_k15_3 linear_r23 linear_b23 mutated_kd15_3 mutated_s23)
theorem mutated_pl15_3 (tail : List Nat) : parseFields 4081 27 (linear_v15_3 ++ (125 :: tail)) = some (linear_l15_3, tail) := by
  simpa only [linear_l15_3, linear_v15_3, linear_k15_3, linear_g55, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4080 27 (linear_k15_3 ++ (34 :: 58 :: (linear_b23 ++ (125 :: tail)))) linear_k15_3 (linear_b23 ++ (125 :: tail)) tail linear_r23 (mutated_kp15_3 (linear_b23 ++ (125 :: tail))) (mutated_p23 (125 :: tail)))
def linear_l15_2 : List (List Nat × Raw) := (linear_k15_2, linear_r22) :: linear_l15_3
def linear_v15_2 : List Nat := (linear_g52 ++ linear_b22) ++ (44 :: linear_v15_3)
theorem mutated_sl15_2 : serializeFields 4082 27 linear_l15_2 = some linear_v15_2 := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k15_2 linear_r22 (linear_k15_3, linear_r23) [] linear_b22 linear_v15_3 mutated_kd15_2 mutated_s22 mutated_sl15_3)
theorem mutated_pl15_2 (tail : List Nat) : parseFields 4082 27 (linear_v15_2 ++ (125 :: tail)) = some (linear_l15_2, tail) := by
  simpa only [linear_l15_2, linear_v15_2, linear_k15_2, linear_g52, linear_l15_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k15_2 ++ (34 :: 58 :: (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))))) linear_k15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail)))) (linear_v15_3 ++ (125 :: tail)) tail linear_r22 linear_l15_3 (mutated_kp15_2 (linear_b22 ++ (44 :: (linear_v15_3 ++ (125 :: tail))))) (mutated_p22 (44 :: (linear_v15_3 ++ (125 :: tail)))) (mutated_pl15_3 tail))
def linear_l15_1 : List (List Nat × Raw) := (linear_k15_1, linear_r17) :: linear_l15_2
def linear_v15_1 : List Nat := (linear_g41 ++ linear_b17) ++ (44 :: linear_v15_2)
theorem mutated_sl15_1 : serializeFields 4083 27 linear_l15_1 = some linear_v15_1 := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k15_1 linear_r17 (linear_k15_2, linear_r22) linear_l15_3 linear_b17 linear_v15_2 mutated_kd15_1 mutated_s17 mutated_sl15_2)
theorem mutated_pl15_1 (tail : List Nat) : parseFields 4083 27 (linear_v15_1 ++ (125 :: tail)) = some (linear_l15_1, tail) := by
  simpa only [linear_l15_1, linear_v15_1, linear_k15_1, linear_g41, linear_l15_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k15_1 ++ (34 :: 58 :: (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))))) linear_k15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail)))) (linear_v15_2 ++ (125 :: tail)) tail linear_r17 linear_l15_2 (mutated_kp15_1 (linear_b17 ++ (44 :: (linear_v15_2 ++ (125 :: tail))))) (mutated_p17 (44 :: (linear_v15_2 ++ (125 :: tail)))) (mutated_pl15_2 tail))
def linear_l15_0 : List (List Nat × Raw) := (linear_k15_0, linear_r16) :: linear_l15_1
def linear_v15_0 : List Nat := (linear_g38 ++ linear_b16) ++ (44 :: linear_v15_1)
theorem mutated_sl15_0 : serializeFields 4084 27 linear_l15_0 = some linear_v15_0 := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4083 27 linear_k15_0 linear_r16 (linear_k15_1, linear_r17) linear_l15_2 linear_b16 linear_v15_1 mutated_kd15_0 mutated_s16 mutated_sl15_1)
theorem mutated_pl15_0 (tail : List Nat) : parseFields 4084 27 (linear_v15_0 ++ (125 :: tail)) = some (linear_l15_0, tail) := by
  simpa only [linear_l15_0, linear_v15_0, linear_k15_0, linear_g38, linear_l15_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4083 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) linear_k15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))) (linear_v15_1 ++ (125 :: tail)) tail linear_r16 linear_l15_1 (mutated_kp15_0 (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail))))) (mutated_p16 (44 :: (linear_v15_1 ++ (125 :: tail)))) (mutated_pl15_1 tail))
def linear_r15 : Raw := (.obj linear_l15_0)
def linear_b15 : List Nat := linear_g37 ++ (linear_v15_0 ++ linear_g57)
theorem mutated_o15 : orderedFields linear_l15_0 = true := by decide +kernel
theorem mutated_s15 : serializeRaw 4085 28 linear_r15 = some linear_b15 := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4084 27 linear_l15_0 linear_v15_0 mutated_o15 mutated_sl15_0)
theorem mutated_p15 (tail : List Nat) : parseRaw 4085 28 (linear_b15 ++ tail) = some (linear_r15, tail) := by
  simpa only [linear_r15, linear_b15, linear_g37, linear_g57, linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4084 27 (linear_k15_0 ++ (34 :: 58 :: (linear_b16 ++ (44 :: (linear_v15_1 ++ (125 :: tail)))))) tail linear_l15_0 mutated_o15 (by simpa only [linear_v15_0, linear_k15_0, linear_g38, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl15_0 tail)))
def linear_r25 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,51])
def linear_b25 : List Nat := linear_g61
theorem mutated_s25 : serializeRaw 4082 27 linear_r25 = some linear_b25 := by decide +kernel
theorem mutated_p25 (tail : List Nat) : parseRaw 4082 27 (linear_b25 ++ tail) = some (linear_r25, tail) := by rfl
def linear_r26 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,51])])),([97,116,116,114,115],(.obj [])),([111,112],(.str [99,111,109,112,97,114,101,46,108,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,53])),([116,121,112,101],(.str [98,111,111,108]))])]))])])
def linear_b26 : List Nat := linear_g64
theorem mutated_s26 : serializeRaw 4081 27 linear_r26 = some linear_b26 := by decide +kernel
theorem mutated_p26 (tail : List Nat) : parseRaw 4081 27 (linear_b26 ++ tail) = some (linear_r26, tail) := by rfl
def linear_r27 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,49])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,50])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,51])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,52])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,54])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b27 : List Nat := linear_g67
theorem mutated_s27 : serializeRaw 4080 27 linear_r27 = some linear_b27 := by decide +kernel
theorem mutated_p27 (tail : List Nat) : parseRaw 4080 27 (linear_b27 ++ tail) = some (linear_r27, tail) := by rfl
def linear_r28 : Raw := (.obj [([99,111,110,100],(.str [100,103,95,118,95,50,53])),([101,108,115,101],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,52]))])),([111,112],(.str [98,114,97,110,99,104])),([116,104,101,110],(.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,48]),(.str [100,103,95,118,95,50,49]),(.str [100,103,95,118,95,50,50]),(.str [100,103,95,118,95,50,51]),(.str [100,103,95,118,95,50,52]),(.str [100,103,95,118,95,50,54])])),([116,97,114,103,101,116],(.str [100,103,95,103,117,97,114,100,95,48]))]))])
def linear_b28 : List Nat := linear_g70
theorem mutated_s28 : serializeRaw 4079 27 linear_r28 = some linear_b28 := by decide +kernel
theorem mutated_p28 (tail : List Nat) : parseRaw 4079 27 (linear_b28 ++ tail) = some (linear_r28, tail) := by rfl
def linear_k24_0 : List Nat := [105,100]
theorem mutated_kd24_0 : stringBytes linear_k24_0 = true := by decide +kernel
theorem mutated_kp24_0 (tail : List Nat) : parseStringTail (linear_k24_0 ++ (34 :: 58 :: tail)) [] = some (linear_k24_0, 58 :: tail) := by rfl
def linear_k24_1 : List Nat := [111,112,115]
theorem mutated_kd24_1 : stringBytes linear_k24_1 = true := by decide +kernel
theorem mutated_kp24_1 (tail : List Nat) : parseStringTail (linear_k24_1 ++ (34 :: 58 :: tail)) [] = some (linear_k24_1, 58 :: tail) := by rfl
def linear_k24_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd24_2 : stringBytes linear_k24_2 = true := by decide +kernel
theorem mutated_kp24_2 (tail : List Nat) : parseStringTail (linear_k24_2 ++ (34 :: 58 :: tail)) [] = some (linear_k24_2, 58 :: tail) := by rfl
def linear_k24_3 : List Nat := [116,101,114,109]
theorem mutated_kd24_3 : stringBytes linear_k24_3 = true := by decide +kernel
theorem mutated_kp24_3 (tail : List Nat) : parseStringTail (linear_k24_3 ++ (34 :: 58 :: tail)) [] = some (linear_k24_3, 58 :: tail) := by rfl
def linear_l24_3 : List (List Nat × Raw) := [(linear_k24_3, linear_r28)]
def linear_v24_3 : List Nat := linear_g69 ++ linear_b28
theorem mutated_sl24_3 : serializeFields 4080 27 linear_l24_3 = some linear_v24_3 := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_single 4079 27 linear_k24_3 linear_r28 linear_b28 mutated_kd24_3 mutated_s28)
theorem mutated_pl24_3 (tail : List Nat) : parseFields 4080 27 (linear_v24_3 ++ (125 :: tail)) = some (linear_l24_3, tail) := by
  simpa only [linear_l24_3, linear_v24_3, linear_k24_3, linear_g69, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_last 4079 27 (linear_k24_3 ++ (34 :: 58 :: (linear_b28 ++ (125 :: tail)))) linear_k24_3 (linear_b28 ++ (125 :: tail)) tail linear_r28 (mutated_kp24_3 (linear_b28 ++ (125 :: tail))) (mutated_p28 (125 :: tail)))
def linear_l24_2 : List (List Nat × Raw) := (linear_k24_2, linear_r27) :: linear_l24_3
def linear_v24_2 : List Nat := (linear_g66 ++ linear_b27) ++ (44 :: linear_v24_3)
theorem mutated_sl24_2 : serializeFields 4081 27 linear_l24_2 = some linear_v24_2 := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4080 27 linear_k24_2 linear_r27 (linear_k24_3, linear_r28) [] linear_b27 linear_v24_3 mutated_kd24_2 mutated_s27 mutated_sl24_3)
theorem mutated_pl24_2 (tail : List Nat) : parseFields 4081 27 (linear_v24_2 ++ (125 :: tail)) = some (linear_l24_2, tail) := by
  simpa only [linear_l24_2, linear_v24_2, linear_k24_2, linear_g66, linear_l24_3, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4080 27 (linear_k24_2 ++ (34 :: 58 :: (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))))) linear_k24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail)))) (linear_v24_3 ++ (125 :: tail)) tail linear_r27 linear_l24_3 (mutated_kp24_2 (linear_b27 ++ (44 :: (linear_v24_3 ++ (125 :: tail))))) (mutated_p27 (44 :: (linear_v24_3 ++ (125 :: tail)))) (mutated_pl24_3 tail))
def linear_l24_1 : List (List Nat × Raw) := (linear_k24_1, linear_r26) :: linear_l24_2
def linear_v24_1 : List Nat := (linear_g63 ++ linear_b26) ++ (44 :: linear_v24_2)
theorem mutated_sl24_1 : serializeFields 4082 27 linear_l24_1 = some linear_v24_1 := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4081 27 linear_k24_1 linear_r26 (linear_k24_2, linear_r27) linear_l24_3 linear_b26 linear_v24_2 mutated_kd24_1 mutated_s26 mutated_sl24_2)
theorem mutated_pl24_1 (tail : List Nat) : parseFields 4082 27 (linear_v24_1 ++ (125 :: tail)) = some (linear_l24_1, tail) := by
  simpa only [linear_l24_1, linear_v24_1, linear_k24_1, linear_g63, linear_l24_2, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4081 27 (linear_k24_1 ++ (34 :: 58 :: (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))))) linear_k24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail)))) (linear_v24_2 ++ (125 :: tail)) tail linear_r26 linear_l24_2 (mutated_kp24_1 (linear_b26 ++ (44 :: (linear_v24_2 ++ (125 :: tail))))) (mutated_p26 (44 :: (linear_v24_2 ++ (125 :: tail)))) (mutated_pl24_2 tail))
def linear_l24_0 : List (List Nat × Raw) := (linear_k24_0, linear_r25) :: linear_l24_1
def linear_v24_0 : List Nat := (linear_g60 ++ linear_b25) ++ (44 :: linear_v24_1)
theorem mutated_sl24_0 : serializeFields 4083 27 linear_l24_0 = some linear_v24_0 := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_fields_cons 4082 27 linear_k24_0 linear_r25 (linear_k24_1, linear_r26) linear_l24_2 linear_b25 linear_v24_1 mutated_kd24_0 mutated_s25 mutated_sl24_1)
theorem mutated_pl24_0 (tail : List Nat) : parseFields 4083 27 (linear_v24_0 ++ (125 :: tail)) = some (linear_l24_0, tail) := by
  simpa only [linear_l24_0, linear_v24_0, linear_k24_0, linear_g60, linear_l24_1, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_fields_cons 4082 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) linear_k24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))) (linear_v24_1 ++ (125 :: tail)) tail linear_r25 linear_l24_1 (mutated_kp24_0 (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail))))) (mutated_p25 (44 :: (linear_v24_1 ++ (125 :: tail)))) (mutated_pl24_1 tail))
def linear_r24 : Raw := (.obj linear_l24_0)
def linear_b24 : List Nat := linear_g59 ++ (linear_v24_0 ++ linear_g71)
theorem mutated_o24 : orderedFields linear_l24_0 = true := by decide +kernel
theorem mutated_s24 : serializeRaw 4084 28 linear_r24 = some linear_b24 := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.serialize_object 4083 27 linear_l24_0 linear_v24_0 mutated_o24 mutated_sl24_0)
theorem mutated_p24 (tail : List Nat) : parseRaw 4084 28 (linear_b24 ++ tail) = some (linear_r24, tail) := by
  simpa only [linear_r24, linear_b24, linear_g59, linear_g71, linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (HiaCoreSyntaxSlice.Structured.parse_object 4083 27 (linear_k24_0 ++ (34 :: 58 :: (linear_b25 ++ (44 :: (linear_v24_1 ++ (125 :: tail)))))) tail linear_l24_0 mutated_o24 (by simpa only [linear_v24_0, linear_k24_0, linear_g60, List.append_assoc, List.cons_append, List.nil_append, List.append_nil] using (mutated_pl24_0 tail)))
def linear_r30 : Raw := (.str [100,103,95,115,104,97,114,101,100,95,52])
def linear_b30 : List Nat := linear_g75
theorem mutated_s30 : serializeRaw 4081 27 linear_r30 = some linear_b30 := by decide +kernel
theorem mutated_p30 (tail : List Nat) : parseRaw 4081 27 (linear_b30 ++ tail) = some (linear_r30, tail) := by rfl
def linear_r31 : Raw := (.arr [(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,50])),([116,121,112,101],(.str [117,54,52]))])]))]),(.obj [([97,114,103,115],(.arr [])),([97,116,116,114,115],(.obj [([118,97,108,117,101],(.num 0))])),([111,112],(.str [99,111,110,115,116])),([111,117,116],(.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,51])),([116,121,112,101],(.str [117,115,105,122,101]))])]))])])
def linear_b31 : List Nat := linear_g78
theorem mutated_s31 : serializeRaw 4080 27 linear_r31 = some linear_b31 := by decide +kernel
theorem mutated_p31 (tail : List Nat) : parseRaw 4080 27 (linear_b31 ++ tail) = some (linear_r31, tail) := by rfl
def linear_r32 : Raw := (.arr [(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,55])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,56])),([116,121,112,101],(.str [117,51,50]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,50,57])),([116,121,112,101],(.str [98,117,102,102,101,114]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,48])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,49])),([116,121,112,101],(.str [117,115,105,122,101]))]),(.obj [([110,97,109,101],(.str [100,103,95,118,95,51,52])),([116,121,112,101],(.str [117,115,105,122,101]))])])
def linear_b32 : List Nat := linear_g81
theorem mutated_s32 : serializeRaw 4079 27 linear_r32 = some linear_b32 := by decide +kernel
theorem mutated_p32 (tail : List Nat) : parseRaw 4079 27 (linear_b32 ++ tail) = some (linear_r32, tail) := by rfl
def linear_r33 : Raw := (.obj [([97,114,103,115],(.arr [(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,50,56]),(.str [100,103,95,118,95,50,57]),(.str [100,103,95,118,95,51,50]),(.str [100,103,95,118,95,50,55]),(.str [100,103,95,118,95,51,51]),(.str [100,103,95,118,95,51,52])])),([111,112],(.str [106,117,109,112])),([116,97,114,103,101,116],(.str [100,103,95,115,104,97,114,101,100,95,53]))])
def linear_b33 : List Nat := linear_g84
theorem mutated_s33 : serializeRaw 4078 27 linear_r33 = some linear_b33 := by decide +kernel
theorem mutated_p33 (tail : List Nat) : parseRaw 4078 27 (linear_b33 ++ tail) = some (linear_r33, tail) := by rfl
def linear_k29_0 : List Nat := [105,100]
theorem mutated_kd29_0 : stringBytes linear_k29_0 = true := by decide +kernel
theorem mutated_kp29_0 (tail : List Nat) : parseStringTail (linear_k29_0 ++ (34 :: 58 :: tail)) [] = some (linear_k29_0, 58 :: tail) := by rfl
def linear_k29_1 : List Nat := [111,112,115]
theorem mutated_kd29_1 : stringBytes linear_k29_1 = true := by decide +kernel
theorem mutated_kp29_1 (tail : List Nat) : parseStringTail (linear_k29_1 ++ (34 :: 58 :: tail)) [] = some (linear_k29_1, 58 :: tail) := by rfl
def linear_k29_2 : List Nat := [112,97,114,97,109,115]
theorem mutated_kd29_2 : stringBytes linear_k29_2 = true := by decide +kernel
theorem mutated_kp29_2 (tail : List Nat) : parseStringTail (linear_k29_2 ++ (34 :: 58 :: tail)) [] = some (linear_k29_2, 58 :: tail) := by rfl
def linear_k29_3 : List Nat := [116,101,114,109]
theorem mutated_kd29_3 : stringBytes linear_k29_3 = true := by decide +kernel
end HiaCoreSyntaxSlice.WrongCondition
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0000
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0001
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0002
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0003
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0004
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0005
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0006
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0007
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0008
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0009
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0010
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0011
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0012
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0013
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0014
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0015
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0016
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0017
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0018
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0019
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0020
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0021
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0022
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0023
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0024
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0025
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0026
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0027
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0028
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0029
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0030
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0031
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0032
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0033
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0034
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0035
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0036
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0037
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0038
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0039
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0040
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0041
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0042
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0043
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0044
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0045
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0046
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0047
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0048
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0049
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0050
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0051
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0052
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0053
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0054
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0055
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0056
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0057
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0058
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0059
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0060
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0061
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0062
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0063
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0064
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0065
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0066
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0067
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0068
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0069
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0070
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0071
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0072
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0073
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0074
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0075
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0076
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0077
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0078
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0079
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0080
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0081
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0082
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0083
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0084
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0085
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0086
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0087
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0088
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0089
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0090
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0091
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0092
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0093
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0094
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0095
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0096
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0097
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0098
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0099
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0100
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0101
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0102
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0103
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0104
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0105
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0106
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0107
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0108
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0109
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0110
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0111
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0112
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0113
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0114
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0115
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0116
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0117
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0118
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0119
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0120
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0121
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0122
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0123
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0124
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0125
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0126
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0127
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0128
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0129
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0130
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0131
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0132
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0133
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0134
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0135
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0136
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0137
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0138
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0139
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0140
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0141
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0142
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0143
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0144
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0145
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0146
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0147
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0148
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0149
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0150
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0151
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0152
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0153
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0154
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0155
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0156
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0157
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0158
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0159
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0160
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0161
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0162
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0163
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0164
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0165
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0166
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0167
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0168
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0169
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0170
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0171
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0172
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0173
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0174
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0175
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0176
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0177
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0178
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0179
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0180
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0181
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0182
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0183
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0184
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0185
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0186
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0187
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0188
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0189
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0190
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0191
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0192
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0193
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0194
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0195
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0196
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0197
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0198
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0199
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0200
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0201
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0202
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0203
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0204
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0205
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0206
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0207
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0208
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0209
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0210
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0211
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0212
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0213
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0214
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0215
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0216
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0217
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0218
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0219
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0220
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0221
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0222
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0223
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0224
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0225
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0226
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0227
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0228
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0229
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0230
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0231
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0232
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0233
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0234
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0235
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0236
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0237
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0238
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0239
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0240
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0241
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0242
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0243
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0244
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0245
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0246
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0247
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0248
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0249
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0250
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0251
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0252
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0253
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0254
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0255
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0256
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0257
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0258
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0259
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0260
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0261
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0262
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0263
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0264
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0265
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0266
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0267
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0268
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0269
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0270
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0271
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0272
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0273
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0274
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0275
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0276
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0277
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0278
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0279
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0280
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0281
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0282
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0283
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0284
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0285
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0286
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0287
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0288
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0289
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0290
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0291
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0292
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0293
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0294
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0295
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0296
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0297
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0298
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0299
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0300
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0301
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0302
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0303
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0304
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0305
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0306
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0307
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0308
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0309
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0310
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0311
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0312
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0313
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0314
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0315
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0316
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0317
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0318
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0319
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0320
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0321
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0322
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0323
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0324
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0325
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0326
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0327
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0328
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0329
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0330
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0331
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0332
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0333
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0334
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0335
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0336
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0337
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0338
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0339
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0340
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0341
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0342
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0343
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0344
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0345
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0346
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0347
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0348
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0349
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0350
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0351
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0352
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0353
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0354
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0355
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0356
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0357
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0358
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0359
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0360
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0361
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0362
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0363
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0364
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0365
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0366
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0367
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0368
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0369
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0370
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0371
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0372
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0373
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0374
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0375
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0376
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0377
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0378
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0379
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0380
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0381
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0382
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0383
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0384
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0385
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0386
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0387
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0388
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0389
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0390
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0391
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0392
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0393
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0394
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0395
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0396
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0397
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0398
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0399
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0400
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0401
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0402
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0403
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0404
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0405
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0406
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0407
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0408
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0409
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0410
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0411
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0412
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0413
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0414
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0415
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0416
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0417
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0418
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0419
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0420
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0421
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0422
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0423
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0424
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0425
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0426
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0427
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0428
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0429
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0430
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0431
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0432
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0433
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0434
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0435
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0436
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0437
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0438
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0439
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0440
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0441
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0442
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0443
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0444
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0445
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0446
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0447
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0448
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0449
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0450
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0451
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0452
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0453
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0454
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0455
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0456
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0457
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0458
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0459
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0460
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0461
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0462
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0463
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0464
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0465
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0466
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0467
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0468
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0469
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0470
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0471
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0472
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0473
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0474
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0475
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0476
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0477
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0478
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0479
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0480
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0481
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0482
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0483
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0484
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0485
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0486
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0487
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0488
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0489
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0490
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0491
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0492
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0493
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0494
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0495
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0496
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0497
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0498
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0499
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0500
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0501
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0502
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0503
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0504
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0505
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0506
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0507
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0508
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0509
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0510
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0511
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0512
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0513
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0514
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0515
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0516
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0517
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0518
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0519
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0520
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0521
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0522
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0523
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0524
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0525
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0526
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0527
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0528
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0529
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0530
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0531
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0532
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0533
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0534
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0535
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0536
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0537
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0538
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0539
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0540
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0541
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0542
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0543
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0544
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0545
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0546
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0547
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0548
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0549
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0550
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0551
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0552
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0553
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0554
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0555
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0556
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0557
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0558
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0559
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0560
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0561
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0562
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0563
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0564
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0565
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0566
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0567
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0568
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0569
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0570
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0571
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0572
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0573
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0574
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0575
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0576
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0577
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0578
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0579
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0580
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0581
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0582
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0583
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0584
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0585
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0586
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0587
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0588
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0589
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0590
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0591
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0592
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0593
#print axioms HiaCoreSyntaxSlice.LiteralTwo.linear_bf0594
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_bounds
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_byte_range
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd0_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd0_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd0_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd0_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd113_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd113_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd113_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd113_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd118_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd118_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd118_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd118_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd123_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd123_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd123_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd123_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd135_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd135_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd135_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd135_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd140_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd140_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd140_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd140_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd145_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd145_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd145_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd145_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd3_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd3_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd3_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd3_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd3_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd3_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd49_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd49_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd49_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd49_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd65_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd65_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd65_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd65_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd70_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd70_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd70_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd70_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd75_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd75_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd75_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd75_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd87_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd87_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd87_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd87_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd92_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd92_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd92_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd92_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd97_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd97_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd97_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kd97_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp0_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp0_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp0_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp0_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp113_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp113_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp113_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp113_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp118_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp118_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp118_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp118_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp123_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp123_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp123_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp123_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp135_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp135_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp135_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp135_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp140_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp140_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp140_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp140_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp145_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp145_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp145_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp145_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp3_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp3_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp3_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp3_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp3_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp3_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp49_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp49_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp49_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp49_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp65_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp65_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp65_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp65_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp70_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp70_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp70_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp70_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp75_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp75_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp75_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp75_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp87_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp87_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp87_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp87_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp92_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp92_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp92_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp92_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp97_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp97_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp97_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_kp97_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_length
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o113
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o118
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o123
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o135
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o140
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o145
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o49
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o65
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o70
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o75
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o87
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o92
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_o97
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p100
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p101
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p102
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p103
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p104
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p105
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p106
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p107
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p108
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p109
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p110
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p111
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p112
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p113
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p114
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p115
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p116
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p117
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p118
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p119
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p120
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p121
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p122
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p123
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p124
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p125
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p126
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p127
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p128
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p129
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p130
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p131
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p132
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p133
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p134
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p135
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p136
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p137
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p138
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p139
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p140
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p141
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p142
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p143
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p144
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p145
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p146
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p147
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p148
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p149
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p150
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p151
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p152
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p153
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p154
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p155
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p156
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p49
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p63
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p64
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p65
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p66
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p67
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p68
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p69
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p70
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p71
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p72
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p73
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p74
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p75
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p76
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p77
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p78
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p79
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p80
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p81
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p82
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p83
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p84
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p85
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p86
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p87
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p88
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p89
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p90
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p91
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p92
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p93
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p94
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p95
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p96
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p97
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p98
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_p99
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_parsed
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl0_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl0_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl0_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl0_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl113_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl113_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl113_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl113_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl118_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl118_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl118_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl118_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl123_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl123_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl123_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl123_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl125_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl135_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl135_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl135_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl135_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl140_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl140_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl140_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl140_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl145_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl145_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl145_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl145_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl2_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl3_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl3_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl3_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl3_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl3_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl3_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl49_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl49_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl49_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl49_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_11
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_12
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_13
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_14
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_15
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_16
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_17
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_18
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_19
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_20
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl4_9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl65_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl65_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl65_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl65_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl70_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl70_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl70_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl70_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl75_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl75_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl75_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl75_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl77_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl87_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl87_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl87_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl87_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl92_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl92_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl92_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl92_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl97_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl97_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl97_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl97_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_pl99_9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s100
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s101
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s102
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s103
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s104
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s105
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s106
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s107
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s108
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s109
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s110
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s111
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s112
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s113
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s114
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s115
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s116
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s117
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s118
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s119
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s120
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s121
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s122
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s123
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s124
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s125
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s126
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s127
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s128
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s129
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s130
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s131
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s132
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s133
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s134
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s135
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s136
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s137
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s138
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s139
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s140
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s141
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s142
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s143
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s144
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s145
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s146
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s147
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s148
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s149
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s150
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s151
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s152
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s153
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s154
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s155
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s156
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s49
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s63
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s64
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s65
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s66
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s67
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s68
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s69
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s70
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s71
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s72
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s73
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s74
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s75
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s76
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s77
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s78
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s79
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s80
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s81
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s82
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s83
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s84
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s85
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s86
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s87
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s88
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s89
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s90
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s91
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s92
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s93
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s94
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s95
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s96
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s97
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s98
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_s99
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_serialized
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl0_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl0_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl0_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl0_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl113_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl113_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl113_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl113_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl118_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl118_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl118_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl118_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl123_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl123_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl123_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl123_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl125_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl135_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl135_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl135_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl135_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl140_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl140_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl140_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl140_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl145_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl145_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl145_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl145_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl2_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl3_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl3_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl3_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl3_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl3_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl3_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl49_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl49_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl49_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl49_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_11
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_12
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_13
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_14
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_15
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_16
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_17
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_18
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_19
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_20
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl4_9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl65_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl65_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl65_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl65_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl70_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl70_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl70_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl70_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl75_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl75_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl75_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl75_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl77_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl87_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl87_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl87_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl87_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl92_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl92_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl92_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl92_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl97_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl97_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl97_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl97_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_0
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_1
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_10
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_2
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_3
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_4
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_5
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_6
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_7
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_8
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_sl99_9
#print axioms HiaCoreSyntaxSlice.LiteralTwo.mutated_transport
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd10_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd10_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd10_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd10_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd15_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd15_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd15_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd15_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd24_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd24_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd24_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd24_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd29_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd29_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd29_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd29_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd5_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd5_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd5_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kd5_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp10_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp10_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp10_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp10_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp15_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp15_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp15_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp15_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp24_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp24_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp24_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp24_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp29_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp29_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp29_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp5_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp5_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp5_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_kp5_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o15
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o24
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_o5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p11
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p12
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p13
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p14
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p15
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p16
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p17
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p18
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p19
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p20
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p21
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p22
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p23
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p24
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p25
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p26
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p27
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p28
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p30
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p31
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p32
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p33
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_p9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl10_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl10_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl10_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl10_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl15_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl15_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl15_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl15_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl17_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl17_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl17_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl17_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl24_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl24_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl24_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl24_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl5_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl5_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl5_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_pl5_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s10
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s11
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s12
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s13
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s14
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s15
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s16
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s17
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s18
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s19
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s20
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s21
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s22
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s23
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s24
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s25
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s26
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s27
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s28
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s30
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s31
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s32
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s33
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s5
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s6
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s7
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s8
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_s9
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl10_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl10_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl10_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl10_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl15_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl15_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl15_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl15_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl17_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl17_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl17_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl17_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl24_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl24_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl24_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl24_3
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl5_0
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl5_1
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl5_2
#print axioms HiaCoreSyntaxSlice.WrongCondition.mutated_sl5_3
