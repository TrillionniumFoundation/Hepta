import HiaSyntaxResearch.Baseline
/-!
UNCHECKED Lean 4.19 proof text. Append after the existing
Lean.Elab.Tactic.Omega import; no additional import is required.

Restricted, compact canonical JSON transport for an inert whole-document tree.
The decoder is independent of the serializer. checkedEncode accepts only after
an actual decode equality check, so determinacy below is a checked round-trip
result, not an assumed serializer-injectivity theorem. No claim of completeness
for all JSON, all Core, or every input within the resource limits is made.
File-to-byte provenance is outside this kernel statement.
-/

namespace HiaCoreSyntaxSlice

inductive Raw where
  | str (bytes : List Nat)
  | num (value : Nat)
  | arr (items : List Raw)
  | obj (fields : List (List Nat × Raw))
  deriving Repr

/- Lean 4.19 does not derive DecidableEq for this nested datatype. These
    explicit mutual decisions produce equality proofs by constructor congruence
    and reject unequal constructor arguments by constructor injectivity. -/
mutual
  def rawDecEq : (a b : Raw) → Decidable (a = b)
    | .str left, .str right =>
      if same : left = right then isTrue (congrArg Raw.str same)
      else isFalse (fun equal => same (Raw.str.inj equal))
    | .num left, .num right =>
      if same : left = right then isTrue (congrArg Raw.num same)
      else isFalse (fun equal => same (Raw.num.inj equal))
    | .arr left, .arr right =>
      match rawListDecEq left right with
      | isTrue same => isTrue (congrArg Raw.arr same)
      | isFalse different => isFalse (fun equal => different (Raw.arr.inj equal))
    | .obj left, .obj right =>
      match rawFieldsDecEq left right with
      | isTrue same => isTrue (congrArg Raw.obj same)
      | isFalse different => isFalse (fun equal => different (Raw.obj.inj equal))
    | .str _, .num _ => isFalse (by intro equal; cases equal)
    | .str _, .arr _ => isFalse (by intro equal; cases equal)
    | .str _, .obj _ => isFalse (by intro equal; cases equal)
    | .num _, .str _ => isFalse (by intro equal; cases equal)
    | .num _, .arr _ => isFalse (by intro equal; cases equal)
    | .num _, .obj _ => isFalse (by intro equal; cases equal)
    | .arr _, .str _ => isFalse (by intro equal; cases equal)
    | .arr _, .num _ => isFalse (by intro equal; cases equal)
    | .arr _, .obj _ => isFalse (by intro equal; cases equal)
    | .obj _, .str _ => isFalse (by intro equal; cases equal)
    | .obj _, .num _ => isFalse (by intro equal; cases equal)
    | .obj _, .arr _ => isFalse (by intro equal; cases equal)

  def rawListDecEq : (a b : List Raw) → Decidable (a = b)
    | [], [] => isTrue rfl
    | [], _ :: _ => isFalse (by intro equal; cases equal)
    | _ :: _, [] => isFalse (by intro equal; cases equal)
    | left :: leftRest, right :: rightRest =>
      match rawDecEq left right with
      | isFalse different =>
        isFalse (fun equal => different (List.cons.inj equal).1)
      | isTrue same =>
        match rawListDecEq leftRest rightRest with
        | isFalse different =>
          isFalse (fun equal => different (List.cons.inj equal).2)
        | isTrue sameRest => isTrue (by cases same; cases sameRest; rfl)

  def rawFieldDecEq : (a b : List Nat × Raw) → Decidable (a = b)
    | (leftKey, left), (rightKey, right) =>
      if sameKey : leftKey = rightKey then
        match rawDecEq left right with
        | isTrue same => isTrue (by cases sameKey; cases same; rfl)
        | isFalse different =>
          isFalse (fun equal => different (congrArg Prod.snd equal))
      else isFalse (fun equal => sameKey (congrArg Prod.fst equal))

  def rawFieldsDecEq : (a b : List (List Nat × Raw)) → Decidable (a = b)
    | [], [] => isTrue rfl
    | [], _ :: _ => isFalse (by intro equal; cases equal)
    | _ :: _, [] => isFalse (by intro equal; cases equal)
    | left :: leftRest, right :: rightRest =>
      match rawFieldDecEq left right with
      | isFalse different =>
        isFalse (fun equal => different (List.cons.inj equal).1)
      | isTrue same =>
        match rawFieldsDecEq leftRest rightRest with
        | isFalse different =>
          isFalse (fun equal => different (List.cons.inj equal).2)
        | isTrue sameRest => isTrue (by cases same; cases sameRest; rfl)
end

instance : DecidableEq Raw := rawDecEq

def transportFuel : Nat := 4096
def transportDepth : Nat := 32
def transportByteLimit : Nat := 32768

/-- Printable ASCII without JSON's quote or escape character. -/
def stringByte (byte : Nat) : Bool :=
  decide (32 ≤ byte ∧ byte ≤ 126 ∧ byte ≠ 34 ∧ byte ≠ 92)

def stringBytes : List Nat → Bool
  | [] => true
  | byte :: rest => stringByte byte && stringBytes rest

/-- Strict lexicographic comparison of byte lists, including prefix ordering. -/
def keyLess : List Nat → List Nat → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: left, b :: right =>
    if a < b then true else if a = b then keyLess left right else false

/-- Strict order rejects both duplicates and noncanonical field order. -/
def orderedFields : List (List Nat × Raw) → Bool
  | [] => true
  | (key, _) :: rest =>
    match rest with
    | [] => true
    | (nextKey, _) :: _ => keyLess key nextKey && orderedFields rest

/-- Count all value nodes, including unselected subtrees, without recursion on
    the nested datatype. This is separate from parser/serializer call fuel. -/
def nodeBudget : Nat → List Raw → Bool
  | _, [] => true
  | 0, _ :: _ => false
  | fuel + 1, .str _ :: rest => nodeBudget fuel rest
  | fuel + 1, .num _ :: rest => nodeBudget fuel rest
  | fuel + 1, .arr items :: rest => nodeBudget fuel (items ++ rest)
  | fuel + 1, .obj fields :: rest =>
    nodeBudget fuel (fields.map (fun entry => entry.2) ++ rest)

/-- A separate cheap whole-tree budget check for syntax extraction. Each
    pending item carries the number of value levels still allowed at that item. -/
def depthNodeBudget : Nat → List (Nat × Raw) → Bool
  | _, [] => true
  | 0, _ :: _ => false
  | _ + 1, (0, _) :: _ => false
  | fuel + 1, (_ + 1, .str _) :: rest => depthNodeBudget fuel rest
  | fuel + 1, (_ + 1, .num _) :: rest => depthNodeBudget fuel rest
  | fuel + 1, (depth + 1, .arr items) :: rest =>
    depthNodeBudget fuel (items.map (fun item => (depth, item)) ++ rest)
  | fuel + 1, (depth + 1, .obj fields) :: rest =>
    depthNodeBudget fuel (fields.map (fun entry => (depth, entry.2)) ++ rest)

def withinBounds (raw : Raw) : Bool :=
  depthNodeBudget transportFuel [(transportDepth, raw)]

/-- Explicit base-ten conversion. Zero emits exactly one digit. The only
    leading digit emitted is 1..9 unless the entire numeral is zero. -/
def decimalAux : Nat → Nat → List Nat → Option (List Nat)
  | 0, _, _ => none
  | fuel + 1, value, suffix =>
    if value < 10 then some ((48 + value) :: suffix)
    else decimalAux fuel (value / 10) ((48 + value % 10) :: suffix)

def decimal (value : Nat) : Option (List Nat) :=
  decimalAux transportByteLimit value []

mutual
  /-- A compact serializer with no escape or raw-fragment constructor. -/
  def serializeRaw : Nat → Nat → Raw → Option (List Nat)
    | 0, _, _ => none
    | _ + 1, 0, _ => none
    | _ + 1, _ + 1, .str bytes =>
      if stringBytes bytes then some (34 :: (bytes ++ [34])) else none
    | _ + 1, _ + 1, .num value => decimal value
    | fuel + 1, depth + 1, .arr items => do
      let bytes ← serializeItems fuel depth items
      pure (91 :: (bytes ++ [93]))
    | fuel + 1, depth + 1, .obj fields =>
      if orderedFields fields then do
        let bytes ← serializeFields fuel depth fields
        pure (123 :: (bytes ++ [125]))
      else none

  def serializeItems : Nat → Nat → List Raw → Option (List Nat)
    | _, _, [] => some []
    | 0, _, _ :: _ => none
    | fuel + 1, depth, value :: rest => do
      let bytes ← serializeRaw fuel depth value
      match rest with
      | [] => pure bytes
      | _ :: _ =>
        let suffix ← serializeItems fuel depth rest
        pure (bytes ++ (44 :: suffix))

  def serializeFields : Nat → Nat → List (List Nat × Raw) → Option (List Nat)
    | _, _, [] => some []
    | 0, _, _ :: _ => none
    | fuel + 1, depth, (key, value) :: rest =>
      if stringBytes key then do
        let bytes ← serializeRaw fuel depth value
        let field := 34 :: (key ++ (34 :: 58 :: bytes))
        match rest with
        | [] => pure field
        | _ :: _ =>
          let suffix ← serializeFields fuel depth rest
          pure (field ++ (44 :: suffix))
      else none
end

/-- The byte and node checks are part of the accepted transport domain. -/
def serializeChecked (raw : Raw) : Option (List Nat) :=
  if withinBounds raw then
    match serializeRaw transportFuel transportDepth raw with
    | none => none
    | some bytes => if bytes.length ≤ transportByteLimit then some bytes else none
  else none

def digitByte (byte : Nat) : Bool := decide (48 ≤ byte ∧ byte ≤ 57)

/-- Called after an opening quote. It consumes its closing quote, never escapes. -/
def parseStringTail : List Nat → List Nat → Option (List Nat × List Nat)
  | [], _ => none
  | byte :: rest, reversed =>
    if byte = 34 then some (reversed.reverse, rest)
    else if stringByte byte then parseStringTail rest (byte :: reversed)
    else none

def parseDigits : List Nat → Nat → Nat × List Nat
  | [], value => (value, [])
  | byte :: rest, value =>
    if digitByte byte then parseDigits rest (value * 10 + (byte - 48))
    else (value, byte :: rest)

/-- A zero cannot be followed by another decimal digit. A separator is checked
    by the enclosing parser or by decode's full-consumption check. -/
def parseNumber : List Nat → Option (Nat × List Nat)
  | [] => none
  | byte :: rest =>
    if byte = 48 then
      match rest with
      | next :: _ => if digitByte next then none else some (0, rest)
      | [] => some (0, [])
    else if decide (49 ≤ byte ∧ byte ≤ 57) then
      some (parseDigits rest (byte - 48))
    else none

mutual
  /-- Independent, fuelled parser. Whitespace, escape sequences, signs,
      decimals, bool and null have no admitting parser case. -/
  def parseRaw : Nat → Nat → List Nat → Option (Raw × List Nat)
    | 0, _, _ => none
    | _ + 1, 0, _ => none
    | _ + 1, _ + 1, 34 :: rest => do
      let (bytes, suffix) ← parseStringTail rest []
      pure (.str bytes, suffix)
    | _ + 1, _ + 1, 91 :: 93 :: rest => some (.arr [], rest)
    | fuel + 1, depth + 1, 91 :: rest => do
      let (items, suffix) ← parseItems fuel depth rest
      pure (.arr items, suffix)
    | _ + 1, _ + 1, 123 :: 125 :: rest => some (.obj [], rest)
    | fuel + 1, depth + 1, 123 :: rest => do
      let (fields, suffix) ← parseFields fuel depth rest
      if orderedFields fields then pure (.obj fields, suffix) else none
    | _ + 1, _ + 1, bytes => do
      let (value, suffix) ← parseNumber bytes
      pure (.num value, suffix)

  /-- Nonempty array contents only. A trailing comma therefore cannot pass. -/
  def parseItems : Nat → Nat → List Nat → Option (List Raw × List Nat)
    | 0, _, _ => none
    | fuel + 1, depth, bytes => do
      let (value, suffix) ← parseRaw fuel depth bytes
      match suffix with
      | 93 :: rest => pure ([value], rest)
      | 44 :: rest =>
        let (values, suffix) ← parseItems fuel depth rest
        pure (value :: values, suffix)
      | _ => none

  /-- Nonempty object contents only. Keys must be unescaped strings. -/
  def parseFields : Nat → Nat → List Nat → Option (List (List Nat × Raw) × List Nat)
    | 0, _, _ => none
    | fuel + 1, depth, 34 :: rest => do
      let (key, suffix) ← parseStringTail rest []
      match suffix with
      | 58 :: rest =>
        let (value, suffix) ← parseRaw fuel depth rest
        match suffix with
        | 125 :: rest => pure ([(key, value)], rest)
        | 44 :: rest =>
          let (fields, suffix) ← parseFields fuel depth rest
          pure ((key, value) :: fields, suffix)
        | _ => none
      | _ => none
    | _ + 1, _, _ => none
end

/-- Full consumption, exact byte limit, and whole-tree node limit are mandatory.
    Parser recursion is bounded independently of the value-node counter. -/
def decode (bytes : List Nat) : Option Raw :=
  if bytes.length ≤ transportByteLimit ∧
      bytes.all (fun byte => decide (byte ≤ 255)) = true then
    match parseRaw transportFuel transportDepth bytes with
    | some (raw, []) => if withinBounds raw then some raw else none
    | _ => none
  else none

/-- Successful encoding includes a decoder equality check, not an assumption
    that structurally different inputs cannot happen to emit equal bytes. -/
def checkedEncode (raw : Raw) : Option (List Nat) :=
  match serializeChecked raw with
  | none => none
  | some bytes => if decode bytes = some raw then some bytes else none

/-- Compose separately kernel-checked computational certificates without
    weakening the full byte equality or any transport bound. The premises
    concern the same raw tree and the same independently supplied byte list. -/
theorem checkedEncode_of_parts (raw : Raw) (bytes : List Nat)
    (bounds : withinBounds raw = true)
    (serialized : serializeRaw transportFuel transportDepth raw = some bytes)
    (parsed : parseRaw transportFuel transportDepth bytes = some (raw, []))
    (boundedLength : bytes.length ≤ transportByteLimit)
    (byteRange : bytes.all (fun byte => decide (byte ≤ 255)) = true) :
    checkedEncode raw = some bytes := by
  have encoded : serializeChecked raw = some bytes := by
    simp [serializeChecked, bounds, serialized, boundedLength]
  have decoded : decode bytes = some raw := by
    simp [decode, boundedLength, byteRange, parsed, bounds]
  simp [checkedEncode, encoded, decoded]

/-- Generic checked round trip. This says nothing about unaccepted inputs. -/
theorem checkedEncode_roundtrip (raw : Raw) (bytes : List Nat)
    (accepted : checkedEncode raw = some bytes) : decode bytes = some raw := by
  unfold checkedEncode at accepted
  cases encoded : serializeChecked raw with
  | none => simp [encoded] at accepted
  | some candidate =>
    by_cases parsed : decode candidate = some raw
    · have same : candidate = bytes := by simpa [encoded, parsed] using accepted
      simpa [same] using parsed
    · simp [encoded, parsed] at accepted

/-- Equal accepted bytes identify one inert whole-document Raw tree. The proof
    uses decoder equality and does not postulate serializer injectivity. -/
theorem checkedEncode_determinate (a b : Raw) (bytes : List Nat)
    (left : checkedEncode a = some bytes)
    (right : checkedEncode b = some bytes) : a = b := by
  have decodedLeft := checkedEncode_roundtrip a bytes left
  have decodedRight := checkedEncode_roundtrip b bytes right
  exact Option.some.inj (decodedLeft.symm.trans decodedRight)


end HiaCoreSyntaxSlice

#print axioms HiaCoreSyntaxSlice.checkedEncode_determinate
#print axioms HiaCoreSyntaxSlice.checkedEncode_of_parts
#print axioms HiaCoreSyntaxSlice.checkedEncode_roundtrip
/-!
UNCHECKED helper proof text until the pinned Lean 4.19 kernel accepts it.
Append after the exact transport portion of CoreSyntaxSlice.lean. No imports.

These are one-step equalities for the existing functions, not replacement
semantics. The f/d parameters are the precise child call arguments. No rule
resets fuel, drops a suffix, admits a numeric boundary, or supplies a fact from
Python. Concrete leaf certificates and all byte/source bindings remain required.
-/

namespace HiaCoreSyntaxSlice.Structured

/-- The child list call uses exactly f and d. -/
theorem serialize_array (f d : Nat) (items : List Raw) (output : List Nat)
    (children : serializeItems f d items = some output) :
    serializeRaw (f + 1) (d + 1) (.arr items) =
      some (91 :: (output ++ [93])) := by
  simp [serializeRaw, children]

theorem serialize_object (f d : Nat) (fields : List (List Nat × Raw))
    (output : List Nat) (ordered : orderedFields fields = true)
    (children : serializeFields f d fields = some output) :
    serializeRaw (f + 1) (d + 1) (.obj fields) =
      some (123 :: (output ++ [125])) := by
  simp [serializeRaw, ordered, children]

theorem serialize_items_nil (f d : Nat) :
    serializeItems f d [] = some [] := by
  cases f <;> rfl

theorem serialize_items_single (f d : Nat) (value : Raw) (output : List Nat)
    (child : serializeRaw f d value = some output) :
    serializeItems (f + 1) d [value] = some output := by
  simp [serializeItems, child]

theorem serialize_items_cons (f d : Nat) (value next : Raw) (rest : List Raw)
    (output suffix : List Nat)
    (child : serializeRaw f d value = some output)
    (children : serializeItems f d (next :: rest) = some suffix) :
    serializeItems (f + 1) d (value :: next :: rest) =
      some (output ++ (44 :: suffix)) := by
  simp [serializeItems, child, children]

theorem serialize_fields_nil (f d : Nat) :
    serializeFields f d [] = some [] := by
  cases f <;> rfl

theorem serialize_fields_single (f d : Nat) (key : List Nat) (value : Raw)
    (output : List Nat) (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output) :
    serializeFields (f + 1) d [(key, value)] =
      some (34 :: (key ++ (34 :: 58 :: output))) := by
  simp [serializeFields, keyDomain, child]

theorem serialize_fields_cons (f d : Nat) (key : List Nat) (value : Raw)
    (next : List Nat × Raw) (rest : List (List Nat × Raw))
    (output suffix : List Nat) (keyDomain : stringBytes key = true)
    (child : serializeRaw f d value = some output)
    (children : serializeFields f d (next :: rest) = some suffix) :
    serializeFields (f + 1) d ((key, value) :: next :: rest) =
      some ((34 :: (key ++ (34 :: 58 :: output))) ++ (44 :: suffix)) := by
  simp [serializeFields, keyDomain, child, children]

theorem serialize_string (f d : Nat) (value : List Nat)
    (domain : stringBytes value = true) :
    serializeRaw (f + 1) (d + 1) (.str value) =
      some (34 :: (value ++ [34])) := by
  simp [serializeRaw, domain]

theorem serialize_number (f d value : Nat) (output : List Nat)
    (digits : decimal value = some output) :
    serializeRaw (f + 1) (d + 1) (.num value) = some output := by
  simp [serializeRaw, digits]

/-- Exclude the earlier empty-array pattern before applying the list rule. -/
theorem parse_array (f d : Nat) (input tail : List Nat) (items : List Raw)
    (notEmptyClose : input.head? ≠ some 93)
    (children : parseItems f d input = some (items, tail)) :
    parseRaw (f + 1) (d + 1) (91 :: input) = some (.arr items, tail) := by
  unfold parseRaw
  split
  case h_1 => omega
  case h_2 => omega
  case h_3 =>
    rename_i hinput
    have bad : (91 : Nat) = 34 := (List.cons.inj hinput).1
    omega
  case h_4 =>
    rename_i hinput
    exact False.elim
      (notEmptyClose (congrArg List.head? (List.cons.inj hinput).2))
  case h_5 =>
    rename_i childFuel childDepth rest excluded hf hd hinput
    have fuelEq : f = childFuel := Nat.succ.inj hf
    have depthEq : d = childDepth := Nat.succ.inj hd
    have inputEq : input = rest := (List.cons.inj hinput).2
    rw [← fuelEq, ← depthEq, ← inputEq, children] <;> rfl
  case h_6 =>
    rename_i hinput
    have bad : (91 : Nat) = 123 := (List.cons.inj hinput).1
    omega
  case h_7 =>
    rename_i hinput
    have bad : (91 : Nat) = 123 := (List.cons.inj hinput).1
    omega
  case h_8 =>
    rename_i noString noEmptyArray noArray noEmptyObject noObject
    exact False.elim (noArray input rfl)

/-- The explicit opening quote excludes the earlier empty-object pattern. -/
theorem parse_object (f d : Nat) (input tail : List Nat)
    (fields : List (List Nat × Raw))
    (ordered : orderedFields fields = true)
    (children : parseFields f d (34 :: input) = some (fields, tail)) :
    parseRaw (f + 1) (d + 1) (123 :: 34 :: input) =
      some (.obj fields, tail) := by
  simp [parseRaw, children, ordered]

theorem parse_items_last (f d : Nat) (input tail : List Nat) (value : Raw)
    (child : parseRaw f d input = some (value, 93 :: tail)) :
    parseItems (f + 1) d input = some ([value], tail) := by
  simp [parseItems, child]

theorem parse_items_cons (f d : Nat) (input middle tail : List Nat)
    (value : Raw) (rest : List Raw)
    (child : parseRaw f d input = some (value, 44 :: middle))
    (children : parseItems f d middle = some (rest, tail)) :
    parseItems (f + 1) d input = some (value :: rest, tail) := by
  simp [parseItems, child, children]

theorem parse_fields_last (f d : Nat) (keyInput key valueInput tail : List Nat)
    (value : Raw)
    (keyRead : parseStringTail keyInput [] = some (key, 58 :: valueInput))
    (child : parseRaw f d valueInput = some (value, 125 :: tail)) :
    parseFields (f + 1) d (34 :: keyInput) = some ([(key, value)], tail) := by
  simp [parseFields, keyRead, child]

theorem parse_fields_cons (f d : Nat)
    (keyInput key valueInput middle tail : List Nat)
    (value : Raw) (rest : List (List Nat × Raw))
    (keyRead : parseStringTail keyInput [] = some (key, 58 :: valueInput))
    (child : parseRaw f d valueInput = some (value, 44 :: middle))
    (children : parseFields f d middle = some (rest, tail)) :
    parseFields (f + 1) d (34 :: keyInput) = some ((key, value) :: rest, tail) := by
  simp [parseFields, keyRead, child, children]

theorem parse_empty_array (f d : Nat) (tail : List Nat) :
    parseRaw (f + 1) (d + 1) (91 :: 93 :: tail) = some (.arr [], tail) := by
  rfl

theorem parse_empty_object (f d : Nat) (tail : List Nat) :
    parseRaw (f + 1) (d + 1) (123 :: 125 :: tail) = some (.obj [], tail) := by
  rfl

theorem parse_string (f d : Nat) (input value tail : List Nat)
    (characters : parseStringTail input [] = some (value, tail)) :
    parseRaw (f + 1) (d + 1) (34 :: input) = some (.str value, tail) := by
  simp [parseRaw, characters]

/-- Reading a valid quoted prefix does not inspect the suffix after its quote.
    The accumulator form supports induction without assumptions about that suffix. -/
theorem parse_string_tail_prefix (segment suffix acc : List Nat) :
    stringBytes segment = true →
    parseStringTail (segment ++ (34 :: suffix)) acc =
      some (acc.reverse ++ segment, suffix) := by
  induction segment generalizing acc with
  | nil =>
    intro _domain
    simp [parseStringTail]
  | cons first rest previous =>
    intro domain
    have parts : stringByte first = true ∧ stringBytes rest = true := by
      simpa only [stringBytes, Bool.and_eq_true] using domain
    have allowed : 32 ≤ first ∧ first ≤ 126 ∧ first ≠ 34 ∧ first ≠ 92 := by
      simpa [stringByte] using parts.1
    have notQuote : first ≠ 34 := allowed.2.2.1
    have remaining := previous (first :: acc) parts.2
    simpa [parseStringTail, notQuote, parts.1, List.reverse_cons, List.append_assoc]
      using remaining

/-- A key packet supplies its checked domain and this symbolic-tail equation. -/
theorem parse_key_prefix (key tail : List Nat) (domain : stringBytes key = true) :
    parseStringTail (key ++ (34 :: 58 :: tail)) [] = some (key, 58 :: tail) := by
  simpa using parse_string_tail_prefix key (58 :: tail) [] domain

/-
Leaf-generation contract (not an extra theorem or assumed fact):

For nonnumeric complete leaf bytes b and Raw r at exact F,D, prove
  ∀ tail, parseRaw F D (b ++ tail) = some (r, tail).
For a numeric leaf use its actual structural delimiter c ∈ {44,93,125}:
  ∀ tail, parseRaw F D (b ++ (c :: tail)) = some (r, c :: tail).
For a key k, prove stringBytes k = true and
  ∀ tail, parseStringTail (k ++ (34 :: 58 :: tail)) [] = some (k, 58 :: tail).

These are closed small-prefix proofs after introducing the symbolic tail.
Unfold only the local leaf/key definitions. Never replace the numeric form with
an arbitrary-suffix extension rule: decimal bytes [49] followed by [50] parse
as 12. Root composition must still return the exact empty suffix.
-/

/-- Decimal digits cannot be split by an arbitrary suffix-extension rule. -/
theorem reject_numeric_split :
    ¬ (parseRaw 2 2 [49, 50] = some (.num 1, [50])) := by
  intro claim
  change some (Raw.num 12, ([] : List Nat)) = some (Raw.num 1, [50]) at claim
  have tails : ([] : List Nat) = [50] := congrArg Prod.snd (Option.some.inj claim)
  cases tails

/-- A colon cannot replace the comma between two array items. -/
theorem reject_wrong_separator :
    ¬ (parseRaw 8 4 [91, 49, 58, 50, 93] =
      some (.arr [.num 1, .num 2], [])) := by
  decide +kernel

/-- An object close cannot terminate an array. -/
theorem reject_wrong_closing :
    ¬ (parseRaw 8 4 [91, 49, 125] = some (.arr [.num 1], [])) := by
  decide +kernel

/-- A successful prefix parse does not authorize dropping remaining bytes. -/
theorem reject_trailing_bytes :
    ¬ (parseRaw 2 2 [91, 93, 48] = some (.arr [], [])) ∧
    ¬ (decode [91, 93, 48] = some (.arr [])) := by
  constructor
  · intro claim
    change some (Raw.arr [], [48]) = some (Raw.arr [], ([] : List Nat)) at claim
    have tails : [48] = ([] : List Nat) := congrArg Prod.snd (Option.some.inj claim)
    cases tails
  · intro claim
    change none = some (Raw.arr []) at claim
    cases claim

theorem reject_insufficient_fuel :
    ¬ (parseRaw 0 2 [48] = some (.num 0, [])) := by
  decide +kernel

theorem reject_insufficient_depth :
    ¬ (parseRaw 2 0 [48] = some (.num 0, [])) := by
  decide +kernel

/-- Fixed Raw cannot justify a different literal byte inside its encoding. -/
theorem reject_changed_leaf_byte :
    ¬ (serializeRaw 2 2 (.str [97]) = some [34, 98, 34]) := by
  decide +kernel

/-- Both distinct sufficient fuel values succeed. Fuel inequality alone is
    not a sound negative-control criterion. -/
theorem reject_distinct_sufficient_fuel_failure :
    ¬ (parseRaw 1 1 [48] ≠ some (.num 0, []) ∨
       parseRaw 2 1 [48] ≠ some (.num 0, [])) := by
  intro failure
  cases failure with
  | inl rejected => exact rejected rfl
  | inr rejected => exact rejected rfl

end HiaCoreSyntaxSlice.Structured
#print axioms HiaCoreSyntaxSlice.Structured.parse_array
#print axioms HiaCoreSyntaxSlice.Structured.parse_empty_array
#print axioms HiaCoreSyntaxSlice.Structured.parse_empty_object
#print axioms HiaCoreSyntaxSlice.Structured.parse_fields_cons
#print axioms HiaCoreSyntaxSlice.Structured.parse_fields_last
#print axioms HiaCoreSyntaxSlice.Structured.parse_items_cons
#print axioms HiaCoreSyntaxSlice.Structured.parse_items_last
#print axioms HiaCoreSyntaxSlice.Structured.parse_key_prefix
#print axioms HiaCoreSyntaxSlice.Structured.parse_object
#print axioms HiaCoreSyntaxSlice.Structured.parse_string
#print axioms HiaCoreSyntaxSlice.Structured.parse_string_tail_prefix
#print axioms HiaCoreSyntaxSlice.Structured.reject_changed_leaf_byte
#print axioms HiaCoreSyntaxSlice.Structured.reject_distinct_sufficient_fuel_failure
#print axioms HiaCoreSyntaxSlice.Structured.reject_insufficient_depth
#print axioms HiaCoreSyntaxSlice.Structured.reject_insufficient_fuel
#print axioms HiaCoreSyntaxSlice.Structured.reject_numeric_split
#print axioms HiaCoreSyntaxSlice.Structured.reject_trailing_bytes
#print axioms HiaCoreSyntaxSlice.Structured.reject_wrong_closing
#print axioms HiaCoreSyntaxSlice.Structured.reject_wrong_separator
#print axioms HiaCoreSyntaxSlice.Structured.serialize_array
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_cons
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_nil
#print axioms HiaCoreSyntaxSlice.Structured.serialize_fields_single
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_cons
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_nil
#print axioms HiaCoreSyntaxSlice.Structured.serialize_items_single
#print axioms HiaCoreSyntaxSlice.Structured.serialize_number
#print axioms HiaCoreSyntaxSlice.Structured.serialize_object
#print axioms HiaCoreSyntaxSlice.Structured.serialize_string
